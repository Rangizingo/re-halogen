000000000099ce00 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi1ELi2EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi>:
; _ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi1ELi2EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi():
	s_clause 0x1                                               // 00000099CE00: BF850001
	s_load_b32 s3, s[0:1], 0x88                                // 00000099CE04: F40000C0 F8000088
	s_load_b512 s[12:27], s[0:1], null                         // 00000099CE0C: F4100300 F8000000
	v_and_b32_e32 v72, 31, v0                                  // 00000099CE14: 3690009F
	v_lshrrev_b32_e32 v71, 5, v0                               // 00000099CE18: 328E0085
	s_mov_b32 s4, -1                                           // 00000099CE1C: BE8400C1
	s_waitcnt lgkmcnt(0)                                       // 00000099CE20: BF89FC07
	s_cmp_lt_i32 s2, s3                                        // 00000099CE24: BF040302
	s_cbranch_scc1 2246                                        // 00000099CE28: BFA208C6 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi1ELi2EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x2344>
	s_load_b64 s[8:9], s[0:1], 0x7c                            // 00000099CE2C: F4040200 F800007C
	s_sub_i32 s3, s2, s3                                       // 00000099CE34: 81830302
	s_clause 0x1                                               // 00000099CE38: BF850001
	s_load_b256 s[44:51], s[0:1], 0x60                         // 00000099CE3C: F40C0B00 F8000060
	s_load_b256 s[36:43], s[0:1], 0x40                         // 00000099CE44: F40C0900 F8000040
	s_mov_b32 s33, 0                                           // 00000099CE4C: BEA10080
	s_mov_b32 s28, exec_lo                                     // 00000099CE50: BE9C007E
	s_waitcnt lgkmcnt(0)                                       // 00000099CE54: BF89FC07
	s_abs_i32 s4, s9                                           // 00000099CE58: BE841509
	s_ashr_i32 s7, s9, 31                                      // 00000099CE5C: 86079F09
	s_cvt_f32_u32 s5, s4                                       // 00000099CE60: BE856504
	s_sub_i32 s6, 0, s4                                        // 00000099CE64: 81860480
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000099CE68: BF87029A
	v_rcp_iflag_f32_e32 v1, s5                                 // 00000099CE6C: 7E025605
	v_readfirstlane_b32 s5, v1                                 // 00000099CE70: 7E0A0501
	s_mul_f32 s5, s5, 0x4f7ffffe                               // 00000099CE74: A205FF05 4F7FFFFE
	s_delay_alu instid0(SALU_CYCLE_3) | instskip(NEXT) | instid1(SALU_CYCLE_3)// 00000099CE7C: BF87059B
	s_cvt_u32_f32 s5, s5                                       // 00000099CE80: BE856705
	s_mul_i32 s6, s6, s5                                       // 00000099CE84: 96060506
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000099CE88: BF870499
	s_mul_hi_u32 s6, s5, s6                                    // 00000099CE8C: 96860605
	s_add_i32 s5, s5, s6                                       // 00000099CE90: 81050605
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000099CE94: BF870499
	s_mul_hi_u32 s5, s3, s5                                    // 00000099CE98: 96850503
	s_mul_i32 s6, s5, s4                                       // 00000099CE9C: 96060405
	s_add_i32 s10, s5, 1                                       // 00000099CEA0: 810A8105
	s_sub_i32 s6, s3, s6                                       // 00000099CEA4: 81860603
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000099CEA8: BF870009
	s_sub_i32 s11, s6, s4                                      // 00000099CEAC: 818B0406
	s_cmp_ge_u32 s6, s4                                        // 00000099CEB0: BF090406
	s_cselect_b32 s5, s10, s5                                  // 00000099CEB4: 9805050A
	s_cselect_b32 s6, s11, s6                                  // 00000099CEB8: 9806060B
	s_add_i32 s10, s5, 1                                       // 00000099CEBC: 810A8105
	s_cmp_ge_u32 s6, s4                                        // 00000099CEC0: BF090406
	s_cselect_b32 s4, s10, s5                                  // 00000099CEC4: 9804050A
	s_ashr_i32 s11, s50, 31                                    // 00000099CEC8: 860B9F32
	s_xor_b32 s4, s4, s7                                       // 00000099CECC: 8D040704
	s_lshr_b32 s1, s11, 25                                     // 00000099CED0: 8501990B
	s_sub_i32 s10, s4, s7                                      // 00000099CED4: 818A0704
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000099CED8: BF870499
	s_mul_i32 s0, s10, s9                                      // 00000099CEDC: 9600090A
	s_sub_i32 s30, s3, s0                                      // 00000099CEE0: 819E0003
	s_add_i32 s0, s50, s1                                      // 00000099CEE4: 81000132
	s_mul_i32 s31, s30, s8                                     // 00000099CEE8: 961F081E
	s_ashr_i32 s0, s0, 7                                       // 00000099CEEC: 86008700
	s_add_i32 s1, s31, s8                                      // 00000099CEF0: 8101081F
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000099CEF4: BF870499
	s_min_i32 s0, s0, s1                                       // 00000099CEF8: 89000100
	s_sub_i32 s29, s0, s31                                     // 00000099CEFC: 819D1F00
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000099CF00: BF870009
	.long 0xd4c4007e                                           // 00000099CF04: D4C4007E
	v_cndmask_b32_e32 v1, s29, v71, vcc_lo                     // 00000099CF08: 02028E1D
	s_cbranch_execz 503                                        // 00000099CF0C: BFA501F7 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi1ELi2EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x8ec>
	s_add_i32 s34, s48, -1                                     // 00000099CF10: 8122C130
	s_cmp_lg_u64 s[40:41], 0                                   // 00000099CF14: BF118028
	v_dual_mov_b32 v8, v71 :: v_dual_and_b32 v1, 1, v0         // 00000099CF18: CA240147 08000081
	s_cselect_b32 s35, -1, 0                                   // 00000099CF20: 982380C1
	s_abs_i32 s51, s29                                         // 00000099CF24: BEB3151D
	v_and_b32_e32 v2, 2, v0                                    // 00000099CF28: 36040082
	s_cvt_f32_u32 s0, s51                                      // 00000099CF2C: BE806533
	v_lshlrev_b32_e32 v6, 3, v72                               // 00000099CF30: 300C9083
	v_lshlrev_b32_e32 v7, 7, v71                               // 00000099CF34: 300E8E87
	v_and_b32_e32 v3, 4, v0                                    // 00000099CF38: 36060084
	v_rcp_iflag_f32_e32 v4, s0                                 // 00000099CF3C: 7E085600
	v_and_b32_e32 v5, 8, v0                                    // 00000099CF40: 360A0088
	.long 0xd44a0001                                           // 00000099CF44: D44A0001
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 00000099CF48: 02020280
	.long 0xd44a0003                                           // 00000099CF4C: D44A0003
	v_cndmask_b32_e32 v1, 0, v2, vcc_lo                        // 00000099CF50: 02020480
	v_lshl_or_b32 v1, v71, 8, v6                               // 00000099CF54: D6560001 04191147
	v_lshl_add_u32 v2, s31, 7, v7                              // 00000099CF5C: D6460002 041D0E1F
	s_ashr_i32 s53, s29, 31                                    // 00000099CF64: 86359F1D
	s_sub_i32 s55, 0, s51                                      // 00000099CF68: 81B73380
	s_mul_i32 s8, s53, 0x1400                                  // 00000099CF6C: 9608FF35 00001400
	.long 0xd44c0000                                           // 00000099CF74: D44C0000
	v_cndmask_b32_e32 v1, 16, v72, vcc_lo                      // 00000099CF78: 02029090
	v_readfirstlane_b32 s5, v4                                 // 00000099CF7C: 7E0A0504
	.long 0xd44a0004                                           // 00000099CF80: D44A0004
	v_cndmask_b32_e32 v1, 0, v3, vcc_lo                        // 00000099CF84: 02020680
	v_subrev_nc_u32_e32 v9, s8, v1                             // 00000099CF88: 4E120208
	v_lshl_or_b32 v1, v72, 2, v2                               // 00000099CF8C: D6560001 04090548
	s_lshl_b32 s6, s29, 7                                      // 00000099CF94: 8406871D
	s_mul_f32 s7, s5, 0x4f7ffffe                               // 00000099CF98: A207FF05 4F7FFFFE
	.long 0xd44a0005                                           // 00000099CFA0: D44A0005
	v_cndmask_b32_e32 v1, 0, v5, vcc_lo                        // 00000099CFA4: 02020A80
	s_mov_b32 s52, 0x76543210                                  // 00000099CFA8: BEB400FF 76543210
	s_lshl_b32 s54, s29, 8                                     // 00000099CFB0: 8436881D
	s_cvt_u32_f32 s7, s7                                       // 00000099CFB4: BE876707
	s_mov_b32 s57, 0x3db504f3                                  // 00000099CFB8: BEB900FF 3DB504F3
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000099CFC0: BF87049A
	s_mul_i32 s55, s55, s7                                     // 00000099CFC4: 96370737
	s_mul_hi_u32 s8, s7, s55                                   // 00000099CFC8: 96883707
	s_sub_i32 s55, 0, s6                                       // 00000099CFCC: 81B70680
	s_add_i32 s56, s7, s8                                      // 00000099CFD0: 81380807
	s_branch 164                                               // 00000099CFD4: BFA000A4 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi1ELi2EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x468>
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000099CFD8: BF870091
	.long 0xd7006a02                                           // 00000099CFDC: D7006A02
	v_cndmask_b32_e32 v1, s26, v2, vcc_lo                      // 00000099CFE0: 0202041A
	v_add_co_ci_u32_e64 v3, null, s27, v3, vcc_lo              // 00000099CFE4: D5207C03 01AA061B
	v_sub_f32_e32 v4, v15, v13                                 // 00000099CFEC: 08081B0F
	v_add_nc_u32_e32 v1, 0x400, v1                             // 00000099CFF0: 4A0202FF 00000400
	global_load_d16_b16 v2, v[2:3], off offset:6               // 00000099CFF8: DC820006 027C0002
	s_waitcnt vmcnt(0)                                         // 00000099D000: BF8903F7
	v_fma_mix_f32 v5, v14, v2, v12 op_sel_hi:[0,1,0]           // 00000099D004: CC200005 1432050E
	v_fma_mix_f32 v2, -v14, v2, v12 op_sel_hi:[0,1,0]          // 00000099D00C: CC200002 3432050E
	v_add_f32_e32 v3, v15, v13                                 // 00000099D014: 06061B0F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000099D018: BF8701A2
	v_add_f32_e32 v7, v4, v2                                   // 00000099D01C: 060E0504
	v_sub_f32_e32 v2, v4, v2                                   // 00000099D020: 08040504
	v_add_f32_e32 v6, v3, v5                                   // 00000099D024: 060C0B03
	v_sub_f32_e32 v3, v3, v5                                   // 00000099D028: 08060B03
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000099D02C: BF870193
	v_mov_b32_dpp v13, v2 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000099D030: 7E1A02FA FF016102
	v_mov_b32_dpp v4, v6 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000099D038: 7E0802FA FF016106
	v_cndmask_b32_e64 v6, -v6, v6, s1                          // 00000099D040: D5010006 20060D06
	v_cndmask_b32_e64 v2, -v2, v2, s1                          // 00000099D048: D5010002 20060502
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 00000099D050: BF870142
	v_add_f32_e32 v4, v6, v4                                   // 00000099D054: 06080906
	v_mov_b32_dpp v5, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000099D058: 7E0A02FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, s1                          // 00000099D060: D5010007 20060F07
	.long 0xd72c0006                                           // 00000099D068: D72C0006
	v_cndmask_b32_e32 v1, 0x1400, v11, vcc_lo                  // 00000099D06C: 020216FF 00001400
	v_add_f32_e32 v5, v7, v5                                   // 00000099D074: 060A0B07
	v_mov_b32_dpp v7, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000099D078: 7E0E02FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, s3                          // 00000099D080: D5010004 200E0904
	s_delay_alu instid0(VALU_DEP_1)                            // 00000099D088: BF870001
	v_add_f32_e32 v4, v4, v7                                   // 00000099D08C: 06080F04
	v_mov_b32_dpp v12, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000099D090: 7E1802FA FF016103
	v_cndmask_b32_e64 v3, -v3, v3, s1                          // 00000099D098: D5010003 20060703
	.long 0xd72c0007                                           // 00000099D0A0: D72C0007
	v_cndmask_b32_e32 v1, s54, v10, vcc_lo                     // 00000099D0A4: 02021436
	v_add_f32_e32 v2, v2, v13                                  // 00000099D0A8: 06041B02
	v_mov_b32_dpp v10, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000099D0AC: 7E1402FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s4                          // 00000099D0B4: D5010004 20120904
	v_add_f32_e32 v3, v3, v12                                  // 00000099D0BC: 06061903
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000099D0C0: BF870224
	v_mov_b32_dpp v13, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000099D0C4: 7E1A02FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, s3                          // 00000099D0CC: D5010002 200E0502
	v_add_f32_e32 v4, v4, v10                                  // 00000099D0D4: 06081504
	v_mov_b32_dpp v11, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000099D0D8: 7E1602FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, s3                          // 00000099D0E0: D5010005 200E0B05
	v_mov_b32_dpp v12, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000099D0E8: 7E1802FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, s3                          // 00000099D0F0: D5010003 200E0703
	v_add_f32_e32 v2, v2, v13                                  // 00000099D0F8: 06041B02
	v_mov_b32_dpp v10, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000099D0FC: 7E1402FA FF016804
	v_add_f32_e32 v5, v5, v11                                  // 00000099D104: 060A1705
	v_cndmask_b32_e64 v4, -v4, v4, s5                          // 00000099D108: D5010004 20160904
	v_add_f32_e32 v3, v3, v12                                  // 00000099D110: 06061903
	v_mov_b32_dpp v13, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000099D114: 7E1A02FA FF016402
	v_cndmask_b32_e64 v2, -v2, v2, s4                          // 00000099D11C: D5010002 20120502
	v_mov_b32_dpp v11, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000099D124: 7E1602FA FF016405
	v_cndmask_b32_e64 v5, -v5, v5, s4                          // 00000099D12C: D5010005 20120B05
	v_mov_b32_dpp v12, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000099D134: 7E1802FA FF016403
	v_cndmask_b32_e64 v3, -v3, v3, s4                          // 00000099D13C: D5010003 20120703
	v_add_f32_e32 v2, v2, v13                                  // 00000099D144: 06041B02
	v_sub_nc_u32_e32 v6, v6, v7                                // 00000099D148: 4C0C0F06
	v_add_f32_e32 v5, v5, v11                                  // 00000099D14C: 060A1705
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000099D150: BF870214
	v_add_f32_e32 v3, v3, v12                                  // 00000099D154: 06061903
	v_mov_b32_dpp v13, v2 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000099D158: 7E1A02FA FF016802
	v_cndmask_b32_e64 v2, -v2, v2, s5                          // 00000099D160: D5010002 20160502
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 00000099D168: BF870254
	v_mov_b32_dpp v11, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000099D16C: 7E1602FA FF016805
	v_cndmask_b32_e64 v5, -v5, v5, s5                          // 00000099D174: D5010005 20160B05
	v_add_nc_u32_e32 v8, 8, v8                                 // 00000099D17C: 4A101088
	v_mov_b32_dpp v12, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000099D180: 7E1802FA FF016803
	v_cndmask_b32_e64 v3, -v3, v3, s5                          // 00000099D188: D5010003 20160703
	v_dual_add_f32 v4, v4, v10 :: v_dual_add_f32 v5, v5, v11   // 00000099D190: C9081504 04041705
	v_add_f32_e32 v2, v2, v13                                  // 00000099D198: 06041B02
	v_cmp_le_i32_e32 vcc_lo, s29, v8                           // 00000099D19C: 7C86101D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000099D1A0: BF870214
	v_dual_add_f32 v3, v3, v12 :: v_dual_add_nc_u32 v6, v9, v6 // 00000099D1A4: C9201903 03060D09
	v_dual_mov_b32 v11, v5 :: v_dual_mov_b32 v10, v4           // 00000099D1AC: CA100105 0B0A0104
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000099D1B4: BF870234
	v_mov_b32_e32 v13, v2                                      // 00000099D1B8: 7E1A0302
	v_cndmask_b32_e64 v5, -v5, v5, s0                          // 00000099D1BC: D5010005 20020B05
	v_cndmask_b32_e64 v4, -v4, v4, s0                          // 00000099D1C4: D5010004 20020904
	v_permlanex16_b32 v11, v11, s52, 0xfedcba98                // 00000099D1CC: D65C000B 03FC690B FEDCBA98
	v_mov_b32_e32 v12, v3                                      // 00000099D1D8: 7E180303
	v_cndmask_b32_e64 v2, -v2, v2, s0                          // 00000099D1DC: D5010002 20020502
	v_cndmask_b32_e64 v3, -v3, v3, s0                          // 00000099D1E4: D5010003 20020703
	v_permlanex16_b32 v10, v10, s52, 0xfedcba98                // 00000099D1EC: D65C000A 03FC690A FEDCBA98
	v_permlanex16_b32 v13, v13, s52, 0xfedcba98                // 00000099D1F8: D65C000D 03FC690D FEDCBA98
	v_add_f32_e32 v5, v5, v11                                  // 00000099D204: 060A1705
	v_permlanex16_b32 v12, v12, s52, 0xfedcba98                // 00000099D208: D65C000C 03FC690C FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000099D214: BF870214
	v_dual_add_f32 v4, v4, v10 :: v_dual_add_nc_u32 v9, 0x800, v9// 00000099D218: C9201504 040812FF 00000800
	v_add_f32_e32 v7, v2, v13                                  // 00000099D224: 060E1B02
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000099D228: BF870214
	v_fma_mixhi_f16 v2, v5, s57, 0                             // 00000099D22C: CC220002 02007305
	v_add_f32_e32 v10, v3, v12                                 // 00000099D234: 06141903
	s_or_b32 s33, vcc_lo, s33                                  // 00000099D238: 8C21216A
	v_fma_mixlo_f16 v2, v4, s57, 0                             // 00000099D23C: CC210002 02007304
	v_fma_mixhi_f16 v3, v7, s57, 0                             // 00000099D244: CC220003 02007307
	s_delay_alu instid0(VALU_DEP_3)                            // 00000099D24C: BF870003
	v_fma_mixlo_f16 v3, v10, s57, 0                            // 00000099D250: CC210003 0200730A
	ds_store_b64 v6, v[2:3] offset:8192                        // 00000099D258: D9342000 00000206
	s_and_not1_b32 exec_lo, exec_lo, s33                       // 00000099D260: 917E217E
	s_cbranch_execz 289                                        // 00000099D264: BFA50121 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi1ELi2EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x8ec>
	.long 0xd72d0002                                           // 00000099D268: D72D0002
	v_cndmask_b32_e32 v0, v8, v56, vcc_lo                      // 00000099D26C: 02007108
	s_mov_b32 s6, -1                                           // 00000099D270: BE8600C1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000099D274: BF870091
	.long 0xd72c0003                                           // 00000099D278: D72C0003
	v_cndmask_b32_e32 v0, v2, v51, vcc_lo                      // 00000099D27C: 02006702
	v_sub_nc_u32_e32 v3, v8, v3                                // 00000099D280: 4C060708
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000099D284: BF870121
	v_subrev_nc_u32_e32 v5, s51, v3                            // 00000099D288: 4E0A0633
	v_cmp_le_u32_e32 vcc_lo, s51, v3                           // 00000099D28C: 7C960633
	v_dual_cndmask_b32 v3, v3, v5 :: v_dual_add_nc_u32 v4, 1, v2// 00000099D290: CA600B03 03040481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000099D298: BF870111
	v_cndmask_b32_e32 v2, v2, v4, vcc_lo                       // 00000099D29C: 02040902
	v_cmp_le_u32_e32 vcc_lo, s51, v3                           // 00000099D2A0: 7C960633
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000099D2A4: BF870092
	v_add_nc_u32_e32 v4, 1, v2                                 // 00000099D2A8: 4A080481
	v_cndmask_b32_e32 v2, v2, v4, vcc_lo                       // 00000099D2AC: 02040902
	s_and_not1_b32 vcc_lo, exec_lo, s35                        // 00000099D2B0: 916A237E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000099D2B4: BF870091
	v_xor_b32_e32 v11, s53, v2                                 // 00000099D2B8: 3A160435
	v_subrev_nc_u32_e32 v10, s53, v11                          // 00000099D2BC: 4E141635
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000099D2C0: BF8700A1
	v_mad_u64_u32 v[6:7], null, s55, v10, v[1:2]               // 00000099D2C4: D6FE7C06 04061437
	v_min_i32_e32 v2, s34, v10                                 // 00000099D2CC: 22041422
	v_mad_i64_i32 v[4:5], null, v2, s50, 0                     // 00000099D2D0: D6FF7C04 02006502
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000099D2D8: BF870093
	v_ashrrev_i32_e32 v7, 31, v6                               // 00000099D2DC: 340E0C9F
	.long 0xd73c0002                                           // 00000099D2E0: D73C0002
	v_cndmask_b32_e32 v1, 1, v6, vcc_lo                        // 00000099D2E4: 02020C81
	s_cbranch_vccnz 212                                        // 00000099D2E8: BFA400D4 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi1ELi2EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x83c>
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000099D2EC: BF870093
	.long 0xd7006a06                                           // 00000099D2F0: D7006A06
	v_cndmask_b32_e32 v1, v4, v6, vcc_lo                       // 00000099D2F4: 02020D04
	v_add_co_ci_u32_e64 v7, null, v5, v7, vcc_lo               // 00000099D2F8: D5207C07 01AA0F05
	.long 0x7f383880                                           // 00000099D300: 7F383880
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000099D304: BF870112
	.long 0xd73c0006                                           // 00000099D308: D73C0006
	v_cndmask_b32_e32 v1, 1, v6, vcc_lo                        // 00000099D30C: 02020C81
	.long 0x7f3e399c                                           // 00000099D310: 7F3E399C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000099D314: BF870092
	.long 0xd7006a0c                                           // 00000099D318: D7006A0C
	v_cndmask_b32_e32 v1, s38, v6, vcc_lo                      // 00000099D31C: 02020C26
	v_add_co_ci_u32_e64 v13, null, s39, v7, vcc_lo             // 00000099D320: D5207C0D 01AA0E27
	.long 0xd7006a06                                           // 00000099D328: D7006A06
	v_cndmask_b32_e32 v1, s40, v6, vcc_lo                      // 00000099D32C: 02020C28
	s_delay_alu instid0(VALU_DEP_1)                            // 00000099D330: BF870001
	v_add_co_ci_u32_e64 v7, null, s41, v7, vcc_lo              // 00000099D334: D5207C07 01AA0E29
	global_load_b64 v[12:13], v[12:13], off                    // 00000099D33C: DC560000 0C7C000C
	.long 0xd7006a0e                                           // 00000099D344: D7006A0E
	v_cndmask_b32_e32 v1, s26, v2, vcc_lo                      // 00000099D348: 0202041A
	global_load_b64 v[6:7], v[6:7], off                        // 00000099D34C: DC560000 067C0006
	v_add_co_ci_u32_e64 v15, null, s27, v3, vcc_lo             // 00000099D354: D5207C0F 01AA061B
	s_clause 0x1                                               // 00000099D35C: BF850001
	global_load_b32 v16, v[14:15], off                         // 00000099D360: DC520000 107C000E
	global_load_d16_b16 v14, v[14:15], off offset:4            // 00000099D368: DC820004 0E7C000E
	s_waitcnt vmcnt(3)                                         // 00000099D370: BF890FF7
	.long 0x7e1e390c                                           // 00000099D374: 7E1E390C
	s_waitcnt vmcnt(2)                                         // 00000099D378: BF890BF7
	v_and_b32_e32 v38, 0xffff0000, v6                          // 00000099D37C: 364C0CFF FFFF0000
	v_lshlrev_b32_e32 v6, 16, v6                               // 00000099D384: 300C0C90
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000099D388: BF870093
	v_lshlrev_b32_e32 v15, 16, v15                             // 00000099D38C: 301E1E90
	v_mul_f32_e32 v19, 0xbfb8aa3b, v15                         // 00000099D390: 10261EFF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000099D398: BF870291
	v_exp_f32_e32 v19, v19                                     // 00000099D39C: 7E264B13
	v_dual_add_f32 v19, 1.0, v19 :: v_dual_and_b32 v12, 0xffff0000, v12// 00000099D3A0: C92426F2 130C18FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000099D3AC: BF870111
	v_mul_f32_e32 v18, 0xbfb8aa3b, v12                         // 00000099D3B0: 102418FF BFB8AA3B
	v_div_scale_f32 v23, null, v19, v19, v15                   // 00000099D3B8: D6FC7C17 043E2713
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000099D3C0: BF8701B2
	v_exp_f32_e32 v18, v18                                     // 00000099D3C4: 7E244B12
	v_lshlrev_b32_e32 v17, 16, v13                             // 00000099D3C8: 30221A90
	v_div_scale_f32 v36, s7, v15, v19, v15                     // 00000099D3CC: D6FC0724 043E270F
	v_rcp_f32_e32 v27, v23                                     // 00000099D3D4: 7E365517
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000099D3D8: BF870196
	v_add_f32_e32 v18, 1.0, v18                                // 00000099D3DC: 062424F2
	v_mul_f32_e32 v20, 0xbfb8aa3b, v17                         // 00000099D3E0: 102822FF BFB8AA3B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000099D3E8: BF870195
	v_fma_f32 v35, -v23, v27, 1.0                              // 00000099D3EC: D6130023 23CA3717
	v_div_scale_f32 v22, null, v18, v18, v12                   // 00000099D3F4: D6FC7C16 04322512
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000099D3FC: BF8701B3
	v_exp_f32_e32 v20, v20                                     // 00000099D400: 7E284B14
	v_and_b32_e32 v13, 0xffff0000, v13                         // 00000099D404: 361A1AFF FFFF0000
	v_div_scale_f32 v32, vcc_lo, v12, v18, v12                 // 00000099D40C: D6FC6A20 0432250C
	v_rcp_f32_e32 v25, v22                                     // 00000099D414: 7E325516
	s_delay_alu instid0(TRANS32_DEP_2) | instid1(VALU_DEP_2)   // 00000099D418: BF870106
	v_dual_add_f32 v20, 1.0, v20 :: v_dual_mul_f32 v21, 0xbfb8aa3b, v13// 00000099D41C: C90628F2 14141AFF BFB8AA3B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000099D428: BF870115
	v_fma_f32 v33, -v22, v25, 1.0                              // 00000099D42C: D6130021 23CA3316
	v_div_scale_f32 v24, null, v20, v20, v17                   // 00000099D434: D6FC7C18 04462914
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000099D43C: BF8701A3
	v_exp_f32_e32 v21, v21                                     // 00000099D440: 7E2A4B15
	v_div_scale_f32 v34, s6, v17, v20, v17                     // 00000099D444: D6FC0622 04462911
	v_fmac_f32_e32 v25, v33, v25                               // 00000099D44C: 56323321
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 00000099D450: BF870313
	v_rcp_f32_e32 v29, v24                                     // 00000099D454: 7E3A5518
	v_add_f32_e32 v21, 1.0, v21                                // 00000099D458: 062A2AF2
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000099D45C: BF870115
	v_fma_f32 v37, -v24, v29, 1.0                              // 00000099D460: D6130025 23CA3B18
	v_div_scale_f32 v26, null, v21, v21, v13                   // 00000099D468: D6FC7C1A 04362B15
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000099D470: BF8701A2
	v_fmac_f32_e32 v29, v37, v29                               // 00000099D474: 563A3B25
	v_mul_f32_e32 v37, v32, v25                                // 00000099D478: 104A3320
	v_rcp_f32_e32 v30, v26                                     // 00000099D47C: 7E3C551A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000099D480: BF870091
	v_fma_f32 v40, -v22, v37, v32                              // 00000099D484: D6130028 24824B16
	v_fmac_f32_e32 v37, v40, v25                               // 00000099D48C: 564A3328
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000099D490: BF870115
	v_fma_f32 v33, -v26, v30, 1.0                              // 00000099D494: D6130021 23CA3D1A
	v_fma_f32 v22, -v22, v37, v32                              // 00000099D49C: D6130016 24824B16
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000099D4A4: BF870112
	v_fmac_f32_e32 v30, v33, v30                               // 00000099D4A8: 563C3D21
	v_div_fmas_f32 v22, v22, v25, v37                          // 00000099D4AC: D6370016 04963316
	s_mov_b32 vcc_lo, s7                                       // 00000099D4B4: BEEA0007
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000099D4B8: BF8701B1
	v_div_fixup_f32 v12, v22, v18, v12                         // 00000099D4BC: D627000C 04322516
	v_fmac_f32_e32 v27, v35, v27                               // 00000099D4C4: 56363723
	v_div_scale_f32 v35, s8, v13, v21, v13                     // 00000099D4C8: D6FC0823 04362B0D
	v_mul_f32_e32 v12, v12, v38                                // 00000099D4D0: 10184D0C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000099D4D4: BF870193
	v_mul_f32_e32 v33, v36, v27                                // 00000099D4D8: 10423724
	v_mul_f32_e32 v41, v35, v30                                // 00000099D4DC: 10523D23
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000099D4E0: BF870193
	.long 0x7e38398c                                           // 00000099D4E4: 7E38398C
	v_fma_f32 v42, -v23, v33, v36                              // 00000099D4E8: D613002A 24924317
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000099D4F0: BF870113
	v_fma_f32 v40, -v26, v41, v35                              // 00000099D4F4: D6130028 248E531A
	v_fmac_f32_e32 v33, v42, v27                               // 00000099D4FC: 5642372A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000099D500: BF870112
	v_fmac_f32_e32 v41, v40, v30                               // 00000099D504: 56523D28
	v_fma_f32 v23, -v23, v33, v36                              // 00000099D508: D6130017 24924317
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000099D510: BF870112
	v_fma_f32 v22, -v26, v41, v35                              // 00000099D514: D6130016 248E531A
	v_div_fmas_f32 v23, v23, v27, v33                          // 00000099D51C: D6370017 04863717
	s_mov_b32 vcc_lo, s6                                       // 00000099D524: BEEA0006
	s_mov_b32 s6, 0                                            // 00000099D528: BE860080
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000099D52C: BF870121
	v_div_fixup_f32 v15, v23, v19, v15                         // 00000099D530: D627000F 043E2717
	v_lshlrev_b32_e32 v19, 16, v7                              // 00000099D538: 30260E90
	v_dual_mul_f32 v6, v15, v6 :: v_dual_and_b32 v7, 0xffff0000, v7// 00000099D53C: C8E40D0F 06060EFF FFFF0000
	v_mul_f32_e32 v39, v34, v29                                // 00000099D548: 104E3B22
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000099D54C: BF870112
	.long 0x7e3e3986                                           // 00000099D550: 7E3E3986
	v_fma_f32 v43, -v24, v39, v34                              // 00000099D554: D613002B 248A4F18
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000099D55C: BF870091
	v_fmac_f32_e32 v39, v43, v29                               // 00000099D560: 564E3B2B
	v_fma_f32 v24, -v24, v39, v34                              // 00000099D564: D6130018 248A4F18
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000099D56C: BF870131
	v_div_fmas_f32 v18, v24, v29, v39                          // 00000099D570: D6370012 049E3B18
	s_mov_b32 vcc_lo, s8                                       // 00000099D578: BEEA0008
	v_div_fmas_f32 v15, v22, v30, v41                          // 00000099D57C: D637000F 04A63D16
	v_div_fixup_f32 v17, v18, v20, v17                         // 00000099D584: D6270011 04462912
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000099D58C: BF8701A2
	v_div_fixup_f32 v13, v15, v21, v13                         // 00000099D590: D627000D 04362B0F
	v_and_b32_e32 v15, 1, v28                                  // 00000099D598: 361E3881
	v_mul_f32_e32 v17, v17, v19                                // 00000099D59C: 10222711
	v_and_b32_e32 v19, 1, v31                                  // 00000099D5A0: 36263E81
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000099D5A4: BF870214
	v_mul_f32_e32 v7, v13, v7                                  // 00000099D5A8: 100E0F0D
	v_add3_u32 v12, v12, v15, 0x7fff                           // 00000099D5AC: D655000C 03FE1F0C 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000099D5B8: BF870214
	v_bfe_u32 v18, v17, 16, 1                                  // 00000099D5BC: D6100012 02052111
	v_add3_u32 v6, v6, v19, 0x7fff                             // 00000099D5C4: D6550006 03FE2706 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000099D5D0: BF870214
	v_bfe_u32 v15, v7, 16, 1                                   // 00000099D5D4: D610000F 02052107
	v_and_b32_e32 v12, 0xffff0000, v12                         // 00000099D5DC: 361818FF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000099D5E4: BF870214
	v_add3_u32 v13, v17, v18, 0x7fff                           // 00000099D5E8: D655000D 03FE2511 00007FFF
	v_and_b32_e32 v6, 0xffff0000, v6                           // 00000099D5F4: 360C0CFF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000099D5FC: BF870194
	v_add3_u32 v7, v7, v15, 0x7fff                             // 00000099D600: D6550007 03FE1F07 00007FFF
	v_and_b32_e32 v17, 0xffff0000, v13                         // 00000099D60C: 36221AFF FFFF0000
	s_waitcnt vmcnt(1)                                         // 00000099D614: BF8907F7
	v_fma_mix_f32 v13, v16, v12, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 00000099D618: CC20080D 8A021910
	v_fma_mix_f32 v15, v16, v6, neg(0) op_sel_hi:[1,0,0]       // 00000099D620: CC20000F 8A020D10
	s_waitcnt vmcnt(0)                                         // 00000099D628: BF8903F7
	v_fma_mix_f32 v12, v14, v17, neg(0) op_sel_hi:[1,0,0]      // 00000099D62C: CC20000C 8A02230E
	v_and_b32_e32 v14, 0xffff0000, v7                          // 00000099D634: 361C0EFF FFFF0000
	s_and_not1_b32 vcc_lo, exec_lo, s6                         // 00000099D63C: 916A067E
	s_cbranch_vccnz 65125                                      // 00000099D640: BFA4FE65 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi1ELi2EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x1d8>
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000099D644: BF870093
	.long 0xd73c0004                                           // 00000099D648: D73C0004
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 00000099D64C: 02020881
	.long 0xd7006a04                                           // 00000099D650: D7006A04
	v_cndmask_b32_e32 v1, s38, v4, vcc_lo                      // 00000099D654: 02020826
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000099D658: BF870111
	v_add_co_ci_u32_e64 v5, null, s39, v5, vcc_lo              // 00000099D65C: D5207C05 01AA0A27
	.long 0xd7006a04                                           // 00000099D664: D7006A04
	v_cndmask_b32_e32 v1, v4, v2, vcc_lo                       // 00000099D668: 02020504
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000099D66C: BF8700A1
	v_add_co_ci_u32_e64 v5, null, v5, v3, vcc_lo               // 00000099D670: D5207C05 01AA0705
	.long 0xd7006a06                                           // 00000099D678: D7006A06
	v_cndmask_b32_e32 v1, s26, v2, vcc_lo                      // 00000099D67C: 0202041A
	v_add_co_ci_u32_e64 v7, null, s27, v3, vcc_lo              // 00000099D680: D5207C07 01AA061B
	global_load_b64 v[4:5], v[4:5], off                        // 00000099D688: DC560000 047C0004
	s_clause 0x1                                               // 00000099D690: BF850001
	global_load_b32 v14, v[6:7], off                           // 00000099D694: DC520000 0E7C0006
	global_load_d16_b16 v6, v[6:7], off offset:4               // 00000099D69C: DC820004 067C0006
	s_waitcnt vmcnt(2)                                         // 00000099D6A4: BF890BF7
	.long 0x7e0e3904                                           // 00000099D6A8: 7E0E3904
	v_and_b32_e32 v4, 0xffff0000, v4                           // 00000099D6AC: 360808FF FFFF0000
	v_lshlrev_b32_e32 v12, 16, v5                              // 00000099D6B4: 30180A90
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000099D6B8: BF8701A3
	v_lshlrev_b32_e32 v7, 16, v7                               // 00000099D6BC: 300E0E90
	s_waitcnt vmcnt(1)                                         // 00000099D6C0: BF8907F7
	v_fma_mix_f32 v13, v14, v4, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 00000099D6C4: CC20080D 8A02090E
	s_waitcnt vmcnt(0)                                         // 00000099D6CC: BF8903F7
	v_fma_mix_f32 v12, v6, v12, neg(0) op_sel_hi:[1,0,0]       // 00000099D6D0: CC20000C 8A021906
	v_fma_mix_f32 v15, v14, v7, neg(0) op_sel_hi:[1,0,0]       // 00000099D6D8: CC20000F 8A020F0E
	v_and_b32_e32 v14, 0xffff0000, v5                          // 00000099D6E0: 361C0AFF FFFF0000
	s_branch 65083                                             // 00000099D6E8: BFA0FE3B <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi1ELi2EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x1d8>
	s_or_b32 exec_lo, exec_lo, s28                             // 00000099D6EC: 8C7E1C7E
	s_bfe_i32 s28, s29, 0x1001c                                // 00000099D6F0: 939CFF1D 0001001C
	s_lshr_b32 s3, s11, 28                                     // 00000099D6F8: 85039C0B
	s_lshr_b64 s[0:1], s[28:29], 29                            // 00000099D6FC: 85809D1C
	s_add_i32 s3, s50, s3                                      // 00000099D700: 81030332
	s_add_i32 s0, s0, 7                                        // 00000099D704: 81008700
	s_lshl_b32 s1, s29, 3                                      // 00000099D708: 8401831D
	s_ashr_i32 s0, s0, 3                                       // 00000099D70C: 86008300
	s_lshl_b32 s4, s31, 3                                      // 00000099D710: 8404831F
	.long 0xd72c0001                                           // 00000099D714: D72C0001
	v_cndmask_b32_e32 v1, s0, v71, vcc_lo                      // 00000099D718: 02028E00
	v_lshlrev_b32_e32 v7, 2, v72                               // 00000099D71C: 300E9082
	s_waitcnt lgkmcnt(0)                                       // 00000099D720: BF89FC07
	s_barrier                                                  // 00000099D724: BFBD0000
	buffer_gl0_inv                                             // 00000099D728: E0AC0000 00000000
	v_add_nc_u32_e32 v2, s0, v1                                // 00000099D730: 4A040200
	s_ashr_i32 s0, s3, 4                                       // 00000099D734: 86008403
	s_ashr_i32 s3, s4, 31                                      // 00000099D738: 86039F04
	s_mul_hi_i32 s5, s10, s0                                   // 00000099D73C: 9705000A
	s_mul_i32 s0, s10, s0                                      // 00000099D740: 9600000A
	v_min_i32_e32 v8, s1, v2                                   // 00000099D744: 22100401
	s_add_u32 s0, s0, s4                                       // 00000099D748: 80000400
	s_addc_u32 s1, s5, s3                                      // 00000099D74C: 82010305
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000099D750: BF870099
	s_lshl_b64 s[4:5], s[0:1], 10                              // 00000099D754: 84848A00
	v_cmp_lt_i32_e32 vcc_lo, v1, v8                            // 00000099D758: 7C821101
	s_add_u32 s1, s24, s4                                      // 00000099D75C: 80010418
	s_addc_u32 s3, s25, s5                                     // 00000099D760: 82030519
	s_and_saveexec_b32 s4, vcc_lo                              // 00000099D764: BE84206A
	s_cbranch_execz 93                                         // 00000099D768: BFA5005D <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi1ELi2EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0xae0>
	.long 0xd7010002                                           // 00000099D76C: D7010002
	v_cndmask_b32_e32 v0, v72, v129, vcc_lo                    // 00000099D770: 02010348
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000099D774: BF870121
	v_cndmask_b32_e64 v3, v2, 31, s0                           // 00000099D778: D5010003 00013F02
	v_ashrrev_i32_e32 v2, 31, v1                               // 00000099D780: 3404029F
	.long 0xd44c0000                                           // 00000099D784: D44C0000
	v_cndmask_b32_e32 v1, 31, v3, vcc_lo                       // 00000099D788: 0202069F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000099D78C: BF870091
	v_cndmask_b32_e64 v5, 0xe1, 1, s0                          // 00000099D790: D5010005 000102FF 000000E1
	v_dual_mov_b32 v4, 0 :: v_dual_add_nc_u32 v9, v5, v3       // 00000099D79C: CA200080 04080705
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000099D7A4: BF870114
	.long 0xd73c0005                                           // 00000099D7A8: D73C0005
	v_cndmask_b32_e32 v1, 10, v1, vcc_lo                       // 00000099D7AC: 0202028A
	.long 0xd73c0002                                           // 00000099D7B0: D73C0002
	v_cndmask_b32_e32 v1, 2, v3, vcc_lo                        // 00000099D7B4: 02020682
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000099D7B8: BF870223
	v_lshlrev_b32_e32 v4, 24, v9                               // 00000099D7BC: 30081298
	v_bfe_i32 v10, v9, 7, 1                                    // 00000099D7C0: D611000A 02050F09
	.long 0xd700000b                                           // 00000099D7C8: D700000B
	v_cndmask_b32_e32 v1, s1, v5, vcc_lo                       // 00000099D7CC: 02020A01
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000099D7D0: BF870211
	v_add_co_ci_u32_e64 v6, null, s3, v6, s0                   // 00000099D7D4: D5207C06 00020C03
	v_ashrrev_i32_e32 v9, 22, v4                               // 00000099D7DC: 34120896
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000099D7E0: BF870093
	.long 0xd7000004                                           // 00000099D7E4: D7000004
	v_cndmask_b32_e32 v1, v11, v2, vcc_lo                      // 00000099D7E8: 0202050B
	v_add_co_ci_u32_e64 v5, null, v6, v3, s0                   // 00000099D7EC: D5207C05 00020706
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000099D7F4: BF870093
	.long 0xd7000009                                           // 00000099D7F8: D7000009
	v_cndmask_b32_e32 v1, v11, v9, vcc_lo                      // 00000099D7FC: 0202130B
	v_add_co_ci_u32_e64 v10, null, v6, v10, s0                 // 00000099D800: D5207C0A 00021506
	.long 0xd700000b                                           // 00000099D808: D700000B
	v_cndmask_b32_e32 v1, v11, v7, vcc_lo                      // 00000099D80C: 02020F0B
	s_delay_alu instid0(VALU_DEP_1)                            // 00000099D810: BF870001
	v_add_co_ci_u32_e64 v12, null, 0, v6, s0                   // 00000099D814: D5207C0C 00020C80
	s_clause 0x17                                              // 00000099D81C: BF850017
	global_load_b32 v2, v[4:5], off                            // 00000099D820: DC520000 027C0004
	global_load_b32 v54, v[4:5], off offset:128                // 00000099D828: DC520080 367C0004
	global_load_b32 v51, v[4:5], off offset:256                // 00000099D830: DC520100 337C0004
	global_load_b32 v48, v[4:5], off offset:384                // 00000099D838: DC520180 307C0004
	global_load_b32 v45, v[4:5], off offset:512                // 00000099D840: DC520200 2D7C0004
	global_load_b32 v42, v[4:5], off offset:640                // 00000099D848: DC520280 2A7C0004
	global_load_b32 v24, v[4:5], off offset:768                // 00000099D850: DC520300 187C0004
	global_load_b32 v18, v[4:5], off offset:896                // 00000099D858: DC520380 127C0004
	global_load_b32 v4, v[9:10], off                           // 00000099D860: DC520000 047C0009
	global_load_b32 v55, v[9:10], off offset:128               // 00000099D868: DC520080 377C0009
	global_load_b32 v52, v[9:10], off offset:256               // 00000099D870: DC520100 347C0009
	global_load_b32 v49, v[9:10], off offset:384               // 00000099D878: DC520180 317C0009
	global_load_b32 v46, v[9:10], off offset:512               // 00000099D880: DC520200 2E7C0009
	global_load_b32 v43, v[9:10], off offset:640               // 00000099D888: DC520280 2B7C0009
	global_load_b32 v25, v[9:10], off offset:768               // 00000099D890: DC520300 197C0009
	global_load_b32 v19, v[9:10], off offset:896               // 00000099D898: DC520380 137C0009
	global_load_b32 v3, v[11:12], off                          // 00000099D8A0: DC520000 037C000B
	global_load_b32 v53, v[11:12], off offset:128              // 00000099D8A8: DC520080 357C000B
	global_load_b32 v50, v[11:12], off offset:256              // 00000099D8B0: DC520100 327C000B
	global_load_b32 v47, v[11:12], off offset:384              // 00000099D8B8: DC520180 2F7C000B
	global_load_b32 v44, v[11:12], off offset:512              // 00000099D8C0: DC520200 2C7C000B
	global_load_b32 v41, v[11:12], off offset:640              // 00000099D8C8: DC520280 297C000B
	global_load_b32 v23, v[11:12], off offset:768              // 00000099D8D0: DC520300 177C000B
	global_load_b32 v17, v[11:12], off offset:896              // 00000099D8D8: DC520380 117C000B
	s_or_b32 exec_lo, exec_lo, s4                              // 00000099D8E0: 8C7E047E
	v_dual_mov_b32 v10, 0 :: v_dual_mov_b32 v9, 0              // 00000099D8E4: CA100080 0A080080
	v_dual_mov_b32 v11, 0 :: v_dual_mov_b32 v12, 0             // 00000099D8EC: CA100080 0B0C0080
	v_dual_mov_b32 v13, 0 :: v_dual_mov_b32 v14, 0             // 00000099D8F4: CA100080 0D0E0080
	v_dual_mov_b32 v15, 0 :: v_dual_mov_b32 v16, 0             // 00000099D8FC: CA100080 0F100080
	s_ashr_i32 s11, s10, 31                                    // 00000099D904: 860B9F0A
	s_and_saveexec_b32 s0, vcc_lo                              // 00000099D908: BE80206A
	s_cbranch_execz 945                                        // 00000099D90C: BFA503B1 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi1ELi2EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x19d4>
	v_dual_mov_b32 v10, 0 :: v_dual_add_nc_u32 v5, -1, v0      // 00000099D910: CA200080 0A0400C1
	v_and_or_b32 v20, v0, 16, 0x2000                           // 00000099D918: D6570014 03FD2100 00002000
	v_dual_mov_b32 v12, 0 :: v_dual_lshlrev_b32 v21, 2, v72    // 00000099D924: CA220080 0C149082
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000099D92C: BF870123
	v_dual_mov_b32 v16, 0 :: v_dual_and_b32 v5, 31, v5         // 00000099D930: CA240080 10040A9F
	v_dual_mov_b32 v9, 0 :: v_dual_mov_b32 v14, 0              // 00000099D938: CA100080 090E0080
	v_dual_mov_b32 v11, 0 :: v_dual_lshlrev_b32 v22, 2, v5     // 00000099D940: CA220080 0B160A82
	v_mov_b32_e32 v13, 0                                       // 00000099D948: 7E1A0280
	v_mov_b32_e32 v15, 0                                       // 00000099D94C: 7E1E0280
	s_mov_b32 s4, 0                                            // 00000099D950: BE840080
	s_movk_i32 s5, 0x1eee                                      // 00000099D954: B0051EEE
	s_branch 867                                               // 00000099D958: BFA00363 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi1ELi2EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x18e8>
	s_or_b32 exec_lo, exec_lo, s6                              // 00000099D95C: 8C7E067E
	s_waitcnt vmcnt(15)                                        // 00000099D960: BF893FF7
	v_alignbit_b32 v56, v2, v4, 16                             // 00000099D964: D6160038 02420902
	s_waitcnt vmcnt(7)                                         // 00000099D96C: BF891FF7
	v_bfe_u32 v57, v3, 12, 16                                  // 00000099D970: D6100039 02411903
	v_bfe_u32 v58, v3, 8, 16                                   // 00000099D978: D610003A 02411103
	v_lshl_add_u32 v1, v1, 5, v20                              // 00000099D980: D6460001 04510B01
	v_bfe_u32 v59, v3, 4, 16                                   // 00000099D988: D610003B 02410903
	v_bfe_u32 v60, v56, 12, 16                                 // 00000099D990: D610003C 02411938
	v_bfe_u32 v63, v56, 8, 16                                  // 00000099D998: D610003F 02411138
	.long 0xd72c0039                                           // 00000099D9A0: D72C0039
	v_cndmask_b32_e32 v1, 0x83dcd12d, v57, vcc_lo              // 00000099D9A4: 020272FF 83DCD12D
	.long 0xd72c003a                                           // 00000099D9AC: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 00000099D9B0: 020274FF 83DCD12D
	.long 0xd72c003b                                           // 00000099D9B8: D72C003B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 00000099D9BC: 020276FF 83DCD12D
	.long 0xd72c003c                                           // 00000099D9C4: D72C003C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v60, vcc_lo              // 00000099D9C8: 020278FF 83DCD12D
	.long 0xd72c003f                                           // 00000099D9D0: D72C003F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v63, vcc_lo              // 00000099D9D4: 02027EFF 83DCD12D
	v_alignbit_b32 v54, v54, v55, 16                           // 00000099D9DC: D6160036 02426F36
	v_alignbit_b32 v51, v51, v52, 16                           // 00000099D9E4: D6160033 02426933
	v_alignbit_b32 v48, v48, v49, 16                           // 00000099D9EC: D6160030 02426330
	v_sad_u8 v57, v57, 0, 0x6400                               // 00000099D9F4: D6220039 03FD0139 00006400
	v_sad_u8 v58, v58, 0, 0x6400                               // 00000099DA00: D622003A 03FD013A 00006400
	v_sad_u8 v59, v59, 0, 0x6400                               // 00000099DA0C: D622003B 03FD013B 00006400
	v_sad_u8 v60, v60, 0, 0x6400                               // 00000099DA18: D622003C 03FD013C 00006400
	v_sad_u8 v63, v63, 0, 0x6400                               // 00000099DA24: D622003F 03FD013F 00006400
	v_and_b32_e32 v57, 0xffff, v57                             // 00000099DA30: 367272FF 0000FFFF
	v_bfe_u32 v49, v48, 12, 16                                 // 00000099DA38: D6100031 02411930
	v_alignbit_b32 v45, v45, v46, 16                           // 00000099DA40: D616002D 02425D2D
	v_and_b32_e32 v60, 0xffff, v60                             // 00000099DA48: 367878FF 0000FFFF
	v_alignbit_b32 v24, v24, v25, 16                           // 00000099DA50: D6160018 02423318
	v_lshl_or_b32 v57, v58, 16, v57                            // 00000099DA58: D6560039 04E5213A
	.long 0xd72c0031                                           // 00000099DA60: D72C0031
	v_cndmask_b32_e32 v1, 0x83dcd12d, v49, vcc_lo              // 00000099DA64: 020262FF 83DCD12D
	v_alignbit_b32 v42, v42, v43, 16                           // 00000099DA6C: D616002A 0242572A
	v_lshl_or_b32 v60, v63, 16, v60                            // 00000099DA74: D656003C 04F1213F
	s_waitcnt vmcnt(5)                                         // 00000099DA7C: BF8917F7
	v_bfe_u32 v63, v50, 4, 16                                  // 00000099DA80: D610003F 02410932
	v_pk_fma_f16 v57, v57, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000099DA88: CC0E0039 0BFC0B39 0000C931
	v_alignbit_b32 v18, v18, v19, 16                           // 00000099DA94: D6160012 02422712
	v_cmp_eq_u32_e32 vcc_lo, v5, v8                            // 00000099DA9C: 7C941105
	v_pk_fma_f16 v58, v60, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000099DAA0: CC0E003A 0BFC0B3C 0000C931
	v_and_b32_e32 v61, 0xffff, v3                              // 00000099DAAC: 367A06FF 0000FFFF
	ds_load_b128 v[1:4], v1                                    // 00000099DAB4: DBFC0000 01000001
	v_bfe_u32 v60, v53, 12, 16                                 // 00000099DABC: D610003C 02411935
	v_sad_u8 v49, v49, 0, 0x6400                               // 00000099DAC4: D6220031 03FD0131 00006400
	s_or_b32 s4, vcc_lo, s4                                    // 00000099DAD0: 8C04046A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000099DAD4: BF870112
	.long 0xd72c003c                                           // 00000099DAD8: D72C003C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v60, vcc_lo              // 00000099DADC: 020278FF 83DCD12D
	v_and_b32_e32 v49, 0xffff, v49                             // 00000099DAE4: 366262FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000099DAEC: BF870092
	v_sad_u8 v60, v60, 0, 0x6400                               // 00000099DAF0: D622003C 03FD013C 00006400
	v_and_b32_e32 v60, 0xffff, v60                             // 00000099DAFC: 367878FF 0000FFFF
	s_waitcnt lgkmcnt(0)                                       // 00000099DB04: BF89FC07
	v_dot2acc_f32_f16 v16, v58, v1                             // 00000099DB08: 0420033A
	.long 0xd72c003d                                           // 00000099DB0C: D72C003D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v61, vcc_lo              // 00000099DB10: 02027AFF 83DCD12D
	v_and_b32_e32 v58, 0xffff, v54                             // 00000099DB18: 36746CFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000099DB20: BF870191
	.long 0xd72c003a                                           // 00000099DB24: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 00000099DB28: 020274FF 83DCD12D
	v_sad_u8 v61, v61, 0, 0x6400                               // 00000099DB30: D622003D 03FD013D 00006400
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000099DB3C: BF870191
	v_lshlrev_b32_e32 v61, 16, v61                             // 00000099DB40: 307A7A90
	v_sad_u8 v58, v58, 0, 0x6400                               // 00000099DB44: D622003A 03FD013A 00006400
	s_delay_alu instid0(VALU_DEP_2)                            // 00000099DB50: BF870002
	v_and_or_b32 v55, 0xffff, v59, v61                         // 00000099DB54: D6570037 04F676FF 0000FFFF
	v_bfe_u32 v59, v54, 12, 16                                 // 00000099DB60: D610003B 02411936
	v_bfe_u32 v61, v54, 8, 16                                  // 00000099DB68: D610003D 02411136
	v_bfe_u32 v54, v54, 4, 16                                  // 00000099DB70: D6100036 02410936
	v_lshlrev_b32_e32 v58, 16, v58                             // 00000099DB78: 30747490
	v_pk_fma_f16 v55, v55, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000099DB7C: CC0E0037 0BFC0B37 0000C931
	.long 0xd72c003b                                           // 00000099DB88: D72C003B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 00000099DB8C: 020276FF 83DCD12D
	.long 0xd72c003d                                           // 00000099DB94: D72C003D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v61, vcc_lo              // 00000099DB98: 02027AFF 83DCD12D
	.long 0xd72c0036                                           // 00000099DBA0: D72C0036
	v_cndmask_b32_e32 v1, 0x83dcd12d, v54, vcc_lo              // 00000099DBA4: 02026CFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000099DBAC: BF870193
	v_sad_u8 v59, v59, 0, 0x6400                               // 00000099DBB0: D622003B 03FD013B 00006400
	v_sad_u8 v61, v61, 0, 0x6400                               // 00000099DBBC: D622003D 03FD013D 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000099DBC8: BF870193
	v_sad_u8 v54, v54, 0, 0x6400                               // 00000099DBCC: D6220036 03FD0136 00006400
	v_and_b32_e32 v59, 0xffff, v59                             // 00000099DBD8: 367676FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000099DBE0: BF870112
	v_and_or_b32 v54, 0xffff, v54, v58                         // 00000099DBE4: D6570036 04EA6CFF 0000FFFF
	v_lshl_or_b32 v59, v61, 16, v59                            // 00000099DBF0: D656003B 04ED213D
	v_bfe_u32 v61, v50, 12, 16                                 // 00000099DBF8: D610003D 02411932
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000099DC00: BF870193
	v_pk_fma_f16 v54, v54, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000099DC04: CC0E0036 0BFC0B36 0000C931
	v_pk_fma_f16 v52, v59, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000099DC10: CC0E0034 0BFC0B3B 0000C931
	v_and_b32_e32 v62, 0xffff, v56                             // 00000099DC1C: 367C70FF 0000FFFF
	v_bfe_u32 v56, v56, 4, 16                                  // 00000099DC24: D6100038 02410938
	.long 0xd72c003d                                           // 00000099DC2C: D72C003D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v61, vcc_lo              // 00000099DC30: 02027AFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000099DC38: BF870214
	v_dot2acc_f32_f16 v15, v52, v1                             // 00000099DC3C: 041E0334
	.long 0xd72c003e                                           // 00000099DC40: D72C003E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v62, vcc_lo              // 00000099DC44: 02027CFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000099DC4C: BF870224
	.long 0xd72c0038                                           // 00000099DC50: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v56, vcc_lo              // 00000099DC54: 020270FF 83DCD12D
	.long 0xd72c0034                                           // 00000099DC5C: D72C0034
	v_cndmask_b32_e32 v1, 0x83dcd12d, v63, vcc_lo              // 00000099DC60: 02027EFF 83DCD12D
	v_dot2acc_f32_f16 v15, v54, v2                             // 00000099DC68: 041E0536
	v_sad_u8 v61, v61, 0, 0x6400                               // 00000099DC6C: D622003D 03FD013D 00006400
	s_waitcnt vmcnt(4)                                         // 00000099DC78: BF8913F7
	v_bfe_u32 v54, v47, 4, 16                                  // 00000099DC7C: D6100036 0241092F
	v_sad_u8 v62, v62, 0, 0x6400                               // 00000099DC84: D622003E 03FD013E 00006400
	v_sad_u8 v56, v56, 0, 0x6400                               // 00000099DC90: D6220038 03FD0138 00006400
	v_sad_u8 v52, v52, 0, 0x6400                               // 00000099DC9C: D6220034 03FD0134 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000099DCA8: BF870093
	v_lshlrev_b32_e32 v62, 16, v62                             // 00000099DCAC: 307C7C90
	v_and_or_b32 v56, 0xffff, v56, v62                         // 00000099DCB0: D6570038 04FA70FF 0000FFFF
	v_bfe_u32 v62, v53, 8, 16                                  // 00000099DCBC: D610003E 02411135
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000099DCC4: BF870092
	v_pk_fma_f16 v56, v56, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000099DCC8: CC0E0038 0BFC0B38 0000C931
	v_dot2acc_f32_f16 v16, v56, v2                             // 00000099DCD4: 04200538
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000099DCD8: BF8701A3
	.long 0xd72c0038                                           // 00000099DCDC: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v62, vcc_lo              // 00000099DCE0: 02027CFF 83DCD12D
	v_bfe_u32 v62, v53, 4, 16                                  // 00000099DCE8: D610003E 02410935
	v_dot2acc_f32_f16 v16, v57, v3                             // 00000099DCF0: 04200739
	v_bfe_u32 v57, v51, 12, 16                                 // 00000099DCF4: D6100039 02411933
	s_delay_alu instid0(VALU_DEP_3)                            // 00000099DCFC: BF870003
	.long 0xd72c003a                                           // 00000099DD00: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v62, vcc_lo              // 00000099DD04: 02027CFF 83DCD12D
	v_bfe_u32 v62, v50, 8, 16                                  // 00000099DD0C: D610003E 02411132
	v_and_b32_e32 v50, 0xffff, v50                             // 00000099DD14: 366464FF 0000FFFF
	v_sad_u8 v56, v56, 0, 0x6400                               // 00000099DD1C: D6220038 03FD0138 00006400
	v_dual_dot2acc_f32_f16 v16, v55, v4 :: v_dual_and_b32 v59, 0xffff, v51// 00000099DD28: CB240937 103A66FF 0000FFFF
	.long 0xd72c0039                                           // 00000099DD34: D72C0039
	v_cndmask_b32_e32 v1, 0x83dcd12d, v57, vcc_lo              // 00000099DD38: 020272FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000099DD40: BF870214
	.long 0xd72c0032                                           // 00000099DD44: D72C0032
	v_cndmask_b32_e32 v1, 0x83dcd12d, v50, vcc_lo              // 00000099DD48: 020264FF 83DCD12D
	v_lshl_or_b32 v56, v56, 16, v60                            // 00000099DD50: D6560038 04F12138
	v_bfe_u32 v60, v51, 8, 16                                  // 00000099DD58: D610003C 02411133
	v_bfe_u32 v51, v51, 4, 16                                  // 00000099DD60: D6100033 02410933
	.long 0xd72c003b                                           // 00000099DD68: D72C003B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 00000099DD6C: 020276FF 83DCD12D
	.long 0xd72c003e                                           // 00000099DD74: D72C003E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v62, vcc_lo              // 00000099DD78: 02027CFF 83DCD12D
	v_sad_u8 v58, v58, 0, 0x6400                               // 00000099DD80: D622003A 03FD013A 00006400
	.long 0xd72c003c                                           // 00000099DD8C: D72C003C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v60, vcc_lo              // 00000099DD90: 020278FF 83DCD12D
	v_sad_u8 v50, v50, 0, 0x6400                               // 00000099DD98: D6220032 03FD0132 00006400
	v_sad_u8 v57, v57, 0, 0x6400                               // 00000099DDA4: D6220039 03FD0139 00006400
	.long 0xd72c0033                                           // 00000099DDB0: D72C0033
	v_cndmask_b32_e32 v1, 0x83dcd12d, v51, vcc_lo              // 00000099DDB4: 020266FF 83DCD12D
	v_pk_fma_f16 v56, v56, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000099DDBC: CC0E0038 0BFC0B38 0000C931
	v_sad_u8 v59, v59, 0, 0x6400                               // 00000099DDC8: D622003B 03FD013B 00006400
	v_lshlrev_b32_e32 v50, 16, v50                             // 00000099DDD4: 30646490
	s_waitcnt vmcnt(3)                                         // 00000099DDD8: BF890FF7
	v_bfe_u32 v55, v44, 8, 16                                  // 00000099DDDC: D6100037 0241112C
	v_sad_u8 v60, v60, 0, 0x6400                               // 00000099DDE4: D622003C 03FD013C 00006400
	v_dot2acc_f32_f16 v15, v56, v3                             // 00000099DDF0: 041E0738
	v_lshlrev_b32_e32 v59, 16, v59                             // 00000099DDF4: 30767690
	v_and_or_b32 v50, 0xffff, v52, v50                         // 00000099DDF8: D6570032 04CA68FF 0000FFFF
	v_sad_u8 v51, v51, 0, 0x6400                               // 00000099DE04: D6220033 03FD0133 00006400
	.long 0xd72c0037                                           // 00000099DE10: D72C0037
	v_cndmask_b32_e32 v1, 0x83dcd12d, v55, vcc_lo              // 00000099DE14: 02026EFF 83DCD12D
	v_bfe_u32 v56, v44, 4, 16                                  // 00000099DE1C: D6100038 0241092C
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000099DE24: BF8701C4
	v_pk_fma_f16 v50, v50, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000099DE28: CC0E0032 0BFC0B32 0000C931
	v_and_b32_e32 v57, 0xffff, v57                             // 00000099DE34: 367272FF 0000FFFF
	v_and_or_b32 v51, 0xffff, v51, v59                         // 00000099DE3C: D6570033 04EE66FF 0000FFFF
	v_and_b32_e32 v59, 0xffff, v61                             // 00000099DE48: 36767AFF 0000FFFF
	v_lshl_or_b32 v57, v60, 16, v57                            // 00000099DE50: D6560039 04E5213C
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000099DE58: BF8701A3
	v_pk_fma_f16 v51, v51, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000099DE5C: CC0E0033 0BFC0B33 0000C931
	v_sad_u8 v60, v62, 0, 0x6400                               // 00000099DE68: D622003C 03FD013E 00006400
	v_pk_fma_f16 v57, v57, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000099DE74: CC0E0039 0BFC0B39 0000C931
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000099DE80: BF870112
	v_lshl_or_b32 v59, v60, 16, v59                            // 00000099DE84: D656003B 04ED213C
	v_dot2acc_f32_f16 v14, v57, v1                             // 00000099DE8C: 041C0339
	v_and_b32_e32 v53, 0xffff, v53                             // 00000099DE90: 366A6AFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000099DE98: BF870193
	v_pk_fma_f16 v52, v59, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000099DE9C: CC0E0034 0BFC0B3B 0000C931
	v_dot2acc_f32_f16 v14, v51, v2                             // 00000099DEA8: 041C0533
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000099DEAC: BF870113
	.long 0xd72c0035                                           // 00000099DEB0: D72C0035
	v_cndmask_b32_e32 v1, 0x83dcd12d, v53, vcc_lo              // 00000099DEB4: 02026AFF 83DCD12D
	v_dot2acc_f32_f16 v14, v52, v3                             // 00000099DEBC: 041C0734
	v_bfe_u32 v52, v47, 12, 16                                 // 00000099DEC0: D6100034 0241192F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000099DEC8: BF870193
	v_sad_u8 v53, v53, 0, 0x6400                               // 00000099DECC: D6220035 03FD0135 00006400
	v_dot2acc_f32_f16 v14, v50, v4                             // 00000099DED8: 041C0932
	v_bfe_u32 v50, v48, 8, 16                                  // 00000099DEDC: D6100032 02411130
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000099DEE4: BF870214
	.long 0xd72c0034                                           // 00000099DEE8: D72C0034
	v_cndmask_b32_e32 v1, 0x83dcd12d, v52, vcc_lo              // 00000099DEEC: 020268FF 83DCD12D
	v_lshlrev_b32_e32 v53, 16, v53                             // 00000099DEF4: 306A6A90
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000099DEF8: BF870113
	.long 0xd72c0032                                           // 00000099DEFC: D72C0032
	v_cndmask_b32_e32 v1, 0x83dcd12d, v50, vcc_lo              // 00000099DF00: 020264FF 83DCD12D
	v_and_or_b32 v53, 0xffff, v58, v53                         // 00000099DF08: D6570035 04D674FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000099DF14: BF870114
	v_sad_u8 v52, v52, 0, 0x6400                               // 00000099DF18: D6220034 03FD0134 00006400
	v_pk_fma_f16 v51, v53, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000099DF24: CC0E0033 0BFC0B35 0000C931
	v_bfe_u32 v53, v47, 8, 16                                  // 00000099DF30: D6100035 0241112F
	v_and_b32_e32 v47, 0xffff, v47                             // 00000099DF38: 365E5EFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4)                            // 00000099DF40: BF870004
	v_and_b32_e32 v52, 0xffff, v52                             // 00000099DF44: 366868FF 0000FFFF
	v_sad_u8 v50, v50, 0, 0x6400                               // 00000099DF4C: D6220032 03FD0132 00006400
	v_dot2acc_f32_f16 v15, v51, v4                             // 00000099DF58: 041E0933
	v_and_b32_e32 v51, 0xffff, v48                             // 00000099DF5C: 366660FF 0000FFFF
	v_bfe_u32 v48, v48, 4, 16                                  // 00000099DF64: D6100030 02410930
	.long 0xd72c0035                                           // 00000099DF6C: D72C0035
	v_cndmask_b32_e32 v1, 0x83dcd12d, v53, vcc_lo              // 00000099DF70: 02026AFF 83DCD12D
	.long 0xd72c002f                                           // 00000099DF78: D72C002F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v47, vcc_lo              // 00000099DF7C: 02025EFF 83DCD12D
	v_lshl_or_b32 v49, v50, 16, v49                            // 00000099DF84: D6560031 04C52132
	.long 0xd72c0033                                           // 00000099DF8C: D72C0033
	v_cndmask_b32_e32 v1, 0x83dcd12d, v51, vcc_lo              // 00000099DF90: 020266FF 83DCD12D
	.long 0xd72c0030                                           // 00000099DF98: D72C0030
	v_cndmask_b32_e32 v1, 0x83dcd12d, v48, vcc_lo              // 00000099DF9C: 020260FF 83DCD12D
	.long 0xd72c0032                                           // 00000099DFA4: D72C0032
	v_cndmask_b32_e32 v1, 0x83dcd12d, v54, vcc_lo              // 00000099DFA8: 02026CFF 83DCD12D
	v_bfe_u32 v54, v44, 12, 16                                 // 00000099DFB0: D6100036 0241192C
	v_pk_fma_f16 v49, v49, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000099DFB8: CC0E0031 0BFC0B31 0000C931
	v_sad_u8 v53, v53, 0, 0x6400                               // 00000099DFC4: D6220035 03FD0135 00006400
	v_sad_u8 v47, v47, 0, 0x6400                               // 00000099DFD0: D622002F 03FD012F 00006400
	v_sad_u8 v51, v51, 0, 0x6400                               // 00000099DFDC: D6220033 03FD0133 00006400
	v_sad_u8 v48, v48, 0, 0x6400                               // 00000099DFE8: D6220030 03FD0130 00006400
	s_delay_alu instid0(VALU_DEP_4)                            // 00000099DFF4: BF870004
	v_lshl_or_b32 v46, v53, 16, v52                            // 00000099DFF8: D656002E 04D12135
	v_bfe_u32 v53, v45, 8, 16                                  // 00000099E000: D6100035 0241112D
	v_sad_u8 v50, v50, 0, 0x6400                               // 00000099E008: D6220032 03FD0132 00006400
	v_lshlrev_b32_e32 v51, 16, v51                             // 00000099E014: 30666690
	v_lshlrev_b32_e32 v47, 16, v47                             // 00000099E018: 305E5E90
	v_dot2acc_f32_f16 v13, v49, v1                             // 00000099E01C: 041A0331
	.long 0xd72c0035                                           // 00000099E020: D72C0035
	v_cndmask_b32_e32 v1, 0x83dcd12d, v53, vcc_lo              // 00000099E024: 02026AFF 83DCD12D
	v_and_b32_e32 v52, 0xffff, v45                             // 00000099E02C: 36685AFF 0000FFFF
	v_and_or_b32 v48, 0xffff, v48, v51                         // 00000099E034: D6570030 04CE60FF 0000FFFF
	v_bfe_u32 v51, v45, 12, 16                                 // 00000099E040: D6100033 0241192D
	v_and_or_b32 v47, 0xffff, v50, v47                         // 00000099E048: D657002F 04BE64FF 0000FFFF
	v_bfe_u32 v45, v45, 4, 16                                  // 00000099E054: D610002D 0241092D
	.long 0xd72c0034                                           // 00000099E05C: D72C0034
	v_cndmask_b32_e32 v1, 0x83dcd12d, v52, vcc_lo              // 00000099E060: 020268FF 83DCD12D
	v_pk_fma_f16 v48, v48, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000099E068: CC0E0030 0BFC0B30 0000C931
	.long 0xd72c0033                                           // 00000099E074: D72C0033
	v_cndmask_b32_e32 v1, 0x83dcd12d, v51, vcc_lo              // 00000099E078: 020266FF 83DCD12D
	v_sad_u8 v53, v53, 0, 0x6400                               // 00000099E080: D6220035 03FD0135 00006400
	.long 0xd72c002d                                           // 00000099E08C: D72C002D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v45, vcc_lo              // 00000099E090: 02025AFF 83DCD12D
	.long 0xd72c0036                                           // 00000099E098: D72C0036
	v_cndmask_b32_e32 v1, 0x83dcd12d, v54, vcc_lo              // 00000099E09C: 02026CFF 83DCD12D
	v_dot2acc_f32_f16 v13, v48, v2                             // 00000099E0A4: 041A0530
	s_waitcnt vmcnt(2)                                         // 00000099E0A8: BF890BF7
	v_bfe_u32 v48, v41, 12, 16                                 // 00000099E0AC: D6100030 02411929
	v_sad_u8 v52, v52, 0, 0x6400                               // 00000099E0B4: D6220034 03FD0134 00006400
	v_pk_fma_f16 v46, v46, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000099E0C0: CC0E002E 0BFC0B2E 0000C931
	v_sad_u8 v51, v51, 0, 0x6400                               // 00000099E0CC: D6220033 03FD0133 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000099E0D8: BF870234
	.long 0xd72c0030                                           // 00000099E0DC: D72C0030
	v_cndmask_b32_e32 v1, 0x83dcd12d, v48, vcc_lo              // 00000099E0E0: 020260FF 83DCD12D
	v_sad_u8 v45, v45, 0, 0x6400                               // 00000099E0E8: D622002D 03FD012D 00006400
	v_sad_u8 v54, v54, 0, 0x6400                               // 00000099E0F4: D6220036 03FD0136 00006400
	v_and_b32_e32 v51, 0xffff, v51                             // 00000099E100: 366666FF 0000FFFF
	v_dot2acc_f32_f16 v13, v46, v3                             // 00000099E108: 041A072E
	s_delay_alu instid0(VALU_DEP_2)                            // 00000099E10C: BF870002
	v_lshl_or_b32 v50, v53, 16, v51                            // 00000099E110: D6560032 04CD2135
	v_sad_u8 v48, v48, 0, 0x6400                               // 00000099E118: D6220030 03FD0130 00006400
	v_sad_u8 v53, v55, 0, 0x6400                               // 00000099E124: D6220035 03FD0137 00006400
	.long 0xd72c0033                                           // 00000099E130: D72C0033
	v_cndmask_b32_e32 v1, 0x83dcd12d, v56, vcc_lo              // 00000099E134: 020270FF 83DCD12D
	v_mov_b32_e32 v55, v39                                     // 00000099E13C: 7E6E0327
	v_pk_fma_f16 v49, v50, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000099E140: CC0E0031 0BFC0B32 0000C931
	v_and_b32_e32 v48, 0xffff, v48                             // 00000099E14C: 366060FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000099E154: BF870132
	v_dot2acc_f32_f16 v12, v49, v1                             // 00000099E158: 04180331
	v_bfe_u32 v49, v41, 8, 16                                  // 00000099E15C: D6100031 02411129
	v_sad_u8 v51, v51, 0, 0x6400                               // 00000099E164: D6220033 03FD0133 00006400
	.long 0xd72c0031                                           // 00000099E170: D72C0031
	v_cndmask_b32_e32 v1, 0x83dcd12d, v49, vcc_lo              // 00000099E174: 020262FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000099E17C: BF870091
	v_sad_u8 v49, v49, 0, 0x6400                               // 00000099E180: D6220031 03FD0131 00006400
	v_lshl_or_b32 v25, v49, 16, v48                            // 00000099E18C: D6560019 04C12131
	s_waitcnt vmcnt(1)                                         // 00000099E194: BF8907F7
	v_bfe_u32 v48, v23, 12, 16                                 // 00000099E198: D6100030 02411917
	v_bfe_u32 v49, v24, 8, 16                                  // 00000099E1A0: D6100031 02411118
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000099E1A8: BF870223
	v_pk_fma_f16 v25, v25, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000099E1AC: CC0E0019 0BFC0B19 0000C931
	v_lshlrev_b32_e32 v52, 16, v52                             // 00000099E1B8: 30686890
	.long 0xd72c0030                                           // 00000099E1BC: D72C0030
	v_cndmask_b32_e32 v1, 0x83dcd12d, v48, vcc_lo              // 00000099E1C0: 020260FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000099E1C8: BF870194
	.long 0xd72c0031                                           // 00000099E1CC: D72C0031
	v_cndmask_b32_e32 v1, 0x83dcd12d, v49, vcc_lo              // 00000099E1D0: 020262FF 83DCD12D
	v_and_or_b32 v45, 0xffff, v45, v52                         // 00000099E1D8: D657002D 04D25AFF 0000FFFF
	v_and_b32_e32 v52, 0xffff, v54                             // 00000099E1E4: 36686CFF 0000FFFF
	v_mov_b32_e32 v54, v33                                     // 00000099E1EC: 7E6C0321
	v_sad_u8 v48, v48, 0, 0x6400                               // 00000099E1F0: D6220030 03FD0130 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000099E1FC: BF870214
	v_pk_fma_f16 v45, v45, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000099E200: CC0E002D 0BFC0B2D 0000C931
	v_lshl_or_b32 v50, v53, 16, v52                            // 00000099E20C: D6560032 04D12135
	v_sad_u8 v49, v49, 0, 0x6400                               // 00000099E214: D6220031 03FD0131 00006400
	v_mov_b32_e32 v52, v38                                     // 00000099E220: 7E680326
	v_and_b32_e32 v48, 0xffff, v48                             // 00000099E224: 366060FF 0000FFFF
	v_dot2acc_f32_f16 v12, v45, v2                             // 00000099E22C: 0418052D
	v_pk_fma_f16 v43, v50, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000099E230: CC0E002B 0BFC0B32 0000C931
	v_pk_fma_f16 v45, v47, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000099E23C: CC0E002D 0BFC0B2F 0000C931
	v_bfe_u32 v47, v42, 12, 16                                 // 00000099E248: D610002F 0241192A
	v_bfe_u32 v50, v41, 4, 16                                  // 00000099E250: D6100032 02410929
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000099E258: BF870224
	v_dual_dot2acc_f32_f16 v12, v43, v3 :: v_dual_and_b32 v41, 0xffff, v41// 00000099E25C: CB24072B 0C2852FF 0000FFFF
	v_bfe_u32 v43, v42, 8, 16                                  // 00000099E268: D610002B 0241112A
	.long 0xd72c002e                                           // 00000099E270: D72C002E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v47, vcc_lo              // 00000099E274: 02025EFF 83DCD12D
	v_and_b32_e32 v47, 0xffff, v42                             // 00000099E27C: 365E54FF 0000FFFF
	v_bfe_u32 v42, v42, 4, 16                                  // 00000099E284: D610002A 0241092A
	.long 0xd72c0029                                           // 00000099E28C: D72C0029
	v_cndmask_b32_e32 v1, 0x83dcd12d, v41, vcc_lo              // 00000099E290: 020252FF 83DCD12D
	.long 0xd72c002b                                           // 00000099E298: D72C002B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v43, vcc_lo              // 00000099E29C: 020256FF 83DCD12D
	.long 0xd72c0032                                           // 00000099E2A4: D72C0032
	v_cndmask_b32_e32 v1, 0x83dcd12d, v50, vcc_lo              // 00000099E2A8: 020264FF 83DCD12D
	.long 0xd72c002f                                           // 00000099E2B0: D72C002F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v47, vcc_lo              // 00000099E2B4: 02025EFF 83DCD12D
	.long 0xd72c002a                                           // 00000099E2BC: D72C002A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v42, vcc_lo              // 00000099E2C0: 020254FF 83DCD12D
	v_sad_u8 v46, v46, 0, 0x6400                               // 00000099E2C8: D622002E 03FD012E 00006400
	v_dot2acc_f32_f16 v13, v45, v4                             // 00000099E2D4: 041A092D
	v_mov_b32_e32 v45, v28                                     // 00000099E2D8: 7E5A031C
	v_sad_u8 v41, v41, 0, 0x6400                               // 00000099E2DC: D6220029 03FD0129 00006400
	v_sad_u8 v43, v43, 0, 0x6400                               // 00000099E2E8: D622002B 03FD012B 00006400
	v_and_b32_e32 v46, 0xffff, v46                             // 00000099E2F4: 365C5CFF 0000FFFF
	v_sad_u8 v47, v47, 0, 0x6400                               // 00000099E2FC: D622002F 03FD012F 00006400
	v_sad_u8 v42, v42, 0, 0x6400                               // 00000099E308: D622002A 03FD012A 00006400
	v_sad_u8 v50, v50, 0, 0x6400                               // 00000099E314: D6220032 03FD0132 00006400
	v_lshlrev_b32_e32 v41, 16, v41                             // 00000099E320: 30525290
	v_lshl_or_b32 v43, v43, 16, v46                            // 00000099E324: D656002B 04B9212B
	v_lshlrev_b32_e32 v47, 16, v47                             // 00000099E32C: 305E5E90
	v_bfe_u32 v46, v24, 12, 16                                 // 00000099E330: D610002E 02411918
	v_mov_b32_e32 v53, v39                                     // 00000099E338: 7E6A0327
	v_and_or_b32 v41, 0xffff, v50, v41                         // 00000099E33C: D6570029 04A664FF 0000FFFF
	v_pk_fma_f16 v43, v43, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000099E348: CC0E002B 0BFC0B2B 0000C931
	v_and_or_b32 v42, 0xffff, v42, v47                         // 00000099E354: D657002A 04BE54FF 0000FFFF
	v_and_b32_e32 v47, 0xffff, v24                             // 00000099E360: 365E30FF 0000FFFF
	.long 0xd72c002e                                           // 00000099E368: D72C002E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v46, vcc_lo              // 00000099E36C: 02025CFF 83DCD12D
	v_bfe_u32 v50, v23, 8, 16                                  // 00000099E374: D6100032 02411117
	v_dot2acc_f32_f16 v11, v43, v1                             // 00000099E37C: 0416032B
	v_pk_fma_f16 v42, v42, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000099E380: CC0E002A 0BFC0B2A 0000C931
	v_bfe_u32 v24, v24, 4, 16                                  // 00000099E38C: D6100018 02410918
	.long 0xd72c002f                                           // 00000099E394: D72C002F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v47, vcc_lo              // 00000099E398: 02025EFF 83DCD12D
	.long 0xd72c002b                                           // 00000099E3A0: D72C002B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v50, vcc_lo              // 00000099E3A4: 020264FF 83DCD12D
	v_pk_fma_f16 v41, v41, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000099E3AC: CC0E0029 0BFC0B29 0000C931
	v_sad_u8 v46, v46, 0, 0x6400                               // 00000099E3B8: D622002E 03FD012E 00006400
	v_dot2acc_f32_f16 v11, v42, v2                             // 00000099E3C4: 0416052A
	.long 0xd72c0018                                           // 00000099E3C8: D72C0018
	v_cndmask_b32_e32 v1, 0x83dcd12d, v24, vcc_lo              // 00000099E3CC: 020230FF 83DCD12D
	v_bfe_u32 v42, v18, 12, 16                                 // 00000099E3D4: D610002A 02411912
	v_bfe_u32 v50, v23, 4, 16                                  // 00000099E3DC: D6100032 02410917
	v_sad_u8 v47, v47, 0, 0x6400                               // 00000099E3E4: D622002F 03FD012F 00006400
	v_sad_u8 v43, v43, 0, 0x6400                               // 00000099E3F0: D622002B 03FD012B 00006400
	v_dual_dot2acc_f32_f16 v11, v25, v3 :: v_dual_and_b32 v46, 0xffff, v46// 00000099E3FC: CB240719 0B2E5CFF 0000FFFF
	.long 0xd72c002a                                           // 00000099E408: D72C002A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v42, vcc_lo              // 00000099E40C: 020254FF 83DCD12D
	v_sad_u8 v24, v24, 0, 0x6400                               // 00000099E414: D6220018 03FD0118 00006400
	v_lshlrev_b32_e32 v47, 16, v47                             // 00000099E420: 305E5E90
	v_lshl_or_b32 v43, v43, 16, v48                            // 00000099E424: D656002B 04C1212B
	v_bfe_u32 v48, v18, 8, 16                                  // 00000099E42C: D6100030 02411112
	v_dot2acc_f32_f16 v11, v41, v4                             // 00000099E434: 04160929
	v_lshl_or_b32 v46, v49, 16, v46                            // 00000099E438: D656002E 04B92131
	s_waitcnt vmcnt(0)                                         // 00000099E440: BF8903F7
	v_bfe_u32 v49, v17, 12, 16                                 // 00000099E444: D6100031 02411911
	v_and_or_b32 v24, 0xffff, v24, v47                         // 00000099E44C: D6570018 04BE30FF 0000FFFF
	.long 0xd72c002f                                           // 00000099E458: D72C002F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v50, vcc_lo              // 00000099E45C: 020264FF 83DCD12D
	v_bfe_u32 v50, v17, 8, 16                                  // 00000099E464: D6100032 02411111
	.long 0xd72c0030                                           // 00000099E46C: D72C0030
	v_cndmask_b32_e32 v1, 0x83dcd12d, v48, vcc_lo              // 00000099E470: 020260FF 83DCD12D
	.long 0xd72c0031                                           // 00000099E478: D72C0031
	v_cndmask_b32_e32 v1, 0x83dcd12d, v49, vcc_lo              // 00000099E47C: 020262FF 83DCD12D
	v_sad_u8 v42, v42, 0, 0x6400                               // 00000099E484: D622002A 03FD012A 00006400
	v_and_b32_e32 v23, 0xffff, v23                             // 00000099E490: 362E2EFF 0000FFFF
	.long 0xd72c0032                                           // 00000099E498: D72C0032
	v_cndmask_b32_e32 v1, 0x83dcd12d, v50, vcc_lo              // 00000099E49C: 020264FF 83DCD12D
	v_pk_fma_f16 v24, v24, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000099E4A4: CC0E0018 0BFC0B18 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 00000099E4B0: BF870254
	v_dual_mov_b32 v25, v34 :: v_dual_and_b32 v42, 0xffff, v42 // 00000099E4B4: CA240122 192A54FF 0000FFFF
	v_sad_u8 v48, v48, 0, 0x6400                               // 00000099E4C0: D6220030 03FD0130 00006400
	v_sad_u8 v49, v49, 0, 0x6400                               // 00000099E4CC: D6220031 03FD0131 00006400
	v_pk_fma_f16 v43, v43, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000099E4D8: CC0E002B 0BFC0B2B 0000C931
	v_mov_b32_e32 v41, v35                                     // 00000099E4E4: 7E520323
	v_lshl_or_b32 v42, v48, 16, v42                            // 00000099E4E8: D656002A 04A92130
	s_delay_alu instid0(VALU_DEP_4)                            // 00000099E4F0: BF870004
	v_and_b32_e32 v48, 0xffff, v49                             // 00000099E4F4: 366062FF 0000FFFF
	v_sad_u8 v49, v50, 0, 0x6400                               // 00000099E4FC: D6220031 03FD0132 00006400
	v_mov_b32_e32 v50, v38                                     // 00000099E508: 7E640326
	.long 0xd72c0013                                           // 00000099E50C: D72C0013
	v_cndmask_b32_e32 v1, 0x83dcd12d, v23, vcc_lo              // 00000099E510: 02022EFF 83DCD12D
	v_pk_fma_f16 v23, v46, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000099E518: CC0E0017 0BFC0B2E 0000C931
	v_and_b32_e32 v44, 0xffff, v44                             // 00000099E524: 365858FF 0000FFFF
	v_sad_u8 v46, v47, 0, 0x6400                               // 00000099E52C: D622002E 03FD012F 00006400
	v_and_b32_e32 v47, 0xffff, v18                             // 00000099E538: 365E24FF 0000FFFF
	v_bfe_u32 v18, v18, 4, 16                                  // 00000099E540: D6100012 02410912
	v_dot2acc_f32_f16 v9, v23, v1                              // 00000099E548: 04120317
	.long 0xd72c002c                                           // 00000099E54C: D72C002C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v44, vcc_lo              // 00000099E550: 020258FF 83DCD12D
	v_sad_u8 v19, v19, 0, 0x6400                               // 00000099E558: D6220013 03FD0113 00006400
	.long 0xd72c002f                                           // 00000099E564: D72C002F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v47, vcc_lo              // 00000099E568: 02025EFF 83DCD12D
	.long 0xd72c0012                                           // 00000099E570: D72C0012
	v_cndmask_b32_e32 v1, 0x83dcd12d, v18, vcc_lo              // 00000099E574: 020224FF 83DCD12D
	v_pk_fma_f16 v23, v42, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000099E57C: CC0E0017 0BFC0B2A 0000C931
	v_lshl_or_b32 v42, v49, 16, v48                            // 00000099E588: D656002A 04C12131
	v_lshlrev_b32_e32 v19, 16, v19                             // 00000099E590: 30262690
	v_dot2acc_f32_f16 v9, v24, v2                              // 00000099E594: 04120518
	v_sad_u8 v44, v44, 0, 0x6400                               // 00000099E598: D622002C 03FD012C 00006400
	v_dot2acc_f32_f16 v10, v23, v1                             // 00000099E5A4: 04140317
	v_sad_u8 v47, v47, 0, 0x6400                               // 00000099E5A8: D622002F 03FD012F 00006400
	v_sad_u8 v18, v18, 0, 0x6400                               // 00000099E5B4: D6220012 03FD0112 00006400
	v_and_or_b32 v1, 0xffff, v46, v19                          // 00000099E5C0: D6570001 044E5CFF 0000FFFF
	v_lshlrev_b32_e32 v44, 16, v44                             // 00000099E5CC: 30585890
	v_pk_fma_f16 v19, v42, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000099E5D0: CC0E0013 0BFC0B2A 0000C931
	v_lshlrev_b32_e32 v47, 16, v47                             // 00000099E5DC: 305E5E90
	v_dot2acc_f32_f16 v9, v43, v3                              // 00000099E5E0: 0412072B
	v_pk_fma_f16 v1, v1, s5, 0xc931 op_sel_hi:[1,0,0]          // 00000099E5E4: CC0E0001 0BFC0B01 0000C931
	v_and_or_b32 v44, 0xffff, v51, v44                         // 00000099E5F0: D657002C 04B266FF 0000FFFF
	v_bfe_u32 v51, v17, 4, 16                                  // 00000099E5FC: D6100033 02410911
	v_and_b32_e32 v17, 0xffff, v17                             // 00000099E604: 362222FF 0000FFFF
	v_and_or_b32 v18, 0xffff, v18, v47                         // 00000099E60C: D6570012 04BE24FF 0000FFFF
	v_dot2acc_f32_f16 v9, v1, v4                               // 00000099E618: 04120901
	v_pk_fma_f16 v44, v44, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000099E61C: CC0E002C 0BFC0B2C 0000C931
	.long 0xd72c002f                                           // 00000099E628: D72C002F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v51, vcc_lo              // 00000099E62C: 020266FF 83DCD12D
	.long 0xd72c0011                                           // 00000099E634: D72C0011
	v_cndmask_b32_e32 v1, 0x83dcd12d, v17, vcc_lo              // 00000099E638: 020222FF 83DCD12D
	v_pk_fma_f16 v18, v18, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000099E640: CC0E0012 0BFC0B12 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000099E64C: BF8701A4
	v_dual_mov_b32 v23, v34 :: v_dual_dot2acc_f32_f16 v12, v44, v4// 00000099E650: CA180122 170C092C
	v_dual_mov_b32 v24, v26 :: v_dual_mov_b32 v43, v35         // 00000099E658: CA10011A 182A0123
	v_dot2acc_f32_f16 v10, v18, v2                             // 00000099E660: 04140512
	v_sad_u8 v47, v47, 0, 0x6400                               // 00000099E664: D622002F 03FD012F 00006400
	v_sad_u8 v17, v17, 0, 0x6400                               // 00000099E670: D6220011 03FD0111 00006400
	v_mov_b32_e32 v18, v6                                      // 00000099E67C: 7E240306
	v_mov_b32_e32 v42, v27                                     // 00000099E680: 7E54031B
	v_dual_dot2acc_f32_f16 v10, v19, v3 :: v_dual_mov_b32 v19, v32// 00000099E684: CB100713 0A120120
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000099E68C: BF8701B4
	v_dual_mov_b32 v44, v36 :: v_dual_lshlrev_b32 v17, 16, v17 // 00000099E690: CA220124 2C102290
	v_dual_mov_b32 v46, v36 :: v_dual_mov_b32 v49, v37         // 00000099E698: CA100124 2E300125
	v_mov_b32_e32 v48, v29                                     // 00000099E6A0: 7E60031D
	v_and_or_b32 v17, 0xffff, v47, v17                         // 00000099E6A4: D6570011 04465EFF 0000FFFF
	v_mov_b32_e32 v47, v37                                     // 00000099E6B0: 7E5E0325
	v_mov_b32_e32 v51, v30                                     // 00000099E6B4: 7E66031E
	v_mov_b32_e32 v3, v40                                      // 00000099E6B8: 7E060328
	v_mov_b32_e32 v1, v5                                       // 00000099E6BC: 7E020305
	v_pk_fma_f16 v2, v17, s5, 0xc931 op_sel_hi:[1,0,0]         // 00000099E6C0: CC0E0002 0BFC0B11 0000C931
	s_delay_alu instid0(VALU_DEP_1)                            // 00000099E6CC: BF870001
	v_dual_mov_b32 v17, v32 :: v_dual_dot2acc_f32_f16 v10, v2, v4// 00000099E6D0: CA180120 110A0902
	v_mov_b32_e32 v4, v40                                      // 00000099E6D8: 7E080328
	v_mov_b32_e32 v2, v31                                      // 00000099E6DC: 7E04031F
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 00000099E6E0: 917E047E
	s_cbranch_execz 58                                         // 00000099E6E4: BFA5003A <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi1ELi2EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x19d0>
	v_add_nc_u32_e32 v5, 1, v1                                 // 00000099E6E8: 4A0A0281
	s_mov_b32 s6, exec_lo                                      // 00000099E6EC: BE86007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000099E6F0: BF870001
	.long 0xd4c1007e                                           // 00000099E6F4: D4C1007E
	v_cndmask_b32_e32 v1, v5, v8, vcc_lo                       // 00000099E6F8: 02021105
	s_cbranch_execz 64663                                      // 00000099E6FC: BFA5FC97 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi1ELi2EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0xb5c>
	v_ashrrev_i32_e32 v6, 31, v5                               // 00000099E700: 340C0A9F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000099E704: BF870091
	.long 0xd73c001a                                           // 00000099E708: D73C001A
	v_cndmask_b32_e32 v1, 10, v5, vcc_lo                       // 00000099E70C: 02020A8A
	.long 0xd7006a06                                           // 00000099E710: D7006A06
	v_cndmask_b32_e32 v1, s1, v26, vcc_lo                      // 00000099E714: 02023401
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000099E718: BF870111
	v_add_co_ci_u32_e64 v26, null, s3, v27, vcc_lo             // 00000099E71C: D5207C1A 01AA3603
	.long 0xd7006a22                                           // 00000099E724: D7006A22
	v_cndmask_b32_e32 v1, v6, v22, vcc_lo                      // 00000099E728: 02022D06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000099E72C: BF8700A1
	v_add_co_ci_u32_e64 v35, null, 0, v26, vcc_lo              // 00000099E730: D5207C23 01AA3480
	.long 0xd7006a38                                           // 00000099E738: D7006A38
	v_cndmask_b32_e32 v1, v6, v21, vcc_lo                      // 00000099E73C: 02022B06
	v_add_co_ci_u32_e64 v57, null, 0, v26, vcc_lo              // 00000099E740: D5207C39 01AA3480
	s_clause 0xf                                               // 00000099E748: BF85000F
	global_load_b32 v31, v[34:35], off                         // 00000099E74C: DC520000 1F7C0022
	global_load_b32 v33, v[34:35], off offset:128              // 00000099E754: DC520080 217C0022
	global_load_b32 v30, v[34:35], off offset:256              // 00000099E75C: DC520100 1E7C0022
	global_load_b32 v29, v[34:35], off offset:384              // 00000099E764: DC520180 1D7C0022
	global_load_b32 v28, v[34:35], off offset:512              // 00000099E76C: DC520200 1C7C0022
	global_load_b32 v27, v[34:35], off offset:640              // 00000099E774: DC520280 1B7C0022
	global_load_b32 v26, v[34:35], off offset:768              // 00000099E77C: DC520300 1A7C0022
	global_load_b32 v6, v[34:35], off offset:896               // 00000099E784: DC520380 067C0022
	global_load_b32 v40, v[56:57], off                         // 00000099E78C: DC520000 287C0038
	global_load_b32 v39, v[56:57], off offset:128              // 00000099E794: DC520080 277C0038
	global_load_b32 v38, v[56:57], off offset:256              // 00000099E79C: DC520100 267C0038
	global_load_b32 v37, v[56:57], off offset:384              // 00000099E7A4: DC520180 257C0038
	global_load_b32 v36, v[56:57], off offset:512              // 00000099E7AC: DC520200 247C0038
	global_load_b32 v35, v[56:57], off offset:640              // 00000099E7B4: DC520280 237C0038
	global_load_b32 v34, v[56:57], off offset:768              // 00000099E7BC: DC520300 227C0038
	global_load_b32 v32, v[56:57], off offset:896              // 00000099E7C4: DC520380 207C0038
	s_branch 64611                                             // 00000099E7CC: BFA0FC63 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi1ELi2EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0xb5c>
	s_or_b32 exec_lo, exec_lo, s4                              // 00000099E7D0: 8C7E047E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000099E7D4: BF870009
	s_or_b32 exec_lo, exec_lo, s0                              // 00000099E7D8: 8C7E007E
	s_waitcnt vmcnt(23)                                        // 00000099E7DC: BF895FF7
	v_dual_mov_b32 v1, v16 :: v_dual_mov_b32 v2, v15           // 00000099E7E0: CA100110 0102010F
	s_waitcnt vmcnt(7)                                         // 00000099E7E8: BF891FF7
	v_dual_mov_b32 v3, v14 :: v_dual_mov_b32 v4, v13           // 00000099E7EC: CA10010E 0304010D
	v_dual_mov_b32 v5, v12 :: v_dual_mov_b32 v6, v11           // 00000099E7F4: CA10010C 0506010B
	s_waitcnt vmcnt(0)                                         // 00000099E7FC: BF8903F7
	v_dual_mov_b32 v8, v9 :: v_dual_mov_b32 v17, v10           // 00000099E800: CA100109 0810010A
	s_mov_b32 s0, 0x76543210                                   // 00000099E808: BE8000FF 76543210
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000099E810: BF870009
	v_permlanex16_b32 v1, v1, s0, 0xfedcba98                   // 00000099E814: D65C0001 03FC0101 FEDCBA98
	v_permlanex16_b32 v2, v2, s0, 0xfedcba98                   // 00000099E820: D65C0002 03FC0102 FEDCBA98
	v_permlanex16_b32 v3, v3, s0, 0xfedcba98                   // 00000099E82C: D65C0003 03FC0103 FEDCBA98
	v_permlanex16_b32 v4, v4, s0, 0xfedcba98                   // 00000099E838: D65C0004 03FC0104 FEDCBA98
	v_permlanex16_b32 v5, v5, s0, 0xfedcba98                   // 00000099E844: D65C0005 03FC0105 FEDCBA98
	v_permlanex16_b32 v6, v6, s0, 0xfedcba98                   // 00000099E850: D65C0006 03FC0106 FEDCBA98
	v_permlanex16_b32 v8, v8, s0, 0xfedcba98                   // 00000099E85C: D65C0008 03FC0108 FEDCBA98
	v_permlanex16_b32 v17, v17, s0, 0xfedcba98                 // 00000099E868: D65C0011 03FC0111 FEDCBA98
	.long 0xd44c0000                                           // 00000099E874: D44C0000
	v_cndmask_b32_e32 v1, 16, v72, vcc_lo                      // 00000099E878: 02029090
	s_barrier                                                  // 00000099E87C: BFBD0000
	buffer_gl0_inv                                             // 00000099E880: E0AC0000 00000000
	s_and_saveexec_b32 s1, s0                                  // 00000099E888: BE812000
	s_cbranch_execz 21                                         // 00000099E88C: BFA50015 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi1ELi2EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x1ae4>
	v_lshl_or_b32 v7, v71, 9, v7                               // 00000099E890: D6560007 041D1347
	v_add_f32_e32 v10, v10, v17                                // 00000099E898: 0614230A
	v_dual_add_f32 v1, v16, v1 :: v_dual_add_f32 v2, v15, v2   // 00000099E89C: C9080310 0102050F
	v_dual_add_f32 v3, v14, v3 :: v_dual_add_f32 v4, v13, v4   // 00000099E8A4: C908070E 0304090D
	s_delay_alu instid0(VALU_DEP_4)                            // 00000099E8AC: BF870004
	v_add_nc_u32_e32 v7, 0x2000, v7                            // 00000099E8B0: 4A0E0EFF 00002000
	v_dual_add_f32 v5, v12, v5 :: v_dual_add_f32 v6, v11, v6   // 00000099E8B8: C9080B0C 05060D0B
	v_add_f32_e32 v8, v9, v8                                   // 00000099E8C0: 06101109
	ds_store_2addr_b32 v7, v1, v2 offset1:16                   // 00000099E8C4: D8381000 00020107
	ds_store_2addr_b32 v7, v3, v4 offset0:32 offset1:48        // 00000099E8CC: D8383020 00040307
	ds_store_2addr_b32 v7, v5, v6 offset0:64 offset1:80        // 00000099E8D4: D8385040 00060507
	ds_store_2addr_b32 v7, v8, v10 offset0:96 offset1:112      // 00000099E8DC: D8387060 000A0807
	s_or_b32 exec_lo, exec_lo, s1                              // 00000099E8E4: 8C7E017E
	.long 0xd44c0001                                           // 00000099E8E8: D44C0001
	v_cndmask_b32_e32 v1, 0x80, v0, vcc_lo                     // 00000099E8EC: 020200FF 00000080
	s_waitcnt lgkmcnt(0)                                       // 00000099E8F4: BF89FC07
	s_barrier                                                  // 00000099E8F8: BFBD0000
	buffer_gl0_inv                                             // 00000099E8FC: E0AC0000 00000000
	s_and_saveexec_b32 s3, s1                                  // 00000099E904: BE832001
	s_cbranch_execnz 7                                         // 00000099E908: BFA60007 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi1ELi2EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x1b28>
	s_or_b32 exec_lo, exec_lo, s3                              // 00000099E90C: 8C7E037E
	s_cmp_lt_i32 s9, 2                                         // 00000099E910: BF048209
	s_mov_b32 s3, -1                                           // 00000099E914: BE8300C1
	s_cbranch_scc0 33                                          // 00000099E918: BFA10021 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi1ELi2EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x1ba0>
	s_and_b32 vcc_lo, exec_lo, s3                              // 00000099E91C: 8B6A037E
	s_cbranch_vccnz 155                                        // 00000099E920: BFA4009B <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi1ELi2EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x1d90>
	s_branch 518                                               // 00000099E924: BFA00206 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi1ELi2EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x2340>
	v_lshlrev_b32_e32 v7, 2, v0                                // 00000099E928: 300E0082
	ds_load_2addr_stride64_b32 v[1:2], v7 offset0:32 offset1:34// 00000099E92C: D8E02220 01000007
	ds_load_2addr_stride64_b32 v[3:4], v7 offset0:36 offset1:38// 00000099E934: D8E02624 03000007
	ds_load_2addr_stride64_b32 v[5:6], v7 offset0:40 offset1:42// 00000099E93C: D8E02A28 05000007
	s_waitcnt lgkmcnt(2)                                       // 00000099E944: BF89FC27
	v_add_f32_e32 v1, 0, v1                                    // 00000099E948: 06020280
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000099E94C: BF8700A1
	v_add_f32_e32 v1, v1, v2                                   // 00000099E950: 06020501
	s_waitcnt lgkmcnt(1)                                       // 00000099E954: BF89FC17
	v_add_f32_e32 v3, v1, v3                                   // 00000099E958: 06060701
	ds_load_2addr_stride64_b32 v[1:2], v7 offset0:44 offset1:46// 00000099E95C: D8E02E2C 01000007
	v_add_f32_e32 v3, v3, v4                                   // 00000099E964: 06060903
	s_waitcnt lgkmcnt(1)                                       // 00000099E968: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000099E96C: BF870091
	v_add_f32_e32 v3, v3, v5                                   // 00000099E970: 06060B03
	v_add_f32_e32 v3, v3, v6                                   // 00000099E974: 06060D03
	s_waitcnt lgkmcnt(0)                                       // 00000099E978: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000099E97C: BF870091
	v_add_f32_e32 v1, v3, v1                                   // 00000099E980: 06020303
	v_add_f32_e32 v1, v1, v2                                   // 00000099E984: 06020501
	ds_store_b32 v7, v1 offset:12288                           // 00000099E988: D8343000 00000107
	s_or_b32 exec_lo, exec_lo, s3                              // 00000099E990: 8C7E037E
	s_cmp_lt_i32 s9, 2                                         // 00000099E994: BF048209
	s_mov_b32 s3, -1                                           // 00000099E998: BE8300C1
	s_cbranch_scc1 65503                                       // 00000099E99C: BFA2FFDF <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi1ELi2EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x1b1c>
	s_waitcnt lgkmcnt(0)                                       // 00000099E9A0: BF89FC07
	s_barrier                                                  // 00000099E9A4: BFBD0000
	buffer_gl0_inv                                             // 00000099E9A8: E0AC0000 00000000
	s_and_saveexec_b32 s3, s1                                  // 00000099E9B0: BE832001
	s_cbranch_execz 17                                         // 00000099E9B4: BFA50011 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi1ELi2EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x1bfc>
	v_lshlrev_b32_e32 v1, 2, v0                                // 00000099E9B8: 30020082
	s_mul_hi_i32 s5, s30, s49                                  // 00000099E9BC: 9705311E
	s_mul_i32 s4, s30, s49                                     // 00000099E9C0: 9604311E
	s_lshl_b32 s6, s10, 7                                      // 00000099E9C4: 8406870A
	s_lshl_b64 s[4:5], s[4:5], 2                               // 00000099E9C8: 84848204
	ds_load_b32 v2, v1 offset:12288                            // 00000099E9CC: D8D83000 02000001
	s_ashr_i32 s7, s6, 31                                      // 00000099E9D4: 86079F06
	s_add_u32 s8, s44, s4                                      // 00000099E9D8: 8008042C
	s_addc_u32 s24, s45, s5                                    // 00000099E9DC: 8218052D
	s_lshl_b64 s[4:5], s[6:7], 2                               // 00000099E9E0: 84848206
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000099E9E4: BF870009
	s_add_u32 s4, s8, s4                                       // 00000099E9E8: 80040408
	s_addc_u32 s5, s24, s5                                     // 00000099E9EC: 82050518
	s_waitcnt lgkmcnt(0)                                       // 00000099E9F0: BF89FC07
	global_store_b32 v1, v2, s[4:5]                            // 00000099E9F4: DC6A0000 00040201
	s_or_b32 exec_lo, exec_lo, s3                              // 00000099E9FC: 8C7E037E
	.long 0xd44a0003                                           // 00000099EA00: D44A0003
	v_cndmask_b32_e32 v1, 0, v0, vcc_lo                        // 00000099EA04: 02020080
	s_waitcnt_vscnt null, 0x0                                  // 00000099EA08: BC7C0000
	buffer_gl1_inv                                             // 00000099EA0C: E0B00000 00000000
	buffer_gl0_inv                                             // 00000099EA14: E0AC0000 00000000
	s_barrier                                                  // 00000099EA1C: BFBD0000
	buffer_gl0_inv                                             // 00000099EA20: E0AC0000 00000000
	s_and_saveexec_b32 s4, s3                                  // 00000099EA28: BE842003
	s_cbranch_execz 29                                         // 00000099EA2C: BFA5001D <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi1ELi2EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x1ca4>
	s_mov_b32 s6, exec_lo                                      // 00000099EA30: BE86007E
	s_mov_b32 s5, exec_lo                                      // 00000099EA34: BE85007E
	.long 0xd71f0001                                           // 00000099EA38: D71F0001
	v_cndmask_b32_e32 v0, s6, v128, vcc_lo                     // 00000099EA3C: 02010006
	s_delay_alu instid0(VALU_DEP_1)                            // 00000099EA40: BF870001
	v_cmpx_eq_u32_e32 0, v1                                    // 00000099EA44: 7D940280
	s_cbranch_execz 9                                          // 00000099EA48: BFA50009 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi1ELi2EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x1c70>
	s_lshl_b64 s[24:25], s[10:11], 2                           // 00000099EA4C: 8498820A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 00000099EA50: BF8704B9
	s_add_u32 s24, s46, s24                                    // 00000099EA54: 8018182E
	s_addc_u32 s25, s47, s25                                   // 00000099EA58: 8219192F
	s_bcnt1_i32_b32 s6, s6                                     // 00000099EA5C: BE861806
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v3, s6              // 00000099EA60: CA100080 02020006
	global_atomic_add_u32 v2, v2, v3, s[24:25] glc             // 00000099EA68: DCD64000 02180302
	s_or_b32 exec_lo, exec_lo, s5                              // 00000099EA70: 8C7E057E
	s_waitcnt vmcnt(0)                                         // 00000099EA74: BF8903F7
	v_readfirstlane_b32 s5, v2                                 // 00000099EA78: 7E0A0502
	s_delay_alu instid0(VALU_DEP_1)                            // 00000099EA7C: BF870001
	v_dual_mov_b32 v2, 0 :: v_dual_add_nc_u32 v1, s5, v1       // 00000099EA80: CA200080 02000205
	s_add_i32 s5, s9, -1                                       // 00000099EA88: 8105C109
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 00000099EA8C: BF870481
	v_cmp_eq_u32_e32 vcc_lo, s5, v1                            // 00000099EA90: 7C940205
	v_cndmask_b32_e64 v1, 0, 1, vcc_lo                         // 00000099EA94: D5010001 01A90280
	ds_store_b32 v2, v1 offset:13312                           // 00000099EA9C: D8343400 00000102
	s_or_b32 exec_lo, exec_lo, s4                              // 00000099EAA4: 8C7E047E
	v_mov_b32_e32 v1, 0                                        // 00000099EAA8: 7E020280
	s_waitcnt lgkmcnt(0)                                       // 00000099EAAC: BF89FC07
	s_barrier                                                  // 00000099EAB0: BFBD0000
	buffer_gl0_inv                                             // 00000099EAB4: E0AC0000 00000000
	ds_load_b32 v1, v1 offset:13312                            // 00000099EABC: D8D83400 01000001
	s_waitcnt lgkmcnt(0)                                       // 00000099EAC4: BF89FC07
	v_cmp_eq_u32_e32 vcc_lo, 0, v1                             // 00000099EAC8: 7C940280
	s_cbranch_vccnz 47                                         // 00000099EACC: BFA4002F <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi1ELi2EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x1d8c>
	buffer_gl1_inv                                             // 00000099EAD0: E0B00000 00000000
	buffer_gl0_inv                                             // 00000099EAD8: E0AC0000 00000000
	s_and_saveexec_b32 s6, s1                                  // 00000099EAE0: BE862001
	s_cbranch_execz 29                                         // 00000099EAE4: BFA5001D <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi1ELi2EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x1d5c>
	s_lshl_b32 s4, s10, 7                                      // 00000099EAE8: 8404870A
	v_dual_mov_b32 v4, 0 :: v_dual_lshlrev_b32 v3, 2, v0       // 00000099EAEC: CA220080 04020082
	s_ashr_i32 s5, s4, 31                                      // 00000099EAF4: 86059F04
	s_ashr_i32 s25, s49, 31                                    // 00000099EAF8: 86199F31
	s_lshl_b64 s[4:5], s[4:5], 2                               // 00000099EAFC: 84848204
	s_mov_b32 s24, s49                                         // 00000099EB00: BE980031
	s_add_u32 s1, s44, s4                                      // 00000099EB04: 8001042C
	s_addc_u32 s4, s45, s5                                     // 00000099EB08: 8204052D
	.long 0xd7000101                                           // 00000099EB0C: D7000101
	v_cndmask_b32_e32 v1, s1, v3, vcc_lo                       // 00000099EB10: 02020601
	s_delay_alu instid0(VALU_DEP_1)                            // 00000099EB14: BF870001
	v_add_co_ci_u32_e64 v2, null, s4, 0, s1                    // 00000099EB18: D5207C02 00050004
	s_lshl_b64 s[4:5], s[24:25], 2                             // 00000099EB20: 84848218
	global_load_b32 v5, v[1:2], off glc                        // 00000099EB24: DC524000 057C0001
	.long 0xd7006a01                                           // 00000099EB2C: D7006A01
	v_cndmask_b32_e32 v0, v1, v4, vcc_lo                       // 00000099EB30: 02000901
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000099EB34: BF8704A1
	v_add_co_ci_u32_e64 v2, null, s5, v2, vcc_lo               // 00000099EB38: D5207C02 01AA0405
	s_add_i32 s9, s9, -1                                       // 00000099EB40: 8109C109
	s_cmp_eq_u32 s9, 0                                         // 00000099EB44: BF068009
	s_waitcnt vmcnt(0)                                         // 00000099EB48: BF8903F7
	v_add_f32_e32 v4, v4, v5                                   // 00000099EB4C: 06080B04
	s_cbranch_scc0 65524                                       // 00000099EB50: BFA1FFF4 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi1ELi2EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x1d24>
	ds_store_b32 v3, v4 offset:12288                           // 00000099EB54: D8343000 00000403
	s_or_b32 exec_lo, exec_lo, s6                              // 00000099EB5C: 8C7E067E
	s_and_saveexec_b32 s1, s3                                  // 00000099EB60: BE812003
	s_cbranch_execz 6                                          // 00000099EB64: BFA50006 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi1ELi2EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x1d80>
	s_lshl_b64 s[4:5], s[10:11], 2                             // 00000099EB68: 8484820A
	v_mov_b32_e32 v1, 0                                        // 00000099EB6C: 7E020280
	s_add_u32 s4, s46, s4                                      // 00000099EB70: 8004042E
	s_addc_u32 s5, s47, s5                                     // 00000099EB74: 8205052F
	global_store_b32 v1, v1, s[4:5]                            // 00000099EB78: DC6A0000 00040101
	s_or_b32 exec_lo, exec_lo, s1                              // 00000099EB80: 8C7E017E
	s_cbranch_execnz 2                                         // 00000099EB84: BFA60002 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi1ELi2EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x1d90>
	s_branch 365                                               // 00000099EB88: BFA0016D <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi1ELi2EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x2340>
	s_branch 364                                               // 00000099EB8C: BFA0016C <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi1ELi2EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x2340>
	v_cmp_eq_u32_e32 vcc_lo, 0, v71                            // 00000099EB90: 7C948E80
	s_cmp_gt_i32 s48, 0                                        // 00000099EB94: BF028030
	s_waitcnt lgkmcnt(0)                                       // 00000099EB98: BF89FC07
	s_waitcnt_vscnt null, 0x0                                  // 00000099EB9C: BC7C0000
	s_cselect_b32 s1, -1, 0                                    // 00000099EBA0: 980180C1
	s_barrier                                                  // 00000099EBA4: BFBD0000
	s_and_b32 s1, vcc_lo, s1                                   // 00000099EBA8: 8B01016A
	buffer_gl0_inv                                             // 00000099EBAC: E0AC0000 00000000
	s_and_saveexec_b32 s4, s1                                  // 00000099EBB4: BE842001
	s_cbranch_execz 352                                        // 00000099EBB8: BFA50160 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi1ELi2EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x233c>
	v_and_b32_e32 v1, 15, v0                                   // 00000099EBBC: 3602008F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000099EBC0: BF870091
	v_lshlrev_b32_e32 v2, 2, v1                                // 00000099EBC4: 30040282
	v_add_nc_u32_e32 v8, 0x3000, v2                            // 00000099EBC8: 4A1004FF 00003000
	ds_load_2addr_b32 v[2:3], v8 offset1:16                    // 00000099EBD0: D8DC1000 02000008
	ds_load_2addr_b32 v[4:5], v8 offset0:32 offset1:48         // 00000099EBD8: D8DC3020 04000008
	ds_load_2addr_b32 v[6:7], v8 offset0:64 offset1:80         // 00000099EBE0: D8DC5040 06000008
	ds_load_2addr_b32 v[8:9], v8 offset0:96 offset1:112        // 00000099EBE8: D8DC7060 08000008
	v_and_b32_e32 v10, 1, v0                                   // 00000099EBF0: 36140081
	v_and_b32_e32 v11, 2, v0                                   // 00000099EBF4: 36160082
	s_waitcnt lgkmcnt(3)                                       // 00000099EBF8: BF89FC37
	v_dual_add_f32 v13, v2, v3 :: v_dual_and_b32 v12, 4, v0    // 00000099EBFC: C9240702 0D0C0084
	s_waitcnt lgkmcnt(2)                                       // 00000099EC04: BF89FC27
	v_dual_sub_f32 v2, v2, v3 :: v_dual_add_f32 v3, v4, v5     // 00000099EC08: C9480702 02020B04
	s_waitcnt lgkmcnt(1)                                       // 00000099EC10: BF89FC17
	v_dual_sub_f32 v4, v4, v5 :: v_dual_add_f32 v5, v6, v7     // 00000099EC14: C9480B04 04040F06
	s_waitcnt lgkmcnt(0)                                       // 00000099EC1C: BF89FC07
	v_dual_sub_f32 v6, v6, v7 :: v_dual_add_f32 v7, v8, v9     // 00000099EC20: C9480F06 06061308
	v_dual_sub_f32 v8, v8, v9 :: v_dual_add_f32 v9, v13, v3    // 00000099EC28: C9481308 0808070D
	v_sub_f32_e32 v3, v13, v3                                  // 00000099EC30: 0806070D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 00000099EC34: BF870243
	v_dual_add_f32 v13, v2, v4 :: v_dual_add_f32 v14, v5, v7   // 00000099EC38: C9080902 0D0E0F05
	v_dual_sub_f32 v2, v2, v4 :: v_dual_sub_f32 v5, v5, v7     // 00000099EC40: C94A0902 02040F05
	v_cmp_eq_u32_e32 vcc_lo, 0, v10                            // 00000099EC48: 7C941480
	.long 0xd44a0001                                           // 00000099EC4C: D44A0001
	v_cndmask_b32_e32 v1, 0, v11, vcc_lo                       // 00000099EC50: 02021680
	v_dual_add_f32 v7, v9, v14 :: v_dual_add_f32 v4, v6, v8    // 00000099EC54: C9081D09 07041106
	v_sub_f32_e32 v6, v6, v8                                   // 00000099EC5C: 080C1106
	v_sub_f32_e32 v8, v9, v14                                  // 00000099EC60: 08101D09
	.long 0xd44a0003                                           // 00000099EC64: D44A0003
	v_cndmask_b32_e32 v1, 0, v12, vcc_lo                       // 00000099EC68: 02021880
	s_delay_alu instid0(VALU_DEP_3)                            // 00000099EC6C: BF870003
	v_dual_add_f32 v9, v13, v4 :: v_dual_sub_f32 v10, v2, v6   // 00000099EC70: C90A090D 090A0D02
	v_dual_sub_f32 v4, v13, v4 :: v_dual_add_f32 v13, v3, v5   // 00000099EC78: C948090D 040C0B03
	v_sub_f32_e32 v3, v3, v5                                   // 00000099EC80: 08060B03
	v_add_f32_e32 v5, v2, v6                                   // 00000099EC84: 060A0D02
	v_mov_b32_dpp v2, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000099EC88: 7E0402FA FF016107
	v_cndmask_b32_e64 v6, -v7, v7, vcc_lo                      // 00000099EC90: D5010006 21AA0F07
	v_mov_b32_dpp v7, v9 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000099EC98: 7E0E02FA FF016109
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 00000099ECA0: D5010009 21AA1309
	v_mov_b32_dpp v15, v5 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000099ECA8: 7E1E02FA FF016105
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 00000099ECB0: D5010005 21AA0B05
	v_mov_b32_dpp v14, v13 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000099ECB8: 7E1C02FA FF01610D
	v_cndmask_b32_e64 v13, -v13, v13, vcc_lo                   // 00000099ECC0: D501000D 21AA1B0D
	v_mov_b32_dpp v16, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000099ECC8: 7E2002FA FF016108
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 00000099ECD0: D5010008 21AA1108
	v_mov_b32_dpp v17, v4 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000099ECD8: 7E2202FA FF016104
	v_cndmask_b32_e64 v18, -v4, v4, vcc_lo                     // 00000099ECE0: D5010012 21AA0904
	v_mov_b32_dpp v19, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000099ECE8: 7E2602FA FF016103
	v_cndmask_b32_e64 v20, -v3, v3, vcc_lo                     // 00000099ECF0: D5010014 21AA0703
	v_dual_add_f32 v3, v9, v7 :: v_dual_add_f32 v2, v6, v2     // 00000099ECF8: C9080F09 03020506
	v_dual_add_f32 v4, v5, v15 :: v_dual_add_f32 v7, v8, v16   // 00000099ED00: C9081F05 04062108
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000099ED08: BF870192
	v_cndmask_b32_e64 v8, -v3, v3, s1                          // 00000099ED0C: D5010008 20060703
	v_mov_b32_dpp v6, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000099ED14: 7E0C02FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, s1                          // 00000099ED1C: D5010002 20060502
	v_mov_b32_dpp v3, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000099ED24: 7E0602FA FF016203
	v_mov_b32_dpp v11, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000099ED2C: 7E1602FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, s1                          // 00000099ED34: D5010004 20060904
	v_add_f32_e32 v5, v13, v14                                 // 00000099ED3C: 060A1D0D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000099ED40: BF870224
	v_dual_add_f32 v2, v2, v6 :: v_dual_add_f32 v3, v8, v3     // 00000099ED44: C9080D02 02020708
	v_mov_b32_dpp v13, v7 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000099ED4C: 7E1A02FA FF016207
	v_add_f32_e32 v4, v4, v11                                  // 00000099ED54: 06081704
	s_delay_alu instid0(VALU_DEP_4)                            // 00000099ED58: BF870004
	v_mov_b32_dpp v9, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000099ED5C: 7E1202FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, s1                          // 00000099ED64: D5010005 20060B05
	v_mov_b32_dpp v6, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000099ED6C: 7E0C02FA FF016402
	v_cndmask_b32_e64 v8, -v3, v3, s3                          // 00000099ED74: D5010008 200E0703
	v_cndmask_b32_e64 v2, -v2, v2, s3                          // 00000099ED7C: D5010002 200E0502
	v_mov_b32_dpp v11, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000099ED84: 7E1602FA FF016403
	v_add_f32_e32 v5, v5, v9                                   // 00000099ED8C: 060A1305
	v_mov_b32_dpp v9, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000099ED90: 7E1202FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s3                          // 00000099ED98: D5010004 200E0904
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000099EDA0: BF870214
	v_dual_add_f32 v3, v2, v6 :: v_dual_add_f32 v6, v8, v11    // 00000099EDA4: C9080D02 03061708
	v_mov_b32_dpp v8, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000099EDAC: 7E1002FA FF016405
	v_cndmask_b32_e64 v11, -v5, v5, s3                         // 00000099EDB4: D501000B 200E0B05
	s_delay_alu instid0(VALU_DEP_4)                            // 00000099EDBC: BF870004
	v_add_f32_e32 v4, v4, v9                                   // 00000099EDC0: 06081304
	v_mov_b32_dpp v9, v10 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000099EDC4: 7E1202FA FF01610A
	v_cndmask_b32_e64 v10, -v10, v10, vcc_lo                   // 00000099EDCC: D501000A 21AA150A
	v_add_f32_e32 v12, v18, v17                                // 00000099EDD4: 06182312
	v_cndmask_b32_e64 v7, -v7, v7, s1                          // 00000099EDD8: D5010007 20060F07
	v_add_f32_e32 v14, v20, v19                                // 00000099EDE0: 061C2714
	v_mov_b32_dpp v2, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000099EDE4: 7E0402FA FF016803
	v_add_f32_e32 v9, v10, v9                                  // 00000099EDEC: 0612130A
	v_mov_b32_dpp v5, v6 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000099EDF0: 7E0A02FA FF016806
	v_add_f32_e32 v13, v7, v13                                 // 00000099EDF8: 061A1B07
	v_mov_b32_dpp v15, v14 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000099EDFC: 7E1E02FA FF01620E
	v_cndmask_b32_e64 v14, -v14, v14, s1                       // 00000099EE04: D501000E 20061D0E
	v_mov_b32_dpp v16, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000099EE0C: 7E2002FA FF016209
	v_cndmask_b32_e64 v9, -v9, v9, s1                          // 00000099EE14: D5010009 20061309
	v_add_f32_e32 v7, v11, v8                                  // 00000099EE1C: 060E110B
	v_mov_b32_dpp v10, v12 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000099EE20: 7E1402FA FF01620C
	v_cndmask_b32_e64 v12, -v12, v12, s1                       // 00000099EE28: D501000C 2006190C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000099EE30: BF870114
	v_dual_add_f32 v8, v14, v15 :: v_dual_add_f32 v9, v9, v16  // 00000099EE34: C9081F0E 08082109
	v_add_f32_e32 v10, v12, v10                                // 00000099EE3C: 0614150C
	v_mov_b32_dpp v11, v13 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000099EE40: 7E1602FA FF01640D
	v_cndmask_b32_e64 v13, -v13, v13, s3                       // 00000099EE48: D501000D 200E1B0D
	s_delay_alu instid0(VALU_DEP_4)                            // 00000099EE50: BF870004
	v_mov_b32_dpp v15, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000099EE54: 7E1E02FA FF016408
	v_mov_b32_dpp v17, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000099EE5C: 7E2202FA FF016409
	v_mov_b32_dpp v12, v10 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000099EE64: 7E1802FA FF01640A
	v_cndmask_b32_e64 v10, -v10, v10, s3                       // 00000099EE6C: D501000A 200E150A
	v_cndmask_b32_e64 v18, -v8, v8, s3                         // 00000099EE74: D5010012 200E1108
	v_cndmask_b32_e64 v9, -v9, v9, s3                          // 00000099EE7C: D5010009 200E1309
	v_add_f32_e32 v14, v13, v11                                // 00000099EE84: 061C170D
	v_mov_b32_dpp v8, v7 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000099EE88: 7E1002FA FF016807
	v_add_f32_e32 v16, v10, v12                                // 00000099EE90: 0620190A
	v_add_f32_e32 v15, v18, v15                                // 00000099EE94: 061E1F12
	v_add_f32_e32 v17, v9, v17                                 // 00000099EE98: 06222309
	v_mov_b32_dpp v9, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000099EE9C: 7E1202FA FF016804
	v_mov_b32_dpp v10, v14 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000099EEA4: 7E1402FA FF01680E
	v_mov_b32_dpp v11, v16 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000099EEAC: 7E1602FA FF016810
	v_mov_b32_dpp v12, v15 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000099EEB4: 7E1802FA FF01680F
	v_mov_b32_dpp v13, v17 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000099EEBC: 7E1A02FA FF016811
	s_and_b32 exec_lo, exec_lo, s0                             // 00000099EEC4: 8B7E007E
	s_cbranch_execz 156                                        // 00000099EEC8: BFA5009C <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi1ELi2EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x233c>
	v_lshl_or_b32 v18, s10, 7, v1                              // 00000099EECC: D6560012 04050E0A
	v_and_b32_e32 v1, 8, v0                                    // 00000099EED4: 36020088
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000099EED8: BF870092
	v_ashrrev_i32_e32 v19, 31, v18                             // 00000099EEDC: 3426249F
	.long 0xd73c0012                                           // 00000099EEE0: D73C0012
	v_cndmask_b32_e32 v1, 1, v18, vcc_lo                       // 00000099EEE4: 02022481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000099EEE8: BF870091
	.long 0xd7006a14                                           // 00000099EEEC: D7006A14
	v_cndmask_b32_e32 v1, s36, v18, vcc_lo                     // 00000099EEF0: 02022424
	v_add_co_ci_u32_e64 v21, null, s37, v19, vcc_lo            // 00000099EEF4: D5207C15 01AA2625
	v_cmp_eq_u32_e32 vcc_lo, 0, v1                             // 00000099EEFC: 7C940280
	s_clause 0x7                                               // 00000099EF00: BF850007
	global_load_d16_b16 v22, v[20:21], off offset:32           // 00000099EF04: DC820020 167C0014
	global_load_d16_b16 v23, v[20:21], off                     // 00000099EF0C: DC820000 177C0014
	global_load_d16_b16 v24, v[20:21], off offset:64           // 00000099EF14: DC820040 187C0014
	global_load_d16_b16 v25, v[20:21], off offset:96           // 00000099EF1C: DC820060 197C0014
	global_load_d16_b16 v26, v[20:21], off offset:128          // 00000099EF24: DC820080 1A7C0014
	global_load_d16_b16 v27, v[20:21], off offset:160          // 00000099EF2C: DC8200A0 1B7C0014
	global_load_d16_b16 v28, v[20:21], off offset:192          // 00000099EF34: DC8200C0 1C7C0014
	global_load_d16_b16 v20, v[20:21], off offset:224          // 00000099EF3C: DC8200E0 147C0014
	.long 0x7f2a3880                                           // 00000099EF44: 7F2A3880
	v_cndmask_b32_e64 v1, -v6, v6, vcc_lo                      // 00000099EF48: D5010001 21AA0D06
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 00000099EF50: D5010004 21AA0904
	v_cndmask_b32_e64 v14, -v14, v14, vcc_lo                   // 00000099EF58: D501000E 21AA1D0E
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 00000099EF60: D5010003 21AA0703
	s_waitcnt vmcnt(7)                                         // 00000099EF68: BF891FF7
	.long 0x7f2c3995                                           // 00000099EF6C: 7F2C3995
	v_add_f32_e32 v1, v1, v5                                   // 00000099EF70: 06020B01
	v_cndmask_b32_e64 v5, -v7, v7, vcc_lo                      // 00000099EF74: D5010005 21AA0F07
	v_cndmask_b32_e64 v7, -v16, v16, vcc_lo                    // 00000099EF7C: D5010007 21AA2110
	v_cndmask_b32_e64 v16, -v17, v17, vcc_lo                   // 00000099EF84: D5010010 21AA2311
	v_add_f32_e32 v4, v4, v9                                   // 00000099EF8C: 06081304
	v_cndmask_b32_e64 v15, -v15, v15, vcc_lo                   // 00000099EF90: D501000F 21AA1F0F
	v_dual_add_f32 v5, v5, v8 :: v_dual_add_f32 v8, v14, v10   // 00000099EF98: C9081105 0508150E
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000099EFA0: BF8701A3
	v_dual_mul_f32 v17, 0x3db504f3, v1 :: v_dual_mul_f32 v4, 0x3db504f3, v4// 00000099EFA4: C8C602FF 110408FF 3DB504F3
	v_dual_add_f32 v3, v3, v2 :: v_dual_add_f32 v10, v16, v13  // 00000099EFB0: C9080503 030A1B10
	v_dual_add_f32 v7, v7, v11 :: v_dual_mul_f32 v8, 0x3db504f3, v8// 00000099EFB8: C9061707 070810FF 3DB504F3
	.long 0x7f0c3995                                           // 00000099EFC4: 7F0C3995
	s_delay_alu instid0(VALU_DEP_3)                            // 00000099EFC8: BF870003
	v_mul_f32_e32 v3, 0x3db504f3, v3                           // 00000099EFCC: 100606FF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 00000099EFD4: BF8903F7
	.long 0x7f283995                                           // 00000099EFD8: 7F283995
	v_dual_mul_f32 v7, 0x3db504f3, v7 :: v_dual_mul_f32 v10, 0x3db504f3, v10// 00000099EFDC: C8C60EFF 070A14FF 3DB504F3
	v_mul_f32_e32 v5, 0x3db504f3, v5                           // 00000099EFE8: 100A0AFF 3DB504F3
	.long 0x7f2e3995                                           // 00000099EFF0: 7F2E3995
	.long 0xd7006a01                                           // 00000099EFF4: D7006A01
	v_cndmask_b32_e32 v1, s42, v18, vcc_lo                     // 00000099EFF8: 0202242A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000099EFFC: BF870221
	v_add_co_ci_u32_e64 v2, null, s43, v19, vcc_lo             // 00000099F000: D5207C02 01AA262B
	v_fma_mix_f32 v11, v22, v17, neg(0) op_sel_hi:[1,0,0]      // 00000099F008: CC20000B 8A022316
	v_fma_mix_f32 v3, v23, v3, neg(0) op_sel_hi:[1,0,0]        // 00000099F010: CC200003 8A020717
	v_fma_mix_f32 v5, v24, v5, neg(0) op_sel_hi:[1,0,0]        // 00000099F018: CC200005 8A020B18
	v_fma_mix_f32 v4, v25, v4, neg(0) op_sel_hi:[1,0,0]        // 00000099F020: CC200004 8A020919
	v_fma_mix_f32 v8, v26, v8, neg(0) op_sel_hi:[1,0,0]        // 00000099F028: CC200008 8A02111A
	.long 0x7e2a398b                                           // 00000099F030: 7E2A398B
	v_add_f32_e32 v9, v15, v12                                 // 00000099F034: 0612190F
	v_fma_mix_f32 v7, v27, v7, neg(0) op_sel_hi:[1,0,0]        // 00000099F038: CC200007 8A020F1B
	v_fma_mix_f32 v10, v20, v10, neg(0) op_sel_hi:[1,0,0]      // 00000099F040: CC20000A 8A021514
	.long 0x7e0c3983                                           // 00000099F048: 7E0C3983
	v_and_b32_e32 v12, 1, v21                                  // 00000099F04C: 36182A81
	v_mul_f32_e32 v9, 0x3db504f3, v9                           // 00000099F050: 101212FF 3DB504F3
	.long 0x7e2a3984                                           // 00000099F058: 7E2A3984
	.long 0x7e283985                                           // 00000099F05C: 7E283985
	.long 0x7e2c3988                                           // 00000099F060: 7E2C3988
	v_and_b32_e32 v6, 1, v6                                    // 00000099F064: 360C0C81
	v_fma_mix_f32 v9, v28, v9, neg(0) op_sel_hi:[1,0,0]        // 00000099F068: CC200009 8A02131C
	v_and_b32_e32 v13, 1, v21                                  // 00000099F070: 361A2A81
	.long 0x7e2a3987                                           // 00000099F074: 7E2A3987
	v_and_b32_e32 v14, 1, v20                                  // 00000099F078: 361C2881
	v_and_b32_e32 v15, 1, v22                                  // 00000099F07C: 361E2C81
	.long 0x7e2e3989                                           // 00000099F080: 7E2E3989
	v_add3_u32 v3, v3, v6, 0x7fff                              // 00000099F084: D6550003 03FE0D03 00007FFF
	v_and_b32_e32 v16, 1, v21                                  // 00000099F090: 36202A81
	.long 0x7e2a398a                                           // 00000099F094: 7E2A398A
	v_add3_u32 v11, v11, v12, 0x7fff                           // 00000099F098: D655000B 03FE190B 00007FFF
	v_and_b32_e32 v17, 1, v23                                  // 00000099F0A4: 36222E81
	v_add3_u32 v5, v5, v14, 0x7fff                             // 00000099F0A8: D6550005 03FE1D05 00007FFF
	v_add3_u32 v4, v4, v13, 0x7fff                             // 00000099F0B4: D6550004 03FE1B04 00007FFF
	v_and_b32_e32 v6, 1, v21                                   // 00000099F0C0: 360C2A81
	v_add3_u32 v8, v8, v15, 0x7fff                             // 00000099F0C4: D6550008 03FE1F08 00007FFF
	v_add3_u32 v9, v9, v17, 0x7fff                             // 00000099F0D0: D6550009 03FE2309 00007FFF
	v_add3_u32 v7, v7, v16, 0x7fff                             // 00000099F0DC: D6550007 03FE2107 00007FFF
	s_delay_alu instid0(VALU_DEP_4)                            // 00000099F0E8: BF870004
	v_add3_u32 v6, v10, v6, 0x7fff                             // 00000099F0EC: D6550006 03FE0D0A 00007FFF
	s_clause 0x7                                               // 00000099F0F8: BF850007
	global_store_d16_hi_b16 v[1:2], v3, off                    // 00000099F0FC: DC960000 007C0301
	global_store_d16_hi_b16 v[1:2], v11, off offset:32         // 00000099F104: DC960020 007C0B01
	global_store_d16_hi_b16 v[1:2], v5, off offset:64          // 00000099F10C: DC960040 007C0501
	global_store_d16_hi_b16 v[1:2], v4, off offset:96          // 00000099F114: DC960060 007C0401
	global_store_d16_hi_b16 v[1:2], v8, off offset:128         // 00000099F11C: DC960080 007C0801
	global_store_d16_hi_b16 v[1:2], v7, off offset:160         // 00000099F124: DC9600A0 007C0701
	global_store_d16_hi_b16 v[1:2], v9, off offset:192         // 00000099F12C: DC9600C0 007C0901
	global_store_d16_hi_b16 v[1:2], v6, off offset:224         // 00000099F134: DC9600E0 007C0601
	s_or_b32 exec_lo, exec_lo, s4                              // 00000099F13C: 8C7E047E
	s_mov_b32 s4, 0                                            // 00000099F140: BE840080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000099F144: BF870009
	s_and_b32 vcc_lo, exec_lo, s4                              // 00000099F148: 8B6A047E
	s_cbranch_vccz 3849                                        // 00000099F14C: BFA30F09 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi1ELi2EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x5f74>
	s_mul_hi_i32 s0, s2, 0x66666667                            // 00000099F150: 9700FF02 66666667
	v_mov_b32_e32 v1, 0                                        // 00000099F158: 7E020280
	s_lshr_b32 s1, s0, 31                                      // 00000099F15C: 85019F00
	s_ashr_i32 s0, s0, 1                                       // 00000099F160: 86008100
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000099F164: BF870499
	s_add_i32 s10, s0, s1                                      // 00000099F168: 810A0100
	s_ashr_i32 s11, s10, 31                                    // 00000099F16C: 860B9F0A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000099F170: BF870499
	s_lshl_b64 s[0:1], s[10:11], 2                             // 00000099F174: 8480820A
	s_add_u32 s0, s16, s0                                      // 00000099F178: 80000010
	s_addc_u32 s1, s17, s1                                     // 00000099F17C: 82010111
	global_load_b32 v1, v1, s[0:1]                             // 00000099F180: DC520000 01000001
	s_mov_b32 s1, exec_lo                                      // 00000099F188: BE81007E
	s_waitcnt vmcnt(0)                                         // 00000099F18C: BF8903F7
	v_readfirstlane_b32 s4, v1                                 // 00000099F190: 7E080501
	v_cmpx_gt_u32_e32 0x140, v0                                // 00000099F194: 7D9800FF 00000140
	s_cbranch_execz 44                                         // 00000099F19C: BFA5002C <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi1ELi2EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x2450>
	s_mul_hi_i32 s0, s2, 0x51eb851f                            // 00000099F1A0: 9700FF02 51EB851F
	v_lshlrev_b32_e32 v4, 4, v0                                // 00000099F1A8: 30080084
	s_lshr_b32 s3, s0, 31                                      // 00000099F1AC: 85039F00
	s_ashr_i32 s0, s0, 4                                       // 00000099F1B0: 86008400
	v_or_b32_e32 v3, 0xffffff00, v0                            // 00000099F1B4: 380600FF FFFFFF00
	s_add_i32 s0, s0, s3                                       // 00000099F1BC: 81000300
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000099F1C0: BF8700D9
	s_mul_i32 s3, s0, 0x1400                                   // 00000099F1C4: 9603FF00 00001400
	s_mul_hi_i32 s0, s0, 0x1400                                // 00000099F1CC: 9700FF00 00001400
	s_add_u32 s3, s14, s3                                      // 00000099F1D4: 8003030E
	s_addc_u32 s0, s15, s0                                     // 00000099F1D8: 8200000F
	.long 0xd7000301                                           // 00000099F1DC: D7000301
	v_cndmask_b32_e32 v1, s3, v4, vcc_lo                       // 00000099F1E0: 02020803
	v_add_co_ci_u32_e64 v2, null, s0, 0, s3                    // 00000099F1E4: D5207C02 000D0000
	s_mov_b32 s3, 0                                            // 00000099F1EC: BE830080
	s_nop 0                                                    // 00000099F1F0: BF800000
	s_nop 0                                                    // 00000099F1F4: BF800000
	s_nop 0                                                    // 00000099F1F8: BF800000
	s_nop 0                                                    // 00000099F1FC: BF800000
	global_load_b128 v[5:8], v[1:2], off                       // 00000099F200: DC5E0000 057C0001
	v_add_nc_u32_e32 v3, 0x100, v3                             // 00000099F208: 4A0606FF 00000100
	.long 0xd7006a01                                           // 00000099F210: D7006A01
	v_cndmask_b32_e32 v1, 0x1000, v1, vcc_lo                   // 00000099F214: 020202FF 00001000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000099F21C: BF870191
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 00000099F220: D5207C02 01AA0480
	.long 0xd4490000                                           // 00000099F228: D4490000
	v_cndmask_b32_e32 v1, 63, v3, vcc_lo                       // 00000099F22C: 020206BF
	s_or_b32 s3, s0, s3                                        // 00000099F230: 8C030300
	s_waitcnt vmcnt(0)                                         // 00000099F234: BF8903F7
	ds_store_b128 v4, v[5:8]                                   // 00000099F238: DB7C0000 00000504
	v_add_nc_u32_e32 v4, 0x1000, v4                            // 00000099F240: 4A0808FF 00001000
	s_and_not1_b32 exec_lo, exec_lo, s3                        // 00000099F248: 917E037E
	s_cbranch_execnz 65516                                     // 00000099F24C: BFA6FFEC <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi1ELi2EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x2400>
	s_or_b32 exec_lo, exec_lo, s1                              // 00000099F250: 8C7E017E
	v_mul_u32_u24_e32 v25, 20, v71                             // 00000099F254: 16328E94
	v_mad_u32_u24 v88, v72, 24, 0x2f0                          // 00000099F258: D60B0058 03FD3148 000002F0
	v_cmp_eq_u32_e32 vcc_lo, 0, v72                            // 00000099F264: 7C949080
	s_mul_i32 s5, s10, -5                                      // 00000099F268: 9605C50A
	s_mul_i32 s1, s4, 0x12c000                                 // 00000099F26C: 9601FF04 0012C000
	v_min_u32_e32 v26, 0x8c, v25                               // 00000099F274: 263432FF 0000008C
	v_lshrrev_b32_e32 v1, 5, v88                               // 00000099F27C: 3202B085
	s_mul_hi_i32 s0, s4, 0x12c000                              // 00000099F280: 9700FF04 0012C000
	s_add_i32 s5, s5, s2                                       // 00000099F288: 81050205
	s_add_u32 s1, s12, s1                                      // 00000099F28C: 8001010C
	v_add_nc_u32_e32 v73, 20, v26                              // 00000099F290: 4A923494
	v_subrev_nc_u32_e32 v1, 24, v1                             // 00000099F294: 4E020298
	s_addc_u32 s3, s13, s0                                     // 00000099F298: 8203000D
	s_mul_i32 s2, s5, 0x3c000                                  // 00000099F29C: 9602FF05 0003C000
	v_add_nc_u32_e32 v89, 8, v88                               // 00000099F2A4: 4AB2B088
	.long 0xd4490000                                           // 00000099F2A8: D4490000
	v_cndmask_b32_e32 v1, v25, v73, vcc_lo                     // 00000099F2AC: 02029319
	v_cndmask_b32_e64 v15, v1, 23, vcc_lo                      // 00000099F2B0: D501000F 01A92F01
	s_mul_hi_i32 s6, s5, 0x3c000                               // 00000099F2B8: 9706FF05 0003C000
	s_add_u32 s2, s1, s2                                       // 00000099F2C0: 80020201
	s_addc_u32 s3, s3, s6                                      // 00000099F2C4: 82030603
	s_waitcnt lgkmcnt(0)                                       // 00000099F2C8: BF89FC07
	s_waitcnt_vscnt null, 0x0                                  // 00000099F2CC: BC7C0000
	s_barrier                                                  // 00000099F2D0: BFBD0000
	buffer_gl0_inv                                             // 00000099F2D4: E0AC0000 00000000
	s_and_saveexec_b32 s6, s0                                  // 00000099F2DC: BE862000
	s_cbranch_execz 190                                        // 00000099F2E0: BFA500BE <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi1ELi2EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x27dc>
	v_lshrrev_b32_e32 v1, 5, v89                               // 00000099F2E4: 3202B285
	.long 0xd4440001                                           // 00000099F2E8: D4440001
	v_cndmask_b32_e32 v1, 23, v15, vcc_lo                      // 00000099F2EC: 02021E97
	v_mul_u32_u24_e32 v6, 0x7800, v71                          // 00000099F2F0: 160C8EFF 00007800
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000099F2F8: BF870193
	v_subrev_nc_u32_e32 v1, 24, v1                             // 00000099F2FC: 4E020298
	v_cndmask_b32_e64 v2, 0xe9, 1, s1                          // 00000099F300: D5010002 000502FF 000000E9
	v_mov_b32_e32 v16, 0                                       // 00000099F30C: 7E200280
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000099F310: BF870193
	v_cndmask_b32_e64 v1, v1, 23, vcc_lo                       // 00000099F314: D5010001 01A92F01
	v_add_nc_u32_e32 v5, v2, v15                               // 00000099F31C: 4A0A1F02
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000099F320: BF870223
	.long 0xd73c0003                                           // 00000099F324: D73C0003
	v_cndmask_b32_e32 v1, 2, v15, vcc_lo                       // 00000099F328: 02021E82
	v_mov_b32_e32 v2, v16                                      // 00000099F32C: 7E040310
	.long 0xd4440001                                           // 00000099F330: D4440001
	v_cndmask_b32_e32 v1, 23, v1, vcc_lo                       // 00000099F334: 02020297
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000099F338: BF8701A4
	v_lshlrev_b32_e32 v7, 24, v5                               // 00000099F33C: 300E0A98
	v_bfe_i32 v9, v5, 7, 1                                     // 00000099F340: D6110009 02050F05
	v_cndmask_b32_e64 v8, 0xe9, 1, s1                          // 00000099F348: D5010008 000502FF 000000E9
	.long 0xd700010b                                           // 00000099F354: D700010B
	v_cndmask_b32_e32 v1, s2, v6, vcc_lo                       // 00000099F358: 02020C02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000099F35C: BF870191
	v_add_co_ci_u32_e64 v12, null, s3, 0, s1                   // 00000099F360: D5207C0C 00050003
	v_add_nc_u32_e32 v10, v8, v1                               // 00000099F368: 4A140308
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000099F36C: BF870233
	.long 0xd7000105                                           // 00000099F370: D7000105
	v_cndmask_b32_e32 v1, v11, v3, vcc_lo                      // 00000099F374: 0202070B
	v_ashrrev_i32_e32 v7, 22, v7                               // 00000099F378: 340E0E96
	.long 0xd73c0001                                           // 00000099F37C: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 00000099F380: 02020282
	v_lshlrev_b32_e32 v3, 24, v10                              // 00000099F384: 30061498
	v_add_co_ci_u32_e64 v6, null, v12, v4, s1                  // 00000099F388: D5207C06 0006090C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000099F390: BF870194
	.long 0xd7000107                                           // 00000099F394: D7000107
	v_cndmask_b32_e32 v1, v11, v7, vcc_lo                      // 00000099F398: 02020F0B
	v_ashrrev_i32_e32 v3, 22, v3                               // 00000099F39C: 34060696
	v_bfe_i32 v4, v10, 7, 1                                    // 00000099F3A0: D6110004 02050F0A
	v_add_co_ci_u32_e64 v8, null, v12, v9, s1                  // 00000099F3A8: D5207C08 0006130C
	.long 0xd7000109                                           // 00000099F3B0: D7000109
	v_cndmask_b32_e32 v1, v11, v1, vcc_lo                      // 00000099F3B4: 0202030B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000099F3B8: BF8700A1
	v_add_co_ci_u32_e64 v10, null, v12, v2, s1                 // 00000099F3BC: D5207C0A 0006050C
	.long 0xd700014a                                           // 00000099F3C4: D700014A
	v_cndmask_b32_e32 v1, v11, v3, vcc_lo                      // 00000099F3C8: 0202070B
	v_add_co_ci_u32_e64 v75, null, v12, v4, s1                 // 00000099F3CC: D5207C4B 0006090C
	s_clause 0x1f                                              // 00000099F3D4: BF85001F
	global_load_b32 v2, v[5:6], off                            // 00000099F3D8: DC520000 027C0005
	global_load_b32 v68, v[5:6], off offset:96                 // 00000099F3E0: DC520060 447C0005
	global_load_b32 v64, v[5:6], off offset:192                // 00000099F3E8: DC5200C0 407C0005
	global_load_b32 v60, v[5:6], off offset:288                // 00000099F3F0: DC520120 3C7C0005
	global_load_b32 v56, v[5:6], off offset:384                // 00000099F3F8: DC520180 387C0005
	global_load_b32 v52, v[5:6], off offset:480                // 00000099F400: DC5201E0 347C0005
	global_load_b32 v48, v[5:6], off offset:576                // 00000099F408: DC520240 307C0005
	global_load_b32 v44, v[5:6], off offset:672                // 00000099F410: DC5202A0 2C7C0005
	global_load_b32 v1, v[7:8], off                            // 00000099F418: DC520000 017C0007
	global_load_b32 v67, v[7:8], off offset:96                 // 00000099F420: DC520060 437C0007
	global_load_b32 v63, v[7:8], off offset:192                // 00000099F428: DC5200C0 3F7C0007
	global_load_b32 v59, v[7:8], off offset:288                // 00000099F430: DC520120 3B7C0007
	global_load_b32 v55, v[7:8], off offset:384                // 00000099F438: DC520180 377C0007
	global_load_b32 v51, v[7:8], off offset:480                // 00000099F440: DC5201E0 337C0007
	global_load_b32 v47, v[7:8], off offset:576                // 00000099F448: DC520240 2F7C0007
	global_load_b32 v43, v[7:8], off offset:672                // 00000099F450: DC5202A0 2B7C0007
	global_load_b32 v4, v[9:10], off                           // 00000099F458: DC520000 047C0009
	global_load_b32 v70, v[9:10], off offset:96                // 00000099F460: DC520060 467C0009
	global_load_b32 v66, v[9:10], off offset:192               // 00000099F468: DC5200C0 427C0009
	global_load_b32 v62, v[9:10], off offset:288               // 00000099F470: DC520120 3E7C0009
	global_load_b32 v58, v[9:10], off offset:384               // 00000099F478: DC520180 3A7C0009
	global_load_b32 v54, v[9:10], off offset:480               // 00000099F480: DC5201E0 367C0009
	global_load_b32 v50, v[9:10], off offset:576               // 00000099F488: DC520240 327C0009
	global_load_b32 v46, v[9:10], off offset:672               // 00000099F490: DC5202A0 2E7C0009
	global_load_b32 v3, v[74:75], off                          // 00000099F498: DC520000 037C004A
	global_load_b32 v69, v[74:75], off offset:96               // 00000099F4A0: DC520060 457C004A
	global_load_b32 v65, v[74:75], off offset:192              // 00000099F4A8: DC5200C0 417C004A
	global_load_b32 v61, v[74:75], off offset:288              // 00000099F4B0: DC520120 3D7C004A
	global_load_b32 v57, v[74:75], off offset:384              // 00000099F4B8: DC520180 397C004A
	global_load_b32 v53, v[74:75], off offset:480              // 00000099F4C0: DC5201E0 357C004A
	global_load_b32 v49, v[74:75], off offset:576              // 00000099F4C8: DC520240 317C004A
	global_load_b32 v45, v[74:75], off offset:672              // 00000099F4D0: DC5202A0 2D7C004A
	s_clause 0x1f                                              // 00000099F4D8: BF85001F
	global_load_b32 v40, v[5:6], off offset:768                // 00000099F4DC: DC520300 287C0005
	global_load_b32 v36, v[5:6], off offset:864                // 00000099F4E4: DC520360 247C0005
	global_load_b32 v32, v[5:6], off offset:960                // 00000099F4EC: DC5203C0 207C0005
	global_load_b32 v28, v[5:6], off offset:1056               // 00000099F4F4: DC520420 1C7C0005
	global_load_b32 v22, v[5:6], off offset:1152               // 00000099F4FC: DC520480 167C0005
	global_load_b32 v18, v[5:6], off offset:1248               // 00000099F504: DC5204E0 127C0005
	global_load_b32 v12, v[5:6], off offset:1344               // 00000099F50C: DC520540 0C7C0005
	global_load_b32 v6, v[5:6], off offset:1440                // 00000099F514: DC5205A0 067C0005
	global_load_b32 v39, v[7:8], off offset:768                // 00000099F51C: DC520300 277C0007
	global_load_b32 v35, v[7:8], off offset:864                // 00000099F524: DC520360 237C0007
	global_load_b32 v31, v[7:8], off offset:960                // 00000099F52C: DC5203C0 1F7C0007
	global_load_b32 v27, v[7:8], off offset:1056               // 00000099F534: DC520420 1B7C0007
	global_load_b32 v21, v[7:8], off offset:1152               // 00000099F53C: DC520480 157C0007
	global_load_b32 v17, v[7:8], off offset:1248               // 00000099F544: DC5204E0 117C0007
	global_load_b32 v11, v[7:8], off offset:1344               // 00000099F54C: DC520540 0B7C0007
	global_load_b32 v5, v[7:8], off offset:1440                // 00000099F554: DC5205A0 057C0007
	global_load_b32 v42, v[9:10], off offset:768               // 00000099F55C: DC520300 2A7C0009
	global_load_b32 v38, v[9:10], off offset:864               // 00000099F564: DC520360 267C0009
	global_load_b32 v34, v[9:10], off offset:960               // 00000099F56C: DC5203C0 227C0009
	global_load_b32 v30, v[9:10], off offset:1056              // 00000099F574: DC520420 1E7C0009
	global_load_b32 v24, v[9:10], off offset:1152              // 00000099F57C: DC520480 187C0009
	global_load_b32 v20, v[9:10], off offset:1248              // 00000099F584: DC5204E0 147C0009
	global_load_b32 v14, v[9:10], off offset:1344              // 00000099F58C: DC520540 0E7C0009
	global_load_b32 v8, v[9:10], off offset:1440               // 00000099F594: DC5205A0 087C0009
	global_load_b32 v41, v[74:75], off offset:768              // 00000099F59C: DC520300 297C004A
	global_load_b32 v37, v[74:75], off offset:864              // 00000099F5A4: DC520360 257C004A
	global_load_b32 v33, v[74:75], off offset:960              // 00000099F5AC: DC5203C0 217C004A
	global_load_b32 v29, v[74:75], off offset:1056             // 00000099F5B4: DC520420 1D7C004A
	global_load_b32 v23, v[74:75], off offset:1152             // 00000099F5BC: DC520480 177C004A
	global_load_b32 v19, v[74:75], off offset:1248             // 00000099F5C4: DC5204E0 137C004A
	global_load_b32 v13, v[74:75], off offset:1344             // 00000099F5CC: DC520540 0D7C004A
	global_load_b32 v7, v[74:75], off offset:1440              // 00000099F5D4: DC5205A0 077C004A
	s_or_b32 exec_lo, exec_lo, s6                              // 00000099F5DC: 8C7E067E
	v_dual_mov_b32 v10, 0 :: v_dual_mov_b32 v75, 0             // 00000099F5E0: CA100080 0A4A0080
	v_dual_mov_b32 v74, 0 :: v_dual_mov_b32 v77, 0             // 00000099F5E8: CA100080 4A4C0080
	v_dual_mov_b32 v76, 0 :: v_dual_mov_b32 v79, 0             // 00000099F5F0: CA100080 4C4E0080
	v_dual_mov_b32 v78, 0 :: v_dual_mov_b32 v81, 0             // 00000099F5F8: CA100080 4E500080
	v_dual_mov_b32 v80, 0 :: v_dual_mov_b32 v83, 0             // 00000099F600: CA100080 50520080
	v_dual_mov_b32 v82, 0 :: v_dual_mov_b32 v85, 0             // 00000099F608: CA100080 52540080
	v_dual_mov_b32 v84, 0 :: v_dual_mov_b32 v87, 0             // 00000099F610: CA100080 54560080
	v_dual_mov_b32 v86, 0 :: v_dual_mov_b32 v9, 0              // 00000099F618: CA100080 56080080
	s_and_saveexec_b32 s1, s0                                  // 00000099F620: BE812000
	s_cbranch_execz 2083                                       // 00000099F624: BFA50823 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi1ELi2EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x48b4>
	v_lshrrev_b32_e32 v9, 5, v89                               // 00000099F628: 3212B285
	v_mul_i32_i24_e32 v74, 0xffffffe8, v72                     // 00000099F62C: 129490FF FFFFFFE8
	v_dual_mov_b32 v10, 0 :: v_dual_and_b32 v75, 0x7e0, v88    // 00000099F634: CA240080 0A4AB0FF 000007E0
	v_and_b32_e32 v78, 16, v0                                  // 00000099F640: 369C0090
	s_delay_alu instid0(VALU_DEP_4)                            // 00000099F644: BF870004
	v_subrev_nc_u32_e32 v9, 24, v9                             // 00000099F648: 4E121298
	v_sub_nc_u32_e32 v89, 0, v26                               // 00000099F64C: 4CB23480
	v_add_nc_u32_e32 v88, 1, v25                               // 00000099F650: 4AB03281
	v_add3_u32 v90, v74, v75, 0xfffffd34                       // 00000099F654: D655005A 03FE974A FFFFFD34
	v_mov_b32_e32 v75, v10                                     // 00000099F660: 7E96030A
	v_cndmask_b32_e64 v9, v9, 23, vcc_lo                       // 00000099F664: D5010009 01A92F09
	v_lshl_or_b32 v91, v25, 5, v78                             // 00000099F66C: D656005B 05390B19
	.long 0xd4440000                                           // 00000099F674: D4440000
	v_cndmask_b32_e32 v1, 23, v15, vcc_lo                      // 00000099F678: 02021E97
	v_lshl_or_b32 v76, v72, 3, 4                               // 00000099F67C: D656004C 02110748
	v_ashrrev_i32_e32 v16, 31, v15                             // 00000099F684: 34201E9F
	.long 0xd703001a                                           // 00000099F688: D703001A
	v_cndmask_b32_e32 v0, v9, v129, vcc_lo                     // 00000099F68C: 02010309
	v_mov_b32_e32 v79, v10                                     // 00000099F690: 7E9E030A
	v_cndmask_b32_e64 v77, 0xe9, 1, s0                         // 00000099F694: D501004D 000102FF 000000E9
	v_mad_u32_u24 v83, v76, 3, 0x2f0                           // 00000099F6A0: D60B0053 03FD074C 000002F0
	v_mul_i32_i24_e32 v85, -3, v76                             // 00000099F6AC: 12AA98C3
	.long 0xd7620019                                           // 00000099F6B0: D7620019
	v_cndmask_b32_e32 v1, 0xff, v26, vcc_lo                    // 00000099F6B4: 020234FF 000000FF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000099F6BC: BF870234
	v_dual_mov_b32 v81, v10 :: v_dual_add_nc_u32 v84, v77, v15 // 00000099F6C0: CA20010A 51541F4D
	.long 0xd73c000f                                           // 00000099F6C8: D73C000F
	v_cndmask_b32_e32 v1, 2, v15, vcc_lo                       // 00000099F6CC: 02021E82
	v_mov_b32_e32 v77, v10                                     // 00000099F6D0: 7E9A030A
	v_cmp_ne_u16_e32 vcc_lo, 24, v25                           // 00000099F6D4: 7C7A3298
	v_mov_b32_e32 v78, v10                                     // 00000099F6D8: 7E9C030A
	v_and_b32_e32 v86, 0xff, v84                               // 00000099F6DC: 36ACA8FF 000000FF
	v_mov_b32_e32 v80, v10                                     // 00000099F6E4: 7EA0030A
	v_mov_b32_e32 v82, v10                                     // 00000099F6E8: 7EA4030A
	v_cndmask_b16 v25, 0, v26, vcc_lo                          // 00000099F6EC: D65D0019 01AA3480
	v_mov_b32_e32 v74, v10                                     // 00000099F6F4: 7E94030A
	v_dual_mov_b32 v83, v10 :: v_dual_and_b32 v26, 0x7e0, v83  // 00000099F6F8: CA24010A 531AA6FF 000007E0
	v_dual_mov_b32 v76, v10 :: v_dual_lshlrev_b32 v93, 2, v86  // 00000099F704: CA22010A 4C5CAC82
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000099F70C: BF870194
	v_and_b32_e32 v25, 0xff, v25                               // 00000099F710: 363232FF 000000FF
	v_add3_u32 v92, v85, v26, 0xfffffd34                       // 00000099F718: D655005C 03FE3555 FFFFFD34
	v_mov_b32_e32 v84, v10                                     // 00000099F724: 7EA8030A
	v_mov_b32_e32 v86, v10                                     // 00000099F728: 7EAC030A
	s_delay_alu instid0(VALU_DEP_4)                            // 00000099F72C: BF870004
	v_dual_mov_b32 v85, v10 :: v_dual_lshlrev_b32 v94, 2, v25  // 00000099F730: CA22010A 555E3282
	.long 0xd73c0019                                           // 00000099F738: D73C0019
	v_cndmask_b32_e32 v1, 2, v9, vcc_lo                        // 00000099F73C: 02021282
	v_mov_b32_e32 v87, v10                                     // 00000099F740: 7EAE030A
	v_mov_b32_e32 v9, v10                                      // 00000099F744: 7E12030A
	s_mov_b32 s0, 0                                            // 00000099F748: BE800080
	s_mov_b32 s6, 0xdcd12d                                     // 00000099F74C: BE8600FF 00DCD12D
	s_movk_i32 s7, 0x83                                        // 00000099F754: B0070083
	s_movk_i32 s8, 0x1eee                                      // 00000099F758: B0081EEE
	s_branch 1847                                              // 00000099F75C: BFA00737 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi1ELi2EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x463c>
	s_or_b32 exec_lo, exec_lo, s9                              // 00000099F760: 8C7E097E
	s_waitcnt vmcnt(55)                                        // 00000099F764: BF89DFF7
	.long 0xd73d0001                                           // 00000099F768: D73D0001
	v_cndmask_b32_e32 v1, v90, v1, vcc_lo                      // 00000099F76C: 0202035A
	s_waitcnt vmcnt(39)                                        // 00000099F770: BF899FF7
	.long 0xd73d0002                                           // 00000099F774: D73D0002
	v_cndmask_b32_e32 v1, v92, v3, vcc_lo                      // 00000099F778: 0202075C
	.long 0xd73d0043                                           // 00000099F77C: D73D0043
	v_cndmask_b32_e32 v1, v90, v67, vcc_lo                     // 00000099F780: 0202875A
	s_waitcnt vmcnt(38)                                        // 00000099F784: BF899BF7
	.long 0xd73d0044                                           // 00000099F788: D73D0044
	v_cndmask_b32_e32 v1, v92, v69, vcc_lo                     // 00000099F78C: 02028B5C
	.long 0xd73d003f                                           // 00000099F790: D73D003F
	v_cndmask_b32_e32 v1, v90, v63, vcc_lo                     // 00000099F794: 02027F5A
	.long 0xd73d003b                                           // 00000099F798: D73D003B
	v_cndmask_b32_e32 v1, v90, v59, vcc_lo                     // 00000099F79C: 0202775A
	v_bfe_u32 v3, v1, 9, 16                                    // 00000099F7A0: D6100003 02411301
	v_bfe_u32 v160, v2, 9, 16                                  // 00000099F7A8: D61000A0 02411302
	v_bfe_u32 v161, v2, 6, 16                                  // 00000099F7B0: D61000A1 02410D02
	v_bfe_u32 v162, v2, 3, 16                                  // 00000099F7B8: D61000A2 02410702
	v_and_b32_e32 v163, 0xffff, v2                             // 00000099F7C0: 374604FF 0000FFFF
	v_mul_u32_u24_e32 v2, s6, v3                               // 00000099F7C8: 16040606
	v_mul_u32_u24_e32 v3, s7, v3                               // 00000099F7CC: 16060607
	v_lshl_add_u32 v2, v3, 24, v2                              // 00000099F7D0: D6460002 04093103
	v_bfe_u32 v4, v1, 6, 16                                    // 00000099F7D8: D6100004 02410D01
	v_mul_u32_u24_e32 v3, s6, v4                               // 00000099F7E0: 16060806
	v_bfe_u32 v159, v1, 3, 16                                  // 00000099F7E4: D610009F 02410701
	v_mul_u32_u24_e32 v4, s7, v4                               // 00000099F7EC: 16080807
	v_sad_u8 v2, v2, 0, 0x6400                                 // 00000099F7F0: D6220002 03FD0102 00006400
	v_lshl_add_u32 v3, v4, 24, v3                              // 00000099F7FC: D6460003 040D3104
	v_and_b32_e32 v1, 0xffff, v1                               // 00000099F804: 360202FF 0000FFFF
	v_mul_u32_u24_e32 v164, s6, v159                           // 00000099F80C: 17493E06
	v_mul_u32_u24_e32 v4, s7, v159                             // 00000099F810: 16093E07
	v_mul_u32_u24_e32 v159, s6, v160                           // 00000099F814: 173F4006
	v_and_b32_e32 v166, 0xffff, v2                             // 00000099F818: 374C04FF 0000FFFF
	v_mul_u32_u24_e32 v2, s7, v160                             // 00000099F820: 16054007
	v_lshl_add_u32 v159, v2, 24, v159                          // 00000099F824: D646009F 067D3102
	v_mul_u32_u24_e32 v2, s6, v1                               // 00000099F82C: 16040206
	v_mul_u32_u24_e32 v1, s7, v1                               // 00000099F830: 16020207
	v_lshl_add_u32 v160, v1, 24, v2                            // 00000099F834: D64600A0 04093101
	v_mul_u32_u24_e32 v1, s6, v161                             // 00000099F83C: 16034206
	v_mul_u32_u24_e32 v2, s7, v161                             // 00000099F840: 16054207
	v_lshl_add_u32 v161, v2, 24, v1                            // 00000099F844: D64600A1 04053102
	v_mul_u32_u24_e32 v1, s6, v162                             // 00000099F84C: 16034406
	v_mul_u32_u24_e32 v2, s7, v162                             // 00000099F850: 16054407
	v_lshl_add_u32 v164, v4, 24, v164                          // 00000099F854: D64600A4 06913104
	v_sad_u8 v165, v3, 0, 0x6400                               // 00000099F85C: D62200A5 03FD0103 00006400
	v_lshl_add_u32 v162, v2, 24, v1                            // 00000099F868: D64600A2 04053102
	ds_load_b128 v[1:4], v91                                   // 00000099F870: DBFC0000 0100005B
	v_sad_u8 v159, v159, 0, 0x6400                             // 00000099F878: D622009F 03FD019F 00006400
	v_sad_u8 v164, v164, 0, 0x6400                             // 00000099F884: D62200A4 03FD01A4 00006400
	v_lshl_or_b32 v165, v165, 16, v166                         // 00000099F890: D65600A5 069921A5
	v_sad_u8 v160, v160, 0, 0x6400                             // 00000099F898: D62200A0 03FD01A0 00006400
	v_sad_u8 v161, v161, 0, 0x6400                             // 00000099F8A4: D62200A1 03FD01A1 00006400
	v_and_b32_e32 v159, 0xffff, v159                           // 00000099F8B0: 373F3EFF 0000FFFF
	v_and_b32_e32 v164, 0xffff, v164                           // 00000099F8B8: 374948FF 0000FFFF
	v_pk_fma_f16 v165, v165, s8, 0xc931 op_sel_hi:[1,0,0]      // 00000099F8C0: CC0E00A5 0BFC11A5 0000C931
	v_mul_u32_u24_e32 v167, s6, v163                           // 00000099F8CC: 174F4606
	v_mul_u32_u24_e32 v163, s7, v163                           // 00000099F8D0: 17474607
	v_lshl_add_u32 v163, v163, 24, v167                        // 00000099F8D4: D64600A3 069D31A3
	v_lshl_or_b32 v160, v160, 16, v164                         // 00000099F8DC: D65600A0 069121A0
	v_sad_u8 v162, v162, 0, 0x6400                             // 00000099F8E4: D62200A2 03FD01A2 00006400
	v_lshl_or_b32 v159, v161, 16, v159                         // 00000099F8F0: D656009F 067D21A1
	v_bfe_u32 v69, v67, 9, 16                                  // 00000099F8F8: D6100045 02411343
	v_sad_u8 v163, v163, 0, 0x6400                             // 00000099F900: D62200A3 03FD01A3 00006400
	v_pk_fma_f16 v160, v160, s8, 0xc931 op_sel_hi:[1,0,0]      // 00000099F90C: CC0E00A0 0BFC11A0 0000C931
	v_mul_u32_u24_e32 v164, s6, v69                            // 00000099F918: 17488A06
	v_pk_fma_f16 v159, v159, s8, 0xc931 op_sel_hi:[1,0,0]      // 00000099F91C: CC0E009F 0BFC119F 0000C931
	s_waitcnt lgkmcnt(0)                                       // 00000099F928: BF89FC07
	v_dot2acc_f32_f16 v9, v165, v1                             // 00000099F92C: 041203A5
	v_mul_u32_u24_e32 v69, s7, v69                             // 00000099F930: 168A8A07
	v_lshl_add_u32 v69, v69, 24, v164                          // 00000099F934: D6460045 06913145
	v_bfe_u32 v70, v67, 6, 16                                  // 00000099F93C: D6100046 02410D43
	v_bfe_u32 v164, v68, 6, 16                                 // 00000099F944: D61000A4 02410D44
	v_dot2acc_f32_f16 v9, v160, v2                             // 00000099F94C: 041205A0
	v_and_b32_e32 v162, 0xffff, v162                           // 00000099F950: 374544FF 0000FFFF
	v_sad_u8 v69, v69, 0, 0x6400                               // 00000099F958: D6220045 03FD0145 00006400
	v_bfe_u32 v165, v68, 3, 16                                 // 00000099F964: D61000A5 02410744
	s_waitcnt vmcnt(36)                                        // 00000099F96C: BF8993F7
	.long 0xd73d003c                                           // 00000099F970: D73D003C
	v_cndmask_b32_e32 v1, v92, v61, vcc_lo                     // 00000099F974: 02027B5C
	v_dot2acc_f32_f16 v9, v159, v3                             // 00000099F978: 0412079F
	v_lshl_or_b32 v161, v163, 16, v162                         // 00000099F97C: D65600A1 068921A3
	v_bfe_u32 v162, v67, 3, 16                                 // 00000099F984: D61000A2 02410743
	v_mul_u32_u24_e32 v166, s6, v162                           // 00000099F98C: 174D4406
	v_mul_u32_u24_e32 v162, s7, v162                           // 00000099F990: 17454407
	s_delay_alu instid0(VALU_DEP_1)                            // 00000099F994: BF870001
	v_lshl_add_u32 v162, v162, 24, v166                        // 00000099F998: D64600A2 069931A2
	v_mul_u32_u24_e32 v166, s6, v70                            // 00000099F9A0: 174C8C06
	v_mul_u32_u24_e32 v70, s7, v70                             // 00000099F9A4: 168C8C07
	v_lshl_add_u32 v70, v70, 24, v166                          // 00000099F9A8: D6460046 06993146
	v_and_b32_e32 v67, 0xffff, v67                             // 00000099F9B0: 368686FF 0000FFFF
	v_bfe_u32 v163, v68, 9, 16                                 // 00000099F9B8: D61000A3 02411344
	v_mul_u32_u24_e32 v166, s6, v67                            // 00000099F9C0: 174C8606
	v_mul_u32_u24_e32 v67, s7, v67                             // 00000099F9C4: 16868607
	s_delay_alu instid0(VALU_DEP_2)                            // 00000099F9C8: BF870002
	v_lshl_add_u32 v67, v67, 24, v166                          // 00000099F9CC: D6460043 06993143
	v_mul_u32_u24_e32 v166, s6, v163                           // 00000099F9D4: 174D4606
	v_mul_u32_u24_e32 v163, s7, v163                           // 00000099F9D8: 17474607
	v_lshl_add_u32 v163, v163, 24, v166                        // 00000099F9DC: D64600A3 069931A3
	v_sad_u8 v162, v162, 0, 0x6400                             // 00000099F9E4: D62200A2 03FD01A2 00006400
	v_and_b32_e32 v69, 0xffff, v69                             // 00000099F9F0: 368A8AFF 0000FFFF
	v_sad_u8 v70, v70, 0, 0x6400                               // 00000099F9F8: D6220046 03FD0146 00006400
	v_mul_u32_u24_e32 v166, s6, v164                           // 00000099FA04: 174D4806
	v_mul_u32_u24_e32 v164, s7, v164                           // 00000099FA08: 17494807
	v_lshl_add_u32 v164, v164, 24, v166                        // 00000099FA0C: D64600A4 069931A4
	v_and_b32_e32 v162, 0xffff, v162                           // 00000099FA14: 374544FF 0000FFFF
	v_sad_u8 v67, v67, 0, 0x6400                               // 00000099FA1C: D6220043 03FD0143 00006400
	v_sad_u8 v163, v163, 0, 0x6400                             // 00000099FA28: D62200A3 03FD01A3 00006400
	v_lshl_or_b32 v69, v70, 16, v69                            // 00000099FA34: D6560045 05152146
	v_bfe_u32 v61, v59, 9, 16                                  // 00000099FA3C: D610003D 0241133B
	v_bfe_u32 v62, v59, 6, 16                                  // 00000099FA44: D610003E 02410D3B
	v_lshl_or_b32 v67, v67, 16, v162                           // 00000099FA4C: D6560043 06892143
	v_and_b32_e32 v70, 0xffff, v163                            // 00000099FA54: 368D46FF 0000FFFF
	v_sad_u8 v162, v164, 0, 0x6400                             // 00000099FA5C: D62200A2 03FD01A4 00006400
	v_pk_fma_f16 v69, v69, s8, 0xc931 op_sel_hi:[1,0,0]        // 00000099FA68: CC0E0045 0BFC1145 0000C931
	v_mul_u32_u24_e32 v166, s6, v165                           // 00000099FA74: 174D4A06
	v_pk_fma_f16 v67, v67, s8, 0xc931 op_sel_hi:[1,0,0]        // 00000099FA78: CC0E0043 0BFC1143 0000C931
	v_mul_u32_u24_e32 v165, s7, v165                           // 00000099FA84: 174B4A07
	v_lshl_or_b32 v70, v162, 16, v70                           // 00000099FA88: D6560046 051921A2
	v_dual_dot2acc_f32_f16 v87, v69, v1 :: v_dual_and_b32 v68, 0xffff, v68// 00000099FA90: CB240345 574488FF 0000FFFF
	v_bfe_u32 v69, v63, 9, 16                                  // 00000099FA9C: D6100045 0241133F
	v_lshl_add_u32 v165, v165, 24, v166                        // 00000099FAA4: D64600A5 069931A5
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000099FAAC: BF870214
	v_pk_fma_f16 v64, v70, s8, 0xc931 op_sel_hi:[1,0,0]        // 00000099FAB0: CC0E0040 0BFC1146 0000C931
	v_dot2acc_f32_f16 v87, v67, v2                             // 00000099FABC: 04AE0543
	v_bfe_u32 v70, v63, 6, 16                                  // 00000099FAC0: D6100046 02410D3F
	v_pk_fma_f16 v67, v161, s8, 0xc931 op_sel_hi:[1,0,0]       // 00000099FAC8: CC0E0043 0BFC11A1 0000C931
	v_mul_u32_u24_e32 v161, s6, v70                            // 00000099FAD4: 17428C06
	v_mul_u32_u24_e32 v70, s7, v70                             // 00000099FAD8: 168C8C07
	v_dot2acc_f32_f16 v87, v64, v3                             // 00000099FADC: 04AE0740
	.long 0xd73d0040                                           // 00000099FAE0: D73D0040
	v_cndmask_b32_e32 v1, v92, v65, vcc_lo                     // 00000099FAE4: 0202835C
	v_mul_u32_u24_e32 v65, s6, v69                             // 00000099FAE8: 16828A06
	v_mul_u32_u24_e32 v66, s7, v69                             // 00000099FAEC: 16848A07
	s_delay_alu instid0(VALU_DEP_1)                            // 00000099FAF0: BF870001
	v_lshl_add_u32 v65, v66, 24, v65                           // 00000099FAF4: D6460041 05053142
	v_lshl_add_u32 v70, v70, 24, v161                          // 00000099FAFC: D6460046 06853146
	v_bfe_u32 v66, v63, 3, 16                                  // 00000099FB04: D6100042 0241073F
	v_bfe_u32 v69, v64, 9, 16                                  // 00000099FB0C: D6100045 02411340
	v_mul_u32_u24_e32 v161, s6, v66                            // 00000099FB14: 17428406
	v_sad_u8 v65, v65, 0, 0x6400                               // 00000099FB18: D6220041 03FD0141 00006400
	v_sad_u8 v70, v70, 0, 0x6400                               // 00000099FB24: D6220046 03FD0146 00006400
	v_mul_u32_u24_e32 v66, s7, v66                             // 00000099FB30: 16848407
	v_and_b32_e32 v63, 0xffff, v63                             // 00000099FB34: 367E7EFF 0000FFFF
	v_lshl_add_u32 v66, v66, 24, v161                          // 00000099FB3C: D6460042 06853142
	v_and_b32_e32 v65, 0xffff, v65                             // 00000099FB44: 368282FF 0000FFFF
	v_mul_u32_u24_e32 v161, s6, v69                            // 00000099FB4C: 17428A06
	v_mul_u32_u24_e32 v69, s7, v69                             // 00000099FB50: 168A8A07
	v_bfe_u32 v159, v64, 6, 16                                 // 00000099FB54: D610009F 02410D40
	v_lshl_add_u32 v69, v69, 24, v161                          // 00000099FB5C: D6460045 06853145
	v_lshl_or_b32 v65, v70, 16, v65                            // 00000099FB64: D6560041 05052146
	v_mul_u32_u24_e32 v161, s6, v63                            // 00000099FB6C: 17427E06
	v_mul_u32_u24_e32 v63, s7, v63                             // 00000099FB70: 167E7E07
	v_lshl_add_u32 v63, v63, 24, v161                          // 00000099FB74: D646003F 0685313F
	v_mul_u32_u24_e32 v161, s6, v159                           // 00000099FB7C: 17433E06
	v_pk_fma_f16 v65, v65, s8, 0xc931 op_sel_hi:[1,0,0]        // 00000099FB80: CC0E0041 0BFC1141 0000C931
	v_mul_u32_u24_e32 v159, s7, v159                           // 00000099FB8C: 173F3E07
	v_lshl_add_u32 v159, v159, 24, v161                        // 00000099FB90: D646009F 0685319F
	v_mul_u32_u24_e32 v161, s6, v61                            // 00000099FB98: 17427A06
	v_mul_u32_u24_e32 v61, s7, v61                             // 00000099FB9C: 167A7A07
	v_lshl_add_u32 v61, v61, 24, v161                          // 00000099FBA0: D646003D 0685313D
	v_dot2acc_f32_f16 v86, v65, v1                             // 00000099FBA8: 04AC0341
	v_bfe_u32 v65, v59, 3, 16                                  // 00000099FBAC: D6100041 0241073B
	v_mul_u32_u24_e32 v161, s6, v65                            // 00000099FBB4: 17428206
	v_mul_u32_u24_e32 v65, s7, v65                             // 00000099FBB8: 16828207
	s_delay_alu instid0(VALU_DEP_1)                            // 00000099FBBC: BF870001
	v_lshl_add_u32 v65, v65, 24, v161                          // 00000099FBC0: D6460041 06853141
	v_mul_u32_u24_e32 v161, s6, v62                            // 00000099FBC8: 17427C06
	v_mul_u32_u24_e32 v62, s7, v62                             // 00000099FBCC: 167C7C07
	v_sad_u8 v61, v61, 0, 0x6400                               // 00000099FBD0: D622003D 03FD013D 00006400
	v_lshl_add_u32 v62, v62, 24, v161                          // 00000099FBDC: D646003E 0685313E
	v_and_b32_e32 v59, 0xffff, v59                             // 00000099FBE4: 367676FF 0000FFFF
	v_mul_u32_u24_e32 v161, s6, v59                            // 00000099FBEC: 17427606
	v_mul_u32_u24_e32 v59, s7, v59                             // 00000099FBF0: 16767607
	v_sad_u8 v65, v65, 0, 0x6400                               // 00000099FBF4: D6220041 03FD0141 00006400
	s_delay_alu instid0(VALU_DEP_2)                            // 00000099FC00: BF870002
	v_lshl_add_u32 v59, v59, 24, v161                          // 00000099FC04: D646003B 0685313B
	v_and_b32_e32 v61, 0xffff, v61                             // 00000099FC0C: 367A7AFF 0000FFFF
	v_sad_u8 v62, v62, 0, 0x6400                               // 00000099FC14: D622003E 03FD013E 00006400
	v_sad_u8 v163, v165, 0, 0x6400                             // 00000099FC20: D62200A3 03FD01A5 00006400
	v_and_b32_e32 v65, 0xffff, v65                             // 00000099FC2C: 368282FF 0000FFFF
	v_sad_u8 v59, v59, 0, 0x6400                               // 00000099FC34: D622003B 03FD013B 00006400
	v_sad_u8 v66, v66, 0, 0x6400                               // 00000099FC40: D6220042 03FD0142 00006400
	v_lshl_or_b32 v61, v62, 16, v61                            // 00000099FC4C: D656003D 04F5213E
	v_sad_u8 v69, v69, 0, 0x6400                               // 00000099FC54: D6220045 03FD0145 00006400
	v_sad_u8 v63, v63, 0, 0x6400                               // 00000099FC60: D622003F 03FD013F 00006400
	v_lshl_or_b32 v59, v59, 16, v65                            // 00000099FC6C: D656003B 0505213B
	v_sad_u8 v70, v159, 0, 0x6400                              // 00000099FC74: D6220046 03FD019F 00006400
	v_pk_fma_f16 v61, v61, s8, 0xc931 op_sel_hi:[1,0,0]        // 00000099FC80: CC0E003D 0BFC113D 0000C931
	v_and_b32_e32 v69, 0xffff, v69                             // 00000099FC8C: 368A8AFF 0000FFFF
	v_bfe_u32 v160, v64, 3, 16                                 // 00000099FC94: D61000A0 02410740
	v_pk_fma_f16 v59, v59, s8, 0xc931 op_sel_hi:[1,0,0]        // 00000099FC9C: CC0E003B 0BFC113B 0000C931
	v_mul_u32_u24_e32 v159, s6, v160                           // 00000099FCA8: 173F4006
	v_dual_dot2acc_f32_f16 v85, v61, v1 :: v_dual_and_b32 v162, 0xffff, v163// 00000099FCAC: CB24033D 55A346FF 0000FFFF
	v_and_b32_e32 v64, 0xffff, v64                             // 00000099FCB8: 368080FF 0000FFFF
	v_mul_u32_u24_e32 v160, s7, v160                           // 00000099FCC0: 17414007
	v_lshl_add_u32 v159, v160, 24, v159                        // 00000099FCC4: D646009F 067D31A0
	s_delay_alu instid0(VALU_DEP_3)                            // 00000099FCCC: BF870003
	v_dot2acc_f32_f16 v85, v59, v2                             // 00000099FCD0: 04AA053B
	v_and_b32_e32 v66, 0xffff, v66                             // 00000099FCD4: 368484FF 0000FFFF
	v_bfe_u32 v160, v60, 3, 16                                 // 00000099FCDC: D61000A0 0241073C
	v_dot2acc_f32_f16 v9, v67, v4                              // 00000099FCE4: 04120943
	v_mul_u32_u24_e32 v164, s6, v68                            // 00000099FCE8: 17488806
	v_mul_u32_u24_e32 v68, s7, v68                             // 00000099FCEC: 16888807
	v_lshl_or_b32 v63, v63, 16, v66                            // 00000099FCF0: D656003F 0509213F
	v_lshl_or_b32 v66, v70, 16, v69                            // 00000099FCF8: D6560042 05152146
	v_mul_u32_u24_e32 v70, s6, v64                             // 00000099FD00: 168C8006
	v_mul_u32_u24_e32 v64, s7, v64                             // 00000099FD04: 16808007
	v_lshl_add_u32 v64, v64, 24, v70                           // 00000099FD08: D6460040 05193140
	v_bfe_u32 v70, v60, 9, 16                                  // 00000099FD10: D6100046 0241133C
	v_mul_u32_u24_e32 v161, s6, v70                            // 00000099FD18: 17428C06
	v_mul_u32_u24_e32 v70, s7, v70                             // 00000099FD1C: 168C8C07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000099FD20: BF8700D1
	v_lshl_add_u32 v70, v70, 24, v161                          // 00000099FD24: D6460046 06853146
	v_sad_u8 v69, v159, 0, 0x6400                              // 00000099FD2C: D6220045 03FD019F 00006400
	v_bfe_u32 v159, v60, 6, 16                                 // 00000099FD38: D610009F 02410D3C
	v_mul_u32_u24_e32 v161, s6, v159                           // 00000099FD40: 17433E06
	v_mul_u32_u24_e32 v159, s7, v159                           // 00000099FD44: 173F3E07
	v_lshl_add_u32 v159, v159, 24, v161                        // 00000099FD48: D646009F 0685319F
	v_mul_u32_u24_e32 v161, s6, v160                           // 00000099FD50: 17434006
	v_mul_u32_u24_e32 v160, s7, v160                           // 00000099FD54: 17414007
	v_sad_u8 v70, v70, 0, 0x6400                               // 00000099FD58: D6220046 03FD0146 00006400
	v_lshl_add_u32 v160, v160, 24, v161                        // 00000099FD64: D64600A0 068531A0
	v_and_b32_e32 v60, 0xffff, v60                             // 00000099FD6C: 367878FF 0000FFFF
	v_sad_u8 v65, v159, 0, 0x6400                              // 00000099FD74: D6220041 03FD019F 00006400
	v_mul_u32_u24_e32 v159, s6, v60                            // 00000099FD80: 173E7806
	v_mul_u32_u24_e32 v60, s7, v60                             // 00000099FD84: 16787807
	v_and_b32_e32 v62, 0xffff, v70                             // 00000099FD88: 367C8CFF 0000FFFF
	v_sad_u8 v70, v160, 0, 0x6400                              // 00000099FD90: D6220046 03FD01A0 00006400
	v_lshl_add_u32 v60, v60, 24, v159                          // 00000099FD9C: D646003C 067D313C
	v_pk_fma_f16 v63, v63, s8, 0xc931 op_sel_hi:[1,0,0]        // 00000099FDA4: CC0E003F 0BFC113F 0000C931
	v_and_b32_e32 v69, 0xffff, v69                             // 00000099FDB0: 368A8AFF 0000FFFF
	v_sad_u8 v64, v64, 0, 0x6400                               // 00000099FDB8: D6220040 03FD0140 00006400
	v_lshl_or_b32 v62, v65, 16, v62                            // 00000099FDC4: D656003E 04F92141
	v_and_b32_e32 v65, 0xffff, v70                             // 00000099FDCC: 36828CFF 0000FFFF
	v_sad_u8 v60, v60, 0, 0x6400                               // 00000099FDD4: D622003C 03FD013C 00006400
	v_pk_fma_f16 v66, v66, s8, 0xc931 op_sel_hi:[1,0,0]        // 00000099FDE0: CC0E0042 0BFC1142 0000C931
	v_lshl_or_b32 v61, v64, 16, v69                            // 00000099FDEC: D656003D 05152140
	v_dot2acc_f32_f16 v86, v63, v2                             // 00000099FDF4: 04AC053F
	v_pk_fma_f16 v62, v62, s8, 0xc931 op_sel_hi:[1,0,0]        // 00000099FDF8: CC0E003E 0BFC113E 0000C931
	v_lshl_or_b32 v60, v60, 16, v65                            // 00000099FE04: D656003C 0505213C
	v_lshl_add_u32 v68, v68, 24, v164                          // 00000099FE0C: D6460044 06913144
	.long 0xd73d0037                                           // 00000099FE14: D73D0037
	v_cndmask_b32_e32 v1, v90, v55, vcc_lo                     // 00000099FE18: 02026F5A
	v_pk_fma_f16 v59, v61, s8, 0xc931 op_sel_hi:[1,0,0]        // 00000099FE1C: CC0E003B 0BFC113D 0000C931
	v_dot2acc_f32_f16 v86, v66, v3                             // 00000099FE28: 04AC0742
	v_pk_fma_f16 v56, v60, s8, 0xc931 op_sel_hi:[1,0,0]        // 00000099FE2C: CC0E0038 0BFC113C 0000C931
	v_dot2acc_f32_f16 v85, v62, v3                             // 00000099FE38: 04AA073E
	v_sad_u8 v68, v68, 0, 0x6400                               // 00000099FE3C: D6220044 03FD0144 00006400
	v_bfe_u32 v60, v55, 6, 16                                  // 00000099FE48: D610003C 02410D37
	v_dot2acc_f32_f16 v86, v59, v4                             // 00000099FE50: 04AC093B
	v_bfe_u32 v59, v55, 9, 16                                  // 00000099FE54: D610003B 02411337
	v_dot2acc_f32_f16 v85, v56, v4                             // 00000099FE5C: 04AA0938
	s_waitcnt vmcnt(35)                                        // 00000099FE60: BF898FF7
	.long 0xd73d0038                                           // 00000099FE64: D73D0038
	v_cndmask_b32_e32 v1, v92, v57, vcc_lo                     // 00000099FE68: 0202735C
	v_mul_u32_u24_e32 v58, s6, v59                             // 00000099FE6C: 16747606
	v_lshl_or_b32 v68, v68, 16, v162                           // 00000099FE70: D6560044 06892144
	v_mul_u32_u24_e32 v59, s7, v59                             // 00000099FE78: 16767607
	v_lshl_add_u32 v58, v59, 24, v58                           // 00000099FE7C: D646003A 04E9313B
	v_bfe_u32 v57, v55, 3, 16                                  // 00000099FE84: D6100039 02410737
	v_mul_u32_u24_e32 v63, s6, v60                             // 00000099FE8C: 167E7806
	v_mul_u32_u24_e32 v60, s7, v60                             // 00000099FE90: 16787807
	v_pk_fma_f16 v68, v68, s8, 0xc931 op_sel_hi:[1,0,0]        // 00000099FE94: CC0E0044 0BFC1144 0000C931
	v_bfe_u32 v59, v56, 9, 16                                  // 00000099FEA0: D610003B 02411338
	v_sad_u8 v58, v58, 0, 0x6400                               // 00000099FEA8: D622003A 03FD013A 00006400
	v_lshl_add_u32 v60, v60, 24, v63                           // 00000099FEB4: D646003C 04FD313C
	v_mul_u32_u24_e32 v63, s6, v57                             // 00000099FEBC: 167E7206
	v_mul_u32_u24_e32 v57, s7, v57                             // 00000099FEC0: 16727207
	v_lshl_add_u32 v57, v57, 24, v63                           // 00000099FEC4: D6460039 04FD3139
	v_mul_u32_u24_e32 v63, s6, v59                             // 00000099FECC: 167E7606
	v_mul_u32_u24_e32 v59, s7, v59                             // 00000099FED0: 16767607
	v_lshl_add_u32 v59, v59, 24, v63                           // 00000099FED4: D646003B 04FD313B
	v_and_b32_e32 v55, 0xffff, v55                             // 00000099FEDC: 366E6EFF 0000FFFF
	v_bfe_u32 v61, v56, 6, 16                                  // 00000099FEE4: D610003D 02410D38
	v_mul_u32_u24_e32 v63, s6, v55                             // 00000099FEEC: 167E6E06
	v_mul_u32_u24_e32 v55, s7, v55                             // 00000099FEF0: 166E6E07
	v_dual_dot2acc_f32_f16 v87, v68, v4 :: v_dual_and_b32 v58, 0xffff, v58// 00000099FEF4: CB240944 573A74FF 0000FFFF
	v_bfe_u32 v62, v56, 3, 16                                  // 00000099FF00: D610003E 02410738
	v_sad_u8 v60, v60, 0, 0x6400                               // 00000099FF08: D622003C 03FD013C 00006400
	v_lshl_add_u32 v55, v55, 24, v63                           // 00000099FF14: D6460037 04FD3137
	v_mul_u32_u24_e32 v63, s6, v61                             // 00000099FF1C: 167E7A06
	v_mul_u32_u24_e32 v61, s7, v61                             // 00000099FF20: 167A7A07
	v_lshl_add_u32 v61, v61, 24, v63                           // 00000099FF24: D646003D 04FD313D
	v_mul_u32_u24_e32 v63, s6, v62                             // 00000099FF2C: 167E7C06
	v_mul_u32_u24_e32 v62, s7, v62                             // 00000099FF30: 167C7C07
	v_sad_u8 v57, v57, 0, 0x6400                               // 00000099FF34: D6220039 03FD0139 00006400
	v_sad_u8 v59, v59, 0, 0x6400                               // 00000099FF40: D622003B 03FD013B 00006400
	v_lshl_add_u32 v62, v62, 24, v63                           // 00000099FF4C: D646003E 04FD313E
	v_lshl_or_b32 v58, v60, 16, v58                            // 00000099FF54: D656003A 04E9213C
	.long 0xd73d0033                                           // 00000099FF5C: D73D0033
	v_cndmask_b32_e32 v1, v90, v51, vcc_lo                     // 00000099FF60: 0202675A
	v_and_b32_e32 v57, 0xffff, v57                             // 00000099FF64: 367272FF 0000FFFF
	v_sad_u8 v55, v55, 0, 0x6400                               // 00000099FF6C: D6220037 03FD0137 00006400
	v_and_b32_e32 v59, 0xffff, v59                             // 00000099FF78: 367676FF 0000FFFF
	v_sad_u8 v61, v61, 0, 0x6400                               // 00000099FF80: D622003D 03FD013D 00006400
	v_sad_u8 v62, v62, 0, 0x6400                               // 00000099FF8C: D622003E 03FD013E 00006400
	v_pk_fma_f16 v58, v58, s8, 0xc931 op_sel_hi:[1,0,0]        // 00000099FF98: CC0E003A 0BFC113A 0000C931
	s_waitcnt vmcnt(34)                                        // 00000099FFA4: BF898BF7
	.long 0xd73d0034                                           // 00000099FFA8: D73D0034
	v_cndmask_b32_e32 v1, v92, v53, vcc_lo                     // 00000099FFAC: 02026B5C
	v_bfe_u32 v53, v51, 9, 16                                  // 00000099FFB0: D6100035 02411333
	v_lshl_or_b32 v55, v55, 16, v57                            // 00000099FFB8: D6560037 04E52137
	v_lshl_or_b32 v57, v61, 16, v59                            // 00000099FFC0: D6560039 04ED213D
	v_and_b32_e32 v59, 0xffff, v62                             // 00000099FFC8: 36767CFF 0000FFFF
	v_mul_u32_u24_e32 v62, s6, v53                             // 00000099FFD0: 167C6A06
	v_mul_u32_u24_e32 v53, s7, v53                             // 00000099FFD4: 166A6A07
	v_lshl_add_u32 v53, v53, 24, v62                           // 00000099FFD8: D6460035 04F93135
	v_dot2acc_f32_f16 v84, v58, v1                             // 00000099FFE0: 04A8033A
	v_bfe_u32 v58, v51, 3, 16                                  // 00000099FFE4: D610003A 02410733
	v_bfe_u32 v54, v51, 6, 16                                  // 00000099FFEC: D6100036 02410D33
	v_mul_u32_u24_e32 v62, s6, v58                             // 00000099FFF4: 167C7406
	v_mul_u32_u24_e32 v58, s7, v58                             // 00000099FFF8: 16747407
	s_delay_alu instid0(VALU_DEP_2)                            // 00000099FFFC: BF870002
	v_lshl_add_u32 v58, v58, 24, v62                           // 0000009A0000: D646003A 04F9313A
	v_mul_u32_u24_e32 v62, s6, v54                             // 0000009A0008: 167C6C06
	v_mul_u32_u24_e32 v54, s7, v54                             // 0000009A000C: 166C6C07
	v_sad_u8 v53, v53, 0, 0x6400                               // 0000009A0010: D6220035 03FD0135 00006400
	v_lshl_add_u32 v54, v54, 24, v62                           // 0000009A001C: D6460036 04F93136
	v_and_b32_e32 v51, 0xffff, v51                             // 0000009A0024: 366666FF 0000FFFF
	v_mul_u32_u24_e32 v62, s6, v51                             // 0000009A002C: 167C6606
	v_mul_u32_u24_e32 v51, s7, v51                             // 0000009A0030: 16666607
	v_sad_u8 v58, v58, 0, 0x6400                               // 0000009A0034: D622003A 03FD013A 00006400
	s_delay_alu instid0(VALU_DEP_2)                            // 0000009A0040: BF870002
	v_lshl_add_u32 v51, v51, 24, v62                           // 0000009A0044: D6460033 04F93133
	v_and_b32_e32 v53, 0xffff, v53                             // 0000009A004C: 366A6AFF 0000FFFF
	v_sad_u8 v54, v54, 0, 0x6400                               // 0000009A0054: D6220036 03FD0136 00006400
	v_bfe_u32 v60, v52, 6, 16                                  // 0000009A0060: D610003C 02410D34
	v_and_b32_e32 v58, 0xffff, v58                             // 0000009A0068: 367474FF 0000FFFF
	v_sad_u8 v51, v51, 0, 0x6400                               // 0000009A0070: D6220033 03FD0133 00006400
	.long 0xd73d002f                                           // 0000009A007C: D73D002F
	v_cndmask_b32_e32 v1, v90, v47, vcc_lo                     // 0000009A0080: 02025F5A
	v_lshl_or_b32 v53, v54, 16, v53                            // 0000009A0084: D6560035 04D52136
	v_pk_fma_f16 v55, v55, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000009A008C: CC0E0037 0BFC1137 0000C931
	v_bfe_u32 v61, v52, 3, 16                                  // 0000009A0098: D610003D 02410734
	v_lshl_or_b32 v51, v51, 16, v58                            // 0000009A00A0: D6560033 04E92133
	v_pk_fma_f16 v57, v57, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000009A00A8: CC0E0039 0BFC1139 0000C931
	v_pk_fma_f16 v53, v53, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000009A00B4: CC0E0035 0BFC1135 0000C931
	v_dot2acc_f32_f16 v84, v55, v2                             // 0000009A00C0: 04A80537
	.long 0xd73d002b                                           // 0000009A00C4: D73D002B
	v_cndmask_b32_e32 v1, v90, v43, vcc_lo                     // 0000009A00C8: 0202575A
	v_pk_fma_f16 v51, v51, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000009A00CC: CC0E0033 0BFC1133 0000C931
	s_waitcnt vmcnt(32)                                        // 0000009A00D8: BF8983F7
	.long 0xd73d002c                                           // 0000009A00DC: D73D002C
	v_cndmask_b32_e32 v1, v92, v45, vcc_lo                     // 0000009A00E0: 02025B5C
	v_dual_dot2acc_f32_f16 v83, v53, v1 :: v_dual_and_b32 v56, 0xffff, v56// 0000009A00E4: CB240335 533870FF 0000FFFF
	v_bfe_u32 v53, v47, 9, 16                                  // 0000009A00F0: D6100035 0241132F
	v_dot2acc_f32_f16 v84, v57, v3                             // 0000009A00F8: 04A80739
	v_bfe_u32 v45, v43, 9, 16                                  // 0000009A00FC: D610002D 0241132B
	s_delay_alu instid0(VALU_DEP_4)                            // 0000009A0104: BF870004
	v_dot2acc_f32_f16 v83, v51, v2                             // 0000009A0108: 04A60533
	v_mul_u32_u24_e32 v63, s6, v56                             // 0000009A010C: 167E7006
	v_mul_u32_u24_e32 v56, s7, v56                             // 0000009A0110: 16707007
	v_lshl_add_u32 v56, v56, 24, v63                           // 0000009A0114: D6460038 04FD3138
	v_bfe_u32 v46, v43, 6, 16                                  // 0000009A011C: D610002E 02410D2B
	s_waitcnt vmcnt(23)                                        // 0000009A0124: BF895FF7
	.long 0xd73d0027                                           // 0000009A0128: D73D0027
	v_cndmask_b32_e32 v1, v90, v39, vcc_lo                     // 0000009A012C: 02024F5A
	s_waitcnt vmcnt(22)                                        // 0000009A0130: BF895BF7
	.long 0xd73d0023                                           // 0000009A0134: D73D0023
	v_cndmask_b32_e32 v1, v90, v35, vcc_lo                     // 0000009A0138: 0202475A
	s_waitcnt vmcnt(6)                                         // 0000009A013C: BF891BF7
	.long 0xd73d0024                                           // 0000009A0140: D73D0024
	v_cndmask_b32_e32 v1, v92, v37, vcc_lo                     // 0000009A0144: 02024B5C
	v_sad_u8 v56, v56, 0, 0x6400                               // 0000009A0148: D6220038 03FD0138 00006400
	.long 0xd73d001f                                           // 0000009A0154: D73D001F
	v_cndmask_b32_e32 v1, v90, v31, vcc_lo                     // 0000009A0158: 02023F5A
	.long 0xd73d001b                                           // 0000009A015C: D73D001B
	v_cndmask_b32_e32 v1, v90, v27, vcc_lo                     // 0000009A0160: 0202375A
	s_waitcnt vmcnt(4)                                         // 0000009A0164: BF8913F7
	.long 0xd73d001c                                           // 0000009A0168: D73D001C
	v_cndmask_b32_e32 v1, v92, v29, vcc_lo                     // 0000009A016C: 02023B5C
	v_bfe_u32 v37, v35, 9, 16                                  // 0000009A0170: D6100025 02411323
	v_lshl_or_b32 v56, v56, 16, v59                            // 0000009A0178: D6560038 04ED2138
	v_bfe_u32 v59, v52, 9, 16                                  // 0000009A0180: D610003B 02411334
	v_mul_u32_u24_e32 v62, s6, v59                             // 0000009A0188: 167C7606
	v_mul_u32_u24_e32 v59, s7, v59                             // 0000009A018C: 16767607
	s_delay_alu instid0(VALU_DEP_1)                            // 0000009A0190: BF870001
	v_lshl_add_u32 v59, v59, 24, v62                           // 0000009A0194: D646003B 04F9313B
	v_mul_u32_u24_e32 v62, s6, v60                             // 0000009A019C: 167C7806
	v_mul_u32_u24_e32 v60, s7, v60                             // 0000009A01A0: 16787807
	v_lshl_add_u32 v60, v60, 24, v62                           // 0000009A01A4: D646003C 04F9313C
	v_mul_u32_u24_e32 v62, s6, v61                             // 0000009A01AC: 167C7A06
	v_sad_u8 v59, v59, 0, 0x6400                               // 0000009A01B0: D622003B 03FD013B 00006400
	v_mul_u32_u24_e32 v61, s7, v61                             // 0000009A01BC: 167A7A07
	v_lshl_add_u32 v61, v61, 24, v62                           // 0000009A01C0: D646003D 04F9313D
	v_sad_u8 v58, v60, 0, 0x6400                               // 0000009A01C8: D622003A 03FD013C 00006400
	v_pk_fma_f16 v51, v56, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000009A01D4: CC0E0033 0BFC1138 0000C931
	v_and_b32_e32 v54, 0xffff, v59                             // 0000009A01E0: 366C76FF 0000FFFF
	v_bfe_u32 v38, v35, 6, 16                                  // 0000009A01E8: D6100026 02410D23
	v_sad_u8 v59, v61, 0, 0x6400                               // 0000009A01F0: D622003B 03FD013D 00006400
	v_bfe_u32 v29, v27, 9, 16                                  // 0000009A01FC: D610001D 0241131B
	v_bfe_u32 v30, v27, 6, 16                                  // 0000009A0204: D610001E 02410D1B
	v_lshl_or_b32 v54, v58, 16, v54                            // 0000009A020C: D6560036 04D9213A
	.long 0xd73d0015                                           // 0000009A0214: D73D0015
	v_cndmask_b32_e32 v1, v90, v21, vcc_lo                     // 0000009A0218: 02022B5A
	.long 0xd73d0011                                           // 0000009A021C: D73D0011
	v_cndmask_b32_e32 v1, v90, v17, vcc_lo                     // 0000009A0220: 0202235A
	s_waitcnt vmcnt(2)                                         // 0000009A0224: BF890BF7
	.long 0xd73d0012                                           // 0000009A0228: D73D0012
	v_cndmask_b32_e32 v1, v92, v19, vcc_lo                     // 0000009A022C: 0202275C
	.long 0xd73d000b                                           // 0000009A0230: D73D000B
	v_cndmask_b32_e32 v1, v90, v11, vcc_lo                     // 0000009A0234: 0202175A
	v_pk_fma_f16 v48, v54, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000009A0238: CC0E0030 0BFC1136 0000C931
	v_and_b32_e32 v52, 0xffff, v52                             // 0000009A0244: 366868FF 0000FFFF
	v_bfe_u32 v54, v47, 6, 16                                  // 0000009A024C: D6100036 02410D2F
	v_mul_u32_u24_e32 v57, s6, v54                             // 0000009A0254: 16726C06
	v_mul_u32_u24_e32 v54, s7, v54                             // 0000009A0258: 166C6C07
	v_dot2acc_f32_f16 v83, v48, v3                             // 0000009A025C: 04A60730
	.long 0xd73d0030                                           // 0000009A0260: D73D0030
	v_cndmask_b32_e32 v1, v92, v49, vcc_lo                     // 0000009A0264: 0202635C
	v_mul_u32_u24_e32 v49, s6, v53                             // 0000009A0268: 16626A06
	v_mul_u32_u24_e32 v50, s7, v53                             // 0000009A026C: 16646A07
	s_delay_alu instid0(VALU_DEP_1)                            // 0000009A0270: BF870001
	v_lshl_add_u32 v49, v50, 24, v49                           // 0000009A0274: D6460031 04C53132
	v_lshl_add_u32 v54, v54, 24, v57                           // 0000009A027C: D6460036 04E53136
	v_bfe_u32 v50, v47, 3, 16                                  // 0000009A0284: D6100032 0241072F
	v_bfe_u32 v53, v48, 9, 16                                  // 0000009A028C: D6100035 02411330
	v_mul_u32_u24_e32 v57, s6, v50                             // 0000009A0294: 16726406
	v_sad_u8 v49, v49, 0, 0x6400                               // 0000009A0298: D6220031 03FD0131 00006400
	v_sad_u8 v54, v54, 0, 0x6400                               // 0000009A02A4: D6220036 03FD0136 00006400
	v_mul_u32_u24_e32 v50, s7, v50                             // 0000009A02B0: 16646407
	v_and_b32_e32 v47, 0xffff, v47                             // 0000009A02B4: 365E5EFF 0000FFFF
	v_lshl_add_u32 v50, v50, 24, v57                           // 0000009A02BC: D6460032 04E53132
	v_and_b32_e32 v49, 0xffff, v49                             // 0000009A02C4: 366262FF 0000FFFF
	v_mul_u32_u24_e32 v57, s6, v53                             // 0000009A02CC: 16726A06
	v_mul_u32_u24_e32 v53, s7, v53                             // 0000009A02D0: 166A6A07
	v_bfe_u32 v55, v48, 6, 16                                  // 0000009A02D4: D6100037 02410D30
	v_lshl_add_u32 v53, v53, 24, v57                           // 0000009A02DC: D6460035 04E53135
	v_lshl_or_b32 v49, v54, 16, v49                            // 0000009A02E4: D6560031 04C52136
	v_mul_u32_u24_e32 v57, s6, v47                             // 0000009A02EC: 16725E06
	v_mul_u32_u24_e32 v47, s7, v47                             // 0000009A02F0: 165E5E07
	v_lshl_add_u32 v47, v47, 24, v57                           // 0000009A02F4: D646002F 04E5312F
	v_mul_u32_u24_e32 v57, s6, v55                             // 0000009A02FC: 16726E06
	v_pk_fma_f16 v49, v49, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000009A0300: CC0E0031 0BFC1131 0000C931
	v_mul_u32_u24_e32 v55, s7, v55                             // 0000009A030C: 166E6E07
	v_lshl_add_u32 v55, v55, 24, v57                           // 0000009A0310: D6460037 04E53137
	v_mul_u32_u24_e32 v57, s6, v45                             // 0000009A0318: 16725A06
	v_mul_u32_u24_e32 v45, s7, v45                             // 0000009A031C: 165A5A07
	v_lshl_add_u32 v45, v45, 24, v57                           // 0000009A0320: D646002D 04E5312D
	v_dot2acc_f32_f16 v82, v49, v1                             // 0000009A0328: 04A40331
	v_bfe_u32 v49, v43, 3, 16                                  // 0000009A032C: D6100031 0241072B
	v_mul_u32_u24_e32 v57, s6, v49                             // 0000009A0334: 16726206
	v_mul_u32_u24_e32 v49, s7, v49                             // 0000009A0338: 16626207
	s_delay_alu instid0(VALU_DEP_1)                            // 0000009A033C: BF870001
	v_lshl_add_u32 v49, v49, 24, v57                           // 0000009A0340: D6460031 04E53131
	v_mul_u32_u24_e32 v57, s6, v46                             // 0000009A0348: 16725C06
	v_mul_u32_u24_e32 v46, s7, v46                             // 0000009A034C: 165C5C07
	v_sad_u8 v45, v45, 0, 0x6400                               // 0000009A0350: D622002D 03FD012D 00006400
	v_lshl_add_u32 v46, v46, 24, v57                           // 0000009A035C: D646002E 04E5312E
	v_and_b32_e32 v43, 0xffff, v43                             // 0000009A0364: 365656FF 0000FFFF
	v_mul_u32_u24_e32 v57, s6, v43                             // 0000009A036C: 16725606
	v_mul_u32_u24_e32 v43, s7, v43                             // 0000009A0370: 16565607
	v_sad_u8 v49, v49, 0, 0x6400                               // 0000009A0374: D6220031 03FD0131 00006400
	s_delay_alu instid0(VALU_DEP_2)                            // 0000009A0380: BF870002
	v_lshl_add_u32 v43, v43, 24, v57                           // 0000009A0384: D646002B 04E5312B
	v_and_b32_e32 v45, 0xffff, v45                             // 0000009A038C: 365A5AFF 0000FFFF
	v_sad_u8 v46, v46, 0, 0x6400                               // 0000009A0394: D622002E 03FD012E 00006400
	v_sad_u8 v50, v50, 0, 0x6400                               // 0000009A03A0: D6220032 03FD0132 00006400
	v_and_b32_e32 v49, 0xffff, v49                             // 0000009A03AC: 366262FF 0000FFFF
	v_sad_u8 v43, v43, 0, 0x6400                               // 0000009A03B4: D622002B 03FD012B 00006400
	v_sad_u8 v53, v53, 0, 0x6400                               // 0000009A03C0: D6220035 03FD0135 00006400
	v_lshl_or_b32 v45, v46, 16, v45                            // 0000009A03CC: D656002D 04B5212E
	v_sad_u8 v47, v47, 0, 0x6400                               // 0000009A03D4: D622002F 03FD012F 00006400
	v_sad_u8 v54, v55, 0, 0x6400                               // 0000009A03E0: D6220036 03FD0137 00006400
	v_lshl_or_b32 v43, v43, 16, v49                            // 0000009A03EC: D656002B 04C5212B
	v_and_b32_e32 v53, 0xffff, v53                             // 0000009A03F4: 366A6AFF 0000FFFF
	v_pk_fma_f16 v45, v45, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000009A03FC: CC0E002D 0BFC112D 0000C931
	v_mul_u32_u24_e32 v60, s6, v52                             // 0000009A0408: 16786806
	v_mul_u32_u24_e32 v52, s7, v52                             // 0000009A040C: 16686807
	v_pk_fma_f16 v43, v43, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000009A0410: CC0E002B 0BFC112B 0000C931
	v_lshl_add_u32 v52, v52, 24, v60                           // 0000009A041C: D6460034 04F13134
	v_dual_dot2acc_f32_f16 v81, v45, v1 :: v_dual_and_b32 v58, 0xffff, v59// 0000009A0424: CB24032D 513A76FF 0000FFFF
	v_bfe_u32 v56, v48, 3, 16                                  // 0000009A0430: D6100038 02410730
	v_mul_u32_u24_e32 v55, s6, v56                             // 0000009A0438: 166E7006
	s_delay_alu instid0(VALU_DEP_2)                            // 0000009A043C: BF870002
	v_dual_dot2acc_f32_f16 v81, v43, v2 :: v_dual_and_b32 v48, 0xffff, v48// 0000009A0440: CB24052B 513060FF 0000FFFF
	v_and_b32_e32 v50, 0xffff, v50                             // 0000009A044C: 366464FF 0000FFFF
	v_mul_u32_u24_e32 v56, s7, v56                             // 0000009A0454: 16707007
	v_lshl_add_u32 v55, v56, 24, v55                           // 0000009A0458: D6460037 04DD3138
	v_sad_u8 v52, v52, 0, 0x6400                               // 0000009A0460: D6220034 03FD0134 00006400
	v_bfe_u32 v56, v44, 3, 16                                  // 0000009A046C: D6100038 0241072C
	v_lshl_or_b32 v47, v47, 16, v50                            // 0000009A0474: D656002F 04C9212F
	v_lshl_or_b32 v50, v54, 16, v53                            // 0000009A047C: D6560032 04D52136
	v_mul_u32_u24_e32 v54, s6, v48                             // 0000009A0484: 166C6006
	v_mul_u32_u24_e32 v48, s7, v48                             // 0000009A0488: 16606007
	v_lshl_add_u32 v48, v48, 24, v54                           // 0000009A048C: D6460030 04D93130
	v_bfe_u32 v54, v44, 9, 16                                  // 0000009A0494: D6100036 0241132C
	v_mul_u32_u24_e32 v57, s6, v54                             // 0000009A049C: 16726C06
	v_mul_u32_u24_e32 v54, s7, v54                             // 0000009A04A0: 166C6C07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000009A04A4: BF8700D1
	v_lshl_add_u32 v54, v54, 24, v57                           // 0000009A04A8: D6460036 04E53136
	v_sad_u8 v53, v55, 0, 0x6400                               // 0000009A04B0: D6220035 03FD0137 00006400
	v_bfe_u32 v55, v44, 6, 16                                  // 0000009A04BC: D6100037 02410D2C
	v_mul_u32_u24_e32 v57, s6, v55                             // 0000009A04C4: 16726E06
	v_mul_u32_u24_e32 v55, s7, v55                             // 0000009A04C8: 166E6E07
	v_lshl_add_u32 v55, v55, 24, v57                           // 0000009A04CC: D6460037 04E53137
	v_mul_u32_u24_e32 v57, s6, v56                             // 0000009A04D4: 16727006
	v_mul_u32_u24_e32 v56, s7, v56                             // 0000009A04D8: 16707007
	v_lshl_or_b32 v52, v52, 16, v58                            // 0000009A04DC: D6560034 04E92134
	v_sad_u8 v54, v54, 0, 0x6400                               // 0000009A04E4: D6220036 03FD0136 00006400
	v_lshl_add_u32 v56, v56, 24, v57                           // 0000009A04F0: D6460038 04E53138
	v_and_b32_e32 v44, 0xffff, v44                             // 0000009A04F8: 365858FF 0000FFFF
	v_sad_u8 v49, v55, 0, 0x6400                               // 0000009A0500: D6220031 03FD0137 00006400
	v_mul_u32_u24_e32 v55, s6, v44                             // 0000009A050C: 166E5806
	v_mul_u32_u24_e32 v44, s7, v44                             // 0000009A0510: 16585807
	v_pk_fma_f16 v52, v52, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000009A0514: CC0E0034 0BFC1134 0000C931
	v_and_b32_e32 v46, 0xffff, v54                             // 0000009A0520: 365C6CFF 0000FFFF
	v_sad_u8 v54, v56, 0, 0x6400                               // 0000009A0528: D6220036 03FD0138 00006400
	v_lshl_add_u32 v44, v44, 24, v55                           // 0000009A0534: D646002C 04DD312C
	v_pk_fma_f16 v47, v47, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000009A053C: CC0E002F 0BFC112F 0000C931
	v_and_b32_e32 v53, 0xffff, v53                             // 0000009A0548: 366A6AFF 0000FFFF
	v_sad_u8 v48, v48, 0, 0x6400                               // 0000009A0550: D6220030 03FD0130 00006400
	v_dot2acc_f32_f16 v83, v52, v4                             // 0000009A055C: 04A60934
	v_lshl_or_b32 v46, v49, 16, v46                            // 0000009A0560: D656002E 04B92131
	v_and_b32_e32 v49, 0xffff, v54                             // 0000009A0568: 36626CFF 0000FFFF
	v_sad_u8 v44, v44, 0, 0x6400                               // 0000009A0570: D622002C 03FD012C 00006400
	v_pk_fma_f16 v50, v50, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000009A057C: CC0E0032 0BFC1132 0000C931
	v_lshl_or_b32 v45, v48, 16, v53                            // 0000009A0588: D656002D 04D52130
	v_dot2acc_f32_f16 v82, v47, v2                             // 0000009A0590: 04A4052F
	v_pk_fma_f16 v46, v46, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000009A0594: CC0E002E 0BFC112E 0000C931
	v_lshl_or_b32 v44, v44, 16, v49                            // 0000009A05A0: D656002C 04C5212C
	v_bfe_u32 v19, v17, 9, 16                                  // 0000009A05A8: D6100013 02411311
	v_pk_fma_f16 v43, v45, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000009A05B0: CC0E002B 0BFC112D 0000C931
	v_dot2acc_f32_f16 v82, v50, v3                             // 0000009A05BC: 04A40732
	v_dot2acc_f32_f16 v81, v46, v3                             // 0000009A05C0: 04A2072E
	v_pk_fma_f16 v40, v44, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000009A05C4: CC0E0028 0BFC112C 0000C931
	v_bfe_u32 v44, v39, 6, 16                                  // 0000009A05D0: D610002C 02410D27
	v_mul_u32_u24_e32 v47, s6, v44                             // 0000009A05D8: 165E5806
	v_dot2acc_f32_f16 v82, v43, v4                             // 0000009A05DC: 04A4092B
	v_bfe_u32 v43, v39, 9, 16                                  // 0000009A05E0: D610002B 02411327
	v_dot2acc_f32_f16 v81, v40, v4                             // 0000009A05E8: 04A20928
	.long 0xd73d0028                                           // 0000009A05EC: D73D0028
	v_cndmask_b32_e32 v1, v92, v41, vcc_lo                     // 0000009A05F0: 0202535C
	v_mul_u32_u24_e32 v42, s6, v43                             // 0000009A05F4: 16545606
	v_mul_u32_u24_e32 v43, s7, v43                             // 0000009A05F8: 16565607
	v_lshl_add_u32 v42, v43, 24, v42                           // 0000009A05FC: D646002A 04A9312B
	v_bfe_u32 v41, v39, 3, 16                                  // 0000009A0604: D6100029 02410727
	v_mul_u32_u24_e32 v44, s7, v44                             // 0000009A060C: 16585807
	v_bfe_u32 v43, v40, 9, 16                                  // 0000009A0610: D610002B 02411328
	v_lshl_add_u32 v44, v44, 24, v47                           // 0000009A0618: D646002C 04BD312C
	v_sad_u8 v42, v42, 0, 0x6400                               // 0000009A0620: D622002A 03FD012A 00006400
	v_mul_u32_u24_e32 v47, s6, v41                             // 0000009A062C: 165E5206
	v_mul_u32_u24_e32 v41, s7, v41                             // 0000009A0630: 16525207
	v_lshl_add_u32 v41, v41, 24, v47                           // 0000009A0634: D6460029 04BD3129
	v_mul_u32_u24_e32 v47, s6, v43                             // 0000009A063C: 165E5606
	v_mul_u32_u24_e32 v43, s7, v43                             // 0000009A0640: 16565607
	v_lshl_add_u32 v43, v43, 24, v47                           // 0000009A0644: D646002B 04BD312B
	v_and_b32_e32 v39, 0xffff, v39                             // 0000009A064C: 364E4EFF 0000FFFF
	v_bfe_u32 v45, v40, 6, 16                                  // 0000009A0654: D610002D 02410D28
	v_mul_u32_u24_e32 v47, s6, v39                             // 0000009A065C: 165E4E06
	v_mul_u32_u24_e32 v39, s7, v39                             // 0000009A0660: 164E4E07
	v_bfe_u32 v46, v40, 3, 16                                  // 0000009A0664: D610002E 02410728
	v_and_b32_e32 v42, 0xffff, v42                             // 0000009A066C: 365454FF 0000FFFF
	v_sad_u8 v44, v44, 0, 0x6400                               // 0000009A0674: D622002C 03FD012C 00006400
	v_lshl_add_u32 v39, v39, 24, v47                           // 0000009A0680: D6460027 04BD3127
	v_mul_u32_u24_e32 v47, s6, v45                             // 0000009A0688: 165E5A06
	v_mul_u32_u24_e32 v45, s7, v45                             // 0000009A068C: 165A5A07
	v_lshl_add_u32 v45, v45, 24, v47                           // 0000009A0690: D646002D 04BD312D
	v_mul_u32_u24_e32 v47, s6, v46                             // 0000009A0698: 165E5C06
	v_mul_u32_u24_e32 v46, s7, v46                             // 0000009A069C: 165C5C07
	v_sad_u8 v41, v41, 0, 0x6400                               // 0000009A06A0: D6220029 03FD0129 00006400
	v_sad_u8 v43, v43, 0, 0x6400                               // 0000009A06AC: D622002B 03FD012B 00006400
	v_lshl_add_u32 v46, v46, 24, v47                           // 0000009A06B8: D646002E 04BD312E
	v_lshl_or_b32 v42, v44, 16, v42                            // 0000009A06C0: D656002A 04A9212C
	v_sad_u8 v39, v39, 0, 0x6400                               // 0000009A06C8: D6220027 03FD0127 00006400
	v_and_b32_e32 v41, 0xffff, v41                             // 0000009A06D4: 365252FF 0000FFFF
	v_and_b32_e32 v43, 0xffff, v43                             // 0000009A06DC: 365656FF 0000FFFF
	v_sad_u8 v45, v45, 0, 0x6400                               // 0000009A06E4: D622002D 03FD012D 00006400
	v_sad_u8 v46, v46, 0, 0x6400                               // 0000009A06F0: D622002E 03FD012E 00006400
	v_pk_fma_f16 v42, v42, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000009A06FC: CC0E002A 0BFC112A 0000C931
	v_lshl_or_b32 v39, v39, 16, v41                            // 0000009A0708: D6560027 04A52127
	v_bfe_u32 v44, v36, 6, 16                                  // 0000009A0710: D610002C 02410D24
	v_lshl_or_b32 v41, v45, 16, v43                            // 0000009A0718: D6560029 04AD212D
	v_and_b32_e32 v43, 0xffff, v46                             // 0000009A0720: 36565CFF 0000FFFF
	v_mul_u32_u24_e32 v46, s6, v37                             // 0000009A0728: 165C4A06
	v_mul_u32_u24_e32 v37, s7, v37                             // 0000009A072C: 164A4A07
	v_lshl_add_u32 v37, v37, 24, v46                           // 0000009A0730: D6460025 04B93125
	v_dot2acc_f32_f16 v80, v42, v1                             // 0000009A0738: 04A0032A
	v_bfe_u32 v42, v35, 3, 16                                  // 0000009A073C: D610002A 02410723
	v_mul_u32_u24_e32 v46, s6, v42                             // 0000009A0744: 165C5406
	v_mul_u32_u24_e32 v42, s7, v42                             // 0000009A0748: 16545407
	s_delay_alu instid0(VALU_DEP_1)                            // 0000009A074C: BF870001
	v_lshl_add_u32 v42, v42, 24, v46                           // 0000009A0750: D646002A 04B9312A
	v_mul_u32_u24_e32 v46, s6, v38                             // 0000009A0758: 165C4C06
	v_mul_u32_u24_e32 v38, s7, v38                             // 0000009A075C: 164C4C07
	v_sad_u8 v37, v37, 0, 0x6400                               // 0000009A0760: D6220025 03FD0125 00006400
	v_lshl_add_u32 v38, v38, 24, v46                           // 0000009A076C: D6460026 04B93126
	v_and_b32_e32 v35, 0xffff, v35                             // 0000009A0774: 364646FF 0000FFFF
	v_mul_u32_u24_e32 v46, s6, v35                             // 0000009A077C: 165C4606
	v_mul_u32_u24_e32 v35, s7, v35                             // 0000009A0780: 16464607
	v_sad_u8 v42, v42, 0, 0x6400                               // 0000009A0784: D622002A 03FD012A 00006400
	s_delay_alu instid0(VALU_DEP_2)                            // 0000009A0790: BF870002
	v_lshl_add_u32 v35, v35, 24, v46                           // 0000009A0794: D6460023 04B93123
	v_and_b32_e32 v37, 0xffff, v37                             // 0000009A079C: 364A4AFF 0000FFFF
	v_sad_u8 v38, v38, 0, 0x6400                               // 0000009A07A4: D6220026 03FD0126 00006400
	v_pk_fma_f16 v39, v39, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000009A07B0: CC0E0027 0BFC1127 0000C931
	v_and_b32_e32 v42, 0xffff, v42                             // 0000009A07BC: 365454FF 0000FFFF
	v_sad_u8 v35, v35, 0, 0x6400                               // 0000009A07C4: D6220023 03FD0123 00006400
	v_pk_fma_f16 v41, v41, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000009A07D0: CC0E0029 0BFC1129 0000C931
	v_lshl_or_b32 v37, v38, 16, v37                            // 0000009A07DC: D6560025 04952126
	v_dot2acc_f32_f16 v80, v39, v2                             // 0000009A07E4: 04A00527
	v_bfe_u32 v45, v36, 3, 16                                  // 0000009A07E8: D610002D 02410724
	v_lshl_or_b32 v35, v35, 16, v42                            // 0000009A07F0: D6560023 04A92123
	v_bfe_u32 v20, v17, 6, 16                                  // 0000009A07F8: D6100014 02410D11
	v_pk_fma_f16 v37, v37, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000009A0800: CC0E0025 0BFC1125 0000C931
	v_dot2acc_f32_f16 v80, v41, v3                             // 0000009A080C: 04A00729
	.long 0xd73d0005                                           // 0000009A0810: D73D0005
	v_cndmask_b32_e32 v1, v90, v5, vcc_lo                      // 0000009A0814: 02020B5A
	v_pk_fma_f16 v35, v35, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000009A0818: CC0E0023 0BFC1123 0000C931
	s_waitcnt vmcnt(0)                                         // 0000009A0824: BF8903F7
	.long 0xd73d0006                                           // 0000009A0828: D73D0006
	v_cndmask_b32_e32 v1, v92, v7, vcc_lo                      // 0000009A082C: 02020F5C
	v_dot2acc_f32_f16 v79, v37, v1                             // 0000009A0830: 049E0325
	v_bfe_u32 v37, v31, 9, 16                                  // 0000009A0834: D6100025 0241131F
	v_add_nc_u32_e32 v88, 1, v88                               // 0000009A083C: 4AB0B081
	v_bfe_u32 v7, v5, 9, 16                                    // 0000009A0840: D6100007 02411305
	v_bfe_u32 v8, v5, 6, 16                                    // 0000009A0848: D6100008 02410D05
	v_dual_dot2acc_f32_f16 v79, v35, v2 :: v_dual_and_b32 v40, 0xffff, v40// 0000009A0850: CB240523 4F2850FF 0000FFFF
	v_mul_u32_u24_e32 v47, s6, v40                             // 0000009A085C: 165E5006
	v_mul_u32_u24_e32 v40, s7, v40                             // 0000009A0860: 16505007
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000009A0864: BF8701B1
	v_lshl_add_u32 v40, v40, 24, v47                           // 0000009A0868: D6460028 04BD3128
	v_dual_dot2acc_f32_f16 v84, v51, v4 :: v_dual_add_nc_u32 v91, 32, v91// 0000009A0870: CB200933 545AB6A0
	v_dual_mov_b32 v62, v124 :: v_dual_mov_b32 v49, v122       // 0000009A0878: CA10017C 3E30017A
	v_sad_u8 v40, v40, 0, 0x6400                               // 0000009A0880: D6220028 03FD0128 00006400
	v_mov_b32_e32 v47, v104                                    // 0000009A088C: 7E5E0368
	v_mov_b32_e32 v53, v125                                    // 0000009A0890: 7E6A037D
	v_mov_b32_e32 v51, v105                                    // 0000009A0894: 7E660369
	v_mov_b32_e32 v57, v129                                    // 0000009A0898: 7E720381
	v_lshl_or_b32 v40, v40, 16, v43                            // 0000009A089C: D6560028 04AD2128
	v_bfe_u32 v43, v36, 9, 16                                  // 0000009A08A4: D610002B 02411324
	v_mul_u32_u24_e32 v46, s6, v43                             // 0000009A08AC: 165C5606
	v_mul_u32_u24_e32 v43, s7, v43                             // 0000009A08B0: 16565607
	s_delay_alu instid0(VALU_DEP_1)                            // 0000009A08B4: BF870001
	v_lshl_add_u32 v43, v43, 24, v46                           // 0000009A08B8: D646002B 04B9312B
	v_mul_u32_u24_e32 v46, s6, v44                             // 0000009A08C0: 165C5806
	v_mul_u32_u24_e32 v44, s7, v44                             // 0000009A08C4: 16585807
	v_lshl_add_u32 v44, v44, 24, v46                           // 0000009A08C8: D646002C 04B9312C
	v_pk_fma_f16 v35, v40, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000009A08D0: CC0E0023 0BFC1128 0000C931
	v_sad_u8 v43, v43, 0, 0x6400                               // 0000009A08DC: D622002B 03FD012B 00006400
	v_mul_u32_u24_e32 v46, s6, v45                             // 0000009A08E8: 165C5A06
	v_mul_u32_u24_e32 v45, s7, v45                             // 0000009A08EC: 165A5A07
	v_sad_u8 v42, v44, 0, 0x6400                               // 0000009A08F0: D622002A 03FD012C 00006400
	v_lshl_add_u32 v45, v45, 24, v46                           // 0000009A08FC: D646002D 04B9312D
	v_and_b32_e32 v38, 0xffff, v43                             // 0000009A0904: 364C56FF 0000FFFF
	v_dot2acc_f32_f16 v80, v35, v4                             // 0000009A090C: 04A00923
	v_dual_mov_b32 v46, v106 :: v_dual_mov_b32 v35, v147       // 0000009A0910: CA10016A 2E220193
	v_mov_b32_e32 v64, v100                                    // 0000009A0918: 7E800364
	s_delay_alu instid0(VALU_DEP_4)                            // 0000009A091C: BF870004
	v_lshl_or_b32 v38, v42, 16, v38                            // 0000009A0920: D6560026 0499212A
	v_sad_u8 v43, v45, 0, 0x6400                               // 0000009A0928: D622002B 03FD012D 00006400
	v_mov_b32_e32 v45, v119                                    // 0000009A0934: 7E5A0377
	v_mov_b32_e32 v55, v107                                    // 0000009A0938: 7E6E036B
	v_mov_b32_e32 v61, v132                                    // 0000009A093C: 7E7A0384
	v_pk_fma_f16 v32, v38, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000009A0940: CC0E0020 0BFC1126 0000C931
	v_bfe_u32 v38, v31, 6, 16                                  // 0000009A094C: D6100026 02410D1F
	v_mul_u32_u24_e32 v41, s6, v38                             // 0000009A0954: 16524C06
	v_mul_u32_u24_e32 v38, s7, v38                             // 0000009A0958: 164C4C07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000009A095C: BF8700D1
	v_lshl_add_u32 v38, v38, 24, v41                           // 0000009A0960: D6460026 04A53126
	v_dot2acc_f32_f16 v79, v32, v3                             // 0000009A0968: 049E0720
	.long 0xd73d0020                                           // 0000009A096C: D73D0020
	v_cndmask_b32_e32 v1, v92, v33, vcc_lo                     // 0000009A0970: 0202435C
	v_mul_u32_u24_e32 v33, s6, v37                             // 0000009A0974: 16424A06
	v_mul_u32_u24_e32 v34, s7, v37                             // 0000009A0978: 16444A07
	v_lshl_add_u32 v33, v34, 24, v33                           // 0000009A097C: D6460021 04853122
	v_sad_u8 v38, v38, 0, 0x6400                               // 0000009A0984: D6220026 03FD0126 00006400
	v_bfe_u32 v34, v31, 3, 16                                  // 0000009A0990: D6100022 0241071F
	v_bfe_u32 v37, v32, 9, 16                                  // 0000009A0998: D6100025 02411320
	v_mul_u32_u24_e32 v41, s6, v34                             // 0000009A09A0: 16524406
	v_sad_u8 v33, v33, 0, 0x6400                               // 0000009A09A4: D6220021 03FD0121 00006400
	v_mul_u32_u24_e32 v34, s7, v34                             // 0000009A09B0: 16444407
	v_lshl_add_u32 v34, v34, 24, v41                           // 0000009A09B4: D6460022 04A53122
	v_mul_u32_u24_e32 v41, s6, v37                             // 0000009A09BC: 16524A06
	v_mul_u32_u24_e32 v37, s7, v37                             // 0000009A09C0: 164A4A07
	v_and_b32_e32 v33, 0xffff, v33                             // 0000009A09C4: 364242FF 0000FFFF
	v_lshl_add_u32 v37, v37, 24, v41                           // 0000009A09CC: D6460025 04A53125
	v_and_b32_e32 v31, 0xffff, v31                             // 0000009A09D4: 363E3EFF 0000FFFF
	v_bfe_u32 v39, v32, 6, 16                                  // 0000009A09DC: D6100027 02410D20
	v_mul_u32_u24_e32 v41, s6, v31                             // 0000009A09E4: 16523E06
	v_lshl_or_b32 v33, v38, 16, v33                            // 0000009A09E8: D6560021 04852126
	v_mul_u32_u24_e32 v31, s7, v31                             // 0000009A09F0: 163E3E07
	v_lshl_add_u32 v31, v31, 24, v41                           // 0000009A09F4: D646001F 04A5311F
	v_mul_u32_u24_e32 v41, s6, v39                             // 0000009A09FC: 16524E06
	v_mul_u32_u24_e32 v39, s7, v39                             // 0000009A0A00: 164E4E07
	v_sad_u8 v34, v34, 0, 0x6400                               // 0000009A0A04: D6220022 03FD0122 00006400
	v_sad_u8 v37, v37, 0, 0x6400                               // 0000009A0A10: D6220025 03FD0125 00006400
	v_lshl_add_u32 v39, v39, 24, v41                           // 0000009A0A1C: D6460027 04A53127
	v_pk_fma_f16 v33, v33, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000009A0A24: CC0E0021 0BFC1121 0000C931
	v_mul_u32_u24_e32 v41, s6, v29                             // 0000009A0A30: 16523A06
	v_mul_u32_u24_e32 v29, s7, v29                             // 0000009A0A34: 163A3A07
	v_lshl_add_u32 v29, v29, 24, v41                           // 0000009A0A38: D646001D 04A5311D
	v_and_b32_e32 v34, 0xffff, v34                             // 0000009A0A40: 364444FF 0000FFFF
	v_sad_u8 v31, v31, 0, 0x6400                               // 0000009A0A48: D622001F 03FD011F 00006400
	v_and_b32_e32 v37, 0xffff, v37                             // 0000009A0A54: 364A4AFF 0000FFFF
	v_sad_u8 v38, v39, 0, 0x6400                               // 0000009A0A5C: D6220026 03FD0127 00006400
	v_dot2acc_f32_f16 v78, v33, v1                             // 0000009A0A68: 049C0321
	v_bfe_u32 v33, v27, 3, 16                                  // 0000009A0A6C: D6100021 0241071B
	v_mul_u32_u24_e32 v41, s6, v33                             // 0000009A0A74: 16524206
	v_mul_u32_u24_e32 v33, s7, v33                             // 0000009A0A78: 16424207
	s_delay_alu instid0(VALU_DEP_1)                            // 0000009A0A7C: BF870001
	v_lshl_add_u32 v33, v33, 24, v41                           // 0000009A0A80: D6460021 04A53121
	v_mul_u32_u24_e32 v41, s6, v30                             // 0000009A0A88: 16523C06
	v_mul_u32_u24_e32 v30, s7, v30                             // 0000009A0A8C: 163C3C07
	v_sad_u8 v29, v29, 0, 0x6400                               // 0000009A0A90: D622001D 03FD011D 00006400
	v_lshl_add_u32 v30, v30, 24, v41                           // 0000009A0A9C: D646001E 04A5311E
	v_bfe_u32 v40, v32, 3, 16                                  // 0000009A0AA4: D6100028 02410720
	v_mul_u32_u24_e32 v39, s6, v40                             // 0000009A0AAC: 164E5006
	v_and_b32_e32 v32, 0xffff, v32                             // 0000009A0AB0: 364040FF 0000FFFF
	v_mul_u32_u24_e32 v40, s7, v40                             // 0000009A0AB8: 16505007
	s_delay_alu instid0(VALU_DEP_2)                            // 0000009A0ABC: BF870002
	v_lshl_add_u32 v39, v40, 24, v39                           // 0000009A0AC0: D6460027 049D3128
	v_lshl_or_b32 v31, v31, 16, v34                            // 0000009A0AC8: D656001F 0489211F
	v_lshl_or_b32 v34, v38, 16, v37                            // 0000009A0AD0: D6560022 04952126
	v_mul_u32_u24_e32 v38, s6, v32                             // 0000009A0AD8: 164C4006
	v_mul_u32_u24_e32 v32, s7, v32                             // 0000009A0ADC: 16404007
	v_and_b32_e32 v27, 0xffff, v27                             // 0000009A0AE0: 363636FF 0000FFFF
	v_lshl_add_u32 v32, v32, 24, v38                           // 0000009A0AE8: D6460020 04993120
	v_bfe_u32 v38, v28, 9, 16                                  // 0000009A0AF0: D6100026 0241131C
	v_mul_u32_u24_e32 v41, s6, v27                             // 0000009A0AF8: 16523606
	v_mul_u32_u24_e32 v27, s7, v27                             // 0000009A0AFC: 16363607
	v_sad_u8 v33, v33, 0, 0x6400                               // 0000009A0B00: D6220021 03FD0121 00006400
	v_lshl_add_u32 v27, v27, 24, v41                           // 0000009A0B0C: D646001B 04A5311B
	v_mul_u32_u24_e32 v41, s6, v38                             // 0000009A0B14: 16524C06
	v_mul_u32_u24_e32 v38, s7, v38                             // 0000009A0B18: 164C4C07
	v_lshl_add_u32 v38, v38, 24, v41                           // 0000009A0B1C: D6460026 04A53126
	v_and_b32_e32 v29, 0xffff, v29                             // 0000009A0B24: 363A3AFF 0000FFFF
	v_sad_u8 v30, v30, 0, 0x6400                               // 0000009A0B2C: D622001E 03FD011E 00006400
	v_sad_u8 v37, v39, 0, 0x6400                               // 0000009A0B38: D6220025 03FD0127 00006400
	v_bfe_u32 v39, v28, 6, 16                                  // 0000009A0B44: D6100027 02410D1C
	v_bfe_u32 v40, v28, 3, 16                                  // 0000009A0B4C: D6100028 0241071C
	v_mul_u32_u24_e32 v41, s6, v39                             // 0000009A0B54: 16524E06
	v_mul_u32_u24_e32 v39, s7, v39                             // 0000009A0B58: 164E4E07
	v_and_b32_e32 v33, 0xffff, v33                             // 0000009A0B5C: 364242FF 0000FFFF
	v_sad_u8 v27, v27, 0, 0x6400                               // 0000009A0B64: D622001B 03FD011B 00006400
	v_lshl_add_u32 v39, v39, 24, v41                           // 0000009A0B70: D6460027 04A53127
	v_mul_u32_u24_e32 v41, s6, v40                             // 0000009A0B78: 16525006
	v_mul_u32_u24_e32 v40, s7, v40                             // 0000009A0B7C: 16505007
	v_sad_u8 v38, v38, 0, 0x6400                               // 0000009A0B80: D6220026 03FD0126 00006400
	v_lshl_add_u32 v40, v40, 24, v41                           // 0000009A0B8C: D6460028 04A53128
	v_lshl_or_b32 v29, v30, 16, v29                            // 0000009A0B94: D656001D 0475211E
	v_and_b32_e32 v28, 0xffff, v28                             // 0000009A0B9C: 363838FF 0000FFFF
	v_lshl_or_b32 v27, v27, 16, v33                            // 0000009A0BA4: D656001B 0485211B
	v_sad_u8 v33, v39, 0, 0x6400                               // 0000009A0BAC: D6220021 03FD0127 00006400
	v_mul_u32_u24_e32 v39, s6, v28                             // 0000009A0BB8: 164E3806
	v_mul_u32_u24_e32 v28, s7, v28                             // 0000009A0BBC: 16383807
	v_and_b32_e32 v30, 0xffff, v38                             // 0000009A0BC0: 363C4CFF 0000FFFF
	v_sad_u8 v38, v40, 0, 0x6400                               // 0000009A0BC8: D6220026 03FD0128 00006400
	v_lshl_add_u32 v28, v28, 24, v39                           // 0000009A0BD4: D646001C 049D311C
	v_pk_fma_f16 v29, v29, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000009A0BDC: CC0E001D 0BFC111D 0000C931
	v_and_b32_e32 v36, 0xffff, v36                             // 0000009A0BE8: 364848FF 0000FFFF
	v_pk_fma_f16 v31, v31, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000009A0BF0: CC0E001F 0BFC111F 0000C931
	v_and_b32_e32 v37, 0xffff, v37                             // 0000009A0BFC: 364A4AFF 0000FFFF
	v_sad_u8 v32, v32, 0, 0x6400                               // 0000009A0C04: D6220020 03FD0120 00006400
	v_pk_fma_f16 v27, v27, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000009A0C10: CC0E001B 0BFC111B 0000C931
	v_lshl_or_b32 v30, v33, 16, v30                            // 0000009A0C1C: D656001E 04792121
	v_and_b32_e32 v33, 0xffff, v38                             // 0000009A0C24: 36424CFF 0000FFFF
	v_sad_u8 v28, v28, 0, 0x6400                               // 0000009A0C2C: D622001C 03FD011C 00006400
	v_dot2acc_f32_f16 v77, v29, v1                             // 0000009A0C38: 049A031D
	v_pk_fma_f16 v34, v34, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000009A0C3C: CC0E0022 0BFC1122 0000C931
	v_lshl_or_b32 v29, v32, 16, v37                            // 0000009A0C48: D656001D 04952120
	v_dot2acc_f32_f16 v78, v31, v2                             // 0000009A0C50: 049C051F
	v_pk_fma_f16 v30, v30, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000009A0C54: CC0E001E 0BFC111E 0000C931
	v_lshl_or_b32 v28, v28, 16, v33                            // 0000009A0C60: D656001C 0485211C
	v_dot2acc_f32_f16 v77, v27, v2                             // 0000009A0C68: 049A051B
	v_pk_fma_f16 v27, v29, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000009A0C6C: CC0E001B 0BFC111D 0000C931
	v_dot2acc_f32_f16 v78, v34, v3                             // 0000009A0C78: 049C0722
	v_mul_u32_u24_e32 v44, s6, v36                             // 0000009A0C7C: 16584806
	v_pk_fma_f16 v22, v28, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000009A0C80: CC0E0016 0BFC111C 0000C931
	v_dot2acc_f32_f16 v77, v30, v3                             // 0000009A0C8C: 049A071E
	v_bfe_u32 v28, v21, 6, 16                                  // 0000009A0C90: D610001C 02410D15
	v_dot2acc_f32_f16 v78, v27, v4                             // 0000009A0C98: 049C091B
	v_bfe_u32 v27, v21, 9, 16                                  // 0000009A0C9C: D610001B 02411315
	v_mul_u32_u24_e32 v31, s6, v28                             // 0000009A0CA4: 163E3806
	v_dot2acc_f32_f16 v77, v22, v4                             // 0000009A0CA8: 049A0916
	.long 0xd73d0016                                           // 0000009A0CAC: D73D0016
	v_cndmask_b32_e32 v1, v92, v23, vcc_lo                     // 0000009A0CB0: 02022F5C
	v_mul_u32_u24_e32 v24, s6, v27                             // 0000009A0CB4: 16303606
	v_mul_u32_u24_e32 v27, s7, v27                             // 0000009A0CB8: 16363607
	v_lshl_add_u32 v24, v27, 24, v24                           // 0000009A0CBC: D6460018 0461311B
	v_bfe_u32 v23, v21, 3, 16                                  // 0000009A0CC4: D6100017 02410715
	v_mul_u32_u24_e32 v28, s7, v28                             // 0000009A0CCC: 16383807
	v_bfe_u32 v27, v22, 9, 16                                  // 0000009A0CD0: D610001B 02411316
	v_lshl_add_u32 v28, v28, 24, v31                           // 0000009A0CD8: D646001C 047D311C
	v_sad_u8 v24, v24, 0, 0x6400                               // 0000009A0CE0: D6220018 03FD0118 00006400
	v_mul_u32_u24_e32 v31, s6, v23                             // 0000009A0CEC: 163E2E06
	v_mul_u32_u24_e32 v23, s7, v23                             // 0000009A0CF0: 162E2E07
	v_lshl_add_u32 v23, v23, 24, v31                           // 0000009A0CF4: D6460017 047D3117
	v_mul_u32_u24_e32 v31, s6, v27                             // 0000009A0CFC: 163E3606
	v_mul_u32_u24_e32 v27, s7, v27                             // 0000009A0D00: 16363607
	v_lshl_add_u32 v27, v27, 24, v31                           // 0000009A0D04: D646001B 047D311B
	v_and_b32_e32 v21, 0xffff, v21                             // 0000009A0D0C: 362A2AFF 0000FFFF
	v_bfe_u32 v29, v22, 6, 16                                  // 0000009A0D14: D610001D 02410D16
	v_mul_u32_u24_e32 v31, s6, v21                             // 0000009A0D1C: 163E2A06
	v_mul_u32_u24_e32 v21, s7, v21                             // 0000009A0D20: 162A2A07
	v_mul_u32_u24_e32 v36, s7, v36                             // 0000009A0D24: 16484807
	v_bfe_u32 v30, v22, 3, 16                                  // 0000009A0D28: D610001E 02410716
	v_and_b32_e32 v24, 0xffff, v24                             // 0000009A0D30: 363030FF 0000FFFF
	v_sad_u8 v28, v28, 0, 0x6400                               // 0000009A0D38: D622001C 03FD011C 00006400
	v_lshl_add_u32 v21, v21, 24, v31                           // 0000009A0D44: D6460015 047D3115
	v_mul_u32_u24_e32 v31, s6, v29                             // 0000009A0D4C: 163E3A06
	v_mul_u32_u24_e32 v29, s7, v29                             // 0000009A0D50: 163A3A07
	v_lshl_add_u32 v36, v36, 24, v44                           // 0000009A0D54: D6460024 04B13124
	v_lshl_add_u32 v29, v29, 24, v31                           // 0000009A0D5C: D646001D 047D311D
	v_mul_u32_u24_e32 v31, s6, v30                             // 0000009A0D64: 163E3C06
	v_mul_u32_u24_e32 v30, s7, v30                             // 0000009A0D68: 163C3C07
	v_sad_u8 v23, v23, 0, 0x6400                               // 0000009A0D6C: D6220017 03FD0117 00006400
	v_sad_u8 v27, v27, 0, 0x6400                               // 0000009A0D78: D622001B 03FD011B 00006400
	v_lshl_add_u32 v30, v30, 24, v31                           // 0000009A0D84: D646001E 047D311E
	v_lshl_or_b32 v24, v28, 16, v24                            // 0000009A0D8C: D6560018 0461211C
	v_and_b32_e32 v42, 0xffff, v43                             // 0000009A0D94: 365456FF 0000FFFF
	v_sad_u8 v36, v36, 0, 0x6400                               // 0000009A0D9C: D6220024 03FD0124 00006400
	v_dual_mov_b32 v34, v151 :: v_dual_and_b32 v23, 0xffff, v23// 0000009A0DA8: CA240197 22162EFF 0000FFFF
	v_sad_u8 v21, v21, 0, 0x6400                               // 0000009A0DB4: D6220015 03FD0115 00006400
	v_dual_mov_b32 v32, v116 :: v_dual_and_b32 v27, 0xffff, v27// 0000009A0DC0: CA240174 201A36FF 0000FFFF
	v_sad_u8 v29, v29, 0, 0x6400                               // 0000009A0DCC: D622001D 03FD011D 00006400
	v_sad_u8 v30, v30, 0, 0x6400                               // 0000009A0DD8: D622001E 03FD011E 00006400
	v_and_b32_e32 v22, 0xffff, v22                             // 0000009A0DE4: 362C2CFF 0000FFFF
	v_mul_u32_u24_e32 v31, s6, v22                             // 0000009A0DEC: 163E2C06
	v_mul_u32_u24_e32 v22, s7, v22                             // 0000009A0DF0: 162C2C07
	v_pk_fma_f16 v24, v24, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000009A0DF4: CC0E0018 0BFC1118 0000C931
	v_lshl_or_b32 v36, v36, 16, v42                            // 0000009A0E00: D6560024 04A92124
	v_lshl_add_u32 v22, v22, 24, v31                           // 0000009A0E08: D6460016 047D3116
	v_lshl_or_b32 v21, v21, 16, v23                            // 0000009A0E10: D6560015 045D2115
	v_lshl_or_b32 v23, v29, 16, v27                            // 0000009A0E18: D6560017 046D211D
	v_dual_mov_b32 v38, v153 :: v_dual_and_b32 v27, 0xffff, v30// 0000009A0E20: CA240199 261A3CFF 0000FFFF
	v_mul_u32_u24_e32 v30, s6, v19                             // 0000009A0E2C: 163C2606
	v_mul_u32_u24_e32 v19, s7, v19                             // 0000009A0E30: 16262607
	v_lshl_add_u32 v19, v19, 24, v30                           // 0000009A0E34: D6460013 04793113
	v_dot2acc_f32_f16 v76, v24, v1                             // 0000009A0E3C: 04980318
	v_bfe_u32 v24, v17, 3, 16                                  // 0000009A0E40: D6100018 02410711
	v_pk_fma_f16 v36, v36, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000009A0E48: CC0E0024 0BFC1124 0000C931
	v_sad_u8 v22, v22, 0, 0x6400                               // 0000009A0E54: D6220016 03FD0116 00006400
	v_mul_u32_u24_e32 v30, s6, v24                             // 0000009A0E60: 163C3006
	v_mul_u32_u24_e32 v24, s7, v24                             // 0000009A0E64: 16303007
	v_lshl_add_u32 v24, v24, 24, v30                           // 0000009A0E68: D6460018 04793118
	v_mul_u32_u24_e32 v30, s6, v20                             // 0000009A0E70: 163C2806
	v_mul_u32_u24_e32 v20, s7, v20                             // 0000009A0E74: 16282807
	v_sad_u8 v19, v19, 0, 0x6400                               // 0000009A0E78: D6220013 03FD0113 00006400
	v_lshl_add_u32 v20, v20, 24, v30                           // 0000009A0E84: D6460014 04793114
	v_and_b32_e32 v17, 0xffff, v17                             // 0000009A0E8C: 362222FF 0000FFFF
	v_dot2acc_f32_f16 v79, v36, v4                             // 0000009A0E94: 049E0924
	v_lshl_or_b32 v22, v22, 16, v27                            // 0000009A0E98: D6560016 046D2116
	v_bfe_u32 v27, v18, 9, 16                                  // 0000009A0EA0: D610001B 02411312
	v_mov_b32_e32 v36, v117                                    // 0000009A0EA8: 7E480375
	v_mul_u32_u24_e32 v30, s6, v17                             // 0000009A0EAC: 163C2206
	v_mul_u32_u24_e32 v17, s7, v17                             // 0000009A0EB0: 16222207
	v_lshl_add_u32 v17, v17, 24, v30                           // 0000009A0EB4: D6460011 04793111
	v_mul_u32_u24_e32 v30, s6, v27                             // 0000009A0EBC: 163C3606
	v_mul_u32_u24_e32 v27, s7, v27                             // 0000009A0EC0: 16363607
	v_sad_u8 v24, v24, 0, 0x6400                               // 0000009A0EC4: D6220018 03FD0118 00006400
	v_lshl_add_u32 v27, v27, 24, v30                           // 0000009A0ED0: D646001B 0479311B
	v_dual_mov_b32 v42, v155 :: v_dual_and_b32 v19, 0xffff, v19// 0000009A0ED8: CA24019B 2A1226FF 0000FFFF
	v_sad_u8 v20, v20, 0, 0x6400                               // 0000009A0EE4: D6220014 03FD0114 00006400
	v_bfe_u32 v28, v18, 6, 16                                  // 0000009A0EF0: D610001C 02410D12
	v_mul_u32_u24_e32 v30, s6, v28                             // 0000009A0EF8: 163C3806
	v_mul_u32_u24_e32 v28, s7, v28                             // 0000009A0EFC: 16383807
	v_and_b32_e32 v24, 0xffff, v24                             // 0000009A0F00: 363030FF 0000FFFF
	v_sad_u8 v17, v17, 0, 0x6400                               // 0000009A0F08: D6220011 03FD0111 00006400
	v_sad_u8 v27, v27, 0, 0x6400                               // 0000009A0F14: D622001B 03FD011B 00006400
	v_lshl_add_u32 v28, v28, 24, v30                           // 0000009A0F20: D646001C 0479311C
	v_lshl_or_b32 v19, v20, 16, v19                            // 0000009A0F28: D6560013 044D2114
	v_pk_fma_f16 v21, v21, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000009A0F30: CC0E0015 0BFC1115 0000C931
	v_lshl_or_b32 v17, v17, 16, v24                            // 0000009A0F3C: D6560011 04612111
	v_and_b32_e32 v20, 0xffff, v27                             // 0000009A0F44: 362836FF 0000FFFF
	v_sad_u8 v24, v28, 0, 0x6400                               // 0000009A0F4C: D6220018 03FD011C 00006400
	v_pk_fma_f16 v19, v19, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000009A0F58: CC0E0013 0BFC1113 0000C931
	v_pk_fma_f16 v23, v23, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000009A0F64: CC0E0017 0BFC1117 0000C931
	v_pk_fma_f16 v17, v17, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000009A0F70: CC0E0011 0BFC1111 0000C931
	v_dot2acc_f32_f16 v76, v21, v2                             // 0000009A0F7C: 04980515
	v_lshl_or_b32 v20, v24, 16, v20                            // 0000009A0F80: D6560014 04512118
	v_dot2acc_f32_f16 v75, v19, v1                             // 0000009A0F88: 04960313
	v_bfe_u32 v19, v11, 9, 16                                  // 0000009A0F8C: D6100013 0241130B
	v_mov_b32_e32 v40, v118                                    // 0000009A0F94: 7E500376
	v_dot2acc_f32_f16 v76, v23, v3                             // 0000009A0F98: 04980717
	v_pk_fma_f16 v12, v20, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000009A0F9C: CC0E000C 0BFC1114 0000C931
	v_dot2acc_f32_f16 v75, v17, v2                             // 0000009A0FA8: 04960511
	v_bfe_u32 v20, v11, 6, 16                                  // 0000009A0FAC: D6100014 02410D0B
	v_mul_u32_u24_e32 v23, s6, v20                             // 0000009A0FB4: 162E2806
	v_mul_u32_u24_e32 v20, s7, v20                             // 0000009A0FB8: 16282807
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000009A0FBC: BF8700D1
	v_lshl_add_u32 v20, v20, 24, v23                           // 0000009A0FC0: D6460014 045D3114
	v_dot2acc_f32_f16 v75, v12, v3                             // 0000009A0FC8: 0496070C
	.long 0xd73d000c                                           // 0000009A0FCC: D73D000C
	v_cndmask_b32_e32 v1, v92, v13, vcc_lo                     // 0000009A0FD0: 02021B5C
	v_mul_u32_u24_e32 v13, s6, v19                             // 0000009A0FD4: 161A2606
	v_mul_u32_u24_e32 v14, s7, v19                             // 0000009A0FD8: 161C2607
	v_lshl_add_u32 v13, v14, 24, v13                           // 0000009A0FDC: D646000D 0435310E
	v_sad_u8 v20, v20, 0, 0x6400                               // 0000009A0FE4: D6220014 03FD0114 00006400
	v_bfe_u32 v14, v11, 3, 16                                  // 0000009A0FF0: D610000E 0241070B
	v_bfe_u32 v19, v12, 9, 16                                  // 0000009A0FF8: D6100013 0241130C
	v_mul_u32_u24_e32 v23, s6, v14                             // 0000009A1000: 162E1C06
	v_sad_u8 v13, v13, 0, 0x6400                               // 0000009A1004: D622000D 03FD010D 00006400
	v_mul_u32_u24_e32 v14, s7, v14                             // 0000009A1010: 161C1C07
	v_and_b32_e32 v11, 0xffff, v11                             // 0000009A1014: 361616FF 0000FFFF
	v_lshl_add_u32 v14, v14, 24, v23                           // 0000009A101C: D646000E 045D310E
	v_mul_u32_u24_e32 v23, s6, v19                             // 0000009A1024: 162E2606
	v_and_b32_e32 v13, 0xffff, v13                             // 0000009A1028: 361A1AFF 0000FFFF
	v_mul_u32_u24_e32 v19, s7, v19                             // 0000009A1030: 16262607
	v_bfe_u32 v21, v12, 6, 16                                  // 0000009A1034: D6100015 02410D0C
	v_lshl_add_u32 v19, v19, 24, v23                           // 0000009A103C: D6460013 045D3113
	v_mul_u32_u24_e32 v23, s6, v11                             // 0000009A1044: 162E1606
	v_lshl_or_b32 v13, v20, 16, v13                            // 0000009A1048: D656000D 04352114
	v_mul_u32_u24_e32 v11, s7, v11                             // 0000009A1050: 16161607
	v_lshl_add_u32 v11, v11, 24, v23                           // 0000009A1054: D646000B 045D310B
	v_mul_u32_u24_e32 v23, s6, v21                             // 0000009A105C: 162E2A06
	v_mul_u32_u24_e32 v21, s7, v21                             // 0000009A1060: 162A2A07
	v_pk_fma_f16 v13, v13, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000009A1064: CC0E000D 0BFC110D 0000C931
	v_lshl_add_u32 v21, v21, 24, v23                           // 0000009A1070: D6460015 045D3115
	v_mul_u32_u24_e32 v23, s6, v7                              // 0000009A1078: 162E0E06
	v_mul_u32_u24_e32 v7, s7, v7                               // 0000009A107C: 160E0E07
	v_lshl_add_u32 v7, v7, 24, v23                             // 0000009A1080: D6460007 045D3107
	v_dot2acc_f32_f16 v74, v13, v1                             // 0000009A1088: 0494030D
	v_bfe_u32 v13, v5, 3, 16                                   // 0000009A108C: D610000D 02410705
	v_mul_u32_u24_e32 v23, s6, v13                             // 0000009A1094: 162E1A06
	v_mul_u32_u24_e32 v13, s7, v13                             // 0000009A1098: 161A1A07
	s_delay_alu instid0(VALU_DEP_1)                            // 0000009A109C: BF870001
	v_lshl_add_u32 v13, v13, 24, v23                           // 0000009A10A0: D646000D 045D310D
	v_mul_u32_u24_e32 v23, s6, v8                              // 0000009A10A8: 162E1006
	v_mul_u32_u24_e32 v8, s7, v8                               // 0000009A10AC: 16101007
	v_sad_u8 v7, v7, 0, 0x6400                                 // 0000009A10B0: D6220007 03FD0107 00006400
	v_lshl_add_u32 v8, v8, 24, v23                             // 0000009A10BC: D6460008 045D3108
	v_sad_u8 v14, v14, 0, 0x6400                               // 0000009A10C4: D622000E 03FD010E 00006400
	v_sad_u8 v19, v19, 0, 0x6400                               // 0000009A10D0: D6220013 03FD0113 00006400
	v_dual_mov_b32 v48, v96 :: v_dual_and_b32 v5, 0xffff, v5   // 0000009A10DC: CA240160 30040AFF 0000FFFF
	v_mul_u32_u24_e32 v23, s6, v5                              // 0000009A10E8: 162E0A06
	v_mul_u32_u24_e32 v5, s7, v5                               // 0000009A10EC: 160A0A07
	v_sad_u8 v13, v13, 0, 0x6400                               // 0000009A10F0: D622000D 03FD010D 00006400
	s_delay_alu instid0(VALU_DEP_2)                            // 0000009A10FC: BF870002
	v_lshl_add_u32 v5, v5, 24, v23                             // 0000009A1100: D6460005 045D3105
	v_dual_mov_b32 v54, v110 :: v_dual_and_b32 v7, 0xffff, v7  // 0000009A1108: CA24016E 36060EFF 0000FFFF
	v_sad_u8 v8, v8, 0, 0x6400                                 // 0000009A1114: D6220008 03FD0108 00006400
	v_pk_fma_f16 v17, v22, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000009A1120: CC0E0011 0BFC1116 0000C931
	v_and_b32_e32 v14, 0xffff, v14                             // 0000009A112C: 361C1CFF 0000FFFF
	v_sad_u8 v11, v11, 0, 0x6400                               // 0000009A1134: D622000B 03FD010B 00006400
	v_dual_mov_b32 v44, v95 :: v_dual_and_b32 v19, 0xffff, v19 // 0000009A1140: CA24015F 2C1226FF 0000FFFF
	v_sad_u8 v20, v21, 0, 0x6400                               // 0000009A114C: D6220014 03FD0115 00006400
	v_bfe_u32 v22, v12, 3, 16                                  // 0000009A1158: D6100016 0241070C
	v_and_b32_e32 v12, 0xffff, v12                             // 0000009A1160: 361818FF 0000FFFF
	v_dual_mov_b32 v52, v97 :: v_dual_and_b32 v13, 0xffff, v13 // 0000009A1168: CA240161 340C1AFF 0000FFFF
	v_sad_u8 v5, v5, 0, 0x6400                                 // 0000009A1174: D6220005 03FD0105 00006400
	v_lshl_or_b32 v7, v8, 16, v7                               // 0000009A1180: D6560007 041D2108
	v_mul_u32_u24_e32 v21, s6, v22                             // 0000009A1188: 162A2C06
	v_dot2acc_f32_f16 v76, v17, v4                             // 0000009A118C: 04980911
	v_mov_b32_e32 v17, v133                                    // 0000009A1190: 7E220385
	v_lshl_or_b32 v11, v11, 16, v14                            // 0000009A1194: D656000B 0439210B
	v_lshl_or_b32 v14, v20, 16, v19                            // 0000009A119C: D656000E 044D2114
	v_mul_u32_u24_e32 v20, s6, v12                             // 0000009A11A4: 16281806
	v_mul_u32_u24_e32 v12, s7, v12                             // 0000009A11A8: 16181807
	v_mul_u32_u24_e32 v22, s7, v22                             // 0000009A11AC: 162C2C07
	v_lshl_add_u32 v21, v22, 24, v21                           // 0000009A11B0: D6460015 04553116
	v_lshl_add_u32 v12, v12, 24, v20                           // 0000009A11B8: D646000C 0451310C
	v_bfe_u32 v20, v6, 9, 16                                   // 0000009A11C0: D6100014 02411306
	v_mul_u32_u24_e32 v23, s6, v20                             // 0000009A11C8: 162E2806
	v_mul_u32_u24_e32 v20, s7, v20                             // 0000009A11CC: 16282807
	s_delay_alu instid0(VALU_DEP_1)                            // 0000009A11D0: BF870001
	v_lshl_add_u32 v20, v20, 24, v23                           // 0000009A11D4: D6460014 045D3114
	v_lshl_or_b32 v5, v5, 16, v13                              // 0000009A11DC: D6560005 04352105
	v_pk_fma_f16 v7, v7, s8, 0xc931 op_sel_hi:[1,0,0]          // 0000009A11E4: CC0E0007 0BFC1107 0000C931
	v_sad_u8 v19, v21, 0, 0x6400                               // 0000009A11F0: D6220013 03FD0115 00006400
	v_bfe_u32 v21, v6, 6, 16                                   // 0000009A11FC: D6100015 02410D06
	v_mul_u32_u24_e32 v23, s6, v21                             // 0000009A1204: 162E2A06
	v_mul_u32_u24_e32 v21, s7, v21                             // 0000009A1208: 162A2A07
	v_bfe_u32 v29, v18, 3, 16                                  // 0000009A120C: D610001D 02410712
	v_bfe_u32 v22, v6, 3, 16                                   // 0000009A1214: D6100016 02410706
	v_sad_u8 v20, v20, 0, 0x6400                               // 0000009A121C: D6220014 03FD0114 00006400
	v_lshl_add_u32 v21, v21, 24, v23                           // 0000009A1228: D6460015 045D3115
	v_mul_u32_u24_e32 v30, s6, v29                             // 0000009A1230: 163C3A06
	v_mul_u32_u24_e32 v29, s7, v29                             // 0000009A1234: 163A3A07
	v_mul_u32_u24_e32 v23, s6, v22                             // 0000009A1238: 162E2C06
	v_mul_u32_u24_e32 v22, s7, v22                             // 0000009A123C: 162C2C07
	v_pk_fma_f16 v5, v5, s8, 0xc931 op_sel_hi:[1,0,0]          // 0000009A1240: CC0E0005 0BFC1105 0000C931
	v_dot2acc_f32_f16 v10, v7, v1                              // 0000009A124C: 04140307
	v_lshl_add_u32 v29, v29, 24, v30                           // 0000009A1250: D646001D 0479311D
	v_lshl_add_u32 v22, v22, 24, v23                           // 0000009A1258: D6460016 045D3116
	v_and_b32_e32 v18, 0xffff, v18                             // 0000009A1260: 362424FF 0000FFFF
	v_and_b32_e32 v6, 0xffff, v6                               // 0000009A1268: 360C0CFF 0000FFFF
	v_and_b32_e32 v8, 0xffff, v20                              // 0000009A1270: 361028FF 0000FFFF
	v_sad_u8 v13, v21, 0, 0x6400                               // 0000009A1278: D622000D 03FD0115 00006400
	v_mul_u32_u24_e32 v21, s6, v6                              // 0000009A1284: 162A0C06
	v_mul_u32_u24_e32 v6, s7, v6                               // 0000009A1288: 160C0C07
	v_dual_dot2acc_f32_f16 v10, v5, v2 :: v_dual_mov_b32 v5, v126// 0000009A128C: CB100505 0A04017E
	v_mul_u32_u24_e32 v28, s6, v18                             // 0000009A1294: 16382406
	v_mul_u32_u24_e32 v18, s7, v18                             // 0000009A1298: 16242407
	v_sad_u8 v27, v29, 0, 0x6400                               // 0000009A129C: D622001B 03FD011D 00006400
	v_lshl_add_u32 v18, v18, 24, v28                           // 0000009A12A8: D6460012 04713112
	v_sad_u8 v20, v22, 0, 0x6400                               // 0000009A12B0: D6220014 03FD0116 00006400
	v_lshl_add_u32 v6, v6, 24, v21                             // 0000009A12BC: D6460006 04553106
	v_pk_fma_f16 v11, v11, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000009A12C4: CC0E000B 0BFC110B 0000C931
	v_mov_b32_e32 v29, v154                                    // 0000009A12D0: 7E3A039A
	v_lshl_or_b32 v8, v13, 16, v8                              // 0000009A12D4: D6560008 0421210D
	v_and_b32_e32 v24, 0xffff, v27                             // 0000009A12DC: 363036FF 0000FFFF
	v_sad_u8 v18, v18, 0, 0x6400                               // 0000009A12E4: D6220012 03FD0112 00006400
	v_dual_mov_b32 v50, v108 :: v_dual_and_b32 v19, 0xffff, v19// 0000009A12F0: CA24016C 321226FF 0000FFFF
	v_sad_u8 v12, v12, 0, 0x6400                               // 0000009A12FC: D622000C 03FD010C 00006400
	v_dual_mov_b32 v58, v121 :: v_dual_and_b32 v13, 0xffff, v20// 0000009A1308: CA240179 3A0C28FF 0000FFFF
	v_sad_u8 v6, v6, 0, 0x6400                                 // 0000009A1314: D6220006 03FD0106 00006400
	v_pk_fma_f16 v14, v14, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000009A1320: CC0E000E 0BFC110E 0000C931
	v_dot2acc_f32_f16 v74, v11, v2                             // 0000009A132C: 0494050B
	v_pk_fma_f16 v7, v8, s8, 0xc931 op_sel_hi:[1,0,0]          // 0000009A1330: CC0E0007 0BFC1108 0000C931
	v_lshl_or_b32 v1, v12, 16, v19                             // 0000009A133C: D6560001 044D210C
	v_lshl_or_b32 v6, v6, 16, v13                              // 0000009A1344: D6560006 04352106
	v_mov_b32_e32 v19, v149                                    // 0000009A134C: 7E260395
	v_lshl_or_b32 v18, v18, 16, v24                            // 0000009A1350: D6560012 04612112
	v_dot2acc_f32_f16 v74, v14, v3                             // 0000009A1358: 0494070E
	v_dual_dot2acc_f32_f16 v10, v7, v3 :: v_dual_mov_b32 v27, v140// 0000009A135C: CB100707 0A1A018C
	v_dual_mov_b32 v56, v98 :: v_dual_add_nc_u32 v3, v89, v88  // 0000009A1364: CA200162 3802B159
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000009A136C: BF870234
	v_pk_fma_f16 v18, v18, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000009A1370: CC0E0012 0BFC1112 0000C931
	v_pk_fma_f16 v1, v1, s8, 0xc931 op_sel_hi:[1,0,0]          // 0000009A137C: CC0E0001 0BFC1101 0000C931
	v_pk_fma_f16 v2, v6, s8, 0xc931 op_sel_hi:[1,0,0]          // 0000009A1388: CC0E0002 0BFC1106 0000C931
	v_cmp_eq_u32_e32 vcc_lo, 21, v3                            // 0000009A1394: 7C940695
	v_mov_b32_e32 v7, v142                                     // 0000009A1398: 7E0E038E
	v_dot2acc_f32_f16 v75, v18, v4                             // 0000009A139C: 04960912
	v_dot2acc_f32_f16 v74, v1, v4                              // 0000009A13A0: 04940901
	v_dot2acc_f32_f16 v10, v2, v4                              // 0000009A13A4: 04140902
	v_mov_b32_e32 v8, v134                                     // 0000009A13A8: 7E100386
	v_dual_mov_b32 v6, v111 :: v_dual_mov_b32 v13, v146        // 0000009A13AC: CA10016F 060C0192
	v_mov_b32_e32 v14, v138                                    // 0000009A13B4: 7E1C038A
	v_dual_mov_b32 v11, v130 :: v_dual_mov_b32 v12, v112       // 0000009A13B8: CA100182 0B0C0170
	v_mov_b32_e32 v20, v141                                    // 0000009A13C0: 7E28038D
	v_dual_mov_b32 v18, v113 :: v_dual_mov_b32 v23, v152       // 0000009A13C4: CA100171 12160198
	v_mov_b32_e32 v24, v145                                    // 0000009A13CC: 7E300391
	v_dual_mov_b32 v21, v137 :: v_dual_mov_b32 v22, v114       // 0000009A13D0: CA100189 15160172
	v_mov_b32_e32 v30, v148                                    // 0000009A13D8: 7E3C0394
	v_dual_mov_b32 v28, v115 :: v_dual_mov_b32 v33, v156       // 0000009A13DC: CA100173 1C20019C
	v_dual_mov_b32 v60, v99 :: v_dual_mov_b32 v31, v144        // 0000009A13E4: CA100163 3C1E0190
	v_dual_mov_b32 v70, v131 :: v_dual_mov_b32 v37, v157       // 0000009A13EC: CA100183 4624019D
	v_dual_mov_b32 v66, v128 :: v_dual_mov_b32 v41, v158       // 0000009A13F4: CA100180 4228019E
	v_dual_mov_b32 v68, v101 :: v_dual_mov_b32 v39, v150       // 0000009A13FC: CA100165 44260196
	v_mov_b32_e32 v4, v135                                     // 0000009A1404: 7E080387
	v_mov_b32_e32 v43, v103                                    // 0000009A1408: 7E560367
	v_mov_b32_e32 v59, v109                                    // 0000009A140C: 7E76036D
	v_mov_b32_e32 v65, v136                                    // 0000009A1410: 7E820388
	v_mov_b32_e32 v63, v120                                    // 0000009A1414: 7E7E0378
	v_mov_b32_e32 v69, v139                                    // 0000009A1418: 7E8A038B
	v_mov_b32_e32 v67, v123                                    // 0000009A141C: 7E86037B
	v_mov_b32_e32 v3, v143                                     // 0000009A1420: 7E06038F
	v_dual_mov_b32 v1, v127 :: v_dual_mov_b32 v2, v102         // 0000009A1424: CA10017F 01020166
	s_or_b32 s0, vcc_lo, s0                                    // 0000009A142C: 8C00006A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000009A1430: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s0                        // 0000009A1434: 917E007E
	s_cbranch_execz 157                                        // 0000009A1438: BFA5009D <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi1ELi2EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x48b0>
	s_mov_b32 s9, exec_lo                                      // 0000009A143C: BE89007E
	.long 0xd4c9007e                                           // 0000009A1440: D4C9007E
	v_cndmask_b32_e32 v1, v88, v73, vcc_lo                     // 0000009A1444: 02029358
	s_cbranch_execz 63685                                      // 0000009A1448: BFA5F8C5 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi1ELi2EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x2960>
	v_mad_u64_u32 v[95:96], null, 0x600, v88, s[2:3]           // 0000009A144C: D6FE7C5F 000AB0FF 00000600
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000009A1458: BF870091
	.long 0xd7006a85                                           // 0000009A145C: D7006A85
	v_cndmask_b32_e32 v1, v95, v15, vcc_lo                     // 0000009A1460: 02021F5F
	v_add_co_ci_u32_e64 v134, null, v96, v16, vcc_lo           // 0000009A1464: D5207C86 01AA2160
	.long 0xd7006a8d                                           // 0000009A146C: D7006A8D
	v_cndmask_b32_e32 v1, v95, v93, vcc_lo                     // 0000009A1470: 0202BB5F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000009A1474: BF8700A1
	v_add_co_ci_u32_e64 v142, null, 0, v96, vcc_lo             // 0000009A1478: D5207C8E 01AAC080
	.long 0xd7006a9c                                           // 0000009A1480: D7006A9C
	v_cndmask_b32_e32 v1, v95, v25, vcc_lo                     // 0000009A1484: 0202335F
	v_add_co_ci_u32_e64 v157, null, v96, v26, vcc_lo           // 0000009A1488: D5207C9D 01AA3560
	.long 0xd7006a9f                                           // 0000009A1490: D7006A9F
	v_cndmask_b32_e32 v1, v95, v94, vcc_lo                     // 0000009A1494: 0202BD5F
	s_delay_alu instid0(VALU_DEP_1)                            // 0000009A1498: BF870001
	v_add_co_ci_u32_e64 v160, null, 0, v96, vcc_lo             // 0000009A149C: D5207CA0 01AAC080
	s_clause 0x1f                                              // 0000009A14A4: BF85001F
	global_load_b32 v102, v[133:134], off                      // 0000009A14A8: DC520000 667C0085
	global_load_b32 v101, v[133:134], off offset:96            // 0000009A14B0: DC520060 657C0085
	global_load_b32 v100, v[133:134], off offset:192           // 0000009A14B8: DC5200C0 647C0085
	global_load_b32 v99, v[133:134], off offset:288            // 0000009A14C0: DC520120 637C0085
	global_load_b32 v98, v[133:134], off offset:384            // 0000009A14C8: DC520180 627C0085
	global_load_b32 v97, v[133:134], off offset:480            // 0000009A14D0: DC5201E0 617C0085
	global_load_b32 v96, v[133:134], off offset:576            // 0000009A14D8: DC520240 607C0085
	global_load_b32 v95, v[133:134], off offset:672            // 0000009A14E0: DC5202A0 5F7C0085
	global_load_b32 v127, v[141:142], off                      // 0000009A14E8: DC520000 7F7C008D
	global_load_b32 v123, v[141:142], off offset:96            // 0000009A14F0: DC520060 7B7C008D
	global_load_b32 v120, v[141:142], off offset:192           // 0000009A14F8: DC5200C0 787C008D
	global_load_b32 v109, v[141:142], off offset:288           // 0000009A1500: DC520120 6D7C008D
	global_load_b32 v107, v[141:142], off offset:384           // 0000009A1508: DC520180 6B7C008D
	global_load_b32 v105, v[141:142], off offset:480           // 0000009A1510: DC5201E0 697C008D
	global_load_b32 v104, v[141:142], off offset:576           // 0000009A1518: DC520240 687C008D
	global_load_b32 v103, v[141:142], off offset:672           // 0000009A1520: DC5202A0 677C008D
	global_load_b32 v135, v[156:157], off                      // 0000009A1528: DC520000 877C009C
	global_load_b32 v131, v[156:157], off offset:96            // 0000009A1530: DC520060 837C009C
	global_load_b32 v128, v[156:157], off offset:192           // 0000009A1538: DC5200C0 807C009C
	global_load_b32 v124, v[156:157], off offset:288           // 0000009A1540: DC520120 7C7C009C
	global_load_b32 v121, v[156:157], off offset:384           // 0000009A1548: DC520180 797C009C
	global_load_b32 v110, v[156:157], off offset:480           // 0000009A1550: DC5201E0 6E7C009C
	global_load_b32 v108, v[156:157], off offset:576           // 0000009A1558: DC520240 6C7C009C
	global_load_b32 v106, v[156:157], off offset:672           // 0000009A1560: DC5202A0 6A7C009C
	global_load_b32 v143, v[159:160], off                      // 0000009A1568: DC520000 8F7C009F
	global_load_b32 v139, v[159:160], off offset:96            // 0000009A1570: DC520060 8B7C009F
	global_load_b32 v136, v[159:160], off offset:192           // 0000009A1578: DC5200C0 887C009F
	global_load_b32 v132, v[159:160], off offset:288           // 0000009A1580: DC520120 847C009F
	global_load_b32 v129, v[159:160], off offset:384           // 0000009A1588: DC520180 817C009F
	global_load_b32 v125, v[159:160], off offset:480           // 0000009A1590: DC5201E0 7D7C009F
	global_load_b32 v122, v[159:160], off offset:576           // 0000009A1598: DC520240 7A7C009F
	global_load_b32 v119, v[159:160], off offset:672           // 0000009A15A0: DC5202A0 777C009F
	s_clause 0x1f                                              // 0000009A15A8: BF85001F
	global_load_b32 v118, v[133:134], off offset:768           // 0000009A15AC: DC520300 767C0085
	global_load_b32 v117, v[133:134], off offset:864           // 0000009A15B4: DC520360 757C0085
	global_load_b32 v116, v[133:134], off offset:960           // 0000009A15BC: DC5203C0 747C0085
	global_load_b32 v115, v[133:134], off offset:1056          // 0000009A15C4: DC520420 737C0085
	global_load_b32 v114, v[133:134], off offset:1152          // 0000009A15CC: DC520480 727C0085
	global_load_b32 v113, v[133:134], off offset:1248          // 0000009A15D4: DC5204E0 717C0085
	global_load_b32 v112, v[133:134], off offset:1344          // 0000009A15DC: DC520540 707C0085
	global_load_b32 v111, v[133:134], off offset:1440          // 0000009A15E4: DC5205A0 6F7C0085
	global_load_b32 v150, v[141:142], off offset:768           // 0000009A15EC: DC520300 967C008D
	global_load_b32 v147, v[141:142], off offset:864           // 0000009A15F4: DC520360 937C008D
	global_load_b32 v144, v[141:142], off offset:960           // 0000009A15FC: DC5203C0 907C008D
	global_load_b32 v140, v[141:142], off offset:1056          // 0000009A1604: DC520420 8C7C008D
	global_load_b32 v137, v[141:142], off offset:1152          // 0000009A160C: DC520480 897C008D
	global_load_b32 v133, v[141:142], off offset:1248          // 0000009A1614: DC5204E0 857C008D
	global_load_b32 v130, v[141:142], off offset:1344          // 0000009A161C: DC520540 827C008D
	global_load_b32 v126, v[141:142], off offset:1440          // 0000009A1624: DC5205A0 7E7C008D
	global_load_b32 v155, v[156:157], off offset:768           // 0000009A162C: DC520300 9B7C009C
	global_load_b32 v153, v[156:157], off offset:864           // 0000009A1634: DC520360 997C009C
	global_load_b32 v151, v[156:157], off offset:960           // 0000009A163C: DC5203C0 977C009C
	global_load_b32 v148, v[156:157], off offset:1056          // 0000009A1644: DC520420 947C009C
	global_load_b32 v145, v[156:157], off offset:1152          // 0000009A164C: DC520480 917C009C
	global_load_b32 v141, v[156:157], off offset:1248          // 0000009A1654: DC5204E0 8D7C009C
	global_load_b32 v138, v[156:157], off offset:1344          // 0000009A165C: DC520540 8A7C009C
	global_load_b32 v134, v[156:157], off offset:1440          // 0000009A1664: DC5205A0 867C009C
	global_load_b32 v158, v[159:160], off offset:768           // 0000009A166C: DC520300 9E7C009F
	global_load_b32 v157, v[159:160], off offset:864           // 0000009A1674: DC520360 9D7C009F
	global_load_b32 v156, v[159:160], off offset:960           // 0000009A167C: DC5203C0 9C7C009F
	global_load_b32 v154, v[159:160], off offset:1056          // 0000009A1684: DC520420 9A7C009F
	global_load_b32 v152, v[159:160], off offset:1152          // 0000009A168C: DC520480 987C009F
	global_load_b32 v149, v[159:160], off offset:1248          // 0000009A1694: DC5204E0 957C009F
	global_load_b32 v146, v[159:160], off offset:1344          // 0000009A169C: DC520540 927C009F
	global_load_b32 v142, v[159:160], off offset:1440          // 0000009A16A4: DC5205A0 8E7C009F
	s_branch 63532                                             // 0000009A16AC: BFA0F82C <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi1ELi2EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x2960>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000009A16B0: 8C7E007E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000009A16B4: BF870009
	s_or_b32 exec_lo, exec_lo, s1                              // 0000009A16B8: 8C7E017E
	s_waitcnt vmcnt(55)                                        // 0000009A16BC: BF89DFF7
	v_dual_mov_b32 v1, v9 :: v_dual_mov_b32 v2, v87            // 0000009A16C0: CA100109 01020157
	s_waitcnt vmcnt(39)                                        // 0000009A16C8: BF899FF7
	v_dual_mov_b32 v3, v86 :: v_dual_mov_b32 v4, v85           // 0000009A16CC: CA100156 03040155
	s_waitcnt vmcnt(0)                                         // 0000009A16D4: BF8903F7
	v_dual_mov_b32 v7, v84 :: v_dual_mov_b32 v14, v82          // 0000009A16D8: CA100154 070E0152
	v_dual_mov_b32 v11, v83 :: v_dual_mov_b32 v6, v80          // 0000009A16E0: CA100153 0B060150
	v_dual_mov_b32 v5, v81 :: v_dual_mov_b32 v8, v79           // 0000009A16E8: CA100151 0508014F
	v_dual_mov_b32 v12, v78 :: v_dual_mov_b32 v13, v77         // 0000009A16F0: CA10014E 0C0C014D
	v_dual_mov_b32 v15, v76 :: v_dual_mov_b32 v16, v75         // 0000009A16F8: CA10014C 0F10014B
	v_mov_b32_e32 v17, v74                                     // 0000009A1700: 7E22034A
	v_mov_b32_e32 v18, v10                                     // 0000009A1704: 7E24030A
	s_mov_b32 s0, 0x76543210                                   // 0000009A1708: BE8000FF 76543210
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000009A1710: BF870009
	v_permlanex16_b32 v1, v1, s0, 0xfedcba98                   // 0000009A1714: D65C0001 03FC0101 FEDCBA98
	v_permlanex16_b32 v2, v2, s0, 0xfedcba98                   // 0000009A1720: D65C0002 03FC0102 FEDCBA98
	v_permlanex16_b32 v3, v3, s0, 0xfedcba98                   // 0000009A172C: D65C0003 03FC0103 FEDCBA98
	v_permlanex16_b32 v4, v4, s0, 0xfedcba98                   // 0000009A1738: D65C0004 03FC0104 FEDCBA98
	v_permlanex16_b32 v7, v7, s0, 0xfedcba98                   // 0000009A1744: D65C0007 03FC0107 FEDCBA98
	v_permlanex16_b32 v11, v11, s0, 0xfedcba98                 // 0000009A1750: D65C000B 03FC010B FEDCBA98
	v_permlanex16_b32 v14, v14, s0, 0xfedcba98                 // 0000009A175C: D65C000E 03FC010E FEDCBA98
	v_permlanex16_b32 v5, v5, s0, 0xfedcba98                   // 0000009A1768: D65C0005 03FC0105 FEDCBA98
	v_permlanex16_b32 v6, v6, s0, 0xfedcba98                   // 0000009A1774: D65C0006 03FC0106 FEDCBA98
	v_permlanex16_b32 v8, v8, s0, 0xfedcba98                   // 0000009A1780: D65C0008 03FC0108 FEDCBA98
	v_permlanex16_b32 v12, v12, s0, 0xfedcba98                 // 0000009A178C: D65C000C 03FC010C FEDCBA98
	v_permlanex16_b32 v13, v13, s0, 0xfedcba98                 // 0000009A1798: D65C000D 03FC010D FEDCBA98
	v_permlanex16_b32 v15, v15, s0, 0xfedcba98                 // 0000009A17A4: D65C000F 03FC010F FEDCBA98
	v_permlanex16_b32 v16, v16, s0, 0xfedcba98                 // 0000009A17B0: D65C0010 03FC0110 FEDCBA98
	v_permlanex16_b32 v17, v17, s0, 0xfedcba98                 // 0000009A17BC: D65C0011 03FC0111 FEDCBA98
	v_permlanex16_b32 v18, v18, s0, 0xfedcba98                 // 0000009A17C8: D65C0012 03FC0112 FEDCBA98
	.long 0xd44c0000                                           // 0000009A17D4: D44C0000
	v_cndmask_b32_e32 v1, 16, v72, vcc_lo                      // 0000009A17D8: 02029090
	s_barrier                                                  // 0000009A17DC: BFBD0000
	buffer_gl0_inv                                             // 0000009A17E0: E0AC0000 00000000
	s_and_saveexec_b32 s1, s0                                  // 0000009A17E8: BE812000
	s_cbranch_execz 36                                         // 0000009A17EC: BFA50024 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi1ELi2EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x4a80>
	v_dual_add_f32 v10, v10, v18 :: v_dual_add_f32 v1, v9, v1  // 0000009A17F0: C908250A 0A000309
	v_add_f32_e32 v9, v83, v11                                 // 0000009A17F8: 06121753
	v_dual_add_f32 v11, v82, v14 :: v_dual_add_f32 v8, v79, v8 // 0000009A17FC: C9081D52 0B08114F
	v_lshlrev_b32_e32 v14, 2, v72                              // 0000009A1804: 301C9082
	v_dual_add_f32 v2, v87, v2 :: v_dual_add_f32 v3, v86, v3   // 0000009A1808: C9080557 02020756
	v_dual_add_f32 v4, v85, v4 :: v_dual_add_f32 v7, v84, v7   // 0000009A1810: C9080955 04060F54
	s_delay_alu instid0(VALU_DEP_3)                            // 0000009A1818: BF870003
	v_lshl_or_b32 v14, v71, 10, v14                            // 0000009A181C: D656000E 04391547
	v_dual_add_f32 v5, v81, v5 :: v_dual_add_f32 v6, v80, v6   // 0000009A1824: C9080B51 05060D50
	v_dual_add_f32 v12, v78, v12 :: v_dual_add_f32 v13, v77, v13// 0000009A182C: C908194E 0C0C1B4D
	v_dual_add_f32 v15, v76, v15 :: v_dual_add_f32 v16, v75, v16// 0000009A1834: C9081F4C 0F10214B
	v_add_f32_e32 v17, v74, v17                                // 0000009A183C: 0622234A
	ds_store_2addr_b32 v14, v1, v2 offset1:16                  // 0000009A1840: D8381000 0002010E
	ds_store_2addr_b32 v14, v3, v4 offset0:32 offset1:48       // 0000009A1848: D8383020 0004030E
	ds_store_2addr_b32 v14, v7, v9 offset0:64 offset1:80       // 0000009A1850: D8385040 0009070E
	ds_store_2addr_b32 v14, v11, v5 offset0:96 offset1:112     // 0000009A1858: D8387060 00050B0E
	ds_store_2addr_b32 v14, v6, v8 offset0:128 offset1:144     // 0000009A1860: D8389080 0008060E
	ds_store_2addr_b32 v14, v12, v13 offset0:160 offset1:176   // 0000009A1868: D838B0A0 000D0C0E
	ds_store_2addr_b32 v14, v15, v16 offset0:192 offset1:208   // 0000009A1870: D838D0C0 00100F0E
	ds_store_2addr_b32 v14, v17, v10 offset0:224 offset1:240   // 0000009A1878: D838F0E0 000A110E
	s_or_b32 exec_lo, exec_lo, s1                              // 0000009A1880: 8C7E017E
	s_waitcnt lgkmcnt(0)                                       // 0000009A1884: BF89FC07
	s_barrier                                                  // 0000009A1888: BFBD0000
	buffer_gl0_inv                                             // 0000009A188C: E0AC0000 00000000
	s_mov_b32 s1, exec_lo                                      // 0000009A1894: BE81007E
	v_cmpx_eq_u32_e32 0, v71                                   // 0000009A1898: 7D948E80
	s_cbranch_execz 1333                                       // 0000009A189C: BFA50535 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi1ELi2EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x5f74>
	v_and_b32_e32 v3, 15, v0                                   // 0000009A18A0: 3606008F
	s_mul_i32 s1, s4, 0xa00                                    // 0000009A18A4: 9601FF04 00000A00
	s_mul_hi_i32 s2, s4, 0xa00                                 // 0000009A18AC: 9702FF04 00000A00
	s_add_u32 s1, s18, s1                                      // 0000009A18B4: 80010112
	s_addc_u32 s7, s19, s2                                     // 0000009A18B8: 82070213
	v_lshlrev_b32_e32 v4, 2, v3                                // 0000009A18BC: 30080682
	s_lshl_b32 s2, s5, 7                                       // 0000009A18C0: 84028705
	ds_load_2addr_b32 v[1:2], v4 offset1:16                    // 0000009A18C4: D8DC1000 01000004
	ds_load_2addr_b32 v[5:6], v4 offset0:128 offset1:144       // 0000009A18CC: D8DC9080 05000004
	s_ashr_i32 s3, s2, 31                                      // 0000009A18D4: 86039F02
	v_lshlrev_b32_e32 v52, 1, v0                               // 0000009A18D8: 30680081
	s_lshl_b64 s[12:13], s[2:3], 1                             // 0000009A18DC: 848C8102
	s_mul_hi_i32 s2, s4, 0x500                                 // 0000009A18E0: 9702FF04 00000500
	s_add_u32 s6, s1, s12                                      // 0000009A18E8: 80060C01
	s_addc_u32 s7, s7, s13                                     // 0000009A18EC: 82070D07
	s_mul_i32 s1, s4, 0x500                                    // 0000009A18F0: 9601FF04 00000500
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000009A18F8: BF870009
	s_add_u32 s1, s20, s1                                      // 0000009A18FC: 80010114
	s_addc_u32 s2, s21, s2                                     // 0000009A1900: 82020215
	s_add_u32 s8, s1, s12                                      // 0000009A1904: 80080C01
	s_addc_u32 s9, s2, s13                                     // 0000009A1908: 82090D02
	s_waitcnt lgkmcnt(1)                                       // 0000009A190C: BF89FC17
	v_add_f32_e32 v1, 0, v1                                    // 0000009A1910: 06020280
	v_add_nc_u32_e32 v45, 0x400, v4                            // 0000009A1914: 4A5A08FF 00000400
	s_waitcnt lgkmcnt(0)                                       // 0000009A191C: BF89FC07
	v_dual_add_f32 v5, 0, v5 :: v_dual_add_nc_u32 v46, 0x800, v4// 0000009A1920: C9200A80 052E08FF 00000800
	v_add_nc_u32_e32 v47, 0xc00, v4                            // 0000009A192C: 4A5E08FF 00000C00
	v_add_nc_u32_e32 v48, 0x1000, v4                           // 0000009A1934: 4A6008FF 00001000
	v_add_nc_u32_e32 v49, 0x1400, v4                           // 0000009A193C: 4A6208FF 00001400
	v_add_nc_u32_e32 v50, 0x1800, v4                           // 0000009A1944: 4A6408FF 00001800
	v_add_nc_u32_e32 v51, 0x1c00, v4                           // 0000009A194C: 4A6608FF 00001C00
	ds_load_2addr_b32 v[7:8], v45 offset1:16                   // 0000009A1954: D8DC1000 0700002D
	ds_load_2addr_b32 v[9:10], v4 offset0:32 offset1:48        // 0000009A195C: D8DC3020 09000004
	ds_load_2addr_b32 v[11:12], v4 offset0:160 offset1:176     // 0000009A1964: D8DCB0A0 0B000004
	ds_load_2addr_b32 v[13:14], v45 offset0:128 offset1:144    // 0000009A196C: D8DC9080 0D00002D
	ds_load_2addr_b32 v[15:16], v46 offset1:16                 // 0000009A1974: D8DC1000 0F00002E
	ds_load_2addr_b32 v[17:18], v46 offset0:128 offset1:144    // 0000009A197C: D8DC9080 1100002E
	ds_load_2addr_b32 v[19:20], v47 offset1:16                 // 0000009A1984: D8DC1000 1300002F
	ds_load_2addr_b32 v[21:22], v47 offset0:128 offset1:144    // 0000009A198C: D8DC9080 1500002F
	ds_load_2addr_b32 v[23:24], v48 offset1:16                 // 0000009A1994: D8DC1000 17000030
	ds_load_2addr_b32 v[25:26], v48 offset0:128 offset1:144    // 0000009A199C: D8DC9080 19000030
	ds_load_2addr_b32 v[27:28], v49 offset1:16                 // 0000009A19A4: D8DC1000 1B000031
	ds_load_2addr_b32 v[29:30], v49 offset0:128 offset1:144    // 0000009A19AC: D8DC9080 1D000031
	ds_load_2addr_b32 v[31:32], v50 offset1:16                 // 0000009A19B4: D8DC1000 1F000032
	ds_load_2addr_b32 v[33:34], v50 offset0:128 offset1:144    // 0000009A19BC: D8DC9080 21000032
	ds_load_2addr_b32 v[35:36], v51 offset1:16                 // 0000009A19C4: D8DC1000 23000033
	v_add_f32_e32 v2, 0, v2                                    // 0000009A19CC: 06040480
	ds_load_2addr_b32 v[43:44], v46 offset0:32 offset1:48      // 0000009A19D0: D8DC3020 2B00002E
	s_waitcnt lgkmcnt(15)                                      // 0000009A19D8: BF89FCF7
	v_add_f32_e32 v1, v1, v7                                   // 0000009A19DC: 06020F01
	v_dual_add_f32 v7, 0, v6 :: v_dual_add_f32 v2, v2, v8      // 0000009A19E0: C9080C80 07021102
	s_waitcnt lgkmcnt(12)                                      // 0000009A19E8: BF89FCC7
	v_add_f32_e32 v13, v5, v13                                 // 0000009A19EC: 061A1B05
	ds_load_2addr_b32 v[5:6], v46 offset0:160 offset1:176      // 0000009A19F0: D8DCB0A0 0500002E
	s_waitcnt lgkmcnt(12)                                      // 0000009A19F8: BF89FCC7
	v_dual_add_f32 v1, v1, v15 :: v_dual_add_f32 v14, v7, v14  // 0000009A19FC: C9081F01 010E1D07
	s_waitcnt lgkmcnt(11)                                      // 0000009A1A04: BF89FCB7
	v_dual_add_f32 v2, v2, v16 :: v_dual_add_f32 v13, v13, v17 // 0000009A1A08: C9082102 020C230D
	ds_load_2addr_b32 v[15:16], v48 offset0:32 offset1:48      // 0000009A1A10: D8DC3020 0F000030
	v_add_f32_e32 v14, v14, v18                                // 0000009A1A18: 061C250E
	s_waitcnt lgkmcnt(11)                                      // 0000009A1A1C: BF89FCB7
	v_dual_add_f32 v2, v2, v20 :: v_dual_add_f32 v1, v1, v19   // 0000009A1A20: C9082902 02002701
	ds_load_2addr_b32 v[7:8], v47 offset0:32 offset1:48        // 0000009A1A28: D8DC3020 0700002F
	ds_load_2addr_b32 v[17:18], v48 offset0:160 offset1:176    // 0000009A1A30: D8DCB0A0 11000030
	s_waitcnt lgkmcnt(12)                                      // 0000009A1A38: BF89FCC7
	v_add_f32_e32 v14, v14, v22                                // 0000009A1A3C: 061C2D0E
	s_waitcnt lgkmcnt(11)                                      // 0000009A1A40: BF89FCB7
	v_dual_add_f32 v2, v2, v24 :: v_dual_add_f32 v1, v1, v23   // 0000009A1A44: C9083102 02002F01
	ds_load_2addr_b32 v[19:20], v49 offset0:32 offset1:48      // 0000009A1A4C: D8DC3020 13000031
	s_waitcnt lgkmcnt(11)                                      // 0000009A1A54: BF89FCB7
	v_add_f32_e32 v14, v14, v26                                // 0000009A1A58: 061C350E
	ds_load_2addr_b32 v[37:38], v51 offset0:128 offset1:144    // 0000009A1A5C: D8DC9080 25000033
	ds_load_2addr_b32 v[39:40], v45 offset0:32 offset1:48      // 0000009A1A64: D8DC3020 2700002D
	ds_load_2addr_b32 v[41:42], v45 offset0:160 offset1:176    // 0000009A1A6C: D8DCB0A0 2900002D
	v_add_f32_e32 v13, v13, v21                                // 0000009A1A74: 061A2B0D
	s_waitcnt lgkmcnt(13)                                      // 0000009A1A78: BF89FCD7
	v_add_f32_e32 v1, v1, v27                                  // 0000009A1A7C: 06023701
	v_add_f32_e32 v23, v2, v28                                 // 0000009A1A80: 062E3902
	s_waitcnt lgkmcnt(12)                                      // 0000009A1A84: BF89FCC7
	v_dual_add_f32 v24, v14, v30 :: v_dual_add_f32 v9, 0, v9   // 0000009A1A88: C9083D0E 18081280
	ds_load_2addr_b32 v[21:22], v49 offset0:160 offset1:176    // 0000009A1A90: D8DCB0A0 15000031
	v_add_f32_e32 v11, 0, v11                                  // 0000009A1A98: 06161680
	s_waitcnt lgkmcnt(11)                                      // 0000009A1A9C: BF89FCB7
	v_dual_add_f32 v1, v1, v31 :: v_dual_add_f32 v26, v24, v34 // 0000009A1AA0: C9083F01 011A4518
	s_waitcnt lgkmcnt(3)                                       // 0000009A1AA8: BF89FC37
	s_delay_alu instid0(VALU_DEP_1)                            // 0000009A1AAC: BF870001
	v_dual_add_f32 v13, v13, v25 :: v_dual_add_f32 v54, v26, v38// 0000009A1AB0: C908330D 0D364D1A
	s_waitcnt lgkmcnt(2)                                       // 0000009A1AB8: BF89FC27
	v_add_f32_e32 v9, v9, v39                                  // 0000009A1ABC: 06124F09
	v_add_f32_e32 v39, v1, v35                                 // 0000009A1AC0: 064E4701
	v_lshlrev_b32_e32 v1, 1, v3                                // 0000009A1AC4: 30020681
	s_waitcnt lgkmcnt(1)                                       // 0000009A1AC8: BF89FC17
	v_add_f32_e32 v3, v11, v41                                 // 0000009A1ACC: 0606530B
	v_add_f32_e32 v11, v23, v32                                // 0000009A1AD0: 06164117
	v_add_f32_e32 v9, v9, v43                                  // 0000009A1AD4: 06125709
	ds_load_2addr_b32 v[23:24], v50 offset0:32 offset1:48      // 0000009A1AD8: D8DC3020 17000032
	v_or_b32_e32 v41, 32, v52                                  // 0000009A1AE0: 385268A0
	v_add_f32_e32 v5, v3, v5                                   // 0000009A1AE4: 060A0B03
	v_add_f32_e32 v53, v11, v36                                // 0000009A1AE8: 066A490B
	v_add_f32_e32 v7, v9, v7                                   // 0000009A1AEC: 060E0F09
	global_load_d16_b16 v3, v41, s[6:7]                        // 0000009A1AF0: DC820000 03060029
	v_add_f32_e32 v7, v7, v15                                  // 0000009A1AF8: 060E1F07
	v_add_f32_e32 v15, 0, v12                                  // 0000009A1AFC: 061E1880
	ds_load_2addr_b32 v[11:12], v4 offset0:192 offset1:208     // 0000009A1B00: D8DCD0C0 0B000004
	ds_load_2addr_b32 v[27:28], v51 offset0:32 offset1:48      // 0000009A1B08: D8DC3020 1B000033
	v_add_f32_e32 v7, v7, v19                                  // 0000009A1B10: 060E2707
	s_waitcnt lgkmcnt(2)                                       // 0000009A1B14: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000009A1B18: BF870001
	v_add_f32_e32 v19, v7, v23                                 // 0000009A1B1C: 06262F07
	v_add_f32_e32 v13, v13, v29                                // 0000009A1B20: 061A3B0D
	ds_load_2addr_b32 v[29:30], v45 offset0:64 offset1:80      // 0000009A1B24: D8DC5040 1D00002D
	ds_load_2addr_b32 v[31:32], v45 offset0:192 offset1:208    // 0000009A1B2C: D8DCD0C0 1F00002D
	v_add_f32_e32 v25, v13, v33                                // 0000009A1B34: 0632430D
	ds_load_2addr_b32 v[13:14], v47 offset0:160 offset1:176    // 0000009A1B38: D8DCB0A0 0D00002F
	s_waitcnt lgkmcnt(4)                                       // 0000009A1B40: BF89FC47
	v_add_f32_e32 v11, 0, v11                                  // 0000009A1B44: 06161680
	v_add_f32_e32 v43, v25, v37                                // 0000009A1B48: 06564B19
	ds_load_2addr_b32 v[25:26], v50 offset0:160 offset1:176    // 0000009A1B4C: D8DCB0A0 19000032
	ds_load_2addr_b32 v[37:38], v48 offset0:192 offset1:208    // 0000009A1B54: D8DCD0C0 25000030
	s_waitcnt lgkmcnt(3)                                       // 0000009A1B5C: BF89FC37
	v_add_f32_e32 v11, v11, v31                                // 0000009A1B60: 06163F0B
	s_waitcnt lgkmcnt(2)                                       // 0000009A1B64: BF89FC27
	v_add_f32_e32 v5, v5, v13                                  // 0000009A1B68: 060A1B05
	v_add_f32_e32 v13, 0, v10                                  // 0000009A1B6C: 061A1480
	ds_load_2addr_b32 v[9:10], v4 offset0:64 offset1:80        // 0000009A1B70: D8DC5040 09000004
	v_add_f32_e32 v5, v5, v17                                  // 0000009A1B78: 060A2305
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000009A1B7C: BF8701C1
	v_add_f32_e32 v17, v5, v21                                 // 0000009A1B80: 06222B05
	v_add_f32_e32 v5, v13, v40                                 // 0000009A1B84: 060A510D
	v_add_f32_e32 v13, v15, v42                                // 0000009A1B88: 061A550F
	s_waitcnt lgkmcnt(2)                                       // 0000009A1B8C: BF89FC27
	v_dual_add_f32 v40, v19, v27 :: v_dual_add_f32 v21, v17, v25// 0000009A1B90: C9083713 28143311
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009A1B98: BF870193
	v_add_f32_e32 v7, v5, v44                                  // 0000009A1B9C: 060E5905
	v_add_f32_e32 v13, v13, v6                                 // 0000009A1BA0: 061A0D0D
	ds_load_2addr_b32 v[5:6], v46 offset0:64 offset1:80        // 0000009A1BA4: D8DC5040 0500002E
	ds_load_2addr_b32 v[33:34], v46 offset0:192 offset1:208    // 0000009A1BAC: D8DCD0C0 2100002E
	ds_load_2addr_b32 v[35:36], v51 offset0:160 offset1:176    // 0000009A1BB4: D8DCB0A0 23000033
	v_add_f32_e32 v15, v7, v8                                  // 0000009A1BBC: 061E1107
	ds_load_2addr_b32 v[7:8], v47 offset0:64 offset1:80        // 0000009A1BC0: D8DC5040 0700002F
	v_add_f32_e32 v17, v13, v14                                // 0000009A1BC8: 06221D0D
	ds_load_2addr_b32 v[13:14], v47 offset0:192 offset1:208    // 0000009A1BCC: D8DCD0C0 0D00002F
	s_waitcnt lgkmcnt(5)                                       // 0000009A1BD4: BF89FC57
	v_add_f32_e32 v9, 0, v9                                    // 0000009A1BD8: 06121280
	v_add_f32_e32 v23, v15, v16                                // 0000009A1BDC: 062E210F
	ds_load_2addr_b32 v[15:16], v48 offset0:64 offset1:80      // 0000009A1BE0: D8DC5040 0F000030
	v_add_f32_e32 v17, v17, v18                                // 0000009A1BE8: 06222511
	v_add_f32_e32 v9, v9, v29                                  // 0000009A1BEC: 06123B09
	v_add_f32_e32 v23, v23, v20                                // 0000009A1BF0: 062E2917
	ds_load_2addr_b32 v[19:20], v49 offset0:192 offset1:208    // 0000009A1BF4: D8DCD0C0 13000031
	v_add_f32_e32 v22, v17, v22                                // 0000009A1BFC: 062C2D11
	ds_load_2addr_b32 v[17:18], v49 offset0:64 offset1:80      // 0000009A1C00: D8DC5040 11000031
	s_waitcnt lgkmcnt(7)                                       // 0000009A1C08: BF89FC77
	v_add_f32_e32 v5, v9, v5                                   // 0000009A1C0C: 060A0B09
	s_waitcnt lgkmcnt(5)                                       // 0000009A1C10: BF89FC57
	v_dual_add_f32 v9, v11, v33 :: v_dual_add_f32 v42, v21, v35// 0000009A1C14: C908430B 092A4715
	v_add_f32_e32 v27, v23, v24                                // 0000009A1C1C: 06363117
	v_add_f32_e32 v33, v22, v26                                // 0000009A1C20: 06423516
	ds_load_2addr_b32 v[21:22], v50 offset0:64 offset1:80      // 0000009A1C24: D8DC5040 15000032
	ds_load_2addr_b32 v[23:24], v50 offset0:192 offset1:208    // 0000009A1C2C: D8DCD0C0 17000032
	s_waitcnt lgkmcnt(6)                                       // 0000009A1C34: BF89FC67
	v_add_f32_e32 v5, v5, v7                                   // 0000009A1C38: 060A0F05
	s_waitcnt lgkmcnt(5)                                       // 0000009A1C3C: BF89FC57
	v_add_f32_e32 v7, v9, v13                                  // 0000009A1C40: 060E1B09
	s_waitcnt lgkmcnt(4)                                       // 0000009A1C44: BF89FC47
	s_delay_alu instid0(VALU_DEP_2)                            // 0000009A1C48: BF870002
	v_add_f32_e32 v13, v5, v15                                 // 0000009A1C4C: 061A1F05
	v_add_f32_e32 v5, 0, v10                                   // 0000009A1C50: 060A1480
	ds_load_2addr_b32 v[9:10], v51 offset0:64 offset1:80       // 0000009A1C54: D8DC5040 09000033
	ds_load_2addr_b32 v[25:26], v51 offset0:192 offset1:208    // 0000009A1C5C: D8DCD0C0 19000033
	v_add_f32_e32 v7, v7, v37                                  // 0000009A1C64: 060E4B07
	v_add_f32_e32 v15, 0, v12                                  // 0000009A1C68: 061E1880
	ds_load_2addr_b32 v[11:12], v4 offset0:96 offset1:112      // 0000009A1C6C: D8DC7060 0B000004
	v_add_f32_e32 v31, v5, v30                                 // 0000009A1C74: 063E3D05
	ds_load_2addr_b32 v[29:30], v4 offset0:224 offset1:240     // 0000009A1C78: D8DCF0E0 1D000004
	s_waitcnt lgkmcnt(6)                                       // 0000009A1C80: BF89FC67
	v_dual_add_f32 v13, v13, v17 :: v_dual_add_f32 v4, v15, v32// 0000009A1C84: C908230D 0D04410F
	v_add_f32_e32 v15, v7, v19                                 // 0000009A1C8C: 061E2707
	v_add_f32_e32 v17, v31, v6                                 // 0000009A1C90: 06220D1F
	ds_load_2addr_b32 v[6:7], v45 offset0:96 offset1:112       // 0000009A1C94: D8DC7060 0600002D
	ds_load_2addr_b32 v[31:32], v45 offset0:224 offset1:240    // 0000009A1C9C: D8DCF0E0 1F00002D
	s_waitcnt lgkmcnt(7)                                       // 0000009A1CA4: BF89FC77
	v_dual_add_f32 v13, v13, v21 :: v_dual_add_f32 v4, v4, v34 // 0000009A1CA8: C9082B0D 0D044504
	s_waitcnt lgkmcnt(6)                                       // 0000009A1CB0: BF89FC67
	v_dual_add_f32 v15, v15, v23 :: v_dual_add_f32 v8, v17, v8 // 0000009A1CB4: C9082F0F 0F081111
	s_clause 0x1                                               // 0000009A1CBC: BF850001
	global_load_d16_b16 v2, v1, s[6:7]                         // 0000009A1CC0: DC820000 02060001
	global_load_d16_b16 v5, v1, s[6:7] offset:64               // 0000009A1CC8: DC820040 05060001
	v_dual_add_f32 v4, v4, v14 :: v_dual_add_f32 v37, v27, v28 // 0000009A1CD0: C9081D04 0424391B
	s_waitcnt lgkmcnt(5)                                       // 0000009A1CD8: BF89FC57
	v_add_f32_e32 v23, v13, v9                                 // 0000009A1CDC: 062E130D
	s_waitcnt lgkmcnt(4)                                       // 0000009A1CE0: BF89FC47
	v_dual_add_f32 v25, v15, v25 :: v_dual_add_f32 v8, v8, v16 // 0000009A1CE4: C908330F 19082108
	ds_load_2addr_b32 v[13:14], v46 offset0:96 offset1:112     // 0000009A1CEC: D8DC7060 0D00002E
	ds_load_2addr_b32 v[15:16], v46 offset0:224 offset1:240    // 0000009A1CF4: D8DCF0E0 0F00002E
	v_add_f32_e32 v9, v4, v38                                  // 0000009A1CFC: 06124D04
	s_waitcnt lgkmcnt(5)                                       // 0000009A1D00: BF89FC57
	v_add_f32_e32 v11, 0, v11                                  // 0000009A1D04: 06161680
	s_waitcnt lgkmcnt(4)                                       // 0000009A1D08: BF89FC47
	v_dual_add_f32 v17, 0, v29 :: v_dual_add_f32 v38, v8, v18  // 0000009A1D0C: C9083A80 11262508
	v_add_f32_e32 v21, v33, v36                                // 0000009A1D14: 062A4921
	v_add_f32_e32 v44, v9, v20                                 // 0000009A1D18: 06582909
	s_waitcnt lgkmcnt(2)                                       // 0000009A1D1C: BF89FC27
	s_delay_alu instid0(VALU_DEP_3)                            // 0000009A1D20: BF870003
	v_dual_add_f32 v8, v11, v6 :: v_dual_add_f32 v11, v17, v31 // 0000009A1D24: C9080D0B 080A3F11
	ds_load_2addr_b32 v[17:18], v47 offset0:96 offset1:112     // 0000009A1D2C: D8DC7060 1100002F
	ds_load_2addr_b32 v[19:20], v47 offset0:224 offset1:240    // 0000009A1D34: D8DCF0E0 1300002F
	ds_load_2addr_b32 v[27:28], v48 offset0:96 offset1:112     // 0000009A1D3C: D8DC7060 1B000030
	ds_load_2addr_b32 v[33:34], v48 offset0:224 offset1:240    // 0000009A1D44: D8DCF0E0 21000030
	v_add_f32_e32 v31, 0, v12                                  // 0000009A1D4C: 063E1880
	v_add_f32_e32 v35, 0, v30                                  // 0000009A1D50: 06463C80
	s_clause 0x1                                               // 0000009A1D54: BF850001
	global_load_d16_b16 v6, v41, s[6:7] offset:1280            // 0000009A1D58: DC820500 06060029
	global_load_d16_b16 v4, v1, s[6:7] offset:1280             // 0000009A1D60: DC820500 04060001
	v_or_b32_e32 v45, 0x60, v52                                // 0000009A1D68: 385A68FF 00000060
	v_add_f32_e32 v7, v31, v7                                  // 0000009A1D70: 060E0F1F
	s_waitcnt lgkmcnt(5)                                       // 0000009A1D74: BF89FC57
	v_add_f32_e32 v13, v8, v13                                 // 0000009A1D78: 061A1B08
	global_load_d16_b16 v8, v41, s[8:9]                        // 0000009A1D7C: DC820000 08080029
	s_waitcnt lgkmcnt(4)                                       // 0000009A1D84: BF89FC47
	v_add_f32_e32 v15, v11, v15                                // 0000009A1D88: 061E1F0B
	ds_load_2addr_b32 v[11:12], v49 offset0:96 offset1:112     // 0000009A1D8C: D8DC7060 0B000031
	ds_load_2addr_b32 v[29:30], v49 offset0:224 offset1:240    // 0000009A1D94: D8DCF0E0 1D000031
	v_add_f32_e32 v41, v35, v32                                // 0000009A1D9C: 06524123
	ds_load_2addr_b32 v[31:32], v50 offset0:96 offset1:112     // 0000009A1DA0: D8DC7060 1F000032
	ds_load_2addr_b32 v[35:36], v50 offset0:224 offset1:240    // 0000009A1DA8: D8DCF0E0 23000032
	v_add_f32_e32 v7, v7, v14                                  // 0000009A1DB0: 060E1D07
	global_load_d16_b16 v9, v45, s[6:7]                        // 0000009A1DB4: DC820000 0906002D
	v_add_f32_e32 v41, v41, v16                                // 0000009A1DBC: 06522129
	s_waitcnt lgkmcnt(7)                                       // 0000009A1DC0: BF89FC77
	v_add_f32_e32 v17, v13, v17                                // 0000009A1DC4: 0622230D
	s_waitcnt lgkmcnt(6)                                       // 0000009A1DC8: BF89FC67
	v_add_f32_e32 v19, v15, v19                                // 0000009A1DCC: 0626270F
	ds_load_2addr_b32 v[13:14], v51 offset0:96 offset1:112     // 0000009A1DD0: D8DC7060 0D000033
	ds_load_2addr_b32 v[15:16], v51 offset0:224 offset1:240    // 0000009A1DD8: D8DCF0E0 0F000033
	v_dual_add_f32 v7, v7, v18 :: v_dual_add_f32 v18, v41, v20 // 0000009A1DE0: C9082507 07122929
	s_waitcnt lgkmcnt(7)                                       // 0000009A1DE8: BF89FC77
	v_add_f32_e32 v17, v17, v27                                // 0000009A1DEC: 06223711
	s_waitcnt lgkmcnt(6)                                       // 0000009A1DF0: BF89FC67
	v_dual_add_f32 v19, v19, v33 :: v_dual_add_f32 v20, v38, v22// 0000009A1DF4: C9084313 13142D26
	v_dual_add_f32 v7, v7, v28 :: v_dual_add_f32 v18, v18, v34 // 0000009A1DFC: C9083907 07124512
	v_add_f32_e32 v22, v44, v24                                // 0000009A1E04: 062C312C
	v_or_b32_e32 v28, 0xa0, v52                                // 0000009A1E08: 383868FF 000000A0
	s_waitcnt lgkmcnt(5)                                       // 0000009A1E10: BF89FC57
	v_add_f32_e32 v11, v17, v11                                // 0000009A1E14: 06161711
	s_waitcnt lgkmcnt(4)                                       // 0000009A1E18: BF89FC47
	v_add_f32_e32 v17, v19, v29                                // 0000009A1E1C: 06223B13
	v_dual_add_f32 v7, v7, v12 :: v_dual_add_f32 v12, v18, v30 // 0000009A1E20: C9081907 070C3D12
	s_waitcnt lgkmcnt(3)                                       // 0000009A1E28: BF89FC37
	v_dual_add_f32 v10, v20, v10 :: v_dual_add_f32 v11, v11, v31// 0000009A1E2C: C9081514 0A0A3F0B
	s_waitcnt lgkmcnt(2)                                       // 0000009A1E34: BF89FC27
	v_dual_add_f32 v17, v17, v35 :: v_dual_add_f32 v18, v22, v26// 0000009A1E38: C9084711 11123516
	v_add_f32_e32 v12, v12, v36                                // 0000009A1E40: 0618490C
	v_add_f32_e32 v7, v7, v32                                  // 0000009A1E44: 060E4107
	s_waitcnt lgkmcnt(1)                                       // 0000009A1E48: BF89FC17
	v_add_f32_e32 v11, v11, v13                                // 0000009A1E4C: 06161B0B
	s_waitcnt lgkmcnt(0)                                       // 0000009A1E50: BF89FC07
	v_add_f32_e32 v13, v17, v15                                // 0000009A1E54: 061A1F11
	v_dual_add_f32 v19, v23, v10 :: v_dual_add_f32 v12, v12, v16// 0000009A1E58: C9081517 130C210C
	v_sub_f32_e32 v10, v23, v10                                // 0000009A1E60: 08141517
	v_dual_add_f32 v22, v43, v54 :: v_dual_add_f32 v23, v42, v21// 0000009A1E64: C9086D2B 16162B2A
	v_add_f32_e32 v24, v25, v18                                // 0000009A1E6C: 06302519
	s_delay_alu instid0(VALU_DEP_4)                            // 0000009A1E70: BF870004
	v_add_f32_e32 v27, v13, v12                                // 0000009A1E74: 0636190D
	v_add_f32_e32 v7, v7, v14                                  // 0000009A1E78: 060E1D07
	v_sub_f32_e32 v15, v39, v53                                // 0000009A1E7C: 081E6B27
	v_add_f32_e32 v16, v40, v37                                // 0000009A1E80: 06204B28
	v_dual_sub_f32 v17, v40, v37 :: v_dual_add_f32 v30, v22, v23// 0000009A1E84: C9484B28 111E2F16
	v_add_f32_e32 v31, v24, v27                                // 0000009A1E8C: 063E3718
	v_dual_add_f32 v20, v11, v7 :: v_dual_and_b32 v37, 1, v0   // 0000009A1E90: C9240F0B 14240081
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000009A1E98: BF870223
	v_add_f32_e32 v36, v15, v17                                // 0000009A1E9C: 0648230F
	v_sub_f32_e32 v15, v15, v17                                // 0000009A1EA0: 081E230F
	v_add_f32_e32 v17, v30, v31                                // 0000009A1EA4: 06223F1E
	s_delay_alu instid0(VALU_DEP_4)                            // 0000009A1EA8: BF870004
	.long 0xd44a0002                                           // 0000009A1EAC: D44A0002
	v_cndmask_b32_e32 v1, 0, v37, vcc_lo                       // 0000009A1EB0: 02024A80
	v_add_f32_e32 v14, v39, v53                                // 0000009A1EB4: 061C6B27
	v_add_f32_e32 v39, v19, v20                                // 0000009A1EB8: 064E2913
	v_sub_f32_e32 v19, v19, v20                                // 0000009A1EBC: 08262913
	v_mov_b32_dpp v20, v17 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009A1EC0: 7E2802FA FF016111
	v_cndmask_b32_e64 v17, -v17, v17, s2                       // 0000009A1EC8: D5010011 200A2311
	v_sub_f32_e32 v37, v43, v54                                // 0000009A1ED0: 084A6D2B
	v_dual_sub_f32 v21, v42, v21 :: v_dual_sub_f32 v18, v25, v18// 0000009A1ED4: C94A2B2A 15122519
	v_dual_sub_f32 v12, v13, v12 :: v_dual_sub_f32 v11, v11, v7// 0000009A1EDC: C94A190D 0C0A0F0B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000009A1EE4: BF8701A4
	v_add_f32_e32 v13, v17, v20                                // 0000009A1EE8: 061A2911
	v_and_b32_e32 v17, 2, v0                                   // 0000009A1EEC: 36220082
	v_dual_add_f32 v25, v37, v21 :: v_dual_add_f32 v40, v18, v12// 0000009A1EF0: C9082B25 19281912
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000009A1EF8: BF870224
	v_add_f32_e32 v20, v10, v11                                // 0000009A1EFC: 0628170A
	v_sub_f32_e32 v10, v10, v11                                // 0000009A1F00: 0814170A
	.long 0xd44a0003                                           // 0000009A1F04: D44A0003
	v_cndmask_b32_e32 v1, 0, v17, vcc_lo                       // 0000009A1F08: 02022280
	v_sub_f32_e32 v17, v22, v23                                // 0000009A1F0C: 08222F16
	v_dual_add_f32 v11, v25, v40 :: v_dual_sub_f32 v22, v24, v27// 0000009A1F10: C90A5119 0B163718
	v_and_b32_e32 v23, 4, v0                                   // 0000009A1F18: 362E0084
	v_mov_b32_dpp v41, v13 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009A1F1C: 7E5202FA FF01620D
	v_cndmask_b32_e64 v13, -v13, v13, s3                       // 0000009A1F24: D501000D 200E1B0D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 0000009A1F2C: BF870254
	v_mov_b32_dpp v24, v11 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009A1F30: 7E3002FA FF01610B
	v_cndmask_b32_e64 v11, -v11, v11, s2                       // 0000009A1F38: D501000B 200A170B
	v_add_f32_e32 v27, v17, v22                                // 0000009A1F40: 06362D11
	.long 0xd44a0004                                           // 0000009A1F44: D44A0004
	v_cndmask_b32_e32 v1, 0, v23, vcc_lo                       // 0000009A1F48: 02022E80
	v_dual_add_f32 v13, v13, v41 :: v_dual_and_b32 v0, 8, v0   // 0000009A1F4C: C924530D 0D000088
	v_add_f32_e32 v11, v11, v24                                // 0000009A1F54: 0616310B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000009A1F58: BF870224
	v_mov_b32_dpp v23, v27 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009A1F5C: 7E2E02FA FF01611B
	v_cndmask_b32_e64 v24, -v27, v27, s2                       // 0000009A1F64: D5010018 200A371B
	.long 0xd44a0001                                           // 0000009A1F6C: D44A0001
	v_cndmask_b32_e32 v1, 0, v0, vcc_lo                        // 0000009A1F70: 02020080
	v_sub_f32_e32 v0, v37, v21                                 // 0000009A1F74: 08002B25
	v_mov_b32_dpp v27, v11 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009A1F78: 7E3602FA FF01620B
	v_cndmask_b32_e64 v11, -v11, v11, s3                       // 0000009A1F80: D501000B 200E170B
	v_dual_add_f32 v23, v24, v23 :: v_dual_sub_f32 v12, v18, v12// 0000009A1F88: C90A2F18 170C1912
	v_mov_b32_dpp v41, v13 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009A1F90: 7E5202FA FF01640D
	v_cndmask_b32_e64 v13, -v13, v13, s4                       // 0000009A1F98: D501000D 20121B0D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009A1FA0: BF870214
	v_add_f32_e32 v11, v11, v27                                // 0000009A1FA4: 0616370B
	v_mov_b32_dpp v18, v23 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009A1FA8: 7E2402FA FF016217
	v_cndmask_b32_e64 v21, -v23, v23, s3                       // 0000009A1FB0: D5010015 200E2F17
	v_sub_f32_e32 v24, v25, v40                                // 0000009A1FB8: 08305119
	v_add_f32_e32 v13, v13, v41                                // 0000009A1FBC: 061A530D
	v_mov_b32_dpp v25, v11 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009A1FC0: 7E3202FA FF01640B
	v_cndmask_b32_e64 v11, -v11, v11, s4                       // 0000009A1FC8: D501000B 2012170B
	v_dual_add_f32 v18, v21, v18 :: v_dual_add_f32 v21, v0, v12// 0000009A1FD0: C9082515 12141900
	v_sub_f32_e32 v23, v30, v31                                // 0000009A1FD8: 082E3F1E
	v_sub_f32_e32 v17, v17, v22                                // 0000009A1FDC: 08222D11
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009A1FE0: BF870214
	v_add_f32_e32 v11, v11, v25                                // 0000009A1FE4: 0616330B
	v_mov_b32_dpp v25, v18 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009A1FE8: 7E3202FA FF016412
	v_cndmask_b32_e64 v18, -v18, v18, s4                       // 0000009A1FF0: D5010012 20122512
	v_mov_b32_dpp v30, v21 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009A1FF8: 7E3C02FA FF016115
	v_cndmask_b32_e64 v21, -v21, v21, s2                       // 0000009A2000: D5010015 200A2B15
	v_mov_b32_dpp v22, v13 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009A2008: 7E2C02FA FF01680D
	v_cndmask_b32_e64 v13, -v13, v13, s1                       // 0000009A2010: D501000D 20061B0D
	v_add_f32_e32 v18, v18, v25                                // 0000009A2018: 06243312
	v_add_f32_e32 v29, v14, v16                                // 0000009A201C: 063A210E
	v_dual_add_f32 v21, v21, v30 :: v_dual_sub_f32 v14, v14, v16// 0000009A2020: C90A3D15 150E210E
	v_or_b32_e32 v16, 0xe0, v52                                // 0000009A2028: 382068FF 000000E0
	v_sub_f32_e32 v0, v0, v12                                  // 0000009A2030: 08001900
	v_add_f32_e32 v12, v13, v22                                // 0000009A2034: 06182D0D
	v_mov_b32_dpp v13, v18 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009A2038: 7E1A02FA FF016812
	v_mov_b32_dpp v22, v21 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009A2040: 7E2C02FA FF016215
	v_cndmask_b32_e64 v21, -v21, v21, s3                       // 0000009A2048: D5010015 200E2B15
	v_cndmask_b32_e64 v18, -v18, v18, s1                       // 0000009A2050: D5010012 20062512
	v_mov_b32_dpp v25, v23 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009A2058: 7E3202FA FF016117
	v_cndmask_b32_e64 v23, -v23, v23, s2                       // 0000009A2060: D5010017 200A2F17
	global_load_d16_b16 v38, v16, s[6:7]                       // 0000009A2068: DC820000 26060010
	v_add_f32_e32 v21, v21, v22                                // 0000009A2070: 062A2D15
	v_add_f32_e32 v13, v18, v13                                // 0000009A2074: 061A1B12
	global_load_d16_b16 v22, v28, s[6:7] offset:1280           // 0000009A2078: DC820500 1606001C
	v_add_f32_e32 v18, v23, v25                                // 0000009A2080: 06243317
	s_clause 0x7                                               // 0000009A2084: BF850007
	global_load_d16_b16 v25, v16, s[6:7] offset:1280           // 0000009A2088: DC820500 19060010
	global_load_d16_b16 v26, v1, s[6:7] offset:128             // 0000009A2090: DC820080 1A060001
	global_load_d16_b16 v32, v28, s[6:7]                       // 0000009A2098: DC820000 2006001C
	global_load_d16_b16 v33, v1, s[6:7] offset:1344            // 0000009A20A0: DC820540 21060001
	global_load_d16_b16 v7, v1, s[6:7] offset:1408             // 0000009A20A8: DC820580 07060001
	global_load_d16_b16 v34, v1, s[6:7] offset:1472            // 0000009A20B0: DC8205C0 22060001
	global_load_d16_b16 v35, v1, s[6:7] offset:192             // 0000009A20B8: DC8200C0 23060001
	global_load_d16_b16 v27, v45, s[6:7] offset:1280           // 0000009A20C0: DC820500 1B06002D
	v_mov_b32_dpp v23, v21 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009A20C8: 7E2E02FA FF016415
	v_cndmask_b32_e64 v21, -v21, v21, s4                       // 0000009A20D0: D5010015 20122B15
	s_clause 0x5                                               // 0000009A20D8: BF850005
	global_load_d16_b16 v28, v28, s[8:9]                       // 0000009A20DC: DC820000 1C08001C
	global_load_d16_b16 v16, v16, s[8:9]                       // 0000009A20E4: DC820000 10080010
	global_load_d16_b16 v37, v1, s[8:9]                        // 0000009A20EC: DC820000 25080001
	global_load_d16_b16 v40, v1, s[8:9] offset:64              // 0000009A20F4: DC820040 28080001
	global_load_d16_b16 v41, v1, s[8:9] offset:128             // 0000009A20FC: DC820080 29080001
	global_load_d16_b16 v42, v1, s[8:9] offset:192             // 0000009A2104: DC8200C0 2A080001
	v_mov_b32_dpp v31, v11 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009A210C: 7E3E02FA FF01680B
	v_add_f32_e32 v21, v21, v23                                // 0000009A2114: 062A2F15
	global_load_d16_b16 v23, v45, s[8:9]                       // 0000009A2118: DC820000 1708002D
	v_cndmask_b32_e64 v11, -v11, v11, s1                       // 0000009A2120: D501000B 2006170B
	v_mov_b32_dpp v30, v18 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009A2128: 7E3C02FA FF016212
	v_cndmask_b32_e64 v18, -v18, v18, s3                       // 0000009A2130: D5010012 200E2512
	v_add_f32_e32 v43, v36, v20                                // 0000009A2138: 06562924
	v_mov_b32_dpp v47, v24 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009A213C: 7E5E02FA FF016118
	v_add_f32_e32 v11, v11, v31                                // 0000009A2144: 06163F0B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009A2148: BF870214
	v_dual_add_f32 v31, v29, v39 :: v_dual_add_f32 v18, v18, v30// 0000009A214C: C9084F1D 1F123D12
	v_mov_b32_dpp v45, v43 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009A2154: 7E5A02FA FF01612B
	v_cndmask_b32_e64 v43, -v43, v43, s2                       // 0000009A215C: D501002B 200A572B
	v_cndmask_b32_e64 v24, -v24, v24, s2                       // 0000009A2164: D5010018 200A3118
	s_delay_alu instid0(VALU_DEP_4)                            // 0000009A216C: BF870004
	v_mov_b32_dpp v30, v31 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009A2170: 7E3C02FA FF01611F
	v_cndmask_b32_e64 v31, -v31, v31, s2                       // 0000009A2178: D501001F 200A3F1F
	v_mov_b32_dpp v44, v21 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009A2180: 7E5802FA FF016815
	v_add_f32_e32 v43, v43, v45                                // 0000009A2188: 06565B2B
	v_cndmask_b32_e64 v21, -v21, v21, s1                       // 0000009A218C: D5010015 20062B15
	v_add_f32_e32 v24, v24, v47                                // 0000009A2194: 06305F18
	v_add_f32_e32 v30, v31, v30                                // 0000009A2198: 063C3D1F
	v_mov_b32_dpp v31, v18 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009A219C: 7E3E02FA FF016412
	v_cndmask_b32_e64 v18, -v18, v18, s4                       // 0000009A21A4: D5010012 20122512
	v_add_f32_e32 v21, v21, v44                                // 0000009A21AC: 062A5915
	v_mul_f32_e32 v12, 0x3db504f3, v12                         // 0000009A21B0: 101818FF 3DB504F3
	v_mov_b32_dpp v46, v30 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009A21B8: 7E5C02FA FF01621E
	v_cndmask_b32_e64 v30, -v30, v30, s3                       // 0000009A21C0: D501001E 200E3D1E
	v_add_f32_e32 v18, v18, v31                                // 0000009A21C8: 06243F12
	v_mov_b32_dpp v31, v43 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009A21CC: 7E3E02FA FF01622B
	v_cndmask_b32_e64 v43, -v43, v43, s3                       // 0000009A21D4: D501002B 200E572B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000009A21DC: BF870234
	v_dual_sub_f32 v29, v29, v39 :: v_dual_add_f32 v30, v30, v46// 0000009A21E0: C9484F1D 1D1E5D1E
	v_mov_b32_dpp v46, v24 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009A21E8: 7E5C02FA FF016218
	v_cndmask_b32_e64 v24, -v24, v24, s3                       // 0000009A21F0: D5010018 200E3118
	v_add_f32_e32 v31, v43, v31                                // 0000009A21F8: 063E3F2B
	v_mov_b32_dpp v43, v18 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009A21FC: 7E5602FA FF016812
	v_mov_b32_dpp v45, v30 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009A2204: 7E5A02FA FF01641E
	v_cndmask_b32_e64 v30, -v30, v30, s4                       // 0000009A220C: D501001E 20123D1E
	v_add_f32_e32 v24, v24, v46                                // 0000009A2214: 06305D18
	v_mov_b32_dpp v44, v31 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009A2218: 7E5802FA FF01641F
	v_cndmask_b32_e64 v31, -v31, v31, s4                       // 0000009A2220: D501001F 20123F1F
	v_mov_b32_dpp v46, v17 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009A2228: 7E5C02FA FF016111
	v_add_f32_e32 v30, v30, v45                                // 0000009A2230: 063C5B1E
	v_cndmask_b32_e64 v17, -v17, v17, s2                       // 0000009A2234: D5010011 200A2311
	v_cndmask_b32_e64 v18, -v18, v18, s1                       // 0000009A223C: D5010012 20062512
	v_add_f32_e32 v31, v31, v44                                // 0000009A2244: 063E591F
	v_mov_b32_dpp v44, v24 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009A2248: 7E5802FA FF016418
	v_mov_b32_dpp v45, v30 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009A2250: 7E5A02FA FF01681E
	v_cndmask_b32_e64 v30, -v30, v30, s1                       // 0000009A2258: D501001E 20063D1E
	v_add_f32_e32 v17, v17, v46                                // 0000009A2260: 06225D11
	v_cndmask_b32_e64 v24, -v24, v24, s4                       // 0000009A2264: D5010018 20123118
	v_add_f32_e32 v18, v18, v43                                // 0000009A226C: 06245712
	s_delay_alu instid0(VALU_DEP_4)                            // 0000009A2270: BF870004
	v_dual_mul_f32 v11, 0x3db504f3, v11 :: v_dual_add_f32 v30, v30, v45// 0000009A2274: C8C816FF 0B1E5B1E 3DB504F3
	v_mov_b32_dpp v45, v31 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009A2280: 7E5A02FA FF01681F
	v_cndmask_b32_e64 v31, -v31, v31, s1                       // 0000009A2288: D501001F 20063F1F
	v_mov_b32_dpp v46, v17 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009A2290: 7E5C02FA FF016211
	v_cndmask_b32_e64 v17, -v17, v17, s3                       // 0000009A2298: D5010011 200E2311
	v_mul_f32_e32 v30, 0x3db504f3, v30                         // 0000009A22A0: 103C3CFF 3DB504F3
	v_add_f32_e32 v24, v24, v44                                // 0000009A22A8: 06305918
	v_dual_sub_f32 v20, v36, v20 :: v_dual_mul_f32 v13, 0x3db504f3, v13// 0000009A22AC: C9462924 140C1AFF 3DB504F3
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000009A22B8: BF8701A4
	v_add_f32_e32 v17, v17, v46                                // 0000009A22BC: 06225D11
	v_dual_mul_f32 v21, 0x3db504f3, v21 :: v_dual_mul_f32 v18, 0x3db504f3, v18// 0000009A22C0: C8C62AFF 151224FF 3DB504F3
	v_mov_b32_dpp v36, v20 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009A22CC: 7E4802FA FF016114
	v_cndmask_b32_e64 v20, -v20, v20, s2                       // 0000009A22D4: D5010014 200A2914
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000009A22DC: BF8700A4
	v_mov_b32_dpp v44, v17 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009A22E0: 7E5802FA FF016411
	v_cndmask_b32_e64 v17, -v17, v17, s4                       // 0000009A22E8: D5010011 20122311
	v_add_f32_e32 v17, v17, v44                                // 0000009A22F0: 06225911
	v_mov_b32_dpp v44, v0 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009A22F4: 7E5802FA FF016100
	v_cndmask_b32_e64 v0, -v0, v0, s2                          // 0000009A22FC: D5010000 200A0100
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009A2304: BF870211
	v_add_f32_e32 v0, v0, v44                                  // 0000009A2308: 06005900
	v_mov_b32_dpp v44, v17 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009A230C: 7E5802FA FF016811
	v_cndmask_b32_e64 v17, -v17, v17, s1                       // 0000009A2314: D5010011 20062311
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000009A231C: BF870091
	v_add_f32_e32 v17, v17, v44                                // 0000009A2320: 06225911
	v_mul_f32_e32 v17, 0x3db504f3, v17                         // 0000009A2324: 102222FF 3DB504F3
	s_waitcnt vmcnt(22)                                        // 0000009A232C: BF895BF7
	v_fma_mix_f32 v2, v2, v30, neg(0) op_sel_hi:[1,0,0]        // 0000009A2330: CC200002 8A023D02
	v_add_f32_e32 v30, v31, v45                                // 0000009A2338: 063C5B1F
	v_mov_b32_dpp v31, v24 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009A233C: 7E3E02FA FF016818
	v_cndmask_b32_e64 v24, -v24, v24, s1                       // 0000009A2344: D5010018 20063118
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009A234C: BF870214
	v_mul_f32_e32 v43, 0xbfb8aa3b, v2                          // 0000009A2350: 105604FF BFB8AA3B
	v_mul_f32_e32 v30, 0x3db504f3, v30                         // 0000009A2358: 103C3CFF 3DB504F3
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000009A2360: BF870223
	v_add_f32_e32 v24, v24, v31                                // 0000009A2364: 06303F18
	v_add_f32_e32 v31, v14, v19                                // 0000009A2368: 063E270E
	v_exp_f32_e32 v43, v43                                     // 0000009A236C: 7E564B2B
	s_delay_alu instid0(VALU_DEP_3)                            // 0000009A2370: BF870003
	v_fma_mix_f32 v3, v3, v30, neg(0) op_sel_hi:[1,0,0]        // 0000009A2374: CC200003 8A023D03
	v_sub_f32_e32 v14, v14, v19                                // 0000009A237C: 081C270E
	v_mul_f32_e32 v24, 0x3db504f3, v24                         // 0000009A2380: 103030FF 3DB504F3
	v_mov_b32_dpp v45, v31 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009A2388: 7E5A02FA FF01611F
	v_cndmask_b32_e64 v31, -v31, v31, s2                       // 0000009A2390: D501001F 200A3F1F
	v_mul_f32_e32 v30, 0xbfb8aa3b, v3                          // 0000009A2398: 103C06FF BFB8AA3B
	v_mov_b32_dpp v19, v14 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009A23A0: 7E2602FA FF01610E
	v_cndmask_b32_e64 v14, -v14, v14, s2                       // 0000009A23A8: D501000E 200A1D0E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009A23B0: BF870215
	v_add_f32_e32 v43, 1.0, v43                                // 0000009A23B4: 065656F2
	v_exp_f32_e32 v30, v30                                     // 0000009A23B8: 7E3C4B1E
	v_add_f32_e32 v31, v31, v45                                // 0000009A23BC: 063E5B1F
	v_mov_b32_dpp v45, v0 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009A23C0: 7E5A02FA FF016200
	v_cndmask_b32_e64 v0, -v0, v0, s3                          // 0000009A23C8: D5010000 200E0100
	v_div_scale_f32 v46, null, v43, v43, v2                    // 0000009A23D0: D6FC7C2E 040A572B
	s_waitcnt vmcnt(19)                                        // 0000009A23D8: BF894FF7
	v_fma_mix_f32 v4, v4, v12, neg(0) op_sel_hi:[1,0,0]        // 0000009A23DC: CC200004 8A021904
	v_mov_b32_dpp v48, v31 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009A23E4: 7E6002FA FF01621F
	v_cndmask_b32_e64 v31, -v31, v31, s3                       // 0000009A23EC: D501001F 200E3F1F
	v_add_f32_e32 v0, v0, v45                                  // 0000009A23F4: 06005B00
	v_rcp_f32_e32 v47, v46                                     // 0000009A23F8: 7E5E552E
	v_add_f32_e32 v30, 1.0, v30                                // 0000009A23FC: 063C3CF2
	v_fma_mix_f32 v6, v6, v11, neg(0) op_sel_hi:[1,0,0]        // 0000009A2400: CC200006 8A021706
	v_add_f32_e32 v31, v31, v48                                // 0000009A2408: 063E611F
	v_mov_b32_dpp v44, v0 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009A240C: 7E5802FA FF016400
	v_cndmask_b32_e64 v0, -v0, v0, s4                          // 0000009A2414: D5010000 20120100
	v_div_scale_f32 v45, null, v30, v30, v3                    // 0000009A241C: D6FC7C2D 040E3D1E
	v_add_f32_e32 v14, v14, v19                                // 0000009A2424: 061C270E
	v_mov_b32_dpp v50, v31 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009A2428: 7E6402FA FF01641F
	v_cndmask_b32_e64 v31, -v31, v31, s4                       // 0000009A2430: D501001F 20123F1F
	v_add_f32_e32 v0, v0, v44                                  // 0000009A2438: 06005900
	v_rcp_f32_e32 v48, v45                                     // 0000009A243C: 7E60552D
	v_add_f32_e32 v44, v15, v10                                // 0000009A2440: 0658150F
	v_fma_f32 v49, -v46, v47, 1.0                              // 0000009A2444: D6130031 23CA5F2E
	v_add_f32_e32 v31, v31, v50                                // 0000009A244C: 063E651F
	v_sub_f32_e32 v10, v15, v10                                // 0000009A2450: 0814150F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(TRANS32_DEP_1)// 0000009A2454: BF8702C4
	v_mov_b32_dpp v51, v44 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009A2458: 7E6602FA FF01612C
	v_cndmask_b32_e64 v44, -v44, v44, s2                       // 0000009A2460: D501002C 200A592C
	v_fmac_f32_e32 v47, v49, v47                               // 0000009A2468: 565E5F31
	v_div_scale_f32 v49, vcc_lo, v2, v43, v2                   // 0000009A246C: D6FC6A31 040A5702
	v_fma_f32 v50, -v45, v48, 1.0                              // 0000009A2474: D6130032 23CA612D
	v_mov_b32_dpp v52, v31 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009A247C: 7E6802FA FF01681F
	v_cndmask_b32_e64 v31, -v31, v31, s1                       // 0000009A2484: D501001F 20063F1F
	v_add_f32_e32 v44, v44, v51                                // 0000009A248C: 0658672C
	v_mov_b32_dpp v51, v0 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009A2490: 7E6602FA FF016800
	v_fmac_f32_e32 v48, v50, v48                               // 0000009A2498: 56606132
	v_div_scale_f32 v50, s5, v3, v30, v3                       // 0000009A249C: D6FC0532 040E3D03
	v_dual_add_f32 v31, v31, v52 :: v_dual_mul_f32 v52, v49, v47// 0000009A24A4: C906691F 1F345F31
	v_mov_b32_dpp v54, v44 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009A24AC: 7E6C02FA FF01622C
	v_cndmask_b32_e64 v44, -v44, v44, s3                       // 0000009A24B4: D501002C 200E592C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009A24BC: BF870214
	v_mul_f32_e32 v53, v50, v48                                // 0000009A24C0: 106A6132
	v_mul_f32_e32 v31, 0x3db504f3, v31                         // 0000009A24C4: 103E3EFF 3DB504F3
	v_fma_f32 v55, -v46, v52, v49                              // 0000009A24CC: D6130037 24C6692E
	v_cndmask_b32_e64 v0, -v0, v0, s1                          // 0000009A24D4: D5010000 20060100
	v_add_f32_e32 v44, v44, v54                                // 0000009A24DC: 06586D2C
	v_fma_f32 v56, -v45, v53, v50                              // 0000009A24E0: D6130038 24CA6B2D
	v_fma_mix_f32 v5, v5, v31, neg(0) op_sel_hi:[1,0,0]        // 0000009A24E8: CC200005 8A023F05
	v_fmac_f32_e32 v52, v55, v47                               // 0000009A24F0: 56685F37
	v_add_f32_e32 v0, v0, v51                                  // 0000009A24F4: 06006700
	v_mov_b32_dpp v31, v44 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009A24F8: 7E3E02FA FF01642C
	v_cndmask_b32_e64 v44, -v44, v44, s4                       // 0000009A2500: D501002C 2012592C
	v_fmac_f32_e32 v53, v56, v48                               // 0000009A2508: 566A6138
	v_fma_f32 v46, -v46, v52, v49                              // 0000009A250C: D613002E 24C6692E
	v_mul_f32_e32 v51, 0xbfb8aa3b, v5                          // 0000009A2514: 10660AFF BFB8AA3B
	v_mov_b32_dpp v19, v10 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009A251C: 7E2602FA FF01610A
	v_add_f32_e32 v31, v44, v31                                // 0000009A2524: 063E3F2C
	v_fma_f32 v45, -v45, v53, v50                              // 0000009A2528: D613002D 24CA6B2D
	v_div_fmas_f32 v44, v46, v47, v52                          // 0000009A2530: D637002C 04D25F2E
	s_mov_b32 vcc_lo, s5                                       // 0000009A2538: BEEA0005
	v_exp_f32_e32 v49, v51                                     // 0000009A253C: 7E624B33
	v_mov_b32_dpp v46, v31 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009A2540: 7E5C02FA FF01681F
	v_cndmask_b32_e64 v31, -v31, v31, s1                       // 0000009A2548: D501001F 20063F1F
	v_div_fmas_f32 v45, v45, v48, v53                          // 0000009A2550: D637002D 04D6612D
	v_div_fixup_f32 v2, v44, v43, v2                           // 0000009A2558: D6270002 040A572C
	v_cndmask_b32_e64 v10, -v10, v10, s2                       // 0000009A2560: D501000A 200A150A
	v_mul_f32_e32 v0, 0x3db504f3, v0                           // 0000009A2568: 100000FF 3DB504F3
	v_add_f32_e32 v12, v31, v46                                // 0000009A2570: 06185D1F
	v_mov_b32_dpp v31, v29 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009A2574: 7E3E02FA FF01611D
	v_cndmask_b32_e64 v29, -v29, v29, s2                       // 0000009A257C: D501001D 200A3B1D
	v_div_fixup_f32 v3, v45, v30, v3                           // 0000009A2584: D6270003 040E3D2D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000009A258C: BF870224
	v_dual_mul_f32 v2, v4, v2 :: v_dual_mul_f32 v11, 0x3db504f3, v12// 0000009A2590: C8C60504 020A18FF 3DB504F3
	v_add_f32_e32 v10, v10, v19                                // 0000009A259C: 0614270A
	v_add_f32_e32 v4, v29, v31                                 // 0000009A25A0: 06083F1D
	s_delay_alu instid0(VALU_DEP_4)                            // 0000009A25A4: BF870004
	v_mul_f32_e32 v3, v6, v3                                   // 0000009A25A8: 10060706
	v_add_f32_e32 v47, 1.0, v49                                // 0000009A25AC: 065E62F2
	s_waitcnt vmcnt(17)                                        // 0000009A25B0: BF8947F7
	v_fma_mix_f32 v6, v9, v11, neg(0) op_sel_hi:[1,0,0]        // 0000009A25B4: CC200006 8A021709
	v_add_f32_e32 v9, v20, v36                                 // 0000009A25BC: 06124914
	v_mov_b32_dpp v20, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009A25C0: 7E2802FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, s3                          // 0000009A25C8: D5010004 200E0904
	v_fma_mix_f32 v3, v8, v3, neg(0) op_sel_hi:[1,0,0]         // 0000009A25D0: CC200003 8A020708
	v_mul_f32_e32 v8, 0xbfb8aa3b, v6                           // 0000009A25D8: 10100CFF BFB8AA3B
	v_mov_b32_dpp v29, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009A25E0: 7E3A02FA FF016209
	v_cndmask_b32_e64 v9, -v9, v9, s3                          // 0000009A25E8: D5010009 200E1309
	v_add_f32_e32 v4, v4, v20                                  // 0000009A25F0: 06082904
	v_div_scale_f32 v30, null, v47, v47, v5                    // 0000009A25F4: D6FC7C1E 04165F2F
	v_exp_f32_e32 v8, v8                                       // 0000009A25FC: 7E104B08
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009A2600: BF870193
	v_add_f32_e32 v9, v9, v29                                  // 0000009A2604: 06123B09
	v_mov_b32_dpp v15, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009A2608: 7E1E02FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s4                          // 0000009A2610: D5010004 20120904
	v_mov_b32_dpp v29, v14 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009A2618: 7E3A02FA FF01620E
	v_cndmask_b32_e64 v14, -v14, v14, s3                       // 0000009A2620: D501000E 200E1D0E
	v_mov_b32_dpp v20, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009A2628: 7E2802FA FF016409
	v_cndmask_b32_e64 v9, -v9, v9, s4                          // 0000009A2630: D5010009 20121309
	v_add_f32_e32 v4, v4, v15                                  // 0000009A2638: 06081F04
	v_mov_b32_dpp v15, v10 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009A263C: 7E1E02FA FF01620A
	v_add_f32_e32 v14, v14, v29                                // 0000009A2644: 061C3B0E
	v_cndmask_b32_e64 v10, -v10, v10, s3                       // 0000009A2648: D501000A 200E150A
	v_add_f32_e32 v9, v9, v20                                  // 0000009A2650: 06122909
	v_mov_b32_dpp v19, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009A2654: 7E2602FA FF016804
	v_cndmask_b32_e64 v4, -v4, v4, s1                          // 0000009A265C: D5010004 20060904
	v_mov_b32_dpp v20, v14 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009A2664: 7E2802FA FF01640E
	v_cndmask_b32_e64 v14, -v14, v14, s4                       // 0000009A266C: D501000E 20121D0E
	v_add_f32_e32 v10, v10, v15                                // 0000009A2674: 06141F0A
	v_rcp_f32_e32 v12, v30                                     // 0000009A2678: 7E18551E
	v_mov_b32_dpp v15, v9 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009A267C: 7E1E02FA FF016809
	v_cndmask_b32_e64 v9, -v9, v9, s1                          // 0000009A2684: D5010009 20061309
	v_add_f32_e32 v4, v4, v19                                  // 0000009A268C: 06082704
	v_add_f32_e32 v14, v14, v20                                // 0000009A2690: 061C290E
	v_mov_b32_dpp v19, v10 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009A2694: 7E2602FA FF01640A
	v_cndmask_b32_e64 v10, -v10, v10, s4                       // 0000009A269C: D501000A 2012150A
	v_dual_add_f32 v8, 1.0, v8 :: v_dual_add_f32 v9, v9, v15   // 0000009A26A4: C90810F2 08081F09
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000009A26AC: BF870224
	v_mov_b32_dpp v15, v14 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009A26B0: 7E1E02FA FF01680E
	v_cndmask_b32_e64 v14, -v14, v14, s1                       // 0000009A26B8: D501000E 20061D0E
	v_add_f32_e32 v10, v10, v19                                // 0000009A26C0: 0614270A
	v_fma_f32 v11, -v30, v12, 1.0                              // 0000009A26C4: D613000B 23CA191E
	v_mul_f32_e32 v4, 0x3db504f3, v4                           // 0000009A26CC: 100808FF 3DB504F3
	v_div_scale_f32 v19, null, v8, v8, v6                      // 0000009A26D4: D6FC7C13 041A1108
	v_add_f32_e32 v14, v14, v15                                // 0000009A26DC: 061C1F0E
	v_mov_b32_dpp v15, v10 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009A26E0: 7E1E02FA FF01680A
	v_cndmask_b32_e64 v10, -v10, v10, s1                       // 0000009A26E8: D501000A 2006150A
	v_fmac_f32_e32 v12, v11, v12                               // 0000009A26F0: 5618190B
	v_div_scale_f32 v11, vcc_lo, v5, v47, v5                   // 0000009A26F4: D6FC6A0B 04165F05
	v_mul_f32_e32 v9, 0x3db504f3, v9                           // 0000009A26FC: 101212FF 3DB504F3
	v_rcp_f32_e32 v20, v19                                     // 0000009A2704: 7E285513
	v_add_f32_e32 v10, v10, v15                                // 0000009A2708: 06141F0A
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000009A270C: BF8701B3
	v_dual_mul_f32 v14, 0x3db504f3, v14 :: v_dual_mul_f32 v15, v11, v12// 0000009A2710: C8C61CFF 0E0E190B 3DB504F3
	s_waitcnt vmcnt(12)                                        // 0000009A271C: BF8933F7
	v_fma_mix_f32 v9, v32, v9, neg(0) op_sel_hi:[1,0,0]        // 0000009A2720: CC200009 8A021320
	v_mul_f32_e32 v10, 0x3db504f3, v10                         // 0000009A2728: 101414FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_3)                            // 0000009A2730: BF870003
	v_fma_f32 v31, -v30, v15, v11                              // 0000009A2734: D613001F 242E1F1E
	v_fma_mix_f32 v4, v26, v4, neg(0) op_sel_hi:[1,0,0]        // 0000009A273C: CC200004 8A02091A
	s_waitcnt vmcnt(8)                                         // 0000009A2744: BF8923F7
	v_fma_mix_f32 v14, v35, v14, neg(0) op_sel_hi:[1,0,0]      // 0000009A2748: CC20000E 8A021D23
	v_mul_f32_e32 v29, 0xbfb8aa3b, v9                          // 0000009A2750: 103A12FF BFB8AA3B
	v_fma_f32 v32, -v19, v20, 1.0                              // 0000009A2758: D6130020 23CA2913
	v_fma_mix_f32 v10, v38, v10, neg(0) op_sel_hi:[1,0,0]      // 0000009A2760: CC20000A 8A021526
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009A2768: BF870214
	v_dual_mul_f32 v26, 0xbfb8aa3b, v4 :: v_dual_mul_f32 v35, 0xbfb8aa3b, v14// 0000009A276C: C8C608FF 1A221CFF BFB8AA3B
	v_exp_f32_e32 v29, v29                                     // 0000009A2778: 7E3A4B1D
	v_fmac_f32_e32 v15, v31, v12                               // 0000009A277C: 561E191F
	v_fmac_f32_e32 v20, v32, v20                               // 0000009A2780: 56282920
	s_delay_alu instid0(VALU_DEP_3)                            // 0000009A2784: BF870003
	v_exp_f32_e32 v26, v26                                     // 0000009A2788: 7E344B1A
	v_mul_f32_e32 v32, 0xbfb8aa3b, v10                         // 0000009A278C: 104014FF BFB8AA3B
	v_exp_f32_e32 v31, v35                                     // 0000009A2794: 7E3E4B23
	v_fma_f32 v11, -v30, v15, v11                              // 0000009A2798: D613000B 242E1F1E
	v_div_scale_f32 v35, s5, v6, v8, v6                        // 0000009A27A0: D6FC0523 041A1106
	v_fma_mix_f32 v13, v33, v13, neg(0) op_sel_hi:[1,0,0]      // 0000009A27A8: CC20000D 8A021B21
	v_exp_f32_e32 v30, v32                                     // 0000009A27B0: 7E3C4B20
	v_add_f32_e32 v29, 1.0, v29                                // 0000009A27B4: 063A3AF2
	v_div_fmas_f32 v11, v11, v12, v15                          // 0000009A27B8: D637000B 043E190B
	v_mul_f32_e32 v32, v35, v20                                // 0000009A27C0: 10402923
	v_add_f32_e32 v26, 1.0, v26                                // 0000009A27C4: 063434F2
	s_mov_b32 vcc_lo, s5                                       // 0000009A27C8: BEEA0005
	v_add_f32_e32 v31, 1.0, v31                                // 0000009A27CC: 063E3EF2
	v_div_scale_f32 v39, null, v29, v29, v9                    // 0000009A27D0: D6FC7C27 04263B1D
	v_fma_f32 v15, -v19, v32, v35                              // 0000009A27D8: D613000F 248E4113
	v_div_scale_f32 v36, null, v26, v26, v4                    // 0000009A27E0: D6FC7C24 0412351A
	v_add_f32_e32 v30, 1.0, v30                                // 0000009A27E8: 063C3CF2
	v_div_scale_f32 v12, null, v31, v31, v14                   // 0000009A27EC: D6FC7C0C 043A3F1F
	v_rcp_f32_e32 v43, v39                                     // 0000009A27F4: 7E565527
	v_fmac_f32_e32 v32, v15, v20                               // 0000009A27F8: 5640290F
	v_rcp_f32_e32 v38, v36                                     // 0000009A27FC: 7E4C5524
	v_div_scale_f32 v33, null, v30, v30, v10                   // 0000009A2800: D6FC7C21 042A3D1E
	v_rcp_f32_e32 v45, v12                                     // 0000009A2808: 7E5A550C
	v_div_fixup_f32 v5, v11, v47, v5                           // 0000009A280C: D6270005 04165F0B
	v_div_scale_f32 v11, s6, v4, v26, v4                       // 0000009A2814: D6FC060B 04123504
	v_fma_f32 v19, -v19, v32, v35                              // 0000009A281C: D6130013 248E4113
	v_rcp_f32_e32 v15, v33                                     // 0000009A2824: 7E1E5521
	s_waitcnt vmcnt(7)                                         // 0000009A2828: BF891FF7
	v_fma_mix_f32 v21, v27, v21, neg(0) op_sel_hi:[1,0,0]      // 0000009A282C: CC200015 8A022B1B
	v_mul_f32_e32 v5, v13, v5                                  // 0000009A2834: 100A0B0D
	v_fma_mix_f32 v0, v25, v0, neg(0) op_sel_hi:[1,0,0]        // 0000009A2838: CC200000 8A020119
	v_fma_f32 v44, -v36, v38, 1.0                              // 0000009A2840: D613002C 23CA4D24
	v_div_fmas_f32 v19, v19, v20, v32                          // 0000009A2848: D6370013 04822913
	v_fma_f32 v13, -v12, v45, 1.0                              // 0000009A2850: D613000D 23CA5B0C
	s_mov_b32 vcc_lo, s6                                       // 0000009A2858: BEEA0006
	v_fma_mix_f32 v7, v7, v18, neg(0) op_sel_hi:[1,0,0]        // 0000009A285C: CC200007 8A022507
	v_fmac_f32_e32 v38, v44, v38                               // 0000009A2864: 564C4D2C
	v_fma_f32 v44, -v39, v43, 1.0                              // 0000009A2868: D613002C 23CA5727
	v_fma_f32 v46, -v33, v15, 1.0                              // 0000009A2870: D613002E 23CA1F21
	v_fmac_f32_e32 v45, v13, v45                               // 0000009A2878: 565A5B0D
	v_div_scale_f32 v13, s8, v14, v31, v14                     // 0000009A287C: D6FC080D 043A3F0E
	v_mul_f32_e32 v35, v11, v38                                // 0000009A2884: 10464D0B
	v_fmac_f32_e32 v43, v44, v43                               // 0000009A2888: 5656572C
	v_div_scale_f32 v44, s7, v9, v29, v9                       // 0000009A288C: D6FC072C 04263B09
	v_fmac_f32_e32 v15, v46, v15                               // 0000009A2894: 561E1F2E
	v_div_scale_f32 v46, s5, v10, v30, v10                     // 0000009A2898: D6FC052E 042A3D0A
	v_fma_f32 v20, -v36, v35, v11                              // 0000009A28A0: D6130014 242E4724
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000009A28A8: BF8701A4
	v_dual_mul_f32 v47, v13, v45 :: v_dual_mul_f32 v32, v44, v43// 0000009A28AC: C8C65B0D 2F20572C
	v_div_fixup_f32 v6, v19, v8, v6                            // 0000009A28B4: D6270006 041A1113
	v_dual_fmac_f32 v35, v20, v38 :: v_dual_mul_f32 v20, v46, v15// 0000009A28BC: C8064D14 23141F2E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009A28C4: BF870213
	v_fma_f32 v8, -v39, v32, v44                               // 0000009A28C8: D6130008 24B24127
	v_fma_f32 v19, -v12, v47, v13                              // 0000009A28D0: D6130013 24365F0C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009A28D8: BF870214
	v_mul_f32_e32 v6, v21, v6                                  // 0000009A28DC: 100C0D15
	v_fma_f32 v11, -v36, v35, v11                              // 0000009A28E0: D613000B 242E4724
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000009A28E8: BF870234
	v_fmac_f32_e32 v32, v8, v43                                // 0000009A28EC: 56405708
	v_fma_f32 v8, -v33, v20, v46                               // 0000009A28F0: D6130008 24BA2921
	v_fmac_f32_e32 v47, v19, v45                               // 0000009A28F8: 565E5B13
	v_div_fmas_f32 v11, v11, v38, v35                          // 0000009A28FC: D637000B 048E4D0B
	s_mov_b32 vcc_lo, s7                                       // 0000009A2904: BEEA0007
	v_fma_f32 v19, -v39, v32, v44                              // 0000009A2908: D6130013 24B24127
	v_fmac_f32_e32 v20, v8, v15                                // 0000009A2910: 56281F08
	v_fma_f32 v8, -v12, v47, v13                               // 0000009A2914: D6130008 24365F0C
	v_div_fixup_f32 v4, v11, v26, v4                           // 0000009A291C: D6270004 0412350B
	v_fma_mix_f32 v11, v34, v17, neg(0) op_sel_hi:[1,0,0]      // 0000009A2924: CC20000B 8A022322
	v_div_fmas_f32 v12, v19, v43, v32                          // 0000009A292C: D637000C 04825713
	v_fma_f32 v13, -v33, v20, v46                              // 0000009A2934: D613000D 24BA2921
	s_mov_b32 vcc_lo, s8                                       // 0000009A293C: BEEA0008
	s_waitcnt vmcnt(0)                                         // 0000009A2940: BF8903F7
	v_fma_mix_f32 v6, v23, v6, neg(0) op_sel_hi:[1,0,0]        // 0000009A2944: CC200006 8A020D17
	v_div_fmas_f32 v8, v8, v45, v47                            // 0000009A294C: D6370008 04BE5B08
	s_mov_b32 vcc_lo, s5                                       // 0000009A2954: BEEA0005
	v_div_fixup_f32 v9, v12, v29, v9                           // 0000009A2958: D6270009 04263B0C
	v_div_fmas_f32 v13, v13, v15, v20                          // 0000009A2960: D637000D 04521F0D
	v_fma_mix_f32 v12, v22, v24, neg(0) op_sel_hi:[1,0,0]      // 0000009A2968: CC20000C 8A023116
	v_div_fixup_f32 v8, v8, v31, v14                           // 0000009A2970: D6270008 043A3F08
	v_mul_f32_e32 v4, v7, v4                                   // 0000009A2978: 10080907
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009A297C: BF870194
	v_div_fixup_f32 v10, v13, v30, v10                         // 0000009A2980: D627000A 042A3D0D
	v_dual_mul_f32 v9, v12, v9 :: v_dual_mul_f32 v8, v11, v8   // 0000009A2988: C8C6130C 0908110B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000009A2990: BF870112
	v_mul_f32_e32 v0, v0, v10                                  // 0000009A2994: 10001500
	v_fma_mix_f32 v7, v28, v9, neg(0) op_sel_hi:[1,0,0]        // 0000009A2998: CC200007 8A02131C
	v_fma_mix_f32 v9, v2, v37, v3 op_sel_hi:[0,1,0]            // 0000009A29A0: CC200009 140E4B02
	v_fma_mix_f32 v10, v5, v40, v6 op_sel_hi:[0,1,0]           // 0000009A29A8: CC20000A 141A5105
	v_fma_mix_f32 v2, v2, v37, -v3 op_sel_hi:[0,1,0]           // 0000009A29B0: CC200002 940E4B02
	v_fma_mix_f32 v0, v16, v0, neg(0) op_sel_hi:[1,0,0]        // 0000009A29B8: CC200000 8A020110
	v_fma_mix_f32 v11, v4, v41, v7 op_sel_hi:[0,1,0]           // 0000009A29C0: CC20000B 141E5304
	v_fma_mix_f32 v3, v5, v40, -v6 op_sel_hi:[0,1,0]           // 0000009A29C8: CC200003 941A5105
	v_fma_mix_f32 v4, v4, v41, -v7 op_sel_hi:[0,1,0]           // 0000009A29D0: CC200004 941E5304
	v_add_f32_e32 v5, v9, v10                                  // 0000009A29D8: 060A1509
	v_fma_mix_f32 v12, v8, v42, v0 op_sel_hi:[0,1,0]           // 0000009A29DC: CC20000C 14025508
	v_fma_mix_f32 v0, v8, v42, -v0 op_sel_hi:[0,1,0]           // 0000009A29E4: CC200000 94025508
	v_dual_sub_f32 v7, v9, v10 :: v_dual_add_f32 v8, v2, v3    // 0000009A29EC: C9481509 07080702
	v_sub_f32_e32 v2, v2, v3                                   // 0000009A29F4: 08040702
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000009A29F8: BF8701B4
	v_add_f32_e32 v6, v11, v12                                 // 0000009A29FC: 060C190B
	v_sub_f32_e32 v9, v11, v12                                 // 0000009A2A00: 0812190B
	v_add_f32_e32 v10, v4, v0                                  // 0000009A2A04: 06140104
	v_dual_sub_f32 v0, v4, v0 :: v_dual_add_f32 v3, v5, v6     // 0000009A2A08: C9480104 00020D05
	v_sub_f32_e32 v4, v5, v6                                   // 0000009A2A10: 08080D05
	s_delay_alu instid0(VALU_DEP_3)                            // 0000009A2A14: BF870003
	v_add_f32_e32 v6, v8, v10                                  // 0000009A2A18: 060C1508
	v_sub_f32_e32 v8, v8, v10                                  // 0000009A2A1C: 08101508
	v_add_f32_e32 v10, v7, v9                                  // 0000009A2A20: 06141307
	v_mov_b32_dpp v5, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009A2A24: 7E0A02FA FF016103
	v_cndmask_b32_e64 v3, -v3, v3, s2                          // 0000009A2A2C: D5010003 200A0703
	v_sub_f32_e32 v7, v7, v9                                   // 0000009A2A34: 080E1307
	v_mov_b32_dpp v14, v4 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009A2A38: 7E1C02FA FF016104
	v_mov_b32_dpp v9, v10 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009A2A40: 7E1202FA FF01610A
	v_cndmask_b32_e64 v10, -v10, v10, s2                       // 0000009A2A48: D501000A 200A150A
	v_add_f32_e32 v3, v3, v5                                   // 0000009A2A50: 06060B03
	v_mov_b32_dpp v5, v6 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009A2A54: 7E0A02FA FF016106
	v_cndmask_b32_e64 v6, -v6, v6, s2                          // 0000009A2A5C: D5010006 200A0D06
	v_cndmask_b32_e64 v15, -v4, v4, s2                         // 0000009A2A64: D501000F 200A0904
	v_add_f32_e32 v9, v10, v9                                  // 0000009A2A6C: 0612130A
	v_mov_b32_dpp v11, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009A2A70: 7E1602FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, s3                          // 0000009A2A78: D5010003 200E0703
	v_add_f32_e32 v5, v6, v5                                   // 0000009A2A80: 060A0B06
	v_add_f32_e32 v6, v2, v0                                   // 0000009A2A84: 060C0102
	v_sub_f32_e32 v10, v2, v0                                  // 0000009A2A88: 08140102
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009A2A8C: BF870214
	v_add_f32_e32 v0, v3, v11                                  // 0000009A2A90: 06001703
	v_mov_b32_dpp v2, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009A2A94: 7E0402FA FF016205
	v_cndmask_b32_e64 v3, -v5, v5, s3                          // 0000009A2A9C: D5010003 200E0B05
	v_mov_b32_dpp v5, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009A2AA4: 7E0A02FA FF016209
	v_cndmask_b32_e64 v9, -v9, v9, s3                          // 0000009A2AAC: D5010009 200E1309
	v_mov_b32_dpp v11, v6 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009A2AB4: 7E1602FA FF016106
	v_cndmask_b32_e64 v6, -v6, v6, s2                          // 0000009A2ABC: D5010006 200A0D06
	v_add_f32_e32 v2, v3, v2                                   // 0000009A2AC4: 06040503
	v_mov_b32_dpp v16, v10 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009A2AC8: 7E2002FA FF01610A
	v_add_f32_e32 v5, v9, v5                                   // 0000009A2AD0: 060A0B09
	v_cndmask_b32_e64 v10, -v10, v10, s2                       // 0000009A2AD4: D501000A 200A150A
	v_add_f32_e32 v6, v6, v11                                  // 0000009A2ADC: 060C1706
	v_mov_b32_dpp v9, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009A2AE0: 7E1202FA FF016402
	v_cndmask_b32_e64 v2, -v2, v2, s4                          // 0000009A2AE8: D5010002 20120502
	v_mov_b32_dpp v11, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009A2AF0: 7E1602FA FF016405
	v_cndmask_b32_e64 v5, -v5, v5, s4                          // 0000009A2AF8: D5010005 20120B05
	v_mov_b32_dpp v12, v6 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009A2B00: 7E1802FA FF016206
	v_cndmask_b32_e64 v13, -v6, v6, s3                         // 0000009A2B08: D501000D 200E0D06
	v_add_f32_e32 v4, v2, v9                                   // 0000009A2B10: 06081302
	v_add_f32_e32 v10, v10, v16                                // 0000009A2B14: 0614210A
	v_dual_add_f32 v6, v5, v11 :: v_dual_add_f32 v11, v15, v14 // 0000009A2B18: C9081705 060A1D0F
	v_mov_b32_dpp v14, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009A2B20: 7E1C02FA FF016108
	v_cndmask_b32_e64 v8, -v8, v8, s2                          // 0000009A2B28: D5010008 200A1108
	v_mov_b32_dpp v15, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009A2B30: 7E1E02FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, s2                          // 0000009A2B38: D5010007 200A0F07
	v_add_f32_e32 v9, v13, v12                                 // 0000009A2B40: 0612190D
	v_mov_b32_dpp v13, v11 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009A2B44: 7E1A02FA FF01620B
	v_cndmask_b32_e64 v11, -v11, v11, s3                       // 0000009A2B4C: D501000B 200E170B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000009A2B54: BF870234
	v_dual_add_f32 v8, v8, v14 :: v_dual_add_f32 v7, v7, v15   // 0000009A2B58: C9081D08 08061F07
	v_mov_b32_dpp v15, v10 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009A2B60: 7E1E02FA FF01620A
	v_cndmask_b32_e64 v10, -v10, v10, s3                       // 0000009A2B68: D501000A 200E150A
	v_add_f32_e32 v11, v11, v13                                // 0000009A2B70: 06161B0B
	s_delay_alu instid0(VALU_DEP_4)                            // 0000009A2B74: BF870004
	v_mov_b32_dpp v13, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009A2B78: 7E1A02FA FF016208
	v_cndmask_b32_e64 v8, -v8, v8, s3                          // 0000009A2B80: D5010008 200E1108
	v_mov_b32_dpp v14, v7 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009A2B88: 7E1C02FA FF016207
	v_cndmask_b32_e64 v7, -v7, v7, s3                          // 0000009A2B90: D5010007 200E0F07
	v_add_f32_e32 v10, v10, v15                                // 0000009A2B98: 06141F0A
	v_mov_b32_dpp v3, v0 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009A2B9C: 7E0602FA FF016400
	v_add_f32_e32 v8, v8, v13                                  // 0000009A2BA4: 06101B08
	v_cndmask_b32_e64 v0, -v0, v0, s4                          // 0000009A2BA8: D5010000 20120100
	v_add_f32_e32 v7, v7, v14                                  // 0000009A2BB0: 060E1D07
	v_mov_b32_dpp v12, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009A2BB4: 7E1802FA FF016409
	v_cndmask_b32_e64 v9, -v9, v9, s4                          // 0000009A2BBC: D5010009 20121309
	v_mov_b32_dpp v13, v11 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009A2BC4: 7E1A02FA FF01640B
	v_cndmask_b32_e64 v11, -v11, v11, s4                       // 0000009A2BCC: D501000B 2012170B
	v_mov_b32_dpp v14, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009A2BD4: 7E1C02FA FF016408
	v_cndmask_b32_e64 v8, -v8, v8, s4                          // 0000009A2BDC: D5010008 20121108
	v_mov_b32_dpp v15, v7 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009A2BE4: 7E1E02FA FF016407
	v_cndmask_b32_e64 v7, -v7, v7, s4                          // 0000009A2BEC: D5010007 20120F07
	v_mov_b32_dpp v16, v10 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009A2BF4: 7E2002FA FF01640A
	v_cndmask_b32_e64 v17, -v10, v10, s4                       // 0000009A2BFC: D5010011 2012150A
	v_dual_add_f32 v0, v0, v3 :: v_dual_add_f32 v9, v9, v12    // 0000009A2C04: C9080700 00081909
	v_dual_add_f32 v10, v11, v13 :: v_dual_add_f32 v11, v8, v14// 0000009A2C0C: C9081B0B 0A0A1D08
	v_add_f32_e32 v13, v7, v15                                 // 0000009A2C14: 061A1F07
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009A2C18: BF870214
	v_add_f32_e32 v15, v17, v16                                // 0000009A2C1C: 061E2111
	v_mov_b32_dpp v2, v0 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009A2C20: 7E0402FA FF016800
	v_mov_b32_dpp v3, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009A2C28: 7E0602FA FF016804
	v_mov_b32_dpp v5, v6 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009A2C30: 7E0A02FA FF016806
	v_mov_b32_dpp v7, v9 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009A2C38: 7E0E02FA FF016809
	v_mov_b32_dpp v8, v10 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009A2C40: 7E1002FA FF01680A
	v_mov_b32_dpp v12, v11 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009A2C48: 7E1802FA FF01680B
	v_mov_b32_dpp v14, v13 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009A2C50: 7E1C02FA FF01680D
	v_mov_b32_dpp v16, v15 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009A2C58: 7E2002FA FF01680F
	s_mov_b32 s2, 0x3db504f3                                   // 0000009A2C60: BE8200FF 3DB504F3
	s_and_b32 exec_lo, exec_lo, s0                             // 0000009A2C68: 8B7E007E
	s_cbranch_execz 65                                         // 0000009A2C6C: BFA50041 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi1ELi2EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x5f74>
	v_cndmask_b32_e64 v15, -v15, v15, s1                       // 0000009A2C70: D501000F 20061F0F
	v_cndmask_b32_e64 v0, -v0, v0, s1                          // 0000009A2C78: D5010000 20060100
	v_cndmask_b32_e64 v4, -v4, v4, s1                          // 0000009A2C80: D5010004 20060904
	v_cndmask_b32_e64 v6, -v6, v6, s1                          // 0000009A2C88: D5010006 20060D06
	v_cndmask_b32_e64 v9, -v9, v9, s1                          // 0000009A2C90: D5010009 20061309
	v_cndmask_b32_e64 v13, -v13, v13, s1                       // 0000009A2C98: D501000D 20061B0D
	v_cndmask_b32_e64 v10, -v10, v10, s1                       // 0000009A2CA0: D501000A 2006150A
	v_cndmask_b32_e64 v11, -v11, v11, s1                       // 0000009A2CA8: D501000B 2006170B
	v_dual_add_f32 v15, v15, v16 :: v_dual_add_f32 v0, v0, v2  // 0000009A2CB0: C908210F 0F000500
	v_add_f32_e32 v3, v4, v3                                   // 0000009A2CB8: 06060704
	v_add_f32_e32 v5, v6, v5                                   // 0000009A2CBC: 060A0B06
	v_add_f32_e32 v7, v9, v7                                   // 0000009A2CC0: 060E0F09
	s_mul_i32 s0, s10, 0x500                                   // 0000009A2CC4: 9600FF0A 00000500
	v_dual_add_f32 v13, v13, v14 :: v_dual_add_f32 v8, v10, v8 // 0000009A2CCC: C9081D0D 0D08110A
	s_mul_hi_i32 s1, s10, 0x500                                // 0000009A2CD4: 9701FF0A 00000500
	v_add_f32_e32 v11, v11, v12                                // 0000009A2CDC: 0616190B
	s_add_u32 s0, s22, s0                                      // 0000009A2CE0: 80000016
	v_fma_mixlo_f16 v0, v0, s2, 0                              // 0000009A2CE4: CC210000 02000500
	s_addc_u32 s1, s23, s1                                     // 0000009A2CEC: 82010117
	v_fma_mixhi_f16 v0, v3, s2, 0                              // 0000009A2CF0: CC220000 02000503
	s_add_u32 s0, s0, s12                                      // 0000009A2CF8: 80000C00
	v_fma_mixlo_f16 v2, v5, s2, 0                              // 0000009A2CFC: CC210002 02000505
	s_addc_u32 s1, s1, s13                                     // 0000009A2D04: 82010D01
	v_fma_mixhi_f16 v2, v7, s2, 0                              // 0000009A2D08: CC220002 02000507
	v_fma_mixlo_f16 v3, v8, s2, 0                              // 0000009A2D10: CC210003 02000508
	v_fma_mixhi_f16 v3, v11, s2, 0                             // 0000009A2D18: CC220003 0200050B
	v_fma_mixlo_f16 v4, v13, s2, 0                             // 0000009A2D20: CC210004 0200050D
	v_fma_mixhi_f16 v4, v15, s2, 0                             // 0000009A2D28: CC220004 0200050F
	s_clause 0x7                                               // 0000009A2D30: BF850007
	global_store_b16 v1, v0, s[0:1]                            // 0000009A2D34: DC660000 00000001
	global_store_d16_hi_b16 v1, v0, s[0:1] offset:32           // 0000009A2D3C: DC960020 00000001
	global_store_b16 v1, v2, s[0:1] offset:64                  // 0000009A2D44: DC660040 00000201
	global_store_d16_hi_b16 v1, v2, s[0:1] offset:96           // 0000009A2D4C: DC960060 00000201
	global_store_b16 v1, v3, s[0:1] offset:128                 // 0000009A2D54: DC660080 00000301
	global_store_d16_hi_b16 v1, v3, s[0:1] offset:160          // 0000009A2D5C: DC9600A0 00000301
	global_store_b16 v1, v4, s[0:1] offset:192                 // 0000009A2D64: DC6600C0 00000401
	global_store_d16_hi_b16 v1, v4, s[0:1] offset:224          // 0000009A2D6C: DC9600E0 00000401
	s_nop 0                                                    // 0000009A2D74: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 0000009A2D78: BFB60003
	s_endpgm                                                   // 0000009A2D7C: BFB00000
		...

