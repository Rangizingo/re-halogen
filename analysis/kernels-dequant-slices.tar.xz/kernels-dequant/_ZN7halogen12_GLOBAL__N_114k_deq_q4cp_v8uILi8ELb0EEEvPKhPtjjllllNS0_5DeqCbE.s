0000000000281e00 <_ZN7halogen12_GLOBAL__N_114k_deq_q4cp_v8uILi8ELb0EEEvPKhPtjjllllNS0_5DeqCbE>:
; _ZN7halogen12_GLOBAL__N_114k_deq_q4cp_v8uILi8ELb0EEEvPKhPtjjllllNS0_5DeqCbE():
	s_load_b128 s[12:15], s[0:1], null                         // 000000281E00: F4080300 F8000000
	s_mov_b32 s3, exec_lo                                      // 000000281E08: BE83007E
	v_cmpx_gt_u32_e32 16, v0                                   // 000000281E0C: 7D980090
	s_cbranch_execz 7                                          // 000000281E10: BFA50007 <_ZN7halogen12_GLOBAL__N_114k_deq_q4cp_v8uILi8ELb0EEEvPKhPtjjllllNS0_5DeqCbE+0x30>
	v_lshlrev_b32_e32 v1, 2, v0                                // 000000281E14: 30020082
	s_waitcnt lgkmcnt(0)                                       // 000000281E18: BF89FC07
	global_load_b32 v2, v1, s[12:13]                           // 000000281E1C: DC520000 020C0001
	s_waitcnt vmcnt(0)                                         // 000000281E24: BF8903F7
	ds_store_b32 v1, v2                                        // 000000281E28: D8340000 00000201
	s_or_b32 exec_lo, exec_lo, s3                              // 000000281E30: 8C7E037E
	s_load_b64 s[16:17], s[0:1], 0x10                          // 000000281E34: F4040400 F8000010
	s_lshl_b32 s21, s2, 11                                     // 000000281E3C: 84158B02
	s_waitcnt lgkmcnt(0)                                       // 000000281E40: BF89FC07
	s_cmp_ge_u32 s21, s17                                      // 000000281E44: BF091115
	s_cbranch_scc1 3104                                        // 000000281E48: BFA20C20 <_ZN7halogen12_GLOBAL__N_114k_deq_q4cp_v8uILi8ELb0EEEvPKhPtjjllllNS0_5DeqCbE+0x30cc>
	s_load_b256 s[4:11], s[0:1], 0x18                          // 000000281E4C: F40C0100 F8000018
	s_cvt_f32_u32 s3, s16                                      // 000000281E54: BE836510
	v_mov_b32_e32 v12, 0                                       // 000000281E58: 7E180280
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(SKIP_1) | instid1(TRANS32_DEP_1)// 000000281E5C: BF8702AA
	v_rcp_iflag_f32_e32 v1, s3                                 // 000000281E60: 7E025603
	s_load_b32 s3, s[0:1], 0x78                                // 000000281E64: F40000C0 F8000078
	v_readfirstlane_b32 s18, v1                                // 000000281E6C: 7E240501
	s_mul_f32 s18, s18, 0x4f7ffffe                             // 000000281E70: A212FF12 4F7FFFFE
	s_waitcnt lgkmcnt(0)                                       // 000000281E78: BF89FC07
	s_lshr_b32 s0, s5, 31                                      // 000000281E7C: 85009F05
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000281E80: BF870009
	s_add_u32 s0, s4, s0                                       // 000000281E84: 80000004
	s_addc_u32 s1, s5, 0                                       // 000000281E88: 82018005
	s_cvt_u32_f32 s20, s18                                     // 000000281E8C: BE946712
	s_ashr_i64 s[18:19], s[0:1], 1                             // 000000281E90: 86928100
	s_add_u32 s6, s12, s6                                      // 000000281E94: 8006060C
	s_addc_u32 s7, s13, s7                                     // 000000281E98: 8207070D
	s_add_u32 s8, s12, s8                                      // 000000281E9C: 8008080C
	s_addc_u32 s9, s13, s9                                     // 000000281EA0: 8209090D
	s_sub_i32 s0, 0, s16                                       // 000000281EA4: 81801080
	s_mov_b32 s12, 0                                           // 000000281EA8: BE8C0080
	s_mul_i32 s0, s0, s20                                      // 000000281EAC: 96001400
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000281EB0: BF870499
	s_mul_hi_u32 s0, s20, s0                                   // 000000281EB4: 96800014
	s_add_i32 s13, s20, s0                                     // 000000281EB8: 810D0014
	s_mov_b32 s20, -1                                          // 000000281EBC: BE9400C1
	s_branch 7                                                 // 000000281EC0: BFA00007 <_ZN7halogen12_GLOBAL__N_114k_deq_q4cp_v8uILi8ELb0EEEvPKhPtjjllllNS0_5DeqCbE+0xe0>
	s_or_b32 exec_lo, exec_lo, s1                              // 000000281EC4: 8C7E017E
	s_add_i32 s2, s2, s3                                       // 000000281EC8: 81020302
	s_mov_b32 s20, 0                                           // 000000281ECC: BE940080
	s_lshl_b32 s21, s2, 11                                     // 000000281ED0: 84158B02
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000281ED4: BF870009
	s_cmp_lt_u32 s21, s17                                      // 000000281ED8: BF0A1115
	s_cbranch_scc0 3067                                        // 000000281EDC: BFA10BFB <_ZN7halogen12_GLOBAL__N_114k_deq_q4cp_v8uILi8ELb0EEEvPKhPtjjllllNS0_5DeqCbE+0x30cc>
	v_or_b32_e32 v38, s21, v0                                  // 000000281EE0: 384C0015
	s_add_i32 s0, s21, 0x800                                   // 000000281EE4: 8100FF15 00000800
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000281EEC: BF870009
	s_cmp_le_u32 s0, s17                                       // 000000281EF0: BF0B1100
	s_cselect_b32 s21, -1, 0                                   // 000000281EF4: 981580C1
	s_waitcnt vmcnt(7)                                         // 000000281EF8: BF891FF7
	.long 0xd72d0001                                           // 000000281EFC: D72D0001
	v_cndmask_b32_e32 v0, v38, v13, vcc_lo                     // 000000281F00: 02001B26
	v_add_nc_u32_e32 v20, 0x200, v38                           // 000000281F04: 4A284CFF 00000200
	v_or_b32_e32 v18, 0x400, v38                               // 000000281F0C: 38244CFF 00000400
	v_add_nc_u32_e32 v17, 0x500, v38                           // 000000281F14: 4A224CFF 00000500
	v_add_nc_u32_e32 v16, 0x600, v38                           // 000000281F1C: 4A204CFF 00000600
	v_add_nc_u32_e32 v15, 0x700, v38                           // 000000281F24: 4A1E4CFF 00000700
	.long 0xd72d0031                                           // 000000281F2C: D72D0031
	v_cndmask_b32_e32 v0, v20, v13, vcc_lo                     // 000000281F30: 02001B14
	.long 0xd72d002f                                           // 000000281F34: D72D002F
	v_cndmask_b32_e32 v0, v18, v13, vcc_lo                     // 000000281F38: 02001B12
	s_waitcnt vmcnt(6)                                         // 000000281F3C: BF891BF7
	.long 0xd72c0002                                           // 000000281F40: D72C0002
	v_cndmask_b32_e32 v0, v1, v16, vcc_lo                      // 000000281F44: 02002101
	.long 0xd72d000b                                           // 000000281F48: D72D000B
	v_cndmask_b32_e32 v0, v17, v13, vcc_lo                     // 000000281F4C: 02001B11
	.long 0xd72d000a                                           // 000000281F50: D72D000A
	v_cndmask_b32_e32 v0, v16, v13, vcc_lo                     // 000000281F54: 02001B10
	.long 0xd72d0009                                           // 000000281F58: D72D0009
	v_cndmask_b32_e32 v0, v15, v13, vcc_lo                     // 000000281F5C: 02001B0F
	s_cmp_gt_u32 s0, s17                                       // 000000281F60: BF081100
	s_mov_b32 s0, -1                                           // 000000281F64: BE8000C1
	v_add_nc_u32_e32 v22, 0x100, v38                           // 000000281F68: 4A2C4CFF 00000100
	v_add_nc_u32_e32 v19, 0x300, v38                           // 000000281F70: 4A264CFF 00000300
	v_sub_nc_u32_e32 v2, v38, v2                               // 000000281F78: 4C040526
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000281F7C: BF870193
	.long 0xd72d0032                                           // 000000281F80: D72D0032
	v_cndmask_b32_e32 v0, v22, v13, vcc_lo                     // 000000281F84: 02001B16
	.long 0xd72d0030                                           // 000000281F88: D72D0030
	v_cndmask_b32_e32 v0, v19, v13, vcc_lo                     // 000000281F8C: 02001B13
	s_waitcnt vmcnt(4)                                         // 000000281F90: BF8913F7
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000281F94: BF870123
	v_subrev_nc_u32_e32 v4, s16, v2                            // 000000281F98: 4E080410
	v_cmp_le_u32_e32 vcc_lo, s16, v2                           // 000000281F9C: 7C960410
	v_dual_cndmask_b32 v2, v2, v4 :: v_dual_add_nc_u32 v3, 1, v1// 000000281FA0: CA600902 02020281
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000281FA8: BF870111
	v_cndmask_b32_e32 v1, v1, v3, vcc_lo                       // 000000281FAC: 02020701
	v_cmp_le_u32_e32 vcc_lo, s16, v2                           // 000000281FB0: 7C960410
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000281FB4: BF870092
	v_add_nc_u32_e32 v3, 1, v1                                 // 000000281FB8: 4A060281
	v_cndmask_b32_e32 v28, v1, v3, vcc_lo                      // 000000281FBC: 02380701
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000281FC0: BF870091
	.long 0xd72c0001                                           // 000000281FC4: D72C0001
	v_cndmask_b32_e32 v0, v28, v16, vcc_lo                     // 000000281FC8: 0200211C
	v_sub_nc_u32_e32 v1, v38, v1                               // 000000281FCC: 4C020326
	s_delay_alu instid0(VALU_DEP_1)                            // 000000281FD0: BF870001
	v_lshlrev_b32_e32 v29, 3, v1                               // 000000281FD4: 303A0283
	s_cbranch_scc1 355                                         // 000000281FD8: BFA20163 <_ZN7halogen12_GLOBAL__N_114k_deq_q4cp_v8uILi8ELb0EEEvPKhPtjjllllNS0_5DeqCbE+0x768>
	.long 0xd72c0003                                           // 000000281FDC: D72C0003
	v_cndmask_b32_e32 v0, v50, v16, vcc_lo                     // 000000281FE0: 02002132
	s_waitcnt vmcnt(2)                                         // 000000281FE4: BF890BF7
	.long 0xd72c0006                                           // 000000281FE8: D72C0006
	v_cndmask_b32_e32 v0, v49, v16, vcc_lo                     // 000000281FEC: 02002131
	v_lshrrev_b32_e32 v14, 4, v29                              // 000000281FF0: 321C3A84
	v_add_nc_u32_e32 v21, 1, v49                               // 000000281FF4: 4A2A6281
	v_mad_u64_u32 v[1:2], null, s18, v28, s[6:7]               // 000000281FF8: D6FE7C01 001A3812
	.long 0xd72c0017                                           // 000000282000: D72C0017
	v_cndmask_b32_e32 v0, v48, v16, vcc_lo                     // 000000282004: 02002130
	v_lshrrev_b32_e32 v13, 1, v29                              // 000000282008: 321A3A81
	v_and_b32_e32 v14, 0xffffffe, v14                          // 00000028200C: 361C1CFF 0FFFFFFE
	v_sub_nc_u32_e32 v5, v22, v3                               // 000000282014: 4C0A0716
	v_sub_nc_u32_e32 v6, v20, v6                               // 000000282018: 4C0C0D14
	v_mad_u64_u32 v[3:4], null, s10, v28, s[8:9]               // 00000028201C: D6FE7C03 0022380A
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000282024: BF870223
	v_subrev_nc_u32_e32 v8, s16, v5                            // 000000282028: 4E100A10
	v_cmp_le_u32_e32 vcc_lo, s16, v5                           // 00000028202C: 7C960A10
	v_subrev_nc_u32_e32 v24, s16, v6                           // 000000282030: 4E300C10
	s_waitcnt vmcnt(1)                                         // 000000282034: BF8907F7
	v_add_nc_u32_e32 v7, 1, v50                                // 000000282038: 4A0E6481
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000028203C: BF8701B1
	v_cndmask_b32_e32 v7, v50, v7, vcc_lo                      // 000000282040: 020E0F32
	v_cndmask_b32_e32 v5, v5, v8, vcc_lo                       // 000000282044: 020A1105
	v_cmp_le_u32_e32 vcc_lo, s16, v6                           // 000000282048: 7C960C10
	v_add_nc_u32_e32 v8, 1, v7                                 // 00000028204C: 4A100E81
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000282050: BF8701B3
	.long 0xd44b0000                                           // 000000282054: D44B0000
	v_cndmask_b32_e32 v1, s16, v5, vcc_lo                      // 000000282058: 02020A10
	v_dual_cndmask_b32 v5, v49, v21 :: v_dual_cndmask_b32 v24, v6, v24// 00000028205C: CA522B31 05183106
	v_add_nc_u32_e32 v21, 1, v48                               // 000000282064: 4A2A6081
	v_cndmask_b32_e64 v39, v7, v8, s0                          // 000000282068: D5010027 00021107
	v_mad_u64_u32 v[6:7], null, s19, v28, v[2:3]               // 000000282070: D6FE7C06 040A3813
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000282078: BF8700C4
	v_mad_u64_u32 v[7:8], null, s11, v28, v[4:5]               // 00000028207C: D6FE7C07 0412380B
	v_sub_nc_u32_e32 v8, v19, v23                              // 000000282084: 4C102F13
	v_cmp_le_u32_e32 vcc_lo, s16, v24                          // 000000282088: 7C963010
	.long 0xd72c0019                                           // 00000028208C: D72C0019
	v_cndmask_b32_e32 v0, v39, v16, vcc_lo                     // 000000282090: 02002127
	v_sub_nc_u32_e32 v23, v22, v25                             // 000000282094: 4C2E3316
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000282098: BF8700A1
	v_lshlrev_b32_e32 v40, 3, v23                              // 00000028209C: 30502E83
	v_add_nc_u32_e32 v26, 1, v5                                // 0000002820A0: 4A340A81
	v_cndmask_b32_e32 v31, v5, v26, vcc_lo                     // 0000002820A4: 023E3505
	v_mad_u64_u32 v[4:5], null, s18, v39, s[6:7]               // 0000002820A8: D6FE7C04 001A4E12
	.long 0xd7006a29                                           // 0000002820B0: D7006A29
	v_cndmask_b32_e32 v1, v1, v13, vcc_lo                      // 0000002820B4: 02021B01
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000002820B8: BF8701C1
	v_add_co_ci_u32_e64 v42, null, 0, v6, vcc_lo               // 0000002820BC: D5207C2A 01AA0C80
	.long 0xd7006a06                                           // 0000002820C4: D7006A06
	v_cndmask_b32_e32 v1, v3, v14, vcc_lo                      // 0000002820C8: 02021D03
	v_lshrrev_b32_e32 v3, 1, v40                               // 0000002820CC: 32065081
	v_add_co_ci_u32_e64 v7, null, 0, v7, vcc_lo                // 0000002820D0: D5207C07 01AA0E80
	v_mad_u64_u32 v[13:14], null, s19, v39, v[5:6]             // 0000002820D8: D6FE7C0D 04164E13
	v_mad_u64_u32 v[1:2], null, s10, v39, s[8:9]               // 0000002820E0: D6FE7C01 00224E0A
	s_delay_alu instid0(VALU_DEP_4)                            // 0000002820E8: BF870004
	.long 0xd7006a2b                                           // 0000002820EC: D7006A2B
	v_cndmask_b32_e32 v1, v4, v3, vcc_lo                       // 0000002820F0: 02020704
	v_mad_u64_u32 v[3:4], null, s18, v31, s[6:7]               // 0000002820F4: D6FE7C03 001A3E12
	v_lshrrev_b32_e32 v5, 1, v23                               // 0000002820FC: 320A2E81
	v_subrev_nc_u32_e32 v23, s16, v8                           // 000000282100: 4E2E1010
	v_add_co_ci_u32_e64 v44, null, 0, v13, vcc_lo              // 000000282104: D5207C2C 01AA1A80
	v_cmp_le_u32_e32 vcc_lo, s16, v8                           // 00000028210C: 7C961010
	v_mad_u64_u32 v[13:14], null, s11, v39, v[2:3]             // 000000282110: D6FE7C0D 040A4E0B
	v_and_b32_e32 v2, 0xffffffe, v5                            // 000000282118: 36040AFF 0FFFFFFE
	.long 0xd72c0018                                           // 000000282120: D72C0018
	v_cndmask_b32_e32 v0, v31, v16, vcc_lo                     // 000000282124: 0200211F
	v_cndmask_b32_e32 v8, v8, v23, vcc_lo                      // 000000282128: 02102F08
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000028212C: BF8701A2
	v_sub_nc_u32_e32 v30, v20, v24                             // 000000282130: 4C3C3114
	v_cndmask_b32_e32 v21, v48, v21, vcc_lo                    // 000000282134: 022A2B30
	v_cmp_le_u32_e32 vcc_lo, s16, v8                           // 000000282138: 7C961010
	.long 0xd72c0008                                           // 00000028213C: D72C0008
	v_cndmask_b32_e32 v0, v47, v16, vcc_lo                     // 000000282140: 0200212F
	v_mad_u64_u32 v[23:24], null, s19, v31, v[4:5]             // 000000282144: D6FE7C17 04123E13
	v_lshlrev_b32_e32 v36, 3, v30                              // 00000028214C: 30483C83
	v_add_nc_u32_e32 v14, 1, v21                               // 000000282150: 4A1C2A81
	v_mad_u64_u32 v[4:5], null, s10, v31, s[8:9]               // 000000282154: D6FE7C04 00223E0A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000028215C: BF870193
	v_lshrrev_b32_e32 v24, 1, v36                              // 000000282160: 32304881
	v_cndmask_b32_e32 v27, v21, v14, vcc_lo                    // 000000282164: 02361D15
	.long 0xd7006a19                                           // 000000282168: D7006A19
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 00000028216C: 02020501
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000282170: BF870211
	v_add_co_ci_u32_e64 v26, null, 0, v13, vcc_lo              // 000000282174: D5207C1A 01AA1A80
	.long 0xd7006a2d                                           // 00000028217C: D7006A2D
	v_cndmask_b32_e32 v1, v3, v24, vcc_lo                      // 000000282180: 02023103
	v_sub_nc_u32_e32 v3, v18, v8                               // 000000282184: 4C061112
	v_mad_u64_u32 v[13:14], null, s11, v31, v[5:6]             // 000000282188: D6FE7C0D 04163E0B
	v_add_co_ci_u32_e64 v46, null, 0, v23, vcc_lo              // 000000282190: D5207C2E 01AA2E80
	.long 0xd72c0001                                           // 000000282198: D72C0001
	v_cndmask_b32_e32 v0, v27, v16, vcc_lo                     // 00000028219C: 0200211B
	s_delay_alu instid0(VALU_DEP_4)                            // 0000002821A0: BF870004
	v_subrev_nc_u32_e32 v14, s16, v3                           // 0000002821A4: 4E1C0610
	v_cmp_le_u32_e32 vcc_lo, s16, v3                           // 0000002821A8: 7C960610
	v_add_nc_u32_e32 v2, 1, v47                                // 0000002821AC: 4A045E81
	v_lshrrev_b32_e32 v5, 1, v30                               // 0000002821B0: 320A3C81
	.long 0xd72c0017                                           // 0000002821B4: D72C0017
	v_cndmask_b32_e32 v0, v11, v16, vcc_lo                     // 0000002821B8: 0200210B
	v_cndmask_b32_e32 v3, v3, v14, vcc_lo                      // 0000002821BC: 02061D03
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000002821C0: BF8701B4
	v_cndmask_b32_e32 v21, v47, v2, vcc_lo                     // 0000002821C4: 022A052F
	v_sub_nc_u32_e32 v8, v19, v1                               // 0000002821C8: 4C100313
	v_mad_u64_u32 v[1:2], null, s18, v27, s[6:7]               // 0000002821CC: D6FE7C01 001A3612
	v_add_nc_u32_e32 v14, 1, v21                               // 0000002821D4: 4A1C2A81
	v_and_b32_e32 v5, 0xffffffe, v5                            // 0000002821D8: 360A0AFF 0FFFFFFE
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000002821E0: BF8701A4
	v_lshlrev_b32_e32 v34, 3, v8                               // 0000002821E4: 30441083
	v_lshrrev_b32_e32 v8, 1, v8                                // 0000002821E8: 32101081
	.long 0xd7006a04                                           // 0000002821EC: D7006A04
	v_cndmask_b32_e32 v1, v4, v5, vcc_lo                       // 0000002821F0: 02020B04
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002821F4: BF870001
	v_add_co_ci_u32_e64 v5, null, 0, v13, vcc_lo               // 0000002821F8: D5207C05 01AA1A80
	v_cmp_le_u32_e32 vcc_lo, s16, v3                           // 000000282200: 7C960610
	v_cndmask_b32_e32 v24, v21, v14, vcc_lo                    // 000000282204: 02301D15
	v_mad_u64_u32 v[13:14], null, s19, v27, v[2:3]             // 000000282208: D6FE7C0D 040A3613
	v_mad_u64_u32 v[2:3], null, s10, v27, s[8:9]               // 000000282210: D6FE7C02 0022360A
	v_lshrrev_b32_e32 v14, 1, v34                              // 000000282218: 321C4481
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000028221C: BF870114
	.long 0xd72c0015                                           // 000000282220: D72C0015
	v_cndmask_b32_e32 v0, v24, v16, vcc_lo                     // 000000282224: 02002118
	.long 0xd7006a34                                           // 000000282228: D7006A34
	v_cndmask_b32_e32 v1, v1, v14, vcc_lo                      // 00000028222C: 02021D01
	s_delay_alu instid0(VALU_DEP_1)                            // 000000282230: BF870001
	v_add_co_ci_u32_e64 v53, null, 0, v13, vcc_lo              // 000000282234: D5207C35 01AA1A80
	v_mad_u64_u32 v[13:14], null, s11, v27, v[3:4]             // 00000028223C: D6FE7C0D 040E360B
	v_and_b32_e32 v1, 0xffffffe, v8                            // 000000282244: 360210FF 0FFFFFFE
	v_sub_nc_u32_e32 v3, v17, v23                              // 00000028224C: 4C062F11
	v_add_nc_u32_e32 v8, 1, v11                                // 000000282250: 4A101681
	v_sub_nc_u32_e32 v21, v18, v21                             // 000000282254: 4C2A2B12
	s_delay_alu instid0(VALU_DEP_4)                            // 000000282258: BF870004
	.long 0xd7006a20                                           // 00000028225C: D7006A20
	v_cndmask_b32_e32 v1, v2, v1, vcc_lo                       // 000000282260: 02020302
	v_mad_u64_u32 v[1:2], null, s18, v24, s[6:7]               // 000000282264: D6FE7C01 001A3012
	v_add_co_ci_u32_e64 v33, null, 0, v13, vcc_lo              // 00000028226C: D5207C21 01AA1A80
	v_cmp_le_u32_e32 vcc_lo, s16, v3                           // 000000282274: 7C960610
	v_subrev_nc_u32_e32 v23, s16, v3                           // 000000282278: 4E2E0610
	v_dual_cndmask_b32 v13, v11, v8 :: v_dual_lshlrev_b32 v30, 3, v21// 00000028227C: CA62110B 0D1E2A83
	s_clause 0x3                                               // 000000282284: BF850003
	global_load_d16_b16 v8, v[6:7], off                        // 000000282288: DC820000 087C0006
	global_load_d16_hi_b16 v8, v[25:26], off                   // 000000282290: DC8E0000 087C0019
	global_load_d16_b16 v14, v[4:5], off                       // 000000282298: DC820000 0E7C0004
	global_load_d16_hi_b16 v14, v[32:33], off                  // 0000002822A0: DC8E0000 0E7C0020
	v_mad_u64_u32 v[4:5], null, s19, v24, v[2:3]               // 0000002822A8: D6FE7C04 040A3013
	v_cndmask_b32_e32 v5, v3, v23, vcc_lo                      // 0000002822B0: 020A2F03
	v_lshrrev_b32_e32 v7, 1, v30                               // 0000002822B4: 320E3C81
	v_add_nc_u32_e32 v6, 1, v13                                // 0000002822B8: 4A0C1A81
	.long 0xd72c0017                                           // 0000002822BC: D72C0017
	v_cndmask_b32_e32 v0, v10, v16, vcc_lo                     // 0000002822C0: 0200210A
	v_mad_u64_u32 v[2:3], null, s10, v24, s[8:9]               // 0000002822C4: D6FE7C02 0022300A
	v_cmp_le_u32_e32 vcc_lo, s16, v5                           // 0000002822CC: 7C960A10
	.long 0xd72c001a                                           // 0000002822D0: D72C001A
	v_cndmask_b32_e32 v0, v9, v16, vcc_lo                      // 0000002822D4: 02002109
	v_cndmask_b32_e32 v25, v13, v6, vcc_lo                     // 0000002822D8: 02320D0D
	.long 0xd7006a36                                           // 0000002822DC: D7006A36
	v_cndmask_b32_e32 v1, v1, v7, vcc_lo                       // 0000002822E0: 02020F01
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002822E4: BF870191
	v_add_co_ci_u32_e64 v55, null, 0, v4, vcc_lo               // 0000002822E8: D5207C37 01AA0880
	.long 0xd72c0004                                           // 0000002822F0: D72C0004
	v_cndmask_b32_e32 v0, v25, v16, vcc_lo                     // 0000002822F4: 02002119
	v_sub_nc_u32_e32 v1, v16, v23                              // 0000002822F8: 4C022F10
	v_lshrrev_b32_e32 v13, 1, v21                              // 0000002822FC: 321A2A81
	v_add_nc_u32_e32 v7, 1, v10                                // 000000282300: 4A0E1481
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000282304: BF870193
	v_cmp_le_u32_e32 vcc_lo, s16, v1                           // 000000282308: 7C960210
	v_and_b32_e32 v13, 0xffffffe, v13                          // 00000028230C: 361A1AFF 0FFFFFFE
	v_mad_u64_u32 v[5:6], null, s11, v24, v[3:4]               // 000000282314: D6FE7C05 040E300B
	v_subrev_nc_u32_e32 v6, s16, v1                            // 00000028231C: 4E0C0210
	v_sub_nc_u32_e32 v21, v17, v4                              // 000000282320: 4C2A0911
	v_cndmask_b32_e32 v7, v10, v7, vcc_lo                      // 000000282324: 020E0F0A
	v_mad_u64_u32 v[3:4], null, s18, v25, s[6:7]               // 000000282328: D6FE7C03 001A3212
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000282330: BF870224
	v_cndmask_b32_e32 v1, v1, v6, vcc_lo                       // 000000282334: 02020D01
	.long 0xd7006a38                                           // 000000282338: D7006A38
	v_cndmask_b32_e32 v1, v2, v13, vcc_lo                      // 00000028233C: 02021B02
	v_add_nc_u32_e32 v6, 1, v7                                 // 000000282340: 4A0C0E81
	v_add_co_ci_u32_e64 v57, null, 0, v5, vcc_lo               // 000000282344: D5207C39 01AA0A80
	s_delay_alu instid0(VALU_DEP_4)                            // 00000028234C: BF870004
	v_cmp_le_u32_e32 vcc_lo, s16, v1                           // 000000282350: 7C960210
	v_lshlrev_b32_e32 v33, 3, v21                              // 000000282354: 30422A83
	v_sub_nc_u32_e32 v5, v15, v26                              // 000000282358: 4C0A350F
	v_lshrrev_b32_e32 v21, 1, v21                              // 00000028235C: 322A2A81
	v_mad_u64_u32 v[1:2], null, s10, v25, s[8:9]               // 000000282360: D6FE7C01 0022320A
	v_cndmask_b32_e32 v23, v7, v6, vcc_lo                      // 000000282368: 022E0D07
	v_add_nc_u32_e32 v13, 1, v9                                // 00000028236C: 4A1A1281
	v_mad_u64_u32 v[6:7], null, s19, v25, v[4:5]               // 000000282370: D6FE7C06 04123213
	v_and_b32_e32 v32, 0xffffffe, v21                          // 000000282378: 36402AFF 0FFFFFFE
	v_subrev_nc_u32_e32 v7, s16, v5                            // 000000282380: 4E0E0A10
	.long 0xd72c0004                                           // 000000282384: D72C0004
	v_cndmask_b32_e32 v0, v23, v16, vcc_lo                     // 000000282388: 02002117
	v_cmp_le_u32_e32 vcc_lo, s16, v5                           // 00000028238C: 7C960A10
	v_mad_u64_u32 v[58:59], null, s11, v25, v[2:3]             // 000000282390: D6FE7C3A 040A320B
	v_lshrrev_b32_e32 v26, 1, v33                              // 000000282398: 32344281
	v_cndmask_b32_e32 v2, v5, v7, vcc_lo                       // 00000028239C: 02040F05
	s_waitcnt vmcnt(4)                                         // 0000002823A0: BF8913F7
	v_sub_nc_u32_e32 v35, v16, v4                              // 0000002823A4: 4C460910
	v_cndmask_b32_e32 v13, v9, v13, vcc_lo                     // 0000002823A8: 021A1B09
	v_mad_u64_u32 v[4:5], null, s18, v23, s[6:7]               // 0000002823AC: D6FE7C04 001A2E12
	v_cmp_le_u32_e32 vcc_lo, s16, v2                           // 0000002823B4: 7C960410
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002823B8: BF870193
	v_add_nc_u32_e32 v7, 1, v13                                // 0000002823BC: 4A0E1A81
	v_mad_u64_u32 v[63:64], null, s19, v23, v[5:6]             // 0000002823C0: D6FE7C3F 04162E13
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002823C8: BF8700A2
	v_cndmask_b32_e32 v21, v13, v7, vcc_lo                     // 0000002823CC: 022A0F0D
	.long 0xd7006a3b                                           // 0000002823D0: D7006A3B
	v_cndmask_b32_e32 v1, v3, v26, vcc_lo                      // 0000002823D4: 02023503
	v_add_co_ci_u32_e64 v60, null, 0, v6, vcc_lo               // 0000002823D8: D5207C3C 01AA0C80
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 0000002823E0: BF870253
	.long 0xd72c0003                                           // 0000002823E4: D72C0003
	v_cndmask_b32_e32 v0, v21, v16, vcc_lo                     // 0000002823E8: 02002115
	v_lshlrev_b32_e32 v26, 3, v35                              // 0000002823EC: 30344683
	.long 0xd7006a3d                                           // 0000002823F0: D7006A3D
	v_cndmask_b32_e32 v1, v1, v32, vcc_lo                      // 0000002823F4: 02024101
	v_mad_u64_u32 v[1:2], null, s10, v23, s[8:9]               // 0000002823F8: D6FE7C01 00222E0A
	v_mad_u64_u32 v[5:6], null, s10, v21, s[8:9]               // 000000282400: D6FE7C05 00222A0A
	v_lshrrev_b32_e32 v7, 1, v26                               // 000000282408: 320E3481
	v_lshrrev_b32_e32 v13, 1, v35                              // 00000028240C: 321A4681
	v_sub_nc_u32_e32 v32, v15, v3                              // 000000282410: 4C40070F
	v_add_co_ci_u32_e64 v62, null, 0, v58, vcc_lo              // 000000282414: D5207C3E 01AA7480
	s_delay_alu instid0(VALU_DEP_4)                            // 00000028241C: BF870004
	.long 0xd7006a40                                           // 000000282420: D7006A40
	v_cndmask_b32_e32 v1, v4, v7, vcc_lo                       // 000000282424: 02020F04
	v_mad_u64_u32 v[66:67], null, s11, v23, v[2:3]             // 000000282428: D6FE7C42 040A2E0B
	v_mad_u64_u32 v[2:3], null, s18, v21, s[6:7]               // 000000282430: D6FE7C02 001A2A12
	v_lshrrev_b32_e32 v4, 1, v32                               // 000000282438: 32084081
	v_and_b32_e32 v35, 0xffffffe, v13                          // 00000028243C: 36461AFF 0FFFFFFE
	v_lshlrev_b32_e32 v13, 3, v32                              // 000000282444: 301A4083
	v_mad_u64_u32 v[6:7], null, s11, v21, v[6:7]               // 000000282448: D6FE7C06 041A2A0B
	v_add_co_ci_u32_e64 v65, null, 0, v63, vcc_lo              // 000000282450: D5207C41 01AA7E80
	v_and_b32_e32 v7, 0xffffffe, v4                            // 000000282458: 360E08FF 0FFFFFFE
	v_mad_u64_u32 v[3:4], null, s19, v21, v[3:4]               // 000000282460: D6FE7C03 040E2A13
	.long 0xd7006a43                                           // 000000282468: D7006A43
	v_cndmask_b32_e32 v1, v1, v35, vcc_lo                      // 00000028246C: 02024701
	v_lshrrev_b32_e32 v1, 1, v13                               // 000000282470: 32021A81
	v_add_co_ci_u32_e64 v68, null, 0, v66, vcc_lo              // 000000282474: D5207C44 01AA8480
	.long 0xd7006a04                                           // 00000028247C: D7006A04
	v_cndmask_b32_e32 v1, v5, v7, vcc_lo                       // 000000282480: 02020F05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000282484: BF870211
	v_add_co_ci_u32_e64 v5, null, 0, v6, vcc_lo                // 000000282488: D5207C05 01AA0C80
	.long 0xd7006a45                                           // 000000282490: D7006A45
	v_cndmask_b32_e32 v1, v2, v1, vcc_lo                       // 000000282494: 02020302
	s_delay_alu instid0(VALU_DEP_1)                            // 000000282498: BF870001
	v_add_co_ci_u32_e64 v70, null, 0, v3, vcc_lo               // 00000028249C: D5207C46 01AA0680
	s_clause 0xb                                               // 0000002824A4: BF85000B
	global_load_d16_b16 v32, v[56:57], off                     // 0000002824A8: DC820000 207C0038
	global_load_d16_hi_b16 v32, v[61:62], off                  // 0000002824B0: DC8E0000 207C003D
	global_load_d16_b16 v37, v[67:68], off                     // 0000002824B8: DC820000 257C0043
	global_load_d16_b16 v51, v[4:5], off                       // 0000002824C0: DC820000 337C0004
	global_load_b32 v1, v[41:42], off                          // 0000002824C8: DC520000 017C0029
	global_load_b32 v2, v[43:44], off                          // 0000002824D0: DC520000 027C002B
	global_load_b32 v3, v[45:46], off                          // 0000002824D8: DC520000 037C002D
	global_load_b32 v4, v[52:53], off                          // 0000002824E0: DC520000 047C0034
	global_load_b32 v5, v[54:55], off                          // 0000002824E8: DC520000 057C0036
	global_load_b32 v6, v[59:60], off                          // 0000002824F0: DC520000 067C003B
	global_load_b32 v7, v[64:65], off                          // 0000002824F8: DC520000 077C0040
	global_load_b32 v35, v[69:70], off                         // 000000282500: DC520000 237C0045
	s_waitcnt vmcnt(14)                                        // 000000282508: BF893BF7
	v_cvt_f32_f16_e32 v46, v8                                  // 00000028250C: 7E5C1708
	v_cvt_f32_f16_e32 v45, v136/*Invalid register, operand has 'VS_32_Lo128' register class*/// 000000282510: 7E5A1788
	s_waitcnt vmcnt(12)                                        // 000000282514: BF8933F7
	v_cvt_f32_f16_e32 v44, v14                                 // 000000282518: 7E58170E
	v_cvt_f32_f16_e32 v43, v142/*Invalid register, operand has 'VS_32_Lo128' register class*/// 00000028251C: 7E56178E
	s_waitcnt vmcnt(10)                                        // 000000282520: BF892BF7
	v_cvt_f32_f16_e32 v42, v32                                 // 000000282524: 7E541720
	v_cvt_f32_f16_e32 v41, v160/*Invalid register, operand has 'VS_32_Lo128' register class*/// 000000282528: 7E5217A0
	s_waitcnt vmcnt(9)                                         // 00000028252C: BF8927F7
	v_cvt_f32_f16_e32 v37, v37                                 // 000000282530: 7E4A1725
	s_waitcnt vmcnt(8)                                         // 000000282534: BF8923F7
	v_cvt_f32_f16_e32 v32, v51                                 // 000000282538: 7E401733
	s_cbranch_execz 12                                         // 00000028253C: BFA5000C <_ZN7halogen12_GLOBAL__N_114k_deq_q4cp_v8uILi8ELb0EEEvPKhPtjjllllNS0_5DeqCbE+0x770>
	s_and_not1_b32 vcc_lo, exec_lo, s20                        // 000000282540: 916A147E
	s_cbranch_vccnz 515                                        // 000000282544: BFA40203 <_ZN7halogen12_GLOBAL__N_114k_deq_q4cp_v8uILi8ELb0EEEvPKhPtjjllllNS0_5DeqCbE+0xf54>
	s_waitcnt vmcnt(0)                                         // 000000282548: BF8903F7
	s_barrier                                                  // 00000028254C: BFBD0000
	buffer_gl0_inv                                             // 000000282550: E0AC0000 00000000
	s_and_not1_b32 vcc_lo, exec_lo, s21                        // 000000282558: 916A157E
	s_cbranch_vccz 511                                         // 00000028255C: BFA301FF <_ZN7halogen12_GLOBAL__N_114k_deq_q4cp_v8uILi8ELb0EEEvPKhPtjjllllNS0_5DeqCbE+0xf5c>
	s_mov_b32 s0, 0                                            // 000000282560: BE800080
	s_branch 1522                                              // 000000282564: BFA005F2 <_ZN7halogen12_GLOBAL__N_114k_deq_q4cp_v8uILi8ELb0EEEvPKhPtjjllllNS0_5DeqCbE+0x1f30>
	s_and_not1_b32 vcc_lo, exec_lo, s0                         // 000000282568: 916A007E
	s_cbranch_vccnz 65524                                      // 00000028256C: BFA4FFF4 <_ZN7halogen12_GLOBAL__N_114k_deq_q4cp_v8uILi8ELb0EEEvPKhPtjjllllNS0_5DeqCbE+0x740>
	s_mov_b32 s0, exec_lo                                      // 000000282570: BE80007E
	.long 0xd4cb007e                                           // 000000282574: D4CB007E
	v_cndmask_b32_e32 v1, s17, v38, vcc_lo                     // 000000282578: 02024C11
	s_xor_b32 s0, exec_lo, s0                                  // 00000028257C: 8D00007E
	s_cbranch_execz 2                                          // 000000282580: BFA50002 <_ZN7halogen12_GLOBAL__N_114k_deq_q4cp_v8uILi8ELb0EEEvPKhPtjjllllNS0_5DeqCbE+0x78c>
	s_waitcnt vmcnt(1)                                         // 000000282584: BF8907F7
	v_mov_b32_e32 v1, s12                                      // 000000282588: 7E02020C
	s_or_saveexec_b32 s0, s0                                   // 00000028258C: BE802200
	v_mov_b32_e32 v46, 0                                       // 000000282590: 7E5C0280
	s_xor_b32 exec_lo, exec_lo, s0                             // 000000282594: 8D7E007E
	s_cbranch_execz 33                                         // 000000282598: BFA50021 <_ZN7halogen12_GLOBAL__N_114k_deq_q4cp_v8uILi8ELb0EEEvPKhPtjjllllNS0_5DeqCbE+0x820>
	s_waitcnt vmcnt(6)                                         // 00000028259C: BF891BF7
	v_mad_u64_u32 v[1:2], null, s10, v28, s[8:9]               // 0000002825A0: D6FE7C01 0022380A
	s_waitcnt vmcnt(4)                                         // 0000002825A8: BF8913F7
	v_mad_u64_u32 v[3:4], null, s18, v28, s[6:7]               // 0000002825AC: D6FE7C03 001A3812
	s_waitcnt vmcnt(1)                                         // 0000002825B4: BF8907F7
	v_lshrrev_b32_e32 v7, 4, v29                               // 0000002825B8: 320E3A84
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002825BC: BF870112
	v_mad_u64_u32 v[5:6], null, s11, v28, v[2:3]               // 0000002825C0: D6FE7C05 040A380B
	v_and_b32_e32 v2, 0xffffffe, v7                            // 0000002825C8: 36040EFF 0FFFFFFE
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002825D0: BF870191
	.long 0xd7006a01                                           // 0000002825D4: D7006A01
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 0000002825D8: 02020501
	v_mad_u64_u32 v[6:7], null, s19, v28, v[4:5]               // 0000002825DC: D6FE7C06 04123813
	v_lshrrev_b32_e32 v4, 1, v29                               // 0000002825E4: 32083A81
	v_add_co_ci_u32_e64 v2, null, 0, v5, vcc_lo                // 0000002825E8: D5207C02 01AA0A80
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002825F0: BF870092
	.long 0xd7006a03                                           // 0000002825F4: D7006A03
	v_cndmask_b32_e32 v1, v3, v4, vcc_lo                       // 0000002825F8: 02020903
	v_add_co_ci_u32_e64 v4, null, 0, v6, vcc_lo                // 0000002825FC: D5207C04 01AA0C80
	s_clause 0x1                                               // 000000282604: BF850001
	global_load_d16_b16 v2, v[1:2], off                        // 000000282608: DC820000 027C0001
	global_load_b32 v1, v[3:4], off                            // 000000282610: DC520000 017C0003
	s_waitcnt vmcnt(1)                                         // 000000282618: BF8907F7
	v_cvt_f32_f16_e32 v46, v2                                  // 00000028261C: 7E5C1702
	s_or_b32 exec_lo, exec_lo, s0                              // 000000282620: 8C7E007E
	.long 0xd72c0008                                           // 000000282624: D72C0008
	v_cndmask_b32_e32 v0, v50, v16, vcc_lo                     // 000000282628: 02002132
	.long 0xd44b0001                                           // 00000028262C: D44B0001
	v_cndmask_b32_e32 v1, s17, v22, vcc_lo                     // 000000282630: 02022C11
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000282634: BF870092
	v_sub_nc_u32_e32 v8, v22, v8                               // 000000282638: 4C101116
	v_subrev_nc_u32_e32 v13, s16, v8                           // 00000028263C: 4E1A1010
	v_cmp_le_u32_e32 vcc_lo, s16, v8                           // 000000282640: 7C961010
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000282644: BF870092
	v_cndmask_b32_e32 v8, v8, v13, vcc_lo                      // 000000282648: 02101B08
	.long 0xd44b0000                                           // 00000028264C: D44B0000
	v_cndmask_b32_e32 v1, s16, v8, vcc_lo                      // 000000282650: 02021010
	s_and_saveexec_b32 s22, s1                                 // 000000282654: BE962001
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000282658: BF870009
	s_xor_b32 s1, exec_lo, s22                                 // 00000028265C: 8D01167E
	s_cbranch_execz 2                                          // 000000282660: BFA50002 <_ZN7halogen12_GLOBAL__N_114k_deq_q4cp_v8uILi8ELb0EEEvPKhPtjjllllNS0_5DeqCbE+0x86c>
	s_waitcnt vmcnt(6)                                         // 000000282664: BF891BF7
	v_mov_b32_e32 v2, s12                                      // 000000282668: 7E04020C
	s_or_saveexec_b32 s1, s1                                   // 00000028266C: BE812201
	v_dual_mov_b32 v45, 0 :: v_dual_add_nc_u32 v8, 1, v50      // 000000282670: CA200080 2D086481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000282678: BF870091
	v_cndmask_b32_e32 v8, v50, v8, vcc_lo                      // 00000028267C: 02101132
	v_add_nc_u32_e32 v13, 1, v8                                // 000000282680: 4A1A1081
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000282684: BF870091
	v_cndmask_b32_e64 v39, v8, v13, s0                         // 000000282688: D5010027 00021B08
	.long 0xd72c0008                                           // 000000282690: D72C0008
	v_cndmask_b32_e32 v0, v39, v16, vcc_lo                     // 000000282694: 02002127
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000282698: BF870091
	v_sub_nc_u32_e32 v8, v22, v8                               // 00000028269C: 4C101116
	v_lshlrev_b32_e32 v40, 3, v8                               // 0000002826A0: 30501083
	s_xor_b32 exec_lo, exec_lo, s1                             // 0000002826A4: 8D7E017E
	s_cbranch_execz 30                                         // 0000002826A8: BFA5001E <_ZN7halogen12_GLOBAL__N_114k_deq_q4cp_v8uILi8ELb0EEEvPKhPtjjllllNS0_5DeqCbE+0x924>
	v_mad_u64_u32 v[13:14], null, s10, v39, s[8:9]             // 0000002826AC: D6FE7C0D 00224E0A
	v_mad_u64_u32 v[23:24], null, s18, v39, s[6:7]             // 0000002826B4: D6FE7C17 001A4E12
	s_waitcnt vmcnt(6)                                         // 0000002826BC: BF891BF7
	v_lshrrev_b32_e32 v2, 4, v40                               // 0000002826C0: 32045084
	v_lshrrev_b32_e32 v8, 1, v40                               // 0000002826C4: 32105081
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002826C8: BF870122
	v_and_b32_e32 v2, 0xffffffe, v2                            // 0000002826CC: 360404FF 0FFFFFFE
	v_mad_u64_u32 v[25:26], null, s11, v39, v[14:15]           // 0000002826D4: D6FE7C19 043A4E0B
	.long 0xd7006a0d                                           // 0000002826DC: D7006A0D
	v_cndmask_b32_e32 v1, v13, v2, vcc_lo                      // 0000002826E0: 0202050D
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000002826E4: BF8700B2
	v_mad_u64_u32 v[26:27], null, s19, v39, v[24:25]           // 0000002826E8: D6FE7C1A 04624E13
	v_add_co_ci_u32_e64 v14, null, 0, v25, vcc_lo              // 0000002826F0: D5207C0E 01AA3280
	.long 0xd7006a17                                           // 0000002826F8: D7006A17
	v_cndmask_b32_e32 v1, v23, v8, vcc_lo                      // 0000002826FC: 02021117
	v_add_co_ci_u32_e64 v24, null, 0, v26, vcc_lo              // 000000282700: D5207C18 01AA3480
	s_clause 0x1                                               // 000000282708: BF850001
	global_load_d16_b16 v8, v[13:14], off                      // 00000028270C: DC820000 087C000D
	global_load_b32 v2, v[23:24], off                          // 000000282714: DC520000 027C0017
	s_waitcnt vmcnt(1)                                         // 00000028271C: BF8907F7
	v_cvt_f32_f16_e32 v45, v8                                  // 000000282720: 7E5A1708
	s_or_b32 exec_lo, exec_lo, s1                              // 000000282724: 8C7E017E
	.long 0xd72c0008                                           // 000000282728: D72C0008
	v_cndmask_b32_e32 v0, v49, v16, vcc_lo                     // 00000028272C: 02002131
	.long 0xd44b0001                                           // 000000282730: D44B0001
	v_cndmask_b32_e32 v1, s17, v20, vcc_lo                     // 000000282734: 02022811
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000282738: BF870092
	v_sub_nc_u32_e32 v8, v20, v8                               // 00000028273C: 4C101114
	v_subrev_nc_u32_e32 v13, s16, v8                           // 000000282740: 4E1A1010
	v_cmp_le_u32_e32 vcc_lo, s16, v8                           // 000000282744: 7C961010
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000282748: BF870092
	v_cndmask_b32_e32 v8, v8, v13, vcc_lo                      // 00000028274C: 02101B08
	.long 0xd44b0000                                           // 000000282750: D44B0000
	v_cndmask_b32_e32 v1, s16, v8, vcc_lo                      // 000000282754: 02021010
	s_and_saveexec_b32 s22, s1                                 // 000000282758: BE962001
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000028275C: BF870009
	s_xor_b32 s1, exec_lo, s22                                 // 000000282760: 8D01167E
	s_cbranch_execz 2                                          // 000000282764: BFA50002 <_ZN7halogen12_GLOBAL__N_114k_deq_q4cp_v8uILi8ELb0EEEvPKhPtjjllllNS0_5DeqCbE+0x970>
	s_waitcnt vmcnt(5)                                         // 000000282768: BF8917F7
	v_mov_b32_e32 v3, s12                                      // 00000028276C: 7E06020C
	s_or_saveexec_b32 s1, s1                                   // 000000282770: BE812201
	v_add_nc_u32_e32 v8, 1, v49                                // 000000282774: 4A106281
	v_mov_b32_e32 v44, 0                                       // 000000282778: 7E580280
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000028277C: BF870092
	v_cndmask_b32_e32 v8, v49, v8, vcc_lo                      // 000000282780: 02101131
	v_add_nc_u32_e32 v13, 1, v8                                // 000000282784: 4A1A1081
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000282788: BF870091
	v_cndmask_b32_e64 v31, v8, v13, s0                         // 00000028278C: D501001F 00021B08
	.long 0xd72c0008                                           // 000000282794: D72C0008
	v_cndmask_b32_e32 v0, v31, v16, vcc_lo                     // 000000282798: 0200211F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000028279C: BF870091
	v_sub_nc_u32_e32 v8, v20, v8                               // 0000002827A0: 4C101114
	v_lshlrev_b32_e32 v36, 3, v8                               // 0000002827A4: 30481083
	s_xor_b32 exec_lo, exec_lo, s1                             // 0000002827A8: 8D7E017E
	s_cbranch_execz 30                                         // 0000002827AC: BFA5001E <_ZN7halogen12_GLOBAL__N_114k_deq_q4cp_v8uILi8ELb0EEEvPKhPtjjllllNS0_5DeqCbE+0xa28>
	v_mad_u64_u32 v[13:14], null, s10, v31, s[8:9]             // 0000002827B0: D6FE7C0D 00223E0A
	v_mad_u64_u32 v[23:24], null, s18, v31, s[6:7]             // 0000002827B8: D6FE7C17 001A3E12
	s_waitcnt vmcnt(5)                                         // 0000002827C0: BF8917F7
	v_lshrrev_b32_e32 v3, 4, v36                               // 0000002827C4: 32064884
	v_lshrrev_b32_e32 v8, 1, v36                               // 0000002827C8: 32104881
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002827CC: BF870122
	v_and_b32_e32 v3, 0xffffffe, v3                            // 0000002827D0: 360606FF 0FFFFFFE
	v_mad_u64_u32 v[25:26], null, s11, v31, v[14:15]           // 0000002827D8: D6FE7C19 043A3E0B
	.long 0xd7006a0d                                           // 0000002827E0: D7006A0D
	v_cndmask_b32_e32 v1, v13, v3, vcc_lo                      // 0000002827E4: 0202070D
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000002827E8: BF8700B2
	v_mad_u64_u32 v[26:27], null, s19, v31, v[24:25]           // 0000002827EC: D6FE7C1A 04623E13
	v_add_co_ci_u32_e64 v14, null, 0, v25, vcc_lo              // 0000002827F4: D5207C0E 01AA3280
	.long 0xd7006a17                                           // 0000002827FC: D7006A17
	v_cndmask_b32_e32 v1, v23, v8, vcc_lo                      // 000000282800: 02021117
	v_add_co_ci_u32_e64 v24, null, 0, v26, vcc_lo              // 000000282804: D5207C18 01AA3480
	s_clause 0x1                                               // 00000028280C: BF850001
	global_load_d16_b16 v8, v[13:14], off                      // 000000282810: DC820000 087C000D
	global_load_b32 v3, v[23:24], off                          // 000000282818: DC520000 037C0017
	s_waitcnt vmcnt(1)                                         // 000000282820: BF8907F7
	v_cvt_f32_f16_e32 v44, v8                                  // 000000282824: 7E581708
	s_or_b32 exec_lo, exec_lo, s1                              // 000000282828: 8C7E017E
	.long 0xd72c0008                                           // 00000028282C: D72C0008
	v_cndmask_b32_e32 v0, v48, v16, vcc_lo                     // 000000282830: 02002130
	.long 0xd44b0001                                           // 000000282834: D44B0001
	v_cndmask_b32_e32 v1, s17, v19, vcc_lo                     // 000000282838: 02022611
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000028283C: BF870092
	v_sub_nc_u32_e32 v8, v19, v8                               // 000000282840: 4C101113
	v_subrev_nc_u32_e32 v13, s16, v8                           // 000000282844: 4E1A1010
	v_cmp_le_u32_e32 vcc_lo, s16, v8                           // 000000282848: 7C961010
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000028284C: BF870092
	v_cndmask_b32_e32 v8, v8, v13, vcc_lo                      // 000000282850: 02101B08
	.long 0xd44b0000                                           // 000000282854: D44B0000
	v_cndmask_b32_e32 v1, s16, v8, vcc_lo                      // 000000282858: 02021010
	s_and_saveexec_b32 s22, s1                                 // 00000028285C: BE962001
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000282860: BF870009
	s_xor_b32 s1, exec_lo, s22                                 // 000000282864: 8D01167E
	s_cbranch_execz 2                                          // 000000282868: BFA50002 <_ZN7halogen12_GLOBAL__N_114k_deq_q4cp_v8uILi8ELb0EEEvPKhPtjjllllNS0_5DeqCbE+0xa74>
	s_waitcnt vmcnt(4)                                         // 00000028286C: BF8913F7
	v_mov_b32_e32 v4, s12                                      // 000000282870: 7E08020C
	s_or_saveexec_b32 s1, s1                                   // 000000282874: BE812201
	v_dual_mov_b32 v43, 0 :: v_dual_add_nc_u32 v8, 1, v48      // 000000282878: CA200080 2B086081
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000282880: BF870091
	v_cndmask_b32_e32 v8, v48, v8, vcc_lo                      // 000000282884: 02101130
	v_add_nc_u32_e32 v13, 1, v8                                // 000000282888: 4A1A1081
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000028288C: BF870091
	v_cndmask_b32_e64 v27, v8, v13, s0                         // 000000282890: D501001B 00021B08
	.long 0xd72c0008                                           // 000000282898: D72C0008
	v_cndmask_b32_e32 v0, v27, v16, vcc_lo                     // 00000028289C: 0200211B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002828A0: BF870091
	v_sub_nc_u32_e32 v8, v19, v8                               // 0000002828A4: 4C101113
	v_lshlrev_b32_e32 v34, 3, v8                               // 0000002828A8: 30441083
	s_xor_b32 exec_lo, exec_lo, s1                             // 0000002828AC: 8D7E017E
	s_cbranch_execz 30                                         // 0000002828B0: BFA5001E <_ZN7halogen12_GLOBAL__N_114k_deq_q4cp_v8uILi8ELb0EEEvPKhPtjjllllNS0_5DeqCbE+0xb2c>
	v_mad_u64_u32 v[13:14], null, s10, v27, s[8:9]             // 0000002828B4: D6FE7C0D 0022360A
	v_mad_u64_u32 v[23:24], null, s18, v27, s[6:7]             // 0000002828BC: D6FE7C17 001A3612
	s_waitcnt vmcnt(4)                                         // 0000002828C4: BF8913F7
	v_lshrrev_b32_e32 v4, 4, v34                               // 0000002828C8: 32084484
	v_lshrrev_b32_e32 v8, 1, v34                               // 0000002828CC: 32104481
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002828D0: BF870122
	v_and_b32_e32 v4, 0xffffffe, v4                            // 0000002828D4: 360808FF 0FFFFFFE
	v_mad_u64_u32 v[25:26], null, s11, v27, v[14:15]           // 0000002828DC: D6FE7C19 043A360B
	.long 0xd7006a0d                                           // 0000002828E4: D7006A0D
	v_cndmask_b32_e32 v1, v13, v4, vcc_lo                      // 0000002828E8: 0202090D
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000002828EC: BF8700B2
	v_mad_u64_u32 v[32:33], null, s19, v27, v[24:25]           // 0000002828F0: D6FE7C20 04623613
	v_add_co_ci_u32_e64 v14, null, 0, v25, vcc_lo              // 0000002828F8: D5207C0E 01AA3280
	.long 0xd7006a17                                           // 000000282900: D7006A17
	v_cndmask_b32_e32 v1, v23, v8, vcc_lo                      // 000000282904: 02021117
	v_add_co_ci_u32_e64 v24, null, 0, v32, vcc_lo              // 000000282908: D5207C18 01AA4080
	s_clause 0x1                                               // 000000282910: BF850001
	global_load_d16_b16 v8, v[13:14], off                      // 000000282914: DC820000 087C000D
	global_load_b32 v4, v[23:24], off                          // 00000028291C: DC520000 047C0017
	s_waitcnt vmcnt(1)                                         // 000000282924: BF8907F7
	v_cvt_f32_f16_e32 v43, v8                                  // 000000282928: 7E561708
	s_or_b32 exec_lo, exec_lo, s1                              // 00000028292C: 8C7E017E
	.long 0xd72c0008                                           // 000000282930: D72C0008
	v_cndmask_b32_e32 v0, v47, v16, vcc_lo                     // 000000282934: 0200212F
	.long 0xd44b0001                                           // 000000282938: D44B0001
	v_cndmask_b32_e32 v1, s17, v18, vcc_lo                     // 00000028293C: 02022411
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000282940: BF870092
	v_sub_nc_u32_e32 v8, v18, v8                               // 000000282944: 4C101112
	v_subrev_nc_u32_e32 v13, s16, v8                           // 000000282948: 4E1A1010
	v_cmp_le_u32_e32 vcc_lo, s16, v8                           // 00000028294C: 7C961010
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000282950: BF870092
	v_cndmask_b32_e32 v8, v8, v13, vcc_lo                      // 000000282954: 02101B08
	.long 0xd44b0000                                           // 000000282958: D44B0000
	v_cndmask_b32_e32 v1, s16, v8, vcc_lo                      // 00000028295C: 02021010
	s_and_saveexec_b32 s22, s1                                 // 000000282960: BE962001
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000282964: BF870009
	s_xor_b32 s1, exec_lo, s22                                 // 000000282968: 8D01167E
	s_cbranch_execz 2                                          // 00000028296C: BFA50002 <_ZN7halogen12_GLOBAL__N_114k_deq_q4cp_v8uILi8ELb0EEEvPKhPtjjllllNS0_5DeqCbE+0xb78>
	s_waitcnt vmcnt(3)                                         // 000000282970: BF890FF7
	v_mov_b32_e32 v5, s12                                      // 000000282974: 7E0A020C
	s_or_saveexec_b32 s1, s1                                   // 000000282978: BE812201
	v_add_nc_u32_e32 v8, 1, v47                                // 00000028297C: 4A105E81
	v_mov_b32_e32 v42, 0                                       // 000000282980: 7E540280
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000282984: BF870092
	v_cndmask_b32_e32 v8, v47, v8, vcc_lo                      // 000000282988: 0210112F
	v_add_nc_u32_e32 v13, 1, v8                                // 00000028298C: 4A1A1081
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000282990: BF870091
	v_cndmask_b32_e64 v24, v8, v13, s0                         // 000000282994: D5010018 00021B08
	.long 0xd72c0008                                           // 00000028299C: D72C0008
	v_cndmask_b32_e32 v0, v24, v16, vcc_lo                     // 0000002829A0: 02002118
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002829A4: BF870091
	v_sub_nc_u32_e32 v8, v18, v8                               // 0000002829A8: 4C101112
	v_lshlrev_b32_e32 v30, 3, v8                               // 0000002829AC: 303C1083
	s_xor_b32 exec_lo, exec_lo, s1                             // 0000002829B0: 8D7E017E
	s_cbranch_execz 30                                         // 0000002829B4: BFA5001E <_ZN7halogen12_GLOBAL__N_114k_deq_q4cp_v8uILi8ELb0EEEvPKhPtjjllllNS0_5DeqCbE+0xc30>
	v_mad_u64_u32 v[13:14], null, s10, v24, s[8:9]             // 0000002829B8: D6FE7C0D 0022300A
	v_mad_u64_u32 v[25:26], null, s18, v24, s[6:7]             // 0000002829C0: D6FE7C19 001A3012
	s_waitcnt vmcnt(3)                                         // 0000002829C8: BF890FF7
	v_lshrrev_b32_e32 v5, 4, v30                               // 0000002829CC: 320A3C84
	v_lshrrev_b32_e32 v8, 1, v30                               // 0000002829D0: 32103C81
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000002829D4: BF8701B2
	v_and_b32_e32 v5, 0xffffffe, v5                            // 0000002829D8: 360A0AFF 0FFFFFFE
	v_mad_u64_u32 v[32:33], null, s11, v24, v[14:15]           // 0000002829E0: D6FE7C20 043A300B
	v_mad_u64_u32 v[41:42], null, s19, v24, v[26:27]           // 0000002829E8: D6FE7C29 046A3013
	.long 0xd7006a0d                                           // 0000002829F0: D7006A0D
	v_cndmask_b32_e32 v1, v13, v5, vcc_lo                      // 0000002829F4: 02020B0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002829F8: BF8700A1
	v_add_co_ci_u32_e64 v14, null, 0, v32, vcc_lo              // 0000002829FC: D5207C0E 01AA4080
	.long 0xd7006a19                                           // 000000282A04: D7006A19
	v_cndmask_b32_e32 v1, v25, v8, vcc_lo                      // 000000282A08: 02021119
	v_add_co_ci_u32_e64 v26, null, 0, v41, vcc_lo              // 000000282A0C: D5207C1A 01AA5280
	s_clause 0x1                                               // 000000282A14: BF850001
	global_load_d16_b16 v8, v[13:14], off                      // 000000282A18: DC820000 087C000D
	global_load_b32 v5, v[25:26], off                          // 000000282A20: DC520000 057C0019
	s_waitcnt vmcnt(1)                                         // 000000282A28: BF8907F7
	v_cvt_f32_f16_e32 v42, v8                                  // 000000282A2C: 7E541708
	s_or_b32 exec_lo, exec_lo, s1                              // 000000282A30: 8C7E017E
	.long 0xd72c0008                                           // 000000282A34: D72C0008
	v_cndmask_b32_e32 v0, v11, v16, vcc_lo                     // 000000282A38: 0200210B
	.long 0xd44b0001                                           // 000000282A3C: D44B0001
	v_cndmask_b32_e32 v1, s17, v17, vcc_lo                     // 000000282A40: 02022211
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000282A44: BF870092
	v_sub_nc_u32_e32 v8, v17, v8                               // 000000282A48: 4C101111
	v_subrev_nc_u32_e32 v13, s16, v8                           // 000000282A4C: 4E1A1010
	v_cmp_le_u32_e32 vcc_lo, s16, v8                           // 000000282A50: 7C961010
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000282A54: BF870092
	v_cndmask_b32_e32 v8, v8, v13, vcc_lo                      // 000000282A58: 02101B08
	.long 0xd44b0000                                           // 000000282A5C: D44B0000
	v_cndmask_b32_e32 v1, s16, v8, vcc_lo                      // 000000282A60: 02021010
	s_and_saveexec_b32 s22, s1                                 // 000000282A64: BE962001
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000282A68: BF870009
	s_xor_b32 s1, exec_lo, s22                                 // 000000282A6C: 8D01167E
	s_cbranch_execz 2                                          // 000000282A70: BFA50002 <_ZN7halogen12_GLOBAL__N_114k_deq_q4cp_v8uILi8ELb0EEEvPKhPtjjllllNS0_5DeqCbE+0xc7c>
	s_waitcnt vmcnt(2)                                         // 000000282A74: BF890BF7
	v_mov_b32_e32 v6, s12                                      // 000000282A78: 7E0C020C
	s_or_saveexec_b32 s1, s1                                   // 000000282A7C: BE812201
	v_dual_mov_b32 v41, 0 :: v_dual_add_nc_u32 v8, 1, v11      // 000000282A80: CA200080 29081681
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000282A88: BF870091
	v_cndmask_b32_e32 v8, v11, v8, vcc_lo                      // 000000282A8C: 0210110B
	v_add_nc_u32_e32 v11, 1, v8                                // 000000282A90: 4A161081
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000282A94: BF870091
	v_cndmask_b32_e64 v25, v8, v11, s0                         // 000000282A98: D5010019 00021708
	.long 0xd72c0008                                           // 000000282AA0: D72C0008
	v_cndmask_b32_e32 v0, v25, v16, vcc_lo                     // 000000282AA4: 02002119
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000282AA8: BF870091
	v_sub_nc_u32_e32 v8, v17, v8                               // 000000282AAC: 4C101111
	v_lshlrev_b32_e32 v33, 3, v8                               // 000000282AB0: 30421083
	s_xor_b32 exec_lo, exec_lo, s1                             // 000000282AB4: 8D7E017E
	s_cbranch_execz 30                                         // 000000282AB8: BFA5001E <_ZN7halogen12_GLOBAL__N_114k_deq_q4cp_v8uILi8ELb0EEEvPKhPtjjllllNS0_5DeqCbE+0xd34>
	v_mad_u64_u32 v[13:14], null, s10, v25, s[8:9]             // 000000282ABC: D6FE7C0D 0022320A
	v_mad_u64_u32 v[47:48], null, s18, v25, s[6:7]             // 000000282AC4: D6FE7C2F 001A3212
	s_waitcnt vmcnt(2)                                         // 000000282ACC: BF890BF7
	v_lshrrev_b32_e32 v6, 4, v33                               // 000000282AD0: 320C4284
	v_lshrrev_b32_e32 v8, 1, v33                               // 000000282AD4: 32104281
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000282AD8: BF870122
	v_and_b32_e32 v6, 0xffffffe, v6                            // 000000282ADC: 360C0CFF 0FFFFFFE
	v_mad_u64_u32 v[49:50], null, s11, v25, v[14:15]           // 000000282AE4: D6FE7C31 043A320B
	.long 0xd7006a0d                                           // 000000282AEC: D7006A0D
	v_cndmask_b32_e32 v1, v13, v6, vcc_lo                      // 000000282AF0: 02020D0D
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000282AF4: BF8700B2
	v_mad_u64_u32 v[50:51], null, s19, v25, v[48:49]           // 000000282AF8: D6FE7C32 04C23213
	v_add_co_ci_u32_e64 v14, null, 0, v49, vcc_lo              // 000000282B00: D5207C0E 01AA6280
	.long 0xd7006a2f                                           // 000000282B08: D7006A2F
	v_cndmask_b32_e32 v1, v47, v8, vcc_lo                      // 000000282B0C: 0202112F
	v_add_co_ci_u32_e64 v48, null, 0, v50, vcc_lo              // 000000282B10: D5207C30 01AA6480
	s_clause 0x1                                               // 000000282B18: BF850001
	global_load_d16_b16 v8, v[13:14], off                      // 000000282B1C: DC820000 087C000D
	global_load_b32 v6, v[47:48], off                          // 000000282B24: DC520000 067C002F
	s_waitcnt vmcnt(1)                                         // 000000282B2C: BF8907F7
	v_cvt_f32_f16_e32 v41, v8                                  // 000000282B30: 7E521708
	s_or_b32 exec_lo, exec_lo, s1                              // 000000282B34: 8C7E017E
	.long 0xd72c0008                                           // 000000282B38: D72C0008
	v_cndmask_b32_e32 v0, v10, v16, vcc_lo                     // 000000282B3C: 0200210A
	.long 0xd44b0001                                           // 000000282B40: D44B0001
	v_cndmask_b32_e32 v1, s17, v16, vcc_lo                     // 000000282B44: 02022011
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000282B48: BF870092
	v_sub_nc_u32_e32 v8, v16, v8                               // 000000282B4C: 4C101110
	v_subrev_nc_u32_e32 v11, s16, v8                           // 000000282B50: 4E161010
	v_cmp_le_u32_e32 vcc_lo, s16, v8                           // 000000282B54: 7C961010
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000282B58: BF870092
	v_cndmask_b32_e32 v8, v8, v11, vcc_lo                      // 000000282B5C: 02101708
	.long 0xd44b0000                                           // 000000282B60: D44B0000
	v_cndmask_b32_e32 v1, s16, v8, vcc_lo                      // 000000282B64: 02021010
	s_and_saveexec_b32 s22, s1                                 // 000000282B68: BE962001
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000282B6C: BF870009
	s_xor_b32 s1, exec_lo, s22                                 // 000000282B70: 8D01167E
	s_cbranch_execz 2                                          // 000000282B74: BFA50002 <_ZN7halogen12_GLOBAL__N_114k_deq_q4cp_v8uILi8ELb0EEEvPKhPtjjllllNS0_5DeqCbE+0xd80>
	s_waitcnt vmcnt(1)                                         // 000000282B78: BF8907F7
	v_mov_b32_e32 v7, s12                                      // 000000282B7C: 7E0E020C
	s_or_saveexec_b32 s1, s1                                   // 000000282B80: BE812201
	v_dual_mov_b32 v37, 0 :: v_dual_add_nc_u32 v8, 1, v10      // 000000282B84: CA200080 25081481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000282B8C: BF870091
	v_cndmask_b32_e32 v8, v10, v8, vcc_lo                      // 000000282B90: 0210110A
	v_add_nc_u32_e32 v10, 1, v8                                // 000000282B94: 4A141081
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000282B98: BF870091
	v_cndmask_b32_e64 v23, v8, v10, s0                         // 000000282B9C: D5010017 00021508
	.long 0xd72c0008                                           // 000000282BA4: D72C0008
	v_cndmask_b32_e32 v0, v23, v16, vcc_lo                     // 000000282BA8: 02002117
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000282BAC: BF870091
	v_sub_nc_u32_e32 v8, v16, v8                               // 000000282BB0: 4C101110
	v_lshlrev_b32_e32 v26, 3, v8                               // 000000282BB4: 30341083
	s_xor_b32 exec_lo, exec_lo, s1                             // 000000282BB8: 8D7E017E
	s_cbranch_execz 32                                         // 000000282BBC: BFA50020 <_ZN7halogen12_GLOBAL__N_114k_deq_q4cp_v8uILi8ELb0EEEvPKhPtjjllllNS0_5DeqCbE+0xe40>
	s_waitcnt vmcnt(1)                                         // 000000282BC0: BF8907F7
	v_mad_u64_u32 v[7:8], null, s10, v23, s[8:9]               // 000000282BC4: D6FE7C07 00222E0A
	v_mad_u64_u32 v[10:11], null, s18, v23, s[6:7]             // 000000282BCC: D6FE7C0A 001A2E12
	v_lshrrev_b32_e32 v21, 4, v26                              // 000000282BD4: 322A3484
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000282BD8: BF870113
	v_mad_u64_u32 v[13:14], null, s11, v23, v[8:9]             // 000000282BDC: D6FE7C0D 04222E0B
	v_and_b32_e32 v8, 0xffffffe, v21                           // 000000282BE4: 36102AFF 0FFFFFFE
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000282BEC: BF8701A4
	v_mad_u64_u32 v[47:48], null, s19, v23, v[11:12]           // 000000282BF0: D6FE7C2F 042E2E13
	v_lshrrev_b32_e32 v11, 1, v26                              // 000000282BF8: 32163481
	.long 0xd7006a07                                           // 000000282BFC: D7006A07
	v_cndmask_b32_e32 v1, v7, v8, vcc_lo                       // 000000282C00: 02021107
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000282C04: BF870191
	v_add_co_ci_u32_e64 v8, null, 0, v13, vcc_lo               // 000000282C08: D5207C08 01AA1A80
	.long 0xd7006a0a                                           // 000000282C10: D7006A0A
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                     // 000000282C14: 0202170A
	s_delay_alu instid0(VALU_DEP_1)                            // 000000282C18: BF870001
	v_add_co_ci_u32_e64 v11, null, 0, v47, vcc_lo              // 000000282C1C: D5207C0B 01AA5E80
	s_clause 0x1                                               // 000000282C24: BF850001
	global_load_d16_b16 v8, v[7:8], off                        // 000000282C28: DC820000 087C0007
	global_load_b32 v7, v[10:11], off                          // 000000282C30: DC520000 077C000A
	s_waitcnt vmcnt(1)                                         // 000000282C38: BF8907F7
	v_cvt_f32_f16_e32 v37, v8                                  // 000000282C3C: 7E4A1708
	s_or_b32 exec_lo, exec_lo, s1                              // 000000282C40: 8C7E017E
	.long 0xd72c0008                                           // 000000282C44: D72C0008
	v_cndmask_b32_e32 v0, v9, v16, vcc_lo                      // 000000282C48: 02002109
	.long 0xd44b0001                                           // 000000282C4C: D44B0001
	v_cndmask_b32_e32 v1, s17, v15, vcc_lo                     // 000000282C50: 02021E11
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000282C54: BF870092
	v_sub_nc_u32_e32 v8, v15, v8                               // 000000282C58: 4C10110F
	v_subrev_nc_u32_e32 v10, s16, v8                           // 000000282C5C: 4E141010
	v_cmp_le_u32_e32 vcc_lo, s16, v8                           // 000000282C60: 7C961010
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000282C64: BF870092
	v_cndmask_b32_e32 v8, v8, v10, vcc_lo                      // 000000282C68: 02101508
	.long 0xd44b0000                                           // 000000282C6C: D44B0000
	v_cndmask_b32_e32 v1, s16, v8, vcc_lo                      // 000000282C70: 02021010
	s_and_saveexec_b32 s22, s1                                 // 000000282C74: BE962001
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000282C78: BF870499
	s_xor_b32 s1, exec_lo, s22                                 // 000000282C7C: 8D01167E
	s_or_saveexec_b32 s1, s1                                   // 000000282C80: BE812201
	s_waitcnt vmcnt(0)                                         // 000000282C84: BF8903F7
	v_dual_mov_b32 v35, 0 :: v_dual_add_nc_u32 v8, 1, v9       // 000000282C88: CA200080 23081281
	v_mov_b32_e32 v32, 0                                       // 000000282C90: 7E400280
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000282C94: BF870092
	v_cndmask_b32_e32 v8, v9, v8, vcc_lo                       // 000000282C98: 02101109
	v_add_nc_u32_e32 v9, 1, v8                                 // 000000282C9C: 4A121081
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000282CA0: BF870091
	v_cndmask_b32_e64 v21, v8, v9, s0                          // 000000282CA4: D5010015 00021308
	.long 0xd72c0008                                           // 000000282CAC: D72C0008
	v_cndmask_b32_e32 v0, v21, v16, vcc_lo                     // 000000282CB0: 02002115
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000282CB4: BF870091
	v_sub_nc_u32_e32 v8, v15, v8                               // 000000282CB8: 4C10110F
	v_lshlrev_b32_e32 v13, 3, v8                               // 000000282CBC: 301A1083
	s_xor_b32 exec_lo, exec_lo, s1                             // 000000282CC0: 8D7E017E
	s_cbranch_execz 31                                         // 000000282CC4: BFA5001F <_ZN7halogen12_GLOBAL__N_114k_deq_q4cp_v8uILi8ELb0EEEvPKhPtjjllllNS0_5DeqCbE+0xf44>
	v_mad_u64_u32 v[8:9], null, s10, v21, s[8:9]               // 000000282CC8: D6FE7C08 00222A0A
	v_mad_u64_u32 v[10:11], null, s18, v21, s[6:7]             // 000000282CD0: D6FE7C0A 001A2A12
	v_lshrrev_b32_e32 v14, 4, v13                              // 000000282CD8: 321C1A84
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000282CDC: BF870112
	v_mad_u64_u32 v[47:48], null, s11, v21, v[9:10]            // 000000282CE0: D6FE7C2F 04262A0B
	v_and_b32_e32 v9, 0xffffffe, v14                           // 000000282CE8: 36121CFF 0FFFFFFE
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000282CF0: BF8701A4
	v_mad_u64_u32 v[48:49], null, s19, v21, v[11:12]           // 000000282CF4: D6FE7C30 042E2A13
	v_lshrrev_b32_e32 v11, 1, v13                              // 000000282CFC: 32161A81
	.long 0xd7006a08                                           // 000000282D00: D7006A08
	v_cndmask_b32_e32 v1, v8, v9, vcc_lo                       // 000000282D04: 02021308
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000282D08: BF870191
	v_add_co_ci_u32_e64 v9, null, 0, v47, vcc_lo               // 000000282D0C: D5207C09 01AA5E80
	.long 0xd7006a0a                                           // 000000282D14: D7006A0A
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                     // 000000282D18: 0202170A
	s_delay_alu instid0(VALU_DEP_1)                            // 000000282D1C: BF870001
	v_add_co_ci_u32_e64 v11, null, 0, v48, vcc_lo              // 000000282D20: D5207C0B 01AA6080
	s_clause 0x1                                               // 000000282D28: BF850001
	global_load_d16_b16 v8, v[8:9], off                        // 000000282D2C: DC820000 087C0008
	global_load_b32 v35, v[10:11], off                         // 000000282D34: DC520000 237C000A
	s_waitcnt vmcnt(1)                                         // 000000282D3C: BF8907F7
	v_cvt_f32_f16_e32 v32, v8                                  // 000000282D40: 7E401708
	s_or_b32 exec_lo, exec_lo, s1                              // 000000282D44: 8C7E017E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000282D48: BF870009
	s_and_not1_b32 vcc_lo, exec_lo, s20                        // 000000282D4C: 916A147E
	s_cbranch_vccz 65021                                       // 000000282D50: BFA3FDFD <_ZN7halogen12_GLOBAL__N_114k_deq_q4cp_v8uILi8ELb0EEEvPKhPtjjllllNS0_5DeqCbE+0x748>
	s_and_not1_b32 vcc_lo, exec_lo, s21                        // 000000282D54: 916A157E
	s_cbranch_vccnz 65025                                      // 000000282D58: BFA4FE01 <_ZN7halogen12_GLOBAL__N_114k_deq_q4cp_v8uILi8ELb0EEEvPKhPtjjllllNS0_5DeqCbE+0x760>
	s_waitcnt vmcnt(7)                                         // 000000282D5C: BF891FF7
	v_lshrrev_b32_e32 v11, 10, v1                              // 000000282D60: 3216028A
	v_lshrrev_b32_e32 v14, 14, v1                              // 000000282D64: 321C028E
	v_lshrrev_b32_e32 v47, 18, v1                              // 000000282D68: 325E0292
	v_lshrrev_b32_e32 v9, 2, v1                                // 000000282D6C: 32120282
	v_lshrrev_b32_e32 v10, 6, v1                               // 000000282D70: 32140286
	v_and_b32_e32 v11, 60, v11                                 // 000000282D74: 361616BC
	v_and_b32_e32 v14, 60, v14                                 // 000000282D78: 361C1CBC
	v_and_b32_e32 v47, 60, v47                                 // 000000282D7C: 365E5EBC
	v_and_b32_e32 v9, 60, v9                                   // 000000282D80: 361212BC
	s_waitcnt vmcnt(6)                                         // 000000282D84: BF891BF7
	v_lshrrev_b32_e32 v54, 2, v2                               // 000000282D88: 326C0482
	ds_load_b32 v11, v11                                       // 000000282D8C: D8D80000 0B00000B
	ds_load_b32 v50, v14                                       // 000000282D94: D8D80000 3200000E
	ds_load_b32 v47, v47                                       // 000000282D9C: D8D80000 2F00002F
	v_and_b32_e32 v10, 60, v10                                 // 000000282DA4: 361414BC
	v_and_b32_e32 v8, 15, v1                                   // 000000282DA8: 3610028F
	.long 0x7f1c3880                                           // 000000282DAC: 7F1C3880
	v_lshrrev_b32_e32 v55, 6, v2                               // 000000282DB0: 326E0486
	s_waitcnt vmcnt(5)                                         // 000000282DB4: BF8917F7
	v_lshrrev_b32_e32 v61, 22, v3                              // 000000282DB8: 327A0696
	v_lshrrev_b32_e32 v62, 26, v3                              // 000000282DBC: 327C069A
	s_waitcnt vmcnt(3)                                         // 000000282DC0: BF890FF7
	v_lshrrev_b32_e32 v64, 26, v5                              // 000000282DC4: 32800A9A
	s_waitcnt vmcnt(2)                                         // 000000282DC8: BF890BF7
	v_lshrrev_b32_e32 v65, 22, v6                              // 000000282DCC: 32820C96
	v_lshrrev_b32_e32 v66, 26, v6                              // 000000282DD0: 32840C9A
	v_and_b32_e32 v61, 60, v61                                 // 000000282DD4: 367A7ABC
	v_and_b32_e32 v62, 60, v62                                 // 000000282DD8: 367C7CBC
	v_and_b32_e32 v64, 60, v64                                 // 000000282DDC: 368080BC
	v_and_b32_e32 v65, 60, v65                                 // 000000282DE0: 368282BC
	v_and_b32_e32 v66, 60, v66                                 // 000000282DE4: 368484BC
	s_waitcnt vmcnt(1)                                         // 000000282DE8: BF8907F7
	v_lshrrev_b32_e32 v69, 14, v7                              // 000000282DEC: 328A0E8E
	v_lshrrev_b32_e32 v70, 18, v7                              // 000000282DF0: 328C0E92
	v_lshrrev_b32_e32 v71, 22, v7                              // 000000282DF4: 328E0E96
	s_waitcnt lgkmcnt(2)                                       // 000000282DF8: BF89FC27
	v_mul_f32_e32 v11, v46, v11                                // 000000282DFC: 1016172E
	s_waitcnt lgkmcnt(1)                                       // 000000282E00: BF89FC17
	v_mul_f32_e32 v50, v46, v50                                // 000000282E04: 1064652E
	s_waitcnt lgkmcnt(0)                                       // 000000282E08: BF89FC07
	v_mul_f32_e32 v57, v46, v47                                // 000000282E0C: 10725F2E
	ds_load_b32 v49, v9                                        // 000000282E10: D8D80000 31000009
	ds_load_b32 v10, v10                                       // 000000282E18: D8D80000 0A00000A
	v_lshlrev_b32_e32 v8, 2, v8                                // 000000282E20: 30101082
	v_lshrrev_b32_e32 v9, 26, v1                               // 000000282E24: 3212029A
	v_bfe_u32 v58, v11, 16, 1                                  // 000000282E28: D610003A 0205210B
	v_lshrrev_b32_e32 v72, 26, v7                              // 000000282E30: 32900E9A
	v_and_b32_e32 v70, 60, v70                                 // 000000282E34: 368C8CBC
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000282E38: BF870214
	v_and_b32_e32 v52, 60, v9                                  // 000000282E3C: 366812BC
	v_add3_u32 v11, v11, v58, 0x7fff                           // 000000282E40: D655000B 03FE750B 00007FFF
	s_delay_alu instid0(VALU_DEP_4)                            // 000000282E4C: BF870004
	v_and_b32_e32 v72, 60, v72                                 // 000000282E50: 369090BC
	s_mov_b32 s0, -1                                           // 000000282E54: BE8000C1
	v_and_b32_e32 v69, 60, v69                                 // 000000282E58: 368A8ABC
	ds_load_b32 v52, v52                                       // 000000282E5C: D8D80000 34000034
	v_and_b32_e32 v53, 15, v2                                  // 000000282E64: 366A048F
	s_waitcnt lgkmcnt(2)                                       // 000000282E68: BF89FC27
	v_mul_f32_e32 v49, v46, v49                                // 000000282E6C: 1062632E
	ds_load_b32 v48, v8                                        // 000000282E70: D8D80000 30000008
	v_lshrrev_b32_e32 v8, 22, v1                               // 000000282E78: 32100296
	s_waitcnt lgkmcnt(2)                                       // 000000282E7C: BF89FC27
	v_mul_f32_e32 v10, v46, v10                                // 000000282E80: 1014152E
	v_bfe_u32 v47, v49, 16, 1                                  // 000000282E84: D610002F 02052131
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000282E8C: BF870113
	v_and_b32_e32 v8, 60, v8                                   // 000000282E90: 361010BC
	v_add3_u32 v47, v49, v47, 0x7fff                           // 000000282E94: D655002F 03FE5F31 00007FFF
	v_bfe_u32 v49, v57, 16, 1                                  // 000000282EA0: D6100031 02052139
	ds_load_b32 v51, v8                                        // 000000282EA8: D8D80000 33000008
	s_waitcnt lgkmcnt(2)                                       // 000000282EB0: BF89FC27
	v_mul_f32_e32 v52, v46, v52                                // 000000282EB4: 1068692E
	v_add3_u32 v49, v57, v49, 0x7fff                           // 000000282EB8: D6550031 03FE6339 00007FFF
	s_waitcnt lgkmcnt(1)                                       // 000000282EC4: BF89FC17
	v_mul_f32_e32 v48, v46, v48                                // 000000282EC8: 1060612E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000282ECC: BF870091
	v_bfe_u32 v56, v48, 16, 1                                  // 000000282ED0: D6100038 02052130
	v_add3_u32 v48, v48, v56, 0x7fff                           // 000000282ED8: D6550030 03FE7130 00007FFF
	v_bfe_u32 v56, v10, 16, 1                                  // 000000282EE4: D6100038 0205210A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000282EEC: BF870112
	.long 0x7e1c39b0                                           // 000000282EF0: 7E1C39B0
	v_add3_u32 v10, v10, v56, 0x7fff                           // 000000282EF4: D655000A 03FE710A 00007FFF
	v_bfe_u32 v48, v50, 16, 1                                  // 000000282F00: D6100030 02052132
	v_lshrrev_b32_e32 v56, 26, v2                              // 000000282F08: 3270049A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000282F0C: BF870214
	v_and_or_b32 v47, 0xffff0000, v47, v14                     // 000000282F10: D657002F 043A5EFF FFFF0000
	.long 0x7e1c398a                                           // 000000282F1C: 7E1C398A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000282F20: BF870214
	v_add3_u32 v10, v50, v48, 0x7fff                           // 000000282F24: D655000A 03FE6132 00007FFF
	v_and_b32_e32 v56, 60, v56                                 // 000000282F30: 367070BC
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000282F34: BF870223
	v_and_or_b32 v48, 0xffff0000, v11, v14                     // 000000282F38: D6570030 043A16FF FFFF0000
	v_lshlrev_b32_e32 v11, 2, v53                              // 000000282F44: 30166A82
	.long 0x7e1c398a                                           // 000000282F48: 7E1C398A
	v_and_b32_e32 v53, 60, v55                                 // 000000282F4C: 366A6EBC
	v_lshrrev_b32_e32 v55, 22, v2                              // 000000282F50: 326E0496
	ds_load_b32 v11, v11                                       // 000000282F54: D8D80000 0B00000B
	s_waitcnt lgkmcnt(1)                                       // 000000282F5C: BF89FC17
	v_mul_f32_e32 v51, v46, v51                                // 000000282F60: 1066672E
	v_mad_u64_u32 v[8:9], null, s4, v28, 0                     // 000000282F64: D6FE7C08 02023804
	v_and_or_b32 v49, 0xffff0000, v49, v14                     // 000000282F6C: D6570031 043A62FF FFFF0000
	v_and_b32_e32 v55, 60, v55                                 // 000000282F78: 366E6EBC
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000282F7C: BF870094
	v_bfe_u32 v50, v51, 16, 1                                  // 000000282F80: D6100032 02052133
	v_add3_u32 v10, v51, v50, 0x7fff                           // 000000282F88: D655000A 03FE6533 00007FFF
	v_and_b32_e32 v50, 60, v54                                 // 000000282F94: 36646CBC
	v_bfe_u32 v51, v52, 16, 1                                  // 000000282F98: D6100033 02052134
	v_lshrrev_b32_e32 v54, 18, v2                              // 000000282FA0: 326C0492
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000282FA4: BF870224
	.long 0x7e1c398a                                           // 000000282FA8: 7E1C398A
	v_mad_u64_u32 v[9:10], null, s5, v28, v[9:10]              // 000000282FAC: D6FE7C09 04263805
	v_add3_u32 v51, v52, v51, 0x7fff                           // 000000282FB4: D6550033 03FE6734 00007FFF
	ds_load_b32 v10, v50                                       // 000000282FC0: D8D80000 0A000032
	ds_load_b32 v52, v53                                       // 000000282FC8: D8D80000 34000035
	v_lshrrev_b32_e32 v50, 10, v2                              // 000000282FD0: 3264048A
	v_lshrrev_b32_e32 v53, 14, v2                              // 000000282FD4: 326A048E
	v_and_b32_e32 v54, 60, v54                                 // 000000282FD8: 366C6CBC
	s_waitcnt lgkmcnt(2)                                       // 000000282FDC: BF89FC27
	v_mul_f32_e32 v58, v45, v11                                // 000000282FE0: 1074172D
	v_dual_mov_b32 v11, v29 :: v_dual_and_b32 v50, 60, v50     // 000000282FE4: CA24011D 0B3264BC
	v_and_b32_e32 v53, 60, v53                                 // 000000282FEC: 366A6ABC
	ds_load_b32 v57, v50                                       // 000000282FF0: D8D80000 39000032
	ds_load_b32 v53, v53                                       // 000000282FF8: D8D80000 35000035
	ds_load_b32 v54, v54                                       // 000000283000: D8D80000 36000036
	ds_load_b32 v55, v55                                       // 000000283008: D8D80000 37000037
	ds_load_b32 v56, v56                                       // 000000283010: D8D80000 38000038
	.long 0xd73c0008                                           // 000000283018: D73C0008
	v_cndmask_b32_e32 v1, 1, v8, vcc_lo                        // 00000028301C: 02021081
	v_and_or_b32 v50, 0xffff0000, v51, v14                     // 000000283020: D6570032 043A66FF FFFF0000
	v_bfe_u32 v51, v58, 16, 1                                  // 00000028302C: D6100033 0205213A
	s_delay_alu instid0(VALU_DEP_3)                            // 000000283034: BF870003
	.long 0xd7006a3b                                           // 000000283038: D7006A3B
	v_cndmask_b32_e32 v1, s14, v8, vcc_lo                      // 00000028303C: 0202100E
	s_waitcnt lgkmcnt(6)                                       // 000000283040: BF89FC67
	v_mul_f32_e32 v10, v45, v10                                // 000000283044: 1014152D
	s_waitcnt lgkmcnt(5)                                       // 000000283048: BF89FC57
	v_mul_f32_e32 v52, v45, v52                                // 00000028304C: 1068692D
	v_add_co_ci_u32_e64 v60, null, s15, v9, vcc_lo             // 000000283050: D5207C3C 01AA120F
	v_add3_u32 v8, v58, v51, 0x7fff                            // 000000283058: D6550008 03FE673A 00007FFF
	v_bfe_u32 v9, v10, 16, 1                                   // 000000283064: D6100009 0205210A
	s_delay_alu instid0(VALU_DEP_4)                            // 00000028306C: BF870004
	v_bfe_u32 v51, v52, 16, 1                                  // 000000283070: D6100033 02052134
	s_waitcnt lgkmcnt(4)                                       // 000000283078: BF89FC47
	v_mul_f32_e32 v57, v45, v57                                // 00000028307C: 1072732D
	s_waitcnt lgkmcnt(3)                                       // 000000283080: BF89FC37
	v_mul_f32_e32 v53, v45, v53                                // 000000283084: 106A6B2D
	.long 0x7e1c3988                                           // 000000283088: 7E1C3988
	v_add3_u32 v8, v10, v9, 0x7fff                             // 00000028308C: D6550008 03FE130A 00007FFF
	v_add3_u32 v9, v52, v51, 0x7fff                            // 000000283098: D6550009 03FE6734 00007FFF
	v_bfe_u32 v10, v57, 16, 1                                  // 0000002830A4: D610000A 02052139
	s_waitcnt lgkmcnt(2)                                       // 0000002830AC: BF89FC27
	v_mul_f32_e32 v54, v45, v54                                // 0000002830B0: 106C6D2D
	v_bfe_u32 v52, v53, 16, 1                                  // 0000002830B4: D6100034 02052135
	v_and_or_b32 v51, 0xffff0000, v8, v14                      // 0000002830BC: D6570033 043A10FF FFFF0000
	.long 0x7e1c3989                                           // 0000002830C8: 7E1C3989
	v_add3_u32 v10, v57, v10, 0x7fff                           // 0000002830CC: D655000A 03FE1539 00007FFF
	v_bfe_u32 v57, v54, 16, 1                                  // 0000002830D8: D6100039 02052136
	v_add3_u32 v53, v53, v52, 0x7fff                           // 0000002830E0: D6550035 03FE6935 00007FFF
	.long 0xd73c0008                                           // 0000002830EC: D73C0008
	v_cndmask_b32_e32 v1, 1, v11, vcc_lo                       // 0000002830F0: 02021681
	s_waitcnt lgkmcnt(0)                                       // 0000002830F4: BF89FC07
	v_mul_f32_e32 v56, v45, v56                                // 0000002830F8: 1070712D
	v_and_or_b32 v52, 0xffff0000, v10, v14                     // 0000002830FC: D6570034 043A14FF FFFF0000
	v_add3_u32 v10, v54, v57, 0x7fff                           // 000000283108: D655000A 03FE7336 00007FFF
	v_lshrrev_b32_e32 v57, 2, v3                               // 000000283114: 32720682
	v_mul_f32_e32 v58, v45, v55                                // 000000283118: 10746F2D
	.long 0x7e1c39b5                                           // 00000028311C: 7E1C39B5
	.long 0xd7006a36                                           // 000000283120: D7006A36
	v_cndmask_b32_e32 v1, v59, v8, vcc_lo                      // 000000283124: 0202113B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000283128: BF870214
	v_and_b32_e32 v57, 60, v57                                 // 00000028312C: 367272BC
	v_bfe_u32 v11, v58, 16, 1                                  // 000000283130: D610000B 0205213A
	v_add_co_ci_u32_e64 v55, null, v60, v9, vcc_lo             // 000000283138: D5207C37 01AA133C
	v_and_or_b32 v53, 0xffff0000, v10, v14                     // 000000283140: D6570035 043A14FF FFFF0000
	v_mad_u64_u32 v[8:9], null, s4, v39, 0                     // 00000028314C: D6FE7C08 02024E04
	s_delay_alu instid0(VALU_DEP_4)                            // 000000283154: BF870004
	v_add3_u32 v10, v58, v11, 0x7fff                           // 000000283158: D655000A 03FE173A 00007FFF
	v_lshrrev_b32_e32 v58, 6, v3                               // 000000283164: 32740686
	v_and_b32_e32 v11, 15, v3                                  // 000000283168: 3616068F
	v_bfe_u32 v59, v56, 16, 1                                  // 00000028316C: D610003B 02052138
	v_lshrrev_b32_e32 v60, 18, v3                              // 000000283174: 32780692
	.long 0x7e1c398a                                           // 000000283178: 7E1C398A
	v_and_b32_e32 v58, 60, v58                                 // 00000028317C: 367474BC
	v_mad_u64_u32 v[9:10], null, s5, v39, v[9:10]              // 000000283180: D6FE7C09 04264E05
	ds_load_b32 v10, v57                                       // 000000283188: D8D80000 0A000039
	ds_load_b32 v57, v58                                       // 000000283190: D8D80000 3900003A
	v_lshlrev_b32_e32 v11, 2, v11                              // 000000283198: 30161682
	v_lshrrev_b32_e32 v58, 10, v3                              // 00000028319C: 3274068A
	v_add3_u32 v56, v56, v59, 0x7fff                           // 0000002831A0: D6550038 03FE7738 00007FFF
	v_lshrrev_b32_e32 v59, 14, v3                              // 0000002831AC: 3276068E
	v_and_b32_e32 v60, 60, v60                                 // 0000002831B0: 367878BC
	global_store_b128 v[54:55], v[47:50], off                  // 0000002831B4: DC760000 007C2F36
	v_and_b32_e32 v58, 60, v58                                 // 0000002831BC: 367474BC
	.long 0xd73c0008                                           // 0000002831C0: D73C0008
	v_cndmask_b32_e32 v1, 1, v8, vcc_lo                        // 0000002831C4: 02021081
	v_and_b32_e32 v59, 60, v59                                 // 0000002831C8: 367676BC
	v_and_or_b32 v54, 0xffff0000, v56, v14                     // 0000002831CC: D6570036 043A70FF FFFF0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002831D8: BF870093
	.long 0xd7006a31                                           // 0000002831DC: D7006A31
	v_cndmask_b32_e32 v1, s14, v8, vcc_lo                      // 0000002831E0: 0202100E
	v_add_co_ci_u32_e64 v50, null, s15, v9, vcc_lo             // 0000002831E4: D5207C32 01AA120F
	s_waitcnt lgkmcnt(1)                                       // 0000002831EC: BF89FC17
	v_mul_f32_e32 v10, v44, v10                                // 0000002831F0: 1014152C
	ds_load_b32 v11, v11                                       // 0000002831F4: D8D80000 0B00000B
	s_waitcnt lgkmcnt(1)                                       // 0000002831FC: BF89FC17
	v_mul_f32_e32 v48, v44, v57                                // 000000283200: 1060732C
	ds_load_b32 v58, v58                                       // 000000283204: D8D80000 3A00003A
	ds_load_b32 v59, v59                                       // 00000028320C: D8D80000 3B00003B
	ds_load_b32 v60, v60                                       // 000000283214: D8D80000 3C00003C
	ds_load_b32 v61, v61                                       // 00000028321C: D8D80000 3D00003D
	ds_load_b32 v62, v62                                       // 000000283224: D8D80000 3E00003E
	v_bfe_u32 v9, v10, 16, 1                                   // 00000028322C: D6100009 0205210A
	s_waitcnt lgkmcnt(4)                                       // 000000283234: BF89FC47
	v_mul_f32_e32 v55, v44, v58                                // 000000283238: 106E752C
	s_waitcnt lgkmcnt(3)                                       // 00000028323C: BF89FC37
	v_mul_f32_e32 v56, v44, v59                                // 000000283240: 1070772C
	v_mul_f32_e32 v63, v44, v11                                // 000000283244: 107E172C
	s_waitcnt lgkmcnt(2)                                       // 000000283248: BF89FC27
	v_mul_f32_e32 v57, v44, v60                                // 00000028324C: 1072792C
	v_mov_b32_e32 v11, v40                                     // 000000283250: 7E160328
	s_waitcnt lgkmcnt(1)                                       // 000000283254: BF89FC17
	v_mul_f32_e32 v58, v44, v61                                // 000000283258: 10747B2C
	v_lshrrev_b32_e32 v60, 18, v4                              // 00000028325C: 32780892
	v_bfe_u32 v47, v63, 16, 1                                  // 000000283260: D610002F 0205213F
	v_lshrrev_b32_e32 v61, 22, v4                              // 000000283268: 327A0896
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000028326C: BF870193
	v_and_b32_e32 v60, 60, v60                                 // 000000283270: 367878BC
	v_add3_u32 v8, v63, v47, 0x7fff                            // 000000283274: D6550008 03FE5F3F 00007FFF
	v_bfe_u32 v47, v48, 16, 1                                  // 000000283280: D610002F 02052130
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000283288: BF870194
	v_and_b32_e32 v61, 60, v61                                 // 00000028328C: 367A7ABC
	.long 0x7e1c3988                                           // 000000283290: 7E1C3988
	v_add3_u32 v8, v10, v9, 0x7fff                             // 000000283294: D6550008 03FE130A 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000002832A0: BF870234
	v_add3_u32 v9, v48, v47, 0x7fff                            // 0000002832A4: D6550009 03FE5F30 00007FFF
	v_bfe_u32 v10, v55, 16, 1                                  // 0000002832B0: D610000A 02052137
	v_bfe_u32 v48, v56, 16, 1                                  // 0000002832B8: D6100030 02052138
	v_and_or_b32 v47, 0xffff0000, v8, v14                      // 0000002832C0: D657002F 043A10FF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002832CC: BF870214
	.long 0x7e1c3989                                           // 0000002832D0: 7E1C3989
	v_add3_u32 v10, v55, v10, 0x7fff                           // 0000002832D4: D655000A 03FE1537 00007FFF
	s_delay_alu instid0(VALU_DEP_4)                            // 0000002832E0: BF870004
	v_add3_u32 v55, v56, v48, 0x7fff                           // 0000002832E4: D6550037 03FE6138 00007FFF
	v_bfe_u32 v56, v57, 16, 1                                  // 0000002832F0: D6100038 02052139
	.long 0xd73c0008                                           // 0000002832F8: D73C0008
	v_cndmask_b32_e32 v1, 1, v11, vcc_lo                       // 0000002832FC: 02021681
	v_bfe_u32 v11, v58, 16, 1                                  // 000000283300: D610000B 0205213A
	v_and_or_b32 v48, 0xffff0000, v10, v14                     // 000000283308: D6570030 043A14FF FFFF0000
	.long 0x7e1c39b7                                           // 000000283314: 7E1C39B7
	v_add3_u32 v10, v57, v56, 0x7fff                           // 000000283318: D655000A 03FE7139 00007FFF
	v_lshrrev_b32_e32 v57, 2, v4                               // 000000283324: 32720882
	.long 0xd7006a37                                           // 000000283328: D7006A37
	v_cndmask_b32_e32 v1, v49, v8, vcc_lo                      // 00000028332C: 02021131
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000283330: BF870211
	v_add_co_ci_u32_e64 v56, null, v50, v9, vcc_lo             // 000000283334: D5207C38 01AA1332
	v_and_or_b32 v49, 0xffff0000, v10, v14                     // 00000028333C: D6570031 043A14FF FFFF0000
	v_add3_u32 v10, v58, v11, 0x7fff                           // 000000283348: D655000A 03FE173A 00007FFF
	v_mad_u64_u32 v[8:9], null, s4, v31, 0                     // 000000283354: D6FE7C08 02023E04
	v_lshrrev_b32_e32 v58, 6, v4                               // 00000028335C: 32740886
	v_and_b32_e32 v57, 60, v57                                 // 000000283360: 367272BC
	v_and_b32_e32 v11, 15, v4                                  // 000000283364: 3616088F
	.long 0x7e1c398a                                           // 000000283368: 7E1C398A
	s_waitcnt lgkmcnt(0)                                       // 00000028336C: BF89FC07
	v_mul_f32_e32 v50, v44, v62                                // 000000283370: 10647D2C
	v_and_b32_e32 v58, 60, v58                                 // 000000283374: 367474BC
	v_lshrrev_b32_e32 v62, 26, v4                              // 000000283378: 327C089A
	v_mad_u64_u32 v[9:10], null, s5, v31, v[9:10]              // 00000028337C: D6FE7C09 04263E05
	ds_load_b32 v10, v57                                       // 000000283384: D8D80000 0A000039
	ds_load_b32 v57, v58                                       // 00000028338C: D8D80000 3900003A
	v_lshlrev_b32_e32 v11, 2, v11                              // 000000283394: 30161682
	v_bfe_u32 v59, v50, 16, 1                                  // 000000283398: D610003B 02052132
	v_lshrrev_b32_e32 v58, 10, v4                              // 0000002833A0: 3274088A
	v_and_b32_e32 v62, 60, v62                                 // 0000002833A4: 367C7CBC
	global_store_b128 v[55:56], v[51:54], off                  // 0000002833A8: DC760000 007C3337
	ds_load_b32 v11, v11                                       // 0000002833B0: D8D80000 0B00000B
	v_add3_u32 v50, v50, v59, 0x7fff                           // 0000002833B8: D6550032 03FE7732 00007FFF
	v_lshrrev_b32_e32 v59, 14, v4                              // 0000002833C4: 3276088E
	v_and_b32_e32 v58, 60, v58                                 // 0000002833C8: 367474BC
	.long 0xd73c0008                                           // 0000002833CC: D73C0008
	v_cndmask_b32_e32 v1, 1, v8, vcc_lo                        // 0000002833D0: 02021081
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002833D4: BF870214
	v_and_or_b32 v50, 0xffff0000, v50, v14                     // 0000002833D8: D6570032 043A64FF FFFF0000
	v_and_b32_e32 v59, 60, v59                                 // 0000002833E4: 367676BC
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002833E8: BF870093
	.long 0xd7006a35                                           // 0000002833EC: D7006A35
	v_cndmask_b32_e32 v1, s14, v8, vcc_lo                      // 0000002833F0: 0202100E
	v_add_co_ci_u32_e64 v54, null, s15, v9, vcc_lo             // 0000002833F4: D5207C36 01AA120F
	s_waitcnt lgkmcnt(1)                                       // 0000002833FC: BF89FC17
	v_mul_f32_e32 v52, v43, v57                                // 000000283400: 1068732B
	ds_load_b32 v58, v58                                       // 000000283404: D8D80000 3A00003A
	ds_load_b32 v59, v59                                       // 00000028340C: D8D80000 3B00003B
	ds_load_b32 v60, v60                                       // 000000283414: D8D80000 3C00003C
	ds_load_b32 v61, v61                                       // 00000028341C: D8D80000 3D00003D
	ds_load_b32 v62, v62                                       // 000000283424: D8D80000 3E00003E
	v_mul_f32_e32 v10, v43, v10                                // 00000028342C: 1014152B
	v_bfe_u32 v55, v52, 16, 1                                  // 000000283430: D6100037 02052134
	s_waitcnt lgkmcnt(5)                                       // 000000283438: BF89FC57
	v_mul_f32_e32 v63, v43, v11                                // 00000028343C: 107E172B
	v_mov_b32_e32 v11, v36                                     // 000000283440: 7E160324
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000283444: BF870112
	v_bfe_u32 v51, v63, 16, 1                                  // 000000283448: D6100033 0205213F
	.long 0xd73c0008                                           // 000000283450: D73C0008
	v_cndmask_b32_e32 v1, 1, v11, vcc_lo                       // 000000283454: 02021681
	s_delay_alu instid0(VALU_DEP_2)                            // 000000283458: BF870002
	v_add3_u32 v11, v63, v51, 0x7fff                           // 00000028345C: D655000B 03FE673F 00007FFF
	v_bfe_u32 v51, v10, 16, 1                                  // 000000283468: D6100033 0205210A
	s_waitcnt lgkmcnt(4)                                       // 000000283470: BF89FC47
	v_mul_f32_e32 v56, v43, v58                                // 000000283474: 1070752B
	s_waitcnt lgkmcnt(3)                                       // 000000283478: BF89FC37
	v_mul_f32_e32 v57, v43, v59                                // 00000028347C: 1072772B
	s_waitcnt lgkmcnt(2)                                       // 000000283480: BF89FC27
	v_mul_f32_e32 v58, v43, v60                                // 000000283484: 1074792B
	.long 0x7e1c398b                                           // 000000283488: 7E1C398B
	v_add3_u32 v10, v10, v51, 0x7fff                           // 00000028348C: D655000A 03FE670A 00007FFF
	v_add3_u32 v11, v52, v55, 0x7fff                           // 000000283498: D655000B 03FE6F34 00007FFF
	v_bfe_u32 v52, v56, 16, 1                                  // 0000002834A4: D6100034 02052138
	v_bfe_u32 v55, v57, 16, 1                                  // 0000002834AC: D6100037 02052139
	.long 0xd7006a35                                           // 0000002834B4: D7006A35
	v_cndmask_b32_e32 v1, v53, v8, vcc_lo                      // 0000002834B8: 02021135
	v_and_or_b32 v51, 0xffff0000, v10, v14                     // 0000002834BC: D6570033 043A14FF FFFF0000
	.long 0x7e1c398b                                           // 0000002834C8: 7E1C398B
	v_add3_u32 v10, v56, v52, 0x7fff                           // 0000002834CC: D655000A 03FE6938 00007FFF
	v_add3_u32 v11, v57, v55, 0x7fff                           // 0000002834D8: D655000B 03FE6F39 00007FFF
	v_bfe_u32 v55, v58, 16, 1                                  // 0000002834E4: D6100037 0205213A
	v_lshrrev_b32_e32 v57, 2, v5                               // 0000002834EC: 32720A82
	v_add_co_ci_u32_e64 v54, null, v54, v9, vcc_lo             // 0000002834F0: D5207C36 01AA1336
	v_and_or_b32 v52, 0xffff0000, v10, v14                     // 0000002834F8: D6570034 043A14FF FFFF0000
	.long 0x7e1c398b                                           // 000000283504: 7E1C398B
	v_add3_u32 v11, v58, v55, 0x7fff                           // 000000283508: D655000B 03FE6F3A 00007FFF
	v_lshrrev_b32_e32 v58, 6, v5                               // 000000283514: 32740A86
	s_waitcnt lgkmcnt(1)                                       // 000000283518: BF89FC17
	v_mul_f32_e32 v56, v43, v61                                // 00000028351C: 10707B2B
	v_and_b32_e32 v10, 15, v5                                  // 000000283520: 36140A8F
	v_mad_u64_u32 v[8:9], null, s4, v27, 0                     // 000000283524: D6FE7C08 02023604
	v_lshrrev_b32_e32 v61, 14, v5                              // 00000028352C: 327A0A8E
	s_waitcnt lgkmcnt(0)                                       // 000000283530: BF89FC07
	v_mul_f32_e32 v59, v43, v62                                // 000000283534: 10767D2B
	v_bfe_u32 v55, v56, 16, 1                                  // 000000283538: D6100037 02052138
	v_lshlrev_b32_e32 v10, 2, v10                              // 000000283540: 30141482
	v_lshrrev_b32_e32 v62, 18, v5                              // 000000283544: 327C0A92
	v_lshrrev_b32_e32 v63, 22, v5                              // 000000283548: 327E0A96
	v_bfe_u32 v60, v59, 16, 1                                  // 00000028354C: D610003C 0205213B
	v_add3_u32 v55, v56, v55, 0x7fff                           // 000000283554: D6550037 03FE6F38 00007FFF
	v_and_b32_e32 v56, 60, v57                                 // 000000283560: 367072BC
	v_and_b32_e32 v57, 60, v58                                 // 000000283564: 367274BC
	ds_load_b32 v58, v10                                       // 000000283568: D8D80000 3A00000A
	v_mad_u64_u32 v[9:10], null, s5, v27, v[9:10]              // 000000283570: D6FE7C09 04263605
	ds_load_b32 v10, v56                                       // 000000283578: D8D80000 0A000038
	ds_load_b32 v56, v57                                       // 000000283580: D8D80000 38000039
	v_lshrrev_b32_e32 v57, 10, v5                              // 000000283588: 32720A8A
	v_and_b32_e32 v61, 60, v61                                 // 00000028358C: 367A7ABC
	v_and_b32_e32 v62, 60, v62                                 // 000000283590: 367C7CBC
	v_and_b32_e32 v63, 60, v63                                 // 000000283594: 367E7EBC
	global_store_b128 v[53:54], v[47:50], off                  // 000000283598: DC760000 007C2F35
	v_and_b32_e32 v57, 60, v57                                 // 0000002835A0: 367272BC
	.long 0xd73c0008                                           // 0000002835A4: D73C0008
	v_cndmask_b32_e32 v1, 1, v8, vcc_lo                        // 0000002835A8: 02021081
	v_and_or_b32 v53, 0xffff0000, v11, v14                     // 0000002835AC: D6570035 043A16FF FFFF0000
	.long 0x7e1c39b7                                           // 0000002835B8: 7E1C39B7
	v_add3_u32 v11, v59, v60, 0x7fff                           // 0000002835BC: D655000B 03FE793B 00007FFF
	v_lshrrev_b32_e32 v60, 6, v6                               // 0000002835C8: 32780C86
	.long 0xd7006a32                                           // 0000002835CC: D7006A32
	v_cndmask_b32_e32 v1, s14, v8, vcc_lo                      // 0000002835D0: 0202100E
	s_delay_alu instid0(VALU_DEP_3)                            // 0000002835D4: BF870003
	v_and_or_b32 v54, 0xffff0000, v11, v14                     // 0000002835D8: D6570036 043A16FF FFFF0000
	v_add_co_ci_u32_e64 v59, null, s15, v9, vcc_lo             // 0000002835E4: D5207C3B 01AA120F
	s_waitcnt lgkmcnt(2)                                       // 0000002835EC: BF89FC27
	v_mul_f32_e32 v58, v42, v58                                // 0000002835F0: 1074752A
	s_waitcnt lgkmcnt(1)                                       // 0000002835F4: BF89FC17
	v_mul_f32_e32 v10, v42, v10                                // 0000002835F8: 1014152A
	ds_load_b32 v57, v57                                       // 0000002835FC: D8D80000 39000039
	ds_load_b32 v61, v61                                       // 000000283604: D8D80000 3D00003D
	ds_load_b32 v62, v62                                       // 00000028360C: D8D80000 3E00003E
	ds_load_b32 v63, v63                                       // 000000283614: D8D80000 3F00003F
	ds_load_b32 v64, v64                                       // 00000028361C: D8D80000 40000040
	s_waitcnt lgkmcnt(5)                                       // 000000283624: BF89FC57
	v_mul_f32_e32 v48, v42, v56                                // 000000283628: 1060712A
	v_and_b32_e32 v60, 60, v60                                 // 00000028362C: 367878BC
	v_bfe_u32 v47, v58, 16, 1                                  // 000000283630: D610002F 0205213A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000283638: BF870121
	v_add3_u32 v11, v58, v47, 0x7fff                           // 00000028363C: D655000B 03FE5F3A 00007FFF
	v_bfe_u32 v47, v10, 16, 1                                  // 000000283648: D610002F 0205210A
	.long 0x7e1c398b                                           // 000000283650: 7E1C398B
	s_delay_alu instid0(VALU_DEP_2)                            // 000000283654: BF870002
	v_add3_u32 v9, v10, v47, 0x7fff                            // 000000283658: D6550009 03FE5F0A 00007FFF
	v_mov_b32_e32 v11, v34                                     // 000000283664: 7E160322
	s_waitcnt lgkmcnt(4)                                       // 000000283668: BF89FC47
	v_dual_mul_f32 v8, v42, v57 :: v_dual_and_b32 v57, 15, v6  // 00000028366C: C8E4732A 08380C8F
	v_bfe_u32 v49, v48, 16, 1                                  // 000000283674: D6100031 02052130
	v_and_or_b32 v47, 0xffff0000, v9, v14                      // 00000028367C: D657002F 043A12FF FFFF0000
	.long 0xd73c0037                                           // 000000283688: D73C0037
	v_cndmask_b32_e32 v1, 1, v11, vcc_lo                       // 00000028368C: 02021681
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000283690: BF8701C3
	v_add3_u32 v10, v48, v49, 0x7fff                           // 000000283694: D655000A 03FE6330 00007FFF
	s_waitcnt lgkmcnt(3)                                       // 0000002836A0: BF89FC37
	v_mul_f32_e32 v48, v42, v61                                // 0000002836A4: 10607B2A
	v_bfe_u32 v49, v8, 16, 1                                   // 0000002836A8: D6100031 02052108
	.long 0x7e1c398a                                           // 0000002836B0: 7E1C398A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002836B4: BF870193
	v_bfe_u32 v9, v48, 16, 1                                   // 0000002836B8: D6100009 02052130
	v_add3_u32 v8, v8, v49, 0x7fff                             // 0000002836C0: D6550008 03FE6308 00007FFF
	s_waitcnt lgkmcnt(1)                                       // 0000002836CC: BF89FC17
	v_mul_f32_e32 v49, v42, v63                                // 0000002836D0: 10627F2A
	v_mul_f32_e32 v10, v42, v62                                // 0000002836D4: 10147D2A
	v_lshrrev_b32_e32 v62, 10, v6                              // 0000002836D8: 327C0C8A
	v_add3_u32 v9, v48, v9, 0x7fff                             // 0000002836DC: D6550009 03FE1330 00007FFF
	v_and_or_b32 v48, 0xffff0000, v8, v14                      // 0000002836E8: D6570030 043A10FF FFFF0000
	v_bfe_u32 v8, v49, 16, 1                                   // 0000002836F4: D6100008 02052131
	v_lshrrev_b32_e32 v63, 14, v6                              // 0000002836FC: 327E0C8E
	v_and_b32_e32 v62, 60, v62                                 // 000000283700: 367C7CBC
	.long 0x7e1c3989                                           // 000000283704: 7E1C3989
	s_delay_alu instid0(VALU_DEP_4)                            // 000000283708: BF870004
	v_add3_u32 v58, v49, v8, 0x7fff                            // 00000028370C: D655003A 03FE1131 00007FFF
	v_lshlrev_b32_e32 v49, 2, v57                              // 000000283718: 30627282
	v_bfe_u32 v11, v10, 16, 1                                  // 00000028371C: D610000B 0205210A
	v_lshrrev_b32_e32 v57, 2, v6                               // 000000283724: 32720C82
	v_mad_u64_u32 v[8:9], null, s4, v24, 0                     // 000000283728: D6FE7C08 02023004
	v_and_b32_e32 v63, 60, v63                                 // 000000283730: 367E7EBC
	ds_load_b32 v49, v49                                       // 000000283734: D8D80000 31000031
	v_add3_u32 v10, v10, v11, 0x7fff                           // 00000028373C: D655000A 03FE170A 00007FFF
	s_waitcnt lgkmcnt(1)                                       // 000000283748: BF89FC17
	v_mul_f32_e32 v11, v42, v64                                // 00000028374C: 1016812A
	v_lshrrev_b32_e32 v64, 18, v6                              // 000000283750: 32800C92
	v_and_b32_e32 v57, 60, v57                                 // 000000283754: 367272BC
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000283758: BF870193
	v_bfe_u32 v61, v11, 16, 1                                  // 00000028375C: D610003D 0205210B
	v_and_b32_e32 v64, 60, v64                                 // 000000283764: 368080BC
	ds_load_b32 v57, v57                                       // 000000283768: D8D80000 39000039
	ds_load_b32 v60, v60                                       // 000000283770: D8D80000 3C00003C
	ds_load_b32 v62, v62                                       // 000000283778: D8D80000 3E00003E
	ds_load_b32 v63, v63                                       // 000000283780: D8D80000 3F00003F
	ds_load_b32 v64, v64                                       // 000000283788: D8D80000 40000040
	ds_load_b32 v65, v65                                       // 000000283790: D8D80000 41000041
	ds_load_b32 v66, v66                                       // 000000283798: D8D80000 42000042
	s_waitcnt lgkmcnt(7)                                       // 0000002837A0: BF89FC77
	v_mul_f32_e32 v67, v41, v49                                // 0000002837A4: 10866329
	v_and_or_b32 v49, 0xffff0000, v10, v14                     // 0000002837A8: D6570031 043A14FF FFFF0000
	v_mad_u64_u32 v[9:10], null, s5, v24, v[9:10]              // 0000002837B4: D6FE7C09 04263005
	.long 0x7e1c39ba                                           // 0000002837BC: 7E1C39BA
	v_add3_u32 v10, v11, v61, 0x7fff                           // 0000002837C0: D655000A 03FE7B0B 00007FFF
	v_bfe_u32 v11, v67, 16, 1                                  // 0000002837CC: D610000B 02052143
	.long 0xd7006a3a                                           // 0000002837D4: D7006A3A
	v_cndmask_b32_e32 v1, v50, v55, vcc_lo                     // 0000002837D8: 02026F32
	s_waitcnt lgkmcnt(5)                                       // 0000002837DC: BF89FC57
	v_mul_f32_e32 v55, v41, v60                                // 0000002837E0: 106E7929
	v_and_or_b32 v50, 0xffff0000, v10, v14                     // 0000002837E4: D6570032 043A14FF FFFF0000
	.long 0xd73c0008                                           // 0000002837F0: D73C0008
	v_cndmask_b32_e32 v1, 1, v8, vcc_lo                        // 0000002837F4: 02021081
	v_add3_u32 v10, v67, v11, 0x7fff                           // 0000002837F8: D655000A 03FE1743 00007FFF
	v_mul_f32_e32 v11, v41, v57                                // 000000283804: 10167329
	v_add_co_ci_u32_e64 v59, null, v59, v56, vcc_lo            // 000000283808: D5207C3B 01AA713B
	s_waitcnt lgkmcnt(4)                                       // 000000283810: BF89FC47
	v_mul_f32_e32 v56, v41, v62                                // 000000283814: 10707D29
	.long 0xd7006a39                                           // 000000283818: D7006A39
	v_cndmask_b32_e32 v1, s14, v8, vcc_lo                      // 00000028381C: 0202100E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000283820: BF870001
	v_add_co_ci_u32_e64 v67, null, s15, v9, vcc_lo             // 000000283824: D5207C43 01AA120F
	v_bfe_u32 v8, v11, 16, 1                                   // 00000028382C: D6100008 0205210B
	v_bfe_u32 v9, v55, 16, 1                                   // 000000283834: D6100009 02052137
	.long 0x7e1c398a                                           // 00000028383C: 7E1C398A
	s_waitcnt lgkmcnt(3)                                       // 000000283840: BF89FC37
	v_mul_f32_e32 v10, v41, v63                                // 000000283844: 10147F29
	v_bfe_u32 v60, v56, 16, 1                                  // 000000283848: D610003C 02052138
	v_add3_u32 v8, v11, v8, 0x7fff                             // 000000283850: D6550008 03FE110B 00007FFF
	v_add3_u32 v9, v55, v9, 0x7fff                             // 00000028385C: D6550009 03FE1337 00007FFF
	v_mov_b32_e32 v11, v30                                     // 000000283868: 7E16031E
	v_bfe_u32 v61, v10, 16, 1                                  // 00000028386C: D610003D 0205210A
	s_waitcnt lgkmcnt(2)                                       // 000000283874: BF89FC27
	v_mul_f32_e32 v62, v41, v64                                // 000000283878: 107C8129
	v_and_or_b32 v55, 0xffff0000, v8, v14                      // 00000028387C: D6570037 043A10FF FFFF0000
	.long 0x7e1c3989                                           // 000000283888: 7E1C3989
	v_add3_u32 v8, v56, v60, 0x7fff                            // 00000028388C: D6550008 03FE7938 00007FFF
	v_add3_u32 v9, v10, v61, 0x7fff                            // 000000283898: D6550009 03FE7B0A 00007FFF
	.long 0xd73c003c                                           // 0000002838A4: D73C003C
	v_cndmask_b32_e32 v1, 1, v11, vcc_lo                       // 0000002838A8: 02021681
	v_bfe_u32 v11, v62, 16, 1                                  // 0000002838AC: D610000B 0205213E
	v_and_b32_e32 v64, 15, v7                                  // 0000002838B4: 36800E8F
	v_and_or_b32 v56, 0xffff0000, v8, v14                      // 0000002838B8: D6570038 043A10FF FFFF0000
	.long 0x7e1c3989                                           // 0000002838C4: 7E1C3989
	v_mad_u64_u32 v[8:9], null, s4, v25, 0                     // 0000002838C8: D6FE7C08 02023204
	v_add3_u32 v62, v62, v11, 0x7fff                           // 0000002838D0: D655003E 03FE173E 00007FFF
	v_lshlrev_b32_e32 v11, 2, v64                              // 0000002838DC: 30168082
	v_lshrrev_b32_e32 v64, 2, v7                               // 0000002838E0: 32800E82
	s_waitcnt lgkmcnt(1)                                       // 0000002838E4: BF89FC17
	v_mul_f32_e32 v10, v41, v65                                // 0000002838E8: 10148329
	s_waitcnt lgkmcnt(0)                                       // 0000002838EC: BF89FC07
	v_mul_f32_e32 v65, v41, v66                                // 0000002838F0: 10828529
	v_lshrrev_b32_e32 v66, 6, v7                               // 0000002838F4: 32840E86
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002838F8: BF870193
	v_bfe_u32 v63, v10, 16, 1                                  // 0000002838FC: D610003F 0205210A
	v_bfe_u32 v68, v65, 16, 1                                  // 000000283904: D6100044 02052141
	s_delay_alu instid0(VALU_DEP_2)                            // 00000028390C: BF870002
	v_add3_u32 v63, v10, v63, 0x7fff                           // 000000283910: D655003F 03FE7F0A 00007FFF
	v_mad_u64_u32 v[9:10], null, s5, v25, v[9:10]              // 00000028391C: D6FE7C09 04263205
	ds_load_b32 v10, v11                                       // 000000283924: D8D80000 0A00000B
	v_and_b32_e32 v11, 60, v64                                 // 00000028392C: 361680BC
	v_and_b32_e32 v64, 60, v66                                 // 000000283930: 368084BC
	v_lshrrev_b32_e32 v66, 10, v7                              // 000000283934: 32840E8A
	v_and_b32_e32 v71, 60, v71                                 // 000000283938: 368E8EBC
	.long 0xd73c0008                                           // 00000028393C: D73C0008
	v_cndmask_b32_e32 v1, 1, v8, vcc_lo                        // 000000283940: 02021081
	s_delay_alu instid0(VALU_DEP_3)                            // 000000283944: BF870003
	v_and_b32_e32 v66, 60, v66                                 // 000000283948: 368484BC
	s_waitcnt lgkmcnt(0)                                       // 00000028394C: BF89FC07
	v_mul_f32_e32 v74, v37, v10                                // 000000283950: 10941525
	ds_load_b32 v73, v11                                       // 000000283954: D8D80000 4900000B
	ds_load_b32 v64, v64                                       // 00000028395C: D8D80000 40000040
	ds_load_b32 v66, v66                                       // 000000283964: D8D80000 42000042
	ds_load_b32 v69, v69                                       // 00000028396C: D8D80000 45000045
	ds_load_b32 v70, v70                                       // 000000283974: D8D80000 46000046
	ds_load_b32 v71, v71                                       // 00000028397C: D8D80000 47000047
	ds_load_b32 v72, v72                                       // 000000283984: D8D80000 48000048
	.long 0xd7006a0a                                           // 00000028398C: D7006A0A
	v_cndmask_b32_e32 v1, v57, v60, vcc_lo                     // 000000283990: 02027939
	s_delay_alu instid0(VALU_DEP_1)                            // 000000283994: BF870001
	v_add_co_ci_u32_e64 v11, null, v67, v61, vcc_lo            // 000000283998: D5207C0B 01AA7B43
	v_bfe_u32 v61, v74, 16, 1                                  // 0000002839A0: D610003D 0205214A
	v_and_or_b32 v57, 0xffff0000, v62, v14                     // 0000002839A8: D6570039 043A7CFF FFFF0000
	.long 0x7e1c39bf                                           // 0000002839B4: 7E1C39BF
	v_add3_u32 v60, v65, v68, 0x7fff                           // 0000002839B8: D655003C 03FE8941 00007FFF
	s_clause 0x1                                               // 0000002839C4: BF850001
	global_store_b128 v[58:59], v[51:54], off                  // 0000002839C8: DC760000 007C333A
	global_store_b128 v[10:11], v[47:50], off                  // 0000002839D0: DC760000 007C2F0A
	v_add3_u32 v10, v74, v61, 0x7fff                           // 0000002839D8: D655000A 03FE7B4A 00007FFF
	.long 0xd7006a34                                           // 0000002839E4: D7006A34
	v_cndmask_b32_e32 v1, s14, v8, vcc_lo                      // 0000002839E8: 0202100E
	v_and_or_b32 v58, 0xffff0000, v60, v14                     // 0000002839EC: D657003A 043A78FF FFFF0000
	s_waitcnt lgkmcnt(6)                                       // 0000002839F8: BF89FC67
	v_mul_f32_e32 v11, v37, v73                                // 0000002839FC: 10169325
	s_waitcnt lgkmcnt(5)                                       // 000000283A00: BF89FC57
	v_mul_f32_e32 v47, v37, v64                                // 000000283A04: 105E8125
	v_add_co_ci_u32_e64 v53, null, s15, v9, vcc_lo             // 000000283A08: D5207C35 01AA120F
	s_waitcnt lgkmcnt(4)                                       // 000000283A10: BF89FC47
	v_mul_f32_e32 v48, v37, v66                                // 000000283A14: 10608525
	v_bfe_u32 v8, v11, 16, 1                                   // 000000283A18: D6100008 0205210B
	v_bfe_u32 v9, v47, 16, 1                                   // 000000283A20: D6100009 0205212F
	.long 0x7e1c398a                                           // 000000283A28: 7E1C398A
	s_waitcnt vmcnt(0)                                         // 000000283A2C: BF8903F7
	v_lshrrev_b32_e32 v54, 2, v35                              // 000000283A30: 326C4682
	s_waitcnt lgkmcnt(3)                                       // 000000283A34: BF89FC37
	v_mul_f32_e32 v10, v37, v69                                // 000000283A38: 10148B25
	v_add3_u32 v8, v11, v8, 0x7fff                             // 000000283A3C: D6550008 03FE110B 00007FFF
	v_add3_u32 v9, v47, v9, 0x7fff                             // 000000283A48: D6550009 03FE132F 00007FFF
	v_bfe_u32 v49, v48, 16, 1                                  // 000000283A54: D6100031 02052130
	v_mov_b32_e32 v11, v33                                     // 000000283A5C: 7E160321
	v_bfe_u32 v50, v10, 16, 1                                  // 000000283A60: D6100032 0205210A
	v_and_or_b32 v47, 0xffff0000, v8, v14                      // 000000283A68: D657002F 043A10FF FFFF0000
	.long 0x7e1c3989                                           // 000000283A74: 7E1C3989
	v_add3_u32 v8, v48, v49, 0x7fff                            // 000000283A78: D6550008 03FE6330 00007FFF
	s_waitcnt lgkmcnt(2)                                       // 000000283A84: BF89FC27
	v_mul_f32_e32 v9, v37, v70                                 // 000000283A88: 10128D25
	v_add3_u32 v10, v10, v50, 0x7fff                           // 000000283A8C: D655000A 03FE650A 00007FFF
	.long 0xd73c0032                                           // 000000283A98: D73C0032
	v_cndmask_b32_e32 v1, 1, v11, vcc_lo                       // 000000283A9C: 02021681
	s_waitcnt lgkmcnt(1)                                       // 000000283AA0: BF89FC17
	v_mul_f32_e32 v11, v37, v71                                // 000000283AA4: 10168F25
	v_and_or_b32 v48, 0xffff0000, v8, v14                      // 000000283AA8: D6570030 043A10FF FFFF0000
	v_bfe_u32 v8, v9, 16, 1                                    // 000000283AB4: D6100008 02052109
	.long 0x7e1c398a                                           // 000000283ABC: 7E1C398A
	v_and_b32_e32 v10, 15, v35                                 // 000000283AC0: 3614468F
	v_bfe_u32 v49, v11, 16, 1                                  // 000000283AC4: D6100031 0205210B
	v_lshrrev_b32_e32 v62, 10, v35                             // 000000283ACC: 327C468A
	v_add3_u32 v59, v9, v8, 0x7fff                             // 000000283AD0: D655003B 03FE1109 00007FFF
	v_lshrrev_b32_e32 v63, 14, v35                             // 000000283ADC: 327E468E
	v_lshlrev_b32_e32 v8, 2, v10                               // 000000283AE0: 30101482
	v_add3_u32 v10, v11, v49, 0x7fff                           // 000000283AE4: D655000A 03FE630B 00007FFF
	v_and_b32_e32 v11, 60, v54                                 // 000000283AF0: 36166CBC
	v_lshrrev_b32_e32 v49, 6, v35                              // 000000283AF4: 32624686
	v_lshrrev_b32_e32 v64, 18, v35                             // 000000283AF8: 32804692
	ds_load_b32 v61, v8                                        // 000000283AFC: D8D80000 3D000008
	v_lshrrev_b32_e32 v65, 22, v35                             // 000000283B04: 32824696
	ds_load_b32 v11, v11                                       // 000000283B08: D8D80000 0B00000B
	v_lshrrev_b32_e32 v66, 26, v35                             // 000000283B10: 3284469A
	v_and_b32_e32 v49, 60, v49                                 // 000000283B14: 366262BC
	v_and_b32_e32 v62, 60, v62                                 // 000000283B18: 367C7CBC
	s_waitcnt lgkmcnt(2)                                       // 000000283B1C: BF89FC27
	v_dual_mul_f32 v60, v37, v72 :: v_dual_and_b32 v63, 60, v63// 000000283B20: C8E49125 3C3E7EBC
	v_and_b32_e32 v64, 60, v64                                 // 000000283B28: 368080BC
	v_and_b32_e32 v65, 60, v65                                 // 000000283B2C: 368282BC
	v_and_b32_e32 v66, 60, v66                                 // 000000283B30: 368484BC
	v_mad_u64_u32 v[8:9], null, s4, v23, 0                     // 000000283B34: D6FE7C08 02022E04
	v_bfe_u32 v54, v60, 16, 1                                  // 000000283B3C: D6100036 0205213C
	.long 0xd7006a34                                           // 000000283B44: D7006A34
	v_cndmask_b32_e32 v1, v52, v50, vcc_lo                     // 000000283B48: 02026534
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000283B4C: BF870191
	v_add_co_ci_u32_e64 v53, null, v53, v51, vcc_lo            // 000000283B50: D5207C35 01AA6735
	v_add3_u32 v54, v60, v54, 0x7fff                           // 000000283B58: D6550036 03FE6D3C 00007FFF
	s_waitcnt lgkmcnt(1)                                       // 000000283B64: BF89FC17
	v_mul_f32_e32 v61, v32, v61                                // 000000283B68: 107A7B20
	global_store_b128 v[52:53], v[55:58], off                  // 000000283B6C: DC760000 007C3734
	s_waitcnt lgkmcnt(0)                                       // 000000283B74: BF89FC07
	v_mul_f32_e32 v68, v32, v11                                // 000000283B78: 10881720
	ds_load_b32 v67, v49                                       // 000000283B7C: D8D80000 43000031
	ds_load_b32 v62, v62                                       // 000000283B84: D8D80000 3E00003E
	ds_load_b32 v63, v63                                       // 000000283B8C: D8D80000 3F00003F
	ds_load_b32 v64, v64                                       // 000000283B94: D8D80000 40000040
	ds_load_b32 v65, v65                                       // 000000283B9C: D8D80000 41000041
	ds_load_b32 v66, v66                                       // 000000283BA4: D8D80000 42000042
	v_and_or_b32 v49, 0xffff0000, v59, v14                     // 000000283BAC: D6570031 043A76FF FFFF0000
	.long 0x7e1c398a                                           // 000000283BB8: 7E1C398A
	v_mad_u64_u32 v[9:10], null, s5, v23, v[9:10]              // 000000283BBC: D6FE7C09 04262E05
	v_bfe_u32 v10, v61, 16, 1                                  // 000000283BC4: D610000A 0205213D
	v_bfe_u32 v51, v68, 16, 1                                  // 000000283BCC: D6100033 02052144
	v_mov_b32_e32 v11, v26                                     // 000000283BD4: 7E16031A
	v_and_or_b32 v50, 0xffff0000, v54, v14                     // 000000283BD8: D6570032 043A6CFF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000283BE4: BF8701B4
	v_add3_u32 v10, v61, v10, 0x7fff                           // 000000283BE8: D655000A 03FE153D 00007FFF
	.long 0xd73c003b                                           // 000000283BF4: D73C003B
	v_cndmask_b32_e32 v1, 1, v8, vcc_lo                        // 000000283BF8: 02021081
	v_add3_u32 v8, v68, v51, 0x7fff                            // 000000283BFC: D6550008 03FE6744 00007FFF
	.long 0x7e1c398a                                           // 000000283C08: 7E1C398A
	s_waitcnt lgkmcnt(5)                                       // 000000283C0C: BF89FC57
	v_mul_f32_e32 v54, v32, v67                                // 000000283C10: 106C8720
	s_waitcnt lgkmcnt(4)                                       // 000000283C14: BF89FC47
	v_mul_f32_e32 v10, v32, v62                                // 000000283C18: 10147D20
	s_waitcnt lgkmcnt(3)                                       // 000000283C1C: BF89FC37
	v_mul_f32_e32 v51, v32, v63                                // 000000283C20: 10667F20
	.long 0xd73c003d                                           // 000000283C24: D73C003D
	v_cndmask_b32_e32 v1, 1, v11, vcc_lo                       // 000000283C28: 02021681
	s_waitcnt lgkmcnt(2)                                       // 000000283C2C: BF89FC27
	v_mul_f32_e32 v63, v32, v64                                // 000000283C30: 107E8120
	v_bfe_u32 v9, v54, 16, 1                                   // 000000283C34: D6100009 02052136
	v_bfe_u32 v11, v10, 16, 1                                  // 000000283C3C: D610000B 0205210A
	s_waitcnt lgkmcnt(1)                                       // 000000283C44: BF89FC17
	v_mul_f32_e32 v64, v32, v65                                // 000000283C48: 10808320
	v_and_or_b32 v8, 0xffff0000, v8, v14                       // 000000283C4C: D6570008 043A10FF FFFF0000
	.long 0xd7006a3b                                           // 000000283C58: D7006A3B
	v_cndmask_b32_e32 v1, s14, v59, vcc_lo                     // 000000283C5C: 0202760E
	v_add3_u32 v9, v54, v9, 0x7fff                             // 000000283C60: D6550009 03FE1336 00007FFF
	v_bfe_u32 v54, v51, 16, 1                                  // 000000283C6C: D6100036 02052133
	v_add_co_ci_u32_e64 v60, null, s15, v60, vcc_lo            // 000000283C74: D5207C3C 01AA780F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000283C7C: BF870214
	.long 0xd7006a3b                                           // 000000283C80: D7006A3B
	v_cndmask_b32_e32 v1, v59, v61, vcc_lo                     // 000000283C84: 02027B3B
	.long 0x7e1c3989                                           // 000000283C88: 7E1C3989
	v_add3_u32 v9, v10, v11, 0x7fff                            // 000000283C8C: D6550009 03FE170A 00007FFF
	v_add3_u32 v10, v51, v54, 0x7fff                           // 000000283C98: D655000A 03FE6D33 00007FFF
	v_bfe_u32 v11, v63, 16, 1                                  // 000000283CA4: D610000B 0205213F
	v_bfe_u32 v51, v64, 16, 1                                  // 000000283CAC: D6100033 02052140
	s_waitcnt lgkmcnt(0)                                       // 000000283CB4: BF89FC07
	v_mul_f32_e32 v54, v32, v66                                // 000000283CB8: 106C8520
	v_and_or_b32 v9, 0xffff0000, v9, v14                       // 000000283CBC: D6570009 043A12FF FFFF0000
	.long 0x7e1c398a                                           // 000000283CC8: 7E1C398A
	v_add3_u32 v10, v63, v11, 0x7fff                           // 000000283CCC: D655000A 03FE173F 00007FFF
	v_add3_u32 v11, v64, v51, 0x7fff                           // 000000283CD8: D655000B 03FE6740 00007FFF
	v_bfe_u32 v51, v54, 16, 1                                  // 000000283CE4: D6100033 02052136
	v_add_co_ci_u32_e64 v60, null, v60, v62, vcc_lo            // 000000283CEC: D5207C3C 01AA7D3C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000283CF4: BF870214
	v_and_or_b32 v10, 0xffff0000, v10, v14                     // 000000283CF8: D657000A 043A14FF FFFF0000
	.long 0x7e1c398b                                           // 000000283D04: 7E1C398B
	s_delay_alu instid0(VALU_DEP_4)                            // 000000283D08: BF870004
	v_add3_u32 v11, v54, v51, 0x7fff                           // 000000283D0C: D655000B 03FE6736 00007FFF
	global_store_b128 v[59:60], v[47:50], off                  // 000000283D18: DC760000 007C2F3B
	v_and_or_b32 v11, 0xffff0000, v11, v14                     // 000000283D20: D657000B 043A16FF FFFF0000
	s_cbranch_execnz 672                                       // 000000283D2C: BFA602A0 <_ZN7halogen12_GLOBAL__N_114k_deq_q4cp_v8uILi8ELb0EEEvPKhPtjjllllNS0_5DeqCbE+0x29b0>
	s_mov_b32 s1, exec_lo                                      // 000000283D30: BE81007E
	.long 0xd4cc007e                                           // 000000283D34: D4CC007E
	v_cndmask_b32_e32 v1, s17, v38, vcc_lo                     // 000000283D38: 02024C11
	s_cbranch_execz 697                                        // 000000283D3C: BFA502B9 <_ZN7halogen12_GLOBAL__N_114k_deq_q4cp_v8uILi8ELb0EEEvPKhPtjjllllNS0_5DeqCbE+0x2a24>
	s_waitcnt vmcnt(7)                                         // 000000283D40: BF891FF7
	v_lshrrev_b32_e32 v8, 22, v1                               // 000000283D44: 32100296
	v_lshrrev_b32_e32 v9, 26, v1                               // 000000283D48: 3212029A
	v_lshrrev_b32_e32 v11, 14, v1                              // 000000283D4C: 3216028E
	v_lshrrev_b32_e32 v14, 10, v1                              // 000000283D50: 321C028A
	v_lshrrev_b32_e32 v10, 18, v1                              // 000000283D54: 32140292
	v_and_b32_e32 v8, 60, v8                                   // 000000283D58: 361010BC
	v_lshrrev_b32_e32 v38, 6, v1                               // 000000283D5C: 324C0286
	v_lshrrev_b32_e32 v47, 2, v1                               // 000000283D60: 325E0282
	v_and_b32_e32 v1, 15, v1                                   // 000000283D64: 3602028F
	v_and_b32_e32 v9, 60, v9                                   // 000000283D68: 361212BC
	ds_load_b32 v48, v8                                        // 000000283D6C: D8D80000 30000008
	v_and_b32_e32 v8, 60, v11                                  // 000000283D74: 361016BC
	v_and_b32_e32 v11, 60, v14                                 // 000000283D78: 36161CBC
	v_and_b32_e32 v10, 60, v10                                 // 000000283D7C: 361414BC
	v_and_b32_e32 v14, 60, v38                                 // 000000283D80: 361C4CBC
	v_and_b32_e32 v38, 60, v47                                 // 000000283D84: 364C5EBC
	v_lshlrev_b32_e32 v1, 2, v1                                // 000000283D88: 30020282
	ds_load_b32 v51, v11                                       // 000000283D8C: D8D80000 3300000B
	ds_load_b32 v14, v14                                       // 000000283D94: D8D80000 0E00000E
	ds_load_b32 v38, v38                                       // 000000283D9C: D8D80000 26000026
	ds_load_b32 v1, v1                                         // 000000283DA4: D8D80000 01000001
	v_mov_b32_e32 v11, v29                                     // 000000283DAC: 7E16031D
	.long 0x7f683880                                           // 000000283DB0: 7F683880
	s_waitcnt lgkmcnt(4)                                       // 000000283DB4: BF89FC47
	v_mul_f32_e32 v29, v46, v48                                // 000000283DB8: 103A612E
	ds_load_b32 v47, v9                                        // 000000283DBC: D8D80000 2F000009
	ds_load_b32 v49, v10                                       // 000000283DC4: D8D80000 3100000A
	ds_load_b32 v50, v8                                        // 000000283DCC: D8D80000 32000008
	v_mad_u64_u32 v[8:9], null, s4, v28, 0                     // 000000283DD4: D6FE7C08 02023804
	v_bfe_u32 v48, v29, 16, 1                                  // 000000283DDC: D6100030 0205211D
	s_waitcnt lgkmcnt(5)                                       // 000000283DE4: BF89FC57
	v_mul_f32_e32 v14, v46, v14                                // 000000283DE8: 101C1D2E
	s_waitcnt lgkmcnt(4)                                       // 000000283DEC: BF89FC47
	v_mul_f32_e32 v38, v46, v38                                // 000000283DF0: 104C4D2E
	s_waitcnt lgkmcnt(3)                                       // 000000283DF4: BF89FC37
	v_mul_f32_e32 v1, v46, v1                                  // 000000283DF8: 1002032E
	v_mad_u64_u32 v[9:10], null, s5, v28, v[9:10]              // 000000283DFC: D6FE7C09 04263805
	v_add3_u32 v29, v29, v48, 0x7fff                           // 000000283E04: D655001D 03FE611D 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000283E10: BF870191
	.long 0x7e68399d                                           // 000000283E14: 7E68399D
	.long 0xd73c0008                                           // 000000283E18: D73C0008
	v_cndmask_b32_e32 v1, 1, v8, vcc_lo                        // 000000283E1C: 02021081
	s_waitcnt lgkmcnt(2)                                       // 000000283E20: BF89FC27
	v_mul_f32_e32 v10, v46, v47                                // 000000283E24: 10145F2E
	s_waitcnt lgkmcnt(1)                                       // 000000283E28: BF89FC17
	v_mul_f32_e32 v28, v46, v49                                // 000000283E2C: 1038632E
	s_waitcnt lgkmcnt(0)                                       // 000000283E30: BF89FC07
	v_mul_f32_e32 v47, v46, v50                                // 000000283E34: 105E652E
	v_mul_f32_e32 v50, v46, v51                                // 000000283E38: 1064672E
	v_bfe_u32 v49, v10, 16, 1                                  // 000000283E3C: D6100031 0205210A
	v_bfe_u32 v46, v28, 16, 1                                  // 000000283E44: D610002E 0205211C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000283E4C: BF870194
	v_bfe_u32 v48, v47, 16, 1                                  // 000000283E50: D6100030 0205212F
	v_add3_u32 v10, v10, v49, 0x7fff                           // 000000283E58: D655000A 03FE630A 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000283E64: BF870193
	v_add3_u32 v28, v28, v46, 0x7fff                           // 000000283E68: D655001C 03FE5D1C 00007FFF
	v_add3_u32 v29, v47, v48, 0x7fff                           // 000000283E74: D655001D 03FE612F 00007FFF
	v_bfe_u32 v47, v14, 16, 1                                  // 000000283E80: D610002F 0205210E
	v_bfe_u32 v48, v50, 16, 1                                  // 000000283E88: D6100030 02052132
	v_and_or_b32 v49, 0xffff0000, v10, v52                     // 000000283E90: D6570031 04D214FF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000283E9C: BF870214
	.long 0x7e68399d                                           // 000000283EA0: 7E68399D
	v_add3_u32 v10, v14, v47, 0x7fff                           // 000000283EA4: D655000A 03FE5F0E 00007FFF
	v_bfe_u32 v14, v1, 16, 1                                   // 000000283EB0: D610000E 02052101
	v_add3_u32 v46, v50, v48, 0x7fff                           // 000000283EB8: D655002E 03FE6132 00007FFF
	v_bfe_u32 v29, v38, 16, 1                                  // 000000283EC4: D610001D 02052126
	v_and_or_b32 v48, 0xffff0000, v28, v52                     // 000000283ECC: D6570030 04D238FF FFFF0000
	.long 0x7e68398a                                           // 000000283ED8: 7E68398A
	v_add3_u32 v1, v1, v14, 0x7fff                             // 000000283EDC: D6550001 03FE1D01 00007FFF
	.long 0xd73c000a                                           // 000000283EE8: D73C000A
	v_cndmask_b32_e32 v1, 1, v11, vcc_lo                       // 000000283EEC: 02021681
	v_add3_u32 v14, v38, v29, 0x7fff                           // 000000283EF0: D655000E 03FE3B26 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000283EFC: BF870214
	v_and_or_b32 v47, 0xffff0000, v46, v52                     // 000000283F00: D657002F 04D25CFF FFFF0000
	.long 0x7e683981                                           // 000000283F0C: 7E683981
	.long 0xd7006a01                                           // 000000283F10: D7006A01
	v_cndmask_b32_e32 v1, s14, v8, vcc_lo                      // 000000283F14: 0202100E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000283F18: BF870191
	v_add_co_ci_u32_e64 v9, null, s15, v9, vcc_lo              // 000000283F1C: D5207C09 01AA120F
	v_and_or_b32 v46, 0xffff0000, v14, v52                     // 000000283F24: D657002E 04D21CFF FFFF0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000283F30: BF870093
	.long 0xd7006a08                                           // 000000283F34: D7006A08
	v_cndmask_b32_e32 v1, v1, v10, vcc_lo                      // 000000283F38: 02021501
	v_add_co_ci_u32_e64 v9, null, v9, v11, vcc_lo              // 000000283F3C: D5207C09 01AA1709
	global_store_b128 v[8:9], v[46:49], off                    // 000000283F44: DC760000 007C2E08
	s_or_b32 exec_lo, exec_lo, s1                              // 000000283F4C: 8C7E017E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000283F50: BF870009
	s_mov_b32 s1, exec_lo                                      // 000000283F54: BE81007E
	.long 0xd4cc007e                                           // 000000283F58: D4CC007E
	v_cndmask_b32_e32 v1, s17, v22, vcc_lo                     // 000000283F5C: 02022C11
	s_cbranch_execnz 566                                       // 000000283F60: BFA60236 <_ZN7halogen12_GLOBAL__N_114k_deq_q4cp_v8uILi8ELb0EEEvPKhPtjjllllNS0_5DeqCbE+0x2a3c>
	s_or_b32 exec_lo, exec_lo, s1                              // 000000283F64: 8C7E017E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000283F68: BF870009
	s_mov_b32 s1, exec_lo                                      // 000000283F6C: BE81007E
	.long 0xd4cc007e                                           // 000000283F70: D4CC007E
	v_cndmask_b32_e32 v1, s17, v20, vcc_lo                     // 000000283F74: 02022811
	s_cbranch_execz 698                                        // 000000283F78: BFA502BA <_ZN7halogen12_GLOBAL__N_114k_deq_q4cp_v8uILi8ELb0EEEvPKhPtjjllllNS0_5DeqCbE+0x2c64>
	s_waitcnt vmcnt(5)                                         // 000000283F7C: BF8917F7
	v_lshrrev_b32_e32 v1, 22, v3                               // 000000283F80: 32020696
	v_lshrrev_b32_e32 v2, 26, v3                               // 000000283F84: 3204069A
	v_lshrrev_b32_e32 v8, 18, v3                               // 000000283F88: 32100692
	v_lshrrev_b32_e32 v9, 14, v3                               // 000000283F8C: 3212068E
	v_lshrrev_b32_e32 v10, 10, v3                              // 000000283F90: 3214068A
	v_and_b32_e32 v1, 60, v1                                   // 000000283F94: 360202BC
	v_lshrrev_b32_e32 v11, 6, v3                               // 000000283F98: 32160686
	v_lshrrev_b32_e32 v14, 2, v3                               // 000000283F9C: 321C0682
	v_and_b32_e32 v2, 60, v2                                   // 000000283FA0: 360404BC
	v_and_b32_e32 v8, 60, v8                                   // 000000283FA4: 361010BC
	ds_load_b32 v20, v1                                        // 000000283FA8: D8D80000 14000001
	v_and_b32_e32 v1, 60, v9                                   // 000000283FB0: 360212BC
	v_and_b32_e32 v9, 60, v10                                  // 000000283FB4: 361214BC
	v_and_b32_e32 v10, 60, v11                                 // 000000283FB8: 361416BC
	v_and_b32_e32 v11, 60, v14                                 // 000000283FBC: 36161CBC
	ds_load_b32 v14, v2                                        // 000000283FC0: D8D80000 0E000002
	ds_load_b32 v8, v8                                         // 000000283FC8: D8D80000 08000008
	ds_load_b32 v22, v1                                        // 000000283FD0: D8D80000 16000001
	v_and_b32_e32 v3, 15, v3                                   // 000000283FD8: 3606068F
	.long 0x7f4c3880                                           // 000000283FDC: 7F4C3880
	s_delay_alu instid0(VALU_DEP_2)                            // 000000283FE0: BF870002
	v_lshlrev_b32_e32 v1, 2, v3                                // 000000283FE4: 30020682
	ds_load_b32 v9, v9                                         // 000000283FE8: D8D80000 09000009
	ds_load_b32 v10, v10                                       // 000000283FF0: D8D80000 0A00000A
	ds_load_b32 v28, v11                                       // 000000283FF8: D8D80000 1C00000B
	ds_load_b32 v29, v1                                        // 000000284000: D8D80000 1D000001
	v_mad_u64_u32 v[1:2], null, s4, v31, 0                     // 000000284008: D6FE7C01 02023E04
	v_mov_b32_e32 v11, v36                                     // 000000284010: 7E160324
	s_waitcnt lgkmcnt(7)                                       // 000000284014: BF89FC77
	v_mul_f32_e32 v20, v44, v20                                // 000000284018: 1028292C
	s_delay_alu instid0(VALU_DEP_3)                            // 00000028401C: BF870003
	v_mad_u64_u32 v[2:3], null, s5, v31, v[2:3]                // 000000284020: D6FE7C02 040A3E05
	s_waitcnt lgkmcnt(6)                                       // 000000284028: BF89FC67
	v_mul_f32_e32 v3, v44, v14                                 // 00000028402C: 10061D2C
	s_waitcnt lgkmcnt(5)                                       // 000000284030: BF89FC57
	v_mul_f32_e32 v8, v44, v8                                  // 000000284034: 1010112C
	s_waitcnt lgkmcnt(4)                                       // 000000284038: BF89FC47
	v_mul_f32_e32 v14, v44, v22                                // 00000028403C: 101C2D2C
	v_bfe_u32 v22, v20, 16, 1                                  // 000000284040: D6100016 02052114
	v_bfe_u32 v31, v3, 16, 1                                   // 000000284048: D610001F 02052103
	v_bfe_u32 v36, v8, 16, 1                                   // 000000284050: D6100024 02052108
	s_waitcnt lgkmcnt(3)                                       // 000000284058: BF89FC37
	v_mul_f32_e32 v9, v44, v9                                  // 00000028405C: 1012132C
	s_waitcnt lgkmcnt(2)                                       // 000000284060: BF89FC27
	v_mul_f32_e32 v10, v44, v10                                // 000000284064: 1014152C
	v_add3_u32 v20, v20, v22, 0x7fff                           // 000000284068: D6550014 03FE2D14 00007FFF
	v_bfe_u32 v22, v14, 16, 1                                  // 000000284074: D6100016 0205210E
	s_waitcnt lgkmcnt(0)                                       // 00000028407C: BF89FC07
	v_mul_f32_e32 v29, v44, v29                                // 000000284080: 103A3B2C
	v_add3_u32 v3, v3, v31, 0x7fff                             // 000000284084: D6550003 03FE3F03 00007FFF
	v_mul_f32_e32 v28, v44, v28                                // 000000284090: 1038392C
	.long 0x7e4c3994                                           // 000000284094: 7E4C3994
	v_add3_u32 v14, v14, v22, 0x7fff                           // 000000284098: D655000E 03FE2D0E 00007FFF
	v_bfe_u32 v20, v10, 16, 1                                  // 0000002840A4: D6100014 0205210A
	v_bfe_u32 v22, v9, 16, 1                                   // 0000002840AC: D6100016 02052109
	v_add3_u32 v8, v8, v36, 0x7fff                             // 0000002840B4: D6550008 03FE4908 00007FFF
	v_and_or_b32 v47, 0xffff0000, v3, v38                      // 0000002840C0: D657002F 049A06FF FFFF0000
	.long 0x7e4c398e                                           // 0000002840CC: 7E4C398E
	v_add3_u32 v3, v10, v20, 0x7fff                            // 0000002840D0: D6550003 03FE290A 00007FFF
	v_bfe_u32 v10, v29, 16, 1                                  // 0000002840DC: D610000A 0205211D
	.long 0xd73c0001                                           // 0000002840E4: D73C0001
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 0000002840E8: 02020281
	v_bfe_u32 v14, v28, 16, 1                                  // 0000002840EC: D610000E 0205211C
	v_add3_u32 v20, v9, v22, 0x7fff                            // 0000002840F4: D6550014 03FE2D09 00007FFF
	v_and_or_b32 v46, 0xffff0000, v8, v38                      // 000000284100: D657002E 049A10FF FFFF0000
	.long 0x7e4c3983                                           // 00000028410C: 7E4C3983
	v_add3_u32 v3, v29, v10, 0x7fff                            // 000000284110: D6550003 03FE151D 00007FFF
	.long 0xd73c0008                                           // 00000028411C: D73C0008
	v_cndmask_b32_e32 v1, 1, v11, vcc_lo                       // 000000284120: 02021681
	.long 0xd7006a01                                           // 000000284124: D7006A01
	v_cndmask_b32_e32 v1, s14, v1, vcc_lo                      // 000000284128: 0202020E
	v_add3_u32 v10, v28, v14, 0x7fff                           // 00000028412C: D655000A 03FE1D1C 00007FFF
	v_and_or_b32 v45, 0xffff0000, v20, v38                     // 000000284138: D657002D 049A28FF FFFF0000
	.long 0x7e4c3983                                           // 000000284144: 7E4C3983
	v_add_co_ci_u32_e64 v2, null, s15, v2, vcc_lo              // 000000284148: D5207C02 01AA040F
	.long 0xd7006a01                                           // 000000284150: D7006A01
	v_cndmask_b32_e32 v1, v1, v8, vcc_lo                       // 000000284154: 02021101
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000284158: BF870193
	v_and_or_b32 v44, 0xffff0000, v10, v38                     // 00000028415C: D657002C 049A14FF FFFF0000
	v_add_co_ci_u32_e64 v2, null, v2, v9, vcc_lo               // 000000284168: D5207C02 01AA1302
	global_store_b128 v[1:2], v[44:47], off                    // 000000284170: DC760000 007C2C01
	s_or_b32 exec_lo, exec_lo, s1                              // 000000284178: 8C7E017E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000028417C: BF870009
	s_mov_b32 s1, exec_lo                                      // 000000284180: BE81007E
	.long 0xd4cc007e                                           // 000000284184: D4CC007E
	v_cndmask_b32_e32 v1, s17, v19, vcc_lo                     // 000000284188: 02022611
	s_cbranch_execnz 571                                       // 00000028418C: BFA6023B <_ZN7halogen12_GLOBAL__N_114k_deq_q4cp_v8uILi8ELb0EEEvPKhPtjjllllNS0_5DeqCbE+0x2c7c>
	s_or_b32 exec_lo, exec_lo, s1                              // 000000284190: 8C7E017E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000284194: BF870009
	s_mov_b32 s1, exec_lo                                      // 000000284198: BE81007E
	.long 0xd4cc007e                                           // 00000028419C: D4CC007E
	v_cndmask_b32_e32 v1, s17, v18, vcc_lo                     // 0000002841A0: 02022411
	s_cbranch_execz 699                                        // 0000002841A4: BFA502BB <_ZN7halogen12_GLOBAL__N_114k_deq_q4cp_v8uILi8ELb0EEEvPKhPtjjllllNS0_5DeqCbE+0x2e94>
	s_waitcnt vmcnt(3)                                         // 0000002841A8: BF890FF7
	v_lshrrev_b32_e32 v1, 22, v5                               // 0000002841AC: 32020A96
	v_lshrrev_b32_e32 v2, 26, v5                               // 0000002841B0: 32040A9A
	v_lshrrev_b32_e32 v3, 18, v5                               // 0000002841B4: 32060A92
	v_lshrrev_b32_e32 v4, 14, v5                               // 0000002841B8: 32080A8E
	v_lshrrev_b32_e32 v8, 10, v5                               // 0000002841BC: 32100A8A
	v_and_b32_e32 v1, 60, v1                                   // 0000002841C0: 360202BC
	v_lshrrev_b32_e32 v9, 6, v5                                // 0000002841C4: 32120A86
	v_lshrrev_b32_e32 v10, 2, v5                               // 0000002841C8: 32140A82
	v_dual_mov_b32 v11, v30 :: v_dual_and_b32 v2, 60, v2       // 0000002841CC: CA24011E 0B0204BC
	ds_load_b32 v14, v1                                        // 0000002841D4: D8D80000 0E000001
	v_and_b32_e32 v3, 60, v3                                   // 0000002841DC: 360606BC
	v_and_b32_e32 v1, 60, v4                                   // 0000002841E0: 360208BC
	v_and_b32_e32 v5, 15, v5                                   // 0000002841E4: 360A0A8F
	v_and_b32_e32 v4, 60, v8                                   // 0000002841E8: 360810BC
	v_and_b32_e32 v8, 60, v9                                   // 0000002841EC: 361012BC
	v_and_b32_e32 v9, 60, v10                                  // 0000002841F0: 361214BC
	ds_load_b32 v10, v2                                        // 0000002841F4: D8D80000 0A000002
	ds_load_b32 v18, v3                                        // 0000002841FC: D8D80000 12000003
	ds_load_b32 v19, v1                                        // 000000284204: D8D80000 13000001
	v_lshlrev_b32_e32 v1, 2, v5                                // 00000028420C: 30020A82
	ds_load_b32 v4, v4                                         // 000000284210: D8D80000 04000004
	ds_load_b32 v5, v8                                         // 000000284218: D8D80000 05000008
	ds_load_b32 v8, v9                                         // 000000284220: D8D80000 08000009
	ds_load_b32 v9, v1                                         // 000000284228: D8D80000 09000001
	v_mad_u64_u32 v[1:2], null, s4, v24, 0                     // 000000284230: D6FE7C01 02023004
	.long 0x7f283880                                           // 000000284238: 7F283880
	s_delay_alu instid0(VALU_DEP_2)                            // 00000028423C: BF870002
	v_mad_u64_u32 v[2:3], null, s5, v24, v[2:3]                // 000000284240: D6FE7C02 040A3005
	s_waitcnt lgkmcnt(7)                                       // 000000284248: BF89FC77
	v_mul_f32_e32 v14, v42, v14                                // 00000028424C: 101C1D2A
	s_waitcnt lgkmcnt(6)                                       // 000000284250: BF89FC67
	v_mul_f32_e32 v3, v42, v10                                 // 000000284254: 1006152A
	s_waitcnt lgkmcnt(5)                                       // 000000284258: BF89FC57
	v_mul_f32_e32 v10, v42, v18                                // 00000028425C: 1014252A
	s_waitcnt lgkmcnt(4)                                       // 000000284260: BF89FC47
	v_mul_f32_e32 v18, v42, v19                                // 000000284264: 1024272A
	v_bfe_u32 v19, v14, 16, 1                                  // 000000284268: D6100013 0205210E
	s_waitcnt lgkmcnt(3)                                       // 000000284270: BF89FC37
	v_mul_f32_e32 v22, v42, v4                                 // 000000284274: 102C092A
	s_waitcnt lgkmcnt(2)                                       // 000000284278: BF89FC27
	v_mul_f32_e32 v5, v42, v5                                  // 00000028427C: 100A0B2A
	s_waitcnt lgkmcnt(1)                                       // 000000284280: BF89FC17
	v_mul_f32_e32 v24, v42, v8                                 // 000000284284: 1030112A
	v_bfe_u32 v4, v3, 16, 1                                    // 000000284288: D6100004 02052103
	v_add3_u32 v8, v14, v19, 0x7fff                            // 000000284290: D6550008 03FE270E 00007FFF
	v_bfe_u32 v14, v18, 16, 1                                  // 00000028429C: D610000E 02052112
	s_waitcnt lgkmcnt(0)                                       // 0000002842A4: BF89FC07
	v_mul_f32_e32 v9, v42, v9                                  // 0000002842A8: 1012132A
	v_bfe_u32 v19, v10, 16, 1                                  // 0000002842AC: D6100013 0205210A
	v_add3_u32 v3, v3, v4, 0x7fff                              // 0000002842B4: D6550003 03FE0903 00007FFF
	.long 0x7e283988                                           // 0000002842C0: 7E283988
	v_add3_u32 v8, v18, v14, 0x7fff                            // 0000002842C4: D6550008 03FE1D12 00007FFF
	v_bfe_u32 v14, v5, 16, 1                                   // 0000002842D0: D610000E 02052105
	v_add3_u32 v10, v10, v19, 0x7fff                           // 0000002842D8: D655000A 03FE270A 00007FFF
	v_bfe_u32 v18, v22, 16, 1                                  // 0000002842E4: D6100012 02052116
	v_and_or_b32 v4, 0xffff0000, v3, v20                       // 0000002842EC: D6570004 045206FF FFFF0000
	.long 0x7e283988                                           // 0000002842F8: 7E283988
	v_add3_u32 v5, v5, v14, 0x7fff                             // 0000002842FC: D6550005 03FE1D05 00007FFF
	v_bfe_u32 v8, v9, 16, 1                                    // 000000284308: D6100008 02052109
	v_add3_u32 v18, v22, v18, 0x7fff                           // 000000284310: D6550012 03FE2516 00007FFF
	v_bfe_u32 v14, v24, 16, 1                                  // 00000028431C: D610000E 02052118
	v_and_or_b32 v3, 0xffff0000, v10, v20                      // 000000284324: D6570003 045214FF FFFF0000
	.long 0x7e283985                                           // 000000284330: 7E283985
	v_add3_u32 v5, v9, v8, 0x7fff                              // 000000284334: D6550005 03FE1109 00007FFF
	.long 0xd73c0008                                           // 000000284340: D73C0008
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 000000284344: 02020281
	.long 0xd73c000a                                           // 000000284348: D73C000A
	v_cndmask_b32_e32 v1, 1, v11, vcc_lo                       // 00000028434C: 02021681
	v_add3_u32 v1, v24, v14, 0x7fff                            // 000000284350: D6550001 03FE1D18 00007FFF
	v_and_or_b32 v2, 0xffff0000, v18, v20                      // 00000028435C: D6570002 045224FF FFFF0000
	.long 0x7e283985                                           // 000000284368: 7E283985
	.long 0xd7006a05                                           // 00000028436C: D7006A05
	v_cndmask_b32_e32 v1, s14, v8, vcc_lo                      // 000000284370: 0202100E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000284374: BF870191
	v_add_co_ci_u32_e64 v9, null, s15, v9, vcc_lo              // 000000284378: D5207C09 01AA120F
	v_and_or_b32 v1, 0xffff0000, v1, v20                       // 000000284380: D6570001 045202FF FFFF0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000028438C: BF870093
	.long 0xd7006a08                                           // 000000284390: D7006A08
	v_cndmask_b32_e32 v1, v5, v10, vcc_lo                      // 000000284394: 02021505
	v_add_co_ci_u32_e64 v9, null, v9, v11, vcc_lo              // 000000284398: D5207C09 01AA1709
	global_store_b128 v[8:9], v[1:4], off                      // 0000002843A0: DC760000 007C0108
	s_or_b32 exec_lo, exec_lo, s1                              // 0000002843A8: 8C7E017E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002843AC: BF870009
	s_mov_b32 s1, exec_lo                                      // 0000002843B0: BE81007E
	.long 0xd4cc007e                                           // 0000002843B4: D4CC007E
	v_cndmask_b32_e32 v1, s17, v17, vcc_lo                     // 0000002843B8: 02022211
	s_cbranch_execnz 571                                       // 0000002843BC: BFA6023B <_ZN7halogen12_GLOBAL__N_114k_deq_q4cp_v8uILi8ELb0EEEvPKhPtjjllllNS0_5DeqCbE+0x2eac>
	s_or_b32 exec_lo, exec_lo, s1                              // 0000002843C0: 8C7E017E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002843C4: BF870009
	s_mov_b32 s1, exec_lo                                      // 0000002843C8: BE81007E
	.long 0xd4cc007e                                           // 0000002843CC: D4CC007E
	v_cndmask_b32_e32 v1, s17, v16, vcc_lo                     // 0000002843D0: 02022011
	s_cbranch_execz 128                                        // 0000002843D4: BFA50080 <_ZN7halogen12_GLOBAL__N_114k_deq_q4cp_v8uILi8ELb0EEEvPKhPtjjllllNS0_5DeqCbE+0x27d8>
	s_waitcnt vmcnt(1)                                         // 0000002843D8: BF8907F7
	v_lshrrev_b32_e32 v1, 22, v7                               // 0000002843DC: 32020E96
	v_lshrrev_b32_e32 v2, 26, v7                               // 0000002843E0: 32040E9A
	v_lshrrev_b32_e32 v3, 18, v7                               // 0000002843E4: 32060E92
	v_lshrrev_b32_e32 v4, 14, v7                               // 0000002843E8: 32080E8E
	v_lshrrev_b32_e32 v5, 10, v7                               // 0000002843EC: 320A0E8A
	v_and_b32_e32 v1, 60, v1                                   // 0000002843F0: 360202BC
	v_lshrrev_b32_e32 v6, 6, v7                                // 0000002843F4: 320C0E86
	v_lshrrev_b32_e32 v8, 2, v7                                // 0000002843F8: 32100E82
	v_dual_mov_b32 v11, v26 :: v_dual_and_b32 v2, 60, v2       // 0000002843FC: CA24011A 0B0204BC
	ds_load_b32 v9, v1                                         // 000000284404: D8D80000 09000001
	v_and_b32_e32 v3, 60, v3                                   // 00000028440C: 360606BC
	v_and_b32_e32 v1, 60, v4                                   // 000000284410: 360208BC
	v_and_b32_e32 v4, 60, v5                                   // 000000284414: 36080ABC
	v_and_b32_e32 v5, 60, v6                                   // 000000284418: 360A0CBC
	v_and_b32_e32 v6, 15, v7                                   // 00000028441C: 360C0E8F
	v_and_b32_e32 v7, 60, v8                                   // 000000284420: 360E10BC
	ds_load_b32 v8, v2                                         // 000000284424: D8D80000 08000002
	ds_load_b32 v10, v3                                        // 00000028442C: D8D80000 0A000003
	ds_load_b32 v14, v1                                        // 000000284434: D8D80000 0E000001
	.long 0x7f203880                                           // 00000028443C: 7F203880
	s_waitcnt lgkmcnt(3)                                       // 000000284440: BF89FC37
	v_mul_f32_e32 v9, v37, v9                                  // 000000284444: 10121325
	v_lshlrev_b32_e32 v1, 2, v6                                // 000000284448: 30020C82
	ds_load_b32 v4, v4                                         // 00000028444C: D8D80000 04000004
	ds_load_b32 v5, v5                                         // 000000284454: D8D80000 05000005
	ds_load_b32 v6, v7                                         // 00000028445C: D8D80000 06000007
	ds_load_b32 v7, v1                                         // 000000284464: D8D80000 07000001
	v_mad_u64_u32 v[1:2], null, s4, v23, 0                     // 00000028446C: D6FE7C01 02022E04
	s_delay_alu instid0(VALU_DEP_1)                            // 000000284474: BF870001
	v_mad_u64_u32 v[2:3], null, s5, v23, v[2:3]                // 000000284478: D6FE7C02 040A2E05
	s_waitcnt lgkmcnt(6)                                       // 000000284480: BF89FC67
	v_mul_f32_e32 v3, v37, v8                                  // 000000284484: 10061125
	s_waitcnt lgkmcnt(5)                                       // 000000284488: BF89FC57
	v_mul_f32_e32 v8, v37, v10                                 // 00000028448C: 10101525
	s_waitcnt lgkmcnt(4)                                       // 000000284490: BF89FC47
	v_mul_f32_e32 v10, v37, v14                                // 000000284494: 10141D25
	v_bfe_u32 v14, v9, 16, 1                                   // 000000284498: D610000E 02052109
	s_waitcnt lgkmcnt(3)                                       // 0000002844A0: BF89FC37
	v_mul_f32_e32 v17, v37, v4                                 // 0000002844A4: 10220925
	s_waitcnt lgkmcnt(2)                                       // 0000002844A8: BF89FC27
	v_mul_f32_e32 v5, v37, v5                                  // 0000002844AC: 100A0B25
	s_waitcnt lgkmcnt(1)                                       // 0000002844B0: BF89FC17
	v_mul_f32_e32 v18, v37, v6                                 // 0000002844B4: 10240D25
	v_bfe_u32 v4, v3, 16, 1                                    // 0000002844B8: D6100004 02052103
	v_add3_u32 v6, v9, v14, 0x7fff                             // 0000002844C0: D6550006 03FE1D09 00007FFF
	v_bfe_u32 v9, v10, 16, 1                                   // 0000002844CC: D6100009 0205210A
	s_waitcnt lgkmcnt(0)                                       // 0000002844D4: BF89FC07
	v_mul_f32_e32 v7, v37, v7                                  // 0000002844D8: 100E0F25
	v_bfe_u32 v14, v8, 16, 1                                   // 0000002844DC: D610000E 02052108
	v_add3_u32 v3, v3, v4, 0x7fff                              // 0000002844E4: D6550003 03FE0903 00007FFF
	.long 0x7e203986                                           // 0000002844F0: 7E203986
	v_add3_u32 v6, v10, v9, 0x7fff                             // 0000002844F4: D6550006 03FE130A 00007FFF
	v_bfe_u32 v9, v5, 16, 1                                    // 000000284500: D6100009 02052105
	v_add3_u32 v8, v8, v14, 0x7fff                             // 000000284508: D6550008 03FE1D08 00007FFF
	v_bfe_u32 v10, v17, 16, 1                                  // 000000284514: D610000A 02052111
	v_and_or_b32 v4, 0xffff0000, v3, v16                       // 00000028451C: D6570004 044206FF FFFF0000
	.long 0x7e203986                                           // 000000284528: 7E203986
	v_add3_u32 v5, v5, v9, 0x7fff                              // 00000028452C: D6550005 03FE1305 00007FFF
	v_bfe_u32 v6, v7, 16, 1                                    // 000000284538: D6100006 02052107
	v_bfe_u32 v9, v18, 16, 1                                   // 000000284540: D6100009 02052112
	v_add3_u32 v10, v17, v10, 0x7fff                           // 000000284548: D655000A 03FE1511 00007FFF
	v_and_or_b32 v3, 0xffff0000, v8, v16                       // 000000284554: D6570003 044210FF FFFF0000
	.long 0x7e203985                                           // 000000284560: 7E203985
	v_add3_u32 v14, v7, v6, 0x7fff                             // 000000284564: D655000E 03FE0D07 00007FFF
	.long 0xd73c0005                                           // 000000284570: D73C0005
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 000000284574: 02020281
	.long 0xd73c0007                                           // 000000284578: D73C0007
	v_cndmask_b32_e32 v1, 1, v11, vcc_lo                       // 00000028457C: 02021681
	v_add3_u32 v1, v18, v9, 0x7fff                             // 000000284580: D6550001 03FE1312 00007FFF
	v_and_or_b32 v2, 0xffff0000, v10, v16                      // 00000028458C: D6570002 044214FF FFFF0000
	.long 0x7e20398e                                           // 000000284598: 7E20398E
	.long 0xd7006a05                                           // 00000028459C: D7006A05
	v_cndmask_b32_e32 v1, s14, v5, vcc_lo                      // 0000002845A0: 02020A0E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002845A4: BF870191
	v_add_co_ci_u32_e64 v6, null, s15, v6, vcc_lo              // 0000002845A8: D5207C06 01AA0C0F
	v_and_or_b32 v1, 0xffff0000, v1, v16                       // 0000002845B0: D6570001 044202FF FFFF0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002845BC: BF870093
	.long 0xd7006a05                                           // 0000002845C0: D7006A05
	v_cndmask_b32_e32 v1, v5, v7, vcc_lo                       // 0000002845C4: 02020F05
	v_add_co_ci_u32_e64 v6, null, v6, v8, vcc_lo               // 0000002845C8: D5207C06 01AA1106
	global_store_b128 v[5:6], v[1:4], off                      // 0000002845D0: DC760000 007C0105
	s_or_b32 exec_lo, exec_lo, s1                              // 0000002845D8: 8C7E017E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002845DC: BF870009
	s_mov_b32 s1, exec_lo                                      // 0000002845E0: BE81007E
	.long 0xd4cc007e                                           // 0000002845E4: D4CC007E
	v_cndmask_b32_e32 v1, s17, v15, vcc_lo                     // 0000002845E8: 02021E11
	s_cbranch_execz 111                                        // 0000002845EC: BFA5006F <_ZN7halogen12_GLOBAL__N_114k_deq_q4cp_v8uILi8ELb0EEEvPKhPtjjllllNS0_5DeqCbE+0x29ac>
	s_waitcnt vmcnt(0)                                         // 0000002845F0: BF8903F7
	v_lshrrev_b32_e32 v2, 26, v35                              // 0000002845F4: 3204469A
	v_lshrrev_b32_e32 v3, 18, v35                              // 0000002845F8: 32064692
	v_lshrrev_b32_e32 v4, 14, v35                              // 0000002845FC: 3208468E
	v_lshrrev_b32_e32 v1, 22, v35                              // 000000284600: 32024696
	v_lshrrev_b32_e32 v5, 10, v35                              // 000000284604: 320A468A
	v_and_b32_e32 v2, 60, v2                                   // 000000284608: 360404BC
	v_and_b32_e32 v3, 60, v3                                   // 00000028460C: 360606BC
	v_and_b32_e32 v4, 60, v4                                   // 000000284610: 360808BC
	v_lshrrev_b32_e32 v6, 6, v35                               // 000000284614: 320C4686
	v_lshrrev_b32_e32 v7, 2, v35                               // 000000284618: 320E4682
	ds_load_b32 v2, v2                                         // 00000028461C: D8D80000 02000002
	ds_load_b32 v3, v3                                         // 000000284624: D8D80000 03000003
	ds_load_b32 v4, v4                                         // 00000028462C: D8D80000 04000004
	v_and_b32_e32 v1, 60, v1                                   // 000000284634: 360202BC
	v_and_b32_e32 v8, 15, v35                                  // 000000284638: 3610468F
	v_and_b32_e32 v5, 60, v5                                   // 00000028463C: 360A0ABC
	v_and_b32_e32 v6, 60, v6                                   // 000000284640: 360C0CBC
	v_and_b32_e32 v7, 60, v7                                   // 000000284644: 360E0EBC
	.long 0x7f1c3880                                           // 000000284648: 7F1C3880
	v_lshlrev_b32_e32 v8, 2, v8                                // 00000028464C: 30101082
	ds_load_b32 v5, v5                                         // 000000284650: D8D80000 05000005
	ds_load_b32 v6, v6                                         // 000000284658: D8D80000 06000006
	ds_load_b32 v7, v7                                         // 000000284660: D8D80000 07000007
	ds_load_b32 v8, v8                                         // 000000284668: D8D80000 08000008
	s_or_b32 s0, s0, exec_lo                                   // 000000284670: 8C007E00
	s_waitcnt lgkmcnt(6)                                       // 000000284674: BF89FC67
	v_mul_f32_e32 v2, v32, v2                                  // 000000284678: 10040520
	ds_load_b32 v1, v1                                         // 00000028467C: D8D80000 01000001
	s_waitcnt lgkmcnt(5)                                       // 000000284684: BF89FC57
	v_mul_f32_e32 v4, v32, v4                                  // 000000284688: 10080920
	v_mul_f32_e32 v3, v32, v3                                  // 00000028468C: 10060720
	v_bfe_u32 v10, v2, 16, 1                                   // 000000284690: D610000A 02052102
	s_waitcnt lgkmcnt(4)                                       // 000000284698: BF89FC47
	v_mul_f32_e32 v5, v32, v5                                  // 00000028469C: 100A0B20
	s_waitcnt lgkmcnt(3)                                       // 0000002846A0: BF89FC37
	v_mul_f32_e32 v6, v32, v6                                  // 0000002846A4: 100C0D20
	v_bfe_u32 v11, v3, 16, 1                                   // 0000002846A8: D610000B 02052103
	s_waitcnt lgkmcnt(1)                                       // 0000002846B0: BF89FC17
	v_mul_f32_e32 v8, v32, v8                                  // 0000002846B4: 10101120
	v_add3_u32 v2, v2, v10, 0x7fff                             // 0000002846B8: D6550002 03FE1502 00007FFF
	v_mul_f32_e32 v7, v32, v7                                  // 0000002846C4: 100E0F20
	v_add3_u32 v3, v3, v11, 0x7fff                             // 0000002846C8: D6550003 03FE1703 00007FFF
	s_waitcnt lgkmcnt(0)                                       // 0000002846D4: BF89FC07
	v_mul_f32_e32 v1, v32, v1                                  // 0000002846D8: 10020320
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002846DC: BF870091
	v_bfe_u32 v9, v1, 16, 1                                    // 0000002846E0: D6100009 02052101
	v_add3_u32 v1, v1, v9, 0x7fff                              // 0000002846E8: D6550001 03FE1301 00007FFF
	v_bfe_u32 v9, v4, 16, 1                                    // 0000002846F4: D6100009 02052104
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002846FC: BF870112
	.long 0x7e1c3981                                           // 000000284700: 7E1C3981
	v_add3_u32 v1, v4, v9, 0x7fff                              // 000000284704: D6550001 03FE1304 00007FFF
	v_bfe_u32 v4, v6, 16, 1                                    // 000000284710: D6100004 02052106
	v_bfe_u32 v9, v5, 16, 1                                    // 000000284718: D6100009 02052105
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000284720: BF870214
	v_and_or_b32 v11, 0xffff0000, v2, v14                      // 000000284724: D657000B 043A04FF FFFF0000
	.long 0x7e1c3981                                           // 000000284730: 7E1C3981
	s_delay_alu instid0(VALU_DEP_4)                            // 000000284734: BF870004
	v_add3_u32 v1, v6, v4, 0x7fff                              // 000000284738: D6550001 03FE0906 00007FFF
	v_bfe_u32 v2, v8, 16, 1                                    // 000000284744: D6100002 02052108
	v_bfe_u32 v4, v7, 16, 1                                    // 00000028474C: D6100004 02052107
	v_add3_u32 v5, v5, v9, 0x7fff                              // 000000284754: D6550005 03FE1305 00007FFF
	v_and_or_b32 v10, 0xffff0000, v3, v14                      // 000000284760: D657000A 043A06FF FFFF0000
	.long 0x7e1c3981                                           // 00000028476C: 7E1C3981
	v_add3_u32 v1, v8, v2, 0x7fff                              // 000000284770: D6550001 03FE0508 00007FFF
	v_add3_u32 v2, v7, v4, 0x7fff                              // 00000028477C: D6550002 03FE0907 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000284788: BF870193
	v_and_or_b32 v9, 0xffff0000, v5, v14                       // 00000028478C: D6570009 043A0AFF FFFF0000
	.long 0x7e1c3981                                           // 000000284798: 7E1C3981
	s_delay_alu instid0(VALU_DEP_1)                            // 00000028479C: BF870001
	v_and_or_b32 v8, 0xffff0000, v2, v14                       // 0000002847A0: D6570008 043A04FF FFFF0000
	s_or_b32 exec_lo, exec_lo, s1                              // 0000002847AC: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 0000002847B0: BE812000
	s_cbranch_execz 62915                                      // 0000002847B4: BFA5F5C3 <_ZN7halogen12_GLOBAL__N_114k_deq_q4cp_v8uILi8ELb0EEEvPKhPtjjllllNS0_5DeqCbE+0xc4>
	s_waitcnt vmcnt(6)                                         // 0000002847B8: BF891BF7
	v_mad_u64_u32 v[1:2], null, s4, v21, 0                     // 0000002847BC: D6FE7C01 02022A04
	v_mov_b32_e32 v14, v12                                     // 0000002847C4: 7E1C030C
	s_waitcnt vmcnt(5)                                         // 0000002847C8: BF8917F7
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002847CC: BF870122
	v_mad_u64_u32 v[2:3], null, s5, v21, v[2:3]                // 0000002847D0: D6FE7C02 040A2A05
	s_waitcnt vmcnt(4)                                         // 0000002847D8: BF8913F7
	.long 0xd73c0003                                           // 0000002847DC: D73C0003
	v_cndmask_b32_e32 v1, 1, v13, vcc_lo                       // 0000002847E0: 02021A81
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002847E4: BF870092
	.long 0xd73c0001                                           // 0000002847E8: D73C0001
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 0000002847EC: 02020281
	.long 0xd7006a01                                           // 0000002847F0: D7006A01
	v_cndmask_b32_e32 v1, s14, v1, vcc_lo                      // 0000002847F4: 0202020E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002847F8: BF870111
	v_add_co_ci_u32_e64 v2, null, s15, v2, vcc_lo              // 0000002847FC: D5207C02 01AA040F
	.long 0xd7006a01                                           // 000000284804: D7006A01
	v_cndmask_b32_e32 v1, v1, v3, vcc_lo                       // 000000284808: 02020701
	s_delay_alu instid0(VALU_DEP_1)                            // 00000028480C: BF870001
	v_add_co_ci_u32_e64 v2, null, v2, v4, vcc_lo               // 000000284810: D5207C02 01AA0902
	global_store_b128 v[1:2], v[8:11], off                     // 000000284818: DC760000 007C0801
	s_branch 62888                                             // 000000284820: BFA0F5A8 <_ZN7halogen12_GLOBAL__N_114k_deq_q4cp_v8uILi8ELb0EEEvPKhPtjjllllNS0_5DeqCbE+0xc4>
	s_or_b32 exec_lo, exec_lo, s1                              // 000000284824: 8C7E017E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000284828: BF870009
	s_mov_b32 s1, exec_lo                                      // 00000028482C: BE81007E
	.long 0xd4cc007e                                           // 000000284830: D4CC007E
	v_cndmask_b32_e32 v1, s17, v22, vcc_lo                     // 000000284834: 02022C11
	s_cbranch_execz 64970                                      // 000000284838: BFA5FDCA <_ZN7halogen12_GLOBAL__N_114k_deq_q4cp_v8uILi8ELb0EEEvPKhPtjjllllNS0_5DeqCbE+0x2164>
	s_waitcnt vmcnt(6)                                         // 00000028483C: BF891BF7
	v_lshrrev_b32_e32 v11, 10, v2                              // 000000284840: 3216048A
	v_lshrrev_b32_e32 v14, 6, v2                               // 000000284844: 321C0486
	v_lshrrev_b32_e32 v22, 2, v2                               // 000000284848: 322C0482
	v_lshrrev_b32_e32 v1, 22, v2                               // 00000028484C: 32020496
	v_lshrrev_b32_e32 v8, 26, v2                               // 000000284850: 3210049A
	v_lshrrev_b32_e32 v9, 18, v2                               // 000000284854: 32120492
	v_lshrrev_b32_e32 v10, 14, v2                              // 000000284858: 3214048E
	v_and_b32_e32 v2, 15, v2                                   // 00000028485C: 3604048F
	v_and_b32_e32 v11, 60, v11                                 // 000000284860: 361616BC
	v_and_b32_e32 v14, 60, v14                                 // 000000284864: 361C1CBC
	v_and_b32_e32 v22, 60, v22                                 // 000000284868: 362C2CBC
	v_and_b32_e32 v8, 60, v8                                   // 00000028486C: 361010BC
	v_lshlrev_b32_e32 v2, 2, v2                                // 000000284870: 30040482
	ds_load_b32 v46, v11                                       // 000000284874: D8D80000 2E00000B
	ds_load_b32 v14, v14                                       // 00000028487C: D8D80000 0E00000E
	ds_load_b32 v22, v22                                       // 000000284884: D8D80000 16000016
	ds_load_b32 v2, v2                                         // 00000028488C: D8D80000 02000002
	v_and_b32_e32 v9, 60, v9                                   // 000000284894: 361212BC
	v_dual_mov_b32 v11, v40 :: v_dual_and_b32 v10, 60, v10     // 000000284898: CA240128 0B0A14BC
	.long 0x7f623880                                           // 0000002848A0: 7F623880
	s_waitcnt lgkmcnt(2)                                       // 0000002848A4: BF89FC27
	v_mul_f32_e32 v14, v45, v14                                // 0000002848A8: 101C1D2D
	ds_load_b32 v28, v8                                        // 0000002848AC: D8D80000 1C000008
	ds_load_b32 v29, v9                                        // 0000002848B4: D8D80000 1D000009
	ds_load_b32 v38, v10                                       // 0000002848BC: D8D80000 2600000A
	v_mad_u64_u32 v[8:9], null, s4, v39, 0                     // 0000002848C4: D6FE7C08 02024E04
	s_waitcnt lgkmcnt(4)                                       // 0000002848CC: BF89FC47
	v_dual_mul_f32 v22, v45, v22 :: v_dual_and_b32 v1, 60, v1  // 0000002848D0: C8E42D2D 160002BC
	s_waitcnt lgkmcnt(3)                                       // 0000002848D8: BF89FC37
	v_mul_f32_e32 v2, v45, v2                                  // 0000002848DC: 1004052D
	s_delay_alu instid0(VALU_DEP_3)                            // 0000002848E0: BF870003
	v_mad_u64_u32 v[9:10], null, s5, v39, v[9:10]              // 0000002848E4: D6FE7C09 04264E05
	v_mul_f32_e32 v39, v45, v46                                // 0000002848EC: 104E5D2D
	s_waitcnt lgkmcnt(2)                                       // 0000002848F0: BF89FC27
	v_mul_f32_e32 v10, v45, v28                                // 0000002848F4: 1014392D
	ds_load_b32 v1, v1                                         // 0000002848F8: D8D80000 01000001
	s_waitcnt lgkmcnt(2)                                       // 000000284900: BF89FC27
	v_mul_f32_e32 v28, v45, v29                                // 000000284904: 10383B2D
	s_waitcnt lgkmcnt(1)                                       // 000000284908: BF89FC17
	v_mul_f32_e32 v29, v45, v38                                // 00000028490C: 103A4D2D
	v_bfe_u32 v40, v10, 16, 1                                  // 000000284910: D6100028 0205210A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000284918: BF870141
	v_add3_u32 v10, v10, v40, 0x7fff                           // 00000028491C: D655000A 03FE510A 00007FFF
	s_waitcnt lgkmcnt(0)                                       // 000000284928: BF89FC07
	v_mul_f32_e32 v1, v45, v1                                  // 00000028492C: 1002032D
	v_bfe_u32 v45, v28, 16, 1                                  // 000000284930: D610002D 0205211C
	v_bfe_u32 v38, v1, 16, 1                                   // 000000284938: D6100026 02052101
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000284940: BF870112
	v_add3_u32 v28, v28, v45, 0x7fff                           // 000000284944: D655001C 03FE5B1C 00007FFF
	v_add3_u32 v1, v1, v38, 0x7fff                             // 000000284950: D6550001 03FE4D01 00007FFF
	v_bfe_u32 v38, v29, 16, 1                                  // 00000028495C: D6100026 0205211D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000284964: BF870112
	.long 0x7e623981                                           // 000000284968: 7E623981
	v_add3_u32 v1, v29, v38, 0x7fff                            // 00000028496C: D6550001 03FE4D1D 00007FFF
	v_bfe_u32 v29, v14, 16, 1                                  // 000000284978: D610001D 0205210E
	v_bfe_u32 v38, v39, 16, 1                                  // 000000284980: D6100026 02052127
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000284988: BF870214
	v_and_or_b32 v48, 0xffff0000, v10, v49                     // 00000028498C: D6570030 04C614FF FFFF0000
	.long 0x7e623981                                           // 000000284998: 7E623981
	s_delay_alu instid0(VALU_DEP_4)                            // 00000028499C: BF870004
	v_add3_u32 v1, v14, v29, 0x7fff                            // 0000002849A0: D6550001 03FE3B0E 00007FFF
	v_bfe_u32 v10, v2, 16, 1                                   // 0000002849AC: D610000A 02052102
	v_bfe_u32 v14, v22, 16, 1                                  // 0000002849B4: D610000E 02052116
	v_add3_u32 v29, v39, v38, 0x7fff                           // 0000002849BC: D655001D 03FE4D27 00007FFF
	v_and_or_b32 v47, 0xffff0000, v28, v49                     // 0000002849C8: D657002F 04C638FF FFFF0000
	.long 0x7e623981                                           // 0000002849D4: 7E623981
	v_add3_u32 v10, v2, v10, 0x7fff                            // 0000002849D8: D655000A 03FE1502 00007FFF
	.long 0xd73c0001                                           // 0000002849E4: D73C0001
	v_cndmask_b32_e32 v1, 1, v8, vcc_lo                        // 0000002849E8: 02021081
	.long 0xd73c0008                                           // 0000002849EC: D73C0008
	v_cndmask_b32_e32 v1, 1, v11, vcc_lo                       // 0000002849F0: 02021681
	v_add3_u32 v11, v22, v14, 0x7fff                           // 0000002849F4: D655000B 03FE1D16 00007FFF
	v_and_or_b32 v46, 0xffff0000, v29, v49                     // 000000284A00: D657002E 04C63AFF FFFF0000
	.long 0x7e62398a                                           // 000000284A0C: 7E62398A
	.long 0xd7006a01                                           // 000000284A10: D7006A01
	v_cndmask_b32_e32 v1, s14, v1, vcc_lo                      // 000000284A14: 0202020E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000284A18: BF870191
	v_add_co_ci_u32_e64 v2, null, s15, v2, vcc_lo              // 000000284A1C: D5207C02 01AA040F
	v_and_or_b32 v45, 0xffff0000, v11, v49                     // 000000284A24: D657002D 04C616FF FFFF0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000284A30: BF870093
	.long 0xd7006a01                                           // 000000284A34: D7006A01
	v_cndmask_b32_e32 v1, v1, v8, vcc_lo                       // 000000284A38: 02021101
	v_add_co_ci_u32_e64 v2, null, v2, v9, vcc_lo               // 000000284A3C: D5207C02 01AA1302
	global_store_b128 v[1:2], v[45:48], off                    // 000000284A44: DC760000 007C2D01
	s_or_b32 exec_lo, exec_lo, s1                              // 000000284A4C: 8C7E017E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000284A50: BF870009
	s_mov_b32 s1, exec_lo                                      // 000000284A54: BE81007E
	.long 0xd4cc007e                                           // 000000284A58: D4CC007E
	v_cndmask_b32_e32 v1, s17, v20, vcc_lo                     // 000000284A5C: 02022811
	s_cbranch_execnz 64838                                     // 000000284A60: BFA6FD46 <_ZN7halogen12_GLOBAL__N_114k_deq_q4cp_v8uILi8ELb0EEEvPKhPtjjllllNS0_5DeqCbE+0x217c>
	s_or_b32 exec_lo, exec_lo, s1                              // 000000284A64: 8C7E017E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000284A68: BF870009
	s_mov_b32 s1, exec_lo                                      // 000000284A6C: BE81007E
	.long 0xd4cc007e                                           // 000000284A70: D4CC007E
	v_cndmask_b32_e32 v1, s17, v19, vcc_lo                     // 000000284A74: 02022611
	s_cbranch_execz 64965                                      // 000000284A78: BFA5FDC5 <_ZN7halogen12_GLOBAL__N_114k_deq_q4cp_v8uILi8ELb0EEEvPKhPtjjllllNS0_5DeqCbE+0x2390>
	s_waitcnt vmcnt(4)                                         // 000000284A7C: BF8913F7
	v_lshrrev_b32_e32 v1, 22, v4                               // 000000284A80: 32020896
	v_lshrrev_b32_e32 v2, 26, v4                               // 000000284A84: 3204089A
	v_lshrrev_b32_e32 v3, 18, v4                               // 000000284A88: 32060892
	v_lshrrev_b32_e32 v8, 14, v4                               // 000000284A8C: 3210088E
	v_lshrrev_b32_e32 v9, 10, v4                               // 000000284A90: 3212088A
	v_and_b32_e32 v1, 60, v1                                   // 000000284A94: 360202BC
	v_lshrrev_b32_e32 v10, 6, v4                               // 000000284A98: 32140886
	v_lshrrev_b32_e32 v11, 2, v4                               // 000000284A9C: 32160882
	v_and_b32_e32 v2, 60, v2                                   // 000000284AA0: 360404BC
	v_and_b32_e32 v3, 60, v3                                   // 000000284AA4: 360606BC
	ds_load_b32 v14, v1                                        // 000000284AA8: D8D80000 0E000001
	v_and_b32_e32 v1, 60, v8                                   // 000000284AB0: 360210BC
	v_and_b32_e32 v4, 15, v4                                   // 000000284AB4: 3608088F
	v_and_b32_e32 v8, 60, v9                                   // 000000284AB8: 361012BC
	v_and_b32_e32 v9, 60, v10                                  // 000000284ABC: 361214BC
	v_dual_mov_b32 v11, v34 :: v_dual_and_b32 v10, 60, v11     // 000000284AC0: CA240122 0B0A16BC
	ds_load_b32 v19, v2                                        // 000000284AC8: D8D80000 13000002
	ds_load_b32 v20, v3                                        // 000000284AD0: D8D80000 14000003
	ds_load_b32 v22, v1                                        // 000000284AD8: D8D80000 16000001
	v_lshlrev_b32_e32 v1, 2, v4                                // 000000284AE0: 30020882
	ds_load_b32 v4, v8                                         // 000000284AE4: D8D80000 04000008
	ds_load_b32 v8, v9                                         // 000000284AEC: D8D80000 08000009
	ds_load_b32 v9, v10                                        // 000000284AF4: D8D80000 0900000A
	ds_load_b32 v10, v1                                        // 000000284AFC: D8D80000 0A000001
	v_mad_u64_u32 v[1:2], null, s4, v27, 0                     // 000000284B04: D6FE7C01 02023604
	.long 0x7f383880                                           // 000000284B0C: 7F383880
	s_delay_alu instid0(VALU_DEP_2)                            // 000000284B10: BF870002
	v_mad_u64_u32 v[2:3], null, s5, v27, v[2:3]                // 000000284B14: D6FE7C02 040A3605
	s_waitcnt lgkmcnt(7)                                       // 000000284B1C: BF89FC77
	v_mul_f32_e32 v14, v43, v14                                // 000000284B20: 101C1D2B
	s_waitcnt lgkmcnt(6)                                       // 000000284B24: BF89FC67
	v_mul_f32_e32 v3, v43, v19                                 // 000000284B28: 1006272B
	s_waitcnt lgkmcnt(5)                                       // 000000284B2C: BF89FC57
	v_mul_f32_e32 v19, v43, v20                                // 000000284B30: 1026292B
	s_waitcnt lgkmcnt(4)                                       // 000000284B34: BF89FC47
	v_mul_f32_e32 v20, v43, v22                                // 000000284B38: 10282D2B
	v_bfe_u32 v22, v14, 16, 1                                  // 000000284B3C: D6100016 0205210E
	s_waitcnt lgkmcnt(3)                                       // 000000284B44: BF89FC37
	v_mul_f32_e32 v27, v43, v4                                 // 000000284B48: 1036092B
	s_waitcnt lgkmcnt(2)                                       // 000000284B4C: BF89FC27
	v_mul_f32_e32 v8, v43, v8                                  // 000000284B50: 1010112B
	s_waitcnt lgkmcnt(1)                                       // 000000284B54: BF89FC17
	v_mul_f32_e32 v29, v43, v9                                 // 000000284B58: 103A132B
	v_bfe_u32 v4, v3, 16, 1                                    // 000000284B5C: D6100004 02052103
	v_add3_u32 v9, v14, v22, 0x7fff                            // 000000284B64: D6550009 03FE2D0E 00007FFF
	v_bfe_u32 v14, v20, 16, 1                                  // 000000284B70: D610000E 02052114
	s_waitcnt lgkmcnt(0)                                       // 000000284B78: BF89FC07
	v_mul_f32_e32 v10, v43, v10                                // 000000284B7C: 1014152B
	v_bfe_u32 v22, v19, 16, 1                                  // 000000284B80: D6100016 02052113
	v_add3_u32 v3, v3, v4, 0x7fff                              // 000000284B88: D6550003 03FE0903 00007FFF
	.long 0x7e383989                                           // 000000284B94: 7E383989
	v_add3_u32 v9, v20, v14, 0x7fff                            // 000000284B98: D6550009 03FE1D14 00007FFF
	v_bfe_u32 v14, v8, 16, 1                                   // 000000284BA4: D610000E 02052108
	v_add3_u32 v19, v19, v22, 0x7fff                           // 000000284BAC: D6550013 03FE2D13 00007FFF
	v_bfe_u32 v20, v27, 16, 1                                  // 000000284BB8: D6100014 0205211B
	v_and_or_b32 v4, 0xffff0000, v3, v28                       // 000000284BC0: D6570004 047206FF FFFF0000
	.long 0x7e383989                                           // 000000284BCC: 7E383989
	v_add3_u32 v8, v8, v14, 0x7fff                             // 000000284BD0: D6550008 03FE1D08 00007FFF
	v_bfe_u32 v9, v10, 16, 1                                   // 000000284BDC: D6100009 0205210A
	v_bfe_u32 v14, v29, 16, 1                                  // 000000284BE4: D610000E 0205211D
	v_add3_u32 v20, v27, v20, 0x7fff                           // 000000284BEC: D6550014 03FE291B 00007FFF
	v_and_or_b32 v3, 0xffff0000, v19, v28                      // 000000284BF8: D6570003 047226FF FFFF0000
	.long 0x7e383988                                           // 000000284C04: 7E383988
	v_add3_u32 v19, v10, v9, 0x7fff                            // 000000284C08: D6550013 03FE130A 00007FFF
	.long 0xd73c0008                                           // 000000284C14: D73C0008
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 000000284C18: 02020281
	.long 0xd73c000a                                           // 000000284C1C: D73C000A
	v_cndmask_b32_e32 v1, 1, v11, vcc_lo                       // 000000284C20: 02021681
	v_add3_u32 v1, v29, v14, 0x7fff                            // 000000284C24: D6550001 03FE1D1D 00007FFF
	v_and_or_b32 v2, 0xffff0000, v20, v28                      // 000000284C30: D6570002 047228FF FFFF0000
	.long 0x7e383993                                           // 000000284C3C: 7E383993
	.long 0xd7006a08                                           // 000000284C40: D7006A08
	v_cndmask_b32_e32 v1, s14, v8, vcc_lo                      // 000000284C44: 0202100E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000284C48: BF870191
	v_add_co_ci_u32_e64 v9, null, s15, v9, vcc_lo              // 000000284C4C: D5207C09 01AA120F
	v_and_or_b32 v1, 0xffff0000, v1, v28                       // 000000284C54: D6570001 047202FF FFFF0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000284C60: BF870093
	.long 0xd7006a08                                           // 000000284C64: D7006A08
	v_cndmask_b32_e32 v1, v8, v10, vcc_lo                      // 000000284C68: 02021508
	v_add_co_ci_u32_e64 v9, null, v9, v11, vcc_lo              // 000000284C6C: D5207C09 01AA1709
	global_store_b128 v[8:9], v[1:4], off                      // 000000284C74: DC760000 007C0108
	s_or_b32 exec_lo, exec_lo, s1                              // 000000284C7C: 8C7E017E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000284C80: BF870009
	s_mov_b32 s1, exec_lo                                      // 000000284C84: BE81007E
	.long 0xd4cc007e                                           // 000000284C88: D4CC007E
	v_cndmask_b32_e32 v1, s17, v18, vcc_lo                     // 000000284C8C: 02022411
	s_cbranch_execnz 64837                                     // 000000284C90: BFA6FD45 <_ZN7halogen12_GLOBAL__N_114k_deq_q4cp_v8uILi8ELb0EEEvPKhPtjjllllNS0_5DeqCbE+0x23a8>
	s_or_b32 exec_lo, exec_lo, s1                              // 000000284C94: 8C7E017E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000284C98: BF870009
	s_mov_b32 s1, exec_lo                                      // 000000284C9C: BE81007E
	.long 0xd4cc007e                                           // 000000284CA0: D4CC007E
	v_cndmask_b32_e32 v1, s17, v17, vcc_lo                     // 000000284CA4: 02022211
	s_cbranch_execz 64965                                      // 000000284CA8: BFA5FDC5 <_ZN7halogen12_GLOBAL__N_114k_deq_q4cp_v8uILi8ELb0EEEvPKhPtjjllllNS0_5DeqCbE+0x25c0>
	s_waitcnt vmcnt(2)                                         // 000000284CAC: BF890BF7
	v_lshrrev_b32_e32 v1, 22, v6                               // 000000284CB0: 32020C96
	v_lshrrev_b32_e32 v2, 26, v6                               // 000000284CB4: 32040C9A
	v_lshrrev_b32_e32 v3, 18, v6                               // 000000284CB8: 32060C92
	v_lshrrev_b32_e32 v4, 14, v6                               // 000000284CBC: 32080C8E
	v_lshrrev_b32_e32 v5, 10, v6                               // 000000284CC0: 320A0C8A
	v_and_b32_e32 v1, 60, v1                                   // 000000284CC4: 360202BC
	v_lshrrev_b32_e32 v8, 6, v6                                // 000000284CC8: 32100C86
	v_lshrrev_b32_e32 v9, 2, v6                                // 000000284CCC: 32120C82
	v_dual_mov_b32 v11, v33 :: v_dual_and_b32 v2, 60, v2       // 000000284CD0: CA240121 0B0204BC
	v_and_b32_e32 v3, 60, v3                                   // 000000284CD8: 360606BC
	ds_load_b32 v10, v1                                        // 000000284CDC: D8D80000 0A000001
	v_and_b32_e32 v1, 60, v4                                   // 000000284CE4: 360208BC
	v_and_b32_e32 v4, 60, v5                                   // 000000284CE8: 36080ABC
	v_and_b32_e32 v5, 60, v8                                   // 000000284CEC: 360A10BC
	v_and_b32_e32 v8, 60, v9                                   // 000000284CF0: 361012BC
	ds_load_b32 v9, v2                                         // 000000284CF4: D8D80000 09000002
	ds_load_b32 v14, v3                                        // 000000284CFC: D8D80000 0E000003
	ds_load_b32 v17, v1                                        // 000000284D04: D8D80000 11000001
	v_and_b32_e32 v6, 15, v6                                   // 000000284D0C: 360C0C8F
	.long 0x7f243880                                           // 000000284D10: 7F243880
	s_delay_alu instid0(VALU_DEP_2)                            // 000000284D14: BF870002
	v_lshlrev_b32_e32 v1, 2, v6                                // 000000284D18: 30020C82
	ds_load_b32 v4, v4                                         // 000000284D1C: D8D80000 04000004
	ds_load_b32 v5, v5                                         // 000000284D24: D8D80000 05000005
	ds_load_b32 v6, v8                                         // 000000284D2C: D8D80000 06000008
	ds_load_b32 v8, v1                                         // 000000284D34: D8D80000 08000001
	v_mad_u64_u32 v[1:2], null, s4, v25, 0                     // 000000284D3C: D6FE7C01 02023204
	s_waitcnt lgkmcnt(7)                                       // 000000284D44: BF89FC77
	v_mul_f32_e32 v10, v41, v10                                // 000000284D48: 10141529
	s_delay_alu instid0(VALU_DEP_2)                            // 000000284D4C: BF870002
	v_mad_u64_u32 v[2:3], null, s5, v25, v[2:3]                // 000000284D50: D6FE7C02 040A3205
	s_waitcnt lgkmcnt(6)                                       // 000000284D58: BF89FC67
	v_mul_f32_e32 v3, v41, v9                                  // 000000284D5C: 10061329
	s_waitcnt lgkmcnt(5)                                       // 000000284D60: BF89FC57
	v_mul_f32_e32 v9, v41, v14                                 // 000000284D64: 10121D29
	s_waitcnt lgkmcnt(4)                                       // 000000284D68: BF89FC47
	v_mul_f32_e32 v14, v41, v17                                // 000000284D6C: 101C2329
	v_bfe_u32 v17, v10, 16, 1                                  // 000000284D70: D6100011 0205210A
	s_waitcnt lgkmcnt(3)                                       // 000000284D78: BF89FC37
	v_mul_f32_e32 v19, v41, v4                                 // 000000284D7C: 10260929
	s_waitcnt lgkmcnt(2)                                       // 000000284D80: BF89FC27
	v_mul_f32_e32 v5, v41, v5                                  // 000000284D84: 100A0B29
	s_waitcnt lgkmcnt(1)                                       // 000000284D88: BF89FC17
	v_mul_f32_e32 v20, v41, v6                                 // 000000284D8C: 10280D29
	v_bfe_u32 v4, v3, 16, 1                                    // 000000284D90: D6100004 02052103
	v_add3_u32 v6, v10, v17, 0x7fff                            // 000000284D98: D6550006 03FE230A 00007FFF
	v_bfe_u32 v10, v14, 16, 1                                  // 000000284DA4: D610000A 0205210E
	s_waitcnt lgkmcnt(0)                                       // 000000284DAC: BF89FC07
	v_mul_f32_e32 v8, v41, v8                                  // 000000284DB0: 10101129
	v_bfe_u32 v17, v9, 16, 1                                   // 000000284DB4: D6100011 02052109
	v_add3_u32 v3, v3, v4, 0x7fff                              // 000000284DBC: D6550003 03FE0903 00007FFF
	.long 0x7e243986                                           // 000000284DC8: 7E243986
	v_add3_u32 v6, v14, v10, 0x7fff                            // 000000284DCC: D6550006 03FE150E 00007FFF
	v_bfe_u32 v10, v5, 16, 1                                   // 000000284DD8: D610000A 02052105
	v_add3_u32 v9, v9, v17, 0x7fff                             // 000000284DE0: D6550009 03FE2309 00007FFF
	v_bfe_u32 v14, v19, 16, 1                                  // 000000284DEC: D610000E 02052113
	v_and_or_b32 v4, 0xffff0000, v3, v18                       // 000000284DF4: D6570004 044A06FF FFFF0000
	.long 0x7e243986                                           // 000000284E00: 7E243986
	v_add3_u32 v5, v5, v10, 0x7fff                             // 000000284E04: D6550005 03FE1505 00007FFF
	v_bfe_u32 v6, v8, 16, 1                                    // 000000284E10: D6100006 02052108
	v_bfe_u32 v10, v20, 16, 1                                  // 000000284E18: D610000A 02052114
	v_add3_u32 v14, v19, v14, 0x7fff                           // 000000284E20: D655000E 03FE1D13 00007FFF
	v_and_or_b32 v3, 0xffff0000, v9, v18                       // 000000284E2C: D6570003 044A12FF FFFF0000
	.long 0x7e243985                                           // 000000284E38: 7E243985
	v_add3_u32 v17, v8, v6, 0x7fff                             // 000000284E3C: D6550011 03FE0D08 00007FFF
	.long 0xd73c0005                                           // 000000284E48: D73C0005
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 000000284E4C: 02020281
	.long 0xd73c0008                                           // 000000284E50: D73C0008
	v_cndmask_b32_e32 v1, 1, v11, vcc_lo                       // 000000284E54: 02021681
	v_add3_u32 v1, v20, v10, 0x7fff                            // 000000284E58: D6550001 03FE1514 00007FFF
	v_and_or_b32 v2, 0xffff0000, v14, v18                      // 000000284E64: D6570002 044A1CFF FFFF0000
	.long 0x7e243991                                           // 000000284E70: 7E243991
	.long 0xd7006a05                                           // 000000284E74: D7006A05
	v_cndmask_b32_e32 v1, s14, v5, vcc_lo                      // 000000284E78: 02020A0E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000284E7C: BF870191
	v_add_co_ci_u32_e64 v6, null, s15, v6, vcc_lo              // 000000284E80: D5207C06 01AA0C0F
	v_and_or_b32 v1, 0xffff0000, v1, v18                       // 000000284E88: D6570001 044A02FF FFFF0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000284E94: BF870093
	.long 0xd7006a05                                           // 000000284E98: D7006A05
	v_cndmask_b32_e32 v1, v5, v8, vcc_lo                       // 000000284E9C: 02021105
	v_add_co_ci_u32_e64 v6, null, v6, v9, vcc_lo               // 000000284EA0: D5207C06 01AA1306
	global_store_b128 v[5:6], v[1:4], off                      // 000000284EA8: DC760000 007C0105
	s_or_b32 exec_lo, exec_lo, s1                              // 000000284EB0: 8C7E017E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000284EB4: BF870009
	s_mov_b32 s1, exec_lo                                      // 000000284EB8: BE81007E
	.long 0xd4cc007e                                           // 000000284EBC: D4CC007E
	v_cndmask_b32_e32 v1, s17, v16, vcc_lo                     // 000000284EC0: 02022011
	s_cbranch_execz 64964                                      // 000000284EC4: BFA5FDC4 <_ZN7halogen12_GLOBAL__N_114k_deq_q4cp_v8uILi8ELb0EEEvPKhPtjjllllNS0_5DeqCbE+0x27d8>
	s_branch 64835                                             // 000000284EC8: BFA0FD43 <_ZN7halogen12_GLOBAL__N_114k_deq_q4cp_v8uILi8ELb0EEEvPKhPtjjllllNS0_5DeqCbE+0x25d8>
	s_endpgm                                                   // 000000284ECC: BFB00000
		...

