000000000038c600 <_ZN7halogen12_GLOBAL__N_111k_hc6_fusedILi1EEEvNS0_5LqGrpEPKtliPKhS4_PtPfPyy>:
; _ZN7halogen12_GLOBAL__N_111k_hc6_fusedILi1EEEvNS0_5LqGrpEPKtliPKhS4_PtPfPyy():
	s_clause 0x2                                               // 00000038C600: BF850002
	s_load_b32 s3, s[0:1], 0x138                               // 00000038C604: F40000C0 F8000138
	s_load_b128 s[16:19], s[0:1], 0x128                        // 00000038C60C: F4080400 F8000128
	s_load_b128 s[12:15], s[0:1], 0x160                        // 00000038C614: F4080300 F8000160
	s_mov_b32 s6, -1                                           // 00000038C61C: BE8600C1
	s_waitcnt lgkmcnt(0)                                       // 00000038C620: BF89FC07
	s_cmp_ge_i32 s2, s3                                        // 00000038C624: BF030302
	s_cbranch_scc0 2555                                        // 00000038C628: BFA109FB <_ZN7halogen12_GLOBAL__N_111k_hc6_fusedILi1EEEvNS0_5LqGrpEPKtliPKhS4_PtPfPyy+0x2818>
	s_load_b256 s[4:11], s[0:1], 0x140                         // 00000038C62C: F40C0100 F8000140
	v_lshrrev_b32_e32 v1, 4, v0                                // 00000038C634: 32020084
	v_bfe_u32 v2, v0, 4, 1                                     // 00000038C638: D6100002 02050900
	v_and_b32_e32 v40, 15, v0                                  // 00000038C640: 3650008F
	s_sub_i32 s3, s2, s3                                       // 00000038C644: 81830302
	s_delay_alu instid0(VALU_DEP_3)                            // 00000038C648: BF870003
	v_and_b32_e32 v1, 14, v1                                   // 00000038C64C: 3602028E
	s_lshl_b32 s3, s3, 4                                       // 00000038C650: 84038403
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 00000038C654: BF870481
	v_or3_b32 v31, s3, v1, v2                                  // 00000038C658: D658001F 040A0203
	.long 0xd44c0003                                           // 00000038C660: D44C0003
	v_cndmask_b32_e32 v1, 10, v40, vcc_lo                      // 00000038C664: 0202508A
	s_and_saveexec_b32 s20, s3                                 // 00000038C668: BE942003
	s_cbranch_execz 99                                         // 00000038C66C: BFA50063 <_ZN7halogen12_GLOBAL__N_111k_hc6_fusedILi1EEEvNS0_5LqGrpEPKtliPKhS4_PtPfPyy+0x1fc>
	s_waitcnt lgkmcnt(0)                                       // 00000038C670: BF89FC07
	v_mad_i64_i32 v[1:2], null, 0x110, v31, s[4:5]             // 00000038C674: D6FF7C01 00123EFF 00000110
	v_lshlrev_b32_e32 v3, 1, v0                                // 00000038C680: 30060081
	v_lshlrev_b32_e32 v4, 4, v40                               // 00000038C684: 30085084
	v_lshlrev_b32_e32 v5, 3, v40                               // 00000038C688: 300A5083
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000038C68C: BF870193
	v_and_b32_e32 v7, 28, v3                                   // 00000038C690: 360E069C
	.long 0xd7006a03                                           // 00000038C694: D7006A03
	v_cndmask_b32_e32 v1, v1, v4, vcc_lo                       // 00000038C698: 02020901
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000038C69C: BF870211
	v_add_co_ci_u32_e64 v4, null, 0, v2, vcc_lo                // 00000038C6A0: D5207C04 01AA0480
	.long 0xd7006a05                                           // 00000038C6A8: D7006A05
	v_cndmask_b32_e32 v1, v1, v5, vcc_lo                       // 00000038C6AC: 02020B01
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000038C6B0: BF8700A1
	v_add_co_ci_u32_e64 v6, null, 0, v2, vcc_lo                // 00000038C6B4: D5207C06 01AA0480
	.long 0xd7006a01                                           // 00000038C6BC: D7006A01
	v_cndmask_b32_e32 v1, v1, v7, vcc_lo                       // 00000038C6C0: 02020F01
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 00000038C6C4: D5207C02 01AA0480
	.long 0xd7006a07                                           // 00000038C6CC: D7006A07
	v_cndmask_b32_e32 v1, 0xaa000, v3, vcc_lo                  // 00000038C6D0: 020206FF 000AA000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000038C6D8: BF8700A1
	v_add_co_ci_u32_e64 v8, null, 0, v4, vcc_lo                // 00000038C6DC: D5207C08 01AA0880
	.long 0xd7006a09                                           // 00000038C6E4: D7006A09
	v_cndmask_b32_e32 v1, 0xaa000, v5, vcc_lo                  // 00000038C6E8: 02020AFF 000AA000
	v_add_co_ci_u32_e64 v10, null, 0, v6, vcc_lo               // 00000038C6F0: D5207C0A 01AA0C80
	.long 0xd7006a0b                                           // 00000038C6F8: D7006A0B
	v_cndmask_b32_e32 v1, 0xaa000, v1, vcc_lo                  // 00000038C6FC: 020202FF 000AA000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000038C704: BF870001
	v_add_co_ci_u32_e64 v12, null, 0, v2, vcc_lo               // 00000038C708: D5207C0C 01AA0480
	s_clause 0x5                                               // 00000038C710: BF850005
	global_load_b128 v[27:30], v[3:4], off                     // 00000038C714: DC5E0000 1B7C0003
	global_load_b64 v[38:39], v[5:6], off offset:160           // 00000038C71C: DC5600A0 267C0005
	global_load_b32 v46, v[1:2], off offset:240                // 00000038C724: DC5200F0 2E7C0001
	global_load_b128 v[20:23], v[7:8], off                     // 00000038C72C: DC5E0000 147C0007
	global_load_b64 v[36:37], v[9:10], off offset:160          // 00000038C734: DC5600A0 247C0009
	global_load_b32 v44, v[11:12], off offset:240              // 00000038C73C: DC5200F0 2C7C000B
	.long 0xd7006a07                                           // 00000038C744: D7006A07
	v_cndmask_b32_e32 v1, 0x154000, v3, vcc_lo                 // 00000038C748: 020206FF 00154000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000038C750: BF8700A1
	v_add_co_ci_u32_e64 v8, null, 0, v4, vcc_lo                // 00000038C754: D5207C08 01AA0880
	.long 0xd7006a09                                           // 00000038C75C: D7006A09
	v_cndmask_b32_e32 v1, 0x154000, v5, vcc_lo                 // 00000038C760: 02020AFF 00154000
	v_add_co_ci_u32_e64 v10, null, 0, v6, vcc_lo               // 00000038C768: D5207C0A 01AA0C80
	.long 0xd7006a0b                                           // 00000038C770: D7006A0B
	v_cndmask_b32_e32 v1, 0x154000, v1, vcc_lo                 // 00000038C774: 020202FF 00154000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000038C77C: BF8700A1
	v_add_co_ci_u32_e64 v12, null, 0, v2, vcc_lo               // 00000038C780: D5207C0C 01AA0480
	.long 0xd7006a03                                           // 00000038C788: D7006A03
	v_cndmask_b32_e32 v1, 0x1fe000, v3, vcc_lo                 // 00000038C78C: 020206FF 001FE000
	v_add_co_ci_u32_e64 v4, null, 0, v4, vcc_lo                // 00000038C794: D5207C04 01AA0880
	.long 0xd7006a0d                                           // 00000038C79C: D7006A0D
	v_cndmask_b32_e32 v1, 0x1fe000, v5, vcc_lo                 // 00000038C7A0: 02020AFF 001FE000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000038C7A8: BF8700A1
	v_add_co_ci_u32_e64 v14, null, 0, v6, vcc_lo               // 00000038C7AC: D5207C0E 01AA0C80
	.long 0xd7006a0f                                           // 00000038C7B4: D7006A0F
	v_cndmask_b32_e32 v1, 0x1fe000, v1, vcc_lo                 // 00000038C7B8: 020202FF 001FE000
	v_add_co_ci_u32_e64 v16, null, 0, v2, vcc_lo               // 00000038C7C0: D5207C10 01AA0480
	s_clause 0x5                                               // 00000038C7C8: BF850005
	global_load_b128 v[5:8], v[7:8], off                       // 00000038C7CC: DC5E0000 057C0007
	global_load_b64 v[34:35], v[9:10], off offset:160          // 00000038C7D4: DC5600A0 227C0009
	global_load_b32 v43, v[11:12], off offset:240              // 00000038C7DC: DC5200F0 2B7C000B
	global_load_b128 v[1:4], v[3:4], off                       // 00000038C7E4: DC5E0000 017C0003
	global_load_b64 v[32:33], v[13:14], off offset:160         // 00000038C7EC: DC5600A0 207C000D
	global_load_b32 v41, v[15:16], off offset:240              // 00000038C7F4: DC5200F0 297C000F
	s_or_b32 exec_lo, exec_lo, s20                             // 00000038C7FC: 8C7E147E
	s_waitcnt lgkmcnt(0)                                       // 00000038C800: BF89FC07
	s_mov_b32 s4, exec_lo                                      // 00000038C804: BE84007E
	v_cmpx_eq_u32_e32 0, v0                                    // 00000038C808: 7D940080
	s_cbranch_execz 20                                         // 00000038C80C: BFA50014 <_ZN7halogen12_GLOBAL__N_111k_hc6_fusedILi1EEEvNS0_5LqGrpEPKtliPKhS4_PtPfPyy+0x260>
	v_mov_b32_e32 v9, 0                                        // 00000038C810: 7E120280
	global_load_b64 v[10:11], v9, s[12:13] glc                 // 00000038C814: DC564000 0A0C0009
	s_waitcnt vmcnt(0)                                         // 00000038C81C: BF8903F7
	buffer_gl1_inv                                             // 00000038C820: E0B00000 00000000
	buffer_gl0_inv                                             // 00000038C828: E0AC0000 00000000
	v_cmp_le_u64_e32 vcc_lo, s[14:15], v[10:11]                // 00000038C830: 7CB6140E
	s_cbranch_vccnz 10                                         // 00000038C834: BFA4000A <_ZN7halogen12_GLOBAL__N_111k_hc6_fusedILi1EEEvNS0_5LqGrpEPKtliPKhS4_PtPfPyy+0x260>
	s_sleep 1                                                  // 00000038C838: BF830001
	global_load_b64 v[10:11], v9, s[12:13] glc                 // 00000038C83C: DC564000 0A0C0009
	s_waitcnt vmcnt(0)                                         // 00000038C844: BF8903F7
	buffer_gl1_inv                                             // 00000038C848: E0B00000 00000000
	buffer_gl0_inv                                             // 00000038C850: E0AC0000 00000000
	v_cmp_gt_u64_e32 vcc_lo, s[14:15], v[10:11]                // 00000038C858: 7CB8140E
	s_cbranch_vccnz 65526                                      // 00000038C85C: BFA4FFF6 <_ZN7halogen12_GLOBAL__N_111k_hc6_fusedILi1EEEvNS0_5LqGrpEPKtliPKhS4_PtPfPyy+0x238>
	s_or_b32 exec_lo, exec_lo, s4                              // 00000038C860: 8C7E047E
	v_dual_mov_b32 v9, 0 :: v_dual_mov_b32 v10, 0              // 00000038C864: CA100080 090A0080
	v_dual_mov_b32 v11, 0 :: v_dual_mov_b32 v12, 0             // 00000038C86C: CA100080 0B0C0080
	s_waitcnt vmcnt(0)                                         // 00000038C874: BF8903F7
	s_barrier                                                  // 00000038C878: BFBD0000
	buffer_gl0_inv                                             // 00000038C87C: E0AC0000 00000000
	buffer_gl1_inv                                             // 00000038C884: E0B00000 00000000
	buffer_gl0_inv                                             // 00000038C88C: E0AC0000 00000000
	s_and_saveexec_b32 s4, s3                                  // 00000038C894: BE842003
	s_cbranch_execz 2061                                       // 00000038C898: BFA5080D <_ZN7halogen12_GLOBAL__N_111k_hc6_fusedILi1EEEvNS0_5LqGrpEPKtliPKhS4_PtPfPyy+0x22d0>
	v_lshlrev_b32_e32 v9, 4, v38                               // 00000038C89C: 30124C84
	v_lshlrev_b32_e32 v10, 2, v38                              // 00000038C8A0: 30144C82
	v_lshrrev_b32_e32 v11, 4, v27                              // 00000038C8A4: 32163684
	v_lshrrev_b32_e32 v12, 8, v27                              // 00000038C8A8: 32183688
	v_lshrrev_b32_e32 v13, 2, v38                              // 00000038C8AC: 321A4C82
	v_and_b32_e32 v9, 48, v9                                   // 00000038C8B0: 361212B0
	v_and_b32_e32 v10, 48, v10                                 // 00000038C8B4: 361414B0
	v_and_b32_e32 v14, 48, v38                                 // 00000038C8B8: 361C4CB0
	v_lshrrev_b32_e32 v15, 12, v27                             // 00000038C8BC: 321E368C
	v_and_b32_e32 v13, 48, v13                                 // 00000038C8C0: 361A1AB0
	v_and_or_b32 v9, v27, 15, v9                               // 00000038C8C4: D6570009 04251F1B
	v_and_or_b32 v10, v11, 15, v10                             // 00000038C8CC: D657000A 04291F0B
	v_and_or_b32 v11, v12, 15, v14                             // 00000038C8D4: D657000B 04391F0C
	.long 0x7f543880                                           // 00000038C8DC: 7F543880
	v_and_or_b32 v12, v15, 15, v13                             // 00000038C8E0: D657000C 04351F0F
	v_cvt_f32_ubyte0_e32 v9, v9                                // 00000038C8E8: 7E122309
	v_cvt_f32_ubyte0_e32 v10, v10                              // 00000038C8EC: 7E14230A
	v_cvt_f32_ubyte0_e32 v11, v11                              // 00000038C8F0: 7E16230B
	v_lshrrev_b32_e32 v16, 24, v28                             // 00000038C8F4: 32203898
	v_cvt_f32_ubyte0_e32 v12, v12                              // 00000038C8F8: 7E18230C
	v_fma_mix_f32 v9, v9, v46, v46 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038C8FC: CC206009 14BA5D09
	v_fma_mix_f32 v10, v10, v46, v46 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038C904: CC20600A 14BA5D0A
	v_fma_mix_f32 v11, v11, v46, v46 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038C90C: CC20600B 14BA5D0B
	v_lshrrev_b32_e32 v17, 26, v38                             // 00000038C914: 32224C9A
	v_fma_mix_f32 v12, v12, v46, v46 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038C918: CC20600C 14BA5D0C
	v_bfe_u32 v13, v9, 16, 1                                   // 00000038C920: D610000D 02052109
	v_bfe_u32 v14, v10, 16, 1                                  // 00000038C928: D610000E 0205210A
	v_lshlrev_b32_e32 v18, 4, v39                              // 00000038C930: 30244E84
	v_lshlrev_b32_e32 v24, 2, v39                              // 00000038C934: 30304E82
	v_bfe_u32 v15, v12, 16, 1                                  // 00000038C938: D610000F 0205210C
	v_add3_u32 v9, v9, v13, 0x7fff                             // 00000038C940: D6550009 03FE1B09 00007FFF
	v_bfe_u32 v13, v11, 16, 1                                  // 00000038C94C: D610000D 0205210B
	v_add3_u32 v10, v10, v14, 0x7fff                           // 00000038C954: D655000A 03FE1D0A 00007FFF
	v_lshrrev_b32_e32 v14, 28, v27                             // 00000038C960: 321C369C
	v_add3_u32 v12, v12, v15, 0x7fff                           // 00000038C964: D655000C 03FE1F0C 00007FFF
	.long 0x7e543989                                           // 00000038C970: 7E543989
	v_add3_u32 v9, v11, v13, 0x7fff                            // 00000038C974: D6550009 03FE1B0B 00007FFF
	v_lshrrev_b32_e32 v11, 4, v38                              // 00000038C980: 32164C84
	v_lshrrev_b32_e32 v13, 24, v27                             // 00000038C984: 321A3698
	v_lshrrev_b32_e32 v15, 10, v38                             // 00000038C988: 321E4C8A
	v_and_or_b32 v47, 0xffff0000, v10, v42                     // 00000038C98C: D657002F 04AA14FF FFFF0000
	.long 0x7e543989                                           // 00000038C998: 7E543989
	v_lshrrev_b32_e32 v9, 6, v38                               // 00000038C99C: 32124C86
	v_and_b32_e32 v10, 48, v11                                 // 00000038C9A0: 361416B0
	v_lshrrev_b32_e32 v11, 8, v38                              // 00000038C9A4: 32164C88
	v_lshrrev_b32_e32 v19, 4, v29                              // 00000038C9A8: 32263A84
	v_and_or_b32 v48, 0xffff0000, v12, v42                     // 00000038C9AC: D6570030 04AA18FF FFFF0000
	.long 0x7e54399b                                           // 00000038C9B8: 7E54399B
	v_lshrrev_b32_e32 v12, 20, v27                             // 00000038C9BC: 32183694
	v_and_b32_e32 v9, 48, v9                                   // 00000038C9C0: 361212B0
	v_and_b32_e32 v11, 48, v11                                 // 00000038C9C4: 361616B0
	v_lshrrev_b32_e32 v25, 8, v29                              // 00000038C9C8: 32323A88
	v_and_or_b32 v10, v42, 15, v10                             // 00000038C9CC: D657000A 04291F2A
	v_and_b32_e32 v27, 48, v39                                 // 00000038C9D4: 36364EB0
	v_and_or_b32 v9, v12, 15, v9                               // 00000038C9D8: D6570009 04251F0C
	v_and_or_b32 v11, v13, 15, v11                             // 00000038C9E0: D657000B 042D1F0D
	v_and_or_b32 v12, v15, 48, v14                             // 00000038C9E8: D657000C 0439610F
	v_cvt_f32_ubyte0_e32 v10, v10                              // 00000038C9F0: 7E14230A
	v_lshrrev_b32_e32 v52, 2, v39                              // 00000038C9F4: 32684E82
	v_cvt_f32_ubyte0_e32 v9, v9                                // 00000038C9F8: 7E122309
	v_cvt_f32_ubyte0_e32 v11, v11                              // 00000038C9FC: 7E16230B
	v_cvt_f32_ubyte0_e32 v12, v12                              // 00000038CA00: 7E18230C
	v_fma_mix_f32 v10, v10, v46, v46 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038CA04: CC20600A 14BA5D0A
	v_lshrrev_b32_e32 v45, 12, v29                             // 00000038CA0C: 325A3A8C
	v_fma_mix_f32 v9, v9, v46, v46 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038CA10: CC206009 14BA5D09
	v_fma_mix_f32 v11, v11, v46, v46 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038CA18: CC20600B 14BA5D0B
	v_fma_mix_f32 v12, v12, v46, v46 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038CA20: CC20600C 14BA5D0C
	v_bfe_u32 v13, v10, 16, 1                                  // 00000038CA28: D610000D 0205210A
	v_lshrrev_b32_e32 v59, 2, v36                              // 00000038CA30: 32764882
	v_bfe_u32 v14, v9, 16, 1                                   // 00000038CA34: D610000E 02052109
	v_lshrrev_b32_e32 v63, 12, v21                             // 00000038CA3C: 327E2A8C
	v_bfe_u32 v15, v12, 16, 1                                  // 00000038CA40: D610000F 0205210C
	v_add3_u32 v10, v10, v13, 0x7fff                           // 00000038CA48: D655000A 03FE1B0A 00007FFF
	v_bfe_u32 v13, v11, 16, 1                                  // 00000038CA54: D610000D 0205210B
	v_add3_u32 v9, v9, v14, 0x7fff                             // 00000038CA5C: D6550009 03FE1D09 00007FFF
	v_lshrrev_b32_e32 v14, 24, v38                             // 00000038CA68: 321C4C98
	v_lshrrev_b32_e32 v68, 12, v38                             // 00000038CA6C: 32884C8C
	.long 0x7e54398a                                           // 00000038CA70: 7E54398A
	v_add3_u32 v10, v11, v13, 0x7fff                           // 00000038CA74: D655000A 03FE1B0B 00007FFF
	v_add3_u32 v11, v12, v15, 0x7fff                           // 00000038CA80: D655000B 03FE1F0C 00007FFF
	v_lshrrev_b32_e32 v13, 12, v28                             // 00000038CA8C: 321A388C
	v_lshrrev_b32_e32 v12, 20, v38                             // 00000038CA90: 32184C94
	v_and_or_b32 v50, 0xffff0000, v9, v42                      // 00000038CA94: D6570032 04AA12FF FFFF0000
	.long 0x7e54398a                                           // 00000038CAA0: 7E54398A
	v_lshrrev_b32_e32 v9, 8, v28                               // 00000038CAA4: 32123888
	v_lshrrev_b32_e32 v10, 18, v38                             // 00000038CAA8: 32144C92
	v_lshrrev_b32_e32 v15, 22, v38                             // 00000038CAAC: 321E4C96
	v_and_b32_e32 v12, 48, v12                                 // 00000038CAB0: 361818B0
	v_and_or_b32 v49, 0xffff0000, v11, v42                     // 00000038CAB4: D6570031 04AA16FF FFFF0000
	.long 0x7e5439a6                                           // 00000038CAC0: 7E5439A6
	v_and_b32_e32 v10, 48, v10                                 // 00000038CAC4: 361414B0
	v_and_b32_e32 v15, 48, v15                                 // 00000038CAC8: 361E1EB0
	v_and_b32_e32 v14, 48, v14                                 // 00000038CACC: 361C1CB0
	v_lshrrev_b32_e32 v67, 14, v38                             // 00000038CAD0: 32864C8E
	v_and_b32_e32 v11, 48, v42                                 // 00000038CAD4: 361654B0
	v_and_or_b32 v10, v13, 15, v10                             // 00000038CAD8: D657000A 04291F0D
	v_lshrrev_b32_e32 v13, 28, v28                             // 00000038CAE0: 321A389C
	v_and_or_b32 v14, v16, 15, v14                             // 00000038CAE4: D657000E 04391F10
	v_lshrrev_b32_e32 v38, 20, v36                             // 00000038CAEC: 324C4894
	v_and_or_b32 v9, v9, 15, v11                               // 00000038CAF0: D6570009 042D1F09
	v_cvt_f32_ubyte0_e32 v10, v10                              // 00000038CAF8: 7E14230A
	v_lshrrev_b32_e32 v11, 20, v28                             // 00000038CAFC: 32163894
	v_cvt_f32_ubyte0_e32 v14, v14                              // 00000038CB00: 7E1C230E
	v_lshrrev_b32_e32 v71, 22, v36                             // 00000038CB04: 328E4896
	v_cvt_f32_ubyte0_e32 v9, v9                                // 00000038CB08: 7E122309
	v_fma_mix_f32 v10, v10, v46, v46 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038CB0C: CC20600A 14BA5D0A
	v_and_or_b32 v11, v11, 15, v15                             // 00000038CB14: D657000B 043D1F0B
	v_fma_mix_f32 v14, v14, v46, v46 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038CB1C: CC20600E 14BA5D0E
	v_lshrrev_b32_e32 v64, 24, v36                             // 00000038CB24: 32804898
	v_fma_mix_f32 v9, v9, v46, v46 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038CB28: CC206009 14BA5D09
	v_bfe_u32 v51, v10, 16, 1                                  // 00000038CB30: D6100033 0205210A
	v_cvt_f32_ubyte0_e32 v11, v11                              // 00000038CB38: 7E16230B
	v_lshrrev_b32_e32 v65, 20, v21                             // 00000038CB3C: 32822A94
	v_and_b32_e32 v71, 48, v71                                 // 00000038CB40: 368E8EB0
	v_bfe_u32 v26, v9, 16, 1                                   // 00000038CB44: D610001A 02052109
	v_add3_u32 v10, v10, v51, 0x7fff                           // 00000038CB4C: D655000A 03FE670A 00007FFF
	v_fma_mix_f32 v11, v11, v46, v46 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038CB58: CC20600B 14BA5D0B
	v_lshrrev_b32_e32 v72, 24, v21                             // 00000038CB60: 32902A98
	v_lshlrev_b32_e32 v74, 4, v37                              // 00000038CB64: 30944A84
	v_add3_u32 v9, v9, v26, 0x7fff                             // 00000038CB68: D6550009 03FE3509 00007FFF
	v_lshrrev_b32_e32 v26, 8, v20                              // 00000038CB74: 32342888
	v_and_b32_e32 v64, 48, v64                                 // 00000038CB78: 368080B0
	v_and_or_b32 v65, v65, 15, v71                             // 00000038CB7C: D6570041 051D1F41
	v_lshrrev_b32_e32 v73, 26, v36                             // 00000038CB84: 3292489A
	.long 0x7e543989                                           // 00000038CB88: 7E543989
	v_and_or_b32 v9, v17, 48, v13                              // 00000038CB8C: D6570009 04356111
	v_and_b32_e32 v13, 48, v18                                 // 00000038CB94: 361A24B0
	v_and_b32_e32 v17, 48, v24                                 // 00000038CB98: 362230B0
	v_and_or_b32 v18, v25, 15, v27                             // 00000038CB9C: D6570012 046D1F19
	v_and_or_b32 v51, 0xffff0000, v10, v42                     // 00000038CBA4: D6570033 04AA14FF FFFF0000
	.long 0x7e54399c                                           // 00000038CBB0: 7E54399C
	v_and_or_b32 v13, v29, 15, v13                             // 00000038CBB4: D657000D 04351F1D
	v_and_b32_e32 v10, 48, v52                                 // 00000038CBBC: 361468B0
	v_cvt_f32_ubyte0_e32 v9, v9                                // 00000038CBC0: 7E122309
	v_and_or_b32 v15, v19, 15, v17                             // 00000038CBC4: D657000F 04451F13
	v_and_or_b32 v12, v42, 15, v12                             // 00000038CBCC: D657000C 04311F2A
	v_cvt_f32_ubyte0_e32 v13, v13                              // 00000038CBD4: 7E1A230D
	v_and_or_b32 v10, v45, 15, v10                             // 00000038CBD8: D657000A 04291F2D
	v_cvt_f32_ubyte0_e32 v16, v18                              // 00000038CBE0: 7E202312
	v_fma_mix_f32 v9, v9, v46, v46 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038CBE4: CC206009 14BA5D09
	v_cvt_f32_ubyte0_e32 v12, v12                              // 00000038CBEC: 7E18230C
	v_cvt_f32_ubyte0_e32 v15, v15                              // 00000038CBF0: 7E1E230F
	v_fma_mix_f32 v13, v13, v46, v46 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038CBF4: CC20600D 14BA5D0D
	v_bfe_u32 v19, v11, 16, 1                                  // 00000038CBFC: D6100013 0205210B
	v_fma_mix_f32 v16, v16, v46, v46 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038CC04: CC206010 14BA5D10
	v_fma_mix_f32 v12, v12, v46, v46 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038CC0C: CC20600C 14BA5D0C
	v_cvt_f32_ubyte0_e32 v10, v10                              // 00000038CC14: 7E14230A
	v_bfe_u32 v18, v9, 16, 1                                   // 00000038CC18: D6100012 02052109
	v_fma_mix_f32 v15, v15, v46, v46 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038CC20: CC20600F 14BA5D0F
	v_add3_u32 v11, v11, v19, 0x7fff                           // 00000038CC28: D655000B 03FE270B 00007FFF
	v_bfe_u32 v17, v12, 16, 1                                  // 00000038CC34: D6100011 0205210C
	v_fma_mix_f32 v10, v10, v46, v46 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038CC3C: CC20600A 14BA5D0A
	v_add3_u32 v9, v9, v18, 0x7fff                             // 00000038CC44: D6550009 03FE2509 00007FFF
	v_lshlrev_b32_e32 v18, 4, v36                              // 00000038CC50: 30244884
	v_lshlrev_b32_e32 v25, 2, v36                              // 00000038CC54: 30324882
	v_add3_u32 v12, v12, v17, 0x7fff                           // 00000038CC58: D655000C 03FE230C 00007FFF
	v_bfe_u32 v17, v14, 16, 1                                  // 00000038CC64: D6100011 0205210E
	v_lshrrev_b32_e32 v19, 4, v20                              // 00000038CC6C: 32262884
	v_lshrrev_b32_e32 v45, 12, v20                             // 00000038CC70: 325A288C
	v_lshlrev_b32_e32 v24, 6, v40                              // 00000038CC74: 30305086
	.long 0x7e54398c                                           // 00000038CC78: 7E54398C
	v_add3_u32 v12, v14, v17, 0x7fff                           // 00000038CC7C: D655000C 03FE230E 00007FFF
	v_bfe_u32 v14, v13, 16, 1                                  // 00000038CC88: D610000E 0205210D
	v_bfe_u32 v17, v15, 16, 1                                  // 00000038CC90: D6100011 0205210F
	v_lshlrev_b32_e32 v76, 2, v37                              // 00000038CC98: 30984A82
	v_and_or_b32 v53, 0xffff0000, v11, v42                     // 00000038CC9C: D6570035 04AA16FF FFFF0000
	.long 0x7e54398c                                           // 00000038CCA8: 7E54398C
	v_add3_u32 v11, v13, v14, 0x7fff                           // 00000038CCAC: D655000B 03FE1D0D 00007FFF
	v_bfe_u32 v12, v16, 16, 1                                  // 00000038CCB8: D610000C 02052110
	v_bfe_u32 v13, v10, 16, 1                                  // 00000038CCC0: D610000D 0205210A
	v_add3_u32 v14, v15, v17, 0x7fff                           // 00000038CCC8: D655000E 03FE230F 00007FFF
	v_and_or_b32 v54, 0xffff0000, v9, v42                      // 00000038CCD4: D6570036 04AA12FF FFFF0000
	.long 0x7e54398b                                           // 00000038CCE0: 7E54398B
	v_add3_u32 v9, v16, v12, 0x7fff                            // 00000038CCE4: D6550009 03FE1910 00007FFF
	v_lshrrev_b32_e32 v11, 4, v39                              // 00000038CCF0: 32164E84
	v_add3_u32 v10, v10, v13, 0x7fff                           // 00000038CCF4: D655000A 03FE1B0A 00007FFF
	v_lshrrev_b32_e32 v12, 20, v29                             // 00000038CD00: 32183A94
	v_and_or_b32 v55, 0xffff0000, v14, v42                     // 00000038CD04: D6570037 04AA1CFF FFFF0000
	.long 0x7e543989                                           // 00000038CD10: 7E543989
	v_lshrrev_b32_e32 v9, 6, v39                               // 00000038CD14: 32124E86
	v_and_b32_e32 v11, 48, v11                                 // 00000038CD18: 361616B0
	v_lshrrev_b32_e32 v13, 24, v29                             // 00000038CD1C: 321A3A98
	v_lshrrev_b32_e32 v14, 28, v29                             // 00000038CD20: 321C3A9C
	v_and_or_b32 v56, 0xffff0000, v10, v42                     // 00000038CD24: D6570038 04AA14FF FFFF0000
	.long 0x7e54399d                                           // 00000038CD30: 7E54399D
	v_lshrrev_b32_e32 v10, 8, v39                              // 00000038CD34: 32144E88
	v_and_b32_e32 v9, 48, v9                                   // 00000038CD38: 361212B0
	v_lshrrev_b32_e32 v15, 10, v39                             // 00000038CD3C: 321E4E8A
	v_lshrrev_b32_e32 v16, 24, v30                             // 00000038CD40: 32203C98
	v_and_or_b32 v11, v42, 15, v11                             // 00000038CD44: D657000B 042D1F2A
	v_and_b32_e32 v10, 48, v10                                 // 00000038CD4C: 361414B0
	v_and_or_b32 v9, v12, 15, v9                               // 00000038CD50: D6570009 04251F0C
	v_and_or_b32 v12, v15, 48, v14                             // 00000038CD58: D657000C 0439610F
	v_lshrrev_b32_e32 v17, 26, v39                             // 00000038CD60: 32224E9A
	v_cvt_f32_ubyte0_e32 v11, v11                              // 00000038CD64: 7E16230B
	v_and_or_b32 v10, v13, 15, v10                             // 00000038CD68: D657000A 04291F0D
	v_cvt_f32_ubyte0_e32 v9, v9                                // 00000038CD70: 7E122309
	v_cvt_f32_ubyte0_e32 v12, v12                              // 00000038CD74: 7E18230C
	v_and_b32_e32 v29, 48, v36                                 // 00000038CD78: 363A48B0
	v_fma_mix_f32 v11, v11, v46, v46 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038CD7C: CC20600B 14BA5D0B
	v_cvt_f32_ubyte0_e32 v10, v10                              // 00000038CD84: 7E14230A
	v_fma_mix_f32 v9, v9, v46, v46 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038CD88: CC206009 14BA5D09
	v_fma_mix_f32 v12, v12, v46, v46 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038CD90: CC20600C 14BA5D0C
	v_lshrrev_b32_e32 v81, 2, v37                              // 00000038CD98: 32A24A82
	v_bfe_u32 v13, v11, 16, 1                                  // 00000038CD9C: D610000D 0205210B
	v_fma_mix_f32 v10, v10, v46, v46 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038CDA4: CC20600A 14BA5D0A
	v_bfe_u32 v14, v9, 16, 1                                   // 00000038CDAC: D610000E 02052109
	v_bfe_u32 v15, v12, 16, 1                                  // 00000038CDB4: D610000F 0205210C
	v_and_or_b32 v64, v72, 15, v64                             // 00000038CDBC: D6570040 05011F48
	v_add3_u32 v11, v11, v13, 0x7fff                           // 00000038CDC4: D655000B 03FE1B0B 00007FFF
	v_bfe_u32 v13, v10, 16, 1                                  // 00000038CDD0: D610000D 0205210A
	v_add3_u32 v9, v9, v14, 0x7fff                             // 00000038CDD8: D6550009 03FE1D09 00007FFF
	v_lshrrev_b32_e32 v14, 24, v39                             // 00000038CDE4: 321C4E98
	v_lshrrev_b32_e32 v75, 4, v22                              // 00000038CDE8: 32962C84
	.long 0x7e54398b                                           // 00000038CDEC: 7E54398B
	v_add3_u32 v10, v10, v13, 0x7fff                           // 00000038CDF0: D655000A 03FE1B0A 00007FFF
	v_add3_u32 v11, v12, v15, 0x7fff                           // 00000038CDFC: D655000B 03FE1F0C 00007FFF
	v_lshrrev_b32_e32 v13, 12, v30                             // 00000038CE08: 321A3C8C
	v_lshrrev_b32_e32 v12, 20, v39                             // 00000038CE0C: 32184E94
	v_and_or_b32 v58, 0xffff0000, v9, v42                      // 00000038CE10: D657003A 04AA12FF FFFF0000
	.long 0x7e54398a                                           // 00000038CE1C: 7E54398A
	v_lshrrev_b32_e32 v9, 8, v30                               // 00000038CE20: 32123C88
	v_lshrrev_b32_e32 v10, 18, v39                             // 00000038CE24: 32144E92
	v_lshrrev_b32_e32 v15, 22, v39                             // 00000038CE28: 321E4E96
	v_and_b32_e32 v12, 48, v12                                 // 00000038CE2C: 361818B0
	v_and_or_b32 v57, 0xffff0000, v11, v42                     // 00000038CE30: D6570039 04AA16FF FFFF0000
	.long 0x7e5439a7                                           // 00000038CE3C: 7E5439A7
	v_and_b32_e32 v10, 48, v10                                 // 00000038CE40: 361414B0
	v_and_b32_e32 v15, 48, v15                                 // 00000038CE44: 361E1EB0
	v_and_b32_e32 v14, 48, v14                                 // 00000038CE48: 361C1CB0
	v_lshrrev_b32_e32 v77, 8, v22                              // 00000038CE4C: 329A2C88
	v_and_b32_e32 v11, 48, v42                                 // 00000038CE50: 361654B0
	v_and_or_b32 v10, v13, 15, v10                             // 00000038CE54: D657000A 04291F0D
	v_lshrrev_b32_e32 v13, 28, v30                             // 00000038CE5C: 321A3C9C
	v_and_or_b32 v14, v16, 15, v14                             // 00000038CE60: D657000E 04391F10
	v_and_b32_e32 v79, 48, v37                                 // 00000038CE68: 369E4AB0
	v_and_or_b32 v9, v9, 15, v11                               // 00000038CE6C: D6570009 042D1F09
	v_cvt_f32_ubyte0_e32 v10, v10                              // 00000038CE74: 7E14230A
	v_lshrrev_b32_e32 v11, 20, v30                             // 00000038CE78: 32163C94
	v_cvt_f32_ubyte0_e32 v14, v14                              // 00000038CE7C: 7E1C230E
	v_lshrrev_b32_e32 v80, 12, v22                             // 00000038CE80: 32A02C8C
	v_cvt_f32_ubyte0_e32 v9, v9                                // 00000038CE84: 7E122309
	v_fma_mix_f32 v10, v10, v46, v46 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038CE88: CC20600A 14BA5D0A
	v_and_or_b32 v11, v11, 15, v15                             // 00000038CE90: D657000B 043D1F0B
	v_fma_mix_f32 v14, v14, v46, v46 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038CE98: CC20600E 14BA5D0E
	v_cvt_f32_ubyte0_e32 v65, v65                              // 00000038CEA0: 7E822341
	v_fma_mix_f32 v9, v9, v46, v46 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038CEA4: CC206009 14BA5D09
	v_bfe_u32 v52, v10, 16, 1                                  // 00000038CEAC: D6100034 0205210A
	v_cvt_f32_ubyte0_e32 v11, v11                              // 00000038CEB4: 7E16230B
	v_cvt_f32_ubyte0_e32 v64, v64                              // 00000038CEB8: 7E802340
	v_fma_mix_f32 v65, v65, v44, v44 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038CEBC: CC206041 14B25941
	v_bfe_u32 v27, v9, 16, 1                                   // 00000038CEC4: D610001B 02052109
	v_add3_u32 v10, v10, v52, 0x7fff                           // 00000038CECC: D655000A 03FE690A 00007FFF
	v_fma_mix_f32 v11, v11, v46, v46 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038CED8: CC20600B 14BA5D0B
	v_fma_mix_f32 v64, v64, v44, v44 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038CEE0: CC206040 14B25940
	v_lshrrev_b32_e32 v86, 28, v23                             // 00000038CEE8: 32AC2E9C
	v_add3_u32 v9, v9, v27, 0x7fff                             // 00000038CEEC: D6550009 03FE3709 00007FFF
	v_lshrrev_b32_e32 v87, 26, v37                             // 00000038CEF8: 32AE4A9A
	v_lshrrev_b32_e32 v88, 8, v5                               // 00000038CEFC: 32B00A88
	v_and_b32_e32 v89, 48, v34                                 // 00000038CF00: 36B244B0
	v_and_b32_e32 v68, 48, v68                                 // 00000038CF04: 368888B0
	.long 0x7e543989                                           // 00000038CF08: 7E543989
	v_and_or_b32 v9, v17, 48, v13                              // 00000038CF0C: D6570009 04356111
	v_and_b32_e32 v13, 48, v18                                 // 00000038CF14: 361A24B0
	v_and_b32_e32 v17, 48, v25                                 // 00000038CF18: 362232B0
	v_and_or_b32 v18, v26, 15, v29                             // 00000038CF1C: D6570012 04751F1A
	v_and_or_b32 v52, 0xffff0000, v10, v42                     // 00000038CF24: D6570034 04AA14FF FFFF0000
	.long 0x7e54399e                                           // 00000038CF30: 7E54399E
	v_and_b32_e32 v10, 48, v59                                 // 00000038CF34: 361476B0
	v_and_or_b32 v13, v20, 15, v13                             // 00000038CF38: D657000D 04351F14
	v_cvt_f32_ubyte0_e32 v9, v9                                // 00000038CF40: 7E122309
	v_and_or_b32 v15, v19, 15, v17                             // 00000038CF44: D657000F 04451F13
	v_and_or_b32 v12, v42, 15, v12                             // 00000038CF4C: D657000C 04311F2A
	v_and_or_b32 v10, v45, 15, v10                             // 00000038CF54: D657000A 04291F2D
	v_cvt_f32_ubyte0_e32 v13, v13                              // 00000038CF5C: 7E1A230D
	v_cvt_f32_ubyte0_e32 v16, v18                              // 00000038CF60: 7E202312
	v_fma_mix_f32 v9, v9, v46, v46 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038CF64: CC206009 14BA5D09
	v_cvt_f32_ubyte0_e32 v12, v12                              // 00000038CF6C: 7E18230C
	v_cvt_f32_ubyte0_e32 v15, v15                              // 00000038CF70: 7E1E230F
	v_cvt_f32_ubyte0_e32 v10, v10                              // 00000038CF74: 7E14230A
	v_fma_mix_f32 v13, v13, v44, v44 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038CF78: CC20600D 14B2590D
	v_bfe_u32 v19, v11, 16, 1                                  // 00000038CF80: D6100013 0205210B
	v_fma_mix_f32 v12, v12, v46, v46 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038CF88: CC20600C 14BA5D0C
	v_fma_mix_f32 v16, v16, v44, v44 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038CF90: CC206010 14B25910
	v_bfe_u32 v18, v9, 16, 1                                   // 00000038CF98: D6100012 02052109
	v_fma_mix_f32 v15, v15, v44, v44 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038CFA0: CC20600F 14B2590F
	v_fma_mix_f32 v25, v10, v44, v44 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038CFA8: CC206019 14B2590A
	v_bfe_u32 v17, v12, 16, 1                                  // 00000038CFB0: D6100011 0205210C
	v_add3_u32 v10, v11, v19, 0x7fff                           // 00000038CFB8: D655000A 03FE270B 00007FFF
	v_add3_u32 v9, v9, v18, 0x7fff                             // 00000038CFC4: D6550009 03FE2509 00007FFF
	v_lshrrev_b32_e32 v18, 28, v20                             // 00000038CFD0: 3224289C
	v_lshrrev_b32_e32 v19, 10, v36                             // 00000038CFD4: 3226488A
	v_add3_u32 v12, v12, v17, 0x7fff                           // 00000038CFD8: D655000C 03FE230C 00007FFF
	v_bfe_u32 v17, v14, 16, 1                                  // 00000038CFE4: D6100011 0205210E
	v_and_or_b32 v86, v87, 48, v86                             // 00000038CFEC: D6570056 05596157
	v_and_or_b32 v88, v88, 15, v89                             // 00000038CFF4: D6570058 05651F58
	v_and_or_b32 v18, v19, 48, v18                             // 00000038CFFC: D6570012 04496113
	.long 0x7e54398c                                           // 00000038D004: 7E54398C
	v_add3_u32 v11, v14, v17, 0x7fff                           // 00000038D008: D655000B 03FE230E 00007FFF
	v_bfe_u32 v12, v13, 16, 1                                  // 00000038D014: D610000C 0205210D
	v_bfe_u32 v14, v15, 16, 1                                  // 00000038D01C: D610000E 0205210F
	v_lshrrev_b32_e32 v17, 24, v20                             // 00000038D024: 32222898
	v_and_or_b32 v29, 0xffff0000, v10, v42                     // 00000038D028: D657001D 04AA14FF FFFF0000
	.long 0x7e54398b                                           // 00000038D034: 7E54398B
	v_add3_u32 v10, v13, v12, 0x7fff                           // 00000038D038: D655000A 03FE190D 00007FFF
	v_bfe_u32 v11, v16, 16, 1                                  // 00000038D044: D610000B 02052110
	v_bfe_u32 v13, v25, 16, 1                                  // 00000038D04C: D610000D 02052119
	v_add3_u32 v14, v15, v14, 0x7fff                           // 00000038D054: D655000E 03FE1D0F 00007FFF
	v_and_or_b32 v45, 0xffff0000, v9, v42                      // 00000038D060: D657002D 04AA12FF FFFF0000
	.long 0x7e54398a                                           // 00000038D06C: 7E54398A
	v_add3_u32 v15, v16, v11, 0x7fff                           // 00000038D070: D655000F 03FE1710 00007FFF
	global_load_b128 v[9:12], v24, s[6:7]                      // 00000038D07C: DC5E0000 09060018
	v_lshrrev_b32_e32 v16, 4, v36                              // 00000038D084: 32204884
	v_add3_u32 v13, v25, v13, 0x7fff                           // 00000038D088: D655000D 03FE1B19 00007FFF
	v_and_or_b32 v60, 0xffff0000, v14, v42                     // 00000038D094: D657003C 04AA1CFF FFFF0000
	.long 0x7e54398f                                           // 00000038D0A0: 7E54398F
	v_lshrrev_b32_e32 v14, 6, v36                              // 00000038D0A4: 321C4886
	v_and_b32_e32 v15, 48, v16                                 // 00000038D0A8: 361E20B0
	v_lshrrev_b32_e32 v16, 20, v20                             // 00000038D0AC: 32202894
	v_cvt_f32_ubyte0_e32 v18, v18                              // 00000038D0B0: 7E242312
	v_and_or_b32 v59, 0xffff0000, v13, v42                     // 00000038D0B4: D657003B 04AA1AFF FFFF0000
	.long 0x7e543994                                           // 00000038D0C0: 7E543994
	v_lshrrev_b32_e32 v13, 8, v36                              // 00000038D0C4: 321A4888
	v_and_b32_e32 v14, 48, v14                                 // 00000038D0C8: 361C1CB0
	v_fma_mix_f32 v26, v18, v44, v44 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038D0CC: CC20601A 14B25912
	v_lshrrev_b32_e32 v66, 4, v28                              // 00000038D0D4: 32843884
	v_and_or_b32 v15, v42, 15, v15                             // 00000038D0D8: D657000F 043D1F2A
	v_and_b32_e32 v13, 48, v13                                 // 00000038D0E0: 361A1AB0
	v_and_or_b32 v20, v16, 15, v14                             // 00000038D0E4: D6570014 04391F10
	v_bfe_u32 v27, v26, 16, 1                                  // 00000038D0EC: D610001B 0205211A
	v_lshrrev_b32_e32 v83, 22, v37                             // 00000038D0F4: 32A64A96
	v_cvt_f32_ubyte0_e32 v25, v15                              // 00000038D0F8: 7E32230F
	v_and_or_b32 v17, v17, 15, v13                             // 00000038D0FC: D6570011 04351F11
	global_load_b128 v[13:16], v24, s[6:7] offset:16           // 00000038D104: DC5E0010 0D060018
	v_cvt_f32_ubyte0_e32 v19, v20                              // 00000038D10C: 7E262314
	v_add3_u32 v26, v26, v27, 0x7fff                           // 00000038D110: D655001A 03FE371A 00007FFF
	v_fma_mix_f32 v20, v25, v44, v44 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038D11C: CC206014 14B25919
	v_cvt_f32_ubyte0_e32 v17, v17                              // 00000038D124: 7E222311
	v_lshrrev_b32_e32 v84, 24, v23                             // 00000038D128: 32A82E98
	v_fma_mix_f32 v19, v19, v44, v44 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038D12C: CC206013 14B25913
	v_and_or_b32 v68, v28, 15, v68                             // 00000038D134: D6570044 05111F1C
	v_bfe_u32 v25, v20, 16, 1                                  // 00000038D13C: D6100019 02052114
	v_fma_mix_f32 v17, v17, v44, v44 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038D144: CC206011 14B25911
	v_lshlrev_b32_e32 v28, 2, v34                              // 00000038D14C: 30384482
	v_bfe_u32 v18, v19, 16, 1                                  // 00000038D150: D6100012 02052113
	v_lshrrev_b32_e32 v90, 28, v5                              // 00000038D158: 32B40A9C
	v_add3_u32 v20, v20, v25, 0x7fff                           // 00000038D15C: D6550014 03FE3314 00007FFF
	v_bfe_u32 v25, v17, 16, 1                                  // 00000038D168: D6100019 02052111
	v_and_b32_e32 v83, 48, v83                                 // 00000038D170: 36A6A6B0
	v_add3_u32 v61, v19, v18, 0x7fff                           // 00000038D174: D655003D 03FE2513 00007FFF
	v_and_b32_e32 v28, 48, v28                                 // 00000038D180: 363838B0
	.long 0x7e543994                                           // 00000038D184: 7E543994
	v_add3_u32 v25, v17, v25, 0x7fff                           // 00000038D188: D6550019 03FE3311 00007FFF
	global_load_b128 v[17:20], v24, s[6:7] offset:32           // 00000038D194: DC5E0020 11060018
	v_cvt_f32_ubyte0_e32 v88, v88                              // 00000038D19C: 7EB02358
	v_and_b32_e32 v67, 48, v67                                 // 00000038D1A0: 368686B0
	v_and_or_b32 v62, 0xffff0000, v61, v42                     // 00000038D1A4: D657003E 04AA7AFF FFFF0000
	.long 0x7e543999                                           // 00000038D1B0: 7E543999
	v_lshrrev_b32_e32 v25, 8, v21                              // 00000038D1B4: 32322A88
	v_fma_mix_f32 v88, v88, v43, v43 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038D1B8: CC206058 14AE5758
	v_and_or_b32 v66, v66, 15, v67                             // 00000038D1C0: D6570042 050D1F42
	v_cvt_f32_ubyte0_e32 v68, v68                              // 00000038D1C8: 7E882344
	v_and_or_b32 v61, 0xffff0000, v26, v42                     // 00000038D1CC: D657003D 04AA34FF FFFF0000
	.long 0x7e5439a4                                           // 00000038D1D8: 7E5439A4
	v_lshrrev_b32_e32 v26, 18, v36                             // 00000038D1DC: 32344892
	v_cvt_f32_ubyte0_e32 v66, v66                              // 00000038D1E0: 7E842342
	v_fma_mix_f32 v68, v68, v46, v46 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038D1E4: CC206044 14BA5D44
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000038D1EC: BF870214
	v_and_b32_e32 v27, 48, v42                                 // 00000038D1F0: 363654B0
	v_and_b32_e32 v69, 48, v26                                 // 00000038D1F4: 368A34B0
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000038D1F8: BF870194
	v_fma_mix_f32 v66, v66, v46, v46 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038D1FC: CC206042 14BA5D42
	v_and_or_b32 v70, v25, 15, v27                             // 00000038D204: D6570046 046D1F19
	global_load_b128 v[24:27], v24, s[6:7] offset:48           // 00000038D20C: DC5E0030 18060018
	v_and_or_b32 v63, v63, 15, v69                             // 00000038D214: D657003F 05151F3F
	v_cvt_f32_ubyte0_e32 v69, v70                              // 00000038D21C: 7E8A2346
	v_lshrrev_b32_e32 v70, 28, v21                             // 00000038D220: 328C2A9C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000038D224: BF870193
	v_cvt_f32_ubyte0_e32 v63, v63                              // 00000038D228: 7E7E233F
	v_fma_mix_f32 v69, v69, v44, v44 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038D22C: CC206045 14B25945
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000038D234: BF870112
	v_fma_mix_f32 v63, v63, v44, v44 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038D238: CC20603F 14B2593F
	v_bfe_u32 v78, v69, 16, 1                                  // 00000038D240: D610004E 02052145
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000038D248: BF870112
	v_bfe_u32 v82, v63, 16, 1                                  // 00000038D24C: D6100052 0205213F
	v_add3_u32 v69, v69, v78, 0x7fff                           // 00000038D254: D6550045 03FE9D45 00007FFF
	v_and_b32_e32 v78, 48, v38                                 // 00000038D260: 369C4CB0
	s_delay_alu instid0(VALU_DEP_3)                            // 00000038D264: BF870003
	v_add3_u32 v38, v63, v82, 0x7fff                           // 00000038D268: D6550026 03FEA53F 00007FFF
	v_and_or_b32 v63, v73, 48, v70                             // 00000038D274: D657003F 05196149
	v_and_b32_e32 v70, 48, v76                                 // 00000038D27C: 368C98B0
	.long 0x7e5439c5                                           // 00000038D280: 7E5439C5
	v_and_b32_e32 v69, 48, v74                                 // 00000038D284: 368A94B0
	v_and_b32_e32 v74, 48, v81                                 // 00000038D288: 3694A2B0
	v_and_or_b32 v73, v77, 15, v79                             // 00000038D28C: D6570049 053D1F4D
	v_cvt_f32_ubyte0_e32 v63, v63                              // 00000038D294: 7E7E233F
	v_and_or_b32 v38, 0xffff0000, v38, v42                     // 00000038D298: D6570026 04AA4CFF FFFF0000
	.long 0x7e543995                                           // 00000038D2A4: 7E543995
	v_and_or_b32 v69, v22, 15, v69                             // 00000038D2A8: D6570045 05151F16
	v_and_or_b32 v70, v75, 15, v70                             // 00000038D2B0: D6570046 05191F4B
	v_and_or_b32 v72, v80, 15, v74                             // 00000038D2B8: D6570048 05291F50
	v_cvt_f32_ubyte0_e32 v73, v73                              // 00000038D2C0: 7E922349
	v_and_or_b32 v71, v42, 15, v78                             // 00000038D2C4: D6570047 05391F2A
	v_cvt_f32_ubyte0_e32 v69, v69                              // 00000038D2CC: 7E8A2345
	v_fma_mix_f32 v63, v63, v44, v44 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038D2D0: CC20603F 14B2593F
	v_cvt_f32_ubyte0_e32 v70, v70                              // 00000038D2D8: 7E8C2346
	v_bfe_u32 v76, v65, 16, 1                                  // 00000038D2DC: D610004C 02052141
	v_cvt_f32_ubyte0_e32 v71, v71                              // 00000038D2E4: 7E8E2347
	v_fma_mix_f32 v69, v69, v44, v44 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038D2E8: CC206045 14B25945
	v_fma_mix_f32 v73, v73, v44, v44 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038D2F0: CC206049 14B25949
	v_cvt_f32_ubyte0_e32 v72, v72                              // 00000038D2F8: 7E902348
	v_bfe_u32 v75, v63, 16, 1                                  // 00000038D2FC: D610004B 0205213F
	v_fma_mix_f32 v71, v71, v44, v44 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038D304: CC206047 14B25947
	v_fma_mix_f32 v70, v70, v44, v44 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038D30C: CC206046 14B25946
	v_add3_u32 v65, v65, v76, 0x7fff                           // 00000038D314: D6550041 03FE9941 00007FFF
	v_fma_mix_f32 v72, v72, v44, v44 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038D320: CC206048 14B25948
	v_lshrrev_b32_e32 v76, 24, v22                             // 00000038D328: 32982C98
	v_bfe_u32 v74, v71, 16, 1                                  // 00000038D32C: D610004A 02052147
	v_lshrrev_b32_e32 v77, 10, v37                             // 00000038D334: 329A4A8A
	v_lshrrev_b32_e32 v79, 14, v36                             // 00000038D338: 329E488E
	v_lshrrev_b32_e32 v81, 18, v37                             // 00000038D33C: 32A24A92
	v_lshrrev_b32_e32 v80, 12, v23                             // 00000038D340: 32A02E8C
	v_add3_u32 v71, v71, v74, 0x7fff                           // 00000038D344: D6550047 03FE9547 00007FFF
	v_bfe_u32 v74, v64, 16, 1                                  // 00000038D350: D610004A 02052140
	v_lshrrev_b32_e32 v82, 20, v23                             // 00000038D358: 32A42E94
	v_and_b32_e32 v81, 48, v81                                 // 00000038D35C: 36A2A2B0
	v_and_b32_e32 v79, 48, v79                                 // 00000038D360: 369E9EB0
	.long 0x7e5439c7                                           // 00000038D364: 7E5439C7
	v_add3_u32 v64, v64, v74, 0x7fff                           // 00000038D368: D6550040 03FE9540 00007FFF
	v_bfe_u32 v71, v69, 16, 1                                  // 00000038D374: D6100047 02052145
	v_add3_u32 v74, v63, v75, 0x7fff                           // 00000038D37C: D655004A 03FE973F 00007FFF
	v_bfe_u32 v75, v70, 16, 1                                  // 00000038D388: D610004B 02052146
	v_and_or_b32 v63, 0xffff0000, v65, v42                     // 00000038D390: D657003F 04AA82FF FFFF0000
	.long 0x7e5439c0                                           // 00000038D39C: 7E5439C0
	v_add3_u32 v65, v69, v71, 0x7fff                           // 00000038D3A0: D6550041 03FE8F45 00007FFF
	v_bfe_u32 v69, v73, 16, 1                                  // 00000038D3AC: D6100045 02052149
	v_bfe_u32 v71, v72, 16, 1                                  // 00000038D3B4: D6100047 02052148
	v_add3_u32 v70, v70, v75, 0x7fff                           // 00000038D3BC: D6550046 03FE9746 00007FFF
	v_and_or_b32 v64, 0xffff0000, v74, v42                     // 00000038D3C8: D6570040 04AA94FF FFFF0000
	.long 0x7e5439c1                                           // 00000038D3D4: 7E5439C1
	v_add3_u32 v69, v73, v69, 0x7fff                           // 00000038D3D8: D6550045 03FE8B49 00007FFF
	v_lshrrev_b32_e32 v74, 4, v37                              // 00000038D3E4: 32944A84
	v_add3_u32 v71, v72, v71, 0x7fff                           // 00000038D3E8: D6550047 03FE8F48 00007FFF
	v_lshrrev_b32_e32 v72, 6, v37                              // 00000038D3F4: 32904A86
	v_and_or_b32 v65, 0xffff0000, v70, v42                     // 00000038D3F8: D6570041 04AA8CFF FFFF0000
	.long 0x7e5439c5                                           // 00000038D404: 7E5439C5
	v_and_b32_e32 v69, 15, v30                                 // 00000038D408: 368A3C8F
	v_lshrrev_b32_e32 v70, 4, v30                              // 00000038D40C: 328C3C84
	v_and_b32_e32 v74, 48, v74                                 // 00000038D410: 369494B0
	v_lshrrev_b32_e32 v75, 20, v22                             // 00000038D414: 32962C94
	v_and_or_b32 v30, 0xffff0000, v71, v42                     // 00000038D418: D657001E 04AA8EFF FFFF0000
	.long 0x7e543996                                           // 00000038D424: 7E543996
	v_lshrrev_b32_e32 v71, 8, v37                              // 00000038D428: 328E4A88
	v_and_b32_e32 v72, 48, v72                                 // 00000038D42C: 369090B0
	v_lshrrev_b32_e32 v22, 28, v22                             // 00000038D430: 322C2C9C
	v_lshrrev_b32_e32 v73, 12, v39                             // 00000038D434: 32924E8C
	v_and_or_b32 v74, v42, 15, v74                             // 00000038D438: D657004A 05291F2A
	v_and_b32_e32 v71, 48, v71                                 // 00000038D440: 368E8EB0
	v_and_or_b32 v72, v75, 15, v72                             // 00000038D444: D6570048 05211F4B
	v_lshrrev_b32_e32 v75, 14, v39                             // 00000038D44C: 32964E8E
	v_and_or_b32 v22, v77, 48, v22                             // 00000038D450: D6570016 0459614D
	v_cvt_f32_ubyte0_e32 v74, v74                              // 00000038D458: 7E94234A
	v_and_or_b32 v71, v76, 15, v71                             // 00000038D45C: D6570047 051D1F4C
	v_cvt_f32_ubyte0_e32 v39, v72                              // 00000038D464: 7E4E2348
	v_and_or_b32 v80, v80, 15, v81                             // 00000038D468: D6570050 05451F50
	v_cvt_f32_ubyte0_e32 v22, v22                              // 00000038D470: 7E2C2316
	v_fma_mix_f32 v72, v74, v44, v44 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038D474: CC206048 14B2594A
	v_cvt_f32_ubyte0_e32 v71, v71                              // 00000038D47C: 7E8E2347
	v_fma_mix_f32 v39, v39, v44, v44 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038D480: CC206027 14B25927
	v_lshrrev_b32_e32 v74, 12, v36                             // 00000038D488: 3294488C
	v_fma_mix_f32 v22, v22, v44, v44 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038D48C: CC206016 14B25916
	v_bfe_u32 v76, v72, 16, 1                                  // 00000038D494: D610004C 02052148
	v_fma_mix_f32 v71, v71, v44, v44 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038D49C: CC206047 14B25947
	v_bfe_u32 v78, v39, 16, 1                                  // 00000038D4A4: D610004E 02052127
	v_cvt_f32_ubyte0_e32 v80, v80                              // 00000038D4AC: 7EA02350
	v_bfe_u32 v36, v22, 16, 1                                  // 00000038D4B0: D6100024 02052116
	v_add3_u32 v72, v72, v76, 0x7fff                           // 00000038D4B8: D6550048 03FE9948 00007FFF
	v_bfe_u32 v76, v71, 16, 1                                  // 00000038D4C4: D610004C 02052147
	v_add3_u32 v39, v39, v78, 0x7fff                           // 00000038D4CC: D6550027 03FE9D27 00007FFF
	v_and_or_b32 v69, v73, 48, v69                             // 00000038D4D8: D6570045 05156149
	v_add3_u32 v22, v22, v36, 0x7fff                           // 00000038D4E0: D6550016 03FE4916 00007FFF
	.long 0x7e5439c8                                           // 00000038D4EC: 7E5439C8
	v_add3_u32 v71, v71, v76, 0x7fff                           // 00000038D4F0: D6550047 03FE9947 00007FFF
	v_fma_mix_f32 v73, v80, v44, v44 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038D4FC: CC206049 14B25950
	v_lshrrev_b32_e32 v78, 20, v37                             // 00000038D504: 329C4A94
	v_lshrrev_b32_e32 v81, 4, v5                               // 00000038D508: 32A20A84
	v_and_or_b32 v36, 0xffff0000, v39, v42                     // 00000038D50C: D6570024 04AA4EFF FFFF0000
	.long 0x7e5439c7                                           // 00000038D518: 7E5439C7
	v_lshrrev_b32_e32 v71, 8, v23                              // 00000038D51C: 328E2E88
	v_bfe_u32 v89, v73, 16, 1                                  // 00000038D520: D6100059 02052149
	v_and_b32_e32 v78, 48, v78                                 // 00000038D528: 369C9CB0
	v_lshrrev_b32_e32 v80, 10, v34                             // 00000038D52C: 32A0448A
	v_and_or_b32 v39, 0xffff0000, v22, v42                     // 00000038D530: D6570027 04AA2CFF FFFF0000
	.long 0x7e5439a5                                           // 00000038D53C: 7E5439A5
	v_lshrrev_b32_e32 v22, 24, v37                             // 00000038D540: 322C4A98
	v_add3_u32 v73, v73, v89, 0x7fff                           // 00000038D544: D6550049 03FEB349 00007FFF
	v_and_or_b32 v80, v80, 48, v90                             // 00000038D550: D6570050 05696150
	v_lshrrev_b32_e32 v90, 12, v5                              // 00000038D558: 32B40A8C
	v_and_b32_e32 v85, 48, v42                                 // 00000038D55C: 36AA54B0
	v_and_b32_e32 v22, 48, v22                                 // 00000038D560: 362C2CB0
	v_and_or_b32 v82, v82, 15, v83                             // 00000038D564: D6570052 054D1F52
	v_and_or_b32 v28, v81, 15, v28                             // 00000038D56C: D657001C 04711F51
	v_lshrrev_b32_e32 v83, 20, v5                              // 00000038D574: 32A60A94
	v_and_or_b32 v71, v71, 15, v85                             // 00000038D578: D6570047 05551F47
	v_and_or_b32 v22, v84, 15, v22                             // 00000038D580: D6570016 04591F54
	v_cvt_f32_ubyte0_e32 v84, v86                              // 00000038D588: 7EA82356
	v_lshlrev_b32_e32 v85, 4, v34                              // 00000038D58C: 30AA4484
	v_cvt_f32_ubyte0_e32 v82, v82                              // 00000038D590: 7EA42352
	v_cvt_f32_ubyte0_e32 v71, v71                              // 00000038D594: 7E8E2347
	v_cvt_f32_ubyte0_e32 v22, v22                              // 00000038D598: 7E2C2316
	v_fma_mix_f32 v81, v84, v44, v44 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038D59C: CC206051 14B25954
	v_and_b32_e32 v85, 48, v85                                 // 00000038D5A4: 36AAAAB0
	v_fma_mix_f32 v82, v82, v44, v44 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038D5A8: CC206052 14B25952
	v_fma_mix_f32 v71, v71, v44, v44 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038D5B0: CC206047 14B25947
	v_fma_mix_f32 v22, v22, v44, v44 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038D5B8: CC206016 14B25916
	v_cvt_f32_ubyte0_e32 v28, v28                              // 00000038D5C0: 7E38231C
	v_and_or_b32 v85, v5, 15, v85                              // 00000038D5C4: D6570055 05551F05
	v_lshrrev_b32_e32 v86, 6, v34                              // 00000038D5CC: 32AC4486
	v_bfe_u32 v87, v71, 16, 1                                  // 00000038D5D0: D6100057 02052147
	v_lshrrev_b32_e32 v89, 8, v34                              // 00000038D5D8: 32B24488
	v_fma_mix_f32 v28, v28, v43, v43 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038D5DC: CC20601C 14AE571C
	v_cvt_f32_ubyte0_e32 v85, v85                              // 00000038D5E4: 7EAA2355
	v_and_b32_e32 v86, 48, v86                                 // 00000038D5E8: 36ACACB0
	v_add3_u32 v71, v71, v87, 0x7fff                           // 00000038D5EC: D6550047 03FEAF47 00007FFF
	v_lshrrev_b32_e32 v87, 2, v34                              // 00000038D5F8: 32AE4482
	v_lshrrev_b32_e32 v84, 24, v5                              // 00000038D5FC: 32A80A98
	v_fma_mix_f32 v85, v85, v43, v43 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038D600: CC206055 14AE5755
	v_and_or_b32 v67, v83, 15, v86                             // 00000038D608: D6570043 05591F53
	.long 0x7e5439c7                                           // 00000038D610: 7E5439C7
	v_and_b32_e32 v87, 48, v87                                 // 00000038D614: 36AEAEB0
	v_lshrrev_b32_e32 v71, 4, v34                              // 00000038D618: 328E4484
	v_bfe_u32 v91, v85, 16, 1                                  // 00000038D61C: D610005B 02052155
	v_and_b32_e32 v89, 48, v89                                 // 00000038D624: 36B2B2B0
	v_and_or_b32 v73, 0xffff0000, v73, v42                     // 00000038D628: D6570049 04AA92FF FFFF0000
	.long 0x7e543997                                           // 00000038D634: 7E543997
	v_and_or_b32 v87, v90, 15, v87                             // 00000038D638: D6570057 055D1F5A
	v_bfe_u32 v90, v81, 16, 1                                  // 00000038D640: D610005A 02052151
	v_add3_u32 v85, v85, v91, 0x7fff                           // 00000038D648: D6550055 03FEB755 00007FFF
	v_and_b32_e32 v71, 48, v71                                 // 00000038D654: 368E8EB0
	v_and_or_b32 v78, v42, 15, v78                             // 00000038D658: D657004E 05391F2A
	v_cvt_f32_ubyte0_e32 v87, v87                              // 00000038D660: 7EAE2357
	v_add3_u32 v81, v81, v90, 0x7fff                           // 00000038D664: D6550051 03FEB551 00007FFF
	v_cvt_f32_ubyte0_e32 v67, v67                              // 00000038D670: 7E862343
	v_and_b32_e32 v75, 48, v75                                 // 00000038D674: 369696B0
	v_cvt_f32_ubyte0_e32 v78, v78                              // 00000038D678: 7E9C234E
	v_fma_mix_f32 v87, v87, v43, v43 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038D67C: CC206057 14AE5757
	v_and_b32_e32 v74, 48, v74                                 // 00000038D684: 369494B0
	v_fma_mix_f32 v67, v67, v43, v43 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038D688: CC206043 14AE5743
	v_and_or_b32 v70, v70, 15, v75                             // 00000038D690: D6570046 052D1F46
	v_fma_mix_f32 v78, v78, v44, v44 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038D698: CC20604E 14B2594E
	v_cvt_f32_ubyte0_e32 v69, v69                              // 00000038D6A0: 7E8A2345
	v_lshrrev_b32_e32 v77, 4, v21                              // 00000038D6A4: 329A2A84
	v_bfe_u32 v86, v67, 16, 1                                  // 00000038D6A8: D6100056 02052143
	v_and_or_b32 v21, v21, 15, v74                             // 00000038D6B0: D6570015 05291F15
	v_bfe_u32 v90, v78, 16, 1                                  // 00000038D6B8: D610005A 0205214E
	v_lshrrev_b32_e32 v91, 20, v34                             // 00000038D6C0: 32B64494
	v_lshrrev_b32_e32 v72, 12, v37                             // 00000038D6C4: 32904A8C
	v_add3_u32 v67, v67, v86, 0x7fff                           // 00000038D6C8: D6550043 03FEAD43 00007FFF
	v_cvt_f32_ubyte0_e32 v21, v21                              // 00000038D6D4: 7E2A2315
	v_add3_u32 v78, v78, v90, 0x7fff                           // 00000038D6D8: D655004E 03FEB54E 00007FFF
	v_bfe_u32 v90, v82, 16, 1                                  // 00000038D6E4: D610005A 02052152
	v_lshrrev_b32_e32 v86, 20, v6                              // 00000038D6EC: 32AC0C94
	v_and_b32_e32 v76, 15, v23                                 // 00000038D6F0: 36982E8F
	v_fma_mix_f32 v21, v21, v44, v44 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038D6F4: CC206015 14B25915
	.long 0x7e5439ce                                           // 00000038D6FC: 7E5439CE
	v_add3_u32 v82, v82, v90, 0x7fff                           // 00000038D700: D6550052 03FEB552 00007FFF
	v_bfe_u32 v90, v22, 16, 1                                  // 00000038D70C: D610005A 02052116
	v_bfe_u32 v78, v88, 16, 1                                  // 00000038D714: D610004E 02052158
	v_lshrrev_b32_e32 v37, 14, v37                             // 00000038D71C: 324A4A8E
	v_lshrrev_b32_e32 v23, 4, v23                              // 00000038D720: 322E2E84
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000038D724: BF870214
	v_add3_u32 v90, v22, v90, 0x7fff                           // 00000038D728: D655005A 03FEB516 00007FFF
	v_add3_u32 v78, v88, v78, 0x7fff                           // 00000038D734: D655004E 03FE9D58 00007FFF
	v_bfe_u32 v88, v28, 16, 1                                  // 00000038D740: D6100058 0205211C
	v_and_or_b32 v22, 0xffff0000, v82, v42                     // 00000038D748: D6570016 04AAA4FF FFFF0000
	v_lshrrev_b32_e32 v82, 8, v6                               // 00000038D754: 32A40C88
	.long 0x7e5439da                                           // 00000038D758: 7E5439DA
	v_bfe_u32 v90, v87, 16, 1                                  // 00000038D75C: D610005A 02052157
	v_add3_u32 v88, v28, v88, 0x7fff                           // 00000038D764: D6550058 03FEB11C 00007FFF
	v_and_b32_e32 v37, 48, v37                                 // 00000038D770: 364A4AB0
	s_delay_alu instid0(VALU_DEP_4)                            // 00000038D774: BF870004
	v_and_or_b32 v28, 0xffff0000, v81, v42                     // 00000038D778: D657001C 04AAA2FF FFFF0000
	.long 0x7e5439d5                                           // 00000038D784: 7E5439D5
	v_add3_u32 v85, v87, v90, 0x7fff                           // 00000038D788: D6550055 03FEB557 00007FFF
	v_lshrrev_b32_e32 v87, 18, v34                             // 00000038D794: 32AE4492
	v_lshrrev_b32_e32 v81, 12, v6                              // 00000038D798: 32A20C8C
	v_and_or_b32 v23, v23, 15, v37                             // 00000038D79C: D6570017 04951F17
	v_and_or_b32 v88, 0xffff0000, v88, v42                     // 00000038D7A4: D6570058 04AAB0FF FFFF0000
	.long 0x7e5439ce                                           // 00000038D7B0: 7E5439CE
	v_lshrrev_b32_e32 v78, 24, v34                             // 00000038D7B4: 329C4498
	.long 0x7f4a39aa                                           // 00000038D7B8: 7F4A39AA
	v_cvt_f32_ubyte0_e32 v23, v23                              // 00000038D7BC: 7E2E2317
	s_delay_alu instid0(VALU_DEP_4)                            // 00000038D7C0: BF870004
	v_and_or_b32 v83, 0xffff0000, v85, v42                     // 00000038D7C4: D6570053 04AAAAFF FFFF0000
	.long 0x7e543985                                           // 00000038D7D0: 7E543985
	v_cvt_f32_ubyte0_e32 v5, v80                               // 00000038D7D4: 7E0A2350
	v_and_or_b32 v80, v84, 15, v89                             // 00000038D7D8: D6570050 05651F54
	v_bfe_u32 v85, v68, 16, 1                                  // 00000038D7E0: D6100055 02052144
	v_fma_mix_f32 v23, v23, v44, v44 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038D7E8: CC206017 14B25917
	v_and_or_b32 v71, v42, 15, v71                             // 00000038D7F0: D6570047 051D1F2A
	v_fma_mix_f32 v5, v5, v43, v43 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038D7F8: CC206005 14AE5705
	v_cvt_f32_ubyte0_e32 v80, v80                              // 00000038D800: 7EA02350
	v_add3_u32 v68, v68, v85, 0x7fff                           // 00000038D804: D6550044 03FEAB44 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000038D810: BF870214
	v_cvt_f32_ubyte0_e32 v71, v71                              // 00000038D814: 7E8E2347
	v_bfe_u32 v84, v5, 16, 1                                   // 00000038D818: D6100054 02052105
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000038D820: BF870194
	v_fma_mix_f32 v80, v80, v43, v43 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038D824: CC206050 14AE5750
	v_fma_mix_f32 v71, v71, v43, v43 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038D82C: CC206047 14AE5747
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000038D834: BF870193
	v_add3_u32 v5, v5, v84, 0x7fff                             // 00000038D838: D6550005 03FEA905 00007FFF
	v_bfe_u32 v84, v80, 16, 1                                  // 00000038D844: D6100054 02052150
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000038D84C: BF870113
	v_bfe_u32 v85, v71, 16, 1                                  // 00000038D850: D6100055 02052147
	v_add3_u32 v80, v80, v84, 0x7fff                           // 00000038D858: D6550050 03FEA950 00007FFF
	v_lshrrev_b32_e32 v84, 22, v34                             // 00000038D864: 32A84496
	s_delay_alu instid0(VALU_DEP_3)                            // 00000038D868: BF870003
	v_add3_u32 v71, v71, v85, 0x7fff                           // 00000038D86C: D6550047 03FEAB47 00007FFF
	.long 0x7faa39aa                                           // 00000038D878: 7FAA39AA
	.long 0x7eaa39c4                                           // 00000038D87C: 7EAA39C4
	v_and_b32_e32 v68, 48, v91                                 // 00000038D880: 3688B6B0
	s_waitcnt vmcnt(3)                                         // 00000038D884: BF890FF7
	v_dot2_f32_bf16 v47, v9, v47, 0                            // 00000038D888: CC1A402F 1A025F09
	.long 0x7e5439c7                                           // 00000038D890: 7E5439C7
	.long 0x7f8e39aa                                           // 00000038D894: 7F8E39AA
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000038D898: BF870223
	v_dot2_f32_bf16 v47, v10, v48, v47                         // 00000038D89C: CC1A402F 1CBE610A
	v_bfe_u32 v48, v66, 16, 1                                  // 00000038D8A4: D6100030 02052142
	v_and_or_b32 v67, 0xffff0000, v67, v42                     // 00000038D8AC: D6570043 04AA86FF FFFF0000
	.long 0x7e5439d0                                           // 00000038D8B8: 7E5439D0
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000038D8BC: BF870214
	v_dot2_f32_bf16 v47, v11, v50, v47                         // 00000038D8C0: CC1A402F 1CBE650B
	v_add3_u32 v48, v66, v48, 0x7fff                           // 00000038D8C8: D6550030 03FE6142 00007FFF
	v_and_b32_e32 v66, 48, v87                                 // 00000038D8D4: 3684AEB0
	s_delay_alu instid0(VALU_DEP_4)                            // 00000038D8D8: BF870004
	v_and_or_b32 v50, 0xffff0000, v5, v42                      // 00000038D8DC: D6570032 04AA0AFF FFFF0000
	.long 0x7e5439a2                                           // 00000038D8E8: 7E5439A2
	v_dot2_f32_bf16 v47, v12, v49, v47                         // 00000038D8EC: CC1A402F 1CBE630C
	v_and_or_b32 v48, 0xffff0000, v48, v85                     // 00000038D8F4: D6570030 055660FF FFFF0000
	v_and_or_b32 v66, v81, 15, v66                             // 00000038D900: D6570042 05091F51
	.long 0x7f0a39aa                                           // 00000038D908: 7F0A39AA
	v_and_b32_e32 v49, 48, v42                                 // 00000038D90C: 366254B0
	s_waitcnt vmcnt(2)                                         // 00000038D910: BF890BF7
	v_dot2_f32_bf16 v47, v13, v48, v47                         // 00000038D914: CC1A402F 1CBE610D
	v_cvt_f32_ubyte0_e32 v66, v66                              // 00000038D91C: 7E842342
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000038D920: BF870223
	v_and_or_b32 v48, v82, 15, v49                             // 00000038D924: D6570030 04C51F52
	v_and_or_b32 v49, v77, 15, v79                             // 00000038D92C: D6570031 053D1F4D
	v_dot2_f32_bf16 v47, v14, v51, v47                         // 00000038D934: CC1A402F 1CBE670E
	v_fma_mix_f32 v51, v69, v46, v46 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038D93C: CC206033 14BA5D45
	s_delay_alu instid0(VALU_DEP_4)                            // 00000038D944: BF870004
	v_cvt_f32_ubyte0_e32 v48, v48                              // 00000038D948: 7E602330
	v_cvt_f32_ubyte0_e32 v69, v70                              // 00000038D94C: 7E8A2346
	v_fma_mix_f32 v66, v66, v43, v43 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038D950: CC206042 14AE5742
	v_dot2_f32_bf16 v47, v15, v53, v47                         // 00000038D958: CC1A402F 1CBE6B0F
	v_bfe_u32 v53, v51, 16, 1                                  // 00000038D960: D6100035 02052133
	v_fma_mix_f32 v48, v48, v43, v43 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038D968: CC206030 14AE5730
	v_fma_mix_f32 v46, v69, v46, v46 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038D970: CC20602E 14BA5D45
	v_bfe_u32 v69, v66, 16, 1                                  // 00000038D978: D6100045 02052142
	v_dot2_f32_bf16 v47, v16, v54, v47                         // 00000038D980: CC1A402F 1CBE6D10
	v_add3_u32 v51, v51, v53, 0x7fff                           // 00000038D988: D6550033 03FE6B33 00007FFF
	v_bfe_u32 v54, v48, 16, 1                                  // 00000038D994: D6100036 02052130
	v_bfe_u32 v53, v46, 16, 1                                  // 00000038D99C: D6100035 0205212E
	v_cvt_f32_ubyte0_e32 v49, v49                              // 00000038D9A4: 7E622331
	s_waitcnt vmcnt(1)                                         // 00000038D9A8: BF8907F7
	v_dot2_f32_bf16 v47, v17, v55, v47                         // 00000038D9AC: CC1A402F 1CBE6F11
	.long 0x7e8e39b3                                           // 00000038D9B4: 7E8E39B3
	v_add3_u32 v48, v48, v54, 0x7fff                           // 00000038D9B8: D6550030 03FE6D30 00007FFF
	v_add3_u32 v54, v66, v69, 0x7fff                           // 00000038D9C4: D6550036 03FE8B42 00007FFF
	v_add3_u32 v46, v46, v53, 0x7fff                           // 00000038D9D0: D655002E 03FE6B2E 00007FFF
	v_dot2_f32_bf16 v47, v18, v56, v47                         // 00000038D9DC: CC1A402F 1CBE7112
	v_and_b32_e32 v53, 48, v84                                 // 00000038D9E4: 366AA8B0
	.long 0x7e5439b0                                           // 00000038D9E8: 7E5439B0
	v_bfe_u32 v48, v21, 16, 1                                  // 00000038D9EC: D6100030 02052115
	v_and_or_b32 v46, 0xffff0000, v46, v71                     // 00000038D9F4: D657002E 051E5CFF FFFF0000
	v_dot2_f32_bf16 v47, v19, v58, v47                         // 00000038DA00: CC1A402F 1CBE7513
	v_fma_mix_f32 v49, v49, v44, v44 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038DA08: CC206031 14B25931
	v_and_or_b32 v51, 0xffff0000, v54, v42                     // 00000038DA10: D6570033 04AA6CFF FFFF0000
	.long 0x7e543986                                           // 00000038DA1C: 7E543986
	v_add3_u32 v21, v21, v48, 0x7fff                           // 00000038DA20: D6550015 03FE6115 00007FFF
	v_dot2_f32_bf16 v47, v20, v57, v47                         // 00000038DA2C: CC1A402F 1CBE7314
	v_bfe_u32 v54, v49, 16, 1                                  // 00000038DA34: D6100036 02052131
	v_and_or_b32 v53, v86, 15, v53                             // 00000038DA3C: D6570035 04D51F56
	v_and_or_b32 v48, v42, 15, v68                             // 00000038DA44: D6570030 05111F2A
	.long 0x7e0a3995                                           // 00000038DA4C: 7E0A3995
	v_lshlrev_b32_e32 v56, 4, v35                              // 00000038DA50: 30704684
	s_waitcnt vmcnt(0)                                         // 00000038DA54: BF8903F7
	v_dot2_f32_bf16 v21, v24, v46, v47                         // 00000038DA58: CC1A4015 1CBE5D18
	v_lshrrev_b32_e32 v47, 24, v6                              // 00000038DA60: 325E0C98
	v_cvt_f32_ubyte0_e32 v46, v48                              // 00000038DA64: 7E5C2330
	v_and_b32_e32 v48, 48, v78                                 // 00000038DA68: 36609CB0
	v_lshrrev_b32_e32 v57, 26, v34                             // 00000038DA6C: 3272449A
	v_and_b32_e32 v58, 48, v35                                 // 00000038DA70: 367446B0
	v_lshrrev_b32_e32 v66, 2, v35                              // 00000038DA74: 32844682
	v_fma_mix_f32 v46, v46, v43, v43 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038DA78: CC20602E 14AE572E
	v_and_or_b32 v47, v47, 15, v48                             // 00000038DA80: D657002F 04C11F2F
	v_add3_u32 v48, v49, v54, 0x7fff                           // 00000038DA88: D6550030 03FE6D31 00007FFF
	v_cvt_f32_ubyte0_e32 v49, v53                              // 00000038DA94: 7E622335
	v_and_or_b32 v55, v72, 48, v76                             // 00000038DA98: D6570037 05316148
	v_bfe_u32 v54, v46, 16, 1                                  // 00000038DAA0: D6100036 0205212E
	v_cvt_f32_ubyte0_e32 v47, v47                              // 00000038DAA8: 7E5E232F
	v_and_or_b32 v5, 0xffff0000, v48, v5                       // 00000038DAAC: D6570005 041660FF FFFF0000
	v_fma_mix_f32 v49, v49, v43, v43 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038DAB8: CC206031 14AE5731
	v_cvt_f32_ubyte0_e32 v53, v55                              // 00000038DAC0: 7E6A2337
	v_add3_u32 v46, v46, v54, 0x7fff                           // 00000038DAC4: D655002E 03FE6D2E 00007FFF
	v_fma_mix_f32 v47, v47, v43, v43 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038DAD0: CC20602F 14AE572F
	v_lshrrev_b32_e32 v48, 4, v35                              // 00000038DAD8: 32604684
	v_bfe_u32 v54, v49, 16, 1                                  // 00000038DADC: D6100036 02052131
	v_fma_mix_f32 v53, v53, v44, v44 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038DAE4: CC206035 14B25935
	.long 0x7e5439ae                                           // 00000038DAEC: 7E5439AE
	v_bfe_u32 v46, v47, 16, 1                                  // 00000038DAF0: D610002E 0205212F
	v_and_b32_e32 v48, 48, v48                                 // 00000038DAF8: 366060B0
	v_add3_u32 v49, v49, v54, 0x7fff                           // 00000038DAFC: D6550031 03FE6D31 00007FFF
	v_lshrrev_b32_e32 v54, 28, v6                              // 00000038DB08: 326C0C9C
	v_bfe_u32 v55, v53, 16, 1                                  // 00000038DB0C: D6100037 02052135
	v_add3_u32 v46, v47, v46, 0x7fff                           // 00000038DB14: D655002E 03FE5D2F 00007FFF
	v_and_b32_e32 v47, 48, v56                                 // 00000038DB20: 365E70B0
	v_lshlrev_b32_e32 v56, 2, v35                              // 00000038DB24: 30704682
	v_and_or_b32 v49, 0xffff0000, v49, v42                     // 00000038DB28: D6570031 04AA62FF FFFF0000
	v_and_or_b32 v54, v57, 48, v54                             // 00000038DB34: D6570036 04D96139
	.long 0x7e5439ae                                           // 00000038DB3C: 7E5439AE
	v_and_or_b32 v46, v7, 15, v47                              // 00000038DB40: D657002E 04BD1F07
	v_lshrrev_b32_e32 v47, 4, v7                               // 00000038DB48: 325E0E84
	v_and_b32_e32 v56, 48, v56                                 // 00000038DB4C: 367070B0
	v_lshrrev_b32_e32 v57, 8, v7                               // 00000038DB50: 32720E88
	v_cvt_f32_ubyte0_e32 v54, v54                              // 00000038DB54: 7E6C2336
	v_cvt_f32_ubyte0_e32 v46, v46                              // 00000038DB58: 7E5C232E
	v_add3_u32 v53, v53, v55, 0x7fff                           // 00000038DB5C: D6550035 03FE6F35 00007FFF
	v_and_or_b32 v47, v47, 15, v56                             // 00000038DB68: D657002F 04E11F2F
	v_and_or_b32 v56, v57, 15, v58                             // 00000038DB70: D6570038 04E91F39
	v_lshrrev_b32_e32 v57, 12, v7                              // 00000038DB78: 32720E8C
	v_and_b32_e32 v58, 48, v66                                 // 00000038DB7C: 367484B0
	v_fma_mix_f32 v54, v54, v43, v43 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038DB80: CC206036 14AE5736
	v_fma_mix_f32 v46, v46, v43, v43 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038DB88: CC20602E 14AE572E
	v_cvt_f32_ubyte0_e32 v47, v47                              // 00000038DB90: 7E5E232F
	v_cvt_f32_ubyte0_e32 v56, v56                              // 00000038DB94: 7E702338
	v_and_or_b32 v57, v57, 15, v58                             // 00000038DB98: D6570039 04E91F39
	v_bfe_u32 v58, v54, 16, 1                                  // 00000038DBA0: D610003A 02052136
	v_bfe_u32 v66, v46, 16, 1                                  // 00000038DBA8: D6100042 0205212E
	v_fma_mix_f32 v47, v47, v43, v43 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038DBB0: CC20602F 14AE572F
	v_fma_mix_f32 v56, v56, v43, v43 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038DBB8: CC206038 14AE5738
	v_cvt_f32_ubyte0_e32 v57, v57                              // 00000038DBC0: 7E722339
	v_add3_u32 v54, v54, v58, 0x7fff                           // 00000038DBC4: D6550036 03FE7536 00007FFF
	v_add3_u32 v46, v46, v66, 0x7fff                           // 00000038DBD0: D655002E 03FE852E 00007FFF
	v_bfe_u32 v58, v47, 16, 1                                  // 00000038DBDC: D610003A 0205212F
	v_bfe_u32 v66, v56, 16, 1                                  // 00000038DBE4: D6100042 02052138
	v_fma_mix_f32 v57, v57, v43, v43 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038DBEC: CC206039 14AE5739
	v_and_or_b32 v54, 0xffff0000, v54, v42                     // 00000038DBF4: D6570036 04AA6CFF FFFF0000
	.long 0x7e5439ae                                           // 00000038DC00: 7E5439AE
	v_add3_u32 v46, v47, v58, 0x7fff                           // 00000038DC04: D655002E 03FE752F 00007FFF
	v_add3_u32 v47, v56, v66, 0x7fff                           // 00000038DC10: D655002F 03FE8538 00007FFF
	v_bfe_u32 v56, v57, 16, 1                                  // 00000038DC1C: D6100038 02052139
	.long 0x7e4a39b5                                           // 00000038DC24: 7E4A39B5
	v_lshrrev_b32_e32 v53, 6, v35                              // 00000038DC28: 326A4686
	v_and_or_b32 v46, 0xffff0000, v46, v42                     // 00000038DC2C: D657002E 04AA5CFF FFFF0000
	.long 0x7e5439af                                           // 00000038DC38: 7E5439AF
	v_add3_u32 v47, v57, v56, 0x7fff                           // 00000038DC3C: D655002F 03FE7139 00007FFF
	v_dot2_f32_bf16 v55, v9, v60, 0                            // 00000038DC48: CC1A4037 1A027909
	v_lshrrev_b32_e32 v56, 8, v35                              // 00000038DC50: 32704688
	v_lshrrev_b32_e32 v57, 20, v7                              // 00000038DC54: 32720E94
	v_and_b32_e32 v53, 48, v53                                 // 00000038DC58: 366A6AB0
	v_and_or_b32 v47, 0xffff0000, v47, v42                     // 00000038DC5C: D657002F 04AA5EFF FFFF0000
	.long 0x7e543987                                           // 00000038DC68: 7E543987
	v_lshrrev_b32_e32 v58, 24, v7                              // 00000038DC6C: 32740E98
	v_and_b32_e32 v56, 48, v56                                 // 00000038DC70: 367070B0
	v_dot2_f32_bf16 v44, v10, v59, v55                         // 00000038DC74: CC1A402C 1CDE770A
	v_and_or_b32 v53, v57, 15, v53                             // 00000038DC7C: D6570035 04D51F39
	v_and_or_b32 v48, v42, 15, v48                             // 00000038DC84: D6570030 04C11F2A
	v_lshrrev_b32_e32 v7, 28, v7                               // 00000038DC8C: 320E0E9C
	v_and_or_b32 v55, v58, 15, v56                             // 00000038DC90: D6570037 04E11F3A
	v_lshrrev_b32_e32 v56, 10, v35                             // 00000038DC98: 3270468A
	v_dot2_f32_bf16 v44, v11, v62, v44                         // 00000038DC9C: CC1A402C 1CB27D0B
	v_cvt_f32_ubyte0_e32 v48, v48                              // 00000038DCA4: 7E602330
	v_cvt_f32_ubyte0_e32 v53, v53                              // 00000038DCA8: 7E6A2335
	v_cvt_f32_ubyte0_e32 v55, v55                              // 00000038DCAC: 7E6E2337
	v_and_or_b32 v7, v56, 48, v7                               // 00000038DCB0: D6570007 041D6138
	v_dot2_f32_bf16 v44, v12, v61, v44                         // 00000038DCB8: CC1A402C 1CB27B0C
	v_fma_mix_f32 v48, v48, v43, v43 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038DCC0: CC206030 14AE5730
	v_fma_mix_f32 v53, v53, v43, v43 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038DCC8: CC206035 14AE5735
	v_fma_mix_f32 v55, v55, v43, v43 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038DCD0: CC206037 14AE5737
	v_cvt_f32_ubyte0_e32 v7, v7                                // 00000038DCD8: 7E0E2307
	v_dot2_f32_bf16 v5, v13, v5, v44                           // 00000038DCDC: CC1A4005 1CB20B0D
	v_bfe_u32 v56, v48, 16, 1                                  // 00000038DCE4: D6100038 02052130
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000038DCEC: BF870193
	v_fma_mix_f32 v7, v7, v43, v43 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038DCF0: CC206007 14AE5707
	v_dot2_f32_bf16 v5, v14, v38, v5                           // 00000038DCF8: CC1A4005 1C164D0E
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000038DD00: BF870233
	v_add3_u32 v44, v48, v56, 0x7fff                           // 00000038DD04: D655002C 03FE7130 00007FFF
	v_bfe_u32 v48, v53, 16, 1                                  // 00000038DD10: D6100030 02052135
	v_bfe_u32 v56, v55, 16, 1                                  // 00000038DD18: D6100038 02052137
	v_dot2_f32_bf16 v5, v15, v63, v5                           // 00000038DD20: CC1A4005 1C167F0F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000038DD28: BF870214
	.long 0x7e5439ac                                           // 00000038DD2C: 7E5439AC
	v_add3_u32 v38, v53, v48, 0x7fff                           // 00000038DD30: D6550026 03FE6135 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000038DD3C: BF870234
	v_add3_u32 v44, v55, v56, 0x7fff                           // 00000038DD40: D655002C 03FE7137 00007FFF
	v_bfe_u32 v48, v7, 16, 1                                   // 00000038DD4C: D6100030 02052107
	v_bfe_u32 v53, v23, 16, 1                                  // 00000038DD54: D6100035 02052117
	v_and_or_b32 v38, 0xffff0000, v38, v42                     // 00000038DD5C: D6570026 04AA4CFF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000038DD68: BF870214
	.long 0x7e5439ac                                           // 00000038DD6C: 7E5439AC
	v_add3_u32 v7, v7, v48, 0x7fff                             // 00000038DD70: D6550007 03FE6107 00007FFF
	v_dot2_f32_bf16 v44, v16, v64, v5                          // 00000038DD7C: CC1A402C 1C168110
	v_add3_u32 v23, v23, v53, 0x7fff                           // 00000038DD84: D6550017 03FE6B17 00007FFF
	v_dot2_f32_bf16 v5, v25, v52, v21                          // 00000038DD90: CC1A4005 1C566919
	s_delay_alu instid0(VALU_DEP_4)                            // 00000038DD98: BF870004
	v_and_or_b32 v21, 0xffff0000, v7, v42                      // 00000038DD9C: D6570015 04AA0EFF FFFF0000
	.long 0x7e5439a3                                           // 00000038DDA8: 7E5439A3
	v_dot2_f32_bf16 v7, v17, v65, v44                          // 00000038DDAC: CC1A4007 1CB28311
	v_and_or_b32 v23, 0xffff0000, v23, v37                     // 00000038DDB4: D6570017 04962EFF FFFF0000
	v_lshrrev_b32_e32 v37, 12, v34                             // 00000038DDC0: 324A448C
	v_lshrrev_b32_e32 v44, 8, v8                               // 00000038DDC4: 32581088
	v_and_b32_e32 v48, 48, v42                                 // 00000038DDC8: 366054B0
	v_dot2_f32_bf16 v7, v18, v30, v7                           // 00000038DDCC: CC1A4007 1C1E3D12
	v_lshrrev_b32_e32 v30, 18, v35                             // 00000038DDD4: 323C4692
	v_and_b32_e32 v37, 48, v37                                 // 00000038DDD8: 364A4AB0
	v_lshrrev_b32_e32 v34, 14, v34                             // 00000038DDDC: 3244448E
	v_and_or_b32 v44, v44, 15, v48                             // 00000038DDE0: D657002C 04C11F2C
	v_lshrrev_b32_e32 v48, 12, v8                              // 00000038DDE8: 3260108C
	v_and_b32_e32 v30, 48, v30                                 // 00000038DDEC: 363C3CB0
	v_and_or_b32 v37, v6, 15, v37                              // 00000038DDF0: D6570025 04951F06
	v_lshrrev_b32_e32 v6, 4, v6                                // 00000038DDF8: 320C0C84
	v_and_b32_e32 v34, 48, v34                                 // 00000038DDFC: 364444B0
	v_cvt_f32_ubyte0_e32 v44, v44                              // 00000038DE00: 7E58232C
	v_and_or_b32 v30, v48, 15, v30                             // 00000038DE04: D657001E 04791F30
	v_cvt_f32_ubyte0_e32 v37, v37                              // 00000038DE0C: 7E4A2325
	v_dot2_f32_bf16 v7, v19, v36, v7                           // 00000038DE10: CC1A4007 1C1E4913
	v_and_or_b32 v6, v6, 15, v34                               // 00000038DE18: D6570006 04891F06
	v_fma_mix_f32 v34, v44, v43, v43 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038DE20: CC206022 14AE572C
	v_cvt_f32_ubyte0_e32 v30, v30                              // 00000038DE28: 7E3C231E
	v_fma_mix_f32 v36, v37, v43, v43 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038DE2C: CC206024 14AE5725
	v_dot2_f32_bf16 v7, v20, v39, v7                           // 00000038DE34: CC1A4007 1C1E4F14
	v_cvt_f32_ubyte0_e32 v6, v6                                // 00000038DE3C: 7E0C2306
	v_bfe_u32 v37, v34, 16, 1                                  // 00000038DE40: D6100025 02052122
	v_fma_mix_f32 v30, v30, v43, v43 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038DE48: CC20601E 14AE571E
	v_bfe_u32 v39, v36, 16, 1                                  // 00000038DE50: D6100027 02052124
	v_dot2_f32_bf16 v7, v24, v23, v7                           // 00000038DE58: CC1A4007 1C1E2F18
	v_fma_mix_f32 v23, v6, v43, v43 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038DE60: CC206017 14AE5706
	v_add3_u32 v34, v34, v37, 0x7fff                           // 00000038DE68: D6550022 03FE4B22 00007FFF
	v_bfe_u32 v37, v30, 16, 1                                  // 00000038DE74: D6100025 0205211E
	v_add3_u32 v36, v36, v39, 0x7fff                           // 00000038DE7C: D6550024 03FE4F24 00007FFF
	v_dot2_f32_bf16 v6, v25, v73, v7                           // 00000038DE88: CC1A4006 1C1E9319
	v_bfe_u32 v7, v23, 16, 1                                   // 00000038DE90: D6100007 02052117
	.long 0x7e5439a2                                           // 00000038DE98: 7E5439A2
	v_add3_u32 v30, v30, v37, 0x7fff                           // 00000038DE9C: D655001E 03FE4B1E 00007FFF
	.long 0x7e4439a4                                           // 00000038DEA8: 7E4439A4
	v_lshrrev_b32_e32 v36, 20, v35                             // 00000038DEAC: 32484694
	.long 0x7f4439aa                                           // 00000038DEB0: 7F4439AA
	v_add3_u32 v23, v23, v7, 0x7fff                            // 00000038DEB4: D6550017 03FE0F17 00007FFF
	v_and_or_b32 v7, 0xffff0000, v30, v42                      // 00000038DEC0: D6570007 04AA3CFF FFFF0000
	.long 0x7e543988                                           // 00000038DECC: 7E543988
	v_and_b32_e32 v30, 48, v36                                 // 00000038DED0: 363C48B0
	v_lshrrev_b32_e32 v36, 12, v35                             // 00000038DED4: 3248468C
	v_lshrrev_b32_e32 v37, 22, v35                             // 00000038DED8: 324A4696
	v_and_b32_e32 v39, 15, v8                                  // 00000038DEDC: 364E108F
	v_and_or_b32 v23, 0xffff0000, v23, v34                     // 00000038DEE0: D6570017 048A2EFF FFFF0000
	v_and_or_b32 v30, v42, 15, v30                             // 00000038DEEC: D657001E 04791F2A
	v_lshrrev_b32_e32 v34, 20, v8                              // 00000038DEF4: 32441094
	v_and_b32_e32 v37, 48, v37                                 // 00000038DEF8: 364A4AB0
	v_and_or_b32 v36, v36, 48, v39                             // 00000038DEFC: D6570024 049D6124
	v_lshrrev_b32_e32 v39, 14, v35                             // 00000038DF04: 324E468E
	v_cvt_f32_ubyte0_e32 v30, v30                              // 00000038DF08: 7E3C231E
	v_lshrrev_b32_e32 v48, 24, v8                              // 00000038DF0C: 32601098
	v_and_or_b32 v34, v34, 15, v37                             // 00000038DF10: D6570022 04951F22
	v_lshrrev_b32_e32 v44, 4, v8                               // 00000038DF18: 32581084
	v_and_b32_e32 v37, 48, v39                                 // 00000038DF1C: 364A4EB0
	v_lshrrev_b32_e32 v39, 24, v35                             // 00000038DF20: 324E4698
	v_fma_mix_f32 v30, v30, v43, v43 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038DF24: CC20601E 14AE571E
	v_cvt_f32_ubyte0_e32 v34, v34                              // 00000038DF2C: 7E442322
	v_lshrrev_b32_e32 v8, 28, v8                               // 00000038DF30: 3210109C
	v_and_or_b32 v37, v44, 15, v37                             // 00000038DF34: D6570025 04951F2C
	v_and_b32_e32 v39, 48, v39                                 // 00000038DF3C: 364E4EB0
	v_bfe_u32 v52, v30, 16, 1                                  // 00000038DF40: D6100034 0205211E
	v_fma_mix_f32 v34, v34, v43, v43 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038DF48: CC206022 14AE5722
	v_cvt_f32_ubyte0_e32 v36, v36                              // 00000038DF50: 7E482324
	v_cvt_f32_ubyte0_e32 v37, v37                              // 00000038DF54: 7E4A2325
	v_and_or_b32 v39, v48, 15, v39                             // 00000038DF58: D6570027 049D1F30
	v_add3_u32 v30, v30, v52, 0x7fff                           // 00000038DF60: D655001E 03FE691E 00007FFF
	v_bfe_u32 v44, v34, 16, 1                                  // 00000038DF6C: D610002C 02052122
	v_lshlrev_b32_e32 v48, 4, v32                              // 00000038DF74: 30604084
	v_lshlrev_b32_e32 v52, 2, v32                              // 00000038DF78: 30684082
	v_cvt_f32_ubyte0_e32 v39, v39                              // 00000038DF7C: 7E4E2327
	.long 0x7e54399e                                           // 00000038DF80: 7E54399E
	v_add3_u32 v30, v34, v44, 0x7fff                           // 00000038DF84: D655001E 03FE5922 00007FFF
	v_lshrrev_b32_e32 v34, 26, v35                             // 00000038DF90: 3244469A
	v_and_b32_e32 v44, 15, v1                                  // 00000038DF94: 3658028F
	v_fma_mix_f32 v35, v39, v43, v43 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038DF98: CC206023 14AE5727
	v_dot2_f32_bf16 v39, v9, v88, 0                            // 00000038DFA0: CC1A4027 1A02B109
	v_and_or_b32 v30, 0xffff0000, v30, v42                     // 00000038DFA8: D657001E 04AA3CFF FFFF0000
	v_and_or_b32 v8, v34, 48, v8                               // 00000038DFB4: D6570008 04216122
	v_and_or_b32 v44, v48, 48, v44                             // 00000038DFBC: D657002C 04B16130
	v_bfe_u32 v34, v35, 16, 1                                  // 00000038DFC4: D6100022 02052123
	v_dot2_f32_bf16 v39, v10, v83, v39                         // 00000038DFCC: CC1A4027 1C9EA70A
	v_bfe_u32 v48, v1, 4, 4                                    // 00000038DFD4: D6100030 02110901
	v_cvt_f32_ubyte0_e32 v8, v8                                // 00000038DFDC: 7E102308
	v_fma_mix_f32 v36, v36, v43, v43 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038DFE0: CC206024 14AE5724
	v_add3_u32 v34, v35, v34, 0x7fff                           // 00000038DFE8: D6550022 03FE4523 00007FFF
	v_dot2_f32_bf16 v35, v11, v67, v39                         // 00000038DFF4: CC1A4023 1C9E870B
	v_cvt_f32_ubyte0_e32 v39, v44                              // 00000038DFFC: 7E4E232C
	v_and_or_b32 v44, v52, 48, v48                             // 00000038E000: D657002C 04C16134
	v_fma_mix_f32 v8, v8, v43, v43 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038E008: CC206008 14AE5708
	.long 0x7e5439a2                                           // 00000038E010: 7E5439A2
	v_dot2_f32_bf16 v34, v12, v50, v35                         // 00000038E014: CC1A4022 1C8E650C
	v_fma_mix_f32 v35, v39, v41, v41 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038E01C: CC206023 14A65327
	v_cvt_f32_ubyte0_e32 v39, v44                              // 00000038E024: 7E4E232C
	v_bfe_u32 v44, v1, 8, 4                                    // 00000038E028: D610002C 02111101
	v_bfe_u32 v48, v8, 16, 1                                   // 00000038E030: D6100030 02052108
	v_dot2_f32_bf16 v23, v13, v23, v34                         // 00000038E038: CC1A4017 1C8A2F0D
	v_bfe_u32 v34, v35, 16, 1                                  // 00000038E040: D6100022 02052123
	v_fma_mix_f32 v39, v39, v41, v41 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038E048: CC206027 14A65327
	v_and_or_b32 v44, v32, 48, v44                             // 00000038E050: D657002C 04B16120
	v_add3_u32 v8, v8, v48, 0x7fff                             // 00000038E058: D6550008 03FE6108 00007FFF
	v_dot2_f32_bf16 v23, v14, v51, v23                         // 00000038E064: CC1A4017 1C5E670E
	v_add3_u32 v34, v35, v34, 0x7fff                           // 00000038E06C: D6550022 03FE4523 00007FFF
	v_bfe_u32 v35, v39, 16, 1                                  // 00000038E078: D6100023 02052127
	v_cvt_f32_ubyte0_e32 v44, v44                              // 00000038E080: 7E58232C
	v_and_or_b32 v8, 0xffff0000, v8, v42                       // 00000038E084: D6570008 04AA10FF FFFF0000
	v_fma_mix_f32 v37, v37, v43, v43 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038E090: CC206025 14AE5725
	.long 0x7e5439a2                                           // 00000038E098: 7E5439A2
	v_add3_u32 v34, v39, v35, 0x7fff                           // 00000038E09C: D6550022 03FE4727 00007FFF
	v_fma_mix_f32 v35, v44, v41, v41 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038E0A8: CC206023 14A6532C
	v_bfe_u32 v39, v1, 12, 4                                   // 00000038E0B0: D6100027 02111901
	v_lshrrev_b32_e32 v44, 2, v32                              // 00000038E0B8: 32584082
	v_lshrrev_b32_e32 v48, 4, v32                              // 00000038E0BC: 32604084
	v_dot2_f32_bf16 v23, v15, v49, v23                         // 00000038E0C0: CC1A4017 1C5E630F
	v_bfe_u32 v43, v35, 16, 1                                  // 00000038E0C8: D610002B 02052123
	v_bfe_u32 v49, v1, 20, 4                                   // 00000038E0D0: D6100031 02112901
	v_and_or_b32 v39, v44, 48, v39                             // 00000038E0D8: D6570027 049D612C
	v_bfe_u32 v44, v1, 16, 4                                   // 00000038E0E0: D610002C 02112101
	v_lshrrev_b32_e32 v50, 6, v32                              // 00000038E0E8: 32644086
	v_add3_u32 v35, v35, v43, 0x7fff                           // 00000038E0EC: D6550023 03FE5723 00007FFF
	v_lshrrev_b32_e32 v43, 8, v32                              // 00000038E0F8: 32564088
	v_and_or_b32 v34, 0xffff0000, v34, v42                     // 00000038E0FC: D6570022 04AA44FF FFFF0000
	v_and_or_b32 v44, v48, 48, v44                             // 00000038E108: D657002C 04B16130
	v_bfe_u32 v48, v1, 24, 4                                   // 00000038E110: D6100030 02113101
	.long 0x7e5439a3                                           // 00000038E118: 7E5439A3
	v_cvt_f32_ubyte0_e32 v35, v39                              // 00000038E11C: 7E462327
	v_and_or_b32 v39, v50, 48, v49                             // 00000038E120: D6570027 04C56132
	v_cvt_f32_ubyte0_e32 v44, v44                              // 00000038E128: 7E58232C
	v_and_or_b32 v43, v43, 48, v48                             // 00000038E12C: D657002B 04C1612B
	v_lshrrev_b32_e32 v1, 28, v1                               // 00000038E134: 3202029C
	v_lshrrev_b32_e32 v48, 10, v32                             // 00000038E138: 3260408A
	v_fma_mix_f32 v35, v35, v41, v41 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038E13C: CC206023 14A65323
	v_fma_mix_f32 v44, v44, v41, v41 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038E144: CC20602C 14A6532C
	v_cvt_f32_ubyte0_e32 v39, v39                              // 00000038E14C: 7E4E2327
	v_cvt_f32_ubyte0_e32 v43, v43                              // 00000038E150: 7E56232B
	v_and_or_b32 v1, v48, 48, v1                               // 00000038E154: D6570001 04056130
	v_bfe_u32 v48, v35, 16, 1                                  // 00000038E15C: D6100030 02052123
	v_bfe_u32 v49, v44, 16, 1                                  // 00000038E164: D6100031 0205212C
	v_fma_mix_f32 v39, v39, v41, v41 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038E16C: CC206027 14A65327
	v_fma_mix_f32 v43, v43, v41, v41 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038E174: CC20602B 14A6532B
	v_cvt_f32_ubyte0_e32 v1, v1                                // 00000038E17C: 7E022301
	v_add3_u32 v35, v35, v48, 0x7fff                           // 00000038E180: D6550023 03FE6123 00007FFF
	v_add3_u32 v44, v44, v49, 0x7fff                           // 00000038E18C: D655002C 03FE632C 00007FFF
	v_bfe_u32 v48, v39, 16, 1                                  // 00000038E198: D6100030 02052127
	v_bfe_u32 v49, v43, 16, 1                                  // 00000038E1A0: D6100031 0205212B
	v_fma_mix_f32 v1, v1, v41, v41 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038E1A8: CC206001 14A65301
	v_dot2_f32_bf16 v23, v16, v54, v23                         // 00000038E1B0: CC1A4017 1C5E6D10
	v_and_or_b32 v35, 0xffff0000, v35, v42                     // 00000038E1B8: D6570023 04AA46FF FFFF0000
	.long 0x7e5439ac                                           // 00000038E1C4: 7E5439AC
	v_add3_u32 v39, v39, v48, 0x7fff                           // 00000038E1C8: D6550027 03FE6127 00007FFF
	v_add3_u32 v43, v43, v49, 0x7fff                           // 00000038E1D4: D655002B 03FE632B 00007FFF
	v_bfe_u32 v44, v1, 16, 1                                   // 00000038E1E0: D610002C 02052101
	v_bfe_u32 v53, v36, 16, 1                                  // 00000038E1E8: D6100035 02052124
	v_dot2_f32_bf16 v23, v17, v46, v23                         // 00000038E1F0: CC1A4017 1C5E5D11
	v_and_or_b32 v39, 0xffff0000, v39, v42                     // 00000038E1F8: D6570027 04AA4EFF FFFF0000
	.long 0x7e5439ab                                           // 00000038E204: 7E5439AB
	v_add3_u32 v1, v1, v44, 0x7fff                             // 00000038E208: D6550001 03FE5901 00007FFF
	v_add3_u32 v36, v36, v53, 0x7fff                           // 00000038E214: D6550024 03FE6B24 00007FFF
	v_bfe_u32 v48, v37, 16, 1                                  // 00000038E220: D6100030 02052125
	v_dot2_f32_bf16 v23, v18, v47, v23                         // 00000038E228: CC1A4017 1C5E5F12
	v_bfe_u32 v43, v2, 8, 4                                    // 00000038E230: D610002B 02111102
	v_and_or_b32 v1, 0xffff0000, v1, v42                       // 00000038E238: D6570001 04AA02FF FFFF0000
	.long 0x7e5439a0                                           // 00000038E244: 7E5439A0
	.long 0x7e4839a4                                           // 00000038E248: 7E4839A4
	.long 0x7f4839aa                                           // 00000038E24C: 7F4839AA
	v_add3_u32 v37, v37, v48, 0x7fff                           // 00000038E250: D6550025 03FE6125 00007FFF
	v_dot2_f32_bf16 v23, v19, v38, v23                         // 00000038E25C: CC1A4017 1C5E4D13
	v_and_or_b32 v38, v42, 48, v43                             // 00000038E264: D6570026 04AD612A
	v_bfe_u32 v43, v2, 12, 4                                   // 00000038E26C: D610002B 02111902
	v_lshrrev_b32_e32 v46, 18, v32                             // 00000038E274: 325C4092
	v_and_or_b32 v36, 0xffff0000, v37, v36                     // 00000038E278: D6570024 04924AFF FFFF0000
	v_lshrrev_b32_e32 v37, 12, v32                             // 00000038E284: 324A408C
	v_and_b32_e32 v44, 15, v2                                  // 00000038E288: 3658048F
	v_cvt_f32_ubyte0_e32 v38, v38                              // 00000038E28C: 7E4C2326
	v_and_or_b32 v43, v46, 48, v43                             // 00000038E290: D657002B 04AD612E
	v_lshrrev_b32_e32 v47, 14, v32                             // 00000038E298: 325E408E
	v_lshrrev_b32_e32 v46, 20, v32                             // 00000038E29C: 325C4094
	v_and_or_b32 v37, v37, 48, v44                             // 00000038E2A0: D6570025 04B16125
	v_bfe_u32 v44, v2, 4, 4                                    // 00000038E2A8: D610002C 02110902
	v_fma_mix_f32 v38, v38, v41, v41 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038E2B0: CC206026 14A65326
	v_bfe_u32 v48, v2, 16, 4                                   // 00000038E2B8: D6100030 02112102
	v_cvt_f32_ubyte0_e32 v43, v43                              // 00000038E2C0: 7E56232B
	v_lshrrev_b32_e32 v49, 22, v32                             // 00000038E2C4: 32624096
	v_and_or_b32 v44, v47, 48, v44                             // 00000038E2C8: D657002C 04B1612F
	v_bfe_u32 v47, v38, 16, 1                                  // 00000038E2D0: D610002F 02052126
	v_and_or_b32 v46, v46, 48, v48                             // 00000038E2D8: D657002E 04C1612E
	v_fma_mix_f32 v43, v43, v41, v41 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038E2E0: CC20602B 14A6532B
	v_bfe_u32 v48, v2, 20, 4                                   // 00000038E2E8: D6100030 02112902
	v_cvt_f32_ubyte0_e32 v37, v37                              // 00000038E2F0: 7E4A2325
	v_add3_u32 v38, v38, v47, 0x7fff                           // 00000038E2F4: D6550026 03FE5F26 00007FFF
	v_cvt_f32_ubyte0_e32 v46, v46                              // 00000038E300: 7E5C232E
	v_bfe_u32 v47, v43, 16, 1                                  // 00000038E304: D610002F 0205212B
	v_and_or_b32 v48, v49, 48, v48                             // 00000038E30C: D6570030 04C16131
	v_fma_mix_f32 v37, v37, v41, v41 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038E314: CC206025 14A65325
	.long 0x7e5439a6                                           // 00000038E31C: 7E5439A6
	v_fma_mix_f32 v38, v46, v41, v41 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038E320: CC206026 14A6532E
	v_add3_u32 v43, v43, v47, 0x7fff                           // 00000038E328: D655002B 03FE5F2B 00007FFF
	v_lshrrev_b32_e32 v46, 24, v32                             // 00000038E334: 325C4098
	v_cvt_f32_ubyte0_e32 v47, v48                              // 00000038E338: 7E5E2330
	v_bfe_u32 v48, v2, 24, 4                                   // 00000038E33C: D6100030 02113102
	v_bfe_u32 v50, v37, 16, 1                                  // 00000038E344: D6100032 02052125
	v_bfe_u32 v49, v38, 16, 1                                  // 00000038E34C: D6100031 02052126
	v_lshrrev_b32_e32 v2, 28, v2                               // 00000038E354: 3204049C
	v_fma_mix_f32 v47, v47, v41, v41 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038E358: CC20602F 14A6532F
	v_and_or_b32 v46, v46, 48, v48                             // 00000038E360: D657002E 04C1612E
	v_add3_u32 v37, v37, v50, 0x7fff                           // 00000038E368: D6550025 03FE6525 00007FFF
	v_add3_u32 v38, v38, v49, 0x7fff                           // 00000038E374: D6550026 03FE6326 00007FFF
	v_lshrrev_b32_e32 v32, 26, v32                             // 00000038E380: 3240409A
	v_bfe_u32 v48, v47, 16, 1                                  // 00000038E384: D6100030 0205212F
	v_cvt_f32_ubyte0_e32 v46, v46                              // 00000038E38C: 7E5C232E
	v_and_b32_e32 v49, 15, v3                                  // 00000038E390: 3662068F
	v_lshlrev_b32_e32 v50, 4, v33                              // 00000038E394: 30644284
	v_and_or_b32 v43, 0xffff0000, v43, v42                     // 00000038E398: D657002B 04AA56FF FFFF0000
	v_and_or_b32 v2, v32, 48, v2                               // 00000038E3A4: D6570002 04096120
	.long 0x7e5439a6                                           // 00000038E3AC: 7E5439A6
	v_add3_u32 v32, v47, v48, 0x7fff                           // 00000038E3B0: D6550020 03FE612F 00007FFF
	v_fma_mix_f32 v38, v46, v41, v41 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038E3BC: CC206026 14A6532E
	v_and_or_b32 v46, v50, 48, v49                             // 00000038E3C4: D657002E 04C56132
	v_bfe_u32 v47, v3, 4, 4                                    // 00000038E3CC: D610002F 02110903
	v_lshlrev_b32_e32 v48, 2, v33                              // 00000038E3D4: 30604282
	v_cvt_f32_ubyte0_e32 v2, v2                                // 00000038E3D8: 7E042302
	v_bfe_u32 v49, v38, 16, 1                                  // 00000038E3DC: D6100031 02052126
	v_cvt_f32_ubyte0_e32 v46, v46                              // 00000038E3E4: 7E5C232E
	v_and_or_b32 v32, 0xffff0000, v32, v42                     // 00000038E3E8: D6570020 04AA40FF FFFF0000
	v_and_or_b32 v47, v48, 48, v47                             // 00000038E3F4: D657002F 04BD6130
	v_bfe_u32 v48, v3, 8, 4                                    // 00000038E3FC: D6100030 02111103
	v_fma_mix_f32 v2, v2, v41, v41 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038E404: CC206002 14A65302
	v_fma_mix_f32 v46, v46, v41, v41 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038E40C: CC20602E 14A6532E
	v_add3_u32 v38, v38, v49, 0x7fff                           // 00000038E414: D6550026 03FE6326 00007FFF
	v_cvt_f32_ubyte0_e32 v47, v47                              // 00000038E420: 7E5E232F
	v_and_or_b32 v48, v33, 48, v48                             // 00000038E424: D6570030 04C16121
	v_bfe_u32 v49, v2, 16, 1                                   // 00000038E42C: D6100031 02052102
	v_bfe_u32 v50, v46, 16, 1                                  // 00000038E434: D6100032 0205212E
	.long 0x7e5439a6                                           // 00000038E43C: 7E5439A6
	v_fma_mix_f32 v38, v47, v41, v41 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038E440: CC206026 14A6532F
	v_cvt_f32_ubyte0_e32 v47, v48                              // 00000038E448: 7E5E2330
	v_add3_u32 v2, v2, v49, 0x7fff                             // 00000038E44C: D6550002 03FE6302 00007FFF
	v_add3_u32 v46, v46, v50, 0x7fff                           // 00000038E458: D655002E 03FE652E 00007FFF
	v_lshrrev_b32_e32 v49, 2, v33                              // 00000038E464: 32624282
	v_bfe_u32 v48, v38, 16, 1                                  // 00000038E468: D6100030 02052126
	v_fma_mix_f32 v47, v47, v41, v41 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038E470: CC20602F 14A6532F
	v_and_or_b32 v2, 0xffff0000, v2, v42                       // 00000038E478: D6570002 04AA04FF FFFF0000
	.long 0x7e5439ae                                           // 00000038E484: 7E5439AE
	v_bfe_u32 v46, v3, 12, 4                                   // 00000038E488: D610002E 02111903
	v_add3_u32 v38, v38, v48, 0x7fff                           // 00000038E490: D6550026 03FE6126 00007FFF
	v_bfe_u32 v48, v47, 16, 1                                  // 00000038E49C: D6100030 0205212F
	v_bfe_u32 v50, v3, 16, 4                                   // 00000038E4A4: D6100032 02112103
	v_lshrrev_b32_e32 v51, 4, v33                              // 00000038E4AC: 32664284
	v_and_or_b32 v46, v49, 48, v46                             // 00000038E4B0: D657002E 04B96131
	v_and_or_b32 v38, 0xffff0000, v38, v42                     // 00000038E4B8: D6570026 04AA4CFF FFFF0000
	v_add3_u32 v47, v47, v48, 0x7fff                           // 00000038E4C4: D655002F 03FE612F 00007FFF
	v_lshrrev_b32_e32 v49, 8, v33                              // 00000038E4D0: 32624288
	v_and_or_b32 v48, v51, 48, v50                             // 00000038E4D4: D6570030 04C96133
	v_bfe_u32 v50, v3, 20, 4                                   // 00000038E4DC: D6100032 02112903
	v_lshrrev_b32_e32 v51, 6, v33                              // 00000038E4E4: 32664286
	v_cvt_f32_ubyte0_e32 v46, v46                              // 00000038E4E8: 7E5C232E
	v_bfe_u32 v52, v3, 24, 4                                   // 00000038E4EC: D6100034 02113103
	v_cvt_f32_ubyte0_e32 v48, v48                              // 00000038E4F4: 7E602330
	.long 0x7e5439af                                           // 00000038E4F8: 7E5439AF
	v_and_or_b32 v47, v51, 48, v50                             // 00000038E4FC: D657002F 04C96133
	v_fma_mix_f32 v46, v46, v41, v41 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038E504: CC20602E 14A6532E
	v_and_or_b32 v49, v49, 48, v52                             // 00000038E50C: D6570031 04D16131
	v_fma_mix_f32 v48, v48, v41, v41 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038E514: CC206030 14A65330
	v_lshrrev_b32_e32 v3, 28, v3                               // 00000038E51C: 3206069C
	v_lshrrev_b32_e32 v50, 10, v33                             // 00000038E520: 3264428A
	v_cvt_f32_ubyte0_e32 v47, v47                              // 00000038E524: 7E5E232F
	v_bfe_u32 v51, v46, 16, 1                                  // 00000038E528: D6100033 0205212E
	v_cvt_f32_ubyte0_e32 v49, v49                              // 00000038E530: 7E622331
	v_bfe_u32 v52, v48, 16, 1                                  // 00000038E534: D6100034 02052130
	v_and_or_b32 v3, v50, 48, v3                               // 00000038E53C: D6570003 040D6132
	v_fma_mix_f32 v47, v47, v41, v41 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038E544: CC20602F 14A6532F
	v_add3_u32 v46, v46, v51, 0x7fff                           // 00000038E54C: D655002E 03FE672E 00007FFF
	v_fma_mix_f32 v49, v49, v41, v41 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038E558: CC206031 14A65331
	v_add3_u32 v48, v48, v52, 0x7fff                           // 00000038E560: D6550030 03FE6930 00007FFF
	v_cvt_f32_ubyte0_e32 v3, v3                                // 00000038E56C: 7E062303
	v_bfe_u32 v50, v47, 16, 1                                  // 00000038E570: D6100032 0205212F
	v_cvt_f32_ubyte0_e32 v44, v44                              // 00000038E578: 7E58232C
	v_and_or_b32 v46, 0xffff0000, v46, v42                     // 00000038E57C: D657002E 04AA5CFF FFFF0000
	v_bfe_u32 v51, v49, 16, 1                                  // 00000038E588: D6100033 02052131
	.long 0x7e5439b0                                           // 00000038E590: 7E5439B0
	v_fma_mix_f32 v3, v3, v41, v41 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038E594: CC206003 14A65303
	v_add3_u32 v47, v47, v50, 0x7fff                           // 00000038E59C: D655002F 03FE652F 00007FFF
	v_lshrrev_b32_e32 v48, 12, v33                             // 00000038E5A8: 3260428C
	v_and_b32_e32 v50, 15, v4                                  // 00000038E5AC: 3664088F
	v_fma_mix_f32 v44, v44, v41, v41 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038E5B0: CC20602C 14A6532C
	v_add3_u32 v49, v49, v51, 0x7fff                           // 00000038E5B8: D6550031 03FE6731 00007FFF
	v_bfe_u32 v51, v3, 16, 1                                   // 00000038E5C4: D6100033 02052103
	v_and_or_b32 v47, 0xffff0000, v47, v42                     // 00000038E5CC: D657002F 04AA5EFF FFFF0000
	v_and_or_b32 v48, v48, 48, v50                             // 00000038E5D8: D6570030 04C96130
	v_bfe_u32 v52, v44, 16, 1                                  // 00000038E5E0: D6100034 0205212C
	.long 0x7e5439b1                                           // 00000038E5E8: 7E5439B1
	v_add3_u32 v3, v3, v51, 0x7fff                             // 00000038E5EC: D6550003 03FE6703 00007FFF
	.long 0x7e4a39a5                                           // 00000038E5F8: 7E4A39A5
	v_cvt_f32_ubyte0_e32 v48, v48                              // 00000038E5FC: 7E602330
	.long 0x7f4a39aa                                           // 00000038E600: 7F4A39AA
	v_add3_u32 v44, v44, v52, 0x7fff                           // 00000038E604: D655002C 03FE692C 00007FFF
	v_and_or_b32 v3, 0xffff0000, v3, v42                       // 00000038E610: D6570003 04AA06FF FFFF0000
	.long 0x7e5439a1                                           // 00000038E61C: 7E5439A1
	v_bfe_u32 v49, v4, 4, 4                                    // 00000038E620: D6100031 02110904
	v_lshrrev_b32_e32 v50, 14, v33                             // 00000038E628: 3264428E
	v_fma_mix_f32 v48, v48, v41, v41 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038E62C: CC206030 14A65330
	v_bfe_u32 v51, v4, 8, 4                                    // 00000038E634: D6100033 02111104
	v_dot2_f32_bf16 v9, v9, v34, 0                             // 00000038E63C: CC1A4009 1A024509
	v_dot2_f32_bf16 v21, v20, v21, v23                         // 00000038E644: CC1A4015 1C5E2B14
	v_and_or_b32 v23, 0xffff0000, v44, v37                     // 00000038E64C: D6570017 049658FF FFFF0000
	v_and_or_b32 v37, v50, 48, v49                             // 00000038E658: D6570025 04C56132
	v_bfe_u32 v44, v48, 16, 1                                  // 00000038E660: D610002C 02052130
	v_and_or_b32 v49, v42, 48, v51                             // 00000038E668: D6570031 04CD612A
	v_bfe_u32 v50, v4, 12, 4                                   // 00000038E670: D6100032 02111904
	v_lshrrev_b32_e32 v51, 18, v33                             // 00000038E678: 32664292
	v_dot2_f32_bf16 v9, v10, v35, v9                           // 00000038E67C: CC1A4009 1C26470A
	v_cvt_f32_ubyte0_e32 v34, v37                              // 00000038E684: 7E442325
	v_add3_u32 v37, v48, v44, 0x7fff                           // 00000038E688: D6550025 03FE5930 00007FFF
	v_cvt_f32_ubyte0_e32 v44, v49                              // 00000038E694: 7E582331
	v_and_or_b32 v48, v51, 48, v50                             // 00000038E698: D6570030 04C96133
	v_dot2_f32_bf16 v9, v11, v39, v9                           // 00000038E6A0: CC1A4009 1C264F0B
	v_fma_mix_f32 v10, v34, v41, v41 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038E6A8: CC20600A 14A65322
	.long 0x7e4439a5                                           // 00000038E6B0: 7E4439A5
	v_fma_mix_f32 v35, v44, v41, v41 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038E6B4: CC206023 14A6532C
	v_cvt_f32_ubyte0_e32 v37, v48                              // 00000038E6BC: 7E4A2330
	v_dot2_f32_bf16 v1, v12, v1, v9                            // 00000038E6C0: CC1A4001 1C26030C
	v_bfe_u32 v11, v10, 16, 1                                  // 00000038E6C8: D610000B 0205210A
	.long 0x7f4439aa                                           // 00000038E6D0: 7F4439AA
	v_bfe_u32 v39, v35, 16, 1                                  // 00000038E6D4: D6100027 02052123
	v_fma_mix_f32 v37, v37, v41, v41 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038E6DC: CC206025 14A65325
	v_dot2_f32_bf16 v1, v13, v23, v1                           // 00000038E6E4: CC1A4001 1C062F0D
	v_add3_u32 v9, v10, v11, 0x7fff                            // 00000038E6EC: D6550009 03FE170A 00007FFF
	v_lshrrev_b32_e32 v13, 20, v33                             // 00000038E6F8: 321A4294
	v_add3_u32 v11, v35, v39, 0x7fff                           // 00000038E6FC: D655000B 03FE4F23 00007FFF
	v_bfe_u32 v12, v37, 16, 1                                  // 00000038E708: D610000C 02052125
	v_dot2_f32_bf16 v1, v14, v43, v1                           // 00000038E710: CC1A4001 1C06570E
	v_dot2_f32_bf16 v10, v24, v36, v21                         // 00000038E718: CC1A400A 1C564918
	v_lshrrev_b32_e32 v14, 24, v33                             // 00000038E720: 321C4298
	.long 0x7e54398b                                           // 00000038E724: 7E54398B
	v_add3_u32 v11, v37, v12, 0x7fff                           // 00000038E728: D655000B 03FE1925 00007FFF
	v_bfe_u32 v12, v4, 16, 4                                   // 00000038E734: D610000C 02112104
	v_dot2_f32_bf16 v1, v15, v32, v1                           // 00000038E73C: CC1A4001 1C06410F
	v_bfe_u32 v21, v4, 20, 4                                   // 00000038E744: D6100015 02112904
	v_lshrrev_b32_e32 v23, 22, v33                             // 00000038E74C: 322E4296
	v_and_or_b32 v9, 0xffff0000, v9, v34                       // 00000038E750: D6570009 048A12FF FFFF0000
	v_and_or_b32 v12, v13, 48, v12                             // 00000038E75C: D657000C 0431610D
	v_bfe_u32 v13, v4, 24, 4                                   // 00000038E764: D610000D 02113104
	v_dot2_f32_bf16 v1, v16, v2, v1                            // 00000038E76C: CC1A4001 1C060510
	v_and_or_b32 v15, v23, 48, v21                             // 00000038E774: D657000F 04556117
	v_lshrrev_b32_e32 v4, 28, v4                               // 00000038E77C: 3208089C
	v_cvt_f32_ubyte0_e32 v2, v12                               // 00000038E780: 7E04230C
	v_and_or_b32 v12, v14, 48, v13                             // 00000038E784: D657000C 0435610E
	v_lshrrev_b32_e32 v13, 26, v33                             // 00000038E78C: 321A429A
	v_dot2_f32_bf16 v1, v17, v38, v1                           // 00000038E790: CC1A4001 1C064D11
	v_cvt_f32_ubyte0_e32 v14, v15                              // 00000038E798: 7E1C230F
	v_fma_mix_f32 v2, v2, v41, v41 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038E79C: CC206002 14A65302
	v_cvt_f32_ubyte0_e32 v12, v12                              // 00000038E7A4: 7E18230C
	v_and_or_b32 v4, v13, 48, v4                               // 00000038E7A8: D6570004 0411610D
	v_dot2_f32_bf16 v1, v18, v46, v1                           // 00000038E7B0: CC1A4001 1C065D12
	v_fma_mix_f32 v14, v14, v41, v41 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038E7B8: CC20600E 14A6530E
	v_bfe_u32 v13, v2, 16, 1                                   // 00000038E7C0: D610000D 02052102
	v_fma_mix_f32 v12, v12, v41, v41 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038E7C8: CC20600C 14A6530C
	v_cvt_f32_ubyte0_e32 v4, v4                                // 00000038E7D0: 7E082304
	v_dot2_f32_bf16 v1, v19, v47, v1                           // 00000038E7D4: CC1A4001 1C065F13
	v_and_or_b32 v11, 0xffff0000, v11, v42                     // 00000038E7DC: D657000B 04AA16FF FFFF0000
	v_add3_u32 v2, v2, v13, 0x7fff                             // 00000038E7E8: D6550002 03FE1B02 00007FFF
	v_bfe_u32 v13, v14, 16, 1                                  // 00000038E7F4: D610000D 0205210E
	v_bfe_u32 v15, v12, 16, 1                                  // 00000038E7FC: D610000F 0205210C
	v_fma_mix_f32 v4, v4, v41, v41 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038E804: CC206004 14A65304
	v_dot2_f32_bf16 v1, v20, v3, v1                            // 00000038E80C: CC1A4001 1C060714
	.long 0x7e543982                                           // 00000038E814: 7E543982
	v_add3_u32 v2, v14, v13, 0x7fff                            // 00000038E818: D6550002 03FE1B0E 00007FFF
	v_add3_u32 v3, v12, v15, 0x7fff                            // 00000038E824: D6550003 03FE1F0C 00007FFF
	v_bfe_u32 v12, v4, 16, 1                                   // 00000038E830: D610000C 02052104
	v_dot2_f32_bf16 v1, v24, v9, v1                            // 00000038E838: CC1A4001 1C061318
	v_dot2_f32_bf16 v7, v25, v7, v10                           // 00000038E840: CC1A4007 1C2A0F19
	v_and_or_b32 v2, 0xffff0000, v2, v42                       // 00000038E848: D6570002 04AA04FF FFFF0000
	.long 0x7e543983                                           // 00000038E854: 7E543983
	v_add3_u32 v3, v4, v12, 0x7fff                             // 00000038E858: D6550003 03FE1904 00007FFF
	v_dot2_f32_bf16 v1, v25, v11, v1                           // 00000038E864: CC1A4001 1C061719
	v_dot2_f32_bf16 v4, v26, v29, v5                           // 00000038E86C: CC1A4004 1C163B1A
	v_dot2_f32_bf16 v5, v26, v22, v6                           // 00000038E874: CC1A4005 1C1A2D1A
	v_dot2_f32_bf16 v6, v26, v30, v7                           // 00000038E87C: CC1A4006 1C1E3D1A
	v_and_or_b32 v3, 0xffff0000, v3, v42                       // 00000038E884: D6570003 04AA06FF FFFF0000
	v_dot2_f32_bf16 v1, v26, v2, v1                            // 00000038E890: CC1A4001 1C06051A
	v_dot2_f32_bf16 v2, v27, v45, v4                           // 00000038E898: CC1A4002 1C125B1B
	v_dot2_f32_bf16 v4, v27, v28, v5                           // 00000038E8A0: CC1A4004 1C16391B
	v_dot2_f32_bf16 v5, v27, v8, v6                            // 00000038E8A8: CC1A4005 1C1A111B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000038E8B0: BF870194
	v_dot2_f32_bf16 v1, v27, v3, v1                            // 00000038E8B4: CC1A4001 1C06071B
	v_dual_add_f32 v9, 0, v2 :: v_dual_add_f32 v10, 0, v4      // 00000038E8BC: C9080480 090A0880
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000038E8C4: BF870193
	v_add_f32_e32 v11, 0, v5                                   // 00000038E8C8: 06160A80
	v_add_f32_e32 v12, 0, v1                                   // 00000038E8CC: 06180280
	s_or_b32 exec_lo, exec_lo, s4                              // 00000038E8D0: 8C7E047E
	.long 0xd71f0001                                           // 00000038E8D4: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 00000038E8D8: 020100C1
	s_mov_b32 s6, 0                                            // 00000038E8DC: BE860080
	s_mov_b32 s7, exec_lo                                      // 00000038E8E0: BE87007E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000038E8E4: BF870121
	v_xor_b32_e32 v2, 8, v1                                    // 00000038E8E8: 3A040288
	v_xor_b32_e32 v6, 4, v1                                    // 00000038E8EC: 3A0C0284
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 00000038E8F0: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 00000038E8F4: 02040501
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000038E8F8: BF870113
	v_cmp_gt_u32_e32 vcc_lo, 32, v6                            // 00000038E8FC: 7C980CA0
	v_lshlrev_b32_e32 v2, 2, v2                                // 00000038E900: 30040482
	ds_bpermute_b32 v3, v2, v9                                 // 00000038E904: DACC0000 03000902
	s_waitcnt lgkmcnt(0)                                       // 00000038E90C: BF89FC07
	v_add_f32_e32 v3, v9, v3                                   // 00000038E910: 06060709
	ds_bpermute_b32 v5, v2, v11                                // 00000038E914: DACC0000 05000B02
	v_cndmask_b32_e32 v6, v1, v6, vcc_lo                       // 00000038E91C: 020C0D01
	ds_bpermute_b32 v4, v2, v10                                // 00000038E920: DACC0000 04000A02
	ds_bpermute_b32 v2, v2, v12                                // 00000038E928: DACC0000 02000C02
	s_waitcnt lgkmcnt(2)                                       // 00000038E930: BF89FC27
	v_dual_add_f32 v5, v11, v5 :: v_dual_lshlrev_b32 v6, 2, v6 // 00000038E934: C9220B0B 05060C82
	s_waitcnt lgkmcnt(1)                                       // 00000038E93C: BF89FC17
	v_add_f32_e32 v4, v10, v4                                  // 00000038E940: 0608090A
	v_xor_b32_e32 v10, 2, v1                                   // 00000038E944: 3A140282
	s_waitcnt lgkmcnt(0)                                       // 00000038E948: BF89FC07
	v_add_f32_e32 v2, v12, v2                                  // 00000038E94C: 0604050C
	ds_bpermute_b32 v9, v6, v5                                 // 00000038E950: DACC0000 09000506
	v_cmp_gt_u32_e32 vcc_lo, 32, v10                           // 00000038E958: 7C9814A0
	v_cndmask_b32_e32 v10, v1, v10, vcc_lo                     // 00000038E95C: 02141501
	s_waitcnt lgkmcnt(0)                                       // 00000038E960: BF89FC07
	v_add_f32_e32 v5, v5, v9                                   // 00000038E964: 060A1305
	ds_bpermute_b32 v7, v6, v3                                 // 00000038E968: DACC0000 07000306
	ds_bpermute_b32 v8, v6, v4                                 // 00000038E970: DACC0000 08000406
	v_lshlrev_b32_e32 v10, 2, v10                              // 00000038E978: 30141482
	ds_bpermute_b32 v6, v6, v2                                 // 00000038E97C: DACC0000 06000206
	s_waitcnt lgkmcnt(1)                                       // 00000038E984: BF89FC17
	v_dual_add_f32 v3, v3, v7 :: v_dual_add_f32 v4, v4, v8     // 00000038E988: C9080F03 03041104
	ds_bpermute_b32 v8, v10, v5                                // 00000038E990: DACC0000 0800050A
	s_waitcnt lgkmcnt(0)                                       // 00000038E998: BF89FC07
	v_dual_add_f32 v2, v2, v6 :: v_dual_add_f32 v5, v5, v8     // 00000038E99C: C9080D02 02041105
	ds_bpermute_b32 v6, v10, v3                                // 00000038E9A4: DACC0000 0600030A
	ds_bpermute_b32 v9, v10, v2                                // 00000038E9AC: DACC0000 0900020A
	s_waitcnt lgkmcnt(1)                                       // 00000038E9B4: BF89FC17
	v_add_f32_e32 v3, v3, v6                                   // 00000038E9B8: 06060D03
	ds_bpermute_b32 v7, v10, v4                                // 00000038E9BC: DACC0000 0700040A
	v_xor_b32_e32 v10, 1, v1                                   // 00000038E9C4: 3A140281
	s_waitcnt lgkmcnt(1)                                       // 00000038E9C8: BF89FC17
	v_add_f32_e32 v6, v2, v9                                   // 00000038E9CC: 060C1302
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000038E9D0: BF8700B2
	v_cmp_gt_u32_e32 vcc_lo, 32, v10                           // 00000038E9D4: 7C9814A0
	v_cndmask_b32_e32 v1, v1, v10, vcc_lo                      // 00000038E9D8: 02021501
	s_waitcnt lgkmcnt(0)                                       // 00000038E9DC: BF89FC07
	v_dual_add_f32 v4, v4, v7 :: v_dual_lshlrev_b32 v1, 2, v1  // 00000038E9E0: C9220F04 04000282
	ds_bpermute_b32 v7, v1, v3                                 // 00000038E9E8: DACC0000 07000301
	ds_bpermute_b32 v9, v1, v5                                 // 00000038E9F0: DACC0000 09000501
	ds_bpermute_b32 v10, v1, v6                                // 00000038E9F8: DACC0000 0A000601
	ds_bpermute_b32 v8, v1, v4                                 // 00000038EA00: DACC0000 08000401
	v_cmpx_eq_u32_e32 0, v40                                   // 00000038EA08: 7D945080
	s_cbranch_execz 257                                        // 00000038EA0C: BFA50101 <_ZN7halogen12_GLOBAL__N_111k_hc6_fusedILi1EEEvNS0_5LqGrpEPKtliPKhS4_PtPfPyy+0x2814>
	v_ashrrev_i32_e32 v32, 31, v31                             // 00000038EA10: 34403E9F
	s_waitcnt lgkmcnt(0)                                       // 00000038EA14: BF89FC07
	v_dual_add_f32 v3, v3, v7 :: v_dual_add_f32 v4, v4, v8     // 00000038EA18: C9080F03 03041104
	v_dual_add_f32 v5, v5, v9 :: v_dual_add_f32 v6, v6, v10    // 00000038EA20: C9081305 05061506
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000038EA28: BF870193
	.long 0xd73c0001                                           // 00000038EA2C: D73C0001
	v_cndmask_b32_e32 v1, 1, v31, vcc_lo                       // 00000038EA30: 02023E81
	v_bfe_u32 v7, v3, 16, 1                                    // 00000038EA34: D6100007 02052103
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000038EA3C: BF870214
	v_bfe_u32 v8, v4, 16, 1                                    // 00000038EA40: D6100008 02052104
	v_bfe_u32 v9, v5, 16, 1                                    // 00000038EA48: D6100009 02052105
	v_bfe_u32 v10, v6, 16, 1                                   // 00000038EA50: D610000A 02052106
	s_cmp_eq_u64 s[10:11], 0                                   // 00000038EA58: BF10800A
	.long 0xd7006a0b                                           // 00000038EA5C: D7006A0B
	v_cndmask_b32_e32 v1, s16, v1, vcc_lo                      // 00000038EA60: 02020210
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000038EA64: BF8701A1
	v_add_co_ci_u32_e64 v12, null, s17, v2, vcc_lo             // 00000038EA68: D5207C0C 01AA0411
	v_add3_u32 v4, v4, v8, 0x7fff                              // 00000038EA70: D6550004 03FE1104 00007FFF
	.long 0xd7006a0d                                           // 00000038EA7C: D7006A0D
	v_cndmask_b32_e32 v1, 0x1000, v11, vcc_lo                  // 00000038EA80: 020216FF 00001000
	global_load_u16 v17, v[11:12], off                         // 00000038EA88: DC4A0000 117C000B
	v_add_co_ci_u32_e64 v14, null, 0, v12, vcc_lo              // 00000038EA90: D5207C0E 01AA1880
	.long 0xd7006a0f                                           // 00000038EA98: D7006A0F
	v_cndmask_b32_e32 v1, 0x2000, v11, vcc_lo                  // 00000038EA9C: 020216FF 00002000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000038EAA4: BF8700D1
	v_add_co_ci_u32_e64 v16, null, 0, v12, vcc_lo              // 00000038EAA8: D5207C10 01AA1880
	s_clause 0x1                                               // 00000038EAB0: BF850001
	global_load_u16 v13, v[13:14], off offset:1024             // 00000038EAB4: DC4A0400 0D7C000D
	global_load_u16 v14, v[15:16], off offset:2048             // 00000038EABC: DC4A0800 0E7C000F
	.long 0xd7006a0b                                           // 00000038EAC4: D7006A0B
	v_cndmask_b32_e32 v1, 0x3000, v11, vcc_lo                  // 00000038EAC8: 020216FF 00003000
	v_add_co_ci_u32_e64 v12, null, 0, v12, vcc_lo              // 00000038EAD0: D5207C0C 01AA1880
	v_and_b32_e32 v4, 0xffff0000, v4                           // 00000038EAD8: 360808FF FFFF0000
	v_add3_u32 v3, v3, v7, 0x7fff                              // 00000038EAE0: D6550003 03FE0F03 00007FFF
	v_add3_u32 v6, v6, v10, 0x7fff                             // 00000038EAEC: D6550006 03FE1506 00007FFF
	global_load_u16 v11, v[11:12], off offset:3072             // 00000038EAF8: DC4A0C00 0B7C000B
	v_add3_u32 v5, v5, v9, 0x7fff                              // 00000038EB00: D6550005 03FE1305 00007FFF
	v_mul_f32_e32 v4, 0xbfb8aa3b, v4                           // 00000038EB0C: 100808FF BFB8AA3B
	v_and_b32_e32 v6, 0xffff0000, v6                           // 00000038EB14: 360C0CFF FFFF0000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000038EB1C: BF870122
	v_exp_f32_e32 v4, v4                                       // 00000038EB20: 7E084B04
	v_and_b32_e32 v3, 0xffff0000, v3                           // 00000038EB24: 360606FF FFFF0000
	v_mul_f32_e32 v6, 0xbfb8aa3b, v6                           // 00000038EB2C: 100C0CFF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 00000038EB34: BF870311
	v_exp_f32_e32 v6, v6                                       // 00000038EB38: 7E0C4B06
	v_dual_add_f32 v4, 1.0, v4 :: v_dual_and_b32 v5, 0xffff0000, v5// 00000038EB3C: C92408F2 04040AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000038EB48: BF870113
	v_mul_f32_e32 v3, 0xbfb8aa3b, v3                           // 00000038EB4C: 100606FF BFB8AA3B
	v_div_scale_f32 v8, null, v4, v4, 1.0                      // 00000038EB54: D6FC7C08 03CA0904
	s_delay_alu instid0(VALU_DEP_2)                            // 00000038EB5C: BF870002
	v_exp_f32_e32 v3, v3                                       // 00000038EB60: 7E064B03
	s_delay_alu instid0(TRANS32_DEP_2) | instid1(VALU_DEP_3)   // 00000038EB64: BF870186
	v_dual_add_f32 v6, 1.0, v6 :: v_dual_mul_f32 v5, 0xbfb8aa3b, v5// 00000038EB68: C9060CF2 06040AFF BFB8AA3B
	v_div_scale_f32 v20, s3, 1.0, v4, 1.0                      // 00000038EB74: D6FC0314 03CA08F2
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000038EB7C: BF870113
	v_rcp_f32_e32 v15, v8                                      // 00000038EB80: 7E1E5508
	v_div_scale_f32 v10, null, v6, v6, 1.0                     // 00000038EB84: D6FC7C0A 03CA0D06
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_3)// 00000038EB8C: BF870393
	v_exp_f32_e32 v5, v5                                       // 00000038EB90: 7E0A4B05
	v_add_f32_e32 v3, 1.0, v3                                  // 00000038EB94: 060606F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_3)// 00000038EB98: BF870392
	v_rcp_f32_e32 v18, v10                                     // 00000038EB9C: 7E24550A
	v_fma_f32 v22, -v8, v15, 1.0                               // 00000038EBA0: D6130016 23CA1F08
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(TRANS32_DEP_2)// 00000038EBA8: BF870322
	v_div_scale_f32 v7, null, v3, v3, 1.0                      // 00000038EBAC: D6FC7C07 03CA0703
	v_div_scale_f32 v19, vcc_lo, 1.0, v3, 1.0                  // 00000038EBB4: D6FC6A13 03CA06F2
	v_add_f32_e32 v5, 1.0, v5                                  // 00000038EBBC: 060A0AF2
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000038EBC0: BF870214
	v_fmac_f32_e32 v15, v22, v15                               // 00000038EBC4: 561E1F16
	v_rcp_f32_e32 v12, v7                                      // 00000038EBC8: 7E185507
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000038EBCC: BF870196
	v_fma_f32 v25, -v10, v18, 1.0                              // 00000038EBD0: D6130019 23CA250A
	v_div_scale_f32 v9, null, v5, v5, 1.0                      // 00000038EBD8: D6FC7C09 03CA0B05
	v_div_scale_f32 v24, s4, 1.0, v5, 1.0                      // 00000038EBE0: D6FC0418 03CA0AF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 00000038EBE8: BF870312
	v_rcp_f32_e32 v16, v9                                      // 00000038EBEC: 7E205509
	v_fma_f32 v21, -v7, v12, 1.0                               // 00000038EBF0: D6130015 23CA1907
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(TRANS32_DEP_1)// 00000038EBF8: BF8702A1
	v_fmac_f32_e32 v12, v21, v12                               // 00000038EBFC: 56181915
	v_div_scale_f32 v21, s5, 1.0, v6, 1.0                      // 00000038EC00: D6FC0515 03CA0CF2
	v_fma_f32 v23, -v9, v16, 1.0                               // 00000038EC08: D6130017 23CA2109
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000038EC10: BF870091
	v_dual_fmac_f32 v16, v23, v16 :: v_dual_mul_f32 v23, v20, v15// 00000038EC14: C8062117 10161F14
	v_dual_fmac_f32 v18, v25, v18 :: v_dual_mul_f32 v25, v24, v16// 00000038EC1C: C8062519 12182118
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000038EC24: BF8701A2
	v_fma_f32 v28, -v8, v23, v20                               // 00000038EC28: D613001C 24522F08
	v_mul_f32_e32 v22, v19, v12                                // 00000038EC30: 102C1913
	v_fma_f32 v29, -v9, v25, v24                               // 00000038EC34: D613001D 24623309
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000038EC3C: BF870193
	v_fmac_f32_e32 v23, v28, v15                               // 00000038EC40: 562E1F1C
	v_fma_f32 v27, -v7, v22, v19                               // 00000038EC44: D613001B 244E2D07
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000038EC4C: BF870112
	v_fma_f32 v8, -v8, v23, v20                                // 00000038EC50: D6130008 24522F08
	v_fmac_f32_e32 v22, v27, v12                               // 00000038EC58: 562C191B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000038EC5C: BF870091
	v_fma_f32 v7, -v7, v22, v19                                // 00000038EC60: D6130007 244E2D07
	v_div_fmas_f32 v7, v7, v12, v22                            // 00000038EC68: D6370007 045A1907
	s_mov_b32 vcc_lo, s3                                       // 00000038EC70: BEEA0003
	v_div_fmas_f32 v8, v8, v15, v23                            // 00000038EC74: D6370008 045E1F08
	s_mov_b32 vcc_lo, s4                                       // 00000038EC7C: BEEA0004
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000038EC80: BF870112
	v_div_fixup_f32 v3, v7, v3, 1.0                            // 00000038EC84: D6270003 03CA0707
	v_div_fixup_f32 v4, v8, v4, 1.0                            // 00000038EC8C: D6270004 03CA0908
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000038EC94: BF870092
	v_bfe_u32 v8, v3, 16, 1                                    // 00000038EC98: D6100008 02052103
	v_add3_u32 v3, v3, v8, 0x7fff                              // 00000038ECA0: D6550003 03FE1103 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000038ECAC: BF870091
	v_dual_mul_f32 v26, v21, v18 :: v_dual_and_b32 v3, 0xffff0000, v3// 00000038ECB0: C8E42515 1A0206FF FFFF0000
	v_fma_f32 v30, -v10, v26, v21                              // 00000038ECBC: D613001E 2456350A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000038ECC4: BF870091
	v_dual_fmac_f32 v25, v29, v16 :: v_dual_fmac_f32 v26, v30, v18// 00000038ECC8: C800211D 191A251E
	v_fma_f32 v9, -v9, v25, v24                                // 00000038ECD0: D6130009 24623309
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000038ECD8: BF870112
	v_fma_f32 v10, -v10, v26, v21                              // 00000038ECDC: D613000A 2456350A
	v_div_fmas_f32 v7, v9, v16, v25                            // 00000038ECE4: D6370007 04662109
	s_mov_b32 vcc_lo, s5                                       // 00000038ECEC: BEEA0005
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000038ECF0: BF870112
	v_div_fmas_f32 v9, v10, v18, v26                           // 00000038ECF4: D6370009 046A250A
	v_div_fixup_f32 v5, v7, v5, 1.0                            // 00000038ECFC: D6270005 03CA0B07
	v_bfe_u32 v7, v4, 16, 1                                    // 00000038ED04: D6100007 02052104
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000038ED0C: BF870193
	v_div_fixup_f32 v6, v9, v6, 1.0                            // 00000038ED10: D6270006 03CA0D09
	v_bfe_u32 v8, v5, 16, 1                                    // 00000038ED18: D6100008 02052105
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000038ED20: BF870193
	v_add3_u32 v4, v4, v7, 0x7fff                              // 00000038ED24: D6550004 03FE0F04 00007FFF
	v_bfe_u32 v9, v6, 16, 1                                    // 00000038ED30: D6100009 02052106
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000038ED38: BF870193
	v_add3_u32 v5, v5, v8, 0x7fff                              // 00000038ED3C: D6550005 03FE1105 00007FFF
	v_and_b32_e32 v4, 0xffff0000, v4                           // 00000038ED48: 360808FF FFFF0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000038ED50: BF870193
	v_add3_u32 v6, v6, v9, 0x7fff                              // 00000038ED54: D6550006 03FE1306 00007FFF
	v_and_b32_e32 v5, 0xffff0000, v5                           // 00000038ED60: 360A0AFF FFFF0000
	s_waitcnt vmcnt(3)                                         // 00000038ED68: BF890FF7
	v_lshlrev_b32_e32 v7, 16, v17                              // 00000038ED6C: 300E2290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000038ED70: BF8700C1
	v_fma_f32 v3, v3, v7, 0                                    // 00000038ED74: D6130003 02020F03
	s_waitcnt vmcnt(2)                                         // 00000038ED7C: BF890BF7
	v_lshlrev_b32_e32 v7, 16, v13                              // 00000038ED80: 300E1A90
	s_waitcnt vmcnt(1)                                         // 00000038ED84: BF8907F7
	v_dual_fmac_f32 v3, v4, v7 :: v_dual_lshlrev_b32 v8, 16, v14// 00000038ED88: C8220F04 03081C90
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000038ED90: BF8700B1
	v_dual_fmac_f32 v3, v5, v8 :: v_dual_and_b32 v4, 0xffff0000, v6// 00000038ED94: C8241105 03040CFF FFFF0000
	s_waitcnt vmcnt(0)                                         // 00000038EDA0: BF8903F7
	v_lshlrev_b32_e32 v5, 16, v11                              // 00000038EDA4: 300A1690
	v_fmac_f32_e32 v3, v4, v5                                  // 00000038EDA8: 56060B04
	s_delay_alu instid0(VALU_DEP_1)                            // 00000038EDAC: BF870001
	v_mul_f32_e32 v3, 0x3e800000, v3                           // 00000038EDB0: 100606FF 3E800000
	s_cbranch_scc1 9                                           // 00000038EDB8: BFA20009 <_ZN7halogen12_GLOBAL__N_111k_hc6_fusedILi1EEEvNS0_5LqGrpEPKtliPKhS4_PtPfPyy+0x27e0>
	.long 0xd73c0004                                           // 00000038EDBC: D73C0004
	v_cndmask_b32_e32 v1, 2, v31, vcc_lo                       // 00000038EDC0: 02023E82
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000038EDC4: BF870091
	.long 0xd7006a04                                           // 00000038EDC8: D7006A04
	v_cndmask_b32_e32 v1, s10, v4, vcc_lo                      // 00000038EDCC: 0202080A
	v_add_co_ci_u32_e64 v5, null, s11, v5, vcc_lo              // 00000038EDD0: D5207C05 01AA0A0B
	global_store_b32 v[4:5], v3, off                           // 00000038EDD8: DC6A0000 007C0304
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000038EDE0: BF8700A1
	v_bfe_u32 v4, v3, 16, 1                                    // 00000038EDE4: D6100004 02052103
	.long 0xd7006a01                                           // 00000038EDEC: D7006A01
	v_cndmask_b32_e32 v1, s8, v1, vcc_lo                       // 00000038EDF0: 02020208
	v_add_co_ci_u32_e64 v2, null, s9, v2, vcc_lo               // 00000038EDF4: D5207C02 01AA0409
	s_delay_alu instid0(VALU_DEP_3)                            // 00000038EDFC: BF870003
	v_add3_u32 v3, v3, v4, 0x7fff                              // 00000038EE00: D6550003 03FE0903 00007FFF
	global_store_d16_hi_b16 v[1:2], v3, off                    // 00000038EE0C: DC960000 007C0301
	s_or_b32 exec_lo, exec_lo, s7                              // 00000038EE14: 8C7E077E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000038EE18: BF870009
	s_and_b32 vcc_lo, exec_lo, s6                              // 00000038EE1C: 8B6A067E
	s_cbranch_vccz 1243                                        // 00000038EE20: BFA304DB <_ZN7halogen12_GLOBAL__N_111k_hc6_fusedILi1EEEvNS0_5LqGrpEPKtliPKhS4_PtPfPyy+0x3b90>
	s_clause 0x3                                               // 00000038EE24: BF850003
	s_load_b32 s3, s[0:1], 0x120                               // 00000038EE28: F40000C0 F8000120
	s_load_b32 s4, s[0:1], 0x88                                // 00000038EE30: F4000100 F8000088
	s_load_b32 s5, s[0:1], 0xd0                                // 00000038EE38: F4000140 F80000D0
	s_load_b32 s6, s[0:1], 0x118                               // 00000038EE40: F4000180 F8000118
	v_lshrrev_b32_e32 v5, 5, v0                                // 00000038EE48: 320A0085
	v_dual_mov_b32 v17, 0 :: v_dual_and_b32 v16, 31, v0        // 00000038EE4C: CA240080 1110009F
	v_mov_b32_e32 v12, 0                                       // 00000038EE54: 7E180280
	v_dual_mov_b32 v30, 0 :: v_dual_mov_b32 v13, 0             // 00000038EE58: CA100080 1E0C0080
	s_waitcnt lgkmcnt(0)                                       // 00000038EE60: BF89FC07
	s_cmp_gt_i32 s3, 1                                         // 00000038EE64: BF028103
	s_cselect_b32 s7, -1, 0                                    // 00000038EE68: 980780C1
	s_cmp_ge_i32 s2, s4                                        // 00000038EE6C: BF030402
	s_cselect_b32 s4, -1, 0                                    // 00000038EE70: 980480C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000038EE74: BF870009
	s_and_b32 s4, s7, s4                                       // 00000038EE78: 8B040407
	s_cmp_gt_i32 s3, 2                                         // 00000038EE7C: BF028203
	v_cndmask_b32_e64 v1, 0, 1, s4                             // 00000038EE80: D5010001 00110280
	s_cselect_b32 s7, -1, 0                                    // 00000038EE88: 980780C1
	s_cmp_ge_i32 s2, s5                                        // 00000038EE8C: BF030502
	s_cselect_b32 s5, -1, 0                                    // 00000038EE90: 980580C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000038EE94: BF870009
	s_and_b32 s4, s7, s5                                       // 00000038EE98: 8B040507
	s_cmp_gt_i32 s3, 3                                         // 00000038EE9C: BF028303
	v_readfirstlane_b32 s5, v1                                 // 00000038EEA0: 7E0A0501
	s_cselect_b32 s3, -1, 0                                    // 00000038EEA4: 980380C1
	s_cmp_ge_i32 s2, s6                                        // 00000038EEA8: BF030602
	s_cselect_b32 s6, -1, 0                                    // 00000038EEAC: 980680C1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(SALU_CYCLE_1)// 00000038EEB0: BF8704D9
	s_and_b32 s3, s3, s6                                       // 00000038EEB4: 8B030603
	s_and_b32 s4, s4, exec_lo                                  // 00000038EEB8: 8B047E04
	s_cselect_b32 s4, 2, s5                                    // 00000038EEBC: 98040582
	s_and_b32 s3, s3, exec_lo                                  // 00000038EEC0: 8B037E03
	s_cselect_b32 s3, 3, s4                                    // 00000038EEC4: 98030483
	s_mulk_i32 s3, 0x48                                        // 00000038EEC8: B8030048
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000038EECC: BF870009
	s_add_u32 s4, s0, s3                                       // 00000038EED0: 80040300
	s_addc_u32 s5, s1, 0                                       // 00000038EED4: 82058001
	s_clause 0x1                                               // 00000038EED8: BF850001
	s_load_b64 s[6:7], s[4:5], 0x30                            // 00000038EEDC: F4040182 F8000030
	s_load_b32 s8, s[4:5], 0x40                                // 00000038EEE4: F4000202 F8000040
	s_waitcnt lgkmcnt(0)                                       // 00000038EEEC: BF89FC07
	.long 0xd451000e                                           // 00000038EEF0: D451000E
	v_cndmask_b32_e32 v0, s6, v137, vcc_lo                     // 00000038EEF4: 02011206
	s_and_b32 s0, s14, exec_lo                                 // 00000038EEF8: 8B007E0E
	s_cselect_b32 s3, 8, 2                                     // 00000038EEFC: 98038288
	s_cselect_b32 s15, 3, 1                                    // 00000038EF00: 980F8183
	v_cvt_f32_ubyte0_e32 v1, s3                                // 00000038EF04: 7E022203
	s_sub_i32 s8, s2, s8                                       // 00000038EF08: 81880802
	s_add_i32 s21, s3, -1                                      // 00000038EF0C: 8115C103
	s_ashr_i32 s9, s8, 31                                      // 00000038EF10: 86099F08
	s_and_b32 s11, s14, exec_lo                                // 00000038EF14: 8B0B7E0E
	v_rcp_iflag_f32_e32 v2, v1                                 // 00000038EF18: 7E045701
	s_cselect_b32 s20, 0, 2                                    // 00000038EF1C: 98148280
	s_ashr_i32 s24, s19, 31                                    // 00000038EF20: 86189F13
	s_lshl_b64 s[8:9], s[8:9], s20                             // 00000038EF24: 84881408
	v_lshrrev_b32_e32 v18, s15, v5                             // 00000038EF28: 32240A0F
	s_load_b64 s[0:1], s[4:5], null                            // 00000038EF2C: F4040002 F8000000
	v_mov_b32_e32 v1, 0                                        // 00000038EF34: 7E020280
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000038EF38: BF870292
	.long 0xd7000803                                           // 00000038EF3C: D7000803
	v_cndmask_b32_e32 v1, s8, v18, vcc_lo                      // 00000038EF40: 02022408
	v_readfirstlane_b32 s10, v2                                // 00000038EF44: 7E140502
	v_add_co_ci_u32_e64 v4, null, s9, 0, s8                    // 00000038EF48: D5207C04 00210009
	v_mov_b32_e32 v2, 0                                        // 00000038EF50: 7E040280
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000038EF54: BF870123
	s_mul_f32 s11, s10, 0x4f7ffffe                             // 00000038EF58: A20BFF0A 4F7FFFFE
	s_lshr_b32 s10, s24, 27                                    // 00000038EF60: 850A9B18
	v_cmp_gt_i64_e32 vcc_lo, s[6:7], v[3:4]                    // 00000038EF64: 7CA80606
	s_add_u32 s10, s18, s10                                    // 00000038EF68: 800A0A12
	s_cvt_u32_f32 s25, s11                                     // 00000038EF6C: BE99670B
	s_addc_u32 s11, s19, 0                                     // 00000038EF70: 820B8013
	s_sub_i32 s26, 0, s3                                       // 00000038EF74: 819A0380
	s_lshr_b64 s[22:23], s[10:11], 5                           // 00000038EF78: 8596850A
	s_mul_i32 s26, s26, s25                                    // 00000038EF7C: 961A191A
	s_add_i32 s10, s21, s22                                    // 00000038EF80: 810A1615
	s_mul_hi_u32 s11, s25, s26                                 // 00000038EF84: 968B1A19
	s_abs_i32 s23, s10                                         // 00000038EF88: BE97150A
	s_add_i32 s25, s25, s11                                    // 00000038EF8C: 81190B19
	s_ashr_i32 s10, s10, 31                                    // 00000038EF90: 860A9F0A
	s_mul_hi_u32 s11, s23, s25                                 // 00000038EF94: 968B1917
	v_dual_cndmask_b32 v4, 0, v4 :: v_dual_and_b32 v19, s21, v5// 00000038EF98: CA640880 04120A15
	s_mul_i32 s25, s11, s3                                     // 00000038EFA0: 9619030B
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000038EFA4: BF870009
	s_sub_i32 s23, s23, s25                                    // 00000038EFA8: 81971917
	s_add_i32 s25, s11, 1                                      // 00000038EFAC: 8119810B
	s_sub_i32 s26, s23, s3                                     // 00000038EFB0: 819A0317
	s_cmp_ge_u32 s23, s3                                       // 00000038EFB4: BF090317
	s_cselect_b32 s8, s25, s11                                 // 00000038EFB8: 98080B19
	s_cselect_b32 s9, s26, s23                                 // 00000038EFBC: 9809171A
	s_add_i32 s11, s8, 1                                       // 00000038EFC0: 810B8108
	s_cmp_ge_u32 s9, s3                                        // 00000038EFC4: BF090309
	s_cselect_b32 s8, s11, s8                                  // 00000038EFC8: 9808080B
	s_lshr_b32 s9, s19, 31                                     // 00000038EFCC: 85099F13
	s_xor_b32 s8, s8, s10                                      // 00000038EFD0: 8D080A08
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000038EFD4: BF870009
	s_sub_i32 s21, s8, s10                                     // 00000038EFD8: 81950A08
	s_add_u32 s8, s18, s9                                      // 00000038EFDC: 80080912
	s_addc_u32 s9, s19, 0                                      // 00000038EFE0: 82098013
	s_lshr_b32 s23, s24, 30                                    // 00000038EFE4: 85179E18
	s_ashr_i64 s[10:11], s[8:9], 1                             // 00000038EFE8: 868A8108
	s_add_u32 s8, s18, s23                                     // 00000038EFEC: 80081712
	s_addc_u32 s9, s19, 0                                      // 00000038EFF0: 82098013
	s_lshr_b32 s23, s24, 28                                    // 00000038EFF4: 85179C18
	s_ashr_i64 s[8:9], s[8:9], 2                               // 00000038EFF8: 86888208
	s_add_u32 s18, s18, s23                                    // 00000038EFFC: 80121712
	s_addc_u32 s19, s19, 0                                     // 00000038F000: 82138013
	.long 0xd72c0005                                           // 00000038F004: D72C0005
	v_cndmask_b32_e32 v0, v19, v21, vcc_lo                     // 00000038F008: 02002B13
	s_ashr_i64 s[18:19], s[18:19], 4                           // 00000038F00C: 86928412
	s_add_u32 s23, s8, s10                                     // 00000038F010: 80170A08
	s_addc_u32 s24, s9, s11                                    // 00000038F014: 82180B09
	s_add_u32 s18, s23, s18                                    // 00000038F018: 80121217
	s_addc_u32 s19, s24, s19                                   // 00000038F01C: 82131318
	s_add_u32 s18, s18, 15                                     // 00000038F020: 80128F12
	s_addc_u32 s19, s19, 0                                     // 00000038F024: 82138013
	v_dual_cndmask_b32 v3, 0, v3 :: v_dual_add_nc_u32 v6, s21, v5// 00000038F028: CA600680 03060A15
	s_ashr_i32 s23, s19, 31                                    // 00000038F030: 86179F13
	v_add_nc_u32_e32 v20, v5, v16                              // 00000038F034: 4A282105
	s_lshr_b32 s23, s23, 28                                    // 00000038F038: 85179C17
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000038F03C: BF870009
	s_add_u32 s18, s18, s23                                    // 00000038F040: 80121712
	s_addc_u32 s19, s19, 0                                     // 00000038F044: 82138013
	s_and_b32 s18, s18, -16                                    // 00000038F048: 8B12D012
	.long 0xd72c0007                                           // 00000038F04C: D72C0007
	v_cndmask_b32_e32 v1, s19, v3, vcc_lo                      // 00000038F050: 02020613
	.long 0xd72c0008                                           // 00000038F054: D72C0008
	v_cndmask_b32_e32 v1, s18, v4, vcc_lo                      // 00000038F058: 02020812
	s_waitcnt lgkmcnt(0)                                       // 00000038F05C: BF89FC07
	v_mad_u64_u32 v[9:10], null, s18, v3, s[0:1]               // 00000038F060: D6FE7C09 00020612
	v_min_i32_e32 v21, s22, v6                                 // 00000038F068: 222A0C16
	v_dual_mov_b32 v3, 0 :: v_dual_mov_b32 v4, 0               // 00000038F06C: CA100080 03040080
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000038F074: BF870212
	v_cmp_lt_i32_e32 vcc_lo, v20, v21                          // 00000038F078: 7C822B14
	v_add3_u32 v22, v7, v10, v8                                // 00000038F07C: D6550016 04221507
	s_and_saveexec_b32 s1, vcc_lo                              // 00000038F084: BE81206A
	s_cbranch_execz 39                                         // 00000038F088: BFA50027 <_ZN7halogen12_GLOBAL__N_111k_hc6_fusedILi1EEEvNS0_5LqGrpEPKtliPKhS4_PtPfPyy+0x2b28>
	v_lshlrev_b32_e32 v1, 4, v20                               // 00000038F08C: 30022884
	v_lshlrev_b32_e32 v4, 1, v20                               // 00000038F090: 30082881
	v_lshlrev_b32_e32 v3, 3, v20                               // 00000038F094: 30062883
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000038F098: BF870223
	v_ashrrev_i32_e32 v2, 31, v1                               // 00000038F09C: 3404029F
	.long 0xd7000001                                           // 00000038F0A0: D7000001
	v_cndmask_b32_e32 v1, v9, v1, vcc_lo                       // 00000038F0A4: 02020309
	v_and_b32_e32 v4, -4, v4                                   // 00000038F0A8: 360808C4
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000038F0AC: BF870214
	v_ashrrev_i32_e32 v8, 31, v3                               // 00000038F0B0: 3410069F
	v_add_co_ci_u32_e64 v2, null, v22, v2, s0                  // 00000038F0B4: D5207C02 00020516
	.long 0xd7000006                                           // 00000038F0BC: D7000006
	v_cndmask_b32_e32 v0, v9, v10, vcc_lo                      // 00000038F0C0: 02001509
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000038F0C4: BF8701A1
	v_add_co_ci_u32_e64 v7, null, s11, v22, s0                 // 00000038F0C8: D5207C07 00022C0B
	v_ashrrev_i32_e32 v12, 31, v4                              // 00000038F0D0: 3418089F
	.long 0xd700000a                                           // 00000038F0D4: D700000A
	v_cndmask_b32_e32 v0, v6, v8, vcc_lo                       // 00000038F0D8: 02001106
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000038F0DC: BF8700A1
	v_add_co_ci_u32_e64 v11, null, s9, v7, s0                  // 00000038F0E0: D5207C0B 00020E09
	.long 0xd7000006                                           // 00000038F0E8: D7000006
	v_cndmask_b32_e32 v1, v6, v3, vcc_lo                       // 00000038F0EC: 02020706
	v_add_co_ci_u32_e64 v7, null, v7, v8, s0                   // 00000038F0F0: D5207C07 00021107
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000038F0F8: BF870094
	.long 0xd700000a                                           // 00000038F0FC: D700000A
	v_cndmask_b32_e32 v1, v10, v4, vcc_lo                      // 00000038F100: 0202090A
	v_add_co_ci_u32_e64 v11, null, v11, v12, s0                // 00000038F104: D5207C0B 0002190B
	s_clause 0x2                                               // 00000038F10C: BF850002
	global_load_b128 v[1:4], v[1:2], off                       // 00000038F110: DC5E0000 017C0001
	global_load_b64 v[12:13], v[6:7], off                      // 00000038F118: DC560000 0C7C0006
	global_load_b32 v30, v[10:11], off                         // 00000038F120: DC520000 1E7C000A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000038F128: 8C7E017E
	s_and_saveexec_b32 s1, vcc_lo                              // 00000038F12C: BE81206A
	s_cbranch_execz 621                                        // 00000038F130: BFA5026D <_ZN7halogen12_GLOBAL__N_111k_hc6_fusedILi1EEEvNS0_5LqGrpEPKtliPKhS4_PtPfPyy+0x34e8>
	.long 0xd7006a17                                           // 00000038F134: D7006A17
	v_cndmask_b32_e32 v0, v9, v10, vcc_lo                      // 00000038F138: 02001509
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000038F13C: BF870231
	v_add_co_ci_u32_e64 v24, null, s11, v22, vcc_lo            // 00000038F140: D5207C18 01AA2C0B
	v_dual_mov_b32 v17, 0 :: v_dual_lshlrev_b32 v6, 5, v16     // 00000038F148: CA220080 11062085
	v_add_nc_u32_e32 v7, 32, v20                               // 00000038F150: 4A0E28A0
	.long 0xd7006a19                                           // 00000038F154: D7006A19
	v_cndmask_b32_e32 v0, v23, v8, vcc_lo                      // 00000038F158: 02001117
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000038F15C: BF870211
	v_add_co_ci_u32_e64 v26, null, s9, v24, vcc_lo             // 00000038F160: D5207C1A 01AA3009
	v_lshl_add_u32 v10, v5, 5, v6                              // 00000038F168: D646000A 04190B05
	s_delay_alu instid0(VALU_DEP_4)                            // 00000038F170: BF870004
	v_lshlrev_b32_e32 v27, 4, v7                               // 00000038F174: 30360E84
	s_waitcnt vmcnt(0)                                         // 00000038F178: BF8903F7
	v_dual_mov_b32 v31, v30 :: v_dual_lshlrev_b32 v28, 3, v7   // 00000038F17C: CA22011E 1F1C0E83
	v_lshlrev_b32_e32 v29, 1, v7                               // 00000038F184: 303A0E81
	s_mov_b32 s8, 0                                            // 00000038F188: BE880080
	s_branch 558                                               // 00000038F18C: BFA0022E <_ZN7halogen12_GLOBAL__N_111k_hc6_fusedILi1EEEvNS0_5LqGrpEPKtliPKhS4_PtPfPyy+0x3448>
	s_or_b32 exec_lo, exec_lo, s9                              // 00000038F190: 8C7E097E
	v_ashrrev_i32_e32 v11, 31, v10                             // 00000038F194: 3416149F
	v_lshlrev_b32_e32 v48, 2, v12                              // 00000038F198: 30601882
	v_lshrrev_b32_e32 v49, 4, v1                               // 00000038F19C: 32620284
	v_lshrrev_b32_e32 v50, 8, v1                               // 00000038F1A0: 32640288
	v_lshrrev_b32_e32 v51, 2, v12                              // 00000038F1A4: 32661882
	.long 0xd73c0020                                           // 00000038F1A8: D73C0020
	v_cndmask_b32_e32 v1, 1, v10, vcc_lo                       // 00000038F1AC: 02021481
	v_lshlrev_b32_e32 v11, 4, v12                              // 00000038F1B0: 30161884
	v_and_b32_e32 v48, 48, v48                                 // 00000038F1B4: 366060B0
	v_and_b32_e32 v52, 48, v12                                 // 00000038F1B8: 366818B0
	v_lshrrev_b32_e32 v53, 12, v1                              // 00000038F1BC: 326A028C
	v_and_b32_e32 v51, 48, v51                                 // 00000038F1C0: 366666B0
	.long 0xd700002c                                           // 00000038F1C4: D700002C
	v_cndmask_b32_e32 v1, s16, v32, vcc_lo                     // 00000038F1C8: 02024010
	s_delay_alu instid0(VALU_DEP_1)                            // 00000038F1CC: BF870001
	v_add_co_ci_u32_e64 v45, null, s17, v33, s0                // 00000038F1D0: D5207C2D 00024211
	v_and_b32_e32 v11, 48, v11                                 // 00000038F1D8: 361616B0
	v_and_or_b32 v48, v49, 15, v48                             // 00000038F1DC: D6570030 04C11F31
	v_and_or_b32 v49, v50, 15, v52                             // 00000038F1E4: D6570031 04D11F32
	s_clause 0x3                                               // 00000038F1EC: BF850003
	global_load_b128 v[32:35], v[44:45], off                   // 00000038F1F0: DC5E0000 207C002C
	global_load_b128 v[36:39], v[44:45], off offset:16         // 00000038F1F8: DC5E0010 247C002C
	global_load_b128 v[40:43], v[44:45], off offset:32         // 00000038F200: DC5E0020 287C002C
	global_load_b128 v[44:47], v[44:45], off offset:48         // 00000038F208: DC5E0030 2C7C002C
	v_and_or_b32 v50, v53, 15, v51                             // 00000038F210: D6570032 04CD1F35
	v_and_or_b32 v11, v1, 15, v11                              // 00000038F218: D657000B 042D1F01
	v_cvt_f32_ubyte0_e32 v48, v48                              // 00000038F220: 7E602330
	v_cvt_f32_ubyte0_e32 v49, v49                              // 00000038F224: 7E622331
	.long 0x7f6a3880                                           // 00000038F228: 7F6A3880
	v_cvt_f32_ubyte0_e32 v50, v50                              // 00000038F22C: 7E642332
	v_cvt_f32_ubyte0_e32 v11, v11                              // 00000038F230: 7E16230B
	v_fma_mix_f32 v48, v48, v30, v30 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038F234: CC206030 147A3D30
	v_fma_mix_f32 v49, v49, v30, v30 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038F23C: CC206031 147A3D31
	v_lshrrev_b32_e32 v55, 10, v12                             // 00000038F244: 326E188A
	v_fma_mix_f32 v50, v50, v30, v30 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038F248: CC206032 147A3D32
	v_fma_mix_f32 v11, v11, v30, v30 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038F250: CC20600B 147A3D0B
	v_bfe_u32 v52, v48, 16, 1                                  // 00000038F258: D6100034 02052130
	v_lshrrev_b32_e32 v60, 22, v12                             // 00000038F260: 32781896
	v_lshrrev_b32_e32 v59, 20, v2                              // 00000038F264: 32760494
	v_bfe_u32 v54, v50, 16, 1                                  // 00000038F268: D6100036 02052132
	v_bfe_u32 v51, v11, 16, 1                                  // 00000038F270: D6100033 0205210B
	v_add3_u32 v48, v48, v52, 0x7fff                           // 00000038F278: D6550030 03FE6930 00007FFF
	v_lshrrev_b32_e32 v52, 20, v1                              // 00000038F284: 32680294
	v_lshrrev_b32_e32 v61, 24, v2                              // 00000038F288: 327A0498
	v_add3_u32 v50, v50, v54, 0x7fff                           // 00000038F28C: D6550032 03FE6D32 00007FFF
	v_add3_u32 v11, v11, v51, 0x7fff                           // 00000038F298: D655000B 03FE670B 00007FFF
	v_bfe_u32 v51, v49, 16, 1                                  // 00000038F2A4: D6100033 02052131
	v_lshrrev_b32_e32 v54, 24, v1                              // 00000038F2AC: 326C0298
	v_lshlrev_b32_e32 v64, 4, v13                              // 00000038F2B0: 30801A84
	v_and_b32_e32 v60, 48, v60                                 // 00000038F2B4: 367878B0
	.long 0x7e6a398b                                           // 00000038F2B8: 7E6A398B
	v_add3_u32 v11, v49, v51, 0x7fff                           // 00000038F2BC: D655000B 03FE6731 00007FFF
	v_lshrrev_b32_e32 v49, 4, v12                              // 00000038F2C8: 32621884
	v_lshrrev_b32_e32 v51, 8, v12                              // 00000038F2CC: 32661888
	v_lshrrev_b32_e32 v57, 14, v12                             // 00000038F2D0: 3272188E
	v_and_or_b32 v48, 0xffff0000, v48, v53                     // 00000038F2D4: D6570030 04D660FF FFFF0000
	.long 0x7e6a398b                                           // 00000038F2E0: 7E6A398B
	v_lshrrev_b32_e32 v11, 6, v12                              // 00000038F2E4: 32161886
	v_and_b32_e32 v49, 48, v49                                 // 00000038F2E8: 366262B0
	v_and_b32_e32 v51, 48, v51                                 // 00000038F2EC: 366666B0
	v_lshrrev_b32_e32 v62, 28, v2                              // 00000038F2F0: 327C049C
	v_and_or_b32 v50, 0xffff0000, v50, v53                     // 00000038F2F4: D6570032 04D664FF FFFF0000
	.long 0x7e6a3981                                           // 00000038F300: 7E6A3981
	v_and_b32_e32 v11, 48, v11                                 // 00000038F304: 361616B0
	v_lshrrev_b32_e32 v1, 28, v1                               // 00000038F308: 3202029C
	v_and_or_b32 v51, v54, 15, v51                             // 00000038F30C: D6570033 04CD1F36
	v_lshlrev_b32_e32 v66, 2, v13                              // 00000038F314: 30841A82
	v_and_or_b32 v49, v53, 15, v49                             // 00000038F318: D6570031 04C51F35
	v_and_or_b32 v11, v52, 15, v11                             // 00000038F320: D657000B 042D1F34
	v_and_or_b32 v1, v55, 48, v1                               // 00000038F328: D6570001 04056137
	v_cvt_f32_ubyte0_e32 v51, v51                              // 00000038F330: 7E662333
	v_lshrrev_b32_e32 v52, 12, v12                             // 00000038F334: 3268188C
	v_cvt_f32_ubyte0_e32 v49, v49                              // 00000038F338: 7E622331
	v_cvt_f32_ubyte0_e32 v11, v11                              // 00000038F33C: 7E16230B
	v_cvt_f32_ubyte0_e32 v1, v1                                // 00000038F340: 7E022301
	v_fma_mix_f32 v51, v51, v30, v30 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038F344: CC206033 147A3D33
	v_and_or_b32 v59, v59, 15, v60                             // 00000038F34C: D657003B 04F11F3B
	v_fma_mix_f32 v49, v49, v30, v30 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038F354: CC206031 147A3D31
	v_fma_mix_f32 v11, v11, v30, v30 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038F35C: CC20600B 147A3D0B
	v_fma_mix_f32 v1, v1, v30, v30 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038F364: CC206001 147A3D01
	v_lshrrev_b32_e32 v65, 4, v3                               // 00000038F36C: 32820684
	v_and_b32_e32 v67, 48, v13                                 // 00000038F370: 36861AB0
	v_bfe_u32 v54, v49, 16, 1                                  // 00000038F374: D6100036 02052131
	v_bfe_u32 v56, v11, 16, 1                                  // 00000038F37C: D6100038 0205210B
	v_bfe_u32 v58, v1, 16, 1                                   // 00000038F384: D610003A 02052101
	v_cvt_f32_ubyte0_e32 v59, v59                              // 00000038F38C: 7E76233B
	v_lshrrev_b32_e32 v68, 12, v3                              // 00000038F390: 3288068C
	v_add3_u32 v49, v49, v54, 0x7fff                           // 00000038F394: D6550031 03FE6D31 00007FFF
	v_bfe_u32 v54, v51, 16, 1                                  // 00000038F3A0: D6100036 02052133
	v_add3_u32 v11, v11, v56, 0x7fff                           // 00000038F3A8: D655000B 03FE710B 00007FFF
	v_add3_u32 v1, v1, v58, 0x7fff                             // 00000038F3B4: D6550001 03FE7501 00007FFF
	v_lshrrev_b32_e32 v56, 18, v12                             // 00000038F3C0: 32701892
	.long 0x7e6a39b1                                           // 00000038F3C4: 7E6A39B1
	v_add3_u32 v49, v51, v54, 0x7fff                           // 00000038F3C8: D6550031 03FE6D33 00007FFF
	v_lshrrev_b32_e32 v51, 8, v2                               // 00000038F3D4: 32660488
	v_lshrrev_b32_e32 v54, 20, v12                             // 00000038F3D8: 326C1894
	v_and_b32_e32 v56, 48, v56                                 // 00000038F3DC: 367070B0
	v_and_or_b32 v11, 0xffff0000, v11, v53                     // 00000038F3E0: D657000B 04D616FF FFFF0000
	.long 0x7e6a39b1                                           // 00000038F3EC: 7E6A39B1
	v_lshrrev_b32_e32 v49, 12, v2                              // 00000038F3F0: 3262048C
	v_lshrrev_b32_e32 v58, 24, v12                             // 00000038F3F4: 32741898
	v_and_b32_e32 v54, 48, v54                                 // 00000038F3F8: 366C6CB0
	v_fma_mix_f32 v59, v59, v30, v30 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038F3FC: CC20603B 147A3D3B
	v_and_or_b32 v1, 0xffff0000, v1, v53                       // 00000038F404: D6570001 04D602FF FFFF0000
	.long 0x7e6a398c                                           // 00000038F410: 7E6A398C
	v_and_or_b32 v49, v49, 15, v56                             // 00000038F414: D6570031 04E11F31
	v_and_b32_e32 v58, 48, v58                                 // 00000038F41C: 367474B0
	v_lshrrev_b32_e32 v12, 26, v12                             // 00000038F420: 3218189A
	v_lshrrev_b32_e32 v56, 2, v13                              // 00000038F424: 32701A82
	v_and_b32_e32 v63, 48, v53                                 // 00000038F428: 367E6AB0
	v_cvt_f32_ubyte0_e32 v49, v49                              // 00000038F42C: 7E622331
	v_and_or_b32 v58, v61, 15, v58                             // 00000038F430: D657003A 04E91F3D
	v_and_or_b32 v12, v12, 48, v62                             // 00000038F438: D657000C 04F9610C
	v_and_b32_e32 v62, 48, v66                                 // 00000038F440: 367C84B0
	v_and_or_b32 v51, v51, 15, v63                             // 00000038F444: D6570033 04FD1F33
	v_fma_mix_f32 v49, v49, v30, v30 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038F44C: CC206031 147A3D31
	v_lshrrev_b32_e32 v63, 8, v3                               // 00000038F454: 327E0688
	v_cvt_f32_ubyte0_e32 v58, v58                              // 00000038F458: 7E74233A
	v_and_b32_e32 v56, 48, v56                                 // 00000038F45C: 367070B0
	v_cvt_f32_ubyte0_e32 v51, v51                              // 00000038F460: 7E662333
	v_bfe_u32 v78, v49, 16, 1                                  // 00000038F464: D610004E 02052131
	v_and_or_b32 v63, v63, 15, v67                             // 00000038F46C: D657003F 050D1F3F
	v_cvt_f32_ubyte0_e32 v12, v12                              // 00000038F474: 7E18230C
	v_and_or_b32 v60, v65, 15, v62                             // 00000038F478: D657003C 04F91F41
	v_fma_mix_f32 v51, v51, v30, v30 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038F480: CC206033 147A3D33
	v_add3_u32 v49, v49, v78, 0x7fff                           // 00000038F488: D6550031 03FE9D31 00007FFF
	v_fma_mix_f32 v58, v58, v30, v30 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038F494: CC20603A 147A3D3A
	v_and_or_b32 v56, v68, 15, v56                             // 00000038F49C: D6570038 04E11F44
	v_cvt_f32_ubyte0_e32 v61, v63                              // 00000038F4A4: 7E7A233F
	v_bfe_u32 v74, v51, 16, 1                                  // 00000038F4A8: D610004A 02052133
	v_fma_mix_f32 v12, v12, v30, v30 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038F4B0: CC20600C 147A3D0C
	v_cvt_f32_ubyte0_e32 v60, v60                              // 00000038F4B8: 7E78233C
	v_cvt_f32_ubyte0_e32 v56, v56                              // 00000038F4BC: 7E702338
	v_fma_mix_f32 v61, v61, v30, v30 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038F4C0: CC20603D 147A3D3D
	v_add3_u32 v51, v51, v74, 0x7fff                           // 00000038F4C8: D6550033 03FE9533 00007FFF
	v_bfe_u32 v63, v12, 16, 1                                  // 00000038F4D4: D610003F 0205210C
	v_fma_mix_f32 v60, v60, v30, v30 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038F4DC: CC20603C 147A3D3C
	v_fma_mix_f32 v56, v56, v30, v30 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038F4E4: CC206038 147A3D38
	v_lshrrev_b32_e32 v70, 4, v13                              // 00000038F4EC: 328C1A84
	.long 0x7e6a39b3                                           // 00000038F4F0: 7E6A39B3
	v_and_b32_e32 v51, 48, v64                                 // 00000038F4F4: 366680B0
	v_bfe_u32 v64, v59, 16, 1                                  // 00000038F4F8: D6100040 0205213B
	v_add3_u32 v12, v12, v63, 0x7fff                           // 00000038F500: D655000C 03FE7F0C 00007FFF
	v_lshrrev_b32_e32 v69, 8, v13                              // 00000038F50C: 328A1A88
	v_and_or_b32 v49, 0xffff0000, v49, v53                     // 00000038F510: D6570031 04D662FF FFFF0000
	.long 0x7e6a3982                                           // 00000038F51C: 7E6A3982
	v_and_or_b32 v51, v3, 15, v51                              // 00000038F520: D6570033 04CD1F03
	v_add3_u32 v59, v59, v64, 0x7fff                           // 00000038F528: D655003B 03FE813B 00007FFF
	v_lshrrev_b32_e32 v72, 6, v13                              // 00000038F534: 32901A86
	v_and_b32_e32 v63, 48, v70                                 // 00000038F538: 367E8CB0
	v_and_or_b32 v54, v53, 15, v54                             // 00000038F53C: D6570036 04D91F35
	v_cvt_f32_ubyte0_e32 v51, v51                              // 00000038F544: 7E662333
	v_lshrrev_b32_e32 v71, 20, v3                              // 00000038F548: 328E0694
	v_lshrrev_b32_e32 v73, 24, v3                              // 00000038F54C: 32920698
	v_and_b32_e32 v66, 48, v72                                 // 00000038F550: 368490B0
	v_cvt_f32_ubyte0_e32 v54, v54                              // 00000038F554: 7E6C2336
	v_fma_mix_f32 v51, v51, v30, v30 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038F558: CC206033 147A3D33
	v_and_b32_e32 v67, 48, v69                                 // 00000038F560: 36868AB0
	v_lshrrev_b32_e32 v76, 28, v3                              // 00000038F564: 3298069C
	v_lshrrev_b32_e32 v77, 10, v13                             // 00000038F568: 329A1A8A
	v_fma_mix_f32 v54, v54, v30, v30 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038F56C: CC206036 147A3D36
	v_and_or_b32 v66, v71, 15, v66                             // 00000038F574: D6570042 05091F47
	v_and_or_b32 v67, v73, 15, v67                             // 00000038F57C: D6570043 050D1F49
	v_and_b32_e32 v52, 48, v52                                 // 00000038F584: 366868B0
	v_and_or_b32 v71, v77, 48, v76                             // 00000038F588: D6570047 0531614D
	v_bfe_u32 v62, v54, 16, 1                                  // 00000038F590: D610003E 02052136
	v_cvt_f32_ubyte0_e32 v66, v66                              // 00000038F598: 7E842342
	v_cvt_f32_ubyte0_e32 v67, v67                              // 00000038F59C: 7E862343
	v_lshrrev_b32_e32 v55, 4, v2                               // 00000038F5A0: 326E0484
	v_cvt_f32_ubyte0_e32 v71, v71                              // 00000038F5A4: 7E8E2347
	v_add3_u32 v54, v54, v62, 0x7fff                           // 00000038F5A8: D6550036 03FE7D36 00007FFF
	v_bfe_u32 v62, v58, 16, 1                                  // 00000038F5B4: D610003E 0205213A
	v_fma_mix_f32 v66, v66, v30, v30 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038F5BC: CC206042 147A3D42
	v_fma_mix_f32 v67, v67, v30, v30 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038F5C4: CC206043 147A3D43
	v_fma_mix_f32 v71, v71, v30, v30 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038F5CC: CC206047 147A3D47
	.long 0x7e6a39b6                                           // 00000038F5D4: 7E6A39B6
	v_add3_u32 v54, v58, v62, 0x7fff                           // 00000038F5D8: D6550036 03FE7D3A 00007FFF
	v_bfe_u32 v58, v51, 16, 1                                  // 00000038F5E4: D610003A 02052133
	v_bfe_u32 v62, v60, 16, 1                                  // 00000038F5EC: D610003E 0205213C
	v_bfe_u32 v76, v66, 16, 1                                  // 00000038F5F4: D610004C 02052142
	v_and_or_b32 v59, 0xffff0000, v59, v53                     // 00000038F5FC: D657003B 04D676FF FFFF0000
	.long 0x7e6a39b6                                           // 00000038F608: 7E6A39B6
	v_add3_u32 v51, v51, v58, 0x7fff                           // 00000038F60C: D6550033 03FE7533 00007FFF
	v_bfe_u32 v54, v61, 16, 1                                  // 00000038F618: D6100036 0205213D
	v_bfe_u32 v58, v56, 16, 1                                  // 00000038F620: D610003A 02052138
	v_add3_u32 v60, v60, v62, 0x7fff                           // 00000038F628: D655003C 03FE7D3C 00007FFF
	v_and_or_b32 v12, 0xffff0000, v12, v53                     // 00000038F634: D657000C 04D618FF FFFF0000
	.long 0x7e6a39b3                                           // 00000038F640: 7E6A39B3
	v_add3_u32 v51, v61, v54, 0x7fff                           // 00000038F644: D6550033 03FE6D3D 00007FFF
	v_add3_u32 v56, v56, v58, 0x7fff                           // 00000038F650: D6550038 03FE7538 00007FFF
	v_bfe_u32 v77, v71, 16, 1                                  // 00000038F65C: D610004D 02052147
	v_add3_u32 v66, v66, v76, 0x7fff                           // 00000038F664: D6550042 03FE9942 00007FFF
	v_and_or_b32 v58, 0xffff0000, v60, v53                     // 00000038F670: D657003A 04D678FF FFFF0000
	.long 0x7e6a39b3                                           // 00000038F67C: 7E6A39B3
	v_and_b32_e32 v57, 48, v57                                 // 00000038F680: 367272B0
	v_add3_u32 v71, v71, v77, 0x7fff                           // 00000038F684: D6550047 03FE9B47 00007FFF
	v_and_or_b32 v2, v2, 15, v52                               // 00000038F690: D6570002 04D11F02
	v_lshrrev_b32_e32 v75, 12, v13                             // 00000038F698: 32961A8C
	v_and_or_b32 v56, 0xffff0000, v56, v53                     // 00000038F69C: D6570038 04D670FF FFFF0000
	.long 0x7e6a3983                                           // 00000038F6A8: 7E6A3983
	v_lshrrev_b32_e32 v51, 14, v13                             // 00000038F6AC: 32661A8E
	v_lshrrev_b32_e32 v62, 20, v13                             // 00000038F6B0: 327C1A94
	v_lshrrev_b32_e32 v64, 18, v13                             // 00000038F6B4: 32801A92
	v_lshrrev_b32_e32 v65, 24, v13                             // 00000038F6B8: 32821A98
	v_and_or_b32 v63, v53, 15, v63                             // 00000038F6BC: D657003F 04FD1F35
	v_lshrrev_b32_e32 v69, 22, v13                             // 00000038F6C4: 328A1A96
	v_lshrrev_b32_e32 v74, 26, v13                             // 00000038F6C8: 32941A9A
	v_cvt_f32_ubyte0_e32 v2, v2                                // 00000038F6CC: 7E042302
	v_lshrrev_b32_e32 v60, 8, v4                               // 00000038F6D0: 32780888
	v_cvt_f32_ubyte0_e32 v63, v63                              // 00000038F6D4: 7E7E233F
	v_lshrrev_b32_e32 v3, 12, v4                               // 00000038F6D8: 3206088C
	v_and_b32_e32 v54, 15, v4                                  // 00000038F6DC: 366C088F
	v_fma_mix_f32 v2, v2, v30, v30 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038F6E0: CC206002 147A3D02
	v_lshrrev_b32_e32 v61, 4, v4                               // 00000038F6E8: 327A0884
	v_fma_mix_f32 v63, v63, v30, v30 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038F6EC: CC20603F 147A3D3F
	v_lshrrev_b32_e32 v72, 28, v4                              // 00000038F6F4: 3290089C
	v_and_or_b32 v54, v75, 48, v54                             // 00000038F6F8: D6570036 04D9614B
	v_and_b32_e32 v51, 48, v51                                 // 00000038F700: 366666B0
	v_lshrrev_b32_e32 v68, 20, v4                              // 00000038F704: 32880894
	v_bfe_u32 v73, v63, 16, 1                                  // 00000038F708: D6100049 0205213F
	v_lshrrev_b32_e32 v70, 24, v4                              // 00000038F710: 328C0898
	v_and_b32_e32 v65, 48, v65                                 // 00000038F714: 368282B0
	.long 0x7f6839b5                                           // 00000038F718: 7F6839B5
	v_add_nc_u32_e32 v27, 0x200, v27                           // 00000038F71C: 4A3636FF 00000200
	v_add3_u32 v63, v63, v73, 0x7fff                           // 00000038F724: D655003F 03FE933F 00007FFF
	v_bfe_u32 v73, v67, 16, 1                                  // 00000038F730: D6100049 02052143
	v_add_nc_u32_e32 v28, 0x100, v28                           // 00000038F738: 4A3838FF 00000100
	v_add_nc_u32_e32 v29, 64, v29                              // 00000038F740: 4A3A3AC0
	v_add_nc_u32_e32 v10, 0x400, v10                           // 00000038F744: 4A1414FF 00000400
	.long 0x7e6a39bf                                           // 00000038F74C: 7E6A39BF
	v_add3_u32 v63, v67, v73, 0x7fff                           // 00000038F750: D655003F 03FE9343 00007FFF
	.long 0x7f8639b5                                           // 00000038F75C: 7F8639B5
	s_and_b32 s0, exec_lo, vcc_lo                              // 00000038F760: 8B006A7E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000038F764: BF870193
	v_and_or_b32 v66, 0xffff0000, v66, v53                     // 00000038F768: D6570042 04D684FF FFFF0000
	.long 0x7e6a39bf                                           // 00000038F774: 7E6A39BF
	s_or_b32 s8, s0, s8                                        // 00000038F778: 8C080800
	s_delay_alu instid0(VALU_DEP_1)                            // 00000038F77C: BF870001
	v_and_or_b32 v63, 0xffff0000, v71, v53                     // 00000038F780: D657003F 04D68EFF FFFF0000
	.long 0x7e6a398d                                           // 00000038F78C: 7E6A398D
	v_and_or_b32 v13, v55, 15, v57                             // 00000038F790: D657000D 04E51F37
	v_and_b32_e32 v57, 48, v62                                 // 00000038F798: 36727CB0
	v_and_b32_e32 v55, 48, v64                                 // 00000038F79C: 366E80B0
	v_and_b32_e32 v64, 48, v69                                 // 00000038F7A0: 36808AB0
	v_and_b32_e32 v62, 48, v53                                 // 00000038F7A4: 367C6AB0
	v_cvt_f32_ubyte0_e32 v13, v13                              // 00000038F7A8: 7E1A230D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000038F7AC: BF870194
	v_and_or_b32 v3, v3, 15, v55                               // 00000038F7B0: D6570003 04DD1F03
	v_and_or_b32 v60, v60, 15, v62                             // 00000038F7B8: D657003C 04F91F3C
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000038F7C0: BF870223
	v_fma_mix_f32 v13, v13, v30, v30 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038F7C4: CC20600D 147A3D0D
	v_bfe_u32 v62, v2, 16, 1                                   // 00000038F7CC: D610003E 02052102
	v_cvt_f32_ubyte0_e32 v3, v3                                // 00000038F7D4: 7E062303
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000038F7D8: BF870193
	v_bfe_u32 v55, v13, 16, 1                                  // 00000038F7DC: D6100037 0205210D
	v_add3_u32 v2, v2, v62, 0x7fff                             // 00000038F7E4: D6550002 03FE7D02 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000038F7F0: BF870193
	v_fma_mix_f32 v3, v3, v30, v30 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038F7F4: CC206003 147A3D03
	v_add3_u32 v13, v13, v55, 0x7fff                           // 00000038F7FC: D655000D 03FE6F0D 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000038F808: BF870093
	.long 0x7e863982                                           // 00000038F80C: 7E863982
	v_and_or_b32 v13, 0xffff0000, v13, v67                     // 00000038F810: D657000D 050E1AFF FFFF0000
	s_waitcnt vmcnt(3)                                         // 00000038F81C: BF890FF7
	v_dot2_f32_bf16 v32, v32, v48, 0                           // 00000038F820: CC1A4020 1A026120
	v_cvt_f32_ubyte0_e32 v48, v60                              // 00000038F828: 7E60233C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000038F82C: BF870112
	v_dot2_f32_bf16 v32, v33, v50, v32                         // 00000038F830: CC1A4020 1C826521
	v_fma_mix_f32 v33, v48, v30, v30 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038F838: CC206021 147A3D30
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000038F840: BF870112
	v_dot2_f32_bf16 v2, v34, v11, v32                          // 00000038F844: CC1A4002 1C821722
	v_bfe_u32 v11, v33, 16, 1                                  // 00000038F84C: D610000B 02052121
	v_and_or_b32 v32, v74, 48, v72                             // 00000038F854: D6570020 0521614A
	v_cvt_f32_ubyte0_e32 v34, v54                              // 00000038F85C: 7E442336
	s_delay_alu instid0(VALU_DEP_4)                            // 00000038F860: BF870004
	v_dot2_f32_bf16 v1, v35, v1, v2                            // 00000038F864: CC1A4001 1C0A0323
	v_bfe_u32 v2, v3, 16, 1                                    // 00000038F86C: D6100002 02052103
	v_add3_u32 v11, v33, v11, 0x7fff                           // 00000038F874: D655000B 03FE1721 00007FFF
	v_and_or_b32 v33, v61, 15, v51                             // 00000038F880: D6570021 04CD1F3D
	s_waitcnt vmcnt(2)                                         // 00000038F888: BF890BF7
	v_dot2_f32_bf16 v1, v36, v13, v1                           // 00000038F88C: CC1A4001 1C061B24
	v_add3_u32 v2, v3, v2, 0x7fff                              // 00000038F894: D6550002 03FE0503 00007FFF
	.long 0x7e6a398b                                           // 00000038F8A0: 7E6A398B
	v_cvt_f32_ubyte0_e32 v13, v32                              // 00000038F8A4: 7E1A2320
	v_cvt_f32_ubyte0_e32 v32, v33                              // 00000038F8A8: 7E402321
	v_dot2_f32_bf16 v1, v37, v49, v1                           // 00000038F8AC: CC1A4001 1C066325
	v_and_or_b32 v3, v68, 15, v64                              // 00000038F8B4: D6570003 05011F44
	v_and_or_b32 v2, 0xffff0000, v2, v53                       // 00000038F8BC: D6570002 04D604FF FFFF0000
	.long 0x7e6a3984                                           // 00000038F8C8: 7E6A3984
	v_fma_mix_f32 v4, v34, v30, v30 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038F8CC: CC206004 147A3D22
	v_dot2_f32_bf16 v1, v38, v59, v1                           // 00000038F8D4: CC1A4001 1C067726
	v_and_or_b32 v11, v70, 15, v65                             // 00000038F8DC: D657000B 05051F46
	v_fma_mix_f32 v32, v32, v30, v30 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038F8E4: CC206020 147A3D20
	v_and_or_b32 v33, v53, 15, v57                             // 00000038F8EC: D6570021 04E51F35
	v_cvt_f32_ubyte0_e32 v3, v3                                // 00000038F8F4: 7E062303
	v_dot2_f32_bf16 v1, v39, v12, v1                           // 00000038F8F8: CC1A4001 1C061927
	v_fma_mix_f32 v12, v13, v30, v30 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038F900: CC20600C 147A3D0D
	v_bfe_u32 v13, v4, 16, 1                                   // 00000038F908: D610000D 02052104
	v_cvt_f32_ubyte0_e32 v33, v33                              // 00000038F910: 7E422321
	v_cvt_f32_ubyte0_e32 v11, v11                              // 00000038F914: 7E16230B
	s_waitcnt vmcnt(1)                                         // 00000038F918: BF8907F7
	v_dot2_f32_bf16 v1, v40, v58, v1                           // 00000038F91C: CC1A4001 1C067528
	v_fma_mix_f32 v3, v3, v30, v30 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038F924: CC206003 147A3D03
	v_add3_u32 v4, v4, v13, 0x7fff                             // 00000038F92C: D6550004 03FE1B04 00007FFF
	v_fma_mix_f32 v13, v33, v30, v30 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038F938: CC20600D 147A3D21
	v_bfe_u32 v33, v32, 16, 1                                  // 00000038F940: D6100021 02052120
	v_dot2_f32_bf16 v1, v41, v56, v1                           // 00000038F948: CC1A4001 1C067129
	v_fma_mix_f32 v11, v11, v30, v30 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000038F950: CC20600B 147A3D0B
	.long 0x7e683984                                           // 00000038F958: 7E683984
	v_bfe_u32 v4, v13, 16, 1                                   // 00000038F95C: D6100004 0205210D
	v_add3_u32 v30, v32, v33, 0x7fff                           // 00000038F964: D655001E 03FE4320 00007FFF
	v_dot2_f32_bf16 v1, v42, v66, v1                           // 00000038F970: CC1A4001 1C06852A
	v_bfe_u32 v32, v3, 16, 1                                   // 00000038F978: D6100020 02052103
	v_bfe_u32 v33, v11, 16, 1                                  // 00000038F980: D6100021 0205210B
	v_add3_u32 v4, v13, v4, 0x7fff                             // 00000038F988: D6550004 03FE090D 00007FFF
	v_and_or_b32 v13, 0xffff0000, v30, v52                     // 00000038F994: D657000D 04D23CFF FFFF0000
	v_dot2_f32_bf16 v1, v43, v63, v1                           // 00000038F9A0: CC1A4001 1C067F2B
	v_bfe_u32 v30, v12, 16, 1                                  // 00000038F9A8: D610001E 0205210C
	v_add3_u32 v3, v3, v32, 0x7fff                             // 00000038F9B0: D6550003 03FE4103 00007FFF
	.long 0x7e6a3984                                           // 00000038F9BC: 7E6A3984
	v_add3_u32 v4, v11, v33, 0x7fff                            // 00000038F9C0: D6550004 03FE430B 00007FFF
	s_waitcnt vmcnt(0)                                         // 00000038F9CC: BF8903F7
	v_dot2_f32_bf16 v1, v44, v13, v1                           // 00000038F9D0: CC1A4001 1C061B2C
	v_add3_u32 v11, v12, v30, 0x7fff                           // 00000038F9D8: D655000B 03FE3D0C 00007FFF
	v_mov_b32_e32 v12, v14                                     // 00000038F9E4: 7E18030E
	v_and_or_b32 v3, 0xffff0000, v3, v53                       // 00000038F9E8: D6570003 04D606FF FFFF0000
	.long 0x7e6a3984                                           // 00000038F9F4: 7E6A3984
	v_dot2_f32_bf16 v1, v45, v2, v1                            // 00000038F9F8: CC1A4001 1C06052D
	v_dual_mov_b32 v2, v6 :: v_dual_mov_b32 v13, v15           // 00000038FA00: CA100106 020C010F
	v_mov_b32_e32 v30, v31                                     // 00000038FA08: 7E3C031F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000038FA0C: BF870214
	v_and_or_b32 v4, 0xffff0000, v11, v53                      // 00000038FA10: D6570004 04D616FF FFFF0000
	v_dot2_f32_bf16 v1, v46, v3, v1                            // 00000038FA1C: CC1A4001 1C06072E
	v_mov_b32_e32 v3, v7                                       // 00000038FA24: 7E060307
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000038FA28: BF870092
	v_dot2_f32_bf16 v1, v47, v4, v1                            // 00000038FA2C: CC1A4001 1C06092F
	v_dual_mov_b32 v4, v8 :: v_dual_add_f32 v17, v17, v1       // 00000038FA34: CA080108 04100311
	v_mov_b32_e32 v1, v5                                       // 00000038FA3C: 7E020305
	s_and_not1_b32 exec_lo, exec_lo, s8                        // 00000038FA40: 917E087E
	s_cbranch_execz 39                                         // 00000038FA44: BFA50027 <_ZN7halogen12_GLOBAL__N_111k_hc6_fusedILi1EEEvNS0_5LqGrpEPKtliPKhS4_PtPfPyy+0x34e4>
	s_delay_alu instid0(VALU_DEP_1)                            // 00000038FA48: BF870001
	v_dual_mov_b32 v5, v1 :: v_dual_add_nc_u32 v20, 32, v20    // 00000038FA4C: CA200101 051428A0
	v_dual_mov_b32 v6, v2 :: v_dual_mov_b32 v7, v3             // 00000038FA54: CA100102 06060103
	v_dual_mov_b32 v8, v4 :: v_dual_mov_b32 v15, v13           // 00000038FA5C: CA100104 080E010D
	v_mov_b32_e32 v14, v12                                     // 00000038FA64: 7E1C030C
	s_mov_b32 s9, exec_lo                                      // 00000038FA68: BE89007E
	v_cmp_ge_i32_e32 vcc_lo, v20, v21                          // 00000038FA6C: 7C8C2B14
	.long 0xd4c1007e                                           // 00000038FA70: D4C1007E
	v_cndmask_b32_e32 v1, v20, v21, vcc_lo                     // 00000038FA74: 02022B14
	s_cbranch_execz 64965                                      // 00000038FA78: BFA5FDC5 <_ZN7halogen12_GLOBAL__N_111k_hc6_fusedILi1EEEvNS0_5LqGrpEPKtliPKhS4_PtPfPyy+0x2b90>
	v_and_b32_e32 v7, -4, v29                                  // 00000038FA7C: 360E3AC4
	v_ashrrev_i32_e32 v6, 31, v27                              // 00000038FA80: 340C369F
	v_ashrrev_i32_e32 v8, 31, v28                              // 00000038FA84: 3410389F
	.long 0xd7000005                                           // 00000038FA88: D7000005
	v_cndmask_b32_e32 v1, v9, v27, vcc_lo                      // 00000038FA8C: 02023709
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000038FA90: BF870214
	v_ashrrev_i32_e32 v11, 31, v7                              // 00000038FA94: 34160E9F
	v_add_co_ci_u32_e64 v6, null, v22, v6, s0                  // 00000038FA98: D5207C06 00020D16
	.long 0xd700000e                                           // 00000038FAA0: D700000E
	v_cndmask_b32_e32 v1, v23, v28, vcc_lo                     // 00000038FAA4: 02023917
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000038FAA8: BF8700A1
	v_add_co_ci_u32_e64 v15, null, v24, v8, s0                 // 00000038FAAC: D5207C0F 00021118
	.long 0xd700001f                                           // 00000038FAB4: D700001F
	v_cndmask_b32_e32 v1, v25, v7, vcc_lo                      // 00000038FAB8: 02020F19
	v_add_co_ci_u32_e64 v32, null, v26, v11, s0                // 00000038FABC: D5207C20 0002171A
	s_clause 0x2                                               // 00000038FAC4: BF850002
	global_load_b128 v[5:8], v[5:6], off                       // 00000038FAC8: DC5E0000 057C0005
	global_load_b64 v[14:15], v[14:15], off                    // 00000038FAD0: DC560000 0E7C000E
	global_load_b32 v31, v[31:32], off                         // 00000038FAD8: DC520000 1F7C001F
	s_branch 64939                                             // 00000038FAE0: BFA0FDAB <_ZN7halogen12_GLOBAL__N_111k_hc6_fusedILi1EEEvNS0_5LqGrpEPKtliPKhS4_PtPfPyy+0x2b90>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000038FAE4: 8C7E087E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000038FAE8: BF8700C9
	s_or_b32 exec_lo, exec_lo, s1                              // 00000038FAEC: 8C7E017E
	s_waitcnt vmcnt(2)                                         // 00000038FAF0: BF890BF7
	.long 0xd71f0001                                           // 00000038FAF4: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 00000038FAF8: 020100C1
	s_mov_b32 s0, exec_lo                                      // 00000038FAFC: BE80007E
	v_xor_b32_e32 v2, 16, v1                                   // 00000038FB00: 3A040290
	v_xor_b32_e32 v3, 8, v1                                    // 00000038FB04: 3A060288
	v_xor_b32_e32 v4, 4, v1                                    // 00000038FB08: 3A080284
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000038FB0C: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 00000038FB10: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 00000038FB14: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v3                            // 00000038FB18: 7C9806A0
	v_cndmask_b32_e32 v3, v1, v3, vcc_lo                       // 00000038FB1C: 02060701
	v_cmp_gt_u32_e32 vcc_lo, 32, v4                            // 00000038FB20: 7C9808A0
	v_cndmask_b32_e32 v4, v1, v4, vcc_lo                       // 00000038FB24: 02080901
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000038FB28: BF870211
	v_lshlrev_b32_e32 v4, 2, v4                                // 00000038FB2C: 30080882
	v_lshlrev_b32_e32 v3, 2, v3                                // 00000038FB30: 30060682
	v_lshlrev_b32_e32 v2, 2, v2                                // 00000038FB34: 30040482
	ds_bpermute_b32 v2, v2, v17                                // 00000038FB38: DACC0000 02001102
	s_waitcnt lgkmcnt(0)                                       // 00000038FB40: BF89FC07
	v_add_f32_e32 v2, v17, v2                                  // 00000038FB44: 06040511
	ds_bpermute_b32 v3, v3, v2                                 // 00000038FB48: DACC0000 03000203
	s_waitcnt lgkmcnt(0)                                       // 00000038FB50: BF89FC07
	v_add_f32_e32 v2, v2, v3                                   // 00000038FB54: 06040702
	ds_bpermute_b32 v3, v4, v2                                 // 00000038FB58: DACC0000 03000204
	v_xor_b32_e32 v4, 2, v1                                    // 00000038FB60: 3A080282
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000038FB64: BF8700A1
	v_cmp_gt_u32_e32 vcc_lo, 32, v4                            // 00000038FB68: 7C9808A0
	v_cndmask_b32_e32 v4, v1, v4, vcc_lo                       // 00000038FB6C: 02080901
	v_lshlrev_b32_e32 v4, 2, v4                                // 00000038FB70: 30080882
	s_waitcnt lgkmcnt(0)                                       // 00000038FB74: BF89FC07
	v_add_f32_e32 v2, v2, v3                                   // 00000038FB78: 06040702
	ds_bpermute_b32 v3, v4, v2                                 // 00000038FB7C: DACC0000 03000204
	v_xor_b32_e32 v4, 1, v1                                    // 00000038FB84: 3A080281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000038FB88: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v4                            // 00000038FB8C: 7C9808A0
	s_waitcnt lgkmcnt(0)                                       // 00000038FB90: BF89FC07
	v_dual_cndmask_b32 v4, v1, v4 :: v_dual_add_f32 v1, v2, v3 // 00000038FB94: CA480901 04000702
	v_lshlrev_b32_e32 v2, 2, v4                                // 00000038FB9C: 30040882
	ds_bpermute_b32 v2, v2, v1                                 // 00000038FBA0: DACC0000 02000102
	v_cmpx_eq_u32_e32 0, v16                                   // 00000038FBA8: 7D942080
	s_cbranch_execz 9                                          // 00000038FBAC: BFA50009 <_ZN7halogen12_GLOBAL__N_111k_hc6_fusedILi1EEEvNS0_5LqGrpEPKtliPKhS4_PtPfPyy+0x35d4>
	v_lshlrev_b32_e32 v3, s15, v18                             // 00000038FBB0: 3006240F
	s_waitcnt lgkmcnt(0)                                       // 00000038FBB4: BF89FC07
	v_add_f32_e32 v1, v1, v2                                   // 00000038FBB8: 06020501
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000038FBBC: BF870092
	v_lshlrev_b32_e32 v3, 2, v3                                // 00000038FBC0: 30060682
	v_lshl_add_u32 v3, v19, 2, v3                              // 00000038FBC4: D6460003 040D0513
	ds_store_b32 v3, v1                                        // 00000038FBCC: D8340000 00000103
	s_or_b32 exec_lo, exec_lo, s0                              // 00000038FBD4: 8C7E007E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000038FBD8: BF870009
	s_and_b32 s0, s14, exec_lo                                 // 00000038FBDC: 8B007E0E
	s_cselect_b32 s0, 1, 4                                     // 00000038FBE0: 98008481
	s_mov_b32 s1, exec_lo                                      // 00000038FBE4: BE81007E
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000038FBE8: BF890007
	s_waitcnt_vscnt null, 0x0                                  // 00000038FBEC: BC7C0000
	s_barrier                                                  // 00000038FBF0: BFBD0000
	buffer_gl0_inv                                             // 00000038FBF4: E0AC0000 00000000
	.long 0xd4cc007e                                           // 00000038FBFC: D4CC007E
	v_cndmask_b32_e32 v1, s0, v0, vcc_lo                       // 00000038FC00: 02020000
	s_cbranch_execz 328                                        // 00000038FC04: BFA50148 <_ZN7halogen12_GLOBAL__N_111k_hc6_fusedILi1EEEvNS0_5LqGrpEPKtliPKhS4_PtPfPyy+0x3b28>
	s_load_b32 s0, s[4:5], 0x40                                // 00000038FC08: F4000002 F8000040
	v_mov_b32_e32 v3, 0                                        // 00000038FC10: 7E060280
	s_waitcnt lgkmcnt(0)                                       // 00000038FC14: BF89FC07
	s_sub_i32 s8, s2, s0                                       // 00000038FC18: 81880002
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000038FC1C: BF870499
	s_ashr_i32 s9, s8, 31                                      // 00000038FC20: 86099F08
	s_lshl_b64 s[8:9], s[8:9], s20                             // 00000038FC24: 84881408
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000038FC28: BF870099
	.long 0xd7000001                                           // 00000038FC2C: D7000001
	v_cndmask_b32_e32 v1, s8, v0, vcc_lo                       // 00000038FC30: 02020008
	v_add_co_ci_u32_e64 v2, null, s9, 0, s0                    // 00000038FC34: D5207C02 00010009
	s_delay_alu instid0(VALU_DEP_1)                            // 00000038FC3C: BF870001
	v_cmp_gt_i64_e32 vcc_lo, s[6:7], v[1:2]                    // 00000038FC40: 7CA80206
	s_and_b32 exec_lo, exec_lo, vcc_lo                         // 00000038FC44: 8B7E6A7E
	s_cbranch_execz 311                                        // 00000038FC48: BFA50137 <_ZN7halogen12_GLOBAL__N_111k_hc6_fusedILi1EEEvNS0_5LqGrpEPKtliPKhS4_PtPfPyy+0x3b28>
	v_lshlrev_b32_e32 v4, s15, v0                              // 00000038FC4C: 3008000F
	s_delay_alu instid0(VALU_DEP_1)                            // 00000038FC50: BF870001
	v_lshlrev_b32_e32 v4, 2, v4                                // 00000038FC54: 30080882
	ds_load_b32 v5, v4                                         // 00000038FC58: D8D80000 05000004
	v_add_nc_u32_e32 v4, 4, v4                                 // 00000038FC60: 4A080884
	s_add_i32 s3, s3, -1                                       // 00000038FC64: 8103C103
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000038FC68: BF870009
	s_cmp_eq_u32 s3, 0                                         // 00000038FC6C: BF068003
	s_waitcnt lgkmcnt(0)                                       // 00000038FC70: BF89FC07
	v_add_f32_e32 v3, v3, v5                                   // 00000038FC74: 06060B03
	s_cbranch_scc0 65527                                       // 00000038FC78: BFA1FFF7 <_ZN7halogen12_GLOBAL__N_111k_hc6_fusedILi1EEEvNS0_5LqGrpEPKtliPKhS4_PtPfPyy+0x3658>
	s_clause 0x1                                               // 00000038FC7C: BF850001
	s_load_b64 s[6:7], s[4:5], 0x38                            // 00000038FC80: F4040182 F8000038
	s_load_b64 s[2:3], s[4:5], 0x8                             // 00000038FC88: F4040082 F8000008
	s_mov_b32 s9, -1                                           // 00000038FC90: BE8900C1
	s_mov_b32 s8, 0                                            // 00000038FC94: BE880080
	s_mov_b32 s0, 0                                            // 00000038FC98: BE800080
	s_waitcnt lgkmcnt(0)                                       // 00000038FC9C: BF89FC07
	s_cmp_lt_i32 s7, 3                                         // 00000038FCA0: BF048307
	s_cbranch_scc1 159                                         // 00000038FCA4: BFA2009F <_ZN7halogen12_GLOBAL__N_111k_hc6_fusedILi1EEEvNS0_5LqGrpEPKtliPKhS4_PtPfPyy+0x3924>
	s_cmp_gt_i32 s7, 3                                         // 00000038FCA8: BF028307
	s_cbranch_scc0 60                                          // 00000038FCAC: BFA1003C <_ZN7halogen12_GLOBAL__N_111k_hc6_fusedILi1EEEvNS0_5LqGrpEPKtliPKhS4_PtPfPyy+0x37a0>
	s_cmp_gt_i32 s7, 4                                         // 00000038FCB0: BF028407
	s_cbranch_scc0 60                                          // 00000038FCB4: BFA1003C <_ZN7halogen12_GLOBAL__N_111k_hc6_fusedILi1EEEvNS0_5LqGrpEPKtliPKhS4_PtPfPyy+0x37a8>
	s_cmp_eq_u32 s7, 5                                         // 00000038FCB8: BF068507
	s_mov_b32 s0, -1                                           // 00000038FCBC: BE8000C1
	s_cbranch_scc0 53                                          // 00000038FCC0: BFA10035 <_ZN7halogen12_GLOBAL__N_111k_hc6_fusedILi1EEEvNS0_5LqGrpEPKtliPKhS4_PtPfPyy+0x3798>
	v_lshrrev_b32_e32 v4, 23, v2                               // 00000038FCC4: 32080497
	s_load_b64 s[4:5], s[4:5], 0x10                            // 00000038FCC8: F4040102 F8000010
	v_mov_b32_e32 v8, s3                                       // 00000038FCD0: 7E100203
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000038FCD4: BF870092
	.long 0xd7006a04                                           // 00000038FCD8: D7006A04
	v_cndmask_b32_e32 v1, v1, v4, vcc_lo                       // 00000038FCDC: 02020901
	v_add_co_ci_u32_e64 v6, null, 0, v2, vcc_lo                // 00000038FCE0: D5207C06 01AA0480
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000038FCE8: BF870092
	v_and_b32_e32 v7, 0xfffffe00, v4                           // 00000038FCEC: 360E08FF FFFFFE00
	.long 0xd7016a04                                           // 00000038FCF4: D7016A04
	v_cndmask_b32_e32 v1, v1, v7, vcc_lo                       // 00000038FCF8: 02020F01
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000038FCFC: BF870111
	v_sub_co_ci_u32_e64 v5, null, v2, v6, vcc_lo               // 00000038FD00: D5217C05 01AA0D02
	.long 0xd7000009                                           // 00000038FD08: D7000009
	v_cndmask_b32_e32 v1, 0xffffff00, v4, vcc_lo               // 00000038FD0C: 020208FF FFFFFF00
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 00000038FD14: BF870152
	v_cmp_gt_i64_e32 vcc_lo, 0x100, v[4:5]                     // 00000038FD18: 7CA808FF 00000100
	v_add_co_ci_u32_e64 v10, null, -1, v5, s0                  // 00000038FD20: D5207C0A 00020AC1
	v_mov_b32_e32 v11, s2                                      // 00000038FD28: 7E160202
	s_mov_b32 s0, 0                                            // 00000038FD2C: BE800080
	s_waitcnt lgkmcnt(0)                                       // 00000038FD30: BF89FC07
	v_dual_cndmask_b32 v8, s5, v8 :: v_dual_cndmask_b32 v5, v10, v5// 00000038FD34: CA521005 08040B0A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000038FD3C: BF870122
	v_dual_cndmask_b32 v4, v9, v4 :: v_dual_cndmask_b32 v9, s4, v11// 00000038FD40: CA520909 04081604
	v_bfe_u32 v10, v3, 16, 1                                   // 00000038FD48: D610000A 02052103
	.long 0xd73c0004                                           // 00000038FD50: D73C0004
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 00000038FD54: 02020881
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000038FD58: BF870093
	.long 0xd7006a07                                           // 00000038FD5C: D7006A07
	v_cndmask_b32_e32 v1, v9, v7, vcc_lo                       // 00000038FD60: 02020F09
	v_add_co_ci_u32_e64 v6, null, v8, v6, vcc_lo               // 00000038FD64: D5207C06 01AA0D08
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000038FD6C: BF870194
	v_add3_u32 v8, v3, v10, 0x7fff                             // 00000038FD70: D6550008 03FE1503 00007FFF
	.long 0xd7006a04                                           // 00000038FD7C: D7006A04
	v_cndmask_b32_e32 v1, v7, v4, vcc_lo                       // 00000038FD80: 02020907
	s_delay_alu instid0(VALU_DEP_1)                            // 00000038FD84: BF870001
	v_add_co_ci_u32_e64 v5, null, v6, v5, vcc_lo               // 00000038FD88: D5207C05 01AA0B06
	global_store_d16_hi_b16 v[4:5], v8, off                    // 00000038FD90: DC960000 007C0804
	s_mov_b32 s4, 0                                            // 00000038FD98: BE840080
	s_branch 3                                                 // 00000038FD9C: BFA00003 <_ZN7halogen12_GLOBAL__N_111k_hc6_fusedILi1EEEvNS0_5LqGrpEPKtliPKhS4_PtPfPyy+0x37ac>
	s_mov_b32 s4, -1                                           // 00000038FDA0: BE8400C1
	s_branch 42                                                // 00000038FDA4: BFA0002A <_ZN7halogen12_GLOBAL__N_111k_hc6_fusedILi1EEEvNS0_5LqGrpEPKtliPKhS4_PtPfPyy+0x3850>
	s_mov_b32 s4, -1                                           // 00000038FDA8: BE8400C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000038FDAC: BF870009
	s_and_b32 vcc_lo, exec_lo, s4                              // 00000038FDB0: 8B6A047E
	s_cbranch_vccz 37                                          // 00000038FDB4: BFA30025 <_ZN7halogen12_GLOBAL__N_111k_hc6_fusedILi1EEEvNS0_5LqGrpEPKtliPKhS4_PtPfPyy+0x384c>
	v_mul_f32_e32 v4, 0xbfb8aa3b, v3                           // 00000038FDB8: 100806FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000038FDC0: BF870291
	v_exp_f32_e32 v4, v4                                       // 00000038FDC4: 7E084B04
	v_add_f32_e32 v6, 1.0, v4                                  // 00000038FDC8: 060C08F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000038FDCC: BF870121
	v_div_scale_f32 v4, null, v6, v6, 1.0                      // 00000038FDD0: D6FC7C04 03CA0D06
	v_div_scale_f32 v8, vcc_lo, 1.0, v6, 1.0                   // 00000038FDD8: D6FC6A08 03CA0CF2
	v_rcp_f32_e32 v5, v4                                       // 00000038FDE0: 7E0A5504
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000038FDE4: BF870095
	v_fma_f32 v7, -v4, v5, 1.0                                 // 00000038FDE8: D6130007 23CA0B04
	v_fmac_f32_e32 v5, v7, v5                                  // 00000038FDF0: 560A0B07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000038FDF4: BF870091
	v_mul_f32_e32 v7, v8, v5                                   // 00000038FDF8: 100E0B08
	v_fma_f32 v9, -v4, v7, v8                                  // 00000038FDFC: D6130009 24220F04
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000038FE04: BF870091
	v_fmac_f32_e32 v7, v9, v5                                  // 00000038FE08: 560E0B09
	v_fma_f32 v4, -v4, v7, v8                                  // 00000038FE0C: D6130004 24220F04
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000038FE14: BF870121
	v_div_fmas_f32 v7, v4, v5, v7                              // 00000038FE18: D6370007 041E0B04
	.long 0xd73c0004                                           // 00000038FE20: D73C0004
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 00000038FE24: 02020282
	v_div_fixup_f32 v6, v7, v6, 1.0                            // 00000038FE28: D6270006 03CA0D07
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000038FE30: BF870092
	.long 0xd7006a04                                           // 00000038FE34: D7006A04
	v_cndmask_b32_e32 v1, s2, v4, vcc_lo                       // 00000038FE38: 02020802
	v_add_co_ci_u32_e64 v5, null, s3, v5, vcc_lo               // 00000038FE3C: D5207C05 01AA0A03
	global_store_b32 v[4:5], v6, off                           // 00000038FE44: DC6A0000 007C0604
	s_mov_b32 s4, 0                                            // 00000038FE4C: BE840080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000038FE50: BF870009
	s_and_b32 vcc_lo, exec_lo, s4                              // 00000038FE54: 8B6A047E
	s_cbranch_vccz 49                                          // 00000038FE58: BFA30031 <_ZN7halogen12_GLOBAL__N_111k_hc6_fusedILi1EEEvNS0_5LqGrpEPKtliPKhS4_PtPfPyy+0x3920>
	v_bfe_u32 v4, v3, 16, 1                                    // 00000038FE5C: D6100004 02052103
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000038FE64: BF870091
	v_add3_u32 v4, v3, v4, 0x7fff                              // 00000038FE68: D6550004 03FE0903 00007FFF
	v_and_b32_e32 v4, 0xffff0000, v4                           // 00000038FE74: 360808FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000038FE7C: BF870091
	v_mul_f32_e32 v4, s6, v4                                   // 00000038FE80: 10080806
	v_mul_f32_e32 v4, 0xbfb8aa3b, v4                           // 00000038FE84: 100808FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000038FE8C: BF870291
	v_exp_f32_e32 v4, v4                                       // 00000038FE90: 7E084B04
	v_add_f32_e32 v4, 1.0, v4                                  // 00000038FE94: 060808F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000038FE98: BF870121
	v_div_scale_f32 v5, null, v4, v4, 1.0                      // 00000038FE9C: D6FC7C05 03CA0904
	v_div_scale_f32 v8, vcc_lo, 1.0, v4, 1.0                   // 00000038FEA4: D6FC6A08 03CA08F2
	v_rcp_f32_e32 v6, v5                                       // 00000038FEAC: 7E0C5505
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000038FEB0: BF870095
	v_fma_f32 v7, -v5, v6, 1.0                                 // 00000038FEB4: D6130007 23CA0D05
	v_fmac_f32_e32 v6, v7, v6                                  // 00000038FEBC: 560C0D07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000038FEC0: BF870091
	v_mul_f32_e32 v7, v8, v6                                   // 00000038FEC4: 100E0D08
	v_fma_f32 v9, -v5, v7, v8                                  // 00000038FEC8: D6130009 24220F05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000038FED0: BF870091
	v_fmac_f32_e32 v7, v9, v6                                  // 00000038FED4: 560E0D09
	v_fma_f32 v5, -v5, v7, v8                                  // 00000038FED8: D6130005 24220F05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000038FEE0: BF870091
	v_div_fmas_f32 v5, v5, v6, v7                              // 00000038FEE4: D6370005 041E0D05
	v_div_fixup_f32 v6, v5, v4, 1.0                            // 00000038FEEC: D6270006 03CA0905
	.long 0xd73c0004                                           // 00000038FEF4: D73C0004
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 00000038FEF8: 02020282
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000038FEFC: BF870112
	v_add_f32_e32 v6, v6, v6                                   // 00000038FF00: 060C0D06
	.long 0xd7006a04                                           // 00000038FF04: D7006A04
	v_cndmask_b32_e32 v1, s2, v4, vcc_lo                       // 00000038FF08: 02020802
	s_delay_alu instid0(VALU_DEP_1)                            // 00000038FF0C: BF870001
	v_add_co_ci_u32_e64 v5, null, s3, v5, vcc_lo               // 00000038FF10: D5207C05 01AA0A03
	global_store_b32 v[4:5], v6, off                           // 00000038FF18: DC6A0000 007C0604
	s_mov_b32 s9, 0                                            // 00000038FF20: BE890080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000038FF24: BF870009
	s_and_b32 vcc_lo, exec_lo, s9                              // 00000038FF28: 8B6A097E
	s_cbranch_vccz 61                                          // 00000038FF2C: BFA3003D <_ZN7halogen12_GLOBAL__N_111k_hc6_fusedILi1EEEvNS0_5LqGrpEPKtliPKhS4_PtPfPyy+0x3a24>
	s_cmp_gt_i32 s7, 1                                         // 00000038FF30: BF028107
	s_mov_b32 s4, -1                                           // 00000038FF34: BE8400C1
	s_cbranch_scc0 53                                          // 00000038FF38: BFA10035 <_ZN7halogen12_GLOBAL__N_111k_hc6_fusedILi1EEEvNS0_5LqGrpEPKtliPKhS4_PtPfPyy+0x3a10>
	v_bfe_u32 v4, v3, 16, 1                                    // 00000038FF3C: D6100004 02052103
	s_mov_b32 s4, 0                                            // 00000038FF44: BE840080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000038FF48: BF870091
	v_add3_u32 v4, v3, v4, 0x7fff                              // 00000038FF4C: D6550004 03FE0903 00007FFF
	v_and_b32_e32 v4, 0xffff0000, v4                           // 00000038FF58: 360808FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000038FF60: BF870091
	v_mul_f32_e32 v4, 0xbfb8aa3b, v4                           // 00000038FF64: 100808FF BFB8AA3B
	v_exp_f32_e32 v4, v4                                       // 00000038FF6C: 7E084B04
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000038FF70: BF870095
	v_add_f32_e32 v4, 1.0, v4                                  // 00000038FF74: 060808F2
	v_div_scale_f32 v5, null, v4, v4, 1.0                      // 00000038FF78: D6FC7C05 03CA0904
	v_div_scale_f32 v8, vcc_lo, 1.0, v4, 1.0                   // 00000038FF80: D6FC6A08 03CA08F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000038FF88: BF870292
	v_rcp_f32_e32 v6, v5                                       // 00000038FF8C: 7E0C5505
	v_fma_f32 v7, -v5, v6, 1.0                                 // 00000038FF90: D6130007 23CA0D05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000038FF98: BF870091
	v_fmac_f32_e32 v6, v7, v6                                  // 00000038FF9C: 560C0D07
	v_mul_f32_e32 v7, v8, v6                                   // 00000038FFA0: 100E0D08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000038FFA4: BF870091
	v_fma_f32 v9, -v5, v7, v8                                  // 00000038FFA8: D6130009 24220F05
	v_fmac_f32_e32 v7, v9, v6                                  // 00000038FFB0: 560E0D09
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000038FFB4: BF870091
	v_fma_f32 v5, -v5, v7, v8                                  // 00000038FFB8: D6130005 24220F05
	v_div_fmas_f32 v5, v5, v6, v7                              // 00000038FFC0: D6370005 041E0D05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000038FFC8: BF870121
	v_div_fixup_f32 v6, v5, v4, 1.0                            // 00000038FFCC: D6270006 03CA0905
	.long 0xd73c0004                                           // 00000038FFD4: D73C0004
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 00000038FFD8: 02020281
	v_bfe_u32 v7, v6, 16, 1                                    // 00000038FFDC: D6100007 02052106
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000038FFE4: BF870092
	.long 0xd7006a04                                           // 00000038FFE8: D7006A04
	v_cndmask_b32_e32 v1, s2, v4, vcc_lo                       // 00000038FFEC: 02020802
	v_add_co_ci_u32_e64 v5, null, s3, v5, vcc_lo               // 00000038FFF0: D5207C05 01AA0A03
	s_delay_alu instid0(VALU_DEP_3)                            // 00000038FFF8: BF870003
	v_add3_u32 v6, v6, v7, 0x7fff                              // 00000038FFFC: D6550006 03FE0F06 00007FFF
	global_store_d16_hi_b16 v[4:5], v6, off                    // 000000390008: DC960000 007C0604
	s_and_not1_b32 vcc_lo, exec_lo, s4                         // 000000390010: 916A047E
	s_cbranch_vccnz 3                                          // 000000390014: BFA40003 <_ZN7halogen12_GLOBAL__N_111k_hc6_fusedILi1EEEvNS0_5LqGrpEPKtliPKhS4_PtPfPyy+0x3a24>
	s_cmp_lg_u32 s7, 1                                         // 000000390018: BF078107
	s_mov_b32 s8, -1                                           // 00000039001C: BE8800C1
	s_cselect_b32 s0, -1, 0                                    // 000000390020: 980080C1
	v_bfe_u32 v4, v3, 16, 1                                    // 000000390024: D6100004 02052103
	.long 0xd73c0001                                           // 00000039002C: D73C0001
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 000000390030: 02020281
	s_and_b32 vcc_lo, exec_lo, s0                              // 000000390034: 8B6A007E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000390038: BF870002
	v_add3_u32 v3, v3, v4, 0x7fff                              // 00000039003C: D6550003 03FE0903 00007FFF
	s_cbranch_vccz 8                                           // 000000390048: BFA30008 <_ZN7halogen12_GLOBAL__N_111k_hc6_fusedILi1EEEvNS0_5LqGrpEPKtliPKhS4_PtPfPyy+0x3a6c>
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000039004C: BF870092
	.long 0xd7006a04                                           // 000000390050: D7006A04
	v_cndmask_b32_e32 v1, s2, v1, vcc_lo                       // 000000390054: 02020202
	v_add_co_ci_u32_e64 v5, null, s3, v2, vcc_lo               // 000000390058: D5207C05 01AA0403
	s_mov_b32 s8, 0                                            // 000000390060: BE880080
	global_store_d16_hi_b16 v[4:5], v3, off                    // 000000390064: DC960000 007C0304
	s_and_not1_b32 vcc_lo, exec_lo, s8                         // 00000039006C: 916A087E
	s_cbranch_vccnz 45                                         // 000000390070: BFA4002D <_ZN7halogen12_GLOBAL__N_111k_hc6_fusedILi1EEEvNS0_5LqGrpEPKtliPKhS4_PtPfPyy+0x3b28>
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000390074: BF870091
	v_and_b32_e32 v3, 0xffff0000, v3                           // 000000390078: 360606FF FFFF0000
	v_mul_f32_e32 v3, s6, v3                                   // 000000390080: 10060606
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000390084: BF870091
	v_mul_f32_e32 v4, 0xbfb8aa3b, v3                           // 000000390088: 100806FF BFB8AA3B
	v_exp_f32_e32 v4, v4                                       // 000000390090: 7E084B04
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000390094: BF870095
	v_add_f32_e32 v4, 1.0, v4                                  // 000000390098: 060808F2
	v_div_scale_f32 v5, null, v4, v4, v3                       // 00000039009C: D6FC7C05 040E0904
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000003900A4: BF870291
	v_rcp_f32_e32 v6, v5                                       // 0000003900A8: 7E0C5505
	v_fma_f32 v7, -v5, v6, 1.0                                 // 0000003900AC: D6130007 23CA0D05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003900B4: BF8700A1
	v_fmac_f32_e32 v6, v7, v6                                  // 0000003900B8: 560C0D07
	v_div_scale_f32 v8, vcc_lo, v3, v4, v3                     // 0000003900BC: D6FC6A08 040E0903
	v_mul_f32_e32 v7, v8, v6                                   // 0000003900C4: 100E0D08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003900C8: BF870091
	v_fma_f32 v9, -v5, v7, v8                                  // 0000003900CC: D6130009 24220F05
	v_fmac_f32_e32 v7, v9, v6                                  // 0000003900D4: 560E0D09
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003900D8: BF870091
	v_fma_f32 v5, -v5, v7, v8                                  // 0000003900DC: D6130005 24220F05
	v_div_fmas_f32 v5, v5, v6, v7                              // 0000003900E4: D6370005 041E0D05
	.long 0xd7006a01                                           // 0000003900EC: D7006A01
	v_cndmask_b32_e32 v1, s2, v1, vcc_lo                       // 0000003900F0: 02020202
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003900F4: BF870191
	v_add_co_ci_u32_e64 v2, null, s3, v2, vcc_lo               // 0000003900F8: D5207C02 01AA0403
	v_div_fixup_f32 v3, v5, v4, v3                             // 000000390100: D6270003 040E0905
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000390108: BF870091
	v_bfe_u32 v4, v3, 16, 1                                    // 00000039010C: D6100004 02052103
	v_add3_u32 v3, v3, v4, 0x7fff                              // 000000390114: D6550003 03FE0903 00007FFF
	global_store_d16_hi_b16 v[1:2], v3, off                    // 000000390120: DC960000 007C0301
	s_or_b32 exec_lo, exec_lo, s1                              // 000000390128: 8C7E017E
	s_waitcnt_vscnt null, 0x0                                  // 00000039012C: BC7C0000
	s_barrier                                                  // 000000390130: BFBD0000
	buffer_gl0_inv                                             // 000000390134: E0AC0000 00000000
	s_mov_b32 s0, exec_lo                                      // 00000039013C: BE80007E
	v_cmpx_eq_u32_e32 0, v0                                    // 000000390140: 7D940080
	s_cbranch_execz 18                                         // 000000390144: BFA50012 <_ZN7halogen12_GLOBAL__N_111k_hc6_fusedILi1EEEvNS0_5LqGrpEPKtliPKhS4_PtPfPyy+0x3b90>
	s_mov_b32 s0, exec_lo                                      // 000000390148: BE80007E
	buffer_gl1_inv                                             // 00000039014C: E0B00000 00000000
	buffer_gl0_inv                                             // 000000390154: E0AC0000 00000000
	.long 0xd71f0000                                           // 00000039015C: D71F0000
	v_cndmask_b32_e32 v0, s0, v128, vcc_lo                     // 000000390160: 02010000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000390164: BF8704A1
	v_cmp_eq_u32_e32 vcc_lo, 0, v0                             // 000000390168: 7C940080
	s_and_b32 s1, exec_lo, vcc_lo                              // 00000039016C: 8B016A7E
	s_mov_b32 exec_lo, s1                                      // 000000390170: BEFE0001
	s_cbranch_execz 6                                          // 000000390174: BFA50006 <_ZN7halogen12_GLOBAL__N_111k_hc6_fusedILi1EEEvNS0_5LqGrpEPKtliPKhS4_PtPfPyy+0x3b90>
	s_bcnt1_i32_b32 s0, s0                                     // 000000390178: BE801800
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000039017C: BF870009
	v_dual_mov_b32 v1, 0 :: v_dual_mov_b32 v0, s0              // 000000390180: CA100080 01000000
	global_atomic_add_u64 v1, v[0:1], s[12:13]                 // 000000390188: DD0E0000 000C0001
	s_endpgm                                                   // 000000390190: BFB00000
		...

