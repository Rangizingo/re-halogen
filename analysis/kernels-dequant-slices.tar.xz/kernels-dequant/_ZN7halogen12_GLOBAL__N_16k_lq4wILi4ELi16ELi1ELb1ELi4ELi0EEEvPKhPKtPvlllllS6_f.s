0000000000f93800 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi16ELi1ELb1ELi4ELi0EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi16ELi1ELb1ELi4ELi0EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 000000F93800: F4100100 F8000000
	v_and_b32_e32 v16, 15, v0                                  // 000000F93808: 3620008F
	v_lshrrev_b32_e32 v1, 4, v0                                // 000000F9380C: 32020084
	s_ashr_i32 s3, s2, 31                                      // 000000F93810: 86039F02
	.long 0x7f103880                                           // 000000F93814: 7F103880
	s_lshl_b64 s[0:1], s[2:3], 4                               // 000000F93818: 84808402
	v_mov_b32_e32 v17, 0                                       // 000000F9381C: 7E220280
	v_dual_mov_b32 v10, s1 :: v_dual_lshlrev_b32 v3, 2, v1     // 000000F93820: CA220001 0A020282
	v_or_b32_e32 v9, s0, v1                                    // 000000F93828: 38120200
	v_dual_mov_b32 v1, 0 :: v_dual_lshlrev_b32 v2, 2, v16      // 000000F9382C: CA220080 01022082
	s_waitcnt lgkmcnt(0)                                       // 000000F93834: BF89FC07
	s_clause 0x1                                               // 000000F93838: BF850001
	global_load_b32 v4, v2, s[4:5]                             // 000000F9383C: DC520000 04040002
	global_load_b32 v7, v3, s[4:5]                             // 000000F93844: DC520000 07040003
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[9:10]                 // 000000F9384C: 7CA8120C
	s_add_u32 s2, s4, s14                                      // 000000F93850: 80020E04
	s_addc_u32 s3, s5, s15                                     // 000000F93854: 82030F05
	s_lshr_b32 s0, s11, 31                                     // 000000F93858: 85009F0B
	v_mov_b32_e32 v18, 0                                       // 000000F9385C: 7E240280
	s_add_u32 s14, s10, s0                                     // 000000F93860: 800E000A
	v_cndmask_b32_e32 v11, 0, v9, vcc_lo                       // 000000F93864: 02161280
	v_cndmask_b32_e64 v14, 0, s1, vcc_lo                       // 000000F93868: D501000E 01A80280
	s_addc_u32 s15, s11, 0                                     // 000000F93870: 820F800B
	s_ashr_i32 s20, s11, 31                                    // 000000F93874: 86149F0B
	s_ashr_i64 s[0:1], s[14:15], 1                             // 000000F93878: 8680810E
	.long 0xd72c000d                                           // 000000F9387C: D72C000D
	v_cndmask_b32_e32 v1, s19, v11, vcc_lo                     // 000000F93880: 02021613
	v_mad_u64_u32 v[5:6], null, s18, v11, 0                    // 000000F93884: D6FE7C05 02021612
	.long 0xd72c000f                                           // 000000F9388C: D72C000F
	v_cndmask_b32_e32 v0, v11, v1, vcc_lo                      // 000000F93890: 0200030B
	.long 0xd72c0014                                           // 000000F93894: D72C0014
	v_cndmask_b32_e32 v0, v14, v0, vcc_lo                      // 000000F93898: 0200010E
	.long 0xd72c000e                                           // 000000F9389C: D72C000E
	v_cndmask_b32_e32 v1, s18, v14, vcc_lo                     // 000000F938A0: 02021C12
	s_lshr_b32 s14, s20, 27                                    // 000000F938A4: 850E9B14
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v3, 0               // 000000F938A8: CA100080 02020080
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 000000F938B0: BF870152
	v_add3_u32 v6, v6, v14, v13                                // 000000F938B4: D6550006 04361D06
	s_waitcnt vmcnt(1)                                         // 000000F938BC: BF8907F7
	v_bfe_u32 v12, v4, 16, 1                                   // 000000F938C0: D610000C 02052104
	s_waitcnt vmcnt(0)                                         // 000000F938C8: BF8903F7
	v_bfe_u32 v19, v7, 16, 1                                   // 000000F938CC: D6100013 02052107
	v_add3_u32 v4, v4, v12, 0x7fff                             // 000000F938D4: D6550004 03FE1904 00007FFF
	v_mad_u64_u32 v[11:12], null, v11, s0, s[2:3]              // 000000F938E0: D6FE7C0B 0008010B
	s_add_u32 s2, s10, s14                                     // 000000F938E8: 80020E0A
	v_add3_u32 v7, v7, v19, 0x7fff                             // 000000F938EC: D6550007 03FE2707 00007FFF
	s_addc_u32 s3, s11, 0                                      // 000000F938F8: 8203800B
	.long 0x7e103984                                           // 000000F938FC: 7E103984
	s_lshr_b64 s[2:3], s[2:3], 5                               // 000000F93900: 85828502
	v_dual_mov_b32 v4, 0 :: v_dual_lshlrev_b32 v19, 2, v0      // 000000F93904: CA220080 04120082
	.long 0xd4440000                                           // 000000F9390C: D4440000
	v_cndmask_b32_e32 v1, s2, v16, vcc_lo                      // 000000F93910: 02022002
	s_delay_alu instid0(VALU_DEP_3)                            // 000000F93914: BF870003
	v_and_or_b32 v7, 0xffff0000, v7, v8                        // 000000F93918: D6570007 04220EFF FFFF0000
	v_add3_u32 v0, v20, v12, v15                               // 000000F93924: D6550000 043E1914
	ds_store_b32 v19, v7                                       // 000000F9392C: D8340000 00000713
	s_waitcnt lgkmcnt(0)                                       // 000000F93934: BF89FC07
	s_barrier                                                  // 000000F93938: BFBD0000
	buffer_gl0_inv                                             // 000000F9393C: E0AC0000 00000000
	s_and_saveexec_b32 s3, s0                                  // 000000F93944: BE832000
	s_cbranch_execz 26                                         // 000000F93948: BFA5001A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi16ELi1ELb1ELi4ELi0EEEvPKhPKtPvlllllS6_f+0x1b4>
	s_add_u32 s1, s4, s16                                      // 000000F9394C: 80011004
	s_addc_u32 s14, s5, s17                                    // 000000F93950: 820E1105
	v_lshlrev_b32_e32 v1, 1, v16                               // 000000F93954: 30022081
	.long 0xd7000102                                           // 000000F93958: D7000102
	v_cndmask_b32_e32 v1, s1, v5, vcc_lo                       // 000000F9395C: 02020A01
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000F93960: BF8701A1
	v_add_co_ci_u32_e64 v3, null, s14, v6, s1                  // 000000F93964: D5207C03 00060C0E
	v_lshlrev_b32_e32 v4, 4, v16                               // 000000F9396C: 30082084
	.long 0xd7000101                                           // 000000F93970: D7000101
	v_cndmask_b32_e32 v1, v2, v1, vcc_lo                       // 000000F93974: 02020302
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000F93978: BF870191
	v_add_co_ci_u32_e64 v2, null, 0, v3, s1                    // 000000F9397C: D5207C02 00060680
	.long 0xd7000103                                           // 000000F93984: D7000103
	v_cndmask_b32_e32 v1, v11, v4, vcc_lo                      // 000000F93988: 0202090B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000F9398C: BF870001
	v_add_co_ci_u32_e64 v4, null, 0, v0, s1                    // 000000F93990: D5207C04 00060080
	s_clause 0x1                                               // 000000F93998: BF850001
	global_load_d16_b16 v7, v[1:2], off                        // 000000F9399C: DC820000 077C0001
	global_load_b128 v[1:4], v[3:4], off                       // 000000F939A4: DC5E0000 017C0003
	s_waitcnt vmcnt(1)                                         // 000000F939AC: BF8907F7
	v_cvt_f32_f16_e32 v18, v7                                  // 000000F939B0: 7E241707
	s_or_b32 exec_lo, exec_lo, s3                              // 000000F939B4: 8C7E037E
	v_dual_mov_b32 v19, 0 :: v_dual_mov_b32 v20, 0             // 000000F939B8: CA100080 13140080
	v_mov_b32_e32 v21, 0                                       // 000000F939C0: 7E2A0280
	s_and_saveexec_b32 s3, s0                                  // 000000F939C4: BE832000
	s_cbranch_execz 382                                        // 000000F939C8: BFA5017E <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi16ELi1ELb1ELi4ELi0EEEvPKhPKtPvlllllS6_f+0x7c4>
	s_mul_i32 s0, s11, 6                                       // 000000F939CC: 9600860B
	s_mul_hi_u32 s1, s10, 6                                    // 000000F939D0: 9681860A
	v_dual_mov_b32 v13, 0 :: v_dual_lshlrev_b32 v12, 5, v16    // 000000F939D4: CA220080 0D0C2085
	s_add_i32 s18, s1, s0                                      // 000000F939DC: 81120001
	v_lshlrev_b32_e32 v7, 1, v16                               // 000000F939E0: 300E2081
	.long 0xd7000005                                           // 000000F939E4: D7000005
	v_cndmask_b32_e32 v1, s16, v5, vcc_lo                      // 000000F939E8: 02020A10
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000F939EC: BF8701A1
	v_add_co_ci_u32_e64 v6, null, s17, v6, s0                  // 000000F939F0: D5207C06 00020C11
	v_mov_b32_e32 v20, v13                                     // 000000F939F8: 7E28030D
	.long 0xd7000005                                           // 000000F939FC: D7000005
	v_cndmask_b32_e32 v1, v5, v7, vcc_lo                       // 000000F93A00: 02020F05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000F93A04: BF8701A1
	v_add_co_ci_u32_e64 v6, null, 0, v6, s0                    // 000000F93A08: D5207C06 00020C80
	v_lshl_or_b32 v22, v16, 4, 0x100                           // 000000F93A10: D6560016 03FD0910 00000100
	.long 0xd7000005                                           // 000000F93A1C: D7000005
	v_cndmask_b32_e32 v1, s4, v5, vcc_lo                       // 000000F93A20: 02020A04
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000F93A24: BF8701A1
	v_add_co_ci_u32_e64 v6, null, s5, v6, s0                   // 000000F93A28: D5207C06 00020C05
	v_dual_mov_b32 v23, v16 :: v_dual_mov_b32 v24, v18         // 000000F93A30: CA100110 17180112
	.long 0xd700000e                                           // 000000F93A38: D700000E
	v_cndmask_b32_e32 v0, v5, v160, vcc_lo                     // 000000F93A3C: 02014105
	s_delay_alu instid0(VALU_DEP_1)                            // 000000F93A40: BF870001
	v_add_co_ci_u32_e64 v15, null, 0, v6, s0                   // 000000F93A44: D5207C0F 00020C80
	v_mov_b32_e32 v21, v13                                     // 000000F93A4C: 7E2A030D
	v_mov_b32_e32 v19, v13                                     // 000000F93A50: 7E26030D
	v_mov_b32_e32 v17, v13                                     // 000000F93A54: 7E22030D
	s_lshl_b64 s[14:15], s[10:11], 2                           // 000000F93A58: 848E820A
	s_mul_i32 s17, s10, 6                                      // 000000F93A5C: 9611860A
	s_mov_b32 s16, 0                                           // 000000F93A60: BE900080
	s_lshl_b64 s[4:5], s[10:11], 1                             // 000000F93A64: 8484810A
	s_branch 316                                               // 000000F93A68: BFA0013C <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi16ELi1ELb1ELi4ELi0EEEvPKhPKtPvlllllS6_f+0x75c>
	s_or_b32 exec_lo, exec_lo, s10                             // 000000F93A6C: 8C7E0A7E
	.long 0xd73c0019                                           // 000000F93A70: D73C0019
	v_cndmask_b32_e32 v1, 1, v12, vcc_lo                       // 000000F93A74: 02021881
	v_and_b32_e32 v57, 0xff, v1                                // 000000F93A78: 367202FF 000000FF
	v_lshrrev_b32_e32 v58, 6, v1                               // 000000F93A80: 32740286
	v_lshrrev_b32_e32 v59, 14, v1                              // 000000F93A84: 3276028E
	v_lshrrev_b32_e32 v1, 22, v1                               // 000000F93A88: 32020296
	v_and_b32_e32 v60, 0xff, v2                                // 000000F93A8C: 367804FF 000000FF
	.long 0xd7000149                                           // 000000F93A94: D7000149
	v_cndmask_b32_e32 v1, s6, v25, vcc_lo                      // 000000F93A98: 02023206
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000F93A9C: BF8701A1
	v_add_co_ci_u32_e64 v74, null, s7, v26, s1                 // 000000F93AA0: D5207C4A 00063407
	v_lshlrev_b32_e32 v57, 2, v57                              // 000000F93AA8: 30727282
	.long 0xd700014d                                           // 000000F93AAC: D700014D
	v_cndmask_b32_e32 v0, v73, v4, vcc_lo                      // 000000F93AB0: 02000949
	global_load_b128 v[25:28], v[73:74], off                   // 000000F93AB4: DC5E0000 197C0049
	v_add_co_ci_u32_e64 v78, null, s5, v74, s1                 // 000000F93ABC: D5207C4E 00069405
	.long 0xd700014f                                           // 000000F93AC4: D700014F
	v_cndmask_b32_e32 v0, v73, v14, vcc_lo                     // 000000F93AC8: 02001D49
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F93ACC: BF8700A1
	v_add_co_ci_u32_e64 v80, null, s15, v74, s1                // 000000F93AD0: D5207C50 0006940F
	.long 0xd7000151                                           // 000000F93AD8: D7000151
	v_cndmask_b32_e32 v0, v73, v17, vcc_lo                     // 000000F93ADC: 02002349
	v_add_co_ci_u32_e64 v82, null, s18, v74, s1                // 000000F93AE0: D5207C52 00069412
	s_clause 0x6                                               // 000000F93AE8: BF850006
	global_load_b128 v[29:32], v[77:78], off                   // 000000F93AEC: DC5E0000 1D7C004D
	global_load_b128 v[33:36], v[79:80], off                   // 000000F93AF4: DC5E0000 217C004F
	global_load_b128 v[37:40], v[81:82], off                   // 000000F93AFC: DC5E0000 257C0051
	global_load_b128 v[41:44], v[73:74], off offset:16         // 000000F93B04: DC5E0010 297C0049
	global_load_b128 v[45:48], v[77:78], off offset:16         // 000000F93B0C: DC5E0010 2D7C004D
	global_load_b128 v[49:52], v[79:80], off offset:16         // 000000F93B14: DC5E0010 317C004F
	global_load_b128 v[53:56], v[81:82], off offset:16         // 000000F93B1C: DC5E0010 357C0051
	v_and_b32_e32 v58, 0x3fc, v58                              // 000000F93B24: 367474FF 000003FC
	ds_load_b32 v75, v57                                       // 000000F93B2C: D8D80000 4B000039
	v_lshrrev_b32_e32 v61, 6, v2                               // 000000F93B34: 327A0486
	v_lshrrev_b32_e32 v62, 14, v2                              // 000000F93B38: 327C048E
	v_lshrrev_b32_e32 v2, 22, v2                               // 000000F93B3C: 32040496
	ds_load_b32 v83, v58                                       // 000000F93B40: D8D80000 5300003A
	v_and_b32_e32 v57, 0x3fc, v59                              // 000000F93B48: 367276FF 000003FC
	v_and_b32_e32 v1, 0x3fc, v1                                // 000000F93B50: 360202FF 000003FC
	v_lshlrev_b32_e32 v76, 2, v60                              // 000000F93B58: 30987882
	v_and_b32_e32 v84, 0x3fc, v61                              // 000000F93B5C: 36A87AFF 000003FC
	v_and_b32_e32 v88, 0x3fc, v62                              // 000000F93B64: 36B07CFF 000003FC
	ds_load_b32 v89, v57                                       // 000000F93B6C: D8D80000 59000039
	s_clause 0x3                                               // 000000F93B74: BF850003
	global_load_b128 v[57:60], v[73:74], off offset:32         // 000000F93B78: DC5E0020 397C0049
	global_load_b128 v[61:64], v[77:78], off offset:32         // 000000F93B80: DC5E0020 3D7C004D
	global_load_b128 v[65:68], v[79:80], off offset:32         // 000000F93B88: DC5E0020 417C004F
	global_load_b128 v[69:72], v[81:82], off offset:32         // 000000F93B90: DC5E0020 457C0051
	v_and_b32_e32 v2, 0x3fc, v2                                // 000000F93B98: 360404FF 000003FC
	ds_load_b32 v1, v1                                         // 000000F93BA0: D8D80000 01000001
	ds_load_b32 v90, v76                                       // 000000F93BA8: D8D80000 5A00004C
	ds_load_b32 v91, v84                                       // 000000F93BB0: D8D80000 5B000054
	ds_load_b32 v88, v88                                       // 000000F93BB8: D8D80000 58000058
	ds_load_b32 v2, v2                                         // 000000F93BC0: D8D80000 02000002
	v_and_b32_e32 v85, 0xff, v3                                // 000000F93BC8: 36AA06FF 000000FF
	v_lshrrev_b32_e32 v86, 6, v3                               // 000000F93BD0: 32AC0686
	v_lshrrev_b32_e32 v87, 14, v3                              // 000000F93BD4: 32AE068E
	v_lshrrev_b32_e32 v3, 22, v3                               // 000000F93BD8: 32060696
	v_and_b32_e32 v92, 0xff, v4                                // 000000F93BDC: 36B808FF 000000FF
	v_lshrrev_b32_e32 v93, 6, v4                               // 000000F93BE4: 32BA0886
	v_lshrrev_b32_e32 v94, 14, v4                              // 000000F93BE8: 32BC088E
	v_lshrrev_b32_e32 v4, 22, v4                               // 000000F93BEC: 32080896
	v_and_b32_e32 v3, 0x3fc, v3                                // 000000F93BF0: 360606FF 000003FC
	s_and_b32 s1, exec_lo, s0                                  // 000000F93BF8: 8B01007E
	.long 0xd700000e                                           // 000000F93BFC: D700000E
	v_cndmask_b32_e32 v0, v14, v160, vcc_lo                    // 000000F93C00: 0201410E
	s_delay_alu instid0(VALU_DEP_3)                            // 000000F93C04: BF870003
	v_and_b32_e32 v4, 0x3fc, v4                                // 000000F93C08: 360808FF 000003FC
	v_add_nc_u32_e32 v12, 0x200, v12                           // 000000F93C10: 4A1818FF 00000200
	v_add_nc_u32_e32 v22, 0x100, v22                           // 000000F93C18: 4A2C2CFF 00000100
	v_add_co_ci_u32_e64 v15, null, 0, v15, s0                  // 000000F93C20: D5207C0F 00021E80
	s_or_b32 s16, s1, s16                                      // 000000F93C28: 8C101001
	s_waitcnt vmcnt(11) lgkmcnt(7)                             // 000000F93C2C: BF892C77
	v_dot2_f32_bf16 v25, v25, v75, 0                           // 000000F93C30: CC1A4019 1A029719
	s_waitcnt lgkmcnt(6)                                       // 000000F93C38: BF89FC67
	s_delay_alu instid0(VALU_DEP_1)                            // 000000F93C3C: BF870001
	v_dot2_f32_bf16 v25, v26, v83, v25                         // 000000F93C40: CC1A4019 1C66A71A
	s_waitcnt vmcnt(10)                                        // 000000F93C48: BF892BF7
	v_dot2_f32_bf16 v26, v29, v75, 0                           // 000000F93C4C: CC1A401A 1A02971D
	s_waitcnt vmcnt(9)                                         // 000000F93C54: BF8927F7
	v_dot2_f32_bf16 v29, v33, v75, 0                           // 000000F93C58: CC1A401D 1A029721
	s_waitcnt vmcnt(8)                                         // 000000F93C60: BF8923F7
	v_dot2_f32_bf16 v33, v37, v75, 0                           // 000000F93C64: CC1A4021 1A029725
	s_waitcnt lgkmcnt(5)                                       // 000000F93C6C: BF89FC57
	v_dot2_f32_bf16 v25, v27, v89, v25                         // 000000F93C70: CC1A4019 1C66B31B
	global_load_b128 v[73:76], v[73:74], off offset:48         // 000000F93C78: DC5E0030 497C0049
	v_dot2_f32_bf16 v30, v30, v83, v26                         // 000000F93C80: CC1A401E 1C6AA71E
	v_dot2_f32_bf16 v29, v34, v83, v29                         // 000000F93C88: CC1A401D 1C76A722
	v_dot2_f32_bf16 v33, v38, v83, v33                         // 000000F93C90: CC1A4021 1C86A726
	s_waitcnt lgkmcnt(4)                                       // 000000F93C98: BF89FC47
	v_dot2_f32_bf16 v34, v28, v1, v25                          // 000000F93C9C: CC1A4022 1C66031C
	s_clause 0x2                                               // 000000F93CA4: BF850002
	global_load_b128 v[25:28], v[77:78], off offset:48         // 000000F93CA8: DC5E0030 197C004D
	global_load_b128 v[77:80], v[79:80], off offset:48         // 000000F93CB0: DC5E0030 4D7C004F
	global_load_b128 v[81:84], v[81:82], off offset:48         // 000000F93CB8: DC5E0030 517C0051
	v_dot2_f32_bf16 v30, v31, v89, v30                         // 000000F93CC0: CC1A401E 1C7AB31F
	v_dot2_f32_bf16 v29, v35, v89, v29                         // 000000F93CC8: CC1A401D 1C76B323
	v_dot2_f32_bf16 v31, v39, v89, v33                         // 000000F93CD0: CC1A401F 1C86B327
	v_lshlrev_b32_e32 v33, 2, v85                              // 000000F93CD8: 3042AA82
	v_and_b32_e32 v35, 0x3fc, v86                              // 000000F93CDC: 3646ACFF 000003FC
	v_dot2_f32_bf16 v30, v32, v1, v30                          // 000000F93CE4: CC1A401E 1C7A0320
	v_dot2_f32_bf16 v29, v36, v1, v29                          // 000000F93CEC: CC1A401D 1C760324
	v_dot2_f32_bf16 v1, v40, v1, v31                           // 000000F93CF4: CC1A4001 1C7E0328
	v_and_b32_e32 v37, 0x3fc, v87                              // 000000F93CFC: 364AAEFF 000003FC
	s_waitcnt vmcnt(11) lgkmcnt(3)                             // 000000F93D04: BF892C37
	v_dot2_f32_bf16 v31, v41, v90, v34                         // 000000F93D08: CC1A401F 1C8AB529
	s_waitcnt vmcnt(10)                                        // 000000F93D10: BF892BF7
	v_dot2_f32_bf16 v30, v45, v90, v30                         // 000000F93D14: CC1A401E 1C7AB52D
	s_waitcnt vmcnt(9)                                         // 000000F93D1C: BF8927F7
	v_dot2_f32_bf16 v29, v49, v90, v29                         // 000000F93D20: CC1A401D 1C76B531
	s_waitcnt vmcnt(8)                                         // 000000F93D28: BF8923F7
	v_dot2_f32_bf16 v1, v53, v90, v1                           // 000000F93D2C: CC1A4001 1C06B535
	ds_load_b32 v32, v33                                       // 000000F93D34: D8D80000 20000021
	ds_load_b32 v34, v37                                       // 000000F93D3C: D8D80000 22000025
	s_waitcnt lgkmcnt(4)                                       // 000000F93D44: BF89FC47
	v_dot2_f32_bf16 v31, v42, v91, v31                         // 000000F93D48: CC1A401F 1C7EB72A
	v_dot2_f32_bf16 v30, v46, v91, v30                         // 000000F93D50: CC1A401E 1C7AB72E
	v_dot2_f32_bf16 v29, v50, v91, v29                         // 000000F93D58: CC1A401D 1C76B732
	v_dot2_f32_bf16 v1, v54, v91, v1                           // 000000F93D60: CC1A4001 1C06B736
	ds_load_b32 v33, v35                                       // 000000F93D68: D8D80000 21000023
	s_waitcnt lgkmcnt(4)                                       // 000000F93D70: BF89FC47
	v_dot2_f32_bf16 v31, v43, v88, v31                         // 000000F93D74: CC1A401F 1C7EB12B
	v_dot2_f32_bf16 v30, v47, v88, v30                         // 000000F93D7C: CC1A401E 1C7AB12F
	v_dot2_f32_bf16 v29, v51, v88, v29                         // 000000F93D84: CC1A401D 1C76B133
	v_dot2_f32_bf16 v1, v55, v88, v1                           // 000000F93D8C: CC1A4001 1C06B137
	v_lshlrev_b32_e32 v38, 2, v92                              // 000000F93D94: 304CB882
	s_waitcnt lgkmcnt(3)                                       // 000000F93D98: BF89FC37
	v_dot2_f32_bf16 v31, v44, v2, v31                          // 000000F93D9C: CC1A401F 1C7E052C
	v_dot2_f32_bf16 v30, v48, v2, v30                          // 000000F93DA4: CC1A401E 1C7A0530
	v_dot2_f32_bf16 v29, v52, v2, v29                          // 000000F93DAC: CC1A401D 1C760534
	v_dot2_f32_bf16 v1, v56, v2, v1                            // 000000F93DB4: CC1A4001 1C060538
	v_and_b32_e32 v39, 0x3fc, v93                              // 000000F93DBC: 364EBAFF 000003FC
	v_and_b32_e32 v85, 0x3fc, v94                              // 000000F93DC4: 36AABCFF 000003FC
	ds_load_b32 v2, v3                                         // 000000F93DCC: D8D80000 02000003
	ds_load_b32 v3, v38                                        // 000000F93DD4: D8D80000 03000026
	ds_load_b32 v35, v39                                       // 000000F93DDC: D8D80000 23000027
	ds_load_b32 v36, v85                                       // 000000F93DE4: D8D80000 24000055
	ds_load_b32 v37, v4                                        // 000000F93DEC: D8D80000 25000004
	s_waitcnt vmcnt(7) lgkmcnt(7)                              // 000000F93DF4: BF891C77
	v_dot2_f32_bf16 v4, v57, v32, v31                          // 000000F93DF8: CC1A4004 1C7E4139
	s_waitcnt vmcnt(6)                                         // 000000F93E00: BF891BF7
	v_dot2_f32_bf16 v30, v61, v32, v30                         // 000000F93E04: CC1A401E 1C7A413D
	s_waitcnt vmcnt(5)                                         // 000000F93E0C: BF8917F7
	v_dot2_f32_bf16 v29, v65, v32, v29                         // 000000F93E10: CC1A401D 1C764141
	s_waitcnt vmcnt(4)                                         // 000000F93E18: BF8913F7
	v_dot2_f32_bf16 v1, v69, v32, v1                           // 000000F93E1C: CC1A4001 1C064145
	s_waitcnt lgkmcnt(5)                                       // 000000F93E24: BF89FC57
	v_dot2_f32_bf16 v4, v58, v33, v4                           // 000000F93E28: CC1A4004 1C12433A
	v_dot2_f32_bf16 v30, v62, v33, v30                         // 000000F93E30: CC1A401E 1C7A433E
	v_dot2_f32_bf16 v29, v66, v33, v29                         // 000000F93E38: CC1A401D 1C764342
	v_dot2_f32_bf16 v1, v70, v33, v1                           // 000000F93E40: CC1A4001 1C064346
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000F93E48: BF870214
	v_dot2_f32_bf16 v4, v59, v34, v4                           // 000000F93E4C: CC1A4004 1C12453B
	v_dot2_f32_bf16 v30, v63, v34, v30                         // 000000F93E54: CC1A401E 1C7A453F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000F93E5C: BF870214
	v_dot2_f32_bf16 v29, v67, v34, v29                         // 000000F93E60: CC1A401D 1C764543
	v_dot2_f32_bf16 v1, v71, v34, v1                           // 000000F93E68: CC1A4001 1C064547
	s_waitcnt lgkmcnt(4)                                       // 000000F93E70: BF89FC47
	v_dot2_f32_bf16 v4, v60, v2, v4                            // 000000F93E74: CC1A4004 1C12053C
	v_dot2_f32_bf16 v30, v64, v2, v30                          // 000000F93E7C: CC1A401E 1C7A0540
	v_dot2_f32_bf16 v29, v68, v2, v29                          // 000000F93E84: CC1A401D 1C760544
	v_dot2_f32_bf16 v1, v72, v2, v1                            // 000000F93E8C: CC1A4001 1C060548
	s_waitcnt vmcnt(3) lgkmcnt(3)                              // 000000F93E94: BF890C37
	v_dot2_f32_bf16 v2, v73, v3, v4                            // 000000F93E98: CC1A4002 1C120749
	v_mov_b32_e32 v4, v8                                       // 000000F93EA0: 7E080308
	s_waitcnt vmcnt(2)                                         // 000000F93EA4: BF890BF7
	v_dot2_f32_bf16 v25, v25, v3, v30                          // 000000F93EA8: CC1A4019 1C7A0719
	s_waitcnt vmcnt(1)                                         // 000000F93EB0: BF8907F7
	v_dot2_f32_bf16 v29, v77, v3, v29                          // 000000F93EB4: CC1A401D 1C76074D
	s_waitcnt vmcnt(0)                                         // 000000F93EBC: BF8903F7
	v_dot2_f32_bf16 v1, v81, v3, v1                            // 000000F93EC0: CC1A4001 1C060751
	s_waitcnt lgkmcnt(2)                                       // 000000F93EC8: BF89FC27
	v_dot2_f32_bf16 v2, v74, v35, v2                           // 000000F93ECC: CC1A4002 1C0A474A
	v_mov_b32_e32 v3, v7                                       // 000000F93ED4: 7E060307
	v_dot2_f32_bf16 v8, v26, v35, v25                          // 000000F93ED8: CC1A4008 1C66471A
	v_dot2_f32_bf16 v25, v78, v35, v29                         // 000000F93EE0: CC1A4019 1C76474E
	v_dot2_f32_bf16 v1, v82, v35, v1                           // 000000F93EE8: CC1A4001 1C064752
	s_waitcnt lgkmcnt(1)                                       // 000000F93EF0: BF89FC17
	v_dot2_f32_bf16 v7, v75, v36, v2                           // 000000F93EF4: CC1A4007 1C0A494B
	v_mov_b32_e32 v2, v6                                       // 000000F93EFC: 7E040306
	v_dot2_f32_bf16 v8, v27, v36, v8                           // 000000F93F00: CC1A4008 1C22491B
	v_dot2_f32_bf16 v25, v79, v36, v25                         // 000000F93F08: CC1A4019 1C66494F
	v_dot2_f32_bf16 v1, v83, v36, v1                           // 000000F93F10: CC1A4001 1C064953
	s_waitcnt lgkmcnt(0)                                       // 000000F93F18: BF89FC07
	v_dot2_f32_bf16 v6, v76, v37, v7                           // 000000F93F1C: CC1A4006 1C1E4B4C
	v_dot2_f32_bf16 v7, v28, v37, v8                           // 000000F93F24: CC1A4007 1C224B1C
	v_dot2_f32_bf16 v8, v80, v37, v25                          // 000000F93F2C: CC1A4008 1C664B50
	v_dot2_f32_bf16 v25, v84, v37, v1                          // 000000F93F34: CC1A4019 1C064B54
	v_mov_b32_e32 v1, v5                                       // 000000F93F3C: 7E020305
	v_fmac_f32_e32 v21, v18, v6                                // 000000F93F40: 562A0D12
	v_fmac_f32_e32 v20, v18, v7                                // 000000F93F44: 56280F12
	v_fmac_f32_e32 v19, v18, v8                                // 000000F93F48: 56261112
	v_dual_fmac_f32 v17, v18, v25 :: v_dual_mov_b32 v18, v24   // 000000F93F4C: C8103312 11120118
	s_and_not1_b32 exec_lo, exec_lo, s16                       // 000000F93F54: 917E107E
	s_cbranch_execz 25                                         // 000000F93F58: BFA50019 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi16ELi1ELb1ELi4ELi0EEEvPKhPKtPvlllllS6_f+0x7c0>
	s_waitcnt vmcnt(0)                                         // 000000F93F5C: BF8903F7
	v_dual_mov_b32 v6, v2 :: v_dual_add_nc_u32 v23, 16, v23    // 000000F93F60: CA200102 06162E90
	v_dual_mov_b32 v5, v1 :: v_dual_mov_b32 v8, v4             // 000000F93F68: CA100101 05080104
	v_mov_b32_e32 v7, v3                                       // 000000F93F70: 7E0E0303
	s_delay_alu instid0(VALU_DEP_3)                            // 000000F93F74: BF870003
	.long 0xd4430000                                           // 000000F93F78: D4430000
	v_cndmask_b32_e32 v1, s2, v23, vcc_lo                      // 000000F93F7C: 02022E02
	s_mov_b32 s10, exec_lo                                     // 000000F93F80: BE8A007E
	.long 0xd4c4007e                                           // 000000F93F84: D4C4007E
	v_cndmask_b32_e32 v1, s2, v23, vcc_lo                      // 000000F93F88: 02022E02
	s_cbranch_execz 65207                                      // 000000F93F8C: BFA5FEB7 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi16ELi1ELb1ELi4ELi0EEEvPKhPKtPvlllllS6_f+0x26c>
	.long 0xd7000105                                           // 000000F93F90: D7000105
	v_cndmask_b32_e32 v1, v11, v22, vcc_lo                     // 000000F93F94: 02022D0B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000F93F98: BF870001
	v_add_co_ci_u32_e64 v6, null, 0, v0, s1                    // 000000F93F9C: D5207C06 00060080
	global_load_d16_b16 v24, v[14:15], off                     // 000000F93FA4: DC820000 187C000E
	global_load_b128 v[5:8], v[5:6], off                       // 000000F93FAC: DC5E0000 057C0005
	s_waitcnt vmcnt(1)                                         // 000000F93FB4: BF8907F7
	v_cvt_f32_f16_e32 v24, v24                                 // 000000F93FB8: 7E301718
	s_branch 65195                                             // 000000F93FBC: BFA0FEAB <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi16ELi1ELb1ELi4ELi0EEEvPKhPKtPvlllllS6_f+0x26c>
	s_or_b32 exec_lo, exec_lo, s16                             // 000000F93FC0: 8C7E107E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000F93FC4: BF8700B9
	s_or_b32 exec_lo, exec_lo, s3                              // 000000F93FC8: 8C7E037E
	.long 0xd71f0000                                           // 000000F93FCC: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 000000F93FD0: 020100C1
	s_waitcnt vmcnt(0)                                         // 000000F93FD4: BF8903F7
	v_xor_b32_e32 v1, 8, v0                                    // 000000F93FD8: 3A020088
	v_xor_b32_e32 v5, 4, v0                                    // 000000F93FDC: 3A0A0084
	v_xor_b32_e32 v11, 2, v0                                   // 000000F93FE0: 3A160082
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F93FE4: BF870093
	.long 0xd44c0000                                           // 000000F93FE8: D44C0000
	v_cndmask_b32_e32 v1, 32, v1, vcc_lo                       // 000000F93FEC: 020202A0
	v_cndmask_b32_e64 v1, v0, v1, s0                           // 000000F93FF0: D5010001 00020300
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000F93FF8: BF870114
	.long 0xd44c0000                                           // 000000F93FFC: D44C0000
	v_cndmask_b32_e32 v1, 32, v5, vcc_lo                       // 000000F94000: 02020AA0
	v_lshlrev_b32_e32 v1, 2, v1                                // 000000F94004: 30020282
	s_delay_alu instid0(VALU_DEP_2)                            // 000000F94008: BF870002
	v_cndmask_b32_e64 v5, v0, v5, s0                           // 000000F9400C: D5010005 00020B00
	.long 0xd44c0000                                           // 000000F94014: D44C0000
	v_cndmask_b32_e32 v1, 32, v11, vcc_lo                      // 000000F94018: 020216A0
	ds_bpermute_b32 v2, v1, v21                                // 000000F9401C: DACC0000 02001501
	v_cndmask_b32_e64 v11, v0, v11, s0                         // 000000F94024: D501000B 00021700
	s_waitcnt lgkmcnt(0)                                       // 000000F9402C: BF89FC07
	v_add_f32_e32 v2, v21, v2                                  // 000000F94030: 06040515
	ds_bpermute_b32 v4, v1, v19                                // 000000F94034: DACC0000 04001301
	ds_bpermute_b32 v3, v1, v20                                // 000000F9403C: DACC0000 03001401
	ds_bpermute_b32 v1, v1, v17                                // 000000F94044: DACC0000 01001101
	s_waitcnt lgkmcnt(2)                                       // 000000F9404C: BF89FC27
	v_dual_add_f32 v4, v19, v4 :: v_dual_lshlrev_b32 v5, 2, v5 // 000000F94050: C9220913 04040A82
	ds_bpermute_b32 v6, v5, v2                                 // 000000F94058: DACC0000 06000205
	s_waitcnt lgkmcnt(2)                                       // 000000F94060: BF89FC27
	v_add_f32_e32 v3, v20, v3                                  // 000000F94064: 06060714
	ds_bpermute_b32 v8, v5, v4                                 // 000000F94068: DACC0000 08000405
	s_waitcnt lgkmcnt(1)                                       // 000000F94070: BF89FC17
	v_dual_add_f32 v1, v17, v1 :: v_dual_add_f32 v2, v2, v6    // 000000F94074: C9080311 01020D02
	ds_bpermute_b32 v7, v5, v3                                 // 000000F9407C: DACC0000 07000305
	s_waitcnt lgkmcnt(1)                                       // 000000F94084: BF89FC17
	v_dual_add_f32 v4, v4, v8 :: v_dual_lshlrev_b32 v11, 2, v11// 000000F94088: C9221104 040A1682
	ds_bpermute_b32 v5, v5, v1                                 // 000000F94090: DACC0000 05000105
	s_waitcnt lgkmcnt(1)                                       // 000000F94098: BF89FC17
	v_add_f32_e32 v3, v3, v7                                   // 000000F9409C: 06060F03
	ds_bpermute_b32 v7, v11, v4                                // 000000F940A0: DACC0000 0700040B
	s_waitcnt lgkmcnt(1)                                       // 000000F940A8: BF89FC17
	v_add_f32_e32 v5, v1, v5                                   // 000000F940AC: 060A0B01
	ds_bpermute_b32 v1, v11, v2                                // 000000F940B0: DACC0000 0100020B
	ds_bpermute_b32 v6, v11, v3                                // 000000F940B8: DACC0000 0600030B
	ds_bpermute_b32 v8, v11, v5                                // 000000F940C0: DACC0000 0800050B
	v_xor_b32_e32 v11, 1, v0                                   // 000000F940C8: 3A160081
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F940CC: BF870091
	.long 0xd44c0000                                           // 000000F940D0: D44C0000
	v_cndmask_b32_e32 v1, 32, v11, vcc_lo                      // 000000F940D4: 020216A0
	v_cndmask_b32_e64 v0, v0, v11, s0                          // 000000F940D8: D5010000 00021700
	.long 0xd44a0000                                           // 000000F940E0: D44A0000
	v_cndmask_b32_e32 v1, 0, v16, vcc_lo                       // 000000F940E4: 02022080
	s_waitcnt lgkmcnt(2)                                       // 000000F940E8: BF89FC27
	s_delay_alu instid0(VALU_DEP_2)                            // 000000F940EC: BF870002
	v_dual_add_f32 v0, v2, v1 :: v_dual_lshlrev_b32 v11, 2, v0 // 000000F940F0: C9220302 000A0082
	s_waitcnt lgkmcnt(1)                                       // 000000F940F8: BF89FC17
	v_dual_add_f32 v1, v3, v6 :: v_dual_add_f32 v2, v4, v7     // 000000F940FC: C9080D03 01020F04
	s_waitcnt lgkmcnt(0)                                       // 000000F94104: BF89FC07
	v_add_f32_e32 v3, v5, v8                                   // 000000F94108: 06061105
	s_and_b32 s0, s0, vcc_lo                                   // 000000F9410C: 8B006A00
	ds_bpermute_b32 v4, v11, v0                                // 000000F94110: DACC0000 0400000B
	ds_bpermute_b32 v5, v11, v1                                // 000000F94118: DACC0000 0500010B
	ds_bpermute_b32 v6, v11, v2                                // 000000F94120: DACC0000 0600020B
	ds_bpermute_b32 v7, v11, v3                                // 000000F94128: DACC0000 0700030B
	s_and_saveexec_b32 s1, s0                                  // 000000F94130: BE812000
	s_cbranch_execz 138                                        // 000000F94134: BFA5008A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi16ELi1ELb1ELi4ELi0EEEvPKhPKtPvlllllS6_f+0xb60>
	s_waitcnt lgkmcnt(2)                                       // 000000F94138: BF89FC27
	v_dual_add_f32 v0, v0, v4 :: v_dual_add_f32 v1, v1, v5     // 000000F9413C: C9080900 00000B01
	s_waitcnt lgkmcnt(0)                                       // 000000F94144: BF89FC07
	v_dual_add_f32 v2, v2, v6 :: v_dual_add_f32 v3, v3, v7     // 000000F94148: C9080D02 02020F03
	s_lshl_b64 s[4:5], s[12:13], 2                             // 000000F94150: 8484820C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000F94154: BF870112
	v_dual_mul_f32 v0, 0xbfb8aa3b, v0 :: v_dual_mul_f32 v1, 0xbfb8aa3b, v1// 000000F94158: C8C600FF 000002FF BFB8AA3B
	v_dual_mul_f32 v2, 0xbfb8aa3b, v2 :: v_dual_mul_f32 v3, 0xbfb8aa3b, v3// 000000F94164: C8C604FF 020206FF BFB8AA3B
	s_lshl_b64 s[6:7], s[12:13], 3                             // 000000F94170: 8486830C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000F94174: BF870112
	v_exp_f32_e32 v0, v0                                       // 000000F94178: 7E004B00
	v_exp_f32_e32 v1, v1                                       // 000000F9417C: 7E024B01
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(TRANS32_DEP_3)// 000000F94180: BF8703A1
	v_exp_f32_e32 v2, v2                                       // 000000F94184: 7E044B02
	v_exp_f32_e32 v3, v3                                       // 000000F94188: 7E064B03
	v_dual_add_f32 v7, 1.0, v0 :: v_dual_add_f32 v8, 1.0, v1   // 000000F9418C: C90800F2 070802F2
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000F94194: BF8701A5
	v_dual_add_f32 v11, 1.0, v2 :: v_dual_add_f32 v12, 1.0, v3 // 000000F94198: C90804F2 0B0C06F2
	.long 0xd73c0000                                           // 000000F941A0: D73C0000
	v_cndmask_b32_e32 v1, 2, v9, vcc_lo                        // 000000F941A4: 02021282
	v_div_scale_f32 v13, null, v7, v7, 1.0                     // 000000F941A8: D6FC7C0D 03CA0F07
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000F941B0: BF870214
	v_div_scale_f32 v14, null, v8, v8, 1.0                     // 000000F941B4: D6FC7C0E 03CA1108
	v_div_scale_f32 v15, null, v11, v11, 1.0                   // 000000F941BC: D6FC7C0F 03CA170B
	v_div_scale_f32 v16, null, v12, v12, 1.0                   // 000000F941C4: D6FC7C10 03CA190C
	v_div_scale_f32 v9, vcc_lo, 1.0, v7, 1.0                   // 000000F941CC: D6FC6A09 03CA0EF2
	v_rcp_f32_e32 v17, v13                                     // 000000F941D4: 7E22550D
	v_rcp_f32_e32 v18, v14                                     // 000000F941D8: 7E24550E
	v_rcp_f32_e32 v19, v15                                     // 000000F941DC: 7E26550F
	v_rcp_f32_e32 v20, v16                                     // 000000F941E0: 7E285510
	v_div_scale_f32 v10, s0, 1.0, v8, 1.0                      // 000000F941E4: D6FC000A 03CA10F2
	v_div_scale_f32 v21, s1, 1.0, v11, 1.0                     // 000000F941EC: D6FC0115 03CA16F2
	v_div_scale_f32 v22, s2, 1.0, v12, 1.0                     // 000000F941F4: D6FC0216 03CA18F2
	v_fma_f32 v2, -v13, v17, 1.0                               // 000000F941FC: D6130002 23CA230D
	s_delay_alu instid0(TRANS32_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 000000F94204: BF870317
	v_fma_f32 v3, -v14, v18, 1.0                               // 000000F94208: D6130003 23CA250E
	v_fma_f32 v4, -v15, v19, 1.0                               // 000000F94210: D6130004 23CA270F
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000F94218: BF870195
	v_fma_f32 v5, -v16, v20, 1.0                               // 000000F9421C: D6130005 23CA2910
	v_dual_fmac_f32 v17, v2, v17 :: v_dual_fmac_f32 v18, v3, v18// 000000F94224: C8002302 11122503
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000F9422C: BF8701A2
	v_dual_fmac_f32 v19, v4, v19 :: v_dual_fmac_f32 v20, v5, v20// 000000F94230: C8002704 13142905
	.long 0xd7000303                                           // 000000F94238: D7000303
	v_cndmask_b32_e32 v1, s8, v0, vcc_lo                       // 000000F9423C: 02020008
	v_dual_mul_f32 v23, v9, v17 :: v_dual_mul_f32 v24, v10, v18// 000000F94240: C8C62309 1718250A
	v_add_co_ci_u32_e64 v4, null, s9, v1, s3                   // 000000F94248: D5207C04 000E0209
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000F94250: BF870194
	v_dual_mul_f32 v25, v21, v19 :: v_dual_mul_f32 v26, v22, v20// 000000F94254: C8C62715 191A2916
	v_fma_f32 v2, -v13, v23, v9                                // 000000F9425C: D6130002 24262F0D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000F94264: BF870223
	v_mad_u64_u32 v[0:1], null, s12, 12, v[3:4]                // 000000F94268: D6FE7C00 040D180C
	v_fma_f32 v27, -v14, v24, v10                              // 000000F94270: D613001B 242A310E
	v_fma_f32 v28, -v15, v25, v21                              // 000000F94278: D613001C 2456330F
	v_fma_f32 v29, -v16, v26, v22                              // 000000F94280: D613001D 245A3510
	v_fmac_f32_e32 v23, v2, v17                                // 000000F94288: 562E2302
	.long 0xd7000305                                           // 000000F9428C: D7000305
	v_cndmask_b32_e32 v0, v3, v4, vcc_lo                       // 000000F94290: 02000903
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000F94294: BF870214
	v_dual_fmac_f32 v24, v27, v18 :: v_dual_fmac_f32 v25, v28, v19// 000000F94298: C800251B 1818271C
	v_fmac_f32_e32 v26, v29, v20                               // 000000F942A0: 5634291D
	v_mad_u64_u32 v[1:2], null, s13, 12, v[1:2]                // 000000F942A4: D6FE7C01 0405180D
	v_fma_f32 v2, -v13, v23, v9                                // 000000F942AC: D6130002 24262F0D
	s_delay_alu instid0(VALU_DEP_4)                            // 000000F942B4: BF870004
	v_fma_f32 v9, -v14, v24, v10                               // 000000F942B8: D6130009 242A310E
	v_fma_f32 v10, -v15, v25, v21                              // 000000F942C0: D613000A 2456330F
	v_fma_f32 v13, -v16, v26, v22                              // 000000F942C8: D613000D 245A3510
	v_add_co_ci_u32_e64 v6, null, s5, v4, s3                   // 000000F942D0: D5207C06 000E0805
	v_div_fmas_f32 v2, v2, v17, v23                            // 000000F942D8: D6370002 045E2302
	s_mov_b32 vcc_lo, s0                                       // 000000F942E0: BEEA0000
	v_div_fmas_f32 v9, v9, v18, v24                            // 000000F942E4: D6370009 04622509
	s_mov_b32 vcc_lo, s1                                       // 000000F942EC: BEEA0001
	s_delay_alu instid0(VALU_DEP_2)                            // 000000F942F0: BF870002
	v_div_fixup_f32 v2, v2, v7, 1.0                            // 000000F942F4: D6270002 03CA0F02
	v_div_fmas_f32 v10, v10, v19, v25                          // 000000F942FC: D637000A 0466270A
	s_mov_b32 vcc_lo, s2                                       // 000000F94304: BEEA0002
	v_div_fixup_f32 v9, v9, v8, 1.0                            // 000000F94308: D6270009 03CA1109
	v_div_fmas_f32 v13, v13, v20, v26                          // 000000F94310: D637000D 046A290D
	.long 0xd7006a07                                           // 000000F94318: D7006A07
	v_cndmask_b32_e32 v0, v3, v6, vcc_lo                       // 000000F9431C: 02000D03
	v_div_fixup_f32 v10, v10, v11, 1.0                         // 000000F94320: D627000A 03CA170A
	v_add_co_ci_u32_e64 v8, null, s7, v4, vcc_lo               // 000000F94328: D5207C08 01AA0807
	s_delay_alu instid0(VALU_DEP_4)                            // 000000F94330: BF870004
	v_div_fixup_f32 v11, v13, v12, 1.0                         // 000000F94334: D627000B 03CA190D
	s_clause 0x3                                               // 000000F9433C: BF850003
	global_store_b32 v[3:4], v2, off                           // 000000F94340: DC6A0000 007C0203
	global_store_b32 v[5:6], v9, off                           // 000000F94348: DC6A0000 007C0905
	global_store_b32 v[7:8], v10, off                          // 000000F94350: DC6A0000 007C0A07
	global_store_b32 v[0:1], v11, off                          // 000000F94358: DC6A0000 007C0B00
	s_endpgm                                                   // 000000F94360: BFB00000
		...

