0000000000833b00 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi16ELi1ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi16ELi1ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 000000833B00: F4100100 F8000000
	v_and_b32_e32 v16, 15, v0                                  // 000000833B08: 3620008F
	v_lshrrev_b32_e32 v1, 4, v0                                // 000000833B0C: 32020084
	s_ashr_i32 s3, s2, 31                                      // 000000833B10: 86039F02
	.long 0x7f103880                                           // 000000833B14: 7F103880
	s_lshl_b64 s[2:3], s[2:3], 4                               // 000000833B18: 84828402
	v_mov_b32_e32 v17, 0                                       // 000000833B1C: 7E220280
	v_dual_mov_b32 v10, s3 :: v_dual_lshlrev_b32 v3, 2, v1     // 000000833B20: CA220003 0A020282
	v_or_b32_e32 v9, s2, v1                                    // 000000833B28: 38120202
	v_dual_mov_b32 v1, 0 :: v_dual_lshlrev_b32 v2, 2, v16      // 000000833B2C: CA220080 01022082
	s_waitcnt lgkmcnt(0)                                       // 000000833B34: BF89FC07
	s_clause 0x1                                               // 000000833B38: BF850001
	global_load_b32 v4, v2, s[4:5]                             // 000000833B3C: DC520000 04040002
	global_load_b32 v7, v3, s[4:5]                             // 000000833B44: DC520000 07040003
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[9:10]                 // 000000833B4C: 7CA8120C
	s_add_u32 s12, s4, s14                                     // 000000833B50: 800C0E04
	s_addc_u32 s13, s5, s15                                    // 000000833B54: 820D0F05
	s_lshr_b32 s2, s11, 31                                     // 000000833B58: 85029F0B
	v_mov_b32_e32 v18, 0                                       // 000000833B5C: 7E240280
	s_add_u32 s14, s10, s2                                     // 000000833B60: 800E020A
	v_cndmask_b32_e32 v11, 0, v9, vcc_lo                       // 000000833B64: 02161280
	v_cndmask_b32_e64 v14, 0, s3, vcc_lo                       // 000000833B68: D501000E 01A80680
	s_addc_u32 s15, s11, 0                                     // 000000833B70: 820F800B
	s_ashr_i32 s20, s11, 31                                    // 000000833B74: 86149F0B
	s_ashr_i64 s[2:3], s[14:15], 1                             // 000000833B78: 8682810E
	.long 0xd72c000d                                           // 000000833B7C: D72C000D
	v_cndmask_b32_e32 v1, s19, v11, vcc_lo                     // 000000833B80: 02021613
	v_mad_u64_u32 v[5:6], null, s18, v11, 0                    // 000000833B84: D6FE7C05 02021612
	.long 0xd72c000f                                           // 000000833B8C: D72C000F
	v_cndmask_b32_e32 v0, v11, v3, vcc_lo                      // 000000833B90: 0200070B
	.long 0xd72c0014                                           // 000000833B94: D72C0014
	v_cndmask_b32_e32 v0, v14, v2, vcc_lo                      // 000000833B98: 0200050E
	.long 0xd72c000e                                           // 000000833B9C: D72C000E
	v_cndmask_b32_e32 v1, s18, v14, vcc_lo                     // 000000833BA0: 02021C12
	s_lshr_b32 s14, s20, 27                                    // 000000833BA4: 850E9B14
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v3, 0               // 000000833BA8: CA100080 02020080
	s_add_u32 s10, s10, s14                                    // 000000833BB0: 800A0E0A
	s_addc_u32 s11, s11, 0                                     // 000000833BB4: 820B800B
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000833BB8: BF870119
	s_lshr_b64 s[10:11], s[10:11], 5                           // 000000833BBC: 858A850A
	v_add3_u32 v6, v6, v14, v13                                // 000000833BC0: D6550006 04361D06
	s_waitcnt vmcnt(1)                                         // 000000833BC8: BF8907F7
	v_bfe_u32 v12, v4, 16, 1                                   // 000000833BCC: D610000C 02052104
	s_waitcnt vmcnt(0)                                         // 000000833BD4: BF8903F7
	v_bfe_u32 v19, v7, 16, 1                                   // 000000833BD8: D6100013 02052107
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000833BE0: BF8701A2
	v_add3_u32 v4, v4, v12, 0x7fff                             // 000000833BE4: D6550004 03FE1904 00007FFF
	v_mad_u64_u32 v[11:12], null, v11, s2, s[12:13]            // 000000833BF0: D6FE7C0B 0030050B
	v_add3_u32 v7, v7, v19, 0x7fff                             // 000000833BF8: D6550007 03FE2707 00007FFF
	v_lshlrev_b32_e32 v19, 2, v0                               // 000000833C04: 30260082
	.long 0xd4440002                                           // 000000833C08: D4440002
	v_cndmask_b32_e32 v1, s10, v16, vcc_lo                     // 000000833C0C: 0202200A
	.long 0x7e103984                                           // 000000833C10: 7E103984
	v_mov_b32_e32 v4, 0                                        // 000000833C14: 7E080280
	v_add3_u32 v0, v20, v12, v15                               // 000000833C18: D6550000 043E1914
	s_delay_alu instid0(VALU_DEP_3)                            // 000000833C20: BF870003
	v_and_or_b32 v7, 0xffff0000, v7, v8                        // 000000833C24: D6570007 04220EFF FFFF0000
	ds_store_b32 v19, v7                                       // 000000833C30: D8340000 00000713
	s_waitcnt lgkmcnt(0)                                       // 000000833C38: BF89FC07
	s_barrier                                                  // 000000833C3C: BFBD0000
	buffer_gl0_inv                                             // 000000833C40: E0AC0000 00000000
	s_and_saveexec_b32 s11, s2                                 // 000000833C48: BE8B2002
	s_cbranch_execz 26                                         // 000000833C4C: BFA5001A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi16ELi1ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f+0x1b8>
	s_add_u32 s3, s4, s16                                      // 000000833C50: 80031004
	s_addc_u32 s12, s5, s17                                    // 000000833C54: 820C1105
	v_lshlrev_b32_e32 v1, 1, v16                               // 000000833C58: 30022081
	.long 0xd7000302                                           // 000000833C5C: D7000302
	v_cndmask_b32_e32 v1, s3, v5, vcc_lo                       // 000000833C60: 02020A03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000833C64: BF8701A1
	v_add_co_ci_u32_e64 v3, null, s12, v6, s3                  // 000000833C68: D5207C03 000E0C0C
	v_lshlrev_b32_e32 v4, 4, v16                               // 000000833C70: 30082084
	.long 0xd7000301                                           // 000000833C74: D7000301
	v_cndmask_b32_e32 v1, v2, v1, vcc_lo                       // 000000833C78: 02020302
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000833C7C: BF870191
	v_add_co_ci_u32_e64 v2, null, 0, v3, s3                    // 000000833C80: D5207C02 000E0680
	.long 0xd7000303                                           // 000000833C88: D7000303
	v_cndmask_b32_e32 v1, v11, v4, vcc_lo                      // 000000833C8C: 0202090B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000833C90: BF870001
	v_add_co_ci_u32_e64 v4, null, 0, v0, s3                    // 000000833C94: D5207C04 000E0080
	s_clause 0x1                                               // 000000833C9C: BF850001
	global_load_d16_b16 v7, v[1:2], off                        // 000000833CA0: DC820000 077C0001
	global_load_b128 v[1:4], v[3:4], off                       // 000000833CA8: DC5E0000 017C0003
	s_waitcnt vmcnt(1)                                         // 000000833CB0: BF8907F7
	v_cvt_f32_f16_e32 v18, v7                                  // 000000833CB4: 7E241707
	s_or_b32 exec_lo, exec_lo, s11                             // 000000833CB8: 8C7E0B7E
	s_and_saveexec_b32 s11, s2                                 // 000000833CBC: BE8B2002
	s_cbranch_execz 227                                        // 000000833CC0: BFA500E3 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi16ELi1ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f+0x550>
	v_dual_mov_b32 v20, v16 :: v_dual_lshlrev_b32 v7, 1, v16   // 000000833CC4: CA220110 14062081
	.long 0xd7000205                                           // 000000833CCC: D7000205
	v_cndmask_b32_e32 v1, s16, v5, vcc_lo                      // 000000833CD0: 02020A10
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000833CD4: BF8701A1
	v_add_co_ci_u32_e64 v6, null, s17, v6, s2                  // 000000833CD8: D5207C06 000A0C11
	v_dual_mov_b32 v13, 0 :: v_dual_lshlrev_b32 v12, 5, v16    // 000000833CE0: CA220080 0D0C2085
	.long 0xd7000205                                           // 000000833CE8: D7000205
	v_cndmask_b32_e32 v1, v5, v7, vcc_lo                       // 000000833CEC: 02020F05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000833CF0: BF8701A1
	v_add_co_ci_u32_e64 v6, null, 0, v6, s2                    // 000000833CF4: D5207C06 000A0C80
	v_lshl_or_b32 v19, v16, 4, 0x100                           // 000000833CFC: D6560013 03FD0910 00000100
	.long 0xd7000205                                           // 000000833D08: D7000205
	v_cndmask_b32_e32 v1, s4, v5, vcc_lo                       // 000000833D0C: 02020A04
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000833D10: BF8701A1
	v_add_co_ci_u32_e64 v6, null, s5, v6, s2                   // 000000833D14: D5207C06 000A0C05
	v_mov_b32_e32 v17, v13                                     // 000000833D1C: 7E22030D
	.long 0xd700020e                                           // 000000833D20: D700020E
	v_cndmask_b32_e32 v0, v5, v160, vcc_lo                     // 000000833D24: 02014105
	s_delay_alu instid0(VALU_DEP_1)                            // 000000833D28: BF870001
	v_add_co_ci_u32_e64 v15, null, 0, v6, s2                   // 000000833D2C: D5207C0F 000A0C80
	v_mov_b32_e32 v21, v18                                     // 000000833D34: 7E2A0312
	s_mov_b32 s4, 0                                            // 000000833D38: BE840080
	s_branch 170                                               // 000000833D3C: BFA000AA <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi16ELi1ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f+0x4e8>
	s_or_b32 exec_lo, exec_lo, s5                              // 000000833D40: 8C7E057E
	.long 0xd73c0016                                           // 000000833D44: D73C0016
	v_cndmask_b32_e32 v1, 1, v12, vcc_lo                       // 000000833D48: 02021881
	v_and_b32_e32 v38, 0xff, v1                                // 000000833D4C: 364C02FF 000000FF
	v_lshrrev_b32_e32 v39, 6, v1                               // 000000833D54: 324E0286
	v_lshrrev_b32_e32 v40, 14, v1                              // 000000833D58: 3250028E
	v_lshrrev_b32_e32 v1, 22, v1                               // 000000833D5C: 32020296
	v_and_b32_e32 v41, 0xff, v2                                // 000000833D60: 365204FF 000000FF
	.long 0xd7000322                                           // 000000833D68: D7000322
	v_cndmask_b32_e32 v1, s6, v22, vcc_lo                      // 000000833D6C: 02022C06
	s_delay_alu instid0(VALU_DEP_1)                            // 000000833D70: BF870001
	v_add_co_ci_u32_e64 v35, null, s7, v23, s3                 // 000000833D74: D5207C23 000E2E07
	v_lshlrev_b32_e32 v38, 2, v38                              // 000000833D7C: 304C4C82
	v_and_b32_e32 v39, 0x3fc, v39                              // 000000833D80: 364E4EFF 000003FC
	v_and_b32_e32 v40, 0x3fc, v40                              // 000000833D88: 365050FF 000003FC
	s_clause 0x3                                               // 000000833D90: BF850003
	global_load_b128 v[22:25], v[34:35], off                   // 000000833D94: DC5E0000 167C0022
	global_load_b128 v[26:29], v[34:35], off offset:16         // 000000833D9C: DC5E0010 1A7C0022
	global_load_b128 v[30:33], v[34:35], off offset:32         // 000000833DA4: DC5E0020 1E7C0022
	global_load_b128 v[34:37], v[34:35], off offset:48         // 000000833DAC: DC5E0030 227C0022
	v_lshrrev_b32_e32 v42, 6, v2                               // 000000833DB4: 32540486
	ds_load_b32 v38, v38                                       // 000000833DB8: D8D80000 26000026
	ds_load_b32 v39, v39                                       // 000000833DC0: D8D80000 27000027
	ds_load_b32 v40, v40                                       // 000000833DC8: D8D80000 28000028
	v_lshrrev_b32_e32 v43, 14, v2                              // 000000833DD0: 3256048E
	v_lshrrev_b32_e32 v2, 22, v2                               // 000000833DD4: 32040496
	v_and_b32_e32 v1, 0x3fc, v1                                // 000000833DD8: 360202FF 000003FC
	v_lshlrev_b32_e32 v41, 2, v41                              // 000000833DE0: 30525282
	v_and_b32_e32 v42, 0x3fc, v42                              // 000000833DE4: 365454FF 000003FC
	v_and_b32_e32 v43, 0x3fc, v43                              // 000000833DEC: 365656FF 000003FC
	v_and_b32_e32 v2, 0x3fc, v2                                // 000000833DF4: 360404FF 000003FC
	ds_load_b32 v1, v1                                         // 000000833DFC: D8D80000 01000001
	ds_load_b32 v41, v41                                       // 000000833E04: D8D80000 29000029
	ds_load_b32 v42, v42                                       // 000000833E0C: D8D80000 2A00002A
	ds_load_b32 v43, v43                                       // 000000833E14: D8D80000 2B00002B
	ds_load_b32 v2, v2                                         // 000000833E1C: D8D80000 02000002
	s_and_b32 s3, exec_lo, s2                                  // 000000833E24: 8B03027E
	.long 0xd700020e                                           // 000000833E28: D700020E
	v_cndmask_b32_e32 v0, v14, v160, vcc_lo                    // 000000833E2C: 0201410E
	v_add_nc_u32_e32 v12, 0x200, v12                           // 000000833E30: 4A1818FF 00000200
	v_add_nc_u32_e32 v19, 0x100, v19                           // 000000833E38: 4A2626FF 00000100
	v_add_co_ci_u32_e64 v15, null, 0, v15, s2                  // 000000833E40: D5207C0F 000A1E80
	s_or_b32 s4, s3, s4                                        // 000000833E48: 8C040403
	s_waitcnt vmcnt(3) lgkmcnt(7)                              // 000000833E4C: BF890C77
	v_dot2_f32_bf16 v22, v22, v38, 0                           // 000000833E50: CC1A4016 1A024D16
	v_lshrrev_b32_e32 v38, 14, v3                              // 000000833E58: 324C068E
	s_waitcnt lgkmcnt(6)                                       // 000000833E5C: BF89FC67
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000833E60: BF8701A2
	v_dot2_f32_bf16 v22, v23, v39, v22                         // 000000833E64: CC1A4016 1C5A4F17
	v_and_b32_e32 v23, 0xff, v3                                // 000000833E6C: 362E06FF 000000FF
	v_and_b32_e32 v38, 0x3fc, v38                              // 000000833E74: 364C4CFF 000003FC
	s_waitcnt lgkmcnt(5)                                       // 000000833E7C: BF89FC57
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000833E80: BF8701C3
	v_dot2_f32_bf16 v22, v24, v40, v22                         // 000000833E84: CC1A4016 1C5A5118
	v_lshrrev_b32_e32 v24, 6, v3                               // 000000833E8C: 32300686
	v_lshrrev_b32_e32 v3, 22, v3                               // 000000833E90: 32060696
	s_waitcnt lgkmcnt(4)                                       // 000000833E94: BF89FC47
	v_dot2_f32_bf16 v1, v25, v1, v22                           // 000000833E98: CC1A4001 1C5A0319
	v_lshlrev_b32_e32 v22, 2, v23                              // 000000833EA0: 302C2E82
	v_and_b32_e32 v24, 0x3fc, v24                              // 000000833EA4: 363030FF 000003FC
	v_and_b32_e32 v23, 0xff, v4                                // 000000833EAC: 362E08FF 000000FF
	v_lshrrev_b32_e32 v25, 6, v4                               // 000000833EB4: 32320886
	s_waitcnt vmcnt(2) lgkmcnt(3)                              // 000000833EB8: BF890837
	v_dot2_f32_bf16 v1, v26, v41, v1                           // 000000833EBC: CC1A4001 1C06531A
	ds_load_b32 v22, v22                                       // 000000833EC4: D8D80000 16000016
	ds_load_b32 v24, v24                                       // 000000833ECC: D8D80000 18000018
	v_lshrrev_b32_e32 v26, 14, v4                              // 000000833ED4: 3234088E
	v_lshrrev_b32_e32 v4, 22, v4                               // 000000833ED8: 32080896
	s_waitcnt lgkmcnt(4)                                       // 000000833EDC: BF89FC47
	v_dot2_f32_bf16 v1, v27, v42, v1                           // 000000833EE0: CC1A4001 1C06551B
	ds_load_b32 v27, v38                                       // 000000833EE8: D8D80000 1B000026
	v_and_b32_e32 v3, 0x3fc, v3                                // 000000833EF0: 360606FF 000003FC
	v_lshlrev_b32_e32 v23, 2, v23                              // 000000833EF8: 302E2E82
	v_and_b32_e32 v25, 0x3fc, v25                              // 000000833EFC: 363232FF 000003FC
	s_waitcnt lgkmcnt(4)                                       // 000000833F04: BF89FC47
	v_dot2_f32_bf16 v1, v28, v43, v1                           // 000000833F08: CC1A4001 1C06571C
	v_and_b32_e32 v26, 0x3fc, v26                              // 000000833F10: 363434FF 000003FC
	v_and_b32_e32 v4, 0x3fc, v4                                // 000000833F18: 360808FF 000003FC
	s_waitcnt lgkmcnt(3)                                       // 000000833F20: BF89FC37
	s_delay_alu instid0(VALU_DEP_3)                            // 000000833F24: BF870003
	v_dot2_f32_bf16 v1, v29, v2, v1                            // 000000833F28: CC1A4001 1C06051D
	ds_load_b32 v2, v3                                         // 000000833F30: D8D80000 02000003
	ds_load_b32 v3, v23                                        // 000000833F38: D8D80000 03000017
	ds_load_b32 v23, v25                                       // 000000833F40: D8D80000 17000019
	ds_load_b32 v25, v26                                       // 000000833F48: D8D80000 1900001A
	ds_load_b32 v4, v4                                         // 000000833F50: D8D80000 04000004
	s_waitcnt vmcnt(1) lgkmcnt(7)                              // 000000833F58: BF890477
	v_dot2_f32_bf16 v1, v30, v22, v1                           // 000000833F5C: CC1A4001 1C062D1E
	s_waitcnt lgkmcnt(6)                                       // 000000833F64: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000833F68: BF8700A1
	v_dot2_f32_bf16 v1, v31, v24, v1                           // 000000833F6C: CC1A4001 1C06311F
	s_waitcnt lgkmcnt(5)                                       // 000000833F74: BF89FC57
	v_dot2_f32_bf16 v1, v32, v27, v1                           // 000000833F78: CC1A4001 1C063720
	s_waitcnt lgkmcnt(4)                                       // 000000833F80: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000833F84: BF870131
	v_dot2_f32_bf16 v1, v33, v2, v1                            // 000000833F88: CC1A4001 1C060521
	v_mov_b32_e32 v2, v6                                       // 000000833F90: 7E040306
	s_waitcnt vmcnt(0) lgkmcnt(3)                              // 000000833F94: BF890037
	v_dot2_f32_bf16 v1, v34, v3, v1                            // 000000833F98: CC1A4001 1C060722
	v_mov_b32_e32 v3, v7                                       // 000000833FA0: 7E060307
	s_waitcnt lgkmcnt(2)                                       // 000000833FA4: BF89FC27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000833FA8: BF8700A2
	v_dot2_f32_bf16 v1, v35, v23, v1                           // 000000833FAC: CC1A4001 1C062F23
	s_waitcnt lgkmcnt(1)                                       // 000000833FB4: BF89FC17
	v_dot2_f32_bf16 v1, v36, v25, v1                           // 000000833FB8: CC1A4001 1C063324
	s_waitcnt lgkmcnt(0)                                       // 000000833FC0: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000833FC4: BF870121
	v_dot2_f32_bf16 v22, v37, v4, v1                           // 000000833FC8: CC1A4016 1C060925
	v_dual_mov_b32 v4, v8 :: v_dual_mov_b32 v1, v5             // 000000833FD0: CA100108 04000105
	v_dual_fmac_f32 v17, v18, v22 :: v_dual_mov_b32 v18, v21   // 000000833FD8: C8102D12 11120115
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000833FE0: 917E047E
	s_cbranch_execz 25                                         // 000000833FE4: BFA50019 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi16ELi1ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f+0x54c>
	s_waitcnt vmcnt(0)                                         // 000000833FE8: BF8903F7
	v_dual_mov_b32 v5, v1 :: v_dual_add_nc_u32 v20, 16, v20    // 000000833FEC: CA200101 05142890
	v_dual_mov_b32 v6, v2 :: v_dual_mov_b32 v7, v3             // 000000833FF4: CA100102 06060103
	v_mov_b32_e32 v8, v4                                       // 000000833FFC: 7E100304
	s_delay_alu instid0(VALU_DEP_3)                            // 000000834000: BF870003
	.long 0xd4430002                                           // 000000834004: D4430002
	v_cndmask_b32_e32 v1, s10, v20, vcc_lo                     // 000000834008: 0202280A
	s_mov_b32 s5, exec_lo                                      // 00000083400C: BE85007E
	.long 0xd4c4007e                                           // 000000834010: D4C4007E
	v_cndmask_b32_e32 v1, s10, v20, vcc_lo                     // 000000834014: 0202280A
	s_cbranch_execz 65353                                      // 000000834018: BFA5FF49 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi16ELi1ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f+0x240>
	.long 0xd7000305                                           // 00000083401C: D7000305
	v_cndmask_b32_e32 v1, v11, v19, vcc_lo                     // 000000834020: 0202270B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000834024: BF870001
	v_add_co_ci_u32_e64 v6, null, 0, v0, s3                    // 000000834028: D5207C06 000E0080
	global_load_d16_b16 v21, v[14:15], off                     // 000000834030: DC820000 157C000E
	global_load_b128 v[5:8], v[5:6], off                       // 000000834038: DC5E0000 057C0005
	s_waitcnt vmcnt(1)                                         // 000000834040: BF8907F7
	v_cvt_f32_f16_e32 v21, v21                                 // 000000834044: 7E2A1715
	s_branch 65341                                             // 000000834048: BFA0FF3D <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi16ELi1ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f+0x240>
	s_or_b32 exec_lo, exec_lo, s4                              // 00000083404C: 8C7E047E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000834050: BF8700B9
	s_or_b32 exec_lo, exec_lo, s11                             // 000000834054: 8C7E0B7E
	.long 0xd71f0000                                           // 000000834058: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 00000083405C: 020100C1
	s_waitcnt vmcnt(0)                                         // 000000834060: BF8903F7
	v_xor_b32_e32 v1, 8, v0                                    // 000000834064: 3A020088
	v_xor_b32_e32 v2, 4, v0                                    // 000000834068: 3A040084
	v_xor_b32_e32 v3, 2, v0                                    // 00000083406C: 3A060082
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000834070: BF870093
	.long 0xd44c0002                                           // 000000834074: D44C0002
	v_cndmask_b32_e32 v1, 32, v1, vcc_lo                       // 000000834078: 020202A0
	v_cndmask_b32_e64 v1, v0, v1, s2                           // 00000083407C: D5010001 000A0300
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000834084: BF870114
	.long 0xd44c0002                                           // 000000834088: D44C0002
	v_cndmask_b32_e32 v1, 32, v2, vcc_lo                       // 00000083408C: 020204A0
	v_lshlrev_b32_e32 v1, 2, v1                                // 000000834090: 30020282
	s_delay_alu instid0(VALU_DEP_2)                            // 000000834094: BF870002
	v_cndmask_b32_e64 v2, v0, v2, s2                           // 000000834098: D5010002 000A0500
	.long 0xd44c0002                                           // 0000008340A0: D44C0002
	v_cndmask_b32_e32 v1, 32, v3, vcc_lo                       // 0000008340A4: 020206A0
	ds_bpermute_b32 v1, v1, v17                                // 0000008340A8: DACC0000 01001101
	v_lshlrev_b32_e32 v2, 2, v2                                // 0000008340B0: 30040482
	v_cndmask_b32_e64 v3, v0, v3, s2                           // 0000008340B4: D5010003 000A0700
	s_waitcnt lgkmcnt(0)                                       // 0000008340BC: BF89FC07
	v_add_f32_e32 v1, v17, v1                                  // 0000008340C0: 06020311
	ds_bpermute_b32 v2, v2, v1                                 // 0000008340C4: DACC0000 02000102
	s_waitcnt lgkmcnt(0)                                       // 0000008340CC: BF89FC07
	v_add_f32_e32 v1, v1, v2                                   // 0000008340D0: 06020501
	v_lshlrev_b32_e32 v3, 2, v3                                // 0000008340D4: 30060682
	ds_bpermute_b32 v2, v3, v1                                 // 0000008340D8: DACC0000 02000103
	v_xor_b32_e32 v3, 1, v0                                    // 0000008340E0: 3A060081
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008340E4: BF870091
	.long 0xd44c0002                                           // 0000008340E8: D44C0002
	v_cndmask_b32_e32 v1, 32, v3, vcc_lo                       // 0000008340EC: 020206A0
	v_cndmask_b32_e64 v3, v0, v3, s2                           // 0000008340F0: D5010003 000A0700
	.long 0xd44a0002                                           // 0000008340F8: D44A0002
	v_cndmask_b32_e32 v1, 0, v16, vcc_lo                       // 0000008340FC: 02022080
	s_and_b32 s2, s2, vcc_lo                                   // 000000834100: 8B026A02
	s_waitcnt lgkmcnt(0)                                       // 000000834104: BF89FC07
	v_dual_add_f32 v0, v1, v2 :: v_dual_lshlrev_b32 v1, 2, v3  // 000000834108: C9220501 00000682
	ds_bpermute_b32 v1, v1, v0                                 // 000000834110: DACC0000 01000001
	s_and_saveexec_b32 s3, s2                                  // 000000834118: BE832002
	s_cbranch_execz 53                                         // 00000083411C: BFA50035 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi16ELi1ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f+0x6f4>
	s_load_b32 s0, s[0:1], 0x48                                // 000000834120: F4000000 F8000048
	s_waitcnt lgkmcnt(0)                                       // 000000834128: BF89FC07
	v_add_f32_e32 v0, v0, v1                                   // 00000083412C: 06000300
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000834130: BF870091
	v_bfe_u32 v1, v0, 16, 1                                    // 000000834134: D6100001 02052100
	v_add3_u32 v0, v0, v1, 0x7fff                              // 00000083413C: D6550000 03FE0300 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000834148: BF870091
	v_and_b32_e32 v0, 0xffff0000, v0                           // 00000083414C: 360000FF FFFF0000
	v_mul_f32_e32 v0, s0, v0                                   // 000000834154: 10000000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000834158: BF870091
	v_mul_f32_e32 v0, 0xbfb8aa3b, v0                           // 00000083415C: 100000FF BFB8AA3B
	v_exp_f32_e32 v0, v0                                       // 000000834164: 7E004B00
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000834168: BF870095
	v_add_f32_e32 v0, 1.0, v0                                  // 00000083416C: 060000F2
	v_div_scale_f32 v1, null, v0, v0, 1.0                      // 000000834170: D6FC7C01 03CA0100
	v_div_scale_f32 v4, vcc_lo, 1.0, v0, 1.0                   // 000000834178: D6FC6A04 03CA00F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000834180: BF870292
	v_rcp_f32_e32 v2, v1                                       // 000000834184: 7E045501
	v_fma_f32 v3, -v1, v2, 1.0                                 // 000000834188: D6130003 23CA0501
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000834190: BF870091
	v_fmac_f32_e32 v2, v3, v2                                  // 000000834194: 56040503
	v_mul_f32_e32 v3, v4, v2                                   // 000000834198: 10060504
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000083419C: BF870091
	v_fma_f32 v5, -v1, v3, v4                                  // 0000008341A0: D6130005 24120701
	v_fmac_f32_e32 v3, v5, v2                                  // 0000008341A8: 56060505
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008341AC: BF870091
	v_fma_f32 v1, -v1, v3, v4                                  // 0000008341B0: D6130001 24120701
	v_div_fmas_f32 v1, v1, v2, v3                              // 0000008341B8: D6370001 040E0501
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000008341C0: BF870121
	v_div_fixup_f32 v2, v1, v0, 1.0                            // 0000008341C4: D6270002 03CA0101
	.long 0xd73c0000                                           // 0000008341CC: D73C0000
	v_cndmask_b32_e32 v1, 2, v9, vcc_lo                        // 0000008341D0: 02021282
	v_add_f32_e32 v2, v2, v2                                   // 0000008341D4: 06040502
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008341D8: BF870092
	.long 0xd7006a00                                           // 0000008341DC: D7006A00
	v_cndmask_b32_e32 v1, s8, v0, vcc_lo                       // 0000008341E0: 02020008
	v_add_co_ci_u32_e64 v1, null, s9, v1, vcc_lo               // 0000008341E4: D5207C01 01AA0209
	global_store_b32 v[0:1], v2, off                           // 0000008341EC: DC6A0000 007C0200
	s_endpgm                                                   // 0000008341F4: BFB00000
		...

