0000000000debc00 <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_fl_gILi2EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfPKfS5_PKtSD_PtPj>:
; _ZN7halogen12_GLOBAL__N_115k_i4r_rows_fl_gILi2EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfPKfS5_PKtSD_PtPj():
	s_load_b512 s[4:19], s[0:1], null                          // 000000DEBC00: F4100100 F8000000
	s_waitcnt lgkmcnt(0)                                       // 000000DEBC08: BF89FC07
	s_load_b32 s3, s[14:15], null                              // 000000DEBC0C: F40000C7 F8000000
	s_mul_hi_i32 s14, s2, 0x66666667                           // 000000DEBC14: 970EFF02 66666667
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000DEBC1C: BF8704A9
	s_lshr_b32 s15, s14, 31                                    // 000000DEBC20: 850F9F0E
	s_ashr_i32 s14, s14, 4                                     // 000000DEBC24: 860E840E
	s_add_i32 s15, s14, s15                                    // 000000DEBC28: 810F0F0E
	s_waitcnt lgkmcnt(0)                                       // 000000DEBC2C: BF89FC07
	s_cmp_ge_i32 s15, s3                                       // 000000DEBC30: BF03030F
	s_cbranch_scc1 1815                                        // 000000DEBC34: BFA20717 <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_fl_gILi2EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfPKfS5_PKtSD_PtPj+0x1c94>
	s_mul_i32 s20, s15, 5                                      // 000000DEBC38: 9614850F
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000DEBC3C: BF870499
	s_ashr_i32 s21, s20, 31                                    // 000000DEBC40: 86159F14
	s_lshl_b64 s[20:21], s[20:21], 4                           // 000000DEBC44: 84948414
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000DEBC48: BF870009
	s_add_u32 s20, s10, s20                                    // 000000DEBC4C: 8014140A
	s_addc_u32 s21, s11, s21                                   // 000000DEBC50: 8215150B
	s_clause 0x1                                               // 000000DEBC54: BF850001
	s_load_b64 s[10:11], s[20:21], 0x8                         // 000000DEBC58: F404028A F8000008
	s_load_b32 s14, s[20:21], null                             // 000000DEBC60: F400038A F8000000
	s_mov_b32 s20, exec_lo                                     // 000000DEBC68: BE94007E
	s_waitcnt lgkmcnt(0)                                       // 000000DEBC6C: BF89FC07
	s_sub_i32 s11, s11, s10                                    // 000000DEBC70: 818B0A0B
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000DEBC74: BF870009
	s_min_i32 s3, s11, 2                                       // 000000DEBC78: 8903820B
	v_cmpx_gt_u32_e32 2, v0                                    // 000000DEBC7C: 7D980082
	s_cbranch_execz 22                                         // 000000DEBC80: BFA50016 <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_fl_gILi2EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfPKfS5_PKtSD_PtPj+0xdc>
	v_mov_b32_e32 v1, 0                                        // 000000DEBC84: 7E020280
	s_mov_b32 s21, exec_lo                                     // 000000DEBC88: BE95007E
	.long 0xd4cc007e                                           // 000000DEBC8C: D4CC007E
	v_cndmask_b32_e32 v1, s3, v0, vcc_lo                       // 000000DEBC90: 02020003
	s_cbranch_execz 12                                         // 000000DEBC94: BFA5000C <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_fl_gILi2EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfPKfS5_PKtSD_PtPj+0xc8>
	v_dual_mov_b32 v2, 0 :: v_dual_add_nc_u32 v1, s10, v0      // 000000DEBC98: CA200080 0200000A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DEBCA0: BF870091
	.long 0xd73c0001                                           // 000000DEBCA4: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 000000DEBCA8: 02020282
	.long 0xd7006a01                                           // 000000DEBCAC: D7006A01
	v_cndmask_b32_e32 v1, s12, v1, vcc_lo                      // 000000DEBCB0: 0202020C
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DEBCB4: BF870001
	v_add_co_ci_u32_e64 v2, null, s13, v2, vcc_lo              // 000000DEBCB8: D5207C02 01AA040D
	global_load_b32 v1, v[1:2], off                            // 000000DEBCC0: DC520000 017C0001
	s_or_b32 exec_lo, exec_lo, s21                             // 000000DEBCC8: 8C7E157E
	v_lshlrev_b32_e32 v2, 2, v0                                // 000000DEBCCC: 30040082
	s_waitcnt vmcnt(0)                                         // 000000DEBCD0: BF8903F7
	ds_store_b32 v2, v1 offset:2560                            // 000000DEBCD4: D8340A00 00000102
	s_or_b32 exec_lo, exec_lo, s20                             // 000000DEBCDC: 8C7E147E
	s_cmp_gt_i32 s11, 0                                        // 000000DEBCE0: BF02800B
	s_waitcnt lgkmcnt(0)                                       // 000000DEBCE4: BF89FC07
	s_cselect_b32 s10, -1, 0                                   // 000000DEBCE8: 980A80C1
	s_cmp_lt_i32 s11, 1                                        // 000000DEBCEC: BF04810B
	s_mov_b32 s11, 0                                           // 000000DEBCF0: BE8B0080
	s_barrier                                                  // 000000DEBCF4: BFBD0000
	buffer_gl0_inv                                             // 000000DEBCF8: E0AC0000 00000000
	s_cbranch_scc1 37                                          // 000000DEBD00: BFA20025 <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_fl_gILi2EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfPKfS5_PKtSD_PtPj+0x198>
	v_lshlrev_b32_e32 v3, 4, v0                                // 000000DEBD04: 30060084
	v_cmp_gt_u32_e32 vcc_lo, 0x50, v0                          // 000000DEBD08: 7C9800FF 00000050
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DEBD10: BF870092
	.long 0xd7000801                                           // 000000DEBD14: D7000801
	v_cndmask_b32_e32 v1, s8, v3, vcc_lo                       // 000000DEBD18: 02020608
	v_add_co_ci_u32_e64 v2, null, s9, 0, s8                    // 000000DEBD1C: D5207C02 00210009
	s_mov_b32 s8, s3                                           // 000000DEBD24: BE880003
	s_branch 12                                                // 000000DEBD28: BFA0000C <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_fl_gILi2EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfPKfS5_PKtSD_PtPj+0x15c>
	s_nop 0                                                    // 000000DEBD2C: BF800000
	s_nop 0                                                    // 000000DEBD30: BF800000
	s_nop 0                                                    // 000000DEBD34: BF800000
	s_nop 0                                                    // 000000DEBD38: BF800000
	s_nop 0                                                    // 000000DEBD3C: BF800000
	s_or_b32 exec_lo, exec_lo, s9                              // 000000DEBD40: 8C7E097E
	v_add_nc_u32_e32 v3, 0x500, v3                             // 000000DEBD44: 4A0606FF 00000500
	s_add_i32 s8, s8, -1                                       // 000000DEBD4C: 8108C108
	s_add_i32 s11, s11, 4                                      // 000000DEBD50: 810B840B
	s_cmp_lg_u32 s8, 0                                         // 000000DEBD54: BF078008
	s_cbranch_scc0 15                                          // 000000DEBD58: BFA1000F <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_fl_gILi2EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfPKfS5_PKtSD_PtPj+0x198>
	s_and_saveexec_b32 s9, vcc_lo                              // 000000DEBD5C: BE89206A
	s_cbranch_execz 65527                                      // 000000DEBD60: BFA5FFF7 <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_fl_gILi2EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfPKfS5_PKtSD_PtPj+0x140>
	v_mov_b32_e32 v4, s11                                      // 000000DEBD64: 7E08020B
	ds_load_b32 v4, v4 offset:2560                             // 000000DEBD68: D8D80A00 04000004
	s_waitcnt lgkmcnt(0)                                       // 000000DEBD70: BF89FC07
	v_mad_i64_i32 v[4:5], null, 0x500, v4, v[1:2]              // 000000DEBD74: D6FF7C04 040608FF 00000500
	global_load_b128 v[4:7], v[4:5], off                       // 000000DEBD80: DC5E0000 047C0004
	s_waitcnt vmcnt(0)                                         // 000000DEBD88: BF8903F7
	ds_store_b128 v3, v[4:7]                                   // 000000DEBD8C: DB7C0000 00000403
	s_branch 65514                                             // 000000DEBD94: BFA0FFEA <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_fl_gILi2EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfPKfS5_PKtSD_PtPj+0x140>
	s_mul_i32 s8, s15, 0xffffffd8                              // 000000DEBD98: 9608FF0F FFFFFFD8
	s_and_not1_b32 vcc_lo, exec_lo, s10                        // 000000DEBDA0: 916A0A7E
	s_add_i32 s2, s8, s2                                       // 000000DEBDA4: 81020208
	s_waitcnt lgkmcnt(0)                                       // 000000DEBDA8: BF89FC07
	s_barrier                                                  // 000000DEBDAC: BFBD0000
	buffer_gl0_inv                                             // 000000DEBDB0: E0AC0000 00000000
	s_cbranch_vccnz 1006                                       // 000000DEBDB8: BFA403EE <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_fl_gILi2EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfPKfS5_PKtSD_PtPj+0x1174>
	v_lshrrev_b32_e32 v1, 2, v0                                // 000000DEBDBC: 32020082
	v_bfe_u32 v2, v0, 2, 3                                     // 000000DEBDC0: D6100002 020D0500
	s_lshl_b32 s8, s2, 6                                       // 000000DEBDC8: 84088602
	v_and_b32_e32 v9, 3, v0                                    // 000000DEBDCC: 36120083
	s_add_u32 s6, s4, s6                                       // 000000DEBDD0: 80060604
	v_and_b32_e32 v1, 56, v1                                   // 000000DEBDD4: 360202B8
	s_addc_u32 s7, s5, s7                                      // 000000DEBDD8: 82070705
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DEBDDC: BF870091
	v_or3_b32 v1, s8, v1, v2                                   // 000000DEBDE0: D6580001 040A0208
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000DEBDE8: 3404029F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000DEBDEC: BF870121
	v_mad_i64_i32 v[3:4], null, 0xa00, s14, v[1:2]             // 000000DEBDF0: D6FF7C03 04041CFF 00000A00
	.long 0xd73c0001                                           // 000000DEBDFC: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 000000DEBE00: 02020282
	v_mad_u64_u32 v[5:6], null, 0x140, v3, s[4:5]              // 000000DEBE04: D6FE7C05 001206FF 00000140
	v_mad_u64_u32 v[10:11], null, v3, 10, s[6:7]               // 000000DEBE10: D6FE7C0A 00191503
	v_lshlrev_b32_e32 v3, 4, v9                                // 000000DEBE18: 30061284
	s_mov_b32 s4, 0                                            // 000000DEBE1C: BE840080
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DEBE20: BF870113
	v_mad_i32_i24 v6, 0x140, v4, v6                            // 000000DEBE24: D60A0006 041A08FF 00000140
	.long 0xd7006a16                                           // 000000DEBE30: D7006A16
	v_cndmask_b32_e32 v1, v5, v3, vcc_lo                       // 000000DEBE34: 02020705
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000DEBE38: BF870224
	v_mad_i32_i24 v11, v4, 10, v11                             // 000000DEBE3C: D60A000B 042D1504
	v_lshlrev_b32_e32 v3, 6, v9                                // 000000DEBE44: 30061286
	v_add_co_ci_u32_e64 v23, null, 0, v6, vcc_lo               // 000000DEBE48: D5207C17 01AA0C80
	.long 0xd7006a01                                           // 000000DEBE50: D7006A01
	v_cndmask_b32_e32 v1, s16, v1, vcc_lo                      // 000000DEBE54: 02020210
	s_clause 0x6                                               // 000000DEBE58: BF850006
	global_load_d16_b16 v4, v[10:11], off offset:8             // 000000DEBE5C: DC820008 047C000A
	global_load_b128 v[5:8], v[22:23], off                     // 000000DEBE64: DC5E0000 057C0016
	global_load_b64 v[26:27], v[10:11], off                    // 000000DEBE6C: DC560000 1A7C000A
	global_load_b128 v[10:13], v[22:23], off offset:64         // 000000DEBE74: DC5E0040 0A7C0016
	global_load_b128 v[14:17], v[22:23], off offset:128        // 000000DEBE7C: DC5E0080 0E7C0016
	global_load_b128 v[18:21], v[22:23], off offset:192        // 000000DEBE84: DC5E00C0 127C0016
	global_load_b128 v[22:25], v[22:23], off offset:256        // 000000DEBE8C: DC5E0100 167C0016
	v_add_co_ci_u32_e64 v2, null, s17, v2, vcc_lo              // 000000DEBE94: D5207C02 01AA0411
	v_cmp_eq_u32_e32 vcc_lo, 0, v9                             // 000000DEBE9C: 7C941280
	s_waitcnt vmcnt(6)                                         // 000000DEBEA0: BF891BF7
	v_cvt_f32_f16_e32 v4, v4                                   // 000000DEBEA4: 7E081704
	s_waitcnt vmcnt(5)                                         // 000000DEBEA8: BF8917F7
	v_and_b32_e32 v28, 0xf0f0f0f, v5                           // 000000DEBEAC: 36380AFF 0F0F0F0F
	v_lshrrev_b32_e32 v29, 4, v5                               // 000000DEBEB4: 323A0A84
	v_and_b32_e32 v30, 0xf0f0f0f, v6                           // 000000DEBEB8: 363C0CFF 0F0F0F0F
	v_lshrrev_b32_e32 v31, 4, v6                               // 000000DEBEC0: 323E0C84
	v_and_b32_e32 v32, 0xf0f0f0f, v7                           // 000000DEBEC4: 36400EFF 0F0F0F0F
	v_lshrrev_b32_e32 v33, 4, v7                               // 000000DEBECC: 32420E84
	v_and_b32_e32 v34, 0xf0f0f0f, v8                           // 000000DEBED0: 364410FF 0F0F0F0F
	v_lshrrev_b32_e32 v35, 4, v8                               // 000000DEBED8: 32461084
	s_waitcnt vmcnt(4)                                         // 000000DEBEDC: BF8913F7
	v_cvt_f32_f16_e32 v5, v26                                  // 000000DEBEE0: 7E0A171A
	s_waitcnt vmcnt(3)                                         // 000000DEBEE4: BF890FF7
	v_and_b32_e32 v36, 0xf0f0f0f, v10                          // 000000DEBEE8: 364814FF 0F0F0F0F
	v_lshrrev_b32_e32 v10, 4, v10                              // 000000DEBEF0: 32141484
	v_and_b32_e32 v37, 0xf0f0f0f, v11                          // 000000DEBEF4: 364A16FF 0F0F0F0F
	v_lshrrev_b32_e32 v11, 4, v11                              // 000000DEBEFC: 32161684
	v_and_b32_e32 v38, 0xf0f0f0f, v12                          // 000000DEBF00: 364C18FF 0F0F0F0F
	v_lshrrev_b32_e32 v12, 4, v12                              // 000000DEBF08: 32181884
	v_and_b32_e32 v39, 0xf0f0f0f, v13                          // 000000DEBF0C: 364E1AFF 0F0F0F0F
	v_lshrrev_b32_e32 v13, 4, v13                              // 000000DEBF14: 321A1A84
	v_cvt_f32_f16_e32 v6, v154/*Invalid register, operand has 'VS_32_Lo128' register class*/// 000000DEBF18: 7E0C179A
	s_waitcnt vmcnt(2)                                         // 000000DEBF1C: BF890BF7
	v_and_b32_e32 v26, 0xf0f0f0f, v14                          // 000000DEBF20: 36341CFF 0F0F0F0F
	v_lshrrev_b32_e32 v14, 4, v14                              // 000000DEBF28: 321C1C84
	v_and_b32_e32 v40, 0xf0f0f0f, v15                          // 000000DEBF2C: 36501EFF 0F0F0F0F
	v_lshrrev_b32_e32 v15, 4, v15                              // 000000DEBF34: 321E1E84
	v_and_b32_e32 v41, 0xf0f0f0f, v16                          // 000000DEBF38: 365220FF 0F0F0F0F
	v_lshrrev_b32_e32 v16, 4, v16                              // 000000DEBF40: 32202084
	v_and_b32_e32 v42, 0xf0f0f0f, v17                          // 000000DEBF44: 365422FF 0F0F0F0F
	v_lshrrev_b32_e32 v17, 4, v17                              // 000000DEBF4C: 32222284
	v_cvt_f32_f16_e32 v7, v27                                  // 000000DEBF50: 7E0E171B
	s_waitcnt vmcnt(1)                                         // 000000DEBF54: BF8907F7
	v_and_b32_e32 v43, 0xf0f0f0f, v18                          // 000000DEBF58: 365624FF 0F0F0F0F
	v_lshrrev_b32_e32 v18, 4, v18                              // 000000DEBF60: 32242484
	v_and_b32_e32 v44, 0xf0f0f0f, v19                          // 000000DEBF64: 365826FF 0F0F0F0F
	v_lshrrev_b32_e32 v19, 4, v19                              // 000000DEBF6C: 32262684
	v_and_b32_e32 v45, 0xf0f0f0f, v20                          // 000000DEBF70: 365A28FF 0F0F0F0F
	v_lshrrev_b32_e32 v20, 4, v20                              // 000000DEBF78: 32282884
	v_and_b32_e32 v46, 0xf0f0f0f, v21                          // 000000DEBF7C: 365C2AFF 0F0F0F0F
	v_lshrrev_b32_e32 v21, 4, v21                              // 000000DEBF84: 322A2A84
	v_cvt_f32_f16_e32 v8, v155/*Invalid register, operand has 'VS_32_Lo128' register class*/// 000000DEBF88: 7E10179B
	s_waitcnt vmcnt(0)                                         // 000000DEBF8C: BF8903F7
	v_and_b32_e32 v27, 0xf0f0f0f, v22                          // 000000DEBF90: 36362CFF 0F0F0F0F
	v_lshrrev_b32_e32 v22, 4, v22                              // 000000DEBF98: 322C2C84
	v_and_b32_e32 v47, 0xf0f0f0f, v23                          // 000000DEBF9C: 365E2EFF 0F0F0F0F
	v_lshrrev_b32_e32 v23, 4, v23                              // 000000DEBFA4: 322E2E84
	v_and_b32_e32 v48, 0xf0f0f0f, v24                          // 000000DEBFA8: 366030FF 0F0F0F0F
	v_lshrrev_b32_e32 v24, 4, v24                              // 000000DEBFB0: 32303084
	v_and_b32_e32 v49, 0xf0f0f0f, v25                          // 000000DEBFB4: 366232FF 0F0F0F0F
	v_lshrrev_b32_e32 v25, 4, v25                              // 000000DEBFBC: 32323284
	v_and_b32_e32 v29, 0xf0f0f0f, v29                          // 000000DEBFC0: 363A3AFF 0F0F0F0F
	v_and_b32_e32 v31, 0xf0f0f0f, v31                          // 000000DEBFC8: 363E3EFF 0F0F0F0F
	v_and_b32_e32 v33, 0xf0f0f0f, v33                          // 000000DEBFD0: 364242FF 0F0F0F0F
	v_and_b32_e32 v35, 0xf0f0f0f, v35                          // 000000DEBFD8: 364646FF 0F0F0F0F
	v_and_b32_e32 v10, 0xf0f0f0f, v10                          // 000000DEBFE0: 361414FF 0F0F0F0F
	v_and_b32_e32 v11, 0xf0f0f0f, v11                          // 000000DEBFE8: 361616FF 0F0F0F0F
	v_and_b32_e32 v12, 0xf0f0f0f, v12                          // 000000DEBFF0: 361818FF 0F0F0F0F
	v_and_b32_e32 v13, 0xf0f0f0f, v13                          // 000000DEBFF8: 361A1AFF 0F0F0F0F
	v_and_b32_e32 v14, 0xf0f0f0f, v14                          // 000000DEC000: 361C1CFF 0F0F0F0F
	v_and_b32_e32 v15, 0xf0f0f0f, v15                          // 000000DEC008: 361E1EFF 0F0F0F0F
	v_and_b32_e32 v16, 0xf0f0f0f, v16                          // 000000DEC010: 362020FF 0F0F0F0F
	v_and_b32_e32 v17, 0xf0f0f0f, v17                          // 000000DEC018: 362222FF 0F0F0F0F
	v_and_b32_e32 v18, 0xf0f0f0f, v18                          // 000000DEC020: 362424FF 0F0F0F0F
	v_and_b32_e32 v19, 0xf0f0f0f, v19                          // 000000DEC028: 362626FF 0F0F0F0F
	v_and_b32_e32 v20, 0xf0f0f0f, v20                          // 000000DEC030: 362828FF 0F0F0F0F
	v_and_b32_e32 v21, 0xf0f0f0f, v21                          // 000000DEC038: 362A2AFF 0F0F0F0F
	v_and_b32_e32 v22, 0xf0f0f0f, v22                          // 000000DEC040: 362C2CFF 0F0F0F0F
	v_and_b32_e32 v23, 0xf0f0f0f, v23                          // 000000DEC048: 362E2EFF 0F0F0F0F
	v_and_b32_e32 v24, 0xf0f0f0f, v24                          // 000000DEC050: 363030FF 0F0F0F0F
	v_and_b32_e32 v25, 0xf0f0f0f, v25                          // 000000DEC058: 363232FF 0F0F0F0F
	v_perm_b32 v50, v29, v28, 0xc040c00                        // 000000DEC060: D6440032 03FE391D 0C040C00
	v_perm_b32 v51, v29, v28, 0xc050c01                        // 000000DEC06C: D6440033 03FE391D 0C050C01
	v_perm_b32 v52, v29, v28, 0xc060c02                        // 000000DEC078: D6440034 03FE391D 0C060C02
	v_perm_b32 v28, v29, v28, 0xc070c03                        // 000000DEC084: D644001C 03FE391D 0C070C03
	v_perm_b32 v29, v31, v30, 0xc040c00                        // 000000DEC090: D644001D 03FE3D1F 0C040C00
	v_perm_b32 v53, v31, v30, 0xc050c01                        // 000000DEC09C: D6440035 03FE3D1F 0C050C01
	v_perm_b32 v54, v31, v30, 0xc060c02                        // 000000DEC0A8: D6440036 03FE3D1F 0C060C02
	v_perm_b32 v30, v31, v30, 0xc070c03                        // 000000DEC0B4: D644001E 03FE3D1F 0C070C03
	v_perm_b32 v31, v33, v32, 0xc040c00                        // 000000DEC0C0: D644001F 03FE4121 0C040C00
	v_perm_b32 v55, v33, v32, 0xc050c01                        // 000000DEC0CC: D6440037 03FE4121 0C050C01
	v_perm_b32 v56, v33, v32, 0xc060c02                        // 000000DEC0D8: D6440038 03FE4121 0C060C02
	v_perm_b32 v32, v33, v32, 0xc070c03                        // 000000DEC0E4: D6440020 03FE4121 0C070C03
	v_perm_b32 v33, v35, v34, 0xc040c00                        // 000000DEC0F0: D6440021 03FE4523 0C040C00
	v_perm_b32 v57, v35, v34, 0xc050c01                        // 000000DEC0FC: D6440039 03FE4523 0C050C01
	v_perm_b32 v58, v35, v34, 0xc060c02                        // 000000DEC108: D644003A 03FE4523 0C060C02
	v_perm_b32 v34, v35, v34, 0xc070c03                        // 000000DEC114: D6440022 03FE4523 0C070C03
	v_perm_b32 v35, v10, v36, 0xc040c00                        // 000000DEC120: D6440023 03FE490A 0C040C00
	v_perm_b32 v59, v10, v36, 0xc050c01                        // 000000DEC12C: D644003B 03FE490A 0C050C01
	v_perm_b32 v60, v10, v36, 0xc060c02                        // 000000DEC138: D644003C 03FE490A 0C060C02
	v_perm_b32 v10, v10, v36, 0xc070c03                        // 000000DEC144: D644000A 03FE490A 0C070C03
	v_perm_b32 v36, v11, v37, 0xc040c00                        // 000000DEC150: D6440024 03FE4B0B 0C040C00
	v_perm_b32 v61, v11, v37, 0xc050c01                        // 000000DEC15C: D644003D 03FE4B0B 0C050C01
	v_perm_b32 v62, v11, v37, 0xc060c02                        // 000000DEC168: D644003E 03FE4B0B 0C060C02
	v_perm_b32 v11, v11, v37, 0xc070c03                        // 000000DEC174: D644000B 03FE4B0B 0C070C03
	v_perm_b32 v37, v12, v38, 0xc040c00                        // 000000DEC180: D6440025 03FE4D0C 0C040C00
	v_perm_b32 v63, v12, v38, 0xc050c01                        // 000000DEC18C: D644003F 03FE4D0C 0C050C01
	v_perm_b32 v64, v12, v38, 0xc060c02                        // 000000DEC198: D6440040 03FE4D0C 0C060C02
	v_perm_b32 v12, v12, v38, 0xc070c03                        // 000000DEC1A4: D644000C 03FE4D0C 0C070C03
	v_perm_b32 v38, v13, v39, 0xc040c00                        // 000000DEC1B0: D6440026 03FE4F0D 0C040C00
	v_perm_b32 v65, v13, v39, 0xc050c01                        // 000000DEC1BC: D6440041 03FE4F0D 0C050C01
	v_perm_b32 v66, v13, v39, 0xc060c02                        // 000000DEC1C8: D6440042 03FE4F0D 0C060C02
	v_perm_b32 v13, v13, v39, 0xc070c03                        // 000000DEC1D4: D644000D 03FE4F0D 0C070C03
	v_perm_b32 v39, v14, v26, 0xc040c00                        // 000000DEC1E0: D6440027 03FE350E 0C040C00
	v_perm_b32 v67, v14, v26, 0xc050c01                        // 000000DEC1EC: D6440043 03FE350E 0C050C01
	v_perm_b32 v68, v14, v26, 0xc060c02                        // 000000DEC1F8: D6440044 03FE350E 0C060C02
	v_perm_b32 v14, v14, v26, 0xc070c03                        // 000000DEC204: D644000E 03FE350E 0C070C03
	v_perm_b32 v26, v15, v40, 0xc040c00                        // 000000DEC210: D644001A 03FE510F 0C040C00
	v_perm_b32 v69, v15, v40, 0xc050c01                        // 000000DEC21C: D6440045 03FE510F 0C050C01
	v_perm_b32 v70, v15, v40, 0xc060c02                        // 000000DEC228: D6440046 03FE510F 0C060C02
	v_perm_b32 v15, v15, v40, 0xc070c03                        // 000000DEC234: D644000F 03FE510F 0C070C03
	v_perm_b32 v40, v16, v41, 0xc040c00                        // 000000DEC240: D6440028 03FE5310 0C040C00
	v_perm_b32 v71, v16, v41, 0xc050c01                        // 000000DEC24C: D6440047 03FE5310 0C050C01
	v_perm_b32 v72, v16, v41, 0xc060c02                        // 000000DEC258: D6440048 03FE5310 0C060C02
	v_perm_b32 v16, v16, v41, 0xc070c03                        // 000000DEC264: D6440010 03FE5310 0C070C03
	v_perm_b32 v41, v17, v42, 0xc040c00                        // 000000DEC270: D6440029 03FE5511 0C040C00
	v_perm_b32 v73, v17, v42, 0xc050c01                        // 000000DEC27C: D6440049 03FE5511 0C050C01
	v_perm_b32 v74, v17, v42, 0xc060c02                        // 000000DEC288: D644004A 03FE5511 0C060C02
	v_perm_b32 v17, v17, v42, 0xc070c03                        // 000000DEC294: D6440011 03FE5511 0C070C03
	v_perm_b32 v42, v18, v43, 0xc040c00                        // 000000DEC2A0: D644002A 03FE5712 0C040C00
	v_perm_b32 v75, v18, v43, 0xc050c01                        // 000000DEC2AC: D644004B 03FE5712 0C050C01
	v_perm_b32 v76, v18, v43, 0xc060c02                        // 000000DEC2B8: D644004C 03FE5712 0C060C02
	v_perm_b32 v18, v18, v43, 0xc070c03                        // 000000DEC2C4: D6440012 03FE5712 0C070C03
	v_perm_b32 v43, v19, v44, 0xc040c00                        // 000000DEC2D0: D644002B 03FE5913 0C040C00
	v_perm_b32 v77, v19, v44, 0xc050c01                        // 000000DEC2DC: D644004D 03FE5913 0C050C01
	v_perm_b32 v78, v19, v44, 0xc060c02                        // 000000DEC2E8: D644004E 03FE5913 0C060C02
	v_perm_b32 v19, v19, v44, 0xc070c03                        // 000000DEC2F4: D6440013 03FE5913 0C070C03
	v_perm_b32 v44, v20, v45, 0xc040c00                        // 000000DEC300: D644002C 03FE5B14 0C040C00
	v_perm_b32 v79, v20, v45, 0xc050c01                        // 000000DEC30C: D644004F 03FE5B14 0C050C01
	v_perm_b32 v80, v20, v45, 0xc060c02                        // 000000DEC318: D6440050 03FE5B14 0C060C02
	v_perm_b32 v20, v20, v45, 0xc070c03                        // 000000DEC324: D6440014 03FE5B14 0C070C03
	v_perm_b32 v45, v21, v46, 0xc040c00                        // 000000DEC330: D644002D 03FE5D15 0C040C00
	v_perm_b32 v81, v21, v46, 0xc050c01                        // 000000DEC33C: D6440051 03FE5D15 0C050C01
	v_perm_b32 v82, v21, v46, 0xc060c02                        // 000000DEC348: D6440052 03FE5D15 0C060C02
	v_perm_b32 v21, v21, v46, 0xc070c03                        // 000000DEC354: D6440015 03FE5D15 0C070C03
	v_perm_b32 v46, v22, v27, 0xc040c00                        // 000000DEC360: D644002E 03FE3716 0C040C00
	v_perm_b32 v83, v22, v27, 0xc050c01                        // 000000DEC36C: D6440053 03FE3716 0C050C01
	v_perm_b32 v84, v22, v27, 0xc060c02                        // 000000DEC378: D6440054 03FE3716 0C060C02
	v_perm_b32 v22, v22, v27, 0xc070c03                        // 000000DEC384: D6440016 03FE3716 0C070C03
	v_perm_b32 v27, v23, v47, 0xc040c00                        // 000000DEC390: D644001B 03FE5F17 0C040C00
	v_perm_b32 v85, v23, v47, 0xc050c01                        // 000000DEC39C: D6440055 03FE5F17 0C050C01
	v_perm_b32 v86, v23, v47, 0xc060c02                        // 000000DEC3A8: D6440056 03FE5F17 0C060C02
	v_perm_b32 v23, v23, v47, 0xc070c03                        // 000000DEC3B4: D6440017 03FE5F17 0C070C03
	v_perm_b32 v47, v24, v48, 0xc040c00                        // 000000DEC3C0: D644002F 03FE6118 0C040C00
	v_perm_b32 v87, v24, v48, 0xc050c01                        // 000000DEC3CC: D6440057 03FE6118 0C050C01
	v_perm_b32 v88, v24, v48, 0xc060c02                        // 000000DEC3D8: D6440058 03FE6118 0C060C02
	v_perm_b32 v24, v24, v48, 0xc070c03                        // 000000DEC3E4: D6440018 03FE6118 0C070C03
	v_perm_b32 v48, v25, v49, 0xc040c00                        // 000000DEC3F0: D6440030 03FE6319 0C040C00
	v_perm_b32 v89, v25, v49, 0xc050c01                        // 000000DEC3FC: D6440059 03FE6319 0C050C01
	v_perm_b32 v90, v25, v49, 0xc060c02                        // 000000DEC408: D644005A 03FE6319 0C060C02
	v_perm_b32 v25, v25, v49, 0xc070c03                        // 000000DEC414: D6440019 03FE6319 0C070C03
	v_or_b32_e32 v49, 0x64006400, v50                          // 000000DEC420: 386264FF 64006400
	v_or_b32_e32 v50, 0x64006400, v51                          // 000000DEC428: 386466FF 64006400
	v_or_b32_e32 v51, 0x64006400, v52                          // 000000DEC430: 386668FF 64006400
	v_or_b32_e32 v28, 0x64006400, v28                          // 000000DEC438: 383838FF 64006400
	v_or_b32_e32 v29, 0x64006400, v29                          // 000000DEC440: 383A3AFF 64006400
	v_or_b32_e32 v52, 0x64006400, v53                          // 000000DEC448: 38686AFF 64006400
	v_or_b32_e32 v53, 0x64006400, v54                          // 000000DEC450: 386A6CFF 64006400
	v_or_b32_e32 v30, 0x64006400, v30                          // 000000DEC458: 383C3CFF 64006400
	v_or_b32_e32 v31, 0x64006400, v31                          // 000000DEC460: 383E3EFF 64006400
	v_or_b32_e32 v54, 0x64006400, v55                          // 000000DEC468: 386C6EFF 64006400
	v_or_b32_e32 v55, 0x64006400, v56                          // 000000DEC470: 386E70FF 64006400
	v_or_b32_e32 v32, 0x64006400, v32                          // 000000DEC478: 384040FF 64006400
	v_or_b32_e32 v33, 0x64006400, v33                          // 000000DEC480: 384242FF 64006400
	v_or_b32_e32 v56, 0x64006400, v57                          // 000000DEC488: 387072FF 64006400
	v_or_b32_e32 v57, 0x64006400, v58                          // 000000DEC490: 387274FF 64006400
	v_or_b32_e32 v34, 0x64006400, v34                          // 000000DEC498: 384444FF 64006400
	v_or_b32_e32 v35, 0x64006400, v35                          // 000000DEC4A0: 384646FF 64006400
	v_or_b32_e32 v58, 0x64006400, v59                          // 000000DEC4A8: 387476FF 64006400
	v_or_b32_e32 v59, 0x64006400, v60                          // 000000DEC4B0: 387678FF 64006400
	v_or_b32_e32 v60, 0x64006400, v10                          // 000000DEC4B8: 387814FF 64006400
	v_or_b32_e32 v36, 0x64006400, v36                          // 000000DEC4C0: 384848FF 64006400
	v_or_b32_e32 v61, 0x64006400, v61                          // 000000DEC4C8: 387A7AFF 64006400
	v_or_b32_e32 v62, 0x64006400, v62                          // 000000DEC4D0: 387C7CFF 64006400
	v_or_b32_e32 v91, 0x64006400, v11                          // 000000DEC4D8: 38B616FF 64006400
	v_or_b32_e32 v37, 0x64006400, v37                          // 000000DEC4E0: 384A4AFF 64006400
	v_or_b32_e32 v63, 0x64006400, v63                          // 000000DEC4E8: 387E7EFF 64006400
	v_or_b32_e32 v64, 0x64006400, v64                          // 000000DEC4F0: 388080FF 64006400
	v_or_b32_e32 v92, 0x64006400, v12                          // 000000DEC4F8: 38B818FF 64006400
	v_or_b32_e32 v38, 0x64006400, v38                          // 000000DEC500: 384C4CFF 64006400
	v_or_b32_e32 v65, 0x64006400, v65                          // 000000DEC508: 388282FF 64006400
	v_or_b32_e32 v66, 0x64006400, v66                          // 000000DEC510: 388484FF 64006400
	v_or_b32_e32 v93, 0x64006400, v13                          // 000000DEC518: 38BA1AFF 64006400
	v_or_b32_e32 v94, 0x64006400, v39                          // 000000DEC520: 38BC4EFF 64006400
	v_or_b32_e32 v67, 0x64006400, v67                          // 000000DEC528: 388686FF 64006400
	v_or_b32_e32 v68, 0x64006400, v68                          // 000000DEC530: 388888FF 64006400
	v_or_b32_e32 v95, 0x64006400, v14                          // 000000DEC538: 38BE1CFF 64006400
	v_or_b32_e32 v96, 0x64006400, v26                          // 000000DEC540: 38C034FF 64006400
	v_or_b32_e32 v69, 0x64006400, v69                          // 000000DEC548: 388A8AFF 64006400
	v_or_b32_e32 v70, 0x64006400, v70                          // 000000DEC550: 388C8CFF 64006400
	v_or_b32_e32 v97, 0x64006400, v15                          // 000000DEC558: 38C21EFF 64006400
	v_or_b32_e32 v98, 0x64006400, v40                          // 000000DEC560: 38C450FF 64006400
	v_or_b32_e32 v71, 0x64006400, v71                          // 000000DEC568: 388E8EFF 64006400
	v_or_b32_e32 v72, 0x64006400, v72                          // 000000DEC570: 389090FF 64006400
	v_or_b32_e32 v99, 0x64006400, v16                          // 000000DEC578: 38C620FF 64006400
	v_or_b32_e32 v100, 0x64006400, v41                         // 000000DEC580: 38C852FF 64006400
	v_or_b32_e32 v73, 0x64006400, v73                          // 000000DEC588: 389292FF 64006400
	v_or_b32_e32 v74, 0x64006400, v74                          // 000000DEC590: 389494FF 64006400
	v_or_b32_e32 v101, 0x64006400, v17                         // 000000DEC598: 38CA22FF 64006400
	v_or_b32_e32 v102, 0x64006400, v42                         // 000000DEC5A0: 38CC54FF 64006400
	v_or_b32_e32 v75, 0x64006400, v75                          // 000000DEC5A8: 389696FF 64006400
	v_or_b32_e32 v76, 0x64006400, v76                          // 000000DEC5B0: 389898FF 64006400
	v_or_b32_e32 v103, 0x64006400, v18                         // 000000DEC5B8: 38CE24FF 64006400
	v_or_b32_e32 v104, 0x64006400, v43                         // 000000DEC5C0: 38D056FF 64006400
	v_or_b32_e32 v77, 0x64006400, v77                          // 000000DEC5C8: 389A9AFF 64006400
	v_or_b32_e32 v78, 0x64006400, v78                          // 000000DEC5D0: 389C9CFF 64006400
	v_or_b32_e32 v105, 0x64006400, v19                         // 000000DEC5D8: 38D226FF 64006400
	v_or_b32_e32 v106, 0x64006400, v44                         // 000000DEC5E0: 38D458FF 64006400
	v_or_b32_e32 v79, 0x64006400, v79                          // 000000DEC5E8: 389E9EFF 64006400
	v_or_b32_e32 v80, 0x64006400, v80                          // 000000DEC5F0: 38A0A0FF 64006400
	v_or_b32_e32 v107, 0x64006400, v20                         // 000000DEC5F8: 38D628FF 64006400
	v_or_b32_e32 v108, 0x64006400, v45                         // 000000DEC600: 38D85AFF 64006400
	v_or_b32_e32 v81, 0x64006400, v81                          // 000000DEC608: 38A2A2FF 64006400
	v_or_b32_e32 v82, 0x64006400, v82                          // 000000DEC610: 38A4A4FF 64006400
	v_or_b32_e32 v109, 0x64006400, v21                         // 000000DEC618: 38DA2AFF 64006400
	v_or_b32_e32 v110, 0x64006400, v46                         // 000000DEC620: 38DC5CFF 64006400
	v_or_b32_e32 v83, 0x64006400, v83                          // 000000DEC628: 38A6A6FF 64006400
	v_or_b32_e32 v84, 0x64006400, v84                          // 000000DEC630: 38A8A8FF 64006400
	v_or_b32_e32 v111, 0x64006400, v22                         // 000000DEC638: 38DE2CFF 64006400
	v_or_b32_e32 v112, 0x64006400, v27                         // 000000DEC640: 38E036FF 64006400
	v_or_b32_e32 v85, 0x64006400, v85                          // 000000DEC648: 38AAAAFF 64006400
	v_or_b32_e32 v86, 0x64006400, v86                          // 000000DEC650: 38ACACFF 64006400
	v_or_b32_e32 v113, 0x64006400, v23                         // 000000DEC658: 38E22EFF 64006400
	v_or_b32_e32 v114, 0x64006400, v47                         // 000000DEC660: 38E45EFF 64006400
	v_or_b32_e32 v87, 0x64006400, v87                          // 000000DEC668: 38AEAEFF 64006400
	v_or_b32_e32 v88, 0x64006400, v88                          // 000000DEC670: 38B0B0FF 64006400
	v_or_b32_e32 v115, 0x64006400, v24                         // 000000DEC678: 38E630FF 64006400
	v_or_b32_e32 v116, 0x64006400, v48                         // 000000DEC680: 38E860FF 64006400
	v_or_b32_e32 v89, 0x64006400, v89                          // 000000DEC688: 38B2B2FF 64006400
	v_or_b32_e32 v90, 0x64006400, v90                          // 000000DEC690: 38B4B4FF 64006400
	v_or_b32_e32 v117, 0x64006400, v25                         // 000000DEC698: 38EA32FF 64006400
	.long 0xcc0f400a                                           // 000000DEC6A0: CC0F400A
	v_mul_i32_i24_e32 v1, 0xe408, v49                          // 000000DEC6A4: 120262FF 0000E408
	.long 0xcc0f400b                                           // 000000DEC6AC: CC0F400B
	v_mul_i32_i24_e32 v1, 0xe408, v50                          // 000000DEC6B0: 120264FF 0000E408
	.long 0xcc0f400c                                           // 000000DEC6B8: CC0F400C
	v_mul_i32_i24_e32 v1, 0xe408, v51                          // 000000DEC6BC: 120266FF 0000E408
	.long 0xcc0f400d                                           // 000000DEC6C4: CC0F400D
	v_mul_i32_i24_e32 v1, 0xe408, v28                          // 000000DEC6C8: 120238FF 0000E408
	.long 0xcc0f400e                                           // 000000DEC6D0: CC0F400E
	v_mul_i32_i24_e32 v1, 0xe408, v29                          // 000000DEC6D4: 12023AFF 0000E408
	.long 0xcc0f400f                                           // 000000DEC6DC: CC0F400F
	v_mul_i32_i24_e32 v1, 0xe408, v52                          // 000000DEC6E0: 120268FF 0000E408
	.long 0xcc0f4010                                           // 000000DEC6E8: CC0F4010
	v_mul_i32_i24_e32 v1, 0xe408, v53                          // 000000DEC6EC: 12026AFF 0000E408
	.long 0xcc0f4011                                           // 000000DEC6F4: CC0F4011
	v_mul_i32_i24_e32 v1, 0xe408, v30                          // 000000DEC6F8: 12023CFF 0000E408
	.long 0xcc0f4012                                           // 000000DEC700: CC0F4012
	v_mul_i32_i24_e32 v1, 0xe408, v31                          // 000000DEC704: 12023EFF 0000E408
	.long 0xcc0f4013                                           // 000000DEC70C: CC0F4013
	v_mul_i32_i24_e32 v1, 0xe408, v54                          // 000000DEC710: 12026CFF 0000E408
	.long 0xcc0f4014                                           // 000000DEC718: CC0F4014
	v_mul_i32_i24_e32 v1, 0xe408, v55                          // 000000DEC71C: 12026EFF 0000E408
	.long 0xcc0f4015                                           // 000000DEC724: CC0F4015
	v_mul_i32_i24_e32 v1, 0xe408, v32                          // 000000DEC728: 120240FF 0000E408
	.long 0xcc0f4016                                           // 000000DEC730: CC0F4016
	v_mul_i32_i24_e32 v1, 0xe408, v33                          // 000000DEC734: 120242FF 0000E408
	.long 0xcc0f4017                                           // 000000DEC73C: CC0F4017
	v_mul_i32_i24_e32 v1, 0xe408, v56                          // 000000DEC740: 120270FF 0000E408
	.long 0xcc0f4018                                           // 000000DEC748: CC0F4018
	v_mul_i32_i24_e32 v1, 0xe408, v57                          // 000000DEC74C: 120272FF 0000E408
	.long 0xcc0f4019                                           // 000000DEC754: CC0F4019
	v_mul_i32_i24_e32 v1, 0xe408, v34                          // 000000DEC758: 120244FF 0000E408
	.long 0xcc0f401a                                           // 000000DEC760: CC0F401A
	v_mul_i32_i24_e32 v1, 0xe408, v35                          // 000000DEC764: 120246FF 0000E408
	.long 0xcc0f401b                                           // 000000DEC76C: CC0F401B
	v_mul_i32_i24_e32 v1, 0xe408, v58                          // 000000DEC770: 120274FF 0000E408
	.long 0xcc0f401c                                           // 000000DEC778: CC0F401C
	v_mul_i32_i24_e32 v1, 0xe408, v59                          // 000000DEC77C: 120276FF 0000E408
	.long 0xcc0f401d                                           // 000000DEC784: CC0F401D
	v_mul_i32_i24_e32 v1, 0xe408, v60                          // 000000DEC788: 120278FF 0000E408
	.long 0xcc0f401e                                           // 000000DEC790: CC0F401E
	v_mul_i32_i24_e32 v1, 0xe408, v36                          // 000000DEC794: 120248FF 0000E408
	.long 0xcc0f401f                                           // 000000DEC79C: CC0F401F
	v_mul_i32_i24_e32 v1, 0xe408, v61                          // 000000DEC7A0: 12027AFF 0000E408
	.long 0xcc0f4020                                           // 000000DEC7A8: CC0F4020
	v_mul_i32_i24_e32 v1, 0xe408, v62                          // 000000DEC7AC: 12027CFF 0000E408
	.long 0xcc0f4021                                           // 000000DEC7B4: CC0F4021
	v_mul_i32_i24_e32 v1, 0xe408, v91                          // 000000DEC7B8: 1202B6FF 0000E408
	.long 0xcc0f4022                                           // 000000DEC7C0: CC0F4022
	v_mul_i32_i24_e32 v1, 0xe408, v37                          // 000000DEC7C4: 12024AFF 0000E408
	.long 0xcc0f4023                                           // 000000DEC7CC: CC0F4023
	v_mul_i32_i24_e32 v1, 0xe408, v63                          // 000000DEC7D0: 12027EFF 0000E408
	.long 0xcc0f4024                                           // 000000DEC7D8: CC0F4024
	v_mul_i32_i24_e32 v1, 0xe408, v64                          // 000000DEC7DC: 120280FF 0000E408
	.long 0xcc0f4025                                           // 000000DEC7E4: CC0F4025
	v_mul_i32_i24_e32 v1, 0xe408, v92                          // 000000DEC7E8: 1202B8FF 0000E408
	.long 0xcc0f4026                                           // 000000DEC7F0: CC0F4026
	v_mul_i32_i24_e32 v1, 0xe408, v38                          // 000000DEC7F4: 12024CFF 0000E408
	.long 0xcc0f4027                                           // 000000DEC7FC: CC0F4027
	v_mul_i32_i24_e32 v1, 0xe408, v65                          // 000000DEC800: 120282FF 0000E408
	.long 0xcc0f4028                                           // 000000DEC808: CC0F4028
	v_mul_i32_i24_e32 v1, 0xe408, v66                          // 000000DEC80C: 120284FF 0000E408
	.long 0xcc0f4029                                           // 000000DEC814: CC0F4029
	v_mul_i32_i24_e32 v1, 0xe408, v93                          // 000000DEC818: 1202BAFF 0000E408
	.long 0xcc0f402a                                           // 000000DEC820: CC0F402A
	v_mul_i32_i24_e32 v1, 0xe408, v94                          // 000000DEC824: 1202BCFF 0000E408
	.long 0xcc0f402b                                           // 000000DEC82C: CC0F402B
	v_mul_i32_i24_e32 v1, 0xe408, v67                          // 000000DEC830: 120286FF 0000E408
	.long 0xcc0f402c                                           // 000000DEC838: CC0F402C
	v_mul_i32_i24_e32 v1, 0xe408, v68                          // 000000DEC83C: 120288FF 0000E408
	.long 0xcc0f402d                                           // 000000DEC844: CC0F402D
	v_mul_i32_i24_e32 v1, 0xe408, v95                          // 000000DEC848: 1202BEFF 0000E408
	.long 0xcc0f402e                                           // 000000DEC850: CC0F402E
	v_mul_i32_i24_e32 v1, 0xe408, v96                          // 000000DEC854: 1202C0FF 0000E408
	.long 0xcc0f402f                                           // 000000DEC85C: CC0F402F
	v_mul_i32_i24_e32 v1, 0xe408, v69                          // 000000DEC860: 12028AFF 0000E408
	.long 0xcc0f4030                                           // 000000DEC868: CC0F4030
	v_mul_i32_i24_e32 v1, 0xe408, v70                          // 000000DEC86C: 12028CFF 0000E408
	.long 0xcc0f4031                                           // 000000DEC874: CC0F4031
	v_mul_i32_i24_e32 v1, 0xe408, v97                          // 000000DEC878: 1202C2FF 0000E408
	.long 0xcc0f4032                                           // 000000DEC880: CC0F4032
	v_mul_i32_i24_e32 v1, 0xe408, v98                          // 000000DEC884: 1202C4FF 0000E408
	.long 0xcc0f4033                                           // 000000DEC88C: CC0F4033
	v_mul_i32_i24_e32 v1, 0xe408, v71                          // 000000DEC890: 12028EFF 0000E408
	.long 0xcc0f4034                                           // 000000DEC898: CC0F4034
	v_mul_i32_i24_e32 v1, 0xe408, v72                          // 000000DEC89C: 120290FF 0000E408
	.long 0xcc0f4035                                           // 000000DEC8A4: CC0F4035
	v_mul_i32_i24_e32 v1, 0xe408, v99                          // 000000DEC8A8: 1202C6FF 0000E408
	.long 0xcc0f4036                                           // 000000DEC8B0: CC0F4036
	v_mul_i32_i24_e32 v1, 0xe408, v100                         // 000000DEC8B4: 1202C8FF 0000E408
	.long 0xcc0f4037                                           // 000000DEC8BC: CC0F4037
	v_mul_i32_i24_e32 v1, 0xe408, v73                          // 000000DEC8C0: 120292FF 0000E408
	.long 0xcc0f4038                                           // 000000DEC8C8: CC0F4038
	v_mul_i32_i24_e32 v1, 0xe408, v74                          // 000000DEC8CC: 120294FF 0000E408
	.long 0xcc0f4039                                           // 000000DEC8D4: CC0F4039
	v_mul_i32_i24_e32 v1, 0xe408, v101                         // 000000DEC8D8: 1202CAFF 0000E408
	.long 0xcc0f403a                                           // 000000DEC8E0: CC0F403A
	v_mul_i32_i24_e32 v1, 0xe408, v102                         // 000000DEC8E4: 1202CCFF 0000E408
	.long 0xcc0f403b                                           // 000000DEC8EC: CC0F403B
	v_mul_i32_i24_e32 v1, 0xe408, v75                          // 000000DEC8F0: 120296FF 0000E408
	.long 0xcc0f403c                                           // 000000DEC8F8: CC0F403C
	v_mul_i32_i24_e32 v1, 0xe408, v76                          // 000000DEC8FC: 120298FF 0000E408
	.long 0xcc0f403d                                           // 000000DEC904: CC0F403D
	v_mul_i32_i24_e32 v1, 0xe408, v103                         // 000000DEC908: 1202CEFF 0000E408
	.long 0xcc0f403e                                           // 000000DEC910: CC0F403E
	v_mul_i32_i24_e32 v1, 0xe408, v104                         // 000000DEC914: 1202D0FF 0000E408
	.long 0xcc0f403f                                           // 000000DEC91C: CC0F403F
	v_mul_i32_i24_e32 v1, 0xe408, v77                          // 000000DEC920: 12029AFF 0000E408
	.long 0xcc0f4040                                           // 000000DEC928: CC0F4040
	v_mul_i32_i24_e32 v1, 0xe408, v78                          // 000000DEC92C: 12029CFF 0000E408
	.long 0xcc0f4041                                           // 000000DEC934: CC0F4041
	v_mul_i32_i24_e32 v1, 0xe408, v105                         // 000000DEC938: 1202D2FF 0000E408
	.long 0xcc0f4042                                           // 000000DEC940: CC0F4042
	v_mul_i32_i24_e32 v1, 0xe408, v106                         // 000000DEC944: 1202D4FF 0000E408
	.long 0xcc0f4043                                           // 000000DEC94C: CC0F4043
	v_mul_i32_i24_e32 v1, 0xe408, v79                          // 000000DEC950: 12029EFF 0000E408
	.long 0xcc0f4044                                           // 000000DEC958: CC0F4044
	v_mul_i32_i24_e32 v1, 0xe408, v80                          // 000000DEC95C: 1202A0FF 0000E408
	.long 0xcc0f4045                                           // 000000DEC964: CC0F4045
	v_mul_i32_i24_e32 v1, 0xe408, v107                         // 000000DEC968: 1202D6FF 0000E408
	.long 0xcc0f4046                                           // 000000DEC970: CC0F4046
	v_mul_i32_i24_e32 v1, 0xe408, v108                         // 000000DEC974: 1202D8FF 0000E408
	.long 0xcc0f4047                                           // 000000DEC97C: CC0F4047
	v_mul_i32_i24_e32 v1, 0xe408, v81                          // 000000DEC980: 1202A2FF 0000E408
	.long 0xcc0f4048                                           // 000000DEC988: CC0F4048
	v_mul_i32_i24_e32 v1, 0xe408, v82                          // 000000DEC98C: 1202A4FF 0000E408
	.long 0xcc0f4049                                           // 000000DEC994: CC0F4049
	v_mul_i32_i24_e32 v1, 0xe408, v109                         // 000000DEC998: 1202DAFF 0000E408
	.long 0xcc0f404a                                           // 000000DEC9A0: CC0F404A
	v_mul_i32_i24_e32 v1, 0xe408, v110                         // 000000DEC9A4: 1202DCFF 0000E408
	.long 0xcc0f404b                                           // 000000DEC9AC: CC0F404B
	v_mul_i32_i24_e32 v1, 0xe408, v83                          // 000000DEC9B0: 1202A6FF 0000E408
	.long 0xcc0f404c                                           // 000000DEC9B8: CC0F404C
	v_mul_i32_i24_e32 v1, 0xe408, v84                          // 000000DEC9BC: 1202A8FF 0000E408
	.long 0xcc0f404d                                           // 000000DEC9C4: CC0F404D
	v_mul_i32_i24_e32 v1, 0xe408, v111                         // 000000DEC9C8: 1202DEFF 0000E408
	.long 0xcc0f404e                                           // 000000DEC9D0: CC0F404E
	v_mul_i32_i24_e32 v1, 0xe408, v112                         // 000000DEC9D4: 1202E0FF 0000E408
	.long 0xcc0f404f                                           // 000000DEC9DC: CC0F404F
	v_mul_i32_i24_e32 v1, 0xe408, v85                          // 000000DEC9E0: 1202AAFF 0000E408
	.long 0xcc0f4050                                           // 000000DEC9E8: CC0F4050
	v_mul_i32_i24_e32 v1, 0xe408, v86                          // 000000DEC9EC: 1202ACFF 0000E408
	.long 0xcc0f4051                                           // 000000DEC9F4: CC0F4051
	v_mul_i32_i24_e32 v1, 0xe408, v113                         // 000000DEC9F8: 1202E2FF 0000E408
	.long 0xcc0f4052                                           // 000000DECA00: CC0F4052
	v_mul_i32_i24_e32 v1, 0xe408, v114                         // 000000DECA04: 1202E4FF 0000E408
	.long 0xcc0f4053                                           // 000000DECA0C: CC0F4053
	v_mul_i32_i24_e32 v1, 0xe408, v87                          // 000000DECA10: 1202AEFF 0000E408
	.long 0xcc0f4054                                           // 000000DECA18: CC0F4054
	v_mul_i32_i24_e32 v1, 0xe408, v88                          // 000000DECA1C: 1202B0FF 0000E408
	.long 0xcc0f4055                                           // 000000DECA24: CC0F4055
	v_mul_i32_i24_e32 v1, 0xe408, v115                         // 000000DECA28: 1202E6FF 0000E408
	.long 0xcc0f4056                                           // 000000DECA30: CC0F4056
	v_mul_i32_i24_e32 v1, 0xe408, v116                         // 000000DECA34: 1202E8FF 0000E408
	.long 0xcc0f4057                                           // 000000DECA3C: CC0F4057
	v_mul_i32_i24_e32 v1, 0xe408, v89                          // 000000DECA40: 1202B2FF 0000E408
	.long 0xcc0f4058                                           // 000000DECA48: CC0F4058
	v_mul_i32_i24_e32 v1, 0xe408, v90                          // 000000DECA4C: 1202B4FF 0000E408
	.long 0xcc0f4059                                           // 000000DECA54: CC0F4059
	v_mul_i32_i24_e32 v1, 0xe408, v117                         // 000000DECA58: 1202EAFF 0000E408
	s_branch 5                                                 // 000000DECA60: BFA00005 <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_fl_gILi2EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfPKfS5_PKtSD_PtPj+0xe78>
	s_or_b32 exec_lo, exec_lo, s5                              // 000000DECA64: 8C7E057E
	s_add_i32 s4, s4, 1                                        // 000000DECA68: 81048104
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000DECA6C: BF870009
	s_cmp_lg_u32 s4, s3                                        // 000000DECA70: BF070304
	s_cbranch_scc0 191                                         // 000000DECA74: BFA100BF <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_fl_gILi2EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfPKfS5_PKtSD_PtPj+0x1174>
	s_mul_i32 s5, s4, 0x500                                    // 000000DECA78: 9605FF04 00000500
	v_dual_mov_b32 v114, 0 :: v_dual_mov_b32 v115, 0           // 000000DECA80: CA100080 72720080
	v_or_b32_e32 v9, s5, v3                                    // 000000DECA88: 38120605
	ds_load_b128 v[90:93], v9                                  // 000000DECA8C: DBFC0000 5A000009
	ds_load_b128 v[94:97], v9 offset:256                       // 000000DECA94: DBFC0100 5E000009
	ds_load_b128 v[98:101], v9 offset:512                      // 000000DECA9C: DBFC0200 62000009
	ds_load_b128 v[102:105], v9 offset:16                      // 000000DECAA4: DBFC0010 66000009
	v_mov_b32_e32 v116, 0                                      // 000000DECAAC: 7EE80280
	ds_load_b128 v[106:109], v9 offset:768                     // 000000DECAB0: DBFC0300 6A000009
	ds_load_b128 v[110:113], v9 offset:272                     // 000000DECAB8: DBFC0110 6E000009
	v_dual_mov_b32 v117, 0 :: v_dual_mov_b32 v118, 0           // 000000DECAC0: CA100080 75760080
	s_waitcnt lgkmcnt(4)                                       // 000000DECAC8: BF89FC47
	v_dot2acc_f32_f16 v115, v26, v94                           // 000000DECACC: 04E6BD1A
	v_dot2acc_f32_f16 v114, v10, v90                           // 000000DECAD0: 04E4B50A
	s_waitcnt lgkmcnt(1)                                       // 000000DECAD4: BF89FC17
	v_dot2acc_f32_f16 v117, v58, v106                          // 000000DECAD8: 04EAD53A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DECADC: BF870193
	v_dot2acc_f32_f16 v115, v27, v95                           // 000000DECAE0: 04E6BF1B
	v_dot2acc_f32_f16 v114, v11, v91                           // 000000DECAE4: 04E4B70B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DECAE8: BF870193
	v_dot2acc_f32_f16 v117, v59, v107                          // 000000DECAEC: 04EAD73B
	v_dot2acc_f32_f16 v115, v28, v96                           // 000000DECAF0: 04E6C11C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DECAF4: BF870193
	v_dot2acc_f32_f16 v114, v12, v92                           // 000000DECAF8: 04E4B90C
	v_dual_dot2acc_f32_f16 v116, v42, v98 :: v_dual_dot2acc_f32_f16 v117, v60, v108// 000000DECAFC: CB18C52A 7474D93C
	s_delay_alu instid0(VALU_DEP_3)                            // 000000DECB04: BF870003
	v_dot2acc_f32_f16 v115, v29, v97                           // 000000DECB08: 04E6C31D
	ds_load_b128 v[94:97], v9 offset:1024                      // 000000DECB0C: DBFC0400 5E000009
	v_dot2acc_f32_f16 v114, v13, v93                           // 000000DECB14: 04E4BB0D
	v_dot2acc_f32_f16 v116, v43, v99                           // 000000DECB18: 04E8C72B
	ds_load_b128 v[90:93], v9 offset:528                       // 000000DECB1C: DBFC0210 5A000009
	v_dot2acc_f32_f16 v117, v61, v109                          // 000000DECB24: 04EADB3D
	ds_load_b128 v[106:109], v9 offset:1040                    // 000000DECB28: DBFC0410 6A000009
	s_waitcnt lgkmcnt(3)                                       // 000000DECB30: BF89FC37
	v_dual_dot2acc_f32_f16 v115, v30, v110 :: v_dual_dot2acc_f32_f16 v116, v44, v100// 000000DECB34: CB18DD1E 7374C92C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000DECB3C: BF8700C1
	v_dual_dot2acc_f32_f16 v115, v31, v111 :: v_dual_dot2acc_f32_f16 v116, v45, v101// 000000DECB40: CB18DF1F 7374CB2D
	ds_load_b128 v[98:101], v9 offset:784                      // 000000DECB48: DBFC0310 62000009
	v_dual_dot2acc_f32_f16 v115, v32, v112 :: v_dual_dot2acc_f32_f16 v114, v14, v102// 000000DECB50: CB18E120 7372CD0E
	s_waitcnt lgkmcnt(3)                                       // 000000DECB58: BF89FC37
	v_dual_dot2acc_f32_f16 v118, v74, v94 :: v_dual_dot2acc_f32_f16 v115, v33, v113// 000000DECB5C: CB18BD4A 7672E321
	s_delay_alu instid0(VALU_DEP_2)                            // 000000DECB64: BF870002
	v_dot2acc_f32_f16 v114, v15, v103                          // 000000DECB68: 04E4CF0F
	ds_load_b128 v[110:113], v9 offset:544                     // 000000DECB6C: DBFC0220 6E000009
	s_waitcnt lgkmcnt(3)                                       // 000000DECB74: BF89FC37
	v_dot2acc_f32_f16 v116, v46, v90                           // 000000DECB78: 04E8B52E
	v_dot2acc_f32_f16 v118, v75, v95                           // 000000DECB7C: 04ECBF4B
	v_dot2acc_f32_f16 v114, v16, v104                          // 000000DECB80: 04E4D110
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DECB84: BF870112
	v_dot2acc_f32_f16 v118, v76, v96                           // 000000DECB88: 04ECC14C
	v_dot2acc_f32_f16 v114, v17, v105                          // 000000DECB8C: 04E4D311
	ds_load_b128 v[102:105], v9 offset:288                     // 000000DECB90: DBFC0120 66000009
	v_dot2acc_f32_f16 v116, v47, v91                           // 000000DECB98: 04E8B72F
	v_dot2acc_f32_f16 v118, v77, v97                           // 000000DECB9C: 04ECC34D
	ds_load_b128 v[94:97], v9 offset:32                        // 000000DECBA0: DBFC0020 5E000009
	v_dot2acc_f32_f16 v116, v48, v92                           // 000000DECBA8: 04E8B930
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000DECBAC: BF8700C1
	v_dot2acc_f32_f16 v116, v49, v93                           // 000000DECBB0: 04E8BB31
	ds_load_b128 v[90:93], v9 offset:48                        // 000000DECBB4: DBFC0030 5A000009
	s_waitcnt lgkmcnt(3)                                       // 000000DECBBC: BF89FC37
	v_dot2acc_f32_f16 v116, v50, v110                          // 000000DECBC0: 04E8DD32
	v_dot2acc_f32_f16 v116, v51, v111                          // 000000DECBC4: 04E8DF33
	s_waitcnt lgkmcnt(1)                                       // 000000DECBC8: BF89FC17
	v_dot2acc_f32_f16 v114, v18, v94                           // 000000DECBCC: 04E4BD12
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DECBD0: BF870112
	v_dot2acc_f32_f16 v116, v52, v112                          // 000000DECBD4: 04E8E134
	v_dot2acc_f32_f16 v114, v19, v95                           // 000000DECBD8: 04E4BF13
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000DECBDC: BF8700B2
	v_dot2acc_f32_f16 v116, v53, v113                          // 000000DECBE0: 04E8E335
	ds_load_b128 v[110:113], v9 offset:816                     // 000000DECBE4: DBFC0330 6E000009
	v_dot2acc_f32_f16 v114, v20, v96                           // 000000DECBEC: 04E4C114
	v_dot2acc_f32_f16 v114, v21, v97                           // 000000DECBF0: 04E4C315
	ds_load_b128 v[94:97], v9 offset:560                       // 000000DECBF4: DBFC0230 5E000009
	v_dot2acc_f32_f16 v117, v62, v98                           // 000000DECBFC: 04EAC53E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DECC00: BF870091
	v_dot2acc_f32_f16 v117, v63, v99                           // 000000DECC04: 04EAC73F
	v_dot2acc_f32_f16 v117, v64, v100                          // 000000DECC08: 04EAC940
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000DECC0C: BF8700C1
	v_dot2acc_f32_f16 v117, v65, v101                          // 000000DECC10: 04EACB41
	ds_load_b128 v[98:101], v9 offset:800                      // 000000DECC14: DBFC0320 62000009
	s_waitcnt lgkmcnt(1)                                       // 000000DECC1C: BF89FC17
	v_dot2acc_f32_f16 v116, v54, v94                           // 000000DECC20: 04E8BD36
	v_dot2acc_f32_f16 v116, v55, v95                           // 000000DECC24: 04E8BF37
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DECC28: BF8700A1
	v_dot2acc_f32_f16 v116, v56, v96                           // 000000DECC2C: 04E8C138
	s_waitcnt lgkmcnt(0)                                       // 000000DECC30: BF89FC07
	v_dual_dot2acc_f32_f16 v116, v57, v97 :: v_dual_dot2acc_f32_f16 v117, v66, v98// 000000DECC34: CB18C339 7474C542
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DECC3C: BF870091
	v_dual_dot2acc_f32_f16 v118, v78, v106 :: v_dual_dot2acc_f32_f16 v117, v67, v99// 000000DECC40: CB18D54E 7674C743
	v_dual_dot2acc_f32_f16 v117, v68, v100 :: v_dual_dot2acc_f32_f16 v118, v79, v107// 000000DECC48: CB18C944 7576D74F
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DECC50: BF870001
	v_dual_dot2acc_f32_f16 v117, v69, v101 :: v_dual_dot2acc_f32_f16 v118, v80, v108// 000000DECC54: CB18CB45 7576D950
	ds_load_b128 v[98:101], v9 offset:1072                     // 000000DECC5C: DBFC0430 62000009
	v_dual_dot2acc_f32_f16 v117, v70, v110 :: v_dual_dot2acc_f32_f16 v118, v81, v109// 000000DECC64: CB18DD46 7576DB51
	ds_load_b128 v[106:109], v9 offset:304                     // 000000DECC6C: DBFC0130 6A000009
	v_dot2acc_f32_f16 v115, v34, v102                          // 000000DECC74: 04E6CD22
	v_dual_dot2acc_f32_f16 v117, v71, v111 :: v_dual_dot2acc_f32_f16 v114, v22, v90// 000000DECC78: CB18DF47 7572B516
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DECC80: BF870112
	v_dot2acc_f32_f16 v115, v35, v103                          // 000000DECC84: 04E6CF23
	v_dual_dot2acc_f32_f16 v117, v72, v112 :: v_dual_dot2acc_f32_f16 v114, v23, v91// 000000DECC88: CB18E148 7572B717
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DECC90: BF870112
	v_dot2acc_f32_f16 v115, v36, v104                          // 000000DECC94: 04E6D124
	v_dual_dot2acc_f32_f16 v117, v73, v113 :: v_dual_dot2acc_f32_f16 v114, v24, v92// 000000DECC98: CB18E349 7572B918
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000DECCA0: BF8700C2
	v_dot2acc_f32_f16 v115, v37, v105                          // 000000DECCA4: 04E6D325
	ds_load_b128 v[102:105], v9 offset:1056                    // 000000DECCA8: DBFC0420 66000009
	s_waitcnt lgkmcnt(1)                                       // 000000DECCB0: BF89FC17
	v_dual_dot2acc_f32_f16 v114, v25, v93 :: v_dual_dot2acc_f32_f16 v115, v38, v106// 000000DECCB4: CB18BB19 7272D526
	v_fma_f32 v9, v5, v114, 0                                  // 000000DECCBC: D6130009 0202E505
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DECCC4: BF870092
	v_dot2acc_f32_f16 v115, v39, v107                          // 000000DECCC8: 04E6D727
	v_dot2acc_f32_f16 v115, v40, v108                          // 000000DECCCC: 04E6D928
	s_waitcnt lgkmcnt(0)                                       // 000000DECCD0: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DECCD4: BF870091
	v_dual_dot2acc_f32_f16 v115, v41, v109 :: v_dual_dot2acc_f32_f16 v118, v82, v102// 000000DECCD8: CB18DB29 7376CD52
	v_fmac_f32_e32 v9, v6, v115                                // 000000DECCE0: 5612E706
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DECCE4: BF870091
	v_fmac_f32_e32 v9, v7, v116                                // 000000DECCE8: 5612E907
	v_dual_dot2acc_f32_f16 v118, v83, v103 :: v_dual_fmac_f32 v9, v8, v117// 000000DECCEC: CB00CF53 7608EB08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DECCF4: BF870091
	v_dot2acc_f32_f16 v118, v84, v104                          // 000000DECCF8: 04ECD154
	v_dot2acc_f32_f16 v118, v85, v105                          // 000000DECCFC: 04ECD355
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DECD00: BF870091
	v_dot2acc_f32_f16 v118, v86, v98                           // 000000DECD04: 04ECC556
	v_dot2acc_f32_f16 v118, v87, v99                           // 000000DECD08: 04ECC757
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DECD0C: BF870091
	v_dot2acc_f32_f16 v118, v88, v100                          // 000000DECD10: 04ECC958
	v_dot2acc_f32_f16 v118, v89, v101                          // 000000DECD14: 04ECCB59
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DECD18: BF870091
	v_fmac_f32_e32 v9, v4, v118                                // 000000DECD1C: 5612ED04
	v_mov_b32_dpp v90, v9 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DECD20: 7EB402FA FF016109
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DECD28: BF870091
	v_add_f32_e32 v9, v9, v90                                  // 000000DECD2C: 0612B509
	v_mov_b32_dpp v90, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DECD30: 7EB402FA FF016209
	s_and_saveexec_b32 s5, vcc_lo                              // 000000DECD38: BE85206A
	s_cbranch_execz 65353                                      // 000000DECD3C: BFA5FF49 <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_fl_gILi2EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfPKfS5_PKtSD_PtPj+0xe64>
	s_lshl_b32 s6, s4, 2                                       // 000000DECD40: 84068204
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DECD44: BF870001
	v_add_f32_e32 v9, v9, v90                                  // 000000DECD48: 0612B509
	v_mov_b32_e32 v91, s6                                      // 000000DECD4C: 7EB60206
	ds_load_b32 v91, v91 offset:2560                           // 000000DECD50: D8D80A00 5B00005B
	s_waitcnt lgkmcnt(0)                                       // 000000DECD58: BF89FC07
	v_mad_i64_i32 v[91:92], null, 0x2800, v91, v[1:2]          // 000000DECD5C: D6FF7C5B 0406B6FF 00002800
	global_store_b32 v[91:92], v9, off                         // 000000DECD68: DC6A0000 007C095B
	s_branch 65340                                             // 000000DECD70: BFA0FF3C <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_fl_gILi2EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfPKfS5_PKtSD_PtPj+0xe64>
	s_load_b64 s[8:9], s[0:1], 0x60                            // 000000DECD74: F4040200 F8000060
	s_lshr_b32 s4, s2, 31                                      // 000000DECD7C: 85049F02
	s_waitcnt lgkmcnt(0)                                       // 000000DECD80: BF89FC07
	s_waitcnt_vscnt null, 0x0                                  // 000000DECD84: BC7C0000
	buffer_gl1_inv                                             // 000000DECD88: E0B00000 00000000
	buffer_gl0_inv                                             // 000000DECD90: E0AC0000 00000000
	s_add_i32 s2, s2, s4                                       // 000000DECD98: 81020402
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000DECD9C: BF870009
	s_ashr_i32 s10, s2, 1                                      // 000000DECDA0: 860A8102
	s_mov_b32 s2, exec_lo                                      // 000000DECDA4: BE82007E
	s_barrier                                                  // 000000DECDA8: BFBD0000
	buffer_gl0_inv                                             // 000000DECDAC: E0AC0000 00000000
	.long 0xd4cc007e                                           // 000000DECDB4: D4CC007E
	v_cndmask_b32_e32 v1, s3, v0, vcc_lo                       // 000000DECDB8: 02020003
	s_cbranch_execz 32                                         // 000000DECDBC: BFA50020 <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_fl_gILi2EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfPKfS5_PKtSD_PtPj+0x1240>
	v_dual_mov_b32 v4, 1 :: v_dual_lshlrev_b32 v3, 2, v0       // 000000DECDC0: CA220081 04020082
	ds_load_b32 v1, v3 offset:2560                             // 000000DECDC8: D8D80A00 01000003
	s_waitcnt lgkmcnt(0)                                       // 000000DECDD0: BF89FC07
	.long 0xd72e0001                                           // 000000DECDD4: D72E0001
	v_cndmask_b32_e32 v1, 0x66666667, v1, vcc_lo               // 000000DECDD8: 020202FF 66666667
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DECDE0: BF8700A1
	v_lshrrev_b32_e32 v2, 31, v1                               // 000000DECDE4: 3204029F
	v_lshrrev_b32_e32 v1, 2, v1                                // 000000DECDE8: 32020282
	v_add_nc_u32_e32 v1, v1, v2                                // 000000DECDEC: 4A020501
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DECDF0: BF870091
	v_mad_u64_u32 v[1:2], null, v1, 20, s[10:11]               // 000000DECDF4: D6FE7C01 00292901
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000DECDFC: 3404029F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DECE00: BF870091
	.long 0xd73c0001                                           // 000000DECE04: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 000000DECE08: 02020282
	.long 0xd7006a01                                           // 000000DECE0C: D7006A01
	v_cndmask_b32_e32 v1, s8, v1, vcc_lo                       // 000000DECE10: 02020208
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DECE14: BF870001
	v_add_co_ci_u32_e64 v2, null, s9, v2, vcc_lo               // 000000DECE18: D5207C02 01AA0409
	global_atomic_add_u32 v1, v[1:2], v4, off glc              // 000000DECE20: DCD64000 017C0401
	s_waitcnt vmcnt(0)                                         // 000000DECE28: BF8903F7
	v_cmp_eq_u32_e32 vcc_lo, 19, v1                            // 000000DECE2C: 7C940293
	v_cndmask_b32_e64 v1, 0, 1, vcc_lo                         // 000000DECE30: D5010001 01A90280
	ds_store_b32 v3, v1 offset:2568                            // 000000DECE38: D8340A08 00000103
	s_or_b32 exec_lo, exec_lo, s2                              // 000000DECE40: 8C7E027E
	v_lshrrev_b32_e32 v1, 5, v0                                // 000000DECE44: 32020085
	s_waitcnt lgkmcnt(0)                                       // 000000DECE48: BF89FC07
	s_barrier                                                  // 000000DECE4C: BFBD0000
	buffer_gl0_inv                                             // 000000DECE50: E0AC0000 00000000
	s_mov_b32 s2, exec_lo                                      // 000000DECE58: BE82007E
	.long 0xd4c4007e                                           // 000000DECE5C: D4C4007E
	v_cndmask_b32_e32 v1, s3, v1, vcc_lo                       // 000000DECE60: 02020203
	s_cbranch_execz 651                                        // 000000DECE64: BFA5028B <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_fl_gILi2EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfPKfS5_PKtSD_PtPj+0x1c94>
	v_lshlrev_b32_e32 v1, 2, v1                                // 000000DECE68: 30020282
	ds_load_b32 v2, v1 offset:2568                             // 000000DECE6C: D8D80A08 02000001
	s_waitcnt lgkmcnt(0)                                       // 000000DECE74: BF89FC07
	v_cmp_ne_u32_e32 vcc_lo, 0, v2                             // 000000DECE78: 7C9A0480
	s_and_b32 exec_lo, exec_lo, vcc_lo                         // 000000DECE7C: 8B7E6A7E
	s_cbranch_execz 644                                        // 000000DECE80: BFA50284 <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_fl_gILi2EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfPKfS5_PKtSD_PtPj+0x1c94>
	v_add_nc_u32_e32 v1, 0xa08, v1                             // 000000DECE84: 4A0202FF 00000A08
	buffer_gl1_inv                                             // 000000DECE8C: E0B00000 00000000
	buffer_gl0_inv                                             // 000000DECE94: E0AC0000 00000000
	v_and_b32_e32 v3, 31, v0                                   // 000000DECE9C: 3606009F
	s_load_b256 s[0:7], s[0:1], 0x40                           // 000000DECEA0: F40C0000 F8000040
	v_add_nc_u32_e32 v1, -8, v1                                // 000000DECEA8: 4A0202C8
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000DECEAC: BF8700D2
	v_lshlrev_b32_e32 v2, 2, v3                                // 000000DECEB0: 30040682
	ds_load_b32 v1, v1                                         // 000000DECEB4: D8D80000 01000001
	v_lshl_or_b32 v4, s10, 7, v2                               // 000000DECEBC: D6560004 04090E0A
	s_waitcnt lgkmcnt(0)                                       // 000000DECEC4: BF89FC07
	.long 0xd72e0001                                           // 000000DECEC8: D72E0001
	v_cndmask_b32_e32 v1, 0x66666667, v1, vcc_lo               // 000000DECECC: 020202FF 66666667
	v_lshrrev_b32_e32 v5, 31, v1                               // 000000DECED4: 320A029F
	v_ashrrev_i32_e32 v1, 2, v1                                // 000000DECED8: 34020282
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000DECEDC: BF870121
	v_add_nc_u32_e32 v1, v1, v5                                // 000000DECEE0: 4A020B01
	v_ashrrev_i32_e32 v5, 31, v4                               // 000000DECEE4: 340A089F
	.long 0xd72c0006                                           // 000000DECEE8: D72C0006
	v_cndmask_b32_e32 v0, v1, v138, vcc_lo                     // 000000DECEEC: 02011501
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000DECEF0: BF870122
	.long 0xd73c0008                                           // 000000DECEF4: D73C0008
	v_cndmask_b32_e32 v1, 2, v4, vcc_lo                        // 000000DECEF8: 02020882
	.long 0xd73c0004                                           // 000000DECEFC: D73C0004
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 000000DECF00: 02020881
	.long 0xd7006a08                                           // 000000DECF04: D7006A08
	v_cndmask_b32_e32 v1, s16, v8, vcc_lo                      // 000000DECF08: 02021010
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DECF0C: BF870214
	v_ashrrev_i32_e32 v7, 31, v6                               // 000000DECF10: 340E0C9F
	v_add_co_ci_u32_e64 v9, null, s17, v9, vcc_lo              // 000000DECF14: D5207C09 01AA1211
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DECF1C: BF870112
	.long 0xd73c000a                                           // 000000DECF20: D73C000A
	v_cndmask_b32_e32 v1, 2, v6, vcc_lo                        // 000000DECF24: 02020C82
	v_mad_i64_i32 v[12:13], null, 0x2800, v6, v[8:9]           // 000000DECF28: D6FF7C0C 04220CFF 00002800
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DECF34: BF870092
	.long 0xd7006a0a                                           // 000000DECF38: D7006A0A
	v_cndmask_b32_e32 v1, s18, v10, vcc_lo                     // 000000DECF3C: 02021412
	v_add_co_ci_u32_e64 v11, null, s19, v11, vcc_lo            // 000000DECF40: D5207C0B 01AA1613
	s_delay_alu instid0(VALU_DEP_3)                            // 000000DECF48: BF870003
	.long 0xd7006a0e                                           // 000000DECF4C: D7006A0E
	v_cndmask_b32_e32 v1, 0x2800, v12, vcc_lo                  // 000000DECF50: 020218FF 00002800
	global_load_b32 v2, v[10:11], off                          // 000000DECF58: DC520000 027C000A
	s_clause 0x3                                               // 000000DECF60: BF850003
	global_load_b32 v7, v[12:13], off glc                      // 000000DECF64: DC524000 077C000C
	global_load_b32 v16, v[12:13], off offset:4 glc            // 000000DECF6C: DC524004 107C000C
	global_load_b32 v17, v[12:13], off offset:8 glc            // 000000DECF74: DC524008 117C000C
	global_load_b32 v18, v[12:13], off offset:12 glc           // 000000DECF7C: DC52400C 127C000C
	v_add_co_ci_u32_e64 v15, null, 0, v13, vcc_lo              // 000000DECF84: D5207C0F 01AA1A80
	.long 0xd7006a0c                                           // 000000DECF8C: D7006A0C
	v_cndmask_b32_e32 v1, 0x2000, v12, vcc_lo                  // 000000DECF90: 020218FF 00002000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DECF98: BF870001
	v_add_co_ci_u32_e64 v13, null, 0, v13, vcc_lo              // 000000DECF9C: D5207C0D 01AA1A80
	s_waitcnt vmcnt(3)                                         // 000000DECFA4: BF890FF7
	v_mul_f32_e32 v19, v2, v7                                  // 000000DECFA8: 10260F02
	s_waitcnt vmcnt(2)                                         // 000000DECFAC: BF890BF7
	v_mul_f32_e32 v16, v2, v16                                 // 000000DECFB0: 10202102
	s_waitcnt vmcnt(1)                                         // 000000DECFB4: BF8907F7
	v_mul_f32_e32 v17, v2, v17                                 // 000000DECFB8: 10222302
	s_waitcnt vmcnt(0)                                         // 000000DECFBC: BF8903F7
	v_mul_f32_e32 v18, v2, v18                                 // 000000DECFC0: 10242502
	global_load_b32 v2, v[10:11], off offset:4                 // 000000DECFC4: DC520004 027C000A
	s_clause 0x3                                               // 000000DECFCC: BF850003
	global_load_b32 v7, v[12:13], off offset:2048 glc          // 000000DECFD0: DC524800 077C000C
	global_load_b32 v20, v[14:15], off offset:4 glc            // 000000DECFD8: DC524004 147C000E
	global_load_b32 v21, v[14:15], off offset:8 glc            // 000000DECFE0: DC524008 157C000E
	global_load_b32 v14, v[14:15], off offset:12 glc           // 000000DECFE8: DC52400C 0E7C000E
	s_waitcnt vmcnt(3)                                         // 000000DECFF0: BF890FF7
	v_mul_f32_e32 v22, v2, v7                                  // 000000DECFF4: 102C0F02
	s_waitcnt vmcnt(2)                                         // 000000DECFF8: BF890BF7
	v_mul_f32_e32 v20, v2, v20                                 // 000000DECFFC: 10282902
	v_add_nc_u32_e32 v12, 2, v6                                // 000000DED000: 4A180C82
	s_waitcnt vmcnt(1)                                         // 000000DED004: BF8907F7
	v_mul_f32_e32 v21, v2, v21                                 // 000000DED008: 102A2B02
	s_waitcnt vmcnt(0)                                         // 000000DED00C: BF8903F7
	v_mul_f32_e32 v23, v2, v14                                 // 000000DED010: 102E1D02
	v_mad_i64_i32 v[12:13], null, 0x2800, v12, v[8:9]          // 000000DED014: D6FF7C0C 042218FF 00002800
	global_load_b32 v2, v[10:11], off offset:8                 // 000000DED020: DC520008 027C000A
	s_clause 0x3                                               // 000000DED028: BF850003
	global_load_b32 v7, v[12:13], off glc                      // 000000DED02C: DC524000 077C000C
	global_load_b32 v24, v[12:13], off offset:4 glc            // 000000DED034: DC524004 187C000C
	global_load_b32 v25, v[12:13], off offset:8 glc            // 000000DED03C: DC524008 197C000C
	global_load_b32 v26, v[12:13], off offset:12 glc           // 000000DED044: DC52400C 1A7C000C
	.long 0xd7006a0e                                           // 000000DED04C: D7006A0E
	v_cndmask_b32_e32 v1, 0x2800, v12, vcc_lo                  // 000000DED050: 020218FF 00002800
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DED058: BF8700A1
	v_add_co_ci_u32_e64 v15, null, 0, v13, vcc_lo              // 000000DED05C: D5207C0F 01AA1A80
	.long 0xd7006a0c                                           // 000000DED064: D7006A0C
	v_cndmask_b32_e32 v1, 0x2000, v12, vcc_lo                  // 000000DED068: 020218FF 00002000
	v_add_co_ci_u32_e64 v13, null, 0, v13, vcc_lo              // 000000DED070: D5207C0D 01AA1A80
	s_waitcnt vmcnt(3)                                         // 000000DED078: BF890FF7
	v_mul_f32_e32 v27, v2, v7                                  // 000000DED07C: 10360F02
	s_waitcnt vmcnt(2)                                         // 000000DED080: BF890BF7
	v_mul_f32_e32 v24, v2, v24                                 // 000000DED084: 10303102
	s_waitcnt vmcnt(1)                                         // 000000DED088: BF8907F7
	v_mul_f32_e32 v25, v2, v25                                 // 000000DED08C: 10323302
	s_waitcnt vmcnt(0)                                         // 000000DED090: BF8903F7
	v_mul_f32_e32 v26, v2, v26                                 // 000000DED094: 10343502
	global_load_b32 v2, v[10:11], off offset:12                // 000000DED098: DC52000C 027C000A
	s_clause 0x3                                               // 000000DED0A0: BF850003
	global_load_b32 v7, v[12:13], off offset:2048 glc          // 000000DED0A4: DC524800 077C000C
	global_load_b32 v28, v[14:15], off offset:4 glc            // 000000DED0AC: DC524004 1C7C000E
	global_load_b32 v29, v[14:15], off offset:8 glc            // 000000DED0B4: DC524008 1D7C000E
	global_load_b32 v14, v[14:15], off offset:12 glc           // 000000DED0BC: DC52400C 0E7C000E
	v_add_nc_u32_e32 v12, 4, v6                                // 000000DED0C4: 4A180C84
	s_waitcnt vmcnt(3)                                         // 000000DED0C8: BF890FF7
	v_mul_f32_e32 v30, v2, v7                                  // 000000DED0CC: 103C0F02
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DED0D0: BF870001
	v_mad_i64_i32 v[12:13], null, 0x2800, v12, v[8:9]          // 000000DED0D4: D6FF7C0C 042218FF 00002800
	s_waitcnt vmcnt(2)                                         // 000000DED0E0: BF890BF7
	v_mul_f32_e32 v28, v2, v28                                 // 000000DED0E4: 10383902
	s_waitcnt vmcnt(1)                                         // 000000DED0E8: BF8907F7
	v_mul_f32_e32 v29, v2, v29                                 // 000000DED0EC: 103A3B02
	s_waitcnt vmcnt(0)                                         // 000000DED0F0: BF8903F7
	v_mul_f32_e32 v31, v2, v14                                 // 000000DED0F4: 103E1D02
	global_load_b32 v2, v[10:11], off offset:16                // 000000DED0F8: DC520010 027C000A
	s_clause 0x3                                               // 000000DED100: BF850003
	global_load_b32 v7, v[12:13], off glc                      // 000000DED104: DC524000 077C000C
	global_load_b32 v32, v[12:13], off offset:4 glc            // 000000DED10C: DC524004 207C000C
	global_load_b32 v33, v[12:13], off offset:8 glc            // 000000DED114: DC524008 217C000C
	global_load_b32 v34, v[12:13], off offset:12 glc           // 000000DED11C: DC52400C 227C000C
	.long 0xd7006a0e                                           // 000000DED124: D7006A0E
	v_cndmask_b32_e32 v1, 0x2800, v12, vcc_lo                  // 000000DED128: 020218FF 00002800
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DED130: BF8700A1
	v_add_co_ci_u32_e64 v15, null, 0, v13, vcc_lo              // 000000DED134: D5207C0F 01AA1A80
	.long 0xd7006a0c                                           // 000000DED13C: D7006A0C
	v_cndmask_b32_e32 v1, 0x2000, v12, vcc_lo                  // 000000DED140: 020218FF 00002000
	v_add_co_ci_u32_e64 v13, null, 0, v13, vcc_lo              // 000000DED148: D5207C0D 01AA1A80
	s_waitcnt vmcnt(3)                                         // 000000DED150: BF890FF7
	v_mul_f32_e32 v35, v2, v7                                  // 000000DED154: 10460F02
	s_waitcnt vmcnt(2)                                         // 000000DED158: BF890BF7
	v_mul_f32_e32 v32, v2, v32                                 // 000000DED15C: 10404102
	s_waitcnt vmcnt(1)                                         // 000000DED160: BF8907F7
	v_mul_f32_e32 v33, v2, v33                                 // 000000DED164: 10424302
	s_waitcnt vmcnt(0)                                         // 000000DED168: BF8903F7
	v_mul_f32_e32 v34, v2, v34                                 // 000000DED16C: 10444502
	global_load_b32 v2, v[10:11], off offset:20                // 000000DED170: DC520014 027C000A
	s_clause 0x3                                               // 000000DED178: BF850003
	global_load_b32 v7, v[12:13], off offset:2048 glc          // 000000DED17C: DC524800 077C000C
	global_load_b32 v36, v[14:15], off offset:4 glc            // 000000DED184: DC524004 247C000E
	global_load_b32 v37, v[14:15], off offset:8 glc            // 000000DED18C: DC524008 257C000E
	global_load_b32 v14, v[14:15], off offset:12 glc           // 000000DED194: DC52400C 0E7C000E
	v_add_nc_u32_e32 v12, 6, v6                                // 000000DED19C: 4A180C86
	v_add_nc_u32_e32 v6, 8, v6                                 // 000000DED1A0: 4A0C0C88
	s_waitcnt vmcnt(3)                                         // 000000DED1A4: BF890FF7
	v_mul_f32_e32 v38, v2, v7                                  // 000000DED1A8: 104C0F02
	s_delay_alu instid0(VALU_DEP_2)                            // 000000DED1AC: BF870002
	v_mad_i64_i32 v[12:13], null, 0x2800, v12, v[8:9]          // 000000DED1B0: D6FF7C0C 042218FF 00002800
	s_waitcnt vmcnt(2)                                         // 000000DED1BC: BF890BF7
	v_mul_f32_e32 v36, v2, v36                                 // 000000DED1C0: 10484902
	s_waitcnt vmcnt(1)                                         // 000000DED1C4: BF8907F7
	v_mul_f32_e32 v37, v2, v37                                 // 000000DED1C8: 104A4B02
	s_waitcnt vmcnt(0)                                         // 000000DED1CC: BF8903F7
	v_mul_f32_e32 v39, v2, v14                                 // 000000DED1D0: 104E1D02
	global_load_b32 v2, v[10:11], off offset:24                // 000000DED1D4: DC520018 027C000A
	s_clause 0x3                                               // 000000DED1DC: BF850003
	global_load_b32 v7, v[12:13], off glc                      // 000000DED1E0: DC524000 077C000C
	global_load_b32 v40, v[12:13], off offset:4 glc            // 000000DED1E8: DC524004 287C000C
	global_load_b32 v41, v[12:13], off offset:8 glc            // 000000DED1F0: DC524008 297C000C
	global_load_b32 v42, v[12:13], off offset:12 glc           // 000000DED1F8: DC52400C 2A7C000C
	.long 0xd7006a0e                                           // 000000DED200: D7006A0E
	v_cndmask_b32_e32 v1, 0x2800, v12, vcc_lo                  // 000000DED204: 020218FF 00002800
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DED20C: BF8700A1
	v_add_co_ci_u32_e64 v15, null, 0, v13, vcc_lo              // 000000DED210: D5207C0F 01AA1A80
	.long 0xd7006a0c                                           // 000000DED218: D7006A0C
	v_cndmask_b32_e32 v1, 0x2000, v12, vcc_lo                  // 000000DED21C: 020218FF 00002000
	v_add_co_ci_u32_e64 v13, null, 0, v13, vcc_lo              // 000000DED224: D5207C0D 01AA1A80
	s_waitcnt vmcnt(3)                                         // 000000DED22C: BF890FF7
	v_mul_f32_e32 v43, v2, v7                                  // 000000DED230: 10560F02
	s_waitcnt vmcnt(2)                                         // 000000DED234: BF890BF7
	v_mul_f32_e32 v40, v2, v40                                 // 000000DED238: 10505102
	s_waitcnt vmcnt(1)                                         // 000000DED23C: BF8907F7
	v_mul_f32_e32 v41, v2, v41                                 // 000000DED240: 10525302
	s_waitcnt vmcnt(0)                                         // 000000DED244: BF8903F7
	v_mul_f32_e32 v42, v2, v42                                 // 000000DED248: 10545502
	global_load_b32 v2, v[10:11], off offset:28                // 000000DED24C: DC52001C 027C000A
	s_clause 0x3                                               // 000000DED254: BF850003
	global_load_b32 v12, v[12:13], off offset:2048 glc         // 000000DED258: DC524800 0C7C000C
	global_load_b32 v13, v[14:15], off offset:4 glc            // 000000DED260: DC524004 0D7C000E
	global_load_b32 v44, v[14:15], off offset:8 glc            // 000000DED268: DC524008 2C7C000E
	global_load_b32 v14, v[14:15], off offset:12 glc           // 000000DED270: DC52400C 0E7C000E
	v_mad_i64_i32 v[6:7], null, 0x2800, v6, v[8:9]             // 000000DED278: D6FF7C06 04220CFF 00002800
	s_waitcnt vmcnt(3)                                         // 000000DED284: BF890FF7
	v_mul_f32_e32 v12, v2, v12                                 // 000000DED288: 10181902
	s_waitcnt vmcnt(2)                                         // 000000DED28C: BF890BF7
	v_mul_f32_e32 v13, v2, v13                                 // 000000DED290: 101A1B02
	s_waitcnt vmcnt(1)                                         // 000000DED294: BF8907F7
	v_mul_f32_e32 v15, v2, v44                                 // 000000DED298: 101E5902
	s_waitcnt vmcnt(0)                                         // 000000DED29C: BF8903F7
	v_mul_f32_e32 v14, v2, v14                                 // 000000DED2A0: 101C1D02
	global_load_b32 v2, v[10:11], off offset:32                // 000000DED2A4: DC520020 027C000A
	s_clause 0x3                                               // 000000DED2AC: BF850003
	global_load_b32 v44, v[6:7], off glc                       // 000000DED2B0: DC524000 2C7C0006
	global_load_b32 v45, v[6:7], off offset:4 glc              // 000000DED2B8: DC524004 2D7C0006
	global_load_b32 v46, v[6:7], off offset:8 glc              // 000000DED2C0: DC524008 2E7C0006
	global_load_b32 v47, v[6:7], off offset:12 glc             // 000000DED2C8: DC52400C 2F7C0006
	.long 0xd7006a08                                           // 000000DED2D0: D7006A08
	v_cndmask_b32_e32 v1, 0x2800, v6, vcc_lo                   // 000000DED2D4: 02020CFF 00002800
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DED2DC: BF8700A1
	v_add_co_ci_u32_e64 v9, null, 0, v7, vcc_lo                // 000000DED2E0: D5207C09 01AA0E80
	.long 0xd7006a06                                           // 000000DED2E8: D7006A06
	v_cndmask_b32_e32 v1, 0x2000, v6, vcc_lo                   // 000000DED2EC: 02020CFF 00002000
	v_add_co_ci_u32_e64 v7, null, 0, v7, vcc_lo                // 000000DED2F4: D5207C07 01AA0E80
	s_waitcnt vmcnt(3)                                         // 000000DED2FC: BF890FF7
	v_mul_f32_e32 v44, v2, v44                                 // 000000DED300: 10585902
	s_waitcnt vmcnt(2)                                         // 000000DED304: BF890BF7
	v_mul_f32_e32 v45, v2, v45                                 // 000000DED308: 105A5B02
	s_waitcnt vmcnt(1)                                         // 000000DED30C: BF8907F7
	v_mul_f32_e32 v46, v2, v46                                 // 000000DED310: 105C5D02
	s_waitcnt vmcnt(0)                                         // 000000DED314: BF8903F7
	v_mul_f32_e32 v47, v2, v47                                 // 000000DED318: 105E5F02
	global_load_b32 v2, v[10:11], off offset:36                // 000000DED31C: DC520024 027C000A
	s_clause 0x3                                               // 000000DED324: BF850003
	global_load_b32 v10, v[6:7], off offset:2048 glc           // 000000DED328: DC524800 0A7C0006
	global_load_b32 v11, v[8:9], off offset:4 glc              // 000000DED330: DC524004 0B7C0008
	global_load_b32 v48, v[8:9], off offset:8 glc              // 000000DED338: DC524008 307C0008
	global_load_b32 v49, v[8:9], off offset:12 glc             // 000000DED340: DC52400C 317C0008
	.long 0xd7006a08                                           // 000000DED348: D7006A08
	v_cndmask_b32_e32 v1, s0, v4, vcc_lo                       // 000000DED34C: 02020800
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DED350: BF870001
	v_add_co_ci_u32_e64 v9, null, s1, v5, vcc_lo               // 000000DED354: D5207C09 01AA0A01
	v_mad_i64_i32 v[6:7], null, 0x1400, v1, s[2:3]             // 000000DED35C: D6FF7C06 000A02FF 00001400
	s_mov_b32 s0, 0x76543210                                   // 000000DED368: BE8000FF 76543210
	s_waitcnt vmcnt(3)                                         // 000000DED370: BF890FF7
	v_mul_f32_e32 v50, v2, v10                                 // 000000DED374: 10641502
	s_waitcnt vmcnt(2)                                         // 000000DED378: BF890BF7
	v_mul_f32_e32 v51, v2, v11                                 // 000000DED37C: 10661702
	s_waitcnt vmcnt(1)                                         // 000000DED380: BF8907F7
	v_mul_f32_e32 v48, v2, v48                                 // 000000DED384: 10606102
	s_waitcnt vmcnt(0)                                         // 000000DED388: BF8903F7
	v_mul_f32_e32 v49, v2, v49                                 // 000000DED38C: 10626302
	global_load_b64 v[8:9], v[8:9], off                        // 000000DED390: DC560000 087C0008
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000DED398: 3404029F
	.long 0xd7006a06                                           // 000000DED39C: D7006A06
	v_cndmask_b32_e32 v1, v6, v4, vcc_lo                       // 000000DED3A0: 02020906
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DED3A4: BF870191
	v_add_co_ci_u32_e64 v7, null, v7, v5, vcc_lo               // 000000DED3A8: D5207C07 01AA0B07
	.long 0xd73c000a                                           // 000000DED3B0: D73C000A
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 000000DED3B4: 02020282
	global_load_b64 v[6:7], v[6:7], off                        // 000000DED3B8: DC560000 067C0006
	.long 0xd7006a0a                                           // 000000DED3C0: D7006A0A
	v_cndmask_b32_e32 v1, s4, v10, vcc_lo                      // 000000DED3C4: 02021404
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000DED3C8: BF870141
	v_add_co_ci_u32_e64 v11, null, s5, v11, vcc_lo             // 000000DED3CC: D5207C0B 01AA1605
	global_load_b32 v2, v[10:11], off                          // 000000DED3D4: DC520000 027C000A
	v_dual_add_f32 v10, 0, v19 :: v_dual_add_f32 v11, 0, v16   // 000000DED3DC: C9082680 0A0A2080
	v_dual_add_f32 v16, 0, v17 :: v_dual_add_f32 v17, 0, v18   // 000000DED3E4: C9082280 10102480
	v_dual_add_f32 v10, v10, v22 :: v_dual_add_f32 v11, v11, v20// 000000DED3EC: C9082D0A 0A0A290B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DED3F4: BF870112
	v_dual_add_f32 v16, v16, v21 :: v_dual_add_f32 v17, v17, v23// 000000DED3F8: C9082B10 10102F11
	v_dual_add_f32 v10, v10, v27 :: v_dual_add_f32 v11, v11, v24// 000000DED400: C908370A 0A0A310B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DED408: BF870112
	v_dual_add_f32 v16, v16, v25 :: v_dual_add_f32 v17, v17, v26// 000000DED40C: C9083310 10103511
	v_dual_add_f32 v10, v10, v30 :: v_dual_add_f32 v11, v11, v28// 000000DED414: C9083D0A 0A0A390B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DED41C: BF870112
	v_dual_add_f32 v16, v16, v29 :: v_dual_add_f32 v17, v17, v31// 000000DED420: C9083B10 10103F11
	v_dual_add_f32 v10, v10, v35 :: v_dual_add_f32 v11, v11, v32// 000000DED428: C908470A 0A0A410B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DED430: BF870112
	v_dual_add_f32 v16, v16, v33 :: v_dual_add_f32 v17, v17, v34// 000000DED434: C9084310 10104511
	v_dual_add_f32 v10, v10, v38 :: v_dual_add_f32 v11, v11, v36// 000000DED43C: C9084D0A 0A0A490B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DED444: BF870112
	v_dual_add_f32 v16, v16, v37 :: v_dual_add_f32 v17, v17, v39// 000000DED448: C9084B10 10104F11
	v_dual_add_f32 v10, v10, v43 :: v_dual_add_f32 v11, v11, v40// 000000DED450: C908570A 0A0A510B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DED458: BF870112
	v_dual_add_f32 v17, v17, v42 :: v_dual_add_f32 v16, v16, v41// 000000DED45C: C9085511 11105310
	v_dual_add_f32 v10, v10, v12 :: v_dual_add_f32 v11, v11, v13// 000000DED464: C908190A 0A0A1B0B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DED46C: BF870112
	v_dual_add_f32 v13, v17, v14 :: v_dual_add_f32 v12, v16, v15// 000000DED470: C9081D11 0D0C1F10
	v_dual_add_f32 v10, v10, v44 :: v_dual_add_f32 v11, v11, v45// 000000DED478: C908590A 0A0A5B0B
	v_and_b32_e32 v15, 2, v0                                   // 000000DED480: 361E0082
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000DED484: BF870223
	v_dual_add_f32 v13, v13, v47 :: v_dual_add_f32 v12, v12, v46// 000000DED488: C9085F0D 0D0C5D0C
	v_and_b32_e32 v14, 1, v0                                   // 000000DED490: 361C0081
	v_dual_add_f32 v10, v10, v50 :: v_dual_add_f32 v11, v11, v51// 000000DED494: C908650A 0A0A670B
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000DED49C: BF870223
	v_dual_add_f32 v13, v13, v49 :: v_dual_add_f32 v12, v12, v48// 000000DED4A0: C908630D 0D0C610C
	v_and_b32_e32 v16, 4, v0                                   // 000000DED4A8: 36200084
	v_cmp_eq_u32_e32 vcc_lo, 0, v14                            // 000000DED4AC: 7C941C80
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DED4B0: BF870214
	v_add_f32_e32 v17, v10, v11                                // 000000DED4B4: 0622170A
	v_dual_sub_f32 v10, v10, v11 :: v_dual_add_f32 v11, v12, v13// 000000DED4B8: C948170A 0A0A1B0C
	v_dual_sub_f32 v12, v12, v13 :: v_dual_and_b32 v13, 8, v0  // 000000DED4C0: C9641B0C 0C0C0088
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000DED4C8: BF8701A2
	v_add_f32_e32 v18, v17, v11                                // 000000DED4CC: 06241711
	v_sub_f32_e32 v11, v17, v11                                // 000000DED4D0: 08161711
	v_add_f32_e32 v19, v10, v12                                // 000000DED4D4: 0626190A
	v_sub_f32_e32 v10, v10, v12                                // 000000DED4D8: 0814190A
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000DED4DC: BF870224
	v_mov_b32_dpp v12, v18 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DED4E0: 7E1802FA FF016112
	v_cndmask_b32_e64 v14, -v18, v18, vcc_lo                   // 000000DED4E8: D501000E 21AA2512
	v_mov_b32_dpp v17, v19 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DED4F0: 7E2202FA FF016113
	v_cndmask_b32_e64 v18, -v19, v19, vcc_lo                   // 000000DED4F8: D5010012 21AA2713
	v_mov_b32_dpp v19, v11 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DED500: 7E2602FA FF01610B
	v_cndmask_b32_e64 v11, -v11, v11, vcc_lo                   // 000000DED508: D501000B 21AA170B
	v_and_b32_e32 v0, 16, v0                                   // 000000DED510: 36000090
	v_mov_b32_dpp v20, v10 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DED514: 7E2802FA FF01610A
	v_cndmask_b32_e64 v10, -v10, v10, vcc_lo                   // 000000DED51C: D501000A 21AA150A
	v_add_f32_e32 v12, v14, v12                                // 000000DED524: 0618190E
	v_cmp_eq_u32_e32 vcc_lo, 0, v15                            // 000000DED528: 7C941E80
	v_dual_add_f32 v14, v18, v17 :: v_dual_add_f32 v11, v11, v19// 000000DED52C: C9082312 0E0A270B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DED534: BF870214
	v_add_f32_e32 v10, v10, v20                                // 000000DED538: 0614290A
	v_mov_b32_dpp v15, v12 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DED53C: 7E1E02FA FF01620C
	v_cndmask_b32_e64 v12, -v12, v12, vcc_lo                   // 000000DED544: D501000C 21AA190C
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DED54C: BF870004
	v_mov_b32_dpp v17, v14 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DED550: 7E2202FA FF01620E
	v_cndmask_b32_e64 v14, -v14, v14, vcc_lo                   // 000000DED558: D501000E 21AA1D0E
	v_mov_b32_dpp v18, v11 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DED560: 7E2402FA FF01620B
	v_cndmask_b32_e64 v11, -v11, v11, vcc_lo                   // 000000DED568: D501000B 21AA170B
	v_mov_b32_dpp v19, v10 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DED570: 7E2602FA FF01620A
	v_cndmask_b32_e64 v10, -v10, v10, vcc_lo                   // 000000DED578: D501000A 21AA150A
	v_cmp_eq_u32_e32 vcc_lo, 0, v16                            // 000000DED580: 7C942080
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DED584: BF870194
	v_dual_add_f32 v14, v14, v17 :: v_dual_add_f32 v11, v11, v18// 000000DED588: C908230E 0E0A250B
	v_add_f32_e32 v10, v10, v19                                // 000000DED590: 0614270A
	s_delay_alu instid0(VALU_DEP_2)                            // 000000DED594: BF870002
	v_mov_b32_dpp v16, v14 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DED598: 7E2002FA FF01640E
	v_cndmask_b32_e64 v14, -v14, v14, vcc_lo                   // 000000DED5A0: D501000E 21AA1D0E
	v_add_f32_e32 v12, v12, v15                                // 000000DED5A8: 06181F0C
	v_mov_b32_dpp v17, v11 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DED5AC: 7E2202FA FF01640B
	v_cndmask_b32_e64 v11, -v11, v11, vcc_lo                   // 000000DED5B4: D501000B 21AA170B
	v_mov_b32_dpp v18, v10 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DED5BC: 7E2402FA FF01640A
	v_cndmask_b32_e64 v10, -v10, v10, vcc_lo                   // 000000DED5C4: D501000A 21AA150A
	v_mov_b32_dpp v15, v12 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DED5CC: 7E1E02FA FF01640C
	v_cndmask_b32_e64 v12, -v12, v12, vcc_lo                   // 000000DED5D4: D501000C 21AA190C
	v_cmp_eq_u32_e32 vcc_lo, 0, v13                            // 000000DED5DC: 7C941A80
	v_add_f32_e32 v13, v14, v16                                // 000000DED5E0: 061A210E
	v_dual_add_f32 v11, v11, v17 :: v_dual_add_f32 v10, v10, v18// 000000DED5E4: C908230B 0B0A250A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DED5EC: BF870194
	v_add_f32_e32 v12, v12, v15                                // 000000DED5F0: 06181F0C
	v_mov_b32_dpp v15, v13 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DED5F4: 7E1E02FA FF01680D
	v_cndmask_b32_e64 v13, -v13, v13, vcc_lo                   // 000000DED5FC: D501000D 21AA1B0D
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DED604: BF870004
	v_mov_b32_dpp v16, v11 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DED608: 7E2002FA FF01680B
	v_cndmask_b32_e64 v11, -v11, v11, vcc_lo                   // 000000DED610: D501000B 21AA170B
	v_mov_b32_dpp v14, v12 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DED618: 7E1C02FA FF01680C
	v_cndmask_b32_e64 v12, -v12, v12, vcc_lo                   // 000000DED620: D501000C 21AA190C
	v_mov_b32_dpp v17, v10 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DED628: 7E2202FA FF01680A
	v_cndmask_b32_e64 v10, -v10, v10, vcc_lo                   // 000000DED630: D501000A 21AA150A
	v_cmp_eq_u32_e32 vcc_lo, 0, v0                             // 000000DED638: 7C940080
	v_dual_add_f32 v0, v11, v16 :: v_dual_add_f32 v11, v13, v15// 000000DED63C: C908210B 000A1F0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000DED644: BF870121
	v_dual_add_f32 v10, v10, v17 :: v_dual_mov_b32 v15, v11    // 000000DED648: C910230A 0A0E010B
	v_cndmask_b32_e64 v11, -v11, v11, vcc_lo                   // 000000DED650: D501000B 21AA170B
	v_mov_b32_e32 v16, v10                                     // 000000DED658: 7E20030A
	v_cndmask_b32_e64 v10, -v10, v10, vcc_lo                   // 000000DED65C: D501000A 21AA150A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DED664: BF870194
	v_permlanex16_b32 v15, v15, s0, 0xfedcba98                 // 000000DED668: D65C000F 03FC010F FEDCBA98
	v_permlanex16_b32 v16, v16, s0, 0xfedcba98                 // 000000DED674: D65C0010 03FC0110 FEDCBA98
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000DED680: BF8701B2
	v_dual_add_f32 v11, v11, v15 :: v_dual_add_f32 v12, v12, v14// 000000DED684: C9081F0B 0B0C1D0C
	v_mov_b32_e32 v14, v0                                      // 000000DED68C: 7E1C0300
	v_cndmask_b32_e64 v0, -v0, v0, vcc_lo                      // 000000DED690: D5010000 21AA0100
	v_dual_add_f32 v10, v10, v16 :: v_dual_mul_f32 v11, 0x3db504f3, v11// 000000DED698: C906210A 0A0A16FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000DED6A4: BF870234
	v_mov_b32_e32 v13, v12                                     // 000000DED6A8: 7E1A030C
	v_cndmask_b32_e64 v12, -v12, v12, vcc_lo                   // 000000DED6AC: D501000C 21AA190C
	v_permlanex16_b32 v14, v14, s0, 0xfedcba98                 // 000000DED6B4: D65C000E 03FC010E FEDCBA98
	v_mul_f32_e32 v10, 0x3db504f3, v10                         // 000000DED6C0: 101414FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DED6C8: BF870194
	v_permlanex16_b32 v13, v13, s0, 0xfedcba98                 // 000000DED6CC: D65C000D 03FC010D FEDCBA98
	v_add_f32_e32 v0, v0, v14                                  // 000000DED6D8: 06001D00
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DED6DC: BF870112
	v_add_f32_e32 v12, v12, v13                                // 000000DED6E0: 06181B0C
	v_mul_f32_e32 v0, 0x3db504f3, v0                           // 000000DED6E4: 100000FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000DED6EC: BF870122
	v_mul_f32_e32 v12, 0x3db504f3, v12                         // 000000DED6F0: 101818FF 3DB504F3
	s_waitcnt vmcnt(2)                                         // 000000DED6F8: BF890BF7
	v_fma_mix_f32 v0, v9, v0, neg(0) op_sel_hi:[1,0,0]         // 000000DED6FC: CC200000 8A020109
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000DED704: BF870232
	v_fma_mix_f32 v12, v8, v12, neg(0) op_sel_hi:[1,0,0]       // 000000DED708: CC20000C 8A021908
	v_fma_mix_f32 v8, v8, v11, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000DED710: CC200808 8A021708
	v_fma_mix_f32 v9, v9, v10, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000DED718: CC200809 8A021509
	v_bfe_u32 v10, v0, 16, 1                                   // 000000DED720: D610000A 02052100
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DED728: BF870214
	v_bfe_u32 v11, v12, 16, 1                                  // 000000DED72C: D610000B 0205210C
	v_bfe_u32 v14, v8, 16, 1                                   // 000000DED734: D610000E 02052108
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DED73C: BF870004
	v_bfe_u32 v15, v9, 16, 1                                   // 000000DED740: D610000F 02052109
	s_waitcnt vmcnt(1)                                         // 000000DED748: BF8907F7
	v_lshlrev_b32_e32 v13, 16, v6                              // 000000DED74C: 301A0C90
	v_add3_u32 v0, v0, v10, 0x7fff                             // 000000DED750: D6550000 03FE1500 00007FFF
	v_add3_u32 v10, v12, v11, 0x7fff                           // 000000DED75C: D655000A 03FE170C 00007FFF
	v_add3_u32 v8, v8, v14, 0x7fff                             // 000000DED768: D6550008 03FE1D08 00007FFF
	v_add3_u32 v9, v9, v15, 0x7fff                             // 000000DED774: D6550009 03FE1F09 00007FFF
	v_lshlrev_b32_e32 v11, 16, v7                              // 000000DED780: 30160E90
	v_and_b32_e32 v0, 0xffff0000, v0                           // 000000DED784: 360000FF FFFF0000
	v_and_b32_e32 v10, 0xffff0000, v10                         // 000000DED78C: 361414FF FFFF0000
	v_and_b32_e32 v6, 0xffff0000, v6                           // 000000DED794: 360C0CFF FFFF0000
	v_and_b32_e32 v7, 0xffff0000, v7                           // 000000DED79C: 360E0EFF FFFF0000
	v_and_b32_e32 v8, 0xffff0000, v8                           // 000000DED7A4: 361010FF FFFF0000
	s_waitcnt vmcnt(0)                                         // 000000DED7AC: BF8903F7
	v_dual_fmac_f32 v0, v2, v11 :: v_dual_and_b32 v9, 0xffff0000, v9// 000000DED7B0: C8241702 000812FF FFFF0000
	v_fmac_f32_e32 v10, v2, v13                                // 000000DED7BC: 56141B02
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DED7C0: BF870193
	v_fmac_f32_e32 v8, v2, v6                                  // 000000DED7C4: 56100D02
	v_fmac_f32_e32 v9, v2, v7                                  // 000000DED7C8: 56120F02
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DED7CC: BF870214
	v_bfe_u32 v2, v0, 16, 1                                    // 000000DED7D0: D6100002 02052100
	v_bfe_u32 v11, v10, 16, 1                                  // 000000DED7D8: D610000B 0205210A
	v_mad_i64_i32 v[6:7], null, 0x1400, v1, s[6:7]             // 000000DED7E0: D6FF7C06 001A02FF 00001400
	v_bfe_u32 v12, v8, 16, 1                                   // 000000DED7EC: D610000C 02052108
	v_bfe_u32 v13, v9, 16, 1                                   // 000000DED7F4: D610000D 02052109
	v_add3_u32 v0, v0, v2, 0x7fff                              // 000000DED7FC: D6550000 03FE0500 00007FFF
	v_add3_u32 v2, v10, v11, 0x7fff                            // 000000DED808: D6550002 03FE170A 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DED814: BF870214
	v_add3_u32 v8, v8, v12, 0x7fff                             // 000000DED818: D6550008 03FE1908 00007FFF
	v_add3_u32 v9, v9, v13, 0x7fff                             // 000000DED824: D6550009 03FE1B09 00007FFF
	.long 0xd7006a04                                           // 000000DED830: D7006A04
	v_cndmask_b32_e32 v1, v6, v4, vcc_lo                       // 000000DED834: 02020906
	.long 0x7e123980                                           // 000000DED838: 7E123980
	.long 0x7e103982                                           // 000000DED83C: 7E103982
	v_add_co_ci_u32_e64 v5, null, v7, v5, vcc_lo               // 000000DED840: D5207C05 01AA0B07
	v_cmp_eq_u32_e32 vcc_lo, 0, v3                             // 000000DED848: 7C940680
	global_store_b64 v[4:5], v[8:9], off                       // 000000DED84C: DC6E0000 007C0804
	s_and_b32 exec_lo, exec_lo, vcc_lo                         // 000000DED854: 8B7E6A7E
	s_cbranch_execz 14                                         // 000000DED858: BFA5000E <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_fl_gILi2EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfPKfS5_PKtSD_PtPj+0x1c94>
	v_mad_u64_u32 v[0:1], null, v1, 20, s[10:11]               // 000000DED85C: D6FE7C00 00292901
	v_mov_b32_e32 v2, 0                                        // 000000DED864: 7E040280
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DED868: BF870092
	v_ashrrev_i32_e32 v1, 31, v0                               // 000000DED86C: 3402009F
	.long 0xd73c0000                                           // 000000DED870: D73C0000
	v_cndmask_b32_e32 v1, 2, v0, vcc_lo                        // 000000DED874: 02020082
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DED878: BF870091
	.long 0xd7006a00                                           // 000000DED87C: D7006A00
	v_cndmask_b32_e32 v1, s8, v0, vcc_lo                       // 000000DED880: 02020008
	v_add_co_ci_u32_e64 v1, null, s9, v1, vcc_lo               // 000000DED884: D5207C01 01AA0209
	global_store_b32 v[0:1], v2, off                           // 000000DED88C: DC6A0000 007C0200
	s_nop 0                                                    // 000000DED894: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 000000DED898: BFB60003
	s_endpgm                                                   // 000000DED89C: BFB00000
		...

