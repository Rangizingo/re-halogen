0000000000d8c300 <_ZN7halogen12_GLOBAL__N_111k_ht_moe_guILi3ELi8ELi1EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_S5_PDF16_>:
; _ZN7halogen12_GLOBAL__N_111k_ht_moe_guILi3ELi8ELi1EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_S5_PDF16_():
	s_load_b256 s[12:19], s[0:1], null                         // 000000D8C300: F40C0300 F8000000
	s_mov_b32 s3, 0                                            // 000000D8C308: BE830080
	v_lshrrev_b32_e32 v159, 5, v0                              // 000000D8C30C: 333E0085
	s_lshl_b64 s[2:3], s[2:3], 4                               // 000000D8C310: 84828402
	v_and_b32_e32 v158, 15, v0                                 // 000000D8C314: 373C008F
	v_and_b32_e32 v157, 31, v0                                 // 000000D8C318: 373A009F
	s_load_b256 s[4:11], s[0:1], 0x20                          // 000000D8C31C: F40C0100 F8000020
	v_lshlrev_b32_e32 v4, 4, v0                                // 000000D8C324: 30080084
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D8C328: BF870092
	v_mad_u32_u24 v3, v157, 24, 0x2f0                          // 000000D8C32C: D60B0003 03FD319D 000002F0
	v_and_b32_e32 v5, 0x7e0, v3                                // 000000D8C338: 360A06FF 000007E0
	s_waitcnt lgkmcnt(0)                                       // 000000D8C340: BF89FC07
	s_add_u32 s2, s16, s2                                      // 000000D8C344: 80020210
	s_addc_u32 s3, s17, s3                                     // 000000D8C348: 82030311
	s_load_b128 s[20:23], s[2:3], null                         // 000000D8C34C: F4080501 F8000000
	s_waitcnt lgkmcnt(0)                                       // 000000D8C354: BF89FC07
	v_lshl_add_u32 v156, v159, 4, s22                          // 000000D8C358: D646009C 0059099F
	s_add_i32 s2, s23, -1                                      // 000000D8C360: 8102C117
	s_mul_i32 s0, s20, 0x12c000                                // 000000D8C364: 9600FF14 0012C000
	s_mul_hi_i32 s1, s20, 0x12c000                             // 000000D8C36C: 9701FF14 0012C000
	s_add_u32 s0, s12, s0                                      // 000000D8C374: 8000000C
	v_add_nc_u32_e32 v1, v156, v158                            // 000000D8C378: 4A033D9C
	s_addc_u32 s1, s13, s1                                     // 000000D8C37C: 8201010D
	s_mul_hi_i32 s3, s21, 0x3c000                              // 000000D8C380: 9703FF15 0003C000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000D8C388: BF8704A1
	v_min_i32_e32 v1, s2, v1                                   // 000000D8C38C: 22020202
	s_mul_i32 s2, s21, 0x3c000                                 // 000000D8C390: 9602FF15 0003C000
	s_add_u32 s2, s0, s2                                       // 000000D8C398: 80020200
	s_addc_u32 s3, s1, s3                                      // 000000D8C39C: 82030301
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D8C3A0: BF870091
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000D8C3A4: 3404029F
	.long 0xd73c0001                                           // 000000D8C3A8: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 000000D8C3AC: 02020282
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D8C3B0: BF870091
	.long 0xd7006a01                                           // 000000D8C3B4: D7006A01
	v_cndmask_b32_e32 v1, s18, v1, vcc_lo                      // 000000D8C3B8: 02020212
	v_add_co_ci_u32_e64 v2, null, s19, v2, vcc_lo              // 000000D8C3BC: D5207C02 01AA0413
	v_cmp_lt_u32_e32 vcc_lo, 0x1ff, v0                         // 000000D8C3C4: 7C9200FF 000001FF
	global_load_b32 v7, v[1:2], off                            // 000000D8C3CC: DC520000 077C0001
	v_lshrrev_b32_e32 v1, 5, v3                                // 000000D8C3D4: 32020685
	v_lshlrev_b32_e32 v2, 3, v157                              // 000000D8C3D8: 30053A83
	v_lshrrev_b32_e32 v3, 1, v0                                // 000000D8C3DC: 32060081
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D8C3E0: BF870193
	v_add_nc_u32_e32 v6, 0xe9, v1                              // 000000D8C3E4: 4A0C02FF 000000E9
	v_or_b32_e32 v8, 4, v2                                     // 000000D8C3EC: 38100484
	s_and_saveexec_b32 s0, vcc_lo                              // 000000D8C3F0: BE80206A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000D8C3F4: BF870009
	s_xor_b32 s0, exec_lo, s0                                  // 000000D8C3F8: 8D00007E
	s_cbranch_execz 57                                         // 000000D8C3FC: BFA50039 <_ZN7halogen12_GLOBAL__N_111k_ht_moe_guILi3ELi8ELi1EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_S5_PDF16_+0x1e4>
	v_or_b32_e32 v8, 4, v2                                     // 000000D8C400: 38100484
	v_dual_mov_b32 v11, 0 :: v_dual_and_b32 v10, 0xff, v6      // 000000D8C404: CA240080 0B0A0CFF 000000FF
	v_and_b32_e32 v9, 0xf0, v4                                 // 000000D8C410: 361208FF 000000F0
	v_mad_i32_i24 v5, 0xffffffe8, v157, v5                     // 000000D8C418: D60A0005 04173AFF FFFFFFE8
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000D8C424: BF8701A4
	v_mad_u32_u24 v12, v8, 3, 0x2f0                            // 000000D8C428: D60B000C 03FD0708 000002F0
	v_and_b32_e32 v16, 8, v3                                   // 000000D8C434: 36200688
	v_dual_mov_b32 v13, v11 :: v_dual_add_nc_u32 v138, 0xfffffd3d, v5// 000000D8C438: CA20010B 0D8A0AFF FFFFFD3D
	s_delay_alu instid0(VALU_DEP_3)                            // 000000D8C444: BF870003
	v_lshrrev_b32_e32 v14, 5, v12                              // 000000D8C448: 321C1885
	v_and_b32_e32 v4, 0x7e0, v12                               // 000000D8C44C: 360818FF 000007E0
	v_add_nc_u32_e32 v139, 0xfffffd3a, v5                      // 000000D8C454: 4B160AFF FFFFFD3A
	v_add_nc_u32_e32 v140, 0xfffffd37, v5                      // 000000D8C45C: 4B180AFF FFFFFD37
	v_add_nc_u32_e32 v141, 0xfffffd34, v5                      // 000000D8C464: 4B1A0AFF FFFFFD34
	.long 0xd7030002                                           // 000000D8C46C: D7030002
	v_cndmask_b32_e32 v0, v14, v129, vcc_lo                    // 000000D8C470: 0201030E
	v_mad_i32_i24 v4, v8, -3, v4                               // 000000D8C474: D60A0004 04118708
	v_subrev_nc_u32_e32 v15, 24, v14                           // 000000D8C47C: 4E1E1C98
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D8C480: BF870193
	.long 0xd7624002                                           // 000000D8C484: D7624002
	v_cndmask_b32_e32 v1, 0xff, v2, vcc_lo                     // 000000D8C488: 020204FF 000000FF
	v_add_nc_u32_e32 v142, 0xfffffd3d, v4                      // 000000D8C490: 4B1C08FF FFFFFD3D
	v_add_nc_u32_e32 v143, 0xfffffd3a, v4                      // 000000D8C498: 4B1E08FF FFFFFD3A
	v_add_nc_u32_e32 v144, 0xfffffd37, v4                      // 000000D8C4A0: 4B2008FF FFFFFD37
	v_add_nc_u32_e32 v145, 0xfffffd34, v4                      // 000000D8C4A8: 4B2208FF FFFFFD34
	.long 0xd7055002                                           // 000000D8C4B0: D7055002
	v_cndmask_b32_e32 v1, 0xab, v2, vcc_lo                     // 000000D8C4B4: 020204FF 000000AB
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D8C4BC: BF870091
	.long 0xd7395002                                           // 000000D8C4C0: D7395002
	v_cndmask_b32_e32 v1, 12, v2, vcc_lo                       // 000000D8C4C4: 0202048C
	.long 0xd7054802                                           // 000000D8C4C8: D7054802
	v_cndmask_b32_e32 v0, v2, v152, vcc_lo                     // 000000D8C4CC: 02013102
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D8C4D0: BF870091
	.long 0xd7041002                                           // 000000D8C4D4: D7041002
	v_cndmask_b32_e32 v1, v2, v2, vcc_lo                       // 000000D8C4D8: 02020502
	v_and_b32_e32 v12, 0xff, v2                                // 000000D8C4DC: 361804FF 000000FF
	s_or_saveexec_b32 s0, s0                                   // 000000D8C4E4: BE802200
	v_subrev_nc_u32_e32 v14, 24, v1                            // 000000D8C4E8: 4E1C0298
	s_xor_b32 exec_lo, exec_lo, s0                             // 000000D8C4EC: 8D7E007E
	s_cbranch_execz 236                                        // 000000D8C4F0: BFA500EC <_ZN7halogen12_GLOBAL__N_111k_ht_moe_guILi3ELi8ELi1EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_S5_PDF16_+0x5a4>
	v_mad_u32_u24 v15, v8, 3, 0x2f0                            // 000000D8C4F4: D60B000F 03FD0708 000002F0
	v_cmp_ne_u32_e32 vcc_lo, 0, v157                           // 000000D8C500: 7C9B3A80
	v_mov_b32_e32 v2, 0                                        // 000000D8C504: 7E040280
	v_mad_i32_i24 v5, 0xffffffe8, v157, v5                     // 000000D8C508: D60A0005 04173AFF FFFFFFE8
	s_mov_b32 s1, 0                                            // 000000D8C514: BE810080
	v_lshrrev_b32_e32 v18, 5, v15                              // 000000D8C518: 32241E85
	v_cndmask_b32_e32 v1, 23, v14, vcc_lo                      // 000000D8C51C: 02021C97
	v_dual_mov_b32 v11, v2 :: v_dual_and_b32 v10, 0xff, v6     // 000000D8C520: CA240102 0B0A0CFF 000000FF
	v_dual_mov_b32 v13, v2 :: v_dual_and_b32 v16, 8, v3        // 000000D8C52C: CA240102 0D100688
	s_delay_alu instid0(VALU_DEP_4)                            // 000000D8C534: BF870004
	.long 0xd703000c                                           // 000000D8C538: D703000C
	v_cndmask_b32_e32 v0, v18, v129, vcc_lo                    // 000000D8C53C: 02010312
	v_add_nc_u32_e32 v139, 0xfffffd3a, v5                      // 000000D8C540: 4B160AFF FFFFFD3A
	v_add_nc_u32_e32 v140, 0xfffffd37, v5                      // 000000D8C548: 4B180AFF FFFFFD37
	v_add_nc_u32_e32 v141, 0xfffffd34, v5                      // 000000D8C550: 4B1A0AFF FFFFFD34
	v_and_b32_e32 v19, 0x7e0, v15                              // 000000D8C558: 36261EFF 000007E0
	.long 0xd7620006                                           // 000000D8C560: D7620006
	v_cndmask_b32_e32 v1, 0xff, v12, vcc_lo                    // 000000D8C564: 020218FF 000000FF
	v_subrev_nc_u32_e32 v15, 24, v18                           // 000000D8C56C: 4E1E2498
	v_cmp_lt_u32_e32 vcc_lo, 5, v8                             // 000000D8C570: 7C921085
	v_add_nc_u32_e32 v138, 0xfffffd3d, v5                      // 000000D8C574: 4B140AFF FFFFFD3D
	v_and_b32_e32 v9, 0xf0, v4                                 // 000000D8C57C: 361208FF 000000F0
	.long 0xd7050003                                           // 000000D8C584: D7050003
	v_cndmask_b32_e32 v1, 0xab, v6, vcc_lo                     // 000000D8C588: 02020CFF 000000AB
	v_dual_mov_b32 v6, v2 :: v_dual_lshlrev_b32 v17, 2, v10    // 000000D8C590: CA220102 06101482
	s_movk_i32 s10, 0x1eee                                     // 000000D8C598: B00A1EEE
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D8C59C: BF870193
	v_or_b32_e32 v20, v9, v16                                  // 000000D8C5A0: 38282109
	.long 0xd7390003                                           // 000000D8C5A4: D7390003
	v_cndmask_b32_e32 v1, 12, v3, vcc_lo                       // 000000D8C5A8: 0202068C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D8C5AC: BF870112
	v_lshlrev_b32_e32 v18, 1, v20                              // 000000D8C5B0: 30242881
	.long 0xd7050005                                           // 000000D8C5B4: D7050005
	v_cndmask_b32_e32 v0, v3, v152, vcc_lo                     // 000000D8C5B8: 02013103
	.long 0xd73c0003                                           // 000000D8C5BC: D73C0003
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 000000D8C5C0: 02020282
	v_mad_i32_i24 v1, v8, -3, v19                              // 000000D8C5C4: D60A0001 044D8708
	v_mov_b32_e32 v20, v159                                    // 000000D8C5CC: 7E28039F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D8C5D0: BF870194
	.long 0xd704000c                                           // 000000D8C5D4: D704000C
	v_cndmask_b32_e32 v1, v12, v5, vcc_lo                      // 000000D8C5D8: 02020B0C
	v_dual_cndmask_b32 v5, 23, v15 :: v_dual_add_nc_u32 v142, 0xfffffd3d, v1// 000000D8C5DC: CA601E97 058E02FF FFFFFD3D
	v_add_nc_u32_e32 v143, 0xfffffd3a, v1                      // 000000D8C5E8: 4B1E02FF FFFFFD3A
	v_add_nc_u32_e32 v144, 0xfffffd37, v1                      // 000000D8C5F0: 4B2002FF FFFFFD37
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D8C5F8: BF870214
	v_and_b32_e32 v12, 0xff, v12                               // 000000D8C5FC: 361818FF 000000FF
	.long 0xd73c0005                                           // 000000D8C604: D73C0005
	v_cndmask_b32_e32 v1, 2, v5, vcc_lo                        // 000000D8C608: 02020A82
	v_add_nc_u32_e32 v145, 0xfffffd34, v1                      // 000000D8C60C: 4B2202FF FFFFFD34
	s_delay_alu instid0(VALU_DEP_3)                            // 000000D8C614: BF870003
	v_lshlrev_b32_e32 v19, 2, v12                              // 000000D8C618: 30261882
	.long 0xd72c0001                                           // 000000D8C61C: D72C0001
	v_cndmask_b32_e32 v0, v20, v152, vcc_lo                    // 000000D8C620: 02013114
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D8C624: BF870091
	.long 0xd73c0015                                           // 000000D8C628: D73C0015
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 000000D8C62C: 02020282
	.long 0xd7006a01                                           // 000000D8C630: D7006A01
	v_cndmask_b32_e32 v1, s2, v21, vcc_lo                      // 000000D8C634: 02022A02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D8C638: BF870111
	v_add_co_ci_u32_e64 v28, null, s3, v22, vcc_lo             // 000000D8C63C: D5207C1C 01AA2C03
	.long 0xd7006a15                                           // 000000D8C644: D7006A15
	v_cndmask_b32_e32 v1, v1, v3, vcc_lo                       // 000000D8C648: 02020701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000D8C64C: BF8700A1
	v_add_co_ci_u32_e64 v22, null, v28, v4, vcc_lo             // 000000D8C650: D5207C16 01AA091C
	.long 0xd7006a17                                           // 000000D8C658: D7006A17
	v_cndmask_b32_e32 v1, v1, v17, vcc_lo                      // 000000D8C65C: 02022301
	v_add_co_ci_u32_e64 v24, null, 0, v28, vcc_lo              // 000000D8C660: D5207C18 01AA3880
	.long 0xd7006a19                                           // 000000D8C668: D7006A19
	v_cndmask_b32_e32 v1, v1, v5, vcc_lo                       // 000000D8C66C: 02020B01
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000D8C670: BF8700A1
	v_add_co_ci_u32_e64 v26, null, v28, v6, vcc_lo             // 000000D8C674: D5207C1A 01AA0D1C
	.long 0xd7006a1b                                           // 000000D8C67C: D7006A1B
	v_cndmask_b32_e32 v1, v1, v19, vcc_lo                      // 000000D8C680: 02022701
	v_add_co_ci_u32_e64 v28, null, 0, v28, vcc_lo              // 000000D8C684: D5207C1C 01AA3880
	s_clause 0x3                                               // 000000D8C68C: BF850003
	global_load_b32 v22, v[21:22], off                         // 000000D8C690: DC520000 167C0015
	global_load_b32 v21, v[23:24], off                         // 000000D8C698: DC520000 157C0017
	global_load_b32 v24, v[25:26], off                         // 000000D8C6A0: DC520000 187C0019
	global_load_b32 v23, v[27:28], off                         // 000000D8C6A8: DC520000 177C001B
	v_lshl_or_b32 v1, v20, 9, v18                              // 000000D8C6B0: D6560001 04491314
	v_cmp_lt_u32_e32 vcc_lo, 7, v20                            // 000000D8C6B8: 7C922887
	s_or_b32 s1, vcc_lo, s1                                    // 000000D8C6BC: 8C01016A
	s_waitcnt vmcnt(2)                                         // 000000D8C6C0: BF890BF7
	.long 0xd73d0019                                           // 000000D8C6C4: D73D0019
	v_cndmask_b32_e32 v1, v138, v21, vcc_lo                    // 000000D8C6C8: 02022B8A
	.long 0xd73d001a                                           // 000000D8C6CC: D73D001A
	v_cndmask_b32_e32 v1, v139, v21, vcc_lo                    // 000000D8C6D0: 02022B8B
	.long 0xd73d001b                                           // 000000D8C6D4: D73D001B
	v_cndmask_b32_e32 v1, v140, v21, vcc_lo                    // 000000D8C6D8: 02022B8C
	s_waitcnt vmcnt(0)                                         // 000000D8C6DC: BF8903F7
	.long 0xd73d001c                                           // 000000D8C6E0: D73D001C
	v_cndmask_b32_e32 v1, v142, v23, vcc_lo                    // 000000D8C6E4: 02022F8E
	.long 0xd73d001d                                           // 000000D8C6E8: D73D001D
	v_cndmask_b32_e32 v1, v143, v23, vcc_lo                    // 000000D8C6EC: 02022F8F
	.long 0xd73d001e                                           // 000000D8C6F0: D73D001E
	v_cndmask_b32_e32 v1, v144, v23, vcc_lo                    // 000000D8C6F4: 02022F90
	.long 0xd73d0015                                           // 000000D8C6F8: D73D0015
	v_cndmask_b32_e32 v1, v141, v21, vcc_lo                    // 000000D8C6FC: 02022B8D
	.long 0xd73d0016                                           // 000000D8C700: D73D0016
	v_cndmask_b32_e32 v1, v145, v23, vcc_lo                    // 000000D8C704: 02022F91
	v_and_b32_e32 v23, 0xffff, v25                             // 000000D8C708: 362E32FF 0000FFFF
	v_and_b32_e32 v24, 0xffff, v26                             // 000000D8C710: 363034FF 0000FFFF
	v_and_b32_e32 v25, 0xffff, v27                             // 000000D8C718: 363236FF 0000FFFF
	v_and_b32_e32 v26, 0xffff, v28                             // 000000D8C720: 363438FF 0000FFFF
	v_and_b32_e32 v27, 0xffff, v29                             // 000000D8C728: 36363AFF 0000FFFF
	v_and_b32_e32 v28, 0xffff, v30                             // 000000D8C730: 36383CFF 0000FFFF
	v_add_nc_u32_e32 v29, 8, v20                               // 000000D8C738: 4A3A2888
	v_and_b32_e32 v21, 0xffff, v21                             // 000000D8C73C: 362A2AFF 0000FFFF
	v_and_b32_e32 v22, 0xffff, v22                             // 000000D8C744: 362C2CFF 0000FFFF
	.long 0xd72c0019                                           // 000000D8C74C: D72C0019
	v_cndmask_b32_e32 v1, 0x83dcd12d, v25, vcc_lo              // 000000D8C750: 020232FF 83DCD12D
	.long 0xd72c001a                                           // 000000D8C758: D72C001A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v26, vcc_lo              // 000000D8C75C: 020234FF 83DCD12D
	.long 0xd72c001c                                           // 000000D8C764: D72C001C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v28, vcc_lo              // 000000D8C768: 020238FF 83DCD12D
	v_mov_b32_e32 v20, v29                                     // 000000D8C770: 7E28031D
	.long 0xd72c0017                                           // 000000D8C774: D72C0017
	v_cndmask_b32_e32 v1, 0x83dcd12d, v23, vcc_lo              // 000000D8C778: 02022EFF 83DCD12D
	.long 0xd72c0018                                           // 000000D8C780: D72C0018
	v_cndmask_b32_e32 v1, 0x83dcd12d, v24, vcc_lo              // 000000D8C784: 020230FF 83DCD12D
	.long 0xd72c0015                                           // 000000D8C78C: D72C0015
	v_cndmask_b32_e32 v1, 0x83dcd12d, v21, vcc_lo              // 000000D8C790: 02022AFF 83DCD12D
	.long 0xd72c001b                                           // 000000D8C798: D72C001B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v27, vcc_lo              // 000000D8C79C: 020236FF 83DCD12D
	.long 0xd72c0016                                           // 000000D8C7A4: D72C0016
	v_cndmask_b32_e32 v1, 0x83dcd12d, v22, vcc_lo              // 000000D8C7A8: 02022CFF 83DCD12D
	v_sad_u8 v25, v25, 0, 0x6400                               // 000000D8C7B0: D6220019 03FD0119 00006400
	v_sad_u8 v26, v26, 0, 0x6400                               // 000000D8C7BC: D622001A 03FD011A 00006400
	v_sad_u8 v28, v28, 0, 0x6400                               // 000000D8C7C8: D622001C 03FD011C 00006400
	v_sad_u8 v23, v23, 0, 0x6400                               // 000000D8C7D4: D6220017 03FD0117 00006400
	v_sad_u8 v24, v24, 0, 0x6400                               // 000000D8C7E0: D6220018 03FD0118 00006400
	v_sad_u8 v21, v21, 0, 0x6400                               // 000000D8C7EC: D6220015 03FD0115 00006400
	v_sad_u8 v27, v27, 0, 0x6400                               // 000000D8C7F8: D622001B 03FD011B 00006400
	v_sad_u8 v22, v22, 0, 0x6400                               // 000000D8C804: D6220016 03FD0116 00006400
	v_and_b32_e32 v23, 0xffff, v23                             // 000000D8C810: 362E2EFF 0000FFFF
	v_and_b32_e32 v25, 0xffff, v25                             // 000000D8C818: 363232FF 0000FFFF
	v_and_b32_e32 v26, 0xffff, v26                             // 000000D8C820: 363434FF 0000FFFF
	v_and_b32_e32 v28, 0xffff, v28                             // 000000D8C828: 363838FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D8C830: BF870214
	v_lshl_or_b32 v23, v24, 16, v23                            // 000000D8C834: D6560017 045D2118
	v_lshl_or_b32 v24, v21, 16, v25                            // 000000D8C83C: D6560018 04652115
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D8C844: BF870214
	v_lshl_or_b32 v25, v27, 16, v26                            // 000000D8C848: D6560019 0469211B
	v_lshl_or_b32 v26, v22, 16, v28                            // 000000D8C850: D656001A 04712116
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D8C858: BF870214
	v_pk_fma_f16 v21, v23, s10, 0xc931 op_sel_hi:[1,0,0]       // 000000D8C85C: CC0E0015 0BFC1517 0000C931
	v_pk_fma_f16 v22, v24, s10, 0xc931 op_sel_hi:[1,0,0]       // 000000D8C868: CC0E0016 0BFC1518 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D8C874: BF870214
	v_pk_fma_f16 v23, v25, s10, 0xc931 op_sel_hi:[1,0,0]       // 000000D8C878: CC0E0017 0BFC1519 0000C931
	v_pk_fma_f16 v24, v26, s10, 0xc931 op_sel_hi:[1,0,0]       // 000000D8C884: CC0E0018 0BFC151A 0000C931
	ds_store_b128 v1, v[21:24]                                 // 000000D8C890: DB7C0000 00001501
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 000000D8C898: 917E017E
	s_cbranch_execnz 65375                                     // 000000D8C89C: BFA6FF5F <_ZN7halogen12_GLOBAL__N_111k_ht_moe_guILi3ELi8ELi1EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_S5_PDF16_+0x31c>
	s_or_b32 exec_lo, exec_lo, s1                              // 000000D8C8A0: 8C7E017E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000D8C8A4: BF870009
	s_or_b32 exec_lo, exec_lo, s0                              // 000000D8C8A8: 8C7E007E
	.long 0xd44d0001                                           // 000000D8C8AC: D44D0001
	v_cndmask_b32_e32 v1, 0, v157, vcc_lo                      // 000000D8C8B0: 02033A80
	v_dual_mov_b32 v2, 0 :: v_dual_lshlrev_b32 v3, 1, v16      // 000000D8C8B4: CA220080 02022081
	s_waitcnt vmcnt(0)                                         // 000000D8C8BC: BF8903F7
	v_mad_i64_i32 v[146:147], null, 0x1400, v7, s[14:15]       // 000000D8C8C0: D6FF7C92 003A0EFF 00001400
	v_lshlrev_b32_e32 v161, 5, v158                            // 000000D8C8CC: 31433C85
	v_cndmask_b32_e64 v1, 23, v14, s1                          // 000000D8C8D0: D5010001 00061C97
	.long 0xd4490001                                           // 000000D8C8D8: D4490001
	v_cndmask_b32_e32 v1, 5, v8, vcc_lo                        // 000000D8C8DC: 02021085
	v_lshl_add_u32 v160, v9, 1, v3                             // 000000D8C8E0: D64600A0 040D0309
	v_mov_b32_e32 v3, v2                                       // 000000D8C8E8: 7E060302
	v_mov_b32_e32 v4, v2                                       // 000000D8C8EC: 7E080302
	v_mov_b32_e32 v5, v2                                       // 000000D8C8F0: 7E0A0302
	v_cndmask_b32_e64 v14, 23, v15, s1                         // 000000D8C8F4: D501000E 00061E97
	v_mov_b32_e32 v6, v2                                       // 000000D8C8FC: 7E0C0302
	v_mov_b32_e32 v7, v2                                       // 000000D8C900: 7E0E0302
	v_mov_b32_e32 v8, v2                                       // 000000D8C904: 7E100302
	v_mov_b32_e32 v9, v2                                       // 000000D8C908: 7E120302
	v_mov_b32_e32 v15, v2                                      // 000000D8C90C: 7E1E0302
	.long 0xd4490000                                           // 000000D8C910: D4490000
	v_cndmask_b32_e32 v1, 0x1ff, v0, vcc_lo                    // 000000D8C914: 020200FF 000001FF
	.long 0xd73c0094                                           // 000000D8C91C: D73C0094
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 000000D8C920: 02020282
	.long 0xd73c0096                                           // 000000D8C924: D73C0096
	v_cndmask_b32_e32 v1, 2, v10, vcc_lo                       // 000000D8C928: 02021482
	.long 0xd73c009a                                           // 000000D8C92C: D73C009A
	v_cndmask_b32_e32 v1, 2, v12, vcc_lo                       // 000000D8C930: 02021882
	.long 0xd73c0098                                           // 000000D8C934: D73C0098
	v_cndmask_b32_e32 v1, 2, v14, vcc_lo                       // 000000D8C938: 02021C82
	v_dual_mov_b32 v17, v9 :: v_dual_mov_b32 v14, v6           // 000000D8C93C: CA100109 110E0106
	v_dual_mov_b32 v25, v9 :: v_dual_mov_b32 v22, v6           // 000000D8C944: CA100109 19160106
	v_dual_mov_b32 v33, v9 :: v_dual_mov_b32 v30, v6           // 000000D8C94C: CA100109 211E0106
	v_dual_mov_b32 v41, v9 :: v_dual_mov_b32 v38, v6           // 000000D8C954: CA100109 29260106
	v_dual_mov_b32 v49, v9 :: v_dual_mov_b32 v46, v6           // 000000D8C95C: CA100109 312E0106
	v_dual_mov_b32 v57, v9 :: v_dual_mov_b32 v54, v6           // 000000D8C964: CA100109 39360106
	v_dual_mov_b32 v65, v9 :: v_dual_mov_b32 v62, v6           // 000000D8C96C: CA100109 413E0106
	v_dual_mov_b32 v73, v9 :: v_dual_mov_b32 v70, v6           // 000000D8C974: CA100109 49460106
	v_dual_mov_b32 v81, v9 :: v_dual_mov_b32 v78, v6           // 000000D8C97C: CA100109 514E0106
	v_dual_mov_b32 v89, v9 :: v_dual_mov_b32 v86, v6           // 000000D8C984: CA100109 59560106
	v_dual_mov_b32 v97, v9 :: v_dual_mov_b32 v94, v6           // 000000D8C98C: CA100109 615E0106
	v_dual_mov_b32 v105, v9 :: v_dual_mov_b32 v102, v6         // 000000D8C994: CA100109 69660106
	v_dual_mov_b32 v113, v9 :: v_dual_mov_b32 v110, v6         // 000000D8C99C: CA100109 716E0106
	v_dual_mov_b32 v121, v9 :: v_dual_mov_b32 v118, v6         // 000000D8C9A4: CA100109 79760106
	v_dual_mov_b32 v129, v9 :: v_dual_mov_b32 v126, v6         // 000000D8C9AC: CA100109 817E0106
	v_dual_mov_b32 v137, v9 :: v_dual_mov_b32 v134, v6         // 000000D8C9B4: CA100109 89860106
	v_dual_mov_b32 v16, v8 :: v_dual_mov_b32 v15, v7           // 000000D8C9BC: CA100108 100E0107
	v_dual_mov_b32 v12, v4 :: v_dual_mov_b32 v13, v5           // 000000D8C9C4: CA100104 0C0C0105
	v_dual_mov_b32 v10, v2 :: v_dual_mov_b32 v11, v3           // 000000D8C9CC: CA100102 0A0A0103
	v_dual_mov_b32 v24, v8 :: v_dual_mov_b32 v23, v7           // 000000D8C9D4: CA100108 18160107
	v_dual_mov_b32 v20, v4 :: v_dual_mov_b32 v21, v5           // 000000D8C9DC: CA100104 14140105
	v_dual_mov_b32 v18, v2 :: v_dual_mov_b32 v19, v3           // 000000D8C9E4: CA100102 12120103
	v_dual_mov_b32 v32, v8 :: v_dual_mov_b32 v31, v7           // 000000D8C9EC: CA100108 201E0107
	v_dual_mov_b32 v28, v4 :: v_dual_mov_b32 v29, v5           // 000000D8C9F4: CA100104 1C1C0105
	v_dual_mov_b32 v26, v2 :: v_dual_mov_b32 v27, v3           // 000000D8C9FC: CA100102 1A1A0103
	v_dual_mov_b32 v40, v8 :: v_dual_mov_b32 v39, v7           // 000000D8CA04: CA100108 28260107
	v_dual_mov_b32 v36, v4 :: v_dual_mov_b32 v37, v5           // 000000D8CA0C: CA100104 24240105
	v_dual_mov_b32 v34, v2 :: v_dual_mov_b32 v35, v3           // 000000D8CA14: CA100102 22220103
	v_dual_mov_b32 v48, v8 :: v_dual_mov_b32 v47, v7           // 000000D8CA1C: CA100108 302E0107
	v_dual_mov_b32 v44, v4 :: v_dual_mov_b32 v45, v5           // 000000D8CA24: CA100104 2C2C0105
	v_dual_mov_b32 v42, v2 :: v_dual_mov_b32 v43, v3           // 000000D8CA2C: CA100102 2A2A0103
	v_dual_mov_b32 v56, v8 :: v_dual_mov_b32 v55, v7           // 000000D8CA34: CA100108 38360107
	v_dual_mov_b32 v52, v4 :: v_dual_mov_b32 v53, v5           // 000000D8CA3C: CA100104 34340105
	v_dual_mov_b32 v50, v2 :: v_dual_mov_b32 v51, v3           // 000000D8CA44: CA100102 32320103
	v_dual_mov_b32 v64, v8 :: v_dual_mov_b32 v63, v7           // 000000D8CA4C: CA100108 403E0107
	v_dual_mov_b32 v60, v4 :: v_dual_mov_b32 v61, v5           // 000000D8CA54: CA100104 3C3C0105
	v_dual_mov_b32 v58, v2 :: v_dual_mov_b32 v59, v3           // 000000D8CA5C: CA100102 3A3A0103
	v_dual_mov_b32 v72, v8 :: v_dual_mov_b32 v71, v7           // 000000D8CA64: CA100108 48460107
	v_dual_mov_b32 v68, v4 :: v_dual_mov_b32 v69, v5           // 000000D8CA6C: CA100104 44440105
	v_dual_mov_b32 v66, v2 :: v_dual_mov_b32 v67, v3           // 000000D8CA74: CA100102 42420103
	v_dual_mov_b32 v80, v8 :: v_dual_mov_b32 v79, v7           // 000000D8CA7C: CA100108 504E0107
	v_dual_mov_b32 v76, v4 :: v_dual_mov_b32 v77, v5           // 000000D8CA84: CA100104 4C4C0105
	v_dual_mov_b32 v74, v2 :: v_dual_mov_b32 v75, v3           // 000000D8CA8C: CA100102 4A4A0103
	v_dual_mov_b32 v88, v8 :: v_dual_mov_b32 v87, v7           // 000000D8CA94: CA100108 58560107
	v_dual_mov_b32 v84, v4 :: v_dual_mov_b32 v85, v5           // 000000D8CA9C: CA100104 54540105
	v_dual_mov_b32 v82, v2 :: v_dual_mov_b32 v83, v3           // 000000D8CAA4: CA100102 52520103
	v_dual_mov_b32 v96, v8 :: v_dual_mov_b32 v95, v7           // 000000D8CAAC: CA100108 605E0107
	v_dual_mov_b32 v92, v4 :: v_dual_mov_b32 v93, v5           // 000000D8CAB4: CA100104 5C5C0105
	v_dual_mov_b32 v90, v2 :: v_dual_mov_b32 v91, v3           // 000000D8CABC: CA100102 5A5A0103
	v_dual_mov_b32 v104, v8 :: v_dual_mov_b32 v103, v7         // 000000D8CAC4: CA100108 68660107
	v_dual_mov_b32 v100, v4 :: v_dual_mov_b32 v101, v5         // 000000D8CACC: CA100104 64640105
	v_dual_mov_b32 v98, v2 :: v_dual_mov_b32 v99, v3           // 000000D8CAD4: CA100102 62620103
	v_dual_mov_b32 v112, v8 :: v_dual_mov_b32 v111, v7         // 000000D8CADC: CA100108 706E0107
	v_dual_mov_b32 v108, v4 :: v_dual_mov_b32 v109, v5         // 000000D8CAE4: CA100104 6C6C0105
	v_dual_mov_b32 v106, v2 :: v_dual_mov_b32 v107, v3         // 000000D8CAEC: CA100102 6A6A0103
	v_dual_mov_b32 v120, v8 :: v_dual_mov_b32 v119, v7         // 000000D8CAF4: CA100108 78760107
	v_dual_mov_b32 v116, v4 :: v_dual_mov_b32 v117, v5         // 000000D8CAFC: CA100104 74740105
	v_dual_mov_b32 v114, v2 :: v_dual_mov_b32 v115, v3         // 000000D8CB04: CA100102 72720103
	v_dual_mov_b32 v128, v8 :: v_dual_mov_b32 v127, v7         // 000000D8CB0C: CA100108 807E0107
	v_dual_mov_b32 v124, v4 :: v_dual_mov_b32 v125, v5         // 000000D8CB14: CA100104 7C7C0105
	v_dual_mov_b32 v122, v2 :: v_dual_mov_b32 v123, v3         // 000000D8CB1C: CA100102 7A7A0103
	v_dual_mov_b32 v136, v8 :: v_dual_mov_b32 v135, v7         // 000000D8CB24: CA100108 88860107
	v_dual_mov_b32 v132, v4 :: v_dual_mov_b32 v133, v5         // 000000D8CB2C: CA100104 84840105
	v_dual_mov_b32 v130, v2 :: v_dual_mov_b32 v131, v3         // 000000D8CB34: CA100102 82820103
	s_mov_b32 s13, 0                                           // 000000D8CB3C: BE8D0080
	s_xor_b32 s1, s0, -1                                       // 000000D8CB40: 8D01C100
	s_movk_i32 s10, 0x1eee                                     // 000000D8CB44: B00A1EEE
	v_cmp_gt_i32_e32 vcc_lo, s23, v156                         // 000000D8CB48: 7C893817
	s_branch 4                                                 // 000000D8CB4C: BFA00004 <_ZN7halogen12_GLOBAL__N_111k_ht_moe_guILi3ELi8ELi1EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_S5_PDF16_+0x860>
	s_or_b32 exec_lo, exec_lo, s12                             // 000000D8CB50: 8C7E0C7E
	s_cmpk_eq_i32 s11, 0xa0                                    // 000000D8CB54: B18B00A0
	s_mov_b32 s13, s11                                         // 000000D8CB58: BE8D000B
	s_cbranch_scc1 306                                         // 000000D8CB5C: BFA20132 <_ZN7halogen12_GLOBAL__N_111k_ht_moe_guILi3ELi8ELi1EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_S5_PDF16_+0xd28>
	s_and_b32 s14, s13, 1                                      // 000000D8CB60: 8B0E810D
	s_add_i32 s11, s13, 1                                      // 000000D8CB64: 810B810D
	s_cmpk_lg_i32 s13, 0x9f                                    // 000000D8CB68: B20D009F
	s_waitcnt lgkmcnt(0)                                       // 000000D8CB6C: BF89FC07
	s_cselect_b32 s0, -1, 0                                    // 000000D8CB70: 980080C1
	s_barrier                                                  // 000000D8CB74: BFBD0000
	s_and_b32 s0, s0, s1                                       // 000000D8CB78: 8B000100
	buffer_gl0_inv                                             // 000000D8CB7C: E0AC0000 00000000
	s_and_saveexec_b32 s12, s0                                 // 000000D8CB84: BE8C2000
	s_cbranch_execz 166                                        // 000000D8CB88: BFA500A6 <_ZN7halogen12_GLOBAL__N_111k_ht_moe_guILi3ELi8ELi1EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_S5_PDF16_+0xb24>
	s_xor_b32 s0, s14, 1                                       // 000000D8CB8C: 8D00810E
	v_mov_b32_e32 v4, v159                                     // 000000D8CB90: 7E08039F
	v_lshl_add_u32 v3, s0, 13, v160                            // 000000D8CB94: D6460003 06811A00
	s_lshl_b32 s15, s11, 4                                     // 000000D8CB9C: 840F840B
	s_mov_b32 s16, 0                                           // 000000D8CBA0: BE900080
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D8CBA4: BF870092
	v_add_nc_u32_e32 v1, s15, v4                               // 000000D8CBA8: 4A02080F
	.long 0xd72c0001                                           // 000000D8CBAC: D72C0001
	v_cndmask_b32_e32 v0, v1, v152, vcc_lo                     // 000000D8CBB0: 02013101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D8CBB4: BF870091
	.long 0xd73c0005                                           // 000000D8CBB8: D73C0005
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 000000D8CBBC: 02020282
	.long 0xd7000001                                           // 000000D8CBC0: D7000001
	v_cndmask_b32_e32 v1, s2, v5, vcc_lo                       // 000000D8CBC4: 02020A02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D8CBC8: BF870111
	v_add_co_ci_u32_e64 v9, null, s3, v6, s0                   // 000000D8CBCC: D5207C09 00020C03
	.long 0xd7000005                                           // 000000D8CBD4: D7000005
	v_cndmask_b32_e32 v1, v1, v148, vcc_lo                     // 000000D8CBD8: 02032901
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000D8CBDC: BF8700A1
	v_add_co_ci_u32_e64 v6, null, v9, v149, s0                 // 000000D8CBE0: D5207C06 00032B09
	.long 0xd7000007                                           // 000000D8CBE8: D7000007
	v_cndmask_b32_e32 v1, v1, v150, vcc_lo                     // 000000D8CBEC: 02032D01
	v_add_co_ci_u32_e64 v8, null, v9, v151, s0                 // 000000D8CBF0: D5207C08 00032F09
	.long 0xd70000a2                                           // 000000D8CBF8: D70000A2
	v_cndmask_b32_e32 v1, v1, v152, vcc_lo                     // 000000D8CBFC: 02033101
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000D8CC00: BF8700A1
	v_add_co_ci_u32_e64 v163, null, v9, v153, s0               // 000000D8CC04: D5207CA3 00033309
	.long 0xd70000a4                                           // 000000D8CC0C: D70000A4
	v_cndmask_b32_e32 v1, v1, v154, vcc_lo                     // 000000D8CC10: 02033501
	v_add_co_ci_u32_e64 v165, null, v9, v155, s0               // 000000D8CC14: D5207CA5 00033709
	s_clause 0x3                                               // 000000D8CC1C: BF850003
	global_load_b32 v6, v[5:6], off                            // 000000D8CC20: DC520000 067C0005
	global_load_b32 v5, v[7:8], off                            // 000000D8CC28: DC520000 057C0007
	global_load_b32 v8, v[162:163], off                        // 000000D8CC30: DC520000 087C00A2
	global_load_b32 v7, v[164:165], off                        // 000000D8CC38: DC520000 077C00A4
	.long 0xd4490000                                           // 000000D8CC40: D4490000
	v_cndmask_b32_e32 v1, 7, v4, vcc_lo                        // 000000D8CC44: 02020887
	v_lshl_add_u32 v1, v4, 9, v3                               // 000000D8CC48: D6460001 040D1304
	s_or_b32 s16, s0, s16                                      // 000000D8CC50: 8C101000
	s_waitcnt vmcnt(2)                                         // 000000D8CC54: BF890BF7
	.long 0xd73d00a2                                           // 000000D8CC58: D73D00A2
	v_cndmask_b32_e32 v1, v138, v5, vcc_lo                     // 000000D8CC5C: 02020B8A
	.long 0xd73d00a3                                           // 000000D8CC60: D73D00A3
	v_cndmask_b32_e32 v1, v139, v5, vcc_lo                     // 000000D8CC64: 02020B8B
	.long 0xd73d00a4                                           // 000000D8CC68: D73D00A4
	v_cndmask_b32_e32 v1, v140, v5, vcc_lo                     // 000000D8CC6C: 02020B8C
	s_waitcnt vmcnt(0)                                         // 000000D8CC70: BF8903F7
	.long 0xd73d00a5                                           // 000000D8CC74: D73D00A5
	v_cndmask_b32_e32 v1, v142, v7, vcc_lo                     // 000000D8CC78: 02020F8E
	.long 0xd73d00a6                                           // 000000D8CC7C: D73D00A6
	v_cndmask_b32_e32 v1, v143, v7, vcc_lo                     // 000000D8CC80: 02020F8F
	.long 0xd73d00a7                                           // 000000D8CC84: D73D00A7
	v_cndmask_b32_e32 v1, v144, v7, vcc_lo                     // 000000D8CC88: 02020F90
	.long 0xd73d0005                                           // 000000D8CC8C: D73D0005
	v_cndmask_b32_e32 v1, v141, v5, vcc_lo                     // 000000D8CC90: 02020B8D
	.long 0xd73d0006                                           // 000000D8CC94: D73D0006
	v_cndmask_b32_e32 v1, v145, v7, vcc_lo                     // 000000D8CC98: 02020F91
	v_and_b32_e32 v7, 0xffff, v162                             // 000000D8CC9C: 360F44FF 0000FFFF
	v_and_b32_e32 v9, 0xffff, v164                             // 000000D8CCA4: 361348FF 0000FFFF
	v_and_b32_e32 v162, 0xffff, v165                           // 000000D8CCAC: 37454AFF 0000FFFF
	v_and_b32_e32 v164, 0xffff, v167                           // 000000D8CCB4: 37494EFF 0000FFFF
	v_and_b32_e32 v8, 0xffff, v163                             // 000000D8CCBC: 361146FF 0000FFFF
	v_and_b32_e32 v5, 0xffff, v5                               // 000000D8CCC4: 360A0AFF 0000FFFF
	v_and_b32_e32 v163, 0xffff, v166                           // 000000D8CCCC: 37474CFF 0000FFFF
	v_and_b32_e32 v6, 0xffff, v6                               // 000000D8CCD4: 360C0CFF 0000FFFF
	.long 0xd72c0007                                           // 000000D8CCDC: D72C0007
	v_cndmask_b32_e32 v1, 0x83dcd12d, v7, vcc_lo               // 000000D8CCE0: 02020EFF 83DCD12D
	.long 0xd72c0009                                           // 000000D8CCE8: D72C0009
	v_cndmask_b32_e32 v1, 0x83dcd12d, v9, vcc_lo               // 000000D8CCEC: 020212FF 83DCD12D
	.long 0xd72c00a2                                           // 000000D8CCF4: D72C00A2
	v_cndmask_b32_e32 v1, 0x83dcd12d, v162, vcc_lo             // 000000D8CCF8: 020344FF 83DCD12D
	.long 0xd72c00a4                                           // 000000D8CD00: D72C00A4
	v_cndmask_b32_e32 v1, 0x83dcd12d, v164, vcc_lo             // 000000D8CD04: 020348FF 83DCD12D
	.long 0xd72c0008                                           // 000000D8CD0C: D72C0008
	v_cndmask_b32_e32 v1, 0x83dcd12d, v8, vcc_lo               // 000000D8CD10: 020210FF 83DCD12D
	.long 0xd72c0005                                           // 000000D8CD18: D72C0005
	v_cndmask_b32_e32 v1, 0x83dcd12d, v5, vcc_lo               // 000000D8CD1C: 02020AFF 83DCD12D
	.long 0xd72c00a3                                           // 000000D8CD24: D72C00A3
	v_cndmask_b32_e32 v1, 0x83dcd12d, v163, vcc_lo             // 000000D8CD28: 020346FF 83DCD12D
	.long 0xd72c0006                                           // 000000D8CD30: D72C0006
	v_cndmask_b32_e32 v1, 0x83dcd12d, v6, vcc_lo               // 000000D8CD34: 02020CFF 83DCD12D
	v_sad_u8 v7, v7, 0, 0x6400                                 // 000000D8CD3C: D6220007 03FD0107 00006400
	v_sad_u8 v9, v9, 0, 0x6400                                 // 000000D8CD48: D6220009 03FD0109 00006400
	v_sad_u8 v162, v162, 0, 0x6400                             // 000000D8CD54: D62200A2 03FD01A2 00006400
	v_sad_u8 v164, v164, 0, 0x6400                             // 000000D8CD60: D62200A4 03FD01A4 00006400
	v_sad_u8 v8, v8, 0, 0x6400                                 // 000000D8CD6C: D6220008 03FD0108 00006400
	v_sad_u8 v5, v5, 0, 0x6400                                 // 000000D8CD78: D6220005 03FD0105 00006400
	v_sad_u8 v163, v163, 0, 0x6400                             // 000000D8CD84: D62200A3 03FD01A3 00006400
	v_sad_u8 v6, v6, 0, 0x6400                                 // 000000D8CD90: D6220006 03FD0106 00006400
	v_and_b32_e32 v7, 0xffff, v7                               // 000000D8CD9C: 360E0EFF 0000FFFF
	v_and_b32_e32 v9, 0xffff, v9                               // 000000D8CDA4: 361212FF 0000FFFF
	v_and_b32_e32 v162, 0xffff, v162                           // 000000D8CDAC: 374544FF 0000FFFF
	v_and_b32_e32 v164, 0xffff, v164                           // 000000D8CDB4: 374948FF 0000FFFF
	v_add_nc_u32_e32 v165, 8, v4                               // 000000D8CDBC: 4B4A0888
	v_lshl_or_b32 v7, v8, 16, v7                               // 000000D8CDC0: D6560007 041D2108
	v_lshl_or_b32 v8, v5, 16, v9                               // 000000D8CDC8: D6560008 04252105
	v_lshl_or_b32 v9, v163, 16, v162                           // 000000D8CDD0: D6560009 068921A3
	v_lshl_or_b32 v162, v6, 16, v164                           // 000000D8CDD8: D65600A2 06912106
	v_mov_b32_e32 v4, v165                                     // 000000D8CDE0: 7E0803A5
	v_pk_fma_f16 v5, v7, s10, 0xc931 op_sel_hi:[1,0,0]         // 000000D8CDE4: CC0E0005 0BFC1507 0000C931
	v_pk_fma_f16 v6, v8, s10, 0xc931 op_sel_hi:[1,0,0]         // 000000D8CDF0: CC0E0006 0BFC1508 0000C931
	v_pk_fma_f16 v7, v9, s10, 0xc931 op_sel_hi:[1,0,0]         // 000000D8CDFC: CC0E0007 0BFC1509 0000C931
	v_pk_fma_f16 v8, v162, s10, 0xc931 op_sel_hi:[1,0,0]       // 000000D8CE08: CC0E0008 0BFC15A2 0000C931
	ds_store_b128 v1, v[5:8]                                   // 000000D8CE14: DB7C0000 00000501
	s_and_not1_b32 exec_lo, exec_lo, s16                       // 000000D8CE1C: 917E107E
	s_cbranch_execnz 65376                                     // 000000D8CE20: BFA6FF60 <_ZN7halogen12_GLOBAL__N_111k_ht_moe_guILi3ELi8ELi1EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_S5_PDF16_+0x8a4>
	s_or_b32 exec_lo, exec_lo, s12                             // 000000D8CE24: 8C7E0C7E
	s_and_saveexec_b32 s12, vcc_lo                             // 000000D8CE28: BE8C206A
	s_cbranch_execz 65352                                      // 000000D8CE2C: BFA5FF48 <_ZN7halogen12_GLOBAL__N_111k_ht_moe_guILi3ELi8ELi1EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_S5_PDF16_+0x850>
	s_lshl_b32 s0, s13, 5                                      // 000000D8CE30: 8400850D
	v_lshl_or_b32 v1, s14, 13, v161                            // 000000D8CE34: D6560001 06851A0E
	.long 0xd7000003                                           // 000000D8CE3C: D7000003
	v_cndmask_b32_e32 v0, v146, v0, vcc_lo                     // 000000D8CE40: 02000192
	s_delay_alu instid0(VALU_DEP_1)                            // 000000D8CE44: BF870001
	v_add_co_ci_u32_e64 v4, null, 0, v147, s0                  // 000000D8CE48: D5207C04 00032680
	ds_load_b128 v[170:173], v1                                // 000000D8CE50: DBFC0000 AA000001
	ds_load_b128 v[174:177], v1 offset:16                      // 000000D8CE58: DBFC0010 AE000001
	ds_load_b128 v[182:185], v1 offset:528                     // 000000D8CE60: DBFC0210 B6000001
	ds_load_b128 v[178:181], v1 offset:512                     // 000000D8CE68: DBFC0200 B2000001
	ds_load_b128 v[190:193], v1 offset:1040                    // 000000D8CE70: DBFC0410 BE000001
	ds_load_b128 v[186:189], v1 offset:1024                    // 000000D8CE78: DBFC0400 BA000001
	ds_load_b128 v[198:201], v1 offset:1552                    // 000000D8CE80: DBFC0610 C6000001
	ds_load_b128 v[194:197], v1 offset:1536                    // 000000D8CE88: DBFC0600 C2000001
	ds_load_b128 v[206:209], v1 offset:2064                    // 000000D8CE90: DBFC0810 CE000001
	ds_load_b128 v[202:205], v1 offset:2048                    // 000000D8CE98: DBFC0800 CA000001
	ds_load_b128 v[214:217], v1 offset:2576                    // 000000D8CEA0: DBFC0A10 D6000001
	ds_load_b128 v[210:213], v1 offset:2560                    // 000000D8CEA8: DBFC0A00 D2000001
	s_clause 0x1                                               // 000000D8CEB0: BF850001
	global_load_b128 v[166:169], v[3:4], off offset:16         // 000000D8CEB4: DC5E0010 A67C0003
	global_load_b128 v[162:165], v[3:4], off                   // 000000D8CEBC: DC5E0000 A27C0003
	s_waitcnt vmcnt(0) lgkmcnt(10)                             // 000000D8CEC4: BF8900A7
	v_wmma_f32_16x16x16_f16 v[130:137], v[162:169], v[170:177], v[130:137]// 000000D8CEC8: CC404082 1E0B55A2
	ds_load_b128 v[174:177], v1 offset:3088                    // 000000D8CED0: DBFC0C10 AE000001
	ds_load_b128 v[170:173], v1 offset:3072                    // 000000D8CED8: DBFC0C00 AA000001
	s_waitcnt lgkmcnt(10)                                      // 000000D8CEE0: BF89FCA7
	v_wmma_f32_16x16x16_f16 v[122:129], v[162:169], v[178:185], v[122:129]// 000000D8CEE4: CC40407A 1DEB65A2
	ds_load_b128 v[182:185], v1 offset:3600                    // 000000D8CEEC: DBFC0E10 B6000001
	ds_load_b128 v[178:181], v1 offset:3584                    // 000000D8CEF4: DBFC0E00 B2000001
	s_waitcnt lgkmcnt(10)                                      // 000000D8CEFC: BF89FCA7
	v_wmma_f32_16x16x16_f16 v[114:121], v[162:169], v[186:193], v[114:121]// 000000D8CF00: CC404072 1DCB75A2
	ds_load_b128 v[190:193], v1 offset:4112                    // 000000D8CF08: DBFC1010 BE000001
	ds_load_b128 v[186:189], v1 offset:4096                    // 000000D8CF10: DBFC1000 BA000001
	s_waitcnt lgkmcnt(10)                                      // 000000D8CF18: BF89FCA7
	v_wmma_f32_16x16x16_f16 v[106:113], v[162:169], v[194:201], v[106:113]// 000000D8CF1C: CC40406A 1DAB85A2
	ds_load_b128 v[198:201], v1 offset:4624                    // 000000D8CF24: DBFC1210 C6000001
	ds_load_b128 v[194:197], v1 offset:4608                    // 000000D8CF2C: DBFC1200 C2000001
	s_waitcnt lgkmcnt(10)                                      // 000000D8CF34: BF89FCA7
	v_wmma_f32_16x16x16_f16 v[98:105], v[162:169], v[202:209], v[98:105]// 000000D8CF38: CC404062 1D8B95A2
	ds_load_b128 v[206:209], v1 offset:5136                    // 000000D8CF40: DBFC1410 CE000001
	ds_load_b128 v[202:205], v1 offset:5120                    // 000000D8CF48: DBFC1400 CA000001
	s_waitcnt lgkmcnt(10)                                      // 000000D8CF50: BF89FCA7
	v_wmma_f32_16x16x16_f16 v[90:97], v[162:169], v[210:217], v[90:97]// 000000D8CF54: CC40405A 1D6BA5A2
	ds_load_b128 v[214:217], v1 offset:5648                    // 000000D8CF5C: DBFC1610 D6000001
	ds_load_b128 v[210:213], v1 offset:5632                    // 000000D8CF64: DBFC1600 D2000001
	s_waitcnt lgkmcnt(10)                                      // 000000D8CF6C: BF89FCA7
	v_wmma_f32_16x16x16_f16 v[82:89], v[162:169], v[170:177], v[82:89]// 000000D8CF70: CC404052 1D4B55A2
	ds_load_b128 v[174:177], v1 offset:6160                    // 000000D8CF78: DBFC1810 AE000001
	ds_load_b128 v[170:173], v1 offset:6144                    // 000000D8CF80: DBFC1800 AA000001
	s_waitcnt lgkmcnt(10)                                      // 000000D8CF88: BF89FCA7
	v_wmma_f32_16x16x16_f16 v[74:81], v[162:169], v[178:185], v[74:81]// 000000D8CF8C: CC40404A 1D2B65A2
	ds_load_b128 v[182:185], v1 offset:6672                    // 000000D8CF94: DBFC1A10 B6000001
	ds_load_b128 v[178:181], v1 offset:6656                    // 000000D8CF9C: DBFC1A00 B2000001
	s_waitcnt lgkmcnt(10)                                      // 000000D8CFA4: BF89FCA7
	v_wmma_f32_16x16x16_f16 v[66:73], v[162:169], v[186:193], v[66:73]// 000000D8CFA8: CC404042 1D0B75A2
	ds_load_b128 v[190:193], v1 offset:7184                    // 000000D8CFB0: DBFC1C10 BE000001
	ds_load_b128 v[186:189], v1 offset:7168                    // 000000D8CFB8: DBFC1C00 BA000001
	s_waitcnt lgkmcnt(10)                                      // 000000D8CFC0: BF89FCA7
	v_wmma_f32_16x16x16_f16 v[58:65], v[162:169], v[194:201], v[58:65]// 000000D8CFC4: CC40403A 1CEB85A2
	ds_load_b128 v[198:201], v1 offset:7696                    // 000000D8CFCC: DBFC1E10 C6000001
	ds_load_b128 v[194:197], v1 offset:7680                    // 000000D8CFD4: DBFC1E00 C2000001
	s_waitcnt lgkmcnt(10)                                      // 000000D8CFDC: BF89FCA7
	v_wmma_f32_16x16x16_f16 v[50:57], v[162:169], v[202:209], v[50:57]// 000000D8CFE0: CC404032 1CCB95A2
	s_waitcnt lgkmcnt(8)                                       // 000000D8CFE8: BF89FC87
	v_wmma_f32_16x16x16_f16 v[42:49], v[162:169], v[210:217], v[42:49]// 000000D8CFEC: CC40402A 1CABA5A2
	s_waitcnt lgkmcnt(6)                                       // 000000D8CFF4: BF89FC67
	v_wmma_f32_16x16x16_f16 v[34:41], v[162:169], v[170:177], v[34:41]// 000000D8CFF8: CC404022 1C8B55A2
	s_waitcnt lgkmcnt(4)                                       // 000000D8D000: BF89FC47
	v_wmma_f32_16x16x16_f16 v[26:33], v[162:169], v[178:185], v[26:33]// 000000D8D004: CC40401A 1C6B65A2
	s_waitcnt lgkmcnt(2)                                       // 000000D8D00C: BF89FC27
	v_wmma_f32_16x16x16_f16 v[18:25], v[162:169], v[186:193], v[18:25]// 000000D8D010: CC404012 1C4B75A2
	s_waitcnt lgkmcnt(0)                                       // 000000D8D018: BF89FC07
	v_wmma_f32_16x16x16_f16 v[10:17], v[162:169], v[194:201], v[10:17]// 000000D8D01C: CC40400A 1C2B85A2
	s_branch 65226                                             // 000000D8D024: BFA0FECA <_ZN7halogen12_GLOBAL__N_111k_ht_moe_guILi3ELi8ELi1EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_S5_PDF16_+0x850>
	s_and_saveexec_b32 s0, vcc_lo                              // 000000D8D028: BE80206A
	s_cbranch_execz 7885                                       // 000000D8D02C: BFA51ECD <_ZN7halogen12_GLOBAL__N_111k_ht_moe_guILi3ELi8ELi1EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_S5_PDF16_+0x8864>
	v_dual_add_f32 v2, v130, v122 :: v_dual_and_b32 v1, 1, v0  // 000000D8D030: C924F582 02000081
	v_dual_sub_f32 v3, v130, v122 :: v_dual_and_b32 v146, 2, v0// 000000D8D038: C964F582 03920082
	v_dual_add_f32 v122, v114, v106 :: v_dual_and_b32 v147, 4, v0// 000000D8D040: C924D572 7A920084
	v_sub_f32_e32 v106, v114, v106                             // 000000D8D048: 08D4D572
	v_and_b32_e32 v148, 8, v0                                  // 000000D8D04C: 37280088
	v_lshrrev_b32_e32 v0, 4, v157                              // 000000D8D050: 32013A84
	v_add_f32_e32 v114, v98, v90                               // 000000D8D054: 06E4B562
	v_sub_f32_e32 v90, v98, v90                                // 000000D8D058: 08B4B562
	v_add_f32_e32 v98, v82, v74                                // 000000D8D05C: 06C49552
	v_sub_f32_e32 v74, v82, v74                                // 000000D8D060: 08949552
	v_add_f32_e32 v82, v66, v58                                // 000000D8D064: 06A47542
	v_sub_f32_e32 v58, v66, v58                                // 000000D8D068: 08747542
	v_add_f32_e32 v66, v50, v42                                // 000000D8D06C: 06845532
	v_sub_f32_e32 v42, v50, v42                                // 000000D8D070: 08545532
	v_add_f32_e32 v50, v34, v26                                // 000000D8D074: 06643522
	v_sub_f32_e32 v26, v34, v26                                // 000000D8D078: 08343522
	v_add_f32_e32 v34, v18, v10                                // 000000D8D07C: 06441512
	s_mul_i32 s0, s20, 0xa00                                   // 000000D8D080: 9600FF14 00000A00
	s_mul_hi_i32 s1, s20, 0xa00                                // 000000D8D088: 9701FF14 00000A00
	s_add_u32 s4, s4, s0                                       // 000000D8D090: 80040004
	v_sub_f32_e32 v10, v18, v10                                // 000000D8D094: 08141512
	v_add_f32_e32 v18, v3, v106                                // 000000D8D098: 0624D503
	v_sub_f32_e32 v3, v3, v106                                 // 000000D8D09C: 0806D503
	v_add_f32_e32 v106, v114, v98                              // 000000D8D0A0: 06D4C572
	v_sub_f32_e32 v98, v114, v98                               // 000000D8D0A4: 08C4C572
	v_add_f32_e32 v114, v90, v74                               // 000000D8D0A8: 06E4955A
	v_sub_f32_e32 v74, v90, v74                                // 000000D8D0AC: 0894955A
	v_add_f32_e32 v90, v82, v66                                // 000000D8D0B0: 06B48552
	v_add_nc_u32_e32 v6, v156, v0                              // 000000D8D0B4: 4A0C019C
	v_add_f32_e32 v0, v2, v122                                 // 000000D8D0B8: 0600F502
	v_sub_f32_e32 v2, v2, v122                                 // 000000D8D0BC: 0804F502
	v_add_f32_e32 v122, v50, v34                               // 000000D8D0C0: 06F44532
	s_addc_u32 s5, s5, s1                                      // 000000D8D0C4: 82050105
	s_lshl_b32 s0, s21, 7                                      // 000000D8D0C8: 84008715
	v_sub_f32_e32 v34, v50, v34                                // 000000D8D0CC: 08444532
	s_ashr_i32 s1, s0, 31                                      // 000000D8D0D0: 86019F00
	v_add_f32_e32 v50, v26, v10                                // 000000D8D0D4: 0664151A
	s_lshl_b64 s[2:3], s[0:1], 1                               // 000000D8D0D8: 84828100
	v_sub_f32_e32 v10, v26, v10                                // 000000D8D0DC: 0814151A
	v_add_f32_e32 v26, v90, v122                               // 000000D8D0E0: 0634F55A
	.long 0xd44a0000                                           // 000000D8D0E4: D44A0000
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 000000D8D0E8: 02020280
	v_sub_f32_e32 v1, v90, v122                                // 000000D8D0EC: 0802F55A
	v_add_f32_e32 v90, v0, v106                                // 000000D8D0F0: 06B4D500
	v_sub_f32_e32 v0, v0, v106                                 // 000000D8D0F4: 0800D500
	v_mov_b32_dpp v151, v26 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D8D0F8: 7F2E02FA FF01611A
	v_cndmask_b32_e64 v26, -v26, v26, s0                       // 000000D8D100: D501001A 2002351A
	s_add_u32 s4, s4, s2                                       // 000000D8D108: 80040204
	s_addc_u32 s5, s5, s3                                      // 000000D8D10C: 82050305
	v_mov_b32_dpp v165, v0 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D8D110: 7F4A02FA FF016100
	v_cndmask_b32_e64 v167, -v0, v0, s0                        // 000000D8D118: D50100A7 20020100
	v_lshlrev_b32_e32 v4, 1, v158                              // 000000D8D120: 30093C81
	v_add_f32_e32 v26, v26, v151                               // 000000D8D124: 06352F1A
	v_sub_f32_e32 v66, v82, v66                                // 000000D8D128: 08848552
	s_delay_alu instid0(VALU_DEP_4)                            // 000000D8D12C: BF870004
	v_dual_add_f32 v82, v58, v42 :: v_dual_add_f32 v151, v167, v165// 000000D8D130: C908553A 52974BA7
	s_clause 0xb                                               // 000000D8D138: BF85000B
	global_load_d16_b16 v5, v4, s[4:5]                         // 000000D8D13C: DC820000 05040004
	global_load_d16_b16 v7, v4, s[4:5] offset:1280             // 000000D8D144: DC820500 07040004
	global_load_d16_b16 v9, v4, s[4:5] offset:1312             // 000000D8D14C: DC820520 09040004
	global_load_d16_b16 v8, v4, s[4:5] offset:32               // 000000D8D154: DC820020 08040004
	global_load_d16_b16 v138, v4, s[4:5] offset:64             // 000000D8D15C: DC820040 8A040004
	global_load_d16_b16 v139, v4, s[4:5] offset:96             // 000000D8D164: DC820060 8B040004
	global_load_d16_b16 v140, v4, s[4:5] offset:128            // 000000D8D16C: DC820080 8C040004
	global_load_d16_b16 v141, v4, s[4:5] offset:160            // 000000D8D174: DC8200A0 8D040004
	global_load_d16_b16 v142, v4, s[4:5] offset:192            // 000000D8D17C: DC8200C0 8E040004
	global_load_d16_b16 v143, v4, s[4:5] offset:224            // 000000D8D184: DC8200E0 8F040004
	global_load_d16_b16 v144, v4, s[4:5] offset:1344           // 000000D8D18C: DC820540 90040004
	global_load_d16_b16 v145, v4, s[4:5] offset:1376           // 000000D8D194: DC820560 91040004
	v_sub_f32_e32 v42, v58, v42                                // 000000D8D19C: 0854553A
	v_add_f32_e32 v58, v82, v50                                // 000000D8D1A0: 06746552
	v_sub_f32_e32 v50, v82, v50                                // 000000D8D1A4: 08646552
	v_add_f32_e32 v82, v66, v34                                // 000000D8D1A8: 06A44542
	v_sub_f32_e32 v34, v66, v34                                // 000000D8D1AC: 08444542
	v_add_f32_e32 v66, v42, v10                                // 000000D8D1B0: 0684152A
	v_sub_f32_e32 v10, v42, v10                                // 000000D8D1B4: 0814152A
	v_add_f32_e32 v42, v18, v114                               // 000000D8D1B8: 0654E512
	v_sub_f32_e32 v18, v18, v114                               // 000000D8D1BC: 0824E512
	s_clause 0x3                                               // 000000D8D1C0: BF850003
	global_load_d16_b16 v106, v4, s[4:5] offset:1408           // 000000D8D1C4: DC820580 6A040004
	global_load_d16_b16 v114, v4, s[4:5] offset:1440           // 000000D8D1CC: DC8205A0 72040004
	global_load_d16_b16 v149, v4, s[4:5] offset:1472           // 000000D8D1D4: DC8205C0 95040004
	global_load_d16_b16 v150, v4, s[4:5] offset:1504           // 000000D8D1DC: DC8205E0 96040004
	s_mul_i32 s10, s20, 0x500                                  // 000000D8D1E4: 960AFF14 00000500
	s_mul_hi_i32 s1, s20, 0x500                                // 000000D8D1EC: 9701FF14 00000500
	s_add_u32 s6, s6, s10                                      // 000000D8D1F4: 80060A06
	s_addc_u32 s1, s7, s1                                      // 000000D8D1F8: 82010107
	s_add_u32 s10, s6, s2                                      // 000000D8D1FC: 800A0206
	s_addc_u32 s11, s1, s3                                     // 000000D8D200: 820B0301
	s_clause 0x7                                               // 000000D8D204: BF850007
	global_load_d16_b16 v170, v4, s[10:11] offset:64           // 000000D8D208: DC820040 AA0A0004
	global_load_d16_b16 v171, v4, s[10:11] offset:96           // 000000D8D210: DC820060 AB0A0004
	global_load_d16_b16 v172, v4, s[10:11] offset:128          // 000000D8D218: DC820080 AC0A0004
	global_load_d16_b16 v173, v4, s[10:11] offset:160          // 000000D8D220: DC8200A0 AD0A0004
	global_load_d16_b16 v174, v4, s[10:11] offset:192          // 000000D8D228: DC8200C0 AE0A0004
	global_load_d16_b16 v175, v4, s[10:11] offset:224          // 000000D8D230: DC8200E0 AF0A0004
	global_load_d16_b16 v176, v4, s[10:11]                     // 000000D8D238: DC820000 B00A0004
	global_load_d16_b16 v157, v4, s[10:11] offset:32           // 000000D8D240: DC820020 9D0A0004
	v_add_f32_e32 v122, v3, v74                                // 000000D8D248: 06F49503
	v_mov_b32_dpp v166, v18 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D8D24C: 7F4C02FA FF016112
	v_cndmask_b32_e64 v18, -v18, v18, s0                       // 000000D8D254: D5010012 20022512
	s_add_u32 s1, s8, s2                                       // 000000D8D25C: 80010208
	s_addc_u32 s2, s9, s3                                      // 000000D8D260: 82020309
	.long 0xd7000100                                           // 000000D8D264: D7000100
	v_cndmask_b32_e32 v1, s1, v4, vcc_lo                       // 000000D8D268: 02020801
	v_add_f32_e32 v130, v2, v98                                // 000000D8D26C: 0704C502
	v_mov_b32_dpp v155, v1 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D8D270: 7F3602FA FF016101
	v_cndmask_b32_e64 v156, -v1, v1, s0                        // 000000D8D278: D501009C 20020301
	v_mov_b32_dpp v162, v42 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D8D280: 7F4402FA FF01612A
	v_cndmask_b32_e64 v42, -v42, v42, s0                       // 000000D8D288: D501002A 2002552A
	v_mov_b32_dpp v164, v122 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D8D290: 7F4802FA FF01617A
	v_cndmask_b32_e64 v122, -v122, v122, s0                    // 000000D8D298: D501007A 2002F57A
	v_add_co_ci_u32_e64 v1, null, s2, 0, s1                    // 000000D8D2A0: D5207C01 00050002
	.long 0xd44a0001                                           // 000000D8D2A8: D44A0001
	v_cndmask_b32_e32 v1, 0, v146, vcc_lo                      // 000000D8D2AC: 02032480
	v_add_f32_e32 v18, v18, v166                               // 000000D8D2B0: 06254D12
	v_mov_b32_dpp v154, v66 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D8D2B4: 7F3402FA FF016142
	v_cndmask_b32_e64 v66, -v66, v66, s0                       // 000000D8D2BC: D5010042 20028542
	v_mov_b32_dpp v161, v90 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D8D2C4: 7F4202FA FF01615A
	v_cndmask_b32_e64 v90, -v90, v90, s0                       // 000000D8D2CC: D501005A 2002B55A
	v_mov_b32_dpp v163, v130 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D8D2D4: 7F4602FA FF016182
	v_cndmask_b32_e64 v130, -v130, v130, s0                    // 000000D8D2DC: D5010082 20030582
	v_add_f32_e32 v42, v42, v162                               // 000000D8D2E4: 0655452A
	v_add_f32_e32 v122, v122, v164                             // 000000D8D2E8: 06F5497A
	v_mov_b32_dpp v166, v18 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D8D2EC: 7F4C02FA FF016212
	v_cndmask_b32_e64 v18, -v18, v18, s1                       // 000000D8D2F4: D5010012 20062512
	v_mov_b32_dpp v153, v82 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D8D2FC: 7F3202FA FF016152
	v_cndmask_b32_e64 v82, -v82, v82, s0                       // 000000D8D304: D5010052 2002A552
	v_mov_b32_dpp v160, v10 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D8D30C: 7F4002FA FF01610A
	v_cndmask_b32_e64 v10, -v10, v10, s0                       // 000000D8D314: D501000A 2002150A
	v_add_f32_e32 v66, v66, v154                               // 000000D8D31C: 06853542
	v_add_f32_e32 v90, v90, v161                               // 000000D8D320: 06B5435A
	v_add_f32_e32 v130, v130, v163                             // 000000D8D324: 07054782
	v_mov_b32_dpp v162, v42 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D8D328: 7F4402FA FF01622A
	v_cndmask_b32_e64 v42, -v42, v42, s1                       // 000000D8D330: D501002A 2006552A
	v_mov_b32_dpp v164, v122 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D8D338: 7F4802FA FF01627A
	v_cndmask_b32_e64 v122, -v122, v122, s1                    // 000000D8D340: D501007A 2006F57A
	v_mov_b32_dpp v165, v151 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D8D348: 7F4A02FA FF016297
	v_cndmask_b32_e64 v151, -v151, v151, s1                    // 000000D8D350: D5010097 20072F97
	.long 0xd44a0002                                           // 000000D8D358: D44A0002
	v_cndmask_b32_e32 v1, 0, v147, vcc_lo                      // 000000D8D35C: 02032680
	v_add_f32_e32 v18, v18, v166                               // 000000D8D360: 06254D12
	v_mov_b32_dpp v152, v58 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D8D364: 7F3002FA FF01613A
	v_cndmask_b32_e64 v58, -v58, v58, s0                       // 000000D8D36C: D501003A 2002753A
	v_add_f32_e32 v82, v82, v153                               // 000000D8D374: 06A53352
	v_add_f32_e32 v146, v156, v155                             // 000000D8D378: 0725379C
	v_add_f32_e32 v10, v10, v160                               // 000000D8D37C: 0615410A
	v_mov_b32_dpp v155, v66 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D8D380: 7F3602FA FF016242
	v_cndmask_b32_e64 v66, -v66, v66, s1                       // 000000D8D388: D5010042 20068542
	v_mov_b32_dpp v161, v90 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D8D390: 7F4202FA FF01625A
	v_cndmask_b32_e64 v90, -v90, v90, s1                       // 000000D8D398: D501005A 2006B55A
	v_mov_b32_dpp v163, v130 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D8D3A0: 7F4602FA FF016282
	v_cndmask_b32_e64 v130, -v130, v130, s1                    // 000000D8D3A8: D5010082 20070582
	v_add_f32_e32 v42, v42, v162                               // 000000D8D3B0: 0655452A
	v_dual_add_f32 v122, v122, v164 :: v_dual_add_f32 v147, v151, v165// 000000D8D3B4: C909497A 7A934B97
	v_mov_b32_dpp v165, v18 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D8D3BC: 7F4A02FA FF016412
	v_cndmask_b32_e64 v18, -v18, v18, s2                       // 000000D8D3C4: D5010012 200A2512
	v_add_f32_e32 v58, v58, v152                               // 000000D8D3CC: 0675313A
	v_mov_b32_dpp v154, v82 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D8D3D0: 7F3402FA FF016252
	v_cndmask_b32_e64 v82, -v82, v82, s1                       // 000000D8D3D8: D5010052 2006A552
	v_mov_b32_dpp v160, v10 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D8D3E0: 7F4002FA FF01620A
	v_cndmask_b32_e64 v10, -v10, v10, s1                       // 000000D8D3E8: D501000A 2006150A
	v_add_f32_e32 v66, v66, v155                               // 000000D8D3F0: 06853742
	v_add_f32_e32 v90, v90, v161                               // 000000D8D3F4: 06B5435A
	v_add_f32_e32 v130, v130, v163                             // 000000D8D3F8: 07054782
	v_mov_b32_dpp v161, v42 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D8D3FC: 7F4202FA FF01642A
	v_cndmask_b32_e64 v42, -v42, v42, s2                       // 000000D8D404: D501002A 200A552A
	v_mov_b32_dpp v163, v122 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D8D40C: 7F4602FA FF01647A
	v_cndmask_b32_e64 v122, -v122, v122, s2                    // 000000D8D414: D501007A 200AF57A
	v_mov_b32_dpp v164, v147 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D8D41C: 7F4802FA FF016493
	v_cndmask_b32_e64 v147, -v147, v147, s2                    // 000000D8D424: D5010093 200B2793
	.long 0xd44a0003                                           // 000000D8D42C: D44A0003
	v_cndmask_b32_e32 v1, 0, v148, vcc_lo                      // 000000D8D430: 02032880
	v_add_f32_e32 v18, v18, v165                               // 000000D8D434: 06254B12
	v_mov_b32_dpp v153, v58 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D8D438: 7F3202FA FF01623A
	v_cndmask_b32_e64 v58, -v58, v58, s1                       // 000000D8D440: D501003A 2006753A
	v_add_f32_e32 v82, v82, v154                               // 000000D8D448: 06A53552
	v_add_f32_e32 v10, v10, v160                               // 000000D8D44C: 0615410A
	v_mov_b32_dpp v154, v66 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D8D450: 7F3402FA FF016442
	v_cndmask_b32_e64 v66, -v66, v66, s2                       // 000000D8D458: D5010042 200A8542
	v_mov_b32_dpp v160, v90 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D8D460: 7F4002FA FF01645A
	v_cndmask_b32_e64 v90, -v90, v90, s2                       // 000000D8D468: D501005A 200AB55A
	v_mov_b32_dpp v162, v130 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D8D470: 7F4402FA FF016482
	v_cndmask_b32_e64 v130, -v130, v130, s2                    // 000000D8D478: D5010082 200B0582
	v_add_f32_e32 v42, v42, v161                               // 000000D8D480: 0655432A
	v_dual_add_f32 v122, v122, v163 :: v_dual_add_f32 v147, v147, v164// 000000D8D484: C909477A 7A934993
	v_mov_b32_dpp v164, v18 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D8D48C: 7F4802FA FF016812
	v_cndmask_b32_e64 v18, -v18, v18, s3                       // 000000D8D494: D5010012 200E2512
	v_sub_f32_e32 v98, v2, v98                                 // 000000D8D49C: 08C4C502
	v_add_f32_e32 v58, v58, v153                               // 000000D8D4A0: 0675333A
	v_mov_b32_dpp v153, v82 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D8D4A4: 7F3202FA FF016452
	v_cndmask_b32_e64 v82, -v82, v82, s2                       // 000000D8D4AC: D5010052 200AA552
	v_add_f32_e32 v66, v66, v154                               // 000000D8D4B4: 06853542
	v_add_f32_e32 v90, v90, v160                               // 000000D8D4B8: 06B5415A
	v_add_f32_e32 v130, v130, v162                             // 000000D8D4BC: 07054582
	v_mov_b32_dpp v160, v42 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D8D4C0: 7F4002FA FF01682A
	v_cndmask_b32_e64 v42, -v42, v42, s3                       // 000000D8D4C8: D501002A 200E552A
	v_mov_b32_dpp v162, v122 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D8D4D0: 7F4402FA FF01687A
	v_cndmask_b32_e64 v122, -v122, v122, s3                    // 000000D8D4D8: D501007A 200EF57A
	v_add_f32_e32 v18, v18, v164                               // 000000D8D4E0: 06254912
	v_mov_b32_dpp v168, v98 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D8D4E4: 7F5002FA FF016162
	v_cndmask_b32_e64 v98, -v98, v98, s0                       // 000000D8D4EC: D5010062 2002C562
	v_add_f32_e32 v82, v82, v153                               // 000000D8D4F4: 06A53352
	v_mov_b32_dpp v153, v66 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D8D4F8: 7F3202FA FF016842
	v_cndmask_b32_e64 v66, -v66, v66, s3                       // 000000D8D500: D5010042 200E8542
	v_add_f32_e32 v42, v42, v160                               // 000000D8D508: 0655412A
	v_add_f32_e32 v122, v122, v162                             // 000000D8D50C: 06F5457A
	v_mul_f32_e32 v18, 0x3db504f3, v18                         // 000000D8D510: 102424FF 3DB504F3
	v_mov_b32_dpp v159, v34 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D8D518: 7F3E02FA FF016122
	v_cndmask_b32_e64 v34, -v34, v34, s0                       // 000000D8D520: D5010022 20024522
	v_add_f32_e32 v98, v98, v168                               // 000000D8D528: 06C55162
	v_add_f32_e32 v66, v66, v153                               // 000000D8D52C: 06853342
	v_mul_f32_e32 v42, 0x3db504f3, v42                         // 000000D8D530: 105454FF 3DB504F3
	v_mul_f32_e32 v122, 0x3db504f3, v122                       // 000000D8D538: 10F4F4FF 3DB504F3
	v_add_f32_e32 v34, v34, v159                               // 000000D8D540: 06453F22
	v_mov_b32_dpp v167, v98 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D8D544: 7F4E02FA FF016262
	v_cndmask_b32_e64 v98, -v98, v98, s1                       // 000000D8D54C: D5010062 2006C562
	v_mul_f32_e32 v66, 0x3db504f3, v66                         // 000000D8D554: 108484FF 3DB504F3
	v_mov_b32_dpp v161, v130 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D8D55C: 7F4202FA FF016882
	v_mov_b32_dpp v159, v34 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D8D564: 7F3E02FA FF016222
	v_cndmask_b32_e64 v34, -v34, v34, s1                       // 000000D8D56C: D5010022 20064522
	v_add_f32_e32 v98, v98, v167                               // 000000D8D574: 06C54F62
	v_cndmask_b32_e64 v130, -v130, v130, s3                    // 000000D8D578: D5010082 200F0582
	v_mov_b32_dpp v158, v50 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D8D580: 7F3C02FA FF016132
	v_cndmask_b32_e64 v50, -v50, v50, s0                       // 000000D8D588: D5010032 20026532
	v_add_f32_e32 v34, v34, v159                               // 000000D8D590: 06453F22
	v_mov_b32_dpp v159, v10 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D8D594: 7F3E02FA FF01640A
	v_cndmask_b32_e64 v10, -v10, v10, s2                       // 000000D8D59C: D501000A 200A150A
	v_mov_b32_dpp v166, v98 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D8D5A4: 7F4C02FA FF016462
	v_cndmask_b32_e64 v98, -v98, v98, s2                       // 000000D8D5AC: D5010062 200AC562
	v_add_f32_e32 v130, v130, v161                             // 000000D8D5B4: 07054382
	v_add_f32_e32 v50, v50, v158                               // 000000D8D5B8: 06653D32
	v_add_f32_e32 v10, v10, v159                               // 000000D8D5BC: 06153F0A
	v_mov_b32_dpp v159, v90 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D8D5C0: 7F3E02FA FF01685A
	v_add_f32_e32 v98, v98, v166                               // 000000D8D5C8: 06C54D62
	v_cndmask_b32_e64 v90, -v90, v90, s3                       // 000000D8D5CC: D501005A 200EB55A
	v_mul_f32_e32 v130, 0x3db504f3, v130                       // 000000D8D5D4: 110504FF 3DB504F3
	v_mov_b32_dpp v156, v146 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D8D5DC: 7F3802FA FF016292
	v_cndmask_b32_e64 v146, -v146, v146, s1                    // 000000D8D5E4: D5010092 20072592
	v_mov_b32_dpp v165, v98 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D8D5EC: 7F4A02FA FF016862
	v_cndmask_b32_e64 v98, -v98, v98, s3                       // 000000D8D5F4: D5010062 200EC562
	v_add_f32_e32 v90, v90, v159                               // 000000D8D5FC: 06B53F5A
	v_mov_b32_dpp v158, v50 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D8D600: 7F3C02FA FF016232
	v_cndmask_b32_e64 v50, -v50, v50, s1                       // 000000D8D608: D5010032 20066532
	v_add_f32_e32 v146, v146, v156                             // 000000D8D610: 07253992
	v_add_f32_e32 v98, v98, v165                               // 000000D8D614: 06C54B62
	v_mul_f32_e32 v90, 0x3db504f3, v90                         // 000000D8D618: 10B4B4FF 3DB504F3
	v_mov_b32_dpp v163, v147 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D8D620: 7F4602FA FF016893
	v_add_f32_e32 v50, v50, v158                               // 000000D8D628: 06653D32
	v_mov_b32_dpp v155, v146 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D8D62C: 7F3602FA FF016492
	v_mul_f32_e32 v98, 0x3db504f3, v98                         // 000000D8D634: 10C4C4FF 3DB504F3
	v_cndmask_b32_e64 v146, -v146, v146, s2                    // 000000D8D63C: D5010092 200B2592
	v_cndmask_b32_e64 v147, -v147, v147, s3                    // 000000D8D644: D5010093 200F2793
	v_mov_b32_dpp v156, v50 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D8D64C: 7F3802FA FF016432
	v_cndmask_b32_e64 v50, -v50, v50, s2                       // 000000D8D654: D5010032 200A6532
	v_mov_b32_dpp v158, v34 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D8D65C: 7F3C02FA FF016422
	v_cndmask_b32_e64 v34, -v34, v34, s2                       // 000000D8D664: D5010022 200A4522
	v_add_f32_e32 v146, v146, v155                             // 000000D8D66C: 07253792
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D8D670: BF870224
	v_dual_add_f32 v147, v147, v163 :: v_dual_add_f32 v50, v50, v156// 000000D8D674: C9094793 93333932
	.long 0xd7000702                                           // 000000D8D67C: D7000702
	v_cndmask_b32_e32 v1, s4, v4, vcc_lo                       // 000000D8D680: 02020804
	v_add_f32_e32 v34, v34, v158                               // 000000D8D684: 06453D22
	s_delay_alu instid0(VALU_DEP_4)                            // 000000D8D688: BF870004
	v_mov_b32_dpp v154, v146 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D8D68C: 7F3402FA FF016892
	v_cndmask_b32_e64 v146, -v146, v146, s3                    // 000000D8D694: D5010092 200F2592
	v_mov_b32_dpp v155, v50 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D8D69C: 7F3602FA FF016832
	v_cndmask_b32_e64 v50, -v50, v50, s3                       // 000000D8D6A4: D5010032 200E6532
	v_mul_f32_e32 v147, 0x3db504f3, v147                       // 000000D8D6AC: 112726FF 3DB504F3
	v_mov_b32_dpp v156, v34 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D8D6B4: 7F3802FA FF016822
	v_cndmask_b32_e64 v34, -v34, v34, s3                       // 000000D8D6BC: D5010022 200E4522
	v_add_f32_e32 v146, v146, v154                             // 000000D8D6C4: 07253592
	v_add_f32_e32 v50, v50, v155                               // 000000D8D6C8: 06653732
	v_mov_b32_dpp v158, v10 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D8D6CC: 7F3C02FA FF01680A
	v_cndmask_b32_e64 v10, -v10, v10, s3                       // 000000D8D6D4: D501000A 200E150A
	v_add_f32_e32 v34, v34, v156                               // 000000D8D6DC: 06453922
	v_mul_f32_e32 v146, 0x3db504f3, v146                       // 000000D8D6E0: 112524FF 3DB504F3
	v_mul_f32_e32 v50, 0x3db504f3, v50                         // 000000D8D6E8: 106464FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D8D6F0: BF870214
	v_add_f32_e32 v10, v10, v158                               // 000000D8D6F4: 06153D0A
	v_mul_f32_e32 v34, 0x3db504f3, v34                         // 000000D8D6F8: 104444FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_2)                            // 000000D8D700: BF870002
	v_mul_f32_e32 v10, 0x3db504f3, v10                         // 000000D8D704: 101414FF 3DB504F3
	s_waitcnt vmcnt(23)                                        // 000000D8D70C: BF895FF7
	v_fma_mix_f32 v5, v5, v90, neg(0) op_sel_hi:[1,0,0]        // 000000D8D710: CC200005 8A02B505
	s_waitcnt vmcnt(20)                                        // 000000D8D718: BF8953F7
	v_fma_mix_f32 v8, v8, v42, neg(0) op_sel_hi:[1,0,0]        // 000000D8D71C: CC200008 8A025508
	s_waitcnt vmcnt(18)                                        // 000000D8D724: BF894BF7
	v_fma_mix_f32 v42, v139, v122, neg(0) op_sel_hi:[1,0,0]    // 000000D8D728: CC20002A 8A02F58B
	s_waitcnt vmcnt(16)                                        // 000000D8D730: BF8943F7
	v_fma_mix_f32 v18, v141, v18, neg(0) op_sel_hi:[1,0,0]     // 000000D8D734: CC200012 8A02258D
	s_waitcnt vmcnt(15)                                        // 000000D8D73C: BF893FF7
	v_fma_mix_f32 v90, v142, v98, neg(0) op_sel_hi:[1,0,0]     // 000000D8D740: CC20005A 8A02C58E
	v_mul_f32_e32 v98, 0xbfb8aa3b, v5                          // 000000D8D748: 10C40AFF BFB8AA3B
	s_waitcnt vmcnt(12)                                        // 000000D8D750: BF8933F7
	v_fma_mix_f32 v66, v145, v66, neg(0) op_sel_hi:[1,0,0]     // 000000D8D754: CC200042 8A028591
	v_sub_f32_e32 v74, v3, v74                                 // 000000D8D75C: 08949503
	v_mul_f32_e32 v139, 0xbfb8aa3b, v18                        // 000000D8D760: 111624FF BFB8AA3B
	v_mov_b32_dpp v152, v26 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D8D768: 7F3002FA FF01621A
	v_cndmask_b32_e64 v26, -v26, v26, s1                       // 000000D8D770: D501001A 2006351A
	v_mul_f32_e32 v122, 0xbfb8aa3b, v8                         // 000000D8D778: 10F410FF BFB8AA3B
	v_mov_b32_dpp v169, v74 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D8D780: 7F5202FA FF01614A
	v_cndmask_b32_e64 v74, -v74, v74, s0                       // 000000D8D788: D501004A 2002954A
	v_exp_f32_e32 v98, v98                                     // 000000D8D790: 7EC44B62
	v_add_f32_e32 v26, v26, v152                               // 000000D8D794: 0635311A
	v_mov_b32_dpp v152, v58 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D8D798: 7F3002FA FF01643A
	v_cndmask_b32_e64 v58, -v58, v58, s2                       // 000000D8D7A0: D501003A 200A753A
	v_add_f32_e32 v74, v74, v169                               // 000000D8D7A8: 0695534A
	v_exp_f32_e32 v122, v122                                   // 000000D8D7AC: 7EF44B7A
	v_mov_b32_dpp v151, v26 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D8D7B0: 7F2E02FA FF01641A
	v_cndmask_b32_e64 v26, -v26, v26, s2                       // 000000D8D7B8: D501001A 200A351A
	v_add_f32_e32 v58, v58, v152                               // 000000D8D7C0: 0675313A
	v_mov_b32_dpp v168, v74 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D8D7C4: 7F5002FA FF01624A
	v_cndmask_b32_e64 v74, -v74, v74, s1                       // 000000D8D7CC: D501004A 2006954A
	v_mov_b32_dpp v152, v82 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D8D7D4: 7F3002FA FF016852
	v_add_f32_e32 v26, v26, v151                               // 000000D8D7DC: 06352F1A
	v_cndmask_b32_e64 v82, -v82, v82, s3                       // 000000D8D7E0: D5010052 200EA552
	v_mov_b32_dpp v151, v58 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D8D7E8: 7F2E02FA FF01683A
	v_add_f32_e32 v74, v74, v168                               // 000000D8D7F0: 0695514A
	v_cndmask_b32_e64 v58, -v58, v58, s3                       // 000000D8D7F4: D501003A 200E753A
	v_mov_b32_dpp v148, v26 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D8D7FC: 7F2802FA FF01681A
	v_cndmask_b32_e64 v26, -v26, v26, s3                       // 000000D8D804: D501001A 200E351A
	v_add_f32_e32 v82, v82, v152                               // 000000D8D80C: 06A53152
	v_mov_b32_dpp v167, v74 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D8D810: 7F4E02FA FF01644A
	v_cndmask_b32_e64 v74, -v74, v74, s2                       // 000000D8D818: D501004A 200A954A
	v_add_f32_e32 v98, 1.0, v98                                // 000000D8D820: 06C4C4F2
	v_add_f32_e32 v26, v26, v148                               // 000000D8D824: 0635291A
	v_add_f32_e32 v58, v58, v151                               // 000000D8D828: 06752F3A
	v_mul_f32_e32 v82, 0x3db504f3, v82                         // 000000D8D82C: 10A4A4FF 3DB504F3
	v_add_f32_e32 v74, v74, v167                               // 000000D8D834: 06954F4A
	v_add_f32_e32 v122, 1.0, v122                              // 000000D8D838: 06F4F4F2
	v_mul_f32_e32 v26, 0x3db504f3, v26                         // 000000D8D83C: 103434FF 3DB504F3
	v_mul_f32_e32 v58, 0x3db504f3, v58                         // 000000D8D844: 107474FF 3DB504F3
	v_fma_mix_f32 v82, v144, v82, neg(0) op_sel_hi:[1,0,0]     // 000000D8D84C: CC200052 8A02A590
	v_mov_b32_dpp v166, v74 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D8D854: 7F4C02FA FF01684A
	v_cndmask_b32_e64 v74, -v74, v74, s3                       // 000000D8D85C: D501004A 200E954A
	v_fma_mix_f32 v7, v7, v26, neg(0) op_sel_hi:[1,0,0]        // 000000D8D864: CC200007 8A023507
	v_fma_mix_f32 v26, v138, v130, neg(0) op_sel_hi:[1,0,0]    // 000000D8D86C: CC20001A 8A03058A
	v_mul_f32_e32 v138, 0xbfb8aa3b, v42                        // 000000D8D874: 111454FF BFB8AA3B
	v_div_scale_f32 v144, null, v122, v122, v8                 // 000000D8D87C: D6FC7C90 0422F57A
	v_add_f32_e32 v74, v74, v166                               // 000000D8D884: 06954D4A
	v_fma_mix_f32 v9, v9, v58, neg(0) op_sel_hi:[1,0,0]        // 000000D8D888: CC200009 8A027509
	v_mul_f32_e32 v130, 0xbfb8aa3b, v26                        // 000000D8D890: 110434FF BFB8AA3B
	v_exp_f32_e32 v138, v138                                   // 000000D8D898: 7F144B8A
	v_fma_mix_f32 v58, v140, v147, neg(0) op_sel_hi:[1,0,0]    // 000000D8D89C: CC20003A 8A03278C
	v_mul_f32_e32 v74, 0x3db504f3, v74                         // 000000D8D8A4: 109494FF 3DB504F3
	v_rcp_f32_e32 v155, v144                                   // 000000D8D8AC: 7F365590
	v_exp_f32_e32 v130, v130                                   // 000000D8D8B0: 7F044B82
	v_mul_f32_e32 v142, 0xbfb8aa3b, v90                        // 000000D8D8B4: 111CB4FF BFB8AA3B
	v_mul_f32_e32 v140, 0xbfb8aa3b, v58                        // 000000D8D8BC: 111874FF BFB8AA3B
	v_fma_mix_f32 v74, v143, v74, neg(0) op_sel_hi:[1,0,0]     // 000000D8D8C4: CC20004A 8A02958F
	v_div_scale_f32 v143, null, v98, v98, v5                   // 000000D8D8CC: D6FC7C8F 0416C562
	v_div_scale_f32 v147, vcc_lo, v5, v98, v5                  // 000000D8D8D4: D6FC6A93 0416C505
	v_add_f32_e32 v138, 1.0, v138                              // 000000D8D8DC: 071514F2
	v_exp_f32_e32 v140, v140                                   // 000000D8D8E0: 7F184B8C
	v_mul_f32_e32 v141, 0xbfb8aa3b, v74                        // 000000D8D8E4: 111A94FF BFB8AA3B
	v_rcp_f32_e32 v154, v143                                   // 000000D8D8EC: 7F34558F
	v_add_f32_e32 v130, 1.0, v130                              // 000000D8D8F0: 070504F2
	v_div_scale_f32 v152, null, v138, v138, v42                // 000000D8D8F4: D6FC7C98 04AB158A
	v_fma_f32 v166, -v144, v155, 1.0                           // 000000D8D8FC: D61300A6 23CB3790
	v_exp_f32_e32 v139, v139                                   // 000000D8D904: 7F164B8B
	v_div_scale_f32 v148, s4, v8, v122, v8                     // 000000D8D908: D6FC0494 0422F508
	v_div_scale_f32 v145, null, v130, v130, v26                // 000000D8D910: D6FC7C91 046B0582
	v_rcp_f32_e32 v164, v152                                   // 000000D8D918: 7F485598
	v_fmac_f32_e32 v155, v166, v155                            // 000000D8D91C: 573737A6
	v_exp_f32_e32 v142, v142                                   // 000000D8D920: 7F1C4B8E
	v_fma_f32 v165, -v143, v154, 1.0                           // 000000D8D924: D61300A5 23CB358F
	v_rcp_f32_e32 v156, v145                                   // 000000D8D92C: 7F385591
	v_exp_f32_e32 v141, v141                                   // 000000D8D930: 7F1A4B8D
	v_add_co_ci_u32_e64 v3, null, s5, 0, s7                    // 000000D8D934: D5207C03 001D0005
	s_delay_alu instid0(VALU_DEP_2)                            // 000000D8D93C: BF870002
	v_fmac_f32_e32 v154, v165, v154                            // 000000D8D940: 573535A5
	v_add_f32_e32 v140, 1.0, v140                              // 000000D8D944: 071918F2
	v_div_scale_f32 v151, s5, v26, v130, v26                   // 000000D8D948: D6FC0597 046B051A
	v_mul_f32_e32 v177, v148, v155                             // 000000D8D950: 11633794
	v_add_f32_e32 v139, 1.0, v139                              // 000000D8D954: 071716F2
	v_fma_f32 v179, -v152, v164, 1.0                           // 000000D8D958: D61300B3 23CB4998
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000D8D960: BF870246
	v_fma_f32 v167, -v145, v156, 1.0                           // 000000D8D964: D61300A7 23CB3991
	v_div_scale_f32 v158, null, v140, v140, v58                // 000000D8D96C: D6FC7C9E 04EB198C
	v_fma_f32 v182, -v144, v177, v148                          // 000000D8D974: D61300B6 26536390
	v_dual_add_f32 v142, 1.0, v142 :: v_dual_add_f32 v141, 1.0, v141// 000000D8D97C: C9091CF2 8E8D1AF2
	v_fmac_f32_e32 v156, v167, v156                            // 000000D8D984: 573939A7
	v_mul_f32_e32 v167, v147, v154                             // 000000D8D988: 114F3593
	v_div_scale_f32 v153, s6, v42, v138, v42                   // 000000D8D98C: D6FC0699 04AB152A
	v_div_scale_f32 v159, null, v139, v139, v18                // 000000D8D994: D6FC7C9F 044B178B
	v_fmac_f32_e32 v164, v179, v164                            // 000000D8D99C: 574949B3
	v_mul_f32_e32 v178, v151, v156                             // 000000D8D9A0: 11653997
	v_fma_f32 v181, -v143, v167, v147                          // 000000D8D9A4: D61300B5 264F4F8F
	v_rcp_f32_e32 v168, v158                                   // 000000D8D9AC: 7F50559E
	v_fmac_f32_e32 v177, v182, v155                            // 000000D8D9B0: 576337B6
	v_div_scale_f32 v160, null, v142, v142, v90                // 000000D8D9B4: D6FC7CA0 056B1D8E
	v_fma_f32 v183, -v145, v178, v151                          // 000000D8D9BC: D61300B7 265F6591
	v_fmac_f32_e32 v167, v181, v154                            // 000000D8D9C4: 574F35B5
	v_div_scale_f32 v161, null, v141, v141, v74                // 000000D8D9C8: D6FC7CA1 052B1B8D
	v_rcp_f32_e32 v169, v159                                   // 000000D8D9D0: 7F52559F
	v_mul_f32_e32 v181, v153, v164                             // 000000D8D9D4: 116B4999
	v_fmac_f32_e32 v178, v183, v156                            // 000000D8D9D8: 576539B7
	v_fma_f32 v143, -v143, v167, v147                          // 000000D8D9DC: D613008F 264F4F8F
	v_fma_f32 v144, -v144, v177, v148                          // 000000D8D9E4: D6130090 26536390
	v_rcp_f32_e32 v165, v160                                   // 000000D8D9EC: 7F4A55A0
	v_rcp_f32_e32 v166, v161                                   // 000000D8D9F0: 7F4C55A1
	v_fma_f32 v147, -v152, v181, v153                          // 000000D8D9F4: D6130093 26676B98
	v_div_fmas_f32 v143, v143, v154, v167                      // 000000D8D9FC: D637008F 069F358F
	s_mov_b32 vcc_lo, s4                                       // 000000D8DA04: BEEA0004
	v_fma_f32 v180, -v158, v168, 1.0                           // 000000D8DA08: D61300B4 23CB519E
	v_fma_f32 v145, -v145, v178, v151                          // 000000D8DA10: D6130091 265F6591
	v_div_fmas_f32 v144, v144, v155, v177                      // 000000D8DA18: D6370090 06C73790
	s_mov_b32 vcc_lo, s5                                       // 000000D8DA20: BEEA0005
	v_fma_f32 v184, -v159, v169, 1.0                           // 000000D8DA24: D61300B8 23CB539F
	v_fmac_f32_e32 v181, v147, v164                            // 000000D8DA2C: 576B4993
	v_div_scale_f32 v162, s7, v58, v140, v58                   // 000000D8DA30: D6FC07A2 04EB193A
	v_fmac_f32_e32 v168, v180, v168                            // 000000D8DA38: 575151B4
	v_div_fmas_f32 v145, v145, v156, v178                      // 000000D8DA3C: D6370091 06CB3991
	v_div_fixup_f32 v8, v144, v122, v8                         // 000000D8DA44: D6270008 0422F590
	v_fma_f32 v179, -v160, v165, 1.0                           // 000000D8DA4C: D61300B3 23CB4BA0
	v_div_scale_f32 v163, s8, v18, v139, v18                   // 000000D8DA54: D6FC08A3 044B1712
	v_fmac_f32_e32 v169, v184, v169                            // 000000D8DA5C: 575353B8
	v_fma_f32 v151, -v161, v166, 1.0                           // 000000D8DA60: D6130097 23CB4DA1
	v_div_fixup_f32 v5, v143, v98, v5                          // 000000D8DA68: D6270005 0416C58F
	v_fma_f32 v98, -v152, v181, v153                           // 000000D8DA70: D6130062 26676B98
	v_div_fixup_f32 v26, v145, v130, v26                       // 000000D8DA78: D627001A 046B0591
	v_mul_f32_e32 v8, v9, v8                                   // 000000D8DA80: 10101109
	v_mul_f32_e32 v9, v162, v168                               // 000000D8DA84: 101351A2
	v_div_scale_f32 v148, s4, v90, v142, v90                   // 000000D8DA88: D6FC0494 056B1D5A
	v_fmac_f32_e32 v165, v179, v165                            // 000000D8DA90: 574B4BB3
	s_mov_b32 vcc_lo, s6                                       // 000000D8DA94: BEEA0006
	v_mul_f32_e32 v7, v7, v5                                   // 000000D8DA98: 100E0B07
	v_div_fmas_f32 v5, v98, v164, v181                         // 000000D8DA9C: D6370005 06D74962
	v_mul_f32_e32 v98, v163, v169                              // 000000D8DAA4: 10C553A3
	v_fmac_f32_e32 v166, v151, v166                            // 000000D8DAA8: 574D4D97
	v_div_scale_f32 v130, s5, v74, v141, v74                   // 000000D8DAAC: D6FC0582 052B1B4A
	v_mul_f32_e32 v26, v82, v26                                // 000000D8DAB4: 10343552
	v_fma_f32 v82, -v158, v9, v162                             // 000000D8DAB8: D6130052 268A139E
	v_mul_f32_e32 v122, v148, v165                             // 000000D8DAC0: 10F54B94
	v_div_fixup_f32 v5, v5, v138, v42                          // 000000D8DAC4: D6270005 04AB1505
	v_fma_f32 v42, -v159, v98, v163                            // 000000D8DACC: D613002A 268EC59F
	v_mul_f32_e32 v138, v130, v166                             // 000000D8DAD4: 11154D82
	v_fmac_f32_e32 v9, v82, v168                               // 000000D8DAD8: 56135152
	v_fma_f32 v82, -v160, v122, v148                           // 000000D8DADC: D6130052 2652F5A0
	v_mul_f32_e32 v5, v66, v5                                  // 000000D8DAE4: 100A0B42
	v_fmac_f32_e32 v98, v42, v169                              // 000000D8DAE8: 56C5532A
	v_fma_f32 v42, -v161, v138, v130                           // 000000D8DAEC: D613002A 260B15A1
	v_fma_f32 v66, -v158, v9, v162                             // 000000D8DAF4: D6130042 268A139E
	v_fmac_f32_e32 v122, v82, v165                             // 000000D8DAFC: 56F54B52
	s_mov_b32 vcc_lo, s7                                       // 000000D8DB00: BEEA0007
	s_waitcnt vmcnt(10)                                        // 000000D8DB04: BF892BF7
	v_fma_mix_f32 v50, v114, v50, neg(0) op_sel_hi:[1,0,0]     // 000000D8DB08: CC200032 8A026572
	v_fmac_f32_e32 v138, v42, v166                             // 000000D8DB10: 57154D2A
	v_div_fmas_f32 v9, v66, v168, v9                           // 000000D8DB14: D6370009 04275142
	v_fma_f32 v66, -v159, v98, v163                            // 000000D8DB1C: D6130042 268EC59F
	v_fma_f32 v42, -v160, v122, v148                           // 000000D8DB24: D613002A 2652F5A0
	s_mov_b32 vcc_lo, s8                                       // 000000D8DB2C: BEEA0008
	v_fma_f32 v82, -v161, v138, v130                           // 000000D8DB30: D6130052 260B15A1
	s_waitcnt vmcnt(8)                                         // 000000D8DB38: BF8923F7
	v_fma_mix_f32 v10, v150, v10, neg(0) op_sel_hi:[1,0,0]     // 000000D8DB3C: CC20000A 8A021596
	v_div_fmas_f32 v66, v66, v169, v98                         // 000000D8DB44: D6370042 058B5342
	s_mov_b32 vcc_lo, s4                                       // 000000D8DB4C: BEEA0004
	v_div_fixup_f32 v9, v9, v140, v58                          // 000000D8DB50: D6270009 04EB1909
	v_div_fmas_f32 v42, v42, v165, v122                        // 000000D8DB58: D637002A 05EB4B2A
	s_mov_b32 vcc_lo, s5                                       // 000000D8DB60: BEEA0005
	v_div_fixup_f32 v18, v66, v139, v18                        // 000000D8DB64: D6270012 044B1742
	v_div_fmas_f32 v82, v82, v166, v138                        // 000000D8DB6C: D6370052 062B4D52
	v_fma_mix_f32 v66, v106, v146, neg(0) op_sel_hi:[1,0,0]    // 000000D8DB74: CC200042 8A03256A
	v_fma_mix_f32 v34, v149, v34, neg(0) op_sel_hi:[1,0,0]     // 000000D8DB7C: CC200022 8A024595
	v_div_fixup_f32 v42, v42, v142, v90                        // 000000D8DB84: D627002A 056B1D2A
	v_mul_f32_e32 v18, v50, v18                                // 000000D8DB8C: 10242532
	v_div_fixup_f32 v74, v82, v141, v74                        // 000000D8DB90: D627004A 052B1B52
	s_waitcnt vmcnt(0)                                         // 000000D8DB98: BF8903F7
	v_fma_mix_f32 v8, v157, v8, neg(0) op_sel_hi:[1,0,0]       // 000000D8DB9C: CC200008 8A02119D
	v_fma_mix_f32 v50, v171, v5, neg(0) op_sel_hi:[1,0,0]      // 000000D8DBA4: CC200032 8A020BAB
	v_mul_f32_e32 v9, v66, v9                                  // 000000D8DBAC: 10121342
	v_fma_mix_f32 v18, v173, v18, neg(0) op_sel_hi:[1,0,0]     // 000000D8DBB0: CC200012 8A0225AD
	v_mul_f32_e32 v10, v10, v74                                // 000000D8DBB8: 1014950A
	v_mul_f32_e32 v34, v34, v42                                // 000000D8DBBC: 10445522
	v_fma_mix_f32 v42, v7, v176, v8 op_sel_hi:[0,1,0]          // 000000D8DBC0: CC20002A 14236107
	v_fma_mix_f32 v58, v26, v170, v50 op_sel_hi:[0,1,0]        // 000000D8DBC8: CC20003A 14CB551A
	v_fma_mix_f32 v66, v9, v172, v18 op_sel_hi:[0,1,0]         // 000000D8DBD0: CC200042 144B5909
	v_fma_mix_f32 v10, v175, v10, neg(0) op_sel_hi:[1,0,0]     // 000000D8DBD8: CC20000A 8A0215AF
	v_fma_mix_f32 v7, v7, v176, -v8 op_sel_hi:[0,1,0]          // 000000D8DBE0: CC200007 94236107
	v_fma_mix_f32 v8, v26, v170, -v50 op_sel_hi:[0,1,0]        // 000000D8DBE8: CC200008 94CB551A
	v_fma_mix_f32 v9, v9, v172, -v18 op_sel_hi:[0,1,0]         // 000000D8DBF0: CC200009 944B5909
	v_add_f32_e32 v18, v42, v58                                // 000000D8DBF8: 0624752A
	v_fma_mix_f32 v74, v34, v174, v10 op_sel_hi:[0,1,0]        // 000000D8DBFC: CC20004A 142B5D22
	v_fma_mix_f32 v10, v34, v174, -v10 op_sel_hi:[0,1,0]       // 000000D8DC04: CC20000A 942B5D22
	v_sub_f32_e32 v34, v42, v58                                // 000000D8DC0C: 0844752A
	v_add_f32_e32 v42, v7, v8                                  // 000000D8DC10: 06541107
	s_delay_alu instid0(VALU_DEP_4)                            // 000000D8DC14: BF870004
	v_dual_sub_f32 v7, v7, v8 :: v_dual_add_f32 v26, v66, v74  // 000000D8DC18: C9481107 071A9542
	v_sub_f32_e32 v50, v66, v74                                // 000000D8DC20: 08649542
	v_add_f32_e32 v58, v9, v10                                 // 000000D8DC24: 06741509
	v_sub_f32_e32 v9, v9, v10                                  // 000000D8DC28: 08121509
	.long 0xd7000404                                           // 000000D8DC2C: D7000404
	v_cndmask_b32_e32 v1, s10, v4, vcc_lo                      // 000000D8DC30: 0202080A
	v_add_f32_e32 v8, v18, v26                                 // 000000D8DC34: 06103512
	v_sub_f32_e32 v10, v18, v26                                // 000000D8DC38: 08143512
	v_add_f32_e32 v26, v42, v58                                // 000000D8DC3C: 0634752A
	v_sub_f32_e32 v42, v42, v58                                // 000000D8DC40: 0854752A
	v_add_f32_e32 v58, v34, v50                                // 000000D8DC44: 06746522
	v_mov_b32_dpp v18, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D8DC48: 7E2402FA FF016108
	v_cndmask_b32_e64 v8, -v8, v8, s0                          // 000000D8DC50: D5010008 20021108
	v_sub_f32_e32 v34, v34, v50                                // 000000D8DC58: 08446522
	v_mov_b32_dpp v82, v10 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D8DC5C: 7EA402FA FF01610A
	v_mov_b32_dpp v50, v58 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D8DC64: 7E6402FA FF01613A
	v_cndmask_b32_e64 v58, -v58, v58, s0                       // 000000D8DC6C: D501003A 2002753A
	v_add_f32_e32 v8, v8, v18                                  // 000000D8DC74: 06102508
	v_mov_b32_dpp v18, v26 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D8DC78: 7E2402FA FF01611A
	v_cndmask_b32_e64 v26, -v26, v26, s0                       // 000000D8DC80: D501001A 2002351A
	v_cndmask_b32_e64 v10, -v10, v10, s0                       // 000000D8DC88: D501000A 2002150A
	v_add_f32_e32 v50, v58, v50                                // 000000D8DC90: 0664653A
	v_mov_b32_dpp v66, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D8DC94: 7E8402FA FF016208
	v_cndmask_b32_e64 v8, -v8, v8, s1                          // 000000D8DC9C: D5010008 20061108
	v_add_f32_e32 v18, v26, v18                                // 000000D8DCA4: 0624251A
	v_add_f32_e32 v26, v7, v9                                  // 000000D8DCA8: 06341307
	v_sub_f32_e32 v58, v7, v9                                  // 000000D8DCAC: 08741307
	v_mov_b32_dpp v90, v42 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D8DCB0: 7EB402FA FF01612A
	v_add_f32_e32 v7, v8, v66                                  // 000000D8DCB8: 060E8508
	v_mov_b32_dpp v8, v18 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D8DCBC: 7E1002FA FF016212
	v_cndmask_b32_e64 v9, -v18, v18, s1                        // 000000D8DCC4: D5010009 20062512
	v_mov_b32_dpp v18, v50 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D8DCCC: 7E2402FA FF016232
	v_cndmask_b32_e64 v50, -v50, v50, s1                       // 000000D8DCD4: D5010032 20066532
	v_mov_b32_dpp v66, v26 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D8DCDC: 7E8402FA FF01611A
	v_cndmask_b32_e64 v26, -v26, v26, s0                       // 000000D8DCE4: D501001A 2002351A
	v_cndmask_b32_e64 v42, -v42, v42, s0                       // 000000D8DCEC: D501002A 2002552A
	v_mov_b32_dpp v98, v34 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D8DCF4: 7EC402FA FF016122
	v_add_f32_e32 v18, v50, v18                                // 000000D8DCFC: 06242532
	v_cndmask_b32_e64 v34, -v34, v34, s0                       // 000000D8DD00: D5010022 20024522
	v_add_f32_e32 v26, v26, v66                                // 000000D8DD08: 0634851A
	v_mov_b32_dpp v106, v58 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D8DD0C: 7ED402FA FF01613A
	v_cndmask_b32_e64 v58, -v58, v58, s0                       // 000000D8DD14: D501003A 2002753A
	v_mov_b32_dpp v66, v18 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D8DD1C: 7E8402FA FF016412
	v_cndmask_b32_e64 v18, -v18, v18, s2                       // 000000D8DD24: D5010012 200A2512
	v_add_f32_e32 v8, v9, v8                                   // 000000D8DD2C: 06101109
	v_add_f32_e32 v42, v42, v90                                // 000000D8DD30: 0654B52A
	v_add_f32_e32 v34, v34, v98                                // 000000D8DD34: 0644C522
	v_add_f32_e32 v58, v58, v106                               // 000000D8DD38: 0674D53A
	v_add_f32_e32 v18, v18, v66                                // 000000D8DD3C: 06248512
	v_add_f32_e32 v66, v10, v82                                // 000000D8DD40: 0684A50A
	v_mov_b32_dpp v9, v7 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D8DD44: 7E1202FA FF016407
	v_cndmask_b32_e64 v7, -v7, v7, s2                          // 000000D8DD4C: D5010007 200A0F07
	v_mov_b32_dpp v50, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D8DD54: 7E6402FA FF016408
	v_cndmask_b32_e64 v8, -v8, v8, s2                          // 000000D8DD5C: D5010008 200A1108
	v_mov_b32_dpp v82, v66 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D8DD64: 7EA402FA FF016242
	v_cndmask_b32_e64 v66, -v66, v66, s1                       // 000000D8DD6C: D5010042 20068542
	v_mov_b32_dpp v74, v26 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D8DD74: 7E9402FA FF01621A
	v_cndmask_b32_e64 v26, -v26, v26, s1                       // 000000D8DD7C: D501001A 2006351A
	v_mov_b32_dpp v90, v34 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D8DD84: 7EB402FA FF016222
	v_cndmask_b32_e64 v34, -v34, v34, s1                       // 000000D8DD8C: D5010022 20064522
	v_add_f32_e32 v66, v66, v82                                // 000000D8DD94: 0684A542
	v_mov_b32_dpp v82, v42 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D8DD98: 7EA402FA FF01622A
	v_cndmask_b32_e64 v42, -v42, v42, s1                       // 000000D8DDA0: D501002A 2006552A
	v_mov_b32_dpp v98, v58 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D8DDA8: 7EC402FA FF01623A
	v_cndmask_b32_e64 v58, -v58, v58, s1                       // 000000D8DDB0: D501003A 2006753A
	v_add_f32_e32 v7, v7, v9                                   // 000000D8DDB8: 060E1307
	v_add_f32_e32 v9, v8, v50                                  // 000000D8DDBC: 06126508
	v_add_f32_e32 v50, v26, v74                                // 000000D8DDC0: 0664951A
	v_add_f32_e32 v42, v42, v82                                // 000000D8DDC4: 0654A52A
	v_add_f32_e32 v34, v34, v90                                // 000000D8DDC8: 0644B522
	v_add_f32_e32 v58, v58, v98                                // 000000D8DDCC: 0674C53A
	v_mov_b32_dpp v82, v66 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D8DDD0: 7EA402FA FF016442
	v_mov_b32_dpp v74, v50 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D8DDD8: 7E9402FA FF016432
	v_cndmask_b32_e64 v50, -v50, v50, s2                       // 000000D8DDE0: D5010032 200A6532
	v_cndmask_b32_e64 v66, -v66, v66, s2                       // 000000D8DDE8: D5010042 200A8542
	v_mov_b32_dpp v90, v42 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D8DDF0: 7EB402FA FF01642A
	v_cndmask_b32_e64 v42, -v42, v42, s2                       // 000000D8DDF8: D501002A 200A552A
	v_mov_b32_dpp v98, v34 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D8DE00: 7EC402FA FF016422
	v_cndmask_b32_e64 v106, -v34, v34, s2                      // 000000D8DE08: D501006A 200A4522
	v_mov_b32_dpp v114, v58 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D8DE10: 7EE402FA FF01643A
	v_cndmask_b32_e64 v122, -v58, v58, s2                      // 000000D8DE18: D501007A 200A753A
	v_add_f32_e32 v34, v50, v74                                // 000000D8DE20: 06449532
	v_add_f32_e32 v58, v66, v82                                // 000000D8DE24: 0674A542
	v_add_f32_e32 v66, v42, v90                                // 000000D8DE28: 0684B52A
	v_add_f32_e32 v82, v106, v98                               // 000000D8DE2C: 06A4C56A
	v_add_f32_e32 v98, v122, v114                              // 000000D8DE30: 06C4E57A
	v_add_co_ci_u32_e64 v5, null, s11, 0, s4                   // 000000D8DE34: D5207C05 0011000B
	v_mov_b32_dpp v8, v7 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D8DE3C: 7E1002FA FF016807
	v_mov_b32_dpp v10, v9 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D8DE44: 7E1402FA FF016809
	v_mov_b32_dpp v26, v18 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D8DE4C: 7E3402FA FF016812
	v_mov_b32_dpp v42, v34 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D8DE54: 7E5402FA FF016822
	v_mov_b32_dpp v50, v58 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D8DE5C: 7E6402FA FF01683A
	v_mov_b32_dpp v74, v66 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D8DE64: 7E9402FA FF016842
	v_mov_b32_dpp v90, v82 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D8DE6C: 7EB402FA FF016852
	v_mov_b32_dpp v106, v98 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D8DE74: 7ED402FA FF016862
	s_mov_b32 s5, 0x3db504f3                                   // 000000D8DE7C: BE8500FF 3DB504F3
	s_mov_b32 s4, exec_lo                                      // 000000D8DE84: BE84007E
	.long 0xd4c4007e                                           // 000000D8DE88: D4C4007E
	v_cndmask_b32_e32 v1, s23, v6, vcc_lo                      // 000000D8DE8C: 02020C17
	s_cbranch_execz 60                                         // 000000D8DE90: BFA5003C <_ZN7halogen12_GLOBAL__N_111k_ht_moe_guILi3ELi8ELi1EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_S5_PDF16_+0x1c84>
	v_cndmask_b32_e64 v98, -v98, v98, s3                       // 000000D8DE94: D5010062 200EC562
	v_cndmask_b32_e64 v7, -v7, v7, s3                          // 000000D8DE9C: D5010007 200E0F07
	v_cndmask_b32_e64 v9, -v9, v9, s3                          // 000000D8DEA4: D5010009 200E1309
	v_cndmask_b32_e64 v18, -v18, v18, s3                       // 000000D8DEAC: D5010012 200E2512
	v_cndmask_b32_e64 v34, -v34, v34, s3                       // 000000D8DEB4: D5010022 200E4522
	v_cndmask_b32_e64 v58, -v58, v58, s3                       // 000000D8DEBC: D501003A 200E753A
	v_cndmask_b32_e64 v82, -v82, v82, s3                       // 000000D8DEC4: D5010052 200EA552
	v_cndmask_b32_e64 v66, -v66, v66, s3                       // 000000D8DECC: D5010042 200E8542
	v_dual_add_f32 v98, v98, v106 :: v_dual_add_f32 v7, v7, v8 // 000000D8DED4: C908D562 62061107
	v_add_f32_e32 v8, v9, v10                                  // 000000D8DEDC: 06101509
	v_add_f32_e32 v9, v18, v26                                 // 000000D8DEE0: 06123512
	v_mad_i64_i32 v[138:139], null, 0x500, v6, v[0:1]          // 000000D8DEE4: D6FF7C8A 04020CFF 00000500
	v_add_f32_e32 v10, v34, v42                                // 000000D8DEF0: 06145522
	v_add_f32_e32 v50, v58, v50                                // 000000D8DEF4: 0664653A
	v_add_f32_e32 v82, v82, v90                                // 000000D8DEF8: 06A4B552
	v_add_f32_e32 v66, v66, v74                                // 000000D8DEFC: 06849542
	v_fma_mixlo_f16 v7, v7, s5, 0                              // 000000D8DF00: CC210007 02000B07
	v_fma_mixhi_f16 v7, v8, s5, 0                              // 000000D8DF08: CC220007 02000B08
	v_fma_mixlo_f16 v8, v9, s5, 0                              // 000000D8DF10: CC210008 02000B09
	v_fma_mixhi_f16 v8, v10, s5, 0                             // 000000D8DF18: CC220008 02000B0A
	v_fma_mixlo_f16 v9, v50, s5, 0                             // 000000D8DF20: CC210009 02000B32
	v_fma_mixhi_f16 v9, v66, s5, 0                             // 000000D8DF28: CC220009 02000B42
	v_fma_mixlo_f16 v10, v82, s5, 0                            // 000000D8DF30: CC21000A 02000B52
	v_fma_mixhi_f16 v10, v98, s5, 0                            // 000000D8DF38: CC22000A 02000B62
	s_clause 0x7                                               // 000000D8DF40: BF850007
	global_store_b16 v[138:139], v7, off                       // 000000D8DF44: DC660000 007C078A
	global_store_d16_hi_b16 v[138:139], v7, off offset:32      // 000000D8DF4C: DC960020 007C078A
	global_store_b16 v[138:139], v8, off offset:64             // 000000D8DF54: DC660040 007C088A
	global_store_d16_hi_b16 v[138:139], v8, off offset:96      // 000000D8DF5C: DC960060 007C088A
	global_store_b16 v[138:139], v9, off offset:128            // 000000D8DF64: DC660080 007C098A
	global_store_d16_hi_b16 v[138:139], v9, off offset:160     // 000000D8DF6C: DC9600A0 007C098A
	global_store_b16 v[138:139], v10, off offset:192           // 000000D8DF74: DC6600C0 007C0A8A
	global_store_d16_hi_b16 v[138:139], v10, off offset:224    // 000000D8DF7C: DC9600E0 007C0A8A
	s_or_b32 exec_lo, exec_lo, s4                              // 000000D8DF84: 8C7E047E
	s_clause 0xb                                               // 000000D8DF88: BF85000B
	global_load_d16_b16 v7, v[2:3], off offset:1280            // 000000D8DF8C: DC820500 077C0002
	global_load_d16_b16 v10, v[2:3], off offset:1312           // 000000D8DF94: DC820520 0A7C0002
	global_load_d16_b16 v8, v[2:3], off                        // 000000D8DF9C: DC820000 087C0002
	global_load_d16_b16 v9, v[2:3], off offset:32              // 000000D8DFA4: DC820020 097C0002
	global_load_d16_b16 v18, v[2:3], off offset:64             // 000000D8DFAC: DC820040 127C0002
	global_load_d16_b16 v26, v[2:3], off offset:96             // 000000D8DFB4: DC820060 1A7C0002
	global_load_d16_b16 v42, v[2:3], off offset:128            // 000000D8DFBC: DC820080 2A7C0002
	global_load_d16_b16 v50, v[2:3], off offset:160            // 000000D8DFC4: DC8200A0 327C0002
	global_load_d16_b16 v74, v[2:3], off offset:192            // 000000D8DFCC: DC8200C0 4A7C0002
	global_load_d16_b16 v82, v[2:3], off offset:224            // 000000D8DFD4: DC8200E0 527C0002
	global_load_d16_b16 v58, v[2:3], off offset:1344           // 000000D8DFDC: DC820540 3A7C0002
	global_load_d16_b16 v66, v[2:3], off offset:1376           // 000000D8DFE4: DC820560 427C0002
	v_add_f32_e32 v90, v131, v123                              // 000000D8DFEC: 06B4F783
	v_add_f32_e32 v106, v115, v107                             // 000000D8DFF0: 06D4D773
	v_sub_f32_e32 v98, v131, v123                              // 000000D8DFF4: 08C4F783
	v_sub_f32_e32 v107, v115, v107                             // 000000D8DFF8: 08D6D773
	v_add_f32_e32 v114, v99, v91                               // 000000D8DFFC: 06E4B763
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D8E000: BF870224
	v_dual_sub_f32 v122, v19, v11 :: v_dual_add_f32 v143, v90, v106// 000000D8E004: C9481713 7A8ED55A
	v_sub_f32_e32 v90, v90, v106                               // 000000D8E00C: 08B4D55A
	v_add_f32_e32 v106, v98, v107                              // 000000D8E010: 06D4D762
	v_sub_f32_e32 v91, v99, v91                                // 000000D8E014: 08B6B763
	v_add_f32_e32 v99, v83, v75                                // 000000D8E018: 06C69753
	v_sub_f32_e32 v98, v98, v107                               // 000000D8E01C: 08C4D762
	v_sub_f32_e32 v75, v83, v75                                // 000000D8E020: 08969753
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000D8E024: BF8701A3
	v_add_f32_e32 v107, v114, v99                              // 000000D8E028: 06D6C772
	v_sub_f32_e32 v99, v114, v99                               // 000000D8E02C: 08C6C772
	v_add_f32_e32 v114, v91, v75                               // 000000D8E030: 06E4975B
	v_sub_f32_e32 v75, v91, v75                                // 000000D8E034: 0896975B
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000D8E038: BF8700A3
	v_add_f32_e32 v146, v90, v99                               // 000000D8E03C: 0724C75A
	v_sub_f32_e32 v90, v90, v99                                // 000000D8E040: 08B4C75A
	v_mov_b32_dpp v157, v90 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D8E044: 7F3A02FA FF01615A
	v_cndmask_b32_e64 v90, -v90, v90, s0                       // 000000D8E04C: D501005A 2002B55A
	v_add_f32_e32 v83, v67, v59                                // 000000D8E054: 06A67743
	v_sub_f32_e32 v59, v67, v59                                // 000000D8E058: 08767743
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D8E05C: BF870093
	v_dual_add_f32 v67, v51, v43 :: v_dual_add_f32 v90, v90, v157// 000000D8E060: C9085733 435B3B5A
	v_add_f32_e32 v91, v83, v67                                // 000000D8E068: 06B68753
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000D8E06C: BF8701C2
	v_mov_b32_dpp v157, v90 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D8E070: 7F3A02FA FF01625A
	v_cndmask_b32_e64 v90, -v90, v90, s1                       // 000000D8E078: D501005A 2006B55A
	v_sub_f32_e32 v43, v51, v43                                // 000000D8E080: 08565733
	v_add_f32_e32 v51, v35, v27                                // 000000D8E084: 06663723
	v_dual_sub_f32 v35, v35, v27 :: v_dual_add_f32 v90, v90, v157// 000000D8E088: C9483723 235B3B5A
	s_delay_alu instid0(VALU_DEP_1)                            // 000000D8E090: BF870001
	v_mov_b32_dpp v157, v90 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D8E094: 7F3A02FA FF01645A
	v_cndmask_b32_e64 v90, -v90, v90, s2                       // 000000D8E09C: D501005A 200AB55A
	v_add_f32_e32 v115, v19, v11                               // 000000D8E0A4: 06E61713
	s_clause 0x3                                               // 000000D8E0A8: BF850003
	global_load_d16_b16 v19, v[2:3], off offset:1408           // 000000D8E0AC: DC820580 137C0002
	global_load_d16_b16 v27, v[2:3], off offset:1440           // 000000D8E0B4: DC8205A0 1B7C0002
	global_load_d16_b16 v11, v[2:3], off offset:1472           // 000000D8E0BC: DC8205C0 0B7C0002
	global_load_d16_b16 v34, v[2:3], off offset:1504           // 000000D8E0C4: DC8205E0 227C0002
	s_clause 0x7                                               // 000000D8E0CC: BF850007
	global_load_d16_b16 v123, v[4:5], off offset:32            // 000000D8E0D0: DC820020 7B7C0004
	global_load_d16_b16 v130, v[4:5], off offset:96            // 000000D8E0D8: DC820060 827C0004
	global_load_d16_b16 v131, v[4:5], off offset:160           // 000000D8E0E0: DC8200A0 837C0004
	global_load_d16_b16 v138, v[4:5], off offset:224           // 000000D8E0E8: DC8200E0 8A7C0004
	global_load_d16_b16 v139, v[4:5], off offset:192           // 000000D8E0F0: DC8200C0 8B7C0004
	global_load_d16_b16 v140, v[4:5], off offset:128           // 000000D8E0F8: DC820080 8C7C0004
	global_load_d16_b16 v141, v[4:5], off offset:64            // 000000D8E100: DC820040 8D7C0004
	global_load_d16_b16 v142, v[4:5], off                      // 000000D8E108: DC820000 8E7C0004
	v_add_f32_e32 v90, v90, v157                               // 000000D8E110: 06B53B5A
	v_add_f32_e32 v144, v51, v115                              // 000000D8E114: 0720E733
	v_sub_f32_e32 v51, v51, v115                               // 000000D8E118: 0866E733
	s_delay_alu instid0(VALU_DEP_3)                            // 000000D8E11C: BF870003
	v_mov_b32_dpp v157, v90 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D8E120: 7F3A02FA FF01685A
	v_cndmask_b32_e64 v90, -v90, v90, s3                       // 000000D8E128: D501005A 200EB55A
	v_sub_f32_e32 v67, v83, v67                                // 000000D8E130: 08868753
	v_add_f32_e32 v83, v59, v43                                // 000000D8E134: 06A6573B
	v_sub_f32_e32 v43, v59, v43                                // 000000D8E138: 0856573B
	v_add_f32_e32 v59, v35, v122                               // 000000D8E13C: 0676F523
	v_dual_sub_f32 v35, v35, v122 :: v_dual_add_f32 v90, v90, v157// 000000D8E140: C948F523 235B3B5A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D8E148: BF870112
	v_add_f32_e32 v122, v83, v59                               // 000000D8E14C: 06F47753
	v_dual_sub_f32 v59, v83, v59 :: v_dual_mul_f32 v90, 0x3db504f3, v90// 000000D8E150: C9467753 3B5AB4FF 3DB504F3
	v_add_f32_e32 v83, v67, v51                                // 000000D8E15C: 06A66743
	v_sub_f32_e32 v51, v67, v51                                // 000000D8E160: 08666743
	v_add_f32_e32 v67, v43, v35                                // 000000D8E164: 0686472B
	v_sub_f32_e32 v35, v43, v35                                // 000000D8E168: 0846472B
	v_add_f32_e32 v43, v106, v114                              // 000000D8E16C: 0656E56A
	v_sub_f32_e32 v106, v106, v114                             // 000000D8E170: 08D4E56A
	v_mov_b32_dpp v114, v122 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D8E174: 7EE402FA FF01617A
	v_mov_b32_dpp v148, v59 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D8E17C: 7F2802FA FF01613B
	v_cndmask_b32_e64 v59, -v59, v59, s0                       // 000000D8E184: D501003B 2002773B
	v_mov_b32_dpp v152, v43 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D8E18C: 7F3002FA FF01612B
	v_cndmask_b32_e64 v43, -v43, v43, s0                       // 000000D8E194: D501002B 2002572B
	v_mov_b32_dpp v156, v106 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D8E19C: 7F3802FA FF01616A
	v_cndmask_b32_e64 v106, -v106, v106, s0                    // 000000D8E1A4: D501006A 2002D56A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D8E1AC: BF870113
	v_add_f32_e32 v43, v43, v152                               // 000000D8E1B0: 0657312B
	v_add_f32_e32 v106, v106, v156                             // 000000D8E1B4: 06D5396A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000D8E1B8: BF8701A2
	v_mov_b32_dpp v152, v43 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D8E1BC: 7F3002FA FF01622B
	v_cndmask_b32_e64 v43, -v43, v43, s1                       // 000000D8E1C4: D501002B 2006572B
	v_mov_b32_dpp v156, v106 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D8E1CC: 7F3802FA FF01626A
	v_cndmask_b32_e64 v106, -v106, v106, s1                    // 000000D8E1D4: D501006A 2006D56A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D8E1DC: BF870113
	v_add_f32_e32 v43, v43, v152                               // 000000D8E1E0: 0657312B
	v_add_f32_e32 v106, v106, v156                             // 000000D8E1E4: 06D5396A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000D8E1E8: BF8701A2
	v_mov_b32_dpp v152, v43 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D8E1EC: 7F3002FA FF01642B
	v_cndmask_b32_e64 v43, -v43, v43, s2                       // 000000D8E1F4: D501002B 200A572B
	v_mov_b32_dpp v156, v106 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D8E1FC: 7F3802FA FF01646A
	v_cndmask_b32_e64 v106, -v106, v106, s2                    // 000000D8E204: D501006A 200AD56A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D8E20C: BF870113
	v_add_f32_e32 v43, v43, v152                               // 000000D8E210: 0657312B
	v_add_f32_e32 v106, v106, v156                             // 000000D8E214: 06D5396A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000D8E218: BF8701A2
	v_mov_b32_dpp v152, v43 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D8E21C: 7F3002FA FF01682B
	v_cndmask_b32_e64 v43, -v43, v43, s3                       // 000000D8E224: D501002B 200E572B
	v_mov_b32_dpp v156, v106 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D8E22C: 7F3802FA FF01686A
	v_cndmask_b32_e64 v106, -v106, v106, s3                    // 000000D8E234: D501006A 200ED56A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D8E23C: BF870113
	v_add_f32_e32 v43, v43, v152                               // 000000D8E240: 0657312B
	v_add_f32_e32 v106, v106, v156                             // 000000D8E244: 06D5396A
	v_add_f32_e32 v115, v91, v144                              // 000000D8E248: 06E7215B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D8E24C: BF870112
	v_dual_mul_f32 v43, 0x3db504f3, v43 :: v_dual_mul_f32 v106, 0x3db504f3, v106// 000000D8E250: C8C656FF 2B6AD4FF 3DB504F3
	v_cndmask_b32_e64 v99, -v115, v115, s0                     // 000000D8E25C: D5010063 2002E773
	s_waitcnt vmcnt(20)                                        // 000000D8E264: BF8953F7
	s_delay_alu instid0(VALU_DEP_2)                            // 000000D8E268: BF870002
	v_fma_mix_f32 v9, v9, v43, neg(0) op_sel_hi:[1,0,0]        // 000000D8E26C: CC200009 8A025709
	s_waitcnt vmcnt(16)                                        // 000000D8E274: BF8943F7
	v_fma_mix_f32 v43, v50, v106, neg(0) op_sel_hi:[1,0,0]     // 000000D8E278: CC20002B 8A02D532
	s_waitcnt vmcnt(15)                                        // 000000D8E280: BF893FF7
	v_fma_mix_f32 v50, v74, v90, neg(0) op_sel_hi:[1,0,0]      // 000000D8E284: CC200032 8A02B54A
	v_add_f32_e32 v145, v98, v75                               // 000000D8E28C: 07229762
	v_sub_f32_e32 v75, v98, v75                                // 000000D8E290: 08969762
	v_mov_b32_dpp v98, v115 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D8E294: 7EC402FA FF016173
	v_cndmask_b32_e64 v115, -v122, v122, s0                    // 000000D8E29C: D5010073 2002F57A
	v_mov_b32_dpp v122, v83 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D8E2A4: 7EF402FA FF016153
	v_mov_b32_dpp v154, v145 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D8E2AC: 7F3402FA FF016191
	v_cndmask_b32_e64 v145, -v145, v145, s0                    // 000000D8E2B4: D5010091 20032391
	v_mov_b32_dpp v158, v75 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D8E2BC: 7F3C02FA FF01614B
	v_cndmask_b32_e64 v75, -v75, v75, s0                       // 000000D8E2C4: D501004B 2002974B
	v_add_f32_e32 v98, v99, v98                                // 000000D8E2CC: 06C4C563
	v_add_f32_e32 v99, v115, v114                              // 000000D8E2D0: 06C6E573
	v_add_f32_e32 v115, v145, v154                             // 000000D8E2D4: 06E73591
	v_cndmask_b32_e64 v83, -v83, v83, s0                       // 000000D8E2D8: D5010053 2002A753
	v_add_f32_e32 v75, v75, v158                               // 000000D8E2E0: 06973D4B
	v_mov_b32_dpp v153, v146 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D8E2E4: 7F3202FA FF016192
	v_cndmask_b32_e64 v146, -v146, v146, s0                    // 000000D8E2EC: D5010092 20032592
	v_mov_b32_dpp v154, v115 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D8E2F4: 7F3402FA FF016273
	v_cndmask_b32_e64 v115, -v115, v115, s1                    // 000000D8E2FC: D5010073 2006E773
	v_mov_b32_dpp v158, v75 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D8E304: 7F3C02FA FF01624B
	v_cndmask_b32_e64 v75, -v75, v75, s1                       // 000000D8E30C: D501004B 2006974B
	v_dual_add_f32 v83, v83, v122 :: v_dual_add_f32 v122, v146, v153// 000000D8E314: C908F553 537B3392
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D8E31C: BF870194
	v_add_f32_e32 v115, v115, v154                             // 000000D8E320: 06E73573
	v_add_f32_e32 v75, v75, v158                               // 000000D8E324: 06973D4B
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D8E328: BF870223
	v_mov_b32_dpp v145, v83 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D8E32C: 7F2202FA FF016253
	v_cndmask_b32_e64 v83, -v83, v83, s1                       // 000000D8E334: D5010053 2006A753
	v_mov_b32_dpp v154, v115 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D8E33C: 7F3402FA FF016473
	v_cndmask_b32_e64 v115, -v115, v115, s2                    // 000000D8E344: D5010073 200AE773
	v_mov_b32_dpp v158, v75 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D8E34C: 7F3C02FA FF01644B
	v_cndmask_b32_e64 v75, -v75, v75, s2                       // 000000D8E354: D501004B 200A974B
	v_add_f32_e32 v83, v83, v145                               // 000000D8E35C: 06A72353
	v_mov_b32_dpp v153, v122 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D8E360: 7F3202FA FF01627A
	v_add_f32_e32 v115, v115, v154                             // 000000D8E368: 06E73573
	v_cndmask_b32_e64 v122, -v122, v122, s1                    // 000000D8E36C: D501007A 2006F57A
	v_add_f32_e32 v75, v75, v158                               // 000000D8E374: 06973D4B
	v_mov_b32_dpp v145, v83 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D8E378: 7F2202FA FF016453
	v_cndmask_b32_e64 v83, -v83, v83, s2                       // 000000D8E380: D5010053 200AA753
	v_mov_b32_dpp v154, v115 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D8E388: 7F3402FA FF016873
	v_cndmask_b32_e64 v115, -v115, v115, s3                    // 000000D8E390: D5010073 200EE773
	v_mov_b32_dpp v158, v75 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D8E398: 7F3C02FA FF01684B
	v_cndmask_b32_e64 v75, -v75, v75, s3                       // 000000D8E3A0: D501004B 200E974B
	v_add_f32_e32 v83, v83, v145                               // 000000D8E3A8: 06A72353
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D8E3AC: BF870194
	v_dual_add_f32 v122, v122, v153 :: v_dual_add_f32 v115, v115, v154// 000000D8E3B0: C909337A 7A733573
	v_add_f32_e32 v75, v75, v158                               // 000000D8E3B8: 06973D4B
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D8E3BC: BF870223
	v_mov_b32_dpp v145, v83 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D8E3C0: 7F2202FA FF016853
	v_cndmask_b32_e64 v83, -v83, v83, s3                       // 000000D8E3C8: D5010053 200EA753
	v_mul_f32_e32 v115, 0x3db504f3, v115                       // 000000D8E3D0: 10E6E6FF 3DB504F3
	v_mov_b32_dpp v153, v122 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D8E3D8: 7F3202FA FF01647A
	v_mul_f32_e32 v75, 0x3db504f3, v75                         // 000000D8E3E0: 109696FF 3DB504F3
	v_cndmask_b32_e64 v122, -v122, v122, s2                    // 000000D8E3E8: D501007A 200AF57A
	v_add_f32_e32 v83, v83, v145                               // 000000D8E3F0: 06A72353
	v_fma_mix_f32 v26, v26, v115, neg(0) op_sel_hi:[1,0,0]     // 000000D8E3F4: CC20001A 8A02E71A
	s_waitcnt vmcnt(14)                                        // 000000D8E3FC: BF893BF7
	v_fma_mix_f32 v74, v82, v75, neg(0) op_sel_hi:[1,0,0]      // 000000D8E400: CC20004A 8A029752
	v_mul_f32_e32 v75, 0xbfb8aa3b, v9                          // 000000D8E408: 109612FF BFB8AA3B
	v_mul_f32_e32 v83, 0x3db504f3, v83                         // 000000D8E410: 10A6A6FF 3DB504F3
	v_mul_f32_e32 v90, 0xbfb8aa3b, v26                         // 000000D8E418: 10B434FF BFB8AA3B
	v_mov_b32_dpp v149, v51 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D8E420: 7F2A02FA FF016133
	v_cndmask_b32_e64 v51, -v51, v51, s0                       // 000000D8E428: D5010033 20026733
	v_exp_f32_e32 v75, v75                                     // 000000D8E430: 7E964B4B
	s_waitcnt vmcnt(13)                                        // 000000D8E434: BF8937F7
	v_fma_mix_f32 v58, v58, v83, neg(0) op_sel_hi:[1,0,0]      // 000000D8E438: CC20003A 8A02A73A
	v_exp_f32_e32 v90, v90                                     // 000000D8E440: 7EB44B5A
	v_add_f32_e32 v122, v122, v153                             // 000000D8E444: 06F5337A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(TRANS32_DEP_2)// 000000D8E448: BF870321
	v_mov_b32_dpp v153, v122 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D8E44C: 7F3202FA FF01687A
	v_cndmask_b32_e64 v122, -v122, v122, s3                    // 000000D8E454: D501007A 200EF57A
	v_add_f32_e32 v75, 1.0, v75                                // 000000D8E45C: 069696F2
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000D8E460: BF870235
	v_add_f32_e32 v83, 1.0, v90                                // 000000D8E464: 06A6B4F2
	v_sub_f32_e32 v91, v91, v144                               // 000000D8E468: 08B7215B
	v_add_f32_e32 v144, v143, v107                             // 000000D8E46C: 0720D78F
	v_div_scale_f32 v115, null, v75, v75, v9                   // 000000D8E470: D6FC7C73 0426974B
	v_sub_f32_e32 v107, v143, v107                             // 000000D8E478: 08D6D78F
	v_mov_b32_dpp v143, v67 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D8E47C: 7F1E02FA FF016143
	v_cndmask_b32_e64 v67, -v67, v67, s0                       // 000000D8E484: D5010043 20028743
	v_mov_b32_dpp v151, v144 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D8E48C: 7F2E02FA FF016190
	v_cndmask_b32_e64 v144, -v144, v144, s0                    // 000000D8E494: D5010090 20032190
	v_rcp_f32_e32 v154, v115                                   // 000000D8E49C: 7F345573
	v_add_f32_e32 v122, v122, v153                             // 000000D8E4A0: 06F5337A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000D8E4A4: BF870232
	v_add_f32_e32 v114, v144, v151                             // 000000D8E4A8: 06E52F90
	v_mov_b32_dpp v144, v99 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D8E4AC: 7F2002FA FF016263
	v_cndmask_b32_e64 v99, -v99, v99, s1                       // 000000D8E4B4: D5010063 2006C763
	v_mul_f32_e32 v122, 0x3db504f3, v122                       // 000000D8E4BC: 10F4F4FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(TRANS32_DEP_1)// 000000D8E4C4: BF8702B4
	v_mov_b32_dpp v151, v114 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D8E4C8: 7F2E02FA FF016272
	v_cndmask_b32_e64 v114, -v114, v114, s1                    // 000000D8E4D0: D5010072 2006E572
	v_add_f32_e32 v59, v59, v148                               // 000000D8E4D8: 0677293B
	v_fma_f32 v164, -v115, v154, 1.0                           // 000000D8E4DC: D61300A4 23CB3573
	v_add_f32_e32 v67, v67, v143                               // 000000D8E4E4: 06871F43
	v_mov_b32_dpp v143, v98 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D8E4E8: 7F1E02FA FF016262
	v_cndmask_b32_e64 v98, -v98, v98, s1                       // 000000D8E4F0: D5010062 2006C562
	v_add_f32_e32 v114, v114, v151                             // 000000D8E4F8: 06E52F72
	v_fmac_f32_e32 v154, v164, v154                            // 000000D8E4FC: 573535A4
	v_mov_b32_dpp v146, v67 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D8E500: 7F2402FA FF016243
	v_cndmask_b32_e64 v67, -v67, v67, s1                       // 000000D8E508: D5010043 20068743
	v_add_f32_e32 v98, v98, v143                               // 000000D8E510: 06C51F62
	v_mov_b32_dpp v151, v114 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D8E514: 7F2E02FA FF016472
	v_cndmask_b32_e64 v114, -v114, v114, s2                    // 000000D8E51C: D5010072 200AE572
	v_fma_mix_f32 v18, v18, v122, neg(0) op_sel_hi:[1,0,0]     // 000000D8E524: CC200012 8A02F512
	v_add_f32_e32 v67, v67, v146                               // 000000D8E52C: 06872543
	v_mov_b32_dpp v143, v98 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D8E530: 7F1E02FA FF016462
	v_cndmask_b32_e64 v98, -v98, v98, s2                       // 000000D8E538: D5010062 200AC562
	v_dual_add_f32 v114, v114, v151 :: v_dual_add_f32 v51, v51, v149// 000000D8E540: C9092F72 72332B33
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D8E548: BF870224
	v_mov_b32_dpp v146, v67 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D8E54C: 7F2402FA FF016443
	v_cndmask_b32_e64 v67, -v67, v67, s2                       // 000000D8E554: D5010043 200A8743
	v_add_f32_e32 v98, v98, v143                               // 000000D8E55C: 06C51F62
	s_delay_alu instid0(VALU_DEP_4)                            // 000000D8E560: BF870004
	v_mov_b32_dpp v151, v114 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D8E564: 7F2E02FA FF016872
	v_cndmask_b32_e64 v114, -v114, v114, s3                    // 000000D8E56C: D5010072 200EE572
	v_add_f32_e32 v99, v99, v144                               // 000000D8E574: 06C72163
	v_add_f32_e32 v67, v67, v146                               // 000000D8E578: 06872543
	v_mov_b32_dpp v143, v98 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D8E57C: 7F1E02FA FF016862
	v_cndmask_b32_e64 v98, -v98, v98, s3                       // 000000D8E584: D5010062 200EC562
	v_add_f32_e32 v114, v114, v151                             // 000000D8E58C: 06E52F72
	v_mov_b32_dpp v144, v99 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D8E590: 7F2002FA FF016463
	v_mov_b32_dpp v146, v67 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D8E598: 7F2402FA FF016843
	v_cndmask_b32_e64 v67, -v67, v67, s3                       // 000000D8E5A0: D5010043 200E8743
	v_add_f32_e32 v98, v98, v143                               // 000000D8E5A8: 06C51F62
	v_mul_f32_e32 v114, 0x3db504f3, v114                       // 000000D8E5AC: 10E4E4FF 3DB504F3
	v_cndmask_b32_e64 v99, -v99, v99, s2                       // 000000D8E5B4: D5010063 200AC763
	v_mov_b32_dpp v148, v59 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D8E5BC: 7F2802FA FF01623B
	v_add_f32_e32 v67, v67, v146                               // 000000D8E5C4: 06872543
	v_mul_f32_e32 v98, 0x3db504f3, v98                         // 000000D8E5C8: 10C4C4FF 3DB504F3
	v_fma_mix_f32 v8, v8, v114, neg(0) op_sel_hi:[1,0,0]       // 000000D8E5D0: CC200008 8A02E508
	v_add_f32_e32 v99, v99, v144                               // 000000D8E5D8: 06C72163
	v_cndmask_b32_e64 v59, -v59, v59, s1                       // 000000D8E5DC: D501003B 2006773B
	v_mul_f32_e32 v67, 0x3db504f3, v67                         // 000000D8E5E4: 108686FF 3DB504F3
	v_fma_mix_f32 v7, v7, v98, neg(0) op_sel_hi:[1,0,0]        // 000000D8E5EC: CC200007 8A02C507
	v_mul_f32_e32 v82, 0xbfb8aa3b, v8                          // 000000D8E5F4: 10A410FF BFB8AA3B
	v_mul_f32_e32 v98, 0xbfb8aa3b, v18                         // 000000D8E5FC: 10C424FF BFB8AA3B
	v_mov_b32_dpp v144, v99 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D8E604: 7F2002FA FF016863
	s_waitcnt vmcnt(12)                                        // 000000D8E60C: BF8933F7
	v_fma_mix_f32 v66, v66, v67, neg(0) op_sel_hi:[1,0,0]      // 000000D8E610: CC200042 8A028742
	v_cndmask_b32_e64 v99, -v99, v99, s3                       // 000000D8E618: D5010063 200EC763
	v_exp_f32_e32 v82, v82                                     // 000000D8E620: 7EA44B52
	v_exp_f32_e32 v98, v98                                     // 000000D8E624: 7EC44B62
	v_mov_b32_dpp v147, v91 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D8E628: 7F2602FA FF01615B
	v_cndmask_b32_e64 v91, -v91, v91, s0                       // 000000D8E630: D501005B 2002B75B
	v_add_f32_e32 v99, v99, v144                               // 000000D8E638: 06C72163
	v_div_scale_f32 v144, null, v83, v83, v26                  // 000000D8E63C: D6FC7C90 046AA753
	v_mul_f32_e32 v114, 0xbfb8aa3b, v50                        // 000000D8E644: 10E464FF BFB8AA3B
	v_div_scale_f32 v122, s4, v9, v75, v9                      // 000000D8E64C: D6FC047A 04269709
	v_mov_b32_dpp v149, v51 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D8E654: 7F2A02FA FF016233
	v_mul_f32_e32 v99, 0x3db504f3, v99                         // 000000D8E65C: 10C6C6FF 3DB504F3
	v_add_f32_e32 v67, 1.0, v82                                // 000000D8E664: 0686A4F2
	v_add_f32_e32 v82, 1.0, v98                                // 000000D8E668: 06A4C4F2
	v_mov_b32_dpp v155, v107 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D8E66C: 7F3602FA FF01616B
	v_cndmask_b32_e64 v107, -v107, v107, s0                    // 000000D8E674: D501006B 2002D76B
	v_fma_mix_f32 v10, v10, v99, neg(0) op_sel_hi:[1,0,0]      // 000000D8E67C: CC20000A 8A02C70A
	v_mul_f32_e32 v99, 0xbfb8aa3b, v43                         // 000000D8E684: 10C656FF BFB8AA3B
	v_rcp_f32_e32 v156, v144                                   // 000000D8E68C: 7F385590
	v_cndmask_b32_e64 v51, -v51, v51, s1                       // 000000D8E690: D5010033 20066733
	v_add_f32_e32 v107, v107, v155                             // 000000D8E698: 06D7376B
	v_exp_f32_e32 v114, v114                                   // 000000D8E69C: 7EE44B72
	v_exp_f32_e32 v99, v99                                     // 000000D8E6A0: 7EC64B63
	v_mul_f32_e32 v164, v122, v154                             // 000000D8E6A4: 1149357A
	v_div_scale_f32 v143, null, v82, v82, v18                  // 000000D8E6A8: D6FC7C8F 044AA552
	v_mov_b32_dpp v155, v107 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D8E6B0: 7F3602FA FF01626B
	v_cndmask_b32_e64 v107, -v107, v107, s1                    // 000000D8E6B8: D501006B 2006D76B
	s_delay_alu instid0(TRANS32_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000D8E6C0: BF870237
	v_fma_f32 v166, -v144, v156, 1.0                           // 000000D8E6C4: D61300A6 23CB3990
	v_add_f32_e32 v91, v91, v147                               // 000000D8E6CC: 06B7275B
	v_fma_f32 v172, -v115, v164, v122                          // 000000D8E6D0: D61300AC 25EB4973
	v_add_f32_e32 v107, v107, v155                             // 000000D8E6D8: 06D7376B
	s_delay_alu instid0(TRANS32_DEP_1)                         // 000000D8E6DC: BF870005
	v_add_f32_e32 v98, 1.0, v99                                // 000000D8E6E0: 06C4C6F2
	v_fmac_f32_e32 v156, v166, v156                            // 000000D8E6E4: 573939A6
	v_mov_b32_dpp v147, v91 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D8E6E8: 7F2602FA FF01625B
	v_cndmask_b32_e64 v91, -v91, v91, s1                       // 000000D8E6F0: D501005B 2006B75B
	v_mov_b32_dpp v155, v107 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D8E6F8: 7F3602FA FF01646B
	v_cndmask_b32_e64 v107, -v107, v107, s2                    // 000000D8E700: D501006B 200AD76B
	v_add_f32_e32 v99, 1.0, v114                               // 000000D8E708: 06C6E4F2
	v_div_scale_f32 v114, vcc_lo, v8, v67, v8                  // 000000D8E70C: D6FC6A72 04228708
	v_dual_add_f32 v91, v91, v147 :: v_dual_fmac_f32 v164, v172, v154// 000000D8E714: C901275B 5BA535AC
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000D8E71C: BF870234
	v_add_f32_e32 v107, v107, v155                             // 000000D8E720: 06D7376B
	v_div_scale_f32 v146, null, v98, v98, v43                  // 000000D8E724: D6FC7C92 04AEC562
	v_div_scale_f32 v152, s8, v43, v98, v43                    // 000000D8E72C: D6FC0898 04AEC52B
	v_mov_b32_dpp v147, v91 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D8E734: 7F2602FA FF01645B
	v_cndmask_b32_e64 v91, -v91, v91, s2                       // 000000D8E73C: D501005B 200AB75B
	v_mov_b32_dpp v155, v107 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D8E744: 7F3602FA FF01686B
	v_cndmask_b32_e64 v107, -v107, v107, s3                    // 000000D8E74C: D501006B 200ED76B
	v_div_scale_f32 v161, s9, v50, v99, v50                    // 000000D8E754: D6FC09A1 04CAC732
	v_rcp_f32_e32 v158, v146                                   // 000000D8E75C: 7F3C5592
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000D8E760: BF8700A2
	v_add_f32_e32 v107, v107, v155                             // 000000D8E764: 06D7376B
	v_rcp_f32_e32 v155, v143                                   // 000000D8E768: 7F36558F
	v_mul_f32_e32 v107, 0x3db504f3, v107                       // 000000D8E76C: 10D6D6FF 3DB504F3
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D8E774: BF870116
	v_fma_f32 v168, -v146, v158, 1.0                           // 000000D8E778: D61300A8 23CB3D92
	v_fma_mix_f32 v42, v42, v107, neg(0) op_sel_hi:[1,0,0]     // 000000D8E780: CC20002A 8A02D72A
	v_mul_f32_e32 v107, 0xbfb8aa3b, v74                        // 000000D8E788: 10D694FF BFB8AA3B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D8E790: BF870215
	v_fma_f32 v165, -v143, v155, 1.0                           // 000000D8E794: D61300A5 23CB378F
	v_dual_fmac_f32 v158, v168, v158 :: v_dual_add_f32 v59, v59, v148// 000000D8E79C: C8093DA8 9E3B293B
	s_delay_alu instid0(VALU_DEP_4)                            // 000000D8E7A4: BF870004
	v_mul_f32_e32 v106, 0xbfb8aa3b, v42                        // 000000D8E7A8: 10D454FF BFB8AA3B
	v_mov_b32_dpp v150, v35 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D8E7B0: 7F2C02FA FF016123
	v_cndmask_b32_e64 v35, -v35, v35, s0                       // 000000D8E7B8: D5010023 20024723
	v_exp_f32_e32 v107, v107                                   // 000000D8E7C0: 7ED64B6B
	v_fmac_f32_e32 v155, v165, v155                            // 000000D8E7C4: 573737A5
	v_exp_f32_e32 v106, v106                                   // 000000D8E7C8: 7ED44B6A
	v_mul_f32_e32 v168, v152, v158                             // 000000D8E7CC: 11513D98
	v_add_f32_e32 v35, v35, v150                               // 000000D8E7D0: 06472D23
	v_mov_b32_dpp v148, v59 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D8E7D4: 7F2802FA FF01643B
	v_cndmask_b32_e64 v59, -v59, v59, s2                       // 000000D8E7DC: D501003B 200A773B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D8E7E4: BF870214
	v_fma_f32 v176, -v146, v168, v152                          // 000000D8E7E8: D61300B0 26635192
	v_mov_b32_dpp v150, v35 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D8E7F0: 7F2C02FA FF016223
	v_cndmask_b32_e64 v35, -v35, v35, s1                       // 000000D8E7F8: D5010023 20064723
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(VALU_DEP_4)   // 000000D8E800: BF870205
	v_dual_add_f32 v59, v59, v148 :: v_dual_add_f32 v90, 1.0, v106// 000000D8E804: C909293B 3B5AD4F2
	v_add_f32_e32 v106, 1.0, v107                              // 000000D8E80C: 06D4D6F2
	v_div_scale_f32 v107, null, v67, v67, v8                   // 000000D8E810: D6FC7C6B 04228743
	v_fmac_f32_e32 v168, v176, v158                            // 000000D8E818: 57513DB0
	s_delay_alu instid0(VALU_DEP_4)                            // 000000D8E81C: BF870004
	v_mov_b32_dpp v148, v59 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D8E820: 7F2802FA FF01683B
	v_cndmask_b32_e64 v59, -v59, v59, s3                       // 000000D8E828: D501003B 200E773B
	v_div_scale_f32 v162, s10, v74, v106, v74                  // 000000D8E830: D6FC0AA2 052AD54A
	v_rcp_f32_e32 v153, v107                                   // 000000D8E838: 7F32556B
	v_div_scale_f32 v145, null, v90, v90, v42                  // 000000D8E83C: D6FC7C91 04AAB55A
	v_div_scale_f32 v151, s7, v42, v90, v42                    // 000000D8E844: D6FC0797 04AAB52A
	v_add_f32_e32 v59, v59, v148                               // 000000D8E84C: 0677293B
	v_div_scale_f32 v148, null, v106, v106, v74                // 000000D8E850: D6FC7C94 052AD56A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D8E858: BF870114
	v_rcp_f32_e32 v157, v145                                   // 000000D8E85C: 7F3A5591
	v_mul_f32_e32 v59, 0x3db504f3, v59                         // 000000D8E860: 107676FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_3)// 000000D8E868: BF870392
	v_rcp_f32_e32 v160, v148                                   // 000000D8E86C: 7F405594
	v_fma_f32 v163, -v107, v153, 1.0                           // 000000D8E870: D61300A3 23CB336B
	s_waitcnt vmcnt(10)                                        // 000000D8E878: BF892BF7
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D8E87C: BF870112
	v_fma_mix_f32 v27, v27, v59, neg(0) op_sel_hi:[1,0,0]      // 000000D8E880: CC20001B 8A02771B
	v_fmac_f32_e32 v153, v163, v153                            // 000000D8E888: 573333A3
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000D8E88C: BF870296
	v_fma_f32 v167, -v145, v157, 1.0                           // 000000D8E890: D61300A7 23CB3B91
	v_fma_f32 v170, -v148, v160, 1.0                           // 000000D8E898: D61300AA 23CB4194
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D8E8A0: BF870113
	v_mul_f32_e32 v163, v114, v153                             // 000000D8E8A4: 11473372
	v_dual_fmac_f32 v157, v167, v157 :: v_dual_fmac_f32 v160, v170, v160// 000000D8E8A8: C8013BA7 9DA141AA
	v_add_f32_e32 v35, v35, v150                               // 000000D8E8B0: 06472D23
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D8E8B4: BF870193
	v_fma_f32 v171, -v107, v163, v114                          // 000000D8E8B8: D61300AB 25CB476B
	v_dual_mul_f32 v167, v151, v157 :: v_dual_mul_f32 v170, v162, v160// 000000D8E8C0: C8C73B97 A7AB41A2
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D8E8C8: BF870223
	v_mov_b32_dpp v150, v35 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D8E8CC: 7F2C02FA FF016423
	v_cndmask_b32_e64 v35, -v35, v35, s2                       // 000000D8E8D4: D5010023 200A4723
	v_fmac_f32_e32 v163, v171, v153                            // 000000D8E8DC: 574733AB
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D8E8E0: BF870224
	v_fma_f32 v175, -v145, v167, v151                          // 000000D8E8E4: D61300AF 265F4F91
	v_fma_f32 v178, -v148, v170, v162                          // 000000D8E8EC: D61300B2 268B5594
	v_add_f32_e32 v35, v35, v150                               // 000000D8E8F4: 06472D23
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D8E8F8: BF870224
	v_fma_f32 v107, -v107, v163, v114                          // 000000D8E8FC: D613006B 25CB476B
	v_fma_f32 v114, -v115, v164, v122                          // 000000D8E904: D6130072 25EB4973
	v_dual_fmac_f32 v167, v175, v157 :: v_dual_fmac_f32 v170, v178, v160// 000000D8E90C: C8013BAF A7AB41B2
	s_delay_alu instid0(VALU_DEP_4)                            // 000000D8E914: BF870004
	v_mov_b32_dpp v150, v35 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D8E918: 7F2C02FA FF016823
	v_cndmask_b32_e64 v35, -v35, v35, s3                       // 000000D8E920: D5010023 200E4723
	v_div_fmas_f32 v107, v107, v153, v163                      // 000000D8E928: D637006B 068F336B
	s_mov_b32 vcc_lo, s4                                       // 000000D8E930: BEEA0004
	s_mov_b32 s4, exec_lo                                      // 000000D8E934: BE84007E
	v_div_fmas_f32 v114, v114, v154, v164                      // 000000D8E938: D6370072 06933572
	v_add_f32_e32 v35, v35, v150                               // 000000D8E940: 06472D23
	v_div_scale_f32 v150, s6, v26, v83, v26                    // 000000D8E944: D6FC0696 046AA71A
	v_add_f32_e32 v51, v51, v149                               // 000000D8E94C: 06672B33
	v_div_fixup_f32 v8, v107, v67, v8                          // 000000D8E950: D6270008 0422876B
	v_div_fixup_f32 v9, v114, v75, v9                          // 000000D8E958: D6270009 04269772
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D8E960: BF870214
	v_dual_mul_f32 v35, 0x3db504f3, v35 :: v_dual_mul_f32 v166, v150, v156// 000000D8E964: C8C646FF 23A73996 3DB504F3
	v_mov_b32_dpp v149, v51 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D8E970: 7F2A02FA FF016433
	v_cndmask_b32_e64 v51, -v51, v51, s2                       // 000000D8E978: D5010033 200A6733
	v_mul_f32_e32 v7, v7, v8                                   // 000000D8E980: 100E1107
	v_mul_f32_e32 v9, v10, v9                                  // 000000D8E984: 1012130A
	s_waitcnt vmcnt(8)                                         // 000000D8E988: BF8923F7
	v_fma_mix_f32 v34, v34, v35, neg(0) op_sel_hi:[1,0,0]      // 000000D8E98C: CC200022 8A024722
	v_add_f32_e32 v91, v91, v147                               // 000000D8E994: 06B7275B
	v_add_f32_e32 v51, v51, v149                               // 000000D8E998: 06672B33
	v_fma_f32 v174, -v144, v166, v150                          // 000000D8E99C: D61300AE 265B4D90
	s_waitcnt vmcnt(7)                                         // 000000D8E9A4: BF891FF7
	v_fma_mix_f32 v9, v123, v9, neg(0) op_sel_hi:[1,0,0]       // 000000D8E9A8: CC200009 8A02137B
	v_mov_b32_dpp v147, v91 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D8E9B0: 7F2602FA FF01685B
	v_cndmask_b32_e64 v91, -v91, v91, s3                       // 000000D8E9B8: D501005B 200EB75B
	v_mov_b32_dpp v149, v51 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D8E9C0: 7F2A02FA FF016833
	v_cndmask_b32_e64 v51, -v51, v51, s3                       // 000000D8E9C8: D5010033 200E6733
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000D8E9D0: BF8701A3
	v_dual_fmac_f32 v166, v174, v156 :: v_dual_add_f32 v91, v91, v147// 000000D8E9D4: C80939AE A65B275B
	v_div_scale_f32 v147, null, v99, v99, v50                  // 000000D8E9DC: D6FC7C93 04CAC763
	v_add_f32_e32 v51, v51, v149                               // 000000D8E9E4: 06672B33
	v_div_scale_f32 v149, s5, v18, v82, v18                    // 000000D8E9E8: D6FC0595 044AA512
	s_delay_alu instid0(VALU_DEP_4)                            // 000000D8E9F0: BF870004
	v_fma_f32 v122, -v144, v166, v150                          // 000000D8E9F4: D613007A 265B4D90
	s_mov_b32 vcc_lo, s5                                       // 000000D8E9FC: BEEA0005
	v_rcp_f32_e32 v159, v147                                   // 000000D8EA00: 7F3E5593
	v_fma_f32 v144, -v146, v168, v152                          // 000000D8EA04: D6130090 26635192
	v_mul_f32_e32 v165, v149, v155                             // 000000D8EA0C: 114B3795
	v_mul_f32_e32 v91, 0x3db504f3, v91                         // 000000D8EA10: 10B6B6FF 3DB504F3
	v_mul_f32_e32 v51, 0x3db504f3, v51                         // 000000D8EA18: 106666FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D8EA20: BF870193
	v_fma_f32 v173, -v143, v165, v149                          // 000000D8EA24: D61300AD 26574B8F
	v_fma_mix_f32 v19, v19, v91, neg(0) op_sel_hi:[1,0,0]      // 000000D8EA2C: CC200013 8A02B713
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000D8EA34: BF870293
	v_fma_mix_f32 v11, v11, v51, neg(0) op_sel_hi:[1,0,0]      // 000000D8EA38: CC20000B 8A02670B
	v_fma_f32 v169, -v147, v159, 1.0                           // 000000D8EA40: D61300A9 23CB3F93
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D8EA48: BF870114
	v_fmac_f32_e32 v165, v173, v155                            // 000000D8EA4C: 574B37AD
	v_fmac_f32_e32 v159, v169, v159                            // 000000D8EA50: 573F3FA9
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000D8EA54: BF8701A2
	v_fma_f32 v115, -v143, v165, v149                          // 000000D8EA58: D6130073 26574B8F
	v_fma_f32 v143, -v145, v167, v151                          // 000000D8EA60: D613008F 265F4F91
	v_mul_f32_e32 v169, v161, v159                             // 000000D8EA68: 11533FA1
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000D8EA6C: BF870123
	v_div_fmas_f32 v115, v115, v155, v165                      // 000000D8EA70: D6370073 06973773
	s_mov_b32 vcc_lo, s6                                       // 000000D8EA78: BEEA0006
	v_fma_f32 v177, -v147, v169, v161                          // 000000D8EA7C: D61300B1 26875393
	v_div_fmas_f32 v67, v122, v156, v166                       // 000000D8EA84: D6370043 069B397A
	s_mov_b32 vcc_lo, s7                                       // 000000D8EA8C: BEEA0007
	v_div_fixup_f32 v18, v115, v82, v18                        // 000000D8EA90: D6270012 044AA573
	v_div_fmas_f32 v75, v143, v157, v167                       // 000000D8EA98: D637004B 069F3B8F
	v_fmac_f32_e32 v169, v177, v159                            // 000000D8EAA0: 57533FB1
	s_mov_b32 vcc_lo, s8                                       // 000000D8EAA4: BEEA0008
	v_div_fixup_f32 v8, v67, v83, v26                          // 000000D8EAA8: D6270008 046AA743
	v_fma_f32 v26, -v148, v170, v162                           // 000000D8EAB0: D613001A 268B5594
	v_div_fmas_f32 v10, v144, v158, v168                       // 000000D8EAB8: D637000A 06A33D90
	v_fma_f32 v145, -v147, v169, v161                          // 000000D8EAC0: D6130091 26875393
	s_mov_b32 vcc_lo, s9                                       // 000000D8EAC8: BEEA0009
	v_mul_f32_e32 v18, v58, v18                                // 000000D8EACC: 1024253A
	v_mul_f32_e32 v8, v66, v8                                  // 000000D8EAD0: 10101142
	v_div_fixup_f32 v10, v10, v98, v43                         // 000000D8EAD4: D627000A 04AEC50A
	v_div_fmas_f32 v58, v145, v159, v169                       // 000000D8EADC: D637003A 06A73F91
	s_mov_b32 vcc_lo, s10                                      // 000000D8EAE4: BEEA000A
	v_div_fixup_f32 v35, v75, v90, v42                         // 000000D8EAE8: D6270023 04AAB54B
	v_div_fmas_f32 v26, v26, v160, v170                        // 000000D8EAF0: D637001A 06AB411A
	v_mul_f32_e32 v10, v27, v10                                // 000000D8EAF8: 1014151B
	v_div_fixup_f32 v27, v58, v99, v50                         // 000000D8EAFC: D627001B 04CAC73A
	s_waitcnt vmcnt(6)                                         // 000000D8EB04: BF891BF7
	v_fma_mix_f32 v8, v130, v8, neg(0) op_sel_hi:[1,0,0]       // 000000D8EB08: CC200008 8A021182
	v_mul_f32_e32 v19, v19, v35                                // 000000D8EB10: 10264713
	v_div_fixup_f32 v26, v26, v106, v74                        // 000000D8EB14: D627001A 052AD51A
	s_waitcnt vmcnt(5)                                         // 000000D8EB1C: BF8917F7
	v_fma_mix_f32 v10, v131, v10, neg(0) op_sel_hi:[1,0,0]     // 000000D8EB20: CC20000A 8A021583
	v_mul_f32_e32 v11, v11, v27                                // 000000D8EB28: 1016370B
	s_waitcnt vmcnt(0)                                         // 000000D8EB2C: BF8903F7
	v_fma_mix_f32 v27, v7, v142, v9 op_sel_hi:[0,1,0]          // 000000D8EB30: CC20001B 14271D07
	v_fma_mix_f32 v7, v7, v142, -v9 op_sel_hi:[0,1,0]          // 000000D8EB38: CC200007 94271D07
	v_mul_f32_e32 v26, v34, v26                                // 000000D8EB40: 10343522
	v_fma_mix_f32 v34, v18, v141, v8 op_sel_hi:[0,1,0]         // 000000D8EB44: CC200022 14231B12
	v_fma_mix_f32 v35, v19, v140, v10 op_sel_hi:[0,1,0]        // 000000D8EB4C: CC200023 142B1913
	v_fma_mix_f32 v8, v18, v141, -v8 op_sel_hi:[0,1,0]         // 000000D8EB54: CC200008 94231B12
	v_fma_mix_f32 v10, v19, v140, -v10 op_sel_hi:[0,1,0]       // 000000D8EB5C: CC20000A 942B1913
	v_fma_mix_f32 v26, v138, v26, neg(0) op_sel_hi:[1,0,0]     // 000000D8EB64: CC20001A 8A02358A
	v_add_f32_e32 v43, v27, v34                                // 000000D8EB6C: 0656451B
	v_sub_f32_e32 v18, v27, v34                                // 000000D8EB70: 0824451B
	v_add_f32_e32 v19, v7, v8                                  // 000000D8EB74: 06261107
	v_sub_f32_e32 v7, v7, v8                                   // 000000D8EB78: 080E1107
	v_fma_mix_f32 v42, v11, v139, v26 op_sel_hi:[0,1,0]        // 000000D8EB7C: CC20002A 146B170B
	v_fma_mix_f32 v11, v11, v139, -v26 op_sel_hi:[0,1,0]       // 000000D8EB84: CC20000B 946B170B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D8EB8C: BF870112
	v_add_f32_e32 v50, v35, v42                                // 000000D8EB90: 06645523
	v_dual_add_f32 v8, v10, v11 :: v_dual_sub_f32 v27, v35, v42// 000000D8EB94: C90A170A 081A5523
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000D8EB9C: BF870122
	v_dual_sub_f32 v10, v10, v11 :: v_dual_add_f32 v9, v43, v50// 000000D8EBA0: C948170A 0A08652B
	v_sub_f32_e32 v11, v43, v50                                // 000000D8EBA8: 0816652B
	v_mov_b32_dpp v26, v9 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D8EBAC: 7E3402FA FF016109
	v_cndmask_b32_e64 v9, -v9, v9, s0                          // 000000D8EBB4: D5010009 20021309
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D8EBBC: BF870113
	v_cndmask_b32_e64 v50, -v11, v11, s0                       // 000000D8EBC0: D5010032 2002170B
	v_dual_add_f32 v9, v9, v26 :: v_dual_add_f32 v26, v19, v8  // 000000D8EBC8: C9083509 091A1113
	v_dual_sub_f32 v19, v19, v8 :: v_dual_add_f32 v8, v18, v27 // 000000D8EBD0: C9481113 13083712
	v_sub_f32_e32 v27, v18, v27                                // 000000D8EBD8: 08363712
	s_delay_alu instid0(VALU_DEP_3)                            // 000000D8EBDC: BF870003
	v_mov_b32_dpp v34, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D8EBE0: 7E4402FA FF016209
	v_cndmask_b32_e64 v9, -v9, v9, s1                          // 000000D8EBE8: D5010009 20061309
	v_mov_b32_dpp v35, v26 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D8EBF0: 7E4602FA FF01611A
	v_cndmask_b32_e64 v26, -v26, v26, s0                       // 000000D8EBF8: D501001A 2002351A
	v_mov_b32_dpp v42, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D8EC00: 7E5402FA FF016108
	v_cndmask_b32_e64 v8, -v8, v8, s0                          // 000000D8EC08: D5010008 20021108
	v_add_f32_e32 v9, v9, v34                                  // 000000D8EC10: 06124509
	v_mov_b32_dpp v51, v27 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D8EC14: 7E6602FA FF01611B
	v_add_f32_e32 v18, v26, v35                                // 000000D8EC1C: 0624471A
	v_add_f32_e32 v26, v7, v10                                 // 000000D8EC20: 06341507
	v_add_f32_e32 v8, v8, v42                                  // 000000D8EC24: 06105508
	v_mov_b32_dpp v34, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D8EC28: 7E4402FA FF016409
	v_cndmask_b32_e64 v9, -v9, v9, s2                          // 000000D8EC30: D5010009 200A1309
	v_mov_b32_dpp v35, v18 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D8EC38: 7E4602FA FF016212
	v_cndmask_b32_e64 v18, -v18, v18, s1                       // 000000D8EC40: D5010012 20062512
	v_mov_b32_dpp v42, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D8EC48: 7E5402FA FF016208
	v_cndmask_b32_e64 v8, -v8, v8, s1                          // 000000D8EC50: D5010008 20061108
	v_mov_b32_dpp v43, v26 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D8EC58: 7E5602FA FF01611A
	v_cndmask_b32_e64 v26, -v26, v26, s0                       // 000000D8EC60: D501001A 2002351A
	v_dual_add_f32 v18, v18, v35 :: v_dual_sub_f32 v35, v7, v10// 000000D8EC68: C90A4712 12221507
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D8EC70: BF870224
	v_add_f32_e32 v8, v8, v42                                  // 000000D8EC74: 06105508
	v_add_f32_e32 v7, v9, v34                                  // 000000D8EC78: 060E4509
	v_add_f32_e32 v9, v26, v43                                 // 000000D8EC7C: 0612571A
	v_mov_b32_dpp v43, v11 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D8EC80: 7E5602FA FF01610B
	v_cndmask_b32_e64 v27, -v27, v27, s0                       // 000000D8EC88: D501001B 2002371B
	v_mov_b32_dpp v26, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D8EC90: 7E3402FA FF016408
	v_cndmask_b32_e64 v8, -v8, v8, s2                          // 000000D8EC98: D5010008 200A1108
	v_mov_b32_dpp v34, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D8ECA0: 7E4402FA FF016209
	v_cndmask_b32_e64 v42, -v9, v9, s1                         // 000000D8ECA8: D501002A 20061309
	v_mov_b32_dpp v58, v35 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D8ECB0: 7E7402FA FF016123
	v_cndmask_b32_e64 v35, -v35, v35, s0                       // 000000D8ECB8: D5010023 20024723
	v_add_f32_e32 v11, v8, v26                                 // 000000D8ECC0: 06163508
	v_mov_b32_dpp v10, v18 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D8ECC4: 7E1402FA FF016412
	v_add_f32_e32 v26, v42, v34                                // 000000D8ECCC: 0634452A
	v_add_f32_e32 v34, v50, v43                                // 000000D8ECD0: 06445732
	v_mov_b32_dpp v50, v19 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D8ECD4: 7E6402FA FF016113
	v_cndmask_b32_e64 v19, -v19, v19, s0                       // 000000D8ECDC: D5010013 20022713
	v_cndmask_b32_e64 v18, -v18, v18, s2                       // 000000D8ECE4: D5010012 200A2512
	v_mov_b32_dpp v42, v26 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D8ECEC: 7E5402FA FF01641A
	v_cndmask_b32_e64 v26, -v26, v26, s2                       // 000000D8ECF4: D501001A 200A351A
	v_mov_b32_dpp v43, v34 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D8ECFC: 7E5602FA FF016222
	v_cndmask_b32_e64 v34, -v34, v34, s1                       // 000000D8ED04: D5010022 20064522
	v_add_f32_e32 v50, v19, v50                                // 000000D8ED0C: 06646513
	v_add_f32_e32 v9, v18, v10                                 // 000000D8ED10: 06121512
	v_dual_add_f32 v19, v26, v42 :: v_dual_add_f32 v26, v27, v51// 000000D8ED14: C908551A 131A671B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D8ED1C: BF870214
	v_dual_add_f32 v27, v34, v43 :: v_dual_add_f32 v34, v35, v58// 000000D8ED20: C9085722 1B227523
	v_mov_b32_dpp v35, v50 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D8ED28: 7E4602FA FF016232
	v_cndmask_b32_e64 v42, -v50, v50, s1                       // 000000D8ED30: D501002A 20066532
	s_delay_alu instid0(VALU_DEP_4)                            // 000000D8ED38: BF870004
	v_mov_b32_dpp v43, v26 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D8ED3C: 7E5602FA FF01621A
	v_cndmask_b32_e64 v26, -v26, v26, s1                       // 000000D8ED44: D501001A 2006351A
	v_mov_b32_dpp v50, v34 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D8ED4C: 7E6402FA FF016222
	v_cndmask_b32_e64 v34, -v34, v34, s1                       // 000000D8ED54: D5010022 20064522
	v_add_f32_e32 v35, v42, v35                                // 000000D8ED5C: 0646472A
	v_mov_b32_dpp v42, v27 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D8ED60: 7E5402FA FF01641B
	v_add_f32_e32 v26, v26, v43                                // 000000D8ED68: 0634571A
	v_cndmask_b32_e64 v27, -v27, v27, s2                       // 000000D8ED6C: D501001B 200A371B
	v_add_f32_e32 v34, v34, v50                                // 000000D8ED74: 06446522
	v_mov_b32_dpp v43, v35 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D8ED78: 7E5602FA FF016423
	v_cndmask_b32_e64 v50, -v35, v35, s2                       // 000000D8ED80: D5010032 200A4723
	v_mov_b32_dpp v51, v26 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D8ED88: 7E6602FA FF01641A
	v_cndmask_b32_e64 v58, -v26, v26, s2                       // 000000D8ED90: D501003A 200A351A
	v_mov_b32_dpp v59, v34 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D8ED98: 7E7602FA FF016422
	v_cndmask_b32_e64 v34, -v34, v34, s2                       // 000000D8EDA0: D5010022 200A4522
	v_dual_add_f32 v35, v27, v42 :: v_dual_add_f32 v42, v50, v43// 000000D8EDA8: C908551B 232A5732
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D8EDB0: BF870224
	v_add_f32_e32 v50, v58, v51                                // 000000D8EDB4: 0664673A
	v_mov_b32_dpp v8, v7 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D8EDB8: 7E1002FA FF016807
	v_add_f32_e32 v58, v34, v59                                // 000000D8EDC0: 06747722
	v_mov_b32_dpp v10, v9 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D8EDC4: 7E1402FA FF016809
	v_mov_b32_dpp v18, v11 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D8EDCC: 7E2402FA FF01680B
	v_mov_b32_dpp v26, v19 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D8EDD4: 7E3402FA FF016813
	v_add_nc_u32_e32 v27, 2, v6                                // 000000D8EDDC: 4A360C82
	v_mov_b32_dpp v34, v35 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D8EDE0: 7E4402FA FF016823
	v_mov_b32_dpp v43, v42 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D8EDE8: 7E5602FA FF01682A
	v_mov_b32_dpp v51, v50 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D8EDF0: 7E6602FA FF016832
	v_mov_b32_dpp v59, v58 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D8EDF8: 7E7602FA FF01683A
	.long 0xd4c4007e                                           // 000000D8EE00: D4C4007E
	v_cndmask_b32_e32 v1, s23, v27, vcc_lo                     // 000000D8EE04: 02023617
	s_cbranch_execz 62                                         // 000000D8EE08: BFA5003E <_ZN7halogen12_GLOBAL__N_111k_ht_moe_guILi3ELi8ELi1EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_S5_PDF16_+0x2c04>
	v_cndmask_b32_e64 v58, -v58, v58, s3                       // 000000D8EE0C: D501003A 200E753A
	v_cndmask_b32_e64 v7, -v7, v7, s3                          // 000000D8EE14: D5010007 200E0F07
	v_cndmask_b32_e64 v9, -v9, v9, s3                          // 000000D8EE1C: D5010009 200E1309
	v_cndmask_b32_e64 v50, -v50, v50, s3                       // 000000D8EE24: D5010032 200E6532
	v_cndmask_b32_e64 v19, -v19, v19, s3                       // 000000D8EE2C: D5010013 200E2713
	v_cndmask_b32_e64 v11, -v11, v11, s3                       // 000000D8EE34: D501000B 200E170B
	v_cndmask_b32_e64 v35, -v35, v35, s3                       // 000000D8EE3C: D5010023 200E4723
	v_cndmask_b32_e64 v42, -v42, v42, s3                       // 000000D8EE44: D501002A 200E552A
	v_dual_add_f32 v58, v58, v59 :: v_dual_add_f32 v7, v7, v8  // 000000D8EE4C: C908773A 3A061107
	v_add_f32_e32 v8, v9, v10                                  // 000000D8EE54: 06101509
	v_dual_add_f32 v50, v50, v51 :: v_dual_add_f32 v9, v11, v18// 000000D8EE58: C9086732 3208250B
	v_add_f32_e32 v26, v19, v26                                // 000000D8EE60: 06343513
	v_mad_i64_i32 v[18:19], null, 0x500, v27, v[0:1]           // 000000D8EE64: D6FF7C12 040236FF 00000500
	s_mov_b32 s5, 0x3db504f3                                   // 000000D8EE70: BE8500FF 3DB504F3
	v_add_f32_e32 v34, v35, v34                                // 000000D8EE78: 06444523
	v_add_f32_e32 v42, v42, v43                                // 000000D8EE7C: 0654572A
	v_fma_mixlo_f16 v7, v7, s5, 0                              // 000000D8EE80: CC210007 02000B07
	v_fma_mixhi_f16 v7, v8, s5, 0                              // 000000D8EE88: CC220007 02000B08
	v_fma_mixlo_f16 v8, v9, s5, 0                              // 000000D8EE90: CC210008 02000B09
	v_fma_mixhi_f16 v8, v26, s5, 0                             // 000000D8EE98: CC220008 02000B1A
	v_fma_mixlo_f16 v9, v34, s5, 0                             // 000000D8EEA0: CC210009 02000B22
	v_fma_mixhi_f16 v9, v42, s5, 0                             // 000000D8EEA8: CC220009 02000B2A
	v_fma_mixlo_f16 v10, v50, s5, 0                            // 000000D8EEB0: CC21000A 02000B32
	v_fma_mixhi_f16 v10, v58, s5, 0                            // 000000D8EEB8: CC22000A 02000B3A
	s_clause 0x7                                               // 000000D8EEC0: BF850007
	global_store_b16 v[18:19], v7, off                         // 000000D8EEC4: DC660000 007C0712
	global_store_d16_hi_b16 v[18:19], v7, off offset:32        // 000000D8EECC: DC960020 007C0712
	global_store_b16 v[18:19], v8, off offset:64               // 000000D8EED4: DC660040 007C0812
	global_store_d16_hi_b16 v[18:19], v8, off offset:96        // 000000D8EEDC: DC960060 007C0812
	global_store_b16 v[18:19], v9, off offset:128              // 000000D8EEE4: DC660080 007C0912
	global_store_d16_hi_b16 v[18:19], v9, off offset:160       // 000000D8EEEC: DC9600A0 007C0912
	global_store_b16 v[18:19], v10, off offset:192             // 000000D8EEF4: DC6600C0 007C0A12
	global_store_d16_hi_b16 v[18:19], v10, off offset:224      // 000000D8EEFC: DC9600E0 007C0A12
	s_or_b32 exec_lo, exec_lo, s4                              // 000000D8EF04: 8C7E047E
	s_clause 0xb                                               // 000000D8EF08: BF85000B
	global_load_d16_b16 v7, v[2:3], off offset:1280            // 000000D8EF0C: DC820500 077C0002
	global_load_d16_b16 v10, v[2:3], off offset:1312           // 000000D8EF14: DC820520 0A7C0002
	global_load_d16_b16 v8, v[2:3], off                        // 000000D8EF1C: DC820000 087C0002
	global_load_d16_b16 v9, v[2:3], off offset:32              // 000000D8EF24: DC820020 097C0002
	global_load_d16_b16 v11, v[2:3], off offset:64             // 000000D8EF2C: DC820040 0B7C0002
	global_load_d16_b16 v18, v[2:3], off offset:96             // 000000D8EF34: DC820060 127C0002
	global_load_d16_b16 v27, v[2:3], off offset:128            // 000000D8EF3C: DC820080 1B7C0002
	global_load_d16_b16 v34, v[2:3], off offset:160            // 000000D8EF44: DC8200A0 227C0002
	global_load_d16_b16 v43, v[2:3], off offset:192            // 000000D8EF4C: DC8200C0 2B7C0002
	global_load_d16_b16 v50, v[2:3], off offset:224            // 000000D8EF54: DC8200E0 327C0002
	global_load_d16_b16 v35, v[2:3], off offset:1344           // 000000D8EF5C: DC820540 237C0002
	global_load_d16_b16 v42, v[2:3], off offset:1376           // 000000D8EF64: DC820560 2A7C0002
	v_add_f32_e32 v67, v100, v92                               // 000000D8EF6C: 0686B964
	v_add_f32_e32 v75, v84, v76                                // 000000D8EF70: 06969954
	v_add_f32_e32 v59, v116, v108                              // 000000D8EF74: 0676D974
	v_sub_f32_e32 v58, v132, v124                              // 000000D8EF78: 0874F984
	v_sub_f32_e32 v66, v116, v108                              // 000000D8EF7C: 0884D974
	v_add_f32_e32 v51, v132, v124                              // 000000D8EF80: 0666F984
	v_sub_f32_e32 v74, v100, v92                               // 000000D8EF84: 0894B964
	s_delay_alu instid0(VALU_DEP_2)                            // 000000D8EF88: BF870002
	v_dual_sub_f32 v76, v84, v76 :: v_dual_add_f32 v107, v51, v59// 000000D8EF8C: C9489954 4C6A7733
	v_sub_f32_e32 v51, v51, v59                                // 000000D8EF94: 08667733
	v_add_f32_e32 v59, v58, v66                                // 000000D8EF98: 0676853A
	v_sub_f32_e32 v58, v58, v66                                // 000000D8EF9C: 0874853A
	v_add_f32_e32 v66, v67, v75                                // 000000D8EFA0: 06849743
	v_dual_sub_f32 v67, v67, v75 :: v_dual_add_f32 v82, v68, v60// 000000D8EFA4: C9489743 43527944
	v_add_f32_e32 v75, v74, v76                                // 000000D8EFAC: 0696994A
	v_sub_f32_e32 v60, v68, v60                                // 000000D8EFB0: 08787944
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000D8EFB4: BF870123
	v_dual_add_f32 v68, v52, v44 :: v_dual_add_f32 v115, v51, v67// 000000D8EFB8: C9085934 44728733
	v_dual_sub_f32 v51, v51, v67 :: v_dual_sub_f32 v44, v52, v44// 000000D8EFC0: C94A8733 332C5934
	v_mov_b32_dpp v132, v115 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D8EFC8: 7F0802FA FF016173
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000D8EFD0: BF8701C2
	v_mov_b32_dpp v141, v51 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D8EFD4: 7F1A02FA FF016133
	v_cndmask_b32_e64 v51, -v51, v51, s0                       // 000000D8EFDC: D5010033 20026733
	v_add_f32_e32 v52, v36, v28                                // 000000D8EFE4: 06683924
	v_cndmask_b32_e64 v115, -v115, v115, s0                    // 000000D8EFE8: D5010073 2002E773
	v_add_f32_e32 v51, v51, v141                               // 000000D8EFF0: 06671B33
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000D8EFF4: BF8700A1
	v_mov_b32_dpp v141, v51 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D8EFF8: 7F1A02FA FF016233
	v_cndmask_b32_e64 v51, -v51, v51, s1                       // 000000D8F000: D5010033 20066733
	v_dual_sub_f32 v28, v36, v28 :: v_dual_add_f32 v51, v51, v141// 000000D8F008: C9483924 1C331B33
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000D8F010: BF8700A1
	v_mov_b32_dpp v141, v51 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D8F014: 7F1A02FA FF016433
	v_cndmask_b32_e64 v51, -v51, v51, s2                       // 000000D8F01C: D5010033 200A6733
	v_dual_add_f32 v36, v20, v12 :: v_dual_add_f32 v51, v51, v141// 000000D8F024: C9081914 24331B33
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 000000D8F02C: BF870251
	v_mov_b32_dpp v141, v51 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D8F030: 7F1A02FA FF016833
	v_cndmask_b32_e64 v51, -v51, v51, s3                       // 000000D8F038: D5010033 200E6733
	v_sub_f32_e32 v74, v74, v76                                // 000000D8F040: 0894994A
	v_add_f32_e32 v76, v82, v68                                // 000000D8F044: 06988952
	v_sub_f32_e32 v68, v82, v68                                // 000000D8F048: 08888952
	v_dual_add_f32 v82, v60, v44 :: v_dual_add_f32 v51, v51, v141// 000000D8F04C: C908593C 52331B33
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000D8F054: BF870244
	v_dual_sub_f32 v83, v20, v12 :: v_dual_add_f32 v114, v58, v74// 000000D8F058: C9481914 5372953A
	v_add_f32_e32 v108, v52, v36                               // 000000D8F060: 06D84934
	v_sub_f32_e32 v44, v60, v44                                // 000000D8F064: 0858593C
	v_sub_f32_e32 v36, v52, v36                                // 000000D8F068: 08484934
	v_add_f32_e32 v60, v28, v83                                // 000000D8F06C: 0678A71C
	v_sub_f32_e32 v28, v28, v83                                // 000000D8F070: 0838A71C
	v_dual_mul_f32 v51, 0x3db504f3, v51 :: v_dual_add_f32 v52, v76, v108// 000000D8F074: C8C866FF 3334D94C 3DB504F3
	v_sub_f32_e32 v58, v58, v74                                // 000000D8F080: 0874953A
	s_delay_alu instid0(VALU_DEP_4)                            // 000000D8F084: BF870004
	v_add_f32_e32 v83, v82, v60                                // 000000D8F088: 06A67952
	v_sub_f32_e32 v60, v82, v60                                // 000000D8F08C: 08787952
	v_add_f32_e32 v82, v68, v36                                // 000000D8F090: 06A44944
	v_sub_f32_e32 v36, v68, v36                                // 000000D8F094: 08484944
	v_add_f32_e32 v68, v44, v28                                // 000000D8F098: 0688392C
	v_sub_f32_e32 v28, v44, v28                                // 000000D8F09C: 0838392C
	v_add_f32_e32 v44, v59, v75                                // 000000D8F0A0: 0658973B
	v_sub_f32_e32 v59, v59, v75                                // 000000D8F0A4: 0876973B
	v_mov_b32_dpp v67, v52 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D8F0A8: 7E8602FA FF016134
	v_cndmask_b32_e64 v52, -v52, v52, s0                       // 000000D8F0B0: D5010034 20026934
	v_mov_b32_dpp v74, v83 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D8F0B8: 7E9402FA FF016153
	v_mov_b32_dpp v131, v44 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D8F0C0: 7F0602FA FF01612C
	v_mov_b32_dpp v140, v59 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D8F0C8: 7F1802FA FF01613B
	v_cndmask_b32_e64 v59, -v59, v59, s0                       // 000000D8F0D0: D501003B 2002773B
	v_add_f32_e32 v52, v52, v67                                // 000000D8F0D8: 06688734
	v_cndmask_b32_e64 v44, -v44, v44, s0                       // 000000D8F0DC: D501002C 2002592C
	v_cndmask_b32_e64 v75, -v83, v83, s0                       // 000000D8F0E4: D501004B 2002A753
	v_mov_b32_dpp v83, v82 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D8F0EC: 7EA602FA FF016152
	v_add_f32_e32 v59, v59, v140                               // 000000D8F0F4: 0677193B
	v_cndmask_b32_e64 v82, -v82, v82, s0                       // 000000D8F0F8: D5010052 2002A552
	v_mov_b32_dpp v138, v114 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D8F100: 7F1402FA FF016172
	v_add_f32_e32 v67, v75, v74                                // 000000D8F108: 0686954B
	v_cndmask_b32_e64 v114, -v114, v114, s0                    // 000000D8F10C: D5010072 2002E572
	v_mov_b32_dpp v140, v59 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D8F114: 7F1802FA FF01623B
	v_cndmask_b32_e64 v59, -v59, v59, s1                       // 000000D8F11C: D501003B 2006773B
	v_add_f32_e32 v44, v44, v131                               // 000000D8F124: 0659072C
	s_clause 0x3                                               // 000000D8F128: BF850003
	global_load_d16_b16 v19, v[2:3], off offset:1408           // 000000D8F12C: DC820580 137C0002
	global_load_d16_b16 v20, v[2:3], off offset:1440           // 000000D8F134: DC8205A0 147C0002
	global_load_d16_b16 v12, v[2:3], off offset:1472           // 000000D8F13C: DC8205C0 0C7C0002
	global_load_d16_b16 v26, v[2:3], off offset:1504           // 000000D8F144: DC8205E0 1A7C0002
	s_clause 0x7                                               // 000000D8F14C: BF850007
	global_load_d16_b16 v84, v[4:5], off offset:32             // 000000D8F150: DC820020 547C0004
	global_load_d16_b16 v90, v[4:5], off offset:96             // 000000D8F158: DC820060 5A7C0004
	global_load_d16_b16 v91, v[4:5], off offset:160            // 000000D8F160: DC8200A0 5B7C0004
	global_load_d16_b16 v92, v[4:5], off offset:224            // 000000D8F168: DC8200E0 5C7C0004
	global_load_d16_b16 v98, v[4:5], off offset:192            // 000000D8F170: DC8200C0 627C0004
	global_load_d16_b16 v99, v[4:5], off offset:128            // 000000D8F178: DC820080 637C0004
	global_load_d16_b16 v100, v[4:5], off offset:64            // 000000D8F180: DC820040 647C0004
	global_load_d16_b16 v106, v[4:5], off                      // 000000D8F188: DC820000 6A7C0004
	v_add_f32_e32 v59, v59, v140                               // 000000D8F190: 0677193B
	v_mov_b32_dpp v131, v44 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D8F194: 7F0602FA FF01622C
	v_cndmask_b32_e64 v44, -v44, v44, s1                       // 000000D8F19C: D501002C 2006592C
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000D8F1A4: BF8700A3
	v_mov_b32_dpp v140, v59 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D8F1A8: 7F1802FA FF01643B
	v_cndmask_b32_e64 v59, -v59, v59, s2                       // 000000D8F1B0: D501003B 200A773B
	v_dual_add_f32 v44, v44, v131 :: v_dual_add_f32 v59, v59, v140// 000000D8F1B8: C909072C 2C3B193B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000D8F1C0: BF8701A1
	v_mov_b32_dpp v131, v44 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D8F1C4: 7F0602FA FF01642C
	v_cndmask_b32_e64 v44, -v44, v44, s2                       // 000000D8F1CC: D501002C 200A592C
	v_mov_b32_dpp v140, v59 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D8F1D4: 7F1802FA FF01683B
	v_cndmask_b32_e64 v59, -v59, v59, s3                       // 000000D8F1DC: D501003B 200E773B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D8F1E4: BF870091
	v_dual_add_f32 v44, v44, v131 :: v_dual_add_f32 v59, v59, v140// 000000D8F1E8: C909072C 2C3B193B
	v_mov_b32_dpp v131, v44 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D8F1F0: 7F0602FA FF01682C
	v_cndmask_b32_e64 v44, -v44, v44, s3                       // 000000D8F1F8: D501002C 200E592C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D8F200: BF870113
	v_mul_f32_e32 v59, 0x3db504f3, v59                         // 000000D8F204: 107676FF 3DB504F3
	v_add_f32_e32 v44, v44, v131                               // 000000D8F20C: 0659072C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000D8F210: BF8700A1
	v_mul_f32_e32 v44, 0x3db504f3, v44                         // 000000D8F214: 105858FF 3DB504F3
	s_waitcnt vmcnt(20)                                        // 000000D8F21C: BF8953F7
	v_fma_mix_f32 v9, v9, v44, neg(0) op_sel_hi:[1,0,0]        // 000000D8F220: CC200009 8A025909
	s_waitcnt vmcnt(16)                                        // 000000D8F228: BF8943F7
	v_fma_mix_f32 v34, v34, v59, neg(0) op_sel_hi:[1,0,0]      // 000000D8F22C: CC200022 8A027722
	s_waitcnt vmcnt(15)                                        // 000000D8F234: BF893FF7
	v_fma_mix_f32 v43, v43, v51, neg(0) op_sel_hi:[1,0,0]      // 000000D8F238: CC20002B 8A02672B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D8F240: BF870092
	v_mul_f32_e32 v59, 0xbfb8aa3b, v34                         // 000000D8F244: 107644FF BFB8AA3B
	v_exp_f32_e32 v59, v59                                     // 000000D8F24C: 7E764B3B
	v_sub_f32_e32 v76, v76, v108                               // 000000D8F250: 0898D94C
	v_add_f32_e32 v108, v107, v66                              // 000000D8F254: 06D8856B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(TRANS32_DEP_1)// 000000D8F258: BF8702A1
	v_mov_b32_dpp v130, v108 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D8F25C: 7F0402FA FF01616C
	v_cndmask_b32_e64 v108, -v108, v108, s0                    // 000000D8F264: D501006C 2002D96C
	v_add_f32_e32 v59, 1.0, v59                                // 000000D8F26C: 067676F2
	v_mov_b32_dpp v116, v76 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D8F270: 7EE802FA FF01614C
	v_cndmask_b32_e64 v76, -v76, v76, s0                       // 000000D8F278: D501004C 2002994C
	v_sub_f32_e32 v66, v107, v66                               // 000000D8F280: 0884856B
	v_mov_b32_dpp v107, v68 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D8F284: 7ED602FA FF016144
	v_cndmask_b32_e64 v68, -v68, v68, s0                       // 000000D8F28C: D5010044 20028944
	v_div_scale_f32 v131, s8, v34, v59, v34                    // 000000D8F294: D6FC0883 048A7722
	v_add_f32_e32 v75, v76, v116                               // 000000D8F29C: 0696E94C
	v_mov_b32_dpp v139, v66 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D8F2A0: 7F1602FA FF016142
	v_cndmask_b32_e64 v66, -v66, v66, s0                       // 000000D8F2A8: D5010042 20028542
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000D8F2B0: BF870233
	v_mov_b32_dpp v116, v75 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D8F2B4: 7EE802FA FF01624B
	v_cndmask_b32_e64 v75, -v75, v75, s1                       // 000000D8F2BC: D501004B 2006974B
	v_add_f32_e32 v68, v68, v107                               // 000000D8F2C4: 0688D744
	v_add_f32_e32 v66, v66, v139                               // 000000D8F2C8: 06851742
	v_mov_b32_dpp v107, v52 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D8F2CC: 7ED602FA FF016234
	v_cndmask_b32_e64 v52, -v52, v52, s1                       // 000000D8F2D4: D5010034 20066934
	v_add_f32_e32 v75, v75, v116                               // 000000D8F2DC: 0696E94B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000D8F2E0: BF8701A4
	v_mov_b32_dpp v139, v66 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D8F2E4: 7F1602FA FF016242
	v_cndmask_b32_e64 v66, -v66, v66, s1                       // 000000D8F2EC: D5010042 20068542
	v_mov_b32_dpp v116, v75 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D8F2F4: 7EE802FA FF01644B
	v_cndmask_b32_e64 v75, -v75, v75, s2                       // 000000D8F2FC: D501004B 200A974B
	v_add_f32_e32 v76, v108, v130                              // 000000D8F304: 0699056C
	s_delay_alu instid0(VALU_DEP_4)                            // 000000D8F308: BF870004
	v_add_f32_e32 v66, v66, v139                               // 000000D8F30C: 06851742
	v_mov_b32_dpp v108, v67 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D8F310: 7ED802FA FF016243
	v_cndmask_b32_e64 v67, -v67, v67, s1                       // 000000D8F318: D5010043 20068743
	v_add_f32_e32 v75, v75, v116                               // 000000D8F320: 0696E94B
	v_mov_b32_dpp v130, v76 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D8F324: 7F0402FA FF01624C
	v_cndmask_b32_e64 v76, -v76, v76, s1                       // 000000D8F32C: D501004C 2006994C
	v_mov_b32_dpp v139, v66 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D8F334: 7F1602FA FF016442
	v_cndmask_b32_e64 v66, -v66, v66, s2                       // 000000D8F33C: D5010042 200A8542
	v_dual_add_f32 v74, v82, v83 :: v_dual_add_f32 v67, v67, v108// 000000D8F344: C908A752 4A42D943
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D8F34C: BF870224
	v_add_f32_e32 v76, v76, v130                               // 000000D8F350: 0699054C
	v_add_f32_e32 v82, v114, v138                              // 000000D8F354: 06A51572
	v_add_f32_e32 v66, v66, v139                               // 000000D8F358: 06851742
	s_delay_alu instid0(VALU_DEP_4)                            // 000000D8F35C: BF870004
	v_mov_b32_dpp v114, v74 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D8F360: 7EE402FA FF01624A
	v_cndmask_b32_e64 v74, -v74, v74, s1                       // 000000D8F368: D501004A 2006954A
	v_mov_b32_dpp v130, v76 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D8F370: 7F0402FA FF01644C
	v_cndmask_b32_e64 v76, -v76, v76, s2                       // 000000D8F378: D501004C 200A994C
	v_mov_b32_dpp v139, v66 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D8F380: 7F1602FA FF016842
	v_cndmask_b32_e64 v66, -v66, v66, s3                       // 000000D8F388: D5010042 200E8542
	v_add_f32_e32 v83, v115, v132                              // 000000D8F390: 06A70973
	v_mov_b32_dpp v142, v58 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D8F394: 7F1C02FA FF01613A
	v_add_f32_e32 v76, v76, v130                               // 000000D8F39C: 0699054C
	v_cndmask_b32_e64 v58, -v58, v58, s0                       // 000000D8F3A0: D501003A 2002753A
	v_add_f32_e32 v66, v66, v139                               // 000000D8F3A8: 06851742
	v_mov_b32_dpp v116, v75 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D8F3AC: 7EE802FA FF01684B
	v_cndmask_b32_e64 v75, -v75, v75, s3                       // 000000D8F3B4: D501004B 200E974B
	v_mov_b32_dpp v130, v76 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D8F3BC: 7F0402FA FF01684C
	v_cndmask_b32_e64 v76, -v76, v76, s3                       // 000000D8F3C4: D501004C 200E994C
	v_mul_f32_e32 v66, 0x3db504f3, v66                         // 000000D8F3CC: 108484FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D8F3D4: BF870224
	v_dual_add_f32 v58, v58, v142 :: v_dual_add_f32 v75, v75, v116// 000000D8F3D8: C9091D3A 3A4AE94B
	v_mov_b32_dpp v108, v67 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D8F3E0: 7ED802FA FF016443
	v_add_f32_e32 v76, v76, v130                               // 000000D8F3E8: 0699054C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D8F3EC: BF870214
	v_fma_mix_f32 v27, v27, v66, neg(0) op_sel_hi:[1,0,0]      // 000000D8F3F0: CC20001B 8A02851B
	v_mov_b32_dpp v142, v58 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D8F3F8: 7F1C02FA FF01623A
	v_cndmask_b32_e64 v58, -v58, v58, s1                       // 000000D8F400: D501003A 2006753A
	v_cndmask_b32_e64 v67, -v67, v67, s2                       // 000000D8F408: D5010043 200A8743
	v_mul_f32_e32 v76, 0x3db504f3, v76                         // 000000D8F410: 109898FF 3DB504F3
	v_mul_f32_e32 v66, 0xbfb8aa3b, v27                         // 000000D8F418: 108436FF BFB8AA3B
	v_mov_b32_dpp v115, v68 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D8F420: 7EE602FA FF016244
	v_add_f32_e32 v58, v58, v142                               // 000000D8F428: 06751D3A
	v_cndmask_b32_e64 v68, -v68, v68, s1                       // 000000D8F42C: D5010044 20068944
	v_fma_mix_f32 v8, v8, v76, neg(0) op_sel_hi:[1,0,0]        // 000000D8F434: CC200008 8A029908
	v_add_f32_e32 v74, v74, v114                               // 000000D8F43C: 0694E54A
	v_exp_f32_e32 v66, v66                                     // 000000D8F440: 7E844B42
	v_mov_b32_dpp v142, v58 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D8F444: 7F1C02FA FF01643A
	v_cndmask_b32_e64 v58, -v58, v58, s2                       // 000000D8F44C: D501003A 200A753A
	v_mul_f32_e32 v51, 0xbfb8aa3b, v8                          // 000000D8F454: 106610FF BFB8AA3B
	v_mov_b32_dpp v114, v74 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D8F45C: 7EE402FA FF01644A
	v_cndmask_b32_e64 v74, -v74, v74, s2                       // 000000D8F464: D501004A 200A954A
	v_mov_b32_dpp v132, v83 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D8F46C: 7F0802FA FF016253
	v_add_f32_e32 v58, v58, v142                               // 000000D8F474: 06751D3A
	v_cndmask_b32_e64 v83, -v83, v83, s1                       // 000000D8F478: D5010053 2006A753
	v_exp_f32_e32 v51, v51                                     // 000000D8F480: 7E664B33
	v_add_f32_e32 v74, v74, v114                               // 000000D8F484: 0694E54A
	v_add_f32_e32 v66, 1.0, v66                                // 000000D8F488: 068484F2
	v_mov_b32_dpp v142, v58 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D8F48C: 7F1C02FA FF01683A
	v_cndmask_b32_e64 v58, -v58, v58, s3                       // 000000D8F494: D501003A 200E753A
	v_mul_f32_e32 v76, 0xbfb8aa3b, v43                         // 000000D8F49C: 109856FF BFB8AA3B
	v_mov_b32_dpp v114, v74 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D8F4A4: 7EE402FA FF01684A
	v_cndmask_b32_e64 v74, -v74, v74, s3                       // 000000D8F4AC: D501004A 200E954A
	v_div_scale_f32 v130, s7, v27, v66, v27                    // 000000D8F4B4: D6FC0782 046E851B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000D8F4BC: BF8701A5
	v_dual_add_f32 v58, v58, v142 :: v_dual_add_f32 v51, 1.0, v51// 000000D8F4C0: C9091D3A 3A3266F2
	v_exp_f32_e32 v76, v76                                     // 000000D8F4C8: 7E984B4C
	v_add_f32_e32 v74, v74, v114                               // 000000D8F4CC: 0694E54A
	v_div_scale_f32 v114, null, v66, v66, v27                  // 000000D8F4D0: D6FC7C72 046E8542
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D8F4D8: BF870193
	v_dual_mul_f32 v58, 0x3db504f3, v58 :: v_dual_mul_f32 v75, 0x3db504f3, v75// 000000D8F4DC: C8C674FF 3A4A96FF 3DB504F3
	v_dual_add_f32 v67, v67, v108 :: v_dual_mul_f32 v74, 0x3db504f3, v74// 000000D8F4E8: C906D943 434A94FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000D8F4F4: BF870123
	v_rcp_f32_e32 v141, v114                                   // 000000D8F4F8: 7F1A5572
	s_waitcnt vmcnt(14)                                        // 000000D8F4FC: BF893BF7
	v_fma_mix_f32 v44, v50, v58, neg(0) op_sel_hi:[1,0,0]      // 000000D8F500: CC20002C 8A027532
	v_add_f32_e32 v68, v68, v115                               // 000000D8F508: 0688E744
	v_mul_f32_e32 v50, 0xbfb8aa3b, v9                          // 000000D8F50C: 106412FF BFB8AA3B
	s_waitcnt vmcnt(13)                                        // 000000D8F514: BF8937F7
	v_fma_mix_f32 v35, v35, v74, neg(0) op_sel_hi:[1,0,0]      // 000000D8F518: CC200023 8A029523
	v_div_scale_f32 v74, null, v51, v51, v8                    // 000000D8F520: D6FC7C4A 04226733
	s_waitcnt vmcnt(11)                                        // 000000D8F528: BF892FF7
	v_fma_mix_f32 v19, v19, v75, neg(0) op_sel_hi:[1,0,0]      // 000000D8F52C: CC200013 8A029713
	v_mov_b32_dpp v108, v67 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D8F534: 7ED802FA FF016843
	v_cndmask_b32_e64 v67, -v67, v67, s3                       // 000000D8F53C: D5010043 200E8743
	v_exp_f32_e32 v50, v50                                     // 000000D8F544: 7E644B32
	v_fma_f32 v151, -v114, v141, 1.0                           // 000000D8F548: D6130097 23CB1B72
	v_add_f32_e32 v83, v83, v132                               // 000000D8F550: 06A70953
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D8F554: BF870193
	v_add_f32_e32 v67, v67, v108                               // 000000D8F558: 0686D943
	v_fmac_f32_e32 v141, v151, v141                            // 000000D8F55C: 571B1B97
	v_mov_b32_dpp v123, v36 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D8F560: 7EF602FA FF016124
	v_cndmask_b32_e64 v36, -v36, v36, s0                       // 000000D8F568: D5010024 20024924
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(VALU_DEP_4)   // 000000D8F570: BF870205
	v_dual_mul_f32 v67, 0x3db504f3, v67 :: v_dual_add_f32 v50, 1.0, v50// 000000D8F574: C8C886FF 433264F2 3DB504F3
	v_mov_b32_dpp v132, v83 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D8F580: 7F0802FA FF016453
	v_cndmask_b32_e64 v83, -v83, v83, s2                       // 000000D8F588: D5010053 200AA753
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D8F590: BF870214
	v_add_f32_e32 v36, v36, v123                               // 000000D8F594: 0648F724
	v_fma_mix_f32 v10, v10, v67, neg(0) op_sel_hi:[1,0,0]      // 000000D8F598: CC20000A 8A02870A
	v_mul_f32_e32 v67, 0xbfb8aa3b, v44                         // 000000D8F5A0: 108658FF BFB8AA3B
	v_mov_b32_dpp v115, v68 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D8F5A8: 7EE602FA FF016444
	v_cndmask_b32_e64 v68, -v68, v68, s2                       // 000000D8F5B0: D5010044 200A8944
	v_mov_b32_dpp v123, v36 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D8F5B8: 7EF602FA FF016224
	v_cndmask_b32_e64 v36, -v36, v36, s1                       // 000000D8F5C0: D5010024 20064924
	v_exp_f32_e32 v67, v67                                     // 000000D8F5C8: 7E864B43
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000D8F5CC: BF870243
	v_dual_add_f32 v83, v83, v132 :: v_dual_add_f32 v68, v68, v115// 000000D8F5D0: C9090953 5344E744
	v_mov_b32_dpp v138, v82 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D8F5D8: 7F1402FA FF016252
	v_cndmask_b32_e64 v82, -v82, v82, s1                       // 000000D8F5E0: D5010052 2006A552
	v_mul_f32_e32 v151, v130, v141                             // 000000D8F5E8: 112F1B82
	v_mov_b32_dpp v132, v83 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D8F5EC: 7F0802FA FF016853
	v_cndmask_b32_e64 v83, -v83, v83, s3                       // 000000D8F5F4: D5010053 200EA753
	v_add_f32_e32 v52, v52, v107                               // 000000D8F5FC: 0668D734
	v_mov_b32_dpp v115, v68 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D8F600: 7EE602FA FF016844
	s_delay_alu instid0(TRANS32_DEP_1)                         // 000000D8F608: BF870005
	v_add_f32_e32 v67, 1.0, v67                                // 000000D8F60C: 068686F2
	v_mov_b32_dpp v122, v60 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D8F610: 7EF402FA FF01613C
	v_cndmask_b32_e64 v60, -v60, v60, s0                       // 000000D8F618: D501003C 2002793C
	v_cndmask_b32_e64 v68, -v68, v68, s3                       // 000000D8F620: D5010044 200E8944
	v_add_f32_e32 v83, v83, v132                               // 000000D8F628: 06A70953
	v_rcp_f32_e32 v132, v74                                    // 000000D8F62C: 7F08554A
	v_mov_b32_dpp v107, v52 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D8F630: 7ED602FA FF016434
	v_add_f32_e32 v60, v60, v122                               // 000000D8F638: 0678F53C
	v_add_f32_e32 v68, v68, v115                               // 000000D8F63C: 0688E744
	v_mul_f32_e32 v83, 0x3db504f3, v83                         // 000000D8F640: 10A6A6FF 3DB504F3
	v_cndmask_b32_e64 v52, -v52, v52, s2                       // 000000D8F648: D5010034 200A6934
	v_div_scale_f32 v115, null, v59, v59, v34                  // 000000D8F650: D6FC7C73 048A773B
	v_mov_b32_dpp v122, v60 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D8F658: 7EF402FA FF01623C
	v_mul_f32_e32 v68, 0x3db504f3, v68                         // 000000D8F660: 108888FF 3DB504F3
	v_fma_mix_f32 v11, v11, v83, neg(0) op_sel_hi:[1,0,0]      // 000000D8F668: CC20000B 8A02A70B
	v_fma_f32 v147, -v74, v132, 1.0                            // 000000D8F670: D6130093 23CB094A
	v_div_scale_f32 v83, s4, v9, v50, v9                       // 000000D8F678: D6FC0453 04266509
	v_cndmask_b32_e64 v60, -v60, v60, s1                       // 000000D8F680: D501003C 2006793C
	v_fma_mix_f32 v42, v42, v68, neg(0) op_sel_hi:[1,0,0]      // 000000D8F688: CC20002A 8A02892A
	v_add_f32_e32 v68, 1.0, v76                                // 000000D8F690: 068898F2
	v_div_scale_f32 v76, vcc_lo, v8, v51, v8                   // 000000D8F694: D6FC6A4C 04226708
	v_fmac_f32_e32 v132, v147, v132                            // 000000D8F69C: 57090993
	v_add_f32_e32 v82, v82, v138                               // 000000D8F6A0: 06A51552
	v_mul_f32_e32 v58, 0xbfb8aa3b, v11                         // 000000D8F6A4: 107416FF BFB8AA3B
	v_div_scale_f32 v116, null, v68, v68, v43                  // 000000D8F6AC: D6FC7C74 04AE8944
	v_div_scale_f32 v145, s9, v43, v68, v43                    // 000000D8F6B4: D6FC0991 04AE892B
	v_mul_f32_e32 v147, v76, v132                              // 000000D8F6BC: 1127094C
	v_mov_b32_dpp v138, v82 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D8F6C0: 7F1402FA FF016452
	v_cndmask_b32_e64 v82, -v82, v82, s2                       // 000000D8F6C8: D5010052 200AA552
	v_exp_f32_e32 v58, v58                                     // 000000D8F6D0: 7E744B3A
	v_rcp_f32_e32 v143, v116                                   // 000000D8F6D4: 7F1E5574
	v_fma_f32 v155, -v74, v147, v76                            // 000000D8F6D8: D613009B 2533274A
	v_add_f32_e32 v36, v36, v123                               // 000000D8F6E0: 0648F724
	v_add_f32_e32 v82, v82, v138                               // 000000D8F6E4: 06A51552
	v_rcp_f32_e32 v142, v115                                   // 000000D8F6E8: 7F1C5573
	v_div_scale_f32 v146, s10, v44, v67, v44                   // 000000D8F6EC: D6FC0A92 04B2872C
	v_fmac_f32_e32 v147, v155, v132                            // 000000D8F6F4: 5727099B
	v_mov_b32_dpp v123, v36 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D8F6F8: 7EF602FA FF016424
	v_mov_b32_dpp v138, v82 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D8F700: 7F1402FA FF016852
	v_cndmask_b32_e64 v82, -v82, v82, s3                       // 000000D8F708: D5010052 200EA552
	v_add_f32_e32 v58, 1.0, v58                                // 000000D8F710: 067474F2
	v_fma_f32 v74, -v74, v147, v76                             // 000000D8F714: D613004A 2533274A
	v_cndmask_b32_e64 v36, -v36, v36, s2                       // 000000D8F71C: D5010024 200A4924
	v_fma_f32 v153, -v116, v143, 1.0                           // 000000D8F724: D6130099 23CB1F74
	v_add_f32_e32 v82, v82, v138                               // 000000D8F72C: 06A51552
	v_fma_f32 v152, -v115, v142, 1.0                           // 000000D8F730: D6130098 23CB1D73
	v_div_fmas_f32 v74, v74, v132, v147                        // 000000D8F738: D637004A 064F094A
	s_mov_b32 vcc_lo, s4                                       // 000000D8F740: BEEA0004
	v_add_f32_e32 v36, v36, v123                               // 000000D8F744: 0648F724
	v_dual_mul_f32 v82, 0x3db504f3, v82 :: v_dual_fmac_f32 v143, v153, v143// 000000D8F748: C8C0A4FF 528F1F99 3DB504F3
	v_add_f32_e32 v60, v60, v122                               // 000000D8F754: 0678F53C
	v_div_fixup_f32 v8, v74, v51, v8                           // 000000D8F758: D6270008 0422674A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D8F760: BF870214
	v_mov_b32_dpp v123, v36 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D8F764: 7EF602FA FF016824
	v_fma_mix_f32 v18, v18, v82, neg(0) op_sel_hi:[1,0,0]      // 000000D8F76C: CC200012 8A02A512
	v_div_scale_f32 v82, null, v50, v50, v9                    // 000000D8F774: D6FC7C52 04266532
	v_cndmask_b32_e64 v36, -v36, v36, s3                       // 000000D8F77C: D5010024 200E4924
	v_mul_f32_e32 v153, v145, v143                             // 000000D8F784: 11331F91
	v_mov_b32_dpp v122, v60 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D8F788: 7EF402FA FF01643C
	v_cndmask_b32_e64 v60, -v60, v60, s2                       // 000000D8F790: D501003C 200A793C
	v_rcp_f32_e32 v138, v82                                    // 000000D8F798: 7F145552
	v_add_f32_e32 v36, v36, v123                               // 000000D8F79C: 0648F724
	v_div_scale_f32 v123, s5, v11, v58, v11                    // 000000D8F7A0: D6FC057B 042E750B
	v_fmac_f32_e32 v142, v152, v142                            // 000000D8F7A8: 571D1D98
	v_fma_f32 v161, -v116, v153, v145                          // 000000D8F7AC: D61300A1 26473374
	s_mov_b32 s4, exec_lo                                      // 000000D8F7B4: BE84007E
	v_mul_f32_e32 v36, 0x3db504f3, v36                         // 000000D8F7B8: 104848FF 3DB504F3
	v_fma_f32 v159, -v114, v151, v130                          // 000000D8F7C0: D613009F 260B2F72
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000D8F7C8: BF870293
	v_dual_mul_f32 v152, v131, v142 :: v_dual_fmac_f32 v153, v161, v143// 000000D8F7CC: C8C11D83 98991FA1
	v_fma_f32 v148, -v82, v138, 1.0                            // 000000D8F7D4: D6130094 23CB1552
	s_waitcnt vmcnt(9)                                         // 000000D8F7DC: BF8927F7
	v_fma_mix_f32 v12, v12, v36, neg(0) op_sel_hi:[1,0,0]      // 000000D8F7E0: CC20000C 8A02490C
	v_fmac_f32_e32 v151, v159, v141                            // 000000D8F7E8: 572F1B9F
	v_fma_f32 v160, -v115, v152, v131                          // 000000D8F7EC: D61300A0 260F3173
	v_fmac_f32_e32 v138, v148, v138                            // 000000D8F7F4: 57151594
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D8F7F8: BF870112
	v_fmac_f32_e32 v152, v160, v142                            // 000000D8F7FC: 57311DA0
	v_mul_f32_e32 v148, v83, v138                              // 000000D8F800: 11291553
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D8F804: BF870091
	v_fma_f32 v156, -v82, v148, v83                            // 000000D8F808: D613009C 254F2952
	v_fmac_f32_e32 v148, v156, v138                            // 000000D8F810: 5729159C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D8F814: BF870091
	v_fma_f32 v76, -v82, v148, v83                             // 000000D8F818: D613004C 254F2952
	v_div_fmas_f32 v76, v76, v138, v148                        // 000000D8F820: D637004C 0653154C
	s_mov_b32 vcc_lo, s5                                       // 000000D8F828: BEEA0005
	s_mov_b32 s5, 0x3db504f3                                   // 000000D8F82C: BE8500FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D8F834: BF870091
	v_div_fixup_f32 v9, v76, v50, v9                           // 000000D8F838: D6270009 0426654C
	v_dual_add_f32 v52, v52, v107 :: v_dual_mul_f32 v9, v10, v9// 000000D8F840: C906D734 3408130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000D8F848: BF8701B1
	v_mov_b32_dpp v107, v52 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D8F84C: 7ED602FA FF016834
	v_cndmask_b32_e64 v52, -v52, v52, s3                       // 000000D8F854: D5010034 200E6934
	s_waitcnt vmcnt(7)                                         // 000000D8F85C: BF891FF7
	v_fma_mix_f32 v9, v84, v9, neg(0) op_sel_hi:[1,0,0]        // 000000D8F860: CC200009 8A021354
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000D8F868: BF870122
	v_add_f32_e32 v52, v52, v107                               // 000000D8F86C: 0668D734
	v_div_scale_f32 v107, null, v58, v58, v11                  // 000000D8F870: D6FC7C6B 042E753A
	v_mul_f32_e32 v52, 0x3db504f3, v52                         // 000000D8F878: 106868FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D8F880: BF870092
	v_rcp_f32_e32 v139, v107                                   // 000000D8F884: 7F16556B
	v_fma_mix_f32 v7, v7, v52, neg(0) op_sel_hi:[1,0,0]        // 000000D8F888: CC200007 8A026907
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000D8F890: BF870291
	v_dual_mul_f32 v52, 0xbfb8aa3b, v18 :: v_dual_mul_f32 v7, v7, v8// 000000D8F894: C8C624FF 34061107 BFB8AA3B
	v_fma_f32 v149, -v107, v139, 1.0                           // 000000D8F8A0: D6130095 23CB176B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D8F8A8: BF870092
	v_exp_f32_e32 v52, v52                                     // 000000D8F8AC: 7E684B34
	v_fmac_f32_e32 v139, v149, v139                            // 000000D8F8B0: 57171795
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(TRANS32_DEP_1)// 000000D8F8B4: BF8702B1
	v_mul_f32_e32 v149, v123, v139                             // 000000D8F8B8: 112B177B
	v_mov_b32_dpp v124, v28 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D8F8BC: 7EF802FA FF01611C
	v_cndmask_b32_e64 v28, -v28, v28, s0                       // 000000D8F8C4: D501001C 2002391C
	v_add_f32_e32 v52, 1.0, v52                                // 000000D8F8CC: 066868F2
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D8F8D0: BF870194
	v_fma_f32 v157, -v107, v149, v123                          // 000000D8F8D4: D613009D 25EF2B6B
	v_add_f32_e32 v28, v28, v124                               // 000000D8F8DC: 0638F91C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D8F8E0: BF870193
	v_div_scale_f32 v108, null, v52, v52, v18                  // 000000D8F8E4: D6FC7C6C 044A6934
	v_fmac_f32_e32 v149, v157, v139                            // 000000D8F8EC: 572B179D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D8F8F0: BF870223
	v_mov_b32_dpp v124, v28 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D8F8F4: 7EF802FA FF01621C
	v_cndmask_b32_e64 v28, -v28, v28, s1                       // 000000D8F8FC: D501001C 2006391C
	v_rcp_f32_e32 v140, v108                                   // 000000D8F904: 7F18556C
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000D8F908: BF870243
	v_fma_f32 v82, -v107, v149, v123                           // 000000D8F90C: D6130052 25EF2B6B
	v_fma_f32 v107, -v114, v151, v130                          // 000000D8F914: D613006B 260B2F72
	v_fma_f32 v114, -v116, v153, v145                          // 000000D8F91C: D6130072 26473374
	v_add_f32_e32 v28, v28, v124                               // 000000D8F924: 0638F91C
	v_div_fmas_f32 v82, v82, v139, v149                        // 000000D8F928: D6370052 06571752
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(TRANS32_DEP_1)// 000000D8F930: BF8702A2
	v_mov_b32_dpp v124, v28 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D8F934: 7EF802FA FF01641C
	v_cndmask_b32_e64 v28, -v28, v28, s2                       // 000000D8F93C: D501001C 200A391C
	v_fma_f32 v150, -v108, v140, 1.0                           // 000000D8F944: D6130096 23CB196C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D8F94C: BF870194
	v_div_fixup_f32 v11, v82, v58, v11                         // 000000D8F950: D627000B 042E7552
	v_add_f32_e32 v28, v28, v124                               // 000000D8F958: 0638F91C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D8F95C: BF870112
	v_dual_fmac_f32 v140, v150, v140 :: v_dual_mul_f32 v11, v35, v11// 000000D8F960: C8071996 8C0A1723
	v_mov_b32_dpp v124, v28 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D8F968: 7EF802FA FF01681C
	v_cndmask_b32_e64 v28, -v28, v28, s3                       // 000000D8F970: D501001C 200E391C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 000000D8F978: BF870151
	v_add_f32_e32 v28, v28, v124                               // 000000D8F97C: 0638F91C
	v_div_scale_f32 v124, s6, v18, v52, v18                    // 000000D8F980: D6FC067C 044A6912
	s_mov_b32 vcc_lo, s6                                       // 000000D8F988: BEEA0006
	v_mul_f32_e32 v28, 0x3db504f3, v28                         // 000000D8F98C: 103838FF 3DB504F3
	v_mul_f32_e32 v150, v124, v140                             // 000000D8F994: 112D197C
	v_fma_mix_f32 v26, v26, v28, neg(0) op_sel_hi:[1,0,0]      // 000000D8F998: CC20001A 8A02391A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D8F9A0: BF870092
	v_fma_f32 v158, -v108, v150, v124                          // 000000D8F9A4: D613009E 25F32D6C
	v_fmac_f32_e32 v150, v158, v140                            // 000000D8F9AC: 572D199E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000D8F9B0: BF870121
	v_fma_f32 v83, -v108, v150, v124                           // 000000D8F9B4: D6130053 25F32D6C
	v_fma_f32 v108, -v115, v152, v131                          // 000000D8F9BC: D613006C 260F3173
	v_div_fmas_f32 v51, v83, v140, v150                        // 000000D8F9C4: D6370033 065B1953
	s_mov_b32 vcc_lo, s7                                       // 000000D8F9CC: BEEA0007
	v_div_fmas_f32 v50, v107, v141, v151                       // 000000D8F9D0: D6370032 065F1B6B
	s_mov_b32 vcc_lo, s8                                       // 000000D8F9D8: BEEA0008
	s_delay_alu instid0(VALU_DEP_2)                            // 000000D8F9DC: BF870002
	v_div_fixup_f32 v8, v51, v52, v18                          // 000000D8F9E0: D6270008 044A6933
	v_div_fmas_f32 v10, v108, v142, v152                       // 000000D8F9E8: D637000A 06631D6C
	s_mov_b32 vcc_lo, s9                                       // 000000D8F9F0: BEEA0009
	v_div_fixup_f32 v27, v50, v66, v27                         // 000000D8F9F4: D627001B 046E8532
	v_add_f32_e32 v60, v60, v122                               // 000000D8F9FC: 0678F53C
	v_div_fmas_f32 v35, v114, v143, v153                       // 000000D8FA00: D6370023 06671F72
	s_mov_b32 vcc_lo, s10                                      // 000000D8FA08: BEEA000A
	v_div_fixup_f32 v10, v10, v59, v34                         // 000000D8FA0C: D627000A 048A770A
	v_dual_mul_f32 v8, v42, v8 :: v_dual_mul_f32 v19, v19, v27 // 000000D8FA14: C8C6112A 08123713
	v_mov_b32_dpp v122, v60 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D8FA1C: 7EF402FA FF01683C
	v_cndmask_b32_e64 v60, -v60, v60, s3                       // 000000D8FA24: D501003C 200E793C
	s_waitcnt vmcnt(6)                                         // 000000D8FA2C: BF891BF7
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D8FA30: BF870113
	v_fma_mix_f32 v8, v90, v8, neg(0) op_sel_hi:[1,0,0]        // 000000D8FA34: CC200008 8A02115A
	v_add_f32_e32 v60, v60, v122                               // 000000D8FA3C: 0678F53C
	v_div_scale_f32 v122, null, v67, v67, v44                  // 000000D8FA40: D6FC7C7A 04B28743
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D8FA48: BF870112
	v_mul_f32_e32 v60, 0x3db504f3, v60                         // 000000D8FA4C: 107878FF 3DB504F3
	v_rcp_f32_e32 v144, v122                                   // 000000D8FA54: 7F20557A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D8FA58: BF870091
	v_fma_mix_f32 v20, v20, v60, neg(0) op_sel_hi:[1,0,0]      // 000000D8FA5C: CC200014 8A027914
	v_mul_f32_e32 v10, v20, v10                                // 000000D8FA64: 10141514
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000D8FA68: BF8701B5
	v_fma_f32 v154, -v122, v144, 1.0                           // 000000D8FA6C: D613009A 23CB217A
	v_div_fixup_f32 v20, v35, v68, v43                         // 000000D8FA74: D6270014 04AE8923
	s_waitcnt vmcnt(5)                                         // 000000D8FA7C: BF8917F7
	v_fma_mix_f32 v10, v91, v10, neg(0) op_sel_hi:[1,0,0]      // 000000D8FA80: CC20000A 8A02155B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D8FA88: BF870193
	v_fmac_f32_e32 v144, v154, v144                            // 000000D8FA8C: 5721219A
	v_mul_f32_e32 v12, v12, v20                                // 000000D8FA90: 1018290C
	s_waitcnt vmcnt(0)                                         // 000000D8FA94: BF8903F7
	v_fma_mix_f32 v20, v7, v106, v9 op_sel_hi:[0,1,0]          // 000000D8FA98: CC200014 1426D507
	v_fma_mix_f32 v7, v7, v106, -v9 op_sel_hi:[0,1,0]          // 000000D8FAA0: CC200007 9426D507
	v_fma_mix_f32 v27, v19, v99, v10 op_sel_hi:[0,1,0]         // 000000D8FAA8: CC20001B 142AC713
	v_mul_f32_e32 v154, v146, v144                             // 000000D8FAB0: 11352192
	v_fma_mix_f32 v10, v19, v99, -v10 op_sel_hi:[0,1,0]        // 000000D8FAB4: CC20000A 942AC713
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D8FABC: BF870092
	v_fma_f32 v162, -v122, v154, v146                          // 000000D8FAC0: D61300A2 264B357A
	v_fmac_f32_e32 v154, v162, v144                            // 000000D8FAC8: 573521A2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D8FACC: BF870091
	v_fma_f32 v18, -v122, v154, v146                           // 000000D8FAD0: D6130012 264B357A
	v_div_fmas_f32 v18, v18, v144, v154                        // 000000D8FAD8: D6370012 066B2112
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D8FAE0: BF870091
	v_div_fixup_f32 v18, v18, v67, v44                         // 000000D8FAE4: D6270012 04B28712
	v_mul_f32_e32 v18, v26, v18                                // 000000D8FAEC: 1024251A
	v_fma_mix_f32 v26, v11, v100, v8 op_sel_hi:[0,1,0]         // 000000D8FAF0: CC20001A 1422C90B
	v_fma_mix_f32 v8, v11, v100, -v8 op_sel_hi:[0,1,0]         // 000000D8FAF8: CC200008 9422C90B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D8FB00: BF870193
	v_fma_mix_f32 v18, v92, v18, neg(0) op_sel_hi:[1,0,0]      // 000000D8FB04: CC200012 8A02255C
	v_add_f32_e32 v34, v20, v26                                // 000000D8FB0C: 06443514
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 000000D8FB10: BF870252
	v_fma_mix_f32 v28, v12, v98, v18 op_sel_hi:[0,1,0]         // 000000D8FB14: CC20001C 144AC50C
	v_fma_mix_f32 v11, v12, v98, -v18 op_sel_hi:[0,1,0]        // 000000D8FB1C: CC20000B 944AC50C
	v_sub_f32_e32 v12, v20, v26                                // 000000D8FB24: 08183514
	v_add_f32_e32 v18, v7, v8                                  // 000000D8FB28: 06241107
	v_sub_f32_e32 v7, v7, v8                                   // 000000D8FB2C: 080E1107
	v_dual_add_f32 v35, v27, v28 :: v_dual_add_f32 v8, v10, v11// 000000D8FB30: C908391B 2308170A
	v_sub_f32_e32 v20, v27, v28                                // 000000D8FB38: 0828391B
	v_sub_f32_e32 v10, v10, v11                                // 000000D8FB3C: 0814170A
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000D8FB40: BF870123
	v_add_f32_e32 v9, v34, v35                                 // 000000D8FB44: 06124722
	v_sub_f32_e32 v11, v34, v35                                // 000000D8FB48: 08164722
	v_mov_b32_dpp v19, v9 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D8FB4C: 7E2602FA FF016109
	v_cndmask_b32_e64 v9, -v9, v9, s0                          // 000000D8FB54: D5010009 20021309
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D8FB5C: BF870113
	v_cndmask_b32_e64 v35, -v11, v11, s0                       // 000000D8FB60: D5010023 2002170B
	v_add_f32_e32 v9, v9, v19                                  // 000000D8FB68: 06122709
	v_add_f32_e32 v19, v18, v8                                 // 000000D8FB6C: 06261112
	v_sub_f32_e32 v18, v18, v8                                 // 000000D8FB70: 08241112
	v_add_f32_e32 v8, v12, v20                                 // 000000D8FB74: 0610290C
	v_sub_f32_e32 v20, v12, v20                                // 000000D8FB78: 0828290C
	v_mov_b32_dpp v26, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D8FB7C: 7E3402FA FF016209
	v_cndmask_b32_e64 v9, -v9, v9, s1                          // 000000D8FB84: D5010009 20061309
	v_mov_b32_dpp v27, v19 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D8FB8C: 7E3602FA FF016113
	v_cndmask_b32_e64 v19, -v19, v19, s0                       // 000000D8FB94: D5010013 20022713
	v_mov_b32_dpp v28, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D8FB9C: 7E3802FA FF016108
	v_cndmask_b32_e64 v8, -v8, v8, s0                          // 000000D8FBA4: D5010008 20021108
	v_mov_b32_dpp v36, v20 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D8FBAC: 7E4802FA FF016114
	v_cndmask_b32_e64 v20, -v20, v20, s0                       // 000000D8FBB4: D5010014 20022914
	v_dual_add_f32 v9, v9, v26 :: v_dual_add_f32 v12, v19, v27 // 000000D8FBBC: C9083509 090C3713
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D8FBC4: BF870114
	v_dual_add_f32 v19, v7, v10 :: v_dual_add_f32 v8, v8, v28  // 000000D8FBC8: C9081507 13083908
	v_mov_b32_dpp v26, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D8FBD0: 7E3402FA FF016409
	v_cndmask_b32_e64 v9, -v9, v9, s2                          // 000000D8FBD8: D5010009 200A1309
	s_delay_alu instid0(VALU_DEP_4)                            // 000000D8FBE0: BF870004
	v_mov_b32_dpp v27, v12 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D8FBE4: 7E3602FA FF01620C
	v_cndmask_b32_e64 v12, -v12, v12, s1                       // 000000D8FBEC: D501000C 2006190C
	v_mov_b32_dpp v28, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D8FBF4: 7E3802FA FF016208
	v_cndmask_b32_e64 v8, -v8, v8, s1                          // 000000D8FBFC: D5010008 20061108
	v_mov_b32_dpp v34, v19 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D8FC04: 7E4402FA FF016113
	v_cndmask_b32_e64 v19, -v19, v19, s0                       // 000000D8FC0C: D5010013 20022713
	v_dual_add_f32 v12, v12, v27 :: v_dual_sub_f32 v27, v7, v10// 000000D8FC14: C90A370C 0C1A1507
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D8FC1C: BF870194
	v_dual_add_f32 v8, v8, v28 :: v_dual_add_f32 v7, v9, v26   // 000000D8FC20: C9083908 08063509
	v_add_f32_e32 v9, v19, v34                                 // 000000D8FC28: 06124513
	v_mov_b32_dpp v34, v11 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D8FC2C: 7E4402FA FF01610B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D8FC34: BF870214
	v_mov_b32_dpp v42, v27 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D8FC38: 7E5402FA FF01611B
	v_mov_b32_dpp v19, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D8FC40: 7E2602FA FF016408
	v_cndmask_b32_e64 v8, -v8, v8, s2                          // 000000D8FC48: D5010008 200A1108
	v_mov_b32_dpp v26, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D8FC50: 7E3402FA FF016209
	v_cndmask_b32_e64 v28, -v9, v9, s1                         // 000000D8FC58: D501001C 20061309
	v_cndmask_b32_e64 v27, -v27, v27, s0                       // 000000D8FC60: D501001B 2002371B
	v_mov_b32_dpp v10, v12 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D8FC68: 7E1402FA FF01640C
	v_add_f32_e32 v11, v8, v19                                 // 000000D8FC70: 06162708
	v_cndmask_b32_e64 v12, -v12, v12, s2                       // 000000D8FC74: D501000C 200A190C
	v_add_f32_e32 v19, v28, v26                                // 000000D8FC7C: 0626351C
	v_add_f32_e32 v26, v35, v34                                // 000000D8FC80: 06344523
	v_mov_b32_dpp v35, v18 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D8FC84: 7E4602FA FF016112
	v_cndmask_b32_e64 v18, -v18, v18, s0                       // 000000D8FC8C: D5010012 20022512
	v_add_f32_e32 v9, v12, v10                                 // 000000D8FC94: 0612150C
	v_mov_b32_dpp v28, v19 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D8FC98: 7E3802FA FF016413
	v_cndmask_b32_e64 v19, -v19, v19, s2                       // 000000D8FCA0: D5010013 200A2713
	v_mov_b32_dpp v34, v26 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D8FCA8: 7E4402FA FF01621A
	v_cndmask_b32_e64 v26, -v26, v26, s1                       // 000000D8FCB0: D501001A 2006351A
	v_add_f32_e32 v35, v18, v35                                // 000000D8FCB8: 06464712
	v_mov_b32_dpp v8, v7 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D8FCBC: 7E1002FA FF016807
	v_add_f32_e32 v18, v19, v28                                // 000000D8FCC4: 06243913
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000D8FCC8: BF870244
	v_dual_add_f32 v19, v20, v36 :: v_dual_add_f32 v20, v26, v34// 000000D8FCCC: C9084914 1314451A
	v_add_f32_e32 v26, v27, v42                                // 000000D8FCD4: 0634551B
	v_mov_b32_dpp v27, v35 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D8FCD8: 7E3602FA FF016223
	v_cndmask_b32_e64 v28, -v35, v35, s1                       // 000000D8FCE0: D501001C 20064723
	v_mov_b32_dpp v34, v19 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D8FCE8: 7E4402FA FF016213
	v_cndmask_b32_e64 v19, -v19, v19, s1                       // 000000D8FCF0: D5010013 20062713
	v_mov_b32_dpp v35, v26 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D8FCF8: 7E4602FA FF01621A
	v_cndmask_b32_e64 v26, -v26, v26, s1                       // 000000D8FD00: D501001A 2006351A
	v_add_f32_e32 v27, v28, v27                                // 000000D8FD08: 0636371C
	v_mov_b32_dpp v28, v20 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D8FD0C: 7E3802FA FF016414
	v_add_f32_e32 v19, v19, v34                                // 000000D8FD14: 06264513
	v_cndmask_b32_e64 v20, -v20, v20, s2                       // 000000D8FD18: D5010014 200A2914
	v_add_f32_e32 v26, v26, v35                                // 000000D8FD20: 0634471A
	v_mov_b32_dpp v34, v27 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D8FD24: 7E4402FA FF01641B
	v_cndmask_b32_e64 v35, -v27, v27, s2                       // 000000D8FD2C: D5010023 200A371B
	v_mov_b32_dpp v36, v19 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D8FD34: 7E4802FA FF016413
	v_cndmask_b32_e64 v42, -v19, v19, s2                       // 000000D8FD3C: D501002A 200A2713
	v_mov_b32_dpp v43, v26 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D8FD44: 7E5602FA FF01641A
	v_cndmask_b32_e64 v26, -v26, v26, s2                       // 000000D8FD4C: D501001A 200A351A
	v_dual_add_f32 v27, v20, v28 :: v_dual_add_f32 v28, v35, v34// 000000D8FD54: C9083914 1B1C4523
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D8FD5C: BF870224
	v_add_f32_e32 v35, v42, v36                                // 000000D8FD60: 0646492A
	v_mov_b32_dpp v10, v9 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D8FD64: 7E1402FA FF016809
	v_add_f32_e32 v42, v26, v43                                // 000000D8FD6C: 0654571A
	v_mov_b32_dpp v12, v11 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D8FD70: 7E1802FA FF01680B
	v_mov_b32_dpp v19, v18 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D8FD78: 7E2602FA FF016812
	v_add_nc_u32_e32 v20, 4, v6                                // 000000D8FD80: 4A280C84
	v_mov_b32_dpp v26, v27 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D8FD84: 7E3402FA FF01681B
	v_mov_b32_dpp v34, v28 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D8FD8C: 7E4402FA FF01681C
	v_mov_b32_dpp v36, v35 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D8FD94: 7E4802FA FF016823
	v_mov_b32_dpp v43, v42 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D8FD9C: 7E5602FA FF01682A
	.long 0xd4c4007e                                           // 000000D8FDA4: D4C4007E
	v_cndmask_b32_e32 v1, s23, v20, vcc_lo                     // 000000D8FDA8: 02022817
	s_cbranch_execz 60                                         // 000000D8FDAC: BFA5003C <_ZN7halogen12_GLOBAL__N_111k_ht_moe_guILi3ELi8ELi1EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_S5_PDF16_+0x3ba0>
	v_cndmask_b32_e64 v28, -v28, v28, s3                       // 000000D8FDB0: D501001C 200E391C
	v_cndmask_b32_e64 v7, -v7, v7, s3                          // 000000D8FDB8: D5010007 200E0F07
	v_cndmask_b32_e64 v9, -v9, v9, s3                          // 000000D8FDC0: D5010009 200E1309
	v_cndmask_b32_e64 v11, -v11, v11, s3                       // 000000D8FDC8: D501000B 200E170B
	v_cndmask_b32_e64 v18, -v18, v18, s3                       // 000000D8FDD0: D5010012 200E2512
	v_cndmask_b32_e64 v27, -v27, v27, s3                       // 000000D8FDD8: D501001B 200E371B
	v_cndmask_b32_e64 v42, -v42, v42, s3                       // 000000D8FDE0: D501002A 200E552A
	v_cndmask_b32_e64 v35, -v35, v35, s3                       // 000000D8FDE8: D5010023 200E4723
	v_dual_add_f32 v28, v28, v34 :: v_dual_add_f32 v7, v7, v8  // 000000D8FDF0: C908451C 1C061107
	v_dual_add_f32 v8, v9, v10 :: v_dual_add_f32 v9, v11, v12  // 000000D8FDF8: C9081509 0808190B
	v_mad_i64_i32 v[11:12], null, 0x500, v20, v[0:1]           // 000000D8FE00: D6FF7C0B 040228FF 00000500
	v_add_f32_e32 v10, v18, v19                                // 000000D8FE0C: 06142712
	v_add_f32_e32 v26, v27, v26                                // 000000D8FE10: 0634351B
	v_dual_add_f32 v42, v42, v43 :: v_dual_add_f32 v35, v35, v36// 000000D8FE14: C908572A 2A224923
	v_fma_mixlo_f16 v7, v7, s5, 0                              // 000000D8FE1C: CC210007 02000B07
	v_fma_mixhi_f16 v7, v8, s5, 0                              // 000000D8FE24: CC220007 02000B08
	v_fma_mixlo_f16 v8, v9, s5, 0                              // 000000D8FE2C: CC210008 02000B09
	v_fma_mixhi_f16 v8, v10, s5, 0                             // 000000D8FE34: CC220008 02000B0A
	v_fma_mixlo_f16 v9, v26, s5, 0                             // 000000D8FE3C: CC210009 02000B1A
	v_fma_mixhi_f16 v9, v28, s5, 0                             // 000000D8FE44: CC220009 02000B1C
	v_fma_mixlo_f16 v10, v35, s5, 0                            // 000000D8FE4C: CC21000A 02000B23
	v_fma_mixhi_f16 v10, v42, s5, 0                            // 000000D8FE54: CC22000A 02000B2A
	s_clause 0x7                                               // 000000D8FE5C: BF850007
	global_store_b16 v[11:12], v7, off                         // 000000D8FE60: DC660000 007C070B
	global_store_d16_hi_b16 v[11:12], v7, off offset:32        // 000000D8FE68: DC960020 007C070B
	global_store_b16 v[11:12], v8, off offset:64               // 000000D8FE70: DC660040 007C080B
	global_store_d16_hi_b16 v[11:12], v8, off offset:96        // 000000D8FE78: DC960060 007C080B
	global_store_b16 v[11:12], v9, off offset:128              // 000000D8FE80: DC660080 007C090B
	global_store_d16_hi_b16 v[11:12], v9, off offset:160       // 000000D8FE88: DC9600A0 007C090B
	global_store_b16 v[11:12], v10, off offset:192             // 000000D8FE90: DC6600C0 007C0A0B
	global_store_d16_hi_b16 v[11:12], v10, off offset:224      // 000000D8FE98: DC9600E0 007C0A0B
	s_or_b32 exec_lo, exec_lo, s4                              // 000000D8FEA0: 8C7E047E
	s_clause 0xb                                               // 000000D8FEA4: BF85000B
	global_load_d16_b16 v7, v[2:3], off offset:1280            // 000000D8FEA8: DC820500 077C0002
	global_load_d16_b16 v10, v[2:3], off offset:1312           // 000000D8FEB0: DC820520 0A7C0002
	global_load_d16_b16 v8, v[2:3], off                        // 000000D8FEB8: DC820000 087C0002
	global_load_d16_b16 v9, v[2:3], off offset:32              // 000000D8FEC0: DC820020 097C0002
	global_load_d16_b16 v11, v[2:3], off offset:64             // 000000D8FEC8: DC820040 0B7C0002
	global_load_d16_b16 v12, v[2:3], off offset:96             // 000000D8FED0: DC820060 0C7C0002
	global_load_d16_b16 v26, v[2:3], off offset:128            // 000000D8FED8: DC820080 1A7C0002
	global_load_d16_b16 v27, v[2:3], off offset:160            // 000000D8FEE0: DC8200A0 1B7C0002
	global_load_d16_b16 v35, v[2:3], off offset:192            // 000000D8FEE8: DC8200C0 237C0002
	global_load_d16_b16 v36, v[2:3], off offset:224            // 000000D8FEF0: DC8200E0 247C0002
	global_load_d16_b16 v28, v[2:3], off offset:1344           // 000000D8FEF8: DC820540 1C7C0002
	global_load_d16_b16 v34, v[2:3], off offset:1376           // 000000D8FF00: DC820560 227C0002
	v_add_f32_e32 v66, v53, v45                                // 000000D8FF08: 06845B35
	v_sub_f32_e32 v45, v53, v45                                // 000000D8FF0C: 085A5B35
	v_add_f32_e32 v53, v37, v29                                // 000000D8FF10: 066A3B25
	v_sub_f32_e32 v29, v37, v29                                // 000000D8FF14: 083A3B25
	v_add_f32_e32 v37, v21, v13                                // 000000D8FF18: 064A1B15
	v_add_f32_e32 v51, v101, v93                               // 000000D8FF1C: 0666BB65
	s_delay_alu instid0(VALU_DEP_2)                            // 000000D8FF20: BF870002
	v_add_f32_e32 v84, v53, v37                                // 000000D8FF24: 06A84B35
	v_add_f32_e32 v58, v85, v77                                // 000000D8FF28: 06749B55
	v_add_f32_e32 v44, v117, v109                              // 000000D8FF2C: 0658DB75
	v_sub_f32_e32 v43, v133, v125                              // 000000D8FF30: 0856FB85
	v_sub_f32_e32 v50, v117, v109                              // 000000D8FF34: 0864DB75
	v_add_f32_e32 v42, v133, v125                              // 000000D8FF38: 0654FB85
	v_sub_f32_e32 v59, v85, v77                                // 000000D8FF3C: 08769B55
	v_add_f32_e32 v60, v69, v61                                // 000000D8FF40: 06787B45
	v_sub_f32_e32 v52, v101, v93                               // 000000D8FF44: 0868BB65
	v_sub_f32_e32 v61, v69, v61                                // 000000D8FF48: 087A7B45
	v_add_f32_e32 v83, v42, v44                                // 000000D8FF4C: 06A6592A
	v_sub_f32_e32 v42, v42, v44                                // 000000D8FF50: 0854592A
	v_add_f32_e32 v44, v43, v50                                // 000000D8FF54: 0658652B
	v_sub_f32_e32 v43, v43, v50                                // 000000D8FF58: 0856652B
	v_add_f32_e32 v50, v51, v58                                // 000000D8FF5C: 06647533
	v_dual_sub_f32 v51, v51, v58 :: v_dual_add_f32 v58, v52, v59// 000000D8FF60: C9487533 333A7734
	v_sub_f32_e32 v21, v21, v13                                // 000000D8FF68: 082A1B15
	s_clause 0x3                                               // 000000D8FF6C: BF850003
	global_load_d16_b16 v18, v[2:3], off offset:1408           // 000000D8FF70: DC820580 127C0002
	global_load_d16_b16 v19, v[2:3], off offset:1440           // 000000D8FF78: DC8205A0 137C0002
	global_load_d16_b16 v13, v[2:3], off offset:1472           // 000000D8FF80: DC8205C0 0D7C0002
	global_load_d16_b16 v20, v[2:3], off offset:1504           // 000000D8FF88: DC8205E0 147C0002
	s_clause 0x7                                               // 000000D8FF90: BF850007
	global_load_d16_b16 v67, v[4:5], off offset:32             // 000000D8FF94: DC820020 437C0004
	global_load_d16_b16 v68, v[4:5], off offset:96             // 000000D8FF9C: DC820060 447C0004
	global_load_d16_b16 v69, v[4:5], off offset:160            // 000000D8FFA4: DC8200A0 457C0004
	global_load_d16_b16 v74, v[4:5], off offset:224            // 000000D8FFAC: DC8200E0 4A7C0004
	global_load_d16_b16 v75, v[4:5], off offset:192            // 000000D8FFB4: DC8200C0 4B7C0004
	global_load_d16_b16 v76, v[4:5], off offset:128            // 000000D8FFBC: DC820080 4C7C0004
	global_load_d16_b16 v77, v[4:5], off offset:64             // 000000D8FFC4: DC820040 4D7C0004
	global_load_d16_b16 v82, v[4:5], off                       // 000000D8FFCC: DC820000 527C0004
	v_sub_f32_e32 v52, v52, v59                                // 000000D8FFD4: 08687734
	v_dual_add_f32 v59, v60, v66 :: v_dual_add_f32 v90, v42, v51// 000000D8FFD8: C908853C 3B5A672A
	v_dual_sub_f32 v37, v53, v37 :: v_dual_sub_f32 v42, v42, v51// 000000D8FFE0: C94A4B35 252A672A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D8FFE8: BF870193
	v_add_f32_e32 v85, v43, v52                                // 000000D8FFEC: 06AA692B
	v_dual_sub_f32 v53, v59, v84 :: v_dual_sub_f32 v60, v60, v66// 000000D8FFF0: C94AA93B 353C853C
	v_add_f32_e32 v66, v61, v45                                // 000000D8FFF8: 06845B3D
	v_sub_f32_e32 v45, v61, v45                                // 000000D8FFFC: 085A5B3D
	v_add_f32_e32 v61, v29, v21                                // 000000D90000: 067A2B1D
	v_sub_f32_e32 v21, v29, v21                                // 000000D90004: 082A2B1D
	v_sub_f32_e32 v43, v43, v52                                // 000000D90008: 0856692B
	v_add_f32_e32 v29, v59, v84                                // 000000D9000C: 063AA93B
	v_add_f32_e32 v84, v83, v50                                // 000000D90010: 06A86553
	v_sub_f32_e32 v50, v83, v50                                // 000000D90014: 08646553
	v_mov_b32_dpp v91, v53 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D90018: 7EB602FA FF016135
	v_cndmask_b32_e64 v53, -v53, v53, s0                       // 000000D90020: D5010035 20026B35
	v_mov_b32_dpp v51, v29 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D90028: 7E6602FA FF01611D
	v_mov_b32_dpp v99, v84 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D90030: 7EC602FA FF016154
	v_cndmask_b32_e64 v84, -v84, v84, s0                       // 000000D90038: D5010054 2002A954
	v_add_f32_e32 v59, v66, v61                                // 000000D90040: 06767B42
	v_sub_f32_e32 v61, v66, v61                                // 000000D90044: 087A7B42
	v_cndmask_b32_e64 v29, -v29, v29, s0                       // 000000D90048: D501001D 20023B1D
	v_add_f32_e32 v66, v60, v37                                // 000000D90050: 06844B3C
	v_mov_b32_dpp v107, v50 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D90054: 7ED602FA FF016132
	v_mov_b32_dpp v52, v59 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D9005C: 7E6802FA FF01613B
	v_cndmask_b32_e64 v50, -v50, v50, s0                       // 000000D90064: D5010032 20026532
	v_sub_f32_e32 v37, v60, v37                                // 000000D9006C: 084A4B3C
	v_add_f32_e32 v60, v45, v21                                // 000000D90070: 06782B2D
	v_sub_f32_e32 v21, v45, v21                                // 000000D90074: 082A2B2D
	v_add_f32_e32 v45, v44, v58                                // 000000D90078: 065A752C
	v_sub_f32_e32 v44, v44, v58                                // 000000D9007C: 0858752C
	v_cndmask_b32_e64 v58, -v59, v59, s0                       // 000000D90080: D501003A 2002773B
	v_add_f32_e32 v29, v29, v51                                // 000000D90088: 063A671D
	v_mov_b32_dpp v101, v90 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D9008C: 7ECA02FA FF01615A
	v_cndmask_b32_e64 v90, -v90, v90, s0                       // 000000D90094: D501005A 2002B55A
	v_mov_b32_dpp v108, v44 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D9009C: 7ED802FA FF01612C
	v_cndmask_b32_e64 v44, -v44, v44, s0                       // 000000D900A4: D501002C 2002592C
	v_add_f32_e32 v51, v58, v52                                // 000000D900AC: 0666693A
	v_mov_b32_dpp v83, v60 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D900B0: 7EA602FA FF01613C
	v_cndmask_b32_e64 v60, -v60, v60, s0                       // 000000D900B8: D501003C 2002793C
	v_mov_b32_dpp v109, v42 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D900C0: 7EDA02FA FF01612A
	v_cndmask_b32_e64 v42, -v42, v42, s0                       // 000000D900C8: D501002A 2002552A
	v_add_f32_e32 v44, v44, v108                               // 000000D900D0: 0658D92C
	v_mov_b32_dpp v92, v61 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D900D4: 7EB802FA FF01613D
	v_cndmask_b32_e64 v61, -v61, v61, s0                       // 000000D900DC: D501003D 20027B3D
	v_add_f32_e32 v58, v60, v83                                // 000000D900E4: 0674A73C
	v_add_f32_e32 v60, v84, v99                                // 000000D900E8: 0678C754
	v_mov_b32_dpp v59, v66 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D900EC: 7E7602FA FF016142
	v_cndmask_b32_e64 v66, -v66, v66, s0                       // 000000D900F4: D5010042 20028542
	v_add_f32_e32 v53, v53, v91                                // 000000D900FC: 066AB735
	v_add_f32_e32 v50, v50, v107                               // 000000D90100: 0664D732
	v_add_f32_e32 v42, v42, v109                               // 000000D90104: 0654DB2A
	v_mov_b32_dpp v93, v37 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D90108: 7EBA02FA FF016125
	v_dual_add_f32 v52, v66, v59 :: v_dual_add_f32 v59, v61, v92// 000000D90110: C9087742 343AB93D
	v_add_f32_e32 v66, v90, v101                               // 000000D90118: 0684CB5A
	v_mov_b32_dpp v90, v58 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D9011C: 7EB402FA FF01623A
	v_cndmask_b32_e64 v58, -v58, v58, s1                       // 000000D90124: D501003A 2006753A
	v_cndmask_b32_e64 v37, -v37, v37, s0                       // 000000D9012C: D5010025 20024B25
	v_mov_b32_dpp v100, v45 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D90134: 7EC802FA FF01612D
	v_cndmask_b32_e64 v45, -v45, v45, s0                       // 000000D9013C: D501002D 20025B2D
	v_mov_b32_dpp v106, v85 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D90144: 7ED402FA FF016155
	v_cndmask_b32_e64 v85, -v85, v85, s0                       // 000000D9014C: D5010055 2002AB55
	v_mov_b32_dpp v114, v43 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D90154: 7EE402FA FF01612B
	v_cndmask_b32_e64 v43, -v43, v43, s0                       // 000000D9015C: D501002B 2002572B
	v_mov_b32_dpp v83, v29 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D90164: 7EA602FA FF01621D
	v_cndmask_b32_e64 v29, -v29, v29, s1                       // 000000D9016C: D501001D 20063B1D
	v_mov_b32_dpp v99, v60 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D90174: 7EC602FA FF01623C
	v_cndmask_b32_e64 v60, -v60, v60, s1                       // 000000D9017C: D501003C 2006793C
	v_mov_b32_dpp v101, v66 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D90184: 7ECA02FA FF016242
	v_cndmask_b32_e64 v66, -v66, v66, s1                       // 000000D9018C: D5010042 20068542
	v_mov_b32_dpp v107, v50 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D90194: 7ED602FA FF016232
	v_cndmask_b32_e64 v50, -v50, v50, s1                       // 000000D9019C: D5010032 20066532
	v_mov_b32_dpp v109, v42 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D901A4: 7EDA02FA FF01622A
	v_cndmask_b32_e64 v42, -v42, v42, s1                       // 000000D901AC: D501002A 2006552A
	v_add_f32_e32 v58, v58, v90                                // 000000D901B4: 0674B53A
	v_mov_b32_dpp v98, v21 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D901B8: 7EC402FA FF016115
	v_cndmask_b32_e64 v21, -v21, v21, s0                       // 000000D901C0: D5010015 20022B15
	v_dual_add_f32 v37, v37, v93 :: v_dual_add_f32 v60, v60, v99// 000000D901C8: C908BB25 253CC73C
	v_dual_add_f32 v45, v45, v100 :: v_dual_add_f32 v66, v66, v101// 000000D901D0: C908C92D 2D42CB42
	v_dual_add_f32 v43, v43, v114 :: v_dual_add_f32 v50, v50, v107// 000000D901D8: C908E52B 2B32D732
	v_mov_b32_dpp v91, v53 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D901E0: 7EB602FA FF016235
	v_cndmask_b32_e64 v53, -v53, v53, s1                       // 000000D901E8: D5010035 20066B35
	v_mov_b32_dpp v92, v59 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D901F0: 7EB802FA FF01623B
	v_cndmask_b32_e64 v59, -v59, v59, s1                       // 000000D901F8: D501003B 2006773B
	v_mov_b32_dpp v108, v44 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D90200: 7ED802FA FF01622C
	v_cndmask_b32_e64 v44, -v44, v44, s1                       // 000000D90208: D501002C 2006592C
	v_add_f32_e32 v61, v85, v106                               // 000000D90210: 067AD555
	v_mov_b32_dpp v85, v52 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D90214: 7EAA02FA FF016234
	v_cndmask_b32_e64 v52, -v52, v52, s1                       // 000000D9021C: D5010034 20066934
	v_add_f32_e32 v21, v21, v98                                // 000000D90224: 062AC515
	v_dual_add_f32 v29, v29, v83 :: v_dual_add_f32 v42, v42, v109// 000000D90228: C908A71D 1D2ADB2A
	v_mov_b32_dpp v90, v58 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D90230: 7EB402FA FF01643A
	v_cndmask_b32_e64 v58, -v58, v58, s2                       // 000000D90238: D501003A 200A753A
	v_mov_b32_dpp v100, v45 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D90240: 7EC802FA FF01622D
	v_cndmask_b32_e64 v45, -v45, v45, s1                       // 000000D90248: D501002D 20065B2D
	v_add_f32_e32 v52, v52, v85                                // 000000D90250: 0668AB34
	v_mov_b32_dpp v98, v21 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D90254: 7EC402FA FF016215
	v_cndmask_b32_e64 v21, -v21, v21, s1                       // 000000D9025C: D5010015 20062B15
	v_dual_add_f32 v53, v53, v91 :: v_dual_add_f32 v58, v58, v90// 000000D90264: C908B735 353AB53A
	v_add_f32_e32 v44, v44, v108                               // 000000D9026C: 0658D92C
	v_mov_b32_dpp v106, v61 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D90270: 7ED402FA FF01623D
	v_cndmask_b32_e64 v61, -v61, v61, s1                       // 000000D90278: D501003D 20067B3D
	v_mov_b32_dpp v83, v29 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D90280: 7EA602FA FF01641D
	v_cndmask_b32_e64 v29, -v29, v29, s2                       // 000000D90288: D501001D 200A3B1D
	v_mov_b32_dpp v99, v60 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D90290: 7EC602FA FF01643C
	v_cndmask_b32_e64 v60, -v60, v60, s2                       // 000000D90298: D501003C 200A793C
	v_add_f32_e32 v59, v59, v92                                // 000000D902A0: 0676B93B
	v_mov_b32_dpp v101, v66 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D902A4: 7ECA02FA FF016442
	v_cndmask_b32_e64 v66, -v66, v66, s2                       // 000000D902AC: D5010042 200A8542
	v_mov_b32_dpp v107, v50 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D902B4: 7ED602FA FF016432
	v_cndmask_b32_e64 v50, -v50, v50, s2                       // 000000D902BC: D5010032 200A6532
	v_mov_b32_dpp v109, v42 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D902C4: 7EDA02FA FF01642A
	v_cndmask_b32_e64 v42, -v42, v42, s2                       // 000000D902CC: D501002A 200A552A
	v_mov_b32_dpp v84, v51 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D902D4: 7EA802FA FF016233
	v_cndmask_b32_e64 v51, -v51, v51, s1                       // 000000D902DC: D5010033 20066733
	v_dual_add_f32 v21, v21, v98 :: v_dual_add_f32 v66, v66, v101// 000000D902E4: C908C515 1542CB42
	v_dual_add_f32 v45, v45, v100 :: v_dual_add_f32 v50, v50, v107// 000000D902EC: C908C92D 2D32D732
	v_dual_add_f32 v61, v61, v106 :: v_dual_add_f32 v42, v42, v109// 000000D902F4: C908D53D 3D2ADB2A
	v_mov_b32_dpp v85, v52 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D902FC: 7EAA02FA FF016434
	v_cndmask_b32_e64 v52, -v52, v52, s2                       // 000000D90304: D5010034 200A6934
	v_add_f32_e32 v60, v60, v99                                // 000000D9030C: 0678C73C
	v_mov_b32_dpp v92, v59 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D90310: 7EB802FA FF01643B
	v_cndmask_b32_e64 v59, -v59, v59, s2                       // 000000D90318: D501003B 200A773B
	v_mov_b32_dpp v90, v58 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D90320: 7EB402FA FF01683A
	v_cndmask_b32_e64 v58, -v58, v58, s3                       // 000000D90328: D501003A 200E753A
	v_add_f32_e32 v29, v29, v83                                // 000000D90330: 063AA71D
	v_mov_b32_dpp v114, v43 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D90334: 7EE402FA FF01622B
	v_cndmask_b32_e64 v43, -v43, v43, s1                       // 000000D9033C: D501002B 2006572B
	v_dual_add_f32 v51, v51, v84 :: v_dual_add_f32 v52, v52, v85// 000000D90344: C908A933 3334AB34
	v_mov_b32_dpp v91, v53 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D9034C: 7EB602FA FF016435
	v_cndmask_b32_e64 v53, -v53, v53, s2                       // 000000D90354: D5010035 200A6B35
	v_mov_b32_dpp v98, v21 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D9035C: 7EC402FA FF016415
	v_cndmask_b32_e64 v21, -v21, v21, s2                       // 000000D90364: D5010015 200A2B15
	v_mov_b32_dpp v101, v66 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D9036C: 7ECA02FA FF016842
	v_cndmask_b32_e64 v66, -v66, v66, s3                       // 000000D90374: D5010042 200E8542
	v_mov_b32_dpp v107, v50 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D9037C: 7ED602FA FF016832
	v_cndmask_b32_e64 v50, -v50, v50, s3                       // 000000D90384: D5010032 200E6532
	v_add_f32_e32 v59, v59, v92                                // 000000D9038C: 0676B93B
	v_mov_b32_dpp v109, v42 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D90390: 7EDA02FA FF01682A
	v_cndmask_b32_e64 v42, -v42, v42, s3                       // 000000D90398: D501002A 200E552A
	v_add_f32_e32 v58, v58, v90                                // 000000D903A0: 0674B53A
	v_mov_b32_dpp v83, v29 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D903A4: 7EA602FA FF01681D
	v_cndmask_b32_e64 v29, -v29, v29, s3                       // 000000D903AC: D501001D 200E3B1D
	v_mov_b32_dpp v84, v51 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D903B4: 7EA802FA FF016433
	v_cndmask_b32_e64 v51, -v51, v51, s2                       // 000000D903BC: D5010033 200A6733
	v_mov_b32_dpp v106, v61 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D903C4: 7ED402FA FF01643D
	v_cndmask_b32_e64 v61, -v61, v61, s2                       // 000000D903CC: D501003D 200A7B3D
	v_dual_add_f32 v53, v53, v91 :: v_dual_add_f32 v66, v66, v101// 000000D903D4: C908B735 3542CB42
	v_dual_add_f32 v21, v21, v98 :: v_dual_add_f32 v42, v42, v109// 000000D903DC: C908C515 152ADB2A
	v_mov_b32_dpp v85, v52 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D903E4: 7EAA02FA FF016834
	v_cndmask_b32_e64 v52, -v52, v52, s3                       // 000000D903EC: D5010034 200E6934
	v_add_f32_e32 v43, v43, v114                               // 000000D903F4: 0656E52B
	v_mov_b32_dpp v99, v60 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D903F8: 7EC602FA FF01683C
	v_cndmask_b32_e64 v60, -v60, v60, s3                       // 000000D90400: D501003C 200E793C
	v_dual_add_f32 v29, v29, v83 :: v_dual_mul_f32 v66, 0x3db504f3, v66// 000000D90408: C906A71D 1D4284FF 3DB504F3
	v_add_f32_e32 v50, v50, v107                               // 000000D90414: 0664D732
	v_mov_b32_dpp v92, v59 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D90418: 7EB802FA FF01683B
	v_cndmask_b32_e64 v59, -v59, v59, s3                       // 000000D90420: D501003B 200E773B
	v_dual_add_f32 v51, v51, v84 :: v_dual_add_f32 v60, v60, v99// 000000D90428: C908A933 333CC73C
	v_add_f32_e32 v52, v52, v85                                // 000000D90430: 0668AB34
	v_mov_b32_dpp v114, v43 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D90434: 7EE402FA FF01642B
	v_cndmask_b32_e64 v43, -v43, v43, s2                       // 000000D9043C: D501002B 200A572B
	v_add_f32_e32 v61, v61, v106                               // 000000D90444: 067AD53D
	v_dual_add_f32 v59, v59, v92 :: v_dual_mul_f32 v42, 0x3db504f3, v42// 000000D90448: C906B93B 3B2A54FF 3DB504F3
	v_mul_f32_e32 v29, 0x3db504f3, v29                         // 000000D90454: 103A3AFF 3DB504F3
	s_delay_alu instid0(VALU_DEP_4)                            // 000000D9045C: BF870004
	v_dual_add_f32 v43, v43, v114 :: v_dual_mul_f32 v60, 0x3db504f3, v60// 000000D90460: C906E52B 2B3C78FF 3DB504F3
	v_mul_f32_e32 v52, 0x3db504f3, v52                         // 000000D9046C: 106868FF 3DB504F3
	v_mov_b32_dpp v106, v61 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D90474: 7ED402FA FF01683D
	v_cndmask_b32_e64 v61, -v61, v61, s3                       // 000000D9047C: D501003D 200E7B3D
	v_mov_b32_dpp v93, v37 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D90484: 7EBA02FA FF016225
	v_cndmask_b32_e64 v37, -v37, v37, s1                       // 000000D9048C: D5010025 20064B25
	v_mov_b32_dpp v108, v44 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D90494: 7ED802FA FF01642C
	v_cndmask_b32_e64 v44, -v44, v44, s2                       // 000000D9049C: D501002C 200A592C
	v_mov_b32_dpp v84, v51 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D904A4: 7EA802FA FF016833
	v_cndmask_b32_e64 v51, -v51, v51, s3                       // 000000D904AC: D5010033 200E6733
	v_mov_b32_dpp v114, v43 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D904B4: 7EE402FA FF01682B
	v_cndmask_b32_e64 v43, -v43, v43, s3                       // 000000D904BC: D501002B 200E572B
	v_dual_add_f32 v37, v37, v93 :: v_dual_add_f32 v44, v44, v108// 000000D904C4: C908BB25 252CD92C
	v_mov_b32_dpp v100, v45 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D904CC: 7EC802FA FF01642D
	v_cndmask_b32_e64 v45, -v45, v45, s2                       // 000000D904D4: D501002D 200A5B2D
	v_dual_add_f32 v51, v51, v84 :: v_dual_mul_f32 v50, 0x3db504f3, v50// 000000D904DC: C906A933 333264FF 3DB504F3
	v_add_f32_e32 v43, v43, v114                               // 000000D904E8: 0656E52B
	v_mov_b32_dpp v93, v37 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D904EC: 7EBA02FA FF016425
	v_cndmask_b32_e64 v37, -v37, v37, s2                       // 000000D904F4: D5010025 200A4B25
	v_dual_add_f32 v45, v45, v100 :: v_dual_mul_f32 v58, 0x3db504f3, v58// 000000D904FC: C906C92D 2D3A74FF 3DB504F3
	v_mov_b32_dpp v108, v44 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D90508: 7ED802FA FF01682C
	v_cndmask_b32_e64 v44, -v44, v44, s3                       // 000000D90510: D501002C 200E592C
	v_mul_f32_e32 v43, 0x3db504f3, v43                         // 000000D90518: 105656FF 3DB504F3
	v_add_f32_e32 v37, v37, v93                                // 000000D90520: 064ABB25
	v_mov_b32_dpp v91, v53 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D90524: 7EB602FA FF016835
	v_cndmask_b32_e64 v53, -v53, v53, s3                       // 000000D9052C: D5010035 200E6B35
	v_mov_b32_dpp v100, v45 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D90534: 7EC802FA FF01682D
	v_cndmask_b32_e64 v45, -v45, v45, s3                       // 000000D9053C: D501002D 200E5B2D
	v_add_f32_e32 v44, v44, v108                               // 000000D90544: 0658D92C
	v_mov_b32_dpp v98, v21 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D90548: 7EC402FA FF016815
	v_add_f32_e32 v53, v53, v91                                // 000000D90550: 066AB735
	v_cndmask_b32_e64 v21, -v21, v21, s3                       // 000000D90554: D5010015 200E2B15
	v_mov_b32_dpp v93, v37 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D9055C: 7EBA02FA FF016825
	v_mul_f32_e32 v44, 0x3db504f3, v44                         // 000000D90564: 105858FF 3DB504F3
	v_cndmask_b32_e64 v37, -v37, v37, s3                       // 000000D9056C: D5010025 200E4B25
	s_waitcnt vmcnt(23)                                        // 000000D90574: BF895FF7
	v_fma_mix_f32 v7, v7, v29, neg(0) op_sel_hi:[1,0,0]        // 000000D90578: CC200007 8A023B07
	s_waitcnt vmcnt(21)                                        // 000000D90580: BF8957F7
	v_fma_mix_f32 v8, v8, v60, neg(0) op_sel_hi:[1,0,0]        // 000000D90584: CC200008 8A027908
	v_add_f32_e32 v37, v37, v93                                // 000000D9058C: 064ABB25
	s_waitcnt vmcnt(19)                                        // 000000D90590: BF894FF7
	v_fma_mix_f32 v11, v11, v66, neg(0) op_sel_hi:[1,0,0]      // 000000D90594: CC20000B 8A02850B
	v_add_f32_e32 v45, v45, v100                               // 000000D9059C: 065AC92D
	s_waitcnt vmcnt(17)                                        // 000000D905A0: BF8947F7
	v_fma_mix_f32 v26, v26, v50, neg(0) op_sel_hi:[1,0,0]      // 000000D905A4: CC20001A 8A02651A
	s_waitcnt vmcnt(16)                                        // 000000D905AC: BF8943F7
	v_fma_mix_f32 v27, v27, v44, neg(0) op_sel_hi:[1,0,0]      // 000000D905B0: CC20001B 8A02591B
	s_waitcnt vmcnt(15)                                        // 000000D905B8: BF893FF7
	v_fma_mix_f32 v29, v35, v42, neg(0) op_sel_hi:[1,0,0]      // 000000D905BC: CC20001D 8A025523
	v_add_f32_e32 v61, v61, v106                               // 000000D905C4: 067AD53D
	s_waitcnt vmcnt(13)                                        // 000000D905C8: BF8937F7
	v_fma_mix_f32 v28, v28, v52, neg(0) op_sel_hi:[1,0,0]      // 000000D905CC: CC20001C 8A02691C
	v_fma_mix_f32 v35, v36, v43, neg(0) op_sel_hi:[1,0,0]      // 000000D905D4: CC200023 8A025724
	v_mul_f32_e32 v44, 0xbfb8aa3b, v11                         // 000000D905DC: 105816FF BFB8AA3B
	v_mul_f32_e32 v60, 0xbfb8aa3b, v29                         // 000000D905E4: 10783AFF BFB8AA3B
	v_mul_f32_e32 v42, 0xbfb8aa3b, v8                          // 000000D905EC: 105410FF BFB8AA3B
	s_waitcnt vmcnt(12)                                        // 000000D905F4: BF8933F7
	v_fma_mix_f32 v34, v34, v58, neg(0) op_sel_hi:[1,0,0]      // 000000D905F8: CC200022 8A027522
	v_mul_f32_e32 v50, 0xbfb8aa3b, v26                         // 000000D90600: 106434FF BFB8AA3B
	v_exp_f32_e32 v44, v44                                     // 000000D90608: 7E584B2C
	v_exp_f32_e32 v60, v60                                     // 000000D9060C: 7E784B3C
	v_mul_f32_e32 v61, 0x3db504f3, v61                         // 000000D90610: 107A7AFF 3DB504F3
	v_mul_f32_e32 v51, 0x3db504f3, v51                         // 000000D90618: 106666FF 3DB504F3
	v_exp_f32_e32 v42, v42                                     // 000000D90620: 7E544B2A
	v_exp_f32_e32 v50, v50                                     // 000000D90624: 7E644B32
	v_dual_mul_f32 v45, 0x3db504f3, v45 :: v_dual_add_f32 v44, 1.0, v44// 000000D90628: C8C85AFF 2D2C58F2 3DB504F3
	s_delay_alu instid0(TRANS32_DEP_3) | instskip(SKIP_2) | instid1(TRANS32_DEP_2)// 000000D90634: BF870337
	v_add_f32_e32 v52, 1.0, v60                                // 000000D90638: 066878F2
	v_fma_mix_f32 v12, v12, v61, neg(0) op_sel_hi:[1,0,0]      // 000000D9063C: CC20000C 8A027B0C
	v_fma_mix_f32 v10, v10, v51, neg(0) op_sel_hi:[1,0,0]      // 000000D90644: CC20000A 8A02670A
	v_add_f32_e32 v42, 1.0, v42                                // 000000D9064C: 065454F2
	v_div_scale_f32 v83, null, v44, v44, v11                   // 000000D90650: D6FC7C53 042E592C
	v_div_scale_f32 v93, s5, v11, v44, v11                     // 000000D90658: D6FC055D 042E590B
	v_mul_f32_e32 v43, 0xbfb8aa3b, v12                         // 000000D90660: 105618FF BFB8AA3B
	v_div_scale_f32 v91, null, v52, v52, v29                   // 000000D90668: D6FC7C5B 04766934
	v_div_scale_f32 v58, null, v42, v42, v8                    // 000000D90670: D6FC7C3A 0422552A
	v_rcp_f32_e32 v107, v83                                    // 000000D90678: 7ED65553
	v_div_scale_f32 v60, vcc_lo, v8, v42, v8                   // 000000D9067C: D6FC6A3C 04225508
	v_exp_f32_e32 v43, v43                                     // 000000D90684: 7E564B2B
	v_rcp_f32_e32 v115, v91                                    // 000000D90688: 7EE6555B
	v_rcp_f32_e32 v101, v58                                    // 000000D9068C: 7ECA553A
	v_div_scale_f32 v117, s9, v29, v52, v29                    // 000000D90690: D6FC0975 0476691D
	v_add_f32_e32 v50, 1.0, v50                                // 000000D90698: 066464F2
	v_fma_mix_f32 v9, v9, v45, neg(0) op_sel_hi:[1,0,0]        // 000000D9069C: CC200009 8A025B09
	v_add_f32_e32 v21, v21, v98                                // 000000D906A4: 062AC515
	v_fma_f32 v125, -v83, v107, 1.0                            // 000000D906A8: D613007D 23CAD753
	s_delay_alu instid0(VALU_DEP_4)                            // 000000D906B0: BF870004
	v_div_scale_f32 v85, null, v50, v50, v26                   // 000000D906B4: D6FC7C55 046A6532
	s_delay_alu instid0(TRANS32_DEP_3) | instid1(VALU_DEP_4)   // 000000D906BC: BF870207
	v_dual_mul_f32 v36, 0xbfb8aa3b, v9 :: v_dual_add_f32 v43, 1.0, v43// 000000D906C0: C8C812FF 242A56F2 BFB8AA3B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000D906CC: BF870235
	v_fma_f32 v123, -v58, v101, 1.0                            // 000000D906D0: D613007B 23CACB3A
	v_div_scale_f32 v99, s7, v26, v50, v26                     // 000000D906D8: D6FC0763 046A651A
	v_fma_f32 v133, -v91, v115, 1.0                            // 000000D906E0: D6130085 23CAE75B
	v_exp_f32_e32 v36, v36                                     // 000000D906E8: 7E484B24
	v_div_scale_f32 v84, null, v43, v43, v12                   // 000000D906EC: D6FC7C54 0432572B
	v_div_scale_f32 v98, s6, v12, v43, v12                     // 000000D906F4: D6FC0662 0432570C
	v_rcp_f32_e32 v109, v85                                    // 000000D906FC: 7EDA5555
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_3)// 000000D90700: BF870392
	v_rcp_f32_e32 v108, v84                                    // 000000D90704: 7ED85554
	v_add_f32_e32 v36, 1.0, v36                                // 000000D90708: 064848F2
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D9070C: BF870116
	v_fma_f32 v131, -v85, v109, 1.0                            // 000000D90710: D6130083 23CADB55
	v_div_scale_f32 v61, null, v36, v36, v9                    // 000000D90718: D6FC7C3D 04264924
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000D90720: BF870235
	v_fma_f32 v130, -v84, v108, 1.0                            // 000000D90724: D6130082 23CAD954
	v_mul_f32_e32 v53, 0x3db504f3, v53                         // 000000D9072C: 106A6AFF 3DB504F3
	v_div_scale_f32 v66, s4, v9, v36, v9                       // 000000D90734: D6FC0442 04264909
	v_rcp_f32_e32 v106, v61                                    // 000000D9073C: 7ED4553D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000D90740: BF870133
	v_dual_fmac_f32 v108, v130, v108 :: v_dual_mul_f32 v45, 0xbfb8aa3b, v27// 000000D90744: C806D982 6C2C36FF BFB8AA3B
	s_waitcnt vmcnt(11)                                        // 000000D90750: BF892FF7
	v_fma_mix_f32 v18, v18, v53, neg(0) op_sel_hi:[1,0,0]      // 000000D90754: CC200012 8A026B12
	v_mul_f32_e32 v130, v98, v108                              // 000000D9075C: 1104D962
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 000000D90760: BF870313
	v_exp_f32_e32 v45, v45                                     // 000000D90764: 7E5A4B2D
	v_fma_f32 v124, -v61, v106, 1.0                            // 000000D90768: D613007C 23CAD53D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D90770: BF870112
	v_fma_f32 v142, -v84, v130, v98                            // 000000D90774: D613008E 258B0554
	v_dual_fmac_f32 v106, v124, v106 :: v_dual_mul_f32 v21, 0x3db504f3, v21// 000000D9077C: C806D57C 6A142AFF 3DB504F3
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D90788: BF870112
	v_fmac_f32_e32 v130, v142, v108                            // 000000D9078C: 5704D98E
	v_mul_f32_e32 v124, v66, v106                              // 000000D90790: 10F8D542
	s_waitcnt vmcnt(8)                                         // 000000D90794: BF8923F7
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D90798: BF870113
	v_fma_mix_f32 v20, v20, v21, neg(0) op_sel_hi:[1,0,0]      // 000000D9079C: CC200014 8A022B14
	v_fma_f32 v140, -v61, v124, v66                            // 000000D907A4: D613008C 250AF93D
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(VALU_DEP_1)   // 000000D907AC: BF870085
	v_dual_add_f32 v45, 1.0, v45 :: v_dual_fmac_f32 v124, v140, v106// 000000D907B0: C9005AF2 2D7CD58C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000D907B8: BF870121
	v_div_scale_f32 v90, null, v45, v45, v27                   // 000000D907BC: D6FC7C5A 046E5B2D
	v_div_scale_f32 v100, s8, v27, v45, v27                    // 000000D907C4: D6FC0864 046E5B1B
	v_rcp_f32_e32 v114, v90                                    // 000000D907CC: 7EE4555A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D907D0: BF870095
	v_fma_f32 v132, -v90, v114, 1.0                            // 000000D907D4: D6130084 23CAE55A
	v_dual_mul_f32 v59, 0x3db504f3, v59 :: v_dual_fmac_f32 v114, v132, v114// 000000D907DC: C8C076FF 3B72E584 3DB504F3
	v_mul_f32_e32 v51, 0xbfb8aa3b, v35                         // 000000D907E8: 106646FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D907F0: BF870192
	v_fma_mix_f32 v19, v19, v59, neg(0) op_sel_hi:[1,0,0]      // 000000D907F4: CC200013 8A027713
	v_mul_f32_e32 v132, v100, v114                             // 000000D907FC: 1108E564
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D90800: BF870093
	v_exp_f32_e32 v51, v51                                     // 000000D90804: 7E664B33
	v_fma_f32 v144, -v90, v132, v100                           // 000000D90808: D6130090 2593095A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000D90810: BF870291
	v_dual_fmac_f32 v101, v123, v101 :: v_dual_fmac_f32 v132, v144, v114// 000000D90814: C800CB7B 6584E590
	v_add_f32_e32 v51, 1.0, v51                                // 000000D9081C: 066666F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D90820: BF870112
	v_mul_f32_e32 v123, v60, v101                              // 000000D90824: 10F6CB3C
	v_div_scale_f32 v92, null, v51, v51, v35                   // 000000D90828: D6FC7C5C 048E6733
	v_div_scale_f32 v122, s10, v35, v51, v35                   // 000000D90830: D6FC0A7A 048E6723
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D90838: BF870193
	v_fma_f32 v139, -v58, v123, v60                            // 000000D9083C: D613008B 24F2F73A
	v_rcp_f32_e32 v116, v92                                    // 000000D90844: 7EE8555C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D90848: BF870091
	v_fmac_f32_e32 v123, v139, v101                            // 000000D9084C: 56F6CB8B
	v_fma_f32 v58, -v58, v123, v60                             // 000000D90850: D613003A 24F2F73A
	v_fma_f32 v60, -v61, v124, v66                             // 000000D90858: D613003C 250AF93D
	v_fma_f32 v66, -v84, v130, v98                             // 000000D90860: D6130042 258B0554
	v_fma_f32 v84, -v90, v132, v100                            // 000000D90868: D6130054 2593095A
	s_delay_alu instid0(TRANS32_DEP_1)                         // 000000D90870: BF870005
	v_fma_f32 v138, -v92, v116, 1.0                            // 000000D90874: D613008A 23CAE95C
	v_mul_f32_e32 v37, 0x3db504f3, v37                         // 000000D9087C: 104A4AFF 3DB504F3
	v_div_fmas_f32 v58, v58, v101, v123                        // 000000D90884: D637003A 05EECB3A
	s_mov_b32 vcc_lo, s4                                       // 000000D9088C: BEEA0004
	s_mov_b32 s4, exec_lo                                      // 000000D90890: BE84007E
	v_div_fmas_f32 v60, v60, v106, v124                        // 000000D90894: D637003C 05F2D53C
	v_fmac_f32_e32 v116, v138, v116                            // 000000D9089C: 56E8E98A
	s_mov_b32 vcc_lo, s5                                       // 000000D908A0: BEEA0005
	v_div_fixup_f32 v8, v58, v42, v8                           // 000000D908A4: D6270008 0422553A
	v_fma_mix_f32 v13, v13, v37, neg(0) op_sel_hi:[1,0,0]      // 000000D908AC: CC20000D 8A024B0D
	v_div_fixup_f32 v9, v60, v36, v9                           // 000000D908B4: D6270009 0426493C
	v_mul_f32_e32 v138, v122, v116                             // 000000D908BC: 1114E97A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D908C0: BF870194
	v_mul_f32_e32 v7, v7, v8                                   // 000000D908C4: 100E1107
	v_mul_f32_e32 v9, v10, v9                                  // 000000D908C8: 1012130A
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000D908CC: BF8701B3
	v_fma_f32 v146, -v92, v138, v122                           // 000000D908D0: D6130092 25EB155C
	v_fmac_f32_e32 v107, v125, v107                            // 000000D908D8: 56D6D77D
	s_waitcnt vmcnt(7)                                         // 000000D908DC: BF891FF7
	v_fma_mix_f32 v9, v67, v9, neg(0) op_sel_hi:[1,0,0]        // 000000D908E0: CC200009 8A021343
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D908E8: BF870092
	v_dual_fmac_f32 v138, v146, v116 :: v_dual_mul_f32 v125, v93, v107// 000000D908EC: C806E992 8A7CD75D
	v_fma_f32 v141, -v83, v125, v93                            // 000000D908F4: D613008D 2576FB53
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D908FC: BF870091
	v_fmac_f32_e32 v125, v141, v107                            // 000000D90900: 56FAD78D
	v_fma_f32 v61, -v83, v125, v93                             // 000000D90904: D613003D 2576FB53
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000D9090C: BF870141
	v_div_fmas_f32 v61, v61, v107, v125                        // 000000D90910: D637003D 05F6D73D
	s_mov_b32 vcc_lo, s6                                       // 000000D90918: BEEA0006
	v_div_fmas_f32 v42, v66, v108, v130                        // 000000D9091C: D637002A 060AD942
	s_mov_b32 vcc_lo, s7                                       // 000000D90924: BEEA0007
	v_div_fixup_f32 v11, v61, v44, v11                         // 000000D90928: D627000B 042E593D
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000D90930: BF8701B2
	v_div_fixup_f32 v8, v42, v43, v12                          // 000000D90934: D6270008 0432572A
	v_fmac_f32_e32 v109, v131, v109                            // 000000D9093C: 56DADB83
	v_fma_f32 v12, -v92, v138, v122                            // 000000D90940: D613000C 25EB155C
	v_dual_mul_f32 v11, v28, v11 :: v_dual_mul_f32 v8, v34, v8 // 000000D90948: C8C6171C 0B081122
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000D90950: BF870123
	v_mul_f32_e32 v131, v99, v109                              // 000000D90954: 1106DB63
	s_waitcnt vmcnt(6)                                         // 000000D90958: BF891BF7
	v_fma_mix_f32 v8, v68, v8, neg(0) op_sel_hi:[1,0,0]        // 000000D9095C: CC200008 8A021144
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D90964: BF870092
	v_fma_f32 v143, -v85, v131, v99                            // 000000D90968: D613008F 258F0755
	v_fmac_f32_e32 v131, v143, v109                            // 000000D90970: 5706DB8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D90974: BF870091
	v_fma_f32 v83, -v85, v131, v99                             // 000000D90978: D6130053 258F0755
	v_div_fmas_f32 v36, v83, v109, v131                        // 000000D90980: D6370024 060EDB53
	s_mov_b32 vcc_lo, s8                                       // 000000D90988: BEEA0008
	v_div_fmas_f32 v10, v84, v114, v132                        // 000000D9098C: D637000A 0612E554
	s_mov_b32 vcc_lo, s9                                       // 000000D90994: BEEA0009
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D90998: BF870112
	v_div_fixup_f32 v21, v36, v50, v26                         // 000000D9099C: D6270015 046A6524
	v_div_fixup_f32 v10, v10, v45, v27                         // 000000D909A4: D627000A 046E5B0A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D909AC: BF870092
	v_dual_fmac_f32 v115, v133, v115 :: v_dual_mul_f32 v18, v18, v21// 000000D909B0: C806E785 73122B12
	v_dual_mul_f32 v10, v19, v10 :: v_dual_mul_f32 v133, v117, v115// 000000D909B8: C8C61513 0A84E775
	s_waitcnt vmcnt(5)                                         // 000000D909C0: BF8917F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D909C4: BF870111
	v_fma_mix_f32 v10, v69, v10, neg(0) op_sel_hi:[1,0,0]      // 000000D909C8: CC20000A 8A021545
	v_fma_f32 v145, -v91, v133, v117                           // 000000D909D0: D6130091 25D70B5B
	s_waitcnt vmcnt(2)                                         // 000000D909D8: BF890BF7
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D909DC: BF870112
	v_fma_mix_f32 v21, v18, v76, v10 op_sel_hi:[0,1,0]         // 000000D909E0: CC200015 142A9912
	v_fmac_f32_e32 v133, v145, v115                            // 000000D909E8: 570AE791
	v_fma_mix_f32 v10, v18, v76, -v10 op_sel_hi:[0,1,0]        // 000000D909EC: CC20000A 942A9912
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D909F4: BF870092
	v_fma_f32 v85, -v91, v133, v117                            // 000000D909F8: D6130055 25D70B5B
	v_div_fmas_f32 v28, v85, v115, v133                        // 000000D90A00: D637001C 0616E755
	s_mov_b32 vcc_lo, s10                                      // 000000D90A08: BEEA000A
	v_div_fmas_f32 v12, v12, v116, v138                        // 000000D90A0C: D637000C 062AE90C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D90A14: BF870112
	v_div_fixup_f32 v19, v28, v52, v29                         // 000000D90A18: D6270013 0476691C
	v_div_fixup_f32 v12, v12, v51, v35                         // 000000D90A20: D627000C 048E670C
	s_delay_alu instid0(VALU_DEP_2)                            // 000000D90A28: BF870002
	v_mul_f32_e32 v13, v13, v19                                // 000000D90A2C: 101A270D
	s_waitcnt vmcnt(0)                                         // 000000D90A30: BF8903F7
	v_fma_mix_f32 v19, v7, v82, v9 op_sel_hi:[0,1,0]           // 000000D90A34: CC200013 1426A507
	v_fma_mix_f32 v7, v7, v82, -v9 op_sel_hi:[0,1,0]           // 000000D90A3C: CC200007 9426A507
	v_mul_f32_e32 v12, v20, v12                                // 000000D90A44: 10181914
	v_fma_mix_f32 v20, v11, v77, v8 op_sel_hi:[0,1,0]          // 000000D90A48: CC200014 14229B0B
	v_fma_mix_f32 v8, v11, v77, -v8 op_sel_hi:[0,1,0]          // 000000D90A50: CC200008 94229B0B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D90A58: BF870193
	v_fma_mix_f32 v12, v74, v12, neg(0) op_sel_hi:[1,0,0]      // 000000D90A5C: CC20000C 8A02194A
	v_add_f32_e32 v27, v19, v20                                // 000000D90A64: 06362913
	s_delay_alu instid0(VALU_DEP_2)                            // 000000D90A68: BF870002
	v_fma_mix_f32 v26, v13, v75, v12 op_sel_hi:[0,1,0]         // 000000D90A6C: CC20001A 1432970D
	v_fma_mix_f32 v11, v13, v75, -v12 op_sel_hi:[0,1,0]        // 000000D90A74: CC20000B 9432970D
	v_add_f32_e32 v13, v7, v8                                  // 000000D90A7C: 061A1107
	v_sub_f32_e32 v7, v7, v8                                   // 000000D90A80: 080E1107
	v_sub_f32_e32 v12, v19, v20                                // 000000D90A84: 08182913
	v_add_f32_e32 v28, v21, v26                                // 000000D90A88: 06383515
	v_dual_add_f32 v8, v10, v11 :: v_dual_sub_f32 v19, v21, v26// 000000D90A8C: C90A170A 08123515
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D90A94: BF870092
	v_dual_sub_f32 v10, v10, v11 :: v_dual_add_f32 v9, v27, v28// 000000D90A98: C948170A 0A08391B
	v_mov_b32_dpp v18, v9 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D90AA0: 7E2402FA FF016109
	v_cndmask_b32_e64 v9, -v9, v9, s0                          // 000000D90AA8: D5010009 20021309
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000D90AB0: BF870241
	v_add_f32_e32 v9, v9, v18                                  // 000000D90AB4: 06122509
	v_add_f32_e32 v18, v13, v8                                 // 000000D90AB8: 0624110D
	v_dual_sub_f32 v13, v13, v8 :: v_dual_add_f32 v8, v12, v19 // 000000D90ABC: C948110D 0D08270C
	v_sub_f32_e32 v19, v12, v19                                // 000000D90AC4: 0826270C
	v_mov_b32_dpp v20, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D90AC8: 7E2802FA FF016209
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_3)// 000000D90AD0: BF8701D4
	v_mov_b32_dpp v21, v18 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D90AD4: 7E2A02FA FF016112
	v_cndmask_b32_e64 v18, -v18, v18, s0                       // 000000D90ADC: D5010012 20022512
	v_cndmask_b32_e64 v9, -v9, v9, s1                          // 000000D90AE4: D5010009 20061309
	v_mov_b32_dpp v26, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D90AEC: 7E3402FA FF016108
	v_cndmask_b32_e64 v8, -v8, v8, s0                          // 000000D90AF4: D5010008 20021108
	v_dual_add_f32 v12, v18, v21 :: v_dual_add_f32 v9, v9, v20 // 000000D90AFC: C9082B12 0C082909
	v_add_f32_e32 v18, v7, v10                                 // 000000D90B04: 06241507
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D90B08: BF870193
	v_add_f32_e32 v8, v8, v26                                  // 000000D90B0C: 06103508
	v_mov_b32_dpp v21, v12 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D90B10: 7E2A02FA FF01620C
	v_cndmask_b32_e64 v12, -v12, v12, s1                       // 000000D90B18: D501000C 2006190C
	v_mov_b32_dpp v20, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D90B20: 7E2802FA FF016409
	v_cndmask_b32_e64 v9, -v9, v9, s2                          // 000000D90B28: D5010009 200A1309
	v_mov_b32_dpp v26, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D90B30: 7E3402FA FF016208
	v_cndmask_b32_e64 v8, -v8, v8, s1                          // 000000D90B38: D5010008 20061108
	v_dual_add_f32 v12, v12, v21 :: v_dual_sub_f32 v11, v27, v28// 000000D90B40: C90A2B0C 0C0A391B
	v_mov_b32_dpp v27, v18 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D90B48: 7E3602FA FF016112
	v_cndmask_b32_e64 v18, -v18, v18, s0                       // 000000D90B50: D5010012 20022512
	v_sub_f32_e32 v21, v7, v10                                 // 000000D90B58: 082A1507
	v_dual_add_f32 v8, v8, v26 :: v_dual_add_f32 v7, v9, v20   // 000000D90B5C: C9083508 08062909
	v_cndmask_b32_e64 v28, -v11, v11, s0                       // 000000D90B64: D501001C 2002170B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D90B6C: BF870224
	v_add_f32_e32 v9, v18, v27                                 // 000000D90B70: 06123712
	v_mov_b32_dpp v27, v11 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D90B74: 7E3602FA FF01610B
	v_mov_b32_dpp v18, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D90B7C: 7E2402FA FF016408
	v_cndmask_b32_e64 v8, -v8, v8, s2                          // 000000D90B84: D5010008 200A1108
	v_mov_b32_dpp v34, v21 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D90B8C: 7E4402FA FF016115
	v_mov_b32_dpp v20, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D90B94: 7E2802FA FF016209
	v_cndmask_b32_e64 v26, -v9, v9, s1                         // 000000D90B9C: D501001A 20061309
	v_cndmask_b32_e64 v21, -v21, v21, s0                       // 000000D90BA4: D5010015 20022B15
	v_add_f32_e32 v11, v8, v18                                 // 000000D90BAC: 06162508
	v_mov_b32_dpp v10, v12 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D90BB0: 7E1402FA FF01640C
	v_cndmask_b32_e64 v12, -v12, v12, s2                       // 000000D90BB8: D501000C 200A190C
	v_add_f32_e32 v18, v26, v20                                // 000000D90BC0: 0624291A
	v_add_f32_e32 v20, v28, v27                                // 000000D90BC4: 0628371C
	v_mov_b32_dpp v28, v13 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D90BC8: 7E3802FA FF01610D
	v_cndmask_b32_e64 v13, -v13, v13, s0                       // 000000D90BD0: D501000D 20021B0D
	v_add_f32_e32 v9, v12, v10                                 // 000000D90BD8: 0612150C
	v_mov_b32_dpp v26, v18 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D90BDC: 7E3402FA FF016412
	v_cndmask_b32_e64 v18, -v18, v18, s2                       // 000000D90BE4: D5010012 200A2512
	v_mov_b32_dpp v27, v20 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D90BEC: 7E3602FA FF016214
	v_cndmask_b32_e64 v20, -v20, v20, s1                       // 000000D90BF4: D5010014 20062914
	v_add_f32_e32 v28, v13, v28                                // 000000D90BFC: 0638390D
	v_mov_b32_dpp v29, v19 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D90C00: 7E3A02FA FF016113
	v_cndmask_b32_e64 v19, -v19, v19, s0                       // 000000D90C08: D5010013 20022713
	v_add_f32_e32 v13, v18, v26                                // 000000D90C10: 061A3512
	v_mov_b32_dpp v8, v7 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D90C14: 7E1002FA FF016807
	v_cndmask_b32_e64 v26, -v28, v28, s1                       // 000000D90C1C: D501001A 2006391C
	v_mov_b32_dpp v10, v9 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D90C24: 7E1402FA FF016809
	v_dual_add_f32 v18, v19, v29 :: v_dual_add_f32 v19, v20, v27// 000000D90C2C: C9083B13 12123714
	v_add_f32_e32 v20, v21, v34                                // 000000D90C34: 06284515
	v_mov_b32_dpp v21, v28 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D90C38: 7E2A02FA FF01621C
	v_mov_b32_dpp v12, v11 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D90C40: 7E1802FA FF01680B
	s_delay_alu instid0(VALU_DEP_4)                            // 000000D90C48: BF870004
	v_mov_b32_dpp v27, v18 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D90C4C: 7E3602FA FF016212
	v_cndmask_b32_e64 v18, -v18, v18, s1                       // 000000D90C54: D5010012 20062512
	v_mov_b32_dpp v28, v20 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D90C5C: 7E3802FA FF016214
	v_cndmask_b32_e64 v20, -v20, v20, s1                       // 000000D90C64: D5010014 20062914
	v_add_f32_e32 v21, v26, v21                                // 000000D90C6C: 062A2B1A
	v_mov_b32_dpp v26, v19 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D90C70: 7E3402FA FF016413
	v_add_f32_e32 v18, v18, v27                                // 000000D90C78: 06243712
	v_cndmask_b32_e64 v19, -v19, v19, s2                       // 000000D90C7C: D5010013 200A2713
	v_add_f32_e32 v20, v20, v28                                // 000000D90C84: 06283914
	v_mov_b32_dpp v27, v21 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D90C88: 7E3602FA FF016415
	v_cndmask_b32_e64 v28, -v21, v21, s2                       // 000000D90C90: D501001C 200A2B15
	v_mov_b32_dpp v29, v18 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D90C98: 7E3A02FA FF016412
	v_cndmask_b32_e64 v34, -v18, v18, s2                       // 000000D90CA0: D5010022 200A2512
	v_mov_b32_dpp v35, v20 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D90CA8: 7E4602FA FF016414
	v_cndmask_b32_e64 v20, -v20, v20, s2                       // 000000D90CB0: D5010014 200A2914
	v_dual_add_f32 v21, v19, v26 :: v_dual_add_f32 v26, v28, v27// 000000D90CB8: C9083513 151A371C
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D90CC0: BF870224
	v_add_f32_e32 v28, v34, v29                                // 000000D90CC4: 06383B22
	v_mov_b32_dpp v18, v13 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D90CC8: 7E2402FA FF01680D
	v_dual_add_f32 v34, v20, v35 :: v_dual_add_nc_u32 v19, 6, v6// 000000D90CD0: C9204714 22120C86
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000D90CD8: BF870234
	v_mov_b32_dpp v20, v21 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D90CDC: 7E2802FA FF016815
	v_mov_b32_dpp v27, v26 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D90CE4: 7E3602FA FF01681A
	v_mov_b32_dpp v29, v28 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D90CEC: 7E3A02FA FF01681C
	v_mov_b32_dpp v35, v34 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D90CF4: 7E4602FA FF016822
	.long 0xd4c4007e                                           // 000000D90CFC: D4C4007E
	v_cndmask_b32_e32 v1, s23, v19, vcc_lo                     // 000000D90D00: 02022617
	s_cbranch_execz 62                                         // 000000D90D04: BFA5003E <_ZN7halogen12_GLOBAL__N_111k_ht_moe_guILi3ELi8ELi1EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_S5_PDF16_+0x4b00>
	v_cndmask_b32_e64 v28, -v28, v28, s3                       // 000000D90D08: D501001C 200E391C
	v_cndmask_b32_e64 v7, -v7, v7, s3                          // 000000D90D10: D5010007 200E0F07
	v_cndmask_b32_e64 v9, -v9, v9, s3                          // 000000D90D18: D5010009 200E1309
	v_cndmask_b32_e64 v26, -v26, v26, s3                       // 000000D90D20: D501001A 200E351A
	v_cndmask_b32_e64 v11, -v11, v11, s3                       // 000000D90D28: D501000B 200E170B
	v_cndmask_b32_e64 v34, -v34, v34, s3                       // 000000D90D30: D5010022 200E4522
	v_cndmask_b32_e64 v13, -v13, v13, s3                       // 000000D90D38: D501000D 200E1B0D
	v_cndmask_b32_e64 v21, -v21, v21, s3                       // 000000D90D40: D5010015 200E2B15
	v_dual_add_f32 v28, v28, v29 :: v_dual_add_f32 v7, v7, v8  // 000000D90D48: C9083B1C 1C061107
	v_add_f32_e32 v8, v9, v10                                  // 000000D90D50: 06101509
	v_dual_add_f32 v26, v26, v27 :: v_dual_add_f32 v9, v11, v12// 000000D90D54: C908371A 1A08190B
	v_mad_i64_i32 v[11:12], null, 0x500, v19, v[0:1]           // 000000D90D5C: D6FF7C0B 040226FF 00000500
	v_dual_add_f32 v34, v34, v35 :: v_dual_add_f32 v13, v13, v18// 000000D90D68: C9084722 220C250D
	s_mov_b32 s5, 0x3db504f3                                   // 000000D90D70: BE8500FF 3DB504F3
	v_add_f32_e32 v20, v21, v20                                // 000000D90D78: 06282915
	v_fma_mixlo_f16 v7, v7, s5, 0                              // 000000D90D7C: CC210007 02000B07
	v_fma_mixhi_f16 v7, v8, s5, 0                              // 000000D90D84: CC220007 02000B08
	v_fma_mixlo_f16 v8, v9, s5, 0                              // 000000D90D8C: CC210008 02000B09
	v_fma_mixhi_f16 v8, v13, s5, 0                             // 000000D90D94: CC220008 02000B0D
	v_fma_mixlo_f16 v9, v20, s5, 0                             // 000000D90D9C: CC210009 02000B14
	v_fma_mixhi_f16 v9, v26, s5, 0                             // 000000D90DA4: CC220009 02000B1A
	v_fma_mixlo_f16 v10, v28, s5, 0                            // 000000D90DAC: CC21000A 02000B1C
	v_fma_mixhi_f16 v10, v34, s5, 0                            // 000000D90DB4: CC22000A 02000B22
	s_clause 0x7                                               // 000000D90DBC: BF850007
	global_store_b16 v[11:12], v7, off                         // 000000D90DC0: DC660000 007C070B
	global_store_d16_hi_b16 v[11:12], v7, off offset:32        // 000000D90DC8: DC960020 007C070B
	global_store_b16 v[11:12], v8, off offset:64               // 000000D90DD0: DC660040 007C080B
	global_store_d16_hi_b16 v[11:12], v8, off offset:96        // 000000D90DD8: DC960060 007C080B
	global_store_b16 v[11:12], v9, off offset:128              // 000000D90DE0: DC660080 007C090B
	global_store_d16_hi_b16 v[11:12], v9, off offset:160       // 000000D90DE8: DC9600A0 007C090B
	global_store_b16 v[11:12], v10, off offset:192             // 000000D90DF0: DC6600C0 007C0A0B
	global_store_d16_hi_b16 v[11:12], v10, off offset:224      // 000000D90DF8: DC9600E0 007C0A0B
	s_or_b32 exec_lo, exec_lo, s4                              // 000000D90E00: 8C7E047E
	s_clause 0xb                                               // 000000D90E04: BF85000B
	global_load_d16_b16 v7, v[2:3], off offset:1280            // 000000D90E08: DC820500 077C0002
	global_load_d16_b16 v10, v[2:3], off offset:1312           // 000000D90E10: DC820520 0A7C0002
	global_load_d16_b16 v8, v[2:3], off                        // 000000D90E18: DC820000 087C0002
	global_load_d16_b16 v9, v[2:3], off offset:32              // 000000D90E20: DC820020 097C0002
	global_load_d16_b16 v11, v[2:3], off offset:64             // 000000D90E28: DC820040 0B7C0002
	global_load_d16_b16 v12, v[2:3], off offset:96             // 000000D90E30: DC820060 0C7C0002
	global_load_d16_b16 v20, v[2:3], off offset:128            // 000000D90E38: DC820080 147C0002
	global_load_d16_b16 v21, v[2:3], off offset:160            // 000000D90E40: DC8200A0 157C0002
	global_load_d16_b16 v28, v[2:3], off offset:192            // 000000D90E48: DC8200C0 1C7C0002
	global_load_d16_b16 v29, v[2:3], off offset:224            // 000000D90E50: DC8200E0 1D7C0002
	global_load_d16_b16 v26, v[2:3], off offset:1344           // 000000D90E58: DC820540 1A7C0002
	global_load_d16_b16 v27, v[2:3], off offset:1376           // 000000D90E60: DC820560 1B7C0002
	v_add_f32_e32 v53, v38, v30                                // 000000D90E68: 066A3D26
	v_sub_f32_e32 v30, v38, v30                                // 000000D90E6C: 083C3D26
	v_add_f32_e32 v38, v22, v14                                // 000000D90E70: 064C1D16
	v_add_f32_e32 v44, v86, v78                                // 000000D90E74: 06589D56
	v_sub_f32_e32 v45, v86, v78                                // 000000D90E78: 085A9D56
	v_add_f32_e32 v50, v70, v62                                // 000000D90E7C: 06647D46
	v_sub_f32_e32 v22, v22, v14                                // 000000D90E80: 082C1D16
	v_add_f32_e32 v69, v53, v38                                // 000000D90E84: 068A4D35
	v_sub_f32_e32 v37, v118, v110                              // 000000D90E88: 084ADD76
	v_add_f32_e32 v42, v102, v94                               // 000000D90E8C: 0654BD66
	v_sub_f32_e32 v43, v102, v94                               // 000000D90E90: 0856BD66
	v_sub_f32_e32 v35, v134, v126                              // 000000D90E94: 0846FD86
	v_add_f32_e32 v34, v134, v126                              // 000000D90E98: 0644FD86
	v_add_f32_e32 v36, v118, v110                              // 000000D90E9C: 0648DD76
	s_delay_alu instid0(VALU_DEP_1)                            // 000000D90EA0: BF870001
	v_add_f32_e32 v68, v34, v36                                // 000000D90EA4: 06884922
	v_sub_f32_e32 v34, v34, v36                                // 000000D90EA8: 08444922
	v_add_f32_e32 v36, v35, v37                                // 000000D90EAC: 06484B23
	v_sub_f32_e32 v35, v35, v37                                // 000000D90EB0: 08464B23
	v_add_f32_e32 v37, v42, v44                                // 000000D90EB4: 064A592A
	v_add_f32_e32 v52, v54, v46                                // 000000D90EB8: 06685D36
	v_sub_f32_e32 v42, v42, v44                                // 000000D90EBC: 0854592A
	v_add_f32_e32 v44, v43, v45                                // 000000D90EC0: 06585B2B
	v_sub_f32_e32 v43, v43, v45                                // 000000D90EC4: 08565B2B
	v_sub_f32_e32 v51, v70, v62                                // 000000D90EC8: 08667D46
	v_sub_f32_e32 v46, v54, v46                                // 000000D90ECC: 085C5D36
	s_clause 0x3                                               // 000000D90ED0: BF850003
	global_load_d16_b16 v14, v[2:3], off offset:1408           // 000000D90ED4: DC820580 0E7C0002
	global_load_d16_b16 v18, v[2:3], off offset:1440           // 000000D90EDC: DC8205A0 127C0002
	global_load_d16_b16 v13, v[2:3], off offset:1472           // 000000D90EE4: DC8205C0 0D7C0002
	global_load_d16_b16 v19, v[2:3], off offset:1504           // 000000D90EEC: DC8205E0 137C0002
	s_clause 0x7                                               // 000000D90EF4: BF850007
	global_load_d16_b16 v54, v[4:5], off offset:32             // 000000D90EF8: DC820020 367C0004
	global_load_d16_b16 v58, v[4:5], off offset:96             // 000000D90F00: DC820060 3A7C0004
	global_load_d16_b16 v59, v[4:5], off offset:160            // 000000D90F08: DC8200A0 3B7C0004
	global_load_d16_b16 v60, v[4:5], off offset:224            // 000000D90F10: DC8200E0 3C7C0004
	global_load_d16_b16 v61, v[4:5], off offset:192            // 000000D90F18: DC8200C0 3D7C0004
	global_load_d16_b16 v62, v[4:5], off offset:128            // 000000D90F20: DC820080 3E7C0004
	global_load_d16_b16 v66, v[4:5], off offset:64             // 000000D90F28: DC820040 427C0004
	global_load_d16_b16 v67, v[4:5], off                       // 000000D90F30: DC820000 437C0004
	v_dual_add_f32 v70, v35, v43 :: v_dual_add_f32 v45, v50, v52// 000000D90F38: C9085723 462C6932
	v_dual_sub_f32 v35, v35, v43 :: v_dual_sub_f32 v50, v50, v52// 000000D90F40: C94A5723 23326932
	v_add_f32_e32 v52, v51, v46                                // 000000D90F48: 06685D33
	v_sub_f32_e32 v46, v51, v46                                // 000000D90F4C: 085C5D33
	v_add_f32_e32 v51, v30, v22                                // 000000D90F50: 06662D1E
	s_delay_alu instid0(VALU_DEP_4)                            // 000000D90F54: BF870004
	v_mov_b32_dpp v92, v35 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D90F58: 7EB802FA FF016123
	v_cndmask_b32_e64 v35, -v35, v35, s0                       // 000000D90F60: D5010023 20024723
	v_sub_f32_e32 v22, v30, v22                                // 000000D90F68: 082C2D1E
	v_add_f32_e32 v30, v45, v69                                // 000000D90F6C: 063C8B2D
	v_sub_f32_e32 v45, v45, v69                                // 000000D90F70: 085A8B2D
	v_add_f32_e32 v69, v68, v37                                // 000000D90F74: 068A4B44
	v_sub_f32_e32 v37, v68, v37                                // 000000D90F78: 084A4B44
	v_add_f32_e32 v35, v35, v92                                // 000000D90F7C: 0646B923
	v_mov_b32_dpp v85, v70 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D90F80: 7EAA02FA FF016146
	v_mov_b32_dpp v75, v45 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D90F88: 7E9602FA FF01612D
	v_cndmask_b32_e64 v45, -v45, v45, s0                       // 000000D90F90: D501002D 20025B2D
	v_mov_b32_dpp v86, v37 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D90F98: 7EAC02FA FF016125
	v_cndmask_b32_e64 v37, -v37, v37, s0                       // 000000D90FA0: D5010025 20024B25
	v_mov_b32_dpp v92, v35 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D90FA8: 7EB802FA FF016223
	v_cndmask_b32_e64 v35, -v35, v35, s1                       // 000000D90FB0: D5010023 20064723
	v_add_f32_e32 v45, v45, v75                                // 000000D90FB8: 065A972D
	v_cndmask_b32_e64 v70, -v70, v70, s0                       // 000000D90FBC: D5010046 20028D46
	v_add_f32_e32 v37, v37, v86                                // 000000D90FC4: 064AAD25
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D90FC8: BF870214
	v_dual_add_f32 v74, v34, v42 :: v_dual_add_f32 v35, v35, v92// 000000D90FCC: C9085522 4A22B923
	v_mov_b32_dpp v75, v45 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D90FD4: 7E9602FA FF01622D
	v_cndmask_b32_e64 v45, -v45, v45, s1                       // 000000D90FDC: D501002D 20065B2D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D90FE4: BF870214
	v_mov_b32_dpp v86, v37 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D90FE8: 7EAC02FA FF016225
	v_mov_b32_dpp v84, v74 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D90FF0: 7EA802FA FF01614A
	v_cndmask_b32_e64 v74, -v74, v74, s0                       // 000000D90FF8: D501004A 2002954A
	v_sub_f32_e32 v38, v53, v38                                // 000000D91000: 084C4D35
	v_add_f32_e32 v45, v45, v75                                // 000000D91004: 065A972D
	v_add_f32_e32 v53, v52, v51                                // 000000D91008: 066A6734
	v_sub_f32_e32 v51, v52, v51                                // 000000D9100C: 08666734
	v_cndmask_b32_e64 v37, -v37, v37, s1                       // 000000D91010: D5010025 20064B25
	v_add_f32_e32 v52, v50, v38                                // 000000D91018: 06684D32
	v_mov_b32_dpp v75, v45 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D9101C: 7E9602FA FF01642D
	v_cndmask_b32_e64 v45, -v45, v45, s2                       // 000000D91024: D501002D 200A5B2D
	v_sub_f32_e32 v38, v50, v38                                // 000000D9102C: 084C4D32
	v_add_f32_e32 v50, v46, v22                                // 000000D91030: 06642D2E
	v_sub_f32_e32 v22, v46, v22                                // 000000D91034: 082C2D2E
	s_delay_alu instid0(VALU_DEP_4)                            // 000000D91038: BF870004
	v_dual_add_f32 v46, v36, v44 :: v_dual_add_f32 v45, v45, v75// 000000D9103C: C9085924 2E2C972D
	v_sub_f32_e32 v36, v36, v44                                // 000000D91044: 08485924
	v_mov_b32_dpp v43, v53 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D91048: 7E5602FA FF016135
	v_cndmask_b32_e64 v44, -v53, v53, s0                       // 000000D91050: D501002C 20026B35
	v_mov_b32_dpp v68, v50 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D91058: 7E8802FA FF016132
	v_cndmask_b32_e64 v50, -v50, v50, s0                       // 000000D91060: D5010032 20026532
	v_mov_b32_dpp v76, v51 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D91068: 7E9802FA FF016133
	v_cndmask_b32_e64 v51, -v51, v51, s0                       // 000000D91070: D5010033 20026733
	v_mov_b32_dpp v75, v45 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D91078: 7E9602FA FF01682D
	v_cndmask_b32_e64 v45, -v45, v45, s3                       // 000000D91080: D501002D 200E5B2D
	v_sub_f32_e32 v34, v34, v42                                // 000000D91088: 08445522
	v_mov_b32_dpp v42, v30 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D9108C: 7E5402FA FF01611E
	v_cndmask_b32_e64 v30, -v30, v30, s0                       // 000000D91094: D501001E 20023D1E
	v_mov_b32_dpp v53, v52 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D9109C: 7E6A02FA FF016134
	v_cndmask_b32_e64 v52, -v52, v52, s0                       // 000000D910A4: D5010034 20026934
	v_add_f32_e32 v37, v37, v86                                // 000000D910AC: 064AAD25
	v_mov_b32_dpp v77, v38 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D910B0: 7E9A02FA FF016126
	v_add_f32_e32 v30, v30, v42                                // 000000D910B8: 063C551E
	v_add_f32_e32 v42, v44, v43                                // 000000D910BC: 0654572C
	v_add_f32_e32 v44, v50, v68                                // 000000D910C0: 06588932
	v_dual_add_f32 v50, v51, v76 :: v_dual_add_f32 v43, v52, v53// 000000D910C4: C9089933 322A6B34
	v_mov_b32_dpp v86, v37 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D910CC: 7EAC02FA FF016425
	v_cndmask_b32_e64 v37, -v37, v37, s2                       // 000000D910D4: D5010025 200A4B25
	v_add_f32_e32 v52, v70, v85                                // 000000D910DC: 0668AB46
	v_add_f32_e32 v53, v74, v84                                // 000000D910E0: 066AA94A
	v_mov_b32_dpp v70, v43 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D910E4: 7E8C02FA FF01622B
	v_cndmask_b32_e64 v43, -v43, v43, s1                       // 000000D910EC: D501002B 2006572B
	v_add_f32_e32 v37, v37, v86                                // 000000D910F4: 064AAD25
	v_mov_b32_dpp v85, v52 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D910F8: 7EAA02FA FF016234
	v_cndmask_b32_e64 v52, -v52, v52, s1                       // 000000D91100: D5010034 20066934
	v_cndmask_b32_e64 v38, -v38, v38, s0                       // 000000D91108: D5010026 20024D26
	v_add_f32_e32 v43, v43, v70                                // 000000D91110: 06568D2B
	v_mov_b32_dpp v84, v53 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D91114: 7EA802FA FF016235
	v_cndmask_b32_e64 v53, -v53, v53, s1                       // 000000D9111C: D5010035 20066B35
	v_add_f32_e32 v52, v52, v85                                // 000000D91124: 0668AB34
	v_mov_b32_dpp v92, v35 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D91128: 7EB802FA FF016423
	v_mov_b32_dpp v70, v43 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D91130: 7E8C02FA FF01642B
	v_cndmask_b32_e64 v43, -v43, v43, s2                       // 000000D91138: D501002B 200A572B
	v_add_f32_e32 v38, v38, v77                                // 000000D91140: 064C9B26
	v_mov_b32_dpp v85, v52 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D91144: 7EAA02FA FF016434
	v_cndmask_b32_e64 v52, -v52, v52, s2                       // 000000D9114C: D5010034 200A6934
	v_add_f32_e32 v53, v53, v84                                // 000000D91154: 066AA935
	v_cndmask_b32_e64 v35, -v35, v35, s2                       // 000000D91158: D5010023 200A4723
	v_add_f32_e32 v43, v43, v70                                // 000000D91160: 06568D2B
	v_mov_b32_dpp v90, v36 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D91164: 7EB402FA FF016124
	v_add_f32_e32 v52, v52, v85                                // 000000D9116C: 0668AB34
	v_cndmask_b32_e64 v36, -v36, v36, s0                       // 000000D91170: D5010024 20024924
	v_mov_b32_dpp v84, v53 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D91178: 7EA802FA FF016435
	v_cndmask_b32_e64 v53, -v53, v53, s2                       // 000000D91180: D5010035 200A6B35
	v_add_f32_e32 v35, v35, v92                                // 000000D91188: 0646B923
	v_mov_b32_dpp v70, v43 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D9118C: 7E8C02FA FF01682B
	v_cndmask_b32_e64 v43, -v43, v43, s3                       // 000000D91194: D501002B 200E572B
	v_mov_b32_dpp v85, v52 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D9119C: 7EAA02FA FF016834
	v_cndmask_b32_e64 v52, -v52, v52, s3                       // 000000D911A4: D5010034 200E6934
	v_add_f32_e32 v45, v45, v75                                // 000000D911AC: 065A972D
	v_mov_b32_dpp v91, v34 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D911B0: 7EB602FA FF016122
	v_cndmask_b32_e64 v34, -v34, v34, s0                       // 000000D911B8: D5010022 20024522
	v_add_f32_e32 v53, v53, v84                                // 000000D911C0: 066AA935
	v_mov_b32_dpp v78, v22 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D911C4: 7E9C02FA FF016116
	v_cndmask_b32_e64 v22, -v22, v22, s0                       // 000000D911CC: D5010016 20022D16
	v_mov_b32_dpp v92, v35 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D911D4: 7EB802FA FF016823
	v_dual_add_f32 v34, v34, v91 :: v_dual_add_f32 v43, v43, v70// 000000D911DC: C908B722 222A8D2B
	v_add_f32_e32 v36, v36, v90                                // 000000D911E4: 0648B524
	v_cndmask_b32_e64 v35, -v35, v35, s3                       // 000000D911E8: D5010023 200E4723
	v_add_f32_e32 v52, v52, v85                                // 000000D911F0: 0668AB34
	v_add_f32_e32 v22, v22, v78                                // 000000D911F4: 062C9D16
	v_mov_b32_dpp v77, v38 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D911F8: 7E9A02FA FF016226
	v_cndmask_b32_e64 v38, -v38, v38, s1                       // 000000D91200: D5010026 20064D26
	v_add_f32_e32 v35, v35, v92                                // 000000D91208: 0646B923
	v_mul_f32_e32 v43, 0x3db504f3, v43                         // 000000D9120C: 105656FF 3DB504F3
	v_mov_b32_dpp v90, v36 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D91214: 7EB402FA FF016224
	v_cndmask_b32_e64 v36, -v36, v36, s1                       // 000000D9121C: D5010024 20064924
	v_mul_f32_e32 v52, 0x3db504f3, v52                         // 000000D91224: 106868FF 3DB504F3
	v_dual_add_f32 v38, v38, v77 :: v_dual_mul_f32 v35, 0x3db504f3, v35// 000000D9122C: C9069B26 262246FF 3DB504F3
	v_mov_b32_dpp v82, v69 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D91238: 7EA402FA FF016145
	v_cndmask_b32_e64 v69, -v69, v69, s0                       // 000000D91240: D5010045 20028B45
	v_mov_b32_dpp v86, v37 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D91248: 7EAC02FA FF016825
	v_cndmask_b32_e64 v37, -v37, v37, s3                       // 000000D91250: D5010025 200E4B25
	v_mov_b32_dpp v78, v22 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D91258: 7E9C02FA FF016216
	v_cndmask_b32_e64 v22, -v22, v22, s1                       // 000000D91260: D5010016 20062D16
	v_add_f32_e32 v51, v69, v82                                // 000000D91268: 0666A545
	v_mov_b32_dpp v69, v42 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D9126C: 7E8A02FA FF01622A
	v_cndmask_b32_e64 v42, -v42, v42, s1                       // 000000D91274: D501002A 2006552A
	v_mov_b32_dpp v91, v34 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D9127C: 7EB602FA FF016222
	v_cndmask_b32_e64 v34, -v34, v34, s1                       // 000000D91284: D5010022 20064522
	v_add_f32_e32 v37, v37, v86                                // 000000D9128C: 064AAD25
	v_mov_b32_dpp v82, v51 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D91290: 7EA402FA FF016233
	v_add_f32_e32 v42, v42, v69                                // 000000D91298: 06548B2A
	v_cndmask_b32_e64 v51, -v51, v51, s1                       // 000000D9129C: D5010033 20066733
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000D912A4: BF870234
	v_dual_add_f32 v22, v22, v78 :: v_dual_mul_f32 v37, 0x3db504f3, v37// 000000D912A8: C9069D16 16244AFF 3DB504F3
	v_mov_b32_dpp v83, v46 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D912B4: 7EA602FA FF01612E
	v_cndmask_b32_e64 v46, -v46, v46, s0                       // 000000D912BC: D501002E 20025D2E
	v_add_f32_e32 v51, v51, v82                                // 000000D912C4: 0666A533
	v_mov_b32_dpp v84, v53 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D912C8: 7EA802FA FF016835
	v_cndmask_b32_e64 v53, -v53, v53, s3                       // 000000D912D0: D5010035 200E6B35
	v_mov_b32_dpp v74, v44 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D912D8: 7E9402FA FF01622C
	v_cndmask_b32_e64 v44, -v44, v44, s1                       // 000000D912E0: D501002C 2006592C
	v_mov_b32_dpp v82, v51 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D912E8: 7EA402FA FF016433
	v_cndmask_b32_e64 v51, -v51, v51, s2                       // 000000D912F0: D5010033 200A6733
	v_dual_add_f32 v46, v46, v83 :: v_dual_add_f32 v53, v53, v84// 000000D912F8: C908A72E 2E34A935
	v_mov_b32_dpp v68, v30 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D91300: 7E8802FA FF01621E
	v_cndmask_b32_e64 v30, -v30, v30, s1                       // 000000D91308: D501001E 20063D1E
	s_delay_alu instid0(VALU_DEP_4)                            // 000000D91310: BF870004
	v_add_f32_e32 v51, v51, v82                                // 000000D91314: 0666A533
	v_mov_b32_dpp v69, v42 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D91318: 7E8A02FA FF01642A
	v_cndmask_b32_e64 v42, -v42, v42, s2                       // 000000D91320: D501002A 200A552A
	v_mov_b32_dpp v76, v50 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D91328: 7E9802FA FF016232
	v_cndmask_b32_e64 v50, -v50, v50, s1                       // 000000D91330: D5010032 20066532
	v_mov_b32_dpp v82, v51 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D91338: 7EA402FA FF016833
	v_cndmask_b32_e64 v51, -v51, v51, s3                       // 000000D91340: D5010033 200E6733
	v_dual_add_f32 v30, v30, v68 :: v_dual_mul_f32 v53, 0x3db504f3, v53// 000000D91348: C906891E 1E346AFF 3DB504F3
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D91354: BF870224
	v_add_f32_e32 v50, v50, v76                                // 000000D91358: 06649932
	v_mov_b32_dpp v83, v46 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D9135C: 7EA602FA FF01622E
	v_add_f32_e32 v51, v51, v82                                // 000000D91364: 0666A533
	v_add_f32_e32 v44, v44, v74                                // 000000D91368: 0658952C
	v_cndmask_b32_e64 v46, -v46, v46, s1                       // 000000D9136C: D501002E 20065D2E
	v_mov_b32_dpp v76, v50 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D91374: 7E9802FA FF016432
	v_cndmask_b32_e64 v50, -v50, v50, s2                       // 000000D9137C: D5010032 200A6532
	v_mul_f32_e32 v51, 0x3db504f3, v51                         // 000000D91384: 106666FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_4)                            // 000000D9138C: BF870004
	v_dual_mul_f32 v45, 0x3db504f3, v45 :: v_dual_add_f32 v46, v46, v83// 000000D91390: C8C85AFF 2D2EA72E 3DB504F3
	v_mov_b32_dpp v74, v44 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D9139C: 7E9402FA FF01642C
	v_cndmask_b32_e64 v44, -v44, v44, s2                       // 000000D913A4: D501002C 200A592C
	v_mov_b32_dpp v68, v30 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D913AC: 7E8802FA FF01641E
	v_cndmask_b32_e64 v30, -v30, v30, s2                       // 000000D913B4: D501001E 200A3D1E
	v_mov_b32_dpp v83, v46 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D913BC: 7EA602FA FF01642E
	v_cndmask_b32_e64 v46, -v46, v46, s2                       // 000000D913C4: D501002E 200A5D2E
	v_mov_b32_dpp v77, v38 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D913CC: 7E9A02FA FF016426
	v_cndmask_b32_e64 v38, -v38, v38, s2                       // 000000D913D4: D5010026 200A4D26
	v_mov_b32_dpp v78, v22 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D913DC: 7E9C02FA FF016416
	v_cndmask_b32_e64 v22, -v22, v22, s2                       // 000000D913E4: D5010016 200A2D16
	s_waitcnt vmcnt(21)                                        // 000000D913EC: BF8957F7
	v_fma_mix_f32 v8, v8, v51, neg(0) op_sel_hi:[1,0,0]        // 000000D913F0: CC200008 8A026708
	s_waitcnt vmcnt(19)                                        // 000000D913F8: BF894FF7
	v_fma_mix_f32 v11, v11, v53, neg(0) op_sel_hi:[1,0,0]      // 000000D913FC: CC20000B 8A026B0B
	s_waitcnt vmcnt(18)                                        // 000000D91404: BF894BF7
	v_fma_mix_f32 v12, v12, v52, neg(0) op_sel_hi:[1,0,0]      // 000000D91408: CC20000C 8A02690C
	v_add_f32_e32 v36, v36, v90                                // 000000D91410: 0648B524
	s_waitcnt vmcnt(17)                                        // 000000D91414: BF8947F7
	v_fma_mix_f32 v20, v20, v37, neg(0) op_sel_hi:[1,0,0]      // 000000D91418: CC200014 8A024B14
	s_waitcnt vmcnt(14)                                        // 000000D91420: BF893BF7
	v_fma_mix_f32 v29, v29, v35, neg(0) op_sel_hi:[1,0,0]      // 000000D91424: CC20001D 8A02471D
	v_mul_f32_e32 v35, 0xbfb8aa3b, v12                         // 000000D9142C: 104618FF BFB8AA3B
	v_mov_b32_dpp v90, v36 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D91434: 7EB402FA FF016424
	v_cndmask_b32_e64 v36, -v36, v36, s2                       // 000000D9143C: D5010024 200A4924
	s_waitcnt vmcnt(13)                                        // 000000D91444: BF8937F7
	v_fma_mix_f32 v26, v26, v43, neg(0) op_sel_hi:[1,0,0]      // 000000D91448: CC20001A 8A02571A
	v_exp_f32_e32 v35, v35                                     // 000000D91450: 7E464B23
	v_add_f32_e32 v30, v30, v68                                // 000000D91454: 063C891E
	v_add_f32_e32 v36, v36, v90                                // 000000D91458: 0648B524
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(TRANS32_DEP_1)// 000000D9145C: BF8702A1
	v_mov_b32_dpp v90, v36 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D91460: 7EB402FA FF016824
	v_cndmask_b32_e64 v36, -v36, v36, s3                       // 000000D91468: D5010024 200E4924
	v_add_f32_e32 v35, 1.0, v35                                // 000000D91470: 064646F2
	v_mov_b32_dpp v68, v30 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D91474: 7E8802FA FF01681E
	v_cndmask_b32_e64 v30, -v30, v30, s3                       // 000000D9147C: D501001E 200E3D1E
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000D91484: BF870134
	v_add_f32_e32 v36, v36, v90                                // 000000D91488: 0648B524
	s_waitcnt vmcnt(11)                                        // 000000D9148C: BF892FF7
	v_fma_mix_f32 v14, v14, v45, neg(0) op_sel_hi:[1,0,0]      // 000000D91490: CC20000E 8A025B0E
	v_mul_f32_e32 v36, 0x3db504f3, v36                         // 000000D91498: 104848FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000D914A0: BF870121
	v_fma_mix_f32 v21, v21, v36, neg(0) op_sel_hi:[1,0,0]      // 000000D914A4: CC200015 8A024915
	v_add_f32_e32 v34, v34, v91                                // 000000D914AC: 0644B722
	v_dual_mul_f32 v36, 0xbfb8aa3b, v11 :: v_dual_mul_f32 v37, 0xbfb8aa3b, v21// 000000D914B0: C8C616FF 24242AFF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000D914BC: BF8701A2
	v_mov_b32_dpp v91, v34 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D914C0: 7EB602FA FF016422
	v_cndmask_b32_e64 v34, -v34, v34, s2                       // 000000D914C8: D5010022 200A4522
	v_exp_f32_e32 v36, v36                                     // 000000D914D0: 7E484B24
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000D914D4: BF870123
	v_exp_f32_e32 v37, v37                                     // 000000D914D8: 7E4A4B25
	v_add_f32_e32 v44, v44, v74                                // 000000D914DC: 0658952C
	v_add_f32_e32 v34, v34, v91                                // 000000D914E0: 0644B722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(TRANS32_DEP_1)// 000000D914E4: BF8702A1
	v_mov_b32_dpp v91, v34 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D914E8: 7EB602FA FF016822
	v_cndmask_b32_e64 v34, -v34, v34, s3                       // 000000D914F0: D5010022 200E4522
	v_dual_add_f32 v36, 1.0, v36 :: v_dual_add_f32 v37, 1.0, v37// 000000D914F8: C90848F2 24244AF2
	v_mov_b32_dpp v74, v44 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D91500: 7E9402FA FF01682C
	v_cndmask_b32_e64 v44, -v44, v44, s3                       // 000000D91508: D501002C 200E592C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D91510: BF870094
	v_add_f32_e32 v34, v34, v91                                // 000000D91514: 0644B722
	v_mul_f32_e32 v34, 0x3db504f3, v34                         // 000000D91518: 104444FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000D91520: BF8701B1
	v_fma_mix_f32 v28, v28, v34, neg(0) op_sel_hi:[1,0,0]      // 000000D91524: CC20001C 8A02451C
	v_add_f32_e32 v42, v42, v69                                // 000000D9152C: 06548B2A
	v_mul_f32_e32 v34, 0xbfb8aa3b, v8                          // 000000D91530: 104410FF BFB8AA3B
	v_mul_f32_e32 v51, 0xbfb8aa3b, v28                         // 000000D91538: 106638FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D91540: BF870193
	v_mov_b32_dpp v69, v42 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D91544: 7E8A02FA FF01682A
	v_exp_f32_e32 v34, v34                                     // 000000D9154C: 7E444B22
	v_cndmask_b32_e64 v42, -v42, v42, s3                       // 000000D91550: D501002A 200E552A
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(TRANS32_DEP_1)// 000000D91558: BF8702A3
	v_exp_f32_e32 v51, v51                                     // 000000D9155C: 7E664B33
	v_add_f32_e32 v50, v50, v76                                // 000000D91560: 06649932
	v_dual_add_f32 v34, 1.0, v34 :: v_dual_add_f32 v43, 1.0, v51// 000000D91564: C90844F2 222A66F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D9156C: BF870112
	v_mov_b32_dpp v76, v50 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D91570: 7E9802FA FF016832
	v_div_scale_f32 v51, vcc_lo, v8, v34, v8                   // 000000D91578: D6FC6A33 04224508
	v_cndmask_b32_e64 v50, -v50, v50, s3                       // 000000D91580: D5010032 200E6532
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000D91588: BF870124
	v_div_scale_f32 v75, null, v43, v43, v28                   // 000000D9158C: D6FC7C4B 0472572B
	v_div_scale_f32 v98, s9, v28, v43, v28                     // 000000D91594: D6FC0962 0472571C
	v_rcp_f32_e32 v93, v75                                     // 000000D9159C: 7EBA554B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D915A0: BF870095
	v_fma_f32 v109, -v75, v93, 1.0                             // 000000D915A4: D613006D 23CABB4B
	v_dual_add_f32 v46, v46, v83 :: v_dual_fmac_f32 v93, v109, v93// 000000D915AC: C900A72E 2E5CBB6D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 000000D915B4: BF870251
	v_mov_b32_dpp v83, v46 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D915B8: 7EA602FA FF01682E
	v_cndmask_b32_e64 v46, -v46, v46, s3                       // 000000D915C0: D501002E 200E5D2E
	v_add_f32_e32 v44, v44, v74                                // 000000D915C8: 0658952C
	v_div_scale_f32 v74, null, v37, v37, v21                   // 000000D915CC: D6FC7C4A 04564B25
	v_mul_f32_e32 v109, v98, v93                               // 000000D915D4: 10DABB62
	v_add_f32_e32 v46, v46, v83                                // 000000D915D8: 065CA72E
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D915DC: BF870214
	v_mul_f32_e32 v44, 0x3db504f3, v44                         // 000000D915E0: 105858FF 3DB504F3
	v_rcp_f32_e32 v92, v74                                     // 000000D915E8: 7EB8554A
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 000000D915EC: BF870253
	v_fma_f32 v123, -v75, v109, v98                            // 000000D915F0: D613007B 258ADB4B
	v_add_f32_e32 v30, v30, v68                                // 000000D915F8: 063C891E
	v_mul_f32_e32 v46, 0x3db504f3, v46                         // 000000D915FC: 105C5CFF 3DB504F3
	v_fma_mix_f32 v27, v27, v44, neg(0) op_sel_hi:[1,0,0]      // 000000D91604: CC20001B 8A02591B
	v_div_scale_f32 v68, null, v36, v36, v11                   // 000000D9160C: D6FC7C44 042E4924
	v_dual_fmac_f32 v109, v123, v93 :: v_dual_mul_f32 v30, 0x3db504f3, v30// 000000D91614: C806BB7B 6D1E3CFF 3DB504F3
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D91620: BF870224
	v_fma_mix_f32 v9, v9, v46, neg(0) op_sel_hi:[1,0,0]        // 000000D91624: CC200009 8A025D09
	v_mul_f32_e32 v46, 0xbfb8aa3b, v29                         // 000000D9162C: 105C3AFF BFB8AA3B
	v_rcp_f32_e32 v86, v68                                     // 000000D91634: 7EAC5544
	v_fma_f32 v108, -v74, v92, 1.0                             // 000000D91638: D613006C 23CAB94A
	v_fma_mix_f32 v7, v7, v30, neg(0) op_sel_hi:[1,0,0]        // 000000D91640: CC200007 8A023D07
	v_mul_f32_e32 v30, 0xbfb8aa3b, v9                          // 000000D91648: 103C12FF BFB8AA3B
	v_exp_f32_e32 v46, v46                                     // 000000D91650: 7E5C4B2E
	v_div_scale_f32 v83, s8, v21, v37, v21                     // 000000D91654: D6FC0853 04564B15
	v_fmac_f32_e32 v92, v108, v92                              // 000000D9165C: 56B8B96C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_3)// 000000D91660: BF870393
	v_exp_f32_e32 v30, v30                                     // 000000D91664: 7E3C4B1E
	v_fma_f32 v102, -v68, v86, 1.0                             // 000000D91668: D6130066 23CAAD44
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 000000D91670: BF870312
	v_mul_f32_e32 v108, v83, v92                               // 000000D91674: 10D8B953
	v_add_f32_e32 v44, 1.0, v46                                // 000000D91678: 06585CF2
	v_div_scale_f32 v46, null, v34, v34, v8                    // 000000D9167C: D6FC7C2E 04224522
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D91684: BF870214
	v_fmac_f32_e32 v86, v102, v86                              // 000000D91688: 56ACAD66
	v_fma_f32 v122, -v74, v108, v83                            // 000000D9168C: D613007A 254ED94A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000D91694: BF8701B5
	v_add_f32_e32 v30, 1.0, v30                                // 000000D91698: 063C3CF2
	v_div_scale_f32 v99, s10, v29, v44, v29                    // 000000D9169C: D6FC0A63 0476591D
	v_rcp_f32_e32 v84, v46                                     // 000000D916A4: 7EA8552E
	v_fmac_f32_e32 v108, v122, v92                             // 000000D916A8: 56D8B97A
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000D916AC: BF870123
	v_div_scale_f32 v52, null, v30, v30, v9                    // 000000D916B0: D6FC7C34 04263D1E
	v_div_scale_f32 v53, s4, v9, v30, v9                       // 000000D916B8: D6FC0435 04263D09
	v_rcp_f32_e32 v85, v52                                     // 000000D916C0: 7EAA5534
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D916C4: BF870096
	v_fma_f32 v100, -v46, v84, 1.0                             // 000000D916C8: D6130064 23CAA92E
	v_fmac_f32_e32 v84, v100, v84                              // 000000D916D0: 56A8A964
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000D916D4: BF870125
	v_fma_f32 v101, -v52, v85, 1.0                             // 000000D916D8: D6130065 23CAAB34
	v_add_f32_e32 v22, v22, v78                                // 000000D916E0: 062C9D16
	v_dual_mul_f32 v100, v51, v84 :: v_dual_fmac_f32 v85, v101, v85// 000000D916E4: C8C0A933 6454AB65
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D916EC: BF870112
	v_mov_b32_dpp v78, v22 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D916F0: 7E9C02FA FF016816
	v_fma_f32 v114, -v46, v100, v51                            // 000000D916F8: D6130072 24CEC92E
	v_cndmask_b32_e64 v22, -v22, v22, s3                       // 000000D91700: D5010016 200E2D16
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D91708: BF870112
	v_dual_mul_f32 v101, v53, v85 :: v_dual_fmac_f32 v100, v114, v84// 000000D9170C: C8C0AB35 6564A972
	v_add_f32_e32 v22, v22, v78                                // 000000D91714: 062C9D16
	v_div_scale_f32 v78, s6, v12, v35, v12                     // 000000D91718: D6FC064E 0432470C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D91720: BF870213
	v_fma_f32 v115, -v52, v101, v53                            // 000000D91724: D6130073 24D6CB34
	v_fma_f32 v46, -v46, v100, v51                             // 000000D9172C: D613002E 24CEC92E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D91734: BF870112
	v_dual_mul_f32 v22, 0x3db504f3, v22 :: v_dual_fmac_f32 v101, v115, v85// 000000D91738: C8C02CFF 1664AB73 3DB504F3
	v_div_fmas_f32 v46, v46, v84, v100                         // 000000D91744: D637002E 0592A92E
	s_mov_b32 vcc_lo, s4                                       // 000000D9174C: BEEA0004
	s_waitcnt vmcnt(8)                                         // 000000D91750: BF8923F7
	s_delay_alu instid0(VALU_DEP_2)                            // 000000D91754: BF870002
	v_fma_mix_f32 v19, v19, v22, neg(0) op_sel_hi:[1,0,0]      // 000000D91758: CC200013 8A022D13
	v_fma_f32 v51, -v52, v101, v53                             // 000000D91760: D6130033 24D6CB34
	s_mov_b32 s4, exec_lo                                      // 000000D91768: BE84007E
	v_div_fixup_f32 v8, v46, v34, v8                           // 000000D9176C: D6270008 0422452E
	v_add_f32_e32 v42, v42, v69                                // 000000D91774: 06548B2A
	v_div_scale_f32 v69, null, v35, v35, v12                   // 000000D91778: D6FC7C45 04324723
	v_div_fmas_f32 v51, v51, v85, v101                         // 000000D91780: D6370033 0596AB33
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D91788: BF870193
	v_dual_mul_f32 v7, v7, v8 :: v_dual_mul_f32 v42, 0x3db504f3, v42// 000000D9178C: C8C61107 072A54FF 3DB504F3
	v_rcp_f32_e32 v90, v69                                     // 000000D91798: 7EB45545
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D9179C: BF870112
	v_div_fixup_f32 v9, v51, v30, v9                           // 000000D917A0: D6270009 04263D33
	v_fma_mix_f32 v10, v10, v42, neg(0) op_sel_hi:[1,0,0]      // 000000D917A8: CC20000A 8A02550A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D917B0: BF870091
	v_dual_mul_f32 v42, 0xbfb8aa3b, v20 :: v_dual_mul_f32 v9, v10, v9// 000000D917B4: C8C628FF 2A08130A BFB8AA3B
	v_exp_f32_e32 v42, v42                                     // 000000D917C0: 7E544B2A
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000D917C4: BF870126
	v_fma_f32 v106, -v69, v90, 1.0                             // 000000D917C8: D613006A 23CAB545
	s_waitcnt vmcnt(7)                                         // 000000D917D0: BF891FF7
	v_fma_mix_f32 v9, v54, v9, neg(0) op_sel_hi:[1,0,0]        // 000000D917D4: CC200009 8A021336
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000D917DC: BF870292
	v_fmac_f32_e32 v90, v106, v90                              // 000000D917E0: 56B4B56A
	v_add_f32_e32 v42, 1.0, v42                                // 000000D917E4: 065454F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D917E8: BF870112
	v_mul_f32_e32 v106, v78, v90                               // 000000D917EC: 10D4B54E
	v_div_scale_f32 v70, null, v42, v42, v20                   // 000000D917F0: D6FC7C46 0452552A
	v_div_scale_f32 v82, s7, v20, v42, v20                     // 000000D917F8: D6FC0752 04525514
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D91800: BF870193
	v_fma_f32 v117, -v69, v106, v78                            // 000000D91804: D6130075 253AD545
	v_rcp_f32_e32 v91, v70                                     // 000000D9180C: 7EB65546
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D91810: BF870091
	v_fmac_f32_e32 v106, v117, v90                             // 000000D91814: 56D4B575
	v_fma_f32 v53, -v69, v106, v78                             // 000000D91818: D6130035 253AD545
	v_fma_f32 v69, -v74, v108, v83                             // 000000D91820: D6130045 254ED94A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D91828: BF870095
	v_fma_f32 v107, -v70, v91, 1.0                             // 000000D9182C: D613006B 23CAB746
	v_dual_add_f32 v38, v38, v77 :: v_dual_fmac_f32 v91, v107, v91// 000000D91834: C9009B26 265AB76B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000D9183C: BF8701A1
	v_mov_b32_dpp v77, v38 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D91840: 7E9A02FA FF016826
	v_cndmask_b32_e64 v38, -v38, v38, s3                       // 000000D91848: D5010026 200E4D26
	v_mul_f32_e32 v107, v82, v91                               // 000000D91850: 10D6B752
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000D91854: BF8701A2
	v_add_f32_e32 v38, v38, v77                                // 000000D91858: 064C9B26
	v_div_scale_f32 v77, s5, v11, v36, v11                     // 000000D9185C: D6FC054D 042E490B
	v_fma_f32 v118, -v70, v107, v82                            // 000000D91864: D6130076 254AD746
	s_mov_b32 vcc_lo, s5                                       // 000000D9186C: BEEA0005
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D91870: BF870193
	v_mul_f32_e32 v38, 0x3db504f3, v38                         // 000000D91874: 104C4CFF 3DB504F3
	v_mul_f32_e32 v102, v77, v86                               // 000000D9187C: 10CCAD4D
	s_mov_b32 s5, 0x3db504f3                                   // 000000D91880: BE8500FF 3DB504F3
	v_fmac_f32_e32 v107, v118, v91                             // 000000D91888: 56D6B776
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000D9188C: BF8701C3
	v_fma_mix_f32 v13, v13, v38, neg(0) op_sel_hi:[1,0,0]      // 000000D91890: CC20000D 8A024D0D
	v_add_f32_e32 v50, v50, v76                                // 000000D91898: 06649932
	v_div_scale_f32 v76, null, v44, v44, v29                   // 000000D9189C: D6FC7C4C 0476592C
	v_fma_f32 v116, -v68, v102, v77                            // 000000D918A4: D6130074 2536CD44
	v_mul_f32_e32 v50, 0x3db504f3, v50                         // 000000D918AC: 106464FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D918B4: BF870113
	v_rcp_f32_e32 v94, v76                                     // 000000D918B8: 7EBC554C
	v_fmac_f32_e32 v102, v116, v86                             // 000000D918BC: 56CCAD74
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D918C0: BF870112
	v_fma_mix_f32 v18, v18, v50, neg(0) op_sel_hi:[1,0,0]      // 000000D918C4: CC200012 8A026512
	v_fma_f32 v52, -v68, v102, v77                             // 000000D918CC: D6130034 2536CD44
	v_fma_f32 v68, -v70, v107, v82                             // 000000D918D4: D6130044 254AD746
	v_fma_f32 v70, -v75, v109, v98                             // 000000D918DC: D6130046 258ADB4B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D918E4: BF870215
	v_fma_f32 v110, -v76, v94, 1.0                             // 000000D918E8: D613006E 23CABD4C
	v_div_fmas_f32 v52, v52, v86, v102                         // 000000D918F0: D6370034 059AAD34
	s_mov_b32 vcc_lo, s6                                       // 000000D918F8: BEEA0006
	v_div_fmas_f32 v34, v53, v90, v106                         // 000000D918FC: D6370022 05AAB535
	s_delay_alu instid0(VALU_DEP_3)                            // 000000D91904: BF870003
	v_fmac_f32_e32 v94, v110, v94                              // 000000D91908: 56BCBD6E
	s_mov_b32 vcc_lo, s7                                       // 000000D9190C: BEEA0007
	v_div_fixup_f32 v11, v52, v36, v11                         // 000000D91910: D627000B 042E4934
	v_div_fmas_f32 v30, v68, v91, v107                         // 000000D91918: D637001E 05AEB744
	s_mov_b32 vcc_lo, s8                                       // 000000D91920: BEEA0008
	v_mul_f32_e32 v110, v99, v94                               // 000000D91924: 10DCBD63
	v_div_fixup_f32 v8, v34, v35, v12                          // 000000D91928: D6270008 04324722
	v_div_fmas_f32 v10, v69, v92, v108                         // 000000D91930: D637000A 05B2B945
	s_mov_b32 vcc_lo, s9                                       // 000000D91938: BEEA0009
	v_mul_f32_e32 v11, v26, v11                                // 000000D9193C: 1016171A
	v_fma_f32 v124, -v76, v110, v99                            // 000000D91940: D613007C 258EDD4C
	v_div_fmas_f32 v26, v70, v93, v109                         // 000000D91948: D637001A 05B6BB46
	s_mov_b32 vcc_lo, s10                                      // 000000D91950: BEEA000A
	v_div_fixup_f32 v10, v10, v37, v21                         // 000000D91954: D627000A 04564B0A
	v_mul_f32_e32 v8, v27, v8                                  // 000000D9195C: 1010111B
	v_fmac_f32_e32 v110, v124, v94                             // 000000D91960: 56DCBD7C
	v_div_fixup_f32 v20, v30, v42, v20                         // 000000D91964: D6270014 0452551E
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D9196C: BF870224
	v_mul_f32_e32 v10, v18, v10                                // 000000D91970: 10141512
	v_div_fixup_f32 v18, v26, v43, v28                         // 000000D91974: D6270012 0472571A
	v_fma_f32 v12, -v76, v110, v99                             // 000000D9197C: D613000C 258EDD4C
	s_waitcnt vmcnt(6)                                         // 000000D91984: BF891BF7
	v_fma_mix_f32 v8, v58, v8, neg(0) op_sel_hi:[1,0,0]        // 000000D91988: CC200008 8A02113A
	v_mul_f32_e32 v14, v14, v20                                // 000000D91990: 101C290E
	s_waitcnt vmcnt(5)                                         // 000000D91994: BF8917F7
	v_fma_mix_f32 v10, v59, v10, neg(0) op_sel_hi:[1,0,0]      // 000000D91998: CC20000A 8A02153B
	v_mul_f32_e32 v13, v13, v18                                // 000000D919A0: 101A250D
	v_div_fmas_f32 v12, v12, v94, v110                         // 000000D919A4: D637000C 05BABD0C
	s_waitcnt vmcnt(0)                                         // 000000D919AC: BF8903F7
	v_fma_mix_f32 v18, v7, v67, v9 op_sel_hi:[0,1,0]           // 000000D919B0: CC200012 14268707
	v_fma_mix_f32 v7, v7, v67, -v9 op_sel_hi:[0,1,0]           // 000000D919B8: CC200007 94268707
	v_fma_mix_f32 v20, v14, v62, v10 op_sel_hi:[0,1,0]         // 000000D919C0: CC200014 142A7D0E
	v_fma_mix_f32 v10, v14, v62, -v10 op_sel_hi:[0,1,0]        // 000000D919C8: CC20000A 942A7D0E
	v_div_fixup_f32 v12, v12, v44, v29                         // 000000D919D0: D627000C 0476590C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000D919D8: BF8701B1
	v_mul_f32_e32 v12, v19, v12                                // 000000D919DC: 10181913
	v_fma_mix_f32 v19, v11, v66, v8 op_sel_hi:[0,1,0]          // 000000D919E0: CC200013 1422850B
	v_fma_mix_f32 v8, v11, v66, -v8 op_sel_hi:[0,1,0]          // 000000D919E8: CC200008 9422850B
	v_fma_mix_f32 v12, v60, v12, neg(0) op_sel_hi:[1,0,0]      // 000000D919F0: CC20000C 8A02193C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D919F8: BF870113
	v_add_f32_e32 v22, v18, v19                                // 000000D919FC: 062C2712
	v_fma_mix_f32 v21, v13, v61, v12 op_sel_hi:[0,1,0]         // 000000D91A00: CC200015 14327B0D
	v_fma_mix_f32 v11, v13, v61, -v12 op_sel_hi:[0,1,0]        // 000000D91A08: CC20000B 94327B0D
	v_dual_sub_f32 v12, v18, v19 :: v_dual_add_f32 v13, v7, v8 // 000000D91A10: C9482712 0C0C1107
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D91A18: BF870193
	v_dual_sub_f32 v7, v7, v8 :: v_dual_add_f32 v26, v20, v21  // 000000D91A1C: C9481107 071A2B14
	v_add_f32_e32 v8, v10, v11                                 // 000000D91A24: 0610170A
	v_sub_f32_e32 v18, v20, v21                                // 000000D91A28: 08242B14
	v_sub_f32_e32 v10, v10, v11                                // 000000D91A2C: 0814170A
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000D91A30: BF870124
	v_add_f32_e32 v9, v22, v26                                 // 000000D91A34: 06123516
	v_sub_f32_e32 v11, v22, v26                                // 000000D91A38: 08163516
	v_mov_b32_dpp v14, v9 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D91A3C: 7E1C02FA FF016109
	v_cndmask_b32_e64 v9, -v9, v9, s0                          // 000000D91A44: D5010009 20021309
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D91A4C: BF870113
	v_cndmask_b32_e64 v26, -v11, v11, s0                       // 000000D91A50: D501001A 2002170B
	v_add_f32_e32 v9, v9, v14                                  // 000000D91A58: 06121D09
	v_add_f32_e32 v14, v13, v8                                 // 000000D91A5C: 061C110D
	v_dual_sub_f32 v13, v13, v8 :: v_dual_add_f32 v8, v12, v18 // 000000D91A60: C948110D 0D08250C
	v_sub_f32_e32 v18, v12, v18                                // 000000D91A68: 0824250C
	s_delay_alu instid0(VALU_DEP_4)                            // 000000D91A6C: BF870004
	v_mov_b32_dpp v19, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D91A70: 7E2602FA FF016209
	v_cndmask_b32_e64 v9, -v9, v9, s1                          // 000000D91A78: D5010009 20061309
	v_mov_b32_dpp v20, v14 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D91A80: 7E2802FA FF01610E
	v_cndmask_b32_e64 v14, -v14, v14, s0                       // 000000D91A88: D501000E 20021D0E
	v_mov_b32_dpp v21, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D91A90: 7E2A02FA FF016108
	v_cndmask_b32_e64 v8, -v8, v8, s0                          // 000000D91A98: D5010008 20021108
	v_add_f32_e32 v9, v9, v19                                  // 000000D91AA0: 06122709
	v_mov_b32_dpp v27, v18 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D91AA4: 7E3602FA FF016112
	v_add_f32_e32 v12, v14, v20                                // 000000D91AAC: 0618290E
	v_add_f32_e32 v14, v7, v10                                 // 000000D91AB0: 061C1507
	v_add_f32_e32 v8, v8, v21                                  // 000000D91AB4: 06102B08
	v_mov_b32_dpp v19, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D91AB8: 7E2602FA FF016409
	v_cndmask_b32_e64 v9, -v9, v9, s2                          // 000000D91AC0: D5010009 200A1309
	v_mov_b32_dpp v20, v12 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D91AC8: 7E2802FA FF01620C
	v_cndmask_b32_e64 v12, -v12, v12, s1                       // 000000D91AD0: D501000C 2006190C
	v_mov_b32_dpp v21, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D91AD8: 7E2A02FA FF016208
	v_cndmask_b32_e64 v8, -v8, v8, s1                          // 000000D91AE0: D5010008 20061108
	v_mov_b32_dpp v22, v14 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D91AE8: 7E2C02FA FF01610E
	v_cndmask_b32_e64 v14, -v14, v14, s0                       // 000000D91AF0: D501000E 20021D0E
	v_add_f32_e32 v12, v12, v20                                // 000000D91AF8: 0618290C
	v_sub_f32_e32 v20, v7, v10                                 // 000000D91AFC: 08281507
	v_dual_add_f32 v8, v8, v21 :: v_dual_add_f32 v7, v9, v19   // 000000D91B00: C9082B08 08062709
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000D91B08: BF870234
	v_add_f32_e32 v9, v14, v22                                 // 000000D91B0C: 06122D0E
	v_mov_b32_dpp v22, v11 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D91B10: 7E2C02FA FF01610B
	v_cndmask_b32_e64 v18, -v18, v18, s0                       // 000000D91B18: D5010012 20022512
	v_mov_b32_dpp v14, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D91B20: 7E1C02FA FF016408
	v_cndmask_b32_e64 v8, -v8, v8, s2                          // 000000D91B28: D5010008 200A1108
	v_mov_b32_dpp v19, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D91B30: 7E2602FA FF016209
	v_cndmask_b32_e64 v21, -v9, v9, s1                         // 000000D91B38: D5010015 20061309
	v_mov_b32_dpp v28, v20 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D91B40: 7E3802FA FF016114
	v_cndmask_b32_e64 v20, -v20, v20, s0                       // 000000D91B48: D5010014 20022914
	v_add_f32_e32 v11, v8, v14                                 // 000000D91B50: 06161D08
	v_mov_b32_dpp v10, v12 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D91B54: 7E1402FA FF01640C
	v_dual_add_f32 v14, v21, v19 :: v_dual_add_f32 v19, v26, v22// 000000D91B5C: C9082715 0E122D1A
	v_mov_b32_dpp v26, v13 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D91B64: 7E3402FA FF01610D
	v_cndmask_b32_e64 v13, -v13, v13, s0                       // 000000D91B6C: D501000D 20021B0D
	v_cndmask_b32_e64 v12, -v12, v12, s2                       // 000000D91B74: D501000C 200A190C
	s_delay_alu instid0(VALU_DEP_4)                            // 000000D91B7C: BF870004
	v_mov_b32_dpp v21, v14 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D91B80: 7E2A02FA FF01640E
	v_cndmask_b32_e64 v14, -v14, v14, s2                       // 000000D91B88: D501000E 200A1D0E
	v_mov_b32_dpp v22, v19 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D91B90: 7E2C02FA FF016213
	v_cndmask_b32_e64 v19, -v19, v19, s1                       // 000000D91B98: D5010013 20062713
	v_add_f32_e32 v26, v13, v26                                // 000000D91BA0: 0634350D
	v_add_f32_e32 v9, v12, v10                                 // 000000D91BA4: 0612150C
	v_add_f32_e32 v13, v14, v21                                // 000000D91BA8: 061A2B0E
	v_add_f32_e32 v14, v18, v27                                // 000000D91BAC: 061C3712
	v_dual_add_f32 v18, v19, v22 :: v_dual_add_f32 v19, v20, v28// 000000D91BB0: C9082D13 12123914
	v_mov_b32_dpp v20, v26 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D91BB8: 7E2802FA FF01621A
	v_cndmask_b32_e64 v21, -v26, v26, s1                       // 000000D91BC0: D5010015 2006351A
	s_delay_alu instid0(VALU_DEP_4)                            // 000000D91BC8: BF870004
	v_mov_b32_dpp v22, v14 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D91BCC: 7E2C02FA FF01620E
	v_cndmask_b32_e64 v14, -v14, v14, s1                       // 000000D91BD4: D501000E 20061D0E
	v_mov_b32_dpp v26, v19 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D91BDC: 7E3402FA FF016213
	v_cndmask_b32_e64 v19, -v19, v19, s1                       // 000000D91BE4: D5010013 20062713
	v_add_f32_e32 v20, v21, v20                                // 000000D91BEC: 06282915
	v_mov_b32_dpp v21, v18 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D91BF0: 7E2A02FA FF016412
	v_add_f32_e32 v14, v14, v22                                // 000000D91BF8: 061C2D0E
	v_cndmask_b32_e64 v18, -v18, v18, s2                       // 000000D91BFC: D5010012 200A2512
	v_add_f32_e32 v19, v19, v26                                // 000000D91C04: 06263513
	v_mov_b32_dpp v22, v20 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D91C08: 7E2C02FA FF016414
	v_cndmask_b32_e64 v26, -v20, v20, s2                       // 000000D91C10: D501001A 200A2914
	v_mov_b32_dpp v27, v14 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D91C18: 7E3602FA FF01640E
	v_cndmask_b32_e64 v28, -v14, v14, s2                       // 000000D91C20: D501001C 200A1D0E
	v_mov_b32_dpp v29, v19 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D91C28: 7E3A02FA FF016413
	v_cndmask_b32_e64 v19, -v19, v19, s2                       // 000000D91C30: D5010013 200A2713
	v_add_f32_e32 v20, v18, v21                                // 000000D91C38: 06282B12
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D91C3C: BF870224
	v_dual_add_f32 v21, v26, v22 :: v_dual_add_f32 v26, v28, v27// 000000D91C40: C9082D1A 151A371C
	v_mov_b32_dpp v8, v7 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D91C48: 7E1002FA FF016807
	v_add_f32_e32 v28, v19, v29                                // 000000D91C50: 06383B13
	v_mov_b32_dpp v10, v9 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D91C54: 7E1402FA FF016809
	v_mov_b32_dpp v12, v11 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D91C5C: 7E1802FA FF01680B
	v_mov_b32_dpp v14, v13 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D91C64: 7E1C02FA FF01680D
	v_add_nc_u32_e32 v18, 8, v6                                // 000000D91C6C: 4A240C88
	v_mov_b32_dpp v19, v20 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D91C70: 7E2602FA FF016814
	v_mov_b32_dpp v22, v21 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D91C78: 7E2C02FA FF016815
	v_mov_b32_dpp v27, v26 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D91C80: 7E3602FA FF01681A
	v_mov_b32_dpp v29, v28 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D91C88: 7E3A02FA FF01681C
	.long 0xd4c4007e                                           // 000000D91C90: D4C4007E
	v_cndmask_b32_e32 v1, s23, v18, vcc_lo                     // 000000D91C94: 02022417
	s_cbranch_execz 60                                         // 000000D91C98: BFA5003C <_ZN7halogen12_GLOBAL__N_111k_ht_moe_guILi3ELi8ELi1EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_S5_PDF16_+0x5a8c>
	v_cndmask_b32_e64 v26, -v26, v26, s3                       // 000000D91C9C: D501001A 200E351A
	v_cndmask_b32_e64 v7, -v7, v7, s3                          // 000000D91CA4: D5010007 200E0F07
	v_cndmask_b32_e64 v20, -v20, v20, s3                       // 000000D91CAC: D5010014 200E2914
	v_cndmask_b32_e64 v9, -v9, v9, s3                          // 000000D91CB4: D5010009 200E1309
	v_cndmask_b32_e64 v11, -v11, v11, s3                       // 000000D91CBC: D501000B 200E170B
	v_cndmask_b32_e64 v13, -v13, v13, s3                       // 000000D91CC4: D501000D 200E1B0D
	v_cndmask_b32_e64 v28, -v28, v28, s3                       // 000000D91CCC: D501001C 200E391C
	v_cndmask_b32_e64 v21, -v21, v21, s3                       // 000000D91CD4: D5010015 200E2B15
	v_dual_add_f32 v26, v26, v27 :: v_dual_add_f32 v7, v7, v8  // 000000D91CDC: C908371A 1A061107
	v_dual_add_f32 v19, v20, v19 :: v_dual_add_f32 v8, v9, v10 // 000000D91CE4: C9082714 13081509
	v_dual_add_f32 v9, v11, v12 :: v_dual_add_f32 v10, v13, v14// 000000D91CEC: C908190B 090A1D0D
	v_mad_i64_i32 v[11:12], null, 0x500, v18, v[0:1]           // 000000D91CF4: D6FF7C0B 040224FF 00000500
	v_dual_add_f32 v28, v28, v29 :: v_dual_add_f32 v21, v21, v22// 000000D91D00: C9083B1C 1C142D15
	v_fma_mixlo_f16 v7, v7, s5, 0                              // 000000D91D08: CC210007 02000B07
	v_fma_mixhi_f16 v7, v8, s5, 0                              // 000000D91D10: CC220007 02000B08
	v_fma_mixlo_f16 v8, v9, s5, 0                              // 000000D91D18: CC210008 02000B09
	v_fma_mixhi_f16 v8, v10, s5, 0                             // 000000D91D20: CC220008 02000B0A
	v_fma_mixlo_f16 v9, v19, s5, 0                             // 000000D91D28: CC210009 02000B13
	v_fma_mixhi_f16 v9, v21, s5, 0                             // 000000D91D30: CC220009 02000B15
	v_fma_mixlo_f16 v10, v26, s5, 0                            // 000000D91D38: CC21000A 02000B1A
	v_fma_mixhi_f16 v10, v28, s5, 0                            // 000000D91D40: CC22000A 02000B1C
	s_clause 0x7                                               // 000000D91D48: BF850007
	global_store_b16 v[11:12], v7, off                         // 000000D91D4C: DC660000 007C070B
	global_store_d16_hi_b16 v[11:12], v7, off offset:32        // 000000D91D54: DC960020 007C070B
	global_store_b16 v[11:12], v8, off offset:64               // 000000D91D5C: DC660040 007C080B
	global_store_d16_hi_b16 v[11:12], v8, off offset:96        // 000000D91D64: DC960060 007C080B
	global_store_b16 v[11:12], v9, off offset:128              // 000000D91D6C: DC660080 007C090B
	global_store_d16_hi_b16 v[11:12], v9, off offset:160       // 000000D91D74: DC9600A0 007C090B
	global_store_b16 v[11:12], v10, off offset:192             // 000000D91D7C: DC6600C0 007C0A0B
	global_store_d16_hi_b16 v[11:12], v10, off offset:224      // 000000D91D84: DC9600E0 007C0A0B
	s_or_b32 exec_lo, exec_lo, s4                              // 000000D91D8C: 8C7E047E
	s_clause 0xb                                               // 000000D91D90: BF85000B
	global_load_d16_b16 v7, v[2:3], off offset:1280            // 000000D91D94: DC820500 077C0002
	global_load_d16_b16 v10, v[2:3], off offset:1312           // 000000D91D9C: DC820520 0A7C0002
	global_load_d16_b16 v8, v[2:3], off                        // 000000D91DA4: DC820000 087C0002
	global_load_d16_b16 v9, v[2:3], off offset:32              // 000000D91DAC: DC820020 097C0002
	global_load_d16_b16 v11, v[2:3], off offset:64             // 000000D91DB4: DC820040 0B7C0002
	global_load_d16_b16 v12, v[2:3], off offset:96             // 000000D91DBC: DC820060 0C7C0002
	global_load_d16_b16 v19, v[2:3], off offset:128            // 000000D91DC4: DC820080 137C0002
	global_load_d16_b16 v20, v[2:3], off offset:160            // 000000D91DCC: DC8200A0 147C0002
	global_load_d16_b16 v26, v[2:3], off offset:192            // 000000D91DD4: DC8200C0 1A7C0002
	global_load_d16_b16 v27, v[2:3], off offset:224            // 000000D91DDC: DC8200E0 1B7C0002
	global_load_d16_b16 v21, v[2:3], off offset:1344           // 000000D91DE4: DC820540 157C0002
	global_load_d16_b16 v22, v[2:3], off offset:1376           // 000000D91DEC: DC820560 167C0002
	v_add_f32_e32 v46, v39, v31                                // 000000D91DF4: 065C3F27
	v_sub_f32_e32 v31, v39, v31                                // 000000D91DF8: 083E3F27
	v_add_f32_e32 v39, v23, v15                                // 000000D91DFC: 064E1F17
	v_sub_f32_e32 v38, v87, v79                                // 000000D91E00: 084C9F57
	s_delay_alu instid0(VALU_DEP_2)                            // 000000D91E04: BF870002
	v_add_f32_e32 v60, v46, v39                                // 000000D91E08: 06784F2E
	v_sub_f32_e32 v36, v103, v95                               // 000000D91E0C: 0848BF67
	v_add_f32_e32 v30, v119, v111                              // 000000D91E10: 063CDF77
	v_sub_f32_e32 v29, v135, v127                              // 000000D91E14: 083AFF87
	v_sub_f32_e32 v34, v119, v111                              // 000000D91E18: 0844DF77
	v_add_f32_e32 v28, v135, v127                              // 000000D91E1C: 0638FF87
	v_add_f32_e32 v35, v103, v95                               // 000000D91E20: 0646BF67
	v_add_f32_e32 v37, v87, v79                                // 000000D91E24: 064A9F57
	v_sub_f32_e32 v39, v46, v39                                // 000000D91E28: 084E4F2E
	s_delay_alu instid0(VALU_DEP_4)                            // 000000D91E2C: BF870004
	v_add_f32_e32 v59, v28, v30                                // 000000D91E30: 06763D1C
	v_sub_f32_e32 v28, v28, v30                                // 000000D91E34: 08383D1C
	v_add_f32_e32 v30, v29, v34                                // 000000D91E38: 063C451D
	v_dual_sub_f32 v29, v29, v34 :: v_dual_add_f32 v34, v35, v37// 000000D91E3C: C948451D 1D224B23
	v_sub_f32_e32 v35, v35, v37                                // 000000D91E44: 08464B23
	v_add_f32_e32 v37, v36, v38                                // 000000D91E48: 064A4D24
	v_sub_f32_e32 v36, v36, v38                                // 000000D91E4C: 08484D24
	v_add_f32_e32 v42, v71, v63                                // 000000D91E50: 06547F47
	v_add_f32_e32 v44, v55, v47                                // 000000D91E54: 06585F37
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000D91E58: BF8701A3
	v_dual_add_f32 v62, v28, v35 :: v_dual_add_f32 v61, v29, v36// 000000D91E5C: C908471C 3E3C491D
	v_sub_f32_e32 v29, v29, v36                                // 000000D91E64: 083A491D
	v_dual_sub_f32 v43, v71, v63 :: v_dual_add_f32 v38, v42, v44// 000000D91E68: C9487F47 2B26592A
	v_dual_sub_f32 v45, v55, v47 :: v_dual_sub_f32 v42, v42, v44// 000000D91E70: C94A5F37 2D2A592A
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000D91E78: BF870234
	v_mov_b32_dpp v74, v61 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D91E7C: 7E9402FA FF01613D
	v_cndmask_b32_e64 v61, -v61, v61, s0                       // 000000D91E84: D501003D 20027B3D
	v_mov_b32_dpp v78, v29 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D91E8C: 7E9C02FA FF01611D
	v_add_f32_e32 v44, v43, v45                                // 000000D91E94: 06585B2B
	v_sub_f32_e32 v23, v23, v15                                // 000000D91E98: 082E1F17
	s_clause 0x3                                               // 000000D91E9C: BF850003
	global_load_d16_b16 v14, v[2:3], off offset:1408           // 000000D91EA0: DC820580 0E7C0002
	global_load_d16_b16 v15, v[2:3], off offset:1440           // 000000D91EA8: DC8205A0 0F7C0002
	global_load_d16_b16 v13, v[2:3], off offset:1472           // 000000D91EB0: DC8205C0 0D7C0002
	global_load_d16_b16 v18, v[2:3], off offset:1504           // 000000D91EB8: DC8205E0 127C0002
	s_clause 0x7                                               // 000000D91EC0: BF850007
	global_load_d16_b16 v47, v[4:5], off offset:32             // 000000D91EC4: DC820020 2F7C0004
	global_load_d16_b16 v50, v[4:5], off offset:96             // 000000D91ECC: DC820060 327C0004
	global_load_d16_b16 v51, v[4:5], off offset:160            // 000000D91ED4: DC8200A0 337C0004
	global_load_d16_b16 v52, v[4:5], off offset:224            // 000000D91EDC: DC8200E0 347C0004
	global_load_d16_b16 v53, v[4:5], off offset:192            // 000000D91EE4: DC8200C0 357C0004
	global_load_d16_b16 v54, v[4:5], off offset:128            // 000000D91EEC: DC820080 367C0004
	global_load_d16_b16 v55, v[4:5], off offset:64             // 000000D91EF4: DC820040 377C0004
	global_load_d16_b16 v58, v[4:5], off                       // 000000D91EFC: DC820000 3A7C0004
	v_sub_f32_e32 v43, v43, v45                                // 000000D91F04: 08565B2B
	v_cndmask_b32_e64 v29, -v29, v29, s0                       // 000000D91F08: D501001D 20023B1D
	v_add_f32_e32 v45, v31, v23                                // 000000D91F10: 065A2F1F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000D91F14: BF8701B1
	v_dual_add_f32 v29, v29, v78 :: v_dual_add_f32 v46, v44, v45// 000000D91F18: C9089D1D 1D2E5B2C
	v_dual_sub_f32 v44, v44, v45 :: v_dual_add_f32 v45, v42, v39// 000000D91F20: C9485B2C 2C2C4F2A
	v_sub_f32_e32 v39, v42, v39                                // 000000D91F28: 084E4F2A
	v_mov_b32_dpp v78, v29 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D91F2C: 7E9C02FA FF01621D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D91F34: BF870214
	v_mov_b32_dpp v36, v46 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D91F38: 7E4802FA FF01612E
	v_mov_b32_dpp v66, v44 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D91F40: 7E8402FA FF01612C
	v_cndmask_b32_e64 v44, -v44, v44, s0                       // 000000D91F48: D501002C 2002592C
	v_sub_f32_e32 v23, v31, v23                                // 000000D91F50: 082E2F1F
	v_add_f32_e32 v31, v38, v60                                // 000000D91F54: 063E7926
	v_sub_f32_e32 v38, v38, v60                                // 000000D91F58: 084C7926
	v_add_f32_e32 v60, v59, v34                                // 000000D91F5C: 0678453B
	v_sub_f32_e32 v34, v59, v34                                // 000000D91F60: 0844453B
	v_add_f32_e32 v42, v43, v23                                // 000000D91F64: 06542F2B
	v_mov_b32_dpp v67, v39 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D91F68: 7E8602FA FF016127
	v_mov_b32_dpp v63, v38 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D91F70: 7E7E02FA FF016126
	v_mov_b32_dpp v69, v60 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D91F78: 7E8A02FA FF01613C
	v_cndmask_b32_e64 v60, -v60, v60, s0                       // 000000D91F80: D501003C 2002793C
	v_sub_f32_e32 v23, v43, v23                                // 000000D91F88: 082E2F2B
	v_add_f32_e32 v43, v30, v37                                // 000000D91F8C: 06564B1E
	v_sub_f32_e32 v30, v30, v37                                // 000000D91F90: 083C4B1E
	v_cndmask_b32_e64 v37, -v46, v46, s0                       // 000000D91F94: D5010025 20025D2E
	v_mov_b32_dpp v46, v45 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D91F9C: 7E5C02FA FF01612D
	v_cndmask_b32_e64 v45, -v45, v45, s0                       // 000000D91FA4: D501002D 20025B2D
	v_mov_b32_dpp v70, v43 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D91FAC: 7E8C02FA FF01612B
	v_cndmask_b32_e64 v43, -v43, v43, s0                       // 000000D91FB4: D501002B 2002572B
	v_sub_f32_e32 v28, v28, v35                                // 000000D91FBC: 0838471C
	v_mov_b32_dpp v35, v31 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D91FC0: 7E4602FA FF01611F
	v_cndmask_b32_e64 v31, -v31, v31, s0                       // 000000D91FC8: D501001F 20023F1F
	v_mov_b32_dpp v76, v30 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D91FD0: 7E9802FA FF01611E
	v_cndmask_b32_e64 v30, -v30, v30, s0                       // 000000D91FD8: D501001E 20023D1E
	v_cndmask_b32_e64 v38, -v38, v38, s0                       // 000000D91FE0: D5010026 20024D26
	v_cndmask_b32_e64 v39, -v39, v39, s0                       // 000000D91FE8: D5010027 20024F27
	v_add_f32_e32 v31, v31, v35                                // 000000D91FF0: 063E471F
	v_add_f32_e32 v35, v37, v36                                // 000000D91FF4: 06464925
	v_add_f32_e32 v36, v45, v46                                // 000000D91FF8: 06485D2D
	v_add_f32_e32 v45, v61, v74                                // 000000D91FFC: 065A953D
	v_mov_b32_dpp v59, v42 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D92000: 7E7602FA FF01612A
	v_cndmask_b32_e64 v42, -v42, v42, s0                       // 000000D92008: D501002A 2002552A
	v_add_f32_e32 v43, v43, v70                                // 000000D92010: 06568D2B
	v_mov_b32_dpp v77, v28 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D92014: 7E9A02FA FF01611C
	v_cndmask_b32_e64 v28, -v28, v28, s0                       // 000000D9201C: D501001C 2002391C
	v_add_f32_e32 v38, v38, v63                                // 000000D92024: 064C7F26
	v_dual_add_f32 v37, v42, v59 :: v_dual_add_f32 v42, v44, v66// 000000D92028: C908772A 252A852C
	v_add_f32_e32 v44, v60, v69                                // 000000D92030: 06588B3C
	v_mov_b32_dpp v68, v23 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D92034: 7E8802FA FF016117
	v_cndmask_b32_e64 v23, -v23, v23, s0                       // 000000D9203C: D5010017 20022F17
	v_mov_b32_dpp v75, v34 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D92044: 7E9602FA FF016122
	v_cndmask_b32_e64 v34, -v34, v34, s0                       // 000000D9204C: D5010022 20024522
	v_dual_add_f32 v39, v39, v67 :: v_dual_add_f32 v28, v28, v77// 000000D92054: C9088727 271C9B1C
	s_delay_alu instid0(VALU_DEP_4)                            // 000000D9205C: BF870004
	v_add_f32_e32 v23, v23, v68                                // 000000D92060: 062E8917
	v_mov_b32_dpp v71, v62 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D92064: 7E8E02FA FF01613E
	v_cndmask_b32_e64 v62, -v62, v62, s0                       // 000000D9206C: D501003E 20027D3E
	v_add_f32_e32 v30, v30, v76                                // 000000D92074: 063C991E
	v_mov_b32_dpp v59, v31 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D92078: 7E7602FA FF01621F
	v_cndmask_b32_e64 v31, -v31, v31, s1                       // 000000D92080: D501001F 20063F1F
	v_mov_b32_dpp v60, v35 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D92088: 7E7802FA FF016223
	v_cndmask_b32_e64 v35, -v35, v35, s1                       // 000000D92090: D5010023 20064723
	v_add_f32_e32 v46, v62, v71                                // 000000D92098: 065C8F3E
	v_mov_b32_dpp v62, v37 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D9209C: 7E7C02FA FF016225
	v_cndmask_b32_e64 v37, -v37, v37, s1                       // 000000D920A4: D5010025 20064B25
	v_add_f32_e32 v34, v34, v75                                // 000000D920AC: 06449722
	v_mov_b32_dpp v69, v44 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D920B0: 7E8A02FA FF01622C
	v_mov_b32_dpp v70, v43 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D920B8: 7E8C02FA FF01622B
	v_cndmask_b32_e64 v43, -v43, v43, s1                       // 000000D920C0: D501002B 2006572B
	v_cndmask_b32_e64 v44, -v44, v44, s1                       // 000000D920C8: D501002C 2006592C
	v_mov_b32_dpp v61, v36 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D920D0: 7E7A02FA FF016224
	v_cndmask_b32_e64 v36, -v36, v36, s1                       // 000000D920D8: D5010024 20064924
	v_mov_b32_dpp v74, v45 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D920E0: 7E9402FA FF01622D
	v_cndmask_b32_e64 v45, -v45, v45, s1                       // 000000D920E8: D501002D 20065B2D
	v_mov_b32_dpp v76, v30 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D920F0: 7E9802FA FF01621E
	v_cndmask_b32_e64 v30, -v30, v30, s1                       // 000000D920F8: D501001E 20063D1E
	v_mov_b32_dpp v77, v28 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D92100: 7E9A02FA FF01621C
	v_cndmask_b32_e64 v29, -v29, v29, s1                       // 000000D92108: D501001D 20063B1D
	v_cndmask_b32_e64 v28, -v28, v28, s1                       // 000000D92110: D501001C 2006391C
	v_dual_add_f32 v31, v31, v59 :: v_dual_add_f32 v36, v36, v61// 000000D92118: C908771F 1F247B24
	v_add_f32_e32 v35, v35, v60                                // 000000D92120: 06467923
	v_mov_b32_dpp v71, v46 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D92124: 7E8E02FA FF01622E
	v_cndmask_b32_e64 v46, -v46, v46, s1                       // 000000D9212C: D501002E 20065D2E
	v_add_f32_e32 v37, v37, v62                                // 000000D92134: 064A7D25
	v_mov_b32_dpp v75, v34 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D92138: 7E9602FA FF016222
	v_cndmask_b32_e64 v34, -v34, v34, s1                       // 000000D92140: D5010022 20064522
	v_dual_add_f32 v43, v43, v70 :: v_dual_add_f32 v44, v44, v69// 000000D92148: C9088D2B 2B2C8B2C
	v_mov_b32_dpp v63, v38 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D92150: 7E7E02FA FF016226
	v_cndmask_b32_e64 v38, -v38, v38, s1                       // 000000D92158: D5010026 20064D26
	v_mov_b32_dpp v68, v23 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D92160: 7E8802FA FF016217
	v_cndmask_b32_e64 v23, -v23, v23, s1                       // 000000D92168: D5010017 20062F17
	v_dual_add_f32 v45, v45, v74 :: v_dual_add_f32 v46, v46, v71// 000000D92170: C908952D 2D2E8F2E
	v_dual_add_f32 v30, v30, v76 :: v_dual_add_f32 v29, v29, v78// 000000D92178: C908991E 1E1C9D1D
	v_mov_b32_dpp v59, v31 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D92180: 7E7602FA FF01641F
	v_cndmask_b32_e64 v31, -v31, v31, s2                       // 000000D92188: D501001F 200A3F1F
	v_add_f32_e32 v28, v28, v77                                // 000000D92190: 06389B1C
	v_mov_b32_dpp v60, v35 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D92194: 7E7802FA FF016423
	v_cndmask_b32_e64 v35, -v35, v35, s2                       // 000000D9219C: D5010023 200A4723
	v_add_f32_e32 v34, v34, v75                                // 000000D921A4: 06449722
	v_mov_b32_dpp v69, v44 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D921A8: 7E8A02FA FF01642C
	v_mov_b32_dpp v70, v43 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D921B0: 7E8C02FA FF01642B
	v_cndmask_b32_e64 v43, -v43, v43, s2                       // 000000D921B8: D501002B 200A572B
	v_cndmask_b32_e64 v44, -v44, v44, s2                       // 000000D921C0: D501002C 200A592C
	v_dual_add_f32 v38, v38, v63 :: v_dual_add_f32 v23, v23, v68// 000000D921C8: C9087F26 26168917
	v_mov_b32_dpp v71, v46 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D921D0: 7E8E02FA FF01642E
	v_mov_b32_dpp v74, v45 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D921D8: 7E9402FA FF01642D
	v_cndmask_b32_e64 v45, -v45, v45, s2                       // 000000D921E0: D501002D 200A5B2D
	v_cndmask_b32_e64 v46, -v46, v46, s2                       // 000000D921E8: D501002E 200A5D2E
	v_mov_b32_dpp v76, v30 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D921F0: 7E9802FA FF01641E
	v_cndmask_b32_e64 v30, -v30, v30, s2                       // 000000D921F8: D501001E 200A3D1E
	v_mov_b32_dpp v78, v29 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D92200: 7E9C02FA FF01641D
	v_cndmask_b32_e64 v29, -v29, v29, s2                       // 000000D92208: D501001D 200A3B1D
	v_add_f32_e32 v31, v31, v59                                // 000000D92210: 063E771F
	v_mov_b32_dpp v77, v28 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D92214: 7E9A02FA FF01641C
	v_cndmask_b32_e64 v28, -v28, v28, s2                       // 000000D9221C: D501001C 200A391C
	v_add_f32_e32 v35, v35, v60                                // 000000D92224: 06467923
	v_mov_b32_dpp v75, v34 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D92228: 7E9602FA FF016422
	v_cndmask_b32_e64 v34, -v34, v34, s2                       // 000000D92230: D5010022 200A4522
	v_dual_add_f32 v43, v43, v70 :: v_dual_add_f32 v44, v44, v69// 000000D92238: C9088D2B 2B2C8B2C
	v_mov_b32_dpp v63, v38 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D92240: 7E7E02FA FF016426
	v_cndmask_b32_e64 v38, -v38, v38, s2                       // 000000D92248: D5010026 200A4D26
	v_mov_b32_dpp v68, v23 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D92250: 7E8802FA FF016417
	v_cndmask_b32_e64 v23, -v23, v23, s2                       // 000000D92258: D5010017 200A2F17
	v_dual_add_f32 v45, v45, v74 :: v_dual_add_f32 v46, v46, v71// 000000D92260: C908952D 2D2E8F2E
	v_dual_add_f32 v30, v30, v76 :: v_dual_add_f32 v29, v29, v78// 000000D92268: C908991E 1E1C9D1D
	v_mov_b32_dpp v59, v31 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D92270: 7E7602FA FF01681F
	v_cndmask_b32_e64 v31, -v31, v31, s3                       // 000000D92278: D501001F 200E3F1F
	v_add_f32_e32 v28, v28, v77                                // 000000D92280: 06389B1C
	v_mov_b32_dpp v60, v35 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D92284: 7E7802FA FF016823
	v_cndmask_b32_e64 v35, -v35, v35, s3                       // 000000D9228C: D5010023 200E4723
	v_add_f32_e32 v34, v34, v75                                // 000000D92294: 06449722
	v_mov_b32_dpp v69, v44 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D92298: 7E8A02FA FF01682C
	v_mov_b32_dpp v70, v43 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D922A0: 7E8C02FA FF01682B
	v_cndmask_b32_e64 v43, -v43, v43, s3                       // 000000D922A8: D501002B 200E572B
	v_cndmask_b32_e64 v44, -v44, v44, s3                       // 000000D922B0: D501002C 200E592C
	v_mov_b32_dpp v66, v42 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D922B8: 7E8402FA FF01622A
	v_cndmask_b32_e64 v42, -v42, v42, s1                       // 000000D922C0: D501002A 2006552A
	v_mov_b32_dpp v67, v39 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D922C8: 7E8602FA FF016227
	v_cndmask_b32_e64 v39, -v39, v39, s1                       // 000000D922D0: D5010027 20064F27
	v_dual_add_f32 v38, v38, v63 :: v_dual_add_f32 v23, v23, v68// 000000D922D8: C9087F26 26168917
	v_mov_b32_dpp v71, v46 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D922E0: 7E8E02FA FF01682E
	v_mov_b32_dpp v74, v45 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D922E8: 7E9402FA FF01682D
	v_cndmask_b32_e64 v45, -v45, v45, s3                       // 000000D922F0: D501002D 200E5B2D
	v_cndmask_b32_e64 v46, -v46, v46, s3                       // 000000D922F8: D501002E 200E5D2E
	v_mov_b32_dpp v76, v30 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D92300: 7E9802FA FF01681E
	v_cndmask_b32_e64 v30, -v30, v30, s3                       // 000000D92308: D501001E 200E3D1E
	v_mov_b32_dpp v78, v29 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D92310: 7E9C02FA FF01681D
	v_cndmask_b32_e64 v29, -v29, v29, s3                       // 000000D92318: D501001D 200E3B1D
	v_add_f32_e32 v31, v31, v59                                // 000000D92320: 063E771F
	v_mov_b32_dpp v77, v28 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D92324: 7E9A02FA FF01681C
	v_cndmask_b32_e64 v28, -v28, v28, s3                       // 000000D9232C: D501001C 200E391C
	v_add_f32_e32 v35, v35, v60                                // 000000D92334: 06467923
	v_mov_b32_dpp v75, v34 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D92338: 7E9602FA FF016822
	v_cndmask_b32_e64 v34, -v34, v34, s3                       // 000000D92340: D5010022 200E4522
	v_dual_add_f32 v44, v44, v69 :: v_dual_add_f32 v43, v43, v70// 000000D92348: C9088B2C 2C2A8D2B
	v_dual_add_f32 v42, v42, v66 :: v_dual_add_f32 v39, v39, v67// 000000D92350: C908852A 2A268727
	v_mov_b32_dpp v63, v38 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D92358: 7E7E02FA FF016826
	v_cndmask_b32_e64 v38, -v38, v38, s3                       // 000000D92360: D5010026 200E4D26
	v_mov_b32_dpp v68, v23 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D92368: 7E8802FA FF016817
	v_cndmask_b32_e64 v23, -v23, v23, s3                       // 000000D92370: D5010017 200E2F17
	v_dual_add_f32 v46, v46, v71 :: v_dual_add_f32 v45, v45, v74// 000000D92378: C9088F2E 2E2C952D
	v_dual_add_f32 v34, v34, v75 :: v_dual_add_f32 v29, v29, v78// 000000D92380: C9089722 221C9D1D
	v_dual_add_f32 v30, v30, v76 :: v_dual_mul_f32 v31, 0x3db504f3, v31// 000000D92388: C906991E 1E1E3EFF 3DB504F3
	v_dual_add_f32 v28, v28, v77 :: v_dual_mul_f32 v35, 0x3db504f3, v35// 000000D92394: C9069B1C 1C2246FF 3DB504F3
	v_dual_mul_f32 v43, 0x3db504f3, v43 :: v_dual_mul_f32 v44, 0x3db504f3, v44// 000000D923A0: C8C656FF 2B2C58FF 3DB504F3
	v_mov_b32_dpp v61, v36 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D923AC: 7E7A02FA FF016424
	v_cndmask_b32_e64 v36, -v36, v36, s2                       // 000000D923B4: D5010024 200A4924
	v_mov_b32_dpp v62, v37 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D923BC: 7E7C02FA FF016425
	v_cndmask_b32_e64 v37, -v37, v37, s2                       // 000000D923C4: D5010025 200A4B25
	v_mov_b32_dpp v66, v42 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D923CC: 7E8402FA FF01642A
	v_cndmask_b32_e64 v42, -v42, v42, s2                       // 000000D923D4: D501002A 200A552A
	v_mov_b32_dpp v67, v39 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D923DC: 7E8602FA FF016427
	v_cndmask_b32_e64 v39, -v39, v39, s2                       // 000000D923E4: D5010027 200A4F27
	v_dual_add_f32 v38, v38, v63 :: v_dual_add_f32 v23, v23, v68// 000000D923EC: C9087F26 26168917
	v_dual_mul_f32 v45, 0x3db504f3, v45 :: v_dual_mul_f32 v46, 0x3db504f3, v46// 000000D923F4: C8C65AFF 2D2E5CFF 3DB504F3
	v_dual_mul_f32 v30, 0x3db504f3, v30 :: v_dual_mul_f32 v29, 0x3db504f3, v29// 000000D92400: C8C63CFF 1E1C3AFF 3DB504F3
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000D9240C: BF870133
	v_dual_mul_f32 v28, 0x3db504f3, v28 :: v_dual_mul_f32 v23, 0x3db504f3, v23// 000000D92410: C8C638FF 1C162EFF 3DB504F3
	v_dual_add_f32 v36, v36, v61 :: v_dual_add_f32 v37, v37, v62// 000000D9241C: C9087B24 24247D25
	v_dual_add_f32 v42, v42, v66 :: v_dual_add_f32 v39, v39, v67// 000000D92424: C908852A 2A268727
	v_mov_b32_dpp v61, v36 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D9242C: 7E7A02FA FF016824
	v_cndmask_b32_e64 v36, -v36, v36, s3                       // 000000D92434: D5010024 200E4924
	s_delay_alu instid0(VALU_DEP_4)                            // 000000D9243C: BF870004
	v_mov_b32_dpp v62, v37 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D92440: 7E7C02FA FF016825
	v_cndmask_b32_e64 v37, -v37, v37, s3                       // 000000D92448: D5010025 200E4B25
	v_mov_b32_dpp v66, v42 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D92450: 7E8402FA FF01682A
	v_cndmask_b32_e64 v42, -v42, v42, s3                       // 000000D92458: D501002A 200E552A
	v_mov_b32_dpp v67, v39 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D92460: 7E8602FA FF016827
	v_cndmask_b32_e64 v39, -v39, v39, s3                       // 000000D92468: D5010027 200E4F27
	v_dual_add_f32 v36, v36, v61 :: v_dual_add_f32 v37, v37, v62// 000000D92470: C9087B24 24247D25
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000D92478: BF8701A2
	v_dual_add_f32 v42, v42, v66 :: v_dual_add_f32 v39, v39, v67// 000000D9247C: C908852A 2A268727
	v_mul_f32_e32 v34, 0x3db504f3, v34                         // 000000D92484: 104444FF 3DB504F3
	v_dual_mul_f32 v36, 0x3db504f3, v36 :: v_dual_mul_f32 v37, 0x3db504f3, v37// 000000D9248C: C8C648FF 24244AFF 3DB504F3
	s_delay_alu instid0(VALU_DEP_3)                            // 000000D92498: BF870003
	v_mul_f32_e32 v39, 0x3db504f3, v39                         // 000000D9249C: 104E4EFF 3DB504F3
	s_waitcnt vmcnt(23)                                        // 000000D924A4: BF895FF7
	v_fma_mix_f32 v7, v7, v31, neg(0) op_sel_hi:[1,0,0]        // 000000D924A8: CC200007 8A023F07
	s_waitcnt vmcnt(22)                                        // 000000D924B0: BF895BF7
	v_fma_mix_f32 v10, v10, v35, neg(0) op_sel_hi:[1,0,0]      // 000000D924B4: CC20000A 8A02470A
	s_waitcnt vmcnt(21)                                        // 000000D924BC: BF8957F7
	v_fma_mix_f32 v8, v8, v44, neg(0) op_sel_hi:[1,0,0]        // 000000D924C0: CC200008 8A025908
	s_waitcnt vmcnt(20)                                        // 000000D924C8: BF8953F7
	v_fma_mix_f32 v9, v9, v43, neg(0) op_sel_hi:[1,0,0]        // 000000D924CC: CC200009 8A025709
	s_waitcnt vmcnt(19)                                        // 000000D924D4: BF894FF7
	v_fma_mix_f32 v11, v11, v46, neg(0) op_sel_hi:[1,0,0]      // 000000D924D8: CC20000B 8A025D0B
	s_waitcnt vmcnt(18)                                        // 000000D924E0: BF894BF7
	v_fma_mix_f32 v12, v12, v45, neg(0) op_sel_hi:[1,0,0]      // 000000D924E4: CC20000C 8A025B0C
	s_waitcnt vmcnt(17)                                        // 000000D924EC: BF8947F7
	v_fma_mix_f32 v19, v19, v34, neg(0) op_sel_hi:[1,0,0]      // 000000D924F0: CC200013 8A024513
	s_waitcnt vmcnt(16)                                        // 000000D924F8: BF8943F7
	v_fma_mix_f32 v20, v20, v30, neg(0) op_sel_hi:[1,0,0]      // 000000D924FC: CC200014 8A023D14
	s_waitcnt vmcnt(15)                                        // 000000D92504: BF893FF7
	v_fma_mix_f32 v26, v26, v28, neg(0) op_sel_hi:[1,0,0]      // 000000D92508: CC20001A 8A02391A
	s_waitcnt vmcnt(14)                                        // 000000D92510: BF893BF7
	v_fma_mix_f32 v27, v27, v29, neg(0) op_sel_hi:[1,0,0]      // 000000D92514: CC20001B 8A023B1B
	v_dual_mul_f32 v28, 0xbfb8aa3b, v9 :: v_dual_mul_f32 v29, 0xbfb8aa3b, v8// 000000D9251C: C8C612FF 1C1C10FF BFB8AA3B
	v_dual_mul_f32 v30, 0xbfb8aa3b, v12 :: v_dual_mul_f32 v31, 0xbfb8aa3b, v11// 000000D92528: C8C618FF 1E1E16FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D92534: BF870193
	v_dual_mul_f32 v43, 0xbfb8aa3b, v27 :: v_dual_mul_f32 v44, 0xbfb8aa3b, v26// 000000D92538: C8C636FF 2B2C34FF BFB8AA3B
	v_exp_f32_e32 v29, v29                                     // 000000D92544: 7E3A4B1D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D92548: BF870112
	v_exp_f32_e32 v30, v30                                     // 000000D9254C: 7E3C4B1E
	v_exp_f32_e32 v31, v31                                     // 000000D92550: 7E3E4B1F
	s_delay_alu instid0(VALU_DEP_1)                            // 000000D92554: BF870001
	v_exp_f32_e32 v43, v43                                     // 000000D92558: 7E564B2B
	v_mul_f32_e32 v38, 0x3db504f3, v38                         // 000000D9255C: 104C4CFF 3DB504F3
	v_dual_mul_f32 v34, 0xbfb8aa3b, v20 :: v_dual_mul_f32 v35, 0xbfb8aa3b, v19// 000000D92564: C8C628FF 222226FF BFB8AA3B
	v_exp_f32_e32 v28, v28                                     // 000000D92570: 7E384B1C
	s_waitcnt vmcnt(12)                                        // 000000D92574: BF8933F7
	v_fma_mix_f32 v22, v22, v37, neg(0) op_sel_hi:[1,0,0]      // 000000D92578: CC200016 8A024B16
	v_dual_mul_f32 v42, 0x3db504f3, v42 :: v_dual_add_f32 v29, 1.0, v29// 000000D92580: C8C854FF 2A1C3AF2 3DB504F3
	s_delay_alu instid0(TRANS32_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 000000D9258C: BF870317
	v_dual_add_f32 v30, 1.0, v30 :: v_dual_add_f32 v31, 1.0, v31// 000000D92590: C9083CF2 1E1E3EF2
	v_add_f32_e32 v37, 1.0, v43                                // 000000D92598: 064A56F2
	v_exp_f32_e32 v35, v35                                     // 000000D9259C: 7E464B23
	s_delay_alu instid0(VALU_DEP_3)                            // 000000D925A0: BF870003
	v_div_scale_f32 v43, null, v29, v29, v8                    // 000000D925A4: D6FC7C2B 04223B1D
	v_exp_f32_e32 v34, v34                                     // 000000D925AC: 7E444B22
	v_div_scale_f32 v59, null, v31, v31, v11                   // 000000D925B0: D6FC7C3B 042E3F1F
	v_add_f32_e32 v28, 1.0, v28                                // 000000D925B8: 063838F2
	v_exp_f32_e32 v44, v44                                     // 000000D925BC: 7E584B2C
	v_rcp_f32_e32 v71, v43                                     // 000000D925C0: 7E8E552B
	v_div_scale_f32 v66, null, v37, v37, v27                   // 000000D925C4: D6FC7C42 046E4B25
	v_rcp_f32_e32 v75, v59                                     // 000000D925CC: 7E96553B
	v_fma_mix_f32 v21, v21, v36, neg(0) op_sel_hi:[1,0,0]      // 000000D925D0: CC200015 8A024915
	v_add_f32_e32 v35, 1.0, v35                                // 000000D925D8: 064646F2
	v_div_scale_f32 v45, null, v28, v28, v9                    // 000000D925DC: D6FC7C2D 0426391C
	v_rcp_f32_e32 v82, v66                                     // 000000D925E4: 7EA45542
	v_div_scale_f32 v60, null, v30, v30, v12                   // 000000D925E8: D6FC7C3C 04323D1E
	v_div_scale_f32 v46, s4, v9, v28, v9                       // 000000D925F0: D6FC042E 04263909
	v_div_scale_f32 v61, null, v35, v35, v19                   // 000000D925F8: D6FC7C3D 044E4723
	v_fma_f32 v85, -v43, v71, 1.0                              // 000000D92600: D6130055 23CA8F2B
	v_add_f32_e32 v34, 1.0, v34                                // 000000D92608: 064444F2
	v_rcp_f32_e32 v74, v45                                     // 000000D9260C: 7E94552D
	v_fma_f32 v87, -v59, v75, 1.0                              // 000000D92610: D6130057 23CA973B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D92618: BF870193
	v_dual_add_f32 v36, 1.0, v44 :: v_dual_fmac_f32 v71, v85, v71// 000000D9261C: C90058F2 24468F55
	v_div_scale_f32 v62, null, v34, v34, v20                   // 000000D92624: D6FC7C3E 04524522
	v_rcp_f32_e32 v77, v61                                     // 000000D9262C: 7E9A553D
	v_rcp_f32_e32 v76, v60                                     // 000000D92630: 7E98553C
	v_fmac_f32_e32 v75, v87, v75                               // 000000D92634: 56969757
	v_div_scale_f32 v63, null, v36, v36, v26                   // 000000D92638: D6FC7C3F 046A4924
	v_rcp_f32_e32 v78, v62                                     // 000000D92640: 7E9C553E
	v_div_scale_f32 v44, vcc_lo, v8, v29, v8                   // 000000D92644: D6FC6A2C 04223B08
	v_fma_f32 v86, -v45, v74, 1.0                              // 000000D9264C: D6130056 23CA952D
	v_fma_f32 v94, -v66, v82, 1.0                              // 000000D92654: D613005E 23CAA542
	v_rcp_f32_e32 v79, v63                                     // 000000D9265C: 7E9E553F
	v_div_scale_f32 v67, s5, v11, v31, v11                     // 000000D92660: D6FC0543 042E3F0B
	v_fma_f32 v91, -v61, v77, 1.0                              // 000000D92668: D613005B 23CA9B3D
	v_fmac_f32_e32 v74, v86, v74                               // 000000D92670: 56949556
	v_dual_fmac_f32 v82, v94, v82 :: v_dual_mul_f32 v85, v44, v71// 000000D92674: C806A55E 52548F2C
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000D9267C: BF870246
	v_fma_f32 v92, -v62, v78, 1.0                              // 000000D92680: D613005C 23CA9D3E
	v_fma_f32 v90, -v60, v76, 1.0                              // 000000D92688: D613005A 23CA993C
	v_div_scale_f32 v69, s7, v19, v35, v19                     // 000000D92690: D6FC0745 044E4713
	v_div_scale_f32 v70, s8, v20, v34, v20                     // 000000D92698: D6FC0846 04524514
	v_dual_fmac_f32 v77, v91, v77 :: v_dual_fmac_f32 v78, v92, v78// 000000D926A0: C8009B5B 4D4E9D5C
	v_dual_mul_f32 v87, v67, v75 :: v_dual_mul_f32 v86, v46, v74// 000000D926A8: C8C69743 5756952E
	v_fma_f32 v95, -v43, v85, v44                              // 000000D926B0: D613005F 24B2AB2B
	v_div_scale_f32 v68, s6, v12, v30, v12                     // 000000D926B8: D6FC0644 04323D0C
	v_fma_f32 v93, -v63, v79, 1.0                              // 000000D926C0: D613005D 23CA9F3F
	v_dual_fmac_f32 v76, v90, v76 :: v_dual_mul_f32 v91, v69, v77// 000000D926C8: C806995A 4C5A9B45
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000D926D0: BF870234
	v_dual_mul_f32 v92, v70, v78 :: v_dual_fmac_f32 v85, v95, v71// 000000D926D4: C8C09D46 5C548F5F
	v_fma_f32 v98, -v45, v86, v46                              // 000000D926DC: D6130062 24BAAD2D
	v_div_scale_f32 v83, s9, v26, v36, v26                     // 000000D926E4: D6FC0953 046A491A
	v_dual_fmac_f32 v79, v93, v79 :: v_dual_mul_f32 v90, v68, v76// 000000D926EC: C8069F5D 4F5A9944
	v_div_scale_f32 v84, s10, v27, v37, v27                    // 000000D926F4: D6FC0A54 046E4B1B
	v_fma_f32 v99, -v59, v87, v67                              // 000000D926FC: D6130063 250EAF3B
	v_fma_f32 v101, -v61, v91, v69                             // 000000D92704: D6130065 2516B73D
	v_fmac_f32_e32 v86, v98, v74                               // 000000D9270C: 56AC9562
	v_fma_f32 v43, -v43, v85, v44                              // 000000D92710: D613002B 24B2AB2B
	v_mul_f32_e32 v93, v83, v79                                // 000000D92718: 10BA9F53
	v_fma_f32 v100, -v60, v90, v68                             // 000000D9271C: D6130064 2512B53C
	v_dual_mul_f32 v94, v84, v82 :: v_dual_fmac_f32 v87, v99, v75// 000000D92724: C8C0A554 5E569763
	v_fma_f32 v102, -v62, v92, v70                             // 000000D9272C: D6130066 251AB93E
	v_fmac_f32_e32 v91, v101, v77                              // 000000D92734: 56B69B65
	v_fma_f32 v44, -v45, v86, v46                              // 000000D92738: D613002C 24BAAD2D
	v_div_fmas_f32 v43, v43, v71, v85                          // 000000D92740: D637002B 05568F2B
	v_fma_f32 v103, -v63, v93, v83                             // 000000D92748: D6130067 254EBB3F
	v_fmac_f32_e32 v90, v100, v76                              // 000000D92750: 56B49964
	s_mov_b32 vcc_lo, s4                                       // 000000D92754: BEEA0004
	v_fma_f32 v45, -v59, v87, v67                              // 000000D92758: D613002D 250EAF3B
	v_div_fmas_f32 v44, v44, v74, v86                          // 000000D92760: D637002C 055A952C
	v_div_fixup_f32 v8, v43, v29, v8                           // 000000D92768: D6270008 04223B2B
	v_dual_fmac_f32 v92, v102, v78 :: v_dual_fmac_f32 v93, v103, v79// 000000D92770: C8009D66 5C5C9F67
	v_fma_f32 v46, -v60, v90, v68                              // 000000D92778: D613002E 2512B53C
	s_mov_b32 vcc_lo, s5                                       // 000000D92780: BEEA0005
	v_fma_f32 v59, -v61, v91, v69                              // 000000D92784: D613003B 2516B73D
	v_div_fmas_f32 v45, v45, v75, v87                          // 000000D9278C: D637002D 055E972D
	s_mov_b32 vcc_lo, s6                                       // 000000D92794: BEEA0006
	v_fma_f32 v106, -v66, v94, v84                             // 000000D92798: D613006A 2552BD42
	v_div_fixup_f32 v9, v44, v28, v9                           // 000000D927A0: D6270009 0426392C
	v_mul_f32_e32 v7, v7, v8                                   // 000000D927A8: 100E1107
	v_fma_f32 v60, -v62, v92, v70                              // 000000D927AC: D613003C 251AB93E
	v_div_fmas_f32 v29, v46, v76, v90                          // 000000D927B4: D637001D 056A992E
	s_mov_b32 vcc_lo, s7                                       // 000000D927BC: BEEA0007
	v_fma_f32 v61, -v63, v93, v83                              // 000000D927C0: D613003D 254EBB3F
	v_div_fmas_f32 v28, v59, v77, v91                          // 000000D927C8: D637001C 056E9B3B
	s_mov_b32 vcc_lo, s8                                       // 000000D927D0: BEEA0008
	v_div_fixup_f32 v11, v45, v31, v11                         // 000000D927D4: D627000B 042E3F2D
	v_fmac_f32_e32 v94, v106, v82                              // 000000D927DC: 56BCA56A
	s_waitcnt vmcnt(10)                                        // 000000D927E0: BF892BF7
	v_fma_mix_f32 v15, v15, v42, neg(0) op_sel_hi:[1,0,0]      // 000000D927E4: CC20000F 8A02550F
	v_mul_f32_e32 v9, v10, v9                                  // 000000D927EC: 1012130A
	v_div_fmas_f32 v10, v60, v78, v92                          // 000000D927F0: D637000A 05729D3C
	s_mov_b32 vcc_lo, s9                                       // 000000D927F8: BEEA0009
	v_div_fixup_f32 v8, v29, v30, v12                          // 000000D927FC: D6270008 04323D1D
	v_mul_f32_e32 v11, v21, v11                                // 000000D92804: 10161715
	v_fma_f32 v12, -v66, v94, v84                              // 000000D92808: D613000C 2552BD42
	v_div_fmas_f32 v21, v61, v79, v93                          // 000000D92810: D6370015 05769F3D
	v_div_fixup_f32 v10, v10, v34, v20                         // 000000D92818: D627000A 0452450A
	s_mov_b32 vcc_lo, s10                                      // 000000D92820: BEEA000A
	s_waitcnt vmcnt(9)                                         // 000000D92824: BF8927F7
	v_fma_mix_f32 v13, v13, v39, neg(0) op_sel_hi:[1,0,0]      // 000000D92828: CC20000D 8A024F0D
	v_div_fmas_f32 v12, v12, v82, v94                          // 000000D92830: D637000C 057AA50C
	s_waitcnt vmcnt(8)                                         // 000000D92838: BF8923F7
	v_fma_mix_f32 v18, v18, v23, neg(0) op_sel_hi:[1,0,0]      // 000000D9283C: CC200012 8A022F12
	v_mul_f32_e32 v10, v15, v10                                // 000000D92844: 1014150F
	v_div_fixup_f32 v15, v21, v36, v26                         // 000000D92848: D627000F 046A4915
	v_mul_f32_e32 v8, v22, v8                                  // 000000D92850: 10101116
	s_waitcnt vmcnt(7)                                         // 000000D92854: BF891FF7
	v_fma_mix_f32 v9, v47, v9, neg(0) op_sel_hi:[1,0,0]        // 000000D92858: CC200009 8A02132F
	v_div_fixup_f32 v12, v12, v37, v27                         // 000000D92860: D627000C 046E4B0C
	v_fma_mix_f32 v14, v14, v38, neg(0) op_sel_hi:[1,0,0]      // 000000D92868: CC20000E 8A024D0E
	v_mul_f32_e32 v13, v13, v15                                // 000000D92870: 101A1F0D
	s_waitcnt vmcnt(6)                                         // 000000D92874: BF891BF7
	v_fma_mix_f32 v8, v50, v8, neg(0) op_sel_hi:[1,0,0]        // 000000D92878: CC200008 8A021132
	v_div_fixup_f32 v19, v28, v35, v19                         // 000000D92880: D6270013 044E471C
	s_waitcnt vmcnt(0)                                         // 000000D92888: BF8903F7
	v_fma_mix_f32 v15, v7, v58, v9 op_sel_hi:[0,1,0]           // 000000D9288C: CC20000F 14267507
	v_mul_f32_e32 v12, v18, v12                                // 000000D92894: 10181912
	v_fma_mix_f32 v10, v51, v10, neg(0) op_sel_hi:[1,0,0]      // 000000D92898: CC20000A 8A021533
	v_fma_mix_f32 v18, v11, v55, v8 op_sel_hi:[0,1,0]          // 000000D928A0: CC200012 14226F0B
	v_fma_mix_f32 v7, v7, v58, -v9 op_sel_hi:[0,1,0]           // 000000D928A8: CC200007 94267507
	v_fma_mix_f32 v8, v11, v55, -v8 op_sel_hi:[0,1,0]          // 000000D928B0: CC200008 94226F0B
	s_mov_b32 s4, exec_lo                                      // 000000D928B8: BE84007E
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000D928BC: BF870123
	v_dual_add_f32 v21, v15, v18 :: v_dual_mul_f32 v14, v14, v19// 000000D928C0: C906250F 150E270E
	v_fma_mix_f32 v12, v52, v12, neg(0) op_sel_hi:[1,0,0]      // 000000D928C8: CC20000C 8A021934
	v_fma_mix_f32 v19, v14, v54, v10 op_sel_hi:[0,1,0]         // 000000D928D0: CC200013 142A6D0E
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000D928D8: BF870122
	v_fma_mix_f32 v20, v13, v53, v12 op_sel_hi:[0,1,0]         // 000000D928DC: CC200014 14326B0D
	v_fma_mix_f32 v11, v13, v53, -v12 op_sel_hi:[0,1,0]        // 000000D928E4: CC20000B 94326B0D
	v_add_f32_e32 v22, v19, v20                                // 000000D928EC: 062C2913
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000D928F0: BF870241
	v_add_f32_e32 v9, v21, v22                                 // 000000D928F4: 06122D15
	v_fma_mix_f32 v10, v14, v54, -v10 op_sel_hi:[0,1,0]        // 000000D928F8: CC20000A 942A6D0E
	v_add_f32_e32 v13, v7, v8                                  // 000000D92900: 061A1107
	v_sub_f32_e32 v7, v7, v8                                   // 000000D92904: 080E1107
	v_mov_b32_dpp v14, v9 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D92908: 7E1C02FA FF016109
	v_cndmask_b32_e64 v9, -v9, v9, s0                          // 000000D92910: D5010009 20021309
	v_add_f32_e32 v8, v10, v11                                 // 000000D92918: 0610170A
	v_sub_f32_e32 v12, v15, v18                                // 000000D9291C: 0818250F
	v_dual_sub_f32 v15, v19, v20 :: v_dual_sub_f32 v10, v10, v11// 000000D92920: C94A2913 0F0A170A
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000D92928: BF870234
	v_add_f32_e32 v9, v9, v14                                  // 000000D9292C: 06121D09
	v_sub_f32_e32 v11, v21, v22                                // 000000D92930: 08162D15
	v_add_f32_e32 v14, v13, v8                                 // 000000D92934: 061C110D
	v_dual_sub_f32 v13, v13, v8 :: v_dual_add_f32 v8, v12, v15 // 000000D92938: C948110D 0D081F0C
	s_delay_alu instid0(VALU_DEP_4)                            // 000000D92940: BF870004
	v_mov_b32_dpp v18, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D92944: 7E2402FA FF016209
	v_cndmask_b32_e64 v9, -v9, v9, s1                          // 000000D9294C: D5010009 20061309
	v_sub_f32_e32 v15, v12, v15                                // 000000D92954: 081E1F0C
	v_mov_b32_dpp v19, v14 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D92958: 7E2602FA FF01610E
	v_cndmask_b32_e64 v14, -v14, v14, s0                       // 000000D92960: D501000E 20021D0E
	v_mov_b32_dpp v20, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D92968: 7E2802FA FF016108
	v_cndmask_b32_e64 v8, -v8, v8, s0                          // 000000D92970: D5010008 20021108
	v_add_f32_e32 v9, v9, v18                                  // 000000D92978: 06122509
	v_cndmask_b32_e64 v22, -v11, v11, s0                       // 000000D9297C: D5010016 2002170B
	v_add_f32_e32 v12, v14, v19                                // 000000D92984: 0618270E
	v_add_f32_e32 v14, v7, v10                                 // 000000D92988: 061C1507
	v_add_f32_e32 v8, v8, v20                                  // 000000D9298C: 06102908
	v_mov_b32_dpp v18, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D92990: 7E2402FA FF016409
	v_cndmask_b32_e64 v9, -v9, v9, s2                          // 000000D92998: D5010009 200A1309
	v_mov_b32_dpp v19, v12 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D929A0: 7E2602FA FF01620C
	v_cndmask_b32_e64 v12, -v12, v12, s1                       // 000000D929A8: D501000C 2006190C
	v_mov_b32_dpp v20, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D929B0: 7E2802FA FF016208
	v_cndmask_b32_e64 v8, -v8, v8, s1                          // 000000D929B8: D5010008 20061108
	v_mov_b32_dpp v21, v14 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D929C0: 7E2A02FA FF01610E
	v_cndmask_b32_e64 v14, -v14, v14, s0                       // 000000D929C8: D501000E 20021D0E
	v_dual_add_f32 v12, v12, v19 :: v_dual_sub_f32 v19, v7, v10// 000000D929D0: C90A270C 0C121507
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D929D8: BF870194
	v_dual_add_f32 v8, v8, v20 :: v_dual_add_f32 v7, v9, v18   // 000000D929DC: C9082908 08062509
	v_add_f32_e32 v9, v14, v21                                 // 000000D929E4: 06122B0E
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D929E8: BF870223
	v_mov_b32_dpp v10, v12 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D929EC: 7E1402FA FF01640C
	v_cndmask_b32_e64 v12, -v12, v12, s2                       // 000000D929F4: D501000C 200A190C
	v_mov_b32_dpp v14, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D929FC: 7E1C02FA FF016408
	v_cndmask_b32_e64 v8, -v8, v8, s2                          // 000000D92A04: D5010008 200A1108
	v_mov_b32_dpp v18, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D92A0C: 7E2402FA FF016209
	v_cndmask_b32_e64 v20, -v9, v9, s1                         // 000000D92A14: D5010014 20061309
	v_mov_b32_dpp v21, v11 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D92A1C: 7E2A02FA FF01610B
	v_add_f32_e32 v9, v12, v10                                 // 000000D92A24: 0612150C
	v_mov_b32_dpp v23, v15 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D92A28: 7E2E02FA FF01610F
	v_cndmask_b32_e64 v15, -v15, v15, s0                       // 000000D92A30: D501000F 20021F0F
	v_add_f32_e32 v11, v8, v14                                 // 000000D92A38: 06161D08
	v_add_f32_e32 v14, v20, v18                                // 000000D92A3C: 061C2514
	v_add_f32_e32 v18, v22, v21                                // 000000D92A40: 06242B16
	v_mov_b32_dpp v22, v13 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D92A44: 7E2C02FA FF01610D
	v_cndmask_b32_e64 v13, -v13, v13, s0                       // 000000D92A4C: D501000D 20021B0D
	v_mov_b32_dpp v26, v19 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D92A54: 7E3402FA FF016113
	v_mov_b32_dpp v20, v14 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D92A5C: 7E2802FA FF01640E
	v_cndmask_b32_e64 v14, -v14, v14, s2                       // 000000D92A64: D501000E 200A1D0E
	v_mov_b32_dpp v21, v18 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D92A6C: 7E2A02FA FF016212
	v_cndmask_b32_e64 v18, -v18, v18, s1                       // 000000D92A74: D5010012 20062512
	v_cndmask_b32_e64 v19, -v19, v19, s0                       // 000000D92A7C: D5010013 20022713
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D92A84: BF870194
	v_dual_add_f32 v22, v13, v22 :: v_dual_add_f32 v13, v14, v20// 000000D92A88: C9082D0D 160C290E
	v_dual_add_f32 v14, v15, v23 :: v_dual_add_f32 v15, v18, v21// 000000D92A90: C9082F0F 0E0E2B12
	v_mov_b32_dpp v8, v7 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D92A98: 7E1002FA FF016807
	s_delay_alu instid0(VALU_DEP_3)                            // 000000D92AA0: BF870003
	v_cndmask_b32_e64 v20, -v22, v22, s1                       // 000000D92AA4: D5010014 20062D16
	v_add_f32_e32 v18, v19, v26                                // 000000D92AAC: 06243513
	v_mov_b32_dpp v19, v22 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D92AB0: 7E2602FA FF016216
	v_mov_b32_dpp v21, v14 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D92AB8: 7E2A02FA FF01620E
	v_cndmask_b32_e64 v14, -v14, v14, s1                       // 000000D92AC0: D501000E 20061D0E
	v_mov_b32_dpp v10, v9 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D92AC8: 7E1402FA FF016809
	v_mov_b32_dpp v12, v11 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D92AD0: 7E1802FA FF01680B
	v_add_f32_e32 v19, v20, v19                                // 000000D92AD8: 06262714
	v_mov_b32_dpp v22, v18 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D92ADC: 7E2C02FA FF016212
	v_cndmask_b32_e64 v18, -v18, v18, s1                       // 000000D92AE4: D5010012 20062512
	v_mov_b32_dpp v20, v15 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D92AEC: 7E2802FA FF01640F
	v_cndmask_b32_e64 v15, -v15, v15, s2                       // 000000D92AF4: D501000F 200A1F0F
	v_add_f32_e32 v14, v14, v21                                // 000000D92AFC: 061C2B0E
	v_mov_b32_dpp v21, v19 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D92B00: 7E2A02FA FF016413
	v_add_f32_e32 v18, v18, v22                                // 000000D92B08: 06242D12
	v_cndmask_b32_e64 v22, -v19, v19, s2                       // 000000D92B0C: D5010016 200A2713
	v_add_f32_e32 v19, v15, v20                                // 000000D92B14: 0626290F
	v_mov_b32_dpp v23, v14 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D92B18: 7E2E02FA FF01640E
	v_cndmask_b32_e64 v26, -v14, v14, s2                       // 000000D92B20: D501001A 200A1D0E
	v_mov_b32_dpp v27, v18 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D92B28: 7E3602FA FF016412
	v_cndmask_b32_e64 v18, -v18, v18, s2                       // 000000D92B30: D5010012 200A2512
	v_dual_add_f32 v20, v22, v21 :: v_dual_add_nc_u32 v15, 10, v6// 000000D92B38: C9202B16 140E0C8A
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D92B40: BF870224
	v_add_f32_e32 v22, v26, v23                                // 000000D92B44: 062C2F1A
	v_mov_b32_dpp v14, v13 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D92B48: 7E1C02FA FF01680D
	v_add_f32_e32 v26, v18, v27                                // 000000D92B50: 06343712
	v_mov_b32_dpp v18, v19 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D92B54: 7E2402FA FF016813
	v_mov_b32_dpp v21, v20 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D92B5C: 7E2A02FA FF016814
	v_mov_b32_dpp v23, v22 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D92B64: 7E2E02FA FF016816
	s_delay_alu instid0(VALU_DEP_4)                            // 000000D92B6C: BF870004
	v_mov_b32_dpp v27, v26 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D92B70: 7E3602FA FF01681A
	.long 0xd4c4007e                                           // 000000D92B78: D4C4007E
	v_cndmask_b32_e32 v1, s23, v15, vcc_lo                     // 000000D92B7C: 02021E17
	s_cbranch_execz 62                                         // 000000D92B80: BFA5003E <_ZN7halogen12_GLOBAL__N_111k_ht_moe_guILi3ELi8ELi1EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_S5_PDF16_+0x697c>
	v_cndmask_b32_e64 v22, -v22, v22, s3                       // 000000D92B84: D5010016 200E2D16
	v_cndmask_b32_e64 v7, -v7, v7, s3                          // 000000D92B8C: D5010007 200E0F07
	v_cndmask_b32_e64 v9, -v9, v9, s3                          // 000000D92B94: D5010009 200E1309
	v_cndmask_b32_e64 v20, -v20, v20, s3                       // 000000D92B9C: D5010014 200E2914
	v_cndmask_b32_e64 v11, -v11, v11, s3                       // 000000D92BA4: D501000B 200E170B
	v_cndmask_b32_e64 v26, -v26, v26, s3                       // 000000D92BAC: D501001A 200E351A
	v_cndmask_b32_e64 v13, -v13, v13, s3                       // 000000D92BB4: D501000D 200E1B0D
	v_cndmask_b32_e64 v19, -v19, v19, s3                       // 000000D92BBC: D5010013 200E2713
	v_dual_add_f32 v22, v22, v23 :: v_dual_add_f32 v7, v7, v8  // 000000D92BC4: C9082F16 16061107
	v_add_f32_e32 v8, v9, v10                                  // 000000D92BCC: 06101509
	v_dual_add_f32 v20, v20, v21 :: v_dual_add_f32 v9, v11, v12// 000000D92BD0: C9082B14 1408190B
	v_mad_i64_i32 v[11:12], null, 0x500, v15, v[0:1]           // 000000D92BD8: D6FF7C0B 04021EFF 00000500
	v_dual_add_f32 v26, v26, v27 :: v_dual_add_f32 v13, v13, v14// 000000D92BE4: C908371A 1A0C1D0D
	s_mov_b32 s5, 0x3db504f3                                   // 000000D92BEC: BE8500FF 3DB504F3
	v_add_f32_e32 v18, v19, v18                                // 000000D92BF4: 06242513
	v_fma_mixlo_f16 v7, v7, s5, 0                              // 000000D92BF8: CC210007 02000B07
	v_fma_mixhi_f16 v7, v8, s5, 0                              // 000000D92C00: CC220007 02000B08
	v_fma_mixlo_f16 v8, v9, s5, 0                              // 000000D92C08: CC210008 02000B09
	v_fma_mixhi_f16 v8, v13, s5, 0                             // 000000D92C10: CC220008 02000B0D
	v_fma_mixlo_f16 v9, v18, s5, 0                             // 000000D92C18: CC210009 02000B12
	v_fma_mixhi_f16 v9, v20, s5, 0                             // 000000D92C20: CC220009 02000B14
	v_fma_mixlo_f16 v10, v22, s5, 0                            // 000000D92C28: CC21000A 02000B16
	v_fma_mixhi_f16 v10, v26, s5, 0                            // 000000D92C30: CC22000A 02000B1A
	s_clause 0x7                                               // 000000D92C38: BF850007
	global_store_b16 v[11:12], v7, off                         // 000000D92C3C: DC660000 007C070B
	global_store_d16_hi_b16 v[11:12], v7, off offset:32        // 000000D92C44: DC960020 007C070B
	global_store_b16 v[11:12], v8, off offset:64               // 000000D92C4C: DC660040 007C080B
	global_store_d16_hi_b16 v[11:12], v8, off offset:96        // 000000D92C54: DC960060 007C080B
	global_store_b16 v[11:12], v9, off offset:128              // 000000D92C5C: DC660080 007C090B
	global_store_d16_hi_b16 v[11:12], v9, off offset:160       // 000000D92C64: DC9600A0 007C090B
	global_store_b16 v[11:12], v10, off offset:192             // 000000D92C6C: DC6600C0 007C0A0B
	global_store_d16_hi_b16 v[11:12], v10, off offset:224      // 000000D92C74: DC9600E0 007C0A0B
	s_or_b32 exec_lo, exec_lo, s4                              // 000000D92C7C: 8C7E047E
	s_clause 0xb                                               // 000000D92C80: BF85000B
	global_load_d16_b16 v7, v[2:3], off offset:1280            // 000000D92C84: DC820500 077C0002
	global_load_d16_b16 v10, v[2:3], off offset:1312           // 000000D92C8C: DC820520 0A7C0002
	global_load_d16_b16 v8, v[2:3], off                        // 000000D92C94: DC820000 087C0002
	global_load_d16_b16 v9, v[2:3], off offset:32              // 000000D92C9C: DC820020 097C0002
	global_load_d16_b16 v11, v[2:3], off offset:64             // 000000D92CA4: DC820040 0B7C0002
	global_load_d16_b16 v12, v[2:3], off offset:96             // 000000D92CAC: DC820060 0C7C0002
	global_load_d16_b16 v18, v[2:3], off offset:128            // 000000D92CB4: DC820080 127C0002
	global_load_d16_b16 v19, v[2:3], off offset:160            // 000000D92CBC: DC8200A0 137C0002
	global_load_d16_b16 v22, v[2:3], off offset:192            // 000000D92CC4: DC8200C0 167C0002
	global_load_d16_b16 v23, v[2:3], off offset:224            // 000000D92CCC: DC8200E0 177C0002
	global_load_d16_b16 v20, v[2:3], off offset:1344           // 000000D92CD4: DC820540 147C0002
	global_load_d16_b16 v21, v[2:3], off offset:1376           // 000000D92CDC: DC820560 157C0002
	v_add_f32_e32 v42, v40, v32                                // 000000D92CE4: 06544128
	v_sub_f32_e32 v32, v40, v32                                // 000000D92CE8: 08404128
	v_add_f32_e32 v40, v24, v16                                // 000000D92CEC: 06502118
	v_sub_f32_e32 v31, v104, v96                               // 000000D92CF0: 083EC168
	v_sub_f32_e32 v39, v56, v48                                // 000000D92CF4: 084E6138
	v_sub_f32_e32 v24, v24, v16                                // 000000D92CF8: 08302118
	s_delay_alu instid0(VALU_DEP_4)                            // 000000D92CFC: BF870004
	v_add_f32_e32 v53, v42, v40                                // 000000D92D00: 066A512A
	v_sub_f32_e32 v37, v72, v64                                // 000000D92D04: 084A8148
	v_add_f32_e32 v34, v88, v80                                // 000000D92D08: 0644A158
	v_sub_f32_e32 v35, v88, v80                                // 000000D92D0C: 0846A158
	v_sub_f32_e32 v29, v120, v112                              // 000000D92D10: 083AE178
	v_add_f32_e32 v30, v104, v96                               // 000000D92D14: 063CC168
	v_sub_f32_e32 v27, v136, v128                              // 000000D92D18: 08370188
	v_add_f32_e32 v26, v136, v128                              // 000000D92D1C: 06350188
	v_add_f32_e32 v28, v120, v112                              // 000000D92D20: 0638E178
	v_add_f32_e32 v36, v72, v64                                // 000000D92D24: 06488148
	s_delay_alu instid0(VALU_DEP_2)                            // 000000D92D28: BF870002
	v_add_f32_e32 v52, v26, v28                                // 000000D92D2C: 0668391A
	v_sub_f32_e32 v26, v26, v28                                // 000000D92D30: 0834391A
	v_add_f32_e32 v28, v27, v29                                // 000000D92D34: 06383B1B
	v_sub_f32_e32 v27, v27, v29                                // 000000D92D38: 08363B1B
	v_add_f32_e32 v29, v30, v34                                // 000000D92D3C: 063A451E
	v_sub_f32_e32 v30, v30, v34                                // 000000D92D40: 083C451E
	v_add_f32_e32 v34, v31, v35                                // 000000D92D44: 0644471F
	v_dual_sub_f32 v31, v31, v35 :: v_dual_add_f32 v38, v56, v48// 000000D92D48: C948471F 1F266138
	s_clause 0x3                                               // 000000D92D50: BF850003
	global_load_d16_b16 v14, v[2:3], off offset:1408           // 000000D92D54: DC820580 0E7C0002
	global_load_d16_b16 v15, v[2:3], off offset:1440           // 000000D92D5C: DC8205A0 0F7C0002
	global_load_d16_b16 v13, v[2:3], off offset:1472           // 000000D92D64: DC8205C0 0D7C0002
	global_load_d16_b16 v16, v[2:3], off offset:1504           // 000000D92D6C: DC8205E0 107C0002
	s_clause 0x7                                               // 000000D92D74: BF850007
	global_load_d16_b16 v43, v[4:5], off offset:32             // 000000D92D78: DC820020 2B7C0004
	global_load_d16_b16 v44, v[4:5], off offset:96             // 000000D92D80: DC820060 2C7C0004
	global_load_d16_b16 v45, v[4:5], off offset:160            // 000000D92D88: DC8200A0 2D7C0004
	global_load_d16_b16 v46, v[4:5], off offset:224            // 000000D92D90: DC8200E0 2E7C0004
	global_load_d16_b16 v47, v[4:5], off offset:192            // 000000D92D98: DC8200C0 2F7C0004
	global_load_d16_b16 v48, v[4:5], off offset:128            // 000000D92DA0: DC820080 307C0004
	global_load_d16_b16 v50, v[4:5], off offset:64             // 000000D92DA8: DC820040 327C0004
	global_load_d16_b16 v51, v[4:5], off                       // 000000D92DB0: DC820000 337C0004
	v_dual_add_f32 v55, v26, v30 :: v_dual_add_f32 v54, v27, v31// 000000D92DB8: C9083D1A 37363F1B
	v_sub_f32_e32 v27, v27, v31                                // 000000D92DC0: 08363F1B
	v_add_f32_e32 v35, v36, v38                                // 000000D92DC4: 06464D24
	v_sub_f32_e32 v36, v36, v38                                // 000000D92DC8: 08484D24
	v_add_f32_e32 v38, v37, v39                                // 000000D92DCC: 064C4F25
	v_sub_f32_e32 v37, v37, v39                                // 000000D92DD0: 084A4F25
	v_mov_b32_dpp v69, v27 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D92DD4: 7E8A02FA FF01611B
	v_cndmask_b32_e64 v27, -v27, v27, s0                       // 000000D92DDC: D501001B 2002371B
	v_add_f32_e32 v39, v32, v24                                // 000000D92DE4: 064E3120
	v_sub_f32_e32 v40, v42, v40                                // 000000D92DE8: 0850512A
	v_sub_f32_e32 v24, v32, v24                                // 000000D92DEC: 08303120
	v_mov_b32_dpp v63, v55 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D92DF0: 7E7E02FA FF016137
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D92DF8: BF870214
	v_dual_add_f32 v27, v27, v69 :: v_dual_add_f32 v42, v38, v39// 000000D92DFC: C9088B1B 1B2A4F26
	v_dual_sub_f32 v38, v38, v39 :: v_dual_add_f32 v39, v36, v40// 000000D92E04: C9484F26 26265124
	v_sub_f32_e32 v36, v36, v40                                // 000000D92E0C: 08485124
	v_add_f32_e32 v40, v37, v24                                // 000000D92E10: 06503125
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000D92E14: BF8701C4
	v_mov_b32_dpp v69, v27 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D92E18: 7E8A02FA FF01621B
	v_cndmask_b32_e64 v27, -v27, v27, s1                       // 000000D92E20: D501001B 2006371B
	v_dual_sub_f32 v24, v37, v24 :: v_dual_add_f32 v37, v28, v34// 000000D92E28: C9483125 1824451C
	v_sub_f32_e32 v26, v26, v30                                // 000000D92E30: 08343D1A
	v_dual_sub_f32 v28, v28, v34 :: v_dual_add_f32 v27, v27, v69// 000000D92E34: C948451C 1C1A8B1B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D92E3C: BF870213
	v_mov_b32_dpp v60, v24 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D92E40: 7E7802FA FF016118
	v_mov_b32_dpp v62, v37 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D92E48: 7E7C02FA FF016125
	v_cndmask_b32_e64 v37, -v37, v37, s0                       // 000000D92E50: D5010025 20024B25
	v_cndmask_b32_e64 v24, -v24, v24, s0                       // 000000D92E58: D5010018 20023118
	v_mov_b32_dpp v68, v26 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D92E60: 7E8802FA FF01611A
	v_cndmask_b32_e64 v26, -v26, v26, s0                       // 000000D92E68: D501001A 2002351A
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000D92E70: BF870244
	v_dual_add_f32 v32, v35, v53 :: v_dual_add_f32 v37, v37, v62// 000000D92E74: C9086B23 20247D25
	v_sub_f32_e32 v35, v35, v53                                // 000000D92E7C: 08466B23
	v_add_f32_e32 v53, v52, v29                                // 000000D92E80: 066A3B34
	v_sub_f32_e32 v29, v52, v29                                // 000000D92E84: 083A3B34
	v_mov_b32_dpp v30, v32 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D92E88: 7E3C02FA FF016120
	v_mov_b32_dpp v62, v37 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D92E90: 7E7C02FA FF016225
	v_cndmask_b32_e64 v37, -v37, v37, s1                       // 000000D92E98: D5010025 20064B25
	v_add_f32_e32 v24, v24, v60                                // 000000D92EA0: 06307918
	v_cndmask_b32_e64 v31, -v32, v32, s0                       // 000000D92EA4: D501001F 20024120
	v_mov_b32_dpp v32, v42 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D92EAC: 7E4002FA FF01612A
	v_cndmask_b32_e64 v34, -v42, v42, s0                       // 000000D92EB4: D5010022 2002552A
	v_add_f32_e32 v37, v37, v62                                // 000000D92EBC: 064A7D25
	v_mov_b32_dpp v42, v39 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D92EC0: 7E5402FA FF016127
	v_cndmask_b32_e64 v39, -v39, v39, s0                       // 000000D92EC8: D5010027 20024F27
	v_mov_b32_dpp v61, v53 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D92ED0: 7E7A02FA FF016135
	v_cndmask_b32_e64 v53, -v53, v53, s0                       // 000000D92ED8: D5010035 20026B35
	v_mov_b32_dpp v62, v37 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D92EE0: 7E7C02FA FF016425
	v_cndmask_b32_e64 v37, -v37, v37, s2                       // 000000D92EE8: D5010025 200A4B25
	v_add_f32_e32 v26, v26, v68                                // 000000D92EF0: 0634891A
	v_mov_b32_dpp v60, v24 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D92EF4: 7E7802FA FF016218
	v_cndmask_b32_e64 v24, -v24, v24, s1                       // 000000D92EFC: D5010018 20063118
	v_mov_b32_dpp v66, v29 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D92F04: 7E8402FA FF01611D
	v_add_f32_e32 v37, v37, v62                                // 000000D92F0C: 064A7D25
	v_cndmask_b32_e64 v29, -v29, v29, s0                       // 000000D92F10: D501001D 20023B1D
	v_dual_add_f32 v30, v31, v30 :: v_dual_add_f32 v31, v34, v32// 000000D92F18: C9083D1F 1E1E4122
	v_mov_b32_dpp v64, v54 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D92F20: 7E8002FA FF016136
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 000000D92F28: BF870254
	v_mov_b32_dpp v62, v37 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D92F2C: 7E7C02FA FF016825
	v_cndmask_b32_e64 v37, -v37, v37, s3                       // 000000D92F34: D5010025 200E4B25
	v_dual_add_f32 v24, v24, v60 :: v_dual_add_f32 v29, v29, v66// 000000D92F3C: C9087918 181C851D
	v_cndmask_b32_e64 v54, -v54, v54, s0                       // 000000D92F44: D5010036 20026D36
	v_cndmask_b32_e64 v55, -v55, v55, s0                       // 000000D92F4C: D5010037 20026F37
	v_add_f32_e32 v37, v37, v62                                // 000000D92F54: 064A7D25
	v_dual_add_f32 v32, v39, v42 :: v_dual_add_f32 v39, v53, v61// 000000D92F58: C9085527 20267B35
	v_mov_b32_dpp v53, v31 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D92F60: 7E6A02FA FF01621F
	v_cndmask_b32_e64 v31, -v31, v31, s1                       // 000000D92F68: D501001F 20063F1F
	v_mov_b32_dpp v66, v29 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D92F70: 7E8402FA FF01621D
	v_cndmask_b32_e64 v29, -v29, v29, s1                       // 000000D92F78: D501001D 20063B1D
	v_mov_b32_dpp v61, v39 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D92F80: 7E7A02FA FF016227
	v_cndmask_b32_e64 v39, -v39, v39, s1                       // 000000D92F88: D5010027 20064F27
	v_add_f32_e32 v31, v31, v53                                // 000000D92F90: 063E6B1F
	v_mov_b32_dpp v69, v27 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D92F94: 7E8A02FA FF01641B
	v_add_f32_e32 v29, v29, v66                                // 000000D92F9C: 063A851D
	v_cndmask_b32_e64 v27, -v27, v27, s2                       // 000000D92FA0: D501001B 200A371B
	v_add_f32_e32 v39, v39, v61                                // 000000D92FA8: 064E7B27
	v_mov_b32_dpp v52, v40 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D92FAC: 7E6802FA FF016128
	v_cndmask_b32_e64 v40, -v40, v40, s0                       // 000000D92FB4: D5010028 20025128
	v_mov_b32_dpp v53, v31 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D92FBC: 7E6A02FA FF01641F
	v_cndmask_b32_e64 v31, -v31, v31, s2                       // 000000D92FC4: D501001F 200A3F1F
	v_mov_b32_dpp v66, v29 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D92FCC: 7E8402FA FF01641D
	v_cndmask_b32_e64 v29, -v29, v29, s2                       // 000000D92FD4: D501001D 200A3B1D
	v_add_f32_e32 v34, v40, v52                                // 000000D92FDC: 06446928
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D92FE0: BF870194
	v_dual_add_f32 v40, v54, v64 :: v_dual_add_f32 v31, v31, v53// 000000D92FE4: C9088136 281E6B1F
	v_dual_add_f32 v42, v55, v63 :: v_dual_add_f32 v29, v29, v66// 000000D92FEC: C9087F37 2A1C851D
	v_mul_f32_e32 v37, 0x3db504f3, v37                         // 000000D92FF4: 104A4AFF 3DB504F3
	v_mov_b32_dpp v54, v32 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D92FFC: 7E6C02FA FF016220
	v_cndmask_b32_e64 v32, -v32, v32, s1                       // 000000D93004: D5010020 20064120
	v_mov_b32_dpp v56, v35 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D9300C: 7E7002FA FF016123
	v_cndmask_b32_e64 v35, -v35, v35, s0                       // 000000D93014: D5010023 20024723
	v_mov_b32_dpp v63, v42 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D9301C: 7E7E02FA FF01622A
	v_cndmask_b32_e64 v42, -v42, v42, s1                       // 000000D93024: D501002A 2006552A
	v_dual_add_f32 v32, v32, v54 :: v_dual_add_f32 v27, v27, v69// 000000D9302C: C9086D20 201A8B1B
	v_mov_b32_dpp v58, v38 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D93034: 7E7402FA FF016126
	v_cndmask_b32_e64 v38, -v38, v38, s0                       // 000000D9303C: D5010026 20024D26
	v_add_f32_e32 v35, v35, v56                                // 000000D93044: 06467123
	v_mov_b32_dpp v59, v36 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D93048: 7E7602FA FF016124
	v_mov_b32_dpp v69, v27 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D93050: 7E8A02FA FF01681B
	v_cndmask_b32_e64 v27, -v27, v27, s3                       // 000000D93058: D501001B 200E371B
	v_add_f32_e32 v42, v42, v63                                // 000000D93060: 06547F2A
	v_cndmask_b32_e64 v36, -v36, v36, s0                       // 000000D93064: D5010024 20024924
	v_add_f32_e32 v38, v38, v58                                // 000000D9306C: 064C7526
	v_mov_b32_dpp v56, v35 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D93070: 7E7002FA FF016223
	v_cndmask_b32_e64 v35, -v35, v35, s1                       // 000000D93078: D5010023 20064723
	v_add_f32_e32 v27, v27, v69                                // 000000D93080: 06368B1B
	v_mov_b32_dpp v63, v42 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D93084: 7E7E02FA FF01642A
	v_cndmask_b32_e64 v42, -v42, v42, s2                       // 000000D9308C: D501002A 200A552A
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000D93094: BF870234
	v_dual_add_f32 v36, v36, v59 :: v_dual_add_f32 v35, v35, v56// 000000D93098: C9087724 24227123
	v_mov_b32_dpp v67, v28 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D930A0: 7E8602FA FF01611C
	v_cndmask_b32_e64 v28, -v28, v28, s0                       // 000000D930A8: D501001C 2002391C
	v_add_f32_e32 v42, v42, v63                                // 000000D930B0: 06547F2A
	v_mov_b32_dpp v55, v34 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D930B4: 7E6E02FA FF016222
	v_mov_b32_dpp v56, v35 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D930BC: 7E7002FA FF016423
	v_cndmask_b32_e64 v35, -v35, v35, s2                       // 000000D930C4: D5010023 200A4723
	v_add_f32_e32 v28, v28, v67                                // 000000D930CC: 0638871C
	v_mov_b32_dpp v63, v42 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D930D0: 7E7E02FA FF01682A
	v_cndmask_b32_e64 v42, -v42, v42, s3                       // 000000D930D8: D501002A 200E552A
	v_cndmask_b32_e64 v34, -v34, v34, s1                       // 000000D930E0: D5010022 20064522
	v_mov_b32_dpp v58, v38 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D930E8: 7E7402FA FF016226
	v_cndmask_b32_e64 v38, -v38, v38, s1                       // 000000D930F0: D5010026 20064D26
	v_mov_b32_dpp v64, v40 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D930F8: 7E8002FA FF016228
	v_cndmask_b32_e64 v40, -v40, v40, s1                       // 000000D93100: D5010028 20065128
	v_add_f32_e32 v35, v35, v56                                // 000000D93108: 06467123
	v_mov_b32_dpp v53, v31 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D9310C: 7E6A02FA FF01681F
	v_cndmask_b32_e64 v31, -v31, v31, s3                       // 000000D93114: D501001F 200E3F1F
	v_mov_b32_dpp v66, v29 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D9311C: 7E8402FA FF01681D
	v_cndmask_b32_e64 v29, -v29, v29, s3                       // 000000D93124: D501001D 200E3B1D
	v_add_f32_e32 v42, v42, v63                                // 000000D9312C: 06547F2A
	v_mov_b32_dpp v67, v28 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D93130: 7E8602FA FF01621C
	v_cndmask_b32_e64 v28, -v28, v28, s1                       // 000000D93138: D501001C 2006391C
	v_dual_add_f32 v34, v34, v55 :: v_dual_add_f32 v31, v31, v53// 000000D93140: C9086F22 221E6B1F
	v_dual_add_f32 v40, v40, v64 :: v_dual_add_f32 v29, v29, v66// 000000D93148: C9088128 281C851D
	v_mov_b32_dpp v56, v35 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D93150: 7E7002FA FF016823
	v_cndmask_b32_e64 v35, -v35, v35, s3                       // 000000D93158: D5010023 200E4723
	v_add_f32_e32 v38, v38, v58                                // 000000D93160: 064C7526
	v_mul_f32_e32 v42, 0x3db504f3, v42                         // 000000D93164: 105454FF 3DB504F3
	v_dual_add_f32 v28, v28, v67 :: v_dual_mul_f32 v29, 0x3db504f3, v29// 000000D9316C: C906871C 1C1C3AFF 3DB504F3
	v_mov_b32_dpp v61, v39 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D93178: 7E7A02FA FF016427
	v_cndmask_b32_e64 v39, -v39, v39, s2                       // 000000D93180: D5010027 200A4F27
	v_add_f32_e32 v35, v35, v56                                // 000000D93188: 06467123
	v_mov_b32_dpp v58, v38 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D9318C: 7E7402FA FF016426
	v_cndmask_b32_e64 v38, -v38, v38, s2                       // 000000D93194: D5010026 200A4D26
	v_mul_f32_e32 v31, 0x3db504f3, v31                         // 000000D9319C: 103E3EFF 3DB504F3
	v_mov_b32_dpp v52, v30 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D931A4: 7E6802FA FF01621E
	v_cndmask_b32_e64 v30, -v30, v30, s1                       // 000000D931AC: D501001E 20063D1E
	v_mov_b32_dpp v59, v36 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D931B4: 7E7602FA FF016224
	v_cndmask_b32_e64 v36, -v36, v36, s1                       // 000000D931BC: D5010024 20064924
	v_add_f32_e32 v39, v39, v61                                // 000000D931C4: 064E7B27
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000D931C8: BF870234
	v_dual_mul_f32 v27, 0x3db504f3, v27 :: v_dual_add_f32 v30, v30, v52// 000000D931CC: C8C836FF 1B1E691E 3DB504F3
	v_mov_b32_dpp v67, v28 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D931D8: 7E8602FA FF01641C
	v_cndmask_b32_e64 v28, -v28, v28, s2                       // 000000D931E0: D501001C 200A391C
	v_mov_b32_dpp v61, v39 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D931E8: 7E7A02FA FF016827
	v_cndmask_b32_e64 v39, -v39, v39, s3                       // 000000D931F0: D5010027 200E4F27
	v_add_f32_e32 v36, v36, v59                                // 000000D931F8: 06487724
	v_mov_b32_dpp v52, v30 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D931FC: 7E6802FA FF01641E
	v_cndmask_b32_e64 v30, -v30, v30, s2                       // 000000D93204: D501001E 200A3D1E
	v_mov_b32_dpp v68, v26 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D9320C: 7E8802FA FF01621A
	v_add_f32_e32 v39, v39, v61                                // 000000D93214: 064E7B27
	v_mov_b32_dpp v59, v36 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D93218: 7E7602FA FF016424
	v_cndmask_b32_e64 v36, -v36, v36, s2                       // 000000D93220: D5010024 200A4924
	v_add_f32_e32 v30, v30, v52                                // 000000D93228: 063C691E
	v_cndmask_b32_e64 v26, -v26, v26, s1                       // 000000D9322C: D501001A 2006351A
	v_mov_b32_dpp v55, v34 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D93234: 7E6E02FA FF016422
	v_cndmask_b32_e64 v34, -v34, v34, s2                       // 000000D9323C: D5010022 200A4522
	v_mul_f32_e32 v39, 0x3db504f3, v39                         // 000000D93244: 104E4EFF 3DB504F3
	v_mov_b32_dpp v52, v30 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D9324C: 7E6802FA FF01681E
	v_cndmask_b32_e64 v30, -v30, v30, s3                       // 000000D93254: D501001E 200E3D1E
	v_add_f32_e32 v26, v26, v68                                // 000000D9325C: 0634891A
	v_mov_b32_dpp v60, v24 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D93260: 7E7802FA FF016418
	v_cndmask_b32_e64 v24, -v24, v24, s2                       // 000000D93268: D5010018 200A3118
	v_mov_b32_dpp v54, v32 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D93270: 7E6C02FA FF016420
	v_cndmask_b32_e64 v32, -v32, v32, s2                       // 000000D93278: D5010020 200A4120
	v_mov_b32_dpp v68, v26 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D93280: 7E8802FA FF01641A
	v_cndmask_b32_e64 v26, -v26, v26, s2                       // 000000D93288: D501001A 200A351A
	v_mul_f32_e32 v35, 0x3db504f3, v35                         // 000000D93290: 104646FF 3DB504F3
	v_mov_b32_dpp v64, v40 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D93298: 7E8002FA FF016428
	v_add_f32_e32 v32, v32, v54                                // 000000D932A0: 06406D20
	v_cndmask_b32_e64 v40, -v40, v40, s2                       // 000000D932A4: D5010028 200A5128
	s_delay_alu instid0(VALU_DEP_2)                            // 000000D932AC: BF870002
	v_mov_b32_dpp v54, v32 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D932B0: 7E6C02FA FF016820
	v_cndmask_b32_e64 v32, -v32, v32, s3                       // 000000D932B8: D5010020 200E4120
	s_waitcnt vmcnt(22)                                        // 000000D932C0: BF895BF7
	v_fma_mix_f32 v10, v10, v31, neg(0) op_sel_hi:[1,0,0]      // 000000D932C4: CC20000A 8A023F0A
	s_waitcnt vmcnt(21)                                        // 000000D932CC: BF8957F7
	v_fma_mix_f32 v8, v8, v39, neg(0) op_sel_hi:[1,0,0]        // 000000D932D0: CC200008 8A024F08
	v_add_f32_e32 v34, v34, v55                                // 000000D932D8: 06446F22
	s_waitcnt vmcnt(19)                                        // 000000D932DC: BF894FF7
	v_fma_mix_f32 v11, v11, v42, neg(0) op_sel_hi:[1,0,0]      // 000000D932E0: CC20000B 8A02550B
	v_add_f32_e32 v38, v38, v58                                // 000000D932E8: 064C7526
	s_waitcnt vmcnt(17)                                        // 000000D932EC: BF8947F7
	v_fma_mix_f32 v18, v18, v29, neg(0) op_sel_hi:[1,0,0]      // 000000D932F0: CC200012 8A023B12
	v_add_f32_e32 v36, v36, v59                                // 000000D932F8: 06487724
	v_fma_mix_f32 v9, v9, v37, neg(0) op_sel_hi:[1,0,0]        // 000000D932FC: CC200009 8A024B09
	v_mul_f32_e32 v29, 0xbfb8aa3b, v11                         // 000000D93304: 103A16FF BFB8AA3B
	s_waitcnt vmcnt(14)                                        // 000000D9330C: BF893BF7
	v_fma_mix_f32 v23, v23, v27, neg(0) op_sel_hi:[1,0,0]      // 000000D93310: CC200017 8A023717
	v_mul_f32_e32 v31, 0xbfb8aa3b, v18                         // 000000D93318: 103E24FF BFB8AA3B
	v_mov_b32_dpp v59, v36 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D93320: 7E7602FA FF016824
	v_cndmask_b32_e64 v36, -v36, v36, s3                       // 000000D93328: D5010024 200E4924
	v_exp_f32_e32 v29, v29                                     // 000000D93330: 7E3A4B1D
	v_mul_f32_e32 v27, 0xbfb8aa3b, v8                          // 000000D93334: 103610FF BFB8AA3B
	v_exp_f32_e32 v31, v31                                     // 000000D9333C: 7E3E4B1F
	v_add_f32_e32 v30, v30, v52                                // 000000D93340: 063C691E
	v_mov_b32_dpp v55, v34 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D93344: 7E6E02FA FF016822
	v_cndmask_b32_e64 v34, -v34, v34, s3                       // 000000D9334C: D5010022 200E4522
	v_dual_add_f32 v24, v24, v60 :: v_dual_mul_f32 v37, 0xbfb8aa3b, v23// 000000D93354: C9067918 18242EFF BFB8AA3B
	v_exp_f32_e32 v27, v27                                     // 000000D93360: 7E364B1B
	s_delay_alu instid0(TRANS32_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D93364: BF870197
	v_dual_add_f32 v26, v26, v68 :: v_dual_add_f32 v29, 1.0, v29// 000000D93368: C908891A 1A1C3AF2
	v_add_f32_e32 v34, v34, v55                                // 000000D93370: 06446F22
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000D93374: BF8701A6
	v_dual_add_f32 v31, 1.0, v31 :: v_dual_mul_f32 v30, 0x3db504f3, v30// 000000D93378: C9063EF2 1F1E3CFF 3DB504F3
	v_exp_f32_e32 v37, v37                                     // 000000D93384: 7E4A4B25
	v_div_scale_f32 v52, null, v29, v29, v11                   // 000000D93388: D6FC7C34 042E3B1D
	v_mov_b32_dpp v58, v38 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D93390: 7E7402FA FF016826
	s_delay_alu instid0(VALU_DEP_3)                            // 000000D93398: BF870003
	v_div_scale_f32 v61, s7, v18, v31, v18                     // 000000D9339C: D6FC073D 044A3F12
	v_add_f32_e32 v36, v36, v59                                // 000000D933A4: 06487724
	v_div_scale_f32 v59, s5, v11, v29, v11                     // 000000D933A8: D6FC053B 042E3B0B
	v_rcp_f32_e32 v66, v52                                     // 000000D933B0: 7E845534
	v_fma_mix_f32 v7, v7, v30, neg(0) op_sel_hi:[1,0,0]        // 000000D933B4: CC200007 8A023D07
	v_add_f32_e32 v27, 1.0, v27                                // 000000D933BC: 063636F2
	v_cndmask_b32_e64 v38, -v38, v38, s3                       // 000000D933C0: D5010026 200E4D26
	v_mov_b32_dpp v68, v26 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D933C8: 7E8802FA FF01681A
	v_cndmask_b32_e64 v26, -v26, v26, s3                       // 000000D933D0: D501001A 200E351A
	v_mov_b32_dpp v60, v24 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D933D8: 7E7802FA FF016818
	v_cndmask_b32_e64 v24, -v24, v24, s3                       // 000000D933E0: D5010018 200E3118
	v_add_f32_e32 v38, v38, v58                                // 000000D933E8: 064C7526
	s_waitcnt vmcnt(11)                                        // 000000D933EC: BF892FF7
	v_fma_mix_f32 v14, v14, v35, neg(0) op_sel_hi:[1,0,0]      // 000000D933F0: CC20000E 8A02470E
	v_fma_f32 v77, -v52, v66, 1.0                              // 000000D933F8: D613004D 23CA8534
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D93400: BF870091
	v_fmac_f32_e32 v66, v77, v66                               // 000000D93404: 5684854D
	v_dual_add_f32 v28, v28, v67 :: v_dual_mul_f32 v77, v59, v66// 000000D93408: C906871C 1C4C853B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000D93410: BF8701A1
	v_mov_b32_dpp v67, v28 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D93414: 7E8602FA FF01681C
	v_cndmask_b32_e64 v28, -v28, v28, s3                       // 000000D9341C: D501001C 200E391C
	v_fma_f32 v86, -v52, v77, v59                              // 000000D93424: D6130056 24EE9B34
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D9342C: BF870091
	v_dual_add_f32 v28, v28, v67 :: v_dual_fmac_f32 v77, v86, v66// 000000D93430: C900871C 1C4C8556
	v_mul_f32_e32 v28, 0x3db504f3, v28                         // 000000D93438: 103838FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D93440: BF870091
	v_fma_mix_f32 v19, v19, v28, neg(0) op_sel_hi:[1,0,0]      // 000000D93444: CC200013 8A023913
	v_mul_f32_e32 v30, 0xbfb8aa3b, v19                         // 000000D9344C: 103C26FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000D93454: BF870291
	v_exp_f32_e32 v30, v30                                     // 000000D93458: 7E3C4B1E
	v_add_f32_e32 v30, 1.0, v30                                // 000000D9345C: 063C3CF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000D93460: BF870121
	v_div_scale_f32 v55, null, v30, v30, v19                   // 000000D93464: D6FC7C37 044E3D1E
	v_div_scale_f32 v62, s8, v19, v30, v19                     // 000000D9346C: D6FC083E 044E3D13
	v_rcp_f32_e32 v69, v55                                     // 000000D93474: 7E8A5537
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D93478: BF870095
	v_fma_f32 v80, -v55, v69, 1.0                              // 000000D9347C: D6130050 23CA8B37
	v_dual_fmac_f32 v69, v80, v69 :: v_dual_mul_f32 v34, 0x3db504f3, v34// 000000D93484: C8068B50 452244FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D93490: BF870111
	v_mul_f32_e32 v80, v62, v69                                // 000000D93494: 10A08B3E
	v_fma_mix_f32 v21, v21, v34, neg(0) op_sel_hi:[1,0,0]      // 000000D93498: CC200015 8A024515
	v_add_f32_e32 v34, 1.0, v37                                // 000000D934A0: 06444AF2
	v_div_scale_f32 v37, null, v27, v27, v8                    // 000000D934A4: D6FC7C25 0422371B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D934AC: BF870194
	v_fma_f32 v90, -v55, v80, v62                              // 000000D934B0: D613005A 24FAA137
	v_div_scale_f32 v58, null, v34, v34, v23                   // 000000D934B8: D6FC7C3A 045E4522
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000D934C0: BF8701A3
	v_rcp_f32_e32 v63, v37                                     // 000000D934C4: 7E7E5525
	v_div_scale_f32 v74, s10, v23, v34, v23                    // 000000D934C8: D6FC0A4A 045E4517
	v_fmac_f32_e32 v80, v90, v69                               // 000000D934D0: 56A08B5A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 000000D934D4: BF870313
	v_rcp_f32_e32 v71, v58                                     // 000000D934D8: 7E8E553A
	v_fma_f32 v75, -v37, v63, 1.0                              // 000000D934DC: D613004B 23CA7F25
	v_add_f32_e32 v32, v32, v54                                // 000000D934E4: 06406D20
	v_div_scale_f32 v54, null, v31, v31, v18                   // 000000D934E8: D6FC7C36 044A3F1F
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D934F0: BF870215
	v_fma_f32 v83, -v58, v71, 1.0                              // 000000D934F4: D6130053 23CA8F3A
	v_dual_fmac_f32 v63, v75, v63 :: v_dual_add_f32 v26, v26, v68// 000000D934FC: C8087F4B 3F1A891A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D93504: BF870113
	v_rcp_f32_e32 v68, v54                                     // 000000D93508: 7E885536
	v_dual_fmac_f32 v71, v83, v71 :: v_dual_mul_f32 v38, 0x3db504f3, v38// 000000D9350C: C8068F53 47264CFF 3DB504F3
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000D93518: BF870121
	v_dual_mul_f32 v26, 0x3db504f3, v26 :: v_dual_mul_f32 v83, v74, v71// 000000D9351C: C8C634FF 1A528F4A 3DB504F3
	s_waitcnt vmcnt(10)                                        // 000000D93528: BF892BF7
	v_fma_mix_f32 v15, v15, v38, neg(0) op_sel_hi:[1,0,0]      // 000000D9352C: CC20000F 8A024D0F
	s_delay_alu instid0(VALU_DEP_2)                            // 000000D93534: BF870002
	v_fma_mix_f32 v22, v22, v26, neg(0) op_sel_hi:[1,0,0]      // 000000D93538: CC200016 8A023516
	v_add_f32_e32 v40, v40, v64                                // 000000D93540: 06508128
	v_mul_f32_e32 v26, 0xbfb8aa3b, v9                          // 000000D93544: 103412FF BFB8AA3B
	v_fma_f32 v92, -v58, v83, v74                              // 000000D9354C: D613005C 252AA73A
	v_mul_f32_e32 v32, 0x3db504f3, v32                         // 000000D93554: 104040FF 3DB504F3
	v_mul_f32_e32 v39, 0xbfb8aa3b, v22                         // 000000D9355C: 104E2CFF BFB8AA3B
	v_mov_b32_dpp v64, v40 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D93564: 7E8002FA FF016828
	v_cndmask_b32_e64 v40, -v40, v40, s3                       // 000000D9356C: D5010028 200E5128
	v_fmac_f32_e32 v83, v92, v71                               // 000000D93574: 56A68F5C
	v_fma_mix_f32 v20, v20, v32, neg(0) op_sel_hi:[1,0,0]      // 000000D93578: CC200014 8A024114
	v_exp_f32_e32 v39, v39                                     // 000000D93580: 7E4E4B27
	v_exp_f32_e32 v26, v26                                     // 000000D93584: 7E344B1A
	v_fma_f32 v79, -v54, v68, 1.0                              // 000000D93588: D613004F 23CA8936
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 000000D93590: BF870311
	v_fmac_f32_e32 v68, v79, v68                               // 000000D93594: 5688894F
	v_add_f32_e32 v32, 1.0, v39                                // 000000D93598: 06404EF2
	v_div_scale_f32 v39, vcc_lo, v8, v27, v8                   // 000000D9359C: D6FC6A27 04223708
	v_add_f32_e32 v40, v40, v64                                // 000000D935A4: 06508128
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(VALU_DEP_4)   // 000000D935A8: BF870205
	v_dual_add_f32 v26, 1.0, v26 :: v_dual_mul_f32 v79, v61, v68// 000000D935AC: C90634F2 1A4E893D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D935B4: BF870194
	v_div_scale_f32 v56, null, v32, v32, v22                   // 000000D935B8: D6FC7C38 045A4120
	v_dual_mul_f32 v75, v39, v63 :: v_dual_mul_f32 v40, 0x3db504f3, v40// 000000D935C0: C8C67F27 4B2850FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D935CC: BF870213
	v_div_scale_f32 v42, s4, v9, v26, v9                       // 000000D935D0: D6FC042A 04263509
	v_fma_f32 v88, -v54, v79, v61                              // 000000D935D8: D6130058 24F69F36
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D935E0: BF870194
	v_rcp_f32_e32 v70, v56                                     // 000000D935E4: 7E8C5538
	v_fma_f32 v84, -v37, v75, v39                              // 000000D935E8: D6130054 249E9725
	v_fma_mix_f32 v12, v12, v40, neg(0) op_sel_hi:[1,0,0]      // 000000D935F0: CC20000C 8A02510C
	v_div_scale_f32 v40, null, v26, v26, v9                    // 000000D935F8: D6FC7C28 0426351A
	v_div_scale_f32 v72, s9, v22, v32, v22                     // 000000D93600: D6FC0948 045A4116
	v_fmac_f32_e32 v79, v88, v68                               // 000000D93608: 569E8958
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D9360C: BF870214
	v_dual_fmac_f32 v75, v84, v63 :: v_dual_mul_f32 v28, 0xbfb8aa3b, v12// 000000D93610: C8067F54 4B1C18FF BFB8AA3B
	v_rcp_f32_e32 v64, v40                                     // 000000D9361C: 7E805528
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D93620: BF870116
	v_fma_f32 v82, -v56, v70, 1.0                              // 000000D93624: D6130052 23CA8D38
	v_fma_f32 v37, -v37, v75, v39                              // 000000D9362C: D6130025 249E9725
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D93634: BF870113
	v_exp_f32_e32 v28, v28                                     // 000000D93638: 7E384B1C
	v_fmac_f32_e32 v70, v82, v70                               // 000000D9363C: 568C8D52
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(TRANS32_DEP_2)// 000000D93640: BF870322
	v_div_fmas_f32 v37, v37, v63, v75                          // 000000D93644: D6370025 052E7F25
	s_mov_b32 vcc_lo, s4                                       // 000000D9364C: BEEA0004
	v_fma_f32 v76, -v40, v64, 1.0                              // 000000D93650: D613004C 23CA8128
	s_mov_b32 s4, exec_lo                                      // 000000D93658: BE84007E
	v_mul_f32_e32 v82, v72, v70                                // 000000D9365C: 10A48D48
	v_div_fixup_f32 v8, v37, v27, v8                           // 000000D93660: D6270008 04223725
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D93668: BF870225
	v_add_f32_e32 v28, 1.0, v28                                // 000000D9366C: 063838F2
	v_fmac_f32_e32 v64, v76, v64                               // 000000D93670: 5680814C
	v_fma_f32 v91, -v56, v82, v72                              // 000000D93674: D613005B 2522A538
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D9367C: BF870214
	v_mul_f32_e32 v7, v7, v8                                   // 000000D93680: 100E1107
	v_div_scale_f32 v53, null, v28, v28, v12                   // 000000D93684: D6FC7C35 0432391C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D9368C: BF870214
	v_mul_f32_e32 v76, v42, v64                                // 000000D93690: 1098812A
	v_fmac_f32_e32 v82, v91, v70                               // 000000D93694: 56A48D5B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D93698: BF870113
	v_rcp_f32_e32 v67, v53                                     // 000000D9369C: 7E865535
	v_fma_f32 v85, -v40, v76, v42                              // 000000D936A0: D6130055 24AA9928
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000D936A8: BF870291
	v_fmac_f32_e32 v76, v85, v64                               // 000000D936AC: 56988155
	v_fma_f32 v78, -v53, v67, 1.0                              // 000000D936B0: D613004E 23CA8735
	v_add_f32_e32 v24, v24, v60                                // 000000D936B8: 06307918
	v_div_scale_f32 v60, s6, v12, v28, v12                     // 000000D936BC: D6FC063C 0432390C
	s_delay_alu instid0(VALU_DEP_4)                            // 000000D936C4: BF870004
	v_fma_f32 v39, -v40, v76, v42                              // 000000D936C8: D6130027 24AA9928
	v_fma_f32 v40, -v52, v77, v59                              // 000000D936D0: D6130028 24EE9B34
	v_fmac_f32_e32 v67, v78, v67                               // 000000D936D8: 5686874E
	v_fma_f32 v52, -v54, v79, v61                              // 000000D936DC: D6130034 24F69F36
	v_fma_f32 v54, -v56, v82, v72                              // 000000D936E4: D6130036 2522A538
	v_div_fmas_f32 v39, v39, v64, v76                          // 000000D936EC: D6370027 05328127
	s_mov_b32 vcc_lo, s5                                       // 000000D936F4: BEEA0005
	v_mul_f32_e32 v78, v60, v67                                // 000000D936F8: 109C873C
	v_div_fmas_f32 v40, v40, v66, v77                          // 000000D936FC: D6370028 05368528
	s_mov_b32 vcc_lo, s6                                       // 000000D93704: BEEA0006
	v_div_fixup_f32 v9, v39, v26, v9                           // 000000D93708: D6270009 04263527
	v_mul_f32_e32 v24, 0x3db504f3, v24                         // 000000D93710: 103030FF 3DB504F3
	v_fma_f32 v87, -v53, v78, v60                              // 000000D93718: D6130057 24F29D35
	v_div_fixup_f32 v11, v40, v29, v11                         // 000000D93720: D627000B 042E3B28
	s_mov_b32 s5, 0x3db504f3                                   // 000000D93728: BE8500FF 3DB504F3
	v_mul_f32_e32 v9, v10, v9                                  // 000000D93730: 1012130A
	s_waitcnt vmcnt(8)                                         // 000000D93734: BF8923F7
	v_fma_mix_f32 v16, v16, v24, neg(0) op_sel_hi:[1,0,0]      // 000000D93738: CC200010 8A023110
	v_fmac_f32_e32 v78, v87, v67                               // 000000D93740: 569C8757
	v_mul_f32_e32 v11, v20, v11                                // 000000D93744: 10161714
	s_waitcnt vmcnt(7)                                         // 000000D93748: BF891FF7
	v_fma_mix_f32 v9, v43, v9, neg(0) op_sel_hi:[1,0,0]        // 000000D9374C: CC200009 8A02132B
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000D93754: BF870123
	v_fma_f32 v42, -v53, v78, v60                              // 000000D93758: D613002A 24F29D35
	v_fma_f32 v53, -v55, v80, v62                              // 000000D93760: D6130035 24FAA137
	v_div_fmas_f32 v27, v42, v67, v78                          // 000000D93768: D637001B 053A872A
	s_mov_b32 vcc_lo, s7                                       // 000000D93770: BEEA0007
	v_div_fmas_f32 v26, v52, v68, v79                          // 000000D93774: D637001A 053E8934
	s_mov_b32 vcc_lo, s8                                       // 000000D9377C: BEEA0008
	s_delay_alu instid0(VALU_DEP_2)                            // 000000D93780: BF870002
	v_div_fixup_f32 v8, v27, v28, v12                          // 000000D93784: D6270008 0432391B
	v_div_fmas_f32 v10, v53, v69, v80                          // 000000D9378C: D637000A 05428B35
	v_fma_f32 v12, -v58, v83, v74                              // 000000D93794: D613000C 252AA73A
	v_div_fixup_f32 v18, v26, v31, v18                         // 000000D9379C: D6270012 044A3F1A
	s_mov_b32 vcc_lo, s9                                       // 000000D937A4: BEEA0009
	v_mul_f32_e32 v8, v21, v8                                  // 000000D937A8: 10101115
	v_div_fixup_f32 v10, v10, v30, v19                         // 000000D937AC: D627000A 044E3D0A
	v_div_fmas_f32 v20, v54, v70, v82                          // 000000D937B4: D6370014 054A8D36
	s_mov_b32 vcc_lo, s10                                      // 000000D937BC: BEEA000A
	v_mul_f32_e32 v14, v14, v18                                // 000000D937C0: 101C250E
	v_div_fmas_f32 v12, v12, v71, v83                          // 000000D937C4: D637000C 054E8F0C
	v_mul_f32_e32 v10, v15, v10                                // 000000D937CC: 1014150F
	v_div_fixup_f32 v15, v20, v32, v22                         // 000000D937D0: D627000F 045A4114
	s_waitcnt vmcnt(6)                                         // 000000D937D8: BF891BF7
	v_fma_mix_f32 v8, v44, v8, neg(0) op_sel_hi:[1,0,0]        // 000000D937DC: CC200008 8A02112C
	v_div_fixup_f32 v12, v12, v34, v23                         // 000000D937E4: D627000C 045E450C
	s_waitcnt vmcnt(5)                                         // 000000D937EC: BF8917F7
	v_fma_mix_f32 v10, v45, v10, neg(0) op_sel_hi:[1,0,0]      // 000000D937F0: CC20000A 8A02152D
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000D937F8: BF870122
	v_mul_f32_e32 v12, v16, v12                                // 000000D937FC: 10181910
	s_waitcnt vmcnt(2)                                         // 000000D93800: BF890BF7
	v_fma_mix_f32 v18, v14, v48, v10 op_sel_hi:[0,1,0]         // 000000D93804: CC200012 142A610E
	v_mul_f32_e32 v36, 0x3db504f3, v36                         // 000000D9380C: 104848FF 3DB504F3
	s_waitcnt vmcnt(1)                                         // 000000D93814: BF8907F7
	v_fma_mix_f32 v16, v11, v50, v8 op_sel_hi:[0,1,0]          // 000000D93818: CC200010 1422650B
	v_fma_mix_f32 v8, v11, v50, -v8 op_sel_hi:[0,1,0]          // 000000D93820: CC200008 9422650B
	v_fma_mix_f32 v12, v46, v12, neg(0) op_sel_hi:[1,0,0]      // 000000D93828: CC20000C 8A02192E
	v_fma_mix_f32 v10, v14, v48, -v10 op_sel_hi:[0,1,0]        // 000000D93830: CC20000A 942A610E
	v_fma_mix_f32 v13, v13, v36, neg(0) op_sel_hi:[1,0,0]      // 000000D93838: CC20000D 8A02490D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000D93840: BF8701C1
	v_mul_f32_e32 v13, v13, v15                                // 000000D93844: 101A1F0D
	s_waitcnt vmcnt(0)                                         // 000000D93848: BF8903F7
	v_fma_mix_f32 v15, v7, v51, v9 op_sel_hi:[0,1,0]           // 000000D9384C: CC20000F 14266707
	v_fma_mix_f32 v7, v7, v51, -v9 op_sel_hi:[0,1,0]           // 000000D93854: CC200007 94266707
	v_fma_mix_f32 v19, v13, v47, v12 op_sel_hi:[0,1,0]         // 000000D9385C: CC200013 14325F0D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 000000D93864: BF870253
	v_add_f32_e32 v20, v15, v16                                // 000000D93868: 0628210F
	v_fma_mix_f32 v11, v13, v47, -v12 op_sel_hi:[0,1,0]        // 000000D9386C: CC20000B 94325F0D
	v_sub_f32_e32 v12, v15, v16                                // 000000D93874: 0818210F
	v_add_f32_e32 v13, v7, v8                                  // 000000D93878: 061A1107
	v_add_f32_e32 v21, v18, v19                                // 000000D9387C: 062A2712
	v_dual_sub_f32 v7, v7, v8 :: v_dual_add_f32 v8, v10, v11   // 000000D93880: C9481107 0708170A
	v_sub_f32_e32 v15, v18, v19                                // 000000D93888: 081E2712
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000D9388C: BF870123
	v_dual_sub_f32 v10, v10, v11 :: v_dual_add_f32 v9, v20, v21// 000000D93890: C948170A 0A082B14
	v_sub_f32_e32 v11, v20, v21                                // 000000D93898: 08162B14
	v_mov_b32_dpp v14, v9 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D9389C: 7E1C02FA FF016109
	v_cndmask_b32_e64 v9, -v9, v9, s0                          // 000000D938A4: D5010009 20021309
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D938AC: BF870113
	v_cndmask_b32_e64 v21, -v11, v11, s0                       // 000000D938B0: D5010015 2002170B
	v_add_f32_e32 v9, v9, v14                                  // 000000D938B8: 06121D09
	v_add_f32_e32 v14, v13, v8                                 // 000000D938BC: 061C110D
	v_dual_sub_f32 v13, v13, v8 :: v_dual_add_f32 v8, v12, v15 // 000000D938C0: C948110D 0D081F0C
	v_sub_f32_e32 v15, v12, v15                                // 000000D938C8: 081E1F0C
	s_delay_alu instid0(VALU_DEP_4)                            // 000000D938CC: BF870004
	v_mov_b32_dpp v16, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D938D0: 7E2002FA FF016209
	v_cndmask_b32_e64 v9, -v9, v9, s1                          // 000000D938D8: D5010009 20061309
	v_mov_b32_dpp v18, v14 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D938E0: 7E2402FA FF01610E
	v_cndmask_b32_e64 v14, -v14, v14, s0                       // 000000D938E8: D501000E 20021D0E
	v_mov_b32_dpp v19, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D938F0: 7E2602FA FF016108
	v_cndmask_b32_e64 v8, -v8, v8, s0                          // 000000D938F8: D5010008 20021108
	v_add_f32_e32 v9, v9, v16                                  // 000000D93900: 06122109
	v_mov_b32_dpp v22, v15 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D93904: 7E2C02FA FF01610F
	v_add_f32_e32 v12, v14, v18                                // 000000D9390C: 0618250E
	v_add_f32_e32 v14, v7, v10                                 // 000000D93910: 061C1507
	v_add_f32_e32 v8, v8, v19                                  // 000000D93914: 06102708
	v_mov_b32_dpp v16, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D93918: 7E2002FA FF016409
	v_cndmask_b32_e64 v9, -v9, v9, s2                          // 000000D93920: D5010009 200A1309
	v_mov_b32_dpp v18, v12 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D93928: 7E2402FA FF01620C
	v_cndmask_b32_e64 v12, -v12, v12, s1                       // 000000D93930: D501000C 2006190C
	v_mov_b32_dpp v19, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D93938: 7E2602FA FF016208
	v_cndmask_b32_e64 v8, -v8, v8, s1                          // 000000D93940: D5010008 20061108
	v_mov_b32_dpp v20, v14 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D93948: 7E2802FA FF01610E
	v_cndmask_b32_e64 v14, -v14, v14, s0                       // 000000D93950: D501000E 20021D0E
	v_add_f32_e32 v12, v12, v18                                // 000000D93958: 0618250C
	v_sub_f32_e32 v18, v7, v10                                 // 000000D9395C: 08241507
	v_dual_add_f32 v8, v8, v19 :: v_dual_add_f32 v7, v9, v16   // 000000D93960: C9082708 08062109
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000D93968: BF870234
	v_add_f32_e32 v9, v14, v20                                 // 000000D9396C: 0612290E
	v_mov_b32_dpp v20, v11 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D93970: 7E2802FA FF01610B
	v_cndmask_b32_e64 v15, -v15, v15, s0                       // 000000D93978: D501000F 20021F0F
	v_mov_b32_dpp v14, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D93980: 7E1C02FA FF016408
	v_cndmask_b32_e64 v8, -v8, v8, s2                          // 000000D93988: D5010008 200A1108
	v_mov_b32_dpp v16, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D93990: 7E2002FA FF016209
	v_cndmask_b32_e64 v19, -v9, v9, s1                         // 000000D93998: D5010013 20061309
	v_mov_b32_dpp v23, v18 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D939A0: 7E2E02FA FF016112
	v_cndmask_b32_e64 v18, -v18, v18, s0                       // 000000D939A8: D5010012 20022512
	v_add_f32_e32 v11, v8, v14                                 // 000000D939B0: 06161D08
	v_mov_b32_dpp v10, v12 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D939B4: 7E1402FA FF01640C
	v_add_f32_e32 v14, v19, v16                                // 000000D939BC: 061C2113
	v_add_f32_e32 v16, v21, v20                                // 000000D939C0: 06202915
	v_mov_b32_dpp v21, v13 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D939C4: 7E2A02FA FF01610D
	v_cndmask_b32_e64 v13, -v13, v13, s0                       // 000000D939CC: D501000D 20021B0D
	v_cndmask_b32_e64 v12, -v12, v12, s2                       // 000000D939D4: D501000C 200A190C
	v_mov_b32_dpp v19, v14 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D939DC: 7E2602FA FF01640E
	v_cndmask_b32_e64 v14, -v14, v14, s2                       // 000000D939E4: D501000E 200A1D0E
	v_mov_b32_dpp v20, v16 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D939EC: 7E2802FA FF016210
	v_cndmask_b32_e64 v16, -v16, v16, s1                       // 000000D939F4: D5010010 20062110
	v_add_f32_e32 v21, v13, v21                                // 000000D939FC: 062A2B0D
	v_add_f32_e32 v9, v12, v10                                 // 000000D93A00: 0612150C
	v_dual_add_f32 v13, v14, v19 :: v_dual_add_f32 v14, v15, v22// 000000D93A04: C908270E 0D0E2D0F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D93A0C: BF870214
	v_dual_add_f32 v15, v16, v20 :: v_dual_add_f32 v16, v18, v23// 000000D93A10: C9082910 0F102F12
	v_mov_b32_dpp v18, v21 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D93A18: 7E2402FA FF016215
	v_cndmask_b32_e64 v19, -v21, v21, s1                       // 000000D93A20: D5010013 20062B15
	s_delay_alu instid0(VALU_DEP_4)                            // 000000D93A28: BF870004
	v_mov_b32_dpp v20, v14 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D93A2C: 7E2802FA FF01620E
	v_cndmask_b32_e64 v14, -v14, v14, s1                       // 000000D93A34: D501000E 20061D0E
	v_mov_b32_dpp v21, v16 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D93A3C: 7E2A02FA FF016210
	v_cndmask_b32_e64 v16, -v16, v16, s1                       // 000000D93A44: D5010010 20062110
	v_add_f32_e32 v18, v19, v18                                // 000000D93A4C: 06242513
	v_mov_b32_dpp v19, v15 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D93A50: 7E2602FA FF01640F
	v_add_f32_e32 v14, v14, v20                                // 000000D93A58: 061C290E
	v_cndmask_b32_e64 v15, -v15, v15, s2                       // 000000D93A5C: D501000F 200A1F0F
	v_add_f32_e32 v16, v16, v21                                // 000000D93A64: 06202B10
	v_mov_b32_dpp v20, v18 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D93A68: 7E2802FA FF016412
	v_cndmask_b32_e64 v21, -v18, v18, s2                       // 000000D93A70: D5010015 200A2512
	v_mov_b32_dpp v22, v14 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D93A78: 7E2C02FA FF01640E
	v_cndmask_b32_e64 v23, -v14, v14, s2                       // 000000D93A80: D5010017 200A1D0E
	v_mov_b32_dpp v24, v16 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D93A88: 7E3002FA FF016410
	v_cndmask_b32_e64 v16, -v16, v16, s2                       // 000000D93A90: D5010010 200A2110
	v_dual_add_f32 v18, v15, v19 :: v_dual_add_f32 v19, v21, v20// 000000D93A98: C908270F 12122915
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D93AA0: BF870224
	v_add_f32_e32 v21, v23, v22                                // 000000D93AA4: 062A2D17
	v_mov_b32_dpp v8, v7 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D93AA8: 7E1002FA FF016807
	v_add_f32_e32 v23, v16, v24                                // 000000D93AB0: 062E3110
	v_mov_b32_dpp v10, v9 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D93AB4: 7E1402FA FF016809
	v_mov_b32_dpp v12, v11 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D93ABC: 7E1802FA FF01680B
	v_mov_b32_dpp v14, v13 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D93AC4: 7E1C02FA FF01680D
	v_add_nc_u32_e32 v15, 12, v6                               // 000000D93ACC: 4A1E0C8C
	v_mov_b32_dpp v16, v18 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D93AD0: 7E2002FA FF016812
	v_mov_b32_dpp v20, v19 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D93AD8: 7E2802FA FF016813
	v_mov_b32_dpp v22, v21 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D93AE0: 7E2C02FA FF016815
	v_mov_b32_dpp v24, v23 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D93AE8: 7E3002FA FF016817
	.long 0xd4c4007e                                           // 000000D93AF0: D4C4007E
	v_cndmask_b32_e32 v1, s23, v15, vcc_lo                     // 000000D93AF4: 02021E17
	s_cbranch_execz 60                                         // 000000D93AF8: BFA5003C <_ZN7halogen12_GLOBAL__N_111k_ht_moe_guILi3ELi8ELi1EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_S5_PDF16_+0x78ec>
	v_cndmask_b32_e64 v7, -v7, v7, s3                          // 000000D93AFC: D5010007 200E0F07
	v_cndmask_b32_e64 v23, -v23, v23, s3                       // 000000D93B04: D5010017 200E2F17
	v_cndmask_b32_e64 v9, -v9, v9, s3                          // 000000D93B0C: D5010009 200E1309
	v_cndmask_b32_e64 v11, -v11, v11, s3                       // 000000D93B14: D501000B 200E170B
	v_cndmask_b32_e64 v19, -v19, v19, s3                       // 000000D93B1C: D5010013 200E2713
	v_cndmask_b32_e64 v13, -v13, v13, s3                       // 000000D93B24: D501000D 200E1B0D
	v_cndmask_b32_e64 v21, -v21, v21, s3                       // 000000D93B2C: D5010015 200E2B15
	v_cndmask_b32_e64 v18, -v18, v18, s3                       // 000000D93B34: D5010012 200E2512
	v_add_f32_e32 v7, v7, v8                                   // 000000D93B3C: 060E1107
	v_dual_add_f32 v23, v23, v24 :: v_dual_add_f32 v8, v9, v10 // 000000D93B40: C9083117 17081509
	v_add_f32_e32 v9, v11, v12                                 // 000000D93B48: 0612190B
	v_mad_i64_i32 v[11:12], null, 0x500, v15, v[0:1]           // 000000D93B4C: D6FF7C0B 04021EFF 00000500
	v_dual_add_f32 v19, v19, v20 :: v_dual_add_f32 v10, v13, v14// 000000D93B58: C9082913 130A1D0D
	v_dual_add_f32 v21, v21, v22 :: v_dual_add_f32 v16, v18, v16// 000000D93B60: C9082D15 15102112
	v_fma_mixlo_f16 v7, v7, s5, 0                              // 000000D93B68: CC210007 02000B07
	v_fma_mixhi_f16 v7, v8, s5, 0                              // 000000D93B70: CC220007 02000B08
	v_fma_mixlo_f16 v8, v9, s5, 0                              // 000000D93B78: CC210008 02000B09
	v_fma_mixhi_f16 v8, v10, s5, 0                             // 000000D93B80: CC220008 02000B0A
	v_fma_mixlo_f16 v9, v16, s5, 0                             // 000000D93B88: CC210009 02000B10
	v_fma_mixhi_f16 v9, v19, s5, 0                             // 000000D93B90: CC220009 02000B13
	v_fma_mixlo_f16 v10, v21, s5, 0                            // 000000D93B98: CC21000A 02000B15
	v_fma_mixhi_f16 v10, v23, s5, 0                            // 000000D93BA0: CC22000A 02000B17
	s_clause 0x7                                               // 000000D93BA8: BF850007
	global_store_b16 v[11:12], v7, off                         // 000000D93BAC: DC660000 007C070B
	global_store_d16_hi_b16 v[11:12], v7, off offset:32        // 000000D93BB4: DC960020 007C070B
	global_store_b16 v[11:12], v8, off offset:64               // 000000D93BBC: DC660040 007C080B
	global_store_d16_hi_b16 v[11:12], v8, off offset:96        // 000000D93BC4: DC960060 007C080B
	global_store_b16 v[11:12], v9, off offset:128              // 000000D93BCC: DC660080 007C090B
	global_store_d16_hi_b16 v[11:12], v9, off offset:160       // 000000D93BD4: DC9600A0 007C090B
	global_store_b16 v[11:12], v10, off offset:192             // 000000D93BDC: DC6600C0 007C0A0B
	global_store_d16_hi_b16 v[11:12], v10, off offset:224      // 000000D93BE4: DC9600E0 007C0A0B
	s_or_b32 exec_lo, exec_lo, s4                              // 000000D93BEC: 8C7E047E
	s_clause 0xb                                               // 000000D93BF0: BF85000B
	global_load_d16_b16 v7, v[2:3], off offset:1280            // 000000D93BF4: DC820500 077C0002
	global_load_d16_b16 v10, v[2:3], off offset:1312           // 000000D93BFC: DC820520 0A7C0002
	global_load_d16_b16 v8, v[2:3], off                        // 000000D93C04: DC820000 087C0002
	global_load_d16_b16 v9, v[2:3], off offset:32              // 000000D93C0C: DC820020 097C0002
	global_load_d16_b16 v11, v[2:3], off offset:64             // 000000D93C14: DC820040 0B7C0002
	global_load_d16_b16 v12, v[2:3], off offset:96             // 000000D93C1C: DC820060 0C7C0002
	global_load_d16_b16 v13, v[2:3], off offset:128            // 000000D93C24: DC820080 0D7C0002
	global_load_d16_b16 v14, v[2:3], off offset:160            // 000000D93C2C: DC8200A0 0E7C0002
	global_load_d16_b16 v15, v[2:3], off offset:192            // 000000D93C34: DC8200C0 0F7C0002
	global_load_d16_b16 v16, v[2:3], off offset:224            // 000000D93C3C: DC8200E0 107C0002
	global_load_d16_b16 v18, v[2:3], off offset:1344           // 000000D93C44: DC820540 127C0002
	global_load_d16_b16 v19, v[2:3], off offset:1376           // 000000D93C4C: DC820560 137C0002
	v_add_f32_e32 v34, v41, v33                                // 000000D93C54: 06444329
	v_add_f32_e32 v35, v25, v17                                // 000000D93C58: 06462319
	v_sub_f32_e32 v28, v89, v81                                // 000000D93C5C: 0838A359
	v_add_f32_e32 v29, v73, v65                                // 000000D93C60: 063A8349
	v_sub_f32_e32 v32, v57, v49                                // 000000D93C64: 08406339
	s_delay_alu instid0(VALU_DEP_4)                            // 000000D93C68: BF870004
	v_dual_sub_f32 v33, v41, v33 :: v_dual_add_f32 v44, v34, v35// 000000D93C6C: C9484329 212C4722
	v_sub_f32_e32 v30, v73, v65                                // 000000D93C74: 083C8349
	v_sub_f32_e32 v26, v105, v97                               // 000000D93C78: 0834C369
	v_add_f32_e32 v22, v121, v113                              // 000000D93C7C: 062CE379
	v_add_f32_e32 v24, v105, v97                               // 000000D93C80: 0630C369
	v_add_f32_e32 v27, v89, v81                                // 000000D93C84: 0636A359
	v_add_f32_e32 v20, v137, v129                              // 000000D93C88: 06290389
	v_sub_f32_e32 v21, v137, v129                              // 000000D93C8C: 082B0389
	v_add_f32_e32 v31, v57, v49                                // 000000D93C90: 063E6339
	v_sub_f32_e32 v17, v25, v17                                // 000000D93C94: 08222319
	s_clause 0x3                                               // 000000D93C98: BF850003
	global_load_d16_b16 v25, v[2:3], off offset:1408           // 000000D93C9C: DC820580 197C0002
	global_load_d16_b16 v36, v[2:3], off offset:1440           // 000000D93CA4: DC8205A0 247C0002
	global_load_d16_b16 v37, v[2:3], off offset:1472           // 000000D93CAC: DC8205C0 257C0002
	global_load_d16_b16 v2, v[2:3], off offset:1504            // 000000D93CB4: DC8205E0 027C0002
	s_clause 0x7                                               // 000000D93CBC: BF850007
	global_load_d16_b16 v3, v[4:5], off                        // 000000D93CC0: DC820000 037C0004
	global_load_d16_b16 v38, v[4:5], off offset:32             // 000000D93CC8: DC820020 267C0004
	global_load_d16_b16 v39, v[4:5], off offset:64             // 000000D93CD0: DC820040 277C0004
	global_load_d16_b16 v40, v[4:5], off offset:96             // 000000D93CD8: DC820060 287C0004
	global_load_d16_b16 v41, v[4:5], off offset:128            // 000000D93CE0: DC820080 297C0004
	global_load_d16_b16 v42, v[4:5], off offset:160            // 000000D93CE8: DC8200A0 2A7C0004
	global_load_d16_b16 v43, v[4:5], off offset:192            // 000000D93CF0: DC8200C0 2B7C0004
	global_load_d16_b16 v4, v[4:5], off offset:224             // 000000D93CF8: DC8200E0 047C0004
	v_add_f32_e32 v5, v20, v22                                 // 000000D93D00: 060A2D14
	v_dual_sub_f32 v23, v121, v113 :: v_dual_sub_f32 v20, v20, v22// 000000D93D04: C94AE379 17142D14
	v_sub_f32_e32 v34, v34, v35                                // 000000D93D0C: 08444722
	v_add_nc_u32_e32 v6, 14, v6                                // 000000D93D10: 4A0C0C8E
	s_delay_alu instid0(VALU_DEP_3)                            // 000000D93D14: BF870003
	v_add_f32_e32 v22, v21, v23                                // 000000D93D18: 062C2F15
	v_sub_f32_e32 v21, v21, v23                                // 000000D93D1C: 082A2F15
	v_add_f32_e32 v23, v24, v27                                // 000000D93D20: 062E3718
	v_dual_sub_f32 v24, v24, v27 :: v_dual_add_f32 v27, v26, v28// 000000D93D24: C9483718 181A391A
	v_sub_f32_e32 v26, v26, v28                                // 000000D93D2C: 0834391A
	v_add_f32_e32 v28, v29, v31                                // 000000D93D30: 06383F1D
	s_delay_alu instid0(VALU_DEP_3)                            // 000000D93D34: BF870003
	v_dual_sub_f32 v29, v29, v31 :: v_dual_add_f32 v46, v20, v24// 000000D93D38: C9483F1D 1D2E3114
	v_add_f32_e32 v31, v30, v32                                // 000000D93D40: 063E411E
	v_sub_f32_e32 v30, v30, v32                                // 000000D93D44: 083C411E
	v_add_f32_e32 v32, v33, v17                                // 000000D93D48: 06402321
	v_dual_sub_f32 v17, v33, v17 :: v_dual_sub_f32 v20, v20, v24// 000000D93D4C: C94A2321 11143114
	v_mov_b32_dpp v53, v46 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D93D54: 7E6A02FA FF01612E
	v_cndmask_b32_e64 v46, -v46, v46, s0                       // 000000D93D5C: D501002E 20025D2E
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000D93D64: BF8701C4
	v_add_f32_e32 v35, v31, v32                                // 000000D93D68: 0646411F
	v_dual_sub_f32 v31, v31, v32 :: v_dual_add_f32 v32, v29, v34// 000000D93D6C: C948411F 1F20451D
	v_dual_sub_f32 v29, v29, v34 :: v_dual_add_f32 v34, v30, v17// 000000D93D74: C948451D 1D22231E
	v_sub_f32_e32 v17, v30, v17                                // 000000D93D7C: 0822231E
	v_mov_b32_dpp v48, v31 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D93D80: 7E6002FA FF01611F
	v_cndmask_b32_e64 v31, -v31, v31, s0                       // 000000D93D88: D501001F 20023F1F
	v_dual_add_f32 v30, v22, v27 :: v_dual_add_f32 v45, v21, v26// 000000D93D90: C9083716 1E2C3515
	v_sub_f32_e32 v22, v22, v27                                // 000000D93D98: 082C3716
	v_cndmask_b32_e64 v27, -v35, v35, s0                       // 000000D93D9C: D501001B 20024723
	s_delay_alu instid0(VALU_DEP_4)                            // 000000D93DA4: BF870004
	v_add_f32_e32 v31, v31, v48                                // 000000D93DA8: 063E611F
	v_add_f32_e32 v33, v28, v44                                // 000000D93DAC: 0642591C
	v_sub_f32_e32 v28, v28, v44                                // 000000D93DB0: 0838591C
	v_add_f32_e32 v44, v5, v23                                 // 000000D93DB4: 06582F05
	v_mov_b32_dpp v49, v29 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D93DB8: 7E6202FA FF01611D
	v_cndmask_b32_e64 v29, -v29, v29, s0                       // 000000D93DC0: D501001D 20023B1D
	v_cndmask_b32_e64 v24, -v33, v33, s0                       // 000000D93DC8: D5010018 20024321
	v_mov_b32_dpp v47, v28 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D93DD0: 7E5E02FA FF01611C
	v_cndmask_b32_e64 v28, -v28, v28, s0                       // 000000D93DD8: D501001C 2002391C
	v_sub_f32_e32 v21, v21, v26                                // 000000D93DE0: 082A3515
	v_mov_b32_dpp v26, v35 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D93DE4: 7E3402FA FF016123
	v_sub_f32_e32 v5, v5, v23                                  // 000000D93DEC: 080A2F05
	v_mov_b32_dpp v23, v33 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D93DF0: 7E2E02FA FF016121
	v_mov_b32_dpp v35, v34 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D93DF8: 7E4602FA FF016122
	v_cndmask_b32_e64 v34, -v34, v34, s0                       // 000000D93E00: D5010022 20024522
	v_mov_b32_dpp v50, v17 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D93E08: 7E6402FA FF016111
	v_cndmask_b32_e64 v17, -v17, v17, s0                       // 000000D93E10: D5010011 20022311
	v_dual_add_f32 v23, v24, v23 :: v_dual_add_f32 v24, v27, v26// 000000D93E18: C9082F18 1718351B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000D93E20: BF870234
	v_add_f32_e32 v27, v34, v35                                // 000000D93E24: 06364722
	v_add_f32_e32 v34, v46, v53                                // 000000D93E28: 06446B2E
	v_mov_b32_dpp v52, v30 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D93E2C: 7E6802FA FF01611E
	v_mov_b32_dpp v35, v23 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D93E34: 7E4602FA FF016217
	v_cndmask_b32_e64 v23, -v23, v23, s1                       // 000000D93E3C: D5010017 20062F17
	v_mov_b32_dpp v46, v27 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D93E44: 7E5C02FA FF01621B
	v_cndmask_b32_e64 v27, -v27, v27, s1                       // 000000D93E4C: D501001B 2006371B
	v_cndmask_b32_e64 v30, -v30, v30, s0                       // 000000D93E54: D501001E 20023D1E
	v_mov_b32_dpp v55, v5 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D93E5C: 7E6E02FA FF016105
	v_add_f32_e32 v23, v23, v35                                // 000000D93E64: 062E4717
	v_mov_b32_dpp v33, v32 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D93E68: 7E4202FA FF016120
	v_cndmask_b32_e64 v32, -v32, v32, s0                       // 000000D93E70: D5010020 20024120
	v_mov_b32_dpp v56, v22 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D93E78: 7E7002FA FF016116
	v_cndmask_b32_e64 v22, -v22, v22, s0                       // 000000D93E80: D5010016 20022D16
	v_cndmask_b32_e64 v5, -v5, v5, s0                          // 000000D93E88: D5010005 20020B05
	v_add_f32_e32 v28, v28, v47                                // 000000D93E90: 06385F1C
	v_add_f32_e32 v26, v32, v33                                // 000000D93E94: 06344320
	v_mov_b32_dpp v54, v45 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D93E98: 7E6C02FA FF01612D
	v_cndmask_b32_e64 v45, -v45, v45, s0                       // 000000D93EA0: D501002D 20025B2D
	v_mov_b32_dpp v58, v21 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D93EA8: 7E7402FA FF016115
	v_cndmask_b32_e64 v21, -v21, v21, s0                       // 000000D93EB0: D5010015 20022B15
	v_add_f32_e32 v27, v27, v46                                // 000000D93EB8: 06365D1B
	v_mov_b32_dpp v51, v44 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D93EBC: 7E6602FA FF01612C
	v_add_f32_e32 v33, v45, v54                                // 000000D93EC4: 06426D2D
	v_cndmask_b32_e64 v44, -v44, v44, s0                       // 000000D93EC8: D501002C 2002592C
	v_mov_b32_dpp v57, v20 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D93ED0: 7E7202FA FF016114
	v_cndmask_b32_e64 v20, -v20, v20, s0                       // 000000D93ED8: D5010014 20022914
	v_dual_add_f32 v29, v29, v49 :: v_dual_add_f32 v30, v30, v52// 000000D93EE0: C908631D 1D1E691E
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D93EE8: BF870224
	v_dual_add_f32 v17, v17, v50 :: v_dual_add_f32 v32, v44, v51// 000000D93EEC: C9086511 1120672C
	v_dual_add_f32 v22, v22, v56 :: v_dual_add_f32 v5, v5, v55 // 000000D93EF4: C9087116 16046F05
	v_dual_add_f32 v21, v21, v58 :: v_dual_add_f32 v20, v20, v57// 000000D93EFC: C9087515 15147314
	v_mov_b32_dpp v53, v34 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D93F04: 7E6A02FA FF016222
	v_cndmask_b32_e64 v34, -v34, v34, s1                       // 000000D93F0C: D5010022 20064522
	v_mov_b32_dpp v51, v32 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D93F14: 7E6602FA FF016220
	v_mov_b32_dpp v52, v30 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D93F1C: 7E6802FA FF01621E
	v_cndmask_b32_e64 v30, -v30, v30, s1                       // 000000D93F24: D501001E 20063D1E
	v_cndmask_b32_e64 v32, -v32, v32, s1                       // 000000D93F2C: D5010020 20064120
	v_mov_b32_dpp v55, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D93F34: 7E6E02FA FF016205
	v_mov_b32_dpp v56, v22 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D93F3C: 7E7002FA FF016216
	v_cndmask_b32_e64 v22, -v22, v22, s1                       // 000000D93F44: D5010016 20062D16
	v_cndmask_b32_e64 v5, -v5, v5, s1                          // 000000D93F4C: D5010005 20060B05
	v_mov_b32_dpp v58, v21 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D93F54: 7E7402FA FF016215
	v_cndmask_b32_e64 v21, -v21, v21, s1                       // 000000D93F5C: D5010015 20062B15
	v_add_f32_e32 v34, v34, v53                                // 000000D93F64: 06446B22
	v_mov_b32_dpp v54, v33 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D93F68: 7E6C02FA FF016221
	v_cndmask_b32_e64 v33, -v33, v33, s1                       // 000000D93F70: D5010021 20064321
	v_add_f32_e32 v30, v30, v52                                // 000000D93F78: 063C691E
	v_dual_add_f32 v32, v32, v51 :: v_dual_add_f32 v21, v21, v58// 000000D93F7C: C9086720 20147515
	v_add_f32_e32 v5, v5, v55                                  // 000000D93F84: 060A6F05
	v_mov_b32_dpp v35, v23 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D93F88: 7E4602FA FF016417
	v_cndmask_b32_e64 v23, -v23, v23, s2                       // 000000D93F90: D5010017 200A2F17
	v_add_f32_e32 v22, v22, v56                                // 000000D93F98: 062C7116
	v_mov_b32_dpp v53, v34 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D93F9C: 7E6A02FA FF016422
	v_cndmask_b32_e64 v34, -v34, v34, s2                       // 000000D93FA4: D5010022 200A4522
	v_add_f32_e32 v33, v33, v54                                // 000000D93FAC: 06426D21
	v_mov_b32_dpp v51, v32 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D93FB0: 7E6602FA FF016420
	v_mov_b32_dpp v52, v30 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D93FB8: 7E6802FA FF01641E
	v_cndmask_b32_e64 v30, -v30, v30, s2                       // 000000D93FC0: D501001E 200A3D1E
	v_cndmask_b32_e64 v32, -v32, v32, s2                       // 000000D93FC8: D5010020 200A4120
	v_mov_b32_dpp v55, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D93FD0: 7E6E02FA FF016405
	v_cndmask_b32_e64 v5, -v5, v5, s2                          // 000000D93FD8: D5010005 200A0B05
	v_mov_b32_dpp v58, v21 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D93FE0: 7E7402FA FF016415
	v_cndmask_b32_e64 v21, -v21, v21, s2                       // 000000D93FE8: D5010015 200A2B15
	v_add_f32_e32 v23, v23, v35                                // 000000D93FF0: 062E4717
	v_mov_b32_dpp v56, v22 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D93FF4: 7E7002FA FF016416
	v_cndmask_b32_e64 v22, -v22, v22, s2                       // 000000D93FFC: D5010016 200A2D16
	v_dual_add_f32 v34, v34, v53 :: v_dual_add_f32 v5, v5, v55 // 000000D94004: C9086B22 22046F05
	v_mov_b32_dpp v54, v33 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D9400C: 7E6C02FA FF016421
	v_cndmask_b32_e64 v33, -v33, v33, s2                       // 000000D94014: D5010021 200A4321
	v_add_f32_e32 v30, v30, v52                                // 000000D9401C: 063C691E
	v_dual_add_f32 v32, v32, v51 :: v_dual_add_f32 v21, v21, v58// 000000D94020: C9086720 20147515
	v_mov_b32_dpp v35, v23 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D94028: 7E4602FA FF016817
	v_cndmask_b32_e64 v23, -v23, v23, s3                       // 000000D94030: D5010017 200E2F17
	v_add_f32_e32 v22, v22, v56                                // 000000D94038: 062C7116
	v_mov_b32_dpp v53, v34 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D9403C: 7E6A02FA FF016822
	v_cndmask_b32_e64 v34, -v34, v34, s3                       // 000000D94044: D5010022 200E4522
	v_add_f32_e32 v33, v33, v54                                // 000000D9404C: 06426D21
	v_mov_b32_dpp v51, v32 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D94050: 7E6602FA FF016820
	v_mov_b32_dpp v52, v30 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D94058: 7E6802FA FF01681E
	v_cndmask_b32_e64 v30, -v30, v30, s3                       // 000000D94060: D501001E 200E3D1E
	v_cndmask_b32_e64 v32, -v32, v32, s3                       // 000000D94068: D5010020 200E4120
	v_mov_b32_dpp v55, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D94070: 7E6E02FA FF016805
	v_cndmask_b32_e64 v5, -v5, v5, s3                          // 000000D94078: D5010005 200E0B05
	v_mov_b32_dpp v58, v21 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D94080: 7E7402FA FF016815
	v_cndmask_b32_e64 v21, -v21, v21, s3                       // 000000D94088: D5010015 200E2B15
	v_add_f32_e32 v23, v23, v35                                // 000000D94090: 062E4717
	v_mov_b32_dpp v56, v22 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D94094: 7E7002FA FF016816
	v_cndmask_b32_e64 v22, -v22, v22, s3                       // 000000D9409C: D5010016 200E2D16
	s_delay_alu instid0(VALU_DEP_4)                            // 000000D940A4: BF870004
	v_dual_add_f32 v34, v34, v53 :: v_dual_add_f32 v21, v21, v58// 000000D940A8: C9086B22 22147515
	v_mov_b32_dpp v54, v33 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D940B0: 7E6C02FA FF016821
	v_cndmask_b32_e64 v33, -v33, v33, s3                       // 000000D940B8: D5010021 200E4321
	v_add_f32_e32 v32, v32, v51                                // 000000D940C0: 06406720
	v_dual_add_f32 v30, v30, v52 :: v_dual_add_f32 v5, v5, v55 // 000000D940C4: C908691E 1E046F05
	v_dual_add_f32 v22, v22, v56 :: v_dual_mul_f32 v23, 0x3db504f3, v23// 000000D940CC: C9067116 16162EFF 3DB504F3
	v_dual_mul_f32 v34, 0x3db504f3, v34 :: v_dual_mul_f32 v21, 0x3db504f3, v21// 000000D940D8: C8C644FF 22142AFF 3DB504F3
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D940E4: BF870194
	v_dual_add_f32 v33, v33, v54 :: v_dual_mul_f32 v32, 0x3db504f3, v32// 000000D940E8: C9066D21 212040FF 3DB504F3
	v_dual_mul_f32 v5, 0x3db504f3, v5 :: v_dual_mul_f32 v22, 0x3db504f3, v22// 000000D940F4: C8C60AFF 05162CFF 3DB504F3
	v_mov_b32_dpp v44, v24 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D94100: 7E5802FA FF016218
	v_cndmask_b32_e64 v24, -v24, v24, s1                       // 000000D94108: D5010018 20063118
	v_mov_b32_dpp v45, v26 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D94110: 7E5A02FA FF01621A
	v_cndmask_b32_e64 v26, -v26, v26, s1                       // 000000D94118: D501001A 2006351A
	v_mov_b32_dpp v48, v31 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D94120: 7E6002FA FF01621F
	v_cndmask_b32_e64 v31, -v31, v31, s1                       // 000000D94128: D501001F 20063F1F
	v_mov_b32_dpp v49, v29 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D94130: 7E6202FA FF01621D
	v_cndmask_b32_e64 v29, -v29, v29, s1                       // 000000D94138: D501001D 20063B1D
	v_add_f32_e32 v24, v24, v44                                // 000000D94140: 06305918
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D94144: BF870224
	v_dual_add_f32 v26, v26, v45 :: v_dual_add_f32 v31, v31, v48// 000000D94148: C9085B1A 1A1E611F
	v_mov_b32_dpp v47, v28 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D94150: 7E5E02FA FF01621C
	v_add_f32_e32 v29, v29, v49                                // 000000D94158: 063A631D
	s_delay_alu instid0(VALU_DEP_4)                            // 000000D9415C: BF870004
	v_mov_b32_dpp v44, v24 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D94160: 7E5802FA FF016418
	v_cndmask_b32_e64 v24, -v24, v24, s2                       // 000000D94168: D5010018 200A3118
	v_mov_b32_dpp v45, v26 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D94170: 7E5A02FA FF01641A
	v_cndmask_b32_e64 v26, -v26, v26, s2                       // 000000D94178: D501001A 200A351A
	v_mov_b32_dpp v48, v31 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D94180: 7E6002FA FF01641F
	v_cndmask_b32_e64 v31, -v31, v31, s2                       // 000000D94188: D501001F 200A3F1F
	v_mov_b32_dpp v49, v29 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D94190: 7E6202FA FF01641D
	v_cndmask_b32_e64 v29, -v29, v29, s2                       // 000000D94198: D501001D 200A3B1D
	v_add_f32_e32 v24, v24, v44                                // 000000D941A0: 06305918
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D941A4: BF870224
	v_dual_add_f32 v26, v26, v45 :: v_dual_add_f32 v31, v31, v48// 000000D941A8: C9085B1A 1A1E611F
	v_cndmask_b32_e64 v28, -v28, v28, s1                       // 000000D941B0: D501001C 2006391C
	v_add_f32_e32 v29, v29, v49                                // 000000D941B8: 063A631D
	s_delay_alu instid0(VALU_DEP_4)                            // 000000D941BC: BF870004
	v_mov_b32_dpp v44, v24 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D941C0: 7E5802FA FF016818
	v_cndmask_b32_e64 v24, -v24, v24, s3                       // 000000D941C8: D5010018 200E3118
	v_mov_b32_dpp v45, v26 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D941D0: 7E5A02FA FF01681A
	v_cndmask_b32_e64 v26, -v26, v26, s3                       // 000000D941D8: D501001A 200E351A
	v_mov_b32_dpp v48, v31 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D941E0: 7E6002FA FF01681F
	v_cndmask_b32_e64 v31, -v31, v31, s3                       // 000000D941E8: D501001F 200E3F1F
	v_mov_b32_dpp v49, v29 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D941F0: 7E6202FA FF01681D
	v_cndmask_b32_e64 v29, -v29, v29, s3                       // 000000D941F8: D501001D 200E3B1D
	v_add_f32_e32 v24, v24, v44                                // 000000D94200: 06305918
	v_mov_b32_dpp v57, v20 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D94204: 7E7202FA FF016214
	v_cndmask_b32_e64 v20, -v20, v20, s1                       // 000000D9420C: D5010014 20062914
	v_dual_add_f32 v26, v26, v45 :: v_dual_add_f32 v31, v31, v48// 000000D94214: C9085B1A 1A1E611F
	s_delay_alu instid0(VALU_DEP_4)                            // 000000D9421C: BF870004
	v_dual_add_f32 v29, v29, v49 :: v_dual_mul_f32 v24, 0x3db504f3, v24// 000000D94220: C906631D 1D1830FF 3DB504F3
	v_mov_b32_dpp v50, v17 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D9422C: 7E6402FA FF016211
	v_cndmask_b32_e64 v17, -v17, v17, s1                       // 000000D94234: D5010011 20062311
	v_add_f32_e32 v28, v28, v47                                // 000000D9423C: 06385F1C
	v_mov_b32_dpp v46, v27 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D94240: 7E5C02FA FF01641B
	v_cndmask_b32_e64 v27, -v27, v27, s2                       // 000000D94248: D501001B 200A371B
	v_dual_add_f32 v20, v20, v57 :: v_dual_mul_f32 v31, 0x3db504f3, v31// 000000D94250: C9067314 141E3EFF 3DB504F3
	v_add_f32_e32 v17, v17, v50                                // 000000D9425C: 06226511
	v_mov_b32_dpp v47, v28 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D94260: 7E5E02FA FF01641C
	v_cndmask_b32_e64 v28, -v28, v28, s2                       // 000000D94268: D501001C 200A391C
	v_add_f32_e32 v27, v27, v46                                // 000000D94270: 06365D1B
	v_mov_b32_dpp v57, v20 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D94274: 7E7202FA FF016414
	v_cndmask_b32_e64 v20, -v20, v20, s2                       // 000000D9427C: D5010014 200A2914
	v_mov_b32_dpp v50, v17 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D94284: 7E6402FA FF016411
	v_cndmask_b32_e64 v17, -v17, v17, s2                       // 000000D9428C: D5010011 200A2311
	v_add_f32_e32 v28, v28, v47                                // 000000D94294: 06385F1C
	v_mov_b32_dpp v46, v27 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D94298: 7E5C02FA FF01681B
	v_cndmask_b32_e64 v27, -v27, v27, s3                       // 000000D942A0: D501001B 200E371B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D942A8: BF870214
	v_dual_add_f32 v20, v20, v57 :: v_dual_add_f32 v17, v17, v50// 000000D942AC: C9087314 14106511
	v_mov_b32_dpp v47, v28 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D942B4: 7E5E02FA FF01681C
	v_cndmask_b32_e64 v28, -v28, v28, s3                       // 000000D942BC: D501001C 200E391C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D942C4: BF870214
	v_add_f32_e32 v27, v27, v46                                // 000000D942C8: 06365D1B
	v_mov_b32_dpp v57, v20 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D942CC: 7E7202FA FF016814
	v_cndmask_b32_e64 v20, -v20, v20, s3                       // 000000D942D4: D5010014 200E2914
	v_mov_b32_dpp v50, v17 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D942DC: 7E6402FA FF016811
	v_cndmask_b32_e64 v17, -v17, v17, s3                       // 000000D942E4: D5010011 200E2311
	v_add_f32_e32 v28, v28, v47                                // 000000D942EC: 06385F1C
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000D942F0: BF870234
	v_dual_mul_f32 v27, 0x3db504f3, v27 :: v_dual_add_f32 v20, v20, v57// 000000D942F4: C8C836FF 1B147314 3DB504F3
	v_dual_mul_f32 v30, 0x3db504f3, v30 :: v_dual_mul_f32 v33, 0x3db504f3, v33// 000000D94300: C8C63CFF 1E2042FF 3DB504F3
	v_dual_mul_f32 v26, 0x3db504f3, v26 :: v_dual_mul_f32 v29, 0x3db504f3, v29// 000000D9430C: C8C634FF 1A1C3AFF 3DB504F3
	v_dual_add_f32 v17, v17, v50 :: v_dual_mul_f32 v28, 0x3db504f3, v28// 000000D94318: C9066511 111C38FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_1)                            // 000000D94324: BF870001
	v_mul_f32_e32 v17, 0x3db504f3, v17                         // 000000D94328: 102222FF 3DB504F3
	s_waitcnt vmcnt(23)                                        // 000000D94330: BF895FF7
	v_fma_mix_f32 v7, v7, v23, neg(0) op_sel_hi:[1,0,0]        // 000000D94334: CC200007 8A022F07
	s_waitcnt vmcnt(22)                                        // 000000D9433C: BF895BF7
	v_fma_mix_f32 v10, v10, v24, neg(0) op_sel_hi:[1,0,0]      // 000000D94340: CC20000A 8A02310A
	s_waitcnt vmcnt(21)                                        // 000000D94348: BF8957F7
	v_fma_mix_f32 v8, v8, v32, neg(0) op_sel_hi:[1,0,0]        // 000000D9434C: CC200008 8A024108
	s_waitcnt vmcnt(20)                                        // 000000D94354: BF8953F7
	v_fma_mix_f32 v9, v9, v30, neg(0) op_sel_hi:[1,0,0]        // 000000D94358: CC200009 8A023D09
	s_waitcnt vmcnt(19)                                        // 000000D94360: BF894FF7
	v_fma_mix_f32 v11, v11, v34, neg(0) op_sel_hi:[1,0,0]      // 000000D94364: CC20000B 8A02450B
	s_waitcnt vmcnt(18)                                        // 000000D9436C: BF894BF7
	v_fma_mix_f32 v12, v12, v33, neg(0) op_sel_hi:[1,0,0]      // 000000D94370: CC20000C 8A02430C
	s_waitcnt vmcnt(17)                                        // 000000D94378: BF8947F7
	v_fma_mix_f32 v5, v13, v5, neg(0) op_sel_hi:[1,0,0]        // 000000D9437C: CC200005 8A020B0D
	s_waitcnt vmcnt(16)                                        // 000000D94384: BF8943F7
	v_fma_mix_f32 v13, v14, v22, neg(0) op_sel_hi:[1,0,0]      // 000000D94388: CC20000D 8A022D0E
	v_mul_f32_e32 v22, 0xbfb8aa3b, v11                         // 000000D94390: 102C16FF BFB8AA3B
	s_waitcnt vmcnt(13)                                        // 000000D94398: BF8937F7
	v_fma_mix_f32 v18, v18, v26, neg(0) op_sel_hi:[1,0,0]      // 000000D9439C: CC200012 8A023512
	s_waitcnt vmcnt(12)                                        // 000000D943A4: BF8933F7
	v_fma_mix_f32 v19, v19, v27, neg(0) op_sel_hi:[1,0,0]      // 000000D943A8: CC200013 8A023713
	v_mul_f32_e32 v23, 0xbfb8aa3b, v13                         // 000000D943B0: 102E1AFF BFB8AA3B
	v_exp_f32_e32 v22, v22                                     // 000000D943B8: 7E2C4B16
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(TRANS32_DEP_1)// 000000D943BC: BF8702C1
	v_exp_f32_e32 v23, v23                                     // 000000D943C0: 7E2E4B17
	v_mul_f32_e32 v20, 0x3db504f3, v20                         // 000000D943C4: 102828FF 3DB504F3
	s_waitcnt vmcnt(8)                                         // 000000D943CC: BF8923F7
	v_fma_mix_f32 v2, v2, v17, neg(0) op_sel_hi:[1,0,0]        // 000000D943D0: CC200002 8A022302
	v_dual_add_f32 v22, 1.0, v22 :: v_dual_add_f32 v23, 1.0, v23// 000000D943D8: C9082CF2 16162EF2
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D943E0: BF870113
	v_fma_mix_f32 v14, v15, v20, neg(0) op_sel_hi:[1,0,0]      // 000000D943E4: CC20000E 8A02290F
	v_div_scale_f32 v35, null, v22, v22, v11                   // 000000D943EC: D6FC7C23 042E2D16
	v_fma_mix_f32 v15, v16, v21, neg(0) op_sel_hi:[1,0,0]      // 000000D943F4: CC20000F 8A022B10
	v_dual_mul_f32 v16, 0xbfb8aa3b, v9 :: v_dual_mul_f32 v21, 0xbfb8aa3b, v12// 000000D943FC: C8C612FF 101418FF BFB8AA3B
	v_div_scale_f32 v49, null, v23, v23, v13                   // 000000D94408: D6FC7C31 04362F17
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D94410: BF870194
	v_rcp_f32_e32 v55, v35                                     // 000000D94414: 7E6E5523
	v_mul_f32_e32 v30, 0xbfb8aa3b, v15                         // 000000D94418: 103C1EFF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_3)                            // 000000D94420: BF870003
	v_exp_f32_e32 v16, v16                                     // 000000D94424: 7E204B10
	v_exp_f32_e32 v21, v21                                     // 000000D94428: 7E2A4B15
	v_div_scale_f32 v44, s5, v11, v22, v11                     // 000000D9442C: D6FC052C 042E2D0B
	v_rcp_f32_e32 v58, v49                                     // 000000D94434: 7E745531
	v_exp_f32_e32 v30, v30                                     // 000000D94438: 7E3C4B1E
	v_mul_f32_e32 v20, 0xbfb8aa3b, v8                          // 000000D9443C: 102810FF BFB8AA3B
	v_div_scale_f32 v50, s8, v13, v23, v13                     // 000000D94444: D6FC0832 04362F0D
	v_fma_f32 v65, -v35, v55, 1.0                              // 000000D9444C: D6130041 23CA6F23
	v_mul_f32_e32 v24, 0xbfb8aa3b, v5                          // 000000D94454: 10300AFF BFB8AA3B
	s_delay_alu instid0(TRANS32_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 000000D9445C: BF870317
	v_add_f32_e32 v21, 1.0, v21                                // 000000D94460: 062A2AF2
	v_fma_f32 v68, -v49, v58, 1.0                              // 000000D94464: D6130044 23CA7531
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D9446C: BF870214
	v_fmac_f32_e32 v55, v65, v55                               // 000000D94470: 566E6F41
	v_exp_f32_e32 v24, v24                                     // 000000D94474: 7E304B18
	s_delay_alu instid0(TRANS32_DEP_2)                         // 000000D94478: BF870006
	v_add_f32_e32 v27, 1.0, v30                                // 000000D9447C: 06363CF2
	v_exp_f32_e32 v20, v20                                     // 000000D94480: 7E284B14
	v_div_scale_f32 v45, null, v21, v21, v12                   // 000000D94484: D6FC7C2D 04322B15
	v_mul_f32_e32 v65, v44, v55                                // 000000D9448C: 10826F2C
	v_div_scale_f32 v46, s6, v12, v21, v12                     // 000000D94490: D6FC062E 04322B0C
	v_div_scale_f32 v52, null, v27, v27, v15                   // 000000D94498: D6FC7C34 043E371B
	v_div_scale_f32 v62, s10, v15, v27, v15                    // 000000D944A0: D6FC0A3E 043E370F
	v_rcp_f32_e32 v56, v45                                     // 000000D944A8: 7E70552D
	v_fma_f32 v73, -v35, v65, v44                              // 000000D944AC: D6130049 24B28323
	v_add_f32_e32 v24, 1.0, v24                                // 000000D944B4: 063030F2
	v_rcp_f32_e32 v60, v52                                     // 000000D944B8: 7E785534
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D944BC: BF870112
	v_fmac_f32_e32 v65, v73, v55                               // 000000D944C0: 56826F49
	v_div_scale_f32 v47, null, v24, v24, v5                    // 000000D944C4: D6FC7C2F 04163118
	v_div_scale_f32 v48, s7, v5, v24, v5                       // 000000D944CC: D6FC0730 04163105
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D944D4: BF870196
	v_fma_f32 v66, -v45, v56, 1.0                              // 000000D944D8: D6130042 23CA712D
	v_rcp_f32_e32 v57, v47                                     // 000000D944E0: 7E72552F
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D944E4: BF870116
	v_fma_f32 v70, -v52, v60, 1.0                              // 000000D944E8: D6130046 23CA7934
	v_fmac_f32_e32 v56, v66, v56                               // 000000D944F0: 56707142
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000D944F4: BF870291
	v_mul_f32_e32 v66, v46, v56                                // 000000D944F8: 1084712E
	v_fma_f32 v67, -v47, v57, 1.0                              // 000000D944FC: D6130043 23CA732F
	v_mul_f32_e32 v32, 0xbfb8aa3b, v14                         // 000000D94504: 10401CFF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D9450C: BF870193
	v_fma_f32 v74, -v45, v66, v46                              // 000000D94510: D613004A 24BA852D
	v_fmac_f32_e32 v57, v67, v57                               // 000000D94518: 56727343
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D9451C: BF870093
	v_exp_f32_e32 v32, v32                                     // 000000D94520: 7E404B20
	v_dual_fmac_f32 v66, v74, v56 :: v_dual_mul_f32 v67, v48, v57// 000000D94524: C806714A 42427330
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000D9452C: BF870291
	v_fma_f32 v75, -v47, v67, v48                              // 000000D94530: D613004B 24C2872F
	v_add_f32_e32 v26, 1.0, v32                                // 000000D94538: 063440F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D9453C: BF870112
	v_dual_fmac_f32 v58, v68, v58 :: v_dual_fmac_f32 v67, v75, v57// 000000D94540: C8007544 3A42734B
	v_div_scale_f32 v51, null, v26, v26, v14                   // 000000D94548: D6FC7C33 043A351A
	v_div_scale_f32 v61, s9, v14, v26, v14                     // 000000D94550: D6FC093D 043A350E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D94558: BF870193
	v_mul_f32_e32 v68, v50, v58                                // 000000D9455C: 10887532
	v_rcp_f32_e32 v59, v51                                     // 000000D94560: 7E765533
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000D94564: BF870291
	v_fma_f32 v76, -v49, v68, v50                              // 000000D94568: D613004C 24CA8931
	v_fma_f32 v69, -v51, v59, 1.0                              // 000000D94570: D6130045 23CA7733
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D94578: BF870091
	v_dual_add_f32 v20, 1.0, v20 :: v_dual_fmac_f32 v59, v69, v59// 000000D9457C: C90028F2 143A7745
	v_div_scale_f32 v30, null, v20, v20, v8                    // 000000D94584: D6FC7C1E 04222914
	v_div_scale_f32 v32, vcc_lo, v8, v20, v8                   // 000000D9458C: D6FC6A20 04222908
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D94594: BF870193
	v_mul_f32_e32 v69, v61, v59                                // 000000D94598: 108A773D
	v_rcp_f32_e32 v53, v30                                     // 000000D9459C: 7E6A551E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D945A0: BF870091
	v_fma_f32 v77, -v51, v69, v61                              // 000000D945A4: D613004D 24F68B33
	v_dual_fmac_f32 v60, v70, v60 :: v_dual_fmac_f32 v69, v77, v59// 000000D945AC: C8007946 3C44774D
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D945B4: BF870095
	v_fma_f32 v63, -v30, v53, 1.0                              // 000000D945B8: D613003F 23CA6B1E
	v_dual_mul_f32 v70, v62, v60 :: v_dual_fmac_f32 v53, v63, v53// 000000D945C0: C8C0793E 46346B3F
	v_add_f32_e32 v16, 1.0, v16                                // 000000D945C8: 062020F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D945CC: BF870192
	v_fma_f32 v78, -v52, v70, v62                              // 000000D945D0: D613004E 24FA8D34
	v_mul_f32_e32 v63, v32, v53                                // 000000D945D8: 107E6B20
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D945DC: BF870223
	v_div_scale_f32 v33, null, v16, v16, v9                    // 000000D945E0: D6FC7C21 04262110
	v_div_scale_f32 v34, s4, v9, v16, v9                       // 000000D945E8: D6FC0422 04262109
	v_fmac_f32_e32 v70, v78, v60                               // 000000D945F0: 568C794E
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D945F4: BF870214
	v_fma_f32 v71, -v30, v63, v32                              // 000000D945F8: D6130047 24827F1E
	v_rcp_f32_e32 v54, v33                                     // 000000D94600: 7E6C5521
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D94604: BF870091
	v_fmac_f32_e32 v63, v71, v53                               // 000000D94608: 567E6B47
	v_fma_f32 v30, -v30, v63, v32                              // 000000D9460C: D613001E 24827F1E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D94614: BF870115
	v_fma_f32 v64, -v33, v54, 1.0                              // 000000D94618: D6130040 23CA6D21
	v_div_fmas_f32 v30, v30, v53, v63                          // 000000D94620: D637001E 04FE6B1E
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000D94628: BF870122
	v_fmac_f32_e32 v54, v64, v54                               // 000000D9462C: 566C6D40
	s_mov_b32 vcc_lo, s4                                       // 000000D94630: BEEA0004
	v_div_fixup_f32 v8, v30, v20, v8                           // 000000D94634: D6270008 0422291E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D9463C: BF870091
	v_dual_mul_f32 v64, v34, v54 :: v_dual_mul_f32 v7, v7, v8  // 000000D94640: C8C66D22 40061107
	v_fma_f32 v72, -v33, v64, v34                              // 000000D94648: D6130048 248A8121
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D94650: BF870091
	v_fmac_f32_e32 v64, v72, v54                               // 000000D94654: 56806D48
	v_fma_f32 v32, -v33, v64, v34                              // 000000D94658: D6130020 248A8121
	v_fma_f32 v33, -v35, v65, v44                              // 000000D94660: D6130021 24B28323
	v_fma_f32 v34, -v45, v66, v46                              // 000000D94668: D6130022 24BA852D
	v_fma_f32 v35, -v47, v67, v48                              // 000000D94670: D6130023 24C2872F
	v_fma_f32 v45, -v51, v69, v61                              // 000000D94678: D613002D 24F68B33
	v_div_fmas_f32 v32, v32, v54, v64                          // 000000D94680: D6370020 05026D20
	s_mov_b32 vcc_lo, s5                                       // 000000D94688: BEEA0005
	v_div_fmas_f32 v33, v33, v55, v65                          // 000000D9468C: D6370021 05066F21
	s_mov_b32 vcc_lo, s6                                       // 000000D94694: BEEA0006
	s_delay_alu instid0(VALU_DEP_2)                            // 000000D94698: BF870002
	v_div_fixup_f32 v9, v32, v16, v9                           // 000000D9469C: D6270009 04262120
	v_div_fmas_f32 v20, v34, v56, v66                          // 000000D946A4: D6370014 050A7122
	s_mov_b32 vcc_lo, s7                                       // 000000D946AC: BEEA0007
	v_div_fixup_f32 v11, v33, v22, v11                         // 000000D946B0: D627000B 042E2D21
	v_fmac_f32_e32 v68, v76, v58                               // 000000D946B8: 5688754C
	v_div_fmas_f32 v16, v35, v57, v67                          // 000000D946BC: D6370010 050E7323
	s_mov_b32 vcc_lo, s8                                       // 000000D946C4: BEEA0008
	v_div_fixup_f32 v8, v20, v21, v12                          // 000000D946C8: D6270008 04322B14
	v_fma_f32 v12, -v52, v70, v62                              // 000000D946D0: D613000C 24FA8D34
	v_mul_f32_e32 v9, v10, v9                                  // 000000D946D8: 1012130A
	v_div_fixup_f32 v5, v16, v24, v5                           // 000000D946DC: D6270005 04163110
	v_mul_f32_e32 v11, v18, v11                                // 000000D946E4: 10161712
	v_fma_f32 v44, -v49, v68, v50                              // 000000D946E8: D613002C 24CA8931
	s_waitcnt vmcnt(6)                                         // 000000D946F0: BF891BF7
	v_fma_mix_f32 v9, v38, v9, neg(0) op_sel_hi:[1,0,0]        // 000000D946F4: CC200009 8A021326
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000D946FC: BF870142
	v_div_fmas_f32 v10, v44, v58, v68                          // 000000D94700: D637000A 0512752C
	s_mov_b32 vcc_lo, s9                                       // 000000D94708: BEEA0009
	v_div_fmas_f32 v18, v45, v59, v69                          // 000000D9470C: D6370012 0516772D
	s_mov_b32 vcc_lo, s10                                      // 000000D94714: BEEA000A
	v_div_fixup_f32 v10, v10, v23, v13                         // 000000D94718: D627000A 04362F0A
	v_div_fmas_f32 v12, v12, v60, v70                          // 000000D94720: D637000C 051A790C
	v_fma_mix_f32 v13, v25, v28, neg(0) op_sel_hi:[1,0,0]      // 000000D94728: CC20000D 8A023919
	v_div_fixup_f32 v14, v18, v26, v14                         // 000000D94730: D627000E 043A3512
	v_cmp_gt_i32_e32 vcc_lo, s23, v6                           // 000000D94738: 7C880C17
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000D9473C: BF870124
	v_div_fixup_f32 v12, v12, v27, v15                         // 000000D94740: D627000C 043E370C
	v_fma_mix_f32 v15, v37, v29, neg(0) op_sel_hi:[1,0,0]      // 000000D94748: CC20000F 8A023B25
	v_dual_mul_f32 v5, v13, v5 :: v_dual_mul_f32 v2, v2, v12   // 000000D94750: C8C60B0D 05021902
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000D94758: BF870122
	v_mul_f32_e32 v12, v15, v14                                // 000000D9475C: 10181D0F
	s_waitcnt vmcnt(0)                                         // 000000D94760: BF8903F7
	v_fma_mix_f32 v2, v4, v2, neg(0) op_sel_hi:[1,0,0]         // 000000D94764: CC200002 8A020504
	v_fma_mix_f32 v4, v7, v3, v9 op_sel_hi:[0,1,0]             // 000000D9476C: CC200004 14260707
	v_fma_mix_f32 v3, v7, v3, -v9 op_sel_hi:[0,1,0]            // 000000D94774: CC200003 94260707
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000D9477C: BF870143
	v_fma_mix_f32 v15, v12, v43, v2 op_sel_hi:[0,1,0]          // 000000D94780: CC20000F 140A570C
	v_mul_f32_e32 v8, v19, v8                                  // 000000D94788: 10101113
	v_fma_mix_f32 v19, v36, v31, neg(0) op_sel_hi:[1,0,0]      // 000000D9478C: CC200013 8A023F24
	v_fma_mix_f32 v2, v12, v43, -v2 op_sel_hi:[0,1,0]          // 000000D94794: CC200002 940A570C
	v_mul_f32_e32 v10, v19, v10                                // 000000D9479C: 10141513
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D947A0: BF870091
	v_fma_mix_f32 v10, v42, v10, neg(0) op_sel_hi:[1,0,0]      // 000000D947A4: CC20000A 8A02152A
	v_fma_mix_f32 v14, v5, v41, v10 op_sel_hi:[0,1,0]          // 000000D947AC: CC20000E 142A5305
	v_fma_mix_f32 v5, v5, v41, -v10 op_sel_hi:[0,1,0]          // 000000D947B4: CC200005 942A5305
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000D947BC: BF8700A2
	v_add_f32_e32 v17, v14, v15                                // 000000D947C0: 06221F0E
	v_fma_mix_f32 v8, v40, v8, neg(0) op_sel_hi:[1,0,0]        // 000000D947C4: CC200008 8A021128
	v_fma_mix_f32 v13, v11, v39, v8 op_sel_hi:[0,1,0]          // 000000D947CC: CC20000D 14224F0B
	v_fma_mix_f32 v7, v11, v39, -v8 op_sel_hi:[0,1,0]          // 000000D947D4: CC200007 94224F0B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D947DC: BF870112
	v_dual_sub_f32 v11, v14, v15 :: v_dual_add_f32 v16, v4, v13// 000000D947E0: C9481F0E 0B101B04
	v_add_f32_e32 v9, v3, v7                                   // 000000D947E8: 06120F03
	v_sub_f32_e32 v3, v3, v7                                   // 000000D947EC: 08060F03
	v_add_f32_e32 v7, v5, v2                                   // 000000D947F0: 060E0505
	v_sub_f32_e32 v2, v5, v2                                   // 000000D947F4: 08040505
	v_add_f32_e32 v8, v16, v17                                 // 000000D947F8: 06102310
	v_sub_f32_e32 v4, v4, v13                                  // 000000D947FC: 08081B04
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000D94800: BF8700A2
	v_mov_b32_dpp v10, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D94804: 7E1402FA FF016108
	v_cndmask_b32_e64 v8, -v8, v8, s0                          // 000000D9480C: D5010008 20021108
	v_dual_add_f32 v5, v8, v10 :: v_dual_add_f32 v10, v9, v7   // 000000D94814: C9081508 050A0F09
	v_sub_f32_e32 v9, v9, v7                                   // 000000D9481C: 08120F09
	v_add_f32_e32 v7, v4, v11                                  // 000000D94820: 060E1704
	v_sub_f32_e32 v11, v4, v11                                 // 000000D94824: 08161704
	s_delay_alu instid0(VALU_DEP_4)                            // 000000D94828: BF870004
	v_mov_b32_dpp v12, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D9482C: 7E1802FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, s1                          // 000000D94834: D5010005 20060B05
	v_mov_b32_dpp v13, v10 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D9483C: 7E1A02FA FF01610A
	v_cndmask_b32_e64 v10, -v10, v10, s0                       // 000000D94844: D501000A 2002150A
	v_mov_b32_dpp v14, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D9484C: 7E1C02FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, s0                          // 000000D94854: D5010007 20020F07
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000D9485C: BF8701A3
	v_dual_add_f32 v5, v5, v12 :: v_dual_add_f32 v4, v10, v13  // 000000D94860: C9081905 05041B0A
	v_add_f32_e32 v10, v3, v2                                  // 000000D94868: 06140503
	v_add_f32_e32 v7, v7, v14                                  // 000000D9486C: 060E1D07
	s_delay_alu instid0(VALU_DEP_3)                            // 000000D94870: BF870003
	v_mov_b32_dpp v12, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D94874: 7E1802FA FF016405
	v_cndmask_b32_e64 v5, -v5, v5, s2                          // 000000D9487C: D5010005 200A0B05
	v_mov_b32_dpp v13, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D94884: 7E1A02FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, s1                          // 000000D9488C: D5010004 20060904
	v_mov_b32_dpp v14, v7 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D94894: 7E1C02FA FF016207
	v_cndmask_b32_e64 v7, -v7, v7, s1                          // 000000D9489C: D5010007 20060F07
	v_mov_b32_dpp v15, v10 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D948A4: 7E1E02FA FF01610A
	v_cndmask_b32_e64 v10, -v10, v10, s0                       // 000000D948AC: D501000A 2002150A
	v_sub_f32_e32 v8, v16, v17                                 // 000000D948B4: 08102310
	v_dual_add_f32 v4, v4, v13 :: v_dual_sub_f32 v13, v3, v2   // 000000D948B8: C90A1B04 040C0503
	v_dual_add_f32 v3, v7, v14 :: v_dual_add_f32 v2, v5, v12   // 000000D948C0: C9081D07 03021905
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D948C8: BF870194
	v_add_f32_e32 v5, v10, v15                                 // 000000D948CC: 060A1F0A
	v_mov_b32_dpp v7, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D948D0: 7E0E02FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s2                          // 000000D948D8: D5010004 200A0904
	s_delay_alu instid0(VALU_DEP_4)                            // 000000D948E0: BF870004
	v_mov_b32_dpp v10, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D948E4: 7E1402FA FF016403
	v_cndmask_b32_e64 v3, -v3, v3, s2                          // 000000D948EC: D5010003 200A0703
	v_mov_b32_dpp v12, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D948F4: 7E1802FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, s1                          // 000000D948FC: D5010005 20060B05
	v_mov_b32_dpp v14, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D94904: 7E1C02FA FF016108
	v_cndmask_b32_e64 v8, -v8, v8, s0                          // 000000D9490C: D5010008 20021108
	v_dual_add_f32 v4, v4, v7 :: v_dual_add_f32 v7, v3, v10    // 000000D94914: C9080F04 04061503
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D9491C: BF870224
	v_add_f32_e32 v10, v5, v12                                 // 000000D94920: 06141905
	v_mov_b32_dpp v16, v9 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D94924: 7E2002FA FF016109
	v_add_f32_e32 v12, v8, v14                                 // 000000D9492C: 06181D08
	v_cndmask_b32_e64 v9, -v9, v9, s0                          // 000000D94930: D5010009 20021309
	v_mov_b32_dpp v17, v11 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D94938: 7E2202FA FF01610B
	v_mov_b32_dpp v14, v10 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D94940: 7E1C02FA FF01640A
	v_cndmask_b32_e64 v10, -v10, v10, s2                       // 000000D94948: D501000A 200A150A
	v_mov_b32_dpp v15, v12 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D94950: 7E1E02FA FF01620C
	v_cndmask_b32_e64 v12, -v12, v12, s1                       // 000000D94958: D501000C 2006190C
	v_cndmask_b32_e64 v11, -v11, v11, s0                       // 000000D94960: D501000B 2002170B
	v_mov_b32_dpp v18, v13 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D94968: 7E2402FA FF01610D
	v_cndmask_b32_e64 v13, -v13, v13, s0                       // 000000D94970: D501000D 20021B0D
	v_dual_add_f32 v16, v9, v16 :: v_dual_add_f32 v9, v10, v14 // 000000D94978: C9082109 10081D0A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D94980: BF870194
	v_dual_add_f32 v10, v11, v17 :: v_dual_add_f32 v11, v12, v15// 000000D94984: C908230B 0A0A1F0C
	v_add_f32_e32 v12, v13, v18                                // 000000D9498C: 0618250D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D94990: BF870223
	v_mov_b32_dpp v13, v16 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D94994: 7E1A02FA FF016210
	v_cndmask_b32_e64 v14, -v16, v16, s1                       // 000000D9499C: D501000E 20062110
	v_mov_b32_dpp v15, v10 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D949A4: 7E1E02FA FF01620A
	v_cndmask_b32_e64 v10, -v10, v10, s1                       // 000000D949AC: D501000A 2006150A
	v_mov_b32_dpp v16, v12 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D949B4: 7E2002FA FF01620C
	v_cndmask_b32_e64 v12, -v12, v12, s1                       // 000000D949BC: D501000C 2006190C
	v_add_f32_e32 v13, v14, v13                                // 000000D949C4: 061A1B0E
	v_mov_b32_dpp v14, v11 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D949C8: 7E1C02FA FF01640B
	v_add_f32_e32 v10, v10, v15                                // 000000D949D0: 06141F0A
	v_cndmask_b32_e64 v11, -v11, v11, s2                       // 000000D949D4: D501000B 200A170B
	v_add_f32_e32 v12, v12, v16                                // 000000D949DC: 0618210C
	v_mov_b32_dpp v15, v13 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D949E0: 7E1E02FA FF01640D
	v_cndmask_b32_e64 v13, -v13, v13, s2                       // 000000D949E8: D501000D 200A1B0D
	v_mov_b32_dpp v16, v10 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D949F0: 7E2002FA FF01640A
	v_cndmask_b32_e64 v17, -v10, v10, s2                       // 000000D949F8: D5010011 200A150A
	v_mov_b32_dpp v18, v12 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D94A00: 7E2402FA FF01640C
	v_cndmask_b32_e64 v19, -v12, v12, s2                       // 000000D94A08: D5010013 200A190C
	v_dual_add_f32 v12, v11, v14 :: v_dual_add_f32 v13, v13, v15// 000000D94A10: C9081D0B 0C0C1F0D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D94A18: BF870224
	v_add_f32_e32 v15, v17, v16                                // 000000D94A1C: 061E2111
	v_mov_b32_dpp v3, v2 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D94A20: 7E0602FA FF016802
	v_add_f32_e32 v17, v19, v18                                // 000000D94A28: 06222513
	v_mov_b32_dpp v5, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D94A2C: 7E0A02FA FF016804
	v_mov_b32_dpp v8, v7 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D94A34: 7E1002FA FF016807
	v_mov_b32_dpp v10, v9 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D94A3C: 7E1402FA FF016809
	v_mov_b32_dpp v11, v12 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D94A44: 7E1602FA FF01680C
	v_mov_b32_dpp v14, v13 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D94A4C: 7E1C02FA FF01680D
	v_mov_b32_dpp v16, v15 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D94A54: 7E2002FA FF01680F
	v_mov_b32_dpp v18, v17 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D94A5C: 7E2402FA FF016811
	s_and_b32 exec_lo, exec_lo, vcc_lo                         // 000000D94A64: 8B7E6A7E
	s_cbranch_execz 62                                         // 000000D94A68: BFA5003E <_ZN7halogen12_GLOBAL__N_111k_ht_moe_guILi3ELi8ELi1EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_S5_PDF16_+0x8864>
	v_cndmask_b32_e64 v17, -v17, v17, s3                       // 000000D94A6C: D5010011 200E2311
	v_cndmask_b32_e64 v2, -v2, v2, s3                          // 000000D94A74: D5010002 200E0502
	v_cndmask_b32_e64 v4, -v4, v4, s3                          // 000000D94A7C: D5010004 200E0904
	v_cndmask_b32_e64 v7, -v7, v7, s3                          // 000000D94A84: D5010007 200E0F07
	v_cndmask_b32_e64 v9, -v9, v9, s3                          // 000000D94A8C: D5010009 200E1309
	v_cndmask_b32_e64 v12, -v12, v12, s3                       // 000000D94A94: D501000C 200E190C
	v_cndmask_b32_e64 v15, -v15, v15, s3                       // 000000D94A9C: D501000F 200E1F0F
	v_cndmask_b32_e64 v13, -v13, v13, s3                       // 000000D94AA4: D501000D 200E1B0D
	v_dual_add_f32 v17, v17, v18 :: v_dual_add_f32 v2, v2, v3  // 000000D94AAC: C9082511 11020702
	v_add_f32_e32 v3, v4, v5                                   // 000000D94AB4: 06060B04
	v_add_f32_e32 v7, v7, v8                                   // 000000D94AB8: 060E1107
	v_mad_i64_i32 v[4:5], null, 0x500, v6, v[0:1]              // 000000D94ABC: D6FF7C04 04020CFF 00000500
	v_add_f32_e32 v9, v9, v10                                  // 000000D94AC8: 06121509
	s_mov_b32 s0, 0x3db504f3                                   // 000000D94ACC: BE8000FF 3DB504F3
	v_add_f32_e32 v11, v12, v11                                // 000000D94AD4: 0616170C
	v_add_f32_e32 v15, v15, v16                                // 000000D94AD8: 061E210F
	v_add_f32_e32 v13, v13, v14                                // 000000D94ADC: 061A1D0D
	v_fma_mixlo_f16 v0, v2, s0, 0                              // 000000D94AE0: CC210000 02000102
	v_fma_mixhi_f16 v0, v3, s0, 0                              // 000000D94AE8: CC220000 02000103
	v_fma_mixlo_f16 v1, v7, s0, 0                              // 000000D94AF0: CC210001 02000107
	v_fma_mixhi_f16 v1, v9, s0, 0                              // 000000D94AF8: CC220001 02000109
	v_fma_mixlo_f16 v2, v11, s0, 0                             // 000000D94B00: CC210002 0200010B
	v_fma_mixhi_f16 v2, v13, s0, 0                             // 000000D94B08: CC220002 0200010D
	v_fma_mixlo_f16 v3, v15, s0, 0                             // 000000D94B10: CC210003 0200010F
	v_fma_mixhi_f16 v3, v17, s0, 0                             // 000000D94B18: CC220003 02000111
	s_clause 0x7                                               // 000000D94B20: BF850007
	global_store_b16 v[4:5], v0, off                           // 000000D94B24: DC660000 007C0004
	global_store_d16_hi_b16 v[4:5], v0, off offset:32          // 000000D94B2C: DC960020 007C0004
	global_store_b16 v[4:5], v1, off offset:64                 // 000000D94B34: DC660040 007C0104
	global_store_d16_hi_b16 v[4:5], v1, off offset:96          // 000000D94B3C: DC960060 007C0104
	global_store_b16 v[4:5], v2, off offset:128                // 000000D94B44: DC660080 007C0204
	global_store_d16_hi_b16 v[4:5], v2, off offset:160         // 000000D94B4C: DC9600A0 007C0204
	global_store_b16 v[4:5], v3, off offset:192                // 000000D94B54: DC6600C0 007C0304
	global_store_d16_hi_b16 v[4:5], v3, off offset:224         // 000000D94B5C: DC9600E0 007C0304
	s_nop 0                                                    // 000000D94B64: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 000000D94B68: BFB60003
	s_endpgm                                                   // 000000D94B6C: BFB00000
		...

