00000000007c0900 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[8:23], s[0:1], null                          // 0000007C0900: F4100200 F8000000
	v_and_b32_e32 v1, 15, v0                                   // 0000007C0908: 3602008F
	v_lshrrev_b32_e32 v2, 2, v0                                // 0000007C090C: 32040082
	s_ashr_i32 s3, s2, 31                                      // 0000007C0910: 86039F02
	v_lshrrev_b32_e32 v3, 5, v0                                // 0000007C0914: 32060085
	s_lshl_b64 s[2:3], s[2:3], 3                               // 0000007C0918: 84828302
	v_lshlrev_b32_e32 v1, 2, v1                                // 0000007C091C: 30020282
	v_dual_mov_b32 v17, s3 :: v_dual_and_b32 v2, 60, v2        // 0000007C0920: CA240003 110204BC
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007C0928: BF870003
	v_or_b32_e32 v16, s2, v3                                   // 0000007C092C: 38200602
	.long 0x7f063880                                           // 0000007C0930: 7F063880
	v_and_b32_e32 v23, 31, v0                                  // 0000007C0934: 362E009F
	v_lshlrev_b32_e32 v0, 2, v0                                // 0000007C0938: 30000082
	s_waitcnt lgkmcnt(0)                                       // 0000007C093C: BF89FC07
	s_clause 0x1                                               // 0000007C0940: BF850001
	global_load_b32 v1, v1, s[8:9]                             // 0000007C0944: DC520000 01080001
	global_load_b32 v2, v2, s[8:9]                             // 0000007C094C: DC520000 02080002
	.long 0xd4540002                                           // 0000007C0954: D4540002
	v_cndmask_b32_e32 v1, s16, v16, vcc_lo                     // 0000007C0958: 02022010
	s_add_u32 s24, s8, s20                                     // 0000007C095C: 80181408
	s_addc_u32 s25, s9, s21                                    // 0000007C0960: 82191509
	s_ashr_i32 s4, s15, 31                                     // 0000007C0964: 86049F0F
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 0000007C0968: BF870159
	s_lshr_b32 s4, s4, 27                                      // 0000007C096C: 85049B04
	v_cndmask_b32_e64 v8, 0, v16, s2                           // 0000007C0970: D5010008 000A2080
	v_cndmask_b32_e64 v9, 0, s3, s2                            // 0000007C0978: D5010009 00080680
	s_add_u32 s4, s14, s4                                      // 0000007C0980: 8004040E
	s_addc_u32 s5, s15, 0                                      // 0000007C0984: 8205800F
	.long 0xd72c0004                                           // 0000007C0988: D72C0004
	v_cndmask_b32_e32 v1, s23, v8, vcc_lo                      // 0000007C098C: 02021017
	v_mad_u64_u32 v[12:13], null, s22, v8, 0                   // 0000007C0990: D6FE7C0C 02021016
	s_lshr_b64 s[6:7], s[4:5], 5                               // 0000007C0998: 85868504
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000007C099C: BF870009
	s_cmpk_lt_i32 s6, 0x101                                    // 0000007C09A0: B3860101
	.long 0xd4440004                                           // 0000007C09A4: D4440004
	v_cndmask_b32_e32 v1, s6, v23, vcc_lo                      // 0000007C09A8: 02022E06
	s_cselect_b32 s3, -1, 0                                    // 0000007C09AC: 980380C1
	s_cmpk_gt_i32 s6, 0x100                                    // 0000007C09B0: B2860100
	.long 0xd700050e                                           // 0000007C09B4: D700050E
	v_cndmask_b32_e32 v1, s24, v12, vcc_lo                     // 0000007C09B8: 02021818
	s_cselect_b32 s7, -1, 0                                    // 0000007C09BC: 980780C1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 0000007C09C0: BF870159
	s_and_b32 vcc_lo, exec_lo, s7                              // 0000007C09C4: 8B6A077E
	s_waitcnt vmcnt(1)                                         // 0000007C09C8: BF8907F7
	v_bfe_u32 v5, v1, 16, 1                                    // 0000007C09CC: D6100005 02052101
	s_waitcnt vmcnt(0)                                         // 0000007C09D4: BF8903F7
	v_bfe_u32 v6, v2, 16, 1                                    // 0000007C09D8: D6100006 02052102
	v_add3_u32 v1, v1, v5, 0x7fff                              // 0000007C09E0: D6550001 03FE0B01 00007FFF
	.long 0xd72c0005                                           // 0000007C09EC: D72C0005
	v_cndmask_b32_e32 v1, s22, v9, vcc_lo                      // 0000007C09F0: 02021216
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007C09F4: BF870193
	v_add3_u32 v2, v2, v6, 0x7fff                              // 0000007C09F8: D6550002 03FE0D02 00007FFF
	.long 0x7e063981                                           // 0000007C0A04: 7E063981
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007C0A08: BF870113
	v_add3_u32 v13, v13, v5, v4                                // 0000007C0A0C: D655000D 04120B0D
	v_and_or_b32 v1, 0xffff0000, v2, v3                        // 0000007C0A14: D6570001 040E04FF FFFF0000
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007C0A20: BF870002
	v_add_co_ci_u32_e64 v15, null, s25, v13, s5                // 0000007C0A24: D5207C0F 00161A19
	ds_store_b32 v0, v1                                        // 0000007C0A2C: D8340000 00000100
	s_waitcnt lgkmcnt(0)                                       // 0000007C0A34: BF89FC07
	s_barrier                                                  // 0000007C0A38: BFBD0000
	buffer_gl0_inv                                             // 0000007C0A3C: E0AC0000 00000000
	s_cbranch_vccnz 146                                        // 0000007C0A44: BFA40092 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x390>
	v_dual_mov_b32 v1, 0 :: v_dual_mov_b32 v0, 0               // 0000007C0A48: CA100080 01000080
	s_and_saveexec_b32 s5, s4                                  // 0000007C0A50: BE852004
	s_cbranch_execz 10                                         // 0000007C0A54: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x180>
	v_lshlrev_b32_e32 v0, 1, v23                               // 0000007C0A58: 30002E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007C0A5C: BF870091
	.long 0xd7006a02                                           // 0000007C0A60: D7006A02
	v_cndmask_b32_e32 v1, v14, v0, vcc_lo                      // 0000007C0A64: 0202010E
	v_add_co_ci_u32_e64 v3, null, 0, v15, vcc_lo               // 0000007C0A68: D5207C03 01AA1E80
	global_load_d16_b16 v0, v[2:3], off                        // 0000007C0A70: DC820000 007C0002
	s_waitcnt vmcnt(0)                                         // 0000007C0A78: BF8903F7
	v_cvt_f32_f16_e32 v0, v0                                   // 0000007C0A7C: 7E001700
	s_or_b32 exec_lo, exec_lo, s5                              // 0000007C0A80: 8C7E057E
	v_or_b32_e32 v2, 32, v23                                   // 0000007C0A84: 38042EA0
	s_mov_b32 s4, exec_lo                                      // 0000007C0A88: BE84007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007C0A8C: BF870001
	.long 0xd4c4007e                                           // 0000007C0A90: D4C4007E
	v_cndmask_b32_e32 v1, s6, v2, vcc_lo                       // 0000007C0A94: 02020406
	s_cbranch_execz 10                                         // 0000007C0A98: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x1c4>
	v_lshlrev_b32_e32 v1, 1, v2                                // 0000007C0A9C: 30020481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007C0AA0: BF870091
	.long 0xd7006a01                                           // 0000007C0AA4: D7006A01
	v_cndmask_b32_e32 v1, v14, v1, vcc_lo                      // 0000007C0AA8: 0202030E
	v_add_co_ci_u32_e64 v2, null, 0, v15, vcc_lo               // 0000007C0AAC: D5207C02 01AA1E80
	global_load_d16_b16 v1, v[1:2], off                        // 0000007C0AB4: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 0000007C0ABC: BF8903F7
	v_cvt_f32_f16_e32 v1, v1                                   // 0000007C0AC0: 7E021701
	s_or_b32 exec_lo, exec_lo, s4                              // 0000007C0AC4: 8C7E047E
	v_or_b32_e32 v4, 64, v23                                   // 0000007C0AC8: 38082EC0
	v_dual_mov_b32 v3, 0 :: v_dual_mov_b32 v2, 0               // 0000007C0ACC: CA100080 03020080
	s_mov_b32 s4, exec_lo                                      // 0000007C0AD4: BE84007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007C0AD8: BF870002
	.long 0xd4c4007e                                           // 0000007C0ADC: D4C4007E
	v_cndmask_b32_e32 v1, s6, v4, vcc_lo                       // 0000007C0AE0: 02020806
	s_cbranch_execz 10                                         // 0000007C0AE4: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x210>
	v_lshlrev_b32_e32 v2, 1, v4                                // 0000007C0AE8: 30040881
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007C0AEC: BF870091
	.long 0xd7006a04                                           // 0000007C0AF0: D7006A04
	v_cndmask_b32_e32 v1, v14, v2, vcc_lo                      // 0000007C0AF4: 0202050E
	v_add_co_ci_u32_e64 v5, null, 0, v15, vcc_lo               // 0000007C0AF8: D5207C05 01AA1E80
	global_load_d16_b16 v2, v[4:5], off                        // 0000007C0B00: DC820000 027C0004
	s_waitcnt vmcnt(0)                                         // 0000007C0B08: BF8903F7
	v_cvt_f32_f16_e32 v2, v2                                   // 0000007C0B0C: 7E041702
	s_or_b32 exec_lo, exec_lo, s4                              // 0000007C0B10: 8C7E047E
	v_or_b32_e32 v4, 0x60, v23                                 // 0000007C0B14: 38082EFF 00000060
	s_mov_b32 s4, exec_lo                                      // 0000007C0B1C: BE84007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007C0B20: BF870001
	.long 0xd4c4007e                                           // 0000007C0B24: D4C4007E
	v_cndmask_b32_e32 v1, s6, v4, vcc_lo                       // 0000007C0B28: 02020806
	s_cbranch_execz 10                                         // 0000007C0B2C: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x258>
	v_lshlrev_b32_e32 v3, 1, v4                                // 0000007C0B30: 30060881
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007C0B34: BF870091
	.long 0xd7006a03                                           // 0000007C0B38: D7006A03
	v_cndmask_b32_e32 v1, v14, v3, vcc_lo                      // 0000007C0B3C: 0202070E
	v_add_co_ci_u32_e64 v4, null, 0, v15, vcc_lo               // 0000007C0B40: D5207C04 01AA1E80
	global_load_d16_b16 v3, v[3:4], off                        // 0000007C0B48: DC820000 037C0003
	s_waitcnt vmcnt(0)                                         // 0000007C0B50: BF8903F7
	v_cvt_f32_f16_e32 v3, v3                                   // 0000007C0B54: 7E061703
	s_or_b32 exec_lo, exec_lo, s4                              // 0000007C0B58: 8C7E047E
	v_or_b32_e32 v6, 0x80, v23                                 // 0000007C0B5C: 380C2EFF 00000080
	v_dual_mov_b32 v5, 0 :: v_dual_mov_b32 v4, 0               // 0000007C0B64: CA100080 05040080
	s_mov_b32 s4, exec_lo                                      // 0000007C0B6C: BE84007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007C0B70: BF870002
	.long 0xd4c4007e                                           // 0000007C0B74: D4C4007E
	v_cndmask_b32_e32 v1, s6, v6, vcc_lo                       // 0000007C0B78: 02020C06
	s_cbranch_execz 10                                         // 0000007C0B7C: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x2a8>
	v_lshlrev_b32_e32 v4, 1, v6                                // 0000007C0B80: 30080C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007C0B84: BF870091
	.long 0xd7006a06                                           // 0000007C0B88: D7006A06
	v_cndmask_b32_e32 v1, v14, v4, vcc_lo                      // 0000007C0B8C: 0202090E
	v_add_co_ci_u32_e64 v7, null, 0, v15, vcc_lo               // 0000007C0B90: D5207C07 01AA1E80
	global_load_d16_b16 v4, v[6:7], off                        // 0000007C0B98: DC820000 047C0006
	s_waitcnt vmcnt(0)                                         // 0000007C0BA0: BF8903F7
	v_cvt_f32_f16_e32 v4, v4                                   // 0000007C0BA4: 7E081704
	s_or_b32 exec_lo, exec_lo, s4                              // 0000007C0BA8: 8C7E047E
	v_or_b32_e32 v6, 0xa0, v23                                 // 0000007C0BAC: 380C2EFF 000000A0
	s_mov_b32 s4, exec_lo                                      // 0000007C0BB4: BE84007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007C0BB8: BF870001
	.long 0xd4c4007e                                           // 0000007C0BBC: D4C4007E
	v_cndmask_b32_e32 v1, s6, v6, vcc_lo                       // 0000007C0BC0: 02020C06
	s_cbranch_execz 10                                         // 0000007C0BC4: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x2f0>
	v_lshlrev_b32_e32 v5, 1, v6                                // 0000007C0BC8: 300A0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007C0BCC: BF870091
	.long 0xd7006a05                                           // 0000007C0BD0: D7006A05
	v_cndmask_b32_e32 v1, v14, v5, vcc_lo                      // 0000007C0BD4: 02020B0E
	v_add_co_ci_u32_e64 v6, null, 0, v15, vcc_lo               // 0000007C0BD8: D5207C06 01AA1E80
	global_load_d16_b16 v5, v[5:6], off                        // 0000007C0BE0: DC820000 057C0005
	s_waitcnt vmcnt(0)                                         // 0000007C0BE8: BF8903F7
	v_cvt_f32_f16_e32 v5, v5                                   // 0000007C0BEC: 7E0A1705
	s_or_b32 exec_lo, exec_lo, s4                              // 0000007C0BF0: 8C7E047E
	v_or_b32_e32 v10, 0xc0, v23                                // 0000007C0BF4: 38142EFF 000000C0
	v_dual_mov_b32 v7, 0 :: v_dual_mov_b32 v6, 0               // 0000007C0BFC: CA100080 07060080
	s_mov_b32 s4, exec_lo                                      // 0000007C0C04: BE84007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007C0C08: BF870002
	.long 0xd4c4007e                                           // 0000007C0C0C: D4C4007E
	v_cndmask_b32_e32 v1, s6, v10, vcc_lo                      // 0000007C0C10: 02021406
	s_cbranch_execz 10                                         // 0000007C0C14: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x340>
	v_lshlrev_b32_e32 v6, 1, v10                               // 0000007C0C18: 300C1481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007C0C1C: BF870091
	.long 0xd7006a0a                                           // 0000007C0C20: D7006A0A
	v_cndmask_b32_e32 v1, v14, v6, vcc_lo                      // 0000007C0C24: 02020D0E
	v_add_co_ci_u32_e64 v11, null, 0, v15, vcc_lo              // 0000007C0C28: D5207C0B 01AA1E80
	global_load_d16_b16 v6, v[10:11], off                      // 0000007C0C30: DC820000 067C000A
	s_waitcnt vmcnt(0)                                         // 0000007C0C38: BF8903F7
	v_cvt_f32_f16_e32 v6, v6                                   // 0000007C0C3C: 7E0C1706
	s_or_b32 exec_lo, exec_lo, s4                              // 0000007C0C40: 8C7E047E
	v_or_b32_e32 v10, 0xe0, v23                                // 0000007C0C44: 38142EFF 000000E0
	s_mov_b32 s4, exec_lo                                      // 0000007C0C4C: BE84007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007C0C50: BF870001
	.long 0xd4c4007e                                           // 0000007C0C54: D4C4007E
	v_cndmask_b32_e32 v1, s6, v10, vcc_lo                      // 0000007C0C58: 02021406
	s_cbranch_execz 10                                         // 0000007C0C5C: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x388>
	v_lshlrev_b32_e32 v7, 1, v10                               // 0000007C0C60: 300E1481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007C0C64: BF870091
	.long 0xd7006a0a                                           // 0000007C0C68: D7006A0A
	v_cndmask_b32_e32 v1, v14, v7, vcc_lo                      // 0000007C0C6C: 02020F0E
	v_add_co_ci_u32_e64 v11, null, 0, v15, vcc_lo              // 0000007C0C70: D5207C0B 01AA1E80
	global_load_d16_b16 v7, v[10:11], off                      // 0000007C0C78: DC820000 077C000A
	s_waitcnt vmcnt(0)                                         // 0000007C0C80: BF8903F7
	v_cvt_f32_f16_e32 v7, v7                                   // 0000007C0C84: 7E0E1707
	s_or_b32 exec_lo, exec_lo, s4                              // 0000007C0C88: 8C7E047E
	s_branch 9                                                 // 0000007C0C8C: BFA00009 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x3b4>
	v_mov_b32_e32 v0, 0                                        // 0000007C0C90: 7E000280
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007C0C94: BF870001
	v_mov_b32_e32 v1, v0                                       // 0000007C0C98: 7E020300
	v_mov_b32_e32 v2, v0                                       // 0000007C0C9C: 7E040300
	v_mov_b32_e32 v3, v0                                       // 0000007C0CA0: 7E060300
	v_mov_b32_e32 v4, v0                                       // 0000007C0CA4: 7E080300
	v_mov_b32_e32 v5, v0                                       // 0000007C0CA8: 7E0A0300
	v_mov_b32_e32 v6, v0                                       // 0000007C0CAC: 7E0C0300
	v_mov_b32_e32 v7, v0                                       // 0000007C0CB0: 7E0E0300
	s_add_u32 s4, s8, s18                                      // 0000007C0CB4: 80041208
	s_addc_u32 s5, s9, s19                                     // 0000007C0CB8: 82051309
	s_lshr_b32 s18, s15, 31                                    // 0000007C0CBC: 85129F0F
	v_mov_b32_e32 v26, 0                                       // 0000007C0CC0: 7E340280
	s_add_u32 s18, s14, s18                                    // 0000007C0CC4: 8012120E
	s_addc_u32 s19, s15, 0                                     // 0000007C0CC8: 8213800F
	v_cndmask_b32_e64 v24, 0, 1, s7                            // 0000007C0CCC: D5010018 001D0280
	s_ashr_i64 s[18:19], s[18:19], 1                           // 0000007C0CD4: 86928112
	v_mov_b32_e32 v27, 0                                       // 0000007C0CD8: 7E360280
	v_mad_u64_u32 v[18:19], null, v8, s18, s[4:5]              // 0000007C0CDC: D6FE7C12 00102508
	.long 0xd72c000b                                           // 0000007C0CE4: D72C000B
	v_cndmask_b32_e32 v0, v8, v19, vcc_lo                      // 0000007C0CE8: 02002708
	.long 0xd72c0014                                           // 0000007C0CEC: D72C0014
	v_cndmask_b32_e32 v0, v9, v18, vcc_lo                      // 0000007C0CF0: 02002509
	.long 0xd4440004                                           // 0000007C0CF4: D4440004
	v_cndmask_b32_e32 v1, s6, v23, vcc_lo                      // 0000007C0CF8: 02022E06
	v_dual_mov_b32 v8, 0 :: v_dual_mov_b32 v9, 0               // 0000007C0CFC: CA100080 08080080
	v_mov_b32_e32 v10, 0                                       // 0000007C0D04: 7E140280
	s_delay_alu instid0(VALU_DEP_4)                            // 0000007C0D08: BF870004
	v_add3_u32 v25, v20, v19, v11                              // 0000007C0D0C: D6550019 042E2714
	v_mov_b32_e32 v11, 0                                       // 0000007C0D14: 7E160280
	s_and_saveexec_b32 s5, s4                                  // 0000007C0D18: BE852004
	s_cbranch_execz 21                                         // 0000007C0D1C: BFA50015 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x474>
	v_dual_mov_b32 v27, 0 :: v_dual_lshlrev_b32 v8, 4, v23     // 0000007C0D20: CA220080 1B082E84
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007C0D28: BF870091
	.long 0xd7006a08                                           // 0000007C0D2C: D7006A08
	v_cndmask_b32_e32 v1, v18, v8, vcc_lo                      // 0000007C0D30: 02021112
	v_add_co_ci_u32_e64 v9, null, 0, v25, vcc_lo               // 0000007C0D34: D5207C09 01AA3280
	s_and_not1_b32 vcc_lo, exec_lo, s7                         // 0000007C0D3C: 916A077E
	global_load_b128 v[8:11], v[8:9], off                      // 0000007C0D40: DC5E0000 087C0008
	s_cbranch_vccnz 10                                         // 0000007C0D48: BFA4000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x474>
	v_lshlrev_b32_e32 v19, 1, v23                              // 0000007C0D4C: 30262E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007C0D50: BF870091
	.long 0xd7006a0e                                           // 0000007C0D54: D7006A0E
	v_cndmask_b32_e32 v1, v14, v19, vcc_lo                     // 0000007C0D58: 0202270E
	v_add_co_ci_u32_e64 v15, null, 0, v15, vcc_lo              // 0000007C0D5C: D5207C0F 01AA1E80
	global_load_d16_b16 v14, v[14:15], off                     // 0000007C0D64: DC820000 0E7C000E
	s_waitcnt vmcnt(0)                                         // 0000007C0D6C: BF8903F7
	v_cvt_f32_f16_e32 v27, v14                                 // 0000007C0D70: 7E36170E
	s_or_b32 exec_lo, exec_lo, s5                              // 0000007C0D74: 8C7E057E
	v_mov_b32_e32 v28, 0                                       // 0000007C0D78: 7E380280
	s_and_saveexec_b32 s5, s4                                  // 0000007C0D7C: BE852004
	s_cbranch_execz 305                                        // 0000007C0D80: BFA50131 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x948>
	v_dual_mov_b32 v31, v27 :: v_dual_lshlrev_b32 v14, 1, v23  // 0000007C0D84: CA22011B 1F0E2E81
	.long 0xd7006a0c                                           // 0000007C0D8C: D7006A0C
	v_cndmask_b32_e32 v1, s20, v12, vcc_lo                     // 0000007C0D90: 02021814
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007C0D94: BF8701A1
	v_add_co_ci_u32_e64 v13, null, s21, v13, vcc_lo            // 0000007C0D98: D5207C0D 01AA1A15
	v_dual_mov_b32 v20, 0 :: v_dual_lshlrev_b32 v19, 5, v23    // 0000007C0DA0: CA220080 14122E85
	.long 0xd7006a0c                                           // 0000007C0DA8: D7006A0C
	v_cndmask_b32_e32 v1, v12, v14, vcc_lo                     // 0000007C0DAC: 02021D0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007C0DB0: BF8701A1
	v_add_co_ci_u32_e64 v13, null, 0, v13, vcc_lo              // 0000007C0DB4: D5207C0D 01AA1A80
	v_lshl_or_b32 v29, v23, 4, 0x200                           // 0000007C0DBC: D656001D 03FD0917 00000200
	.long 0xd7006a0c                                           // 0000007C0DC8: D7006A0C
	v_cndmask_b32_e32 v1, s8, v12, vcc_lo                      // 0000007C0DCC: 02021808
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007C0DD0: BF8701A1
	v_add_co_ci_u32_e64 v13, null, s9, v13, vcc_lo             // 0000007C0DD4: D5207C0D 01AA1A09
	v_mov_b32_e32 v30, v23                                     // 0000007C0DDC: 7E3C0317
	.long 0xd7006a15                                           // 0000007C0DE0: D7006A15
	v_cndmask_b32_e32 v0, v12, v192, vcc_lo                    // 0000007C0DE4: 0201810C
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007C0DE8: BF870001
	v_add_co_ci_u32_e64 v22, null, 0, v13, vcc_lo              // 0000007C0DEC: D5207C16 01AA1A80
	v_mov_b32_e32 v28, v20                                     // 0000007C0DF4: 7E380314
	v_mov_b32_e32 v26, v20                                     // 0000007C0DF8: 7E340314
	s_mov_b32 s7, 0                                            // 0000007C0DFC: BE870080
	s_lshl_b64 s[8:9], s[14:15], 1                             // 0000007C0E00: 8488810E
	s_branch 243                                               // 0000007C0E04: BFA000F3 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x8d4>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000007C0E08: 8C7E0E7E
	.long 0xd73c0020                                           // 0000007C0E0C: D73C0020
	v_cndmask_b32_e32 v1, 1, v19, vcc_lo                       // 0000007C0E10: 02022681
	v_and_b32_e32 v64, 0xff, v8                                // 0000007C0E14: 368010FF 000000FF
	v_lshrrev_b32_e32 v65, 6, v8                               // 0000007C0E1C: 32821086
	v_lshrrev_b32_e32 v66, 14, v8                              // 0000007C0E20: 3284108E
	v_lshrrev_b32_e32 v8, 22, v8                               // 0000007C0E24: 32101096
	v_and_b32_e32 v67, 0xff, v9                                // 0000007C0E28: 368612FF 000000FF
	.long 0xd7006a38                                           // 0000007C0E30: D7006A38
	v_cndmask_b32_e32 v1, s10, v32, vcc_lo                     // 0000007C0E34: 0202400A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007C0E38: BF8701A1
	v_add_co_ci_u32_e64 v57, null, s11, v33, vcc_lo            // 0000007C0E3C: D5207C39 01AA420B
	v_lshlrev_b32_e32 v64, 2, v64                              // 0000007C0E44: 30808082
	.long 0xd7006a3c                                           // 0000007C0E48: D7006A3C
	v_cndmask_b32_e32 v0, v56, v8, vcc_lo                      // 0000007C0E4C: 02001138
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007C0E50: BF870001
	v_add_co_ci_u32_e64 v61, null, s9, v57, vcc_lo             // 0000007C0E54: D5207C3D 01AA7209
	v_and_b32_e32 v65, 0x3fc, v65                              // 0000007C0E5C: 368282FF 000003FC
	ds_load_b32 v64, v64                                       // 0000007C0E64: D8D80000 40000040
	s_clause 0x7                                               // 0000007C0E6C: BF850007
	global_load_b128 v[32:35], v[56:57], off                   // 0000007C0E70: DC5E0000 207C0038
	global_load_b128 v[36:39], v[60:61], off                   // 0000007C0E78: DC5E0000 247C003C
	global_load_b128 v[40:43], v[56:57], off offset:16         // 0000007C0E80: DC5E0010 287C0038
	global_load_b128 v[44:47], v[60:61], off offset:16         // 0000007C0E88: DC5E0010 2C7C003C
	global_load_b128 v[48:51], v[56:57], off offset:32         // 0000007C0E90: DC5E0020 307C0038
	global_load_b128 v[52:55], v[60:61], off offset:32         // 0000007C0E98: DC5E0020 347C003C
	global_load_b128 v[56:59], v[56:57], off offset:48         // 0000007C0EA0: DC5E0030 387C0038
	global_load_b128 v[60:63], v[60:61], off offset:48         // 0000007C0EA8: DC5E0030 3C7C003C
	v_and_b32_e32 v66, 0x3fc, v66                              // 0000007C0EB0: 368484FF 000003FC
	v_lshrrev_b32_e32 v68, 6, v9                               // 0000007C0EB8: 32881286
	ds_load_b32 v65, v65                                       // 0000007C0EBC: D8D80000 41000041
	v_lshrrev_b32_e32 v69, 14, v9                              // 0000007C0EC4: 328A128E
	v_lshrrev_b32_e32 v9, 22, v9                               // 0000007C0EC8: 32121296
	ds_load_b32 v66, v66                                       // 0000007C0ECC: D8D80000 42000042
	v_and_b32_e32 v8, 0x3fc, v8                                // 0000007C0ED4: 361010FF 000003FC
	v_lshlrev_b32_e32 v67, 2, v67                              // 0000007C0EDC: 30868682
	v_and_b32_e32 v68, 0x3fc, v68                              // 0000007C0EE0: 368888FF 000003FC
	v_and_b32_e32 v69, 0x3fc, v69                              // 0000007C0EE8: 368A8AFF 000003FC
	v_and_b32_e32 v9, 0x3fc, v9                                // 0000007C0EF0: 361212FF 000003FC
	ds_load_b32 v8, v8                                         // 0000007C0EF8: D8D80000 08000008
	ds_load_b32 v67, v67                                       // 0000007C0F00: D8D80000 43000043
	ds_load_b32 v68, v68                                       // 0000007C0F08: D8D80000 44000044
	ds_load_b32 v69, v69                                       // 0000007C0F10: D8D80000 45000045
	ds_load_b32 v9, v9                                         // 0000007C0F18: D8D80000 09000009
	.long 0xd7006a15                                           // 0000007C0F20: D7006A15
	v_cndmask_b32_e32 v0, v21, v192, vcc_lo                    // 0000007C0F24: 02018115
	v_add_nc_u32_e32 v29, 0x200, v29                           // 0000007C0F28: 4A3A3AFF 00000200
	v_add_co_ci_u32_e64 v22, null, 0, v22, vcc_lo              // 0000007C0F30: D5207C16 01AA2C80
	s_and_b32 s4, exec_lo, s4                                  // 0000007C0F38: 8B04047E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000007C0F3C: BF870009
	s_or_b32 s7, s4, s7                                        // 0000007C0F40: 8C070704
	s_waitcnt vmcnt(7) lgkmcnt(7)                              // 0000007C0F44: BF891C77
	v_dot2_f32_bf16 v32, v32, v64, 0                           // 0000007C0F48: CC1A4020 1A028120
	s_waitcnt vmcnt(6)                                         // 0000007C0F50: BF891BF7
	v_dot2_f32_bf16 v36, v36, v64, 0                           // 0000007C0F54: CC1A4024 1A028124
	v_and_b32_e32 v64, 0xff, v10                               // 0000007C0F5C: 368014FF 000000FF
	s_waitcnt lgkmcnt(6)                                       // 0000007C0F64: BF89FC67
	v_dot2_f32_bf16 v32, v33, v65, v32                         // 0000007C0F68: CC1A4020 1C828321
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007C0F70: BF870003
	v_dot2_f32_bf16 v33, v37, v65, v36                         // 0000007C0F74: CC1A4021 1C928325
	v_lshrrev_b32_e32 v36, 6, v10                              // 0000007C0F7C: 32481486
	v_lshrrev_b32_e32 v37, 14, v10                             // 0000007C0F80: 324A148E
	v_lshrrev_b32_e32 v10, 22, v10                             // 0000007C0F84: 32141496
	s_waitcnt lgkmcnt(5)                                       // 0000007C0F88: BF89FC57
	v_dot2_f32_bf16 v32, v34, v66, v32                         // 0000007C0F8C: CC1A4020 1C828522
	v_dot2_f32_bf16 v33, v38, v66, v33                         // 0000007C0F94: CC1A4021 1C868526
	v_and_b32_e32 v34, 0xff, v11                               // 0000007C0F9C: 364416FF 000000FF
	v_lshrrev_b32_e32 v38, 6, v11                              // 0000007C0FA4: 324C1686
	v_lshrrev_b32_e32 v65, 14, v11                             // 0000007C0FA8: 3282168E
	s_waitcnt lgkmcnt(4)                                       // 0000007C0FAC: BF89FC47
	v_dot2_f32_bf16 v32, v35, v8, v32                          // 0000007C0FB0: CC1A4020 1C821123
	v_dot2_f32_bf16 v8, v39, v8, v33                           // 0000007C0FB8: CC1A4008 1C861127
	v_and_b32_e32 v35, 0x3fc, v36                              // 0000007C0FC0: 364648FF 000003FC
	v_and_b32_e32 v36, 0x3fc, v37                              // 0000007C0FC8: 36484AFF 000003FC
	v_lshrrev_b32_e32 v11, 22, v11                             // 0000007C0FD0: 32161696
	s_waitcnt vmcnt(5) lgkmcnt(3)                              // 0000007C0FD4: BF891437
	v_dot2_f32_bf16 v32, v40, v67, v32                         // 0000007C0FD8: CC1A4020 1C828728
	s_waitcnt vmcnt(4)                                         // 0000007C0FE0: BF8913F7
	v_dot2_f32_bf16 v8, v44, v67, v8                           // 0000007C0FE4: CC1A4008 1C22872C
	v_and_b32_e32 v10, 0x3fc, v10                              // 0000007C0FEC: 361414FF 000003FC
	v_lshlrev_b32_e32 v34, 2, v34                              // 0000007C0FF4: 30444482
	v_and_b32_e32 v37, 0x3fc, v38                              // 0000007C0FF8: 364A4CFF 000003FC
	s_waitcnt lgkmcnt(2)                                       // 0000007C1000: BF89FC27
	v_dot2_f32_bf16 v32, v41, v68, v32                         // 0000007C1004: CC1A4020 1C828929
	v_dot2_f32_bf16 v8, v45, v68, v8                           // 0000007C100C: CC1A4008 1C22892D
	v_and_b32_e32 v38, 0x3fc, v65                              // 0000007C1014: 364C82FF 000003FC
	v_and_b32_e32 v11, 0x3fc, v11                              // 0000007C101C: 361616FF 000003FC
	ds_load_b32 v35, v35                                       // 0000007C1024: D8D80000 23000023
	ds_load_b32 v36, v36                                       // 0000007C102C: D8D80000 24000024
	s_waitcnt lgkmcnt(3)                                       // 0000007C1034: BF89FC37
	v_dot2_f32_bf16 v32, v42, v69, v32                         // 0000007C1038: CC1A4020 1C828B2A
	v_cndmask_b32_e64 v42, v27, v0, s3                         // 0000007C1040: D501002A 000E011B
	v_lshlrev_b32_e32 v33, 2, v64                              // 0000007C1048: 30428082
	v_dot2_f32_bf16 v8, v46, v69, v8                           // 0000007C104C: CC1A4008 1C228B2E
	v_mov_b32_e32 v27, v31                                     // 0000007C1054: 7E36031F
	s_waitcnt lgkmcnt(2)                                       // 0000007C1058: BF89FC27
	v_dot2_f32_bf16 v32, v43, v9, v32                          // 0000007C105C: CC1A4020 1C82132B
	ds_load_b32 v33, v33                                       // 0000007C1064: D8D80000 21000021
	v_dot2_f32_bf16 v8, v47, v9, v8                            // 0000007C106C: CC1A4008 1C22132F
	ds_load_b32 v9, v10                                        // 0000007C1074: D8D80000 0900000A
	ds_load_b32 v10, v34                                       // 0000007C107C: D8D80000 0A000022
	ds_load_b32 v39, v37                                       // 0000007C1084: D8D80000 27000025
	ds_load_b32 v40, v38                                       // 0000007C108C: D8D80000 28000026
	ds_load_b32 v41, v11                                       // 0000007C1094: D8D80000 2900000B
	v_cndmask_b32_e64 v37, v5, v6, s3                          // 0000007C109C: D5010025 000E0D05
	v_cndmask_b32_e64 v38, v6, v7, s3                          // 0000007C10A4: D5010026 000E0F06
	v_cndmask_b32_e64 v34, v2, v3, s3                          // 0000007C10AC: D5010022 000E0702
	s_waitcnt vmcnt(3) lgkmcnt(5)                              // 0000007C10B4: BF890C57
	v_dot2_f32_bf16 v11, v48, v33, v32                         // 0000007C10B8: CC1A400B 1C824330
	s_waitcnt vmcnt(2)                                         // 0000007C10C0: BF890BF7
	v_dot2_f32_bf16 v8, v52, v33, v8                           // 0000007C10C4: CC1A4008 1C224334
	v_cndmask_b32_e64 v33, v1, v2, s3                          // 0000007C10CC: D5010021 000E0501
	v_cndmask_b32_e64 v32, v0, v1, s3                          // 0000007C10D4: D5010020 000E0300
	v_dot2_f32_bf16 v11, v49, v35, v11                         // 0000007C10DC: CC1A400B 1C2E4731
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007C10E4: BF8701A4
	v_dot2_f32_bf16 v8, v53, v35, v8                           // 0000007C10E8: CC1A4008 1C224735
	v_cndmask_b32_e64 v35, v3, v4, s3                          // 0000007C10F0: D5010023 000E0903
	v_dot2_f32_bf16 v11, v50, v36, v11                         // 0000007C10F8: CC1A400B 1C2E4932
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000007C1100: BF8701B3
	v_dot2_f32_bf16 v8, v54, v36, v8                           // 0000007C1104: CC1A4008 1C224936
	v_cndmask_b32_e64 v36, v4, v5, s3                          // 0000007C110C: D5010024 000E0B04
	s_waitcnt lgkmcnt(4)                                       // 0000007C1114: BF89FC47
	v_dot2_f32_bf16 v11, v51, v9, v11                          // 0000007C1118: CC1A400B 1C2E1333
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000007C1120: BF8701B3
	v_dot2_f32_bf16 v8, v55, v9, v8                            // 0000007C1124: CC1A4008 1C221337
	v_mov_b32_e32 v9, v13                                      // 0000007C112C: 7E12030D
	s_waitcnt vmcnt(1) lgkmcnt(3)                              // 0000007C1130: BF890437
	v_dot2_f32_bf16 v4, v56, v10, v11                          // 0000007C1134: CC1A4004 1C2E1538
	s_waitcnt vmcnt(0)                                         // 0000007C113C: BF8903F7
	v_dot2_f32_bf16 v5, v60, v10, v8                           // 0000007C1140: CC1A4005 1C22153C
	v_dual_mov_b32 v11, v15 :: v_dual_mov_b32 v10, v14         // 0000007C1148: CA10010F 0B0A010E
	v_mov_b32_e32 v8, v12                                      // 0000007C1150: 7E10030C
	s_waitcnt lgkmcnt(2)                                       // 0000007C1154: BF89FC27
	v_dot2_f32_bf16 v0, v57, v39, v4                           // 0000007C1158: CC1A4000 1C124F39
	v_dot2_f32_bf16 v1, v61, v39, v5                           // 0000007C1160: CC1A4001 1C164F3D
	v_mov_b32_e32 v39, v7                                      // 0000007C1168: 7E4E0307
	v_add_nc_u32_e32 v19, 0x400, v19                           // 0000007C116C: 4A2626FF 00000400
	s_waitcnt lgkmcnt(1)                                       // 0000007C1174: BF89FC17
	v_dot2_f32_bf16 v0, v58, v40, v0                           // 0000007C1178: CC1A4000 1C02513A
	v_dot2_f32_bf16 v1, v62, v40, v1                           // 0000007C1180: CC1A4001 1C06513E
	s_waitcnt lgkmcnt(0)                                       // 0000007C1188: BF89FC07
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007C118C: BF870112
	v_dot2_f32_bf16 v0, v59, v41, v0                           // 0000007C1190: CC1A4000 1C02533B
	v_dot2_f32_bf16 v1, v63, v41, v1                           // 0000007C1198: CC1A4001 1C06533F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007C11A0: BF870112
	v_fmac_f32_e32 v28, v42, v0                                // 0000007C11A4: 5638012A
	v_fmac_f32_e32 v26, v42, v1                                // 0000007C11A8: 5634032A
	v_dual_mov_b32 v0, v32 :: v_dual_mov_b32 v1, v33           // 0000007C11AC: CA100120 00000121
	v_dual_mov_b32 v2, v34 :: v_dual_mov_b32 v3, v35           // 0000007C11B4: CA100122 02020123
	v_dual_mov_b32 v4, v36 :: v_dual_mov_b32 v5, v37           // 0000007C11BC: CA100124 04040125
	v_dual_mov_b32 v6, v38 :: v_dual_mov_b32 v7, v39           // 0000007C11C4: CA100126 06060127
	s_and_not1_b32 exec_lo, exec_lo, s7                        // 0000007C11CC: 917E077E
	s_cbranch_execz 28                                         // 0000007C11D0: BFA5001C <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x944>
	s_waitcnt vmcnt(0)                                         // 0000007C11D4: BF8903F7
	v_dual_mov_b32 v13, v9 :: v_dual_add_nc_u32 v30, 32, v30   // 0000007C11D8: CA200109 0D1E3CA0
	v_dual_mov_b32 v12, v8 :: v_dual_mov_b32 v15, v11          // 0000007C11E0: CA100108 0C0E010B
	v_mov_b32_e32 v14, v10                                     // 0000007C11E8: 7E1C030A
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007C11EC: BF870003
	.long 0xd4430004                                           // 0000007C11F0: D4430004
	v_cndmask_b32_e32 v1, s6, v30, vcc_lo                      // 0000007C11F4: 02023C06
	s_mov_b32 s14, exec_lo                                     // 0000007C11F8: BE8E007E
	.long 0xd4c4007e                                           // 0000007C11FC: D4C4007E
	v_cndmask_b32_e32 v1, s6, v30, vcc_lo                      // 0000007C1200: 02023C06
	s_cbranch_execz 65280                                      // 0000007C1204: BFA5FF00 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x508>
	.long 0xd7006a0c                                           // 0000007C1208: D7006A0C
	v_cndmask_b32_e32 v1, v18, v29, vcc_lo                     // 0000007C120C: 02023B12
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007C1210: BF870001
	v_add_co_ci_u32_e64 v13, null, 0, v25, vcc_lo              // 0000007C1214: D5207C0D 01AA3280
	v_cmp_ne_u32_e32 vcc_lo, 1, v24                            // 0000007C121C: 7C9A3081
	v_mov_b32_e32 v31, v27                                     // 0000007C1220: 7E3E031B
	global_load_b128 v[12:15], v[12:13], off                   // 0000007C1224: DC5E0000 0C7C000C
	s_cbranch_vccnz 65270                                      // 0000007C122C: BFA4FEF6 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x508>
	global_load_d16_b16 v31, v[21:22], off                     // 0000007C1230: DC820000 1F7C0015
	s_waitcnt vmcnt(0)                                         // 0000007C1238: BF8903F7
	v_cvt_f32_f16_e32 v31, v31                                 // 0000007C123C: 7E3E171F
	s_branch 65265                                             // 0000007C1240: BFA0FEF1 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x508>
	s_or_b32 exec_lo, exec_lo, s7                              // 0000007C1244: 8C7E077E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007C1248: BF8700A9
	s_or_b32 exec_lo, exec_lo, s5                              // 0000007C124C: 8C7E057E
	.long 0xd71f0000                                           // 0000007C1250: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000007C1254: 020100C1
	v_xor_b32_e32 v1, 16, v0                                   // 0000007C1258: 3A020090
	v_xor_b32_e32 v3, 8, v0                                    // 0000007C125C: 3A060088
	v_xor_b32_e32 v5, 4, v0                                    // 0000007C1260: 3A0A0084
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000007C1264: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v1                            // 0000007C1268: 7C9802A0
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 0000007C126C: 02020300
	v_cmp_gt_u32_e32 vcc_lo, 32, v3                            // 0000007C1270: 7C9806A0
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007C1274: BF870002
	v_lshlrev_b32_e32 v1, 2, v1                                // 0000007C1278: 30020282
	v_cndmask_b32_e32 v3, v0, v3, vcc_lo                       // 0000007C127C: 02060700
	v_cmp_gt_u32_e32 vcc_lo, 32, v5                            // 0000007C1280: 7C980AA0
	ds_bpermute_b32 v2, v1, v28                                // 0000007C1284: DACC0000 02001C01
	s_waitcnt lgkmcnt(0)                                       // 0000007C128C: BF89FC07
	v_dual_add_f32 v2, v28, v2 :: v_dual_lshlrev_b32 v3, 2, v3 // 0000007C1290: C922051C 02020682
	ds_bpermute_b32 v1, v1, v26                                // 0000007C1298: DACC0000 01001A01
	ds_bpermute_b32 v4, v3, v2                                 // 0000007C12A0: DACC0000 04000203
	s_waitcnt lgkmcnt(1)                                       // 0000007C12A8: BF89FC17
	v_add_f32_e32 v1, v26, v1                                  // 0000007C12AC: 0602031A
	s_waitcnt lgkmcnt(0)                                       // 0000007C12B0: BF89FC07
	v_add_f32_e32 v2, v2, v4                                   // 0000007C12B4: 06040902
	ds_bpermute_b32 v3, v3, v1                                 // 0000007C12B8: DACC0000 03000103
	v_cndmask_b32_e32 v5, v0, v5, vcc_lo                       // 0000007C12C0: 020A0B00
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007C12C4: BF870001
	v_lshlrev_b32_e32 v5, 2, v5                                // 0000007C12C8: 300A0A82
	s_waitcnt lgkmcnt(0)                                       // 0000007C12CC: BF89FC07
	v_add_f32_e32 v1, v1, v3                                   // 0000007C12D0: 06020701
	ds_bpermute_b32 v3, v5, v2                                 // 0000007C12D4: DACC0000 03000205
	ds_bpermute_b32 v4, v5, v1                                 // 0000007C12DC: DACC0000 04000105
	v_xor_b32_e32 v5, 2, v0                                    // 0000007C12E4: 3A0A0082
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007C12E8: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v5                            // 0000007C12EC: 7C980AA0
	v_cndmask_b32_e32 v5, v0, v5, vcc_lo                       // 0000007C12F0: 020A0B00
	s_waitcnt lgkmcnt(1)                                       // 0000007C12F4: BF89FC17
	v_dual_add_f32 v2, v2, v3 :: v_dual_lshlrev_b32 v5, 2, v5  // 0000007C12F8: C9220702 02040A82
	s_waitcnt lgkmcnt(0)                                       // 0000007C1300: BF89FC07
	v_add_f32_e32 v1, v1, v4                                   // 0000007C1304: 06020901
	ds_bpermute_b32 v3, v5, v2                                 // 0000007C1308: DACC0000 03000205
	ds_bpermute_b32 v4, v5, v1                                 // 0000007C1310: DACC0000 04000105
	v_xor_b32_e32 v5, 1, v0                                    // 0000007C1318: 3A0A0081
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000007C131C: BF870141
	v_cmp_gt_u32_e32 vcc_lo, 32, v5                            // 0000007C1320: 7C980AA0
	v_cndmask_b32_e32 v0, v0, v5, vcc_lo                       // 0000007C1324: 02000B00
	v_cmp_eq_u32_e32 vcc_lo, 0, v23                            // 0000007C1328: 7C942E80
	s_waitcnt lgkmcnt(1)                                       // 0000007C132C: BF89FC17
	v_dual_add_f32 v2, v2, v3 :: v_dual_lshlrev_b32 v5, 2, v0  // 0000007C1330: C9220702 02040082
	s_and_b32 s2, vcc_lo, s2                                   // 0000007C1338: 8B02026A
	s_waitcnt lgkmcnt(0)                                       // 0000007C133C: BF89FC07
	v_add_f32_e32 v0, v1, v4                                   // 0000007C1340: 06000901
	ds_bpermute_b32 v3, v5, v2                                 // 0000007C1344: DACC0000 03000205
	ds_bpermute_b32 v1, v5, v0                                 // 0000007C134C: DACC0000 01000005
	s_and_saveexec_b32 s3, s2                                  // 0000007C1354: BE832002
	s_cbranch_execz 119                                        // 0000007C1358: BFA50077 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0xc38>
	s_waitcnt lgkmcnt(1)                                       // 0000007C135C: BF89FC17
	v_add_f32_e32 v2, v2, v3                                   // 0000007C1360: 06040702
	.long 0x7f063880                                           // 0000007C1364: 7F063880
	s_waitcnt lgkmcnt(0)                                       // 0000007C1368: BF89FC07
	v_add_f32_e32 v0, v0, v1                                   // 0000007C136C: 06000300
	s_load_b32 s0, s[0:1], 0x48                                // 0000007C1370: F4000000 F8000048
	.long 0x7e023982                                           // 0000007C1378: 7E023982
	.long 0x7f023983                                           // 0000007C137C: 7F023983
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007C1380: BF870091
	v_and_b32_e32 v1, 1, v1                                    // 0000007C1384: 36020281
	v_add3_u32 v1, v2, v1, 0x7fff                              // 0000007C1388: D6550001 03FE0302 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007C1394: BF8700A1
	v_and_b32_e32 v1, 0xffff0000, v1                           // 0000007C1398: 360202FF FFFF0000
	s_waitcnt lgkmcnt(0)                                       // 0000007C13A0: BF89FC07
	v_mul_f32_e32 v1, s0, v1                                   // 0000007C13A4: 10020200
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007C13A8: BF870091
	v_mul_f32_e32 v2, 0xbfb8aa3b, v1                           // 0000007C13AC: 100402FF BFB8AA3B
	v_exp_f32_e32 v2, v2                                       // 0000007C13B4: 7E044B02
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007C13B8: BF870095
	v_add_f32_e32 v2, 1.0, v2                                  // 0000007C13BC: 060404F2
	v_div_scale_f32 v5, null, v2, v2, v1                       // 0000007C13C0: D6FC7C05 04060502
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(TRANS32_DEP_1)// 0000007C13C8: BF8702A1
	v_rcp_f32_e32 v7, v5                                       // 0000007C13CC: 7E0E5505
	s_waitcnt vmcnt(0)                                         // 0000007C13D0: BF8903F7
	v_fma_f32 v9, -v5, v7, 1.0                                 // 0000007C13D4: D6130009 23CA0F05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007C13DC: BF8700A1
	v_fmac_f32_e32 v7, v9, v7                                  // 0000007C13E0: 560E0F09
	.long 0x7e063980                                           // 0000007C13E4: 7E063980
	v_and_b32_e32 v4, 1, v3                                    // 0000007C13E8: 36080681
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007C13EC: BF870091
	v_add3_u32 v0, v0, v4, 0x7fff                              // 0000007C13F0: D6550000 03FE0900 00007FFF
	v_and_b32_e32 v0, 0xffff0000, v0                           // 0000007C13FC: 360000FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007C1404: BF870091
	v_mul_f32_e32 v0, s0, v0                                   // 0000007C1408: 10000000
	v_mul_f32_e32 v4, 0xbfb8aa3b, v0                           // 0000007C140C: 100800FF BFB8AA3B
	v_div_scale_f32 v11, vcc_lo, v1, v2, v1                    // 0000007C1414: D6FC6A0B 04060501
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000007C141C: BF870292
	v_exp_f32_e32 v4, v4                                       // 0000007C1420: 7E084B04
	v_add_f32_e32 v4, 1.0, v4                                  // 0000007C1424: 060808F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000007C1428: BF870121
	v_div_scale_f32 v6, null, v4, v4, v0                       // 0000007C142C: D6FC7C06 04020904
	v_div_scale_f32 v9, s0, v0, v4, v0                         // 0000007C1434: D6FC0009 04020900
	v_rcp_f32_e32 v8, v6                                       // 0000007C143C: 7E105506
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007C1440: BF870095
	v_fma_f32 v10, -v6, v8, 1.0                                // 0000007C1444: D613000A 23CA1106
	v_fmac_f32_e32 v8, v10, v8                                 // 0000007C144C: 5610110A
	v_mul_f32_e32 v10, v11, v7                                 // 0000007C1450: 10140F0B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007C1454: BF870112
	v_mul_f32_e32 v12, v9, v8                                  // 0000007C1458: 10181109
	v_fma_f32 v13, -v5, v10, v11                               // 0000007C145C: D613000D 242E1505
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007C1464: BF870112
	v_fma_f32 v14, -v6, v12, v9                                // 0000007C1468: D613000E 24261906
	v_fmac_f32_e32 v10, v13, v7                                // 0000007C1470: 56140F0D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007C1474: BF870112
	v_fmac_f32_e32 v12, v14, v8                                // 0000007C1478: 5618110E
	v_fma_f32 v5, -v5, v10, v11                                // 0000007C147C: D6130005 242E1505
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007C1484: BF870112
	v_fma_f32 v6, -v6, v12, v9                                 // 0000007C1488: D6130006 24261906
	v_div_fmas_f32 v5, v5, v7, v10                             // 0000007C1490: D6370005 042A0F05
	s_mov_b32 vcc_lo, s0                                       // 0000007C1498: BEEA0000
	s_lshl_b64 s[0:1], s[16:17], 1                             // 0000007C149C: 84808110
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007C14A0: BF870112
	v_div_fmas_f32 v6, v6, v8, v12                             // 0000007C14A4: D6370006 04321106
	v_div_fixup_f32 v2, v5, v2, v1                             // 0000007C14AC: D6270002 04060505
	.long 0x7f0a3983                                           // 0000007C14B4: 7F0A3983
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000007C14B8: BF870223
	v_div_fixup_f32 v4, v6, v4, v0                             // 0000007C14BC: D6270004 04020906
	.long 0xd73c0000                                           // 0000007C14C4: D73C0000
	v_cndmask_b32_e32 v1, 1, v16, vcc_lo                       // 0000007C14C8: 02022081
	.long 0x7e0a3982                                           // 0000007C14CC: 7E0A3982
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007C14D0: BF870113
	.long 0x7e063984                                           // 0000007C14D4: 7E063984
	v_and_b32_e32 v5, 1, v5                                    // 0000007C14D8: 360A0A81
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007C14DC: BF870194
	.long 0xd7006a00                                           // 0000007C14E0: D7006A00
	v_cndmask_b32_e32 v1, s12, v0, vcc_lo                      // 0000007C14E4: 0202000C
	v_and_b32_e32 v3, 1, v3                                    // 0000007C14E8: 36060681
	v_add_co_ci_u32_e64 v1, null, s13, v1, vcc_lo              // 0000007C14EC: D5207C01 01AA020D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000007C14F4: BF870214
	v_add3_u32 v5, v2, v5, 0x7fff                              // 0000007C14F8: D6550005 03FE0B02 00007FFF
	.long 0xd7006a02                                           // 0000007C1504: D7006A02
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 0000007C1508: 02000100
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000007C150C: BF870214
	v_add3_u32 v4, v4, v3, 0x7fff                              // 0000007C1510: D6550004 03FE0704 00007FFF
	v_add_co_ci_u32_e64 v3, null, s1, v1, vcc_lo               // 0000007C151C: D5207C03 01AA0201
	s_clause 0x1                                               // 0000007C1524: BF850001
	global_store_d16_hi_b16 v[0:1], v5, off                    // 0000007C1528: DC960000 007C0500
	global_store_d16_hi_b16 v[2:3], v4, off                    // 0000007C1530: DC960000 007C0402
	s_endpgm                                                   // 0000007C1538: BFB00000
		...

