000000000047cb00 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi2ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_>:
; _ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi2ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_():
	s_clause 0x3                                               // 00000047CB00: BF850003
	s_load_b256 s[12:19], s[0:1], null                         // 00000047CB04: F40C0300 F8000000
	s_load_b256 s[20:27], s[0:1], 0x20                         // 00000047CB0C: F40C0500 F8000020
	s_load_b128 s[28:31], s[0:1], 0x40                         // 00000047CB14: F4080700 F8000040
	s_load_b32 s33, s[0:1], 0x54                               // 00000047CB1C: F4000840 F8000054
	v_and_b32_e32 v13, 31, v0                                  // 00000047CB24: 361A009F
	v_lshrrev_b32_e32 v11, 5, v0                               // 00000047CB28: 32160085
	s_mov_b32 s4, s3                                           // 00000047CB2C: BE840003
	s_delay_alu instid0(VALU_DEP_2)                            // 00000047CB30: BF870002
	v_lshlrev_b32_e32 v12, 2, v13                              // 00000047CB34: 30181A82
	s_waitcnt lgkmcnt(0)                                       // 00000047CB38: BF89FC07
	s_ashr_i32 s35, s17, 31                                    // 00000047CB3C: 86239F11
	s_mul_i32 s34, s19, s3                                     // 00000047CB40: 96220313
	s_lshr_b32 s0, s35, 25                                     // 00000047CB44: 85009923
	s_add_i32 s1, s34, s19                                     // 00000047CB48: 81011322
	s_add_i32 s0, s17, s0                                      // 00000047CB4C: 81000011
	s_mov_b32 s19, exec_lo                                     // 00000047CB50: BE93007E
	s_ashr_i32 s0, s0, 7                                       // 00000047CB54: 86008700
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000047CB58: BF870499
	s_min_i32 s0, s0, s1                                       // 00000047CB5C: 89000100
	s_sub_i32 s11, s0, s34                                     // 00000047CB60: 818B2200
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000047CB64: BF870499
	s_lshl_b32 s10, s11, 1                                     // 00000047CB68: 840A810B
	.long 0xd4c4007e                                           // 00000047CB6C: D4C4007E
	v_cndmask_b32_e32 v1, s10, v11, vcc_lo                     // 00000047CB70: 0202160A
	s_cbranch_execz 506                                        // 00000047CB74: BFA501FA <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi2ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x860>
	s_add_i32 s36, s16, -1                                     // 00000047CB78: 8124C110
	s_cmp_lg_u64 s[30:31], 0                                   // 00000047CB7C: BF11801E
	v_and_b32_e32 v2, 2, v0                                    // 00000047CB80: 36040082
	s_cselect_b32 s37, -1, 0                                   // 00000047CB84: 982580C1
	s_abs_i32 s38, s11                                         // 00000047CB88: BEA6150B
	v_lshlrev_b32_e32 v6, 3, v13                               // 00000047CB8C: 300C1A83
	s_cvt_f32_u32 s0, s38                                      // 00000047CB90: BE806526
	v_dual_mov_b32 v8, v11 :: v_dual_and_b32 v1, 1, v0         // 00000047CB94: CA24010B 08000081
	v_and_b32_e32 v4, 4, v0                                    // 00000047CB9C: 36080084
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000047CBA0: BF870009
	v_rcp_iflag_f32_e32 v3, s0                                 // 00000047CBA4: 7E065600
	v_and_b32_e32 v5, 8, v0                                    // 00000047CBA8: 360A0088
	v_add_nc_u32_e32 v7, s34, v11                              // 00000047CBAC: 4A0E1622
	.long 0xd44a0003                                           // 00000047CBB0: D44A0003
	v_cndmask_b32_e32 v1, 0, v2, vcc_lo                        // 00000047CBB4: 02020480
	v_lshl_or_b32 v2, v11, 8, v6                               // 00000047CBB8: D6560002 0419110B
	s_ashr_i32 s42, s11, 31                                    // 00000047CBC0: 862A9F0B
	s_sub_i32 s9, 0, s38                                       // 00000047CBC4: 81892680
	s_mul_i32 s44, s42, 0x1400                                 // 00000047CBC8: 962CFF2A 00001400
	.long 0xd44c0000                                           // 00000047CBD0: D44C0000
	v_cndmask_b32_e32 v1, 16, v13, vcc_lo                      // 00000047CBD4: 02021A90
	.long 0xd44a0001                                           // 00000047CBD8: D44A0001
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 00000047CBDC: 02020280
	v_readfirstlane_b32 s5, v3                                 // 00000047CBE0: 7E0A0503
	.long 0xd44a0006                                           // 00000047CBE4: D44A0006
	v_cndmask_b32_e32 v1, 0, v5, vcc_lo                        // 00000047CBE8: 02020A80
	v_lshl_or_b32 v1, v7, 7, v12                               // 00000047CBEC: D6560001 04310F07
	v_subrev_nc_u32_e32 v9, s44, v2                            // 00000047CBF4: 4E12042C
	s_lshl_b32 s7, s11, 7                                      // 00000047CBF8: 8407870B
	s_mul_f32 s8, s5, 0x4f7ffffe                               // 00000047CBFC: A208FF05 4F7FFFFE
	.long 0xd44a0005                                           // 00000047CC04: D44A0005
	v_cndmask_b32_e32 v1, 0, v4, vcc_lo                        // 00000047CC08: 02020880
	s_mov_b32 s39, s17                                         // 00000047CC0C: BEA70011
	s_mov_b32 s40, 0                                           // 00000047CC10: BEA80080
	s_cvt_u32_f32 s8, s8                                       // 00000047CC14: BE886708
	s_mov_b32 s41, 0x76543210                                  // 00000047CC18: BEA900FF 76543210
	s_lshl_b32 s43, s11, 8                                     // 00000047CC20: 842B880B
	s_sub_i32 s44, 0, s7                                       // 00000047CC24: 81AC0780
	s_mul_i32 s9, s9, s8                                       // 00000047CC28: 96090809
	s_mov_b32 s46, 0x3db504f3                                  // 00000047CC2C: BEAE00FF 3DB504F3
	s_mul_hi_u32 s9, s8, s9                                    // 00000047CC34: 96890908
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000047CC38: BF870009
	s_add_i32 s45, s8, s9                                      // 00000047CC3C: 812D0908
	s_branch 168                                               // 00000047CC40: BFA000A8 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi2ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x3e4>
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000047CC44: BF870091
	.long 0xd7006a02                                           // 00000047CC48: D7006A02
	v_cndmask_b32_e32 v1, s20, v2, vcc_lo                      // 00000047CC4C: 02020414
	v_add_co_ci_u32_e64 v3, null, s21, v3, vcc_lo              // 00000047CC50: D5207C03 01AA0615
	v_add_nc_u32_e32 v1, 0x400, v1                             // 00000047CC58: 4A0202FF 00000400
	global_load_d16_b16 v2, v[2:3], off offset:6               // 00000047CC60: DC820006 027C0002
	s_waitcnt vmcnt(0)                                         // 00000047CC68: BF8903F7
	v_fma_mix_f32 v5, v17, v2, v15 op_sel_hi:[0,1,0]           // 00000047CC6C: CC200005 143E0511
	v_sub_f32_e32 v4, v18, v16                                 // 00000047CC74: 08082112
	v_fma_mix_f32 v2, -v17, v2, v15 op_sel_hi:[0,1,0]          // 00000047CC78: CC200002 343E0511
	v_add_f32_e32 v3, v18, v16                                 // 00000047CC80: 06062112
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000047CC84: BF8701A2
	v_add_f32_e32 v7, v4, v2                                   // 00000047CC88: 060E0504
	v_sub_f32_e32 v2, v4, v2                                   // 00000047CC8C: 08040504
	v_add_f32_e32 v6, v3, v5                                   // 00000047CC90: 060C0B03
	v_sub_f32_e32 v3, v3, v5                                   // 00000047CC94: 08060B03
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000047CC98: BF870193
	v_mov_b32_dpp v16, v2 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000047CC9C: 7E2002FA FF016102
	v_mov_b32_dpp v4, v6 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000047CCA4: 7E0802FA FF016106
	v_cndmask_b32_e64 v6, -v6, v6, s1                          // 00000047CCAC: D5010006 20060D06
	v_cndmask_b32_e64 v2, -v2, v2, s1                          // 00000047CCB4: D5010002 20060502
	v_mov_b32_dpp v15, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000047CCBC: 7E1E02FA FF016103
	v_cndmask_b32_e64 v3, -v3, v3, s1                          // 00000047CCC4: D5010003 20060703
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 00000047CCCC: BF870144
	v_add_f32_e32 v4, v6, v4                                   // 00000047CCD0: 06080906
	v_mov_b32_dpp v5, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000047CCD4: 7E0A02FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, s1                          // 00000047CCDC: D5010007 20060F07
	.long 0xd72c0006                                           // 00000047CCE4: D72C0006
	v_cndmask_b32_e32 v1, 0x1400, v14, vcc_lo                  // 00000047CCE8: 02021CFF 00001400
	v_dual_add_f32 v2, v2, v16 :: v_dual_add_f32 v5, v7, v5    // 00000047CCF0: C9082102 02040B07
	v_mov_b32_dpp v7, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000047CCF8: 7E0E02FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, s3                          // 00000047CD00: D5010004 200E0904
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000047CD08: BF8701C3
	v_mov_b32_dpp v16, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000047CD0C: 7E2002FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, s3                          // 00000047CD14: D5010002 200E0502
	v_mov_b32_dpp v14, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000047CD1C: 7E1C02FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, s3                          // 00000047CD24: D5010005 200E0B05
	v_dual_add_f32 v3, v3, v15 :: v_dual_add_f32 v2, v2, v16   // 00000047CD2C: C9081F03 03022102
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000047CD34: BF870112
	v_add_f32_e32 v5, v5, v14                                  // 00000047CD38: 060A1D05
	v_mov_b32_dpp v15, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000047CD3C: 7E1E02FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, s3                          // 00000047CD44: D5010003 200E0703
	s_delay_alu instid0(VALU_DEP_4)                            // 00000047CD4C: BF870004
	v_mov_b32_dpp v16, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000047CD50: 7E2002FA FF016402
	v_cndmask_b32_e64 v2, -v2, v2, s5                          // 00000047CD58: D5010002 20160502
	v_mov_b32_dpp v14, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000047CD60: 7E1C02FA FF016405
	v_cndmask_b32_e64 v5, -v5, v5, s5                          // 00000047CD68: D5010005 20160B05
	v_add_f32_e32 v4, v4, v7                                   // 00000047CD70: 06080F04
	.long 0xd72c0007                                           // 00000047CD74: D72C0007
	v_cndmask_b32_e32 v1, s43, v10, vcc_lo                     // 00000047CD78: 0202142B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000047CD7C: BF870193
	v_add_f32_e32 v5, v5, v14                                  // 00000047CD80: 060A1D05
	v_mov_b32_dpp v10, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000047CD84: 7E1402FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s5                          // 00000047CD8C: D5010004 20160904
	v_add_f32_e32 v3, v3, v15                                  // 00000047CD94: 06061F03
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000047CD98: BF870224
	v_mov_b32_dpp v14, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000047CD9C: 7E1C02FA FF016805
	v_cndmask_b32_e64 v5, -v5, v5, s6                          // 00000047CDA4: D5010005 201A0B05
	v_add_f32_e32 v4, v4, v10                                  // 00000047CDAC: 06081504
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 00000047CDB0: BF870254
	v_mov_b32_dpp v15, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000047CDB4: 7E1E02FA FF016403
	v_cndmask_b32_e64 v3, -v3, v3, s5                          // 00000047CDBC: D5010003 20160703
	v_add_nc_u32_e32 v8, 8, v8                                 // 00000047CDC4: 4A101088
	v_dual_add_f32 v2, v2, v16 :: v_dual_add_f32 v5, v5, v14   // 00000047CDC8: C9082102 02041D05
	v_mov_b32_dpp v10, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000047CDD0: 7E1402FA FF016804
	v_add_f32_e32 v3, v3, v15                                  // 00000047CDD8: 06061F03
	v_cndmask_b32_e64 v4, -v4, v4, s6                          // 00000047CDDC: D5010004 201A0904
	s_delay_alu instid0(VALU_DEP_4)                            // 00000047CDE4: BF870004
	v_mov_b32_dpp v16, v2 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000047CDE8: 7E2002FA FF016802
	v_cndmask_b32_e64 v2, -v2, v2, s6                          // 00000047CDF0: D5010002 201A0502
	v_sub_nc_u32_e32 v6, v6, v7                                // 00000047CDF8: 4C0C0F06
	v_mov_b32_dpp v15, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000047CDFC: 7E1E02FA FF016803
	v_cndmask_b32_e64 v3, -v3, v3, s6                          // 00000047CE04: D5010003 201A0703
	v_add_f32_e32 v4, v4, v10                                  // 00000047CE0C: 06081504
	v_cmp_le_i32_e32 vcc_lo, s10, v8                           // 00000047CE10: 7C86100A
	v_add_nc_u32_e32 v6, v9, v6                                // 00000047CE14: 4A0C0D09
	v_add_nc_u32_e32 v9, 0x800, v9                             // 00000047CE18: 4A1212FF 00000800
	v_dual_add_f32 v3, v3, v15 :: v_dual_add_f32 v2, v2, v16   // 00000047CE20: C9081F03 03022102
	s_or_b32 s40, vcc_lo, s40                                  // 00000047CE28: 8C28286A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000047CE2C: BF8701B1
	v_dual_mov_b32 v15, v3 :: v_dual_mov_b32 v16, v2           // 00000047CE30: CA100103 0F100102
	v_cndmask_b32_e64 v2, -v2, v2, s0                          // 00000047CE38: D5010002 20020502
	v_cndmask_b32_e64 v3, -v3, v3, s0                          // 00000047CE40: D5010003 20020703
	v_permlanex16_b32 v15, v15, s41, 0xfedcba98                // 00000047CE48: D65C000F 03FC530F FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000047CE54: BF8701B4
	v_permlanex16_b32 v16, v16, s41, 0xfedcba98                // 00000047CE58: D65C0010 03FC5310 FEDCBA98
	v_mov_b32_e32 v14, v5                                      // 00000047CE64: 7E1C0305
	v_cndmask_b32_e64 v5, -v5, v5, s0                          // 00000047CE68: D5010005 20020B05
	v_add_f32_e32 v7, v2, v16                                  // 00000047CE70: 060E2102
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000047CE74: BF8701B3
	v_permlanex16_b32 v14, v14, s41, 0xfedcba98                // 00000047CE78: D65C000E 03FC530E FEDCBA98
	v_mov_b32_e32 v10, v4                                      // 00000047CE84: 7E140304
	v_cndmask_b32_e64 v4, -v4, v4, s0                          // 00000047CE88: D5010004 20020904
	v_add_f32_e32 v5, v5, v14                                  // 00000047CE90: 060A1D05
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000047CE94: BF870113
	v_permlanex16_b32 v10, v10, s41, 0xfedcba98                // 00000047CE98: D65C000A 03FC530A FEDCBA98
	v_fma_mixhi_f16 v2, v5, s46, 0                             // 00000047CEA4: CC220002 02005D05
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000047CEAC: BF8701B2
	v_add_f32_e32 v4, v4, v10                                  // 00000047CEB0: 06081504
	v_add_f32_e32 v10, v3, v15                                 // 00000047CEB4: 06141F03
	v_fma_mixhi_f16 v3, v7, s46, 0                             // 00000047CEB8: CC220003 02005D07
	v_fma_mixlo_f16 v2, v4, s46, 0                             // 00000047CEC0: CC210002 02005D04
	s_delay_alu instid0(VALU_DEP_3)                            // 00000047CEC8: BF870003
	v_fma_mixlo_f16 v3, v10, s46, 0                            // 00000047CECC: CC210003 02005D0A
	ds_store_b64 v6, v[2:3]                                    // 00000047CED4: D9340000 00000206
	s_and_not1_b32 exec_lo, exec_lo, s40                       // 00000047CEDC: 917E287E
	s_cbranch_execz 287                                        // 00000047CEE0: BFA5011F <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi2ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x860>
	.long 0xd72d0002                                           // 00000047CEE4: D72D0002
	v_cndmask_b32_e32 v0, v8, v45, vcc_lo                      // 00000047CEE8: 02005B08
	s_mov_b32 s7, -1                                           // 00000047CEEC: BE8700C1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000047CEF0: BF870091
	.long 0xd72c0003                                           // 00000047CEF4: D72C0003
	v_cndmask_b32_e32 v0, v2, v38, vcc_lo                      // 00000047CEF8: 02004D02
	v_sub_nc_u32_e32 v3, v8, v3                                // 00000047CEFC: 4C060708
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000047CF00: BF870121
	v_subrev_nc_u32_e32 v5, s38, v3                            // 00000047CF04: 4E0A0626
	v_cmp_le_u32_e32 vcc_lo, s38, v3                           // 00000047CF08: 7C960626
	v_dual_cndmask_b32 v3, v3, v5 :: v_dual_add_nc_u32 v4, 1, v2// 00000047CF0C: CA600B03 03040481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000047CF14: BF870111
	v_cndmask_b32_e32 v2, v2, v4, vcc_lo                       // 00000047CF18: 02040902
	v_cmp_le_u32_e32 vcc_lo, s38, v3                           // 00000047CF1C: 7C960626
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000047CF20: BF870092
	v_add_nc_u32_e32 v4, 1, v2                                 // 00000047CF24: 4A080481
	v_cndmask_b32_e32 v2, v2, v4, vcc_lo                       // 00000047CF28: 02040902
	s_and_not1_b32 vcc_lo, exec_lo, s37                        // 00000047CF2C: 916A257E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000047CF30: BF870091
	v_xor_b32_e32 v14, s42, v2                                 // 00000047CF34: 3A1C042A
	v_subrev_nc_u32_e32 v10, s42, v14                          // 00000047CF38: 4E141C2A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000047CF3C: BF8700A1
	v_mad_u64_u32 v[6:7], null, s44, v10, v[1:2]               // 00000047CF40: D6FE7C06 0406142C
	v_min_i32_e32 v2, s36, v10                                 // 00000047CF48: 22041424
	v_mad_i64_i32 v[4:5], null, v2, s39, 0                     // 00000047CF4C: D6FF7C04 02004F02
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000047CF54: BF870093
	v_ashrrev_i32_e32 v7, 31, v6                               // 00000047CF58: 340E0C9F
	.long 0xd73c0002                                           // 00000047CF5C: D73C0002
	v_cndmask_b32_e32 v1, 1, v6, vcc_lo                        // 00000047CF60: 02020C81
	s_cbranch_vccnz 210                                        // 00000047CF64: BFA400D2 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi2ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x7b0>
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000047CF68: BF870093
	.long 0xd7006a06                                           // 00000047CF6C: D7006A06
	v_cndmask_b32_e32 v1, v4, v6, vcc_lo                       // 00000047CF70: 02020D04
	v_add_co_ci_u32_e64 v7, null, v5, v7, vcc_lo               // 00000047CF74: D5207C07 01AA0F05
	.long 0x7f3e3880                                           // 00000047CF7C: 7F3E3880
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000047CF80: BF870112
	.long 0xd73c0006                                           // 00000047CF84: D73C0006
	v_cndmask_b32_e32 v1, 1, v6, vcc_lo                        // 00000047CF88: 02020C81
	.long 0x7f44399f                                           // 00000047CF8C: 7F44399F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000047CF90: BF870092
	.long 0xd7006a0f                                           // 00000047CF94: D7006A0F
	v_cndmask_b32_e32 v1, s14, v6, vcc_lo                      // 00000047CF98: 02020C0E
	v_add_co_ci_u32_e64 v16, null, s15, v7, vcc_lo             // 00000047CF9C: D5207C10 01AA0E0F
	.long 0xd7006a06                                           // 00000047CFA4: D7006A06
	v_cndmask_b32_e32 v1, s30, v6, vcc_lo                      // 00000047CFA8: 02020C1E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000047CFAC: BF870001
	v_add_co_ci_u32_e64 v7, null, s31, v7, vcc_lo              // 00000047CFB0: D5207C07 01AA0E1F
	global_load_b64 v[15:16], v[15:16], off                    // 00000047CFB8: DC560000 0F7C000F
	.long 0xd7006a11                                           // 00000047CFC0: D7006A11
	v_cndmask_b32_e32 v1, s20, v2, vcc_lo                      // 00000047CFC4: 02020414
	global_load_b64 v[6:7], v[6:7], off                        // 00000047CFC8: DC560000 067C0006
	v_add_co_ci_u32_e64 v18, null, s21, v3, vcc_lo             // 00000047CFD0: D5207C12 01AA0615
	s_clause 0x1                                               // 00000047CFD8: BF850001
	global_load_b32 v19, v[17:18], off                         // 00000047CFDC: DC520000 137C0011
	global_load_d16_b16 v17, v[17:18], off offset:4            // 00000047CFE4: DC820004 117C0011
	s_waitcnt vmcnt(3)                                         // 00000047CFEC: BF890FF7
	.long 0x7e24390f                                           // 00000047CFF0: 7E24390F
	s_waitcnt vmcnt(2)                                         // 00000047CFF4: BF890BF7
	v_and_b32_e32 v41, 0xffff0000, v6                          // 00000047CFF8: 36520CFF FFFF0000
	v_lshlrev_b32_e32 v6, 16, v6                               // 00000047D000: 300C0C90
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000047D004: BF870093
	v_lshlrev_b32_e32 v18, 16, v18                             // 00000047D008: 30242490
	v_mul_f32_e32 v22, 0xbfb8aa3b, v18                         // 00000047D00C: 102C24FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000047D014: BF870291
	v_exp_f32_e32 v22, v22                                     // 00000047D018: 7E2C4B16
	v_dual_add_f32 v22, 1.0, v22 :: v_dual_and_b32 v15, 0xffff0000, v15// 00000047D01C: C9242CF2 160E1EFF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000047D028: BF870111
	v_mul_f32_e32 v21, 0xbfb8aa3b, v15                         // 00000047D02C: 102A1EFF BFB8AA3B
	v_div_scale_f32 v26, null, v22, v22, v18                   // 00000047D034: D6FC7C1A 044A2D16
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000047D03C: BF8701B2
	v_exp_f32_e32 v21, v21                                     // 00000047D040: 7E2A4B15
	v_lshlrev_b32_e32 v20, 16, v16                             // 00000047D044: 30282090
	v_div_scale_f32 v39, s8, v18, v22, v18                     // 00000047D048: D6FC0827 044A2D12
	v_rcp_f32_e32 v30, v26                                     // 00000047D050: 7E3C551A
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000047D054: BF870196
	v_add_f32_e32 v21, 1.0, v21                                // 00000047D058: 062A2AF2
	v_mul_f32_e32 v23, 0xbfb8aa3b, v20                         // 00000047D05C: 102E28FF BFB8AA3B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000047D064: BF870195
	v_fma_f32 v38, -v26, v30, 1.0                              // 00000047D068: D6130026 23CA3D1A
	v_div_scale_f32 v25, null, v21, v21, v15                   // 00000047D070: D6FC7C19 043E2B15
	s_delay_alu instid0(VALU_DEP_3)                            // 00000047D078: BF870003
	v_exp_f32_e32 v23, v23                                     // 00000047D07C: 7E2E4B17
	v_and_b32_e32 v16, 0xffff0000, v16                         // 00000047D080: 362020FF FFFF0000
	v_div_scale_f32 v35, vcc_lo, v15, v21, v15                 // 00000047D088: D6FC6A23 043E2B0F
	v_fmac_f32_e32 v30, v38, v30                               // 00000047D090: 563C3D26
	v_rcp_f32_e32 v28, v25                                     // 00000047D094: 7E385519
	s_delay_alu instid0(TRANS32_DEP_2) | instid1(VALU_DEP_3)   // 00000047D098: BF870186
	v_dual_add_f32 v23, 1.0, v23 :: v_dual_mul_f32 v24, 0xbfb8aa3b, v16// 00000047D09C: C9062EF2 171820FF BFB8AA3B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000047D0A8: BF870115
	v_fma_f32 v36, -v25, v28, 1.0                              // 00000047D0AC: D6130024 23CA3919
	v_div_scale_f32 v27, null, v23, v23, v20                   // 00000047D0B4: D6FC7C1B 04522F17
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000047D0BC: BF8701A3
	v_exp_f32_e32 v24, v24                                     // 00000047D0C0: 7E304B18
	v_div_scale_f32 v37, s7, v20, v23, v20                     // 00000047D0C4: D6FC0725 04522F14
	v_fmac_f32_e32 v28, v36, v28                               // 00000047D0CC: 56383924
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 00000047D0D0: BF870313
	v_rcp_f32_e32 v32, v27                                     // 00000047D0D4: 7E40551B
	v_add_f32_e32 v24, 1.0, v24                                // 00000047D0D8: 063030F2
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000047D0DC: BF870115
	v_fma_f32 v40, -v27, v32, 1.0                              // 00000047D0E0: D6130028 23CA411B
	v_div_scale_f32 v29, null, v24, v24, v16                   // 00000047D0E8: D6FC7C1D 04423118
	v_div_scale_f32 v38, s9, v16, v24, v16                     // 00000047D0F0: D6FC0926 04423110
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000047D0F8: BF870193
	v_fmac_f32_e32 v32, v40, v32                               // 00000047D0FC: 56404128
	v_rcp_f32_e32 v33, v29                                     // 00000047D100: 7E42551D
	v_mul_f32_e32 v40, v35, v28                                // 00000047D104: 10503923
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000047D108: BF870112
	v_mul_f32_e32 v42, v37, v32                                // 00000047D10C: 10544125
	v_fma_f32 v43, -v25, v40, v35                              // 00000047D110: D613002B 248E5119
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000047D118: BF870292
	v_fma_f32 v46, -v27, v42, v37                              // 00000047D11C: D613002E 2496551B
	v_fma_f32 v36, -v29, v33, 1.0                              // 00000047D124: D6130024 23CA431D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000047D12C: BF870113
	v_fmac_f32_e32 v40, v43, v28                               // 00000047D130: 5650392B
	v_dual_fmac_f32 v42, v46, v32 :: v_dual_fmac_f32 v33, v36, v33// 00000047D134: C800412E 2A204324
	v_mul_f32_e32 v36, v39, v30                                // 00000047D13C: 10483D27
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000047D140: BF870193
	v_fma_f32 v25, -v25, v40, v35                              // 00000047D144: D6130019 248E5119
	v_fma_f32 v27, -v27, v42, v37                              // 00000047D14C: D613001B 2496551B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000047D154: BF870214
	v_mul_f32_e32 v44, v38, v33                                // 00000047D158: 10584326
	v_fma_f32 v45, -v26, v36, v39                              // 00000047D15C: D613002D 249E491A
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000047D164: BF8701A4
	v_div_fmas_f32 v25, v25, v28, v40                          // 00000047D168: D6370019 04A23919
	s_mov_b32 vcc_lo, s8                                       // 00000047D170: BEEA0008
	v_fma_f32 v43, -v29, v44, v38                              // 00000047D174: D613002B 249A591D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000047D17C: BF870193
	v_fmac_f32_e32 v36, v45, v30                               // 00000047D180: 56483D2D
	v_div_fixup_f32 v15, v25, v21, v15                         // 00000047D184: D627000F 043E2B19
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000047D18C: BF870193
	v_fmac_f32_e32 v44, v43, v33                               // 00000047D190: 5658432B
	v_fma_f32 v26, -v26, v36, v39                              // 00000047D194: D613001A 249E491A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000047D19C: BF870193
	v_mul_f32_e32 v15, v15, v41                                // 00000047D1A0: 101E530F
	v_fma_f32 v25, -v29, v44, v38                              // 00000047D1A4: D6130019 249A591D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000047D1AC: BF8701A3
	v_div_fmas_f32 v26, v26, v30, v36                          // 00000047D1B0: D637001A 04923D1A
	s_mov_b32 vcc_lo, s7                                       // 00000047D1B8: BEEA0007
	.long 0x7e3e398f                                           // 00000047D1BC: 7E3E398F
	v_div_fmas_f32 v21, v27, v32, v42                          // 00000047D1C0: D6370015 04AA411B
	s_mov_b32 vcc_lo, s9                                       // 00000047D1C8: BEEA0009
	v_div_fixup_f32 v18, v26, v22, v18                         // 00000047D1CC: D6270012 044A2D1A
	v_lshlrev_b32_e32 v22, 16, v7                              // 00000047D1D4: 302C0E90
	v_and_b32_e32 v7, 0xffff0000, v7                           // 00000047D1D8: 360E0EFF FFFF0000
	v_div_fixup_f32 v20, v21, v23, v20                         // 00000047D1E0: D6270014 04522F15
	s_mov_b32 s7, 0                                            // 00000047D1E8: BE870080
	v_mul_f32_e32 v6, v18, v6                                  // 00000047D1EC: 100C0D12
	v_div_fmas_f32 v18, v25, v33, v44                          // 00000047D1F0: D6370012 04B24319
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000047D1F8: BF870193
	v_mul_f32_e32 v20, v20, v22                                // 00000047D1FC: 10282D14
	.long 0x7e443986                                           // 00000047D200: 7E443986
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000047D204: BF870223
	v_div_fixup_f32 v16, v18, v24, v16                         // 00000047D208: D6270010 04423112
	v_and_b32_e32 v18, 1, v31                                  // 00000047D210: 36243E81
	v_bfe_u32 v21, v20, 16, 1                                  // 00000047D214: D6100015 02052114
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000047D21C: BF870193
	v_dual_mul_f32 v7, v16, v7 :: v_dual_and_b32 v22, 1, v34   // 00000047D220: C8E40F10 07164481
	v_add3_u32 v15, v15, v18, 0x7fff                           // 00000047D228: D655000F 03FE250F 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000047D234: BF870193
	v_add3_u32 v16, v20, v21, 0x7fff                           // 00000047D238: D6550010 03FE2B14 00007FFF
	v_add3_u32 v6, v6, v22, 0x7fff                             // 00000047D244: D6550006 03FE2D06 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000047D250: BF870214
	v_bfe_u32 v18, v7, 16, 1                                   // 00000047D254: D6100012 02052107
	v_and_b32_e32 v15, 0xffff0000, v15                         // 00000047D25C: 361E1EFF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000047D264: BF870214
	v_and_b32_e32 v20, 0xffff0000, v16                         // 00000047D268: 362820FF FFFF0000
	v_and_b32_e32 v6, 0xffff0000, v6                           // 00000047D270: 360C0CFF FFFF0000
	s_delay_alu instid0(VALU_DEP_4)                            // 00000047D278: BF870004
	v_add3_u32 v7, v7, v18, 0x7fff                             // 00000047D27C: D6550007 03FE2507 00007FFF
	s_waitcnt vmcnt(1)                                         // 00000047D288: BF8907F7
	v_fma_mix_f32 v16, v19, v15, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 00000047D28C: CC200810 8A021F13
	s_waitcnt vmcnt(0)                                         // 00000047D294: BF8903F7
	v_fma_mix_f32 v15, v17, v20, neg(0) op_sel_hi:[1,0,0]      // 00000047D298: CC20000F 8A022911
	v_fma_mix_f32 v18, v19, v6, neg(0) op_sel_hi:[1,0,0]       // 00000047D2A0: CC200012 8A020D13
	v_and_b32_e32 v17, 0xffff0000, v7                          // 00000047D2A8: 36220EFF FFFF0000
	s_and_not1_b32 vcc_lo, exec_lo, s7                         // 00000047D2B0: 916A077E
	s_cbranch_vccnz 65123                                      // 00000047D2B4: BFA4FE63 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi2ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x144>
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000047D2B8: BF870093
	.long 0xd73c0004                                           // 00000047D2BC: D73C0004
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 00000047D2C0: 02020881
	.long 0xd7006a04                                           // 00000047D2C4: D7006A04
	v_cndmask_b32_e32 v1, s14, v4, vcc_lo                      // 00000047D2C8: 0202080E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000047D2CC: BF870111
	v_add_co_ci_u32_e64 v5, null, s15, v5, vcc_lo              // 00000047D2D0: D5207C05 01AA0A0F
	.long 0xd7006a04                                           // 00000047D2D8: D7006A04
	v_cndmask_b32_e32 v1, v4, v2, vcc_lo                       // 00000047D2DC: 02020504
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000047D2E0: BF8700A1
	v_add_co_ci_u32_e64 v5, null, v5, v3, vcc_lo               // 00000047D2E4: D5207C05 01AA0705
	.long 0xd7006a06                                           // 00000047D2EC: D7006A06
	v_cndmask_b32_e32 v1, s20, v2, vcc_lo                      // 00000047D2F0: 02020414
	v_add_co_ci_u32_e64 v7, null, s21, v3, vcc_lo              // 00000047D2F4: D5207C07 01AA0615
	global_load_b64 v[4:5], v[4:5], off                        // 00000047D2FC: DC560000 047C0004
	s_clause 0x1                                               // 00000047D304: BF850001
	global_load_b32 v17, v[6:7], off                           // 00000047D308: DC520000 117C0006
	global_load_d16_b16 v6, v[6:7], off offset:4               // 00000047D310: DC820004 067C0006
	s_waitcnt vmcnt(2)                                         // 00000047D318: BF890BF7
	.long 0x7e0e3904                                           // 00000047D31C: 7E0E3904
	v_and_b32_e32 v4, 0xffff0000, v4                           // 00000047D320: 360808FF FFFF0000
	v_lshlrev_b32_e32 v15, 16, v5                              // 00000047D328: 301E0A90
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000047D32C: BF8701A3
	v_lshlrev_b32_e32 v7, 16, v7                               // 00000047D330: 300E0E90
	s_waitcnt vmcnt(1)                                         // 00000047D334: BF8907F7
	v_fma_mix_f32 v16, v17, v4, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 00000047D338: CC200810 8A020911
	s_waitcnt vmcnt(0)                                         // 00000047D340: BF8903F7
	v_fma_mix_f32 v15, v6, v15, neg(0) op_sel_hi:[1,0,0]       // 00000047D344: CC20000F 8A021F06
	v_fma_mix_f32 v18, v17, v7, neg(0) op_sel_hi:[1,0,0]       // 00000047D34C: CC200012 8A020F11
	v_and_b32_e32 v17, 0xffff0000, v5                          // 00000047D354: 36220AFF FFFF0000
	s_branch 65081                                             // 00000047D35C: BFA0FE39 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi2ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x144>
	s_or_b32 exec_lo, exec_lo, s19                             // 00000047D360: 8C7E137E
	s_bfe_i32 s10, s11, 0x1001c                                // 00000047D364: 938AFF0B 0001001C
	s_lshl_b32 s3, s11, 3                                      // 00000047D36C: 8403830B
	s_lshr_b64 s[0:1], s[10:11], 29                            // 00000047D370: 85809D0A
	s_lshr_b32 s1, s35, 28                                     // 00000047D374: 85019C23
	s_add_i32 s0, s0, 7                                        // 00000047D378: 81008700
	s_add_i32 s1, s17, s1                                      // 00000047D37C: 81010111
	s_ashr_i32 s0, s0, 3                                       // 00000047D380: 86008300
	s_waitcnt lgkmcnt(0)                                       // 00000047D384: BF89FC07
	.long 0xd72c0001                                           // 00000047D388: D72C0001
	v_cndmask_b32_e32 v1, s0, v11, vcc_lo                      // 00000047D38C: 02021600
	s_barrier                                                  // 00000047D390: BFBD0000
	buffer_gl0_inv                                             // 00000047D394: E0AC0000 00000000
	v_add_nc_u32_e32 v2, s0, v1                                // 00000047D39C: 4A040200
	s_ashr_i32 s0, s1, 4                                       // 00000047D3A0: 86008401
	s_lshl_b32 s1, s34, 3                                      // 00000047D3A4: 84018322
	s_mul_hi_i32 s5, s0, s2                                    // 00000047D3A8: 97050200
	s_mul_i32 s0, s0, s2                                       // 00000047D3AC: 96000200
	v_min_i32_e32 v14, s3, v2                                  // 00000047D3B0: 221C0403
	s_ashr_i32 s3, s1, 31                                      // 00000047D3B4: 86039F01
	s_add_u32 s0, s0, s1                                       // 00000047D3B8: 80000100
	s_addc_u32 s1, s5, s3                                      // 00000047D3BC: 82010305
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000047D3C0: BF870009
	s_lshl_b64 s[6:7], s[0:1], 10                              // 00000047D3C4: 84868A00
	v_cmp_lt_i32_e32 vcc_lo, v1, v14                           // 00000047D3C8: 7C821D01
	s_add_u32 s1, s12, s6                                      // 00000047D3CC: 8001060C
	s_addc_u32 s5, s13, s7                                     // 00000047D3D0: 8205070D
	s_and_saveexec_b32 s3, vcc_lo                              // 00000047D3D4: BE83206A
	s_cbranch_execz 93                                         // 00000047D3D8: BFA5005D <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi2ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0xa50>
	.long 0xd7010002                                           // 00000047D3DC: D7010002
	v_cndmask_b32_e32 v0, v13, v129, vcc_lo                    // 00000047D3E0: 0201030D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000047D3E4: BF870121
	v_cndmask_b32_e64 v3, v2, 31, s0                           // 00000047D3E8: D5010003 00013F02
	v_ashrrev_i32_e32 v2, 31, v1                               // 00000047D3F0: 3404029F
	.long 0xd44c0000                                           // 00000047D3F4: D44C0000
	v_cndmask_b32_e32 v1, 31, v3, vcc_lo                       // 00000047D3F8: 0202069F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000047D3FC: BF870091
	v_cndmask_b32_e64 v5, 0xe1, 1, s0                          // 00000047D400: D5010005 000102FF 000000E1
	v_dual_mov_b32 v4, 0 :: v_dual_add_nc_u32 v7, v5, v3       // 00000047D40C: CA200080 04060705
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000047D414: BF870114
	.long 0xd73c0005                                           // 00000047D418: D73C0005
	v_cndmask_b32_e32 v1, 10, v1, vcc_lo                       // 00000047D41C: 0202028A
	.long 0xd73c0002                                           // 00000047D420: D73C0002
	v_cndmask_b32_e32 v1, 2, v3, vcc_lo                        // 00000047D424: 02020682
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000047D428: BF870223
	v_lshlrev_b32_e32 v4, 24, v7                               // 00000047D42C: 30080E98
	v_bfe_i32 v7, v7, 7, 1                                     // 00000047D430: D6110007 02050F07
	.long 0xd7000008                                           // 00000047D438: D7000008
	v_cndmask_b32_e32 v1, s1, v5, vcc_lo                       // 00000047D43C: 02020A01
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000047D440: BF870211
	v_add_co_ci_u32_e64 v9, null, s5, v6, s0                   // 00000047D444: D5207C09 00020C05
	v_ashrrev_i32_e32 v6, 22, v4                               // 00000047D44C: 340C0896
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000047D450: BF870093
	.long 0xd7000004                                           // 00000047D454: D7000004
	v_cndmask_b32_e32 v1, v8, v2, vcc_lo                       // 00000047D458: 02020508
	v_add_co_ci_u32_e64 v5, null, v9, v3, s0                   // 00000047D45C: D5207C05 00020709
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000047D464: BF870093
	.long 0xd7000006                                           // 00000047D468: D7000006
	v_cndmask_b32_e32 v1, v8, v6, vcc_lo                       // 00000047D46C: 02020D08
	v_add_co_ci_u32_e64 v7, null, v9, v7, s0                   // 00000047D470: D5207C07 00020F09
	.long 0xd7000008                                           // 00000047D478: D7000008
	v_cndmask_b32_e32 v1, v8, v12, vcc_lo                      // 00000047D47C: 02021908
	s_delay_alu instid0(VALU_DEP_1)                            // 00000047D480: BF870001
	v_add_co_ci_u32_e64 v9, null, 0, v9, s0                    // 00000047D484: D5207C09 00021280
	s_clause 0x17                                              // 00000047D48C: BF850017
	global_load_b32 v2, v[4:5], off                            // 00000047D490: DC520000 027C0004
	global_load_b32 v69, v[4:5], off offset:128                // 00000047D498: DC520080 457C0004
	global_load_b32 v66, v[4:5], off offset:256                // 00000047D4A0: DC520100 427C0004
	global_load_b32 v63, v[4:5], off offset:384                // 00000047D4A8: DC520180 3F7C0004
	global_load_b32 v60, v[4:5], off offset:512                // 00000047D4B0: DC520200 3C7C0004
	global_load_b32 v57, v[4:5], off offset:640                // 00000047D4B8: DC520280 397C0004
	global_load_b32 v53, v[4:5], off offset:768                // 00000047D4C0: DC520300 357C0004
	global_load_b32 v35, v[4:5], off offset:896                // 00000047D4C8: DC520380 237C0004
	global_load_b32 v3, v[6:7], off                            // 00000047D4D0: DC520000 037C0006
	global_load_b32 v70, v[6:7], off offset:128                // 00000047D4D8: DC520080 467C0006
	global_load_b32 v67, v[6:7], off offset:256                // 00000047D4E0: DC520100 437C0006
	global_load_b32 v64, v[6:7], off offset:384                // 00000047D4E8: DC520180 407C0006
	global_load_b32 v61, v[6:7], off offset:512                // 00000047D4F0: DC520200 3D7C0006
	global_load_b32 v58, v[6:7], off offset:640                // 00000047D4F8: DC520280 3A7C0006
	global_load_b32 v55, v[6:7], off offset:768                // 00000047D500: DC520300 377C0006
	global_load_b32 v37, v[6:7], off offset:896                // 00000047D508: DC520380 257C0006
	global_load_b32 v71, v[8:9], off                           // 00000047D510: DC520000 477C0008
	global_load_b32 v68, v[8:9], off offset:128                // 00000047D518: DC520080 447C0008
	global_load_b32 v65, v[8:9], off offset:256                // 00000047D520: DC520100 417C0008
	global_load_b32 v62, v[8:9], off offset:384                // 00000047D528: DC520180 3E7C0008
	global_load_b32 v59, v[8:9], off offset:512                // 00000047D530: DC520200 3B7C0008
	global_load_b32 v56, v[8:9], off offset:640                // 00000047D538: DC520280 387C0008
	global_load_b32 v54, v[8:9], off offset:768                // 00000047D540: DC520300 367C0008
	global_load_b32 v36, v[8:9], off offset:896                // 00000047D548: DC520380 247C0008
	s_or_b32 exec_lo, exec_lo, s3                              // 00000047D550: 8C7E037E
	v_dual_mov_b32 v15, 0 :: v_dual_mov_b32 v20, 0             // 00000047D554: CA100080 0F140080
	v_dual_mov_b32 v17, 0 :: v_dual_mov_b32 v24, 0             // 00000047D55C: CA100080 11180080
	v_dual_mov_b32 v19, 0 :: v_dual_mov_b32 v16, 0             // 00000047D564: CA100080 13100080
	v_dual_mov_b32 v21, 0 :: v_dual_mov_b32 v26, 0             // 00000047D56C: CA100080 151A0080
	v_dual_mov_b32 v23, 0 :: v_dual_mov_b32 v18, 0             // 00000047D574: CA100080 17120080
	v_dual_mov_b32 v25, 0 :: v_dual_mov_b32 v22, 0             // 00000047D57C: CA100080 19160080
	v_dual_mov_b32 v28, 0 :: v_dual_mov_b32 v29, 0             // 00000047D584: CA100080 1C1C0080
	v_dual_mov_b32 v27, 0 :: v_dual_mov_b32 v30, 0             // 00000047D58C: CA100080 1B1E0080
	s_ashr_i32 s3, s2, 31                                      // 00000047D594: 86039F02
	s_and_saveexec_b32 s0, vcc_lo                              // 00000047D598: BE80206A
	s_cbranch_execz 1047                                       // 00000047D59C: BFA50417 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi2ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1afc>
	v_dual_mov_b32 v15, 0 :: v_dual_add_nc_u32 v4, -1, v0      // 00000047D5A0: CA200080 0F0400C1
	v_dual_mov_b32 v20, 0 :: v_dual_and_b32 v5, 16, v0         // 00000047D5A8: CA240080 14040090
	v_dual_mov_b32 v24, 0 :: v_dual_add_nc_u32 v9, 1, v1       // 00000047D5B0: CA200080 18080281
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 00000047D5B8: BF870243
	v_dual_mov_b32 v17, 0 :: v_dual_and_b32 v4, 31, v4         // 00000047D5BC: CA240080 1104089F
	v_sub_nc_u32_e32 v31, 0, v14                               // 00000047D5C4: 4C3E1C80
	v_dual_mov_b32 v19, 0 :: v_dual_lshlrev_b32 v32, 2, v13    // 00000047D5C8: CA220080 13201A82
	v_lshl_or_b32 v33, v1, 5, v5                               // 00000047D5D0: D6560021 04150B01
	v_dual_mov_b32 v21, 0 :: v_dual_lshlrev_b32 v34, 2, v4     // 00000047D5D8: CA220080 15220882
	v_dual_mov_b32 v23, 0 :: v_dual_mov_b32 v16, 0             // 00000047D5E0: CA100080 17100080
	v_dual_mov_b32 v25, 0 :: v_dual_mov_b32 v26, 0             // 00000047D5E8: CA100080 191A0080
	v_dual_mov_b32 v18, 0 :: v_dual_mov_b32 v29, 0             // 00000047D5F0: CA100080 121C0080
	v_dual_mov_b32 v22, 0 :: v_dual_mov_b32 v27, 0             // 00000047D5F8: CA100080 161A0080
	v_mov_b32_e32 v28, 0                                       // 00000047D600: 7E380280
	v_mov_b32_e32 v30, 0                                       // 00000047D604: 7E3C0280
	s_mov_b32 s6, 0                                            // 00000047D608: BE860080
	s_mov_b32 s7, 0xdcd12d                                     // 00000047D60C: BE8700FF 00DCD12D
	s_movk_i32 s8, 0x83                                        // 00000047D614: B0080083
	s_movk_i32 s9, 0x1eee                                      // 00000047D618: B0091EEE
	s_branch 958                                               // 00000047D61C: BFA003BE <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi2ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1a18>
	s_or_b32 exec_lo, exec_lo, s10                             // 00000047D620: 8C7E0A7E
	s_waitcnt vmcnt(15)                                        // 00000047D624: BF893FF7
	v_alignbit_b32 v72, v2, v3, 16                             // 00000047D628: D6160048 02420702
	ds_load_b128 v[1:4], v33                                   // 00000047D630: DBFC0000 01000021
	ds_load_b128 v[5:8], v33 offset:5120                       // 00000047D638: DBFC1400 05000021
	s_waitcnt vmcnt(7)                                         // 00000047D640: BF891FF7
	v_bfe_u32 v75, v71, 12, 16                                 // 00000047D644: D610004B 02411947
	v_alignbit_b32 v69, v69, v70, 16                           // 00000047D64C: D6160045 02428D45
	v_alignbit_b32 v66, v66, v67, 16                           // 00000047D654: D6160042 02428742
	v_bfe_u32 v73, v72, 12, 16                                 // 00000047D65C: D6100049 02411948
	v_mul_u32_u24_e32 v77, s7, v73                             // 00000047D664: 169A9207
	v_mul_u32_u24_e32 v73, s8, v73                             // 00000047D668: 16929208
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000047D66C: BF8700C1
	v_lshl_add_u32 v73, v73, 24, v77                           // 00000047D670: D6460049 05353149
	v_bfe_u32 v74, v72, 8, 16                                  // 00000047D678: D610004A 02411148
	v_mul_u32_u24_e32 v78, s7, v74                             // 00000047D680: 169C9407
	v_mul_u32_u24_e32 v74, s8, v74                             // 00000047D684: 16949408
	v_lshl_add_u32 v74, v74, 24, v78                           // 00000047D688: D646004A 0539314A
	v_sad_u8 v73, v73, 0, 0x6400                               // 00000047D690: D6220049 03FD0149 00006400
	v_bfe_u32 v76, v72, 4, 16                                  // 00000047D69C: D610004C 02410948
	v_mul_u32_u24_e32 v77, s7, v76                             // 00000047D6A4: 169A9807
	v_mul_u32_u24_e32 v76, s8, v76                             // 00000047D6A8: 16989808
	v_sad_u8 v74, v74, 0, 0x6400                               // 00000047D6AC: D622004A 03FD014A 00006400
	v_and_b32_e32 v73, 0xffff, v73                             // 00000047D6B8: 369292FF 0000FFFF
	v_lshl_add_u32 v76, v76, 24, v77                           // 00000047D6C0: D646004C 0535314C
	v_bfe_u32 v77, v71, 8, 16                                  // 00000047D6C8: D610004D 02411147
	v_alignbit_b32 v63, v63, v64, 16                           // 00000047D6D0: D616003F 0242813F
	v_alignbit_b32 v60, v60, v61, 16                           // 00000047D6D8: D616003C 02427B3C
	v_lshl_or_b32 v73, v74, 16, v73                            // 00000047D6E0: D6560049 0525214A
	v_sad_u8 v76, v76, 0, 0x6400                               // 00000047D6E8: D622004C 03FD014C 00006400
	v_alignbit_b32 v57, v57, v58, 16                           // 00000047D6F4: D6160039 02427539
	v_alignbit_b32 v35, v35, v37, 16                           // 00000047D6FC: D6160023 02424B23
	v_alignbit_b32 v53, v53, v55, 16                           // 00000047D704: D6160035 02426F35
	v_pk_fma_f16 v73, v73, s9, 0xc931 op_sel_hi:[1,0,0]        // 00000047D70C: CC0E0049 0BFC1349 0000C931
	v_and_b32_e32 v72, 0xffff, v72                             // 00000047D718: 369090FF 0000FFFF
	v_add_nc_u32_e32 v33, 32, v33                              // 00000047D720: 4A4242A0
	v_add_nc_u32_e32 v9, 1, v9                                 // 00000047D724: 4A121281
	s_waitcnt lgkmcnt(0)                                       // 00000047D728: BF89FC07
	v_dot2acc_f32_f16 v27, v73, v5                             // 00000047D72C: 04360B49
	v_mul_u32_u24_e32 v78, s7, v72                             // 00000047D730: 169C9007
	v_mul_u32_u24_e32 v72, s8, v72                             // 00000047D734: 16909008
	v_lshl_add_u32 v72, v72, 24, v78                           // 00000047D738: D6460048 05393148
	v_mul_u32_u24_e32 v78, s7, v75                             // 00000047D740: 169C9607
	v_mul_u32_u24_e32 v75, s8, v75                             // 00000047D744: 16969608
	v_lshl_add_u32 v75, v75, 24, v78                           // 00000047D748: D646004B 0539314B
	v_and_b32_e32 v76, 0xffff, v76                             // 00000047D750: 369898FF 0000FFFF
	v_sad_u8 v72, v72, 0, 0x6400                               // 00000047D758: D6220048 03FD0148 00006400
	v_bfe_u32 v78, v71, 4, 16                                  // 00000047D764: D610004E 02410947
	v_dual_dot2acc_f32_f16 v30, v73, v1 :: v_dual_and_b32 v71, 0xffff, v71// 00000047D76C: CB240349 1E468EFF 0000FFFF
	v_sad_u8 v74, v75, 0, 0x6400                               // 00000047D778: D622004A 03FD014B 00006400
	v_mul_u32_u24_e32 v75, s7, v78                             // 00000047D784: 16969C07
	v_lshl_or_b32 v72, v72, 16, v76                            // 00000047D788: D6560048 05312148
	v_mul_u32_u24_e32 v76, s8, v78                             // 00000047D790: 16989C08
	v_lshl_add_u32 v75, v76, 24, v75                           // 00000047D794: D646004B 052D314C
	v_mul_u32_u24_e32 v76, s7, v77                             // 00000047D79C: 16989A07
	v_mul_u32_u24_e32 v77, s8, v77                             // 00000047D7A0: 169A9A08
	v_lshl_add_u32 v76, v77, 24, v76                           // 00000047D7A4: D646004C 0531314D
	v_mul_u32_u24_e32 v77, s7, v71                             // 00000047D7AC: 169A8E07
	v_mul_u32_u24_e32 v71, s8, v71                             // 00000047D7B0: 168E8E08
	v_sad_u8 v75, v75, 0, 0x6400                               // 00000047D7B4: D622004B 03FD014B 00006400
	v_lshl_add_u32 v71, v71, 24, v77                           // 00000047D7C0: D6460047 05353147
	v_pk_fma_f16 v72, v72, s9, 0xc931 op_sel_hi:[1,0,0]        // 00000047D7C8: CC0E0048 0BFC1348 0000C931
	v_sad_u8 v76, v76, 0, 0x6400                               // 00000047D7D4: D622004C 03FD014C 00006400
	v_bfe_u32 v73, v69, 4, 16                                  // 00000047D7E0: D6100049 02410945
	v_and_b32_e32 v75, 0xffff, v75                             // 00000047D7E8: 369696FF 0000FFFF
	v_sad_u8 v71, v71, 0, 0x6400                               // 00000047D7F0: D6220047 03FD0147 00006400
	v_dot2acc_f32_f16 v30, v72, v2                             // 00000047D7FC: 043C0548
	v_dot2acc_f32_f16 v27, v72, v6                             // 00000047D800: 04360D48
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000047D804: BF870093
	v_lshl_or_b32 v71, v71, 16, v75                            // 00000047D808: D6560047 052D2147
	v_pk_fma_f16 v70, v71, s9, 0xc931 op_sel_hi:[1,0,0]        // 00000047D810: CC0E0046 0BFC1347 0000C931
	v_bfe_u32 v71, v69, 12, 16                                 // 00000047D81C: D6100047 02411945
	v_mul_u32_u24_e32 v72, s7, v71                             // 00000047D824: 16908E07
	v_mul_u32_u24_e32 v71, s8, v71                             // 00000047D828: 168E8E08
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000047D82C: BF8700C1
	v_lshl_add_u32 v71, v71, 24, v72                           // 00000047D830: D6460047 05213147
	v_bfe_u32 v72, v69, 8, 16                                  // 00000047D838: D6100048 02411145
	v_mul_u32_u24_e32 v75, s7, v72                             // 00000047D840: 16969007
	v_mul_u32_u24_e32 v72, s8, v72                             // 00000047D844: 16909008
	v_lshl_add_u32 v72, v72, 24, v75                           // 00000047D848: D6460048 052D3148
	v_sad_u8 v71, v71, 0, 0x6400                               // 00000047D850: D6220047 03FD0147 00006400
	v_mul_u32_u24_e32 v75, s7, v73                             // 00000047D85C: 16969207
	v_mul_u32_u24_e32 v73, s8, v73                             // 00000047D860: 16929208
	v_lshl_add_u32 v73, v73, 24, v75                           // 00000047D864: D6460049 052D3149
	v_sad_u8 v72, v72, 0, 0x6400                               // 00000047D86C: D6220048 03FD0148 00006400
	v_and_b32_e32 v71, 0xffff, v71                             // 00000047D878: 368E8EFF 0000FFFF
	v_and_b32_e32 v69, 0xffff, v69                             // 00000047D880: 368A8AFF 0000FFFF
	s_waitcnt vmcnt(6)                                         // 00000047D888: BF891BF7
	v_bfe_u32 v75, v68, 8, 16                                  // 00000047D88C: D610004B 02411144
	v_sad_u8 v73, v73, 0, 0x6400                               // 00000047D894: D6220049 03FD0149 00006400
	v_lshl_or_b32 v71, v72, 16, v71                            // 00000047D8A0: D6560047 051D2148
	v_mul_u32_u24_e32 v72, s7, v69                             // 00000047D8A8: 16908A07
	v_mul_u32_u24_e32 v69, s8, v69                             // 00000047D8AC: 168A8A08
	v_lshl_add_u32 v69, v69, 24, v72                           // 00000047D8B0: D6460045 05213145
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000047D8B8: BF8701A2
	v_pk_fma_f16 v71, v71, s9, 0xc931 op_sel_hi:[1,0,0]        // 00000047D8BC: CC0E0047 0BFC1347 0000C931
	v_and_b32_e32 v74, 0xffff, v74                             // 00000047D8C8: 369494FF 0000FFFF
	v_sad_u8 v69, v69, 0, 0x6400                               // 00000047D8D0: D6220045 03FD0145 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000047D8DC: BF870193
	v_dot2acc_f32_f16 v29, v71, v1                             // 00000047D8E0: 043A0347
	v_lshl_or_b32 v74, v76, 16, v74                            // 00000047D8E4: D656004A 0529214C
	v_bfe_u32 v76, v68, 4, 16                                  // 00000047D8EC: D610004C 02410944
	v_dot2acc_f32_f16 v28, v71, v5                             // 00000047D8F4: 04380B47
	v_bfe_u32 v71, v66, 4, 16                                  // 00000047D8F8: D6100047 02410942
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000047D900: BF870094
	v_pk_fma_f16 v74, v74, s9, 0xc931 op_sel_hi:[1,0,0]        // 00000047D904: CC0E004A 0BFC134A 0000C931
	v_dot2acc_f32_f16 v30, v74, v3                             // 00000047D910: 043C074A
	v_dot2acc_f32_f16 v27, v74, v7                             // 00000047D914: 04360F4A
	v_bfe_u32 v74, v68, 12, 16                                 // 00000047D918: D610004A 02411944
	v_and_b32_e32 v68, 0xffff, v68                             // 00000047D920: 368888FF 0000FFFF
	v_and_b32_e32 v72, 0xffff, v73                             // 00000047D928: 369092FF 0000FFFF
	v_mul_u32_u24_e32 v73, s7, v74                             // 00000047D930: 16929407
	v_mul_u32_u24_e32 v74, s8, v74                             // 00000047D934: 16949408
	v_lshl_add_u32 v73, v74, 24, v73                           // 00000047D938: D6460049 0525314A
	v_mul_u32_u24_e32 v74, s7, v76                             // 00000047D940: 16949807
	v_mul_u32_u24_e32 v76, s8, v76                             // 00000047D944: 16989808
	v_lshl_add_u32 v74, v76, 24, v74                           // 00000047D948: D646004A 0529314C
	v_mul_u32_u24_e32 v76, s7, v75                             // 00000047D950: 16989607
	v_mul_u32_u24_e32 v75, s8, v75                             // 00000047D954: 16969608
	v_sad_u8 v73, v73, 0, 0x6400                               // 00000047D958: D6220049 03FD0149 00006400
	v_lshl_add_u32 v75, v75, 24, v76                           // 00000047D964: D646004B 0531314B
	v_dot2acc_f32_f16 v27, v70, v8                             // 00000047D96C: 04361146
	v_lshl_or_b32 v69, v69, 16, v72                            // 00000047D970: D6560045 05212145
	v_mul_u32_u24_e32 v76, s7, v68                             // 00000047D978: 16988807
	v_mul_u32_u24_e32 v68, s8, v68                             // 00000047D97C: 16888808
	v_sad_u8 v74, v74, 0, 0x6400                               // 00000047D980: D622004A 03FD014A 00006400
	v_lshl_add_u32 v68, v68, 24, v76                           // 00000047D98C: D6460044 05313144
	v_pk_fma_f16 v67, v69, s9, 0xc931 op_sel_hi:[1,0,0]        // 00000047D994: CC0E0043 0BFC1345 0000C931
	v_and_b32_e32 v72, 0xffff, v73                             // 00000047D9A0: 369092FF 0000FFFF
	v_sad_u8 v73, v75, 0, 0x6400                               // 00000047D9A8: D6220049 03FD014B 00006400
	v_dot2acc_f32_f16 v30, v70, v4                             // 00000047D9B4: 043C0946
	v_sad_u8 v68, v68, 0, 0x6400                               // 00000047D9B8: D6220044 03FD0144 00006400
	v_dot2acc_f32_f16 v29, v67, v2                             // 00000047D9C4: 043A0543
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000047D9C8: BF8700C4
	v_lshl_or_b32 v69, v73, 16, v72                            // 00000047D9CC: D6560045 05212149
	v_bfe_u32 v72, v66, 12, 16                                 // 00000047D9D4: D6100048 02411942
	v_mul_u32_u24_e32 v70, s7, v72                             // 00000047D9DC: 168C9007
	v_mul_u32_u24_e32 v72, s8, v72                             // 00000047D9E0: 16909008
	v_lshl_add_u32 v70, v72, 24, v70                           // 00000047D9E4: D6460046 05193148
	v_pk_fma_f16 v69, v69, s9, 0xc931 op_sel_hi:[1,0,0]        // 00000047D9EC: CC0E0045 0BFC1345 0000C931
	v_and_b32_e32 v74, 0xffff, v74                             // 00000047D9F8: 369494FF 0000FFFF
	v_bfe_u32 v72, v66, 8, 16                                  // 00000047DA00: D6100048 02411142
	v_mul_u32_u24_e32 v73, s7, v72                             // 00000047DA08: 16929007
	v_mul_u32_u24_e32 v72, s8, v72                             // 00000047DA0C: 16909008
	v_dot2acc_f32_f16 v29, v69, v3                             // 00000047DA10: 043A0745
	v_lshl_or_b32 v68, v68, 16, v74                            // 00000047DA14: D6560044 05292144
	v_mul_u32_u24_e32 v74, s7, v71                             // 00000047DA1C: 16948E07
	v_mul_u32_u24_e32 v71, s8, v71                             // 00000047DA20: 168E8E08
	v_lshl_add_u32 v71, v71, 24, v74                           // 00000047DA24: D6460047 05293147
	v_sad_u8 v70, v70, 0, 0x6400                               // 00000047DA2C: D6220046 03FD0146 00006400
	v_pk_fma_f16 v68, v68, s9, 0xc931 op_sel_hi:[1,0,0]        // 00000047DA38: CC0E0044 0BFC1344 0000C931
	v_and_b32_e32 v66, 0xffff, v66                             // 00000047DA44: 368484FF 0000FFFF
	v_lshl_add_u32 v72, v72, 24, v73                           // 00000047DA4C: D6460048 05253148
	v_sad_u8 v71, v71, 0, 0x6400                               // 00000047DA54: D6220047 03FD0147 00006400
	s_waitcnt vmcnt(5)                                         // 00000047DA60: BF8917F7
	v_bfe_u32 v73, v65, 12, 16                                 // 00000047DA64: D6100049 02411941
	v_dot2acc_f32_f16 v29, v68, v4                             // 00000047DA6C: 043A0944
	v_mul_u32_u24_e32 v75, s7, v66                             // 00000047DA70: 16968407
	v_mul_u32_u24_e32 v66, s8, v66                             // 00000047DA74: 16848408
	v_lshl_add_u32 v66, v66, 24, v75                           // 00000047DA78: D6460042 052D3142
	v_and_b32_e32 v71, 0xffff, v71                             // 00000047DA80: 368E8EFF 0000FFFF
	v_mul_u32_u24_e32 v75, s7, v73                             // 00000047DA88: 16969207
	v_mul_u32_u24_e32 v73, s8, v73                             // 00000047DA8C: 16929208
	v_and_b32_e32 v70, 0xffff, v70                             // 00000047DA90: 368C8CFF 0000FFFF
	v_sad_u8 v66, v66, 0, 0x6400                               // 00000047DA98: D6220042 03FD0142 00006400
	v_sad_u8 v72, v72, 0, 0x6400                               // 00000047DAA4: D6220048 03FD0148 00006400
	v_lshl_add_u32 v73, v73, 24, v75                           // 00000047DAB0: D6460049 052D3149
	v_bfe_u32 v75, v65, 4, 16                                  // 00000047DAB8: D610004B 02410941
	v_bfe_u32 v74, v65, 8, 16                                  // 00000047DAC0: D610004A 02411141
	v_lshl_or_b32 v66, v66, 16, v71                            // 00000047DAC8: D6560042 051D2142
	v_mul_u32_u24_e32 v71, s7, v75                             // 00000047DAD0: 168E9607
	v_lshl_or_b32 v70, v72, 16, v70                            // 00000047DAD4: D6560046 05192148
	v_sad_u8 v72, v73, 0, 0x6400                               // 00000047DADC: D6220048 03FD0149 00006400
	v_mul_u32_u24_e32 v73, s8, v75                             // 00000047DAE8: 16929608
	v_lshl_add_u32 v71, v73, 24, v71                           // 00000047DAEC: D6460047 051D3149
	v_dual_dot2acc_f32_f16 v28, v67, v6 :: v_dual_and_b32 v65, 0xffff, v65// 00000047DAF4: CB240D43 1C4082FF 0000FFFF
	v_mul_u32_u24_e32 v73, s7, v74                             // 00000047DB00: 16929407
	v_mul_u32_u24_e32 v74, s8, v74                             // 00000047DB04: 16949408
	v_lshl_add_u32 v73, v74, 24, v73                           // 00000047DB08: D6460049 0525314A
	v_mul_u32_u24_e32 v74, s7, v65                             // 00000047DB10: 16948207
	v_mul_u32_u24_e32 v65, s8, v65                             // 00000047DB14: 16828208
	v_sad_u8 v71, v71, 0, 0x6400                               // 00000047DB18: D6220047 03FD0147 00006400
	v_lshl_add_u32 v65, v65, 24, v74                           // 00000047DB24: D6460041 05293141
	v_pk_fma_f16 v70, v70, s9, 0xc931 op_sel_hi:[1,0,0]        // 00000047DB2C: CC0E0046 0BFC1346 0000C931
	v_pk_fma_f16 v66, v66, s9, 0xc931 op_sel_hi:[1,0,0]        // 00000047DB38: CC0E0042 0BFC1342 0000C931
	v_sad_u8 v73, v73, 0, 0x6400                               // 00000047DB44: D6220049 03FD0149 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000047DB50: BF870214
	v_sad_u8 v65, v65, 0, 0x6400                               // 00000047DB54: D6220041 03FD0141 00006400
	v_dual_dot2acc_f32_f16 v22, v70, v1 :: v_dual_and_b32 v71, 0xffff, v71// 00000047DB60: CB240346 16468EFF 0000FFFF
	v_dot2acc_f32_f16 v18, v70, v5                             // 00000047DB6C: 04240B46
	s_waitcnt vmcnt(4)                                         // 00000047DB70: BF8913F7
	v_bfe_u32 v70, v62, 4, 16                                  // 00000047DB74: D6100046 0241093E
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000047DB7C: BF870133
	v_dot2acc_f32_f16 v22, v66, v2                             // 00000047DB80: 042C0542
	v_lshl_or_b32 v65, v65, 16, v71                            // 00000047DB84: D6560041 051D2141
	v_dual_dot2acc_f32_f16 v18, v66, v6 :: v_dual_mov_b32 v71, v52// 00000047DB8C: CB100D42 12460134
	v_pk_fma_f16 v64, v65, s9, 0xc931 op_sel_hi:[1,0,0]        // 00000047DB94: CC0E0040 0BFC1341 0000C931
	v_bfe_u32 v65, v63, 12, 16                                 // 00000047DBA0: D6100041 0241193F
	v_mul_u32_u24_e32 v66, s7, v65                             // 00000047DBA8: 16848207
	v_mul_u32_u24_e32 v65, s8, v65                             // 00000047DBAC: 16828208
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000047DBB0: BF870121
	v_lshl_add_u32 v65, v65, 24, v66                           // 00000047DBB4: D6460041 05093141
	v_bfe_u32 v66, v63, 8, 16                                  // 00000047DBBC: D6100042 0241113F
	v_sad_u8 v65, v65, 0, 0x6400                               // 00000047DBC4: D6220041 03FD0141 00006400
	v_dot2acc_f32_f16 v28, v69, v7                             // 00000047DBD0: 04380F45
	v_mul_u32_u24_e32 v69, s7, v66                             // 00000047DBD4: 168A8407
	v_mul_u32_u24_e32 v66, s8, v66                             // 00000047DBD8: 16848408
	v_lshl_add_u32 v66, v66, 24, v69                           // 00000047DBDC: D6460042 05153142
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000047DBE4: BF8701A2
	v_dual_dot2acc_f32_f16 v28, v68, v8 :: v_dual_and_b32 v65, 0xffff, v65// 00000047DBE8: CB241144 1C4082FF 0000FFFF
	v_bfe_u32 v68, v62, 12, 16                                 // 00000047DBF4: D6100044 0241193E
	v_sad_u8 v66, v66, 0, 0x6400                               // 00000047DBFC: D6220042 03FD0142 00006400
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000047DC08: BF870091
	v_lshl_or_b32 v65, v66, 16, v65                            // 00000047DC0C: D6560041 05052142
	v_pk_fma_f16 v65, v65, s9, 0xc931 op_sel_hi:[1,0,0]        // 00000047DC14: CC0E0041 0BFC1341 0000C931
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000047DC20: BF8701B1
	v_dual_dot2acc_f32_f16 v25, v65, v5 :: v_dual_and_b32 v72, 0xffff, v72// 00000047DC24: CB240B41 194890FF 0000FFFF
	v_dot2acc_f32_f16 v26, v65, v1                             // 00000047DC30: 04340341
	v_bfe_u32 v65, v60, 4, 16                                  // 00000047DC34: D6100041 0241093C
	v_lshl_or_b32 v72, v73, 16, v72                            // 00000047DC3C: D6560048 05212149
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000047DC44: BF870091
	v_pk_fma_f16 v67, v72, s9, 0xc931 op_sel_hi:[1,0,0]        // 00000047DC48: CC0E0043 0BFC1348 0000C931
	v_dot2acc_f32_f16 v22, v67, v3                             // 00000047DC54: 042C0743
	v_dot2acc_f32_f16 v18, v67, v7                             // 00000047DC58: 04240F43
	v_bfe_u32 v67, v63, 4, 16                                  // 00000047DC5C: D6100043 0241093F
	v_mul_u32_u24_e32 v69, s7, v67                             // 00000047DC64: 168A8607
	v_mul_u32_u24_e32 v67, s8, v67                             // 00000047DC68: 16868608
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000047DC6C: BF8700C1
	v_lshl_add_u32 v67, v67, 24, v69                           // 00000047DC70: D6460043 05153143
	v_and_b32_e32 v63, 0xffff, v63                             // 00000047DC78: 367E7EFF 0000FFFF
	v_mul_u32_u24_e32 v66, s7, v63                             // 00000047DC80: 16847E07
	v_mul_u32_u24_e32 v63, s8, v63                             // 00000047DC84: 167E7E08
	v_lshl_add_u32 v63, v63, 24, v66                           // 00000047DC88: D646003F 0509313F
	v_sad_u8 v67, v67, 0, 0x6400                               // 00000047DC90: D6220043 03FD0143 00006400
	v_bfe_u32 v69, v62, 8, 16                                  // 00000047DC9C: D6100045 0241113E
	v_and_b32_e32 v62, 0xffff, v62                             // 00000047DCA4: 367C7CFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000047DCAC: BF870214
	v_sad_u8 v63, v63, 0, 0x6400                               // 00000047DCB0: D622003F 03FD013F 00006400
	v_and_b32_e32 v66, 0xffff, v67                             // 00000047DCBC: 368486FF 0000FFFF
	v_mul_u32_u24_e32 v67, s7, v68                             // 00000047DCC4: 16868807
	v_mul_u32_u24_e32 v68, s8, v68                             // 00000047DCC8: 16888808
	v_lshl_add_u32 v67, v68, 24, v67                           // 00000047DCCC: D6460043 050D3144
	v_mul_u32_u24_e32 v68, s7, v70                             // 00000047DCD4: 16888C07
	v_mul_u32_u24_e32 v70, s8, v70                             // 00000047DCD8: 168C8C08
	v_lshl_add_u32 v68, v70, 24, v68                           // 00000047DCDC: D6460044 05113146
	v_mul_u32_u24_e32 v70, s7, v69                             // 00000047DCE4: 168C8A07
	v_mul_u32_u24_e32 v69, s8, v69                             // 00000047DCE8: 168A8A08
	v_lshl_add_u32 v69, v69, 24, v70                           // 00000047DCEC: D6460045 05193145
	v_mul_u32_u24_e32 v70, s7, v62                             // 00000047DCF4: 168C7C07
	v_mul_u32_u24_e32 v62, s8, v62                             // 00000047DCF8: 167C7C08
	v_sad_u8 v68, v68, 0, 0x6400                               // 00000047DCFC: D6220044 03FD0144 00006400
	v_lshl_add_u32 v62, v62, 24, v70                           // 00000047DD08: D646003E 0519313E
	v_sad_u8 v67, v67, 0, 0x6400                               // 00000047DD10: D6220043 03FD0143 00006400
	v_lshl_or_b32 v63, v63, 16, v66                            // 00000047DD1C: D656003F 0509213F
	v_mov_b32_e32 v70, v51                                     // 00000047DD24: 7E8C0333
	v_and_b32_e32 v68, 0xffff, v68                             // 00000047DD28: 368888FF 0000FFFF
	v_sad_u8 v62, v62, 0, 0x6400                               // 00000047DD30: D622003E 03FD013E 00006400
	v_and_b32_e32 v66, 0xffff, v67                             // 00000047DD3C: 368486FF 0000FFFF
	v_sad_u8 v67, v69, 0, 0x6400                               // 00000047DD44: D6220043 03FD0145 00006400
	v_pk_fma_f16 v61, v63, s9, 0xc931 op_sel_hi:[1,0,0]        // 00000047DD50: CC0E003D 0BFC133F 0000C931
	s_delay_alu instid0(VALU_DEP_4)                            // 00000047DD5C: BF870004
	v_lshl_or_b32 v62, v62, 16, v68                            // 00000047DD60: D656003E 0511213E
	v_mul_u32_u24_e32 v68, s7, v65                             // 00000047DD68: 16888207
	v_mul_u32_u24_e32 v65, s8, v65                             // 00000047DD6C: 16828208
	v_lshl_or_b32 v63, v67, 16, v66                            // 00000047DD70: D656003F 05092143
	v_lshl_add_u32 v65, v65, 24, v68                           // 00000047DD78: D6460041 05113141
	v_dot2acc_f32_f16 v25, v61, v6                             // 00000047DD80: 04320D3D
	v_pk_fma_f16 v62, v62, s9, 0xc931 op_sel_hi:[1,0,0]        // 00000047DD84: CC0E003E 0BFC133E 0000C931
	v_bfe_u32 v66, v60, 12, 16                                 // 00000047DD90: D6100042 0241193C
	v_pk_fma_f16 v63, v63, s9, 0xc931 op_sel_hi:[1,0,0]        // 00000047DD98: CC0E003F 0BFC133F 0000C931
	v_sad_u8 v65, v65, 0, 0x6400                               // 00000047DDA4: D6220041 03FD0141 00006400
	s_waitcnt vmcnt(3)                                         // 00000047DDB0: BF890FF7
	v_bfe_u32 v68, v59, 8, 16                                  // 00000047DDB4: D6100044 0241113B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000047DDBC: BF870193
	v_dot2acc_f32_f16 v25, v63, v7                             // 00000047DDC0: 04320F3F
	v_dual_dot2acc_f32_f16 v22, v64, v4 :: v_dual_and_b32 v65, 0xffff, v65// 00000047DDC4: CB240940 164082FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_2)                            // 00000047DDD0: BF870002
	v_dot2acc_f32_f16 v25, v62, v8                             // 00000047DDD4: 0432113E
	v_dot2acc_f32_f16 v18, v64, v8                             // 00000047DDD8: 04241140
	v_mul_u32_u24_e32 v64, s7, v66                             // 00000047DDDC: 16808407
	v_mul_u32_u24_e32 v66, s8, v66                             // 00000047DDE0: 16848408
	v_lshl_add_u32 v64, v66, 24, v64                           // 00000047DDE4: D6460040 05013142
	v_bfe_u32 v66, v60, 8, 16                                  // 00000047DDEC: D6100042 0241113C
	v_and_b32_e32 v60, 0xffff, v60                             // 00000047DDF4: 367878FF 0000FFFF
	v_mul_u32_u24_e32 v69, s7, v60                             // 00000047DDFC: 168A7807
	v_mul_u32_u24_e32 v60, s8, v60                             // 00000047DE00: 16787808
	v_mul_u32_u24_e32 v67, s7, v66                             // 00000047DE04: 16868407
	v_mul_u32_u24_e32 v66, s8, v66                             // 00000047DE08: 16848408
	v_lshl_add_u32 v60, v60, 24, v69                           // 00000047DE0C: D646003C 0515313C
	v_sad_u8 v64, v64, 0, 0x6400                               // 00000047DE14: D6220040 03FD0140 00006400
	v_lshl_add_u32 v66, v66, 24, v67                           // 00000047DE20: D6460042 050D3142
	v_bfe_u32 v67, v59, 12, 16                                 // 00000047DE28: D6100043 0241193B
	v_mul_u32_u24_e32 v69, s7, v67                             // 00000047DE30: 168A8607
	v_mul_u32_u24_e32 v67, s8, v67                             // 00000047DE34: 16868608
	v_sad_u8 v60, v60, 0, 0x6400                               // 00000047DE38: D622003C 03FD013C 00006400
	v_and_b32_e32 v64, 0xffff, v64                             // 00000047DE44: 368080FF 0000FFFF
	v_sad_u8 v66, v66, 0, 0x6400                               // 00000047DE4C: D6220042 03FD0142 00006400
	v_lshl_add_u32 v67, v67, 24, v69                           // 00000047DE58: D6460043 05153143
	v_bfe_u32 v69, v59, 4, 16                                  // 00000047DE60: D6100045 0241093B
	v_lshl_or_b32 v60, v60, 16, v65                            // 00000047DE68: D656003C 0505213C
	v_mul_u32_u24_e32 v65, s7, v69                             // 00000047DE70: 16828A07
	v_lshl_or_b32 v64, v66, 16, v64                            // 00000047DE74: D6560040 05012142
	v_sad_u8 v66, v67, 0, 0x6400                               // 00000047DE7C: D6220042 03FD0143 00006400
	v_mul_u32_u24_e32 v67, s8, v69                             // 00000047DE88: 16868A08
	v_lshl_add_u32 v65, v67, 24, v65                           // 00000047DE8C: D6460041 05053143
	v_and_b32_e32 v59, 0xffff, v59                             // 00000047DE94: 367676FF 0000FFFF
	v_mul_u32_u24_e32 v67, s7, v68                             // 00000047DE9C: 16868807
	v_mul_u32_u24_e32 v68, s8, v68                             // 00000047DEA0: 16888808
	v_lshl_add_u32 v67, v68, 24, v67                           // 00000047DEA4: D6460043 050D3144
	v_mul_u32_u24_e32 v68, s7, v59                             // 00000047DEAC: 16887607
	v_mul_u32_u24_e32 v59, s8, v59                             // 00000047DEB0: 16767608
	v_sad_u8 v65, v65, 0, 0x6400                               // 00000047DEB4: D6220041 03FD0141 00006400
	v_lshl_add_u32 v59, v59, 24, v68                           // 00000047DEC0: D646003B 0511313B
	v_pk_fma_f16 v64, v64, s9, 0xc931 op_sel_hi:[1,0,0]        // 00000047DEC8: CC0E0040 0BFC1340 0000C931
	v_pk_fma_f16 v60, v60, s9, 0xc931 op_sel_hi:[1,0,0]        // 00000047DED4: CC0E003C 0BFC133C 0000C931
	v_and_b32_e32 v66, 0xffff, v66                             // 00000047DEE0: 368484FF 0000FFFF
	v_and_b32_e32 v65, 0xffff, v65                             // 00000047DEE8: 368282FF 0000FFFF
	v_sad_u8 v59, v59, 0, 0x6400                               // 00000047DEF0: D622003B 03FD013B 00006400
	v_dot2acc_f32_f16 v16, v64, v1                             // 00000047DEFC: 04200340
	v_dot2acc_f32_f16 v24, v64, v5                             // 00000047DF00: 04300B40
	v_sad_u8 v67, v67, 0, 0x6400                               // 00000047DF04: D6220043 03FD0143 00006400
	s_waitcnt vmcnt(2)                                         // 00000047DF10: BF890BF7
	v_bfe_u32 v64, v56, 4, 16                                  // 00000047DF14: D6100040 02410938
	v_lshl_or_b32 v59, v59, 16, v65                            // 00000047DF1C: D656003B 0505213B
	v_dot2acc_f32_f16 v16, v60, v2                             // 00000047DF24: 0420053C
	v_dot2acc_f32_f16 v24, v60, v6                             // 00000047DF28: 04300D3C
	v_lshl_or_b32 v66, v67, 16, v66                            // 00000047DF2C: D6560042 05092143
	v_mov_b32_e32 v67, v50                                     // 00000047DF34: 7E860332
	v_pk_fma_f16 v58, v59, s9, 0xc931 op_sel_hi:[1,0,0]        // 00000047DF38: CC0E003A 0BFC133B 0000C931
	v_bfe_u32 v59, v57, 12, 16                                 // 00000047DF44: D610003B 02411939
	v_mul_u32_u24_e32 v60, s7, v59                             // 00000047DF4C: 16787607
	v_mul_u32_u24_e32 v59, s8, v59                             // 00000047DF50: 16767608
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 00000047DF54: BF870241
	v_lshl_add_u32 v59, v59, 24, v60                           // 00000047DF58: D646003B 04F1313B
	v_bfe_u32 v60, v57, 8, 16                                  // 00000047DF60: D610003C 02411139
	v_dual_mov_b32 v68, v51 :: v_dual_mov_b32 v69, v45         // 00000047DF68: CA100133 4444012D
	v_mov_b32_e32 v65, v50                                     // 00000047DF70: 7E820332
	v_sad_u8 v59, v59, 0, 0x6400                               // 00000047DF74: D622003B 03FD013B 00006400
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000047DF80: BF8701B1
	v_dual_dot2acc_f32_f16 v26, v61, v2 :: v_dual_and_b32 v59, 0xffff, v59// 00000047DF84: CB24053D 1A3A76FF 0000FFFF
	v_pk_fma_f16 v61, v66, s9, 0xc931 op_sel_hi:[1,0,0]        // 00000047DF90: CC0E003D 0BFC1342 0000C931
	v_mov_b32_e32 v66, v42                                     // 00000047DF9C: 7E84032A
	v_dot2acc_f32_f16 v26, v63, v3                             // 00000047DFA0: 0434073F
	v_mul_u32_u24_e32 v63, s7, v60                             // 00000047DFA4: 167E7807
	v_mul_u32_u24_e32 v60, s8, v60                             // 00000047DFA8: 16787808
	v_lshl_add_u32 v60, v60, 24, v63                           // 00000047DFAC: D646003C 04FD313C
	v_dot2acc_f32_f16 v16, v61, v3                             // 00000047DFB4: 0420073D
	v_dot2acc_f32_f16 v24, v61, v7                             // 00000047DFB8: 04300F3D
	v_bfe_u32 v61, v57, 4, 16                                  // 00000047DFBC: D610003D 02410939
	v_mul_u32_u24_e32 v63, s7, v61                             // 00000047DFC4: 167E7A07
	v_mul_u32_u24_e32 v61, s8, v61                             // 00000047DFC8: 167A7A08
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 00000047DFCC: BF870241
	v_lshl_add_u32 v61, v61, 24, v63                           // 00000047DFD0: D646003D 04FD313D
	v_sad_u8 v60, v60, 0, 0x6400                               // 00000047DFD8: D622003C 03FD013C 00006400
	v_dual_dot2acc_f32_f16 v26, v62, v4 :: v_dual_and_b32 v57, 0xffff, v57// 00000047DFE4: CB24093E 1A3872FF 0000FFFF
	v_bfe_u32 v62, v56, 12, 16                                 // 00000047DFF0: D610003E 02411938
	v_sad_u8 v61, v61, 0, 0x6400                               // 00000047DFF8: D622003D 03FD013D 00006400
	s_delay_alu instid0(VALU_DEP_4)                            // 00000047E004: BF870004
	v_lshl_or_b32 v59, v60, 16, v59                            // 00000047E008: D656003B 04ED213C
	v_mul_u32_u24_e32 v60, s7, v57                             // 00000047E010: 16787207
	v_mul_u32_u24_e32 v57, s8, v57                             // 00000047E014: 16727208
	v_lshl_add_u32 v57, v57, 24, v60                           // 00000047E018: D6460039 04F13139
	v_and_b32_e32 v60, 0xffff, v61                             // 00000047E020: 36787AFF 0000FFFF
	v_mul_u32_u24_e32 v61, s7, v62                             // 00000047E028: 167A7C07
	v_mul_u32_u24_e32 v62, s8, v62                             // 00000047E02C: 167C7C08
	v_lshl_add_u32 v61, v62, 24, v61                           // 00000047E030: D646003D 04F5313E
	v_sad_u8 v57, v57, 0, 0x6400                               // 00000047E038: D6220039 03FD0139 00006400
	v_bfe_u32 v63, v56, 8, 16                                  // 00000047E044: D610003F 02411138
	v_mul_u32_u24_e32 v62, s7, v64                             // 00000047E04C: 167C8007
	v_mul_u32_u24_e32 v64, s8, v64                             // 00000047E050: 16808008
	v_lshl_add_u32 v62, v64, 24, v62                           // 00000047E054: D646003E 04F93140
	v_mul_u32_u24_e32 v64, s7, v63                             // 00000047E05C: 16807E07
	v_mul_u32_u24_e32 v63, s8, v63                             // 00000047E060: 167E7E08
	v_sad_u8 v61, v61, 0, 0x6400                               // 00000047E064: D622003D 03FD013D 00006400
	v_lshl_add_u32 v63, v63, 24, v64                           // 00000047E070: D646003F 0501313F
	v_lshl_or_b32 v57, v57, 16, v60                            // 00000047E078: D6560039 04F12139
	v_pk_fma_f16 v59, v59, s9, 0xc931 op_sel_hi:[1,0,0]        // 00000047E080: CC0E003B 0BFC133B 0000C931
	v_dot2acc_f32_f16 v16, v58, v4                             // 00000047E08C: 0420093A
	v_and_b32_e32 v60, 0xffff, v61                             // 00000047E090: 36787AFF 0000FFFF
	v_sad_u8 v61, v63, 0, 0x6400                               // 00000047E098: D622003D 03FD013F 00006400
	v_pk_fma_f16 v57, v57, s9, 0xc931 op_sel_hi:[1,0,0]        // 00000047E0A4: CC0E0039 0BFC1339 0000C931
	v_dot2acc_f32_f16 v23, v59, v1                             // 00000047E0B0: 042E033B
	v_dual_dot2acc_f32_f16 v21, v59, v5 :: v_dual_dot2acc_f32_f16 v24, v58, v8// 00000047E0B4: CB180B3B 1518113A
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000047E0BC: BF870224
	v_lshl_or_b32 v58, v61, 16, v60                            // 00000047E0C0: D656003A 04F1213D
	v_bfe_u32 v59, v53, 4, 16                                  // 00000047E0C8: D610003B 02410935
	v_dot2acc_f32_f16 v23, v57, v2                             // 00000047E0D0: 042E0539
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000047E0D4: BF8700C4
	v_dot2acc_f32_f16 v21, v57, v6                             // 00000047E0D8: 042A0D39
	v_bfe_u32 v57, v53, 12, 16                                 // 00000047E0DC: D6100039 02411935
	v_mul_u32_u24_e32 v63, s7, v57                             // 00000047E0E4: 167E7207
	v_mul_u32_u24_e32 v57, s8, v57                             // 00000047E0E8: 16727208
	v_lshl_add_u32 v57, v57, 24, v63                           // 00000047E0EC: D6460039 04FD3139
	v_pk_fma_f16 v55, v58, s9, 0xc931 op_sel_hi:[1,0,0]        // 00000047E0F4: CC0E0037 0BFC133A 0000C931
	v_bfe_u32 v58, v53, 8, 16                                  // 00000047E100: D610003A 02411135
	v_mul_u32_u24_e32 v63, s7, v59                             // 00000047E108: 167E7607
	v_mul_u32_u24_e32 v59, s8, v59                             // 00000047E10C: 16767608
	v_lshl_add_u32 v59, v59, 24, v63                           // 00000047E110: D646003B 04FD313B
	v_mul_u32_u24_e32 v63, s7, v58                             // 00000047E118: 167E7407
	v_mul_u32_u24_e32 v58, s8, v58                             // 00000047E11C: 16747408
	v_sad_u8 v57, v57, 0, 0x6400                               // 00000047E120: D6220039 03FD0139 00006400
	v_lshl_add_u32 v58, v58, 24, v63                           // 00000047E12C: D646003A 04FD313A
	v_and_b32_e32 v53, 0xffff, v53                             // 00000047E134: 366A6AFF 0000FFFF
	s_waitcnt vmcnt(1)                                         // 00000047E13C: BF8907F7
	v_bfe_u32 v60, v54, 12, 16                                 // 00000047E140: D610003C 02411936
	v_mul_u32_u24_e32 v63, s7, v53                             // 00000047E148: 167E6A07
	v_mul_u32_u24_e32 v53, s8, v53                             // 00000047E14C: 166A6A08
	v_lshl_add_u32 v53, v53, 24, v63                           // 00000047E150: D6460035 04FD3135
	v_mul_u32_u24_e32 v63, s7, v60                             // 00000047E158: 167E7807
	v_mul_u32_u24_e32 v60, s8, v60                             // 00000047E15C: 16787808
	v_sad_u8 v59, v59, 0, 0x6400                               // 00000047E160: D622003B 03FD013B 00006400
	v_lshl_add_u32 v60, v60, 24, v63                           // 00000047E16C: D646003C 04FD313C
	v_and_b32_e32 v57, 0xffff, v57                             // 00000047E174: 367272FF 0000FFFF
	v_sad_u8 v58, v58, 0, 0x6400                               // 00000047E17C: D622003A 03FD013A 00006400
	v_bfe_u32 v61, v54, 8, 16                                  // 00000047E188: D610003D 02411136
	v_mul_u32_u24_e32 v63, s7, v61                             // 00000047E190: 167E7A07
	v_mul_u32_u24_e32 v61, s8, v61                             // 00000047E194: 167A7A08
	v_and_b32_e32 v59, 0xffff, v59                             // 00000047E198: 367676FF 0000FFFF
	v_sad_u8 v53, v53, 0, 0x6400                               // 00000047E1A0: D6220035 03FD0135 00006400
	v_sad_u8 v60, v60, 0, 0x6400                               // 00000047E1AC: D622003C 03FD013C 00006400
	v_lshl_add_u32 v61, v61, 24, v63                           // 00000047E1B8: D646003D 04FD313D
	v_lshl_or_b32 v57, v58, 16, v57                            // 00000047E1C0: D6560039 04E5213A
	v_and_b32_e32 v56, 0xffff, v56                             // 00000047E1C8: 367070FF 0000FFFF
	v_lshl_or_b32 v53, v53, 16, v59                            // 00000047E1D0: D6560035 04ED2135
	v_and_b32_e32 v58, 0xffff, v60                             // 00000047E1D8: 367478FF 0000FFFF
	v_sad_u8 v59, v61, 0, 0x6400                               // 00000047E1E0: D622003B 03FD013D 00006400
	v_pk_fma_f16 v57, v57, s9, 0xc931 op_sel_hi:[1,0,0]        // 00000047E1EC: CC0E0039 0BFC1339 0000C931
	v_mul_u32_u24_e32 v64, s7, v56                             // 00000047E1F8: 16807007
	v_mul_u32_u24_e32 v56, s8, v56                             // 00000047E1FC: 16707008
	v_sad_u8 v62, v62, 0, 0x6400                               // 00000047E200: D622003E 03FD013E 00006400
	v_lshl_add_u32 v56, v56, 24, v64                           // 00000047E20C: D6460038 05013138
	v_pk_fma_f16 v53, v53, s9, 0xc931 op_sel_hi:[1,0,0]        // 00000047E214: CC0E0035 0BFC1335 0000C931
	v_lshl_or_b32 v58, v59, 16, v58                            // 00000047E220: D656003A 04E9213B
	v_dot2acc_f32_f16 v19, v57, v5                             // 00000047E228: 04260B39
	v_dot2acc_f32_f16 v23, v55, v3                             // 00000047E22C: 042E0737
	v_sad_u8 v56, v56, 0, 0x6400                               // 00000047E230: D6220038 03FD0138 00006400
	v_dot2acc_f32_f16 v21, v55, v7                             // 00000047E23C: 042A0F37
	v_pk_fma_f16 v55, v58, s9, 0xc931 op_sel_hi:[1,0,0]        // 00000047E240: CC0E0037 0BFC133A 0000C931
	v_dot2acc_f32_f16 v19, v53, v6                             // 00000047E24C: 04260D35
	v_and_b32_e32 v62, 0xffff, v62                             // 00000047E250: 367C7CFF 0000FFFF
	v_dot2acc_f32_f16 v20, v57, v1                             // 00000047E258: 04280339
	v_bfe_u32 v57, v35, 4, 16                                  // 00000047E25C: D6100039 02410923
	s_waitcnt vmcnt(0)                                         // 00000047E264: BF8903F7
	v_bfe_u32 v58, v36, 12, 16                                 // 00000047E268: D610003A 02411924
	v_dot2acc_f32_f16 v19, v55, v7                             // 00000047E270: 04260F37
	v_lshl_or_b32 v56, v56, 16, v62                            // 00000047E274: D6560038 04F92138
	v_bfe_u32 v62, v54, 4, 16                                  // 00000047E27C: D610003E 02410936
	v_mul_u32_u24_e32 v63, s7, v62                             // 00000047E284: 167E7C07
	v_mul_u32_u24_e32 v62, s8, v62                             // 00000047E288: 167C7C08
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000047E28C: BF8700C1
	v_lshl_add_u32 v62, v62, 24, v63                           // 00000047E290: D646003E 04FD313E
	v_and_b32_e32 v54, 0xffff, v54                             // 00000047E298: 366C6CFF 0000FFFF
	v_mul_u32_u24_e32 v61, s7, v54                             // 00000047E2A0: 167A6C07
	v_mul_u32_u24_e32 v54, s8, v54                             // 00000047E2A4: 166C6C08
	v_lshl_add_u32 v54, v54, 24, v61                           // 00000047E2A8: D6460036 04F53136
	v_sad_u8 v60, v62, 0, 0x6400                               // 00000047E2B0: D622003C 03FD013E 00006400
	v_pk_fma_f16 v56, v56, s9, 0xc931 op_sel_hi:[1,0,0]        // 00000047E2BC: CC0E0038 0BFC1338 0000C931
	v_dot2acc_f32_f16 v20, v53, v2                             // 00000047E2C8: 04280535
	v_mov_b32_e32 v62, v49                                     // 00000047E2CC: 7E7C0331
	v_sad_u8 v54, v54, 0, 0x6400                               // 00000047E2D0: D6220036 03FD0136 00006400
	v_and_b32_e32 v59, 0xffff, v60                             // 00000047E2DC: 367678FF 0000FFFF
	v_dot2acc_f32_f16 v23, v56, v4                             // 00000047E2E4: 042E0938
	v_dot2acc_f32_f16 v21, v56, v8                             // 00000047E2E8: 042A1138
	v_bfe_u32 v56, v35, 8, 16                                  // 00000047E2EC: D6100038 02411123
	v_bfe_u32 v60, v36, 4, 16                                  // 00000047E2F4: D610003C 02410924
	v_lshl_or_b32 v54, v54, 16, v59                            // 00000047E2FC: D6560036 04ED2136
	v_bfe_u32 v59, v36, 8, 16                                  // 00000047E304: D610003B 02411124
	v_and_b32_e32 v36, 0xffff, v36                             // 00000047E30C: 364848FF 0000FFFF
	v_mov_b32_e32 v64, v49                                     // 00000047E314: 7E800331
	v_mov_b32_e32 v63, v41                                     // 00000047E318: 7E7E0329
	v_pk_fma_f16 v37, v54, s9, 0xc931 op_sel_hi:[1,0,0]        // 00000047E31C: CC0E0025 0BFC1336 0000C931
	v_bfe_u32 v54, v35, 12, 16                                 // 00000047E328: D6100036 02411923
	v_mul_u32_u24_e32 v61, s7, v54                             // 00000047E330: 167A6C07
	v_mul_u32_u24_e32 v54, s8, v54                             // 00000047E334: 166C6C08
	s_delay_alu instid0(VALU_DEP_1)                            // 00000047E338: BF870001
	v_lshl_add_u32 v54, v54, 24, v61                           // 00000047E33C: D6460036 04F53136
	v_mul_u32_u24_e32 v61, s7, v57                             // 00000047E344: 167A7207
	v_mul_u32_u24_e32 v57, s8, v57                             // 00000047E348: 16727208
	v_lshl_add_u32 v57, v57, 24, v61                           // 00000047E34C: D6460039 04F53139
	v_mul_u32_u24_e32 v61, s7, v56                             // 00000047E354: 167A7007
	v_mul_u32_u24_e32 v56, s8, v56                             // 00000047E358: 16707008
	v_sad_u8 v54, v54, 0, 0x6400                               // 00000047E35C: D6220036 03FD0136 00006400
	v_lshl_add_u32 v56, v56, 24, v61                           // 00000047E368: D6460038 04F53138
	v_and_b32_e32 v35, 0xffff, v35                             // 00000047E370: 364646FF 0000FFFF
	v_mul_u32_u24_e32 v61, s7, v35                             // 00000047E378: 167A4607
	v_mul_u32_u24_e32 v35, s8, v35                             // 00000047E37C: 16464608
	s_delay_alu instid0(VALU_DEP_1)                            // 00000047E380: BF870001
	v_lshl_add_u32 v35, v35, 24, v61                           // 00000047E384: D6460023 04F53123
	v_mul_u32_u24_e32 v61, s7, v58                             // 00000047E38C: 167A7407
	v_mul_u32_u24_e32 v58, s8, v58                             // 00000047E390: 16747408
	v_sad_u8 v57, v57, 0, 0x6400                               // 00000047E394: D6220039 03FD0139 00006400
	v_lshl_add_u32 v58, v58, 24, v61                           // 00000047E3A0: D646003A 04F5313A
	v_and_b32_e32 v54, 0xffff, v54                             // 00000047E3A8: 366C6CFF 0000FFFF
	v_sad_u8 v56, v56, 0, 0x6400                               // 00000047E3B0: D6220038 03FD0138 00006400
	v_mul_u32_u24_e32 v61, s7, v59                             // 00000047E3BC: 167A7607
	v_mul_u32_u24_e32 v59, s8, v59                             // 00000047E3C0: 16767608
	v_and_b32_e32 v57, 0xffff, v57                             // 00000047E3C4: 367272FF 0000FFFF
	v_sad_u8 v35, v35, 0, 0x6400                               // 00000047E3CC: D6220023 03FD0123 00006400
	v_sad_u8 v58, v58, 0, 0x6400                               // 00000047E3D8: D622003A 03FD013A 00006400
	v_lshl_add_u32 v59, v59, 24, v61                           // 00000047E3E4: D646003B 04F5313B
	v_lshl_or_b32 v54, v56, 16, v54                            // 00000047E3EC: D6560036 04D92138
	v_mul_u32_u24_e32 v61, s7, v60                             // 00000047E3F4: 167A7807
	v_mul_u32_u24_e32 v60, s8, v60                             // 00000047E3F8: 16787808
	v_lshl_add_u32 v60, v60, 24, v61                           // 00000047E3FC: D646003C 04F5313C
	v_lshl_or_b32 v35, v35, 16, v57                            // 00000047E404: D6560023 04E52123
	v_and_b32_e32 v56, 0xffff, v58                             // 00000047E40C: 367074FF 0000FFFF
	v_sad_u8 v57, v59, 0, 0x6400                               // 00000047E414: D6220039 03FD013B 00006400
	v_pk_fma_f16 v54, v54, s9, 0xc931 op_sel_hi:[1,0,0]        // 00000047E420: CC0E0036 0BFC1336 0000C931
	v_mul_u32_u24_e32 v59, s7, v36                             // 00000047E42C: 16764807
	v_mul_u32_u24_e32 v36, s8, v36                             // 00000047E430: 16484808
	v_sad_u8 v58, v60, 0, 0x6400                               // 00000047E434: D622003A 03FD013C 00006400
	v_lshl_add_u32 v36, v36, 24, v59                           // 00000047E440: D6460024 04ED3124
	v_pk_fma_f16 v35, v35, s9, 0xc931 op_sel_hi:[1,0,0]        // 00000047E448: CC0E0023 0BFC1323 0000C931
	v_dot2acc_f32_f16 v17, v54, v1                             // 00000047E454: 04220336
	v_dot2acc_f32_f16 v15, v54, v5                             // 00000047E458: 041E0B36
	v_mov_b32_e32 v59, v48                                     // 00000047E45C: 7E760330
	v_lshl_or_b32 v56, v57, 16, v56                            // 00000047E460: D6560038 04E12139
	v_and_b32_e32 v57, 0xffff, v58                             // 00000047E468: 367274FF 0000FFFF
	v_sad_u8 v36, v36, 0, 0x6400                               // 00000047E470: D6220024 03FD0124 00006400
	v_dual_dot2acc_f32_f16 v20, v55, v3 :: v_dual_dot2acc_f32_f16 v19, v37, v8// 00000047E47C: CB180737 14121125
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 00000047E484: BF870254
	v_pk_fma_f16 v1, v56, s9, 0xc931 op_sel_hi:[1,0,0]         // 00000047E488: CC0E0001 0BFC1338 0000C931
	v_dot2acc_f32_f16 v17, v35, v2                             // 00000047E494: 04220523
	v_dot2acc_f32_f16 v15, v35, v6                             // 00000047E498: 041E0D23
	v_lshl_or_b32 v5, v36, 16, v57                             // 00000047E49C: D6560005 04E52124
	v_dot2acc_f32_f16 v20, v37, v4                             // 00000047E4A4: 04280925
	v_dual_mov_b32 v56, v47 :: v_dual_dot2acc_f32_f16 v17, v1, v3// 00000047E4A8: CA18012F 38100701
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 00000047E4B0: BF870254
	v_dot2acc_f32_f16 v15, v1, v7                              // 00000047E4B4: 041E0F01
	v_add_nc_u32_e32 v1, v31, v9                               // 00000047E4B8: 4A02131F
	v_pk_fma_f16 v2, v5, s9, 0xc931 op_sel_hi:[1,0,0]          // 00000047E4BC: CC0E0002 0BFC1305 0000C931
	v_dual_mov_b32 v58, v47 :: v_dual_mov_b32 v61, v48         // 00000047E4C8: CA10012F 3A3C0130
	v_mov_b32_e32 v57, v39                                     // 00000047E4D0: 7E720327
	v_cmp_eq_u32_e32 vcc_lo, 1, v1                             // 00000047E4D4: 7C940281
	s_delay_alu instid0(VALU_DEP_4)                            // 00000047E4D8: BF870004
	v_dot2acc_f32_f16 v17, v2, v4                              // 00000047E4DC: 04220902
	v_dual_dot2acc_f32_f16 v15, v2, v8 :: v_dual_mov_b32 v60, v40// 00000047E4E0: CB101102 0F3C0128
	v_dual_mov_b32 v3, v52 :: v_dual_mov_b32 v2, v43           // 00000047E4E8: CA100134 0302012B
	v_mov_b32_e32 v53, v38                                     // 00000047E4F0: 7E6A0326
	v_dual_mov_b32 v55, v46 :: v_dual_mov_b32 v36, v44         // 00000047E4F4: CA10012E 3724012C
	v_dual_mov_b32 v54, v46 :: v_dual_mov_b32 v37, v44         // 00000047E4FC: CA10012E 3624012C
	v_mov_b32_e32 v35, v10                                     // 00000047E504: 7E46030A
	s_or_b32 s6, vcc_lo, s6                                    // 00000047E508: 8C06066A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000047E50C: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 00000047E510: 917E067E
	s_cbranch_execz 56                                         // 00000047E514: BFA50038 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi2ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1af8>
	s_mov_b32 s10, exec_lo                                     // 00000047E518: BE8A007E
	.long 0xd4c1007e                                           // 00000047E51C: D4C1007E
	v_cndmask_b32_e32 v1, v9, v14, vcc_lo                      // 00000047E520: 02021D09
	s_cbranch_execz 64574                                      // 00000047E524: BFA5FC3E <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi2ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0xb20>
	v_ashrrev_i32_e32 v10, 31, v9                              // 00000047E528: 3414129F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000047E52C: BF870091
	.long 0xd73c0004                                           // 00000047E530: D73C0004
	v_cndmask_b32_e32 v1, 10, v9, vcc_lo                       // 00000047E534: 0202128A
	.long 0xd7006a01                                           // 00000047E538: D7006A01
	v_cndmask_b32_e32 v1, s1, v4, vcc_lo                       // 00000047E53C: 02020801
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000047E540: BF870111
	v_add_co_ci_u32_e64 v7, null, s5, v5, vcc_lo               // 00000047E544: D5207C07 01AA0A05
	.long 0xd7006a04                                           // 00000047E54C: D7006A04
	v_cndmask_b32_e32 v1, v1, v34, vcc_lo                      // 00000047E550: 02024501
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000047E554: BF8700A1
	v_add_co_ci_u32_e64 v5, null, 0, v7, vcc_lo                // 00000047E558: D5207C05 01AA0E80
	.long 0xd7006a06                                           // 00000047E560: D7006A06
	v_cndmask_b32_e32 v1, v1, v32, vcc_lo                      // 00000047E564: 02024101
	v_add_co_ci_u32_e64 v7, null, 0, v7, vcc_lo                // 00000047E568: D5207C07 01AA0E80
	s_clause 0xf                                               // 00000047E570: BF85000F
	global_load_b32 v43, v[4:5], off                           // 00000047E574: DC520000 2B7C0004
	global_load_b32 v45, v[4:5], off offset:128                // 00000047E57C: DC520080 2D7C0004
	global_load_b32 v42, v[4:5], off offset:256                // 00000047E584: DC520100 2A7C0004
	global_load_b32 v41, v[4:5], off offset:384                // 00000047E58C: DC520180 297C0004
	global_load_b32 v40, v[4:5], off offset:512                // 00000047E594: DC520200 287C0004
	global_load_b32 v39, v[4:5], off offset:640                // 00000047E59C: DC520280 277C0004
	global_load_b32 v38, v[4:5], off offset:768                // 00000047E5A4: DC520300 267C0004
	global_load_b32 v10, v[4:5], off offset:896                // 00000047E5AC: DC520380 0A7C0004
	global_load_b32 v52, v[6:7], off                           // 00000047E5B4: DC520000 347C0006
	global_load_b32 v51, v[6:7], off offset:128                // 00000047E5BC: DC520080 337C0006
	global_load_b32 v50, v[6:7], off offset:256                // 00000047E5C4: DC520100 327C0006
	global_load_b32 v49, v[6:7], off offset:384                // 00000047E5CC: DC520180 317C0006
	global_load_b32 v48, v[6:7], off offset:512                // 00000047E5D4: DC520200 307C0006
	global_load_b32 v47, v[6:7], off offset:640                // 00000047E5DC: DC520280 2F7C0006
	global_load_b32 v46, v[6:7], off offset:768                // 00000047E5E4: DC520300 2E7C0006
	global_load_b32 v44, v[6:7], off offset:896                // 00000047E5EC: DC520380 2C7C0006
	s_branch 64522                                             // 00000047E5F4: BFA0FC0A <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi2ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0xb20>
	s_or_b32 exec_lo, exec_lo, s6                              // 00000047E5F8: 8C7E067E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000047E5FC: BF870009
	s_or_b32 exec_lo, exec_lo, s0                              // 00000047E600: 8C7E007E
	s_waitcnt vmcnt(23)                                        // 00000047E604: BF895FF7
	v_dual_mov_b32 v1, v30 :: v_dual_mov_b32 v2, v27           // 00000047E608: CA10011E 0102011B
	s_waitcnt vmcnt(15)                                        // 00000047E610: BF893FF7
	v_dual_mov_b32 v3, v29 :: v_dual_mov_b32 v6, v28           // 00000047E614: CA10011D 0306011C
	v_dual_mov_b32 v4, v22 :: v_dual_mov_b32 v9, v25           // 00000047E61C: CA100116 04080119
	v_dual_mov_b32 v5, v18 :: v_dual_mov_b32 v10, v24          // 00000047E624: CA100112 050A0118
	v_dual_mov_b32 v8, v26 :: v_dual_mov_b32 v7, v16           // 00000047E62C: CA10011A 08060110
	v_dual_mov_b32 v14, v23 :: v_dual_mov_b32 v31, v21         // 00000047E634: CA100117 0E1E0115
	v_dual_mov_b32 v32, v20 :: v_dual_mov_b32 v33, v19         // 00000047E63C: CA100114 20200113
	v_dual_mov_b32 v34, v17 :: v_dual_mov_b32 v35, v15         // 00000047E644: CA100111 2222010F
	s_mov_b32 s0, 0x76543210                                   // 00000047E64C: BE8000FF 76543210
	s_waitcnt vmcnt(0)                                         // 00000047E654: BF8903F7
	v_permlanex16_b32 v1, v1, s0, 0xfedcba98                   // 00000047E658: D65C0001 03FC0101 FEDCBA98
	v_permlanex16_b32 v2, v2, s0, 0xfedcba98                   // 00000047E664: D65C0002 03FC0102 FEDCBA98
	v_permlanex16_b32 v3, v3, s0, 0xfedcba98                   // 00000047E670: D65C0003 03FC0103 FEDCBA98
	v_permlanex16_b32 v6, v6, s0, 0xfedcba98                   // 00000047E67C: D65C0006 03FC0106 FEDCBA98
	v_permlanex16_b32 v4, v4, s0, 0xfedcba98                   // 00000047E688: D65C0004 03FC0104 FEDCBA98
	v_permlanex16_b32 v5, v5, s0, 0xfedcba98                   // 00000047E694: D65C0005 03FC0105 FEDCBA98
	v_permlanex16_b32 v8, v8, s0, 0xfedcba98                   // 00000047E6A0: D65C0008 03FC0108 FEDCBA98
	v_permlanex16_b32 v9, v9, s0, 0xfedcba98                   // 00000047E6AC: D65C0009 03FC0109 FEDCBA98
	v_permlanex16_b32 v7, v7, s0, 0xfedcba98                   // 00000047E6B8: D65C0007 03FC0107 FEDCBA98
	v_permlanex16_b32 v10, v10, s0, 0xfedcba98                 // 00000047E6C4: D65C000A 03FC010A FEDCBA98
	v_permlanex16_b32 v14, v14, s0, 0xfedcba98                 // 00000047E6D0: D65C000E 03FC010E FEDCBA98
	v_permlanex16_b32 v31, v31, s0, 0xfedcba98                 // 00000047E6DC: D65C001F 03FC011F FEDCBA98
	v_permlanex16_b32 v32, v32, s0, 0xfedcba98                 // 00000047E6E8: D65C0020 03FC0120 FEDCBA98
	v_permlanex16_b32 v33, v33, s0, 0xfedcba98                 // 00000047E6F4: D65C0021 03FC0121 FEDCBA98
	v_permlanex16_b32 v34, v34, s0, 0xfedcba98                 // 00000047E700: D65C0022 03FC0122 FEDCBA98
	v_permlanex16_b32 v35, v35, s0, 0xfedcba98                 // 00000047E70C: D65C0023 03FC0123 FEDCBA98
	.long 0xd44c0000                                           // 00000047E718: D44C0000
	v_cndmask_b32_e32 v1, 16, v13, vcc_lo                      // 00000047E71C: 02021A90
	s_barrier                                                  // 00000047E720: BFBD0000
	buffer_gl0_inv                                             // 00000047E724: E0AC0000 00000000
	s_and_saveexec_b32 s1, s0                                  // 00000047E72C: BE812000
	s_cbranch_execz 34                                         // 00000047E730: BFA50022 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi2ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1cbc>
	v_dual_add_f32 v3, v29, v3 :: v_dual_add_f32 v2, v27, v2   // 00000047E734: C908071D 0302051B
	v_add_f32_e32 v1, v30, v1                                  // 00000047E73C: 0602031E
	v_lshl_or_b32 v12, v11, 10, v12                            // 00000047E740: D656000C 0431150B
	v_dual_add_f32 v9, v25, v9 :: v_dual_add_f32 v6, v28, v6   // 00000047E748: C9081319 09060D1C
	v_dual_add_f32 v13, v15, v35 :: v_dual_add_f32 v10, v24, v10// 00000047E750: C908470F 0D0A1518
	v_dual_add_f32 v15, v17, v34 :: v_dual_add_f32 v8, v26, v8 // 00000047E758: C9084511 0F08111A
	v_dual_add_f32 v4, v22, v4 :: v_dual_add_f32 v7, v16, v7   // 00000047E760: C9080916 04060F10
	v_add_f32_e32 v5, v18, v5                                  // 00000047E768: 060A0B12
	v_add_f32_e32 v17, v19, v33                                // 00000047E76C: 06224313
	v_dual_add_f32 v19, v20, v32 :: v_dual_add_f32 v14, v23, v14// 00000047E770: C9084114 130E1D17
	v_add_f32_e32 v20, v21, v31                                // 00000047E778: 06283F15
	ds_store_2addr_b32 v12, v1, v3 offset1:16                  // 00000047E77C: D8381000 0003010C
	ds_store_2addr_b32 v12, v2, v6 offset0:128 offset1:144     // 00000047E784: D8389080 0006020C
	ds_store_2addr_b32 v12, v4, v8 offset0:32 offset1:48       // 00000047E78C: D8383020 0008040C
	ds_store_2addr_b32 v12, v5, v9 offset0:160 offset1:176     // 00000047E794: D838B0A0 0009050C
	ds_store_2addr_b32 v12, v7, v14 offset0:64 offset1:80      // 00000047E79C: D8385040 000E070C
	ds_store_2addr_b32 v12, v10, v20 offset0:192 offset1:208   // 00000047E7A4: D838D0C0 00140A0C
	ds_store_2addr_b32 v12, v19, v15 offset0:96 offset1:112    // 00000047E7AC: D8387060 000F130C
	ds_store_2addr_b32 v12, v17, v13 offset0:224 offset1:240   // 00000047E7B4: D838F0E0 000D110C
	s_or_b32 exec_lo, exec_lo, s1                              // 00000047E7BC: 8C7E017E
	.long 0xd44c0001                                           // 00000047E7C0: D44C0001
	v_cndmask_b32_e32 v1, 0x100, v0, vcc_lo                    // 00000047E7C4: 020200FF 00000100
	s_waitcnt lgkmcnt(0)                                       // 00000047E7CC: BF89FC07
	s_barrier                                                  // 00000047E7D0: BFBD0000
	buffer_gl0_inv                                             // 00000047E7D4: E0AC0000 00000000
	s_and_saveexec_b32 s5, s1                                  // 00000047E7DC: BE852001
	s_cbranch_execnz 7                                         // 00000047E7E0: BFA60007 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi2ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1d00>
	s_or_b32 exec_lo, exec_lo, s5                              // 00000047E7E4: 8C7E057E
	s_cmp_lt_i32 s33, 2                                        // 00000047E7E8: BF048221
	s_mov_b32 s5, -1                                           // 00000047E7EC: BE8500C1
	s_cbranch_scc0 33                                          // 00000047E7F0: BFA10021 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi2ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1d78>
	s_and_b32 vcc_lo, exec_lo, s5                              // 00000047E7F4: 8B6A057E
	s_cbranch_vccnz 197                                        // 00000047E7F8: BFA400C5 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi2ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2010>
	s_endpgm                                                   // 00000047E7FC: BFB00000
	v_lshlrev_b32_e32 v7, 2, v0                                // 00000047E800: 300E0082
	ds_load_2addr_stride64_b32 v[1:2], v7 offset1:4            // 00000047E804: D8E00400 01000007
	ds_load_2addr_stride64_b32 v[3:4], v7 offset0:8 offset1:12 // 00000047E80C: D8E00C08 03000007
	ds_load_2addr_stride64_b32 v[5:6], v7 offset0:16 offset1:20// 00000047E814: D8E01410 05000007
	s_waitcnt lgkmcnt(2)                                       // 00000047E81C: BF89FC27
	v_add_f32_e32 v1, 0, v1                                    // 00000047E820: 06020280
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000047E824: BF8700A1
	v_add_f32_e32 v1, v1, v2                                   // 00000047E828: 06020501
	s_waitcnt lgkmcnt(1)                                       // 00000047E82C: BF89FC17
	v_add_f32_e32 v3, v1, v3                                   // 00000047E830: 06060701
	ds_load_2addr_stride64_b32 v[1:2], v7 offset0:24 offset1:28// 00000047E834: D8E01C18 01000007
	v_add_f32_e32 v3, v3, v4                                   // 00000047E83C: 06060903
	s_waitcnt lgkmcnt(1)                                       // 00000047E840: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000047E844: BF870091
	v_add_f32_e32 v3, v3, v5                                   // 00000047E848: 06060B03
	v_add_f32_e32 v3, v3, v6                                   // 00000047E84C: 06060D03
	s_waitcnt lgkmcnt(0)                                       // 00000047E850: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000047E854: BF870091
	v_add_f32_e32 v1, v3, v1                                   // 00000047E858: 06020303
	v_add_f32_e32 v1, v1, v2                                   // 00000047E85C: 06020501
	ds_store_b32 v7, v1 offset:8192                            // 00000047E860: D8342000 00000107
	s_or_b32 exec_lo, exec_lo, s5                              // 00000047E868: 8C7E057E
	s_cmp_lt_i32 s33, 2                                        // 00000047E86C: BF048221
	s_mov_b32 s5, -1                                           // 00000047E870: BE8500C1
	s_cbranch_scc1 65503                                       // 00000047E874: BFA2FFDF <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi2ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1cf4>
	s_waitcnt lgkmcnt(0)                                       // 00000047E878: BF89FC07
	s_barrier                                                  // 00000047E87C: BFBD0000
	buffer_gl0_inv                                             // 00000047E880: E0AC0000 00000000
	s_and_saveexec_b32 s5, s1                                  // 00000047E888: BE852001
	s_cbranch_execz 41                                         // 00000047E88C: BFA50029 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi2ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1e34>
	v_lshrrev_b32_e32 v1, 7, v0                                // 00000047E890: 32020087
	s_ashr_i32 s6, s18, 31                                     // 00000047E894: 86069F12
	v_lshlrev_b32_e32 v4, 2, v0                                // 00000047E898: 30080082
	s_delay_alu instid0(VALU_DEP_2)                            // 00000047E89C: BF870002
	v_lshl_or_b32 v1, s4, 1, v1                                // 00000047E8A0: D6560001 04050204
	s_ashr_i32 s4, s4, 31                                      // 00000047E8A8: 86049F04
	ds_load_b32 v4, v4 offset:8192                             // 00000047E8AC: D8D82000 04000004
	s_mul_i32 s4, s4, s18                                      // 00000047E8B4: 96041204
	.long 0xd72c0003                                           // 00000047E8B8: D72C0003
	v_cndmask_b32_e32 v0, v1, v6, vcc_lo                       // 00000047E8BC: 02000D01
	v_mad_u64_u32 v[1:2], null, v1, s18, 0                     // 00000047E8C0: D6FE7C01 02002501
	s_lshl_b32 s6, s2, 7                                       // 00000047E8C8: 84068702
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000047E8CC: BF870499
	s_ashr_i32 s7, s6, 31                                      // 00000047E8D0: 86079F06
	s_lshl_b64 s[6:7], s[6:7], 2                               // 00000047E8D4: 84868206
	v_add3_u32 v2, v2, v3, s4                                  // 00000047E8D8: D6550002 00120702
	v_and_b32_e32 v3, 0x7f, v0                                 // 00000047E8E0: 360600FF 0000007F
	s_add_u32 s4, s24, s6                                      // 00000047E8E8: 80040618
	s_addc_u32 s6, s25, s7                                     // 00000047E8EC: 82060719
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000047E8F0: BF870112
	.long 0xd73c0001                                           // 00000047E8F4: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 00000047E8F8: 02020282
	v_lshlrev_b32_e32 v3, 2, v3                                // 00000047E8FC: 30060682
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000047E900: BF870092
	.long 0xd7006a01                                           // 00000047E904: D7006A01
	v_cndmask_b32_e32 v1, s4, v1, vcc_lo                       // 00000047E908: 02020204
	v_add_co_ci_u32_e64 v2, null, s6, v2, vcc_lo               // 00000047E90C: D5207C02 01AA0406
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000047E914: BF870092
	.long 0xd7006a01                                           // 00000047E918: D7006A01
	v_cndmask_b32_e32 v1, v1, v3, vcc_lo                       // 00000047E91C: 02020701
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 00000047E920: D5207C02 01AA0480
	s_waitcnt lgkmcnt(0)                                       // 00000047E928: BF89FC07
	global_store_b32 v[1:2], v4, off                           // 00000047E92C: DC6A0000 007C0401
	s_or_b32 exec_lo, exec_lo, s5                              // 00000047E934: 8C7E057E
	.long 0xd44a0004                                           // 00000047E938: D44A0004
	v_cndmask_b32_e32 v1, 0, v0, vcc_lo                        // 00000047E93C: 02020080
	s_waitcnt_vscnt null, 0x0                                  // 00000047E940: BC7C0000
	buffer_gl1_inv                                             // 00000047E944: E0B00000 00000000
	buffer_gl0_inv                                             // 00000047E94C: E0AC0000 00000000
	s_barrier                                                  // 00000047E954: BFBD0000
	buffer_gl0_inv                                             // 00000047E958: E0AC0000 00000000
	s_and_saveexec_b32 s5, s4                                  // 00000047E960: BE852004
	s_cbranch_execz 29                                         // 00000047E964: BFA5001D <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi2ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1edc>
	s_mov_b32 s7, exec_lo                                      // 00000047E968: BE87007E
	s_mov_b32 s6, exec_lo                                      // 00000047E96C: BE86007E
	.long 0xd71f0001                                           // 00000047E970: D71F0001
	v_cndmask_b32_e32 v0, s7, v128, vcc_lo                     // 00000047E974: 02010007
	s_delay_alu instid0(VALU_DEP_1)                            // 00000047E978: BF870001
	v_cmpx_eq_u32_e32 0, v1                                    // 00000047E97C: 7D940280
	s_cbranch_execz 9                                          // 00000047E980: BFA50009 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi2ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1ea8>
	s_lshl_b64 s[8:9], s[2:3], 2                               // 00000047E984: 84888202
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 00000047E988: BF8704B9
	s_add_u32 s8, s26, s8                                      // 00000047E98C: 8008081A
	s_addc_u32 s9, s27, s9                                     // 00000047E990: 8209091B
	s_bcnt1_i32_b32 s7, s7                                     // 00000047E994: BE871807
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v3, s7              // 00000047E998: CA100080 02020007
	global_atomic_add_u32 v2, v2, v3, s[8:9] glc               // 00000047E9A0: DCD64000 02080302
	s_or_b32 exec_lo, exec_lo, s6                              // 00000047E9A8: 8C7E067E
	s_waitcnt vmcnt(0)                                         // 00000047E9AC: BF8903F7
	v_readfirstlane_b32 s6, v2                                 // 00000047E9B0: 7E0C0502
	s_delay_alu instid0(VALU_DEP_1)                            // 00000047E9B4: BF870001
	v_dual_mov_b32 v2, 0 :: v_dual_add_nc_u32 v1, s6, v1       // 00000047E9B8: CA200080 02000206
	s_add_i32 s6, s33, -1                                      // 00000047E9C0: 8106C121
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 00000047E9C4: BF870481
	v_cmp_eq_u32_e32 vcc_lo, s6, v1                            // 00000047E9C8: 7C940206
	v_cndmask_b32_e64 v1, 0, 1, vcc_lo                         // 00000047E9CC: D5010001 01A90280
	ds_store_b32 v2, v1 offset:10240                           // 00000047E9D4: D8342800 00000102
	s_or_b32 exec_lo, exec_lo, s5                              // 00000047E9DC: 8C7E057E
	v_mov_b32_e32 v1, 0                                        // 00000047E9E0: 7E020280
	s_waitcnt lgkmcnt(0)                                       // 00000047E9E4: BF89FC07
	s_barrier                                                  // 00000047E9E8: BFBD0000
	buffer_gl0_inv                                             // 00000047E9EC: E0AC0000 00000000
	ds_load_b32 v1, v1 offset:10240                            // 00000047E9F4: D8D82800 01000001
	s_waitcnt lgkmcnt(0)                                       // 00000047E9FC: BF89FC07
	v_cmp_eq_u32_e32 vcc_lo, 0, v1                             // 00000047EA00: 7C940280
	s_cbranch_vccnz 65                                         // 00000047EA04: BFA40041 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi2ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x200c>
	buffer_gl1_inv                                             // 00000047EA08: E0B00000 00000000
	buffer_gl0_inv                                             // 00000047EA10: E0AC0000 00000000
	s_and_saveexec_b32 s5, s1                                  // 00000047EA18: BE852001
	s_cbranch_execz 47                                         // 00000047EA1C: BFA5002F <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi2ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1fdc>
	v_and_b32_e32 v2, 0x7f, v0                                 // 00000047EA20: 360400FF 0000007F
	s_lshl_b32 s6, s2, 7                                       // 00000047EA28: 84068702
	s_ashr_i32 s1, s18, 31                                     // 00000047EA2C: 86019F12
	s_ashr_i32 s7, s6, 31                                      // 00000047EA30: 86079F06
	v_lshrrev_b32_e32 v1, 7, v0                                // 00000047EA34: 32020087
	v_dual_mov_b32 v2, 0 :: v_dual_lshlrev_b32 v3, 2, v2       // 00000047EA38: CA220080 02020482
	s_lshl_b64 s[6:7], s[6:7], 2                               // 00000047EA40: 84868206
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000047EA44: BF8700A9
	s_add_u32 s6, s24, s6                                      // 00000047EA48: 80060618
	s_addc_u32 s7, s25, s7                                     // 00000047EA4C: 82070719
	.long 0xd7000603                                           // 00000047EA50: D7000603
	v_cndmask_b32_e32 v1, s6, v3, vcc_lo                       // 00000047EA54: 02020606
	s_delay_alu instid0(VALU_DEP_1)                            // 00000047EA58: BF870001
	v_add_co_ci_u32_e64 v4, null, s7, 0, s6                    // 00000047EA5C: D5207C04 00190007
	s_nop 0                                                    // 00000047EA64: BF800000
	s_nop 0                                                    // 00000047EA68: BF800000
	s_nop 0                                                    // 00000047EA6C: BF800000
	s_nop 0                                                    // 00000047EA70: BF800000
	s_nop 0                                                    // 00000047EA74: BF800000
	s_nop 0                                                    // 00000047EA78: BF800000
	s_nop 0                                                    // 00000047EA7C: BF800000
	v_mad_u64_u32 v[5:6], null, v1, s18, 0                     // 00000047EA80: D6FE7C05 02002501
	s_add_i32 s33, s33, -1                                     // 00000047EA88: 8121C121
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000047EA8C: BF870139
	s_cmp_eq_u32 s33, 0                                        // 00000047EA90: BF068021
	v_mad_u64_u32 v[6:7], null, v1, s1, v[6:7]                 // 00000047EA94: D6FE7C06 04180301
	v_add_nc_u32_e32 v1, 2, v1                                 // 00000047EA9C: 4A020282
	.long 0xd73c0005                                           // 00000047EAA0: D73C0005
	v_cndmask_b32_e32 v1, 2, v5, vcc_lo                        // 00000047EAA4: 02020A82
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000047EAA8: BF870091
	.long 0xd7006a05                                           // 00000047EAAC: D7006A05
	v_cndmask_b32_e32 v1, v3, v5, vcc_lo                       // 00000047EAB0: 02020B03
	v_add_co_ci_u32_e64 v6, null, v4, v6, vcc_lo               // 00000047EAB4: D5207C06 01AA0D04
	global_load_b32 v5, v[5:6], off glc                        // 00000047EABC: DC524000 057C0005
	s_waitcnt vmcnt(0)                                         // 00000047EAC4: BF8903F7
	v_add_f32_e32 v2, v2, v5                                   // 00000047EAC8: 06040B02
	s_cbranch_scc0 65516                                       // 00000047EACC: BFA1FFEC <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi2ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1f80>
	v_lshlrev_b32_e32 v1, 2, v0                                // 00000047EAD0: 30020082
	ds_store_b32 v1, v2 offset:8192                            // 00000047EAD4: D8342000 00000201
	s_or_b32 exec_lo, exec_lo, s5                              // 00000047EADC: 8C7E057E
	s_and_saveexec_b32 s1, s4                                  // 00000047EAE0: BE812004
	s_cbranch_execz 6                                          // 00000047EAE4: BFA50006 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi2ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2000>
	s_lshl_b64 s[4:5], s[2:3], 2                               // 00000047EAE8: 84848202
	v_mov_b32_e32 v1, 0                                        // 00000047EAEC: 7E020280
	s_add_u32 s4, s26, s4                                      // 00000047EAF0: 8004041A
	s_addc_u32 s5, s27, s5                                     // 00000047EAF4: 8205051B
	global_store_b32 v1, v1, s[4:5]                            // 00000047EAF8: DC6A0000 00040101
	s_or_b32 exec_lo, exec_lo, s1                              // 00000047EB00: 8C7E017E
	s_cbranch_execz 65341                                      // 00000047EB04: BFA5FF3D <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi2ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1cfc>
	s_branch 1                                                 // 00000047EB08: BFA00001 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi2ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2010>
	s_branch 65339                                             // 00000047EB0C: BFA0FF3B <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi2ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1cfc>
	v_cmp_gt_i32_e32 vcc_lo, s16, v11                          // 00000047EB10: 7C881610
	.long 0xd44c0001                                           // 00000047EB14: D44C0001
	v_cndmask_b32_e32 v1, 64, v0, vcc_lo                       // 00000047EB18: 020200C0
	s_waitcnt lgkmcnt(0)                                       // 00000047EB1C: BF89FC07
	s_waitcnt_vscnt null, 0x0                                  // 00000047EB20: BC7C0000
	s_barrier                                                  // 00000047EB24: BFBD0000
	buffer_gl0_inv                                             // 00000047EB28: E0AC0000 00000000
	s_and_b32 s1, vcc_lo, s1                                   // 00000047EB30: 8B01016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000047EB34: BF870009
	s_and_saveexec_b32 s3, s1                                  // 00000047EB38: BE832001
	s_cbranch_execz 65327                                      // 00000047EB3C: BFA5FF2F <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi2ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1cfc>
	v_and_b32_e32 v1, 15, v0                                   // 00000047EB40: 3602008F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000047EB44: BF870091
	v_lshlrev_b32_e32 v2, 2, v1                                // 00000047EB48: 30040282
	v_lshl_or_b32 v2, v11, 9, v2                               // 00000047EB4C: D6560002 0409130B
	s_delay_alu instid0(VALU_DEP_1)                            // 00000047EB54: BF870001
	v_add_nc_u32_e32 v8, 0x2000, v2                            // 00000047EB58: 4A1004FF 00002000
	ds_load_2addr_b32 v[2:3], v8 offset1:16                    // 00000047EB60: D8DC1000 02000008
	ds_load_2addr_b32 v[4:5], v8 offset0:32 offset1:48         // 00000047EB68: D8DC3020 04000008
	ds_load_2addr_b32 v[6:7], v8 offset0:64 offset1:80         // 00000047EB70: D8DC5040 06000008
	ds_load_2addr_b32 v[8:9], v8 offset0:96 offset1:112        // 00000047EB78: D8DC7060 08000008
	v_and_b32_e32 v10, 1, v0                                   // 00000047EB80: 36140081
	s_waitcnt lgkmcnt(3)                                       // 00000047EB84: BF89FC37
	v_dual_add_f32 v14, v2, v3 :: v_dual_and_b32 v13, 4, v0    // 00000047EB88: C9240702 0E0C0084
	s_waitcnt lgkmcnt(2)                                       // 00000047EB90: BF89FC27
	v_dual_sub_f32 v2, v2, v3 :: v_dual_add_f32 v3, v4, v5     // 00000047EB94: C9480702 02020B04
	s_waitcnt lgkmcnt(1)                                       // 00000047EB9C: BF89FC17
	v_dual_sub_f32 v4, v4, v5 :: v_dual_add_f32 v5, v6, v7     // 00000047EBA0: C9480B04 04040F06
	s_waitcnt lgkmcnt(0)                                       // 00000047EBA8: BF89FC07
	v_dual_sub_f32 v6, v6, v7 :: v_dual_add_f32 v7, v8, v9     // 00000047EBAC: C9480F06 06061308
	v_sub_f32_e32 v8, v8, v9                                   // 00000047EBB4: 08101308
	v_dual_add_f32 v9, v14, v3 :: v_dual_and_b32 v12, 2, v0    // 00000047EBB8: C924070E 090C0082
	v_sub_f32_e32 v3, v14, v3                                  // 00000047EBC0: 0806070E
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000047EBC4: BF8701B4
	v_dual_add_f32 v14, v2, v4 :: v_dual_add_f32 v15, v5, v7   // 00000047EBC8: C9080902 0E0E0F05
	v_sub_f32_e32 v2, v2, v4                                   // 00000047EBD0: 08040902
	v_dual_add_f32 v4, v6, v8 :: v_dual_sub_f32 v5, v5, v7     // 00000047EBD4: C90A1106 04040F05
	v_dual_sub_f32 v6, v6, v8 :: v_dual_add_f32 v7, v9, v15    // 00000047EBDC: C9481106 06061F09
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000047EBE4: BF870222
	v_dual_sub_f32 v8, v9, v15 :: v_dual_add_f32 v9, v14, v4   // 00000047EBE8: C9481F09 0808090E
	v_sub_f32_e32 v4, v14, v4                                  // 00000047EBF0: 0808090E
	v_add_f32_e32 v14, v3, v5                                  // 00000047EBF4: 061C0B03
	v_sub_f32_e32 v3, v3, v5                                   // 00000047EBF8: 08060B03
	v_add_f32_e32 v5, v2, v6                                   // 00000047EBFC: 060A0D02
	v_cmp_eq_u32_e32 vcc_lo, 0, v10                            // 00000047EC00: 7C941480
	v_mov_b32_dpp v10, v9 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000047EC04: 7E1402FA FF016109
	v_mov_b32_dpp v18, v4 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000047EC0C: 7E2402FA FF016104
	v_mov_b32_dpp v15, v14 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000047EC14: 7E1E02FA FF01610E
	v_mov_b32_dpp v16, v5 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000047EC1C: 7E2002FA FF016105
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 00000047EC24: D5010009 21AA1309
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 00000047EC2C: D5010005 21AA0B05
	v_sub_f32_e32 v2, v2, v6                                   // 00000047EC34: 08040D02
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 00000047EC38: D5010004 21AA0904
	v_cndmask_b32_e64 v14, -v14, v14, vcc_lo                   // 00000047EC40: D501000E 21AA1D0E
	v_mov_b32_dpp v17, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000047EC48: 7E2202FA FF016108
	v_add_f32_e32 v5, v5, v16                                  // 00000047EC50: 060A2105
	v_mov_b32_dpp v21, v2 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000047EC54: 7E2A02FA FF016102
	v_cndmask_b32_e64 v22, -v2, v2, vcc_lo                     // 00000047EC5C: D5010016 21AA0502
	v_add_f32_e32 v2, v9, v10                                  // 00000047EC64: 06041509
	v_add_f32_e32 v9, v4, v18                                  // 00000047EC68: 06122504
	v_mov_b32_dpp v6, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000047EC6C: 7E0C02FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, vcc_lo                      // 00000047EC74: D5010007 21AA0F07
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 00000047EC7C: D5010008 21AA1108
	v_mov_b32_dpp v19, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000047EC84: 7E2602FA FF016103
	v_cndmask_b32_e64 v20, -v3, v3, vcc_lo                     // 00000047EC8C: D5010014 21AA0703
	v_cmp_eq_u32_e32 vcc_lo, 0, v12                            // 00000047EC94: 7C941880
	v_add_f32_e32 v3, v7, v6                                   // 00000047EC98: 06060D07
	.long 0xd44a0001                                           // 00000047EC9C: D44A0001
	v_cndmask_b32_e32 v1, 0, v13, vcc_lo                       // 00000047ECA0: 02021A80
	v_mov_b32_dpp v12, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000047ECA4: 7E1802FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 00000047ECAC: D5010005 21AA0B05
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000047ECB4: BF8700A4
	v_mov_b32_dpp v4, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000047ECB8: 7E0802FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 00000047ECC0: D5010003 21AA0703
	v_add_f32_e32 v3, v3, v4                                   // 00000047ECC8: 06060903
	v_mov_b32_dpp v7, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000047ECCC: 7E0E02FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, vcc_lo                      // 00000047ECD4: D5010002 21AA0502
	v_add_f32_e32 v4, v5, v12                                  // 00000047ECDC: 06081905
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000047ECE0: BF8700A4
	v_mov_b32_dpp v5, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000047ECE4: 7E0A02FA FF016403
	v_cndmask_b32_e64 v3, -v3, v3, s1                          // 00000047ECEC: D5010003 20060703
	v_dual_add_f32 v2, v2, v7 :: v_dual_add_f32 v3, v3, v5     // 00000047ECF4: C9080F02 02020B03
	s_delay_alu instid0(VALU_DEP_1)                            // 00000047ECFC: BF870001
	v_cndmask_b32_e64 v7, -v2, v2, s1                          // 00000047ED00: D5010007 20060502
	v_mov_b32_dpp v2, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000047ED08: 7E0402FA FF016402
	v_add_f32_e32 v6, v14, v15                                 // 00000047ED10: 060C1F0E
	v_add_f32_e32 v14, v22, v21                                // 00000047ED14: 061C2B16
	v_mov_b32_dpp v15, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000047ED18: 7E1E02FA FF016209
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 00000047ED20: D5010009 21AA1309
	v_add_f32_e32 v7, v7, v2                                   // 00000047ED28: 060E0507
	v_mov_b32_dpp v10, v6 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000047ED2C: 7E1402FA FF016206
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 00000047ED34: D5010006 21AA0D06
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000047ED3C: BF870234
	v_dual_add_f32 v8, v8, v17 :: v_dual_add_f32 v9, v9, v15   // 00000047ED40: C9082308 08081F09
	v_mov_b32_dpp v16, v14 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000047ED48: 7E2002FA FF01620E
	v_cndmask_b32_e64 v14, -v14, v14, vcc_lo                   // 00000047ED50: D501000E 21AA1D0E
	v_add_f32_e32 v6, v6, v10                                  // 00000047ED58: 060C1506
	v_mov_b32_dpp v10, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000047ED5C: 7E1402FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s1                          // 00000047ED64: D5010004 20060904
	v_mov_b32_dpp v13, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000047ED6C: 7E1A02FA FF016208
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 00000047ED74: D5010008 21AA1108
	v_mov_b32_dpp v12, v6 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000047ED7C: 7E1802FA FF016406
	v_cndmask_b32_e64 v6, -v6, v6, s1                          // 00000047ED84: D5010006 20060D06
	v_add_f32_e32 v4, v4, v10                                  // 00000047ED8C: 06081504
	v_add_f32_e32 v10, v20, v19                                // 00000047ED90: 06142714
	v_add_f32_e32 v8, v8, v13                                  // 00000047ED94: 06101B08
	v_mov_b32_dpp v2, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000047ED98: 7E0402FA FF016803
	v_add_f32_e32 v6, v6, v12                                  // 00000047EDA0: 060C1906
	v_mov_b32_dpp v5, v7 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000047EDA4: 7E0A02FA FF016807
	v_mov_b32_dpp v13, v10 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000047EDAC: 7E1A02FA FF01620A
	v_cndmask_b32_e64 v10, -v10, v10, vcc_lo                   // 00000047EDB4: D501000A 21AA150A
	v_mov_b32_dpp v12, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000047EDBC: 7E1802FA FF016408
	v_cndmask_b32_e64 v15, -v8, v8, s1                         // 00000047EDC4: D501000F 20061108
	v_mov_b32_dpp v8, v6 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000047EDCC: 7E1002FA FF016806
	s_delay_alu instid0(VALU_DEP_4)                            // 00000047EDD4: BF870004
	v_add_f32_e32 v10, v10, v13                                // 00000047EDD8: 06141B0A
	v_add_f32_e32 v13, v14, v16                                // 00000047EDDC: 061A210E
	v_mov_b32_dpp v14, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000047EDE0: 7E1C02FA FF016409
	v_cndmask_b32_e64 v9, -v9, v9, s1                          // 00000047EDE8: D5010009 20061309
	v_add_f32_e32 v15, v15, v12                                // 00000047EDF0: 061E190F
	v_mov_b32_dpp v16, v10 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000047EDF4: 7E2002FA FF01640A
	v_mov_b32_dpp v18, v13 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000047EDFC: 7E2402FA FF01640D
	v_cndmask_b32_e64 v10, -v10, v10, s1                       // 00000047EE04: D501000A 2006150A
	v_cndmask_b32_e64 v13, -v13, v13, s1                       // 00000047EE0C: D501000D 20061B0D
	v_add_f32_e32 v17, v9, v14                                 // 00000047EE14: 06221D09
	v_mov_b32_dpp v9, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000047EE18: 7E1202FA FF016804
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000047EE20: BF870214
	v_add_f32_e32 v16, v10, v16                                // 00000047EE24: 0620210A
	v_add_f32_e32 v18, v13, v18                                // 00000047EE28: 0624250D
	v_mov_b32_dpp v10, v15 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000047EE2C: 7E1402FA FF01680F
	v_mov_b32_dpp v12, v17 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000047EE34: 7E1802FA FF016811
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000047EE3C: BF870214
	v_mov_b32_dpp v13, v16 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000047EE40: 7E1A02FA FF016810
	v_mov_b32_dpp v14, v18 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000047EE48: 7E1C02FA FF016812
	s_and_b32 exec_lo, exec_lo, s0                             // 00000047EE50: 8B7E007E
	s_cbranch_execz 65129                                      // 00000047EE54: BFA5FE69 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi2ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1cfc>
	v_lshl_or_b32 v19, s2, 7, v1                               // 00000047EE58: D6560013 04050E02
	.long 0x7f2e3880                                           // 00000047EE60: 7F2E3880
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000047EE64: BF870112
	v_ashrrev_i32_e32 v20, 31, v19                             // 00000047EE68: 3428269F
	.long 0x7f303997                                           // 00000047EE6C: 7F303997
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000047EE70: BF870092
	.long 0xd73c0013                                           // 00000047EE74: D73C0013
	v_cndmask_b32_e32 v1, 1, v19, vcc_lo                       // 00000047EE78: 02022681
	.long 0xd7006a15                                           // 00000047EE7C: D7006A15
	v_cndmask_b32_e32 v1, s22, v19, vcc_lo                     // 00000047EE80: 02022616
	s_delay_alu instid0(VALU_DEP_1)                            // 00000047EE84: BF870001
	v_add_co_ci_u32_e64 v22, null, s23, v20, vcc_lo            // 00000047EE88: D5207C16 01AA2817
	s_clause 0x7                                               // 00000047EE90: BF850007
	global_load_d16_b16 v23, v[21:22], off offset:32           // 00000047EE94: DC820020 177C0015
	global_load_d16_b16 v24, v[21:22], off                     // 00000047EE9C: DC820000 187C0015
	global_load_d16_b16 v25, v[21:22], off offset:64           // 00000047EEA4: DC820040 197C0015
	global_load_d16_b16 v26, v[21:22], off offset:96           // 00000047EEAC: DC820060 1A7C0015
	global_load_d16_b16 v27, v[21:22], off offset:128          // 00000047EEB4: DC820080 1B7C0015
	global_load_d16_b16 v28, v[21:22], off offset:160          // 00000047EEBC: DC8200A0 1C7C0015
	global_load_d16_b16 v29, v[21:22], off offset:192          // 00000047EEC4: DC8200C0 1D7C0015
	global_load_d16_b16 v21, v[21:22], off offset:224          // 00000047EECC: DC8200E0 157C0015
	v_and_b32_e32 v22, 8, v0                                   // 00000047EED4: 362C0088
	v_mad_i64_i32 v[0:1], null, s18, v11, 0                    // 00000047EED8: D6FF7C00 02021612
	s_waitcnt vmcnt(7)                                         // 00000047EEE0: BF891FF7
	.long 0x7f163997                                           // 00000047EEE4: 7F163997
	s_waitcnt vmcnt(0)                                         // 00000047EEE8: BF8903F7
	.long 0x7f2a3997                                           // 00000047EEEC: 7F2A3997
	v_cmp_eq_u32_e32 vcc_lo, 0, v22                            // 00000047EEF0: 7C942C80
	.long 0x7f2c3997                                           // 00000047EEF4: 7F2C3997
	.long 0xd73c0000                                           // 00000047EEF8: D73C0000
	v_cndmask_b32_e32 v1, 1, v0, vcc_lo                        // 00000047EEFC: 02020081
	v_cndmask_b32_e64 v7, -v7, v7, vcc_lo                      // 00000047EF00: D5010007 21AA0F07
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 00000047EF08: D5010003 21AA0703
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 00000047EF10: D5010004 21AA0904
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 00000047EF18: D5010006 21AA0D06
	v_cndmask_b32_e64 v16, -v16, v16, vcc_lo                   // 00000047EF20: D5010010 21AA2110
	v_add_f32_e32 v5, v7, v5                                   // 00000047EF28: 060A0B07
	v_cndmask_b32_e64 v7, -v17, v17, vcc_lo                    // 00000047EF2C: D5010007 21AA2311
	v_cndmask_b32_e64 v17, -v18, v18, vcc_lo                   // 00000047EF34: D5010011 21AA2512
	v_add_f32_e32 v2, v3, v2                                   // 00000047EF3C: 06040503
	v_add_f32_e32 v4, v4, v9                                   // 00000047EF40: 06081304
	v_mul_f32_e32 v3, 0x3db504f3, v5                           // 00000047EF44: 10060AFF 3DB504F3
	v_add_f32_e32 v5, v6, v8                                   // 00000047EF4C: 060A1106
	v_cndmask_b32_e64 v15, -v15, v15, vcc_lo                   // 00000047EF50: D501000F 21AA1F0F
	v_dual_add_f32 v7, v7, v12 :: v_dual_add_f32 v8, v16, v13  // 00000047EF58: C9081907 07081B10
	v_dual_add_f32 v9, v17, v14 :: v_dual_mul_f32 v4, 0x3db504f3, v4// 00000047EF60: C9061D11 090408FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000047EF6C: BF870212
	v_dual_mul_f32 v2, 0x3db504f3, v2 :: v_dual_mul_f32 v7, 0x3db504f3, v7// 00000047EF70: C8C604FF 02060EFF 3DB504F3
	v_dual_add_f32 v6, v15, v10 :: v_dual_mul_f32 v5, 0x3db504f3, v5// 00000047EF7C: C906150F 06040AFF 3DB504F3
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000047EF88: BF8701A3
	v_mul_f32_e32 v9, 0x3db504f3, v9                           // 00000047EF8C: 101212FF 3DB504F3
	.long 0xd7006a00                                           // 00000047EF94: D7006A00
	v_cndmask_b32_e32 v1, s28, v0, vcc_lo                      // 00000047EF98: 0202001C
	v_mul_f32_e32 v6, 0x3db504f3, v6                           // 00000047EF9C: 100C0CFF 3DB504F3
	v_add_co_ci_u32_e64 v1, null, s29, v1, vcc_lo              // 00000047EFA4: D5207C01 01AA021D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000047EFAC: BF870093
	.long 0xd7006a00                                           // 00000047EFB0: D7006A00
	v_cndmask_b32_e32 v1, v0, v19, vcc_lo                      // 00000047EFB4: 02022700
	v_add_co_ci_u32_e64 v1, null, v1, v20, vcc_lo              // 00000047EFB8: D5207C01 01AA2901
	v_fma_mix_f32 v3, v23, v3, neg(0) op_sel_hi:[1,0,0]        // 00000047EFC0: CC200003 8A020717
	v_fma_mix_f32 v2, v24, v2, neg(0) op_sel_hi:[1,0,0]        // 00000047EFC8: CC200002 8A020518
	v_fma_mix_f32 v5, v25, v5, neg(0) op_sel_hi:[1,0,0]        // 00000047EFD0: CC200005 8A020B19
	v_fma_mix_f32 v4, v26, v4, neg(0) op_sel_hi:[1,0,0]        // 00000047EFD8: CC200004 8A02091A
	v_fma_mix_f32 v6, v27, v6, neg(0) op_sel_hi:[1,0,0]        // 00000047EFE0: CC200006 8A020D1B
	.long 0x7e2e3983                                           // 00000047EFE8: 7E2E3983
	v_fma_mix_f32 v7, v28, v7, neg(0) op_sel_hi:[1,0,0]        // 00000047EFEC: CC200007 8A020F1C
	.long 0x7e163982                                           // 00000047EFF4: 7E163982
	v_mul_f32_e32 v8, 0x3db504f3, v8                           // 00000047EFF8: 101010FF 3DB504F3
	v_fma_mix_f32 v9, v21, v9, neg(0) op_sel_hi:[1,0,0]        // 00000047F000: CC200009 8A021315
	v_and_b32_e32 v10, 1, v23                                  // 00000047F008: 36142E81
	.long 0x7e2e3984                                           // 00000047F00C: 7E2E3984
	v_and_b32_e32 v11, 1, v11                                  // 00000047F010: 36161681
	v_fma_mix_f32 v8, v29, v8, neg(0) op_sel_hi:[1,0,0]        // 00000047F014: CC200008 8A02111D
	.long 0x7e2a3985                                           // 00000047F01C: 7E2A3985
	.long 0x7e2c3986                                           // 00000047F020: 7E2C3986
	v_and_b32_e32 v12, 1, v23                                  // 00000047F024: 36182E81
	.long 0x7e2e3987                                           // 00000047F028: 7E2E3987
	.long 0x7e303988                                           // 00000047F02C: 7E303988
	v_and_b32_e32 v13, 1, v21                                  // 00000047F030: 361A2A81
	v_and_b32_e32 v14, 1, v22                                  // 00000047F034: 361C2C81
	v_add3_u32 v3, v3, v10, 0x7fff                             // 00000047F038: D6550003 03FE1503 00007FFF
	v_and_b32_e32 v15, 1, v23                                  // 00000047F044: 361E2E81
	.long 0x7e2e3989                                           // 00000047F048: 7E2E3989
	v_and_b32_e32 v16, 1, v24                                  // 00000047F04C: 36203081
	v_add3_u32 v2, v2, v11, 0x7fff                             // 00000047F050: D6550002 03FE1702 00007FFF
	v_add3_u32 v5, v5, v13, 0x7fff                             // 00000047F05C: D6550005 03FE1B05 00007FFF
	v_add3_u32 v4, v4, v12, 0x7fff                             // 00000047F068: D6550004 03FE1904 00007FFF
	v_and_b32_e32 v10, 1, v23                                  // 00000047F074: 36142E81
	v_add3_u32 v6, v6, v14, 0x7fff                             // 00000047F078: D6550006 03FE1D06 00007FFF
	v_add3_u32 v8, v8, v16, 0x7fff                             // 00000047F084: D6550008 03FE2108 00007FFF
	v_add3_u32 v7, v7, v15, 0x7fff                             // 00000047F090: D6550007 03FE1F07 00007FFF
	s_delay_alu instid0(VALU_DEP_4)                            // 00000047F09C: BF870004
	v_add3_u32 v9, v9, v10, 0x7fff                             // 00000047F0A0: D6550009 03FE1509 00007FFF
	s_clause 0x7                                               // 00000047F0AC: BF850007
	global_store_d16_hi_b16 v[0:1], v2, off                    // 00000047F0B0: DC960000 007C0200
	global_store_d16_hi_b16 v[0:1], v3, off offset:32          // 00000047F0B8: DC960020 007C0300
	global_store_d16_hi_b16 v[0:1], v5, off offset:64          // 00000047F0C0: DC960040 007C0500
	global_store_d16_hi_b16 v[0:1], v4, off offset:96          // 00000047F0C8: DC960060 007C0400
	global_store_d16_hi_b16 v[0:1], v6, off offset:128         // 00000047F0D0: DC960080 007C0600
	global_store_d16_hi_b16 v[0:1], v7, off offset:160         // 00000047F0D8: DC9600A0 007C0700
	global_store_d16_hi_b16 v[0:1], v8, off offset:192         // 00000047F0E0: DC9600C0 007C0800
	global_store_d16_hi_b16 v[0:1], v9, off offset:224         // 00000047F0E8: DC9600E0 007C0900
	s_endpgm                                                   // 00000047F0F0: BFB00000
		...

