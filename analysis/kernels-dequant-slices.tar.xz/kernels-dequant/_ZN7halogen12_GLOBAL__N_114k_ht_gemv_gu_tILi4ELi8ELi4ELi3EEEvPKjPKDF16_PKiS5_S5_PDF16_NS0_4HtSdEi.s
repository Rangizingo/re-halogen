0000000000a07d00 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi3EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi>:
; _ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi3EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi():
	s_clause 0x1                                               // 000000A07D00: BF850001
	s_load_b32 s3, s[0:1], 0x88                                // 000000A07D04: F40000C0 F8000088
	s_load_b512 s[12:27], s[0:1], null                         // 000000A07D0C: F4100300 F8000000
	v_and_b32_e32 v41, 31, v0                                  // 000000A07D14: 3652009F
	v_lshrrev_b32_e32 v40, 5, v0                               // 000000A07D18: 32500085
	s_mov_b32 s4, -1                                           // 000000A07D1C: BE8400C1
	s_waitcnt lgkmcnt(0)                                       // 000000A07D20: BF89FC07
	s_cmp_lt_i32 s2, s3                                        // 000000A07D24: BF040302
	s_cbranch_scc1 2674                                        // 000000A07D28: BFA20A72 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi3EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x29f4>
	s_load_b64 s[8:9], s[0:1], 0x7c                            // 000000A07D2C: F4040200 F800007C
	s_sub_i32 s28, s2, s3                                      // 000000A07D34: 819C0302
	s_clause 0x1                                               // 000000A07D38: BF850001
	s_load_b256 s[44:51], s[0:1], 0x60                         // 000000A07D3C: F40C0B00 F8000060
	s_load_b256 s[36:43], s[0:1], 0x40                         // 000000A07D44: F40C0900 F8000040
	s_mov_b32 s34, 0                                           // 000000A07D4C: BEA20080
	s_mov_b32 s33, exec_lo                                     // 000000A07D50: BEA1007E
	s_waitcnt lgkmcnt(0)                                       // 000000A07D54: BF89FC07
	s_abs_i32 s4, s9                                           // 000000A07D58: BE841509
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_2)// 000000A07D5C: BF870529
	s_cvt_f32_u32 s5, s4                                       // 000000A07D60: BE856504
	s_sub_i32 s6, 0, s4                                        // 000000A07D64: 81860480
	v_rcp_iflag_f32_e32 v1, s5                                 // 000000A07D68: 7E025605
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_3)// 000000A07D6C: BF8705A5
	v_readfirstlane_b32 s5, v1                                 // 000000A07D70: 7E0A0501
	s_mul_f32 s5, s5, 0x4f7ffffe                               // 000000A07D74: A205FF05 4F7FFFFE
	s_cvt_u32_f32 s5, s5                                       // 000000A07D7C: BE856705
	s_delay_alu instid0(SALU_CYCLE_3) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000A07D80: BF87049B
	s_mul_i32 s6, s6, s5                                       // 000000A07D84: 96060506
	s_mul_hi_u32 s6, s5, s6                                    // 000000A07D88: 96860605
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 000000A07D8C: BF8704B9
	s_add_i32 s5, s5, s6                                       // 000000A07D90: 81050605
	s_ashr_i32 s6, s9, 31                                      // 000000A07D94: 86069F09
	s_mul_hi_u32 s3, s28, s5                                   // 000000A07D98: 9683051C
	s_mul_i32 s5, s3, s4                                       // 000000A07D9C: 96050403
	s_add_i32 s7, s3, 1                                        // 000000A07DA0: 81078103
	s_sub_i32 s5, s28, s5                                      // 000000A07DA4: 8185051C
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000A07DA8: BF870009
	s_sub_i32 s10, s5, s4                                      // 000000A07DAC: 818A0405
	s_cmp_ge_u32 s5, s4                                        // 000000A07DB0: BF090405
	s_cselect_b32 s3, s7, s3                                   // 000000A07DB4: 98030307
	s_cselect_b32 s5, s10, s5                                  // 000000A07DB8: 9805050A
	s_add_i32 s7, s3, 1                                        // 000000A07DBC: 81078103
	s_cmp_ge_u32 s5, s4                                        // 000000A07DC0: BF090405
	s_cselect_b32 s3, s7, s3                                   // 000000A07DC4: 98030307
	s_ashr_i32 s11, s50, 31                                    // 000000A07DC8: 860B9F32
	s_xor_b32 s3, s3, s6                                       // 000000A07DCC: 8D030603
	s_lshr_b32 s0, s11, 25                                     // 000000A07DD0: 8500990B
	s_sub_i32 s10, s3, s6                                      // 000000A07DD4: 818A0603
	s_add_i32 s0, s50, s0                                      // 000000A07DD8: 81000032
	s_mul_i32 s30, s10, s9                                     // 000000A07DDC: 961E090A
	s_ashr_i32 s0, s0, 7                                       // 000000A07DE0: 86008700
	s_sub_i32 s29, s28, s30                                    // 000000A07DE4: 819D1E1C
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000A07DE8: BF870499
	s_mul_i32 s29, s29, s8                                     // 000000A07DEC: 961D081D
	s_add_i32 s1, s29, s8                                      // 000000A07DF0: 8101081D
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000A07DF4: BF870499
	s_min_i32 s0, s0, s1                                       // 000000A07DF8: 89000100
	s_sub_i32 s35, s0, s29                                     // 000000A07DFC: 81A31D00
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000A07E00: BF870499
	s_lshl_b32 s31, s35, 2                                     // 000000A07E04: 841F8223
	.long 0xd4c4007e                                           // 000000A07E08: D4C4007E
	v_cndmask_b32_e32 v1, s31, v40, vcc_lo                     // 000000A07E0C: 0202501F
	s_cbranch_execz 503                                        // 000000A07E10: BFA501F7 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi3EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x8f0>
	s_add_i32 s51, s48, -1                                     // 000000A07E14: 8133C130
	s_cmp_lg_u64 s[40:41], 0                                   // 000000A07E18: BF118028
	v_dual_mov_b32 v8, v40 :: v_dual_and_b32 v1, 1, v0         // 000000A07E1C: CA240128 08000081
	s_cselect_b32 s52, -1, 0                                   // 000000A07E24: 983480C1
	s_abs_i32 s53, s35                                         // 000000A07E28: BEB51523
	v_and_b32_e32 v2, 2, v0                                    // 000000A07E2C: 36040082
	s_cvt_f32_u32 s0, s53                                      // 000000A07E30: BE806535
	v_lshlrev_b32_e32 v6, 3, v41                               // 000000A07E34: 300C5283
	v_lshlrev_b32_e32 v7, 7, v40                               // 000000A07E38: 300E5087
	v_and_b32_e32 v3, 4, v0                                    // 000000A07E3C: 36060084
	v_rcp_iflag_f32_e32 v4, s0                                 // 000000A07E40: 7E085600
	v_and_b32_e32 v5, 8, v0                                    // 000000A07E44: 360A0088
	.long 0xd44a0001                                           // 000000A07E48: D44A0001
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 000000A07E4C: 02020280
	.long 0xd44a0003                                           // 000000A07E50: D44A0003
	v_cndmask_b32_e32 v1, 0, v2, vcc_lo                        // 000000A07E54: 02020480
	v_lshl_or_b32 v1, v40, 8, v6                               // 000000A07E58: D6560001 04191128
	v_lshl_add_u32 v2, s29, 7, v7                              // 000000A07E60: D6460002 041D0E1D
	s_ashr_i32 s55, s35, 31                                    // 000000A07E68: 86379F23
	s_sub_i32 s57, 0, s53                                      // 000000A07E6C: 81B93580
	s_mul_i32 s8, s55, 0x1400                                  // 000000A07E70: 9608FF37 00001400
	.long 0xd44c0000                                           // 000000A07E78: D44C0000
	v_cndmask_b32_e32 v1, 16, v41, vcc_lo                      // 000000A07E7C: 02025290
	v_readfirstlane_b32 s5, v4                                 // 000000A07E80: 7E0A0504
	.long 0xd44a0004                                           // 000000A07E84: D44A0004
	v_cndmask_b32_e32 v1, 0, v3, vcc_lo                        // 000000A07E88: 02020680
	v_subrev_nc_u32_e32 v9, s8, v1                             // 000000A07E8C: 4E120208
	v_lshl_or_b32 v1, v41, 2, v2                               // 000000A07E90: D6560001 04090529
	s_lshl_b32 s6, s35, 7                                      // 000000A07E98: 84068723
	s_mul_f32 s7, s5, 0x4f7ffffe                               // 000000A07E9C: A207FF05 4F7FFFFE
	.long 0xd44a0005                                           // 000000A07EA4: D44A0005
	v_cndmask_b32_e32 v1, 0, v5, vcc_lo                        // 000000A07EA8: 02020A80
	s_mov_b32 s54, 0x76543210                                  // 000000A07EAC: BEB600FF 76543210
	s_lshl_b32 s56, s35, 8                                     // 000000A07EB4: 84388823
	s_cvt_u32_f32 s7, s7                                       // 000000A07EB8: BE876707
	s_mov_b32 s59, 0x3db504f3                                  // 000000A07EBC: BEBB00FF 3DB504F3
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000A07EC4: BF87049A
	s_mul_i32 s57, s57, s7                                     // 000000A07EC8: 96390739
	s_mul_hi_u32 s8, s7, s57                                   // 000000A07ECC: 96883907
	s_sub_i32 s57, 0, s6                                       // 000000A07ED0: 81B90680
	s_add_i32 s58, s7, s8                                      // 000000A07ED4: 813A0807
	s_branch 164                                               // 000000A07ED8: BFA000A4 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi3EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x46c>
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A07EDC: BF870091
	.long 0xd7006a02                                           // 000000A07EE0: D7006A02
	v_cndmask_b32_e32 v1, s26, v2, vcc_lo                      // 000000A07EE4: 0202041A
	v_add_co_ci_u32_e64 v3, null, s27, v3, vcc_lo              // 000000A07EE8: D5207C03 01AA061B
	v_sub_f32_e32 v4, v15, v13                                 // 000000A07EF0: 08081B0F
	v_add_nc_u32_e32 v1, 0x400, v1                             // 000000A07EF4: 4A0202FF 00000400
	global_load_d16_b16 v2, v[2:3], off offset:6               // 000000A07EFC: DC820006 027C0002
	s_waitcnt vmcnt(0)                                         // 000000A07F04: BF8903F7
	v_fma_mix_f32 v5, v14, v2, v12 op_sel_hi:[0,1,0]           // 000000A07F08: CC200005 1432050E
	v_fma_mix_f32 v2, -v14, v2, v12 op_sel_hi:[0,1,0]          // 000000A07F10: CC200002 3432050E
	v_add_f32_e32 v3, v15, v13                                 // 000000A07F18: 06061B0F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000A07F1C: BF8701A2
	v_add_f32_e32 v7, v4, v2                                   // 000000A07F20: 060E0504
	v_sub_f32_e32 v2, v4, v2                                   // 000000A07F24: 08040504
	v_add_f32_e32 v6, v3, v5                                   // 000000A07F28: 060C0B03
	v_sub_f32_e32 v3, v3, v5                                   // 000000A07F2C: 08060B03
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A07F30: BF870193
	v_mov_b32_dpp v13, v2 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A07F34: 7E1A02FA FF016102
	v_mov_b32_dpp v4, v6 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A07F3C: 7E0802FA FF016106
	v_cndmask_b32_e64 v6, -v6, v6, s1                          // 000000A07F44: D5010006 20060D06
	v_cndmask_b32_e64 v2, -v2, v2, s1                          // 000000A07F4C: D5010002 20060502
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000A07F54: BF870142
	v_add_f32_e32 v4, v6, v4                                   // 000000A07F58: 06080906
	v_mov_b32_dpp v5, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A07F5C: 7E0A02FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, s1                          // 000000A07F64: D5010007 20060F07
	.long 0xd72c0006                                           // 000000A07F6C: D72C0006
	v_cndmask_b32_e32 v1, 0x1400, v11, vcc_lo                  // 000000A07F70: 020216FF 00001400
	v_add_f32_e32 v5, v7, v5                                   // 000000A07F78: 060A0B07
	v_mov_b32_dpp v7, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A07F7C: 7E0E02FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, s3                          // 000000A07F84: D5010004 200E0904
	s_delay_alu instid0(VALU_DEP_1)                            // 000000A07F8C: BF870001
	v_add_f32_e32 v4, v4, v7                                   // 000000A07F90: 06080F04
	v_mov_b32_dpp v12, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A07F94: 7E1802FA FF016103
	v_cndmask_b32_e64 v3, -v3, v3, s1                          // 000000A07F9C: D5010003 20060703
	.long 0xd72c0007                                           // 000000A07FA4: D72C0007
	v_cndmask_b32_e32 v1, s56, v10, vcc_lo                     // 000000A07FA8: 02021438
	v_add_f32_e32 v2, v2, v13                                  // 000000A07FAC: 06041B02
	v_mov_b32_dpp v10, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A07FB0: 7E1402FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s4                          // 000000A07FB8: D5010004 20120904
	v_add_f32_e32 v3, v3, v12                                  // 000000A07FC0: 06061903
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000A07FC4: BF870224
	v_mov_b32_dpp v13, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A07FC8: 7E1A02FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, s3                          // 000000A07FD0: D5010002 200E0502
	v_add_f32_e32 v4, v4, v10                                  // 000000A07FD8: 06081504
	v_mov_b32_dpp v11, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A07FDC: 7E1602FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, s3                          // 000000A07FE4: D5010005 200E0B05
	v_mov_b32_dpp v12, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A07FEC: 7E1802FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, s3                          // 000000A07FF4: D5010003 200E0703
	v_add_f32_e32 v2, v2, v13                                  // 000000A07FFC: 06041B02
	v_mov_b32_dpp v10, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A08000: 7E1402FA FF016804
	v_add_f32_e32 v5, v5, v11                                  // 000000A08008: 060A1705
	v_cndmask_b32_e64 v4, -v4, v4, s5                          // 000000A0800C: D5010004 20160904
	v_add_f32_e32 v3, v3, v12                                  // 000000A08014: 06061903
	v_mov_b32_dpp v13, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A08018: 7E1A02FA FF016402
	v_cndmask_b32_e64 v2, -v2, v2, s4                          // 000000A08020: D5010002 20120502
	v_mov_b32_dpp v11, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A08028: 7E1602FA FF016405
	v_cndmask_b32_e64 v5, -v5, v5, s4                          // 000000A08030: D5010005 20120B05
	v_mov_b32_dpp v12, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A08038: 7E1802FA FF016403
	v_cndmask_b32_e64 v3, -v3, v3, s4                          // 000000A08040: D5010003 20120703
	v_add_f32_e32 v2, v2, v13                                  // 000000A08048: 06041B02
	v_sub_nc_u32_e32 v6, v6, v7                                // 000000A0804C: 4C0C0F06
	v_add_f32_e32 v5, v5, v11                                  // 000000A08050: 060A1705
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A08054: BF870214
	v_add_f32_e32 v3, v3, v12                                  // 000000A08058: 06061903
	v_mov_b32_dpp v13, v2 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A0805C: 7E1A02FA FF016802
	v_cndmask_b32_e64 v2, -v2, v2, s5                          // 000000A08064: D5010002 20160502
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 000000A0806C: BF870254
	v_mov_b32_dpp v11, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A08070: 7E1602FA FF016805
	v_cndmask_b32_e64 v5, -v5, v5, s5                          // 000000A08078: D5010005 20160B05
	v_add_nc_u32_e32 v8, 8, v8                                 // 000000A08080: 4A101088
	v_mov_b32_dpp v12, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A08084: 7E1802FA FF016803
	v_cndmask_b32_e64 v3, -v3, v3, s5                          // 000000A0808C: D5010003 20160703
	v_dual_add_f32 v4, v4, v10 :: v_dual_add_f32 v5, v5, v11   // 000000A08094: C9081504 04041705
	v_add_f32_e32 v2, v2, v13                                  // 000000A0809C: 06041B02
	v_cmp_le_i32_e32 vcc_lo, s31, v8                           // 000000A080A0: 7C86101F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A080A4: BF870214
	v_dual_add_f32 v3, v3, v12 :: v_dual_add_nc_u32 v6, v9, v6 // 000000A080A8: C9201903 03060D09
	v_dual_mov_b32 v11, v5 :: v_dual_mov_b32 v10, v4           // 000000A080B0: CA100105 0B0A0104
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000A080B8: BF870234
	v_mov_b32_e32 v13, v2                                      // 000000A080BC: 7E1A0302
	v_cndmask_b32_e64 v5, -v5, v5, s0                          // 000000A080C0: D5010005 20020B05
	v_cndmask_b32_e64 v4, -v4, v4, s0                          // 000000A080C8: D5010004 20020904
	v_permlanex16_b32 v11, v11, s54, 0xfedcba98                // 000000A080D0: D65C000B 03FC6D0B FEDCBA98
	v_mov_b32_e32 v12, v3                                      // 000000A080DC: 7E180303
	v_cndmask_b32_e64 v2, -v2, v2, s0                          // 000000A080E0: D5010002 20020502
	v_cndmask_b32_e64 v3, -v3, v3, s0                          // 000000A080E8: D5010003 20020703
	v_permlanex16_b32 v10, v10, s54, 0xfedcba98                // 000000A080F0: D65C000A 03FC6D0A FEDCBA98
	v_permlanex16_b32 v13, v13, s54, 0xfedcba98                // 000000A080FC: D65C000D 03FC6D0D FEDCBA98
	v_add_f32_e32 v5, v5, v11                                  // 000000A08108: 060A1705
	v_permlanex16_b32 v12, v12, s54, 0xfedcba98                // 000000A0810C: D65C000C 03FC6D0C FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A08118: BF870214
	v_dual_add_f32 v4, v4, v10 :: v_dual_add_nc_u32 v9, 0x800, v9// 000000A0811C: C9201504 040812FF 00000800
	v_add_f32_e32 v7, v2, v13                                  // 000000A08128: 060E1B02
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A0812C: BF870214
	v_fma_mixhi_f16 v2, v5, s59, 0                             // 000000A08130: CC220002 02007705
	v_add_f32_e32 v10, v3, v12                                 // 000000A08138: 06141903
	s_or_b32 s34, vcc_lo, s34                                  // 000000A0813C: 8C22226A
	v_fma_mixlo_f16 v2, v4, s59, 0                             // 000000A08140: CC210002 02007704
	v_fma_mixhi_f16 v3, v7, s59, 0                             // 000000A08148: CC220003 02007707
	s_delay_alu instid0(VALU_DEP_3)                            // 000000A08150: BF870003
	v_fma_mixlo_f16 v3, v10, s59, 0                            // 000000A08154: CC210003 0200770A
	ds_store_b64 v6, v[2:3] offset:22016                       // 000000A0815C: D9345600 00000206
	s_and_not1_b32 exec_lo, exec_lo, s34                       // 000000A08164: 917E227E
	s_cbranch_execz 289                                        // 000000A08168: BFA50121 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi3EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x8f0>
	.long 0xd72d0002                                           // 000000A0816C: D72D0002
	v_cndmask_b32_e32 v0, v8, v58, vcc_lo                      // 000000A08170: 02007508
	s_mov_b32 s6, -1                                           // 000000A08174: BE8600C1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A08178: BF870091
	.long 0xd72c0003                                           // 000000A0817C: D72C0003
	v_cndmask_b32_e32 v0, v2, v53, vcc_lo                      // 000000A08180: 02006B02
	v_sub_nc_u32_e32 v3, v8, v3                                // 000000A08184: 4C060708
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000A08188: BF870121
	v_subrev_nc_u32_e32 v5, s53, v3                            // 000000A0818C: 4E0A0635
	v_cmp_le_u32_e32 vcc_lo, s53, v3                           // 000000A08190: 7C960635
	v_dual_cndmask_b32 v3, v3, v5 :: v_dual_add_nc_u32 v4, 1, v2// 000000A08194: CA600B03 03040481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A0819C: BF870111
	v_cndmask_b32_e32 v2, v2, v4, vcc_lo                       // 000000A081A0: 02040902
	v_cmp_le_u32_e32 vcc_lo, s53, v3                           // 000000A081A4: 7C960635
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A081A8: BF870092
	v_add_nc_u32_e32 v4, 1, v2                                 // 000000A081AC: 4A080481
	v_cndmask_b32_e32 v2, v2, v4, vcc_lo                       // 000000A081B0: 02040902
	s_and_not1_b32 vcc_lo, exec_lo, s52                        // 000000A081B4: 916A347E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A081B8: BF870091
	v_xor_b32_e32 v11, s55, v2                                 // 000000A081BC: 3A160437
	v_subrev_nc_u32_e32 v10, s55, v11                          // 000000A081C0: 4E141637
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000A081C4: BF8700A1
	v_mad_u64_u32 v[6:7], null, s57, v10, v[1:2]               // 000000A081C8: D6FE7C06 04061439
	v_min_i32_e32 v2, s51, v10                                 // 000000A081D0: 22041433
	v_mad_i64_i32 v[4:5], null, v2, s50, 0                     // 000000A081D4: D6FF7C04 02006502
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A081DC: BF870093
	v_ashrrev_i32_e32 v7, 31, v6                               // 000000A081E0: 340E0C9F
	.long 0xd73c0002                                           // 000000A081E4: D73C0002
	v_cndmask_b32_e32 v1, 1, v6, vcc_lo                        // 000000A081E8: 02020C81
	s_cbranch_vccnz 212                                        // 000000A081EC: BFA400D4 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi3EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x840>
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A081F0: BF870093
	.long 0xd7006a06                                           // 000000A081F4: D7006A06
	v_cndmask_b32_e32 v1, v4, v6, vcc_lo                       // 000000A081F8: 02020D04
	v_add_co_ci_u32_e64 v7, null, v5, v7, vcc_lo               // 000000A081FC: D5207C07 01AA0F05
	.long 0x7f383880                                           // 000000A08204: 7F383880
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A08208: BF870112
	.long 0xd73c0006                                           // 000000A0820C: D73C0006
	v_cndmask_b32_e32 v1, 1, v6, vcc_lo                        // 000000A08210: 02020C81
	.long 0x7f3e399c                                           // 000000A08214: 7F3E399C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A08218: BF870092
	.long 0xd7006a0c                                           // 000000A0821C: D7006A0C
	v_cndmask_b32_e32 v1, s38, v6, vcc_lo                      // 000000A08220: 02020C26
	v_add_co_ci_u32_e64 v13, null, s39, v7, vcc_lo             // 000000A08224: D5207C0D 01AA0E27
	.long 0xd7006a06                                           // 000000A0822C: D7006A06
	v_cndmask_b32_e32 v1, s40, v6, vcc_lo                      // 000000A08230: 02020C28
	s_delay_alu instid0(VALU_DEP_1)                            // 000000A08234: BF870001
	v_add_co_ci_u32_e64 v7, null, s41, v7, vcc_lo              // 000000A08238: D5207C07 01AA0E29
	global_load_b64 v[12:13], v[12:13], off                    // 000000A08240: DC560000 0C7C000C
	.long 0xd7006a0e                                           // 000000A08248: D7006A0E
	v_cndmask_b32_e32 v1, s26, v2, vcc_lo                      // 000000A0824C: 0202041A
	global_load_b64 v[6:7], v[6:7], off                        // 000000A08250: DC560000 067C0006
	v_add_co_ci_u32_e64 v15, null, s27, v3, vcc_lo             // 000000A08258: D5207C0F 01AA061B
	s_clause 0x1                                               // 000000A08260: BF850001
	global_load_b32 v16, v[14:15], off                         // 000000A08264: DC520000 107C000E
	global_load_d16_b16 v14, v[14:15], off offset:4            // 000000A0826C: DC820004 0E7C000E
	s_waitcnt vmcnt(3)                                         // 000000A08274: BF890FF7
	.long 0x7e1e390c                                           // 000000A08278: 7E1E390C
	s_waitcnt vmcnt(2)                                         // 000000A0827C: BF890BF7
	v_and_b32_e32 v38, 0xffff0000, v6                          // 000000A08280: 364C0CFF FFFF0000
	v_lshlrev_b32_e32 v6, 16, v6                               // 000000A08288: 300C0C90
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A0828C: BF870093
	v_lshlrev_b32_e32 v15, 16, v15                             // 000000A08290: 301E1E90
	v_mul_f32_e32 v19, 0xbfb8aa3b, v15                         // 000000A08294: 10261EFF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000A0829C: BF870291
	v_exp_f32_e32 v19, v19                                     // 000000A082A0: 7E264B13
	v_dual_add_f32 v19, 1.0, v19 :: v_dual_and_b32 v12, 0xffff0000, v12// 000000A082A4: C92426F2 130C18FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A082B0: BF870111
	v_mul_f32_e32 v18, 0xbfb8aa3b, v12                         // 000000A082B4: 102418FF BFB8AA3B
	v_div_scale_f32 v23, null, v19, v19, v15                   // 000000A082BC: D6FC7C17 043E2713
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000A082C4: BF8701B2
	v_exp_f32_e32 v18, v18                                     // 000000A082C8: 7E244B12
	v_lshlrev_b32_e32 v17, 16, v13                             // 000000A082CC: 30221A90
	v_div_scale_f32 v36, s7, v15, v19, v15                     // 000000A082D0: D6FC0724 043E270F
	v_rcp_f32_e32 v27, v23                                     // 000000A082D8: 7E365517
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A082DC: BF870196
	v_add_f32_e32 v18, 1.0, v18                                // 000000A082E0: 062424F2
	v_mul_f32_e32 v20, 0xbfb8aa3b, v17                         // 000000A082E4: 102822FF BFB8AA3B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A082EC: BF870195
	v_fma_f32 v35, -v23, v27, 1.0                              // 000000A082F0: D6130023 23CA3717
	v_div_scale_f32 v22, null, v18, v18, v12                   // 000000A082F8: D6FC7C16 04322512
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000A08300: BF8701B3
	v_exp_f32_e32 v20, v20                                     // 000000A08304: 7E284B14
	v_and_b32_e32 v13, 0xffff0000, v13                         // 000000A08308: 361A1AFF FFFF0000
	v_div_scale_f32 v32, vcc_lo, v12, v18, v12                 // 000000A08310: D6FC6A20 0432250C
	v_rcp_f32_e32 v25, v22                                     // 000000A08318: 7E325516
	s_delay_alu instid0(TRANS32_DEP_2) | instid1(VALU_DEP_2)   // 000000A0831C: BF870106
	v_dual_add_f32 v20, 1.0, v20 :: v_dual_mul_f32 v21, 0xbfb8aa3b, v13// 000000A08320: C90628F2 14141AFF BFB8AA3B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A0832C: BF870115
	v_fma_f32 v33, -v22, v25, 1.0                              // 000000A08330: D6130021 23CA3316
	v_div_scale_f32 v24, null, v20, v20, v17                   // 000000A08338: D6FC7C18 04462914
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000A08340: BF8701A3
	v_exp_f32_e32 v21, v21                                     // 000000A08344: 7E2A4B15
	v_div_scale_f32 v34, s6, v17, v20, v17                     // 000000A08348: D6FC0622 04462911
	v_fmac_f32_e32 v25, v33, v25                               // 000000A08350: 56323321
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 000000A08354: BF870313
	v_rcp_f32_e32 v29, v24                                     // 000000A08358: 7E3A5518
	v_add_f32_e32 v21, 1.0, v21                                // 000000A0835C: 062A2AF2
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A08360: BF870115
	v_fma_f32 v37, -v24, v29, 1.0                              // 000000A08364: D6130025 23CA3B18
	v_div_scale_f32 v26, null, v21, v21, v13                   // 000000A0836C: D6FC7C1A 04362B15
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000A08374: BF8701A2
	v_fmac_f32_e32 v29, v37, v29                               // 000000A08378: 563A3B25
	v_mul_f32_e32 v37, v32, v25                                // 000000A0837C: 104A3320
	v_rcp_f32_e32 v30, v26                                     // 000000A08380: 7E3C551A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A08384: BF870091
	v_fma_f32 v42, -v22, v37, v32                              // 000000A08388: D613002A 24824B16
	v_fmac_f32_e32 v37, v42, v25                               // 000000A08390: 564A332A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A08394: BF870115
	v_fma_f32 v33, -v26, v30, 1.0                              // 000000A08398: D6130021 23CA3D1A
	v_fma_f32 v22, -v22, v37, v32                              // 000000A083A0: D6130016 24824B16
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A083A8: BF870112
	v_fmac_f32_e32 v30, v33, v30                               // 000000A083AC: 563C3D21
	v_div_fmas_f32 v22, v22, v25, v37                          // 000000A083B0: D6370016 04963316
	s_mov_b32 vcc_lo, s7                                       // 000000A083B8: BEEA0007
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000A083BC: BF8701B1
	v_div_fixup_f32 v12, v22, v18, v12                         // 000000A083C0: D627000C 04322516
	v_fmac_f32_e32 v27, v35, v27                               // 000000A083C8: 56363723
	v_div_scale_f32 v35, s8, v13, v21, v13                     // 000000A083CC: D6FC0823 04362B0D
	v_mul_f32_e32 v12, v12, v38                                // 000000A083D4: 10184D0C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A083D8: BF870193
	v_mul_f32_e32 v33, v36, v27                                // 000000A083DC: 10423724
	v_mul_f32_e32 v43, v35, v30                                // 000000A083E0: 10563D23
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A083E4: BF870193
	.long 0x7e38398c                                           // 000000A083E8: 7E38398C
	v_fma_f32 v44, -v23, v33, v36                              // 000000A083EC: D613002C 24924317
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A083F4: BF870113
	v_fma_f32 v42, -v26, v43, v35                              // 000000A083F8: D613002A 248E571A
	v_fmac_f32_e32 v33, v44, v27                               // 000000A08400: 5642372C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A08404: BF870112
	v_fmac_f32_e32 v43, v42, v30                               // 000000A08408: 56563D2A
	v_fma_f32 v23, -v23, v33, v36                              // 000000A0840C: D6130017 24924317
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A08414: BF870112
	v_fma_f32 v22, -v26, v43, v35                              // 000000A08418: D6130016 248E571A
	v_div_fmas_f32 v23, v23, v27, v33                          // 000000A08420: D6370017 04863717
	s_mov_b32 vcc_lo, s6                                       // 000000A08428: BEEA0006
	s_mov_b32 s6, 0                                            // 000000A0842C: BE860080
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000A08430: BF870121
	v_div_fixup_f32 v15, v23, v19, v15                         // 000000A08434: D627000F 043E2717
	v_lshlrev_b32_e32 v19, 16, v7                              // 000000A0843C: 30260E90
	v_dual_mul_f32 v6, v15, v6 :: v_dual_and_b32 v7, 0xffff0000, v7// 000000A08440: C8E40D0F 06060EFF FFFF0000
	v_mul_f32_e32 v39, v34, v29                                // 000000A0844C: 104E3B22
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A08450: BF870112
	.long 0x7e3e3986                                           // 000000A08454: 7E3E3986
	v_fma_f32 v45, -v24, v39, v34                              // 000000A08458: D613002D 248A4F18
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A08460: BF870091
	v_fmac_f32_e32 v39, v45, v29                               // 000000A08464: 564E3B2D
	v_fma_f32 v24, -v24, v39, v34                              // 000000A08468: D6130018 248A4F18
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000A08470: BF870131
	v_div_fmas_f32 v18, v24, v29, v39                          // 000000A08474: D6370012 049E3B18
	s_mov_b32 vcc_lo, s8                                       // 000000A0847C: BEEA0008
	v_div_fmas_f32 v15, v22, v30, v43                          // 000000A08480: D637000F 04AE3D16
	v_div_fixup_f32 v17, v18, v20, v17                         // 000000A08488: D6270011 04462912
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000A08490: BF8701A2
	v_div_fixup_f32 v13, v15, v21, v13                         // 000000A08494: D627000D 04362B0F
	v_and_b32_e32 v15, 1, v28                                  // 000000A0849C: 361E3881
	v_mul_f32_e32 v17, v17, v19                                // 000000A084A0: 10222711
	v_and_b32_e32 v19, 1, v31                                  // 000000A084A4: 36263E81
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A084A8: BF870214
	v_mul_f32_e32 v7, v13, v7                                  // 000000A084AC: 100E0F0D
	v_add3_u32 v12, v12, v15, 0x7fff                           // 000000A084B0: D655000C 03FE1F0C 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A084BC: BF870214
	v_bfe_u32 v18, v17, 16, 1                                  // 000000A084C0: D6100012 02052111
	v_add3_u32 v6, v6, v19, 0x7fff                             // 000000A084C8: D6550006 03FE2706 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A084D4: BF870214
	v_bfe_u32 v15, v7, 16, 1                                   // 000000A084D8: D610000F 02052107
	v_and_b32_e32 v12, 0xffff0000, v12                         // 000000A084E0: 361818FF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A084E8: BF870214
	v_add3_u32 v13, v17, v18, 0x7fff                           // 000000A084EC: D655000D 03FE2511 00007FFF
	v_and_b32_e32 v6, 0xffff0000, v6                           // 000000A084F8: 360C0CFF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A08500: BF870194
	v_add3_u32 v7, v7, v15, 0x7fff                             // 000000A08504: D6550007 03FE1F07 00007FFF
	v_and_b32_e32 v17, 0xffff0000, v13                         // 000000A08510: 36221AFF FFFF0000
	s_waitcnt vmcnt(1)                                         // 000000A08518: BF8907F7
	v_fma_mix_f32 v13, v16, v12, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000A0851C: CC20080D 8A021910
	v_fma_mix_f32 v15, v16, v6, neg(0) op_sel_hi:[1,0,0]       // 000000A08524: CC20000F 8A020D10
	s_waitcnt vmcnt(0)                                         // 000000A0852C: BF8903F7
	v_fma_mix_f32 v12, v14, v17, neg(0) op_sel_hi:[1,0,0]      // 000000A08530: CC20000C 8A02230E
	v_and_b32_e32 v14, 0xffff0000, v7                          // 000000A08538: 361C0EFF FFFF0000
	s_and_not1_b32 vcc_lo, exec_lo, s6                         // 000000A08540: 916A067E
	s_cbranch_vccnz 65125                                      // 000000A08544: BFA4FE65 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi3EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x1dc>
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A08548: BF870093
	.long 0xd73c0004                                           // 000000A0854C: D73C0004
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 000000A08550: 02020881
	.long 0xd7006a04                                           // 000000A08554: D7006A04
	v_cndmask_b32_e32 v1, s38, v4, vcc_lo                      // 000000A08558: 02020826
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A0855C: BF870111
	v_add_co_ci_u32_e64 v5, null, s39, v5, vcc_lo              // 000000A08560: D5207C05 01AA0A27
	.long 0xd7006a04                                           // 000000A08568: D7006A04
	v_cndmask_b32_e32 v1, v4, v2, vcc_lo                       // 000000A0856C: 02020504
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000A08570: BF8700A1
	v_add_co_ci_u32_e64 v5, null, v5, v3, vcc_lo               // 000000A08574: D5207C05 01AA0705
	.long 0xd7006a06                                           // 000000A0857C: D7006A06
	v_cndmask_b32_e32 v1, s26, v2, vcc_lo                      // 000000A08580: 0202041A
	v_add_co_ci_u32_e64 v7, null, s27, v3, vcc_lo              // 000000A08584: D5207C07 01AA061B
	global_load_b64 v[4:5], v[4:5], off                        // 000000A0858C: DC560000 047C0004
	s_clause 0x1                                               // 000000A08594: BF850001
	global_load_b32 v14, v[6:7], off                           // 000000A08598: DC520000 0E7C0006
	global_load_d16_b16 v6, v[6:7], off offset:4               // 000000A085A0: DC820004 067C0006
	s_waitcnt vmcnt(2)                                         // 000000A085A8: BF890BF7
	.long 0x7e0e3904                                           // 000000A085AC: 7E0E3904
	v_and_b32_e32 v4, 0xffff0000, v4                           // 000000A085B0: 360808FF FFFF0000
	v_lshlrev_b32_e32 v12, 16, v5                              // 000000A085B8: 30180A90
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000A085BC: BF8701A3
	v_lshlrev_b32_e32 v7, 16, v7                               // 000000A085C0: 300E0E90
	s_waitcnt vmcnt(1)                                         // 000000A085C4: BF8907F7
	v_fma_mix_f32 v13, v14, v4, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000A085C8: CC20080D 8A02090E
	s_waitcnt vmcnt(0)                                         // 000000A085D0: BF8903F7
	v_fma_mix_f32 v12, v6, v12, neg(0) op_sel_hi:[1,0,0]       // 000000A085D4: CC20000C 8A021906
	v_fma_mix_f32 v15, v14, v7, neg(0) op_sel_hi:[1,0,0]       // 000000A085DC: CC20000F 8A020F0E
	v_and_b32_e32 v14, 0xffff0000, v5                          // 000000A085E4: 361C0AFF FFFF0000
	s_branch 65083                                             // 000000A085EC: BFA0FE3B <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi3EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x1dc>
	s_or_b32 exec_lo, exec_lo, s33                             // 000000A085F0: 8C7E217E
	s_bfe_i32 s34, s35, 0x1001c                                // 000000A085F4: 93A2FF23 0001001C
	s_lshr_b32 s3, s11, 28                                     // 000000A085FC: 85039C0B
	s_lshr_b64 s[0:1], s[34:35], 29                            // 000000A08600: 85809D22
	s_add_i32 s3, s50, s3                                      // 000000A08604: 81030332
	s_add_i32 s0, s0, 7                                        // 000000A08608: 81008700
	s_lshl_b32 s1, s35, 3                                      // 000000A0860C: 84018323
	s_ashr_i32 s0, s0, 3                                       // 000000A08610: 86008300
	s_lshl_b32 s4, s29, 3                                      // 000000A08614: 8404831D
	.long 0xd72c0001                                           // 000000A08618: D72C0001
	v_cndmask_b32_e32 v1, s0, v40, vcc_lo                      // 000000A0861C: 02025000
	v_lshlrev_b32_e32 v19, 2, v41                              // 000000A08620: 30265282
	s_waitcnt lgkmcnt(0)                                       // 000000A08624: BF89FC07
	s_barrier                                                  // 000000A08628: BFBD0000
	buffer_gl0_inv                                             // 000000A0862C: E0AC0000 00000000
	v_add_nc_u32_e32 v2, s0, v1                                // 000000A08634: 4A040200
	s_ashr_i32 s0, s3, 4                                       // 000000A08638: 86008403
	s_ashr_i32 s3, s4, 31                                      // 000000A0863C: 86039F04
	s_mul_hi_i32 s5, s10, s0                                   // 000000A08640: 9705000A
	s_mul_i32 s0, s10, s0                                      // 000000A08644: 9600000A
	v_min_i32_e32 v21, s1, v2                                  // 000000A08648: 222A0401
	s_add_u32 s0, s0, s4                                       // 000000A0864C: 80000400
	s_addc_u32 s1, s5, s3                                      // 000000A08650: 82010305
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A08654: BF870099
	s_lshl_b64 s[4:5], s[0:1], 10                              // 000000A08658: 84848A00
	v_cmp_lt_i32_e32 vcc_lo, v1, v21                           // 000000A0865C: 7C822B01
	s_add_u32 s1, s24, s4                                      // 000000A08660: 80010418
	s_addc_u32 s3, s25, s5                                     // 000000A08664: 82030519
	s_and_saveexec_b32 s4, vcc_lo                              // 000000A08668: BE84206A
	s_cbranch_execz 93                                         // 000000A0866C: BFA5005D <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi3EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0xae4>
	.long 0xd7010002                                           // 000000A08670: D7010002
	v_cndmask_b32_e32 v0, v41, v129, vcc_lo                    // 000000A08674: 02010329
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000A08678: BF870121
	v_cndmask_b32_e64 v3, v2, 31, s0                           // 000000A0867C: D5010003 00013F02
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000A08684: 3404029F
	.long 0xd44c0000                                           // 000000A08688: D44C0000
	v_cndmask_b32_e32 v1, 31, v3, vcc_lo                       // 000000A0868C: 0202069F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A08690: BF870091
	v_cndmask_b32_e64 v5, 0xe1, 1, s0                          // 000000A08694: D5010005 000102FF 000000E1
	v_dual_mov_b32 v4, 0 :: v_dual_add_nc_u32 v7, v5, v3       // 000000A086A0: CA200080 04060705
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A086A8: BF870114
	.long 0xd73c0005                                           // 000000A086AC: D73C0005
	v_cndmask_b32_e32 v1, 10, v1, vcc_lo                       // 000000A086B0: 0202028A
	.long 0xd73c0002                                           // 000000A086B4: D73C0002
	v_cndmask_b32_e32 v1, 2, v3, vcc_lo                        // 000000A086B8: 02020682
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000A086BC: BF870223
	v_lshlrev_b32_e32 v4, 24, v7                               // 000000A086C0: 30080E98
	v_bfe_i32 v7, v7, 7, 1                                     // 000000A086C4: D6110007 02050F07
	.long 0xd7000008                                           // 000000A086CC: D7000008
	v_cndmask_b32_e32 v1, s1, v5, vcc_lo                       // 000000A086D0: 02020A01
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A086D4: BF870211
	v_add_co_ci_u32_e64 v9, null, s3, v6, s0                   // 000000A086D8: D5207C09 00020C03
	v_ashrrev_i32_e32 v6, 22, v4                               // 000000A086E0: 340C0896
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A086E4: BF870093
	.long 0xd7000004                                           // 000000A086E8: D7000004
	v_cndmask_b32_e32 v1, v8, v2, vcc_lo                       // 000000A086EC: 02020508
	v_add_co_ci_u32_e64 v5, null, v9, v3, s0                   // 000000A086F0: D5207C05 00020709
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A086F8: BF870093
	.long 0xd7000006                                           // 000000A086FC: D7000006
	v_cndmask_b32_e32 v1, v8, v6, vcc_lo                       // 000000A08700: 02020D08
	v_add_co_ci_u32_e64 v7, null, v9, v7, s0                   // 000000A08704: D5207C07 00020F09
	.long 0xd7000008                                           // 000000A0870C: D7000008
	v_cndmask_b32_e32 v1, v8, v19, vcc_lo                      // 000000A08710: 02022708
	s_delay_alu instid0(VALU_DEP_1)                            // 000000A08714: BF870001
	v_add_co_ci_u32_e64 v9, null, 0, v9, s0                    // 000000A08718: D5207C09 00021280
	s_clause 0x17                                              // 000000A08720: BF850017
	global_load_b32 v2, v[4:5], off                            // 000000A08724: DC520000 027C0004
	global_load_b32 v92, v[4:5], off offset:128                // 000000A0872C: DC520080 5C7C0004
	global_load_b32 v89, v[4:5], off offset:256                // 000000A08734: DC520100 597C0004
	global_load_b32 v86, v[4:5], off offset:384                // 000000A0873C: DC520180 567C0004
	global_load_b32 v83, v[4:5], off offset:512                // 000000A08744: DC520200 537C0004
	global_load_b32 v80, v[4:5], off offset:640                // 000000A0874C: DC520280 507C0004
	global_load_b32 v77, v[4:5], off offset:768                // 000000A08754: DC520300 4D7C0004
	global_load_b32 v59, v[4:5], off offset:896                // 000000A0875C: DC520380 3B7C0004
	global_load_b32 v4, v[6:7], off                            // 000000A08764: DC520000 047C0006
	global_load_b32 v93, v[6:7], off offset:128                // 000000A0876C: DC520080 5D7C0006
	global_load_b32 v90, v[6:7], off offset:256                // 000000A08774: DC520100 5A7C0006
	global_load_b32 v87, v[6:7], off offset:384                // 000000A0877C: DC520180 577C0006
	global_load_b32 v84, v[6:7], off offset:512                // 000000A08784: DC520200 547C0006
	global_load_b32 v81, v[6:7], off offset:640                // 000000A0878C: DC520280 517C0006
	global_load_b32 v78, v[6:7], off offset:768                // 000000A08794: DC520300 4E7C0006
	global_load_b32 v60, v[6:7], off offset:896                // 000000A0879C: DC520380 3C7C0006
	global_load_b32 v3, v[8:9], off                            // 000000A087A4: DC520000 037C0008
	global_load_b32 v91, v[8:9], off offset:128                // 000000A087AC: DC520080 5B7C0008
	global_load_b32 v88, v[8:9], off offset:256                // 000000A087B4: DC520100 587C0008
	global_load_b32 v85, v[8:9], off offset:384                // 000000A087BC: DC520180 557C0008
	global_load_b32 v82, v[8:9], off offset:512                // 000000A087C4: DC520200 527C0008
	global_load_b32 v79, v[8:9], off offset:640                // 000000A087CC: DC520280 4F7C0008
	global_load_b32 v76, v[8:9], off offset:768                // 000000A087D4: DC520300 4C7C0008
	global_load_b32 v58, v[8:9], off offset:896                // 000000A087DC: DC520380 3A7C0008
	s_or_b32 exec_lo, exec_lo, s4                              // 000000A087E4: 8C7E047E
	v_dual_mov_b32 v20, 0 :: v_dual_mov_b32 v23, 0             // 000000A087E8: CA100080 14160080
	v_dual_mov_b32 v22, 0 :: v_dual_mov_b32 v27, 0             // 000000A087F0: CA100080 161A0080
	v_dual_mov_b32 v24, 0 :: v_dual_mov_b32 v29, 0             // 000000A087F8: CA100080 181C0080
	v_dual_mov_b32 v26, 0 :: v_dual_mov_b32 v31, 0             // 000000A08800: CA100080 1A1E0080
	v_dual_mov_b32 v28, 0 :: v_dual_mov_b32 v33, 0             // 000000A08808: CA100080 1C200080
	v_dual_mov_b32 v30, 0 :: v_dual_mov_b32 v35, 0             // 000000A08810: CA100080 1E220080
	v_dual_mov_b32 v32, 0 :: v_dual_mov_b32 v37, 0             // 000000A08818: CA100080 20240080
	v_dual_mov_b32 v34, 0 :: v_dual_mov_b32 v39, 0             // 000000A08820: CA100080 22260080
	v_dual_mov_b32 v36, 0 :: v_dual_mov_b32 v45, 0             // 000000A08828: CA100080 242C0080
	v_dual_mov_b32 v38, 0 :: v_dual_mov_b32 v25, 0             // 000000A08830: CA100080 26180080
	v_dual_mov_b32 v42, 0 :: v_dual_mov_b32 v51, 0             // 000000A08838: CA100080 2A320080
	v_dual_mov_b32 v44, 0 :: v_dual_mov_b32 v53, 0             // 000000A08840: CA100080 2C340080
	v_dual_mov_b32 v46, 0 :: v_dual_mov_b32 v47, 0             // 000000A08848: CA100080 2E2E0080
	v_dual_mov_b32 v48, 0 :: v_dual_mov_b32 v49, 0             // 000000A08850: CA100080 30300080
	v_dual_mov_b32 v50, 0 :: v_dual_mov_b32 v43, 0             // 000000A08858: CA100080 322A0080
	v_mov_b32_e32 v52, 0                                       // 000000A08860: 7E680280
	v_mov_b32_e32 v54, 0                                       // 000000A08864: 7E6C0280
	s_ashr_i32 s11, s10, 31                                    // 000000A08868: 860B9F0A
	s_and_saveexec_b32 s0, vcc_lo                              // 000000A0886C: BE80206A
	s_cbranch_execz 1077                                       // 000000A08870: BFA50435 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi3EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x1c48>
	v_dual_mov_b32 v20, 0 :: v_dual_add_nc_u32 v5, -1, v0      // 000000A08874: CA200080 140400C1
	v_mov_b32_e32 v22, 0                                       // 000000A0887C: 7E2C0280
	v_and_or_b32 v55, v0, 16, 0x5600                           // 000000A08880: D6570037 03FD2100 00005600
	v_dual_mov_b32 v23, 0 :: v_dual_lshlrev_b32 v56, 2, v41    // 000000A0888C: CA220080 17385282
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000A08894: BF8701B4
	v_dual_mov_b32 v24, 0 :: v_dual_and_b32 v5, 31, v5         // 000000A08898: CA240080 18040A9F
	v_dual_mov_b32 v27, 0 :: v_dual_mov_b32 v26, 0             // 000000A088A0: CA100080 1B1A0080
	v_dual_mov_b32 v28, 0 :: v_dual_mov_b32 v29, 0             // 000000A088A8: CA100080 1C1C0080
	v_dual_mov_b32 v30, 0 :: v_dual_lshlrev_b32 v57, 2, v5     // 000000A088B0: CA220080 1E380A82
	v_dual_mov_b32 v31, 0 :: v_dual_mov_b32 v32, 0             // 000000A088B8: CA100080 1F200080
	v_dual_mov_b32 v33, 0 :: v_dual_mov_b32 v34, 0             // 000000A088C0: CA100080 21220080
	v_dual_mov_b32 v35, 0 :: v_dual_mov_b32 v36, 0             // 000000A088C8: CA100080 23240080
	v_dual_mov_b32 v37, 0 :: v_dual_mov_b32 v38, 0             // 000000A088D0: CA100080 25260080
	v_dual_mov_b32 v39, 0 :: v_dual_mov_b32 v42, 0             // 000000A088D8: CA100080 272A0080
	v_dual_mov_b32 v45, 0 :: v_dual_mov_b32 v44, 0             // 000000A088E0: CA100080 2D2C0080
	v_dual_mov_b32 v25, 0 :: v_dual_mov_b32 v46, 0             // 000000A088E8: CA100080 192E0080
	v_dual_mov_b32 v51, 0 :: v_dual_mov_b32 v48, 0             // 000000A088F0: CA100080 33300080
	v_dual_mov_b32 v53, 0 :: v_dual_mov_b32 v50, 0             // 000000A088F8: CA100080 35320080
	v_mov_b32_e32 v47, 0                                       // 000000A08900: 7E5E0280
	v_dual_mov_b32 v49, 0 :: v_dual_mov_b32 v52, 0             // 000000A08904: CA100080 31340080
	v_dual_mov_b32 v43, 0 :: v_dual_mov_b32 v54, 0             // 000000A0890C: CA100080 2B360080
	s_mov_b32 s4, 0                                            // 000000A08914: BE840080
	s_movk_i32 s5, 0x1eee                                      // 000000A08918: B0051EEE
	s_branch 975                                               // 000000A0891C: BFA003CF <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi3EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x1b5c>
	s_or_b32 exec_lo, exec_lo, s6                              // 000000A08920: 8C7E067E
	s_waitcnt vmcnt(15)                                        // 000000A08924: BF893FF7
	v_alignbit_b32 v2, v2, v4, 16                              // 000000A08928: D6160002 02420902
	v_lshl_add_u32 v13, v1, 5, v55                             // 000000A08930: D646000D 04DD0B01
	s_waitcnt vmcnt(7)                                         // 000000A08938: BF891FF7
	v_bfe_u32 v14, v3, 12, 16                                  // 000000A0893C: D610000E 02411903
	v_bfe_u32 v15, v3, 8, 16                                   // 000000A08944: D610000F 02411103
	v_bfe_u32 v16, v3, 4, 16                                   // 000000A0894C: D6100010 02410903
	v_bfe_u32 v1, v2, 12, 16                                   // 000000A08954: D6100001 02411902
	v_bfe_u32 v5, v2, 8, 16                                    // 000000A0895C: D6100005 02411102
	.long 0xd72c000e                                           // 000000A08964: D72C000E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v14, vcc_lo              // 000000A08968: 02021CFF 83DCD12D
	.long 0xd72c000f                                           // 000000A08970: D72C000F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v15, vcc_lo              // 000000A08974: 02021EFF 83DCD12D
	v_alignbit_b32 v92, v92, v93, 16                           // 000000A0897C: D616005C 0242BB5C
	.long 0xd72c005f                                           // 000000A08984: D72C005F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v1, vcc_lo               // 000000A08988: 020202FF 83DCD12D
	.long 0xd72c0061                                           // 000000A08990: D72C0061
	v_cndmask_b32_e32 v1, 0x83dcd12d, v5, vcc_lo               // 000000A08994: 02020AFF 83DCD12D
	s_waitcnt vmcnt(6)                                         // 000000A0899C: BF891BF7
	v_bfe_u32 v100, v91, 4, 16                                 // 000000A089A0: D6100064 0241095B
	v_alignbit_b32 v89, v89, v90, 16                           // 000000A089A8: D6160059 0242B559
	v_bfe_u32 v93, v92, 12, 16                                 // 000000A089B0: D610005D 0241195C
	v_sad_u8 v14, v14, 0, 0x6400                               // 000000A089B8: D622000E 03FD010E 00006400
	v_sad_u8 v99, v15, 0, 0x6400                               // 000000A089C4: D6220063 03FD010F 00006400
	v_alignbit_b32 v86, v86, v87, 16                           // 000000A089D0: D6160056 0242AF56
	v_sad_u8 v95, v95, 0, 0x6400                               // 000000A089D8: D622005F 03FD015F 00006400
	v_sad_u8 v97, v97, 0, 0x6400                               // 000000A089E4: D6220061 03FD0161 00006400
	.long 0xd72c005d                                           // 000000A089F0: D72C005D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v93, vcc_lo              // 000000A089F4: 0202BAFF 83DCD12D
	v_bfe_u32 v90, v89, 12, 16                                 // 000000A089FC: D610005A 02411959
	v_bfe_u32 v87, v86, 12, 16                                 // 000000A08A04: D6100057 02411956
	v_and_b32_e32 v95, 0xffff, v95                             // 000000A08A0C: 36BEBEFF 0000FFFF
	v_alignbit_b32 v83, v83, v84, 16                           // 000000A08A14: D6160053 0242A953
	v_alignbit_b32 v80, v80, v81, 16                           // 000000A08A1C: D6160050 0242A350
	.long 0xd72c005a                                           // 000000A08A24: D72C005A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v90, vcc_lo              // 000000A08A28: 0202B4FF 83DCD12D
	.long 0xd72c0057                                           // 000000A08A30: D72C0057
	v_cndmask_b32_e32 v1, 0x83dcd12d, v87, vcc_lo              // 000000A08A34: 0202AEFF 83DCD12D
	v_lshl_or_b32 v95, v97, 16, v95                            // 000000A08A3C: D656005F 057D2161
	.long 0xd72c0061                                           // 000000A08A44: D72C0061
	v_cndmask_b32_e32 v1, 0x83dcd12d, v16, vcc_lo              // 000000A08A48: 020220FF 83DCD12D
	v_sad_u8 v93, v93, 0, 0x6400                               // 000000A08A50: D622005D 03FD015D 00006400
	v_bfe_u32 v84, v83, 12, 16                                 // 000000A08A5C: D6100054 02411953
	v_bfe_u32 v81, v80, 12, 16                                 // 000000A08A64: D6100051 02411950
	v_pk_fma_f16 v95, v95, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A08A6C: CC0E005F 0BFC0B5F 0000C931
	v_and_b32_e32 v4, 0xffff, v2                               // 000000A08A78: 360804FF 0000FFFF
	v_bfe_u32 v2, v2, 4, 16                                    // 000000A08A80: D6100002 02410902
	v_sad_u8 v90, v90, 0, 0x6400                               // 000000A08A88: D622005A 03FD015A 00006400
	v_sad_u8 v97, v97, 0, 0x6400                               // 000000A08A94: D6220061 03FD0161 00006400
	v_sad_u8 v87, v87, 0, 0x6400                               // 000000A08AA0: D6220057 03FD0157 00006400
	.long 0xd72c0060                                           // 000000A08AAC: D72C0060
	v_cndmask_b32_e32 v1, 0x83dcd12d, v4, vcc_lo               // 000000A08AB0: 020208FF 83DCD12D
	.long 0xd72c0062                                           // 000000A08AB8: D72C0062
	v_cndmask_b32_e32 v1, 0x83dcd12d, v2, vcc_lo               // 000000A08ABC: 020204FF 83DCD12D
	.long 0xd72c0054                                           // 000000A08AC4: D72C0054
	v_cndmask_b32_e32 v1, 0x83dcd12d, v84, vcc_lo              // 000000A08AC8: 0202A8FF 83DCD12D
	.long 0xd72c0051                                           // 000000A08AD0: D72C0051
	v_cndmask_b32_e32 v1, 0x83dcd12d, v81, vcc_lo              // 000000A08AD4: 0202A2FF 83DCD12D
	v_alignbit_b32 v77, v77, v78, 16                           // 000000A08ADC: D616004D 02429D4D
	v_alignbit_b32 v59, v59, v60, 16                           // 000000A08AE4: D616003B 0242793B
	v_cmp_eq_u32_e32 vcc_lo, v17, v21                          // 000000A08AEC: 7C942B11
	v_and_b32_e32 v93, 0xffff, v93                             // 000000A08AF0: 36BABAFF 0000FFFF
	v_sad_u8 v96, v96, 0, 0x6400                               // 000000A08AF8: D6220060 03FD0160 00006400
	v_sad_u8 v98, v98, 0, 0x6400                               // 000000A08B04: D6220062 03FD0162 00006400
	v_sad_u8 v84, v84, 0, 0x6400                               // 000000A08B10: D6220054 03FD0154 00006400
	v_sad_u8 v81, v81, 0, 0x6400                               // 000000A08B1C: D6220051 03FD0151 00006400
	v_bfe_u32 v78, v77, 12, 16                                 // 000000A08B28: D610004E 0241194D
	v_lshlrev_b32_e32 v96, 16, v96                             // 000000A08B30: 30C0C090
	v_bfe_u32 v60, v59, 12, 16                                 // 000000A08B34: D610003C 0241193B
	s_or_b32 s4, vcc_lo, s4                                    // 000000A08B3C: 8C04046A
	v_and_b32_e32 v90, 0xffff, v90                             // 000000A08B40: 36B4B4FF 0000FFFF
	.long 0xd72c004e                                           // 000000A08B48: D72C004E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 000000A08B4C: 02029CFF 83DCD12D
	v_and_or_b32 v96, 0xffff, v98, v96                         // 000000A08B54: D6570060 0582C4FF 0000FFFF
	.long 0xd72c003c                                           // 000000A08B60: D72C003C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v60, vcc_lo              // 000000A08B64: 020278FF 83DCD12D
	v_and_b32_e32 v84, 0xffff, v84                             // 000000A08B6C: 36A8A8FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3)                            // 000000A08B74: BF870003
	v_pk_fma_f16 v96, v96, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A08B78: CC0E0060 0BFC0B60 0000C931
	v_and_b32_e32 v94, 0xffff, v3                              // 000000A08B84: 36BC06FF 0000FFFF
	ds_load_b128 v[1:4], v13                                   // 000000A08B8C: DBFC0000 0100000D
	ds_load_b128 v[5:8], v13 offset:5120                       // 000000A08B94: DBFC1400 0500000D
	ds_load_b128 v[9:12], v13 offset:10240                     // 000000A08B9C: DBFC2800 0900000D
	v_sad_u8 v78, v78, 0, 0x6400                               // 000000A08BA4: D622004E 03FD014E 00006400
	v_sad_u8 v60, v60, 0, 0x6400                               // 000000A08BB0: D622003C 03FD013C 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000A08BBC: BF8700D2
	v_and_b32_e32 v78, 0xffff, v78                             // 000000A08BC0: 369C9CFF 0000FFFF
	s_waitcnt lgkmcnt(2)                                       // 000000A08BC8: BF89FC27
	v_dot2acc_f32_f16 v54, v95, v1                             // 000000A08BCC: 046C035F
	s_waitcnt lgkmcnt(0)                                       // 000000A08BD0: BF89FC07
	v_dot2acc_f32_f16 v43, v95, v9                             // 000000A08BD4: 0456135F
	v_dot2acc_f32_f16 v43, v96, v10                            // 000000A08BD8: 04561560
	.long 0xd72c005e                                           // 000000A08BDC: D72C005E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v94, vcc_lo              // 000000A08BE0: 0202BCFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A08BE8: BF870091
	v_sad_u8 v94, v94, 0, 0x6400                               // 000000A08BEC: D622005E 03FD015E 00006400
	v_lshlrev_b32_e32 v94, 16, v94                             // 000000A08BF8: 30BCBC90
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000A08BFC: BF870121
	v_and_or_b32 v94, 0xffff, v97, v94                         // 000000A08C00: D657005E 057AC2FF 0000FFFF
	v_dual_dot2acc_f32_f16 v54, v96, v2 :: v_dual_and_b32 v97, 0xffff, v92// 000000A08C0C: CB240560 3660B8FF 0000FFFF
	v_pk_fma_f16 v94, v94, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A08C18: CC0E005E 0BFC0B5E 0000C931
	v_and_b32_e32 v98, 0xffff, v14                             // 000000A08C24: 36C41CFF 0000FFFF
	ds_load_b128 v[13:16], v13 offset:15360                    // 000000A08C2C: DBFC3C00 0D00000D
	.long 0xd72c0061                                           // 000000A08C34: D72C0061
	v_cndmask_b32_e32 v1, 0x83dcd12d, v97, vcc_lo              // 000000A08C38: 0202C2FF 83DCD12D
	v_lshl_or_b32 v98, v99, 16, v98                            // 000000A08C40: D6560062 05892163
	v_bfe_u32 v99, v91, 8, 16                                  // 000000A08C48: D6100063 0241115B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A08C50: BF870212
	v_pk_fma_f16 v98, v98, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A08C54: CC0E0062 0BFC0B62 0000C931
	v_sad_u8 v97, v97, 0, 0x6400                               // 000000A08C60: D6220061 03FD0161 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A08C6C: BF870113
	.long 0xd72c0063                                           // 000000A08C70: D72C0063
	v_cndmask_b32_e32 v1, 0x83dcd12d, v99, vcc_lo              // 000000A08C74: 0202C6FF 83DCD12D
	v_dual_dot2acc_f32_f16 v54, v98, v3 :: v_dual_lshlrev_b32 v97, 16, v97// 000000A08C7C: CB220762 3660C290
	v_dot2acc_f32_f16 v43, v98, v11                            // 000000A08C84: 04561762
	s_waitcnt lgkmcnt(0)                                       // 000000A08C88: BF89FC07
	v_dot2acc_f32_f16 v49, v95, v13                            // 000000A08C8C: 04621B5F
	v_dot2acc_f32_f16 v52, v95, v5                             // 000000A08C90: 04680B5F
	v_bfe_u32 v95, v92, 8, 16                                  // 000000A08C94: D610005F 0241115C
	v_bfe_u32 v92, v92, 4, 16                                  // 000000A08C9C: D610005C 0241095C
	v_dot2acc_f32_f16 v43, v94, v12                            // 000000A08CA4: 0456195E
	v_dot2acc_f32_f16 v49, v96, v14                            // 000000A08CA8: 04621D60
	v_dot2acc_f32_f16 v52, v96, v6                             // 000000A08CAC: 04680D60
	.long 0xd72c005f                                           // 000000A08CB0: D72C005F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v95, vcc_lo              // 000000A08CB4: 0202BEFF 83DCD12D
	v_bfe_u32 v96, v91, 12, 16                                 // 000000A08CBC: D6100060 0241195B
	.long 0xd72c005c                                           // 000000A08CC4: D72C005C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v92, vcc_lo              // 000000A08CC8: 0202B8FF 83DCD12D
	v_and_b32_e32 v91, 0xffff, v91                             // 000000A08CD0: 36B6B6FF 0000FFFF
	v_dot2acc_f32_f16 v52, v98, v7                             // 000000A08CD8: 04680F62
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000A08CDC: BF870224
	.long 0xd72c0060                                           // 000000A08CE0: D72C0060
	v_cndmask_b32_e32 v1, 0x83dcd12d, v96, vcc_lo              // 000000A08CE4: 0202C0FF 83DCD12D
	v_sad_u8 v95, v95, 0, 0x6400                               // 000000A08CEC: D622005F 03FD015F 00006400
	.long 0xd72c005b                                           // 000000A08CF8: D72C005B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v91, vcc_lo              // 000000A08CFC: 0202B6FF 83DCD12D
	v_sad_u8 v92, v92, 0, 0x6400                               // 000000A08D04: D622005C 03FD015C 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000A08D10: BF8701A3
	v_lshl_or_b32 v93, v95, 16, v93                            // 000000A08D14: D656005D 0575215F
	v_sad_u8 v96, v96, 0, 0x6400                               // 000000A08D1C: D6220060 03FD0160 00006400
	v_and_or_b32 v92, 0xffff, v92, v97                         // 000000A08D28: D657005C 0586B8FF 0000FFFF
	v_sad_u8 v91, v91, 0, 0x6400                               // 000000A08D34: D622005B 03FD015B 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000A08D40: BF870224
	v_pk_fma_f16 v93, v93, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A08D44: CC0E005D 0BFC0B5D 0000C931
	v_dot2acc_f32_f16 v49, v98, v15                            // 000000A08D50: 04621F62
	v_pk_fma_f16 v92, v92, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A08D54: CC0E005C 0BFC0B5C 0000C931
	v_dot2acc_f32_f16 v52, v94, v8                             // 000000A08D60: 0468115E
	.long 0xd72c0062                                           // 000000A08D64: D72C0062
	v_cndmask_b32_e32 v1, 0x83dcd12d, v100, vcc_lo             // 000000A08D68: 0202C8FF 83DCD12D
	v_dual_dot2acc_f32_f16 v50, v93, v13 :: v_dual_and_b32 v95, 0xffff, v96// 000000A08D70: CB241B5D 325EC0FF 0000FFFF
	v_sad_u8 v96, v99, 0, 0x6400                               // 000000A08D7C: D6220060 03FD0163 00006400
	v_dual_dot2acc_f32_f16 v47, v93, v1 :: v_dual_dot2acc_f32_f16 v54, v94, v4// 000000A08D88: CB18035D 2F36095E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A08D90: BF870193
	v_dual_dot2acc_f32_f16 v50, v92, v14 :: v_dual_lshlrev_b32 v91, 16, v91// 000000A08D94: CB221D5C 325AB690
	v_lshl_or_b32 v95, v96, 16, v95                            // 000000A08D9C: D656005F 057D2160
	v_dot2acc_f32_f16 v53, v93, v5                             // 000000A08DA4: 046A0B5D
	v_dot2acc_f32_f16 v51, v93, v9                             // 000000A08DA8: 0466135D
	v_dot2acc_f32_f16 v47, v92, v2                             // 000000A08DAC: 045E055C
	v_bfe_u32 v93, v89, 8, 16                                  // 000000A08DB0: D610005D 02411159
	v_pk_fma_f16 v95, v95, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A08DB8: CC0E005F 0BFC0B5F 0000C931
	v_dual_dot2acc_f32_f16 v49, v94, v16 :: v_dual_and_b32 v94, 0xffff, v89// 000000A08DC4: CB24215E 315EB2FF 0000FFFF
	v_sad_u8 v97, v98, 0, 0x6400                               // 000000A08DD0: D6220061 03FD0162 00006400
	v_bfe_u32 v89, v89, 4, 16                                  // 000000A08DDC: D6100059 02410959
	s_waitcnt vmcnt(5)                                         // 000000A08DE4: BF8917F7
	v_bfe_u32 v96, v88, 12, 16                                 // 000000A08DE8: D6100060 02411958
	.long 0xd72c005d                                           // 000000A08DF0: D72C005D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v93, vcc_lo              // 000000A08DF4: 0202BAFF 83DCD12D
	.long 0xd72c005e                                           // 000000A08DFC: D72C005E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v94, vcc_lo              // 000000A08E00: 0202BCFF 83DCD12D
	v_and_or_b32 v91, 0xffff, v97, v91                         // 000000A08E08: D657005B 056EC2FF 0000FFFF
	v_bfe_u32 v97, v88, 8, 16                                  // 000000A08E14: D6100061 02411158
	.long 0xd72c0060                                           // 000000A08E1C: D72C0060
	v_cndmask_b32_e32 v1, 0x83dcd12d, v96, vcc_lo              // 000000A08E20: 0202C0FF 83DCD12D
	v_bfe_u32 v98, v88, 4, 16                                  // 000000A08E28: D6100062 02410958
	v_and_b32_e32 v88, 0xffff, v88                             // 000000A08E30: 36B0B0FF 0000FFFF
	.long 0xd72c0059                                           // 000000A08E38: D72C0059
	v_cndmask_b32_e32 v1, 0x83dcd12d, v89, vcc_lo              // 000000A08E3C: 0202B2FF 83DCD12D
	v_sad_u8 v93, v93, 0, 0x6400                               // 000000A08E44: D622005D 03FD015D 00006400
	v_sad_u8 v94, v94, 0, 0x6400                               // 000000A08E50: D622005E 03FD015E 00006400
	.long 0xd72c0061                                           // 000000A08E5C: D72C0061
	v_cndmask_b32_e32 v1, 0x83dcd12d, v97, vcc_lo              // 000000A08E60: 0202C2FF 83DCD12D
	.long 0xd72c0058                                           // 000000A08E68: D72C0058
	v_cndmask_b32_e32 v1, 0x83dcd12d, v88, vcc_lo              // 000000A08E6C: 0202B0FF 83DCD12D
	v_pk_fma_f16 v91, v91, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A08E74: CC0E005B 0BFC0B5B 0000C931
	v_sad_u8 v96, v96, 0, 0x6400                               // 000000A08E80: D6220060 03FD0160 00006400
	v_lshl_or_b32 v90, v93, 16, v90                            // 000000A08E8C: D656005A 0569215D
	v_sad_u8 v89, v89, 0, 0x6400                               // 000000A08E94: D6220059 03FD0159 00006400
	v_dual_dot2acc_f32_f16 v50, v95, v15 :: v_dual_lshlrev_b32 v93, 16, v94// 000000A08EA0: CB221F5F 325CBC90
	.long 0xd72c005e                                           // 000000A08EA8: D72C005E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v98, vcc_lo              // 000000A08EAC: 0202C4FF 83DCD12D
	v_dual_dot2acc_f32_f16 v53, v92, v6 :: v_dual_and_b32 v96, 0xffff, v96// 000000A08EB4: CB240D5C 3560C0FF 0000FFFF
	v_sad_u8 v97, v97, 0, 0x6400                               // 000000A08EC0: D6220061 03FD0161 00006400
	v_sad_u8 v88, v88, 0, 0x6400                               // 000000A08ECC: D6220058 03FD0158 00006400
	v_pk_fma_f16 v90, v90, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A08ED8: CC0E005A 0BFC0B5A 0000C931
	v_dot2acc_f32_f16 v50, v91, v16                            // 000000A08EE4: 0464215B
	v_and_or_b32 v89, 0xffff, v89, v93                         // 000000A08EE8: D6570059 0576B2FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A08EF4: BF870214
	v_dual_dot2acc_f32_f16 v51, v92, v10 :: v_dual_lshlrev_b32 v88, 16, v88// 000000A08EF8: CB22155C 3358B090
	v_dual_dot2acc_f32_f16 v47, v95, v3 :: v_dual_dot2acc_f32_f16 v48, v90, v5// 000000A08F00: CB18075F 2F300B5A
	v_lshl_or_b32 v92, v97, 16, v96                            // 000000A08F08: D656005C 05812161
	v_sad_u8 v93, v94, 0, 0x6400                               // 000000A08F10: D622005D 03FD015E 00006400
	v_pk_fma_f16 v89, v89, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A08F1C: CC0E0059 0BFC0B59 0000C931
	v_dual_dot2acc_f32_f16 v53, v95, v7 :: v_dual_dot2acc_f32_f16 v46, v90, v9// 000000A08F28: CB180F5F 352E135A
	v_dot2acc_f32_f16 v51, v95, v11                            // 000000A08F30: 0466175F
	v_pk_fma_f16 v92, v92, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A08F34: CC0E005C 0BFC0B5C 0000C931
	v_and_or_b32 v88, 0xffff, v93, v88                         // 000000A08F40: D6570058 0562BAFF 0000FFFF
	v_dual_dot2acc_f32_f16 v48, v89, v6 :: v_dual_dot2acc_f32_f16 v47, v91, v4// 000000A08F4C: CB180D59 302E095B
	v_dual_dot2acc_f32_f16 v46, v89, v10 :: v_dual_dot2acc_f32_f16 v53, v91, v8// 000000A08F54: CB181559 2E34115B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A08F5C: BF870193
	v_pk_fma_f16 v88, v88, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A08F60: CC0E0058 0BFC0B58 0000C931
	v_dual_dot2acc_f32_f16 v48, v92, v7 :: v_dual_dot2acc_f32_f16 v25, v90, v1// 000000A08F6C: CB180F5C 3018035A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A08F74: BF870113
	v_dual_dot2acc_f32_f16 v51, v91, v12 :: v_dual_dot2acc_f32_f16 v46, v92, v11// 000000A08F78: CB18195B 332E175C
	v_dual_dot2acc_f32_f16 v45, v90, v13 :: v_dual_dot2acc_f32_f16 v48, v88, v8// 000000A08F80: CB181B5A 2D301158
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000A08F88: BF8701A3
	v_dot2acc_f32_f16 v25, v89, v2                             // 000000A08F8C: 04320559
	v_and_b32_e32 v90, 0xffff, v86                             // 000000A08F90: 36B4ACFF 0000FFFF
	v_dual_dot2acc_f32_f16 v46, v88, v12 :: v_dual_dot2acc_f32_f16 v45, v89, v14// 000000A08F98: CB181958 2E2C1D59
	v_bfe_u32 v89, v86, 8, 16                                  // 000000A08FA0: D6100059 02411156
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A08FA8: BF870004
	v_dot2acc_f32_f16 v25, v92, v3                             // 000000A08FAC: 0432075C
	v_bfe_u32 v86, v86, 4, 16                                  // 000000A08FB0: D6100056 02410956
	.long 0xd72c005a                                           // 000000A08FB8: D72C005A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v90, vcc_lo              // 000000A08FBC: 0202B4FF 83DCD12D
	s_waitcnt vmcnt(4)                                         // 000000A08FC4: BF8913F7
	v_bfe_u32 v91, v85, 12, 16                                 // 000000A08FC8: D610005B 02411955
	.long 0xd72c0059                                           // 000000A08FD0: D72C0059
	v_cndmask_b32_e32 v1, 0x83dcd12d, v89, vcc_lo              // 000000A08FD4: 0202B2FF 83DCD12D
	v_bfe_u32 v93, v85, 4, 16                                  // 000000A08FDC: D610005D 02410955
	.long 0xd72c0056                                           // 000000A08FE4: D72C0056
	v_cndmask_b32_e32 v1, 0x83dcd12d, v86, vcc_lo              // 000000A08FE8: 0202ACFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 000000A08FF0: BF870254
	.long 0xd72c005b                                           // 000000A08FF4: D72C005B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v91, vcc_lo              // 000000A08FF8: 0202B6FF 83DCD12D
	v_sad_u8 v90, v90, 0, 0x6400                               // 000000A09000: D622005A 03FD015A 00006400
	v_dot2acc_f32_f16 v25, v88, v4                             // 000000A0900C: 04320958
	v_sad_u8 v89, v89, 0, 0x6400                               // 000000A09010: D6220059 03FD0159 00006400
	v_sad_u8 v86, v86, 0, 0x6400                               // 000000A0901C: D6220056 03FD0156 00006400
	v_lshlrev_b32_e32 v90, 16, v90                             // 000000A09028: 30B4B490
	v_sad_u8 v91, v91, 0, 0x6400                               // 000000A0902C: D622005B 03FD015B 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A09038: BF870092
	v_and_or_b32 v86, 0xffff, v86, v90                         // 000000A0903C: D6570056 056AACFF 0000FFFF
	v_pk_fma_f16 v86, v86, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A09048: CC0E0056 0BFC0B56 0000C931
	v_and_b32_e32 v87, 0xffff, v87                             // 000000A09054: 36AEAEFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A0905C: BF870091
	v_lshl_or_b32 v87, v89, 16, v87                            // 000000A09060: D6560057 055D2159
	v_pk_fma_f16 v87, v87, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A09068: CC0E0057 0BFC0B57 0000C931
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000A09074: BF8701B1
	v_dual_dot2acc_f32_f16 v44, v87, v1 :: v_dual_dot2acc_f32_f16 v45, v92, v15// 000000A09078: CB180357 2C2C1F5C
	v_dot2acc_f32_f16 v42, v87, v5                             // 000000A09080: 04540B57
	v_bfe_u32 v92, v85, 8, 16                                  // 000000A09084: D610005C 02411155
	v_dual_dot2acc_f32_f16 v44, v86, v2 :: v_dual_and_b32 v85, 0xffff, v85// 000000A0908C: CB240556 2C54AAFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000A09098: BF8701A4
	v_dual_dot2acc_f32_f16 v45, v88, v16 :: v_dual_dot2acc_f32_f16 v38, v87, v13// 000000A0909C: CB182158 2D261B57
	.long 0xd72c0058                                           // 000000A090A4: D72C0058
	v_cndmask_b32_e32 v1, 0x83dcd12d, v93, vcc_lo              // 000000A090A8: 0202BAFF 83DCD12D
	.long 0xd72c0055                                           // 000000A090B0: D72C0055
	v_cndmask_b32_e32 v1, 0x83dcd12d, v85, vcc_lo              // 000000A090B4: 0202AAFF 83DCD12D
	v_dot2acc_f32_f16 v42, v86, v6                             // 000000A090BC: 04540D56
	.long 0xd72c005c                                           // 000000A090C0: D72C005C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v92, vcc_lo              // 000000A090C4: 0202B8FF 83DCD12D
	v_dot2acc_f32_f16 v38, v86, v14                            // 000000A090CC: 044C1D56
	v_mov_b32_e32 v93, v74                                     // 000000A090D0: 7EBA034A
	v_sad_u8 v88, v88, 0, 0x6400                               // 000000A090D4: D6220058 03FD0158 00006400
	v_sad_u8 v85, v85, 0, 0x6400                               // 000000A090E0: D6220055 03FD0155 00006400
	v_sad_u8 v90, v92, 0, 0x6400                               // 000000A090EC: D622005A 03FD015C 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A090F8: BF870092
	v_dual_mov_b32 v92, v68 :: v_dual_lshlrev_b32 v85, 16, v85 // 000000A090FC: CA220144 5C54AA90
	v_and_or_b32 v85, 0xffff, v88, v85                         // 000000A09104: D6570055 0556B0FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000A09110: BF870141
	v_pk_fma_f16 v85, v85, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A09114: CC0E0055 0BFC0B55 0000C931
	v_and_b32_e32 v89, 0xffff, v91                             // 000000A09120: 36B2B6FF 0000FFFF
	s_waitcnt vmcnt(3)                                         // 000000A09128: BF890FF7
	v_bfe_u32 v91, v82, 4, 16                                  // 000000A0912C: D610005B 02410952
	v_lshl_or_b32 v89, v90, 16, v89                            // 000000A09134: D6560059 0565215A
	v_bfe_u32 v90, v82, 8, 16                                  // 000000A0913C: D610005A 02411152
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000A09144: BF870232
	v_pk_fma_f16 v88, v89, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A09148: CC0E0058 0BFC0B59 0000C931
	v_bfe_u32 v89, v82, 12, 16                                 // 000000A09154: D6100059 02411952
	v_and_b32_e32 v82, 0xffff, v82                             // 000000A0915C: 36A4A4FF 0000FFFF
	.long 0xd72c005a                                           // 000000A09164: D72C005A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v90, vcc_lo              // 000000A09168: 0202B4FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A09170: BF870214
	v_dual_dot2acc_f32_f16 v42, v88, v7 :: v_dual_dot2acc_f32_f16 v39, v87, v9// 000000A09174: CB180F58 2A261357
	.long 0xd72c0059                                           // 000000A0917C: D72C0059
	v_cndmask_b32_e32 v1, 0x83dcd12d, v89, vcc_lo              // 000000A09180: 0202B2FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000A09188: BF870224
	.long 0xd72c0052                                           // 000000A0918C: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 000000A09190: 0202A4FF 83DCD12D
	v_dot2acc_f32_f16 v44, v88, v3                             // 000000A09198: 04580758
	v_dual_dot2acc_f32_f16 v42, v85, v8 :: v_dual_dot2acc_f32_f16 v39, v86, v10// 000000A0919C: CB181155 2A261556
	v_bfe_u32 v86, v83, 8, 16                                  // 000000A091A4: D6100056 02411153
	v_sad_u8 v90, v90, 0, 0x6400                               // 000000A091AC: D622005A 03FD015A 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_3)// 000000A091B8: BF8701D4
	v_dot2acc_f32_f16 v44, v85, v4                             // 000000A091BC: 04580955
	v_sad_u8 v89, v89, 0, 0x6400                               // 000000A091C0: D6220059 03FD0159 00006400
	v_dot2acc_f32_f16 v39, v88, v11                            // 000000A091CC: 044E1758
	.long 0xd72c0056                                           // 000000A091D0: D72C0056
	v_cndmask_b32_e32 v1, 0x83dcd12d, v86, vcc_lo              // 000000A091D4: 0202ACFF 83DCD12D
	v_sad_u8 v82, v82, 0, 0x6400                               // 000000A091DC: D6220052 03FD0152 00006400
	v_dot2acc_f32_f16 v39, v85, v12                            // 000000A091E8: 044E1955
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A091EC: BF870093
	v_sad_u8 v86, v86, 0, 0x6400                               // 000000A091F0: D6220056 03FD0156 00006400
	v_lshl_or_b32 v84, v86, 16, v84                            // 000000A091FC: D6560054 05512156
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000A09204: BF8701B1
	v_pk_fma_f16 v84, v84, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A09208: CC0E0054 0BFC0B54 0000C931
	v_and_b32_e32 v87, 0xffff, v83                             // 000000A09214: 36AEA6FF 0000FFFF
	v_bfe_u32 v83, v83, 4, 16                                  // 000000A0921C: D6100053 02410953
	v_dual_dot2acc_f32_f16 v37, v84, v1 :: v_dual_lshlrev_b32 v82, 16, v82// 000000A09224: CB220354 2552A490
	v_dot2acc_f32_f16 v36, v84, v5                             // 000000A0922C: 04480B54
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A09230: BF870214
	.long 0xd72c0057                                           // 000000A09234: D72C0057
	v_cndmask_b32_e32 v1, 0x83dcd12d, v87, vcc_lo              // 000000A09238: 0202AEFF 83DCD12D
	.long 0xd72c0053                                           // 000000A09240: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v83, vcc_lo              // 000000A09244: 0202A6FF 83DCD12D
	v_dot2acc_f32_f16 v35, v84, v9                             // 000000A0924C: 04461354
	v_dot2acc_f32_f16 v38, v88, v15                            // 000000A09250: 044C1F58
	v_dot2acc_f32_f16 v34, v84, v13                            // 000000A09254: 04441B54
	v_bfe_u32 v84, v80, 8, 16                                  // 000000A09258: D6100054 02411150
	s_waitcnt vmcnt(2)                                         // 000000A09260: BF890BF7
	v_bfe_u32 v88, v79, 4, 16                                  // 000000A09264: D6100058 0241094F
	v_sad_u8 v87, v87, 0, 0x6400                               // 000000A0926C: D6220057 03FD0157 00006400
	v_sad_u8 v83, v83, 0, 0x6400                               // 000000A09278: D6220053 03FD0153 00006400
	v_dot2acc_f32_f16 v38, v85, v16                            // 000000A09284: 044C2155
	v_bfe_u32 v85, v79, 12, 16                                 // 000000A09288: D6100055 0241194F
	.long 0xd72c0054                                           // 000000A09290: D72C0054
	v_cndmask_b32_e32 v1, 0x83dcd12d, v84, vcc_lo              // 000000A09294: 0202A8FF 83DCD12D
	v_lshlrev_b32_e32 v87, 16, v87                             // 000000A0929C: 30AEAE90
	.long 0xd72c0058                                           // 000000A092A0: D72C0058
	v_cndmask_b32_e32 v1, 0x83dcd12d, v88, vcc_lo              // 000000A092A4: 0202B0FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A092AC: BF870194
	.long 0xd72c0055                                           // 000000A092B0: D72C0055
	v_cndmask_b32_e32 v1, 0x83dcd12d, v85, vcc_lo              // 000000A092B4: 0202AAFF 83DCD12D
	v_and_or_b32 v83, 0xffff, v83, v87                         // 000000A092BC: D6570053 055EA6FF 0000FFFF
	v_sad_u8 v84, v84, 0, 0x6400                               // 000000A092C8: D6220054 03FD0154 00006400
	s_delay_alu instid0(VALU_DEP_2)                            // 000000A092D4: BF870002
	v_pk_fma_f16 v83, v83, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A092D8: CC0E0053 0BFC0B53 0000C931
	v_and_b32_e32 v86, 0xffff, v89                             // 000000A092E4: 36ACB2FF 0000FFFF
	.long 0xd72c0059                                           // 000000A092EC: D72C0059
	v_cndmask_b32_e32 v1, 0x83dcd12d, v91, vcc_lo              // 000000A092F0: 0202B6FF 83DCD12D
	v_sad_u8 v85, v85, 0, 0x6400                               // 000000A092F8: D6220055 03FD0155 00006400
	v_mov_b32_e32 v91, v74                                     // 000000A09304: 7EB6034A
	v_dot2acc_f32_f16 v37, v83, v2                             // 000000A09308: 044A0553
	v_lshl_or_b32 v86, v90, 16, v86                            // 000000A0930C: D6560056 0559215A
	v_dot2acc_f32_f16 v36, v83, v6                             // 000000A09314: 04480D53
	v_dot2acc_f32_f16 v35, v83, v10                            // 000000A09318: 04461553
	v_dual_dot2acc_f32_f16 v34, v83, v14 :: v_dual_and_b32 v83, 0xffff, v80// 000000A0931C: CB241D53 2252A0FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A09328: BF870004
	v_pk_fma_f16 v86, v86, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0932C: CC0E0056 0BFC0B56 0000C931
	v_sad_u8 v87, v89, 0, 0x6400                               // 000000A09338: D6220057 03FD0159 00006400
	v_bfe_u32 v80, v80, 4, 16                                  // 000000A09344: D6100050 02410950
	v_and_b32_e32 v81, 0xffff, v81                             // 000000A0934C: 36A2A2FF 0000FFFF
	.long 0xd72c0053                                           // 000000A09354: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v83, vcc_lo              // 000000A09358: 0202A6FF 83DCD12D
	v_dot2acc_f32_f16 v37, v86, v3                             // 000000A09360: 044A0756
	v_dot2acc_f32_f16 v36, v86, v7                             // 000000A09364: 04480F56
	v_dot2acc_f32_f16 v35, v86, v11                            // 000000A09368: 04461756
	v_and_or_b32 v82, 0xffff, v87, v82                         // 000000A0936C: D6570052 054AAEFF 0000FFFF
	v_bfe_u32 v87, v79, 8, 16                                  // 000000A09378: D6100057 0241114F
	.long 0xd72c0050                                           // 000000A09380: D72C0050
	v_cndmask_b32_e32 v1, 0x83dcd12d, v80, vcc_lo              // 000000A09384: 0202A0FF 83DCD12D
	v_dot2acc_f32_f16 v34, v86, v15                            // 000000A0938C: 04441F56
	v_sad_u8 v83, v83, 0, 0x6400                               // 000000A09390: D6220053 03FD0153 00006400
	v_pk_fma_f16 v82, v82, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0939C: CC0E0052 0BFC0B52 0000C931
	.long 0xd72c0057                                           // 000000A093A8: D72C0057
	v_cndmask_b32_e32 v1, 0x83dcd12d, v87, vcc_lo              // 000000A093AC: 0202AEFF 83DCD12D
	v_lshl_or_b32 v81, v84, 16, v81                            // 000000A093B4: D6560051 05452154
	v_and_b32_e32 v79, 0xffff, v79                             // 000000A093BC: 369E9EFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A093C4: BF870004
	v_dual_dot2acc_f32_f16 v34, v82, v16 :: v_dual_lshlrev_b32 v83, 16, v83// 000000A093C8: CB222152 2252A690
	v_sad_u8 v80, v80, 0, 0x6400                               // 000000A093D0: D6220050 03FD0150 00006400
	v_dot2acc_f32_f16 v36, v82, v8                             // 000000A093DC: 04481152
	v_pk_fma_f16 v81, v81, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A093E0: CC0E0051 0BFC0B51 0000C931
	v_sad_u8 v84, v87, 0, 0x6400                               // 000000A093EC: D6220054 03FD0157 00006400
	.long 0xd72c004f                                           // 000000A093F8: D72C004F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v79, vcc_lo              // 000000A093FC: 02029EFF 83DCD12D
	v_and_or_b32 v80, 0xffff, v80, v83                         // 000000A09404: D6570050 054EA0FF 0000FFFF
	v_and_b32_e32 v83, 0xffff, v85                             // 000000A09410: 36A6AAFF 0000FFFF
	v_dual_dot2acc_f32_f16 v37, v82, v4 :: v_dual_dot2acc_f32_f16 v32, v81, v5// 000000A09418: CB180952 25200B51
	v_sad_u8 v85, v88, 0, 0x6400                               // 000000A09420: D6220055 03FD0158 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A0942C: BF870214
	v_pk_fma_f16 v80, v80, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A09430: CC0E0050 0BFC0B50 0000C931
	v_lshl_or_b32 v83, v84, 16, v83                            // 000000A0943C: D6560053 054D2154
	v_dot2acc_f32_f16 v35, v82, v12                            // 000000A09444: 04461952
	v_sad_u8 v79, v79, 0, 0x6400                               // 000000A09448: D622004F 03FD014F 00006400
	v_and_b32_e32 v82, 0xffff, v77                             // 000000A09454: 36A49AFF 0000FFFF
	v_dot2acc_f32_f16 v32, v80, v6                             // 000000A0945C: 04400D50
	v_pk_fma_f16 v83, v83, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A09460: CC0E0053 0BFC0B53 0000C931
	v_dot2acc_f32_f16 v33, v81, v1                             // 000000A0946C: 04420351
	v_dual_dot2acc_f32_f16 v30, v81, v13 :: v_dual_lshlrev_b32 v79, 16, v79// 000000A09470: CB221B51 1E4E9E90
	v_bfe_u32 v84, v77, 8, 16                                  // 000000A09478: D6100054 0241114D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A09480: BF870193
	v_dual_dot2acc_f32_f16 v32, v83, v7 :: v_dual_dot2acc_f32_f16 v33, v80, v2// 000000A09484: CB180F53 20200550
	v_and_or_b32 v79, 0xffff, v85, v79                         // 000000A0948C: D657004F 053EAAFF 0000FFFF
	v_bfe_u32 v77, v77, 4, 16                                  // 000000A09498: D610004D 0241094D
	.long 0xd72c0052                                           // 000000A094A0: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 000000A094A4: 0202A4FF 83DCD12D
	s_waitcnt vmcnt(1)                                         // 000000A094AC: BF8907F7
	v_bfe_u32 v85, v76, 12, 16                                 // 000000A094B0: D6100055 0241194C
	.long 0xd72c0054                                           // 000000A094B8: D72C0054
	v_cndmask_b32_e32 v1, 0x83dcd12d, v84, vcc_lo              // 000000A094BC: 0202A8FF 83DCD12D
	v_dot2acc_f32_f16 v31, v81, v9                             // 000000A094C4: 043E1351
	v_bfe_u32 v86, v76, 8, 16                                  // 000000A094C8: D6100056 0241114C
	.long 0xd72c004d                                           // 000000A094D0: D72C004D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v77, vcc_lo              // 000000A094D4: 02029AFF 83DCD12D
	v_bfe_u32 v87, v76, 4, 16                                  // 000000A094DC: D6100057 0241094C
	.long 0xd72c0055                                           // 000000A094E4: D72C0055
	v_cndmask_b32_e32 v1, 0x83dcd12d, v85, vcc_lo              // 000000A094E8: 0202AAFF 83DCD12D
	v_and_b32_e32 v76, 0xffff, v76                             // 000000A094F0: 369898FF 0000FFFF
	v_pk_fma_f16 v79, v79, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A094F8: CC0E004F 0BFC0B4F 0000C931
	v_dot2acc_f32_f16 v33, v83, v3                             // 000000A09504: 04420753
	v_sad_u8 v82, v82, 0, 0x6400                               // 000000A09508: D6220052 03FD0152 00006400
	v_sad_u8 v84, v84, 0, 0x6400                               // 000000A09514: D6220054 03FD0154 00006400
	.long 0xd72c0056                                           // 000000A09520: D72C0056
	v_cndmask_b32_e32 v1, 0x83dcd12d, v86, vcc_lo              // 000000A09524: 0202ACFF 83DCD12D
	.long 0xd72c004c                                           // 000000A0952C: D72C004C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v76, vcc_lo              // 000000A09530: 020298FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A09538: BF870004
	v_dual_dot2acc_f32_f16 v33, v79, v4 :: v_dual_lshlrev_b32 v82, 16, v82// 000000A0953C: CB22094F 2152A490
	v_sad_u8 v77, v77, 0, 0x6400                               // 000000A09544: D622004D 03FD014D 00006400
	v_sad_u8 v85, v85, 0, 0x6400                               // 000000A09550: D6220055 03FD0155 00006400
	v_lshl_or_b32 v78, v84, 16, v78                            // 000000A0955C: D656004E 05392154
	.long 0xd72c0051                                           // 000000A09564: D72C0051
	v_cndmask_b32_e32 v1, 0x83dcd12d, v87, vcc_lo              // 000000A09568: 0202AEFF 83DCD12D
	v_dot2acc_f32_f16 v31, v80, v10                            // 000000A09570: 043E1550
	v_and_or_b32 v77, 0xffff, v77, v82                         // 000000A09574: D657004D 054A9AFF 0000FFFF
	v_and_b32_e32 v82, 0xffff, v85                             // 000000A09580: 36A4AAFF 0000FFFF
	v_sad_u8 v84, v86, 0, 0x6400                               // 000000A09588: D6220054 03FD0156 00006400
	v_sad_u8 v76, v76, 0, 0x6400                               // 000000A09594: D622004C 03FD014C 00006400
	v_pk_fma_f16 v78, v78, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A095A0: CC0E004E 0BFC0B4E 0000C931
	v_dual_dot2acc_f32_f16 v31, v83, v11 :: v_dual_dot2acc_f32_f16 v30, v80, v14// 000000A095AC: CB181753 1F1E1D50
	v_pk_fma_f16 v77, v77, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A095B4: CC0E004D 0BFC0B4D 0000C931
	v_lshl_or_b32 v80, v84, 16, v82                            // 000000A095C0: D6560050 05492154
	v_sad_u8 v81, v81, 0, 0x6400                               // 000000A095C8: D6220051 03FD0151 00006400
	v_dual_dot2acc_f32_f16 v29, v78, v1 :: v_dual_lshlrev_b32 v76, 16, v76// 000000A095D4: CB22034E 1D4C9890
	v_dual_dot2acc_f32_f16 v31, v79, v12 :: v_dual_dot2acc_f32_f16 v28, v78, v5// 000000A095DC: CB18194F 1F1C0B4E
	v_dot2acc_f32_f16 v27, v78, v9                             // 000000A095E4: 0436134E
	v_pk_fma_f16 v80, v80, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A095E8: CC0E0050 0BFC0B50 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000A095F4: BF870244
	v_and_or_b32 v76, 0xffff, v81, v76                         // 000000A095F8: D657004C 0532A2FF 0000FFFF
	v_dual_dot2acc_f32_f16 v29, v77, v2 :: v_dual_dot2acc_f32_f16 v30, v83, v15// 000000A09604: CB18054D 1D1E1F53
	v_dot2acc_f32_f16 v28, v77, v6                             // 000000A0960C: 04380D4D
	v_dot2acc_f32_f16 v27, v77, v10                            // 000000A09610: 0436154D
	v_pk_fma_f16 v76, v76, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A09614: CC0E004C 0BFC0B4C 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A09620: BF870214
	v_dual_dot2acc_f32_f16 v29, v80, v3 :: v_dual_dot2acc_f32_f16 v30, v79, v16// 000000A09624: CB180750 1D1E214F
	v_dot2acc_f32_f16 v28, v80, v7                             // 000000A0962C: 04380F50
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A09630: BF870194
	v_dual_dot2acc_f32_f16 v27, v80, v11 :: v_dual_dot2acc_f32_f16 v26, v78, v13// 000000A09634: CB181750 1B1A1B4E
	v_dual_dot2acc_f32_f16 v29, v76, v4 :: v_dual_and_b32 v78, 0xffff, v59// 000000A0963C: CB24094C 1D4E76FF 0000FFFF
	v_dot2acc_f32_f16 v32, v79, v8                             // 000000A09648: 0440114F
	v_bfe_u32 v79, v59, 8, 16                                  // 000000A0964C: D610004F 0241113B
	v_bfe_u32 v59, v59, 4, 16                                  // 000000A09654: D610003B 0241093B
	s_waitcnt vmcnt(0)                                         // 000000A0965C: BF8903F7
	v_bfe_u32 v81, v58, 12, 16                                 // 000000A09660: D6100051 0241193A
	.long 0xd72c004e                                           // 000000A09668: D72C004E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 000000A0966C: 02029CFF 83DCD12D
	v_bfe_u32 v82, v58, 8, 16                                  // 000000A09674: D6100052 0241113A
	.long 0xd72c004f                                           // 000000A0967C: D72C004F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v79, vcc_lo              // 000000A09680: 02029EFF 83DCD12D
	.long 0xd72c003b                                           // 000000A09688: D72C003B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 000000A0968C: 020276FF 83DCD12D
	.long 0xd72c0051                                           // 000000A09694: D72C0051
	v_cndmask_b32_e32 v1, 0x83dcd12d, v81, vcc_lo              // 000000A09698: 0202A2FF 83DCD12D
	v_dot2acc_f32_f16 v27, v76, v12                            // 000000A096A0: 0436194C
	.long 0xd72c0052                                           // 000000A096A4: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 000000A096A8: 0202A4FF 83DCD12D
	v_bfe_u32 v83, v58, 4, 16                                  // 000000A096B0: D6100053 0241093A
	v_sad_u8 v78, v78, 0, 0x6400                               // 000000A096B8: D622004E 03FD014E 00006400
	v_and_b32_e32 v58, 0xffff, v58                             // 000000A096C4: 367474FF 0000FFFF
	v_sad_u8 v79, v79, 0, 0x6400                               // 000000A096CC: D622004F 03FD014F 00006400
	v_sad_u8 v59, v59, 0, 0x6400                               // 000000A096D8: D622003B 03FD013B 00006400
	v_sad_u8 v81, v81, 0, 0x6400                               // 000000A096E4: D6220051 03FD0151 00006400
	v_lshlrev_b32_e32 v78, 16, v78                             // 000000A096F0: 309C9C90
	v_dot2acc_f32_f16 v28, v76, v8                             // 000000A096F4: 0438114C
	v_sad_u8 v82, v82, 0, 0x6400                               // 000000A096F8: D6220052 03FD0152 00006400
	.long 0xd72c003a                                           // 000000A09704: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 000000A09708: 020274FF 83DCD12D
	v_and_b32_e32 v81, 0xffff, v81                             // 000000A09710: 36A2A2FF 0000FFFF
	v_and_or_b32 v59, 0xffff, v59, v78                         // 000000A09718: D657003B 053A76FF 0000FFFF
	v_mov_b32_e32 v85, v72                                     // 000000A09724: 7EAA0348
	v_mov_b32_e32 v89, v65                                     // 000000A09728: 7EB20341
	v_mov_b32_e32 v87, v72                                     // 000000A0972C: 7EAE0348
	v_lshl_or_b32 v78, v82, 16, v81                            // 000000A09730: D656004E 05452152
	v_pk_fma_f16 v59, v59, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A09738: CC0E003B 0BFC0B3B 0000C931
	v_and_b32_e32 v60, 0xffff, v60                             // 000000A09744: 367878FF 0000FFFF
	v_sad_u8 v58, v58, 0, 0x6400                               // 000000A0974C: D622003A 03FD013A 00006400
	v_mov_b32_e32 v81, v70                                     // 000000A09758: 7EA20346
	v_pk_fma_f16 v78, v78, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0975C: CC0E004E 0BFC0B4E 0000C931
	v_mov_b32_e32 v86, v64                                     // 000000A09768: 7EAC0340
	v_lshl_or_b32 v60, v79, 16, v60                            // 000000A0976C: D656003C 04F1214F
	v_dual_mov_b32 v79, v70 :: v_dual_lshlrev_b32 v58, 16, v58 // 000000A09774: CA220146 4F3A7490
	v_mov_b32_e32 v88, v73                                     // 000000A0977C: 7EB00349
	v_mov_b32_e32 v90, v73                                     // 000000A09780: 7EB40349
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000A09784: BF870124
	v_pk_fma_f16 v60, v60, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A09788: CC0E003C 0BFC0B3C 0000C931
	v_mov_b32_e32 v84, v71                                     // 000000A09794: 7EA80347
	v_dual_mov_b32 v82, v71 :: v_dual_dot2acc_f32_f16 v23, v60, v5// 000000A09798: CA180147 52160B3C
	v_dot2acc_f32_f16 v24, v60, v1                             // 000000A097A0: 0430033C
	v_dot2acc_f32_f16 v22, v60, v9                             // 000000A097A4: 042C133C
	v_dot2acc_f32_f16 v20, v60, v13                            // 000000A097A8: 04281B3C
	v_mov_b32_e32 v60, v67                                     // 000000A097AC: 7E780343
	v_dot2acc_f32_f16 v23, v59, v6                             // 000000A097B0: 042E0D3B
	v_dot2acc_f32_f16 v26, v77, v14                            // 000000A097B4: 04341D4D
	.long 0xd72c004d                                           // 000000A097B8: D72C004D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v83, vcc_lo              // 000000A097BC: 0202A6FF 83DCD12D
	v_dot2acc_f32_f16 v24, v59, v2                             // 000000A097C4: 0430053B
	v_dot2acc_f32_f16 v22, v59, v10                            // 000000A097C8: 042C153B
	v_dual_dot2acc_f32_f16 v20, v59, v14 :: v_dual_dot2acc_f32_f16 v23, v78, v7// 000000A097CC: CB181D3B 14160F4E
	v_mov_b32_e32 v2, v66                                      // 000000A097D4: 7E040342
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 000000A097D8: BF870254
	v_dual_dot2acc_f32_f16 v24, v78, v3 :: v_dual_mov_b32 v3, v75// 000000A097DC: CB10074E 1802014B
	v_sad_u8 v77, v77, 0, 0x6400                               // 000000A097E4: D622004D 03FD014D 00006400
	v_dual_dot2acc_f32_f16 v22, v78, v11 :: v_dual_mov_b32 v83, v63// 000000A097F0: CB10174E 1652013F
	v_dot2acc_f32_f16 v20, v78, v15                            // 000000A097F8: 04281F4E
	v_mov_b32_e32 v78, v69                                     // 000000A097FC: 7E9C0345
	v_and_or_b32 v1, 0xffff, v77, v58                          // 000000A09800: D6570001 04EA9AFF 0000FFFF
	v_mov_b32_e32 v77, v61                                     // 000000A0980C: 7E9A033D
	v_dual_mov_b32 v59, v18 :: v_dual_mov_b32 v58, v67         // 000000A09810: CA100112 3B3A0143
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000A09818: BF8701B3
	v_pk_fma_f16 v1, v1, s5, 0xc931 op_sel_hi:[1,0,0]          // 000000A0981C: CC0E0001 0BFC0B01 0000C931
	v_dot2acc_f32_f16 v26, v80, v15                            // 000000A09828: 04341F50
	v_mov_b32_e32 v80, v62                                     // 000000A0982C: 7EA0033E
	v_dot2acc_f32_f16 v24, v1, v4                              // 000000A09830: 04300901
	v_dot2acc_f32_f16 v23, v1, v8                              // 000000A09834: 042E1101
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A09838: BF870004
	v_dot2acc_f32_f16 v26, v76, v16                            // 000000A0983C: 0434214C
	v_dot2acc_f32_f16 v22, v1, v12                             // 000000A09840: 042C1901
	v_dot2acc_f32_f16 v20, v1, v16                             // 000000A09844: 04282101
	v_mov_b32_e32 v4, v75                                      // 000000A09848: 7E08034B
	v_mov_b32_e32 v76, v69                                     // 000000A0984C: 7E980345
	v_mov_b32_e32 v1, v17                                      // 000000A09850: 7E020311
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000A09854: 917E047E
	s_cbranch_execz 58                                         // 000000A09858: BFA5003A <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi3EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x1c44>
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000A0985C: BF8700A1
	v_add_nc_u32_e32 v17, 1, v1                                // 000000A09860: 4A220281
	s_mov_b32 s6, exec_lo                                      // 000000A09864: BE86007E
	.long 0xd4c1007e                                           // 000000A09868: D4C1007E
	v_cndmask_b32_e32 v1, v17, v21, vcc_lo                     // 000000A0986C: 02022B11
	s_cbranch_execz 64555                                      // 000000A09870: BFA5FC2B <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi3EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0xc20>
	v_ashrrev_i32_e32 v18, 31, v17                             // 000000A09874: 3424229F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A09878: BF870091
	.long 0xd73c0005                                           // 000000A0987C: D73C0005
	v_cndmask_b32_e32 v1, 10, v17, vcc_lo                      // 000000A09880: 0202228A
	.long 0xd7006a07                                           // 000000A09884: D7006A07
	v_cndmask_b32_e32 v1, s1, v5, vcc_lo                       // 000000A09888: 02020A01
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A0988C: BF870111
	v_add_co_ci_u32_e64 v8, null, s3, v6, vcc_lo               // 000000A09890: D5207C08 01AA0C03
	.long 0xd7006a05                                           // 000000A09898: D7006A05
	v_cndmask_b32_e32 v1, v7, v57, vcc_lo                      // 000000A0989C: 02027307
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000A098A0: BF8700A1
	v_add_co_ci_u32_e64 v6, null, 0, v8, vcc_lo                // 000000A098A4: D5207C06 01AA1080
	.long 0xd7006a07                                           // 000000A098AC: D7006A07
	v_cndmask_b32_e32 v1, v7, v56, vcc_lo                      // 000000A098B0: 02027107
	v_add_co_ci_u32_e64 v8, null, 0, v8, vcc_lo                // 000000A098B4: D5207C08 01AA1080
	s_clause 0xf                                               // 000000A098BC: BF85000F
	global_load_b32 v66, v[5:6], off                           // 000000A098C0: DC520000 427C0005
	global_load_b32 v68, v[5:6], off offset:128                // 000000A098C8: DC520080 447C0005
	global_load_b32 v65, v[5:6], off offset:256                // 000000A098D0: DC520100 417C0005
	global_load_b32 v64, v[5:6], off offset:384                // 000000A098D8: DC520180 407C0005
	global_load_b32 v63, v[5:6], off offset:512                // 000000A098E0: DC520200 3F7C0005
	global_load_b32 v62, v[5:6], off offset:640                // 000000A098E8: DC520280 3E7C0005
	global_load_b32 v61, v[5:6], off offset:768                // 000000A098F0: DC520300 3D7C0005
	global_load_b32 v18, v[5:6], off offset:896                // 000000A098F8: DC520380 127C0005
	global_load_b32 v75, v[7:8], off                           // 000000A09900: DC520000 4B7C0007
	global_load_b32 v74, v[7:8], off offset:128                // 000000A09908: DC520080 4A7C0007
	global_load_b32 v73, v[7:8], off offset:256                // 000000A09910: DC520100 497C0007
	global_load_b32 v72, v[7:8], off offset:384                // 000000A09918: DC520180 487C0007
	global_load_b32 v71, v[7:8], off offset:512                // 000000A09920: DC520200 477C0007
	global_load_b32 v70, v[7:8], off offset:640                // 000000A09928: DC520280 467C0007
	global_load_b32 v69, v[7:8], off offset:768                // 000000A09930: DC520300 457C0007
	global_load_b32 v67, v[7:8], off offset:896                // 000000A09938: DC520380 437C0007
	s_branch 64503                                             // 000000A09940: BFA0FBF7 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi3EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0xc20>
	s_or_b32 exec_lo, exec_lo, s4                              // 000000A09944: 8C7E047E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000A09948: BF870009
	s_or_b32 exec_lo, exec_lo, s0                              // 000000A0994C: 8C7E007E
	s_waitcnt vmcnt(23)                                        // 000000A09950: BF895FF7
	v_dual_mov_b32 v1, v54 :: v_dual_mov_b32 v2, v43           // 000000A09954: CA100136 0102012B
	s_waitcnt vmcnt(7)                                         // 000000A0995C: BF891FF7
	v_dual_mov_b32 v3, v52 :: v_dual_mov_b32 v4, v49           // 000000A09960: CA100134 03040131
	v_dual_mov_b32 v5, v47 :: v_dual_mov_b32 v6, v25           // 000000A09968: CA10012F 05060119
	v_dual_mov_b32 v7, v53 :: v_dual_mov_b32 v8, v51           // 000000A09970: CA100135 07080133
	v_dual_mov_b32 v9, v50 :: v_dual_mov_b32 v10, v48          // 000000A09978: CA100132 090A0130
	v_dual_mov_b32 v11, v46 :: v_dual_mov_b32 v12, v45         // 000000A09980: CA10012E 0B0C012D
	v_dual_mov_b32 v13, v44 :: v_dual_mov_b32 v14, v42         // 000000A09988: CA10012C 0D0E012A
	v_dual_mov_b32 v15, v39 :: v_dual_mov_b32 v16, v38         // 000000A09990: CA100127 0F100126
	v_dual_mov_b32 v17, v37 :: v_dual_mov_b32 v18, v36         // 000000A09998: CA100125 11120124
	v_dual_mov_b32 v21, v35 :: v_dual_mov_b32 v56, v33         // 000000A099A0: CA100123 15380121
	s_waitcnt vmcnt(0)                                         // 000000A099A8: BF8903F7
	v_dual_mov_b32 v55, v34 :: v_dual_mov_b32 v58, v31         // 000000A099AC: CA100122 373A011F
	v_dual_mov_b32 v57, v32 :: v_dual_mov_b32 v60, v29         // 000000A099B4: CA100120 393C011D
	v_dual_mov_b32 v59, v30 :: v_dual_mov_b32 v62, v27         // 000000A099BC: CA10011E 3B3E011B
	v_dual_mov_b32 v61, v28 :: v_dual_mov_b32 v66, v22         // 000000A099C4: CA10011C 3D420116
	v_dual_mov_b32 v63, v26 :: v_dual_mov_b32 v64, v24         // 000000A099CC: CA10011A 3F400118
	v_mov_b32_e32 v65, v23                                     // 000000A099D4: 7E820317
	v_mov_b32_e32 v67, v20                                     // 000000A099D8: 7E860314
	s_mov_b32 s0, 0x76543210                                   // 000000A099DC: BE8000FF 76543210
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000A099E4: BF870009
	v_permlanex16_b32 v1, v1, s0, 0xfedcba98                   // 000000A099E8: D65C0001 03FC0101 FEDCBA98
	v_permlanex16_b32 v3, v3, s0, 0xfedcba98                   // 000000A099F4: D65C0003 03FC0103 FEDCBA98
	v_permlanex16_b32 v2, v2, s0, 0xfedcba98                   // 000000A09A00: D65C0002 03FC0102 FEDCBA98
	v_permlanex16_b32 v4, v4, s0, 0xfedcba98                   // 000000A09A0C: D65C0004 03FC0104 FEDCBA98
	v_permlanex16_b32 v5, v5, s0, 0xfedcba98                   // 000000A09A18: D65C0005 03FC0105 FEDCBA98
	v_permlanex16_b32 v7, v7, s0, 0xfedcba98                   // 000000A09A24: D65C0007 03FC0107 FEDCBA98
	v_permlanex16_b32 v8, v8, s0, 0xfedcba98                   // 000000A09A30: D65C0008 03FC0108 FEDCBA98
	v_permlanex16_b32 v9, v9, s0, 0xfedcba98                   // 000000A09A3C: D65C0009 03FC0109 FEDCBA98
	v_permlanex16_b32 v6, v6, s0, 0xfedcba98                   // 000000A09A48: D65C0006 03FC0106 FEDCBA98
	v_permlanex16_b32 v10, v10, s0, 0xfedcba98                 // 000000A09A54: D65C000A 03FC010A FEDCBA98
	v_permlanex16_b32 v11, v11, s0, 0xfedcba98                 // 000000A09A60: D65C000B 03FC010B FEDCBA98
	v_permlanex16_b32 v12, v12, s0, 0xfedcba98                 // 000000A09A6C: D65C000C 03FC010C FEDCBA98
	v_permlanex16_b32 v13, v13, s0, 0xfedcba98                 // 000000A09A78: D65C000D 03FC010D FEDCBA98
	v_permlanex16_b32 v14, v14, s0, 0xfedcba98                 // 000000A09A84: D65C000E 03FC010E FEDCBA98
	v_permlanex16_b32 v15, v15, s0, 0xfedcba98                 // 000000A09A90: D65C000F 03FC010F FEDCBA98
	v_permlanex16_b32 v16, v16, s0, 0xfedcba98                 // 000000A09A9C: D65C0010 03FC0110 FEDCBA98
	v_permlanex16_b32 v17, v17, s0, 0xfedcba98                 // 000000A09AA8: D65C0011 03FC0111 FEDCBA98
	v_permlanex16_b32 v18, v18, s0, 0xfedcba98                 // 000000A09AB4: D65C0012 03FC0112 FEDCBA98
	v_permlanex16_b32 v21, v21, s0, 0xfedcba98                 // 000000A09AC0: D65C0015 03FC0115 FEDCBA98
	v_permlanex16_b32 v55, v55, s0, 0xfedcba98                 // 000000A09ACC: D65C0037 03FC0137 FEDCBA98
	v_permlanex16_b32 v56, v56, s0, 0xfedcba98                 // 000000A09AD8: D65C0038 03FC0138 FEDCBA98
	v_permlanex16_b32 v57, v57, s0, 0xfedcba98                 // 000000A09AE4: D65C0039 03FC0139 FEDCBA98
	v_permlanex16_b32 v58, v58, s0, 0xfedcba98                 // 000000A09AF0: D65C003A 03FC013A FEDCBA98
	v_permlanex16_b32 v59, v59, s0, 0xfedcba98                 // 000000A09AFC: D65C003B 03FC013B FEDCBA98
	v_permlanex16_b32 v60, v60, s0, 0xfedcba98                 // 000000A09B08: D65C003C 03FC013C FEDCBA98
	v_permlanex16_b32 v61, v61, s0, 0xfedcba98                 // 000000A09B14: D65C003D 03FC013D FEDCBA98
	v_permlanex16_b32 v62, v62, s0, 0xfedcba98                 // 000000A09B20: D65C003E 03FC013E FEDCBA98
	v_permlanex16_b32 v63, v63, s0, 0xfedcba98                 // 000000A09B2C: D65C003F 03FC013F FEDCBA98
	v_permlanex16_b32 v64, v64, s0, 0xfedcba98                 // 000000A09B38: D65C0040 03FC0140 FEDCBA98
	v_permlanex16_b32 v65, v65, s0, 0xfedcba98                 // 000000A09B44: D65C0041 03FC0141 FEDCBA98
	v_permlanex16_b32 v66, v66, s0, 0xfedcba98                 // 000000A09B50: D65C0042 03FC0142 FEDCBA98
	v_permlanex16_b32 v67, v67, s0, 0xfedcba98                 // 000000A09B5C: D65C0043 03FC0143 FEDCBA98
	.long 0xd44c0000                                           // 000000A09B68: D44C0000
	v_cndmask_b32_e32 v1, 16, v41, vcc_lo                      // 000000A09B6C: 02025290
	s_barrier                                                  // 000000A09B70: BFBD0000
	buffer_gl0_inv                                             // 000000A09B74: E0AC0000 00000000
	s_and_saveexec_b32 s1, s0                                  // 000000A09B7C: BE812000
	s_cbranch_execz 73                                         // 000000A09B80: BFA50049 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi3EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x1fa8>
	v_lshl_or_b32 v19, v40, 11, v19                            // 000000A09B84: D6560013 044D1728
	v_dual_add_f32 v30, v30, v59 :: v_dual_add_f32 v21, v35, v21// 000000A09B8C: C908771E 1E142B23
	v_dual_add_f32 v10, v48, v10 :: v_dual_add_f32 v5, v47, v5 // 000000A09B94: C9081530 0A040B2F
	v_dual_add_f32 v4, v49, v4 :: v_dual_add_f32 v1, v54, v1   // 000000A09B9C: C9080931 04000336
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A09BA4: BF870004
	v_dual_add_f32 v2, v43, v2 :: v_dual_add_nc_u32 v35, 0x5400, v19// 000000A09BA8: C920052B 022226FF 00005400
	v_dual_add_f32 v18, v36, v18 :: v_dual_add_f32 v11, v46, v11// 000000A09BB4: C9082524 120A172E
	v_dual_add_f32 v14, v42, v14 :: v_dual_add_f32 v7, v53, v7 // 000000A09BBC: C9081D2A 0E060F35
	v_dual_add_f32 v8, v51, v8 :: v_dual_add_f32 v3, v52, v3   // 000000A09BC4: C9081133 08020734
	v_add_nc_u32_e32 v36, 0x5800, v19                          // 000000A09BCC: 4A4826FF 00005800
	v_dual_add_f32 v12, v45, v12 :: v_dual_add_f32 v9, v50, v9 // 000000A09BD4: C908192D 0C081332
	v_dual_add_f32 v6, v25, v6 :: v_dual_add_nc_u32 v19, 0x5c00, v19// 000000A09BDC: C9200D19 061226FF 00005C00
	v_dual_add_f32 v16, v38, v16 :: v_dual_add_f32 v13, v44, v13// 000000A09BE8: C9082126 100C1B2C
	v_dual_add_f32 v20, v20, v67 :: v_dual_add_f32 v23, v23, v65// 000000A09BF0: C9088714 14168317
	v_dual_add_f32 v22, v22, v66 :: v_dual_add_f32 v29, v29, v60// 000000A09BF8: C9088516 161C791D
	v_dual_add_f32 v24, v24, v64 :: v_dual_add_f32 v27, v27, v62// 000000A09C00: C9088118 181A7D1B
	v_dual_add_f32 v26, v26, v63 :: v_dual_add_f32 v31, v31, v58// 000000A09C08: C9087F1A 1A1E751F
	v_dual_add_f32 v28, v28, v61 :: v_dual_add_f32 v33, v33, v56// 000000A09C10: C9087B1C 1C207121
	v_dual_add_f32 v32, v32, v57 :: v_dual_add_f32 v15, v39, v15// 000000A09C18: C9087320 200E1F27
	v_dual_add_f32 v34, v34, v55 :: v_dual_add_f32 v17, v37, v17// 000000A09C20: C9086F22 22102325
	ds_store_2addr_b32 v35, v1, v5 offset0:128 offset1:144     // 000000A09C28: D8389080 00050123
	ds_store_2addr_b32 v36, v3, v7 offset1:16                  // 000000A09C30: D8381000 00070324
	ds_store_2addr_b32 v36, v2, v8 offset0:128 offset1:144     // 000000A09C38: D8389080 00080224
	ds_store_2addr_b32 v19, v4, v9 offset1:16                  // 000000A09C40: D8381000 00090413
	ds_store_2addr_b32 v35, v6, v13 offset0:160 offset1:176    // 000000A09C48: D838B0A0 000D0623
	ds_store_2addr_b32 v36, v10, v14 offset0:32 offset1:48     // 000000A09C50: D8383020 000E0A24
	ds_store_2addr_b32 v36, v11, v15 offset0:160 offset1:176   // 000000A09C58: D838B0A0 000F0B24
	ds_store_2addr_b32 v19, v12, v16 offset0:32 offset1:48     // 000000A09C60: D8383020 00100C13
	ds_store_2addr_b32 v35, v17, v33 offset0:192 offset1:208   // 000000A09C68: D838D0C0 00211123
	ds_store_2addr_b32 v36, v18, v32 offset0:64 offset1:80     // 000000A09C70: D8385040 00201224
	ds_store_2addr_b32 v36, v21, v31 offset0:192 offset1:208   // 000000A09C78: D838D0C0 001F1524
	ds_store_2addr_b32 v19, v34, v30 offset0:64 offset1:80     // 000000A09C80: D8385040 001E2213
	ds_store_2addr_b32 v35, v29, v24 offset0:224 offset1:240   // 000000A09C88: D838F0E0 00181D23
	ds_store_2addr_b32 v36, v28, v23 offset0:96 offset1:112    // 000000A09C90: D8387060 00171C24
	ds_store_2addr_b32 v36, v27, v22 offset0:224 offset1:240   // 000000A09C98: D838F0E0 00161B24
	ds_store_2addr_b32 v19, v26, v20 offset0:96 offset1:112    // 000000A09CA0: D8387060 00141A13
	s_or_b32 exec_lo, exec_lo, s1                              // 000000A09CA8: 8C7E017E
	.long 0xd44c0001                                           // 000000A09CAC: D44C0001
	v_cndmask_b32_e32 v1, 0x200, v0, vcc_lo                    // 000000A09CB0: 020200FF 00000200
	s_waitcnt lgkmcnt(0)                                       // 000000A09CB8: BF89FC07
	s_barrier                                                  // 000000A09CBC: BFBD0000
	buffer_gl0_inv                                             // 000000A09CC0: E0AC0000 00000000
	s_and_saveexec_b32 s3, s1                                  // 000000A09CC8: BE832001
	s_cbranch_execz 47                                         // 000000A09CCC: BFA5002F <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi3EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x208c>
	v_mov_b32_e32 v1, v0                                       // 000000A09CD0: 7E020300
	s_mov_b32 s4, 0                                            // 000000A09CD4: BE840080
	s_nop 0                                                    // 000000A09CD8: BF800000
	s_nop 0                                                    // 000000A09CDC: BF800000
	s_nop 0                                                    // 000000A09CE0: BF800000
	s_nop 0                                                    // 000000A09CE4: BF800000
	s_nop 0                                                    // 000000A09CE8: BF800000
	s_nop 0                                                    // 000000A09CEC: BF800000
	s_nop 0                                                    // 000000A09CF0: BF800000
	s_nop 0                                                    // 000000A09CF4: BF800000
	s_nop 0                                                    // 000000A09CF8: BF800000
	s_nop 0                                                    // 000000A09CFC: BF800000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000A09D00: BF870001
	v_lshlrev_b32_e32 v8, 2, v1                                // 000000A09D04: 30100282
	v_cmp_lt_u32_e32 vcc_lo, 0xff, v1                          // 000000A09D08: 7C9202FF 000000FF
	ds_load_2addr_stride64_b32 v[2:3], v8 offset0:86 offset1:94// 000000A09D10: D8E05E56 02000008
	ds_load_2addr_stride64_b32 v[4:5], v8 offset0:102 offset1:110// 000000A09D18: D8E06E66 04000008
	ds_load_2addr_stride64_b32 v[6:7], v8 offset0:118 offset1:126// 000000A09D20: D8E07E76 06000008
	s_or_b32 s4, vcc_lo, s4                                    // 000000A09D28: 8C04046A
	s_waitcnt lgkmcnt(2)                                       // 000000A09D2C: BF89FC27
	v_add_f32_e32 v2, 0, v2                                    // 000000A09D30: 06040480
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000A09D34: BF8700C1
	v_add_f32_e32 v9, v2, v3                                   // 000000A09D38: 06120702
	ds_load_2addr_stride64_b32 v[2:3], v8 offset0:134 offset1:142// 000000A09D3C: D8E08E86 02000008
	s_waitcnt lgkmcnt(2)                                       // 000000A09D44: BF89FC27
	v_add_f32_e32 v4, v9, v4                                   // 000000A09D48: 06080909
	v_add_f32_e32 v4, v4, v5                                   // 000000A09D4C: 06080B04
	s_waitcnt lgkmcnt(1)                                       // 000000A09D50: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A09D54: BF870091
	v_add_f32_e32 v4, v4, v6                                   // 000000A09D58: 06080D04
	v_add_f32_e32 v4, v4, v7                                   // 000000A09D5C: 06080F04
	s_waitcnt lgkmcnt(0)                                       // 000000A09D60: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000A09D64: BF8700A1
	v_add_f32_e32 v2, v4, v2                                   // 000000A09D68: 06040504
	v_add_nc_u32_e32 v4, 0x100, v1                             // 000000A09D6C: 4A0802FF 00000100
	v_dual_add_f32 v2, v2, v3 :: v_dual_mov_b32 v1, v4         // 000000A09D74: C9100702 02000104
	ds_store_b32 v8, v2 offset:38400                           // 000000A09D7C: D8349600 00000208
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000A09D84: 917E047E
	s_cbranch_execnz 65501                                     // 000000A09D88: BFA6FFDD <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi3EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x2000>
	s_or_b32 exec_lo, exec_lo, s3                              // 000000A09D8C: 8C7E037E
	s_cmp_lt_i32 s9, 2                                         // 000000A09D90: BF048209
	s_mov_b32 s3, -1                                           // 000000A09D94: BE8300C1
	s_cbranch_scc1 212                                         // 000000A09D98: BFA200D4 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi3EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x23ec>
	s_waitcnt lgkmcnt(0)                                       // 000000A09D9C: BF89FC07
	s_barrier                                                  // 000000A09DA0: BFBD0000
	buffer_gl0_inv                                             // 000000A09DA4: E0AC0000 00000000
	s_and_saveexec_b32 s3, s1                                  // 000000A09DAC: BE832001
	s_cbranch_execz 71                                         // 000000A09DB0: BFA50047 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi3EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x21d0>
	v_lshrrev_b32_e32 v1, 7, v0                                // 000000A09DB4: 32020087
	s_ashr_i32 s29, s28, 31                                    // 000000A09DB8: 861D9F1C
	s_ashr_i32 s31, s30, 31                                    // 000000A09DBC: 861F9F1E
	s_lshl_b64 s[4:5], s[28:29], 2                             // 000000A09DC0: 8484821C
	s_lshl_b32 s6, s10, 7                                      // 000000A09DC4: 8406870A
	v_or_b32_e32 v1, s4, v1                                    // 000000A09DC8: 38020204
	v_mov_b32_e32 v2, s5                                       // 000000A09DCC: 7E040205
	s_lshl_b64 s[4:5], s[30:31], 2                             // 000000A09DD0: 8484821E
	s_ashr_i32 s7, s6, 31                                      // 000000A09DD4: 86079F06
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000A09DD8: BF8700A9
	s_lshl_b64 s[6:7], s[6:7], 2                               // 000000A09DDC: 84868206
	.long 0xd7016a01                                           // 000000A09DE0: D7016A01
	v_cndmask_b32_e32 v0, v1, v4, vcc_lo                       // 000000A09DE4: 02000901
	v_subrev_co_ci_u32_e64 v2, null, s5, v2, vcc_lo            // 000000A09DE8: D5227C02 01AA0405
	s_ashr_i32 s5, s49, 31                                     // 000000A09DF0: 86059F31
	s_mov_b32 s4, s49                                          // 000000A09DF4: BE840031
	.long 0xd72c0004                                           // 000000A09DF8: D72C0004
	v_cndmask_b32_e32 v0, v1, v5, vcc_lo                       // 000000A09DFC: 02000B01
	.long 0xd72c0003                                           // 000000A09E00: D72C0003
	v_cndmask_b32_e32 v0, v2, v49, vcc_lo                      // 000000A09E04: 02006302
	v_mad_u64_u32 v[1:2], null, v1, s49, 0                     // 000000A09E08: D6FE7C01 02006301
	s_lshl_b64 s[4:5], s[4:5], 3                               // 000000A09E10: 84848304
	v_add3_u32 v2, v2, v4, v3                                  // 000000A09E14: D6550002 040E0902
	v_and_b32_e32 v3, 0x7f, v0                                 // 000000A09E1C: 360600FF 0000007F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A09E24: BF870112
	.long 0xd73c0001                                           // 000000A09E28: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 000000A09E2C: 02020282
	v_lshlrev_b32_e32 v4, 2, v3                                // 000000A09E30: 30080682
	v_lshlrev_b32_e32 v3, 2, v0                                // 000000A09E34: 30060082
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A09E38: BF870093
	.long 0xd7006a01                                           // 000000A09E3C: D7006A01
	v_cndmask_b32_e32 v0, v1, v6, vcc_lo                       // 000000A09E40: 02000D01
	v_add_co_ci_u32_e64 v2, null, s7, v2, vcc_lo               // 000000A09E44: D5207C02 01AA0407
	s_mov_b32 s6, 0                                            // 000000A09E4C: BE860080
	.long 0xd7006a01                                           // 000000A09E50: D7006A01
	v_cndmask_b32_e32 v1, v1, v4, vcc_lo                       // 000000A09E54: 02020901
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000A09E58: BF8701A1
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 000000A09E5C: D5207C02 01AA0480
	v_or_b32_e32 v4, 0xffffff00, v0                            // 000000A09E64: 380800FF FFFFFF00
	.long 0xd7006a01                                           // 000000A09E6C: D7006A01
	v_cndmask_b32_e32 v1, s44, v1, vcc_lo                      // 000000A09E70: 0202022C
	s_delay_alu instid0(VALU_DEP_1)                            // 000000A09E74: BF870001
	v_add_co_ci_u32_e64 v2, null, s45, v2, vcc_lo              // 000000A09E78: D5207C02 01AA042D
	ds_load_b32 v5, v3 offset:38400                            // 000000A09E80: D8D89600 05000003
	.long 0xd7000704                                           // 000000A09E88: D7000704
	v_cndmask_b32_e32 v1, 0x100, v4, vcc_lo                    // 000000A09E8C: 020208FF 00000100
	s_xor_b32 s7, s7, -1                                       // 000000A09E94: 8D07C107
	v_add_nc_u32_e32 v3, 0x400, v3                             // 000000A09E98: 4A0606FF 00000400
	s_and_b32 s7, exec_lo, s7                                  // 000000A09EA0: 8B07077E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000A09EA4: BF8700C9
	s_or_b32 s6, s7, s6                                        // 000000A09EA8: 8C060607
	s_waitcnt lgkmcnt(0)                                       // 000000A09EAC: BF89FC07
	global_store_b32 v[1:2], v5, off                           // 000000A09EB0: DC6A0000 007C0501
	.long 0xd7006a01                                           // 000000A09EB8: D7006A01
	v_cndmask_b32_e32 v0, v1, v4, vcc_lo                       // 000000A09EBC: 02000901
	v_add_co_ci_u32_e64 v2, null, s5, v2, vcc_lo               // 000000A09EC0: D5207C02 01AA0405
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 000000A09EC8: 917E067E
	s_cbranch_execnz 65516                                     // 000000A09ECC: BFA6FFEC <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi3EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x2180>
	s_or_b32 exec_lo, exec_lo, s3                              // 000000A09ED0: 8C7E037E
	.long 0xd44a0003                                           // 000000A09ED4: D44A0003
	v_cndmask_b32_e32 v1, 0, v0, vcc_lo                        // 000000A09ED8: 02020080
	s_waitcnt_vscnt null, 0x0                                  // 000000A09EDC: BC7C0000
	buffer_gl1_inv                                             // 000000A09EE0: E0B00000 00000000
	buffer_gl0_inv                                             // 000000A09EE8: E0AC0000 00000000
	s_barrier                                                  // 000000A09EF0: BFBD0000
	buffer_gl0_inv                                             // 000000A09EF4: E0AC0000 00000000
	s_and_saveexec_b32 s4, s3                                  // 000000A09EFC: BE842003
	s_cbranch_execz 29                                         // 000000A09F00: BFA5001D <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi3EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x2278>
	s_mov_b32 s6, exec_lo                                      // 000000A09F04: BE86007E
	s_mov_b32 s5, exec_lo                                      // 000000A09F08: BE85007E
	.long 0xd71f0001                                           // 000000A09F0C: D71F0001
	v_cndmask_b32_e32 v0, s6, v128, vcc_lo                     // 000000A09F10: 02010006
	s_delay_alu instid0(VALU_DEP_1)                            // 000000A09F14: BF870001
	v_cmpx_eq_u32_e32 0, v1                                    // 000000A09F18: 7D940280
	s_cbranch_execz 9                                          // 000000A09F1C: BFA50009 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi3EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x2244>
	s_lshl_b64 s[24:25], s[10:11], 2                           // 000000A09F20: 8498820A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 000000A09F24: BF8704B9
	s_add_u32 s24, s46, s24                                    // 000000A09F28: 8018182E
	s_addc_u32 s25, s47, s25                                   // 000000A09F2C: 8219192F
	s_bcnt1_i32_b32 s6, s6                                     // 000000A09F30: BE861806
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v3, s6              // 000000A09F34: CA100080 02020006
	global_atomic_add_u32 v2, v2, v3, s[24:25] glc             // 000000A09F3C: DCD64000 02180302
	s_or_b32 exec_lo, exec_lo, s5                              // 000000A09F44: 8C7E057E
	s_waitcnt vmcnt(0)                                         // 000000A09F48: BF8903F7
	v_readfirstlane_b32 s5, v2                                 // 000000A09F4C: 7E0A0502
	s_delay_alu instid0(VALU_DEP_1)                            // 000000A09F50: BF870001
	v_dual_mov_b32 v2, 0 :: v_dual_add_nc_u32 v1, s5, v1       // 000000A09F54: CA200080 02000205
	s_add_i32 s5, s9, -1                                       // 000000A09F5C: 8105C109
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 000000A09F60: BF870481
	v_cmp_eq_u32_e32 vcc_lo, s5, v1                            // 000000A09F64: 7C940205
	v_cndmask_b32_e64 v1, 0, 1, vcc_lo                         // 000000A09F68: D5010001 01A90280
	ds_store_b32 v2, v1 offset:42496                           // 000000A09F70: D834A600 00000102
	s_or_b32 exec_lo, exec_lo, s4                              // 000000A09F78: 8C7E047E
	v_mov_b32_e32 v1, 0                                        // 000000A09F7C: 7E020280
	s_waitcnt lgkmcnt(0)                                       // 000000A09F80: BF89FC07
	s_barrier                                                  // 000000A09F84: BFBD0000
	buffer_gl0_inv                                             // 000000A09F88: E0AC0000 00000000
	ds_load_b32 v1, v1 offset:42496                            // 000000A09F90: D8D8A600 01000001
	s_waitcnt lgkmcnt(0)                                       // 000000A09F98: BF89FC07
	v_cmp_eq_u32_e32 vcc_lo, 0, v1                             // 000000A09F9C: 7C940280
	s_cbranch_vccnz 5809                                       // 000000A09FA0: BFA416B1 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi3EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x7d68>
	buffer_gl1_inv                                             // 000000A09FA4: E0B00000 00000000
	buffer_gl0_inv                                             // 000000A09FAC: E0AC0000 00000000
	s_and_saveexec_b32 s8, s1                                  // 000000A09FB4: BE882001
	s_cbranch_execz 65                                         // 000000A09FB8: BFA50041 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi3EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x23c0>
	v_lshrrev_b32_e32 v1, 7, v0                                // 000000A09FBC: 32020087
	s_lshl_b32 s4, s10, 7                                      // 000000A09FC0: 8404870A
	v_and_b32_e32 v3, 0x7f, v0                                 // 000000A09FC4: 360600FF 0000007F
	s_ashr_i32 s5, s4, 31                                      // 000000A09FCC: 86059F04
	v_mov_b32_e32 v5, v0                                       // 000000A09FD0: 7E0A0300
	v_mad_i64_i32 v[1:2], null, v1, s49, 0                     // 000000A09FD4: D6FF7C01 02006301
	s_lshl_b64 s[4:5], s[4:5], 2                               // 000000A09FDC: 84848204
	v_lshlrev_b32_e32 v3, 2, v3                                // 000000A09FE0: 30060682
	s_ashr_i32 s7, s49, 31                                     // 000000A09FE4: 86079F31
	s_mov_b32 s6, s49                                          // 000000A09FE8: BE860031
	s_mov_b32 s24, 0                                           // 000000A09FEC: BE980080
	.long 0xd73c0001                                           // 000000A09FF0: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 000000A09FF4: 02020282
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A09FF8: BF870091
	.long 0xd7006a01                                           // 000000A09FFC: D7006A01
	v_cndmask_b32_e32 v0, v1, v4, vcc_lo                       // 000000A0A000: 02000901
	v_add_co_ci_u32_e64 v2, null, s5, v2, vcc_lo               // 000000A0A004: D5207C02 01AA0405
	s_lshl_b64 s[4:5], s[6:7], 3                               // 000000A0A00C: 84848306
	.long 0xd7006a01                                           // 000000A0A010: D7006A01
	v_cndmask_b32_e32 v1, v1, v3, vcc_lo                       // 000000A0A014: 02020701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000A0A018: BF8700B1
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 000000A0A01C: D5207C02 01AA0480
	s_lshl_b64 s[6:7], s[6:7], 4                               // 000000A0A024: 84868406
	.long 0xd7006a01                                           // 000000A0A028: D7006A01
	v_cndmask_b32_e32 v1, s44, v1, vcc_lo                      // 000000A0A02C: 0202022C
	v_add_co_ci_u32_e64 v2, null, s45, v2, vcc_lo              // 000000A0A030: D5207C02 01AA042D
	s_nop 0                                                    // 000000A0A038: BF800000
	s_nop 0                                                    // 000000A0A03C: BF800000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000A0A040: BF870001
	v_dual_mov_b32 v4, v2 :: v_dual_mov_b32 v3, v1             // 000000A0A044: CA100102 04020101
	v_mov_b32_e32 v6, 0                                        // 000000A0A04C: 7E0C0280
	s_mov_b32 s1, s9                                           // 000000A0A050: BE810009
	global_load_b32 v7, v[3:4], off glc                        // 000000A0A054: DC524000 077C0003
	.long 0xd7006a03                                           // 000000A0A05C: D7006A03
	v_cndmask_b32_e32 v0, v3, v6, vcc_lo                       // 000000A0A060: 02000D03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000A0A064: BF8704A1
	v_add_co_ci_u32_e64 v4, null, s7, v4, vcc_lo               // 000000A0A068: D5207C04 01AA0807
	s_add_i32 s1, s1, -1                                       // 000000A0A070: 8101C101
	s_cmp_eq_u32 s1, 0                                         // 000000A0A074: BF068001
	s_waitcnt vmcnt(0)                                         // 000000A0A078: BF8903F7
	v_add_f32_e32 v6, v6, v7                                   // 000000A0A07C: 060C0F06
	s_cbranch_scc0 65524                                       // 000000A0A080: BFA1FFF4 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi3EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x2354>
	v_add_nc_u32_e32 v4, 0x100, v5                             // 000000A0A084: 4A080AFF 00000100
	v_cmp_lt_u32_e32 vcc_lo, 0xff, v5                          // 000000A0A08C: 7C920AFF 000000FF
	.long 0xd7000101                                           // 000000A0A094: D7000101
	v_cndmask_b32_e32 v0, v1, v4, vcc_lo                       // 000000A0A098: 02000901
	v_lshlrev_b32_e32 v3, 2, v5                                // 000000A0A09C: 30060A82
	v_add_co_ci_u32_e64 v2, null, s5, v2, s1                   // 000000A0A0A0: D5207C02 00060405
	v_mov_b32_e32 v5, v4                                       // 000000A0A0A8: 7E0A0304
	s_or_b32 s24, vcc_lo, s24                                  // 000000A0A0AC: 8C18186A
	ds_store_b32 v3, v6 offset:38400                           // 000000A0A0B0: D8349600 00000603
	s_and_not1_b32 exec_lo, exec_lo, s24                       // 000000A0A0B8: 917E187E
	s_cbranch_execnz 65504                                     // 000000A0A0BC: BFA6FFE0 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi3EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x2340>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000A0A0C0: 8C7E087E
	s_and_saveexec_b32 s1, s3                                  // 000000A0A0C4: BE812003
	s_cbranch_execz 6                                          // 000000A0A0C8: BFA50006 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi3EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x23e4>
	s_lshl_b64 s[4:5], s[10:11], 2                             // 000000A0A0CC: 8484820A
	v_mov_b32_e32 v1, 0                                        // 000000A0A0D0: 7E020280
	s_add_u32 s4, s46, s4                                      // 000000A0A0D4: 8004042E
	s_addc_u32 s5, s47, s5                                     // 000000A0A0D8: 8205052F
	global_store_b32 v1, v1, s[4:5]                            // 000000A0A0DC: DC6A0000 00040101
	s_or_b32 exec_lo, exec_lo, s1                              // 000000A0A0E4: 8C7E017E
	s_mov_b32 s3, -1                                           // 000000A0A0E8: BE8300C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000A0A0EC: BF870009
	s_and_b32 vcc_lo, exec_lo, s3                              // 000000A0A0F0: 8B6A037E
	s_cbranch_vccz 382                                         // 000000A0A0F4: BFA3017E <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi3EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x29f0>
	v_cmp_gt_i32_e32 vcc_lo, s48, v40                          // 000000A0A0F8: 7C885030
	.long 0xd44c0001                                           // 000000A0A0FC: D44C0001
	v_cndmask_b32_e32 v1, 0x80, v0, vcc_lo                     // 000000A0A100: 020200FF 00000080
	s_waitcnt lgkmcnt(0)                                       // 000000A0A108: BF89FC07
	s_waitcnt_vscnt null, 0x0                                  // 000000A0A10C: BC7C0000
	s_barrier                                                  // 000000A0A110: BFBD0000
	buffer_gl0_inv                                             // 000000A0A114: E0AC0000 00000000
	s_and_b32 s1, vcc_lo, s1                                   // 000000A0A11C: 8B01016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000A0A120: BF870009
	s_and_saveexec_b32 s3, s1                                  // 000000A0A124: BE832001
	s_cbranch_execz 368                                        // 000000A0A128: BFA50170 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi3EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x29ec>
	v_and_b32_e32 v1, 15, v0                                   // 000000A0A12C: 3602008F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A0A130: BF870091
	v_lshlrev_b32_e32 v2, 2, v1                                // 000000A0A134: 30040282
	v_lshl_or_b32 v2, v40, 9, v2                               // 000000A0A138: D6560002 04091328
	s_delay_alu instid0(VALU_DEP_1)                            // 000000A0A140: BF870001
	v_add_nc_u32_e32 v8, 0x9400, v2                            // 000000A0A144: 4A1004FF 00009400
	ds_load_2addr_b32 v[2:3], v8 offset0:128 offset1:144       // 000000A0A14C: D8DC9080 02000008
	ds_load_2addr_b32 v[4:5], v8 offset0:160 offset1:176       // 000000A0A154: D8DCB0A0 04000008
	ds_load_2addr_b32 v[6:7], v8 offset0:192 offset1:208       // 000000A0A15C: D8DCD0C0 06000008
	ds_load_2addr_b32 v[8:9], v8 offset0:224 offset1:240       // 000000A0A164: D8DCF0E0 08000008
	v_and_b32_e32 v10, 1, v0                                   // 000000A0A16C: 36140081
	v_and_b32_e32 v11, 2, v0                                   // 000000A0A170: 36160082
	s_waitcnt lgkmcnt(3)                                       // 000000A0A174: BF89FC37
	v_dual_add_f32 v13, v2, v3 :: v_dual_and_b32 v12, 4, v0    // 000000A0A178: C9240702 0D0C0084
	s_waitcnt lgkmcnt(2)                                       // 000000A0A180: BF89FC27
	v_dual_sub_f32 v2, v2, v3 :: v_dual_add_f32 v3, v4, v5     // 000000A0A184: C9480702 02020B04
	s_waitcnt lgkmcnt(1)                                       // 000000A0A18C: BF89FC17
	v_dual_sub_f32 v4, v4, v5 :: v_dual_add_f32 v5, v6, v7     // 000000A0A190: C9480B04 04040F06
	s_waitcnt lgkmcnt(0)                                       // 000000A0A198: BF89FC07
	v_dual_sub_f32 v6, v6, v7 :: v_dual_add_f32 v7, v8, v9     // 000000A0A19C: C9480F06 06061308
	v_dual_sub_f32 v8, v8, v9 :: v_dual_add_f32 v9, v13, v3    // 000000A0A1A4: C9481308 0808070D
	v_sub_f32_e32 v3, v13, v3                                  // 000000A0A1AC: 0806070D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000A0A1B0: BF870243
	v_dual_add_f32 v13, v2, v4 :: v_dual_add_f32 v14, v5, v7   // 000000A0A1B4: C9080902 0D0E0F05
	v_dual_sub_f32 v2, v2, v4 :: v_dual_sub_f32 v5, v5, v7     // 000000A0A1BC: C94A0902 02040F05
	v_cmp_eq_u32_e32 vcc_lo, 0, v10                            // 000000A0A1C4: 7C941480
	.long 0xd44a0001                                           // 000000A0A1C8: D44A0001
	v_cndmask_b32_e32 v1, 0, v12, vcc_lo                       // 000000A0A1CC: 02021880
	v_dual_add_f32 v7, v9, v14 :: v_dual_add_f32 v4, v6, v8    // 000000A0A1D0: C9081D09 07041106
	v_sub_f32_e32 v6, v6, v8                                   // 000000A0A1D8: 080C1106
	v_sub_f32_e32 v8, v9, v14                                  // 000000A0A1DC: 08101D09
	s_delay_alu instid0(VALU_DEP_3)                            // 000000A0A1E0: BF870003
	v_add_f32_e32 v9, v13, v4                                  // 000000A0A1E4: 0612090D
	v_dual_sub_f32 v4, v13, v4 :: v_dual_add_f32 v13, v3, v5   // 000000A0A1E8: C948090D 040C0B03
	v_sub_f32_e32 v3, v3, v5                                   // 000000A0A1F0: 08060B03
	v_add_f32_e32 v5, v2, v6                                   // 000000A0A1F4: 060A0D02
	v_sub_f32_e32 v2, v2, v6                                   // 000000A0A1F8: 08040D02
	v_mov_b32_dpp v6, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A0A1FC: 7E0C02FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, vcc_lo                      // 000000A0A204: D5010007 21AA0F07
	v_mov_b32_dpp v10, v9 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A0A20C: 7E1402FA FF016109
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 000000A0A214: D5010009 21AA1309
	v_mov_b32_dpp v14, v13 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A0A21C: 7E1C02FA FF01610D
	v_cndmask_b32_e64 v13, -v13, v13, vcc_lo                   // 000000A0A224: D501000D 21AA1B0D
	v_mov_b32_dpp v15, v5 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A0A22C: 7E1E02FA FF016105
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 000000A0A234: D5010005 21AA0B05
	v_mov_b32_dpp v16, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A0A23C: 7E2002FA FF016108
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 000000A0A244: D5010008 21AA1108
	v_mov_b32_dpp v17, v4 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A0A24C: 7E2202FA FF016104
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 000000A0A254: D5010004 21AA0904
	v_mov_b32_dpp v18, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A0A25C: 7E2402FA FF016103
	v_cndmask_b32_e64 v19, -v3, v3, vcc_lo                     // 000000A0A264: D5010013 21AA0703
	v_cndmask_b32_e64 v21, -v2, v2, vcc_lo                     // 000000A0A26C: D5010015 21AA0502
	v_cmp_eq_u32_e32 vcc_lo, 0, v11                            // 000000A0A274: 7C941680
	v_dual_add_f32 v3, v7, v6 :: v_dual_add_f32 v8, v8, v16    // 000000A0A278: C9080D07 03082108
	v_mov_b32_dpp v20, v2 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A0A280: 7E2802FA FF016102
	v_dual_add_f32 v2, v9, v10 :: v_dual_add_f32 v9, v4, v17   // 000000A0A288: C9081509 02082304
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000A0A290: BF870233
	v_mov_b32_dpp v4, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A0A294: 7E0802FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 000000A0A29C: D5010003 21AA0703
	v_add_f32_e32 v6, v13, v14                                 // 000000A0A2A4: 060C1D0D
	v_mov_b32_dpp v7, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A0A2A8: 7E0E02FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, vcc_lo                      // 000000A0A2B0: D5010002 21AA0502
	v_mov_b32_dpp v12, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A0A2B8: 7E1802FA FF016208
	v_add_f32_e32 v3, v3, v4                                   // 000000A0A2C0: 06060903
	v_mov_b32_dpp v10, v6 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A0A2C4: 7E1402FA FF016206
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 000000A0A2CC: D5010006 21AA0D06
	v_add_f32_e32 v5, v5, v15                                  // 000000A0A2D4: 060A1F05
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 000000A0A2D8: D5010008 21AA1108
	v_add_f32_e32 v13, v21, v20                                // 000000A0A2E0: 061A2915
	v_mov_b32_dpp v14, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A0A2E4: 7E1C02FA FF016209
	v_add_f32_e32 v6, v6, v10                                  // 000000A0A2EC: 060C1506
	v_mov_b32_dpp v11, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A0A2F0: 7E1602FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 000000A0A2F8: D5010005 21AA0B05
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 000000A0A300: D5010009 21AA1309
	v_add_f32_e32 v8, v8, v12                                  // 000000A0A308: 06101908
	v_mov_b32_dpp v15, v13 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A0A30C: 7E1E02FA FF01620D
	v_cndmask_b32_e64 v13, -v13, v13, vcc_lo                   // 000000A0A314: D501000D 21AA1B0D
	v_add_f32_e32 v4, v5, v11                                  // 000000A0A31C: 06081705
	v_mov_b32_dpp v5, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A0A320: 7E0A02FA FF016403
	v_cndmask_b32_e64 v3, -v3, v3, s1                          // 000000A0A328: D5010003 20060703
	v_add_f32_e32 v2, v2, v7                                   // 000000A0A330: 06040F02
	v_mov_b32_dpp v11, v6 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A0A334: 7E1602FA FF016406
	v_cndmask_b32_e64 v6, -v6, v6, s1                          // 000000A0A33C: D5010006 20060D06
	v_add_f32_e32 v9, v9, v14                                  // 000000A0A344: 06121D09
	v_add_f32_e32 v3, v3, v5                                   // 000000A0A348: 06060B03
	v_cndmask_b32_e64 v7, -v2, v2, s1                          // 000000A0A34C: D5010007 20060502
	v_mov_b32_dpp v2, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A0A354: 7E0402FA FF016402
	v_add_f32_e32 v6, v6, v11                                  // 000000A0A35C: 060C1706
	v_mov_b32_dpp v11, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A0A360: 7E1602FA FF016408
	v_cndmask_b32_e64 v14, -v8, v8, s1                         // 000000A0A368: D501000E 20061108
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000A0A370: BF870234
	v_add_f32_e32 v7, v7, v2                                   // 000000A0A374: 060E0507
	v_mov_b32_dpp v10, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A0A378: 7E1402FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s1                          // 000000A0A380: D5010004 20060904
	v_add_f32_e32 v14, v14, v11                                // 000000A0A388: 061C170E
	v_mov_b32_dpp v2, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A0A38C: 7E0402FA FF016803
	v_mov_b32_dpp v5, v7 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A0A394: 7E0A02FA FF016807
	v_mov_b32_dpp v8, v6 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A0A39C: 7E1002FA FF016806
	v_add_f32_e32 v4, v4, v10                                  // 000000A0A3A4: 06081504
	v_add_f32_e32 v10, v19, v18                                // 000000A0A3A8: 06142513
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000A0A3AC: BF8700A1
	v_mov_b32_dpp v12, v10 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A0A3B0: 7E1802FA FF01620A
	v_cndmask_b32_e64 v10, -v10, v10, vcc_lo                   // 000000A0A3B8: D501000A 21AA150A
	v_add_f32_e32 v10, v10, v12                                // 000000A0A3C0: 0614190A
	v_add_f32_e32 v12, v13, v15                                // 000000A0A3C4: 06181F0D
	v_mov_b32_dpp v13, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A0A3C8: 7E1A02FA FF016409
	v_cndmask_b32_e64 v9, -v9, v9, s1                          // 000000A0A3D0: D5010009 20061309
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A0A3D8: BF870214
	v_mov_b32_dpp v15, v10 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A0A3DC: 7E1E02FA FF01640A
	v_mov_b32_dpp v17, v12 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A0A3E4: 7E2202FA FF01640C
	v_cndmask_b32_e64 v10, -v10, v10, s1                       // 000000A0A3EC: D501000A 2006150A
	v_cndmask_b32_e64 v12, -v12, v12, s1                       // 000000A0A3F4: D501000C 2006190C
	v_add_f32_e32 v16, v9, v13                                 // 000000A0A3FC: 06201B09
	v_mov_b32_dpp v9, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A0A400: 7E1202FA FF016804
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A0A408: BF870214
	v_add_f32_e32 v15, v10, v15                                // 000000A0A40C: 061E1F0A
	v_add_f32_e32 v17, v12, v17                                // 000000A0A410: 0622230C
	v_mov_b32_dpp v10, v14 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A0A414: 7E1402FA FF01680E
	v_mov_b32_dpp v11, v16 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A0A41C: 7E1602FA FF016810
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A0A424: BF870214
	v_mov_b32_dpp v12, v15 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A0A428: 7E1802FA FF01680F
	v_mov_b32_dpp v13, v17 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A0A430: 7E1A02FA FF016811
	s_and_b32 exec_lo, exec_lo, s0                             // 000000A0A438: 8B7E007E
	s_cbranch_execz 171                                        // 000000A0A43C: BFA500AB <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi3EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x29ec>
	v_lshl_or_b32 v18, s10, 7, v1                              // 000000A0A440: D6560012 04050E0A
	v_and_b32_e32 v1, 8, v0                                    // 000000A0A448: 36020088
	.long 0x7f2c3880                                           // 000000A0A44C: 7F2C3880
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A0A450: BF870113
	v_ashrrev_i32_e32 v19, 31, v18                             // 000000A0A454: 3426249F
	.long 0x7f323996                                           // 000000A0A458: 7F323996
	.long 0x7f2e3996                                           // 000000A0A45C: 7F2E3996
	.long 0x7f303996                                           // 000000A0A460: 7F303996
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A0A464: BF870094
	.long 0xd73c0012                                           // 000000A0A468: D73C0012
	v_cndmask_b32_e32 v1, 1, v18, vcc_lo                       // 000000A0A46C: 02022481
	.long 0xd7006a14                                           // 000000A0A470: D7006A14
	v_cndmask_b32_e32 v1, s36, v18, vcc_lo                     // 000000A0A474: 02022424
	s_delay_alu instid0(VALU_DEP_1)                            // 000000A0A478: BF870001
	v_add_co_ci_u32_e64 v21, null, s37, v19, vcc_lo            // 000000A0A47C: D5207C15 01AA2625
	v_cmp_eq_u32_e32 vcc_lo, 0, v1                             // 000000A0A484: 7C940280
	s_clause 0x7                                               // 000000A0A488: BF850007
	global_load_d16_b16 v22, v[20:21], off offset:32           // 000000A0A48C: DC820020 167C0014
	global_load_d16_b16 v23, v[20:21], off                     // 000000A0A494: DC820000 177C0014
	global_load_d16_b16 v24, v[20:21], off offset:64           // 000000A0A49C: DC820040 187C0014
	global_load_d16_b16 v25, v[20:21], off offset:96           // 000000A0A4A4: DC820060 197C0014
	global_load_d16_b16 v26, v[20:21], off offset:128          // 000000A0A4AC: DC820080 1A7C0014
	global_load_d16_b16 v27, v[20:21], off offset:160          // 000000A0A4B4: DC8200A0 1B7C0014
	global_load_d16_b16 v28, v[20:21], off offset:192          // 000000A0A4BC: DC8200C0 1C7C0014
	global_load_d16_b16 v29, v[20:21], off offset:224          // 000000A0A4C4: DC8200E0 1D7C0014
	v_mad_i64_i32 v[20:21], null, s49, v40, 0                  // 000000A0A4CC: D6FF7C14 02025031
	v_cndmask_b32_e64 v1, -v7, v7, vcc_lo                      // 000000A0A4D4: D5010001 21AA0F07
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 000000A0A4DC: D5010004 21AA0904
	v_cndmask_b32_e64 v14, -v14, v14, vcc_lo                   // 000000A0A4E4: D501000E 21AA1D0E
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 000000A0A4EC: D5010003 21AA0703
	v_cndmask_b32_e64 v15, -v15, v15, vcc_lo                   // 000000A0A4F4: D501000F 21AA1F0F
	v_add_f32_e32 v1, v1, v5                                   // 000000A0A4FC: 06020B01
	v_cndmask_b32_e64 v5, -v6, v6, vcc_lo                      // 000000A0A500: D5010005 21AA0D06
	.long 0xd73c0014                                           // 000000A0A508: D73C0014
	v_cndmask_b32_e32 v1, 1, v20, vcc_lo                       // 000000A0A50C: 02022881
	v_cndmask_b32_e64 v6, -v16, v16, vcc_lo                    // 000000A0A510: D5010006 21AA2110
	v_cndmask_b32_e64 v16, -v17, v17, vcc_lo                   // 000000A0A518: D5010010 21AA2311
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000A0A520: BF8700B4
	v_dual_add_f32 v4, v4, v9 :: v_dual_add_f32 v5, v5, v8     // 000000A0A524: C9081304 04041105
	v_add_f32_e32 v8, v14, v10                                 // 000000A0A52C: 0610150E
	.long 0xd7006a11                                           // 000000A0A530: D7006A11
	v_cndmask_b32_e32 v1, s42, v20, vcc_lo                     // 000000A0A534: 0202282A
	v_add_co_ci_u32_e64 v20, null, s43, v21, vcc_lo            // 000000A0A538: D5207C14 01AA2A2B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000A0A540: BF8701C4
	v_dual_mul_f32 v21, 0x3db504f3, v1 :: v_dual_mul_f32 v4, 0x3db504f3, v4// 000000A0A544: C8C602FF 150408FF 3DB504F3
	v_dual_add_f32 v3, v3, v2 :: v_dual_add_f32 v6, v6, v11    // 000000A0A550: C9080503 03061706
	v_dual_add_f32 v9, v15, v12 :: v_dual_add_f32 v10, v16, v13// 000000A0A558: C908190F 090A1B10
	v_mul_f32_e32 v5, 0x3db504f3, v5                           // 000000A0A560: 100A0AFF 3DB504F3
	v_dual_mul_f32 v3, 0x3db504f3, v3 :: v_dual_mul_f32 v8, 0x3db504f3, v8// 000000A0A568: C8C606FF 030810FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A0A574: BF870214
	v_mul_f32_e32 v6, 0x3db504f3, v6                           // 000000A0A578: 100C0CFF 3DB504F3
	v_mul_f32_e32 v10, 0x3db504f3, v10                         // 000000A0A580: 101414FF 3DB504F3
	s_waitcnt vmcnt(7)                                         // 000000A0A588: BF891FF7
	.long 0x7f0e3996                                           // 000000A0A58C: 7F0E3996
	.long 0xd7006a01                                           // 000000A0A590: D7006A01
	v_cndmask_b32_e32 v1, v17, v18, vcc_lo                     // 000000A0A594: 02022511
	s_delay_alu instid0(VALU_DEP_1)                            // 000000A0A598: BF870001
	v_add_co_ci_u32_e64 v2, null, v20, v19, vcc_lo             // 000000A0A59C: D5207C02 01AA2714
	v_fma_mix_f32 v11, v22, v21, neg(0) op_sel_hi:[1,0,0]      // 000000A0A5A4: CC20000B 8A022B16
	s_waitcnt vmcnt(6)                                         // 000000A0A5AC: BF891BF7
	v_fma_mix_f32 v3, v23, v3, neg(0) op_sel_hi:[1,0,0]        // 000000A0A5B0: CC200003 8A020717
	s_waitcnt vmcnt(5)                                         // 000000A0A5B8: BF8917F7
	v_fma_mix_f32 v5, v24, v5, neg(0) op_sel_hi:[1,0,0]        // 000000A0A5BC: CC200005 8A020B18
	s_waitcnt vmcnt(4)                                         // 000000A0A5C4: BF8913F7
	v_fma_mix_f32 v4, v25, v4, neg(0) op_sel_hi:[1,0,0]        // 000000A0A5C8: CC200004 8A020919
	s_waitcnt vmcnt(3)                                         // 000000A0A5D0: BF890FF7
	v_fma_mix_f32 v8, v26, v8, neg(0) op_sel_hi:[1,0,0]        // 000000A0A5D4: CC200008 8A02111A
	.long 0x7e2c398b                                           // 000000A0A5DC: 7E2C398B
	v_mul_f32_e32 v9, 0x3db504f3, v9                           // 000000A0A5E0: 101212FF 3DB504F3
	s_waitcnt vmcnt(2)                                         // 000000A0A5E8: BF890BF7
	v_fma_mix_f32 v6, v27, v6, neg(0) op_sel_hi:[1,0,0]        // 000000A0A5EC: CC200006 8A020D1B
	s_waitcnt vmcnt(0)                                         // 000000A0A5F4: BF8903F7
	v_fma_mix_f32 v10, v29, v10, neg(0) op_sel_hi:[1,0,0]      // 000000A0A5F8: CC20000A 8A02151D
	.long 0x7e0e3983                                           // 000000A0A600: 7E0E3983
	v_and_b32_e32 v12, 1, v22                                  // 000000A0A604: 36182C81
	.long 0x7e2c3984                                           // 000000A0A608: 7E2C3984
	v_fma_mix_f32 v9, v28, v9, neg(0) op_sel_hi:[1,0,0]        // 000000A0A60C: CC200009 8A02131C
	.long 0x7e2e3985                                           // 000000A0A614: 7E2E3985
	.long 0x7e303988                                           // 000000A0A618: 7E303988
	v_and_b32_e32 v7, 1, v7                                    // 000000A0A61C: 360E0E81
	v_and_b32_e32 v13, 1, v22                                  // 000000A0A620: 361A2C81
	.long 0x7e2c3986                                           // 000000A0A624: 7E2C3986
	.long 0x7e323989                                           // 000000A0A628: 7E323989
	v_and_b32_e32 v14, 1, v23                                  // 000000A0A62C: 361C2E81
	v_and_b32_e32 v15, 1, v24                                  // 000000A0A630: 361E3081
	v_add3_u32 v3, v3, v7, 0x7fff                              // 000000A0A634: D6550003 03FE0F03 00007FFF
	v_and_b32_e32 v16, 1, v22                                  // 000000A0A640: 36202C81
	.long 0x7e2c398a                                           // 000000A0A644: 7E2C398A
	v_and_b32_e32 v17, 1, v25                                  // 000000A0A648: 36223281
	v_add3_u32 v11, v11, v12, 0x7fff                           // 000000A0A64C: D655000B 03FE190B 00007FFF
	v_add3_u32 v5, v5, v14, 0x7fff                             // 000000A0A658: D6550005 03FE1D05 00007FFF
	v_add3_u32 v4, v4, v13, 0x7fff                             // 000000A0A664: D6550004 03FE1B04 00007FFF
	v_and_b32_e32 v7, 1, v22                                   // 000000A0A670: 360E2C81
	v_add3_u32 v8, v8, v15, 0x7fff                             // 000000A0A674: D6550008 03FE1F08 00007FFF
	v_add3_u32 v9, v9, v17, 0x7fff                             // 000000A0A680: D6550009 03FE2309 00007FFF
	v_add3_u32 v6, v6, v16, 0x7fff                             // 000000A0A68C: D6550006 03FE2106 00007FFF
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A0A698: BF870004
	v_add3_u32 v7, v10, v7, 0x7fff                             // 000000A0A69C: D6550007 03FE0F0A 00007FFF
	s_clause 0x7                                               // 000000A0A6A8: BF850007
	global_store_d16_hi_b16 v[1:2], v3, off                    // 000000A0A6AC: DC960000 007C0301
	global_store_d16_hi_b16 v[1:2], v11, off offset:32         // 000000A0A6B4: DC960020 007C0B01
	global_store_d16_hi_b16 v[1:2], v5, off offset:64          // 000000A0A6BC: DC960040 007C0501
	global_store_d16_hi_b16 v[1:2], v4, off offset:96          // 000000A0A6C4: DC960060 007C0401
	global_store_d16_hi_b16 v[1:2], v8, off offset:128         // 000000A0A6CC: DC960080 007C0801
	global_store_d16_hi_b16 v[1:2], v6, off offset:160         // 000000A0A6D4: DC9600A0 007C0601
	global_store_d16_hi_b16 v[1:2], v9, off offset:192         // 000000A0A6DC: DC9600C0 007C0901
	global_store_d16_hi_b16 v[1:2], v7, off offset:224         // 000000A0A6E4: DC9600E0 007C0701
	s_or_b32 exec_lo, exec_lo, s3                              // 000000A0A6EC: 8C7E037E
	s_mov_b32 s4, 0                                            // 000000A0A6F0: BE840080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000A0A6F4: BF870009
	s_and_b32 vcc_lo, exec_lo, s4                              // 000000A0A6F8: 8B6A047E
	s_cbranch_vccz 5335                                        // 000000A0A6FC: BFA314D7 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi3EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x7d5c>
	s_mul_hi_i32 s0, s2, 0x66666667                            // 000000A0A700: 9700FF02 66666667
	v_mov_b32_e32 v1, 0                                        // 000000A0A708: 7E020280
	s_lshr_b32 s1, s0, 31                                      // 000000A0A70C: 85019F00
	s_ashr_i32 s0, s0, 1                                       // 000000A0A710: 86008100
	s_mov_b32 s3, exec_lo                                      // 000000A0A714: BE83007E
	s_add_i32 s10, s0, s1                                      // 000000A0A718: 810A0100
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000A0A71C: BF870499
	s_ashr_i32 s11, s10, 31                                    // 000000A0A720: 860B9F0A
	s_lshl_b64 s[0:1], s[10:11], 2                             // 000000A0A724: 8480820A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000A0A728: BF870009
	s_add_u32 s0, s16, s0                                      // 000000A0A72C: 80000010
	s_addc_u32 s1, s17, s1                                     // 000000A0A730: 82010111
	global_load_b32 v1, v1, s[0:1]                             // 000000A0A734: DC520000 01000001
	s_waitcnt vmcnt(0)                                         // 000000A0A73C: BF8903F7
	v_readfirstlane_b32 s1, v1                                 // 000000A0A740: 7E020501
	v_cmpx_gt_u32_e32 0x140, v0                                // 000000A0A744: 7D9800FF 00000140
	s_cbranch_execz 48                                         // 000000A0A74C: BFA50030 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi3EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x2b10>
	s_mul_hi_i32 s0, s2, 0x51eb851f                            // 000000A0A750: 9700FF02 51EB851F
	v_lshlrev_b32_e32 v4, 4, v0                                // 000000A0A758: 30080084
	s_lshr_b32 s4, s0, 31                                      // 000000A0A75C: 85049F00
	s_ashr_i32 s0, s0, 4                                       // 000000A0A760: 86008400
	v_or_b32_e32 v3, 0xffffff00, v0                            // 000000A0A764: 380600FF FFFFFF00
	s_add_i32 s0, s0, s4                                       // 000000A0A76C: 81000400
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000A0A770: BF8700D9
	s_mul_i32 s4, s0, 0x1400                                   // 000000A0A774: 9604FF00 00001400
	s_mul_hi_i32 s0, s0, 0x1400                                // 000000A0A77C: 9700FF00 00001400
	s_add_u32 s4, s14, s4                                      // 000000A0A784: 8004040E
	s_addc_u32 s0, s15, s0                                     // 000000A0A788: 8200000F
	.long 0xd7000401                                           // 000000A0A78C: D7000401
	v_cndmask_b32_e32 v1, s4, v4, vcc_lo                       // 000000A0A790: 02020804
	v_add_co_ci_u32_e64 v2, null, s0, 0, s4                    // 000000A0A794: D5207C02 00110000
	s_mov_b32 s4, 0                                            // 000000A0A79C: BE840080
	s_nop 0                                                    // 000000A0A7A0: BF800000
	s_nop 0                                                    // 000000A0A7A4: BF800000
	s_nop 0                                                    // 000000A0A7A8: BF800000
	s_nop 0                                                    // 000000A0A7AC: BF800000
	s_nop 0                                                    // 000000A0A7B0: BF800000
	s_nop 0                                                    // 000000A0A7B4: BF800000
	s_nop 0                                                    // 000000A0A7B8: BF800000
	s_nop 0                                                    // 000000A0A7BC: BF800000
	global_load_b128 v[5:8], v[1:2], off                       // 000000A0A7C0: DC5E0000 057C0001
	v_add_nc_u32_e32 v3, 0x100, v3                             // 000000A0A7C8: 4A0606FF 00000100
	.long 0xd7006a01                                           // 000000A0A7D0: D7006A01
	v_cndmask_b32_e32 v1, 0x1000, v1, vcc_lo                   // 000000A0A7D4: 020202FF 00001000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A0A7DC: BF870191
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 000000A0A7E0: D5207C02 01AA0480
	.long 0xd4490000                                           // 000000A0A7E8: D4490000
	v_cndmask_b32_e32 v1, 63, v3, vcc_lo                       // 000000A0A7EC: 020206BF
	s_or_b32 s4, s0, s4                                        // 000000A0A7F0: 8C040400
	s_waitcnt vmcnt(0)                                         // 000000A0A7F4: BF8903F7
	ds_store_b128 v4, v[5:8]                                   // 000000A0A7F8: DB7C0000 00000504
	v_add_nc_u32_e32 v4, 0x1000, v4                            // 000000A0A800: 4A0808FF 00001000
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000A0A808: 917E047E
	s_cbranch_execnz 65516                                     // 000000A0A80C: BFA6FFEC <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi3EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x2ac0>
	s_or_b32 exec_lo, exec_lo, s3                              // 000000A0A810: 8C7E037E
	v_mul_u32_u24_e32 v71, 20, v40                             // 000000A0A814: 168E5094
	v_dual_mov_b32 v1, 0 :: v_dual_lshlrev_b32 v42, 2, v41     // 000000A0A818: CA220080 012A5282
	s_mul_i32 s0, s10, -5                                      // 000000A0A820: 9600C50A
	s_mul_i32 s5, s1, 0x190000                                 // 000000A0A824: 9605FF01 00190000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A0A82C: BF870112
	v_min_u32_e32 v3, 0x8c, v71                                // 000000A0A830: 26068EFF 0000008C
	v_mov_b32_e32 v16, v1                                      // 000000A0A838: 7E200301
	v_mov_b32_e32 v2, v1                                       // 000000A0A83C: 7E040301
	v_mov_b32_e32 v4, v1                                       // 000000A0A840: 7E080301
	v_mov_b32_e32 v5, v1                                       // 000000A0A844: 7E0A0301
	v_add_nc_u32_e32 v43, 20, v3                               // 000000A0A848: 4A560694
	v_mov_b32_e32 v3, v1                                       // 000000A0A84C: 7E060301
	v_mov_b32_e32 v6, v1                                       // 000000A0A850: 7E0C0301
	v_mov_b32_e32 v7, v1                                       // 000000A0A854: 7E0E0301
	v_mov_b32_e32 v8, v1                                       // 000000A0A858: 7E100301
	v_mov_b32_e32 v9, v1                                       // 000000A0A85C: 7E120301
	v_mov_b32_e32 v10, v1                                      // 000000A0A860: 7E140301
	v_mov_b32_e32 v11, v1                                      // 000000A0A864: 7E160301
	v_mov_b32_e32 v12, v1                                      // 000000A0A868: 7E180301
	v_mov_b32_e32 v13, v1                                      // 000000A0A86C: 7E1A0301
	v_mov_b32_e32 v14, v1                                      // 000000A0A870: 7E1C0301
	v_mov_b32_e32 v15, v1                                      // 000000A0A874: 7E1E0301
	s_add_i32 s2, s0, s2                                       // 000000A0A878: 81020200
	s_mul_hi_i32 s4, s1, 0x190000                              // 000000A0A87C: 9704FF01 00190000
	v_mov_b32_e32 v32, v16                                     // 000000A0A884: 7E400310
	s_add_u32 s0, s12, s5                                      // 000000A0A888: 8000050C
	s_mul_i32 s6, s2, 0x50000                                  // 000000A0A88C: 9606FF02 00050000
	v_cmp_lt_u32_e32 vcc_lo, v71, v43                          // 000000A0A894: 7C925747
	v_dual_mov_b32 v31, v15 :: v_dual_mov_b32 v30, v14         // 000000A0A898: CA10010F 1F1E010E
	v_dual_mov_b32 v29, v13 :: v_dual_mov_b32 v28, v12         // 000000A0A8A0: CA10010D 1D1C010C
	v_dual_mov_b32 v27, v11 :: v_dual_mov_b32 v26, v10         // 000000A0A8A8: CA10010B 1B1A010A
	v_dual_mov_b32 v25, v9 :: v_dual_mov_b32 v24, v8           // 000000A0A8B0: CA100109 19180108
	v_dual_mov_b32 v23, v7 :: v_dual_mov_b32 v22, v6           // 000000A0A8B8: CA100107 17160106
	v_dual_mov_b32 v21, v5 :: v_dual_mov_b32 v20, v4           // 000000A0A8C0: CA100105 15140104
	v_dual_mov_b32 v19, v3 :: v_dual_mov_b32 v18, v2           // 000000A0A8C8: CA100103 13120102
	v_mov_b32_e32 v17, v1                                      // 000000A0A8D0: 7E220301
	s_addc_u32 s3, s13, s4                                     // 000000A0A8D4: 8203040D
	s_mul_hi_i32 s7, s2, 0x50000                               // 000000A0A8D8: 9707FF02 00050000
	s_add_u32 s8, s0, s6                                       // 000000A0A8E0: 80080600
	s_addc_u32 s9, s3, s7                                      // 000000A0A8E4: 82090703
	s_waitcnt lgkmcnt(0)                                       // 000000A0A8E8: BF89FC07
	s_waitcnt_vscnt null, 0x0                                  // 000000A0A8EC: BC7C0000
	s_barrier                                                  // 000000A0A8F0: BFBD0000
	buffer_gl0_inv                                             // 000000A0A8F4: E0AC0000 00000000
	s_and_saveexec_b32 s3, vcc_lo                              // 000000A0A8FC: BE83206A
	s_cbranch_execz 45                                         // 000000A0A900: BFA5002D <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi3EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x2cb8>
	v_mul_u32_u24_e32 v17, 0xa000, v40                         // 000000A0A904: 162250FF 0000A000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A0A90C: BF870091
	.long 0xd7000011                                           // 000000A0A910: D7000011
	v_cndmask_b32_e32 v1, s8, v17, vcc_lo                      // 000000A0A914: 02022208
	v_add_co_ci_u32_e64 v18, null, s9, 0, s0                   // 000000A0A918: D5207C12 00010009
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A0A920: BF870092
	.long 0xd7000020                                           // 000000A0A924: D7000020
	v_cndmask_b32_e32 v1, v17, v42, vcc_lo                     // 000000A0A928: 02025511
	v_add_co_ci_u32_e64 v33, null, 0, v18, s0                  // 000000A0A92C: D5207C21 00022480
	s_clause 0xf                                               // 000000A0A934: BF85000F
	global_load_b32 v17, v[32:33], off                         // 000000A0A938: DC520000 117C0020
	global_load_b32 v18, v[32:33], off offset:128              // 000000A0A940: DC520080 127C0020
	global_load_b32 v19, v[32:33], off offset:256              // 000000A0A948: DC520100 137C0020
	global_load_b32 v20, v[32:33], off offset:384              // 000000A0A950: DC520180 147C0020
	global_load_b32 v21, v[32:33], off offset:512              // 000000A0A958: DC520200 157C0020
	global_load_b32 v22, v[32:33], off offset:640              // 000000A0A960: DC520280 167C0020
	global_load_b32 v23, v[32:33], off offset:768              // 000000A0A968: DC520300 177C0020
	global_load_b32 v24, v[32:33], off offset:896              // 000000A0A970: DC520380 187C0020
	global_load_b32 v25, v[32:33], off offset:1024             // 000000A0A978: DC520400 197C0020
	global_load_b32 v26, v[32:33], off offset:1152             // 000000A0A980: DC520480 1A7C0020
	global_load_b32 v27, v[32:33], off offset:1280             // 000000A0A988: DC520500 1B7C0020
	global_load_b32 v28, v[32:33], off offset:1408             // 000000A0A990: DC520580 1C7C0020
	global_load_b32 v29, v[32:33], off offset:1536             // 000000A0A998: DC520600 1D7C0020
	global_load_b32 v30, v[32:33], off offset:1664             // 000000A0A9A0: DC520680 1E7C0020
	global_load_b32 v31, v[32:33], off offset:1792             // 000000A0A9A8: DC520700 1F7C0020
	global_load_b32 v32, v[32:33], off offset:1920             // 000000A0A9B0: DC520780 207C0020
	s_or_b32 exec_lo, exec_lo, s3                              // 000000A0A9B8: 8C7E037E
	v_or_b32_e32 v33, 1, v71                                   // 000000A0A9BC: 38428E81
	s_mov_b32 s3, exec_lo                                      // 000000A0A9C0: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000A0A9C4: BF870001
	.long 0xd4c9007e                                           // 000000A0A9C8: D4C9007E
	v_cndmask_b32_e32 v1, v33, v43, vcc_lo                     // 000000A0A9CC: 02025721
	s_cbranch_execz 44                                         // 000000A0A9D0: BFA5002C <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi3EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x2d84>
	v_lshlrev_b32_e32 v1, 11, v33                              // 000000A0A9D4: 3002428B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A0A9D8: BF870091
	.long 0xd7000001                                           // 000000A0A9DC: D7000001
	v_cndmask_b32_e32 v1, s8, v1, vcc_lo                       // 000000A0A9E0: 02020208
	v_add_co_ci_u32_e64 v2, null, s9, 0, s0                    // 000000A0A9E4: D5207C02 00010009
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A0A9EC: BF870092
	.long 0xd7000021                                           // 000000A0A9F0: D7000021
	v_cndmask_b32_e32 v1, v1, v42, vcc_lo                      // 000000A0A9F4: 02025501
	v_add_co_ci_u32_e64 v34, null, 0, v2, s0                   // 000000A0A9F8: D5207C22 00020480
	s_clause 0xf                                               // 000000A0AA00: BF85000F
	global_load_b32 v1, v[33:34], off                          // 000000A0AA04: DC520000 017C0021
	global_load_b32 v2, v[33:34], off offset:128               // 000000A0AA0C: DC520080 027C0021
	global_load_b32 v3, v[33:34], off offset:256               // 000000A0AA14: DC520100 037C0021
	global_load_b32 v4, v[33:34], off offset:384               // 000000A0AA1C: DC520180 047C0021
	global_load_b32 v5, v[33:34], off offset:512               // 000000A0AA24: DC520200 057C0021
	global_load_b32 v6, v[33:34], off offset:640               // 000000A0AA2C: DC520280 067C0021
	global_load_b32 v7, v[33:34], off offset:768               // 000000A0AA34: DC520300 077C0021
	global_load_b32 v8, v[33:34], off offset:896               // 000000A0AA3C: DC520380 087C0021
	global_load_b32 v9, v[33:34], off offset:1024              // 000000A0AA44: DC520400 097C0021
	global_load_b32 v10, v[33:34], off offset:1152             // 000000A0AA4C: DC520480 0A7C0021
	global_load_b32 v11, v[33:34], off offset:1280             // 000000A0AA54: DC520500 0B7C0021
	global_load_b32 v12, v[33:34], off offset:1408             // 000000A0AA5C: DC520580 0C7C0021
	global_load_b32 v13, v[33:34], off offset:1536             // 000000A0AA64: DC520600 0D7C0021
	global_load_b32 v14, v[33:34], off offset:1664             // 000000A0AA6C: DC520680 0E7C0021
	global_load_b32 v15, v[33:34], off offset:1792             // 000000A0AA74: DC520700 0F7C0021
	global_load_b32 v16, v[33:34], off offset:1920             // 000000A0AA7C: DC520780 107C0021
	s_or_b32 exec_lo, exec_lo, s3                              // 000000A0AA84: 8C7E037E
	v_dual_mov_b32 v58, 0 :: v_dual_mov_b32 v45, 0             // 000000A0AA88: CA100080 3A2C0080
	v_dual_mov_b32 v44, 0 :: v_dual_mov_b32 v47, 0             // 000000A0AA90: CA100080 2C2E0080
	v_dual_mov_b32 v46, 0 :: v_dual_mov_b32 v49, 0             // 000000A0AA98: CA100080 2E300080
	v_dual_mov_b32 v48, 0 :: v_dual_mov_b32 v51, 0             // 000000A0AAA0: CA100080 30320080
	v_dual_mov_b32 v50, 0 :: v_dual_mov_b32 v53, 0             // 000000A0AAA8: CA100080 32340080
	v_dual_mov_b32 v52, 0 :: v_dual_mov_b32 v55, 0             // 000000A0AAB0: CA100080 34360080
	v_dual_mov_b32 v54, 0 :: v_dual_mov_b32 v57, 0             // 000000A0AAB8: CA100080 36380080
	v_dual_mov_b32 v56, 0 :: v_dual_mov_b32 v59, 0             // 000000A0AAC0: CA100080 383A0080
	s_and_saveexec_b32 s3, vcc_lo                              // 000000A0AAC8: BE83206A
	s_cbranch_execz 3633                                       // 000000A0AACC: BFA50E31 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi3EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x6694>
	v_cmp_ne_u32_e32 vcc_lo, 0, v41                            // 000000A0AAD0: 7C9A5280
	v_lshlrev_b32_e32 v33, 5, v41                              // 000000A0AAD4: 30425285
	v_dual_mov_b32 v59, 0 :: v_dual_lshlrev_b32 v44, 11, v71   // 000000A0AAD8: CA220080 3B2C8E8B
	.long 0xd700003c                                           // 000000A0AAE0: D700003C
	v_cndmask_b32_e32 v1, s8, v42, vcc_lo                      // 000000A0AAE4: 02025408
	s_delay_alu instid0(VALU_DEP_3)                            // 000000A0AAE8: BF870003
	v_dual_mov_b32 v37, 0 :: v_dual_add_nc_u32 v34, 0x3f0, v33 // 000000A0AAEC: CA200080 252242FF 000003F0
	v_add_co_ci_u32_e64 v61, null, s9, 0, s0                   // 000000A0AAF8: D5207C3D 00010009
	s_add_u32 s0, s5, s6                                       // 000000A0AB00: 80000605
	v_lshrrev_b32_e32 v38, 5, v34                              // 000000A0AB04: 324C4485
	s_addc_u32 s4, s4, s7                                      // 000000A0AB08: 82040704
	.long 0xd700002c                                           // 000000A0AB0C: D700002C
	v_cndmask_b32_e32 v1, s0, v44, vcc_lo                      // 000000A0AB10: 02025800
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A0AB14: BF870191
	v_add_co_ci_u32_e64 v45, null, s4, 0, s0                   // 000000A0AB18: D5207C2D 00010004
	v_subrev_nc_u32_e32 v38, 32, v38                           // 000000A0AB20: 4E4C4CA0
	v_dual_mov_b32 v57, 0 :: v_dual_and_b32 v34, 0x7e0, v34    // 000000A0AB24: CA240080 392244FF 000007E0
	v_mul_u32_u24_e32 v35, 0x840, v40                          // 000000A0AB30: 164650FF 00000840
	v_mad_u32_u24 v36, 0x840, v40, v42                         // 000000A0AB38: D60B0024 04AA50FF 00000840
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000A0AB44: BF8700A4
	v_cndmask_b32_e32 v38, 31, v38, vcc_lo                     // 000000A0AB48: 024C4C9F
	.long 0xd7006a2c                                           // 000000A0AB4C: D7006A2C
	v_cndmask_b32_e32 v1, v44, v42, vcc_lo                     // 000000A0AB50: 0202552C
	v_add_co_ci_u32_e64 v45, null, 0, v45, vcc_lo              // 000000A0AB54: D5207C2D 01AA5A80
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000A0AB5C: BF870223
	v_dual_mov_b32 v55, 0 :: v_dual_add_nc_u32 v46, 1, v38     // 000000A0AB60: CA200080 372E4C81
	v_sub_nc_u32_e32 v33, v34, v33                             // 000000A0AB68: 4C424322
	.long 0xd7006a2c                                           // 000000A0AB6C: D7006A2C
	v_cndmask_b32_e32 v1, s12, v44, vcc_lo                     // 000000A0AB70: 0202580C
	s_delay_alu instid0(VALU_DEP_3)                            // 000000A0AB74: BF870003
	v_dual_mov_b32 v53, 0 :: v_dual_and_b32 v34, 31, v46       // 000000A0AB78: CA240080 35225C9F
	v_dual_mov_b32 v56, 0 :: v_dual_and_b32 v39, 16, v0        // 000000A0AB80: CA240080 38260090
	v_add_co_ci_u32_e64 v45, null, s13, v45, vcc_lo            // 000000A0AB88: D5207C2D 01AA5A0D
	v_dual_mov_b32 v51, 0 :: v_dual_add_nc_u32 v62, 0xfffffc30, v33// 000000A0AB90: CA200080 333E42FF FFFFFC30
	v_lshl_add_u32 v33, v38, 2, v35                            // 000000A0AB9C: D6460021 048D0526
	v_lshl_add_u32 v34, v34, 2, v35                            // 000000A0ABA4: D6460022 048D0522
	.long 0xd7006a26                                           // 000000A0ABAC: D7006A26
	v_cndmask_b32_e32 v1, 0x1400, v44, vcc_lo                  // 000000A0ABB0: 020258FF 00001400
	v_lshl_or_b32 v63, v71, 5, v39                             // 000000A0ABB8: D656003F 049D0B47
	v_add_co_ci_u32_e64 v39, null, 0, v45, vcc_lo              // 000000A0ABC0: D5207C27 01AA5A80
	v_dual_mov_b32 v49, 0 :: v_dual_add_nc_u32 v64, 0x1400, v36// 000000A0ABC8: CA200080 314048FF 00001400
	v_dual_mov_b32 v54, 0 :: v_dual_add_nc_u32 v65, 0x1800, v36// 000000A0ABD4: CA200080 364048FF 00001800
	v_dual_mov_b32 v47, 0 :: v_dual_add_nc_u32 v66, 0x1400, v33// 000000A0ABE0: CA200080 2F4242FF 00001400
	v_dual_mov_b32 v52, 0 :: v_dual_add_nc_u32 v67, 0x1400, v34// 000000A0ABEC: CA200080 344244FF 00001400
	v_dual_mov_b32 v45, 0 :: v_dual_add_nc_u32 v68, 0x1800, v33// 000000A0ABF8: CA200080 2D4442FF 00001800
	v_dual_mov_b32 v50, 0 :: v_dual_add_nc_u32 v69, 0x1800, v34// 000000A0AC04: CA200080 324444FF 00001800
	v_mov_b32_e32 v48, 0                                       // 000000A0AC10: 7E600280
	v_mov_b32_e32 v46, 0                                       // 000000A0AC14: 7E5C0280
	v_mov_b32_e32 v44, 0                                       // 000000A0AC18: 7E580280
	v_mov_b32_e32 v58, 0                                       // 000000A0AC1C: 7E740280
	s_mov_b32 s4, 0                                            // 000000A0AC20: BE840080
	s_movk_i32 s5, 0x1eee                                      // 000000A0AC24: B0051EEE
	s_branch 1714                                              // 000000A0AC28: BFA006B2 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi3EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x49f4>
	s_or_b32 exec_lo, exec_lo, s7                              // 000000A0AC2C: 8C7E077E
	ds_load_2addr_b32 v[71:72], v67 offset1:32                 // 000000A0AC30: D8DC2000 47000043
	ds_load_2addr_b32 v[77:78], v64 offset1:32                 // 000000A0AC38: D8DC2000 4D000040
	ds_load_2addr_b32 v[75:76], v66 offset1:32                 // 000000A0AC40: D8DC2000 4B000042
	ds_load_b128 v[33:36], v63 offset:32                       // 000000A0AC48: DBFC0020 2100003F
	s_waitcnt lgkmcnt(3)                                       // 000000A0AC50: BF89FC37
	v_mov_b32_e32 v74, v71                                     // 000000A0AC54: 7E940347
	s_waitcnt lgkmcnt(2)                                       // 000000A0AC58: BF89FC27
	v_bfe_u32 v71, v77, 12, 16                                 // 000000A0AC5C: D6100047 0241194D
	s_waitcnt lgkmcnt(1)                                       // 000000A0AC64: BF89FC17
	v_mov_b32_e32 v73, v76                                     // 000000A0AC68: 7E92034C
	v_bfe_u32 v79, v77, 8, 16                                  // 000000A0AC6C: D610004F 0241114D
	v_bfe_u32 v80, v77, 4, 16                                  // 000000A0AC74: D6100050 0241094D
	v_and_b32_e32 v77, 0xffff, v77                             // 000000A0AC7C: 369A9AFF 0000FFFF
	.long 0xd73d004a                                           // 000000A0AC84: D73D004A
	v_cndmask_b32_e32 v1, v62, v74, vcc_lo                     // 000000A0AC88: 0202953E
	v_bfe_u32 v76, v78, 12, 16                                 // 000000A0AC8C: D610004C 0241194E
	v_bfe_u32 v81, v78, 8, 16                                  // 000000A0AC94: D6100051 0241114E
	v_bfe_u32 v82, v78, 4, 16                                  // 000000A0AC9C: D6100052 0241094E
	v_and_b32_e32 v78, 0xffff, v78                             // 000000A0ACA4: 369C9CFF 0000FFFF
	.long 0xd72c004b                                           // 000000A0ACAC: D72C004B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v71, vcc_lo              // 000000A0ACB0: 02028EFF 83DCD12D
	.long 0xd73d0047                                           // 000000A0ACB8: D73D0047
	v_cndmask_b32_e32 v1, v62, v72, vcc_lo                     // 000000A0ACBC: 0202913E
	.long 0xd72c004d                                           // 000000A0ACC0: D72C004D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v77, vcc_lo              // 000000A0ACC4: 02029AFF 83DCD12D
	.long 0xd72c0050                                           // 000000A0ACCC: D72C0050
	v_cndmask_b32_e32 v1, 0x83dcd12d, v80, vcc_lo              // 000000A0ACD0: 0202A0FF 83DCD12D
	.long 0xd72c004f                                           // 000000A0ACD8: D72C004F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v79, vcc_lo              // 000000A0ACDC: 02029EFF 83DCD12D
	v_bfe_u32 v83, v74, 4, 16                                  // 000000A0ACE4: D6100053 0241094A
	v_bfe_u32 v72, v74, 12, 16                                 // 000000A0ACEC: D6100048 0241194A
	v_bfe_u32 v84, v71, 12, 16                                 // 000000A0ACF4: D6100054 02411947
	v_bfe_u32 v85, v71, 8, 16                                  // 000000A0ACFC: D6100055 02411147
	v_sad_u8 v75, v75, 0, 0x6400                               // 000000A0AD04: D622004B 03FD014B 00006400
	v_sad_u8 v77, v77, 0, 0x6400                               // 000000A0AD10: D622004D 03FD014D 00006400
	v_sad_u8 v80, v80, 0, 0x6400                               // 000000A0AD1C: D6220050 03FD0150 00006400
	.long 0xd72c0054                                           // 000000A0AD28: D72C0054
	v_cndmask_b32_e32 v1, 0x83dcd12d, v84, vcc_lo              // 000000A0AD2C: 0202A8FF 83DCD12D
	.long 0xd72c0053                                           // 000000A0AD34: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v83, vcc_lo              // 000000A0AD38: 0202A6FF 83DCD12D
	.long 0xd72c0055                                           // 000000A0AD40: D72C0055
	v_cndmask_b32_e32 v1, 0x83dcd12d, v85, vcc_lo              // 000000A0AD44: 0202AAFF 83DCD12D
	v_lshlrev_b32_e32 v77, 16, v77                             // 000000A0AD4C: 309A9A90
	v_sad_u8 v79, v79, 0, 0x6400                               // 000000A0AD50: D622004F 03FD014F 00006400
	v_and_b32_e32 v75, 0xffff, v75                             // 000000A0AD5C: 369696FF 0000FFFF
	.long 0xd72c0049                                           // 000000A0AD64: D72C0049
	v_cndmask_b32_e32 v1, 0x83dcd12d, v76, vcc_lo              // 000000A0AD68: 020298FF 83DCD12D
	v_bfe_u32 v76, v74, 8, 16                                  // 000000A0AD70: D610004C 0241114A
	v_and_or_b32 v80, 0xffff, v80, v77                         // 000000A0AD78: D6570050 0536A0FF 0000FFFF
	v_sad_u8 v77, v84, 0, 0x6400                               // 000000A0AD84: D622004D 03FD0154 00006400
	.long 0xd72c0048                                           // 000000A0AD90: D72C0048
	v_cndmask_b32_e32 v1, 0x83dcd12d, v72, vcc_lo              // 000000A0AD94: 020290FF 83DCD12D
	v_lshl_or_b32 v75, v79, 16, v75                            // 000000A0AD9C: D656004B 052D214F
	v_sad_u8 v79, v83, 0, 0x6400                               // 000000A0ADA4: D622004F 03FD0153 00006400
	v_sad_u8 v83, v85, 0, 0x6400                               // 000000A0ADB0: D6220053 03FD0155 00006400
	v_and_b32_e32 v77, 0xffff, v77                             // 000000A0ADBC: 369A9AFF 0000FFFF
	.long 0xd72c004c                                           // 000000A0ADC4: D72C004C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v76, vcc_lo              // 000000A0ADC8: 020298FF 83DCD12D
	v_bfe_u32 v86, v71, 4, 16                                  // 000000A0ADD0: D6100056 02410947
	v_and_b32_e32 v71, 0xffff, v71                             // 000000A0ADD8: 368E8EFF 0000FFFF
	v_sad_u8 v72, v72, 0, 0x6400                               // 000000A0ADE0: D6220048 03FD0148 00006400
	v_lshl_or_b32 v77, v83, 16, v77                            // 000000A0ADEC: D656004D 05352153
	.long 0xd72c0051                                           // 000000A0ADF4: D72C0051
	v_cndmask_b32_e32 v1, 0x83dcd12d, v81, vcc_lo              // 000000A0ADF8: 0202A2FF 83DCD12D
	v_sad_u8 v73, v73, 0, 0x6400                               // 000000A0AE00: D6220049 03FD0149 00006400
	.long 0xd72c0047                                           // 000000A0AE0C: D72C0047
	v_cndmask_b32_e32 v1, 0x83dcd12d, v71, vcc_lo              // 000000A0AE10: 02028EFF 83DCD12D
	v_sad_u8 v76, v76, 0, 0x6400                               // 000000A0AE18: D622004C 03FD014C 00006400
	v_pk_fma_f16 v83, v77, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0AE24: CC0E0053 0BFC0B4D 0000C931
	v_and_b32_e32 v72, 0xffff, v72                             // 000000A0AE30: 369090FF 0000FFFF
	v_and_b32_e32 v73, 0xffff, v73                             // 000000A0AE38: 369292FF 0000FFFF
	.long 0xd72c0056                                           // 000000A0AE40: D72C0056
	v_cndmask_b32_e32 v1, 0x83dcd12d, v86, vcc_lo              // 000000A0AE44: 0202ACFF 83DCD12D
	v_sad_u8 v81, v81, 0, 0x6400                               // 000000A0AE4C: D6220051 03FD0151 00006400
	s_waitcnt lgkmcnt(0)                                       // 000000A0AE58: BF89FC07
	v_dot2acc_f32_f16 v57, v83, v33                            // 000000A0AE5C: 04724353
	v_lshl_or_b32 v72, v76, 16, v72                            // 000000A0AE60: D6560048 0521214C
	v_sad_u8 v76, v71, 0, 0x6400                               // 000000A0AE68: D622004C 03FD0147 00006400
	.long 0xd72c004e                                           // 000000A0AE74: D72C004E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 000000A0AE78: 02029CFF 83DCD12D
	v_lshl_or_b32 v81, v81, 16, v73                            // 000000A0AE80: D6560051 05252151
	.long 0xd72c0052                                           // 000000A0AE88: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 000000A0AE8C: 0202A4FF 83DCD12D
	v_pk_fma_f16 v84, v72, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0AE94: CC0E0054 0BFC0B48 0000C931
	v_and_b32_e32 v74, 0xffff, v74                             // 000000A0AEA0: 369494FF 0000FFFF
	ds_load_2addr_b32 v[71:72], v67 offset0:64 offset1:96      // 000000A0AEA8: D8DC6040 47000043
	v_sad_u8 v86, v86, 0, 0x6400                               // 000000A0AEB0: D6220056 03FD0156 00006400
	v_dot2acc_f32_f16 v59, v84, v33                            // 000000A0AEBC: 04764354
	.long 0xd72c004a                                           // 000000A0AEC0: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 000000A0AEC4: 020294FF 83DCD12D
	v_sad_u8 v78, v78, 0, 0x6400                               // 000000A0AECC: D622004E 03FD014E 00006400
	v_sad_u8 v82, v82, 0, 0x6400                               // 000000A0AED8: D6220052 03FD0152 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000A0AEE4: BF8700A3
	v_sad_u8 v74, v74, 0, 0x6400                               // 000000A0AEE8: D622004A 03FD014A 00006400
	s_waitcnt lgkmcnt(0)                                       // 000000A0AEF4: BF89FC07
	v_dual_mov_b32 v73, v71 :: v_dual_lshlrev_b32 v74, 16, v74 // 000000A0AEF8: CA220147 494A9490
	v_pk_fma_f16 v71, v81, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0AF00: CC0E0047 0BFC0B51 0000C931
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000A0AF0C: BF870122
	v_and_or_b32 v74, 0xffff, v79, v74                         // 000000A0AF10: D657004A 052A9EFF 0000FFFF
	v_pk_fma_f16 v79, v75, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0AF1C: CC0E004F 0BFC0B4B 0000C931
	v_pk_fma_f16 v85, v74, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0AF28: CC0E0055 0BFC0B4A 0000C931
	ds_load_2addr_b32 v[74:75], v66 offset0:64 offset1:96      // 000000A0AF34: D8DC6040 4A000042
	v_dual_dot2acc_f32_f16 v59, v85, v34 :: v_dual_lshlrev_b32 v76, 16, v76// 000000A0AF3C: CB224555 3B4C9890
	v_lshlrev_b32_e32 v78, 16, v78                             // 000000A0AF44: 309C9C90
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A0AF48: BF870192
	v_and_or_b32 v76, 0xffff, v86, v76                         // 000000A0AF4C: D657004C 0532ACFF 0000FFFF
	v_dot2acc_f32_f16 v59, v79, v35                            // 000000A0AF58: 0476474F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A0AF5C: BF870193
	v_and_or_b32 v78, 0xffff, v82, v78                         // 000000A0AF60: D657004E 053AA4FF 0000FFFF
	v_pk_fma_f16 v84, v76, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0AF6C: CC0E0054 0BFC0B4C 0000C931
	ds_load_2addr_b32 v[76:77], v64 offset0:64 offset1:96      // 000000A0AF78: D8DC6040 4C000040
	v_pk_fma_f16 v78, v78, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0AF80: CC0E004E 0BFC0B4E 0000C931
	s_waitcnt lgkmcnt(1)                                       // 000000A0AF8C: BF89FC17
	.long 0xd73d0049                                           // 000000A0AF90: D73D0049
	v_cndmask_b32_e32 v1, v62, v73, vcc_lo                     // 000000A0AF94: 0202933E
	v_dot2acc_f32_f16 v57, v84, v34                            // 000000A0AF98: 04724554
	v_pk_fma_f16 v74, v80, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0AF9C: CC0E004A 0BFC0B50 0000C931
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A0AFA8: BF870113
	v_bfe_u32 v79, v73, 8, 16                                  // 000000A0AFAC: D610004F 02411149
	v_dual_dot2acc_f32_f16 v59, v74, v36 :: v_dual_and_b32 v74, 0xffff, v73// 000000A0AFB4: CB24494A 3B4A92FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A0AFC0: BF870004
	v_dot2acc_f32_f16 v57, v71, v35                            // 000000A0AFC4: 04724747
	v_bfe_u32 v71, v73, 12, 16                                 // 000000A0AFC8: D6100047 02411949
	v_bfe_u32 v73, v73, 4, 16                                  // 000000A0AFD0: D6100049 02410949
	s_waitcnt lgkmcnt(0)                                       // 000000A0AFD8: BF89FC07
	v_bfe_u32 v80, v76, 8, 16                                  // 000000A0AFDC: D6100050 0241114C
	.long 0xd72c004a                                           // 000000A0AFE4: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 000000A0AFE8: 020294FF 83DCD12D
	v_dot2acc_f32_f16 v57, v78, v36                            // 000000A0AFF0: 0472494E
	.long 0xd72c0047                                           // 000000A0AFF4: D72C0047
	v_cndmask_b32_e32 v1, 0x83dcd12d, v71, vcc_lo              // 000000A0AFF8: 02028EFF 83DCD12D
	v_bfe_u32 v78, v76, 12, 16                                 // 000000A0B000: D610004E 0241194C
	.long 0xd72c004f                                           // 000000A0B008: D72C004F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v79, vcc_lo              // 000000A0B00C: 02029EFF 83DCD12D
	v_bfe_u32 v81, v76, 4, 16                                  // 000000A0B014: D6100051 0241094C
	.long 0xd72c0049                                           // 000000A0B01C: D72C0049
	v_cndmask_b32_e32 v1, 0x83dcd12d, v73, vcc_lo              // 000000A0B020: 020292FF 83DCD12D
	v_and_b32_e32 v76, 0xffff, v76                             // 000000A0B028: 369898FF 0000FFFF
	.long 0xd72c004e                                           // 000000A0B030: D72C004E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 000000A0B034: 02029CFF 83DCD12D
	.long 0xd72c0050                                           // 000000A0B03C: D72C0050
	v_cndmask_b32_e32 v1, 0x83dcd12d, v80, vcc_lo              // 000000A0B040: 0202A0FF 83DCD12D
	v_sad_u8 v71, v71, 0, 0x6400                               // 000000A0B048: D6220047 03FD0147 00006400
	v_sad_u8 v74, v74, 0, 0x6400                               // 000000A0B054: D622004A 03FD014A 00006400
	.long 0xd72c004c                                           // 000000A0B060: D72C004C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v76, vcc_lo              // 000000A0B064: 020298FF 83DCD12D
	v_sad_u8 v79, v79, 0, 0x6400                               // 000000A0B06C: D622004F 03FD014F 00006400
	v_sad_u8 v82, v73, 0, 0x6400                               // 000000A0B078: D6220052 03FD0149 00006400
	v_and_b32_e32 v71, 0xffff, v71                             // 000000A0B084: 368E8EFF 0000FFFF
	v_sad_u8 v78, v78, 0, 0x6400                               // 000000A0B08C: D622004E 03FD014E 00006400
	v_mov_b32_e32 v73, v75                                     // 000000A0B098: 7E92034B
	.long 0xd72c0051                                           // 000000A0B09C: D72C0051
	v_cndmask_b32_e32 v1, 0x83dcd12d, v81, vcc_lo              // 000000A0B0A0: 0202A2FF 83DCD12D
	v_lshlrev_b32_e32 v74, 16, v74                             // 000000A0B0A8: 30949490
	v_sad_u8 v75, v80, 0, 0x6400                               // 000000A0B0AC: D622004B 03FD0150 00006400
	v_and_b32_e32 v78, 0xffff, v78                             // 000000A0B0B8: 369C9CFF 0000FFFF
	v_lshl_or_b32 v79, v79, 16, v71                            // 000000A0B0C0: D656004F 051D214F
	v_sad_u8 v76, v76, 0, 0x6400                               // 000000A0B0C8: D622004C 03FD014C 00006400
	.long 0xd73d0047                                           // 000000A0B0D4: D73D0047
	v_cndmask_b32_e32 v1, v62, v72, vcc_lo                     // 000000A0B0D8: 0202913E
	v_and_or_b32 v74, 0xffff, v82, v74                         // 000000A0B0DC: D657004A 052AA4FF 0000FFFF
	v_lshl_or_b32 v72, v75, 16, v78                            // 000000A0B0E8: D6560048 0539214B
	v_sad_u8 v73, v81, 0, 0x6400                               // 000000A0B0F0: D6220049 03FD0151 00006400
	v_lshlrev_b32_e32 v75, 16, v76                             // 000000A0B0FC: 30969890
	v_pk_fma_f16 v76, v79, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0B100: CC0E004C 0BFC0B4F 0000C931
	v_bfe_u32 v78, v71, 12, 16                                 // 000000A0B10C: D610004E 02411947
	v_pk_fma_f16 v74, v74, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0B114: CC0E004A 0BFC0B4A 0000C931
	v_pk_fma_f16 v79, v72, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0B120: CC0E004F 0BFC0B48 0000C931
	v_and_or_b32 v72, 0xffff, v73, v75                         // 000000A0B12C: D6570048 052E92FF 0000FFFF
	v_dot2acc_f32_f16 v56, v76, v33                            // 000000A0B138: 0470434C
	v_bfe_u32 v73, v71, 8, 16                                  // 000000A0B13C: D6100049 02411147
	.long 0xd72c004b                                           // 000000A0B144: D72C004B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 000000A0B148: 02029CFF 83DCD12D
	v_and_b32_e32 v76, 0xffff, v71                             // 000000A0B150: 36988EFF 0000FFFF
	v_pk_fma_f16 v78, v72, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0B158: CC0E004E 0BFC0B48 0000C931
	v_dot2acc_f32_f16 v56, v74, v34                            // 000000A0B164: 0470454A
	v_bfe_u32 v74, v71, 4, 16                                  // 000000A0B168: D610004A 02410947
	ds_load_2addr_b32 v[71:72], v67 offset0:128 offset1:160    // 000000A0B170: D8DCA080 47000043
	.long 0xd72c0049                                           // 000000A0B178: D72C0049
	v_cndmask_b32_e32 v1, 0x83dcd12d, v73, vcc_lo              // 000000A0B17C: 020292FF 83DCD12D
	.long 0xd72c004c                                           // 000000A0B184: D72C004C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v76, vcc_lo              // 000000A0B188: 020298FF 83DCD12D
	v_sad_u8 v80, v75, 0, 0x6400                               // 000000A0B190: D6220050 03FD014B 00006400
	.long 0xd72c0053                                           // 000000A0B19C: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 000000A0B1A0: 020294FF 83DCD12D
	ds_load_2addr_b32 v[74:75], v66 offset0:128 offset1:160    // 000000A0B1A8: D8DCA080 4A000042
	v_bfe_u32 v81, v77, 12, 16                                 // 000000A0B1B0: D6100051 0241194D
	v_bfe_u32 v82, v77, 8, 16                                  // 000000A0B1B8: D6100052 0241114D
	v_and_b32_e32 v80, 0xffff, v80                             // 000000A0B1C0: 36A0A0FF 0000FFFF
	v_sad_u8 v73, v73, 0, 0x6400                               // 000000A0B1C8: D6220049 03FD0149 00006400
	v_bfe_u32 v84, v77, 4, 16                                  // 000000A0B1D4: D6100054 0241094D
	v_and_b32_e32 v77, 0xffff, v77                             // 000000A0B1DC: 369A9AFF 0000FFFF
	.long 0xd72c0051                                           // 000000A0B1E4: D72C0051
	v_cndmask_b32_e32 v1, 0x83dcd12d, v81, vcc_lo              // 000000A0B1E8: 0202A2FF 83DCD12D
	v_sad_u8 v76, v76, 0, 0x6400                               // 000000A0B1F0: D622004C 03FD014C 00006400
	v_lshl_or_b32 v73, v73, 16, v80                            // 000000A0B1FC: D6560049 05412149
	.long 0xd72c0052                                           // 000000A0B204: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 000000A0B208: 0202A4FF 83DCD12D
	.long 0xd72c004d                                           // 000000A0B210: D72C004D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v77, vcc_lo              // 000000A0B214: 02029AFF 83DCD12D
	v_sad_u8 v80, v83, 0, 0x6400                               // 000000A0B21C: D6220050 03FD0153 00006400
	v_dot2acc_f32_f16 v56, v79, v35                            // 000000A0B228: 0470474F
	v_pk_fma_f16 v83, v73, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0B22C: CC0E0053 0BFC0B49 0000C931
	s_waitcnt lgkmcnt(1)                                       // 000000A0B238: BF89FC17
	v_dual_mov_b32 v73, v71 :: v_dual_lshlrev_b32 v76, 16, v76 // 000000A0B23C: CA220147 494C9890
	v_sad_u8 v81, v81, 0, 0x6400                               // 000000A0B244: D6220051 03FD0151 00006400
	.long 0xd72c0047                                           // 000000A0B250: D72C0047
	v_cndmask_b32_e32 v1, 0x83dcd12d, v84, vcc_lo              // 000000A0B254: 0202A8FF 83DCD12D
	v_sad_u8 v84, v77, 0, 0x6400                               // 000000A0B25C: D6220054 03FD014D 00006400
	v_dot2acc_f32_f16 v55, v83, v33                            // 000000A0B268: 046E4353
	v_and_or_b32 v80, 0xffff, v80, v76                         // 000000A0B26C: D6570050 0532A0FF 0000FFFF
	ds_load_2addr_b32 v[76:77], v64 offset0:128 offset1:160    // 000000A0B278: D8DCA080 4C000040
	s_waitcnt lgkmcnt(1)                                       // 000000A0B280: BF89FC17
	.long 0xd73d0049                                           // 000000A0B284: D73D0049
	v_cndmask_b32_e32 v1, v62, v73, vcc_lo                     // 000000A0B288: 0202933E
	v_and_b32_e32 v81, 0xffff, v81                             // 000000A0B28C: 36A2A2FF 0000FFFF
	v_sad_u8 v82, v82, 0, 0x6400                               // 000000A0B294: D6220052 03FD0152 00006400
	v_pk_fma_f16 v74, v80, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0B2A0: CC0E004A 0BFC0B50 0000C931
	v_sad_u8 v71, v71, 0, 0x6400                               // 000000A0B2AC: D6220047 03FD0147 00006400
	v_dot2acc_f32_f16 v56, v78, v36                            // 000000A0B2B8: 0470494E
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000A0B2BC: BF870244
	v_lshl_or_b32 v80, v82, 16, v81                            // 000000A0B2C0: D6560050 05452152
	v_lshlrev_b32_e32 v81, 16, v84                             // 000000A0B2C8: 30A2A890
	v_bfe_u32 v82, v73, 12, 16                                 // 000000A0B2CC: D6100052 02411949
	v_dot2acc_f32_f16 v55, v74, v34                            // 000000A0B2D4: 046E454A
	v_pk_fma_f16 v79, v80, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0B2D8: CC0E004F 0BFC0B50 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A0B2E4: BF870214
	v_and_or_b32 v71, 0xffff, v71, v81                         // 000000A0B2E8: D6570047 05468EFF 0000FFFF
	.long 0xd72c004a                                           // 000000A0B2F4: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 000000A0B2F8: 0202A4FF 83DCD12D
	v_bfe_u32 v80, v73, 8, 16                                  // 000000A0B300: D6100050 02411149
	s_delay_alu instid0(VALU_DEP_3)                            // 000000A0B308: BF870003
	v_pk_fma_f16 v78, v71, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0B30C: CC0E004E 0BFC0B47 0000C931
	v_bfe_u32 v71, v73, 4, 16                                  // 000000A0B318: D6100047 02410949
	v_and_b32_e32 v73, 0xffff, v73                             // 000000A0B320: 369292FF 0000FFFF
	s_waitcnt lgkmcnt(0)                                       // 000000A0B328: BF89FC07
	v_and_b32_e32 v82, 0xffff, v76                             // 000000A0B32C: 36A498FF 0000FFFF
	v_sad_u8 v74, v74, 0, 0x6400                               // 000000A0B334: D622004A 03FD014A 00006400
	v_dot2acc_f32_f16 v55, v79, v35                            // 000000A0B340: 046E474F
	.long 0xd72c004f                                           // 000000A0B344: D72C004F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v80, vcc_lo              // 000000A0B348: 0202A0FF 83DCD12D
	v_bfe_u32 v80, v76, 12, 16                                 // 000000A0B350: D6100050 0241194C
	.long 0xd72c0049                                           // 000000A0B358: D72C0049
	v_cndmask_b32_e32 v1, 0x83dcd12d, v73, vcc_lo              // 000000A0B35C: 020292FF 83DCD12D
	.long 0xd72c0047                                           // 000000A0B364: D72C0047
	v_cndmask_b32_e32 v1, 0x83dcd12d, v71, vcc_lo              // 000000A0B368: 02028EFF 83DCD12D
	.long 0xd72c0052                                           // 000000A0B370: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 000000A0B374: 0202A4FF 83DCD12D
	v_bfe_u32 v81, v76, 8, 16                                  // 000000A0B37C: D6100051 0241114C
	.long 0xd72c0050                                           // 000000A0B384: D72C0050
	v_cndmask_b32_e32 v1, 0x83dcd12d, v80, vcc_lo              // 000000A0B388: 0202A0FF 83DCD12D
	v_and_b32_e32 v74, 0xffff, v74                             // 000000A0B390: 369494FF 0000FFFF
	v_sad_u8 v79, v79, 0, 0x6400                               // 000000A0B398: D622004F 03FD014F 00006400
	v_bfe_u32 v76, v76, 4, 16                                  // 000000A0B3A4: D610004C 0241094C
	v_sad_u8 v73, v73, 0, 0x6400                               // 000000A0B3AC: D6220049 03FD0149 00006400
	v_dot2acc_f32_f16 v55, v78, v36                            // 000000A0B3B8: 046E494E
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A0B3BC: BF870004
	v_lshl_or_b32 v74, v79, 16, v74                            // 000000A0B3C0: D656004A 0529214F
	.long 0xd72c004f                                           // 000000A0B3C8: D72C004F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v81, vcc_lo              // 000000A0B3CC: 0202A2FF 83DCD12D
	.long 0xd72c004c                                           // 000000A0B3D4: D72C004C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v76, vcc_lo              // 000000A0B3D8: 020298FF 83DCD12D
	v_sad_u8 v80, v80, 0, 0x6400                               // 000000A0B3E0: D6220050 03FD0150 00006400
	v_sad_u8 v81, v71, 0, 0x6400                               // 000000A0B3EC: D6220051 03FD0147 00006400
	v_lshlrev_b32_e32 v83, 16, v73                             // 000000A0B3F8: 30A69290
	v_sad_u8 v71, v82, 0, 0x6400                               // 000000A0B3FC: D6220047 03FD0152 00006400
	v_mov_b32_e32 v73, v75                                     // 000000A0B408: 7E92034B
	v_and_b32_e32 v75, 0xffff, v80                             // 000000A0B40C: 3696A0FF 0000FFFF
	v_sad_u8 v79, v79, 0, 0x6400                               // 000000A0B414: D622004F 03FD014F 00006400
	v_sad_u8 v76, v76, 0, 0x6400                               // 000000A0B420: D622004C 03FD014C 00006400
	v_lshlrev_b32_e32 v80, 16, v71                             // 000000A0B42C: 30A08E90
	.long 0xd73d0047                                           // 000000A0B430: D73D0047
	v_cndmask_b32_e32 v1, v62, v72, vcc_lo                     // 000000A0B434: 0202913E
	v_pk_fma_f16 v73, v74, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0B438: CC0E0049 0BFC0B4A 0000C931
	v_lshl_or_b32 v74, v79, 16, v75                            // 000000A0B444: D656004A 052D214F
	v_and_or_b32 v72, 0xffff, v81, v83                         // 000000A0B44C: D6570048 054EA2FF 0000FFFF
	v_and_or_b32 v75, 0xffff, v76, v80                         // 000000A0B458: D657004B 054298FF 0000FFFF
	v_bfe_u32 v80, v77, 8, 16                                  // 000000A0B464: D6100050 0241114D
	v_bfe_u32 v76, v71, 12, 16                                 // 000000A0B46C: D610004C 02411947
	v_dot2acc_f32_f16 v54, v73, v33                            // 000000A0B474: 046C4349
	v_pk_fma_f16 v78, v74, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0B478: CC0E004E 0BFC0B4A 0000C931
	v_bfe_u32 v74, v71, 8, 16                                  // 000000A0B484: D610004A 02411147
	v_pk_fma_f16 v72, v72, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0B48C: CC0E0048 0BFC0B48 0000C931
	.long 0xd72c0049                                           // 000000A0B498: D72C0049
	v_cndmask_b32_e32 v1, 0x83dcd12d, v76, vcc_lo              // 000000A0B49C: 020298FF 83DCD12D
	v_pk_fma_f16 v79, v75, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0B4A4: CC0E004F 0BFC0B4B 0000C931
	v_bfe_u32 v75, v71, 4, 16                                  // 000000A0B4B0: D610004B 02410947
	v_and_b32_e32 v71, 0xffff, v71                             // 000000A0B4B8: 368E8EFF 0000FFFF
	.long 0xd72c004a                                           // 000000A0B4C0: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 000000A0B4C4: 020294FF 83DCD12D
	v_dot2acc_f32_f16 v54, v72, v34                            // 000000A0B4CC: 046C4548
	v_bfe_u32 v76, v77, 12, 16                                 // 000000A0B4D0: D610004C 0241194D
	v_bfe_u32 v81, v77, 4, 16                                  // 000000A0B4D8: D6100051 0241094D
	v_sad_u8 v73, v73, 0, 0x6400                               // 000000A0B4E0: D6220049 03FD0149 00006400
	.long 0xd72c0052                                           // 000000A0B4EC: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v71, vcc_lo              // 000000A0B4F0: 02028EFF 83DCD12D
	ds_load_2addr_b32 v[71:72], v67 offset0:192 offset1:224    // 000000A0B4F8: D8DCE0C0 47000043
	v_and_b32_e32 v77, 0xffff, v77                             // 000000A0B500: 369A9AFF 0000FFFF
	v_sad_u8 v83, v74, 0, 0x6400                               // 000000A0B508: D6220053 03FD014A 00006400
	v_and_b32_e32 v73, 0xffff, v73                             // 000000A0B514: 369292FF 0000FFFF
	.long 0xd72c0054                                           // 000000A0B51C: D72C0054
	v_cndmask_b32_e32 v1, 0x83dcd12d, v75, vcc_lo              // 000000A0B520: 020296FF 83DCD12D
	ds_load_2addr_b32 v[74:75], v66 offset0:192 offset1:224    // 000000A0B528: D8DCE0C0 4A000042
	.long 0xd72c004d                                           // 000000A0B530: D72C004D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v77, vcc_lo              // 000000A0B534: 02029AFF 83DCD12D
	.long 0xd72c004c                                           // 000000A0B53C: D72C004C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v76, vcc_lo              // 000000A0B540: 020298FF 83DCD12D
	v_lshl_or_b32 v83, v83, 16, v73                            // 000000A0B548: D6560053 05252153
	v_sad_u8 v73, v82, 0, 0x6400                               // 000000A0B550: D6220049 03FD0152 00006400
	.long 0xd72c0050                                           // 000000A0B55C: D72C0050
	v_cndmask_b32_e32 v1, 0x83dcd12d, v80, vcc_lo              // 000000A0B560: 0202A0FF 83DCD12D
	.long 0xd72c0051                                           // 000000A0B568: D72C0051
	v_cndmask_b32_e32 v1, 0x83dcd12d, v81, vcc_lo              // 000000A0B56C: 0202A2FF 83DCD12D
	v_sad_u8 v84, v84, 0, 0x6400                               // 000000A0B574: D6220054 03FD0154 00006400
	v_pk_fma_f16 v83, v83, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0B580: CC0E0053 0BFC0B53 0000C931
	v_lshlrev_b32_e32 v85, 16, v73                             // 000000A0B58C: 30AA9290
	v_sad_u8 v73, v77, 0, 0x6400                               // 000000A0B590: D6220049 03FD014D 00006400
	v_sad_u8 v82, v76, 0, 0x6400                               // 000000A0B59C: D6220052 03FD014C 00006400
	ds_load_2addr_b32 v[76:77], v64 offset0:192 offset1:224    // 000000A0B5A8: D8DCE0C0 4C000040
	v_sad_u8 v80, v80, 0, 0x6400                               // 000000A0B5B0: D6220050 03FD0150 00006400
	v_sad_u8 v81, v81, 0, 0x6400                               // 000000A0B5BC: D6220051 03FD0151 00006400
	s_waitcnt lgkmcnt(2)                                       // 000000A0B5C8: BF89FC27
	v_dual_mov_b32 v73, v71 :: v_dual_lshlrev_b32 v86, 16, v73 // 000000A0B5CC: CA220147 49569290
	v_and_b32_e32 v82, 0xffff, v82                             // 000000A0B5D4: 36A4A4FF 0000FFFF
	v_and_or_b32 v71, 0xffff, v84, v85                         // 000000A0B5DC: D6570047 0556A8FF 0000FFFF
	v_dot2acc_f32_f16 v53, v83, v33                            // 000000A0B5E8: 046A4353
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A0B5EC: BF870004
	v_and_or_b32 v81, 0xffff, v81, v86                         // 000000A0B5F0: D6570051 055AA2FF 0000FFFF
	s_waitcnt lgkmcnt(1)                                       // 000000A0B5FC: BF89FC17
	.long 0xd73d0049                                           // 000000A0B600: D73D0049
	v_cndmask_b32_e32 v1, v62, v73, vcc_lo                     // 000000A0B604: 0202933E
	v_lshl_or_b32 v80, v80, 16, v82                            // 000000A0B608: D6560050 05492150
	v_pk_fma_f16 v71, v71, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0B610: CC0E0047 0BFC0B47 0000C931
	v_dot2acc_f32_f16 v54, v78, v35                            // 000000A0B61C: 046C474E
	v_pk_fma_f16 v78, v81, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0B620: CC0E004E 0BFC0B51 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000A0B62C: BF870224
	v_pk_fma_f16 v74, v80, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0B630: CC0E004A 0BFC0B50 0000C931
	v_bfe_u32 v80, v73, 12, 16                                 // 000000A0B63C: D6100050 02411949
	v_dual_dot2acc_f32_f16 v54, v79, v36 :: v_dual_and_b32 v81, 0xffff, v73// 000000A0B644: CB24494F 365092FF 0000FFFF
	s_waitcnt lgkmcnt(0)                                       // 000000A0B650: BF89FC07
	v_bfe_u32 v82, v76, 12, 16                                 // 000000A0B654: D6100052 0241194C
	s_delay_alu instid0(VALU_DEP_3)                            // 000000A0B65C: BF870003
	.long 0xd72c0050                                           // 000000A0B660: D72C0050
	v_cndmask_b32_e32 v1, 0x83dcd12d, v80, vcc_lo              // 000000A0B664: 0202A0FF 83DCD12D
	v_bfe_u32 v83, v76, 8, 16                                  // 000000A0B66C: D6100053 0241114C
	.long 0xd72c0051                                           // 000000A0B674: D72C0051
	v_cndmask_b32_e32 v1, 0x83dcd12d, v81, vcc_lo              // 000000A0B678: 0202A2FF 83DCD12D
	v_bfe_u32 v84, v76, 4, 16                                  // 000000A0B680: D6100054 0241094C
	.long 0xd72c0052                                           // 000000A0B688: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 000000A0B68C: 0202A4FF 83DCD12D
	v_and_b32_e32 v76, 0xffff, v76                             // 000000A0B694: 369898FF 0000FFFF
	.long 0xd72c0053                                           // 000000A0B69C: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v83, vcc_lo              // 000000A0B6A0: 0202A6FF 83DCD12D
	v_sad_u8 v80, v80, 0, 0x6400                               // 000000A0B6A8: D6220050 03FD0150 00006400
	v_dot2acc_f32_f16 v53, v71, v34                            // 000000A0B6B4: 046A4547
	v_bfe_u32 v71, v73, 8, 16                                  // 000000A0B6B8: D6100047 02411149
	v_bfe_u32 v73, v73, 4, 16                                  // 000000A0B6C0: D6100049 02410949
	v_sad_u8 v81, v81, 0, 0x6400                               // 000000A0B6C8: D6220051 03FD0151 00006400
	v_sad_u8 v82, v82, 0, 0x6400                               // 000000A0B6D4: D6220052 03FD0152 00006400
	v_sad_u8 v83, v83, 0, 0x6400                               // 000000A0B6E0: D6220053 03FD0153 00006400
	.long 0xd72c0047                                           // 000000A0B6EC: D72C0047
	v_cndmask_b32_e32 v1, 0x83dcd12d, v71, vcc_lo              // 000000A0B6F0: 02028EFF 83DCD12D
	.long 0xd72c0049                                           // 000000A0B6F8: D72C0049
	v_cndmask_b32_e32 v1, 0x83dcd12d, v73, vcc_lo              // 000000A0B6FC: 020292FF 83DCD12D
	v_lshlrev_b32_e32 v81, 16, v81                             // 000000A0B704: 30A2A290
	v_and_b32_e32 v82, 0xffff, v82                             // 000000A0B708: 36A4A4FF 0000FFFF
	v_and_b32_e32 v80, 0xffff, v80                             // 000000A0B710: 36A0A0FF 0000FFFF
	v_sad_u8 v71, v71, 0, 0x6400                               // 000000A0B718: D6220047 03FD0147 00006400
	v_sad_u8 v85, v73, 0, 0x6400                               // 000000A0B724: D6220055 03FD0149 00006400
	v_mov_b32_e32 v73, v75                                     // 000000A0B730: 7E92034B
	.long 0xd72c004b                                           // 000000A0B734: D72C004B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v76, vcc_lo              // 000000A0B738: 020298FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A0B740: BF870214
	v_lshl_or_b32 v80, v71, 16, v80                            // 000000A0B744: D6560050 05412147
	v_and_or_b32 v76, 0xffff, v85, v81                         // 000000A0B74C: D657004C 0546AAFF 0000FFFF
	v_lshl_or_b32 v81, v83, 16, v82                            // 000000A0B758: D6560051 05492153
	.long 0xd72c0052                                           // 000000A0B760: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v84, vcc_lo              // 000000A0B764: 0202A8FF 83DCD12D
	.long 0xd73d0047                                           // 000000A0B76C: D73D0047
	v_cndmask_b32_e32 v1, v62, v72, vcc_lo                     // 000000A0B770: 0202913E
	v_pk_fma_f16 v73, v80, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0B774: CC0E0049 0BFC0B50 0000C931
	v_sad_u8 v72, v75, 0, 0x6400                               // 000000A0B780: D6220048 03FD014B 00006400
	v_dot2acc_f32_f16 v53, v74, v35                            // 000000A0B78C: 046A474A
	v_pk_fma_f16 v80, v76, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0B790: CC0E0050 0BFC0B4C 0000C931
	v_bfe_u32 v84, v77, 8, 16                                  // 000000A0B79C: D6100054 0241114D
	v_bfe_u32 v74, v71, 12, 16                                 // 000000A0B7A4: D610004A 02411947
	v_sad_u8 v75, v82, 0, 0x6400                               // 000000A0B7AC: D622004B 03FD0152 00006400
	v_lshlrev_b32_e32 v72, 16, v72                             // 000000A0B7B8: 30909090
	v_and_b32_e32 v76, 0xffff, v71                             // 000000A0B7BC: 36988EFF 0000FFFF
	v_bfe_u32 v82, v71, 8, 16                                  // 000000A0B7C4: D6100052 02411147
	v_bfe_u32 v71, v71, 4, 16                                  // 000000A0B7CC: D6100047 02410947
	.long 0xd72c004a                                           // 000000A0B7D4: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 000000A0B7D8: 020294FF 83DCD12D
	v_and_or_b32 v83, 0xffff, v75, v72                         // 000000A0B7E0: D6570053 052296FF 0000FFFF
	v_bfe_u32 v72, v77, 12, 16                                 // 000000A0B7EC: D6100048 0241194D
	.long 0xd72c004b                                           // 000000A0B7F4: D72C004B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 000000A0B7F8: 0202A4FF 83DCD12D
	.long 0xd72c0052                                           // 000000A0B800: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v71, vcc_lo              // 000000A0B804: 02028EFF 83DCD12D
	v_dot2acc_f32_f16 v52, v73, v33                            // 000000A0B80C: 04684349
	v_and_b32_e32 v85, 0xffff, v77                             // 000000A0B810: 36AA9AFF 0000FFFF
	.long 0xd72c0056                                           // 000000A0B818: D72C0056
	v_cndmask_b32_e32 v1, 0x83dcd12d, v72, vcc_lo              // 000000A0B81C: 020290FF 83DCD12D
	ds_load_2addr_b32 v[71:72], v69 offset1:32                 // 000000A0B824: D8DC2000 47000045
	v_sad_u8 v74, v74, 0, 0x6400                               // 000000A0B82C: D622004A 03FD014A 00006400
	v_bfe_u32 v77, v77, 4, 16                                  // 000000A0B838: D610004D 0241094D
	v_sad_u8 v88, v75, 0, 0x6400                               // 000000A0B840: D6220058 03FD014B 00006400
	.long 0xd72c0054                                           // 000000A0B84C: D72C0054
	v_cndmask_b32_e32 v1, 0x83dcd12d, v84, vcc_lo              // 000000A0B850: 0202A8FF 83DCD12D
	v_sad_u8 v82, v82, 0, 0x6400                               // 000000A0B858: D6220052 03FD0152 00006400
	v_and_b32_e32 v87, 0xffff, v74                             // 000000A0B864: 36AE94FF 0000FFFF
	ds_load_2addr_b32 v[74:75], v68 offset1:32                 // 000000A0B86C: D8DC2000 4A000044
	v_sad_u8 v86, v86, 0, 0x6400                               // 000000A0B874: D6220056 03FD0156 00006400
	.long 0xd72c0055                                           // 000000A0B880: D72C0055
	v_cndmask_b32_e32 v1, 0x83dcd12d, v85, vcc_lo              // 000000A0B884: 0202AAFF 83DCD12D
	.long 0xd72c004d                                           // 000000A0B88C: D72C004D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v77, vcc_lo              // 000000A0B890: 02029AFF 83DCD12D
	v_lshl_or_b32 v87, v88, 16, v87                            // 000000A0B898: D6560057 055D2158
	v_sad_u8 v84, v84, 0, 0x6400                               // 000000A0B8A0: D6220054 03FD0154 00006400
	v_pk_fma_f16 v81, v81, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0B8AC: CC0E0051 0BFC0B51 0000C931
	v_dot2acc_f32_f16 v52, v80, v34                            // 000000A0B8B8: 04684550
	v_pk_fma_f16 v80, v83, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0B8BC: CC0E0050 0BFC0B53 0000C931
	v_sad_u8 v85, v85, 0, 0x6400                               // 000000A0B8C8: D6220055 03FD0155 00006400
	s_waitcnt lgkmcnt(1)                                       // 000000A0B8D4: BF89FC17
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000A0B8D8: BF8701B3
	v_dual_dot2acc_f32_f16 v52, v81, v35 :: v_dual_mov_b32 v73, v71// 000000A0B8DC: CB104751 34480147
	.long 0xd72c004c                                           // 000000A0B8E4: D72C004C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v76, vcc_lo              // 000000A0B8E8: 020298FF 83DCD12D
	v_sad_u8 v71, v77, 0, 0x6400                               // 000000A0B8F0: D6220047 03FD014D 00006400
	v_dot2acc_f32_f16 v52, v80, v36                            // 000000A0B8FC: 04684950
	s_waitcnt lgkmcnt(0)                                       // 000000A0B900: BF89FC07
	.long 0xd73d0049                                           // 000000A0B904: D73D0049
	v_cndmask_b32_e32 v1, v62, v73, vcc_lo                     // 000000A0B908: 0202933E
	v_dot2acc_f32_f16 v53, v78, v36                            // 000000A0B90C: 046A494E
	v_sad_u8 v76, v76, 0, 0x6400                               // 000000A0B910: D622004C 03FD014C 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A0B91C: BF870113
	v_and_b32_e32 v78, 0xffff, v73                             // 000000A0B920: 369C92FF 0000FFFF
	v_lshlrev_b32_e32 v76, 16, v76                             // 000000A0B928: 30989890
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A0B92C: BF870112
	.long 0xd72c004e                                           // 000000A0B930: D72C004E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 000000A0B934: 02029CFF 83DCD12D
	v_and_or_b32 v76, 0xffff, v82, v76                         // 000000A0B93C: D657004C 0532A4FF 0000FFFF
	v_and_b32_e32 v82, 0xffff, v86                             // 000000A0B948: 36A4ACFF 0000FFFF
	v_pk_fma_f16 v86, v87, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0B950: CC0E0056 0BFC0B57 0000C931
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_3)// 000000A0B95C: BF8701D3
	v_pk_fma_f16 v87, v76, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0B960: CC0E0057 0BFC0B4C 0000C931
	ds_load_2addr_b32 v[76:77], v65 offset1:32                 // 000000A0B96C: D8DC2000 4C000041
	v_lshl_or_b32 v82, v84, 16, v82                            // 000000A0B974: D6560052 05492154
	v_dot2acc_f32_f16 v51, v86, v33                            // 000000A0B97C: 04664356
	v_lshlrev_b32_e32 v84, 16, v85                             // 000000A0B980: 30A8AA90
	v_pk_fma_f16 v74, v82, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0B984: CC0E004A 0BFC0B52 0000C931
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000A0B990: BF870223
	v_dot2acc_f32_f16 v51, v87, v34                            // 000000A0B994: 04664557
	v_bfe_u32 v82, v73, 12, 16                                 // 000000A0B998: D6100052 02411949
	v_and_or_b32 v71, 0xffff, v71, v84                         // 000000A0B9A0: D6570047 05528EFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A0B9AC: BF870193
	v_dot2acc_f32_f16 v51, v74, v35                            // 000000A0B9B0: 0466474A
	.long 0xd72c004a                                           // 000000A0B9B4: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 000000A0B9B8: 0202A4FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000A0B9C0: BF8701B3
	v_pk_fma_f16 v71, v71, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0B9C4: CC0E0047 0BFC0B47 0000C931
	s_waitcnt lgkmcnt(0)                                       // 000000A0B9D0: BF89FC07
	v_bfe_u32 v79, v76, 12, 16                                 // 000000A0B9D4: D610004F 0241194C
	v_sad_u8 v74, v74, 0, 0x6400                               // 000000A0B9DC: D622004A 03FD014A 00006400
	s_delay_alu instid0(VALU_DEP_3)                            // 000000A0B9E8: BF870003
	v_dot2acc_f32_f16 v51, v71, v36                            // 000000A0B9EC: 04664947
	v_bfe_u32 v71, v73, 8, 16                                  // 000000A0B9F0: D6100047 02411149
	v_bfe_u32 v73, v73, 4, 16                                  // 000000A0B9F8: D6100049 02410949
	.long 0xd72c004f                                           // 000000A0BA00: D72C004F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v79, vcc_lo              // 000000A0BA04: 02029EFF 83DCD12D
	v_bfe_u32 v80, v76, 8, 16                                  // 000000A0BA0C: D6100050 0241114C
	v_bfe_u32 v81, v76, 4, 16                                  // 000000A0BA14: D6100051 0241094C
	.long 0xd72c0047                                           // 000000A0BA1C: D72C0047
	v_cndmask_b32_e32 v1, 0x83dcd12d, v71, vcc_lo              // 000000A0BA20: 02028EFF 83DCD12D
	v_and_b32_e32 v76, 0xffff, v76                             // 000000A0BA28: 369898FF 0000FFFF
	.long 0xd72c0052                                           // 000000A0BA30: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v73, vcc_lo              // 000000A0BA34: 020292FF 83DCD12D
	v_mov_b32_e32 v73, v75                                     // 000000A0BA3C: 7E92034B
	.long 0xd72c0051                                           // 000000A0BA40: D72C0051
	v_cndmask_b32_e32 v1, 0x83dcd12d, v81, vcc_lo              // 000000A0BA44: 0202A2FF 83DCD12D
	v_and_b32_e32 v74, 0xffff, v74                             // 000000A0BA4C: 369494FF 0000FFFF
	.long 0xd72c004b                                           // 000000A0BA54: D72C004B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v76, vcc_lo              // 000000A0BA58: 020298FF 83DCD12D
	v_bfe_u32 v85, v77, 4, 16                                  // 000000A0BA60: D6100055 0241094D
	v_sad_u8 v83, v71, 0, 0x6400                               // 000000A0BA68: D6220053 03FD0147 00006400
	v_sad_u8 v71, v78, 0, 0x6400                               // 000000A0BA74: D6220047 03FD014E 00006400
	v_sad_u8 v78, v79, 0, 0x6400                               // 000000A0BA80: D622004E 03FD014F 00006400
	.long 0xd72c004f                                           // 000000A0BA8C: D72C004F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v80, vcc_lo              // 000000A0BA90: 0202A0FF 83DCD12D
	v_sad_u8 v76, v82, 0, 0x6400                               // 000000A0BA98: D622004C 03FD0152 00006400
	v_lshl_or_b32 v74, v83, 16, v74                            // 000000A0BAA4: D656004A 05292153
	v_lshlrev_b32_e32 v80, 16, v71                             // 000000A0BAAC: 30A08E90
	.long 0xd73d0047                                           // 000000A0BAB0: D73D0047
	v_cndmask_b32_e32 v1, v62, v72, vcc_lo                     // 000000A0BAB4: 0202913E
	v_and_b32_e32 v72, 0xffff, v78                             // 000000A0BAB8: 36909CFF 0000FFFF
	v_sad_u8 v75, v75, 0, 0x6400                               // 000000A0BAC0: D622004B 03FD014B 00006400
	v_pk_fma_f16 v74, v74, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0BACC: CC0E004A 0BFC0B4A 0000C931
	v_sad_u8 v73, v79, 0, 0x6400                               // 000000A0BAD8: D6220049 03FD014F 00006400
	v_and_or_b32 v76, 0xffff, v76, v80                         // 000000A0BAE4: D657004C 054298FF 0000FFFF
	v_bfe_u32 v78, v71, 12, 16                                 // 000000A0BAF0: D610004E 02411947
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A0BAF8: BF870214
	v_dual_dot2acc_f32_f16 v50, v74, v33 :: v_dual_lshlrev_b32 v75, 16, v75// 000000A0BAFC: CB22434A 324A9690
	v_lshl_or_b32 v72, v73, 16, v72                            // 000000A0BB04: D6560048 05212149
	v_sad_u8 v73, v81, 0, 0x6400                               // 000000A0BB0C: D6220049 03FD0151 00006400
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A0BB18: BF870004
	.long 0xd72c004e                                           // 000000A0BB1C: D72C004E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 000000A0BB20: 02029CFF 83DCD12D
	v_pk_fma_f16 v79, v76, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0BB28: CC0E004F 0BFC0B4C 0000C931
	v_bfe_u32 v74, v71, 4, 16                                  // 000000A0BB34: D610004A 02410947
	v_pk_fma_f16 v80, v72, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0BB3C: CC0E0050 0BFC0B48 0000C931
	v_bfe_u32 v72, v71, 8, 16                                  // 000000A0BB48: D6100048 02411147
	v_and_or_b32 v81, 0xffff, v73, v75                         // 000000A0BB50: D6570051 052E92FF 0000FFFF
	v_and_b32_e32 v73, 0xffff, v71                             // 000000A0BB5C: 36928EFF 0000FFFF
	.long 0xd72c0054                                           // 000000A0BB64: D72C0054
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 000000A0BB68: 020294FF 83DCD12D
	v_sad_u8 v75, v78, 0, 0x6400                               // 000000A0BB70: D622004B 03FD014E 00006400
	.long 0xd72c004c                                           // 000000A0BB7C: D72C004C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v72, vcc_lo              // 000000A0BB80: 020290FF 83DCD12D
	ds_load_2addr_b32 v[71:72], v69 offset0:64 offset1:96      // 000000A0BB88: D8DC6040 47000045
	.long 0xd72c0049                                           // 000000A0BB90: D72C0049
	v_cndmask_b32_e32 v1, 0x83dcd12d, v73, vcc_lo              // 000000A0BB94: 020292FF 83DCD12D
	v_bfe_u32 v78, v77, 12, 16                                 // 000000A0BB9C: D610004E 0241194D
	v_and_b32_e32 v83, 0xffff, v75                             // 000000A0BBA4: 36A696FF 0000FFFF
	ds_load_2addr_b32 v[74:75], v68 offset0:64 offset1:96      // 000000A0BBAC: D8DC6040 4A000044
	v_bfe_u32 v82, v77, 8, 16                                  // 000000A0BBB4: D6100052 0241114D
	v_and_b32_e32 v77, 0xffff, v77                             // 000000A0BBBC: 369A9AFF 0000FFFF
	v_sad_u8 v76, v76, 0, 0x6400                               // 000000A0BBC4: D622004C 03FD014C 00006400
	.long 0xd72c004e                                           // 000000A0BBD0: D72C004E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 000000A0BBD4: 02029CFF 83DCD12D
	v_sad_u8 v73, v73, 0, 0x6400                               // 000000A0BBDC: D6220049 03FD0149 00006400
	.long 0xd72c0052                                           // 000000A0BBE8: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 000000A0BBEC: 0202A4FF 83DCD12D
	.long 0xd72c004d                                           // 000000A0BBF4: D72C004D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v77, vcc_lo              // 000000A0BBF8: 02029AFF 83DCD12D
	v_lshl_or_b32 v76, v76, 16, v83                            // 000000A0BC00: D656004C 054D214C
	v_sad_u8 v83, v84, 0, 0x6400                               // 000000A0BC08: D6220053 03FD0154 00006400
	v_dual_dot2acc_f32_f16 v50, v79, v34 :: v_dual_lshlrev_b32 v73, 16, v73// 000000A0BC14: CB22454F 32489290
	v_sad_u8 v78, v78, 0, 0x6400                               // 000000A0BC1C: D622004E 03FD014E 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000A0BC28: BF870224
	v_pk_fma_f16 v84, v76, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0BC2C: CC0E0054 0BFC0B4C 0000C931
	v_pk_fma_f16 v81, v81, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0BC38: CC0E0051 0BFC0B51 0000C931
	v_and_or_b32 v76, 0xffff, v83, v73                         // 000000A0BC44: D657004C 0526A6FF 0000FFFF
	s_waitcnt lgkmcnt(1)                                       // 000000A0BC50: BF89FC17
	v_mov_b32_e32 v73, v71                                     // 000000A0BC54: 7E920347
	.long 0xd72c0053                                           // 000000A0BC58: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v85, vcc_lo              // 000000A0BC5C: 0202AAFF 83DCD12D
	v_and_b32_e32 v71, 0xffff, v78                             // 000000A0BC64: 368E9CFF 0000FFFF
	v_sad_u8 v78, v82, 0, 0x6400                               // 000000A0BC6C: D622004E 03FD0152 00006400
	v_sad_u8 v85, v77, 0, 0x6400                               // 000000A0BC78: D6220055 03FD014D 00006400
	s_waitcnt lgkmcnt(0)                                       // 000000A0BC84: BF89FC07
	.long 0xd73d0049                                           // 000000A0BC88: D73D0049
	v_cndmask_b32_e32 v1, v62, v73, vcc_lo                     // 000000A0BC8C: 0202933E
	v_pk_fma_f16 v82, v76, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0BC90: CC0E0052 0BFC0B4C 0000C931
	ds_load_2addr_b32 v[76:77], v65 offset0:64 offset1:96      // 000000A0BC9C: D8DC6040 4C000041
	v_lshl_or_b32 v71, v78, 16, v71                            // 000000A0BCA4: D6560047 051D214E
	v_sad_u8 v74, v83, 0, 0x6400                               // 000000A0BCAC: D622004A 03FD0153 00006400
	v_dot2acc_f32_f16 v49, v84, v33                            // 000000A0BCB8: 04624354
	v_lshlrev_b32_e32 v78, 16, v85                             // 000000A0BCBC: 309CAA90
	v_bfe_u32 v83, v73, 12, 16                                 // 000000A0BCC0: D6100053 02411949
	v_pk_fma_f16 v71, v71, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0BCC8: CC0E0047 0BFC0B47 0000C931
	v_bfe_u32 v79, v73, 8, 16                                  // 000000A0BCD4: D610004F 02411149
	v_dot2acc_f32_f16 v49, v82, v34                            // 000000A0BCDC: 04624552
	v_and_or_b32 v74, 0xffff, v74, v78                         // 000000A0BCE0: D657004A 053A94FF 0000FFFF
	.long 0xd72c004e                                           // 000000A0BCEC: D72C004E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v83, vcc_lo              // 000000A0BCF0: 0202A6FF 83DCD12D
	v_dot2acc_f32_f16 v50, v80, v35                            // 000000A0BCF8: 04644750
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A0BCFC: BF870113
	v_pk_fma_f16 v74, v74, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0BD00: CC0E004A 0BFC0B4A 0000C931
	v_dot2acc_f32_f16 v50, v81, v36                            // 000000A0BD0C: 04644951
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A0BD10: BF870004
	v_sad_u8 v78, v78, 0, 0x6400                               // 000000A0BD14: D622004E 03FD014E 00006400
	v_dot2acc_f32_f16 v49, v71, v35                            // 000000A0BD20: 04624747
	.long 0xd72c0047                                           // 000000A0BD24: D72C0047
	v_cndmask_b32_e32 v1, 0x83dcd12d, v79, vcc_lo              // 000000A0BD28: 02029EFF 83DCD12D
	v_and_b32_e32 v79, 0xffff, v73                             // 000000A0BD30: 369E92FF 0000FFFF
	v_bfe_u32 v73, v73, 4, 16                                  // 000000A0BD38: D6100049 02410949
	s_waitcnt lgkmcnt(0)                                       // 000000A0BD40: BF89FC07
	v_bfe_u32 v80, v76, 12, 16                                 // 000000A0BD44: D6100050 0241194C
	v_and_b32_e32 v78, 0xffff, v78                             // 000000A0BD4C: 369C9CFF 0000FFFF
	v_bfe_u32 v82, v76, 8, 16                                  // 000000A0BD54: D6100052 0241114C
	.long 0xd72c004f                                           // 000000A0BD5C: D72C004F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v79, vcc_lo              // 000000A0BD60: 02029EFF 83DCD12D
	.long 0xd72c0049                                           // 000000A0BD68: D72C0049
	v_cndmask_b32_e32 v1, 0x83dcd12d, v73, vcc_lo              // 000000A0BD6C: 020292FF 83DCD12D
	v_sad_u8 v71, v71, 0, 0x6400                               // 000000A0BD74: D6220047 03FD0147 00006400
	.long 0xd72c0050                                           // 000000A0BD80: D72C0050
	v_cndmask_b32_e32 v1, 0x83dcd12d, v80, vcc_lo              // 000000A0BD84: 0202A0FF 83DCD12D
	v_and_b32_e32 v83, 0xffff, v76                             // 000000A0BD8C: 36A698FF 0000FFFF
	v_bfe_u32 v76, v76, 4, 16                                  // 000000A0BD94: D610004C 0241094C
	v_dot2acc_f32_f16 v49, v74, v36                            // 000000A0BD9C: 0462494A
	v_lshl_or_b32 v78, v71, 16, v78                            // 000000A0BDA0: D656004E 05392147
	v_sad_u8 v71, v79, 0, 0x6400                               // 000000A0BDA8: D6220047 03FD014F 00006400
	.long 0xd72c004f                                           // 000000A0BDB4: D72C004F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 000000A0BDB8: 0202A4FF 83DCD12D
	.long 0xd72c0052                                           // 000000A0BDC0: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v83, vcc_lo              // 000000A0BDC4: 0202A6FF 83DCD12D
	v_sad_u8 v83, v73, 0, 0x6400                               // 000000A0BDCC: D6220053 03FD0149 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000A0BDD8: BF8701B4
	v_dual_mov_b32 v73, v75 :: v_dual_lshlrev_b32 v84, 16, v71 // 000000A0BDDC: CA22014B 49548E90
	v_sad_u8 v80, v80, 0, 0x6400                               // 000000A0BDE4: D6220050 03FD0150 00006400
	.long 0xd72c004b                                           // 000000A0BDF0: D72C004B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v76, vcc_lo              // 000000A0BDF4: 020298FF 83DCD12D
	.long 0xd73d0047                                           // 000000A0BDFC: D73D0047
	v_cndmask_b32_e32 v1, v62, v72, vcc_lo                     // 000000A0BE00: 0202913E
	v_sad_u8 v79, v79, 0, 0x6400                               // 000000A0BE04: D622004F 03FD014F 00006400
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A0BE10: BF870004
	v_and_b32_e32 v76, 0xffff, v80                             // 000000A0BE14: 3698A0FF 0000FFFF
	v_sad_u8 v80, v82, 0, 0x6400                               // 000000A0BE1C: D6220050 03FD0152 00006400
	v_pk_fma_f16 v72, v78, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0BE28: CC0E0048 0BFC0B4E 0000C931
	v_and_or_b32 v73, 0xffff, v83, v84                         // 000000A0BE34: D6570049 0552A6FF 0000FFFF
	v_sad_u8 v75, v75, 0, 0x6400                               // 000000A0BE40: D622004B 03FD014B 00006400
	v_lshl_or_b32 v76, v79, 16, v76                            // 000000A0BE4C: D656004C 0531214F
	v_bfe_u32 v79, v71, 12, 16                                 // 000000A0BE54: D610004F 02411947
	v_lshlrev_b32_e32 v78, 16, v80                             // 000000A0BE5C: 309CA090
	v_pk_fma_f16 v73, v73, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0BE60: CC0E0049 0BFC0B49 0000C931
	v_dot2acc_f32_f16 v48, v72, v33                            // 000000A0BE6C: 04604348
	v_pk_fma_f16 v72, v76, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0BE70: CC0E0048 0BFC0B4C 0000C931
	.long 0xd72c004c                                           // 000000A0BE7C: D72C004C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v79, vcc_lo              // 000000A0BE80: 02029EFF 83DCD12D
	v_and_or_b32 v75, 0xffff, v75, v78                         // 000000A0BE88: D657004B 053A96FF 0000FFFF
	v_bfe_u32 v78, v71, 8, 16                                  // 000000A0BE94: D610004E 02411147
	v_dot2acc_f32_f16 v48, v73, v34                            // 000000A0BE9C: 04604549
	v_bfe_u32 v83, v77, 8, 16                                  // 000000A0BEA0: D6100053 0241114D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A0BEA8: BF870214
	v_pk_fma_f16 v79, v75, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0BEAC: CC0E004F 0BFC0B4B 0000C931
	.long 0xd72c0049                                           // 000000A0BEB8: D72C0049
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 000000A0BEBC: 02029CFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A0BEC4: BF870004
	v_dot2acc_f32_f16 v48, v72, v35                            // 000000A0BEC8: 04604748
	v_sad_u8 v74, v76, 0, 0x6400                               // 000000A0BECC: D622004A 03FD014C 00006400
	v_bfe_u32 v76, v71, 4, 16                                  // 000000A0BED8: D610004C 02410947
	v_and_b32_e32 v75, 0xffff, v71                             // 000000A0BEE0: 36968EFF 0000FFFF
	ds_load_2addr_b32 v[71:72], v69 offset0:128 offset1:160    // 000000A0BEE8: D8DCA080 47000045
	v_bfe_u32 v78, v77, 12, 16                                 // 000000A0BEF0: D610004E 0241194D
	v_and_b32_e32 v80, 0xffff, v74                             // 000000A0BEF8: 36A094FF 0000FFFF
	v_sad_u8 v73, v73, 0, 0x6400                               // 000000A0BF00: D6220049 03FD0149 00006400
	.long 0xd72c0051                                           // 000000A0BF0C: D72C0051
	v_cndmask_b32_e32 v1, 0x83dcd12d, v75, vcc_lo              // 000000A0BF10: 020296FF 83DCD12D
	ds_load_2addr_b32 v[74:75], v68 offset0:128 offset1:160    // 000000A0BF18: D8DCA080 4A000044
	v_and_b32_e32 v82, 0xffff, v77                             // 000000A0BF20: 36A49AFF 0000FFFF
	.long 0xd72c004c                                           // 000000A0BF28: D72C004C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v76, vcc_lo              // 000000A0BF2C: 020298FF 83DCD12D
	v_lshl_or_b32 v80, v73, 16, v80                            // 000000A0BF34: D6560050 05412149
	v_dot2acc_f32_f16 v48, v79, v36                            // 000000A0BF3C: 0460494F
	.long 0xd72c004e                                           // 000000A0BF40: D72C004E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 000000A0BF44: 02029CFF 83DCD12D
	.long 0xd72c0049                                           // 000000A0BF4C: D72C0049
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 000000A0BF50: 0202A4FF 83DCD12D
	v_sad_u8 v81, v81, 0, 0x6400                               // 000000A0BF58: D6220051 03FD0151 00006400
	v_pk_fma_f16 v79, v80, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0BF64: CC0E004F 0BFC0B50 0000C931
	.long 0xd72c0052                                           // 000000A0BF70: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v83, vcc_lo              // 000000A0BF74: 0202A6FF 83DCD12D
	v_sad_u8 v84, v76, 0, 0x6400                               // 000000A0BF7C: D6220054 03FD014C 00006400
	v_bfe_u32 v77, v77, 4, 16                                  // 000000A0BF88: D610004D 0241094D
	v_lshlrev_b32_e32 v81, 16, v81                             // 000000A0BF90: 30A2A290
	v_sad_u8 v78, v78, 0, 0x6400                               // 000000A0BF94: D622004E 03FD014E 00006400
	v_sad_u8 v85, v73, 0, 0x6400                               // 000000A0BFA0: D6220055 03FD0149 00006400
	s_waitcnt lgkmcnt(1)                                       // 000000A0BFAC: BF89FC17
	v_mov_b32_e32 v73, v71                                     // 000000A0BFB0: 7E920347
	v_dot2acc_f32_f16 v47, v79, v33                            // 000000A0BFB4: 045E434F
	.long 0xd72c0053                                           // 000000A0BFB8: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v77, vcc_lo              // 000000A0BFBC: 02029AFF 83DCD12D
	ds_load_2addr_b32 v[76:77], v65 offset0:128 offset1:160    // 000000A0BFC4: D8DCA080 4C000041
	v_sad_u8 v71, v82, 0, 0x6400                               // 000000A0BFCC: D6220047 03FD0152 00006400
	s_waitcnt lgkmcnt(1)                                       // 000000A0BFD8: BF89FC17
	.long 0xd73d0049                                           // 000000A0BFDC: D73D0049
	v_cndmask_b32_e32 v1, v62, v73, vcc_lo                     // 000000A0BFE0: 0202933E
	v_and_or_b32 v74, 0xffff, v84, v81                         // 000000A0BFE4: D657004A 0546A8FF 0000FFFF
	v_sad_u8 v82, v83, 0, 0x6400                               // 000000A0BFF0: D6220052 03FD0153 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A0BFFC: BF870193
	v_bfe_u32 v80, v73, 12, 16                                 // 000000A0C000: D6100050 02411949
	v_pk_fma_f16 v74, v74, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0C008: CC0E004A 0BFC0B4A 0000C931
	v_lshlrev_b32_e32 v83, 16, v85                             // 000000A0C014: 30A6AA90
	v_bfe_u32 v79, v73, 8, 16                                  // 000000A0C018: D610004F 02411149
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A0C020: BF870214
	.long 0xd72c0050                                           // 000000A0C024: D72C0050
	v_cndmask_b32_e32 v1, 0x83dcd12d, v80, vcc_lo              // 000000A0C028: 0202A0FF 83DCD12D
	v_dot2acc_f32_f16 v47, v74, v34                            // 000000A0C030: 045E454A
	v_and_b32_e32 v78, 0xffff, v78                             // 000000A0C034: 369C9CFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A0C03C: BF870114
	.long 0xd72c004f                                           // 000000A0C040: D72C004F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v79, vcc_lo              // 000000A0C044: 02029EFF 83DCD12D
	v_lshl_or_b32 v71, v71, 16, v78                            // 000000A0C04C: D6560047 05392147
	v_sad_u8 v80, v80, 0, 0x6400                               // 000000A0C054: D6220050 03FD0150 00006400
	v_and_or_b32 v78, 0xffff, v82, v83                         // 000000A0C060: D657004E 054EA4FF 0000FFFF
	s_waitcnt lgkmcnt(0)                                       // 000000A0C06C: BF89FC07
	v_bfe_u32 v82, v76, 12, 16                                 // 000000A0C070: D6100052 0241194C
	v_bfe_u32 v83, v76, 8, 16                                  // 000000A0C078: D6100053 0241114C
	v_pk_fma_f16 v81, v71, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0C080: CC0E0051 0BFC0B47 0000C931
	v_and_b32_e32 v80, 0xffff, v80                             // 000000A0C08C: 36A0A0FF 0000FFFF
	v_and_b32_e32 v71, 0xffff, v73                             // 000000A0C094: 368E92FF 0000FFFF
	v_bfe_u32 v73, v73, 4, 16                                  // 000000A0C09C: D6100049 02410949
	v_bfe_u32 v84, v76, 4, 16                                  // 000000A0C0A4: D6100054 0241094C
	v_and_b32_e32 v76, 0xffff, v76                             // 000000A0C0AC: 369898FF 0000FFFF
	.long 0xd72c0052                                           // 000000A0C0B4: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 000000A0C0B8: 0202A4FF 83DCD12D
	.long 0xd72c0047                                           // 000000A0C0C0: D72C0047
	v_cndmask_b32_e32 v1, 0x83dcd12d, v71, vcc_lo              // 000000A0C0C4: 02028EFF 83DCD12D
	.long 0xd72c0049                                           // 000000A0C0CC: D72C0049
	v_cndmask_b32_e32 v1, 0x83dcd12d, v73, vcc_lo              // 000000A0C0D0: 020292FF 83DCD12D
	v_sad_u8 v79, v79, 0, 0x6400                               // 000000A0C0D8: D622004F 03FD014F 00006400
	.long 0xd72c004c                                           // 000000A0C0E4: D72C004C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v76, vcc_lo              // 000000A0C0E8: 020298FF 83DCD12D
	.long 0xd72c0053                                           // 000000A0C0F0: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v83, vcc_lo              // 000000A0C0F4: 0202A6FF 83DCD12D
	.long 0xd72c0054                                           // 000000A0C0FC: D72C0054
	v_cndmask_b32_e32 v1, 0x83dcd12d, v84, vcc_lo              // 000000A0C100: 0202A8FF 83DCD12D
	v_dot2acc_f32_f16 v47, v81, v35                            // 000000A0C108: 045E4751
	v_lshl_or_b32 v79, v79, 16, v80                            // 000000A0C10C: D656004F 0541214F
	v_sad_u8 v71, v71, 0, 0x6400                               // 000000A0C114: D6220047 03FD0147 00006400
	v_sad_u8 v73, v73, 0, 0x6400                               // 000000A0C120: D6220049 03FD0149 00006400
	v_sad_u8 v82, v82, 0, 0x6400                               // 000000A0C12C: D6220052 03FD0152 00006400
	v_bfe_u32 v81, v77, 4, 16                                  // 000000A0C138: D6100051 0241094D
	v_pk_fma_f16 v78, v78, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0C140: CC0E004E 0BFC0B4E 0000C931
	v_lshlrev_b32_e32 v71, 16, v71                             // 000000A0C14C: 308E8E90
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A0C150: BF870193
	.long 0xd72c0051                                           // 000000A0C154: D72C0051
	v_cndmask_b32_e32 v1, 0x83dcd12d, v81, vcc_lo              // 000000A0C158: 0202A2FF 83DCD12D
	v_dot2acc_f32_f16 v47, v78, v36                            // 000000A0C160: 045E494E
	s_delay_alu instid0(VALU_DEP_3)                            // 000000A0C164: BF870003
	v_and_or_b32 v80, 0xffff, v73, v71                         // 000000A0C168: D6570050 051E92FF 0000FFFF
	v_sad_u8 v71, v76, 0, 0x6400                               // 000000A0C174: D6220047 03FD014C 00006400
	v_mov_b32_e32 v73, v75                                     // 000000A0C180: 7E92034B
	v_sad_u8 v76, v83, 0, 0x6400                               // 000000A0C184: D622004C 03FD0153 00006400
	v_and_b32_e32 v75, 0xffff, v82                             // 000000A0C190: 3696A4FF 0000FFFF
	v_sad_u8 v82, v84, 0, 0x6400                               // 000000A0C198: D6220052 03FD0154 00006400
	v_lshlrev_b32_e32 v83, 16, v71                             // 000000A0C1A4: 30A68E90
	.long 0xd73d0047                                           // 000000A0C1A8: D73D0047
	v_cndmask_b32_e32 v1, v62, v72, vcc_lo                     // 000000A0C1AC: 0202913E
	v_pk_fma_f16 v72, v79, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0C1B0: CC0E0048 0BFC0B4F 0000C931
	v_lshl_or_b32 v74, v76, 16, v75                            // 000000A0C1BC: D656004A 052D214C
	v_pk_fma_f16 v73, v80, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0C1C4: CC0E0049 0BFC0B50 0000C931
	v_and_or_b32 v75, 0xffff, v82, v83                         // 000000A0C1D0: D657004B 054EA4FF 0000FFFF
	v_sad_u8 v81, v81, 0, 0x6400                               // 000000A0C1DC: D6220051 03FD0151 00006400
	v_bfe_u32 v76, v71, 12, 16                                 // 000000A0C1E8: D610004C 02411947
	v_dot2acc_f32_f16 v46, v72, v33                            // 000000A0C1F0: 045C4348
	v_pk_fma_f16 v79, v74, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0C1F4: CC0E004F 0BFC0B4A 0000C931
	v_bfe_u32 v74, v71, 4, 16                                  // 000000A0C200: D610004A 02410947
	v_pk_fma_f16 v80, v75, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0C208: CC0E0050 0BFC0B4B 0000C931
	.long 0xd72c0048                                           // 000000A0C214: D72C0048
	v_cndmask_b32_e32 v1, 0x83dcd12d, v76, vcc_lo              // 000000A0C218: 020298FF 83DCD12D
	v_dot2acc_f32_f16 v46, v73, v34                            // 000000A0C220: 045C4549
	v_bfe_u32 v73, v71, 8, 16                                  // 000000A0C224: D6100049 02411147
	v_and_b32_e32 v71, 0xffff, v71                             // 000000A0C22C: 368E8EFF 0000FFFF
	v_bfe_u32 v75, v77, 12, 16                                 // 000000A0C234: D610004B 0241194D
	v_bfe_u32 v76, v77, 8, 16                                  // 000000A0C23C: D610004C 0241114D
	v_and_b32_e32 v77, 0xffff, v77                             // 000000A0C244: 369A9AFF 0000FFFF
	.long 0xd72c0049                                           // 000000A0C24C: D72C0049
	v_cndmask_b32_e32 v1, 0x83dcd12d, v73, vcc_lo              // 000000A0C250: 020292FF 83DCD12D
	v_sad_u8 v82, v72, 0, 0x6400                               // 000000A0C258: D6220052 03FD0148 00006400
	.long 0xd72c0053                                           // 000000A0C264: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v71, vcc_lo              // 000000A0C268: 02028EFF 83DCD12D
	ds_load_2addr_b32 v[71:72], v69 offset0:192 offset1:224    // 000000A0C270: D8DCE0C0 47000045
	.long 0xd72c0054                                           // 000000A0C278: D72C0054
	v_cndmask_b32_e32 v1, 0x83dcd12d, v75, vcc_lo              // 000000A0C27C: 020296FF 83DCD12D
	.long 0xd72c0055                                           // 000000A0C284: D72C0055
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 000000A0C288: 020294FF 83DCD12D
	ds_load_2addr_b32 v[74:75], v68 offset0:192 offset1:224    // 000000A0C290: D8DCE0C0 4A000044
	.long 0xd72c004d                                           // 000000A0C298: D72C004D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v77, vcc_lo              // 000000A0C29C: 02029AFF 83DCD12D
	v_sad_u8 v86, v73, 0, 0x6400                               // 000000A0C2A4: D6220056 03FD0149 00006400
	v_and_b32_e32 v82, 0xffff, v82                             // 000000A0C2B0: 36A4A4FF 0000FFFF
	v_sad_u8 v73, v83, 0, 0x6400                               // 000000A0C2B8: D6220049 03FD0153 00006400
	.long 0xd72c0053                                           // 000000A0C2C4: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v76, vcc_lo              // 000000A0C2C8: 020298FF 83DCD12D
	v_sad_u8 v84, v84, 0, 0x6400                               // 000000A0C2D0: D6220054 03FD0154 00006400
	v_sad_u8 v85, v85, 0, 0x6400                               // 000000A0C2DC: D6220055 03FD0155 00006400
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A0C2E8: BF870004
	v_dual_dot2acc_f32_f16 v46, v79, v35 :: v_dual_lshlrev_b32 v87, 16, v73// 000000A0C2EC: CB22474F 2E569290
	v_sad_u8 v73, v77, 0, 0x6400                               // 000000A0C2F4: D6220049 03FD014D 00006400
	ds_load_2addr_b32 v[76:77], v65 offset0:192 offset1:224    // 000000A0C300: D8DCE0C0 4C000041
	v_and_b32_e32 v84, 0xffff, v84                             // 000000A0C308: 36A8A8FF 0000FFFF
	v_sad_u8 v83, v83, 0, 0x6400                               // 000000A0C310: D6220053 03FD0153 00006400
	v_dot2acc_f32_f16 v46, v80, v36                            // 000000A0C31C: 045C4950
	v_lshlrev_b32_e32 v88, 16, v73                             // 000000A0C320: 30B09290
	s_waitcnt lgkmcnt(2)                                       // 000000A0C324: BF89FC27
	v_mov_b32_e32 v73, v71                                     // 000000A0C328: 7E920347
	v_lshl_or_b32 v71, v86, 16, v82                            // 000000A0C32C: D6560047 05492156
	v_and_or_b32 v82, 0xffff, v85, v87                         // 000000A0C334: D6570052 055EAAFF 0000FFFF
	v_lshl_or_b32 v83, v83, 16, v84                            // 000000A0C340: D6560053 05512153
	s_waitcnt lgkmcnt(1)                                       // 000000A0C348: BF89FC17
	.long 0xd73d0049                                           // 000000A0C34C: D73D0049
	v_cndmask_b32_e32 v1, v62, v73, vcc_lo                     // 000000A0C350: 0202933E
	v_pk_fma_f16 v71, v71, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0C354: CC0E0047 0BFC0B47 0000C931
	v_pk_fma_f16 v74, v82, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0C360: CC0E004A 0BFC0B52 0000C931
	v_pk_fma_f16 v79, v83, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0C36C: CC0E004F 0BFC0B53 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A0C378: BF870214
	v_bfe_u32 v82, v73, 12, 16                                 // 000000A0C37C: D6100052 02411949
	v_dot2acc_f32_f16 v45, v71, v33                            // 000000A0C384: 045A4347
	v_and_b32_e32 v71, 0xffff, v73                             // 000000A0C388: 368E92FF 0000FFFF
	v_bfe_u32 v83, v73, 8, 16                                  // 000000A0C390: D6100053 02411149
	v_bfe_u32 v73, v73, 4, 16                                  // 000000A0C398: D6100049 02410949
	.long 0xd72c0052                                           // 000000A0C3A0: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 000000A0C3A4: 0202A4FF 83DCD12D
	s_waitcnt lgkmcnt(0)                                       // 000000A0C3AC: BF89FC07
	v_bfe_u32 v84, v76, 12, 16                                 // 000000A0C3B0: D6100054 0241194C
	.long 0xd72c0047                                           // 000000A0C3B8: D72C0047
	v_cndmask_b32_e32 v1, 0x83dcd12d, v71, vcc_lo              // 000000A0C3BC: 02028EFF 83DCD12D
	.long 0xd72c0053                                           // 000000A0C3C4: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v83, vcc_lo              // 000000A0C3C8: 0202A6FF 83DCD12D
	.long 0xd72c0049                                           // 000000A0C3D0: D72C0049
	v_cndmask_b32_e32 v1, 0x83dcd12d, v73, vcc_lo              // 000000A0C3D4: 020292FF 83DCD12D
	v_bfe_u32 v85, v76, 8, 16                                  // 000000A0C3DC: D6100055 0241114C
	.long 0xd72c0054                                           // 000000A0C3E4: D72C0054
	v_cndmask_b32_e32 v1, 0x83dcd12d, v84, vcc_lo              // 000000A0C3E8: 0202A8FF 83DCD12D
	v_bfe_u32 v86, v76, 4, 16                                  // 000000A0C3F0: D6100056 0241094C
	v_sad_u8 v82, v82, 0, 0x6400                               // 000000A0C3F8: D6220052 03FD0152 00006400
	v_dot2acc_f32_f16 v45, v74, v34                            // 000000A0C404: 045A454A
	v_sad_u8 v71, v71, 0, 0x6400                               // 000000A0C408: D6220047 03FD0147 00006400
	.long 0xd72c0055                                           // 000000A0C414: D72C0055
	v_cndmask_b32_e32 v1, 0x83dcd12d, v85, vcc_lo              // 000000A0C418: 0202AAFF 83DCD12D
	v_sad_u8 v83, v83, 0, 0x6400                               // 000000A0C420: D6220053 03FD0153 00006400
	v_and_b32_e32 v82, 0xffff, v82                             // 000000A0C42C: 36A4A4FF 0000FFFF
	v_sad_u8 v87, v73, 0, 0x6400                               // 000000A0C434: D6220057 03FD0149 00006400
	v_lshlrev_b32_e32 v71, 16, v71                             // 000000A0C440: 308E8E90
	v_mov_b32_e32 v73, v75                                     // 000000A0C444: 7E92034B
	v_sad_u8 v84, v84, 0, 0x6400                               // 000000A0C448: D6220054 03FD0154 00006400
	v_lshl_or_b32 v82, v83, 16, v82                            // 000000A0C454: D6560052 05492153
	v_dual_dot2acc_f32_f16 v45, v79, v35 :: v_dual_and_b32 v76, 0xffff, v76// 000000A0C45C: CB24474F 2D4C98FF 0000FFFF
	v_and_or_b32 v83, 0xffff, v87, v71                         // 000000A0C468: D6570053 051EAEFF 0000FFFF
	.long 0xd73d0047                                           // 000000A0C474: D73D0047
	v_cndmask_b32_e32 v1, v62, v72, vcc_lo                     // 000000A0C478: 0202913E
	v_and_b32_e32 v84, 0xffff, v84                             // 000000A0C47C: 36A8A8FF 0000FFFF
	v_sad_u8 v75, v85, 0, 0x6400                               // 000000A0C484: D622004B 03FD0155 00006400
	.long 0xd72c0049                                           // 000000A0C490: D72C0049
	v_cndmask_b32_e32 v1, 0x83dcd12d, v76, vcc_lo              // 000000A0C494: 020298FF 83DCD12D
	.long 0xd72c0055                                           // 000000A0C49C: D72C0055
	v_cndmask_b32_e32 v1, 0x83dcd12d, v86, vcc_lo              // 000000A0C4A0: 0202ACFF 83DCD12D
	v_pk_fma_f16 v74, v82, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0C4A8: CC0E004A 0BFC0B52 0000C931
	v_bfe_u32 v76, v71, 12, 16                                 // 000000A0C4B4: D610004C 02411947
	v_lshl_or_b32 v72, v75, 16, v84                            // 000000A0C4BC: D6560048 0551214B
	v_pk_fma_f16 v75, v83, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0C4C4: CC0E004B 0BFC0B53 0000C931
	v_and_b32_e32 v83, 0xffff, v71                             // 000000A0C4D0: 36A68EFF 0000FFFF
	v_bfe_u32 v84, v71, 8, 16                                  // 000000A0C4D8: D6100054 02411147
	.long 0xd72c004c                                           // 000000A0C4E0: D72C004C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v76, vcc_lo              // 000000A0C4E4: 020298FF 83DCD12D
	v_bfe_u32 v71, v71, 4, 16                                  // 000000A0C4EC: D6100047 02410947
	v_sad_u8 v82, v85, 0, 0x6400                               // 000000A0C4F4: D6220052 03FD0155 00006400
	.long 0xd72c0053                                           // 000000A0C500: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v83, vcc_lo              // 000000A0C504: 0202A6FF 83DCD12D
	v_bfe_u32 v85, v77, 12, 16                                 // 000000A0C50C: D6100055 0241194D
	.long 0xd72c0054                                           // 000000A0C514: D72C0054
	v_cndmask_b32_e32 v1, 0x83dcd12d, v84, vcc_lo              // 000000A0C518: 0202A8FF 83DCD12D
	.long 0xd72c0047                                           // 000000A0C520: D72C0047
	v_cndmask_b32_e32 v1, 0x83dcd12d, v71, vcc_lo              // 000000A0C524: 02028EFF 83DCD12D
	v_bfe_u32 v86, v77, 8, 16                                  // 000000A0C52C: D6100056 0241114D
	v_sad_u8 v76, v76, 0, 0x6400                               // 000000A0C534: D622004C 03FD014C 00006400
	v_bfe_u32 v87, v77, 4, 16                                  // 000000A0C540: D6100057 0241094D
	.long 0xd72c0055                                           // 000000A0C548: D72C0055
	v_cndmask_b32_e32 v1, 0x83dcd12d, v85, vcc_lo              // 000000A0C54C: 0202AAFF 83DCD12D
	v_sad_u8 v83, v83, 0, 0x6400                               // 000000A0C554: D6220053 03FD0153 00006400
	v_and_b32_e32 v77, 0xffff, v77                             // 000000A0C560: 369A9AFF 0000FFFF
	v_and_b32_e32 v76, 0xffff, v76                             // 000000A0C568: 369898FF 0000FFFF
	v_sad_u8 v84, v84, 0, 0x6400                               // 000000A0C570: D6220054 03FD0154 00006400
	v_sad_u8 v71, v71, 0, 0x6400                               // 000000A0C57C: D6220047 03FD0147 00006400
	v_lshlrev_b32_e32 v83, 16, v83                             // 000000A0C588: 30A6A690
	.long 0xd72c0056                                           // 000000A0C58C: D72C0056
	v_cndmask_b32_e32 v1, 0x83dcd12d, v86, vcc_lo              // 000000A0C590: 0202ACFF 83DCD12D
	.long 0xd72c004d                                           // 000000A0C598: D72C004D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v77, vcc_lo              // 000000A0C59C: 02029AFF 83DCD12D
	v_and_or_b32 v81, 0xffff, v81, v88                         // 000000A0C5A4: D6570051 0562A2FF 0000FFFF
	v_sad_u8 v85, v85, 0, 0x6400                               // 000000A0C5B0: D6220055 03FD0155 00006400
	v_lshl_or_b32 v76, v84, 16, v76                            // 000000A0C5BC: D656004C 05312154
	v_and_or_b32 v71, 0xffff, v71, v83                         // 000000A0C5C4: D6570047 054E8EFF 0000FFFF
	.long 0xd72c0053                                           // 000000A0C5D0: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v87, vcc_lo              // 000000A0C5D4: 0202AEFF 83DCD12D
	v_pk_fma_f16 v81, v81, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0C5DC: CC0E0051 0BFC0B51 0000C931
	v_sad_u8 v73, v73, 0, 0x6400                               // 000000A0C5E8: D6220049 03FD0149 00006400
	v_and_b32_e32 v84, 0xffff, v85                             // 000000A0C5F4: 36A8AAFF 0000FFFF
	v_sad_u8 v85, v86, 0, 0x6400                               // 000000A0C5FC: D6220055 03FD0156 00006400
	v_dot2acc_f32_f16 v44, v74, v33                            // 000000A0C608: 0458434A
	v_sad_u8 v74, v77, 0, 0x6400                               // 000000A0C60C: D622004A 03FD014D 00006400
	v_pk_fma_f16 v76, v76, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0C618: CC0E004C 0BFC0B4C 0000C931
	v_lshlrev_b32_e32 v73, 16, v73                             // 000000A0C624: 30929290
	v_pk_fma_f16 v71, v71, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0C628: CC0E0047 0BFC0B47 0000C931
	v_sad_u8 v83, v83, 0, 0x6400                               // 000000A0C634: D6220053 03FD0153 00006400
	v_lshlrev_b32_e32 v74, 16, v74                             // 000000A0C640: 30949490
	v_dual_dot2acc_f32_f16 v58, v76, v33 :: v_dual_dot2acc_f32_f16 v45, v81, v36// 000000A0C644: CB18434C 3A2C4951
	v_lshl_or_b32 v77, v85, 16, v84                            // 000000A0C64C: D656004D 05512155
	v_pk_fma_f16 v72, v72, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0C654: CC0E0048 0BFC0B48 0000C931
	v_and_or_b32 v33, 0xffff, v82, v73                         // 000000A0C660: D6570021 0526A4FF 0000FFFF
	v_dot2acc_f32_f16 v44, v75, v34                            // 000000A0C66C: 0458454B
	v_and_or_b32 v74, 0xffff, v83, v74                         // 000000A0C670: D657004A 052AA6FF 0000FFFF
	v_pk_fma_f16 v73, v77, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0C67C: CC0E0049 0BFC0B4D 0000C931
	v_dot2acc_f32_f16 v58, v71, v34                            // 000000A0C688: 04744547
	v_pk_fma_f16 v33, v33, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0C68C: CC0E0021 0BFC0B21 0000C931
	v_dot2acc_f32_f16 v44, v72, v35                            // 000000A0C698: 04584748
	v_pk_fma_f16 v34, v74, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0C69C: CC0E0022 0BFC0B4A 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A0C6A8: BF870194
	v_dot2acc_f32_f16 v58, v73, v35                            // 000000A0C6AC: 04744749
	v_dot2acc_f32_f16 v44, v33, v36                            // 000000A0C6B0: 04584921
	s_delay_alu instid0(VALU_DEP_2)                            // 000000A0C6B4: BF870002
	v_dot2acc_f32_f16 v58, v34, v36                            // 000000A0C6B8: 04744922
	s_or_b32 exec_lo, exec_lo, s6                              // 000000A0C6BC: 8C7E067E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000A0C6C0: BF870009
	s_and_b32 s0, exec_lo, vcc_lo                              // 000000A0C6C4: 8B006A7E
	.long 0xd7006a26                                           // 000000A0C6C8: D7006A26
	v_cndmask_b32_e32 v1, 0x1000, v38, vcc_lo                  // 000000A0C6CC: 02024CFF 00001000
	v_add_nc_u32_e32 v63, 64, v63                              // 000000A0C6D4: 4A7E7EC0
	v_add_co_ci_u32_e64 v39, null, 0, v39, vcc_lo              // 000000A0C6D8: D5207C27 01AA4E80
	v_mov_b32_e32 v71, v70                                     // 000000A0C6E0: 7E8E0346
	s_or_b32 s4, s0, s4                                        // 000000A0C6E4: 8C040400
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000A0C6E8: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000A0C6EC: 917E047E
	s_cbranch_execz 1831                                       // 000000A0C6F0: BFA50727 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi3EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x6690>
	s_delay_alu instid0(VALU_DEP_1)                            // 000000A0C6F4: BF870001
	v_add_nc_u32_e32 v70, 2, v71                               // 000000A0C6F8: 4A8C8E82
	s_mov_b32 s6, exec_lo                                      // 000000A0C6FC: BE86007E
	s_waitcnt vmcnt(14)                                        // 000000A0C700: BF893BF7
	ds_store_2addr_b32 v64, v17, v18 offset1:32                // 000000A0C704: D8382000 00121140
	s_waitcnt vmcnt(12)                                        // 000000A0C70C: BF8933F7
	ds_store_2addr_b32 v64, v19, v20 offset0:64 offset1:96     // 000000A0C710: D8386040 00141340
	s_waitcnt vmcnt(10)                                        // 000000A0C718: BF892BF7
	ds_store_2addr_b32 v64, v21, v22 offset0:128 offset1:160   // 000000A0C71C: D838A080 00161540
	s_waitcnt vmcnt(8)                                         // 000000A0C724: BF8923F7
	ds_store_2addr_b32 v64, v23, v24 offset0:192 offset1:224   // 000000A0C728: D838E0C0 00181740
	s_waitcnt vmcnt(6)                                         // 000000A0C730: BF891BF7
	ds_store_2addr_b32 v65, v25, v26 offset1:32                // 000000A0C734: D8382000 001A1941
	s_waitcnt vmcnt(4)                                         // 000000A0C73C: BF8913F7
	ds_store_2addr_b32 v65, v27, v28 offset0:64 offset1:96     // 000000A0C740: D8386040 001C1B41
	s_waitcnt vmcnt(2)                                         // 000000A0C748: BF890BF7
	ds_store_2addr_b32 v65, v29, v30 offset0:128 offset1:160   // 000000A0C74C: D838A080 001E1D41
	s_waitcnt vmcnt(0)                                         // 000000A0C754: BF8903F7
	ds_store_2addr_b32 v65, v31, v32 offset0:192 offset1:224   // 000000A0C758: D838E0C0 00201F41
	v_cmp_ge_u32_e32 vcc_lo, v70, v43                          // 000000A0C760: 7C9C5746
	.long 0xd4c9007e                                           // 000000A0C764: D4C9007E
	v_cndmask_b32_e32 v1, v70, v43, vcc_lo                     // 000000A0C768: 02025746
	s_cbranch_execz 33                                         // 000000A0C76C: BFA50021 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi3EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x4af4>
	s_clause 0xf                                               // 000000A0C770: BF85000F
	global_load_b32 v17, v[38:39], off offset:-1024            // 000000A0C774: DC521C00 117C0026
	global_load_b32 v18, v[38:39], off offset:-896             // 000000A0C77C: DC521C80 127C0026
	global_load_b32 v19, v[38:39], off offset:-768             // 000000A0C784: DC521D00 137C0026
	global_load_b32 v20, v[38:39], off offset:-640             // 000000A0C78C: DC521D80 147C0026
	global_load_b32 v21, v[38:39], off offset:-512             // 000000A0C794: DC521E00 157C0026
	global_load_b32 v22, v[38:39], off offset:-384             // 000000A0C79C: DC521E80 167C0026
	global_load_b32 v23, v[38:39], off offset:-256             // 000000A0C7A4: DC521F00 177C0026
	global_load_b32 v24, v[38:39], off offset:-128             // 000000A0C7AC: DC521F80 187C0026
	global_load_b32 v25, v[38:39], off                         // 000000A0C7B4: DC520000 197C0026
	global_load_b32 v26, v[38:39], off offset:128              // 000000A0C7BC: DC520080 1A7C0026
	global_load_b32 v27, v[38:39], off offset:256              // 000000A0C7C4: DC520100 1B7C0026
	global_load_b32 v28, v[38:39], off offset:384              // 000000A0C7CC: DC520180 1C7C0026
	global_load_b32 v29, v[38:39], off offset:512              // 000000A0C7D4: DC520200 1D7C0026
	global_load_b32 v30, v[38:39], off offset:640              // 000000A0C7DC: DC520280 1E7C0026
	global_load_b32 v31, v[38:39], off offset:768              // 000000A0C7E4: DC520300 1F7C0026
	global_load_b32 v32, v[38:39], off offset:896              // 000000A0C7EC: DC520380 207C0026
	s_or_b32 exec_lo, exec_lo, s6                              // 000000A0C7F4: 8C7E067E
	ds_load_2addr_b32 v[72:73], v67 offset1:32                 // 000000A0C7F8: D8DC2000 48000043
	ds_load_2addr_b32 v[82:83], v64 offset1:32                 // 000000A0C800: D8DC2000 52000040
	ds_load_2addr_b32 v[76:77], v66 offset1:32                 // 000000A0C808: D8DC2000 4C000042
	ds_load_b128 v[33:36], v63                                 // 000000A0C810: DBFC0000 2100003F
	ds_load_2addr_b32 v[78:79], v66 offset0:64 offset1:96      // 000000A0C818: D8DC6040 4E000042
	ds_load_2addr_b32 v[80:81], v67 offset0:64 offset1:96      // 000000A0C820: D8DC6040 50000043
	s_mov_b32 s6, exec_lo                                      // 000000A0C828: BE86007E
	s_waitcnt lgkmcnt(5)                                       // 000000A0C82C: BF89FC57
	v_mov_b32_e32 v75, v72                                     // 000000A0C830: 7E960348
	s_waitcnt lgkmcnt(4)                                       // 000000A0C834: BF89FC47
	v_bfe_u32 v72, v82, 12, 16                                 // 000000A0C838: D6100048 02411952
	v_bfe_u32 v84, v82, 8, 16                                  // 000000A0C840: D6100054 02411152
	v_bfe_u32 v85, v82, 4, 16                                  // 000000A0C848: D6100055 02410952
	v_and_b32_e32 v82, 0xffff, v82                             // 000000A0C850: 36A4A4FF 0000FFFF
	s_waitcnt lgkmcnt(3)                                       // 000000A0C858: BF89FC37
	v_mov_b32_e32 v74, v77                                     // 000000A0C85C: 7E94034D
	.long 0xd73d004b                                           // 000000A0C860: D73D004B
	v_cndmask_b32_e32 v1, v62, v75, vcc_lo                     // 000000A0C864: 0202973E
	v_bfe_u32 v77, v83, 12, 16                                 // 000000A0C868: D610004D 02411953
	v_bfe_u32 v86, v83, 8, 16                                  // 000000A0C870: D6100056 02411153
	v_bfe_u32 v87, v83, 4, 16                                  // 000000A0C878: D6100057 02410953
	v_and_b32_e32 v83, 0xffff, v83                             // 000000A0C880: 36A6A6FF 0000FFFF
	.long 0xd72c004c                                           // 000000A0C888: D72C004C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v72, vcc_lo              // 000000A0C88C: 020290FF 83DCD12D
	.long 0xd73d0048                                           // 000000A0C894: D73D0048
	v_cndmask_b32_e32 v1, v62, v73, vcc_lo                     // 000000A0C898: 0202933E
	.long 0xd72c0049                                           // 000000A0C89C: D72C0049
	v_cndmask_b32_e32 v1, 0x83dcd12d, v77, vcc_lo              // 000000A0C8A0: 02029AFF 83DCD12D
	v_bfe_u32 v77, v75, 12, 16                                 // 000000A0C8A8: D610004D 0241194B
	.long 0xd72c004a                                           // 000000A0C8B0: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v83, vcc_lo              // 000000A0C8B4: 0202A6FF 83DCD12D
	v_bfe_u32 v83, v75, 8, 16                                  // 000000A0C8BC: D6100053 0241114B
	v_bfe_u32 v88, v75, 4, 16                                  // 000000A0C8C4: D6100058 0241094B
	v_and_b32_e32 v75, 0xffff, v75                             // 000000A0C8CC: 369696FF 0000FFFF
	.long 0xd72c004d                                           // 000000A0C8D4: D72C004D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v77, vcc_lo              // 000000A0C8D8: 02029AFF 83DCD12D
	v_bfe_u32 v89, v72, 12, 16                                 // 000000A0C8E0: D6100059 02411948
	.long 0xd72c0053                                           // 000000A0C8E8: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v83, vcc_lo              // 000000A0C8EC: 0202A6FF 83DCD12D
	.long 0xd72c0058                                           // 000000A0C8F4: D72C0058
	v_cndmask_b32_e32 v1, 0x83dcd12d, v88, vcc_lo              // 000000A0C8F8: 0202B0FF 83DCD12D
	.long 0xd72c004b                                           // 000000A0C900: D72C004B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v75, vcc_lo              // 000000A0C904: 020296FF 83DCD12D
	.long 0xd72c0052                                           // 000000A0C90C: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 000000A0C910: 0202A4FF 83DCD12D
	v_bfe_u32 v90, v72, 8, 16                                  // 000000A0C918: D610005A 02411148
	.long 0xd72c0059                                           // 000000A0C920: D72C0059
	v_cndmask_b32_e32 v1, 0x83dcd12d, v89, vcc_lo              // 000000A0C924: 0202B2FF 83DCD12D
	v_sad_u8 v77, v77, 0, 0x6400                               // 000000A0C92C: D622004D 03FD014D 00006400
	.long 0xd72c0054                                           // 000000A0C938: D72C0054
	v_cndmask_b32_e32 v1, 0x83dcd12d, v84, vcc_lo              // 000000A0C93C: 0202A8FF 83DCD12D
	v_sad_u8 v83, v83, 0, 0x6400                               // 000000A0C944: D6220053 03FD0153 00006400
	v_sad_u8 v88, v88, 0, 0x6400                               // 000000A0C950: D6220058 03FD0158 00006400
	v_sad_u8 v75, v75, 0, 0x6400                               // 000000A0C95C: D622004B 03FD014B 00006400
	v_and_b32_e32 v77, 0xffff, v77                             // 000000A0C968: 369A9AFF 0000FFFF
	v_bfe_u32 v91, v72, 4, 16                                  // 000000A0C970: D610005B 02410948
	.long 0xd72c0055                                           // 000000A0C978: D72C0055
	v_cndmask_b32_e32 v1, 0x83dcd12d, v85, vcc_lo              // 000000A0C97C: 0202AAFF 83DCD12D
	.long 0xd72c005a                                           // 000000A0C984: D72C005A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v90, vcc_lo              // 000000A0C988: 0202B4FF 83DCD12D
	v_lshlrev_b32_e32 v75, 16, v75                             // 000000A0C990: 30969690
	v_lshl_or_b32 v77, v83, 16, v77                            // 000000A0C994: D656004D 05352153
	v_sad_u8 v76, v76, 0, 0x6400                               // 000000A0C99C: D622004C 03FD014C 00006400
	v_sad_u8 v82, v82, 0, 0x6400                               // 000000A0C9A8: D6220052 03FD0152 00006400
	v_sad_u8 v89, v89, 0, 0x6400                               // 000000A0C9B4: D6220059 03FD0159 00006400
	v_and_or_b32 v75, 0xffff, v88, v75                         // 000000A0C9C0: D657004B 052EB0FF 0000FFFF
	v_pk_fma_f16 v77, v77, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0C9CC: CC0E004D 0BFC0B4D 0000C931
	v_and_b32_e32 v72, 0xffff, v72                             // 000000A0C9D8: 369090FF 0000FFFF
	v_sad_u8 v84, v84, 0, 0x6400                               // 000000A0C9E0: D6220054 03FD0154 00006400
	v_sad_u8 v85, v85, 0, 0x6400                               // 000000A0C9EC: D6220055 03FD0155 00006400
	v_pk_fma_f16 v75, v75, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0C9F8: CC0E004B 0BFC0B4B 0000C931
	s_waitcnt lgkmcnt(2)                                       // 000000A0CA04: BF89FC27
	v_dot2acc_f32_f16 v59, v77, v33                            // 000000A0CA08: 0476434D
	.long 0xd72c0048                                           // 000000A0CA0C: D72C0048
	v_cndmask_b32_e32 v1, 0x83dcd12d, v72, vcc_lo              // 000000A0CA10: 020290FF 83DCD12D
	v_and_b32_e32 v76, 0xffff, v76                             // 000000A0CA18: 369898FF 0000FFFF
	s_waitcnt lgkmcnt(0)                                       // 000000A0CA20: BF89FC07
	v_dual_mov_b32 v77, v80 :: v_dual_lshlrev_b32 v82, 16, v82 // 000000A0CA24: CA220150 4D52A490
	v_sad_u8 v83, v90, 0, 0x6400                               // 000000A0CA2C: D6220053 03FD015A 00006400
	v_and_b32_e32 v89, 0xffff, v89                             // 000000A0CA38: 36B2B2FF 0000FFFF
	.long 0xd72c005b                                           // 000000A0CA40: D72C005B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v91, vcc_lo              // 000000A0CA44: 0202B6FF 83DCD12D
	v_dot2acc_f32_f16 v59, v75, v34                            // 000000A0CA4C: 0476454B
	v_lshl_or_b32 v76, v84, 16, v76                            // 000000A0CA50: D656004C 05312154
	v_sad_u8 v72, v72, 0, 0x6400                               // 000000A0CA58: D6220048 03FD0148 00006400
	v_sad_u8 v73, v73, 0, 0x6400                               // 000000A0CA64: D6220049 03FD0149 00006400
	v_and_or_b32 v82, 0xffff, v85, v82                         // 000000A0CA70: D6570052 054AAAFF 0000FFFF
	v_lshl_or_b32 v83, v83, 16, v89                            // 000000A0CA7C: D6560053 05652153
	.long 0xd72c0056                                           // 000000A0CA84: D72C0056
	v_cndmask_b32_e32 v1, 0x83dcd12d, v86, vcc_lo              // 000000A0CA88: 0202ACFF 83DCD12D
	.long 0xd72c004b                                           // 000000A0CA90: D72C004B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v87, vcc_lo              // 000000A0CA94: 0202AEFF 83DCD12D
	v_pk_fma_f16 v84, v76, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0CA9C: CC0E0054 0BFC0B4C 0000C931
	v_sad_u8 v76, v91, 0, 0x6400                               // 000000A0CAA8: D622004C 03FD015B 00006400
	v_lshlrev_b32_e32 v72, 16, v72                             // 000000A0CAB4: 30909090
	v_pk_fma_f16 v85, v82, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0CAB8: CC0E0055 0BFC0B52 0000C931
	v_pk_fma_f16 v82, v83, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0CAC4: CC0E0052 0BFC0B53 0000C931
	v_and_b32_e32 v83, 0xffff, v73                             // 000000A0CAD0: 36A692FF 0000FFFF
	v_sad_u8 v87, v74, 0, 0x6400                               // 000000A0CAD8: D6220057 03FD014A 00006400
	ds_load_2addr_b32 v[73:74], v64 offset0:64 offset1:96      // 000000A0CAE4: D8DC6040 49000040
	v_sad_u8 v80, v86, 0, 0x6400                               // 000000A0CAEC: D6220050 03FD0156 00006400
	v_sad_u8 v86, v75, 0, 0x6400                               // 000000A0CAF8: D6220056 03FD014B 00006400
	v_dot2acc_f32_f16 v59, v84, v35                            // 000000A0CB04: 04764754
	v_and_or_b32 v72, 0xffff, v76, v72                         // 000000A0CB08: D6570048 052298FF 0000FFFF
	.long 0xd73d004b                                           // 000000A0CB14: D73D004B
	v_cndmask_b32_e32 v1, v62, v77, vcc_lo                     // 000000A0CB18: 02029B3E
	v_lshl_or_b32 v76, v80, 16, v83                            // 000000A0CB1C: D656004C 054D2150
	v_dot2acc_f32_f16 v57, v82, v33                            // 000000A0CB24: 04724352
	v_lshlrev_b32_e32 v87, 16, v87                             // 000000A0CB28: 30AEAE90
	v_pk_fma_f16 v72, v72, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0CB2C: CC0E0048 0BFC0B48 0000C931
	v_bfe_u32 v78, v75, 12, 16                                 // 000000A0CB38: D610004E 0241194B
	v_pk_fma_f16 v80, v76, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0CB40: CC0E0050 0BFC0B4C 0000C931
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000A0CB4C: BF870223
	v_dual_dot2acc_f32_f16 v57, v72, v34 :: v_dual_and_b32 v76, 0xffff, v75// 000000A0CB50: CB244548 394C96FF 0000FFFF
	v_and_or_b32 v77, 0xffff, v86, v87                         // 000000A0CB5C: D657004D 055EACFF 0000FFFF
	.long 0xd72c0048                                           // 000000A0CB68: D72C0048
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 000000A0CB6C: 02029CFF 83DCD12D
	v_bfe_u32 v78, v75, 8, 16                                  // 000000A0CB74: D610004E 0241114B
	v_bfe_u32 v75, v75, 4, 16                                  // 000000A0CB7C: D610004B 0241094B
	.long 0xd72c004c                                           // 000000A0CB84: D72C004C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v76, vcc_lo              // 000000A0CB88: 020298FF 83DCD12D
	s_waitcnt lgkmcnt(0)                                       // 000000A0CB90: BF89FC07
	v_bfe_u32 v82, v73, 12, 16                                 // 000000A0CB94: D6100052 02411949
	v_bfe_u32 v83, v73, 8, 16                                  // 000000A0CB9C: D6100053 02411149
	.long 0xd72c004e                                           // 000000A0CBA4: D72C004E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 000000A0CBA8: 02029CFF 83DCD12D
	.long 0xd72c004b                                           // 000000A0CBB0: D72C004B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v75, vcc_lo              // 000000A0CBB4: 020296FF 83DCD12D
	v_sad_u8 v72, v72, 0, 0x6400                               // 000000A0CBBC: D6220048 03FD0148 00006400
	.long 0xd72c0052                                           // 000000A0CBC8: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 000000A0CBCC: 0202A4FF 83DCD12D
	.long 0xd72c0053                                           // 000000A0CBD4: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v83, vcc_lo              // 000000A0CBD8: 0202A6FF 83DCD12D
	v_sad_u8 v76, v76, 0, 0x6400                               // 000000A0CBE0: D622004C 03FD014C 00006400
	v_bfe_u32 v84, v73, 4, 16                                  // 000000A0CBEC: D6100054 02410949
	v_and_b32_e32 v72, 0xffff, v72                             // 000000A0CBF4: 369090FF 0000FFFF
	v_sad_u8 v78, v78, 0, 0x6400                               // 000000A0CBFC: D622004E 03FD014E 00006400
	v_sad_u8 v75, v75, 0, 0x6400                               // 000000A0CC08: D622004B 03FD014B 00006400
	v_dual_dot2acc_f32_f16 v57, v80, v35 :: v_dual_lshlrev_b32 v76, 16, v76// 000000A0CC14: CB224750 394C9890
	v_sad_u8 v86, v82, 0, 0x6400                               // 000000A0CC1C: D6220056 03FD0152 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000A0CC28: BF870224
	v_lshl_or_b32 v72, v78, 16, v72                            // 000000A0CC2C: D6560048 0521214E
	v_dual_mov_b32 v82, v79 :: v_dual_and_b32 v73, 0xffff, v73 // 000000A0CC34: CA24014F 524892FF 0000FFFF
	v_and_or_b32 v78, 0xffff, v75, v76                         // 000000A0CC40: D657004E 053296FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A0CC4C: BF870004
	v_and_b32_e32 v79, 0xffff, v86                             // 000000A0CC50: 369EACFF 0000FFFF
	v_sad_u8 v83, v83, 0, 0x6400                               // 000000A0CC58: D6220053 03FD0153 00006400
	v_pk_fma_f16 v72, v72, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0CC64: CC0E0048 0BFC0B48 0000C931
	.long 0xd72c0049                                           // 000000A0CC70: D72C0049
	v_cndmask_b32_e32 v1, 0x83dcd12d, v73, vcc_lo              // 000000A0CC74: 020292FF 83DCD12D
	.long 0xd73d004b                                           // 000000A0CC7C: D73D004B
	v_cndmask_b32_e32 v1, v62, v81, vcc_lo                     // 000000A0CC80: 0202A33E
	v_pk_fma_f16 v76, v78, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0CC84: CC0E004C 0BFC0B4E 0000C931
	v_lshl_or_b32 v78, v83, 16, v79                            // 000000A0CC90: D656004E 053D2153
	v_dot2acc_f32_f16 v56, v72, v33                            // 000000A0CC98: 04704348
	.long 0xd72c0054                                           // 000000A0CC9C: D72C0054
	v_cndmask_b32_e32 v1, 0x83dcd12d, v84, vcc_lo              // 000000A0CCA0: 0202A8FF 83DCD12D
	v_pk_fma_f16 v77, v77, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0CCA8: CC0E004D 0BFC0B4D 0000C931
	v_bfe_u32 v72, v75, 12, 16                                 // 000000A0CCB4: D6100048 0241194B
	v_sad_u8 v73, v73, 0, 0x6400                               // 000000A0CCBC: D6220049 03FD0149 00006400
	v_pk_fma_f16 v78, v78, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0CCC8: CC0E004E 0BFC0B4E 0000C931
	v_dual_dot2acc_f32_f16 v56, v76, v34 :: v_dual_dot2acc_f32_f16 v59, v85, v36// 000000A0CCD4: CB18454C 383A4955
	v_and_b32_e32 v80, 0xffff, v75                             // 000000A0CCDC: 36A096FF 0000FFFF
	v_sad_u8 v79, v84, 0, 0x6400                               // 000000A0CCE4: D622004F 03FD0154 00006400
	.long 0xd72c004c                                           // 000000A0CCF0: D72C004C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v72, vcc_lo              // 000000A0CCF4: 020290FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A0CCFC: BF870004
	v_dual_dot2acc_f32_f16 v56, v78, v35 :: v_dual_lshlrev_b32 v73, 16, v73// 000000A0CD00: CB22474E 38489290
	v_bfe_u32 v72, v75, 8, 16                                  // 000000A0CD08: D6100048 0241114B
	v_bfe_u32 v81, v75, 4, 16                                  // 000000A0CD10: D6100051 0241094B
	v_bfe_u32 v82, v74, 12, 16                                 // 000000A0CD18: D6100052 0241194A
	.long 0xd72c0050                                           // 000000A0CD20: D72C0050
	v_cndmask_b32_e32 v1, 0x83dcd12d, v80, vcc_lo              // 000000A0CD24: 0202A0FF 83DCD12D
	v_and_or_b32 v73, 0xffff, v79, v73                         // 000000A0CD2C: D6570049 05269EFF 0000FFFF
	v_sad_u8 v78, v76, 0, 0x6400                               // 000000A0CD38: D622004E 03FD014C 00006400
	v_dot2acc_f32_f16 v57, v77, v36                            // 000000A0CD44: 0472494D
	.long 0xd72c004d                                           // 000000A0CD48: D72C004D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v72, vcc_lo              // 000000A0CD4C: 020290FF 83DCD12D
	ds_load_2addr_b32 v[75:76], v66 offset0:128 offset1:160    // 000000A0CD54: D8DCA080 4B000042
	v_pk_fma_f16 v79, v73, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0CD5C: CC0E004F 0BFC0B49 0000C931
	ds_load_2addr_b32 v[72:73], v67 offset0:128 offset1:160    // 000000A0CD68: D8DCA080 48000043
	v_and_b32_e32 v78, 0xffff, v78                             // 000000A0CD70: 369C9CFF 0000FFFF
	.long 0xd72c0052                                           // 000000A0CD78: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 000000A0CD7C: 0202A4FF 83DCD12D
	v_and_b32_e32 v84, 0xffff, v74                             // 000000A0CD84: 36A894FF 0000FFFF
	v_bfe_u32 v83, v74, 8, 16                                  // 000000A0CD8C: D6100053 0241114A
	v_sad_u8 v77, v77, 0, 0x6400                               // 000000A0CD94: D622004D 03FD014D 00006400
	v_bfe_u32 v74, v74, 4, 16                                  // 000000A0CDA0: D610004A 0241094A
	.long 0xd72c0051                                           // 000000A0CDA8: D72C0051
	v_cndmask_b32_e32 v1, 0x83dcd12d, v81, vcc_lo              // 000000A0CDAC: 0202A2FF 83DCD12D
	v_dot2acc_f32_f16 v56, v79, v36                            // 000000A0CDB4: 0470494F
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A0CDB8: BF870004
	v_lshl_or_b32 v85, v77, 16, v78                            // 000000A0CDBC: D6560055 0539214D
	.long 0xd72c004e                                           // 000000A0CDC4: D72C004E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v84, vcc_lo              // 000000A0CDC8: 0202A8FF 83DCD12D
	v_sad_u8 v77, v80, 0, 0x6400                               // 000000A0CDD0: D622004D 03FD0150 00006400
	v_sad_u8 v80, v82, 0, 0x6400                               // 000000A0CDDC: D6220050 03FD0152 00006400
	.long 0xd72c0052                                           // 000000A0CDE8: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v83, vcc_lo              // 000000A0CDEC: 0202A6FF 83DCD12D
	.long 0xd72c0053                                           // 000000A0CDF4: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 000000A0CDF8: 020294FF 83DCD12D
	v_sad_u8 v84, v78, 0, 0x6400                               // 000000A0CE00: D6220054 03FD014E 00006400
	s_waitcnt lgkmcnt(0)                                       // 000000A0CE0C: BF89FC07
	v_mov_b32_e32 v74, v72                                     // 000000A0CE10: 7E940348
	v_sad_u8 v72, v81, 0, 0x6400                               // 000000A0CE14: D6220048 03FD0151 00006400
	v_lshlrev_b32_e32 v81, 16, v77                             // 000000A0CE20: 30A29A90
	ds_load_2addr_b32 v[77:78], v64 offset0:128 offset1:160    // 000000A0CE24: D8DCA080 4D000040
	.long 0xd73d004a                                           // 000000A0CE2C: D73D004A
	v_cndmask_b32_e32 v1, v62, v74, vcc_lo                     // 000000A0CE30: 0202953E
	v_sad_u8 v75, v82, 0, 0x6400                               // 000000A0CE34: D622004B 03FD0152 00006400
	v_sad_u8 v82, v83, 0, 0x6400                               // 000000A0CE40: D6220052 03FD0153 00006400
	v_lshlrev_b32_e32 v83, 16, v84                             // 000000A0CE4C: 30A6A890
	v_and_or_b32 v72, 0xffff, v72, v81                         // 000000A0CE50: D6570048 054690FF 0000FFFF
	v_pk_fma_f16 v84, v85, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0CE5C: CC0E0054 0BFC0B55 0000C931
	v_and_b32_e32 v80, 0xffff, v80                             // 000000A0CE68: 36A0A0FF 0000FFFF
	v_bfe_u32 v81, v74, 12, 16                                 // 000000A0CE70: D6100051 0241194A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A0CE78: BF870214
	v_pk_fma_f16 v72, v72, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0CE7C: CC0E0048 0BFC0B48 0000C931
	v_dot2acc_f32_f16 v55, v84, v33                            // 000000A0CE88: 046E4354
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A0CE8C: BF870004
	v_lshl_or_b32 v75, v75, 16, v80                            // 000000A0CE90: D656004B 0541214B
	v_and_or_b32 v80, 0xffff, v82, v83                         // 000000A0CE98: D6570050 054EA4FF 0000FFFF
	.long 0xd72c0051                                           // 000000A0CEA4: D72C0051
	v_cndmask_b32_e32 v1, 0x83dcd12d, v81, vcc_lo              // 000000A0CEA8: 0202A2FF 83DCD12D
	v_bfe_u32 v82, v74, 8, 16                                  // 000000A0CEB0: D6100052 0241114A
	v_and_b32_e32 v83, 0xffff, v74                             // 000000A0CEB8: 36A694FF 0000FFFF
	v_bfe_u32 v74, v74, 4, 16                                  // 000000A0CEC0: D610004A 0241094A
	s_waitcnt lgkmcnt(0)                                       // 000000A0CEC8: BF89FC07
	v_dual_dot2acc_f32_f16 v55, v72, v34 :: v_dual_and_b32 v86, 0xffff, v77// 000000A0CECC: CB244548 37569AFF 0000FFFF
	.long 0xd72c0052                                           // 000000A0CED8: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 000000A0CEDC: 0202A4FF 83DCD12D
	.long 0xd72c0053                                           // 000000A0CEE4: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v83, vcc_lo              // 000000A0CEE8: 0202A6FF 83DCD12D
	v_sad_u8 v81, v81, 0, 0x6400                               // 000000A0CEF0: D6220051 03FD0151 00006400
	v_bfe_u32 v84, v77, 12, 16                                 // 000000A0CEFC: D6100054 0241194D
	.long 0xd72c004a                                           // 000000A0CF04: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 000000A0CF08: 020294FF 83DCD12D
	v_bfe_u32 v85, v77, 8, 16                                  // 000000A0CF10: D6100055 0241114D
	v_bfe_u32 v77, v77, 4, 16                                  // 000000A0CF18: D610004D 0241094D
	v_and_b32_e32 v81, 0xffff, v81                             // 000000A0CF20: 36A2A2FF 0000FFFF
	v_sad_u8 v82, v82, 0, 0x6400                               // 000000A0CF28: D6220052 03FD0152 00006400
	.long 0xd72c0054                                           // 000000A0CF34: D72C0054
	v_cndmask_b32_e32 v1, 0x83dcd12d, v84, vcc_lo              // 000000A0CF38: 0202A8FF 83DCD12D
	v_sad_u8 v83, v83, 0, 0x6400                               // 000000A0CF40: D6220053 03FD0153 00006400
	.long 0xd72c0055                                           // 000000A0CF4C: D72C0055
	v_cndmask_b32_e32 v1, 0x83dcd12d, v85, vcc_lo              // 000000A0CF50: 0202AAFF 83DCD12D
	v_sad_u8 v74, v74, 0, 0x6400                               // 000000A0CF58: D622004A 03FD014A 00006400
	v_lshl_or_b32 v81, v82, 16, v81                            // 000000A0CF64: D6560051 05452152
	.long 0xd72c0052                                           // 000000A0CF6C: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v86, vcc_lo              // 000000A0CF70: 0202ACFF 83DCD12D
	v_lshlrev_b32_e32 v83, 16, v83                             // 000000A0CF78: 30A6A690
	.long 0xd72c004d                                           // 000000A0CF7C: D72C004D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v77, vcc_lo              // 000000A0CF80: 02029AFF 83DCD12D
	v_sad_u8 v84, v84, 0, 0x6400                               // 000000A0CF88: D6220054 03FD0154 00006400
	v_pk_fma_f16 v81, v81, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0CF94: CC0E0051 0BFC0B51 0000C931
	v_pk_fma_f16 v75, v75, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0CFA0: CC0E004B 0BFC0B4B 0000C931
	v_and_or_b32 v72, 0xffff, v74, v83                         // 000000A0CFAC: D6570048 054E94FF 0000FFFF
	v_sad_u8 v83, v85, 0, 0x6400                               // 000000A0CFB8: D6220053 03FD0155 00006400
	v_sad_u8 v74, v82, 0, 0x6400                               // 000000A0CFC4: D622004A 03FD0152 00006400
	v_and_b32_e32 v82, 0xffff, v84                             // 000000A0CFD0: 36A4A8FF 0000FFFF
	v_dot2acc_f32_f16 v54, v81, v33                            // 000000A0CFD8: 046C4351
	v_pk_fma_f16 v84, v72, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0CFDC: CC0E0054 0BFC0B48 0000C931
	v_sad_u8 v72, v77, 0, 0x6400                               // 000000A0CFE8: D6220048 03FD014D 00006400
	v_dual_mov_b32 v74, v76 :: v_dual_lshlrev_b32 v77, 16, v74 // 000000A0CFF4: CA22014C 4A4C9490
	v_lshl_or_b32 v76, v83, 16, v82                            // 000000A0CFFC: D656004C 05492153
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A0D004: BF870194
	v_dual_dot2acc_f32_f16 v55, v75, v35 :: v_dual_dot2acc_f32_f16 v54, v84, v34// 000000A0D008: CB18474B 37364554
	v_and_or_b32 v75, 0xffff, v72, v77                         // 000000A0D010: D657004B 053690FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A0D01C: BF870214
	.long 0xd73d0048                                           // 000000A0D020: D73D0048
	v_cndmask_b32_e32 v1, v62, v73, vcc_lo                     // 000000A0D024: 0202933E
	v_pk_fma_f16 v73, v76, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0D028: CC0E0049 0BFC0B4C 0000C931
	v_pk_fma_f16 v80, v80, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0D034: CC0E0050 0BFC0B50 0000C931
	v_bfe_u32 v82, v78, 8, 16                                  // 000000A0D040: D6100052 0241114E
	v_pk_fma_f16 v79, v75, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0D048: CC0E004F 0BFC0B4B 0000C931
	v_bfe_u32 v84, v78, 4, 16                                  // 000000A0D054: D6100054 0241094E
	v_bfe_u32 v74, v72, 12, 16                                 // 000000A0D05C: D610004A 02411948
	v_dot2acc_f32_f16 v54, v73, v35                            // 000000A0D064: 046C4749
	v_bfe_u32 v75, v72, 8, 16                                  // 000000A0D068: D610004B 02411148
	v_and_b32_e32 v76, 0xffff, v72                             // 000000A0D070: 369890FF 0000FFFF
	v_bfe_u32 v77, v72, 4, 16                                  // 000000A0D078: D610004D 02410948
	ds_load_2addr_b32 v[72:73], v67 offset0:192 offset1:224    // 000000A0D080: D8DCE0C0 48000043
	.long 0xd72c004a                                           // 000000A0D088: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 000000A0D08C: 020294FF 83DCD12D
	.long 0xd72c0053                                           // 000000A0D094: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v75, vcc_lo              // 000000A0D098: 020296FF 83DCD12D
	.long 0xd72c0051                                           // 000000A0D0A0: D72C0051
	v_cndmask_b32_e32 v1, 0x83dcd12d, v76, vcc_lo              // 000000A0D0A4: 020298FF 83DCD12D
	ds_load_2addr_b32 v[75:76], v66 offset0:192 offset1:224    // 000000A0D0AC: D8DCE0C0 4B000042
	v_dot2acc_f32_f16 v55, v80, v36                            // 000000A0D0B4: 046E4950
	v_bfe_u32 v80, v78, 12, 16                                 // 000000A0D0B8: D6100050 0241194E
	v_and_b32_e32 v78, 0xffff, v78                             // 000000A0D0C0: 369C9CFF 0000FFFF
	.long 0xd72c0052                                           // 000000A0D0C8: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 000000A0D0CC: 0202A4FF 83DCD12D
	v_sad_u8 v74, v74, 0, 0x6400                               // 000000A0D0D4: D622004A 03FD014A 00006400
	v_sad_u8 v83, v83, 0, 0x6400                               // 000000A0D0E0: D6220053 03FD0153 00006400
	.long 0xd72c0050                                           // 000000A0D0EC: D72C0050
	v_cndmask_b32_e32 v1, 0x83dcd12d, v80, vcc_lo              // 000000A0D0F0: 0202A0FF 83DCD12D
	.long 0xd72c004e                                           // 000000A0D0F8: D72C004E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 000000A0D0FC: 02029CFF 83DCD12D
	.long 0xd72c0054                                           // 000000A0D104: D72C0054
	v_cndmask_b32_e32 v1, 0x83dcd12d, v84, vcc_lo              // 000000A0D108: 0202A8FF 83DCD12D
	v_dual_dot2acc_f32_f16 v54, v79, v36 :: v_dual_and_b32 v85, 0xffff, v74// 000000A0D110: CB24494F 365494FF 0000FFFF
	.long 0xd72c004d                                           // 000000A0D11C: D72C004D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v77, vcc_lo              // 000000A0D120: 02029AFF 83DCD12D
	v_sad_u8 v81, v81, 0, 0x6400                               // 000000A0D128: D6220051 03FD0151 00006400
	v_sad_u8 v80, v80, 0, 0x6400                               // 000000A0D134: D6220050 03FD0150 00006400
	s_waitcnt lgkmcnt(1)                                       // 000000A0D140: BF89FC17
	v_mov_b32_e32 v74, v72                                     // 000000A0D144: 7E940348
	v_lshl_or_b32 v72, v83, 16, v85                            // 000000A0D148: D6560048 05552153
	v_sad_u8 v83, v78, 0, 0x6400                               // 000000A0D150: D6220053 03FD014E 00006400
	v_and_b32_e32 v80, 0xffff, v80                             // 000000A0D15C: 36A0A0FF 0000FFFF
	s_waitcnt lgkmcnt(0)                                       // 000000A0D164: BF89FC07
	.long 0xd73d004a                                           // 000000A0D168: D73D004A
	v_cndmask_b32_e32 v1, v62, v74, vcc_lo                     // 000000A0D16C: 0202953E
	v_sad_u8 v75, v82, 0, 0x6400                               // 000000A0D170: D622004B 03FD0152 00006400
	v_sad_u8 v82, v84, 0, 0x6400                               // 000000A0D17C: D6220052 03FD0154 00006400
	v_lshlrev_b32_e32 v83, 16, v83                             // 000000A0D188: 30A6A690
	v_pk_fma_f16 v72, v72, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0D18C: CC0E0048 0BFC0B48 0000C931
	v_sad_u8 v77, v77, 0, 0x6400                               // 000000A0D198: D622004D 03FD014D 00006400
	v_bfe_u32 v84, v74, 12, 16                                 // 000000A0D1A4: D6100054 0241194A
	v_lshl_or_b32 v75, v75, 16, v80                            // 000000A0D1AC: D656004B 0541214B
	v_and_or_b32 v80, 0xffff, v82, v83                         // 000000A0D1B4: D6570050 054EA4FF 0000FFFF
	v_dot2acc_f32_f16 v53, v72, v33                            // 000000A0D1C0: 046A4348
	v_bfe_u32 v82, v74, 8, 16                                  // 000000A0D1C4: D6100052 0241114A
	.long 0xd72c0048                                           // 000000A0D1CC: D72C0048
	v_cndmask_b32_e32 v1, 0x83dcd12d, v84, vcc_lo              // 000000A0D1D0: 0202A8FF 83DCD12D
	v_pk_fma_f16 v75, v75, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0D1D8: CC0E004B 0BFC0B4B 0000C931
	v_pk_fma_f16 v79, v80, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0D1E4: CC0E004F 0BFC0B50 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A0D1F0: BF870214
	.long 0xd72c0050                                           // 000000A0D1F4: D72C0050
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 000000A0D1F8: 0202A4FF 83DCD12D
	v_sad_u8 v72, v72, 0, 0x6400                               // 000000A0D200: D6220048 03FD0148 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A0D20C: BF870112
	v_sad_u8 v80, v80, 0, 0x6400                               // 000000A0D210: D6220050 03FD0150 00006400
	v_and_b32_e32 v72, 0xffff, v72                             // 000000A0D21C: 369090FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A0D224: BF870091
	v_lshl_or_b32 v72, v80, 16, v72                            // 000000A0D228: D6560048 05212150
	v_pk_fma_f16 v72, v72, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0D230: CC0E0048 0BFC0B48 0000C931
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000A0D23C: BF8700A1
	v_dot2acc_f32_f16 v52, v72, v33                            // 000000A0D240: 04684348
	v_lshlrev_b32_e32 v81, 16, v81                             // 000000A0D244: 30A2A290
	v_and_or_b32 v81, 0xffff, v77, v81                         // 000000A0D248: D6570051 05469AFF 0000FFFF
	ds_load_2addr_b32 v[77:78], v64 offset0:192 offset1:224    // 000000A0D254: D8DCE0C0 4D000040
	v_pk_fma_f16 v81, v81, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0D25C: CC0E0051 0BFC0B51 0000C931
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000A0D268: BF8701B1
	v_dot2acc_f32_f16 v53, v81, v34                            // 000000A0D26C: 046A4551
	v_and_b32_e32 v81, 0xffff, v74                             // 000000A0D270: 36A294FF 0000FFFF
	v_bfe_u32 v74, v74, 4, 16                                  // 000000A0D278: D610004A 0241094A
	v_dot2acc_f32_f16 v53, v75, v35                            // 000000A0D280: 046A474B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A0D284: BF870193
	.long 0xd72c0051                                           // 000000A0D288: D72C0051
	v_cndmask_b32_e32 v1, 0x83dcd12d, v81, vcc_lo              // 000000A0D28C: 0202A2FF 83DCD12D
	.long 0xd72c0052                                           // 000000A0D294: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 000000A0D298: 020294FF 83DCD12D
	v_mov_b32_e32 v74, v76                                     // 000000A0D2A0: 7E94034C
	s_waitcnt lgkmcnt(0)                                       // 000000A0D2A4: BF89FC07
	v_bfe_u32 v75, v77, 12, 16                                 // 000000A0D2A8: D610004B 0241194D
	v_bfe_u32 v83, v77, 8, 16                                  // 000000A0D2B0: D6100053 0241114D
	v_bfe_u32 v84, v77, 4, 16                                  // 000000A0D2B8: D6100054 0241094D
	v_and_b32_e32 v77, 0xffff, v77                             // 000000A0D2C0: 369A9AFF 0000FFFF
	v_sad_u8 v80, v81, 0, 0x6400                               // 000000A0D2C8: D6220050 03FD0151 00006400
	.long 0xd72c0051                                           // 000000A0D2D4: D72C0051
	v_cndmask_b32_e32 v1, 0x83dcd12d, v75, vcc_lo              // 000000A0D2D8: 020296FF 83DCD12D
	.long 0xd73d004a                                           // 000000A0D2E0: D73D004A
	v_cndmask_b32_e32 v1, v62, v73, vcc_lo                     // 000000A0D2E4: 0202933E
	v_sad_u8 v76, v82, 0, 0x6400                               // 000000A0D2E8: D622004C 03FD0152 00006400
	.long 0xd72c004d                                           // 000000A0D2F4: D72C004D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v77, vcc_lo              // 000000A0D2F8: 02029AFF 83DCD12D
	v_lshlrev_b32_e32 v80, 16, v80                             // 000000A0D300: 30A0A090
	.long 0xd72c0049                                           // 000000A0D304: D72C0049
	v_cndmask_b32_e32 v1, 0x83dcd12d, v84, vcc_lo              // 000000A0D308: 0202A8FF 83DCD12D
	.long 0xd72c0052                                           // 000000A0D310: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v83, vcc_lo              // 000000A0D314: 0202A6FF 83DCD12D
	v_bfe_u32 v84, v78, 8, 16                                  // 000000A0D31C: D6100054 0241114E
	v_sad_u8 v75, v81, 0, 0x6400                               // 000000A0D324: D622004B 03FD0151 00006400
	v_and_or_b32 v76, 0xffff, v76, v80                         // 000000A0D330: D657004C 054298FF 0000FFFF
	v_bfe_u32 v80, v74, 12, 16                                 // 000000A0D33C: D6100050 0241194A
	v_sad_u8 v77, v77, 0, 0x6400                               // 000000A0D344: D622004D 03FD014D 00006400
	v_sad_u8 v73, v73, 0, 0x6400                               // 000000A0D350: D6220049 03FD0149 00006400
	v_sad_u8 v81, v82, 0, 0x6400                               // 000000A0D35C: D6220051 03FD0152 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A0D368: BF870214
	.long 0xd72c0050                                           // 000000A0D36C: D72C0050
	v_cndmask_b32_e32 v1, 0x83dcd12d, v80, vcc_lo              // 000000A0D370: 0202A0FF 83DCD12D
	v_lshlrev_b32_e32 v77, 16, v77                             // 000000A0D378: 309A9A90
	v_bfe_u32 v82, v74, 8, 16                                  // 000000A0D37C: D6100052 0241114A
	v_pk_fma_f16 v76, v76, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0D384: CC0E004C 0BFC0B4C 0000C931
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A0D390: BF870193
	v_and_or_b32 v73, 0xffff, v73, v77                         // 000000A0D394: D6570049 053692FF 0000FFFF
	.long 0xd72c0048                                           // 000000A0D3A0: D72C0048
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 000000A0D3A4: 0202A4FF 83DCD12D
	v_sad_u8 v77, v80, 0, 0x6400                               // 000000A0D3AC: D622004D 03FD0150 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A0D3B8: BF870214
	v_dual_dot2acc_f32_f16 v53, v79, v36 :: v_dual_dot2acc_f32_f16 v52, v76, v34// 000000A0D3BC: CB18494F 3534454C
	v_pk_fma_f16 v80, v73, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0D3C4: CC0E0050 0BFC0B49 0000C931
	v_and_b32_e32 v75, 0xffff, v75                             // 000000A0D3D0: 369696FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A0D3D8: BF870004
	v_and_b32_e32 v76, 0xffff, v77                             // 000000A0D3DC: 36989AFF 0000FFFF
	v_and_b32_e32 v82, 0xffff, v78                             // 000000A0D3E4: 36A49CFF 0000FFFF
	v_sad_u8 v77, v72, 0, 0x6400                               // 000000A0D3EC: D622004D 03FD0148 00006400
	ds_load_2addr_b32 v[72:73], v69 offset1:32                 // 000000A0D3F8: D8DC2000 48000045
	v_lshl_or_b32 v75, v81, 16, v75                            // 000000A0D400: D656004B 052D2151
	v_bfe_u32 v81, v78, 12, 16                                 // 000000A0D408: D6100051 0241194E
	v_bfe_u32 v78, v78, 4, 16                                  // 000000A0D410: D610004E 0241094E
	v_lshl_or_b32 v77, v77, 16, v76                            // 000000A0D418: D656004D 0531214D
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A0D420: BF870004
	v_pk_fma_f16 v79, v75, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0D424: CC0E004F 0BFC0B4B 0000C931
	v_and_b32_e32 v75, 0xffff, v74                             // 000000A0D430: 369694FF 0000FFFF
	v_bfe_u32 v74, v74, 4, 16                                  // 000000A0D438: D610004A 0241094A
	.long 0xd72c0051                                           // 000000A0D440: D72C0051
	v_cndmask_b32_e32 v1, 0x83dcd12d, v81, vcc_lo              // 000000A0D444: 0202A2FF 83DCD12D
	v_pk_fma_f16 v85, v77, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0D44C: CC0E0055 0BFC0B4D 0000C931
	.long 0xd72c004d                                           // 000000A0D458: D72C004D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 000000A0D45C: 0202A4FF 83DCD12D
	.long 0xd72c0053                                           // 000000A0D464: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v75, vcc_lo              // 000000A0D468: 020296FF 83DCD12D
	.long 0xd72c004a                                           // 000000A0D470: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 000000A0D474: 020294FF 83DCD12D
	ds_load_2addr_b32 v[75:76], v68 offset1:32                 // 000000A0D47C: D8DC2000 4B000044
	v_dual_dot2acc_f32_f16 v52, v79, v35 :: v_dual_dot2acc_f32_f16 v51, v85, v33// 000000A0D484: CB18474F 34324355
	v_sad_u8 v81, v81, 0, 0x6400                               // 000000A0D48C: D6220051 03FD0151 00006400
	v_sad_u8 v87, v77, 0, 0x6400                               // 000000A0D498: D6220057 03FD014D 00006400
	v_sad_u8 v82, v83, 0, 0x6400                               // 000000A0D4A4: D6220052 03FD0153 00006400
	.long 0xd72c0053                                           // 000000A0D4B0: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v84, vcc_lo              // 000000A0D4B4: 0202A8FF 83DCD12D
	v_sad_u8 v86, v74, 0, 0x6400                               // 000000A0D4BC: D6220056 03FD014A 00006400
	s_waitcnt lgkmcnt(1)                                       // 000000A0D4C8: BF89FC17
	v_dual_mov_b32 v74, v72 :: v_dual_and_b32 v81, 0xffff, v81 // 000000A0D4CC: CA240148 4A50A2FF 0000FFFF
	v_lshlrev_b32_e32 v82, 16, v82                             // 000000A0D4D8: 30A4A490
	.long 0xd72c0054                                           // 000000A0D4DC: D72C0054
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 000000A0D4E0: 02029CFF 83DCD12D
	ds_load_2addr_b32 v[77:78], v65 offset1:32                 // 000000A0D4E8: D8DC2000 4D000041
	v_dot2acc_f32_f16 v52, v80, v36                            // 000000A0D4F0: 04684950
	v_sad_u8 v72, v83, 0, 0x6400                               // 000000A0D4F4: D6220048 03FD0153 00006400
	v_and_or_b32 v82, 0xffff, v86, v82                         // 000000A0D500: D6570052 054AACFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A0D50C: BF870112
	v_lshl_or_b32 v72, v72, 16, v81                            // 000000A0D510: D6560048 05452148
	v_pk_fma_f16 v79, v82, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0D518: CC0E004F 0BFC0B52 0000C931
	v_sad_u8 v83, v84, 0, 0x6400                               // 000000A0D524: D6220053 03FD0154 00006400
	s_waitcnt lgkmcnt(1)                                       // 000000A0D530: BF89FC17
	.long 0xd73d004a                                           // 000000A0D534: D73D004A
	v_cndmask_b32_e32 v1, v62, v74, vcc_lo                     // 000000A0D538: 0202953E
	v_pk_fma_f16 v72, v72, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0D53C: CC0E0048 0BFC0B48 0000C931
	v_dot2acc_f32_f16 v51, v79, v34                            // 000000A0D548: 0466454F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A0D54C: BF870113
	v_bfe_u32 v81, v74, 12, 16                                 // 000000A0D550: D6100051 0241194A
	v_dot2acc_f32_f16 v51, v72, v35                            // 000000A0D558: 04664748
	v_lshlrev_b32_e32 v84, 16, v87                             // 000000A0D55C: 30A8AE90
	s_waitcnt lgkmcnt(0)                                       // 000000A0D560: BF89FC07
	v_bfe_u32 v85, v77, 4, 16                                  // 000000A0D564: D6100055 0241094D
	.long 0xd72c004f                                           // 000000A0D56C: D72C004F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v81, vcc_lo              // 000000A0D570: 0202A2FF 83DCD12D
	v_bfe_u32 v81, v74, 8, 16                                  // 000000A0D578: D6100051 0241114A
	v_and_or_b32 v75, 0xffff, v83, v84                         // 000000A0D580: D657004B 0552A6FF 0000FFFF
	v_bfe_u32 v83, v77, 12, 16                                 // 000000A0D58C: D6100053 0241194D
	v_bfe_u32 v84, v77, 8, 16                                  // 000000A0D594: D6100054 0241114D
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A0D59C: BF870004
	.long 0xd72c0051                                           // 000000A0D5A0: D72C0051
	v_cndmask_b32_e32 v1, 0x83dcd12d, v81, vcc_lo              // 000000A0D5A4: 0202A2FF 83DCD12D
	v_and_b32_e32 v77, 0xffff, v77                             // 000000A0D5AC: 369A9AFF 0000FFFF
	v_pk_fma_f16 v82, v75, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0D5B4: CC0E0052 0BFC0B4B 0000C931
	v_and_b32_e32 v75, 0xffff, v74                             // 000000A0D5C0: 369694FF 0000FFFF
	v_bfe_u32 v74, v74, 4, 16                                  // 000000A0D5C8: D610004A 0241094A
	v_sad_u8 v79, v79, 0, 0x6400                               // 000000A0D5D0: D622004F 03FD014F 00006400
	.long 0xd72c0053                                           // 000000A0D5DC: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v83, vcc_lo              // 000000A0D5E0: 0202A6FF 83DCD12D
	.long 0xd72c0054                                           // 000000A0D5E8: D72C0054
	v_cndmask_b32_e32 v1, 0x83dcd12d, v84, vcc_lo              // 000000A0D5EC: 0202A8FF 83DCD12D
	.long 0xd72c004b                                           // 000000A0D5F4: D72C004B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v75, vcc_lo              // 000000A0D5F8: 020296FF 83DCD12D
	.long 0xd72c004a                                           // 000000A0D600: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 000000A0D604: 020294FF 83DCD12D
	v_and_b32_e32 v79, 0xffff, v79                             // 000000A0D60C: 369E9EFF 0000FFFF
	v_sad_u8 v81, v81, 0, 0x6400                               // 000000A0D614: D6220051 03FD0151 00006400
	.long 0xd72c004d                                           // 000000A0D620: D72C004D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v77, vcc_lo              // 000000A0D624: 02029AFF 83DCD12D
	.long 0xd72c0055                                           // 000000A0D62C: D72C0055
	v_cndmask_b32_e32 v1, 0x83dcd12d, v85, vcc_lo              // 000000A0D630: 0202AAFF 83DCD12D
	v_sad_u8 v83, v83, 0, 0x6400                               // 000000A0D638: D6220053 03FD0153 00006400
	v_dot2acc_f32_f16 v51, v82, v36                            // 000000A0D644: 04664952
	v_sad_u8 v75, v75, 0, 0x6400                               // 000000A0D648: D622004B 03FD014B 00006400
	v_sad_u8 v74, v74, 0, 0x6400                               // 000000A0D654: D622004A 03FD014A 00006400
	v_lshl_or_b32 v79, v81, 16, v79                            // 000000A0D660: D656004F 053D2151
	v_bfe_u32 v82, v78, 12, 16                                 // 000000A0D668: D6100052 0241194E
	v_sad_u8 v77, v77, 0, 0x6400                               // 000000A0D670: D622004D 03FD014D 00006400
	v_lshlrev_b32_e32 v75, 16, v75                             // 000000A0D67C: 30969690
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A0D680: BF870214
	v_pk_fma_f16 v79, v79, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0D684: CC0E004F 0BFC0B4F 0000C931
	.long 0xd72c0052                                           // 000000A0D690: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 000000A0D694: 0202A4FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A0D69C: BF870214
	v_lshlrev_b32_e32 v77, 16, v77                             // 000000A0D6A0: 309A9A90
	v_and_or_b32 v81, 0xffff, v74, v75                         // 000000A0D6A4: D6570051 052E94FF 0000FFFF
	v_mov_b32_e32 v74, v76                                     // 000000A0D6B0: 7E94034C
	v_and_b32_e32 v76, 0xffff, v83                             // 000000A0D6B4: 3698A6FF 0000FFFF
	v_sad_u8 v83, v84, 0, 0x6400                               // 000000A0D6BC: D6220053 03FD0154 00006400
	v_dot2acc_f32_f16 v50, v79, v33                            // 000000A0D6C8: 0464434F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000A0D6CC: BF870224
	.long 0xd73d004a                                           // 000000A0D6D0: D73D004A
	v_cndmask_b32_e32 v1, v62, v73, vcc_lo                     // 000000A0D6D4: 0202933E
	v_pk_fma_f16 v73, v81, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0D6D8: CC0E0049 0BFC0B51 0000C931
	v_lshl_or_b32 v75, v83, 16, v76                            // 000000A0D6E4: D656004B 05312153
	v_sad_u8 v76, v85, 0, 0x6400                               // 000000A0D6EC: D622004C 03FD0155 00006400
	v_bfe_u32 v83, v78, 8, 16                                  // 000000A0D6F8: D6100053 0241114E
	v_sad_u8 v82, v82, 0, 0x6400                               // 000000A0D700: D6220052 03FD0152 00006400
	v_bfe_u32 v79, v74, 12, 16                                 // 000000A0D70C: D610004F 0241194A
	v_pk_fma_f16 v72, v75, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0D714: CC0E0048 0BFC0B4B 0000C931
	v_dot2acc_f32_f16 v50, v73, v34                            // 000000A0D720: 04644549
	v_bfe_u32 v73, v74, 8, 16                                  // 000000A0D724: D6100049 0241114A
	v_and_or_b32 v75, 0xffff, v76, v77                         // 000000A0D72C: D657004B 053698FF 0000FFFF
	.long 0xd72c004c                                           // 000000A0D738: D72C004C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v79, vcc_lo              // 000000A0D73C: 02029EFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A0D744: BF870214
	v_dual_dot2acc_f32_f16 v50, v72, v35 :: v_dual_and_b32 v81, 0xffff, v74// 000000A0D748: CB244748 325094FF 0000FFFF
	.long 0xd72c004d                                           // 000000A0D754: D72C004D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v73, vcc_lo              // 000000A0D758: 020292FF 83DCD12D
	ds_load_2addr_b32 v[72:73], v69 offset0:64 offset1:96      // 000000A0D760: D8DC6040 48000045
	v_pk_fma_f16 v79, v75, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0D768: CC0E004F 0BFC0B4B 0000C931
	v_bfe_u32 v74, v74, 4, 16                                  // 000000A0D774: D610004A 0241094A
	.long 0xd72c0053                                           // 000000A0D77C: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v83, vcc_lo              // 000000A0D780: 0202A6FF 83DCD12D
	v_sad_u8 v80, v76, 0, 0x6400                               // 000000A0D788: D6220050 03FD014C 00006400
	ds_load_2addr_b32 v[75:76], v68 offset0:64 offset1:96      // 000000A0D794: D8DC6040 4B000044
	v_and_b32_e32 v82, 0xffff, v82                             // 000000A0D79C: 36A4A4FF 0000FFFF
	.long 0xd72c0055                                           // 000000A0D7A4: D72C0055
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 000000A0D7A8: 020294FF 83DCD12D
	.long 0xd72c0051                                           // 000000A0D7B0: D72C0051
	v_cndmask_b32_e32 v1, 0x83dcd12d, v81, vcc_lo              // 000000A0D7B4: 0202A2FF 83DCD12D
	v_sad_u8 v77, v77, 0, 0x6400                               // 000000A0D7BC: D622004D 03FD014D 00006400
	v_dot2acc_f32_f16 v50, v79, v36                            // 000000A0D7C8: 0464494F
	s_waitcnt lgkmcnt(1)                                       // 000000A0D7CC: BF89FC17
	v_mov_b32_e32 v74, v72                                     // 000000A0D7D0: 7E940348
	v_sad_u8 v72, v85, 0, 0x6400                               // 000000A0D7D4: D6220048 03FD0155 00006400
	s_waitcnt lgkmcnt(0)                                       // 000000A0D7E0: BF89FC07
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000A0D7E4: BF8700A2
	.long 0xd73d004a                                           // 000000A0D7E8: D73D004A
	v_cndmask_b32_e32 v1, v62, v74, vcc_lo                     // 000000A0D7EC: 0202953E
	v_sad_u8 v75, v83, 0, 0x6400                               // 000000A0D7F0: D622004B 03FD0153 00006400
	v_lshl_or_b32 v75, v75, 16, v82                            // 000000A0D7FC: D656004B 0549214B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000A0D804: BF8700A1
	v_pk_fma_f16 v75, v75, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0D808: CC0E004B 0BFC0B4B 0000C931
	v_and_b32_e32 v80, 0xffff, v80                             // 000000A0D814: 36A0A0FF 0000FFFF
	v_lshl_or_b32 v80, v77, 16, v80                            // 000000A0D81C: D6560050 0541214D
	v_sad_u8 v77, v81, 0, 0x6400                               // 000000A0D824: D622004D 03FD0151 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A0D830: BF870112
	v_pk_fma_f16 v80, v80, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0D834: CC0E0050 0BFC0B50 0000C931
	v_lshlrev_b32_e32 v85, 16, v77                             // 000000A0D840: 30AA9A90
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A0D844: BF870112
	v_dot2acc_f32_f16 v49, v80, v33                            // 000000A0D848: 04624350
	v_and_or_b32 v72, 0xffff, v72, v85                         // 000000A0D84C: D6570048 055690FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A0D858: BF870091
	v_pk_fma_f16 v72, v72, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0D85C: CC0E0048 0BFC0B48 0000C931
	v_dot2acc_f32_f16 v49, v72, v34                            // 000000A0D868: 04624548
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000A0D86C: BF870121
	v_dual_dot2acc_f32_f16 v49, v75, v35 :: v_dual_and_b32 v84, 0xffff, v78// 000000A0D870: CB24474B 31549CFF 0000FFFF
	v_bfe_u32 v78, v78, 4, 16                                  // 000000A0D87C: D610004E 0241094E
	.long 0xd72c0051                                           // 000000A0D884: D72C0051
	v_cndmask_b32_e32 v1, 0x83dcd12d, v84, vcc_lo              // 000000A0D888: 0202A8FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_3)// 000000A0D890: BF8701D2
	.long 0xd72c0054                                           // 000000A0D894: D72C0054
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 000000A0D898: 02029CFF 83DCD12D
	ds_load_2addr_b32 v[77:78], v65 offset0:64 offset1:96      // 000000A0D8A0: D8DC6040 4D000041
	v_sad_u8 v81, v81, 0, 0x6400                               // 000000A0D8A8: D6220051 03FD0151 00006400
	v_sad_u8 v83, v84, 0, 0x6400                               // 000000A0D8B4: D6220053 03FD0154 00006400
	v_bfe_u32 v84, v74, 12, 16                                 // 000000A0D8C0: D6100054 0241194A
	v_lshlrev_b32_e32 v81, 16, v81                             // 000000A0D8C8: 30A2A290
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000A0D8CC: BF8701A2
	.long 0xd72c0052                                           // 000000A0D8D0: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v84, vcc_lo              // 000000A0D8D4: 0202A8FF 83DCD12D
	v_and_b32_e32 v84, 0xffff, v74                             // 000000A0D8DC: 36A894FF 0000FFFF
	v_and_or_b32 v81, 0xffff, v83, v81                         // 000000A0D8E4: D6570051 0546A6FF 0000FFFF
	v_bfe_u32 v83, v74, 8, 16                                  // 000000A0D8F0: D6100053 0241114A
	v_bfe_u32 v74, v74, 4, 16                                  // 000000A0D8F8: D610004A 0241094A
	s_waitcnt lgkmcnt(0)                                       // 000000A0D900: BF89FC07
	v_and_b32_e32 v86, 0xffff, v77                             // 000000A0D904: 36AC9AFF 0000FFFF
	v_sad_u8 v82, v82, 0, 0x6400                               // 000000A0D90C: D6220052 03FD0152 00006400
	.long 0xd72c0050                                           // 000000A0D918: D72C0050
	v_cndmask_b32_e32 v1, 0x83dcd12d, v83, vcc_lo              // 000000A0D91C: 0202A6FF 83DCD12D
	.long 0xd72c0053                                           // 000000A0D924: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v84, vcc_lo              // 000000A0D928: 0202A8FF 83DCD12D
	v_bfe_u32 v84, v77, 12, 16                                 // 000000A0D930: D6100054 0241194D
	.long 0xd72c004a                                           // 000000A0D938: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 000000A0D93C: 020294FF 83DCD12D
	v_and_b32_e32 v82, 0xffff, v82                             // 000000A0D944: 36A4A4FF 0000FFFF
	v_bfe_u32 v85, v77, 8, 16                                  // 000000A0D94C: D6100055 0241114D
	v_bfe_u32 v77, v77, 4, 16                                  // 000000A0D954: D610004D 0241094D
	.long 0xd72c0054                                           // 000000A0D95C: D72C0054
	v_cndmask_b32_e32 v1, 0x83dcd12d, v84, vcc_lo              // 000000A0D960: 0202A8FF 83DCD12D
	v_sad_u8 v80, v80, 0, 0x6400                               // 000000A0D968: D6220050 03FD0150 00006400
	v_sad_u8 v83, v83, 0, 0x6400                               // 000000A0D974: D6220053 03FD0153 00006400
	.long 0xd72c0055                                           // 000000A0D980: D72C0055
	v_cndmask_b32_e32 v1, 0x83dcd12d, v85, vcc_lo              // 000000A0D984: 0202AAFF 83DCD12D
	v_sad_u8 v74, v74, 0, 0x6400                               // 000000A0D98C: D622004A 03FD014A 00006400
	.long 0xd72c004d                                           // 000000A0D998: D72C004D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v77, vcc_lo              // 000000A0D99C: 02029AFF 83DCD12D
	v_lshl_or_b32 v80, v80, 16, v82                            // 000000A0D9A4: D6560050 05492150
	.long 0xd72c0052                                           // 000000A0D9AC: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v86, vcc_lo              // 000000A0D9B0: 0202ACFF 83DCD12D
	v_lshlrev_b32_e32 v83, 16, v83                             // 000000A0D9B8: 30A6A690
	v_sad_u8 v84, v84, 0, 0x6400                               // 000000A0D9BC: D6220054 03FD0154 00006400
	v_pk_fma_f16 v81, v81, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0D9C8: CC0E0051 0BFC0B51 0000C931
	v_pk_fma_f16 v80, v80, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0D9D4: CC0E0050 0BFC0B50 0000C931
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A0D9E0: BF870004
	v_and_or_b32 v72, 0xffff, v74, v83                         // 000000A0D9E4: D6570048 054E94FF 0000FFFF
	v_sad_u8 v83, v85, 0, 0x6400                               // 000000A0D9F0: D6220053 03FD0155 00006400
	v_sad_u8 v74, v82, 0, 0x6400                               // 000000A0D9FC: D622004A 03FD0152 00006400
	v_and_b32_e32 v82, 0xffff, v84                             // 000000A0DA08: 36A4A8FF 0000FFFF
	v_dot2acc_f32_f16 v48, v80, v33                            // 000000A0DA10: 04604350
	v_pk_fma_f16 v84, v72, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0DA14: CC0E0054 0BFC0B48 0000C931
	v_sad_u8 v72, v77, 0, 0x6400                               // 000000A0DA20: D6220048 03FD014D 00006400
	v_dual_mov_b32 v74, v76 :: v_dual_lshlrev_b32 v77, 16, v74 // 000000A0DA2C: CA22014C 4A4C9490
	v_lshl_or_b32 v76, v83, 16, v82                            // 000000A0DA34: D656004C 05492153
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A0DA3C: BF870194
	v_dual_dot2acc_f32_f16 v48, v84, v34 :: v_dual_dot2acc_f32_f16 v49, v81, v36// 000000A0DA40: CB184554 30304951
	v_and_or_b32 v75, 0xffff, v72, v77                         // 000000A0DA48: D657004B 053690FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A0DA54: BF870214
	.long 0xd73d0048                                           // 000000A0DA58: D73D0048
	v_cndmask_b32_e32 v1, v62, v73, vcc_lo                     // 000000A0DA5C: 0202933E
	v_pk_fma_f16 v73, v76, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0DA60: CC0E0049 0BFC0B4C 0000C931
	v_bfe_u32 v77, v78, 12, 16                                 // 000000A0DA6C: D610004D 0241194E
	v_bfe_u32 v80, v78, 8, 16                                  // 000000A0DA74: D6100050 0241114E
	v_pk_fma_f16 v79, v75, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0DA7C: CC0E004F 0BFC0B4B 0000C931
	v_bfe_u32 v81, v78, 4, 16                                  // 000000A0DA88: D6100051 0241094E
	v_bfe_u32 v74, v72, 12, 16                                 // 000000A0DA90: D610004A 02411948
	v_bfe_u32 v75, v72, 8, 16                                  // 000000A0DA98: D610004B 02411148
	v_bfe_u32 v76, v72, 4, 16                                  // 000000A0DAA0: D610004C 02410948
	v_and_b32_e32 v72, 0xffff, v72                             // 000000A0DAA8: 369090FF 0000FFFF
	v_dot2acc_f32_f16 v48, v73, v35                            // 000000A0DAB0: 04604749
	.long 0xd72c004a                                           // 000000A0DAB4: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 000000A0DAB8: 020294FF 83DCD12D
	.long 0xd72c0053                                           // 000000A0DAC0: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v75, vcc_lo              // 000000A0DAC4: 020296FF 83DCD12D
	.long 0xd72c0054                                           // 000000A0DACC: D72C0054
	v_cndmask_b32_e32 v1, 0x83dcd12d, v76, vcc_lo              // 000000A0DAD0: 020298FF 83DCD12D
	.long 0xd72c0052                                           // 000000A0DAD8: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v72, vcc_lo              // 000000A0DADC: 020290FF 83DCD12D
	ds_load_2addr_b32 v[72:73], v69 offset0:128 offset1:160    // 000000A0DAE4: D8DCA080 48000045
	ds_load_2addr_b32 v[75:76], v68 offset0:128 offset1:160    // 000000A0DAEC: D8DCA080 4B000044
	.long 0xd72c004d                                           // 000000A0DAF4: D72C004D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v77, vcc_lo              // 000000A0DAF8: 02029AFF 83DCD12D
	v_and_b32_e32 v78, 0xffff, v78                             // 000000A0DB00: 369C9CFF 0000FFFF
	v_sad_u8 v74, v74, 0, 0x6400                               // 000000A0DB08: D622004A 03FD014A 00006400
	.long 0xd72c0050                                           // 000000A0DB14: D72C0050
	v_cndmask_b32_e32 v1, 0x83dcd12d, v80, vcc_lo              // 000000A0DB18: 0202A0FF 83DCD12D
	v_sad_u8 v83, v83, 0, 0x6400                               // 000000A0DB20: D6220053 03FD0153 00006400
	v_sad_u8 v82, v82, 0, 0x6400                               // 000000A0DB2C: D6220052 03FD0152 00006400
	.long 0xd72c004e                                           // 000000A0DB38: D72C004E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 000000A0DB3C: 02029CFF 83DCD12D
	v_and_b32_e32 v74, 0xffff, v74                             // 000000A0DB44: 369494FF 0000FFFF
	v_sad_u8 v84, v84, 0, 0x6400                               // 000000A0DB4C: D6220054 03FD0154 00006400
	v_sad_u8 v77, v77, 0, 0x6400                               // 000000A0DB58: D622004D 03FD014D 00006400
	v_lshlrev_b32_e32 v82, 16, v82                             // 000000A0DB64: 30A4A490
	.long 0xd72c0051                                           // 000000A0DB68: D72C0051
	v_cndmask_b32_e32 v1, 0x83dcd12d, v81, vcc_lo              // 000000A0DB6C: 0202A2FF 83DCD12D
	v_lshl_or_b32 v83, v83, 16, v74                            // 000000A0DB74: D6560053 05292153
	v_dot2acc_f32_f16 v48, v79, v36                            // 000000A0DB7C: 0460494F
	v_sad_u8 v85, v78, 0, 0x6400                               // 000000A0DB80: D6220055 03FD014E 00006400
	v_and_or_b32 v82, 0xffff, v84, v82                         // 000000A0DB8C: D6570052 054AA8FF 0000FFFF
	v_and_b32_e32 v84, 0xffff, v77                             // 000000A0DB98: 36A89AFF 0000FFFF
	ds_load_2addr_b32 v[77:78], v65 offset0:128 offset1:160    // 000000A0DBA0: D8DCA080 4D000041
	s_waitcnt lgkmcnt(2)                                       // 000000A0DBA8: BF89FC27
	v_mov_b32_e32 v74, v72                                     // 000000A0DBAC: 7E940348
	v_sad_u8 v72, v80, 0, 0x6400                               // 000000A0DBB0: D6220048 03FD0150 00006400
	v_sad_u8 v80, v81, 0, 0x6400                               // 000000A0DBBC: D6220050 03FD0151 00006400
	v_lshlrev_b32_e32 v81, 16, v85                             // 000000A0DBC8: 30A2AA90
	s_waitcnt lgkmcnt(1)                                       // 000000A0DBCC: BF89FC17
	.long 0xd73d004a                                           // 000000A0DBD0: D73D004A
	v_cndmask_b32_e32 v1, v62, v74, vcc_lo                     // 000000A0DBD4: 0202953E
	v_pk_fma_f16 v75, v83, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0DBD8: CC0E004B 0BFC0B53 0000C931
	v_lshl_or_b32 v72, v72, 16, v84                            // 000000A0DBE4: D6560048 05512148
	v_and_or_b32 v79, 0xffff, v80, v81                         // 000000A0DBEC: D657004F 0546A0FF 0000FFFF
	v_pk_fma_f16 v80, v82, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0DBF8: CC0E0050 0BFC0B52 0000C931
	v_bfe_u32 v81, v74, 12, 16                                 // 000000A0DC04: D6100051 0241194A
	v_dot2acc_f32_f16 v47, v75, v33                            // 000000A0DC0C: 045E434B
	v_pk_fma_f16 v75, v72, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0DC10: CC0E004B 0BFC0B48 0000C931
	v_and_b32_e32 v72, 0xffff, v74                             // 000000A0DC1C: 369094FF 0000FFFF
	v_pk_fma_f16 v79, v79, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0DC24: CC0E004F 0BFC0B4F 0000C931
	.long 0xd72c0051                                           // 000000A0DC30: D72C0051
	v_cndmask_b32_e32 v1, 0x83dcd12d, v81, vcc_lo              // 000000A0DC34: 0202A2FF 83DCD12D
	v_dot2acc_f32_f16 v47, v80, v34                            // 000000A0DC3C: 045E4550
	v_bfe_u32 v80, v74, 8, 16                                  // 000000A0DC40: D6100050 0241114A
	v_bfe_u32 v74, v74, 4, 16                                  // 000000A0DC48: D610004A 0241094A
	.long 0xd72c0048                                           // 000000A0DC50: D72C0048
	v_cndmask_b32_e32 v1, 0x83dcd12d, v72, vcc_lo              // 000000A0DC54: 020290FF 83DCD12D
	s_waitcnt lgkmcnt(0)                                       // 000000A0DC5C: BF89FC07
	v_bfe_u32 v82, v77, 12, 16                                 // 000000A0DC60: D6100052 0241194D
	v_bfe_u32 v83, v77, 8, 16                                  // 000000A0DC68: D6100053 0241114D
	.long 0xd72c0050                                           // 000000A0DC70: D72C0050
	v_cndmask_b32_e32 v1, 0x83dcd12d, v80, vcc_lo              // 000000A0DC74: 0202A0FF 83DCD12D
	.long 0xd72c004a                                           // 000000A0DC7C: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 000000A0DC80: 020294FF 83DCD12D
	v_bfe_u32 v84, v77, 4, 16                                  // 000000A0DC88: D6100054 0241094D
	v_and_b32_e32 v77, 0xffff, v77                             // 000000A0DC90: 369A9AFF 0000FFFF
	v_sad_u8 v81, v81, 0, 0x6400                               // 000000A0DC98: D6220051 03FD0151 00006400
	v_sad_u8 v72, v72, 0, 0x6400                               // 000000A0DCA4: D6220048 03FD0148 00006400
	.long 0xd72c0052                                           // 000000A0DCB0: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 000000A0DCB4: 0202A4FF 83DCD12D
	.long 0xd72c0053                                           // 000000A0DCBC: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v83, vcc_lo              // 000000A0DCC0: 0202A6FF 83DCD12D
	.long 0xd72c004d                                           // 000000A0DCC8: D72C004D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v77, vcc_lo              // 000000A0DCCC: 02029AFF 83DCD12D
	v_and_b32_e32 v81, 0xffff, v81                             // 000000A0DCD4: 36A2A2FF 0000FFFF
	v_sad_u8 v80, v80, 0, 0x6400                               // 000000A0DCDC: D6220050 03FD0150 00006400
	v_sad_u8 v74, v74, 0, 0x6400                               // 000000A0DCE8: D622004A 03FD014A 00006400
	v_lshlrev_b32_e32 v72, 16, v72                             // 000000A0DCF4: 30909090
	.long 0xd72c0054                                           // 000000A0DCF8: D72C0054
	v_cndmask_b32_e32 v1, 0x83dcd12d, v84, vcc_lo              // 000000A0DCFC: 0202A8FF 83DCD12D
	v_sad_u8 v82, v82, 0, 0x6400                               // 000000A0DD04: D6220052 03FD0152 00006400
	v_lshl_or_b32 v80, v80, 16, v81                            // 000000A0DD10: D6560050 05452150
	v_dot2acc_f32_f16 v47, v75, v35                            // 000000A0DD18: 045E474B
	v_and_or_b32 v81, 0xffff, v74, v72                         // 000000A0DD1C: D6570051 052294FF 0000FFFF
	v_sad_u8 v72, v77, 0, 0x6400                               // 000000A0DD28: D6220048 03FD014D 00006400
	v_mov_b32_e32 v74, v76                                     // 000000A0DD34: 7E94034C
	v_sad_u8 v77, v83, 0, 0x6400                               // 000000A0DD38: D622004D 03FD0153 00006400
	v_and_b32_e32 v76, 0xffff, v82                             // 000000A0DD44: 3698A4FF 0000FFFF
	v_sad_u8 v82, v84, 0, 0x6400                               // 000000A0DD4C: D6220052 03FD0154 00006400
	v_lshlrev_b32_e32 v83, 16, v72                             // 000000A0DD58: 30A69090
	.long 0xd73d0048                                           // 000000A0DD5C: D73D0048
	v_cndmask_b32_e32 v1, v62, v73, vcc_lo                     // 000000A0DD60: 0202933E
	v_pk_fma_f16 v73, v80, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0DD64: CC0E0049 0BFC0B50 0000C931
	v_lshl_or_b32 v75, v77, 16, v76                            // 000000A0DD70: D656004B 0531214D
	v_pk_fma_f16 v74, v81, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0DD78: CC0E004A 0BFC0B51 0000C931
	v_and_or_b32 v76, 0xffff, v82, v83                         // 000000A0DD84: D657004C 054EA4FF 0000FFFF
	v_dot2acc_f32_f16 v47, v79, v36                            // 000000A0DD90: 045E494F
	v_bfe_u32 v77, v72, 12, 16                                 // 000000A0DD94: D610004D 02411948
	v_dot2acc_f32_f16 v46, v73, v33                            // 000000A0DD9C: 045C4349
	v_pk_fma_f16 v79, v75, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0DDA0: CC0E004F 0BFC0B4B 0000C931
	v_bfe_u32 v75, v72, 4, 16                                  // 000000A0DDAC: D610004B 02410948
	v_pk_fma_f16 v80, v76, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0DDB4: CC0E0050 0BFC0B4C 0000C931
	.long 0xd72c0049                                           // 000000A0DDC0: D72C0049
	v_cndmask_b32_e32 v1, 0x83dcd12d, v77, vcc_lo              // 000000A0DDC4: 02029AFF 83DCD12D
	v_dot2acc_f32_f16 v46, v74, v34                            // 000000A0DDCC: 045C454A
	v_bfe_u32 v74, v72, 8, 16                                  // 000000A0DDD0: D610004A 02411148
	v_and_b32_e32 v72, 0xffff, v72                             // 000000A0DDD8: 369090FF 0000FFFF
	v_bfe_u32 v76, v78, 12, 16                                 // 000000A0DDE0: D610004C 0241194E
	v_bfe_u32 v77, v78, 8, 16                                  // 000000A0DDE8: D610004D 0241114E
	v_bfe_u32 v81, v78, 4, 16                                  // 000000A0DDF0: D6100051 0241094E
	.long 0xd72c004a                                           // 000000A0DDF8: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 000000A0DDFC: 020294FF 83DCD12D
	v_sad_u8 v82, v73, 0, 0x6400                               // 000000A0DE04: D6220052 03FD0149 00006400
	.long 0xd72c0053                                           // 000000A0DE10: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v72, vcc_lo              // 000000A0DE14: 020290FF 83DCD12D
	ds_load_2addr_b32 v[72:73], v69 offset0:192 offset1:224    // 000000A0DE1C: D8DCE0C0 48000045
	v_and_b32_e32 v78, 0xffff, v78                             // 000000A0DE24: 369C9CFF 0000FFFF
	.long 0xd72c0054                                           // 000000A0DE2C: D72C0054
	v_cndmask_b32_e32 v1, 0x83dcd12d, v76, vcc_lo              // 000000A0DE30: 020298FF 83DCD12D
	.long 0xd72c0055                                           // 000000A0DE38: D72C0055
	v_cndmask_b32_e32 v1, 0x83dcd12d, v75, vcc_lo              // 000000A0DE3C: 020296FF 83DCD12D
	ds_load_2addr_b32 v[75:76], v68 offset0:192 offset1:224    // 000000A0DE44: D8DCE0C0 4B000044
	v_sad_u8 v86, v74, 0, 0x6400                               // 000000A0DE4C: D6220056 03FD014A 00006400
	.long 0xd72c004e                                           // 000000A0DE58: D72C004E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 000000A0DE5C: 02029CFF 83DCD12D
	v_sad_u8 v74, v83, 0, 0x6400                               // 000000A0DE64: D622004A 03FD0153 00006400
	v_and_b32_e32 v82, 0xffff, v82                             // 000000A0DE70: 36A4A4FF 0000FFFF
	.long 0xd72c0053                                           // 000000A0DE78: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v77, vcc_lo              // 000000A0DE7C: 02029AFF 83DCD12D
	v_sad_u8 v84, v84, 0, 0x6400                               // 000000A0DE84: D6220054 03FD0154 00006400
	v_sad_u8 v85, v85, 0, 0x6400                               // 000000A0DE90: D6220055 03FD0155 00006400
	v_dual_dot2acc_f32_f16 v46, v79, v35 :: v_dual_lshlrev_b32 v87, 16, v74// 000000A0DE9C: CB22474F 2E569490
	v_sad_u8 v74, v78, 0, 0x6400                               // 000000A0DEA4: D622004A 03FD014E 00006400
	ds_load_2addr_b32 v[77:78], v65 offset0:192 offset1:224    // 000000A0DEB0: D8DCE0C0 4D000041
	v_and_b32_e32 v84, 0xffff, v84                             // 000000A0DEB8: 36A8A8FF 0000FFFF
	v_sad_u8 v83, v83, 0, 0x6400                               // 000000A0DEC0: D6220053 03FD0153 00006400
	.long 0xd72c0051                                           // 000000A0DECC: D72C0051
	v_cndmask_b32_e32 v1, 0x83dcd12d, v81, vcc_lo              // 000000A0DED0: 0202A2FF 83DCD12D
	v_lshlrev_b32_e32 v88, 16, v74                             // 000000A0DED8: 30B09490
	s_waitcnt lgkmcnt(2)                                       // 000000A0DEDC: BF89FC27
	v_mov_b32_e32 v74, v72                                     // 000000A0DEE0: 7E940348
	v_lshl_or_b32 v72, v86, 16, v82                            // 000000A0DEE4: D6560048 05492156
	v_and_or_b32 v82, 0xffff, v85, v87                         // 000000A0DEEC: D6570052 055EAAFF 0000FFFF
	v_lshl_or_b32 v83, v83, 16, v84                            // 000000A0DEF8: D6560053 05512153
	s_waitcnt lgkmcnt(1)                                       // 000000A0DF00: BF89FC17
	.long 0xd73d004a                                           // 000000A0DF04: D73D004A
	v_cndmask_b32_e32 v1, v62, v74, vcc_lo                     // 000000A0DF08: 0202953E
	v_pk_fma_f16 v72, v72, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0DF0C: CC0E0048 0BFC0B48 0000C931
	v_pk_fma_f16 v75, v82, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0DF18: CC0E004B 0BFC0B52 0000C931
	v_pk_fma_f16 v79, v83, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0DF24: CC0E004F 0BFC0B53 0000C931
	v_dot2acc_f32_f16 v46, v80, v36                            // 000000A0DF30: 045C4950
	v_sad_u8 v81, v81, 0, 0x6400                               // 000000A0DF34: D6220051 03FD0151 00006400
	v_bfe_u32 v82, v74, 12, 16                                 // 000000A0DF40: D6100052 0241194A
	v_dual_dot2acc_f32_f16 v45, v72, v33 :: v_dual_and_b32 v72, 0xffff, v74// 000000A0DF48: CB244348 2D4894FF 0000FFFF
	v_bfe_u32 v83, v74, 8, 16                                  // 000000A0DF54: D6100053 0241114A
	v_bfe_u32 v74, v74, 4, 16                                  // 000000A0DF5C: D610004A 0241094A
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A0DF64: BF870004
	.long 0xd72c0052                                           // 000000A0DF68: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 000000A0DF6C: 0202A4FF 83DCD12D
	s_waitcnt lgkmcnt(0)                                       // 000000A0DF74: BF89FC07
	v_bfe_u32 v84, v77, 12, 16                                 // 000000A0DF78: D6100054 0241194D
	.long 0xd72c0048                                           // 000000A0DF80: D72C0048
	v_cndmask_b32_e32 v1, 0x83dcd12d, v72, vcc_lo              // 000000A0DF84: 020290FF 83DCD12D
	.long 0xd72c0053                                           // 000000A0DF8C: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v83, vcc_lo              // 000000A0DF90: 0202A6FF 83DCD12D
	.long 0xd72c004a                                           // 000000A0DF98: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 000000A0DF9C: 020294FF 83DCD12D
	v_bfe_u32 v85, v77, 8, 16                                  // 000000A0DFA4: D6100055 0241114D
	.long 0xd72c0054                                           // 000000A0DFAC: D72C0054
	v_cndmask_b32_e32 v1, 0x83dcd12d, v84, vcc_lo              // 000000A0DFB0: 0202A8FF 83DCD12D
	v_bfe_u32 v86, v77, 4, 16                                  // 000000A0DFB8: D6100056 0241094D
	v_sad_u8 v82, v82, 0, 0x6400                               // 000000A0DFC0: D6220052 03FD0152 00006400
	v_and_b32_e32 v77, 0xffff, v77                             // 000000A0DFCC: 369A9AFF 0000FFFF
	v_sad_u8 v72, v72, 0, 0x6400                               // 000000A0DFD4: D6220048 03FD0148 00006400
	v_sad_u8 v83, v83, 0, 0x6400                               // 000000A0DFE0: D6220053 03FD0153 00006400
	.long 0xd72c0055                                           // 000000A0DFEC: D72C0055
	v_cndmask_b32_e32 v1, 0x83dcd12d, v85, vcc_lo              // 000000A0DFF0: 0202AAFF 83DCD12D
	v_and_b32_e32 v82, 0xffff, v82                             // 000000A0DFF8: 36A4A4FF 0000FFFF
	v_sad_u8 v87, v74, 0, 0x6400                               // 000000A0E000: D6220057 03FD014A 00006400
	v_lshlrev_b32_e32 v72, 16, v72                             // 000000A0E00C: 30909090
	v_mov_b32_e32 v74, v76                                     // 000000A0E010: 7E94034C
	v_sad_u8 v84, v84, 0, 0x6400                               // 000000A0E014: D6220054 03FD0154 00006400
	v_lshl_or_b32 v82, v83, 16, v82                            // 000000A0E020: D6560052 05492153
	v_dot2acc_f32_f16 v45, v75, v34                            // 000000A0E028: 045A454B
	v_and_or_b32 v83, 0xffff, v87, v72                         // 000000A0E02C: D6570053 0522AEFF 0000FFFF
	.long 0xd73d0048                                           // 000000A0E038: D73D0048
	v_cndmask_b32_e32 v1, v62, v73, vcc_lo                     // 000000A0E03C: 0202933E
	v_and_b32_e32 v84, 0xffff, v84                             // 000000A0E040: 36A8A8FF 0000FFFF
	v_sad_u8 v76, v85, 0, 0x6400                               // 000000A0E048: D622004C 03FD0155 00006400
	v_pk_fma_f16 v75, v82, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0E054: CC0E004B 0BFC0B52 0000C931
	.long 0xd72c004a                                           // 000000A0E060: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v77, vcc_lo              // 000000A0E064: 02029AFF 83DCD12D
	.long 0xd72c0055                                           // 000000A0E06C: D72C0055
	v_cndmask_b32_e32 v1, 0x83dcd12d, v86, vcc_lo              // 000000A0E070: 0202ACFF 83DCD12D
	v_bfe_u32 v77, v72, 12, 16                                 // 000000A0E078: D610004D 02411948
	v_lshl_or_b32 v73, v76, 16, v84                            // 000000A0E080: D6560049 0551214C
	v_pk_fma_f16 v76, v83, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0E088: CC0E004C 0BFC0B53 0000C931
	v_dot2acc_f32_f16 v44, v75, v33                            // 000000A0E094: 0458434B
	v_bfe_u32 v84, v72, 8, 16                                  // 000000A0E098: D6100054 02411148
	.long 0xd72c004d                                           // 000000A0E0A0: D72C004D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v77, vcc_lo              // 000000A0E0A4: 02029AFF 83DCD12D
	v_pk_fma_f16 v73, v73, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0E0AC: CC0E0049 0BFC0B49 0000C931
	v_sad_u8 v82, v85, 0, 0x6400                               // 000000A0E0B8: D6220052 03FD0155 00006400
	v_dual_dot2acc_f32_f16 v44, v76, v34 :: v_dual_and_b32 v83, 0xffff, v72// 000000A0E0C4: CB24454C 2C5290FF 0000FFFF
	.long 0xd72c0054                                           // 000000A0E0D0: D72C0054
	v_cndmask_b32_e32 v1, 0x83dcd12d, v84, vcc_lo              // 000000A0E0D4: 0202A8FF 83DCD12D
	v_bfe_u32 v72, v72, 4, 16                                  // 000000A0E0DC: D6100048 02410948
	v_bfe_u32 v85, v78, 12, 16                                 // 000000A0E0E4: D6100055 0241194E
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A0E0EC: BF870004
	v_dot2acc_f32_f16 v44, v73, v35                            // 000000A0E0F0: 04584749
	.long 0xd72c0053                                           // 000000A0E0F4: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v83, vcc_lo              // 000000A0E0F8: 0202A6FF 83DCD12D
	v_sad_u8 v77, v77, 0, 0x6400                               // 000000A0E100: D622004D 03FD014D 00006400
	.long 0xd72c0048                                           // 000000A0E10C: D72C0048
	v_cndmask_b32_e32 v1, 0x83dcd12d, v72, vcc_lo              // 000000A0E110: 020290FF 83DCD12D
	v_bfe_u32 v86, v78, 8, 16                                  // 000000A0E118: D6100056 0241114E
	v_sad_u8 v84, v84, 0, 0x6400                               // 000000A0E120: D6220054 03FD0154 00006400
	v_bfe_u32 v87, v78, 4, 16                                  // 000000A0E12C: D6100057 0241094E
	v_and_b32_e32 v77, 0xffff, v77                             // 000000A0E134: 369A9AFF 0000FFFF
	.long 0xd72c0055                                           // 000000A0E13C: D72C0055
	v_cndmask_b32_e32 v1, 0x83dcd12d, v85, vcc_lo              // 000000A0E140: 0202AAFF 83DCD12D
	v_sad_u8 v83, v83, 0, 0x6400                               // 000000A0E148: D6220053 03FD0153 00006400
	v_and_b32_e32 v78, 0xffff, v78                             // 000000A0E154: 369C9CFF 0000FFFF
	v_sad_u8 v74, v74, 0, 0x6400                               // 000000A0E15C: D622004A 03FD014A 00006400
	v_lshl_or_b32 v77, v84, 16, v77                            // 000000A0E168: D656004D 05352154
	v_sad_u8 v72, v72, 0, 0x6400                               // 000000A0E170: D6220048 03FD0148 00006400
	v_lshlrev_b32_e32 v83, 16, v83                             // 000000A0E17C: 30A6A690
	.long 0xd72c0056                                           // 000000A0E180: D72C0056
	v_cndmask_b32_e32 v1, 0x83dcd12d, v86, vcc_lo              // 000000A0E184: 0202ACFF 83DCD12D
	.long 0xd72c004e                                           // 000000A0E18C: D72C004E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 000000A0E190: 02029CFF 83DCD12D
	v_sad_u8 v85, v85, 0, 0x6400                               // 000000A0E198: D6220055 03FD0155 00006400
	v_lshlrev_b32_e32 v74, 16, v74                             // 000000A0E1A4: 30949490
	v_pk_fma_f16 v77, v77, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0E1A8: CC0E004D 0BFC0B4D 0000C931
	v_and_or_b32 v72, 0xffff, v72, v83                         // 000000A0E1B4: D6570048 054E90FF 0000FFFF
	.long 0xd72c0053                                           // 000000A0E1C0: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v87, vcc_lo              // 000000A0E1C4: 0202AEFF 83DCD12D
	v_and_b32_e32 v84, 0xffff, v85                             // 000000A0E1CC: 36A8AAFF 0000FFFF
	v_sad_u8 v85, v86, 0, 0x6400                               // 000000A0E1D4: D6220055 03FD0156 00006400
	v_sad_u8 v75, v78, 0, 0x6400                               // 000000A0E1E0: D622004B 03FD014E 00006400
	v_dot2acc_f32_f16 v58, v77, v33                            // 000000A0E1EC: 0474434D
	v_and_or_b32 v33, 0xffff, v82, v74                         // 000000A0E1F0: D6570021 052AA4FF 0000FFFF
	v_pk_fma_f16 v72, v72, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0E1FC: CC0E0048 0BFC0B48 0000C931
	v_lshl_or_b32 v78, v85, 16, v84                            // 000000A0E208: D656004E 05512155
	v_sad_u8 v83, v83, 0, 0x6400                               // 000000A0E210: D6220053 03FD0153 00006400
	v_and_or_b32 v81, 0xffff, v81, v88                         // 000000A0E21C: D6570051 0562A2FF 0000FFFF
	v_pk_fma_f16 v33, v33, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0E228: CC0E0021 0BFC0B21 0000C931
	v_lshlrev_b32_e32 v75, 16, v75                             // 000000A0E234: 30969690
	v_pk_fma_f16 v74, v78, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0E238: CC0E004A 0BFC0B4E 0000C931
	v_dot2acc_f32_f16 v58, v72, v34                            // 000000A0E244: 04744548
	v_pk_fma_f16 v81, v81, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0E248: CC0E0051 0BFC0B51 0000C931
	v_dot2acc_f32_f16 v44, v33, v36                            // 000000A0E254: 04584921
	v_and_or_b32 v75, 0xffff, v83, v75                         // 000000A0E258: D657004B 052EA6FF 0000FFFF
	v_dot2acc_f32_f16 v45, v79, v35                            // 000000A0E264: 045A474F
	v_dot2acc_f32_f16 v58, v74, v35                            // 000000A0E268: 0474474A
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000A0E26C: BF870223
	v_pk_fma_f16 v34, v75, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A0E270: CC0E0022 0BFC0B4B 0000C931
	v_add_nc_u32_e32 v35, 1, v71                               // 000000A0E27C: 4A468E81
	v_dot2acc_f32_f16 v45, v81, v36                            // 000000A0E280: 045A4951
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A0E284: BF870193
	v_dot2acc_f32_f16 v58, v34, v36                            // 000000A0E288: 04744922
	.long 0xd4c9007e                                           // 000000A0E28C: D4C9007E
	v_cndmask_b32_e32 v1, v35, v43, vcc_lo                     // 000000A0E290: 02025723
	s_cbranch_execz 63753                                      // 000000A0E294: BFA5F909 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi3EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x49bc>
	v_add_nc_u32_e32 v36, 3, v71                               // 000000A0E298: 4A488E83
	s_mov_b32 s7, exec_lo                                      // 000000A0E29C: BE87007E
	ds_store_2addr_b32 v64, v1, v2 offset1:32                  // 000000A0E2A0: D8382000 00020140
	ds_store_2addr_b32 v64, v3, v4 offset0:64 offset1:96       // 000000A0E2A8: D8386040 00040340
	ds_store_2addr_b32 v64, v5, v6 offset0:128 offset1:160     // 000000A0E2B0: D838A080 00060540
	ds_store_2addr_b32 v64, v7, v8 offset0:192 offset1:224     // 000000A0E2B8: D838E0C0 00080740
	ds_store_2addr_b32 v65, v9, v10 offset1:32                 // 000000A0E2C0: D8382000 000A0941
	ds_store_2addr_b32 v65, v11, v12 offset0:64 offset1:96     // 000000A0E2C8: D8386040 000C0B41
	ds_store_2addr_b32 v65, v13, v14 offset0:128 offset1:160   // 000000A0E2D0: D838A080 000E0D41
	ds_store_2addr_b32 v65, v15, v16 offset0:192 offset1:224   // 000000A0E2D8: D838E0C0 00100F41
	.long 0xd4c9007e                                           // 000000A0E2E0: D4C9007E
	v_cndmask_b32_e32 v1, v36, v43, vcc_lo                     // 000000A0E2E4: 02025724
	s_cbranch_execz 62032                                      // 000000A0E2E8: BFA5F250 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi3EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x2f2c>
	.long 0xd73c0001                                           // 000000A0E2EC: D73C0001
	v_cndmask_b32_e32 v1, 11, v36, vcc_lo                      // 000000A0E2F0: 0202488B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A0E2F4: BF870091
	.long 0xd7000021                                           // 000000A0E2F8: D7000021
	v_cndmask_b32_e32 v1, v60, v1, vcc_lo                      // 000000A0E2FC: 0202033C
	v_add_co_ci_u32_e64 v34, null, v61, v2, s0                 // 000000A0E300: D5207C22 0002053D
	s_clause 0xf                                               // 000000A0E308: BF85000F
	global_load_b32 v1, v[33:34], off                          // 000000A0E30C: DC520000 017C0021
	global_load_b32 v2, v[33:34], off offset:128               // 000000A0E314: DC520080 027C0021
	global_load_b32 v3, v[33:34], off offset:256               // 000000A0E31C: DC520100 037C0021
	global_load_b32 v4, v[33:34], off offset:384               // 000000A0E324: DC520180 047C0021
	global_load_b32 v5, v[33:34], off offset:512               // 000000A0E32C: DC520200 057C0021
	global_load_b32 v6, v[33:34], off offset:640               // 000000A0E334: DC520280 067C0021
	global_load_b32 v7, v[33:34], off offset:768               // 000000A0E33C: DC520300 077C0021
	global_load_b32 v8, v[33:34], off offset:896               // 000000A0E344: DC520380 087C0021
	global_load_b32 v9, v[33:34], off offset:1024              // 000000A0E34C: DC520400 097C0021
	global_load_b32 v10, v[33:34], off offset:1152             // 000000A0E354: DC520480 0A7C0021
	global_load_b32 v11, v[33:34], off offset:1280             // 000000A0E35C: DC520500 0B7C0021
	global_load_b32 v12, v[33:34], off offset:1408             // 000000A0E364: DC520580 0C7C0021
	global_load_b32 v13, v[33:34], off offset:1536             // 000000A0E36C: DC520600 0D7C0021
	global_load_b32 v14, v[33:34], off offset:1664             // 000000A0E374: DC520680 0E7C0021
	global_load_b32 v15, v[33:34], off offset:1792             // 000000A0E37C: DC520700 0F7C0021
	global_load_b32 v16, v[33:34], off offset:1920             // 000000A0E384: DC520780 107C0021
	s_branch 61991                                             // 000000A0E38C: BFA0F227 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi3EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x2f2c>
	s_or_b32 exec_lo, exec_lo, s4                              // 000000A0E390: 8C7E047E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000A0E394: BF870009
	s_or_b32 exec_lo, exec_lo, s3                              // 000000A0E398: 8C7E037E
	s_waitcnt vmcnt(14)                                        // 000000A0E39C: BF893BF7
	v_dual_mov_b32 v1, v59 :: v_dual_mov_b32 v2, v57           // 000000A0E3A0: CA10013B 01020139
	s_waitcnt vmcnt(12)                                        // 000000A0E3A8: BF8933F7
	v_dual_mov_b32 v3, v56 :: v_dual_mov_b32 v4, v55           // 000000A0E3AC: CA100138 03040137
	s_waitcnt vmcnt(10)                                        // 000000A0E3B4: BF892BF7
	v_dual_mov_b32 v5, v54 :: v_dual_mov_b32 v6, v53           // 000000A0E3B8: CA100136 05060135
	s_waitcnt vmcnt(8)                                         // 000000A0E3C0: BF8923F7
	v_dual_mov_b32 v7, v52 :: v_dual_mov_b32 v8, v51           // 000000A0E3C4: CA100134 07080133
	s_waitcnt vmcnt(6)                                         // 000000A0E3CC: BF891BF7
	v_dual_mov_b32 v9, v50 :: v_dual_mov_b32 v10, v49          // 000000A0E3D0: CA100132 090A0131
	s_waitcnt vmcnt(4)                                         // 000000A0E3D8: BF8913F7
	v_dual_mov_b32 v11, v48 :: v_dual_mov_b32 v12, v47         // 000000A0E3DC: CA100130 0B0C012F
	s_waitcnt vmcnt(2)                                         // 000000A0E3E4: BF890BF7
	v_dual_mov_b32 v13, v46 :: v_dual_mov_b32 v14, v45         // 000000A0E3E8: CA10012E 0D0E012D
	s_waitcnt vmcnt(0)                                         // 000000A0E3F0: BF8903F7
	v_dual_mov_b32 v15, v44 :: v_dual_mov_b32 v16, v58         // 000000A0E3F4: CA10012C 0F10013A
	s_mov_b32 s0, 0x76543210                                   // 000000A0E3FC: BE8000FF 76543210
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000A0E404: BF870009
	v_permlanex16_b32 v1, v1, s0, 0xfedcba98                   // 000000A0E408: D65C0001 03FC0101 FEDCBA98
	v_permlanex16_b32 v2, v2, s0, 0xfedcba98                   // 000000A0E414: D65C0002 03FC0102 FEDCBA98
	v_permlanex16_b32 v3, v3, s0, 0xfedcba98                   // 000000A0E420: D65C0003 03FC0103 FEDCBA98
	v_permlanex16_b32 v4, v4, s0, 0xfedcba98                   // 000000A0E42C: D65C0004 03FC0104 FEDCBA98
	v_permlanex16_b32 v5, v5, s0, 0xfedcba98                   // 000000A0E438: D65C0005 03FC0105 FEDCBA98
	v_permlanex16_b32 v6, v6, s0, 0xfedcba98                   // 000000A0E444: D65C0006 03FC0106 FEDCBA98
	v_permlanex16_b32 v7, v7, s0, 0xfedcba98                   // 000000A0E450: D65C0007 03FC0107 FEDCBA98
	v_permlanex16_b32 v8, v8, s0, 0xfedcba98                   // 000000A0E45C: D65C0008 03FC0108 FEDCBA98
	v_permlanex16_b32 v9, v9, s0, 0xfedcba98                   // 000000A0E468: D65C0009 03FC0109 FEDCBA98
	v_permlanex16_b32 v10, v10, s0, 0xfedcba98                 // 000000A0E474: D65C000A 03FC010A FEDCBA98
	v_permlanex16_b32 v11, v11, s0, 0xfedcba98                 // 000000A0E480: D65C000B 03FC010B FEDCBA98
	v_permlanex16_b32 v12, v12, s0, 0xfedcba98                 // 000000A0E48C: D65C000C 03FC010C FEDCBA98
	v_permlanex16_b32 v13, v13, s0, 0xfedcba98                 // 000000A0E498: D65C000D 03FC010D FEDCBA98
	v_permlanex16_b32 v14, v14, s0, 0xfedcba98                 // 000000A0E4A4: D65C000E 03FC010E FEDCBA98
	v_permlanex16_b32 v15, v15, s0, 0xfedcba98                 // 000000A0E4B0: D65C000F 03FC010F FEDCBA98
	v_permlanex16_b32 v16, v16, s0, 0xfedcba98                 // 000000A0E4BC: D65C0010 03FC0110 FEDCBA98
	.long 0xd44c0000                                           // 000000A0E4C8: D44C0000
	v_cndmask_b32_e32 v1, 16, v41, vcc_lo                      // 000000A0E4CC: 02025290
	s_barrier                                                  // 000000A0E4D0: BFBD0000
	buffer_gl0_inv                                             // 000000A0E4D4: E0AC0000 00000000
	s_and_saveexec_b32 s3, s0                                  // 000000A0E4DC: BE832000
	s_cbranch_execz 34                                         // 000000A0E4E0: BFA50022 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi3EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x686c>
	v_dual_add_f32 v16, v58, v16 :: v_dual_add_f32 v1, v59, v1 // 000000A0E4E4: C908213A 1000033B
	v_dual_add_f32 v2, v57, v2 :: v_dual_add_f32 v3, v56, v3   // 000000A0E4EC: C9080539 02020738
	v_lshl_or_b32 v17, v40, 10, v42                            // 000000A0E4F4: D6560011 04A91528
	v_dual_add_f32 v4, v55, v4 :: v_dual_add_f32 v5, v54, v5   // 000000A0E4FC: C9080937 04040B36
	v_dual_add_f32 v6, v53, v6 :: v_dual_add_f32 v7, v52, v7   // 000000A0E504: C9080D35 06060F34
	v_dual_add_f32 v8, v51, v8 :: v_dual_add_f32 v9, v50, v9   // 000000A0E50C: C9081133 08081332
	v_dual_add_f32 v10, v49, v10 :: v_dual_add_f32 v11, v48, v11// 000000A0E514: C9081531 0A0A1730
	v_dual_add_f32 v12, v47, v12 :: v_dual_add_f32 v13, v46, v13// 000000A0E51C: C908192F 0C0C1B2E
	v_dual_add_f32 v14, v45, v14 :: v_dual_add_f32 v15, v44, v15// 000000A0E524: C9081D2D 0E0E1F2C
	ds_store_2addr_b32 v17, v1, v2 offset1:16                  // 000000A0E52C: D8381000 00020111
	ds_store_2addr_b32 v17, v3, v4 offset0:32 offset1:48       // 000000A0E534: D8383020 00040311
	ds_store_2addr_b32 v17, v5, v6 offset0:64 offset1:80       // 000000A0E53C: D8385040 00060511
	ds_store_2addr_b32 v17, v7, v8 offset0:96 offset1:112      // 000000A0E544: D8387060 00080711
	ds_store_2addr_b32 v17, v9, v10 offset0:128 offset1:144    // 000000A0E54C: D8389080 000A0911
	ds_store_2addr_b32 v17, v11, v12 offset0:160 offset1:176   // 000000A0E554: D838B0A0 000C0B11
	ds_store_2addr_b32 v17, v13, v14 offset0:192 offset1:208   // 000000A0E55C: D838D0C0 000E0D11
	ds_store_2addr_b32 v17, v15, v16 offset0:224 offset1:240   // 000000A0E564: D838F0E0 00100F11
	s_or_b32 exec_lo, exec_lo, s3                              // 000000A0E56C: 8C7E037E
	s_waitcnt lgkmcnt(0)                                       // 000000A0E570: BF89FC07
	s_barrier                                                  // 000000A0E574: BFBD0000
	buffer_gl0_inv                                             // 000000A0E578: E0AC0000 00000000
	s_mov_b32 s3, exec_lo                                      // 000000A0E580: BE83007E
	v_cmpx_eq_u32_e32 0, v40                                   // 000000A0E584: 7D945080
	s_cbranch_execz 1332                                       // 000000A0E588: BFA50534 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi3EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x7d5c>
	v_and_b32_e32 v3, 15, v0                                   // 000000A0E58C: 3606008F
	s_mul_i32 s3, s1, 0xa00                                    // 000000A0E590: 9603FF01 00000A00
	s_mul_hi_i32 s4, s1, 0xa00                                 // 000000A0E598: 9704FF01 00000A00
	s_add_u32 s5, s18, s3                                      // 000000A0E5A0: 80050312
	s_addc_u32 s4, s19, s4                                     // 000000A0E5A4: 82040413
	v_lshlrev_b32_e32 v4, 2, v3                                // 000000A0E5A8: 30080682
	s_lshl_b32 s2, s2, 7                                       // 000000A0E5AC: 84028702
	ds_load_2addr_b32 v[1:2], v4 offset1:16                    // 000000A0E5B0: D8DC1000 01000004
	ds_load_2addr_b32 v[5:6], v4 offset0:128 offset1:144       // 000000A0E5B8: D8DC9080 05000004
	s_ashr_i32 s3, s2, 31                                      // 000000A0E5C0: 86039F02
	v_lshlrev_b32_e32 v52, 1, v0                               // 000000A0E5C4: 30680081
	s_lshl_b64 s[12:13], s[2:3], 1                             // 000000A0E5C8: 848C8102
	s_mul_i32 s2, s1, 0x500                                    // 000000A0E5CC: 9602FF01 00000500
	s_add_u32 s6, s5, s12                                      // 000000A0E5D4: 80060C05
	s_addc_u32 s7, s4, s13                                     // 000000A0E5D8: 82070D04
	s_mul_hi_i32 s1, s1, 0x500                                 // 000000A0E5DC: 9701FF01 00000500
	s_add_u32 s2, s20, s2                                      // 000000A0E5E4: 80020214
	s_addc_u32 s1, s21, s1                                     // 000000A0E5E8: 82010115
	s_add_u32 s8, s2, s12                                      // 000000A0E5EC: 80080C02
	s_addc_u32 s9, s1, s13                                     // 000000A0E5F0: 82090D01
	s_waitcnt lgkmcnt(1)                                       // 000000A0E5F4: BF89FC17
	v_add_f32_e32 v1, 0, v1                                    // 000000A0E5F8: 06020280
	v_add_nc_u32_e32 v45, 0x400, v4                            // 000000A0E5FC: 4A5A08FF 00000400
	s_waitcnt lgkmcnt(0)                                       // 000000A0E604: BF89FC07
	v_dual_add_f32 v5, 0, v5 :: v_dual_add_nc_u32 v46, 0x800, v4// 000000A0E608: C9200A80 052E08FF 00000800
	v_add_nc_u32_e32 v47, 0xc00, v4                            // 000000A0E614: 4A5E08FF 00000C00
	v_add_nc_u32_e32 v48, 0x1000, v4                           // 000000A0E61C: 4A6008FF 00001000
	v_add_nc_u32_e32 v49, 0x1400, v4                           // 000000A0E624: 4A6208FF 00001400
	v_add_nc_u32_e32 v50, 0x1800, v4                           // 000000A0E62C: 4A6408FF 00001800
	v_add_nc_u32_e32 v51, 0x1c00, v4                           // 000000A0E634: 4A6608FF 00001C00
	ds_load_2addr_b32 v[7:8], v45 offset1:16                   // 000000A0E63C: D8DC1000 0700002D
	ds_load_2addr_b32 v[9:10], v4 offset0:32 offset1:48        // 000000A0E644: D8DC3020 09000004
	ds_load_2addr_b32 v[11:12], v4 offset0:160 offset1:176     // 000000A0E64C: D8DCB0A0 0B000004
	ds_load_2addr_b32 v[13:14], v45 offset0:128 offset1:144    // 000000A0E654: D8DC9080 0D00002D
	ds_load_2addr_b32 v[15:16], v46 offset1:16                 // 000000A0E65C: D8DC1000 0F00002E
	ds_load_2addr_b32 v[17:18], v46 offset0:128 offset1:144    // 000000A0E664: D8DC9080 1100002E
	ds_load_2addr_b32 v[19:20], v47 offset1:16                 // 000000A0E66C: D8DC1000 1300002F
	ds_load_2addr_b32 v[21:22], v47 offset0:128 offset1:144    // 000000A0E674: D8DC9080 1500002F
	ds_load_2addr_b32 v[23:24], v48 offset1:16                 // 000000A0E67C: D8DC1000 17000030
	ds_load_2addr_b32 v[25:26], v48 offset0:128 offset1:144    // 000000A0E684: D8DC9080 19000030
	ds_load_2addr_b32 v[27:28], v49 offset1:16                 // 000000A0E68C: D8DC1000 1B000031
	ds_load_2addr_b32 v[29:30], v49 offset0:128 offset1:144    // 000000A0E694: D8DC9080 1D000031
	ds_load_2addr_b32 v[31:32], v50 offset1:16                 // 000000A0E69C: D8DC1000 1F000032
	ds_load_2addr_b32 v[33:34], v50 offset0:128 offset1:144    // 000000A0E6A4: D8DC9080 21000032
	ds_load_2addr_b32 v[35:36], v51 offset1:16                 // 000000A0E6AC: D8DC1000 23000033
	v_add_f32_e32 v2, 0, v2                                    // 000000A0E6B4: 06040480
	ds_load_2addr_b32 v[43:44], v46 offset0:32 offset1:48      // 000000A0E6B8: D8DC3020 2B00002E
	s_waitcnt lgkmcnt(15)                                      // 000000A0E6C0: BF89FCF7
	v_add_f32_e32 v1, v1, v7                                   // 000000A0E6C4: 06020F01
	v_dual_add_f32 v7, 0, v6 :: v_dual_add_f32 v2, v2, v8      // 000000A0E6C8: C9080C80 07021102
	s_waitcnt lgkmcnt(12)                                      // 000000A0E6D0: BF89FCC7
	v_add_f32_e32 v13, v5, v13                                 // 000000A0E6D4: 061A1B05
	ds_load_2addr_b32 v[5:6], v46 offset0:160 offset1:176      // 000000A0E6D8: D8DCB0A0 0500002E
	s_waitcnt lgkmcnt(12)                                      // 000000A0E6E0: BF89FCC7
	v_dual_add_f32 v1, v1, v15 :: v_dual_add_f32 v14, v7, v14  // 000000A0E6E4: C9081F01 010E1D07
	s_waitcnt lgkmcnt(11)                                      // 000000A0E6EC: BF89FCB7
	v_dual_add_f32 v2, v2, v16 :: v_dual_add_f32 v13, v13, v17 // 000000A0E6F0: C9082102 020C230D
	ds_load_2addr_b32 v[15:16], v48 offset0:32 offset1:48      // 000000A0E6F8: D8DC3020 0F000030
	v_add_f32_e32 v14, v14, v18                                // 000000A0E700: 061C250E
	s_waitcnt lgkmcnt(11)                                      // 000000A0E704: BF89FCB7
	v_dual_add_f32 v2, v2, v20 :: v_dual_add_f32 v1, v1, v19   // 000000A0E708: C9082902 02002701
	ds_load_2addr_b32 v[7:8], v47 offset0:32 offset1:48        // 000000A0E710: D8DC3020 0700002F
	ds_load_2addr_b32 v[17:18], v48 offset0:160 offset1:176    // 000000A0E718: D8DCB0A0 11000030
	s_waitcnt lgkmcnt(12)                                      // 000000A0E720: BF89FCC7
	v_add_f32_e32 v14, v14, v22                                // 000000A0E724: 061C2D0E
	s_waitcnt lgkmcnt(11)                                      // 000000A0E728: BF89FCB7
	v_dual_add_f32 v2, v2, v24 :: v_dual_add_f32 v1, v1, v23   // 000000A0E72C: C9083102 02002F01
	ds_load_2addr_b32 v[19:20], v49 offset0:32 offset1:48      // 000000A0E734: D8DC3020 13000031
	s_waitcnt lgkmcnt(11)                                      // 000000A0E73C: BF89FCB7
	v_add_f32_e32 v14, v14, v26                                // 000000A0E740: 061C350E
	ds_load_2addr_b32 v[37:38], v51 offset0:128 offset1:144    // 000000A0E744: D8DC9080 25000033
	ds_load_2addr_b32 v[39:40], v45 offset0:32 offset1:48      // 000000A0E74C: D8DC3020 2700002D
	ds_load_2addr_b32 v[41:42], v45 offset0:160 offset1:176    // 000000A0E754: D8DCB0A0 2900002D
	v_add_f32_e32 v13, v13, v21                                // 000000A0E75C: 061A2B0D
	s_waitcnt lgkmcnt(13)                                      // 000000A0E760: BF89FCD7
	v_add_f32_e32 v1, v1, v27                                  // 000000A0E764: 06023701
	v_add_f32_e32 v23, v2, v28                                 // 000000A0E768: 062E3902
	s_waitcnt lgkmcnt(12)                                      // 000000A0E76C: BF89FCC7
	v_dual_add_f32 v24, v14, v30 :: v_dual_add_f32 v9, 0, v9   // 000000A0E770: C9083D0E 18081280
	ds_load_2addr_b32 v[21:22], v49 offset0:160 offset1:176    // 000000A0E778: D8DCB0A0 15000031
	v_add_f32_e32 v11, 0, v11                                  // 000000A0E780: 06161680
	s_waitcnt lgkmcnt(11)                                      // 000000A0E784: BF89FCB7
	v_dual_add_f32 v1, v1, v31 :: v_dual_add_f32 v26, v24, v34 // 000000A0E788: C9083F01 011A4518
	s_waitcnt lgkmcnt(3)                                       // 000000A0E790: BF89FC37
	s_delay_alu instid0(VALU_DEP_1)                            // 000000A0E794: BF870001
	v_dual_add_f32 v13, v13, v25 :: v_dual_add_f32 v54, v26, v38// 000000A0E798: C908330D 0D364D1A
	s_waitcnt lgkmcnt(2)                                       // 000000A0E7A0: BF89FC27
	v_add_f32_e32 v9, v9, v39                                  // 000000A0E7A4: 06124F09
	v_add_f32_e32 v39, v1, v35                                 // 000000A0E7A8: 064E4701
	v_lshlrev_b32_e32 v1, 1, v3                                // 000000A0E7AC: 30020681
	s_waitcnt lgkmcnt(1)                                       // 000000A0E7B0: BF89FC17
	v_add_f32_e32 v3, v11, v41                                 // 000000A0E7B4: 0606530B
	v_add_f32_e32 v11, v23, v32                                // 000000A0E7B8: 06164117
	v_add_f32_e32 v9, v9, v43                                  // 000000A0E7BC: 06125709
	ds_load_2addr_b32 v[23:24], v50 offset0:32 offset1:48      // 000000A0E7C0: D8DC3020 17000032
	v_or_b32_e32 v41, 32, v52                                  // 000000A0E7C8: 385268A0
	v_add_f32_e32 v5, v3, v5                                   // 000000A0E7CC: 060A0B03
	v_add_f32_e32 v53, v11, v36                                // 000000A0E7D0: 066A490B
	v_add_f32_e32 v7, v9, v7                                   // 000000A0E7D4: 060E0F09
	global_load_d16_b16 v3, v41, s[6:7]                        // 000000A0E7D8: DC820000 03060029
	v_add_f32_e32 v7, v7, v15                                  // 000000A0E7E0: 060E1F07
	v_add_f32_e32 v15, 0, v12                                  // 000000A0E7E4: 061E1880
	ds_load_2addr_b32 v[11:12], v4 offset0:192 offset1:208     // 000000A0E7E8: D8DCD0C0 0B000004
	ds_load_2addr_b32 v[27:28], v51 offset0:32 offset1:48      // 000000A0E7F0: D8DC3020 1B000033
	v_add_f32_e32 v7, v7, v19                                  // 000000A0E7F8: 060E2707
	s_waitcnt lgkmcnt(2)                                       // 000000A0E7FC: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 000000A0E800: BF870001
	v_add_f32_e32 v19, v7, v23                                 // 000000A0E804: 06262F07
	v_add_f32_e32 v13, v13, v29                                // 000000A0E808: 061A3B0D
	ds_load_2addr_b32 v[29:30], v45 offset0:64 offset1:80      // 000000A0E80C: D8DC5040 1D00002D
	ds_load_2addr_b32 v[31:32], v45 offset0:192 offset1:208    // 000000A0E814: D8DCD0C0 1F00002D
	v_add_f32_e32 v25, v13, v33                                // 000000A0E81C: 0632430D
	ds_load_2addr_b32 v[13:14], v47 offset0:160 offset1:176    // 000000A0E820: D8DCB0A0 0D00002F
	s_waitcnt lgkmcnt(4)                                       // 000000A0E828: BF89FC47
	v_add_f32_e32 v11, 0, v11                                  // 000000A0E82C: 06161680
	v_add_f32_e32 v43, v25, v37                                // 000000A0E830: 06564B19
	ds_load_2addr_b32 v[25:26], v50 offset0:160 offset1:176    // 000000A0E834: D8DCB0A0 19000032
	ds_load_2addr_b32 v[37:38], v48 offset0:192 offset1:208    // 000000A0E83C: D8DCD0C0 25000030
	s_waitcnt lgkmcnt(3)                                       // 000000A0E844: BF89FC37
	v_add_f32_e32 v11, v11, v31                                // 000000A0E848: 06163F0B
	s_waitcnt lgkmcnt(2)                                       // 000000A0E84C: BF89FC27
	v_add_f32_e32 v5, v5, v13                                  // 000000A0E850: 060A1B05
	v_add_f32_e32 v13, 0, v10                                  // 000000A0E854: 061A1480
	ds_load_2addr_b32 v[9:10], v4 offset0:64 offset1:80        // 000000A0E858: D8DC5040 09000004
	v_add_f32_e32 v5, v5, v17                                  // 000000A0E860: 060A2305
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000A0E864: BF8701C1
	v_add_f32_e32 v17, v5, v21                                 // 000000A0E868: 06222B05
	v_add_f32_e32 v5, v13, v40                                 // 000000A0E86C: 060A510D
	v_add_f32_e32 v13, v15, v42                                // 000000A0E870: 061A550F
	s_waitcnt lgkmcnt(2)                                       // 000000A0E874: BF89FC27
	v_dual_add_f32 v40, v19, v27 :: v_dual_add_f32 v21, v17, v25// 000000A0E878: C9083713 28143311
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A0E880: BF870193
	v_add_f32_e32 v7, v5, v44                                  // 000000A0E884: 060E5905
	v_add_f32_e32 v13, v13, v6                                 // 000000A0E888: 061A0D0D
	ds_load_2addr_b32 v[5:6], v46 offset0:64 offset1:80        // 000000A0E88C: D8DC5040 0500002E
	ds_load_2addr_b32 v[33:34], v46 offset0:192 offset1:208    // 000000A0E894: D8DCD0C0 2100002E
	ds_load_2addr_b32 v[35:36], v51 offset0:160 offset1:176    // 000000A0E89C: D8DCB0A0 23000033
	v_add_f32_e32 v15, v7, v8                                  // 000000A0E8A4: 061E1107
	ds_load_2addr_b32 v[7:8], v47 offset0:64 offset1:80        // 000000A0E8A8: D8DC5040 0700002F
	v_add_f32_e32 v17, v13, v14                                // 000000A0E8B0: 06221D0D
	ds_load_2addr_b32 v[13:14], v47 offset0:192 offset1:208    // 000000A0E8B4: D8DCD0C0 0D00002F
	s_waitcnt lgkmcnt(5)                                       // 000000A0E8BC: BF89FC57
	v_add_f32_e32 v9, 0, v9                                    // 000000A0E8C0: 06121280
	v_add_f32_e32 v23, v15, v16                                // 000000A0E8C4: 062E210F
	ds_load_2addr_b32 v[15:16], v48 offset0:64 offset1:80      // 000000A0E8C8: D8DC5040 0F000030
	v_add_f32_e32 v17, v17, v18                                // 000000A0E8D0: 06222511
	v_add_f32_e32 v9, v9, v29                                  // 000000A0E8D4: 06123B09
	v_add_f32_e32 v23, v23, v20                                // 000000A0E8D8: 062E2917
	ds_load_2addr_b32 v[19:20], v49 offset0:192 offset1:208    // 000000A0E8DC: D8DCD0C0 13000031
	v_add_f32_e32 v22, v17, v22                                // 000000A0E8E4: 062C2D11
	ds_load_2addr_b32 v[17:18], v49 offset0:64 offset1:80      // 000000A0E8E8: D8DC5040 11000031
	s_waitcnt lgkmcnt(7)                                       // 000000A0E8F0: BF89FC77
	v_add_f32_e32 v5, v9, v5                                   // 000000A0E8F4: 060A0B09
	s_waitcnt lgkmcnt(5)                                       // 000000A0E8F8: BF89FC57
	v_dual_add_f32 v9, v11, v33 :: v_dual_add_f32 v42, v21, v35// 000000A0E8FC: C908430B 092A4715
	v_add_f32_e32 v27, v23, v24                                // 000000A0E904: 06363117
	v_add_f32_e32 v33, v22, v26                                // 000000A0E908: 06423516
	ds_load_2addr_b32 v[21:22], v50 offset0:64 offset1:80      // 000000A0E90C: D8DC5040 15000032
	ds_load_2addr_b32 v[23:24], v50 offset0:192 offset1:208    // 000000A0E914: D8DCD0C0 17000032
	s_waitcnt lgkmcnt(6)                                       // 000000A0E91C: BF89FC67
	v_add_f32_e32 v5, v5, v7                                   // 000000A0E920: 060A0F05
	s_waitcnt lgkmcnt(5)                                       // 000000A0E924: BF89FC57
	v_add_f32_e32 v7, v9, v13                                  // 000000A0E928: 060E1B09
	s_waitcnt lgkmcnt(4)                                       // 000000A0E92C: BF89FC47
	s_delay_alu instid0(VALU_DEP_2)                            // 000000A0E930: BF870002
	v_add_f32_e32 v13, v5, v15                                 // 000000A0E934: 061A1F05
	v_add_f32_e32 v5, 0, v10                                   // 000000A0E938: 060A1480
	ds_load_2addr_b32 v[9:10], v51 offset0:64 offset1:80       // 000000A0E93C: D8DC5040 09000033
	ds_load_2addr_b32 v[25:26], v51 offset0:192 offset1:208    // 000000A0E944: D8DCD0C0 19000033
	v_add_f32_e32 v7, v7, v37                                  // 000000A0E94C: 060E4B07
	v_add_f32_e32 v15, 0, v12                                  // 000000A0E950: 061E1880
	ds_load_2addr_b32 v[11:12], v4 offset0:96 offset1:112      // 000000A0E954: D8DC7060 0B000004
	v_add_f32_e32 v31, v5, v30                                 // 000000A0E95C: 063E3D05
	ds_load_2addr_b32 v[29:30], v4 offset0:224 offset1:240     // 000000A0E960: D8DCF0E0 1D000004
	s_waitcnt lgkmcnt(6)                                       // 000000A0E968: BF89FC67
	v_dual_add_f32 v13, v13, v17 :: v_dual_add_f32 v4, v15, v32// 000000A0E96C: C908230D 0D04410F
	v_add_f32_e32 v15, v7, v19                                 // 000000A0E974: 061E2707
	v_add_f32_e32 v17, v31, v6                                 // 000000A0E978: 06220D1F
	ds_load_2addr_b32 v[6:7], v45 offset0:96 offset1:112       // 000000A0E97C: D8DC7060 0600002D
	ds_load_2addr_b32 v[31:32], v45 offset0:224 offset1:240    // 000000A0E984: D8DCF0E0 1F00002D
	s_waitcnt lgkmcnt(7)                                       // 000000A0E98C: BF89FC77
	v_dual_add_f32 v13, v13, v21 :: v_dual_add_f32 v4, v4, v34 // 000000A0E990: C9082B0D 0D044504
	s_waitcnt lgkmcnt(6)                                       // 000000A0E998: BF89FC67
	v_dual_add_f32 v15, v15, v23 :: v_dual_add_f32 v8, v17, v8 // 000000A0E99C: C9082F0F 0F081111
	s_clause 0x1                                               // 000000A0E9A4: BF850001
	global_load_d16_b16 v2, v1, s[6:7]                         // 000000A0E9A8: DC820000 02060001
	global_load_d16_b16 v5, v1, s[6:7] offset:64               // 000000A0E9B0: DC820040 05060001
	v_dual_add_f32 v4, v4, v14 :: v_dual_add_f32 v37, v27, v28 // 000000A0E9B8: C9081D04 0424391B
	s_waitcnt lgkmcnt(5)                                       // 000000A0E9C0: BF89FC57
	v_add_f32_e32 v23, v13, v9                                 // 000000A0E9C4: 062E130D
	s_waitcnt lgkmcnt(4)                                       // 000000A0E9C8: BF89FC47
	v_dual_add_f32 v25, v15, v25 :: v_dual_add_f32 v8, v8, v16 // 000000A0E9CC: C908330F 19082108
	ds_load_2addr_b32 v[13:14], v46 offset0:96 offset1:112     // 000000A0E9D4: D8DC7060 0D00002E
	ds_load_2addr_b32 v[15:16], v46 offset0:224 offset1:240    // 000000A0E9DC: D8DCF0E0 0F00002E
	v_add_f32_e32 v9, v4, v38                                  // 000000A0E9E4: 06124D04
	s_waitcnt lgkmcnt(5)                                       // 000000A0E9E8: BF89FC57
	v_add_f32_e32 v11, 0, v11                                  // 000000A0E9EC: 06161680
	s_waitcnt lgkmcnt(4)                                       // 000000A0E9F0: BF89FC47
	v_dual_add_f32 v17, 0, v29 :: v_dual_add_f32 v38, v8, v18  // 000000A0E9F4: C9083A80 11262508
	v_add_f32_e32 v21, v33, v36                                // 000000A0E9FC: 062A4921
	v_add_f32_e32 v44, v9, v20                                 // 000000A0EA00: 06582909
	s_waitcnt lgkmcnt(2)                                       // 000000A0EA04: BF89FC27
	s_delay_alu instid0(VALU_DEP_3)                            // 000000A0EA08: BF870003
	v_dual_add_f32 v8, v11, v6 :: v_dual_add_f32 v11, v17, v31 // 000000A0EA0C: C9080D0B 080A3F11
	ds_load_2addr_b32 v[17:18], v47 offset0:96 offset1:112     // 000000A0EA14: D8DC7060 1100002F
	ds_load_2addr_b32 v[19:20], v47 offset0:224 offset1:240    // 000000A0EA1C: D8DCF0E0 1300002F
	ds_load_2addr_b32 v[27:28], v48 offset0:96 offset1:112     // 000000A0EA24: D8DC7060 1B000030
	ds_load_2addr_b32 v[33:34], v48 offset0:224 offset1:240    // 000000A0EA2C: D8DCF0E0 21000030
	v_add_f32_e32 v31, 0, v12                                  // 000000A0EA34: 063E1880
	v_add_f32_e32 v35, 0, v30                                  // 000000A0EA38: 06463C80
	s_clause 0x1                                               // 000000A0EA3C: BF850001
	global_load_d16_b16 v6, v41, s[6:7] offset:1280            // 000000A0EA40: DC820500 06060029
	global_load_d16_b16 v4, v1, s[6:7] offset:1280             // 000000A0EA48: DC820500 04060001
	v_or_b32_e32 v45, 0x60, v52                                // 000000A0EA50: 385A68FF 00000060
	v_add_f32_e32 v7, v31, v7                                  // 000000A0EA58: 060E0F1F
	s_waitcnt lgkmcnt(5)                                       // 000000A0EA5C: BF89FC57
	v_add_f32_e32 v13, v8, v13                                 // 000000A0EA60: 061A1B08
	global_load_d16_b16 v8, v41, s[8:9]                        // 000000A0EA64: DC820000 08080029
	s_waitcnt lgkmcnt(4)                                       // 000000A0EA6C: BF89FC47
	v_add_f32_e32 v15, v11, v15                                // 000000A0EA70: 061E1F0B
	ds_load_2addr_b32 v[11:12], v49 offset0:96 offset1:112     // 000000A0EA74: D8DC7060 0B000031
	ds_load_2addr_b32 v[29:30], v49 offset0:224 offset1:240    // 000000A0EA7C: D8DCF0E0 1D000031
	v_add_f32_e32 v41, v35, v32                                // 000000A0EA84: 06524123
	ds_load_2addr_b32 v[31:32], v50 offset0:96 offset1:112     // 000000A0EA88: D8DC7060 1F000032
	ds_load_2addr_b32 v[35:36], v50 offset0:224 offset1:240    // 000000A0EA90: D8DCF0E0 23000032
	v_add_f32_e32 v7, v7, v14                                  // 000000A0EA98: 060E1D07
	global_load_d16_b16 v9, v45, s[6:7]                        // 000000A0EA9C: DC820000 0906002D
	v_add_f32_e32 v41, v41, v16                                // 000000A0EAA4: 06522129
	s_waitcnt lgkmcnt(7)                                       // 000000A0EAA8: BF89FC77
	v_add_f32_e32 v17, v13, v17                                // 000000A0EAAC: 0622230D
	s_waitcnt lgkmcnt(6)                                       // 000000A0EAB0: BF89FC67
	v_add_f32_e32 v19, v15, v19                                // 000000A0EAB4: 0626270F
	ds_load_2addr_b32 v[13:14], v51 offset0:96 offset1:112     // 000000A0EAB8: D8DC7060 0D000033
	ds_load_2addr_b32 v[15:16], v51 offset0:224 offset1:240    // 000000A0EAC0: D8DCF0E0 0F000033
	v_dual_add_f32 v7, v7, v18 :: v_dual_add_f32 v18, v41, v20 // 000000A0EAC8: C9082507 07122929
	s_waitcnt lgkmcnt(7)                                       // 000000A0EAD0: BF89FC77
	v_add_f32_e32 v17, v17, v27                                // 000000A0EAD4: 06223711
	s_waitcnt lgkmcnt(6)                                       // 000000A0EAD8: BF89FC67
	v_dual_add_f32 v19, v19, v33 :: v_dual_add_f32 v20, v38, v22// 000000A0EADC: C9084313 13142D26
	v_dual_add_f32 v7, v7, v28 :: v_dual_add_f32 v18, v18, v34 // 000000A0EAE4: C9083907 07124512
	v_add_f32_e32 v22, v44, v24                                // 000000A0EAEC: 062C312C
	v_or_b32_e32 v28, 0xa0, v52                                // 000000A0EAF0: 383868FF 000000A0
	s_waitcnt lgkmcnt(5)                                       // 000000A0EAF8: BF89FC57
	v_add_f32_e32 v11, v17, v11                                // 000000A0EAFC: 06161711
	s_waitcnt lgkmcnt(4)                                       // 000000A0EB00: BF89FC47
	v_add_f32_e32 v17, v19, v29                                // 000000A0EB04: 06223B13
	v_dual_add_f32 v7, v7, v12 :: v_dual_add_f32 v12, v18, v30 // 000000A0EB08: C9081907 070C3D12
	s_waitcnt lgkmcnt(3)                                       // 000000A0EB10: BF89FC37
	v_dual_add_f32 v10, v20, v10 :: v_dual_add_f32 v11, v11, v31// 000000A0EB14: C9081514 0A0A3F0B
	s_waitcnt lgkmcnt(2)                                       // 000000A0EB1C: BF89FC27
	v_dual_add_f32 v17, v17, v35 :: v_dual_add_f32 v18, v22, v26// 000000A0EB20: C9084711 11123516
	v_add_f32_e32 v12, v12, v36                                // 000000A0EB28: 0618490C
	v_add_f32_e32 v7, v7, v32                                  // 000000A0EB2C: 060E4107
	s_waitcnt lgkmcnt(1)                                       // 000000A0EB30: BF89FC17
	v_add_f32_e32 v11, v11, v13                                // 000000A0EB34: 06161B0B
	s_waitcnt lgkmcnt(0)                                       // 000000A0EB38: BF89FC07
	v_add_f32_e32 v13, v17, v15                                // 000000A0EB3C: 061A1F11
	v_dual_add_f32 v19, v23, v10 :: v_dual_add_f32 v12, v12, v16// 000000A0EB40: C9081517 130C210C
	v_sub_f32_e32 v10, v23, v10                                // 000000A0EB48: 08141517
	v_dual_add_f32 v22, v43, v54 :: v_dual_add_f32 v23, v42, v21// 000000A0EB4C: C9086D2B 16162B2A
	v_add_f32_e32 v24, v25, v18                                // 000000A0EB54: 06302519
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A0EB58: BF870004
	v_add_f32_e32 v27, v13, v12                                // 000000A0EB5C: 0636190D
	v_add_f32_e32 v7, v7, v14                                  // 000000A0EB60: 060E1D07
	v_sub_f32_e32 v15, v39, v53                                // 000000A0EB64: 081E6B27
	v_add_f32_e32 v16, v40, v37                                // 000000A0EB68: 06204B28
	v_dual_sub_f32 v17, v40, v37 :: v_dual_add_f32 v30, v22, v23// 000000A0EB6C: C9484B28 111E2F16
	v_add_f32_e32 v31, v24, v27                                // 000000A0EB74: 063E3718
	v_dual_add_f32 v20, v11, v7 :: v_dual_and_b32 v37, 1, v0   // 000000A0EB78: C9240F0B 14240081
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000A0EB80: BF870223
	v_add_f32_e32 v36, v15, v17                                // 000000A0EB84: 0648230F
	v_sub_f32_e32 v15, v15, v17                                // 000000A0EB88: 081E230F
	v_add_f32_e32 v17, v30, v31                                // 000000A0EB8C: 06223F1E
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A0EB90: BF870004
	.long 0xd44a0002                                           // 000000A0EB94: D44A0002
	v_cndmask_b32_e32 v1, 0, v37, vcc_lo                       // 000000A0EB98: 02024A80
	v_add_f32_e32 v14, v39, v53                                // 000000A0EB9C: 061C6B27
	v_add_f32_e32 v39, v19, v20                                // 000000A0EBA0: 064E2913
	v_sub_f32_e32 v19, v19, v20                                // 000000A0EBA4: 08262913
	v_mov_b32_dpp v20, v17 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A0EBA8: 7E2802FA FF016111
	v_cndmask_b32_e64 v17, -v17, v17, s2                       // 000000A0EBB0: D5010011 200A2311
	v_sub_f32_e32 v37, v43, v54                                // 000000A0EBB8: 084A6D2B
	v_dual_sub_f32 v21, v42, v21 :: v_dual_sub_f32 v18, v25, v18// 000000A0EBBC: C94A2B2A 15122519
	v_dual_sub_f32 v12, v13, v12 :: v_dual_sub_f32 v11, v11, v7// 000000A0EBC4: C94A190D 0C0A0F0B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000A0EBCC: BF8701A4
	v_add_f32_e32 v13, v17, v20                                // 000000A0EBD0: 061A2911
	v_and_b32_e32 v17, 2, v0                                   // 000000A0EBD4: 36220082
	v_dual_add_f32 v25, v37, v21 :: v_dual_add_f32 v40, v18, v12// 000000A0EBD8: C9082B25 19281912
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000A0EBE0: BF870224
	v_add_f32_e32 v20, v10, v11                                // 000000A0EBE4: 0628170A
	v_sub_f32_e32 v10, v10, v11                                // 000000A0EBE8: 0814170A
	.long 0xd44a0003                                           // 000000A0EBEC: D44A0003
	v_cndmask_b32_e32 v1, 0, v17, vcc_lo                       // 000000A0EBF0: 02022280
	v_sub_f32_e32 v17, v22, v23                                // 000000A0EBF4: 08222F16
	v_dual_add_f32 v11, v25, v40 :: v_dual_sub_f32 v22, v24, v27// 000000A0EBF8: C90A5119 0B163718
	v_and_b32_e32 v23, 4, v0                                   // 000000A0EC00: 362E0084
	v_mov_b32_dpp v41, v13 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A0EC04: 7E5202FA FF01620D
	v_cndmask_b32_e64 v13, -v13, v13, s3                       // 000000A0EC0C: D501000D 200E1B0D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 000000A0EC14: BF870254
	v_mov_b32_dpp v24, v11 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A0EC18: 7E3002FA FF01610B
	v_cndmask_b32_e64 v11, -v11, v11, s2                       // 000000A0EC20: D501000B 200A170B
	v_add_f32_e32 v27, v17, v22                                // 000000A0EC28: 06362D11
	.long 0xd44a0004                                           // 000000A0EC2C: D44A0004
	v_cndmask_b32_e32 v1, 0, v23, vcc_lo                       // 000000A0EC30: 02022E80
	v_dual_add_f32 v13, v13, v41 :: v_dual_and_b32 v0, 8, v0   // 000000A0EC34: C924530D 0D000088
	v_add_f32_e32 v11, v11, v24                                // 000000A0EC3C: 0616310B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000A0EC40: BF870224
	v_mov_b32_dpp v23, v27 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A0EC44: 7E2E02FA FF01611B
	v_cndmask_b32_e64 v24, -v27, v27, s2                       // 000000A0EC4C: D5010018 200A371B
	.long 0xd44a0001                                           // 000000A0EC54: D44A0001
	v_cndmask_b32_e32 v1, 0, v0, vcc_lo                        // 000000A0EC58: 02020080
	v_sub_f32_e32 v0, v37, v21                                 // 000000A0EC5C: 08002B25
	v_mov_b32_dpp v27, v11 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A0EC60: 7E3602FA FF01620B
	v_cndmask_b32_e64 v11, -v11, v11, s3                       // 000000A0EC68: D501000B 200E170B
	v_dual_add_f32 v23, v24, v23 :: v_dual_sub_f32 v12, v18, v12// 000000A0EC70: C90A2F18 170C1912
	v_mov_b32_dpp v41, v13 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A0EC78: 7E5202FA FF01640D
	v_cndmask_b32_e64 v13, -v13, v13, s4                       // 000000A0EC80: D501000D 20121B0D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A0EC88: BF870214
	v_add_f32_e32 v11, v11, v27                                // 000000A0EC8C: 0616370B
	v_mov_b32_dpp v18, v23 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A0EC90: 7E2402FA FF016217
	v_cndmask_b32_e64 v21, -v23, v23, s3                       // 000000A0EC98: D5010015 200E2F17
	v_sub_f32_e32 v24, v25, v40                                // 000000A0ECA0: 08305119
	v_add_f32_e32 v13, v13, v41                                // 000000A0ECA4: 061A530D
	v_mov_b32_dpp v25, v11 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A0ECA8: 7E3202FA FF01640B
	v_cndmask_b32_e64 v11, -v11, v11, s4                       // 000000A0ECB0: D501000B 2012170B
	v_dual_add_f32 v18, v21, v18 :: v_dual_add_f32 v21, v0, v12// 000000A0ECB8: C9082515 12141900
	v_sub_f32_e32 v23, v30, v31                                // 000000A0ECC0: 082E3F1E
	v_sub_f32_e32 v17, v17, v22                                // 000000A0ECC4: 08222D11
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A0ECC8: BF870214
	v_add_f32_e32 v11, v11, v25                                // 000000A0ECCC: 0616330B
	v_mov_b32_dpp v25, v18 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A0ECD0: 7E3202FA FF016412
	v_cndmask_b32_e64 v18, -v18, v18, s4                       // 000000A0ECD8: D5010012 20122512
	v_mov_b32_dpp v30, v21 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A0ECE0: 7E3C02FA FF016115
	v_cndmask_b32_e64 v21, -v21, v21, s2                       // 000000A0ECE8: D5010015 200A2B15
	v_mov_b32_dpp v22, v13 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A0ECF0: 7E2C02FA FF01680D
	v_cndmask_b32_e64 v13, -v13, v13, s1                       // 000000A0ECF8: D501000D 20061B0D
	v_add_f32_e32 v18, v18, v25                                // 000000A0ED00: 06243312
	v_add_f32_e32 v29, v14, v16                                // 000000A0ED04: 063A210E
	v_dual_add_f32 v21, v21, v30 :: v_dual_sub_f32 v14, v14, v16// 000000A0ED08: C90A3D15 150E210E
	v_or_b32_e32 v16, 0xe0, v52                                // 000000A0ED10: 382068FF 000000E0
	v_sub_f32_e32 v0, v0, v12                                  // 000000A0ED18: 08001900
	v_add_f32_e32 v12, v13, v22                                // 000000A0ED1C: 06182D0D
	v_mov_b32_dpp v13, v18 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A0ED20: 7E1A02FA FF016812
	v_mov_b32_dpp v22, v21 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A0ED28: 7E2C02FA FF016215
	v_cndmask_b32_e64 v21, -v21, v21, s3                       // 000000A0ED30: D5010015 200E2B15
	v_cndmask_b32_e64 v18, -v18, v18, s1                       // 000000A0ED38: D5010012 20062512
	v_mov_b32_dpp v25, v23 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A0ED40: 7E3202FA FF016117
	v_cndmask_b32_e64 v23, -v23, v23, s2                       // 000000A0ED48: D5010017 200A2F17
	global_load_d16_b16 v38, v16, s[6:7]                       // 000000A0ED50: DC820000 26060010
	v_add_f32_e32 v21, v21, v22                                // 000000A0ED58: 062A2D15
	v_add_f32_e32 v13, v18, v13                                // 000000A0ED5C: 061A1B12
	global_load_d16_b16 v22, v28, s[6:7] offset:1280           // 000000A0ED60: DC820500 1606001C
	v_add_f32_e32 v18, v23, v25                                // 000000A0ED68: 06243317
	s_clause 0x7                                               // 000000A0ED6C: BF850007
	global_load_d16_b16 v25, v16, s[6:7] offset:1280           // 000000A0ED70: DC820500 19060010
	global_load_d16_b16 v26, v1, s[6:7] offset:128             // 000000A0ED78: DC820080 1A060001
	global_load_d16_b16 v32, v28, s[6:7]                       // 000000A0ED80: DC820000 2006001C
	global_load_d16_b16 v33, v1, s[6:7] offset:1344            // 000000A0ED88: DC820540 21060001
	global_load_d16_b16 v7, v1, s[6:7] offset:1408             // 000000A0ED90: DC820580 07060001
	global_load_d16_b16 v34, v1, s[6:7] offset:1472            // 000000A0ED98: DC8205C0 22060001
	global_load_d16_b16 v35, v1, s[6:7] offset:192             // 000000A0EDA0: DC8200C0 23060001
	global_load_d16_b16 v27, v45, s[6:7] offset:1280           // 000000A0EDA8: DC820500 1B06002D
	v_mov_b32_dpp v23, v21 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A0EDB0: 7E2E02FA FF016415
	v_cndmask_b32_e64 v21, -v21, v21, s4                       // 000000A0EDB8: D5010015 20122B15
	s_clause 0x5                                               // 000000A0EDC0: BF850005
	global_load_d16_b16 v28, v28, s[8:9]                       // 000000A0EDC4: DC820000 1C08001C
	global_load_d16_b16 v16, v16, s[8:9]                       // 000000A0EDCC: DC820000 10080010
	global_load_d16_b16 v37, v1, s[8:9]                        // 000000A0EDD4: DC820000 25080001
	global_load_d16_b16 v40, v1, s[8:9] offset:64              // 000000A0EDDC: DC820040 28080001
	global_load_d16_b16 v41, v1, s[8:9] offset:128             // 000000A0EDE4: DC820080 29080001
	global_load_d16_b16 v42, v1, s[8:9] offset:192             // 000000A0EDEC: DC8200C0 2A080001
	v_mov_b32_dpp v31, v11 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A0EDF4: 7E3E02FA FF01680B
	v_add_f32_e32 v21, v21, v23                                // 000000A0EDFC: 062A2F15
	global_load_d16_b16 v23, v45, s[8:9]                       // 000000A0EE00: DC820000 1708002D
	v_cndmask_b32_e64 v11, -v11, v11, s1                       // 000000A0EE08: D501000B 2006170B
	v_mov_b32_dpp v30, v18 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A0EE10: 7E3C02FA FF016212
	v_cndmask_b32_e64 v18, -v18, v18, s3                       // 000000A0EE18: D5010012 200E2512
	v_add_f32_e32 v43, v36, v20                                // 000000A0EE20: 06562924
	v_mov_b32_dpp v47, v24 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A0EE24: 7E5E02FA FF016118
	v_add_f32_e32 v11, v11, v31                                // 000000A0EE2C: 06163F0B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A0EE30: BF870214
	v_dual_add_f32 v31, v29, v39 :: v_dual_add_f32 v18, v18, v30// 000000A0EE34: C9084F1D 1F123D12
	v_mov_b32_dpp v45, v43 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A0EE3C: 7E5A02FA FF01612B
	v_cndmask_b32_e64 v43, -v43, v43, s2                       // 000000A0EE44: D501002B 200A572B
	v_cndmask_b32_e64 v24, -v24, v24, s2                       // 000000A0EE4C: D5010018 200A3118
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A0EE54: BF870004
	v_mov_b32_dpp v30, v31 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A0EE58: 7E3C02FA FF01611F
	v_cndmask_b32_e64 v31, -v31, v31, s2                       // 000000A0EE60: D501001F 200A3F1F
	v_mov_b32_dpp v44, v21 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A0EE68: 7E5802FA FF016815
	v_add_f32_e32 v43, v43, v45                                // 000000A0EE70: 06565B2B
	v_cndmask_b32_e64 v21, -v21, v21, s1                       // 000000A0EE74: D5010015 20062B15
	v_add_f32_e32 v24, v24, v47                                // 000000A0EE7C: 06305F18
	v_add_f32_e32 v30, v31, v30                                // 000000A0EE80: 063C3D1F
	v_mov_b32_dpp v31, v18 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A0EE84: 7E3E02FA FF016412
	v_cndmask_b32_e64 v18, -v18, v18, s4                       // 000000A0EE8C: D5010012 20122512
	v_add_f32_e32 v21, v21, v44                                // 000000A0EE94: 062A5915
	v_mul_f32_e32 v12, 0x3db504f3, v12                         // 000000A0EE98: 101818FF 3DB504F3
	v_mov_b32_dpp v46, v30 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A0EEA0: 7E5C02FA FF01621E
	v_cndmask_b32_e64 v30, -v30, v30, s3                       // 000000A0EEA8: D501001E 200E3D1E
	v_add_f32_e32 v18, v18, v31                                // 000000A0EEB0: 06243F12
	v_mov_b32_dpp v31, v43 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A0EEB4: 7E3E02FA FF01622B
	v_cndmask_b32_e64 v43, -v43, v43, s3                       // 000000A0EEBC: D501002B 200E572B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000A0EEC4: BF870234
	v_dual_sub_f32 v29, v29, v39 :: v_dual_add_f32 v30, v30, v46// 000000A0EEC8: C9484F1D 1D1E5D1E
	v_mov_b32_dpp v46, v24 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A0EED0: 7E5C02FA FF016218
	v_cndmask_b32_e64 v24, -v24, v24, s3                       // 000000A0EED8: D5010018 200E3118
	v_add_f32_e32 v31, v43, v31                                // 000000A0EEE0: 063E3F2B
	v_mov_b32_dpp v43, v18 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A0EEE4: 7E5602FA FF016812
	v_mov_b32_dpp v45, v30 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A0EEEC: 7E5A02FA FF01641E
	v_cndmask_b32_e64 v30, -v30, v30, s4                       // 000000A0EEF4: D501001E 20123D1E
	v_add_f32_e32 v24, v24, v46                                // 000000A0EEFC: 06305D18
	v_mov_b32_dpp v44, v31 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A0EF00: 7E5802FA FF01641F
	v_cndmask_b32_e64 v31, -v31, v31, s4                       // 000000A0EF08: D501001F 20123F1F
	v_mov_b32_dpp v46, v17 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A0EF10: 7E5C02FA FF016111
	v_add_f32_e32 v30, v30, v45                                // 000000A0EF18: 063C5B1E
	v_cndmask_b32_e64 v17, -v17, v17, s2                       // 000000A0EF1C: D5010011 200A2311
	v_cndmask_b32_e64 v18, -v18, v18, s1                       // 000000A0EF24: D5010012 20062512
	v_add_f32_e32 v31, v31, v44                                // 000000A0EF2C: 063E591F
	v_mov_b32_dpp v44, v24 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A0EF30: 7E5802FA FF016418
	v_mov_b32_dpp v45, v30 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A0EF38: 7E5A02FA FF01681E
	v_cndmask_b32_e64 v30, -v30, v30, s1                       // 000000A0EF40: D501001E 20063D1E
	v_add_f32_e32 v17, v17, v46                                // 000000A0EF48: 06225D11
	v_cndmask_b32_e64 v24, -v24, v24, s4                       // 000000A0EF4C: D5010018 20123118
	v_add_f32_e32 v18, v18, v43                                // 000000A0EF54: 06245712
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A0EF58: BF870004
	v_dual_mul_f32 v11, 0x3db504f3, v11 :: v_dual_add_f32 v30, v30, v45// 000000A0EF5C: C8C816FF 0B1E5B1E 3DB504F3
	v_mov_b32_dpp v45, v31 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A0EF68: 7E5A02FA FF01681F
	v_cndmask_b32_e64 v31, -v31, v31, s1                       // 000000A0EF70: D501001F 20063F1F
	v_mov_b32_dpp v46, v17 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A0EF78: 7E5C02FA FF016211
	v_cndmask_b32_e64 v17, -v17, v17, s3                       // 000000A0EF80: D5010011 200E2311
	v_mul_f32_e32 v30, 0x3db504f3, v30                         // 000000A0EF88: 103C3CFF 3DB504F3
	v_add_f32_e32 v24, v24, v44                                // 000000A0EF90: 06305918
	v_dual_sub_f32 v20, v36, v20 :: v_dual_mul_f32 v13, 0x3db504f3, v13// 000000A0EF94: C9462924 140C1AFF 3DB504F3
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000A0EFA0: BF8701A4
	v_add_f32_e32 v17, v17, v46                                // 000000A0EFA4: 06225D11
	v_dual_mul_f32 v21, 0x3db504f3, v21 :: v_dual_mul_f32 v18, 0x3db504f3, v18// 000000A0EFA8: C8C62AFF 151224FF 3DB504F3
	v_mov_b32_dpp v36, v20 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A0EFB4: 7E4802FA FF016114
	v_cndmask_b32_e64 v20, -v20, v20, s2                       // 000000A0EFBC: D5010014 200A2914
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000A0EFC4: BF8700A4
	v_mov_b32_dpp v44, v17 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A0EFC8: 7E5802FA FF016411
	v_cndmask_b32_e64 v17, -v17, v17, s4                       // 000000A0EFD0: D5010011 20122311
	v_add_f32_e32 v17, v17, v44                                // 000000A0EFD8: 06225911
	v_mov_b32_dpp v44, v0 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A0EFDC: 7E5802FA FF016100
	v_cndmask_b32_e64 v0, -v0, v0, s2                          // 000000A0EFE4: D5010000 200A0100
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A0EFEC: BF870211
	v_add_f32_e32 v0, v0, v44                                  // 000000A0EFF0: 06005900
	v_mov_b32_dpp v44, v17 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A0EFF4: 7E5802FA FF016811
	v_cndmask_b32_e64 v17, -v17, v17, s1                       // 000000A0EFFC: D5010011 20062311
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A0F004: BF870091
	v_add_f32_e32 v17, v17, v44                                // 000000A0F008: 06225911
	v_mul_f32_e32 v17, 0x3db504f3, v17                         // 000000A0F00C: 102222FF 3DB504F3
	s_waitcnt vmcnt(22)                                        // 000000A0F014: BF895BF7
	v_fma_mix_f32 v2, v2, v30, neg(0) op_sel_hi:[1,0,0]        // 000000A0F018: CC200002 8A023D02
	v_add_f32_e32 v30, v31, v45                                // 000000A0F020: 063C5B1F
	v_mov_b32_dpp v31, v24 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A0F024: 7E3E02FA FF016818
	v_cndmask_b32_e64 v24, -v24, v24, s1                       // 000000A0F02C: D5010018 20063118
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A0F034: BF870214
	v_mul_f32_e32 v43, 0xbfb8aa3b, v2                          // 000000A0F038: 105604FF BFB8AA3B
	v_mul_f32_e32 v30, 0x3db504f3, v30                         // 000000A0F040: 103C3CFF 3DB504F3
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000A0F048: BF870223
	v_add_f32_e32 v24, v24, v31                                // 000000A0F04C: 06303F18
	v_add_f32_e32 v31, v14, v19                                // 000000A0F050: 063E270E
	v_exp_f32_e32 v43, v43                                     // 000000A0F054: 7E564B2B
	s_delay_alu instid0(VALU_DEP_3)                            // 000000A0F058: BF870003
	v_fma_mix_f32 v3, v3, v30, neg(0) op_sel_hi:[1,0,0]        // 000000A0F05C: CC200003 8A023D03
	v_sub_f32_e32 v14, v14, v19                                // 000000A0F064: 081C270E
	v_mul_f32_e32 v24, 0x3db504f3, v24                         // 000000A0F068: 103030FF 3DB504F3
	v_mov_b32_dpp v45, v31 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A0F070: 7E5A02FA FF01611F
	v_cndmask_b32_e64 v31, -v31, v31, s2                       // 000000A0F078: D501001F 200A3F1F
	v_mul_f32_e32 v30, 0xbfb8aa3b, v3                          // 000000A0F080: 103C06FF BFB8AA3B
	v_mov_b32_dpp v19, v14 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A0F088: 7E2602FA FF01610E
	v_cndmask_b32_e64 v14, -v14, v14, s2                       // 000000A0F090: D501000E 200A1D0E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A0F098: BF870215
	v_add_f32_e32 v43, 1.0, v43                                // 000000A0F09C: 065656F2
	v_exp_f32_e32 v30, v30                                     // 000000A0F0A0: 7E3C4B1E
	v_add_f32_e32 v31, v31, v45                                // 000000A0F0A4: 063E5B1F
	v_mov_b32_dpp v45, v0 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A0F0A8: 7E5A02FA FF016200
	v_cndmask_b32_e64 v0, -v0, v0, s3                          // 000000A0F0B0: D5010000 200E0100
	v_div_scale_f32 v46, null, v43, v43, v2                    // 000000A0F0B8: D6FC7C2E 040A572B
	s_waitcnt vmcnt(19)                                        // 000000A0F0C0: BF894FF7
	v_fma_mix_f32 v4, v4, v12, neg(0) op_sel_hi:[1,0,0]        // 000000A0F0C4: CC200004 8A021904
	v_mov_b32_dpp v48, v31 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A0F0CC: 7E6002FA FF01621F
	v_cndmask_b32_e64 v31, -v31, v31, s3                       // 000000A0F0D4: D501001F 200E3F1F
	v_add_f32_e32 v0, v0, v45                                  // 000000A0F0DC: 06005B00
	v_rcp_f32_e32 v47, v46                                     // 000000A0F0E0: 7E5E552E
	v_add_f32_e32 v30, 1.0, v30                                // 000000A0F0E4: 063C3CF2
	v_fma_mix_f32 v6, v6, v11, neg(0) op_sel_hi:[1,0,0]        // 000000A0F0E8: CC200006 8A021706
	v_add_f32_e32 v31, v31, v48                                // 000000A0F0F0: 063E611F
	v_mov_b32_dpp v44, v0 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A0F0F4: 7E5802FA FF016400
	v_cndmask_b32_e64 v0, -v0, v0, s4                          // 000000A0F0FC: D5010000 20120100
	v_div_scale_f32 v45, null, v30, v30, v3                    // 000000A0F104: D6FC7C2D 040E3D1E
	v_add_f32_e32 v14, v14, v19                                // 000000A0F10C: 061C270E
	v_mov_b32_dpp v50, v31 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A0F110: 7E6402FA FF01641F
	v_cndmask_b32_e64 v31, -v31, v31, s4                       // 000000A0F118: D501001F 20123F1F
	v_add_f32_e32 v0, v0, v44                                  // 000000A0F120: 06005900
	v_rcp_f32_e32 v48, v45                                     // 000000A0F124: 7E60552D
	v_add_f32_e32 v44, v15, v10                                // 000000A0F128: 0658150F
	v_fma_f32 v49, -v46, v47, 1.0                              // 000000A0F12C: D6130031 23CA5F2E
	v_add_f32_e32 v31, v31, v50                                // 000000A0F134: 063E651F
	v_sub_f32_e32 v10, v15, v10                                // 000000A0F138: 0814150F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(TRANS32_DEP_1)// 000000A0F13C: BF8702C4
	v_mov_b32_dpp v51, v44 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A0F140: 7E6602FA FF01612C
	v_cndmask_b32_e64 v44, -v44, v44, s2                       // 000000A0F148: D501002C 200A592C
	v_fmac_f32_e32 v47, v49, v47                               // 000000A0F150: 565E5F31
	v_div_scale_f32 v49, vcc_lo, v2, v43, v2                   // 000000A0F154: D6FC6A31 040A5702
	v_fma_f32 v50, -v45, v48, 1.0                              // 000000A0F15C: D6130032 23CA612D
	v_mov_b32_dpp v52, v31 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A0F164: 7E6802FA FF01681F
	v_cndmask_b32_e64 v31, -v31, v31, s1                       // 000000A0F16C: D501001F 20063F1F
	v_add_f32_e32 v44, v44, v51                                // 000000A0F174: 0658672C
	v_mov_b32_dpp v51, v0 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A0F178: 7E6602FA FF016800
	v_fmac_f32_e32 v48, v50, v48                               // 000000A0F180: 56606132
	v_div_scale_f32 v50, s5, v3, v30, v3                       // 000000A0F184: D6FC0532 040E3D03
	v_dual_add_f32 v31, v31, v52 :: v_dual_mul_f32 v52, v49, v47// 000000A0F18C: C906691F 1F345F31
	v_mov_b32_dpp v54, v44 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A0F194: 7E6C02FA FF01622C
	v_cndmask_b32_e64 v44, -v44, v44, s3                       // 000000A0F19C: D501002C 200E592C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A0F1A4: BF870214
	v_mul_f32_e32 v53, v50, v48                                // 000000A0F1A8: 106A6132
	v_mul_f32_e32 v31, 0x3db504f3, v31                         // 000000A0F1AC: 103E3EFF 3DB504F3
	v_fma_f32 v55, -v46, v52, v49                              // 000000A0F1B4: D6130037 24C6692E
	v_cndmask_b32_e64 v0, -v0, v0, s1                          // 000000A0F1BC: D5010000 20060100
	v_add_f32_e32 v44, v44, v54                                // 000000A0F1C4: 06586D2C
	v_fma_f32 v56, -v45, v53, v50                              // 000000A0F1C8: D6130038 24CA6B2D
	v_fma_mix_f32 v5, v5, v31, neg(0) op_sel_hi:[1,0,0]        // 000000A0F1D0: CC200005 8A023F05
	v_fmac_f32_e32 v52, v55, v47                               // 000000A0F1D8: 56685F37
	v_add_f32_e32 v0, v0, v51                                  // 000000A0F1DC: 06006700
	v_mov_b32_dpp v31, v44 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A0F1E0: 7E3E02FA FF01642C
	v_cndmask_b32_e64 v44, -v44, v44, s4                       // 000000A0F1E8: D501002C 2012592C
	v_fmac_f32_e32 v53, v56, v48                               // 000000A0F1F0: 566A6138
	v_fma_f32 v46, -v46, v52, v49                              // 000000A0F1F4: D613002E 24C6692E
	v_mul_f32_e32 v51, 0xbfb8aa3b, v5                          // 000000A0F1FC: 10660AFF BFB8AA3B
	v_mov_b32_dpp v19, v10 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A0F204: 7E2602FA FF01610A
	v_add_f32_e32 v31, v44, v31                                // 000000A0F20C: 063E3F2C
	v_fma_f32 v45, -v45, v53, v50                              // 000000A0F210: D613002D 24CA6B2D
	v_div_fmas_f32 v44, v46, v47, v52                          // 000000A0F218: D637002C 04D25F2E
	s_mov_b32 vcc_lo, s5                                       // 000000A0F220: BEEA0005
	v_exp_f32_e32 v49, v51                                     // 000000A0F224: 7E624B33
	v_mov_b32_dpp v46, v31 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A0F228: 7E5C02FA FF01681F
	v_cndmask_b32_e64 v31, -v31, v31, s1                       // 000000A0F230: D501001F 20063F1F
	v_div_fmas_f32 v45, v45, v48, v53                          // 000000A0F238: D637002D 04D6612D
	v_div_fixup_f32 v2, v44, v43, v2                           // 000000A0F240: D6270002 040A572C
	v_cndmask_b32_e64 v10, -v10, v10, s2                       // 000000A0F248: D501000A 200A150A
	v_mul_f32_e32 v0, 0x3db504f3, v0                           // 000000A0F250: 100000FF 3DB504F3
	v_add_f32_e32 v12, v31, v46                                // 000000A0F258: 06185D1F
	v_mov_b32_dpp v31, v29 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A0F25C: 7E3E02FA FF01611D
	v_cndmask_b32_e64 v29, -v29, v29, s2                       // 000000A0F264: D501001D 200A3B1D
	v_div_fixup_f32 v3, v45, v30, v3                           // 000000A0F26C: D6270003 040E3D2D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000A0F274: BF870224
	v_dual_mul_f32 v2, v4, v2 :: v_dual_mul_f32 v11, 0x3db504f3, v12// 000000A0F278: C8C60504 020A18FF 3DB504F3
	v_add_f32_e32 v10, v10, v19                                // 000000A0F284: 0614270A
	v_add_f32_e32 v4, v29, v31                                 // 000000A0F288: 06083F1D
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A0F28C: BF870004
	v_mul_f32_e32 v3, v6, v3                                   // 000000A0F290: 10060706
	v_add_f32_e32 v47, 1.0, v49                                // 000000A0F294: 065E62F2
	s_waitcnt vmcnt(17)                                        // 000000A0F298: BF8947F7
	v_fma_mix_f32 v6, v9, v11, neg(0) op_sel_hi:[1,0,0]        // 000000A0F29C: CC200006 8A021709
	v_add_f32_e32 v9, v20, v36                                 // 000000A0F2A4: 06124914
	v_mov_b32_dpp v20, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A0F2A8: 7E2802FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, s3                          // 000000A0F2B0: D5010004 200E0904
	v_fma_mix_f32 v3, v8, v3, neg(0) op_sel_hi:[1,0,0]         // 000000A0F2B8: CC200003 8A020708
	v_mul_f32_e32 v8, 0xbfb8aa3b, v6                           // 000000A0F2C0: 10100CFF BFB8AA3B
	v_mov_b32_dpp v29, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A0F2C8: 7E3A02FA FF016209
	v_cndmask_b32_e64 v9, -v9, v9, s3                          // 000000A0F2D0: D5010009 200E1309
	v_add_f32_e32 v4, v4, v20                                  // 000000A0F2D8: 06082904
	v_div_scale_f32 v30, null, v47, v47, v5                    // 000000A0F2DC: D6FC7C1E 04165F2F
	v_exp_f32_e32 v8, v8                                       // 000000A0F2E4: 7E104B08
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A0F2E8: BF870193
	v_add_f32_e32 v9, v9, v29                                  // 000000A0F2EC: 06123B09
	v_mov_b32_dpp v15, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A0F2F0: 7E1E02FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s4                          // 000000A0F2F8: D5010004 20120904
	v_mov_b32_dpp v29, v14 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A0F300: 7E3A02FA FF01620E
	v_cndmask_b32_e64 v14, -v14, v14, s3                       // 000000A0F308: D501000E 200E1D0E
	v_mov_b32_dpp v20, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A0F310: 7E2802FA FF016409
	v_cndmask_b32_e64 v9, -v9, v9, s4                          // 000000A0F318: D5010009 20121309
	v_add_f32_e32 v4, v4, v15                                  // 000000A0F320: 06081F04
	v_mov_b32_dpp v15, v10 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A0F324: 7E1E02FA FF01620A
	v_add_f32_e32 v14, v14, v29                                // 000000A0F32C: 061C3B0E
	v_cndmask_b32_e64 v10, -v10, v10, s3                       // 000000A0F330: D501000A 200E150A
	v_add_f32_e32 v9, v9, v20                                  // 000000A0F338: 06122909
	v_mov_b32_dpp v19, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A0F33C: 7E2602FA FF016804
	v_cndmask_b32_e64 v4, -v4, v4, s1                          // 000000A0F344: D5010004 20060904
	v_mov_b32_dpp v20, v14 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A0F34C: 7E2802FA FF01640E
	v_cndmask_b32_e64 v14, -v14, v14, s4                       // 000000A0F354: D501000E 20121D0E
	v_add_f32_e32 v10, v10, v15                                // 000000A0F35C: 06141F0A
	v_rcp_f32_e32 v12, v30                                     // 000000A0F360: 7E18551E
	v_mov_b32_dpp v15, v9 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A0F364: 7E1E02FA FF016809
	v_cndmask_b32_e64 v9, -v9, v9, s1                          // 000000A0F36C: D5010009 20061309
	v_add_f32_e32 v4, v4, v19                                  // 000000A0F374: 06082704
	v_add_f32_e32 v14, v14, v20                                // 000000A0F378: 061C290E
	v_mov_b32_dpp v19, v10 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A0F37C: 7E2602FA FF01640A
	v_cndmask_b32_e64 v10, -v10, v10, s4                       // 000000A0F384: D501000A 2012150A
	v_dual_add_f32 v8, 1.0, v8 :: v_dual_add_f32 v9, v9, v15   // 000000A0F38C: C90810F2 08081F09
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000A0F394: BF870224
	v_mov_b32_dpp v15, v14 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A0F398: 7E1E02FA FF01680E
	v_cndmask_b32_e64 v14, -v14, v14, s1                       // 000000A0F3A0: D501000E 20061D0E
	v_add_f32_e32 v10, v10, v19                                // 000000A0F3A8: 0614270A
	v_fma_f32 v11, -v30, v12, 1.0                              // 000000A0F3AC: D613000B 23CA191E
	v_mul_f32_e32 v4, 0x3db504f3, v4                           // 000000A0F3B4: 100808FF 3DB504F3
	v_div_scale_f32 v19, null, v8, v8, v6                      // 000000A0F3BC: D6FC7C13 041A1108
	v_add_f32_e32 v14, v14, v15                                // 000000A0F3C4: 061C1F0E
	v_mov_b32_dpp v15, v10 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A0F3C8: 7E1E02FA FF01680A
	v_cndmask_b32_e64 v10, -v10, v10, s1                       // 000000A0F3D0: D501000A 2006150A
	v_fmac_f32_e32 v12, v11, v12                               // 000000A0F3D8: 5618190B
	v_div_scale_f32 v11, vcc_lo, v5, v47, v5                   // 000000A0F3DC: D6FC6A0B 04165F05
	v_mul_f32_e32 v9, 0x3db504f3, v9                           // 000000A0F3E4: 101212FF 3DB504F3
	v_rcp_f32_e32 v20, v19                                     // 000000A0F3EC: 7E285513
	v_add_f32_e32 v10, v10, v15                                // 000000A0F3F0: 06141F0A
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000A0F3F4: BF8701B3
	v_dual_mul_f32 v14, 0x3db504f3, v14 :: v_dual_mul_f32 v15, v11, v12// 000000A0F3F8: C8C61CFF 0E0E190B 3DB504F3
	s_waitcnt vmcnt(12)                                        // 000000A0F404: BF8933F7
	v_fma_mix_f32 v9, v32, v9, neg(0) op_sel_hi:[1,0,0]        // 000000A0F408: CC200009 8A021320
	v_mul_f32_e32 v10, 0x3db504f3, v10                         // 000000A0F410: 101414FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_3)                            // 000000A0F418: BF870003
	v_fma_f32 v31, -v30, v15, v11                              // 000000A0F41C: D613001F 242E1F1E
	v_fma_mix_f32 v4, v26, v4, neg(0) op_sel_hi:[1,0,0]        // 000000A0F424: CC200004 8A02091A
	s_waitcnt vmcnt(8)                                         // 000000A0F42C: BF8923F7
	v_fma_mix_f32 v14, v35, v14, neg(0) op_sel_hi:[1,0,0]      // 000000A0F430: CC20000E 8A021D23
	v_mul_f32_e32 v29, 0xbfb8aa3b, v9                          // 000000A0F438: 103A12FF BFB8AA3B
	v_fma_f32 v32, -v19, v20, 1.0                              // 000000A0F440: D6130020 23CA2913
	v_fma_mix_f32 v10, v38, v10, neg(0) op_sel_hi:[1,0,0]      // 000000A0F448: CC20000A 8A021526
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A0F450: BF870214
	v_dual_mul_f32 v26, 0xbfb8aa3b, v4 :: v_dual_mul_f32 v35, 0xbfb8aa3b, v14// 000000A0F454: C8C608FF 1A221CFF BFB8AA3B
	v_exp_f32_e32 v29, v29                                     // 000000A0F460: 7E3A4B1D
	v_fmac_f32_e32 v15, v31, v12                               // 000000A0F464: 561E191F
	v_fmac_f32_e32 v20, v32, v20                               // 000000A0F468: 56282920
	s_delay_alu instid0(VALU_DEP_3)                            // 000000A0F46C: BF870003
	v_exp_f32_e32 v26, v26                                     // 000000A0F470: 7E344B1A
	v_mul_f32_e32 v32, 0xbfb8aa3b, v10                         // 000000A0F474: 104014FF BFB8AA3B
	v_exp_f32_e32 v31, v35                                     // 000000A0F47C: 7E3E4B23
	v_fma_f32 v11, -v30, v15, v11                              // 000000A0F480: D613000B 242E1F1E
	v_div_scale_f32 v35, s5, v6, v8, v6                        // 000000A0F488: D6FC0523 041A1106
	v_fma_mix_f32 v13, v33, v13, neg(0) op_sel_hi:[1,0,0]      // 000000A0F490: CC20000D 8A021B21
	v_exp_f32_e32 v30, v32                                     // 000000A0F498: 7E3C4B20
	v_add_f32_e32 v29, 1.0, v29                                // 000000A0F49C: 063A3AF2
	v_div_fmas_f32 v11, v11, v12, v15                          // 000000A0F4A0: D637000B 043E190B
	v_mul_f32_e32 v32, v35, v20                                // 000000A0F4A8: 10402923
	v_add_f32_e32 v26, 1.0, v26                                // 000000A0F4AC: 063434F2
	s_mov_b32 vcc_lo, s5                                       // 000000A0F4B0: BEEA0005
	v_add_f32_e32 v31, 1.0, v31                                // 000000A0F4B4: 063E3EF2
	v_div_scale_f32 v39, null, v29, v29, v9                    // 000000A0F4B8: D6FC7C27 04263B1D
	v_fma_f32 v15, -v19, v32, v35                              // 000000A0F4C0: D613000F 248E4113
	v_div_scale_f32 v36, null, v26, v26, v4                    // 000000A0F4C8: D6FC7C24 0412351A
	v_add_f32_e32 v30, 1.0, v30                                // 000000A0F4D0: 063C3CF2
	v_div_scale_f32 v12, null, v31, v31, v14                   // 000000A0F4D4: D6FC7C0C 043A3F1F
	v_rcp_f32_e32 v43, v39                                     // 000000A0F4DC: 7E565527
	v_fmac_f32_e32 v32, v15, v20                               // 000000A0F4E0: 5640290F
	v_rcp_f32_e32 v38, v36                                     // 000000A0F4E4: 7E4C5524
	v_div_scale_f32 v33, null, v30, v30, v10                   // 000000A0F4E8: D6FC7C21 042A3D1E
	v_rcp_f32_e32 v45, v12                                     // 000000A0F4F0: 7E5A550C
	v_div_fixup_f32 v5, v11, v47, v5                           // 000000A0F4F4: D6270005 04165F0B
	v_div_scale_f32 v11, s6, v4, v26, v4                       // 000000A0F4FC: D6FC060B 04123504
	v_fma_f32 v19, -v19, v32, v35                              // 000000A0F504: D6130013 248E4113
	v_rcp_f32_e32 v15, v33                                     // 000000A0F50C: 7E1E5521
	s_waitcnt vmcnt(7)                                         // 000000A0F510: BF891FF7
	v_fma_mix_f32 v21, v27, v21, neg(0) op_sel_hi:[1,0,0]      // 000000A0F514: CC200015 8A022B1B
	v_mul_f32_e32 v5, v13, v5                                  // 000000A0F51C: 100A0B0D
	v_fma_mix_f32 v0, v25, v0, neg(0) op_sel_hi:[1,0,0]        // 000000A0F520: CC200000 8A020119
	v_fma_f32 v44, -v36, v38, 1.0                              // 000000A0F528: D613002C 23CA4D24
	v_div_fmas_f32 v19, v19, v20, v32                          // 000000A0F530: D6370013 04822913
	v_fma_f32 v13, -v12, v45, 1.0                              // 000000A0F538: D613000D 23CA5B0C
	s_mov_b32 vcc_lo, s6                                       // 000000A0F540: BEEA0006
	v_fma_mix_f32 v7, v7, v18, neg(0) op_sel_hi:[1,0,0]        // 000000A0F544: CC200007 8A022507
	v_fmac_f32_e32 v38, v44, v38                               // 000000A0F54C: 564C4D2C
	v_fma_f32 v44, -v39, v43, 1.0                              // 000000A0F550: D613002C 23CA5727
	v_fma_f32 v46, -v33, v15, 1.0                              // 000000A0F558: D613002E 23CA1F21
	v_fmac_f32_e32 v45, v13, v45                               // 000000A0F560: 565A5B0D
	v_div_scale_f32 v13, s8, v14, v31, v14                     // 000000A0F564: D6FC080D 043A3F0E
	v_mul_f32_e32 v35, v11, v38                                // 000000A0F56C: 10464D0B
	v_fmac_f32_e32 v43, v44, v43                               // 000000A0F570: 5656572C
	v_div_scale_f32 v44, s7, v9, v29, v9                       // 000000A0F574: D6FC072C 04263B09
	v_fmac_f32_e32 v15, v46, v15                               // 000000A0F57C: 561E1F2E
	v_div_scale_f32 v46, s5, v10, v30, v10                     // 000000A0F580: D6FC052E 042A3D0A
	v_fma_f32 v20, -v36, v35, v11                              // 000000A0F588: D6130014 242E4724
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000A0F590: BF8701A4
	v_dual_mul_f32 v47, v13, v45 :: v_dual_mul_f32 v32, v44, v43// 000000A0F594: C8C65B0D 2F20572C
	v_div_fixup_f32 v6, v19, v8, v6                            // 000000A0F59C: D6270006 041A1113
	v_dual_fmac_f32 v35, v20, v38 :: v_dual_mul_f32 v20, v46, v15// 000000A0F5A4: C8064D14 23141F2E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A0F5AC: BF870213
	v_fma_f32 v8, -v39, v32, v44                               // 000000A0F5B0: D6130008 24B24127
	v_fma_f32 v19, -v12, v47, v13                              // 000000A0F5B8: D6130013 24365F0C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A0F5C0: BF870214
	v_mul_f32_e32 v6, v21, v6                                  // 000000A0F5C4: 100C0D15
	v_fma_f32 v11, -v36, v35, v11                              // 000000A0F5C8: D613000B 242E4724
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000A0F5D0: BF870234
	v_fmac_f32_e32 v32, v8, v43                                // 000000A0F5D4: 56405708
	v_fma_f32 v8, -v33, v20, v46                               // 000000A0F5D8: D6130008 24BA2921
	v_fmac_f32_e32 v47, v19, v45                               // 000000A0F5E0: 565E5B13
	v_div_fmas_f32 v11, v11, v38, v35                          // 000000A0F5E4: D637000B 048E4D0B
	s_mov_b32 vcc_lo, s7                                       // 000000A0F5EC: BEEA0007
	v_fma_f32 v19, -v39, v32, v44                              // 000000A0F5F0: D6130013 24B24127
	v_fmac_f32_e32 v20, v8, v15                                // 000000A0F5F8: 56281F08
	v_fma_f32 v8, -v12, v47, v13                               // 000000A0F5FC: D6130008 24365F0C
	v_div_fixup_f32 v4, v11, v26, v4                           // 000000A0F604: D6270004 0412350B
	v_fma_mix_f32 v11, v34, v17, neg(0) op_sel_hi:[1,0,0]      // 000000A0F60C: CC20000B 8A022322
	v_div_fmas_f32 v12, v19, v43, v32                          // 000000A0F614: D637000C 04825713
	v_fma_f32 v13, -v33, v20, v46                              // 000000A0F61C: D613000D 24BA2921
	s_mov_b32 vcc_lo, s8                                       // 000000A0F624: BEEA0008
	s_waitcnt vmcnt(0)                                         // 000000A0F628: BF8903F7
	v_fma_mix_f32 v6, v23, v6, neg(0) op_sel_hi:[1,0,0]        // 000000A0F62C: CC200006 8A020D17
	v_div_fmas_f32 v8, v8, v45, v47                            // 000000A0F634: D6370008 04BE5B08
	s_mov_b32 vcc_lo, s5                                       // 000000A0F63C: BEEA0005
	v_div_fixup_f32 v9, v12, v29, v9                           // 000000A0F640: D6270009 04263B0C
	v_div_fmas_f32 v13, v13, v15, v20                          // 000000A0F648: D637000D 04521F0D
	v_fma_mix_f32 v12, v22, v24, neg(0) op_sel_hi:[1,0,0]      // 000000A0F650: CC20000C 8A023116
	v_div_fixup_f32 v8, v8, v31, v14                           // 000000A0F658: D6270008 043A3F08
	v_mul_f32_e32 v4, v7, v4                                   // 000000A0F660: 10080907
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A0F664: BF870194
	v_div_fixup_f32 v10, v13, v30, v10                         // 000000A0F668: D627000A 042A3D0D
	v_dual_mul_f32 v9, v12, v9 :: v_dual_mul_f32 v8, v11, v8   // 000000A0F670: C8C6130C 0908110B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A0F678: BF870112
	v_mul_f32_e32 v0, v0, v10                                  // 000000A0F67C: 10001500
	v_fma_mix_f32 v7, v28, v9, neg(0) op_sel_hi:[1,0,0]        // 000000A0F680: CC200007 8A02131C
	v_fma_mix_f32 v9, v2, v37, v3 op_sel_hi:[0,1,0]            // 000000A0F688: CC200009 140E4B02
	v_fma_mix_f32 v10, v5, v40, v6 op_sel_hi:[0,1,0]           // 000000A0F690: CC20000A 141A5105
	v_fma_mix_f32 v2, v2, v37, -v3 op_sel_hi:[0,1,0]           // 000000A0F698: CC200002 940E4B02
	v_fma_mix_f32 v0, v16, v0, neg(0) op_sel_hi:[1,0,0]        // 000000A0F6A0: CC200000 8A020110
	v_fma_mix_f32 v11, v4, v41, v7 op_sel_hi:[0,1,0]           // 000000A0F6A8: CC20000B 141E5304
	v_fma_mix_f32 v3, v5, v40, -v6 op_sel_hi:[0,1,0]           // 000000A0F6B0: CC200003 941A5105
	v_fma_mix_f32 v4, v4, v41, -v7 op_sel_hi:[0,1,0]           // 000000A0F6B8: CC200004 941E5304
	v_add_f32_e32 v5, v9, v10                                  // 000000A0F6C0: 060A1509
	v_fma_mix_f32 v12, v8, v42, v0 op_sel_hi:[0,1,0]           // 000000A0F6C4: CC20000C 14025508
	v_fma_mix_f32 v0, v8, v42, -v0 op_sel_hi:[0,1,0]           // 000000A0F6CC: CC200000 94025508
	v_dual_sub_f32 v7, v9, v10 :: v_dual_add_f32 v8, v2, v3    // 000000A0F6D4: C9481509 07080702
	v_sub_f32_e32 v2, v2, v3                                   // 000000A0F6DC: 08040702
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000A0F6E0: BF8701B4
	v_add_f32_e32 v6, v11, v12                                 // 000000A0F6E4: 060C190B
	v_sub_f32_e32 v9, v11, v12                                 // 000000A0F6E8: 0812190B
	v_add_f32_e32 v10, v4, v0                                  // 000000A0F6EC: 06140104
	v_dual_sub_f32 v0, v4, v0 :: v_dual_add_f32 v3, v5, v6     // 000000A0F6F0: C9480104 00020D05
	v_sub_f32_e32 v4, v5, v6                                   // 000000A0F6F8: 08080D05
	s_delay_alu instid0(VALU_DEP_3)                            // 000000A0F6FC: BF870003
	v_add_f32_e32 v6, v8, v10                                  // 000000A0F700: 060C1508
	v_sub_f32_e32 v8, v8, v10                                  // 000000A0F704: 08101508
	v_add_f32_e32 v10, v7, v9                                  // 000000A0F708: 06141307
	v_mov_b32_dpp v5, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A0F70C: 7E0A02FA FF016103
	v_cndmask_b32_e64 v3, -v3, v3, s2                          // 000000A0F714: D5010003 200A0703
	v_sub_f32_e32 v7, v7, v9                                   // 000000A0F71C: 080E1307
	v_mov_b32_dpp v14, v4 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A0F720: 7E1C02FA FF016104
	v_mov_b32_dpp v9, v10 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A0F728: 7E1202FA FF01610A
	v_cndmask_b32_e64 v10, -v10, v10, s2                       // 000000A0F730: D501000A 200A150A
	v_add_f32_e32 v3, v3, v5                                   // 000000A0F738: 06060B03
	v_mov_b32_dpp v5, v6 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A0F73C: 7E0A02FA FF016106
	v_cndmask_b32_e64 v6, -v6, v6, s2                          // 000000A0F744: D5010006 200A0D06
	v_cndmask_b32_e64 v15, -v4, v4, s2                         // 000000A0F74C: D501000F 200A0904
	v_add_f32_e32 v9, v10, v9                                  // 000000A0F754: 0612130A
	v_mov_b32_dpp v11, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A0F758: 7E1602FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, s3                          // 000000A0F760: D5010003 200E0703
	v_add_f32_e32 v5, v6, v5                                   // 000000A0F768: 060A0B06
	v_add_f32_e32 v6, v2, v0                                   // 000000A0F76C: 060C0102
	v_sub_f32_e32 v10, v2, v0                                  // 000000A0F770: 08140102
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A0F774: BF870214
	v_add_f32_e32 v0, v3, v11                                  // 000000A0F778: 06001703
	v_mov_b32_dpp v2, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A0F77C: 7E0402FA FF016205
	v_cndmask_b32_e64 v3, -v5, v5, s3                          // 000000A0F784: D5010003 200E0B05
	v_mov_b32_dpp v5, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A0F78C: 7E0A02FA FF016209
	v_cndmask_b32_e64 v9, -v9, v9, s3                          // 000000A0F794: D5010009 200E1309
	v_mov_b32_dpp v11, v6 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A0F79C: 7E1602FA FF016106
	v_cndmask_b32_e64 v6, -v6, v6, s2                          // 000000A0F7A4: D5010006 200A0D06
	v_add_f32_e32 v2, v3, v2                                   // 000000A0F7AC: 06040503
	v_mov_b32_dpp v16, v10 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A0F7B0: 7E2002FA FF01610A
	v_add_f32_e32 v5, v9, v5                                   // 000000A0F7B8: 060A0B09
	v_cndmask_b32_e64 v10, -v10, v10, s2                       // 000000A0F7BC: D501000A 200A150A
	v_add_f32_e32 v6, v6, v11                                  // 000000A0F7C4: 060C1706
	v_mov_b32_dpp v9, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A0F7C8: 7E1202FA FF016402
	v_cndmask_b32_e64 v2, -v2, v2, s4                          // 000000A0F7D0: D5010002 20120502
	v_mov_b32_dpp v11, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A0F7D8: 7E1602FA FF016405
	v_cndmask_b32_e64 v5, -v5, v5, s4                          // 000000A0F7E0: D5010005 20120B05
	v_mov_b32_dpp v12, v6 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A0F7E8: 7E1802FA FF016206
	v_cndmask_b32_e64 v13, -v6, v6, s3                         // 000000A0F7F0: D501000D 200E0D06
	v_add_f32_e32 v4, v2, v9                                   // 000000A0F7F8: 06081302
	v_add_f32_e32 v10, v10, v16                                // 000000A0F7FC: 0614210A
	v_dual_add_f32 v6, v5, v11 :: v_dual_add_f32 v11, v15, v14 // 000000A0F800: C9081705 060A1D0F
	v_mov_b32_dpp v14, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A0F808: 7E1C02FA FF016108
	v_cndmask_b32_e64 v8, -v8, v8, s2                          // 000000A0F810: D5010008 200A1108
	v_mov_b32_dpp v15, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A0F818: 7E1E02FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, s2                          // 000000A0F820: D5010007 200A0F07
	v_add_f32_e32 v9, v13, v12                                 // 000000A0F828: 0612190D
	v_mov_b32_dpp v13, v11 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A0F82C: 7E1A02FA FF01620B
	v_cndmask_b32_e64 v11, -v11, v11, s3                       // 000000A0F834: D501000B 200E170B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000A0F83C: BF870234
	v_dual_add_f32 v8, v8, v14 :: v_dual_add_f32 v7, v7, v15   // 000000A0F840: C9081D08 08061F07
	v_mov_b32_dpp v15, v10 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A0F848: 7E1E02FA FF01620A
	v_cndmask_b32_e64 v10, -v10, v10, s3                       // 000000A0F850: D501000A 200E150A
	v_add_f32_e32 v11, v11, v13                                // 000000A0F858: 06161B0B
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A0F85C: BF870004
	v_mov_b32_dpp v13, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A0F860: 7E1A02FA FF016208
	v_cndmask_b32_e64 v8, -v8, v8, s3                          // 000000A0F868: D5010008 200E1108
	v_mov_b32_dpp v14, v7 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A0F870: 7E1C02FA FF016207
	v_cndmask_b32_e64 v7, -v7, v7, s3                          // 000000A0F878: D5010007 200E0F07
	v_add_f32_e32 v10, v10, v15                                // 000000A0F880: 06141F0A
	v_mov_b32_dpp v3, v0 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A0F884: 7E0602FA FF016400
	v_add_f32_e32 v8, v8, v13                                  // 000000A0F88C: 06101B08
	v_cndmask_b32_e64 v0, -v0, v0, s4                          // 000000A0F890: D5010000 20120100
	v_add_f32_e32 v7, v7, v14                                  // 000000A0F898: 060E1D07
	v_mov_b32_dpp v12, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A0F89C: 7E1802FA FF016409
	v_cndmask_b32_e64 v9, -v9, v9, s4                          // 000000A0F8A4: D5010009 20121309
	v_mov_b32_dpp v13, v11 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A0F8AC: 7E1A02FA FF01640B
	v_cndmask_b32_e64 v11, -v11, v11, s4                       // 000000A0F8B4: D501000B 2012170B
	v_mov_b32_dpp v14, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A0F8BC: 7E1C02FA FF016408
	v_cndmask_b32_e64 v8, -v8, v8, s4                          // 000000A0F8C4: D5010008 20121108
	v_mov_b32_dpp v15, v7 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A0F8CC: 7E1E02FA FF016407
	v_cndmask_b32_e64 v7, -v7, v7, s4                          // 000000A0F8D4: D5010007 20120F07
	v_mov_b32_dpp v16, v10 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A0F8DC: 7E2002FA FF01640A
	v_cndmask_b32_e64 v17, -v10, v10, s4                       // 000000A0F8E4: D5010011 2012150A
	v_dual_add_f32 v0, v0, v3 :: v_dual_add_f32 v9, v9, v12    // 000000A0F8EC: C9080700 00081909
	v_dual_add_f32 v10, v11, v13 :: v_dual_add_f32 v11, v8, v14// 000000A0F8F4: C9081B0B 0A0A1D08
	v_add_f32_e32 v13, v7, v15                                 // 000000A0F8FC: 061A1F07
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A0F900: BF870214
	v_add_f32_e32 v15, v17, v16                                // 000000A0F904: 061E2111
	v_mov_b32_dpp v2, v0 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A0F908: 7E0402FA FF016800
	v_mov_b32_dpp v3, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A0F910: 7E0602FA FF016804
	v_mov_b32_dpp v5, v6 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A0F918: 7E0A02FA FF016806
	v_mov_b32_dpp v7, v9 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A0F920: 7E0E02FA FF016809
	v_mov_b32_dpp v8, v10 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A0F928: 7E1002FA FF01680A
	v_mov_b32_dpp v12, v11 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A0F930: 7E1802FA FF01680B
	v_mov_b32_dpp v14, v13 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A0F938: 7E1C02FA FF01680D
	v_mov_b32_dpp v16, v15 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A0F940: 7E2002FA FF01680F
	s_mov_b32 s2, 0x3db504f3                                   // 000000A0F948: BE8200FF 3DB504F3
	s_and_b32 exec_lo, exec_lo, s0                             // 000000A0F950: 8B7E007E
	s_cbranch_execz 65                                         // 000000A0F954: BFA50041 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi3EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x7d5c>
	v_cndmask_b32_e64 v15, -v15, v15, s1                       // 000000A0F958: D501000F 20061F0F
	v_cndmask_b32_e64 v0, -v0, v0, s1                          // 000000A0F960: D5010000 20060100
	v_cndmask_b32_e64 v4, -v4, v4, s1                          // 000000A0F968: D5010004 20060904
	v_cndmask_b32_e64 v6, -v6, v6, s1                          // 000000A0F970: D5010006 20060D06
	v_cndmask_b32_e64 v9, -v9, v9, s1                          // 000000A0F978: D5010009 20061309
	v_cndmask_b32_e64 v13, -v13, v13, s1                       // 000000A0F980: D501000D 20061B0D
	v_cndmask_b32_e64 v10, -v10, v10, s1                       // 000000A0F988: D501000A 2006150A
	v_cndmask_b32_e64 v11, -v11, v11, s1                       // 000000A0F990: D501000B 2006170B
	v_dual_add_f32 v15, v15, v16 :: v_dual_add_f32 v0, v0, v2  // 000000A0F998: C908210F 0F000500
	v_add_f32_e32 v3, v4, v3                                   // 000000A0F9A0: 06060704
	v_add_f32_e32 v5, v6, v5                                   // 000000A0F9A4: 060A0B06
	v_add_f32_e32 v7, v9, v7                                   // 000000A0F9A8: 060E0F09
	s_mul_i32 s0, s10, 0x500                                   // 000000A0F9AC: 9600FF0A 00000500
	v_dual_add_f32 v13, v13, v14 :: v_dual_add_f32 v8, v10, v8 // 000000A0F9B4: C9081D0D 0D08110A
	s_mul_hi_i32 s1, s10, 0x500                                // 000000A0F9BC: 9701FF0A 00000500
	v_add_f32_e32 v11, v11, v12                                // 000000A0F9C4: 0616190B
	s_add_u32 s0, s22, s0                                      // 000000A0F9C8: 80000016
	v_fma_mixlo_f16 v0, v0, s2, 0                              // 000000A0F9CC: CC210000 02000500
	s_addc_u32 s1, s23, s1                                     // 000000A0F9D4: 82010117
	v_fma_mixhi_f16 v0, v3, s2, 0                              // 000000A0F9D8: CC220000 02000503
	s_add_u32 s0, s0, s12                                      // 000000A0F9E0: 80000C00
	v_fma_mixlo_f16 v2, v5, s2, 0                              // 000000A0F9E4: CC210002 02000505
	s_addc_u32 s1, s1, s13                                     // 000000A0F9EC: 82010D01
	v_fma_mixhi_f16 v2, v7, s2, 0                              // 000000A0F9F0: CC220002 02000507
	v_fma_mixlo_f16 v3, v8, s2, 0                              // 000000A0F9F8: CC210003 02000508
	v_fma_mixhi_f16 v3, v11, s2, 0                             // 000000A0FA00: CC220003 0200050B
	v_fma_mixlo_f16 v4, v13, s2, 0                             // 000000A0FA08: CC210004 0200050D
	v_fma_mixhi_f16 v4, v15, s2, 0                             // 000000A0FA10: CC220004 0200050F
	s_clause 0x7                                               // 000000A0FA18: BF850007
	global_store_b16 v1, v0, s[0:1]                            // 000000A0FA1C: DC660000 00000001
	global_store_d16_hi_b16 v1, v0, s[0:1] offset:32           // 000000A0FA24: DC960020 00000001
	global_store_b16 v1, v2, s[0:1] offset:64                  // 000000A0FA2C: DC660040 00000201
	global_store_d16_hi_b16 v1, v2, s[0:1] offset:96           // 000000A0FA34: DC960060 00000201
	global_store_b16 v1, v3, s[0:1] offset:128                 // 000000A0FA3C: DC660080 00000301
	global_store_d16_hi_b16 v1, v3, s[0:1] offset:160          // 000000A0FA44: DC9600A0 00000301
	global_store_b16 v1, v4, s[0:1] offset:192                 // 000000A0FA4C: DC6600C0 00000401
	global_store_d16_hi_b16 v1, v4, s[0:1] offset:224          // 000000A0FA54: DC9600E0 00000401
	s_nop 0                                                    // 000000A0FA5C: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 000000A0FA60: BFB60003
	s_endpgm                                                   // 000000A0FA64: BFB00000
	s_branch 60193                                             // 000000A0FA68: BFA0EB21 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi3EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x29f0>
		...

