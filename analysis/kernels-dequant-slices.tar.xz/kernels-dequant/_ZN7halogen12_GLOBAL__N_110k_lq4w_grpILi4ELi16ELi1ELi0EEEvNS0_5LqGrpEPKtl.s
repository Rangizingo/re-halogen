00000000002a4e00 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl>:
; _ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl():
	s_clause 0x3                                               // 0000002A4E00: BF850003
	s_load_b32 s3, s[0:1], 0x120                               // 0000002A4E04: F40000C0 F8000120
	s_load_b32 s4, s[0:1], 0x88                                // 0000002A4E0C: F4000100 F8000088
	s_load_b32 s5, s[0:1], 0xd0                                // 0000002A4E14: F4000140 F80000D0
	s_load_b32 s6, s[0:1], 0x118                               // 0000002A4E1C: F4000180 F8000118
	v_dual_mov_b32 v20, 0 :: v_dual_and_b32 v17, 15, v0        // 0000002A4E24: CA240080 1410008F
	v_lshrrev_b32_e32 v2, 4, v0                                // 0000002A4E2C: 32040084
	v_lshlrev_b32_e32 v16, 2, v0                               // 0000002A4E30: 30200082
	s_delay_alu instid0(VALU_DEP_2)                            // 0000002A4E34: BF870002
	v_dual_mov_b32 v24, 0 :: v_dual_lshlrev_b32 v3, 2, v2      // 0000002A4E38: CA220080 18020482
	s_waitcnt lgkmcnt(0)                                       // 0000002A4E40: BF89FC07
	s_cmp_gt_i32 s3, 1                                         // 0000002A4E44: BF028103
	s_cselect_b32 s7, -1, 0                                    // 0000002A4E48: 980780C1
	s_cmp_ge_i32 s2, s4                                        // 0000002A4E4C: BF030402
	s_cselect_b32 s4, -1, 0                                    // 0000002A4E50: 980480C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002A4E54: BF870009
	s_and_b32 s4, s7, s4                                       // 0000002A4E58: 8B040407
	s_cmp_gt_i32 s3, 2                                         // 0000002A4E5C: BF028203
	v_cndmask_b32_e64 v1, 0, 1, s4                             // 0000002A4E60: D5010001 00110280
	s_cselect_b32 s7, -1, 0                                    // 0000002A4E68: 980780C1
	s_cmp_ge_i32 s2, s5                                        // 0000002A4E6C: BF030502
	s_cselect_b32 s5, -1, 0                                    // 0000002A4E70: 980580C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002A4E74: BF870009
	s_and_b32 s4, s7, s5                                       // 0000002A4E78: 8B040507
	s_cmp_gt_i32 s3, 3                                         // 0000002A4E7C: BF028303
	v_readfirstlane_b32 s5, v1                                 // 0000002A4E80: 7E0A0501
	s_cselect_b32 s3, -1, 0                                    // 0000002A4E84: 980380C1
	s_cmp_ge_i32 s2, s6                                        // 0000002A4E88: BF030602
	v_lshlrev_b32_e32 v1, 2, v17                               // 0000002A4E8C: 30022282
	s_cselect_b32 s6, -1, 0                                    // 0000002A4E90: 980680C1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(SALU_CYCLE_1)// 0000002A4E94: BF8704D9
	s_and_b32 s3, s3, s6                                       // 0000002A4E98: 8B030603
	s_and_b32 s4, s4, exec_lo                                  // 0000002A4E9C: 8B047E04
	s_cselect_b32 s4, 2, s5                                    // 0000002A4EA0: 98040582
	s_and_b32 s3, s3, exec_lo                                  // 0000002A4EA4: 8B037E03
	s_cselect_b32 s3, 3, s4                                    // 0000002A4EA8: 98030483
	s_mulk_i32 s3, 0x48                                        // 0000002A4EAC: B8030048
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002A4EB0: BF870009
	s_add_u32 s16, s0, s3                                      // 0000002A4EB4: 80100300
	s_addc_u32 s17, s1, 0                                      // 0000002A4EB8: 82118001
	s_clause 0x1                                               // 0000002A4EBC: BF850001
	s_load_b256 s[4:11], s[16:17], 0x18                        // 0000002A4EC0: F40C0108 F8000018
	s_load_b64 s[18:19], s[16:17], null                        // 0000002A4EC8: F4040488 F8000000
	s_waitcnt lgkmcnt(0)                                       // 0000002A4ED0: BF89FC07
	.long 0xd4540003                                           // 0000002A4ED4: D4540003
	v_cndmask_b32_e32 v0, s10, v136, vcc_lo                    // 0000002A4ED8: 0201100A
	s_and_b32 s12, s3, exec_lo                                 // 0000002A4EDC: 8B0C7E03
	s_load_b128 s[12:15], s[0:1], 0x128                        // 0000002A4EE0: F4080300 F8000128
	s_clause 0x1                                               // 0000002A4EE8: BF850001
	global_load_b32 v1, v1, s[18:19]                           // 0000002A4EEC: DC520000 01120001
	global_load_b32 v3, v3, s[18:19]                           // 0000002A4EF4: DC520000 03120003
	s_cselect_b32 s24, 1, 16                                   // 0000002A4EFC: 98189081
	s_cselect_b32 s0, 0, 4                                     // 0000002A4F00: 98008480
	s_add_i32 s25, s24, -1                                     // 0000002A4F04: 8119C118
	v_lshrrev_b32_e32 v18, s0, v2                              // 0000002A4F08: 32240400
	v_and_b32_e32 v19, s25, v2                                 // 0000002A4F0C: 36260419
	s_waitcnt vmcnt(1)                                         // 0000002A4F10: BF8907F7
	v_bfe_u32 v4, v1, 16, 1                                    // 0000002A4F14: D6100004 02052101
	s_waitcnt vmcnt(0)                                         // 0000002A4F1C: BF8903F7
	v_bfe_u32 v5, v3, 16, 1                                    // 0000002A4F20: D6100005 02052103
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000002A4F28: BF8701A2
	v_add3_u32 v1, v1, v4, 0x7fff                              // 0000002A4F2C: D6550001 03FE0901 00007FFF
	.long 0x7f083880                                           // 0000002A4F38: 7F083880
	v_add3_u32 v3, v3, v5, 0x7fff                              // 0000002A4F3C: D6550003 03FE0B03 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A4F48: BF870093
	.long 0x7e083981                                           // 0000002A4F4C: 7E083981
	v_and_or_b32 v1, 0xffff0000, v3, v4                        // 0000002A4F50: D6570001 041206FF FFFF0000
	ds_store_b32 v16, v1                                       // 0000002A4F5C: D8340000 00000110
	v_cvt_f32_ubyte0_e32 v1, s24                               // 0000002A4F64: 7E022218
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002A4F68: BF870291
	v_rcp_iflag_f32_e32 v1, v1                                 // 0000002A4F6C: 7E025701
	v_readfirstlane_b32 s1, v1                                 // 0000002A4F70: 7E020501
	v_mov_b32_e32 v1, 0                                        // 0000002A4F74: 7E020280
	s_mul_f32 s22, s1, 0x4f7ffffe                              // 0000002A4F78: A216FF01 4F7FFFFE
	s_delay_alu instid0(SALU_CYCLE_3)                          // 0000002A4F80: BF87000B
	s_cvt_u32_f32 s26, s22                                     // 0000002A4F84: BE9A6716
	s_waitcnt lgkmcnt(0)                                       // 0000002A4F88: BF89FC07
	s_barrier                                                  // 0000002A4F8C: BFBD0000
	buffer_gl0_inv                                             // 0000002A4F90: E0AC0000 00000000
	s_load_b32 s20, s[16:17], 0x40                             // 0000002A4F98: F4000508 F8000040
	s_waitcnt lgkmcnt(0)                                       // 0000002A4FA0: BF89FC07
	s_sub_i32 s0, s2, s20                                      // 0000002A4FA4: 81801402
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002A4FA8: BF870009
	s_ashr_i32 s1, s0, 31                                      // 0000002A4FAC: 86019F00
	s_and_b32 s3, s3, exec_lo                                  // 0000002A4FB0: 8B037E03
	s_cselect_b32 s3, 4, 0                                     // 0000002A4FB4: 98038084
	s_lshr_b32 s20, s15, 31                                    // 0000002A4FB8: 85149F0F
	s_lshl_b64 s[0:1], s[0:1], s3                              // 0000002A4FBC: 84800300
	s_add_u32 s20, s14, s20                                    // 0000002A4FC0: 8014140E
	s_addc_u32 s21, s15, 0                                     // 0000002A4FC4: 8215800F
	s_ashr_i32 s3, s15, 31                                     // 0000002A4FC8: 86039F0F
	s_ashr_i64 s[20:21], s[20:21], 1                           // 0000002A4FCC: 86948114
	s_lshr_b32 s3, s3, 27                                      // 0000002A4FD0: 85039B03
	.long 0xd7000009                                           // 0000002A4FD4: D7000009
	v_cndmask_b32_e32 v1, s0, v18, vcc_lo                      // 0000002A4FD8: 02022400
	s_add_u32 s22, s14, s3                                     // 0000002A4FDC: 8016030E
	s_addc_u32 s23, s15, 0                                     // 0000002A4FE0: 8217800F
	s_sub_i32 s3, 0, s24                                       // 0000002A4FE4: 81831880
	s_lshr_b64 s[22:23], s[22:23], 5                           // 0000002A4FE8: 85968516
	s_mul_i32 s3, s3, s26                                      // 0000002A4FEC: 96031A03
	s_add_i32 s23, s25, s22                                    // 0000002A4FF0: 81171619
	s_mul_hi_u32 s3, s26, s3                                   // 0000002A4FF4: 9683031A
	s_abs_i32 s27, s23                                         // 0000002A4FF8: BE9B1517
	s_add_i32 s26, s26, s3                                     // 0000002A4FFC: 811A031A
	v_add_co_ci_u32_e64 v10, null, s1, 0, s0                   // 0000002A5000: D5207C0A 00010001
	s_mul_hi_u32 s3, s27, s26                                  // 0000002A5008: 96831A1B
	s_ashr_i32 s1, s23, 31                                     // 0000002A500C: 86019F17
	s_mul_i32 s0, s3, s24                                      // 0000002A5010: 96001803
	s_add_i32 s26, s3, 1                                       // 0000002A5014: 811A8103
	s_sub_i32 s23, s27, s0                                     // 0000002A5018: 8197001B
	.long 0xd4540000                                           // 0000002A501C: D4540000
	v_cndmask_b32_e32 v1, s10, v9, vcc_lo                      // 0000002A5020: 0202120A
	s_sub_i32 s27, s23, s24                                    // 0000002A5024: 819B1817
	s_cmp_ge_u32 s23, s24                                      // 0000002A5028: BF091817
	s_cselect_b32 s3, s26, s3                                  // 0000002A502C: 9803031A
	s_cselect_b32 s23, s27, s23                                // 0000002A5030: 9817171B
	s_add_i32 s26, s3, 1                                       // 0000002A5034: 811A8103
	s_cmp_ge_u32 s23, s24                                      // 0000002A5038: BF091817
	v_cndmask_b32_e64 v3, 0, v10, s0                           // 0000002A503C: D5010003 00021480
	s_cselect_b32 s3, s26, s3                                  // 0000002A5044: 9803031A
	v_cndmask_b32_e64 v2, 0, v9, s0                            // 0000002A5048: D5010002 00021280
	s_xor_b32 s3, s3, s1                                       // 0000002A5050: 8D030103
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002A5054: BF870009
	s_sub_i32 s1, s3, s1                                       // 0000002A5058: 81810103
	s_add_u32 s4, s18, s4                                      // 0000002A505C: 80040412
	s_addc_u32 s5, s19, s5                                     // 0000002A5060: 82050513
	.long 0xd72c0004                                           // 0000002A5064: D72C0004
	v_cndmask_b32_e32 v0, v3, v20, vcc_lo                      // 0000002A5068: 02002903
	.long 0xd72c0007                                           // 0000002A506C: D72C0007
	v_cndmask_b32_e32 v0, v2, v21, vcc_lo                      // 0000002A5070: 02002B02
	v_mad_u64_u32 v[11:12], null, v2, s20, s[4:5]              // 0000002A5074: D6FE7C0B 00102902
	s_add_u32 s6, s18, s6                                      // 0000002A507C: 80060612
	.long 0xd72c0006                                           // 0000002A5080: D72C0006
	v_cndmask_b32_e32 v0, v3, v8, vcc_lo                       // 0000002A5084: 02001103
	s_addc_u32 s7, s19, s7                                     // 0000002A5088: 82070713
	.long 0xd72c0008                                           // 0000002A508C: D72C0008
	v_cndmask_b32_e32 v0, v2, v9, vcc_lo                       // 0000002A5090: 02001302
	v_mad_u64_u32 v[13:14], null, v2, s8, s[6:7]               // 0000002A5094: D6FE7C0D 00181102
	.long 0xd4510003                                           // 0000002A509C: D4510003
	v_cndmask_b32_e32 v0, s10, v137, vcc_lo                    // 0000002A50A0: 0201120A
	v_mov_b32_e32 v2, 0                                        // 0000002A50A4: 7E040280
	v_add3_u32 v12, v4, v12, v7                                // 0000002A50A8: D655000C 041E1904
	v_mov_b32_e32 v4, 0                                        // 0000002A50B0: 7E080280
	.long 0xd72c0005                                           // 0000002A50B4: D72C0005
	v_cndmask_b32_e32 v1, s1, v19, vcc_lo                      // 0000002A50B8: 02022601
	v_add3_u32 v23, v6, v14, v8                                // 0000002A50BC: D6550017 04221D06
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002A50C4: BF870122
	v_add_nc_u32_e32 v3, s1, v5                                // 0000002A50C8: 4A060A01
	v_add_nc_u32_e32 v21, v5, v17                              // 0000002A50CC: 4A2A2305
	v_min_i32_e32 v22, s22, v3                                 // 0000002A50D0: 222C0616
	v_mov_b32_e32 v3, 0                                        // 0000002A50D4: 7E060280
	s_delay_alu instid0(VALU_DEP_2)                            // 0000002A50D8: BF870002
	v_cmp_lt_i32_e32 vcc_lo, v21, v22                          // 0000002A50DC: 7C822D15
	s_and_saveexec_b32 s4, vcc_lo                              // 0000002A50E0: BE84206A
	s_cbranch_execz 21                                         // 0000002A50E4: BFA50015 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x33c>
	v_lshlrev_b32_e32 v1, 1, v21                               // 0000002A50E8: 30022A81
	v_lshlrev_b32_e32 v3, 4, v21                               // 0000002A50EC: 30062A84
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002A50F0: BF870112
	v_ashrrev_i32_e32 v2, 31, v1                               // 0000002A50F4: 3404029F
	v_ashrrev_i32_e32 v4, 31, v3                               // 0000002A50F8: 3408069F
	.long 0xd7000101                                           // 0000002A50FC: D7000101
	v_cndmask_b32_e32 v1, v13, v1, vcc_lo                      // 0000002A5100: 0202030D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002A5104: BF8700A1
	v_add_co_ci_u32_e64 v2, null, v23, v2, s1                  // 0000002A5108: D5207C02 00060517
	.long 0xd7000103                                           // 0000002A5110: D7000103
	v_cndmask_b32_e32 v1, v11, v3, vcc_lo                      // 0000002A5114: 0202070B
	v_add_co_ci_u32_e64 v4, null, v12, v4, s1                  // 0000002A5118: D5207C04 0006090C
	s_clause 0x1                                               // 0000002A5120: BF850001
	global_load_d16_b16 v6, v[1:2], off                        // 0000002A5124: DC820000 067C0001
	global_load_b128 v[1:4], v[3:4], off                       // 0000002A512C: DC5E0000 017C0003
	s_waitcnt vmcnt(1)                                         // 0000002A5134: BF8907F7
	v_cvt_f32_f16_e32 v24, v6                                  // 0000002A5138: 7E301706
	s_or_b32 exec_lo, exec_lo, s4                              // 0000002A513C: 8C7E047E
	v_dual_mov_b32 v26, 0 :: v_dual_mov_b32 v27, 0             // 0000002A5140: CA100080 1A1A0080
	v_mov_b32_e32 v25, 0                                       // 0000002A5148: 7E320280
	s_and_saveexec_b32 s8, vcc_lo                              // 0000002A514C: BE88206A
	s_cbranch_execz 366                                        // 0000002A5150: BFA5016E <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x90c>
	v_dual_mov_b32 v25, 0 :: v_dual_lshlrev_b32 v6, 5, v17     // 0000002A5154: CA220080 19062285
	v_dual_mov_b32 v26, 0 :: v_dual_add_nc_u32 v7, 16, v21     // 0000002A515C: CA200080 1A062A90
	v_mov_b32_e32 v30, v24                                     // 0000002A5164: 7E3C0318
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002A5168: BF870193
	v_lshl_add_u32 v14, v5, 5, v6                              // 0000002A516C: D646000E 04190B05
	v_dual_mov_b32 v27, 0 :: v_dual_lshlrev_b32 v28, 4, v7     // 0000002A5174: CA220080 1B1C0E84
	v_dual_mov_b32 v20, 0 :: v_dual_lshlrev_b32 v29, 1, v7     // 0000002A517C: CA220080 141C0E81
	s_mul_i32 s1, s15, 6                                       // 0000002A5184: 9601860F
	s_mul_hi_u32 s6, s14, 6                                    // 0000002A5188: 9686860E
	s_lshl_b64 s[4:5], s[14:15], 2                             // 0000002A518C: 8484820E
	s_add_i32 s9, s6, s1                                       // 0000002A5190: 81090106
	s_mul_i32 s19, s14, 6                                      // 0000002A5194: 9613860E
	s_mov_b32 s18, 0                                           // 0000002A5198: BE920080
	s_lshl_b64 s[6:7], s[14:15], 1                             // 0000002A519C: 8486810E
	s_branch 314                                               // 0000002A51A0: BFA0013A <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x88c>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000002A51A4: 8C7E0E7E
	v_ashrrev_i32_e32 v15, 31, v14                             // 0000002A51A8: 341E1C9F
	v_lshrrev_b32_e32 v95, 6, v1                               // 0000002A51AC: 32BE0286
	v_lshrrev_b32_e32 v96, 14, v1                              // 0000002A51B0: 32C0028E
	v_and_b32_e32 v97, 0xff, v2                                // 0000002A51B4: 36C204FF 000000FF
	v_lshrrev_b32_e32 v98, 6, v2                               // 0000002A51BC: 32C40486
	.long 0xd73c001f                                           // 0000002A51C0: D73C001F
	v_cndmask_b32_e32 v1, 1, v14, vcc_lo                       // 0000002A51C4: 02021C81
	v_and_b32_e32 v15, 0xff, v1                                // 0000002A51C8: 361E02FF 000000FF
	v_and_b32_e32 v95, 0x3fc, v95                              // 0000002A51D0: 36BEBEFF 000003FC
	v_and_b32_e32 v96, 0x3fc, v96                              // 0000002A51D8: 36C0C0FF 000003FC
	v_lshrrev_b32_e32 v1, 22, v1                               // 0000002A51E0: 32020296
	v_lshrrev_b32_e32 v99, 14, v2                              // 0000002A51E4: 32C6048E
	.long 0xd700014f                                           // 0000002A51E8: D700014F
	v_cndmask_b32_e32 v1, s12, v31, vcc_lo                     // 0000002A51EC: 02023E0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000002A51F0: BF8701A1
	v_add_co_ci_u32_e64 v80, null, s13, v32, s1                // 0000002A51F4: D5207C50 0006400D
	v_lshlrev_b32_e32 v15, 2, v15                              // 0000002A51FC: 301E1E82
	.long 0xd7000153                                           // 0000002A5200: D7000153
	v_cndmask_b32_e32 v0, v79, v6, vcc_lo                      // 0000002A5204: 02000D4F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002A5208: BF8700A1
	v_add_co_ci_u32_e64 v84, null, s7, v80, s1                 // 0000002A520C: D5207C54 0006A007
	.long 0xd7000157                                           // 0000002A5214: D7000157
	v_cndmask_b32_e32 v0, v79, v4, vcc_lo                      // 0000002A5218: 0200094F
	v_add_co_ci_u32_e64 v88, null, s5, v80, s1                 // 0000002A521C: D5207C58 0006A005
	.long 0xd700015b                                           // 0000002A5224: D700015B
	v_cndmask_b32_e32 v0, v79, v19, vcc_lo                     // 0000002A5228: 0200274F
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002A522C: BF870001
	v_add_co_ci_u32_e64 v92, null, s9, v80, s1                 // 0000002A5230: D5207C5C 0006A009
	s_clause 0xf                                               // 0000002A5238: BF85000F
	global_load_b128 v[31:34], v[79:80], off                   // 0000002A523C: DC5E0000 1F7C004F
	global_load_b128 v[35:38], v[83:84], off                   // 0000002A5244: DC5E0000 237C0053
	global_load_b128 v[39:42], v[87:88], off                   // 0000002A524C: DC5E0000 277C0057
	global_load_b128 v[43:46], v[91:92], off                   // 0000002A5254: DC5E0000 2B7C005B
	global_load_b128 v[47:50], v[79:80], off offset:16         // 0000002A525C: DC5E0010 2F7C004F
	global_load_b128 v[51:54], v[83:84], off offset:16         // 0000002A5264: DC5E0010 337C0053
	global_load_b128 v[55:58], v[87:88], off offset:16         // 0000002A526C: DC5E0010 377C0057
	global_load_b128 v[59:62], v[91:92], off offset:16         // 0000002A5274: DC5E0010 3B7C005B
	global_load_b128 v[63:66], v[79:80], off offset:32         // 0000002A527C: DC5E0020 3F7C004F
	global_load_b128 v[67:70], v[83:84], off offset:32         // 0000002A5284: DC5E0020 437C0053
	global_load_b128 v[71:74], v[87:88], off offset:32         // 0000002A528C: DC5E0020 477C0057
	global_load_b128 v[75:78], v[91:92], off offset:32         // 0000002A5294: DC5E0020 4B7C005B
	global_load_b128 v[79:82], v[79:80], off offset:48         // 0000002A529C: DC5E0030 4F7C004F
	global_load_b128 v[83:86], v[83:84], off offset:48         // 0000002A52A4: DC5E0030 537C0053
	global_load_b128 v[87:90], v[87:88], off offset:48         // 0000002A52AC: DC5E0030 577C0057
	global_load_b128 v[91:94], v[91:92], off offset:48         // 0000002A52B4: DC5E0030 5B7C005B
	ds_load_b32 v15, v15                                       // 0000002A52BC: D8D80000 0F00000F
	ds_load_b32 v95, v95                                       // 0000002A52C4: D8D80000 5F00005F
	ds_load_b32 v96, v96                                       // 0000002A52CC: D8D80000 60000060
	v_lshrrev_b32_e32 v2, 22, v2                               // 0000002A52D4: 32040496
	v_and_b32_e32 v1, 0x3fc, v1                                // 0000002A52D8: 360202FF 000003FC
	v_lshlrev_b32_e32 v97, 2, v97                              // 0000002A52E0: 30C2C282
	v_and_b32_e32 v98, 0x3fc, v98                              // 0000002A52E4: 36C4C4FF 000003FC
	v_and_b32_e32 v99, 0x3fc, v99                              // 0000002A52EC: 36C6C6FF 000003FC
	v_and_b32_e32 v2, 0x3fc, v2                                // 0000002A52F4: 360404FF 000003FC
	ds_load_b32 v1, v1                                         // 0000002A52FC: D8D80000 01000001
	ds_load_b32 v97, v97                                       // 0000002A5304: D8D80000 61000061
	ds_load_b32 v98, v98                                       // 0000002A530C: D8D80000 62000062
	ds_load_b32 v99, v99                                       // 0000002A5314: D8D80000 63000063
	ds_load_b32 v2, v2                                         // 0000002A531C: D8D80000 02000002
	v_and_b32_e32 v100, 0xff, v3                               // 0000002A5324: 36C806FF 000000FF
	v_lshrrev_b32_e32 v101, 6, v3                              // 0000002A532C: 32CA0686
	v_lshrrev_b32_e32 v102, 14, v3                             // 0000002A5330: 32CC068E
	v_lshrrev_b32_e32 v3, 22, v3                               // 0000002A5334: 32060696
	v_and_b32_e32 v103, 0xff, v4                               // 0000002A5338: 36CE08FF 000000FF
	v_lshlrev_b32_e32 v100, 2, v100                            // 0000002A5340: 30C8C882
	v_and_b32_e32 v101, 0x3fc, v101                            // 0000002A5344: 36CACAFF 000003FC
	v_and_b32_e32 v102, 0x3fc, v102                            // 0000002A534C: 36CCCCFF 000003FC
	v_lshrrev_b32_e32 v104, 6, v4                              // 0000002A5354: 32D00886
	v_lshrrev_b32_e32 v105, 14, v4                             // 0000002A5358: 32D2088E
	v_lshrrev_b32_e32 v4, 22, v4                               // 0000002A535C: 32080896
	v_and_b32_e32 v3, 0x3fc, v3                                // 0000002A5360: 360606FF 000003FC
	v_add_nc_u32_e32 v28, 0x100, v28                           // 0000002A5368: 4A3838FF 00000100
	v_add_nc_u32_e32 v29, 32, v29                              // 0000002A5370: 4A3A3AA0
	v_add_nc_u32_e32 v14, 0x200, v14                           // 0000002A5374: 4A1C1CFF 00000200
	v_and_b32_e32 v4, 0x3fc, v4                                // 0000002A537C: 360808FF 000003FC
	s_and_b32 s1, exec_lo, vcc_lo                              // 0000002A5384: 8B016A7E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002A5388: BF870009
	s_or_b32 s18, s1, s18                                      // 0000002A538C: 8C121201
	s_waitcnt vmcnt(15) lgkmcnt(7)                             // 0000002A5390: BF893C77
	v_dot2_f32_bf16 v31, v31, v15, 0                           // 0000002A5394: CC1A401F 1A021F1F
	s_waitcnt vmcnt(14)                                        // 0000002A539C: BF893BF7
	v_dot2_f32_bf16 v35, v35, v15, 0                           // 0000002A53A0: CC1A4023 1A021F23
	s_waitcnt vmcnt(13)                                        // 0000002A53A8: BF8937F7
	v_dot2_f32_bf16 v39, v39, v15, 0                           // 0000002A53AC: CC1A4027 1A021F27
	s_waitcnt vmcnt(12)                                        // 0000002A53B4: BF8933F7
	v_dot2_f32_bf16 v15, v43, v15, 0                           // 0000002A53B8: CC1A400F 1A021F2B
	v_lshlrev_b32_e32 v43, 2, v103                             // 0000002A53C0: 3056CE82
	s_waitcnt lgkmcnt(6)                                       // 0000002A53C4: BF89FC67
	v_dot2_f32_bf16 v31, v32, v95, v31                         // 0000002A53C8: CC1A401F 1C7EBF20
	v_dot2_f32_bf16 v32, v36, v95, v35                         // 0000002A53D0: CC1A4020 1C8EBF24
	v_dot2_f32_bf16 v35, v40, v95, v39                         // 0000002A53D8: CC1A4023 1C9EBF28
	v_dot2_f32_bf16 v15, v44, v95, v15                         // 0000002A53E0: CC1A400F 1C3EBF2C
	v_and_b32_e32 v36, 0x3fc, v104                             // 0000002A53E8: 3648D0FF 000003FC
	s_waitcnt lgkmcnt(5)                                       // 0000002A53F0: BF89FC57
	v_dot2_f32_bf16 v31, v33, v96, v31                         // 0000002A53F4: CC1A401F 1C7EC121
	v_dot2_f32_bf16 v32, v37, v96, v32                         // 0000002A53FC: CC1A4020 1C82C125
	v_dot2_f32_bf16 v33, v41, v96, v35                         // 0000002A5404: CC1A4021 1C8EC129
	v_dot2_f32_bf16 v15, v45, v96, v15                         // 0000002A540C: CC1A400F 1C3EC12D
	v_and_b32_e32 v35, 0x3fc, v105                             // 0000002A5414: 3646D2FF 000003FC
	s_waitcnt lgkmcnt(4)                                       // 0000002A541C: BF89FC47
	v_dot2_f32_bf16 v31, v34, v1, v31                          // 0000002A5420: CC1A401F 1C7E0322
	v_dot2_f32_bf16 v32, v38, v1, v32                          // 0000002A5428: CC1A4020 1C820326
	v_dot2_f32_bf16 v33, v42, v1, v33                          // 0000002A5430: CC1A4021 1C86032A
	v_dot2_f32_bf16 v1, v46, v1, v15                           // 0000002A5438: CC1A4001 1C3E032E
	ds_load_b32 v34, v101                                      // 0000002A5440: D8D80000 22000065
	ds_load_b32 v37, v102                                      // 0000002A5448: D8D80000 25000066
	s_waitcnt vmcnt(11) lgkmcnt(5)                             // 0000002A5450: BF892C57
	v_dot2_f32_bf16 v15, v47, v97, v31                         // 0000002A5454: CC1A400F 1C7EC32F
	s_waitcnt vmcnt(10)                                        // 0000002A545C: BF892BF7
	v_dot2_f32_bf16 v31, v51, v97, v32                         // 0000002A5460: CC1A401F 1C82C333
	s_waitcnt vmcnt(9)                                         // 0000002A5468: BF8927F7
	v_dot2_f32_bf16 v32, v55, v97, v33                         // 0000002A546C: CC1A4020 1C86C337
	s_waitcnt vmcnt(8)                                         // 0000002A5474: BF8923F7
	v_dot2_f32_bf16 v1, v59, v97, v1                           // 0000002A5478: CC1A4001 1C06C33B
	ds_load_b32 v33, v100                                      // 0000002A5480: D8D80000 21000064
	s_waitcnt lgkmcnt(5)                                       // 0000002A5488: BF89FC57
	v_dot2_f32_bf16 v15, v48, v98, v15                         // 0000002A548C: CC1A400F 1C3EC530
	v_dot2_f32_bf16 v31, v52, v98, v31                         // 0000002A5494: CC1A401F 1C7EC534
	v_dot2_f32_bf16 v32, v56, v98, v32                         // 0000002A549C: CC1A4020 1C82C538
	v_dot2_f32_bf16 v1, v60, v98, v1                           // 0000002A54A4: CC1A4001 1C06C53C
	s_waitcnt lgkmcnt(4)                                       // 0000002A54AC: BF89FC47
	v_dot2_f32_bf16 v15, v49, v99, v15                         // 0000002A54B0: CC1A400F 1C3EC731
	v_dot2_f32_bf16 v31, v53, v99, v31                         // 0000002A54B8: CC1A401F 1C7EC735
	v_dot2_f32_bf16 v32, v57, v99, v32                         // 0000002A54C0: CC1A4020 1C82C739
	v_dot2_f32_bf16 v1, v61, v99, v1                           // 0000002A54C8: CC1A4001 1C06C73D
	s_waitcnt lgkmcnt(3)                                       // 0000002A54D0: BF89FC37
	v_dot2_f32_bf16 v15, v50, v2, v15                          // 0000002A54D4: CC1A400F 1C3E0532
	v_dot2_f32_bf16 v31, v54, v2, v31                          // 0000002A54DC: CC1A401F 1C7E0536
	v_dot2_f32_bf16 v32, v58, v2, v32                          // 0000002A54E4: CC1A4020 1C82053A
	v_dot2_f32_bf16 v1, v62, v2, v1                            // 0000002A54EC: CC1A4001 1C06053E
	ds_load_b32 v2, v3                                         // 0000002A54F4: D8D80000 02000003
	ds_load_b32 v3, v43                                        // 0000002A54FC: D8D80000 0300002B
	ds_load_b32 v36, v36                                       // 0000002A5504: D8D80000 24000024
	ds_load_b32 v35, v35                                       // 0000002A550C: D8D80000 23000023
	ds_load_b32 v38, v4                                        // 0000002A5514: D8D80000 26000004
	s_waitcnt vmcnt(7) lgkmcnt(5)                              // 0000002A551C: BF891C57
	v_dot2_f32_bf16 v4, v63, v33, v15                          // 0000002A5520: CC1A4004 1C3E433F
	s_waitcnt vmcnt(6)                                         // 0000002A5528: BF891BF7
	v_dot2_f32_bf16 v15, v67, v33, v31                         // 0000002A552C: CC1A400F 1C7E4343
	s_waitcnt vmcnt(5)                                         // 0000002A5534: BF8917F7
	v_dot2_f32_bf16 v31, v71, v33, v32                         // 0000002A5538: CC1A401F 1C824347
	s_waitcnt vmcnt(4)                                         // 0000002A5540: BF8913F7
	v_dot2_f32_bf16 v1, v75, v33, v1                           // 0000002A5544: CC1A4001 1C06434B
	v_dot2_f32_bf16 v4, v64, v34, v4                           // 0000002A554C: CC1A4004 1C124540
	v_dot2_f32_bf16 v15, v68, v34, v15                         // 0000002A5554: CC1A400F 1C3E4544
	v_dot2_f32_bf16 v31, v72, v34, v31                         // 0000002A555C: CC1A401F 1C7E4548
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002A5564: BF870214
	v_dot2_f32_bf16 v1, v76, v34, v1                           // 0000002A5568: CC1A4001 1C06454C
	v_dot2_f32_bf16 v4, v65, v37, v4                           // 0000002A5570: CC1A4004 1C124B41
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002A5578: BF870214
	v_dot2_f32_bf16 v15, v69, v37, v15                         // 0000002A557C: CC1A400F 1C3E4B45
	v_dot2_f32_bf16 v31, v73, v37, v31                         // 0000002A5584: CC1A401F 1C7E4B49
	s_delay_alu instid0(VALU_DEP_4)                            // 0000002A558C: BF870004
	v_dot2_f32_bf16 v1, v77, v37, v1                           // 0000002A5590: CC1A4001 1C064B4D
	s_waitcnt lgkmcnt(4)                                       // 0000002A5598: BF89FC47
	v_dot2_f32_bf16 v32, v66, v2, v4                           // 0000002A559C: CC1A4020 1C120542
	v_dot2_f32_bf16 v15, v70, v2, v15                          // 0000002A55A4: CC1A400F 1C3E0546
	v_dot2_f32_bf16 v31, v74, v2, v31                          // 0000002A55AC: CC1A401F 1C7E054A
	v_dot2_f32_bf16 v1, v78, v2, v1                            // 0000002A55B4: CC1A4001 1C06054E
	v_mov_b32_e32 v4, v8                                       // 0000002A55BC: 7E080308
	s_waitcnt vmcnt(3) lgkmcnt(3)                              // 0000002A55C0: BF890C37
	v_dot2_f32_bf16 v2, v79, v3, v32                           // 0000002A55C4: CC1A4002 1C82074F
	s_waitcnt vmcnt(2)                                         // 0000002A55CC: BF890BF7
	v_dot2_f32_bf16 v8, v83, v3, v15                           // 0000002A55D0: CC1A4008 1C3E0753
	s_waitcnt vmcnt(1)                                         // 0000002A55D8: BF8907F7
	v_dot2_f32_bf16 v15, v87, v3, v31                          // 0000002A55DC: CC1A400F 1C7E0757
	s_waitcnt vmcnt(0)                                         // 0000002A55E4: BF8903F7
	v_dot2_f32_bf16 v1, v91, v3, v1                            // 0000002A55E8: CC1A4001 1C06075B
	v_mov_b32_e32 v3, v7                                       // 0000002A55F0: 7E060307
	s_waitcnt lgkmcnt(2)                                       // 0000002A55F4: BF89FC27
	v_dot2_f32_bf16 v7, v80, v36, v2                           // 0000002A55F8: CC1A4007 1C0A4950
	v_dot2_f32_bf16 v8, v84, v36, v8                           // 0000002A5600: CC1A4008 1C224954
	v_dot2_f32_bf16 v15, v88, v36, v15                         // 0000002A5608: CC1A400F 1C3E4958
	v_dot2_f32_bf16 v1, v92, v36, v1                           // 0000002A5610: CC1A4001 1C06495C
	v_mov_b32_e32 v2, v6                                       // 0000002A5618: 7E040306
	s_waitcnt lgkmcnt(1)                                       // 0000002A561C: BF89FC17
	v_dot2_f32_bf16 v6, v81, v35, v7                           // 0000002A5620: CC1A4006 1C1E4751
	v_dot2_f32_bf16 v7, v85, v35, v8                           // 0000002A5628: CC1A4007 1C224755
	v_dot2_f32_bf16 v8, v89, v35, v15                          // 0000002A5630: CC1A4008 1C3E4759
	v_dot2_f32_bf16 v15, v93, v35, v1                          // 0000002A5638: CC1A400F 1C06475D
	v_mov_b32_e32 v1, v5                                       // 0000002A5640: 7E020305
	s_waitcnt lgkmcnt(0)                                       // 0000002A5644: BF89FC07
	v_dot2_f32_bf16 v5, v82, v38, v6                           // 0000002A5648: CC1A4005 1C1A4D52
	v_dot2_f32_bf16 v6, v86, v38, v7                           // 0000002A5650: CC1A4006 1C1E4D56
	v_dot2_f32_bf16 v7, v90, v38, v8                           // 0000002A5658: CC1A4007 1C224D5A
	v_dot2_f32_bf16 v8, v94, v38, v15                          // 0000002A5660: CC1A4008 1C3E4D5E
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002A5668: BF870214
	v_fmac_f32_e32 v25, v24, v5                                // 0000002A566C: 56320B18
	v_fmac_f32_e32 v27, v24, v6                                // 0000002A5670: 56360D18
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002A5674: BF870214
	v_fmac_f32_e32 v26, v24, v7                                // 0000002A5678: 56340F18
	v_fmac_f32_e32 v20, v24, v8                                // 0000002A567C: 56281118
	v_mov_b32_e32 v24, v30                                     // 0000002A5680: 7E30031E
	s_and_not1_b32 exec_lo, exec_lo, s18                       // 0000002A5684: 917E127E
	s_cbranch_execz 31                                         // 0000002A5688: BFA5001F <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x908>
	s_waitcnt vmcnt(0)                                         // 0000002A568C: BF8903F7
	v_dual_mov_b32 v6, v2 :: v_dual_add_nc_u32 v21, 16, v21    // 0000002A5690: CA200102 06142A90
	v_dual_mov_b32 v5, v1 :: v_dual_mov_b32 v8, v4             // 0000002A5698: CA100101 05080104
	v_mov_b32_e32 v7, v3                                       // 0000002A56A0: 7E0E0303
	s_mov_b32 s14, exec_lo                                     // 0000002A56A4: BE8E007E
	s_delay_alu instid0(VALU_DEP_3)                            // 0000002A56A8: BF870003
	v_cmp_ge_i32_e32 vcc_lo, v21, v22                          // 0000002A56AC: 7C8C2D15
	.long 0xd4c1007e                                           // 0000002A56B0: D4C1007E
	v_cndmask_b32_e32 v1, v21, v22, vcc_lo                     // 0000002A56B4: 02022D15
	s_cbranch_execz 65210                                      // 0000002A56B8: BFA5FEBA <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x3a4>
	v_ashrrev_i32_e32 v6, 31, v29                              // 0000002A56BC: 340C3A9F
	v_ashrrev_i32_e32 v8, 31, v28                              // 0000002A56C0: 3410389F
	.long 0xd7000105                                           // 0000002A56C4: D7000105
	v_cndmask_b32_e32 v1, v13, v29, vcc_lo                     // 0000002A56C8: 02023B0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002A56CC: BF8700A1
	v_add_co_ci_u32_e64 v6, null, v23, v6, s1                  // 0000002A56D0: D5207C06 00060D17
	.long 0xd7000107                                           // 0000002A56D8: D7000107
	v_cndmask_b32_e32 v1, v11, v28, vcc_lo                     // 0000002A56DC: 0202390B
	v_add_co_ci_u32_e64 v8, null, v12, v8, s1                  // 0000002A56E0: D5207C08 0006110C
	s_clause 0x1                                               // 0000002A56E8: BF850001
	global_load_d16_b16 v15, v[5:6], off                       // 0000002A56EC: DC820000 0F7C0005
	global_load_b128 v[5:8], v[7:8], off                       // 0000002A56F4: DC5E0000 057C0007
	s_waitcnt vmcnt(1)                                         // 0000002A56FC: BF8907F7
	v_cvt_f32_f16_e32 v30, v15                                 // 0000002A5700: 7E3C170F
	s_branch 65191                                             // 0000002A5704: BFA0FEA7 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x3a4>
	s_or_b32 exec_lo, exec_lo, s18                             // 0000002A5708: 8C7E127E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000002A570C: BF870149
	s_or_b32 exec_lo, exec_lo, s8                              // 0000002A5710: 8C7E087E
	s_waitcnt vmcnt(0)                                         // 0000002A5714: BF8903F7
	.long 0xd71f0001                                           // 0000002A5718: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000002A571C: 020100C1
	.long 0xd44a0001                                           // 0000002A5720: D44A0001
	v_cndmask_b32_e32 v1, 0, v17, vcc_lo                       // 0000002A5724: 02022280
	v_xor_b32_e32 v2, 8, v1                                    // 0000002A5728: 3A040288
	v_xor_b32_e32 v6, 4, v1                                    // 0000002A572C: 3A0C0284
	v_xor_b32_e32 v12, 2, v1                                   // 0000002A5730: 3A180282
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000002A5734: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 0000002A5738: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 0000002A573C: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v6                            // 0000002A5740: 7C980CA0
	s_delay_alu instid0(VALU_DEP_2)                            // 0000002A5744: BF870002
	v_lshlrev_b32_e32 v2, 2, v2                                // 0000002A5748: 30040482
	ds_bpermute_b32 v3, v2, v25                                // 0000002A574C: DACC0000 03001902
	s_waitcnt lgkmcnt(0)                                       // 0000002A5754: BF89FC07
	v_add_f32_e32 v3, v25, v3                                  // 0000002A5758: 06060719
	ds_bpermute_b32 v5, v2, v26                                // 0000002A575C: DACC0000 05001A02
	v_cndmask_b32_e32 v6, v1, v6, vcc_lo                       // 0000002A5764: 020C0D01
	ds_bpermute_b32 v4, v2, v27                                // 0000002A5768: DACC0000 04001B02
	ds_bpermute_b32 v2, v2, v20                                // 0000002A5770: DACC0000 02001402
	v_cmp_gt_u32_e32 vcc_lo, 32, v12                           // 0000002A5778: 7C9818A0
	s_waitcnt lgkmcnt(2)                                       // 0000002A577C: BF89FC27
	v_dual_add_f32 v5, v26, v5 :: v_dual_lshlrev_b32 v6, 2, v6 // 0000002A5780: C9220B1A 05060C82
	s_waitcnt lgkmcnt(1)                                       // 0000002A5788: BF89FC17
	v_add_f32_e32 v4, v27, v4                                  // 0000002A578C: 0608091B
	s_waitcnt lgkmcnt(0)                                       // 0000002A5790: BF89FC07
	v_add_f32_e32 v2, v20, v2                                  // 0000002A5794: 06040514
	ds_bpermute_b32 v11, v6, v5                                // 0000002A5798: DACC0000 0B000506
	s_waitcnt lgkmcnt(0)                                       // 0000002A57A0: BF89FC07
	v_add_f32_e32 v5, v5, v11                                  // 0000002A57A4: 060A1705
	ds_bpermute_b32 v7, v6, v3                                 // 0000002A57A8: DACC0000 07000306
	ds_bpermute_b32 v8, v6, v4                                 // 0000002A57B0: DACC0000 08000406
	ds_bpermute_b32 v6, v6, v2                                 // 0000002A57B8: DACC0000 06000206
	s_waitcnt lgkmcnt(2)                                       // 0000002A57C0: BF89FC27
	v_dual_add_f32 v3, v3, v7 :: v_dual_cndmask_b32 v12, v1, v12// 0000002A57C4: C9120F03 030C1901
	s_waitcnt lgkmcnt(1)                                       // 0000002A57CC: BF89FC17
	v_add_f32_e32 v4, v4, v8                                   // 0000002A57D0: 06081104
	s_delay_alu instid0(VALU_DEP_2)                            // 0000002A57D4: BF870002
	v_lshlrev_b32_e32 v12, 2, v12                              // 0000002A57D8: 30181882
	ds_bpermute_b32 v8, v12, v5                                // 0000002A57DC: DACC0000 0800050C
	s_waitcnt lgkmcnt(1)                                       // 0000002A57E4: BF89FC17
	v_add_f32_e32 v2, v2, v6                                   // 0000002A57E8: 06040D02
	ds_bpermute_b32 v6, v12, v3                                // 0000002A57EC: DACC0000 0600030C
	ds_bpermute_b32 v7, v12, v4                                // 0000002A57F4: DACC0000 0700040C
	s_waitcnt lgkmcnt(2)                                       // 0000002A57FC: BF89FC27
	v_add_f32_e32 v5, v5, v8                                   // 0000002A5800: 060A1105
	ds_bpermute_b32 v11, v12, v2                               // 0000002A5804: DACC0000 0B00020C
	v_xor_b32_e32 v12, 1, v1                                   // 0000002A580C: 3A180281
	s_waitcnt lgkmcnt(2)                                       // 0000002A5810: BF89FC27
	v_add_f32_e32 v3, v3, v6                                   // 0000002A5814: 06060D03
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000002A5818: BF8700D2
	v_cmp_gt_u32_e32 vcc_lo, 32, v12                           // 0000002A581C: 7C9818A0
	v_cndmask_b32_e32 v1, v1, v12, vcc_lo                      // 0000002A5820: 02021901
	s_and_b32 vcc_lo, exec_lo, s3                              // 0000002A5824: 8B6A037E
	s_mov_b32 s3, -1                                           // 0000002A5828: BE8300C1
	s_waitcnt lgkmcnt(0)                                       // 0000002A582C: BF89FC07
	v_dual_add_f32 v6, v2, v11 :: v_dual_lshlrev_b32 v1, 2, v1 // 0000002A5830: C9221702 06000282
	ds_bpermute_b32 v8, v1, v5                                 // 0000002A5838: DACC0000 08000501
	v_add_f32_e32 v4, v4, v7                                   // 0000002A5840: 06080F04
	ds_bpermute_b32 v2, v1, v3                                 // 0000002A5844: DACC0000 02000301
	ds_bpermute_b32 v11, v1, v6                                // 0000002A584C: DACC0000 0B000601
	ds_bpermute_b32 v7, v1, v4                                 // 0000002A5854: DACC0000 07000401
	s_waitcnt lgkmcnt(2)                                       // 0000002A585C: BF89FC27
	v_add_f32_e32 v1, v3, v2                                   // 0000002A5860: 06020503
	s_waitcnt lgkmcnt(0)                                       // 0000002A5864: BF89FC07
	v_dual_add_f32 v3, v5, v8 :: v_dual_add_f32 v2, v4, v7     // 0000002A5868: C9081105 03020F04
	v_add_f32_e32 v4, v6, v11                                  // 0000002A5870: 06081706
	s_cbranch_vccz 425                                         // 0000002A5874: BFA301A9 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x111c>
	s_and_saveexec_b32 s3, s1                                  // 0000002A5878: BE832001
	v_lshlrev_b32_e32 v5, 4, v19                               // 0000002A587C: 300A2684
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002A5880: BF870001
	v_lshl_or_b32 v5, v18, 8, v5                               // 0000002A5884: D6560005 04151112
	ds_store_b128 v5, v[1:4] offset:1024                       // 0000002A588C: DB7C0400 00000105
	s_or_b32 exec_lo, exec_lo, s3                              // 0000002A5894: 8C7E037E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002A5898: BF870009
	s_mov_b32 s8, exec_lo                                      // 0000002A589C: BE88007E
	s_waitcnt lgkmcnt(0)                                       // 0000002A58A0: BF89FC07
	s_barrier                                                  // 0000002A58A4: BFBD0000
	buffer_gl0_inv                                             // 0000002A58A8: E0AC0000 00000000
	v_cmpx_gt_u32_e32 4, v0                                    // 0000002A58B0: 7D980084
	s_cbranch_execz 407                                        // 0000002A58B4: BFA50197 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1114>
	s_load_b32 s3, s[16:17], 0x40                              // 0000002A58B8: F40000C8 F8000040
	s_waitcnt lgkmcnt(0)                                       // 0000002A58C0: BF89FC07
	s_sub_i32 s2, s2, s3                                       // 0000002A58C4: 81820302
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000002A58C8: BF870499
	s_ashr_i32 s3, s2, 31                                      // 0000002A58CC: 86039F02
	.long 0xd4530004                                           // 0000002A58D0: D4530004
	v_cndmask_b32_e32 v0, s10, v2, vcc_lo                      // 0000002A58D4: 0200040A
	s_and_b32 vcc_lo, exec_lo, s4                              // 0000002A58D8: 8B6A047E
	s_cbranch_vccnz 397                                        // 0000002A58DC: BFA4018D <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1114>
	v_add_nc_u32_e32 v13, 0x400, v16                           // 0000002A58E0: 4A1A20FF 00000400
	s_clause 0x1                                               // 0000002A58E8: BF850001
	s_load_b64 s[6:7], s[16:17], 0x38                          // 0000002A58EC: F4040188 F8000038
	s_load_b64 s[4:5], s[16:17], 0x8                           // 0000002A58F4: F4040108 F8000008
	s_mov_b32 s9, 0                                            // 0000002A58FC: BE890080
	s_mov_b32 s13, -1                                          // 0000002A5900: BE8D00C1
	s_mov_b32 s12, 0                                           // 0000002A5904: BE8C0080
	ds_load_2addr_b32 v[5:6], v13 offset1:4                    // 0000002A5908: D8DC0400 0500000D
	ds_load_2addr_b32 v[7:8], v13 offset0:8 offset1:12         // 0000002A5910: D8DC0C08 0700000D
	ds_load_2addr_b32 v[11:12], v13 offset0:16 offset1:20      // 0000002A5918: D8DC1410 0B00000D
	s_waitcnt lgkmcnt(0)                                       // 0000002A5920: BF89FC07
	s_cmp_lt_i32 s7, 3                                         // 0000002A5924: BF048307
	v_add_f32_e32 v5, 0, v5                                    // 0000002A5928: 060A0A80
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000002A592C: BF8700B1
	v_add_f32_e32 v14, v5, v6                                  // 0000002A5930: 061C0D05
	ds_load_2addr_b32 v[5:6], v13 offset0:24 offset1:28        // 0000002A5934: D8DC1C18 0500000D
	v_add_f32_e32 v7, v14, v7                                  // 0000002A593C: 060E0F0E
	v_add_f32_e32 v14, v7, v8                                  // 0000002A5940: 061C1107
	ds_load_2addr_b32 v[7:8], v13 offset0:32 offset1:36        // 0000002A5944: D8DC2420 0700000D
	v_add_f32_e32 v11, v14, v11                                // 0000002A594C: 0616170E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000002A5950: BF8700C1
	v_add_f32_e32 v14, v11, v12                                // 0000002A5954: 061C190B
	ds_load_2addr_b32 v[11:12], v13 offset0:40 offset1:44      // 0000002A5958: D8DC2C28 0B00000D
	s_waitcnt lgkmcnt(2)                                       // 0000002A5960: BF89FC27
	v_add_f32_e32 v5, v14, v5                                  // 0000002A5964: 060A0B0E
	v_add_f32_e32 v5, v5, v6                                   // 0000002A5968: 060A0D05
	s_waitcnt lgkmcnt(1)                                       // 0000002A596C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000002A5970: BF8700C1
	v_add_f32_e32 v7, v5, v7                                   // 0000002A5974: 060E0F05
	ds_load_2addr_b32 v[5:6], v13 offset0:48 offset1:52        // 0000002A5978: D8DC3430 0500000D
	v_add_f32_e32 v7, v7, v8                                   // 0000002A5980: 060E1107
	s_waitcnt lgkmcnt(1)                                       // 0000002A5984: BF89FC17
	v_add_f32_e32 v11, v7, v11                                 // 0000002A5988: 06161707
	ds_load_2addr_b32 v[7:8], v13 offset0:56 offset1:60        // 0000002A598C: D8DC3C38 0700000D
	v_add_f32_e32 v11, v11, v12                                // 0000002A5994: 0616190B
	s_waitcnt lgkmcnt(1)                                       // 0000002A5998: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A599C: BF870091
	v_add_f32_e32 v5, v11, v5                                  // 0000002A59A0: 060A0B0B
	v_add_f32_e32 v5, v5, v6                                   // 0000002A59A4: 060A0D05
	s_waitcnt lgkmcnt(0)                                       // 0000002A59A8: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A59AC: BF870091
	v_add_f32_e32 v5, v5, v7                                   // 0000002A59B0: 060A0F05
	v_add_f32_e32 v5, v5, v8                                   // 0000002A59B4: 060A1105
	s_cbranch_scc1 178                                         // 0000002A59B8: BFA200B2 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0xe84>
	s_cmp_gt_i32 s7, 3                                         // 0000002A59BC: BF028307
	s_cbranch_scc0 112                                         // 0000002A59C0: BFA10070 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0xd84>
	s_cmp_gt_i32 s7, 4                                         // 0000002A59C4: BF028407
	s_cbranch_scc0 58                                          // 0000002A59C8: BFA1003A <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0xcb4>
	s_cmp_eq_u32 s7, 5                                         // 0000002A59CC: BF068507
	s_mov_b32 s12, -1                                          // 0000002A59D0: BE8C00C1
	s_cbranch_scc0 54                                          // 0000002A59D4: BFA10036 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0xcb0>
	s_ashr_i32 s14, s2, 31                                     // 0000002A59D8: 860E9F02
	s_load_b64 s[12:13], s[16:17], 0x10                        // 0000002A59DC: F4040308 F8000010
	s_lshr_b32 s14, s14, 23                                    // 0000002A59E4: 850E970E
	s_lshr_b32 s15, s10, 31                                    // 0000002A59E8: 850F9F0A
	s_add_i32 s14, s2, s14                                     // 0000002A59EC: 810E0E02
	s_add_i32 s18, s10, s15                                    // 0000002A59F0: 81120F0A
	s_ashr_i32 s14, s14, 9                                     // 0000002A59F4: 860E890E
	s_ashr_i32 s18, s18, 1                                     // 0000002A59F8: 86128112
	s_ashr_i32 s15, s14, 31                                    // 0000002A59FC: 860F9F0E
	v_mad_i64_i32 v[6:7], null, s18, v0, 0                     // 0000002A5A00: D6FF7C06 02020012
	s_lshl_b64 s[14:15], s[14:15], 9                           // 0000002A5A08: 848E890E
	v_bfe_u32 v8, v5, 16, 1                                    // 0000002A5A0C: D6100008 02052105
	s_sub_u32 s18, s2, s14                                     // 0000002A5A14: 80920E02
	s_subb_u32 s19, s3, s15                                    // 0000002A5A18: 82930F03
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002A5A1C: BF870119
	.long 0xd4540014                                           // 0000002A5A20: D4540014
	v_cndmask_b32_e32 v0, 0x100, v18, vcc_lo                   // 0000002A5A24: 020024FF 00000100
	v_add3_u32 v8, v5, v8, 0x7fff                              // 0000002A5A2C: D6550008 03FE1105 00007FFF
	.long 0xd73c0006                                           // 0000002A5A38: D73C0006
	v_cndmask_b32_e32 v1, 1, v6, vcc_lo                        // 0000002A5A3C: 02020C81
	s_and_b32 s21, s20, exec_lo                                // 0000002A5A40: 8B157E14
	s_waitcnt lgkmcnt(0)                                       // 0000002A5A44: BF89FC07
	s_cselect_b32 s12, s4, s12                                 // 0000002A5A48: 980C0C04
	s_cselect_b32 s21, s5, s13                                 // 0000002A5A4C: 98150D05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A5A50: BF870091
	.long 0xd7006a06                                           // 0000002A5A54: D7006A06
	v_cndmask_b32_e32 v1, s12, v6, vcc_lo                      // 0000002A5A58: 02020C0C
	v_add_co_ci_u32_e64 v7, null, s21, v7, vcc_lo              // 0000002A5A5C: D5207C07 01AA0E15
	s_add_u32 s22, s18, 0xffffff00                             // 0000002A5A64: 8016FF12 FFFFFF00
	s_addc_u32 s13, s19, -1                                    // 0000002A5A6C: 820DC113
	s_and_b32 s20, s20, exec_lo                                // 0000002A5A70: 8B147E14
	.long 0xd7006a06                                           // 0000002A5A74: D7006A06
	v_cndmask_b32_e32 v0, v6, v14, vcc_lo                      // 0000002A5A78: 02001D06
	s_cselect_b32 s13, s19, s13                                // 0000002A5A7C: 980D0D13
	s_cselect_b32 s12, s18, s22                                // 0000002A5A80: 980C1612
	v_add_co_ci_u32_e64 v7, null, s15, v7, vcc_lo              // 0000002A5A84: D5207C07 01AA0E0F
	s_lshl_b64 s[12:13], s[12:13], 1                           // 0000002A5A8C: 848C810C
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A5A90: BF870099
	.long 0xd7006a06                                           // 0000002A5A94: D7006A06
	v_cndmask_b32_e32 v0, v6, v12, vcc_lo                      // 0000002A5A98: 02001906
	v_add_co_ci_u32_e64 v7, null, s13, v7, vcc_lo              // 0000002A5A9C: D5207C07 01AA0E0D
	s_mov_b32 s12, 0                                           // 0000002A5AA4: BE8C0080
	global_store_d16_hi_b16 v[6:7], v8, off                    // 0000002A5AA8: DC960000 007C0806
	s_mov_b32 s13, 0                                           // 0000002A5AB0: BE8D0080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002A5AB4: BF870009
	s_and_b32 vcc_lo, exec_lo, s13                             // 0000002A5AB8: 8B6A0D7E
	s_cbranch_vccz 48                                          // 0000002A5ABC: BFA30030 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0xd80>
	v_mul_f32_e32 v6, 0xbfb8aa3b, v5                           // 0000002A5AC0: 100C0AFF BFB8AA3B
	s_lshl_b64 s[14:15], s[2:3], 2                             // 0000002A5AC8: 848E8202
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002A5ACC: BF870291
	v_exp_f32_e32 v6, v6                                       // 0000002A5AD0: 7E0C4B06
	v_add_f32_e32 v11, 1.0, v6                                 // 0000002A5AD4: 06160CF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002A5AD8: BF870121
	v_div_scale_f32 v12, null, v11, v11, 1.0                   // 0000002A5ADC: D6FC7C0C 03CA170B
	v_div_scale_f32 v14, vcc_lo, 1.0, v11, 1.0                 // 0000002A5AE4: D6FC6A0E 03CA16F2
	v_rcp_f32_e32 v13, v12                                     // 0000002A5AEC: 7E1A550C
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A5AF0: BF870095
	v_fma_f32 v6, -v12, v13, 1.0                               // 0000002A5AF4: D6130006 23CA1B0C
	v_fmac_f32_e32 v13, v6, v13                                // 0000002A5AFC: 561A1B06
	v_mad_u64_u32 v[6:7], null, s10, v0, 0                     // 0000002A5B00: D6FE7C06 0202000A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002A5B08: BF870112
	v_mul_f32_e32 v15, v14, v13                                // 0000002A5B0C: 101E1B0E
	v_mad_u64_u32 v[7:8], null, s11, v0, v[7:8]                // 0000002A5B10: D6FE7C07 041E000B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A5B18: BF870092
	v_fma_f32 v16, -v12, v15, v14                              // 0000002A5B1C: D6130010 243A1F0C
	v_fmac_f32_e32 v15, v16, v13                               // 0000002A5B24: 561E1B10
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002A5B28: BF870113
	.long 0xd73c0006                                           // 0000002A5B2C: D73C0006
	v_cndmask_b32_e32 v1, 2, v6, vcc_lo                        // 0000002A5B30: 02020C82
	v_fma_f32 v8, -v12, v15, v14                               // 0000002A5B34: D6130008 243A1F0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002A5B3C: BF870191
	v_div_fmas_f32 v8, v8, v13, v15                            // 0000002A5B40: D6370008 043E1B08
	.long 0xd7006a06                                           // 0000002A5B48: D7006A06
	v_cndmask_b32_e32 v1, s4, v6, vcc_lo                       // 0000002A5B4C: 02020C04
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002A5B50: BF870191
	v_add_co_ci_u32_e64 v7, null, s5, v7, vcc_lo               // 0000002A5B54: D5207C07 01AA0E05
	v_div_fixup_f32 v8, v8, v11, 1.0                           // 0000002A5B5C: D6270008 03CA1708
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A5B64: BF870093
	.long 0xd7006a06                                           // 0000002A5B68: D7006A06
	v_cndmask_b32_e32 v0, v6, v14, vcc_lo                      // 0000002A5B6C: 02001D06
	v_add_co_ci_u32_e64 v7, null, s15, v7, vcc_lo              // 0000002A5B70: D5207C07 01AA0E0F
	global_store_b32 v[6:7], v8, off                           // 0000002A5B78: DC6A0000 007C0806
	s_mov_b32 s13, 0                                           // 0000002A5B80: BE8D0080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002A5B84: BF870009
	s_and_b32 vcc_lo, exec_lo, s13                             // 0000002A5B88: 8B6A0D7E
	s_cbranch_vccz 60                                          // 0000002A5B8C: BFA3003C <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0xe80>
	v_bfe_u32 v6, v5, 16, 1                                    // 0000002A5B90: D6100006 02052105
	s_lshl_b64 s[14:15], s[2:3], 2                             // 0000002A5B98: 848E8202
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A5B9C: BF870091
	v_add3_u32 v6, v5, v6, 0x7fff                              // 0000002A5BA0: D6550006 03FE0D05 00007FFF
	v_and_b32_e32 v6, 0xffff0000, v6                           // 0000002A5BAC: 360C0CFF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A5BB4: BF870091
	v_mul_f32_e32 v6, s6, v6                                   // 0000002A5BB8: 100C0C06
	v_mul_f32_e32 v6, 0xbfb8aa3b, v6                           // 0000002A5BBC: 100C0CFF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002A5BC4: BF870291
	v_exp_f32_e32 v6, v6                                       // 0000002A5BC8: 7E0C4B06
	v_add_f32_e32 v11, 1.0, v6                                 // 0000002A5BCC: 06160CF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002A5BD0: BF870121
	v_div_scale_f32 v12, null, v11, v11, 1.0                   // 0000002A5BD4: D6FC7C0C 03CA170B
	v_div_scale_f32 v14, vcc_lo, 1.0, v11, 1.0                 // 0000002A5BDC: D6FC6A0E 03CA16F2
	v_rcp_f32_e32 v13, v12                                     // 0000002A5BE4: 7E1A550C
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A5BE8: BF870095
	v_fma_f32 v6, -v12, v13, 1.0                               // 0000002A5BEC: D6130006 23CA1B0C
	v_fmac_f32_e32 v13, v6, v13                                // 0000002A5BF4: 561A1B06
	v_mad_u64_u32 v[6:7], null, s10, v0, 0                     // 0000002A5BF8: D6FE7C06 0202000A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A5C00: BF870092
	v_mul_f32_e32 v15, v14, v13                                // 0000002A5C04: 101E1B0E
	v_fma_f32 v8, -v12, v15, v14                               // 0000002A5C08: D6130008 243A1F0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002A5C10: BF870211
	v_fmac_f32_e32 v15, v8, v13                                // 0000002A5C14: 561E1B08
	v_mad_u64_u32 v[7:8], null, s11, v0, v[7:8]                // 0000002A5C18: D6FE7C07 041E000B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002A5C20: BF870112
	v_fma_f32 v8, -v12, v15, v14                               // 0000002A5C24: D6130008 243A1F0C
	.long 0xd73c0006                                           // 0000002A5C2C: D73C0006
	v_cndmask_b32_e32 v1, 2, v6, vcc_lo                        // 0000002A5C30: 02020C82
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002A5C34: BF870112
	v_div_fmas_f32 v8, v8, v13, v15                            // 0000002A5C38: D6370008 043E1B08
	.long 0xd7006a06                                           // 0000002A5C40: D7006A06
	v_cndmask_b32_e32 v1, s4, v6, vcc_lo                       // 0000002A5C44: 02020C04
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002A5C48: BF870212
	v_div_fixup_f32 v8, v8, v11, 1.0                           // 0000002A5C4C: D6270008 03CA1708
	v_add_co_ci_u32_e64 v7, null, s5, v7, vcc_lo               // 0000002A5C54: D5207C07 01AA0E05
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002A5C5C: BF870193
	.long 0xd7006a06                                           // 0000002A5C60: D7006A06
	v_cndmask_b32_e32 v0, v6, v14, vcc_lo                      // 0000002A5C64: 02001D06
	v_add_f32_e32 v8, v8, v8                                   // 0000002A5C68: 06101108
	s_delay_alu instid0(VALU_DEP_3)                            // 0000002A5C6C: BF870003
	v_add_co_ci_u32_e64 v7, null, s15, v7, vcc_lo              // 0000002A5C70: D5207C07 01AA0E0F
	global_store_b32 v[6:7], v8, off                           // 0000002A5C78: DC6A0000 007C0806
	s_mov_b32 s13, 0                                           // 0000002A5C80: BE8D0080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002A5C84: BF870009
	s_and_b32 vcc_lo, exec_lo, s13                             // 0000002A5C88: 8B6A0D7E
	s_cbranch_vccz 72                                          // 0000002A5C8C: BFA30048 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0xfb0>
	s_cmp_gt_i32 s7, 1                                         // 0000002A5C90: BF028107
	s_mov_b32 s9, -1                                           // 0000002A5C94: BE8900C1
	s_cbranch_scc0 63                                          // 0000002A5C98: BFA1003F <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0xf98>
	v_bfe_u32 v6, v5, 16, 1                                    // 0000002A5C9C: D6100006 02052105
	s_lshl_b64 s[14:15], s[2:3], 1                             // 0000002A5CA4: 848E8102
	s_mov_b32 s9, 0                                            // 0000002A5CA8: BE890080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A5CAC: BF870091
	v_add3_u32 v6, v5, v6, 0x7fff                              // 0000002A5CB0: D6550006 03FE0D05 00007FFF
	v_and_b32_e32 v6, 0xffff0000, v6                           // 0000002A5CBC: 360C0CFF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A5CC4: BF870091
	v_mul_f32_e32 v6, 0xbfb8aa3b, v6                           // 0000002A5CC8: 100C0CFF BFB8AA3B
	v_exp_f32_e32 v6, v6                                       // 0000002A5CD0: 7E0C4B06
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A5CD4: BF870095
	v_add_f32_e32 v11, 1.0, v6                                 // 0000002A5CD8: 06160CF2
	v_div_scale_f32 v8, null, v11, v11, 1.0                    // 0000002A5CDC: D6FC7C08 03CA170B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002A5CE4: BF870291
	v_rcp_f32_e32 v12, v8                                      // 0000002A5CE8: 7E185508
	v_fma_f32 v6, -v8, v12, 1.0                                // 0000002A5CEC: D6130006 23CA1908
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000002A5CF4: BF870131
	v_fmac_f32_e32 v12, v6, v12                                // 0000002A5CF8: 56181906
	v_div_scale_f32 v13, vcc_lo, 1.0, v11, 1.0                 // 0000002A5CFC: D6FC6A0D 03CA16F2
	v_mad_u64_u32 v[6:7], null, s10, v0, 0                     // 0000002A5D04: D6FE7C06 0202000A
	v_mul_f32_e32 v14, v13, v12                                // 0000002A5D0C: 101C190D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A5D10: BF870091
	v_fma_f32 v15, -v8, v14, v13                               // 0000002A5D14: D613000F 24361D08
	v_fmac_f32_e32 v14, v15, v12                               // 0000002A5D1C: 561C190F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002A5D20: BF870121
	v_fma_f32 v13, -v8, v14, v13                               // 0000002A5D24: D613000D 24361D08
	v_mad_u64_u32 v[7:8], null, s11, v0, v[7:8]                // 0000002A5D2C: D6FE7C07 041E000B
	v_div_fmas_f32 v8, v13, v12, v14                           // 0000002A5D34: D6370008 043A190D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002A5D3C: BF870112
	.long 0xd73c0006                                           // 0000002A5D40: D73C0006
	v_cndmask_b32_e32 v1, 1, v6, vcc_lo                        // 0000002A5D44: 02020C81
	v_div_fixup_f32 v8, v8, v11, 1.0                           // 0000002A5D48: D6270008 03CA1708
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002A5D50: BF870112
	.long 0xd7006a06                                           // 0000002A5D54: D7006A06
	v_cndmask_b32_e32 v1, s4, v6, vcc_lo                       // 0000002A5D58: 02020C04
	v_bfe_u32 v11, v8, 16, 1                                   // 0000002A5D5C: D610000B 02052108
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002A5D64: BF870194
	v_add_co_ci_u32_e64 v7, null, s5, v7, vcc_lo               // 0000002A5D68: D5207C07 01AA0E05
	.long 0xd7006a06                                           // 0000002A5D70: D7006A06
	v_cndmask_b32_e32 v0, v6, v14, vcc_lo                      // 0000002A5D74: 02001D06
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002A5D78: BF870193
	v_add3_u32 v8, v8, v11, 0x7fff                             // 0000002A5D7C: D6550008 03FE1708 00007FFF
	v_add_co_ci_u32_e64 v7, null, s15, v7, vcc_lo              // 0000002A5D88: D5207C07 01AA0E0F
	global_store_d16_hi_b16 v[6:7], v8, off                    // 0000002A5D90: DC960000 007C0806
	s_and_not1_b32 vcc_lo, exec_lo, s9                         // 0000002A5D98: 916A097E
	s_mov_b32 s9, 0                                            // 0000002A5D9C: BE890080
	s_cbranch_vccnz 3                                          // 0000002A5DA0: BFA40003 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0xfb0>
	s_cmp_lg_u32 s7, 1                                         // 0000002A5DA4: BF078107
	s_mov_b32 s9, -1                                           // 0000002A5DA8: BE8900C1
	s_cselect_b32 s12, -1, 0                                   // 0000002A5DAC: 980C80C1
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002A5DB0: BF8700A1
	v_bfe_u32 v6, v5, 16, 1                                    // 0000002A5DB4: D6100006 02052105
	s_and_b32 vcc_lo, exec_lo, s12                             // 0000002A5DBC: 8B6A0C7E
	v_add3_u32 v5, v5, v6, 0x7fff                              // 0000002A5DC0: D6550005 03FE0D05 00007FFF
	s_cbranch_vccz 21                                          // 0000002A5DCC: BFA30015 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1024>
	v_mad_u64_u32 v[6:7], null, s10, v0, 0                     // 0000002A5DD0: D6FE7C06 0202000A
	s_lshl_b64 s[12:13], s[2:3], 1                             // 0000002A5DD8: 848C8102
	s_mov_b32 s9, 0                                            // 0000002A5DDC: BE890080
	v_mad_u64_u32 v[7:8], null, s11, v0, v[7:8]                // 0000002A5DE0: D6FE7C07 041E000B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A5DE8: BF870091
	.long 0xd73c0006                                           // 0000002A5DEC: D73C0006
	v_cndmask_b32_e32 v1, 1, v6, vcc_lo                        // 0000002A5DF0: 02020C81
	.long 0xd7006a06                                           // 0000002A5DF4: D7006A06
	v_cndmask_b32_e32 v1, s4, v6, vcc_lo                       // 0000002A5DF8: 02020C04
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002A5DFC: BF870111
	v_add_co_ci_u32_e64 v7, null, s5, v7, vcc_lo               // 0000002A5E00: D5207C07 01AA0E05
	.long 0xd7006a06                                           // 0000002A5E08: D7006A06
	v_cndmask_b32_e32 v0, v6, v12, vcc_lo                      // 0000002A5E0C: 02001906
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002A5E10: BF870001
	v_add_co_ci_u32_e64 v7, null, s13, v7, vcc_lo              // 0000002A5E14: D5207C07 01AA0E0D
	global_store_d16_hi_b16 v[6:7], v5, off                    // 0000002A5E1C: DC960000 007C0506
	s_and_not1_b32 vcc_lo, exec_lo, s9                         // 0000002A5E24: 916A097E
	s_cbranch_vccnz 58                                         // 0000002A5E28: BFA4003A <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1114>
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002A5E2C: BF8700A1
	v_and_b32_e32 v5, 0xffff0000, v5                           // 0000002A5E30: 360A0AFF FFFF0000
	s_lshl_b64 s[2:3], s[2:3], 1                               // 0000002A5E38: 84828102
	v_mul_f32_e32 v8, s6, v5                                   // 0000002A5E3C: 10100A06
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A5E40: BF870091
	v_mul_f32_e32 v5, 0xbfb8aa3b, v8                           // 0000002A5E44: 100A10FF BFB8AA3B
	v_exp_f32_e32 v5, v5                                       // 0000002A5E4C: 7E0A4B05
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A5E50: BF870095
	v_add_f32_e32 v11, 1.0, v5                                 // 0000002A5E54: 06160AF2
	v_div_scale_f32 v7, null, v11, v11, v8                     // 0000002A5E58: D6FC7C07 0422170B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002A5E60: BF870291
	v_rcp_f32_e32 v12, v7                                      // 0000002A5E64: 7E185507
	v_fma_f32 v5, -v7, v12, 1.0                                // 0000002A5E68: D6130005 23CA1907
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000002A5E70: BF870131
	v_fmac_f32_e32 v12, v5, v12                                // 0000002A5E74: 56181905
	v_div_scale_f32 v13, vcc_lo, v8, v11, v8                   // 0000002A5E78: D6FC6A0D 04221708
	v_mad_u64_u32 v[5:6], null, s10, v0, 0                     // 0000002A5E80: D6FE7C05 0202000A
	v_mul_f32_e32 v14, v13, v12                                // 0000002A5E88: 101C190D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A5E8C: BF870091
	v_fma_f32 v15, -v7, v14, v13                               // 0000002A5E90: D613000F 24361D07
	v_fmac_f32_e32 v14, v15, v12                               // 0000002A5E98: 561C190F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002A5E9C: BF870121
	v_fma_f32 v13, -v7, v14, v13                               // 0000002A5EA0: D613000D 24361D07
	v_mad_u64_u32 v[6:7], null, s11, v0, v[6:7]                // 0000002A5EA8: D6FE7C06 041A000B
	v_div_fmas_f32 v0, v13, v12, v14                           // 0000002A5EB0: D6370000 043A190D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002A5EB8: BF870112
	.long 0xd73c0005                                           // 0000002A5EBC: D73C0005
	v_cndmask_b32_e32 v1, 1, v5, vcc_lo                        // 0000002A5EC0: 02020A81
	v_div_fixup_f32 v0, v0, v11, v8                            // 0000002A5EC4: D6270000 04221700
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002A5ECC: BF870112
	.long 0xd7006a05                                           // 0000002A5ED0: D7006A05
	v_cndmask_b32_e32 v1, s4, v5, vcc_lo                       // 0000002A5ED4: 02020A04
	v_bfe_u32 v7, v0, 16, 1                                    // 0000002A5ED8: D6100007 02052100
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002A5EE0: BF870194
	v_add_co_ci_u32_e64 v6, null, s5, v6, vcc_lo               // 0000002A5EE4: D5207C06 01AA0C05
	.long 0xd7006a05                                           // 0000002A5EEC: D7006A05
	v_cndmask_b32_e32 v0, v5, v2, vcc_lo                       // 0000002A5EF0: 02000505
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002A5EF4: BF870193
	v_add3_u32 v0, v0, v7, 0x7fff                              // 0000002A5EF8: D6550000 03FE0F00 00007FFF
	v_add_co_ci_u32_e64 v6, null, s3, v6, vcc_lo               // 0000002A5F04: D5207C06 01AA0C03
	global_store_d16_hi_b16 v[5:6], v0, off                    // 0000002A5F0C: DC960000 007C0005
	s_or_b32 exec_lo, exec_lo, s8                              // 0000002A5F14: 8C7E087E
	s_mov_b32 s3, 0                                            // 0000002A5F18: BE830080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002A5F1C: BF870009
	s_and_b32 vcc_lo, exec_lo, s3                              // 0000002A5F20: 8B6A037E
	s_cbranch_vccz 1091                                        // 0000002A5F24: BFA30443 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x2234>
	s_and_b32 s0, s1, s0                                       // 0000002A5F28: 8B000001
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002A5F2C: BF870009
	s_and_saveexec_b32 s1, s0                                  // 0000002A5F30: BE812000
	s_cbranch_execz 1087                                       // 0000002A5F34: BFA5043F <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x2234>
	v_ashrrev_i32_e32 v0, 31, v10                              // 0000002A5F38: 3400149F
	s_clause 0x1                                               // 0000002A5F3C: BF850001
	s_load_b64 s[4:5], s[16:17], 0x8                           // 0000002A5F40: F4040108 F8000008
	s_load_b64 s[2:3], s[16:17], 0x38                          // 0000002A5F48: F4040088 F8000038
	.long 0xd73c0005                                           // 0000002A5F50: D73C0005
	v_cndmask_b32_e32 v1, 1, v9, vcc_lo                        // 0000002A5F54: 02021281
	.long 0xd73c0007                                           // 0000002A5F58: D73C0007
	v_cndmask_b32_e32 v1, 2, v9, vcc_lo                        // 0000002A5F5C: 02021282
	s_mov_b32 s7, -1                                           // 0000002A5F60: BE8700C1
	v_lshrrev_b32_e32 v0, 23, v0                               // 0000002A5F64: 32000097
	s_mov_b32 s1, 0                                            // 0000002A5F68: BE810080
	s_mov_b32 s6, 0                                            // 0000002A5F6C: BE860080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A5F70: BF870091
	.long 0xd7006a0b                                           // 0000002A5F74: D7006A0B
	v_cndmask_b32_e32 v1, v9, v0, vcc_lo                       // 0000002A5F78: 02020109
	v_add_co_ci_u32_e64 v0, null, 0, v10, vcc_lo               // 0000002A5F7C: D5207C00 01AA1480
	.long 0xd7016a05                                           // 0000002A5F84: D7016A05
	v_cndmask_b32_e32 v1, 0, v5, vcc_lo                        // 0000002A5F88: 02020A80
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002A5F8C: BF870123
	v_and_b32_e32 v11, 0xfffffe00, v11                         // 0000002A5F90: 361616FF FFFFFE00
	v_sub_co_ci_u32_e64 v6, null, 0, v6, vcc_lo                // 0000002A5F98: D5217C06 01AA0C80
	.long 0xd7016a09                                           // 0000002A5FA0: D7016A09
	v_cndmask_b32_e32 v1, v9, v11, vcc_lo                      // 0000002A5FA4: 02021709
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000002A5FA8: BF8700B1
	v_sub_co_ci_u32_e64 v10, null, v10, v0, vcc_lo             // 0000002A5FAC: D5217C0A 01AA010A
	s_waitcnt lgkmcnt(0)                                       // 0000002A5FB4: BF89FC07
	.long 0xd7006a07                                           // 0000002A5FB8: D7006A07
	v_cndmask_b32_e32 v1, s4, v7, vcc_lo                       // 0000002A5FBC: 02020E04
	v_add_co_ci_u32_e64 v8, null, s5, v8, vcc_lo               // 0000002A5FC0: D5207C08 01AA1005
	.long 0xd7006a0c                                           // 0000002A5FC8: D7006A0C
	v_cndmask_b32_e32 v1, 0xffffff00, v9, vcc_lo               // 0000002A5FCC: 020212FF FFFFFF00
	.long 0xd4540000                                           // 0000002A5FD4: D4540000
	v_cndmask_b32_e32 v1, 0x100, v9, vcc_lo                    // 0000002A5FD8: 020212FF 00000100
	v_add_co_ci_u32_e64 v13, null, -1, v10, vcc_lo             // 0000002A5FE0: D5207C0D 01AA14C1
	.long 0xd7006a05                                           // 0000002A5FE8: D7006A05
	v_cndmask_b32_e32 v1, v7, v5, vcc_lo                       // 0000002A5FEC: 02020B07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002A5FF0: BF870191
	v_add_co_ci_u32_e64 v6, null, v8, v6, vcc_lo               // 0000002A5FF4: D5207C06 01AA0D08
	v_cndmask_b32_e64 v10, v13, v10, s0                        // 0000002A5FFC: D501000A 0002150D
	v_cndmask_b32_e64 v9, v12, v9, s0                          // 0000002A6004: D5010009 0002130C
	s_cmp_lt_i32 s3, 3                                         // 0000002A600C: BF048303
	s_cbranch_scc1 118                                         // 0000002A6010: BFA20076 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x13ec>
	s_cmp_gt_i32 s3, 3                                         // 0000002A6014: BF028303
	s_cbranch_scc0 70                                          // 0000002A6018: BFA10046 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1334>
	s_cmp_gt_i32 s3, 4                                         // 0000002A601C: BF028403
	s_cbranch_scc0 34                                          // 0000002A6020: BFA10022 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x12ac>
	s_cmp_eq_u32 s3, 5                                         // 0000002A6024: BF068503
	s_mov_b32 s6, -1                                           // 0000002A6028: BE8600C1
	s_cbranch_scc0 30                                          // 0000002A602C: BFA1001E <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x12a8>
	s_load_b64 s[6:7], s[16:17], 0x10                          // 0000002A6030: F4040188 F8000010
	v_dual_mov_b32 v12, s4 :: v_dual_mov_b32 v13, s5           // 0000002A6038: CA100004 0C0C0005
	v_bfe_u32 v15, v1, 16, 1                                   // 0000002A6040: D610000F 02052101
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000002A6048: BF8701A1
	v_add3_u32 v15, v1, v15, 0x7fff                            // 0000002A604C: D655000F 03FE1F01 00007FFF
	s_waitcnt lgkmcnt(0)                                       // 0000002A6058: BF89FC07
	v_cndmask_b32_e64 v14, s6, v12, s0                         // 0000002A605C: D501000E 00021806
	v_cndmask_b32_e64 v16, s7, v13, s0                         // 0000002A6064: D5010010 00021A07
	.long 0xd73c000c                                           // 0000002A606C: D73C000C
	v_cndmask_b32_e32 v1, 1, v9, vcc_lo                        // 0000002A6070: 02021281
	s_mov_b32 s6, 0                                            // 0000002A6074: BE860080
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A6078: BF870093
	.long 0xd7006a0e                                           // 0000002A607C: D7006A0E
	v_cndmask_b32_e32 v1, v14, v11, vcc_lo                     // 0000002A6080: 0202170E
	v_add_co_ci_u32_e64 v16, null, v16, v0, vcc_lo             // 0000002A6084: D5207C10 01AA0110
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A608C: BF870092
	.long 0xd7006a0c                                           // 0000002A6090: D7006A0C
	v_cndmask_b32_e32 v1, v14, v12, vcc_lo                     // 0000002A6094: 0202190E
	v_add_co_ci_u32_e64 v13, null, v16, v13, vcc_lo            // 0000002A6098: D5207C0D 01AA1B10
	global_store_d16_hi_b16 v[12:13], v15, off                 // 0000002A60A0: DC960000 007C0F0C
	s_mov_b32 s7, 0                                            // 0000002A60A8: BE870080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002A60AC: BF870009
	s_and_b32 vcc_lo, exec_lo, s7                              // 0000002A60B0: 8B6A077E
	s_cbranch_vccz 30                                          // 0000002A60B4: BFA3001E <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1330>
	v_mul_f32_e32 v12, 0xbfb8aa3b, v1                          // 0000002A60B8: 101802FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002A60C0: BF870291
	v_exp_f32_e32 v12, v12                                     // 0000002A60C4: 7E184B0C
	v_add_f32_e32 v12, 1.0, v12                                // 0000002A60C8: 061818F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A60CC: BF870091
	v_div_scale_f32 v13, null, v12, v12, 1.0                   // 0000002A60D0: D6FC7C0D 03CA190C
	v_rcp_f32_e32 v14, v13                                     // 0000002A60D8: 7E1C550D
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A60DC: BF870095
	v_fma_f32 v15, -v13, v14, 1.0                              // 0000002A60E0: D613000F 23CA1D0D
	v_fmac_f32_e32 v14, v15, v14                               // 0000002A60E8: 561C1D0F
	v_div_scale_f32 v15, vcc_lo, 1.0, v12, 1.0                 // 0000002A60EC: D6FC6A0F 03CA18F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A60F4: BF870091
	v_mul_f32_e32 v16, v15, v14                                // 0000002A60F8: 10201D0F
	v_fma_f32 v17, -v13, v16, v15                              // 0000002A60FC: D6130011 243E210D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A6104: BF870091
	v_fmac_f32_e32 v16, v17, v14                               // 0000002A6108: 56201D11
	v_fma_f32 v13, -v13, v16, v15                              // 0000002A610C: D613000D 243E210D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A6114: BF870091
	v_div_fmas_f32 v13, v13, v14, v16                          // 0000002A6118: D637000D 04421D0D
	v_div_fixup_f32 v12, v13, v12, 1.0                         // 0000002A6120: D627000C 03CA190D
	global_store_b32 v[7:8], v12, off                          // 0000002A6128: DC6A0000 007C0C07
	s_mov_b32 s7, 0                                            // 0000002A6130: BE870080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002A6134: BF870009
	s_and_b32 vcc_lo, exec_lo, s7                              // 0000002A6138: 8B6A077E
	s_cbranch_vccz 42                                          // 0000002A613C: BFA3002A <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x13e8>
	v_bfe_u32 v12, v1, 16, 1                                   // 0000002A6140: D610000C 02052101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A6148: BF870091
	v_add3_u32 v12, v1, v12, 0x7fff                            // 0000002A614C: D655000C 03FE1901 00007FFF
	v_and_b32_e32 v12, 0xffff0000, v12                         // 0000002A6158: 361818FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A6160: BF870091
	v_mul_f32_e32 v12, s2, v12                                 // 0000002A6164: 10181802
	v_mul_f32_e32 v12, 0xbfb8aa3b, v12                         // 0000002A6168: 101818FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002A6170: BF870291
	v_exp_f32_e32 v12, v12                                     // 0000002A6174: 7E184B0C
	v_add_f32_e32 v12, 1.0, v12                                // 0000002A6178: 061818F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A617C: BF870091
	v_div_scale_f32 v13, null, v12, v12, 1.0                   // 0000002A6180: D6FC7C0D 03CA190C
	v_rcp_f32_e32 v14, v13                                     // 0000002A6188: 7E1C550D
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A618C: BF870095
	v_fma_f32 v15, -v13, v14, 1.0                              // 0000002A6190: D613000F 23CA1D0D
	v_fmac_f32_e32 v14, v15, v14                               // 0000002A6198: 561C1D0F
	v_div_scale_f32 v15, vcc_lo, 1.0, v12, 1.0                 // 0000002A619C: D6FC6A0F 03CA18F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A61A4: BF870091
	v_mul_f32_e32 v16, v15, v14                                // 0000002A61A8: 10201D0F
	v_fma_f32 v17, -v13, v16, v15                              // 0000002A61AC: D6130011 243E210D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A61B4: BF870091
	v_fmac_f32_e32 v16, v17, v14                               // 0000002A61B8: 56201D11
	v_fma_f32 v13, -v13, v16, v15                              // 0000002A61BC: D613000D 243E210D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A61C4: BF870091
	v_div_fmas_f32 v13, v13, v14, v16                          // 0000002A61C8: D637000D 04421D0D
	v_div_fixup_f32 v12, v13, v12, 1.0                         // 0000002A61D0: D627000C 03CA190D
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002A61D8: BF870001
	v_add_f32_e32 v12, v12, v12                                // 0000002A61DC: 0618190C
	global_store_b32 v[7:8], v12, off                          // 0000002A61E0: DC6A0000 007C0C07
	s_mov_b32 s7, 0                                            // 0000002A61E8: BE870080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002A61EC: BF870009
	s_and_b32 vcc_lo, exec_lo, s7                              // 0000002A61F0: 8B6A077E
	s_cbranch_vccz 55                                          // 0000002A61F4: BFA30037 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x14d4>
	s_cmp_gt_i32 s3, 1                                         // 0000002A61F8: BF028103
	s_mov_b32 s1, -1                                           // 0000002A61FC: BE8100C1
	s_cbranch_scc0 46                                          // 0000002A6200: BFA1002E <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x14bc>
	v_bfe_u32 v12, v1, 16, 1                                   // 0000002A6204: D610000C 02052101
	s_mov_b32 s1, 0                                            // 0000002A620C: BE810080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A6210: BF870091
	v_add3_u32 v12, v1, v12, 0x7fff                            // 0000002A6214: D655000C 03FE1901 00007FFF
	v_and_b32_e32 v12, 0xffff0000, v12                         // 0000002A6220: 361818FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A6228: BF870091
	v_mul_f32_e32 v12, 0xbfb8aa3b, v12                         // 0000002A622C: 101818FF BFB8AA3B
	v_exp_f32_e32 v12, v12                                     // 0000002A6234: 7E184B0C
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A6238: BF870095
	v_add_f32_e32 v12, 1.0, v12                                // 0000002A623C: 061818F2
	v_div_scale_f32 v13, null, v12, v12, 1.0                   // 0000002A6240: D6FC7C0D 03CA190C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002A6248: BF870291
	v_rcp_f32_e32 v14, v13                                     // 0000002A624C: 7E1C550D
	v_fma_f32 v15, -v13, v14, 1.0                              // 0000002A6250: D613000F 23CA1D0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002A6258: BF8700A1
	v_fmac_f32_e32 v14, v15, v14                               // 0000002A625C: 561C1D0F
	v_div_scale_f32 v15, vcc_lo, 1.0, v12, 1.0                 // 0000002A6260: D6FC6A0F 03CA18F2
	v_mul_f32_e32 v16, v15, v14                                // 0000002A6268: 10201D0F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A626C: BF870091
	v_fma_f32 v17, -v13, v16, v15                              // 0000002A6270: D6130011 243E210D
	v_fmac_f32_e32 v16, v17, v14                               // 0000002A6278: 56201D11
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A627C: BF870091
	v_fma_f32 v13, -v13, v16, v15                              // 0000002A6280: D613000D 243E210D
	v_div_fmas_f32 v13, v13, v14, v16                          // 0000002A6288: D637000D 04421D0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A6290: BF870091
	v_div_fixup_f32 v12, v13, v12, 1.0                         // 0000002A6294: D627000C 03CA190D
	v_bfe_u32 v13, v12, 16, 1                                  // 0000002A629C: D610000D 0205210C
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002A62A4: BF870001
	v_add3_u32 v12, v12, v13, 0x7fff                           // 0000002A62A8: D655000C 03FE1B0C 00007FFF
	global_store_d16_hi_b16 v[5:6], v12, off                   // 0000002A62B4: DC960000 007C0C05
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 0000002A62BC: 916A017E
	s_mov_b32 s1, 0                                            // 0000002A62C0: BE810080
	s_cbranch_vccnz 3                                          // 0000002A62C4: BFA40003 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x14d4>
	s_cmp_lg_u32 s3, 1                                         // 0000002A62C8: BF078103
	s_mov_b32 s1, -1                                           // 0000002A62CC: BE8100C1
	s_cselect_b32 s6, -1, 0                                    // 0000002A62D0: 980680C1
	v_bfe_u32 v12, v1, 16, 1                                   // 0000002A62D4: D610000C 02052101
	s_and_b32 vcc_lo, exec_lo, s6                              // 0000002A62DC: 8B6A067E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002A62E0: BF870001
	v_add3_u32 v1, v1, v12, 0x7fff                             // 0000002A62E4: D6550001 03FE1901 00007FFF
	s_cbranch_vccz 3                                           // 0000002A62F0: BFA30003 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1500>
	s_mov_b32 s1, 0                                            // 0000002A62F4: BE810080
	global_store_d16_hi_b16 v[5:6], v1, off                    // 0000002A62F8: DC960000 007C0105
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 0000002A6300: 916A017E
	s_cbranch_vccnz 41                                         // 0000002A6304: BFA40029 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x15ac>
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A6308: BF870091
	v_and_b32_e32 v1, 0xffff0000, v1                           // 0000002A630C: 360202FF FFFF0000
	v_mul_f32_e32 v1, s2, v1                                   // 0000002A6314: 10020202
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A6318: BF870091
	v_mul_f32_e32 v12, 0xbfb8aa3b, v1                          // 0000002A631C: 101802FF BFB8AA3B
	v_exp_f32_e32 v12, v12                                     // 0000002A6324: 7E184B0C
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A6328: BF870095
	v_add_f32_e32 v12, 1.0, v12                                // 0000002A632C: 061818F2
	v_div_scale_f32 v13, null, v12, v12, v1                    // 0000002A6330: D6FC7C0D 0406190C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002A6338: BF870291
	v_rcp_f32_e32 v14, v13                                     // 0000002A633C: 7E1C550D
	v_fma_f32 v15, -v13, v14, 1.0                              // 0000002A6340: D613000F 23CA1D0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002A6348: BF8700A1
	v_fmac_f32_e32 v14, v15, v14                               // 0000002A634C: 561C1D0F
	v_div_scale_f32 v15, vcc_lo, v1, v12, v1                   // 0000002A6350: D6FC6A0F 04061901
	v_mul_f32_e32 v16, v15, v14                                // 0000002A6358: 10201D0F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A635C: BF870091
	v_fma_f32 v17, -v13, v16, v15                              // 0000002A6360: D6130011 243E210D
	v_fmac_f32_e32 v16, v17, v14                               // 0000002A6368: 56201D11
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A636C: BF870091
	v_fma_f32 v13, -v13, v16, v15                              // 0000002A6370: D613000D 243E210D
	v_div_fmas_f32 v13, v13, v14, v16                          // 0000002A6378: D637000D 04421D0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A6380: BF870091
	v_div_fixup_f32 v1, v13, v12, v1                           // 0000002A6384: D6270001 0406190D
	v_bfe_u32 v12, v1, 16, 1                                   // 0000002A638C: D610000C 02052101
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002A6394: BF870001
	v_add3_u32 v1, v1, v12, 0x7fff                             // 0000002A6398: D6550001 03FE1901 00007FFF
	global_store_d16_hi_b16 v[5:6], v1, off                    // 0000002A63A4: DC960000 007C0105
	s_lshr_b64 s[6:7], s[10:11], 1                             // 0000002A63AC: 8586810A
	s_mov_b32 s9, -1                                           // 0000002A63B0: BE8900C1
	s_mov_b32 s1, 0                                            // 0000002A63B4: BE810080
	s_cmp_lt_i32 s3, 3                                         // 0000002A63B8: BF048303
	s_mov_b32 s8, 0                                            // 0000002A63BC: BE880080
	s_cbranch_scc1 135                                         // 0000002A63C0: BFA20087 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x17e0>
	s_cmp_gt_i32 s3, 3                                         // 0000002A63C4: BF028303
	s_cbranch_scc0 82                                          // 0000002A63C8: BFA10052 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1714>
	s_cmp_gt_i32 s3, 4                                         // 0000002A63CC: BF028403
	s_cbranch_scc0 40                                          // 0000002A63D0: BFA10028 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1674>
	s_cmp_eq_u32 s3, 5                                         // 0000002A63D4: BF068503
	s_mov_b32 s8, -1                                           // 0000002A63D8: BE8800C1
	s_cbranch_scc0 36                                          // 0000002A63DC: BFA10024 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1670>
	s_load_b64 s[8:9], s[16:17], 0x10                          // 0000002A63E0: F4040208 F8000010
	v_dual_mov_b32 v1, s4 :: v_dual_mov_b32 v12, s5            // 0000002A63E8: CA100004 010C0005
	v_bfe_u32 v14, v2, 16, 1                                   // 0000002A63F0: D610000E 02052102
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000002A63F8: BF8701A1
	v_add3_u32 v14, v2, v14, 0x7fff                            // 0000002A63FC: D655000E 03FE1D02 00007FFF
	s_waitcnt lgkmcnt(0)                                       // 0000002A6408: BF89FC07
	v_cndmask_b32_e64 v1, s8, v1, s0                           // 0000002A640C: D5010001 00020208
	v_cndmask_b32_e64 v12, s9, v12, s0                         // 0000002A6414: D501000C 00021809
	s_lshl_b64 s[8:9], s[6:7], 1                               // 0000002A641C: 84888106
	s_delay_alu instid0(VALU_DEP_2) | instid1(SALU_CYCLE_1)    // 0000002A6420: BF870482
	.long 0xd7006a01                                           // 0000002A6424: D7006A01
	v_cndmask_b32_e32 v0, v1, v8, vcc_lo                       // 0000002A6428: 02001101
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000002A642C: BF8701A1
	v_add_co_ci_u32_e64 v15, null, s9, v12, vcc_lo             // 0000002A6430: D5207C0F 01AA1809
	.long 0xd73c000c                                           // 0000002A6438: D73C000C
	v_cndmask_b32_e32 v1, 1, v9, vcc_lo                        // 0000002A643C: 02021281
	.long 0xd7006a01                                           // 0000002A6440: D7006A01
	v_cndmask_b32_e32 v1, v1, v11, vcc_lo                      // 0000002A6444: 02021701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000002A6448: BF8700B1
	v_add_co_ci_u32_e64 v15, null, v15, v0, vcc_lo             // 0000002A644C: D5207C0F 01AA010F
	s_mov_b32 s8, 0                                            // 0000002A6454: BE880080
	.long 0xd7006a0c                                           // 0000002A6458: D7006A0C
	v_cndmask_b32_e32 v1, v1, v12, vcc_lo                      // 0000002A645C: 02021901
	v_add_co_ci_u32_e64 v13, null, v15, v13, vcc_lo            // 0000002A6460: D5207C0D 01AA1B0F
	global_store_d16_hi_b16 v[12:13], v14, off                 // 0000002A6468: DC960000 007C0E0C
	s_mov_b32 s9, 0                                            // 0000002A6470: BE890080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002A6474: BF870009
	s_and_b32 vcc_lo, exec_lo, s9                              // 0000002A6478: 8B6A097E
	s_cbranch_vccz 36                                          // 0000002A647C: BFA30024 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1710>
	v_mul_f32_e32 v1, 0xbfb8aa3b, v2                           // 0000002A6480: 100204FF BFB8AA3B
	s_lshl_b64 s[12:13], s[10:11], 2                           // 0000002A6488: 848C820A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002A648C: BF870291
	v_exp_f32_e32 v1, v1                                       // 0000002A6490: 7E024B01
	v_add_f32_e32 v1, 1.0, v1                                  // 0000002A6494: 060202F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002A6498: BF870121
	v_div_scale_f32 v12, null, v1, v1, 1.0                     // 0000002A649C: D6FC7C0C 03CA0301
	v_div_scale_f32 v15, vcc_lo, 1.0, v1, 1.0                  // 0000002A64A4: D6FC6A0F 03CA02F2
	v_rcp_f32_e32 v13, v12                                     // 0000002A64AC: 7E1A550C
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A64B0: BF870095
	v_fma_f32 v14, -v12, v13, 1.0                              // 0000002A64B4: D613000E 23CA1B0C
	v_fmac_f32_e32 v13, v14, v13                               // 0000002A64BC: 561A1B0E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A64C0: BF870091
	v_mul_f32_e32 v14, v15, v13                                // 0000002A64C4: 101C1B0F
	v_fma_f32 v16, -v12, v14, v15                              // 0000002A64C8: D6130010 243E1D0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A64D0: BF870091
	v_fmac_f32_e32 v14, v16, v13                               // 0000002A64D4: 561C1B10
	v_fma_f32 v12, -v12, v14, v15                              // 0000002A64D8: D613000C 243E1D0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A64E0: BF870091
	v_div_fmas_f32 v12, v12, v13, v14                          // 0000002A64E4: D637000C 043A1B0C
	v_div_fixup_f32 v1, v12, v1, 1.0                           // 0000002A64EC: D6270001 03CA030C
	.long 0xd7006a0c                                           // 0000002A64F4: D7006A0C
	v_cndmask_b32_e32 v0, v7, v12, vcc_lo                      // 0000002A64F8: 02001907
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002A64FC: BF870001
	v_add_co_ci_u32_e64 v13, null, s13, v8, vcc_lo             // 0000002A6500: D5207C0D 01AA100D
	global_store_b32 v[12:13], v1, off                         // 0000002A6508: DC6A0000 007C010C
	s_mov_b32 s9, 0                                            // 0000002A6510: BE890080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002A6514: BF870009
	s_and_b32 vcc_lo, exec_lo, s9                              // 0000002A6518: 8B6A097E
	s_cbranch_vccz 47                                          // 0000002A651C: BFA3002F <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x17dc>
	v_bfe_u32 v1, v2, 16, 1                                    // 0000002A6520: D6100001 02052102
	s_lshl_b64 s[12:13], s[10:11], 2                           // 0000002A6528: 848C820A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A652C: BF870091
	v_add3_u32 v1, v2, v1, 0x7fff                              // 0000002A6530: D6550001 03FE0302 00007FFF
	v_and_b32_e32 v1, 0xffff0000, v1                           // 0000002A653C: 360202FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A6544: BF870091
	v_mul_f32_e32 v1, s2, v1                                   // 0000002A6548: 10020202
	v_mul_f32_e32 v1, 0xbfb8aa3b, v1                           // 0000002A654C: 100202FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002A6554: BF870291
	v_exp_f32_e32 v1, v1                                       // 0000002A6558: 7E024B01
	v_add_f32_e32 v1, 1.0, v1                                  // 0000002A655C: 060202F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002A6560: BF870121
	v_div_scale_f32 v12, null, v1, v1, 1.0                     // 0000002A6564: D6FC7C0C 03CA0301
	v_div_scale_f32 v15, vcc_lo, 1.0, v1, 1.0                  // 0000002A656C: D6FC6A0F 03CA02F2
	v_rcp_f32_e32 v13, v12                                     // 0000002A6574: 7E1A550C
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A6578: BF870095
	v_fma_f32 v14, -v12, v13, 1.0                              // 0000002A657C: D613000E 23CA1B0C
	v_fmac_f32_e32 v13, v14, v13                               // 0000002A6584: 561A1B0E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A6588: BF870091
	v_mul_f32_e32 v14, v15, v13                                // 0000002A658C: 101C1B0F
	v_fma_f32 v16, -v12, v14, v15                              // 0000002A6590: D6130010 243E1D0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A6598: BF870091
	v_fmac_f32_e32 v14, v16, v13                               // 0000002A659C: 561C1B10
	v_fma_f32 v12, -v12, v14, v15                              // 0000002A65A0: D613000C 243E1D0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A65A8: BF870091
	v_div_fmas_f32 v12, v12, v13, v14                          // 0000002A65AC: D637000C 043A1B0C
	v_div_fixup_f32 v1, v12, v1, 1.0                           // 0000002A65B4: D6270001 03CA030C
	.long 0xd7006a0c                                           // 0000002A65BC: D7006A0C
	v_cndmask_b32_e32 v0, v7, v12, vcc_lo                      // 0000002A65C0: 02001907
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002A65C4: BF870191
	v_add_co_ci_u32_e64 v13, null, s13, v8, vcc_lo             // 0000002A65C8: D5207C0D 01AA100D
	v_add_f32_e32 v1, v1, v1                                   // 0000002A65D0: 06020301
	global_store_b32 v[12:13], v1, off                         // 0000002A65D4: DC6A0000 007C010C
	s_mov_b32 s9, 0                                            // 0000002A65DC: BE890080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002A65E0: BF870009
	s_and_b32 vcc_lo, exec_lo, s9                              // 0000002A65E4: 8B6A097E
	s_cbranch_vccz 60                                          // 0000002A65E8: BFA3003C <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x18dc>
	s_cmp_gt_i32 s3, 1                                         // 0000002A65EC: BF028103
	s_mov_b32 s1, -1                                           // 0000002A65F0: BE8100C1
	s_cbranch_scc0 51                                          // 0000002A65F4: BFA10033 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x18c4>
	v_bfe_u32 v1, v2, 16, 1                                    // 0000002A65F8: D6100001 02052102
	s_lshl_b64 s[12:13], s[10:11], 1                           // 0000002A6600: 848C810A
	s_mov_b32 s1, 0                                            // 0000002A6604: BE810080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A6608: BF870091
	v_add3_u32 v1, v2, v1, 0x7fff                              // 0000002A660C: D6550001 03FE0302 00007FFF
	v_and_b32_e32 v1, 0xffff0000, v1                           // 0000002A6618: 360202FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A6620: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v1                           // 0000002A6624: 100202FF BFB8AA3B
	v_exp_f32_e32 v1, v1                                       // 0000002A662C: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A6630: BF870095
	v_add_f32_e32 v1, 1.0, v1                                  // 0000002A6634: 060202F2
	v_div_scale_f32 v12, null, v1, v1, 1.0                     // 0000002A6638: D6FC7C0C 03CA0301
	v_div_scale_f32 v15, vcc_lo, 1.0, v1, 1.0                  // 0000002A6640: D6FC6A0F 03CA02F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002A6648: BF870292
	v_rcp_f32_e32 v13, v12                                     // 0000002A664C: 7E1A550C
	v_fma_f32 v14, -v12, v13, 1.0                              // 0000002A6650: D613000E 23CA1B0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A6658: BF870091
	v_fmac_f32_e32 v13, v14, v13                               // 0000002A665C: 561A1B0E
	v_mul_f32_e32 v14, v15, v13                                // 0000002A6660: 101C1B0F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A6664: BF870091
	v_fma_f32 v16, -v12, v14, v15                              // 0000002A6668: D6130010 243E1D0C
	v_fmac_f32_e32 v14, v16, v13                               // 0000002A6670: 561C1B10
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A6674: BF870091
	v_fma_f32 v12, -v12, v14, v15                              // 0000002A6678: D613000C 243E1D0C
	v_div_fmas_f32 v12, v12, v13, v14                          // 0000002A6680: D637000C 043A1B0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A6688: BF870091
	v_div_fixup_f32 v1, v12, v1, 1.0                           // 0000002A668C: D6270001 03CA030C
	v_bfe_u32 v12, v1, 16, 1                                   // 0000002A6694: D610000C 02052101
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002A669C: BF8700A1
	v_add3_u32 v1, v1, v12, 0x7fff                             // 0000002A66A0: D6550001 03FE1901 00007FFF
	.long 0xd7006a0c                                           // 0000002A66AC: D7006A0C
	v_cndmask_b32_e32 v0, v5, v12, vcc_lo                      // 0000002A66B0: 02001905
	v_add_co_ci_u32_e64 v13, null, s13, v6, vcc_lo             // 0000002A66B4: D5207C0D 01AA0C0D
	global_store_d16_hi_b16 v[12:13], v1, off                  // 0000002A66BC: DC960000 007C010C
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 0000002A66C4: 916A017E
	s_mov_b32 s1, 0                                            // 0000002A66C8: BE810080
	s_cbranch_vccnz 3                                          // 0000002A66CC: BFA40003 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x18dc>
	s_cmp_lg_u32 s3, 1                                         // 0000002A66D0: BF078103
	s_mov_b32 s1, -1                                           // 0000002A66D4: BE8100C1
	s_cselect_b32 s8, -1, 0                                    // 0000002A66D8: 980880C1
	v_bfe_u32 v1, v2, 16, 1                                    // 0000002A66DC: D6100001 02052102
	s_and_b32 vcc_lo, exec_lo, s8                              // 0000002A66E4: 8B6A087E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002A66E8: BF870001
	v_add3_u32 v1, v2, v1, 0x7fff                              // 0000002A66EC: D6550001 03FE0302 00007FFF
	s_cbranch_vccz 9                                           // 0000002A66F8: BFA30009 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1920>
	s_lshl_b64 s[8:9], s[10:11], 1                             // 0000002A66FC: 8488810A
	s_mov_b32 s1, 0                                            // 0000002A6700: BE810080
	.long 0xd7006a0c                                           // 0000002A6704: D7006A0C
	v_cndmask_b32_e32 v0, v5, v8, vcc_lo                       // 0000002A6708: 02001105
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002A670C: BF870001
	v_add_co_ci_u32_e64 v13, null, s9, v6, vcc_lo              // 0000002A6710: D5207C0D 01AA0C09
	global_store_d16_hi_b16 v[12:13], v1, off                  // 0000002A6718: DC960000 007C010C
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 0000002A6720: 916A017E
	s_cbranch_vccnz 46                                         // 0000002A6724: BFA4002E <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x19e0>
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002A6728: BF8700A1
	v_and_b32_e32 v1, 0xffff0000, v1                           // 0000002A672C: 360202FF FFFF0000
	s_lshl_b64 s[8:9], s[10:11], 1                             // 0000002A6734: 8488810A
	v_mul_f32_e32 v1, s2, v1                                   // 0000002A6738: 10020202
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A673C: BF870091
	v_mul_f32_e32 v2, 0xbfb8aa3b, v1                           // 0000002A6740: 100402FF BFB8AA3B
	v_exp_f32_e32 v2, v2                                       // 0000002A6748: 7E044B02
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A674C: BF870095
	v_add_f32_e32 v2, 1.0, v2                                  // 0000002A6750: 060404F2
	v_div_scale_f32 v12, null, v2, v2, v1                      // 0000002A6754: D6FC7C0C 04060502
	v_div_scale_f32 v15, vcc_lo, v1, v2, v1                    // 0000002A675C: D6FC6A0F 04060501
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002A6764: BF870292
	v_rcp_f32_e32 v13, v12                                     // 0000002A6768: 7E1A550C
	v_fma_f32 v14, -v12, v13, 1.0                              // 0000002A676C: D613000E 23CA1B0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A6774: BF870091
	v_fmac_f32_e32 v13, v14, v13                               // 0000002A6778: 561A1B0E
	v_mul_f32_e32 v14, v15, v13                                // 0000002A677C: 101C1B0F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A6780: BF870091
	v_fma_f32 v16, -v12, v14, v15                              // 0000002A6784: D6130010 243E1D0C
	v_fmac_f32_e32 v14, v16, v13                               // 0000002A678C: 561C1B10
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A6790: BF870091
	v_fma_f32 v12, -v12, v14, v15                              // 0000002A6794: D613000C 243E1D0C
	v_div_fmas_f32 v12, v12, v13, v14                          // 0000002A679C: D637000C 043A1B0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A67A4: BF870091
	v_div_fixup_f32 v1, v12, v2, v1                            // 0000002A67A8: D6270001 0406050C
	v_bfe_u32 v2, v1, 16, 1                                    // 0000002A67B0: D6100002 02052101
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002A67B8: BF8700A1
	v_add3_u32 v12, v1, v2, 0x7fff                             // 0000002A67BC: D655000C 03FE0501 00007FFF
	.long 0xd7006a01                                           // 0000002A67C8: D7006A01
	v_cndmask_b32_e32 v0, v5, v8, vcc_lo                       // 0000002A67CC: 02001105
	v_add_co_ci_u32_e64 v2, null, s9, v6, vcc_lo               // 0000002A67D0: D5207C02 01AA0C09
	global_store_d16_hi_b16 v[1:2], v12, off                   // 0000002A67D8: DC960000 007C0C01
	s_mov_b32 s9, -1                                           // 0000002A67E0: BE8900C1
	s_mov_b32 s1, 0                                            // 0000002A67E4: BE810080
	s_cmp_lt_i32 s3, 3                                         // 0000002A67E8: BF048303
	s_mov_b32 s8, 0                                            // 0000002A67EC: BE880080
	s_cbranch_scc1 138                                         // 0000002A67F0: BFA2008A <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1c1c>
	s_cmp_gt_i32 s3, 3                                         // 0000002A67F4: BF028303
	s_cbranch_scc0 85                                          // 0000002A67F8: BFA10055 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1b50>
	s_cmp_gt_i32 s3, 4                                         // 0000002A67FC: BF028403
	s_cbranch_scc0 43                                          // 0000002A6800: BFA1002B <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1ab0>
	s_cmp_eq_u32 s3, 5                                         // 0000002A6804: BF068503
	s_mov_b32 s8, -1                                           // 0000002A6808: BE8800C1
	s_cbranch_scc0 39                                          // 0000002A680C: BFA10027 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1aac>
	s_load_b64 s[8:9], s[16:17], 0x10                          // 0000002A6810: F4040208 F8000010
	v_dual_mov_b32 v1, s4 :: v_dual_mov_b32 v2, s5             // 0000002A6818: CA100004 01020005
	s_and_b32 s13, s11, 0x7fffffff                             // 0000002A6820: 8B0DFF0B 7FFFFFFF
	s_and_b32 s12, s10, -2                                     // 0000002A6828: 8B0CC20A
	v_bfe_u32 v12, v3, 16, 1                                   // 0000002A682C: D610000C 02052103
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002A6834: BF870001
	v_add3_u32 v12, v3, v12, 0x7fff                            // 0000002A6838: D655000C 03FE1903 00007FFF
	s_waitcnt lgkmcnt(0)                                       // 0000002A6844: BF89FC07
	v_cndmask_b32_e64 v1, s8, v1, s0                           // 0000002A6848: D5010001 00020208
	v_cndmask_b32_e64 v2, s9, v2, s0                           // 0000002A6850: D5010002 00020409
	s_lshl_b64 s[8:9], s[12:13], 1                             // 0000002A6858: 8488810C
	s_delay_alu instid0(VALU_DEP_2) | instid1(SALU_CYCLE_1)    // 0000002A685C: BF870482
	.long 0xd7006a0d                                           // 0000002A6860: D7006A0D
	v_cndmask_b32_e32 v0, v1, v8, vcc_lo                       // 0000002A6864: 02001101
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000002A6868: BF8701A1
	v_add_co_ci_u32_e64 v14, null, s9, v2, vcc_lo              // 0000002A686C: D5207C0E 01AA0409
	.long 0xd73c0001                                           // 0000002A6874: D73C0001
	v_cndmask_b32_e32 v1, 1, v9, vcc_lo                        // 0000002A6878: 02021281
	.long 0xd7006a0d                                           // 0000002A687C: D7006A0D
	v_cndmask_b32_e32 v1, v13, v11, vcc_lo                     // 0000002A6880: 0202170D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000002A6884: BF8700B1
	v_add_co_ci_u32_e64 v14, null, v14, v0, vcc_lo             // 0000002A6888: D5207C0E 01AA010E
	s_mov_b32 s8, 0                                            // 0000002A6890: BE880080
	.long 0xd7006a01                                           // 0000002A6894: D7006A01
	v_cndmask_b32_e32 v1, v13, v1, vcc_lo                      // 0000002A6898: 0202030D
	v_add_co_ci_u32_e64 v2, null, v14, v2, vcc_lo              // 0000002A689C: D5207C02 01AA050E
	global_store_d16_hi_b16 v[1:2], v12, off                   // 0000002A68A4: DC960000 007C0C01
	s_mov_b32 s9, 0                                            // 0000002A68AC: BE890080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002A68B0: BF870009
	s_and_b32 vcc_lo, exec_lo, s9                              // 0000002A68B4: 8B6A097E
	s_cbranch_vccz 36                                          // 0000002A68B8: BFA30024 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1b4c>
	v_mul_f32_e32 v1, 0xbfb8aa3b, v3                           // 0000002A68BC: 100206FF BFB8AA3B
	s_lshl_b64 s[12:13], s[10:11], 3                           // 0000002A68C4: 848C830A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002A68C8: BF870291
	v_exp_f32_e32 v1, v1                                       // 0000002A68CC: 7E024B01
	v_add_f32_e32 v1, 1.0, v1                                  // 0000002A68D0: 060202F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002A68D4: BF870121
	v_div_scale_f32 v2, null, v1, v1, 1.0                      // 0000002A68D8: D6FC7C02 03CA0301
	v_div_scale_f32 v14, vcc_lo, 1.0, v1, 1.0                  // 0000002A68E0: D6FC6A0E 03CA02F2
	v_rcp_f32_e32 v12, v2                                      // 0000002A68E8: 7E185502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A68EC: BF870095
	v_fma_f32 v13, -v2, v12, 1.0                               // 0000002A68F0: D613000D 23CA1902
	v_fmac_f32_e32 v12, v13, v12                               // 0000002A68F8: 5618190D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A68FC: BF870091
	v_mul_f32_e32 v13, v14, v12                                // 0000002A6900: 101A190E
	v_fma_f32 v15, -v2, v13, v14                               // 0000002A6904: D613000F 243A1B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A690C: BF870091
	v_fmac_f32_e32 v13, v15, v12                               // 0000002A6910: 561A190F
	v_fma_f32 v2, -v2, v13, v14                                // 0000002A6914: D6130002 243A1B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A691C: BF870091
	v_div_fmas_f32 v2, v2, v12, v13                            // 0000002A6920: D6370002 04361902
	v_div_fixup_f32 v12, v2, v1, 1.0                           // 0000002A6928: D627000C 03CA0302
	.long 0xd7006a01                                           // 0000002A6930: D7006A01
	v_cndmask_b32_e32 v0, v7, v12, vcc_lo                      // 0000002A6934: 02001907
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002A6938: BF870001
	v_add_co_ci_u32_e64 v2, null, s13, v8, vcc_lo              // 0000002A693C: D5207C02 01AA100D
	global_store_b32 v[1:2], v12, off                          // 0000002A6944: DC6A0000 007C0C01
	s_mov_b32 s9, 0                                            // 0000002A694C: BE890080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002A6950: BF870009
	s_and_b32 vcc_lo, exec_lo, s9                              // 0000002A6954: 8B6A097E
	s_cbranch_vccz 47                                          // 0000002A6958: BFA3002F <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1c18>
	v_bfe_u32 v1, v3, 16, 1                                    // 0000002A695C: D6100001 02052103
	s_lshl_b64 s[12:13], s[10:11], 3                           // 0000002A6964: 848C830A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A6968: BF870091
	v_add3_u32 v1, v3, v1, 0x7fff                              // 0000002A696C: D6550001 03FE0303 00007FFF
	v_and_b32_e32 v1, 0xffff0000, v1                           // 0000002A6978: 360202FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A6980: BF870091
	v_mul_f32_e32 v1, s2, v1                                   // 0000002A6984: 10020202
	v_mul_f32_e32 v1, 0xbfb8aa3b, v1                           // 0000002A6988: 100202FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002A6990: BF870291
	v_exp_f32_e32 v1, v1                                       // 0000002A6994: 7E024B01
	v_add_f32_e32 v1, 1.0, v1                                  // 0000002A6998: 060202F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002A699C: BF870121
	v_div_scale_f32 v2, null, v1, v1, 1.0                      // 0000002A69A0: D6FC7C02 03CA0301
	v_div_scale_f32 v14, vcc_lo, 1.0, v1, 1.0                  // 0000002A69A8: D6FC6A0E 03CA02F2
	v_rcp_f32_e32 v12, v2                                      // 0000002A69B0: 7E185502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A69B4: BF870095
	v_fma_f32 v13, -v2, v12, 1.0                               // 0000002A69B8: D613000D 23CA1902
	v_fmac_f32_e32 v12, v13, v12                               // 0000002A69C0: 5618190D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A69C4: BF870091
	v_mul_f32_e32 v13, v14, v12                                // 0000002A69C8: 101A190E
	v_fma_f32 v15, -v2, v13, v14                               // 0000002A69CC: D613000F 243A1B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A69D4: BF870091
	v_fmac_f32_e32 v13, v15, v12                               // 0000002A69D8: 561A190F
	v_fma_f32 v2, -v2, v13, v14                                // 0000002A69DC: D6130002 243A1B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A69E4: BF870091
	v_div_fmas_f32 v2, v2, v12, v13                            // 0000002A69E8: D6370002 04361902
	v_div_fixup_f32 v1, v2, v1, 1.0                            // 0000002A69F0: D6270001 03CA0302
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002A69F8: BF8700A1
	v_add_f32_e32 v12, v1, v1                                  // 0000002A69FC: 06180301
	.long 0xd7006a01                                           // 0000002A6A00: D7006A01
	v_cndmask_b32_e32 v0, v7, v12, vcc_lo                      // 0000002A6A04: 02001907
	v_add_co_ci_u32_e64 v2, null, s13, v8, vcc_lo              // 0000002A6A08: D5207C02 01AA100D
	global_store_b32 v[1:2], v12, off                          // 0000002A6A10: DC6A0000 007C0C01
	s_mov_b32 s9, 0                                            // 0000002A6A18: BE890080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002A6A1C: BF870009
	s_and_b32 vcc_lo, exec_lo, s9                              // 0000002A6A20: 8B6A097E
	s_cbranch_vccz 60                                          // 0000002A6A24: BFA3003C <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1d18>
	s_cmp_gt_i32 s3, 1                                         // 0000002A6A28: BF028103
	s_mov_b32 s1, -1                                           // 0000002A6A2C: BE8100C1
	s_cbranch_scc0 51                                          // 0000002A6A30: BFA10033 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1d00>
	v_bfe_u32 v1, v3, 16, 1                                    // 0000002A6A34: D6100001 02052103
	s_lshl_b64 s[12:13], s[10:11], 2                           // 0000002A6A3C: 848C820A
	s_mov_b32 s1, 0                                            // 0000002A6A40: BE810080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A6A44: BF870091
	v_add3_u32 v1, v3, v1, 0x7fff                              // 0000002A6A48: D6550001 03FE0303 00007FFF
	v_and_b32_e32 v1, 0xffff0000, v1                           // 0000002A6A54: 360202FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A6A5C: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v1                           // 0000002A6A60: 100202FF BFB8AA3B
	v_exp_f32_e32 v1, v1                                       // 0000002A6A68: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A6A6C: BF870095
	v_add_f32_e32 v1, 1.0, v1                                  // 0000002A6A70: 060202F2
	v_div_scale_f32 v2, null, v1, v1, 1.0                      // 0000002A6A74: D6FC7C02 03CA0301
	v_div_scale_f32 v14, vcc_lo, 1.0, v1, 1.0                  // 0000002A6A7C: D6FC6A0E 03CA02F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002A6A84: BF870292
	v_rcp_f32_e32 v12, v2                                      // 0000002A6A88: 7E185502
	v_fma_f32 v13, -v2, v12, 1.0                               // 0000002A6A8C: D613000D 23CA1902
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A6A94: BF870091
	v_fmac_f32_e32 v12, v13, v12                               // 0000002A6A98: 5618190D
	v_mul_f32_e32 v13, v14, v12                                // 0000002A6A9C: 101A190E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A6AA0: BF870091
	v_fma_f32 v15, -v2, v13, v14                               // 0000002A6AA4: D613000F 243A1B02
	v_fmac_f32_e32 v13, v15, v12                               // 0000002A6AAC: 561A190F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A6AB0: BF870091
	v_fma_f32 v2, -v2, v13, v14                                // 0000002A6AB4: D6130002 243A1B02
	v_div_fmas_f32 v2, v2, v12, v13                            // 0000002A6ABC: D6370002 04361902
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A6AC4: BF870091
	v_div_fixup_f32 v1, v2, v1, 1.0                            // 0000002A6AC8: D6270001 03CA0302
	v_bfe_u32 v2, v1, 16, 1                                    // 0000002A6AD0: D6100002 02052101
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002A6AD8: BF8700A1
	v_add3_u32 v12, v1, v2, 0x7fff                             // 0000002A6ADC: D655000C 03FE0501 00007FFF
	.long 0xd7006a01                                           // 0000002A6AE8: D7006A01
	v_cndmask_b32_e32 v0, v5, v12, vcc_lo                      // 0000002A6AEC: 02001905
	v_add_co_ci_u32_e64 v2, null, s13, v6, vcc_lo              // 0000002A6AF0: D5207C02 01AA0C0D
	global_store_d16_hi_b16 v[1:2], v12, off                   // 0000002A6AF8: DC960000 007C0C01
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 0000002A6B00: 916A017E
	s_mov_b32 s1, 0                                            // 0000002A6B04: BE810080
	s_cbranch_vccnz 3                                          // 0000002A6B08: BFA40003 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1d18>
	s_cmp_lg_u32 s3, 1                                         // 0000002A6B0C: BF078103
	s_mov_b32 s1, -1                                           // 0000002A6B10: BE8100C1
	s_cselect_b32 s8, -1, 0                                    // 0000002A6B14: 980880C1
	v_bfe_u32 v1, v3, 16, 1                                    // 0000002A6B18: D6100001 02052103
	s_and_b32 vcc_lo, exec_lo, s8                              // 0000002A6B20: 8B6A087E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002A6B24: BF870001
	v_add3_u32 v1, v3, v1, 0x7fff                              // 0000002A6B28: D6550001 03FE0303 00007FFF
	s_cbranch_vccz 9                                           // 0000002A6B34: BFA30009 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1d5c>
	s_lshl_b64 s[8:9], s[10:11], 2                             // 0000002A6B38: 8488820A
	s_mov_b32 s1, 0                                            // 0000002A6B3C: BE810080
	.long 0xd7006a02                                           // 0000002A6B40: D7006A02
	v_cndmask_b32_e32 v0, v5, v8, vcc_lo                       // 0000002A6B44: 02001105
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002A6B48: BF870001
	v_add_co_ci_u32_e64 v3, null, s9, v6, vcc_lo               // 0000002A6B4C: D5207C03 01AA0C09
	global_store_d16_hi_b16 v[2:3], v1, off                    // 0000002A6B54: DC960000 007C0102
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 0000002A6B5C: 916A017E
	s_cbranch_vccnz 46                                         // 0000002A6B60: BFA4002E <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1e1c>
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002A6B64: BF8700A1
	v_and_b32_e32 v1, 0xffff0000, v1                           // 0000002A6B68: 360202FF FFFF0000
	s_lshl_b64 s[8:9], s[10:11], 2                             // 0000002A6B70: 8488820A
	v_mul_f32_e32 v1, s2, v1                                   // 0000002A6B74: 10020202
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A6B78: BF870091
	v_mul_f32_e32 v2, 0xbfb8aa3b, v1                           // 0000002A6B7C: 100402FF BFB8AA3B
	v_exp_f32_e32 v2, v2                                       // 0000002A6B84: 7E044B02
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A6B88: BF870095
	v_add_f32_e32 v2, 1.0, v2                                  // 0000002A6B8C: 060404F2
	v_div_scale_f32 v3, null, v2, v2, v1                       // 0000002A6B90: D6FC7C03 04060502
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002A6B98: BF870291
	v_rcp_f32_e32 v12, v3                                      // 0000002A6B9C: 7E185503
	v_fma_f32 v13, -v3, v12, 1.0                               // 0000002A6BA0: D613000D 23CA1903
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002A6BA8: BF8700A1
	v_fmac_f32_e32 v12, v13, v12                               // 0000002A6BAC: 5618190D
	v_div_scale_f32 v14, vcc_lo, v1, v2, v1                    // 0000002A6BB0: D6FC6A0E 04060501
	v_mul_f32_e32 v13, v14, v12                                // 0000002A6BB8: 101A190E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A6BBC: BF870091
	v_fma_f32 v15, -v3, v13, v14                               // 0000002A6BC0: D613000F 243A1B03
	v_fmac_f32_e32 v13, v15, v12                               // 0000002A6BC8: 561A190F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A6BCC: BF870091
	v_fma_f32 v3, -v3, v13, v14                                // 0000002A6BD0: D6130003 243A1B03
	v_div_fmas_f32 v3, v3, v12, v13                            // 0000002A6BD8: D6370003 04361903
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A6BE0: BF870091
	v_div_fixup_f32 v1, v3, v2, v1                             // 0000002A6BE4: D6270001 04060503
	v_bfe_u32 v2, v1, 16, 1                                    // 0000002A6BEC: D6100002 02052101
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002A6BF4: BF8700A1
	v_add3_u32 v3, v1, v2, 0x7fff                              // 0000002A6BF8: D6550003 03FE0501 00007FFF
	.long 0xd7006a01                                           // 0000002A6C04: D7006A01
	v_cndmask_b32_e32 v0, v5, v8, vcc_lo                       // 0000002A6C08: 02001105
	v_add_co_ci_u32_e64 v2, null, s9, v6, vcc_lo               // 0000002A6C0C: D5207C02 01AA0C09
	global_store_d16_hi_b16 v[1:2], v3, off                    // 0000002A6C14: DC960000 007C0301
	s_mov_b32 s9, -1                                           // 0000002A6C1C: BE8900C1
	s_mov_b32 s1, 0                                            // 0000002A6C20: BE810080
	s_cmp_lt_i32 s3, 3                                         // 0000002A6C24: BF048303
	s_mov_b32 s8, 0                                            // 0000002A6C28: BE880080
	s_cbranch_scc1 134                                         // 0000002A6C2C: BFA20086 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x2048>
	s_cmp_gt_i32 s3, 3                                         // 0000002A6C30: BF028303
	s_cbranch_scc0 43                                          // 0000002A6C34: BFA1002B <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1ee4>
	s_cmp_gt_i32 s3, 4                                         // 0000002A6C38: BF028403
	s_cbranch_scc0 43                                          // 0000002A6C3C: BFA1002B <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1eec>
	s_cmp_eq_u32 s3, 5                                         // 0000002A6C40: BF068503
	s_mov_b32 s8, -1                                           // 0000002A6C44: BE8800C1
	s_cbranch_scc0 36                                          // 0000002A6C48: BFA10024 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1edc>
	s_load_b64 s[8:9], s[16:17], 0x10                          // 0000002A6C4C: F4040208 F8000010
	v_mov_b32_e32 v1, s5                                       // 0000002A6C54: 7E020205
	v_mov_b32_e32 v3, s4                                       // 0000002A6C58: 7E060204
	.long 0xd73c0009                                           // 0000002A6C5C: D73C0009
	v_cndmask_b32_e32 v1, 1, v9, vcc_lo                        // 0000002A6C60: 02021281
	s_waitcnt lgkmcnt(0)                                       // 0000002A6C64: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002A6C68: BF870193
	v_cndmask_b32_e64 v2, s9, v1, s0                           // 0000002A6C6C: D5010002 00020209
	v_cndmask_b32_e64 v1, s8, v3, s0                           // 0000002A6C74: D5010001 00020608
	s_mov_b32 s8, 0                                            // 0000002A6C7C: BE880080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A6C80: BF870091
	v_mad_u64_u32 v[1:2], null, s6, 6, v[1:2]                  // 0000002A6C84: D6FE7C01 04050C06
	v_mad_u64_u32 v[2:3], null, s7, 6, v[2:3]                  // 0000002A6C8C: D6FE7C02 04090C07
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002A6C94: BF8700A2
	.long 0xd7006a01                                           // 0000002A6C98: D7006A01
	v_cndmask_b32_e32 v1, v1, v11, vcc_lo                      // 0000002A6C9C: 02021701
	v_bfe_u32 v3, v4, 16, 1                                    // 0000002A6CA0: D6100003 02052104
	v_add3_u32 v3, v4, v3, 0x7fff                              // 0000002A6CA8: D6550003 03FE0704 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002A6CB4: BF870214
	v_add_co_ci_u32_e64 v2, null, v2, v0, vcc_lo               // 0000002A6CB8: D5207C02 01AA0102
	.long 0xd7006a00                                           // 0000002A6CC0: D7006A00
	v_cndmask_b32_e32 v1, v1, v9, vcc_lo                       // 0000002A6CC4: 02021301
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002A6CC8: BF870001
	v_add_co_ci_u32_e64 v1, null, v2, v10, vcc_lo              // 0000002A6CCC: D5207C01 01AA1502
	global_store_d16_hi_b16 v[0:1], v3, off                    // 0000002A6CD4: DC960000 007C0300
	s_mov_b32 s0, 0                                            // 0000002A6CDC: BE800080
	s_branch 3                                                 // 0000002A6CE0: BFA00003 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1ef0>
	s_cbranch_execnz 41                                        // 0000002A6CE4: BFA60029 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1f8c>
	s_branch 86                                                // 0000002A6CE8: BFA00056 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x2044>
	s_mov_b32 s0, -1                                           // 0000002A6CEC: BE8000C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002A6CF0: BF870009
	s_and_b32 vcc_lo, exec_lo, s0                              // 0000002A6CF4: 8B6A007E
	s_cbranch_vccz 35                                          // 0000002A6CF8: BFA30023 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1f88>
	v_mul_f32_e32 v0, 0xbfb8aa3b, v4                           // 0000002A6CFC: 100008FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002A6D04: BF870291
	v_exp_f32_e32 v0, v0                                       // 0000002A6D08: 7E004B00
	v_add_f32_e32 v3, 1.0, v0                                  // 0000002A6D0C: 060600F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002A6D10: BF870121
	v_div_scale_f32 v2, null, v3, v3, 1.0                      // 0000002A6D14: D6FC7C02 03CA0703
	v_div_scale_f32 v10, vcc_lo, 1.0, v3, 1.0                  // 0000002A6D1C: D6FC6A0A 03CA06F2
	v_rcp_f32_e32 v9, v2                                       // 0000002A6D24: 7E125502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A6D28: BF870095
	v_fma_f32 v0, -v2, v9, 1.0                                 // 0000002A6D2C: D6130000 23CA1302
	v_fmac_f32_e32 v9, v0, v9                                  // 0000002A6D34: 56121300
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A6D38: BF870091
	v_mul_f32_e32 v11, v10, v9                                 // 0000002A6D3C: 1016130A
	v_fma_f32 v0, -v2, v11, v10                                // 0000002A6D40: D6130000 242A1702
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002A6D48: BF870121
	v_fmac_f32_e32 v11, v0, v9                                 // 0000002A6D4C: 56161300
	v_mad_u64_u32 v[0:1], null, s10, 12, v[7:8]                // 0000002A6D50: D6FE7C00 041D180A
	v_fma_f32 v2, -v2, v11, v10                                // 0000002A6D58: D6130002 242A1702
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002A6D60: BF870191
	v_div_fmas_f32 v9, v2, v9, v11                             // 0000002A6D64: D6370009 042E1302
	v_mad_u64_u32 v[1:2], null, s11, 12, v[1:2]                // 0000002A6D6C: D6FE7C01 0405180B
	s_delay_alu instid0(VALU_DEP_2)                            // 0000002A6D74: BF870002
	v_div_fixup_f32 v2, v9, v3, 1.0                            // 0000002A6D78: D6270002 03CA0709
	global_store_b32 v[0:1], v2, off                           // 0000002A6D80: DC6A0000 007C0200
	s_branch 46                                                // 0000002A6D88: BFA0002E <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x2044>
	v_bfe_u32 v0, v4, 16, 1                                    // 0000002A6D8C: D6100000 02052104
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A6D94: BF870091
	v_add3_u32 v0, v4, v0, 0x7fff                              // 0000002A6D98: D6550000 03FE0104 00007FFF
	v_and_b32_e32 v0, 0xffff0000, v0                           // 0000002A6DA4: 360000FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A6DAC: BF870091
	v_mul_f32_e32 v0, s2, v0                                   // 0000002A6DB0: 10000002
	v_mul_f32_e32 v0, 0xbfb8aa3b, v0                           // 0000002A6DB4: 100000FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002A6DBC: BF870291
	v_exp_f32_e32 v0, v0                                       // 0000002A6DC0: 7E004B00
	v_add_f32_e32 v2, 1.0, v0                                  // 0000002A6DC4: 060400F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A6DC8: BF870091
	v_div_scale_f32 v0, null, v2, v2, 1.0                      // 0000002A6DCC: D6FC7C00 03CA0502
	v_rcp_f32_e32 v3, v0                                       // 0000002A6DD4: 7E065500
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A6DD8: BF870095
	v_fma_f32 v1, -v0, v3, 1.0                                 // 0000002A6DDC: D6130001 23CA0700
	v_fmac_f32_e32 v3, v1, v3                                  // 0000002A6DE4: 56060701
	v_div_scale_f32 v1, vcc_lo, 1.0, v2, 1.0                   // 0000002A6DE8: D6FC6A01 03CA04F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A6DF0: BF870091
	v_mul_f32_e32 v9, v1, v3                                   // 0000002A6DF4: 10120701
	v_fma_f32 v10, -v0, v9, v1                                 // 0000002A6DF8: D613000A 24061300
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A6E00: BF870091
	v_fmac_f32_e32 v9, v10, v3                                 // 0000002A6E04: 5612070A
	v_fma_f32 v10, -v0, v9, v1                                 // 0000002A6E08: D613000A 24061300
	v_mad_u64_u32 v[0:1], null, s10, 12, v[7:8]                // 0000002A6E10: D6FE7C00 041D180A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A6E18: BF870092
	v_div_fmas_f32 v3, v10, v3, v9                             // 0000002A6E1C: D6370003 0426070A
	v_div_fixup_f32 v3, v3, v2, 1.0                            // 0000002A6E24: D6270003 03CA0503
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002A6E2C: BF870113
	v_mad_u64_u32 v[1:2], null, s11, 12, v[1:2]                // 0000002A6E30: D6FE7C01 0405180B
	v_add_f32_e32 v2, v3, v3                                   // 0000002A6E38: 06040703
	global_store_b32 v[0:1], v2, off                           // 0000002A6E3C: DC6A0000 007C0200
	s_mov_b32 s9, 0                                            // 0000002A6E44: BE890080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002A6E48: BF870009
	s_and_b32 vcc_lo, exec_lo, s9                              // 0000002A6E4C: 8B6A097E
	s_cbranch_vccz 58                                          // 0000002A6E50: BFA3003A <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x213c>
	s_cmp_gt_i32 s3, 1                                         // 0000002A6E54: BF028103
	s_mov_b32 s0, -1                                           // 0000002A6E58: BE8000C1
	s_cbranch_scc0 50                                          // 0000002A6E5C: BFA10032 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x2128>
	v_bfe_u32 v0, v4, 16, 1                                    // 0000002A6E60: D6100000 02052104
	s_mov_b32 s0, 0                                            // 0000002A6E68: BE800080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A6E6C: BF870091
	v_add3_u32 v0, v4, v0, 0x7fff                              // 0000002A6E70: D6550000 03FE0104 00007FFF
	v_and_b32_e32 v0, 0xffff0000, v0                           // 0000002A6E7C: 360000FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A6E84: BF870091
	v_mul_f32_e32 v0, 0xbfb8aa3b, v0                           // 0000002A6E88: 100000FF BFB8AA3B
	v_exp_f32_e32 v0, v0                                       // 0000002A6E90: 7E004B00
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A6E94: BF870095
	v_add_f32_e32 v2, 1.0, v0                                  // 0000002A6E98: 060400F2
	v_div_scale_f32 v0, null, v2, v2, 1.0                      // 0000002A6E9C: D6FC7C00 03CA0502
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002A6EA4: BF870291
	v_rcp_f32_e32 v1, v0                                       // 0000002A6EA8: 7E025500
	v_fma_f32 v3, -v0, v1, 1.0                                 // 0000002A6EAC: D6130003 23CA0300
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002A6EB4: BF8700A1
	v_fmac_f32_e32 v1, v3, v1                                  // 0000002A6EB8: 56020303
	v_div_scale_f32 v3, vcc_lo, 1.0, v2, 1.0                   // 0000002A6EBC: D6FC6A03 03CA04F2
	v_mul_f32_e32 v7, v3, v1                                   // 0000002A6EC4: 100E0303
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A6EC8: BF870091
	v_fma_f32 v8, -v0, v7, v3                                  // 0000002A6ECC: D6130008 240E0F00
	v_fmac_f32_e32 v7, v8, v1                                  // 0000002A6ED4: 560E0308
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A6ED8: BF870091
	v_fma_f32 v0, -v0, v7, v3                                  // 0000002A6EDC: D6130000 240E0F00
	v_div_fmas_f32 v3, v0, v1, v7                              // 0000002A6EE4: D6370003 041E0300
	v_mad_u64_u32 v[0:1], null, s10, 6, v[5:6]                 // 0000002A6EEC: D6FE7C00 04150C0A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002A6EF4: BF870112
	v_div_fixup_f32 v3, v3, v2, 1.0                            // 0000002A6EF8: D6270003 03CA0503
	v_mad_u64_u32 v[1:2], null, s11, 6, v[1:2]                 // 0000002A6F00: D6FE7C01 04050C0B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A6F08: BF870092
	v_bfe_u32 v7, v3, 16, 1                                    // 0000002A6F0C: D6100007 02052103
	v_add3_u32 v2, v3, v7, 0x7fff                              // 0000002A6F14: D6550002 03FE0F03 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off                    // 0000002A6F20: DC960000 007C0200
	s_and_not1_b32 vcc_lo, exec_lo, s0                         // 0000002A6F28: 916A007E
	s_cbranch_vccnz 3                                          // 0000002A6F2C: BFA40003 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x213c>
	s_cmp_lg_u32 s3, 1                                         // 0000002A6F30: BF078103
	s_mov_b32 s1, -1                                           // 0000002A6F34: BE8100C1
	s_cselect_b32 s8, -1, 0                                    // 0000002A6F38: 980880C1
	v_bfe_u32 v0, v4, 16, 1                                    // 0000002A6F3C: D6100000 02052104
	s_and_b32 vcc_lo, exec_lo, s8                              // 0000002A6F44: 8B6A087E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002A6F48: BF870001
	v_add3_u32 v0, v4, v0, 0x7fff                              // 0000002A6F4C: D6550000 03FE0104 00007FFF
	s_cbranch_vccz 7                                           // 0000002A6F58: BFA30007 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x2178>
	v_mad_u64_u32 v[1:2], null, s10, 6, v[5:6]                 // 0000002A6F5C: D6FE7C01 04150C0A
	s_mov_b32 s1, 0                                            // 0000002A6F64: BE810080
	v_mad_u64_u32 v[2:3], null, s11, 6, v[2:3]                 // 0000002A6F68: D6FE7C02 04090C0B
	global_store_d16_hi_b16 v[1:2], v0, off                    // 0000002A6F70: DC960000 007C0001
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 0000002A6F78: 916A017E
	s_cbranch_vccnz 45                                         // 0000002A6F7C: BFA4002D <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x2234>
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A6F80: BF870091
	v_and_b32_e32 v0, 0xffff0000, v0                           // 0000002A6F84: 360000FF FFFF0000
	v_mul_f32_e32 v2, s2, v0                                   // 0000002A6F8C: 10040002
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A6F90: BF870091
	v_mul_f32_e32 v0, 0xbfb8aa3b, v2                           // 0000002A6F94: 100004FF BFB8AA3B
	v_exp_f32_e32 v0, v0                                       // 0000002A6F9C: 7E004B00
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A6FA0: BF870095
	v_add_f32_e32 v3, 1.0, v0                                  // 0000002A6FA4: 060600F2
	v_div_scale_f32 v0, null, v3, v3, v2                       // 0000002A6FA8: D6FC7C00 040A0703
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002A6FB0: BF870291
	v_rcp_f32_e32 v1, v0                                       // 0000002A6FB4: 7E025500
	v_fma_f32 v4, -v0, v1, 1.0                                 // 0000002A6FB8: D6130004 23CA0300
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002A6FC0: BF8700A1
	v_fmac_f32_e32 v1, v4, v1                                  // 0000002A6FC4: 56020304
	v_div_scale_f32 v4, vcc_lo, v2, v3, v2                     // 0000002A6FC8: D6FC6A04 040A0702
	v_mul_f32_e32 v7, v4, v1                                   // 0000002A6FD0: 100E0304
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A6FD4: BF870091
	v_fma_f32 v8, -v0, v7, v4                                  // 0000002A6FD8: D6130008 24120F00
	v_fmac_f32_e32 v7, v8, v1                                  // 0000002A6FE0: 560E0308
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A6FE4: BF870091
	v_fma_f32 v0, -v0, v7, v4                                  // 0000002A6FE8: D6130000 24120F00
	v_div_fmas_f32 v4, v0, v1, v7                              // 0000002A6FF0: D6370004 041E0300
	v_mad_u64_u32 v[0:1], null, s10, 6, v[5:6]                 // 0000002A6FF8: D6FE7C00 04150C0A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002A7000: BF870112
	v_div_fixup_f32 v3, v4, v3, v2                             // 0000002A7004: D6270003 040A0704
	v_mad_u64_u32 v[1:2], null, s11, 6, v[1:2]                 // 0000002A700C: D6FE7C01 04050C0B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A7014: BF870092
	v_bfe_u32 v4, v3, 16, 1                                    // 0000002A7018: D6100004 02052103
	v_add3_u32 v2, v3, v4, 0x7fff                              // 0000002A7020: D6550002 03FE0903 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off                    // 0000002A702C: DC960000 007C0200
	s_nop 0                                                    // 0000002A7034: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 0000002A7038: BFB60003
	s_endpgm                                                   // 0000002A703C: BFB00000
		...

