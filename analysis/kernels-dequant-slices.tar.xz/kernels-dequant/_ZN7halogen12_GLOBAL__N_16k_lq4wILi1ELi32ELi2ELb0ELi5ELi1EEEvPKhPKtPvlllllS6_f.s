00000000008b2c00 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi2ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi2ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 0000008B2C00: F4100100 F8000000
	s_ashr_i32 s3, s2, 31                                      // 0000008B2C08: 86039F02
	v_lshrrev_b32_e32 v2, 2, v0                                // 0000008B2C0C: 32040082
	s_lshl_b64 s[20:21], s[2:3], 2                             // 0000008B2C10: 84948202
	v_and_b32_e32 v1, 15, v0                                   // 0000008B2C14: 3602008F
	v_lshrrev_b32_e32 v21, 6, v0                               // 0000008B2C18: 322A0086
	v_bfe_u32 v22, v0, 5, 1                                    // 0000008B2C1C: D6100016 02050B00
	v_and_b32_e32 v2, 60, v2                                   // 0000008B2C24: 360404BC
	v_and_b32_e32 v23, 31, v0                                  // 0000008B2C28: 362E009F
	v_lshlrev_b32_e32 v1, 2, v1                                // 0000008B2C2C: 30020282
	.long 0x7f0a3880                                           // 0000008B2C30: 7F0A3880
	s_waitcnt lgkmcnt(0)                                       // 0000008B2C34: BF89FC07
	s_clause 0x1                                               // 0000008B2C38: BF850001
	global_load_b32 v3, v1, s[4:5]                             // 0000008B2C3C: DC520000 03040001
	global_load_b32 v4, v2, s[4:5]                             // 0000008B2C44: DC520000 04040002
	s_add_u32 s2, s4, s16                                      // 0000008B2C4C: 80021004
	s_addc_u32 s3, s5, s17                                     // 0000008B2C50: 82031105
	s_ashr_i32 s16, s11, 31                                    // 0000008B2C54: 86109F0B
	v_mov_b32_e32 v2, s21                                      // 0000008B2C58: 7E040215
	s_lshr_b32 s16, s16, 27                                    // 0000008B2C5C: 85109B10
	v_or_b32_e32 v1, s20, v21                                  // 0000008B2C60: 38022A14
	s_add_u32 s16, s10, s16                                    // 0000008B2C64: 8010100A
	s_addc_u32 s17, s11, 0                                     // 0000008B2C68: 8211800B
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008B2C6C: BF870099
	s_lshr_b64 s[16:17], s[16:17], 5                           // 0000008B2C70: 85908510
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[1:2]                  // 0000008B2C74: 7CA8020C
	s_add_i32 s17, s16, 1                                      // 0000008B2C78: 81118110
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000008B2C7C: BF870499
	s_lshr_b32 s22, s17, 31                                    // 0000008B2C80: 85169F11
	s_add_i32 s17, s17, s22                                    // 0000008B2C84: 81111611
	v_cndmask_b32_e32 v9, 0, v1, vcc_lo                        // 0000008B2C88: 02120280
	s_ashr_i32 s17, s17, 1                                     // 0000008B2C8C: 86118111
	v_cndmask_b32_e64 v10, 0, s21, vcc_lo                      // 0000008B2C90: D501000A 01A82A80
	.long 0xd72c0002                                           // 0000008B2C98: D72C0002
	v_cndmask_b32_e32 v1, s17, v22, vcc_lo                     // 0000008B2C9C: 02022C11
	s_cmpk_lt_i32 s16, 0x201                                   // 0000008B2CA0: B3900201
	.long 0xd72c0007                                           // 0000008B2CA4: D72C0007
	v_cndmask_b32_e32 v1, s19, v9, vcc_lo                      // 0000008B2CA8: 02021213
	v_mad_u64_u32 v[17:18], null, s18, v9, s[2:3]              // 0000008B2CAC: D6FE7C11 000A1212
	s_cselect_b32 s2, -1, 0                                    // 0000008B2CB4: 980280C1
	s_cmpk_gt_i32 s16, 0x200                                   // 0000008B2CB8: B2900200
	v_lshlrev_b32_e32 v1, 2, v0                                // 0000008B2CBC: 30020082
	v_add_nc_u32_e32 v11, s17, v2                              // 0000008B2CC0: 4A160411
	v_add_nc_u32_e32 v24, v2, v23                              // 0000008B2CC4: 4A302F02
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000008B2CC8: BF8704A2
	v_min_i32_e32 v25, s16, v11                                // 0000008B2CCC: 22321610
	s_cselect_b32 s16, -1, 0                                   // 0000008B2CD0: 981080C1
	s_and_b32 vcc_lo, exec_lo, s16                             // 0000008B2CD4: 8B6A107E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 0000008B2CD8: BF870151
	.long 0xd4410003                                           // 0000008B2CDC: D4410003
	v_cndmask_b32_e32 v1, v24, v25, vcc_lo                     // 0000008B2CE0: 02023318
	s_waitcnt vmcnt(1)                                         // 0000008B2CE4: BF8907F7
	v_bfe_u32 v6, v3, 16, 1                                    // 0000008B2CE8: D6100006 02052103
	s_waitcnt vmcnt(0)                                         // 0000008B2CF0: BF8903F7
	v_bfe_u32 v8, v4, 16, 1                                    // 0000008B2CF4: D6100008 02052104
	v_add3_u32 v3, v3, v6, 0x7fff                              // 0000008B2CFC: D6550003 03FE0D03 00007FFF
	.long 0xd72c0006                                           // 0000008B2D08: D72C0006
	v_cndmask_b32_e32 v1, s18, v10, vcc_lo                     // 0000008B2D0C: 02021412
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008B2D10: BF870193
	v_add3_u32 v4, v4, v8, 0x7fff                              // 0000008B2D14: D6550004 03FE1104 00007FFF
	.long 0x7e0a3983                                           // 0000008B2D20: 7E0A3983
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000008B2D24: BF870113
	v_add3_u32 v26, v7, v18, v6                                // 0000008B2D28: D655001A 041A2507
	v_and_or_b32 v2, 0xffff0000, v4, v5                        // 0000008B2D30: D6570002 041608FF FFFF0000
	ds_store_b32 v1, v2                                        // 0000008B2D3C: D8340000 00000201
	s_waitcnt lgkmcnt(0)                                       // 0000008B2D44: BF89FC07
	s_barrier                                                  // 0000008B2D48: BFBD0000
	buffer_gl0_inv                                             // 0000008B2D4C: E0AC0000 00000000
	s_cbranch_vccnz 154                                        // 0000008B2D54: BFA4009A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi2ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x3c0>
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v1, 0               // 0000008B2D58: CA100080 02000080
	s_and_saveexec_b32 s17, s3                                 // 0000008B2D60: BE912003
	s_cbranch_execz 11                                         // 0000008B2D64: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi2ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x194>
	v_lshlrev_b32_e32 v1, 1, v24                               // 0000008B2D68: 30023081
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008B2D6C: BF8700A1
	v_ashrrev_i32_e32 v4, 31, v1                               // 0000008B2D70: 3408029F
	.long 0xd7006a03                                           // 0000008B2D74: D7006A03
	v_cndmask_b32_e32 v1, v17, v1, vcc_lo                      // 0000008B2D78: 02020311
	v_add_co_ci_u32_e64 v4, null, v26, v4, vcc_lo              // 0000008B2D7C: D5207C04 01AA091A
	global_load_d16_b16 v1, v[3:4], off                        // 0000008B2D84: DC820000 017C0003
	s_waitcnt vmcnt(0)                                         // 0000008B2D8C: BF8903F7
	v_cvt_f32_f16_e32 v1, v1                                   // 0000008B2D90: 7E021701
	s_or_b32 exec_lo, exec_lo, s17                             // 0000008B2D94: 8C7E117E
	v_add_nc_u32_e32 v3, 32, v24                               // 0000008B2D98: 4A0630A0
	s_mov_b32 s3, exec_lo                                      // 0000008B2D9C: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008B2DA0: BF870001
	.long 0xd4c1007e                                           // 0000008B2DA4: D4C1007E
	v_cndmask_b32_e32 v1, v3, v25, vcc_lo                      // 0000008B2DA8: 02023303
	s_cbranch_execz 11                                         // 0000008B2DAC: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi2ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x1dc>
	v_lshlrev_b32_e32 v2, 1, v3                                // 0000008B2DB0: 30040681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008B2DB4: BF8700A1
	v_ashrrev_i32_e32 v3, 31, v2                               // 0000008B2DB8: 3406049F
	.long 0xd7006a02                                           // 0000008B2DBC: D7006A02
	v_cndmask_b32_e32 v1, v17, v2, vcc_lo                      // 0000008B2DC0: 02020511
	v_add_co_ci_u32_e64 v3, null, v26, v3, vcc_lo              // 0000008B2DC4: D5207C03 01AA071A
	global_load_d16_b16 v2, v[2:3], off                        // 0000008B2DCC: DC820000 027C0002
	s_waitcnt vmcnt(0)                                         // 0000008B2DD4: BF8903F7
	v_cvt_f32_f16_e32 v2, v2                                   // 0000008B2DD8: 7E041702
	s_or_b32 exec_lo, exec_lo, s3                              // 0000008B2DDC: 8C7E037E
	v_dual_mov_b32 v4, 0 :: v_dual_add_nc_u32 v5, 64, v24      // 0000008B2DE0: CA200080 040430C0
	v_mov_b32_e32 v3, 0                                        // 0000008B2DE8: 7E060280
	s_mov_b32 s3, exec_lo                                      // 0000008B2DEC: BE83007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000008B2DF0: BF870002
	.long 0xd4c1007e                                           // 0000008B2DF4: D4C1007E
	v_cndmask_b32_e32 v1, v5, v25, vcc_lo                      // 0000008B2DF8: 02023305
	s_cbranch_execz 11                                         // 0000008B2DFC: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi2ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x22c>
	v_lshlrev_b32_e32 v3, 1, v5                                // 0000008B2E00: 30060A81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008B2E04: BF8700A1
	v_ashrrev_i32_e32 v6, 31, v3                               // 0000008B2E08: 340C069F
	.long 0xd7006a05                                           // 0000008B2E0C: D7006A05
	v_cndmask_b32_e32 v1, v17, v3, vcc_lo                      // 0000008B2E10: 02020711
	v_add_co_ci_u32_e64 v6, null, v26, v6, vcc_lo              // 0000008B2E14: D5207C06 01AA0D1A
	global_load_d16_b16 v3, v[5:6], off                        // 0000008B2E1C: DC820000 037C0005
	s_waitcnt vmcnt(0)                                         // 0000008B2E24: BF8903F7
	v_cvt_f32_f16_e32 v3, v3                                   // 0000008B2E28: 7E061703
	s_or_b32 exec_lo, exec_lo, s3                              // 0000008B2E2C: 8C7E037E
	v_add_nc_u32_e32 v5, 0x60, v24                             // 0000008B2E30: 4A0A30FF 00000060
	s_mov_b32 s3, exec_lo                                      // 0000008B2E38: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008B2E3C: BF870001
	.long 0xd4c1007e                                           // 0000008B2E40: D4C1007E
	v_cndmask_b32_e32 v1, v5, v25, vcc_lo                      // 0000008B2E44: 02023305
	s_cbranch_execz 11                                         // 0000008B2E48: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi2ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x278>
	v_lshlrev_b32_e32 v4, 1, v5                                // 0000008B2E4C: 30080A81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008B2E50: BF8700A1
	v_ashrrev_i32_e32 v5, 31, v4                               // 0000008B2E54: 340A089F
	.long 0xd7006a04                                           // 0000008B2E58: D7006A04
	v_cndmask_b32_e32 v1, v17, v4, vcc_lo                      // 0000008B2E5C: 02020911
	v_add_co_ci_u32_e64 v5, null, v26, v5, vcc_lo              // 0000008B2E60: D5207C05 01AA0B1A
	global_load_d16_b16 v4, v[4:5], off                        // 0000008B2E68: DC820000 047C0004
	s_waitcnt vmcnt(0)                                         // 0000008B2E70: BF8903F7
	v_cvt_f32_f16_e32 v4, v4                                   // 0000008B2E74: 7E081704
	s_or_b32 exec_lo, exec_lo, s3                              // 0000008B2E78: 8C7E037E
	v_dual_mov_b32 v6, 0 :: v_dual_add_nc_u32 v7, 0x80, v24    // 0000008B2E7C: CA200080 060630FF 00000080
	v_mov_b32_e32 v5, 0                                        // 0000008B2E88: 7E0A0280
	s_mov_b32 s3, exec_lo                                      // 0000008B2E8C: BE83007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000008B2E90: BF870002
	.long 0xd4c1007e                                           // 0000008B2E94: D4C1007E
	v_cndmask_b32_e32 v1, v7, v25, vcc_lo                      // 0000008B2E98: 02023307
	s_cbranch_execz 11                                         // 0000008B2E9C: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi2ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x2cc>
	v_lshlrev_b32_e32 v5, 1, v7                                // 0000008B2EA0: 300A0E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008B2EA4: BF8700A1
	v_ashrrev_i32_e32 v8, 31, v5                               // 0000008B2EA8: 34100A9F
	.long 0xd7006a07                                           // 0000008B2EAC: D7006A07
	v_cndmask_b32_e32 v1, v17, v5, vcc_lo                      // 0000008B2EB0: 02020B11
	v_add_co_ci_u32_e64 v8, null, v26, v8, vcc_lo              // 0000008B2EB4: D5207C08 01AA111A
	global_load_d16_b16 v5, v[7:8], off                        // 0000008B2EBC: DC820000 057C0007
	s_waitcnt vmcnt(0)                                         // 0000008B2EC4: BF8903F7
	v_cvt_f32_f16_e32 v5, v5                                   // 0000008B2EC8: 7E0A1705
	s_or_b32 exec_lo, exec_lo, s3                              // 0000008B2ECC: 8C7E037E
	v_add_nc_u32_e32 v7, 0xa0, v24                             // 0000008B2ED0: 4A0E30FF 000000A0
	s_mov_b32 s3, exec_lo                                      // 0000008B2ED8: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008B2EDC: BF870001
	.long 0xd4c1007e                                           // 0000008B2EE0: D4C1007E
	v_cndmask_b32_e32 v1, v7, v25, vcc_lo                      // 0000008B2EE4: 02023307
	s_cbranch_execz 11                                         // 0000008B2EE8: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi2ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x318>
	v_lshlrev_b32_e32 v6, 1, v7                                // 0000008B2EEC: 300C0E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008B2EF0: BF8700A1
	v_ashrrev_i32_e32 v7, 31, v6                               // 0000008B2EF4: 340E0C9F
	.long 0xd7006a06                                           // 0000008B2EF8: D7006A06
	v_cndmask_b32_e32 v1, v17, v6, vcc_lo                      // 0000008B2EFC: 02020D11
	v_add_co_ci_u32_e64 v7, null, v26, v7, vcc_lo              // 0000008B2F00: D5207C07 01AA0F1A
	global_load_d16_b16 v6, v[6:7], off                        // 0000008B2F08: DC820000 067C0006
	s_waitcnt vmcnt(0)                                         // 0000008B2F10: BF8903F7
	v_cvt_f32_f16_e32 v6, v6                                   // 0000008B2F14: 7E0C1706
	s_or_b32 exec_lo, exec_lo, s3                              // 0000008B2F18: 8C7E037E
	v_dual_mov_b32 v8, 0 :: v_dual_add_nc_u32 v11, 0xc0, v24   // 0000008B2F1C: CA200080 080A30FF 000000C0
	v_mov_b32_e32 v7, 0                                        // 0000008B2F28: 7E0E0280
	s_mov_b32 s3, exec_lo                                      // 0000008B2F2C: BE83007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000008B2F30: BF870002
	.long 0xd4c1007e                                           // 0000008B2F34: D4C1007E
	v_cndmask_b32_e32 v1, v11, v25, vcc_lo                     // 0000008B2F38: 0202330B
	s_cbranch_execz 11                                         // 0000008B2F3C: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi2ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x36c>
	v_lshlrev_b32_e32 v7, 1, v11                               // 0000008B2F40: 300E1681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008B2F44: BF8700A1
	v_ashrrev_i32_e32 v12, 31, v7                              // 0000008B2F48: 34180E9F
	.long 0xd7006a0b                                           // 0000008B2F4C: D7006A0B
	v_cndmask_b32_e32 v1, v17, v7, vcc_lo                      // 0000008B2F50: 02020F11
	v_add_co_ci_u32_e64 v12, null, v26, v12, vcc_lo            // 0000008B2F54: D5207C0C 01AA191A
	global_load_d16_b16 v7, v[11:12], off                      // 0000008B2F5C: DC820000 077C000B
	s_waitcnt vmcnt(0)                                         // 0000008B2F64: BF8903F7
	v_cvt_f32_f16_e32 v7, v7                                   // 0000008B2F68: 7E0E1707
	s_or_b32 exec_lo, exec_lo, s3                              // 0000008B2F6C: 8C7E037E
	v_add_nc_u32_e32 v11, 0xe0, v24                            // 0000008B2F70: 4A1630FF 000000E0
	s_mov_b32 s3, exec_lo                                      // 0000008B2F78: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008B2F7C: BF870001
	.long 0xd4c1007e                                           // 0000008B2F80: D4C1007E
	v_cndmask_b32_e32 v1, v11, v25, vcc_lo                     // 0000008B2F84: 0202330B
	s_cbranch_execz 11                                         // 0000008B2F88: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi2ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x3b8>
	v_lshlrev_b32_e32 v8, 1, v11                               // 0000008B2F8C: 30101681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008B2F90: BF8700A1
	v_ashrrev_i32_e32 v12, 31, v8                              // 0000008B2F94: 3418109F
	.long 0xd7006a0b                                           // 0000008B2F98: D7006A0B
	v_cndmask_b32_e32 v1, v17, v8, vcc_lo                      // 0000008B2F9C: 02021111
	v_add_co_ci_u32_e64 v12, null, v26, v12, vcc_lo            // 0000008B2FA0: D5207C0C 01AA191A
	global_load_d16_b16 v8, v[11:12], off                      // 0000008B2FA8: DC820000 087C000B
	s_waitcnt vmcnt(0)                                         // 0000008B2FB0: BF8903F7
	v_cvt_f32_f16_e32 v8, v8                                   // 0000008B2FB4: 7E101708
	s_or_b32 exec_lo, exec_lo, s3                              // 0000008B2FB8: 8C7E037E
	s_branch 9                                                 // 0000008B2FBC: BFA00009 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi2ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x3e4>
	v_mov_b32_e32 v1, 0                                        // 0000008B2FC0: 7E020280
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008B2FC4: BF870001
	v_mov_b32_e32 v2, v1                                       // 0000008B2FC8: 7E040301
	v_mov_b32_e32 v3, v1                                       // 0000008B2FCC: 7E060301
	v_mov_b32_e32 v4, v1                                       // 0000008B2FD0: 7E080301
	v_mov_b32_e32 v5, v1                                       // 0000008B2FD4: 7E0A0301
	v_mov_b32_e32 v6, v1                                       // 0000008B2FD8: 7E0C0301
	v_mov_b32_e32 v7, v1                                       // 0000008B2FDC: 7E0E0301
	v_mov_b32_e32 v8, v1                                       // 0000008B2FE0: 7E100301
	s_add_u32 s4, s4, s14                                      // 0000008B2FE4: 80040E04
	s_addc_u32 s5, s5, s15                                     // 0000008B2FE8: 82050F05
	s_lshr_b32 s3, s11, 31                                     // 0000008B2FEC: 85039F0B
	v_mov_b32_e32 v27, 0                                       // 0000008B2FF0: 7E360280
	s_add_u32 s10, s10, s3                                     // 0000008B2FF4: 800A030A
	s_addc_u32 s11, s11, 0                                     // 0000008B2FF8: 820B800B
	.long 0xd4410003                                           // 0000008B2FFC: D4410003
	v_cndmask_b32_e32 v1, v24, v25, vcc_lo                     // 0000008B3000: 02023318
	s_ashr_i64 s[10:11], s[10:11], 1                           // 0000008B3004: 868A810A
	v_cndmask_b32_e64 v28, 0, 1, s16                           // 0000008B3008: D501001C 00410280
	v_mad_u64_u32 v[18:19], null, v9, s10, s[4:5]              // 0000008B3010: D6FE7C12 00101509
	.long 0xd72c000c                                           // 0000008B3018: D72C000C
	v_cndmask_b32_e32 v0, v9, v11, vcc_lo                      // 0000008B301C: 02001709
	.long 0xd72c000d                                           // 0000008B3020: D72C000D
	v_cndmask_b32_e32 v0, v10, v10, vcc_lo                     // 0000008B3024: 0200150A
	v_dual_mov_b32 v9, 0 :: v_dual_mov_b32 v30, 0              // 0000008B3028: CA100080 091E0080
	v_dual_mov_b32 v10, 0 :: v_dual_mov_b32 v11, 0             // 0000008B3030: CA100080 0A0A0080
	s_delay_alu instid0(VALU_DEP_3)                            // 0000008B3038: BF870003
	v_add3_u32 v29, v13, v19, v12                              // 0000008B303C: D655001D 0432270D
	v_mov_b32_e32 v12, 0                                       // 0000008B3044: 7E180280
	s_and_saveexec_b32 s4, s3                                  // 0000008B3048: BE842003
	s_cbranch_execz 22                                         // 0000008B304C: BFA50016 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi2ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x4a8>
	v_dual_mov_b32 v30, 0 :: v_dual_lshlrev_b32 v9, 4, v24     // 0000008B3050: CA220080 1E083084
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008B3058: BF8700A1
	v_ashrrev_i32_e32 v10, 31, v9                              // 0000008B305C: 3414129F
	.long 0xd7006a09                                           // 0000008B3060: D7006A09
	v_cndmask_b32_e32 v1, v18, v9, vcc_lo                      // 0000008B3064: 02021312
	v_add_co_ci_u32_e64 v10, null, v29, v10, vcc_lo            // 0000008B3068: D5207C0A 01AA151D
	s_and_not1_b32 vcc_lo, exec_lo, s16                        // 0000008B3070: 916A107E
	global_load_b128 v[9:12], v[9:10], off                     // 0000008B3074: DC5E0000 097C0009
	s_cbranch_vccnz 10                                         // 0000008B307C: BFA4000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi2ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x4a8>
	v_lshlrev_b32_e32 v13, 1, v24                              // 0000008B3080: 301A3081
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008B3084: BF870091
	.long 0xd7006a0d                                           // 0000008B3088: D7006A0D
	v_cndmask_b32_e32 v1, v17, v13, vcc_lo                     // 0000008B308C: 02021B11
	v_add_co_ci_u32_e64 v14, null, 0, v26, vcc_lo              // 0000008B3090: D5207C0E 01AA3480
	global_load_d16_b16 v13, v[13:14], off                     // 0000008B3098: DC820000 0D7C000D
	s_waitcnt vmcnt(0)                                         // 0000008B30A0: BF8903F7
	v_cvt_f32_f16_e32 v30, v13                                 // 0000008B30A4: 7E3C170D
	s_or_b32 exec_lo, exec_lo, s4                              // 0000008B30A8: 8C7E047E
	s_and_saveexec_b32 s4, s3                                  // 0000008B30AC: BE842003
	s_cbranch_execz 232                                        // 0000008B30B0: BFA500E8 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi2ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x854>
	v_add_nc_u32_e32 v13, 32, v24                              // 0000008B30B4: 4A1A30A0
	v_lshlrev_b32_e32 v19, 5, v24                              // 0000008B30B8: 30263085
	v_mov_b32_e32 v27, 0                                       // 0000008B30BC: 7E360280
	v_mov_b32_e32 v33, v30                                     // 0000008B30C0: 7E42031E
	s_mov_b32 s5, 0                                            // 0000008B30C4: BE850080
	v_lshlrev_b32_e32 v31, 4, v13                              // 0000008B30C8: 303E1A84
	v_lshlrev_b32_e32 v32, 1, v13                              // 0000008B30CC: 30401A81
	s_branch 188                                               // 0000008B30D0: BFA000BC <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi2ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x7c4>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000008B30D4: 8C7E0A7E
	v_ashrrev_i32_e32 v20, 31, v19                             // 0000008B30D8: 3428269F
	v_lshrrev_b32_e32 v50, 6, v9                               // 0000008B30DC: 32641286
	v_lshrrev_b32_e32 v51, 14, v9                              // 0000008B30E0: 3266128E
	v_and_b32_e32 v52, 0xff, v10                               // 0000008B30E4: 366814FF 000000FF
	v_lshrrev_b32_e32 v53, 6, v10                              // 0000008B30EC: 326A1486
	.long 0xd73c0022                                           // 0000008B30F0: D73C0022
	v_cndmask_b32_e32 v1, 1, v19, vcc_lo                       // 0000008B30F4: 02022681
	v_and_b32_e32 v20, 0xff, v9                                // 0000008B30F8: 362812FF 000000FF
	v_and_b32_e32 v50, 0x3fc, v50                              // 0000008B3100: 366464FF 000003FC
	v_and_b32_e32 v51, 0x3fc, v51                              // 0000008B3108: 366666FF 000003FC
	v_lshrrev_b32_e32 v9, 22, v9                               // 0000008B3110: 32121296
	v_lshrrev_b32_e32 v54, 14, v10                             // 0000008B3114: 326C148E
	.long 0xd7006a2e                                           // 0000008B3118: D7006A2E
	v_cndmask_b32_e32 v1, s6, v34, vcc_lo                      // 0000008B311C: 02024406
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008B3120: BF870001
	v_add_co_ci_u32_e64 v47, null, s7, v35, vcc_lo             // 0000008B3124: D5207C2F 01AA4607
	v_lshlrev_b32_e32 v20, 2, v20                              // 0000008B312C: 30282882
	ds_load_b32 v50, v50                                       // 0000008B3130: D8D80000 32000032
	ds_load_b32 v51, v51                                       // 0000008B3138: D8D80000 33000033
	s_clause 0x3                                               // 0000008B3140: BF850003
	global_load_b128 v[34:37], v[46:47], off                   // 0000008B3144: DC5E0000 227C002E
	global_load_b128 v[38:41], v[46:47], off offset:16         // 0000008B314C: DC5E0010 267C002E
	global_load_b128 v[42:45], v[46:47], off offset:32         // 0000008B3154: DC5E0020 2A7C002E
	global_load_b128 v[46:49], v[46:47], off offset:48         // 0000008B315C: DC5E0030 2E7C002E
	v_lshrrev_b32_e32 v10, 22, v10                             // 0000008B3164: 32141496
	ds_load_b32 v20, v20                                       // 0000008B3168: D8D80000 14000014
	v_and_b32_e32 v9, 0x3fc, v9                                // 0000008B3170: 361212FF 000003FC
	v_lshlrev_b32_e32 v52, 2, v52                              // 0000008B3178: 30686882
	v_and_b32_e32 v53, 0x3fc, v53                              // 0000008B317C: 366A6AFF 000003FC
	v_and_b32_e32 v54, 0x3fc, v54                              // 0000008B3184: 366C6CFF 000003FC
	v_and_b32_e32 v10, 0x3fc, v10                              // 0000008B318C: 361414FF 000003FC
	ds_load_b32 v9, v9                                         // 0000008B3194: D8D80000 09000009
	ds_load_b32 v52, v52                                       // 0000008B319C: D8D80000 34000034
	ds_load_b32 v53, v53                                       // 0000008B31A4: D8D80000 35000035
	ds_load_b32 v54, v54                                       // 0000008B31AC: D8D80000 36000036
	ds_load_b32 v10, v10                                       // 0000008B31B4: D8D80000 0A00000A
	v_add_nc_u32_e32 v32, 64, v32                              // 0000008B31BC: 4A4040C0
	s_and_b32 s3, exec_lo, s3                                  // 0000008B31C0: 8B03037E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000008B31C4: BF870149
	s_or_b32 s5, s3, s5                                        // 0000008B31C8: 8C050503
	s_waitcnt vmcnt(3) lgkmcnt(5)                              // 0000008B31CC: BF890C57
	v_dot2_f32_bf16 v20, v34, v20, 0                           // 0000008B31D0: CC1A4014 1A022922
	v_and_b32_e32 v34, 0xff, v11                               // 0000008B31D8: 364416FF 000000FF
	v_dot2_f32_bf16 v20, v35, v50, v20                         // 0000008B31E0: CC1A4014 1C526523
	v_lshrrev_b32_e32 v35, 6, v11                              // 0000008B31E8: 32461686
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008B31EC: BF8701A2
	v_dot2_f32_bf16 v20, v36, v51, v20                         // 0000008B31F0: CC1A4014 1C526724
	v_lshrrev_b32_e32 v36, 14, v11                             // 0000008B31F8: 3248168E
	v_and_b32_e32 v35, 0x3fc, v35                              // 0000008B31FC: 364646FF 000003FC
	v_lshrrev_b32_e32 v11, 22, v11                             // 0000008B3204: 32161696
	s_waitcnt lgkmcnt(4)                                       // 0000008B3208: BF89FC47
	v_dot2_f32_bf16 v9, v37, v9, v20                           // 0000008B320C: CC1A4009 1C521325
	v_and_b32_e32 v36, 0x3fc, v36                              // 0000008B3214: 364848FF 000003FC
	v_lshrrev_b32_e32 v37, 6, v12                              // 0000008B321C: 324A1886
	ds_load_b32 v35, v35                                       // 0000008B3220: D8D80000 23000023
	s_waitcnt vmcnt(2) lgkmcnt(4)                              // 0000008B3228: BF890847
	v_dot2_f32_bf16 v9, v38, v52, v9                           // 0000008B322C: CC1A4009 1C266926
	ds_load_b32 v36, v36                                       // 0000008B3234: D8D80000 24000024
	v_lshrrev_b32_e32 v38, 14, v12                             // 0000008B323C: 324C188E
	v_and_b32_e32 v37, 0x3fc, v37                              // 0000008B3240: 364A4AFF 000003FC
	s_waitcnt lgkmcnt(4)                                       // 0000008B3248: BF89FC47
	v_dot2_f32_bf16 v9, v39, v53, v9                           // 0000008B324C: CC1A4009 1C266B27
	v_cndmask_b32_e64 v39, v6, v7, s2                          // 0000008B3254: D5010027 000A0F06
	v_and_b32_e32 v38, 0x3fc, v38                              // 0000008B325C: 364C4CFF 000003FC
	s_waitcnt lgkmcnt(3)                                       // 0000008B3264: BF89FC37
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000008B3268: BF870133
	v_dot2_f32_bf16 v9, v40, v54, v9                           // 0000008B326C: CC1A4009 1C266D28
	v_cndmask_b32_e64 v40, v7, v8, s2                          // 0000008B3274: D5010028 000A1107
	s_waitcnt lgkmcnt(2)                                       // 0000008B327C: BF89FC27
	v_dot2_f32_bf16 v9, v41, v10, v9                           // 0000008B3280: CC1A4009 1C261529
	v_dual_mov_b32 v41, v8 :: v_dual_lshlrev_b32 v20, 2, v34   // 0000008B3288: CA220108 29144482
	v_and_b32_e32 v34, 0xff, v12                               // 0000008B3290: 364418FF 000000FF
	v_lshrrev_b32_e32 v12, 22, v12                             // 0000008B3298: 32181896
	ds_load_b32 v20, v20                                       // 0000008B329C: D8D80000 14000014
	v_lshlrev_b32_e32 v34, 2, v34                              // 0000008B32A4: 30444482
	v_and_b32_e32 v12, 0x3fc, v12                              // 0000008B32A8: 361818FF 000003FC
	s_waitcnt vmcnt(1) lgkmcnt(0)                              // 0000008B32B0: BF890407
	v_dot2_f32_bf16 v9, v42, v20, v9                           // 0000008B32B4: CC1A4009 1C26292A
	v_cndmask_b32_e64 v20, v30, v1, s2                         // 0000008B32BC: D5010014 000A031E
	v_mov_b32_e32 v30, v33                                     // 0000008B32C4: 7E3C0321
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000008B32C8: BF870123
	v_dot2_f32_bf16 v9, v43, v35, v9                           // 0000008B32CC: CC1A4009 1C26472B
	v_cndmask_b32_e64 v35, v2, v3, s2                          // 0000008B32D4: D5010023 000A0702
	v_dot2_f32_bf16 v9, v44, v36, v9                           // 0000008B32DC: CC1A4009 1C26492C
	v_cndmask_b32_e64 v36, v3, v4, s2                          // 0000008B32E4: D5010024 000A0903
	v_and_b32_e32 v11, 0x3fc, v11                              // 0000008B32EC: 361616FF 000003FC
	ds_load_b32 v10, v11                                       // 0000008B32F4: D8D80000 0A00000B
	ds_load_b32 v11, v34                                       // 0000008B32FC: D8D80000 0B000022
	ds_load_b32 v34, v37                                       // 0000008B3304: D8D80000 22000025
	ds_load_b32 v50, v38                                       // 0000008B330C: D8D80000 32000026
	ds_load_b32 v51, v12                                       // 0000008B3314: D8D80000 3300000C
	v_cndmask_b32_e64 v38, v5, v6, s2                          // 0000008B331C: D5010026 000A0D05
	v_cndmask_b32_e64 v37, v4, v5, s2                          // 0000008B3324: D5010025 000A0B04
	v_mov_b32_e32 v12, v16                                     // 0000008B332C: 7E180310
	s_waitcnt lgkmcnt(4)                                       // 0000008B3330: BF89FC47
	v_dot2_f32_bf16 v9, v45, v10, v9                           // 0000008B3334: CC1A4009 1C26152D
	v_mov_b32_e32 v10, v14                                     // 0000008B333C: 7E14030E
	s_waitcnt vmcnt(0) lgkmcnt(3)                              // 0000008B3340: BF890037
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000008B3344: BF870132
	v_dot2_f32_bf16 v9, v46, v11, v9                           // 0000008B3348: CC1A4009 1C26172E
	v_mov_b32_e32 v11, v15                                     // 0000008B3350: 7E16030F
	s_waitcnt lgkmcnt(2)                                       // 0000008B3354: BF89FC27
	v_dot2_f32_bf16 v5, v47, v34, v9                           // 0000008B3358: CC1A4005 1C26452F
	v_cndmask_b32_e64 v34, v1, v2, s2                          // 0000008B3360: D5010022 000A0501
	v_add_nc_u32_e32 v31, 0x200, v31                           // 0000008B3368: 4A3E3EFF 00000200
	v_mov_b32_e32 v9, v13                                      // 0000008B3370: 7E12030D
	v_add_nc_u32_e32 v19, 0x400, v19                           // 0000008B3374: 4A2626FF 00000400
	s_waitcnt lgkmcnt(1)                                       // 0000008B337C: BF89FC17
	v_dot2_f32_bf16 v1, v48, v50, v5                           // 0000008B3380: CC1A4001 1C166530
	s_waitcnt lgkmcnt(0)                                       // 0000008B3388: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008B338C: BF870091
	v_dot2_f32_bf16 v1, v49, v51, v1                           // 0000008B3390: CC1A4001 1C066731
	v_fmac_f32_e32 v27, v20, v1                                // 0000008B3398: 56360314
	v_dual_mov_b32 v1, v34 :: v_dual_mov_b32 v2, v35           // 0000008B339C: CA100122 01020123
	v_dual_mov_b32 v3, v36 :: v_dual_mov_b32 v4, v37           // 0000008B33A4: CA100124 03040125
	v_dual_mov_b32 v5, v38 :: v_dual_mov_b32 v6, v39           // 0000008B33AC: CA100126 05060127
	v_dual_mov_b32 v7, v40 :: v_dual_mov_b32 v8, v41           // 0000008B33B4: CA100128 07080129
	s_and_not1_b32 exec_lo, exec_lo, s5                        // 0000008B33BC: 917E057E
	s_cbranch_execz 35                                         // 0000008B33C0: BFA50023 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi2ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x850>
	s_waitcnt vmcnt(0)                                         // 0000008B33C4: BF8903F7
	v_dual_mov_b32 v13, v9 :: v_dual_add_nc_u32 v24, 32, v24   // 0000008B33C8: CA200109 0D1830A0
	v_dual_mov_b32 v14, v10 :: v_dual_mov_b32 v15, v11         // 0000008B33D0: CA10010A 0E0E010B
	v_mov_b32_e32 v16, v12                                     // 0000008B33D8: 7E20030C
	s_delay_alu instid0(VALU_DEP_3)                            // 0000008B33DC: BF870003
	.long 0xd4460003                                           // 0000008B33E0: D4460003
	v_cndmask_b32_e32 v1, v24, v25, vcc_lo                     // 0000008B33E4: 02023318
	s_mov_b32 s10, exec_lo                                     // 0000008B33E8: BE8A007E
	.long 0xd4c1007e                                           // 0000008B33EC: D4C1007E
	v_cndmask_b32_e32 v1, v24, v25, vcc_lo                     // 0000008B33F0: 02023318
	s_cbranch_execz 65335                                      // 0000008B33F4: BFA5FF37 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi2ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x4d4>
	v_ashrrev_i32_e32 v14, 31, v31                             // 0000008B33F8: 341C3E9F
	.long 0xd7006a0d                                           // 0000008B33FC: D7006A0D
	v_cndmask_b32_e32 v1, v18, v31, vcc_lo                     // 0000008B3400: 02023F12
	v_mov_b32_e32 v33, v30                                     // 0000008B3404: 7E42031E
	s_delay_alu instid0(VALU_DEP_3)                            // 0000008B3408: BF870003
	v_add_co_ci_u32_e64 v14, null, v29, v14, vcc_lo            // 0000008B340C: D5207C0E 01AA1D1D
	v_cmp_ne_u32_e32 vcc_lo, 1, v28                            // 0000008B3414: 7C9A3881
	global_load_b128 v[13:16], v[13:14], off                   // 0000008B3418: DC5E0000 0D7C000D
	s_cbranch_vccnz 65324                                      // 0000008B3420: BFA4FF2C <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi2ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x4d4>
	v_ashrrev_i32_e32 v20, 31, v32                             // 0000008B3424: 3428409F
	.long 0xd7006a21                                           // 0000008B3428: D7006A21
	v_cndmask_b32_e32 v1, v17, v32, vcc_lo                     // 0000008B342C: 02024111
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008B3430: BF870001
	v_add_co_ci_u32_e64 v34, null, v26, v20, vcc_lo            // 0000008B3434: D5207C22 01AA291A
	global_load_d16_b16 v20, v[33:34], off                     // 0000008B343C: DC820000 147C0021
	s_waitcnt vmcnt(0)                                         // 0000008B3444: BF8903F7
	v_cvt_f32_f16_e32 v33, v20                                 // 0000008B3448: 7E421714
	s_branch 65313                                             // 0000008B344C: BFA0FF21 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi2ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x4d4>
	s_or_b32 exec_lo, exec_lo, s5                              // 0000008B3450: 8C7E057E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008B3454: BF8700B9
	s_or_b32 exec_lo, exec_lo, s4                              // 0000008B3458: 8C7E047E
	.long 0xd71f0001                                           // 0000008B345C: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000008B3460: 020100C1
	s_mov_b32 s2, exec_lo                                      // 0000008B3464: BE82007E
	v_xor_b32_e32 v2, 16, v1                                   // 0000008B3468: 3A040290
	v_xor_b32_e32 v3, 8, v1                                    // 0000008B346C: 3A060288
	v_xor_b32_e32 v4, 4, v1                                    // 0000008B3470: 3A080284
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000008B3474: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 0000008B3478: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 0000008B347C: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v3                            // 0000008B3480: 7C9806A0
	v_cndmask_b32_e32 v3, v1, v3, vcc_lo                       // 0000008B3484: 02060701
	v_cmp_gt_u32_e32 vcc_lo, 32, v4                            // 0000008B3488: 7C9808A0
	s_delay_alu instid0(VALU_DEP_2)                            // 0000008B348C: BF870002
	v_lshlrev_b32_e32 v3, 2, v3                                // 0000008B3490: 30060682
	v_lshlrev_b32_e32 v2, 2, v2                                // 0000008B3494: 30040482
	v_cndmask_b32_e32 v4, v1, v4, vcc_lo                       // 0000008B3498: 02080901
	ds_bpermute_b32 v2, v2, v27                                // 0000008B349C: DACC0000 02001B02
	v_lshlrev_b32_e32 v4, 2, v4                                // 0000008B34A4: 30080882
	s_waitcnt lgkmcnt(0)                                       // 0000008B34A8: BF89FC07
	v_add_f32_e32 v2, v27, v2                                  // 0000008B34AC: 0604051B
	ds_bpermute_b32 v3, v3, v2                                 // 0000008B34B0: DACC0000 03000203
	s_waitcnt lgkmcnt(0)                                       // 0000008B34B8: BF89FC07
	v_add_f32_e32 v2, v2, v3                                   // 0000008B34BC: 06040702
	ds_bpermute_b32 v3, v4, v2                                 // 0000008B34C0: DACC0000 03000204
	v_xor_b32_e32 v4, 2, v1                                    // 0000008B34C8: 3A080282
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008B34CC: BF8700A1
	v_cmp_gt_u32_e32 vcc_lo, 32, v4                            // 0000008B34D0: 7C9808A0
	v_cndmask_b32_e32 v4, v1, v4, vcc_lo                       // 0000008B34D4: 02080901
	v_lshlrev_b32_e32 v4, 2, v4                                // 0000008B34D8: 30080882
	s_waitcnt lgkmcnt(0)                                       // 0000008B34DC: BF89FC07
	v_add_f32_e32 v2, v2, v3                                   // 0000008B34E0: 06040702
	ds_bpermute_b32 v3, v4, v2                                 // 0000008B34E4: DACC0000 03000204
	v_xor_b32_e32 v4, 1, v1                                    // 0000008B34EC: 3A080281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008B34F0: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v4                            // 0000008B34F4: 7C9808A0
	s_waitcnt lgkmcnt(0)                                       // 0000008B34F8: BF89FC07
	v_dual_cndmask_b32 v4, v1, v4 :: v_dual_add_f32 v1, v2, v3 // 0000008B34FC: CA480901 04000702
	v_lshlrev_b32_e32 v2, 2, v4                                // 0000008B3504: 30040882
	ds_bpermute_b32 v2, v2, v1                                 // 0000008B3508: DACC0000 02000102
	v_cmpx_eq_u32_e32 0, v23                                   // 0000008B3510: 7D942E80
	s_cbranch_execz 8                                          // 0000008B3514: BFA50008 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi2ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x938>
	v_lshlrev_b32_e32 v3, 2, v22                               // 0000008B3518: 30062C82
	s_waitcnt lgkmcnt(0)                                       // 0000008B351C: BF89FC07
	v_add_f32_e32 v1, v1, v2                                   // 0000008B3520: 06020501
	s_delay_alu instid0(VALU_DEP_2)                            // 0000008B3524: BF870002
	v_lshl_or_b32 v3, v21, 3, v3                               // 0000008B3528: D6560003 040D0715
	ds_store_b32 v3, v1 offset:1024                            // 0000008B3530: D8340400 00000103
	s_or_b32 exec_lo, exec_lo, s2                              // 0000008B3538: 8C7E027E
	v_or_b32_e32 v1, s20, v0                                   // 0000008B353C: 38020014
	s_waitcnt lgkmcnt(0)                                       // 0000008B3540: BF89FC07
	v_mov_b32_e32 v2, s21                                      // 0000008B3544: 7E040215
	.long 0xd44c0002                                           // 0000008B3548: D44C0002
	v_cndmask_b32_e32 v1, 4, v0, vcc_lo                        // 0000008B354C: 02020084
	s_waitcnt vmcnt(0)                                         // 0000008B3550: BF8903F7
	s_barrier                                                  // 0000008B3554: BFBD0000
	buffer_gl0_inv                                             // 0000008B3558: E0AC0000 00000000
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[1:2]                  // 0000008B3560: 7CA8020C
	s_and_b32 s2, s2, vcc_lo                                   // 0000008B3564: 8B026A02
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000008B3568: BF870009
	s_and_saveexec_b32 s3, s2                                  // 0000008B356C: BE832002
	s_cbranch_execz 58                                         // 0000008B3570: BFA5003A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi2ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0xa5c>
	v_ashrrev_i32_e32 v3, 31, v2                               // 0000008B3574: 3406049F
	v_lshlrev_b32_e32 v0, 3, v0                                // 0000008B3578: 30000083
	s_load_b64 s[2:3], s[0:1], 0x40                            // 0000008B357C: F4040080 F8000040
	v_mov_b32_e32 v9, s8                                       // 0000008B3584: 7E120208
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008B3588: BF8700B3
	v_lshrrev_b32_e32 v5, 23, v3                               // 0000008B358C: 320A0697
	ds_load_b64 v[3:4], v0 offset:1024                         // 0000008B3590: D9D80400 03000000
	.long 0xd7006a00                                           // 0000008B3598: D7006A00
	v_cndmask_b32_e32 v1, v1, v5, vcc_lo                       // 0000008B359C: 02020B01
	v_add_co_ci_u32_e64 v5, null, 0, v2, vcc_lo                // 0000008B35A0: D5207C05 01AA0480
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008B35A8: BF870092
	v_and_b32_e32 v6, 0xfffffe00, v0                           // 0000008B35AC: 360C00FF FFFFFE00
	.long 0xd7016a00                                           // 0000008B35B4: D7016A00
	v_cndmask_b32_e32 v1, v1, v6, vcc_lo                       // 0000008B35B8: 02020D01
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000008B35BC: BF870111
	v_sub_co_ci_u32_e64 v1, null, v2, v5, vcc_lo               // 0000008B35C0: D5217C01 01AA0B02
	.long 0xd7000007                                           // 0000008B35C8: D7000007
	v_cndmask_b32_e32 v1, 0xffffff00, v0, vcc_lo               // 0000008B35CC: 020200FF FFFFFF00
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000008B35D4: BF870142
	v_cmp_gt_i64_e32 vcc_lo, 0x100, v[0:1]                     // 0000008B35D8: 7CA800FF 00000100
	s_waitcnt lgkmcnt(0)                                       // 0000008B35E0: BF89FC07
	v_dual_add_f32 v3, 0, v3 :: v_dual_mov_b32 v2, s9          // 0000008B35E4: C9100680 03020009
	v_add_co_ci_u32_e64 v8, null, -1, v1, s0                   // 0000008B35EC: D5207C08 000202C1
	v_dual_add_f32 v3, v3, v4 :: v_dual_cndmask_b32 v2, s3, v2 // 0000008B35F4: C9120903 03020403
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008B35FC: BF8701A2
	v_dual_cndmask_b32 v1, v8, v1 :: v_dual_cndmask_b32 v0, v7, v0// 0000008B3600: CA520308 01000107
	v_cndmask_b32_e32 v4, s2, v9, vcc_lo                       // 0000008B3608: 02081202
	v_bfe_u32 v7, v3, 16, 1                                    // 0000008B360C: D6100007 02052103
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008B3614: BF870193
	.long 0xd73c0000                                           // 0000008B3618: D73C0000
	v_cndmask_b32_e32 v1, 1, v0, vcc_lo                        // 0000008B361C: 02020081
	.long 0xd7006a04                                           // 0000008B3620: D7006A04
	v_cndmask_b32_e32 v1, v4, v6, vcc_lo                       // 0000008B3624: 02020D04
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000008B3628: BF870211
	v_add_co_ci_u32_e64 v2, null, v2, v5, vcc_lo               // 0000008B362C: D5207C02 01AA0B02
	v_add3_u32 v3, v3, v7, 0x7fff                              // 0000008B3634: D6550003 03FE0F03 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008B3640: BF870093
	.long 0xd7006a00                                           // 0000008B3644: D7006A00
	v_cndmask_b32_e32 v1, v4, v0, vcc_lo                       // 0000008B3648: 02020104
	v_add_co_ci_u32_e64 v1, null, v2, v1, vcc_lo               // 0000008B364C: D5207C01 01AA0302
	global_store_d16_hi_b16 v[0:1], v3, off                    // 0000008B3654: DC960000 007C0300
	s_endpgm                                                   // 0000008B365C: BFB00000
		...

