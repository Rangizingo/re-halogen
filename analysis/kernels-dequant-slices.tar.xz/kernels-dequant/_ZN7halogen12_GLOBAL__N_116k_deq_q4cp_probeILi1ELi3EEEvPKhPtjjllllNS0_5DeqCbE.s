0000000000273700 <_ZN7halogen12_GLOBAL__N_116k_deq_q4cp_probeILi1ELi3EEEvPKhPtjjllllNS0_5DeqCbE>:
; _ZN7halogen12_GLOBAL__N_116k_deq_q4cp_probeILi1ELi3EEEvPKhPtjjllllNS0_5DeqCbE():
	s_load_b64 s[16:17], s[0:1], 0x10                          // 000000273700: F4040400 F8000010
	s_lshl_b32 s3, s2, 8                                       // 000000273708: 84038802
	s_waitcnt lgkmcnt(0)                                       // 00000027370C: BF89FC07
	s_cmp_ge_u32 s3, s17                                       // 000000273710: BF091103
	s_cbranch_scc1 351                                         // 000000273714: BFA2015F <_ZN7halogen12_GLOBAL__N_116k_deq_q4cp_probeILi1ELi3EEEvPKhPtjjllllNS0_5DeqCbE+0x594>
	s_clause 0x1                                               // 000000273718: BF850001
	s_load_b256 s[4:11], s[0:1], 0x18                          // 00000027371C: F40C0100 F8000018
	s_load_b128 s[12:15], s[0:1], null                         // 000000273724: F4080300 F8000000
	s_cvt_f32_u32 s18, s16                                     // 00000027372C: BE926510
	s_delay_alu instid0(SALU_CYCLE_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000273730: BF87029B
	v_rcp_iflag_f32_e32 v1, s18                                // 000000273734: 7E025612
	v_readfirstlane_b32 s22, v1                                // 000000273738: 7E2C0501
	v_add_nc_u32_e32 v1, s3, v0                                // 00000027373C: 4A020003
	s_waitcnt lgkmcnt(0)                                       // 000000273740: BF89FC07
	s_lshr_b32 s18, s5, 31                                     // 000000273744: 85129F05
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000273748: BF8704A9
	s_add_u32 s18, s4, s18                                     // 00000027374C: 80121204
	s_addc_u32 s19, s5, 0                                      // 000000273750: 82138005
	s_ashr_i64 s[18:19], s[18:19], 1                           // 000000273754: 86928112
	s_add_u32 s20, s12, s6                                     // 000000273758: 8014060C
	s_addc_u32 s21, s13, s7                                    // 00000027375C: 8215070D
	s_add_u32 s6, s12, s8                                      // 000000273760: 8006080C
	s_addc_u32 s7, s13, s9                                     // 000000273764: 8207090D
	s_add_i32 s8, s3, 0x100                                    // 000000273768: 8108FF03 00000100
	s_mul_f32 s12, s22, 0x4f7ffffe                             // 000000273770: A20CFF16 4F7FFFFE
	s_cmp_gt_u32 s8, s17                                       // 000000273778: BF081108
	s_cselect_b32 s9, -1, 0                                    // 00000027377C: 980980C1
	s_cmp_le_u32 s8, s17                                       // 000000273780: BF0B1108
	s_cvt_u32_f32 s8, s12                                      // 000000273784: BE88670C
	s_cselect_b32 s12, -1, 0                                   // 000000273788: 980C80C1
	s_sub_i32 s13, 0, s16                                      // 00000027378C: 818D1080
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000273790: BF870499
	s_mul_i32 s13, s13, s8                                     // 000000273794: 960D080D
	s_mul_hi_u32 s3, s8, s13                                   // 000000273798: 96830D08
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000027379C: BF870499
	s_add_i32 s8, s8, s3                                       // 0000002737A0: 81080308
	.long 0xd72d0002                                           // 0000002737A4: D72D0002
	v_cndmask_b32_e32 v0, v1, v8, vcc_lo                       // 0000002737A8: 02001101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002737AC: BF870091
	.long 0xd72c0003                                           // 0000002737B0: D72C0003
	v_cndmask_b32_e32 v0, v2, v16, vcc_lo                      // 0000002737B4: 02002102
	v_sub_nc_u32_e32 v3, v1, v3                                // 0000002737B8: 4C060701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002737BC: BF870121
	v_subrev_nc_u32_e32 v5, s16, v3                            // 0000002737C0: 4E0A0610
	v_cmp_le_u32_e32 vcc_lo, s16, v3                           // 0000002737C4: 7C960610
	v_dual_cndmask_b32 v3, v3, v5 :: v_dual_add_nc_u32 v4, 1, v2// 0000002737C8: CA600B03 03040481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002737D0: BF870111
	v_dual_cndmask_b32 v2, v2, v4 :: v_dual_mov_b32 v5, 0      // 0000002737D4: CA500902 02040080
	v_cmp_le_u32_e32 vcc_lo, s16, v3                           // 0000002737DC: 7C960610
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002737E0: BF870092
	v_add_nc_u32_e32 v4, 1, v2                                 // 0000002737E4: 4A080481
	v_dual_cndmask_b32 v3, v2, v4 :: v_dual_mov_b32 v4, 0      // 0000002737E8: CA500902 03040080
	.long 0xd44c0003                                           // 0000002737F0: D44C0003
	v_cndmask_b32_e32 v1, s17, v1, vcc_lo                      // 0000002737F4: 02020211
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002737F8: BF8700A2
	.long 0xd72c0002                                           // 0000002737FC: D72C0002
	v_cndmask_b32_e32 v0, v3, v16, vcc_lo                      // 000000273800: 02002103
	s_or_b32 s13, s12, s3                                      // 000000273804: 8C0D030C
	v_sub_nc_u32_e32 v2, v1, v2                                // 000000273808: 4C040501
	s_delay_alu instid0(VALU_DEP_1)                            // 00000027380C: BF870001
	v_lshlrev_b32_e32 v1, 3, v2                                // 000000273810: 30020483
	s_and_saveexec_b32 s12, s13                                // 000000273814: BE8C200D
	s_cbranch_execz 32                                         // 000000273818: BFA50020 <_ZN7halogen12_GLOBAL__N_116k_deq_q4cp_probeILi1ELi3EEEvPKhPtjjllllNS0_5DeqCbE+0x19c>
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000027381C: BF8701B1
	v_lshrrev_b32_e32 v2, 1, v1                                // 000000273820: 32040281
	v_mad_u64_u32 v[4:5], null, s10, v3, s[6:7]                // 000000273824: D6FE7C04 001A060A
	v_lshrrev_b32_e32 v10, 4, v1                               // 00000027382C: 32140284
	.long 0xd7000d06                                           // 000000273830: D7000D06
	v_cndmask_b32_e32 v1, s20, v2, vcc_lo                      // 000000273834: 02020414
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000273838: BF870191
	v_add_co_ci_u32_e64 v7, null, s21, 0, s13                  // 00000027383C: D5207C07 00350015
	v_and_b32_e32 v2, 0xffffffe, v10                           // 000000273844: 360414FF 0FFFFFFE
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000027384C: BF870193
	v_mad_u64_u32 v[8:9], null, s11, v3, v[5:6]                // 000000273850: D6FE7C08 0416060B
	v_mad_u64_u32 v[5:6], null, s18, v3, v[6:7]                // 000000273858: D6FE7C05 041A0612
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000273860: BF870093
	.long 0xd7006a09                                           // 000000273864: D7006A09
	v_cndmask_b32_e32 v1, v4, v2, vcc_lo                       // 000000273868: 02020504
	v_add_co_ci_u32_e64 v10, null, 0, v8, vcc_lo               // 00000027386C: D5207C0A 01AA1080
	s_delay_alu instid0(VALU_DEP_3)                            // 000000273874: BF870003
	v_mad_u64_u32 v[6:7], null, s19, v3, v[6:7]                // 000000273878: D6FE7C06 041A0613
	s_clause 0x1                                               // 000000273880: BF850001
	global_load_d16_b16 v2, v[9:10], off                       // 000000273884: DC820000 027C0009
	global_load_b32 v5, v[5:6], off                            // 00000027388C: DC520000 057C0005
	s_waitcnt vmcnt(1)                                         // 000000273894: BF8907F7
	v_cvt_f32_f16_e32 v4, v2                                   // 000000273898: 7E081702
	s_or_b32 exec_lo, exec_lo, s12                             // 00000027389C: 8C7E0C7E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002738A0: BF870009
	s_and_b32 vcc_lo, exec_lo, s9                              // 0000002738A4: 8B6A097E
	s_mov_b32 s9, -1                                           // 0000002738A8: BE8900C1
	s_waitcnt vmcnt(0)                                         // 0000002738AC: BF8903F7
	s_barrier                                                  // 0000002738B0: BFBD0000
	buffer_gl0_inv                                             // 0000002738B4: E0AC0000 00000000
	s_cbranch_vccnz 11                                         // 0000002738BC: BFA4000B <_ZN7halogen12_GLOBAL__N_116k_deq_q4cp_probeILi1ELi3EEEvPKhPtjjllllNS0_5DeqCbE+0x1ec>
	s_load_b32 s0, s[0:1], 0x78                                // 0000002738C0: F4000000 F8000078
	s_and_not1_b32 vcc_lo, exec_lo, s9                         // 0000002738C8: 916A097E
	s_cbranch_vccz 42                                          // 0000002738CC: BFA3002A <_ZN7halogen12_GLOBAL__N_116k_deq_q4cp_probeILi1ELi3EEEvPKhPtjjllllNS0_5DeqCbE+0x278>
	s_waitcnt lgkmcnt(0)                                       // 0000002738D0: BF89FC07
	s_add_i32 s2, s0, s2                                       // 0000002738D4: 81020200
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000002738D8: BF870499
	s_lshl_b32 s1, s2, 8                                       // 0000002738DC: 84018802
	s_cmp_ge_u32 s1, s17                                       // 0000002738E0: BF091101
	s_cbranch_scc0 70                                          // 0000002738E4: BFA10046 <_ZN7halogen12_GLOBAL__N_116k_deq_q4cp_probeILi1ELi3EEEvPKhPtjjllllNS0_5DeqCbE+0x300>
	s_branch 234                                               // 0000002738E8: BFA000EA <_ZN7halogen12_GLOBAL__N_116k_deq_q4cp_probeILi1ELi3EEEvPKhPtjjllllNS0_5DeqCbE+0x594>
	s_and_saveexec_b32 s9, s3                                  // 0000002738EC: BE892003
	s_cbranch_execz 29                                         // 0000002738F0: BFA5001D <_ZN7halogen12_GLOBAL__N_116k_deq_q4cp_probeILi1ELi3EEEvPKhPtjjllllNS0_5DeqCbE+0x268>
	v_mad_u64_u32 v[6:7], null, s4, v3, 0                      // 0000002738F4: D6FE7C06 02020604
	v_lshl_add_u32 v9, v4, 2, v5                               // 0000002738FC: D6460009 04150504
	v_mov_b32_e32 v2, 0                                        // 000000273904: 7E040280
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000273908: BF870211
	.long 0xd73c000a                                           // 00000027390C: D73C000A
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 000000273910: 02020281
	v_mad_u64_u32 v[7:8], null, s5, v3, v[7:8]                 // 000000273914: D6FE7C07 041E0605
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000027391C: BF870114
	v_sub_nc_u32_e32 v8, v9, v4                                // 000000273920: 4C100909
	.long 0xd73c0006                                           // 000000273924: D73C0006
	v_cndmask_b32_e32 v1, 1, v6, vcc_lo                        // 000000273928: 02020C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000027392C: BF870091
	.long 0xd7006a02                                           // 000000273930: D7006A02
	v_cndmask_b32_e32 v1, s14, v6, vcc_lo                      // 000000273934: 02020C0E
	v_add_co_ci_u32_e64 v6, null, s15, v7, vcc_lo              // 000000273938: D5207C06 01AA0E0F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000273940: BF870194
	v_sub_nc_u32_e32 v7, v8, v4                                // 000000273944: 4C0E0908
	.long 0xd7006a0a                                           // 000000273948: D7006A0A
	v_cndmask_b32_e32 v1, v2, v10, vcc_lo                      // 00000027394C: 02021502
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000273950: BF870191
	v_add_co_ci_u32_e64 v11, null, v6, v11, vcc_lo             // 000000273954: D5207C0B 01AA1706
	v_sub_nc_u32_e32 v6, v7, v4                                // 00000027395C: 4C0C0907
	global_store_b128 v[10:11], v[6:9], off                    // 000000273960: DC760000 007C060A
	s_or_b32 exec_lo, exec_lo, s9                              // 000000273968: 8C7E097E
	s_load_b32 s0, s[0:1], 0x78                                // 00000027396C: F4000000 F8000078
	s_cbranch_execnz 65494                                     // 000000273974: BFA6FFD6 <_ZN7halogen12_GLOBAL__N_116k_deq_q4cp_probeILi1ELi3EEEvPKhPtjjllllNS0_5DeqCbE+0x1d0>
	v_mad_u64_u32 v[7:8], null, s4, v3, 0                      // 000000273978: D6FE7C07 02020604
	v_dual_mov_b32 v2, 0 :: v_dual_add_nc_u32 v5, v4, v5       // 000000273980: CA200080 02040B04
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000273988: BF870111
	v_add_nc_u32_e32 v6, v5, v4                                // 00000027398C: 4A0C0905
	.long 0xd73c0001                                           // 000000273990: D73C0001
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 000000273994: 02020281
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000273998: BF870094
	v_mad_u64_u32 v[8:9], null, s5, v3, v[8:9]                 // 00000027399C: D6FE7C08 04220605
	.long 0xd73c0008                                           // 0000002739A4: D73C0008
	v_cndmask_b32_e32 v1, 1, v7, vcc_lo                        // 0000002739A8: 02020E81
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002739AC: BF870114
	v_add_nc_u32_e32 v7, v6, v4                                // 0000002739B0: 4A0E0906
	.long 0xd7006a03                                           // 0000002739B4: D7006A03
	v_cndmask_b32_e32 v1, s14, v8, vcc_lo                      // 0000002739B8: 0202100E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002739BC: BF870191
	v_add_co_ci_u32_e64 v9, null, s15, v9, vcc_lo              // 0000002739C0: D5207C09 01AA120F
	v_add_nc_u32_e32 v8, v7, v4                                // 0000002739C8: 4A100907
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002739CC: BF870093
	.long 0xd7006a01                                           // 0000002739D0: D7006A01
	v_cndmask_b32_e32 v1, v3, v1, vcc_lo                       // 0000002739D4: 02020303
	v_add_co_ci_u32_e64 v2, null, v9, v2, vcc_lo               // 0000002739D8: D5207C02 01AA0509
	global_store_b128 v[1:2], v[5:8], off                      // 0000002739E0: DC760000 007C0501
	s_waitcnt lgkmcnt(0)                                       // 0000002739E8: BF89FC07
	s_add_i32 s2, s0, s2                                       // 0000002739EC: 81020200
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000002739F0: BF870499
	s_lshl_b32 s1, s2, 8                                       // 0000002739F4: 84018802
	s_cmp_ge_u32 s1, s17                                       // 0000002739F8: BF091101
	s_cbranch_scc1 165                                         // 0000002739FC: BFA200A5 <_ZN7halogen12_GLOBAL__N_116k_deq_q4cp_probeILi1ELi3EEEvPKhPtjjllllNS0_5DeqCbE+0x594>
	v_dual_mov_b32 v5, 0 :: v_dual_lshlrev_b32 v2, 3, v0       // 000000273A00: CA220080 05020083
	v_add_nc_u32_e32 v1, s1, v0                                // 000000273A08: 4A020001
	s_lshl_b32 s3, s16, 3                                      // 000000273A0C: 84038310
	s_lshl_b32 s9, s0, 11                                      // 000000273A10: 84098B00
	s_delay_alu instid0(VALU_DEP_2)                            // 000000273A14: BF870002
	v_lshl_or_b32 v2, s2, 11, v2                               // 000000273A18: D6560002 04091602
	s_lshl_b32 s2, s0, 8                                       // 000000273A20: 84028800
	s_sub_i32 s3, 0, s3                                        // 000000273A24: 81830380
	s_branch 6                                                 // 000000273A28: BFA00006 <_ZN7halogen12_GLOBAL__N_116k_deq_q4cp_probeILi1ELi3EEEvPKhPtjjllllNS0_5DeqCbE+0x344>
	v_add_nc_u32_e32 v1, s2, v1                                // 000000273A2C: 4A020202
	v_add_nc_u32_e32 v2, s9, v2                                // 000000273A30: 4A040409
	s_add_i32 s1, s1, s2                                       // 000000273A34: 81010201
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000273A38: BF870009
	s_cmp_lt_u32 s1, s17                                       // 000000273A3C: BF0A1101
	s_cbranch_scc0 148                                         // 000000273A40: BFA10094 <_ZN7halogen12_GLOBAL__N_116k_deq_q4cp_probeILi1ELi3EEEvPKhPtjjllllNS0_5DeqCbE+0x594>
	.long 0xd72d0003                                           // 000000273A44: D72D0003
	v_cndmask_b32_e32 v0, v1, v8, vcc_lo                       // 000000273A48: 02001101
	s_add_i32 s0, s1, 0x100                                    // 000000273A4C: 8100FF01 00000100
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000273A54: BF8700C9
	s_cmp_gt_u32 s0, s17                                       // 000000273A58: BF081100
	s_cselect_b32 s12, -1, 0                                   // 000000273A5C: 980C80C1
	s_cmp_le_u32 s0, s17                                       // 000000273A60: BF0B1100
	s_cselect_b32 s13, -1, 0                                   // 000000273A64: 980D80C1
	.long 0xd72c0004                                           // 000000273A68: D72C0004
	v_cndmask_b32_e32 v1, s16, v3, vcc_lo                      // 000000273A6C: 02020610
	v_not_b32_e32 v3, v3                                       // 000000273A70: 7E066F03
	s_waitcnt vmcnt(0)                                         // 000000273A74: BF8903F7
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000273A78: BF870112
	v_sub_nc_u32_e32 v8, v1, v4                                // 000000273A7C: 4C100901
	v_mad_u64_u32 v[3:4], null, s16, v3, v[1:2]                // 000000273A80: D6FE7C03 04060610
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000273A88: BF8701A2
	v_cmp_le_u32_e32 vcc_lo, s16, v8                           // 000000273A8C: 7C961010
	v_add_nc_u32_e32 v7, s1, v0                                // 000000273A90: 4A0E0001
	v_cndmask_b32_e32 v3, v8, v3, vcc_lo                       // 000000273A94: 02060708
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000273A98: BF870092
	.long 0xd72d0006                                           // 000000273A9C: D72D0006
	v_cndmask_b32_e32 v0, v7, v8, vcc_lo                       // 000000273AA0: 02001107
	v_dual_mov_b32 v8, 0 :: v_dual_add_nc_u32 v9, 1, v6        // 000000273AA4: CA200080 08080C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000273AAC: BF870121
	v_cndmask_b32_e32 v4, v6, v9, vcc_lo                       // 000000273AB0: 02081306
	.long 0xd44c0000                                           // 000000273AB4: D44C0000
	v_cndmask_b32_e32 v1, s17, v7, vcc_lo                      // 000000273AB8: 02020E11
	v_dual_mov_b32 v7, 0 :: v_dual_add_nc_u32 v6, 1, v4        // 000000273ABC: CA200080 07060881
	v_cmp_le_u32_e32 vcc_lo, s16, v3                           // 000000273AC4: 7C960610
	s_or_b32 s22, s13, s0                                      // 000000273AC8: 8C16000D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000273ACC: BF870092
	v_cndmask_b32_e32 v6, v4, v6, vcc_lo                       // 000000273AD0: 020C0D04
	v_mad_u64_u32 v[3:4], null, s3, v6, v[2:3]                 // 000000273AD4: D6FE7C03 040A0C03
	s_and_saveexec_b32 s13, s22                                // 000000273ADC: BE8D2016
	s_cbranch_execnz 8                                         // 000000273AE0: BFA60008 <_ZN7halogen12_GLOBAL__N_116k_deq_q4cp_probeILi1ELi3EEEvPKhPtjjllllNS0_5DeqCbE+0x404>
	s_or_b32 exec_lo, exec_lo, s13                             // 000000273AE4: 8C7E0D7E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000273AE8: BF870009
	s_and_b32 vcc_lo, exec_lo, s12                             // 000000273AEC: 8B6A0C7E
	s_mov_b32 s12, -1                                          // 000000273AF0: BE8C00C1
	s_cbranch_vccnz 39                                         // 000000273AF4: BFA40027 <_ZN7halogen12_GLOBAL__N_116k_deq_q4cp_probeILi1ELi3EEEvPKhPtjjllllNS0_5DeqCbE+0x494>
	s_and_not1_b32 vcc_lo, exec_lo, s12                        // 000000273AF8: 916A0C7E
	s_cbranch_vccnz 65483                                      // 000000273AFC: BFA4FFCB <_ZN7halogen12_GLOBAL__N_116k_deq_q4cp_probeILi1ELi3EEEvPKhPtjjllllNS0_5DeqCbE+0x32c>
	s_branch 70                                                // 000000273B00: BFA00046 <_ZN7halogen12_GLOBAL__N_116k_deq_q4cp_probeILi1ELi3EEEvPKhPtjjllllNS0_5DeqCbE+0x51c>
	v_lshrrev_b32_e32 v4, 1, v3                                // 000000273B04: 32080681
	v_mad_u64_u32 v[7:8], null, s10, v6, s[6:7]                // 000000273B08: D6FE7C07 001A0C0A
	v_lshrrev_b32_e32 v13, 4, v3                               // 000000273B10: 321A0684
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000273B14: BF870093
	.long 0xd7001609                                           // 000000273B18: D7001609
	v_cndmask_b32_e32 v1, s20, v4, vcc_lo                      // 000000273B1C: 02020814
	v_add_co_ci_u32_e64 v10, null, s21, 0, s22                 // 000000273B20: D5207C0A 00590015
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000273B28: BF870193
	v_and_b32_e32 v4, 0xffffffe, v13                           // 000000273B2C: 36081AFF 0FFFFFFE
	v_mad_u64_u32 v[11:12], null, s11, v6, v[8:9]              // 000000273B34: D6FE7C0B 04220C0B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000273B3C: BF870193
	v_mad_u64_u32 v[8:9], null, s18, v6, v[9:10]               // 000000273B40: D6FE7C08 04260C12
	.long 0xd7006a0c                                           // 000000273B48: D7006A0C
	v_cndmask_b32_e32 v1, v7, v4, vcc_lo                       // 000000273B4C: 02020907
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000273B50: BF870191
	v_add_co_ci_u32_e64 v13, null, 0, v11, vcc_lo              // 000000273B54: D5207C0D 01AA1680
	v_mad_u64_u32 v[9:10], null, s19, v6, v[9:10]              // 000000273B5C: D6FE7C09 04260C13
	s_clause 0x1                                               // 000000273B64: BF850001
	global_load_d16_b16 v4, v[12:13], off                      // 000000273B68: DC820000 047C000C
	global_load_b32 v8, v[8:9], off                            // 000000273B70: DC520000 087C0008
	s_waitcnt vmcnt(1)                                         // 000000273B78: BF8907F7
	v_cvt_f32_f16_e32 v7, v4                                   // 000000273B7C: 7E0E1704
	s_or_b32 exec_lo, exec_lo, s13                             // 000000273B80: 8C7E0D7E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000273B84: BF870009
	s_and_b32 vcc_lo, exec_lo, s12                             // 000000273B88: 8B6A0C7E
	s_mov_b32 s12, -1                                          // 000000273B8C: BE8C00C1
	s_cbranch_vccz 65497                                       // 000000273B90: BFA3FFD9 <_ZN7halogen12_GLOBAL__N_116k_deq_q4cp_probeILi1ELi3EEEvPKhPtjjllllNS0_5DeqCbE+0x3f8>
	s_and_saveexec_b32 s12, s0                                 // 000000273B94: BE8C2000
	s_cbranch_execz 30                                         // 000000273B98: BFA5001E <_ZN7halogen12_GLOBAL__N_116k_deq_q4cp_probeILi1ELi3EEEvPKhPtjjllllNS0_5DeqCbE+0x514>
	v_mad_u64_u32 v[9:10], null, s4, v6, 0                     // 000000273B9C: D6FE7C09 02020C04
	s_waitcnt vmcnt(0)                                         // 000000273BA4: BF8903F7
	v_lshl_add_u32 v12, v7, 2, v8                              // 000000273BA8: D646000C 04210507
	v_mov_b32_e32 v4, v5                                       // 000000273BB0: 7E080305
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000273BB4: BF870211
	.long 0xd73c000d                                           // 000000273BB8: D73C000D
	v_cndmask_b32_e32 v1, 1, v3, vcc_lo                        // 000000273BBC: 02020681
	v_mad_u64_u32 v[10:11], null, s5, v6, v[10:11]             // 000000273BC0: D6FE7C0A 042A0C05
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000273BC8: BF870114
	v_sub_nc_u32_e32 v11, v12, v7                              // 000000273BCC: 4C160F0C
	.long 0xd73c0009                                           // 000000273BD0: D73C0009
	v_cndmask_b32_e32 v1, 1, v9, vcc_lo                        // 000000273BD4: 02021281
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000273BD8: BF870091
	.long 0xd7006a04                                           // 000000273BDC: D7006A04
	v_cndmask_b32_e32 v1, s14, v9, vcc_lo                      // 000000273BE0: 0202120E
	v_add_co_ci_u32_e64 v9, null, s15, v10, vcc_lo             // 000000273BE4: D5207C09 01AA140F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000273BEC: BF870194
	v_sub_nc_u32_e32 v10, v11, v7                              // 000000273BF0: 4C140F0B
	.long 0xd7006a0d                                           // 000000273BF4: D7006A0D
	v_cndmask_b32_e32 v1, v4, v13, vcc_lo                      // 000000273BF8: 02021B04
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000273BFC: BF870191
	v_add_co_ci_u32_e64 v14, null, v9, v14, vcc_lo             // 000000273C00: D5207C0E 01AA1D09
	v_sub_nc_u32_e32 v9, v10, v7                               // 000000273C08: 4C120F0A
	global_store_b128 v[13:14], v[9:12], off                   // 000000273C0C: DC760000 007C090D
	s_or_b32 exec_lo, exec_lo, s12                             // 000000273C14: 8C7E0C7E
	s_cbranch_execnz 65412                                     // 000000273C18: BFA6FF84 <_ZN7halogen12_GLOBAL__N_116k_deq_q4cp_probeILi1ELi3EEEvPKhPtjjllllNS0_5DeqCbE+0x32c>
	v_mad_u64_u32 v[10:11], null, s4, v6, 0                    // 000000273C1C: D6FE7C0A 02020C04
	s_waitcnt vmcnt(0)                                         // 000000273C24: BF8903F7
	v_add_nc_u32_e32 v8, v7, v8                                // 000000273C28: 4A101107
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000273C2C: BF870091
	v_dual_mov_b32 v4, v5 :: v_dual_add_nc_u32 v9, v8, v7      // 000000273C30: CA200105 04080F08
	.long 0xd73c0003                                           // 000000273C38: D73C0003
	v_cndmask_b32_e32 v1, 1, v3, vcc_lo                        // 000000273C3C: 02020681
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000273C40: BF870094
	v_mad_u64_u32 v[11:12], null, s5, v6, v[11:12]             // 000000273C44: D6FE7C0B 042E0C05
	.long 0xd73c000b                                           // 000000273C4C: D73C000B
	v_cndmask_b32_e32 v1, 1, v10, vcc_lo                       // 000000273C50: 02021481
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000273C54: BF870114
	v_add_nc_u32_e32 v10, v9, v7                               // 000000273C58: 4A140F09
	.long 0xd7006a06                                           // 000000273C5C: D7006A06
	v_cndmask_b32_e32 v1, s14, v11, vcc_lo                     // 000000273C60: 0202160E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000273C64: BF870191
	v_add_co_ci_u32_e64 v12, null, s15, v12, vcc_lo            // 000000273C68: D5207C0C 01AA180F
	v_add_nc_u32_e32 v11, v10, v7                              // 000000273C70: 4A160F0A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000273C74: BF870093
	.long 0xd7006a03                                           // 000000273C78: D7006A03
	v_cndmask_b32_e32 v1, v6, v3, vcc_lo                       // 000000273C7C: 02020706
	v_add_co_ci_u32_e64 v4, null, v12, v4, vcc_lo              // 000000273C80: D5207C04 01AA090C
	global_store_b128 v[3:4], v[8:11], off                     // 000000273C88: DC760000 007C0803
	s_branch 65382                                             // 000000273C90: BFA0FF66 <_ZN7halogen12_GLOBAL__N_116k_deq_q4cp_probeILi1ELi3EEEvPKhPtjjllllNS0_5DeqCbE+0x32c>
	s_endpgm                                                   // 000000273C94: BFB00000
		...

