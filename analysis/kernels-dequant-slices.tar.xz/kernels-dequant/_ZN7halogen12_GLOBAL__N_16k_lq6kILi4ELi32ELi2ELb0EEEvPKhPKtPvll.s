000000000059d800 <_ZN7halogen12_GLOBAL__N_16k_lq6kILi4ELi32ELi2ELb0EEEvPKhPKtPvll>:
; _ZN7halogen12_GLOBAL__N_16k_lq6kILi4ELi32ELi2ELb0EEEvPKhPKtPvll():
	s_load_b256 s[4:11], s[0:1], null                          // 00000059D800: F40C0100 F8000000
	s_mov_b32 s3, 0                                            // 00000059D808: BE830080
	v_bfe_u32 v5, v0, 5, 1                                     // 00000059D80C: D6100005 02050B00
	s_lshl_b64 s[14:15], s[2:3], 2                             // 00000059D814: 848E8202
	v_dual_mov_b32 v12, 0 :: v_dual_and_b32 v7, 31, v0         // 00000059D818: CA240080 0C06009F
	v_lshrrev_b32_e32 v6, 6, v0                                // 00000059D820: 320C0086
	v_dual_mov_b32 v10, 0 :: v_dual_mov_b32 v11, 0             // 00000059D824: CA100080 0A0A0080
	v_mov_b32_e32 v13, 0                                       // 00000059D82C: 7E1A0280
	s_waitcnt lgkmcnt(0)                                       // 00000059D830: BF89FC07
	s_ashr_i32 s12, s11, 31                                    // 00000059D834: 860C9F0B
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000059D838: BF870499
	s_lshr_b32 s12, s12, 28                                    // 00000059D83C: 850C9C0C
	s_add_u32 s12, s10, s12                                    // 00000059D840: 800C0C0A
	s_addc_u32 s13, s11, 0                                     // 00000059D844: 820D800B
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000059D848: BF870499
	s_lshr_b64 s[16:17], s[12:13], 4                           // 00000059D84C: 8590840C
	s_add_i32 s2, s16, 1                                       // 00000059D850: 81028110
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000059D854: BF870499
	s_lshr_b32 s12, s2, 31                                     // 00000059D858: 850C9F02
	s_add_i32 s2, s2, s12                                      // 00000059D85C: 81020C02
	s_load_b64 s[12:13], s[0:1], 0x20                          // 00000059D860: F4040300 F8000020
	s_ashr_i32 s2, s2, 1                                       // 00000059D868: 86028102
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000059D86C: BF870099
	.long 0xd72c0001                                           // 00000059D870: D72C0001
	v_cndmask_b32_e32 v1, s2, v5, vcc_lo                       // 00000059D874: 02020A02
	v_add_nc_u32_e32 v2, s2, v1                                // 00000059D878: 4A040202
	v_add_nc_u32_e32 v8, v1, v7                                // 00000059D87C: 4A100F01
	s_mov_b32 s2, exec_lo                                      // 00000059D880: BE82007E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000059D884: BF870092
	v_min_i32_e32 v9, s16, v2                                  // 00000059D888: 22120410
	.long 0xd4c1007e                                           // 00000059D88C: D4C1007E
	v_cndmask_b32_e32 v1, v8, v9, vcc_lo                       // 00000059D890: 02021308
	s_cbranch_execz 465                                        // 00000059D894: BFA501D1 <_ZN7halogen12_GLOBAL__N_16k_lq6kILi4ELi32ELi2ELb0EEEvPKhPKtPvll+0x7dc>
	.long 0xd7000001                                           // 00000059D898: D7000001
	v_cndmask_b32_e32 v1, s14, v6, vcc_lo                      // 00000059D89C: 02020C0E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000059D8A0: BF870001
	v_add_co_ci_u32_e64 v2, null, s15, 0, s0                   // 00000059D8A4: D5207C02 0001000F
	s_ashr_i32 s0, s11, 31                                     // 00000059D8AC: 86009F0B
	v_dual_mov_b32 v10, 0 :: v_dual_lshlrev_b32 v3, 4, v8      // 00000059D8B0: CA220080 0A021084
	s_lshr_b32 s0, s0, 24                                      // 00000059D8B8: 85009800
	s_waitcnt lgkmcnt(0)                                       // 00000059D8BC: BF89FC07
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[1:2]                  // 00000059D8C0: 7CA8020C
	s_add_u32 s0, s10, s0                                      // 00000059D8C4: 8000000A
	s_addc_u32 s1, s11, 0                                      // 00000059D8C8: 8201800B
	v_dual_mov_b32 v13, 0 :: v_dual_mov_b32 v12, 0             // 00000059D8CC: CA100080 0D0C0080
	s_ashr_i64 s[0:1], s[0:1], 8                               // 00000059D8D4: 86808800
	v_dual_cndmask_b32 v2, 0, v2 :: v_dual_cndmask_b32 v1, 0, v1// 00000059D8D8: CA520480 02000280
	s_mulk_i32 s1, 0xd2                                        // 00000059D8E0: B80100D2
	s_mul_hi_u32 s16, s0, 0xd2                                 // 00000059D8E4: 9690FF00 000000D2
	s_mulk_i32 s0, 0xd2                                        // 00000059D8EC: B80000D2
	s_add_i32 s16, s16, s1                                     // 00000059D8F0: 81100110
	.long 0xd72c000b                                           // 00000059D8F4: D72C000B
	v_cndmask_b32_e32 v1, s0, v2, vcc_lo                       // 00000059D8F8: 02020400
	.long 0xd72c0004                                           // 00000059D8FC: D72C0004
	v_cndmask_b32_e32 v1, s16, v1, vcc_lo                      // 00000059D900: 02020210
	v_mad_u64_u32 v[1:2], null, s0, v1, s[4:5]                 // 00000059D904: D6FE7C01 00120200
	s_mul_i32 s0, s11, 6                                       // 00000059D90C: 9600860B
	s_mul_hi_u32 s1, s10, 6                                    // 00000059D910: 9681860A
	s_lshl_b64 s[4:5], s[10:11], 2                             // 00000059D914: 8484820A
	s_add_i32 s16, s1, s0                                      // 00000059D918: 81100001
	s_mul_i32 s17, s10, 6                                      // 00000059D91C: 9611860A
	s_lshl_b64 s[10:11], s[10:11], 1                           // 00000059D920: 848A810A
	v_add3_u32 v2, v4, v2, v11                                 // 00000059D924: D6550002 042E0504
	v_mov_b32_e32 v11, 0                                       // 00000059D92C: 7E160280
	v_ashrrev_i32_e32 v14, 4, v8                               // 00000059D930: 341C1084
	v_bfe_u32 v16, v8, 3, 1                                    // 00000059D934: D6100010 02050708
	v_and_b32_e32 v17, 32, v3                                  // 00000059D93C: 362206A0
	v_and_b32_e32 v15, 15, v8                                  // 00000059D940: 361E108F
	v_and_b32_e32 v18, 16, v3                                  // 00000059D944: 36240690
	.long 0xd72c000e                                           // 00000059D948: D72C000E
	v_cndmask_b32_e32 v1, 0xd2, v14, vcc_lo                    // 00000059D94C: 02021CFF 000000D2
	v_lshlrev_b32_e32 v19, 6, v16                              // 00000059D954: 30262086
	v_lshlrev_b32_e32 v16, 5, v16                              // 00000059D958: 30202085
	v_ashrrev_i32_e32 v4, 31, v3                               // 00000059D95C: 3408069F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000059D960: BF8700A4
	v_ashrrev_i32_e32 v20, 31, v14                             // 00000059D964: 34281C9F
	.long 0xd7006a16                                           // 00000059D968: D7006A16
	v_cndmask_b32_e32 v1, v1, v14, vcc_lo                      // 00000059D96C: 02021D01
	v_add_co_ci_u32_e64 v23, null, v2, v20, vcc_lo             // 00000059D970: D5207C17 01AA2902
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000059D978: BF8701A2
	.long 0xd7006a13                                           // 00000059D97C: D7006A13
	v_cndmask_b32_e32 v1, v22, v19, vcc_lo                     // 00000059D980: 02022716
	.long 0xd7000010                                           // 00000059D984: D7000010
	v_cndmask_b32_e32 v1, v22, v16, vcc_lo                     // 00000059D988: 02022116
	v_add_co_ci_u32_e64 v20, null, 0, v23, vcc_lo              // 00000059D98C: D5207C14 01AA2E80
	s_delay_alu instid0(VALU_DEP_3)                            // 00000059D994: BF870003
	.long 0xd7006a13                                           // 00000059D998: D7006A13
	v_cndmask_b32_e32 v1, v19, v17, vcc_lo                     // 00000059D99C: 02022313
	v_add_co_ci_u32_e64 v17, null, 0, v23, s0                  // 00000059D9A0: D5207C11 00022E80
	.long 0xd700010e                                           // 00000059D9A8: D700010E
	v_cndmask_b32_e32 v1, v22, v15, vcc_lo                     // 00000059D9AC: 02021F16
	.long 0xd7000010                                           // 00000059D9B0: D7000010
	v_cndmask_b32_e32 v1, v16, v18, vcc_lo                     // 00000059D9B4: 02022510
	v_add_co_ci_u32_e64 v20, null, 0, v20, vcc_lo              // 00000059D9B8: D5207C14 01AA2880
	v_add_co_ci_u32_e64 v15, null, 0, v23, s1                  // 00000059D9C0: D5207C0F 00062E80
	v_add_co_ci_u32_e64 v17, null, 0, v17, s0                  // 00000059D9C8: D5207C11 00022280
	.long 0xd7006a12                                           // 00000059D9D0: D7006A12
	v_cndmask_b32_e32 v1, v19, v18, vcc_lo                     // 00000059D9D4: 02022513
	s_delay_alu instid0(VALU_DEP_1)                            // 00000059D9D8: BF870001
	v_add_co_ci_u32_e64 v19, null, 0, v20, vcc_lo              // 00000059D9DC: D5207C13 01AA2880
	s_clause 0x3                                               // 00000059D9E4: BF850003
	global_load_i8 v54, v[14:15], off offset:192               // 00000059D9E8: DC4600C0 367C000E
	global_load_b128 v[14:17], v[16:17], off offset:128        // 00000059D9F0: DC5E0080 0E7C0010
	global_load_b128 v[18:21], v[18:19], off                   // 00000059D9F8: DC5E0000 127C0012
	global_load_d16_b16 v55, v[22:23], off offset:208          // 00000059DA00: DC8200D0 377C0016
	.long 0xd73c0016                                           // 00000059DA08: D73C0016
	v_cndmask_b32_e32 v1, 1, v3, vcc_lo                        // 00000059DA0C: 02020681
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000059DA10: BF870091
	.long 0xd7006a26                                           // 00000059DA14: D7006A26
	v_cndmask_b32_e32 v1, s6, v22, vcc_lo                      // 00000059DA18: 02022C06
	v_add_co_ci_u32_e64 v39, null, s7, v23, vcc_lo             // 00000059DA1C: D5207C27 01AA2E07
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000059DA24: BF870092
	.long 0xd7006a2a                                           // 00000059DA28: D7006A2A
	v_cndmask_b32_e32 v0, v38, v10, vcc_lo                     // 00000059DA2C: 02001526
	v_add_co_ci_u32_e64 v43, null, s11, v39, vcc_lo            // 00000059DA30: D5207C2B 01AA4E0B
	.long 0xd7006a2e                                           // 00000059DA38: D7006A2E
	v_cndmask_b32_e32 v0, v38, v4, vcc_lo                      // 00000059DA3C: 02000926
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000059DA40: BF8700A1
	v_add_co_ci_u32_e64 v47, null, s5, v39, vcc_lo             // 00000059DA44: D5207C2F 01AA4E05
	.long 0xd7006a32                                           // 00000059DA4C: D7006A32
	v_cndmask_b32_e32 v0, v38, v17, vcc_lo                     // 00000059DA50: 02002326
	v_add_co_ci_u32_e64 v51, null, s16, v39, vcc_lo            // 00000059DA54: D5207C33 01AA4E10
	s_clause 0x7                                               // 00000059DA5C: BF850007
	global_load_b128 v[22:25], v[38:39], off                   // 00000059DA60: DC5E0000 167C0026
	global_load_b128 v[26:29], v[42:43], off                   // 00000059DA68: DC5E0000 1A7C002A
	global_load_b128 v[30:33], v[46:47], off                   // 00000059DA70: DC5E0000 1E7C002E
	global_load_b128 v[34:37], v[50:51], off                   // 00000059DA78: DC5E0000 227C0032
	global_load_b128 v[38:41], v[38:39], off offset:16         // 00000059DA80: DC5E0010 267C0026
	global_load_b128 v[42:45], v[42:43], off offset:16         // 00000059DA88: DC5E0010 2A7C002A
	global_load_b128 v[46:49], v[46:47], off offset:16         // 00000059DA90: DC5E0010 2E7C002E
	global_load_b128 v[50:53], v[50:51], off offset:16         // 00000059DA98: DC5E0010 327C0032
	s_waitcnt vmcnt(11)                                        // 00000059DAA0: BF892FF7
	v_cvt_f32_i32_e32 v54, v54                                 // 00000059DAA4: 7E6C0B36
	s_waitcnt vmcnt(8)                                         // 00000059DAA8: BF8923F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000059DAAC: BF870131
	v_fma_mix_f32 v54, v55, v54, neg(0) op_sel_hi:[1,0,0]      // 00000059DAB0: CC200036 8A026D37
	v_and_b32_e32 v56, 6, v8                                   // 00000059DAB8: 36701086
	v_and_b32_e32 v4, 4, v8                                    // 00000059DABC: 36081084
	v_or_b32_e32 v60, 16, v56                                  // 00000059DAC0: 38787090
	v_or_b32_e32 v58, 8, v56                                   // 00000059DAC4: 38747088
	s_delay_alu instid0(VALU_DEP_3)                            // 00000059DAC8: BF870003
	v_or_b32_e32 v59, 16, v4                                   // 00000059DACC: 38760890
	v_or_b32_e32 v62, 24, v56                                  // 00000059DAD0: 387C7098
	v_lshrrev_b32_e32 v63, v56, v14                            // 00000059DAD4: 327E1D38
	v_lshrrev_b32_e32 v65, v60, v14                            // 00000059DAD8: 32821D3C
	v_or_b32_e32 v57, 8, v4                                    // 00000059DADC: 38720888
	v_or_b32_e32 v61, 24, v4                                   // 00000059DAE0: 387A0898
	v_lshrrev_b32_e32 v64, v58, v14                            // 00000059DAE4: 32801D3A
	v_lshrrev_b32_e32 v14, v62, v14                            // 00000059DAE8: 321C1D3E
	v_lshrrev_b32_e32 v66, v56, v15                            // 00000059DAEC: 32841F38
	v_lshrrev_b32_e32 v67, v58, v15                            // 00000059DAF0: 32861F3A
	v_lshrrev_b32_e32 v68, v60, v15                            // 00000059DAF4: 32881F3C
	v_lshrrev_b32_e32 v15, v62, v15                            // 00000059DAF8: 321E1F3E
	v_lshrrev_b32_e32 v69, v56, v16                            // 00000059DAFC: 328A2138
	v_lshrrev_b32_e32 v70, v58, v16                            // 00000059DB00: 328C213A
	v_lshrrev_b32_e32 v71, v60, v16                            // 00000059DB04: 328E213C
	v_lshrrev_b32_e32 v16, v62, v16                            // 00000059DB08: 3220213E
	v_lshrrev_b32_e32 v56, v56, v17                            // 00000059DB0C: 32702338
	v_lshrrev_b32_e32 v58, v58, v17                            // 00000059DB10: 3274233A
	v_lshrrev_b32_e32 v60, v60, v17                            // 00000059DB14: 3278233C
	v_lshrrev_b32_e32 v17, v62, v17                            // 00000059DB18: 3222233E
	v_bfe_u32 v55, v18, v4, 4                                  // 00000059DB1C: D6100037 02120912
	v_lshlrev_b32_e32 v62, 4, v63                              // 00000059DB24: 307C7E84
	v_bfe_u32 v72, v18, v59, 4                                 // 00000059DB28: D6100048 02127712
	v_lshlrev_b32_e32 v65, 4, v65                              // 00000059DB30: 30828284
	v_bfe_u32 v63, v18, v57, 4                                 // 00000059DB34: D610003F 02127312
	v_bfe_u32 v74, v19, v57, 4                                 // 00000059DB3C: D610004A 02127313
	v_bfe_u32 v76, v20, v4, 4                                  // 00000059DB44: D610004C 02120914
	v_bfe_u32 v77, v20, v57, 4                                 // 00000059DB4C: D610004D 02127314
	v_bfe_u32 v78, v20, v59, 4                                 // 00000059DB54: D610004E 02127714
	v_bfe_u32 v20, v20, v61, 4                                 // 00000059DB5C: D6100014 02127B14
	v_lshlrev_b32_e32 v16, 4, v16                              // 00000059DB64: 30202084
	v_bfe_u32 v57, v21, v57, 4                                 // 00000059DB68: D6100039 02127315
	v_lshlrev_b32_e32 v58, 4, v58                              // 00000059DB70: 30747484
	v_and_or_b32 v55, v62, 48, v55                             // 00000059DB74: D6570037 04DD613E
	v_and_or_b32 v62, v65, 48, v72                             // 00000059DB7C: D657003E 05216141
	v_and_or_b32 v16, v16, 48, v20                             // 00000059DB84: D6570010 04516110
	v_lshlrev_b32_e32 v56, 4, v56                              // 00000059DB8C: 30707084
	v_and_or_b32 v20, v58, 48, v57                             // 00000059DB90: D6570014 04E5613A
	v_bfe_u32 v75, v19, v59, 4                                 // 00000059DB98: D610004B 02127713
	v_subrev_nc_u32_e32 v57, 32, v62                           // 00000059DBA0: 4E727CA0
	v_bfe_u32 v59, v21, v59, 4                                 // 00000059DBA4: D610003B 02127715
	v_lshlrev_b32_e32 v60, 4, v60                              // 00000059DBAC: 30787884
	v_subrev_nc_u32_e32 v20, 32, v20                           // 00000059DBB0: 4E2828A0
	v_lshlrev_b32_e32 v17, 4, v17                              // 00000059DBB4: 30222284
	v_cvt_f32_i32_e32 v57, v57                                 // 00000059DBB8: 7E720B39
	v_subrev_nc_u32_e32 v16, 32, v16                           // 00000059DBBC: 4E2020A0
	v_bfe_u32 v18, v18, v61, 4                                 // 00000059DBC0: D6100012 02127B12
	v_cvt_f32_i32_e32 v20, v20                                 // 00000059DBC8: 7E280B14
	v_lshlrev_b32_e32 v69, 4, v69                              // 00000059DBCC: 308A8A84
	v_mul_f32_e32 v57, v54, v57                                // 00000059DBD0: 10727336
	v_bfe_u32 v73, v19, v4, 4                                  // 00000059DBD4: D6100049 02120913
	v_bfe_u32 v4, v21, v4, 4                                   // 00000059DBDC: D6100004 02120915
	v_bfe_u32 v19, v19, v61, 4                                 // 00000059DBE4: D6100013 02127B13
	v_bfe_u32 v21, v21, v61, 4                                 // 00000059DBEC: D6100015 02127B15
	v_mul_f32_e32 v20, v54, v20                                // 00000059DBF4: 10282936
	v_lshlrev_b32_e32 v66, 4, v66                              // 00000059DBF8: 30848484
	v_and_or_b32 v4, v56, 48, v4                               // 00000059DBFC: D6570004 04116138
	v_and_or_b32 v56, v60, 48, v59                             // 00000059DC04: D6570038 04ED613C
	v_and_or_b32 v17, v17, 48, v21                             // 00000059DC0C: D6570011 04556111
	v_lshlrev_b32_e32 v68, 4, v68                              // 00000059DC14: 30888884
	v_lshlrev_b32_e32 v70, 4, v70                              // 00000059DC18: 308C8C84
	v_subrev_nc_u32_e32 v4, 32, v4                             // 00000059DC1C: 4E0808A0
	v_subrev_nc_u32_e32 v56, 32, v56                           // 00000059DC20: 4E7070A0
	v_subrev_nc_u32_e32 v17, 32, v17                           // 00000059DC24: 4E2222A0
	v_cvt_f32_i32_e32 v16, v16                                 // 00000059DC28: 7E200B10
	v_lshlrev_b32_e32 v67, 4, v67                              // 00000059DC2C: 30868684
	v_cvt_f32_i32_e32 v4, v4                                   // 00000059DC30: 7E080B04
	v_lshlrev_b32_e32 v15, 4, v15                              // 00000059DC34: 301E1E84
	v_cvt_f32_i32_e32 v56, v56                                 // 00000059DC38: 7E700B38
	v_lshlrev_b32_e32 v71, 4, v71                              // 00000059DC3C: 308E8E84
	v_cvt_f32_i32_e32 v17, v17                                 // 00000059DC40: 7E220B11
	v_mul_f32_e32 v4, v54, v4                                  // 00000059DC44: 10080936
	v_and_or_b32 v15, v15, 48, v19                             // 00000059DC48: D657000F 044D610F
	v_and_or_b32 v19, v69, 48, v76                             // 00000059DC50: D6570013 05316145
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000059DC58: BF870234
	v_dual_mul_f32 v17, v54, v17 :: v_dual_lshlrev_b32 v14, 4, v14// 00000059DC5C: C8E22336 110E1C84
	v_and_or_b32 v65, v70, 48, v77                             // 00000059DC64: D6570041 05356146
	v_subrev_nc_u32_e32 v21, 32, v55                           // 00000059DC6C: 4E2A6EA0
	v_subrev_nc_u32_e32 v19, 32, v19                           // 00000059DC70: 4E2626A0
	s_delay_alu instid0(VALU_DEP_4)                            // 00000059DC74: BF870004
	v_and_or_b32 v14, v14, 48, v18                             // 00000059DC78: D657000E 0449610E
	v_and_or_b32 v18, v66, 48, v73                             // 00000059DC80: D6570012 05256142
	v_mul_f32_e32 v16, v54, v16                                // 00000059DC88: 10202136
	v_mul_f32_e32 v56, v54, v56                                // 00000059DC8C: 10707136
	v_cvt_f32_i32_e32 v19, v19                                 // 00000059DC90: 7E260B13
	v_lshlrev_b32_e32 v64, 4, v64                              // 00000059DC94: 30808084
	v_and_or_b32 v66, v71, 48, v78                             // 00000059DC98: D6570042 05396147
	v_subrev_nc_u32_e32 v14, 32, v14                           // 00000059DCA0: 4E1C1CA0
	v_subrev_nc_u32_e32 v18, 32, v18                           // 00000059DCA4: 4E2424A0
	v_mul_f32_e32 v19, v54, v19                                // 00000059DCA8: 10262736
	v_and_or_b32 v61, v64, 48, v63                             // 00000059DCAC: D657003D 04FD6140
	v_and_or_b32 v63, v67, 48, v74                             // 00000059DCB4: D657003F 05296143
	v_and_or_b32 v64, v68, 48, v75                             // 00000059DCBC: D6570040 052D6144
	v_subrev_nc_u32_e32 v15, 32, v15                           // 00000059DCC4: 4E1E1EA0
	v_subrev_nc_u32_e32 v60, 32, v65                           // 00000059DCC8: 4E7882A0
	v_subrev_nc_u32_e32 v55, 32, v61                           // 00000059DCCC: 4E6E7AA0
	v_subrev_nc_u32_e32 v58, 32, v63                           // 00000059DCD0: 4E747EA0
	v_subrev_nc_u32_e32 v59, 32, v64                           // 00000059DCD4: 4E7680A0
	v_subrev_nc_u32_e32 v61, 32, v66                           // 00000059DCD8: 4E7A84A0
	v_cvt_f32_i32_e32 v21, v21                                 // 00000059DCDC: 7E2A0B15
	v_cvt_f32_i32_e32 v55, v55                                 // 00000059DCE0: 7E6E0B37
	v_cvt_f32_i32_e32 v14, v14                                 // 00000059DCE4: 7E1C0B0E
	v_cvt_f32_i32_e32 v18, v18                                 // 00000059DCE8: 7E240B12
	v_cvt_f32_i32_e32 v58, v58                                 // 00000059DCEC: 7E740B3A
	v_cvt_f32_i32_e32 v59, v59                                 // 00000059DCF0: 7E760B3B
	v_cvt_f32_i32_e32 v15, v15                                 // 00000059DCF4: 7E1E0B0F
	v_cvt_f32_i32_e32 v60, v60                                 // 00000059DCF8: 7E780B3C
	v_cvt_f32_i32_e32 v61, v61                                 // 00000059DCFC: 7E7A0B3D
	v_mul_f32_e32 v21, v54, v21                                // 00000059DD00: 102A2B36
	v_dual_mul_f32 v55, v54, v55 :: v_dual_add_nc_u32 v8, 32, v8// 00000059DD04: C8E06F36 370810A0
	v_mul_f32_e32 v15, v54, v15                                // 00000059DD0C: 101E1F36
	v_mul_f32_e32 v14, v54, v14                                // 00000059DD10: 101C1D36
	v_mul_f32_e32 v18, v54, v18                                // 00000059DD14: 10242536
	v_mul_f32_e32 v58, v54, v58                                // 00000059DD18: 10747536
	v_mul_f32_e32 v59, v54, v59                                // 00000059DD1C: 10767736
	v_mul_f32_e32 v60, v54, v60                                // 00000059DD20: 10787936
	v_mul_f32_e32 v61, v54, v61                                // 00000059DD24: 107A7B36
	v_bfe_u32 v54, v21, 16, 1                                  // 00000059DD28: D6100036 02052115
	v_bfe_u32 v62, v55, 16, 1                                  // 00000059DD30: D610003E 02052137
	v_bfe_u32 v63, v57, 16, 1                                  // 00000059DD38: D610003F 02052139
	v_bfe_u32 v64, v14, 16, 1                                  // 00000059DD40: D6100040 0205210E
	v_bfe_u32 v65, v18, 16, 1                                  // 00000059DD48: D6100041 02052112
	v_add3_u32 v21, v21, v54, 0x7fff                           // 00000059DD50: D6550015 03FE6D15 00007FFF
	v_add3_u32 v54, v55, v62, 0x7fff                           // 00000059DD5C: D6550036 03FE7D37 00007FFF
	v_add3_u32 v55, v57, v63, 0x7fff                           // 00000059DD68: D6550037 03FE7F39 00007FFF
	v_bfe_u32 v66, v58, 16, 1                                  // 00000059DD74: D6100042 0205213A
	v_add3_u32 v14, v14, v64, 0x7fff                           // 00000059DD7C: D655000E 03FE810E 00007FFF
	.long 0x7e6c3995                                           // 00000059DD88: 7E6C3995
	v_bfe_u32 v67, v59, 16, 1                                  // 00000059DD8C: D6100043 0205213B
	v_add3_u32 v18, v18, v65, 0x7fff                           // 00000059DD94: D6550012 03FE8312 00007FFF
	.long 0x7e1c39b7                                           // 00000059DDA0: 7E1C39B7
	v_bfe_u32 v68, v15, 16, 1                                  // 00000059DDA4: D6100044 0205210F
	s_waitcnt vmcnt(7)                                         // 00000059DDAC: BF891FF7
	v_dot2_f32_bf16 v21, v22, v54, 0                           // 00000059DDB0: CC1A4015 1A026D16
	s_waitcnt vmcnt(6)                                         // 00000059DDB8: BF891BF7
	v_dot2_f32_bf16 v22, v26, v54, 0                           // 00000059DDBC: CC1A4016 1A026D1A
	s_waitcnt vmcnt(5)                                         // 00000059DDC4: BF8917F7
	v_dot2_f32_bf16 v26, v30, v54, 0                           // 00000059DDC8: CC1A401A 1A026D1E
	s_waitcnt vmcnt(4)                                         // 00000059DDD0: BF8913F7
	v_dot2_f32_bf16 v30, v34, v54, 0                           // 00000059DDD4: CC1A401E 1A026D22
	v_add3_u32 v57, v58, v66, 0x7fff                           // 00000059DDDC: D6550039 03FE853A 00007FFF
	v_bfe_u32 v69, v19, 16, 1                                  // 00000059DDE8: D6100045 02052113
	v_add3_u32 v58, v59, v67, 0x7fff                           // 00000059DDF0: D655003A 03FE873B 00007FFF
	.long 0x7e723992                                           // 00000059DDFC: 7E723992
	v_dot2_f32_bf16 v18, v23, v14, v21                         // 00000059DE00: CC1A4012 1C561D17
	v_dot2_f32_bf16 v21, v27, v14, v22                         // 00000059DE08: CC1A4015 1C5A1D1B
	v_dot2_f32_bf16 v22, v31, v14, v26                         // 00000059DE10: CC1A4016 1C6A1D1F
	v_dot2_f32_bf16 v14, v35, v14, v30                         // 00000059DE18: CC1A400E 1C7A1D23
	v_bfe_u32 v70, v60, 16, 1                                  // 00000059DE20: D6100046 0205213C
	v_add3_u32 v15, v15, v68, 0x7fff                           // 00000059DE28: D655000F 03FE890F 00007FFF
	v_bfe_u32 v71, v61, 16, 1                                  // 00000059DE34: D6100047 0205213D
	v_add3_u32 v19, v19, v69, 0x7fff                           // 00000059DE3C: D6550013 03FE8B13 00007FFF
	.long 0x7e1e39ba                                           // 00000059DE48: 7E1E39BA
	v_dot2_f32_bf16 v18, v24, v57, v18                         // 00000059DE4C: CC1A4012 1C4A7318
	v_dot2_f32_bf16 v21, v28, v57, v21                         // 00000059DE54: CC1A4015 1C56731C
	v_dot2_f32_bf16 v22, v32, v57, v22                         // 00000059DE5C: CC1A4016 1C5A7320
	v_dot2_f32_bf16 v14, v36, v57, v14                         // 00000059DE64: CC1A400E 1C3A7324
	v_bfe_u32 v72, v16, 16, 1                                  // 00000059DE6C: D6100048 02052110
	v_add3_u32 v59, v60, v70, 0x7fff                           // 00000059DE74: D655003B 03FE8D3C 00007FFF
	v_bfe_u32 v73, v4, 16, 1                                   // 00000059DE80: D6100049 02052104
	v_add3_u32 v60, v61, v71, 0x7fff                           // 00000059DE88: D655003C 03FE8F3D 00007FFF
	.long 0x7e763993                                           // 00000059DE94: 7E763993
	v_dot2_f32_bf16 v18, v25, v15, v18                         // 00000059DE98: CC1A4012 1C4A1F19
	v_dot2_f32_bf16 v19, v29, v15, v21                         // 00000059DEA0: CC1A4013 1C561F1D
	v_dot2_f32_bf16 v21, v33, v15, v22                         // 00000059DEA8: CC1A4015 1C5A1F21
	v_dot2_f32_bf16 v14, v37, v15, v14                         // 00000059DEB0: CC1A400E 1C3A1F25
	v_bfe_u32 v74, v20, 16, 1                                  // 00000059DEB8: D610004A 02052114
	v_add3_u32 v16, v16, v72, 0x7fff                           // 00000059DEC0: D6550010 03FE9110 00007FFF
	v_bfe_u32 v75, v56, 16, 1                                  // 00000059DECC: D610004B 02052138
	v_add3_u32 v4, v4, v73, 0x7fff                             // 00000059DED4: D6550004 03FE9304 00007FFF
	.long 0x7e2039bc                                           // 00000059DEE0: 7E2039BC
	s_waitcnt vmcnt(3)                                         // 00000059DEE4: BF890FF7
	v_dot2_f32_bf16 v15, v38, v59, v18                         // 00000059DEE8: CC1A400F 1C4A7726
	s_waitcnt vmcnt(2)                                         // 00000059DEF0: BF890BF7
	v_dot2_f32_bf16 v18, v42, v59, v19                         // 00000059DEF4: CC1A4012 1C4E772A
	s_waitcnt vmcnt(1)                                         // 00000059DEFC: BF8907F7
	v_dot2_f32_bf16 v19, v46, v59, v21                         // 00000059DF00: CC1A4013 1C56772E
	s_waitcnt vmcnt(0)                                         // 00000059DF08: BF8903F7
	v_dot2_f32_bf16 v14, v50, v59, v14                         // 00000059DF0C: CC1A400E 1C3A7732
	v_bfe_u32 v76, v17, 16, 1                                  // 00000059DF14: D610004C 02052111
	v_add3_u32 v20, v20, v74, 0x7fff                           // 00000059DF1C: D6550014 03FE9514 00007FFF
	v_add3_u32 v56, v56, v75, 0x7fff                           // 00000059DF28: D6550038 03FE9738 00007FFF
	.long 0x7e283984                                           // 00000059DF34: 7E283984
	v_dot2_f32_bf16 v4, v39, v16, v15                          // 00000059DF38: CC1A4004 1C3E2127
	v_dot2_f32_bf16 v15, v43, v16, v18                         // 00000059DF40: CC1A400F 1C4A212B
	v_dot2_f32_bf16 v18, v47, v16, v19                         // 00000059DF48: CC1A4012 1C4E212F
	v_dot2_f32_bf16 v14, v51, v16, v14                         // 00000059DF50: CC1A400E 1C3A2133
	v_add3_u32 v17, v17, v76, 0x7fff                           // 00000059DF58: D6550011 03FE9911 00007FFF
	.long 0x7e2239b8                                           // 00000059DF64: 7E2239B8
	v_dot2_f32_bf16 v4, v40, v20, v4                           // 00000059DF68: CC1A4004 1C122928
	v_dot2_f32_bf16 v15, v44, v20, v15                         // 00000059DF70: CC1A400F 1C3E292C
	v_dot2_f32_bf16 v16, v48, v20, v18                         // 00000059DF78: CC1A4010 1C4A2930
	v_dot2_f32_bf16 v14, v52, v20, v14                         // 00000059DF80: CC1A400E 1C3A2934
	v_cmp_ge_i32_e32 vcc_lo, v8, v9                            // 00000059DF88: 7C8C1308
	v_dot2_f32_bf16 v4, v41, v17, v4                           // 00000059DF8C: CC1A4004 1C122329
	v_dot2_f32_bf16 v15, v45, v17, v15                         // 00000059DF94: CC1A400F 1C3E232D
	v_dot2_f32_bf16 v16, v49, v17, v16                         // 00000059DF9C: CC1A4010 1C422331
	v_dot2_f32_bf16 v14, v53, v17, v14                         // 00000059DFA4: CC1A400E 1C3A2335
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000059DFAC: BF870194
	v_dual_add_f32 v10, v10, v4 :: v_dual_add_nc_u32 v3, 0x200, v3// 00000059DFB0: C920090A 0A0206FF 00000200
	v_dual_add_f32 v13, v13, v15 :: v_dual_add_f32 v12, v12, v16// 00000059DFBC: C9081F0D 0D0C210C
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000059DFC4: BF8704A3
	v_add_f32_e32 v11, v11, v14                                // 00000059DFC8: 06161D0B
	s_or_b32 s3, vcc_lo, s3                                    // 00000059DFCC: 8C03036A
	s_and_not1_b32 exec_lo, exec_lo, s3                        // 00000059DFD0: 917E037E
	s_cbranch_execnz 65110                                     // 00000059DFD4: BFA6FE56 <_ZN7halogen12_GLOBAL__N_16k_lq6kILi4ELi32ELi2ELb0EEEvPKhPKtPvll+0x130>
	s_or_b32 exec_lo, exec_lo, s3                              // 00000059DFD8: 8C7E037E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000059DFDC: BF8700B9
	s_or_b32 exec_lo, exec_lo, s2                              // 00000059DFE0: 8C7E027E
	.long 0xd71f0001                                           // 00000059DFE4: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 00000059DFE8: 020100C1
	s_mov_b32 s0, exec_lo                                      // 00000059DFEC: BE80007E
	v_xor_b32_e32 v2, 16, v1                                   // 00000059DFF0: 3A040290
	v_xor_b32_e32 v9, 8, v1                                    // 00000059DFF4: 3A120288
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000059DFF8: BF8701A2
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 00000059DFFC: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 00000059E000: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v9                            // 00000059E004: 7C9812A0
	v_cndmask_b32_e32 v9, v1, v9, vcc_lo                       // 00000059E008: 02121301
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000059E00C: BF870211
	v_lshlrev_b32_e32 v9, 2, v9                                // 00000059E010: 30121282
	v_lshlrev_b32_e32 v2, 2, v2                                // 00000059E014: 30040482
	ds_bpermute_b32 v3, v2, v10                                // 00000059E018: DACC0000 03000A02
	s_waitcnt lgkmcnt(0)                                       // 00000059E020: BF89FC07
	v_add_f32_e32 v3, v10, v3                                  // 00000059E024: 0606070A
	ds_bpermute_b32 v4, v2, v13                                // 00000059E028: DACC0000 04000D02
	ds_bpermute_b32 v8, v2, v12                                // 00000059E030: DACC0000 08000C02
	ds_bpermute_b32 v2, v2, v11                                // 00000059E038: DACC0000 02000B02
	ds_bpermute_b32 v10, v9, v3                                // 00000059E040: DACC0000 0A000309
	s_waitcnt lgkmcnt(3)                                       // 00000059E048: BF89FC37
	v_add_f32_e32 v4, v13, v4                                  // 00000059E04C: 0608090D
	v_xor_b32_e32 v13, 4, v1                                   // 00000059E050: 3A1A0284
	s_waitcnt lgkmcnt(2)                                       // 00000059E054: BF89FC27
	v_add_f32_e32 v8, v12, v8                                  // 00000059E058: 0610110C
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000059E05C: BF8700D2
	v_cmp_gt_u32_e32 vcc_lo, 32, v13                           // 00000059E060: 7C981AA0
	s_waitcnt lgkmcnt(1)                                       // 00000059E064: BF89FC17
	v_add_f32_e32 v2, v11, v2                                  // 00000059E068: 0604050B
	ds_bpermute_b32 v12, v9, v8                                // 00000059E06C: DACC0000 0C000809
	v_cndmask_b32_e32 v13, v1, v13, vcc_lo                     // 00000059E074: 021A1B01
	v_lshlrev_b32_e32 v13, 2, v13                              // 00000059E078: 301A1A82
	ds_bpermute_b32 v11, v9, v4                                // 00000059E07C: DACC0000 0B000409
	ds_bpermute_b32 v9, v9, v2                                 // 00000059E084: DACC0000 09000209
	s_waitcnt lgkmcnt(2)                                       // 00000059E08C: BF89FC27
	v_dual_add_f32 v3, v3, v10 :: v_dual_add_f32 v8, v8, v12   // 00000059E090: C9081503 03081908
	s_waitcnt lgkmcnt(1)                                       // 00000059E098: BF89FC17
	v_add_f32_e32 v4, v4, v11                                  // 00000059E09C: 06081704
	s_waitcnt lgkmcnt(0)                                       // 00000059E0A0: BF89FC07
	v_add_f32_e32 v2, v2, v9                                   // 00000059E0A4: 06041302
	ds_bpermute_b32 v9, v13, v3                                // 00000059E0A8: DACC0000 0900030D
	ds_bpermute_b32 v11, v13, v8                               // 00000059E0B0: DACC0000 0B00080D
	ds_bpermute_b32 v10, v13, v4                               // 00000059E0B8: DACC0000 0A00040D
	ds_bpermute_b32 v12, v13, v2                               // 00000059E0C0: DACC0000 0C00020D
	v_xor_b32_e32 v13, 2, v1                                   // 00000059E0C8: 3A1A0282
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000059E0CC: BF8700A1
	v_cmp_gt_u32_e32 vcc_lo, 32, v13                           // 00000059E0D0: 7C981AA0
	v_cndmask_b32_e32 v13, v1, v13, vcc_lo                     // 00000059E0D4: 021A1B01
	v_lshlrev_b32_e32 v13, 2, v13                              // 00000059E0D8: 301A1A82
	s_waitcnt lgkmcnt(2)                                       // 00000059E0DC: BF89FC27
	v_dual_add_f32 v3, v3, v9 :: v_dual_add_f32 v8, v8, v11    // 00000059E0E0: C9081303 03081708
	s_waitcnt lgkmcnt(1)                                       // 00000059E0E8: BF89FC17
	v_add_f32_e32 v4, v4, v10                                  // 00000059E0EC: 06081504
	ds_bpermute_b32 v11, v13, v8                               // 00000059E0F0: DACC0000 0B00080D
	ds_bpermute_b32 v10, v13, v4                               // 00000059E0F8: DACC0000 0A00040D
	s_waitcnt lgkmcnt(2)                                       // 00000059E100: BF89FC27
	v_add_f32_e32 v9, v2, v12                                  // 00000059E104: 06121902
	ds_bpermute_b32 v2, v13, v3                                // 00000059E108: DACC0000 0200030D
	ds_bpermute_b32 v12, v13, v9                               // 00000059E110: DACC0000 0C00090D
	v_xor_b32_e32 v13, 1, v1                                   // 00000059E118: 3A1A0281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000059E11C: BF8700A1
	v_cmp_gt_u32_e32 vcc_lo, 32, v13                           // 00000059E120: 7C981AA0
	v_cndmask_b32_e32 v1, v1, v13, vcc_lo                      // 00000059E124: 02021B01
	v_lshlrev_b32_e32 v13, 2, v1                               // 00000059E128: 301A0282
	s_waitcnt lgkmcnt(1)                                       // 00000059E12C: BF89FC17
	v_add_f32_e32 v1, v3, v2                                   // 00000059E130: 06020503
	v_add_f32_e32 v2, v4, v10                                  // 00000059E134: 06041504
	s_waitcnt lgkmcnt(0)                                       // 00000059E138: BF89FC07
	v_dual_add_f32 v3, v8, v11 :: v_dual_add_f32 v8, v9, v12   // 00000059E13C: C9081708 03081909
	ds_bpermute_b32 v4, v13, v1                                // 00000059E144: DACC0000 0400010D
	ds_bpermute_b32 v9, v13, v2                                // 00000059E14C: DACC0000 0900020D
	ds_bpermute_b32 v10, v13, v3                               // 00000059E154: DACC0000 0A00030D
	ds_bpermute_b32 v11, v13, v8                               // 00000059E15C: DACC0000 0B00080D
	v_cmpx_eq_u32_e32 0, v7                                    // 00000059E164: 7D940E80
	s_cbranch_execz 12                                         // 00000059E168: BFA5000C <_ZN7halogen12_GLOBAL__N_16k_lq6kILi4ELi32ELi2ELb0EEEvPKhPKtPvll+0x99c>
	s_waitcnt lgkmcnt(1)                                       // 00000059E16C: BF89FC17
	v_dual_add_f32 v10, v3, v10 :: v_dual_lshlrev_b32 v5, 4, v5// 00000059E170: C9221503 0A040A84
	s_waitcnt lgkmcnt(0)                                       // 00000059E178: BF89FC07
	v_dual_add_f32 v11, v8, v11 :: v_dual_add_f32 v8, v1, v4   // 00000059E17C: C9081708 0B080901
	v_add_f32_e32 v9, v2, v9                                   // 00000059E184: 06121302
	s_delay_alu instid0(VALU_DEP_3)                            // 00000059E188: BF870003
	v_lshl_or_b32 v1, v6, 5, v5                                // 00000059E18C: D6560001 04150B06
	ds_store_b128 v1, v[8:11]                                  // 00000059E194: DB7C0000 00000801
	s_or_b32 exec_lo, exec_lo, s0                              // 00000059E19C: 8C7E007E
	v_lshrrev_b32_e32 v3, 2, v0                                // 00000059E1A0: 32060082
	v_mov_b32_e32 v2, s15                                      // 00000059E1A4: 7E04020F
	.long 0xd44c0000                                           // 00000059E1A8: D44C0000
	v_cndmask_b32_e32 v1, 16, v0, vcc_lo                       // 00000059E1AC: 02020090
	s_waitcnt lgkmcnt(0)                                       // 00000059E1B0: BF89FC07
	s_barrier                                                  // 00000059E1B4: BFBD0000
	v_or_b32_e32 v1, s14, v3                                   // 00000059E1B8: 3802060E
	buffer_gl0_inv                                             // 00000059E1BC: E0AC0000 00000000
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[1:2]                  // 00000059E1C4: 7CA8020C
	s_and_b32 s0, s0, vcc_lo                                   // 00000059E1C8: 8B006A00
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000059E1CC: BF870009
	s_and_saveexec_b32 s1, s0                                  // 00000059E1D0: BE812000
	s_cbranch_execz 37                                         // 00000059E1D4: BFA50025 <_ZN7halogen12_GLOBAL__N_16k_lq6kILi4ELi32ELi2ELb0EEEvPKhPKtPvll+0xa6c>
	v_and_b32_e32 v0, 3, v0                                    // 00000059E1D8: 36000083
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000059E1DC: BF870091
	v_lshlrev_b32_e32 v4, 2, v0                                // 00000059E1E0: 30080082
	v_lshl_or_b32 v3, v3, 5, v4                                // 00000059E1E4: D6560003 04110B03
	ds_load_2addr_b32 v[6:7], v3 offset1:4                     // 00000059E1EC: D8DC0400 06000003
	v_mad_u64_u32 v[3:4], null, s12, v0, 0                     // 00000059E1F4: D6FE7C03 0202000C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000059E1FC: BF870091
	v_mad_u64_u32 v[4:5], null, s13, v0, v[4:5]                // 00000059E200: D6FE7C04 0412000D
	.long 0xd73c0003                                           // 00000059E208: D73C0003
	v_cndmask_b32_e32 v1, 1, v3, vcc_lo                        // 00000059E20C: 02020681
	s_waitcnt lgkmcnt(0)                                       // 00000059E210: BF89FC07
	v_add_f32_e32 v0, 0, v6                                    // 00000059E214: 06000C80
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000059E218: BF870112
	.long 0xd7006a03                                           // 00000059E21C: D7006A03
	v_cndmask_b32_e32 v1, s8, v3, vcc_lo                       // 00000059E220: 02020608
	v_add_f32_e32 v5, v0, v7                                   // 00000059E224: 060A0F00
	.long 0xd73c0000                                           // 00000059E228: D73C0000
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 00000059E22C: 02020281
	v_add_co_ci_u32_e64 v4, null, s9, v4, vcc_lo               // 00000059E230: D5207C04 01AA0809
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000059E238: BF870193
	v_bfe_u32 v2, v5, 16, 1                                    // 00000059E23C: D6100002 02052105
	.long 0xd7006a00                                           // 00000059E244: D7006A00
	v_cndmask_b32_e32 v1, v3, v0, vcc_lo                       // 00000059E248: 02020103
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000059E24C: BF870191
	v_add_co_ci_u32_e64 v1, null, v4, v1, vcc_lo               // 00000059E250: D5207C01 01AA0304
	v_add3_u32 v2, v5, v2, 0x7fff                              // 00000059E258: D6550002 03FE0505 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off                    // 00000059E264: DC960000 007C0200
	s_endpgm                                                   // 00000059E26C: BFB00000
		...

