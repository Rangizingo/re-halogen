0000000000829e00 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi2ELb0ELi2ELi0EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi2ELb0ELi2ELi0EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 000000829E00: F4100100 F8000000
	s_ashr_i32 s3, s2, 31                                      // 000000829E08: 86039F02
	v_lshrrev_b32_e32 v2, 2, v0                                // 000000829E0C: 32040082
	s_lshl_b64 s[2:3], s[2:3], 2                               // 000000829E10: 84828202
	v_and_b32_e32 v1, 15, v0                                   // 000000829E14: 3602008F
	v_mov_b32_e32 v5, 0                                        // 000000829E18: 7E0A0280
	v_lshrrev_b32_e32 v14, 6, v0                               // 000000829E1C: 321C0086
	v_and_b32_e32 v2, 60, v2                                   // 000000829E20: 360404BC
	s_delay_alu instid0(VALU_DEP_4)                            // 000000829E24: BF870004
	v_dual_mov_b32 v6, 0 :: v_dual_lshlrev_b32 v1, 2, v1       // 000000829E28: CA220080 06000282
	v_bfe_u32 v15, v0, 5, 1                                    // 000000829E30: D610000F 02050B00
	v_dual_mov_b32 v17, 0 :: v_dual_and_b32 v16, 31, v0        // 000000829E38: CA240080 1110009F
	.long 0x7f103880                                           // 000000829E40: 7F103880
	s_waitcnt lgkmcnt(0)                                       // 000000829E44: BF89FC07
	s_clause 0x1                                               // 000000829E48: BF850001
	global_load_b32 v3, v1, s[4:5]                             // 000000829E4C: DC520000 03040001
	global_load_b32 v4, v2, s[4:5]                             // 000000829E54: DC520000 04040002
	v_mov_b32_e32 v2, s3                                       // 000000829E5C: 7E040203
	v_or_b32_e32 v1, s2, v14                                   // 000000829E60: 38021C02
	s_add_u32 s0, s4, s14                                      // 000000829E64: 80000E04
	s_addc_u32 s1, s5, s15                                     // 000000829E68: 82010F05
	s_lshr_b32 s14, s11, 31                                    // 000000829E6C: 850E9F0B
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000829E70: BF870009
	s_add_u32 s14, s10, s14                                    // 000000829E74: 800E0E0A
	s_addc_u32 s15, s11, 0                                     // 000000829E78: 820F800B
	s_ashr_i32 s20, s11, 31                                    // 000000829E7C: 86149F0B
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[1:2]                  // 000000829E80: 7CA8020C
	s_lshr_b32 s20, s20, 27                                    // 000000829E84: 85149B14
	s_ashr_i64 s[14:15], s[14:15], 1                           // 000000829E88: 868E810E
	s_add_u32 s20, s10, s20                                    // 000000829E8C: 8014140A
	s_addc_u32 s21, s11, 0                                     // 000000829E90: 8215800B
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 000000829E94: 02020280
	s_lshr_b64 s[20:21], s[20:21], 5                           // 000000829E98: 85948514
	v_cndmask_b32_e64 v7, 0, s3, vcc_lo                        // 000000829E9C: D5010007 01A80680
	s_add_i32 s21, s20, 1                                      // 000000829EA4: 81158114
	s_delay_alu instid0(VALU_DEP_2)                            // 000000829EA8: BF870002
	.long 0xd72c0002                                           // 000000829EAC: D72C0002
	v_cndmask_b32_e32 v1, s19, v1, vcc_lo                      // 000000829EB0: 02020213
	s_lshr_b32 s19, s21, 31                                    // 000000829EB4: 85139F15
	.long 0xd72c000d                                           // 000000829EB8: D72C000D
	v_cndmask_b32_e32 v0, v1, v15, vcc_lo                      // 000000829EBC: 02001F01
	s_add_i32 s21, s21, s19                                    // 000000829EC0: 81151315
	v_mad_u64_u32 v[9:10], null, v1, s14, s[0:1]               // 000000829EC4: D6FE7C09 00001D01
	s_ashr_i32 s15, s21, 1                                     // 000000829ECC: 860F8115
	s_add_u32 s0, s4, s16                                      // 000000829ED0: 80001004
	.long 0xd72c0012                                           // 000000829ED4: D72C0012
	v_cndmask_b32_e32 v1, s15, v15, vcc_lo                     // 000000829ED8: 02021E0F
	s_addc_u32 s1, s5, s17                                     // 000000829EDC: 82011105
	.long 0xd72c0014                                           // 000000829EE0: D72C0014
	v_cndmask_b32_e32 v0, v7, v14, vcc_lo                      // 000000829EE4: 02001D07
	.long 0xd72c0015                                           // 000000829EE8: D72C0015
	v_cndmask_b32_e32 v1, s18, v7, vcc_lo                      // 000000829EEC: 02020E12
	v_mov_b32_e32 v31, 0                                       // 000000829EF0: 7E3E0280
	v_mov_b32_e32 v7, 0                                        // 000000829EF4: 7E0E0280
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 000000829EF8: BF870154
	v_add3_u32 v10, v20, v10, v13                              // 000000829EFC: D655000A 04361514
	s_waitcnt vmcnt(1)                                         // 000000829F04: BF8907F7
	v_bfe_u32 v11, v3, 16, 1                                   // 000000829F08: D610000B 02052103
	s_waitcnt vmcnt(0)                                         // 000000829F10: BF8903F7
	v_bfe_u32 v19, v4, 16, 1                                   // 000000829F14: D6100013 02052104
	v_add3_u32 v3, v3, v11, 0x7fff                             // 000000829F1C: D6550003 03FE1703 00007FFF
	v_mad_u64_u32 v[11:12], null, s18, v1, s[0:1]              // 000000829F28: D6FE7C0B 00020212
	v_add_nc_u32_e32 v1, s15, v18                              // 000000829F30: 4A02240F
	s_delay_alu instid0(VALU_DEP_4)                            // 000000829F34: BF870004
	v_add3_u32 v4, v4, v19, 0x7fff                             // 000000829F38: D6550004 03FE2704 00007FFF
	v_add_nc_u32_e32 v18, v18, v16                             // 000000829F44: 4A242112
	.long 0x7e103983                                           // 000000829F48: 7E103983
	v_lshlrev_b32_e32 v3, 2, v0                                // 000000829F4C: 30060082
	v_min_i32_e32 v19, s20, v1                                 // 000000829F50: 22260214
	v_add3_u32 v20, v2, v12, v21                               // 000000829F54: D6550014 04561902
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000829F5C: BF870224
	v_and_or_b32 v1, 0xffff0000, v4, v8                        // 000000829F60: D6570001 042208FF FFFF0000
	v_mov_b32_e32 v8, 0                                        // 000000829F6C: 7E100280
	v_cmp_lt_i32_e32 vcc_lo, v18, v19                          // 000000829F70: 7C822712
	ds_store_b32 v3, v1                                        // 000000829F74: D8340000 00000103
	s_waitcnt lgkmcnt(0)                                       // 000000829F7C: BF89FC07
	s_barrier                                                  // 000000829F80: BFBD0000
	buffer_gl0_inv                                             // 000000829F84: E0AC0000 00000000
	s_and_saveexec_b32 s1, vcc_lo                              // 000000829F8C: BE81206A
	s_cbranch_execz 21                                         // 000000829F90: BFA50015 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi2ELb0ELi2ELi0EEEvPKhPKtPvlllllS6_f+0x1e8>
	v_lshlrev_b32_e32 v1, 1, v18                               // 000000829F94: 30022481
	v_lshlrev_b32_e32 v3, 4, v18                               // 000000829F98: 30062484
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000829F9C: BF870112
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000829FA0: 3404029F
	v_ashrrev_i32_e32 v4, 31, v3                               // 000000829FA4: 3408069F
	.long 0xd7000001                                           // 000000829FA8: D7000001
	v_cndmask_b32_e32 v1, v11, v1, vcc_lo                      // 000000829FAC: 0202030B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000829FB0: BF8700A1
	v_add_co_ci_u32_e64 v2, null, v20, v2, s0                  // 000000829FB4: D5207C02 00020514
	.long 0xd7000003                                           // 000000829FBC: D7000003
	v_cndmask_b32_e32 v1, v9, v3, vcc_lo                       // 000000829FC0: 02020709
	v_add_co_ci_u32_e64 v4, null, v10, v4, s0                  // 000000829FC4: D5207C04 0002090A
	s_clause 0x1                                               // 000000829FCC: BF850001
	global_load_d16_b16 v1, v[1:2], off                        // 000000829FD0: DC820000 017C0001
	global_load_b128 v[5:8], v[3:4], off                       // 000000829FD8: DC5E0000 057C0003
	s_waitcnt vmcnt(1)                                         // 000000829FE0: BF8907F7
	v_cvt_f32_f16_e32 v31, v1                                  // 000000829FE4: 7E3E1701
	s_or_b32 exec_lo, exec_lo, s1                              // 000000829FE8: 8C7E017E
	v_dual_mov_b32 v22, 0 :: v_dual_mov_b32 v23, 0             // 000000829FEC: CA100080 16160080
	v_dual_mov_b32 v24, 0 :: v_dual_mov_b32 v25, 0             // 000000829FF4: CA100080 18180080
	v_dual_mov_b32 v26, 0 :: v_dual_mov_b32 v27, 0             // 000000829FFC: CA100080 1A1A0080
	v_mov_b32_e32 v21, 0                                       // 00000082A004: 7E2A0280
	s_and_saveexec_b32 s1, vcc_lo                              // 00000082A008: BE81206A
	s_cbranch_execz 639                                        // 00000082A00C: BFA5027F <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi2ELb0ELi2ELi0EEEvPKhPKtPvlllllS6_f+0xc0c>
	v_dual_mov_b32 v26, 0 :: v_dual_add_nc_u32 v1, 32, v18     // 00000082A010: CA200080 1A0024A0
	v_dual_mov_b32 v21, 0 :: v_dual_lshlrev_b32 v12, 5, v18    // 00000082A018: CA220080 150C2485
	v_dual_mov_b32 v25, 0 :: v_dual_mov_b32 v22, 0             // 00000082A020: CA100080 19160080
	s_delay_alu instid0(VALU_DEP_3)                            // 00000082A028: BF870003
	v_dual_mov_b32 v27, 0 :: v_dual_lshlrev_b32 v28, 4, v1     // 00000082A02C: CA220080 1B1C0284
	v_dual_mov_b32 v24, 0 :: v_dual_lshlrev_b32 v29, 1, v1     // 00000082A034: CA220080 181C0281
	v_dual_mov_b32 v23, 0 :: v_dual_mov_b32 v30, v31           // 00000082A03C: CA100080 171E011F
	v_mov_b32_e32 v17, 0                                       // 00000082A044: 7E220280
	s_mul_i32 s0, s11, 6                                       // 00000082A048: 9600860B
	s_mul_hi_u32 s14, s10, 6                                   // 00000082A04C: 968E860A
	s_lshl_b64 s[4:5], s[10:11], 2                             // 00000082A050: 8484820A
	s_add_i32 s14, s14, s0                                     // 00000082A054: 810E000E
	s_mul_i32 s16, s10, 6                                      // 00000082A058: 9610860A
	s_mov_b32 s15, 0                                           // 00000082A05C: BE8F0080
	s_lshl_b64 s[10:11], s[10:11], 1                           // 00000082A060: 848A810A
	s_branch 585                                               // 00000082A064: BFA00249 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi2ELb0ELi2ELi0EEEvPKhPKtPvlllllS6_f+0xb8c>
	s_or_b32 exec_lo, exec_lo, s17                             // 00000082A068: 8C7E117E
	v_and_b32_e32 v13, 0xff, v5                                // 00000082A06C: 361A0AFF 000000FF
	s_and_b32 s0, exec_lo, vcc_lo                              // 00000082A074: 8B006A7E
	v_add_nc_u32_e32 v29, 64, v29                              // 00000082A078: 4A3A3AC0
	s_or_b32 s15, s0, s15                                      // 00000082A07C: 8C0F0F00
	v_add_nc_u32_e32 v28, 0x200, v28                           // 00000082A080: 4A3838FF 00000200
	v_lshlrev_b32_e32 v13, 2, v13                              // 00000082A088: 301A1A82
	ds_load_b32 v48, v13                                       // 00000082A08C: D8D80000 3000000D
	v_lshrrev_b32_e32 v13, 6, v5                               // 00000082A094: 321A0A86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 00000082A098: BF870141
	v_and_b32_e32 v13, 0x3fc, v13                              // 00000082A09C: 361A1AFF 000003FC
	ds_load_b32 v49, v13                                       // 00000082A0A4: D8D80000 3100000D
	v_lshrrev_b32_e32 v13, 14, v5                              // 00000082A0AC: 321A0A8E
	v_lshrrev_b32_e32 v5, 22, v5                               // 00000082A0B0: 320A0A96
	v_and_b32_e32 v13, 0x3fc, v13                              // 00000082A0B4: 361A1AFF 000003FC
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 00000082A0BC: BF870152
	v_and_b32_e32 v5, 0x3fc, v5                                // 00000082A0C0: 360A0AFF 000003FC
	ds_load_b32 v50, v13                                       // 00000082A0C8: D8D80000 3200000D
	ds_load_b32 v51, v5                                        // 00000082A0D0: D8D80000 33000005
	v_and_b32_e32 v5, 0xff, v6                                 // 00000082A0D8: 360A0CFF 000000FF
	v_ashrrev_i32_e32 v13, 31, v12                             // 00000082A0E0: 341A189F
	v_lshlrev_b32_e32 v5, 2, v5                                // 00000082A0E4: 300A0A82
	ds_load_b32 v52, v5                                        // 00000082A0E8: D8D80000 34000005
	v_lshrrev_b32_e32 v5, 6, v6                                // 00000082A0F0: 320A0C86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000082A0F4: BF8700B1
	v_and_b32_e32 v5, 0x3fc, v5                                // 00000082A0F8: 360A0AFF 000003FC
	ds_load_b32 v53, v5                                        // 00000082A100: D8D80000 35000005
	v_lshrrev_b32_e32 v5, 14, v6                               // 00000082A108: 320A0C8E
	v_and_b32_e32 v5, 0x3fc, v5                                // 00000082A10C: 360A0AFF 000003FC
	ds_load_b32 v54, v5                                        // 00000082A114: D8D80000 36000005
	v_lshrrev_b32_e32 v5, 22, v6                               // 00000082A11C: 320A0C96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000082A120: BF8700B1
	v_and_b32_e32 v5, 0x3fc, v5                                // 00000082A124: 360A0AFF 000003FC
	ds_load_b32 v55, v5                                        // 00000082A12C: D8D80000 37000005
	v_and_b32_e32 v5, 0xff, v7                                 // 00000082A134: 360A0EFF 000000FF
	v_lshlrev_b32_e32 v5, 2, v5                                // 00000082A13C: 300A0A82
	ds_load_b32 v56, v5                                        // 00000082A140: D8D80000 38000005
	v_lshrrev_b32_e32 v5, 6, v7                                // 00000082A148: 320A0E86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000082A14C: BF8700B1
	v_and_b32_e32 v5, 0x3fc, v5                                // 00000082A150: 360A0AFF 000003FC
	ds_load_b32 v57, v5                                        // 00000082A158: D8D80000 39000005
	v_lshrrev_b32_e32 v5, 14, v7                               // 00000082A160: 320A0E8E
	v_and_b32_e32 v5, 0x3fc, v5                                // 00000082A164: 360A0AFF 000003FC
	ds_load_b32 v58, v5                                        // 00000082A16C: D8D80000 3A000005
	v_lshrrev_b32_e32 v5, 22, v7                               // 00000082A174: 320A0E96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000082A178: BF8700B1
	v_and_b32_e32 v5, 0x3fc, v5                                // 00000082A17C: 360A0AFF 000003FC
	ds_load_b32 v59, v5                                        // 00000082A184: D8D80000 3B000005
	v_and_b32_e32 v5, 0xff, v8                                 // 00000082A18C: 360A10FF 000000FF
	v_lshlrev_b32_e32 v5, 2, v5                                // 00000082A194: 300A0A82
	ds_load_b32 v60, v5                                        // 00000082A198: D8D80000 3C000005
	v_lshrrev_b32_e32 v5, 6, v8                                // 00000082A1A0: 320A1086
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000082A1A4: BF8700B1
	v_and_b32_e32 v5, 0x3fc, v5                                // 00000082A1A8: 360A0AFF 000003FC
	ds_load_b32 v61, v5                                        // 00000082A1B0: D8D80000 3D000005
	v_lshrrev_b32_e32 v5, 14, v8                               // 00000082A1B8: 320A108E
	v_and_b32_e32 v5, 0x3fc, v5                                // 00000082A1BC: 360A0AFF 000003FC
	ds_load_b32 v62, v5                                        // 00000082A1C4: D8D80000 3E000005
	v_lshrrev_b32_e32 v5, 22, v8                               // 00000082A1CC: 320A1096
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 00000082A1D0: BF870141
	v_and_b32_e32 v5, 0x3fc, v5                                // 00000082A1D4: 360A0AFF 000003FC
	ds_load_b32 v63, v5                                        // 00000082A1DC: D8D80000 3F000005
	.long 0xd73c0005                                           // 00000082A1E4: D73C0005
	v_cndmask_b32_e32 v1, 1, v12, vcc_lo                       // 00000082A1E8: 02021881
	v_add_nc_u32_e32 v12, 0x400, v12                           // 00000082A1EC: 4A1818FF 00000400
	.long 0xd7006a2c                                           // 00000082A1F4: D7006A2C
	v_cndmask_b32_e32 v1, s6, v5, vcc_lo                       // 00000082A1F8: 02020A06
	s_delay_alu instid0(VALU_DEP_1)                            // 00000082A1FC: BF870001
	v_add_co_ci_u32_e64 v45, null, s7, v6, vcc_lo              // 00000082A200: D5207C2D 01AA0C07
	s_clause 0x3                                               // 00000082A208: BF850003
	global_load_b128 v[5:8], v[44:45], off                     // 00000082A20C: DC5E0000 057C002C
	global_load_b128 v[32:35], v[44:45], off offset:16         // 00000082A214: DC5E0010 207C002C
	global_load_b128 v[36:39], v[44:45], off offset:32         // 00000082A21C: DC5E0020 247C002C
	global_load_b128 v[40:43], v[44:45], off offset:48         // 00000082A224: DC5E0030 287C002C
	s_waitcnt vmcnt(3) lgkmcnt(15)                             // 00000082A22C: BF890CF7
	v_dot2_f32_bf16 v5, v5, v48, 0                             // 00000082A230: CC1A4005 1A026105
	s_waitcnt lgkmcnt(14)                                      // 00000082A238: BF89FCE7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000082A23C: BF8700A1
	v_dot2_f32_bf16 v5, v6, v49, v5                            // 00000082A240: CC1A4005 1C166306
	s_waitcnt lgkmcnt(13)                                      // 00000082A248: BF89FCD7
	v_dot2_f32_bf16 v5, v7, v50, v5                            // 00000082A24C: CC1A4005 1C166507
	s_waitcnt lgkmcnt(12)                                      // 00000082A254: BF89FCC7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000082A258: BF8700A1
	v_dot2_f32_bf16 v5, v8, v51, v5                            // 00000082A25C: CC1A4005 1C166708
	s_waitcnt vmcnt(2) lgkmcnt(11)                             // 00000082A264: BF8908B7
	v_dot2_f32_bf16 v5, v32, v52, v5                           // 00000082A268: CC1A4005 1C166920
	s_waitcnt lgkmcnt(10)                                      // 00000082A270: BF89FCA7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000082A274: BF8700A1
	v_dot2_f32_bf16 v5, v33, v53, v5                           // 00000082A278: CC1A4005 1C166B21
	s_waitcnt lgkmcnt(9)                                       // 00000082A280: BF89FC97
	v_dot2_f32_bf16 v5, v34, v54, v5                           // 00000082A284: CC1A4005 1C166D22
	s_waitcnt lgkmcnt(8)                                       // 00000082A28C: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000082A290: BF8700A1
	v_dot2_f32_bf16 v5, v35, v55, v5                           // 00000082A294: CC1A4005 1C166F23
	s_waitcnt vmcnt(1) lgkmcnt(7)                              // 00000082A29C: BF890477
	v_dot2_f32_bf16 v5, v36, v56, v5                           // 00000082A2A0: CC1A4005 1C167124
	s_waitcnt lgkmcnt(6)                                       // 00000082A2A8: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000082A2AC: BF8700A1
	v_dot2_f32_bf16 v5, v37, v57, v5                           // 00000082A2B0: CC1A4005 1C167325
	s_waitcnt lgkmcnt(5)                                       // 00000082A2B8: BF89FC57
	v_dot2_f32_bf16 v5, v38, v58, v5                           // 00000082A2BC: CC1A4005 1C167526
	s_waitcnt lgkmcnt(4)                                       // 00000082A2C4: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000082A2C8: BF8700A1
	v_dot2_f32_bf16 v5, v39, v59, v5                           // 00000082A2CC: CC1A4005 1C167727
	s_waitcnt vmcnt(0) lgkmcnt(3)                              // 00000082A2D4: BF890037
	v_dot2_f32_bf16 v5, v40, v60, v5                           // 00000082A2D8: CC1A4005 1C167928
	.long 0xd7006a28                                           // 00000082A2E0: D7006A28
	v_cndmask_b32_e32 v0, v44, v10, vcc_lo                     // 00000082A2E4: 0200152C
	s_waitcnt lgkmcnt(2)                                       // 00000082A2E8: BF89FC27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000082A2EC: BF8701C2
	v_dot2_f32_bf16 v5, v41, v61, v5                           // 00000082A2F0: CC1A4005 1C167B29
	v_add_co_ci_u32_e64 v41, null, s11, v45, vcc_lo            // 00000082A2F8: D5207C29 01AA5A0B
	.long 0xd7006a2e                                           // 00000082A300: D7006A2E
	v_cndmask_b32_e32 v0, v44, v4, vcc_lo                      // 00000082A304: 0200092C
	s_waitcnt lgkmcnt(1)                                       // 00000082A308: BF89FC17
	v_dot2_f32_bf16 v5, v42, v62, v5                           // 00000082A30C: CC1A4005 1C167D2A
	v_add_co_ci_u32_e64 v47, null, s5, v45, vcc_lo             // 00000082A314: D5207C2F 01AA5A05
	.long 0xd7006a2c                                           // 00000082A31C: D7006A2C
	v_cndmask_b32_e32 v0, v44, v16, vcc_lo                     // 00000082A320: 0200212C
	s_waitcnt lgkmcnt(0)                                       // 00000082A324: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000082A328: BF870123
	v_dot2_f32_bf16 v5, v43, v63, v5                           // 00000082A32C: CC1A4005 1C167F2B
	v_add_co_ci_u32_e64 v45, null, s14, v45, vcc_lo            // 00000082A334: D5207C2D 01AA5A0E
	v_fmac_f32_e32 v21, v31, v5                                // 00000082A33C: 562A0B1F
	s_clause 0x3                                               // 00000082A340: BF850003
	global_load_b128 v[5:8], v[40:41], off                     // 00000082A344: DC5E0000 057C0028
	global_load_b128 v[32:35], v[40:41], off offset:16         // 00000082A34C: DC5E0010 207C0028
	global_load_b128 v[36:39], v[40:41], off offset:32         // 00000082A354: DC5E0020 247C0028
	global_load_b128 v[40:43], v[40:41], off offset:48         // 00000082A35C: DC5E0030 287C0028
	s_waitcnt vmcnt(3)                                         // 00000082A364: BF890FF7
	v_dot2_f32_bf16 v5, v5, v48, 0                             // 00000082A368: CC1A4005 1A026105
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000082A370: BF870091
	v_dot2_f32_bf16 v5, v6, v49, v5                            // 00000082A374: CC1A4005 1C166306
	v_dot2_f32_bf16 v5, v7, v50, v5                            // 00000082A37C: CC1A4005 1C166507
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000082A384: BF8700A1
	v_dot2_f32_bf16 v5, v8, v51, v5                            // 00000082A388: CC1A4005 1C166708
	s_waitcnt vmcnt(2)                                         // 00000082A390: BF890BF7
	v_dot2_f32_bf16 v5, v32, v52, v5                           // 00000082A394: CC1A4005 1C166920
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000082A39C: BF870091
	v_dot2_f32_bf16 v5, v33, v53, v5                           // 00000082A3A0: CC1A4005 1C166B21
	v_dot2_f32_bf16 v5, v34, v54, v5                           // 00000082A3A8: CC1A4005 1C166D22
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000082A3B0: BF8700A1
	v_dot2_f32_bf16 v5, v35, v55, v5                           // 00000082A3B4: CC1A4005 1C166F23
	s_waitcnt vmcnt(1)                                         // 00000082A3BC: BF8907F7
	v_dot2_f32_bf16 v5, v36, v56, v5                           // 00000082A3C0: CC1A4005 1C167124
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000082A3C8: BF870091
	v_dot2_f32_bf16 v5, v37, v57, v5                           // 00000082A3CC: CC1A4005 1C167325
	v_dot2_f32_bf16 v5, v38, v58, v5                           // 00000082A3D4: CC1A4005 1C167526
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000082A3DC: BF8700A1
	v_dot2_f32_bf16 v5, v39, v59, v5                           // 00000082A3E0: CC1A4005 1C167727
	s_waitcnt vmcnt(0)                                         // 00000082A3E8: BF8903F7
	v_dot2_f32_bf16 v5, v40, v60, v5                           // 00000082A3EC: CC1A4005 1C167928
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000082A3F4: BF870091
	v_dot2_f32_bf16 v5, v41, v61, v5                           // 00000082A3F8: CC1A4005 1C167B29
	v_dot2_f32_bf16 v5, v42, v62, v5                           // 00000082A400: CC1A4005 1C167D2A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000082A408: BF870091
	v_dot2_f32_bf16 v5, v43, v63, v5                           // 00000082A40C: CC1A4005 1C167F2B
	v_fmac_f32_e32 v27, v31, v5                                // 00000082A414: 56360B1F
	s_clause 0x3                                               // 00000082A418: BF850003
	global_load_b128 v[5:8], v[46:47], off                     // 00000082A41C: DC5E0000 057C002E
	global_load_b128 v[32:35], v[46:47], off offset:16         // 00000082A424: DC5E0010 207C002E
	global_load_b128 v[36:39], v[46:47], off offset:32         // 00000082A42C: DC5E0020 247C002E
	global_load_b128 v[40:43], v[46:47], off offset:48         // 00000082A434: DC5E0030 287C002E
	.long 0xd7006a2e                                           // 00000082A43C: D7006A2E
	v_cndmask_b32_e32 v0, v46, v4, vcc_lo                      // 00000082A440: 0200092E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000082A444: BF8700B1
	v_add_co_ci_u32_e64 v47, null, s5, v47, vcc_lo             // 00000082A448: D5207C2F 01AA5E05
	s_waitcnt vmcnt(3)                                         // 00000082A450: BF890FF7
	v_dot2_f32_bf16 v5, v5, v48, 0                             // 00000082A454: CC1A4005 1A026105
	v_dot2_f32_bf16 v5, v6, v49, v5                            // 00000082A45C: CC1A4005 1C166306
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000082A464: BF870091
	v_dot2_f32_bf16 v5, v7, v50, v5                            // 00000082A468: CC1A4005 1C166507
	v_dot2_f32_bf16 v5, v8, v51, v5                            // 00000082A470: CC1A4005 1C166708
	s_waitcnt vmcnt(2)                                         // 00000082A478: BF890BF7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000082A47C: BF870091
	v_dot2_f32_bf16 v5, v32, v52, v5                           // 00000082A480: CC1A4005 1C166920
	v_dot2_f32_bf16 v5, v33, v53, v5                           // 00000082A488: CC1A4005 1C166B21
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000082A490: BF870091
	v_dot2_f32_bf16 v5, v34, v54, v5                           // 00000082A494: CC1A4005 1C166D22
	v_dot2_f32_bf16 v5, v35, v55, v5                           // 00000082A49C: CC1A4005 1C166F23
	s_waitcnt vmcnt(1)                                         // 00000082A4A4: BF8907F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000082A4A8: BF870091
	v_dot2_f32_bf16 v5, v36, v56, v5                           // 00000082A4AC: CC1A4005 1C167124
	v_dot2_f32_bf16 v5, v37, v57, v5                           // 00000082A4B4: CC1A4005 1C167325
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000082A4BC: BF870091
	v_dot2_f32_bf16 v5, v38, v58, v5                           // 00000082A4C0: CC1A4005 1C167526
	v_dot2_f32_bf16 v5, v39, v59, v5                           // 00000082A4C8: CC1A4005 1C167727
	s_waitcnt vmcnt(0)                                         // 00000082A4D0: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000082A4D4: BF870091
	v_dot2_f32_bf16 v5, v40, v60, v5                           // 00000082A4D8: CC1A4005 1C167928
	v_dot2_f32_bf16 v5, v41, v61, v5                           // 00000082A4E0: CC1A4005 1C167B29
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000082A4E8: BF870091
	v_dot2_f32_bf16 v5, v42, v62, v5                           // 00000082A4EC: CC1A4005 1C167D2A
	v_dot2_f32_bf16 v5, v43, v63, v5                           // 00000082A4F4: CC1A4005 1C167F2B
	s_delay_alu instid0(VALU_DEP_1)                            // 00000082A4FC: BF870001
	v_fmac_f32_e32 v26, v31, v5                                // 00000082A500: 56340B1F
	s_clause 0x3                                               // 00000082A504: BF850003
	global_load_b128 v[5:8], v[44:45], off                     // 00000082A508: DC5E0000 057C002C
	global_load_b128 v[32:35], v[44:45], off offset:16         // 00000082A510: DC5E0010 207C002C
	global_load_b128 v[36:39], v[44:45], off offset:32         // 00000082A518: DC5E0020 247C002C
	global_load_b128 v[40:43], v[44:45], off offset:48         // 00000082A520: DC5E0030 287C002C
	.long 0xd7006a2c                                           // 00000082A528: D7006A2C
	v_cndmask_b32_e32 v0, v44, v4, vcc_lo                      // 00000082A52C: 0200092C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000082A530: BF8700B1
	v_add_co_ci_u32_e64 v45, null, s5, v45, vcc_lo             // 00000082A534: D5207C2D 01AA5A05
	s_waitcnt vmcnt(3)                                         // 00000082A53C: BF890FF7
	v_dot2_f32_bf16 v5, v5, v48, 0                             // 00000082A540: CC1A4005 1A026105
	v_dot2_f32_bf16 v5, v6, v49, v5                            // 00000082A548: CC1A4005 1C166306
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000082A550: BF870091
	v_dot2_f32_bf16 v5, v7, v50, v5                            // 00000082A554: CC1A4005 1C166507
	v_dot2_f32_bf16 v5, v8, v51, v5                            // 00000082A55C: CC1A4005 1C166708
	s_waitcnt vmcnt(2)                                         // 00000082A564: BF890BF7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000082A568: BF870091
	v_dot2_f32_bf16 v5, v32, v52, v5                           // 00000082A56C: CC1A4005 1C166920
	v_dot2_f32_bf16 v5, v33, v53, v5                           // 00000082A574: CC1A4005 1C166B21
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000082A57C: BF870091
	v_dot2_f32_bf16 v5, v34, v54, v5                           // 00000082A580: CC1A4005 1C166D22
	v_dot2_f32_bf16 v5, v35, v55, v5                           // 00000082A588: CC1A4005 1C166F23
	s_waitcnt vmcnt(1)                                         // 00000082A590: BF8907F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000082A594: BF870091
	v_dot2_f32_bf16 v5, v36, v56, v5                           // 00000082A598: CC1A4005 1C167124
	v_dot2_f32_bf16 v5, v37, v57, v5                           // 00000082A5A0: CC1A4005 1C167325
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000082A5A8: BF870091
	v_dot2_f32_bf16 v5, v38, v58, v5                           // 00000082A5AC: CC1A4005 1C167526
	v_dot2_f32_bf16 v5, v39, v59, v5                           // 00000082A5B4: CC1A4005 1C167727
	s_waitcnt vmcnt(0)                                         // 00000082A5BC: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000082A5C0: BF870091
	v_dot2_f32_bf16 v5, v40, v60, v5                           // 00000082A5C4: CC1A4005 1C167928
	v_dot2_f32_bf16 v5, v41, v61, v5                           // 00000082A5CC: CC1A4005 1C167B29
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000082A5D4: BF870091
	v_dot2_f32_bf16 v5, v42, v62, v5                           // 00000082A5D8: CC1A4005 1C167D2A
	v_dot2_f32_bf16 v5, v43, v63, v5                           // 00000082A5E0: CC1A4005 1C167F2B
	s_delay_alu instid0(VALU_DEP_1)                            // 00000082A5E8: BF870001
	v_fmac_f32_e32 v25, v31, v5                                // 00000082A5EC: 56320B1F
	s_clause 0x3                                               // 00000082A5F0: BF850003
	global_load_b128 v[5:8], v[46:47], off                     // 00000082A5F4: DC5E0000 057C002E
	global_load_b128 v[32:35], v[46:47], off offset:16         // 00000082A5FC: DC5E0010 207C002E
	global_load_b128 v[36:39], v[46:47], off offset:32         // 00000082A604: DC5E0020 247C002E
	global_load_b128 v[40:43], v[46:47], off offset:48         // 00000082A60C: DC5E0030 287C002E
	s_waitcnt vmcnt(3)                                         // 00000082A614: BF890FF7
	v_dot2_f32_bf16 v5, v5, v48, 0                             // 00000082A618: CC1A4005 1A026105
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000082A620: BF870091
	v_dot2_f32_bf16 v5, v6, v49, v5                            // 00000082A624: CC1A4005 1C166306
	v_dot2_f32_bf16 v5, v7, v50, v5                            // 00000082A62C: CC1A4005 1C166507
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000082A634: BF8700A1
	v_dot2_f32_bf16 v5, v8, v51, v5                            // 00000082A638: CC1A4005 1C166708
	s_waitcnt vmcnt(2)                                         // 00000082A640: BF890BF7
	v_dot2_f32_bf16 v5, v32, v52, v5                           // 00000082A644: CC1A4005 1C166920
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000082A64C: BF870091
	v_dot2_f32_bf16 v5, v33, v53, v5                           // 00000082A650: CC1A4005 1C166B21
	v_dot2_f32_bf16 v5, v34, v54, v5                           // 00000082A658: CC1A4005 1C166D22
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000082A660: BF8700A1
	v_dot2_f32_bf16 v5, v35, v55, v5                           // 00000082A664: CC1A4005 1C166F23
	s_waitcnt vmcnt(1)                                         // 00000082A66C: BF8907F7
	v_dot2_f32_bf16 v5, v36, v56, v5                           // 00000082A670: CC1A4005 1C167124
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000082A678: BF870091
	v_dot2_f32_bf16 v5, v37, v57, v5                           // 00000082A67C: CC1A4005 1C167325
	v_dot2_f32_bf16 v5, v38, v58, v5                           // 00000082A684: CC1A4005 1C167526
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000082A68C: BF8700A1
	v_dot2_f32_bf16 v5, v39, v59, v5                           // 00000082A690: CC1A4005 1C167727
	s_waitcnt vmcnt(0)                                         // 00000082A698: BF8903F7
	v_dot2_f32_bf16 v5, v40, v60, v5                           // 00000082A69C: CC1A4005 1C167928
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000082A6A4: BF870091
	v_dot2_f32_bf16 v5, v41, v61, v5                           // 00000082A6A8: CC1A4005 1C167B29
	v_dot2_f32_bf16 v5, v42, v62, v5                           // 00000082A6B0: CC1A4005 1C167D2A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000082A6B8: BF870091
	v_dot2_f32_bf16 v5, v43, v63, v5                           // 00000082A6BC: CC1A4005 1C167F2B
	v_fmac_f32_e32 v24, v31, v5                                // 00000082A6C4: 56300B1F
	s_clause 0x3                                               // 00000082A6C8: BF850003
	global_load_b128 v[5:8], v[44:45], off                     // 00000082A6CC: DC5E0000 057C002C
	global_load_b128 v[32:35], v[44:45], off offset:16         // 00000082A6D4: DC5E0010 207C002C
	global_load_b128 v[36:39], v[44:45], off offset:32         // 00000082A6DC: DC5E0020 247C002C
	global_load_b128 v[40:43], v[44:45], off offset:48         // 00000082A6E4: DC5E0030 287C002C
	s_waitcnt vmcnt(3)                                         // 00000082A6EC: BF890FF7
	v_dot2_f32_bf16 v5, v5, v48, 0                             // 00000082A6F0: CC1A4005 1A026105
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000082A6F8: BF870091
	v_dot2_f32_bf16 v5, v6, v49, v5                            // 00000082A6FC: CC1A4005 1C166306
	v_dot2_f32_bf16 v5, v7, v50, v5                            // 00000082A704: CC1A4005 1C166507
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000082A70C: BF8700A1
	v_dot2_f32_bf16 v5, v8, v51, v5                            // 00000082A710: CC1A4005 1C166708
	s_waitcnt vmcnt(2)                                         // 00000082A718: BF890BF7
	v_dot2_f32_bf16 v5, v32, v52, v5                           // 00000082A71C: CC1A4005 1C166920
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000082A724: BF870091
	v_dot2_f32_bf16 v5, v33, v53, v5                           // 00000082A728: CC1A4005 1C166B21
	v_dot2_f32_bf16 v5, v34, v54, v5                           // 00000082A730: CC1A4005 1C166D22
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000082A738: BF8700A1
	v_dot2_f32_bf16 v5, v35, v55, v5                           // 00000082A73C: CC1A4005 1C166F23
	s_waitcnt vmcnt(1)                                         // 00000082A744: BF8907F7
	v_dot2_f32_bf16 v5, v36, v56, v5                           // 00000082A748: CC1A4005 1C167124
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000082A750: BF870091
	v_dot2_f32_bf16 v5, v37, v57, v5                           // 00000082A754: CC1A4005 1C167325
	v_dot2_f32_bf16 v5, v38, v58, v5                           // 00000082A75C: CC1A4005 1C167526
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000082A764: BF8700A1
	v_dot2_f32_bf16 v5, v39, v59, v5                           // 00000082A768: CC1A4005 1C167727
	s_waitcnt vmcnt(0)                                         // 00000082A770: BF8903F7
	v_dot2_f32_bf16 v5, v40, v60, v5                           // 00000082A774: CC1A4005 1C167928
	.long 0xd7006a28                                           // 00000082A77C: D7006A28
	v_cndmask_b32_e32 v0, v46, v4, vcc_lo                      // 00000082A780: 0200092E
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000082A784: BF870122
	v_dot2_f32_bf16 v5, v41, v61, v5                           // 00000082A788: CC1A4005 1C167B29
	v_add_co_ci_u32_e64 v41, null, s5, v47, vcc_lo             // 00000082A790: D5207C29 01AA5E05
	v_dot2_f32_bf16 v5, v42, v62, v5                           // 00000082A798: CC1A4005 1C167D2A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000082A7A0: BF870091
	v_dot2_f32_bf16 v5, v43, v63, v5                           // 00000082A7A4: CC1A4005 1C167F2B
	v_fmac_f32_e32 v23, v31, v5                                // 00000082A7AC: 562E0B1F
	s_clause 0x3                                               // 00000082A7B0: BF850003
	global_load_b128 v[5:8], v[40:41], off                     // 00000082A7B4: DC5E0000 057C0028
	global_load_b128 v[32:35], v[40:41], off offset:16         // 00000082A7BC: DC5E0010 207C0028
	global_load_b128 v[36:39], v[40:41], off offset:32         // 00000082A7C4: DC5E0020 247C0028
	global_load_b128 v[40:43], v[40:41], off offset:48         // 00000082A7CC: DC5E0030 287C0028
	s_waitcnt vmcnt(3)                                         // 00000082A7D4: BF890FF7
	v_dot2_f32_bf16 v5, v5, v48, 0                             // 00000082A7D8: CC1A4005 1A026105
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000082A7E0: BF870091
	v_dot2_f32_bf16 v5, v6, v49, v5                            // 00000082A7E4: CC1A4005 1C166306
	v_dot2_f32_bf16 v5, v7, v50, v5                            // 00000082A7EC: CC1A4005 1C166507
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000082A7F4: BF8700A1
	v_dot2_f32_bf16 v5, v8, v51, v5                            // 00000082A7F8: CC1A4005 1C166708
	s_waitcnt vmcnt(2)                                         // 00000082A800: BF890BF7
	v_dot2_f32_bf16 v5, v32, v52, v5                           // 00000082A804: CC1A4005 1C166920
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000082A80C: BF870091
	v_dot2_f32_bf16 v5, v33, v53, v5                           // 00000082A810: CC1A4005 1C166B21
	v_dot2_f32_bf16 v5, v34, v54, v5                           // 00000082A818: CC1A4005 1C166D22
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000082A820: BF8700A1
	v_dot2_f32_bf16 v5, v35, v55, v5                           // 00000082A824: CC1A4005 1C166F23
	s_waitcnt vmcnt(1)                                         // 00000082A82C: BF8907F7
	v_dot2_f32_bf16 v5, v36, v56, v5                           // 00000082A830: CC1A4005 1C167124
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000082A838: BF870091
	v_dot2_f32_bf16 v5, v37, v57, v5                           // 00000082A83C: CC1A4005 1C167325
	v_dot2_f32_bf16 v5, v38, v58, v5                           // 00000082A844: CC1A4005 1C167526
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000082A84C: BF8700A1
	v_dot2_f32_bf16 v5, v39, v59, v5                           // 00000082A850: CC1A4005 1C167727
	s_waitcnt vmcnt(0)                                         // 00000082A858: BF8903F7
	v_dot2_f32_bf16 v5, v40, v60, v5                           // 00000082A85C: CC1A4005 1C167928
	.long 0xd7006a28                                           // 00000082A864: D7006A28
	v_cndmask_b32_e32 v0, v44, v4, vcc_lo                      // 00000082A868: 0200092C
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000082A86C: BF870122
	v_dot2_f32_bf16 v5, v41, v61, v5                           // 00000082A870: CC1A4005 1C167B29
	v_add_co_ci_u32_e64 v41, null, s5, v45, vcc_lo             // 00000082A878: D5207C29 01AA5A05
	v_dot2_f32_bf16 v5, v42, v62, v5                           // 00000082A880: CC1A4005 1C167D2A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000082A888: BF870091
	v_dot2_f32_bf16 v5, v43, v63, v5                           // 00000082A88C: CC1A4005 1C167F2B
	v_fmac_f32_e32 v22, v31, v5                                // 00000082A894: 562C0B1F
	s_clause 0x3                                               // 00000082A898: BF850003
	global_load_b128 v[5:8], v[40:41], off                     // 00000082A89C: DC5E0000 057C0028
	global_load_b128 v[32:35], v[40:41], off offset:16         // 00000082A8A4: DC5E0010 207C0028
	global_load_b128 v[36:39], v[40:41], off offset:32         // 00000082A8AC: DC5E0020 247C0028
	global_load_b128 v[40:43], v[40:41], off offset:48         // 00000082A8B4: DC5E0030 287C0028
	s_waitcnt vmcnt(3)                                         // 00000082A8BC: BF890FF7
	v_dot2_f32_bf16 v5, v5, v48, 0                             // 00000082A8C0: CC1A4005 1A026105
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000082A8C8: BF870121
	v_dot2_f32_bf16 v5, v6, v49, v5                            // 00000082A8CC: CC1A4005 1C166306
	v_mov_b32_e32 v6, v2                                       // 00000082A8D4: 7E0C0302
	v_dot2_f32_bf16 v5, v7, v50, v5                            // 00000082A8D8: CC1A4005 1C166507
	v_mov_b32_e32 v7, v3                                       // 00000082A8E0: 7E0E0303
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000082A8E4: BF870132
	v_dot2_f32_bf16 v5, v8, v51, v5                            // 00000082A8E8: CC1A4005 1C166708
	v_mov_b32_e32 v8, v4                                       // 00000082A8F0: 7E100304
	s_waitcnt vmcnt(2)                                         // 00000082A8F4: BF890BF7
	v_dot2_f32_bf16 v5, v32, v52, v5                           // 00000082A8F8: CC1A4005 1C166920
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000082A900: BF870091
	v_dot2_f32_bf16 v5, v33, v53, v5                           // 00000082A904: CC1A4005 1C166B21
	v_dot2_f32_bf16 v5, v34, v54, v5                           // 00000082A90C: CC1A4005 1C166D22
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000082A914: BF8700A1
	v_dot2_f32_bf16 v5, v35, v55, v5                           // 00000082A918: CC1A4005 1C166F23
	s_waitcnt vmcnt(1)                                         // 00000082A920: BF8907F7
	v_dot2_f32_bf16 v5, v36, v56, v5                           // 00000082A924: CC1A4005 1C167124
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000082A92C: BF870091
	v_dot2_f32_bf16 v5, v37, v57, v5                           // 00000082A930: CC1A4005 1C167325
	v_dot2_f32_bf16 v5, v38, v58, v5                           // 00000082A938: CC1A4005 1C167526
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000082A940: BF8700A1
	v_dot2_f32_bf16 v5, v39, v59, v5                           // 00000082A944: CC1A4005 1C167727
	s_waitcnt vmcnt(0)                                         // 00000082A94C: BF8903F7
	v_dot2_f32_bf16 v5, v40, v60, v5                           // 00000082A950: CC1A4005 1C167928
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000082A958: BF870091
	v_dot2_f32_bf16 v5, v41, v61, v5                           // 00000082A95C: CC1A4005 1C167B29
	v_dot2_f32_bf16 v5, v42, v62, v5                           // 00000082A964: CC1A4005 1C167D2A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000082A96C: BF870091
	v_dot2_f32_bf16 v5, v43, v63, v5                           // 00000082A970: CC1A4005 1C167F2B
	v_fmac_f32_e32 v17, v31, v5                                // 00000082A978: 56220B1F
	v_mov_b32_e32 v5, v1                                       // 00000082A97C: 7E0A0301
	v_mov_b32_e32 v31, v30                                     // 00000082A980: 7E3E031E
	s_and_not1_b32 exec_lo, exec_lo, s15                       // 00000082A984: 917E0F7E
	s_cbranch_execz 31                                         // 00000082A988: BFA5001F <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi2ELb0ELi2ELi0EEEvPKhPKtPvlllllS6_f+0xc08>
	s_waitcnt vmcnt(0)                                         // 00000082A98C: BF8903F7
	v_dual_mov_b32 v1, v5 :: v_dual_add_nc_u32 v18, 32, v18    // 00000082A990: CA200105 011224A0
	v_dual_mov_b32 v2, v6 :: v_dual_mov_b32 v3, v7             // 00000082A998: CA100106 02020107
	v_mov_b32_e32 v4, v8                                       // 00000082A9A0: 7E080308
	s_mov_b32 s17, exec_lo                                     // 00000082A9A4: BE91007E
	s_delay_alu instid0(VALU_DEP_3)                            // 00000082A9A8: BF870003
	v_cmp_ge_i32_e32 vcc_lo, v18, v19                          // 00000082A9AC: 7C8C2712
	.long 0xd4c1007e                                           // 00000082A9B0: D4C1007E
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 00000082A9B4: 02022712
	s_cbranch_execz 64939                                      // 00000082A9B8: BFA5FDAB <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi2ELb0ELi2ELi0EEEvPKhPKtPvlllllS6_f+0x268>
	v_ashrrev_i32_e32 v2, 31, v29                              // 00000082A9BC: 34043A9F
	v_ashrrev_i32_e32 v4, 31, v28                              // 00000082A9C0: 3408389F
	.long 0xd7000001                                           // 00000082A9C4: D7000001
	v_cndmask_b32_e32 v1, v11, v29, vcc_lo                     // 00000082A9C8: 02023B0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000082A9CC: BF8700A1
	v_add_co_ci_u32_e64 v2, null, v20, v2, s0                  // 00000082A9D0: D5207C02 00020514
	.long 0xd7000003                                           // 00000082A9D8: D7000003
	v_cndmask_b32_e32 v1, v9, v28, vcc_lo                      // 00000082A9DC: 02023909
	v_add_co_ci_u32_e64 v4, null, v10, v4, s0                  // 00000082A9E0: D5207C04 0002090A
	s_clause 0x1                                               // 00000082A9E8: BF850001
	global_load_d16_b16 v13, v[1:2], off                       // 00000082A9EC: DC820000 0D7C0001
	global_load_b128 v[1:4], v[3:4], off                       // 00000082A9F4: DC5E0000 017C0003
	s_waitcnt vmcnt(1)                                         // 00000082A9FC: BF8907F7
	v_cvt_f32_f16_e32 v30, v13                                 // 00000082AA00: 7E3C170D
	s_branch 64920                                             // 00000082AA04: BFA0FD98 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi2ELb0ELi2ELi0EEEvPKhPKtPvlllllS6_f+0x268>
	s_or_b32 exec_lo, exec_lo, s15                             // 00000082AA08: 8C7E0F7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000082AA0C: BF8700B9
	s_or_b32 exec_lo, exec_lo, s1                              // 00000082AA10: 8C7E017E
	.long 0xd71f0001                                           // 00000082AA14: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 00000082AA18: 020100C1
	s_mov_b32 s0, exec_lo                                      // 00000082AA1C: BE80007E
	v_xor_b32_e32 v2, 16, v1                                   // 00000082AA20: 3A040290
	v_xor_b32_e32 v10, 8, v1                                   // 00000082AA24: 3A140288
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000082AA28: BF8701A2
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 00000082AA2C: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 00000082AA30: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v10                           // 00000082AA34: 7C9814A0
	s_delay_alu instid0(VALU_DEP_2)                            // 00000082AA38: BF870002
	v_lshlrev_b32_e32 v2, 2, v2                                // 00000082AA3C: 30040482
	ds_bpermute_b32 v3, v2, v21                                // 00000082AA40: DACC0000 03001502
	s_waitcnt lgkmcnt(0)                                       // 00000082AA48: BF89FC07
	v_add_f32_e32 v3, v21, v3                                  // 00000082AA4C: 06060715
	s_waitcnt vmcnt(0)                                         // 00000082AA50: BF8903F7
	ds_bpermute_b32 v5, v2, v26                                // 00000082AA54: DACC0000 05001A02
	ds_bpermute_b32 v7, v2, v24                                // 00000082AA5C: DACC0000 07001802
	ds_bpermute_b32 v9, v2, v22                                // 00000082AA64: DACC0000 09001602
	v_cndmask_b32_e32 v10, v1, v10, vcc_lo                     // 00000082AA6C: 02141501
	ds_bpermute_b32 v4, v2, v27                                // 00000082AA70: DACC0000 04001B02
	ds_bpermute_b32 v6, v2, v25                                // 00000082AA78: DACC0000 06001902
	ds_bpermute_b32 v8, v2, v23                                // 00000082AA80: DACC0000 08001702
	ds_bpermute_b32 v2, v2, v17                                // 00000082AA88: DACC0000 02001102
	v_xor_b32_e32 v21, 4, v1                                   // 00000082AA90: 3A2A0284
	s_delay_alu instid0(VALU_DEP_1)                            // 00000082AA94: BF870001
	v_cmp_gt_u32_e32 vcc_lo, 32, v21                           // 00000082AA98: 7C982AA0
	v_cndmask_b32_e32 v21, v1, v21, vcc_lo                     // 00000082AA9C: 022A2B01
	s_waitcnt lgkmcnt(6)                                       // 00000082AAA0: BF89FC67
	v_add_f32_e32 v5, v26, v5                                  // 00000082AAA4: 060A0B1A
	s_waitcnt lgkmcnt(5)                                       // 00000082AAA8: BF89FC57
	v_dual_add_f32 v7, v24, v7 :: v_dual_lshlrev_b32 v10, 2, v10// 00000082AAAC: C9220F18 070A1482
	s_waitcnt lgkmcnt(3)                                       // 00000082AAB4: BF89FC37
	v_dual_add_f32 v9, v22, v9 :: v_dual_add_f32 v4, v27, v4   // 00000082AAB8: C9081316 0904091B
	s_waitcnt lgkmcnt(2)                                       // 00000082AAC0: BF89FC27
	v_dual_add_f32 v6, v25, v6 :: v_dual_lshlrev_b32 v21, 2, v21// 00000082AAC4: C9220D19 06142A82
	ds_bpermute_b32 v11, v10, v3                               // 00000082AACC: DACC0000 0B00030A
	ds_bpermute_b32 v13, v10, v5                               // 00000082AAD4: DACC0000 0D00050A
	s_waitcnt lgkmcnt(3)                                       // 00000082AADC: BF89FC37
	v_add_f32_e32 v8, v23, v8                                  // 00000082AAE0: 06101117
	s_waitcnt lgkmcnt(2)                                       // 00000082AAE4: BF89FC27
	v_add_f32_e32 v2, v17, v2                                  // 00000082AAE8: 06040511
	ds_bpermute_b32 v12, v10, v4                               // 00000082AAEC: DACC0000 0C00040A
	ds_bpermute_b32 v17, v10, v6                               // 00000082AAF4: DACC0000 1100060A
	ds_bpermute_b32 v18, v10, v7                               // 00000082AAFC: DACC0000 1200070A
	ds_bpermute_b32 v20, v10, v9                               // 00000082AB04: DACC0000 1400090A
	s_waitcnt lgkmcnt(5)                                       // 00000082AB0C: BF89FC57
	v_add_f32_e32 v3, v3, v11                                  // 00000082AB10: 06061703
	s_waitcnt lgkmcnt(4)                                       // 00000082AB14: BF89FC47
	v_add_f32_e32 v5, v5, v13                                  // 00000082AB18: 060A1B05
	ds_bpermute_b32 v19, v10, v8                               // 00000082AB1C: DACC0000 1300080A
	ds_bpermute_b32 v10, v10, v2                               // 00000082AB24: DACC0000 0A00020A
	s_waitcnt lgkmcnt(5)                                       // 00000082AB2C: BF89FC57
	v_add_f32_e32 v4, v4, v12                                  // 00000082AB30: 06081904
	s_waitcnt lgkmcnt(3)                                       // 00000082AB34: BF89FC37
	v_dual_add_f32 v6, v6, v17 :: v_dual_add_f32 v7, v7, v18   // 00000082AB38: C9082306 06062507
	s_waitcnt lgkmcnt(2)                                       // 00000082AB40: BF89FC27
	v_add_f32_e32 v9, v9, v20                                  // 00000082AB44: 06122909
	ds_bpermute_b32 v12, v21, v5                               // 00000082AB48: DACC0000 0C000515
	ds_bpermute_b32 v11, v21, v4                               // 00000082AB50: DACC0000 0B000415
	ds_bpermute_b32 v13, v21, v6                               // 00000082AB58: DACC0000 0D000615
	ds_bpermute_b32 v17, v21, v7                               // 00000082AB60: DACC0000 11000715
	s_waitcnt lgkmcnt(5)                                       // 00000082AB68: BF89FC57
	v_add_f32_e32 v8, v8, v19                                  // 00000082AB6C: 06102708
	s_waitcnt lgkmcnt(4)                                       // 00000082AB70: BF89FC47
	v_add_f32_e32 v2, v2, v10                                  // 00000082AB74: 06041502
	ds_bpermute_b32 v10, v21, v3                               // 00000082AB78: DACC0000 0A000315
	ds_bpermute_b32 v19, v21, v9                               // 00000082AB80: DACC0000 13000915
	ds_bpermute_b32 v18, v21, v8                               // 00000082AB88: DACC0000 12000815
	ds_bpermute_b32 v20, v21, v2                               // 00000082AB90: DACC0000 14000215
	v_xor_b32_e32 v21, 2, v1                                   // 00000082AB98: 3A2A0282
	s_waitcnt lgkmcnt(5)                                       // 00000082AB9C: BF89FC57
	v_dual_add_f32 v5, v5, v12 :: v_dual_add_f32 v6, v6, v13   // 00000082ABA0: C9081905 05061B06
	v_add_f32_e32 v4, v4, v11                                  // 00000082ABA8: 06081704
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 00000082ABAC: BF870143
	v_cmp_gt_u32_e32 vcc_lo, 32, v21                           // 00000082ABB0: 7C982AA0
	v_cndmask_b32_e32 v21, v1, v21, vcc_lo                     // 00000082ABB4: 022A2B01
	s_waitcnt lgkmcnt(4)                                       // 00000082ABB8: BF89FC47
	v_add_f32_e32 v7, v7, v17                                  // 00000082ABBC: 060E2307
	v_lshlrev_b32_e32 v21, 2, v21                              // 00000082ABC0: 302A2A82
	s_waitcnt lgkmcnt(3)                                       // 00000082ABC4: BF89FC37
	v_add_f32_e32 v3, v3, v10                                  // 00000082ABC8: 06061503
	s_waitcnt lgkmcnt(1)                                       // 00000082ABCC: BF89FC17
	v_dual_add_f32 v9, v9, v19 :: v_dual_add_f32 v8, v8, v18   // 00000082ABD0: C9082709 09082508
	s_waitcnt lgkmcnt(0)                                       // 00000082ABD8: BF89FC07
	v_add_f32_e32 v10, v2, v20                                 // 00000082ABDC: 06142902
	ds_bpermute_b32 v11, v21, v4                               // 00000082ABE0: DACC0000 0B000415
	ds_bpermute_b32 v2, v21, v3                                // 00000082ABE8: DACC0000 02000315
	ds_bpermute_b32 v12, v21, v5                               // 00000082ABF0: DACC0000 0C000515
	ds_bpermute_b32 v13, v21, v6                               // 00000082ABF8: DACC0000 0D000615
	ds_bpermute_b32 v17, v21, v7                               // 00000082AC00: DACC0000 11000715
	ds_bpermute_b32 v18, v21, v8                               // 00000082AC08: DACC0000 12000815
	ds_bpermute_b32 v19, v21, v9                               // 00000082AC10: DACC0000 13000915
	ds_bpermute_b32 v20, v21, v10                              // 00000082AC18: DACC0000 14000A15
	v_xor_b32_e32 v21, 1, v1                                   // 00000082AC20: 3A2A0281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000082AC24: BF8700A1
	v_cmp_gt_u32_e32 vcc_lo, 32, v21                           // 00000082AC28: 7C982AA0
	v_cndmask_b32_e32 v1, v1, v21, vcc_lo                      // 00000082AC2C: 02022B01
	v_lshlrev_b32_e32 v21, 2, v1                               // 00000082AC30: 302A0282
	s_waitcnt lgkmcnt(6)                                       // 00000082AC34: BF89FC67
	v_dual_add_f32 v1, v3, v2 :: v_dual_add_f32 v2, v4, v11    // 00000082AC38: C9080503 01021704
	s_waitcnt lgkmcnt(4)                                       // 00000082AC40: BF89FC47
	v_dual_add_f32 v4, v5, v12 :: v_dual_add_f32 v5, v6, v13   // 00000082AC44: C9081905 04041B06
	s_waitcnt lgkmcnt(3)                                       // 00000082AC4C: BF89FC37
	v_add_f32_e32 v3, v7, v17                                  // 00000082AC50: 06062307
	s_waitcnt lgkmcnt(1)                                       // 00000082AC54: BF89FC17
	v_dual_add_f32 v11, v8, v18 :: v_dual_add_f32 v12, v9, v19 // 00000082AC58: C9082508 0B0C2709
	s_waitcnt lgkmcnt(0)                                       // 00000082AC60: BF89FC07
	v_add_f32_e32 v13, v10, v20                                // 00000082AC64: 061A290A
	ds_bpermute_b32 v6, v21, v1                                // 00000082AC68: DACC0000 06000115
	ds_bpermute_b32 v7, v21, v2                                // 00000082AC70: DACC0000 07000215
	ds_bpermute_b32 v9, v21, v4                                // 00000082AC78: DACC0000 09000415
	ds_bpermute_b32 v10, v21, v5                               // 00000082AC80: DACC0000 0A000515
	ds_bpermute_b32 v8, v21, v3                                // 00000082AC88: DACC0000 08000315
	ds_bpermute_b32 v17, v21, v11                              // 00000082AC90: DACC0000 11000B15
	ds_bpermute_b32 v18, v21, v12                              // 00000082AC98: DACC0000 12000C15
	ds_bpermute_b32 v19, v21, v13                              // 00000082ACA0: DACC0000 13000D15
	v_cmpx_eq_u32_e32 0, v16                                   // 00000082ACA8: 7D942080
	s_cbranch_execz 17                                         // 00000082ACAC: BFA50011 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi2ELb0ELi2ELi0EEEvPKhPKtPvlllllS6_f+0xef4>
	s_waitcnt lgkmcnt(0)                                       // 00000082ACB0: BF89FC07
	v_dual_add_f32 v13, v13, v19 :: v_dual_add_f32 v12, v12, v18// 00000082ACB4: C908270D 0D0C250C
	v_lshlrev_b32_e32 v19, 5, v15                              // 00000082ACBC: 30261E85
	v_dual_add_f32 v11, v11, v17 :: v_dual_add_f32 v18, v5, v10// 00000082ACC0: C908230B 0B121505
	v_dual_add_f32 v17, v4, v9 :: v_dual_add_f32 v16, v2, v7   // 00000082ACC8: C9081304 11100F02
	v_dual_add_f32 v15, v1, v6 :: v_dual_add_f32 v10, v3, v8   // 00000082ACD0: C9080D01 0F0A1103
	s_delay_alu instid0(VALU_DEP_4)                            // 00000082ACD8: BF870004
	v_lshl_or_b32 v1, v14, 6, v19                              // 00000082ACDC: D6560001 044D0D0E
	ds_store_b128 v1, v[15:18] offset:1024                     // 00000082ACE4: DB7C0400 00000F01
	ds_store_b128 v1, v[10:13] offset:1040                     // 00000082ACEC: DB7C0410 00000A01
	s_or_b32 exec_lo, exec_lo, s0                              // 00000082ACF4: 8C7E007E
	v_lshrrev_b32_e32 v3, 3, v0                                // 00000082ACF8: 32060083
	v_mov_b32_e32 v2, s3                                       // 00000082ACFC: 7E040203
	.long 0xd44c0000                                           // 00000082AD00: D44C0000
	v_cndmask_b32_e32 v1, 32, v0, vcc_lo                       // 00000082AD04: 020200A0
	s_waitcnt lgkmcnt(0)                                       // 00000082AD08: BF89FC07
	s_barrier                                                  // 00000082AD0C: BFBD0000
	v_or_b32_e32 v1, s2, v3                                    // 00000082AD10: 38020602
	buffer_gl0_inv                                             // 00000082AD14: E0AC0000 00000000
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[1:2]                  // 00000082AD1C: 7CA8020C
	s_and_b32 s0, s0, vcc_lo                                   // 00000082AD20: 8B006A00
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000082AD24: BF870009
	s_and_saveexec_b32 s1, s0                                  // 00000082AD28: BE812000
	s_cbranch_execz 76                                         // 00000082AD2C: BFA5004C <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi2ELb0ELi2ELi0EEEvPKhPKtPvlllllS6_f+0x1060>
	v_and_b32_e32 v0, 7, v0                                    // 00000082AD30: 36000087
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000082AD34: BF870091
	v_lshlrev_b32_e32 v4, 2, v0                                // 00000082AD38: 30080082
	v_lshl_or_b32 v3, v3, 6, v4                                // 00000082AD3C: D6560003 04110D03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000082AD44: BF8700C1
	v_add_nc_u32_e32 v3, 0x400, v3                             // 00000082AD48: 4A0606FF 00000400
	ds_load_2addr_b32 v[3:4], v3 offset1:8                     // 00000082AD50: D8DC0800 03000003
	s_waitcnt lgkmcnt(0)                                       // 00000082AD58: BF89FC07
	v_add_f32_e32 v3, 0, v3                                    // 00000082AD5C: 06060680
	v_add_f32_e32 v3, v3, v4                                   // 00000082AD60: 06060903
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000082AD64: BF870091
	v_bfe_u32 v4, v3, 16, 1                                    // 00000082AD68: D6100004 02052103
	v_add3_u32 v3, v3, v4, 0x7fff                              // 00000082AD70: D6550003 03FE0903 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000082AD7C: BF870091
	v_and_b32_e32 v3, 0xffff0000, v3                           // 00000082AD80: 360606FF FFFF0000
	v_mul_f32_e32 v3, 0xbfb8aa3b, v3                           // 00000082AD88: 100606FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000082AD90: BF870291
	v_exp_f32_e32 v3, v3                                       // 00000082AD94: 7E064B03
	v_add_f32_e32 v6, 1.0, v3                                  // 00000082AD98: 060C06F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000082AD9C: BF870121
	v_div_scale_f32 v5, null, v6, v6, 1.0                      // 00000082ADA0: D6FC7C05 03CA0D06
	v_div_scale_f32 v8, vcc_lo, 1.0, v6, 1.0                   // 00000082ADA8: D6FC6A08 03CA0CF2
	v_rcp_f32_e32 v7, v5                                       // 00000082ADB0: 7E0E5505
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000082ADB4: BF870095
	v_fma_f32 v3, -v5, v7, 1.0                                 // 00000082ADB8: D6130003 23CA0F05
	v_fmac_f32_e32 v7, v3, v7                                  // 00000082ADC0: 560E0F03
	v_mad_u64_u32 v[3:4], null, s12, v0, 0                     // 00000082ADC4: D6FE7C03 0202000C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000082ADCC: BF870092
	v_mul_f32_e32 v9, v8, v7                                   // 00000082ADD0: 10120F08
	v_fma_f32 v10, -v5, v9, v8                                 // 00000082ADD4: D613000A 24221305
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000082ADDC: BF870091
	v_fmac_f32_e32 v9, v10, v7                                 // 00000082ADE0: 56120F0A
	v_fma_f32 v8, -v5, v9, v8                                  // 00000082ADE4: D6130008 24221305
	v_mad_u64_u32 v[4:5], null, s13, v0, v[4:5]                // 00000082ADEC: D6FE7C04 0412000D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000082ADF4: BF870112
	v_div_fmas_f32 v0, v8, v7, v9                              // 00000082ADF8: D6370000 04260F08
	.long 0xd73c0003                                           // 00000082AE00: D73C0003
	v_cndmask_b32_e32 v1, 1, v3, vcc_lo                        // 00000082AE04: 02020681
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000082AE08: BF8701A2
	v_div_fixup_f32 v5, v0, v6, 1.0                            // 00000082AE0C: D6270005 03CA0D00
	.long 0xd73c0000                                           // 00000082AE14: D73C0000
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 00000082AE18: 02020281
	.long 0xd7006a03                                           // 00000082AE1C: D7006A03
	v_cndmask_b32_e32 v1, s8, v3, vcc_lo                       // 00000082AE20: 02020608
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000082AE24: BF8701A3
	v_bfe_u32 v2, v5, 16, 1                                    // 00000082AE28: D6100002 02052105
	v_add_co_ci_u32_e64 v4, null, s9, v4, vcc_lo               // 00000082AE30: D5207C04 01AA0809
	.long 0xd7006a00                                           // 00000082AE38: D7006A00
	v_cndmask_b32_e32 v1, v3, v0, vcc_lo                       // 00000082AE3C: 02020103
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000082AE40: BF870193
	v_add3_u32 v2, v5, v2, 0x7fff                              // 00000082AE44: D6550002 03FE0505 00007FFF
	v_add_co_ci_u32_e64 v1, null, v4, v1, vcc_lo               // 00000082AE50: D5207C01 01AA0304
	global_store_d16_hi_b16 v[0:1], v2, off                    // 00000082AE58: DC960000 007C0200
	s_endpgm                                                   // 00000082AE60: BFB00000
		...

