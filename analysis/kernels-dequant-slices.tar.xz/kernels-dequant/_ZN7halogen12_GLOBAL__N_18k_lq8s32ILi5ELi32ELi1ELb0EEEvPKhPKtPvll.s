000000000058af00 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi5ELi32ELi1ELb0EEEvPKhPKtPvll>:
; _ZN7halogen12_GLOBAL__N_18k_lq8s32ILi5ELi32ELi1ELb0EEEvPKhPKtPvll():
	s_clause 0x1                                               // 00000058AF00: BF850001
	s_load_b256 s[4:11], s[0:1], null                          // 00000058AF04: F40C0100 F8000000
	s_load_b64 s[12:13], s[0:1], 0x20                          // 00000058AF0C: F4040300 F8000020
	v_lshrrev_b32_e32 v1, 5, v0                                // 00000058AF14: 32020085
	s_mov_b32 s3, 0                                            // 00000058AF18: BE830080
	v_dual_mov_b32 v16, 0 :: v_dual_and_b32 v15, 31, v0        // 00000058AF1C: CA240080 100E009F
	s_lshl_b64 s[0:1], s[2:3], 3                               // 00000058AF24: 84808302
	.long 0x7e323880                                           // 00000058AF28: 7E323880
	v_or_b32_e32 v9, s0, v1                                    // 00000058AF2C: 38120200
	v_mov_b32_e32 v10, s1                                      // 00000058AF30: 7E140201
	v_dual_mov_b32 v4, 0 :: v_dual_mov_b32 v5, 0               // 00000058AF34: CA100080 04040080
	v_dual_mov_b32 v6, 0 :: v_dual_lshlrev_b32 v11, 4, v15     // 00000058AF3C: CA220080 060A1E84
	s_waitcnt lgkmcnt(0)                                       // 00000058AF44: BF89FC07
	s_ashr_i32 s0, s11, 31                                     // 00000058AF48: 86009F0B
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[9:10]                 // 00000058AF4C: 7CA8120C
	s_lshr_b32 s0, s0, 28                                      // 00000058AF50: 85009C00
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000058AF54: BF8704A9
	s_add_u32 s2, s10, s0                                      // 00000058AF58: 8002000A
	s_addc_u32 s3, s11, 0                                      // 00000058AF5C: 8203800B
	s_ashr_i64 s[2:3], s[2:3], 4                               // 00000058AF60: 86828402
	v_cndmask_b32_e32 v1, 0, v9, vcc_lo                        // 00000058AF64: 02021280
	s_add_u32 s0, s10, s2                                      // 00000058AF68: 8000020A
	v_cndmask_b32_e64 v2, 0, s1, vcc_lo                        // 00000058AF6C: D5010002 01A80280
	s_addc_u32 s1, s11, s3                                     // 00000058AF74: 8201030B
	s_add_u32 s0, s0, 15                                       // 00000058AF78: 80008F00
	s_addc_u32 s1, s1, 0                                       // 00000058AF7C: 82018001
	s_and_b32 s0, s0, -16                                      // 00000058AF80: 8B00D000
	.long 0xd72c0003                                           // 00000058AF84: D72C0003
	v_cndmask_b32_e32 v0, v1, v1, vcc_lo                       // 00000058AF88: 02000301
	.long 0xd72c0007                                           // 00000058AF8C: D72C0007
	v_cndmask_b32_e32 v0, v2, v0, vcc_lo                       // 00000058AF90: 02000102
	v_mad_u64_u32 v[1:2], null, v1, s0, 0                      // 00000058AF94: D6FE7C01 02000101
	.long 0xd4440000                                           // 00000058AF9C: D4440000
	v_cndmask_b32_e32 v1, s2, v15, vcc_lo                      // 00000058AFA0: 02021E02
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000058AFA4: BF870192
	v_add3_u32 v2, v2, v3, v7                                  // 00000058AFA8: D6550002 041E0702
	.long 0xd7000111                                           // 00000058AFB0: D7000111
	v_cndmask_b32_e32 v1, s4, v1, vcc_lo                       // 00000058AFB4: 02020204
	v_mov_b32_e32 v7, 0                                        // 00000058AFB8: 7E0E0280
	s_delay_alu instid0(VALU_DEP_3)                            // 00000058AFBC: BF870003
	v_add_co_ci_u32_e64 v18, null, s5, v2, s1                  // 00000058AFC0: D5207C12 00060405
	s_and_saveexec_b32 s3, s0                                  // 00000058AFC8: BE832000
	s_cbranch_execz 21                                         // 00000058AFCC: BFA50015 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi5ELi32ELi1ELb0EEEvPKhPKtPvll+0x124>
	v_lshlrev_b32_e32 v3, 4, v15                               // 00000058AFD0: 30061E84
	.long 0xd7000105                                           // 00000058AFD4: D7000105
	v_cndmask_b32_e32 v0, v17, v10, vcc_lo                     // 00000058AFD8: 02001511
	v_and_b32_e32 v7, 30, v0                                   // 00000058AFDC: 360E009E
	v_add_co_ci_u32_e64 v6, null, s11, v18, s1                 // 00000058AFE0: D5207C06 0006240B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000058AFE8: BF870094
	.long 0xd7000103                                           // 00000058AFEC: D7000103
	v_cndmask_b32_e32 v1, v17, v3, vcc_lo                      // 00000058AFF0: 02020711
	v_add_co_ci_u32_e64 v4, null, 0, v18, s1                   // 00000058AFF4: D5207C04 00062480
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000058AFFC: BF870094
	.long 0xd700010c                                           // 00000058B000: D700010C
	v_cndmask_b32_e32 v1, v5, v7, vcc_lo                       // 00000058B004: 02020F05
	v_add_co_ci_u32_e64 v13, null, 0, v6, s1                   // 00000058B008: D5207C0D 00060C80
	s_clause 0x1                                               // 00000058B010: BF850001
	global_load_b128 v[4:7], v[3:4], off                       // 00000058B014: DC5E0000 047C0003
	global_load_d16_b16 v25, v[12:13], off                     // 00000058B01C: DC820000 197C000C
	s_or_b32 exec_lo, exec_lo, s3                              // 00000058B024: 8C7E037E
	v_dual_mov_b32 v19, 0 :: v_dual_mov_b32 v20, 0             // 00000058B028: CA100080 13140080
	v_dual_mov_b32 v21, 0 :: v_dual_mov_b32 v22, 0             // 00000058B030: CA100080 15160080
	s_and_saveexec_b32 s3, s0                                  // 00000058B038: BE832000
	s_cbranch_execz 472                                        // 00000058B03C: BFA501D8 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi5ELi32ELi1ELb0EEEvPKhPKtPvll+0x8a0>
	v_and_or_b32 v0, v0, 30, 32                                // 00000058B040: D6570000 02813D00
	.long 0xd7000001                                           // 00000058B048: D7000001
	v_cndmask_b32_e32 v1, s10, v1, vcc_lo                      // 00000058B04C: 0202020A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000058B050: BF8701A1
	v_add_co_ci_u32_e64 v2, null, s11, v2, s0                  // 00000058B054: D5207C02 0002040B
	v_dual_mov_b32 v12, 0 :: v_dual_mov_b32 v23, v15           // 00000058B05C: CA100080 0C16010F
	.long 0xd7000000                                           // 00000058B064: D7000000
	v_cndmask_b32_e32 v1, v1, v0, vcc_lo                       // 00000058B068: 02020101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000058B06C: BF870191
	v_add_co_ci_u32_e64 v1, null, 0, v2, s0                    // 00000058B070: D5207C01 00020480
	v_mov_b32_e32 v22, v12                                     // 00000058B078: 7E2C030C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000058B07C: BF870093
	.long 0xd700000d                                           // 00000058B080: D700000D
	v_cndmask_b32_e32 v1, s4, v0, vcc_lo                       // 00000058B084: 02020004
	v_add_co_ci_u32_e64 v14, null, s5, v1, s0                  // 00000058B088: D5207C0E 00020205
	v_mov_b32_e32 v21, v12                                     // 00000058B090: 7E2A030C
	v_mov_b32_e32 v20, v12                                     // 00000058B094: 7E28030C
	v_mov_b32_e32 v19, v12                                     // 00000058B098: 7E26030C
	v_mov_b32_e32 v16, v12                                     // 00000058B09C: 7E20030C
	s_mul_i32 s1, s11, 6                                       // 00000058B0A0: 9601860B
	s_mul_hi_u32 s16, s10, 6                                   // 00000058B0A4: 9690860A
	s_lshl_b64 s[14:15], s[10:11], 2                           // 00000058B0A8: 848E820A
	s_add_i32 s16, s16, s1                                     // 00000058B0AC: 81100110
	s_mul_i32 s18, s10, 6                                      // 00000058B0B0: 9612860A
	s_mov_b32 s17, 0                                           // 00000058B0B4: BE910080
	s_lshl_b64 s[4:5], s[10:11], 1                             // 00000058B0B8: 8484810A
	s_branch 410                                               // 00000058B0BC: BFA0019A <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi5ELi32ELi1ELb0EEEvPKhPKtPvll+0x828>
	s_or_b32 exec_lo, exec_lo, s10                             // 00000058B0C0: 8C7E0A7E
	v_bfe_i32 v26, v4, 0, 8                                    // 00000058B0C4: D611001A 02210104
	s_and_b32 s0, exec_lo, s0                                  // 00000058B0CC: 8B00007E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000058B0D0: BF870099
	s_or_b32 s17, s0, s17                                      // 00000058B0D4: 8C111100
	v_cvt_f32_i32_e32 v26, v26                                 // 00000058B0D8: 7E340B1A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000058B0DC: BF870091
	v_fma_mix_f32 v26, v25, v26, neg(0) op_sel_hi:[1,0,0]      // 00000058B0E0: CC20001A 8A023519
	v_bfe_u32 v27, v26, 16, 1                                  // 00000058B0E8: D610001B 0205211A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000058B0F0: BF870121
	v_add3_u32 v26, v26, v27, 0x7fff                           // 00000058B0F4: D655001A 03FE371A 00007FFF
	.long 0x7f363880                                           // 00000058B100: 7F363880
	.long 0x7e36399a                                           // 00000058B104: 7E36399A
	v_bfe_i32 v26, v4, 8, 8                                    // 00000058B108: D611001A 02211104
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000058B110: BF870091
	v_cvt_f32_i32_e32 v26, v26                                 // 00000058B114: 7E340B1A
	v_fma_mix_f32 v26, v25, v26, neg(0) op_sel_hi:[1,0,0]      // 00000058B118: CC20001A 8A023519
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000058B120: BF870091
	v_bfe_u32 v28, v26, 16, 1                                  // 00000058B124: D610001C 0205211A
	v_add3_u32 v26, v26, v28, 0x7fff                           // 00000058B12C: D655001A 03FE391A 00007FFF
	v_bfe_i32 v28, v4, 16, 8                                   // 00000058B138: D611001C 02212104
	v_ashrrev_i32_e32 v4, 24, v4                               // 00000058B140: 34080898
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000058B144: BF870193
	v_and_or_b32 v33, 0xffff0000, v26, v27                     // 00000058B148: D6570021 046E34FF FFFF0000
	v_cvt_f32_i32_e32 v28, v28                                 // 00000058B154: 7E380B1C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000058B158: BF870113
	v_cvt_f32_i32_e32 v4, v4                                   // 00000058B15C: 7E080B04
	v_fma_mix_f32 v28, v25, v28, neg(0) op_sel_hi:[1,0,0]      // 00000058B160: CC20001C 8A023919
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000058B168: BF870112
	v_fma_mix_f32 v4, v25, v4, neg(0) op_sel_hi:[1,0,0]        // 00000058B16C: CC200004 8A020919
	v_bfe_u32 v29, v28, 16, 1                                  // 00000058B174: D610001D 0205211C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000058B17C: BF870191
	v_add3_u32 v28, v28, v29, 0x7fff                           // 00000058B180: D655001C 03FE3B1C 00007FFF
	v_bfe_u32 v29, v4, 16, 1                                   // 00000058B18C: D610001D 02052104
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000058B194: BF8701A2
	.long 0x7e38399c                                           // 00000058B198: 7E38399C
	.long 0x7f38399b                                           // 00000058B19C: 7F38399B
	v_add3_u32 v4, v4, v29, 0x7fff                             // 00000058B1A0: D6550004 03FE3B04 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000058B1AC: BF8700A1
	v_and_or_b32 v34, 0xffff0000, v4, v28                      // 00000058B1B0: D6570022 047208FF FFFF0000
	v_bfe_i32 v4, v5, 0, 8                                     // 00000058B1BC: D6110004 02210105
	v_cvt_f32_i32_e32 v4, v4                                   // 00000058B1C4: 7E080B04
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000058B1C8: BF870091
	v_fma_mix_f32 v4, v25, v4, neg(0) op_sel_hi:[1,0,0]        // 00000058B1CC: CC200004 8A020919
	v_bfe_u32 v26, v4, 16, 1                                   // 00000058B1D4: D610001A 02052104
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000058B1DC: BF870091
	v_add3_u32 v4, v4, v26, 0x7fff                             // 00000058B1E0: D6550004 03FE3504 00007FFF
	.long 0x7e363984                                           // 00000058B1EC: 7E363984
	v_bfe_i32 v4, v5, 8, 8                                     // 00000058B1F0: D6110004 02211105
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000058B1F8: BF870091
	v_cvt_f32_i32_e32 v4, v4                                   // 00000058B1FC: 7E080B04
	v_fma_mix_f32 v4, v25, v4, neg(0) op_sel_hi:[1,0,0]        // 00000058B200: CC200004 8A020919
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000058B208: BF870091
	v_bfe_u32 v26, v4, 16, 1                                   // 00000058B20C: D610001A 02052104
	v_add3_u32 v4, v4, v26, 0x7fff                             // 00000058B214: D6550004 03FE3504 00007FFF
	v_bfe_i32 v26, v5, 16, 8                                   // 00000058B220: D611001A 02212105
	v_ashrrev_i32_e32 v5, 24, v5                               // 00000058B228: 340A0A98
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000058B22C: BF870193
	v_and_or_b32 v35, 0xffff0000, v4, v27                      // 00000058B230: D6570023 046E08FF FFFF0000
	v_cvt_f32_i32_e32 v26, v26                                 // 00000058B23C: 7E340B1A
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000058B240: BF8701A3
	v_cvt_f32_i32_e32 v5, v5                                   // 00000058B244: 7E0A0B05
	v_bfe_i32 v4, v6, 0, 8                                     // 00000058B248: D6110004 02210106
	v_fma_mix_f32 v26, v25, v26, neg(0) op_sel_hi:[1,0,0]      // 00000058B250: CC20001A 8A023519
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000058B258: BF870193
	v_fma_mix_f32 v5, v25, v5, neg(0) op_sel_hi:[1,0,0]        // 00000058B25C: CC200005 8A020B19
	v_cvt_f32_i32_e32 v4, v4                                   // 00000058B264: 7E080B04
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000058B268: BF870113
	v_bfe_u32 v28, v26, 16, 1                                  // 00000058B26C: D610001C 0205211A
	v_fma_mix_f32 v4, v25, v4, neg(0) op_sel_hi:[1,0,0]        // 00000058B274: CC200004 8A020919
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000058B27C: BF870122
	v_add3_u32 v26, v26, v28, 0x7fff                           // 00000058B280: D655001A 03FE391A 00007FFF
	v_bfe_u32 v28, v5, 16, 1                                   // 00000058B28C: D610001C 02052105
	.long 0x7e34399a                                           // 00000058B294: 7E34399A
	.long 0x7f34399b                                           // 00000058B298: 7F34399B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000058B29C: BF870093
	v_add3_u32 v5, v5, v28, 0x7fff                             // 00000058B2A0: D6550005 03FE3905 00007FFF
	v_and_or_b32 v36, 0xffff0000, v5, v26                      // 00000058B2AC: D6570024 046A0AFF FFFF0000
	v_bfe_u32 v5, v4, 16, 1                                    // 00000058B2B8: D6100005 02052104
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000058B2C0: BF870091
	v_add3_u32 v4, v4, v5, 0x7fff                              // 00000058B2C4: D6550004 03FE0B04 00007FFF
	.long 0x7e363984                                           // 00000058B2D0: 7E363984
	v_bfe_i32 v4, v6, 8, 8                                     // 00000058B2D4: D6110004 02211106
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000058B2DC: BF870091
	v_cvt_f32_i32_e32 v4, v4                                   // 00000058B2E0: 7E080B04
	v_fma_mix_f32 v4, v25, v4, neg(0) op_sel_hi:[1,0,0]        // 00000058B2E4: CC200004 8A020919
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000058B2EC: BF870091
	v_bfe_u32 v5, v4, 16, 1                                    // 00000058B2F0: D6100005 02052104
	v_add3_u32 v4, v4, v5, 0x7fff                              // 00000058B2F8: D6550004 03FE0B04 00007FFF
	v_bfe_i32 v5, v6, 16, 8                                    // 00000058B304: D6110005 02212106
	v_ashrrev_i32_e32 v6, 24, v6                               // 00000058B30C: 340C0C98
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000058B310: BF870193
	v_and_or_b32 v37, 0xffff0000, v4, v27                      // 00000058B314: D6570025 046E08FF FFFF0000
	v_cvt_f32_i32_e32 v5, v5                                   // 00000058B320: 7E0A0B05
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000058B324: BF8701A3
	v_cvt_f32_i32_e32 v6, v6                                   // 00000058B328: 7E0C0B06
	v_bfe_i32 v4, v7, 0, 8                                     // 00000058B32C: D6110004 02210107
	v_fma_mix_f32 v5, v25, v5, neg(0) op_sel_hi:[1,0,0]        // 00000058B334: CC200005 8A020B19
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000058B33C: BF870193
	v_fma_mix_f32 v6, v25, v6, neg(0) op_sel_hi:[1,0,0]        // 00000058B340: CC200006 8A020D19
	v_cvt_f32_i32_e32 v4, v4                                   // 00000058B348: 7E080B04
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000058B34C: BF870113
	v_bfe_u32 v26, v5, 16, 1                                   // 00000058B350: D610001A 02052105
	v_fma_mix_f32 v4, v25, v4, neg(0) op_sel_hi:[1,0,0]        // 00000058B358: CC200004 8A020919
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000058B360: BF870122
	v_add3_u32 v5, v5, v26, 0x7fff                             // 00000058B364: D6550005 03FE3505 00007FFF
	v_bfe_u32 v26, v6, 16, 1                                   // 00000058B370: D610001A 02052106
	.long 0x7e0a3985                                           // 00000058B378: 7E0A3985
	.long 0x7f0a399b                                           // 00000058B37C: 7F0A399B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000058B380: BF870093
	v_add3_u32 v6, v6, v26, 0x7fff                             // 00000058B384: D6550006 03FE3506 00007FFF
	v_and_or_b32 v38, 0xffff0000, v6, v5                       // 00000058B390: D6570026 04160CFF FFFF0000
	v_bfe_u32 v5, v4, 16, 1                                    // 00000058B39C: D6100005 02052104
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000058B3A4: BF870091
	v_add3_u32 v4, v4, v5, 0x7fff                              // 00000058B3A8: D6550004 03FE0B04 00007FFF
	.long 0x7e363984                                           // 00000058B3B4: 7E363984
	v_bfe_i32 v4, v7, 8, 8                                     // 00000058B3B8: D6110004 02211107
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000058B3C0: BF870091
	v_cvt_f32_i32_e32 v4, v4                                   // 00000058B3C4: 7E080B04
	v_fma_mix_f32 v4, v25, v4, neg(0) op_sel_hi:[1,0,0]        // 00000058B3C8: CC200004 8A020919
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000058B3D0: BF870091
	v_bfe_u32 v5, v4, 16, 1                                    // 00000058B3D4: D6100005 02052104
	v_add3_u32 v4, v4, v5, 0x7fff                              // 00000058B3DC: D6550004 03FE0B04 00007FFF
	v_bfe_i32 v5, v7, 16, 8                                    // 00000058B3E8: D6110005 02212107
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000058B3F0: BF870112
	v_and_or_b32 v39, 0xffff0000, v4, v27                      // 00000058B3F4: D6570027 046E08FF FFFF0000
	v_cvt_f32_i32_e32 v5, v5                                   // 00000058B400: 7E0A0B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000058B404: BF870091
	v_fma_mix_f32 v5, v25, v5, neg(0) op_sel_hi:[1,0,0]        // 00000058B408: CC200005 8A020B19
	v_bfe_u32 v6, v5, 16, 1                                    // 00000058B410: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000058B418: BF870121
	v_add3_u32 v5, v5, v6, 0x7fff                              // 00000058B41C: D6550005 03FE0D05 00007FFF
	v_ashrrev_i32_e32 v6, 24, v7                               // 00000058B428: 340C0E98
	.long 0x7e0a3985                                           // 00000058B42C: 7E0A3985
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000058B430: BF870122
	v_cvt_f32_i32_e32 v6, v6                                   // 00000058B434: 7E0C0B06
	.long 0x7f0a399b                                           // 00000058B438: 7F0A399B
	v_fma_mix_f32 v6, v25, v6, neg(0) op_sel_hi:[1,0,0]        // 00000058B43C: CC200006 8A020D19
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000058B444: BF870091
	v_bfe_u32 v7, v6, 16, 1                                    // 00000058B448: D6100007 02052106
	v_add3_u32 v6, v6, v7, 0x7fff                              // 00000058B450: D6550006 03FE0F06 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000058B45C: BF870131
	v_and_or_b32 v40, 0xffff0000, v6, v5                       // 00000058B460: D6570028 04160CFF FFFF0000
	.long 0xd73c0004                                           // 00000058B46C: D73C0004
	v_cndmask_b32_e32 v1, 1, v11, vcc_lo                       // 00000058B470: 02021681
	v_mov_b32_e32 v11, v24                                     // 00000058B474: 7E160318
	.long 0xd700001d                                           // 00000058B478: D700001D
	v_cndmask_b32_e32 v1, s6, v4, vcc_lo                       // 00000058B47C: 02020806
	s_delay_alu instid0(VALU_DEP_1)                            // 00000058B480: BF870001
	v_add_co_ci_u32_e64 v30, null, s7, v5, s0                  // 00000058B484: D5207C1E 00020A07
	s_clause 0x1                                               // 00000058B48C: BF850001
	global_load_b128 v[4:7], v[29:30], off                     // 00000058B490: DC5E0000 047C001D
	global_load_b128 v[25:28], v[29:30], off offset:16         // 00000058B498: DC5E0010 197C001D
	s_waitcnt vmcnt(1)                                         // 00000058B4A0: BF8907F7
	v_dot2_f32_bf16 v4, v4, v33, 0                             // 00000058B4A4: CC1A4004 1A024304
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000058B4AC: BF870091
	v_dot2_f32_bf16 v4, v5, v34, v4                            // 00000058B4B0: CC1A4004 1C124505
	v_dot2_f32_bf16 v4, v6, v35, v4                            // 00000058B4B8: CC1A4004 1C124706
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000058B4C0: BF8700A1
	v_dot2_f32_bf16 v4, v7, v36, v4                            // 00000058B4C4: CC1A4004 1C124907
	s_waitcnt vmcnt(0)                                         // 00000058B4CC: BF8903F7
	v_dot2_f32_bf16 v4, v25, v37, v4                           // 00000058B4D0: CC1A4004 1C124B19
	.long 0xd7000019                                           // 00000058B4D8: D7000019
	v_cndmask_b32_e32 v0, v29, v4, vcc_lo                      // 00000058B4DC: 0200091D
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000058B4E0: BF8701B2
	v_dot2_f32_bf16 v4, v26, v38, v4                           // 00000058B4E4: CC1A4004 1C124D1A
	v_add_co_ci_u32_e64 v26, null, s5, v30, s0                 // 00000058B4EC: D5207C1A 00023C05
	.long 0xd700001f                                           // 00000058B4F4: D700001F
	v_cndmask_b32_e32 v0, v29, v14, vcc_lo                     // 00000058B4F8: 02001D1D
	v_dot2_f32_bf16 v4, v27, v39, v4                           // 00000058B4FC: CC1A4004 1C124F1B
	v_add_co_ci_u32_e64 v32, null, s15, v30, s0                // 00000058B504: D5207C20 00023C0F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000058B50C: BF870092
	v_dot2_f32_bf16 v4, v28, v40, v4                           // 00000058B510: CC1A4004 1C12511C
	v_add_f32_e32 v22, v22, v4                                 // 00000058B518: 062C0916
	s_clause 0x1                                               // 00000058B51C: BF850001
	global_load_b128 v[4:7], v[25:26], off                     // 00000058B520: DC5E0000 047C0019
	global_load_b128 v[25:28], v[25:26], off offset:16         // 00000058B528: DC5E0010 197C0019
	s_waitcnt vmcnt(1)                                         // 00000058B530: BF8907F7
	v_dot2_f32_bf16 v4, v4, v33, 0                             // 00000058B534: CC1A4004 1A024304
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000058B53C: BF870091
	v_dot2_f32_bf16 v4, v5, v34, v4                            // 00000058B540: CC1A4004 1C124505
	v_dot2_f32_bf16 v4, v6, v35, v4                            // 00000058B548: CC1A4004 1C124706
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000058B550: BF8700A1
	v_dot2_f32_bf16 v4, v7, v36, v4                            // 00000058B554: CC1A4004 1C124907
	s_waitcnt vmcnt(0)                                         // 00000058B55C: BF8903F7
	v_dot2_f32_bf16 v4, v25, v37, v4                           // 00000058B560: CC1A4004 1C124B19
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000058B568: BF870091
	v_dot2_f32_bf16 v4, v26, v38, v4                           // 00000058B56C: CC1A4004 1C124D1A
	v_dot2_f32_bf16 v4, v27, v39, v4                           // 00000058B574: CC1A4004 1C124F1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000058B57C: BF870091
	v_dot2_f32_bf16 v4, v28, v40, v4                           // 00000058B580: CC1A4004 1C12511C
	v_add_f32_e32 v21, v21, v4                                 // 00000058B588: 062A0915
	s_clause 0x1                                               // 00000058B58C: BF850001
	global_load_b128 v[4:7], v[31:32], off                     // 00000058B590: DC5E0000 047C001F
	global_load_b128 v[25:28], v[31:32], off offset:16         // 00000058B598: DC5E0010 197C001F
	s_waitcnt vmcnt(1)                                         // 00000058B5A0: BF8907F7
	v_dot2_f32_bf16 v4, v4, v33, 0                             // 00000058B5A4: CC1A4004 1A024304
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000058B5AC: BF870091
	v_dot2_f32_bf16 v4, v5, v34, v4                            // 00000058B5B0: CC1A4004 1C124505
	v_dot2_f32_bf16 v4, v6, v35, v4                            // 00000058B5B8: CC1A4004 1C124706
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000058B5C0: BF8700A1
	v_dot2_f32_bf16 v4, v7, v36, v4                            // 00000058B5C4: CC1A4004 1C124907
	s_waitcnt vmcnt(0)                                         // 00000058B5CC: BF8903F7
	v_dot2_f32_bf16 v4, v25, v37, v4                           // 00000058B5D0: CC1A4004 1C124B19
	.long 0xd7000019                                           // 00000058B5D8: D7000019
	v_cndmask_b32_e32 v0, v29, v18, vcc_lo                     // 00000058B5DC: 0200251D
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000058B5E0: BF870122
	v_dot2_f32_bf16 v4, v26, v38, v4                           // 00000058B5E4: CC1A4004 1C124D1A
	v_add_co_ci_u32_e64 v26, null, s16, v30, s0                // 00000058B5EC: D5207C1A 00023C10
	v_dot2_f32_bf16 v4, v27, v39, v4                           // 00000058B5F4: CC1A4004 1C124F1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000058B5FC: BF870091
	v_dot2_f32_bf16 v4, v28, v40, v4                           // 00000058B600: CC1A4004 1C12511C
	v_add_f32_e32 v20, v20, v4                                 // 00000058B608: 06280914
	s_clause 0x1                                               // 00000058B60C: BF850001
	global_load_b128 v[4:7], v[25:26], off                     // 00000058B610: DC5E0000 047C0019
	global_load_b128 v[25:28], v[25:26], off offset:16         // 00000058B618: DC5E0010 197C0019
	s_waitcnt vmcnt(1)                                         // 00000058B620: BF8907F7
	v_dot2_f32_bf16 v4, v4, v33, 0                             // 00000058B624: CC1A4004 1A024304
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000058B62C: BF870091
	v_dot2_f32_bf16 v4, v5, v34, v4                            // 00000058B630: CC1A4004 1C124505
	v_dot2_f32_bf16 v4, v6, v35, v4                            // 00000058B638: CC1A4004 1C124706
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000058B640: BF8700A1
	v_dot2_f32_bf16 v4, v7, v36, v4                            // 00000058B644: CC1A4004 1C124907
	s_waitcnt vmcnt(0)                                         // 00000058B64C: BF8903F7
	v_dot2_f32_bf16 v4, v25, v37, v4                           // 00000058B650: CC1A4004 1C124B19
	.long 0xd7000019                                           // 00000058B658: D7000019
	v_cndmask_b32_e32 v0, v31, v14, vcc_lo                     // 00000058B65C: 02001D1F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000058B660: BF8701B2
	v_dot2_f32_bf16 v4, v26, v38, v4                           // 00000058B664: CC1A4004 1C124D1A
	v_add_co_ci_u32_e64 v26, null, s15, v32, s0                // 00000058B66C: D5207C1A 0002400F
	.long 0xd700000d                                           // 00000058B674: D700000D
	v_cndmask_b32_e32 v0, v13, v160, vcc_lo                    // 00000058B678: 0201410D
	v_dot2_f32_bf16 v4, v27, v39, v4                           // 00000058B67C: CC1A4004 1C124F1B
	v_add_co_ci_u32_e64 v14, null, 0, v14, s0                  // 00000058B684: D5207C0E 00021C80
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000058B68C: BF870092
	v_dot2_f32_bf16 v4, v28, v40, v4                           // 00000058B690: CC1A4004 1C12511C
	v_add_f32_e32 v19, v19, v4                                 // 00000058B698: 06260913
	s_clause 0x1                                               // 00000058B69C: BF850001
	global_load_b128 v[4:7], v[25:26], off                     // 00000058B6A0: DC5E0000 047C0019
	global_load_b128 v[25:28], v[25:26], off offset:16         // 00000058B6A8: DC5E0010 197C0019
	s_waitcnt vmcnt(1)                                         // 00000058B6B0: BF8907F7
	v_dot2_f32_bf16 v4, v4, v33, 0                             // 00000058B6B4: CC1A4004 1A024304
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000058B6BC: BF870121
	v_dot2_f32_bf16 v4, v5, v34, v4                            // 00000058B6C0: CC1A4004 1C124505
	v_mov_b32_e32 v5, v1                                       // 00000058B6C8: 7E0A0301
	v_dot2_f32_bf16 v4, v6, v35, v4                            // 00000058B6CC: CC1A4004 1C124706
	v_mov_b32_e32 v6, v2                                       // 00000058B6D4: 7E0C0302
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000058B6D8: BF870132
	v_dot2_f32_bf16 v4, v7, v36, v4                            // 00000058B6DC: CC1A4004 1C124907
	v_mov_b32_e32 v7, v3                                       // 00000058B6E4: 7E0E0303
	s_waitcnt vmcnt(0)                                         // 00000058B6E8: BF8903F7
	v_dot2_f32_bf16 v4, v25, v37, v4                           // 00000058B6EC: CC1A4004 1C124B19
	.long 0x7e323908                                           // 00000058B6F4: 7E323908
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000058B6F8: BF870092
	v_dot2_f32_bf16 v4, v26, v38, v4                           // 00000058B6FC: CC1A4004 1C124D1A
	v_dot2_f32_bf16 v4, v27, v39, v4                           // 00000058B704: CC1A4004 1C124F1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000058B70C: BF870091
	v_dot2_f32_bf16 v4, v28, v40, v4                           // 00000058B710: CC1A4004 1C12511C
	v_add_f32_e32 v16, v16, v4                                 // 00000058B718: 06200910
	v_mov_b32_e32 v4, v0                                       // 00000058B71C: 7E080300
	s_and_not1_b32 exec_lo, exec_lo, s17                       // 00000058B720: 917E117E
	s_cbranch_execz 29                                         // 00000058B724: BFA5001D <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi5ELi32ELi1ELb0EEEvPKhPKtPvll+0x89c>
	v_add_nc_u32_e32 v23, 32, v23                              // 00000058B728: 4A2E2EA0
	v_add_nc_u32_e32 v24, 0x200, v11                           // 00000058B72C: 4A3016FF 00000200
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000058B734: BF8704A2
	.long 0xd4430000                                           // 00000058B738: D4430000
	v_cndmask_b32_e32 v1, s2, v23, vcc_lo                      // 00000058B73C: 02022E02
	s_and_saveexec_b32 s1, s0                                  // 00000058B740: BE812000
	s_xor_b32 s1, exec_lo, s1                                  // 00000058B744: 8D01017E
	v_add_nc_u32_e32 v24, 0x200, v11                           // 00000058B748: 4A3016FF 00000200
	s_or_saveexec_b32 s10, s1                                  // 00000058B750: BE8A2201
	s_waitcnt vmcnt(0)                                         // 00000058B754: BF8903F7
	.long 0x7e103919                                           // 00000058B758: 7E103919
	v_dual_mov_b32 v0, v4 :: v_dual_mov_b32 v1, v5             // 00000058B75C: CA100104 00000105
	v_dual_mov_b32 v2, v6 :: v_dual_mov_b32 v3, v7             // 00000058B764: CA100106 02020107
	s_xor_b32 exec_lo, exec_lo, s10                            // 00000058B76C: 8D7E0A7E
	s_cbranch_execz 65107                                      // 00000058B770: BFA5FE53 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi5ELi32ELi1ELb0EEEvPKhPKtPvll+0x1c0>
	.long 0xd7000100                                           // 00000058B774: D7000100
	v_cndmask_b32_e32 v1, v17, v24, vcc_lo                     // 00000058B778: 02023111
	s_delay_alu instid0(VALU_DEP_1)                            // 00000058B77C: BF870001
	v_add_co_ci_u32_e64 v1, null, 0, v18, s1                   // 00000058B780: D5207C01 00062480
	global_load_b128 v[0:3], v[0:1], off                       // 00000058B788: DC5E0000 007C0000
	global_load_d16_b16 v8, v[13:14], off                      // 00000058B790: DC820000 087C000D
	s_branch 65097                                             // 00000058B798: BFA0FE49 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi5ELi32ELi1ELb0EEEvPKhPKtPvll+0x1c0>
	s_or_b32 exec_lo, exec_lo, s17                             // 00000058B79C: 8C7E117E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000058B7A0: BF8700A9
	s_or_b32 exec_lo, exec_lo, s3                              // 00000058B7A4: 8C7E037E
	.long 0xd71f0000                                           // 00000058B7A8: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 00000058B7AC: 020100C1
	v_xor_b32_e32 v1, 16, v0                                   // 00000058B7B0: 3A020090
	s_waitcnt vmcnt(1)                                         // 00000058B7B4: BF8907F7
	v_xor_b32_e32 v6, 8, v0                                    // 00000058B7B8: 3A0C0088
	v_xor_b32_e32 v13, 4, v0                                   // 00000058B7BC: 3A1A0084
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000058B7C0: BF870093
	.long 0xd44c0000                                           // 00000058B7C4: D44C0000
	v_cndmask_b32_e32 v1, 32, v1, vcc_lo                       // 00000058B7C8: 020202A0
	v_cndmask_b32_e64 v1, v0, v1, s0                           // 00000058B7CC: D5010001 00020300
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000058B7D4: BF870114
	.long 0xd44c0000                                           // 00000058B7D8: D44C0000
	v_cndmask_b32_e32 v1, 32, v6, vcc_lo                       // 00000058B7DC: 02020CA0
	v_lshlrev_b32_e32 v1, 2, v1                                // 00000058B7E0: 30020282
	s_delay_alu instid0(VALU_DEP_2)                            // 00000058B7E4: BF870002
	v_cndmask_b32_e64 v6, v0, v6, s0                           // 00000058B7E8: D5010006 00020D00
	.long 0xd44c0000                                           // 00000058B7F0: D44C0000
	v_cndmask_b32_e32 v1, 32, v13, vcc_lo                      // 00000058B7F4: 02021AA0
	ds_bpermute_b32 v2, v1, v22                                // 00000058B7F8: DACC0000 02001601
	v_cndmask_b32_e64 v13, v0, v13, s0                         // 00000058B800: D501000D 00021B00
	s_waitcnt lgkmcnt(0)                                       // 00000058B808: BF89FC07
	v_add_f32_e32 v2, v22, v2                                  // 00000058B80C: 06040516
	ds_bpermute_b32 v3, v1, v21                                // 00000058B810: DACC0000 03001501
	ds_bpermute_b32 v4, v1, v20                                // 00000058B818: DACC0000 04001401
	ds_bpermute_b32 v5, v1, v19                                // 00000058B820: DACC0000 05001301
	ds_bpermute_b32 v1, v1, v16                                // 00000058B828: DACC0000 01001001
	s_waitcnt lgkmcnt(3)                                       // 00000058B830: BF89FC37
	v_dual_add_f32 v3, v21, v3 :: v_dual_lshlrev_b32 v6, 2, v6 // 00000058B834: C9220715 03060C82
	ds_bpermute_b32 v7, v6, v2                                 // 00000058B83C: DACC0000 07000206
	s_waitcnt lgkmcnt(2)                                       // 00000058B844: BF89FC27
	v_dual_add_f32 v4, v20, v4 :: v_dual_add_f32 v5, v19, v5   // 00000058B848: C9080914 04040B13
	s_waitcnt lgkmcnt(1)                                       // 00000058B850: BF89FC17
	v_add_f32_e32 v1, v16, v1                                  // 00000058B854: 06020310
	ds_bpermute_b32 v8, v6, v3                                 // 00000058B858: DACC0000 08000306
	ds_bpermute_b32 v11, v6, v4                                // 00000058B860: DACC0000 0B000406
	ds_bpermute_b32 v12, v6, v5                                // 00000058B868: DACC0000 0C000506
	s_waitcnt lgkmcnt(3)                                       // 00000058B870: BF89FC37
	v_dual_add_f32 v2, v2, v7 :: v_dual_lshlrev_b32 v13, 2, v13// 00000058B874: C9220F02 020C1A82
	ds_bpermute_b32 v6, v6, v1                                 // 00000058B87C: DACC0000 06000106
	s_waitcnt lgkmcnt(0)                                       // 00000058B884: BF89FC07
	v_dual_add_f32 v4, v4, v11 :: v_dual_add_f32 v1, v1, v6    // 00000058B888: C9081704 04000D01
	ds_bpermute_b32 v6, v13, v2                                // 00000058B890: DACC0000 0600020D
	v_add_f32_e32 v3, v3, v8                                   // 00000058B898: 06061103
	ds_bpermute_b32 v8, v13, v4                                // 00000058B89C: DACC0000 0800040D
	s_waitcnt lgkmcnt(1)                                       // 00000058B8A4: BF89FC17
	v_dual_add_f32 v2, v2, v6 :: v_dual_add_f32 v5, v5, v12    // 00000058B8A8: C9080D02 02041905
	ds_bpermute_b32 v7, v13, v3                                // 00000058B8B0: DACC0000 0700030D
	s_waitcnt lgkmcnt(1)                                       // 00000058B8B8: BF89FC17
	v_add_f32_e32 v4, v4, v8                                   // 00000058B8BC: 06081104
	ds_bpermute_b32 v12, v13, v1                               // 00000058B8C0: DACC0000 0C00010D
	v_xor_b32_e32 v6, 1, v0                                    // 00000058B8C8: 3A0C0081
	ds_bpermute_b32 v11, v13, v5                               // 00000058B8CC: DACC0000 0B00050D
	v_xor_b32_e32 v13, 2, v0                                   // 00000058B8D4: 3A1A0082
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000058B8D8: BF870091
	.long 0xd44c0000                                           // 00000058B8DC: D44C0000
	v_cndmask_b32_e32 v1, 32, v13, vcc_lo                      // 00000058B8E0: 02021AA0
	v_cndmask_b32_e64 v13, v0, v13, s0                         // 00000058B8E4: D501000D 00021B00
	.long 0xd44c0000                                           // 00000058B8EC: D44C0000
	v_cndmask_b32_e32 v1, 32, v6, vcc_lo                       // 00000058B8F0: 02020CA0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000058B8F4: BF870112
	v_lshlrev_b32_e32 v13, 2, v13                              // 00000058B8F8: 301A1A82
	v_cndmask_b32_e64 v0, v0, v6, s0                           // 00000058B8FC: D5010000 00020D00
	s_waitcnt lgkmcnt(1)                                       // 00000058B904: BF89FC17
	v_dual_add_f32 v8, v1, v12 :: v_dual_add_f32 v3, v3, v7    // 00000058B908: C9081901 08020F03
	.long 0xd44a0000                                           // 00000058B910: D44A0000
	v_cndmask_b32_e32 v1, 0, v15, vcc_lo                       // 00000058B914: 02021E80
	ds_bpermute_b32 v1, v13, v2                                // 00000058B918: DACC0000 0100020D
	v_lshlrev_b32_e32 v14, 2, v0                               // 00000058B920: 301C0082
	ds_bpermute_b32 v7, v13, v3                                // 00000058B924: DACC0000 0700030D
	s_and_b32 s0, s0, vcc_lo                                   // 00000058B92C: 8B006A00
	s_waitcnt lgkmcnt(1)                                       // 00000058B930: BF89FC17
	v_dual_add_f32 v6, v2, v1 :: v_dual_add_f32 v5, v5, v11    // 00000058B934: C9080302 06041705
	ds_bpermute_b32 v11, v13, v4                               // 00000058B93C: DACC0000 0B00040D
	s_waitcnt lgkmcnt(1)                                       // 00000058B944: BF89FC17
	v_add_f32_e32 v7, v3, v7                                   // 00000058B948: 060E0F03
	ds_bpermute_b32 v12, v13, v5                               // 00000058B94C: DACC0000 0C00050D
	ds_bpermute_b32 v13, v13, v8                               // 00000058B954: DACC0000 0D00080D
	s_waitcnt lgkmcnt(2)                                       // 00000058B95C: BF89FC27
	v_add_f32_e32 v0, v4, v11                                  // 00000058B960: 06001704
	ds_bpermute_b32 v11, v14, v7                               // 00000058B964: DACC0000 0B00070E
	s_waitcnt lgkmcnt(1)                                       // 00000058B96C: BF89FC17
	v_dual_add_f32 v4, v8, v13 :: v_dual_add_f32 v1, v5, v12   // 00000058B970: C9081B08 04001905
	ds_bpermute_b32 v8, v14, v6                                // 00000058B978: DACC0000 0800060E
	ds_bpermute_b32 v2, v14, v0                                // 00000058B980: DACC0000 0200000E
	ds_bpermute_b32 v5, v14, v4                                // 00000058B988: DACC0000 0500040E
	ds_bpermute_b32 v3, v14, v1                                // 00000058B990: DACC0000 0300010E
	s_and_saveexec_b32 s1, s0                                  // 00000058B998: BE812000
	s_cbranch_execz 71                                         // 00000058B99C: BFA50047 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi5ELi32ELi1ELb0EEEvPKhPKtPvll+0xbbc>
	s_waitcnt lgkmcnt(3)                                       // 00000058B9A0: BF89FC37
	v_dual_add_f32 v11, v7, v11 :: v_dual_add_f32 v8, v6, v8   // 00000058B9A4: C9081707 0B081106
	.long 0x7f183880                                           // 00000058B9AC: 7F183880
	.long 0xd73c0006                                           // 00000058B9B0: D73C0006
	v_cndmask_b32_e32 v1, 1, v9, vcc_lo                        // 00000058B9B4: 02021281
	s_waitcnt lgkmcnt(0)                                       // 00000058B9B8: BF89FC07
	v_add_f32_e32 v3, v1, v3                                   // 00000058B9BC: 06060701
	.long 0x7e18398b                                           // 00000058B9C0: 7E18398B
	.long 0x7e1a3988                                           // 00000058B9C4: 7E1A3988
	.long 0x7f1a398c                                           // 00000058B9C8: 7F1A398C
	v_add_f32_e32 v10, v4, v5                                  // 00000058B9CC: 06140B04
	.long 0xd7006a04                                           // 00000058B9D0: D7006A04
	v_cndmask_b32_e32 v1, s8, v6, vcc_lo                       // 00000058B9D4: 02020C08
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000058B9D8: BF8701B3
	v_dual_add_f32 v2, v0, v2 :: v_dual_and_b32 v13, 1, v13    // 00000058B9DC: C9240500 020C1A81
	v_add_co_ci_u32_e64 v5, null, s9, v7, vcc_lo               // 00000058B9E4: D5207C05 01AA0E09
	.long 0x7f00398c                                           // 00000058B9EC: 7F00398C
	.long 0x7e003982                                           // 00000058B9F0: 7E003982
	s_lshl_b64 s[0:1], s[12:13], 1                             // 00000058B9F4: 8480810C
	v_and_b32_e32 v9, 1, v12                                   // 00000058B9F8: 36121881
	.long 0x7e183983                                           // 00000058B9FC: 7E183983
	.long 0xd7006a06                                           // 00000058BA00: D7006A06
	v_cndmask_b32_e32 v0, v4, v0, vcc_lo                       // 00000058BA04: 02000104
	v_and_b32_e32 v14, 1, v0                                   // 00000058BA08: 361C0081
	v_mad_u64_u32 v[0:1], null, s12, 6, v[4:5]                 // 00000058BA0C: D6FE7C00 04110C0C
	v_add_co_ci_u32_e64 v7, null, s1, v5, vcc_lo               // 00000058BA14: D5207C07 01AA0A01
	s_lshl_b64 s[0:1], s[12:13], 2                             // 00000058BA1C: 8480820C
	v_add3_u32 v13, v8, v13, 0x7fff                            // 00000058BA20: D655000D 03FE1B08 00007FFF
	.long 0xd7006a08                                           // 00000058BA2C: D7006A08
	v_cndmask_b32_e32 v0, v4, v0, vcc_lo                       // 00000058BA30: 02000104
	v_and_b32_e32 v12, 1, v12                                  // 00000058BA34: 36181881
	v_add3_u32 v11, v11, v9, 0x7fff                            // 00000058BA38: D655000B 03FE130B 00007FFF
	v_bfe_u32 v15, v10, 16, 1                                  // 00000058BA44: D610000F 0205210A
	v_add_co_ci_u32_e64 v9, null, s1, v5, vcc_lo               // 00000058BA4C: D5207C09 01AA0A01
	v_add3_u32 v14, v2, v14, 0x7fff                            // 00000058BA54: D655000E 03FE1D02 00007FFF
	v_mad_u64_u32 v[1:2], null, s13, 6, v[1:2]                 // 00000058BA60: D6FE7C01 04050C0D
	.long 0xd7006a02                                           // 00000058BA68: D7006A02
	v_cndmask_b32_e32 v0, v8, v0, vcc_lo                       // 00000058BA6C: 02000108
	v_add3_u32 v12, v3, v12, 0x7fff                            // 00000058BA70: D655000C 03FE1903 00007FFF
	v_add3_u32 v10, v10, v15, 0x7fff                           // 00000058BA7C: D655000A 03FE1F0A 00007FFF
	v_add_co_ci_u32_e64 v3, null, s1, v9, vcc_lo               // 00000058BA88: D5207C03 01AA1201
	s_clause 0x4                                               // 00000058BA90: BF850004
	global_store_d16_hi_b16 v[4:5], v13, off                   // 00000058BA94: DC960000 007C0D04
	global_store_d16_hi_b16 v[6:7], v11, off                   // 00000058BA9C: DC960000 007C0B06
	global_store_d16_hi_b16 v[8:9], v14, off                   // 00000058BAA4: DC960000 007C0E08
	global_store_d16_hi_b16 v[0:1], v12, off                   // 00000058BAAC: DC960000 007C0C00
	global_store_d16_hi_b16 v[2:3], v10, off                   // 00000058BAB4: DC960000 007C0A02
	s_endpgm                                                   // 00000058BABC: BFB00000
		...

