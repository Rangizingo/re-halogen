000000000051ff00 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb1ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_>:
; _ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb1ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_():
	s_clause 0x3                                               // 00000051FF00: BF850003
	s_load_b256 s[20:27], s[0:1], null                         // 00000051FF04: F40C0500 F8000000
	s_load_b256 s[12:19], s[0:1], 0x20                         // 00000051FF0C: F40C0300 F8000020
	s_load_b128 s[28:31], s[0:1], 0x40                         // 00000051FF14: F4080700 F8000040
	s_load_b32 s33, s[0:1], 0x54                               // 00000051FF1C: F4000840 F8000054
	v_and_b32_e32 v10, 31, v0                                  // 00000051FF24: 3614009F
	v_lshrrev_b32_e32 v8, 5, v0                                // 00000051FF28: 32100085
	s_mov_b32 s4, s3                                           // 00000051FF2C: BE840003
	s_mov_b32 s10, exec_lo                                     // 00000051FF30: BE8A007E
	s_delay_alu instid0(VALU_DEP_2)                            // 00000051FF34: BF870002
	v_lshlrev_b32_e32 v9, 2, v10                               // 00000051FF38: 30121482
	s_waitcnt lgkmcnt(0)                                       // 00000051FF3C: BF89FC07
	s_ashr_i32 s34, s25, 31                                    // 00000051FF40: 86229F19
	s_mul_i32 s35, s27, s3                                     // 00000051FF44: 9623031B
	s_lshr_b32 s0, s34, 25                                     // 00000051FF48: 85009922
	s_add_i32 s1, s35, s27                                     // 00000051FF4C: 81011B23
	s_add_i32 s0, s25, s0                                      // 00000051FF50: 81000019
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000051FF54: BF870499
	s_ashr_i32 s0, s0, 7                                       // 00000051FF58: 86008700
	s_min_i32 s0, s0, s1                                       // 00000051FF5C: 89000100
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000051FF60: BF870499
	s_sub_i32 s11, s0, s35                                     // 00000051FF64: 818B2300
	.long 0xd4c4007e                                           // 00000051FF68: D4C4007E
	v_cndmask_b32_e32 v1, s11, v8, vcc_lo                      // 00000051FF6C: 0202100B
	s_cbranch_execz 501                                        // 00000051FF70: BFA501F5 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb1ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x848>
	s_add_i32 s27, s24, -1                                     // 00000051FF74: 811BC118
	s_cmp_lg_u64 s[30:31], 0                                   // 00000051FF78: BF11801E
	v_dual_mov_b32 v11, v8 :: v_dual_and_b32 v2, 2, v0         // 00000051FF7C: CA240108 0B020082
	s_cselect_b32 s36, -1, 0                                   // 00000051FF84: 982480C1
	s_abs_i32 s37, s11                                         // 00000051FF88: BEA5150B
	v_lshlrev_b32_e32 v6, 3, v10                               // 00000051FF8C: 300C1483
	s_cvt_f32_u32 s0, s37                                      // 00000051FF90: BE806525
	v_and_b32_e32 v1, 1, v0                                    // 00000051FF94: 36020081
	v_and_b32_e32 v4, 4, v0                                    // 00000051FF98: 36080084
	v_and_b32_e32 v5, 8, v0                                    // 00000051FF9C: 360A0088
	v_rcp_iflag_f32_e32 v3, s0                                 // 00000051FFA0: 7E065600
	v_add_nc_u32_e32 v7, s35, v8                               // 00000051FFA4: 4A0E1023
	.long 0xd44a0003                                           // 00000051FFA8: D44A0003
	v_cndmask_b32_e32 v1, 0, v2, vcc_lo                        // 00000051FFAC: 02020480
	v_lshl_or_b32 v2, v8, 8, v6                                // 00000051FFB0: D6560002 04191108
	s_ashr_i32 s41, s11, 31                                    // 00000051FFB8: 86299F0B
	s_sub_i32 s9, 0, s37                                       // 00000051FFBC: 81892580
	s_mul_i32 s43, s41, 0x1400                                 // 00000051FFC0: 962BFF29 00001400
	.long 0xd44c0000                                           // 00000051FFC8: D44C0000
	v_cndmask_b32_e32 v1, 16, v10, vcc_lo                      // 00000051FFCC: 02021490
	.long 0xd44a0001                                           // 00000051FFD0: D44A0001
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 00000051FFD4: 02020280
	.long 0xd44a0006                                           // 00000051FFD8: D44A0006
	v_cndmask_b32_e32 v1, 0, v5, vcc_lo                        // 00000051FFDC: 02020A80
	v_readfirstlane_b32 s5, v3                                 // 00000051FFE0: 7E0A0503
	v_lshl_or_b32 v1, v7, 7, v9                                // 00000051FFE4: D6560001 04250F07
	v_subrev_nc_u32_e32 v12, s43, v2                           // 00000051FFEC: 4E18042B
	s_lshl_b32 s7, s11, 7                                      // 00000051FFF0: 8407870B
	s_mov_b32 s38, s25                                         // 00000051FFF4: BEA60019
	s_mul_f32 s8, s5, 0x4f7ffffe                               // 00000051FFF8: A208FF05 4F7FFFFE
	.long 0xd44a0005                                           // 000000520000: D44A0005
	v_cndmask_b32_e32 v1, 0, v4, vcc_lo                        // 000000520004: 02020880
	s_mov_b32 s39, 0                                           // 000000520008: BEA70080
	s_mov_b32 s40, 0x76543210                                  // 00000052000C: BEA800FF 76543210
	s_cvt_u32_f32 s8, s8                                       // 000000520014: BE886708
	s_lshl_b32 s42, s11, 8                                     // 000000520018: 842A880B
	s_sub_i32 s43, 0, s7                                       // 00000052001C: 81AB0780
	s_mov_b32 s45, 0x3db504f3                                  // 000000520020: BEAD00FF 3DB504F3
	s_mul_i32 s9, s9, s8                                       // 000000520028: 96090809
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000052002C: BF870499
	s_mul_hi_u32 s9, s8, s9                                    // 000000520030: 96890908
	s_add_i32 s44, s8, s9                                      // 000000520034: 812C0908
	s_branch 164                                               // 000000520038: BFA000A4 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb1ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x3cc>
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000052003C: BF870091
	.long 0xd7006a02                                           // 000000520040: D7006A02
	v_cndmask_b32_e32 v1, s12, v2, vcc_lo                      // 000000520044: 0202040C
	v_add_co_ci_u32_e64 v3, null, s13, v3, vcc_lo              // 000000520048: D5207C03 01AA060D
	v_add_nc_u32_e32 v1, 0x400, v1                             // 000000520050: 4A0202FF 00000400
	global_load_d16_b16 v2, v[2:3], off offset:6               // 000000520058: DC820006 027C0002
	s_waitcnt vmcnt(0)                                         // 000000520060: BF8903F7
	v_fma_mix_f32 v5, v17, v2, v15 op_sel_hi:[0,1,0]           // 000000520064: CC200005 143E0511
	v_sub_f32_e32 v4, v18, v16                                 // 00000052006C: 08082112
	v_fma_mix_f32 v2, -v17, v2, v15 op_sel_hi:[0,1,0]          // 000000520070: CC200002 343E0511
	v_add_f32_e32 v3, v18, v16                                 // 000000520078: 06062112
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000052007C: BF8701A2
	v_add_f32_e32 v7, v4, v2                                   // 000000520080: 060E0504
	v_sub_f32_e32 v2, v4, v2                                   // 000000520084: 08040504
	v_add_f32_e32 v6, v3, v5                                   // 000000520088: 060C0B03
	v_sub_f32_e32 v3, v3, v5                                   // 00000052008C: 08060B03
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000520090: BF870193
	v_mov_b32_dpp v16, v2 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000520094: 7E2002FA FF016102
	v_mov_b32_dpp v4, v6 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000052009C: 7E0802FA FF016106
	v_cndmask_b32_e64 v6, -v6, v6, s1                          // 0000005200A4: D5010006 20060D06
	v_cndmask_b32_e64 v2, -v2, v2, s1                          // 0000005200AC: D5010002 20060502
	v_mov_b32_dpp v15, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000005200B4: 7E1E02FA FF016103
	v_cndmask_b32_e64 v3, -v3, v3, s1                          // 0000005200BC: D5010003 20060703
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000005200C4: BF870144
	v_add_f32_e32 v4, v6, v4                                   // 0000005200C8: 06080906
	v_mov_b32_dpp v5, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000005200CC: 7E0A02FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, s1                          // 0000005200D4: D5010007 20060F07
	.long 0xd72c0006                                           // 0000005200DC: D72C0006
	v_cndmask_b32_e32 v1, 0x1400, v14, vcc_lo                  // 0000005200E0: 02021CFF 00001400
	v_dual_add_f32 v2, v2, v16 :: v_dual_add_f32 v5, v7, v5    // 0000005200E8: C9082102 02040B07
	v_mov_b32_dpp v7, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000005200F0: 7E0E02FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, s3                          // 0000005200F8: D5010004 200E0904
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000520100: BF8701C3
	v_mov_b32_dpp v16, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000520104: 7E2002FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, s3                          // 00000052010C: D5010002 200E0502
	v_mov_b32_dpp v14, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000520114: 7E1C02FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, s3                          // 00000052011C: D5010005 200E0B05
	v_dual_add_f32 v3, v3, v15 :: v_dual_add_f32 v2, v2, v16   // 000000520124: C9081F03 03022102
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000052012C: BF870112
	v_add_f32_e32 v5, v5, v14                                  // 000000520130: 060A1D05
	v_mov_b32_dpp v15, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000520134: 7E1E02FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, s3                          // 00000052013C: D5010003 200E0703
	s_delay_alu instid0(VALU_DEP_4)                            // 000000520144: BF870004
	v_mov_b32_dpp v16, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000520148: 7E2002FA FF016402
	v_cndmask_b32_e64 v2, -v2, v2, s5                          // 000000520150: D5010002 20160502
	v_mov_b32_dpp v14, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000520158: 7E1C02FA FF016405
	v_cndmask_b32_e64 v5, -v5, v5, s5                          // 000000520160: D5010005 20160B05
	v_add_f32_e32 v4, v4, v7                                   // 000000520168: 06080F04
	.long 0xd72c0007                                           // 00000052016C: D72C0007
	v_cndmask_b32_e32 v1, s42, v13, vcc_lo                     // 000000520170: 02021A2A
	v_dual_add_f32 v2, v2, v16 :: v_dual_add_nc_u32 v11, 8, v11// 000000520174: C9202102 020A1688
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000052017C: BF870214
	v_add_f32_e32 v5, v5, v14                                  // 000000520180: 060A1D05
	v_mov_b32_dpp v13, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000520184: 7E1A02FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s5                          // 00000052018C: D5010004 20160904
	v_add_f32_e32 v3, v3, v15                                  // 000000520194: 06061F03
	v_mov_b32_dpp v16, v2 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000520198: 7E2002FA FF016802
	v_mov_b32_dpp v14, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000005201A0: 7E1C02FA FF016805
	v_cndmask_b32_e64 v5, -v5, v5, s6                          // 0000005201A8: D5010005 201A0B05
	v_add_f32_e32 v4, v4, v13                                  // 0000005201B0: 06081B04
	v_mov_b32_dpp v15, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000005201B4: 7E1E02FA FF016403
	v_cndmask_b32_e64 v3, -v3, v3, s5                          // 0000005201BC: D5010003 20160703
	v_cndmask_b32_e64 v2, -v2, v2, s6                          // 0000005201C4: D5010002 201A0502
	v_add_f32_e32 v5, v5, v14                                  // 0000005201CC: 060A1D05
	v_mov_b32_dpp v13, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000005201D0: 7E1A02FA FF016804
	v_cndmask_b32_e64 v4, -v4, v4, s6                          // 0000005201D8: D5010004 201A0904
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000005201E0: BF870214
	v_dual_add_f32 v3, v3, v15 :: v_dual_add_f32 v2, v2, v16   // 0000005201E4: C9081F03 03022102
	v_mov_b32_e32 v14, v5                                      // 0000005201EC: 7E1C0305
	v_cndmask_b32_e64 v5, -v5, v5, s0                          // 0000005201F0: D5010005 20020B05
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000005201F8: BF870214
	v_add_f32_e32 v4, v4, v13                                  // 0000005201FC: 06081B04
	v_mov_b32_dpp v15, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000520200: 7E1E02FA FF016803
	v_cndmask_b32_e64 v3, -v3, v3, s6                          // 000000520208: D5010003 201A0703
	v_mov_b32_e32 v16, v2                                      // 000000520210: 7E200302
	v_cndmask_b32_e64 v2, -v2, v2, s0                          // 000000520214: D5010002 20020502
	v_mov_b32_e32 v13, v4                                      // 00000052021C: 7E1A0304
	v_cndmask_b32_e64 v4, -v4, v4, s0                          // 000000520220: D5010004 20020904
	v_add_f32_e32 v3, v3, v15                                  // 000000520228: 06061F03
	v_permlanex16_b32 v14, v14, s40, 0xfedcba98                // 00000052022C: D65C000E 03FC510E FEDCBA98
	v_permlanex16_b32 v16, v16, s40, 0xfedcba98                // 000000520238: D65C0010 03FC5110 FEDCBA98
	v_permlanex16_b32 v13, v13, s40, 0xfedcba98                // 000000520244: D65C000D 03FC510D FEDCBA98
	v_sub_nc_u32_e32 v6, v6, v7                                // 000000520250: 4C0C0F06
	v_mov_b32_e32 v15, v3                                      // 000000520254: 7E1E0303
	v_cndmask_b32_e64 v3, -v3, v3, s0                          // 000000520258: D5010003 20020703
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000520260: BF870214
	v_dual_add_f32 v5, v5, v14 :: v_dual_add_f32 v4, v4, v13   // 000000520264: C9081D05 05041B04
	v_dual_add_f32 v7, v2, v16 :: v_dual_add_nc_u32 v6, v12, v6// 00000052026C: C9202102 07060D0C
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000520274: BF870224
	v_permlanex16_b32 v15, v15, s40, 0xfedcba98                // 000000520278: D65C000F 03FC510F FEDCBA98
	v_cmp_le_i32_e32 vcc_lo, s11, v11                          // 000000520284: 7C86160B
	v_fma_mixlo_f16 v2, v4, s45, 0                             // 000000520288: CC210002 02005B04
	v_add_nc_u32_e32 v12, 0x800, v12                           // 000000520290: 4A1818FF 00000800
	v_fma_mixhi_f16 v2, v5, s45, 0                             // 000000520298: CC220002 02005B05
	v_add_f32_e32 v13, v3, v15                                 // 0000005202A0: 061A1F03
	v_fma_mixhi_f16 v3, v7, s45, 0                             // 0000005202A4: CC220003 02005B07
	s_or_b32 s39, vcc_lo, s39                                  // 0000005202AC: 8C27276A
	s_delay_alu instid0(VALU_DEP_2)                            // 0000005202B0: BF870002
	v_fma_mixlo_f16 v3, v13, s45, 0                            // 0000005202B4: CC210003 02005B0D
	ds_store_b64 v6, v[2:3]                                    // 0000005202BC: D9340000 00000206
	s_and_not1_b32 exec_lo, exec_lo, s39                       // 0000005202C4: 917E277E
	s_cbranch_execz 287                                        // 0000005202C8: BFA5011F <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb1ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x848>
	.long 0xd72d0002                                           // 0000005202CC: D72D0002
	v_cndmask_b32_e32 v0, v11, v44, vcc_lo                     // 0000005202D0: 0200590B
	s_mov_b32 s7, -1                                           // 0000005202D4: BE8700C1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005202D8: BF870091
	.long 0xd72c0003                                           // 0000005202DC: D72C0003
	v_cndmask_b32_e32 v0, v2, v37, vcc_lo                      // 0000005202E0: 02004B02
	v_sub_nc_u32_e32 v3, v11, v3                               // 0000005202E4: 4C06070B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000005202E8: BF870121
	v_subrev_nc_u32_e32 v5, s37, v3                            // 0000005202EC: 4E0A0625
	v_cmp_le_u32_e32 vcc_lo, s37, v3                           // 0000005202F0: 7C960625
	v_dual_cndmask_b32 v3, v3, v5 :: v_dual_add_nc_u32 v4, 1, v2// 0000005202F4: CA600B03 03040481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000005202FC: BF870111
	v_cndmask_b32_e32 v2, v2, v4, vcc_lo                       // 000000520300: 02040902
	v_cmp_le_u32_e32 vcc_lo, s37, v3                           // 000000520304: 7C960625
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000520308: BF870092
	v_add_nc_u32_e32 v4, 1, v2                                 // 00000052030C: 4A080481
	v_cndmask_b32_e32 v2, v2, v4, vcc_lo                       // 000000520310: 02040902
	s_and_not1_b32 vcc_lo, exec_lo, s36                        // 000000520314: 916A247E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000520318: BF870091
	v_xor_b32_e32 v14, s41, v2                                 // 00000052031C: 3A1C0429
	v_subrev_nc_u32_e32 v13, s41, v14                          // 000000520320: 4E1A1C29
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000520324: BF8700A1
	v_mad_u64_u32 v[6:7], null, s43, v13, v[1:2]               // 000000520328: D6FE7C06 04061A2B
	v_min_i32_e32 v2, s27, v13                                 // 000000520330: 22041A1B
	v_mad_i64_i32 v[4:5], null, v2, s38, 0                     // 000000520334: D6FF7C04 02004D02
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000052033C: BF870093
	v_ashrrev_i32_e32 v7, 31, v6                               // 000000520340: 340E0C9F
	.long 0xd73c0002                                           // 000000520344: D73C0002
	v_cndmask_b32_e32 v1, 1, v6, vcc_lo                        // 000000520348: 02020C81
	s_cbranch_vccnz 210                                        // 00000052034C: BFA400D2 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb1ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x798>
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000520350: BF870093
	.long 0xd7006a06                                           // 000000520354: D7006A06
	v_cndmask_b32_e32 v1, v4, v6, vcc_lo                       // 000000520358: 02020D04
	v_add_co_ci_u32_e64 v7, null, v5, v7, vcc_lo               // 00000052035C: D5207C07 01AA0F05
	.long 0x7f3e3880                                           // 000000520364: 7F3E3880
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000520368: BF870112
	.long 0xd73c0006                                           // 00000052036C: D73C0006
	v_cndmask_b32_e32 v1, 1, v6, vcc_lo                        // 000000520370: 02020C81
	.long 0x7f44399f                                           // 000000520374: 7F44399F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000520378: BF870092
	.long 0xd7006a0f                                           // 00000052037C: D7006A0F
	v_cndmask_b32_e32 v1, s22, v6, vcc_lo                      // 000000520380: 02020C16
	v_add_co_ci_u32_e64 v16, null, s23, v7, vcc_lo             // 000000520384: D5207C10 01AA0E17
	.long 0xd7006a06                                           // 00000052038C: D7006A06
	v_cndmask_b32_e32 v1, s30, v6, vcc_lo                      // 000000520390: 02020C1E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000520394: BF870001
	v_add_co_ci_u32_e64 v7, null, s31, v7, vcc_lo              // 000000520398: D5207C07 01AA0E1F
	global_load_b64 v[15:16], v[15:16], off                    // 0000005203A0: DC560000 0F7C000F
	.long 0xd7006a11                                           // 0000005203A8: D7006A11
	v_cndmask_b32_e32 v1, s12, v2, vcc_lo                      // 0000005203AC: 0202040C
	global_load_b64 v[6:7], v[6:7], off                        // 0000005203B0: DC560000 067C0006
	v_add_co_ci_u32_e64 v18, null, s13, v3, vcc_lo             // 0000005203B8: D5207C12 01AA060D
	s_clause 0x1                                               // 0000005203C0: BF850001
	global_load_b32 v19, v[17:18], off                         // 0000005203C4: DC520000 137C0011
	global_load_d16_b16 v17, v[17:18], off offset:4            // 0000005203CC: DC820004 117C0011
	s_waitcnt vmcnt(3)                                         // 0000005203D4: BF890FF7
	.long 0x7e24390f                                           // 0000005203D8: 7E24390F
	s_waitcnt vmcnt(2)                                         // 0000005203DC: BF890BF7
	v_and_b32_e32 v41, 0xffff0000, v6                          // 0000005203E0: 36520CFF FFFF0000
	v_lshlrev_b32_e32 v6, 16, v6                               // 0000005203E8: 300C0C90
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005203EC: BF870093
	v_lshlrev_b32_e32 v18, 16, v18                             // 0000005203F0: 30242490
	v_mul_f32_e32 v22, 0xbfb8aa3b, v18                         // 0000005203F4: 102C24FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000005203FC: BF870291
	v_exp_f32_e32 v22, v22                                     // 000000520400: 7E2C4B16
	v_dual_add_f32 v22, 1.0, v22 :: v_dual_and_b32 v15, 0xffff0000, v15// 000000520404: C9242CF2 160E1EFF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000520410: BF870111
	v_mul_f32_e32 v21, 0xbfb8aa3b, v15                         // 000000520414: 102A1EFF BFB8AA3B
	v_div_scale_f32 v26, null, v22, v22, v18                   // 00000052041C: D6FC7C1A 044A2D16
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000520424: BF8701B2
	v_exp_f32_e32 v21, v21                                     // 000000520428: 7E2A4B15
	v_lshlrev_b32_e32 v20, 16, v16                             // 00000052042C: 30282090
	v_div_scale_f32 v39, s8, v18, v22, v18                     // 000000520430: D6FC0827 044A2D12
	v_rcp_f32_e32 v30, v26                                     // 000000520438: 7E3C551A
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000052043C: BF870196
	v_add_f32_e32 v21, 1.0, v21                                // 000000520440: 062A2AF2
	v_mul_f32_e32 v23, 0xbfb8aa3b, v20                         // 000000520444: 102E28FF BFB8AA3B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000052044C: BF870195
	v_fma_f32 v38, -v26, v30, 1.0                              // 000000520450: D6130026 23CA3D1A
	v_div_scale_f32 v25, null, v21, v21, v15                   // 000000520458: D6FC7C19 043E2B15
	s_delay_alu instid0(VALU_DEP_3)                            // 000000520460: BF870003
	v_exp_f32_e32 v23, v23                                     // 000000520464: 7E2E4B17
	v_and_b32_e32 v16, 0xffff0000, v16                         // 000000520468: 362020FF FFFF0000
	v_div_scale_f32 v35, vcc_lo, v15, v21, v15                 // 000000520470: D6FC6A23 043E2B0F
	v_fmac_f32_e32 v30, v38, v30                               // 000000520478: 563C3D26
	v_rcp_f32_e32 v28, v25                                     // 00000052047C: 7E385519
	s_delay_alu instid0(TRANS32_DEP_2) | instid1(VALU_DEP_3)   // 000000520480: BF870186
	v_dual_add_f32 v23, 1.0, v23 :: v_dual_mul_f32 v24, 0xbfb8aa3b, v16// 000000520484: C9062EF2 171820FF BFB8AA3B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000520490: BF870115
	v_fma_f32 v36, -v25, v28, 1.0                              // 000000520494: D6130024 23CA3919
	v_div_scale_f32 v27, null, v23, v23, v20                   // 00000052049C: D6FC7C1B 04522F17
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000005204A4: BF8701A3
	v_exp_f32_e32 v24, v24                                     // 0000005204A8: 7E304B18
	v_div_scale_f32 v37, s7, v20, v23, v20                     // 0000005204AC: D6FC0725 04522F14
	v_fmac_f32_e32 v28, v36, v28                               // 0000005204B4: 56383924
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 0000005204B8: BF870313
	v_rcp_f32_e32 v32, v27                                     // 0000005204BC: 7E40551B
	v_add_f32_e32 v24, 1.0, v24                                // 0000005204C0: 063030F2
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000005204C4: BF870115
	v_fma_f32 v40, -v27, v32, 1.0                              // 0000005204C8: D6130028 23CA411B
	v_div_scale_f32 v29, null, v24, v24, v16                   // 0000005204D0: D6FC7C1D 04423118
	v_div_scale_f32 v38, s9, v16, v24, v16                     // 0000005204D8: D6FC0926 04423110
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000005204E0: BF870193
	v_fmac_f32_e32 v32, v40, v32                               // 0000005204E4: 56404128
	v_rcp_f32_e32 v33, v29                                     // 0000005204E8: 7E42551D
	v_mul_f32_e32 v40, v35, v28                                // 0000005204EC: 10503923
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000005204F0: BF870112
	v_mul_f32_e32 v42, v37, v32                                // 0000005204F4: 10544125
	v_fma_f32 v43, -v25, v40, v35                              // 0000005204F8: D613002B 248E5119
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000520500: BF870292
	v_fma_f32 v46, -v27, v42, v37                              // 000000520504: D613002E 2496551B
	v_fma_f32 v36, -v29, v33, 1.0                              // 00000052050C: D6130024 23CA431D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000520514: BF870113
	v_fmac_f32_e32 v40, v43, v28                               // 000000520518: 5650392B
	v_dual_fmac_f32 v42, v46, v32 :: v_dual_fmac_f32 v33, v36, v33// 00000052051C: C800412E 2A204324
	v_mul_f32_e32 v36, v39, v30                                // 000000520524: 10483D27
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000520528: BF870193
	v_fma_f32 v25, -v25, v40, v35                              // 00000052052C: D6130019 248E5119
	v_fma_f32 v27, -v27, v42, v37                              // 000000520534: D613001B 2496551B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000052053C: BF870214
	v_mul_f32_e32 v44, v38, v33                                // 000000520540: 10584326
	v_fma_f32 v45, -v26, v36, v39                              // 000000520544: D613002D 249E491A
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000052054C: BF8701A4
	v_div_fmas_f32 v25, v25, v28, v40                          // 000000520550: D6370019 04A23919
	s_mov_b32 vcc_lo, s8                                       // 000000520558: BEEA0008
	v_fma_f32 v43, -v29, v44, v38                              // 00000052055C: D613002B 249A591D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000520564: BF870193
	v_fmac_f32_e32 v36, v45, v30                               // 000000520568: 56483D2D
	v_div_fixup_f32 v15, v25, v21, v15                         // 00000052056C: D627000F 043E2B19
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000520574: BF870193
	v_fmac_f32_e32 v44, v43, v33                               // 000000520578: 5658432B
	v_fma_f32 v26, -v26, v36, v39                              // 00000052057C: D613001A 249E491A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000520584: BF870193
	v_mul_f32_e32 v15, v15, v41                                // 000000520588: 101E530F
	v_fma_f32 v25, -v29, v44, v38                              // 00000052058C: D6130019 249A591D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000520594: BF8701A3
	v_div_fmas_f32 v26, v26, v30, v36                          // 000000520598: D637001A 04923D1A
	s_mov_b32 vcc_lo, s7                                       // 0000005205A0: BEEA0007
	.long 0x7e3e398f                                           // 0000005205A4: 7E3E398F
	v_div_fmas_f32 v21, v27, v32, v42                          // 0000005205A8: D6370015 04AA411B
	s_mov_b32 vcc_lo, s9                                       // 0000005205B0: BEEA0009
	v_div_fixup_f32 v18, v26, v22, v18                         // 0000005205B4: D6270012 044A2D1A
	v_lshlrev_b32_e32 v22, 16, v7                              // 0000005205BC: 302C0E90
	v_and_b32_e32 v7, 0xffff0000, v7                           // 0000005205C0: 360E0EFF FFFF0000
	v_div_fixup_f32 v20, v21, v23, v20                         // 0000005205C8: D6270014 04522F15
	s_mov_b32 s7, 0                                            // 0000005205D0: BE870080
	v_mul_f32_e32 v6, v18, v6                                  // 0000005205D4: 100C0D12
	v_div_fmas_f32 v18, v25, v33, v44                          // 0000005205D8: D6370012 04B24319
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000005205E0: BF870193
	v_mul_f32_e32 v20, v20, v22                                // 0000005205E4: 10282D14
	.long 0x7e443986                                           // 0000005205E8: 7E443986
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000005205EC: BF870223
	v_div_fixup_f32 v16, v18, v24, v16                         // 0000005205F0: D6270010 04423112
	v_and_b32_e32 v18, 1, v31                                  // 0000005205F8: 36243E81
	v_bfe_u32 v21, v20, 16, 1                                  // 0000005205FC: D6100015 02052114
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000520604: BF870193
	v_dual_mul_f32 v7, v16, v7 :: v_dual_and_b32 v22, 1, v34   // 000000520608: C8E40F10 07164481
	v_add3_u32 v15, v15, v18, 0x7fff                           // 000000520610: D655000F 03FE250F 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000052061C: BF870193
	v_add3_u32 v16, v20, v21, 0x7fff                           // 000000520620: D6550010 03FE2B14 00007FFF
	v_add3_u32 v6, v6, v22, 0x7fff                             // 00000052062C: D6550006 03FE2D06 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000520638: BF870214
	v_bfe_u32 v18, v7, 16, 1                                   // 00000052063C: D6100012 02052107
	v_and_b32_e32 v15, 0xffff0000, v15                         // 000000520644: 361E1EFF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000052064C: BF870214
	v_and_b32_e32 v20, 0xffff0000, v16                         // 000000520650: 362820FF FFFF0000
	v_and_b32_e32 v6, 0xffff0000, v6                           // 000000520658: 360C0CFF FFFF0000
	s_delay_alu instid0(VALU_DEP_4)                            // 000000520660: BF870004
	v_add3_u32 v7, v7, v18, 0x7fff                             // 000000520664: D6550007 03FE2507 00007FFF
	s_waitcnt vmcnt(1)                                         // 000000520670: BF8907F7
	v_fma_mix_f32 v16, v19, v15, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000520674: CC200810 8A021F13
	s_waitcnt vmcnt(0)                                         // 00000052067C: BF8903F7
	v_fma_mix_f32 v15, v17, v20, neg(0) op_sel_hi:[1,0,0]      // 000000520680: CC20000F 8A022911
	v_fma_mix_f32 v18, v19, v6, neg(0) op_sel_hi:[1,0,0]       // 000000520688: CC200012 8A020D13
	v_and_b32_e32 v17, 0xffff0000, v7                          // 000000520690: 36220EFF FFFF0000
	s_and_not1_b32 vcc_lo, exec_lo, s7                         // 000000520698: 916A077E
	s_cbranch_vccnz 65127                                      // 00000052069C: BFA4FE67 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb1ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x13c>
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005206A0: BF870093
	.long 0xd73c0004                                           // 0000005206A4: D73C0004
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 0000005206A8: 02020881
	.long 0xd7006a04                                           // 0000005206AC: D7006A04
	v_cndmask_b32_e32 v1, s22, v4, vcc_lo                      // 0000005206B0: 02020816
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000005206B4: BF870111
	v_add_co_ci_u32_e64 v5, null, s23, v5, vcc_lo              // 0000005206B8: D5207C05 01AA0A17
	.long 0xd7006a04                                           // 0000005206C0: D7006A04
	v_cndmask_b32_e32 v1, v4, v2, vcc_lo                       // 0000005206C4: 02020504
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000005206C8: BF8700A1
	v_add_co_ci_u32_e64 v5, null, v5, v3, vcc_lo               // 0000005206CC: D5207C05 01AA0705
	.long 0xd7006a06                                           // 0000005206D4: D7006A06
	v_cndmask_b32_e32 v1, s12, v2, vcc_lo                      // 0000005206D8: 0202040C
	v_add_co_ci_u32_e64 v7, null, s13, v3, vcc_lo              // 0000005206DC: D5207C07 01AA060D
	global_load_b64 v[4:5], v[4:5], off                        // 0000005206E4: DC560000 047C0004
	s_clause 0x1                                               // 0000005206EC: BF850001
	global_load_b32 v17, v[6:7], off                           // 0000005206F0: DC520000 117C0006
	global_load_d16_b16 v6, v[6:7], off offset:4               // 0000005206F8: DC820004 067C0006
	s_waitcnt vmcnt(2)                                         // 000000520700: BF890BF7
	.long 0x7e0e3904                                           // 000000520704: 7E0E3904
	v_and_b32_e32 v4, 0xffff0000, v4                           // 000000520708: 360808FF FFFF0000
	v_lshlrev_b32_e32 v15, 16, v5                              // 000000520710: 301E0A90
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000520714: BF8701A3
	v_lshlrev_b32_e32 v7, 16, v7                               // 000000520718: 300E0E90
	s_waitcnt vmcnt(1)                                         // 00000052071C: BF8907F7
	v_fma_mix_f32 v16, v17, v4, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000520720: CC200810 8A020911
	s_waitcnt vmcnt(0)                                         // 000000520728: BF8903F7
	v_fma_mix_f32 v15, v6, v15, neg(0) op_sel_hi:[1,0,0]       // 00000052072C: CC20000F 8A021F06
	v_fma_mix_f32 v18, v17, v7, neg(0) op_sel_hi:[1,0,0]       // 000000520734: CC200012 8A020F11
	v_and_b32_e32 v17, 0xffff0000, v5                          // 00000052073C: 36220AFF FFFF0000
	s_branch 65085                                             // 000000520744: BFA0FE3D <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb1ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x13c>
	s_or_b32 exec_lo, exec_lo, s10                             // 000000520748: 8C7E0A7E
	s_bfe_i32 s10, s11, 0x1001c                                // 00000052074C: 938AFF0B 0001001C
	s_lshr_b32 s3, s34, 28                                     // 000000520754: 85039C22
	s_lshr_b64 s[0:1], s[10:11], 29                            // 000000520758: 85809D0A
	s_add_i32 s3, s25, s3                                      // 00000052075C: 81030319
	s_add_i32 s0, s0, 7                                        // 000000520760: 81008700
	s_lshl_b32 s1, s11, 3                                      // 000000520764: 8401830B
	s_ashr_i32 s0, s0, 3                                       // 000000520768: 86008300
	s_lshl_b32 s5, s35, 3                                      // 00000052076C: 84058323
	.long 0xd72c0001                                           // 000000520770: D72C0001
	v_cndmask_b32_e32 v1, s0, v8, vcc_lo                       // 000000520774: 02021000
	s_waitcnt lgkmcnt(0)                                       // 000000520778: BF89FC07
	s_barrier                                                  // 00000052077C: BFBD0000
	buffer_gl0_inv                                             // 000000520780: E0AC0000 00000000
	v_add_nc_u32_e32 v2, s0, v1                                // 000000520788: 4A040200
	s_ashr_i32 s0, s3, 4                                       // 00000052078C: 86008403
	s_ashr_i32 s3, s5, 31                                      // 000000520790: 86039F05
	s_mul_hi_i32 s6, s0, s2                                    // 000000520794: 97060200
	s_mul_i32 s0, s0, s2                                       // 000000520798: 96000200
	v_min_i32_e32 v7, s1, v2                                   // 00000052079C: 220E0401
	v_add_nc_u32_e32 v2, 1, v1                                 // 0000005207A0: 4A040281
	s_add_u32 s0, s0, s5                                       // 0000005207A4: 80000500
	s_addc_u32 s1, s6, s3                                      // 0000005207A8: 82010306
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005207AC: BF870099
	s_lshl_b64 s[6:7], s[0:1], 10                              // 0000005207B0: 84868A00
	v_cmp_lt_i32_e32 vcc_lo, v2, v7                            // 0000005207B4: 7C820F02
	s_add_u32 s1, s20, s6                                      // 0000005207B8: 80010614
	s_addc_u32 s5, s21, s7                                     // 0000005207BC: 82050715
	s_and_saveexec_b32 s0, vcc_lo                              // 0000005207C0: BE80206A
	s_cbranch_execz 91                                         // 0000005207C4: BFA5005B <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb1ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0xa34>
	.long 0xd7010303                                           // 0000005207C8: D7010303
	v_cndmask_b32_e32 v0, v10, v129, vcc_lo                    // 0000005207CC: 0201030A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000005207D0: BF870121
	v_cndmask_b32_e64 v4, v3, 31, s3                           // 0000005207D4: D5010004 000D3F03
	v_ashrrev_i32_e32 v3, 31, v2                               // 0000005207DC: 3406049F
	v_cmp_gt_u32_e32 vcc_lo, 31, v4                            // 0000005207E0: 7C98089F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000005207E4: BF8701B2
	.long 0xd73c0002                                           // 0000005207E8: D73C0002
	v_cndmask_b32_e32 v1, 10, v2, vcc_lo                       // 0000005207EC: 0202048A
	v_cndmask_b32_e64 v6, 0xe1, 1, vcc_lo                      // 0000005207F0: D5010006 01A902FF 000000E1
	v_mov_b32_e32 v5, 0                                        // 0000005207FC: 7E0A0280
	.long 0xd7006a0c                                           // 000000520800: D7006A0C
	v_cndmask_b32_e32 v1, s1, v2, vcc_lo                       // 000000520804: 02020401
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000520808: BF870211
	v_add_co_ci_u32_e64 v13, null, s5, v3, vcc_lo              // 00000052080C: D5207C0D 01AA0605
	v_add_nc_u32_e32 v6, v6, v4                                // 000000520814: 4A0C0906
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000520818: BF870114
	.long 0xd73c0004                                           // 00000052081C: D73C0004
	v_cndmask_b32_e32 v1, 2, v4, vcc_lo                        // 000000520820: 02020882
	v_lshlrev_b32_e32 v11, 24, v6                              // 000000520824: 30160C98
	v_bfe_i32 v6, v6, 7, 1                                     // 000000520828: D6110006 02050F06
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000520830: BF870093
	.long 0xd7006a02                                           // 000000520834: D7006A02
	v_cndmask_b32_e32 v1, v12, v4, vcc_lo                      // 000000520838: 0202090C
	v_add_co_ci_u32_e64 v3, null, v13, v5, vcc_lo              // 00000052083C: D5207C03 01AA0B0D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000520844: BF870094
	v_ashrrev_i32_e32 v11, 22, v11                             // 000000520848: 34161696
	.long 0xd7006a04                                           // 00000052084C: D7006A04
	v_cndmask_b32_e32 v1, v12, v11, vcc_lo                     // 000000520850: 0202170C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000520854: BF8700A1
	v_add_co_ci_u32_e64 v5, null, v13, v6, vcc_lo              // 000000520858: D5207C05 01AA0D0D
	.long 0xd7006a23                                           // 000000520860: D7006A23
	v_cndmask_b32_e32 v1, v12, v9, vcc_lo                      // 000000520864: 0202130C
	v_add_co_ci_u32_e64 v36, null, 0, v13, vcc_lo              // 000000520868: D5207C24 01AA1A80
	s_clause 0x17                                              // 000000520870: BF850017
	global_load_b32 v11, v[2:3], off                           // 000000520874: DC520000 0B7C0002
	global_load_b32 v18, v[2:3], off offset:128                // 00000052087C: DC520080 127C0002
	global_load_b32 v17, v[2:3], off offset:256                // 000000520884: DC520100 117C0002
	global_load_b32 v16, v[2:3], off offset:384                // 00000052088C: DC520180 107C0002
	global_load_b32 v15, v[2:3], off offset:512                // 000000520894: DC520200 0F7C0002
	global_load_b32 v14, v[2:3], off offset:640                // 00000052089C: DC520280 0E7C0002
	global_load_b32 v13, v[2:3], off offset:768                // 0000005208A4: DC520300 0D7C0002
	global_load_b32 v12, v[2:3], off offset:896                // 0000005208AC: DC520380 0C7C0002
	global_load_b32 v30, v[4:5], off                           // 0000005208B4: DC520000 1E7C0004
	global_load_b32 v28, v[4:5], off offset:128                // 0000005208BC: DC520080 1C7C0004
	global_load_b32 v26, v[4:5], off offset:256                // 0000005208C4: DC520100 1A7C0004
	global_load_b32 v24, v[4:5], off offset:384                // 0000005208CC: DC520180 187C0004
	global_load_b32 v22, v[4:5], off offset:512                // 0000005208D4: DC520200 167C0004
	global_load_b32 v21, v[4:5], off offset:640                // 0000005208DC: DC520280 157C0004
	global_load_b32 v20, v[4:5], off offset:768                // 0000005208E4: DC520300 147C0004
	global_load_b32 v19, v[4:5], off offset:896                // 0000005208EC: DC520380 137C0004
	global_load_b32 v34, v[35:36], off                         // 0000005208F4: DC520000 227C0023
	global_load_b32 v33, v[35:36], off offset:128              // 0000005208FC: DC520080 217C0023
	global_load_b32 v32, v[35:36], off offset:256              // 000000520904: DC520100 207C0023
	global_load_b32 v31, v[35:36], off offset:384              // 00000052090C: DC520180 1F7C0023
	global_load_b32 v29, v[35:36], off offset:512              // 000000520914: DC520200 1D7C0023
	global_load_b32 v27, v[35:36], off offset:640              // 00000052091C: DC520280 1B7C0023
	global_load_b32 v25, v[35:36], off offset:768              // 000000520924: DC520300 197C0023
	global_load_b32 v23, v[35:36], off offset:896              // 00000052092C: DC520380 177C0023
	s_or_b32 exec_lo, exec_lo, s0                              // 000000520934: 8C7E007E
	v_cmp_lt_i32_e32 vcc_lo, v1, v7                            // 000000520938: 7C820F01
	s_and_saveexec_b32 s3, vcc_lo                              // 00000052093C: BE83206A
	s_cbranch_execz 93                                         // 000000520940: BFA5005D <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb1ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0xbb8>
	.long 0xd7010002                                           // 000000520944: D7010002
	v_cndmask_b32_e32 v0, v10, v129, vcc_lo                    // 000000520948: 0201030A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000052094C: BF870121
	v_cndmask_b32_e64 v3, v2, 31, s0                           // 000000520950: D5010003 00013F02
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000520958: 3404029F
	.long 0xd44c0000                                           // 00000052095C: D44C0000
	v_cndmask_b32_e32 v1, 31, v3, vcc_lo                       // 000000520960: 0202069F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000520964: BF870091
	v_cndmask_b32_e64 v5, 0xe1, 1, s0                          // 000000520968: D5010005 000102FF 000000E1
	v_dual_mov_b32 v4, 0 :: v_dual_add_nc_u32 v35, v5, v3      // 000000520974: CA200080 04220705
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000052097C: BF870114
	.long 0xd73c0005                                           // 000000520980: D73C0005
	v_cndmask_b32_e32 v1, 10, v1, vcc_lo                       // 000000520984: 0202028A
	.long 0xd73c0002                                           // 000000520988: D73C0002
	v_cndmask_b32_e32 v1, 2, v3, vcc_lo                        // 00000052098C: 02020682
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000520990: BF870223
	v_lshlrev_b32_e32 v4, 24, v35                              // 000000520994: 30084698
	v_bfe_i32 v36, v35, 7, 1                                   // 000000520998: D6110024 02050F23
	.long 0xd7000025                                           // 0000005209A0: D7000025
	v_cndmask_b32_e32 v1, s1, v5, vcc_lo                       // 0000005209A4: 02020A01
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000005209A8: BF870211
	v_add_co_ci_u32_e64 v6, null, s5, v6, s0                   // 0000005209AC: D5207C06 00020C05
	v_ashrrev_i32_e32 v35, 22, v4                              // 0000005209B4: 34460896
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005209B8: BF870093
	.long 0xd7000004                                           // 0000005209BC: D7000004
	v_cndmask_b32_e32 v1, v37, v2, vcc_lo                      // 0000005209C0: 02020525
	v_add_co_ci_u32_e64 v5, null, v6, v3, s0                   // 0000005209C4: D5207C05 00020706
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005209CC: BF870093
	.long 0xd7000023                                           // 0000005209D0: D7000023
	v_cndmask_b32_e32 v1, v37, v35, vcc_lo                     // 0000005209D4: 02024725
	v_add_co_ci_u32_e64 v36, null, v6, v36, s0                 // 0000005209D8: D5207C24 00024906
	.long 0xd7000025                                           // 0000005209E0: D7000025
	v_cndmask_b32_e32 v1, v37, v9, vcc_lo                      // 0000005209E4: 02021325
	s_delay_alu instid0(VALU_DEP_1)                            // 0000005209E8: BF870001
	v_add_co_ci_u32_e64 v38, null, 0, v6, s0                   // 0000005209EC: D5207C26 00020C80
	s_clause 0x17                                              // 0000005209F4: BF850017
	global_load_b32 v2, v[4:5], off                            // 0000005209F8: DC520000 027C0004
	global_load_b32 v81, v[4:5], off offset:128                // 000000520A00: DC520080 517C0004
	global_load_b32 v78, v[4:5], off offset:256                // 000000520A08: DC520100 4E7C0004
	global_load_b32 v75, v[4:5], off offset:384                // 000000520A10: DC520180 4B7C0004
	global_load_b32 v72, v[4:5], off offset:512                // 000000520A18: DC520200 487C0004
	global_load_b32 v69, v[4:5], off offset:640                // 000000520A20: DC520280 457C0004
	global_load_b32 v51, v[4:5], off offset:768                // 000000520A28: DC520300 337C0004
	global_load_b32 v44, v[4:5], off offset:896                // 000000520A30: DC520380 2C7C0004
	global_load_b32 v3, v[35:36], off                          // 000000520A38: DC520000 037C0023
	global_load_b32 v82, v[35:36], off offset:128              // 000000520A40: DC520080 527C0023
	global_load_b32 v79, v[35:36], off offset:256              // 000000520A48: DC520100 4F7C0023
	global_load_b32 v76, v[35:36], off offset:384              // 000000520A50: DC520180 4C7C0023
	global_load_b32 v73, v[35:36], off offset:512              // 000000520A58: DC520200 497C0023
	global_load_b32 v70, v[35:36], off offset:640              // 000000520A60: DC520280 467C0023
	global_load_b32 v52, v[35:36], off offset:768              // 000000520A68: DC520300 347C0023
	global_load_b32 v45, v[35:36], off offset:896              // 000000520A70: DC520380 2D7C0023
	global_load_b32 v83, v[37:38], off                         // 000000520A78: DC520000 537C0025
	global_load_b32 v80, v[37:38], off offset:128              // 000000520A80: DC520080 507C0025
	global_load_b32 v77, v[37:38], off offset:256              // 000000520A88: DC520100 4D7C0025
	global_load_b32 v74, v[37:38], off offset:384              // 000000520A90: DC520180 4A7C0025
	global_load_b32 v71, v[37:38], off offset:512              // 000000520A98: DC520200 477C0025
	global_load_b32 v68, v[37:38], off offset:640              // 000000520AA0: DC520280 447C0025
	global_load_b32 v50, v[37:38], off offset:768              // 000000520AA8: DC520300 327C0025
	global_load_b32 v43, v[37:38], off offset:896              // 000000520AB0: DC520380 2B7C0025
	s_or_b32 exec_lo, exec_lo, s3                              // 000000520AB8: 8C7E037E
	v_dual_mov_b32 v35, 0 :: v_dual_mov_b32 v36, 0             // 000000520ABC: CA100080 23240080
	v_dual_mov_b32 v37, 0 :: v_dual_mov_b32 v38, 0             // 000000520AC4: CA100080 25260080
	v_dual_mov_b32 v39, 0 :: v_dual_mov_b32 v40, 0             // 000000520ACC: CA100080 27280080
	v_dual_mov_b32 v41, 0 :: v_dual_mov_b32 v42, 0             // 000000520AD4: CA100080 292A0080
	s_ashr_i32 s3, s2, 31                                      // 000000520ADC: 86039F02
	s_and_saveexec_b32 s0, vcc_lo                              // 000000520AE0: BE80206A
	s_cbranch_execz 959                                        // 000000520AE4: BFA503BF <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb1ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1ae4>
	v_dual_mov_b32 v35, 0 :: v_dual_add_nc_u32 v4, -1, v0      // 000000520AE8: CA200080 230400C1
	v_dual_mov_b32 v37, 0 :: v_dual_and_b32 v6, 16, v0         // 000000520AF0: CA240080 25060090
	v_sub_nc_u32_e32 v46, 0, v7                                // 000000520AF8: 4C5C0E80
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000520AFC: BF870243
	v_dual_mov_b32 v39, 0 :: v_dual_and_b32 v4, 31, v4         // 000000520B00: CA240080 2704089F
	v_dual_mov_b32 v36, 0 :: v_dual_add_nc_u32 v5, 2, v1       // 000000520B08: CA200080 24040282
	v_dual_mov_b32 v38, 0 :: v_dual_lshlrev_b32 v47, 2, v10    // 000000520B10: CA220080 262E1482
	v_lshl_or_b32 v48, v1, 5, v6                               // 000000520B18: D6560030 04190B01
	v_dual_mov_b32 v40, 0 :: v_dual_lshlrev_b32 v49, 2, v4     // 000000520B20: CA220080 28300882
	v_dual_mov_b32 v41, 0 :: v_dual_mov_b32 v42, 0             // 000000520B28: CA100080 292A0080
	s_mov_b32 s6, 0                                            // 000000520B30: BE860080
	s_movk_i32 s7, 0x1eee                                      // 000000520B34: B0071EEE
	s_branch 881                                               // 000000520B38: BFA00371 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb1ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1a00>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000520B3C: 8C7E087E
	s_waitcnt vmcnt(15)                                        // 000000520B40: BF893FF7
	v_alignbit_b32 v84, v2, v3, 16                             // 000000520B44: D6160054 02420702
	s_waitcnt vmcnt(14)                                        // 000000520B4C: BF893BF7
	v_alignbit_b32 v81, v81, v82, 16                           // 000000520B50: D6160051 0242A551
	ds_load_b128 v[1:4], v48                                   // 000000520B58: DBFC0000 01000030
	s_waitcnt vmcnt(7)                                         // 000000520B60: BF891FF7
	v_bfe_u32 v85, v83, 12, 16                                 // 000000520B64: D6100055 02411953
	v_bfe_u32 v86, v83, 8, 16                                  // 000000520B6C: D6100056 02411153
	v_bfe_u32 v88, v84, 12, 16                                 // 000000520B74: D6100058 02411954
	v_bfe_u32 v82, v84, 8, 16                                  // 000000520B7C: D6100052 02411154
	v_bfe_u32 v87, v83, 4, 16                                  // 000000520B84: D6100057 02410953
	.long 0xd72c0055                                           // 000000520B8C: D72C0055
	v_cndmask_b32_e32 v1, 0x83dcd12d, v85, vcc_lo              // 000000520B90: 0202AAFF 83DCD12D
	.long 0xd72c0056                                           // 000000520B98: D72C0056
	v_cndmask_b32_e32 v1, 0x83dcd12d, v86, vcc_lo              // 000000520B9C: 0202ACFF 83DCD12D
	.long 0xd72c0058                                           // 000000520BA4: D72C0058
	v_cndmask_b32_e32 v1, 0x83dcd12d, v88, vcc_lo              // 000000520BA8: 0202B0FF 83DCD12D
	.long 0xd72c0052                                           // 000000520BB0: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 000000520BB4: 0202A4FF 83DCD12D
	.long 0xd72c0057                                           // 000000520BBC: D72C0057
	v_cndmask_b32_e32 v1, 0x83dcd12d, v87, vcc_lo              // 000000520BC0: 0202AEFF 83DCD12D
	s_waitcnt vmcnt(6)                                         // 000000520BC8: BF891BF7
	v_bfe_u32 v90, v80, 12, 16                                 // 000000520BCC: D610005A 02411950
	v_bfe_u32 v91, v81, 12, 16                                 // 000000520BD4: D610005B 02411951
	v_alignbit_b32 v78, v78, v79, 16                           // 000000520BDC: D616004E 02429F4E
	v_sad_u8 v85, v85, 0, 0x6400                               // 000000520BE4: D6220055 03FD0155 00006400
	v_sad_u8 v86, v86, 0, 0x6400                               // 000000520BF0: D6220056 03FD0156 00006400
	v_sad_u8 v88, v88, 0, 0x6400                               // 000000520BFC: D6220058 03FD0158 00006400
	v_sad_u8 v82, v82, 0, 0x6400                               // 000000520C08: D6220052 03FD0152 00006400
	v_sad_u8 v87, v87, 0, 0x6400                               // 000000520C14: D6220057 03FD0157 00006400
	v_and_b32_e32 v85, 0xffff, v85                             // 000000520C20: 36AAAAFF 0000FFFF
	v_alignbit_b32 v75, v75, v76, 16                           // 000000520C28: D616004B 0242994B
	v_and_b32_e32 v88, 0xffff, v88                             // 000000520C30: 36B0B0FF 0000FFFF
	v_alignbit_b32 v72, v72, v73, 16                           // 000000520C38: D6160048 02429348
	v_alignbit_b32 v69, v69, v70, 16                           // 000000520C40: D6160045 02428D45
	v_lshl_or_b32 v85, v86, 16, v85                            // 000000520C48: D6560055 05552156
	.long 0xd72c0056                                           // 000000520C50: D72C0056
	v_cndmask_b32_e32 v1, 0x83dcd12d, v91, vcc_lo              // 000000520C54: 0202B6FF 83DCD12D
	v_lshl_or_b32 v82, v82, 16, v88                            // 000000520C5C: D6560052 05612152
	v_bfe_u32 v88, v80, 4, 16                                  // 000000520C64: D6100058 02410950
	v_alignbit_b32 v51, v51, v52, 16                           // 000000520C6C: D6160033 02426933
	v_pk_fma_f16 v85, v85, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000520C74: CC0E0055 0BFC0F55 0000C931
	v_alignbit_b32 v44, v44, v45, 16                           // 000000520C80: D616002C 02425B2C
	v_pk_fma_f16 v82, v82, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000520C88: CC0E0052 0BFC0F52 0000C931
	v_and_b32_e32 v83, 0xffff, v83                             // 000000520C94: 36A6A6FF 0000FFFF
	v_sad_u8 v86, v86, 0, 0x6400                               // 000000520C9C: D6220056 03FD0156 00006400
	v_add_nc_u32_e32 v5, 1, v5                                 // 000000520CA8: 4A0A0A81
	v_add_nc_u32_e32 v48, 32, v48                              // 000000520CAC: 4A6060A0
	s_waitcnt lgkmcnt(0)                                       // 000000520CB0: BF89FC07
	v_dual_dot2acc_f32_f16 v42, v82, v1 :: v_dual_and_b32 v89, 0xffff, v84// 000000520CB4: CB240352 2A58A8FF 0000FFFF
	v_bfe_u32 v84, v84, 4, 16                                  // 000000520CC0: D6100054 02410954
	.long 0xd72c0053                                           // 000000520CC8: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v83, vcc_lo              // 000000520CCC: 0202A6FF 83DCD12D
	v_bfe_u32 v82, v80, 8, 16                                  // 000000520CD4: D6100052 02411150
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000520CDC: BF870214
	.long 0xd72c0059                                           // 000000520CE0: D72C0059
	v_cndmask_b32_e32 v1, 0x83dcd12d, v89, vcc_lo              // 000000520CE4: 0202B2FF 83DCD12D
	.long 0xd72c0054                                           // 000000520CEC: D72C0054
	v_cndmask_b32_e32 v1, 0x83dcd12d, v84, vcc_lo              // 000000520CF0: 0202A8FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000520CF8: BF870223
	.long 0xd72c0052                                           // 000000520CFC: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 000000520D00: 0202A4FF 83DCD12D
	v_sad_u8 v83, v83, 0, 0x6400                               // 000000520D08: D6220053 03FD0153 00006400
	v_sad_u8 v89, v89, 0, 0x6400                               // 000000520D14: D6220059 03FD0159 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000520D20: BF870194
	v_sad_u8 v84, v84, 0, 0x6400                               // 000000520D24: D6220054 03FD0154 00006400
	v_lshlrev_b32_e32 v83, 16, v83                             // 000000520D30: 30A6A690
	v_sad_u8 v82, v82, 0, 0x6400                               // 000000520D34: D6220052 03FD0152 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000520D40: BF870194
	v_lshlrev_b32_e32 v89, 16, v89                             // 000000520D44: 30B2B290
	v_and_or_b32 v83, 0xffff, v87, v83                         // 000000520D48: D6570053 054EAEFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000520D54: BF870112
	v_and_or_b32 v84, 0xffff, v84, v89                         // 000000520D58: D6570054 0566A8FF 0000FFFF
	v_pk_fma_f16 v83, v83, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000520D64: CC0E0053 0BFC0F53 0000C931
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000520D70: BF870092
	v_pk_fma_f16 v84, v84, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000520D74: CC0E0054 0BFC0F54 0000C931
	v_dot2acc_f32_f16 v42, v84, v2                             // 000000520D80: 04540554
	v_bfe_u32 v84, v81, 8, 16                                  // 000000520D84: D6100054 02411151
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000520D8C: BF8701A2
	v_dual_dot2acc_f32_f16 v42, v85, v3 :: v_dual_and_b32 v87, 0xffff, v81// 000000520D90: CB240755 2A56A2FF 0000FFFF
	v_bfe_u32 v81, v81, 4, 16                                  // 000000520D9C: D6100051 02410951
	.long 0xd72c0054                                           // 000000520DA4: D72C0054
	v_cndmask_b32_e32 v1, 0x83dcd12d, v84, vcc_lo              // 000000520DA8: 0202A8FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000520DB0: BF870213
	v_dot2acc_f32_f16 v42, v83, v4                             // 000000520DB4: 04540953
	.long 0xd72c0055                                           // 000000520DB8: D72C0055
	v_cndmask_b32_e32 v1, 0x83dcd12d, v87, vcc_lo              // 000000520DBC: 0202AEFF 83DCD12D
	.long 0xd72c0057                                           // 000000520DC4: D72C0057
	v_cndmask_b32_e32 v1, 0x83dcd12d, v90, vcc_lo              // 000000520DC8: 0202B4FF 83DCD12D
	.long 0xd72c0051                                           // 000000520DD0: D72C0051
	v_cndmask_b32_e32 v1, 0x83dcd12d, v81, vcc_lo              // 000000520DD4: 0202A2FF 83DCD12D
	s_waitcnt vmcnt(3)                                         // 000000520DDC: BF890FF7
	v_bfe_u32 v83, v71, 4, 16                                  // 000000520DE0: D6100053 02410947
	v_sad_u8 v84, v84, 0, 0x6400                               // 000000520DE8: D6220054 03FD0154 00006400
	v_sad_u8 v85, v85, 0, 0x6400                               // 000000520DF4: D6220055 03FD0155 00006400
	v_sad_u8 v87, v87, 0, 0x6400                               // 000000520E00: D6220057 03FD0157 00006400
	v_sad_u8 v81, v81, 0, 0x6400                               // 000000520E0C: D6220051 03FD0151 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000520E18: BF870193
	v_lshlrev_b32_e32 v85, 16, v85                             // 000000520E1C: 30AAAA90
	v_and_b32_e32 v87, 0xffff, v87                             // 000000520E20: 36AEAEFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000520E28: BF870112
	v_and_or_b32 v81, 0xffff, v81, v85                         // 000000520E2C: D6570051 0556A2FF 0000FFFF
	v_lshl_or_b32 v79, v82, 16, v87                            // 000000520E38: D656004F 055D2152
	v_bfe_u32 v85, v78, 12, 16                                 // 000000520E40: D6100055 0241194E
	v_bfe_u32 v87, v77, 8, 16                                  // 000000520E48: D6100057 0241114D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000520E50: BF870214
	v_pk_fma_f16 v81, v81, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000520E54: CC0E0051 0BFC0F51 0000C931
	v_pk_fma_f16 v79, v79, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000520E60: CC0E004F 0BFC0F4F 0000C931
	v_and_b32_e32 v86, 0xffff, v86                             // 000000520E6C: 36ACACFF 0000FFFF
	.long 0xd72c0055                                           // 000000520E74: D72C0055
	v_cndmask_b32_e32 v1, 0x83dcd12d, v85, vcc_lo              // 000000520E78: 0202AAFF 83DCD12D
	.long 0xd72c0057                                           // 000000520E80: D72C0057
	v_cndmask_b32_e32 v1, 0x83dcd12d, v87, vcc_lo              // 000000520E84: 0202AEFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000520E8C: BF870243
	v_lshl_or_b32 v84, v84, 16, v86                            // 000000520E90: D6560054 05592154
	.long 0xd72c0056                                           // 000000520E98: D72C0056
	v_cndmask_b32_e32 v1, 0x83dcd12d, v88, vcc_lo              // 000000520E9C: 0202B0FF 83DCD12D
	v_and_b32_e32 v88, 0xffff, v77                             // 000000520EA4: 36B09AFF 0000FFFF
	v_sad_u8 v85, v85, 0, 0x6400                               // 000000520EAC: D6220055 03FD0155 00006400
	v_pk_fma_f16 v84, v84, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000520EB8: CC0E0054 0BFC0F54 0000C931
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000520EC4: BF8701A3
	.long 0xd72c0058                                           // 000000520EC8: D72C0058
	v_cndmask_b32_e32 v1, 0x83dcd12d, v88, vcc_lo              // 000000520ECC: 0202B0FF 83DCD12D
	v_sad_u8 v82, v86, 0, 0x6400                               // 000000520ED4: D6220052 03FD0156 00006400
	v_dual_dot2acc_f32_f16 v41, v84, v1 :: v_dual_and_b32 v80, 0xffff, v80// 000000520EE0: CB240354 2950A0FF 0000FFFF
	v_bfe_u32 v84, v77, 12, 16                                 // 000000520EEC: D6100054 0241194D
	v_and_b32_e32 v85, 0xffff, v85                             // 000000520EF4: 36AAAAFF 0000FFFF
	v_bfe_u32 v77, v77, 4, 16                                  // 000000520EFC: D610004D 0241094D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000520F04: BF870234
	v_dot2acc_f32_f16 v41, v81, v2                             // 000000520F08: 04520551
	.long 0xd72c0050                                           // 000000520F0C: D72C0050
	v_cndmask_b32_e32 v1, 0x83dcd12d, v80, vcc_lo              // 000000520F10: 0202A0FF 83DCD12D
	.long 0xd72c0054                                           // 000000520F18: D72C0054
	v_cndmask_b32_e32 v1, 0x83dcd12d, v84, vcc_lo              // 000000520F1C: 0202A8FF 83DCD12D
	.long 0xd72c004d                                           // 000000520F24: D72C004D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v77, vcc_lo              // 000000520F28: 02029AFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000520F30: BF870214
	v_dot2acc_f32_f16 v41, v79, v3                             // 000000520F34: 0452074F
	v_sad_u8 v80, v80, 0, 0x6400                               // 000000520F38: D6220050 03FD0150 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000520F44: BF870214
	v_sad_u8 v84, v84, 0, 0x6400                               // 000000520F48: D6220054 03FD0154 00006400
	v_sad_u8 v77, v77, 0, 0x6400                               // 000000520F54: D622004D 03FD014D 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000520F60: BF870193
	v_lshlrev_b32_e32 v80, 16, v80                             // 000000520F64: 30A0A090
	v_and_b32_e32 v84, 0xffff, v84                             // 000000520F68: 36A8A8FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000520F70: BF870122
	v_and_or_b32 v80, 0xffff, v82, v80                         // 000000520F74: D6570050 0542A4FF 0000FFFF
	v_bfe_u32 v82, v78, 8, 16                                  // 000000520F80: D6100052 0241114E
	v_pk_fma_f16 v80, v80, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000520F88: CC0E0050 0BFC0F50 0000C931
	v_and_b32_e32 v86, 0xffff, v78                             // 000000520F94: 36AC9CFF 0000FFFF
	v_bfe_u32 v78, v78, 4, 16                                  // 000000520F9C: D610004E 0241094E
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000520FA4: BF870214
	.long 0xd72c0052                                           // 000000520FA8: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 000000520FAC: 0202A4FF 83DCD12D
	v_dot2acc_f32_f16 v41, v80, v4                             // 000000520FB4: 04520950
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000520FB8: BF870214
	.long 0xd72c0056                                           // 000000520FBC: D72C0056
	v_cndmask_b32_e32 v1, 0x83dcd12d, v86, vcc_lo              // 000000520FC0: 0202ACFF 83DCD12D
	.long 0xd72c004e                                           // 000000520FC8: D72C004E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 000000520FCC: 02029CFF 83DCD12D
	v_bfe_u32 v80, v74, 12, 16                                 // 000000520FD4: D6100050 0241194A
	v_sad_u8 v82, v82, 0, 0x6400                               // 000000520FDC: D6220052 03FD0152 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000520FE8: BF870232
	.long 0xd72c0050                                           // 000000520FEC: D72C0050
	v_cndmask_b32_e32 v1, 0x83dcd12d, v80, vcc_lo              // 000000520FF0: 0202A0FF 83DCD12D
	v_sad_u8 v86, v86, 0, 0x6400                               // 000000520FF8: D6220056 03FD0156 00006400
	v_sad_u8 v78, v78, 0, 0x6400                               // 000000521004: D622004E 03FD014E 00006400
	v_lshl_or_b32 v82, v82, 16, v85                            // 000000521010: D6560052 05552152
	v_sad_u8 v85, v87, 0, 0x6400                               // 000000521018: D6220055 03FD0157 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000521024: BF870194
	v_lshlrev_b32_e32 v86, 16, v86                             // 000000521028: 30ACAC90
	v_pk_fma_f16 v81, v82, s7, 0xc931 op_sel_hi:[1,0,0]        // 00000052102C: CC0E0051 0BFC0F52 0000C931
	v_sad_u8 v82, v88, 0, 0x6400                               // 000000521038: D6220052 03FD0158 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000521044: BF870214
	v_lshl_or_b32 v84, v85, 16, v84                            // 000000521048: D6560054 05512155
	v_and_or_b32 v78, 0xffff, v78, v86                         // 000000521050: D657004E 055A9CFF 0000FFFF
	v_sad_u8 v80, v80, 0, 0x6400                               // 00000052105C: D6220050 03FD0150 00006400
	v_dot2acc_f32_f16 v40, v81, v1                             // 000000521068: 04500351
	v_lshlrev_b32_e32 v76, 16, v82                             // 00000052106C: 3098A490
	v_pk_fma_f16 v79, v84, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000521070: CC0E004F 0BFC0F54 0000C931
	v_pk_fma_f16 v78, v78, s7, 0xc931 op_sel_hi:[1,0,0]        // 00000052107C: CC0E004E 0BFC0F4E 0000C931
	v_bfe_u32 v81, v75, 12, 16                                 // 000000521088: D6100051 0241194B
	v_and_b32_e32 v82, 0xffff, v74                             // 000000521090: 36A494FF 0000FFFF
	v_and_or_b32 v76, 0xffff, v77, v76                         // 000000521098: D657004C 05329AFF 0000FFFF
	v_and_b32_e32 v80, 0xffff, v80                             // 0000005210A4: 36A0A0FF 0000FFFF
	v_dot2acc_f32_f16 v40, v78, v2                             // 0000005210AC: 0450054E
	.long 0xd72c004d                                           // 0000005210B0: D72C004D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v81, vcc_lo              // 0000005210B4: 0202A2FF 83DCD12D
	v_bfe_u32 v78, v75, 8, 16                                  // 0000005210BC: D610004E 0241114B
	v_pk_fma_f16 v76, v76, s7, 0xc931 op_sel_hi:[1,0,0]        // 0000005210C4: CC0E004C 0BFC0F4C 0000C931
	v_bfe_u32 v81, v74, 8, 16                                  // 0000005210D0: D6100051 0241114A
	v_dot2acc_f32_f16 v40, v79, v3                             // 0000005210D8: 0450074F
	v_bfe_u32 v79, v75, 4, 16                                  // 0000005210DC: D610004F 0241094B
	v_and_b32_e32 v75, 0xffff, v75                             // 0000005210E4: 369696FF 0000FFFF
	.long 0xd72c004e                                           // 0000005210EC: D72C004E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 0000005210F0: 02029CFF 83DCD12D
	v_sad_u8 v77, v77, 0, 0x6400                               // 0000005210F8: D622004D 03FD014D 00006400
	v_dot2acc_f32_f16 v40, v76, v4                             // 000000521104: 0450094C
	v_bfe_u32 v74, v74, 4, 16                                  // 000000521108: D610004A 0241094A
	.long 0xd72c004b                                           // 000000521110: D72C004B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v75, vcc_lo              // 000000521114: 020296FF 83DCD12D
	.long 0xd72c004f                                           // 00000052111C: D72C004F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v79, vcc_lo              // 000000521120: 02029EFF 83DCD12D
	.long 0xd72c0052                                           // 000000521128: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 00000052112C: 0202A4FF 83DCD12D
	v_and_b32_e32 v77, 0xffff, v77                             // 000000521134: 369A9AFF 0000FFFF
	v_sad_u8 v78, v78, 0, 0x6400                               // 00000052113C: D622004E 03FD014E 00006400
	.long 0xd72c0051                                           // 000000521148: D72C0051
	v_cndmask_b32_e32 v1, 0x83dcd12d, v81, vcc_lo              // 00000052114C: 0202A2FF 83DCD12D
	.long 0xd72c004a                                           // 000000521154: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 000000521158: 020294FF 83DCD12D
	s_waitcnt vmcnt(2)                                         // 000000521160: BF890BF7
	v_bfe_u32 v76, v68, 4, 16                                  // 000000521164: D610004C 02410944
	v_sad_u8 v75, v75, 0, 0x6400                               // 00000052116C: D622004B 03FD014B 00006400
	v_lshl_or_b32 v77, v78, 16, v77                            // 000000521178: D656004D 0535214E
	v_sad_u8 v78, v79, 0, 0x6400                               // 000000521180: D622004E 03FD014F 00006400
	v_sad_u8 v79, v82, 0, 0x6400                               // 00000052118C: D622004F 03FD0152 00006400
	v_bfe_u32 v82, v71, 8, 16                                  // 000000521198: D6100052 02411147
	v_lshlrev_b32_e32 v75, 16, v75                             // 0000005211A0: 30969690
	v_sad_u8 v81, v81, 0, 0x6400                               // 0000005211A4: D6220051 03FD0151 00006400
	v_sad_u8 v74, v74, 0, 0x6400                               // 0000005211B0: D622004A 03FD014A 00006400
	v_lshlrev_b32_e32 v79, 16, v79                             // 0000005211BC: 309E9E90
	v_pk_fma_f16 v77, v77, s7, 0xc931 op_sel_hi:[1,0,0]        // 0000005211C0: CC0E004D 0BFC0F4D 0000C931
	v_and_or_b32 v73, 0xffff, v78, v75                         // 0000005211CC: D6570049 052E9CFF 0000FFFF
	v_bfe_u32 v78, v72, 12, 16                                 // 0000005211D8: D610004E 02411948
	v_lshl_or_b32 v75, v81, 16, v80                            // 0000005211E0: D656004B 05412151
	v_and_or_b32 v74, 0xffff, v74, v79                         // 0000005211E8: D657004A 053E94FF 0000FFFF
	v_and_b32_e32 v79, 0xffff, v72                             // 0000005211F4: 369E90FF 0000FFFF
	v_bfe_u32 v80, v72, 8, 16                                  // 0000005211FC: D6100050 02411148
	.long 0xd72c004e                                           // 000000521204: D72C004E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 000000521208: 02029CFF 83DCD12D
	v_bfe_u32 v72, v72, 4, 16                                  // 000000521210: D6100048 02410948
	v_bfe_u32 v81, v71, 12, 16                                 // 000000521218: D6100051 02411947
	.long 0xd72c004f                                           // 000000521220: D72C004F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v79, vcc_lo              // 000000521224: 02029EFF 83DCD12D
	.long 0xd72c0050                                           // 00000052122C: D72C0050
	v_cndmask_b32_e32 v1, 0x83dcd12d, v80, vcc_lo              // 000000521230: 0202A0FF 83DCD12D
	.long 0xd72c0052                                           // 000000521238: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 00000052123C: 0202A4FF 83DCD12D
	.long 0xd72c0048                                           // 000000521244: D72C0048
	v_cndmask_b32_e32 v1, 0x83dcd12d, v72, vcc_lo              // 000000521248: 020290FF 83DCD12D
	.long 0xd72c0051                                           // 000000521250: D72C0051
	v_cndmask_b32_e32 v1, 0x83dcd12d, v81, vcc_lo              // 000000521254: 0202A2FF 83DCD12D
	v_sad_u8 v78, v78, 0, 0x6400                               // 00000052125C: D622004E 03FD014E 00006400
	v_pk_fma_f16 v73, v73, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000521268: CC0E0049 0BFC0F49 0000C931
	v_dot2acc_f32_f16 v39, v77, v1                             // 000000521274: 044E034D
	v_sad_u8 v79, v79, 0, 0x6400                               // 000000521278: D622004F 03FD014F 00006400
	v_sad_u8 v80, v80, 0, 0x6400                               // 000000521284: D6220050 03FD0150 00006400
	v_and_b32_e32 v78, 0xffff, v78                             // 000000521290: 369C9CFF 0000FFFF
	v_sad_u8 v72, v72, 0, 0x6400                               // 000000521298: D6220048 03FD0148 00006400
	v_sad_u8 v81, v81, 0, 0x6400                               // 0000005212A4: D6220051 03FD0151 00006400
	v_lshlrev_b32_e32 v79, 16, v79                             // 0000005212B0: 309E9E90
	v_pk_fma_f16 v75, v75, s7, 0xc931 op_sel_hi:[1,0,0]        // 0000005212B4: CC0E004B 0BFC0F4B 0000C931
	v_lshl_or_b32 v77, v80, 16, v78                            // 0000005212C0: D656004D 05392150
	v_sad_u8 v80, v82, 0, 0x6400                               // 0000005212C8: D6220050 03FD0152 00006400
	v_dot2acc_f32_f16 v39, v73, v2                             // 0000005212D4: 044E0549
	v_and_or_b32 v72, 0xffff, v72, v79                         // 0000005212D8: D6570048 053E90FF 0000FFFF
	v_and_b32_e32 v79, 0xffff, v81                             // 0000005212E4: 369EA2FF 0000FFFF
	v_pk_fma_f16 v73, v77, s7, 0xc931 op_sel_hi:[1,0,0]        // 0000005212EC: CC0E0049 0BFC0F4D 0000C931
	v_pk_fma_f16 v74, v74, s7, 0xc931 op_sel_hi:[1,0,0]        // 0000005212F8: CC0E004A 0BFC0F4A 0000C931
	v_dot2acc_f32_f16 v39, v75, v3                             // 000000521304: 044E074B
	v_pk_fma_f16 v72, v72, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000521308: CC0E0048 0BFC0F48 0000C931
	v_lshl_or_b32 v77, v80, 16, v79                            // 000000521314: D656004D 053D2150
	v_dot2acc_f32_f16 v38, v73, v1                             // 00000052131C: 044C0349
	v_bfe_u32 v75, v68, 8, 16                                  // 000000521320: D610004B 02411144
	v_dot2acc_f32_f16 v39, v74, v4                             // 000000521328: 044E094A
	v_bfe_u32 v74, v68, 12, 16                                 // 00000052132C: D610004A 02411944
	v_pk_fma_f16 v70, v77, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000521334: CC0E0046 0BFC0F4D 0000C931
	v_dot2acc_f32_f16 v38, v72, v2                             // 000000521340: 044C0548
	v_bfe_u32 v72, v69, 12, 16                                 // 000000521344: D6100048 02411945
	v_and_b32_e32 v68, 0xffff, v68                             // 00000052134C: 368888FF 0000FFFF
	v_and_b32_e32 v73, 0xffff, v69                             // 000000521354: 36928AFF 0000FFFF
	.long 0xd72c004c                                           // 00000052135C: D72C004C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v76, vcc_lo              // 000000521360: 020298FF 83DCD12D
	v_dot2acc_f32_f16 v38, v70, v3                             // 000000521368: 044C0746
	v_bfe_u32 v70, v69, 8, 16                                  // 00000052136C: D6100046 02411145
	.long 0xd72c0048                                           // 000000521374: D72C0048
	v_cndmask_b32_e32 v1, 0x83dcd12d, v72, vcc_lo              // 000000521378: 020290FF 83DCD12D
	.long 0xd72c0044                                           // 000000521380: D72C0044
	v_cndmask_b32_e32 v1, 0x83dcd12d, v68, vcc_lo              // 000000521384: 020288FF 83DCD12D
	v_bfe_u32 v69, v69, 4, 16                                  // 00000052138C: D6100045 02410945
	.long 0xd72c0049                                           // 000000521394: D72C0049
	v_cndmask_b32_e32 v1, 0x83dcd12d, v73, vcc_lo              // 000000521398: 020292FF 83DCD12D
	.long 0xd72c0046                                           // 0000005213A0: D72C0046
	v_cndmask_b32_e32 v1, 0x83dcd12d, v70, vcc_lo              // 0000005213A4: 02028CFF 83DCD12D
	.long 0xd72c004a                                           // 0000005213AC: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 0000005213B0: 020294FF 83DCD12D
	v_sad_u8 v76, v76, 0, 0x6400                               // 0000005213B8: D622004C 03FD014C 00006400
	.long 0xd72c0045                                           // 0000005213C4: D72C0045
	v_cndmask_b32_e32 v1, 0x83dcd12d, v69, vcc_lo              // 0000005213C8: 02028AFF 83DCD12D
	v_sad_u8 v72, v72, 0, 0x6400                               // 0000005213D0: D6220048 03FD0148 00006400
	v_sad_u8 v68, v68, 0, 0x6400                               // 0000005213DC: D6220044 03FD0144 00006400
	.long 0xd72c004b                                           // 0000005213E8: D72C004B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v75, vcc_lo              // 0000005213EC: 020296FF 83DCD12D
	v_sad_u8 v73, v73, 0, 0x6400                               // 0000005213F4: D6220049 03FD0149 00006400
	v_sad_u8 v70, v70, 0, 0x6400                               // 000000521400: D6220046 03FD0146 00006400
	v_and_b32_e32 v72, 0xffff, v72                             // 00000052140C: 369090FF 0000FFFF
	v_lshlrev_b32_e32 v68, 16, v68                             // 000000521414: 30888890
	v_sad_u8 v74, v74, 0, 0x6400                               // 000000521418: D622004A 03FD014A 00006400
	v_sad_u8 v69, v69, 0, 0x6400                               // 000000521424: D6220045 03FD0145 00006400
	v_lshlrev_b32_e32 v73, 16, v73                             // 000000521430: 30929290
	v_lshl_or_b32 v70, v70, 16, v72                            // 000000521434: D6560046 05212146
	v_and_or_b32 v52, 0xffff, v76, v68                         // 00000052143C: D6570034 051298FF 0000FFFF
	v_sad_u8 v75, v75, 0, 0x6400                               // 000000521448: D622004B 03FD014B 00006400
	.long 0xd72c004e                                           // 000000521454: D72C004E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v83, vcc_lo              // 000000521458: 0202A6FF 83DCD12D
	v_and_or_b32 v69, 0xffff, v69, v73                         // 000000521460: D6570045 05268AFF 0000FFFF
	v_pk_fma_f16 v68, v70, s7, 0xc931 op_sel_hi:[1,0,0]        // 00000052146C: CC0E0044 0BFC0F46 0000C931
	v_pk_fma_f16 v52, v52, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000521478: CC0E0034 0BFC0F34 0000C931
	v_and_b32_e32 v74, 0xffff, v74                             // 000000521484: 369494FF 0000FFFF
	s_waitcnt vmcnt(1)                                         // 00000052148C: BF8907F7
	v_bfe_u32 v73, v50, 12, 16                                 // 000000521490: D6100049 02411932
	v_pk_fma_f16 v69, v69, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000521498: CC0E0045 0BFC0F45 0000C931
	v_dual_dot2acc_f32_f16 v37, v68, v1 :: v_dual_and_b32 v68, 0xffff, v51// 0000005214A4: CB240344 254466FF 0000FFFF
	v_lshl_or_b32 v72, v75, 16, v74                            // 0000005214B0: D6560048 0529214B
	v_bfe_u32 v74, v51, 8, 16                                  // 0000005214B8: D610004A 02411133
	.long 0xd72c0049                                           // 0000005214C0: D72C0049
	v_cndmask_b32_e32 v1, 0x83dcd12d, v73, vcc_lo              // 0000005214C4: 020292FF 83DCD12D
	v_bfe_u32 v75, v50, 8, 16                                  // 0000005214CC: D610004B 02411132
	.long 0xd72c0044                                           // 0000005214D4: D72C0044
	v_cndmask_b32_e32 v1, 0x83dcd12d, v68, vcc_lo              // 0000005214D8: 020288FF 83DCD12D
	v_pk_fma_f16 v70, v72, s7, 0xc931 op_sel_hi:[1,0,0]        // 0000005214E0: CC0E0046 0BFC0F48 0000C931
	v_bfe_u32 v72, v51, 12, 16                                 // 0000005214EC: D6100048 02411933
	v_bfe_u32 v51, v51, 4, 16                                  // 0000005214F4: D6100033 02410933
	v_dot2acc_f32_f16 v37, v69, v2                             // 0000005214FC: 044A0545
	.long 0xd72c0045                                           // 000000521500: D72C0045
	v_cndmask_b32_e32 v1, 0x83dcd12d, v75, vcc_lo              // 000000521504: 020296FF 83DCD12D
	v_sad_u8 v73, v73, 0, 0x6400                               // 00000052150C: D6220049 03FD0149 00006400
	.long 0xd72c0048                                           // 000000521518: D72C0048
	v_cndmask_b32_e32 v1, 0x83dcd12d, v72, vcc_lo              // 00000052151C: 020290FF 83DCD12D
	.long 0xd72c0033                                           // 000000521524: D72C0033
	v_cndmask_b32_e32 v1, 0x83dcd12d, v51, vcc_lo              // 000000521528: 020266FF 83DCD12D
	v_sad_u8 v68, v68, 0, 0x6400                               // 000000521530: D6220044 03FD0144 00006400
	.long 0xd72c004a                                           // 00000052153C: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 000000521540: 020294FF 83DCD12D
	v_and_b32_e32 v73, 0xffff, v73                             // 000000521548: 369292FF 0000FFFF
	v_dot2acc_f32_f16 v37, v70, v3                             // 000000521550: 044A0746
	v_sad_u8 v69, v69, 0, 0x6400                               // 000000521554: D6220045 03FD0145 00006400
	v_lshlrev_b32_e32 v68, 16, v68                             // 000000521560: 30888890
	v_sad_u8 v72, v72, 0, 0x6400                               // 000000521564: D6220048 03FD0148 00006400
	v_sad_u8 v51, v51, 0, 0x6400                               // 000000521570: D6220033 03FD0133 00006400
	v_bfe_u32 v70, v44, 12, 16                                 // 00000052157C: D6100046 0241192C
	v_sad_u8 v74, v74, 0, 0x6400                               // 000000521584: D622004A 03FD014A 00006400
	v_bfe_u32 v75, v50, 4, 16                                  // 000000521590: D610004B 02410932
	v_and_b32_e32 v72, 0xffff, v72                             // 000000521598: 369090FF 0000FFFF
	v_and_or_b32 v51, 0xffff, v51, v68                         // 0000005215A0: D6570033 051266FF 0000FFFF
	v_lshl_or_b32 v68, v69, 16, v73                            // 0000005215AC: D6560044 05252145
	.long 0xd72c0046                                           // 0000005215B4: D72C0046
	v_cndmask_b32_e32 v1, 0x83dcd12d, v70, vcc_lo              // 0000005215B8: 02028CFF 83DCD12D
	v_bfe_u32 v73, v44, 8, 16                                  // 0000005215C0: D6100049 0241112C
	v_and_b32_e32 v50, 0xffff, v50                             // 0000005215C8: 366464FF 0000FFFF
	v_lshl_or_b32 v72, v74, 16, v72                            // 0000005215D0: D6560048 0521214A
	s_waitcnt vmcnt(0)                                         // 0000005215D8: BF8903F7
	v_bfe_u32 v74, v43, 12, 16                                 // 0000005215DC: D610004A 0241192B
	.long 0xd72c0045                                           // 0000005215E4: D72C0045
	v_cndmask_b32_e32 v1, 0x83dcd12d, v75, vcc_lo              // 0000005215E8: 020296FF 83DCD12D
	.long 0xd72c0049                                           // 0000005215F0: D72C0049
	v_cndmask_b32_e32 v1, 0x83dcd12d, v73, vcc_lo              // 0000005215F4: 020292FF 83DCD12D
	.long 0xd72c002d                                           // 0000005215FC: D72C002D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v50, vcc_lo              // 000000521600: 020264FF 83DCD12D
	v_sad_u8 v70, v70, 0, 0x6400                               // 000000521608: D6220046 03FD0146 00006400
	v_bfe_u32 v75, v43, 8, 16                                  // 000000521614: D610004B 0241112B
	.long 0xd72c004a                                           // 00000052161C: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 000000521620: 020294FF 83DCD12D
	v_pk_fma_f16 v50, v72, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000521628: CC0E0032 0BFC0F48 0000C931
	v_pk_fma_f16 v51, v51, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000521634: CC0E0033 0BFC0F33 0000C931
	v_and_b32_e32 v70, 0xffff, v70                             // 000000521640: 368C8CFF 0000FFFF
	v_sad_u8 v73, v73, 0, 0x6400                               // 000000521648: D6220049 03FD0149 00006400
	.long 0xd72c004b                                           // 000000521654: D72C004B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v75, vcc_lo              // 000000521658: 020296FF 83DCD12D
	v_sad_u8 v45, v45, 0, 0x6400                               // 000000521660: D622002D 03FD012D 00006400
	v_sad_u8 v69, v69, 0, 0x6400                               // 00000052166C: D6220045 03FD0145 00006400
	v_sad_u8 v74, v74, 0, 0x6400                               // 000000521678: D622004A 03FD014A 00006400
	v_lshl_or_b32 v70, v73, 16, v70                            // 000000521684: D6560046 05192149
	v_dot2acc_f32_f16 v36, v50, v1                             // 00000052168C: 04480332
	v_lshlrev_b32_e32 v45, 16, v45                             // 000000521690: 305A5A90
	v_pk_fma_f16 v68, v68, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000521694: CC0E0044 0BFC0F44 0000C931
	v_and_b32_e32 v73, 0xffff, v74                             // 0000005216A0: 369294FF 0000FFFF
	v_sad_u8 v74, v75, 0, 0x6400                               // 0000005216A8: D622004A 03FD014B 00006400
	v_pk_fma_f16 v50, v70, s7, 0xc931 op_sel_hi:[1,0,0]        // 0000005216B4: CC0E0032 0BFC0F46 0000C931
	v_dot2acc_f32_f16 v36, v51, v2                             // 0000005216C0: 04480533
	v_sad_u8 v78, v78, 0, 0x6400                               // 0000005216C4: D622004E 03FD014E 00006400
	v_and_b32_e32 v72, 0xffff, v44                             // 0000005216D0: 369058FF 0000FFFF
	v_lshl_or_b32 v70, v74, 16, v73                            // 0000005216D8: D6560046 0525214A
	v_dual_dot2acc_f32_f16 v35, v50, v1 :: v_dual_mov_b32 v74, v31// 0000005216E0: CB100332 234A011F
	v_and_or_b32 v1, 0xffff, v69, v45                          // 0000005216E8: D6570001 04B68AFF 0000FFFF
	v_dot2acc_f32_f16 v36, v68, v3                             // 0000005216F4: 04480744
	v_mov_b32_e32 v50, v25                                     // 0000005216F8: 7E640319
	v_bfe_u32 v44, v44, 4, 16                                  // 0000005216FC: D610002C 0241092C
	v_bfe_u32 v76, v43, 4, 16                                  // 000000521704: D610004C 0241092B
	v_pk_fma_f16 v1, v1, s7, 0xc931 op_sel_hi:[1,0,0]          // 00000052170C: CC0E0001 0BFC0F01 0000C931
	v_and_b32_e32 v71, 0xffff, v71                             // 000000521718: 368E8EFF 0000FFFF
	v_and_b32_e32 v43, 0xffff, v43                             // 000000521720: 365656FF 0000FFFF
	.long 0xd72c002c                                           // 000000521728: D72C002C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v44, vcc_lo              // 00000052172C: 020258FF 83DCD12D
	v_pk_fma_f16 v45, v70, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000521734: CC0E002D 0BFC0F46 0000C931
	v_dot2acc_f32_f16 v36, v1, v4                              // 000000521740: 04480901
	.long 0xd72c0047                                           // 000000521744: D72C0047
	v_cndmask_b32_e32 v1, 0x83dcd12d, v71, vcc_lo              // 000000521748: 02028EFF 83DCD12D
	.long 0xd72c002b                                           // 000000521750: D72C002B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v43, vcc_lo              // 000000521754: 020256FF 83DCD12D
	v_dual_mov_b32 v80, v33 :: v_dual_dot2acc_f32_f16 v37, v52, v4// 00000052175C: CA180121 50240934
	v_mov_b32_e32 v52, v20                                     // 000000521764: 7E680314
	v_sad_u8 v44, v44, 0, 0x6400                               // 000000521768: D622002C 03FD012C 00006400
	v_dual_mov_b32 v51, v13 :: v_dual_mov_b32 v68, v27         // 000000521774: CA10010D 3344011B
	v_sad_u8 v71, v71, 0, 0x6400                               // 00000052177C: D6220047 03FD0147 00006400
	v_sad_u8 v43, v43, 0, 0x6400                               // 000000521788: D622002B 03FD012B 00006400
	v_dual_mov_b32 v70, v21 :: v_dual_mov_b32 v69, v14         // 000000521794: CA100115 4644010E
	v_mov_b32_e32 v73, v22                                     // 00000052179C: 7E920316
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000005217A0: BF870214
	v_lshlrev_b32_e32 v71, 16, v71                             // 0000005217A4: 308E8E90
	v_lshlrev_b32_e32 v43, 16, v43                             // 0000005217A8: 30565690
	v_mov_b32_e32 v77, v32                                     // 0000005217AC: 7E9A0320
	v_mov_b32_e32 v79, v26                                     // 0000005217B0: 7E9E031A
	v_dual_mov_b32 v81, v18 :: v_dual_mov_b32 v20, v61         // 0000005217B4: CA100112 5114013D
	v_and_or_b32 v71, 0xffff, v78, v71                         // 0000005217BC: D6570047 051E9CFF 0000FFFF
	v_dual_mov_b32 v75, v16 :: v_dual_mov_b32 v78, v17         // 0000005217C8: CA100110 4B4E0111
	v_dual_mov_b32 v83, v34 :: v_dual_mov_b32 v22, v63         // 0000005217D0: CA100122 5316013F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000005217D8: BF870243
	v_pk_fma_f16 v71, v71, s7, 0xc931 op_sel_hi:[1,0,0]        // 0000005217DC: CC0E0047 0BFC0F47 0000C931
	v_dual_mov_b32 v25, v61 :: v_dual_mov_b32 v16, v56         // 0000005217E8: CA10013D 19100138
	v_mov_b32_e32 v13, v53                                     // 0000005217F0: 7E1A0335
	v_dual_mov_b32 v27, v62 :: v_dual_mov_b32 v32, v65         // 0000005217F4: CA10013E 1B200141
	v_dual_dot2acc_f32_f16 v38, v71, v4 :: v_dual_mov_b32 v71, v29// 0000005217FC: CB100947 2646011D
	.long 0xd72c0048                                           // 000000521804: D72C0048
	v_cndmask_b32_e32 v1, 0x83dcd12d, v72, vcc_lo              // 000000521808: 020290FF 83DCD12D
	v_dual_mov_b32 v21, v62 :: v_dual_mov_b32 v26, v65         // 000000521810: CA10013E 151A0141
	v_dual_mov_b32 v29, v63 :: v_dual_mov_b32 v18, v60         // 000000521818: CA10013F 1D12013C
	v_dual_mov_b32 v31, v64 :: v_dual_mov_b32 v34, v67         // 000000521820: CA100140 1F220143
	v_mov_b32_e32 v82, v28                                     // 000000521828: 7EA4031C
	v_sad_u8 v72, v72, 0, 0x6400                               // 00000052182C: D6220048 03FD0148 00006400
	v_dual_mov_b32 v14, v54 :: v_dual_mov_b32 v17, v57         // 000000521838: CA100136 0E100139
	v_mov_b32_e32 v33, v66                                     // 000000521840: 7E420342
	v_mov_b32_e32 v28, v66                                     // 000000521844: 7E380342
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000521848: BF870094
	v_lshlrev_b32_e32 v72, 16, v72                             // 00000052184C: 30909090
	v_and_or_b32 v44, 0xffff, v44, v72                         // 000000521850: D657002C 052258FF 0000FFFF
	.long 0xd72c0048                                           // 00000052185C: D72C0048
	v_cndmask_b32_e32 v1, 0x83dcd12d, v76, vcc_lo              // 000000521860: 020298FF 83DCD12D
	v_mov_b32_e32 v76, v24                                     // 000000521868: 7E980318
	v_mov_b32_e32 v24, v64                                     // 00000052186C: 7E300340
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000521870: BF870214
	v_pk_fma_f16 v44, v44, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000521874: CC0E002C 0BFC0F2C 0000C931
	v_sad_u8 v72, v72, 0, 0x6400                               // 000000521880: D6220048 03FD0148 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000052188C: BF870232
	v_dot2acc_f32_f16 v35, v44, v2                             // 000000521890: 0446052C
	v_mov_b32_e32 v44, v12                                     // 000000521894: 7E58030C
	v_mov_b32_e32 v12, v6                                      // 000000521898: 7E180306
	v_and_or_b32 v43, 0xffff, v72, v43                         // 00000052189C: D657002B 04AE90FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4)                            // 0000005218A8: BF870004
	v_dot2acc_f32_f16 v35, v45, v3                             // 0000005218AC: 0446072D
	v_add_nc_u32_e32 v3, v46, v5                               // 0000005218B0: 4A060B2E
	v_mov_b32_e32 v45, v19                                     // 0000005218B4: 7E5A0313
	v_mov_b32_e32 v72, v15                                     // 0000005218B8: 7E90030F
	v_pk_fma_f16 v2, v43, s7, 0xc931 op_sel_hi:[1,0,0]         // 0000005218BC: CC0E0002 0BFC0F2B 0000C931
	v_mov_b32_e32 v43, v23                                     // 0000005218C8: 7E560317
	v_cmp_eq_u32_e32 vcc_lo, 2, v3                             // 0000005218CC: 7C940682
	v_mov_b32_e32 v3, v30                                      // 0000005218D0: 7E06031E
	v_mov_b32_e32 v23, v59                                     // 0000005218D4: 7E2E033B
	v_dual_dot2acc_f32_f16 v35, v2, v4 :: v_dual_mov_b32 v2, v11// 0000005218D8: CB100902 2302010B
	v_mov_b32_e32 v19, v59                                     // 0000005218E0: 7E26033B
	v_mov_b32_e32 v15, v55                                     // 0000005218E4: 7E1E0337
	v_dual_mov_b32 v30, v67 :: v_dual_mov_b32 v11, v58         // 0000005218E8: CA100143 1E0A013A
	s_or_b32 s6, vcc_lo, s6                                    // 0000005218F0: 8C06066A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000005218F4: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 0000005218F8: 917E067E
	s_cbranch_execz 56                                         // 0000005218FC: BFA50038 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb1ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1ae0>
	s_mov_b32 s8, exec_lo                                      // 000000521900: BE88007E
	.long 0xd4c1007e                                           // 000000521904: D4C1007E
	v_cndmask_b32_e32 v1, v5, v7, vcc_lo                       // 000000521908: 02020F05
	s_cbranch_execz 64651                                      // 00000052190C: BFA5FC8B <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb1ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0xc3c>
	v_ashrrev_i32_e32 v6, 31, v5                               // 000000521910: 340C0A9F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000521914: BF870091
	.long 0xd73c0035                                           // 000000521918: D73C0035
	v_cndmask_b32_e32 v1, 10, v5, vcc_lo                       // 00000052191C: 02020A8A
	.long 0xd7006a01                                           // 000000521920: D7006A01
	v_cndmask_b32_e32 v1, s1, v53, vcc_lo                      // 000000521924: 02026A01
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000521928: BF870111
	v_add_co_ci_u32_e64 v4, null, s5, v54, vcc_lo              // 00000052192C: D5207C04 01AA6C05
	.long 0xd7006a3d                                           // 000000521934: D7006A3D
	v_cndmask_b32_e32 v1, v1, v49, vcc_lo                      // 000000521938: 02026301
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000052193C: BF8700A1
	v_add_co_ci_u32_e64 v62, null, 0, v4, vcc_lo               // 000000521940: D5207C3E 01AA0880
	.long 0xd7006a54                                           // 000000521948: D7006A54
	v_cndmask_b32_e32 v1, v1, v47, vcc_lo                      // 00000052194C: 02025F01
	v_add_co_ci_u32_e64 v85, null, 0, v4, vcc_lo               // 000000521950: D5207C55 01AA0880
	s_clause 0xf                                               // 000000521958: BF85000F
	global_load_b32 v58, v[61:62], off                         // 00000052195C: DC520000 3A7C003D
	global_load_b32 v60, v[61:62], off offset:128              // 000000521964: DC520080 3C7C003D
	global_load_b32 v57, v[61:62], off offset:256              // 00000052196C: DC520100 397C003D
	global_load_b32 v56, v[61:62], off offset:384              // 000000521974: DC520180 387C003D
	global_load_b32 v55, v[61:62], off offset:512              // 00000052197C: DC520200 377C003D
	global_load_b32 v54, v[61:62], off offset:640              // 000000521984: DC520280 367C003D
	global_load_b32 v53, v[61:62], off offset:768              // 00000052198C: DC520300 357C003D
	global_load_b32 v6, v[61:62], off offset:896               // 000000521994: DC520380 067C003D
	global_load_b32 v67, v[84:85], off                         // 00000052199C: DC520000 437C0054
	global_load_b32 v66, v[84:85], off offset:128              // 0000005219A4: DC520080 427C0054
	global_load_b32 v65, v[84:85], off offset:256              // 0000005219AC: DC520100 417C0054
	global_load_b32 v64, v[84:85], off offset:384              // 0000005219B4: DC520180 407C0054
	global_load_b32 v63, v[84:85], off offset:512              // 0000005219BC: DC520200 3F7C0054
	global_load_b32 v62, v[84:85], off offset:640              // 0000005219C4: DC520280 3E7C0054
	global_load_b32 v61, v[84:85], off offset:768              // 0000005219CC: DC520300 3D7C0054
	global_load_b32 v59, v[84:85], off offset:896              // 0000005219D4: DC520380 3B7C0054
	s_branch 64599                                             // 0000005219DC: BFA0FC57 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb1ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0xc3c>
	s_or_b32 exec_lo, exec_lo, s6                              // 0000005219E0: 8C7E067E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000005219E4: BF870009
	s_or_b32 exec_lo, exec_lo, s0                              // 0000005219E8: 8C7E007E
	s_waitcnt vmcnt(23)                                        // 0000005219EC: BF895FF7
	v_dual_mov_b32 v1, v42 :: v_dual_mov_b32 v2, v41           // 0000005219F0: CA10012A 01020129
	s_waitcnt vmcnt(15)                                        // 0000005219F8: BF893FF7
	v_dual_mov_b32 v3, v40 :: v_dual_mov_b32 v4, v38           // 0000005219FC: CA100128 03040126
	v_dual_mov_b32 v7, v39 :: v_dual_mov_b32 v6, v36           // 000000521A04: CA100127 07060124
	v_mov_b32_e32 v5, v37                                      // 000000521A0C: 7E0A0325
	v_mov_b32_e32 v11, v35                                     // 000000521A10: 7E160323
	s_mov_b32 s0, 0x76543210                                   // 000000521A14: BE8000FF 76543210
	s_waitcnt vmcnt(0)                                         // 000000521A1C: BF8903F7
	v_permlanex16_b32 v1, v1, s0, 0xfedcba98                   // 000000521A20: D65C0001 03FC0101 FEDCBA98
	v_permlanex16_b32 v2, v2, s0, 0xfedcba98                   // 000000521A2C: D65C0002 03FC0102 FEDCBA98
	v_permlanex16_b32 v3, v3, s0, 0xfedcba98                   // 000000521A38: D65C0003 03FC0103 FEDCBA98
	v_permlanex16_b32 v7, v7, s0, 0xfedcba98                   // 000000521A44: D65C0007 03FC0107 FEDCBA98
	v_permlanex16_b32 v4, v4, s0, 0xfedcba98                   // 000000521A50: D65C0004 03FC0104 FEDCBA98
	v_permlanex16_b32 v5, v5, s0, 0xfedcba98                   // 000000521A5C: D65C0005 03FC0105 FEDCBA98
	v_permlanex16_b32 v6, v6, s0, 0xfedcba98                   // 000000521A68: D65C0006 03FC0106 FEDCBA98
	v_permlanex16_b32 v11, v11, s0, 0xfedcba98                 // 000000521A74: D65C000B 03FC010B FEDCBA98
	.long 0xd44c0000                                           // 000000521A80: D44C0000
	v_cndmask_b32_e32 v1, 16, v10, vcc_lo                      // 000000521A84: 02021490
	s_barrier                                                  // 000000521A88: BFBD0000
	buffer_gl0_inv                                             // 000000521A8C: E0AC0000 00000000
	s_and_saveexec_b32 s1, s0                                  // 000000521A94: BE812000
	s_cbranch_execz 18                                         // 000000521A98: BFA50012 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb1ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1be4>
	v_dual_add_f32 v10, v35, v11 :: v_dual_add_f32 v1, v42, v1 // 000000521A9C: C9081723 0A00032A
	v_dual_add_f32 v2, v41, v2 :: v_dual_add_f32 v3, v40, v3   // 000000521AA4: C9080529 02020728
	v_lshl_or_b32 v9, v8, 9, v9                                // 000000521AAC: D6560009 04251308
	v_dual_add_f32 v7, v39, v7 :: v_dual_add_f32 v4, v38, v4   // 000000521AB4: C9080F27 07040926
	v_dual_add_f32 v5, v37, v5 :: v_dual_add_f32 v6, v36, v6   // 000000521ABC: C9080B25 05060D24
	ds_store_2addr_b32 v9, v1, v2 offset1:16                   // 000000521AC4: D8381000 00020109
	ds_store_2addr_b32 v9, v3, v7 offset0:32 offset1:48        // 000000521ACC: D8383020 00070309
	ds_store_2addr_b32 v9, v4, v5 offset0:64 offset1:80        // 000000521AD4: D8385040 00050409
	ds_store_2addr_b32 v9, v6, v10 offset0:96 offset1:112      // 000000521ADC: D8387060 000A0609
	s_or_b32 exec_lo, exec_lo, s1                              // 000000521AE4: 8C7E017E
	.long 0xd44c0001                                           // 000000521AE8: D44C0001
	v_cndmask_b32_e32 v1, 0x80, v0, vcc_lo                     // 000000521AEC: 020200FF 00000080
	s_waitcnt lgkmcnt(0)                                       // 000000521AF4: BF89FC07
	s_barrier                                                  // 000000521AF8: BFBD0000
	buffer_gl0_inv                                             // 000000521AFC: E0AC0000 00000000
	s_and_saveexec_b32 s5, s1                                  // 000000521B04: BE852001
	s_cbranch_execnz 7                                         // 000000521B08: BFA60007 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb1ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1c28>
	s_or_b32 exec_lo, exec_lo, s5                              // 000000521B0C: 8C7E057E
	s_cmp_lt_i32 s33, 2                                        // 000000521B10: BF048221
	s_mov_b32 s5, -1                                           // 000000521B14: BE8500C1
	s_cbranch_scc0 33                                          // 000000521B18: BFA10021 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb1ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1ca0>
	s_and_b32 vcc_lo, exec_lo, s5                              // 000000521B1C: 8B6A057E
	s_cbranch_vccnz 154                                        // 000000521B20: BFA4009A <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb1ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1e8c>
	s_endpgm                                                   // 000000521B24: BFB00000
	v_lshlrev_b32_e32 v7, 2, v0                                // 000000521B28: 300E0082
	ds_load_2addr_stride64_b32 v[1:2], v7 offset1:2            // 000000521B2C: D8E00200 01000007
	ds_load_2addr_stride64_b32 v[3:4], v7 offset0:4 offset1:6  // 000000521B34: D8E00604 03000007
	ds_load_2addr_stride64_b32 v[5:6], v7 offset0:8 offset1:10 // 000000521B3C: D8E00A08 05000007
	s_waitcnt lgkmcnt(2)                                       // 000000521B44: BF89FC27
	v_add_f32_e32 v1, 0, v1                                    // 000000521B48: 06020280
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000521B4C: BF8700A1
	v_add_f32_e32 v1, v1, v2                                   // 000000521B50: 06020501
	s_waitcnt lgkmcnt(1)                                       // 000000521B54: BF89FC17
	v_add_f32_e32 v3, v1, v3                                   // 000000521B58: 06060701
	ds_load_2addr_stride64_b32 v[1:2], v7 offset0:12 offset1:14// 000000521B5C: D8E00E0C 01000007
	v_add_f32_e32 v3, v3, v4                                   // 000000521B64: 06060903
	s_waitcnt lgkmcnt(1)                                       // 000000521B68: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000521B6C: BF870091
	v_add_f32_e32 v3, v3, v5                                   // 000000521B70: 06060B03
	v_add_f32_e32 v3, v3, v6                                   // 000000521B74: 06060D03
	s_waitcnt lgkmcnt(0)                                       // 000000521B78: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000521B7C: BF870091
	v_add_f32_e32 v1, v3, v1                                   // 000000521B80: 06020303
	v_add_f32_e32 v1, v1, v2                                   // 000000521B84: 06020501
	ds_store_b32 v7, v1 offset:4096                            // 000000521B88: D8341000 00000107
	s_or_b32 exec_lo, exec_lo, s5                              // 000000521B90: 8C7E057E
	s_cmp_lt_i32 s33, 2                                        // 000000521B94: BF048221
	s_mov_b32 s5, -1                                           // 000000521B98: BE8500C1
	s_cbranch_scc1 65503                                       // 000000521B9C: BFA2FFDF <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb1ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1c1c>
	s_waitcnt lgkmcnt(0)                                       // 000000521BA0: BF89FC07
	s_barrier                                                  // 000000521BA4: BFBD0000
	buffer_gl0_inv                                             // 000000521BA8: E0AC0000 00000000
	s_and_saveexec_b32 s5, s1                                  // 000000521BB0: BE852001
	s_cbranch_execz 17                                         // 000000521BB4: BFA50011 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb1ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1cfc>
	v_lshlrev_b32_e32 v1, 2, v0                                // 000000521BB8: 30020082
	s_mul_hi_i32 s7, s26, s4                                   // 000000521BBC: 9707041A
	s_mul_i32 s6, s26, s4                                      // 000000521BC0: 9606041A
	s_lshl_b32 s8, s2, 7                                       // 000000521BC4: 84088702
	s_lshl_b64 s[6:7], s[6:7], 2                               // 000000521BC8: 84868206
	ds_load_b32 v2, v1 offset:4096                             // 000000521BCC: D8D81000 02000001
	s_ashr_i32 s9, s8, 31                                      // 000000521BD4: 86099F08
	s_add_u32 s4, s16, s6                                      // 000000521BD8: 80040610
	s_addc_u32 s10, s17, s7                                    // 000000521BDC: 820A0711
	s_lshl_b64 s[6:7], s[8:9], 2                               // 000000521BE0: 84868208
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000521BE4: BF870009
	s_add_u32 s6, s4, s6                                       // 000000521BE8: 80060604
	s_addc_u32 s7, s10, s7                                     // 000000521BEC: 8207070A
	s_waitcnt lgkmcnt(0)                                       // 000000521BF0: BF89FC07
	global_store_b32 v1, v2, s[6:7]                            // 000000521BF4: DC6A0000 00060201
	s_or_b32 exec_lo, exec_lo, s5                              // 000000521BFC: 8C7E057E
	.long 0xd44a0004                                           // 000000521C00: D44A0004
	v_cndmask_b32_e32 v1, 0, v0, vcc_lo                        // 000000521C04: 02020080
	s_waitcnt_vscnt null, 0x0                                  // 000000521C08: BC7C0000
	buffer_gl1_inv                                             // 000000521C0C: E0B00000 00000000
	buffer_gl0_inv                                             // 000000521C14: E0AC0000 00000000
	s_barrier                                                  // 000000521C1C: BFBD0000
	buffer_gl0_inv                                             // 000000521C20: E0AC0000 00000000
	s_and_saveexec_b32 s5, s4                                  // 000000521C28: BE852004
	s_cbranch_execz 29                                         // 000000521C2C: BFA5001D <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb1ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1da4>
	s_mov_b32 s7, exec_lo                                      // 000000521C30: BE87007E
	s_mov_b32 s6, exec_lo                                      // 000000521C34: BE86007E
	.long 0xd71f0001                                           // 000000521C38: D71F0001
	v_cndmask_b32_e32 v0, s7, v128, vcc_lo                     // 000000521C3C: 02010007
	s_delay_alu instid0(VALU_DEP_1)                            // 000000521C40: BF870001
	v_cmpx_eq_u32_e32 0, v1                                    // 000000521C44: 7D940280
	s_cbranch_execz 9                                          // 000000521C48: BFA50009 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb1ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1d70>
	s_lshl_b64 s[8:9], s[2:3], 2                               // 000000521C4C: 84888202
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 000000521C50: BF8704B9
	s_add_u32 s8, s18, s8                                      // 000000521C54: 80080812
	s_addc_u32 s9, s19, s9                                     // 000000521C58: 82090913
	s_bcnt1_i32_b32 s7, s7                                     // 000000521C5C: BE871807
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v3, s7              // 000000521C60: CA100080 02020007
	global_atomic_add_u32 v2, v2, v3, s[8:9] glc               // 000000521C68: DCD64000 02080302
	s_or_b32 exec_lo, exec_lo, s6                              // 000000521C70: 8C7E067E
	s_waitcnt vmcnt(0)                                         // 000000521C74: BF8903F7
	v_readfirstlane_b32 s6, v2                                 // 000000521C78: 7E0C0502
	s_delay_alu instid0(VALU_DEP_1)                            // 000000521C7C: BF870001
	v_dual_mov_b32 v2, 0 :: v_dual_add_nc_u32 v1, s6, v1       // 000000521C80: CA200080 02000206
	s_add_i32 s6, s33, -1                                      // 000000521C88: 8106C121
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 000000521C8C: BF870481
	v_cmp_eq_u32_e32 vcc_lo, s6, v1                            // 000000521C90: 7C940206
	v_cndmask_b32_e64 v1, 0, 1, vcc_lo                         // 000000521C94: D5010001 01A90280
	ds_store_b32 v2, v1 offset:5120                            // 000000521C9C: D8341400 00000102
	s_or_b32 exec_lo, exec_lo, s5                              // 000000521CA4: 8C7E057E
	v_mov_b32_e32 v1, 0                                        // 000000521CA8: 7E020280
	s_waitcnt lgkmcnt(0)                                       // 000000521CAC: BF89FC07
	s_barrier                                                  // 000000521CB0: BFBD0000
	buffer_gl0_inv                                             // 000000521CB4: E0AC0000 00000000
	ds_load_b32 v1, v1 offset:5120                             // 000000521CBC: D8D81400 01000001
	s_waitcnt lgkmcnt(0)                                       // 000000521CC4: BF89FC07
	v_cmp_eq_u32_e32 vcc_lo, 0, v1                             // 000000521CC8: 7C940280
	s_cbranch_vccnz 46                                         // 000000521CCC: BFA4002E <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb1ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1e88>
	buffer_gl1_inv                                             // 000000521CD0: E0B00000 00000000
	buffer_gl0_inv                                             // 000000521CD8: E0AC0000 00000000
	s_and_saveexec_b32 s5, s1                                  // 000000521CE0: BE852001
	s_cbranch_execz 28                                         // 000000521CE4: BFA5001C <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb1ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1e58>
	s_lshl_b32 s6, s2, 7                                       // 000000521CE8: 84068702
	v_dual_mov_b32 v4, 0 :: v_dual_lshlrev_b32 v3, 2, v0       // 000000521CEC: CA220080 04020082
	s_ashr_i32 s7, s6, 31                                      // 000000521CF4: 86079F06
	s_ashr_i32 s27, s26, 31                                    // 000000521CF8: 861B9F1A
	s_lshl_b64 s[6:7], s[6:7], 2                               // 000000521CFC: 84868206
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000521D00: BF8700B9
	s_add_u32 s1, s16, s6                                      // 000000521D04: 80010610
	s_addc_u32 s6, s17, s7                                     // 000000521D08: 82060711
	.long 0xd7000101                                           // 000000521D0C: D7000101
	v_cndmask_b32_e32 v1, s1, v3, vcc_lo                       // 000000521D10: 02020601
	v_add_co_ci_u32_e64 v2, null, s6, 0, s1                    // 000000521D14: D5207C02 00050006
	s_lshl_b64 s[6:7], s[26:27], 2                             // 000000521D1C: 8486821A
	global_load_b32 v5, v[1:2], off glc                        // 000000521D20: DC524000 057C0001
	.long 0xd7006a01                                           // 000000521D28: D7006A01
	v_cndmask_b32_e32 v0, v1, v6, vcc_lo                       // 000000521D2C: 02000D01
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000521D30: BF8704A1
	v_add_co_ci_u32_e64 v2, null, s7, v2, vcc_lo               // 000000521D34: D5207C02 01AA0407
	s_add_i32 s33, s33, -1                                     // 000000521D3C: 8121C121
	s_cmp_eq_u32 s33, 0                                        // 000000521D40: BF068021
	s_waitcnt vmcnt(0)                                         // 000000521D44: BF8903F7
	v_add_f32_e32 v4, v4, v5                                   // 000000521D48: 06080B04
	s_cbranch_scc0 65524                                       // 000000521D4C: BFA1FFF4 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb1ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1e20>
	ds_store_b32 v3, v4 offset:4096                            // 000000521D50: D8341000 00000403
	s_or_b32 exec_lo, exec_lo, s5                              // 000000521D58: 8C7E057E
	s_and_saveexec_b32 s1, s4                                  // 000000521D5C: BE812004
	s_cbranch_execz 6                                          // 000000521D60: BFA50006 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb1ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1e7c>
	s_lshl_b64 s[4:5], s[2:3], 2                               // 000000521D64: 84848202
	v_mov_b32_e32 v1, 0                                        // 000000521D68: 7E020280
	s_add_u32 s4, s18, s4                                      // 000000521D6C: 80040412
	s_addc_u32 s5, s19, s5                                     // 000000521D70: 82050513
	global_store_b32 v1, v1, s[4:5]                            // 000000521D74: DC6A0000 00040101
	s_or_b32 exec_lo, exec_lo, s1                              // 000000521D7C: 8C7E017E
	s_cbranch_execz 65384                                      // 000000521D80: BFA5FF68 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb1ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1c24>
	s_branch 1                                                 // 000000521D84: BFA00001 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb1ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1e8c>
	s_branch 65382                                             // 000000521D88: BFA0FF66 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb1ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1c24>
	v_cmp_eq_u32_e32 vcc_lo, 0, v8                             // 000000521D8C: 7C941080
	s_cmp_gt_i32 s24, 0                                        // 000000521D90: BF028018
	s_waitcnt lgkmcnt(0)                                       // 000000521D94: BF89FC07
	s_waitcnt_vscnt null, 0x0                                  // 000000521D98: BC7C0000
	s_cselect_b32 s1, -1, 0                                    // 000000521D9C: 980180C1
	s_barrier                                                  // 000000521DA0: BFBD0000
	s_and_b32 s1, vcc_lo, s1                                   // 000000521DA4: 8B01016A
	buffer_gl0_inv                                             // 000000521DA8: E0AC0000 00000000
	s_and_saveexec_b32 s3, s1                                  // 000000521DB0: BE832001
	s_cbranch_execz 65371                                      // 000000521DB4: BFA5FF5B <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb1ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1c24>
	v_and_b32_e32 v1, 15, v0                                   // 000000521DB8: 3602008F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000521DBC: BF870091
	v_lshlrev_b32_e32 v2, 2, v1                                // 000000521DC0: 30040282
	v_add_nc_u32_e32 v8, 0x1000, v2                            // 000000521DC4: 4A1004FF 00001000
	ds_load_2addr_b32 v[2:3], v8 offset1:16                    // 000000521DCC: D8DC1000 02000008
	ds_load_2addr_b32 v[4:5], v8 offset0:32 offset1:48         // 000000521DD4: D8DC3020 04000008
	ds_load_2addr_b32 v[6:7], v8 offset0:64 offset1:80         // 000000521DDC: D8DC5040 06000008
	ds_load_2addr_b32 v[8:9], v8 offset0:96 offset1:112        // 000000521DE4: D8DC7060 08000008
	v_and_b32_e32 v10, 1, v0                                   // 000000521DEC: 36140081
	s_waitcnt lgkmcnt(3)                                       // 000000521DF0: BF89FC37
	v_dual_add_f32 v12, v2, v3 :: v_dual_and_b32 v11, 2, v0    // 000000521DF4: C9240702 0C0A0082
	s_waitcnt lgkmcnt(2)                                       // 000000521DFC: BF89FC27
	v_dual_sub_f32 v2, v2, v3 :: v_dual_add_f32 v3, v4, v5     // 000000521E00: C9480702 02020B04
	s_waitcnt lgkmcnt(1)                                       // 000000521E08: BF89FC17
	v_dual_sub_f32 v4, v4, v5 :: v_dual_add_f32 v5, v6, v7     // 000000521E0C: C9480B04 04040F06
	s_waitcnt lgkmcnt(0)                                       // 000000521E14: BF89FC07
	v_dual_sub_f32 v6, v6, v7 :: v_dual_sub_f32 v7, v8, v9     // 000000521E18: C94A0F06 06061308
	v_dual_add_f32 v8, v8, v9 :: v_dual_and_b32 v9, 4, v0      // 000000521E20: C9241308 08080084
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000521E28: BF870233
	v_add_f32_e32 v13, v2, v4                                  // 000000521E2C: 061A0902
	v_cmp_eq_u32_e32 vcc_lo, 0, v10                            // 000000521E30: 7C941480
	.long 0xd44a0001                                           // 000000521E34: D44A0001
	v_cndmask_b32_e32 v1, 0, v11, vcc_lo                       // 000000521E38: 02021680
	v_add_f32_e32 v16, v5, v8                                  // 000000521E3C: 06201105
	v_dual_sub_f32 v5, v5, v8 :: v_dual_add_f32 v14, v12, v3   // 000000521E40: C9481105 050E070C
	v_add_f32_e32 v15, v6, v7                                  // 000000521E48: 061E0F06
	v_dual_sub_f32 v3, v12, v3 :: v_dual_sub_f32 v2, v2, v4    // 000000521E4C: C94A070C 03020902
	v_sub_f32_e32 v4, v6, v7                                   // 000000521E54: 08080F06
	.long 0xd44a0003                                           // 000000521E58: D44A0003
	v_cndmask_b32_e32 v1, 0, v9, vcc_lo                        // 000000521E5C: 02021280
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000521E60: BF870214
	v_add_f32_e32 v6, v13, v15                                 // 000000521E64: 060C1F0D
	v_dual_sub_f32 v8, v13, v15 :: v_dual_add_f32 v13, v3, v5  // 000000521E68: C9481F0D 080C0B03
	v_add_f32_e32 v7, v14, v16                                 // 000000521E70: 060E210E
	v_dual_sub_f32 v15, v3, v5 :: v_dual_add_f32 v12, v2, v4   // 000000521E74: C9480B03 0F0C0902
	s_delay_alu instid0(VALU_DEP_4)                            // 000000521E7C: BF870004
	v_mov_b32_dpp v3, v6 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000521E80: 7E0602FA FF016106
	v_sub_f32_e32 v10, v14, v16                                // 000000521E88: 0814210E
	v_sub_f32_e32 v14, v2, v4                                  // 000000521E8C: 081C0902
	v_mov_b32_dpp v2, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000521E90: 7E0402FA FF016107
	v_cndmask_b32_e64 v4, -v6, v6, vcc_lo                      // 000000521E98: D5010004 21AA0D06
	v_cndmask_b32_e64 v5, -v7, v7, vcc_lo                      // 000000521EA0: D5010005 21AA0F07
	v_mov_b32_dpp v16, v13 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000521EA8: 7E2002FA FF01610D
	v_cndmask_b32_e64 v13, -v13, v13, vcc_lo                   // 000000521EB0: D501000D 21AA1B0D
	v_mov_b32_dpp v18, v15 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000521EB8: 7E2402FA FF01610F
	v_add_f32_e32 v3, v4, v3                                   // 000000521EC0: 06060704
	v_mov_b32_dpp v6, v10 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000521EC4: 7E0C02FA FF01610A
	v_cndmask_b32_e64 v10, -v10, v10, vcc_lo                   // 000000521ECC: D501000A 21AA150A
	v_add_f32_e32 v2, v5, v2                                   // 000000521ED4: 06040505
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000521ED8: BF870112
	v_add_f32_e32 v5, v10, v6                                  // 000000521EDC: 060A0D0A
	v_mov_b32_dpp v6, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000521EE0: 7E0C02FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, s1                          // 000000521EE8: D5010002 20060502
	v_mov_b32_dpp v7, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000521EF0: 7E0E02FA FF016108
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 000000521EF8: D5010008 21AA1108
	v_mov_b32_dpp v10, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000521F00: 7E1402FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, s1                          // 000000521F08: D5010005 20060B05
	v_add_f32_e32 v2, v2, v6                                   // 000000521F10: 06040D02
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000521F14: BF870112
	v_add_f32_e32 v10, v5, v10                                 // 000000521F18: 06141505
	v_mov_b32_dpp v6, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000521F1C: 7E0C02FA FF016402
	v_cndmask_b32_e64 v2, -v2, v2, s3                          // 000000521F24: D5010002 200E0502
	v_add_f32_e32 v4, v8, v7                                   // 000000521F2C: 06080F08
	v_cndmask_b32_e64 v8, -v3, v3, s1                          // 000000521F30: D5010008 20060703
	v_mov_b32_dpp v3, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000521F38: 7E0602FA FF016203
	v_add_f32_e32 v7, v13, v16                                 // 000000521F40: 060E210D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000521F44: BF870112
	v_add_f32_e32 v3, v8, v3                                   // 000000521F48: 06060708
	v_mov_b32_dpp v13, v7 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000521F4C: 7E1A02FA FF016207
	v_cndmask_b32_e64 v7, -v7, v7, s1                          // 000000521F54: D5010007 20060F07
	v_mov_b32_dpp v17, v12 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000521F5C: 7E2202FA FF01610C
	v_cndmask_b32_e64 v12, -v12, v12, vcc_lo                   // 000000521F64: D501000C 21AA190C
	v_cndmask_b32_e64 v8, -v3, v3, s3                          // 000000521F6C: D5010008 200E0703
	v_mov_b32_dpp v9, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000521F74: 7E1202FA FF016403
	v_add_f32_e32 v3, v2, v6                                   // 000000521F7C: 06060D02
	v_mov_b32_dpp v11, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000521F80: 7E1602FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, s1                          // 000000521F88: D5010004 20060904
	v_add_f32_e32 v13, v7, v13                                 // 000000521F90: 061A1B07
	v_add_f32_e32 v5, v8, v9                                   // 000000521F94: 060A1308
	v_mov_b32_dpp v8, v10 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000521F98: 7E1002FA FF01640A
	v_cndmask_b32_e64 v9, -v10, v10, s3                        // 000000521FA0: D5010009 200E150A
	v_add_f32_e32 v4, v4, v11                                  // 000000521FA8: 06081704
	v_cndmask_b32_e64 v10, -v15, v15, vcc_lo                   // 000000521FAC: D501000A 21AA1F0F
	v_mov_b32_dpp v19, v14 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000521FB4: 7E2602FA FF01610E
	v_mov_b32_dpp v2, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000521FBC: 7E0402FA FF016803
	v_add_f32_e32 v7, v9, v8                                   // 000000521FC4: 060E1109
	v_mov_b32_dpp v11, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000521FC8: 7E1602FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s3                          // 000000521FD0: D5010004 200E0904
	v_mov_b32_dpp v9, v13 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000521FD8: 7E1202FA FF01640D
	v_cndmask_b32_e64 v13, -v13, v13, s3                       // 000000521FE0: D501000D 200E1B0D
	v_add_f32_e32 v10, v10, v18                                // 000000521FE8: 0614250A
	v_mov_b32_dpp v6, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000521FEC: 7E0C02FA FF016805
	v_add_f32_e32 v4, v4, v11                                  // 000000521FF4: 06081704
	v_cndmask_b32_e64 v11, -v14, v14, vcc_lo                   // 000000521FF8: D501000B 21AA1D0E
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000522000: BF8701A4
	v_mov_b32_dpp v15, v10 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000522004: 7E1E02FA FF01620A
	v_cndmask_b32_e64 v10, -v10, v10, s1                       // 00000052200C: D501000A 2006150A
	v_add_f32_e32 v11, v11, v19                                // 000000522014: 0616270B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000522018: BF870112
	v_dual_add_f32 v8, v10, v15 :: v_dual_add_f32 v15, v13, v9 // 00000052201C: C9081F0A 080E130D
	v_mov_b32_dpp v16, v11 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000522024: 7E2002FA FF01620B
	v_cndmask_b32_e64 v11, -v11, v11, s1                       // 00000052202C: D501000B 2006170B
	v_mov_b32_dpp v9, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000522034: 7E1202FA FF016804
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000052203C: BF870224
	v_cndmask_b32_e64 v18, -v8, v8, s3                         // 000000522040: D5010012 200E1108
	v_add_f32_e32 v12, v12, v17                                // 000000522048: 0618230C
	v_add_f32_e32 v10, v11, v16                                // 00000052204C: 0614210B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000522050: BF8701A2
	v_mov_b32_dpp v14, v12 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000522054: 7E1C02FA FF01620C
	v_cndmask_b32_e64 v12, -v12, v12, s1                       // 00000052205C: D501000C 2006190C
	v_mov_b32_dpp v16, v10 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000522064: 7E2002FA FF01640A
	v_cndmask_b32_e64 v10, -v10, v10, s3                       // 00000052206C: D501000A 200E150A
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000522074: BF8701A3
	v_add_f32_e32 v12, v12, v14                                // 000000522078: 06181D0C
	v_mov_b32_dpp v14, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000052207C: 7E1C02FA FF016408
	v_add_f32_e32 v16, v10, v16                                // 000000522084: 0620210A
	v_mov_b32_dpp v8, v7 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000522088: 7E1002FA FF016807
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000522090: BF870134
	v_mov_b32_dpp v11, v12 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000522094: 7E1602FA FF01640C
	v_cndmask_b32_e64 v12, -v12, v12, s3                       // 00000052209C: D501000C 200E190C
	v_add_f32_e32 v13, v18, v14                                // 0000005220A4: 061A1D12
	v_add_f32_e32 v17, v12, v11                                // 0000005220A8: 0622170C
	v_mov_b32_dpp v11, v15 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000005220AC: 7E1602FA FF01680F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000005220B4: BF870223
	v_mov_b32_dpp v10, v13 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000005220B8: 7E1402FA FF01680D
	v_mov_b32_dpp v12, v16 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000005220C0: 7E1802FA FF016810
	v_mov_b32_dpp v14, v17 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000005220C8: 7E1C02FA FF016811
	s_and_b32 exec_lo, exec_lo, s0                             // 0000005220D0: 8B7E007E
	s_cbranch_execz 65171                                      // 0000005220D4: BFA5FE93 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb1ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1c24>
	v_lshl_or_b32 v18, s2, 7, v1                               // 0000005220D8: D6560012 04050E02
	v_and_b32_e32 v0, 8, v0                                    // 0000005220E0: 36000088
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005220E4: BF870092
	v_ashrrev_i32_e32 v19, 31, v18                             // 0000005220E8: 3426249F
	.long 0xd73c0014                                           // 0000005220EC: D73C0014
	v_cndmask_b32_e32 v1, 1, v18, vcc_lo                       // 0000005220F0: 02022481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005220F4: BF870091
	.long 0xd7006a14                                           // 0000005220F8: D7006A14
	v_cndmask_b32_e32 v1, s14, v20, vcc_lo                     // 0000005220FC: 0202280E
	v_add_co_ci_u32_e64 v21, null, s15, v21, vcc_lo            // 000000522100: D5207C15 01AA2A0F
	v_cmp_eq_u32_e32 vcc_lo, 0, v0                             // 000000522108: 7C940080
	.long 0xd73c0000                                           // 00000052210C: D73C0000
	v_cndmask_b32_e32 v1, 2, v18, vcc_lo                       // 000000522110: 02022482
	s_clause 0x7                                               // 000000522114: BF850007
	global_load_d16_b16 v22, v[20:21], off offset:32           // 000000522118: DC820020 167C0014
	global_load_d16_b16 v23, v[20:21], off                     // 000000522120: DC820000 177C0014
	global_load_d16_b16 v24, v[20:21], off offset:96           // 000000522128: DC820060 187C0014
	global_load_d16_b16 v25, v[20:21], off offset:64           // 000000522130: DC820040 197C0014
	global_load_d16_b16 v26, v[20:21], off offset:160          // 000000522138: DC8200A0 1A7C0014
	global_load_d16_b16 v27, v[20:21], off offset:128          // 000000522140: DC820080 1B7C0014
	global_load_d16_b16 v28, v[20:21], off offset:224          // 000000522148: DC8200E0 1C7C0014
	global_load_d16_b16 v20, v[20:21], off offset:192          // 000000522150: DC8200C0 147C0014
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 000000522158: D5010005 21AA0B05
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 000000522160: D5010003 21AA0703
	v_cndmask_b32_e64 v15, -v15, v15, vcc_lo                   // 000000522168: D501000F 21AA1F0F
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 000000522170: D5010004 21AA0904
	v_cndmask_b32_e64 v7, -v7, v7, vcc_lo                      // 000000522178: D5010007 21AA0F07
	v_add_f32_e32 v5, v5, v6                                   // 000000522180: 060A0D05
	v_cndmask_b32_e64 v6, -v17, v17, vcc_lo                    // 000000522184: D5010006 21AA2311
	v_cndmask_b32_e64 v16, -v16, v16, vcc_lo                   // 00000052218C: D5010010 21AA2110
	v_cndmask_b32_e64 v13, -v13, v13, vcc_lo                   // 000000522194: D501000D 21AA1B0D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000052219C: BF870214
	v_dual_add_f32 v2, v3, v2 :: v_dual_mul_f32 v3, 0x3db504f3, v5// 0000005221A0: C9060503 02020AFF 3DB504F3
	v_dual_add_f32 v5, v6, v14 :: v_dual_add_f32 v6, v15, v11  // 0000005221AC: C9081D06 0506170F
	v_dual_add_f32 v4, v4, v9 :: v_dual_add_f32 v7, v7, v8     // 0000005221B4: C9081304 04061107
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000005221BC: BF870194
	v_dual_add_f32 v8, v16, v12 :: v_dual_add_f32 v9, v13, v10 // 0000005221C0: C9081910 0808150D
	v_dual_mul_f32 v2, 0x3db504f3, v2 :: v_dual_mul_f32 v5, 0x3db504f3, v5// 0000005221C8: C8C604FF 02040AFF 3DB504F3
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000005221D4: BF8700A3
	v_dual_mul_f32 v6, 0x3db504f3, v6 :: v_dual_mul_f32 v7, 0x3db504f3, v7// 0000005221D8: C8C60CFF 06060EFF 3DB504F3
	.long 0xd7006a00                                           // 0000005221E4: D7006A00
	v_cndmask_b32_e32 v1, s28, v0, vcc_lo                      // 0000005221E8: 0202001C
	v_add_co_ci_u32_e64 v1, null, s29, v1, vcc_lo              // 0000005221EC: D5207C01 01AA021D
	v_dual_mul_f32 v4, 0x3db504f3, v4 :: v_dual_mul_f32 v9, 0x3db504f3, v9// 0000005221F4: C8C608FF 040812FF 3DB504F3
	v_mul_f32_e32 v8, 0x3db504f3, v8                           // 000000522200: 101010FF 3DB504F3
	s_waitcnt vmcnt(7)                                         // 000000522208: BF891FF7
	v_fma_mix_f32 v3, v22, v3, neg(0) op_sel_hi:[1,0,0]        // 00000052220C: CC200003 8A020716
	s_waitcnt vmcnt(6)                                         // 000000522214: BF891BF7
	v_fma_mix_f32 v2, v23, v2, neg(0) op_sel_hi:[1,0,0]        // 000000522218: CC200002 8A020517
	s_waitcnt vmcnt(5)                                         // 000000522220: BF8917F7
	v_fma_mix_f32 v5, v24, v5, neg(0) op_sel_hi:[1,0,0]        // 000000522224: CC200005 8A020B18
	s_waitcnt vmcnt(4)                                         // 00000052222C: BF8913F7
	v_fma_mix_f32 v6, v25, v6, neg(0) op_sel_hi:[1,0,0]        // 000000522230: CC200006 8A020D19
	s_waitcnt vmcnt(3)                                         // 000000522238: BF890FF7
	v_fma_mix_f32 v4, v26, v4, neg(0) op_sel_hi:[1,0,0]        // 00000052223C: CC200004 8A02091A
	s_waitcnt vmcnt(2)                                         // 000000522244: BF890BF7
	v_fma_mix_f32 v7, v27, v7, neg(0) op_sel_hi:[1,0,0]        // 000000522248: CC200007 8A020F1B
	s_waitcnt vmcnt(1)                                         // 000000522250: BF8907F7
	v_fma_mix_f32 v8, v28, v8, neg(0) op_sel_hi:[1,0,0]        // 000000522254: CC200008 8A02111C
	s_waitcnt vmcnt(0)                                         // 00000052225C: BF8903F7
	v_fma_mix_f32 v9, v20, v9, neg(0) op_sel_hi:[1,0,0]        // 000000522260: CC200009 8A021314
	s_clause 0x7                                               // 000000522268: BF850007
	global_store_b32 v[0:1], v2, off                           // 00000052226C: DC6A0000 007C0200
	global_store_b32 v[0:1], v3, off offset:64                 // 000000522274: DC6A0040 007C0300
	global_store_b32 v[0:1], v6, off offset:128                // 00000052227C: DC6A0080 007C0600
	global_store_b32 v[0:1], v5, off offset:192                // 000000522284: DC6A00C0 007C0500
	global_store_b32 v[0:1], v7, off offset:256                // 00000052228C: DC6A0100 007C0700
	global_store_b32 v[0:1], v4, off offset:320                // 000000522294: DC6A0140 007C0400
	global_store_b32 v[0:1], v9, off offset:384                // 00000052229C: DC6A0180 007C0900
	global_store_b32 v[0:1], v8, off offset:448                // 0000005222A4: DC6A01C0 007C0800
	s_endpgm                                                   // 0000005222AC: BFB00000
		...

