0000000000851a00 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi2ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi2ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 000000851A00: F4100100 F8000000
	s_ashr_i32 s3, s2, 31                                      // 000000851A08: 86039F02
	v_lshrrev_b32_e32 v2, 2, v0                                // 000000851A0C: 32040082
	s_lshl_b64 s[20:21], s[2:3], 2                             // 000000851A10: 84948202
	v_and_b32_e32 v1, 15, v0                                   // 000000851A14: 3602008F
	v_lshrrev_b32_e32 v28, 6, v0                               // 000000851A18: 32380086
	v_bfe_u32 v29, v0, 5, 1                                    // 000000851A1C: D610001D 02050B00
	v_and_b32_e32 v2, 60, v2                                   // 000000851A24: 360404BC
	v_and_b32_e32 v30, 31, v0                                  // 000000851A28: 363C009F
	v_lshlrev_b32_e32 v1, 2, v1                                // 000000851A2C: 30020282
	.long 0x7f0a3880                                           // 000000851A30: 7F0A3880
	v_lshlrev_b32_e32 v6, 2, v0                                // 000000851A34: 300C0082
	s_waitcnt lgkmcnt(0)                                       // 000000851A38: BF89FC07
	s_clause 0x1                                               // 000000851A3C: BF850001
	global_load_b32 v3, v1, s[4:5]                             // 000000851A40: DC520000 03040001
	global_load_b32 v4, v2, s[4:5]                             // 000000851A48: DC520000 04040002
	s_add_u32 s2, s4, s16                                      // 000000851A50: 80021004
	s_addc_u32 s3, s5, s17                                     // 000000851A54: 82031105
	s_ashr_i32 s16, s11, 31                                    // 000000851A58: 86109F0B
	v_mov_b32_e32 v2, s21                                      // 000000851A5C: 7E040215
	s_lshr_b32 s16, s16, 27                                    // 000000851A60: 85109B10
	v_or_b32_e32 v1, s20, v28                                  // 000000851A64: 38023814
	s_add_u32 s16, s10, s16                                    // 000000851A68: 8010100A
	s_addc_u32 s17, s11, 0                                     // 000000851A6C: 8211800B
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000851A70: BF870099
	s_lshr_b64 s[16:17], s[16:17], 5                           // 000000851A74: 85908510
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[1:2]                  // 000000851A78: 7CA8020C
	s_add_i32 s17, s16, 1                                      // 000000851A7C: 81118110
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000851A80: BF870499
	s_lshr_b32 s22, s17, 31                                    // 000000851A84: 85169F11
	s_add_i32 s17, s17, s22                                    // 000000851A88: 81111611
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 000000851A8C: 02020280
	s_ashr_i32 s17, s17, 1                                     // 000000851A90: 86118111
	v_cndmask_b32_e64 v2, 0, s21, vcc_lo                       // 000000851A94: D5010002 01A82A80
	.long 0xd72c0007                                           // 000000851A9C: D72C0007
	v_cndmask_b32_e32 v1, s17, v29, vcc_lo                     // 000000851AA0: 02023A11
	s_cmpk_lt_i32 s16, 0x201                                   // 000000851AA4: B3900201
	.long 0xd72c0009                                           // 000000851AA8: D72C0009
	v_cndmask_b32_e32 v1, s19, v1, vcc_lo                      // 000000851AAC: 02020213
	v_mad_u64_u32 v[24:25], null, s18, v1, s[2:3]              // 000000851AB0: D6FE7C18 000A0212
	s_cselect_b32 s2, -1, 0                                    // 000000851AB8: 980280C1
	s_cmpk_gt_i32 s16, 0x200                                   // 000000851ABC: B2900200
	v_add_nc_u32_e32 v11, s17, v7                              // 000000851AC0: 4A160E11
	v_add_nc_u32_e32 v31, v7, v30                              // 000000851AC4: 4A3E3D07
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000851AC8: BF8704A2
	v_min_i32_e32 v32, s16, v11                                // 000000851ACC: 22401610
	s_cselect_b32 s16, -1, 0                                   // 000000851AD0: 981080C1
	s_and_b32 vcc_lo, exec_lo, s16                             // 000000851AD4: 8B6A107E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 000000851AD8: BF870151
	.long 0xd4410003                                           // 000000851ADC: D4410003
	v_cndmask_b32_e32 v1, v31, v32, vcc_lo                     // 000000851AE0: 0202411F
	s_waitcnt vmcnt(1)                                         // 000000851AE4: BF8907F7
	v_bfe_u32 v8, v3, 16, 1                                    // 000000851AE8: D6100008 02052103
	s_waitcnt vmcnt(0)                                         // 000000851AF0: BF8903F7
	v_bfe_u32 v10, v4, 16, 1                                   // 000000851AF4: D610000A 02052104
	v_add3_u32 v3, v3, v8, 0x7fff                              // 000000851AFC: D6550003 03FE1103 00007FFF
	.long 0xd72c0008                                           // 000000851B08: D72C0008
	v_cndmask_b32_e32 v1, s18, v2, vcc_lo                      // 000000851B0C: 02020412
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000851B10: BF870193
	v_add3_u32 v4, v4, v10, 0x7fff                             // 000000851B14: D6550004 03FE1504 00007FFF
	.long 0x7e0a3983                                           // 000000851B20: 7E0A3983
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000851B24: BF870113
	v_add3_u32 v33, v9, v25, v8                                // 000000851B28: D6550021 04223309
	v_and_or_b32 v3, 0xffff0000, v4, v5                        // 000000851B30: D6570003 041608FF FFFF0000
	ds_store_b32 v6, v3                                        // 000000851B3C: D8340000 00000306
	s_waitcnt lgkmcnt(0)                                       // 000000851B44: BF89FC07
	s_barrier                                                  // 000000851B48: BFBD0000
	buffer_gl0_inv                                             // 000000851B4C: E0AC0000 00000000
	s_cbranch_vccnz 154                                        // 000000851B54: BFA4009A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi2ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x3c0>
	v_dual_mov_b32 v9, 0 :: v_dual_mov_b32 v8, 0               // 000000851B58: CA100080 09080080
	s_and_saveexec_b32 s17, s3                                 // 000000851B60: BE912003
	s_cbranch_execz 11                                         // 000000851B64: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi2ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x194>
	v_lshlrev_b32_e32 v3, 1, v31                               // 000000851B68: 30063E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000851B6C: BF8700A1
	v_ashrrev_i32_e32 v4, 31, v3                               // 000000851B70: 3408069F
	.long 0xd7006a03                                           // 000000851B74: D7006A03
	v_cndmask_b32_e32 v1, v24, v3, vcc_lo                      // 000000851B78: 02020718
	v_add_co_ci_u32_e64 v4, null, v33, v4, vcc_lo              // 000000851B7C: D5207C04 01AA0921
	global_load_d16_b16 v3, v[3:4], off                        // 000000851B84: DC820000 037C0003
	s_waitcnt vmcnt(0)                                         // 000000851B8C: BF8903F7
	v_cvt_f32_f16_e32 v8, v3                                   // 000000851B90: 7E101703
	s_or_b32 exec_lo, exec_lo, s17                             // 000000851B94: 8C7E117E
	v_add_nc_u32_e32 v3, 32, v31                               // 000000851B98: 4A063EA0
	s_mov_b32 s3, exec_lo                                      // 000000851B9C: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000851BA0: BF870001
	.long 0xd4c1007e                                           // 000000851BA4: D4C1007E
	v_cndmask_b32_e32 v1, v3, v32, vcc_lo                      // 000000851BA8: 02024103
	s_cbranch_execz 11                                         // 000000851BAC: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi2ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x1dc>
	v_lshlrev_b32_e32 v3, 1, v3                                // 000000851BB0: 30060681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000851BB4: BF8700A1
	v_ashrrev_i32_e32 v4, 31, v3                               // 000000851BB8: 3408069F
	.long 0xd7006a03                                           // 000000851BBC: D7006A03
	v_cndmask_b32_e32 v1, v24, v3, vcc_lo                      // 000000851BC0: 02020718
	v_add_co_ci_u32_e64 v4, null, v33, v4, vcc_lo              // 000000851BC4: D5207C04 01AA0921
	global_load_d16_b16 v3, v[3:4], off                        // 000000851BCC: DC820000 037C0003
	s_waitcnt vmcnt(0)                                         // 000000851BD4: BF8903F7
	v_cvt_f32_f16_e32 v9, v3                                   // 000000851BD8: 7E121703
	s_or_b32 exec_lo, exec_lo, s3                              // 000000851BDC: 8C7E037E
	v_dual_mov_b32 v10, 0 :: v_dual_add_nc_u32 v3, 64, v31     // 000000851BE0: CA200080 0A023EC0
	v_mov_b32_e32 v11, 0                                       // 000000851BE8: 7E160280
	s_mov_b32 s3, exec_lo                                      // 000000851BEC: BE83007E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000851BF0: BF870002
	.long 0xd4c1007e                                           // 000000851BF4: D4C1007E
	v_cndmask_b32_e32 v1, v3, v32, vcc_lo                      // 000000851BF8: 02024103
	s_cbranch_execz 11                                         // 000000851BFC: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi2ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x22c>
	v_lshlrev_b32_e32 v3, 1, v3                                // 000000851C00: 30060681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000851C04: BF8700A1
	v_ashrrev_i32_e32 v4, 31, v3                               // 000000851C08: 3408069F
	.long 0xd7006a03                                           // 000000851C0C: D7006A03
	v_cndmask_b32_e32 v1, v24, v3, vcc_lo                      // 000000851C10: 02020718
	v_add_co_ci_u32_e64 v4, null, v33, v4, vcc_lo              // 000000851C14: D5207C04 01AA0921
	global_load_d16_b16 v3, v[3:4], off                        // 000000851C1C: DC820000 037C0003
	s_waitcnt vmcnt(0)                                         // 000000851C24: BF8903F7
	v_cvt_f32_f16_e32 v10, v3                                  // 000000851C28: 7E141703
	s_or_b32 exec_lo, exec_lo, s3                              // 000000851C2C: 8C7E037E
	v_add_nc_u32_e32 v3, 0x60, v31                             // 000000851C30: 4A063EFF 00000060
	s_mov_b32 s3, exec_lo                                      // 000000851C38: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000851C3C: BF870001
	.long 0xd4c1007e                                           // 000000851C40: D4C1007E
	v_cndmask_b32_e32 v1, v3, v32, vcc_lo                      // 000000851C44: 02024103
	s_cbranch_execz 11                                         // 000000851C48: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi2ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x278>
	v_lshlrev_b32_e32 v3, 1, v3                                // 000000851C4C: 30060681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000851C50: BF8700A1
	v_ashrrev_i32_e32 v4, 31, v3                               // 000000851C54: 3408069F
	.long 0xd7006a03                                           // 000000851C58: D7006A03
	v_cndmask_b32_e32 v1, v24, v3, vcc_lo                      // 000000851C5C: 02020718
	v_add_co_ci_u32_e64 v4, null, v33, v4, vcc_lo              // 000000851C60: D5207C04 01AA0921
	global_load_d16_b16 v3, v[3:4], off                        // 000000851C68: DC820000 037C0003
	s_waitcnt vmcnt(0)                                         // 000000851C70: BF8903F7
	v_cvt_f32_f16_e32 v11, v3                                  // 000000851C74: 7E161703
	s_or_b32 exec_lo, exec_lo, s3                              // 000000851C78: 8C7E037E
	v_dual_mov_b32 v12, 0 :: v_dual_add_nc_u32 v3, 0x80, v31   // 000000851C7C: CA200080 0C023EFF 00000080
	v_mov_b32_e32 v13, 0                                       // 000000851C88: 7E1A0280
	s_mov_b32 s3, exec_lo                                      // 000000851C8C: BE83007E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000851C90: BF870002
	.long 0xd4c1007e                                           // 000000851C94: D4C1007E
	v_cndmask_b32_e32 v1, v3, v32, vcc_lo                      // 000000851C98: 02024103
	s_cbranch_execz 11                                         // 000000851C9C: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi2ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x2cc>
	v_lshlrev_b32_e32 v3, 1, v3                                // 000000851CA0: 30060681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000851CA4: BF8700A1
	v_ashrrev_i32_e32 v4, 31, v3                               // 000000851CA8: 3408069F
	.long 0xd7006a03                                           // 000000851CAC: D7006A03
	v_cndmask_b32_e32 v1, v24, v3, vcc_lo                      // 000000851CB0: 02020718
	v_add_co_ci_u32_e64 v4, null, v33, v4, vcc_lo              // 000000851CB4: D5207C04 01AA0921
	global_load_d16_b16 v3, v[3:4], off                        // 000000851CBC: DC820000 037C0003
	s_waitcnt vmcnt(0)                                         // 000000851CC4: BF8903F7
	v_cvt_f32_f16_e32 v12, v3                                  // 000000851CC8: 7E181703
	s_or_b32 exec_lo, exec_lo, s3                              // 000000851CCC: 8C7E037E
	v_add_nc_u32_e32 v3, 0xa0, v31                             // 000000851CD0: 4A063EFF 000000A0
	s_mov_b32 s3, exec_lo                                      // 000000851CD8: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000851CDC: BF870001
	.long 0xd4c1007e                                           // 000000851CE0: D4C1007E
	v_cndmask_b32_e32 v1, v3, v32, vcc_lo                      // 000000851CE4: 02024103
	s_cbranch_execz 11                                         // 000000851CE8: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi2ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x318>
	v_lshlrev_b32_e32 v3, 1, v3                                // 000000851CEC: 30060681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000851CF0: BF8700A1
	v_ashrrev_i32_e32 v4, 31, v3                               // 000000851CF4: 3408069F
	.long 0xd7006a03                                           // 000000851CF8: D7006A03
	v_cndmask_b32_e32 v1, v24, v3, vcc_lo                      // 000000851CFC: 02020718
	v_add_co_ci_u32_e64 v4, null, v33, v4, vcc_lo              // 000000851D00: D5207C04 01AA0921
	global_load_d16_b16 v3, v[3:4], off                        // 000000851D08: DC820000 037C0003
	s_waitcnt vmcnt(0)                                         // 000000851D10: BF8903F7
	v_cvt_f32_f16_e32 v13, v3                                  // 000000851D14: 7E1A1703
	s_or_b32 exec_lo, exec_lo, s3                              // 000000851D18: 8C7E037E
	v_dual_mov_b32 v14, 0 :: v_dual_add_nc_u32 v3, 0xc0, v31   // 000000851D1C: CA200080 0E023EFF 000000C0
	v_mov_b32_e32 v15, 0                                       // 000000851D28: 7E1E0280
	s_mov_b32 s3, exec_lo                                      // 000000851D2C: BE83007E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000851D30: BF870002
	.long 0xd4c1007e                                           // 000000851D34: D4C1007E
	v_cndmask_b32_e32 v1, v3, v32, vcc_lo                      // 000000851D38: 02024103
	s_cbranch_execz 11                                         // 000000851D3C: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi2ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x36c>
	v_lshlrev_b32_e32 v3, 1, v3                                // 000000851D40: 30060681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000851D44: BF8700A1
	v_ashrrev_i32_e32 v4, 31, v3                               // 000000851D48: 3408069F
	.long 0xd7006a03                                           // 000000851D4C: D7006A03
	v_cndmask_b32_e32 v1, v24, v3, vcc_lo                      // 000000851D50: 02020718
	v_add_co_ci_u32_e64 v4, null, v33, v4, vcc_lo              // 000000851D54: D5207C04 01AA0921
	global_load_d16_b16 v3, v[3:4], off                        // 000000851D5C: DC820000 037C0003
	s_waitcnt vmcnt(0)                                         // 000000851D64: BF8903F7
	v_cvt_f32_f16_e32 v14, v3                                  // 000000851D68: 7E1C1703
	s_or_b32 exec_lo, exec_lo, s3                              // 000000851D6C: 8C7E037E
	v_add_nc_u32_e32 v3, 0xe0, v31                             // 000000851D70: 4A063EFF 000000E0
	s_mov_b32 s3, exec_lo                                      // 000000851D78: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000851D7C: BF870001
	.long 0xd4c1007e                                           // 000000851D80: D4C1007E
	v_cndmask_b32_e32 v1, v3, v32, vcc_lo                      // 000000851D84: 02024103
	s_cbranch_execz 11                                         // 000000851D88: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi2ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x3b8>
	v_lshlrev_b32_e32 v3, 1, v3                                // 000000851D8C: 30060681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000851D90: BF8700A1
	v_ashrrev_i32_e32 v4, 31, v3                               // 000000851D94: 3408069F
	.long 0xd7006a03                                           // 000000851D98: D7006A03
	v_cndmask_b32_e32 v1, v24, v3, vcc_lo                      // 000000851D9C: 02020718
	v_add_co_ci_u32_e64 v4, null, v33, v4, vcc_lo              // 000000851DA0: D5207C04 01AA0921
	global_load_d16_b16 v3, v[3:4], off                        // 000000851DA8: DC820000 037C0003
	s_waitcnt vmcnt(0)                                         // 000000851DB0: BF8903F7
	v_cvt_f32_f16_e32 v15, v3                                  // 000000851DB4: 7E1E1703
	s_or_b32 exec_lo, exec_lo, s3                              // 000000851DB8: 8C7E037E
	s_branch 9                                                 // 000000851DBC: BFA00009 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi2ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x3e4>
	v_mov_b32_e32 v8, 0                                        // 000000851DC0: 7E100280
	s_delay_alu instid0(VALU_DEP_1)                            // 000000851DC4: BF870001
	v_mov_b32_e32 v9, v8                                       // 000000851DC8: 7E120308
	v_mov_b32_e32 v10, v8                                      // 000000851DCC: 7E140308
	v_mov_b32_e32 v11, v8                                      // 000000851DD0: 7E160308
	v_mov_b32_e32 v12, v8                                      // 000000851DD4: 7E180308
	v_mov_b32_e32 v13, v8                                      // 000000851DD8: 7E1A0308
	v_mov_b32_e32 v14, v8                                      // 000000851DDC: 7E1C0308
	v_mov_b32_e32 v15, v8                                      // 000000851DE0: 7E1E0308
	s_add_u32 s4, s4, s14                                      // 000000851DE4: 80040E04
	s_addc_u32 s5, s5, s15                                     // 000000851DE8: 82050F05
	s_lshr_b32 s3, s11, 31                                     // 000000851DEC: 85039F0B
	v_dual_mov_b32 v20, 0 :: v_dual_mov_b32 v27, 0             // 000000851DF0: CA100080 141A0080
	s_add_u32 s14, s10, s3                                     // 000000851DF8: 800E030A
	s_addc_u32 s15, s11, 0                                     // 000000851DFC: 820F800B
	.long 0xd4410003                                           // 000000851E00: D4410003
	v_cndmask_b32_e32 v1, v31, v32, vcc_lo                     // 000000851E04: 0202411F
	s_ashr_i64 s[14:15], s[14:15], 1                           // 000000851E08: 868E810E
	v_dual_mov_b32 v34, 0 :: v_dual_mov_b32 v21, 0             // 000000851E0C: CA100080 22140080
	v_mad_u64_u32 v[25:26], null, v1, s14, s[4:5]              // 000000851E14: D6FE7C19 00101D01
	.long 0xd72c0001                                           // 000000851E1C: D72C0001
	v_cndmask_b32_e32 v0, v1, v15, vcc_lo                      // 000000851E20: 02001F01
	.long 0xd72c0002                                           // 000000851E24: D72C0002
	v_cndmask_b32_e32 v0, v2, v14, vcc_lo                      // 000000851E28: 02001D02
	v_cndmask_b32_e64 v35, 0, 1, s16                           // 000000851E2C: D5010023 00410280
	v_dual_mov_b32 v22, 0 :: v_dual_mov_b32 v23, 0             // 000000851E34: CA100080 16160080
	s_delay_alu instid0(VALU_DEP_3)                            // 000000851E3C: BF870003
	v_add3_u32 v36, v2, v26, v1                                // 000000851E40: D6550024 04063502
	s_and_saveexec_b32 s4, s3                                  // 000000851E48: BE842003
	s_cbranch_execz 22                                         // 000000851E4C: BFA50016 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi2ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x4a8>
	v_lshlrev_b32_e32 v1, 4, v31                               // 000000851E50: 30023E84
	v_mov_b32_e32 v27, 0                                       // 000000851E54: 7E360280
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000851E58: BF8700A2
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000851E5C: 3404029F
	.long 0xd7006a01                                           // 000000851E60: D7006A01
	v_cndmask_b32_e32 v1, v25, v1, vcc_lo                      // 000000851E64: 02020319
	v_add_co_ci_u32_e64 v2, null, v36, v2, vcc_lo              // 000000851E68: D5207C02 01AA0524
	s_and_not1_b32 vcc_lo, exec_lo, s16                        // 000000851E70: 916A107E
	global_load_b128 v[20:23], v[1:2], off                     // 000000851E74: DC5E0000 147C0001
	s_cbranch_vccnz 10                                         // 000000851E7C: BFA4000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi2ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x4a8>
	v_lshlrev_b32_e32 v1, 1, v31                               // 000000851E80: 30023E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000851E84: BF870091
	.long 0xd7006a01                                           // 000000851E88: D7006A01
	v_cndmask_b32_e32 v1, v24, v1, vcc_lo                      // 000000851E8C: 02020318
	v_add_co_ci_u32_e64 v2, null, 0, v33, vcc_lo               // 000000851E90: D5207C02 01AA4280
	global_load_d16_b16 v1, v[1:2], off                        // 000000851E98: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 000000851EA0: BF8903F7
	v_cvt_f32_f16_e32 v27, v1                                  // 000000851EA4: 7E361701
	s_or_b32 exec_lo, exec_lo, s4                              // 000000851EA8: 8C7E047E
	v_dual_mov_b32 v38, 0 :: v_dual_mov_b32 v39, 0             // 000000851EAC: CA100080 26260080
	v_dual_mov_b32 v40, 0 :: v_dual_mov_b32 v41, 0             // 000000851EB4: CA100080 28280080
	v_mov_b32_e32 v37, 0                                       // 000000851EBC: 7E4A0280
	s_and_saveexec_b32 s14, s3                                 // 000000851EC0: BE8E2003
	s_cbranch_execz 548                                        // 000000851EC4: BFA50224 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi2ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0xd58>
	v_dual_mov_b32 v40, 0 :: v_dual_add_nc_u32 v1, 32, v31     // 000000851EC8: CA200080 28003EA0
	v_dual_mov_b32 v37, 0 :: v_dual_lshlrev_b32 v26, 5, v31    // 000000851ED0: CA220080 251A3E85
	v_dual_mov_b32 v39, 0 :: v_dual_mov_b32 v34, 0             // 000000851ED8: CA100080 27220080
	s_delay_alu instid0(VALU_DEP_3)                            // 000000851EE0: BF870003
	v_dual_mov_b32 v41, 0 :: v_dual_lshlrev_b32 v42, 4, v1     // 000000851EE4: CA220080 292A0284
	v_dual_mov_b32 v38, 0 :: v_dual_lshlrev_b32 v43, 1, v1     // 000000851EEC: CA220080 262A0281
	v_mov_b32_e32 v44, v27                                     // 000000851EF4: 7E58031B
	s_mul_i32 s3, s11, 6                                       // 000000851EF8: 9603860B
	s_mul_hi_u32 s15, s10, 6                                   // 000000851EFC: 968F860A
	s_lshl_b64 s[4:5], s[10:11], 2                             // 000000851F00: 8484820A
	s_add_i32 s15, s15, s3                                     // 000000851F04: 810F030F
	s_mul_i32 s17, s10, 6                                      // 000000851F08: 9611860A
	s_mov_b32 s16, 0                                           // 000000851F0C: BE900080
	s_lshl_b64 s[10:11], s[10:11], 1                           // 000000851F10: 848A810A
	s_branch 492                                               // 000000851F14: BFA001EC <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi2ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0xcc8>
	s_or_b32 exec_lo, exec_lo, s18                             // 000000851F18: 8C7E127E
	v_cndmask_b32_e64 v55, v27, v8, s2                         // 000000851F1C: D5010037 000A111B
	v_cndmask_b32_e64 v2, v9, v10, s2                          // 000000851F24: D5010002 000A1509
	v_cndmask_b32_e64 v1, v8, v9, s2                           // 000000851F2C: D5010001 000A1308
	v_dual_mov_b32 v8, v15 :: v_dual_and_b32 v9, 0xff, v20     // 000000851F34: CA24010F 080828FF 000000FF
	v_cndmask_b32_e64 v7, v14, v15, s2                         // 000000851F40: D5010007 000A1F0E
	v_cndmask_b32_e64 v6, v13, v14, s2                         // 000000851F48: D5010006 000A1D0D
	v_cndmask_b32_e64 v5, v12, v13, s2                         // 000000851F50: D5010005 000A1B0C
	v_cndmask_b32_e64 v4, v11, v12, s2                         // 000000851F58: D5010004 000A190B
	v_lshlrev_b32_e32 v9, 2, v9                                // 000000851F60: 30121282
	v_cndmask_b32_e64 v3, v10, v11, s2                         // 000000851F64: D5010003 000A170A
	v_ashrrev_i32_e32 v27, 31, v26                             // 000000851F6C: 3436349F
	s_and_b32 s3, exec_lo, s3                                  // 000000851F70: 8B03037E
	v_add_nc_u32_e32 v42, 0x200, v42                           // 000000851F74: 4A5454FF 00000200
	ds_load_b32 v15, v9                                        // 000000851F7C: D8D80000 0F000009
	v_lshrrev_b32_e32 v9, 6, v20                               // 000000851F84: 32122886
	s_or_b32 s16, s3, s16                                      // 000000851F88: 8C101003
	v_add_nc_u32_e32 v43, 64, v43                              // 000000851F8C: 4A5656C0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000851F90: BF8700B2
	v_and_b32_e32 v9, 0x3fc, v9                                // 000000851F94: 361212FF 000003FC
	ds_load_b32 v56, v9                                        // 000000851F9C: D8D80000 38000009
	v_lshrrev_b32_e32 v9, 14, v20                              // 000000851FA4: 3212288E
	v_and_b32_e32 v9, 0x3fc, v9                                // 000000851FA8: 361212FF 000003FC
	ds_load_b32 v57, v9                                        // 000000851FB0: D8D80000 39000009
	v_lshrrev_b32_e32 v9, 22, v20                              // 000000851FB8: 32122896
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000851FBC: BF8700B1
	v_and_b32_e32 v9, 0x3fc, v9                                // 000000851FC0: 361212FF 000003FC
	ds_load_b32 v58, v9                                        // 000000851FC8: D8D80000 3A000009
	v_and_b32_e32 v9, 0xff, v21                                // 000000851FD0: 36122AFF 000000FF
	v_lshlrev_b32_e32 v9, 2, v9                                // 000000851FD8: 30121282
	ds_load_b32 v59, v9                                        // 000000851FDC: D8D80000 3B000009
	v_lshrrev_b32_e32 v9, 6, v21                               // 000000851FE4: 32122A86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000851FE8: BF8700B1
	v_and_b32_e32 v9, 0x3fc, v9                                // 000000851FEC: 361212FF 000003FC
	ds_load_b32 v60, v9                                        // 000000851FF4: D8D80000 3C000009
	v_lshrrev_b32_e32 v9, 14, v21                              // 000000851FFC: 32122A8E
	v_and_b32_e32 v9, 0x3fc, v9                                // 000000852000: 361212FF 000003FC
	ds_load_b32 v61, v9                                        // 000000852008: D8D80000 3D000009
	v_lshrrev_b32_e32 v9, 22, v21                              // 000000852010: 32122A96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000852014: BF8700B1
	v_and_b32_e32 v9, 0x3fc, v9                                // 000000852018: 361212FF 000003FC
	ds_load_b32 v62, v9                                        // 000000852020: D8D80000 3E000009
	v_and_b32_e32 v9, 0xff, v22                                // 000000852028: 36122CFF 000000FF
	v_lshlrev_b32_e32 v9, 2, v9                                // 000000852030: 30121282
	ds_load_b32 v63, v9                                        // 000000852034: D8D80000 3F000009
	v_lshrrev_b32_e32 v9, 6, v22                               // 00000085203C: 32122C86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000852040: BF8700B1
	v_and_b32_e32 v9, 0x3fc, v9                                // 000000852044: 361212FF 000003FC
	ds_load_b32 v64, v9                                        // 00000085204C: D8D80000 40000009
	v_lshrrev_b32_e32 v9, 14, v22                              // 000000852054: 32122C8E
	v_and_b32_e32 v9, 0x3fc, v9                                // 000000852058: 361212FF 000003FC
	ds_load_b32 v65, v9                                        // 000000852060: D8D80000 41000009
	v_lshrrev_b32_e32 v9, 22, v22                              // 000000852068: 32122C96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000085206C: BF8700B1
	v_and_b32_e32 v9, 0x3fc, v9                                // 000000852070: 361212FF 000003FC
	ds_load_b32 v66, v9                                        // 000000852078: D8D80000 42000009
	v_and_b32_e32 v9, 0xff, v23                                // 000000852080: 36122EFF 000000FF
	v_lshlrev_b32_e32 v9, 2, v9                                // 000000852088: 30121282
	ds_load_b32 v67, v9                                        // 00000085208C: D8D80000 43000009
	v_lshrrev_b32_e32 v9, 6, v23                               // 000000852094: 32122E86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000852098: BF8700B1
	v_and_b32_e32 v9, 0x3fc, v9                                // 00000085209C: 361212FF 000003FC
	ds_load_b32 v68, v9                                        // 0000008520A4: D8D80000 44000009
	v_lshrrev_b32_e32 v9, 14, v23                              // 0000008520AC: 32122E8E
	v_and_b32_e32 v9, 0x3fc, v9                                // 0000008520B0: 361212FF 000003FC
	ds_load_b32 v69, v9                                        // 0000008520B8: D8D80000 45000009
	v_lshrrev_b32_e32 v9, 22, v23                              // 0000008520C0: 32122E96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000008520C4: BF870141
	v_and_b32_e32 v9, 0x3fc, v9                                // 0000008520C8: 361212FF 000003FC
	ds_load_b32 v70, v9                                        // 0000008520D0: D8D80000 46000009
	.long 0xd73c0009                                           // 0000008520D8: D73C0009
	v_cndmask_b32_e32 v1, 1, v26, vcc_lo                       // 0000008520DC: 02023481
	v_dual_mov_b32 v27, v44 :: v_dual_add_nc_u32 v26, 0x400, v26// 0000008520E0: CA20012C 1B1A34FF 00000400
	.long 0xd7006a0d                                           // 0000008520EC: D7006A0D
	v_cndmask_b32_e32 v1, s6, v9, vcc_lo                       // 0000008520F0: 02021206
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008520F4: BF870001
	v_add_co_ci_u32_e64 v14, null, s7, v10, vcc_lo             // 0000008520F8: D5207C0E 01AA1407
	s_clause 0x3                                               // 000000852100: BF850003
	global_load_b128 v[9:12], v[13:14], off                    // 000000852104: DC5E0000 097C000D
	global_load_b128 v[20:23], v[13:14], off offset:16         // 00000085210C: DC5E0010 147C000D
	global_load_b128 v[45:48], v[13:14], off offset:32         // 000000852114: DC5E0020 2D7C000D
	global_load_b128 v[49:52], v[13:14], off offset:48         // 00000085211C: DC5E0030 317C000D
	s_waitcnt vmcnt(3) lgkmcnt(15)                             // 000000852124: BF890CF7
	v_dot2_f32_bf16 v9, v9, v15, 0                             // 000000852128: CC1A4009 1A021F09
	s_waitcnt lgkmcnt(14)                                      // 000000852130: BF89FCE7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000852134: BF8700A1
	v_dot2_f32_bf16 v9, v10, v56, v9                           // 000000852138: CC1A4009 1C26710A
	s_waitcnt lgkmcnt(13)                                      // 000000852140: BF89FCD7
	v_dot2_f32_bf16 v9, v11, v57, v9                           // 000000852144: CC1A4009 1C26730B
	s_waitcnt lgkmcnt(12)                                      // 00000085214C: BF89FCC7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000852150: BF8700A1
	v_dot2_f32_bf16 v9, v12, v58, v9                           // 000000852154: CC1A4009 1C26750C
	s_waitcnt vmcnt(2) lgkmcnt(11)                             // 00000085215C: BF8908B7
	v_dot2_f32_bf16 v9, v20, v59, v9                           // 000000852160: CC1A4009 1C267714
	s_waitcnt lgkmcnt(10)                                      // 000000852168: BF89FCA7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000085216C: BF8700A1
	v_dot2_f32_bf16 v9, v21, v60, v9                           // 000000852170: CC1A4009 1C267915
	s_waitcnt lgkmcnt(9)                                       // 000000852178: BF89FC97
	v_dot2_f32_bf16 v9, v22, v61, v9                           // 00000085217C: CC1A4009 1C267B16
	s_waitcnt lgkmcnt(8)                                       // 000000852184: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000852188: BF8700A1
	v_dot2_f32_bf16 v9, v23, v62, v9                           // 00000085218C: CC1A4009 1C267D17
	s_waitcnt vmcnt(1) lgkmcnt(7)                              // 000000852194: BF890477
	v_dot2_f32_bf16 v9, v45, v63, v9                           // 000000852198: CC1A4009 1C267F2D
	s_waitcnt lgkmcnt(6)                                       // 0000008521A0: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008521A4: BF8700A1
	v_dot2_f32_bf16 v9, v46, v64, v9                           // 0000008521A8: CC1A4009 1C26812E
	s_waitcnt lgkmcnt(5)                                       // 0000008521B0: BF89FC57
	v_dot2_f32_bf16 v9, v47, v65, v9                           // 0000008521B4: CC1A4009 1C26832F
	s_waitcnt lgkmcnt(4)                                       // 0000008521BC: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008521C0: BF8700A1
	v_dot2_f32_bf16 v9, v48, v66, v9                           // 0000008521C4: CC1A4009 1C268530
	s_waitcnt vmcnt(0) lgkmcnt(3)                              // 0000008521CC: BF890037
	v_dot2_f32_bf16 v9, v49, v67, v9                           // 0000008521D0: CC1A4009 1C268731
	.long 0xd7006a31                                           // 0000008521D8: D7006A31
	v_cndmask_b32_e32 v0, v13, v10, vcc_lo                     // 0000008521DC: 0200150D
	s_waitcnt lgkmcnt(2)                                       // 0000008521E0: BF89FC27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000008521E4: BF8701C2
	v_dot2_f32_bf16 v9, v50, v68, v9                           // 0000008521E8: CC1A4009 1C268932
	v_add_co_ci_u32_e64 v50, null, s11, v14, vcc_lo            // 0000008521F0: D5207C32 01AA1C0B
	.long 0xd7006a35                                           // 0000008521F8: D7006A35
	v_cndmask_b32_e32 v0, v13, v4, vcc_lo                      // 0000008521FC: 0200090D
	s_waitcnt lgkmcnt(1)                                       // 000000852200: BF89FC17
	v_dot2_f32_bf16 v9, v51, v69, v9                           // 000000852204: CC1A4009 1C268B33
	v_add_co_ci_u32_e64 v54, null, s5, v14, vcc_lo             // 00000085220C: D5207C36 01AA1C05
	.long 0xd7006a0d                                           // 000000852214: D7006A0D
	v_cndmask_b32_e32 v0, v13, v17, vcc_lo                     // 000000852218: 0200230D
	s_waitcnt lgkmcnt(0)                                       // 00000085221C: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000852220: BF870123
	v_dot2_f32_bf16 v9, v52, v70, v9                           // 000000852224: CC1A4009 1C268D34
	v_add_co_ci_u32_e64 v14, null, s15, v14, vcc_lo            // 00000085222C: D5207C0E 01AA1C0F
	v_fmac_f32_e32 v37, v55, v9                                // 000000852234: 564A1337
	s_clause 0x3                                               // 000000852238: BF850003
	global_load_b128 v[9:12], v[49:50], off                    // 00000085223C: DC5E0000 097C0031
	global_load_b128 v[20:23], v[49:50], off offset:16         // 000000852244: DC5E0010 147C0031
	global_load_b128 v[45:48], v[49:50], off offset:32         // 00000085224C: DC5E0020 2D7C0031
	global_load_b128 v[49:52], v[49:50], off offset:48         // 000000852254: DC5E0030 317C0031
	s_waitcnt vmcnt(3)                                         // 00000085225C: BF890FF7
	v_dot2_f32_bf16 v9, v9, v15, 0                             // 000000852260: CC1A4009 1A021F09
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000852268: BF870091
	v_dot2_f32_bf16 v9, v10, v56, v9                           // 00000085226C: CC1A4009 1C26710A
	v_dot2_f32_bf16 v9, v11, v57, v9                           // 000000852274: CC1A4009 1C26730B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000085227C: BF8700A1
	v_dot2_f32_bf16 v9, v12, v58, v9                           // 000000852280: CC1A4009 1C26750C
	s_waitcnt vmcnt(2)                                         // 000000852288: BF890BF7
	v_dot2_f32_bf16 v9, v20, v59, v9                           // 00000085228C: CC1A4009 1C267714
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000852294: BF870091
	v_dot2_f32_bf16 v9, v21, v60, v9                           // 000000852298: CC1A4009 1C267915
	v_dot2_f32_bf16 v9, v22, v61, v9                           // 0000008522A0: CC1A4009 1C267B16
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008522A8: BF8700A1
	v_dot2_f32_bf16 v9, v23, v62, v9                           // 0000008522AC: CC1A4009 1C267D17
	s_waitcnt vmcnt(1)                                         // 0000008522B4: BF8907F7
	v_dot2_f32_bf16 v9, v45, v63, v9                           // 0000008522B8: CC1A4009 1C267F2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008522C0: BF870091
	v_dot2_f32_bf16 v9, v46, v64, v9                           // 0000008522C4: CC1A4009 1C26812E
	v_dot2_f32_bf16 v9, v47, v65, v9                           // 0000008522CC: CC1A4009 1C26832F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008522D4: BF8700A1
	v_dot2_f32_bf16 v9, v48, v66, v9                           // 0000008522D8: CC1A4009 1C268530
	s_waitcnt vmcnt(0)                                         // 0000008522E0: BF8903F7
	v_dot2_f32_bf16 v9, v49, v67, v9                           // 0000008522E4: CC1A4009 1C268731
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008522EC: BF870091
	v_dot2_f32_bf16 v9, v50, v68, v9                           // 0000008522F0: CC1A4009 1C268932
	v_dot2_f32_bf16 v9, v51, v69, v9                           // 0000008522F8: CC1A4009 1C268B33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000852300: BF870091
	v_dot2_f32_bf16 v9, v52, v70, v9                           // 000000852304: CC1A4009 1C268D34
	v_fmac_f32_e32 v41, v55, v9                                // 00000085230C: 56521337
	s_clause 0x3                                               // 000000852310: BF850003
	global_load_b128 v[9:12], v[53:54], off                    // 000000852314: DC5E0000 097C0035
	global_load_b128 v[20:23], v[53:54], off offset:16         // 00000085231C: DC5E0010 147C0035
	global_load_b128 v[45:48], v[53:54], off offset:32         // 000000852324: DC5E0020 2D7C0035
	global_load_b128 v[49:52], v[53:54], off offset:48         // 00000085232C: DC5E0030 317C0035
	s_waitcnt vmcnt(3)                                         // 000000852334: BF890FF7
	v_dot2_f32_bf16 v9, v9, v15, 0                             // 000000852338: CC1A4009 1A021F09
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000852340: BF870091
	v_dot2_f32_bf16 v9, v10, v56, v9                           // 000000852344: CC1A4009 1C26710A
	v_dot2_f32_bf16 v9, v11, v57, v9                           // 00000085234C: CC1A4009 1C26730B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000852354: BF8700A1
	v_dot2_f32_bf16 v9, v12, v58, v9                           // 000000852358: CC1A4009 1C26750C
	s_waitcnt vmcnt(2)                                         // 000000852360: BF890BF7
	v_dot2_f32_bf16 v9, v20, v59, v9                           // 000000852364: CC1A4009 1C267714
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000085236C: BF870091
	v_dot2_f32_bf16 v9, v21, v60, v9                           // 000000852370: CC1A4009 1C267915
	v_dot2_f32_bf16 v9, v22, v61, v9                           // 000000852378: CC1A4009 1C267B16
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000852380: BF8700A1
	v_dot2_f32_bf16 v9, v23, v62, v9                           // 000000852384: CC1A4009 1C267D17
	s_waitcnt vmcnt(1)                                         // 00000085238C: BF8907F7
	v_dot2_f32_bf16 v9, v45, v63, v9                           // 000000852390: CC1A4009 1C267F2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000852398: BF870091
	v_dot2_f32_bf16 v9, v46, v64, v9                           // 00000085239C: CC1A4009 1C26812E
	v_dot2_f32_bf16 v9, v47, v65, v9                           // 0000008523A4: CC1A4009 1C26832F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008523AC: BF8700A1
	v_dot2_f32_bf16 v9, v48, v66, v9                           // 0000008523B0: CC1A4009 1C268530
	s_waitcnt vmcnt(0)                                         // 0000008523B8: BF8903F7
	v_dot2_f32_bf16 v9, v49, v67, v9                           // 0000008523BC: CC1A4009 1C268731
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008523C4: BF870091
	v_dot2_f32_bf16 v9, v50, v68, v9                           // 0000008523C8: CC1A4009 1C268932
	v_dot2_f32_bf16 v9, v51, v69, v9                           // 0000008523D0: CC1A4009 1C268B33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008523D8: BF870091
	v_dot2_f32_bf16 v9, v52, v70, v9                           // 0000008523DC: CC1A4009 1C268D34
	v_fmac_f32_e32 v40, v55, v9                                // 0000008523E4: 56501337
	s_clause 0x3                                               // 0000008523E8: BF850003
	global_load_b128 v[9:12], v[13:14], off                    // 0000008523EC: DC5E0000 097C000D
	global_load_b128 v[20:23], v[13:14], off offset:16         // 0000008523F4: DC5E0010 147C000D
	global_load_b128 v[45:48], v[13:14], off offset:32         // 0000008523FC: DC5E0020 2D7C000D
	global_load_b128 v[49:52], v[13:14], off offset:48         // 000000852404: DC5E0030 317C000D
	s_waitcnt vmcnt(3)                                         // 00000085240C: BF890FF7
	v_dot2_f32_bf16 v9, v9, v15, 0                             // 000000852410: CC1A4009 1A021F09
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000852418: BF870091
	v_dot2_f32_bf16 v9, v10, v56, v9                           // 00000085241C: CC1A4009 1C26710A
	v_dot2_f32_bf16 v9, v11, v57, v9                           // 000000852424: CC1A4009 1C26730B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000085242C: BF8700A1
	v_dot2_f32_bf16 v9, v12, v58, v9                           // 000000852430: CC1A4009 1C26750C
	s_waitcnt vmcnt(2)                                         // 000000852438: BF890BF7
	v_dot2_f32_bf16 v9, v20, v59, v9                           // 00000085243C: CC1A4009 1C267714
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000852444: BF870091
	v_dot2_f32_bf16 v9, v21, v60, v9                           // 000000852448: CC1A4009 1C267915
	v_dot2_f32_bf16 v9, v22, v61, v9                           // 000000852450: CC1A4009 1C267B16
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000852458: BF8700A1
	v_dot2_f32_bf16 v9, v23, v62, v9                           // 00000085245C: CC1A4009 1C267D17
	s_waitcnt vmcnt(1)                                         // 000000852464: BF8907F7
	v_dot2_f32_bf16 v9, v45, v63, v9                           // 000000852468: CC1A4009 1C267F2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000852470: BF870091
	v_dot2_f32_bf16 v9, v46, v64, v9                           // 000000852474: CC1A4009 1C26812E
	v_dot2_f32_bf16 v9, v47, v65, v9                           // 00000085247C: CC1A4009 1C26832F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000852484: BF8700A1
	v_dot2_f32_bf16 v9, v48, v66, v9                           // 000000852488: CC1A4009 1C268530
	s_waitcnt vmcnt(0)                                         // 000000852490: BF8903F7
	v_dot2_f32_bf16 v9, v49, v67, v9                           // 000000852494: CC1A4009 1C268731
	.long 0xd7006a31                                           // 00000085249C: D7006A31
	v_cndmask_b32_e32 v0, v53, v4, vcc_lo                      // 0000008524A0: 02000935
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000008524A4: BF8701B2
	v_dot2_f32_bf16 v9, v50, v68, v9                           // 0000008524A8: CC1A4009 1C268932
	v_add_co_ci_u32_e64 v50, null, s5, v54, vcc_lo             // 0000008524B0: D5207C32 01AA6C05
	.long 0xd7006a0d                                           // 0000008524B8: D7006A0D
	v_cndmask_b32_e32 v0, v13, v4, vcc_lo                      // 0000008524BC: 0200090D
	v_dot2_f32_bf16 v9, v51, v69, v9                           // 0000008524C0: CC1A4009 1C268B33
	v_add_co_ci_u32_e64 v14, null, s5, v14, vcc_lo             // 0000008524C8: D5207C0E 01AA1C05
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008524D0: BF870092
	v_dot2_f32_bf16 v9, v52, v70, v9                           // 0000008524D4: CC1A4009 1C268D34
	v_fmac_f32_e32 v39, v55, v9                                // 0000008524DC: 564E1337
	s_clause 0x3                                               // 0000008524E0: BF850003
	global_load_b128 v[9:12], v[49:50], off                    // 0000008524E4: DC5E0000 097C0031
	global_load_b128 v[20:23], v[49:50], off offset:16         // 0000008524EC: DC5E0010 147C0031
	global_load_b128 v[45:48], v[49:50], off offset:32         // 0000008524F4: DC5E0020 2D7C0031
	global_load_b128 v[49:52], v[49:50], off offset:48         // 0000008524FC: DC5E0030 317C0031
	s_waitcnt vmcnt(3)                                         // 000000852504: BF890FF7
	v_dot2_f32_bf16 v9, v9, v15, 0                             // 000000852508: CC1A4009 1A021F09
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000852510: BF870091
	v_dot2_f32_bf16 v9, v10, v56, v9                           // 000000852514: CC1A4009 1C26710A
	v_dot2_f32_bf16 v9, v11, v57, v9                           // 00000085251C: CC1A4009 1C26730B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000852524: BF8700A1
	v_dot2_f32_bf16 v9, v12, v58, v9                           // 000000852528: CC1A4009 1C26750C
	s_waitcnt vmcnt(2)                                         // 000000852530: BF890BF7
	v_dot2_f32_bf16 v9, v20, v59, v9                           // 000000852534: CC1A4009 1C267714
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000085253C: BF870091
	v_dot2_f32_bf16 v9, v21, v60, v9                           // 000000852540: CC1A4009 1C267915
	v_dot2_f32_bf16 v9, v22, v61, v9                           // 000000852548: CC1A4009 1C267B16
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000852550: BF8700A1
	v_dot2_f32_bf16 v9, v23, v62, v9                           // 000000852554: CC1A4009 1C267D17
	s_waitcnt vmcnt(1)                                         // 00000085255C: BF8907F7
	v_dot2_f32_bf16 v9, v45, v63, v9                           // 000000852560: CC1A4009 1C267F2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000852568: BF870091
	v_dot2_f32_bf16 v9, v46, v64, v9                           // 00000085256C: CC1A4009 1C26812E
	v_dot2_f32_bf16 v9, v47, v65, v9                           // 000000852574: CC1A4009 1C26832F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000085257C: BF8700A1
	v_dot2_f32_bf16 v9, v48, v66, v9                           // 000000852580: CC1A4009 1C268530
	s_waitcnt vmcnt(0)                                         // 000000852588: BF8903F7
	v_dot2_f32_bf16 v9, v49, v67, v9                           // 00000085258C: CC1A4009 1C268731
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000852594: BF870091
	v_dot2_f32_bf16 v9, v50, v68, v9                           // 000000852598: CC1A4009 1C268932
	v_dot2_f32_bf16 v9, v51, v69, v9                           // 0000008525A0: CC1A4009 1C268B33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008525A8: BF870091
	v_dot2_f32_bf16 v9, v52, v70, v9                           // 0000008525AC: CC1A4009 1C268D34
	v_fmac_f32_e32 v38, v55, v9                                // 0000008525B4: 564C1337
	s_clause 0x3                                               // 0000008525B8: BF850003
	global_load_b128 v[9:12], v[13:14], off                    // 0000008525BC: DC5E0000 097C000D
	global_load_b128 v[20:23], v[13:14], off offset:16         // 0000008525C4: DC5E0010 147C000D
	global_load_b128 v[45:48], v[13:14], off offset:32         // 0000008525CC: DC5E0020 2D7C000D
	global_load_b128 v[49:52], v[13:14], off offset:48         // 0000008525D4: DC5E0030 317C000D
	s_waitcnt vmcnt(3)                                         // 0000008525DC: BF890FF7
	v_dot2_f32_bf16 v9, v9, v15, 0                             // 0000008525E0: CC1A4009 1A021F09
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008525E8: BF870091
	v_dot2_f32_bf16 v9, v10, v56, v9                           // 0000008525EC: CC1A4009 1C26710A
	v_dot2_f32_bf16 v9, v11, v57, v9                           // 0000008525F4: CC1A4009 1C26730B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008525FC: BF8700A1
	v_dot2_f32_bf16 v9, v12, v58, v9                           // 000000852600: CC1A4009 1C26750C
	s_waitcnt vmcnt(2)                                         // 000000852608: BF890BF7
	v_dot2_f32_bf16 v9, v20, v59, v9                           // 00000085260C: CC1A4009 1C267714
	v_mov_b32_e32 v20, v16                                     // 000000852614: 7E280310
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000852618: BF870122
	v_dot2_f32_bf16 v9, v21, v60, v9                           // 00000085261C: CC1A4009 1C267915
	v_mov_b32_e32 v21, v17                                     // 000000852624: 7E2A0311
	v_dot2_f32_bf16 v9, v22, v61, v9                           // 000000852628: CC1A4009 1C267B16
	v_mov_b32_e32 v22, v18                                     // 000000852630: 7E2C0312
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000852634: BF870132
	v_dot2_f32_bf16 v9, v23, v62, v9                           // 000000852638: CC1A4009 1C267D17
	v_mov_b32_e32 v23, v19                                     // 000000852640: 7E2E0313
	s_waitcnt vmcnt(1)                                         // 000000852644: BF8907F7
	v_dot2_f32_bf16 v9, v45, v63, v9                           // 000000852648: CC1A4009 1C267F2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000852650: BF870091
	v_dot2_f32_bf16 v9, v46, v64, v9                           // 000000852654: CC1A4009 1C26812E
	v_dot2_f32_bf16 v9, v47, v65, v9                           // 00000085265C: CC1A4009 1C26832F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000852664: BF8700A1
	v_dot2_f32_bf16 v9, v48, v66, v9                           // 000000852668: CC1A4009 1C268530
	s_waitcnt vmcnt(0)                                         // 000000852670: BF8903F7
	v_dot2_f32_bf16 v9, v49, v67, v9                           // 000000852674: CC1A4009 1C268731
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000085267C: BF870091
	v_dot2_f32_bf16 v9, v50, v68, v9                           // 000000852680: CC1A4009 1C268932
	v_dot2_f32_bf16 v9, v51, v69, v9                           // 000000852688: CC1A4009 1C268B33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000852690: BF870091
	v_dot2_f32_bf16 v9, v52, v70, v9                           // 000000852694: CC1A4009 1C268D34
	v_dual_fmac_f32 v34, v55, v9 :: v_dual_mov_b32 v15, v8     // 00000085269C: C8101337 220E0108
	v_dual_mov_b32 v14, v7 :: v_dual_mov_b32 v13, v6           // 0000008526A4: CA100107 0E0C0106
	v_dual_mov_b32 v12, v5 :: v_dual_mov_b32 v11, v4           // 0000008526AC: CA100105 0C0A0104
	v_dual_mov_b32 v10, v3 :: v_dual_mov_b32 v9, v2            // 0000008526B4: CA100103 0A080102
	v_mov_b32_e32 v8, v1                                       // 0000008526BC: 7E100301
	s_and_not1_b32 exec_lo, exec_lo, s16                       // 0000008526C0: 917E107E
	s_cbranch_execz 35                                         // 0000008526C4: BFA50023 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi2ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0xd54>
	s_waitcnt vmcnt(0)                                         // 0000008526C8: BF8903F7
	v_dual_mov_b32 v16, v20 :: v_dual_add_nc_u32 v31, 32, v31  // 0000008526CC: CA200114 101E3EA0
	v_dual_mov_b32 v17, v21 :: v_dual_mov_b32 v18, v22         // 0000008526D4: CA100115 11120116
	v_mov_b32_e32 v19, v23                                     // 0000008526DC: 7E260317
	s_delay_alu instid0(VALU_DEP_3)                            // 0000008526E0: BF870003
	.long 0xd4460003                                           // 0000008526E4: D4460003
	v_cndmask_b32_e32 v1, v31, v32, vcc_lo                     // 0000008526E8: 0202411F
	s_mov_b32 s18, exec_lo                                     // 0000008526EC: BE92007E
	.long 0xd4c1007e                                           // 0000008526F0: D4C1007E
	v_cndmask_b32_e32 v1, v31, v32, vcc_lo                     // 0000008526F4: 0202411F
	s_cbranch_execz 65031                                      // 0000008526F8: BFA5FE07 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi2ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x518>
	v_ashrrev_i32_e32 v2, 31, v42                              // 0000008526FC: 3404549F
	.long 0xd7006a01                                           // 000000852700: D7006A01
	v_cndmask_b32_e32 v1, v25, v42, vcc_lo                     // 000000852704: 02025519
	v_mov_b32_e32 v44, v27                                     // 000000852708: 7E58031B
	s_delay_alu instid0(VALU_DEP_3)                            // 00000085270C: BF870003
	v_add_co_ci_u32_e64 v2, null, v36, v2, vcc_lo              // 000000852710: D5207C02 01AA0524
	v_cmp_ne_u32_e32 vcc_lo, 1, v35                            // 000000852718: 7C9A4681
	global_load_b128 v[16:19], v[1:2], off                     // 00000085271C: DC5E0000 107C0001
	s_cbranch_vccnz 65020                                      // 000000852724: BFA4FDFC <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi2ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x518>
	v_ashrrev_i32_e32 v2, 31, v43                              // 000000852728: 3404569F
	.long 0xd7006a01                                           // 00000085272C: D7006A01
	v_cndmask_b32_e32 v1, v24, v43, vcc_lo                     // 000000852730: 02025718
	s_delay_alu instid0(VALU_DEP_1)                            // 000000852734: BF870001
	v_add_co_ci_u32_e64 v2, null, v33, v2, vcc_lo              // 000000852738: D5207C02 01AA0521
	global_load_d16_b16 v1, v[1:2], off                        // 000000852740: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 000000852748: BF8903F7
	v_cvt_f32_f16_e32 v44, v1                                  // 00000085274C: 7E581701
	s_branch 65009                                             // 000000852750: BFA0FDF1 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi2ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x518>
	s_or_b32 exec_lo, exec_lo, s16                             // 000000852754: 8C7E107E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000852758: BF8700B9
	s_or_b32 exec_lo, exec_lo, s14                             // 00000085275C: 8C7E0E7E
	.long 0xd71f0001                                           // 000000852760: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 000000852764: 020100C1
	s_mov_b32 s2, exec_lo                                      // 000000852768: BE82007E
	v_xor_b32_e32 v2, 16, v1                                   // 00000085276C: 3A040290
	v_xor_b32_e32 v8, 8, v1                                    // 000000852770: 3A100288
	v_xor_b32_e32 v14, 4, v1                                   // 000000852774: 3A1C0284
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000852778: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 00000085277C: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 000000852780: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v8                            // 000000852784: 7C9810A0
	s_delay_alu instid0(VALU_DEP_2)                            // 000000852788: BF870002
	v_lshlrev_b32_e32 v2, 2, v2                                // 00000085278C: 30040482
	ds_bpermute_b32 v3, v2, v37                                // 000000852790: DACC0000 03002502
	s_waitcnt lgkmcnt(0)                                       // 000000852798: BF89FC07
	v_add_f32_e32 v3, v37, v3                                  // 00000085279C: 06060725
	ds_bpermute_b32 v7, v2, v38                                // 0000008527A0: DACC0000 07002602
	v_cndmask_b32_e32 v8, v1, v8, vcc_lo                       // 0000008527A8: 02101101
	ds_bpermute_b32 v5, v2, v40                                // 0000008527AC: DACC0000 05002802
	ds_bpermute_b32 v6, v2, v39                                // 0000008527B4: DACC0000 06002702
	ds_bpermute_b32 v4, v2, v41                                // 0000008527BC: DACC0000 04002902
	ds_bpermute_b32 v2, v2, v34                                // 0000008527C4: DACC0000 02002202
	v_cmp_gt_u32_e32 vcc_lo, 32, v14                           // 0000008527CC: 7C981CA0
	s_waitcnt lgkmcnt(4)                                       // 0000008527D0: BF89FC47
	v_dual_add_f32 v7, v38, v7 :: v_dual_lshlrev_b32 v8, 2, v8 // 0000008527D4: C9220F26 07081082
	s_waitcnt lgkmcnt(3)                                       // 0000008527DC: BF89FC37
	v_add_f32_e32 v5, v40, v5                                  // 0000008527E0: 060A0B28
	ds_bpermute_b32 v9, v8, v3                                 // 0000008527E4: DACC0000 09000308
	s_waitcnt lgkmcnt(0)                                       // 0000008527EC: BF89FC07
	v_add_f32_e32 v3, v3, v9                                   // 0000008527F0: 06061303
	ds_bpermute_b32 v11, v8, v5                                // 0000008527F4: DACC0000 0B000508
	ds_bpermute_b32 v13, v8, v7                                // 0000008527FC: DACC0000 0D000708
	v_add_f32_e32 v6, v39, v6                                  // 000000852804: 060C0D27
	v_add_f32_e32 v4, v41, v4                                  // 000000852808: 06080929
	s_waitcnt lgkmcnt(1)                                       // 00000085280C: BF89FC17
	v_dual_add_f32 v2, v34, v2 :: v_dual_add_f32 v5, v5, v11   // 000000852810: C9080522 02041705
	ds_bpermute_b32 v12, v8, v6                                // 000000852818: DACC0000 0C000608
	s_waitcnt lgkmcnt(1)                                       // 000000852820: BF89FC17
	v_dual_add_f32 v7, v7, v13 :: v_dual_cndmask_b32 v14, v1, v14// 000000852824: C9121B07 070E1D01
	ds_bpermute_b32 v10, v8, v4                                // 00000085282C: DACC0000 0A000408
	ds_bpermute_b32 v8, v8, v2                                 // 000000852834: DACC0000 08000208
	v_lshlrev_b32_e32 v14, 2, v14                              // 00000085283C: 301C1C82
	s_waitcnt lgkmcnt(2)                                       // 000000852840: BF89FC27
	v_add_f32_e32 v6, v6, v12                                  // 000000852844: 060C1906
	ds_bpermute_b32 v12, v14, v7                               // 000000852848: DACC0000 0C00070E
	s_waitcnt lgkmcnt(1)                                       // 000000852850: BF89FC17
	v_add_f32_e32 v2, v2, v8                                   // 000000852854: 06041102
	ds_bpermute_b32 v8, v14, v3                                // 000000852858: DACC0000 0800030E
	ds_bpermute_b32 v13, v14, v2                               // 000000852860: DACC0000 0D00020E
	s_waitcnt lgkmcnt(2)                                       // 000000852868: BF89FC27
	v_dual_add_f32 v7, v7, v12 :: v_dual_add_f32 v4, v4, v10   // 00000085286C: C9081907 07041504
	ds_bpermute_b32 v10, v14, v5                               // 000000852874: DACC0000 0A00050E
	s_waitcnt lgkmcnt(2)                                       // 00000085287C: BF89FC27
	v_add_f32_e32 v3, v3, v8                                   // 000000852880: 06061103
	ds_bpermute_b32 v9, v14, v4                                // 000000852884: DACC0000 0900040E
	s_waitcnt lgkmcnt(1)                                       // 00000085288C: BF89FC17
	v_dual_add_f32 v8, v2, v13 :: v_dual_add_f32 v5, v5, v10   // 000000852890: C9081B02 08041505
	ds_bpermute_b32 v11, v14, v6                               // 000000852898: DACC0000 0B00060E
	v_xor_b32_e32 v14, 2, v1                                   // 0000008528A0: 3A1C0282
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008528A4: BF8700A1
	v_cmp_gt_u32_e32 vcc_lo, 32, v14                           // 0000008528A8: 7C981CA0
	v_cndmask_b32_e32 v14, v1, v14, vcc_lo                     // 0000008528AC: 021C1D01
	v_lshlrev_b32_e32 v14, 2, v14                              // 0000008528B0: 301C1C82
	s_waitcnt lgkmcnt(0)                                       // 0000008528B4: BF89FC07
	v_add_f32_e32 v6, v6, v11                                  // 0000008528B8: 060C1706
	ds_bpermute_b32 v2, v14, v3                                // 0000008528BC: DACC0000 0200030E
	v_add_f32_e32 v4, v4, v9                                   // 0000008528C4: 06081304
	ds_bpermute_b32 v10, v14, v5                               // 0000008528C8: DACC0000 0A00050E
	ds_bpermute_b32 v12, v14, v7                               // 0000008528D0: DACC0000 0C00070E
	ds_bpermute_b32 v11, v14, v6                               // 0000008528D8: DACC0000 0B00060E
	ds_bpermute_b32 v13, v14, v8                               // 0000008528E0: DACC0000 0D00080E
	ds_bpermute_b32 v9, v14, v4                                // 0000008528E8: DACC0000 0900040E
	v_xor_b32_e32 v14, 1, v1                                   // 0000008528F0: 3A1C0281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008528F4: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v14                           // 0000008528F8: 7C981CA0
	v_cndmask_b32_e32 v1, v1, v14, vcc_lo                      // 0000008528FC: 02021D01
	s_waitcnt lgkmcnt(5)                                       // 000000852900: BF89FC57
	v_dual_add_f32 v1, v3, v2 :: v_dual_lshlrev_b32 v14, 2, v1 // 000000852904: C9220503 010E0282
	s_waitcnt lgkmcnt(0)                                       // 00000085290C: BF89FC07
	v_dual_add_f32 v3, v7, v12 :: v_dual_add_f32 v2, v4, v9    // 000000852910: C9081907 03021304
	v_dual_add_f32 v4, v5, v10 :: v_dual_add_f32 v5, v6, v11   // 000000852918: C9081505 04041706
	v_add_f32_e32 v9, v8, v13                                  // 000000852920: 06121B08
	ds_bpermute_b32 v6, v14, v1                                // 000000852924: DACC0000 0600010E
	ds_bpermute_b32 v7, v14, v2                                // 00000085292C: DACC0000 0700020E
	ds_bpermute_b32 v10, v14, v4                               // 000000852934: DACC0000 0A00040E
	ds_bpermute_b32 v11, v14, v5                               // 00000085293C: DACC0000 0B00050E
	ds_bpermute_b32 v8, v14, v3                                // 000000852944: DACC0000 0800030E
	ds_bpermute_b32 v12, v14, v9                               // 00000085294C: DACC0000 0C00090E
	v_cmpx_eq_u32_e32 0, v30                                   // 000000852954: 7D943C80
	s_cbranch_execz 16                                         // 000000852958: BFA50010 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi2ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0xf9c>
	.long 0xd72c000d                                           // 00000085295C: D72C000D
	v_cndmask_b32_e32 v0, v28, v176, vcc_lo                    // 000000852960: 0201611C
	s_waitcnt lgkmcnt(0)                                       // 000000852964: BF89FC07
	v_dual_add_f32 v9, v9, v12 :: v_dual_add_f32 v4, v4, v10   // 000000852968: C9081909 09041504
	v_dual_add_f32 v5, v5, v11 :: v_dual_add_f32 v8, v3, v8    // 000000852970: C9081705 05081103
	v_dual_add_f32 v2, v2, v7 :: v_dual_add_f32 v1, v1, v6     // 000000852978: C9080F02 02000D01
	s_delay_alu instid0(VALU_DEP_4)                            // 000000852980: BF870004
	v_mad_u32_u24 v6, v29, 24, v13                             // 000000852984: D60B0006 0435311D
	ds_store_2addr_b64 v6, v[1:2], v[4:5] offset0:128 offset1:129// 00000085298C: D9388180 00040106
	ds_store_b64 v6, v[8:9] offset:1040                        // 000000852994: D9340410 00000806
	s_or_b32 exec_lo, exec_lo, s2                              // 00000085299C: 8C7E027E
	.long 0xd7050001                                           // 0000008529A0: D7050001
	v_cndmask_b32_e32 v1, 0xab, v0, vcc_lo                     // 0000008529A4: 020200FF 000000AB
	.long 0x7f063880                                           // 0000008529AC: 7F063880
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000008529B0: BF890007
	s_barrier                                                  // 0000008529B4: BFBD0000
	buffer_gl0_inv                                             // 0000008529B8: E0AC0000 00000000
	.long 0xd7390003                                           // 0000008529C0: D7390003
	v_cndmask_b32_e32 v1, 10, v1, vcc_lo                       // 0000008529C4: 0202028A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008529C8: BF870091
	.long 0xd7000201                                           // 0000008529CC: D7000201
	v_cndmask_b32_e32 v1, s20, v3, vcc_lo                      // 0000008529D0: 02020614
	v_add_co_ci_u32_e64 v2, null, s21, 0, s2                   // 0000008529D4: D5207C02 00090015
	.long 0xd44c0002                                           // 0000008529DC: D44C0002
	v_cndmask_b32_e32 v1, 24, v0, vcc_lo                       // 0000008529E0: 02020098
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000008529E4: BF8704A2
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[1:2]                  // 0000008529E8: 7CA8020C
	s_and_b32 s2, s2, vcc_lo                                   // 0000008529EC: 8B026A02
	s_and_saveexec_b32 s3, s2                                  // 0000008529F0: BE832002
	s_cbranch_execz 81                                         // 0000008529F4: BFA50051 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi2ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x113c>
	.long 0xd7054000                                           // 0000008529F8: D7054000
	v_cndmask_b32_e32 v0, v3, v134, vcc_lo                     // 0000008529FC: 02010D03
	v_mul_u32_u24_e32 v3, 48, v3                               // 000000852A00: 160606B0
	s_load_b32 s0, s[0:1], 0x48                                // 000000852A04: F4000000 F8000048
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000852A0C: BF870092
	.long 0xd7041000                                           // 000000852A10: D7041000
	v_cndmask_b32_e32 v1, v0, v0, vcc_lo                       // 000000852A14: 02020100
	v_and_b32_e32 v0, 0xff, v0                                 // 000000852A18: 360000FF 000000FF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000852A20: BF870091
	v_lshl_add_u32 v3, v0, 2, v3                               // 000000852A24: D6460003 040D0500
	v_add_nc_u32_e32 v3, 0x400, v3                             // 000000852A2C: 4A0606FF 00000400
	ds_load_2addr_b32 v[3:4], v3 offset1:6                     // 000000852A34: D8DC0600 03000003
	s_waitcnt lgkmcnt(0)                                       // 000000852A3C: BF89FC07
	v_add_f32_e32 v3, 0, v3                                    // 000000852A40: 06060680
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000852A44: BF870091
	v_add_f32_e32 v3, v3, v4                                   // 000000852A48: 06060903
	v_bfe_u32 v4, v3, 16, 1                                    // 000000852A4C: D6100004 02052103
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000852A54: BF870091
	v_add3_u32 v3, v3, v4, 0x7fff                              // 000000852A58: D6550003 03FE0903 00007FFF
	v_and_b32_e32 v3, 0xffff0000, v3                           // 000000852A64: 360606FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000852A6C: BF870091
	v_mul_f32_e32 v3, s0, v3                                   // 000000852A70: 10060600
	v_mul_f32_e32 v3, 0xbfb8aa3b, v3                           // 000000852A74: 100606FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000852A7C: BF870291
	v_exp_f32_e32 v3, v3                                       // 000000852A80: 7E064B03
	v_add_f32_e32 v6, 1.0, v3                                  // 000000852A84: 060C06F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000852A88: BF870121
	v_div_scale_f32 v7, null, v6, v6, 1.0                      // 000000852A8C: D6FC7C07 03CA0D06
	v_div_scale_f32 v9, vcc_lo, 1.0, v6, 1.0                   // 000000852A94: D6FC6A09 03CA0CF2
	v_rcp_f32_e32 v8, v7                                       // 000000852A9C: 7E105507
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000852AA0: BF870095
	v_fma_f32 v3, -v7, v8, 1.0                                 // 000000852AA4: D6130003 23CA1107
	v_fmac_f32_e32 v8, v3, v8                                  // 000000852AAC: 56101103
	v_mad_u64_u32 v[3:4], null, s12, v0, 0                     // 000000852AB0: D6FE7C03 0202000C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000852AB8: BF870092
	v_mul_f32_e32 v10, v9, v8                                  // 000000852ABC: 10141109
	v_fma_f32 v5, -v7, v10, v9                                 // 000000852AC0: D6130005 24261507
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000852AC8: BF870211
	v_fmac_f32_e32 v10, v5, v8                                 // 000000852ACC: 56141105
	v_mad_u64_u32 v[4:5], null, s13, v0, v[4:5]                // 000000852AD0: D6FE7C04 0412000D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000852AD8: BF870112
	v_fma_f32 v0, -v7, v10, v9                                 // 000000852ADC: D6130000 24261507
	.long 0xd73c0003                                           // 000000852AE4: D73C0003
	v_cndmask_b32_e32 v1, 2, v3, vcc_lo                        // 000000852AE8: 02020682
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000852AEC: BF8701A2
	v_div_fmas_f32 v5, v0, v8, v10                             // 000000852AF0: D6370005 042A1100
	.long 0xd73c0000                                           // 000000852AF8: D73C0000
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 000000852AFC: 02020282
	.long 0xd7006a03                                           // 000000852B00: D7006A03
	v_cndmask_b32_e32 v1, s8, v3, vcc_lo                       // 000000852B04: 02020608
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000852B08: BF8701A3
	v_div_fixup_f32 v2, v5, v6, 1.0                            // 000000852B0C: D6270002 03CA0D05
	v_add_co_ci_u32_e64 v4, null, s9, v4, vcc_lo               // 000000852B14: D5207C04 01AA0809
	.long 0xd7006a00                                           // 000000852B1C: D7006A00
	v_cndmask_b32_e32 v1, v3, v0, vcc_lo                       // 000000852B20: 02020103
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000852B24: BF870193
	v_add_f32_e32 v2, v2, v2                                   // 000000852B28: 06040502
	v_add_co_ci_u32_e64 v1, null, v4, v1, vcc_lo               // 000000852B2C: D5207C01 01AA0304
	global_store_b32 v[0:1], v2, off                           // 000000852B34: DC6A0000 007C0200
	s_endpgm                                                   // 000000852B3C: BFB00000
		...

