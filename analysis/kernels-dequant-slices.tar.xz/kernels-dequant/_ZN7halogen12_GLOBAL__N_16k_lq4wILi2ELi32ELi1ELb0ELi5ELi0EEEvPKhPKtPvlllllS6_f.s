00000000008bae00 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 0000008BAE00: F4100100 F8000000
	s_ashr_i32 s3, s2, 31                                      // 0000008BAE08: 86039F02
	v_lshrrev_b32_e32 v2, 2, v0                                // 0000008BAE0C: 32040082
	s_lshl_b64 s[2:3], s[2:3], 3                               // 0000008BAE10: 84828302
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008BAE14: BF8701A9
	v_dual_mov_b32 v10, s3 :: v_dual_and_b32 v1, 15, v0        // 0000008BAE18: CA240003 0A00008F
	.long 0x7f103880                                           // 0000008BAE20: 7F103880
	v_and_b32_e32 v2, 60, v2                                   // 0000008BAE24: 360404BC
	s_delay_alu instid0(VALU_DEP_3)                            // 0000008BAE28: BF870003
	v_dual_mov_b32 v18, 0 :: v_dual_lshlrev_b32 v1, 2, v1      // 0000008BAE2C: CA220080 12000282
	v_dual_mov_b32 v3, 0 :: v_dual_and_b32 v16, 31, v0         // 0000008BAE34: CA240080 0310009F
	v_mov_b32_e32 v17, 0                                       // 0000008BAE3C: 7E220280
	s_waitcnt lgkmcnt(0)                                       // 0000008BAE40: BF89FC07
	s_clause 0x1                                               // 0000008BAE44: BF850001
	global_load_b32 v4, v1, s[4:5]                             // 0000008BAE48: DC520000 04040001
	global_load_b32 v7, v2, s[4:5]                             // 0000008BAE50: DC520000 07040002
	v_lshrrev_b32_e32 v2, 5, v0                                // 0000008BAE58: 32040085
	s_add_u32 s14, s4, s14                                     // 0000008BAE5C: 800E0E04
	s_addc_u32 s15, s5, s15                                    // 0000008BAE60: 820F0F05
	v_mov_b32_e32 v1, 0                                        // 0000008BAE64: 7E020280
	s_delay_alu instid0(VALU_DEP_2)                            // 0000008BAE68: BF870002
	v_or_b32_e32 v9, s2, v2                                    // 0000008BAE6C: 38120402
	s_lshr_b32 s2, s11, 31                                     // 0000008BAE70: 85029F0B
	v_mov_b32_e32 v2, 0                                        // 0000008BAE74: 7E040280
	s_add_u32 s20, s10, s2                                     // 0000008BAE78: 8014020A
	s_addc_u32 s21, s11, 0                                     // 0000008BAE7C: 8215800B
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[9:10]                 // 0000008BAE80: 7CA8120C
	s_ashr_i32 s22, s11, 31                                    // 0000008BAE84: 86169F0B
	v_cndmask_b32_e32 v11, 0, v9, vcc_lo                       // 0000008BAE88: 02161280
	v_cndmask_b32_e64 v14, 0, s3, vcc_lo                       // 0000008BAE8C: D501000E 01A80680
	s_ashr_i64 s[2:3], s[20:21], 1                             // 0000008BAE94: 86828114
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 0000008BAE98: BF870481
	.long 0xd72c0014                                           // 0000008BAE9C: D72C0014
	v_cndmask_b32_e32 v0, v14, v2, vcc_lo                      // 0000008BAEA0: 0200050E
	.long 0xd72c000e                                           // 0000008BAEA4: D72C000E
	v_cndmask_b32_e32 v1, s18, v14, vcc_lo                     // 0000008BAEA8: 02021C12
	s_waitcnt vmcnt(1)                                         // 0000008BAEAC: BF8907F7
	v_bfe_u32 v12, v4, 16, 1                                   // 0000008BAEB0: D610000C 02052104
	s_waitcnt vmcnt(0)                                         // 0000008BAEB8: BF8903F7
	v_bfe_u32 v19, v7, 16, 1                                   // 0000008BAEBC: D6100013 02052107
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000008BAEC4: BF870112
	v_add3_u32 v4, v4, v12, 0x7fff                             // 0000008BAEC8: D6550004 03FE1904 00007FFF
	v_add3_u32 v7, v7, v19, 0x7fff                             // 0000008BAED4: D6550007 03FE2707 00007FFF
	v_lshlrev_b32_e32 v19, 2, v0                               // 0000008BAEE0: 30260082
	s_delay_alu instid0(VALU_DEP_3)                            // 0000008BAEE4: BF870003
	.long 0x7e103984                                           // 0000008BAEE8: 7E103984
	v_mov_b32_e32 v4, 0                                        // 0000008BAEEC: 7E080280
	.long 0xd72c000d                                           // 0000008BAEF0: D72C000D
	v_cndmask_b32_e32 v1, s19, v11, vcc_lo                     // 0000008BAEF4: 02021613
	v_mad_u64_u32 v[5:6], null, s18, v11, 0                    // 0000008BAEF8: D6FE7C05 02021612
	.long 0xd72c000f                                           // 0000008BAF00: D72C000F
	v_cndmask_b32_e32 v0, v11, v3, vcc_lo                      // 0000008BAF04: 0200070B
	v_mad_u64_u32 v[11:12], null, v11, s2, s[14:15]            // 0000008BAF08: D6FE7C0B 0038050B
	s_lshr_b32 s19, s22, 27                                    // 0000008BAF10: 85139B16
	v_and_or_b32 v7, 0xffff0000, v7, v8                        // 0000008BAF14: D6570007 04220EFF FFFF0000
	s_add_u32 s14, s10, s19                                    // 0000008BAF20: 800E130A
	s_addc_u32 s15, s11, 0                                     // 0000008BAF24: 820F800B
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000008BAF28: BF870009
	s_lshr_b64 s[14:15], s[14:15], 5                           // 0000008BAF2C: 858E850E
	v_add3_u32 v6, v6, v14, v13                                // 0000008BAF30: D6550006 04361D06
	.long 0xd4440002                                           // 0000008BAF38: D4440002
	v_cndmask_b32_e32 v1, s14, v16, vcc_lo                     // 0000008BAF3C: 0202200E
	v_add3_u32 v0, v20, v12, v15                               // 0000008BAF40: D6550000 043E1914
	ds_store_b32 v19, v7                                       // 0000008BAF48: D8340000 00000713
	s_waitcnt lgkmcnt(0)                                       // 0000008BAF50: BF89FC07
	s_barrier                                                  // 0000008BAF54: BFBD0000
	buffer_gl0_inv                                             // 0000008BAF58: E0AC0000 00000000
	s_and_saveexec_b32 s15, s2                                 // 0000008BAF60: BE8F2002
	s_cbranch_execz 26                                         // 0000008BAF64: BFA5001A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f+0x1d0>
	s_add_u32 s3, s4, s16                                      // 0000008BAF68: 80031004
	s_addc_u32 s18, s5, s17                                    // 0000008BAF6C: 82121105
	v_lshlrev_b32_e32 v1, 1, v16                               // 0000008BAF70: 30022081
	.long 0xd7000302                                           // 0000008BAF74: D7000302
	v_cndmask_b32_e32 v1, s3, v5, vcc_lo                       // 0000008BAF78: 02020A03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008BAF7C: BF8701A1
	v_add_co_ci_u32_e64 v3, null, s18, v6, s3                  // 0000008BAF80: D5207C03 000E0C12
	v_lshlrev_b32_e32 v4, 4, v16                               // 0000008BAF88: 30082084
	.long 0xd7000301                                           // 0000008BAF8C: D7000301
	v_cndmask_b32_e32 v1, v2, v1, vcc_lo                       // 0000008BAF90: 02020302
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008BAF94: BF870191
	v_add_co_ci_u32_e64 v2, null, 0, v3, s3                    // 0000008BAF98: D5207C02 000E0680
	.long 0xd7000303                                           // 0000008BAFA0: D7000303
	v_cndmask_b32_e32 v1, v11, v4, vcc_lo                      // 0000008BAFA4: 0202090B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008BAFA8: BF870001
	v_add_co_ci_u32_e64 v4, null, 0, v0, s3                    // 0000008BAFAC: D5207C04 000E0080
	s_clause 0x1                                               // 0000008BAFB4: BF850001
	global_load_d16_b16 v7, v[1:2], off                        // 0000008BAFB8: DC820000 077C0001
	global_load_b128 v[1:4], v[3:4], off                       // 0000008BAFC0: DC5E0000 017C0003
	s_waitcnt vmcnt(1)                                         // 0000008BAFC8: BF8907F7
	v_cvt_f32_f16_e32 v18, v7                                  // 0000008BAFCC: 7E241707
	s_or_b32 exec_lo, exec_lo, s15                             // 0000008BAFD0: 8C7E0F7E
	v_mov_b32_e32 v19, 0                                       // 0000008BAFD4: 7E260280
	s_and_saveexec_b32 s15, s2                                 // 0000008BAFD8: BE8F2002
	s_cbranch_execz 281                                        // 0000008BAFDC: BFA50119 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f+0x644>
	v_dual_mov_b32 v22, v18 :: v_dual_lshlrev_b32 v7, 1, v16   // 0000008BAFE0: CA220112 16062081
	.long 0xd7000205                                           // 0000008BAFE8: D7000205
	v_cndmask_b32_e32 v1, s16, v5, vcc_lo                      // 0000008BAFEC: 02020A10
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008BAFF0: BF8701A1
	v_add_co_ci_u32_e64 v6, null, s17, v6, s2                  // 0000008BAFF4: D5207C06 000A0C11
	v_dual_mov_b32 v13, 0 :: v_dual_lshlrev_b32 v12, 5, v16    // 0000008BAFFC: CA220080 0D0C2085
	.long 0xd7000205                                           // 0000008BB004: D7000205
	v_cndmask_b32_e32 v1, v5, v7, vcc_lo                       // 0000008BB008: 02020F05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008BB00C: BF8701A1
	v_add_co_ci_u32_e64 v6, null, 0, v6, s2                    // 0000008BB010: D5207C06 000A0C80
	v_lshl_or_b32 v20, v16, 4, 0x200                           // 0000008BB018: D6560014 03FD0910 00000200
	.long 0xd7000205                                           // 0000008BB024: D7000205
	v_cndmask_b32_e32 v1, s4, v5, vcc_lo                       // 0000008BB028: 02020A04
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008BB02C: BF8701A1
	v_add_co_ci_u32_e64 v6, null, s5, v6, s2                   // 0000008BB030: D5207C06 000A0C05
	v_mov_b32_e32 v21, v16                                     // 0000008BB038: 7E2A0310
	.long 0xd700020e                                           // 0000008BB03C: D700020E
	v_cndmask_b32_e32 v0, v5, v192, vcc_lo                     // 0000008BB040: 02018105
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008BB044: BF870001
	v_add_co_ci_u32_e64 v15, null, 0, v6, s2                   // 0000008BB048: D5207C0F 000A0C80
	v_mov_b32_e32 v19, v13                                     // 0000008BB050: 7E26030D
	v_mov_b32_e32 v17, v13                                     // 0000008BB054: 7E22030D
	s_mov_b32 s16, 0                                           // 0000008BB058: BE900080
	s_lshl_b64 s[4:5], s[10:11], 1                             // 0000008BB05C: 8484810A
	s_branch 222                                               // 0000008BB060: BFA000DE <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f+0x5dc>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000008BB064: 8C7E0A7E
	.long 0xd73c0017                                           // 0000008BB068: D73C0017
	v_cndmask_b32_e32 v1, 1, v12, vcc_lo                       // 0000008BB06C: 02021881
	v_and_b32_e32 v55, 0xff, v1                                // 0000008BB070: 366E02FF 000000FF
	v_lshrrev_b32_e32 v56, 6, v1                               // 0000008BB078: 32700286
	v_lshrrev_b32_e32 v57, 14, v1                              // 0000008BB07C: 3272028E
	v_lshrrev_b32_e32 v1, 22, v1                               // 0000008BB080: 32020296
	v_and_b32_e32 v58, 0xff, v2                                // 0000008BB084: 367404FF 000000FF
	.long 0xd700032f                                           // 0000008BB08C: D700032F
	v_cndmask_b32_e32 v1, s6, v23, vcc_lo                      // 0000008BB090: 02022E06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008BB094: BF8701A1
	v_add_co_ci_u32_e64 v48, null, s7, v24, s3                 // 0000008BB098: D5207C30 000E3007
	v_lshlrev_b32_e32 v55, 2, v55                              // 0000008BB0A0: 306E6E82
	.long 0xd7000333                                           // 0000008BB0A4: D7000333
	v_cndmask_b32_e32 v0, v47, v4, vcc_lo                      // 0000008BB0A8: 0200092F
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008BB0AC: BF870001
	v_add_co_ci_u32_e64 v52, null, s5, v48, s3                 // 0000008BB0B0: D5207C34 000E6005
	v_and_b32_e32 v56, 0x3fc, v56                              // 0000008BB0B8: 367070FF 000003FC
	ds_load_b32 v55, v55                                       // 0000008BB0C0: D8D80000 37000037
	s_clause 0x7                                               // 0000008BB0C8: BF850007
	global_load_b128 v[23:26], v[47:48], off                   // 0000008BB0CC: DC5E0000 177C002F
	global_load_b128 v[27:30], v[51:52], off                   // 0000008BB0D4: DC5E0000 1B7C0033
	global_load_b128 v[31:34], v[47:48], off offset:16         // 0000008BB0DC: DC5E0010 1F7C002F
	global_load_b128 v[35:38], v[51:52], off offset:16         // 0000008BB0E4: DC5E0010 237C0033
	global_load_b128 v[39:42], v[47:48], off offset:32         // 0000008BB0EC: DC5E0020 277C002F
	global_load_b128 v[43:46], v[51:52], off offset:32         // 0000008BB0F4: DC5E0020 2B7C0033
	global_load_b128 v[47:50], v[47:48], off offset:48         // 0000008BB0FC: DC5E0030 2F7C002F
	global_load_b128 v[51:54], v[51:52], off offset:48         // 0000008BB104: DC5E0030 337C0033
	v_and_b32_e32 v57, 0x3fc, v57                              // 0000008BB10C: 367272FF 000003FC
	v_lshrrev_b32_e32 v59, 6, v2                               // 0000008BB114: 32760486
	ds_load_b32 v56, v56                                       // 0000008BB118: D8D80000 38000038
	v_lshrrev_b32_e32 v60, 14, v2                              // 0000008BB120: 3278048E
	v_lshrrev_b32_e32 v2, 22, v2                               // 0000008BB124: 32040496
	ds_load_b32 v57, v57                                       // 0000008BB128: D8D80000 39000039
	v_and_b32_e32 v1, 0x3fc, v1                                // 0000008BB130: 360202FF 000003FC
	v_lshlrev_b32_e32 v58, 2, v58                              // 0000008BB138: 30747482
	v_and_b32_e32 v59, 0x3fc, v59                              // 0000008BB13C: 367676FF 000003FC
	v_and_b32_e32 v60, 0x3fc, v60                              // 0000008BB144: 367878FF 000003FC
	v_and_b32_e32 v2, 0x3fc, v2                                // 0000008BB14C: 360404FF 000003FC
	ds_load_b32 v1, v1                                         // 0000008BB154: D8D80000 01000001
	ds_load_b32 v58, v58                                       // 0000008BB15C: D8D80000 3A00003A
	ds_load_b32 v59, v59                                       // 0000008BB164: D8D80000 3B00003B
	ds_load_b32 v60, v60                                       // 0000008BB16C: D8D80000 3C00003C
	ds_load_b32 v2, v2                                         // 0000008BB174: D8D80000 02000002
	s_and_b32 s3, exec_lo, s2                                  // 0000008BB17C: 8B03027E
	.long 0xd700020e                                           // 0000008BB180: D700020E
	v_cndmask_b32_e32 v0, v14, v192, vcc_lo                    // 0000008BB184: 0201810E
	v_add_nc_u32_e32 v12, 0x400, v12                           // 0000008BB188: 4A1818FF 00000400
	v_add_nc_u32_e32 v20, 0x200, v20                           // 0000008BB190: 4A2828FF 00000200
	v_add_co_ci_u32_e64 v15, null, 0, v15, s2                  // 0000008BB198: D5207C0F 000A1E80
	s_or_b32 s16, s3, s16                                      // 0000008BB1A0: 8C101003
	s_waitcnt vmcnt(7) lgkmcnt(7)                              // 0000008BB1A4: BF891C77
	v_dot2_f32_bf16 v23, v23, v55, 0                           // 0000008BB1A8: CC1A4017 1A026F17
	s_waitcnt vmcnt(6)                                         // 0000008BB1B0: BF891BF7
	v_dot2_f32_bf16 v27, v27, v55, 0                           // 0000008BB1B4: CC1A401B 1A026F1B
	v_and_b32_e32 v55, 0xff, v3                                // 0000008BB1BC: 366E06FF 000000FF
	s_waitcnt lgkmcnt(6)                                       // 0000008BB1C4: BF89FC67
	v_dot2_f32_bf16 v23, v24, v56, v23                         // 0000008BB1C8: CC1A4017 1C5E7118
	s_delay_alu instid0(VALU_DEP_3)                            // 0000008BB1D0: BF870003
	v_dot2_f32_bf16 v24, v28, v56, v27                         // 0000008BB1D4: CC1A4018 1C6E711C
	v_lshrrev_b32_e32 v27, 6, v3                               // 0000008BB1DC: 32360686
	v_lshrrev_b32_e32 v28, 14, v3                              // 0000008BB1E0: 3238068E
	v_lshrrev_b32_e32 v3, 22, v3                               // 0000008BB1E4: 32060696
	s_waitcnt lgkmcnt(5)                                       // 0000008BB1E8: BF89FC57
	v_dot2_f32_bf16 v23, v25, v57, v23                         // 0000008BB1EC: CC1A4017 1C5E7319
	v_dot2_f32_bf16 v24, v29, v57, v24                         // 0000008BB1F4: CC1A4018 1C62731D
	v_and_b32_e32 v25, 0xff, v4                                // 0000008BB1FC: 363208FF 000000FF
	v_lshrrev_b32_e32 v29, 6, v4                               // 0000008BB204: 323A0886
	v_lshrrev_b32_e32 v56, 14, v4                              // 0000008BB208: 3270088E
	s_waitcnt lgkmcnt(4)                                       // 0000008BB20C: BF89FC47
	v_dot2_f32_bf16 v23, v26, v1, v23                          // 0000008BB210: CC1A4017 1C5E031A
	v_dot2_f32_bf16 v1, v30, v1, v24                           // 0000008BB218: CC1A4001 1C62031E
	v_lshlrev_b32_e32 v24, 2, v55                              // 0000008BB220: 30306E82
	v_and_b32_e32 v26, 0x3fc, v27                              // 0000008BB224: 363436FF 000003FC
	v_and_b32_e32 v27, 0x3fc, v28                              // 0000008BB22C: 363638FF 000003FC
	s_waitcnt vmcnt(5) lgkmcnt(3)                              // 0000008BB234: BF891437
	v_dot2_f32_bf16 v23, v31, v58, v23                         // 0000008BB238: CC1A4017 1C5E751F
	s_waitcnt vmcnt(4)                                         // 0000008BB240: BF8913F7
	v_dot2_f32_bf16 v1, v35, v58, v1                           // 0000008BB244: CC1A4001 1C067523
	ds_load_b32 v24, v24                                       // 0000008BB24C: D8D80000 18000018
	ds_load_b32 v26, v26                                       // 0000008BB254: D8D80000 1A00001A
	ds_load_b32 v27, v27                                       // 0000008BB25C: D8D80000 1B00001B
	s_waitcnt lgkmcnt(5)                                       // 0000008BB264: BF89FC57
	v_dot2_f32_bf16 v23, v32, v59, v23                         // 0000008BB268: CC1A4017 1C5E7720
	v_dot2_f32_bf16 v1, v36, v59, v1                           // 0000008BB270: CC1A4001 1C067724
	v_lshrrev_b32_e32 v4, 22, v4                               // 0000008BB278: 32080896
	v_and_b32_e32 v3, 0x3fc, v3                                // 0000008BB27C: 360606FF 000003FC
	v_lshlrev_b32_e32 v25, 2, v25                              // 0000008BB284: 30323282
	s_waitcnt lgkmcnt(4)                                       // 0000008BB288: BF89FC47
	v_dot2_f32_bf16 v23, v33, v60, v23                         // 0000008BB28C: CC1A4017 1C5E7921
	v_dot2_f32_bf16 v1, v37, v60, v1                           // 0000008BB294: CC1A4001 1C067925
	v_and_b32_e32 v28, 0x3fc, v29                              // 0000008BB29C: 36383AFF 000003FC
	v_and_b32_e32 v29, 0x3fc, v56                              // 0000008BB2A4: 363A70FF 000003FC
	v_and_b32_e32 v4, 0x3fc, v4                                // 0000008BB2AC: 360808FF 000003FC
	s_waitcnt lgkmcnt(3)                                       // 0000008BB2B4: BF89FC37
	v_dot2_f32_bf16 v23, v34, v2, v23                          // 0000008BB2B8: CC1A4017 1C5E0522
	v_dot2_f32_bf16 v1, v38, v2, v1                            // 0000008BB2C0: CC1A4001 1C060526
	ds_load_b32 v2, v3                                         // 0000008BB2C8: D8D80000 02000003
	ds_load_b32 v3, v25                                        // 0000008BB2D0: D8D80000 03000019
	ds_load_b32 v25, v28                                       // 0000008BB2D8: D8D80000 1900001C
	ds_load_b32 v28, v29                                       // 0000008BB2E0: D8D80000 1C00001D
	ds_load_b32 v29, v4                                        // 0000008BB2E8: D8D80000 1D000004
	s_waitcnt vmcnt(3) lgkmcnt(7)                              // 0000008BB2F0: BF890C77
	v_dot2_f32_bf16 v4, v39, v24, v23                          // 0000008BB2F4: CC1A4004 1C5E3127
	s_waitcnt vmcnt(2)                                         // 0000008BB2FC: BF890BF7
	v_dot2_f32_bf16 v1, v43, v24, v1                           // 0000008BB300: CC1A4001 1C06312B
	s_waitcnt lgkmcnt(6)                                       // 0000008BB308: BF89FC67
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000008BB30C: BF870112
	v_dot2_f32_bf16 v4, v40, v26, v4                           // 0000008BB310: CC1A4004 1C123528
	v_dot2_f32_bf16 v1, v44, v26, v1                           // 0000008BB318: CC1A4001 1C06352C
	s_waitcnt lgkmcnt(5)                                       // 0000008BB320: BF89FC57
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000008BB324: BF870112
	v_dot2_f32_bf16 v4, v41, v27, v4                           // 0000008BB328: CC1A4004 1C123729
	v_dot2_f32_bf16 v1, v45, v27, v1                           // 0000008BB330: CC1A4001 1C06372D
	s_waitcnt lgkmcnt(4)                                       // 0000008BB338: BF89FC47
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000008BB33C: BF870112
	v_dot2_f32_bf16 v4, v42, v2, v4                            // 0000008BB340: CC1A4004 1C12052A
	v_dot2_f32_bf16 v1, v46, v2, v1                            // 0000008BB348: CC1A4001 1C06052E
	s_waitcnt vmcnt(1) lgkmcnt(3)                              // 0000008BB350: BF890437
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000008BB354: BF870122
	v_dot2_f32_bf16 v2, v47, v3, v4                            // 0000008BB358: CC1A4002 1C12072F
	s_waitcnt vmcnt(0)                                         // 0000008BB360: BF8903F7
	v_dot2_f32_bf16 v1, v51, v3, v1                            // 0000008BB364: CC1A4001 1C060733
	v_dual_mov_b32 v4, v8 :: v_dual_mov_b32 v3, v7             // 0000008BB36C: CA100108 04020107
	s_waitcnt lgkmcnt(2)                                       // 0000008BB374: BF89FC27
	v_dot2_f32_bf16 v2, v48, v25, v2                           // 0000008BB378: CC1A4002 1C0A3330
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000008BB380: BF870123
	v_dot2_f32_bf16 v1, v52, v25, v1                           // 0000008BB384: CC1A4001 1C063334
	s_waitcnt lgkmcnt(1)                                       // 0000008BB38C: BF89FC17
	v_dot2_f32_bf16 v2, v49, v28, v2                           // 0000008BB390: CC1A4002 1C0A3931
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000008BB398: BF870122
	v_dot2_f32_bf16 v1, v53, v28, v1                           // 0000008BB39C: CC1A4001 1C063935
	s_waitcnt lgkmcnt(0)                                       // 0000008BB3A4: BF89FC07
	v_dot2_f32_bf16 v8, v50, v29, v2                           // 0000008BB3A8: CC1A4008 1C0A3B32
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008BB3B0: BF8701A2
	v_dot2_f32_bf16 v23, v54, v29, v1                          // 0000008BB3B4: CC1A4017 1C063B36
	v_dual_mov_b32 v2, v6 :: v_dual_mov_b32 v1, v5             // 0000008BB3BC: CA100106 02000105
	v_fmac_f32_e32 v19, v18, v8                                // 0000008BB3C4: 56261112
	s_delay_alu instid0(VALU_DEP_3)                            // 0000008BB3C8: BF870003
	v_fmac_f32_e32 v17, v18, v23                               // 0000008BB3CC: 56222F12
	v_mov_b32_e32 v18, v22                                     // 0000008BB3D0: 7E240316
	s_and_not1_b32 exec_lo, exec_lo, s16                       // 0000008BB3D4: 917E107E
	s_cbranch_execz 25                                         // 0000008BB3D8: BFA50019 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f+0x640>
	s_waitcnt vmcnt(0)                                         // 0000008BB3DC: BF8903F7
	v_dual_mov_b32 v6, v2 :: v_dual_add_nc_u32 v21, 32, v21    // 0000008BB3E0: CA200102 06142AA0
	v_dual_mov_b32 v5, v1 :: v_dual_mov_b32 v8, v4             // 0000008BB3E8: CA100101 05080104
	v_mov_b32_e32 v7, v3                                       // 0000008BB3F0: 7E0E0303
	s_delay_alu instid0(VALU_DEP_3)                            // 0000008BB3F4: BF870003
	.long 0xd4430002                                           // 0000008BB3F8: D4430002
	v_cndmask_b32_e32 v1, s14, v21, vcc_lo                     // 0000008BB3FC: 02022A0E
	s_mov_b32 s10, exec_lo                                     // 0000008BB400: BE8A007E
	.long 0xd4c4007e                                           // 0000008BB404: D4C4007E
	v_cndmask_b32_e32 v1, s14, v21, vcc_lo                     // 0000008BB408: 02022A0E
	s_cbranch_execz 65301                                      // 0000008BB40C: BFA5FF15 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f+0x264>
	.long 0xd7000305                                           // 0000008BB410: D7000305
	v_cndmask_b32_e32 v1, v11, v20, vcc_lo                     // 0000008BB414: 0202290B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008BB418: BF870001
	v_add_co_ci_u32_e64 v6, null, 0, v0, s3                    // 0000008BB41C: D5207C06 000E0080
	global_load_d16_b16 v22, v[14:15], off                     // 0000008BB424: DC820000 167C000E
	global_load_b128 v[5:8], v[5:6], off                       // 0000008BB42C: DC5E0000 057C0005
	s_waitcnt vmcnt(1)                                         // 0000008BB434: BF8907F7
	v_cvt_f32_f16_e32 v22, v22                                 // 0000008BB438: 7E2C1716
	s_branch 65289                                             // 0000008BB43C: BFA0FF09 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f+0x264>
	s_or_b32 exec_lo, exec_lo, s16                             // 0000008BB440: 8C7E107E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008BB444: BF8700B9
	s_or_b32 exec_lo, exec_lo, s15                             // 0000008BB448: 8C7E0F7E
	.long 0xd71f0000                                           // 0000008BB44C: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000008BB450: 020100C1
	s_waitcnt vmcnt(0)                                         // 0000008BB454: BF8903F7
	v_xor_b32_e32 v1, 16, v0                                   // 0000008BB458: 3A020090
	v_xor_b32_e32 v3, 8, v0                                    // 0000008BB45C: 3A060088
	v_xor_b32_e32 v5, 4, v0                                    // 0000008BB460: 3A0A0084
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008BB464: BF870093
	.long 0xd44c0002                                           // 0000008BB468: D44C0002
	v_cndmask_b32_e32 v1, 32, v1, vcc_lo                       // 0000008BB46C: 020202A0
	v_cndmask_b32_e64 v1, v0, v1, s2                           // 0000008BB470: D5010001 000A0300
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000008BB478: BF870114
	.long 0xd44c0002                                           // 0000008BB47C: D44C0002
	v_cndmask_b32_e32 v1, 32, v3, vcc_lo                       // 0000008BB480: 020206A0
	v_lshlrev_b32_e32 v1, 2, v1                                // 0000008BB484: 30020282
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000008BB488: BF8700D2
	v_cndmask_b32_e64 v3, v0, v3, s2                           // 0000008BB48C: D5010003 000A0700
	.long 0xd44c0002                                           // 0000008BB494: D44C0002
	v_cndmask_b32_e32 v1, 32, v5, vcc_lo                       // 0000008BB498: 02020AA0
	ds_bpermute_b32 v2, v1, v19                                // 0000008BB49C: DACC0000 02001301
	v_cndmask_b32_e64 v5, v0, v5, s2                           // 0000008BB4A4: D5010005 000A0B00
	s_waitcnt lgkmcnt(0)                                       // 0000008BB4AC: BF89FC07
	v_dual_add_f32 v2, v19, v2 :: v_dual_lshlrev_b32 v5, 2, v5 // 0000008BB4B0: C9220513 02040A82
	v_lshlrev_b32_e32 v3, 2, v3                                // 0000008BB4B8: 30060682
	ds_bpermute_b32 v1, v1, v17                                // 0000008BB4BC: DACC0000 01001101
	ds_bpermute_b32 v4, v3, v2                                 // 0000008BB4C4: DACC0000 04000203
	s_waitcnt lgkmcnt(0)                                       // 0000008BB4CC: BF89FC07
	v_dual_add_f32 v2, v2, v4 :: v_dual_add_f32 v1, v17, v1    // 0000008BB4D0: C9080902 02000311
	ds_bpermute_b32 v3, v3, v1                                 // 0000008BB4D8: DACC0000 03000103
	s_waitcnt lgkmcnt(0)                                       // 0000008BB4E0: BF89FC07
	v_add_f32_e32 v1, v1, v3                                   // 0000008BB4E4: 06020701
	ds_bpermute_b32 v3, v5, v2                                 // 0000008BB4E8: DACC0000 03000205
	ds_bpermute_b32 v4, v5, v1                                 // 0000008BB4F0: DACC0000 04000105
	v_xor_b32_e32 v5, 2, v0                                    // 0000008BB4F8: 3A0A0082
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008BB4FC: BF870091
	.long 0xd44c0002                                           // 0000008BB500: D44C0002
	v_cndmask_b32_e32 v1, 32, v5, vcc_lo                       // 0000008BB504: 02020AA0
	v_cndmask_b32_e64 v5, v0, v5, s2                           // 0000008BB508: D5010005 000A0B00
	s_waitcnt lgkmcnt(0)                                       // 0000008BB510: BF89FC07
	v_dual_add_f32 v2, v2, v3 :: v_dual_add_f32 v1, v1, v4     // 0000008BB514: C9080702 02000901
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000008BB51C: BF8700C2
	v_lshlrev_b32_e32 v5, 2, v5                                // 0000008BB520: 300A0A82
	ds_bpermute_b32 v3, v5, v2                                 // 0000008BB524: DACC0000 03000205
	ds_bpermute_b32 v4, v5, v1                                 // 0000008BB52C: DACC0000 04000105
	v_xor_b32_e32 v5, 1, v0                                    // 0000008BB534: 3A0A0081
	.long 0xd44c0002                                           // 0000008BB538: D44C0002
	v_cndmask_b32_e32 v1, 32, v5, vcc_lo                       // 0000008BB53C: 02020AA0
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000008BB540: BF870121
	v_cndmask_b32_e64 v0, v0, v5, s2                           // 0000008BB544: D5010000 000A0B00
	.long 0xd44a0002                                           // 0000008BB54C: D44A0002
	v_cndmask_b32_e32 v1, 0, v16, vcc_lo                       // 0000008BB550: 02022080
	v_lshlrev_b32_e32 v5, 2, v0                                // 0000008BB554: 300A0082
	s_and_b32 s2, s2, vcc_lo                                   // 0000008BB558: 8B026A02
	s_waitcnt lgkmcnt(1)                                       // 0000008BB55C: BF89FC17
	v_add_f32_e32 v2, v2, v3                                   // 0000008BB560: 06040702
	s_waitcnt lgkmcnt(0)                                       // 0000008BB564: BF89FC07
	v_add_f32_e32 v0, v1, v4                                   // 0000008BB568: 06000901
	ds_bpermute_b32 v3, v5, v2                                 // 0000008BB56C: DACC0000 03000205
	ds_bpermute_b32 v1, v5, v0                                 // 0000008BB574: DACC0000 01000005
	s_and_saveexec_b32 s3, s2                                  // 0000008BB57C: BE832002
	s_cbranch_execz 74                                         // 0000008BB580: BFA5004A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f+0x8ac>
	v_ashrrev_i32_e32 v4, 31, v10                              // 0000008BB584: 3408149F
	s_load_b64 s[2:3], s[0:1], 0x40                            // 0000008BB588: F4040080 F8000040
	s_waitcnt lgkmcnt(0)                                       // 0000008BB590: BF89FC07
	v_add_f32_e32 v8, v2, v3                                   // 0000008BB594: 06100702
	v_mov_b32_e32 v6, s9                                       // 0000008BB598: 7E0C0209
	s_lshr_b32 s0, s13, 31                                     // 0000008BB59C: 85009F0D
	v_lshrrev_b32_e32 v4, 23, v4                               // 0000008BB5A0: 32080897
	s_add_u32 s1, s12, s0                                      // 0000008BB5A4: 8001000C
	s_addc_u32 s4, s13, 0                                      // 0000008BB5A8: 8204800D
	v_mov_b32_e32 v7, s8                                       // 0000008BB5AC: 7E0E0208
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008BB5B0: BF870092
	.long 0xd7006a04                                           // 0000008BB5B4: D7006A04
	v_cndmask_b32_e32 v1, v9, v4, vcc_lo                       // 0000008BB5B8: 02020909
	v_add_co_ci_u32_e64 v5, null, 0, v10, vcc_lo               // 0000008BB5BC: D5207C05 01AA1480
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008BB5C4: BF870092
	v_and_b32_e32 v4, 0xfffffe00, v4                           // 0000008BB5C8: 360808FF FFFFFE00
	.long 0xd7016a02                                           // 0000008BB5D0: D7016A02
	v_cndmask_b32_e32 v1, v9, v4, vcc_lo                       // 0000008BB5D4: 02020909
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008BB5D8: BF8701A1
	v_sub_co_ci_u32_e64 v3, null, v10, v5, vcc_lo              // 0000008BB5DC: D5217C03 01AA0B0A
	v_add_f32_e32 v9, v0, v1                                   // 0000008BB5E4: 06120300
	.long 0xd7000000                                           // 0000008BB5E8: D7000000
	v_cndmask_b32_e32 v1, 0xffffff00, v2, vcc_lo               // 0000008BB5EC: 020204FF FFFFFF00
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_3)// 0000008BB5F4: BF8701D3
	v_cmp_gt_i64_e32 vcc_lo, 0x100, v[2:3]                     // 0000008BB5F8: 7CA804FF 00000100
	.long 0x7f143880                                           // 0000008BB600: 7F143880
	v_add_co_ci_u32_e64 v1, null, -1, v3, s0                   // 0000008BB604: D5207C01 000206C1
	.long 0x7e143989                                           // 0000008BB60C: 7E143989
	s_and_b32 s0, s1, -2                                       // 0000008BB610: 8B00C201
	.long 0x7f16398a                                           // 0000008BB614: 7F16398A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008BB618: BF870193
	v_dual_cndmask_b32 v6, s3, v6 :: v_dual_cndmask_b32 v1, v1, v3// 0000008BB61C: CA520C03 06000701
	v_and_b32_e32 v3, 1, v10                                   // 0000008BB624: 36061481
	.long 0x7e163988                                           // 0000008BB628: 7E163988
	v_cndmask_b32_e32 v0, v0, v2, vcc_lo                       // 0000008BB62C: 02000500
	v_cndmask_b32_e32 v2, s2, v7, vcc_lo                       // 0000008BB630: 02040E02
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008BB634: BF870193
	v_and_b32_e32 v7, 1, v11                                   // 0000008BB638: 360E1681
	.long 0xd73c0000                                           // 0000008BB63C: D73C0000
	v_cndmask_b32_e32 v1, 1, v0, vcc_lo                        // 0000008BB640: 02020081
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008BB644: BF870093
	.long 0xd7006a02                                           // 0000008BB648: D7006A02
	v_cndmask_b32_e32 v1, v2, v4, vcc_lo                       // 0000008BB64C: 02020902
	v_add_co_ci_u32_e64 v4, null, v6, v5, vcc_lo               // 0000008BB650: D5207C04 01AA0B06
	v_add3_u32 v5, v9, v3, 0x7fff                              // 0000008BB658: D6550005 03FE0709 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008BB664: BF870093
	.long 0xd7006a00                                           // 0000008BB668: D7006A00
	v_cndmask_b32_e32 v1, v2, v0, vcc_lo                       // 0000008BB66C: 02020102
	v_add_co_ci_u32_e64 v1, null, v4, v1, vcc_lo               // 0000008BB670: D5207C01 01AA0304
	v_add3_u32 v4, v8, v7, 0x7fff                              // 0000008BB678: D6550004 03FE0F08 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008BB684: BF870093
	.long 0xd7006a02                                           // 0000008BB688: D7006A02
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 0000008BB68C: 02000100
	v_add_co_ci_u32_e64 v3, null, s4, v1, vcc_lo               // 0000008BB690: D5207C03 01AA0204
	s_clause 0x1                                               // 0000008BB698: BF850001
	global_store_d16_hi_b16 v[0:1], v4, off                    // 0000008BB69C: DC960000 007C0400
	global_store_d16_hi_b16 v[2:3], v5, off                    // 0000008BB6A4: DC960000 007C0502
	s_endpgm                                                   // 0000008BB6AC: BFB00000
		...

