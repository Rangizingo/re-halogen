0000000000a65300 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_tILi4ELi8ELi0ELb0EEEvPKjPKDF16_PKiS5_PtNS0_6HtFoldE>:
; _ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_tILi4ELi8ELi0ELb0EEEvPKjPKDF16_PKiS5_PtNS0_6HtFoldE():
	s_load_b256 s[4:11], s[0:1], null                          // 000000A65300: F40C0100 F8000000
	s_mul_hi_i32 s3, s2, 0x66666667                            // 000000A65308: 9703FF02 66666667
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000A65310: BF8704A9
	s_lshr_b32 s12, s3, 31                                     // 000000A65314: 850C9F03
	s_ashr_i32 s3, s3, 3                                       // 000000A65318: 86038303
	s_add_i32 s12, s3, s12                                     // 000000A6531C: 810C0C03
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000A65320: BF870499
	s_ashr_i32 s13, s12, 31                                    // 000000A65324: 860D9F0C
	s_lshl_b64 s[14:15], s[12:13], 2                           // 000000A65328: 848E820C
	s_waitcnt lgkmcnt(0)                                       // 000000A6532C: BF89FC07
	s_add_u32 s14, s8, s14                                     // 000000A65330: 800E0E08
	s_addc_u32 s15, s9, s15                                    // 000000A65334: 820F0F09
	s_load_b64 s[8:9], s[0:1], 0x20                            // 000000A65338: F4040200 F8000020
	s_load_b32 s3, s[14:15], null                              // 000000A65340: F40000C7 F8000000
	s_mov_b32 s0, exec_lo                                      // 000000A65348: BE80007E
	v_cmpx_gt_u32_e32 0x50, v0                                 // 000000A6534C: 7D9800FF 00000050
	s_cbranch_execz 12                                         // 000000A65354: BFA5000C <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_tILi4ELi8ELi0ELb0EEEvPKjPKDF16_PKiS5_PtNS0_6HtFoldE+0x88>
	s_mul_i32 s1, s12, 0x500                                   // 000000A65358: 9601FF0C 00000500
	v_lshlrev_b32_e32 v5, 4, v0                                // 000000A65360: 300A0084
	s_mul_hi_i32 s13, s12, 0x500                               // 000000A65364: 970DFF0C 00000500
	s_add_u32 s6, s6, s1                                       // 000000A6536C: 80060106
	s_addc_u32 s7, s7, s13                                     // 000000A65370: 82070D07
	global_load_b128 v[1:4], v5, s[6:7]                        // 000000A65374: DC5E0000 01060005
	s_waitcnt vmcnt(0)                                         // 000000A6537C: BF8903F7
	ds_store_b128 v5, v[1:4]                                   // 000000A65380: DB7C0000 00000105
	s_or_b32 exec_lo, exec_lo, s0                              // 000000A65388: 8C7E007E
	v_lshrrev_b32_e32 v7, 5, v0                                // 000000A6538C: 320E0085
	v_dual_mov_b32 v11, 0 :: v_dual_and_b32 v8, 31, v0         // 000000A65390: CA240080 0B08009F
	s_mul_i32 s6, s12, 0xffffffec                              // 000000A65398: 9606FF0C FFFFFFEC
	v_dual_mov_b32 v12, 0 :: v_dual_mov_b32 v13, 0             // 000000A653A0: CA100080 0C0C0080
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000A653A8: BF8701B3
	v_mul_u32_u24_e32 v1, 5, v7                                // 000000A653AC: 16020E85
	v_dual_mov_b32 v14, 0 :: v_dual_mov_b32 v17, 0             // 000000A653B0: CA100080 0E100080
	v_dual_mov_b32 v16, 0 :: v_dual_mov_b32 v19, 0             // 000000A653B8: CA100080 10120080
	v_min_u32_e32 v2, 35, v1                                   // 000000A653C0: 260402A3
	v_dual_mov_b32 v18, 0 :: v_dual_lshlrev_b32 v9, 2, v8      // 000000A653C4: CA220080 12081082
	v_mov_b32_e32 v20, 0                                       // 000000A653CC: 7E280280
	s_add_i32 s6, s6, s2                                       // 000000A653D0: 81060206
	s_delay_alu instid0(VALU_DEP_3)                            // 000000A653D4: BF870003
	v_add_nc_u32_e32 v10, 5, v2                                // 000000A653D8: 4A140485
	s_waitcnt lgkmcnt(0)                                       // 000000A653DC: BF89FC07
	s_mul_hi_i32 s7, s3, 0xc8000                               // 000000A653E0: 9707FF03 000C8000
	s_mul_i32 s13, s3, 0xc8000                                 // 000000A653E8: 960DFF03 000C8000
	s_mul_hi_i32 s2, s6, 0xa000                                // 000000A653F0: 9702FF06 0000A000
	s_mul_i32 s14, s6, 0xa000                                  // 000000A653F8: 960EFF06 0000A000
	v_cmp_lt_u32_e32 vcc_lo, v1, v10                           // 000000A65400: 7C921501
	s_barrier                                                  // 000000A65404: BFBD0000
	buffer_gl0_inv                                             // 000000A65408: E0AC0000 00000000
	s_and_saveexec_b32 s1, vcc_lo                              // 000000A65410: BE81206A
	s_cbranch_execz 33                                         // 000000A65414: BFA50021 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_tILi4ELi8ELi0ELb0EEEvPKjPKDF16_PKiS5_PtNS0_6HtFoldE+0x19c>
	v_mul_u32_u24_e32 v3, 0x1400, v7                           // 000000A65418: 16060EFF 00001400
	s_add_u32 s0, s4, s13                                      // 000000A65420: 80000D04
	s_addc_u32 s15, s5, s7                                     // 000000A65424: 820F0705
	s_add_u32 s0, s0, s14                                      // 000000A65428: 80000E00
	s_addc_u32 s15, s15, s2                                    // 000000A6542C: 820F020F
	.long 0xd7000003                                           // 000000A65430: D7000003
	v_cndmask_b32_e32 v1, s0, v3, vcc_lo                       // 000000A65434: 02020600
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A65438: BF870111
	v_add_co_ci_u32_e64 v4, null, s15, 0, s0                   // 000000A6543C: D5207C04 0001000F
	.long 0xd7000003                                           // 000000A65444: D7000003
	v_cndmask_b32_e32 v1, v3, v9, vcc_lo                       // 000000A65448: 02021303
	s_delay_alu instid0(VALU_DEP_1)                            // 000000A6544C: BF870001
	v_add_co_ci_u32_e64 v4, null, 0, v4, s0                    // 000000A65450: D5207C04 00020880
	s_clause 0x7                                               // 000000A65458: BF850007
	global_load_b32 v12, v[3:4], off                           // 000000A6545C: DC520000 0C7C0003
	global_load_b32 v13, v[3:4], off offset:128                // 000000A65464: DC520080 0D7C0003
	global_load_b32 v14, v[3:4], off offset:256                // 000000A6546C: DC520100 0E7C0003
	global_load_b32 v16, v[3:4], off offset:384                // 000000A65474: DC520180 107C0003
	global_load_b32 v17, v[3:4], off offset:512                // 000000A6547C: DC520200 117C0003
	global_load_b32 v18, v[3:4], off offset:640                // 000000A65484: DC520280 127C0003
	global_load_b32 v19, v[3:4], off offset:768                // 000000A6548C: DC520300 137C0003
	global_load_b32 v20, v[3:4], off offset:896                // 000000A65494: DC520380 147C0003
	s_or_b32 exec_lo, exec_lo, s1                              // 000000A6549C: 8C7E017E
	v_dual_mov_b32 v21, 0 :: v_dual_mov_b32 v22, 0             // 000000A654A0: CA100080 15160080
	v_dual_mov_b32 v23, 0 :: v_dual_mov_b32 v24, 0             // 000000A654A8: CA100080 17180080
	v_dual_mov_b32 v25, 0 :: v_dual_mov_b32 v26, 0             // 000000A654B0: CA100080 191A0080
	v_mov_b32_e32 v15, 0                                       // 000000A654B8: 7E1E0280
	s_and_saveexec_b32 s1, vcc_lo                              // 000000A654BC: BE81206A
	s_cbranch_execz 985                                        // 000000A654C0: BFA503D9 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_tILi4ELi8ELi0ELb0EEEvPKjPKDF16_PKiS5_PtNS0_6HtFoldE+0x1128>
	v_cmp_ne_u32_e32 vcc_lo, 0, v8                             // 000000A654C4: 7C9A1080
	v_lshlrev_b32_e32 v3, 5, v8                                // 000000A654C8: 30061085
	v_dual_mov_b32 v26, 0 :: v_dual_and_b32 v21, 16, v0        // 000000A654CC: CA240080 1A140090
	v_dual_mov_b32 v25, 0 :: v_dual_lshlrev_b32 v22, 10, v1    // 000000A654D4: CA220080 1916028A
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000A654DC: BF870143
	v_dual_mov_b32 v15, 0 :: v_dual_add_nc_u32 v4, 0x3f0, v3   // 000000A654E0: CA200080 0F0406FF 000003F0
	s_add_u32 s0, s13, s14                                     // 000000A654EC: 80000E0D
	s_addc_u32 s2, s7, s2                                      // 000000A654F0: 82020207
	v_lshl_or_b32 v27, v1, 5, v21                              // 000000A654F4: D656001B 04550B01
	v_lshrrev_b32_e32 v6, 5, v4                                // 000000A654FC: 320C0885
	.long 0xd7000015                                           // 000000A65500: D7000015
	v_cndmask_b32_e32 v1, s0, v22, vcc_lo                      // 000000A65504: 02022C00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A65508: BF870191
	v_add_co_ci_u32_e64 v22, null, s2, 0, s0                   // 000000A6550C: D5207C16 00010002
	v_subrev_nc_u32_e32 v6, 32, v6                             // 000000A65514: 4E0C0CA0
	v_and_b32_e32 v4, 0x7e0, v4                                // 000000A65518: 360808FF 000007E0
	v_mul_u32_u24_e32 v5, 0x420, v7                            // 000000A65520: 160A0EFF 00000420
	v_mad_u32_u24 v11, 0x420, v7, v9                           // 000000A65528: D60B000B 04260EFF 00000420
	v_sub_nc_u32_e32 v29, 0, v2                                // 000000A65534: 4C3A0480
	v_cndmask_b32_e32 v6, 31, v6, vcc_lo                       // 000000A65538: 020C0C9F
	.long 0xd7006a15                                           // 000000A6553C: D7006A15
	v_cndmask_b32_e32 v1, v21, v9, vcc_lo                      // 000000A65540: 02021315
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A65544: BF870191
	v_add_co_ci_u32_e64 v22, null, 0, v22, vcc_lo              // 000000A65548: D5207C16 01AA2C80
	v_dual_mov_b32 v24, 0 :: v_dual_add_nc_u32 v23, 1, v6      // 000000A65550: CA200080 18160C81
	v_sub_nc_u32_e32 v3, v4, v3                                // 000000A65558: 4C060704
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A6555C: BF870194
	.long 0xd7006a15                                           // 000000A65560: D7006A15
	v_cndmask_b32_e32 v1, s4, v21, vcc_lo                      // 000000A65564: 02022A04
	v_and_b32_e32 v4, 31, v23                                  // 000000A65568: 36082E9F
	v_add_co_ci_u32_e64 v22, null, s5, v22, vcc_lo             // 000000A6556C: D5207C16 01AA2C05
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000A65574: BF870224
	v_add_nc_u32_e32 v28, 0xfffffc30, v3                       // 000000A65578: 4A3806FF FFFFFC30
	v_lshl_add_u32 v3, v6, 2, v5                               // 000000A65580: D6460003 04150506
	v_lshl_add_u32 v4, v4, 2, v5                               // 000000A65588: D6460004 04150504
	.long 0xd7006a05                                           // 000000A65590: D7006A05
	v_cndmask_b32_e32 v1, 0x400, v21, vcc_lo                   // 000000A65594: 02022AFF 00000400
	s_delay_alu instid0(VALU_DEP_1)                            // 000000A6559C: BF870001
	v_add_co_ci_u32_e64 v6, null, 0, v22, vcc_lo               // 000000A655A0: D5207C06 01AA2C80
	v_add_nc_u32_e32 v30, 1, v1                                // 000000A655A8: 4A3C0281
	v_dual_mov_b32 v22, 0 :: v_dual_add_nc_u32 v31, 0x400, v11 // 000000A655AC: CA200080 161E16FF 00000400
	v_add_nc_u32_e32 v32, 0x800, v11                           // 000000A655B8: 4A4016FF 00000800
	v_add_nc_u32_e32 v33, 0x400, v3                            // 000000A655C0: 4A4206FF 00000400
	v_add_nc_u32_e32 v34, 0x400, v4                            // 000000A655C8: 4A4408FF 00000400
	v_add_nc_u32_e32 v35, 0x800, v3                            // 000000A655D0: 4A4606FF 00000800
	v_dual_mov_b32 v23, 0 :: v_dual_add_nc_u32 v36, 0x800, v4  // 000000A655D8: CA200080 172408FF 00000800
	v_mov_b32_e32 v21, 0                                       // 000000A655E4: 7E2A0280
	v_mov_b32_e32 v11, 0                                       // 000000A655E8: 7E160280
	s_mov_b32 s2, 0                                            // 000000A655EC: BE820080
	s_movk_i32 s4, 0x1eee                                      // 000000A655F0: B0041EEE
	s_branch 873                                               // 000000A655F4: BFA00369 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_tILi4ELi8ELi0ELb0EEEvPKjPKDF16_PKiS5_PtNS0_6HtFoldE+0x109c>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000A655F8: 8C7E007E
	ds_load_2addr_b32 v[37:38], v34 offset0:64 offset1:96      // 000000A655FC: D8DC6040 25000022
	ds_load_2addr_b32 v[43:44], v31 offset0:64 offset1:96      // 000000A65604: D8DC6040 2B00001F
	ds_load_2addr_b32 v[41:42], v33 offset0:64 offset1:96      // 000000A6560C: D8DC6040 29000021
	ds_load_b128 v[1:4], v27                                   // 000000A65614: DBFC0000 0100001B
	.long 0xd7000005                                           // 000000A6561C: D7000005
	v_cndmask_b32_e32 v1, 0x400, v5, vcc_lo                    // 000000A65620: 02020AFF 00000400
	v_add_nc_u32_e32 v27, 32, v27                              // 000000A65628: 4A3636A0
	v_add_co_ci_u32_e64 v6, null, 0, v6, s0                    // 000000A6562C: D5207C06 00020C80
	s_waitcnt lgkmcnt(3)                                       // 000000A65634: BF89FC37
	v_mov_b32_e32 v40, v37                                     // 000000A65638: 7E500325
	s_waitcnt lgkmcnt(2)                                       // 000000A6563C: BF89FC27
	v_bfe_u32 v37, v43, 12, 16                                 // 000000A65640: D6100025 0241192B
	v_bfe_u32 v45, v43, 8, 16                                  // 000000A65648: D610002D 0241112B
	v_bfe_u32 v46, v43, 4, 16                                  // 000000A65650: D610002E 0241092B
	v_and_b32_e32 v43, 0xffff, v43                             // 000000A65658: 365656FF 0000FFFF
	s_waitcnt lgkmcnt(1)                                       // 000000A65660: BF89FC17
	v_mov_b32_e32 v39, v42                                     // 000000A65664: 7E4E032A
	.long 0xd73d0028                                           // 000000A65668: D73D0028
	v_cndmask_b32_e32 v1, v28, v40, vcc_lo                     // 000000A6566C: 0202511C
	v_bfe_u32 v42, v44, 12, 16                                 // 000000A65670: D610002A 0241192C
	v_bfe_u32 v47, v44, 8, 16                                  // 000000A65678: D610002F 0241112C
	v_bfe_u32 v48, v44, 4, 16                                  // 000000A65680: D6100030 0241092C
	v_and_b32_e32 v44, 0xffff, v44                             // 000000A65688: 365858FF 0000FFFF
	.long 0xd72c0029                                           // 000000A65690: D72C0029
	v_cndmask_b32_e32 v1, 0x83dcd12d, v37, vcc_lo              // 000000A65694: 02024AFF 83DCD12D
	.long 0xd73d0025                                           // 000000A6569C: D73D0025
	v_cndmask_b32_e32 v1, v28, v38, vcc_lo                     // 000000A656A0: 02024D1C
	v_bfe_u32 v38, v40, 12, 16                                 // 000000A656A4: D6100026 02411928
	.long 0xd72c0027                                           // 000000A656AC: D72C0027
	v_cndmask_b32_e32 v1, 0x83dcd12d, v42, vcc_lo              // 000000A656B0: 020254FF 83DCD12D
	v_bfe_u32 v42, v40, 8, 16                                  // 000000A656B8: D610002A 02411128
	.long 0xd72c002b                                           // 000000A656C0: D72C002B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v43, vcc_lo              // 000000A656C4: 020256FF 83DCD12D
	.long 0xd72c002e                                           // 000000A656CC: D72C002E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v46, vcc_lo              // 000000A656D0: 02025CFF 83DCD12D
	.long 0xd72c0026                                           // 000000A656D8: D72C0026
	v_cndmask_b32_e32 v1, 0x83dcd12d, v38, vcc_lo              // 000000A656DC: 02024CFF 83DCD12D
	v_bfe_u32 v50, v37, 12, 16                                 // 000000A656E4: D6100032 02411925
	.long 0xd72c002a                                           // 000000A656EC: D72C002A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v42, vcc_lo              // 000000A656F0: 020254FF 83DCD12D
	v_bfe_u32 v49, v40, 4, 16                                  // 000000A656F8: D6100031 02410928
	.long 0xd72c002d                                           // 000000A65700: D72C002D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v45, vcc_lo              // 000000A65704: 02025AFF 83DCD12D
	v_sad_u8 v41, v41, 0, 0x6400                               // 000000A6570C: D6220029 03FD0129 00006400
	v_sad_u8 v43, v43, 0, 0x6400                               // 000000A65718: D622002B 03FD012B 00006400
	.long 0xd72c0032                                           // 000000A65724: D72C0032
	v_cndmask_b32_e32 v1, 0x83dcd12d, v50, vcc_lo              // 000000A65728: 020264FF 83DCD12D
	v_sad_u8 v38, v38, 0, 0x6400                               // 000000A65730: D6220026 03FD0126 00006400
	v_sad_u8 v46, v46, 0, 0x6400                               // 000000A6573C: D622002E 03FD012E 00006400
	v_sad_u8 v42, v42, 0, 0x6400                               // 000000A65748: D622002A 03FD012A 00006400
	v_lshlrev_b32_e32 v43, 16, v43                             // 000000A65754: 30565690
	.long 0xd72c0031                                           // 000000A65758: D72C0031
	v_cndmask_b32_e32 v1, 0x83dcd12d, v49, vcc_lo              // 000000A6575C: 020262FF 83DCD12D
	v_and_b32_e32 v38, 0xffff, v38                             // 000000A65764: 364C4CFF 0000FFFF
	v_sad_u8 v45, v45, 0, 0x6400                               // 000000A6576C: D622002D 03FD012D 00006400
	v_and_b32_e32 v41, 0xffff, v41                             // 000000A65778: 365252FF 0000FFFF
	v_and_or_b32 v46, 0xffff, v46, v43                         // 000000A65780: D657002E 04AE5CFF 0000FFFF
	v_sad_u8 v43, v50, 0, 0x6400                               // 000000A6578C: D622002B 03FD0132 00006400
	v_lshl_or_b32 v38, v42, 16, v38                            // 000000A65798: D6560026 0499212A
	v_bfe_u32 v51, v37, 8, 16                                  // 000000A657A0: D6100033 02411125
	.long 0xd72c002c                                           // 000000A657A8: D72C002C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v44, vcc_lo              // 000000A657AC: 020258FF 83DCD12D
	v_lshl_or_b32 v41, v45, 16, v41                            // 000000A657B4: D6560029 04A5212D
	v_sad_u8 v45, v49, 0, 0x6400                               // 000000A657BC: D622002D 03FD0131 00006400
	v_pk_fma_f16 v50, v38, s4, 0xc931 op_sel_hi:[1,0,0]        // 000000A657C8: CC0E0032 0BFC0926 0000C931
	v_and_b32_e32 v40, 0xffff, v40                             // 000000A657D4: 365050FF 0000FFFF
	.long 0xd72c0033                                           // 000000A657DC: D72C0033
	v_cndmask_b32_e32 v1, 0x83dcd12d, v51, vcc_lo              // 000000A657E0: 020266FF 83DCD12D
	.long 0xd72c0030                                           // 000000A657E8: D72C0030
	v_cndmask_b32_e32 v1, 0x83dcd12d, v48, vcc_lo              // 000000A657EC: 020260FF 83DCD12D
	v_bfe_u32 v52, v37, 4, 16                                  // 000000A657F4: D6100034 02410925
	s_waitcnt lgkmcnt(0)                                       // 000000A657FC: BF89FC07
	v_dot2acc_f32_f16 v15, v50, v1                             // 000000A65800: 041E0332
	.long 0xd72c0028                                           // 000000A65804: D72C0028
	v_cndmask_b32_e32 v1, 0x83dcd12d, v40, vcc_lo              // 000000A65808: 020250FF 83DCD12D
	v_sad_u8 v44, v44, 0, 0x6400                               // 000000A65810: D622002C 03FD012C 00006400
	.long 0xd72c002f                                           // 000000A6581C: D72C002F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v47, vcc_lo              // 000000A65820: 02025EFF 83DCD12D
	.long 0xd72c0034                                           // 000000A65828: D72C0034
	v_cndmask_b32_e32 v1, 0x83dcd12d, v52, vcc_lo              // 000000A6582C: 020268FF 83DCD12D
	v_sad_u8 v49, v51, 0, 0x6400                               // 000000A65834: D6220031 03FD0133 00006400
	v_sad_u8 v48, v48, 0, 0x6400                               // 000000A65840: D6220030 03FD0130 00006400
	v_sad_u8 v39, v39, 0, 0x6400                               // 000000A6584C: D6220027 03FD0127 00006400
	v_sad_u8 v40, v40, 0, 0x6400                               // 000000A65858: D6220028 03FD0128 00006400
	v_sad_u8 v47, v47, 0, 0x6400                               // 000000A65864: D622002F 03FD012F 00006400
	v_sad_u8 v52, v52, 0, 0x6400                               // 000000A65870: D6220034 03FD0134 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A6587C: BF870214
	v_and_b32_e32 v39, 0xffff, v39                             // 000000A65880: 364E4EFF 0000FFFF
	v_lshlrev_b32_e32 v40, 16, v40                             // 000000A65888: 30505090
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A6588C: BF870112
	v_lshl_or_b32 v47, v47, 16, v39                            // 000000A65890: D656002F 049D212F
	v_and_or_b32 v40, 0xffff, v45, v40                         // 000000A65898: D6570028 04A25AFF 0000FFFF
	v_pk_fma_f16 v45, v41, s4, 0xc931 op_sel_hi:[1,0,0]        // 000000A658A4: CC0E002D 0BFC0929 0000C931
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000A658B0: BF8700B2
	v_pk_fma_f16 v51, v40, s4, 0xc931 op_sel_hi:[1,0,0]        // 000000A658B4: CC0E0033 0BFC0928 0000C931
	ds_load_2addr_b32 v[40:41], v33 offset0:128 offset1:160    // 000000A658C0: D8DCA080 28000021
	v_dual_dot2acc_f32_f16 v15, v51, v2 :: v_dual_lshlrev_b32 v44, 16, v44// 000000A658C8: CB220533 0F2C5890
	v_and_or_b32 v44, 0xffff, v48, v44                         // 000000A658D0: D657002C 04B260FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A658DC: BF870112
	v_dot2acc_f32_f16 v15, v45, v3                             // 000000A658E0: 041E072D
	v_pk_fma_f16 v44, v44, s4, 0xc931 op_sel_hi:[1,0,0]        // 000000A658E4: CC0E002C 0BFC092C 0000C931
	v_and_b32_e32 v43, 0xffff, v43                             // 000000A658F0: 365656FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A658F8: BF870091
	v_lshl_or_b32 v43, v49, 16, v43                            // 000000A658FC: D656002B 04AD2131
	v_pk_fma_f16 v49, v43, s4, 0xc931 op_sel_hi:[1,0,0]        // 000000A65904: CC0E0031 0BFC092B 0000C931
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000A65910: BF8700A1
	v_dot2acc_f32_f16 v26, v49, v1                             // 000000A65914: 04340331
	v_and_b32_e32 v37, 0xffff, v37                             // 000000A65918: 364A4AFF 0000FFFF
	.long 0xd72c0025                                           // 000000A65920: D72C0025
	v_cndmask_b32_e32 v1, 0x83dcd12d, v37, vcc_lo              // 000000A65924: 02024AFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000A6592C: BF8700B1
	v_sad_u8 v42, v37, 0, 0x6400                               // 000000A65930: D622002A 03FD0125 00006400
	ds_load_2addr_b32 v[37:38], v34 offset0:128 offset1:160    // 000000A6593C: D8DCA080 25000022
	v_lshlrev_b32_e32 v42, 16, v42                             // 000000A65944: 30545490
	v_and_or_b32 v42, 0xffff, v52, v42                         // 000000A65948: D657002A 04AA68FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 000000A65954: BF870151
	v_pk_fma_f16 v50, v42, s4, 0xc931 op_sel_hi:[1,0,0]        // 000000A65958: CC0E0032 0BFC092A 0000C931
	ds_load_2addr_b32 v[42:43], v31 offset0:128 offset1:160    // 000000A65964: D8DCA080 2A00001F
	s_waitcnt lgkmcnt(1)                                       // 000000A6596C: BF89FC17
	v_dual_dot2acc_f32_f16 v26, v50, v2 :: v_dual_mov_b32 v39, v37// 000000A65970: CB100532 1A260125
	v_pk_fma_f16 v37, v47, s4, 0xc931 op_sel_hi:[1,0,0]        // 000000A65978: CC0E0025 0BFC092F 0000C931
	.long 0xd73d0027                                           // 000000A65984: D73D0027
	v_cndmask_b32_e32 v1, v28, v39, vcc_lo                     // 000000A65988: 02024F1C
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000A6598C: BF8701A2
	v_dot2acc_f32_f16 v26, v37, v3                             // 000000A65990: 04340725
	v_pk_fma_f16 v40, v46, s4, 0xc931 op_sel_hi:[1,0,0]        // 000000A65994: CC0E0028 0BFC092E 0000C931
	v_bfe_u32 v37, v39, 12, 16                                 // 000000A659A0: D6100025 02411927
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000A659A8: BF870223
	v_dot2acc_f32_f16 v26, v44, v4                             // 000000A659AC: 0434092C
	v_bfe_u32 v45, v39, 8, 16                                  // 000000A659B0: D610002D 02411127
	v_dual_dot2acc_f32_f16 v15, v40, v4 :: v_dual_and_b32 v40, 0xffff, v39// 000000A659B8: CB240928 0F284EFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A659C4: BF870004
	.long 0xd72c0025                                           // 000000A659C8: D72C0025
	v_cndmask_b32_e32 v1, 0x83dcd12d, v37, vcc_lo              // 000000A659CC: 02024AFF 83DCD12D
	s_waitcnt lgkmcnt(0)                                       // 000000A659D4: BF89FC07
	v_bfe_u32 v44, v42, 12, 16                                 // 000000A659D8: D610002C 0241192A
	v_bfe_u32 v39, v39, 4, 16                                  // 000000A659E0: D6100027 02410927
	v_bfe_u32 v46, v42, 8, 16                                  // 000000A659E8: D610002E 0241112A
	.long 0xd72c002d                                           // 000000A659F0: D72C002D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v45, vcc_lo              // 000000A659F4: 02025AFF 83DCD12D
	v_bfe_u32 v47, v42, 4, 16                                  // 000000A659FC: D610002F 0241092A
	.long 0xd72c002c                                           // 000000A65A04: D72C002C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v44, vcc_lo              // 000000A65A08: 020258FF 83DCD12D
	v_and_b32_e32 v42, 0xffff, v42                             // 000000A65A10: 365454FF 0000FFFF
	v_sad_u8 v37, v37, 0, 0x6400                               // 000000A65A18: D6220025 03FD0125 00006400
	.long 0xd72c0027                                           // 000000A65A24: D72C0027
	v_cndmask_b32_e32 v1, 0x83dcd12d, v39, vcc_lo              // 000000A65A28: 02024EFF 83DCD12D
	.long 0xd72c0028                                           // 000000A65A30: D72C0028
	v_cndmask_b32_e32 v1, 0x83dcd12d, v40, vcc_lo              // 000000A65A34: 020250FF 83DCD12D
	.long 0xd72c002e                                           // 000000A65A3C: D72C002E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v46, vcc_lo              // 000000A65A40: 02025CFF 83DCD12D
	.long 0xd72c002a                                           // 000000A65A48: D72C002A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v42, vcc_lo              // 000000A65A4C: 020254FF 83DCD12D
	v_and_b32_e32 v37, 0xffff, v37                             // 000000A65A54: 364A4AFF 0000FFFF
	v_sad_u8 v44, v44, 0, 0x6400                               // 000000A65A5C: D622002C 03FD012C 00006400
	v_sad_u8 v45, v45, 0, 0x6400                               // 000000A65A68: D622002D 03FD012D 00006400
	.long 0xd72c002f                                           // 000000A65A74: D72C002F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v47, vcc_lo              // 000000A65A78: 02025EFF 83DCD12D
	v_sad_u8 v48, v39, 0, 0x6400                               // 000000A65A80: D6220030 03FD0127 00006400
	v_mov_b32_e32 v39, v41                                     // 000000A65A8C: 7E4E0329
	v_sad_u8 v40, v40, 0, 0x6400                               // 000000A65A90: D6220028 03FD0128 00006400
	v_and_b32_e32 v44, 0xffff, v44                             // 000000A65A9C: 365858FF 0000FFFF
	v_sad_u8 v41, v46, 0, 0x6400                               // 000000A65AA4: D6220029 03FD012E 00006400
	v_lshl_or_b32 v45, v45, 16, v37                            // 000000A65AB0: D656002D 0495212D
	v_sad_u8 v42, v42, 0, 0x6400                               // 000000A65AB8: D622002A 03FD012A 00006400
	.long 0xd73d0025                                           // 000000A65AC4: D73D0025
	v_cndmask_b32_e32 v1, v28, v38, vcc_lo                     // 000000A65AC8: 02024D1C
	v_sad_u8 v39, v47, 0, 0x6400                               // 000000A65ACC: D6220027 03FD012F 00006400
	v_lshl_or_b32 v38, v41, 16, v44                            // 000000A65AD8: D6560026 04B12129
	v_bfe_u32 v47, v43, 12, 16                                 // 000000A65AE0: D610002F 0241192B
	v_lshlrev_b32_e32 v41, 16, v42                             // 000000A65AE8: 30525490
	v_pk_fma_f16 v42, v45, s4, 0xc931 op_sel_hi:[1,0,0]        // 000000A65AEC: CC0E002A 0BFC092D 0000C931
	v_lshlrev_b32_e32 v40, 16, v40                             // 000000A65AF8: 30505090
	v_bfe_u32 v44, v37, 12, 16                                 // 000000A65AFC: D610002C 02411925
	v_pk_fma_f16 v45, v38, s4, 0xc931 op_sel_hi:[1,0,0]        // 000000A65B04: CC0E002D 0BFC0926 0000C931
	v_and_or_b32 v38, 0xffff, v39, v41                         // 000000A65B10: D6570026 04A64EFF 0000FFFF
	v_dot2acc_f32_f16 v25, v42, v1                             // 000000A65B1C: 0432032A
	v_and_or_b32 v40, 0xffff, v48, v40                         // 000000A65B20: D6570028 04A260FF 0000FFFF
	v_bfe_u32 v39, v37, 8, 16                                  // 000000A65B2C: D6100027 02411125
	.long 0xd72c0029                                           // 000000A65B34: D72C0029
	v_cndmask_b32_e32 v1, 0x83dcd12d, v44, vcc_lo              // 000000A65B38: 020258FF 83DCD12D
	v_pk_fma_f16 v44, v38, s4, 0xc931 op_sel_hi:[1,0,0]        // 000000A65B40: CC0E002C 0BFC0926 0000C931
	v_bfe_u32 v48, v43, 8, 16                                  // 000000A65B4C: D6100030 0241112B
	v_pk_fma_f16 v40, v40, s4, 0xc931 op_sel_hi:[1,0,0]        // 000000A65B54: CC0E0028 0BFC0928 0000C931
	.long 0xd72c0027                                           // 000000A65B60: D72C0027
	v_cndmask_b32_e32 v1, 0x83dcd12d, v39, vcc_lo              // 000000A65B64: 02024EFF 83DCD12D
	.long 0xd72c002f                                           // 000000A65B6C: D72C002F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v47, vcc_lo              // 000000A65B70: 02025EFF 83DCD12D
	v_bfe_u32 v50, v43, 4, 16                                  // 000000A65B78: D6100032 0241092B
	.long 0xd72c0030                                           // 000000A65B80: D72C0030
	v_cndmask_b32_e32 v1, 0x83dcd12d, v48, vcc_lo              // 000000A65B84: 020260FF 83DCD12D
	v_dual_dot2acc_f32_f16 v25, v40, v2 :: v_dual_and_b32 v42, 0xffff, v37// 000000A65B8C: CB240528 192A4AFF 0000FFFF
	v_bfe_u32 v40, v37, 4, 16                                  // 000000A65B98: D6100028 02410925
	ds_load_2addr_b32 v[37:38], v34 offset0:192 offset1:224    // 000000A65BA0: D8DCE0C0 25000022
	v_sad_u8 v46, v41, 0, 0x6400                               // 000000A65BA8: D622002E 03FD0129 00006400
	v_dot2acc_f32_f16 v25, v45, v3                             // 000000A65BB4: 0432072D
	.long 0xd72c002a                                           // 000000A65BB8: D72C002A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v42, vcc_lo              // 000000A65BBC: 020254FF 83DCD12D
	.long 0xd72c0031                                           // 000000A65BC4: D72C0031
	v_cndmask_b32_e32 v1, 0x83dcd12d, v40, vcc_lo              // 000000A65BC8: 020250FF 83DCD12D
	ds_load_2addr_b32 v[40:41], v33 offset0:192 offset1:224    // 000000A65BD0: D8DCE0C0 28000021
	v_dual_dot2acc_f32_f16 v25, v44, v4 :: v_dual_and_b32 v46, 0xffff, v46// 000000A65BD8: CB24092C 192E5CFF 0000FFFF
	v_sad_u8 v39, v39, 0, 0x6400                               // 000000A65BE4: D6220027 03FD0127 00006400
	v_sad_u8 v47, v47, 0, 0x6400                               // 000000A65BF0: D622002F 03FD012F 00006400
	v_sad_u8 v48, v48, 0, 0x6400                               // 000000A65BFC: D6220030 03FD0130 00006400
	v_sad_u8 v42, v42, 0, 0x6400                               // 000000A65C08: D622002A 03FD012A 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000A65C14: BF870234
	v_lshl_or_b32 v39, v39, 16, v46                            // 000000A65C18: D6560027 04B92127
	v_sad_u8 v46, v49, 0, 0x6400                               // 000000A65C20: D622002E 03FD0131 00006400
	v_and_b32_e32 v47, 0xffff, v47                             // 000000A65C2C: 365E5EFF 0000FFFF
	v_lshlrev_b32_e32 v42, 16, v42                             // 000000A65C34: 30545490
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000A65C38: BF8701B4
	v_pk_fma_f16 v49, v39, s4, 0xc931 op_sel_hi:[1,0,0]        // 000000A65C3C: CC0E0031 0BFC0927 0000C931
	s_waitcnt lgkmcnt(1)                                       // 000000A65C48: BF89FC17
	v_mov_b32_e32 v39, v37                                     // 000000A65C4C: 7E4E0325
	v_and_or_b32 v46, 0xffff, v46, v42                         // 000000A65C50: D657002E 04AA5CFF 0000FFFF
	.long 0xd72c0025                                           // 000000A65C5C: D72C0025
	v_cndmask_b32_e32 v1, 0x83dcd12d, v50, vcc_lo              // 000000A65C60: 020264FF 83DCD12D
	v_dot2acc_f32_f16 v24, v49, v1                             // 000000A65C68: 04300331
	s_waitcnt lgkmcnt(0)                                       // 000000A65C6C: BF89FC07
	.long 0xd73d0027                                           // 000000A65C70: D73D0027
	v_cndmask_b32_e32 v1, v28, v39, vcc_lo                     // 000000A65C74: 02024F1C
	v_pk_fma_f16 v40, v46, s4, 0xc931 op_sel_hi:[1,0,0]        // 000000A65C78: CC0E0028 0BFC092E 0000C931
	v_lshl_or_b32 v46, v48, 16, v47                            // 000000A65C84: D656002E 04BD2130
	v_sad_u8 v37, v37, 0, 0x6400                               // 000000A65C8C: D6220025 03FD0125 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A65C98: BF870193
	v_dot2acc_f32_f16 v24, v40, v2                             // 000000A65C9C: 04300528
	v_pk_fma_f16 v45, v46, s4, 0xc931 op_sel_hi:[1,0,0]        // 000000A65CA0: CC0E002D 0BFC092E 0000C931
	v_bfe_u32 v48, v39, 12, 16                                 // 000000A65CAC: D6100030 02411927
	v_bfe_u32 v46, v39, 8, 16                                  // 000000A65CB4: D610002E 02411127
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000A65CBC: BF870223
	v_dot2acc_f32_f16 v24, v45, v3                             // 000000A65CC0: 0430072D
	v_and_b32_e32 v43, 0xffff, v43                             // 000000A65CC4: 365656FF 0000FFFF
	.long 0xd72c0028                                           // 000000A65CCC: D72C0028
	v_cndmask_b32_e32 v1, 0x83dcd12d, v48, vcc_lo              // 000000A65CD0: 020260FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A65CD8: BF870194
	.long 0xd72c002d                                           // 000000A65CDC: D72C002D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v46, vcc_lo              // 000000A65CE0: 02025CFF 83DCD12D
	.long 0xd72c002b                                           // 000000A65CE8: D72C002B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v43, vcc_lo              // 000000A65CEC: 020256FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A65CF4: BF870193
	v_sad_u8 v40, v40, 0, 0x6400                               // 000000A65CF8: D6220028 03FD0128 00006400
	v_sad_u8 v45, v45, 0, 0x6400                               // 000000A65D04: D622002D 03FD012D 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000A65D10: BF870143
	v_sad_u8 v50, v43, 0, 0x6400                               // 000000A65D14: D6220032 03FD012B 00006400
	ds_load_2addr_b32 v[42:43], v31 offset0:192 offset1:224    // 000000A65D20: D8DCE0C0 2A00001F
	v_and_b32_e32 v40, 0xffff, v40                             // 000000A65D28: 365050FF 0000FFFF
	v_lshlrev_b32_e32 v47, 16, v50                             // 000000A65D30: 305E6490
	v_lshl_or_b32 v40, v45, 16, v40                            // 000000A65D34: D6560028 04A1212D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A65D3C: BF870092
	v_and_or_b32 v37, 0xffff, v37, v47                         // 000000A65D40: D6570025 04BE4AFF 0000FFFF
	v_pk_fma_f16 v44, v37, s4, 0xc931 op_sel_hi:[1,0,0]        // 000000A65D4C: CC0E002C 0BFC0925 0000C931
	v_bfe_u32 v37, v39, 4, 16                                  // 000000A65D58: D6100025 02410927
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000A65D60: BF8701C2
	v_dual_dot2acc_f32_f16 v24, v44, v4 :: v_dual_and_b32 v39, 0xffff, v39// 000000A65D64: CB24092C 18264EFF 0000FFFF
	s_waitcnt lgkmcnt(0)                                       // 000000A65D70: BF89FC07
	v_bfe_u32 v46, v42, 12, 16                                 // 000000A65D74: D610002E 0241192A
	v_and_b32_e32 v48, 0xffff, v42                             // 000000A65D7C: 366054FF 0000FFFF
	.long 0xd72c0027                                           // 000000A65D84: D72C0027
	v_cndmask_b32_e32 v1, 0x83dcd12d, v39, vcc_lo              // 000000A65D88: 02024EFF 83DCD12D
	.long 0xd72c0025                                           // 000000A65D90: D72C0025
	v_cndmask_b32_e32 v1, 0x83dcd12d, v37, vcc_lo              // 000000A65D94: 02024AFF 83DCD12D
	v_bfe_u32 v47, v42, 8, 16                                  // 000000A65D9C: D610002F 0241112A
	.long 0xd72c002e                                           // 000000A65DA4: D72C002E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v46, vcc_lo              // 000000A65DA8: 02025CFF 83DCD12D
	.long 0xd72c0030                                           // 000000A65DB0: D72C0030
	v_cndmask_b32_e32 v1, 0x83dcd12d, v48, vcc_lo              // 000000A65DB4: 020260FF 83DCD12D
	v_bfe_u32 v42, v42, 4, 16                                  // 000000A65DBC: D610002A 0241092A
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000A65DC4: BF870234
	.long 0xd72c002d                                           // 000000A65DC8: D72C002D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v47, vcc_lo              // 000000A65DCC: 02025EFF 83DCD12D
	v_sad_u8 v39, v39, 0, 0x6400                               // 000000A65DD4: D6220027 03FD0127 00006400
	v_sad_u8 v47, v37, 0, 0x6400                               // 000000A65DE0: D622002F 03FD0125 00006400
	.long 0xd72c002a                                           // 000000A65DEC: D72C002A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v42, vcc_lo              // 000000A65DF0: 020254FF 83DCD12D
	v_sad_u8 v46, v46, 0, 0x6400                               // 000000A65DF8: D622002E 03FD012E 00006400
	v_sad_u8 v37, v48, 0, 0x6400                               // 000000A65E04: D6220025 03FD0130 00006400
	v_lshlrev_b32_e32 v49, 16, v39                             // 000000A65E10: 30624E90
	v_mov_b32_e32 v39, v41                                     // 000000A65E14: 7E4E0329
	v_sad_u8 v45, v45, 0, 0x6400                               // 000000A65E18: D622002D 03FD012D 00006400
	v_and_b32_e32 v41, 0xffff, v46                             // 000000A65E24: 36525CFF 0000FFFF
	v_lshlrev_b32_e32 v46, 16, v37                             // 000000A65E2C: 305C4A90
	v_sad_u8 v42, v42, 0, 0x6400                               // 000000A65E30: D622002A 03FD012A 00006400
	.long 0xd73d0025                                           // 000000A65E3C: D73D0025
	v_cndmask_b32_e32 v1, v28, v38, vcc_lo                     // 000000A65E40: 02024D1C
	v_pk_fma_f16 v39, v40, s4, 0xc931 op_sel_hi:[1,0,0]        // 000000A65E44: CC0E0027 0BFC0928 0000C931
	v_lshl_or_b32 v40, v45, 16, v41                            // 000000A65E50: D6560028 04A5212D
	v_and_or_b32 v38, 0xffff, v47, v49                         // 000000A65E58: D6570026 04C65EFF 0000FFFF
	v_and_or_b32 v41, 0xffff, v42, v46                         // 000000A65E64: D6570029 04BA54FF 0000FFFF
	v_bfe_u32 v46, v43, 8, 16                                  // 000000A65E70: D610002E 0241112B
	v_bfe_u32 v42, v37, 12, 16                                 // 000000A65E78: D610002A 02411925
	v_dot2acc_f32_f16 v23, v39, v1                             // 000000A65E80: 042E0327
	v_pk_fma_f16 v44, v40, s4, 0xc931 op_sel_hi:[1,0,0]        // 000000A65E84: CC0E002C 0BFC0928 0000C931
	v_bfe_u32 v40, v37, 8, 16                                  // 000000A65E90: D6100028 02411125
	v_pk_fma_f16 v38, v38, s4, 0xc931 op_sel_hi:[1,0,0]        // 000000A65E98: CC0E0026 0BFC0926 0000C931
	.long 0xd72c0027                                           // 000000A65EA4: D72C0027
	v_cndmask_b32_e32 v1, 0x83dcd12d, v42, vcc_lo              // 000000A65EA8: 020254FF 83DCD12D
	v_pk_fma_f16 v45, v41, s4, 0xc931 op_sel_hi:[1,0,0]        // 000000A65EB0: CC0E002D 0BFC0929 0000C931
	v_bfe_u32 v41, v37, 4, 16                                  // 000000A65EBC: D6100029 02410925
	v_and_b32_e32 v37, 0xffff, v37                             // 000000A65EC4: 364A4AFF 0000FFFF
	.long 0xd72c0028                                           // 000000A65ECC: D72C0028
	v_cndmask_b32_e32 v1, 0x83dcd12d, v40, vcc_lo              // 000000A65ED0: 020250FF 83DCD12D
	v_dot2acc_f32_f16 v23, v38, v2                             // 000000A65ED8: 042E0526
	v_bfe_u32 v42, v43, 12, 16                                 // 000000A65EDC: D610002A 0241192B
	v_bfe_u32 v47, v43, 4, 16                                  // 000000A65EE4: D610002F 0241092B
	v_sad_u8 v39, v39, 0, 0x6400                               // 000000A65EEC: D6220027 03FD0127 00006400
	.long 0xd72c0030                                           // 000000A65EF8: D72C0030
	v_cndmask_b32_e32 v1, 0x83dcd12d, v37, vcc_lo              // 000000A65EFC: 02024AFF 83DCD12D
	ds_load_2addr_b32 v[37:38], v36 offset1:32                 // 000000A65F04: D8DC2000 25000024
	v_and_b32_e32 v43, 0xffff, v43                             // 000000A65F0C: 365656FF 0000FFFF
	v_sad_u8 v49, v40, 0, 0x6400                               // 000000A65F14: D6220031 03FD0128 00006400
	v_and_b32_e32 v39, 0xffff, v39                             // 000000A65F20: 364E4EFF 0000FFFF
	.long 0xd72c0032                                           // 000000A65F28: D72C0032
	v_cndmask_b32_e32 v1, 0x83dcd12d, v41, vcc_lo              // 000000A65F2C: 020252FF 83DCD12D
	ds_load_2addr_b32 v[40:41], v35 offset1:32                 // 000000A65F34: D8DC2000 28000023
	.long 0xd72c002b                                           // 000000A65F3C: D72C002B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v43, vcc_lo              // 000000A65F40: 020256FF 83DCD12D
	.long 0xd72c002a                                           // 000000A65F48: D72C002A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v42, vcc_lo              // 000000A65F4C: 020254FF 83DCD12D
	v_lshl_or_b32 v49, v49, 16, v39                            // 000000A65F54: D6560031 049D2131
	v_sad_u8 v39, v48, 0, 0x6400                               // 000000A65F5C: D6220027 03FD0130 00006400
	.long 0xd72c002e                                           // 000000A65F68: D72C002E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v46, vcc_lo              // 000000A65F6C: 02025CFF 83DCD12D
	.long 0xd72c002f                                           // 000000A65F74: D72C002F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v47, vcc_lo              // 000000A65F78: 02025EFF 83DCD12D
	v_sad_u8 v50, v50, 0, 0x6400                               // 000000A65F80: D6220032 03FD0132 00006400
	v_pk_fma_f16 v49, v49, s4, 0xc931 op_sel_hi:[1,0,0]        // 000000A65F8C: CC0E0031 0BFC0931 0000C931
	v_lshlrev_b32_e32 v51, 16, v39                             // 000000A65F98: 30664E90
	v_sad_u8 v39, v43, 0, 0x6400                               // 000000A65F9C: D6220027 03FD012B 00006400
	v_sad_u8 v48, v42, 0, 0x6400                               // 000000A65FA8: D6220030 03FD012A 00006400
	ds_load_2addr_b32 v[42:43], v32 offset1:32                 // 000000A65FB4: D8DC2000 2A000020
	v_sad_u8 v46, v46, 0, 0x6400                               // 000000A65FBC: D622002E 03FD012E 00006400
	v_sad_u8 v47, v47, 0, 0x6400                               // 000000A65FC8: D622002F 03FD012F 00006400
	s_waitcnt lgkmcnt(2)                                       // 000000A65FD4: BF89FC27
	v_dual_mov_b32 v39, v37 :: v_dual_lshlrev_b32 v52, 16, v39 // 000000A65FD8: CA220125 27344E90
	v_dual_dot2acc_f32_f16 v23, v44, v3 :: v_dual_and_b32 v48, 0xffff, v48// 000000A65FE0: CB24072C 173060FF 0000FFFF
	v_and_or_b32 v37, 0xffff, v50, v51                         // 000000A65FEC: D6570025 04CE64FF 0000FFFF
	v_dot2acc_f32_f16 v22, v49, v1                             // 000000A65FF8: 042C0331
	s_waitcnt lgkmcnt(1)                                       // 000000A65FFC: BF89FC17
	.long 0xd73d0027                                           // 000000A66000: D73D0027
	v_cndmask_b32_e32 v1, v28, v39, vcc_lo                     // 000000A66004: 02024F1C
	v_lshl_or_b32 v46, v46, 16, v48                            // 000000A66008: D656002E 04C1212E
	v_and_or_b32 v47, 0xffff, v47, v52                         // 000000A66010: D657002F 04D25EFF 0000FFFF
	v_pk_fma_f16 v37, v37, s4, 0xc931 op_sel_hi:[1,0,0]        // 000000A6601C: CC0E0025 0BFC0925 0000C931
	v_dual_dot2acc_f32_f16 v23, v45, v4 :: v_dual_add_nc_u32 v30, 1, v30// 000000A66028: CB20092D 171E3C81
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000A66030: BF870224
	v_pk_fma_f16 v40, v46, s4, 0xc931 op_sel_hi:[1,0,0]        // 000000A66034: CC0E0028 0BFC092E 0000C931
	v_bfe_u32 v46, v39, 12, 16                                 // 000000A66040: D610002E 02411927
	v_dual_dot2acc_f32_f16 v22, v37, v2 :: v_dual_and_b32 v37, 0xffff, v39// 000000A66048: CB240525 16244EFF 0000FFFF
	v_pk_fma_f16 v44, v47, s4, 0xc931 op_sel_hi:[1,0,0]        // 000000A66054: CC0E002C 0BFC092F 0000C931
	v_bfe_u32 v47, v39, 8, 16                                  // 000000A66060: D610002F 02411127
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A66068: BF870004
	.long 0xd72c002e                                           // 000000A6606C: D72C002E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v46, vcc_lo              // 000000A66070: 02025CFF 83DCD12D
	v_bfe_u32 v39, v39, 4, 16                                  // 000000A66078: D6100027 02410927
	.long 0xd72c0025                                           // 000000A66080: D72C0025
	v_cndmask_b32_e32 v1, 0x83dcd12d, v37, vcc_lo              // 000000A66084: 02024AFF 83DCD12D
	s_waitcnt lgkmcnt(0)                                       // 000000A6608C: BF89FC07
	v_bfe_u32 v48, v42, 12, 16                                 // 000000A66090: D6100030 0241192A
	.long 0xd72c002f                                           // 000000A66098: D72C002F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v47, vcc_lo              // 000000A6609C: 02025EFF 83DCD12D
	v_bfe_u32 v49, v42, 8, 16                                  // 000000A660A4: D6100031 0241112A
	.long 0xd72c0027                                           // 000000A660AC: D72C0027
	v_cndmask_b32_e32 v1, 0x83dcd12d, v39, vcc_lo              // 000000A660B0: 02024EFF 83DCD12D
	v_bfe_u32 v50, v42, 4, 16                                  // 000000A660B8: D6100032 0241092A
	v_sad_u8 v46, v46, 0, 0x6400                               // 000000A660C0: D622002E 03FD012E 00006400
	.long 0xd72c0030                                           // 000000A660CC: D72C0030
	v_cndmask_b32_e32 v1, 0x83dcd12d, v48, vcc_lo              // 000000A660D0: 020260FF 83DCD12D
	v_sad_u8 v37, v37, 0, 0x6400                               // 000000A660D8: D6220025 03FD0125 00006400
	.long 0xd72c0031                                           // 000000A660E4: D72C0031
	v_cndmask_b32_e32 v1, 0x83dcd12d, v49, vcc_lo              // 000000A660E8: 020262FF 83DCD12D
	v_sad_u8 v47, v47, 0, 0x6400                               // 000000A660F0: D622002F 03FD012F 00006400
	v_and_b32_e32 v46, 0xffff, v46                             // 000000A660FC: 365C5CFF 0000FFFF
	v_sad_u8 v51, v39, 0, 0x6400                               // 000000A66104: D6220033 03FD0127 00006400
	v_lshlrev_b32_e32 v37, 16, v37                             // 000000A66110: 304A4A90
	v_mov_b32_e32 v39, v41                                     // 000000A66114: 7E4E0329
	v_sad_u8 v48, v48, 0, 0x6400                               // 000000A66118: D6220030 03FD0130 00006400
	v_lshl_or_b32 v46, v47, 16, v46                            // 000000A66124: D656002E 04B9212F
	v_dot2acc_f32_f16 v22, v40, v3                             // 000000A6612C: 042C0728
	v_and_or_b32 v47, 0xffff, v51, v37                         // 000000A66130: D657002F 049666FF 0000FFFF
	.long 0xd73d0025                                           // 000000A6613C: D73D0025
	v_cndmask_b32_e32 v1, v28, v38, vcc_lo                     // 000000A66140: 02024D1C
	v_sad_u8 v41, v49, 0, 0x6400                               // 000000A66144: D6220029 03FD0131 00006400
	v_pk_fma_f16 v40, v46, s4, 0xc931 op_sel_hi:[1,0,0]        // 000000A66150: CC0E0028 0BFC092E 0000C931
	v_and_b32_e32 v42, 0xffff, v42                             // 000000A6615C: 365454FF 0000FFFF
	.long 0xd72c0031                                           // 000000A66164: D72C0031
	v_cndmask_b32_e32 v1, 0x83dcd12d, v50, vcc_lo              // 000000A66168: 020264FF 83DCD12D
	v_bfe_u32 v50, v43, 8, 16                                  // 000000A66170: D6100032 0241112B
	v_bfe_u32 v51, v43, 4, 16                                  // 000000A66178: D6100033 0241092B
	v_dual_dot2acc_f32_f16 v21, v40, v1 :: v_dual_and_b32 v48, 0xffff, v48// 000000A66180: CB240328 153060FF 0000FFFF
	.long 0xd72c0027                                           // 000000A6618C: D72C0027
	v_cndmask_b32_e32 v1, 0x83dcd12d, v42, vcc_lo              // 000000A66190: 020254FF 83DCD12D
	v_bfe_u32 v42, v37, 12, 16                                 // 000000A66198: D610002A 02411925
	.long 0xd72c0032                                           // 000000A661A0: D72C0032
	v_cndmask_b32_e32 v1, 0x83dcd12d, v50, vcc_lo              // 000000A661A4: 020264FF 83DCD12D
	v_sad_u8 v46, v49, 0, 0x6400                               // 000000A661AC: D622002E 03FD0131 00006400
	v_lshl_or_b32 v38, v41, 16, v48                            // 000000A661B8: D6560026 04C12129
	v_pk_fma_f16 v41, v47, s4, 0xc931 op_sel_hi:[1,0,0]        // 000000A661C0: CC0E0029 0BFC092F 0000C931
	v_and_b32_e32 v47, 0xffff, v37                             // 000000A661CC: 365E4AFF 0000FFFF
	.long 0xd72c002a                                           // 000000A661D4: D72C002A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v42, vcc_lo              // 000000A661D8: 020254FF 83DCD12D
	v_bfe_u32 v48, v37, 8, 16                                  // 000000A661E0: D6100030 02411125
	v_bfe_u32 v37, v37, 4, 16                                  // 000000A661E8: D6100025 02410925
	v_bfe_u32 v49, v43, 12, 16                                 // 000000A661F0: D6100031 0241192B
	.long 0xd72c002f                                           // 000000A661F8: D72C002F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v47, vcc_lo              // 000000A661FC: 02025EFF 83DCD12D
	v_pk_fma_f16 v38, v38, s4, 0xc931 op_sel_hi:[1,0,0]        // 000000A66204: CC0E0026 0BFC0926 0000C931
	.long 0xd72c0030                                           // 000000A66210: D72C0030
	v_cndmask_b32_e32 v1, 0x83dcd12d, v48, vcc_lo              // 000000A66214: 020260FF 83DCD12D
	.long 0xd72c0025                                           // 000000A6621C: D72C0025
	v_cndmask_b32_e32 v1, 0x83dcd12d, v37, vcc_lo              // 000000A66220: 02024AFF 83DCD12D
	v_sad_u8 v42, v42, 0, 0x6400                               // 000000A66228: D622002A 03FD012A 00006400
	v_dot2acc_f32_f16 v21, v41, v2                             // 000000A66234: 042A0529
	.long 0xd72c0031                                           // 000000A66238: D72C0031
	v_cndmask_b32_e32 v1, 0x83dcd12d, v49, vcc_lo              // 000000A6623C: 020262FF 83DCD12D
	v_and_b32_e32 v43, 0xffff, v43                             // 000000A66244: 365656FF 0000FFFF
	v_sad_u8 v47, v47, 0, 0x6400                               // 000000A6624C: D622002F 03FD012F 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000A66258: BF870234
	v_dual_dot2acc_f32_f16 v21, v38, v3 :: v_dual_and_b32 v42, 0xffff, v42// 000000A6625C: CB240726 152A54FF 0000FFFF
	v_sad_u8 v48, v48, 0, 0x6400                               // 000000A66268: D6220030 03FD0130 00006400
	v_sad_u8 v37, v37, 0, 0x6400                               // 000000A66274: D6220025 03FD0125 00006400
	v_lshlrev_b32_e32 v47, 16, v47                             // 000000A66280: 305E5E90
	v_sad_u8 v49, v49, 0, 0x6400                               // 000000A66284: D6220031 03FD0131 00006400
	.long 0xd72c002b                                           // 000000A66290: D72C002B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v43, vcc_lo              // 000000A66294: 020256FF 83DCD12D
	v_lshl_or_b32 v42, v48, 16, v42                            // 000000A6629C: D656002A 04A92130
	v_sad_u8 v39, v39, 0, 0x6400                               // 000000A662A4: D6220027 03FD0127 00006400
	v_and_or_b32 v37, 0xffff, v37, v47                         // 000000A662B0: D6570025 04BE4AFF 0000FFFF
	.long 0xd72c002f                                           // 000000A662BC: D72C002F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v51, vcc_lo              // 000000A662C0: 020266FF 83DCD12D
	v_dot2acc_f32_f16 v22, v44, v4                             // 000000A662C8: 042C092C
	v_pk_fma_f16 v42, v42, s4, 0xc931 op_sel_hi:[1,0,0]        // 000000A662CC: CC0E002A 0BFC092A 0000C931
	v_lshlrev_b32_e32 v39, 16, v39                             // 000000A662D8: 304E4E90
	v_pk_fma_f16 v37, v37, s4, 0xc931 op_sel_hi:[1,0,0]        // 000000A662DC: CC0E0025 0BFC0925 0000C931
	v_sad_u8 v40, v43, 0, 0x6400                               // 000000A662E8: D6220028 03FD012B 00006400
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A662F4: BF870004
	v_dot2acc_f32_f16 v11, v42, v1                             // 000000A662F8: 0416032A
	v_and_b32_e32 v48, 0xffff, v49                             // 000000A662FC: 366062FF 0000FFFF
	v_sad_u8 v49, v50, 0, 0x6400                               // 000000A66304: D6220031 03FD0132 00006400
	v_sad_u8 v47, v47, 0, 0x6400                               // 000000A66310: D622002F 03FD012F 00006400
	v_and_or_b32 v1, 0xffff, v46, v39                          // 000000A6631C: D6570001 049E5CFF 0000FFFF
	v_dot2acc_f32_f16 v11, v37, v2                             // 000000A66328: 04160525
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A6632C: BF870194
	v_lshl_or_b32 v43, v49, 16, v48                            // 000000A66330: D656002B 04C12131
	v_pk_fma_f16 v1, v1, s4, 0xc931 op_sel_hi:[1,0,0]          // 000000A66338: CC0E0001 0BFC0901 0000C931
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000A66344: BF8701A2
	v_pk_fma_f16 v39, v43, s4, 0xc931 op_sel_hi:[1,0,0]        // 000000A66348: CC0E0027 0BFC092B 0000C931
	v_lshlrev_b32_e32 v40, 16, v40                             // 000000A66354: 30505090
	v_dot2acc_f32_f16 v21, v1, v4                              // 000000A66358: 042A0901
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A6635C: BF870193
	v_dot2acc_f32_f16 v11, v39, v3                             // 000000A66360: 04160727
	v_and_or_b32 v40, 0xffff, v47, v40                         // 000000A66364: D6570028 04A25EFF 0000FFFF
	v_add_nc_u32_e32 v3, v29, v30                              // 000000A66370: 4A063D1D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A66374: BF870112
	v_pk_fma_f16 v2, v40, s4, 0xc931 op_sel_hi:[1,0,0]         // 000000A66378: CC0E0002 0BFC0928 0000C931
	v_cmp_eq_u32_e32 vcc_lo, 6, v3                             // 000000A66384: 7C940686
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000A66388: BF8704A2
	v_dot2acc_f32_f16 v11, v2, v4                              // 000000A6638C: 04160902
	s_or_b32 s2, vcc_lo, s2                                    // 000000A66390: 8C02026A
	s_and_not1_b32 exec_lo, exec_lo, s2                        // 000000A66394: 917E027E
	s_cbranch_execz 34                                         // 000000A66398: BFA50022 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_tILi4ELi8ELi0ELb0EEEvPKjPKDF16_PKiS5_PtNS0_6HtFoldE+0x1124>
	s_mov_b32 s0, exec_lo                                      // 000000A6639C: BE80007E
	s_waitcnt vmcnt(6)                                         // 000000A663A0: BF891BF7
	ds_store_2addr_b32 v31, v12, v13 offset0:64 offset1:96     // 000000A663A4: D8386040 000D0C1F
	s_waitcnt vmcnt(4)                                         // 000000A663AC: BF8913F7
	ds_store_2addr_b32 v31, v14, v16 offset0:128 offset1:160   // 000000A663B0: D838A080 00100E1F
	s_waitcnt vmcnt(2)                                         // 000000A663B8: BF890BF7
	ds_store_2addr_b32 v31, v17, v18 offset0:192 offset1:224   // 000000A663BC: D838E0C0 0012111F
	s_waitcnt vmcnt(0)                                         // 000000A663C4: BF8903F7
	ds_store_2addr_b32 v32, v19, v20 offset1:32                // 000000A663C8: D8382000 00141320
	.long 0xd4c9007e                                           // 000000A663D0: D4C9007E
	v_cndmask_b32_e32 v1, v30, v10, vcc_lo                     // 000000A663D4: 0202151E
	s_cbranch_execz 64647                                      // 000000A663D8: BFA5FC87 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_tILi4ELi8ELi0ELb0EEEvPKjPKDF16_PKiS5_PtNS0_6HtFoldE+0x2f8>
	s_clause 0x7                                               // 000000A663DC: BF850007
	global_load_b32 v12, v[5:6], off                           // 000000A663E0: DC520000 0C7C0005
	global_load_b32 v13, v[5:6], off offset:128                // 000000A663E8: DC520080 0D7C0005
	global_load_b32 v14, v[5:6], off offset:256                // 000000A663F0: DC520100 0E7C0005
	global_load_b32 v16, v[5:6], off offset:384                // 000000A663F8: DC520180 107C0005
	global_load_b32 v17, v[5:6], off offset:512                // 000000A66400: DC520200 117C0005
	global_load_b32 v18, v[5:6], off offset:640                // 000000A66408: DC520280 127C0005
	global_load_b32 v19, v[5:6], off offset:768                // 000000A66410: DC520300 137C0005
	global_load_b32 v20, v[5:6], off offset:896                // 000000A66418: DC520380 147C0005
	s_branch 64629                                             // 000000A66420: BFA0FC75 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_tILi4ELi8ELi0ELb0EEEvPKjPKDF16_PKiS5_PtNS0_6HtFoldE+0x2f8>
	s_or_b32 exec_lo, exec_lo, s2                              // 000000A66424: 8C7E027E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A66428: BF870099
	s_or_b32 exec_lo, exec_lo, s1                              // 000000A6642C: 8C7E017E
	v_dual_mov_b32 v1, v15 :: v_dual_mov_b32 v2, v26           // 000000A66430: CA10010F 0102011A
	v_dual_mov_b32 v3, v25 :: v_dual_mov_b32 v10, v24          // 000000A66438: CA100119 030A0118
	v_dual_mov_b32 v4, v23 :: v_dual_mov_b32 v5, v22           // 000000A66440: CA100117 04040116
	v_mov_b32_e32 v6, v21                                      // 000000A66448: 7E0C0315
	s_waitcnt vmcnt(7)                                         // 000000A6644C: BF891FF7
	v_mov_b32_e32 v12, v11                                     // 000000A66450: 7E18030B
	s_mov_b32 s0, 0x76543210                                   // 000000A66454: BE8000FF 76543210
	v_cmp_gt_u32_e32 vcc_lo, 16, v8                            // 000000A6645C: 7C981090
	v_permlanex16_b32 v1, v1, s0, 0xfedcba98                   // 000000A66460: D65C0001 03FC0101 FEDCBA98
	v_permlanex16_b32 v2, v2, s0, 0xfedcba98                   // 000000A6646C: D65C0002 03FC0102 FEDCBA98
	v_permlanex16_b32 v3, v3, s0, 0xfedcba98                   // 000000A66478: D65C0003 03FC0103 FEDCBA98
	v_permlanex16_b32 v10, v10, s0, 0xfedcba98                 // 000000A66484: D65C000A 03FC010A FEDCBA98
	v_permlanex16_b32 v4, v4, s0, 0xfedcba98                   // 000000A66490: D65C0004 03FC0104 FEDCBA98
	v_permlanex16_b32 v5, v5, s0, 0xfedcba98                   // 000000A6649C: D65C0005 03FC0105 FEDCBA98
	v_permlanex16_b32 v6, v6, s0, 0xfedcba98                   // 000000A664A8: D65C0006 03FC0106 FEDCBA98
	v_permlanex16_b32 v12, v12, s0, 0xfedcba98                 // 000000A664B4: D65C000C 03FC010C FEDCBA98
	s_waitcnt vmcnt(0)                                         // 000000A664C0: BF8903F7
	s_barrier                                                  // 000000A664C4: BFBD0000
	buffer_gl0_inv                                             // 000000A664C8: E0AC0000 00000000
	s_and_saveexec_b32 s0, vcc_lo                              // 000000A664D0: BE80206A
	s_cbranch_execz 18                                         // 000000A664D4: BFA50012 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_tILi4ELi8ELi0ELb0EEEvPKjPKDF16_PKiS5_PtNS0_6HtFoldE+0x1220>
	v_dual_add_f32 v1, v15, v1 :: v_dual_add_f32 v2, v26, v2   // 000000A664D8: C908030F 0102051A
	v_lshl_or_b32 v9, v7, 9, v9                                // 000000A664E0: D6560009 04251307
	v_dual_add_f32 v8, v11, v12 :: v_dual_add_f32 v3, v25, v3  // 000000A664E8: C908190B 08020719
	v_dual_add_f32 v10, v24, v10 :: v_dual_add_f32 v5, v22, v5 // 000000A664F0: C9081518 0A040B16
	v_add_f32_e32 v4, v23, v4                                  // 000000A664F8: 06080917
	v_add_f32_e32 v6, v21, v6                                  // 000000A664FC: 060C0D15
	ds_store_2addr_b32 v9, v1, v2 offset1:16                   // 000000A66500: D8381000 00020109
	ds_store_2addr_b32 v9, v3, v10 offset0:32 offset1:48       // 000000A66508: D8383020 000A0309
	ds_store_2addr_b32 v9, v4, v5 offset0:64 offset1:80        // 000000A66510: D8385040 00050409
	ds_store_2addr_b32 v9, v6, v8 offset0:96 offset1:112       // 000000A66518: D8387060 00080609
	s_or_b32 exec_lo, exec_lo, s0                              // 000000A66520: 8C7E007E
	s_waitcnt lgkmcnt(0)                                       // 000000A66524: BF89FC07
	s_barrier                                                  // 000000A66528: BFBD0000
	buffer_gl0_inv                                             // 000000A6652C: E0AC0000 00000000
	s_mov_b32 s1, exec_lo                                      // 000000A66534: BE81007E
	v_cmpx_eq_u32_e32 0, v7                                    // 000000A66538: 7D940E80
	s_cbranch_execz 510                                        // 000000A6653C: BFA501FE <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_tILi4ELi8ELi0ELb0EEEvPKjPKDF16_PKiS5_PtNS0_6HtFoldE+0x1a38>
	v_and_b32_e32 v1, 15, v0                                   // 000000A66540: 3602008F
	s_delay_alu instid0(VALU_DEP_1)                            // 000000A66544: BF870001
	v_lshlrev_b32_e32 v16, 2, v1                               // 000000A66548: 30200282
	ds_load_2addr_b32 v[2:3], v16 offset1:16                   // 000000A6654C: D8DC1000 02000010
	ds_load_2addr_b32 v[4:5], v16 offset0:128 offset1:144      // 000000A66554: D8DC9080 04000010
	s_waitcnt lgkmcnt(1)                                       // 000000A6655C: BF89FC17
	v_dual_add_f32 v53, 0, v3 :: v_dual_add_f32 v52, 0, v2     // 000000A66560: C9080680 35340480
	v_add_nc_u32_e32 v48, 0x400, v16                           // 000000A66568: 4A6020FF 00000400
	v_add_nc_u32_e32 v50, 0x800, v16                           // 000000A66570: 4A6420FF 00000800
	v_add_nc_u32_e32 v51, 0xc00, v16                           // 000000A66578: 4A6620FF 00000C00
	s_waitcnt lgkmcnt(0)                                       // 000000A66580: BF89FC07
	v_add_f32_e32 v53, v53, v5                                 // 000000A66584: 066A0B35
	ds_load_2addr_b32 v[6:7], v16 offset0:32 offset1:48        // 000000A66588: D8DC3020 06000010
	ds_load_2addr_b32 v[8:9], v16 offset0:160 offset1:176      // 000000A66590: D8DCB0A0 08000010
	ds_load_2addr_b32 v[10:11], v16 offset0:64 offset1:80      // 000000A66598: D8DC5040 0A000010
	ds_load_2addr_b32 v[12:13], v16 offset0:192 offset1:208    // 000000A665A0: D8DCD0C0 0C000010
	ds_load_2addr_b32 v[14:15], v16 offset0:96 offset1:112     // 000000A665A8: D8DC7060 0E000010
	ds_load_2addr_b32 v[16:17], v16 offset0:224 offset1:240    // 000000A665B0: D8DCF0E0 10000010
	ds_load_2addr_b32 v[18:19], v48 offset1:16                 // 000000A665B8: D8DC1000 12000030
	ds_load_2addr_b32 v[20:21], v48 offset0:128 offset1:144    // 000000A665C0: D8DC9080 14000030
	ds_load_2addr_b32 v[22:23], v50 offset1:16                 // 000000A665C8: D8DC1000 16000032
	ds_load_2addr_b32 v[24:25], v50 offset0:128 offset1:144    // 000000A665D0: D8DC9080 18000032
	ds_load_2addr_b32 v[26:27], v51 offset1:16                 // 000000A665D8: D8DC1000 1A000033
	ds_load_2addr_b32 v[28:29], v51 offset0:128 offset1:144    // 000000A665E0: D8DC9080 1C000033
	ds_load_2addr_b32 v[30:31], v48 offset0:32 offset1:48      // 000000A665E8: D8DC3020 1E000030
	ds_load_2addr_b32 v[32:33], v48 offset0:160 offset1:176    // 000000A665F0: D8DCB0A0 20000030
	ds_load_2addr_b32 v[34:35], v50 offset0:32 offset1:48      // 000000A665F8: D8DC3020 22000032
	ds_load_2addr_b32 v[36:37], v50 offset0:160 offset1:176    // 000000A66600: D8DCB0A0 24000032
	ds_load_2addr_b32 v[38:39], v51 offset0:32 offset1:48      // 000000A66608: D8DC3020 26000033
	ds_load_2addr_b32 v[40:41], v51 offset0:160 offset1:176    // 000000A66610: D8DCB0A0 28000033
	ds_load_2addr_b32 v[42:43], v48 offset0:64 offset1:80      // 000000A66618: D8DC5040 2A000030
	ds_load_2addr_b32 v[44:45], v48 offset0:192 offset1:208    // 000000A66620: D8DCD0C0 2C000030
	ds_load_2addr_b32 v[46:47], v50 offset0:64 offset1:80      // 000000A66628: D8DC5040 2E000032
	s_waitcnt lgkmcnt(20)                                      // 000000A66630: BF89FD47
	v_add_f32_e32 v6, 0, v6                                    // 000000A66634: 060C0C80
	s_waitcnt lgkmcnt(18)                                      // 000000A66638: BF89FD27
	v_dual_add_f32 v52, v52, v4 :: v_dual_add_f32 v11, 0, v11  // 000000A6663C: C9080934 340A1680
	ds_load_2addr_b32 v[2:3], v48 offset0:96 offset1:112       // 000000A66644: D8DC7060 02000030
	ds_load_2addr_b32 v[48:49], v48 offset0:224 offset1:240    // 000000A6664C: D8DCF0E0 30000030
	v_dual_add_f32 v7, 0, v7 :: v_dual_add_f32 v6, v6, v8      // 000000A66654: C9080E80 07061106
	s_waitcnt lgkmcnt(16)                                      // 000000A6665C: BF89FD07
	v_dual_add_f32 v15, 0, v15 :: v_dual_add_f32 v8, v52, v18  // 000000A66660: C9081E80 0F082534
	v_add_f32_e32 v10, 0, v10                                  // 000000A66668: 06141480
	ds_load_2addr_b32 v[4:5], v50 offset0:96 offset1:112       // 000000A6666C: D8DC7060 04000032
	v_add_f32_e32 v18, v53, v19                                // 000000A66674: 06242735
	v_dual_add_f32 v14, 0, v14 :: v_dual_add_f32 v7, v7, v9    // 000000A66678: C9081C80 0E061307
	s_waitcnt lgkmcnt(11)                                      // 000000A66680: BF89FCB7
	v_add_f32_e32 v6, v6, v30                                  // 000000A66684: 060C3D06
	v_add_f32_e32 v9, v10, v12                                 // 000000A66688: 0612190A
	v_add_f32_e32 v8, v8, v20                                  // 000000A6668C: 06102908
	v_add_f32_e32 v12, v11, v13                                // 000000A66690: 06181B0B
	v_dual_add_f32 v18, v18, v21 :: v_dual_add_f32 v7, v7, v31 // 000000A66694: C9082B12 12063F07
	s_waitcnt lgkmcnt(5)                                       // 000000A6669C: BF89FC57
	v_add_f32_e32 v9, v9, v42                                  // 000000A666A0: 06125509
	v_dual_add_f32 v8, v8, v22 :: v_dual_add_f32 v13, v14, v16 // 000000A666A4: C9082D08 080C210E
	v_dual_add_f32 v14, v15, v17 :: v_dual_add_f32 v15, v12, v43// 000000A666AC: C908230F 0E0E570C
	v_add_f32_e32 v6, v6, v32                                  // 000000A666B4: 060C4106
	s_delay_alu instid0(VALU_DEP_3)                            // 000000A666B8: BF870003
	v_add_f32_e32 v8, v8, v24                                  // 000000A666BC: 06103108
	s_waitcnt lgkmcnt(4)                                       // 000000A666C0: BF89FC47
	v_add_f32_e32 v19, v9, v44                                 // 000000A666C4: 06265909
	s_waitcnt lgkmcnt(2)                                       // 000000A666C8: BF89FC27
	v_add_f32_e32 v17, v14, v3                                 // 000000A666CC: 0622070E
	v_dual_add_f32 v18, v18, v23 :: v_dual_add_f32 v23, v15, v45// 000000A666D0: C9082F12 12165B0F
	v_add_f32_e32 v6, v6, v34                                  // 000000A666D8: 060C4506
	v_add_f32_e32 v16, v13, v2                                 // 000000A666DC: 0620050D
	s_waitcnt lgkmcnt(1)                                       // 000000A666E0: BF89FC17
	v_add_f32_e32 v17, v17, v49                                // 000000A666E4: 06226311
	v_dual_add_f32 v10, v18, v25 :: v_dual_add_f32 v19, v19, v46// 000000A666E8: C9083312 0A125D13
	v_dual_add_f32 v23, v23, v47 :: v_dual_add_f32 v6, v6, v36 // 000000A666F0: C9085F17 17064906
	s_waitcnt lgkmcnt(0)                                       // 000000A666F8: BF89FC07
	s_delay_alu instid0(VALU_DEP_3)                            // 000000A666FC: BF870003
	v_add_f32_e32 v5, v17, v5                                  // 000000A66700: 060A0B11
	ds_load_2addr_b32 v[2:3], v51 offset0:192 offset1:208      // 000000A66704: D8DCD0C0 02000033
	ds_load_2addr_b32 v[14:15], v51 offset0:224 offset1:240    // 000000A6670C: D8DCF0E0 0E000033
	v_add_f32_e32 v18, v7, v33                                 // 000000A66714: 06244307
	v_add_f32_e32 v6, v6, v38                                  // 000000A66718: 060C4D06
	ds_load_2addr_b32 v[12:13], v51 offset0:96 offset1:112     // 000000A6671C: D8DC7060 0C000033
	v_add_f32_e32 v22, v6, v40                                 // 000000A66724: 062C5106
	ds_load_2addr_b32 v[6:7], v50 offset0:192 offset1:208      // 000000A66728: D8DCD0C0 06000032
	s_waitcnt lgkmcnt(0)                                       // 000000A66730: BF89FC07
	v_dual_add_f32 v8, v8, v26 :: v_dual_add_f32 v7, v23, v7   // 000000A66734: C9083508 08060F17
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000A6673C: BF8700C1
	v_add_f32_e32 v20, v8, v28                                 // 000000A66740: 06283908
	ds_load_2addr_b32 v[8:9], v50 offset0:224 offset1:240      // 000000A66744: D8DCF0E0 08000032
	s_waitcnt lgkmcnt(0)                                       // 000000A6674C: BF89FC07
	v_dual_add_f32 v10, v10, v27 :: v_dual_add_f32 v5, v5, v9  // 000000A66750: C908370A 0A041305
	v_add_f32_e32 v21, v10, v29                                // 000000A66758: 062A3B0A
	ds_load_2addr_b32 v[10:11], v51 offset0:64 offset1:80      // 000000A6675C: D8DC5040 0A000033
	v_add_f32_e32 v5, v5, v13                                  // 000000A66764: 060A1B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000A66768: BF8700A1
	v_dual_add_f32 v5, v5, v15 :: v_dual_add_f32 v6, v19, v6   // 000000A6676C: C9081F05 05060D13
	s_waitcnt lgkmcnt(0)                                       // 000000A66774: BF89FC07
	v_dual_add_f32 v6, v6, v10 :: v_dual_add_f32 v7, v7, v11   // 000000A66778: C9081506 06061707
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000A66780: BF8701B1
	v_dual_add_f32 v2, v6, v2 :: v_dual_add_f32 v3, v7, v3     // 000000A66784: C9080506 02020707
	v_sub_f32_e32 v7, v20, v21                                 // 000000A6678C: 080E2B14
	v_add_f32_e32 v6, v20, v21                                 // 000000A66790: 060C2B14
	v_add_f32_e32 v10, v2, v3                                  // 000000A66794: 06140702
	v_sub_f32_e32 v2, v2, v3                                   // 000000A66798: 08040702
	v_add_f32_e32 v16, v16, v48                                // 000000A6679C: 06206110
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A667A0: BF870091
	v_add_f32_e32 v4, v16, v4                                  // 000000A667A4: 06080910
	v_add_f32_e32 v4, v4, v8                                   // 000000A667A8: 06081104
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A667AC: BF870091
	v_add_f32_e32 v4, v4, v12                                  // 000000A667B0: 06081904
	v_add_f32_e32 v4, v4, v14                                  // 000000A667B4: 06081D04
	v_add_f32_e32 v18, v18, v35                                // 000000A667B8: 06244712
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A667BC: BF870112
	v_dual_add_f32 v11, v4, v5 :: v_dual_and_b32 v14, 1, v0    // 000000A667C0: C9240B04 0B0E0081
	v_add_f32_e32 v16, v18, v37                                // 000000A667C8: 06204B12
	v_sub_f32_e32 v3, v4, v5                                   // 000000A667CC: 08060B04
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A667D0: BF870213
	.long 0xd44a0000                                           // 000000A667D4: D44A0000
	v_cndmask_b32_e32 v1, 0, v14, vcc_lo                       // 000000A667D8: 02021C80
	v_add_f32_e32 v5, v10, v11                                 // 000000A667DC: 060A170A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A667E0: BF870214
	v_add_f32_e32 v8, v16, v39                                 // 000000A667E4: 06104F10
	v_add_f32_e32 v13, v2, v3                                  // 000000A667E8: 061A0702
	v_dual_sub_f32 v2, v2, v3 :: v_dual_and_b32 v3, 2, v0      // 000000A667EC: C9640702 02020082
	v_sub_f32_e32 v10, v10, v11                                // 000000A667F4: 0814170A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A667F8: BF870194
	v_add_f32_e32 v8, v8, v41                                  // 000000A667FC: 06105308
	.long 0xd44a0001                                           // 000000A66800: D44A0001
	v_cndmask_b32_e32 v1, 0, v3, vcc_lo                        // 000000A66804: 02020680
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000A66808: BF870122
	v_add_f32_e32 v9, v22, v8                                  // 000000A6680C: 06121116
	v_sub_f32_e32 v8, v22, v8                                  // 000000A66810: 08101116
	v_add_f32_e32 v4, v6, v9                                   // 000000A66814: 06081306
	v_sub_f32_e32 v6, v6, v9                                   // 000000A66818: 080C1306
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000A6681C: BF8701A2
	v_dual_add_f32 v12, v7, v8 :: v_dual_add_f32 v9, v4, v5    // 000000A66820: C9081107 0C080B04
	v_sub_f32_e32 v5, v4, v5                                   // 000000A66828: 080A0B04
	v_add_f32_e32 v3, v6, v10                                  // 000000A6682C: 06061506
	v_sub_f32_e32 v10, v6, v10                                 // 000000A66830: 08141506
	v_and_b32_e32 v6, 4, v0                                    // 000000A66834: 360C0084
	v_mov_b32_dpp v11, v9 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A66838: 7E1602FA FF016109
	v_cndmask_b32_e64 v9, -v9, v9, s0                          // 000000A66840: D5010009 20021309
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A66848: BF870113
	.long 0xd44a0002                                           // 000000A6684C: D44A0002
	v_cndmask_b32_e32 v1, 0, v6, vcc_lo                        // 000000A66850: 02020C80
	v_dual_add_f32 v4, v9, v11 :: v_dual_sub_f32 v9, v12, v13  // 000000A66854: C90A1709 04081B0C
	v_dual_sub_f32 v7, v7, v8 :: v_dual_add_f32 v8, v12, v13   // 000000A6685C: C9481107 07081B0C
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000A66864: BF8701A2
	v_mov_b32_dpp v11, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A66868: 7E1602FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, s1                          // 000000A66870: D5010004 20060904
	v_add_f32_e32 v13, v7, v2                                  // 000000A66878: 061A0507
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000A6687C: BF870224
	v_mov_b32_dpp v14, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A66880: 7E1C02FA FF016108
	v_cndmask_b32_e64 v8, -v8, v8, s0                          // 000000A66888: D5010008 20021108
	v_dual_sub_f32 v7, v7, v2 :: v_dual_add_f32 v4, v4, v11    // 000000A66890: C9480507 07041704
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A66898: BF870194
	v_mov_b32_dpp v11, v13 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A6689C: 7E1602FA FF01610D
	v_add_f32_e32 v8, v8, v14                                  // 000000A668A4: 06101D08
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000A668A8: BF8701A3
	v_mov_b32_dpp v6, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A668AC: 7E0C02FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s2                          // 000000A668B4: D5010004 200A0904
	v_mov_b32_dpp v12, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A668BC: 7E1802FA FF016208
	v_cndmask_b32_e64 v8, -v8, v8, s1                          // 000000A668C4: D5010008 20061108
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000A668CC: BF8701C1
	v_add_f32_e32 v8, v8, v12                                  // 000000A668D0: 06101908
	v_cndmask_b32_e64 v12, -v13, v13, s0                       // 000000A668D4: D501000C 20021B0D
	v_mov_b32_dpp v13, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A668DC: 7E1A02FA FF016103
	v_cndmask_b32_e64 v3, -v3, v3, s0                          // 000000A668E4: D5010003 20020703
	v_add_f32_e32 v11, v12, v11                                // 000000A668EC: 0616170C
	v_mov_b32_dpp v12, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A668F0: 7E1802FA FF016408
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000A668F8: BF870223
	v_add_f32_e32 v3, v3, v13                                  // 000000A668FC: 06061B03
	v_cndmask_b32_e64 v8, -v8, v8, s2                          // 000000A66900: D5010008 200A1108
	v_mov_b32_dpp v13, v11 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A66908: 7E1A02FA FF01620B
	v_cndmask_b32_e64 v11, -v11, v11, s1                       // 000000A66910: D501000B 2006170B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 000000A66918: BF870254
	v_mov_b32_dpp v14, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A6691C: 7E1C02FA FF016203
	v_cndmask_b32_e64 v15, -v3, v3, s1                         // 000000A66924: D501000F 20060703
	v_add_f32_e32 v3, v4, v6                                   // 000000A6692C: 06060D04
	v_add_f32_e32 v6, v8, v12                                  // 000000A66930: 060C1908
	v_add_f32_e32 v8, v11, v13                                 // 000000A66934: 06101B0B
	v_add_f32_e32 v11, v15, v14                                // 000000A66938: 06161D0F
	v_mov_b32_dpp v14, v5 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A6693C: 7E1C02FA FF016105
	v_cndmask_b32_e64 v15, -v5, v5, s0                         // 000000A66944: D501000F 20020B05
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A6694C: BF870004
	v_mov_b32_dpp v12, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A66950: 7E1802FA FF016408
	v_cndmask_b32_e64 v8, -v8, v8, s2                          // 000000A66958: D5010008 200A1108
	v_mov_b32_dpp v13, v11 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A66960: 7E1A02FA FF01640B
	v_cndmask_b32_e64 v11, -v11, v11, s2                       // 000000A66968: D501000B 200A170B
	v_mov_b32_dpp v2, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A66970: 7E0402FA FF016803
	v_mov_b32_dpp v4, v6 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A66978: 7E0802FA FF016806
	v_add_f32_e32 v5, v8, v12                                  // 000000A66980: 060A1908
	v_mov_b32_dpp v8, v9 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A66984: 7E1002FA FF016109
	v_cndmask_b32_e64 v9, -v9, v9, s0                          // 000000A6698C: D5010009 20021309
	v_add_f32_e32 v12, v15, v14                                // 000000A66994: 06181D0F
	v_mov_b32_dpp v14, v10 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A66998: 7E1C02FA FF01610A
	v_cndmask_b32_e64 v10, -v10, v10, s0                       // 000000A669A0: D501000A 2002150A
	v_mov_b32_dpp v15, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A669A8: 7E1E02FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, s0                          // 000000A669B0: D5010007 20020F07
	v_add_f32_e32 v8, v9, v8                                   // 000000A669B8: 06101109
	v_mov_b32_dpp v9, v12 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A669BC: 7E1202FA FF01620C
	v_cndmask_b32_e64 v12, -v12, v12, s1                       // 000000A669C4: D501000C 2006190C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A669CC: BF870214
	v_dual_add_f32 v10, v10, v14 :: v_dual_add_f32 v7, v7, v15 // 000000A669D0: C9081D0A 0A061F07
	v_mov_b32_dpp v14, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A669D8: 7E1C02FA FF016208
	v_cndmask_b32_e64 v8, -v8, v8, s1                          // 000000A669E0: D5010008 20061108
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A669E8: BF870214
	v_add_f32_e32 v9, v12, v9                                  // 000000A669EC: 0612130C
	v_mov_b32_dpp v12, v10 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A669F0: 7E1802FA FF01620A
	v_mov_b32_dpp v15, v7 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A669F8: 7E1E02FA FF016207
	v_cndmask_b32_e64 v10, -v10, v10, s1                       // 000000A66A00: D501000A 2006150A
	v_cndmask_b32_e64 v16, -v7, v7, s1                         // 000000A66A08: D5010010 20060F07
	v_dual_add_f32 v8, v8, v14 :: v_dual_add_f32 v7, v11, v13  // 000000A66A10: C9081D08 08061B0B
	v_mov_b32_dpp v11, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A66A18: 7E1602FA FF016409
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A66A20: BF870214
	v_add_f32_e32 v10, v10, v12                                // 000000A66A24: 0614190A
	v_add_f32_e32 v12, v16, v15                                // 000000A66A28: 06181F10
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A66A2C: BF870004
	v_mov_b32_dpp v13, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A66A30: 7E1A02FA FF016408
	v_cndmask_b32_e64 v15, -v8, v8, s2                         // 000000A66A38: D501000F 200A1108
	v_cndmask_b32_e64 v9, -v9, v9, s2                          // 000000A66A40: D5010009 200A1309
	v_mov_b32_dpp v17, v10 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A66A48: 7E2202FA FF01640A
	v_mov_b32_dpp v18, v12 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A66A50: 7E2402FA FF01640C
	v_cndmask_b32_e64 v10, -v10, v10, s2                       // 000000A66A58: D501000A 200A150A
	v_cndmask_b32_e64 v12, -v12, v12, s2                       // 000000A66A60: D501000C 200A190C
	v_add_f32_e32 v14, v9, v11                                 // 000000A66A68: 061C1709
	v_add_f32_e32 v16, v15, v13                                // 000000A66A6C: 06201B0F
	v_mov_b32_dpp v8, v7 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A66A70: 7E1002FA FF016807
	v_add_f32_e32 v15, v10, v17                                // 000000A66A78: 061E230A
	v_add_f32_e32 v17, v12, v18                                // 000000A66A7C: 0622250C
	v_mov_b32_dpp v9, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A66A80: 7E1202FA FF016805
	v_mov_b32_dpp v10, v14 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A66A88: 7E1402FA FF01680E
	v_mov_b32_dpp v11, v16 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A66A90: 7E1602FA FF016810
	v_mov_b32_dpp v12, v15 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A66A98: 7E1802FA FF01680F
	v_mov_b32_dpp v13, v17 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A66AA0: 7E1A02FA FF016811
	s_and_b32 exec_lo, exec_lo, vcc_lo                         // 000000A66AA8: 8B7E6A7E
	s_cbranch_execz 162                                        // 000000A66AAC: BFA500A2 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_tILi4ELi8ELi0ELb0EEEvPKjPKDF16_PKiS5_PtNS0_6HtFoldE+0x1a38>
	v_and_b32_e32 v0, 8, v0                                    // 000000A66AB0: 36000088
	s_mul_i32 s0, s3, 0x1400                                   // 000000A66AB4: 9600FF03 00001400
	s_mul_hi_i32 s1, s3, 0x1400                                // 000000A66ABC: 9701FF03 00001400
	s_add_u32 s2, s10, s0                                      // 000000A66AC4: 8002000A
	s_addc_u32 s3, s11, s1                                     // 000000A66AC8: 8203010B
	v_cmp_eq_u32_e32 vcc_lo, 0, v0                             // 000000A66ACC: 7C940080
	s_lshl_b32 s0, s6, 7                                       // 000000A66AD0: 84008706
	.long 0x7f243880                                           // 000000A66AD4: 7F243880
	s_ashr_i32 s1, s0, 31                                      // 000000A66AD8: 86019F00
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000A66ADC: BF870009
	s_lshl_b64 s[0:1], s[0:1], 1                               // 000000A66AE0: 84808100
	v_cndmask_b32_e64 v0, -v6, v6, vcc_lo                      // 000000A66AE4: D5010000 21AA0D06
	v_lshlrev_b32_e32 v1, 1, v1                                // 000000A66AEC: 30020281
	s_add_u32 s2, s2, s0                                       // 000000A66AF0: 80020002
	s_addc_u32 s3, s3, s1                                      // 000000A66AF4: 82030103
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 000000A66AF8: D5010003 21AA0703
	v_add_f32_e32 v0, v0, v4                                   // 000000A66B00: 06000900
	s_clause 0x7                                               // 000000A66B04: BF850007
	global_load_d16_b16 v18, v1, s[2:3] offset:32              // 000000A66B08: DC820020 12020001
	global_load_d16_b16 v19, v1, s[2:3]                        // 000000A66B10: DC820000 13020001
	global_load_d16_b16 v20, v1, s[2:3] offset:64              // 000000A66B18: DC820040 14020001
	global_load_d16_b16 v21, v1, s[2:3] offset:96              // 000000A66B20: DC820060 15020001
	global_load_d16_b16 v22, v1, s[2:3] offset:128             // 000000A66B28: DC820080 16020001
	global_load_d16_b16 v23, v1, s[2:3] offset:160             // 000000A66B30: DC8200A0 17020001
	global_load_d16_b16 v24, v1, s[2:3] offset:192             // 000000A66B38: DC8200C0 18020001
	global_load_d16_b16 v25, v1, s[2:3] offset:224             // 000000A66B40: DC8200E0 19020001
	v_cndmask_b32_e64 v4, -v5, v5, vcc_lo                      // 000000A66B48: D5010004 21AA0B05
	v_cndmask_b32_e64 v5, -v7, v7, vcc_lo                      // 000000A66B50: D5010005 21AA0F07
	v_cndmask_b32_e64 v7, -v16, v16, vcc_lo                    // 000000A66B58: D5010007 21AA2110
	v_cndmask_b32_e64 v14, -v14, v14, vcc_lo                   // 000000A66B60: D501000E 21AA1D0E
	v_add_f32_e32 v2, v3, v2                                   // 000000A66B68: 06040503
	v_mul_f32_e32 v0, 0x3db504f3, v0                           // 000000A66B6C: 100000FF 3DB504F3
	v_dual_add_f32 v3, v5, v8 :: v_dual_add_f32 v4, v4, v9     // 000000A66B74: C9081105 03041304
	v_cndmask_b32_e64 v16, -v17, v17, vcc_lo                   // 000000A66B7C: D5010010 21AA2311
	v_cndmask_b32_e64 v15, -v15, v15, vcc_lo                   // 000000A66B84: D501000F 21AA1F0F
	v_add_f32_e32 v5, v14, v10                                 // 000000A66B8C: 060A150E
	v_add_f32_e32 v7, v7, v11                                  // 000000A66B90: 060E1707
	v_dual_mul_f32 v3, 0x3db504f3, v3 :: v_dual_mul_f32 v4, 0x3db504f3, v4// 000000A66B94: C8C606FF 030408FF 3DB504F3
	s_waitcnt vmcnt(4)                                         // 000000A66BA0: BF8913F7
	.long 0x7f2a3992                                           // 000000A66BA4: 7F2A3992
	v_dual_add_f32 v8, v15, v12 :: v_dual_add_f32 v9, v16, v13 // 000000A66BA8: C908190F 08081B10
	v_dual_mul_f32 v2, 0x3db504f3, v2 :: v_dual_mul_f32 v7, 0x3db504f3, v7// 000000A66BB0: C8C604FF 02060EFF 3DB504F3
	v_mul_f32_e32 v5, 0x3db504f3, v5                           // 000000A66BBC: 100A0AFF 3DB504F3
	.long 0x7f263992                                           // 000000A66BC4: 7F263992
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A66BC8: BF870004
	v_dual_mul_f32 v9, 0x3db504f3, v9 :: v_dual_mul_f32 v8, 0x3db504f3, v8// 000000A66BCC: C8C612FF 090810FF 3DB504F3
	.long 0x7f283992                                           // 000000A66BD8: 7F283992
	.long 0x7f0c3992                                           // 000000A66BDC: 7F0C3992
	s_mul_i32 s3, s12, 0x1400                                  // 000000A66BE0: 9603FF0C 00001400
	s_mul_hi_i32 s2, s12, 0x1400                               // 000000A66BE8: 9702FF0C 00001400
	s_add_u32 s3, s8, s3                                       // 000000A66BF0: 80030308
	s_addc_u32 s2, s9, s2                                      // 000000A66BF4: 82020209
	s_add_u32 s0, s3, s0                                       // 000000A66BF8: 80000003
	s_addc_u32 s1, s2, s1                                      // 000000A66BFC: 82010102
	v_fma_mix_f32 v0, v18, v0, neg(0) op_sel_hi:[1,0,0]        // 000000A66C00: CC200000 8A020112
	v_fma_mix_f32 v2, v19, v2, neg(0) op_sel_hi:[1,0,0]        // 000000A66C08: CC200002 8A020513
	v_fma_mix_f32 v3, v20, v3, neg(0) op_sel_hi:[1,0,0]        // 000000A66C10: CC200003 8A020714
	v_fma_mix_f32 v4, v21, v4, neg(0) op_sel_hi:[1,0,0]        // 000000A66C18: CC200004 8A020915
	s_waitcnt vmcnt(3)                                         // 000000A66C20: BF890FF7
	v_fma_mix_f32 v5, v22, v5, neg(0) op_sel_hi:[1,0,0]        // 000000A66C24: CC200005 8A020B16
	.long 0x7e243980                                           // 000000A66C2C: 7E243980
	s_waitcnt vmcnt(2)                                         // 000000A66C30: BF890BF7
	v_fma_mix_f32 v7, v23, v7, neg(0) op_sel_hi:[1,0,0]        // 000000A66C34: CC200007 8A020F17
	s_waitcnt vmcnt(1)                                         // 000000A66C3C: BF8907F7
	v_fma_mix_f32 v8, v24, v8, neg(0) op_sel_hi:[1,0,0]        // 000000A66C40: CC200008 8A021118
	s_waitcnt vmcnt(0)                                         // 000000A66C48: BF8903F7
	v_fma_mix_f32 v9, v25, v9, neg(0) op_sel_hi:[1,0,0]        // 000000A66C4C: CC200009 8A021319
	.long 0x7e0c3982                                           // 000000A66C54: 7E0C3982
	v_and_b32_e32 v10, 1, v18                                  // 000000A66C58: 36142481
	.long 0x7e243984                                           // 000000A66C5C: 7E243984
	.long 0x7e263983                                           // 000000A66C60: 7E263983
	.long 0x7e283985                                           // 000000A66C64: 7E283985
	.long 0x7e2a3988                                           // 000000A66C68: 7E2A3988
	v_and_b32_e32 v6, 1, v6                                    // 000000A66C6C: 360C0C81
	v_and_b32_e32 v11, 1, v18                                  // 000000A66C70: 36162481
	.long 0x7e243987                                           // 000000A66C74: 7E243987
	v_and_b32_e32 v12, 1, v19                                  // 000000A66C78: 36182681
	v_and_b32_e32 v13, 1, v20                                  // 000000A66C7C: 361A2881
	v_and_b32_e32 v15, 1, v21                                  // 000000A66C80: 361E2A81
	v_add3_u32 v2, v2, v6, 0x7fff                              // 000000A66C84: D6550002 03FE0D02 00007FFF
	v_and_b32_e32 v14, 1, v18                                  // 000000A66C90: 361C2481
	.long 0x7e243989                                           // 000000A66C94: 7E243989
	v_add3_u32 v0, v0, v10, 0x7fff                             // 000000A66C98: D6550000 03FE1500 00007FFF
	v_add3_u32 v3, v3, v12, 0x7fff                             // 000000A66CA4: D6550003 03FE1903 00007FFF
	v_add3_u32 v4, v4, v11, 0x7fff                             // 000000A66CB0: D6550004 03FE1704 00007FFF
	v_add3_u32 v5, v5, v13, 0x7fff                             // 000000A66CBC: D6550005 03FE1B05 00007FFF
	v_and_b32_e32 v6, 1, v18                                   // 000000A66CC8: 360C2481
	v_add3_u32 v8, v8, v15, 0x7fff                             // 000000A66CCC: D6550008 03FE1F08 00007FFF
	v_add3_u32 v7, v7, v14, 0x7fff                             // 000000A66CD8: D6550007 03FE1D07 00007FFF
	s_delay_alu instid0(VALU_DEP_3)                            // 000000A66CE4: BF870003
	v_add3_u32 v6, v9, v6, 0x7fff                              // 000000A66CE8: D6550006 03FE0D09 00007FFF
	s_clause 0x7                                               // 000000A66CF4: BF850007
	global_store_d16_hi_b16 v1, v2, s[0:1]                     // 000000A66CF8: DC960000 00000201
	global_store_d16_hi_b16 v1, v0, s[0:1] offset:32           // 000000A66D00: DC960020 00000001
	global_store_d16_hi_b16 v1, v3, s[0:1] offset:64           // 000000A66D08: DC960040 00000301
	global_store_d16_hi_b16 v1, v4, s[0:1] offset:96           // 000000A66D10: DC960060 00000401
	global_store_d16_hi_b16 v1, v5, s[0:1] offset:128          // 000000A66D18: DC960080 00000501
	global_store_d16_hi_b16 v1, v7, s[0:1] offset:160          // 000000A66D20: DC9600A0 00000701
	global_store_d16_hi_b16 v1, v8, s[0:1] offset:192          // 000000A66D28: DC9600C0 00000801
	global_store_d16_hi_b16 v1, v6, s[0:1] offset:224          // 000000A66D30: DC9600E0 00000601
	s_endpgm                                                   // 000000A66D38: BFB00000
		...

