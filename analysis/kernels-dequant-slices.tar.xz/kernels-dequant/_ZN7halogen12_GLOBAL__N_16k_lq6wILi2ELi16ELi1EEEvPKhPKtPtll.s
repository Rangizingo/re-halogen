0000000000335500 <_ZN7halogen12_GLOBAL__N_16k_lq6wILi2ELi16ELi1EEEvPKhPKtPtll>:
; _ZN7halogen12_GLOBAL__N_16k_lq6wILi2ELi16ELi1EEEvPKhPKtPtll():
	s_load_b256 s[4:11], s[0:1], null                          // 000000335500: F40C0100 F8000000
	s_mov_b32 s3, 0                                            // 000000335508: BE830080
	v_lshrrev_b32_e32 v1, 4, v0                                // 00000033550C: 32020084
	s_lshl_b64 s[12:13], s[2:3], 4                             // 000000335510: 848C8402
	s_load_b64 s[2:3], s[0:1], 0x20                            // 000000335514: F4040080 F8000020
	v_mov_b32_e32 v9, s13                                      // 00000033551C: 7E12020D
	v_dual_mov_b32 v6, 0 :: v_dual_and_b32 v17, 15, v0         // 000000335520: CA240080 0610008F
	v_or_b32_e32 v8, s12, v1                                   // 000000335528: 3810020C
	v_dual_mov_b32 v4, 0 :: v_dual_mov_b32 v5, 0               // 00000033552C: CA100080 04040080
	v_dual_mov_b32 v7, 0 :: v_dual_mov_b32 v16, 0              // 000000335534: CA100080 07100080
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(SALU_CYCLE_1)// 00000033553C: BF8704D3
	.long 0xd73c0001                                           // 000000335540: D73C0001
	v_cndmask_b32_e32 v1, 4, v8, vcc_lo                        // 000000335544: 02021084
	v_dual_mov_b32 v15, 0 :: v_dual_mov_b32 v36, 0             // 000000335548: CA100080 0F240080
	v_mov_b32_e32 v18, 0                                       // 000000335550: 7E240280
	s_waitcnt lgkmcnt(0)                                       // 000000335554: BF89FC07
	s_ashr_i32 s16, s11, 31                                    // 000000335558: 86109F0B
	s_lshr_b32 s0, s16, 27                                     // 00000033555C: 85009B10
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000335560: BF870009
	s_add_u32 s0, s10, s0                                      // 000000335564: 8000000A
	s_addc_u32 s1, s11, 0                                      // 000000335568: 8201800B
	s_lshr_b32 s14, s11, 31                                    // 00000033556C: 850E9F0B
	s_lshr_b64 s[12:13], s[0:1], 5                             // 000000335570: 858C8500
	s_add_u32 s0, s10, s14                                     // 000000335574: 80000E0A
	s_addc_u32 s1, s11, 0                                      // 000000335578: 8201800B
	s_lshr_b32 s13, s16, 30                                    // 00000033557C: 850D9E10
	s_ashr_i64 s[14:15], s[0:1], 1                             // 000000335580: 868E8100
	s_add_u32 s0, s10, s13                                     // 000000335584: 80000D0A
	s_addc_u32 s1, s11, 0                                      // 000000335588: 8201800B
	s_lshr_b32 s13, s16, 28                                    // 00000033558C: 850D9C10
	s_ashr_i64 s[16:17], s[0:1], 2                             // 000000335590: 86908200
	s_add_u32 s0, s10, s13                                     // 000000335594: 80000D0A
	s_addc_u32 s1, s11, 0                                      // 000000335598: 8201800B
	v_cmp_gt_i64_e32 vcc_lo, s[2:3], v[8:9]                    // 00000033559C: 7CA81002
	s_ashr_i64 s[0:1], s[0:1], 4                               // 0000003355A0: 86808400
	s_add_u32 s13, s16, s14                                    // 0000003355A4: 800D0E10
	s_addc_u32 s18, s17, s15                                   // 0000003355A8: 82120F11
	s_add_u32 s0, s13, s0                                      // 0000003355AC: 8000000D
	s_addc_u32 s1, s18, s1                                     // 0000003355B0: 82010112
	s_add_u32 s0, s0, 15                                       // 0000003355B4: 80008F00
	s_addc_u32 s1, s1, 0                                       // 0000003355B8: 82018001
	v_cndmask_b32_e32 v2, 0, v2, vcc_lo                        // 0000003355BC: 02040480
	s_ashr_i32 s13, s1, 31                                     // 0000003355C0: 860D9F01
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 0000003355C4: 02020280
	s_lshr_b32 s13, s13, 28                                    // 0000003355C8: 850D9C0D
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000003355CC: BF8704A9
	s_add_u32 s0, s0, s13                                      // 0000003355D0: 80000D00
	s_addc_u32 s1, s1, 0                                       // 0000003355D4: 82018001
	s_ashr_i64 s[0:1], s[0:1], 4                               // 0000003355D8: 86808400
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000003355DC: BF870149
	.long 0xd72c0003                                           // 0000003355E0: D72C0003
	v_cndmask_b32_e32 v0, v1, v1, vcc_lo                       // 0000003355E4: 02000301
	.long 0xd72c0002                                           // 0000003355E8: D72C0002
	v_cndmask_b32_e32 v0, v2, v0, vcc_lo                       // 0000003355EC: 02000102
	v_mad_u64_u32 v[10:11], null, v1, s0, s[4:5]               // 0000003355F0: D6FE7C0A 00100101
	.long 0xd4440000                                           // 0000003355F8: D4440000
	v_cndmask_b32_e32 v1, s12, v17, vcc_lo                     // 0000003355FC: 0202220C
	v_add3_u32 v19, v2, v11, v3                                // 000000335600: D6550013 040E1702
	s_and_saveexec_b32 s4, s0                                  // 000000335608: BE842000
	s_cbranch_execz 35                                         // 00000033560C: BFA50023 <_ZN7halogen12_GLOBAL__N_16k_lq6wILi2ELi16ELi1EEEvPKhPKtPtll+0x19c>
	v_lshlrev_b32_e32 v1, 4, v17                               // 000000335610: 30022284
	v_lshlrev_b32_e32 v0, 1, v0                                // 000000335614: 30000081
	v_lshlrev_b32_e32 v5, 3, v17                               // 000000335618: 300A2283
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000033561C: BF870093
	.long 0xd7000101                                           // 000000335620: D7000101
	v_cndmask_b32_e32 v1, v10, v1, vcc_lo                      // 000000335624: 0202030A
	v_add_co_ci_u32_e64 v2, null, 0, v19, s1                   // 000000335628: D5207C02 00062680
	.long 0xd7000103                                           // 000000335630: D7000103
	v_cndmask_b32_e32 v0, v10, v14, vcc_lo                     // 000000335634: 02001D0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000335638: BF8701A1
	v_add_co_ci_u32_e64 v4, null, s15, v19, s1                 // 00000033563C: D5207C04 0006260F
	v_and_b32_e32 v0, 28, v0                                   // 000000335644: 3600009C
	.long 0xd7000106                                           // 000000335648: D7000106
	v_cndmask_b32_e32 v0, v3, v16, vcc_lo                      // 00000033564C: 02002103
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000335650: BF8700A1
	v_add_co_ci_u32_e64 v7, null, s17, v4, s1                  // 000000335654: D5207C07 00060811
	.long 0xd700010b                                           // 00000033565C: D700010B
	v_cndmask_b32_e32 v1, v3, v5, vcc_lo                       // 000000335660: 02020B03
	v_add_co_ci_u32_e64 v12, null, 0, v4, s1                   // 000000335664: D5207C0C 00060880
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000033566C: BF870094
	.long 0xd700010d                                           // 000000335670: D700010D
	v_cndmask_b32_e32 v1, v6, v0, vcc_lo                       // 000000335674: 02020106
	v_add_co_ci_u32_e64 v14, null, 0, v7, s1                   // 000000335678: D5207C0E 00060E80
	s_clause 0x2                                               // 000000335680: BF850002
	global_load_b128 v[4:7], v[1:2], off                       // 000000335684: DC5E0000 047C0001
	global_load_b64 v[15:16], v[11:12], off                    // 00000033568C: DC560000 0F7C000B
	global_load_b32 v36, v[13:14], off                         // 000000335694: DC520000 247C000D
	s_or_b32 exec_lo, exec_lo, s4                              // 00000033569C: 8C7E047E
	v_mov_b32_e32 v20, 0                                       // 0000003356A0: 7E280280
	s_and_saveexec_b32 s13, s0                                 // 0000003356A4: BE8D2000
	s_cbranch_execz 774                                        // 0000003356A8: BFA50306 <_ZN7halogen12_GLOBAL__N_16k_lq6wILi2ELi16ELi1EEEvPKhPKtPtll+0xdc4>
	.long 0xd7000015                                           // 0000003356AC: D7000015
	v_cndmask_b32_e32 v0, v10, v14, vcc_lo                     // 0000003356B0: 02001D0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000003356B4: BF8701A1
	v_add_co_ci_u32_e64 v22, null, s15, v19, s0                // 0000003356B8: D5207C16 0002260F
	v_dual_mov_b32 v12, 0 :: v_dual_lshlrev_b32 v11, 5, v17    // 0000003356C0: CA220080 0C0A2285
	.long 0xd7000017                                           // 0000003356C8: D7000017
	v_cndmask_b32_e32 v0, v21, v16, vcc_lo                     // 0000003356CC: 02002115
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003356D0: BF870001
	v_add_co_ci_u32_e64 v24, null, s17, v22, s0                // 0000003356D4: D5207C18 00022C11
	v_lshl_or_b32 v25, v17, 4, 0x100                           // 0000003356DC: D6560019 03FD0911 00000100
	v_lshl_or_b32 v26, v17, 3, 0x80                            // 0000003356E8: D656001A 03FD0711 00000080
	v_lshl_or_b32 v27, v17, 1, 32                              // 0000003356F4: D656001B 02810311
	v_mov_b32_e32 v18, v12                                     // 0000003356FC: 7E24030C
	s_waitcnt vmcnt(0)                                         // 000000335700: BF8903F7
	v_dual_mov_b32 v28, v17 :: v_dual_mov_b32 v29, v36         // 000000335704: CA100111 1C1C0124
	v_mov_b32_e32 v20, v12                                     // 00000033570C: 7E28030C
	s_mov_b32 s14, 0                                           // 000000335710: BE8E0080
	s_lshl_b64 s[4:5], s[10:11], 1                             // 000000335714: 8484810A
	s_branch 707                                               // 000000335718: BFA002C3 <_ZN7halogen12_GLOBAL__N_16k_lq6wILi2ELi16ELi1EEEvPKhPKtPtll+0xd28>
	s_or_b32 exec_lo, exec_lo, s10                             // 00000033571C: 8C7E0A7E
	v_lshlrev_b32_e32 v30, 4, v15                              // 000000335720: 303C1E84
	v_lshlrev_b32_e32 v32, 2, v15                              // 000000335724: 30401E82
	v_lshrrev_b32_e32 v31, 4, v4                               // 000000335728: 323E0884
	v_lshrrev_b32_e32 v33, 2, v15                              // 00000033572C: 32421E82
	.long 0x7f4a3880                                           // 000000335730: 7F4A3880
	v_and_b32_e32 v30, 48, v30                                 // 000000335734: 363C3CB0
	v_and_b32_e32 v32, 48, v32                                 // 000000335738: 364040B0
	v_lshrrev_b32_e32 v35, 6, v15                              // 00000033573C: 32461E86
	v_and_b32_e32 v33, 48, v33                                 // 000000335740: 364242B0
	v_lshrrev_b32_e32 v34, 20, v4                              // 000000335744: 32440894
	v_and_or_b32 v30, v4, 15, v30                              // 000000335748: D657001E 04791F04
	v_and_or_b32 v31, v31, 15, v32                             // 000000335750: D657001F 04811F1F
	v_and_b32_e32 v35, 48, v35                                 // 000000335758: 364646B0
	v_lshrrev_b32_e32 v39, 18, v15                             // 00000033575C: 324E1E92
	v_lshrrev_b32_e32 v40, 22, v15                             // 000000335760: 32501E96
	v_cvt_f32_ubyte0_e32 v30, v30                              // 000000335764: 7E3C231E
	v_lshrrev_b32_e32 v41, 6, v16                              // 000000335768: 32522086
	v_and_or_b32 v34, v34, 15, v35                             // 00000033576C: D6570022 048D1F22
	v_and_b32_e32 v39, 48, v39                                 // 000000335774: 364E4EB0
	v_and_b32_e32 v40, 48, v40                                 // 000000335778: 365050B0
	v_fma_mix_f32 v30, v30, v36, v36 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000033577C: CC20601E 1492491E
	v_and_b32_e32 v41, 48, v41                                 // 000000335784: 365252B0
	s_and_b32 s0, exec_lo, s0                                  // 000000335788: 8B00007E
	v_add_nc_u32_e32 v25, 0x100, v25                           // 00000033578C: 4A3232FF 00000100
	s_or_b32 s14, s0, s14                                      // 000000335794: 8C0E0E00
	v_bfe_u32 v32, v30, 16, 1                                  // 000000335798: D6100020 0205211E
	v_add_nc_u32_e32 v26, 0x80, v26                            // 0000003357A0: 4A3434FF 00000080
	v_add_nc_u32_e32 v27, 32, v27                              // 0000003357A8: 4A3636A0
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000003357AC: BF870123
	v_add3_u32 v30, v30, v32, 0x7fff                           // 0000003357B0: D655001E 03FE411E 00007FFF
	v_and_b32_e32 v32, 48, v15                                 // 0000003357BC: 36401EB0
	.long 0x7e4a399e                                           // 0000003357C0: 7E4A399E
	v_cvt_f32_ubyte0_e32 v30, v31                              // 0000003357C4: 7E3C231F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003357C8: BF870091
	v_fma_mix_f32 v30, v30, v36, v36 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003357CC: CC20601E 1492491E
	v_bfe_u32 v31, v30, 16, 1                                  // 0000003357D4: D610001F 0205211E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000003357DC: BF870121
	v_add3_u32 v30, v30, v31, 0x7fff                           // 0000003357E0: D655001E 03FE3F1E 00007FFF
	v_lshrrev_b32_e32 v31, 8, v4                               // 0000003357EC: 323E0888
	v_and_or_b32 v30, 0xffff0000, v30, v37                     // 0000003357F0: D657001E 04963CFF FFFF0000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000003357FC: BF870122
	v_and_or_b32 v31, v31, 15, v32                             // 000000335800: D657001F 04811F1F
	v_lshrrev_b32_e32 v32, 12, v4                              // 000000335808: 3240088C
	v_cvt_f32_ubyte0_e32 v31, v31                              // 00000033580C: 7E3E231F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000335810: BF870112
	v_and_or_b32 v32, v32, 15, v33                             // 000000335814: D6570020 04851F20
	v_fma_mix_f32 v31, v31, v36, v36 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000033581C: CC20601F 1492491F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000335824: BF870091
	v_bfe_u32 v33, v31, 16, 1                                  // 000000335828: D6100021 0205211F
	v_add3_u32 v31, v31, v33, 0x7fff                           // 000000335830: D655001F 03FE431F 00007FFF
	v_lshrrev_b32_e32 v33, 8, v15                              // 00000033583C: 32421E88
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000335840: BF8701A2
	.long 0x7e4a399f                                           // 000000335844: 7E4A399F
	v_cvt_f32_ubyte0_e32 v31, v32                              // 000000335848: 7E3E2320
	v_and_b32_e32 v33, 48, v33                                 // 00000033584C: 364242B0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000335850: BF870092
	v_fma_mix_f32 v31, v31, v36, v36 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000335854: CC20601F 1492491F
	v_bfe_u32 v32, v31, 16, 1                                  // 00000033585C: D6100020 0205211F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000335864: BF870121
	v_add3_u32 v31, v31, v32, 0x7fff                           // 000000335868: D655001F 03FE411F 00007FFF
	v_lshrrev_b32_e32 v32, 4, v15                              // 000000335874: 32401E84
	v_and_or_b32 v31, 0xffff0000, v31, v37                     // 000000335878: D657001F 04963EFF FFFF0000
	.long 0x7e4a3984                                           // 000000335884: 7E4A3984
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000335888: BF870093
	v_and_b32_e32 v32, 48, v32                                 // 00000033588C: 364040B0
	v_and_or_b32 v32, v37, 15, v32                             // 000000335890: D6570020 04811F25
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000335898: BF870091
	v_cvt_f32_ubyte0_e32 v32, v32                              // 00000033589C: 7E402320
	v_fma_mix_f32 v32, v32, v36, v36 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003358A0: CC206020 14924920
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003358A8: BF870091
	v_bfe_u32 v35, v32, 16, 1                                  // 0000003358AC: D6100023 02052120
	v_add3_u32 v32, v32, v35, 0x7fff                           // 0000003358B4: D6550020 03FE4720 00007FFF
	v_lshrrev_b32_e32 v35, 12, v15                             // 0000003358C0: 32461E8C
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003358C4: BF8700A2
	.long 0x7e4a39a0                                           // 0000003358C8: 7E4A39A0
	v_cvt_f32_ubyte0_e32 v32, v34                              // 0000003358CC: 7E402322
	v_fma_mix_f32 v32, v32, v36, v36 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003358D0: CC206020 14924920
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003358D8: BF870091
	v_bfe_u32 v34, v32, 16, 1                                  // 0000003358DC: D6100022 02052120
	v_add3_u32 v32, v32, v34, 0x7fff                           // 0000003358E4: D6550020 03FE4520 00007FFF
	v_lshrrev_b32_e32 v34, 24, v4                              // 0000003358F0: 32440898
	v_lshrrev_b32_e32 v4, 28, v4                               // 0000003358F4: 3208089C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003358F8: BF870193
	v_and_or_b32 v32, 0xffff0000, v32, v37                     // 0000003358FC: D6570020 049640FF FFFF0000
	v_and_or_b32 v33, v34, 15, v33                             // 000000335908: D6570021 04851F22
	v_lshrrev_b32_e32 v34, 10, v15                             // 000000335910: 32441E8A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000335914: BF870112
	v_cvt_f32_ubyte0_e32 v33, v33                              // 000000335918: 7E422321
	v_and_or_b32 v4, v34, 48, v4                               // 00000033591C: D6570004 04116122
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000335924: BF870112
	v_fma_mix_f32 v33, v33, v36, v36 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000335928: CC206021 14924921
	v_cvt_f32_ubyte0_e32 v4, v4                                // 000000335930: 7E082304
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000335934: BF870112
	v_bfe_u32 v34, v33, 16, 1                                  // 000000335938: D6100022 02052121
	v_fma_mix_f32 v4, v4, v36, v36 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000335940: CC206004 14924904
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000335948: BF870122
	v_add3_u32 v33, v33, v34, 0x7fff                           // 00000033594C: D6550021 03FE4521 00007FFF
	v_lshrrev_b32_e32 v34, 4, v5                               // 000000335958: 32440A84
	.long 0x7e4a39a1                                           // 00000033595C: 7E4A39A1
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000335960: BF870094
	v_bfe_u32 v33, v4, 16, 1                                   // 000000335964: D6100021 02052104
	v_add3_u32 v4, v4, v33, 0x7fff                             // 00000033596C: D6550004 03FE4304 00007FFF
	v_and_b32_e32 v33, 48, v35                                 // 000000335978: 364246B0
	v_lshrrev_b32_e32 v35, 14, v15                             // 00000033597C: 32461E8E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000335980: BF870193
	v_and_or_b32 v4, 0xffff0000, v4, v37                       // 000000335984: D6570004 049608FF FFFF0000
	v_and_or_b32 v33, v5, 15, v33                              // 000000335990: D6570021 04851F05
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000335998: BF8701A3
	v_and_b32_e32 v35, 48, v35                                 // 00000033599C: 364646B0
	.long 0x7e4a398f                                           // 0000003359A0: 7E4A398F
	v_cvt_f32_ubyte0_e32 v33, v33                              // 0000003359A4: 7E422321
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003359A8: BF870193
	v_and_or_b32 v34, v34, 15, v35                             // 0000003359AC: D6570022 048D1F22
	v_and_b32_e32 v38, 48, v37                                 // 0000003359B4: 364C4AB0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003359B8: BF870193
	v_fma_mix_f32 v33, v33, v36, v36 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003359BC: CC206021 14924921
	v_cvt_f32_ubyte0_e32 v34, v34                              // 0000003359C4: 7E442322
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003359C8: BF870112
	v_bfe_u32 v35, v33, 16, 1                                  // 0000003359CC: D6100023 02052121
	v_fma_mix_f32 v34, v34, v36, v36 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003359D4: CC206022 14924922
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003359DC: BF870112
	v_add3_u32 v33, v33, v35, 0x7fff                           // 0000003359E0: D6550021 03FE4721 00007FFF
	v_bfe_u32 v35, v34, 16, 1                                  // 0000003359EC: D6100023 02052122
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000003359F4: BF8701A2
	.long 0x7e4239a1                                           // 0000003359F8: 7E4239A1
	.long 0x7f4239a5                                           // 0000003359FC: 7F4239A5
	v_add3_u32 v34, v34, v35, 0x7fff                           // 000000335A00: D6550022 03FE4722 00007FFF
	v_lshrrev_b32_e32 v35, 20, v15                             // 000000335A0C: 32461E94
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000335A10: BF8701A2
	v_and_or_b32 v33, 0xffff0000, v34, v33                     // 000000335A14: D6570021 048644FF FFFF0000
	v_lshrrev_b32_e32 v34, 8, v5                               // 000000335A20: 32440A88
	v_and_b32_e32 v35, 48, v35                                 // 000000335A24: 364646B0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000335A28: BF870122
	v_and_or_b32 v34, v34, 15, v38                             // 000000335A2C: D6570022 04991F22
	v_lshrrev_b32_e32 v38, 12, v5                              // 000000335A34: 324C0A8C
	v_cvt_f32_ubyte0_e32 v34, v34                              // 000000335A38: 7E442322
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000335A3C: BF870112
	v_and_or_b32 v38, v38, 15, v39                             // 000000335A40: D6570026 049D1F26
	v_fma_mix_f32 v34, v34, v36, v36 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000335A48: CC206022 14924922
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000335A50: BF870091
	v_bfe_u32 v39, v34, 16, 1                                  // 000000335A54: D6100027 02052122
	v_add3_u32 v34, v34, v39, 0x7fff                           // 000000335A5C: D6550022 03FE4F22 00007FFF
	v_lshrrev_b32_e32 v39, 20, v5                              // 000000335A68: 324E0A94
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000335A6C: BF8701A2
	.long 0x7e4a39a2                                           // 000000335A70: 7E4A39A2
	v_cvt_f32_ubyte0_e32 v34, v38                              // 000000335A74: 7E442326
	v_and_or_b32 v39, v39, 15, v40                             // 000000335A78: D6570027 04A11F27
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000335A80: BF870092
	v_fma_mix_f32 v34, v34, v36, v36 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000335A84: CC206022 14924922
	v_bfe_u32 v38, v34, 16, 1                                  // 000000335A8C: D6100026 02052122
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000335A94: BF8701B1
	v_add3_u32 v34, v34, v38, 0x7fff                           // 000000335A98: D6550022 03FE4D22 00007FFF
	v_lshrrev_b32_e32 v38, 24, v15                             // 000000335AA4: 324C1E98
	v_lshrrev_b32_e32 v15, 26, v15                             // 000000335AA8: 321E1E9A
	v_and_or_b32 v34, 0xffff0000, v34, v37                     // 000000335AAC: D6570022 049644FF FFFF0000
	.long 0x7e4a3985                                           // 000000335AB8: 7E4A3985
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000335ABC: BF870114
	v_and_b32_e32 v38, 48, v38                                 // 000000335AC0: 364C4CB0
	v_and_or_b32 v35, v37, 15, v35                             // 000000335AC4: D6570023 048D1F25
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000335ACC: BF870091
	v_cvt_f32_ubyte0_e32 v35, v35                              // 000000335AD0: 7E462323
	v_fma_mix_f32 v35, v35, v36, v36 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000335AD4: CC206023 14924923
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000335ADC: BF870091
	v_bfe_u32 v40, v35, 16, 1                                  // 000000335AE0: D6100028 02052123
	v_add3_u32 v35, v35, v40, 0x7fff                           // 000000335AE8: D6550023 03FE5123 00007FFF
	v_lshrrev_b32_e32 v40, 2, v16                              // 000000335AF4: 32502082
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000335AF8: BF8701A2
	.long 0x7e4a39a3                                           // 000000335AFC: 7E4A39A3
	v_cvt_f32_ubyte0_e32 v35, v39                              // 000000335B00: 7E462327
	v_and_b32_e32 v40, 48, v40                                 // 000000335B04: 365050B0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000335B08: BF870092
	v_fma_mix_f32 v35, v35, v36, v36 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000335B0C: CC206023 14924923
	v_bfe_u32 v39, v35, 16, 1                                  // 000000335B14: D6100027 02052123
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000335B1C: BF8701B1
	v_add3_u32 v35, v35, v39, 0x7fff                           // 000000335B20: D6550023 03FE4F23 00007FFF
	v_lshrrev_b32_e32 v39, 24, v5                              // 000000335B2C: 324E0A98
	v_lshrrev_b32_e32 v5, 28, v5                               // 000000335B30: 320A0A9C
	v_and_or_b32 v35, 0xffff0000, v35, v37                     // 000000335B34: D6570023 049646FF FFFF0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000335B40: BF870193
	v_and_or_b32 v38, v39, 15, v38                             // 000000335B44: D6570026 04991F27
	v_and_or_b32 v5, v15, 48, v5                               // 000000335B4C: D6570005 0415610F
	v_lshlrev_b32_e32 v39, 2, v16                              // 000000335B54: 304E2082
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000335B58: BF870193
	v_cvt_f32_ubyte0_e32 v15, v38                              // 000000335B5C: 7E1E2326
	v_cvt_f32_ubyte0_e32 v5, v5                                // 000000335B60: 7E0A2305
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000335B64: BF870193
	v_and_b32_e32 v39, 48, v39                                 // 000000335B68: 364E4EB0
	v_fma_mix_f32 v15, v15, v36, v36 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000335B6C: CC20600F 1492490F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000335B74: BF870113
	v_fma_mix_f32 v5, v5, v36, v36 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000335B78: CC206005 14924905
	v_bfe_u32 v38, v15, 16, 1                                  // 000000335B80: D6100026 0205210F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000335B88: BF870121
	v_add3_u32 v15, v15, v38, 0x7fff                           // 000000335B8C: D655000F 03FE4D0F 00007FFF
	v_lshrrev_b32_e32 v38, 4, v6                               // 000000335B98: 324C0C84
	.long 0x7e4a398f                                           // 000000335B9C: 7E4A398F
	v_bfe_u32 v15, v5, 16, 1                                   // 000000335BA0: D610000F 02052105
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000335BA8: BF870113
	v_and_or_b32 v38, v38, 15, v39                             // 000000335BAC: D6570026 049D1F26
	v_add3_u32 v5, v5, v15, 0x7fff                             // 000000335BB4: D6550005 03FE1F05 00007FFF
	v_lshlrev_b32_e32 v15, 4, v16                              // 000000335BC0: 301E2084
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000335BC4: BF870112
	v_and_or_b32 v5, 0xffff0000, v5, v37                       // 000000335BC8: D6570005 04960AFF FFFF0000
	v_and_b32_e32 v15, 48, v15                                 // 000000335BD4: 361E1EB0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000335BD8: BF870091
	v_and_or_b32 v15, v6, 15, v15                              // 000000335BDC: D657000F 043D1F06
	v_cvt_f32_ubyte0_e32 v15, v15                              // 000000335BE4: 7E1E230F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000335BE8: BF870091
	v_fma_mix_f32 v15, v15, v36, v36 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000335BEC: CC20600F 1492490F
	v_bfe_u32 v39, v15, 16, 1                                  // 000000335BF4: D6100027 0205210F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000335BFC: BF870121
	v_add3_u32 v15, v15, v39, 0x7fff                           // 000000335C00: D655000F 03FE4F0F 00007FFF
	v_and_b32_e32 v39, 48, v16                                 // 000000335C0C: 364E20B0
	.long 0x7e4a398f                                           // 000000335C10: 7E4A398F
	v_cvt_f32_ubyte0_e32 v15, v38                              // 000000335C14: 7E1E2326
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000335C18: BF870091
	v_fma_mix_f32 v15, v15, v36, v36 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000335C1C: CC20600F 1492490F
	v_bfe_u32 v38, v15, 16, 1                                  // 000000335C24: D6100026 0205210F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000335C2C: BF870121
	v_add3_u32 v15, v15, v38, 0x7fff                           // 000000335C30: D655000F 03FE4D0F 00007FFF
	v_lshrrev_b32_e32 v38, 8, v6                               // 000000335C3C: 324C0C88
	v_and_or_b32 v15, 0xffff0000, v15, v37                     // 000000335C40: D657000F 04961EFF FFFF0000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000335C4C: BF870122
	v_and_or_b32 v38, v38, 15, v39                             // 000000335C50: D6570026 049D1F26
	v_lshrrev_b32_e32 v39, 12, v6                              // 000000335C58: 324E0C8C
	v_cvt_f32_ubyte0_e32 v38, v38                              // 000000335C5C: 7E4C2326
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000335C60: BF870112
	v_and_or_b32 v39, v39, 15, v40                             // 000000335C64: D6570027 04A11F27
	v_fma_mix_f32 v38, v38, v36, v36 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000335C6C: CC206026 14924926
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000335C74: BF870091
	v_bfe_u32 v40, v38, 16, 1                                  // 000000335C78: D6100028 02052126
	v_add3_u32 v38, v38, v40, 0x7fff                           // 000000335C80: D6550026 03FE5126 00007FFF
	v_lshrrev_b32_e32 v40, 20, v6                              // 000000335C8C: 32500C94
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000335C90: BF8701A2
	.long 0x7e4a39a6                                           // 000000335C94: 7E4A39A6
	v_cvt_f32_ubyte0_e32 v38, v39                              // 000000335C98: 7E4C2327
	v_and_or_b32 v40, v40, 15, v41                             // 000000335C9C: D6570028 04A51F28
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000335CA4: BF870092
	v_fma_mix_f32 v38, v38, v36, v36 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000335CA8: CC206026 14924926
	v_bfe_u32 v39, v38, 16, 1                                  // 000000335CB0: D6100027 02052126
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000335CB8: BF870121
	v_add3_u32 v38, v38, v39, 0x7fff                           // 000000335CBC: D6550026 03FE4F26 00007FFF
	v_lshrrev_b32_e32 v39, 4, v16                              // 000000335CC8: 324E2084
	v_and_or_b32 v52, 0xffff0000, v38, v37                     // 000000335CCC: D6570034 04964CFF FFFF0000
	.long 0x7e4a3986                                           // 000000335CD8: 7E4A3986
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000335CDC: BF870123
	v_and_b32_e32 v39, 48, v39                                 // 000000335CE0: 364E4EB0
	v_lshrrev_b32_e32 v38, 8, v16                              // 000000335CE4: 324C2088
	v_and_or_b32 v39, v37, 15, v39                             // 000000335CE8: D6570027 049D1F25
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000335CF0: BF870112
	v_and_b32_e32 v38, 48, v38                                 // 000000335CF4: 364C4CB0
	v_cvt_f32_ubyte0_e32 v39, v39                              // 000000335CF8: 7E4E2327
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000335CFC: BF870091
	v_fma_mix_f32 v39, v39, v36, v36 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000335D00: CC206027 14924927
	v_bfe_u32 v41, v39, 16, 1                                  // 000000335D08: D6100029 02052127
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000335D10: BF870091
	v_add3_u32 v39, v39, v41, 0x7fff                           // 000000335D14: D6550027 03FE5327 00007FFF
	.long 0x7e4a39a7                                           // 000000335D20: 7E4A39A7
	v_cvt_f32_ubyte0_e32 v39, v40                              // 000000335D24: 7E4E2328
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000335D28: BF870091
	v_fma_mix_f32 v39, v39, v36, v36 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000335D2C: CC206027 14924927
	v_bfe_u32 v40, v39, 16, 1                                  // 000000335D34: D6100028 02052127
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000335D3C: BF870121
	v_add3_u32 v39, v39, v40, 0x7fff                           // 000000335D40: D6550027 03FE5127 00007FFF
	v_lshrrev_b32_e32 v40, 12, v16                             // 000000335D4C: 3250208C
	v_and_or_b32 v53, 0xffff0000, v39, v37                     // 000000335D50: D6570035 04964EFF FFFF0000
	v_lshrrev_b32_e32 v39, 24, v6                              // 000000335D5C: 324E0C98
	v_lshrrev_b32_e32 v6, 28, v6                               // 000000335D60: 320C0C9C
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000335D64: BF870122
	v_and_or_b32 v38, v39, 15, v38                             // 000000335D68: D6570026 04991F27
	v_lshrrev_b32_e32 v39, 10, v16                             // 000000335D70: 324E208A
	v_cvt_f32_ubyte0_e32 v38, v38                              // 000000335D74: 7E4C2326
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000335D78: BF870112
	v_and_or_b32 v6, v39, 48, v6                               // 000000335D7C: D6570006 04196127
	v_fma_mix_f32 v38, v38, v36, v36 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000335D84: CC206026 14924926
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000335D8C: BF870112
	v_cvt_f32_ubyte0_e32 v6, v6                                // 000000335D90: 7E0C2306
	v_bfe_u32 v39, v38, 16, 1                                  // 000000335D94: D6100027 02052126
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000335D9C: BF870112
	v_fma_mix_f32 v6, v6, v36, v36 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000335DA0: CC206006 14924906
	v_add3_u32 v38, v38, v39, 0x7fff                           // 000000335DA8: D6550026 03FE4F26 00007FFF
	v_lshrrev_b32_e32 v39, 14, v16                             // 000000335DB4: 324E208E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000335DB8: BF870212
	.long 0x7e4a39a6                                           // 000000335DBC: 7E4A39A6
	v_bfe_u32 v38, v6, 16, 1                                   // 000000335DC0: D6100026 02052106
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000335DC8: BF870113
	v_and_b32_e32 v39, 48, v39                                 // 000000335DCC: 364E4EB0
	v_add3_u32 v6, v6, v38, 0x7fff                             // 000000335DD0: D6550006 03FE4D06 00007FFF
	v_lshrrev_b32_e32 v38, 4, v7                               // 000000335DDC: 324C0E84
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000335DE0: BF8701A2
	v_and_or_b32 v54, 0xffff0000, v6, v37                      // 000000335DE4: D6570036 04960CFF FFFF0000
	v_and_b32_e32 v6, 15, v7                                   // 000000335DF0: 360C0E8F
	v_and_or_b32 v38, v38, 15, v39                             // 000000335DF4: D6570026 049D1F26
	.long 0x7e4a3990                                           // 000000335DFC: 7E4A3990
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000335E00: BF870193
	v_and_or_b32 v6, v40, 48, v6                               // 000000335E04: D6570006 04196128
	v_cvt_f32_ubyte0_e32 v38, v38                              // 000000335E0C: 7E4C2326
	v_lshrrev_b32_e32 v40, 18, v16                             // 000000335E10: 32502092
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000335E14: BF870193
	v_cvt_f32_ubyte0_e32 v6, v6                                // 000000335E18: 7E0C2306
	v_fma_mix_f32 v38, v38, v36, v36 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000335E1C: CC206026 14924926
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000335E24: BF870193
	v_and_b32_e32 v40, 48, v40                                 // 000000335E28: 365050B0
	v_fma_mix_f32 v6, v6, v36, v36 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000335E2C: CC206006 14924906
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000335E34: BF870091
	v_bfe_u32 v39, v6, 16, 1                                   // 000000335E38: D6100027 02052106
	v_add3_u32 v6, v6, v39, 0x7fff                             // 000000335E40: D6550006 03FE4F06 00007FFF
	v_bfe_u32 v39, v38, 16, 1                                  // 000000335E4C: D6100027 02052126
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000335E54: BF8701A2
	.long 0x7e0c3986                                           // 000000335E58: 7E0C3986
	.long 0x7f0c39a5                                           // 000000335E5C: 7F0C39A5
	v_add3_u32 v38, v38, v39, 0x7fff                           // 000000335E60: D6550026 03FE4F26 00007FFF
	v_and_b32_e32 v39, 48, v37                                 // 000000335E6C: 364E4AB0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000335E70: BF870132
	v_and_or_b32 v55, 0xffff0000, v38, v6                      // 000000335E74: D6570037 041A4CFF FFFF0000
	v_lshrrev_b32_e32 v6, 8, v7                                // 000000335E80: 320C0E88
	v_lshrrev_b32_e32 v38, 20, v16                             // 000000335E84: 324C2094
	v_and_or_b32 v6, v6, 15, v39                               // 000000335E88: D6570006 049D1F06
	v_lshrrev_b32_e32 v39, 12, v7                              // 000000335E90: 324E0E8C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000335E94: BF870193
	v_and_b32_e32 v38, 48, v38                                 // 000000335E98: 364C4CB0
	v_cvt_f32_ubyte0_e32 v6, v6                                // 000000335E9C: 7E0C2306
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000335EA0: BF870113
	v_and_or_b32 v39, v39, 15, v40                             // 000000335EA4: D6570027 04A11F27
	v_fma_mix_f32 v6, v6, v36, v36 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000335EAC: CC206006 14924906
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000335EB4: BF870091
	v_bfe_u32 v40, v6, 16, 1                                   // 000000335EB8: D6100028 02052106
	v_add3_u32 v6, v6, v40, 0x7fff                             // 000000335EC0: D6550006 03FE5106 00007FFF
	v_lshrrev_b32_e32 v40, 22, v16                             // 000000335ECC: 32502096
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000335ED0: BF8701A2
	.long 0x7e4a3986                                           // 000000335ED4: 7E4A3986
	v_cvt_f32_ubyte0_e32 v6, v39                               // 000000335ED8: 7E0C2327
	v_and_b32_e32 v40, 48, v40                                 // 000000335EDC: 365050B0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000335EE0: BF870092
	v_fma_mix_f32 v6, v6, v36, v36 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000335EE4: CC206006 14924906
	v_bfe_u32 v39, v6, 16, 1                                   // 000000335EEC: D6100027 02052106
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000335EF4: BF870121
	v_add3_u32 v6, v6, v39, 0x7fff                             // 000000335EF8: D6550006 03FE4F06 00007FFF
	v_lshrrev_b32_e32 v39, 20, v7                              // 000000335F04: 324E0E94
	v_and_or_b32 v56, 0xffff0000, v6, v37                      // 000000335F08: D6570038 04960CFF FFFF0000
	.long 0x7e4a3987                                           // 000000335F14: 7E4A3987
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000335F18: BF870233
	v_and_or_b32 v39, v39, 15, v40                             // 000000335F1C: D6570027 04A11F27
	v_lshrrev_b32_e32 v6, 24, v16                              // 000000335F24: 320C2098
	v_lshrrev_b32_e32 v16, 26, v16                             // 000000335F28: 3220209A
	v_and_or_b32 v38, v37, 15, v38                             // 000000335F2C: D6570026 04991F25
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000335F34: BF870113
	v_and_b32_e32 v6, 48, v6                                   // 000000335F38: 360C0CB0
	v_cvt_f32_ubyte0_e32 v38, v38                              // 000000335F3C: 7E4C2326
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000335F40: BF870091
	v_fma_mix_f32 v38, v38, v36, v36 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000335F44: CC206026 14924926
	v_bfe_u32 v40, v38, 16, 1                                  // 000000335F4C: D6100028 02052126
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000335F54: BF870091
	v_add3_u32 v38, v38, v40, 0x7fff                           // 000000335F58: D6550026 03FE5126 00007FFF
	.long 0x7e4a39a6                                           // 000000335F64: 7E4A39A6
	v_cvt_f32_ubyte0_e32 v38, v39                              // 000000335F68: 7E4C2327
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000335F6C: BF870091
	v_fma_mix_f32 v38, v38, v36, v36 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000335F70: CC206026 14924926
	v_bfe_u32 v39, v38, 16, 1                                  // 000000335F78: D6100027 02052126
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000335F80: BF870091
	v_add3_u32 v38, v38, v39, 0x7fff                           // 000000335F84: D6550026 03FE4F26 00007FFF
	v_and_or_b32 v57, 0xffff0000, v38, v37                     // 000000335F90: D6570039 04964CFF FFFF0000
	v_lshrrev_b32_e32 v38, 24, v7                              // 000000335F9C: 324C0E98
	v_lshrrev_b32_e32 v7, 28, v7                               // 000000335FA0: 320E0E9C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000335FA4: BF870112
	v_and_or_b32 v6, v38, 15, v6                               // 000000335FA8: D6570006 04191F26
	v_and_or_b32 v7, v16, 48, v7                               // 000000335FB0: D6570007 041D6110
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000335FB8: BF870092
	v_cvt_f32_ubyte0_e32 v6, v6                                // 000000335FBC: 7E0C2306
	v_fma_mix_f32 v6, v6, v36, v36 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000335FC0: CC206006 14924906
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000335FC8: BF870091
	v_bfe_u32 v16, v6, 16, 1                                   // 000000335FCC: D6100010 02052106
	v_add3_u32 v6, v6, v16, 0x7fff                             // 000000335FD4: D6550006 03FE2106 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000335FE0: BF8700A1
	.long 0x7e4a3986                                           // 000000335FE4: 7E4A3986
	v_cvt_f32_ubyte0_e32 v6, v7                                // 000000335FE8: 7E0C2307
	v_fma_mix_f32 v6, v6, v36, v36 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000335FEC: CC206006 14924906
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000335FF4: BF870091
	v_bfe_u32 v7, v6, 16, 1                                    // 000000335FF8: D6100007 02052106
	v_add3_u32 v6, v6, v7, 0x7fff                              // 000000336000: D6550006 03FE0F06 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000033600C: BF870131
	v_and_or_b32 v16, 0xffff0000, v6, v37                      // 000000336010: D6570010 04960CFF FFFF0000
	.long 0xd73c0006                                           // 00000033601C: D73C0006
	v_cndmask_b32_e32 v1, 1, v11, vcc_lo                       // 000000336020: 02021681
	v_add_nc_u32_e32 v11, 0x200, v11                           // 000000336024: 4A1616FF 00000200
	.long 0xd7000006                                           // 00000033602C: D7000006
	v_cndmask_b32_e32 v1, s6, v6, vcc_lo                       // 000000336030: 02020C06
	s_delay_alu instid0(VALU_DEP_1)                            // 000000336034: BF870001
	v_add_co_ci_u32_e64 v7, null, s7, v7, s0                   // 000000336038: D5207C07 00020E07
	s_clause 0x3                                               // 000000336040: BF850003
	global_load_b128 v[36:39], v[6:7], off                     // 000000336044: DC5E0000 247C0006
	global_load_b128 v[40:43], v[6:7], off offset:16           // 00000033604C: DC5E0010 287C0006
	global_load_b128 v[44:47], v[6:7], off offset:32           // 000000336054: DC5E0020 2C7C0006
	global_load_b128 v[48:51], v[6:7], off offset:48           // 00000033605C: DC5E0030 307C0006
	.long 0xd7000006                                           // 000000336064: D7000006
	v_cndmask_b32_e32 v0, v6, v4, vcc_lo                       // 000000336068: 02000906
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000033606C: BF8700B1
	v_add_co_ci_u32_e64 v7, null, s5, v7, s0                   // 000000336070: D5207C07 00020E05
	s_waitcnt vmcnt(3)                                         // 000000336078: BF890FF7
	v_dot2_f32_bf16 v36, v36, v30, 0                           // 00000033607C: CC1A4024 1A023D24
	v_dot2_f32_bf16 v36, v37, v31, v36                         // 000000336084: CC1A4024 1C923F25
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000033608C: BF870091
	v_dot2_f32_bf16 v36, v38, v32, v36                         // 000000336090: CC1A4024 1C924126
	v_dot2_f32_bf16 v36, v39, v4, v36                          // 000000336098: CC1A4024 1C920927
	s_waitcnt vmcnt(2)                                         // 0000003360A0: BF890BF7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003360A4: BF870091
	v_dot2_f32_bf16 v36, v40, v33, v36                         // 0000003360A8: CC1A4024 1C924328
	v_dot2_f32_bf16 v36, v41, v34, v36                         // 0000003360B0: CC1A4024 1C924529
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003360B8: BF870091
	v_dot2_f32_bf16 v36, v42, v35, v36                         // 0000003360BC: CC1A4024 1C92472A
	v_dot2_f32_bf16 v36, v43, v5, v36                          // 0000003360C4: CC1A4024 1C920B2B
	s_waitcnt vmcnt(1)                                         // 0000003360CC: BF8907F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003360D0: BF870091
	v_dot2_f32_bf16 v36, v44, v15, v36                         // 0000003360D4: CC1A4024 1C921F2C
	v_dot2_f32_bf16 v36, v45, v52, v36                         // 0000003360DC: CC1A4024 1C92692D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003360E4: BF870091
	v_dot2_f32_bf16 v36, v46, v53, v36                         // 0000003360E8: CC1A4024 1C926B2E
	v_dot2_f32_bf16 v36, v47, v54, v36                         // 0000003360F0: CC1A4024 1C926D2F
	s_waitcnt vmcnt(0)                                         // 0000003360F8: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003360FC: BF870091
	v_dot2_f32_bf16 v36, v48, v55, v36                         // 000000336100: CC1A4024 1C926F30
	v_dot2_f32_bf16 v36, v49, v56, v36                         // 000000336108: CC1A4024 1C927131
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000336110: BF870091
	v_dot2_f32_bf16 v36, v50, v57, v36                         // 000000336114: CC1A4024 1C927332
	v_dot2_f32_bf16 v36, v51, v16, v36                         // 00000033611C: CC1A4024 1C922133
	s_delay_alu instid0(VALU_DEP_1)                            // 000000336124: BF870001
	v_add_f32_e32 v20, v20, v36                                // 000000336128: 06284914
	s_clause 0x3                                               // 00000033612C: BF850003
	global_load_b128 v[36:39], v[6:7], off                     // 000000336130: DC5E0000 247C0006
	global_load_b128 v[40:43], v[6:7], off offset:16           // 000000336138: DC5E0010 287C0006
	global_load_b128 v[44:47], v[6:7], off offset:32           // 000000336140: DC5E0020 2C7C0006
	global_load_b128 v[48:51], v[6:7], off offset:48           // 000000336148: DC5E0030 307C0006
	v_mov_b32_e32 v7, v3                                       // 000000336150: 7E0E0303
	s_waitcnt vmcnt(3)                                         // 000000336154: BF890FF7
	v_dot2_f32_bf16 v6, v36, v30, 0                            // 000000336158: CC1A4006 1A023D24
	v_mov_b32_e32 v36, v29                                     // 000000336160: 7E48031D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000336164: BF870092
	v_dot2_f32_bf16 v6, v37, v31, v6                           // 000000336168: CC1A4006 1C1A3F25
	v_dot2_f32_bf16 v6, v38, v32, v6                           // 000000336170: CC1A4006 1C1A4126
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000336178: BF870131
	v_dot2_f32_bf16 v4, v39, v4, v6                            // 00000033617C: CC1A4004 1C1A0927
	v_mov_b32_e32 v6, v2                                       // 000000336184: 7E0C0302
	s_waitcnt vmcnt(2)                                         // 000000336188: BF890BF7
	v_dot2_f32_bf16 v4, v40, v33, v4                           // 00000033618C: CC1A4004 1C124328
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000336194: BF870091
	v_dot2_f32_bf16 v4, v41, v34, v4                           // 000000336198: CC1A4004 1C124529
	v_dot2_f32_bf16 v4, v42, v35, v4                           // 0000003361A0: CC1A4004 1C12472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000003361A8: BF870131
	v_dot2_f32_bf16 v4, v43, v5, v4                            // 0000003361AC: CC1A4004 1C120B2B
	v_mov_b32_e32 v5, v1                                       // 0000003361B4: 7E0A0301
	s_waitcnt vmcnt(1)                                         // 0000003361B8: BF8907F7
	v_dot2_f32_bf16 v4, v44, v15, v4                           // 0000003361BC: CC1A4004 1C121F2C
	v_mov_b32_e32 v15, v13                                     // 0000003361C4: 7E1E030D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003361C8: BF870092
	v_dot2_f32_bf16 v4, v45, v52, v4                           // 0000003361CC: CC1A4004 1C12692D
	v_dot2_f32_bf16 v4, v46, v53, v4                           // 0000003361D4: CC1A4004 1C126B2E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003361DC: BF8700A1
	v_dot2_f32_bf16 v4, v47, v54, v4                           // 0000003361E0: CC1A4004 1C126D2F
	s_waitcnt vmcnt(0)                                         // 0000003361E8: BF8903F7
	v_dot2_f32_bf16 v4, v48, v55, v4                           // 0000003361EC: CC1A4004 1C126F30
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003361F4: BF870091
	v_dot2_f32_bf16 v4, v49, v56, v4                           // 0000003361F8: CC1A4004 1C127131
	v_dot2_f32_bf16 v4, v50, v57, v4                           // 000000336200: CC1A4004 1C127332
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000336208: BF870121
	v_dot2_f32_bf16 v4, v51, v16, v4                           // 00000033620C: CC1A4004 1C122133
	v_mov_b32_e32 v16, v14                                     // 000000336214: 7E20030E
	v_add_f32_e32 v18, v18, v4                                 // 000000336218: 06240912
	v_mov_b32_e32 v4, v0                                       // 00000033621C: 7E080300
	s_and_not1_b32 exec_lo, exec_lo, s14                       // 000000336220: 917E0E7E
	s_cbranch_execz 38                                         // 000000336224: BFA50026 <_ZN7halogen12_GLOBAL__N_16k_lq6wILi2ELi16ELi1EEEvPKhPKtPtll+0xdc0>
	v_dual_mov_b32 v1, v5 :: v_dual_add_nc_u32 v28, 16, v28    // 000000336228: CA200105 011C3890
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000336230: BF8701A2
	v_dual_mov_b32 v0, v4 :: v_dual_mov_b32 v3, v7             // 000000336234: CA100104 00020107
	v_dual_mov_b32 v2, v6 :: v_dual_mov_b32 v13, v15           // 00000033623C: CA100106 020C010F
	.long 0xd4430000                                           // 000000336244: D4430000
	v_cndmask_b32_e32 v1, s12, v28, vcc_lo                     // 000000336248: 0202380C
	v_mov_b32_e32 v14, v16                                     // 00000033624C: 7E1C0310
	s_mov_b32 s10, exec_lo                                     // 000000336250: BE8A007E
	.long 0xd4c4007e                                           // 000000336254: D4C4007E
	v_cndmask_b32_e32 v1, s12, v28, vcc_lo                     // 000000336258: 0202380C
	s_cbranch_execz 64815                                      // 00000033625C: BFA5FD2F <_ZN7halogen12_GLOBAL__N_16k_lq6wILi2ELi16ELi1EEEvPKhPKtPtll+0x21c>
	v_and_b32_e32 v2, 0x7ffffffc, v27                          // 000000336260: 360436FF 7FFFFFFC
	.long 0xd7000100                                           // 000000336268: D7000100
	v_cndmask_b32_e32 v1, v10, v25, vcc_lo                     // 00000033626C: 0202330A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000336270: BF8700A1
	v_add_co_ci_u32_e64 v1, null, 0, v19, s1                   // 000000336274: D5207C01 00062680
	.long 0xd700010d                                           // 00000033627C: D700010D
	v_cndmask_b32_e32 v1, v21, v26, vcc_lo                     // 000000336280: 02023515
	v_add_co_ci_u32_e64 v14, null, 0, v22, s1                  // 000000336284: D5207C0E 00062C80
	.long 0xd700011d                                           // 00000033628C: D700011D
	v_cndmask_b32_e32 v1, v23, v2, vcc_lo                      // 000000336290: 02020517
	s_delay_alu instid0(VALU_DEP_1)                            // 000000336294: BF870001
	v_add_co_ci_u32_e64 v30, null, 0, v24, s1                  // 000000336298: D5207C1E 00063080
	s_clause 0x2                                               // 0000003362A0: BF850002
	global_load_b128 v[0:3], v[0:1], off                       // 0000003362A4: DC5E0000 007C0000
	global_load_b64 v[13:14], v[13:14], off                    // 0000003362AC: DC560000 0D7C000D
	global_load_b32 v29, v[29:30], off                         // 0000003362B4: DC520000 1D7C001D
	s_branch 64791                                             // 0000003362BC: BFA0FD17 <_ZN7halogen12_GLOBAL__N_16k_lq6wILi2ELi16ELi1EEEvPKhPKtPtll+0x21c>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000003362C0: 8C7E0E7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003362C4: BF8700A9
	s_or_b32 exec_lo, exec_lo, s13                             // 0000003362C8: 8C7E0D7E
	.long 0xd71f0000                                           // 0000003362CC: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000003362D0: 020100C1
	v_xor_b32_e32 v1, 8, v0                                    // 0000003362D4: 3A020088
	v_xor_b32_e32 v3, 4, v0                                    // 0000003362D8: 3A060084
	s_waitcnt vmcnt(2)                                         // 0000003362DC: BF890BF7
	v_xor_b32_e32 v5, 2, v0                                    // 0000003362E0: 3A0A0082
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003362E4: BF870093
	.long 0xd44c0000                                           // 0000003362E8: D44C0000
	v_cndmask_b32_e32 v1, 32, v1, vcc_lo                       // 0000003362EC: 020202A0
	v_cndmask_b32_e64 v1, v0, v1, s0                           // 0000003362F0: D5010001 00020300
	.long 0xd44c0000                                           // 0000003362F8: D44C0000
	v_cndmask_b32_e32 v1, 32, v3, vcc_lo                       // 0000003362FC: 020206A0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000336300: BF870112
	v_lshlrev_b32_e32 v1, 2, v1                                // 000000336304: 30020282
	v_cndmask_b32_e64 v3, v0, v3, s0                           // 000000336308: D5010003 00020700
	.long 0xd44c0000                                           // 000000336310: D44C0000
	v_cndmask_b32_e32 v1, 32, v5, vcc_lo                       // 000000336314: 02020AA0
	ds_bpermute_b32 v2, v1, v20                                // 000000336318: DACC0000 02001401
	v_cndmask_b32_e64 v5, v0, v5, s0                           // 000000336320: D5010005 00020B00
	s_waitcnt lgkmcnt(0)                                       // 000000336328: BF89FC07
	v_add_f32_e32 v2, v20, v2                                  // 00000033632C: 06040514
	ds_bpermute_b32 v1, v1, v18                                // 000000336330: DACC0000 01001201
	v_lshlrev_b32_e32 v3, 2, v3                                // 000000336338: 30060682
	ds_bpermute_b32 v4, v3, v2                                 // 00000033633C: DACC0000 04000203
	s_waitcnt lgkmcnt(1)                                       // 000000336344: BF89FC17
	v_add_f32_e32 v1, v18, v1                                  // 000000336348: 06020312
	s_waitcnt lgkmcnt(0)                                       // 00000033634C: BF89FC07
	v_add_f32_e32 v2, v2, v4                                   // 000000336350: 06040902
	ds_bpermute_b32 v3, v3, v1                                 // 000000336354: DACC0000 03000103
	v_lshlrev_b32_e32 v5, 2, v5                                // 00000033635C: 300A0A82
	s_waitcnt lgkmcnt(0)                                       // 000000336360: BF89FC07
	v_add_f32_e32 v1, v1, v3                                   // 000000336364: 06020701
	ds_bpermute_b32 v3, v5, v2                                 // 000000336368: DACC0000 03000205
	s_waitcnt lgkmcnt(0)                                       // 000000336370: BF89FC07
	v_add_f32_e32 v2, v2, v3                                   // 000000336374: 06040702
	ds_bpermute_b32 v4, v5, v1                                 // 000000336378: DACC0000 04000105
	v_xor_b32_e32 v5, 1, v0                                    // 000000336380: 3A0A0081
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000336384: BF870091
	.long 0xd44c0000                                           // 000000336388: D44C0000
	v_cndmask_b32_e32 v1, 32, v5, vcc_lo                       // 00000033638C: 02020AA0
	v_cndmask_b32_e64 v0, v0, v5, s0                           // 000000336390: D5010000 00020B00
	.long 0xd44a0000                                           // 000000336398: D44A0000
	v_cndmask_b32_e32 v1, 0, v17, vcc_lo                       // 00000033639C: 02022280
	s_delay_alu instid0(VALU_DEP_2)                            // 0000003363A0: BF870002
	v_lshlrev_b32_e32 v5, 2, v0                                // 0000003363A4: 300A0082
	s_and_b32 s0, s0, vcc_lo                                   // 0000003363A8: 8B006A00
	s_waitcnt lgkmcnt(0)                                       // 0000003363AC: BF89FC07
	v_add_f32_e32 v0, v1, v4                                   // 0000003363B0: 06000901
	ds_bpermute_b32 v3, v5, v2                                 // 0000003363B4: DACC0000 03000205
	ds_bpermute_b32 v1, v5, v0                                 // 0000003363BC: DACC0000 01000005
	s_and_saveexec_b32 s1, s0                                  // 0000003363C4: BE812000
	s_cbranch_execz 35                                         // 0000003363C8: BFA50023 <_ZN7halogen12_GLOBAL__N_16k_lq6wILi2ELi16ELi1EEEvPKhPKtPtll+0xf58>
	s_waitcnt lgkmcnt(1)                                       // 0000003363CC: BF89FC17
	v_add_f32_e32 v2, v2, v3                                   // 0000003363D0: 06040702
	.long 0x7f063880                                           // 0000003363D4: 7F063880
	s_waitcnt lgkmcnt(0)                                       // 0000003363D8: BF89FC07
	v_add_f32_e32 v4, v0, v1                                   // 0000003363DC: 06080300
	.long 0xd73c0000                                           // 0000003363E0: D73C0000
	v_cndmask_b32_e32 v1, 1, v8, vcc_lo                        // 0000003363E4: 02021081
	s_lshl_b64 s[0:1], s[2:3], 1                               // 0000003363E8: 84808102
	.long 0x7e0a3982                                           // 0000003363EC: 7E0A3982
	.long 0x7f0a3983                                           // 0000003363F0: 7F0A3983
	.long 0x7e063984                                           // 0000003363F4: 7E063984
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003363F8: BF870194
	.long 0xd7006a00                                           // 0000003363FC: D7006A00
	v_cndmask_b32_e32 v1, s8, v0, vcc_lo                       // 000000336400: 02020008
	v_and_b32_e32 v5, 1, v5                                    // 000000336404: 360A0A81
	v_add_co_ci_u32_e64 v1, null, s9, v1, vcc_lo               // 000000336408: D5207C01 01AA0209
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000336410: BF870194
	v_and_b32_e32 v6, 1, v3                                    // 000000336414: 360C0681
	v_add3_u32 v5, v2, v5, 0x7fff                              // 000000336418: D6550005 03FE0B02 00007FFF
	.long 0xd7006a02                                           // 000000336424: D7006A02
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 000000336428: 02000100
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000033642C: BF870211
	v_add_co_ci_u32_e64 v3, null, s1, v1, vcc_lo               // 000000336430: D5207C03 01AA0201
	v_add3_u32 v4, v4, v6, 0x7fff                              // 000000336438: D6550004 03FE0D04 00007FFF
	s_clause 0x1                                               // 000000336444: BF850001
	global_store_d16_hi_b16 v[0:1], v5, off                    // 000000336448: DC960000 007C0500
	global_store_d16_hi_b16 v[2:3], v4, off                    // 000000336450: DC960000 007C0402
	s_endpgm                                                   // 000000336458: BFB00000
		...

