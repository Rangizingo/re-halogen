000000000074d000 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi1ELb1ELi0ELi0EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi1ELb1ELi0ELi0EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 00000074D000: F4100100 F8000000
	s_ashr_i32 s3, s2, 31                                      // 00000074D008: 86039F02
	v_lshrrev_b32_e32 v2, 2, v0                                // 00000074D00C: 32040082
	s_lshl_b64 s[0:1], s[2:3], 3                               // 00000074D010: 84808302
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000074D014: BF8701A9
	v_dual_mov_b32 v10, s1 :: v_dual_and_b32 v1, 15, v0        // 00000074D018: CA240001 0A00008F
	.long 0x7f103880                                           // 00000074D020: 7F103880
	v_and_b32_e32 v2, 60, v2                                   // 00000074D024: 360404BC
	s_delay_alu instid0(VALU_DEP_3)                            // 00000074D028: BF870003
	v_dual_mov_b32 v18, 0 :: v_dual_lshlrev_b32 v1, 2, v1      // 00000074D02C: CA220080 12000282
	v_dual_mov_b32 v3, 0 :: v_dual_and_b32 v16, 31, v0         // 00000074D034: CA240080 0310009F
	v_mov_b32_e32 v17, 0                                       // 00000074D03C: 7E220280
	s_waitcnt lgkmcnt(0)                                       // 00000074D040: BF89FC07
	s_clause 0x1                                               // 00000074D044: BF850001
	global_load_b32 v4, v1, s[4:5]                             // 00000074D048: DC520000 04040001
	global_load_b32 v7, v2, s[4:5]                             // 00000074D050: DC520000 07040002
	v_lshrrev_b32_e32 v2, 5, v0                                // 00000074D058: 32040085
	s_add_u32 s2, s4, s14                                      // 00000074D05C: 80020E04
	s_addc_u32 s3, s5, s15                                     // 00000074D060: 82030F05
	v_mov_b32_e32 v1, 0                                        // 00000074D064: 7E020280
	s_delay_alu instid0(VALU_DEP_2)                            // 00000074D068: BF870002
	v_or_b32_e32 v9, s0, v2                                    // 00000074D06C: 38120400
	s_lshr_b32 s0, s11, 31                                     // 00000074D070: 85009F0B
	v_mov_b32_e32 v2, 0                                        // 00000074D074: 7E040280
	s_add_u32 s14, s10, s0                                     // 00000074D078: 800E000A
	s_addc_u32 s15, s11, 0                                     // 00000074D07C: 820F800B
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[9:10]                 // 00000074D080: 7CA8120C
	s_ashr_i32 s20, s11, 31                                    // 00000074D084: 86149F0B
	v_cndmask_b32_e32 v11, 0, v9, vcc_lo                       // 00000074D088: 02161280
	v_cndmask_b32_e64 v14, 0, s1, vcc_lo                       // 00000074D08C: D501000E 01A80280
	s_ashr_i64 s[0:1], s[14:15], 1                             // 00000074D094: 8680810E
	s_lshr_b32 s14, s20, 27                                    // 00000074D098: 850E9B14
	s_delay_alu instid0(VALU_DEP_1)                            // 00000074D09C: BF870001
	.long 0xd72c0014                                           // 00000074D0A0: D72C0014
	v_cndmask_b32_e32 v0, v14, v0, vcc_lo                      // 00000074D0A4: 0200010E
	.long 0xd72c000e                                           // 00000074D0A8: D72C000E
	v_cndmask_b32_e32 v1, s18, v14, vcc_lo                     // 00000074D0AC: 02021C12
	s_waitcnt vmcnt(1)                                         // 00000074D0B0: BF8907F7
	v_bfe_u32 v12, v4, 16, 1                                   // 00000074D0B4: D610000C 02052104
	s_waitcnt vmcnt(0)                                         // 00000074D0BC: BF8903F7
	v_bfe_u32 v19, v7, 16, 1                                   // 00000074D0C0: D6100013 02052107
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000074D0C8: BF870112
	v_add3_u32 v4, v4, v12, 0x7fff                             // 00000074D0CC: D6550004 03FE1904 00007FFF
	v_add3_u32 v7, v7, v19, 0x7fff                             // 00000074D0D8: D6550007 03FE2707 00007FFF
	v_lshlrev_b32_e32 v19, 2, v0                               // 00000074D0E4: 30260082
	s_delay_alu instid0(VALU_DEP_3)                            // 00000074D0E8: BF870003
	.long 0x7e103984                                           // 00000074D0EC: 7E103984
	v_mov_b32_e32 v4, 0                                        // 00000074D0F0: 7E080280
	.long 0xd72c000d                                           // 00000074D0F4: D72C000D
	v_cndmask_b32_e32 v1, s19, v11, vcc_lo                     // 00000074D0F8: 02021613
	v_mad_u64_u32 v[5:6], null, s18, v11, 0                    // 00000074D0FC: D6FE7C05 02021612
	.long 0xd72c000f                                           // 00000074D104: D72C000F
	v_cndmask_b32_e32 v0, v11, v1, vcc_lo                      // 00000074D108: 0200030B
	v_mad_u64_u32 v[11:12], null, v11, s0, s[2:3]              // 00000074D10C: D6FE7C0B 0008010B
	s_add_u32 s2, s10, s14                                     // 00000074D114: 80020E0A
	s_addc_u32 s3, s11, 0                                      // 00000074D118: 8203800B
	v_and_or_b32 v7, 0xffff0000, v7, v8                        // 00000074D11C: D6570007 04220EFF FFFF0000
	s_lshr_b64 s[2:3], s[2:3], 5                               // 00000074D128: 85828502
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000074D12C: BF870009
	.long 0xd4440000                                           // 00000074D130: D4440000
	v_cndmask_b32_e32 v1, s2, v16, vcc_lo                      // 00000074D134: 02022002
	v_add3_u32 v6, v6, v14, v13                                // 00000074D138: D6550006 04361D06
	v_add3_u32 v0, v20, v12, v15                               // 00000074D140: D6550000 043E1914
	ds_store_b32 v19, v7                                       // 00000074D148: D8340000 00000713
	s_waitcnt lgkmcnt(0)                                       // 00000074D150: BF89FC07
	s_barrier                                                  // 00000074D154: BFBD0000
	buffer_gl0_inv                                             // 00000074D158: E0AC0000 00000000
	s_and_saveexec_b32 s3, s0                                  // 00000074D160: BE832000
	s_cbranch_execz 26                                         // 00000074D164: BFA5001A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi1ELb1ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x1d0>
	s_add_u32 s1, s4, s16                                      // 00000074D168: 80011004
	s_addc_u32 s14, s5, s17                                    // 00000074D16C: 820E1105
	v_lshlrev_b32_e32 v1, 1, v16                               // 00000074D170: 30022081
	.long 0xd7000102                                           // 00000074D174: D7000102
	v_cndmask_b32_e32 v1, s1, v5, vcc_lo                       // 00000074D178: 02020A01
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000074D17C: BF8701A1
	v_add_co_ci_u32_e64 v3, null, s14, v6, s1                  // 00000074D180: D5207C03 00060C0E
	v_lshlrev_b32_e32 v4, 4, v16                               // 00000074D188: 30082084
	.long 0xd7000101                                           // 00000074D18C: D7000101
	v_cndmask_b32_e32 v1, v2, v1, vcc_lo                       // 00000074D190: 02020302
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000074D194: BF870191
	v_add_co_ci_u32_e64 v2, null, 0, v3, s1                    // 00000074D198: D5207C02 00060680
	.long 0xd7000103                                           // 00000074D1A0: D7000103
	v_cndmask_b32_e32 v1, v11, v4, vcc_lo                      // 00000074D1A4: 0202090B
	s_delay_alu instid0(VALU_DEP_1)                            // 00000074D1A8: BF870001
	v_add_co_ci_u32_e64 v4, null, 0, v0, s1                    // 00000074D1AC: D5207C04 00060080
	s_clause 0x1                                               // 00000074D1B4: BF850001
	global_load_d16_b16 v7, v[1:2], off                        // 00000074D1B8: DC820000 077C0001
	global_load_b128 v[1:4], v[3:4], off                       // 00000074D1C0: DC5E0000 017C0003
	s_waitcnt vmcnt(1)                                         // 00000074D1C8: BF8907F7
	v_cvt_f32_f16_e32 v18, v7                                  // 00000074D1CC: 7E241707
	s_or_b32 exec_lo, exec_lo, s3                              // 00000074D1D0: 8C7E037E
	v_dual_mov_b32 v19, 0 :: v_dual_mov_b32 v20, 0             // 00000074D1D4: CA100080 13140080
	v_mov_b32_e32 v21, 0                                       // 00000074D1DC: 7E2A0280
	s_and_saveexec_b32 s3, s0                                  // 00000074D1E0: BE832000
	s_cbranch_execz 382                                        // 00000074D1E4: BFA5017E <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi1ELb1ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x7e0>
	s_mul_i32 s0, s11, 6                                       // 00000074D1E8: 9600860B
	s_mul_hi_u32 s1, s10, 6                                    // 00000074D1EC: 9681860A
	v_dual_mov_b32 v13, 0 :: v_dual_lshlrev_b32 v12, 5, v16    // 00000074D1F0: CA220080 0D0C2085
	s_add_i32 s18, s1, s0                                      // 00000074D1F8: 81120001
	v_lshlrev_b32_e32 v7, 1, v16                               // 00000074D1FC: 300E2081
	.long 0xd7000005                                           // 00000074D200: D7000005
	v_cndmask_b32_e32 v1, s16, v5, vcc_lo                      // 00000074D204: 02020A10
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000074D208: BF8701A1
	v_add_co_ci_u32_e64 v6, null, s17, v6, s0                  // 00000074D20C: D5207C06 00020C11
	v_mov_b32_e32 v20, v13                                     // 00000074D214: 7E28030D
	.long 0xd7000005                                           // 00000074D218: D7000005
	v_cndmask_b32_e32 v1, v5, v7, vcc_lo                       // 00000074D21C: 02020F05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000074D220: BF8701A1
	v_add_co_ci_u32_e64 v6, null, 0, v6, s0                    // 00000074D224: D5207C06 00020C80
	v_lshl_or_b32 v22, v16, 4, 0x200                           // 00000074D22C: D6560016 03FD0910 00000200
	.long 0xd7000005                                           // 00000074D238: D7000005
	v_cndmask_b32_e32 v1, s4, v5, vcc_lo                       // 00000074D23C: 02020A04
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000074D240: BF8701A1
	v_add_co_ci_u32_e64 v6, null, s5, v6, s0                   // 00000074D244: D5207C06 00020C05
	v_dual_mov_b32 v23, v16 :: v_dual_mov_b32 v24, v18         // 00000074D24C: CA100110 17180112
	.long 0xd700000e                                           // 00000074D254: D700000E
	v_cndmask_b32_e32 v0, v5, v192, vcc_lo                     // 00000074D258: 02018105
	s_delay_alu instid0(VALU_DEP_1)                            // 00000074D25C: BF870001
	v_add_co_ci_u32_e64 v15, null, 0, v6, s0                   // 00000074D260: D5207C0F 00020C80
	v_mov_b32_e32 v21, v13                                     // 00000074D268: 7E2A030D
	v_mov_b32_e32 v19, v13                                     // 00000074D26C: 7E26030D
	v_mov_b32_e32 v17, v13                                     // 00000074D270: 7E22030D
	s_lshl_b64 s[14:15], s[10:11], 2                           // 00000074D274: 848E820A
	s_mul_i32 s17, s10, 6                                      // 00000074D278: 9611860A
	s_mov_b32 s16, 0                                           // 00000074D27C: BE900080
	s_lshl_b64 s[4:5], s[10:11], 1                             // 00000074D280: 8484810A
	s_branch 316                                               // 00000074D284: BFA0013C <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi1ELb1ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x778>
	s_or_b32 exec_lo, exec_lo, s10                             // 00000074D288: 8C7E0A7E
	.long 0xd73c0019                                           // 00000074D28C: D73C0019
	v_cndmask_b32_e32 v1, 1, v12, vcc_lo                       // 00000074D290: 02021881
	v_and_b32_e32 v57, 0xff, v1                                // 00000074D294: 367202FF 000000FF
	v_lshrrev_b32_e32 v58, 6, v1                               // 00000074D29C: 32740286
	v_lshrrev_b32_e32 v59, 14, v1                              // 00000074D2A0: 3276028E
	v_lshrrev_b32_e32 v1, 22, v1                               // 00000074D2A4: 32020296
	v_and_b32_e32 v60, 0xff, v2                                // 00000074D2A8: 367804FF 000000FF
	.long 0xd7000149                                           // 00000074D2B0: D7000149
	v_cndmask_b32_e32 v1, s6, v25, vcc_lo                      // 00000074D2B4: 02023206
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000074D2B8: BF8701A1
	v_add_co_ci_u32_e64 v74, null, s7, v26, s1                 // 00000074D2BC: D5207C4A 00063407
	v_lshlrev_b32_e32 v57, 2, v57                              // 00000074D2C4: 30727282
	.long 0xd700014d                                           // 00000074D2C8: D700014D
	v_cndmask_b32_e32 v0, v73, v4, vcc_lo                      // 00000074D2CC: 02000949
	global_load_b128 v[25:28], v[73:74], off                   // 00000074D2D0: DC5E0000 197C0049
	v_add_co_ci_u32_e64 v78, null, s5, v74, s1                 // 00000074D2D8: D5207C4E 00069405
	.long 0xd700014f                                           // 00000074D2E0: D700014F
	v_cndmask_b32_e32 v0, v73, v14, vcc_lo                     // 00000074D2E4: 02001D49
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000074D2E8: BF8700A1
	v_add_co_ci_u32_e64 v80, null, s15, v74, s1                // 00000074D2EC: D5207C50 0006940F
	.long 0xd7000151                                           // 00000074D2F4: D7000151
	v_cndmask_b32_e32 v0, v73, v17, vcc_lo                     // 00000074D2F8: 02002349
	v_add_co_ci_u32_e64 v82, null, s18, v74, s1                // 00000074D2FC: D5207C52 00069412
	s_clause 0x6                                               // 00000074D304: BF850006
	global_load_b128 v[29:32], v[77:78], off                   // 00000074D308: DC5E0000 1D7C004D
	global_load_b128 v[33:36], v[79:80], off                   // 00000074D310: DC5E0000 217C004F
	global_load_b128 v[37:40], v[81:82], off                   // 00000074D318: DC5E0000 257C0051
	global_load_b128 v[41:44], v[73:74], off offset:16         // 00000074D320: DC5E0010 297C0049
	global_load_b128 v[45:48], v[77:78], off offset:16         // 00000074D328: DC5E0010 2D7C004D
	global_load_b128 v[49:52], v[79:80], off offset:16         // 00000074D330: DC5E0010 317C004F
	global_load_b128 v[53:56], v[81:82], off offset:16         // 00000074D338: DC5E0010 357C0051
	v_and_b32_e32 v58, 0x3fc, v58                              // 00000074D340: 367474FF 000003FC
	ds_load_b32 v75, v57                                       // 00000074D348: D8D80000 4B000039
	v_lshrrev_b32_e32 v61, 6, v2                               // 00000074D350: 327A0486
	v_lshrrev_b32_e32 v62, 14, v2                              // 00000074D354: 327C048E
	v_lshrrev_b32_e32 v2, 22, v2                               // 00000074D358: 32040496
	ds_load_b32 v83, v58                                       // 00000074D35C: D8D80000 5300003A
	v_and_b32_e32 v57, 0x3fc, v59                              // 00000074D364: 367276FF 000003FC
	v_and_b32_e32 v1, 0x3fc, v1                                // 00000074D36C: 360202FF 000003FC
	v_lshlrev_b32_e32 v76, 2, v60                              // 00000074D374: 30987882
	v_and_b32_e32 v84, 0x3fc, v61                              // 00000074D378: 36A87AFF 000003FC
	v_and_b32_e32 v88, 0x3fc, v62                              // 00000074D380: 36B07CFF 000003FC
	ds_load_b32 v89, v57                                       // 00000074D388: D8D80000 59000039
	s_clause 0x3                                               // 00000074D390: BF850003
	global_load_b128 v[57:60], v[73:74], off offset:32         // 00000074D394: DC5E0020 397C0049
	global_load_b128 v[61:64], v[77:78], off offset:32         // 00000074D39C: DC5E0020 3D7C004D
	global_load_b128 v[65:68], v[79:80], off offset:32         // 00000074D3A4: DC5E0020 417C004F
	global_load_b128 v[69:72], v[81:82], off offset:32         // 00000074D3AC: DC5E0020 457C0051
	v_and_b32_e32 v2, 0x3fc, v2                                // 00000074D3B4: 360404FF 000003FC
	ds_load_b32 v1, v1                                         // 00000074D3BC: D8D80000 01000001
	ds_load_b32 v90, v76                                       // 00000074D3C4: D8D80000 5A00004C
	ds_load_b32 v91, v84                                       // 00000074D3CC: D8D80000 5B000054
	ds_load_b32 v88, v88                                       // 00000074D3D4: D8D80000 58000058
	ds_load_b32 v2, v2                                         // 00000074D3DC: D8D80000 02000002
	v_and_b32_e32 v85, 0xff, v3                                // 00000074D3E4: 36AA06FF 000000FF
	v_lshrrev_b32_e32 v86, 6, v3                               // 00000074D3EC: 32AC0686
	v_lshrrev_b32_e32 v87, 14, v3                              // 00000074D3F0: 32AE068E
	v_lshrrev_b32_e32 v3, 22, v3                               // 00000074D3F4: 32060696
	v_and_b32_e32 v92, 0xff, v4                                // 00000074D3F8: 36B808FF 000000FF
	v_lshrrev_b32_e32 v93, 6, v4                               // 00000074D400: 32BA0886
	v_lshrrev_b32_e32 v94, 14, v4                              // 00000074D404: 32BC088E
	v_lshrrev_b32_e32 v4, 22, v4                               // 00000074D408: 32080896
	v_and_b32_e32 v3, 0x3fc, v3                                // 00000074D40C: 360606FF 000003FC
	s_and_b32 s1, exec_lo, s0                                  // 00000074D414: 8B01007E
	.long 0xd700000e                                           // 00000074D418: D700000E
	v_cndmask_b32_e32 v0, v14, v192, vcc_lo                    // 00000074D41C: 0201810E
	s_delay_alu instid0(VALU_DEP_3)                            // 00000074D420: BF870003
	v_and_b32_e32 v4, 0x3fc, v4                                // 00000074D424: 360808FF 000003FC
	v_add_nc_u32_e32 v12, 0x400, v12                           // 00000074D42C: 4A1818FF 00000400
	v_add_nc_u32_e32 v22, 0x200, v22                           // 00000074D434: 4A2C2CFF 00000200
	v_add_co_ci_u32_e64 v15, null, 0, v15, s0                  // 00000074D43C: D5207C0F 00021E80
	s_or_b32 s16, s1, s16                                      // 00000074D444: 8C101001
	s_waitcnt vmcnt(11) lgkmcnt(7)                             // 00000074D448: BF892C77
	v_dot2_f32_bf16 v25, v25, v75, 0                           // 00000074D44C: CC1A4019 1A029719
	s_waitcnt lgkmcnt(6)                                       // 00000074D454: BF89FC67
	s_delay_alu instid0(VALU_DEP_1)                            // 00000074D458: BF870001
	v_dot2_f32_bf16 v25, v26, v83, v25                         // 00000074D45C: CC1A4019 1C66A71A
	s_waitcnt vmcnt(10)                                        // 00000074D464: BF892BF7
	v_dot2_f32_bf16 v26, v29, v75, 0                           // 00000074D468: CC1A401A 1A02971D
	s_waitcnt vmcnt(9)                                         // 00000074D470: BF8927F7
	v_dot2_f32_bf16 v29, v33, v75, 0                           // 00000074D474: CC1A401D 1A029721
	s_waitcnt vmcnt(8)                                         // 00000074D47C: BF8923F7
	v_dot2_f32_bf16 v33, v37, v75, 0                           // 00000074D480: CC1A4021 1A029725
	s_waitcnt lgkmcnt(5)                                       // 00000074D488: BF89FC57
	v_dot2_f32_bf16 v25, v27, v89, v25                         // 00000074D48C: CC1A4019 1C66B31B
	global_load_b128 v[73:76], v[73:74], off offset:48         // 00000074D494: DC5E0030 497C0049
	v_dot2_f32_bf16 v30, v30, v83, v26                         // 00000074D49C: CC1A401E 1C6AA71E
	v_dot2_f32_bf16 v29, v34, v83, v29                         // 00000074D4A4: CC1A401D 1C76A722
	v_dot2_f32_bf16 v33, v38, v83, v33                         // 00000074D4AC: CC1A4021 1C86A726
	s_waitcnt lgkmcnt(4)                                       // 00000074D4B4: BF89FC47
	v_dot2_f32_bf16 v34, v28, v1, v25                          // 00000074D4B8: CC1A4022 1C66031C
	s_clause 0x2                                               // 00000074D4C0: BF850002
	global_load_b128 v[25:28], v[77:78], off offset:48         // 00000074D4C4: DC5E0030 197C004D
	global_load_b128 v[77:80], v[79:80], off offset:48         // 00000074D4CC: DC5E0030 4D7C004F
	global_load_b128 v[81:84], v[81:82], off offset:48         // 00000074D4D4: DC5E0030 517C0051
	v_dot2_f32_bf16 v30, v31, v89, v30                         // 00000074D4DC: CC1A401E 1C7AB31F
	v_dot2_f32_bf16 v29, v35, v89, v29                         // 00000074D4E4: CC1A401D 1C76B323
	v_dot2_f32_bf16 v31, v39, v89, v33                         // 00000074D4EC: CC1A401F 1C86B327
	v_lshlrev_b32_e32 v33, 2, v85                              // 00000074D4F4: 3042AA82
	v_and_b32_e32 v35, 0x3fc, v86                              // 00000074D4F8: 3646ACFF 000003FC
	v_dot2_f32_bf16 v30, v32, v1, v30                          // 00000074D500: CC1A401E 1C7A0320
	v_dot2_f32_bf16 v29, v36, v1, v29                          // 00000074D508: CC1A401D 1C760324
	v_dot2_f32_bf16 v1, v40, v1, v31                           // 00000074D510: CC1A4001 1C7E0328
	v_and_b32_e32 v37, 0x3fc, v87                              // 00000074D518: 364AAEFF 000003FC
	s_waitcnt vmcnt(11) lgkmcnt(3)                             // 00000074D520: BF892C37
	v_dot2_f32_bf16 v31, v41, v90, v34                         // 00000074D524: CC1A401F 1C8AB529
	s_waitcnt vmcnt(10)                                        // 00000074D52C: BF892BF7
	v_dot2_f32_bf16 v30, v45, v90, v30                         // 00000074D530: CC1A401E 1C7AB52D
	s_waitcnt vmcnt(9)                                         // 00000074D538: BF8927F7
	v_dot2_f32_bf16 v29, v49, v90, v29                         // 00000074D53C: CC1A401D 1C76B531
	s_waitcnt vmcnt(8)                                         // 00000074D544: BF8923F7
	v_dot2_f32_bf16 v1, v53, v90, v1                           // 00000074D548: CC1A4001 1C06B535
	ds_load_b32 v32, v33                                       // 00000074D550: D8D80000 20000021
	ds_load_b32 v34, v37                                       // 00000074D558: D8D80000 22000025
	s_waitcnt lgkmcnt(4)                                       // 00000074D560: BF89FC47
	v_dot2_f32_bf16 v31, v42, v91, v31                         // 00000074D564: CC1A401F 1C7EB72A
	v_dot2_f32_bf16 v30, v46, v91, v30                         // 00000074D56C: CC1A401E 1C7AB72E
	v_dot2_f32_bf16 v29, v50, v91, v29                         // 00000074D574: CC1A401D 1C76B732
	v_dot2_f32_bf16 v1, v54, v91, v1                           // 00000074D57C: CC1A4001 1C06B736
	ds_load_b32 v33, v35                                       // 00000074D584: D8D80000 21000023
	s_waitcnt lgkmcnt(4)                                       // 00000074D58C: BF89FC47
	v_dot2_f32_bf16 v31, v43, v88, v31                         // 00000074D590: CC1A401F 1C7EB12B
	v_dot2_f32_bf16 v30, v47, v88, v30                         // 00000074D598: CC1A401E 1C7AB12F
	v_dot2_f32_bf16 v29, v51, v88, v29                         // 00000074D5A0: CC1A401D 1C76B133
	v_dot2_f32_bf16 v1, v55, v88, v1                           // 00000074D5A8: CC1A4001 1C06B137
	v_lshlrev_b32_e32 v38, 2, v92                              // 00000074D5B0: 304CB882
	s_waitcnt lgkmcnt(3)                                       // 00000074D5B4: BF89FC37
	v_dot2_f32_bf16 v31, v44, v2, v31                          // 00000074D5B8: CC1A401F 1C7E052C
	v_dot2_f32_bf16 v30, v48, v2, v30                          // 00000074D5C0: CC1A401E 1C7A0530
	v_dot2_f32_bf16 v29, v52, v2, v29                          // 00000074D5C8: CC1A401D 1C760534
	v_dot2_f32_bf16 v1, v56, v2, v1                            // 00000074D5D0: CC1A4001 1C060538
	v_and_b32_e32 v39, 0x3fc, v93                              // 00000074D5D8: 364EBAFF 000003FC
	v_and_b32_e32 v85, 0x3fc, v94                              // 00000074D5E0: 36AABCFF 000003FC
	ds_load_b32 v2, v3                                         // 00000074D5E8: D8D80000 02000003
	ds_load_b32 v3, v38                                        // 00000074D5F0: D8D80000 03000026
	ds_load_b32 v35, v39                                       // 00000074D5F8: D8D80000 23000027
	ds_load_b32 v36, v85                                       // 00000074D600: D8D80000 24000055
	ds_load_b32 v37, v4                                        // 00000074D608: D8D80000 25000004
	s_waitcnt vmcnt(7) lgkmcnt(7)                              // 00000074D610: BF891C77
	v_dot2_f32_bf16 v4, v57, v32, v31                          // 00000074D614: CC1A4004 1C7E4139
	s_waitcnt vmcnt(6)                                         // 00000074D61C: BF891BF7
	v_dot2_f32_bf16 v30, v61, v32, v30                         // 00000074D620: CC1A401E 1C7A413D
	s_waitcnt vmcnt(5)                                         // 00000074D628: BF8917F7
	v_dot2_f32_bf16 v29, v65, v32, v29                         // 00000074D62C: CC1A401D 1C764141
	s_waitcnt vmcnt(4)                                         // 00000074D634: BF8913F7
	v_dot2_f32_bf16 v1, v69, v32, v1                           // 00000074D638: CC1A4001 1C064145
	s_waitcnt lgkmcnt(5)                                       // 00000074D640: BF89FC57
	v_dot2_f32_bf16 v4, v58, v33, v4                           // 00000074D644: CC1A4004 1C12433A
	v_dot2_f32_bf16 v30, v62, v33, v30                         // 00000074D64C: CC1A401E 1C7A433E
	v_dot2_f32_bf16 v29, v66, v33, v29                         // 00000074D654: CC1A401D 1C764342
	v_dot2_f32_bf16 v1, v70, v33, v1                           // 00000074D65C: CC1A4001 1C064346
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000074D664: BF870214
	v_dot2_f32_bf16 v4, v59, v34, v4                           // 00000074D668: CC1A4004 1C12453B
	v_dot2_f32_bf16 v30, v63, v34, v30                         // 00000074D670: CC1A401E 1C7A453F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000074D678: BF870214
	v_dot2_f32_bf16 v29, v67, v34, v29                         // 00000074D67C: CC1A401D 1C764543
	v_dot2_f32_bf16 v1, v71, v34, v1                           // 00000074D684: CC1A4001 1C064547
	s_waitcnt lgkmcnt(4)                                       // 00000074D68C: BF89FC47
	v_dot2_f32_bf16 v4, v60, v2, v4                            // 00000074D690: CC1A4004 1C12053C
	v_dot2_f32_bf16 v30, v64, v2, v30                          // 00000074D698: CC1A401E 1C7A0540
	v_dot2_f32_bf16 v29, v68, v2, v29                          // 00000074D6A0: CC1A401D 1C760544
	v_dot2_f32_bf16 v1, v72, v2, v1                            // 00000074D6A8: CC1A4001 1C060548
	s_waitcnt vmcnt(3) lgkmcnt(3)                              // 00000074D6B0: BF890C37
	v_dot2_f32_bf16 v2, v73, v3, v4                            // 00000074D6B4: CC1A4002 1C120749
	v_mov_b32_e32 v4, v8                                       // 00000074D6BC: 7E080308
	s_waitcnt vmcnt(2)                                         // 00000074D6C0: BF890BF7
	v_dot2_f32_bf16 v25, v25, v3, v30                          // 00000074D6C4: CC1A4019 1C7A0719
	s_waitcnt vmcnt(1)                                         // 00000074D6CC: BF8907F7
	v_dot2_f32_bf16 v29, v77, v3, v29                          // 00000074D6D0: CC1A401D 1C76074D
	s_waitcnt vmcnt(0)                                         // 00000074D6D8: BF8903F7
	v_dot2_f32_bf16 v1, v81, v3, v1                            // 00000074D6DC: CC1A4001 1C060751
	s_waitcnt lgkmcnt(2)                                       // 00000074D6E4: BF89FC27
	v_dot2_f32_bf16 v2, v74, v35, v2                           // 00000074D6E8: CC1A4002 1C0A474A
	v_mov_b32_e32 v3, v7                                       // 00000074D6F0: 7E060307
	v_dot2_f32_bf16 v8, v26, v35, v25                          // 00000074D6F4: CC1A4008 1C66471A
	v_dot2_f32_bf16 v25, v78, v35, v29                         // 00000074D6FC: CC1A4019 1C76474E
	v_dot2_f32_bf16 v1, v82, v35, v1                           // 00000074D704: CC1A4001 1C064752
	s_waitcnt lgkmcnt(1)                                       // 00000074D70C: BF89FC17
	v_dot2_f32_bf16 v7, v75, v36, v2                           // 00000074D710: CC1A4007 1C0A494B
	v_mov_b32_e32 v2, v6                                       // 00000074D718: 7E040306
	v_dot2_f32_bf16 v8, v27, v36, v8                           // 00000074D71C: CC1A4008 1C22491B
	v_dot2_f32_bf16 v25, v79, v36, v25                         // 00000074D724: CC1A4019 1C66494F
	v_dot2_f32_bf16 v1, v83, v36, v1                           // 00000074D72C: CC1A4001 1C064953
	s_waitcnt lgkmcnt(0)                                       // 00000074D734: BF89FC07
	v_dot2_f32_bf16 v6, v76, v37, v7                           // 00000074D738: CC1A4006 1C1E4B4C
	v_dot2_f32_bf16 v7, v28, v37, v8                           // 00000074D740: CC1A4007 1C224B1C
	v_dot2_f32_bf16 v8, v80, v37, v25                          // 00000074D748: CC1A4008 1C664B50
	v_dot2_f32_bf16 v25, v84, v37, v1                          // 00000074D750: CC1A4019 1C064B54
	v_mov_b32_e32 v1, v5                                       // 00000074D758: 7E020305
	v_fmac_f32_e32 v21, v18, v6                                // 00000074D75C: 562A0D12
	v_fmac_f32_e32 v20, v18, v7                                // 00000074D760: 56280F12
	v_fmac_f32_e32 v19, v18, v8                                // 00000074D764: 56261112
	v_dual_fmac_f32 v17, v18, v25 :: v_dual_mov_b32 v18, v24   // 00000074D768: C8103312 11120118
	s_and_not1_b32 exec_lo, exec_lo, s16                       // 00000074D770: 917E107E
	s_cbranch_execz 25                                         // 00000074D774: BFA50019 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi1ELb1ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x7dc>
	s_waitcnt vmcnt(0)                                         // 00000074D778: BF8903F7
	v_dual_mov_b32 v6, v2 :: v_dual_add_nc_u32 v23, 32, v23    // 00000074D77C: CA200102 06162EA0
	v_dual_mov_b32 v5, v1 :: v_dual_mov_b32 v8, v4             // 00000074D784: CA100101 05080104
	v_mov_b32_e32 v7, v3                                       // 00000074D78C: 7E0E0303
	s_delay_alu instid0(VALU_DEP_3)                            // 00000074D790: BF870003
	.long 0xd4430000                                           // 00000074D794: D4430000
	v_cndmask_b32_e32 v1, s2, v23, vcc_lo                      // 00000074D798: 02022E02
	s_mov_b32 s10, exec_lo                                     // 00000074D79C: BE8A007E
	.long 0xd4c4007e                                           // 00000074D7A0: D4C4007E
	v_cndmask_b32_e32 v1, s2, v23, vcc_lo                      // 00000074D7A4: 02022E02
	s_cbranch_execz 65207                                      // 00000074D7A8: BFA5FEB7 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi1ELb1ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x288>
	.long 0xd7000105                                           // 00000074D7AC: D7000105
	v_cndmask_b32_e32 v1, v11, v22, vcc_lo                     // 00000074D7B0: 02022D0B
	s_delay_alu instid0(VALU_DEP_1)                            // 00000074D7B4: BF870001
	v_add_co_ci_u32_e64 v6, null, 0, v0, s1                    // 00000074D7B8: D5207C06 00060080
	global_load_d16_b16 v24, v[14:15], off                     // 00000074D7C0: DC820000 187C000E
	global_load_b128 v[5:8], v[5:6], off                       // 00000074D7C8: DC5E0000 057C0005
	s_waitcnt vmcnt(1)                                         // 00000074D7D0: BF8907F7
	v_cvt_f32_f16_e32 v24, v24                                 // 00000074D7D4: 7E301718
	s_branch 65195                                             // 00000074D7D8: BFA0FEAB <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi1ELb1ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x288>
	s_or_b32 exec_lo, exec_lo, s16                             // 00000074D7DC: 8C7E107E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000074D7E0: BF8700B9
	s_or_b32 exec_lo, exec_lo, s3                              // 00000074D7E4: 8C7E037E
	.long 0xd71f0000                                           // 00000074D7E8: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 00000074D7EC: 020100C1
	s_waitcnt vmcnt(0)                                         // 00000074D7F0: BF8903F7
	v_xor_b32_e32 v1, 16, v0                                   // 00000074D7F4: 3A020090
	v_xor_b32_e32 v5, 8, v0                                    // 00000074D7F8: 3A0A0088
	v_xor_b32_e32 v11, 4, v0                                   // 00000074D7FC: 3A160084
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000074D800: BF870093
	.long 0xd44c0000                                           // 00000074D804: D44C0000
	v_cndmask_b32_e32 v1, 32, v1, vcc_lo                       // 00000074D808: 020202A0
	v_cndmask_b32_e64 v1, v0, v1, s0                           // 00000074D80C: D5010001 00020300
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000074D814: BF870114
	.long 0xd44c0000                                           // 00000074D818: D44C0000
	v_cndmask_b32_e32 v1, 32, v5, vcc_lo                       // 00000074D81C: 02020AA0
	v_lshlrev_b32_e32 v1, 2, v1                                // 00000074D820: 30020282
	s_delay_alu instid0(VALU_DEP_2)                            // 00000074D824: BF870002
	v_cndmask_b32_e64 v5, v0, v5, s0                           // 00000074D828: D5010005 00020B00
	.long 0xd44c0000                                           // 00000074D830: D44C0000
	v_cndmask_b32_e32 v1, 32, v11, vcc_lo                      // 00000074D834: 020216A0
	ds_bpermute_b32 v2, v1, v21                                // 00000074D838: DACC0000 02001501
	v_cndmask_b32_e64 v11, v0, v11, s0                         // 00000074D840: D501000B 00021700
	s_waitcnt lgkmcnt(0)                                       // 00000074D848: BF89FC07
	v_add_f32_e32 v2, v21, v2                                  // 00000074D84C: 06040515
	ds_bpermute_b32 v4, v1, v19                                // 00000074D850: DACC0000 04001301
	ds_bpermute_b32 v3, v1, v20                                // 00000074D858: DACC0000 03001401
	ds_bpermute_b32 v1, v1, v17                                // 00000074D860: DACC0000 01001101
	s_waitcnt lgkmcnt(2)                                       // 00000074D868: BF89FC27
	v_dual_add_f32 v4, v19, v4 :: v_dual_lshlrev_b32 v5, 2, v5 // 00000074D86C: C9220913 04040A82
	ds_bpermute_b32 v6, v5, v2                                 // 00000074D874: DACC0000 06000205
	s_waitcnt lgkmcnt(2)                                       // 00000074D87C: BF89FC27
	v_add_f32_e32 v3, v20, v3                                  // 00000074D880: 06060714
	ds_bpermute_b32 v8, v5, v4                                 // 00000074D884: DACC0000 08000405
	s_waitcnt lgkmcnt(1)                                       // 00000074D88C: BF89FC17
	v_dual_add_f32 v1, v17, v1 :: v_dual_add_f32 v2, v2, v6    // 00000074D890: C9080311 01020D02
	ds_bpermute_b32 v7, v5, v3                                 // 00000074D898: DACC0000 07000305
	s_waitcnt lgkmcnt(1)                                       // 00000074D8A0: BF89FC17
	v_dual_add_f32 v4, v4, v8 :: v_dual_lshlrev_b32 v11, 2, v11// 00000074D8A4: C9221104 040A1682
	ds_bpermute_b32 v5, v5, v1                                 // 00000074D8AC: DACC0000 05000105
	s_waitcnt lgkmcnt(0)                                       // 00000074D8B4: BF89FC07
	v_add_f32_e32 v1, v1, v5                                   // 00000074D8B8: 06020B01
	ds_bpermute_b32 v5, v11, v2                                // 00000074D8BC: DACC0000 0500020B
	s_waitcnt lgkmcnt(0)                                       // 00000074D8C4: BF89FC07
	v_dual_add_f32 v2, v2, v5 :: v_dual_add_f32 v3, v3, v7     // 00000074D8C8: C9080B02 02020F03
	ds_bpermute_b32 v7, v11, v4                                // 00000074D8D0: DACC0000 0700040B
	ds_bpermute_b32 v8, v11, v1                                // 00000074D8D8: DACC0000 0800010B
	ds_bpermute_b32 v6, v11, v3                                // 00000074D8E0: DACC0000 0600030B
	v_xor_b32_e32 v11, 2, v0                                   // 00000074D8E8: 3A160082
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000074D8EC: BF870091
	.long 0xd44c0000                                           // 00000074D8F0: D44C0000
	v_cndmask_b32_e32 v1, 32, v11, vcc_lo                      // 00000074D8F4: 020216A0
	v_cndmask_b32_e64 v11, v0, v11, s0                         // 00000074D8F8: D501000B 00021700
	s_delay_alu instid0(VALU_DEP_1)                            // 00000074D900: BF870001
	v_lshlrev_b32_e32 v11, 2, v11                              // 00000074D904: 30161682
	s_waitcnt lgkmcnt(2)                                       // 00000074D908: BF89FC27
	v_add_f32_e32 v5, v4, v7                                   // 00000074D90C: 060A0F04
	ds_bpermute_b32 v4, v11, v2                                // 00000074D910: DACC0000 0400020B
	ds_bpermute_b32 v7, v11, v5                                // 00000074D918: DACC0000 0700050B
	s_waitcnt lgkmcnt(1)                                       // 00000074D920: BF89FC17
	v_dual_add_f32 v2, v2, v4 :: v_dual_add_f32 v3, v3, v6     // 00000074D924: C9080902 02020D03
	s_waitcnt lgkmcnt(0)                                       // 00000074D92C: BF89FC07
	v_add_f32_e32 v5, v5, v7                                   // 00000074D930: 060A0F05
	ds_bpermute_b32 v6, v11, v3                                // 00000074D934: DACC0000 0600030B
	s_waitcnt lgkmcnt(0)                                       // 00000074D93C: BF89FC07
	v_dual_add_f32 v4, v3, v6 :: v_dual_add_f32 v1, v1, v8     // 00000074D940: C9080D03 04001101
	ds_bpermute_b32 v8, v11, v1                                // 00000074D948: DACC0000 0800010B
	v_xor_b32_e32 v11, 1, v0                                   // 00000074D950: 3A160081
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000074D954: BF870091
	.long 0xd44c0000                                           // 00000074D958: D44C0000
	v_cndmask_b32_e32 v1, 32, v11, vcc_lo                      // 00000074D95C: 020216A0
	v_cndmask_b32_e64 v0, v0, v11, s0                          // 00000074D960: D5010000 00021700
	.long 0xd44a0000                                           // 00000074D968: D44A0000
	v_cndmask_b32_e32 v1, 0, v16, vcc_lo                       // 00000074D96C: 02022080
	s_delay_alu instid0(VALU_DEP_2)                            // 00000074D970: BF870002
	v_lshlrev_b32_e32 v11, 2, v0                               // 00000074D974: 30160082
	s_and_b32 s0, s0, vcc_lo                                   // 00000074D978: 8B006A00
	s_waitcnt lgkmcnt(0)                                       // 00000074D97C: BF89FC07
	v_add_f32_e32 v0, v1, v8                                   // 00000074D980: 06001101
	ds_bpermute_b32 v3, v11, v2                                // 00000074D984: DACC0000 0300020B
	ds_bpermute_b32 v6, v11, v4                                // 00000074D98C: DACC0000 0600040B
	ds_bpermute_b32 v7, v11, v5                                // 00000074D994: DACC0000 0700050B
	ds_bpermute_b32 v1, v11, v0                                // 00000074D99C: DACC0000 0100000B
	s_and_saveexec_b32 s1, s0                                  // 00000074D9A4: BE812000
	s_cbranch_execz 38                                         // 00000074D9A8: BFA50026 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi1ELb1ELi0ELi0EEEvPKhPKtPvlllllS6_f+0xa44>
	.long 0xd73c0008                                           // 00000074D9AC: D73C0008
	v_cndmask_b32_e32 v1, 2, v9, vcc_lo                        // 00000074D9B0: 02021282
	s_waitcnt lgkmcnt(1)                                       // 00000074D9B4: BF89FC17
	v_dual_add_f32 v10, v5, v7 :: v_dual_add_f32 v11, v4, v6   // 00000074D9B8: C9080F05 0A0A0D04
	s_lshl_b64 s[0:1], s[12:13], 2                             // 00000074D9C0: 8480820C
	v_add_f32_e32 v12, v2, v3                                  // 00000074D9C4: 06180702
	s_lshl_b64 s[2:3], s[12:13], 3                             // 00000074D9C8: 8482830C
	.long 0xd7006a08                                           // 00000074D9CC: D7006A08
	v_cndmask_b32_e32 v1, s8, v8, vcc_lo                       // 00000074D9D0: 02021008
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000074D9D4: BF8701B1
	v_add_co_ci_u32_e64 v9, null, s9, v9, vcc_lo               // 00000074D9D8: D5207C09 01AA1209
	s_waitcnt lgkmcnt(0)                                       // 00000074D9E0: BF89FC07
	v_add_f32_e32 v0, v0, v1                                   // 00000074D9E4: 06000300
	.long 0xd7006a02                                           // 00000074D9E8: D7006A02
	v_cndmask_b32_e32 v0, v8, v0, vcc_lo                       // 00000074D9EC: 02000108
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000074D9F0: BF870123
	v_mad_u64_u32 v[4:5], null, s12, 12, v[8:9]                // 00000074D9F4: D6FE7C04 0421180C
	v_add_co_ci_u32_e64 v3, null, s1, v9, vcc_lo               // 00000074D9FC: D5207C03 01AA1201
	v_mad_u64_u32 v[5:6], null, s13, 12, v[5:6]                // 00000074DA04: D6FE7C05 0415180D
	.long 0xd7006a06                                           // 00000074DA0C: D7006A06
	v_cndmask_b32_e32 v0, v8, v2, vcc_lo                       // 00000074DA10: 02000508
	s_delay_alu instid0(VALU_DEP_1)                            // 00000074DA14: BF870001
	v_add_co_ci_u32_e64 v7, null, s3, v9, vcc_lo               // 00000074DA18: D5207C07 01AA1203
	s_clause 0x3                                               // 00000074DA20: BF850003
	global_store_b32 v[8:9], v12, off                          // 00000074DA24: DC6A0000 007C0C08
	global_store_b32 v[2:3], v11, off                          // 00000074DA2C: DC6A0000 007C0B02
	global_store_b32 v[6:7], v10, off                          // 00000074DA34: DC6A0000 007C0A06
	global_store_b32 v[4:5], v0, off                           // 00000074DA3C: DC6A0000 007C0004
	s_endpgm                                                   // 00000074DA44: BFB00000
		...

