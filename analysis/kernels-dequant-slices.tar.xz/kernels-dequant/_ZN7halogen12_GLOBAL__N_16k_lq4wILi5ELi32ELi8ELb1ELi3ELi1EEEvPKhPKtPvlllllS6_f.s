0000000000847c00 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi8ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi8ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[8:23], s[0:1], null                          // 000000847C00: F4100200 F8000000
	s_ashr_i32 s3, s2, 31                                      // 000000847C08: 86039F02
	v_lshrrev_b32_e32 v2, 2, v0                                // 000000847C0C: 32040082
	v_lshrrev_b32_e32 v29, 5, v0                               // 000000847C10: 323A0085
	v_and_b32_e32 v30, 31, v0                                  // 000000847C14: 363C009F
	.long 0x7f0a3880                                           // 000000847C18: 7F0A3880
	v_lshlrev_b32_e32 v28, 2, v0                               // 000000847C1C: 30380082
	s_waitcnt lgkmcnt(0)                                       // 000000847C20: BF89FC07
	.long 0xd4510004                                           // 000000847C24: D4510004
	v_cndmask_b32_e32 v0, s2, v16, vcc_lo                      // 000000847C28: 02002002
	s_and_b32 s4, s4, exec_lo                                  // 000000847C2C: 8B047E04
	s_cselect_b32 s6, s3, 0                                    // 000000847C30: 98068003
	s_cselect_b32 s7, s2, 0                                    // 000000847C34: 98078002
	s_add_u32 s4, s8, s20                                      // 000000847C38: 80041408
	s_addc_u32 s5, s9, s21                                     // 000000847C3C: 82051509
	v_and_b32_e32 v1, 15, v0                                   // 000000847C40: 3602008F
	v_and_b32_e32 v2, 60, v2                                   // 000000847C44: 360404BC
	s_ashr_i32 s20, s15, 31                                    // 000000847C48: 86149F0F
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000847C4C: BF870119
	s_lshr_b32 s20, s20, 27                                    // 000000847C50: 85149B14
	v_lshlrev_b32_e32 v1, 2, v1                                // 000000847C54: 30020282
	s_add_u32 s20, s14, s20                                    // 000000847C58: 8014140E
	s_clause 0x1                                               // 000000847C5C: BF850001
	global_load_b32 v3, v1, s[8:9]                             // 000000847C60: DC520000 03080001
	global_load_b32 v4, v2, s[8:9]                             // 000000847C68: DC520000 04080002
	s_addc_u32 s21, s15, 0                                     // 000000847C70: 8215800F
	v_mov_b32_e32 v1, s4                                       // 000000847C74: 7E020204
	s_lshr_b64 s[20:21], s[20:21], 5                           // 000000847C78: 85948514
	v_mov_b32_e32 v2, s5                                       // 000000847C7C: 7E040205
	s_add_i32 s21, s20, 7                                      // 000000847C80: 81158714
	s_mul_i32 s5, s23, s7                                      // 000000847C84: 96050717
	s_ashr_i32 s24, s21, 31                                    // 000000847C88: 86189F15
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 000000847C8C: BF8704B9
	s_lshr_b32 s4, s24, 29                                     // 000000847C90: 85049D18
	v_mad_u64_u32 v[24:25], null, s22, s7, v[1:2]              // 000000847C94: D6FE7C18 04040E16
	s_add_i32 s21, s21, s4                                     // 000000847C9C: 81150415
	s_ashr_i32 s4, s21, 3                                      // 000000847CA0: 86048315
	s_cmpk_lt_i32 s20, 0x801                                   // 000000847CA4: B3940801
	.long 0xd72c0001                                           // 000000847CA8: D72C0001
	v_cndmask_b32_e32 v1, s4, v29, vcc_lo                      // 000000847CAC: 02023A04
	s_mul_i32 s21, s22, s6                                     // 000000847CB0: 96150616
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000847CB4: BF870141
	v_add_nc_u32_e32 v7, s4, v1                                // 000000847CB8: 4A0E0204
	v_add_nc_u32_e32 v31, v1, v30                              // 000000847CBC: 4A3E3D01
	s_cselect_b32 s4, -1, 0                                    // 000000847CC0: 980480C1
	s_cmpk_gt_i32 s20, 0x800                                   // 000000847CC4: B2940800
	v_min_i32_e32 v32, s20, v7                                 // 000000847CC8: 22400E14
	s_cselect_b32 s20, -1, 0                                   // 000000847CCC: 981480C1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 000000847CD0: BF870159
	s_and_b32 vcc_lo, exec_lo, s20                             // 000000847CD4: 8B6A147E
	s_waitcnt vmcnt(1)                                         // 000000847CD8: BF8907F7
	v_bfe_u32 v2, v3, 16, 1                                    // 000000847CDC: D6100002 02052103
	s_waitcnt vmcnt(0)                                         // 000000847CE4: BF8903F7
	v_bfe_u32 v6, v4, 16, 1                                    // 000000847CE8: D6100006 02052104
	v_add3_u32 v2, v3, v2, 0x7fff                              // 000000847CF0: D6550002 03FE0503 00007FFF
	v_add_nc_u32_e32 v3, s5, v25                               // 000000847CFC: 4A063205
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000847D00: BF870223
	v_add3_u32 v4, v4, v6, 0x7fff                              // 000000847D04: D6550004 03FE0D04 00007FFF
	.long 0xd4410005                                           // 000000847D10: D4410005
	v_cndmask_b32_e32 v1, v31, v32, vcc_lo                     // 000000847D14: 0202411F
	.long 0x7e0a3982                                           // 000000847D18: 7E0A3982
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000847D1C: BF870114
	v_add_nc_u32_e32 v33, s21, v3                              // 000000847D20: 4A420615
	v_and_or_b32 v1, 0xffff0000, v4, v5                        // 000000847D24: D6570001 041608FF FFFF0000
	ds_store_b32 v28, v1                                       // 000000847D30: D8340000 0000011C
	s_waitcnt lgkmcnt(0)                                       // 000000847D38: BF89FC07
	s_barrier                                                  // 000000847D3C: BFBD0000
	buffer_gl0_inv                                             // 000000847D40: E0AC0000 00000000
	s_cbranch_vccnz 154                                        // 000000847D48: BFA4009A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi8ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x3b4>
	v_dual_mov_b32 v9, 0 :: v_dual_mov_b32 v8, 0               // 000000847D4C: CA100080 09080080
	s_and_saveexec_b32 s21, s5                                 // 000000847D54: BE952005
	s_cbranch_execz 11                                         // 000000847D58: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi8ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x188>
	v_lshlrev_b32_e32 v1, 1, v31                               // 000000847D5C: 30023E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000847D60: BF8700A1
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000847D64: 3404029F
	.long 0xd7006a01                                           // 000000847D68: D7006A01
	v_cndmask_b32_e32 v1, v24, v1, vcc_lo                      // 000000847D6C: 02020318
	v_add_co_ci_u32_e64 v2, null, v33, v2, vcc_lo              // 000000847D70: D5207C02 01AA0521
	global_load_d16_b16 v1, v[1:2], off                        // 000000847D78: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 000000847D80: BF8903F7
	v_cvt_f32_f16_e32 v8, v1                                   // 000000847D84: 7E101701
	s_or_b32 exec_lo, exec_lo, s21                             // 000000847D88: 8C7E157E
	v_add_nc_u32_e32 v1, 32, v31                               // 000000847D8C: 4A023EA0
	s_mov_b32 s5, exec_lo                                      // 000000847D90: BE85007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000847D94: BF870001
	.long 0xd4c1007e                                           // 000000847D98: D4C1007E
	v_cndmask_b32_e32 v1, v1, v32, vcc_lo                      // 000000847D9C: 02024101
	s_cbranch_execz 11                                         // 000000847DA0: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi8ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x1d0>
	v_lshlrev_b32_e32 v1, 1, v1                                // 000000847DA4: 30020281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000847DA8: BF8700A1
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000847DAC: 3404029F
	.long 0xd7006a01                                           // 000000847DB0: D7006A01
	v_cndmask_b32_e32 v1, v24, v1, vcc_lo                      // 000000847DB4: 02020318
	v_add_co_ci_u32_e64 v2, null, v33, v2, vcc_lo              // 000000847DB8: D5207C02 01AA0521
	global_load_d16_b16 v1, v[1:2], off                        // 000000847DC0: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 000000847DC8: BF8903F7
	v_cvt_f32_f16_e32 v9, v1                                   // 000000847DCC: 7E121701
	s_or_b32 exec_lo, exec_lo, s5                              // 000000847DD0: 8C7E057E
	v_dual_mov_b32 v10, 0 :: v_dual_add_nc_u32 v1, 64, v31     // 000000847DD4: CA200080 0A003EC0
	v_mov_b32_e32 v11, 0                                       // 000000847DDC: 7E160280
	s_mov_b32 s5, exec_lo                                      // 000000847DE0: BE85007E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000847DE4: BF870002
	.long 0xd4c1007e                                           // 000000847DE8: D4C1007E
	v_cndmask_b32_e32 v1, v1, v32, vcc_lo                      // 000000847DEC: 02024101
	s_cbranch_execz 11                                         // 000000847DF0: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi8ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x220>
	v_lshlrev_b32_e32 v1, 1, v1                                // 000000847DF4: 30020281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000847DF8: BF8700A1
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000847DFC: 3404029F
	.long 0xd7006a01                                           // 000000847E00: D7006A01
	v_cndmask_b32_e32 v1, v24, v1, vcc_lo                      // 000000847E04: 02020318
	v_add_co_ci_u32_e64 v2, null, v33, v2, vcc_lo              // 000000847E08: D5207C02 01AA0521
	global_load_d16_b16 v1, v[1:2], off                        // 000000847E10: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 000000847E18: BF8903F7
	v_cvt_f32_f16_e32 v10, v1                                  // 000000847E1C: 7E141701
	s_or_b32 exec_lo, exec_lo, s5                              // 000000847E20: 8C7E057E
	v_add_nc_u32_e32 v1, 0x60, v31                             // 000000847E24: 4A023EFF 00000060
	s_mov_b32 s5, exec_lo                                      // 000000847E2C: BE85007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000847E30: BF870001
	.long 0xd4c1007e                                           // 000000847E34: D4C1007E
	v_cndmask_b32_e32 v1, v1, v32, vcc_lo                      // 000000847E38: 02024101
	s_cbranch_execz 11                                         // 000000847E3C: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi8ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x26c>
	v_lshlrev_b32_e32 v1, 1, v1                                // 000000847E40: 30020281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000847E44: BF8700A1
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000847E48: 3404029F
	.long 0xd7006a01                                           // 000000847E4C: D7006A01
	v_cndmask_b32_e32 v1, v24, v1, vcc_lo                      // 000000847E50: 02020318
	v_add_co_ci_u32_e64 v2, null, v33, v2, vcc_lo              // 000000847E54: D5207C02 01AA0521
	global_load_d16_b16 v1, v[1:2], off                        // 000000847E5C: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 000000847E64: BF8903F7
	v_cvt_f32_f16_e32 v11, v1                                  // 000000847E68: 7E161701
	s_or_b32 exec_lo, exec_lo, s5                              // 000000847E6C: 8C7E057E
	v_dual_mov_b32 v12, 0 :: v_dual_add_nc_u32 v1, 0x80, v31   // 000000847E70: CA200080 0C003EFF 00000080
	v_mov_b32_e32 v13, 0                                       // 000000847E7C: 7E1A0280
	s_mov_b32 s5, exec_lo                                      // 000000847E80: BE85007E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000847E84: BF870002
	.long 0xd4c1007e                                           // 000000847E88: D4C1007E
	v_cndmask_b32_e32 v1, v1, v32, vcc_lo                      // 000000847E8C: 02024101
	s_cbranch_execz 11                                         // 000000847E90: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi8ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x2c0>
	v_lshlrev_b32_e32 v1, 1, v1                                // 000000847E94: 30020281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000847E98: BF8700A1
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000847E9C: 3404029F
	.long 0xd7006a01                                           // 000000847EA0: D7006A01
	v_cndmask_b32_e32 v1, v24, v1, vcc_lo                      // 000000847EA4: 02020318
	v_add_co_ci_u32_e64 v2, null, v33, v2, vcc_lo              // 000000847EA8: D5207C02 01AA0521
	global_load_d16_b16 v1, v[1:2], off                        // 000000847EB0: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 000000847EB8: BF8903F7
	v_cvt_f32_f16_e32 v12, v1                                  // 000000847EBC: 7E181701
	s_or_b32 exec_lo, exec_lo, s5                              // 000000847EC0: 8C7E057E
	v_add_nc_u32_e32 v1, 0xa0, v31                             // 000000847EC4: 4A023EFF 000000A0
	s_mov_b32 s5, exec_lo                                      // 000000847ECC: BE85007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000847ED0: BF870001
	.long 0xd4c1007e                                           // 000000847ED4: D4C1007E
	v_cndmask_b32_e32 v1, v1, v32, vcc_lo                      // 000000847ED8: 02024101
	s_cbranch_execz 11                                         // 000000847EDC: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi8ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x30c>
	v_lshlrev_b32_e32 v1, 1, v1                                // 000000847EE0: 30020281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000847EE4: BF8700A1
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000847EE8: 3404029F
	.long 0xd7006a01                                           // 000000847EEC: D7006A01
	v_cndmask_b32_e32 v1, v24, v1, vcc_lo                      // 000000847EF0: 02020318
	v_add_co_ci_u32_e64 v2, null, v33, v2, vcc_lo              // 000000847EF4: D5207C02 01AA0521
	global_load_d16_b16 v1, v[1:2], off                        // 000000847EFC: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 000000847F04: BF8903F7
	v_cvt_f32_f16_e32 v13, v1                                  // 000000847F08: 7E1A1701
	s_or_b32 exec_lo, exec_lo, s5                              // 000000847F0C: 8C7E057E
	v_dual_mov_b32 v14, 0 :: v_dual_add_nc_u32 v1, 0xc0, v31   // 000000847F10: CA200080 0E003EFF 000000C0
	v_mov_b32_e32 v15, 0                                       // 000000847F1C: 7E1E0280
	s_mov_b32 s5, exec_lo                                      // 000000847F20: BE85007E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000847F24: BF870002
	.long 0xd4c1007e                                           // 000000847F28: D4C1007E
	v_cndmask_b32_e32 v1, v1, v32, vcc_lo                      // 000000847F2C: 02024101
	s_cbranch_execz 11                                         // 000000847F30: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi8ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x360>
	v_lshlrev_b32_e32 v1, 1, v1                                // 000000847F34: 30020281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000847F38: BF8700A1
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000847F3C: 3404029F
	.long 0xd7006a01                                           // 000000847F40: D7006A01
	v_cndmask_b32_e32 v1, v24, v1, vcc_lo                      // 000000847F44: 02020318
	v_add_co_ci_u32_e64 v2, null, v33, v2, vcc_lo              // 000000847F48: D5207C02 01AA0521
	global_load_d16_b16 v1, v[1:2], off                        // 000000847F50: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 000000847F58: BF8903F7
	v_cvt_f32_f16_e32 v14, v1                                  // 000000847F5C: 7E1C1701
	s_or_b32 exec_lo, exec_lo, s5                              // 000000847F60: 8C7E057E
	v_add_nc_u32_e32 v1, 0xe0, v31                             // 000000847F64: 4A023EFF 000000E0
	s_mov_b32 s5, exec_lo                                      // 000000847F6C: BE85007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000847F70: BF870001
	.long 0xd4c1007e                                           // 000000847F74: D4C1007E
	v_cndmask_b32_e32 v1, v1, v32, vcc_lo                      // 000000847F78: 02024101
	s_cbranch_execz 11                                         // 000000847F7C: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi8ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x3ac>
	v_lshlrev_b32_e32 v1, 1, v1                                // 000000847F80: 30020281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000847F84: BF8700A1
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000847F88: 3404029F
	.long 0xd7006a01                                           // 000000847F8C: D7006A01
	v_cndmask_b32_e32 v1, v24, v1, vcc_lo                      // 000000847F90: 02020318
	v_add_co_ci_u32_e64 v2, null, v33, v2, vcc_lo              // 000000847F94: D5207C02 01AA0521
	global_load_d16_b16 v1, v[1:2], off                        // 000000847F9C: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 000000847FA4: BF8903F7
	v_cvt_f32_f16_e32 v15, v1                                  // 000000847FA8: 7E1E1701
	s_or_b32 exec_lo, exec_lo, s5                              // 000000847FAC: 8C7E057E
	s_branch 9                                                 // 000000847FB0: BFA00009 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi8ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x3d8>
	v_mov_b32_e32 v8, 0                                        // 000000847FB4: 7E100280
	s_delay_alu instid0(VALU_DEP_1)                            // 000000847FB8: BF870001
	v_mov_b32_e32 v9, v8                                       // 000000847FBC: 7E120308
	v_mov_b32_e32 v10, v8                                      // 000000847FC0: 7E140308
	v_mov_b32_e32 v11, v8                                      // 000000847FC4: 7E160308
	v_mov_b32_e32 v12, v8                                      // 000000847FC8: 7E180308
	v_mov_b32_e32 v13, v8                                      // 000000847FCC: 7E1A0308
	v_mov_b32_e32 v14, v8                                      // 000000847FD0: 7E1C0308
	v_mov_b32_e32 v15, v8                                      // 000000847FD4: 7E1E0308
	s_add_u32 s8, s8, s18                                      // 000000847FD8: 80081208
	s_addc_u32 s9, s9, s19                                     // 000000847FDC: 82091309
	s_lshr_b32 s5, s15, 31                                     // 000000847FE0: 85059F0F
	v_dual_mov_b32 v1, s7 :: v_dual_mov_b32 v20, 0             // 000000847FE4: CA100007 01140080
	s_add_u32 s18, s14, s5                                     // 000000847FEC: 8012050E
	s_addc_u32 s19, s15, 0                                     // 000000847FF0: 8213800F
	.long 0xd4410005                                           // 000000847FF4: D4410005
	v_cndmask_b32_e32 v1, v31, v32, vcc_lo                     // 000000847FF8: 0202411F
	s_ashr_i64 s[18:19], s[18:19], 1                           // 000000847FFC: 86928112
	v_dual_mov_b32 v34, 0 :: v_dual_mov_b32 v27, 0             // 000000848000: CA100080 221A0080
	v_mad_u64_u32 v[25:26], null, v1, s18, s[8:9]              // 000000848008: D6FE7C19 00202501
	.long 0xd72c0001                                           // 000000848010: D72C0001
	v_cndmask_b32_e32 v0, s7, v19, vcc_lo                      // 000000848014: 02002607
	.long 0xd72c0002                                           // 000000848018: D72C0002
	v_cndmask_b32_e32 v0, s6, v18, vcc_lo                      // 00000084801C: 02002406
	v_cndmask_b32_e64 v35, 0, 1, s20                           // 000000848020: D5010023 00510280
	v_dual_mov_b32 v21, 0 :: v_dual_mov_b32 v22, 0             // 000000848028: CA100080 15160080
	v_mov_b32_e32 v23, 0                                       // 000000848030: 7E2E0280
	s_delay_alu instid0(VALU_DEP_4)                            // 000000848034: BF870004
	v_add3_u32 v36, v2, v26, v1                                // 000000848038: D6550024 04063502
	s_and_saveexec_b32 s6, s5                                  // 000000848040: BE862005
	s_cbranch_execz 22                                         // 000000848044: BFA50016 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi8ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x4a0>
	v_lshlrev_b32_e32 v1, 4, v31                               // 000000848048: 30023E84
	v_mov_b32_e32 v27, 0                                       // 00000084804C: 7E360280
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000848050: BF8700A2
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000848054: 3404029F
	.long 0xd7006a01                                           // 000000848058: D7006A01
	v_cndmask_b32_e32 v1, v25, v1, vcc_lo                      // 00000084805C: 02020319
	v_add_co_ci_u32_e64 v2, null, v36, v2, vcc_lo              // 000000848060: D5207C02 01AA0524
	s_and_not1_b32 vcc_lo, exec_lo, s20                        // 000000848068: 916A147E
	global_load_b128 v[20:23], v[1:2], off                     // 00000084806C: DC5E0000 147C0001
	s_cbranch_vccnz 10                                         // 000000848074: BFA4000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi8ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x4a0>
	v_lshlrev_b32_e32 v1, 1, v31                               // 000000848078: 30023E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000084807C: BF870091
	.long 0xd7006a01                                           // 000000848080: D7006A01
	v_cndmask_b32_e32 v1, v24, v1, vcc_lo                      // 000000848084: 02020318
	v_add_co_ci_u32_e64 v2, null, 0, v33, vcc_lo               // 000000848088: D5207C02 01AA4280
	global_load_d16_b16 v1, v[1:2], off                        // 000000848090: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 000000848098: BF8903F7
	v_cvt_f32_f16_e32 v27, v1                                  // 00000084809C: 7E361701
	s_or_b32 exec_lo, exec_lo, s6                              // 0000008480A0: 8C7E067E
	v_dual_mov_b32 v38, 0 :: v_dual_mov_b32 v39, 0             // 0000008480A4: CA100080 26260080
	v_dual_mov_b32 v40, 0 :: v_dual_mov_b32 v37, 0             // 0000008480AC: CA100080 28240080
	s_and_saveexec_b32 s18, s5                                 // 0000008480B4: BE922005
	s_cbranch_execz 490                                        // 0000008480B8: BFA501EA <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi8ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0xc64>
	v_dual_mov_b32 v40, 0 :: v_dual_add_nc_u32 v1, 32, v31     // 0000008480BC: CA200080 28003EA0
	v_dual_mov_b32 v37, 0 :: v_dual_lshlrev_b32 v26, 5, v31    // 0000008480C4: CA220080 251A3E85
	v_dual_mov_b32 v34, 0 :: v_dual_mov_b32 v43, v27           // 0000008480CC: CA100080 222A011B
	s_delay_alu instid0(VALU_DEP_3)                            // 0000008480D4: BF870003
	v_dual_mov_b32 v38, 0 :: v_dual_lshlrev_b32 v41, 4, v1     // 0000008480D8: CA220080 26280284
	v_dual_mov_b32 v39, 0 :: v_dual_lshlrev_b32 v42, 1, v1     // 0000008480E0: CA220080 272A0281
	s_mul_i32 s5, s15, 6                                       // 0000008480E8: 9605860F
	s_mul_hi_u32 s8, s14, 6                                    // 0000008480EC: 9688860E
	s_lshl_b64 s[6:7], s[14:15], 2                             // 0000008480F0: 8486820E
	s_add_i32 s19, s8, s5                                      // 0000008480F4: 81130508
	s_mul_i32 s21, s14, 6                                      // 0000008480F8: 9615860E
	s_mov_b32 s20, 0                                           // 0000008480FC: BE940080
	s_lshl_b64 s[8:9], s[14:15], 1                             // 000000848100: 8488810E
	s_branch 435                                               // 000000848104: BFA001B3 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi8ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0xbd4>
	s_or_b32 exec_lo, exec_lo, s14                             // 000000848108: 8C7E0E7E
	v_cndmask_b32_e64 v54, v27, v8, s4                         // 00000084810C: D5010036 0012111B
	v_cndmask_b32_e64 v2, v9, v10, s4                          // 000000848114: D5010002 00121509
	v_cndmask_b32_e64 v1, v8, v9, s4                           // 00000084811C: D5010001 00121308
	v_dual_mov_b32 v8, v15 :: v_dual_and_b32 v9, 0xff, v20     // 000000848124: CA24010F 080828FF 000000FF
	v_cndmask_b32_e64 v7, v14, v15, s4                         // 000000848130: D5010007 00121F0E
	v_cndmask_b32_e64 v6, v13, v14, s4                         // 000000848138: D5010006 00121D0D
	v_cndmask_b32_e64 v5, v12, v13, s4                         // 000000848140: D5010005 00121B0C
	v_cndmask_b32_e64 v4, v11, v12, s4                         // 000000848148: D5010004 0012190B
	v_lshlrev_b32_e32 v9, 2, v9                                // 000000848150: 30121282
	v_cndmask_b32_e64 v3, v10, v11, s4                         // 000000848154: D5010003 0012170A
	v_ashrrev_i32_e32 v27, 31, v26                             // 00000084815C: 3436349F
	v_add_nc_u32_e32 v41, 0x200, v41                           // 000000848160: 4A5252FF 00000200
	s_and_b32 s5, exec_lo, s5                                  // 000000848168: 8B05057E
	ds_load_b32 v15, v9                                        // 00000084816C: D8D80000 0F000009
	v_lshrrev_b32_e32 v9, 6, v20                               // 000000848174: 32122886
	s_or_b32 s20, s5, s20                                      // 000000848178: 8C141405
	v_add_nc_u32_e32 v42, 64, v42                              // 00000084817C: 4A5454C0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000848180: BF8700B2
	v_and_b32_e32 v9, 0x3fc, v9                                // 000000848184: 361212FF 000003FC
	ds_load_b32 v55, v9                                        // 00000084818C: D8D80000 37000009
	v_lshrrev_b32_e32 v9, 14, v20                              // 000000848194: 3212288E
	v_and_b32_e32 v9, 0x3fc, v9                                // 000000848198: 361212FF 000003FC
	ds_load_b32 v56, v9                                        // 0000008481A0: D8D80000 38000009
	v_lshrrev_b32_e32 v9, 22, v20                              // 0000008481A8: 32122896
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008481AC: BF8700B1
	v_and_b32_e32 v9, 0x3fc, v9                                // 0000008481B0: 361212FF 000003FC
	ds_load_b32 v57, v9                                        // 0000008481B8: D8D80000 39000009
	v_and_b32_e32 v9, 0xff, v21                                // 0000008481C0: 36122AFF 000000FF
	v_lshlrev_b32_e32 v9, 2, v9                                // 0000008481C8: 30121282
	ds_load_b32 v58, v9                                        // 0000008481CC: D8D80000 3A000009
	v_lshrrev_b32_e32 v9, 6, v21                               // 0000008481D4: 32122A86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008481D8: BF8700B1
	v_and_b32_e32 v9, 0x3fc, v9                                // 0000008481DC: 361212FF 000003FC
	ds_load_b32 v59, v9                                        // 0000008481E4: D8D80000 3B000009
	v_lshrrev_b32_e32 v9, 14, v21                              // 0000008481EC: 32122A8E
	v_and_b32_e32 v9, 0x3fc, v9                                // 0000008481F0: 361212FF 000003FC
	ds_load_b32 v60, v9                                        // 0000008481F8: D8D80000 3C000009
	v_lshrrev_b32_e32 v9, 22, v21                              // 000000848200: 32122A96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000848204: BF8700B1
	v_and_b32_e32 v9, 0x3fc, v9                                // 000000848208: 361212FF 000003FC
	ds_load_b32 v61, v9                                        // 000000848210: D8D80000 3D000009
	v_and_b32_e32 v9, 0xff, v22                                // 000000848218: 36122CFF 000000FF
	v_lshlrev_b32_e32 v9, 2, v9                                // 000000848220: 30121282
	ds_load_b32 v62, v9                                        // 000000848224: D8D80000 3E000009
	v_lshrrev_b32_e32 v9, 6, v22                               // 00000084822C: 32122C86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000848230: BF8700B1
	v_and_b32_e32 v9, 0x3fc, v9                                // 000000848234: 361212FF 000003FC
	ds_load_b32 v63, v9                                        // 00000084823C: D8D80000 3F000009
	v_lshrrev_b32_e32 v9, 14, v22                              // 000000848244: 32122C8E
	v_and_b32_e32 v9, 0x3fc, v9                                // 000000848248: 361212FF 000003FC
	ds_load_b32 v64, v9                                        // 000000848250: D8D80000 40000009
	v_lshrrev_b32_e32 v9, 22, v22                              // 000000848258: 32122C96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000084825C: BF8700B1
	v_and_b32_e32 v9, 0x3fc, v9                                // 000000848260: 361212FF 000003FC
	ds_load_b32 v65, v9                                        // 000000848268: D8D80000 41000009
	v_and_b32_e32 v9, 0xff, v23                                // 000000848270: 36122EFF 000000FF
	v_lshlrev_b32_e32 v9, 2, v9                                // 000000848278: 30121282
	ds_load_b32 v66, v9                                        // 00000084827C: D8D80000 42000009
	v_lshrrev_b32_e32 v9, 6, v23                               // 000000848284: 32122E86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000848288: BF8700B1
	v_and_b32_e32 v9, 0x3fc, v9                                // 00000084828C: 361212FF 000003FC
	ds_load_b32 v67, v9                                        // 000000848294: D8D80000 43000009
	v_lshrrev_b32_e32 v9, 14, v23                              // 00000084829C: 32122E8E
	v_and_b32_e32 v9, 0x3fc, v9                                // 0000008482A0: 361212FF 000003FC
	ds_load_b32 v68, v9                                        // 0000008482A8: D8D80000 44000009
	v_lshrrev_b32_e32 v9, 22, v23                              // 0000008482B0: 32122E96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000008482B4: BF870141
	v_and_b32_e32 v9, 0x3fc, v9                                // 0000008482B8: 361212FF 000003FC
	ds_load_b32 v69, v9                                        // 0000008482C0: D8D80000 45000009
	.long 0xd73c0009                                           // 0000008482C8: D73C0009
	v_cndmask_b32_e32 v1, 1, v26, vcc_lo                       // 0000008482CC: 02023481
	v_dual_mov_b32 v27, v43 :: v_dual_add_nc_u32 v26, 0x400, v26// 0000008482D0: CA20012B 1B1A34FF 00000400
	.long 0xd7006a0d                                           // 0000008482DC: D7006A0D
	v_cndmask_b32_e32 v1, s10, v9, vcc_lo                      // 0000008482E0: 0202120A
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008482E4: BF870001
	v_add_co_ci_u32_e64 v14, null, s11, v10, vcc_lo            // 0000008482E8: D5207C0E 01AA140B
	s_clause 0x3                                               // 0000008482F0: BF850003
	global_load_b128 v[9:12], v[13:14], off                    // 0000008482F4: DC5E0000 097C000D
	global_load_b128 v[20:23], v[13:14], off offset:16         // 0000008482FC: DC5E0010 147C000D
	global_load_b128 v[44:47], v[13:14], off offset:32         // 000000848304: DC5E0020 2C7C000D
	global_load_b128 v[48:51], v[13:14], off offset:48         // 00000084830C: DC5E0030 307C000D
	s_waitcnt vmcnt(3) lgkmcnt(15)                             // 000000848314: BF890CF7
	v_dot2_f32_bf16 v9, v9, v15, 0                             // 000000848318: CC1A4009 1A021F09
	s_waitcnt lgkmcnt(14)                                      // 000000848320: BF89FCE7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000848324: BF8700A1
	v_dot2_f32_bf16 v9, v10, v55, v9                           // 000000848328: CC1A4009 1C266F0A
	s_waitcnt lgkmcnt(13)                                      // 000000848330: BF89FCD7
	v_dot2_f32_bf16 v9, v11, v56, v9                           // 000000848334: CC1A4009 1C26710B
	s_waitcnt lgkmcnt(12)                                      // 00000084833C: BF89FCC7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000848340: BF8700A1
	v_dot2_f32_bf16 v9, v12, v57, v9                           // 000000848344: CC1A4009 1C26730C
	s_waitcnt vmcnt(2) lgkmcnt(11)                             // 00000084834C: BF8908B7
	v_dot2_f32_bf16 v9, v20, v58, v9                           // 000000848350: CC1A4009 1C267514
	s_waitcnt lgkmcnt(10)                                      // 000000848358: BF89FCA7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000084835C: BF8700A1
	v_dot2_f32_bf16 v9, v21, v59, v9                           // 000000848360: CC1A4009 1C267715
	s_waitcnt lgkmcnt(9)                                       // 000000848368: BF89FC97
	v_dot2_f32_bf16 v9, v22, v60, v9                           // 00000084836C: CC1A4009 1C267916
	s_waitcnt lgkmcnt(8)                                       // 000000848374: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000848378: BF8700A1
	v_dot2_f32_bf16 v9, v23, v61, v9                           // 00000084837C: CC1A4009 1C267B17
	s_waitcnt vmcnt(1) lgkmcnt(7)                              // 000000848384: BF890477
	v_dot2_f32_bf16 v9, v44, v62, v9                           // 000000848388: CC1A4009 1C267D2C
	s_waitcnt lgkmcnt(6)                                       // 000000848390: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000848394: BF8700A1
	v_dot2_f32_bf16 v9, v45, v63, v9                           // 000000848398: CC1A4009 1C267F2D
	s_waitcnt lgkmcnt(5)                                       // 0000008483A0: BF89FC57
	v_dot2_f32_bf16 v9, v46, v64, v9                           // 0000008483A4: CC1A4009 1C26812E
	s_waitcnt lgkmcnt(4)                                       // 0000008483AC: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008483B0: BF8700A1
	v_dot2_f32_bf16 v9, v47, v65, v9                           // 0000008483B4: CC1A4009 1C26832F
	s_waitcnt vmcnt(0) lgkmcnt(3)                              // 0000008483BC: BF890037
	v_dot2_f32_bf16 v9, v48, v66, v9                           // 0000008483C0: CC1A4009 1C268530
	.long 0xd7006a30                                           // 0000008483C8: D7006A30
	v_cndmask_b32_e32 v0, v13, v8, vcc_lo                      // 0000008483CC: 0200110D
	s_waitcnt lgkmcnt(2)                                       // 0000008483D0: BF89FC27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000008483D4: BF8701C2
	v_dot2_f32_bf16 v9, v49, v67, v9                           // 0000008483D8: CC1A4009 1C268731
	v_add_co_ci_u32_e64 v49, null, s9, v14, vcc_lo             // 0000008483E0: D5207C31 01AA1C09
	.long 0xd7006a34                                           // 0000008483E8: D7006A34
	v_cndmask_b32_e32 v0, v13, v6, vcc_lo                      // 0000008483EC: 02000D0D
	s_waitcnt lgkmcnt(1)                                       // 0000008483F0: BF89FC17
	v_dot2_f32_bf16 v9, v50, v68, v9                           // 0000008483F4: CC1A4009 1C268932
	v_add_co_ci_u32_e64 v53, null, s7, v14, vcc_lo             // 0000008483FC: D5207C35 01AA1C07
	.long 0xd7006a0d                                           // 000000848404: D7006A0D
	v_cndmask_b32_e32 v0, v13, v21, vcc_lo                     // 000000848408: 02002B0D
	s_waitcnt lgkmcnt(0)                                       // 00000084840C: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000848410: BF870123
	v_dot2_f32_bf16 v9, v51, v69, v9                           // 000000848414: CC1A4009 1C268B33
	v_add_co_ci_u32_e64 v14, null, s19, v14, vcc_lo            // 00000084841C: D5207C0E 01AA1C13
	v_fmac_f32_e32 v37, v54, v9                                // 000000848424: 564A1336
	s_clause 0x3                                               // 000000848428: BF850003
	global_load_b128 v[9:12], v[48:49], off                    // 00000084842C: DC5E0000 097C0030
	global_load_b128 v[20:23], v[48:49], off offset:16         // 000000848434: DC5E0010 147C0030
	global_load_b128 v[44:47], v[48:49], off offset:32         // 00000084843C: DC5E0020 2C7C0030
	global_load_b128 v[48:51], v[48:49], off offset:48         // 000000848444: DC5E0030 307C0030
	s_waitcnt vmcnt(3)                                         // 00000084844C: BF890FF7
	v_dot2_f32_bf16 v9, v9, v15, 0                             // 000000848450: CC1A4009 1A021F09
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000848458: BF870091
	v_dot2_f32_bf16 v9, v10, v55, v9                           // 00000084845C: CC1A4009 1C266F0A
	v_dot2_f32_bf16 v9, v11, v56, v9                           // 000000848464: CC1A4009 1C26710B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000084846C: BF8700A1
	v_dot2_f32_bf16 v9, v12, v57, v9                           // 000000848470: CC1A4009 1C26730C
	s_waitcnt vmcnt(2)                                         // 000000848478: BF890BF7
	v_dot2_f32_bf16 v9, v20, v58, v9                           // 00000084847C: CC1A4009 1C267514
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000848484: BF870091
	v_dot2_f32_bf16 v9, v21, v59, v9                           // 000000848488: CC1A4009 1C267715
	v_dot2_f32_bf16 v9, v22, v60, v9                           // 000000848490: CC1A4009 1C267916
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000848498: BF8700A1
	v_dot2_f32_bf16 v9, v23, v61, v9                           // 00000084849C: CC1A4009 1C267B17
	s_waitcnt vmcnt(1)                                         // 0000008484A4: BF8907F7
	v_dot2_f32_bf16 v9, v44, v62, v9                           // 0000008484A8: CC1A4009 1C267D2C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008484B0: BF870091
	v_dot2_f32_bf16 v9, v45, v63, v9                           // 0000008484B4: CC1A4009 1C267F2D
	v_dot2_f32_bf16 v9, v46, v64, v9                           // 0000008484BC: CC1A4009 1C26812E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008484C4: BF8700A1
	v_dot2_f32_bf16 v9, v47, v65, v9                           // 0000008484C8: CC1A4009 1C26832F
	s_waitcnt vmcnt(0)                                         // 0000008484D0: BF8903F7
	v_dot2_f32_bf16 v9, v48, v66, v9                           // 0000008484D4: CC1A4009 1C268530
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008484DC: BF870091
	v_dot2_f32_bf16 v9, v49, v67, v9                           // 0000008484E0: CC1A4009 1C268731
	v_dot2_f32_bf16 v9, v50, v68, v9                           // 0000008484E8: CC1A4009 1C268932
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008484F0: BF870091
	v_dot2_f32_bf16 v9, v51, v69, v9                           // 0000008484F4: CC1A4009 1C268B33
	v_fmac_f32_e32 v40, v54, v9                                // 0000008484FC: 56501336
	s_clause 0x3                                               // 000000848500: BF850003
	global_load_b128 v[9:12], v[52:53], off                    // 000000848504: DC5E0000 097C0034
	global_load_b128 v[20:23], v[52:53], off offset:16         // 00000084850C: DC5E0010 147C0034
	global_load_b128 v[44:47], v[52:53], off offset:32         // 000000848514: DC5E0020 2C7C0034
	global_load_b128 v[48:51], v[52:53], off offset:48         // 00000084851C: DC5E0030 307C0034
	s_waitcnt vmcnt(3)                                         // 000000848524: BF890FF7
	v_dot2_f32_bf16 v9, v9, v15, 0                             // 000000848528: CC1A4009 1A021F09
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000848530: BF870091
	v_dot2_f32_bf16 v9, v10, v55, v9                           // 000000848534: CC1A4009 1C266F0A
	v_dot2_f32_bf16 v9, v11, v56, v9                           // 00000084853C: CC1A4009 1C26710B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000848544: BF8700A1
	v_dot2_f32_bf16 v9, v12, v57, v9                           // 000000848548: CC1A4009 1C26730C
	s_waitcnt vmcnt(2)                                         // 000000848550: BF890BF7
	v_dot2_f32_bf16 v9, v20, v58, v9                           // 000000848554: CC1A4009 1C267514
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000084855C: BF870091
	v_dot2_f32_bf16 v9, v21, v59, v9                           // 000000848560: CC1A4009 1C267715
	v_dot2_f32_bf16 v9, v22, v60, v9                           // 000000848568: CC1A4009 1C267916
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000848570: BF8700A1
	v_dot2_f32_bf16 v9, v23, v61, v9                           // 000000848574: CC1A4009 1C267B17
	s_waitcnt vmcnt(1)                                         // 00000084857C: BF8907F7
	v_dot2_f32_bf16 v9, v44, v62, v9                           // 000000848580: CC1A4009 1C267D2C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000848588: BF870091
	v_dot2_f32_bf16 v9, v45, v63, v9                           // 00000084858C: CC1A4009 1C267F2D
	v_dot2_f32_bf16 v9, v46, v64, v9                           // 000000848594: CC1A4009 1C26812E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000084859C: BF8700A1
	v_dot2_f32_bf16 v9, v47, v65, v9                           // 0000008485A0: CC1A4009 1C26832F
	s_waitcnt vmcnt(0)                                         // 0000008485A8: BF8903F7
	v_dot2_f32_bf16 v9, v48, v66, v9                           // 0000008485AC: CC1A4009 1C268530
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008485B4: BF870091
	v_dot2_f32_bf16 v9, v49, v67, v9                           // 0000008485B8: CC1A4009 1C268731
	v_dot2_f32_bf16 v9, v50, v68, v9                           // 0000008485C0: CC1A4009 1C268932
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008485C8: BF870091
	v_dot2_f32_bf16 v9, v51, v69, v9                           // 0000008485CC: CC1A4009 1C268B33
	v_fmac_f32_e32 v39, v54, v9                                // 0000008485D4: 564E1336
	s_clause 0x3                                               // 0000008485D8: BF850003
	global_load_b128 v[9:12], v[13:14], off                    // 0000008485DC: DC5E0000 097C000D
	global_load_b128 v[20:23], v[13:14], off offset:16         // 0000008485E4: DC5E0010 147C000D
	global_load_b128 v[44:47], v[13:14], off offset:32         // 0000008485EC: DC5E0020 2C7C000D
	global_load_b128 v[48:51], v[13:14], off offset:48         // 0000008485F4: DC5E0030 307C000D
	.long 0xd7006a0d                                           // 0000008485FC: D7006A0D
	v_cndmask_b32_e32 v0, v52, v6, vcc_lo                      // 000000848600: 02000D34
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000848604: BF8700B1
	v_add_co_ci_u32_e64 v14, null, s7, v53, vcc_lo             // 000000848608: D5207C0E 01AA6A07
	s_waitcnt vmcnt(3)                                         // 000000848610: BF890FF7
	v_dot2_f32_bf16 v9, v9, v15, 0                             // 000000848614: CC1A4009 1A021F09
	v_dot2_f32_bf16 v9, v10, v55, v9                           // 00000084861C: CC1A4009 1C266F0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000848624: BF870091
	v_dot2_f32_bf16 v9, v11, v56, v9                           // 000000848628: CC1A4009 1C26710B
	v_dot2_f32_bf16 v9, v12, v57, v9                           // 000000848630: CC1A4009 1C26730C
	s_waitcnt vmcnt(2)                                         // 000000848638: BF890BF7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000084863C: BF870091
	v_dot2_f32_bf16 v9, v20, v58, v9                           // 000000848640: CC1A4009 1C267514
	v_dot2_f32_bf16 v9, v21, v59, v9                           // 000000848648: CC1A4009 1C267715
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000848650: BF870091
	v_dot2_f32_bf16 v9, v22, v60, v9                           // 000000848654: CC1A4009 1C267916
	v_dot2_f32_bf16 v9, v23, v61, v9                           // 00000084865C: CC1A4009 1C267B17
	s_waitcnt vmcnt(1)                                         // 000000848664: BF8907F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000848668: BF870091
	v_dot2_f32_bf16 v9, v44, v62, v9                           // 00000084866C: CC1A4009 1C267D2C
	v_dot2_f32_bf16 v9, v45, v63, v9                           // 000000848674: CC1A4009 1C267F2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000084867C: BF870091
	v_dot2_f32_bf16 v9, v46, v64, v9                           // 000000848680: CC1A4009 1C26812E
	v_dot2_f32_bf16 v9, v47, v65, v9                           // 000000848688: CC1A4009 1C26832F
	s_waitcnt vmcnt(0)                                         // 000000848690: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000848694: BF870091
	v_dot2_f32_bf16 v9, v48, v66, v9                           // 000000848698: CC1A4009 1C268530
	v_dot2_f32_bf16 v9, v49, v67, v9                           // 0000008486A0: CC1A4009 1C268731
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008486A8: BF870091
	v_dot2_f32_bf16 v9, v50, v68, v9                           // 0000008486AC: CC1A4009 1C268932
	v_dot2_f32_bf16 v9, v51, v69, v9                           // 0000008486B4: CC1A4009 1C268B33
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008486BC: BF870001
	v_fmac_f32_e32 v38, v54, v9                                // 0000008486C0: 564C1336
	s_clause 0x3                                               // 0000008486C4: BF850003
	global_load_b128 v[9:12], v[13:14], off                    // 0000008486C8: DC5E0000 097C000D
	global_load_b128 v[20:23], v[13:14], off offset:16         // 0000008486D0: DC5E0010 147C000D
	global_load_b128 v[44:47], v[13:14], off offset:32         // 0000008486D8: DC5E0020 2C7C000D
	global_load_b128 v[48:51], v[13:14], off offset:48         // 0000008486E0: DC5E0030 307C000D
	s_waitcnt vmcnt(3)                                         // 0000008486E8: BF890FF7
	v_dot2_f32_bf16 v9, v9, v15, 0                             // 0000008486EC: CC1A4009 1A021F09
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008486F4: BF870091
	v_dot2_f32_bf16 v9, v10, v55, v9                           // 0000008486F8: CC1A4009 1C266F0A
	v_dot2_f32_bf16 v9, v11, v56, v9                           // 000000848700: CC1A4009 1C26710B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000848708: BF8700A1
	v_dot2_f32_bf16 v9, v12, v57, v9                           // 00000084870C: CC1A4009 1C26730C
	s_waitcnt vmcnt(2)                                         // 000000848714: BF890BF7
	v_dot2_f32_bf16 v9, v20, v58, v9                           // 000000848718: CC1A4009 1C267514
	v_mov_b32_e32 v20, v16                                     // 000000848720: 7E280310
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000848724: BF870122
	v_dot2_f32_bf16 v9, v21, v59, v9                           // 000000848728: CC1A4009 1C267715
	v_mov_b32_e32 v21, v17                                     // 000000848730: 7E2A0311
	v_dot2_f32_bf16 v9, v22, v60, v9                           // 000000848734: CC1A4009 1C267916
	v_mov_b32_e32 v22, v18                                     // 00000084873C: 7E2C0312
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000848740: BF870132
	v_dot2_f32_bf16 v9, v23, v61, v9                           // 000000848744: CC1A4009 1C267B17
	v_mov_b32_e32 v23, v19                                     // 00000084874C: 7E2E0313
	s_waitcnt vmcnt(1)                                         // 000000848750: BF8907F7
	v_dot2_f32_bf16 v9, v44, v62, v9                           // 000000848754: CC1A4009 1C267D2C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000084875C: BF870091
	v_dot2_f32_bf16 v9, v45, v63, v9                           // 000000848760: CC1A4009 1C267F2D
	v_dot2_f32_bf16 v9, v46, v64, v9                           // 000000848768: CC1A4009 1C26812E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000848770: BF8700A1
	v_dot2_f32_bf16 v9, v47, v65, v9                           // 000000848774: CC1A4009 1C26832F
	s_waitcnt vmcnt(0)                                         // 00000084877C: BF8903F7
	v_dot2_f32_bf16 v9, v48, v66, v9                           // 000000848780: CC1A4009 1C268530
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000848788: BF870091
	v_dot2_f32_bf16 v9, v49, v67, v9                           // 00000084878C: CC1A4009 1C268731
	v_dot2_f32_bf16 v9, v50, v68, v9                           // 000000848794: CC1A4009 1C268932
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000084879C: BF870091
	v_dot2_f32_bf16 v9, v51, v69, v9                           // 0000008487A0: CC1A4009 1C268B33
	v_dual_fmac_f32 v34, v54, v9 :: v_dual_mov_b32 v15, v8     // 0000008487A8: C8101336 220E0108
	v_dual_mov_b32 v14, v7 :: v_dual_mov_b32 v13, v6           // 0000008487B0: CA100107 0E0C0106
	v_dual_mov_b32 v12, v5 :: v_dual_mov_b32 v11, v4           // 0000008487B8: CA100105 0C0A0104
	v_dual_mov_b32 v10, v3 :: v_dual_mov_b32 v9, v2            // 0000008487C0: CA100103 0A080102
	v_mov_b32_e32 v8, v1                                       // 0000008487C8: 7E100301
	s_and_not1_b32 exec_lo, exec_lo, s20                       // 0000008487CC: 917E147E
	s_cbranch_execz 35                                         // 0000008487D0: BFA50023 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi8ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0xc60>
	s_waitcnt vmcnt(0)                                         // 0000008487D4: BF8903F7
	v_dual_mov_b32 v16, v20 :: v_dual_add_nc_u32 v31, 32, v31  // 0000008487D8: CA200114 101E3EA0
	v_dual_mov_b32 v17, v21 :: v_dual_mov_b32 v18, v22         // 0000008487E0: CA100115 11120116
	v_mov_b32_e32 v19, v23                                     // 0000008487E8: 7E260317
	s_delay_alu instid0(VALU_DEP_3)                            // 0000008487EC: BF870003
	.long 0xd4460005                                           // 0000008487F0: D4460005
	v_cndmask_b32_e32 v1, v31, v32, vcc_lo                     // 0000008487F4: 0202411F
	s_mov_b32 s14, exec_lo                                     // 0000008487F8: BE8E007E
	.long 0xd4c1007e                                           // 0000008487FC: D4C1007E
	v_cndmask_b32_e32 v1, v31, v32, vcc_lo                     // 000000848800: 0202411F
	s_cbranch_execz 65088                                      // 000000848804: BFA5FE40 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi8ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x508>
	v_ashrrev_i32_e32 v2, 31, v41                              // 000000848808: 3404529F
	.long 0xd7006a01                                           // 00000084880C: D7006A01
	v_cndmask_b32_e32 v1, v25, v41, vcc_lo                     // 000000848810: 02025319
	v_mov_b32_e32 v43, v27                                     // 000000848814: 7E56031B
	s_delay_alu instid0(VALU_DEP_3)                            // 000000848818: BF870003
	v_add_co_ci_u32_e64 v2, null, v36, v2, vcc_lo              // 00000084881C: D5207C02 01AA0524
	v_cmp_ne_u32_e32 vcc_lo, 1, v35                            // 000000848824: 7C9A4681
	global_load_b128 v[16:19], v[1:2], off                     // 000000848828: DC5E0000 107C0001
	s_cbranch_vccnz 65077                                      // 000000848830: BFA4FE35 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi8ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x508>
	v_ashrrev_i32_e32 v2, 31, v42                              // 000000848834: 3404549F
	.long 0xd7006a01                                           // 000000848838: D7006A01
	v_cndmask_b32_e32 v1, v24, v42, vcc_lo                     // 00000084883C: 02025518
	s_delay_alu instid0(VALU_DEP_1)                            // 000000848840: BF870001
	v_add_co_ci_u32_e64 v2, null, v33, v2, vcc_lo              // 000000848844: D5207C02 01AA0521
	global_load_d16_b16 v1, v[1:2], off                        // 00000084884C: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 000000848854: BF8903F7
	v_cvt_f32_f16_e32 v43, v1                                  // 000000848858: 7E561701
	s_branch 65066                                             // 00000084885C: BFA0FE2A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi8ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x508>
	s_or_b32 exec_lo, exec_lo, s20                             // 000000848860: 8C7E147E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000848864: BF8700B9
	s_or_b32 exec_lo, exec_lo, s18                             // 000000848868: 8C7E127E
	.long 0xd71f0001                                           // 00000084886C: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 000000848870: 020100C1
	s_mov_b32 s4, exec_lo                                      // 000000848874: BE84007E
	v_xor_b32_e32 v2, 16, v1                                   // 000000848878: 3A040290
	v_xor_b32_e32 v7, 8, v1                                    // 00000084887C: 3A0E0288
	v_xor_b32_e32 v12, 4, v1                                   // 000000848880: 3A180284
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000848884: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 000000848888: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 00000084888C: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v7                            // 000000848890: 7C980EA0
	v_cndmask_b32_e32 v7, v1, v7, vcc_lo                       // 000000848894: 020E0F01
	v_cmp_gt_u32_e32 vcc_lo, 32, v12                           // 000000848898: 7C9818A0
	s_delay_alu instid0(VALU_DEP_2)                            // 00000084889C: BF870002
	v_lshlrev_b32_e32 v7, 2, v7                                // 0000008488A0: 300E0E82
	v_lshlrev_b32_e32 v2, 2, v2                                // 0000008488A4: 30040482
	ds_bpermute_b32 v3, v2, v37                                // 0000008488A8: DACC0000 03002502
	s_waitcnt lgkmcnt(0)                                       // 0000008488B0: BF89FC07
	v_add_f32_e32 v3, v37, v3                                  // 0000008488B4: 06060725
	ds_bpermute_b32 v4, v2, v40                                // 0000008488B8: DACC0000 04002802
	ds_bpermute_b32 v5, v2, v39                                // 0000008488C0: DACC0000 05002702
	ds_bpermute_b32 v6, v2, v38                                // 0000008488C8: DACC0000 06002602
	ds_bpermute_b32 v2, v2, v34                                // 0000008488D0: DACC0000 02002202
	ds_bpermute_b32 v8, v7, v3                                 // 0000008488D8: DACC0000 08000307
	s_waitcnt lgkmcnt(3)                                       // 0000008488E0: BF89FC37
	v_dual_add_f32 v4, v40, v4 :: v_dual_add_f32 v5, v39, v5   // 0000008488E4: C9080928 04040B27
	s_waitcnt lgkmcnt(2)                                       // 0000008488EC: BF89FC27
	v_add_f32_e32 v6, v38, v6                                  // 0000008488F0: 060C0D26
	s_waitcnt lgkmcnt(0)                                       // 0000008488F4: BF89FC07
	v_dual_add_f32 v2, v34, v2 :: v_dual_add_f32 v3, v3, v8    // 0000008488F8: C9080522 02021103
	ds_bpermute_b32 v9, v7, v4                                 // 000000848900: DACC0000 09000407
	ds_bpermute_b32 v10, v7, v5                                // 000000848908: DACC0000 0A000507
	v_cndmask_b32_e32 v12, v1, v12, vcc_lo                     // 000000848910: 02181901
	ds_bpermute_b32 v11, v7, v6                                // 000000848914: DACC0000 0B000607
	ds_bpermute_b32 v7, v7, v2                                 // 00000084891C: DACC0000 07000207
	v_lshlrev_b32_e32 v12, 2, v12                              // 000000848924: 30181882
	s_waitcnt lgkmcnt(2)                                       // 000000848928: BF89FC27
	v_dual_add_f32 v4, v4, v9 :: v_dual_add_f32 v5, v5, v10    // 00000084892C: C9081304 04041505
	ds_bpermute_b32 v8, v12, v4                                // 000000848934: DACC0000 0800040C
	ds_bpermute_b32 v9, v12, v5                                // 00000084893C: DACC0000 0900050C
	s_waitcnt lgkmcnt(3)                                       // 000000848944: BF89FC37
	v_add_f32_e32 v6, v6, v11                                  // 000000848948: 060C1706
	s_waitcnt lgkmcnt(1)                                       // 00000084894C: BF89FC17
	v_add_f32_e32 v4, v4, v8                                   // 000000848950: 06081104
	v_add_f32_e32 v2, v2, v7                                   // 000000848954: 06040F02
	ds_bpermute_b32 v7, v12, v3                                // 000000848958: DACC0000 0700030C
	s_waitcnt lgkmcnt(1)                                       // 000000848960: BF89FC17
	v_add_f32_e32 v5, v5, v9                                   // 000000848964: 060A1305
	ds_bpermute_b32 v10, v12, v6                               // 000000848968: DACC0000 0A00060C
	ds_bpermute_b32 v11, v12, v2                               // 000000848970: DACC0000 0B00020C
	v_xor_b32_e32 v12, 2, v1                                   // 000000848978: 3A180282
	s_delay_alu instid0(VALU_DEP_1)                            // 00000084897C: BF870001
	v_cmp_gt_u32_e32 vcc_lo, 32, v12                           // 000000848980: 7C9818A0
	s_waitcnt lgkmcnt(2)                                       // 000000848984: BF89FC27
	v_dual_add_f32 v3, v3, v7 :: v_dual_cndmask_b32 v12, v1, v12// 000000848988: C9120F03 030C1901
	s_waitcnt lgkmcnt(1)                                       // 000000848990: BF89FC17
	v_add_f32_e32 v6, v6, v10                                  // 000000848994: 060C1506
	s_waitcnt lgkmcnt(0)                                       // 000000848998: BF89FC07
	v_add_f32_e32 v2, v2, v11                                  // 00000084899C: 06041702
	v_lshlrev_b32_e32 v12, 2, v12                              // 0000008489A0: 30181882
	ds_bpermute_b32 v7, v12, v3                                // 0000008489A4: DACC0000 0700030C
	ds_bpermute_b32 v8, v12, v4                                // 0000008489AC: DACC0000 0800040C
	ds_bpermute_b32 v9, v12, v5                                // 0000008489B4: DACC0000 0900050C
	ds_bpermute_b32 v10, v12, v6                               // 0000008489BC: DACC0000 0A00060C
	ds_bpermute_b32 v11, v12, v2                               // 0000008489C4: DACC0000 0B00020C
	v_xor_b32_e32 v12, 1, v1                                   // 0000008489CC: 3A180281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008489D0: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v12                           // 0000008489D4: 7C9818A0
	v_cndmask_b32_e32 v1, v1, v12, vcc_lo                      // 0000008489D8: 02021901
	s_waitcnt lgkmcnt(4)                                       // 0000008489DC: BF89FC47
	v_dual_add_f32 v1, v3, v7 :: v_dual_lshlrev_b32 v12, 2, v1 // 0000008489E0: C9220F03 010C0282
	s_waitcnt lgkmcnt(2)                                       // 0000008489E8: BF89FC27
	v_dual_add_f32 v3, v4, v8 :: v_dual_add_f32 v4, v5, v9     // 0000008489EC: C9081104 03041305
	s_waitcnt lgkmcnt(1)                                       // 0000008489F4: BF89FC17
	v_add_f32_e32 v7, v6, v10                                  // 0000008489F8: 060E1506
	s_waitcnt lgkmcnt(0)                                       // 0000008489FC: BF89FC07
	v_add_f32_e32 v2, v2, v11                                  // 000000848A00: 06041702
	ds_bpermute_b32 v5, v12, v1                                // 000000848A04: DACC0000 0500010C
	ds_bpermute_b32 v8, v12, v3                                // 000000848A0C: DACC0000 0800030C
	ds_bpermute_b32 v9, v12, v4                                // 000000848A14: DACC0000 0900040C
	ds_bpermute_b32 v10, v12, v7                               // 000000848A1C: DACC0000 0A00070C
	ds_bpermute_b32 v6, v12, v2                                // 000000848A24: DACC0000 0600020C
	v_cmpx_eq_u32_e32 0, v30                                   // 000000848A2C: 7D943C80
	s_cbranch_execz 18                                         // 000000848A30: BFA50012 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi8ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0xe7c>
	v_mul_u32_u24_e32 v11, 20, v29                             // 000000848A34: 16163A94
	s_waitcnt lgkmcnt(0)                                       // 000000848A38: BF89FC07
	v_dual_add_f32 v3, v3, v8 :: v_dual_add_f32 v2, v2, v6     // 000000848A3C: C9081103 03020D02
	v_add_f32_e32 v1, v1, v5                                   // 000000848A44: 06020B01
	v_dual_add_f32 v7, v7, v10 :: v_dual_add_f32 v4, v4, v9    // 000000848A48: C9081507 07041304
	v_or_b32_e32 v5, 0x400, v11                                // 000000848A50: 380A16FF 00000400
	v_mad_u32_u24 v8, v29, 20, 0x408                           // 000000848A58: D60B0008 03FD291D 00000408
	ds_store_2addr_b32 v5, v1, v3 offset1:1                    // 000000848A64: D8380100 00030105
	ds_store_2addr_b32 v8, v4, v7 offset1:1                    // 000000848A6C: D8380100 00070408
	ds_store_b32 v11, v2 offset:1040                           // 000000848A74: D8340410 0000020B
	s_or_b32 exec_lo, exec_lo, s4                              // 000000848A7C: 8C7E047E
	.long 0xd4510004                                           // 000000848A80: D4510004
	v_cndmask_b32_e32 v0, s2, v16, vcc_lo                      // 000000848A84: 02002002
	v_cmp_gt_u32_e32 vcc_lo, 5, v0                             // 000000848A88: 7C980085
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000848A8C: BF890007
	s_barrier                                                  // 000000848A90: BFBD0000
	buffer_gl0_inv                                             // 000000848A94: E0AC0000 00000000
	s_and_b32 s4, vcc_lo, s4                                   // 000000848A9C: 8B04046A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000848AA0: BF870009
	s_and_saveexec_b32 s5, s4                                  // 000000848AA4: BE852004
	s_cbranch_execz 85                                         // 000000848AA8: BFA50055 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi8ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x1000>
	v_add_nc_u32_e32 v7, 0x400, v28                            // 000000848AAC: 4A0E38FF 00000400
	s_load_b32 s0, s[0:1], 0x48                                // 000000848AB4: F4000000 F8000048
	ds_load_2addr_b32 v[1:2], v7 offset1:5                     // 000000848ABC: D8DC0500 01000007
	ds_load_2addr_b32 v[3:4], v7 offset0:10 offset1:15         // 000000848AC4: D8DC0F0A 03000007
	ds_load_2addr_b32 v[5:6], v7 offset0:20 offset1:25         // 000000848ACC: D8DC1914 05000007
	s_waitcnt lgkmcnt(0)                                       // 000000848AD4: BF89FC07
	v_add_f32_e32 v1, 0, v1                                    // 000000848AD8: 06020280
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000848ADC: BF8700B1
	v_add_f32_e32 v8, v1, v2                                   // 000000848AE0: 06100501
	ds_load_2addr_b32 v[1:2], v7 offset0:30 offset1:35         // 000000848AE4: D8DC231E 01000007
	v_add_f32_e32 v3, v8, v3                                   // 000000848AEC: 06060708
	v_add_f32_e32 v3, v3, v4                                   // 000000848AF0: 06060903
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000848AF4: BF870091
	v_add_f32_e32 v3, v3, v5                                   // 000000848AF8: 06060B03
	v_add_f32_e32 v3, v3, v6                                   // 000000848AFC: 06060D03
	s_waitcnt lgkmcnt(0)                                       // 000000848B00: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000848B04: BF870091
	v_add_f32_e32 v1, v3, v1                                   // 000000848B08: 06020303
	v_add_f32_e32 v1, v1, v2                                   // 000000848B0C: 06020501
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000848B10: BF870091
	v_bfe_u32 v2, v1, 16, 1                                    // 000000848B14: D6100002 02052101
	v_add3_u32 v1, v1, v2, 0x7fff                              // 000000848B1C: D6550001 03FE0501 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000848B28: BF870091
	v_and_b32_e32 v1, 0xffff0000, v1                           // 000000848B2C: 360202FF FFFF0000
	v_mul_f32_e32 v1, s0, v1                                   // 000000848B34: 10020200
	s_lshl_b64 s[0:1], s[2:3], 2                               // 000000848B38: 84808202
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000848B3C: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v1                           // 000000848B40: 100202FF BFB8AA3B
	v_exp_f32_e32 v1, v1                                       // 000000848B48: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000848B4C: BF870095
	v_add_f32_e32 v4, 1.0, v1                                  // 000000848B50: 060802F2
	v_div_scale_f32 v5, null, v4, v4, 1.0                      // 000000848B54: D6FC7C05 03CA0904
	v_div_scale_f32 v7, vcc_lo, 1.0, v4, 1.0                   // 000000848B5C: D6FC6A07 03CA08F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000848B64: BF870292
	v_rcp_f32_e32 v6, v5                                       // 000000848B68: 7E0C5505
	v_fma_f32 v1, -v5, v6, 1.0                                 // 000000848B6C: D6130001 23CA0D05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000848B74: BF870121
	v_fmac_f32_e32 v6, v1, v6                                  // 000000848B78: 560C0D01
	v_mad_u64_u32 v[1:2], null, s16, v0, 0                     // 000000848B7C: D6FE7C01 02020010
	v_mul_f32_e32 v8, v7, v6                                   // 000000848B84: 10100D07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000848B88: BF870091
	v_fma_f32 v3, -v5, v8, v7                                  // 000000848B8C: D6130003 241E1105
	v_fmac_f32_e32 v8, v3, v6                                  // 000000848B94: 56100D03
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000848B98: BF870114
	v_mad_u64_u32 v[2:3], null, s17, v0, v[2:3]                // 000000848B9C: D6FE7C02 040A0011
	v_fma_f32 v0, -v5, v8, v7                                  // 000000848BA4: D6130000 241E1105
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000848BAC: BF870191
	v_div_fmas_f32 v3, v0, v6, v8                              // 000000848BB0: D6370003 04220D00
	.long 0xd73c0000                                           // 000000848BB8: D73C0000
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 000000848BBC: 02020282
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000848BC0: BF870112
	v_div_fixup_f32 v2, v3, v4, 1.0                            // 000000848BC4: D6270002 03CA0903
	.long 0xd7006a00                                           // 000000848BCC: D7006A00
	v_cndmask_b32_e32 v1, s12, v0, vcc_lo                      // 000000848BD0: 0202000C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000848BD4: BF870191
	v_add_co_ci_u32_e64 v1, null, s13, v1, vcc_lo              // 000000848BD8: D5207C01 01AA020D
	v_add_f32_e32 v2, v2, v2                                   // 000000848BE0: 06040502
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000848BE4: BF870093
	.long 0xd7006a00                                           // 000000848BE8: D7006A00
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 000000848BEC: 02000100
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 000000848BF0: D5207C01 01AA0201
	global_store_b32 v[0:1], v2, off                           // 000000848BF8: DC6A0000 007C0200
	s_endpgm                                                   // 000000848C00: BFB00000
		...

