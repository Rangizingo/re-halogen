0000000000910500 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi2ELi4EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi>:
; _ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi2ELi4EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi():
	s_clause 0x1                                               // 000000910500: BF850001
	s_load_b32 s3, s[0:1], 0x88                                // 000000910504: F40000C0 F8000088
	s_load_b512 s[12:27], s[0:1], null                         // 00000091050C: F4100300 F8000000
	s_mov_b32 s4, -1                                           // 000000910514: BE8400C1
	s_waitcnt lgkmcnt(0)                                       // 000000910518: BF89FC07
	s_cmp_lt_i32 s2, s3                                        // 00000091051C: BF040302
	s_cbranch_scc1 2673                                        // 000000910520: BFA20A71 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi2ELi4EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0x29e8>
	s_load_b64 s[8:9], s[0:1], 0x7c                            // 000000910524: F4040200 F800007C
	s_sub_i32 s28, s2, s3                                      // 00000091052C: 819C0302
	s_clause 0x1                                               // 000000910530: BF850001
	s_load_b256 s[44:51], s[0:1], 0x60                         // 000000910534: F40C0B00 F8000060
	s_load_b256 s[36:43], s[0:1], 0x40                         // 00000091053C: F40C0900 F8000040
	v_lshrrev_b32_e32 v19, 5, v0                               // 000000910544: 32260085
	v_and_b32_e32 v20, 31, v0                                  // 000000910548: 3628009F
	s_mov_b32 s34, 0                                           // 00000091054C: BEA20080
	s_mov_b32 s33, exec_lo                                     // 000000910550: BEA1007E
	s_waitcnt lgkmcnt(0)                                       // 000000910554: BF89FC07
	s_abs_i32 s4, s9                                           // 000000910558: BE841509
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_2)// 00000091055C: BF870529
	s_cvt_f32_u32 s5, s4                                       // 000000910560: BE856504
	s_sub_i32 s6, 0, s4                                        // 000000910564: 81860480
	v_rcp_iflag_f32_e32 v1, s5                                 // 000000910568: 7E025605
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_3)// 00000091056C: BF8705A5
	v_readfirstlane_b32 s5, v1                                 // 000000910570: 7E0A0501
	s_mul_f32 s5, s5, 0x4f7ffffe                               // 000000910574: A205FF05 4F7FFFFE
	s_cvt_u32_f32 s5, s5                                       // 00000091057C: BE856705
	s_delay_alu instid0(SALU_CYCLE_3) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000910580: BF87049B
	s_mul_i32 s6, s6, s5                                       // 000000910584: 96060506
	s_mul_hi_u32 s6, s5, s6                                    // 000000910588: 96860605
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 00000091058C: BF8704B9
	s_add_i32 s5, s5, s6                                       // 000000910590: 81050605
	s_ashr_i32 s6, s9, 31                                      // 000000910594: 86069F09
	s_mul_hi_u32 s3, s28, s5                                   // 000000910598: 9683051C
	s_mul_i32 s5, s3, s4                                       // 00000091059C: 96050403
	s_add_i32 s7, s3, 1                                        // 0000009105A0: 81078103
	s_sub_i32 s5, s28, s5                                      // 0000009105A4: 8185051C
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000009105A8: BF870009
	s_sub_i32 s10, s5, s4                                      // 0000009105AC: 818A0405
	s_cmp_ge_u32 s5, s4                                        // 0000009105B0: BF090405
	s_cselect_b32 s3, s7, s3                                   // 0000009105B4: 98030307
	s_cselect_b32 s5, s10, s5                                  // 0000009105B8: 9805050A
	s_add_i32 s7, s3, 1                                        // 0000009105BC: 81078103
	s_cmp_ge_u32 s5, s4                                        // 0000009105C0: BF090405
	s_cselect_b32 s3, s7, s3                                   // 0000009105C4: 98030307
	s_ashr_i32 s11, s50, 31                                    // 0000009105C8: 860B9F32
	s_xor_b32 s3, s3, s6                                       // 0000009105CC: 8D030603
	s_lshr_b32 s0, s11, 25                                     // 0000009105D0: 8500990B
	s_sub_i32 s10, s3, s6                                      // 0000009105D4: 818A0603
	s_add_i32 s0, s50, s0                                      // 0000009105D8: 81000032
	s_mul_i32 s30, s10, s9                                     // 0000009105DC: 961E090A
	s_ashr_i32 s0, s0, 7                                       // 0000009105E0: 86008700
	s_sub_i32 s29, s28, s30                                    // 0000009105E4: 819D1E1C
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000009105E8: BF870499
	s_mul_i32 s29, s29, s8                                     // 0000009105EC: 961D081D
	s_add_i32 s1, s29, s8                                      // 0000009105F0: 8101081D
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000009105F4: BF870499
	s_min_i32 s0, s0, s1                                       // 0000009105F8: 89000100
	s_sub_i32 s35, s0, s29                                     // 0000009105FC: 81A31D00
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000910600: BF870499
	s_lshl_b32 s31, s35, 2                                     // 000000910604: 841F8223
	.long 0xd4c4007e                                           // 000000910608: D4C4007E
	v_cndmask_b32_e32 v1, s31, v19, vcc_lo                     // 00000091060C: 0202261F
	s_cbranch_execz 503                                        // 000000910610: BFA501F7 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi2ELi4EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0x8f0>
	s_add_i32 s51, s48, -1                                     // 000000910614: 8133C130
	s_cmp_lg_u64 s[40:41], 0                                   // 000000910618: BF118028
	v_dual_mov_b32 v8, v19 :: v_dual_and_b32 v1, 1, v0         // 00000091061C: CA240113 08000081
	s_cselect_b32 s52, -1, 0                                   // 000000910624: 983480C1
	s_abs_i32 s53, s35                                         // 000000910628: BEB51523
	v_and_b32_e32 v2, 2, v0                                    // 00000091062C: 36040082
	s_cvt_f32_u32 s0, s53                                      // 000000910630: BE806535
	v_lshlrev_b32_e32 v6, 3, v20                               // 000000910634: 300C2883
	v_lshlrev_b32_e32 v7, 7, v19                               // 000000910638: 300E2687
	v_and_b32_e32 v3, 4, v0                                    // 00000091063C: 36060084
	v_rcp_iflag_f32_e32 v4, s0                                 // 000000910640: 7E085600
	v_and_b32_e32 v5, 8, v0                                    // 000000910644: 360A0088
	.long 0xd44a0001                                           // 000000910648: D44A0001
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 00000091064C: 02020280
	.long 0xd44a0003                                           // 000000910650: D44A0003
	v_cndmask_b32_e32 v1, 0, v2, vcc_lo                        // 000000910654: 02020480
	v_lshl_or_b32 v1, v19, 8, v6                               // 000000910658: D6560001 04191113
	v_lshl_add_u32 v2, s29, 7, v7                              // 000000910660: D6460002 041D0E1D
	s_ashr_i32 s55, s35, 31                                    // 000000910668: 86379F23
	s_sub_i32 s57, 0, s53                                      // 00000091066C: 81B93580
	s_mul_i32 s8, s55, 0x1400                                  // 000000910670: 9608FF37 00001400
	.long 0xd44c0000                                           // 000000910678: D44C0000
	v_cndmask_b32_e32 v1, 16, v20, vcc_lo                      // 00000091067C: 02022890
	v_readfirstlane_b32 s5, v4                                 // 000000910680: 7E0A0504
	.long 0xd44a0004                                           // 000000910684: D44A0004
	v_cndmask_b32_e32 v1, 0, v3, vcc_lo                        // 000000910688: 02020680
	v_subrev_nc_u32_e32 v9, s8, v1                             // 00000091068C: 4E120208
	v_lshl_or_b32 v1, v20, 2, v2                               // 000000910690: D6560001 04090514
	s_lshl_b32 s6, s35, 7                                      // 000000910698: 84068723
	s_mul_f32 s7, s5, 0x4f7ffffe                               // 00000091069C: A207FF05 4F7FFFFE
	.long 0xd44a0005                                           // 0000009106A4: D44A0005
	v_cndmask_b32_e32 v1, 0, v5, vcc_lo                        // 0000009106A8: 02020A80
	s_mov_b32 s54, 0x76543210                                  // 0000009106AC: BEB600FF 76543210
	s_lshl_b32 s56, s35, 8                                     // 0000009106B4: 84388823
	s_cvt_u32_f32 s7, s7                                       // 0000009106B8: BE876707
	s_mov_b32 s59, 0x3db504f3                                  // 0000009106BC: BEBB00FF 3DB504F3
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000009106C4: BF87049A
	s_mul_i32 s57, s57, s7                                     // 0000009106C8: 96390739
	s_mul_hi_u32 s8, s7, s57                                   // 0000009106CC: 96883907
	s_sub_i32 s57, 0, s6                                       // 0000009106D0: 81B90680
	s_add_i32 s58, s7, s8                                      // 0000009106D4: 813A0807
	s_branch 164                                               // 0000009106D8: BFA000A4 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi2ELi4EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0x46c>
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000009106DC: BF870091
	.long 0xd7006a02                                           // 0000009106E0: D7006A02
	v_cndmask_b32_e32 v1, s26, v2, vcc_lo                      // 0000009106E4: 0202041A
	v_add_co_ci_u32_e64 v3, null, s27, v3, vcc_lo              // 0000009106E8: D5207C03 01AA061B
	v_sub_f32_e32 v4, v15, v13                                 // 0000009106F0: 08081B0F
	v_add_nc_u32_e32 v1, 0x400, v1                             // 0000009106F4: 4A0202FF 00000400
	global_load_d16_b16 v2, v[2:3], off offset:6               // 0000009106FC: DC820006 027C0002
	s_waitcnt vmcnt(0)                                         // 000000910704: BF8903F7
	v_fma_mix_f32 v5, v14, v2, v12 op_sel_hi:[0,1,0]           // 000000910708: CC200005 1432050E
	v_fma_mix_f32 v2, -v14, v2, v12 op_sel_hi:[0,1,0]          // 000000910710: CC200002 3432050E
	v_add_f32_e32 v3, v15, v13                                 // 000000910718: 06061B0F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000091071C: BF8701A2
	v_add_f32_e32 v7, v4, v2                                   // 000000910720: 060E0504
	v_sub_f32_e32 v2, v4, v2                                   // 000000910724: 08040504
	v_add_f32_e32 v6, v3, v5                                   // 000000910728: 060C0B03
	v_sub_f32_e32 v3, v3, v5                                   // 00000091072C: 08060B03
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000910730: BF870193
	v_mov_b32_dpp v13, v2 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000910734: 7E1A02FA FF016102
	v_mov_b32_dpp v4, v6 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000091073C: 7E0802FA FF016106
	v_cndmask_b32_e64 v6, -v6, v6, s1                          // 000000910744: D5010006 20060D06
	v_cndmask_b32_e64 v2, -v2, v2, s1                          // 00000091074C: D5010002 20060502
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000910754: BF870142
	v_add_f32_e32 v4, v6, v4                                   // 000000910758: 06080906
	v_mov_b32_dpp v5, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000091075C: 7E0A02FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, s1                          // 000000910764: D5010007 20060F07
	.long 0xd72c0006                                           // 00000091076C: D72C0006
	v_cndmask_b32_e32 v1, 0x1400, v11, vcc_lo                  // 000000910770: 020216FF 00001400
	v_add_f32_e32 v5, v7, v5                                   // 000000910778: 060A0B07
	v_mov_b32_dpp v7, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000091077C: 7E0E02FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, s3                          // 000000910784: D5010004 200E0904
	s_delay_alu instid0(VALU_DEP_1)                            // 00000091078C: BF870001
	v_add_f32_e32 v4, v4, v7                                   // 000000910790: 06080F04
	v_mov_b32_dpp v12, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000910794: 7E1802FA FF016103
	v_cndmask_b32_e64 v3, -v3, v3, s1                          // 00000091079C: D5010003 20060703
	.long 0xd72c0007                                           // 0000009107A4: D72C0007
	v_cndmask_b32_e32 v1, s56, v10, vcc_lo                     // 0000009107A8: 02021438
	v_add_f32_e32 v2, v2, v13                                  // 0000009107AC: 06041B02
	v_mov_b32_dpp v10, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009107B0: 7E1402FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s4                          // 0000009107B8: D5010004 20120904
	v_add_f32_e32 v3, v3, v12                                  // 0000009107C0: 06061903
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000009107C4: BF870224
	v_mov_b32_dpp v13, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009107C8: 7E1A02FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, s3                          // 0000009107D0: D5010002 200E0502
	v_add_f32_e32 v4, v4, v10                                  // 0000009107D8: 06081504
	v_mov_b32_dpp v11, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009107DC: 7E1602FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, s3                          // 0000009107E4: D5010005 200E0B05
	v_mov_b32_dpp v12, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009107EC: 7E1802FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, s3                          // 0000009107F4: D5010003 200E0703
	v_add_f32_e32 v2, v2, v13                                  // 0000009107FC: 06041B02
	v_mov_b32_dpp v10, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000910800: 7E1402FA FF016804
	v_add_f32_e32 v5, v5, v11                                  // 000000910808: 060A1705
	v_cndmask_b32_e64 v4, -v4, v4, s5                          // 00000091080C: D5010004 20160904
	v_add_f32_e32 v3, v3, v12                                  // 000000910814: 06061903
	v_mov_b32_dpp v13, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000910818: 7E1A02FA FF016402
	v_cndmask_b32_e64 v2, -v2, v2, s4                          // 000000910820: D5010002 20120502
	v_mov_b32_dpp v11, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000910828: 7E1602FA FF016405
	v_cndmask_b32_e64 v5, -v5, v5, s4                          // 000000910830: D5010005 20120B05
	v_mov_b32_dpp v12, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000910838: 7E1802FA FF016403
	v_cndmask_b32_e64 v3, -v3, v3, s4                          // 000000910840: D5010003 20120703
	v_add_f32_e32 v2, v2, v13                                  // 000000910848: 06041B02
	v_sub_nc_u32_e32 v6, v6, v7                                // 00000091084C: 4C0C0F06
	v_add_f32_e32 v5, v5, v11                                  // 000000910850: 060A1705
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000910854: BF870214
	v_add_f32_e32 v3, v3, v12                                  // 000000910858: 06061903
	v_mov_b32_dpp v13, v2 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000091085C: 7E1A02FA FF016802
	v_cndmask_b32_e64 v2, -v2, v2, s5                          // 000000910864: D5010002 20160502
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 00000091086C: BF870254
	v_mov_b32_dpp v11, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000910870: 7E1602FA FF016805
	v_cndmask_b32_e64 v5, -v5, v5, s5                          // 000000910878: D5010005 20160B05
	v_add_nc_u32_e32 v8, 8, v8                                 // 000000910880: 4A101088
	v_mov_b32_dpp v12, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000910884: 7E1802FA FF016803
	v_cndmask_b32_e64 v3, -v3, v3, s5                          // 00000091088C: D5010003 20160703
	v_dual_add_f32 v4, v4, v10 :: v_dual_add_f32 v5, v5, v11   // 000000910894: C9081504 04041705
	v_add_f32_e32 v2, v2, v13                                  // 00000091089C: 06041B02
	v_cmp_le_i32_e32 vcc_lo, s31, v8                           // 0000009108A0: 7C86101F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009108A4: BF870214
	v_dual_add_f32 v3, v3, v12 :: v_dual_add_nc_u32 v6, v9, v6 // 0000009108A8: C9201903 03060D09
	v_dual_mov_b32 v11, v5 :: v_dual_mov_b32 v10, v4           // 0000009108B0: CA100105 0B0A0104
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000009108B8: BF870234
	v_mov_b32_e32 v13, v2                                      // 0000009108BC: 7E1A0302
	v_cndmask_b32_e64 v5, -v5, v5, s0                          // 0000009108C0: D5010005 20020B05
	v_cndmask_b32_e64 v4, -v4, v4, s0                          // 0000009108C8: D5010004 20020904
	v_permlanex16_b32 v11, v11, s54, 0xfedcba98                // 0000009108D0: D65C000B 03FC6D0B FEDCBA98
	v_mov_b32_e32 v12, v3                                      // 0000009108DC: 7E180303
	v_cndmask_b32_e64 v2, -v2, v2, s0                          // 0000009108E0: D5010002 20020502
	v_cndmask_b32_e64 v3, -v3, v3, s0                          // 0000009108E8: D5010003 20020703
	v_permlanex16_b32 v10, v10, s54, 0xfedcba98                // 0000009108F0: D65C000A 03FC6D0A FEDCBA98
	v_permlanex16_b32 v13, v13, s54, 0xfedcba98                // 0000009108FC: D65C000D 03FC6D0D FEDCBA98
	v_add_f32_e32 v5, v5, v11                                  // 000000910908: 060A1705
	v_permlanex16_b32 v12, v12, s54, 0xfedcba98                // 00000091090C: D65C000C 03FC6D0C FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000910918: BF870214
	v_dual_add_f32 v4, v4, v10 :: v_dual_add_nc_u32 v9, 0x800, v9// 00000091091C: C9201504 040812FF 00000800
	v_add_f32_e32 v7, v2, v13                                  // 000000910928: 060E1B02
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000091092C: BF870214
	v_fma_mixhi_f16 v2, v5, s59, 0                             // 000000910930: CC220002 02007705
	v_add_f32_e32 v10, v3, v12                                 // 000000910938: 06141903
	s_or_b32 s34, vcc_lo, s34                                  // 00000091093C: 8C22226A
	v_fma_mixlo_f16 v2, v4, s59, 0                             // 000000910940: CC210002 02007704
	v_fma_mixhi_f16 v3, v7, s59, 0                             // 000000910948: CC220003 02007707
	s_delay_alu instid0(VALU_DEP_3)                            // 000000910950: BF870003
	v_fma_mixlo_f16 v3, v10, s59, 0                            // 000000910954: CC210003 0200770A
	ds_store_b64 v6, v[2:3]                                    // 00000091095C: D9340000 00000206
	s_and_not1_b32 exec_lo, exec_lo, s34                       // 000000910964: 917E227E
	s_cbranch_execz 289                                        // 000000910968: BFA50121 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi2ELi4EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0x8f0>
	.long 0xd72d0002                                           // 00000091096C: D72D0002
	v_cndmask_b32_e32 v0, v8, v58, vcc_lo                      // 000000910970: 02007508
	s_mov_b32 s6, -1                                           // 000000910974: BE8600C1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000910978: BF870091
	.long 0xd72c0003                                           // 00000091097C: D72C0003
	v_cndmask_b32_e32 v0, v2, v53, vcc_lo                      // 000000910980: 02006B02
	v_sub_nc_u32_e32 v3, v8, v3                                // 000000910984: 4C060708
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000910988: BF870121
	v_subrev_nc_u32_e32 v5, s53, v3                            // 00000091098C: 4E0A0635
	v_cmp_le_u32_e32 vcc_lo, s53, v3                           // 000000910990: 7C960635
	v_dual_cndmask_b32 v3, v3, v5 :: v_dual_add_nc_u32 v4, 1, v2// 000000910994: CA600B03 03040481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000091099C: BF870111
	v_cndmask_b32_e32 v2, v2, v4, vcc_lo                       // 0000009109A0: 02040902
	v_cmp_le_u32_e32 vcc_lo, s53, v3                           // 0000009109A4: 7C960635
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000009109A8: BF870092
	v_add_nc_u32_e32 v4, 1, v2                                 // 0000009109AC: 4A080481
	v_cndmask_b32_e32 v2, v2, v4, vcc_lo                       // 0000009109B0: 02040902
	s_and_not1_b32 vcc_lo, exec_lo, s52                        // 0000009109B4: 916A347E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000009109B8: BF870091
	v_xor_b32_e32 v11, s55, v2                                 // 0000009109BC: 3A160437
	v_subrev_nc_u32_e32 v10, s55, v11                          // 0000009109C0: 4E141637
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000009109C4: BF8700A1
	v_mad_u64_u32 v[6:7], null, s57, v10, v[1:2]               // 0000009109C8: D6FE7C06 04061439
	v_min_i32_e32 v2, s51, v10                                 // 0000009109D0: 22041433
	v_mad_i64_i32 v[4:5], null, v2, s50, 0                     // 0000009109D4: D6FF7C04 02006502
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000009109DC: BF870093
	v_ashrrev_i32_e32 v7, 31, v6                               // 0000009109E0: 340E0C9F
	.long 0xd73c0002                                           // 0000009109E4: D73C0002
	v_cndmask_b32_e32 v1, 1, v6, vcc_lo                        // 0000009109E8: 02020C81
	s_cbranch_vccnz 212                                        // 0000009109EC: BFA400D4 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi2ELi4EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0x840>
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000009109F0: BF870093
	.long 0xd7006a06                                           // 0000009109F4: D7006A06
	v_cndmask_b32_e32 v1, v4, v6, vcc_lo                       // 0000009109F8: 02020D04
	v_add_co_ci_u32_e64 v7, null, v5, v7, vcc_lo               // 0000009109FC: D5207C07 01AA0F05
	.long 0x7f3c3880                                           // 000000910A04: 7F3C3880
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000910A08: BF870112
	.long 0xd73c0006                                           // 000000910A0C: D73C0006
	v_cndmask_b32_e32 v1, 1, v6, vcc_lo                        // 000000910A10: 02020C81
	.long 0x7f42399e                                           // 000000910A14: 7F42399E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000910A18: BF870092
	.long 0xd7006a0c                                           // 000000910A1C: D7006A0C
	v_cndmask_b32_e32 v1, s38, v6, vcc_lo                      // 000000910A20: 02020C26
	v_add_co_ci_u32_e64 v13, null, s39, v7, vcc_lo             // 000000910A24: D5207C0D 01AA0E27
	.long 0xd7006a06                                           // 000000910A2C: D7006A06
	v_cndmask_b32_e32 v1, s40, v6, vcc_lo                      // 000000910A30: 02020C28
	s_delay_alu instid0(VALU_DEP_1)                            // 000000910A34: BF870001
	v_add_co_ci_u32_e64 v7, null, s41, v7, vcc_lo              // 000000910A38: D5207C07 01AA0E29
	global_load_b64 v[12:13], v[12:13], off                    // 000000910A40: DC560000 0C7C000C
	.long 0xd7006a0e                                           // 000000910A48: D7006A0E
	v_cndmask_b32_e32 v1, s26, v2, vcc_lo                      // 000000910A4C: 0202041A
	global_load_b64 v[6:7], v[6:7], off                        // 000000910A50: DC560000 067C0006
	v_add_co_ci_u32_e64 v15, null, s27, v3, vcc_lo             // 000000910A58: D5207C0F 01AA061B
	s_clause 0x1                                               // 000000910A60: BF850001
	global_load_b32 v16, v[14:15], off                         // 000000910A64: DC520000 107C000E
	global_load_d16_b16 v14, v[14:15], off offset:4            // 000000910A6C: DC820004 0E7C000E
	s_waitcnt vmcnt(3)                                         // 000000910A74: BF890FF7
	.long 0x7e1e390c                                           // 000000910A78: 7E1E390C
	s_waitcnt vmcnt(2)                                         // 000000910A7C: BF890BF7
	v_and_b32_e32 v40, 0xffff0000, v6                          // 000000910A80: 36500CFF FFFF0000
	v_lshlrev_b32_e32 v6, 16, v6                               // 000000910A88: 300C0C90
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000910A8C: BF870093
	v_lshlrev_b32_e32 v15, 16, v15                             // 000000910A90: 301E1E90
	v_mul_f32_e32 v21, 0xbfb8aa3b, v15                         // 000000910A94: 102A1EFF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000910A9C: BF870291
	v_exp_f32_e32 v21, v21                                     // 000000910AA0: 7E2A4B15
	v_dual_add_f32 v21, 1.0, v21 :: v_dual_and_b32 v12, 0xffff0000, v12// 000000910AA4: C9242AF2 150C18FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000910AB0: BF870111
	v_mul_f32_e32 v18, 0xbfb8aa3b, v12                         // 000000910AB4: 102418FF BFB8AA3B
	v_div_scale_f32 v25, null, v21, v21, v15                   // 000000910ABC: D6FC7C19 043E2B15
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000910AC4: BF8701B2
	v_exp_f32_e32 v18, v18                                     // 000000910AC8: 7E244B12
	v_lshlrev_b32_e32 v17, 16, v13                             // 000000910ACC: 30221A90
	v_div_scale_f32 v38, s7, v15, v21, v15                     // 000000910AD0: D6FC0726 043E2B0F
	v_rcp_f32_e32 v29, v25                                     // 000000910AD8: 7E3A5519
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000910ADC: BF870196
	v_add_f32_e32 v18, 1.0, v18                                // 000000910AE0: 062424F2
	v_mul_f32_e32 v22, 0xbfb8aa3b, v17                         // 000000910AE4: 102C22FF BFB8AA3B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000910AEC: BF870195
	v_fma_f32 v37, -v25, v29, 1.0                              // 000000910AF0: D6130025 23CA3B19
	v_div_scale_f32 v24, null, v18, v18, v12                   // 000000910AF8: D6FC7C18 04322512
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000910B00: BF8701B3
	v_exp_f32_e32 v22, v22                                     // 000000910B04: 7E2C4B16
	v_and_b32_e32 v13, 0xffff0000, v13                         // 000000910B08: 361A1AFF FFFF0000
	v_div_scale_f32 v34, vcc_lo, v12, v18, v12                 // 000000910B10: D6FC6A22 0432250C
	v_rcp_f32_e32 v27, v24                                     // 000000910B18: 7E365518
	s_delay_alu instid0(TRANS32_DEP_2) | instid1(VALU_DEP_2)   // 000000910B1C: BF870106
	v_dual_add_f32 v22, 1.0, v22 :: v_dual_mul_f32 v23, 0xbfb8aa3b, v13// 000000910B20: C9062CF2 16161AFF BFB8AA3B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000910B2C: BF870115
	v_fma_f32 v35, -v24, v27, 1.0                              // 000000910B30: D6130023 23CA3718
	v_div_scale_f32 v26, null, v22, v22, v17                   // 000000910B38: D6FC7C1A 04462D16
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000910B40: BF8701A3
	v_exp_f32_e32 v23, v23                                     // 000000910B44: 7E2E4B17
	v_div_scale_f32 v36, s6, v17, v22, v17                     // 000000910B48: D6FC0624 04462D11
	v_fmac_f32_e32 v27, v35, v27                               // 000000910B50: 56363723
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 000000910B54: BF870313
	v_rcp_f32_e32 v31, v26                                     // 000000910B58: 7E3E551A
	v_add_f32_e32 v23, 1.0, v23                                // 000000910B5C: 062E2EF2
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000910B60: BF870115
	v_fma_f32 v39, -v26, v31, 1.0                              // 000000910B64: D6130027 23CA3F1A
	v_div_scale_f32 v28, null, v23, v23, v13                   // 000000910B6C: D6FC7C1C 04362F17
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000910B74: BF8701A2
	v_fmac_f32_e32 v31, v39, v31                               // 000000910B78: 563E3F27
	v_mul_f32_e32 v39, v34, v27                                // 000000910B7C: 104E3722
	v_rcp_f32_e32 v32, v28                                     // 000000910B80: 7E40551C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000910B84: BF870112
	v_mul_f32_e32 v41, v36, v31                                // 000000910B88: 10523F24
	v_fma_f32 v42, -v24, v39, v34                              // 000000910B8C: D613002A 248A4F18
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000910B94: BF870112
	v_fma_f32 v45, -v26, v41, v36                              // 000000910B98: D613002D 2492531A
	v_fmac_f32_e32 v39, v42, v27                               // 000000910BA0: 564E372A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000910BA4: BF870195
	v_fma_f32 v35, -v28, v32, 1.0                              // 000000910BA8: D6130023 23CA411C
	v_fmac_f32_e32 v41, v45, v31                               // 000000910BB0: 56523F2D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000910BB4: BF870193
	v_fma_f32 v24, -v24, v39, v34                              // 000000910BB8: D6130018 248A4F18
	v_fmac_f32_e32 v32, v35, v32                               // 000000910BC0: 56404123
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000910BC4: BF870193
	v_fma_f32 v26, -v26, v41, v36                              // 000000910BC8: D613001A 2492531A
	v_div_fmas_f32 v24, v24, v27, v39                          // 000000910BD0: D6370018 049E3718
	s_mov_b32 vcc_lo, s7                                       // 000000910BD8: BEEA0007
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000910BDC: BF870131
	v_div_fixup_f32 v12, v24, v18, v12                         // 000000910BE0: D627000C 04322518
	v_fmac_f32_e32 v29, v37, v29                               // 000000910BE8: 563A3B25
	v_div_scale_f32 v37, s8, v13, v23, v13                     // 000000910BEC: D6FC0825 04362F0D
	v_dual_mul_f32 v12, v12, v40 :: v_dual_mul_f32 v35, v38, v29// 000000910BF4: C8C6510C 0C223B26
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000910BFC: BF870112
	v_mul_f32_e32 v43, v37, v32                                // 000000910C00: 10564125
	.long 0x7e3c398c                                           // 000000910C04: 7E3C398C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000910C08: BF870193
	v_fma_f32 v44, -v25, v35, v38                              // 000000910C0C: D613002C 249A4719
	v_fma_f32 v42, -v28, v43, v37                              // 000000910C14: D613002A 2496571C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000910C1C: BF870112
	v_fmac_f32_e32 v35, v44, v29                               // 000000910C20: 56463B2C
	v_fmac_f32_e32 v43, v42, v32                               // 000000910C24: 5656412A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000910C28: BF870112
	v_fma_f32 v25, -v25, v35, v38                              // 000000910C2C: D6130019 249A4719
	v_fma_f32 v24, -v28, v43, v37                              // 000000910C34: D6130018 2496571C
	s_delay_alu instid0(VALU_DEP_2)                            // 000000910C3C: BF870002
	v_div_fmas_f32 v25, v25, v29, v35                          // 000000910C40: D6370019 048E3B19
	s_mov_b32 vcc_lo, s6                                       // 000000910C48: BEEA0006
	s_mov_b32 s6, 0                                            // 000000910C4C: BE860080
	v_div_fmas_f32 v18, v26, v31, v41                          // 000000910C50: D6370012 04A63F1A
	s_mov_b32 vcc_lo, s8                                       // 000000910C58: BEEA0008
	v_div_fixup_f32 v15, v25, v21, v15                         // 000000910C5C: D627000F 043E2B19
	v_lshlrev_b32_e32 v21, 16, v7                              // 000000910C64: 302A0E90
	v_and_b32_e32 v7, 0xffff0000, v7                           // 000000910C68: 360E0EFF FFFF0000
	v_div_fixup_f32 v17, v18, v22, v17                         // 000000910C70: D6270011 04462D12
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000910C78: BF8701A4
	v_mul_f32_e32 v6, v15, v6                                  // 000000910C7C: 100C0D0F
	v_div_fmas_f32 v15, v24, v32, v43                          // 000000910C80: D637000F 04AE4118
	v_mul_f32_e32 v17, v17, v21                                // 000000910C88: 10222B11
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000910C8C: BF870193
	.long 0x7e423986                                           // 000000910C90: 7E423986
	v_div_fixup_f32 v13, v15, v23, v13                         // 000000910C94: D627000D 04362F0F
	v_and_b32_e32 v15, 1, v30                                  // 000000910C9C: 361E3C81
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000910CA0: BF870214
	v_bfe_u32 v18, v17, 16, 1                                  // 000000910CA4: D6100012 02052111
	v_and_b32_e32 v21, 1, v33                                  // 000000910CAC: 362A4281
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000910CB0: BF870214
	v_mul_f32_e32 v7, v13, v7                                  // 000000910CB4: 100E0F0D
	v_add3_u32 v12, v12, v15, 0x7fff                           // 000000910CB8: D655000C 03FE1F0C 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000910CC4: BF870214
	v_add3_u32 v13, v17, v18, 0x7fff                           // 000000910CC8: D655000D 03FE2511 00007FFF
	v_add3_u32 v6, v6, v21, 0x7fff                             // 000000910CD4: D6550006 03FE2B06 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000910CE0: BF870214
	v_bfe_u32 v15, v7, 16, 1                                   // 000000910CE4: D610000F 02052107
	v_and_b32_e32 v12, 0xffff0000, v12                         // 000000910CEC: 361818FF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000910CF4: BF870214
	v_and_b32_e32 v17, 0xffff0000, v13                         // 000000910CF8: 36221AFF FFFF0000
	v_and_b32_e32 v6, 0xffff0000, v6                           // 000000910D00: 360C0CFF FFFF0000
	s_delay_alu instid0(VALU_DEP_4)                            // 000000910D08: BF870004
	v_add3_u32 v7, v7, v15, 0x7fff                             // 000000910D0C: D6550007 03FE1F07 00007FFF
	s_waitcnt vmcnt(1)                                         // 000000910D18: BF8907F7
	v_fma_mix_f32 v13, v16, v12, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000910D1C: CC20080D 8A021910
	s_waitcnt vmcnt(0)                                         // 000000910D24: BF8903F7
	v_fma_mix_f32 v12, v14, v17, neg(0) op_sel_hi:[1,0,0]      // 000000910D28: CC20000C 8A02230E
	v_fma_mix_f32 v15, v16, v6, neg(0) op_sel_hi:[1,0,0]       // 000000910D30: CC20000F 8A020D10
	v_and_b32_e32 v14, 0xffff0000, v7                          // 000000910D38: 361C0EFF FFFF0000
	s_and_not1_b32 vcc_lo, exec_lo, s6                         // 000000910D40: 916A067E
	s_cbranch_vccnz 65125                                      // 000000910D44: BFA4FE65 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi2ELi4EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0x1dc>
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000910D48: BF870093
	.long 0xd73c0004                                           // 000000910D4C: D73C0004
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 000000910D50: 02020881
	.long 0xd7006a04                                           // 000000910D54: D7006A04
	v_cndmask_b32_e32 v1, s38, v4, vcc_lo                      // 000000910D58: 02020826
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000910D5C: BF870111
	v_add_co_ci_u32_e64 v5, null, s39, v5, vcc_lo              // 000000910D60: D5207C05 01AA0A27
	.long 0xd7006a04                                           // 000000910D68: D7006A04
	v_cndmask_b32_e32 v1, v4, v2, vcc_lo                       // 000000910D6C: 02020504
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000910D70: BF8700A1
	v_add_co_ci_u32_e64 v5, null, v5, v3, vcc_lo               // 000000910D74: D5207C05 01AA0705
	.long 0xd7006a06                                           // 000000910D7C: D7006A06
	v_cndmask_b32_e32 v1, s26, v2, vcc_lo                      // 000000910D80: 0202041A
	v_add_co_ci_u32_e64 v7, null, s27, v3, vcc_lo              // 000000910D84: D5207C07 01AA061B
	global_load_b64 v[4:5], v[4:5], off                        // 000000910D8C: DC560000 047C0004
	s_clause 0x1                                               // 000000910D94: BF850001
	global_load_b32 v14, v[6:7], off                           // 000000910D98: DC520000 0E7C0006
	global_load_d16_b16 v6, v[6:7], off offset:4               // 000000910DA0: DC820004 067C0006
	s_waitcnt vmcnt(2)                                         // 000000910DA8: BF890BF7
	.long 0x7e0e3904                                           // 000000910DAC: 7E0E3904
	v_and_b32_e32 v4, 0xffff0000, v4                           // 000000910DB0: 360808FF FFFF0000
	v_lshlrev_b32_e32 v12, 16, v5                              // 000000910DB8: 30180A90
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000910DBC: BF8701A3
	v_lshlrev_b32_e32 v7, 16, v7                               // 000000910DC0: 300E0E90
	s_waitcnt vmcnt(1)                                         // 000000910DC4: BF8907F7
	v_fma_mix_f32 v13, v14, v4, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000910DC8: CC20080D 8A02090E
	s_waitcnt vmcnt(0)                                         // 000000910DD0: BF8903F7
	v_fma_mix_f32 v12, v6, v12, neg(0) op_sel_hi:[1,0,0]       // 000000910DD4: CC20000C 8A021906
	v_fma_mix_f32 v15, v14, v7, neg(0) op_sel_hi:[1,0,0]       // 000000910DDC: CC20000F 8A020F0E
	v_and_b32_e32 v14, 0xffff0000, v5                          // 000000910DE4: 361C0AFF FFFF0000
	s_branch 65083                                             // 000000910DEC: BFA0FE3B <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi2ELi4EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0x1dc>
	s_or_b32 exec_lo, exec_lo, s33                             // 000000910DF0: 8C7E217E
	s_bfe_i32 s34, s35, 0x1001c                                // 000000910DF4: 93A2FF23 0001001C
	s_lshr_b32 s3, s11, 28                                     // 000000910DFC: 85039C0B
	s_lshr_b64 s[0:1], s[34:35], 29                            // 000000910E00: 85809D22
	s_add_i32 s3, s50, s3                                      // 000000910E04: 81030332
	s_add_i32 s0, s0, 7                                        // 000000910E08: 81008700
	s_lshl_b32 s1, s35, 3                                      // 000000910E0C: 84018323
	s_ashr_i32 s0, s0, 3                                       // 000000910E10: 86008300
	s_lshl_b32 s4, s29, 3                                      // 000000910E14: 8404831D
	.long 0xd72c0001                                           // 000000910E18: D72C0001
	v_cndmask_b32_e32 v1, s0, v19, vcc_lo                      // 000000910E1C: 02022600
	v_lshlrev_b32_e32 v21, 2, v20                              // 000000910E20: 302A2882
	s_waitcnt lgkmcnt(0)                                       // 000000910E24: BF89FC07
	s_barrier                                                  // 000000910E28: BFBD0000
	buffer_gl0_inv                                             // 000000910E2C: E0AC0000 00000000
	v_add_nc_u32_e32 v2, s0, v1                                // 000000910E34: 4A040200
	s_ashr_i32 s0, s3, 4                                       // 000000910E38: 86008403
	s_ashr_i32 s3, s4, 31                                      // 000000910E3C: 86039F04
	s_mul_hi_i32 s5, s10, s0                                   // 000000910E40: 9705000A
	s_mul_i32 s0, s10, s0                                      // 000000910E44: 9600000A
	v_min_i32_e32 v23, s1, v2                                  // 000000910E48: 222E0401
	s_add_u32 s0, s0, s4                                       // 000000910E4C: 80000400
	s_addc_u32 s1, s5, s3                                      // 000000910E50: 82010305
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000910E54: BF870099
	s_lshl_b64 s[4:5], s[0:1], 10                              // 000000910E58: 84848A00
	v_cmp_lt_i32_e32 vcc_lo, v1, v23                           // 000000910E5C: 7C822F01
	s_add_u32 s1, s24, s4                                      // 000000910E60: 80010418
	s_addc_u32 s3, s25, s5                                     // 000000910E64: 82030519
	s_and_saveexec_b32 s4, vcc_lo                              // 000000910E68: BE84206A
	s_cbranch_execz 93                                         // 000000910E6C: BFA5005D <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi2ELi4EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0xae4>
	.long 0xd7010002                                           // 000000910E70: D7010002
	v_cndmask_b32_e32 v0, v20, v129, vcc_lo                    // 000000910E74: 02010314
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000910E78: BF870121
	v_cndmask_b32_e64 v3, v2, 31, s0                           // 000000910E7C: D5010003 00013F02
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000910E84: 3404029F
	.long 0xd44c0000                                           // 000000910E88: D44C0000
	v_cndmask_b32_e32 v1, 31, v3, vcc_lo                       // 000000910E8C: 0202069F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000910E90: BF870091
	v_cndmask_b32_e64 v5, 0xe1, 1, s0                          // 000000910E94: D5010005 000102FF 000000E1
	v_dual_mov_b32 v4, 0 :: v_dual_add_nc_u32 v7, v5, v3       // 000000910EA0: CA200080 04060705
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000910EA8: BF870114
	.long 0xd73c0005                                           // 000000910EAC: D73C0005
	v_cndmask_b32_e32 v1, 10, v1, vcc_lo                       // 000000910EB0: 0202028A
	.long 0xd73c0002                                           // 000000910EB4: D73C0002
	v_cndmask_b32_e32 v1, 2, v3, vcc_lo                        // 000000910EB8: 02020682
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000910EBC: BF870223
	v_lshlrev_b32_e32 v4, 24, v7                               // 000000910EC0: 30080E98
	v_bfe_i32 v7, v7, 7, 1                                     // 000000910EC4: D6110007 02050F07
	.long 0xd7000008                                           // 000000910ECC: D7000008
	v_cndmask_b32_e32 v1, s1, v5, vcc_lo                       // 000000910ED0: 02020A01
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000910ED4: BF870211
	v_add_co_ci_u32_e64 v9, null, s3, v6, s0                   // 000000910ED8: D5207C09 00020C03
	v_ashrrev_i32_e32 v6, 22, v4                               // 000000910EE0: 340C0896
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000910EE4: BF870093
	.long 0xd7000004                                           // 000000910EE8: D7000004
	v_cndmask_b32_e32 v1, v8, v2, vcc_lo                       // 000000910EEC: 02020508
	v_add_co_ci_u32_e64 v5, null, v9, v3, s0                   // 000000910EF0: D5207C05 00020709
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000910EF8: BF870093
	.long 0xd7000006                                           // 000000910EFC: D7000006
	v_cndmask_b32_e32 v1, v8, v6, vcc_lo                       // 000000910F00: 02020D08
	v_add_co_ci_u32_e64 v7, null, v9, v7, s0                   // 000000910F04: D5207C07 00020F09
	.long 0xd7000008                                           // 000000910F0C: D7000008
	v_cndmask_b32_e32 v1, v8, v21, vcc_lo                      // 000000910F10: 02022B08
	s_delay_alu instid0(VALU_DEP_1)                            // 000000910F14: BF870001
	v_add_co_ci_u32_e64 v9, null, 0, v9, s0                    // 000000910F18: D5207C09 00021280
	s_clause 0x17                                              // 000000910F20: BF850017
	global_load_b32 v2, v[4:5], off                            // 000000910F24: DC520000 027C0004
	global_load_b32 v92, v[4:5], off offset:128                // 000000910F2C: DC520080 5C7C0004
	global_load_b32 v89, v[4:5], off offset:256                // 000000910F34: DC520100 597C0004
	global_load_b32 v86, v[4:5], off offset:384                // 000000910F3C: DC520180 567C0004
	global_load_b32 v83, v[4:5], off offset:512                // 000000910F44: DC520200 537C0004
	global_load_b32 v80, v[4:5], off offset:640                // 000000910F4C: DC520280 507C0004
	global_load_b32 v77, v[4:5], off offset:768                // 000000910F54: DC520300 4D7C0004
	global_load_b32 v59, v[4:5], off offset:896                // 000000910F5C: DC520380 3B7C0004
	global_load_b32 v4, v[6:7], off                            // 000000910F64: DC520000 047C0006
	global_load_b32 v93, v[6:7], off offset:128                // 000000910F6C: DC520080 5D7C0006
	global_load_b32 v90, v[6:7], off offset:256                // 000000910F74: DC520100 5A7C0006
	global_load_b32 v87, v[6:7], off offset:384                // 000000910F7C: DC520180 577C0006
	global_load_b32 v84, v[6:7], off offset:512                // 000000910F84: DC520200 547C0006
	global_load_b32 v81, v[6:7], off offset:640                // 000000910F8C: DC520280 517C0006
	global_load_b32 v78, v[6:7], off offset:768                // 000000910F94: DC520300 4E7C0006
	global_load_b32 v60, v[6:7], off offset:896                // 000000910F9C: DC520380 3C7C0006
	global_load_b32 v3, v[8:9], off                            // 000000910FA4: DC520000 037C0008
	global_load_b32 v91, v[8:9], off offset:128                // 000000910FAC: DC520080 5B7C0008
	global_load_b32 v88, v[8:9], off offset:256                // 000000910FB4: DC520100 587C0008
	global_load_b32 v85, v[8:9], off offset:384                // 000000910FBC: DC520180 557C0008
	global_load_b32 v82, v[8:9], off offset:512                // 000000910FC4: DC520200 527C0008
	global_load_b32 v79, v[8:9], off offset:640                // 000000910FCC: DC520280 4F7C0008
	global_load_b32 v76, v[8:9], off offset:768                // 000000910FD4: DC520300 4C7C0008
	global_load_b32 v58, v[8:9], off offset:896                // 000000910FDC: DC520380 3A7C0008
	s_or_b32 exec_lo, exec_lo, s4                              // 000000910FE4: 8C7E047E
	v_dual_mov_b32 v22, 0 :: v_dual_mov_b32 v25, 0             // 000000910FE8: CA100080 16180080
	v_dual_mov_b32 v24, 0 :: v_dual_mov_b32 v27, 0             // 000000910FF0: CA100080 181A0080
	v_dual_mov_b32 v26, 0 :: v_dual_mov_b32 v31, 0             // 000000910FF8: CA100080 1A1E0080
	v_dual_mov_b32 v28, 0 :: v_dual_mov_b32 v33, 0             // 000000911000: CA100080 1C200080
	v_dual_mov_b32 v30, 0 :: v_dual_mov_b32 v35, 0             // 000000911008: CA100080 1E220080
	v_dual_mov_b32 v32, 0 :: v_dual_mov_b32 v37, 0             // 000000911010: CA100080 20240080
	v_dual_mov_b32 v34, 0 :: v_dual_mov_b32 v39, 0             // 000000911018: CA100080 22260080
	v_dual_mov_b32 v36, 0 :: v_dual_mov_b32 v43, 0             // 000000911020: CA100080 242A0080
	v_dual_mov_b32 v38, 0 :: v_dual_mov_b32 v45, 0             // 000000911028: CA100080 262C0080
	v_dual_mov_b32 v40, 0 :: v_dual_mov_b32 v29, 0             // 000000911030: CA100080 281C0080
	v_dual_mov_b32 v42, 0 :: v_dual_mov_b32 v49, 0             // 000000911038: CA100080 2A300080
	v_dual_mov_b32 v44, 0 :: v_dual_mov_b32 v53, 0             // 000000911040: CA100080 2C340080
	v_dual_mov_b32 v46, 0 :: v_dual_mov_b32 v47, 0             // 000000911048: CA100080 2E2E0080
	v_dual_mov_b32 v48, 0 :: v_dual_mov_b32 v41, 0             // 000000911050: CA100080 30280080
	v_dual_mov_b32 v52, 0 :: v_dual_mov_b32 v51, 0             // 000000911058: CA100080 34320080
	v_mov_b32_e32 v50, 0                                       // 000000911060: 7E640280
	v_mov_b32_e32 v54, 0                                       // 000000911064: 7E6C0280
	s_ashr_i32 s11, s10, 31                                    // 000000911068: 860B9F0A
	s_and_saveexec_b32 s0, vcc_lo                              // 00000091106C: BE80206A
	s_cbranch_execz 1080                                       // 000000911070: BFA50438 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi2ELi4EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0x1c54>
	v_dual_mov_b32 v22, 0 :: v_dual_add_nc_u32 v5, -1, v0      // 000000911074: CA200080 160400C1
	v_dual_mov_b32 v24, 0 :: v_dual_and_b32 v55, 16, v0        // 00000091107C: CA240080 18360090
	v_dual_mov_b32 v25, 0 :: v_dual_lshlrev_b32 v56, 2, v20    // 000000911084: CA220080 19382882
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000091108C: BF870123
	v_dual_mov_b32 v26, 0 :: v_dual_and_b32 v5, 31, v5         // 000000911090: CA240080 1A040A9F
	v_dual_mov_b32 v27, 0 :: v_dual_mov_b32 v28, 0             // 000000911098: CA100080 1B1C0080
	v_dual_mov_b32 v30, 0 :: v_dual_lshlrev_b32 v57, 2, v5     // 0000009110A0: CA220080 1E380A82
	v_dual_mov_b32 v31, 0 :: v_dual_mov_b32 v32, 0             // 0000009110A8: CA100080 1F200080
	v_dual_mov_b32 v33, 0 :: v_dual_mov_b32 v34, 0             // 0000009110B0: CA100080 21220080
	v_dual_mov_b32 v35, 0 :: v_dual_mov_b32 v36, 0             // 0000009110B8: CA100080 23240080
	v_dual_mov_b32 v37, 0 :: v_dual_mov_b32 v38, 0             // 0000009110C0: CA100080 25260080
	v_dual_mov_b32 v39, 0 :: v_dual_mov_b32 v40, 0             // 0000009110C8: CA100080 27280080
	v_dual_mov_b32 v42, 0 :: v_dual_mov_b32 v43, 0             // 0000009110D0: CA100080 2A2A0080
	v_dual_mov_b32 v44, 0 :: v_dual_mov_b32 v45, 0             // 0000009110D8: CA100080 2C2C0080
	v_dual_mov_b32 v46, 0 :: v_dual_mov_b32 v29, 0             // 0000009110E0: CA100080 2E1C0080
	v_dual_mov_b32 v48, 0 :: v_dual_mov_b32 v49, 0             // 0000009110E8: CA100080 30300080
	v_dual_mov_b32 v52, 0 :: v_dual_mov_b32 v53, 0             // 0000009110F0: CA100080 34340080
	v_dual_mov_b32 v47, 0 :: v_dual_mov_b32 v50, 0             // 0000009110F8: CA100080 2F320080
	v_dual_mov_b32 v41, 0 :: v_dual_mov_b32 v54, 0             // 000000911100: CA100080 29360080
	v_mov_b32_e32 v51, 0                                       // 000000911108: 7E660280
	s_mov_b32 s4, 0                                            // 00000091110C: BE840080
	s_movk_i32 s5, 0x1eee                                      // 000000911110: B0051EEE
	s_branch 980                                               // 000000911114: BFA003D4 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi2ELi4EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0x1b68>
	s_or_b32 exec_lo, exec_lo, s6                              // 000000911118: 8C7E067E
	s_waitcnt vmcnt(15)                                        // 00000091111C: BF893FF7
	v_alignbit_b32 v2, v2, v4, 16                              // 000000911120: D6160002 02420902
	v_lshl_or_b32 v13, v1, 5, v55                              // 000000911128: D656000D 04DD0B01
	s_waitcnt vmcnt(7)                                         // 000000911130: BF891FF7
	v_bfe_u32 v14, v3, 12, 16                                  // 000000911134: D610000E 02411903
	v_bfe_u32 v15, v3, 8, 16                                   // 00000091113C: D610000F 02411103
	v_bfe_u32 v16, v3, 4, 16                                   // 000000911144: D6100010 02410903
	v_bfe_u32 v1, v2, 12, 16                                   // 00000091114C: D6100001 02411902
	v_bfe_u32 v5, v2, 8, 16                                    // 000000911154: D6100005 02411102
	.long 0xd72c000e                                           // 00000091115C: D72C000E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v14, vcc_lo              // 000000911160: 02021CFF 83DCD12D
	.long 0xd72c000f                                           // 000000911168: D72C000F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v15, vcc_lo              // 00000091116C: 02021EFF 83DCD12D
	v_alignbit_b32 v92, v92, v93, 16                           // 000000911174: D616005C 0242BB5C
	.long 0xd72c005f                                           // 00000091117C: D72C005F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v1, vcc_lo               // 000000911180: 020202FF 83DCD12D
	.long 0xd72c0061                                           // 000000911188: D72C0061
	v_cndmask_b32_e32 v1, 0x83dcd12d, v5, vcc_lo               // 00000091118C: 02020AFF 83DCD12D
	s_waitcnt vmcnt(6)                                         // 000000911194: BF891BF7
	v_bfe_u32 v100, v91, 4, 16                                 // 000000911198: D6100064 0241095B
	v_alignbit_b32 v89, v89, v90, 16                           // 0000009111A0: D6160059 0242B559
	v_bfe_u32 v93, v92, 12, 16                                 // 0000009111A8: D610005D 0241195C
	v_sad_u8 v14, v14, 0, 0x6400                               // 0000009111B0: D622000E 03FD010E 00006400
	v_sad_u8 v99, v15, 0, 0x6400                               // 0000009111BC: D6220063 03FD010F 00006400
	v_alignbit_b32 v86, v86, v87, 16                           // 0000009111C8: D6160056 0242AF56
	v_sad_u8 v95, v95, 0, 0x6400                               // 0000009111D0: D622005F 03FD015F 00006400
	v_sad_u8 v97, v97, 0, 0x6400                               // 0000009111DC: D6220061 03FD0161 00006400
	.long 0xd72c005d                                           // 0000009111E8: D72C005D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v93, vcc_lo              // 0000009111EC: 0202BAFF 83DCD12D
	v_bfe_u32 v90, v89, 12, 16                                 // 0000009111F4: D610005A 02411959
	v_bfe_u32 v87, v86, 12, 16                                 // 0000009111FC: D6100057 02411956
	v_and_b32_e32 v95, 0xffff, v95                             // 000000911204: 36BEBEFF 0000FFFF
	v_alignbit_b32 v83, v83, v84, 16                           // 00000091120C: D6160053 0242A953
	v_alignbit_b32 v80, v80, v81, 16                           // 000000911214: D6160050 0242A350
	.long 0xd72c005a                                           // 00000091121C: D72C005A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v90, vcc_lo              // 000000911220: 0202B4FF 83DCD12D
	.long 0xd72c0057                                           // 000000911228: D72C0057
	v_cndmask_b32_e32 v1, 0x83dcd12d, v87, vcc_lo              // 00000091122C: 0202AEFF 83DCD12D
	v_lshl_or_b32 v95, v97, 16, v95                            // 000000911234: D656005F 057D2161
	.long 0xd72c0061                                           // 00000091123C: D72C0061
	v_cndmask_b32_e32 v1, 0x83dcd12d, v16, vcc_lo              // 000000911240: 020220FF 83DCD12D
	v_sad_u8 v93, v93, 0, 0x6400                               // 000000911248: D622005D 03FD015D 00006400
	v_bfe_u32 v84, v83, 12, 16                                 // 000000911254: D6100054 02411953
	v_bfe_u32 v81, v80, 12, 16                                 // 00000091125C: D6100051 02411950
	v_pk_fma_f16 v95, v95, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000911264: CC0E005F 0BFC0B5F 0000C931
	v_and_b32_e32 v4, 0xffff, v2                               // 000000911270: 360804FF 0000FFFF
	v_bfe_u32 v2, v2, 4, 16                                    // 000000911278: D6100002 02410902
	v_sad_u8 v90, v90, 0, 0x6400                               // 000000911280: D622005A 03FD015A 00006400
	v_sad_u8 v97, v97, 0, 0x6400                               // 00000091128C: D6220061 03FD0161 00006400
	v_sad_u8 v87, v87, 0, 0x6400                               // 000000911298: D6220057 03FD0157 00006400
	.long 0xd72c0060                                           // 0000009112A4: D72C0060
	v_cndmask_b32_e32 v1, 0x83dcd12d, v4, vcc_lo               // 0000009112A8: 020208FF 83DCD12D
	.long 0xd72c0062                                           // 0000009112B0: D72C0062
	v_cndmask_b32_e32 v1, 0x83dcd12d, v2, vcc_lo               // 0000009112B4: 020204FF 83DCD12D
	.long 0xd72c0054                                           // 0000009112BC: D72C0054
	v_cndmask_b32_e32 v1, 0x83dcd12d, v84, vcc_lo              // 0000009112C0: 0202A8FF 83DCD12D
	.long 0xd72c0051                                           // 0000009112C8: D72C0051
	v_cndmask_b32_e32 v1, 0x83dcd12d, v81, vcc_lo              // 0000009112CC: 0202A2FF 83DCD12D
	v_alignbit_b32 v77, v77, v78, 16                           // 0000009112D4: D616004D 02429D4D
	v_alignbit_b32 v59, v59, v60, 16                           // 0000009112DC: D616003B 0242793B
	v_cmp_eq_u32_e32 vcc_lo, v17, v23                          // 0000009112E4: 7C942F11
	v_and_b32_e32 v93, 0xffff, v93                             // 0000009112E8: 36BABAFF 0000FFFF
	v_sad_u8 v96, v96, 0, 0x6400                               // 0000009112F0: D6220060 03FD0160 00006400
	v_sad_u8 v98, v98, 0, 0x6400                               // 0000009112FC: D6220062 03FD0162 00006400
	v_sad_u8 v84, v84, 0, 0x6400                               // 000000911308: D6220054 03FD0154 00006400
	v_sad_u8 v81, v81, 0, 0x6400                               // 000000911314: D6220051 03FD0151 00006400
	v_bfe_u32 v78, v77, 12, 16                                 // 000000911320: D610004E 0241194D
	v_lshlrev_b32_e32 v96, 16, v96                             // 000000911328: 30C0C090
	v_bfe_u32 v60, v59, 12, 16                                 // 00000091132C: D610003C 0241193B
	s_or_b32 s4, vcc_lo, s4                                    // 000000911334: 8C04046A
	v_and_b32_e32 v90, 0xffff, v90                             // 000000911338: 36B4B4FF 0000FFFF
	.long 0xd72c004e                                           // 000000911340: D72C004E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 000000911344: 02029CFF 83DCD12D
	v_and_or_b32 v96, 0xffff, v98, v96                         // 00000091134C: D6570060 0582C4FF 0000FFFF
	.long 0xd72c003c                                           // 000000911358: D72C003C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v60, vcc_lo              // 00000091135C: 020278FF 83DCD12D
	v_and_b32_e32 v84, 0xffff, v84                             // 000000911364: 36A8A8FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3)                            // 00000091136C: BF870003
	v_pk_fma_f16 v96, v96, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000911370: CC0E0060 0BFC0B60 0000C931
	v_and_b32_e32 v94, 0xffff, v3                              // 00000091137C: 36BC06FF 0000FFFF
	ds_load_b128 v[1:4], v13                                   // 000000911384: DBFC0000 0100000D
	ds_load_b128 v[5:8], v13 offset:5120                       // 00000091138C: DBFC1400 0500000D
	ds_load_b128 v[9:12], v13 offset:10240                     // 000000911394: DBFC2800 0900000D
	v_and_b32_e32 v87, 0xffff, v87                             // 00000091139C: 36AEAEFF 0000FFFF
	v_sad_u8 v78, v78, 0, 0x6400                               // 0000009113A4: D622004E 03FD014E 00006400
	v_sad_u8 v60, v60, 0, 0x6400                               // 0000009113B0: D622003C 03FD013C 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000009113BC: BF870112
	v_and_b32_e32 v78, 0xffff, v78                             // 0000009113C0: 369C9CFF 0000FFFF
	v_and_b32_e32 v60, 0xffff, v60                             // 0000009113C8: 367878FF 0000FFFF
	s_waitcnt lgkmcnt(2)                                       // 0000009113D0: BF89FC27
	v_dot2acc_f32_f16 v54, v95, v1                             // 0000009113D4: 046C035F
	s_waitcnt lgkmcnt(1)                                       // 0000009113D8: BF89FC17
	v_dot2acc_f32_f16 v51, v95, v5                             // 0000009113DC: 04660B5F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000009113E0: BF8700A1
	v_dot2acc_f32_f16 v51, v96, v6                             // 0000009113E4: 04660D60
	.long 0xd72c005e                                           // 0000009113E8: D72C005E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v94, vcc_lo              // 0000009113EC: 0202BCFF 83DCD12D
	v_sad_u8 v94, v94, 0, 0x6400                               // 0000009113F4: D622005E 03FD015E 00006400
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000911400: BF870091
	v_lshlrev_b32_e32 v94, 16, v94                             // 000000911404: 30BCBC90
	v_and_or_b32 v94, 0xffff, v97, v94                         // 000000911408: D657005E 057AC2FF 0000FFFF
	v_dual_dot2acc_f32_f16 v54, v96, v2 :: v_dual_and_b32 v97, 0xffff, v92// 000000911414: CB240560 3660B8FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_2)                            // 000000911420: BF870002
	v_pk_fma_f16 v94, v94, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000911424: CC0E005E 0BFC0B5E 0000C931
	v_and_b32_e32 v98, 0xffff, v14                             // 000000911430: 36C41CFF 0000FFFF
	ds_load_b128 v[13:16], v13 offset:15360                    // 000000911438: DBFC3C00 0D00000D
	.long 0xd72c0061                                           // 000000911440: D72C0061
	v_cndmask_b32_e32 v1, 0x83dcd12d, v97, vcc_lo              // 000000911444: 0202C2FF 83DCD12D
	v_lshl_or_b32 v98, v99, 16, v98                            // 00000091144C: D6560062 05892163
	v_bfe_u32 v99, v91, 8, 16                                  // 000000911454: D6100063 0241115B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000091145C: BF870212
	v_pk_fma_f16 v98, v98, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000911460: CC0E0062 0BFC0B62 0000C931
	v_sad_u8 v97, v97, 0, 0x6400                               // 00000091146C: D6220061 03FD0161 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000911478: BF870113
	.long 0xd72c0063                                           // 00000091147C: D72C0063
	v_cndmask_b32_e32 v1, 0x83dcd12d, v99, vcc_lo              // 000000911480: 0202C6FF 83DCD12D
	v_dual_dot2acc_f32_f16 v54, v98, v3 :: v_dual_lshlrev_b32 v97, 16, v97// 000000911488: CB220762 3660C290
	v_dot2acc_f32_f16 v51, v98, v7                             // 000000911490: 04660F62
	s_waitcnt lgkmcnt(0)                                       // 000000911494: BF89FC07
	v_dot2acc_f32_f16 v41, v95, v13                            // 000000911498: 04521B5F
	v_dot2acc_f32_f16 v50, v95, v9                             // 00000091149C: 0464135F
	v_bfe_u32 v95, v92, 8, 16                                  // 0000009114A0: D610005F 0241115C
	v_bfe_u32 v92, v92, 4, 16                                  // 0000009114A8: D610005C 0241095C
	v_dot2acc_f32_f16 v51, v94, v8                             // 0000009114B0: 0466115E
	v_dot2acc_f32_f16 v41, v96, v14                            // 0000009114B4: 04521D60
	v_dot2acc_f32_f16 v50, v96, v10                            // 0000009114B8: 04641560
	.long 0xd72c005f                                           // 0000009114BC: D72C005F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v95, vcc_lo              // 0000009114C0: 0202BEFF 83DCD12D
	v_bfe_u32 v96, v91, 12, 16                                 // 0000009114C8: D6100060 0241195B
	.long 0xd72c005c                                           // 0000009114D0: D72C005C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v92, vcc_lo              // 0000009114D4: 0202B8FF 83DCD12D
	v_and_b32_e32 v91, 0xffff, v91                             // 0000009114DC: 36B6B6FF 0000FFFF
	v_dot2acc_f32_f16 v50, v98, v11                            // 0000009114E4: 04641762
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000009114E8: BF870224
	.long 0xd72c0060                                           // 0000009114EC: D72C0060
	v_cndmask_b32_e32 v1, 0x83dcd12d, v96, vcc_lo              // 0000009114F0: 0202C0FF 83DCD12D
	v_sad_u8 v95, v95, 0, 0x6400                               // 0000009114F8: D622005F 03FD015F 00006400
	.long 0xd72c005b                                           // 000000911504: D72C005B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v91, vcc_lo              // 000000911508: 0202B6FF 83DCD12D
	v_sad_u8 v92, v92, 0, 0x6400                               // 000000911510: D622005C 03FD015C 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000091151C: BF8701A3
	v_lshl_or_b32 v93, v95, 16, v93                            // 000000911520: D656005D 0575215F
	v_sad_u8 v96, v96, 0, 0x6400                               // 000000911528: D6220060 03FD0160 00006400
	v_and_or_b32 v92, 0xffff, v92, v97                         // 000000911534: D657005C 0586B8FF 0000FFFF
	v_sad_u8 v91, v91, 0, 0x6400                               // 000000911540: D622005B 03FD015B 00006400
	s_delay_alu instid0(VALU_DEP_4)                            // 00000091154C: BF870004
	v_pk_fma_f16 v93, v93, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000911550: CC0E005D 0BFC0B5D 0000C931
	v_dot2acc_f32_f16 v41, v98, v15                            // 00000091155C: 04521F62
	.long 0xd72c0062                                           // 000000911560: D72C0062
	v_cndmask_b32_e32 v1, 0x83dcd12d, v100, vcc_lo             // 000000911564: 0202C8FF 83DCD12D
	v_pk_fma_f16 v92, v92, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000091156C: CC0E005C 0BFC0B5C 0000C931
	v_dual_dot2acc_f32_f16 v54, v94, v4 :: v_dual_lshlrev_b32 v91, 16, v91// 000000911578: CB22095E 365AB690
	v_dual_dot2acc_f32_f16 v52, v93, v9 :: v_dual_and_b32 v95, 0xffff, v96// 000000911580: CB24135D 345EC0FF 0000FFFF
	v_sad_u8 v96, v99, 0, 0x6400                               // 00000091158C: D6220060 03FD0163 00006400
	v_dual_dot2acc_f32_f16 v50, v94, v12 :: v_dual_dot2acc_f32_f16 v47, v93, v1// 000000911598: CB18195E 322E035D
	v_sad_u8 v97, v98, 0, 0x6400                               // 0000009115A0: D6220061 03FD0162 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009115AC: BF870214
	v_dot2acc_f32_f16 v52, v92, v10                            // 0000009115B0: 0468155C
	v_lshl_or_b32 v95, v96, 16, v95                            // 0000009115B4: D656005F 057D2160
	s_waitcnt vmcnt(5)                                         // 0000009115BC: BF8917F7
	v_bfe_u32 v96, v88, 12, 16                                 // 0000009115C0: D6100060 02411958
	v_dot2acc_f32_f16 v41, v94, v16                            // 0000009115C8: 0452215E
	v_and_or_b32 v91, 0xffff, v97, v91                         // 0000009115CC: D657005B 056EC2FF 0000FFFF
	v_bfe_u32 v97, v88, 8, 16                                  // 0000009115D8: D6100061 02411158
	v_pk_fma_f16 v95, v95, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009115E0: CC0E005F 0BFC0B5F 0000C931
	.long 0xd72c0060                                           // 0000009115EC: D72C0060
	v_cndmask_b32_e32 v1, 0x83dcd12d, v96, vcc_lo              // 0000009115F0: 0202C0FF 83DCD12D
	v_dot2acc_f32_f16 v53, v93, v5                             // 0000009115F8: 046A0B5D
	v_pk_fma_f16 v91, v91, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009115FC: CC0E005B 0BFC0B5B 0000C931
	v_and_b32_e32 v94, 0xffff, v89                             // 000000911608: 36BCB2FF 0000FFFF
	v_dual_dot2acc_f32_f16 v52, v95, v11 :: v_dual_dot2acc_f32_f16 v47, v92, v2// 000000911610: CB18175F 342E055C
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000911618: BF870234
	v_dot2acc_f32_f16 v53, v92, v6                             // 00000091161C: 046A0D5C
	v_bfe_u32 v98, v88, 4, 16                                  // 000000911620: D6100062 02410958
	v_and_b32_e32 v88, 0xffff, v88                             // 000000911628: 36B0B0FF 0000FFFF
	v_dot2acc_f32_f16 v52, v91, v12                            // 000000911630: 0468195B
	v_dot2acc_f32_f16 v47, v95, v3                             // 000000911634: 045E075F
	.long 0xd72c0061                                           // 000000911638: D72C0061
	v_cndmask_b32_e32 v1, 0x83dcd12d, v97, vcc_lo              // 00000091163C: 0202C2FF 83DCD12D
	v_sad_u8 v96, v96, 0, 0x6400                               // 000000911644: D6220060 03FD0160 00006400
	v_dot2acc_f32_f16 v49, v93, v13                            // 000000911650: 04621B5D
	v_bfe_u32 v93, v89, 8, 16                                  // 000000911654: D610005D 02411159
	v_bfe_u32 v89, v89, 4, 16                                  // 00000091165C: D6100059 02410959
	.long 0xd72c005e                                           // 000000911664: D72C005E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v94, vcc_lo              // 000000911668: 0202BCFF 83DCD12D
	.long 0xd72c0058                                           // 000000911670: D72C0058
	v_cndmask_b32_e32 v1, 0x83dcd12d, v88, vcc_lo              // 000000911674: 0202B0FF 83DCD12D
	v_and_b32_e32 v96, 0xffff, v96                             // 00000091167C: 36C0C0FF 0000FFFF
	.long 0xd72c005d                                           // 000000911684: D72C005D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v93, vcc_lo              // 000000911688: 0202BAFF 83DCD12D
	v_sad_u8 v97, v97, 0, 0x6400                               // 000000911690: D6220061 03FD0161 00006400
	.long 0xd72c0059                                           // 00000091169C: D72C0059
	v_cndmask_b32_e32 v1, 0x83dcd12d, v89, vcc_lo              // 0000009116A0: 0202B2FF 83DCD12D
	v_dot2acc_f32_f16 v53, v95, v7                             // 0000009116A8: 046A0F5F
	v_sad_u8 v94, v94, 0, 0x6400                               // 0000009116AC: D622005E 03FD015E 00006400
	v_sad_u8 v88, v88, 0, 0x6400                               // 0000009116B8: D6220058 03FD0158 00006400
	v_dot2acc_f32_f16 v49, v92, v14                            // 0000009116C4: 04621D5C
	v_sad_u8 v93, v93, 0, 0x6400                               // 0000009116C8: D622005D 03FD015D 00006400
	v_lshl_or_b32 v92, v97, 16, v96                            // 0000009116D4: D656005C 05812161
	v_sad_u8 v89, v89, 0, 0x6400                               // 0000009116DC: D6220059 03FD0159 00006400
	v_lshlrev_b32_e32 v88, 16, v88                             // 0000009116E8: 30B0B090
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009116EC: BF870214
	v_lshl_or_b32 v90, v93, 16, v90                            // 0000009116F0: D656005A 0569215D
	v_pk_fma_f16 v92, v92, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009116F8: CC0E005C 0BFC0B5C 0000C931
	v_lshlrev_b32_e32 v93, 16, v94                             // 000000911704: 30BABC90
	.long 0xd72c005e                                           // 000000911708: D72C005E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v98, vcc_lo              // 00000091170C: 0202C4FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000911714: BF870224
	v_pk_fma_f16 v90, v90, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000911718: CC0E005A 0BFC0B5A 0000C931
	v_dot2acc_f32_f16 v53, v91, v8                             // 000000911724: 046A115B
	v_and_or_b32 v89, 0xffff, v89, v93                         // 000000911728: D6570059 0576B2FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000911734: BF8701A3
	v_dual_dot2acc_f32_f16 v47, v91, v4 :: v_dual_dot2acc_f32_f16 v48, v90, v5// 000000911738: CB18095B 2F300B5A
	v_sad_u8 v93, v94, 0, 0x6400                               // 000000911740: D622005D 03FD015E 00006400
	v_pk_fma_f16 v89, v89, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000091174C: CC0E0059 0BFC0B59 0000C931
	v_dot2acc_f32_f16 v46, v90, v9                             // 000000911758: 045C135A
	v_dot2acc_f32_f16 v29, v90, v1                             // 00000091175C: 043A035A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000911760: BF870214
	v_and_or_b32 v88, 0xffff, v93, v88                         // 000000911764: D6570058 0562BAFF 0000FFFF
	v_dot2acc_f32_f16 v48, v89, v6                             // 000000911770: 04600D59
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000911774: BF870214
	v_dot2acc_f32_f16 v46, v89, v10                            // 000000911778: 045C1559
	v_dot2acc_f32_f16 v29, v89, v2                             // 00000091177C: 043A0559
	s_waitcnt vmcnt(4)                                         // 000000911780: BF8913F7
	v_bfe_u32 v93, v85, 4, 16                                  // 000000911784: D610005D 02410955
	v_pk_fma_f16 v88, v88, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000091178C: CC0E0058 0BFC0B58 0000C931
	v_dot2acc_f32_f16 v48, v92, v7                             // 000000911798: 04600F5C
	v_dual_dot2acc_f32_f16 v46, v92, v11 :: v_dual_dot2acc_f32_f16 v45, v90, v13// 00000091179C: CB18175C 2E2C1B5A
	v_dual_dot2acc_f32_f16 v29, v92, v3 :: v_dual_and_b32 v90, 0xffff, v86// 0000009117A4: CB24075C 1D5AACFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009117B0: BF870193
	v_dual_dot2acc_f32_f16 v49, v95, v15 :: v_dual_dot2acc_f32_f16 v48, v88, v8// 0000009117B4: CB181F5F 31301158
	v_dual_dot2acc_f32_f16 v46, v88, v12 :: v_dual_dot2acc_f32_f16 v45, v89, v14// 0000009117BC: CB181958 2E2C1D59
	v_bfe_u32 v89, v86, 8, 16                                  // 0000009117C4: D6100059 02411156
	v_bfe_u32 v86, v86, 4, 16                                  // 0000009117CC: D6100056 02410956
	.long 0xd72c005a                                           // 0000009117D4: D72C005A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v90, vcc_lo              // 0000009117D8: 0202B4FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009117E0: BF870193
	.long 0xd72c0059                                           // 0000009117E4: D72C0059
	v_cndmask_b32_e32 v1, 0x83dcd12d, v89, vcc_lo              // 0000009117E8: 0202B2FF 83DCD12D
	.long 0xd72c0056                                           // 0000009117F0: D72C0056
	v_cndmask_b32_e32 v1, 0x83dcd12d, v86, vcc_lo              // 0000009117F4: 0202ACFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3)                            // 0000009117FC: BF870003
	v_sad_u8 v90, v90, 0, 0x6400                               // 000000911800: D622005A 03FD015A 00006400
	v_dot2acc_f32_f16 v49, v91, v16                            // 00000091180C: 0462215B
	v_bfe_u32 v91, v85, 12, 16                                 // 000000911810: D610005B 02411955
	v_sad_u8 v89, v89, 0, 0x6400                               // 000000911818: D6220059 03FD0159 00006400
	v_sad_u8 v86, v86, 0, 0x6400                               // 000000911824: D6220056 03FD0156 00006400
	v_lshlrev_b32_e32 v90, 16, v90                             // 000000911830: 30B4B490
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000911834: BF870214
	.long 0xd72c005b                                           // 000000911838: D72C005B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v91, vcc_lo              // 00000091183C: 0202B6FF 83DCD12D
	v_lshl_or_b32 v87, v89, 16, v87                            // 000000911844: D6560057 055D2159
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000091184C: BF870113
	v_and_or_b32 v86, 0xffff, v86, v90                         // 000000911850: D6570056 056AACFF 0000FFFF
	v_pk_fma_f16 v87, v87, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000091185C: CC0E0057 0BFC0B57 0000C931
	v_dot2acc_f32_f16 v29, v88, v4                             // 000000911868: 043A0958
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000091186C: BF870223
	v_pk_fma_f16 v86, v86, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000911870: CC0E0056 0BFC0B56 0000C931
	v_sad_u8 v91, v91, 0, 0x6400                               // 00000091187C: D622005B 03FD015B 00006400
	v_dot2acc_f32_f16 v44, v87, v1                             // 000000911888: 04580357
	v_dual_dot2acc_f32_f16 v42, v87, v9 :: v_dual_dot2acc_f32_f16 v45, v92, v15// 00000091188C: CB181357 2A2C1F5C
	v_bfe_u32 v92, v85, 8, 16                                  // 000000911894: D610005C 02411155
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000091189C: BF870193
	v_dual_dot2acc_f32_f16 v44, v86, v2 :: v_dual_and_b32 v85, 0xffff, v85// 0000009118A0: CB240556 2C54AAFF 0000FFFF
	v_dual_dot2acc_f32_f16 v42, v86, v10 :: v_dual_dot2acc_f32_f16 v45, v88, v16// 0000009118AC: CB181556 2A2C2158
	v_dot2acc_f32_f16 v40, v87, v13                            // 0000009118B4: 04501B57
	s_delay_alu instid0(VALU_DEP_3)                            // 0000009118B8: BF870003
	.long 0xd72c0055                                           // 0000009118BC: D72C0055
	v_cndmask_b32_e32 v1, 0x83dcd12d, v85, vcc_lo              // 0000009118C0: 0202AAFF 83DCD12D
	.long 0xd72c0058                                           // 0000009118C8: D72C0058
	v_cndmask_b32_e32 v1, 0x83dcd12d, v93, vcc_lo              // 0000009118CC: 0202BAFF 83DCD12D
	.long 0xd72c005c                                           // 0000009118D4: D72C005C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v92, vcc_lo              // 0000009118D8: 0202B8FF 83DCD12D
	v_mov_b32_e32 v93, v74                                     // 0000009118E0: 7EBA034A
	v_dot2acc_f32_f16 v40, v86, v14                            // 0000009118E4: 04501D56
	v_sad_u8 v85, v85, 0, 0x6400                               // 0000009118E8: D6220055 03FD0155 00006400
	v_sad_u8 v88, v88, 0, 0x6400                               // 0000009118F4: D6220058 03FD0158 00006400
	v_sad_u8 v90, v92, 0, 0x6400                               // 000000911900: D622005A 03FD015C 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000091190C: BF870093
	v_dual_mov_b32 v92, v68 :: v_dual_lshlrev_b32 v85, 16, v85 // 000000911910: CA220144 5C54AA90
	v_and_or_b32 v85, 0xffff, v88, v85                         // 000000911918: D6570055 0556B0FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000911924: BF870141
	v_pk_fma_f16 v85, v85, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000911928: CC0E0055 0BFC0B55 0000C931
	v_and_b32_e32 v89, 0xffff, v91                             // 000000911934: 36B2B6FF 0000FFFF
	s_waitcnt vmcnt(3)                                         // 00000091193C: BF890FF7
	v_bfe_u32 v91, v82, 4, 16                                  // 000000911940: D610005B 02410952
	v_lshl_or_b32 v89, v90, 16, v89                            // 000000911948: D6560059 0565215A
	v_bfe_u32 v90, v82, 8, 16                                  // 000000911950: D610005A 02411152
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 000000911958: BF870252
	v_pk_fma_f16 v88, v89, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000091195C: CC0E0058 0BFC0B59 0000C931
	v_dot2acc_f32_f16 v43, v87, v5                             // 000000911968: 04560B57
	v_bfe_u32 v89, v82, 12, 16                                 // 00000091196C: D6100059 02411952
	v_and_b32_e32 v82, 0xffff, v82                             // 000000911974: 36A4A4FF 0000FFFF
	.long 0xd72c005a                                           // 00000091197C: D72C005A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v90, vcc_lo              // 000000911980: 0202B4FF 83DCD12D
	v_dual_dot2acc_f32_f16 v42, v88, v11 :: v_dual_dot2acc_f32_f16 v43, v86, v6// 000000911988: CB181758 2A2A0D56
	v_bfe_u32 v86, v83, 8, 16                                  // 000000911990: D6100056 02411153
	.long 0xd72c0059                                           // 000000911998: D72C0059
	v_cndmask_b32_e32 v1, 0x83dcd12d, v89, vcc_lo              // 00000091199C: 0202B2FF 83DCD12D
	.long 0xd72c0052                                           // 0000009119A4: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 0000009119A8: 0202A4FF 83DCD12D
	v_dot2acc_f32_f16 v44, v88, v3                             // 0000009119B0: 04580758
	v_dot2acc_f32_f16 v43, v88, v7                             // 0000009119B4: 04560F58
	.long 0xd72c0056                                           // 0000009119B8: D72C0056
	v_cndmask_b32_e32 v1, 0x83dcd12d, v86, vcc_lo              // 0000009119BC: 0202ACFF 83DCD12D
	v_sad_u8 v90, v90, 0, 0x6400                               // 0000009119C4: D622005A 03FD015A 00006400
	v_dot2acc_f32_f16 v42, v85, v12                            // 0000009119D0: 04541955
	v_dot2acc_f32_f16 v44, v85, v4                             // 0000009119D4: 04580955
	v_dot2acc_f32_f16 v43, v85, v8                             // 0000009119D8: 04561155
	v_sad_u8 v89, v89, 0, 0x6400                               // 0000009119DC: D6220059 03FD0159 00006400
	v_sad_u8 v82, v82, 0, 0x6400                               // 0000009119E8: D6220052 03FD0152 00006400
	v_sad_u8 v86, v86, 0, 0x6400                               // 0000009119F4: D6220056 03FD0156 00006400
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000911A00: BF870091
	v_lshl_or_b32 v84, v86, 16, v84                            // 000000911A04: D6560054 05512156
	v_pk_fma_f16 v84, v84, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000911A0C: CC0E0054 0BFC0B54 0000C931
	v_and_b32_e32 v87, 0xffff, v83                             // 000000911A18: 36AEA6FF 0000FFFF
	v_bfe_u32 v83, v83, 4, 16                                  // 000000911A20: D6100053 02410953
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000911A28: BF870223
	v_dual_dot2acc_f32_f16 v39, v84, v1 :: v_dual_lshlrev_b32 v82, 16, v82// 000000911A2C: CB220354 2752A490
	v_dot2acc_f32_f16 v38, v84, v5                             // 000000911A34: 044C0B54
	.long 0xd72c0057                                           // 000000911A38: D72C0057
	v_cndmask_b32_e32 v1, 0x83dcd12d, v87, vcc_lo              // 000000911A3C: 0202AEFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4)                            // 000000911A44: BF870004
	.long 0xd72c0053                                           // 000000911A48: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v83, vcc_lo              // 000000911A4C: 0202A6FF 83DCD12D
	v_dot2acc_f32_f16 v37, v84, v9                             // 000000911A54: 044A1354
	v_dot2acc_f32_f16 v40, v88, v15                            // 000000911A58: 04501F58
	v_dot2acc_f32_f16 v36, v84, v13                            // 000000911A5C: 04481B54
	v_bfe_u32 v84, v80, 8, 16                                  // 000000911A60: D6100054 02411150
	s_waitcnt vmcnt(2)                                         // 000000911A68: BF890BF7
	v_bfe_u32 v88, v79, 4, 16                                  // 000000911A6C: D6100058 0241094F
	v_sad_u8 v87, v87, 0, 0x6400                               // 000000911A74: D6220057 03FD0157 00006400
	v_sad_u8 v83, v83, 0, 0x6400                               // 000000911A80: D6220053 03FD0153 00006400
	v_dot2acc_f32_f16 v40, v85, v16                            // 000000911A8C: 04502155
	v_bfe_u32 v85, v79, 12, 16                                 // 000000911A90: D6100055 0241194F
	.long 0xd72c0054                                           // 000000911A98: D72C0054
	v_cndmask_b32_e32 v1, 0x83dcd12d, v84, vcc_lo              // 000000911A9C: 0202A8FF 83DCD12D
	v_lshlrev_b32_e32 v87, 16, v87                             // 000000911AA4: 30AEAE90
	.long 0xd72c0058                                           // 000000911AA8: D72C0058
	v_cndmask_b32_e32 v1, 0x83dcd12d, v88, vcc_lo              // 000000911AAC: 0202B0FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000911AB4: BF870194
	.long 0xd72c0055                                           // 000000911AB8: D72C0055
	v_cndmask_b32_e32 v1, 0x83dcd12d, v85, vcc_lo              // 000000911ABC: 0202AAFF 83DCD12D
	v_and_or_b32 v83, 0xffff, v83, v87                         // 000000911AC4: D6570053 055EA6FF 0000FFFF
	v_sad_u8 v84, v84, 0, 0x6400                               // 000000911AD0: D6220054 03FD0154 00006400
	s_delay_alu instid0(VALU_DEP_2)                            // 000000911ADC: BF870002
	v_pk_fma_f16 v83, v83, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000911AE0: CC0E0053 0BFC0B53 0000C931
	v_and_b32_e32 v86, 0xffff, v89                             // 000000911AEC: 36ACB2FF 0000FFFF
	.long 0xd72c0059                                           // 000000911AF4: D72C0059
	v_cndmask_b32_e32 v1, 0x83dcd12d, v91, vcc_lo              // 000000911AF8: 0202B6FF 83DCD12D
	v_sad_u8 v85, v85, 0, 0x6400                               // 000000911B00: D6220055 03FD0155 00006400
	v_mov_b32_e32 v91, v74                                     // 000000911B0C: 7EB6034A
	v_dot2acc_f32_f16 v39, v83, v2                             // 000000911B10: 044E0553
	v_lshl_or_b32 v86, v90, 16, v86                            // 000000911B14: D6560056 0559215A
	v_dot2acc_f32_f16 v38, v83, v6                             // 000000911B1C: 044C0D53
	v_dot2acc_f32_f16 v37, v83, v10                            // 000000911B20: 044A1553
	v_dual_dot2acc_f32_f16 v36, v83, v14 :: v_dual_and_b32 v83, 0xffff, v80// 000000911B24: CB241D53 2452A0FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4)                            // 000000911B30: BF870004
	v_pk_fma_f16 v86, v86, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000911B34: CC0E0056 0BFC0B56 0000C931
	v_sad_u8 v87, v89, 0, 0x6400                               // 000000911B40: D6220057 03FD0159 00006400
	v_bfe_u32 v80, v80, 4, 16                                  // 000000911B4C: D6100050 02410950
	v_and_b32_e32 v81, 0xffff, v81                             // 000000911B54: 36A2A2FF 0000FFFF
	.long 0xd72c0053                                           // 000000911B5C: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v83, vcc_lo              // 000000911B60: 0202A6FF 83DCD12D
	v_dot2acc_f32_f16 v39, v86, v3                             // 000000911B68: 044E0756
	v_dot2acc_f32_f16 v38, v86, v7                             // 000000911B6C: 044C0F56
	v_dot2acc_f32_f16 v37, v86, v11                            // 000000911B70: 044A1756
	v_and_or_b32 v82, 0xffff, v87, v82                         // 000000911B74: D6570052 054AAEFF 0000FFFF
	v_bfe_u32 v87, v79, 8, 16                                  // 000000911B80: D6100057 0241114F
	.long 0xd72c0050                                           // 000000911B88: D72C0050
	v_cndmask_b32_e32 v1, 0x83dcd12d, v80, vcc_lo              // 000000911B8C: 0202A0FF 83DCD12D
	v_dot2acc_f32_f16 v36, v86, v15                            // 000000911B94: 04481F56
	v_sad_u8 v83, v83, 0, 0x6400                               // 000000911B98: D6220053 03FD0153 00006400
	v_pk_fma_f16 v82, v82, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000911BA4: CC0E0052 0BFC0B52 0000C931
	.long 0xd72c0057                                           // 000000911BB0: D72C0057
	v_cndmask_b32_e32 v1, 0x83dcd12d, v87, vcc_lo              // 000000911BB4: 0202AEFF 83DCD12D
	v_lshl_or_b32 v81, v84, 16, v81                            // 000000911BBC: D6560051 05452154
	v_and_b32_e32 v79, 0xffff, v79                             // 000000911BC4: 369E9EFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4)                            // 000000911BCC: BF870004
	v_dual_dot2acc_f32_f16 v36, v82, v16 :: v_dual_lshlrev_b32 v83, 16, v83// 000000911BD0: CB222152 2452A690
	v_sad_u8 v80, v80, 0, 0x6400                               // 000000911BD8: D6220050 03FD0150 00006400
	v_dot2acc_f32_f16 v38, v82, v8                             // 000000911BE4: 044C1152
	v_pk_fma_f16 v81, v81, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000911BE8: CC0E0051 0BFC0B51 0000C931
	v_sad_u8 v84, v87, 0, 0x6400                               // 000000911BF4: D6220054 03FD0157 00006400
	.long 0xd72c004f                                           // 000000911C00: D72C004F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v79, vcc_lo              // 000000911C04: 02029EFF 83DCD12D
	v_and_or_b32 v80, 0xffff, v80, v83                         // 000000911C0C: D6570050 054EA0FF 0000FFFF
	v_and_b32_e32 v83, 0xffff, v85                             // 000000911C18: 36A6AAFF 0000FFFF
	v_dual_dot2acc_f32_f16 v39, v82, v4 :: v_dual_dot2acc_f32_f16 v34, v81, v5// 000000911C20: CB180952 27220B51
	v_sad_u8 v85, v88, 0, 0x6400                               // 000000911C28: D6220055 03FD0158 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000911C34: BF870214
	v_pk_fma_f16 v80, v80, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000911C38: CC0E0050 0BFC0B50 0000C931
	v_lshl_or_b32 v83, v84, 16, v83                            // 000000911C44: D6560053 054D2154
	v_dot2acc_f32_f16 v37, v82, v12                            // 000000911C4C: 044A1952
	v_sad_u8 v79, v79, 0, 0x6400                               // 000000911C50: D622004F 03FD014F 00006400
	v_and_b32_e32 v82, 0xffff, v77                             // 000000911C5C: 36A49AFF 0000FFFF
	v_dot2acc_f32_f16 v34, v80, v6                             // 000000911C64: 04440D50
	v_pk_fma_f16 v83, v83, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000911C68: CC0E0053 0BFC0B53 0000C931
	v_dot2acc_f32_f16 v35, v81, v1                             // 000000911C74: 04460351
	v_dual_dot2acc_f32_f16 v32, v81, v13 :: v_dual_lshlrev_b32 v79, 16, v79// 000000911C78: CB221B51 204E9E90
	v_bfe_u32 v84, v77, 8, 16                                  // 000000911C80: D6100054 0241114D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000911C88: BF870193
	v_dual_dot2acc_f32_f16 v34, v83, v7 :: v_dual_dot2acc_f32_f16 v35, v80, v2// 000000911C8C: CB180F53 22220550
	v_and_or_b32 v79, 0xffff, v85, v79                         // 000000911C94: D657004F 053EAAFF 0000FFFF
	v_bfe_u32 v77, v77, 4, 16                                  // 000000911CA0: D610004D 0241094D
	.long 0xd72c0052                                           // 000000911CA8: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 000000911CAC: 0202A4FF 83DCD12D
	s_waitcnt vmcnt(1)                                         // 000000911CB4: BF8907F7
	v_bfe_u32 v85, v76, 12, 16                                 // 000000911CB8: D6100055 0241194C
	.long 0xd72c0054                                           // 000000911CC0: D72C0054
	v_cndmask_b32_e32 v1, 0x83dcd12d, v84, vcc_lo              // 000000911CC4: 0202A8FF 83DCD12D
	v_dot2acc_f32_f16 v33, v81, v9                             // 000000911CCC: 04421351
	v_bfe_u32 v86, v76, 8, 16                                  // 000000911CD0: D6100056 0241114C
	.long 0xd72c004d                                           // 000000911CD8: D72C004D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v77, vcc_lo              // 000000911CDC: 02029AFF 83DCD12D
	v_bfe_u32 v87, v76, 4, 16                                  // 000000911CE4: D6100057 0241094C
	.long 0xd72c0055                                           // 000000911CEC: D72C0055
	v_cndmask_b32_e32 v1, 0x83dcd12d, v85, vcc_lo              // 000000911CF0: 0202AAFF 83DCD12D
	v_and_b32_e32 v76, 0xffff, v76                             // 000000911CF8: 369898FF 0000FFFF
	v_pk_fma_f16 v79, v79, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000911D00: CC0E004F 0BFC0B4F 0000C931
	v_dot2acc_f32_f16 v35, v83, v3                             // 000000911D0C: 04460753
	v_sad_u8 v82, v82, 0, 0x6400                               // 000000911D10: D6220052 03FD0152 00006400
	v_sad_u8 v84, v84, 0, 0x6400                               // 000000911D1C: D6220054 03FD0154 00006400
	.long 0xd72c0056                                           // 000000911D28: D72C0056
	v_cndmask_b32_e32 v1, 0x83dcd12d, v86, vcc_lo              // 000000911D2C: 0202ACFF 83DCD12D
	.long 0xd72c004c                                           // 000000911D34: D72C004C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v76, vcc_lo              // 000000911D38: 020298FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4)                            // 000000911D40: BF870004
	v_dual_dot2acc_f32_f16 v35, v79, v4 :: v_dual_lshlrev_b32 v82, 16, v82// 000000911D44: CB22094F 2352A490
	v_sad_u8 v77, v77, 0, 0x6400                               // 000000911D4C: D622004D 03FD014D 00006400
	v_sad_u8 v85, v85, 0, 0x6400                               // 000000911D58: D6220055 03FD0155 00006400
	v_lshl_or_b32 v78, v84, 16, v78                            // 000000911D64: D656004E 05392154
	.long 0xd72c0051                                           // 000000911D6C: D72C0051
	v_cndmask_b32_e32 v1, 0x83dcd12d, v87, vcc_lo              // 000000911D70: 0202AEFF 83DCD12D
	v_dot2acc_f32_f16 v33, v80, v10                            // 000000911D78: 04421550
	v_and_or_b32 v77, 0xffff, v77, v82                         // 000000911D7C: D657004D 054A9AFF 0000FFFF
	v_and_b32_e32 v82, 0xffff, v85                             // 000000911D88: 36A4AAFF 0000FFFF
	v_sad_u8 v84, v86, 0, 0x6400                               // 000000911D90: D6220054 03FD0156 00006400
	v_sad_u8 v76, v76, 0, 0x6400                               // 000000911D9C: D622004C 03FD014C 00006400
	v_pk_fma_f16 v78, v78, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000911DA8: CC0E004E 0BFC0B4E 0000C931
	v_dual_dot2acc_f32_f16 v33, v83, v11 :: v_dual_dot2acc_f32_f16 v32, v80, v14// 000000911DB4: CB181753 21201D50
	v_pk_fma_f16 v77, v77, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000911DBC: CC0E004D 0BFC0B4D 0000C931
	v_lshl_or_b32 v80, v84, 16, v82                            // 000000911DC8: D6560050 05492154
	v_sad_u8 v81, v81, 0, 0x6400                               // 000000911DD0: D6220051 03FD0151 00006400
	v_dual_dot2acc_f32_f16 v31, v78, v1 :: v_dual_lshlrev_b32 v76, 16, v76// 000000911DDC: CB22034E 1F4C9890
	v_dual_dot2acc_f32_f16 v33, v79, v12 :: v_dual_dot2acc_f32_f16 v30, v78, v5// 000000911DE4: CB18194F 211E0B4E
	v_dot2acc_f32_f16 v28, v78, v9                             // 000000911DEC: 0438134E
	v_pk_fma_f16 v80, v80, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000911DF0: CC0E0050 0BFC0B50 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000911DFC: BF870244
	v_and_or_b32 v76, 0xffff, v81, v76                         // 000000911E00: D657004C 0532A2FF 0000FFFF
	v_dot2acc_f32_f16 v31, v77, v2                             // 000000911E0C: 043E054D
	v_dot2acc_f32_f16 v30, v77, v6                             // 000000911E10: 043C0D4D
	v_dual_dot2acc_f32_f16 v32, v83, v15 :: v_dual_dot2acc_f32_f16 v27, v78, v13// 000000911E14: CB181F53 201A1B4E
	v_pk_fma_f16 v76, v76, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000911E1C: CC0E004C 0BFC0B4C 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000911E28: BF870194
	v_dual_dot2acc_f32_f16 v31, v80, v3 :: v_dual_dot2acc_f32_f16 v28, v77, v10// 000000911E2C: CB180750 1F1C154D
	v_dual_dot2acc_f32_f16 v34, v79, v8 :: v_dual_dot2acc_f32_f16 v27, v77, v14// 000000911E34: CB18114F 221A1D4D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000911E3C: BF870194
	v_dot2acc_f32_f16 v32, v79, v16                            // 000000911E40: 0440214F
	v_dot2acc_f32_f16 v31, v76, v4                             // 000000911E44: 043E094C
	s_delay_alu instid0(VALU_DEP_4)                            // 000000911E48: BF870004
	v_dot2acc_f32_f16 v28, v80, v11                            // 000000911E4C: 04381750
	v_bfe_u32 v79, v59, 8, 16                                  // 000000911E50: D610004F 0241113B
	s_waitcnt vmcnt(0)                                         // 000000911E58: BF8903F7
	v_bfe_u32 v81, v58, 12, 16                                 // 000000911E5C: D6100051 0241193A
	v_bfe_u32 v82, v58, 8, 16                                  // 000000911E64: D6100052 0241113A
	v_bfe_u32 v83, v58, 4, 16                                  // 000000911E6C: D6100053 0241093A
	v_dot2acc_f32_f16 v27, v80, v15                            // 000000911E74: 04361F50
	.long 0xd72c004f                                           // 000000911E78: D72C004F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v79, vcc_lo              // 000000911E7C: 02029EFF 83DCD12D
	v_dual_mov_b32 v85, v72 :: v_dual_and_b32 v58, 0xffff, v58 // 000000911E84: CA240148 553A74FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000911E90: BF870214
	.long 0xd72c004d                                           // 000000911E94: D72C004D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v83, vcc_lo              // 000000911E98: 0202A6FF 83DCD12D
	v_dot2acc_f32_f16 v27, v76, v16                            // 000000911EA0: 0436214C
	.long 0xd72c0051                                           // 000000911EA4: D72C0051
	v_cndmask_b32_e32 v1, 0x83dcd12d, v81, vcc_lo              // 000000911EA8: 0202A2FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4)                            // 000000911EB0: BF870004
	.long 0xd72c003a                                           // 000000911EB4: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 000000911EB8: 020274FF 83DCD12D
	v_mov_b32_e32 v87, v72                                     // 000000911EC0: 7EAE0348
	v_sad_u8 v79, v79, 0, 0x6400                               // 000000911EC4: D622004F 03FD014F 00006400
	.long 0xd72c0052                                           // 000000911ED0: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 000000911ED4: 0202A4FF 83DCD12D
	v_mov_b32_e32 v89, v65                                     // 000000911EDC: 7EB20341
	v_sad_u8 v77, v77, 0, 0x6400                               // 000000911EE0: D622004D 03FD014D 00006400
	v_mov_b32_e32 v86, v64                                     // 000000911EEC: 7EAC0340
	v_lshl_or_b32 v60, v79, 16, v60                            // 000000911EF0: D656003C 04F1214F
	v_sad_u8 v58, v58, 0, 0x6400                               // 000000911EF8: D622003A 03FD013A 00006400
	v_sad_u8 v81, v81, 0, 0x6400                               // 000000911F04: D6220051 03FD0151 00006400
	v_dot2acc_f32_f16 v30, v80, v7                             // 000000911F10: 043C0F50
	v_sad_u8 v82, v82, 0, 0x6400                               // 000000911F14: D6220052 03FD0152 00006400
	v_pk_fma_f16 v60, v60, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000911F20: CC0E003C 0BFC0B3C 0000C931
	v_and_b32_e32 v78, 0xffff, v59                             // 000000911F2C: 369C76FF 0000FFFF
	v_bfe_u32 v59, v59, 4, 16                                  // 000000911F34: D610003B 0241093B
	v_lshlrev_b32_e32 v58, 16, v58                             // 000000911F3C: 30747490
	v_and_b32_e32 v81, 0xffff, v81                             // 000000911F40: 36A2A2FF 0000FFFF
	v_dot2acc_f32_f16 v25, v60, v5                             // 000000911F48: 04320B3C
	.long 0xd72c004e                                           // 000000911F4C: D72C004E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 000000911F50: 02029CFF 83DCD12D
	.long 0xd72c003b                                           // 000000911F58: D72C003B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 000000911F5C: 020276FF 83DCD12D
	v_dot2acc_f32_f16 v26, v60, v1                             // 000000911F64: 0434033C
	v_and_or_b32 v1, 0xffff, v77, v58                          // 000000911F68: D6570001 04EA9AFF 0000FFFF
	v_dot2acc_f32_f16 v24, v60, v9                             // 000000911F74: 0430133C
	v_dual_dot2acc_f32_f16 v22, v60, v13 :: v_dual_mov_b32 v79, v70// 000000911F78: CB101B3C 164E0146
	v_mov_b32_e32 v77, v61                                     // 000000911F80: 7E9A033D
	v_sad_u8 v78, v78, 0, 0x6400                               // 000000911F84: D622004E 03FD014E 00006400
	v_sad_u8 v59, v59, 0, 0x6400                               // 000000911F90: D622003B 03FD013B 00006400
	v_pk_fma_f16 v1, v1, s5, 0xc931 op_sel_hi:[1,0,0]          // 000000911F9C: CC0E0001 0BFC0B01 0000C931
	v_mov_b32_e32 v88, v73                                     // 000000911FA8: 7EB00349
	v_mov_b32_e32 v90, v73                                     // 000000911FAC: 7EB40349
	v_dual_mov_b32 v83, v63 :: v_dual_lshlrev_b32 v78, 16, v78 // 000000911FB0: CA22013F 534E9C90
	v_mov_b32_e32 v84, v71                                     // 000000911FB8: 7EA80347
	v_mov_b32_e32 v80, v62                                     // 000000911FBC: 7EA0033E
	v_mov_b32_e32 v60, v67                                     // 000000911FC0: 7E780343
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000911FC4: BF870244
	v_and_or_b32 v59, 0xffff, v59, v78                         // 000000911FC8: D657003B 053A76FF 0000FFFF
	v_lshl_or_b32 v78, v82, 16, v81                            // 000000911FD4: D656004E 05452152
	v_dual_mov_b32 v81, v70 :: v_dual_mov_b32 v82, v71         // 000000911FDC: CA100146 51520147
	v_mov_b32_e32 v58, v67                                     // 000000911FE4: 7E740343
	v_pk_fma_f16 v59, v59, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000911FE8: CC0E003B 0BFC0B3B 0000C931
	v_dot2acc_f32_f16 v30, v76, v8                             // 000000911FF4: 043C114C
	v_pk_fma_f16 v78, v78, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000911FF8: CC0E004E 0BFC0B4E 0000C931
	s_delay_alu instid0(VALU_DEP_3)                            // 000000912004: BF870003
	v_dot2acc_f32_f16 v26, v59, v2                             // 000000912008: 0434053B
	v_dot2acc_f32_f16 v25, v59, v6                             // 00000091200C: 04320D3B
	v_dot2acc_f32_f16 v24, v59, v10                            // 000000912010: 0430153B
	v_dot2acc_f32_f16 v22, v59, v14                            // 000000912014: 042C1D3B
	v_dot2acc_f32_f16 v28, v76, v12                            // 000000912018: 0438194C
	v_dual_dot2acc_f32_f16 v26, v78, v3 :: v_dual_mov_b32 v3, v75// 00000091201C: CB10074E 1A02014B
	v_dot2acc_f32_f16 v25, v78, v7                             // 000000912024: 04320F4E
	v_dot2acc_f32_f16 v24, v78, v11                            // 000000912028: 0430174E
	v_dot2acc_f32_f16 v22, v78, v15                            // 00000091202C: 042C1F4E
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000912030: BF870214
	v_dual_dot2acc_f32_f16 v26, v1, v4 :: v_dual_mov_b32 v59, v18// 000000912034: CB100901 1A3A0112
	v_dot2acc_f32_f16 v25, v1, v8                              // 00000091203C: 04321101
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000912040: BF870214
	v_dot2acc_f32_f16 v24, v1, v12                             // 000000912044: 04301901
	v_dot2acc_f32_f16 v22, v1, v16                             // 000000912048: 042C2101
	v_mov_b32_e32 v4, v75                                      // 00000091204C: 7E08034B
	v_mov_b32_e32 v2, v66                                      // 000000912050: 7E040342
	v_mov_b32_e32 v78, v69                                     // 000000912054: 7E9C0345
	v_mov_b32_e32 v76, v69                                     // 000000912058: 7E980345
	v_mov_b32_e32 v1, v17                                      // 00000091205C: 7E020311
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000912060: 917E047E
	s_cbranch_execz 58                                         // 000000912064: BFA5003A <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi2ELi4EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0x1c50>
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000912068: BF8700A1
	v_add_nc_u32_e32 v17, 1, v1                                // 00000091206C: 4A220281
	s_mov_b32 s6, exec_lo                                      // 000000912070: BE86007E
	.long 0xd4c1007e                                           // 000000912074: D4C1007E
	v_cndmask_b32_e32 v1, v17, v23, vcc_lo                     // 000000912078: 02022F11
	s_cbranch_execz 64550                                      // 00000091207C: BFA5FC26 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi2ELi4EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0xc18>
	v_ashrrev_i32_e32 v18, 31, v17                             // 000000912080: 3424229F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000912084: BF870091
	.long 0xd73c0005                                           // 000000912088: D73C0005
	v_cndmask_b32_e32 v1, 10, v17, vcc_lo                      // 00000091208C: 0202228A
	.long 0xd7006a07                                           // 000000912090: D7006A07
	v_cndmask_b32_e32 v1, s1, v5, vcc_lo                       // 000000912094: 02020A01
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000912098: BF870111
	v_add_co_ci_u32_e64 v8, null, s3, v6, vcc_lo               // 00000091209C: D5207C08 01AA0C03
	.long 0xd7006a05                                           // 0000009120A4: D7006A05
	v_cndmask_b32_e32 v1, v7, v57, vcc_lo                      // 0000009120A8: 02027307
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000009120AC: BF8700A1
	v_add_co_ci_u32_e64 v6, null, 0, v8, vcc_lo                // 0000009120B0: D5207C06 01AA1080
	.long 0xd7006a07                                           // 0000009120B8: D7006A07
	v_cndmask_b32_e32 v1, v7, v56, vcc_lo                      // 0000009120BC: 02027107
	v_add_co_ci_u32_e64 v8, null, 0, v8, vcc_lo                // 0000009120C0: D5207C08 01AA1080
	s_clause 0xf                                               // 0000009120C8: BF85000F
	global_load_b32 v66, v[5:6], off                           // 0000009120CC: DC520000 427C0005
	global_load_b32 v68, v[5:6], off offset:128                // 0000009120D4: DC520080 447C0005
	global_load_b32 v65, v[5:6], off offset:256                // 0000009120DC: DC520100 417C0005
	global_load_b32 v64, v[5:6], off offset:384                // 0000009120E4: DC520180 407C0005
	global_load_b32 v63, v[5:6], off offset:512                // 0000009120EC: DC520200 3F7C0005
	global_load_b32 v62, v[5:6], off offset:640                // 0000009120F4: DC520280 3E7C0005
	global_load_b32 v61, v[5:6], off offset:768                // 0000009120FC: DC520300 3D7C0005
	global_load_b32 v18, v[5:6], off offset:896                // 000000912104: DC520380 127C0005
	global_load_b32 v75, v[7:8], off                           // 00000091210C: DC520000 4B7C0007
	global_load_b32 v74, v[7:8], off offset:128                // 000000912114: DC520080 4A7C0007
	global_load_b32 v73, v[7:8], off offset:256                // 00000091211C: DC520100 497C0007
	global_load_b32 v72, v[7:8], off offset:384                // 000000912124: DC520180 487C0007
	global_load_b32 v71, v[7:8], off offset:512                // 00000091212C: DC520200 477C0007
	global_load_b32 v70, v[7:8], off offset:640                // 000000912134: DC520280 467C0007
	global_load_b32 v69, v[7:8], off offset:768                // 00000091213C: DC520300 457C0007
	global_load_b32 v67, v[7:8], off offset:896                // 000000912144: DC520380 437C0007
	s_branch 64498                                             // 00000091214C: BFA0FBF2 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi2ELi4EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0xc18>
	s_or_b32 exec_lo, exec_lo, s4                              // 000000912150: 8C7E047E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000912154: BF870009
	s_or_b32 exec_lo, exec_lo, s0                              // 000000912158: 8C7E007E
	s_waitcnt vmcnt(23)                                        // 00000091215C: BF895FF7
	v_dual_mov_b32 v1, v54 :: v_dual_mov_b32 v2, v51           // 000000912160: CA100136 01020133
	s_waitcnt vmcnt(7)                                         // 000000912168: BF891FF7
	v_dual_mov_b32 v4, v50 :: v_dual_mov_b32 v3, v41           // 00000091216C: CA100132 04020129
	v_dual_mov_b32 v5, v47 :: v_dual_mov_b32 v8, v52           // 000000912174: CA10012F 05080134
	v_dual_mov_b32 v7, v53 :: v_dual_mov_b32 v10, v48          // 00000091217C: CA100135 070A0130
	v_dual_mov_b32 v9, v49 :: v_dual_mov_b32 v14, v43          // 000000912184: CA100131 090E012B
	v_dual_mov_b32 v6, v29 :: v_dual_mov_b32 v11, v46          // 00000091218C: CA10011D 060A012E
	v_dual_mov_b32 v12, v45 :: v_dual_mov_b32 v13, v44         // 000000912194: CA10012D 0C0C012C
	v_dual_mov_b32 v15, v42 :: v_dual_mov_b32 v16, v40         // 00000091219C: CA10012A 0F100128
	v_dual_mov_b32 v17, v39 :: v_dual_mov_b32 v18, v38         // 0000009121A4: CA100127 11120126
	v_dual_mov_b32 v23, v37 :: v_dual_mov_b32 v56, v35         // 0000009121AC: CA100125 17380123
	s_waitcnt vmcnt(0)                                         // 0000009121B4: BF8903F7
	v_dual_mov_b32 v55, v36 :: v_dual_mov_b32 v58, v33         // 0000009121B8: CA100124 373A0121
	v_dual_mov_b32 v57, v34 :: v_dual_mov_b32 v60, v31         // 0000009121C0: CA100122 393C011F
	v_dual_mov_b32 v59, v32 :: v_dual_mov_b32 v64, v26         // 0000009121C8: CA100120 3B40011A
	v_dual_mov_b32 v61, v30 :: v_dual_mov_b32 v62, v28         // 0000009121D0: CA10011E 3D3E011C
	v_dual_mov_b32 v63, v27 :: v_dual_mov_b32 v66, v24         // 0000009121D8: CA10011B 3F420118
	v_mov_b32_e32 v65, v25                                     // 0000009121E0: 7E820319
	v_mov_b32_e32 v67, v22                                     // 0000009121E4: 7E860316
	s_mov_b32 s0, 0x76543210                                   // 0000009121E8: BE8000FF 76543210
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000009121F0: BF870009
	v_permlanex16_b32 v1, v1, s0, 0xfedcba98                   // 0000009121F4: D65C0001 03FC0101 FEDCBA98
	v_permlanex16_b32 v2, v2, s0, 0xfedcba98                   // 000000912200: D65C0002 03FC0102 FEDCBA98
	v_permlanex16_b32 v4, v4, s0, 0xfedcba98                   // 00000091220C: D65C0004 03FC0104 FEDCBA98
	v_permlanex16_b32 v3, v3, s0, 0xfedcba98                   // 000000912218: D65C0003 03FC0103 FEDCBA98
	v_permlanex16_b32 v5, v5, s0, 0xfedcba98                   // 000000912224: D65C0005 03FC0105 FEDCBA98
	v_permlanex16_b32 v7, v7, s0, 0xfedcba98                   // 000000912230: D65C0007 03FC0107 FEDCBA98
	v_permlanex16_b32 v8, v8, s0, 0xfedcba98                   // 00000091223C: D65C0008 03FC0108 FEDCBA98
	v_permlanex16_b32 v9, v9, s0, 0xfedcba98                   // 000000912248: D65C0009 03FC0109 FEDCBA98
	v_permlanex16_b32 v6, v6, s0, 0xfedcba98                   // 000000912254: D65C0006 03FC0106 FEDCBA98
	v_permlanex16_b32 v10, v10, s0, 0xfedcba98                 // 000000912260: D65C000A 03FC010A FEDCBA98
	v_permlanex16_b32 v11, v11, s0, 0xfedcba98                 // 00000091226C: D65C000B 03FC010B FEDCBA98
	v_permlanex16_b32 v12, v12, s0, 0xfedcba98                 // 000000912278: D65C000C 03FC010C FEDCBA98
	v_permlanex16_b32 v13, v13, s0, 0xfedcba98                 // 000000912284: D65C000D 03FC010D FEDCBA98
	v_permlanex16_b32 v14, v14, s0, 0xfedcba98                 // 000000912290: D65C000E 03FC010E FEDCBA98
	v_permlanex16_b32 v15, v15, s0, 0xfedcba98                 // 00000091229C: D65C000F 03FC010F FEDCBA98
	v_permlanex16_b32 v16, v16, s0, 0xfedcba98                 // 0000009122A8: D65C0010 03FC0110 FEDCBA98
	v_permlanex16_b32 v17, v17, s0, 0xfedcba98                 // 0000009122B4: D65C0011 03FC0111 FEDCBA98
	v_permlanex16_b32 v18, v18, s0, 0xfedcba98                 // 0000009122C0: D65C0012 03FC0112 FEDCBA98
	v_permlanex16_b32 v23, v23, s0, 0xfedcba98                 // 0000009122CC: D65C0017 03FC0117 FEDCBA98
	v_permlanex16_b32 v55, v55, s0, 0xfedcba98                 // 0000009122D8: D65C0037 03FC0137 FEDCBA98
	v_permlanex16_b32 v56, v56, s0, 0xfedcba98                 // 0000009122E4: D65C0038 03FC0138 FEDCBA98
	v_permlanex16_b32 v57, v57, s0, 0xfedcba98                 // 0000009122F0: D65C0039 03FC0139 FEDCBA98
	v_permlanex16_b32 v58, v58, s0, 0xfedcba98                 // 0000009122FC: D65C003A 03FC013A FEDCBA98
	v_permlanex16_b32 v59, v59, s0, 0xfedcba98                 // 000000912308: D65C003B 03FC013B FEDCBA98
	v_permlanex16_b32 v60, v60, s0, 0xfedcba98                 // 000000912314: D65C003C 03FC013C FEDCBA98
	v_permlanex16_b32 v61, v61, s0, 0xfedcba98                 // 000000912320: D65C003D 03FC013D FEDCBA98
	v_permlanex16_b32 v62, v62, s0, 0xfedcba98                 // 00000091232C: D65C003E 03FC013E FEDCBA98
	v_permlanex16_b32 v63, v63, s0, 0xfedcba98                 // 000000912338: D65C003F 03FC013F FEDCBA98
	v_permlanex16_b32 v64, v64, s0, 0xfedcba98                 // 000000912344: D65C0040 03FC0140 FEDCBA98
	v_permlanex16_b32 v65, v65, s0, 0xfedcba98                 // 000000912350: D65C0041 03FC0141 FEDCBA98
	v_permlanex16_b32 v66, v66, s0, 0xfedcba98                 // 00000091235C: D65C0042 03FC0142 FEDCBA98
	v_permlanex16_b32 v67, v67, s0, 0xfedcba98                 // 000000912368: D65C0043 03FC0143 FEDCBA98
	.long 0xd44c0000                                           // 000000912374: D44C0000
	v_cndmask_b32_e32 v1, 16, v20, vcc_lo                      // 000000912378: 02022890
	s_barrier                                                  // 00000091237C: BFBD0000
	buffer_gl0_inv                                             // 000000912380: E0AC0000 00000000
	s_and_saveexec_b32 s1, s0                                  // 000000912388: BE812000
	s_cbranch_execz 68                                         // 00000091238C: BFA50044 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi2ELi4EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0x1fa0>
	v_lshl_or_b32 v21, v19, 11, v21                            // 000000912390: D6560015 04551713
	v_dual_add_f32 v12, v45, v12 :: v_dual_add_f32 v5, v47, v5 // 000000912398: C908192D 0C040B2F
	v_dual_add_f32 v8, v52, v8 :: v_dual_add_f32 v1, v54, v1   // 0000009123A0: C9081134 08000336
	v_dual_add_f32 v10, v48, v10 :: v_dual_add_f32 v7, v53, v7 // 0000009123A8: C9081530 0A060F35
	v_add_f32_e32 v2, v51, v2                                  // 0000009123B0: 06040533
	v_add_f32_e32 v20, v22, v67                                // 0000009123B4: 06288716
	v_add_f32_e32 v22, v24, v66                                // 0000009123B8: 062C8518
	v_dual_add_f32 v24, v25, v65 :: v_dual_add_f32 v25, v26, v64// 0000009123BC: C9088319 1818811A
	v_dual_add_f32 v26, v27, v63 :: v_dual_add_f32 v27, v28, v62// 0000009123C4: C9087F1B 1A1A7D1C
	v_add_f32_e32 v28, v30, v61                                // 0000009123CC: 06387B1E
	v_dual_add_f32 v30, v31, v60 :: v_dual_add_f32 v23, v37, v23// 0000009123D0: C908791F 1E162F25
	v_dual_add_f32 v31, v32, v59 :: v_dual_add_f32 v32, v33, v58// 0000009123D8: C9087720 1F207521
	v_add_f32_e32 v17, v39, v17                                // 0000009123E0: 06222327
	v_dual_add_f32 v33, v34, v57 :: v_dual_add_f32 v34, v35, v56// 0000009123E4: C9087322 21227123
	v_add_f32_e32 v15, v42, v15                                // 0000009123EC: 061E1F2A
	v_dual_add_f32 v35, v36, v55 :: v_dual_add_f32 v4, v50, v4 // 0000009123F0: C9086F24 23040932
	v_dual_add_f32 v3, v41, v3 :: v_dual_add_nc_u32 v36, 0x400, v21// 0000009123F8: C9200729 03242AFF 00000400
	v_dual_add_f32 v14, v43, v14 :: v_dual_add_f32 v9, v49, v9 // 000000912404: C9081D2B 0E081331
	v_dual_add_f32 v18, v38, v18 :: v_dual_add_f32 v13, v44, v13// 00000091240C: C9082526 120C1B2C
	v_add_f32_e32 v6, v29, v6                                  // 000000912414: 060C0D1D
	v_dual_add_f32 v16, v40, v16 :: v_dual_add_f32 v11, v46, v11// 000000912418: C9082128 100A172E
	ds_store_2addr_b32 v21, v1, v5 offset1:16                  // 000000912420: D8381000 00050115
	ds_store_2addr_b32 v21, v2, v7 offset0:128 offset1:144     // 000000912428: D8389080 00070215
	ds_store_2addr_b32 v36, v4, v8 offset1:16                  // 000000912430: D8381000 00080424
	ds_store_2addr_b32 v36, v3, v9 offset0:128 offset1:144     // 000000912438: D8389080 00090324
	ds_store_2addr_b32 v21, v6, v13 offset0:32 offset1:48      // 000000912440: D8383020 000D0615
	ds_store_2addr_b32 v21, v10, v14 offset0:160 offset1:176   // 000000912448: D838B0A0 000E0A15
	ds_store_2addr_b32 v36, v11, v15 offset0:32 offset1:48     // 000000912450: D8383020 000F0B24
	ds_store_2addr_b32 v36, v12, v16 offset0:160 offset1:176   // 000000912458: D838B0A0 00100C24
	ds_store_2addr_b32 v21, v17, v34 offset0:64 offset1:80     // 000000912460: D8385040 00221115
	ds_store_2addr_b32 v21, v18, v33 offset0:192 offset1:208   // 000000912468: D838D0C0 00211215
	ds_store_2addr_b32 v36, v23, v32 offset0:64 offset1:80     // 000000912470: D8385040 00201724
	ds_store_2addr_b32 v36, v35, v31 offset0:192 offset1:208   // 000000912478: D838D0C0 001F2324
	ds_store_2addr_b32 v21, v30, v25 offset0:96 offset1:112    // 000000912480: D8387060 00191E15
	ds_store_2addr_b32 v21, v28, v24 offset0:224 offset1:240   // 000000912488: D838F0E0 00181C15
	ds_store_2addr_b32 v36, v27, v22 offset0:96 offset1:112    // 000000912490: D8387060 00161B24
	ds_store_2addr_b32 v36, v26, v20 offset0:224 offset1:240   // 000000912498: D838F0E0 00141A24
	s_or_b32 exec_lo, exec_lo, s1                              // 0000009124A0: 8C7E017E
	.long 0xd44c0001                                           // 0000009124A4: D44C0001
	v_cndmask_b32_e32 v1, 0x200, v0, vcc_lo                    // 0000009124A8: 020200FF 00000200
	s_waitcnt lgkmcnt(0)                                       // 0000009124B0: BF89FC07
	s_barrier                                                  // 0000009124B4: BFBD0000
	buffer_gl0_inv                                             // 0000009124B8: E0AC0000 00000000
	s_and_saveexec_b32 s3, s1                                  // 0000009124C0: BE832001
	s_cbranch_execz 49                                         // 0000009124C4: BFA50031 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi2ELi4EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0x208c>
	v_mov_b32_e32 v1, v0                                       // 0000009124C8: 7E020300
	s_mov_b32 s4, 0                                            // 0000009124CC: BE840080
	s_nop 0                                                    // 0000009124D0: BF800000
	s_nop 0                                                    // 0000009124D4: BF800000
	s_nop 0                                                    // 0000009124D8: BF800000
	s_nop 0                                                    // 0000009124DC: BF800000
	s_nop 0                                                    // 0000009124E0: BF800000
	s_nop 0                                                    // 0000009124E4: BF800000
	s_nop 0                                                    // 0000009124E8: BF800000
	s_nop 0                                                    // 0000009124EC: BF800000
	s_nop 0                                                    // 0000009124F0: BF800000
	s_nop 0                                                    // 0000009124F4: BF800000
	s_nop 0                                                    // 0000009124F8: BF800000
	s_nop 0                                                    // 0000009124FC: BF800000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000912500: BF870001
	v_lshlrev_b32_e32 v8, 2, v1                                // 000000912504: 30100282
	v_cmp_lt_u32_e32 vcc_lo, 0xff, v1                          // 000000912508: 7C9202FF 000000FF
	ds_load_2addr_stride64_b32 v[2:3], v8 offset1:8            // 000000912510: D8E00800 02000008
	ds_load_2addr_stride64_b32 v[4:5], v8 offset0:16 offset1:24// 000000912518: D8E01810 04000008
	ds_load_2addr_stride64_b32 v[6:7], v8 offset0:32 offset1:40// 000000912520: D8E02820 06000008
	s_or_b32 s4, vcc_lo, s4                                    // 000000912528: 8C04046A
	s_waitcnt lgkmcnt(2)                                       // 00000091252C: BF89FC27
	v_add_f32_e32 v2, 0, v2                                    // 000000912530: 06040480
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000912534: BF8700C1
	v_add_f32_e32 v9, v2, v3                                   // 000000912538: 06120702
	ds_load_2addr_stride64_b32 v[2:3], v8 offset0:48 offset1:56// 00000091253C: D8E03830 02000008
	s_waitcnt lgkmcnt(2)                                       // 000000912544: BF89FC27
	v_add_f32_e32 v4, v9, v4                                   // 000000912548: 06080909
	v_add_f32_e32 v4, v4, v5                                   // 00000091254C: 06080B04
	s_waitcnt lgkmcnt(1)                                       // 000000912550: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000912554: BF870091
	v_add_f32_e32 v4, v4, v6                                   // 000000912558: 06080D04
	v_add_f32_e32 v4, v4, v7                                   // 00000091255C: 06080F04
	s_waitcnt lgkmcnt(0)                                       // 000000912560: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000912564: BF8700A1
	v_add_f32_e32 v2, v4, v2                                   // 000000912568: 06040504
	v_add_nc_u32_e32 v4, 0x100, v1                             // 00000091256C: 4A0802FF 00000100
	v_dual_add_f32 v2, v2, v3 :: v_dual_mov_b32 v1, v4         // 000000912574: C9100702 02000104
	ds_store_b32 v8, v2 offset:16384                           // 00000091257C: D8344000 00000208
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000912584: 917E047E
	s_cbranch_execnz 65501                                     // 000000912588: BFA6FFDD <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi2ELi4EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0x2000>
	s_or_b32 exec_lo, exec_lo, s3                              // 00000091258C: 8C7E037E
	s_cmp_lt_i32 s9, 2                                         // 000000912590: BF048209
	s_mov_b32 s3, -1                                           // 000000912594: BE8300C1
	s_cbranch_scc1 212                                         // 000000912598: BFA200D4 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi2ELi4EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0x23ec>
	s_waitcnt lgkmcnt(0)                                       // 00000091259C: BF89FC07
	s_barrier                                                  // 0000009125A0: BFBD0000
	buffer_gl0_inv                                             // 0000009125A4: E0AC0000 00000000
	s_and_saveexec_b32 s3, s1                                  // 0000009125AC: BE832001
	s_cbranch_execz 71                                         // 0000009125B0: BFA50047 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi2ELi4EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0x21d0>
	v_lshrrev_b32_e32 v1, 7, v0                                // 0000009125B4: 32020087
	s_ashr_i32 s29, s28, 31                                    // 0000009125B8: 861D9F1C
	s_ashr_i32 s31, s30, 31                                    // 0000009125BC: 861F9F1E
	s_lshl_b64 s[4:5], s[28:29], 2                             // 0000009125C0: 8484821C
	s_lshl_b32 s6, s10, 7                                      // 0000009125C4: 8406870A
	v_or_b32_e32 v1, s4, v1                                    // 0000009125C8: 38020204
	v_mov_b32_e32 v2, s5                                       // 0000009125CC: 7E040205
	s_lshl_b64 s[4:5], s[30:31], 2                             // 0000009125D0: 8484821E
	s_ashr_i32 s7, s6, 31                                      // 0000009125D4: 86079F06
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000009125D8: BF8700A9
	s_lshl_b64 s[6:7], s[6:7], 2                               // 0000009125DC: 84868206
	.long 0xd7016a01                                           // 0000009125E0: D7016A01
	v_cndmask_b32_e32 v0, v1, v4, vcc_lo                       // 0000009125E4: 02000901
	v_subrev_co_ci_u32_e64 v2, null, s5, v2, vcc_lo            // 0000009125E8: D5227C02 01AA0405
	s_ashr_i32 s5, s49, 31                                     // 0000009125F0: 86059F31
	s_mov_b32 s4, s49                                          // 0000009125F4: BE840031
	.long 0xd72c0004                                           // 0000009125F8: D72C0004
	v_cndmask_b32_e32 v0, v1, v5, vcc_lo                       // 0000009125FC: 02000B01
	.long 0xd72c0003                                           // 000000912600: D72C0003
	v_cndmask_b32_e32 v0, v2, v49, vcc_lo                      // 000000912604: 02006302
	v_mad_u64_u32 v[1:2], null, v1, s49, 0                     // 000000912608: D6FE7C01 02006301
	s_lshl_b64 s[4:5], s[4:5], 3                               // 000000912610: 84848304
	v_add3_u32 v2, v2, v4, v3                                  // 000000912614: D6550002 040E0902
	v_and_b32_e32 v3, 0x7f, v0                                 // 00000091261C: 360600FF 0000007F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000912624: BF870112
	.long 0xd73c0001                                           // 000000912628: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 00000091262C: 02020282
	v_lshlrev_b32_e32 v4, 2, v3                                // 000000912630: 30080682
	v_lshlrev_b32_e32 v3, 2, v0                                // 000000912634: 30060082
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000912638: BF870093
	.long 0xd7006a01                                           // 00000091263C: D7006A01
	v_cndmask_b32_e32 v0, v1, v6, vcc_lo                       // 000000912640: 02000D01
	v_add_co_ci_u32_e64 v2, null, s7, v2, vcc_lo               // 000000912644: D5207C02 01AA0407
	s_mov_b32 s6, 0                                            // 00000091264C: BE860080
	.long 0xd7006a01                                           // 000000912650: D7006A01
	v_cndmask_b32_e32 v1, v1, v4, vcc_lo                       // 000000912654: 02020901
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000912658: BF8701A1
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 00000091265C: D5207C02 01AA0480
	v_or_b32_e32 v4, 0xffffff00, v0                            // 000000912664: 380800FF FFFFFF00
	.long 0xd7006a01                                           // 00000091266C: D7006A01
	v_cndmask_b32_e32 v1, s44, v1, vcc_lo                      // 000000912670: 0202022C
	s_delay_alu instid0(VALU_DEP_1)                            // 000000912674: BF870001
	v_add_co_ci_u32_e64 v2, null, s45, v2, vcc_lo              // 000000912678: D5207C02 01AA042D
	ds_load_b32 v5, v3 offset:16384                            // 000000912680: D8D84000 05000003
	.long 0xd7000704                                           // 000000912688: D7000704
	v_cndmask_b32_e32 v1, 0x100, v4, vcc_lo                    // 00000091268C: 020208FF 00000100
	s_xor_b32 s7, s7, -1                                       // 000000912694: 8D07C107
	v_add_nc_u32_e32 v3, 0x400, v3                             // 000000912698: 4A0606FF 00000400
	s_and_b32 s7, exec_lo, s7                                  // 0000009126A0: 8B07077E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000009126A4: BF8700C9
	s_or_b32 s6, s7, s6                                        // 0000009126A8: 8C060607
	s_waitcnt lgkmcnt(0)                                       // 0000009126AC: BF89FC07
	global_store_b32 v[1:2], v5, off                           // 0000009126B0: DC6A0000 007C0501
	.long 0xd7006a01                                           // 0000009126B8: D7006A01
	v_cndmask_b32_e32 v0, v1, v4, vcc_lo                       // 0000009126BC: 02000901
	v_add_co_ci_u32_e64 v2, null, s5, v2, vcc_lo               // 0000009126C0: D5207C02 01AA0405
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 0000009126C8: 917E067E
	s_cbranch_execnz 65516                                     // 0000009126CC: BFA6FFEC <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi2ELi4EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0x2180>
	s_or_b32 exec_lo, exec_lo, s3                              // 0000009126D0: 8C7E037E
	.long 0xd44a0003                                           // 0000009126D4: D44A0003
	v_cndmask_b32_e32 v1, 0, v0, vcc_lo                        // 0000009126D8: 02020080
	s_waitcnt_vscnt null, 0x0                                  // 0000009126DC: BC7C0000
	buffer_gl1_inv                                             // 0000009126E0: E0B00000 00000000
	buffer_gl0_inv                                             // 0000009126E8: E0AC0000 00000000
	s_barrier                                                  // 0000009126F0: BFBD0000
	buffer_gl0_inv                                             // 0000009126F4: E0AC0000 00000000
	s_and_saveexec_b32 s4, s3                                  // 0000009126FC: BE842003
	s_cbranch_execz 29                                         // 000000912700: BFA5001D <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi2ELi4EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0x2278>
	s_mov_b32 s6, exec_lo                                      // 000000912704: BE86007E
	s_mov_b32 s5, exec_lo                                      // 000000912708: BE85007E
	.long 0xd71f0001                                           // 00000091270C: D71F0001
	v_cndmask_b32_e32 v0, s6, v128, vcc_lo                     // 000000912710: 02010006
	s_delay_alu instid0(VALU_DEP_1)                            // 000000912714: BF870001
	v_cmpx_eq_u32_e32 0, v1                                    // 000000912718: 7D940280
	s_cbranch_execz 9                                          // 00000091271C: BFA50009 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi2ELi4EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0x2244>
	s_lshl_b64 s[24:25], s[10:11], 2                           // 000000912720: 8498820A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 000000912724: BF8704B9
	s_add_u32 s24, s46, s24                                    // 000000912728: 8018182E
	s_addc_u32 s25, s47, s25                                   // 00000091272C: 8219192F
	s_bcnt1_i32_b32 s6, s6                                     // 000000912730: BE861806
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v3, s6              // 000000912734: CA100080 02020006
	global_atomic_add_u32 v2, v2, v3, s[24:25] glc             // 00000091273C: DCD64000 02180302
	s_or_b32 exec_lo, exec_lo, s5                              // 000000912744: 8C7E057E
	s_waitcnt vmcnt(0)                                         // 000000912748: BF8903F7
	v_readfirstlane_b32 s5, v2                                 // 00000091274C: 7E0A0502
	s_delay_alu instid0(VALU_DEP_1)                            // 000000912750: BF870001
	v_dual_mov_b32 v2, 0 :: v_dual_add_nc_u32 v1, s5, v1       // 000000912754: CA200080 02000205
	s_add_i32 s5, s9, -1                                       // 00000091275C: 8105C109
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 000000912760: BF870481
	v_cmp_eq_u32_e32 vcc_lo, s5, v1                            // 000000912764: 7C940205
	v_cndmask_b32_e64 v1, 0, 1, vcc_lo                         // 000000912768: D5010001 01A90280
	ds_store_b32 v2, v1 offset:29440                           // 000000912770: D8347300 00000102
	s_or_b32 exec_lo, exec_lo, s4                              // 000000912778: 8C7E047E
	v_mov_b32_e32 v1, 0                                        // 00000091277C: 7E020280
	s_waitcnt lgkmcnt(0)                                       // 000000912780: BF89FC07
	s_barrier                                                  // 000000912784: BFBD0000
	buffer_gl0_inv                                             // 000000912788: E0AC0000 00000000
	ds_load_b32 v1, v1 offset:29440                            // 000000912790: D8D87300 01000001
	s_waitcnt lgkmcnt(0)                                       // 000000912798: BF89FC07
	v_cmp_eq_u32_e32 vcc_lo, 0, v1                             // 00000091279C: 7C940280
	s_cbranch_vccnz 2362                                       // 0000009127A0: BFA4093A <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi2ELi4EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0x478c>
	buffer_gl1_inv                                             // 0000009127A4: E0B00000 00000000
	buffer_gl0_inv                                             // 0000009127AC: E0AC0000 00000000
	s_and_saveexec_b32 s8, s1                                  // 0000009127B4: BE882001
	s_cbranch_execz 65                                         // 0000009127B8: BFA50041 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi2ELi4EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0x23c0>
	v_lshrrev_b32_e32 v1, 7, v0                                // 0000009127BC: 32020087
	s_lshl_b32 s4, s10, 7                                      // 0000009127C0: 8404870A
	v_and_b32_e32 v3, 0x7f, v0                                 // 0000009127C4: 360600FF 0000007F
	s_ashr_i32 s5, s4, 31                                      // 0000009127CC: 86059F04
	v_mov_b32_e32 v5, v0                                       // 0000009127D0: 7E0A0300
	v_mad_i64_i32 v[1:2], null, v1, s49, 0                     // 0000009127D4: D6FF7C01 02006301
	s_lshl_b64 s[4:5], s[4:5], 2                               // 0000009127DC: 84848204
	v_lshlrev_b32_e32 v3, 2, v3                                // 0000009127E0: 30060682
	s_ashr_i32 s7, s49, 31                                     // 0000009127E4: 86079F31
	s_mov_b32 s6, s49                                          // 0000009127E8: BE860031
	s_mov_b32 s24, 0                                           // 0000009127EC: BE980080
	.long 0xd73c0001                                           // 0000009127F0: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 0000009127F4: 02020282
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000009127F8: BF870091
	.long 0xd7006a01                                           // 0000009127FC: D7006A01
	v_cndmask_b32_e32 v0, v1, v4, vcc_lo                       // 000000912800: 02000901
	v_add_co_ci_u32_e64 v2, null, s5, v2, vcc_lo               // 000000912804: D5207C02 01AA0405
	s_lshl_b64 s[4:5], s[6:7], 3                               // 00000091280C: 84848306
	.long 0xd7006a01                                           // 000000912810: D7006A01
	v_cndmask_b32_e32 v1, v1, v3, vcc_lo                       // 000000912814: 02020701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000912818: BF8700B1
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 00000091281C: D5207C02 01AA0480
	s_lshl_b64 s[6:7], s[6:7], 4                               // 000000912824: 84868406
	.long 0xd7006a01                                           // 000000912828: D7006A01
	v_cndmask_b32_e32 v1, s44, v1, vcc_lo                      // 00000091282C: 0202022C
	v_add_co_ci_u32_e64 v2, null, s45, v2, vcc_lo              // 000000912830: D5207C02 01AA042D
	s_nop 0                                                    // 000000912838: BF800000
	s_nop 0                                                    // 00000091283C: BF800000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000912840: BF870001
	v_dual_mov_b32 v4, v2 :: v_dual_mov_b32 v3, v1             // 000000912844: CA100102 04020101
	v_mov_b32_e32 v6, 0                                        // 00000091284C: 7E0C0280
	s_mov_b32 s1, s9                                           // 000000912850: BE810009
	global_load_b32 v7, v[3:4], off glc                        // 000000912854: DC524000 077C0003
	.long 0xd7006a03                                           // 00000091285C: D7006A03
	v_cndmask_b32_e32 v0, v3, v6, vcc_lo                       // 000000912860: 02000D03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000912864: BF8704A1
	v_add_co_ci_u32_e64 v4, null, s7, v4, vcc_lo               // 000000912868: D5207C04 01AA0807
	s_add_i32 s1, s1, -1                                       // 000000912870: 8101C101
	s_cmp_eq_u32 s1, 0                                         // 000000912874: BF068001
	s_waitcnt vmcnt(0)                                         // 000000912878: BF8903F7
	v_add_f32_e32 v6, v6, v7                                   // 00000091287C: 060C0F06
	s_cbranch_scc0 65524                                       // 000000912880: BFA1FFF4 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi2ELi4EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0x2354>
	v_add_nc_u32_e32 v4, 0x100, v5                             // 000000912884: 4A080AFF 00000100
	v_cmp_lt_u32_e32 vcc_lo, 0xff, v5                          // 00000091288C: 7C920AFF 000000FF
	.long 0xd7000101                                           // 000000912894: D7000101
	v_cndmask_b32_e32 v0, v1, v4, vcc_lo                       // 000000912898: 02000901
	v_lshlrev_b32_e32 v3, 2, v5                                // 00000091289C: 30060A82
	v_add_co_ci_u32_e64 v2, null, s5, v2, s1                   // 0000009128A0: D5207C02 00060405
	v_mov_b32_e32 v5, v4                                       // 0000009128A8: 7E0A0304
	s_or_b32 s24, vcc_lo, s24                                  // 0000009128AC: 8C18186A
	ds_store_b32 v3, v6 offset:16384                           // 0000009128B0: D8344000 00000603
	s_and_not1_b32 exec_lo, exec_lo, s24                       // 0000009128B8: 917E187E
	s_cbranch_execnz 65504                                     // 0000009128BC: BFA6FFE0 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi2ELi4EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0x2340>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000009128C0: 8C7E087E
	s_and_saveexec_b32 s1, s3                                  // 0000009128C4: BE812003
	s_cbranch_execz 6                                          // 0000009128C8: BFA50006 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi2ELi4EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0x23e4>
	s_lshl_b64 s[4:5], s[10:11], 2                             // 0000009128CC: 8484820A
	v_mov_b32_e32 v1, 0                                        // 0000009128D0: 7E020280
	s_add_u32 s4, s46, s4                                      // 0000009128D4: 8004042E
	s_addc_u32 s5, s47, s5                                     // 0000009128D8: 8205052F
	global_store_b32 v1, v1, s[4:5]                            // 0000009128DC: DC6A0000 00040101
	s_or_b32 exec_lo, exec_lo, s1                              // 0000009128E4: 8C7E017E
	s_mov_b32 s3, -1                                           // 0000009128E8: BE8300C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000009128EC: BF870009
	s_and_b32 vcc_lo, exec_lo, s3                              // 0000009128F0: 8B6A037E
	s_cbranch_vccz 379                                         // 0000009128F4: BFA3017B <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi2ELi4EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0x29e4>
	v_cmp_gt_i32_e32 vcc_lo, s48, v19                          // 0000009128F8: 7C882630
	.long 0xd44c0001                                           // 0000009128FC: D44C0001
	v_cndmask_b32_e32 v1, 0x80, v0, vcc_lo                     // 000000912900: 020200FF 00000080
	s_waitcnt lgkmcnt(0)                                       // 000000912908: BF89FC07
	s_waitcnt_vscnt null, 0x0                                  // 00000091290C: BC7C0000
	s_barrier                                                  // 000000912910: BFBD0000
	buffer_gl0_inv                                             // 000000912914: E0AC0000 00000000
	s_and_b32 s1, vcc_lo, s1                                   // 00000091291C: 8B01016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000912920: BF870009
	s_and_saveexec_b32 s3, s1                                  // 000000912924: BE832001
	s_cbranch_execz 365                                        // 000000912928: BFA5016D <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi2ELi4EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0x29e0>
	v_and_b32_e32 v1, 15, v0                                   // 00000091292C: 3602008F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000912930: BF870091
	v_lshlrev_b32_e32 v2, 2, v1                                // 000000912934: 30040282
	v_lshl_or_b32 v2, v19, 9, v2                               // 000000912938: D6560002 04091313
	s_delay_alu instid0(VALU_DEP_1)                            // 000000912940: BF870001
	v_add_nc_u32_e32 v8, 0x4000, v2                            // 000000912944: 4A1004FF 00004000
	ds_load_2addr_b32 v[2:3], v8 offset1:16                    // 00000091294C: D8DC1000 02000008
	ds_load_2addr_b32 v[4:5], v8 offset0:32 offset1:48         // 000000912954: D8DC3020 04000008
	ds_load_2addr_b32 v[6:7], v8 offset0:64 offset1:80         // 00000091295C: D8DC5040 06000008
	ds_load_2addr_b32 v[8:9], v8 offset0:96 offset1:112        // 000000912964: D8DC7060 08000008
	v_and_b32_e32 v10, 1, v0                                   // 00000091296C: 36140081
	v_and_b32_e32 v11, 2, v0                                   // 000000912970: 36160082
	s_waitcnt lgkmcnt(3)                                       // 000000912974: BF89FC37
	v_dual_add_f32 v13, v2, v3 :: v_dual_and_b32 v12, 4, v0    // 000000912978: C9240702 0D0C0084
	s_waitcnt lgkmcnt(2)                                       // 000000912980: BF89FC27
	v_dual_sub_f32 v2, v2, v3 :: v_dual_add_f32 v3, v4, v5     // 000000912984: C9480702 02020B04
	s_waitcnt lgkmcnt(1)                                       // 00000091298C: BF89FC17
	v_dual_sub_f32 v4, v4, v5 :: v_dual_add_f32 v5, v6, v7     // 000000912990: C9480B04 04040F06
	s_waitcnt lgkmcnt(0)                                       // 000000912998: BF89FC07
	v_dual_sub_f32 v6, v6, v7 :: v_dual_add_f32 v7, v8, v9     // 00000091299C: C9480F06 06061308
	v_dual_sub_f32 v8, v8, v9 :: v_dual_add_f32 v9, v13, v3    // 0000009129A4: C9481308 0808070D
	v_sub_f32_e32 v3, v13, v3                                  // 0000009129AC: 0806070D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000009129B0: BF870243
	v_dual_add_f32 v13, v2, v4 :: v_dual_add_f32 v14, v5, v7   // 0000009129B4: C9080902 0D0E0F05
	v_dual_sub_f32 v2, v2, v4 :: v_dual_sub_f32 v5, v5, v7     // 0000009129BC: C94A0902 02040F05
	v_cmp_eq_u32_e32 vcc_lo, 0, v10                            // 0000009129C4: 7C941480
	.long 0xd44a0001                                           // 0000009129C8: D44A0001
	v_cndmask_b32_e32 v1, 0, v12, vcc_lo                       // 0000009129CC: 02021880
	v_dual_add_f32 v7, v9, v14 :: v_dual_add_f32 v4, v6, v8    // 0000009129D0: C9081D09 07041106
	v_sub_f32_e32 v6, v6, v8                                   // 0000009129D8: 080C1106
	v_sub_f32_e32 v8, v9, v14                                  // 0000009129DC: 08101D09
	s_delay_alu instid0(VALU_DEP_3)                            // 0000009129E0: BF870003
	v_add_f32_e32 v9, v13, v4                                  // 0000009129E4: 0612090D
	v_dual_sub_f32 v4, v13, v4 :: v_dual_add_f32 v13, v3, v5   // 0000009129E8: C948090D 040C0B03
	v_sub_f32_e32 v3, v3, v5                                   // 0000009129F0: 08060B03
	v_add_f32_e32 v5, v2, v6                                   // 0000009129F4: 060A0D02
	v_sub_f32_e32 v2, v2, v6                                   // 0000009129F8: 08040D02
	v_mov_b32_dpp v6, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009129FC: 7E0C02FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, vcc_lo                      // 000000912A04: D5010007 21AA0F07
	v_mov_b32_dpp v10, v9 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000912A0C: 7E1402FA FF016109
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 000000912A14: D5010009 21AA1309
	v_mov_b32_dpp v14, v13 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000912A1C: 7E1C02FA FF01610D
	v_cndmask_b32_e64 v13, -v13, v13, vcc_lo                   // 000000912A24: D501000D 21AA1B0D
	v_mov_b32_dpp v15, v5 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000912A2C: 7E1E02FA FF016105
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 000000912A34: D5010005 21AA0B05
	v_mov_b32_dpp v16, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000912A3C: 7E2002FA FF016108
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 000000912A44: D5010008 21AA1108
	v_mov_b32_dpp v17, v4 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000912A4C: 7E2202FA FF016104
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 000000912A54: D5010004 21AA0904
	v_mov_b32_dpp v18, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000912A5C: 7E2402FA FF016103
	v_cndmask_b32_e64 v20, -v3, v3, vcc_lo                     // 000000912A64: D5010014 21AA0703
	v_cndmask_b32_e64 v22, -v2, v2, vcc_lo                     // 000000912A6C: D5010016 21AA0502
	v_cmp_eq_u32_e32 vcc_lo, 0, v11                            // 000000912A74: 7C941680
	v_dual_add_f32 v3, v7, v6 :: v_dual_add_f32 v8, v8, v16    // 000000912A78: C9080D07 03082108
	v_mov_b32_dpp v21, v2 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000912A80: 7E2A02FA FF016102
	v_dual_add_f32 v2, v9, v10 :: v_dual_add_f32 v9, v4, v17   // 000000912A88: C9081509 02082304
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000912A90: BF870233
	v_mov_b32_dpp v4, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000912A94: 7E0802FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 000000912A9C: D5010003 21AA0703
	v_add_f32_e32 v6, v13, v14                                 // 000000912AA4: 060C1D0D
	v_mov_b32_dpp v7, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000912AA8: 7E0E02FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, vcc_lo                      // 000000912AB0: D5010002 21AA0502
	v_mov_b32_dpp v12, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000912AB8: 7E1802FA FF016208
	v_add_f32_e32 v3, v3, v4                                   // 000000912AC0: 06060903
	v_mov_b32_dpp v10, v6 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000912AC4: 7E1402FA FF016206
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 000000912ACC: D5010006 21AA0D06
	v_add_f32_e32 v5, v5, v15                                  // 000000912AD4: 060A1F05
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 000000912AD8: D5010008 21AA1108
	v_add_f32_e32 v13, v22, v21                                // 000000912AE0: 061A2B16
	v_mov_b32_dpp v14, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000912AE4: 7E1C02FA FF016209
	v_add_f32_e32 v6, v6, v10                                  // 000000912AEC: 060C1506
	v_mov_b32_dpp v11, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000912AF0: 7E1602FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 000000912AF8: D5010005 21AA0B05
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 000000912B00: D5010009 21AA1309
	v_add_f32_e32 v8, v8, v12                                  // 000000912B08: 06101908
	v_mov_b32_dpp v15, v13 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000912B0C: 7E1E02FA FF01620D
	v_cndmask_b32_e64 v13, -v13, v13, vcc_lo                   // 000000912B14: D501000D 21AA1B0D
	v_add_f32_e32 v4, v5, v11                                  // 000000912B1C: 06081705
	v_mov_b32_dpp v5, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000912B20: 7E0A02FA FF016403
	v_cndmask_b32_e64 v3, -v3, v3, s1                          // 000000912B28: D5010003 20060703
	v_add_f32_e32 v2, v2, v7                                   // 000000912B30: 06040F02
	v_mov_b32_dpp v11, v6 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000912B34: 7E1602FA FF016406
	v_cndmask_b32_e64 v6, -v6, v6, s1                          // 000000912B3C: D5010006 20060D06
	v_add_f32_e32 v9, v9, v14                                  // 000000912B44: 06121D09
	v_add_f32_e32 v3, v3, v5                                   // 000000912B48: 06060B03
	v_cndmask_b32_e64 v7, -v2, v2, s1                          // 000000912B4C: D5010007 20060502
	v_mov_b32_dpp v2, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000912B54: 7E0402FA FF016402
	v_cndmask_b32_e64 v14, -v8, v8, s1                         // 000000912B5C: D501000E 20061108
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000912B64: BF870242
	v_add_f32_e32 v7, v7, v2                                   // 000000912B68: 060E0507
	v_mov_b32_dpp v10, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000912B6C: 7E1402FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s1                          // 000000912B74: D5010004 20060904
	v_mov_b32_dpp v2, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000912B7C: 7E0402FA FF016803
	v_mov_b32_dpp v5, v7 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000912B84: 7E0A02FA FF016807
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000912B8C: BF8700A3
	v_add_f32_e32 v4, v4, v10                                  // 000000912B90: 06081504
	v_add_f32_e32 v10, v20, v18                                // 000000912B94: 06142514
	v_mov_b32_dpp v12, v10 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000912B98: 7E1802FA FF01620A
	v_cndmask_b32_e64 v10, -v10, v10, vcc_lo                   // 000000912BA0: D501000A 21AA150A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000912BA8: BF870241
	v_add_f32_e32 v10, v10, v12                                // 000000912BAC: 0614190A
	v_add_f32_e32 v12, v13, v15                                // 000000912BB0: 06181F0D
	v_mov_b32_dpp v13, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000912BB4: 7E1A02FA FF016409
	v_cndmask_b32_e64 v9, -v9, v9, s1                          // 000000912BBC: D5010009 20061309
	v_mov_b32_dpp v15, v10 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000912BC4: 7E1E02FA FF01640A
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 000000912BCC: BF870254
	v_mov_b32_dpp v17, v12 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000912BD0: 7E2202FA FF01640C
	v_cndmask_b32_e64 v10, -v10, v10, s1                       // 000000912BD8: D501000A 2006150A
	v_cndmask_b32_e64 v12, -v12, v12, s1                       // 000000912BE0: D501000C 2006190C
	v_add_f32_e32 v6, v6, v11                                  // 000000912BE8: 060C1706
	v_mov_b32_dpp v11, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000912BEC: 7E1602FA FF016408
	v_dual_add_f32 v16, v9, v13 :: v_dual_add_f32 v15, v10, v15// 000000912BF4: C9081B09 100E1F0A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000912BFC: BF870214
	v_add_f32_e32 v17, v12, v17                                // 000000912C00: 0622230C
	v_mov_b32_dpp v8, v6 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000912C04: 7E1002FA FF016806
	s_delay_alu instid0(VALU_DEP_4)                            // 000000912C0C: BF870004
	v_add_f32_e32 v14, v14, v11                                // 000000912C10: 061C170E
	v_mov_b32_dpp v9, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000912C14: 7E1202FA FF016804
	v_mov_b32_dpp v11, v16 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000912C1C: 7E1602FA FF016810
	v_mov_b32_dpp v12, v15 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000912C24: 7E1802FA FF01680F
	v_mov_b32_dpp v13, v17 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000912C2C: 7E1A02FA FF016811
	v_mov_b32_dpp v10, v14 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000912C34: 7E1402FA FF01680E
	s_and_b32 exec_lo, exec_lo, s0                             // 000000912C3C: 8B7E007E
	s_cbranch_execz 167                                        // 000000912C40: BFA500A7 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi2ELi4EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0x29e0>
	v_lshl_or_b32 v20, s10, 7, v1                              // 000000912C44: D6560014 04050E0A
	v_and_b32_e32 v1, 8, v0                                    // 000000912C4C: 36020088
	v_mad_i64_i32 v[18:19], null, s49, v19, 0                  // 000000912C50: D6FF7C12 02022631
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000912C58: BF870113
	v_ashrrev_i32_e32 v21, 31, v20                             // 000000912C5C: 342A289F
	.long 0xd73c0012                                           // 000000912C60: D73C0012
	v_cndmask_b32_e32 v1, 1, v18, vcc_lo                       // 000000912C64: 02022481
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000912C68: BF870092
	.long 0xd73c0014                                           // 000000912C6C: D73C0014
	v_cndmask_b32_e32 v1, 1, v20, vcc_lo                       // 000000912C70: 02022881
	.long 0xd7006a16                                           // 000000912C74: D7006A16
	v_cndmask_b32_e32 v1, s36, v20, vcc_lo                     // 000000912C78: 02022824
	s_delay_alu instid0(VALU_DEP_1)                            // 000000912C7C: BF870001
	v_add_co_ci_u32_e64 v23, null, s37, v21, vcc_lo            // 000000912C80: D5207C17 01AA2A25
	v_cmp_eq_u32_e32 vcc_lo, 0, v1                             // 000000912C88: 7C940280
	s_clause 0x7                                               // 000000912C8C: BF850007
	global_load_d16_b16 v24, v[22:23], off offset:32           // 000000912C90: DC820020 187C0016
	global_load_d16_b16 v25, v[22:23], off                     // 000000912C98: DC820000 197C0016
	global_load_d16_b16 v26, v[22:23], off offset:64           // 000000912CA0: DC820040 1A7C0016
	global_load_d16_b16 v27, v[22:23], off offset:96           // 000000912CA8: DC820060 1B7C0016
	global_load_d16_b16 v28, v[22:23], off offset:128          // 000000912CB0: DC820080 1C7C0016
	global_load_d16_b16 v29, v[22:23], off offset:160          // 000000912CB8: DC8200A0 1D7C0016
	global_load_d16_b16 v30, v[22:23], off offset:192          // 000000912CC0: DC8200C0 1E7C0016
	global_load_d16_b16 v22, v[22:23], off offset:224          // 000000912CC8: DC8200E0 167C0016
	.long 0x7f2e3880                                           // 000000912CD0: 7F2E3880
	v_cndmask_b32_e64 v1, -v7, v7, vcc_lo                      // 000000912CD4: D5010001 21AA0F07
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 000000912CDC: D5010004 21AA0904
	v_cndmask_b32_e64 v14, -v14, v14, vcc_lo                   // 000000912CE4: D501000E 21AA1D0E
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 000000912CEC: D5010003 21AA0703
	v_cndmask_b32_e64 v15, -v15, v15, vcc_lo                   // 000000912CF4: D501000F 21AA1F0F
	v_add_f32_e32 v1, v1, v5                                   // 000000912CFC: 06020B01
	v_cndmask_b32_e64 v5, -v6, v6, vcc_lo                      // 000000912D00: D5010005 21AA0D06
	v_cndmask_b32_e64 v6, -v16, v16, vcc_lo                    // 000000912D08: D5010006 21AA2110
	v_cndmask_b32_e64 v16, -v17, v17, vcc_lo                   // 000000912D10: D5010010 21AA2311
	.long 0xd7006a11                                           // 000000912D18: D7006A11
	v_cndmask_b32_e32 v1, s42, v18, vcc_lo                     // 000000912D1C: 0202242A
	s_delay_alu instid0(VALU_DEP_1)                            // 000000912D20: BF870001
	v_add_co_ci_u32_e64 v18, null, s43, v19, vcc_lo            // 000000912D24: D5207C12 01AA262B
	v_dual_add_f32 v5, v5, v8 :: v_dual_add_f32 v4, v4, v9     // 000000912D2C: C9081105 05041304
	v_dual_add_f32 v8, v14, v10 :: v_dual_mul_f32 v19, 0x3db504f3, v1// 000000912D34: C906150E 081202FF 3DB504F3
	s_waitcnt vmcnt(7)                                         // 000000912D40: BF891FF7
	.long 0x7f303997                                           // 000000912D44: 7F303997
	v_dual_add_f32 v3, v3, v2 :: v_dual_add_f32 v6, v6, v11    // 000000912D48: C9080503 03061706
	v_mul_f32_e32 v4, 0x3db504f3, v4                           // 000000912D50: 100808FF 3DB504F3
	v_dual_add_f32 v9, v15, v12 :: v_dual_add_f32 v10, v16, v13// 000000912D58: C908190F 090A1B10
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000912D60: BF870213
	v_dual_mul_f32 v3, 0x3db504f3, v3 :: v_dual_mul_f32 v8, 0x3db504f3, v8// 000000912D64: C8C606FF 030810FF 3DB504F3
	v_dual_mul_f32 v6, 0x3db504f3, v6 :: v_dual_mul_f32 v5, 0x3db504f3, v5// 000000912D70: C8C60CFF 06040AFF 3DB504F3
	s_delay_alu instid0(VALU_DEP_3)                            // 000000912D7C: BF870003
	v_mul_f32_e32 v10, 0x3db504f3, v10                         // 000000912D80: 101414FF 3DB504F3
	s_waitcnt vmcnt(6)                                         // 000000912D88: BF891BF7
	.long 0x7f323997                                           // 000000912D8C: 7F323997
	.long 0x7f0e3997                                           // 000000912D90: 7F0E3997
	s_waitcnt vmcnt(0)                                         // 000000912D94: BF8903F7
	.long 0x7f2c3997                                           // 000000912D98: 7F2C3997
	.long 0xd7006a01                                           // 000000912D9C: D7006A01
	v_cndmask_b32_e32 v1, v17, v20, vcc_lo                     // 000000912DA0: 02022911
	s_delay_alu instid0(VALU_DEP_1)                            // 000000912DA4: BF870001
	v_add_co_ci_u32_e64 v2, null, v18, v21, vcc_lo             // 000000912DA8: D5207C02 01AA2B12
	v_fma_mix_f32 v11, v24, v19, neg(0) op_sel_hi:[1,0,0]      // 000000912DB0: CC20000B 8A022718
	v_fma_mix_f32 v3, v25, v3, neg(0) op_sel_hi:[1,0,0]        // 000000912DB8: CC200003 8A020719
	v_fma_mix_f32 v5, v26, v5, neg(0) op_sel_hi:[1,0,0]        // 000000912DC0: CC200005 8A020B1A
	v_fma_mix_f32 v4, v27, v4, neg(0) op_sel_hi:[1,0,0]        // 000000912DC8: CC200004 8A02091B
	v_fma_mix_f32 v8, v28, v8, neg(0) op_sel_hi:[1,0,0]        // 000000912DD0: CC200008 8A02111C
	.long 0x7e2e398b                                           // 000000912DD8: 7E2E398B
	v_mul_f32_e32 v9, 0x3db504f3, v9                           // 000000912DDC: 101212FF 3DB504F3
	v_fma_mix_f32 v6, v29, v6, neg(0) op_sel_hi:[1,0,0]        // 000000912DE4: CC200006 8A020D1D
	v_fma_mix_f32 v10, v22, v10, neg(0) op_sel_hi:[1,0,0]      // 000000912DEC: CC20000A 8A021516
	.long 0x7e0e3983                                           // 000000912DF4: 7E0E3983
	v_and_b32_e32 v12, 1, v23                                  // 000000912DF8: 36182E81
	.long 0x7e2e3984                                           // 000000912DFC: 7E2E3984
	v_fma_mix_f32 v9, v30, v9, neg(0) op_sel_hi:[1,0,0]        // 000000912E00: CC200009 8A02131E
	.long 0x7e2c3985                                           // 000000912E08: 7E2C3985
	.long 0x7e303988                                           // 000000912E0C: 7E303988
	v_and_b32_e32 v7, 1, v7                                    // 000000912E10: 360E0E81
	v_and_b32_e32 v13, 1, v23                                  // 000000912E14: 361A2E81
	.long 0x7e2e3986                                           // 000000912E18: 7E2E3986
	.long 0x7e323989                                           // 000000912E1C: 7E323989
	v_and_b32_e32 v14, 1, v22                                  // 000000912E20: 361C2C81
	v_and_b32_e32 v15, 1, v24                                  // 000000912E24: 361E3081
	v_add3_u32 v3, v3, v7, 0x7fff                              // 000000912E28: D6550003 03FE0F03 00007FFF
	v_and_b32_e32 v16, 1, v23                                  // 000000912E34: 36202E81
	.long 0x7e2e398a                                           // 000000912E38: 7E2E398A
	v_and_b32_e32 v17, 1, v25                                  // 000000912E3C: 36223281
	v_add3_u32 v11, v11, v12, 0x7fff                           // 000000912E40: D655000B 03FE190B 00007FFF
	v_add3_u32 v5, v5, v14, 0x7fff                             // 000000912E4C: D6550005 03FE1D05 00007FFF
	v_add3_u32 v4, v4, v13, 0x7fff                             // 000000912E58: D6550004 03FE1B04 00007FFF
	v_and_b32_e32 v7, 1, v23                                   // 000000912E64: 360E2E81
	v_add3_u32 v8, v8, v15, 0x7fff                             // 000000912E68: D6550008 03FE1F08 00007FFF
	v_add3_u32 v9, v9, v17, 0x7fff                             // 000000912E74: D6550009 03FE2309 00007FFF
	v_add3_u32 v6, v6, v16, 0x7fff                             // 000000912E80: D6550006 03FE2106 00007FFF
	s_delay_alu instid0(VALU_DEP_4)                            // 000000912E8C: BF870004
	v_add3_u32 v7, v10, v7, 0x7fff                             // 000000912E90: D6550007 03FE0F0A 00007FFF
	s_clause 0x7                                               // 000000912E9C: BF850007
	global_store_d16_hi_b16 v[1:2], v3, off                    // 000000912EA0: DC960000 007C0301
	global_store_d16_hi_b16 v[1:2], v11, off offset:32         // 000000912EA8: DC960020 007C0B01
	global_store_d16_hi_b16 v[1:2], v5, off offset:64          // 000000912EB0: DC960040 007C0501
	global_store_d16_hi_b16 v[1:2], v4, off offset:96          // 000000912EB8: DC960060 007C0401
	global_store_d16_hi_b16 v[1:2], v8, off offset:128         // 000000912EC0: DC960080 007C0801
	global_store_d16_hi_b16 v[1:2], v6, off offset:160         // 000000912EC8: DC9600A0 007C0601
	global_store_d16_hi_b16 v[1:2], v9, off offset:192         // 000000912ED0: DC9600C0 007C0901
	global_store_d16_hi_b16 v[1:2], v7, off offset:224         // 000000912ED8: DC9600E0 007C0701
	s_or_b32 exec_lo, exec_lo, s3                              // 000000912EE0: 8C7E037E
	s_mov_b32 s4, 0                                            // 000000912EE4: BE840080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000912EE8: BF870009
	s_and_b32 vcc_lo, exec_lo, s4                              // 000000912EEC: 8B6A047E
	s_cbranch_vccz 1891                                        // 000000912EF0: BFA30763 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi2ELi4EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0x4780>
	v_mov_b32_e32 v1, 0                                        // 000000912EF4: 7E020280
	global_load_b32 v2, v1, s[18:19]                           // 000000912EF8: DC520000 02120001
	s_waitcnt vmcnt(0)                                         // 000000912F00: BF8903F7
	.long 0xd72c0002                                           // 000000912F04: D72C0002
	v_cndmask_b32_e32 v0, v2, v148, vcc_lo                     // 000000912F08: 02012902
	s_delay_alu instid0(VALU_DEP_1)                            // 000000912F0C: BF870001
	v_cmp_ge_i32_e32 vcc_lo, s2, v2                            // 000000912F10: 7C8C0402
	s_cbranch_vccnz 1882                                       // 000000912F14: BFA4075A <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi2ELi4EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0x4780>
	s_mov_b32 s3, 0                                            // 000000912F18: BE830080
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000912F1C: BF870499
	s_lshl_b64 s[0:1], s[2:3], 4                               // 000000912F20: 84808402
	s_add_u32 s0, s16, s0                                      // 000000912F24: 80000010
	s_addc_u32 s1, s17, s1                                     // 000000912F28: 82010111
	global_load_b128 v[1:4], v1, s[0:1]                        // 000000912F2C: DC5E0000 01000001
	s_mov_b32 s0, exec_lo                                      // 000000912F34: BE80007E
	s_waitcnt vmcnt(0)                                         // 000000912F38: BF8903F7
	v_readfirstlane_b32 s4, v1                                 // 000000912F3C: 7E080501
	v_readfirstlane_b32 s3, v2                                 // 000000912F40: 7E060502
	v_cmpx_gt_u32_e32 0xa0, v0                                 // 000000912F44: 7D9800FF 000000A0
	s_cbranch_execz 29                                         // 000000912F4C: BFA5001D <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi2ELi4EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0x2ac4>
	v_cmp_lt_u32_e32 vcc_lo, 0x4f, v0                          // 000000912F50: 7C9200FF 0000004F
	v_add_nc_u32_e32 v1, -1, v4                                // 000000912F58: 4A0208C1
	v_add_co_ci_u32_e64 v2, null, 0, v3, vcc_lo                // 000000912F5C: D5207C02 01AA0680
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000912F64: BF8701B1
	v_min_i32_e32 v5, v2, v1                                   // 000000912F68: 220A0302
	.long 0xd7026a01                                           // 000000912F6C: D7026A01
	v_cndmask_b32_e32 v1, 0x50, v0, vcc_lo                     // 000000912F70: 020200FF 00000050
	v_mov_b32_e32 v2, 0                                        // 000000912F78: 7E040280
	v_mad_i64_i32 v[5:6], null, 0x500, v5, s[14:15]            // 000000912F7C: D6FF7C05 003A0AFF 00000500
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000912F88: BF870093
	v_cndmask_b32_e32 v1, v1, v0, vcc_lo                       // 000000912F8C: 02020101
	.long 0xd73c0001                                           // 000000912F90: D73C0001
	v_cndmask_b32_e32 v1, 4, v1, vcc_lo                        // 000000912F94: 02020284
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000912F98: BF870091
	.long 0xd7006a01                                           // 000000912F9C: D7006A01
	v_cndmask_b32_e32 v1, v5, v1, vcc_lo                       // 000000912FA0: 02020305
	v_add_co_ci_u32_e64 v2, null, v6, v2, vcc_lo               // 000000912FA4: D5207C02 01AA0506
	global_load_b128 v[5:8], v[1:2], off                       // 000000912FAC: DC5E0000 057C0001
	v_lshlrev_b32_e32 v1, 4, v0                                // 000000912FB4: 30020084
	s_waitcnt vmcnt(0)                                         // 000000912FB8: BF8903F7
	ds_store_b128 v1, v[5:8] offset:20480                      // 000000912FBC: DB7C5000 00000501
	s_or_b32 exec_lo, exec_lo, s0                              // 000000912FC4: 8C7E007E
	v_lshrrev_b32_e32 v13, 5, v0                               // 000000912FC8: 321A0085
	v_dual_mov_b32 v17, 0 :: v_dual_and_b32 v14, 31, v0        // 000000912FCC: CA240080 110E009F
	v_dual_mov_b32 v18, 0 :: v_dual_mov_b32 v19, 0             // 000000912FD4: CA100080 12120080
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000912FDC: BF8701C3
	v_mul_u32_u24_e32 v5, 5, v13                               // 000000912FE0: 160A1A85
	v_dual_mov_b32 v20, 0 :: v_dual_mov_b32 v23, 0             // 000000912FE4: CA100080 14160080
	v_mov_b32_e32 v22, 0                                       // 000000912FEC: 7E2C0280
	s_mul_hi_i32 s2, s4, 0x96000                               // 000000912FF0: 9702FF04 00096000
	v_min_u32_e32 v6, 35, v5                                   // 000000912FF8: 260C0AA3
	s_mul_i32 s6, s4, 0x96000                                  // 000000912FFC: 9606FF04 00096000
	s_mul_hi_i32 s5, s3, 0x7800                                // 000000913004: 9705FF03 00007800
	s_mul_i32 s7, s3, 0x7800                                   // 00000091300C: 9607FF03 00007800
	s_waitcnt lgkmcnt(0)                                       // 000000913014: BF89FC07
	s_waitcnt_vscnt null, 0x0                                  // 000000913018: BC7C0000
	v_dual_mov_b32 v21, 0 :: v_dual_add_nc_u32 v16, 5, v6      // 00000091301C: CA200080 15100C85
	s_barrier                                                  // 000000913024: BFBD0000
	buffer_gl0_inv                                             // 000000913028: E0AC0000 00000000
	v_cmp_lt_u32_e32 vcc_lo, v5, v16                           // 000000913030: 7C922105
	s_and_saveexec_b32 s1, vcc_lo                              // 000000913034: BE81206A
	s_cbranch_execz 30                                         // 000000913038: BFA5001E <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi2ELi4EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0x2bb4>
	v_mul_u32_u24_e32 v1, 0xf00, v13                           // 00000091303C: 16021AFF 00000F00
	s_add_u32 s0, s12, s6                                      // 000000913044: 8000060C
	s_addc_u32 s8, s13, s2                                     // 000000913048: 8208020D
	s_add_u32 s0, s0, s7                                       // 00000091304C: 80000700
	s_addc_u32 s8, s8, s5                                      // 000000913050: 82080508
	v_lshlrev_b32_e32 v2, 2, v14                               // 000000913054: 30041C82
	.long 0xd7000001                                           // 000000913058: D7000001
	v_cndmask_b32_e32 v1, s0, v1, vcc_lo                       // 00000091305C: 02020200
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000913060: BF870111
	v_add_co_ci_u32_e64 v7, null, s8, 0, s0                    // 000000913064: D5207C07 00010008
	.long 0xd7000001                                           // 00000091306C: D7000001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 000000913070: 02020501
	s_delay_alu instid0(VALU_DEP_1)                            // 000000913074: BF870001
	v_add_co_ci_u32_e64 v2, null, 0, v7, s0                    // 000000913078: D5207C02 00020E80
	s_clause 0x5                                               // 000000913080: BF850005
	global_load_b32 v18, v[1:2], off                           // 000000913084: DC520000 127C0001
	global_load_b32 v19, v[1:2], off offset:128                // 00000091308C: DC520080 137C0001
	global_load_b32 v20, v[1:2], off offset:256                // 000000913094: DC520100 147C0001
	global_load_b32 v21, v[1:2], off offset:384                // 00000091309C: DC520180 157C0001
	global_load_b32 v22, v[1:2], off offset:512                // 0000009130A4: DC520200 167C0001
	global_load_b32 v23, v[1:2], off offset:640                // 0000009130AC: DC520280 177C0001
	s_or_b32 exec_lo, exec_lo, s1                              // 0000009130B4: 8C7E017E
	v_dual_mov_b32 v37, 0 :: v_dual_mov_b32 v36, 0             // 0000009130B8: CA100080 25240080
	v_dual_mov_b32 v35, 0 :: v_dual_mov_b32 v34, 0             // 0000009130C0: CA100080 23220080
	v_dual_mov_b32 v33, 0 :: v_dual_mov_b32 v32, 0             // 0000009130C8: CA100080 21200080
	v_dual_mov_b32 v24, 0 :: v_dual_mov_b32 v31, 0             // 0000009130D0: CA100080 181E0080
	v_dual_mov_b32 v30, 0 :: v_dual_mov_b32 v25, 0             // 0000009130D8: CA100080 1E180080
	v_dual_mov_b32 v26, 0 :: v_dual_mov_b32 v29, 0             // 0000009130E0: CA100080 1A1C0080
	v_dual_mov_b32 v28, 0 :: v_dual_mov_b32 v27, 0             // 0000009130E8: CA100080 1C1A0080
	v_mov_b32_e32 v15, 0                                       // 0000009130F0: 7E1E0280
	s_and_saveexec_b32 s1, vcc_lo                              // 0000009130F4: BE81206A
	s_cbranch_execz 1100                                       // 0000009130F8: BFA5044C <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi2ELi4EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0x3d2c>
	v_lshl_or_b32 v7, v14, 3, 4                                // 0000009130FC: D6560007 0211070E
	v_mad_u32_u24 v8, v14, 24, 0x2f0                           // 000000913104: D60B0008 03FD310E 000002F0
	v_cmp_ne_u32_e32 vcc_lo, 0, v14                            // 000000913110: 7C9A1C80
	s_movk_i32 s0, 0x320                                       // 000000913114: B0000320
	s_add_u32 s6, s6, s7                                       // 000000913118: 80060706
	v_mad_u32_u24 v10, v7, 3, 0x2f0                            // 00000091311C: D60B000A 03FD0707 000002F0
	v_lshrrev_b32_e32 v1, 5, v8                                // 000000913128: 32021085
	v_mad_u32_u24 v17, v13, s0, 0x5000                         // 00000091312C: D60B0011 03FC010D 00005000
	v_mul_i32_i24_e32 v25, -3, v7                              // 000000913138: 12320EC3
	s_addc_u32 s7, s2, s5                                      // 00000091313C: 82070502
	v_lshrrev_b32_e32 v12, 5, v10                              // 000000913140: 32181485
	v_subrev_nc_u32_e32 v24, 24, v1                            // 000000913144: 4E300298
	v_lshlrev_b32_e32 v11, 2, v14                              // 000000913148: 30161C82
	v_mad_u64_u32 v[1:2], null, 0x300, v5, s[6:7]              // 00000091314C: D6FE7C01 001A0AFF 00000300
	v_mul_i32_i24_e32 v9, 0xffffffe8, v14                      // 000000913158: 12121CFF FFFFFFE8
	v_subrev_nc_u32_e32 v12, 24, v12                           // 000000913160: 4E181898
	v_cndmask_b32_e32 v24, 23, v24, vcc_lo                     // 000000913164: 02303097
	v_cmp_lt_u32_e32 vcc_lo, 5, v7                             // 000000913168: 7C920E85
	v_dual_mov_b32 v15, 0 :: v_dual_and_b32 v8, 0x7e0, v8      // 00000091316C: CA240080 0F0810FF 000007E0
	v_sub_nc_u32_e32 v41, 0, v6                                // 000000913178: 4C520C80
	v_dual_mov_b32 v29, 0 :: v_dual_add_nc_u32 v42, 1, v5      // 00000091317C: CA200080 1D2A0A81
	v_dual_cndmask_b32 v7, 23, v12 :: v_dual_add_nc_u32 v12, v17, v11// 000000913184: CA601897 070C1711
	v_cmp_gt_i32_e32 vcc_lo, 23, v24                           // 00000091318C: 7C883097
	v_add3_u32 v38, v9, v8, 0xfffffd34                         // 000000913190: D6550026 03FE1109 FFFFFD34
	s_delay_alu instid0(VALU_DEP_3)                            // 00000091319C: BF870003
	v_dual_mov_b32 v30, 0 :: v_dual_add_nc_u32 v27, 1, v7      // 0000009131A0: CA200080 1E1A0E81
	v_subrev_nc_u32_e32 v28, 23, v7                            // 0000009131A8: 4E380E97
	v_cndmask_b32_e64 v26, 0xffffffe9, 1, vcc_lo               // 0000009131AC: D501001A 01A902FF FFFFFFE9
	v_lshl_add_u32 v7, v7, 2, v17                              // 0000009131B8: D6460007 04450507
	v_add_nc_u32_e32 v43, 0x800, v12                           // 0000009131C0: 4A5618FF 00000800
	v_cmp_gt_u32_e32 vcc_lo, 24, v27                           // 0000009131C8: 7C983698
	v_and_b32_e32 v10, 0x7e0, v10                              // 0000009131CC: 361414FF 000007E0
	v_add_nc_u32_e32 v8, v26, v24                              // 0000009131D4: 4A10311A
	v_add_nc_u32_e32 v44, 0xc00, v12                           // 0000009131D8: 4A5818FF 00000C00
	v_dual_mov_b32 v32, 0 :: v_dual_add_nc_u32 v47, 0x800, v7  // 0000009131E0: CA200080 202E0EFF 00000800
	v_cndmask_b32_e32 v9, v28, v27, vcc_lo                     // 0000009131EC: 0212371C
	.long 0xd7006a01                                           // 0000009131F0: D7006A01
	v_cndmask_b32_e32 v1, v1, v11, vcc_lo                      // 0000009131F4: 02021701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000009131F8: BF8701A1
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 0000009131FC: D5207C02 01AA0480
	v_add3_u32 v39, v25, v10, 0xfffffd34                       // 000000913204: D6550027 03FE1519 FFFFFD34
	.long 0xd7006a01                                           // 000000913210: D7006A01
	v_cndmask_b32_e32 v1, s12, v1, vcc_lo                      // 000000913214: 0202020C
	v_lshl_add_u32 v10, v24, 2, v17                            // 000000913218: D646000A 04450518
	v_lshl_add_u32 v9, v9, 2, v17                              // 000000913220: D6460009 04450509
	v_dual_mov_b32 v26, 0 :: v_dual_and_b32 v11, 16, v0        // 000000913228: CA240080 1A0A0090
	v_add_co_ci_u32_e64 v2, null, s13, v2, vcc_lo              // 000000913230: D5207C02 01AA040D
	v_mov_b32_e32 v27, 0                                       // 000000913238: 7E360280
	v_lshl_add_u32 v8, v8, 2, v17                              // 00000091323C: D6460008 04450508
	.long 0xd7006a01                                           // 000000913244: D7006A01
	v_cndmask_b32_e32 v1, 0x300, v1, vcc_lo                    // 000000913248: 020202FF 00000300
	v_lshl_or_b32 v40, v5, 5, v11                              // 000000913250: D6560028 042D0B05
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 000000913258: D5207C02 01AA0480
	v_dual_mov_b32 v24, 0 :: v_dual_add_nc_u32 v45, 0x800, v10 // 000000913260: CA200080 182C14FF 00000800
	v_dual_mov_b32 v31, 0 :: v_dual_add_nc_u32 v46, 0x800, v8  // 00000091326C: CA200080 1F2E10FF 00000800
	v_dual_mov_b32 v33, 0 :: v_dual_add_nc_u32 v48, 0x800, v9  // 000000913278: CA200080 213012FF 00000800
	v_dual_mov_b32 v34, 0 :: v_dual_add_nc_u32 v49, 0xc00, v10 // 000000913284: CA200080 223014FF 00000C00
	v_dual_mov_b32 v35, 0 :: v_dual_add_nc_u32 v50, 0xc00, v8  // 000000913290: CA200080 233210FF 00000C00
	v_dual_mov_b32 v36, 0 :: v_dual_add_nc_u32 v51, 0xc00, v7  // 00000091329C: CA200080 24320EFF 00000C00
	v_dual_mov_b32 v37, 0 :: v_dual_add_nc_u32 v52, 0xc00, v9  // 0000009132A8: CA200080 253412FF 00000C00
	v_dual_mov_b32 v28, 0 :: v_dual_mov_b32 v25, 0             // 0000009132B4: CA100080 1C180080
	v_mov_b32_e32 v17, 0                                       // 0000009132BC: 7E220280
	s_mov_b32 s2, 0                                            // 0000009132C0: BE820080
	s_movk_i32 s5, 0x1eee                                      // 0000009132C4: B0051EEE
	s_branch 956                                               // 0000009132C8: BFA003BC <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi2ELi4EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0x3cbc>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000009132CC: 8C7E007E
	ds_load_2addr_b32 v[53:54], v46 offset0:128 offset1:152    // 0000009132D0: D8DC9880 3500002E
	ds_load_2addr_b32 v[55:56], v48 offset0:128 offset1:152    // 0000009132D8: D8DC9880 37000030
	ds_load_2addr_b32 v[6:7], v45 offset0:128 offset1:152      // 0000009132E0: D8DC9880 0600002D
	ds_load_2addr_b32 v[59:60], v47 offset0:128 offset1:152    // 0000009132E8: D8DC9880 3B00002F
	.long 0xd7000001                                           // 0000009132F0: D7000001
	v_cndmask_b32_e32 v1, 0x300, v1, vcc_lo                    // 0000009132F4: 020202FF 00000300
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 0000009132FC: BF870151
	v_add_co_ci_u32_e64 v2, null, 0, v2, s0                    // 000000913300: D5207C02 00020480
	s_waitcnt lgkmcnt(2)                                       // 000000913308: BF89FC27
	v_dual_mov_b32 v5, v53 :: v_dual_mov_b32 v58, v55          // 00000091330C: CA100135 053A0137
	s_waitcnt lgkmcnt(0)                                       // 000000913314: BF89FC07
	v_mov_b32_e32 v57, v60                                     // 000000913318: 7E72033C
	.long 0xd73d003e                                           // 00000091331C: D73D003E
	v_cndmask_b32_e32 v1, v38, v5, vcc_lo                      // 000000913320: 02020B26
	s_delay_alu instid0(VALU_DEP_3)                            // 000000913324: BF870003
	.long 0xd73d003a                                           // 000000913328: D73D003A
	v_cndmask_b32_e32 v1, v39, v58, vcc_lo                     // 00000091332C: 02027527
	v_mov_b32_e32 v55, v7                                      // 000000913330: 7E6E0307
	ds_load_b128 v[5:8], v40 offset:20480                      // 000000913334: DBFC5000 05000028
	ds_load_b128 v[9:12], v40 offset:21760                     // 00000091333C: DBFC5500 09000028
	ds_load_2addr_b32 v[60:61], v46 offset0:176 offset1:200    // 000000913344: D8DCC8B0 3C00002E
	v_add_nc_u32_e32 v40, 32, v40                              // 00000091334C: 4A5050A0
	.long 0xd73d0035                                           // 000000913350: D73D0035
	v_cndmask_b32_e32 v1, v38, v54, vcc_lo                     // 000000913354: 02026D26
	.long 0xd73d0036                                           // 000000913358: D73D0036
	v_cndmask_b32_e32 v1, v39, v56, vcc_lo                     // 00000091335C: 02027127
	v_bfe_u32 v55, v62, 9, 16                                  // 000000913360: D6100037 0241133E
	v_bfe_u32 v56, v62, 6, 16                                  // 000000913368: D6100038 02410D3E
	v_bfe_u32 v57, v62, 3, 16                                  // 000000913370: D6100039 0241073E
	v_bfe_u32 v63, v58, 6, 16                                  // 000000913378: D610003F 02410D3A
	v_bfe_u32 v65, v53, 9, 16                                  // 000000913380: D6100041 02411335
	.long 0xd72c0037                                           // 000000913388: D72C0037
	v_cndmask_b32_e32 v1, 0x83dcd12d, v55, vcc_lo              // 00000091338C: 02026EFF 83DCD12D
	.long 0xd72c0038                                           // 000000913394: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v56, vcc_lo              // 000000913398: 020270FF 83DCD12D
	v_bfe_u32 v66, v53, 6, 16                                  // 0000009133A0: D6100042 02410D35
	v_bfe_u32 v64, v58, 3, 16                                  // 0000009133A8: D6100040 0241073A
	.long 0xd72c0041                                           // 0000009133B0: D72C0041
	v_cndmask_b32_e32 v1, 0x83dcd12d, v65, vcc_lo              // 0000009133B4: 020282FF 83DCD12D
	.long 0xd72c0039                                           // 0000009133BC: D72C0039
	v_cndmask_b32_e32 v1, 0x83dcd12d, v57, vcc_lo              // 0000009133C0: 020272FF 83DCD12D
	.long 0xd72c003f                                           // 0000009133C8: D72C003F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v63, vcc_lo              // 0000009133CC: 02027EFF 83DCD12D
	.long 0xd72c0042                                           // 0000009133D4: D72C0042
	v_cndmask_b32_e32 v1, 0x83dcd12d, v66, vcc_lo              // 0000009133D8: 020284FF 83DCD12D
	v_sad_u8 v55, v55, 0, 0x6400                               // 0000009133E0: D6220037 03FD0137 00006400
	v_sad_u8 v56, v56, 0, 0x6400                               // 0000009133EC: D6220038 03FD0138 00006400
	v_bfe_u32 v67, v53, 3, 16                                  // 0000009133F8: D6100043 02410735
	.long 0xd72c0040                                           // 000000913400: D72C0040
	v_cndmask_b32_e32 v1, 0x83dcd12d, v64, vcc_lo              // 000000913404: 020280FF 83DCD12D
	v_bfe_u32 v68, v54, 9, 16                                  // 00000091340C: D6100044 02411336
	v_and_b32_e32 v55, 0xffff, v55                             // 000000913414: 366E6EFF 0000FFFF
	v_sad_u8 v57, v57, 0, 0x6400                               // 00000091341C: D6220039 03FD0139 00006400
	v_sad_u8 v63, v63, 0, 0x6400                               // 000000913428: D622003F 03FD013F 00006400
	v_bfe_u32 v69, v54, 6, 16                                  // 000000913434: D6100045 02410D36
	v_bfe_u32 v70, v54, 3, 16                                  // 00000091343C: D6100046 02410736
	v_lshl_or_b32 v55, v56, 16, v55                            // 000000913444: D6560037 04DD2138
	v_sad_u8 v56, v65, 0, 0x6400                               // 00000091344C: D6220038 03FD0141 00006400
	v_sad_u8 v65, v66, 0, 0x6400                               // 000000913458: D6220041 03FD0142 00006400
	v_and_b32_e32 v54, 0xffff, v54                             // 000000913464: 366C6CFF 0000FFFF
	v_sad_u8 v64, v64, 0, 0x6400                               // 00000091346C: D6220040 03FD0140 00006400
	v_pk_fma_f16 v55, v55, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000913478: CC0E0037 0BFC0B37 0000C931
	v_and_b32_e32 v56, 0xffff, v56                             // 000000913484: 367070FF 0000FFFF
	.long 0xd72c0043                                           // 00000091348C: D72C0043
	v_cndmask_b32_e32 v1, 0x83dcd12d, v67, vcc_lo              // 000000913490: 020286FF 83DCD12D
	.long 0xd72c0044                                           // 000000913498: D72C0044
	v_cndmask_b32_e32 v1, 0x83dcd12d, v68, vcc_lo              // 00000091349C: 020288FF 83DCD12D
	s_waitcnt lgkmcnt(2)                                       // 0000009134A4: BF89FC27
	v_dot2acc_f32_f16 v15, v55, v5                             // 0000009134A8: 041E0B37
	v_lshl_or_b32 v65, v65, 16, v56                            // 0000009134AC: D6560041 04E12141
	s_waitcnt lgkmcnt(1)                                       // 0000009134B4: BF89FC17
	v_dot2acc_f32_f16 v27, v55, v9                             // 0000009134B8: 04361337
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000009134BC: BF870242
	v_pk_fma_f16 v65, v65, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009134C0: CC0E0041 0BFC0B41 0000C931
	v_and_b32_e32 v59, 0xffff, v62                             // 0000009134CC: 36767CFF 0000FFFF
	v_bfe_u32 v62, v58, 9, 16                                  // 0000009134D4: D610003E 0241133A
	v_and_b32_e32 v58, 0xffff, v58                             // 0000009134DC: 367474FF 0000FFFF
	v_dot2acc_f32_f16 v28, v65, v5                             // 0000009134E4: 04380B41
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009134E8: BF870214
	.long 0xd72c003b                                           // 0000009134EC: D72C003B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 0000009134F0: 020276FF 83DCD12D
	.long 0xd72c003e                                           // 0000009134F8: D72C003E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v62, vcc_lo              // 0000009134FC: 02027CFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4)                            // 000000913504: BF870004
	.long 0xd72c003a                                           // 000000913508: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 00000091350C: 020274FF 83DCD12D
	v_and_b32_e32 v53, 0xffff, v53                             // 000000913514: 366A6AFF 0000FFFF
	v_dot2acc_f32_f16 v29, v65, v9                             // 00000091351C: 043A1341
	v_sad_u8 v59, v59, 0, 0x6400                               // 000000913520: D622003B 03FD013B 00006400
	v_sad_u8 v62, v62, 0, 0x6400                               // 00000091352C: D622003E 03FD013E 00006400
	v_sad_u8 v58, v58, 0, 0x6400                               // 000000913538: D622003A 03FD013A 00006400
	.long 0xd72c0035                                           // 000000913544: D72C0035
	v_cndmask_b32_e32 v1, 0x83dcd12d, v53, vcc_lo              // 000000913548: 02026AFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000913550: BF870214
	v_lshlrev_b32_e32 v59, 16, v59                             // 000000913554: 30767690
	v_and_b32_e32 v62, 0xffff, v62                             // 000000913558: 367C7CFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000913560: BF870194
	v_lshlrev_b32_e32 v58, 16, v58                             // 000000913564: 30747490
	v_and_or_b32 v57, 0xffff, v57, v59                         // 000000913568: D6570039 04EE72FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3)                            // 000000913574: BF870003
	v_lshl_or_b32 v62, v63, 16, v62                            // 000000913578: D656003E 04F9213F
	v_sad_u8 v53, v53, 0, 0x6400                               // 000000913580: D6220035 03FD0135 00006400
	v_sad_u8 v59, v67, 0, 0x6400                               // 00000091358C: D622003B 03FD0143 00006400
	v_sad_u8 v63, v68, 0, 0x6400                               // 000000913598: D622003F 03FD0144 00006400
	v_pk_fma_f16 v66, v57, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009135A4: CC0E0042 0BFC0B39 0000C931
	v_and_or_b32 v57, 0xffff, v64, v58                         // 0000009135B0: D6570039 04EA80FF 0000FFFF
	.long 0xd72c0040                                           // 0000009135BC: D72C0040
	v_cndmask_b32_e32 v1, 0x83dcd12d, v54, vcc_lo              // 0000009135C0: 02026CFF 83DCD12D
	ds_load_2addr_b32 v[54:55], v45 offset0:176 offset1:200    // 0000009135C8: D8DCC8B0 3600002D
	v_pk_fma_f16 v58, v62, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009135D0: CC0E003A 0BFC0B3E 0000C931
	.long 0xd72c003e                                           // 0000009135DC: D72C003E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v69, vcc_lo              // 0000009135E0: 02028AFF 83DCD12D
	v_lshlrev_b32_e32 v53, 16, v53                             // 0000009135E8: 306A6A90
	v_dual_dot2acc_f32_f16 v15, v66, v6 :: v_dual_and_b32 v68, 0xffff, v63// 0000009135EC: CB240D42 0F447EFF 0000FFFF
	v_pk_fma_f16 v67, v57, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009135F8: CC0E0043 0BFC0B39 0000C931
	v_sad_u8 v69, v64, 0, 0x6400                               // 000000913604: D6220045 03FD0140 00006400
	s_delay_alu instid0(VALU_DEP_4)                            // 000000913610: BF870004
	v_and_or_b32 v53, 0xffff, v59, v53                         // 000000913614: D6570035 04D676FF 0000FFFF
	ds_load_2addr_b32 v[56:57], v48 offset0:176 offset1:200    // 000000913620: D8DCC8B0 38000030
	v_sad_u8 v62, v62, 0, 0x6400                               // 000000913628: D622003E 03FD013E 00006400
	.long 0xd72c003b                                           // 000000913634: D72C003B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v70, vcc_lo              // 000000913638: 02028CFF 83DCD12D
	ds_load_2addr_b32 v[63:64], v47 offset0:176 offset1:200    // 000000913640: D8DCC8B0 3F00002F
	v_pk_fma_f16 v70, v53, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000913648: CC0E0046 0BFC0B35 0000C931
	s_waitcnt lgkmcnt(3)                                       // 000000913654: BF89FC37
	v_mov_b32_e32 v53, v60                                     // 000000913658: 7E6A033C
	v_lshl_or_b32 v62, v62, 16, v68                            // 00000091365C: D656003E 0511213E
	v_dual_dot2acc_f32_f16 v15, v58, v7 :: v_dual_lshlrev_b32 v68, 16, v69// 000000913664: CB220F3A 0F448A90
	v_dot2acc_f32_f16 v29, v70, v10                            // 00000091366C: 043A1546
	v_sad_u8 v59, v59, 0, 0x6400                               // 000000913670: D622003B 03FD013B 00006400
	s_waitcnt lgkmcnt(2)                                       // 00000091367C: BF89FC27
	.long 0xd73d0035                                           // 000000913680: D73D0035
	v_cndmask_b32_e32 v1, v38, v53, vcc_lo                     // 000000913684: 02026B26
	v_dot2acc_f32_f16 v27, v66, v10                            // 000000913688: 04361542
	v_pk_fma_f16 v60, v62, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000091368C: CC0E003C 0BFC0B3E 0000C931
	v_dot2acc_f32_f16 v28, v70, v6                             // 000000913698: 04380D46
	v_and_or_b32 v59, 0xffff, v59, v68                         // 00000091369C: D657003B 051276FF 0000FFFF
	v_bfe_u32 v54, v53, 9, 16                                  // 0000009136A8: D6100036 02411335
	s_delay_alu instid0(VALU_DEP_3)                            // 0000009136B0: BF870003
	v_dot2acc_f32_f16 v28, v60, v7                             // 0000009136B4: 04380F3C
	s_waitcnt lgkmcnt(1)                                       // 0000009136B8: BF89FC17
	v_mov_b32_e32 v62, v56                                     // 0000009136BC: 7E7C0338
	v_and_b32_e32 v56, 0xffff, v53                             // 0000009136C0: 36706AFF 0000FFFF
	.long 0xd72c0036                                           // 0000009136C8: D72C0036
	v_cndmask_b32_e32 v1, 0x83dcd12d, v54, vcc_lo              // 0000009136CC: 02026CFF 83DCD12D
	v_pk_fma_f16 v66, v59, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009136D4: CC0E0042 0BFC0B3B 0000C931
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000009136E0: BF870113
	.long 0xd72c0038                                           // 0000009136E4: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v56, vcc_lo              // 0000009136E8: 020270FF 83DCD12D
	v_dot2acc_f32_f16 v28, v66, v8                             // 0000009136F0: 04381142
	s_delay_alu instid0(VALU_DEP_4)                            // 0000009136F4: BF870004
	v_sad_u8 v54, v54, 0, 0x6400                               // 0000009136F8: D6220036 03FD0136 00006400
	v_dot2acc_f32_f16 v27, v58, v11                            // 000000913704: 0436173A
	s_waitcnt lgkmcnt(0)                                       // 000000913708: BF89FC07
	.long 0xd73d003a                                           // 00000091370C: D73D003A
	v_cndmask_b32_e32 v1, v39, v62, vcc_lo                     // 000000913710: 02027D27
	v_bfe_u32 v59, v53, 6, 16                                  // 000000913714: D610003B 02410D35
	v_bfe_u32 v53, v53, 3, 16                                  // 00000091371C: D6100035 02410735
	v_dot2acc_f32_f16 v15, v67, v8                             // 000000913724: 041E1143
	v_sad_u8 v56, v56, 0, 0x6400                               // 000000913728: D6220038 03FD0138 00006400
	v_and_b32_e32 v54, 0xffff, v54                             // 000000913734: 366C6CFF 0000FFFF
	v_bfe_u32 v62, v58, 9, 16                                  // 00000091373C: D610003E 0241133A
	.long 0xd72c003b                                           // 000000913744: D72C003B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 000000913748: 020276FF 83DCD12D
	.long 0xd72c0035                                           // 000000913750: D72C0035
	v_cndmask_b32_e32 v1, 0x83dcd12d, v53, vcc_lo              // 000000913754: 02026AFF 83DCD12D
	v_bfe_u32 v63, v58, 6, 16                                  // 00000091375C: D610003F 02410D3A
	v_dot2acc_f32_f16 v27, v67, v12                            // 000000913764: 04361943
	.long 0xd72c003e                                           // 000000913768: D72C003E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v62, vcc_lo              // 00000091376C: 02027CFF 83DCD12D
	v_bfe_u32 v67, v58, 3, 16                                  // 000000913774: D6100043 0241073A
	v_and_b32_e32 v58, 0xffff, v58                             // 00000091377C: 367474FF 0000FFFF
	.long 0xd72c003f                                           // 000000913784: D72C003F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v63, vcc_lo              // 000000913788: 02027EFF 83DCD12D
	v_sad_u8 v59, v59, 0, 0x6400                               // 000000913790: D622003B 03FD013B 00006400
	v_sad_u8 v53, v53, 0, 0x6400                               // 00000091379C: D6220035 03FD0135 00006400
	v_lshlrev_b32_e32 v56, 16, v56                             // 0000009137A8: 30707090
	.long 0xd72c003a                                           // 0000009137AC: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 0000009137B0: 020274FF 83DCD12D
	v_sad_u8 v62, v62, 0, 0x6400                               // 0000009137B8: D622003E 03FD013E 00006400
	v_lshl_or_b32 v54, v59, 16, v54                            // 0000009137C4: D6560036 04D9213B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000009137CC: BF8701A4
	v_and_or_b32 v53, 0xffff, v53, v56                         // 0000009137D0: D6570035 04E26AFF 0000FFFF
	.long 0xd72c0038                                           // 0000009137DC: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v67, vcc_lo              // 0000009137E0: 020286FF 83DCD12D
	v_pk_fma_f16 v54, v54, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009137E8: CC0E0036 0BFC0B36 0000C931
	v_and_b32_e32 v59, 0xffff, v62                             // 0000009137F4: 36767CFF 0000FFFF
	v_sad_u8 v62, v63, 0, 0x6400                               // 0000009137FC: D622003E 03FD013F 00006400
	v_sad_u8 v58, v58, 0, 0x6400                               // 000000913808: D622003A 03FD013A 00006400
	v_pk_fma_f16 v53, v53, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000913814: CC0E0035 0BFC0B35 0000C931
	v_dot2acc_f32_f16 v26, v54, v5                             // 000000913820: 04340B36
	v_dot2acc_f32_f16 v25, v54, v9                             // 000000913824: 04321336
	v_lshl_or_b32 v59, v62, 16, v59                            // 000000913828: D656003B 04ED213E
	v_mov_b32_e32 v62, v55                                     // 000000913830: 7E7C0337
	v_sad_u8 v56, v56, 0, 0x6400                               // 000000913834: D6220038 03FD0138 00006400
	v_lshlrev_b32_e32 v58, 16, v58                             // 000000913840: 30747490
	v_dot2acc_f32_f16 v26, v53, v6                             // 000000913844: 04340D35
	v_pk_fma_f16 v55, v59, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000913848: CC0E0037 0BFC0B3B 0000C931
	v_dot2acc_f32_f16 v25, v53, v10                            // 000000913854: 04321535
	.long 0xd73d0035                                           // 000000913858: D73D0035
	v_cndmask_b32_e32 v1, v38, v61, vcc_lo                     // 00000091385C: 02027B26
	v_and_or_b32 v56, 0xffff, v56, v58                         // 000000913860: D6570038 04EA70FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000091386C: BF870214
	v_dot2acc_f32_f16 v26, v55, v7                             // 000000913870: 04340F37
	v_dual_mov_b32 v58, v64 :: v_dual_dot2acc_f32_f16 v25, v55, v11// 000000913874: CA180140 3A181737
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000091387C: BF870233
	v_pk_fma_f16 v54, v56, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000913880: CC0E0036 0BFC0B38 0000C931
	v_bfe_u32 v59, v53, 9, 16                                  // 00000091388C: D610003B 02411335
	v_dot2acc_f32_f16 v29, v60, v11                            // 000000913894: 043A173C
	.long 0xd73d0037                                           // 000000913898: D73D0037
	v_cndmask_b32_e32 v1, v39, v57, vcc_lo                     // 00000091389C: 02027327
	v_bfe_u32 v56, v53, 6, 16                                  // 0000009138A0: D6100038 02410D35
	v_dot2acc_f32_f16 v26, v54, v8                             // 0000009138A8: 04341136
	v_dot2acc_f32_f16 v25, v54, v12                            // 0000009138AC: 04321936
	.long 0xd72c0036                                           // 0000009138B0: D72C0036
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 0000009138B4: 020276FF 83DCD12D
	v_bfe_u32 v57, v53, 3, 16                                  // 0000009138BC: D6100039 02410735
	v_bfe_u32 v58, v55, 9, 16                                  // 0000009138C4: D610003A 02411337
	v_bfe_u32 v60, v55, 6, 16                                  // 0000009138CC: D610003C 02410D37
	.long 0xd72c0038                                           // 0000009138D4: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v56, vcc_lo              // 0000009138D8: 020270FF 83DCD12D
	v_bfe_u32 v61, v55, 3, 16                                  // 0000009138E0: D610003D 02410737
	.long 0xd72c003e                                           // 0000009138E8: D72C003E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v57, vcc_lo              // 0000009138EC: 020272FF 83DCD12D
	.long 0xd72c0041                                           // 0000009138F4: D72C0041
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 0000009138F8: 020274FF 83DCD12D
	v_sad_u8 v59, v54, 0, 0x6400                               // 000000913900: D622003B 03FD0136 00006400
	v_dot2acc_f32_f16 v29, v66, v12                            // 00000091390C: 043A1942
	.long 0xd72c003c                                           // 000000913910: D72C003C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v60, vcc_lo              // 000000913914: 020278FF 83DCD12D
	.long 0xd72c0044                                           // 00000091391C: D72C0044
	v_cndmask_b32_e32 v1, 0x83dcd12d, v61, vcc_lo              // 000000913920: 02027AFF 83DCD12D
	v_sad_u8 v66, v56, 0, 0x6400                               // 000000913928: D6220042 03FD0138 00006400
	v_and_b32_e32 v64, 0xffff, v59                             // 000000913934: 368076FF 0000FFFF
	ds_load_2addr_b32 v[58:59], v48 offset0:224 offset1:248    // 00000091393C: D8DCF8E0 3A000030
	v_and_b32_e32 v53, 0xffff, v53                             // 000000913944: 366A6AFF 0000FFFF
	v_sad_u8 v67, v62, 0, 0x6400                               // 00000091394C: D6220043 03FD013E 00006400
	ds_load_2addr_b32 v[56:57], v45 offset0:224 offset1:248    // 000000913958: D8DCF8E0 3800002D
	v_sad_u8 v60, v60, 0, 0x6400                               // 000000913960: D622003C 03FD013C 00006400
	v_lshl_or_b32 v64, v66, 16, v64                            // 00000091396C: D6560040 05012142
	.long 0xd72c003f                                           // 000000913974: D72C003F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v53, vcc_lo              // 000000913978: 02026AFF 83DCD12D
	ds_load_2addr_b32 v[53:54], v46 offset0:224 offset1:248    // 000000913980: D8DCF8E0 3500002E
	v_sad_u8 v62, v63, 0, 0x6400                               // 000000913988: D622003E 03FD013F 00006400
	v_sad_u8 v63, v65, 0, 0x6400                               // 000000913994: D622003F 03FD0141 00006400
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000009139A0: BF870091
	v_and_b32_e32 v63, 0xffff, v63                             // 0000009139A4: 367E7EFF 0000FFFF
	v_lshl_or_b32 v60, v60, 16, v63                            // 0000009139AC: D656003C 04FD213C
	v_pk_fma_f16 v63, v64, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009139B4: CC0E003F 0BFC0B40 0000C931
	v_and_b32_e32 v55, 0xffff, v55                             // 0000009139C0: 366E6EFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3)                            // 0000009139C8: BF870003
	v_pk_fma_f16 v64, v60, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009139CC: CC0E0040 0BFC0B3C 0000C931
	v_lshlrev_b32_e32 v65, 16, v62                             // 0000009139D8: 30827C90
	ds_load_2addr_b32 v[61:62], v47 offset0:224 offset1:248    // 0000009139DC: D8DCF8E0 3D00002F
	v_dot2acc_f32_f16 v30, v63, v5                             // 0000009139E4: 043C0B3F
	.long 0xd72c0037                                           // 0000009139E8: D72C0037
	v_cndmask_b32_e32 v1, 0x83dcd12d, v55, vcc_lo              // 0000009139EC: 02026EFF 83DCD12D
	s_waitcnt lgkmcnt(3)                                       // 0000009139F4: BF89FC37
	v_mov_b32_e32 v60, v58                                     // 0000009139F8: 7E78033A
	v_and_or_b32 v65, 0xffff, v67, v65                         // 0000009139FC: D6570041 050686FF 0000FFFF
	v_dot2acc_f32_f16 v31, v63, v9                             // 000000913A08: 043E133F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000913A0C: BF870094
	v_sad_u8 v66, v55, 0, 0x6400                               // 000000913A10: D6220042 03FD0137 00006400
	v_lshlrev_b32_e32 v66, 16, v66                             // 000000913A1C: 30848490
	s_waitcnt lgkmcnt(0)                                       // 000000913A20: BF89FC07
	.long 0xd73d003c                                           // 000000913A24: D73D003C
	v_cndmask_b32_e32 v1, v39, v60, vcc_lo                     // 000000913A28: 02027927
	v_mov_b32_e32 v55, v53                                     // 000000913A2C: 7E6E0335
	v_sad_u8 v53, v68, 0, 0x6400                               // 000000913A30: D6220035 03FD0144 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000913A3C: BF870113
	v_bfe_u32 v67, v60, 6, 16                                  // 000000913A40: D6100043 02410D3C
	v_and_or_b32 v53, 0xffff, v53, v66                         // 000000913A48: D6570035 050A6AFF 0000FFFF
	v_bfe_u32 v66, v60, 9, 16                                  // 000000913A54: D6100042 0241133C
	v_bfe_u32 v68, v60, 3, 16                                  // 000000913A5C: D6100044 0241073C
	v_and_b32_e32 v60, 0xffff, v60                             // 000000913A64: 367878FF 0000FFFF
	.long 0xd73d0037                                           // 000000913A6C: D73D0037
	v_cndmask_b32_e32 v1, v38, v55, vcc_lo                     // 000000913A70: 02026F26
	v_pk_fma_f16 v56, v65, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000913A74: CC0E0038 0BFC0B41 0000C931
	v_pk_fma_f16 v65, v53, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000913A80: CC0E0041 0BFC0B35 0000C931
	.long 0xd72c0042                                           // 000000913A8C: D72C0042
	v_cndmask_b32_e32 v1, 0x83dcd12d, v66, vcc_lo              // 000000913A90: 020284FF 83DCD12D
	.long 0xd72c0043                                           // 000000913A98: D72C0043
	v_cndmask_b32_e32 v1, 0x83dcd12d, v67, vcc_lo              // 000000913A9C: 020286FF 83DCD12D
	.long 0xd72c003c                                           // 000000913AA4: D72C003C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v60, vcc_lo              // 000000913AA8: 020278FF 83DCD12D
	v_bfe_u32 v58, v55, 9, 16                                  // 000000913AB0: D610003A 02411337
	v_bfe_u32 v61, v55, 6, 16                                  // 000000913AB8: D610003D 02410D37
	v_dot2acc_f32_f16 v30, v56, v6                             // 000000913AC0: 043C0D38
	v_dot2acc_f32_f16 v31, v56, v10                            // 000000913AC4: 043E1538
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000913AC8: BF870214
	.long 0xd72c003a                                           // 000000913ACC: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 000000913AD0: 020274FF 83DCD12D
	.long 0xd72c003d                                           // 000000913AD8: D72C003D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v61, vcc_lo              // 000000913ADC: 02027AFF 83DCD12D
	v_sad_u8 v66, v66, 0, 0x6400                               // 000000913AE4: D6220042 03FD0142 00006400
	v_dot2acc_f32_f16 v30, v64, v7                             // 000000913AF0: 043C0F40
	v_sad_u8 v60, v60, 0, 0x6400                               // 000000913AF4: D622003C 03FD013C 00006400
	v_dot2acc_f32_f16 v31, v64, v11                            // 000000913B00: 043E1740
	v_sad_u8 v58, v58, 0, 0x6400                               // 000000913B04: D622003A 03FD013A 00006400
	v_sad_u8 v61, v61, 0, 0x6400                               // 000000913B10: D622003D 03FD013D 00006400
	v_dot2acc_f32_f16 v30, v65, v8                             // 000000913B1C: 043C1141
	v_lshlrev_b32_e32 v60, 16, v60                             // 000000913B20: 30787890
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000913B24: BF870094
	v_and_b32_e32 v58, 0xffff, v58                             // 000000913B28: 367474FF 0000FFFF
	v_lshl_or_b32 v58, v61, 16, v58                            // 000000913B30: D656003A 04E9213D
	v_and_b32_e32 v61, 0xffff, v66                             // 000000913B38: 367A84FF 0000FFFF
	v_sad_u8 v66, v67, 0, 0x6400                               // 000000913B40: D6220042 03FD0143 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000913B4C: BF8701B3
	v_pk_fma_f16 v58, v58, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000913B50: CC0E003A 0BFC0B3A 0000C931
	v_and_b32_e32 v53, 0xffff, v55                             // 000000913B5C: 366A6EFF 0000FFFF
	v_bfe_u32 v55, v55, 3, 16                                  // 000000913B64: D6100037 02410737
	v_dot2acc_f32_f16 v24, v58, v5                             // 000000913B6C: 04300B3A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000913B70: BF870193
	.long 0xd72c0035                                           // 000000913B74: D72C0035
	v_cndmask_b32_e32 v1, 0x83dcd12d, v53, vcc_lo              // 000000913B78: 02026AFF 83DCD12D
	.long 0xd72c0037                                           // 000000913B80: D72C0037
	v_cndmask_b32_e32 v1, 0x83dcd12d, v55, vcc_lo              // 000000913B84: 02026EFF 83DCD12D
	v_dot2acc_f32_f16 v32, v58, v9                             // 000000913B8C: 0440133A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000913B90: BF870193
	v_sad_u8 v53, v53, 0, 0x6400                               // 000000913B94: D6220035 03FD0135 00006400
	v_sad_u8 v55, v55, 0, 0x6400                               // 000000913BA0: D6220037 03FD0137 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000913BAC: BF870092
	v_lshlrev_b32_e32 v53, 16, v53                             // 000000913BB0: 306A6A90
	v_and_or_b32 v53, 0xffff, v55, v53                         // 000000913BB4: D6570035 04D66EFF 0000FFFF
	.long 0xd72c0037                                           // 000000913BC0: D72C0037
	v_cndmask_b32_e32 v1, 0x83dcd12d, v68, vcc_lo              // 000000913BC4: 020288FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000913BCC: BF8701A2
	v_pk_fma_f16 v63, v53, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000913BD0: CC0E003F 0BFC0B35 0000C931
	v_lshl_or_b32 v53, v66, 16, v61                            // 000000913BDC: D6560035 04F52142
	v_sad_u8 v61, v55, 0, 0x6400                               // 000000913BE4: D622003D 03FD0137 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000913BF0: BF870193
	v_dot2acc_f32_f16 v24, v63, v6                             // 000000913BF4: 04300D3F
	v_pk_fma_f16 v66, v53, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000913BF8: CC0E0042 0BFC0B35 0000C931
	v_mov_b32_e32 v55, v57                                     // 000000913C04: 7E6E0339
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000913C08: BF870224
	v_and_or_b32 v56, 0xffff, v61, v60                         // 000000913C0C: D6570038 04F27AFF 0000FFFF
	v_mov_b32_e32 v60, v62                                     // 000000913C18: 7E78033E
	v_dot2acc_f32_f16 v24, v66, v7                             // 000000913C1C: 04300F42
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000913C20: BF870244
	.long 0xd73d0035                                           // 000000913C24: D73D0035
	v_cndmask_b32_e32 v1, v38, v54, vcc_lo                     // 000000913C28: 02026D26
	v_dot2acc_f32_f16 v31, v65, v12                            // 000000913C2C: 043E1941
	v_pk_fma_f16 v64, v56, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000913C30: CC0E0040 0BFC0B38 0000C931
	.long 0xd73d0036                                           // 000000913C3C: D73D0036
	v_cndmask_b32_e32 v1, v39, v59, vcc_lo                     // 000000913C40: 02027727
	v_bfe_u32 v56, v53, 9, 16                                  // 000000913C44: D6100038 02411335
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000913C4C: BF870193
	v_dual_dot2acc_f32_f16 v24, v64, v8 :: v_dual_and_b32 v57, 0xffff, v53// 000000913C50: CB241140 18386AFF 0000FFFF
	v_bfe_u32 v58, v54, 9, 16                                  // 000000913C5C: D610003A 02411336
	v_bfe_u32 v59, v54, 6, 16                                  // 000000913C64: D610003B 02410D36
	s_delay_alu instid0(VALU_DEP_4)                            // 000000913C6C: BF870004
	.long 0xd72c0037                                           // 000000913C70: D72C0037
	v_cndmask_b32_e32 v1, 0x83dcd12d, v56, vcc_lo              // 000000913C74: 020270FF 83DCD12D
	v_bfe_u32 v56, v53, 6, 16                                  // 000000913C7C: D6100038 02410D35
	v_bfe_u32 v53, v53, 3, 16                                  // 000000913C84: D6100035 02410735
	.long 0xd72c0039                                           // 000000913C8C: D72C0039
	v_cndmask_b32_e32 v1, 0x83dcd12d, v57, vcc_lo              // 000000913C90: 020272FF 83DCD12D
	.long 0xd72c003a                                           // 000000913C98: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 000000913C9C: 020274FF 83DCD12D
	v_bfe_u32 v60, v54, 3, 16                                  // 000000913CA4: D610003C 02410736
	.long 0xd72c0038                                           // 000000913CAC: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v56, vcc_lo              // 000000913CB0: 020270FF 83DCD12D
	.long 0xd72c0035                                           // 000000913CB8: D72C0035
	v_cndmask_b32_e32 v1, 0x83dcd12d, v53, vcc_lo              // 000000913CBC: 02026AFF 83DCD12D
	v_sad_u8 v55, v55, 0, 0x6400                               // 000000913CC4: D6220037 03FD0137 00006400
	v_dot2acc_f32_f16 v32, v63, v10                            // 000000913CD0: 0440153F
	.long 0xd72c0041                                           // 000000913CD4: D72C0041
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 000000913CD8: 020276FF 83DCD12D
	v_sad_u8 v57, v57, 0, 0x6400                               // 000000913CE0: D6220039 03FD0139 00006400
	v_sad_u8 v58, v58, 0, 0x6400                               // 000000913CEC: D622003A 03FD013A 00006400
	v_and_b32_e32 v55, 0xffff, v55                             // 000000913CF8: 366E6EFF 0000FFFF
	v_sad_u8 v56, v56, 0, 0x6400                               // 000000913D00: D6220038 03FD0138 00006400
	v_sad_u8 v62, v53, 0, 0x6400                               // 000000913D0C: D622003E 03FD0135 00006400
	.long 0xd72c003c                                           // 000000913D18: D72C003C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v60, vcc_lo              // 000000913D1C: 020278FF 83DCD12D
	v_dot2acc_f32_f16 v32, v66, v11                            // 000000913D24: 04401742
	v_sad_u8 v65, v65, 0, 0x6400                               // 000000913D28: D6220041 03FD0141 00006400
	v_lshl_or_b32 v55, v56, 16, v55                            // 000000913D34: D6560037 04DD2138
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000913D3C: BF870113
	v_dot2acc_f32_f16 v32, v64, v12                            // 000000913D40: 04401940
	v_pk_fma_f16 v55, v55, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000913D44: CC0E0037 0BFC0B37 0000C931
	v_and_b32_e32 v61, 0xffff, v54                             // 000000913D50: 367A6CFF 0000FFFF
	ds_load_2addr_b32 v[53:54], v50 offset0:16 offset1:40      // 000000913D58: D8DC2810 35000032
	v_sad_u8 v60, v60, 0, 0x6400                               // 000000913D60: D622003C 03FD013C 00006400
	v_dot2acc_f32_f16 v34, v55, v9                             // 000000913D6C: 04441337
	v_lshlrev_b32_e32 v63, 16, v57                             // 000000913D70: 307E7290
	ds_load_2addr_b32 v[56:57], v49 offset0:16 offset1:40      // 000000913D74: D8DC2810 38000031
	.long 0xd72c003d                                           // 000000913D7C: D72C003D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v61, vcc_lo              // 000000913D80: 02027AFF 83DCD12D
	v_and_or_b32 v62, 0xffff, v62, v63                         // 000000913D88: D657003E 04FE7CFF 0000FFFF
	v_and_b32_e32 v63, 0xffff, v58                             // 000000913D94: 367E74FF 0000FFFF
	ds_load_2addr_b32 v[58:59], v52 offset0:16 offset1:40      // 000000913D9C: D8DC2810 3A000034
	v_pk_fma_f16 v68, v62, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000913DA4: CC0E0044 0BFC0B3E 0000C931
	v_sad_u8 v67, v61, 0, 0x6400                               // 000000913DB0: D6220043 03FD013D 00006400
	v_lshl_or_b32 v63, v65, 16, v63                            // 000000913DBC: D656003F 04FD2141
	ds_load_2addr_b32 v[61:62], v51 offset0:16 offset1:40      // 000000913DC4: D8DC2810 3D000033
	v_dual_dot2acc_f32_f16 v34, v68, v10 :: v_dual_dot2acc_f32_f16 v33, v55, v5// 000000913DCC: CB181544 22200B37
	s_waitcnt lgkmcnt(3)                                       // 000000913DD4: BF89FC37
	v_mov_b32_e32 v55, v53                                     // 000000913DD8: 7E6E0335
	v_lshlrev_b32_e32 v65, 16, v67                             // 000000913DDC: 30828690
	v_pk_fma_f16 v53, v63, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000913DE0: CC0E0035 0BFC0B3F 0000C931
	s_waitcnt lgkmcnt(2)                                       // 000000913DEC: BF89FC27
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000913DF0: BF870193
	.long 0xd73d0037                                           // 000000913DF4: D73D0037
	v_cndmask_b32_e32 v1, v38, v55, vcc_lo                     // 000000913DF8: 02026F26
	v_and_or_b32 v60, 0xffff, v60, v65                         // 000000913DFC: D657003C 050678FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000913E08: BF870113
	v_dual_dot2acc_f32_f16 v34, v53, v11 :: v_dual_dot2acc_f32_f16 v33, v68, v6// 000000913E0C: CB181735 22200D44
	v_pk_fma_f16 v56, v60, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000913E14: CC0E0038 0BFC0B3C 0000C931
	s_waitcnt lgkmcnt(1)                                       // 000000913E20: BF89FC17
	v_mov_b32_e32 v60, v58                                     // 000000913E24: 7E78033A
	v_and_b32_e32 v58, 0xffff, v55                             // 000000913E28: 36746EFF 0000FFFF
	v_dot2acc_f32_f16 v33, v53, v7                             // 000000913E30: 04420F35
	v_bfe_u32 v53, v55, 9, 16                                  // 000000913E34: D6100035 02411337
	v_dot2acc_f32_f16 v34, v56, v12                            // 000000913E3C: 04441938
	s_waitcnt lgkmcnt(0)                                       // 000000913E40: BF89FC07
	.long 0xd73d003c                                           // 000000913E44: D73D003C
	v_cndmask_b32_e32 v1, v39, v60, vcc_lo                     // 000000913E48: 02027927
	.long 0xd72c003a                                           // 000000913E4C: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 000000913E50: 020274FF 83DCD12D
	.long 0xd72c0035                                           // 000000913E58: D72C0035
	v_cndmask_b32_e32 v1, 0x83dcd12d, v53, vcc_lo              // 000000913E5C: 02026AFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3)                            // 000000913E64: BF870003
	v_bfe_u32 v61, v60, 9, 16                                  // 000000913E68: D610003D 0241133C
	v_and_b32_e32 v64, 0xffff, v60                             // 000000913E70: 368078FF 0000FFFF
	v_bfe_u32 v63, v60, 6, 16                                  // 000000913E78: D610003F 02410D3C
	v_sad_u8 v58, v58, 0, 0x6400                               // 000000913E80: D622003A 03FD013A 00006400
	v_dot2acc_f32_f16 v33, v56, v8                             // 000000913E8C: 04421138
	v_bfe_u32 v56, v55, 6, 16                                  // 000000913E90: D6100038 02410D37
	v_bfe_u32 v55, v55, 3, 16                                  // 000000913E98: D6100037 02410737
	.long 0xd72c003d                                           // 000000913EA0: D72C003D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v61, vcc_lo              // 000000913EA4: 02027AFF 83DCD12D
	v_lshlrev_b32_e32 v58, 16, v58                             // 000000913EAC: 30747490
	v_sad_u8 v53, v53, 0, 0x6400                               // 000000913EB0: D6220035 03FD0135 00006400
	.long 0xd72c0038                                           // 000000913EBC: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v56, vcc_lo              // 000000913EC0: 020270FF 83DCD12D
	.long 0xd72c0037                                           // 000000913EC8: D72C0037
	v_cndmask_b32_e32 v1, 0x83dcd12d, v55, vcc_lo              // 000000913ECC: 02026EFF 83DCD12D
	v_bfe_u32 v60, v60, 3, 16                                  // 000000913ED4: D610003C 0241073C
	.long 0xd72c003f                                           // 000000913EDC: D72C003F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v63, vcc_lo              // 000000913EE0: 02027EFF 83DCD12D
	v_and_b32_e32 v53, 0xffff, v53                             // 000000913EE8: 366A6AFF 0000FFFF
	v_sad_u8 v61, v61, 0, 0x6400                               // 000000913EF0: D622003D 03FD013D 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000913EFC: BF8701C4
	.long 0xd72c003c                                           // 000000913F00: D72C003C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v60, vcc_lo              // 000000913F04: 020278FF 83DCD12D
	v_sad_u8 v56, v56, 0, 0x6400                               // 000000913F0C: D6220038 03FD0138 00006400
	v_sad_u8 v55, v55, 0, 0x6400                               // 000000913F18: D6220037 03FD0137 00006400
	v_sad_u8 v63, v63, 0, 0x6400                               // 000000913F24: D622003F 03FD013F 00006400
	v_lshl_or_b32 v53, v56, 16, v53                            // 000000913F30: D6560035 04D52138
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000913F38: BF870243
	v_and_or_b32 v58, 0xffff, v55, v58                         // 000000913F3C: D657003A 04EA6EFF 0000FFFF
	v_mov_b32_e32 v55, v57                                     // 000000913F48: 7E6E0339
	.long 0xd72c0040                                           // 000000913F4C: D72C0040
	v_cndmask_b32_e32 v1, 0x83dcd12d, v64, vcc_lo              // 000000913F50: 020280FF 83DCD12D
	v_sad_u8 v57, v60, 0, 0x6400                               // 000000913F58: D6220039 03FD013C 00006400
	v_pk_fma_f16 v58, v58, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000913F64: CC0E003A 0BFC0B3A 0000C931
	v_and_b32_e32 v56, 0xffff, v61                             // 000000913F70: 36707AFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000913F78: BF870094
	v_sad_u8 v61, v64, 0, 0x6400                               // 000000913F7C: D622003D 03FD0140 00006400
	v_lshlrev_b32_e32 v60, 16, v61                             // 000000913F88: 30787A90
	v_pk_fma_f16 v61, v53, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000913F8C: CC0E003D 0BFC0B35 0000C931
	.long 0xd73d0035                                           // 000000913F98: D73D0035
	v_cndmask_b32_e32 v1, v38, v54, vcc_lo                     // 000000913F9C: 02026D26
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000913FA0: BF870092
	v_dot2acc_f32_f16 v35, v61, v5                             // 000000913FA4: 04460B3D
	v_dual_dot2acc_f32_f16 v36, v61, v9 :: v_dual_dot2acc_f32_f16 v35, v58, v6// 000000913FA8: CB18133D 24220D3A
	v_lshl_or_b32 v56, v63, 16, v56                            // 000000913FB0: D6560038 04E1213F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000913FB8: BF870112
	v_dual_dot2acc_f32_f16 v36, v58, v10 :: v_dual_and_b32 v63, 0xffff, v53// 000000913FBC: CB24153A 243E6AFF 0000FFFF
	v_pk_fma_f16 v56, v56, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000913FC8: CC0E0038 0BFC0B38 0000C931
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 000000913FD4: BF870251
	v_dot2acc_f32_f16 v35, v56, v7                             // 000000913FD8: 04460F38
	v_and_or_b32 v54, 0xffff, v57, v60                         // 000000913FDC: D6570036 04F272FF 0000FFFF
	v_mov_b32_e32 v60, v62                                     // 000000913FE8: 7E78033E
	v_bfe_u32 v57, v53, 9, 16                                  // 000000913FEC: D6100039 02411335
	v_dot2acc_f32_f16 v36, v56, v11                            // 000000913FF4: 04481738
	v_pk_fma_f16 v62, v54, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000913FF8: CC0E003E 0BFC0B36 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000914004: BF870214
	.long 0xd73d0036                                           // 000000914008: D73D0036
	v_cndmask_b32_e32 v1, v39, v59, vcc_lo                     // 00000091400C: 02027727
	.long 0xd72c0037                                           // 000000914010: D72C0037
	v_cndmask_b32_e32 v1, 0x83dcd12d, v57, vcc_lo              // 000000914014: 020272FF 83DCD12D
	v_bfe_u32 v57, v53, 6, 16                                  // 00000091401C: D6100039 02410D35
	v_bfe_u32 v53, v53, 3, 16                                  // 000000914024: D6100035 02410735
	.long 0xd72c003b                                           // 00000091402C: D72C003B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v63, vcc_lo              // 000000914030: 02027EFF 83DCD12D
	v_dot2acc_f32_f16 v36, v62, v12                            // 000000914038: 0448193E
	v_bfe_u32 v60, v54, 9, 16                                  // 00000091403C: D610003C 02411336
	.long 0xd72c0039                                           // 000000914044: D72C0039
	v_cndmask_b32_e32 v1, 0x83dcd12d, v57, vcc_lo              // 000000914048: 020272FF 83DCD12D
	v_bfe_u32 v63, v54, 6, 16                                  // 000000914050: D610003F 02410D36
	v_sad_u8 v55, v55, 0, 0x6400                               // 000000914058: D6220037 03FD0137 00006400
	.long 0xd72c0035                                           // 000000914064: D72C0035
	v_cndmask_b32_e32 v1, 0x83dcd12d, v53, vcc_lo              // 000000914068: 02026AFF 83DCD12D
	v_bfe_u32 v64, v54, 3, 16                                  // 000000914070: D6100040 02410736
	.long 0xd72c003c                                           // 000000914078: D72C003C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v60, vcc_lo              // 00000091407C: 020278FF 83DCD12D
	v_and_b32_e32 v54, 0xffff, v54                             // 000000914084: 366C6CFF 0000FFFF
	v_and_b32_e32 v55, 0xffff, v55                             // 00000091408C: 366E6EFF 0000FFFF
	v_sad_u8 v57, v57, 0, 0x6400                               // 000000914094: D6220039 03FD0139 00006400
	v_sad_u8 v59, v59, 0, 0x6400                               // 0000009140A0: D622003B 03FD013B 00006400
	.long 0xd72c003f                                           // 0000009140AC: D72C003F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v63, vcc_lo              // 0000009140B0: 02027EFF 83DCD12D
	.long 0xd72c0036                                           // 0000009140B8: D72C0036
	v_cndmask_b32_e32 v1, 0x83dcd12d, v54, vcc_lo              // 0000009140BC: 02026CFF 83DCD12D
	v_sad_u8 v53, v53, 0, 0x6400                               // 0000009140C4: D6220035 03FD0135 00006400
	v_lshl_or_b32 v55, v57, 16, v55                            // 0000009140D0: D6560037 04DD2139
	v_lshlrev_b32_e32 v59, 16, v59                             // 0000009140D8: 30767690
	v_sad_u8 v60, v60, 0, 0x6400                               // 0000009140DC: D622003C 03FD013C 00006400
	.long 0xd72c0039                                           // 0000009140E8: D72C0039
	v_cndmask_b32_e32 v1, 0x83dcd12d, v64, vcc_lo              // 0000009140EC: 020280FF 83DCD12D
	v_dot2acc_f32_f16 v35, v62, v8                             // 0000009140F4: 0446113E
	v_pk_fma_f16 v55, v55, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009140F8: CC0E0037 0BFC0B37 0000C931
	v_and_or_b32 v53, 0xffff, v53, v59                         // 000000914104: D6570035 04EE6AFF 0000FFFF
	v_and_b32_e32 v59, 0xffff, v60                             // 000000914110: 367678FF 0000FFFF
	v_sad_u8 v60, v63, 0, 0x6400                               // 000000914118: D622003C 03FD013F 00006400
	v_sad_u8 v54, v54, 0, 0x6400                               // 000000914124: D6220036 03FD0136 00006400
	v_dot2acc_f32_f16 v17, v55, v9                             // 000000914130: 04221337
	v_pk_fma_f16 v53, v53, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000914134: CC0E0035 0BFC0B35 0000C931
	v_dot2acc_f32_f16 v37, v55, v5                             // 000000914140: 044A0B37
	v_lshl_or_b32 v59, v60, 16, v59                            // 000000914144: D656003B 04ED213C
	v_lshlrev_b32_e32 v54, 16, v54                             // 00000091414C: 306C6C90
	v_sad_u8 v57, v57, 0, 0x6400                               // 000000914150: D6220039 03FD0139 00006400
	v_dot2acc_f32_f16 v17, v53, v10                            // 00000091415C: 04221535
	v_dot2acc_f32_f16 v37, v53, v6                             // 000000914160: 044A0D35
	v_pk_fma_f16 v5, v59, s5, 0xc931 op_sel_hi:[1,0,0]         // 000000914164: CC0E0005 0BFC0B3B 0000C931
	v_add_nc_u32_e32 v42, 1, v42                               // 000000914170: 4A545481
	v_and_or_b32 v9, 0xffff, v57, v54                          // 000000914174: D6570009 04DA72FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000914180: BF870223
	v_dot2acc_f32_f16 v37, v5, v7                              // 000000914184: 044A0F05
	v_dot2acc_f32_f16 v17, v5, v11                             // 000000914188: 04221705
	v_add_nc_u32_e32 v5, v41, v42                              // 00000091418C: 4A0A5529
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000914190: BF870114
	v_pk_fma_f16 v6, v9, s5, 0xc931 op_sel_hi:[1,0,0]          // 000000914194: CC0E0006 0BFC0B09 0000C931
	v_cmp_eq_u32_e32 vcc_lo, 6, v5                             // 0000009141A0: 7C940A86
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000009141A4: BF8704B2
	v_dot2acc_f32_f16 v37, v6, v8                              // 0000009141A8: 044A1106
	v_dot2acc_f32_f16 v17, v6, v12                             // 0000009141AC: 04221906
	s_or_b32 s2, vcc_lo, s2                                    // 0000009141B0: 8C02026A
	s_and_not1_b32 exec_lo, exec_lo, s2                        // 0000009141B4: 917E027E
	s_cbranch_execz 27                                         // 0000009141B8: BFA5001B <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi2ELi4EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0x3d28>
	s_mov_b32 s0, exec_lo                                      // 0000009141BC: BE80007E
	s_waitcnt vmcnt(4)                                         // 0000009141C0: BF8913F7
	ds_store_2addr_b32 v43, v18, v19 offset0:128 offset1:160   // 0000009141C4: D838A080 0013122B
	s_waitcnt vmcnt(2)                                         // 0000009141CC: BF890BF7
	ds_store_2addr_b32 v43, v20, v21 offset0:192 offset1:224   // 0000009141D0: D838E0C0 0015142B
	s_waitcnt vmcnt(0)                                         // 0000009141D8: BF8903F7
	ds_store_2addr_b32 v44, v22, v23 offset1:32                // 0000009141DC: D8382000 0017162C
	.long 0xd4c9007e                                           // 0000009141E4: D4C9007E
	v_cndmask_b32_e32 v1, v42, v16, vcc_lo                     // 0000009141E8: 0202212A
	s_cbranch_execz 64567                                      // 0000009141EC: BFA5FC37 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi2ELi4EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0x2dcc>
	s_clause 0x5                                               // 0000009141F0: BF850005
	global_load_b32 v18, v[1:2], off                           // 0000009141F4: DC520000 127C0001
	global_load_b32 v19, v[1:2], off offset:128                // 0000009141FC: DC520080 137C0001
	global_load_b32 v20, v[1:2], off offset:256                // 000000914204: DC520100 147C0001
	global_load_b32 v21, v[1:2], off offset:384                // 00000091420C: DC520180 157C0001
	global_load_b32 v22, v[1:2], off offset:512                // 000000914214: DC520200 167C0001
	global_load_b32 v23, v[1:2], off offset:640                // 00000091421C: DC520280 177C0001
	s_branch 64553                                             // 000000914224: BFA0FC29 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi2ELi4EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0x2dcc>
	s_or_b32 exec_lo, exec_lo, s2                              // 000000914228: 8C7E027E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000091422C: BF870099
	s_or_b32 exec_lo, exec_lo, s1                              // 000000914230: 8C7E017E
	v_dual_mov_b32 v1, v15 :: v_dual_mov_b32 v8, v29           // 000000914234: CA10010F 0108011D
	v_dual_mov_b32 v2, v27 :: v_dual_mov_b32 v5, v28           // 00000091423C: CA10011B 0204011C
	v_dual_mov_b32 v6, v26 :: v_dual_mov_b32 v7, v25           // 000000914244: CA10011A 06060119
	v_dual_mov_b32 v10, v30 :: v_dual_mov_b32 v11, v31         // 00000091424C: CA10011E 0A0A011F
	v_dual_mov_b32 v9, v24 :: v_dual_mov_b32 v16, v33          // 000000914254: CA100118 09100121
	s_waitcnt vmcnt(4)                                         // 00000091425C: BF8913F7
	v_dual_mov_b32 v12, v32 :: v_dual_mov_b32 v19, v35         // 000000914260: CA100120 0C120123
	s_waitcnt vmcnt(2)                                         // 000000914268: BF890BF7
	v_dual_mov_b32 v18, v34 :: v_dual_mov_b32 v21, v37         // 00000091426C: CA100122 12140125
	v_mov_b32_e32 v20, v36                                     // 000000914274: 7E280324
	s_waitcnt vmcnt(1)                                         // 000000914278: BF8907F7
	v_mov_b32_e32 v22, v17                                     // 00000091427C: 7E2C0311
	s_mov_b32 s0, 0x76543210                                   // 000000914280: BE8000FF 76543210
	v_cmp_gt_u32_e32 vcc_lo, 16, v14                           // 000000914288: 7C981C90
	v_permlanex16_b32 v1, v1, s0, 0xfedcba98                   // 00000091428C: D65C0001 03FC0101 FEDCBA98
	v_permlanex16_b32 v2, v2, s0, 0xfedcba98                   // 000000914298: D65C0002 03FC0102 FEDCBA98
	v_permlanex16_b32 v5, v5, s0, 0xfedcba98                   // 0000009142A4: D65C0005 03FC0105 FEDCBA98
	v_permlanex16_b32 v8, v8, s0, 0xfedcba98                   // 0000009142B0: D65C0008 03FC0108 FEDCBA98
	v_permlanex16_b32 v6, v6, s0, 0xfedcba98                   // 0000009142BC: D65C0006 03FC0106 FEDCBA98
	v_permlanex16_b32 v7, v7, s0, 0xfedcba98                   // 0000009142C8: D65C0007 03FC0107 FEDCBA98
	v_permlanex16_b32 v10, v10, s0, 0xfedcba98                 // 0000009142D4: D65C000A 03FC010A FEDCBA98
	v_permlanex16_b32 v11, v11, s0, 0xfedcba98                 // 0000009142E0: D65C000B 03FC010B FEDCBA98
	v_permlanex16_b32 v9, v9, s0, 0xfedcba98                   // 0000009142EC: D65C0009 03FC0109 FEDCBA98
	v_permlanex16_b32 v12, v12, s0, 0xfedcba98                 // 0000009142F8: D65C000C 03FC010C FEDCBA98
	v_permlanex16_b32 v16, v16, s0, 0xfedcba98                 // 000000914304: D65C0010 03FC0110 FEDCBA98
	v_permlanex16_b32 v18, v18, s0, 0xfedcba98                 // 000000914310: D65C0012 03FC0112 FEDCBA98
	v_permlanex16_b32 v19, v19, s0, 0xfedcba98                 // 00000091431C: D65C0013 03FC0113 FEDCBA98
	v_permlanex16_b32 v20, v20, s0, 0xfedcba98                 // 000000914328: D65C0014 03FC0114 FEDCBA98
	v_permlanex16_b32 v21, v21, s0, 0xfedcba98                 // 000000914334: D65C0015 03FC0115 FEDCBA98
	v_permlanex16_b32 v22, v22, s0, 0xfedcba98                 // 000000914340: D65C0016 03FC0116 FEDCBA98
	s_waitcnt vmcnt(0)                                         // 00000091434C: BF8903F7
	s_barrier                                                  // 000000914350: BFBD0000
	buffer_gl0_inv                                             // 000000914354: E0AC0000 00000000
	s_and_saveexec_b32 s0, vcc_lo                              // 00000091435C: BE80206A
	s_cbranch_execz 38                                         // 000000914360: BFA50026 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi2ELi4EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0x3efc>
	v_dual_add_f32 v21, v37, v21 :: v_dual_lshlrev_b32 v14, 2, v14// 000000914364: C9222B25 150E1C82
	v_dual_add_f32 v12, v32, v12 :: v_dual_add_f32 v1, v15, v1 // 00000091436C: C9081920 0C00030F
	v_dual_add_f32 v10, v30, v10 :: v_dual_add_f32 v5, v28, v5 // 000000914374: C908151E 0A040B1C
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 00000091437C: BF870243
	v_lshl_or_b32 v14, v13, 10, v14                            // 000000914380: D656000E 0439150D
	v_dual_add_f32 v8, v29, v8 :: v_dual_add_f32 v9, v24, v9   // 000000914388: C908111D 08081318
	v_add_f32_e32 v2, v27, v2                                  // 000000914390: 0604051B
	v_add_f32_e32 v6, v26, v6                                  // 000000914394: 060C0D1A
	v_dual_add_f32 v7, v25, v7 :: v_dual_add_nc_u32 v14, 0x5000, v14// 000000914398: C9200F19 070E1CFF 00005000
	v_dual_add_f32 v16, v33, v16 :: v_dual_add_f32 v11, v31, v11// 0000009143A4: C9082121 100A171F
	v_dual_add_f32 v17, v17, v22 :: v_dual_add_f32 v20, v36, v20// 0000009143AC: C9082D11 11142924
	v_dual_add_f32 v19, v35, v19 :: v_dual_add_f32 v18, v34, v18// 0000009143B4: C9082723 13122522
	ds_store_2addr_b32 v14, v1, v5 offset1:16                  // 0000009143BC: D8381000 0005010E
	ds_store_2addr_b32 v14, v2, v8 offset0:128 offset1:144     // 0000009143C4: D8389080 0008020E
	ds_store_2addr_b32 v14, v6, v10 offset0:32 offset1:48      // 0000009143CC: D8383020 000A060E
	ds_store_2addr_b32 v14, v7, v11 offset0:160 offset1:176    // 0000009143D4: D838B0A0 000B070E
	ds_store_2addr_b32 v14, v9, v16 offset0:64 offset1:80      // 0000009143DC: D8385040 0010090E
	ds_store_2addr_b32 v14, v12, v18 offset0:192 offset1:208   // 0000009143E4: D838D0C0 00120C0E
	ds_store_2addr_b32 v14, v19, v21 offset0:96 offset1:112    // 0000009143EC: D8387060 0015130E
	ds_store_2addr_b32 v14, v20, v17 offset0:224 offset1:240   // 0000009143F4: D838F0E0 0011140E
	s_or_b32 exec_lo, exec_lo, s0                              // 0000009143FC: 8C7E007E
	v_sub_nc_u32_e32 v1, v4, v3                                // 000000914400: 4C020704
	s_waitcnt lgkmcnt(0)                                       // 000000914404: BF89FC07
	s_barrier                                                  // 000000914408: BFBD0000
	buffer_gl0_inv                                             // 00000091440C: E0AC0000 00000000
	s_mov_b32 s1, exec_lo                                      // 000000914414: BE81007E
	v_min_i32_e32 v1, 2, v1                                    // 000000914418: 22020282
	s_delay_alu instid0(VALU_DEP_1)                            // 00000091441C: BF870001
	.long 0xd4c1007e                                           // 000000914420: D4C1007E
	v_cndmask_b32_e32 v1, v13, v1, vcc_lo                      // 000000914424: 0202030D
	s_cbranch_execz 533                                        // 000000914428: BFA50215 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi2ELi4EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0x4780>
	v_and_b32_e32 v1, 15, v0                                   // 00000091442C: 3602008F
	v_lshlrev_b32_e32 v2, 9, v13                               // 000000914430: 30041A89
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000914434: BF870091
	v_lshl_or_b32 v2, v1, 2, v2                                // 000000914438: D6560002 04090501
	v_add_nc_u32_e32 v12, 0x5000, v2                           // 000000914440: 4A1804FF 00005000
	v_add_nc_u32_e32 v50, 0x5400, v2                           // 000000914448: 4A6404FF 00005400
	v_add_nc_u32_e32 v51, 0x5800, v2                           // 000000914450: 4A6604FF 00005800
	v_add_nc_u32_e32 v52, 0x5c00, v2                           // 000000914458: 4A6804FF 00005C00
	v_add_nc_u32_e32 v53, 0x6000, v2                           // 000000914460: 4A6A04FF 00006000
	v_add_nc_u32_e32 v54, 0x6400, v2                           // 000000914468: 4A6C04FF 00006400
	v_add_nc_u32_e32 v55, 0x6800, v2                           // 000000914470: 4A6E04FF 00006800
	v_add_nc_u32_e32 v2, 0x6c00, v2                            // 000000914478: 4A0404FF 00006C00
	ds_load_2addr_b32 v[4:5], v12 offset1:16                   // 000000914480: D8DC1000 0400000C
	ds_load_2addr_b32 v[6:7], v50 offset1:16                   // 000000914488: D8DC1000 06000032
	ds_load_2addr_b32 v[8:9], v51 offset1:16                   // 000000914490: D8DC1000 08000033
	ds_load_2addr_b32 v[10:11], v52 offset1:16                 // 000000914498: D8DC1000 0A000034
	ds_load_2addr_b32 v[14:15], v12 offset0:32 offset1:48      // 0000009144A0: D8DC3020 0E00000C
	ds_load_2addr_b32 v[16:17], v53 offset1:16                 // 0000009144A8: D8DC1000 10000035
	ds_load_2addr_b32 v[18:19], v54 offset1:16                 // 0000009144B0: D8DC1000 12000036
	ds_load_2addr_b32 v[20:21], v55 offset1:16                 // 0000009144B8: D8DC1000 14000037
	ds_load_2addr_b32 v[22:23], v2 offset1:16                  // 0000009144C0: D8DC1000 16000002
	ds_load_2addr_b32 v[24:25], v50 offset0:32 offset1:48      // 0000009144C8: D8DC3020 18000032
	ds_load_2addr_b32 v[26:27], v51 offset0:32 offset1:48      // 0000009144D0: D8DC3020 1A000033
	ds_load_2addr_b32 v[28:29], v52 offset0:32 offset1:48      // 0000009144D8: D8DC3020 1C000034
	ds_load_2addr_b32 v[30:31], v53 offset0:32 offset1:48      // 0000009144E0: D8DC3020 1E000035
	ds_load_2addr_b32 v[32:33], v54 offset0:32 offset1:48      // 0000009144E8: D8DC3020 20000036
	ds_load_2addr_b32 v[34:35], v55 offset0:32 offset1:48      // 0000009144F0: D8DC3020 22000037
	ds_load_2addr_b32 v[36:37], v2 offset0:32 offset1:48       // 0000009144F8: D8DC3020 24000002
	ds_load_2addr_b32 v[38:39], v12 offset0:64 offset1:80      // 000000914500: D8DC5040 2600000C
	ds_load_2addr_b32 v[40:41], v50 offset0:64 offset1:80      // 000000914508: D8DC5040 28000032
	ds_load_2addr_b32 v[42:43], v51 offset0:64 offset1:80      // 000000914510: D8DC5040 2A000033
	ds_load_2addr_b32 v[44:45], v52 offset0:64 offset1:80      // 000000914518: D8DC5040 2C000034
	ds_load_2addr_b32 v[46:47], v53 offset0:64 offset1:80      // 000000914520: D8DC5040 2E000035
	ds_load_2addr_b32 v[48:49], v12 offset0:96 offset1:112     // 000000914528: D8DC7060 3000000C
	s_waitcnt lgkmcnt(21)                                      // 000000914530: BF89FD57
	v_add_f32_e32 v56, 0, v5                                   // 000000914534: 06700A80
	v_add_f32_e32 v12, 0, v4                                   // 000000914538: 06180880
	s_waitcnt lgkmcnt(20)                                      // 00000091453C: BF89FD47
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000914540: BF8700A2
	v_add_f32_e32 v56, v56, v7                                 // 000000914544: 06700F38
	s_waitcnt lgkmcnt(19)                                      // 000000914548: BF89FD37
	v_add_f32_e32 v9, v56, v9                                  // 00000091454C: 06121338
	s_waitcnt lgkmcnt(18)                                      // 000000914550: BF89FD27
	s_delay_alu instid0(VALU_DEP_1)                            // 000000914554: BF870001
	v_add_f32_e32 v9, v9, v11                                  // 000000914558: 06121709
	s_waitcnt lgkmcnt(5)                                       // 00000091455C: BF89FC57
	v_add_f32_e32 v11, 0, v39                                  // 000000914560: 06164E80
	ds_load_2addr_b32 v[4:5], v50 offset0:96 offset1:112       // 000000914564: D8DC7060 04000032
	ds_load_2addr_b32 v[50:51], v51 offset0:96 offset1:112     // 00000091456C: D8DC7060 32000033
	v_dual_add_f32 v9, v9, v17 :: v_dual_add_f32 v14, 0, v14   // 000000914574: C9082309 090E1C80
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000091457C: BF870111
	v_dual_add_f32 v9, v9, v19 :: v_dual_add_f32 v12, v12, v6  // 000000914580: C9082709 090C0D0C
	v_add_f32_e32 v14, v14, v24                                // 000000914588: 061C310E
	ds_load_2addr_b32 v[6:7], v52 offset0:96 offset1:112       // 00000091458C: D8DC7060 06000034
	ds_load_2addr_b32 v[52:53], v53 offset0:96 offset1:112     // 000000914594: D8DC7060 34000035
	v_dual_add_f32 v9, v9, v21 :: v_dual_add_f32 v8, v12, v8   // 00000091459C: C9082B09 0908110C
	v_add_f32_e32 v12, v14, v26                                // 0000009145A4: 0618350E
	v_dual_add_f32 v14, 0, v15 :: v_dual_add_f32 v15, 0, v38   // 0000009145A8: C9081E80 0E0E4C80
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000009145B0: BF870123
	v_add_f32_e32 v23, v9, v23                                 // 0000009145B4: 062E2F09
	s_waitcnt lgkmcnt(8)                                       // 0000009145B8: BF89FC87
	v_add_f32_e32 v15, v15, v40                                // 0000009145BC: 061E510F
	s_waitcnt lgkmcnt(7)                                       // 0000009145C0: BF89FC77
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000009145C4: BF8700A1
	v_add_f32_e32 v15, v15, v42                                // 0000009145C8: 061E550F
	s_waitcnt lgkmcnt(6)                                       // 0000009145CC: BF89FC67
	v_dual_add_f32 v8, v8, v10 :: v_dual_add_f32 v21, v15, v44 // 0000009145D0: C9081508 0814590F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000009145D8: BF870121
	v_dual_add_f32 v8, v8, v16 :: v_dual_add_f32 v15, v11, v41 // 0000009145DC: C9082108 080E530B
	v_add_f32_e32 v14, v14, v25                                // 0000009145E4: 061C330E
	v_add_f32_e32 v8, v8, v18                                  // 0000009145E8: 06102508
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009145EC: BF870193
	v_add_f32_e32 v18, v15, v43                                // 0000009145F0: 0624570F
	v_add_f32_e32 v14, v14, v27                                // 0000009145F4: 061C370E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009145F8: BF870193
	v_add_f32_e32 v8, v8, v20                                  // 0000009145FC: 06102908
	v_add_f32_e32 v26, v18, v45                                // 000000914600: 06345B12
	s_delay_alu instid0(VALU_DEP_3)                            // 000000914604: BF870003
	v_add_f32_e32 v20, v14, v29                                // 000000914608: 06283B0E
	s_waitcnt lgkmcnt(4)                                       // 00000091460C: BF89FC47
	v_add_f32_e32 v14, 0, v49                                  // 000000914610: 061C6280
	ds_load_2addr_b32 v[18:19], v2 offset0:96 offset1:112      // 000000914614: D8DC7060 12000002
	v_add_f32_e32 v22, v8, v22                                 // 00000091461C: 062C2D08
	ds_load_2addr_b32 v[8:9], v54 offset0:64 offset1:80        // 000000914620: D8DC5040 08000036
	s_waitcnt lgkmcnt(5)                                       // 000000914628: BF89FC57
	v_add_f32_e32 v16, v14, v5                                 // 00000091462C: 06200B0E
	ds_load_2addr_b32 v[14:15], v55 offset0:96 offset1:112     // 000000914630: D8DC7060 0E000037
	s_waitcnt lgkmcnt(5)                                       // 000000914638: BF89FC57
	v_add_f32_e32 v25, v16, v51                                // 00000091463C: 06326710
	ds_load_2addr_b32 v[16:17], v2 offset0:64 offset1:80       // 000000914640: D8DC5040 10000002
	s_waitcnt lgkmcnt(5)                                       // 000000914648: BF89FC57
	v_add_f32_e32 v2, v25, v7                                  // 00000091464C: 06040F19
	v_add_f32_e32 v7, v20, v31                                 // 000000914650: 060E3F14
	v_add_f32_e32 v10, v12, v28                                // 000000914654: 0614390C
	v_add_f32_e32 v20, v26, v47                                // 000000914658: 06285F1A
	v_add_f32_e32 v12, 0, v48                                  // 00000091465C: 06186080
	s_waitcnt lgkmcnt(4)                                       // 000000914660: BF89FC47
	v_add_f32_e32 v2, v2, v53                                  // 000000914664: 06046B02
	v_add_f32_e32 v7, v7, v33                                  // 000000914668: 060E4307
	s_waitcnt lgkmcnt(2)                                       // 00000091466C: BF89FC27
	v_add_f32_e32 v9, v20, v9                                  // 000000914670: 06121314
	v_add_f32_e32 v12, v12, v4                                 // 000000914674: 0618090C
	ds_load_2addr_b32 v[4:5], v55 offset0:64 offset1:80        // 000000914678: D8DC5040 04000037
	v_dual_add_f32 v10, v10, v30 :: v_dual_add_f32 v7, v7, v35 // 000000914680: C9083D0A 0A064707
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000914688: BF870091
	v_dual_add_f32 v12, v12, v50 :: v_dual_add_f32 v7, v7, v37 // 00000091468C: C908650C 0C064B07
	v_add_f32_e32 v6, v12, v6                                  // 000000914694: 060C0D0C
	v_add_f32_e32 v12, v21, v46                                // 000000914698: 06185D15
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000091469C: BF870122
	v_add_f32_e32 v6, v6, v52                                  // 0000009146A0: 060C6906
	s_waitcnt lgkmcnt(0)                                       // 0000009146A4: BF89FC07
	v_dual_add_f32 v8, v12, v8 :: v_dual_add_f32 v5, v9, v5    // 0000009146A8: C908110C 08040B09
	v_add_f32_e32 v10, v10, v32                                // 0000009146B0: 0614410A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000009146B4: BF870112
	v_dual_add_f32 v4, v8, v4 :: v_dual_sub_f32 v9, v22, v23   // 0000009146B8: C90A0908 04082F16
	v_dual_add_f32 v5, v5, v17 :: v_dual_add_f32 v10, v10, v34 // 0000009146C0: C9082305 050A450A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000009146C8: BF8701A2
	v_add_f32_e32 v4, v4, v16                                  // 0000009146CC: 06082104
	v_and_b32_e32 v16, 1, v0                                   // 0000009146D0: 36200081
	v_add_f32_e32 v24, v10, v36                                // 0000009146D4: 0630490A
	ds_load_2addr_b32 v[10:11], v54 offset0:96 offset1:112     // 0000009146D8: D8DC7060 0A000036
	.long 0xd44a0000                                           // 0000009146E0: D44A0000
	v_cndmask_b32_e32 v1, 0, v16, vcc_lo                       // 0000009146E4: 02022080
	s_waitcnt lgkmcnt(0)                                       // 0000009146E8: BF89FC07
	v_add_f32_e32 v6, v6, v10                                  // 0000009146EC: 060C1506
	v_dual_add_f32 v2, v2, v11 :: v_dual_add_f32 v11, v4, v5   // 0000009146F0: C9081702 020A0B04
	v_sub_f32_e32 v4, v4, v5                                   // 0000009146F8: 08080B04
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009146FC: BF870193
	v_add_f32_e32 v6, v6, v14                                  // 000000914700: 060C1D06
	v_add_f32_e32 v2, v2, v15                                  // 000000914704: 06041F02
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000914708: BF870112
	v_add_f32_e32 v6, v6, v18                                  // 00000091470C: 060C2506
	v_add_f32_e32 v2, v2, v19                                  // 000000914710: 06042702
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000914714: BF8700A1
	v_add_f32_e32 v12, v6, v2                                  // 000000914718: 06180506
	v_sub_f32_e32 v2, v6, v2                                   // 00000091471C: 08040506
	v_dual_add_f32 v6, v11, v12 :: v_dual_add_f32 v15, v4, v2  // 000000914720: C908190B 060E0504
	v_add_f32_e32 v10, v24, v7                                 // 000000914728: 06140F18
	v_sub_f32_e32 v7, v24, v7                                  // 00000091472C: 080E0F18
	v_dual_sub_f32 v11, v11, v12 :: v_dual_sub_f32 v2, v4, v2  // 000000914730: C94A190B 0B020504
	v_and_b32_e32 v4, 2, v0                                    // 000000914738: 36080082
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000091473C: BF870233
	v_add_f32_e32 v14, v9, v7                                  // 000000914740: 061C0F09
	v_sub_f32_e32 v9, v9, v7                                   // 000000914744: 08120F09
	v_add_f32_e32 v8, v22, v23                                 // 000000914748: 06102F16
	.long 0xd44a0001                                           // 00000091474C: D44A0001
	v_cndmask_b32_e32 v1, 0, v4, vcc_lo                        // 000000914750: 02020880
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000914754: BF870194
	v_add_f32_e32 v7, v14, v15                                 // 000000914758: 060E1F0E
	v_add_f32_e32 v5, v8, v10                                  // 00000091475C: 060A1508
	v_sub_f32_e32 v8, v8, v10                                  // 000000914760: 08101508
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000914764: BF870223
	v_mov_b32_dpp v16, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000914768: 7E2002FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, s0                          // 000000914770: D5010007 20020F07
	v_add_f32_e32 v10, v5, v6                                  // 000000914778: 06140D05
	v_sub_f32_e32 v6, v5, v6                                   // 00000091477C: 080C0D05
	v_add_f32_e32 v4, v8, v11                                  // 000000914780: 06081708
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000914784: BF870214
	v_dual_sub_f32 v8, v8, v11 :: v_dual_add_f32 v7, v7, v16   // 000000914788: C9481708 08062107
	v_mov_b32_dpp v12, v10 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000914790: 7E1802FA FF01610A
	v_cndmask_b32_e64 v10, -v10, v10, s0                       // 000000914798: D501000A 2002150A
	v_and_b32_e32 v11, 4, v0                                   // 0000009147A0: 36160084
	s_delay_alu instid0(VALU_DEP_2)                            // 0000009147A4: BF870002
	v_add_f32_e32 v5, v10, v12                                 // 0000009147A8: 060A190A
	v_sub_f32_e32 v10, v14, v15                                // 0000009147AC: 08141F0E
	v_mov_b32_dpp v14, v7 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009147B0: 7E1C02FA FF016207
	v_cndmask_b32_e64 v7, -v7, v7, s1                          // 0000009147B8: D5010007 20060F07
	v_add_f32_e32 v15, v9, v2                                  // 0000009147C0: 061E0509
	v_mov_b32_dpp v12, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009147C4: 7E1802FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, s1                          // 0000009147CC: D5010005 20060B05
	.long 0xd44a0002                                           // 0000009147D4: D44A0002
	v_cndmask_b32_e32 v1, 0, v11, vcc_lo                       // 0000009147D8: 02021680
	v_add_f32_e32 v7, v7, v14                                  // 0000009147DC: 060E1D07
	v_cndmask_b32_e64 v14, -v15, v15, s0                       // 0000009147E0: D501000E 20021F0F
	v_sub_f32_e32 v9, v9, v2                                   // 0000009147E8: 08120509
	v_add_f32_e32 v5, v5, v12                                  // 0000009147EC: 060A1905
	v_mov_b32_dpp v12, v15 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009147F0: 7E1802FA FF01610F
	v_mov_b32_dpp v15, v4 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009147F8: 7E1E02FA FF016104
	v_cndmask_b32_e64 v4, -v4, v4, s0                          // 000000914800: D5010004 20020904
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000914808: BF870214
	v_mov_b32_dpp v11, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000091480C: 7E1602FA FF016405
	v_add_f32_e32 v12, v14, v12                                // 000000914814: 0618190E
	v_cndmask_b32_e64 v5, -v5, v5, s2                          // 000000914818: D5010005 200A0B05
	s_delay_alu instid0(VALU_DEP_4)                            // 000000914820: BF870004
	v_add_f32_e32 v4, v4, v15                                  // 000000914824: 06081F04
	v_mov_b32_dpp v14, v7 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000914828: 7E1C02FA FF016407
	v_cndmask_b32_e64 v7, -v7, v7, s2                          // 000000914830: D5010007 200A0F07
	v_mov_b32_dpp v15, v12 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000914838: 7E1E02FA FF01620C
	v_cndmask_b32_e64 v12, -v12, v12, s1                       // 000000914840: D501000C 2006190C
	v_mov_b32_dpp v16, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000914848: 7E2002FA FF016204
	v_cndmask_b32_e64 v17, -v4, v4, s1                         // 000000914850: D5010011 20060904
	v_dual_add_f32 v4, v5, v11 :: v_dual_add_f32 v7, v7, v14   // 000000914858: C9081705 04061D07
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000914860: BF8701B2
	v_dual_add_f32 v11, v12, v15 :: v_dual_add_f32 v12, v17, v16// 000000914864: C9081F0C 0B0C2111
	v_mov_b32_dpp v16, v6 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000091486C: 7E2002FA FF016106
	v_cndmask_b32_e64 v17, -v6, v6, s0                         // 000000914874: D5010011 20020D06
	v_mov_b32_dpp v14, v11 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000091487C: 7E1C02FA FF01640B
	v_cndmask_b32_e64 v11, -v11, v11, s2                       // 000000914884: D501000B 200A170B
	v_mov_b32_dpp v15, v12 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000091488C: 7E1E02FA FF01640C
	v_cndmask_b32_e64 v12, -v12, v12, s2                       // 000000914894: D501000C 200A190C
	v_mov_b32_dpp v2, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000091489C: 7E0402FA FF016804
	v_mov_b32_dpp v5, v7 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009148A4: 7E0A02FA FF016807
	v_add_f32_e32 v6, v11, v14                                 // 0000009148AC: 060C1D0B
	v_mov_b32_dpp v11, v10 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009148B0: 7E1602FA FF01610A
	v_cndmask_b32_e64 v10, -v10, v10, s0                       // 0000009148B8: D501000A 2002150A
	v_add_f32_e32 v14, v17, v16                                // 0000009148C0: 061C2111
	v_mov_b32_dpp v16, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009148C4: 7E2002FA FF016108
	v_cndmask_b32_e64 v8, -v8, v8, s0                          // 0000009148CC: D5010008 20021108
	v_mov_b32_dpp v17, v9 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009148D4: 7E2202FA FF016109
	v_cndmask_b32_e64 v9, -v9, v9, s0                          // 0000009148DC: D5010009 20021309
	v_add_f32_e32 v10, v10, v11                                // 0000009148E4: 0614170A
	v_mov_b32_dpp v11, v14 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009148E8: 7E1602FA FF01620E
	v_cndmask_b32_e64 v14, -v14, v14, s1                       // 0000009148F0: D501000E 20061D0E
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009148F8: BF870214
	v_dual_add_f32 v8, v8, v16 :: v_dual_add_f32 v9, v9, v17   // 0000009148FC: C9082108 08082309
	v_mov_b32_dpp v16, v10 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000914904: 7E2002FA FF01620A
	v_cndmask_b32_e64 v10, -v10, v10, s1                       // 00000091490C: D501000A 2006150A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000914914: BF870214
	v_add_f32_e32 v11, v14, v11                                // 000000914918: 0616170E
	v_mov_b32_dpp v14, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000091491C: 7E1C02FA FF016208
	v_mov_b32_dpp v17, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000914924: 7E2202FA FF016209
	v_cndmask_b32_e64 v18, -v8, v8, s1                         // 00000091492C: D5010012 20061108
	v_cndmask_b32_e64 v9, -v9, v9, s1                          // 000000914934: D5010009 20061309
	v_add_f32_e32 v10, v10, v16                                // 00000091493C: 0614210A
	v_add_f32_e32 v8, v12, v15                                 // 000000914940: 06101F0C
	v_mov_b32_dpp v12, v11 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000914944: 7E1802FA FF01640B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000091494C: BF870214
	v_dual_add_f32 v14, v18, v14 :: v_dual_add_f32 v9, v9, v17 // 000000914950: C9081D12 0E082309
	v_mov_b32_dpp v15, v10 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000914958: 7E1E02FA FF01640A
	v_cndmask_b32_e64 v10, -v10, v10, s2                       // 000000914960: D501000A 200A150A
	v_cndmask_b32_e64 v11, -v11, v11, s2                       // 000000914968: D501000B 200A170B
	s_delay_alu instid0(VALU_DEP_4)                            // 000000914970: BF870004
	v_mov_b32_dpp v17, v14 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000914974: 7E2202FA FF01640E
	v_mov_b32_dpp v19, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000091497C: 7E2602FA FF016409
	v_cndmask_b32_e64 v14, -v14, v14, s2                       // 000000914984: D501000E 200A1D0E
	v_cndmask_b32_e64 v20, -v9, v9, s2                         // 00000091498C: D5010014 200A1309
	v_add_f32_e32 v16, v11, v12                                // 000000914994: 0620190B
	v_add_f32_e32 v18, v10, v15                                // 000000914998: 06241F0A
	v_mov_b32_dpp v9, v8 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000091499C: 7E1202FA FF016808
	v_add_f32_e32 v17, v14, v17                                // 0000009149A4: 0622230E
	v_add_f32_e32 v19, v20, v19                                // 0000009149A8: 06262714
	v_mov_b32_dpp v10, v6 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009149AC: 7E1402FA FF016806
	v_mov_b32_dpp v11, v16 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009149B4: 7E1602FA FF016810
	v_mov_b32_dpp v12, v18 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009149BC: 7E1802FA FF016812
	v_mov_b32_dpp v14, v17 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009149C4: 7E1C02FA FF016811
	v_mov_b32_dpp v15, v19 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009149CC: 7E1E02FA FF016813
	s_and_b32 exec_lo, exec_lo, vcc_lo                         // 0000009149D4: 8B7E6A7E
	s_cbranch_execz 169                                        // 0000009149D8: BFA500A9 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi2ELi4EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0x4780>
	v_lshlrev_b32_e32 v20, 1, v1                               // 0000009149DC: 30280281
	v_add_nc_u32_e32 v1, v3, v13                               // 0000009149E0: 4A021B03
	v_and_b32_e32 v3, 8, v0                                    // 0000009149E4: 36060088
	s_mul_i32 s0, s4, 0x1400                                   // 0000009149E8: 9600FF04 00001400
	s_mul_hi_i32 s1, s4, 0x1400                                // 0000009149F0: 9701FF04 00001400
	s_add_u32 s2, s20, s0                                      // 0000009149F8: 80020014
	s_addc_u32 s4, s21, s1                                     // 0000009149FC: 82040115
	v_cmp_eq_u32_e32 vcc_lo, 0, v3                             // 000000914A00: 7C940680
	s_lshl_b32 s0, s3, 7                                       // 000000914A04: 84008703
	.long 0x7f1a3880                                           // 000000914A08: 7F1A3880
	s_ashr_i32 s1, s0, 31                                      // 000000914A0C: 86019F00
	v_cndmask_b32_e64 v3, -v7, v7, vcc_lo                      // 000000914A10: D5010003 21AA0F07
	s_lshl_b64 s[0:1], s[0:1], 1                               // 000000914A18: 84808100
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 000000914A1C: D5010004 21AA0904
	v_cndmask_b32_e64 v16, -v16, v16, vcc_lo                   // 000000914A24: D5010010 21AA2110
	s_add_u32 s2, s2, s0                                       // 000000914A2C: 80020002
	v_add_f32_e32 v3, v3, v5                                   // 000000914A30: 06060B03
	v_cndmask_b32_e64 v5, -v6, v6, vcc_lo                      // 000000914A34: D5010005 21AA0D06
	v_cndmask_b32_e64 v6, -v8, v8, vcc_lo                      // 000000914A3C: D5010006 21AA1108
	s_addc_u32 s3, s4, s1                                      // 000000914A44: 82030104
	v_add_f32_e32 v2, v4, v2                                   // 000000914A48: 06040504
	v_cndmask_b32_e64 v17, -v17, v17, vcc_lo                   // 000000914A4C: D5010011 21AA2311
	v_cndmask_b32_e64 v8, -v18, v18, vcc_lo                    // 000000914A54: D5010008 21AA2512
	v_add_f32_e32 v4, v6, v9                                   // 000000914A5C: 06081306
	v_add_f32_e32 v6, v16, v11                                 // 000000914A60: 060C1710
	v_mul_f32_e32 v3, 0x3db504f3, v3                           // 000000914A64: 100606FF 3DB504F3
	s_clause 0x7                                               // 000000914A6C: BF850007
	global_load_d16_b16 v21, v20, s[2:3] offset:32             // 000000914A70: DC820020 15020014
	global_load_d16_b16 v22, v20, s[2:3]                       // 000000914A78: DC820000 16020014
	global_load_d16_b16 v23, v20, s[2:3] offset:64             // 000000914A80: DC820040 17020014
	global_load_d16_b16 v24, v20, s[2:3] offset:96             // 000000914A88: DC820060 18020014
	global_load_d16_b16 v25, v20, s[2:3] offset:128            // 000000914A90: DC820080 19020014
	global_load_d16_b16 v26, v20, s[2:3] offset:160            // 000000914A98: DC8200A0 1A020014
	global_load_d16_b16 v27, v20, s[2:3] offset:192            // 000000914AA0: DC8200C0 1B020014
	global_load_d16_b16 v28, v20, s[2:3] offset:224            // 000000914AA8: DC8200E0 1C020014
	v_cndmask_b32_e64 v18, -v19, v19, vcc_lo                   // 000000914AB0: D5010012 21AA2713
	v_dual_add_f32 v5, v5, v10 :: v_dual_add_f32 v8, v8, v12   // 000000914AB8: C9081505 05081908
	v_add_f32_e32 v9, v17, v14                                 // 000000914AC0: 06121D11
	v_mul_f32_e32 v2, 0x3db504f3, v2                           // 000000914AC4: 100404FF 3DB504F3
	s_waitcnt vmcnt(7)                                         // 000000914ACC: BF891FF7
	.long 0x7f2a398d                                           // 000000914AD0: 7F2A398D
	v_dual_add_f32 v10, v18, v15 :: v_dual_mul_f32 v5, 0x3db504f3, v5// 000000914AD4: C9061F12 0A040AFF 3DB504F3
	v_dual_mul_f32 v4, 0x3db504f3, v4 :: v_dual_mul_f32 v9, 0x3db504f3, v9// 000000914AE0: C8C608FF 040812FF 3DB504F3
	s_waitcnt vmcnt(6)                                         // 000000914AEC: BF891BF7
	.long 0x7f2c398d                                           // 000000914AF0: 7F2C398D
	.long 0x7f0e398d                                           // 000000914AF4: 7F0E398D
	v_mad_i64_i32 v[0:1], null, 0x1400, v1, s[22:23]           // 000000914AF8: D6FF7C00 005A02FF 00001400
	s_waitcnt vmcnt(5)                                         // 000000914B04: BF8917F7
	.long 0x7f2e398d                                           // 000000914B08: 7F2E398D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000914B0C: BF870092
	.long 0xd7006a00                                           // 000000914B10: D7006A00
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 000000914B14: 02000100
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 000000914B18: D5207C01 01AA0201
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000914B20: BF870092
	.long 0xd7006a00                                           // 000000914B24: D7006A00
	v_cndmask_b32_e32 v1, v0, v20, vcc_lo                      // 000000914B28: 02022900
	v_add_co_ci_u32_e64 v1, null, 0, v1, vcc_lo                // 000000914B2C: D5207C01 01AA0280
	v_fma_mix_f32 v3, v21, v3, neg(0) op_sel_hi:[1,0,0]        // 000000914B34: CC200003 8A020715
	v_fma_mix_f32 v2, v22, v2, neg(0) op_sel_hi:[1,0,0]        // 000000914B3C: CC200002 8A020516
	v_fma_mix_f32 v4, v23, v4, neg(0) op_sel_hi:[1,0,0]        // 000000914B44: CC200004 8A020917
	s_waitcnt vmcnt(4)                                         // 000000914B4C: BF8913F7
	v_fma_mix_f32 v5, v24, v5, neg(0) op_sel_hi:[1,0,0]        // 000000914B50: CC200005 8A020B18
	.long 0x7e1a3983                                           // 000000914B58: 7E1A3983
	v_mul_f32_e32 v8, 0x3db504f3, v8                           // 000000914B5C: 101010FF 3DB504F3
	s_waitcnt vmcnt(1)                                         // 000000914B64: BF8907F7
	v_fma_mix_f32 v9, v27, v9, neg(0) op_sel_hi:[1,0,0]        // 000000914B68: CC200009 8A02131B
	.long 0x7e0e3982                                           // 000000914B70: 7E0E3982
	v_dual_mul_f32 v6, 0x3db504f3, v6 :: v_dual_and_b32 v11, 1, v13// 000000914B74: C8E40CFF 060A1A81 3DB504F3
	v_fma_mix_f32 v8, v26, v8, neg(0) op_sel_hi:[1,0,0]        // 000000914B80: CC200008 8A02111A
	.long 0x7e1a3985                                           // 000000914B88: 7E1A3985
	.long 0x7e2e3989                                           // 000000914B8C: 7E2E3989
	v_dual_mul_f32 v10, 0x3db504f3, v10 :: v_dual_and_b32 v7, 1, v7// 000000914B90: C8E414FF 0A060E81 3DB504F3
	v_fma_mix_f32 v6, v25, v6, neg(0) op_sel_hi:[1,0,0]        // 000000914B9C: CC200006 8A020D19
	s_delay_alu instid0(VALU_DEP_4)                            // 000000914BA4: BF870004
	v_and_b32_e32 v12, 1, v13                                  // 000000914BA8: 36181A81
	.long 0x7e1a3988                                           // 000000914BAC: 7E1A3988
	v_and_b32_e32 v17, 1, v23                                  // 000000914BB0: 36222E81
	s_waitcnt vmcnt(0)                                         // 000000914BB4: BF8903F7
	v_fma_mix_f32 v10, v28, v10, neg(0) op_sel_hi:[1,0,0]      // 000000914BB8: CC20000A 8A02151C
	.long 0x7e2a3984                                           // 000000914BC0: 7E2A3984
	.long 0x7e2c3986                                           // 000000914BC4: 7E2C3986
	v_and_b32_e32 v16, 1, v13                                  // 000000914BC8: 36201A81
	v_add3_u32 v2, v2, v7, 0x7fff                              // 000000914BCC: D6550002 03FE0F02 00007FFF
	.long 0x7e1a398a                                           // 000000914BD8: 7E1A398A
	v_and_b32_e32 v14, 1, v21                                  // 000000914BDC: 361C2A81
	v_and_b32_e32 v15, 1, v22                                  // 000000914BE0: 361E2C81
	v_add3_u32 v3, v3, v11, 0x7fff                             // 000000914BE4: D6550003 03FE1703 00007FFF
	v_add3_u32 v5, v5, v12, 0x7fff                             // 000000914BF0: D6550005 03FE1905 00007FFF
	v_and_b32_e32 v7, 1, v13                                   // 000000914BFC: 360E1A81
	v_add3_u32 v4, v4, v14, 0x7fff                             // 000000914C00: D6550004 03FE1D04 00007FFF
	v_add3_u32 v6, v6, v15, 0x7fff                             // 000000914C0C: D6550006 03FE1F06 00007FFF
	v_add3_u32 v9, v9, v17, 0x7fff                             // 000000914C18: D6550009 03FE2309 00007FFF
	v_add3_u32 v8, v8, v16, 0x7fff                             // 000000914C24: D6550008 03FE2108 00007FFF
	v_add3_u32 v7, v10, v7, 0x7fff                             // 000000914C30: D6550007 03FE0F0A 00007FFF
	s_clause 0x7                                               // 000000914C3C: BF850007
	global_store_d16_hi_b16 v[0:1], v2, off                    // 000000914C40: DC960000 007C0200
	global_store_d16_hi_b16 v[0:1], v3, off offset:32          // 000000914C48: DC960020 007C0300
	global_store_d16_hi_b16 v[0:1], v4, off offset:64          // 000000914C50: DC960040 007C0400
	global_store_d16_hi_b16 v[0:1], v5, off offset:96          // 000000914C58: DC960060 007C0500
	global_store_d16_hi_b16 v[0:1], v6, off offset:128         // 000000914C60: DC960080 007C0600
	global_store_d16_hi_b16 v[0:1], v8, off offset:160         // 000000914C68: DC9600A0 007C0800
	global_store_d16_hi_b16 v[0:1], v9, off offset:192         // 000000914C70: DC9600C0 007C0900
	global_store_d16_hi_b16 v[0:1], v7, off offset:224         // 000000914C78: DC9600E0 007C0700
	s_nop 0                                                    // 000000914C80: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 000000914C84: BFB60003
	s_endpgm                                                   // 000000914C88: BFB00000
	s_branch 63637                                             // 000000914C8C: BFA0F895 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi2ELi4EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0x29e4>
		...

