0000000000856000 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[8:23], s[0:1], null                          // 000000856000: F4100200 F8000000
	s_ashr_i32 s3, s2, 31                                      // 000000856008: 86039F02
	v_lshrrev_b32_e32 v2, 2, v0                                // 00000085600C: 32040082
	s_lshl_b64 s[2:3], s[2:3], 3                               // 000000856010: 84828302
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000856014: BF8701A9
	v_dual_mov_b32 v24, s3 :: v_dual_and_b32 v1, 15, v0        // 000000856018: CA240003 1800008F
	v_and_b32_e32 v30, 31, v0                                  // 000000856020: 363C009F
	v_and_b32_e32 v2, 60, v2                                   // 000000856024: 360404BC
	v_lshlrev_b32_e32 v7, 2, v0                                // 000000856028: 300E0082
	s_delay_alu instid0(VALU_DEP_4)                            // 00000085602C: BF870004
	v_lshlrev_b32_e32 v1, 2, v1                                // 000000856030: 30020282
	.long 0x7f0c3880                                           // 000000856034: 7F0C3880
	s_waitcnt lgkmcnt(0)                                       // 000000856038: BF89FC07
	s_clause 0x1                                               // 00000085603C: BF850001
	global_load_b32 v3, v1, s[8:9]                             // 000000856040: DC520000 03080001
	global_load_b32 v4, v2, s[8:9]                             // 000000856048: DC520000 04080002
	v_lshrrev_b32_e32 v1, 5, v0                                // 000000856050: 32020085
	s_add_u32 s24, s8, s20                                     // 000000856054: 80181408
	s_addc_u32 s25, s9, s21                                    // 000000856058: 82191509
	s_ashr_i32 s4, s15, 31                                     // 00000085605C: 86049F0F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000856060: BF8704A1
	v_or_b32_e32 v23, s2, v1                                   // 000000856064: 382E0202
	s_lshr_b32 s4, s4, 27                                      // 000000856068: 85049B04
	s_add_u32 s4, s14, s4                                      // 00000085606C: 8004040E
	s_addc_u32 s5, s15, 0                                      // 000000856070: 8205800F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000856074: BF8704A1
	.long 0xd4540002                                           // 000000856078: D4540002
	v_cndmask_b32_e32 v1, s16, v23, vcc_lo                     // 00000085607C: 02022E10
	s_lshr_b64 s[6:7], s[4:5], 5                               // 000000856080: 85868504
	s_cmpk_lt_i32 s6, 0x101                                    // 000000856084: B3860101
	.long 0xd4440004                                           // 000000856088: D4440004
	v_cndmask_b32_e32 v1, s6, v30, vcc_lo                      // 00000085608C: 02023C06
	v_cndmask_b32_e64 v2, 0, v23, s2                           // 000000856090: D5010002 000A2E80
	v_cndmask_b32_e64 v5, 0, s3, s2                            // 000000856098: D5010005 00080680
	s_cselect_b32 s3, -1, 0                                    // 0000008560A0: 980380C1
	s_cmpk_gt_i32 s6, 0x100                                    // 0000008560A4: B2860100
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000008560A8: BF8704B2
	.long 0xd72c0008                                           // 0000008560AC: D72C0008
	v_cndmask_b32_e32 v1, s23, v2, vcc_lo                      // 0000008560B0: 02020417
	v_mad_u64_u32 v[0:1], null, s22, v2, 0                     // 0000008560B4: D6FE7C00 02020416
	s_cselect_b32 s7, -1, 0                                    // 0000008560BC: 980780C1
	s_and_b32 vcc_lo, exec_lo, s7                              // 0000008560C0: 8B6A077E
	s_waitcnt vmcnt(1)                                         // 0000008560C4: BF8907F7
	v_bfe_u32 v9, v3, 16, 1                                    // 0000008560C8: D6100009 02052103
	s_waitcnt vmcnt(0)                                         // 0000008560D0: BF8903F7
	v_bfe_u32 v10, v4, 16, 1                                   // 0000008560D4: D610000A 02052104
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008560DC: BF8701A2
	v_add3_u32 v3, v3, v9, 0x7fff                              // 0000008560E0: D6550003 03FE1303 00007FFF
	.long 0xd72c0009                                           // 0000008560EC: D72C0009
	v_cndmask_b32_e32 v1, s22, v5, vcc_lo                      // 0000008560F0: 02020A16
	v_add3_u32 v4, v4, v10, 0x7fff                             // 0000008560F4: D6550004 03FE1504 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000856100: BF870223
	.long 0x7e0c3983                                           // 000000856104: 7E0C3983
	.long 0xd7000503                                           // 000000856108: D7000503
	v_cndmask_b32_e32 v1, s24, v0, vcc_lo                      // 00000085610C: 02020018
	v_add3_u32 v1, v1, v9, v8                                  // 000000856110: D6550001 04221301
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000856118: BF870113
	v_and_or_b32 v6, 0xffff0000, v4, v6                        // 00000085611C: D6570006 041A08FF FFFF0000
	v_add_co_ci_u32_e64 v4, null, s25, v1, s5                  // 000000856128: D5207C04 00160219
	ds_store_b32 v7, v6                                        // 000000856130: D8340000 00000607
	s_waitcnt lgkmcnt(0)                                       // 000000856138: BF89FC07
	s_barrier                                                  // 00000085613C: BFBD0000
	buffer_gl0_inv                                             // 000000856140: E0AC0000 00000000
	s_cbranch_vccnz 146                                        // 000000856148: BFA40092 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x394>
	v_dual_mov_b32 v8, 0 :: v_dual_mov_b32 v7, 0               // 00000085614C: CA100080 08060080
	s_and_saveexec_b32 s5, s4                                  // 000000856154: BE852004
	s_cbranch_execz 10                                         // 000000856158: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x184>
	v_lshlrev_b32_e32 v6, 1, v30                               // 00000085615C: 300C3C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000856160: BF870091
	.long 0xd7006a06                                           // 000000856164: D7006A06
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 000000856168: 02020D03
	v_add_co_ci_u32_e64 v7, null, 0, v4, vcc_lo                // 00000085616C: D5207C07 01AA0880
	global_load_d16_b16 v6, v[6:7], off                        // 000000856174: DC820000 067C0006
	s_waitcnt vmcnt(0)                                         // 00000085617C: BF8903F7
	v_cvt_f32_f16_e32 v7, v6                                   // 000000856180: 7E0E1706
	s_or_b32 exec_lo, exec_lo, s5                              // 000000856184: 8C7E057E
	v_or_b32_e32 v6, 32, v30                                   // 000000856188: 380C3CA0
	s_mov_b32 s4, exec_lo                                      // 00000085618C: BE84007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000856190: BF870001
	.long 0xd4c4007e                                           // 000000856194: D4C4007E
	v_cndmask_b32_e32 v1, s6, v6, vcc_lo                       // 000000856198: 02020C06
	s_cbranch_execz 10                                         // 00000085619C: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x1c8>
	v_lshlrev_b32_e32 v6, 1, v6                                // 0000008561A0: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008561A4: BF870091
	.long 0xd7006a08                                           // 0000008561A8: D7006A08
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 0000008561AC: 02020D03
	v_add_co_ci_u32_e64 v9, null, 0, v4, vcc_lo                // 0000008561B0: D5207C09 01AA0880
	global_load_d16_b16 v6, v[8:9], off                        // 0000008561B8: DC820000 067C0008
	s_waitcnt vmcnt(0)                                         // 0000008561C0: BF8903F7
	v_cvt_f32_f16_e32 v8, v6                                   // 0000008561C4: 7E101706
	s_or_b32 exec_lo, exec_lo, s4                              // 0000008561C8: 8C7E047E
	v_or_b32_e32 v6, 64, v30                                   // 0000008561CC: 380C3CC0
	v_dual_mov_b32 v10, 0 :: v_dual_mov_b32 v9, 0              // 0000008561D0: CA100080 0A080080
	s_mov_b32 s4, exec_lo                                      // 0000008561D8: BE84007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000008561DC: BF870002
	.long 0xd4c4007e                                           // 0000008561E0: D4C4007E
	v_cndmask_b32_e32 v1, s6, v6, vcc_lo                       // 0000008561E4: 02020C06
	s_cbranch_execz 10                                         // 0000008561E8: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x214>
	v_lshlrev_b32_e32 v6, 1, v6                                // 0000008561EC: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008561F0: BF870091
	.long 0xd7006a0b                                           // 0000008561F4: D7006A0B
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 0000008561F8: 02020D03
	v_add_co_ci_u32_e64 v12, null, 0, v4, vcc_lo               // 0000008561FC: D5207C0C 01AA0880
	global_load_d16_b16 v6, v[11:12], off                      // 000000856204: DC820000 067C000B
	s_waitcnt vmcnt(0)                                         // 00000085620C: BF8903F7
	v_cvt_f32_f16_e32 v9, v6                                   // 000000856210: 7E121706
	s_or_b32 exec_lo, exec_lo, s4                              // 000000856214: 8C7E047E
	v_or_b32_e32 v6, 0x60, v30                                 // 000000856218: 380C3CFF 00000060
	s_mov_b32 s4, exec_lo                                      // 000000856220: BE84007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000856224: BF870001
	.long 0xd4c4007e                                           // 000000856228: D4C4007E
	v_cndmask_b32_e32 v1, s6, v6, vcc_lo                       // 00000085622C: 02020C06
	s_cbranch_execz 10                                         // 000000856230: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x25c>
	v_lshlrev_b32_e32 v6, 1, v6                                // 000000856234: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000856238: BF870091
	.long 0xd7006a0a                                           // 00000085623C: D7006A0A
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 000000856240: 02020D03
	v_add_co_ci_u32_e64 v11, null, 0, v4, vcc_lo               // 000000856244: D5207C0B 01AA0880
	global_load_d16_b16 v6, v[10:11], off                      // 00000085624C: DC820000 067C000A
	s_waitcnt vmcnt(0)                                         // 000000856254: BF8903F7
	v_cvt_f32_f16_e32 v10, v6                                  // 000000856258: 7E141706
	s_or_b32 exec_lo, exec_lo, s4                              // 00000085625C: 8C7E047E
	v_or_b32_e32 v6, 0x80, v30                                 // 000000856260: 380C3CFF 00000080
	v_dual_mov_b32 v12, 0 :: v_dual_mov_b32 v11, 0             // 000000856268: CA100080 0C0A0080
	s_mov_b32 s4, exec_lo                                      // 000000856270: BE84007E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000856274: BF870002
	.long 0xd4c4007e                                           // 000000856278: D4C4007E
	v_cndmask_b32_e32 v1, s6, v6, vcc_lo                       // 00000085627C: 02020C06
	s_cbranch_execz 10                                         // 000000856280: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x2ac>
	v_lshlrev_b32_e32 v6, 1, v6                                // 000000856284: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000856288: BF870091
	.long 0xd7006a0d                                           // 00000085628C: D7006A0D
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 000000856290: 02020D03
	v_add_co_ci_u32_e64 v14, null, 0, v4, vcc_lo               // 000000856294: D5207C0E 01AA0880
	global_load_d16_b16 v6, v[13:14], off                      // 00000085629C: DC820000 067C000D
	s_waitcnt vmcnt(0)                                         // 0000008562A4: BF8903F7
	v_cvt_f32_f16_e32 v11, v6                                  // 0000008562A8: 7E161706
	s_or_b32 exec_lo, exec_lo, s4                              // 0000008562AC: 8C7E047E
	v_or_b32_e32 v6, 0xa0, v30                                 // 0000008562B0: 380C3CFF 000000A0
	s_mov_b32 s4, exec_lo                                      // 0000008562B8: BE84007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008562BC: BF870001
	.long 0xd4c4007e                                           // 0000008562C0: D4C4007E
	v_cndmask_b32_e32 v1, s6, v6, vcc_lo                       // 0000008562C4: 02020C06
	s_cbranch_execz 10                                         // 0000008562C8: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x2f4>
	v_lshlrev_b32_e32 v6, 1, v6                                // 0000008562CC: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008562D0: BF870091
	.long 0xd7006a0c                                           // 0000008562D4: D7006A0C
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 0000008562D8: 02020D03
	v_add_co_ci_u32_e64 v13, null, 0, v4, vcc_lo               // 0000008562DC: D5207C0D 01AA0880
	global_load_d16_b16 v6, v[12:13], off                      // 0000008562E4: DC820000 067C000C
	s_waitcnt vmcnt(0)                                         // 0000008562EC: BF8903F7
	v_cvt_f32_f16_e32 v12, v6                                  // 0000008562F0: 7E181706
	s_or_b32 exec_lo, exec_lo, s4                              // 0000008562F4: 8C7E047E
	v_or_b32_e32 v6, 0xc0, v30                                 // 0000008562F8: 380C3CFF 000000C0
	v_dual_mov_b32 v14, 0 :: v_dual_mov_b32 v13, 0             // 000000856300: CA100080 0E0C0080
	s_mov_b32 s4, exec_lo                                      // 000000856308: BE84007E
	s_delay_alu instid0(VALU_DEP_2)                            // 00000085630C: BF870002
	.long 0xd4c4007e                                           // 000000856310: D4C4007E
	v_cndmask_b32_e32 v1, s6, v6, vcc_lo                       // 000000856314: 02020C06
	s_cbranch_execz 10                                         // 000000856318: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x344>
	v_lshlrev_b32_e32 v6, 1, v6                                // 00000085631C: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000856320: BF870091
	.long 0xd7006a0f                                           // 000000856324: D7006A0F
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 000000856328: 02020D03
	v_add_co_ci_u32_e64 v16, null, 0, v4, vcc_lo               // 00000085632C: D5207C10 01AA0880
	global_load_d16_b16 v6, v[15:16], off                      // 000000856334: DC820000 067C000F
	s_waitcnt vmcnt(0)                                         // 00000085633C: BF8903F7
	v_cvt_f32_f16_e32 v13, v6                                  // 000000856340: 7E1A1706
	s_or_b32 exec_lo, exec_lo, s4                              // 000000856344: 8C7E047E
	v_or_b32_e32 v6, 0xe0, v30                                 // 000000856348: 380C3CFF 000000E0
	s_mov_b32 s4, exec_lo                                      // 000000856350: BE84007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000856354: BF870001
	.long 0xd4c4007e                                           // 000000856358: D4C4007E
	v_cndmask_b32_e32 v1, s6, v6, vcc_lo                       // 00000085635C: 02020C06
	s_cbranch_execz 10                                         // 000000856360: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x38c>
	v_lshlrev_b32_e32 v6, 1, v6                                // 000000856364: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000856368: BF870091
	.long 0xd7006a0e                                           // 00000085636C: D7006A0E
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 000000856370: 02020D03
	v_add_co_ci_u32_e64 v15, null, 0, v4, vcc_lo               // 000000856374: D5207C0F 01AA0880
	global_load_d16_b16 v6, v[14:15], off                      // 00000085637C: DC820000 067C000E
	s_waitcnt vmcnt(0)                                         // 000000856384: BF8903F7
	v_cvt_f32_f16_e32 v14, v6                                  // 000000856388: 7E1C1706
	s_or_b32 exec_lo, exec_lo, s4                              // 00000085638C: 8C7E047E
	s_branch 9                                                 // 000000856390: BFA00009 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x3b8>
	v_mov_b32_e32 v7, 0                                        // 000000856394: 7E0E0280
	s_delay_alu instid0(VALU_DEP_1)                            // 000000856398: BF870001
	v_mov_b32_e32 v8, v7                                       // 00000085639C: 7E100307
	v_mov_b32_e32 v9, v7                                       // 0000008563A0: 7E120307
	v_mov_b32_e32 v10, v7                                      // 0000008563A4: 7E140307
	v_mov_b32_e32 v11, v7                                      // 0000008563A8: 7E160307
	v_mov_b32_e32 v12, v7                                      // 0000008563AC: 7E180307
	v_mov_b32_e32 v13, v7                                      // 0000008563B0: 7E1A0307
	v_mov_b32_e32 v14, v7                                      // 0000008563B4: 7E1C0307
	s_add_u32 s4, s8, s18                                      // 0000008563B8: 80041208
	s_addc_u32 s5, s9, s19                                     // 0000008563BC: 82051309
	s_lshr_b32 s18, s15, 31                                    // 0000008563C0: 85129F0F
	v_dual_mov_b32 v19, 0 :: v_dual_mov_b32 v32, 0             // 0000008563C4: CA100080 13200080
	s_add_u32 s18, s14, s18                                    // 0000008563CC: 8012120E
	s_addc_u32 s19, s15, 0                                     // 0000008563D0: 8213800F
	v_cndmask_b32_e64 v31, 0, 1, s7                            // 0000008563D4: D501001F 001D0280
	s_ashr_i64 s[18:19], s[18:19], 1                           // 0000008563DC: 86928112
	v_dual_mov_b32 v42, 0 :: v_dual_mov_b32 v21, 0             // 0000008563E0: CA100080 2A140080
	v_mad_u64_u32 v[25:26], null, v2, s18, s[4:5]              // 0000008563E8: D6FE7C19 00102502
	.long 0xd72c0002                                           // 0000008563F0: D72C0002
	v_cndmask_b32_e32 v0, v2, v19, vcc_lo                      // 0000008563F4: 02002702
	.long 0xd72c0005                                           // 0000008563F8: D72C0005
	v_cndmask_b32_e32 v0, v5, v18, vcc_lo                      // 0000008563FC: 02002505
	.long 0xd4440004                                           // 000000856400: D4440004
	v_cndmask_b32_e32 v1, s6, v30, vcc_lo                      // 000000856404: 02023C06
	v_mov_b32_e32 v20, 0                                       // 000000856408: 7E280280
	v_mov_b32_e32 v22, 0                                       // 00000085640C: 7E2C0280
	s_delay_alu instid0(VALU_DEP_4)                            // 000000856410: BF870004
	v_add3_u32 v33, v5, v26, v2                                // 000000856414: D6550021 040A3505
	s_and_saveexec_b32 s5, s4                                  // 00000085641C: BE852004
	s_cbranch_execz 21                                         // 000000856420: BFA50015 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x478>
	v_lshlrev_b32_e32 v2, 4, v30                               // 000000856424: 30043C84
	v_mov_b32_e32 v42, 0                                       // 000000856428: 7E540280
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000085642C: BF870092
	.long 0xd7006a05                                           // 000000856430: D7006A05
	v_cndmask_b32_e32 v1, v25, v2, vcc_lo                      // 000000856434: 02020519
	v_add_co_ci_u32_e64 v6, null, 0, v33, vcc_lo               // 000000856438: D5207C06 01AA4280
	s_and_not1_b32 vcc_lo, exec_lo, s7                         // 000000856440: 916A077E
	global_load_b128 v[19:22], v[5:6], off                     // 000000856444: DC5E0000 137C0005
	s_cbranch_vccnz 10                                         // 00000085644C: BFA4000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x478>
	v_lshlrev_b32_e32 v2, 1, v30                               // 000000856450: 30043C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000856454: BF870091
	.long 0xd7006a02                                           // 000000856458: D7006A02
	v_cndmask_b32_e32 v1, v3, v2, vcc_lo                       // 00000085645C: 02020503
	v_add_co_ci_u32_e64 v3, null, 0, v4, vcc_lo                // 000000856460: D5207C03 01AA0880
	global_load_d16_b16 v2, v[2:3], off                        // 000000856468: DC820000 027C0002
	s_waitcnt vmcnt(0)                                         // 000000856470: BF8903F7
	v_cvt_f32_f16_e32 v42, v2                                  // 000000856474: 7E541702
	s_or_b32 exec_lo, exec_lo, s5                              // 000000856478: 8C7E057E
	v_dual_mov_b32 v34, 0 :: v_dual_mov_b32 v35, 0             // 00000085647C: CA100080 22220080
	v_dual_mov_b32 v36, 0 :: v_dual_mov_b32 v37, 0             // 000000856484: CA100080 24240080
	v_mov_b32_e32 v38, 0                                       // 00000085648C: 7E4C0280
	s_and_saveexec_b32 s5, s4                                  // 000000856490: BE852004
	s_cbranch_execz 565                                        // 000000856494: BFA50235 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0xd6c>
	v_dual_mov_b32 v27, 0 :: v_dual_lshlrev_b32 v2, 1, v30     // 000000856498: CA220080 1B023C81
	.long 0xd7006a00                                           // 0000008564A0: D7006A00
	v_cndmask_b32_e32 v1, s20, v0, vcc_lo                      // 0000008564A4: 02020014
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008564A8: BF870191
	v_add_co_ci_u32_e64 v1, null, s21, v1, vcc_lo              // 0000008564AC: D5207C01 01AA0215
	v_dual_mov_b32 v37, v27 :: v_dual_lshlrev_b32 v26, 5, v30  // 0000008564B4: CA22011B 251A3C85
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008564BC: BF870093
	.long 0xd7006a00                                           // 0000008564C0: D7006A00
	v_cndmask_b32_e32 v1, v0, v2, vcc_lo                       // 0000008564C4: 02020500
	v_add_co_ci_u32_e64 v1, null, 0, v1, vcc_lo                // 0000008564C8: D5207C01 01AA0280
	v_lshl_or_b32 v39, v30, 4, 0x200                           // 0000008564D0: D6560027 03FD091E 00000200
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008564DC: BF870093
	.long 0xd7006a00                                           // 0000008564E0: D7006A00
	v_cndmask_b32_e32 v1, s8, v0, vcc_lo                       // 0000008564E4: 02020008
	v_add_co_ci_u32_e64 v1, null, s9, v1, vcc_lo               // 0000008564E8: D5207C01 01AA0209
	v_dual_mov_b32 v40, v30 :: v_dual_mov_b32 v35, v27         // 0000008564F0: CA10011E 2822011B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008564F8: BF870093
	.long 0xd7006a1c                                           // 0000008564FC: D7006A1C
	v_cndmask_b32_e32 v0, v0, v192, vcc_lo                     // 000000856500: 02018100
	v_add_co_ci_u32_e64 v29, null, 0, v1, vcc_lo               // 000000856504: D5207C1D 01AA0280
	v_dual_mov_b32 v38, v27 :: v_dual_mov_b32 v41, v42         // 00000085650C: CA10011B 2628012A
	v_mov_b32_e32 v36, v27                                     // 000000856514: 7E48031B
	v_mov_b32_e32 v34, v27                                     // 000000856518: 7E44031B
	v_mov_b32_e32 v32, v27                                     // 00000085651C: 7E40031B
	s_mul_i32 s4, s15, 6                                       // 000000856520: 9604860F
	s_mul_hi_u32 s7, s14, 6                                    // 000000856524: 9687860E
	s_lshl_b64 s[18:19], s[14:15], 2                           // 000000856528: 8492820E
	s_add_i32 s7, s7, s4                                       // 00000085652C: 81070407
	s_mul_i32 s21, s14, 6                                      // 000000856530: 9615860E
	s_mov_b32 s20, 0                                           // 000000856534: BE940080
	s_lshl_b64 s[8:9], s[14:15], 1                             // 000000856538: 8488810E
	s_branch 494                                               // 00000085653C: BFA001EE <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0xcf8>
	s_or_b32 exec_lo, exec_lo, s14                             // 000000856540: 8C7E0E7E
	v_cndmask_b32_e64 v52, v42, v7, s3                         // 000000856544: D5010034 000E0F2A
	v_cndmask_b32_e64 v1, v8, v9, s3                           // 00000085654C: D5010001 000E1308
	v_cndmask_b32_e64 v0, v7, v8, s3                           // 000000856554: D5010000 000E1107
	v_dual_mov_b32 v7, v14 :: v_dual_and_b32 v8, 0xff, v19     // 00000085655C: CA24010E 070826FF 000000FF
	v_cndmask_b32_e64 v6, v13, v14, s3                         // 000000856568: D5010006 000E1D0D
	v_cndmask_b32_e64 v5, v12, v13, s3                         // 000000856570: D5010005 000E1B0C
	v_cndmask_b32_e64 v4, v11, v12, s3                         // 000000856578: D5010004 000E190B
	v_cndmask_b32_e64 v3, v10, v11, s3                         // 000000856580: D5010003 000E170A
	v_lshlrev_b32_e32 v8, 2, v8                                // 000000856588: 30101082
	v_cndmask_b32_e64 v2, v9, v10, s3                          // 00000085658C: D5010002 000E1509
	s_and_b32 s4, exec_lo, s4                                  // 000000856594: 8B04047E
	v_add_nc_u32_e32 v39, 0x200, v39                           // 000000856598: 4A4E4EFF 00000200
	s_or_b32 s20, s4, s20                                      // 0000008565A0: 8C141404
	ds_load_b32 v14, v8                                        // 0000008565A4: D8D80000 0E000008
	v_lshrrev_b32_e32 v8, 6, v19                               // 0000008565AC: 32102686
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008565B0: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 0000008565B4: 361010FF 000003FC
	ds_load_b32 v53, v8                                        // 0000008565BC: D8D80000 35000008
	v_lshrrev_b32_e32 v8, 14, v19                              // 0000008565C4: 3210268E
	v_and_b32_e32 v8, 0x3fc, v8                                // 0000008565C8: 361010FF 000003FC
	ds_load_b32 v54, v8                                        // 0000008565D0: D8D80000 36000008
	v_lshrrev_b32_e32 v8, 22, v19                              // 0000008565D8: 32102696
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008565DC: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 0000008565E0: 361010FF 000003FC
	ds_load_b32 v55, v8                                        // 0000008565E8: D8D80000 37000008
	v_and_b32_e32 v8, 0xff, v20                                // 0000008565F0: 361028FF 000000FF
	v_lshlrev_b32_e32 v8, 2, v8                                // 0000008565F8: 30101082
	ds_load_b32 v56, v8                                        // 0000008565FC: D8D80000 38000008
	v_lshrrev_b32_e32 v8, 6, v20                               // 000000856604: 32102886
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000856608: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 00000085660C: 361010FF 000003FC
	ds_load_b32 v57, v8                                        // 000000856614: D8D80000 39000008
	v_lshrrev_b32_e32 v8, 14, v20                              // 00000085661C: 3210288E
	v_and_b32_e32 v8, 0x3fc, v8                                // 000000856620: 361010FF 000003FC
	ds_load_b32 v58, v8                                        // 000000856628: D8D80000 3A000008
	v_lshrrev_b32_e32 v8, 22, v20                              // 000000856630: 32102896
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000856634: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 000000856638: 361010FF 000003FC
	ds_load_b32 v59, v8                                        // 000000856640: D8D80000 3B000008
	v_and_b32_e32 v8, 0xff, v21                                // 000000856648: 36102AFF 000000FF
	v_lshlrev_b32_e32 v8, 2, v8                                // 000000856650: 30101082
	ds_load_b32 v60, v8                                        // 000000856654: D8D80000 3C000008
	v_lshrrev_b32_e32 v8, 6, v21                               // 00000085665C: 32102A86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000856660: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 000000856664: 361010FF 000003FC
	ds_load_b32 v61, v8                                        // 00000085666C: D8D80000 3D000008
	v_lshrrev_b32_e32 v8, 14, v21                              // 000000856674: 32102A8E
	v_and_b32_e32 v8, 0x3fc, v8                                // 000000856678: 361010FF 000003FC
	ds_load_b32 v62, v8                                        // 000000856680: D8D80000 3E000008
	v_lshrrev_b32_e32 v8, 22, v21                              // 000000856688: 32102A96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000085668C: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 000000856690: 361010FF 000003FC
	ds_load_b32 v63, v8                                        // 000000856698: D8D80000 3F000008
	v_and_b32_e32 v8, 0xff, v22                                // 0000008566A0: 36102CFF 000000FF
	v_lshlrev_b32_e32 v8, 2, v8                                // 0000008566A8: 30101082
	ds_load_b32 v64, v8                                        // 0000008566AC: D8D80000 40000008
	v_lshrrev_b32_e32 v8, 6, v22                               // 0000008566B4: 32102C86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008566B8: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 0000008566BC: 361010FF 000003FC
	ds_load_b32 v65, v8                                        // 0000008566C4: D8D80000 41000008
	v_lshrrev_b32_e32 v8, 14, v22                              // 0000008566CC: 32102C8E
	v_and_b32_e32 v8, 0x3fc, v8                                // 0000008566D0: 361010FF 000003FC
	ds_load_b32 v66, v8                                        // 0000008566D8: D8D80000 42000008
	v_lshrrev_b32_e32 v8, 22, v22                              // 0000008566E0: 32102C96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000008566E4: BF870141
	v_and_b32_e32 v8, 0x3fc, v8                                // 0000008566E8: 361010FF 000003FC
	ds_load_b32 v67, v8                                        // 0000008566F0: D8D80000 43000008
	.long 0xd73c0008                                           // 0000008566F8: D73C0008
	v_cndmask_b32_e32 v1, 1, v26, vcc_lo                       // 0000008566FC: 02023481
	v_add_nc_u32_e32 v26, 0x400, v26                           // 000000856700: 4A3434FF 00000400
	.long 0xd7006a0c                                           // 000000856708: D7006A0C
	v_cndmask_b32_e32 v1, s10, v8, vcc_lo                      // 00000085670C: 0202100A
	s_delay_alu instid0(VALU_DEP_1)                            // 000000856710: BF870001
	v_add_co_ci_u32_e64 v13, null, s11, v9, vcc_lo             // 000000856714: D5207C0D 01AA120B
	s_clause 0x3                                               // 00000085671C: BF850003
	global_load_b128 v[8:11], v[12:13], off                    // 000000856720: DC5E0000 087C000C
	global_load_b128 v[19:22], v[12:13], off offset:16         // 000000856728: DC5E0010 137C000C
	global_load_b128 v[42:45], v[12:13], off offset:32         // 000000856730: DC5E0020 2A7C000C
	global_load_b128 v[46:49], v[12:13], off offset:48         // 000000856738: DC5E0030 2E7C000C
	s_waitcnt vmcnt(3) lgkmcnt(15)                             // 000000856740: BF890CF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 000000856744: CC1A4008 1A021D08
	s_waitcnt lgkmcnt(14)                                      // 00000085674C: BF89FCE7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000856750: BF8700A1
	v_dot2_f32_bf16 v8, v9, v53, v8                            // 000000856754: CC1A4008 1C226B09
	s_waitcnt lgkmcnt(13)                                      // 00000085675C: BF89FCD7
	v_dot2_f32_bf16 v8, v10, v54, v8                           // 000000856760: CC1A4008 1C226D0A
	s_waitcnt lgkmcnt(12)                                      // 000000856768: BF89FCC7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000085676C: BF8700A1
	v_dot2_f32_bf16 v8, v11, v55, v8                           // 000000856770: CC1A4008 1C226F0B
	s_waitcnt vmcnt(2) lgkmcnt(11)                             // 000000856778: BF8908B7
	v_dot2_f32_bf16 v8, v19, v56, v8                           // 00000085677C: CC1A4008 1C227113
	s_waitcnt lgkmcnt(10)                                      // 000000856784: BF89FCA7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000856788: BF8700A1
	v_dot2_f32_bf16 v8, v20, v57, v8                           // 00000085678C: CC1A4008 1C227314
	s_waitcnt lgkmcnt(9)                                       // 000000856794: BF89FC97
	v_dot2_f32_bf16 v8, v21, v58, v8                           // 000000856798: CC1A4008 1C227515
	s_waitcnt lgkmcnt(8)                                       // 0000008567A0: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008567A4: BF8700A1
	v_dot2_f32_bf16 v8, v22, v59, v8                           // 0000008567A8: CC1A4008 1C227716
	s_waitcnt vmcnt(1) lgkmcnt(7)                              // 0000008567B0: BF890477
	v_dot2_f32_bf16 v8, v42, v60, v8                           // 0000008567B4: CC1A4008 1C22792A
	s_waitcnt lgkmcnt(6)                                       // 0000008567BC: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008567C0: BF8700A1
	v_dot2_f32_bf16 v8, v43, v61, v8                           // 0000008567C4: CC1A4008 1C227B2B
	s_waitcnt lgkmcnt(5)                                       // 0000008567CC: BF89FC57
	v_dot2_f32_bf16 v8, v44, v62, v8                           // 0000008567D0: CC1A4008 1C227D2C
	s_waitcnt lgkmcnt(4)                                       // 0000008567D8: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008567DC: BF8700A1
	v_dot2_f32_bf16 v8, v45, v63, v8                           // 0000008567E0: CC1A4008 1C227F2D
	s_waitcnt vmcnt(0) lgkmcnt(3)                              // 0000008567E8: BF890037
	v_dot2_f32_bf16 v8, v46, v64, v8                           // 0000008567EC: CC1A4008 1C22812E
	.long 0xd7006a2e                                           // 0000008567F4: D7006A2E
	v_cndmask_b32_e32 v0, v12, v8, vcc_lo                      // 0000008567F8: 0200110C
	s_waitcnt lgkmcnt(2)                                       // 0000008567FC: BF89FC27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000856800: BF8701C2
	v_dot2_f32_bf16 v8, v47, v65, v8                           // 000000856804: CC1A4008 1C22832F
	v_add_co_ci_u32_e64 v47, null, s9, v13, vcc_lo             // 00000085680C: D5207C2F 01AA1A09
	.long 0xd7006a32                                           // 000000856814: D7006A32
	v_cndmask_b32_e32 v0, v12, v18, vcc_lo                     // 000000856818: 0200250C
	s_waitcnt lgkmcnt(1)                                       // 00000085681C: BF89FC17
	v_dot2_f32_bf16 v8, v48, v66, v8                           // 000000856820: CC1A4008 1C228530
	v_add_co_ci_u32_e64 v51, null, s19, v13, vcc_lo            // 000000856828: D5207C33 01AA1A13
	.long 0xd7006a0c                                           // 000000856830: D7006A0C
	v_cndmask_b32_e32 v0, v12, v21, vcc_lo                     // 000000856834: 02002B0C
	s_waitcnt lgkmcnt(0)                                       // 000000856838: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000085683C: BF870123
	v_dot2_f32_bf16 v8, v49, v67, v8                           // 000000856840: CC1A4008 1C228731
	v_add_co_ci_u32_e64 v13, null, s7, v13, vcc_lo             // 000000856848: D5207C0D 01AA1A07
	v_fmac_f32_e32 v38, v52, v8                                // 000000856850: 564C1134
	s_clause 0x3                                               // 000000856854: BF850003
	global_load_b128 v[8:11], v[46:47], off                    // 000000856858: DC5E0000 087C002E
	global_load_b128 v[19:22], v[46:47], off offset:16         // 000000856860: DC5E0010 137C002E
	global_load_b128 v[42:45], v[46:47], off offset:32         // 000000856868: DC5E0020 2A7C002E
	global_load_b128 v[46:49], v[46:47], off offset:48         // 000000856870: DC5E0030 2E7C002E
	s_waitcnt vmcnt(3)                                         // 000000856878: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 00000085687C: CC1A4008 1A021D08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000856884: BF870091
	v_dot2_f32_bf16 v8, v9, v53, v8                            // 000000856888: CC1A4008 1C226B09
	v_dot2_f32_bf16 v8, v10, v54, v8                           // 000000856890: CC1A4008 1C226D0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000856898: BF8700A1
	v_dot2_f32_bf16 v8, v11, v55, v8                           // 00000085689C: CC1A4008 1C226F0B
	s_waitcnt vmcnt(2)                                         // 0000008568A4: BF890BF7
	v_dot2_f32_bf16 v8, v19, v56, v8                           // 0000008568A8: CC1A4008 1C227113
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008568B0: BF870091
	v_dot2_f32_bf16 v8, v20, v57, v8                           // 0000008568B4: CC1A4008 1C227314
	v_dot2_f32_bf16 v8, v21, v58, v8                           // 0000008568BC: CC1A4008 1C227515
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008568C4: BF8700A1
	v_dot2_f32_bf16 v8, v22, v59, v8                           // 0000008568C8: CC1A4008 1C227716
	s_waitcnt vmcnt(1)                                         // 0000008568D0: BF8907F7
	v_dot2_f32_bf16 v8, v42, v60, v8                           // 0000008568D4: CC1A4008 1C22792A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008568DC: BF870091
	v_dot2_f32_bf16 v8, v43, v61, v8                           // 0000008568E0: CC1A4008 1C227B2B
	v_dot2_f32_bf16 v8, v44, v62, v8                           // 0000008568E8: CC1A4008 1C227D2C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008568F0: BF8700A1
	v_dot2_f32_bf16 v8, v45, v63, v8                           // 0000008568F4: CC1A4008 1C227F2D
	s_waitcnt vmcnt(0)                                         // 0000008568FC: BF8903F7
	v_dot2_f32_bf16 v8, v46, v64, v8                           // 000000856900: CC1A4008 1C22812E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000856908: BF870091
	v_dot2_f32_bf16 v8, v47, v65, v8                           // 00000085690C: CC1A4008 1C22832F
	v_dot2_f32_bf16 v8, v48, v66, v8                           // 000000856914: CC1A4008 1C228530
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000085691C: BF870091
	v_dot2_f32_bf16 v8, v49, v67, v8                           // 000000856920: CC1A4008 1C228731
	v_fmac_f32_e32 v37, v52, v8                                // 000000856928: 564A1134
	s_clause 0x3                                               // 00000085692C: BF850003
	global_load_b128 v[8:11], v[50:51], off                    // 000000856930: DC5E0000 087C0032
	global_load_b128 v[19:22], v[50:51], off offset:16         // 000000856938: DC5E0010 137C0032
	global_load_b128 v[42:45], v[50:51], off offset:32         // 000000856940: DC5E0020 2A7C0032
	global_load_b128 v[46:49], v[50:51], off offset:48         // 000000856948: DC5E0030 2E7C0032
	s_waitcnt vmcnt(3)                                         // 000000856950: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 000000856954: CC1A4008 1A021D08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000085695C: BF870091
	v_dot2_f32_bf16 v8, v9, v53, v8                            // 000000856960: CC1A4008 1C226B09
	v_dot2_f32_bf16 v8, v10, v54, v8                           // 000000856968: CC1A4008 1C226D0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000856970: BF8700A1
	v_dot2_f32_bf16 v8, v11, v55, v8                           // 000000856974: CC1A4008 1C226F0B
	s_waitcnt vmcnt(2)                                         // 00000085697C: BF890BF7
	v_dot2_f32_bf16 v8, v19, v56, v8                           // 000000856980: CC1A4008 1C227113
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000856988: BF870091
	v_dot2_f32_bf16 v8, v20, v57, v8                           // 00000085698C: CC1A4008 1C227314
	v_dot2_f32_bf16 v8, v21, v58, v8                           // 000000856994: CC1A4008 1C227515
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000085699C: BF8700A1
	v_dot2_f32_bf16 v8, v22, v59, v8                           // 0000008569A0: CC1A4008 1C227716
	s_waitcnt vmcnt(1)                                         // 0000008569A8: BF8907F7
	v_dot2_f32_bf16 v8, v42, v60, v8                           // 0000008569AC: CC1A4008 1C22792A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008569B4: BF870091
	v_dot2_f32_bf16 v8, v43, v61, v8                           // 0000008569B8: CC1A4008 1C227B2B
	v_dot2_f32_bf16 v8, v44, v62, v8                           // 0000008569C0: CC1A4008 1C227D2C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008569C8: BF8700A1
	v_dot2_f32_bf16 v8, v45, v63, v8                           // 0000008569CC: CC1A4008 1C227F2D
	s_waitcnt vmcnt(0)                                         // 0000008569D4: BF8903F7
	v_dot2_f32_bf16 v8, v46, v64, v8                           // 0000008569D8: CC1A4008 1C22812E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008569E0: BF870091
	v_dot2_f32_bf16 v8, v47, v65, v8                           // 0000008569E4: CC1A4008 1C22832F
	v_dot2_f32_bf16 v8, v48, v66, v8                           // 0000008569EC: CC1A4008 1C228530
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008569F4: BF870091
	v_dot2_f32_bf16 v8, v49, v67, v8                           // 0000008569F8: CC1A4008 1C228731
	v_fmac_f32_e32 v36, v52, v8                                // 000000856A00: 56481134
	s_clause 0x3                                               // 000000856A04: BF850003
	global_load_b128 v[8:11], v[12:13], off                    // 000000856A08: DC5E0000 087C000C
	global_load_b128 v[19:22], v[12:13], off offset:16         // 000000856A10: DC5E0010 137C000C
	global_load_b128 v[42:45], v[12:13], off offset:32         // 000000856A18: DC5E0020 2A7C000C
	global_load_b128 v[46:49], v[12:13], off offset:48         // 000000856A20: DC5E0030 2E7C000C
	s_waitcnt vmcnt(3)                                         // 000000856A28: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 000000856A2C: CC1A4008 1A021D08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000856A34: BF870091
	v_dot2_f32_bf16 v8, v9, v53, v8                            // 000000856A38: CC1A4008 1C226B09
	v_dot2_f32_bf16 v8, v10, v54, v8                           // 000000856A40: CC1A4008 1C226D0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000856A48: BF8700A1
	v_dot2_f32_bf16 v8, v11, v55, v8                           // 000000856A4C: CC1A4008 1C226F0B
	s_waitcnt vmcnt(2)                                         // 000000856A54: BF890BF7
	v_dot2_f32_bf16 v8, v19, v56, v8                           // 000000856A58: CC1A4008 1C227113
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000856A60: BF870091
	v_dot2_f32_bf16 v8, v20, v57, v8                           // 000000856A64: CC1A4008 1C227314
	v_dot2_f32_bf16 v8, v21, v58, v8                           // 000000856A6C: CC1A4008 1C227515
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000856A74: BF8700A1
	v_dot2_f32_bf16 v8, v22, v59, v8                           // 000000856A78: CC1A4008 1C227716
	s_waitcnt vmcnt(1)                                         // 000000856A80: BF8907F7
	v_dot2_f32_bf16 v8, v42, v60, v8                           // 000000856A84: CC1A4008 1C22792A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000856A8C: BF870091
	v_dot2_f32_bf16 v8, v43, v61, v8                           // 000000856A90: CC1A4008 1C227B2B
	v_dot2_f32_bf16 v8, v44, v62, v8                           // 000000856A98: CC1A4008 1C227D2C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000856AA0: BF8700A1
	v_dot2_f32_bf16 v8, v45, v63, v8                           // 000000856AA4: CC1A4008 1C227F2D
	s_waitcnt vmcnt(0)                                         // 000000856AAC: BF8903F7
	v_dot2_f32_bf16 v8, v46, v64, v8                           // 000000856AB0: CC1A4008 1C22812E
	.long 0xd7006a2e                                           // 000000856AB8: D7006A2E
	v_cndmask_b32_e32 v0, v50, v18, vcc_lo                     // 000000856ABC: 02002532
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000856AC0: BF8701B2
	v_dot2_f32_bf16 v8, v47, v65, v8                           // 000000856AC4: CC1A4008 1C22832F
	v_add_co_ci_u32_e64 v47, null, s19, v51, vcc_lo            // 000000856ACC: D5207C2F 01AA6613
	.long 0xd7006a0c                                           // 000000856AD4: D7006A0C
	v_cndmask_b32_e32 v0, v12, v18, vcc_lo                     // 000000856AD8: 0200250C
	v_dot2_f32_bf16 v8, v48, v66, v8                           // 000000856ADC: CC1A4008 1C228530
	v_add_co_ci_u32_e64 v13, null, s19, v13, vcc_lo            // 000000856AE4: D5207C0D 01AA1A13
	.long 0xd7006a1c                                           // 000000856AEC: D7006A1C
	v_cndmask_b32_e32 v0, v28, v192, vcc_lo                    // 000000856AF0: 0201811C
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000856AF4: BF870123
	v_dot2_f32_bf16 v8, v49, v67, v8                           // 000000856AF8: CC1A4008 1C228731
	v_add_co_ci_u32_e64 v29, null, 0, v29, vcc_lo              // 000000856B00: D5207C1D 01AA3A80
	v_fmac_f32_e32 v35, v52, v8                                // 000000856B08: 56461134
	s_clause 0x3                                               // 000000856B0C: BF850003
	global_load_b128 v[8:11], v[46:47], off                    // 000000856B10: DC5E0000 087C002E
	global_load_b128 v[19:22], v[46:47], off offset:16         // 000000856B18: DC5E0010 137C002E
	global_load_b128 v[42:45], v[46:47], off offset:32         // 000000856B20: DC5E0020 2A7C002E
	global_load_b128 v[46:49], v[46:47], off offset:48         // 000000856B28: DC5E0030 2E7C002E
	s_waitcnt vmcnt(3)                                         // 000000856B30: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 000000856B34: CC1A4008 1A021D08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000856B3C: BF870091
	v_dot2_f32_bf16 v8, v9, v53, v8                            // 000000856B40: CC1A4008 1C226B09
	v_dot2_f32_bf16 v8, v10, v54, v8                           // 000000856B48: CC1A4008 1C226D0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000856B50: BF8700A1
	v_dot2_f32_bf16 v8, v11, v55, v8                           // 000000856B54: CC1A4008 1C226F0B
	s_waitcnt vmcnt(2)                                         // 000000856B5C: BF890BF7
	v_dot2_f32_bf16 v8, v19, v56, v8                           // 000000856B60: CC1A4008 1C227113
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000856B68: BF870091
	v_dot2_f32_bf16 v8, v20, v57, v8                           // 000000856B6C: CC1A4008 1C227314
	v_dot2_f32_bf16 v8, v21, v58, v8                           // 000000856B74: CC1A4008 1C227515
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000856B7C: BF8700A1
	v_dot2_f32_bf16 v8, v22, v59, v8                           // 000000856B80: CC1A4008 1C227716
	s_waitcnt vmcnt(1)                                         // 000000856B88: BF8907F7
	v_dot2_f32_bf16 v8, v42, v60, v8                           // 000000856B8C: CC1A4008 1C22792A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000856B94: BF870091
	v_dot2_f32_bf16 v8, v43, v61, v8                           // 000000856B98: CC1A4008 1C227B2B
	v_dot2_f32_bf16 v8, v44, v62, v8                           // 000000856BA0: CC1A4008 1C227D2C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000856BA8: BF8700A1
	v_dot2_f32_bf16 v8, v45, v63, v8                           // 000000856BAC: CC1A4008 1C227F2D
	s_waitcnt vmcnt(0)                                         // 000000856BB4: BF8903F7
	v_dot2_f32_bf16 v8, v46, v64, v8                           // 000000856BB8: CC1A4008 1C22812E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000856BC0: BF870091
	v_dot2_f32_bf16 v8, v47, v65, v8                           // 000000856BC4: CC1A4008 1C22832F
	v_dot2_f32_bf16 v8, v48, v66, v8                           // 000000856BCC: CC1A4008 1C228530
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000856BD4: BF870091
	v_dot2_f32_bf16 v8, v49, v67, v8                           // 000000856BD8: CC1A4008 1C228731
	v_fmac_f32_e32 v34, v52, v8                                // 000000856BE0: 56441134
	s_clause 0x3                                               // 000000856BE4: BF850003
	global_load_b128 v[8:11], v[12:13], off                    // 000000856BE8: DC5E0000 087C000C
	global_load_b128 v[19:22], v[12:13], off offset:16         // 000000856BF0: DC5E0010 137C000C
	global_load_b128 v[42:45], v[12:13], off offset:32         // 000000856BF8: DC5E0020 2A7C000C
	global_load_b128 v[46:49], v[12:13], off offset:48         // 000000856C00: DC5E0030 2E7C000C
	s_waitcnt vmcnt(3)                                         // 000000856C08: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 000000856C0C: CC1A4008 1A021D08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000856C14: BF870091
	v_dot2_f32_bf16 v8, v9, v53, v8                            // 000000856C18: CC1A4008 1C226B09
	v_dot2_f32_bf16 v8, v10, v54, v8                           // 000000856C20: CC1A4008 1C226D0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000856C28: BF8700A1
	v_dot2_f32_bf16 v8, v11, v55, v8                           // 000000856C2C: CC1A4008 1C226F0B
	s_waitcnt vmcnt(2)                                         // 000000856C34: BF890BF7
	v_dot2_f32_bf16 v8, v19, v56, v8                           // 000000856C38: CC1A4008 1C227113
	v_mov_b32_e32 v19, v15                                     // 000000856C40: 7E26030F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000856C44: BF870122
	v_dot2_f32_bf16 v8, v20, v57, v8                           // 000000856C48: CC1A4008 1C227314
	v_mov_b32_e32 v20, v16                                     // 000000856C50: 7E280310
	v_dot2_f32_bf16 v8, v21, v58, v8                           // 000000856C54: CC1A4008 1C227515
	v_mov_b32_e32 v21, v17                                     // 000000856C5C: 7E2A0311
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000856C60: BF870132
	v_dot2_f32_bf16 v8, v22, v59, v8                           // 000000856C64: CC1A4008 1C227716
	v_mov_b32_e32 v22, v18                                     // 000000856C6C: 7E2C0312
	s_waitcnt vmcnt(1)                                         // 000000856C70: BF8907F7
	v_dot2_f32_bf16 v8, v42, v60, v8                           // 000000856C74: CC1A4008 1C22792A
	v_mov_b32_e32 v42, v41                                     // 000000856C7C: 7E540329
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000856C80: BF870092
	v_dot2_f32_bf16 v8, v43, v61, v8                           // 000000856C84: CC1A4008 1C227B2B
	v_dot2_f32_bf16 v8, v44, v62, v8                           // 000000856C8C: CC1A4008 1C227D2C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000856C94: BF8700A1
	v_dot2_f32_bf16 v8, v45, v63, v8                           // 000000856C98: CC1A4008 1C227F2D
	s_waitcnt vmcnt(0)                                         // 000000856CA0: BF8903F7
	v_dot2_f32_bf16 v8, v46, v64, v8                           // 000000856CA4: CC1A4008 1C22812E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000856CAC: BF870091
	v_dot2_f32_bf16 v8, v47, v65, v8                           // 000000856CB0: CC1A4008 1C22832F
	v_dot2_f32_bf16 v8, v48, v66, v8                           // 000000856CB8: CC1A4008 1C228530
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000856CC0: BF870091
	v_dot2_f32_bf16 v8, v49, v67, v8                           // 000000856CC4: CC1A4008 1C228731
	v_fmac_f32_e32 v32, v52, v8                                // 000000856CCC: 56401134
	v_mov_b32_e32 v14, v7                                      // 000000856CD0: 7E1C0307
	v_dual_mov_b32 v13, v6 :: v_dual_mov_b32 v12, v5           // 000000856CD4: CA100106 0D0C0105
	v_dual_mov_b32 v11, v4 :: v_dual_mov_b32 v10, v3           // 000000856CDC: CA100104 0B0A0103
	v_dual_mov_b32 v9, v2 :: v_dual_mov_b32 v8, v1             // 000000856CE4: CA100102 09080101
	v_mov_b32_e32 v7, v0                                       // 000000856CEC: 7E0E0300
	s_and_not1_b32 exec_lo, exec_lo, s20                       // 000000856CF0: 917E147E
	s_cbranch_execz 28                                         // 000000856CF4: BFA5001C <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0xd68>
	s_waitcnt vmcnt(0)                                         // 000000856CF8: BF8903F7
	v_dual_mov_b32 v15, v19 :: v_dual_add_nc_u32 v40, 32, v40  // 000000856CFC: CA200113 0F2850A0
	v_dual_mov_b32 v16, v20 :: v_dual_mov_b32 v17, v21         // 000000856D04: CA100114 10100115
	v_mov_b32_e32 v18, v22                                     // 000000856D0C: 7E240316
	s_delay_alu instid0(VALU_DEP_3)                            // 000000856D10: BF870003
	.long 0xd4430004                                           // 000000856D14: D4430004
	v_cndmask_b32_e32 v1, s6, v40, vcc_lo                      // 000000856D18: 02025006
	s_mov_b32 s14, exec_lo                                     // 000000856D1C: BE8E007E
	.long 0xd4c4007e                                           // 000000856D20: D4C4007E
	v_cndmask_b32_e32 v1, s6, v40, vcc_lo                      // 000000856D24: 02025006
	s_cbranch_execz 65029                                      // 000000856D28: BFA5FE05 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x540>
	.long 0xd7006a00                                           // 000000856D2C: D7006A00
	v_cndmask_b32_e32 v1, v25, v39, vcc_lo                     // 000000856D30: 02024F19
	s_delay_alu instid0(VALU_DEP_1)                            // 000000856D34: BF870001
	v_add_co_ci_u32_e64 v1, null, 0, v33, vcc_lo               // 000000856D38: D5207C01 01AA4280
	v_cmp_ne_u32_e32 vcc_lo, 1, v31                            // 000000856D40: 7C9A3E81
	v_mov_b32_e32 v41, v42                                     // 000000856D44: 7E52032A
	global_load_b128 v[15:18], v[0:1], off                     // 000000856D48: DC5E0000 0F7C0000
	s_cbranch_vccnz 65019                                      // 000000856D50: BFA4FDFB <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x540>
	global_load_d16_b16 v0, v[28:29], off                      // 000000856D54: DC820000 007C001C
	s_waitcnt vmcnt(0)                                         // 000000856D5C: BF8903F7
	v_cvt_f32_f16_e32 v41, v0                                  // 000000856D60: 7E521700
	s_branch 65014                                             // 000000856D64: BFA0FDF6 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x540>
	s_or_b32 exec_lo, exec_lo, s20                             // 000000856D68: 8C7E147E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000856D6C: BF8700A9
	s_or_b32 exec_lo, exec_lo, s5                              // 000000856D70: 8C7E057E
	.long 0xd71f0000                                           // 000000856D74: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 000000856D78: 020100C1
	v_xor_b32_e32 v1, 16, v0                                   // 000000856D7C: 3A020090
	v_xor_b32_e32 v7, 8, v0                                    // 000000856D80: 3A0E0088
	v_xor_b32_e32 v13, 4, v0                                   // 000000856D84: 3A1A0084
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000856D88: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v1                            // 000000856D8C: 7C9802A0
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 000000856D90: 02020300
	v_cmp_gt_u32_e32 vcc_lo, 32, v7                            // 000000856D94: 7C980EA0
	s_delay_alu instid0(VALU_DEP_2)                            // 000000856D98: BF870002
	v_lshlrev_b32_e32 v1, 2, v1                                // 000000856D9C: 30020282
	ds_bpermute_b32 v4, v1, v36                                // 000000856DA0: DACC0000 04002401
	s_waitcnt lgkmcnt(0)                                       // 000000856DA8: BF89FC07
	v_add_f32_e32 v4, v36, v4                                  // 000000856DAC: 06080924
	ds_bpermute_b32 v2, v1, v38                                // 000000856DB0: DACC0000 02002601
	ds_bpermute_b32 v6, v1, v34                                // 000000856DB8: DACC0000 06002201
	v_cndmask_b32_e32 v7, v0, v7, vcc_lo                       // 000000856DC0: 020E0F00
	ds_bpermute_b32 v3, v1, v37                                // 000000856DC4: DACC0000 03002501
	ds_bpermute_b32 v5, v1, v35                                // 000000856DCC: DACC0000 05002301
	ds_bpermute_b32 v1, v1, v32                                // 000000856DD4: DACC0000 01002001
	v_cmp_gt_u32_e32 vcc_lo, 32, v13                           // 000000856DDC: 7C981AA0
	s_waitcnt lgkmcnt(4)                                       // 000000856DE0: BF89FC47
	v_add_f32_e32 v2, v38, v2                                  // 000000856DE4: 06040526
	s_waitcnt lgkmcnt(3)                                       // 000000856DE8: BF89FC37
	v_dual_add_f32 v6, v34, v6 :: v_dual_lshlrev_b32 v7, 2, v7 // 000000856DEC: C9220D22 06060E82
	ds_bpermute_b32 v8, v7, v2                                 // 000000856DF4: DACC0000 08000207
	s_waitcnt lgkmcnt(0)                                       // 000000856DFC: BF89FC07
	v_add_f32_e32 v2, v2, v8                                   // 000000856E00: 06041102
	ds_bpermute_b32 v10, v7, v4                                // 000000856E04: DACC0000 0A000407
	ds_bpermute_b32 v12, v7, v6                                // 000000856E0C: DACC0000 0C000607
	v_add_f32_e32 v3, v37, v3                                  // 000000856E14: 06060725
	v_add_f32_e32 v5, v35, v5                                  // 000000856E18: 060A0B23
	v_add_f32_e32 v1, v32, v1                                  // 000000856E1C: 06020320
	s_waitcnt lgkmcnt(1)                                       // 000000856E20: BF89FC17
	v_add_f32_e32 v4, v4, v10                                  // 000000856E24: 06081504
	ds_bpermute_b32 v9, v7, v3                                 // 000000856E28: DACC0000 09000307
	s_waitcnt lgkmcnt(1)                                       // 000000856E30: BF89FC17
	v_dual_add_f32 v6, v6, v12 :: v_dual_cndmask_b32 v13, v0, v13// 000000856E34: C9121906 060C1B00
	ds_bpermute_b32 v11, v7, v5                                // 000000856E3C: DACC0000 0B000507
	ds_bpermute_b32 v7, v7, v1                                 // 000000856E44: DACC0000 07000107
	v_lshlrev_b32_e32 v13, 2, v13                              // 000000856E4C: 301A1A82
	s_waitcnt lgkmcnt(2)                                       // 000000856E50: BF89FC27
	v_add_f32_e32 v3, v3, v9                                   // 000000856E54: 06061303
	ds_bpermute_b32 v9, v13, v4                                // 000000856E58: DACC0000 0900040D
	s_waitcnt lgkmcnt(2)                                       // 000000856E60: BF89FC27
	v_add_f32_e32 v5, v5, v11                                  // 000000856E64: 060A1705
	ds_bpermute_b32 v11, v13, v6                               // 000000856E68: DACC0000 0B00060D
	ds_bpermute_b32 v8, v13, v3                                // 000000856E70: DACC0000 0800030D
	s_waitcnt lgkmcnt(2)                                       // 000000856E78: BF89FC27
	v_dual_add_f32 v4, v4, v9 :: v_dual_add_f32 v1, v1, v7     // 000000856E7C: C9081304 04000F01
	ds_bpermute_b32 v7, v13, v2                                // 000000856E84: DACC0000 0700020D
	ds_bpermute_b32 v10, v13, v5                               // 000000856E8C: DACC0000 0A00050D
	ds_bpermute_b32 v12, v13, v1                               // 000000856E94: DACC0000 0C00010D
	v_xor_b32_e32 v13, 2, v0                                   // 000000856E9C: 3A1A0082
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000856EA0: BF870141
	v_cmp_gt_u32_e32 vcc_lo, 32, v13                           // 000000856EA4: 7C981AA0
	s_waitcnt lgkmcnt(2)                                       // 000000856EA8: BF89FC27
	v_dual_cndmask_b32 v13, v0, v13 :: v_dual_add_f32 v2, v2, v7// 000000856EAC: CA481B00 0D020F02
	v_dual_add_f32 v3, v3, v8 :: v_dual_add_f32 v8, v6, v11    // 000000856EB4: C9081103 03081706
	v_lshlrev_b32_e32 v13, 2, v13                              // 000000856EBC: 301A1A82
	s_waitcnt lgkmcnt(1)                                       // 000000856EC0: BF89FC17
	v_add_f32_e32 v5, v5, v10                                  // 000000856EC4: 060A1505
	v_xor_b32_e32 v6, 1, v0                                    // 000000856EC8: 3A0C0081
	ds_bpermute_b32 v10, v13, v4                               // 000000856ECC: DACC0000 0A00040D
	v_cmp_gt_u32_e32 vcc_lo, 32, v6                            // 000000856ED4: 7C980CA0
	v_cndmask_b32_e32 v0, v0, v6, vcc_lo                       // 000000856ED8: 02000D00
	v_cmp_eq_u32_e32 vcc_lo, 0, v30                            // 000000856EDC: 7C943C80
	s_delay_alu instid0(VALU_DEP_2)                            // 000000856EE0: BF870002
	v_lshlrev_b32_e32 v14, 2, v0                               // 000000856EE4: 301C0082
	s_and_b32 s2, vcc_lo, s2                                   // 000000856EE8: 8B02026A
	s_waitcnt lgkmcnt(0)                                       // 000000856EEC: BF89FC07
	v_dual_add_f32 v0, v4, v10 :: v_dual_add_f32 v9, v1, v12   // 000000856EF0: C9081504 00081901
	ds_bpermute_b32 v1, v13, v2                                // 000000856EF8: DACC0000 0100020D
	ds_bpermute_b32 v12, v13, v8                               // 000000856F00: DACC0000 0C00080D
	s_waitcnt lgkmcnt(1)                                       // 000000856F08: BF89FC17
	v_add_f32_e32 v6, v2, v1                                   // 000000856F0C: 060C0302
	s_waitcnt lgkmcnt(0)                                       // 000000856F10: BF89FC07
	v_add_f32_e32 v2, v8, v12                                  // 000000856F14: 06041908
	ds_bpermute_b32 v7, v13, v3                                // 000000856F18: DACC0000 0700030D
	ds_bpermute_b32 v11, v13, v5                               // 000000856F20: DACC0000 0B00050D
	ds_bpermute_b32 v13, v13, v9                               // 000000856F28: DACC0000 0D00090D
	s_waitcnt lgkmcnt(2)                                       // 000000856F30: BF89FC27
	v_add_f32_e32 v7, v3, v7                                   // 000000856F34: 060E0F03
	s_waitcnt lgkmcnt(1)                                       // 000000856F38: BF89FC17
	v_add_f32_e32 v1, v5, v11                                  // 000000856F3C: 06021705
	s_waitcnt lgkmcnt(0)                                       // 000000856F40: BF89FC07
	v_add_f32_e32 v8, v9, v13                                  // 000000856F44: 06101B09
	ds_bpermute_b32 v9, v14, v6                                // 000000856F48: DACC0000 0900060E
	ds_bpermute_b32 v3, v14, v0                                // 000000856F50: DACC0000 0300000E
	ds_bpermute_b32 v10, v14, v7                               // 000000856F58: DACC0000 0A00070E
	ds_bpermute_b32 v4, v14, v1                                // 000000856F60: DACC0000 0400010E
	ds_bpermute_b32 v5, v14, v2                                // 000000856F68: DACC0000 0500020E
	ds_bpermute_b32 v11, v14, v8                               // 000000856F70: DACC0000 0B00080E
	s_and_saveexec_b32 s3, s2                                  // 000000856F78: BE832002
	s_cbranch_execz 280                                        // 000000856F7C: BFA50118 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x13e0>
	s_load_b32 s0, s[0:1], 0x48                                // 000000856F80: F4000000 F8000048
	s_waitcnt lgkmcnt(0)                                       // 000000856F88: BF89FC07
	v_dual_add_f32 v6, v6, v9 :: v_dual_add_f32 v7, v7, v10    // 000000856F8C: C9081306 06061507
	v_dual_add_f32 v8, v8, v11 :: v_dual_add_f32 v1, v1, v4    // 000000856F94: C9081708 08000901
	v_add_f32_e32 v0, v0, v3                                   // 000000856F9C: 06000700
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000856FA0: BF870213
	v_bfe_u32 v9, v6, 16, 1                                    // 000000856FA4: D6100009 02052106
	v_bfe_u32 v10, v7, 16, 1                                   // 000000856FAC: D610000A 02052107
	s_lshl_b64 s[4:5], s[16:17], 2                             // 000000856FB4: 84848210
	s_delay_alu instid0(VALU_DEP_2)                            // 000000856FB8: BF870002
	v_add3_u32 v3, v6, v9, 0x7fff                              // 000000856FBC: D6550003 03FE1306 00007FFF
	v_bfe_u32 v6, v1, 16, 1                                    // 000000856FC8: D6100006 02052101
	v_add_f32_e32 v2, v2, v5                                   // 000000856FD0: 06040B02
	v_add3_u32 v4, v7, v10, 0x7fff                             // 000000856FD4: D6550004 03FE1507 00007FFF
	v_bfe_u32 v9, v8, 16, 1                                    // 000000856FE0: D6100009 02052108
	v_and_b32_e32 v3, 0xffff0000, v3                           // 000000856FE8: 360606FF FFFF0000
	v_add3_u32 v1, v1, v6, 0x7fff                              // 000000856FF0: D6550001 03FE0D01 00007FFF
	v_bfe_u32 v7, v2, 16, 1                                    // 000000856FFC: D6100007 02052102
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000857004: BF870193
	v_dual_mul_f32 v3, s0, v3 :: v_dual_and_b32 v4, 0xffff0000, v4// 000000857008: C8E40600 030408FF FFFF0000
	v_and_b32_e32 v1, 0xffff0000, v1                           // 000000857014: 360202FF FFFF0000
	v_bfe_u32 v5, v0, 16, 1                                    // 00000085701C: D6100005 02052100
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000857024: BF870233
	v_mul_f32_e32 v4, s0, v4                                   // 000000857028: 10080800
	v_add3_u32 v2, v2, v7, 0x7fff                              // 00000085702C: D6550002 03FE0F02 00007FFF
	v_mul_f32_e32 v3, 0xbfb8aa3b, v3                           // 000000857038: 100606FF BFB8AA3B
	v_add3_u32 v0, v0, v5, 0x7fff                              // 000000857040: D6550000 03FE0B00 00007FFF
	v_add3_u32 v5, v8, v9, 0x7fff                              // 00000085704C: D6550005 03FE1308 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000857058: BF870093
	v_exp_f32_e32 v3, v3                                       // 00000085705C: 7E064B03
	v_and_b32_e32 v5, 0xffff0000, v5                           // 000000857060: 360A0AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000857068: BF870001
	v_dual_mul_f32 v5, s0, v5 :: v_dual_and_b32 v0, 0xffff0000, v0// 00000085706C: C8E40A00 050000FF FFFF0000
	v_mul_f32_e32 v4, 0xbfb8aa3b, v4                           // 000000857078: 100808FF BFB8AA3B
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(VALU_DEP_2)   // 000000857080: BF870105
	v_dual_add_f32 v8, 1.0, v3 :: v_dual_mul_f32 v3, 0xbfb8aa3b, v5// 000000857084: C90606F2 08020AFF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000857090: BF870092
	v_exp_f32_e32 v4, v4                                       // 000000857094: 7E084B04
	v_exp_f32_e32 v11, v3                                      // 000000857098: 7E164B03
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000085709C: BF870095
	v_dual_mul_f32 v0, s0, v0 :: v_dual_add_f32 v11, 1.0, v11  // 0000008570A0: C8C80000 000A16F2
	v_dual_mul_f32 v6, s0, v1 :: v_dual_mul_f32 v7, 0xbfb8aa3b, v0// 0000008570A8: C8C60200 060600FF BFB8AA3B
	.long 0xd73c0000                                           // 0000008570B4: D73C0000
	v_cndmask_b32_e32 v1, 2, v23, vcc_lo                       // 0000008570B8: 02022E82
	s_waitcnt vmcnt(0)                                         // 0000008570BC: BF8903F7
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008570C0: BF870193
	v_div_scale_f32 v21, null, v11, v11, 1.0                   // 0000008570C4: D6FC7C15 03CA170B
	v_exp_f32_e32 v7, v7                                       // 0000008570CC: 7E0E4B07
	v_and_b32_e32 v2, 0xffff0000, v2                           // 0000008570D0: 360404FF FFFF0000
	s_delay_alu instid0(VALU_DEP_2)                            // 0000008570D8: BF870002
	v_rcp_f32_e32 v27, v21                                     // 0000008570DC: 7E365515
	s_delay_alu instid0(TRANS32_DEP_2) | instid1(VALU_DEP_1)   // 0000008570E0: BF870086
	v_dual_add_f32 v7, 1.0, v7 :: v_dual_mul_f32 v2, s0, v2    // 0000008570E4: C9060EF2 07020400
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008570EC: BF870095
	v_fma_f32 v28, -v21, v27, 1.0                              // 0000008570F0: D613001C 23CA3715
	v_dual_mul_f32 v2, 0xbfb8aa3b, v2 :: v_dual_fmac_f32 v27, v28, v27// 0000008570F8: C8C004FF 021A371C BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000857104: BF8700A1
	v_exp_f32_e32 v10, v2                                      // 000000857108: 7E144B02
	.long 0xd7006a02                                           // 00000085710C: D7006A02
	v_cndmask_b32_e32 v1, s12, v0, vcc_lo                      // 000000857110: 0202000C
	v_add_co_ci_u32_e64 v3, null, s13, v1, vcc_lo              // 000000857114: D5207C03 01AA020D
	v_div_scale_f32 v1, null, v7, v7, 1.0                      // 00000085711C: D6FC7C01 03CA0F07
	v_div_scale_f32 v15, vcc_lo, 1.0, v8, 1.0                  // 000000857124: D6FC6A0F 03CA10F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000085712C: BF870292
	v_rcp_f32_e32 v17, v1                                      // 000000857130: 7E225501
	v_fma_f32 v23, -v1, v17, 1.0                               // 000000857134: D6130017 23CA2301
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000085713C: BF870091
	v_dual_add_f32 v4, 1.0, v4 :: v_dual_fmac_f32 v17, v23, v17// 000000857140: C90008F2 04102317
	v_div_scale_f32 v9, null, v4, v4, 1.0                      // 000000857148: D6FC7C09 03CA0904
	v_div_scale_f32 v16, s0, 1.0, v4, 1.0                      // 000000857150: D6FC0010 03CA08F2
	v_add_f32_e32 v10, 1.0, v10                                // 000000857158: 061414F2
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000085715C: BF870293
	v_rcp_f32_e32 v13, v9                                      // 000000857160: 7E1A5509
	v_fma_f32 v14, -v9, v13, 1.0                               // 000000857164: D613000E 23CA1B09
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000085716C: BF870091
	v_dual_mul_f32 v6, 0xbfb8aa3b, v6 :: v_dual_fmac_f32 v13, v14, v13// 000000857170: C8C00CFF 060C1B0E BFB8AA3B
	v_exp_f32_e32 v5, v6                                       // 00000085717C: 7E0A4B06
	v_div_scale_f32 v6, null, v8, v8, 1.0                      // 000000857180: D6FC7C06 03CA1108
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000857188: BF870112
	v_mul_f32_e32 v20, v16, v13                                // 00000085718C: 10281B10
	v_rcp_f32_e32 v12, v6                                      // 000000857190: 7E185506
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000857194: BF870091
	v_fma_f32 v25, -v9, v20, v16                               // 000000857198: D6130019 24422909
	v_fmac_f32_e32 v20, v25, v13                               // 0000008571A0: 56281B19
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(TRANS32_DEP_2)// 0000008571A4: BF870321
	v_fma_f32 v9, -v9, v20, v16                                // 0000008571A8: D6130009 24422909
	v_div_scale_f32 v16, s3, 1.0, v10, 1.0                     // 0000008571B0: D6FC0310 03CA14F2
	v_add_f32_e32 v0, 1.0, v5                                  // 0000008571B8: 06000AF2
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008571BC: BF870095
	v_fma_f32 v5, -v6, v12, 1.0                                // 0000008571C0: D6130005 23CA1906
	v_fmac_f32_e32 v12, v5, v12                                // 0000008571C8: 56181905
	v_div_scale_f32 v5, s1, 1.0, v7, 1.0                       // 0000008571CC: D6FC0105 03CA0EF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000008571D4: BF870112
	v_mul_f32_e32 v19, v15, v12                                // 0000008571D8: 1026190F
	v_mul_f32_e32 v25, v5, v17                                 // 0000008571DC: 10322305
	v_div_scale_f32 v18, null, v10, v10, 1.0                   // 0000008571E0: D6FC7C12 03CA150A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000008571E8: BF870113
	v_fma_f32 v24, -v6, v19, v15                               // 0000008571EC: D6130018 243E2706
	v_rcp_f32_e32 v26, v18                                     // 0000008571F4: 7E345512
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008571F8: BF870091
	v_fmac_f32_e32 v19, v24, v12                               // 0000008571FC: 56261918
	v_fma_f32 v6, -v6, v19, v15                                // 000000857200: D6130006 243E2706
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000857208: BF870115
	v_fma_f32 v15, -v18, v26, 1.0                              // 00000085720C: D613000F 23CA3512
	v_div_fmas_f32 v6, v6, v12, v19                            // 000000857214: D6370006 044E1906
	s_mov_b32 vcc_lo, s0                                       // 00000085721C: BEEA0000
	v_fma_f32 v12, -v1, v25, v5                                // 000000857220: D613000C 24163301
	v_div_fmas_f32 v9, v9, v13, v20                            // 000000857228: D6370009 04521B09
	v_fmac_f32_e32 v26, v15, v26                               // 000000857230: 5634350F
	s_mov_b32 vcc_lo, s1                                       // 000000857234: BEEA0001
	v_div_fixup_f32 v6, v6, v8, 1.0                            // 000000857238: D6270006 03CA1106
	v_fmac_f32_e32 v25, v12, v17                               // 000000857240: 5632230C
	v_div_fixup_f32 v4, v9, v4, 1.0                            // 000000857244: D6270004 03CA0909
	v_mul_f32_e32 v9, v16, v26                                 // 00000085724C: 10123510
	v_div_scale_f32 v14, null, v0, v0, 1.0                     // 000000857250: D6FC7C0E 03CA0100
	v_div_scale_f32 v23, s2, 1.0, v0, 1.0                      // 000000857258: D6FC0217 03CA00F2
	v_fma_f32 v1, -v1, v25, v5                                 // 000000857260: D6130001 24163301
	v_add_f32_e32 v12, v4, v4                                  // 000000857268: 06180904
	v_fma_f32 v5, -v18, v9, v16                                // 00000085726C: D6130005 24421312
	v_rcp_f32_e32 v22, v14                                     // 000000857274: 7E2C550E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000857278: BF870113
	v_div_fmas_f32 v1, v1, v17, v25                            // 00000085727C: D6370001 04662301
	v_fmac_f32_e32 v9, v5, v26                                 // 000000857284: 56123505
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000857288: BF870112
	v_div_fixup_f32 v1, v1, v7, 1.0                            // 00000085728C: D6270001 03CA0F01
	v_fma_f32 v15, -v18, v9, v16                               // 000000857294: D613000F 24421312
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000085729C: BF870095
	v_fma_f32 v24, -v14, v22, 1.0                              // 0000008572A0: D6130018 23CA2D0E
	v_dual_add_f32 v13, v1, v1 :: v_dual_fmac_f32 v22, v24, v22// 0000008572A8: C9000301 0D162D18
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008572B0: BF870091
	v_mul_f32_e32 v8, v23, v22                                 // 0000008572B4: 10102D17
	v_fma_f32 v4, -v14, v8, v23                                // 0000008572B8: D6130004 245E110E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008572C0: BF8700A1
	v_fmac_f32_e32 v8, v4, v22                                 // 0000008572C4: 56102D04
	.long 0xd7006a04                                           // 0000008572C8: D7006A04
	v_cndmask_b32_e32 v0, v2, v4, vcc_lo                       // 0000008572CC: 02000902
	v_add_co_ci_u32_e64 v5, null, s5, v3, vcc_lo               // 0000008572D0: D5207C05 01AA0605
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008572D8: BF8700A3
	v_fma_f32 v1, -v14, v8, v23                                // 0000008572DC: D6130001 245E110E
	s_mov_b32 vcc_lo, s2                                       // 0000008572E4: BEEA0002
	v_div_fmas_f32 v1, v1, v22, v8                             // 0000008572E8: D6370001 04222D01
	s_mov_b32 vcc_lo, s3                                       // 0000008572F0: BEEA0003
	s_lshl_b64 s[2:3], s[16:17], 3                             // 0000008572F4: 84828310
	v_div_fmas_f32 v8, v15, v26, v9                            // 0000008572F8: D6370008 0426350F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000857300: BF8701A2
	v_div_fixup_f32 v9, v1, v0, 1.0                            // 000000857304: D6270009 03CA0101
	v_mad_u64_u32 v[0:1], null, s16, 12, v[2:3]                // 00000085730C: D6FE7C00 04091810
	v_div_fixup_f32 v8, v8, v10, 1.0                           // 000000857314: D6270008 03CA1508
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000085731C: BF8700D1
	v_dual_add_f32 v6, v6, v6 :: v_dual_add_f32 v15, v8, v8    // 000000857320: C9080D06 060E1108
	global_store_b32 v[2:3], v6, off                           // 000000857328: DC6A0000 007C0602
	v_div_scale_f32 v6, s0, 1.0, v11, 1.0                      // 000000857330: D6FC0006 03CA16F2
	s_mov_b32 vcc_lo, s0                                       // 000000857338: BEEA0000
	v_mul_f32_e32 v7, v6, v27                                  // 00000085733C: 100E3706
	v_fma_f32 v14, -v21, v7, v6                                // 000000857340: D613000E 241A0F15
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000857348: BF870091
	v_dual_fmac_f32 v7, v14, v27 :: v_dual_add_f32 v14, v9, v9 // 00000085734C: C808370E 070E1309
	v_fma_f32 v6, -v21, v7, v6                                 // 000000857354: D6130006 241A0F15
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 00000085735C: BF870241
	v_div_fmas_f32 v10, v6, v27, v7                            // 000000857360: D637000A 041E3706
	.long 0xd7006a06                                           // 000000857368: D7006A06
	v_cndmask_b32_e32 v0, v2, v2, vcc_lo                       // 00000085736C: 02000502
	v_mad_u64_u32 v[1:2], null, s17, 12, v[1:2]                // 000000857370: D6FE7C01 04051811
	v_add_co_ci_u32_e64 v7, null, s3, v3, vcc_lo               // 000000857378: D5207C07 01AA0603
	v_div_fixup_f32 v8, v10, v11, 1.0                          // 000000857380: D6270008 03CA170A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000857388: BF870094
	.long 0xd7006a02                                           // 00000085738C: D7006A02
	v_cndmask_b32_e32 v0, v6, v2, vcc_lo                       // 000000857390: 02000506
	v_add_co_ci_u32_e64 v3, null, s3, v7, vcc_lo               // 000000857394: D5207C03 01AA0E03
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000085739C: BF8700A3
	v_add_f32_e32 v10, v8, v8                                  // 0000008573A0: 06141108
	.long 0xd7006a08                                           // 0000008573A4: D7006A08
	v_cndmask_b32_e32 v0, v0, v2, vcc_lo                       // 0000008573A8: 02000500
	v_add_co_ci_u32_e64 v9, null, s3, v1, vcc_lo               // 0000008573AC: D5207C09 01AA0203
	s_clause 0x4                                               // 0000008573B4: BF850004
	global_store_b32 v[4:5], v12, off                          // 0000008573B8: DC6A0000 007C0C04
	global_store_b32 v[6:7], v13, off                          // 0000008573C0: DC6A0000 007C0D06
	global_store_b32 v[0:1], v14, off                          // 0000008573C8: DC6A0000 007C0E00
	global_store_b32 v[2:3], v15, off                          // 0000008573D0: DC6A0000 007C0F02
	global_store_b32 v[8:9], v10, off                          // 0000008573D8: DC6A0000 007C0A08
	s_endpgm                                                   // 0000008573E0: BFB00000
		...

