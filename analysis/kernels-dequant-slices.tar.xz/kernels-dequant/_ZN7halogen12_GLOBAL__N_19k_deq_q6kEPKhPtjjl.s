0000000000228b00 <_ZN7halogen12_GLOBAL__N_19k_deq_q6kEPKhPtjjl>:
; _ZN7halogen12_GLOBAL__N_19k_deq_q6kEPKhPtjjl():
	s_load_b64 s[8:9], s[0:1], 0x10                            // 000000228B00: F4040200 F8000010
	v_lshl_or_b32 v2, s2, 8, v0                                // 000000228B08: D6560002 04011002
	s_mov_b32 s2, exec_lo                                      // 000000228B10: BE82007E
	s_waitcnt lgkmcnt(0)                                       // 000000228B14: BF89FC07
	s_delay_alu instid0(VALU_DEP_1)                            // 000000228B18: BF870001
	.long 0xd4cc007e                                           // 000000228B1C: D4CC007E
	v_cndmask_b32_e32 v1, s9, v2, vcc_lo                       // 000000228B20: 02020409
	s_cbranch_execz 389                                        // 000000228B24: BFA50185 <_ZN7halogen12_GLOBAL__N_19k_deq_q6kEPKhPtjjl+0x63c>
	s_load_b64 s[2:3], s[0:1], 0x18                            // 000000228B28: F4040080 F8000018
	s_cvt_f32_u32 s4, s8                                       // 000000228B30: BE846508
	s_load_b32 s11, s[0:1], 0x20                               // 000000228B34: F40002C0 F8000020
	v_mov_b32_e32 v1, 0                                        // 000000228B3C: 7E020280
	s_mov_b32 s10, 0                                           // 000000228B40: BE8A0080
	v_rcp_iflag_f32_e32 v0, s4                                 // 000000228B44: 7E005604
	s_load_b128 s[4:7], s[0:1], null                           // 000000228B48: F4080100 F8000000
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 000000228B50: BF8704C5
	v_readfirstlane_b32 s12, v0                                // 000000228B54: 7E180500
	s_mul_f32 s0, s12, 0x4f7ffffe                              // 000000228B58: A200FF0C 4F7FFFFE
	s_waitcnt lgkmcnt(0)                                       // 000000228B60: BF89FC07
	s_ashr_i32 s1, s3, 31                                      // 000000228B64: 86019F03
	s_lshr_b32 s1, s1, 24                                      // 000000228B68: 85019801
	s_cvt_u32_f32 s14, s0                                      // 000000228B6C: BE8E6700
	s_add_u32 s0, s2, s1                                       // 000000228B70: 80000102
	s_addc_u32 s1, s3, 0                                       // 000000228B74: 82018003
	s_sub_i32 s12, 0, s8                                       // 000000228B78: 818C0880
	s_ashr_i64 s[0:1], s[0:1], 8                               // 000000228B7C: 86808800
	s_mul_i32 s13, s12, s14                                    // 000000228B80: 960D0E0C
	s_mulk_i32 s1, 0xd2                                        // 000000228B84: B80100D2
	s_mul_hi_u32 s15, s0, 0xd2                                 // 000000228B88: 968FFF00 000000D2
	s_mul_i32 s12, s0, 0xd2                                    // 000000228B90: 960CFF00 000000D2
	s_mul_hi_u32 s0, s14, s13                                  // 000000228B98: 96800D0E
	s_lshl_b32 s11, s11, 8                                     // 000000228B9C: 840B880B
	s_add_i32 s13, s15, s1                                     // 000000228BA0: 810D010F
	s_add_i32 s14, s14, s0                                     // 000000228BA4: 810E000E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000228BA8: BF870099
	.long 0xd72d0000                                           // 000000228BAC: D72D0000
	v_cndmask_b32_e32 v0, v2, v14, vcc_lo                      // 000000228BB0: 02001D02
	.long 0xd72c0003                                           // 000000228BB4: D72C0003
	v_cndmask_b32_e32 v0, v0, v8, vcc_lo                       // 000000228BB8: 02001100
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000228BBC: BF870091
	v_sub_nc_u32_e32 v3, v2, v3                                // 000000228BC0: 4C060702
	v_subrev_nc_u32_e32 v5, s8, v3                             // 000000228BC4: 4E0A0608
	v_cmp_le_u32_e32 vcc_lo, s8, v3                            // 000000228BC8: 7C960608
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000228BCC: BF870092
	v_dual_cndmask_b32 v3, v3, v5 :: v_dual_add_nc_u32 v4, 1, v0// 000000228BD0: CA600B03 03040081
	v_cndmask_b32_e32 v0, v0, v4, vcc_lo                       // 000000228BD8: 02000900
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000228BDC: BF870112
	v_cmp_le_u32_e32 vcc_lo, s8, v3                            // 000000228BE0: 7C960608
	v_add_nc_u32_e32 v4, 1, v0                                 // 000000228BE4: 4A080081
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000228BE8: BF870091
	v_cndmask_b32_e32 v13, v0, v4, vcc_lo                      // 000000228BEC: 021A0900
	.long 0xd72c0000                                           // 000000228BF0: D72C0000
	v_cndmask_b32_e32 v0, v13, v8, vcc_lo                      // 000000228BF4: 0200110D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000228BF8: BF870091
	v_sub_nc_u32_e32 v0, v2, v0                                // 000000228BFC: 4C000102
	v_bfe_u32 v7, v0, 3, 1                                     // 000000228C00: D6100007 02050700
	v_lshlrev_b32_e32 v8, 4, v0                                // 000000228C08: 30100084
	v_and_b32_e32 v6, 15, v0                                   // 000000228C0C: 360C008F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 000000228C10: BF870253
	v_lshlrev_b32_e32 v10, 6, v7                               // 000000228C14: 30140E86
	v_mad_u64_u32 v[3:4], null, s12, v13, s[4:5]               // 000000228C18: D6FE7C03 00121A0C
	v_lshlrev_b32_e32 v7, 5, v7                                // 000000228C20: 300E0E85
	v_and_b32_e32 v9, 16, v8                                   // 000000228C24: 36121090
	v_and_b32_e32 v8, 32, v8                                   // 000000228C28: 361010A0
	v_mad_u64_u32 v[4:5], null, s13, v13, v[4:5]               // 000000228C2C: D6FE7C04 04121A0D
	v_ashrrev_i32_e32 v5, 4, v0                                // 000000228C34: 340A0084
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000228C38: BF870091
	.long 0xd72c0005                                           // 000000228C3C: D72C0005
	v_cndmask_b32_e32 v1, 0xd2, v5, vcc_lo                     // 000000228C40: 02020AFF 000000D2
	v_ashrrev_i32_e32 v12, 31, v5                              // 000000228C48: 34180A9F
	.long 0xd7006a0b                                           // 000000228C4C: D7006A0B
	v_cndmask_b32_e32 v1, v3, v5, vcc_lo                       // 000000228C50: 02020B03
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000228C54: BF870111
	v_add_co_ci_u32_e64 v12, null, v4, v12, vcc_lo             // 000000228C58: D5207C0C 01AA1904
	.long 0xd7006a04                                           // 000000228C60: D7006A04
	v_cndmask_b32_e32 v1, v11, v10, vcc_lo                     // 000000228C64: 0202150B
	.long 0xd7000005                                           // 000000228C68: D7000005
	v_cndmask_b32_e32 v1, v11, v7, vcc_lo                      // 000000228C6C: 02020F0B
	s_delay_alu instid0(VALU_DEP_3)                            // 000000228C70: BF870003
	v_add_co_ci_u32_e64 v7, null, 0, v12, vcc_lo               // 000000228C74: D5207C07 01AA1880
	.long 0xd7000103                                           // 000000228C7C: D7000103
	v_cndmask_b32_e32 v1, v11, v6, vcc_lo                      // 000000228C80: 02020D0B
	v_add_co_ci_u32_e64 v6, null, 0, v12, s0                   // 000000228C84: D5207C06 00021880
	.long 0xd7006a08                                           // 000000228C8C: D7006A08
	v_cndmask_b32_e32 v1, v4, v8, vcc_lo                       // 000000228C90: 02021104
	.long 0xd7000005                                           // 000000228C94: D7000005
	v_cndmask_b32_e32 v1, v5, v9, vcc_lo                       // 000000228C98: 02021305
	v_add_co_ci_u32_e64 v10, null, 0, v7, vcc_lo               // 000000228C9C: D5207C0A 01AA0E80
	v_add_co_ci_u32_e64 v4, null, 0, v12, s1                   // 000000228CA4: D5207C04 00061880
	v_add_co_ci_u32_e64 v6, null, 0, v6, s0                    // 000000228CAC: D5207C06 00020C80
	.long 0xd7006a07                                           // 000000228CB4: D7006A07
	v_cndmask_b32_e32 v1, v8, v9, vcc_lo                       // 000000228CB8: 02021308
	s_delay_alu instid0(VALU_DEP_1)                            // 000000228CBC: BF870001
	v_add_co_ci_u32_e64 v8, null, 0, v10, vcc_lo               // 000000228CC0: D5207C08 01AA1480
	s_clause 0x3                                               // 000000228CC8: BF850003
	global_load_i8 v15, v[3:4], off offset:192                 // 000000228CCC: DC4600C0 0F7C0003
	global_load_b128 v[3:6], v[5:6], off offset:128            // 000000228CD4: DC5E0080 037C0005
	global_load_b128 v[7:10], v[7:8], off                      // 000000228CDC: DC5E0000 077C0007
	global_load_d16_b16 v16, v[11:12], off offset:208          // 000000228CE4: DC8200D0 107C000B
	v_mad_u64_u32 v[11:12], null, s2, v13, 0                   // 000000228CEC: D6FE7C0B 02021A02
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000228CF4: BF870121
	v_mad_u64_u32 v[12:13], null, s3, v13, v[12:13]            // 000000228CF8: D6FE7C0C 04321A03
	.long 0xd73c000d                                           // 000000228D00: D73C000D
	v_cndmask_b32_e32 v1, 5, v0, vcc_lo                        // 000000228D04: 02020085
	.long 0xd73c000b                                           // 000000228D08: D73C000B
	v_cndmask_b32_e32 v1, 1, v11, vcc_lo                       // 000000228D0C: 02021681
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000228D10: BF870091
	.long 0xd700000b                                           // 000000228D14: D700000B
	v_cndmask_b32_e32 v1, s6, v11, vcc_lo                      // 000000228D18: 02021606
	v_add_co_ci_u32_e64 v12, null, s7, v12, s0                 // 000000228D1C: D5207C0C 00021807
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000228D24: BF870092
	.long 0xd700000b                                           // 000000228D28: D700000B
	v_cndmask_b32_e32 v1, v11, v13, vcc_lo                     // 000000228D2C: 02021B0B
	v_add_co_ci_u32_e64 v12, null, v12, v14, s0                // 000000228D30: D5207C0C 00021D0C
	s_waitcnt vmcnt(3)                                         // 000000228D38: BF890FF7
	v_cvt_f32_i32_e32 v13, v15                                 // 000000228D3C: 7E1A0B0F
	s_waitcnt vmcnt(0)                                         // 000000228D40: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000228D44: BF870131
	v_fma_mix_f32 v13, v16, v13, neg(0) op_sel_hi:[1,0,0]      // 000000228D48: CC20000D 8A021B10
	v_and_b32_e32 v18, 6, v0                                   // 000000228D50: 36240086
	v_and_b32_e32 v17, 4, v0                                   // 000000228D54: 36220084
	v_or_b32_e32 v19, 8, v18                                   // 000000228D58: 38262488
	s_delay_alu instid0(VALU_DEP_2)                            // 000000228D5C: BF870002
	v_or_b32_e32 v0, 8, v17                                    // 000000228D60: 38002288
	v_or_b32_e32 v21, 16, v18                                  // 000000228D64: 382A2490
	v_or_b32_e32 v23, 24, v18                                  // 000000228D68: 382E2498
	v_or_b32_e32 v20, 16, v17                                  // 000000228D6C: 38282290
	v_lshrrev_b32_e32 v15, v19, v3                             // 000000228D70: 321E0713
	v_lshrrev_b32_e32 v26, v19, v4                             // 000000228D74: 32340913
	v_lshrrev_b32_e32 v29, v19, v5                             // 000000228D78: 323A0B13
	v_lshrrev_b32_e32 v19, v19, v6                             // 000000228D7C: 32260D13
	v_or_b32_e32 v22, 24, v17                                  // 000000228D80: 382C2298
	v_lshrrev_b32_e32 v14, v18, v3                             // 000000228D84: 321C0712
	v_lshrrev_b32_e32 v24, v21, v3                             // 000000228D88: 32300715
	v_lshrrev_b32_e32 v3, v23, v3                              // 000000228D8C: 32060717
	v_lshrrev_b32_e32 v25, v18, v4                             // 000000228D90: 32320912
	v_lshrrev_b32_e32 v27, v21, v4                             // 000000228D94: 32360915
	v_lshrrev_b32_e32 v4, v23, v4                              // 000000228D98: 32080917
	v_lshrrev_b32_e32 v28, v18, v5                             // 000000228D9C: 32380B12
	v_lshrrev_b32_e32 v30, v21, v5                             // 000000228DA0: 323C0B15
	v_lshrrev_b32_e32 v5, v23, v5                              // 000000228DA4: 320A0B17
	v_lshrrev_b32_e32 v18, v18, v6                             // 000000228DA8: 32240D12
	v_lshrrev_b32_e32 v21, v21, v6                             // 000000228DAC: 322A0D15
	v_lshrrev_b32_e32 v6, v23, v6                              // 000000228DB0: 320C0D17
	v_bfe_u32 v23, v7, v0, 4                                   // 000000228DB4: D6100017 02120107
	v_bfe_u32 v33, v8, v0, 4                                   // 000000228DBC: D6100021 02120108
	v_bfe_u32 v36, v9, v0, 4                                   // 000000228DC4: D6100024 02120109
	v_bfe_u32 v0, v10, v0, 4                                   // 000000228DCC: D6100000 0212010A
	v_lshlrev_b32_e32 v19, 4, v19                              // 000000228DD4: 30262684
	v_bfe_u32 v32, v8, v17, 4                                  // 000000228DD8: D6100020 02122308
	v_bfe_u32 v34, v8, v20, 4                                  // 000000228DE0: D6100022 02122908
	v_bfe_u32 v8, v8, v22, 4                                   // 000000228DE8: D6100008 02122D08
	v_lshlrev_b32_e32 v4, 4, v4                                // 000000228DF0: 30080884
	v_bfe_u32 v35, v9, v17, 4                                  // 000000228DF4: D6100023 02122309
	v_lshlrev_b32_e32 v28, 4, v28                              // 000000228DFC: 30383884
	v_and_or_b32 v0, v19, 48, v0                               // 000000228E00: D6570000 04016113
	v_bfe_u32 v16, v7, v17, 4                                  // 000000228E08: D6100010 02122307
	v_and_or_b32 v4, v4, 48, v8                                // 000000228E10: D6570004 04216104
	v_bfe_u32 v31, v7, v20, 4                                  // 000000228E18: D610001F 02122907
	v_and_or_b32 v8, v28, 48, v35                              // 000000228E20: D6570008 048D611C
	v_subrev_nc_u32_e32 v0, 32, v0                             // 000000228E28: 4E0000A0
	v_bfe_u32 v37, v9, v20, 4                                  // 000000228E2C: D6100025 02122909
	v_bfe_u32 v9, v9, v22, 4                                   // 000000228E34: D6100009 02122D09
	v_bfe_u32 v17, v10, v17, 4                                 // 000000228E3C: D6100011 0212230A
	v_lshlrev_b32_e32 v18, 4, v18                              // 000000228E44: 30242484
	v_bfe_u32 v20, v10, v20, 4                                 // 000000228E48: D6100014 0212290A
	v_lshlrev_b32_e32 v21, 4, v21                              // 000000228E50: 302A2A84
	v_bfe_u32 v10, v10, v22, 4                                 // 000000228E54: D610000A 02122D0A
	v_lshlrev_b32_e32 v6, 4, v6                                // 000000228E5C: 300C0C84
	v_subrev_nc_u32_e32 v8, 32, v8                             // 000000228E60: 4E1010A0
	v_cvt_f32_i32_e32 v0, v0                                   // 000000228E64: 7E000B00
	v_lshlrev_b32_e32 v5, 4, v5                                // 000000228E68: 300A0A84
	v_lshlrev_b32_e32 v15, 4, v15                              // 000000228E6C: 301E1E84
	v_and_or_b32 v6, v6, 48, v10                               // 000000228E70: D6570006 04296106
	v_cvt_f32_i32_e32 v8, v8                                   // 000000228E78: 7E100B08
	v_dual_mul_f32 v0, v13, v0 :: v_dual_lshlrev_b32 v27, 4, v27// 000000228E7C: C8E2010D 001A3684
	v_and_or_b32 v5, v5, 48, v9                                // 000000228E84: D6570005 04256105
	v_and_or_b32 v9, v18, 48, v17                              // 000000228E8C: D6570009 04456112
	v_and_or_b32 v17, v21, 48, v20                             // 000000228E94: D6570011 04516115
	v_and_or_b32 v15, v15, 48, v23                             // 000000228E9C: D657000F 045D610F
	v_subrev_nc_u32_e32 v6, 32, v6                             // 000000228EA4: 4E0C0CA0
	v_mul_f32_e32 v8, v13, v8                                  // 000000228EA8: 1010110D
	v_and_or_b32 v23, v27, 48, v34                             // 000000228EAC: D6570017 0489611B
	v_subrev_nc_u32_e32 v17, 32, v17                           // 000000228EB4: 4E2222A0
	v_lshlrev_b32_e32 v26, 4, v26                              // 000000228EB8: 30343484
	v_subrev_nc_u32_e32 v4, 32, v4                             // 000000228EBC: 4E0808A0
	v_cvt_f32_i32_e32 v6, v6                                   // 000000228EC0: 7E0C0B06
	v_lshlrev_b32_e32 v24, 4, v24                              // 000000228EC4: 30303084
	v_subrev_nc_u32_e32 v18, 32, v23                           // 000000228EC8: 4E242EA0
	v_cvt_f32_i32_e32 v17, v17                                 // 000000228ECC: 7E220B11
	v_lshlrev_b32_e32 v14, 4, v14                              // 000000228ED0: 301C1C84
	v_bfe_u32 v7, v7, v22, 4                                   // 000000228ED4: D6100007 02122D07
	v_lshlrev_b32_e32 v30, 4, v30                              // 000000228EDC: 303C3C84
	v_and_or_b32 v22, v26, 48, v33                             // 000000228EE0: D6570016 0485611A
	v_cvt_f32_i32_e32 v18, v18                                 // 000000228EE8: 7E240B12
	v_lshlrev_b32_e32 v3, 4, v3                                // 000000228EEC: 30060684
	v_cvt_f32_i32_e32 v4, v4                                   // 000000228EF0: 7E080B04
	v_lshlrev_b32_e32 v25, 4, v25                              // 000000228EF4: 30323284
	v_mul_f32_e32 v17, v13, v17                                // 000000228EF8: 1022230D
	v_and_or_b32 v14, v14, 48, v16                             // 000000228EFC: D657000E 0441610E
	v_and_or_b32 v16, v24, 48, v31                             // 000000228F04: D6570010 047D6118
	v_mul_f32_e32 v18, v13, v18                                // 000000228F0C: 1024250D
	v_and_or_b32 v3, v3, 48, v7                                // 000000228F10: D6570003 041D6103
	v_subrev_nc_u32_e32 v9, 32, v9                             // 000000228F18: 4E1212A0
	v_subrev_nc_u32_e32 v10, 32, v14                           // 000000228F1C: 4E141CA0
	v_subrev_nc_u32_e32 v14, 32, v15                           // 000000228F20: 4E1C1EA0
	v_subrev_nc_u32_e32 v15, 32, v16                           // 000000228F24: 4E1E20A0
	v_subrev_nc_u32_e32 v16, 32, v22                           // 000000228F28: 4E202CA0
	v_mul_f32_e32 v22, v13, v4                                 // 000000228F2C: 102C090D
	v_and_or_b32 v7, v25, 48, v32                              // 000000228F30: D6570007 04816119
	v_and_or_b32 v25, v30, 48, v37                             // 000000228F38: D6570019 0495611E
	v_subrev_nc_u32_e32 v3, 32, v3                             // 000000228F40: 4E0606A0
	v_subrev_nc_u32_e32 v5, 32, v5                             // 000000228F44: 4E0A0AA0
	v_cvt_f32_i32_e32 v10, v10                                 // 000000228F48: 7E140B0A
	v_subrev_nc_u32_e32 v7, 32, v7                             // 000000228F4C: 4E0E0EA0
	v_subrev_nc_u32_e32 v20, 32, v25                           // 000000228F50: 4E2832A0
	v_cvt_f32_i32_e32 v14, v14                                 // 000000228F54: 7E1C0B0E
	v_cvt_f32_i32_e32 v15, v15                                 // 000000228F58: 7E1E0B0F
	v_cvt_f32_i32_e32 v16, v16                                 // 000000228F5C: 7E200B10
	v_cvt_f32_i32_e32 v7, v7                                   // 000000228F60: 7E0E0B07
	v_cvt_f32_i32_e32 v20, v20                                 // 000000228F64: 7E280B14
	v_lshlrev_b32_e32 v29, 4, v29                              // 000000228F68: 303A3A84
	v_cvt_f32_i32_e32 v9, v9                                   // 000000228F6C: 7E120B09
	v_cvt_f32_i32_e32 v3, v3                                   // 000000228F70: 7E060B03
	v_cvt_f32_i32_e32 v5, v5                                   // 000000228F74: 7E0A0B05
	v_mul_f32_e32 v20, v13, v20                                // 000000228F78: 1028290D
	v_and_or_b32 v24, v29, 48, v36                             // 000000228F7C: D6570018 0491611D
	v_mul_f32_e32 v10, v13, v10                                // 000000228F84: 1014150D
	v_mul_f32_e32 v14, v13, v14                                // 000000228F88: 101C1D0D
	v_mul_f32_e32 v15, v13, v15                                // 000000228F8C: 101E1F0D
	v_mul_f32_e32 v7, v13, v7                                  // 000000228F90: 100E0F0D
	v_subrev_nc_u32_e32 v19, 32, v24                           // 000000228F94: 4E2630A0
	v_mul_f32_e32 v16, v13, v16                                // 000000228F98: 1020210D
	v_mul_f32_e32 v9, v13, v9                                  // 000000228F9C: 1012130D
	v_dual_mul_f32 v21, v13, v3 :: v_dual_add_nc_u32 v2, s11, v2// 000000228FA0: C8E0070D 1502040B
	v_mul_f32_e32 v23, v13, v5                                 // 000000228FA8: 102E0B0D
	v_cvt_f32_i32_e32 v19, v19                                 // 000000228FAC: 7E260B13
	v_bfe_u32 v3, v10, 16, 1                                   // 000000228FB0: D6100003 0205210A
	v_bfe_u32 v4, v14, 16, 1                                   // 000000228FB8: D6100004 0205210E
	v_bfe_u32 v5, v15, 16, 1                                   // 000000228FC0: D6100005 0205210F
	v_bfe_u32 v24, v7, 16, 1                                   // 000000228FC8: D6100018 02052107
	v_mul_f32_e32 v19, v13, v19                                // 000000228FD0: 1026270D
	v_mul_f32_e32 v13, v13, v6                                 // 000000228FD4: 101A0D0D
	v_bfe_u32 v25, v16, 16, 1                                  // 000000228FD8: D6100019 02052110
	v_bfe_u32 v26, v18, 16, 1                                  // 000000228FE0: D610001A 02052112
	v_bfe_u32 v28, v8, 16, 1                                   // 000000228FE8: D610001C 02052108
	v_bfe_u32 v29, v19, 16, 1                                  // 000000228FF0: D610001D 02052113
	v_bfe_u32 v30, v20, 16, 1                                  // 000000228FF8: D610001E 02052114
	v_bfe_u32 v32, v9, 16, 1                                   // 000000229000: D6100020 02052109
	v_bfe_u32 v33, v0, 16, 1                                   // 000000229008: D6100021 02052100
	v_bfe_u32 v34, v17, 16, 1                                  // 000000229010: D6100022 02052111
	v_bfe_u32 v6, v21, 16, 1                                   // 000000229018: D6100006 02052115
	v_bfe_u32 v27, v22, 16, 1                                  // 000000229020: D610001B 02052116
	v_bfe_u32 v31, v23, 16, 1                                  // 000000229028: D610001F 02052117
	v_bfe_u32 v35, v13, 16, 1                                  // 000000229030: D6100023 0205210D
	v_add3_u32 v36, v10, v3, 0x7fff                            // 000000229038: D6550024 03FE070A 00007FFF
	v_add3_u32 v3, v14, v4, 0x7fff                             // 000000229044: D6550003 03FE090E 00007FFF
	v_add3_u32 v14, v15, v5, 0x7fff                            // 000000229050: D655000E 03FE0B0F 00007FFF
	v_add3_u32 v15, v7, v24, 0x7fff                            // 00000022905C: D655000F 03FE3107 00007FFF
	v_add3_u32 v5, v16, v25, 0x7fff                            // 000000229068: D6550005 03FE3310 00007FFF
	v_add3_u32 v16, v18, v26, 0x7fff                           // 000000229074: D6550010 03FE3512 00007FFF
	v_add3_u32 v18, v8, v28, 0x7fff                            // 000000229080: D6550012 03FE3908 00007FFF
	v_add3_u32 v7, v19, v29, 0x7fff                            // 00000022908C: D6550007 03FE3B13 00007FFF
	v_add3_u32 v19, v20, v30, 0x7fff                           // 000000229098: D6550013 03FE3D14 00007FFF
	v_add3_u32 v20, v9, v32, 0x7fff                            // 0000002290A4: D6550014 03FE4109 00007FFF
	v_add3_u32 v9, v0, v33, 0x7fff                             // 0000002290B0: D6550009 03FE4300 00007FFF
	v_add3_u32 v0, v17, v34, 0x7fff                            // 0000002290BC: D6550000 03FE4511 00007FFF
	v_cmp_le_u32_e32 vcc_lo, s9, v2                            // 0000002290C8: 7C960409
	v_add3_u32 v4, v21, v6, 0x7fff                             // 0000002290CC: D6550004 03FE0D15 00007FFF
	v_add3_u32 v6, v22, v27, 0x7fff                            // 0000002290D8: D6550006 03FE3716 00007FFF
	v_add3_u32 v8, v23, v31, 0x7fff                            // 0000002290E4: D6550008 03FE3F17 00007FFF
	v_add3_u32 v10, v13, v35, 0x7fff                           // 0000002290F0: D655000A 03FE470D 00007FFF
	.long 0x7e08398e                                           // 0000002290FC: 7E08398E
	.long 0x7e0639a4                                           // 000000229100: 7E0639A4
	.long 0x7e0c3990                                           // 000000229104: 7E0C3990
	.long 0x7e0a398f                                           // 000000229108: 7E0A398F
	.long 0x7e103993                                           // 00000022910C: 7E103993
	.long 0x7e0e3992                                           // 000000229110: 7E0E3992
	.long 0x7e143980                                           // 000000229114: 7E143980
	.long 0x7e123994                                           // 000000229118: 7E123994
	s_or_b32 s10, vcc_lo, s10                                  // 00000022911C: 8C0A0A6A
	s_clause 0x1                                               // 000000229120: BF850001
	global_store_b128 v[11:12], v[3:6], off                    // 000000229124: DC760000 007C030B
	global_store_b128 v[11:12], v[7:10], off offset:16         // 00000022912C: DC760010 007C070B
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 000000229134: 917E0A7E
	s_cbranch_execnz 65179                                     // 000000229138: BFA6FE9B <_ZN7halogen12_GLOBAL__N_19k_deq_q6kEPKhPtjjl+0xa8>
	s_endpgm                                                   // 00000022913C: BFB00000
		...

