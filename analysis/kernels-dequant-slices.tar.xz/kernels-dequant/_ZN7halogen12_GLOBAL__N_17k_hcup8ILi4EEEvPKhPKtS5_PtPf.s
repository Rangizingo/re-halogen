00000000003d3c00 <_ZN7halogen12_GLOBAL__N_17k_hcup8ILi4EEEvPKhPKtS5_PtPf>:
; _ZN7halogen12_GLOBAL__N_17k_hcup8ILi4EEEvPKhPKtS5_PtPf():
	s_load_b256 s[4:11], s[0:1], null                          // 0000003D3C00: F40C0100 F8000000
	v_lshrrev_b32_e32 v1, 4, v0                                // 0000003D3C08: 32020084
	v_bfe_u32 v2, v0, 4, 1                                     // 0000003D3C0C: D6100002 02050900
	s_lshl_b32 s2, s2, 4                                       // 0000003D3C14: 84028402
	v_and_b32_e32 v65, 15, v0                                  // 0000003D3C18: 3682008F
	v_and_b32_e32 v0, 12, v0                                   // 0000003D3C1C: 3600008C
	v_and_b32_e32 v1, 14, v1                                   // 0000003D3C20: 3602028E
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000003D3C24: BF8701A3
	v_lshlrev_b32_e32 v24, 4, v65                              // 0000003D3C28: 30308284
	v_or_b32_e32 v70, 16, v65                                  // 0000003D3C2C: 388C8290
	v_or3_b32 v64, v1, s2, v2                                  // 0000003D3C30: D6580040 04080501
	s_waitcnt lgkmcnt(0)                                       // 0000003D3C38: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000003D3C3C: BF8700C1
	v_mad_i64_i32 v[1:2], null, 0x154, v64, s[4:5]             // 0000003D3C40: D6FF7C01 001280FF 00000154
	s_load_b64 s[4:5], s[0:1], 0x20                            // 0000003D3C4C: F4040100 F8000020
	s_mov_b32 s0, exec_lo                                      // 0000003D3C54: BE80007E
	.long 0xd7006a08                                           // 0000003D3C58: D7006A08
	v_cndmask_b32_e32 v1, v1, v24, vcc_lo                      // 0000003D3C5C: 02023101
	v_add_co_ci_u32_e64 v9, null, 0, v2, vcc_lo                // 0000003D3C60: D5207C09 01AA0480
	.long 0xd7006a06                                           // 0000003D3C68: D7006A06
	v_cndmask_b32_e32 v1, v1, v0, vcc_lo                       // 0000003D3C6C: 02020101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003D3C70: BF870211
	v_add_co_ci_u32_e64 v7, null, 0, v2, vcc_lo                // 0000003D3C74: D5207C07 01AA0480
	.long 0xd7006a04                                           // 0000003D3C7C: D7006A04
	v_cndmask_b32_e32 v1, 0xd4000, v8, vcc_lo                  // 0000003D3C80: 020210FF 000D4000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003D3C88: BF870211
	v_add_co_ci_u32_e64 v5, null, 0, v9, vcc_lo                // 0000003D3C8C: D5207C05 01AA1280
	.long 0xd7006a0a                                           // 0000003D3C94: D7006A0A
	v_cndmask_b32_e32 v1, 0xd4000, v6, vcc_lo                  // 0000003D3C98: 02020CFF 000D4000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003D3CA0: BF8700A1
	v_add_co_ci_u32_e64 v11, null, 0, v7, vcc_lo               // 0000003D3CA4: D5207C0B 01AA0E80
	.long 0xd7006a14                                           // 0000003D3CAC: D7006A14
	v_cndmask_b32_e32 v1, 0x1a9000, v8, vcc_lo                 // 0000003D3CB0: 020210FF 001A9000
	v_add_co_ci_u32_e64 v21, null, 0, v9, vcc_lo               // 0000003D3CB8: D5207C15 01AA1280
	.long 0xd7006a0c                                           // 0000003D3CC0: D7006A0C
	v_cndmask_b32_e32 v1, 0x1a9000, v6, vcc_lo                 // 0000003D3CC4: 02020CFF 001A9000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003D3CCC: BF8700A1
	v_add_co_ci_u32_e64 v13, null, 0, v7, vcc_lo               // 0000003D3CD0: D5207C0D 01AA0E80
	.long 0xd7006a16                                           // 0000003D3CD8: D7006A16
	v_cndmask_b32_e32 v1, 0x27d000, v8, vcc_lo                 // 0000003D3CDC: 020210FF 0027D000
	v_add_co_ci_u32_e64 v23, null, 0, v9, vcc_lo               // 0000003D3CE4: D5207C17 01AA1280
	.long 0xd7006a0e                                           // 0000003D3CEC: D7006A0E
	v_cndmask_b32_e32 v1, 0x27d000, v6, vcc_lo                 // 0000003D3CF0: 02020CFF 0027D000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003D3CF8: BF870001
	v_add_co_ci_u32_e64 v15, null, 0, v7, vcc_lo               // 0000003D3CFC: D5207C0F 01AA0E80
	s_clause 0x7                                               // 0000003D3D04: BF850007
	global_load_b32 v75, v[6:7], off offset:320                // 0000003D3D08: DC520140 4B7C0006
	global_load_b128 v[60:63], v[4:5], off offset:2048         // 0000003D3D10: DC5E0800 3C7C0004
	global_load_b32 v74, v[10:11], off offset:2368             // 0000003D3D18: DC520940 4A7C000A
	global_load_b128 v[56:59], v[20:21], off                   // 0000003D3D20: DC5E0000 387C0014
	global_load_b32 v73, v[12:13], off offset:320              // 0000003D3D28: DC520140 497C000C
	global_load_b128 v[16:19], v[22:23], off offset:2048       // 0000003D3D30: DC5E0800 107C0016
	global_load_b32 v71, v[14:15], off offset:2368             // 0000003D3D38: DC520940 477C000E
	global_load_b128 v[52:55], v[8:9], off                     // 0000003D3D40: DC5E0000 347C0008
	v_cmpx_gt_u32_e32 20, v70                                  // 0000003D3D48: 7D988C94
	s_cbranch_execz 34                                         // 0000003D3D4C: BFA50022 <_ZN7halogen12_GLOBAL__N_17k_hcup8ILi4EEEvPKhPKtS5_PtPf+0x1d8>
	.long 0xd7006a19                                           // 0000003D3D50: D7006A19
	v_cndmask_b32_e32 v1, 0xd4000, v1, vcc_lo                  // 0000003D3D54: 020202FF 000D4000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003D3D5C: BF8700A1
	v_add_co_ci_u32_e64 v26, null, 0, v2, vcc_lo               // 0000003D3D60: D5207C1A 01AA0480
	.long 0xd7006a1b                                           // 0000003D3D68: D7006A1B
	v_cndmask_b32_e32 v1, 0x1a9000, v1, vcc_lo                 // 0000003D3D6C: 020202FF 001A9000
	v_add_co_ci_u32_e64 v28, null, 0, v2, vcc_lo               // 0000003D3D74: D5207C1C 01AA0480
	.long 0xd7006a00                                           // 0000003D3D7C: D7006A00
	v_cndmask_b32_e32 v1, 0x27d000, v1, vcc_lo                 // 0000003D3D80: 020202FF 0027D000
	s_clause 0x1                                               // 0000003D3D88: BF850001
	global_load_b128 v[12:15], v[8:9], off offset:256          // 0000003D3D8C: DC5E0100 0C7C0008
	global_load_b32 v68, v[1:2], off offset:336                // 0000003D3D94: DC520150 447C0001
	v_add_co_ci_u32_e64 v1, null, 0, v2, vcc_lo                // 0000003D3D9C: D5207C01 01AA0480
	s_clause 0x5                                               // 0000003D3DA4: BF850005
	global_load_b128 v[8:11], v[4:5], off offset:2304          // 0000003D3DA8: DC5E0900 087C0004
	global_load_b128 v[4:7], v[20:21], off offset:256          // 0000003D3DB0: DC5E0100 047C0014
	global_load_b32 v69, v[25:26], off offset:2384             // 0000003D3DB8: DC520950 457C0019
	global_load_b32 v67, v[27:28], off offset:336              // 0000003D3DC0: DC520150 437C001B
	global_load_b32 v66, v[0:1], off offset:2384               // 0000003D3DC8: DC520950 427C0000
	global_load_b128 v[0:3], v[22:23], off offset:2304         // 0000003D3DD0: DC5E0900 007C0016
	s_or_b32 exec_lo, exec_lo, s0                              // 0000003D3DD8: 8C7E007E
	v_lshlrev_b32_e32 v72, 1, v24                              // 0000003D3DDC: 30903081
	s_waitcnt vmcnt(0)                                         // 0000003D3DE0: BF8903F7
	v_cvt_f32_ubyte0_e32 v76, v52                              // 0000003D3DE4: 7E982334
	v_cvt_f32_ubyte1_e32 v77, v52                              // 0000003D3DE8: 7E9A2534
	v_cvt_f32_ubyte0_e32 v80, v53                              // 0000003D3DEC: 7EA02335
	v_cvt_f32_ubyte1_e32 v81, v53                              // 0000003D3DF0: 7EA22535
	s_clause 0x7                                               // 0000003D3DF4: BF850007
	global_load_b128 v[20:23], v72, s[6:7]                     // 0000003D3DF8: DC5E0000 14060048
	global_load_b128 v[24:27], v72, s[6:7] offset:640          // 0000003D3E00: DC5E0280 18060048
	global_load_b128 v[28:31], v72, s[6:7] offset:1280         // 0000003D3E08: DC5E0500 1C060048
	global_load_b128 v[32:35], v72, s[6:7] offset:1920         // 0000003D3E10: DC5E0780 20060048
	global_load_b128 v[36:39], v72, s[6:7] offset:16           // 0000003D3E18: DC5E0010 24060048
	global_load_b128 v[40:43], v72, s[6:7] offset:656          // 0000003D3E20: DC5E0290 28060048
	global_load_b128 v[44:47], v72, s[6:7] offset:1296         // 0000003D3E28: DC5E0510 2C060048
	global_load_b128 v[48:51], v72, s[6:7] offset:1936         // 0000003D3E30: DC5E0790 30060048
	v_fma_mix_f32 v76, v76, v75, v75 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D3E38: CC20604C 152E974C
	v_cvt_f32_ubyte0_e32 v83, v54                              // 0000003D3E40: 7EA62336
	v_fma_mix_f32 v77, v77, v75, v75 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D3E44: CC20604D 152E974D
	v_fma_mix_f32 v80, v80, v75, v75 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D3E4C: CC206050 152E9750
	v_cvt_f32_ubyte2_e32 v78, v52                              // 0000003D3E54: 7E9C2734
	v_bfe_u32 v124, v76, 16, 1                                 // 0000003D3E58: D610007C 0205214C
	v_cvt_f32_ubyte1_e32 v84, v54                              // 0000003D3E60: 7EA82536
	v_cvt_f32_ubyte0_e32 v86, v55                              // 0000003D3E64: 7EAC2337
	v_fma_mix_f32 v81, v81, v75, v75 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D3E68: CC206051 152E9751
	v_fma_mix_f32 v83, v83, v75, v75 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D3E70: CC206053 152E9753
	v_bfe_u32 v125, v77, 16, 1                                 // 0000003D3E78: D610007D 0205214D
	v_bfe_u32 v128, v80, 16, 1                                 // 0000003D3E80: D6100080 02052150
	v_add3_u32 v76, v76, v124, 0x7fff                          // 0000003D3E88: D655004C 03FEF94C 00007FFF
	v_cvt_f32_ubyte3_e32 v79, v52                              // 0000003D3E94: 7E9E2934
	v_cvt_f32_ubyte2_e32 v82, v53                              // 0000003D3E98: 7EA42735
	v_cvt_f32_ubyte3_e32 v53, v53                              // 0000003D3E9C: 7E6A2935
	v_cvt_f32_ubyte2_e32 v85, v54                              // 0000003D3EA0: 7EAA2736
	v_cvt_f32_ubyte3_e32 v54, v54                              // 0000003D3EA4: 7E6C2936
	v_cvt_f32_ubyte1_e32 v87, v55                              // 0000003D3EA8: 7EAE2537
	v_cvt_f32_ubyte2_e32 v88, v55                              // 0000003D3EAC: 7EB02737
	v_cvt_f32_ubyte3_e32 v55, v55                              // 0000003D3EB0: 7E6E2937
	v_cvt_f32_ubyte0_e32 v89, v60                              // 0000003D3EB4: 7EB2233C
	.long 0x7f683880                                           // 0000003D3EB8: 7F683880
	v_fma_mix_f32 v78, v78, v75, v75 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D3EBC: CC20604E 152E974E
	v_fma_mix_f32 v84, v84, v75, v75 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D3EC4: CC206054 152E9754
	v_fma_mix_f32 v86, v86, v75, v75 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D3ECC: CC206056 152E9756
	v_bfe_u32 v129, v81, 16, 1                                 // 0000003D3ED4: D6100081 02052151
	v_bfe_u32 v132, v83, 16, 1                                 // 0000003D3EDC: D6100084 02052153
	v_add3_u32 v77, v77, v125, 0x7fff                          // 0000003D3EE4: D655004D 03FEFB4D 00007FFF
	v_add3_u32 v80, v80, v128, 0x7fff                          // 0000003D3EF0: D6550050 03FF0150 00007FFF
	.long 0x7e6839cc                                           // 0000003D3EFC: 7E6839CC
	v_cvt_f32_ubyte1_e32 v90, v60                              // 0000003D3F00: 7EB4253C
	v_cvt_f32_ubyte2_e32 v91, v60                              // 0000003D3F04: 7EB6273C
	v_cvt_f32_ubyte0_e32 v92, v61                              // 0000003D3F08: 7EB8233D
	v_fma_mix_f32 v79, v79, v75, v75 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D3F0C: CC20604F 152E974F
	v_fma_mix_f32 v82, v82, v75, v75 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D3F14: CC206052 152E9752
	v_fma_mix_f32 v53, v53, v75, v75 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D3F1C: CC206035 152E9735
	v_fma_mix_f32 v85, v85, v75, v75 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D3F24: CC206055 152E9755
	v_fma_mix_f32 v54, v54, v75, v75 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D3F2C: CC206036 152E9736
	v_fma_mix_f32 v87, v87, v75, v75 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D3F34: CC206057 152E9757
	v_fma_mix_f32 v88, v88, v75, v75 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D3F3C: CC206058 152E9758
	v_fma_mix_f32 v55, v55, v75, v75 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D3F44: CC206037 152E9737
	v_fma_mix_f32 v75, v89, v74, v74 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D3F4C: CC20604B 152A9559
	v_bfe_u32 v126, v78, 16, 1                                 // 0000003D3F54: D610007E 0205214E
	v_bfe_u32 v133, v84, 16, 1                                 // 0000003D3F5C: D6100085 02052154
	v_bfe_u32 v136, v86, 16, 1                                 // 0000003D3F64: D6100088 02052156
	v_add3_u32 v81, v81, v129, 0x7fff                          // 0000003D3F6C: D6550051 03FF0351 00007FFF
	v_add3_u32 v83, v83, v132, 0x7fff                          // 0000003D3F78: D6550053 03FF0953 00007FFF
	v_and_or_b32 v77, 0xffff0000, v77, v52                     // 0000003D3F84: D657004D 04D29AFF FFFF0000
	.long 0x7e6839d0                                           // 0000003D3F90: 7E6839D0
	v_cvt_f32_ubyte1_e32 v93, v61                              // 0000003D3F94: 7EBA253D
	v_cvt_f32_ubyte2_e32 v94, v61                              // 0000003D3F98: 7EBC273D
	v_cvt_f32_ubyte0_e32 v95, v62                              // 0000003D3F9C: 7EBE233E
	v_fma_mix_f32 v89, v90, v74, v74 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D3FA0: CC206059 152A955A
	v_fma_mix_f32 v90, v91, v74, v74 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D3FA8: CC20605A 152A955B
	v_fma_mix_f32 v91, v92, v74, v74 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D3FB0: CC20605B 152A955C
	v_bfe_u32 v127, v79, 16, 1                                 // 0000003D3FB8: D610007F 0205214F
	v_bfe_u32 v130, v82, 16, 1                                 // 0000003D3FC0: D6100082 02052152
	v_bfe_u32 v137, v87, 16, 1                                 // 0000003D3FC8: D6100089 02052157
	v_add3_u32 v78, v78, v126, 0x7fff                          // 0000003D3FD0: D655004E 03FEFD4E 00007FFF
	v_bfe_u32 v126, v75, 16, 1                                 // 0000003D3FDC: D610007E 0205214B
	v_add3_u32 v84, v84, v133, 0x7fff                          // 0000003D3FE4: D6550054 03FF0B54 00007FFF
	v_add3_u32 v86, v86, v136, 0x7fff                          // 0000003D3FF0: D6550056 03FF1156 00007FFF
	v_and_or_b32 v81, 0xffff0000, v81, v52                     // 0000003D3FFC: D6570051 04D2A2FF FFFF0000
	.long 0x7e6839d3                                           // 0000003D4008: 7E6839D3
	v_cvt_f32_ubyte1_e32 v96, v62                              // 0000003D400C: 7EC0253E
	v_cvt_f32_ubyte2_e32 v97, v62                              // 0000003D4010: 7EC2273E
	v_cvt_f32_ubyte0_e32 v98, v63                              // 0000003D4014: 7EC4233F
	v_fma_mix_f32 v92, v93, v74, v74 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D4018: CC20605C 152A955D
	v_fma_mix_f32 v93, v94, v74, v74 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D4020: CC20605D 152A955E
	v_fma_mix_f32 v94, v95, v74, v74 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D4028: CC20605E 152A955F
	v_bfe_u32 v131, v53, 16, 1                                 // 0000003D4030: D6100083 02052135
	v_bfe_u32 v134, v85, 16, 1                                 // 0000003D4038: D6100086 02052155
	v_add3_u32 v79, v79, v127, 0x7fff                          // 0000003D4040: D655004F 03FEFF4F 00007FFF
	v_bfe_u32 v127, v89, 16, 1                                 // 0000003D404C: D610007F 02052159
	v_add3_u32 v82, v82, v130, 0x7fff                          // 0000003D4054: D6550052 03FF0552 00007FFF
	v_bfe_u32 v130, v91, 16, 1                                 // 0000003D4060: D6100082 0205215B
	v_add3_u32 v87, v87, v137, 0x7fff                          // 0000003D4068: D6550057 03FF1357 00007FFF
	v_add3_u32 v75, v75, v126, 0x7fff                          // 0000003D4074: D655004B 03FEFD4B 00007FFF
	v_and_or_b32 v84, 0xffff0000, v84, v52                     // 0000003D4080: D6570054 04D2A8FF FFFF0000
	.long 0x7e6839d6                                           // 0000003D408C: 7E6839D6
	v_cvt_f32_ubyte3_e32 v60, v60                              // 0000003D4090: 7E78293C
	v_cvt_f32_ubyte1_e32 v99, v63                              // 0000003D4094: 7EC6253F
	v_cvt_f32_ubyte2_e32 v100, v63                             // 0000003D4098: 7EC8273F
	v_cvt_f32_ubyte0_e32 v102, v56                             // 0000003D409C: 7ECC2338
	v_fma_mix_f32 v95, v96, v74, v74 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D40A0: CC20605F 152A9560
	v_fma_mix_f32 v96, v97, v74, v74 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D40A8: CC206060 152A9561
	v_fma_mix_f32 v97, v98, v74, v74 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D40B0: CC206061 152A9562
	v_bfe_u32 v135, v54, 16, 1                                 // 0000003D40B8: D6100087 02052136
	v_bfe_u32 v124, v88, 16, 1                                 // 0000003D40C0: D610007C 02052158
	v_add3_u32 v53, v53, v131, 0x7fff                          // 0000003D40C8: D6550035 03FF0735 00007FFF
	v_bfe_u32 v131, v92, 16, 1                                 // 0000003D40D4: D6100083 0205215C
	v_add3_u32 v85, v85, v134, 0x7fff                          // 0000003D40DC: D6550055 03FF0D55 00007FFF
	v_bfe_u32 v134, v94, 16, 1                                 // 0000003D40E8: D6100086 0205215E
	v_add3_u32 v89, v89, v127, 0x7fff                          // 0000003D40F0: D6550059 03FEFF59 00007FFF
	v_add3_u32 v91, v91, v130, 0x7fff                          // 0000003D40FC: D655005B 03FF055B 00007FFF
	v_and_or_b32 v87, 0xffff0000, v87, v52                     // 0000003D4108: D6570057 04D2AEFF FFFF0000
	.long 0x7e6839cb                                           // 0000003D4114: 7E6839CB
	v_cvt_f32_ubyte3_e32 v61, v61                              // 0000003D4118: 7E7A293D
	v_cvt_f32_ubyte3_e32 v62, v62                              // 0000003D411C: 7E7C293E
	v_cvt_f32_ubyte3_e32 v101, v63                             // 0000003D4120: 7ECA293F
	v_cvt_f32_ubyte1_e32 v103, v56                             // 0000003D4124: 7ECE2538
	v_cvt_f32_ubyte2_e32 v104, v56                             // 0000003D4128: 7ED02738
	v_cvt_f32_ubyte0_e32 v105, v57                             // 0000003D412C: 7ED22339
	v_cvt_f32_ubyte1_e32 v106, v57                             // 0000003D4130: 7ED42539
	v_cvt_f32_ubyte0_e32 v108, v58                             // 0000003D4134: 7ED8233A
	v_cvt_f32_ubyte2_e32 v110, v58                             // 0000003D4138: 7EDC273A
	v_fma_mix_f32 v60, v60, v74, v74 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D413C: CC20603C 152A953C
	v_fma_mix_f32 v98, v99, v74, v74 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D4144: CC206062 152A9563
	v_fma_mix_f32 v99, v100, v74, v74 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D414C: CC206063 152A9564
	v_fma_mix_f32 v100, v102, v73, v73 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D4154: CC206064 15269366
	v_bfe_u32 v125, v55, 16, 1                                 // 0000003D415C: D610007D 02052137
	v_bfe_u32 v128, v90, 16, 1                                 // 0000003D4164: D6100080 0205215A
	v_add3_u32 v54, v54, v135, 0x7fff                          // 0000003D416C: D6550036 03FF0F36 00007FFF
	v_bfe_u32 v135, v95, 16, 1                                 // 0000003D4178: D6100087 0205215F
	v_add3_u32 v88, v88, v124, 0x7fff                          // 0000003D4180: D6550058 03FEF958 00007FFF
	v_bfe_u32 v124, v97, 16, 1                                 // 0000003D418C: D610007C 02052161
	v_add3_u32 v92, v92, v131, 0x7fff                          // 0000003D4194: D655005C 03FF075C 00007FFF
	v_add3_u32 v94, v94, v134, 0x7fff                          // 0000003D41A0: D655005E 03FF0D5E 00007FFF
	v_and_or_b32 v89, 0xffff0000, v89, v52                     // 0000003D41AC: D6570059 04D2B2FF FFFF0000
	.long 0x7e6839db                                           // 0000003D41B8: 7E6839DB
	v_cvt_f32_ubyte3_e32 v56, v56                              // 0000003D41BC: 7E702938
	v_cvt_f32_ubyte2_e32 v107, v57                             // 0000003D41C0: 7ED62739
	v_cvt_f32_ubyte3_e32 v57, v57                              // 0000003D41C4: 7E722939
	v_cvt_f32_ubyte1_e32 v109, v58                             // 0000003D41C8: 7EDA253A
	v_cvt_f32_ubyte3_e32 v58, v58                              // 0000003D41CC: 7E74293A
	v_cvt_f32_ubyte0_e32 v111, v59                             // 0000003D41D0: 7EDE233B
	v_cvt_f32_ubyte1_e32 v112, v59                             // 0000003D41D4: 7EE0253B
	v_cvt_f32_ubyte2_e32 v113, v59                             // 0000003D41D8: 7EE2273B
	v_cvt_f32_ubyte3_e32 v59, v59                              // 0000003D41DC: 7E76293B
	v_fma_mix_f32 v61, v61, v74, v74 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D41E0: CC20603D 152A953D
	v_fma_mix_f32 v62, v62, v74, v74 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D41E8: CC20603E 152A953E
	v_fma_mix_f32 v74, v101, v74, v74 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D41F0: CC20604A 152A9565
	v_fma_mix_f32 v101, v103, v73, v73 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D41F8: CC206065 15269367
	v_fma_mix_f32 v102, v104, v73, v73 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D4200: CC206066 15269368
	v_fma_mix_f32 v103, v105, v73, v73 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D4208: CC206067 15269369
	v_fma_mix_f32 v104, v106, v73, v73 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D4210: CC206068 1526936A
	v_fma_mix_f32 v106, v108, v73, v73 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D4218: CC20606A 1526936C
	v_fma_mix_f32 v108, v110, v73, v73 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D4220: CC20606C 1526936E
	v_bfe_u32 v129, v60, 16, 1                                 // 0000003D4228: D6100081 0205213C
	v_bfe_u32 v132, v93, 16, 1                                 // 0000003D4230: D6100084 0205215D
	v_add3_u32 v55, v55, v125, 0x7fff                          // 0000003D4238: D6550037 03FEFB37 00007FFF
	v_bfe_u32 v125, v98, 16, 1                                 // 0000003D4244: D610007D 02052162
	v_add3_u32 v90, v90, v128, 0x7fff                          // 0000003D424C: D655005A 03FF015A 00007FFF
	v_bfe_u32 v128, v100, 16, 1                                // 0000003D4258: D6100080 02052164
	v_add3_u32 v95, v95, v135, 0x7fff                          // 0000003D4260: D655005F 03FF0F5F 00007FFF
	v_add3_u32 v97, v97, v124, 0x7fff                          // 0000003D426C: D6550061 03FEF961 00007FFF
	v_and_or_b32 v92, 0xffff0000, v92, v52                     // 0000003D4278: D657005C 04D2B8FF FFFF0000
	.long 0x7e6839de                                           // 0000003D4284: 7E6839DE
	v_fma_mix_f32 v56, v56, v73, v73 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D4288: CC206038 15269338
	v_fma_mix_f32 v105, v107, v73, v73 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D4290: CC206069 1526936B
	v_fma_mix_f32 v57, v57, v73, v73 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D4298: CC206039 15269339
	v_fma_mix_f32 v107, v109, v73, v73 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D42A0: CC20606B 1526936D
	v_fma_mix_f32 v58, v58, v73, v73 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D42A8: CC20603A 1526933A
	v_fma_mix_f32 v109, v111, v73, v73 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D42B0: CC20606D 1526936F
	v_fma_mix_f32 v110, v112, v73, v73 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D42B8: CC20606E 15269370
	v_fma_mix_f32 v111, v113, v73, v73 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D42C0: CC20606F 15269371
	v_fma_mix_f32 v59, v59, v73, v73 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D42C8: CC20603B 1526933B
	v_bfe_u32 v133, v61, 16, 1                                 // 0000003D42D0: D6100085 0205213D
	v_bfe_u32 v136, v96, 16, 1                                 // 0000003D42D8: D6100088 02052160
	v_bfe_u32 v126, v99, 16, 1                                 // 0000003D42E0: D610007E 02052163
	v_add3_u32 v60, v60, v129, 0x7fff                          // 0000003D42E8: D655003C 03FF033C 00007FFF
	v_bfe_u32 v129, v101, 16, 1                                // 0000003D42F4: D6100081 02052165
	v_add3_u32 v93, v93, v132, 0x7fff                          // 0000003D42FC: D655005D 03FF095D 00007FFF
	v_bfe_u32 v132, v103, 16, 1                                // 0000003D4308: D6100084 02052167
	v_bfe_u32 v76, v108, 16, 1                                 // 0000003D4310: D610004C 0205216C
	v_add3_u32 v98, v98, v125, 0x7fff                          // 0000003D4318: D6550062 03FEFB62 00007FFF
	v_add3_u32 v83, v100, v128, 0x7fff                         // 0000003D4324: D6550053 03FF0164 00007FFF
	.long 0x7e9239ce                                           // 0000003D4330: 7E9239CE
	v_and_or_b32 v78, 0xffff0000, v95, v52                     // 0000003D4334: D657004E 04D2BEFF FFFF0000
	.long 0x7e6839e1                                           // 0000003D4340: 7E6839E1
	v_bfe_u32 v137, v62, 16, 1                                 // 0000003D4344: D6100089 0205213E
	v_bfe_u32 v127, v74, 16, 1                                 // 0000003D434C: D610007F 0205214A
	v_bfe_u32 v130, v102, 16, 1                                // 0000003D4354: D6100082 02052166
	v_add3_u32 v61, v61, v133, 0x7fff                          // 0000003D435C: D655003D 03FF0B3D 00007FFF
	v_bfe_u32 v133, v104, 16, 1                                // 0000003D4368: D6100085 02052168
	v_bfe_u32 v134, v105, 16, 1                                // 0000003D4370: D6100086 02052169
	v_add3_u32 v96, v96, v136, 0x7fff                          // 0000003D4378: D6550060 03FF1160 00007FFF
	v_bfe_u32 v136, v106, 16, 1                                // 0000003D4384: D6100088 0205216A
	v_add3_u32 v99, v99, v126, 0x7fff                          // 0000003D438C: D6550063 03FEFD63 00007FFF
	v_bfe_u32 v126, v111, 16, 1                                // 0000003D4398: D610007E 0205216F
	v_add3_u32 v100, v101, v129, 0x7fff                        // 0000003D43A0: D6550064 03FF0365 00007FFF
	v_add3_u32 v86, v103, v132, 0x7fff                         // 0000003D43AC: D6550056 03FF0967 00007FFF
	v_add3_u32 v76, v108, v76, 0x7fff                          // 0000003D43B8: D655004C 03FE996C 00007FFF
	.long 0x7ee039d2                                           // 0000003D43C4: 7EE039D2
	v_and_or_b32 v82, 0xffff0000, v98, v52                     // 0000003D43C8: D6570052 04D2C4FF FFFF0000
	.long 0x7e6839d3                                           // 0000003D43D4: 7E6839D3
	.long 0x7f9239b4                                           // 0000003D43D8: 7F9239B4
	v_add3_u32 v62, v62, v137, 0x7fff                          // 0000003D43DC: D655003E 03FF133E 00007FFF
	v_bfe_u32 v137, v107, 16, 1                                // 0000003D43E8: D6100089 0205216B
	v_bfe_u32 v124, v58, 16, 1                                 // 0000003D43F0: D610007C 0205213A
	v_bfe_u32 v125, v109, 16, 1                                // 0000003D43F8: D610007D 0205216D
	v_add3_u32 v74, v74, v127, 0x7fff                          // 0000003D4400: D655004A 03FEFF4A 00007FFF
	v_bfe_u32 v127, v59, 16, 1                                 // 0000003D440C: D610007F 0205213B
	v_add3_u32 v101, v102, v130, 0x7fff                        // 0000003D4414: D6550065 03FF0566 00007FFF
	v_add3_u32 v102, v104, v133, 0x7fff                        // 0000003D4420: D6550066 03FF0B68 00007FFF
	v_add3_u32 v103, v105, v134, 0x7fff                        // 0000003D442C: D6550067 03FF0D69 00007FFF
	v_add3_u32 v75, v106, v136, 0x7fff                         // 0000003D4438: D655004B 03FF116A 00007FFF
	v_add3_u32 v105, v111, v126, 0x7fff                        // 0000003D4444: D6550069 03FEFD6F 00007FFF
	.long 0x7ef439cc                                           // 0000003D4450: 7EF439CC
	v_and_or_b32 v76, 0xffff0000, v100, v52                    // 0000003D4454: D657004C 04D2C8FF FFFF0000
	.long 0x7e6839d6                                           // 0000003D4460: 7E6839D6
	.long 0x7fe839b4                                           // 0000003D4464: 7FE839B4
	.long 0x7ff439b4                                           // 0000003D4468: 7FF439B4
	.long 0x7ff639b4                                           // 0000003D446C: 7FF639B4
	v_bfe_u32 v131, v56, 16, 1                                 // 0000003D4470: D6100083 02052138
	v_add3_u32 v104, v107, v137, 0x7fff                        // 0000003D4478: D6550068 03FF136B 00007FFF
	v_add3_u32 v58, v58, v124, 0x7fff                          // 0000003D4484: D655003A 03FEF93A 00007FFF
	v_add3_u32 v91, v109, v125, 0x7fff                         // 0000003D4490: D655005B 03FEFB6D 00007FFF
	v_add3_u32 v59, v59, v127, 0x7fff                          // 0000003D449C: D655003B 03FEFF3B 00007FFF
	.long 0x7ee839da                                           // 0000003D44A8: 7EE839DA
	.long 0x7ef639e9                                           // 0000003D44AC: 7EF639E9
	v_and_or_b32 v73, 0xffff0000, v79, v73                     // 0000003D44B0: D6570049 05269EFF FFFF0000
	v_and_or_b32 v79, 0xffff0000, v102, v52                    // 0000003D44BC: D657004F 04D2CCFF FFFF0000
	.long 0x7e6839cb                                           // 0000003D44C8: 7E6839CB
	.long 0x7ff039b4                                           // 0000003D44CC: 7FF039B4
	v_add3_u32 v56, v56, v131, 0x7fff                          // 0000003D44D0: D6550038 03FF0738 00007FFF
	.long 0x7ee239d5                                           // 0000003D44DC: 7EE239D5
	.long 0x7ee639d8                                           // 0000003D44E0: 7EE639D8
	.long 0x7ef039e5                                           // 0000003D44E4: 7EF039E5
	v_and_or_b32 v60, 0xffff0000, v60, v116                    // 0000003D44E8: D657003C 05D278FF FFFF0000
	v_and_or_b32 v75, 0xffff0000, v104, v52                    // 0000003D44F4: D657004B 04D2D0FF FFFF0000
	.long 0x7e6839db                                           // 0000003D4500: 7E6839DB
	v_and_or_b32 v83, 0xffff0000, v58, v122                    // 0000003D4504: D6570053 05EA74FF FFFF0000
	v_and_or_b32 v85, 0xffff0000, v59, v123                    // 0000003D4510: D6570055 05EE76FF FFFF0000
	.long 0x7fe039b4                                           // 0000003D451C: 7FE039B4
	.long 0x7fea39b4                                           // 0000003D4520: 7FEA39B4
	v_bfe_u32 v135, v57, 16, 1                                 // 0000003D4524: D6100087 02052139
	.long 0x7eea39dd                                           // 0000003D452C: 7EEA39DD
	v_and_or_b32 v56, 0xffff0000, v56, v120                    // 0000003D4530: D6570038 05E270FF FFFF0000
	.long 0x7ff239b4                                           // 0000003D453C: 7FF239B4
	.long 0x7ef239e7                                           // 0000003D4540: 7EF239E7
	v_add3_u32 v57, v57, v135, 0x7fff                          // 0000003D4544: D6550039 03FF0F39 00007FFF
	v_and_or_b32 v53, 0xffff0000, v53, v112                    // 0000003D4550: D6570035 05C26AFF FFFF0000
	v_and_or_b32 v61, 0xffff0000, v61, v117                    // 0000003D455C: D657003D 05D67AFF FFFF0000
	.long 0x7fe239b4                                           // 0000003D4568: 7FE239B4
	.long 0x7fec39b4                                           // 0000003D456C: 7FEC39B4
	.long 0x7eec39e0                                           // 0000003D4570: 7EEC39E0
	v_and_or_b32 v57, 0xffff0000, v57, v121                    // 0000003D4574: D6570039 05E672FF FFFF0000
	v_bfe_u32 v80, v110, 16, 1                                 // 0000003D4580: D6100050 0205216E
	v_and_or_b32 v54, 0xffff0000, v54, v113                    // 0000003D4588: D6570036 05C66CFF FFFF0000
	.long 0x7fe639b4                                           // 0000003D4594: 7FE639B4
	v_and_or_b32 v62, 0xffff0000, v62, v118                    // 0000003D4598: D657003E 05DA7CFF FFFF0000
	.long 0x7fee39b4                                           // 0000003D45A4: 7FEE39B4
	v_add3_u32 v80, v110, v80, 0x7fff                          // 0000003D45A8: D6550050 03FEA16E 00007FFF
	.long 0x7eee39e3                                           // 0000003D45B4: 7EEE39E3
	v_and_or_b32 v55, 0xffff0000, v55, v115                    // 0000003D45B8: D6570037 05CE6EFF FFFF0000
	v_cvt_f32_ubyte0_e32 v63, v16                              // 0000003D45C4: 7E7E2310
	v_cvt_f32_ubyte2_e32 v114, v16                             // 0000003D45C8: 7EE42710
	v_and_or_b32 v80, 0xffff0000, v80, v52                     // 0000003D45CC: D6570050 04D2A0FF FFFF0000
	v_and_or_b32 v74, 0xffff0000, v74, v119                    // 0000003D45D8: D657004A 05DE94FF FFFF0000
	s_mov_b32 s0, exec_lo                                      // 0000003D45E4: BE80007E
	s_waitcnt vmcnt(7)                                         // 0000003D45E8: BF891FF7
	v_dot2_f32_bf16 v58, v20, v77, 0                           // 0000003D45EC: CC1A403A 1A029B14
	s_waitcnt vmcnt(6)                                         // 0000003D45F4: BF891BF7
	v_dot2_f32_bf16 v59, v24, v77, 0                           // 0000003D45F8: CC1A403B 1A029B18
	s_waitcnt vmcnt(5)                                         // 0000003D4600: BF8917F7
	v_dot2_f32_bf16 v86, v28, v77, 0                           // 0000003D4604: CC1A4056 1A029B1C
	s_waitcnt vmcnt(4)                                         // 0000003D460C: BF8913F7
	v_dot2_f32_bf16 v77, v32, v77, 0                           // 0000003D4610: CC1A404D 1A029B20
	v_dot2_f32_bf16 v88, v20, v89, 0                           // 0000003D4618: CC1A4058 1A02B314
	v_dot2_f32_bf16 v90, v24, v89, 0                           // 0000003D4620: CC1A405A 1A02B318
	v_dot2_f32_bf16 v91, v28, v89, 0                           // 0000003D4628: CC1A405B 1A02B31C
	v_dot2_f32_bf16 v89, v32, v89, 0                           // 0000003D4630: CC1A4059 1A02B320
	v_dot2_f32_bf16 v93, v20, v76, 0                           // 0000003D4638: CC1A405D 1A029914
	v_dot2_f32_bf16 v94, v24, v76, 0                           // 0000003D4640: CC1A405E 1A029918
	v_dot2_f32_bf16 v95, v28, v76, 0                           // 0000003D4648: CC1A405F 1A02991C
	v_dot2_f32_bf16 v76, v32, v76, 0                           // 0000003D4650: CC1A404C 1A029920
	v_dot2_f32_bf16 v58, v21, v73, v58                         // 0000003D4658: CC1A403A 1CEA9315
	v_dot2_f32_bf16 v59, v25, v73, v59                         // 0000003D4660: CC1A403B 1CEE9319
	v_dot2_f32_bf16 v86, v29, v73, v86                         // 0000003D4668: CC1A4056 1D5A931D
	v_dot2_f32_bf16 v73, v33, v73, v77                         // 0000003D4670: CC1A4049 1D369321
	v_dot2_f32_bf16 v77, v21, v60, v88                         // 0000003D4678: CC1A404D 1D627915
	v_dot2_f32_bf16 v88, v25, v60, v90                         // 0000003D4680: CC1A4058 1D6A7919
	v_dot2_f32_bf16 v90, v29, v60, v91                         // 0000003D4688: CC1A405A 1D6E791D
	v_dot2_f32_bf16 v60, v33, v60, v89                         // 0000003D4690: CC1A403C 1D667921
	v_dot2_f32_bf16 v89, v21, v56, v93                         // 0000003D4698: CC1A4059 1D767115
	v_dot2_f32_bf16 v91, v25, v56, v94                         // 0000003D46A0: CC1A405B 1D7A7119
	v_dot2_f32_bf16 v93, v29, v56, v95                         // 0000003D46A8: CC1A405D 1D7E711D
	v_dot2_f32_bf16 v56, v33, v56, v76                         // 0000003D46B0: CC1A4038 1D327121
	v_dot2_f32_bf16 v58, v22, v81, v58                         // 0000003D46B8: CC1A403A 1CEAA316
	v_dot2_f32_bf16 v59, v26, v81, v59                         // 0000003D46C0: CC1A403B 1CEEA31A
	v_dot2_f32_bf16 v76, v30, v81, v86                         // 0000003D46C8: CC1A404C 1D5AA31E
	v_dot2_f32_bf16 v73, v34, v81, v73                         // 0000003D46D0: CC1A4049 1D26A322
	v_dot2_f32_bf16 v77, v22, v92, v77                         // 0000003D46D8: CC1A404D 1D36B916
	v_dot2_f32_bf16 v81, v26, v92, v88                         // 0000003D46E0: CC1A4051 1D62B91A
	v_dot2_f32_bf16 v86, v30, v92, v90                         // 0000003D46E8: CC1A4056 1D6AB91E
	v_dot2_f32_bf16 v60, v34, v92, v60                         // 0000003D46F0: CC1A403C 1CF2B922
	v_dot2_f32_bf16 v88, v22, v79, v89                         // 0000003D46F8: CC1A4058 1D669F16
	v_dot2_f32_bf16 v89, v26, v79, v91                         // 0000003D4700: CC1A4059 1D6E9F1A
	v_dot2_f32_bf16 v90, v30, v79, v93                         // 0000003D4708: CC1A405A 1D769F1E
	v_dot2_f32_bf16 v56, v34, v79, v56                         // 0000003D4710: CC1A4038 1CE29F22
	v_dot2_f32_bf16 v58, v23, v53, v58                         // 0000003D4718: CC1A403A 1CEA6B17
	v_dot2_f32_bf16 v59, v27, v53, v59                         // 0000003D4720: CC1A403B 1CEE6B1B
	v_dot2_f32_bf16 v76, v31, v53, v76                         // 0000003D4728: CC1A404C 1D326B1F
	v_dot2_f32_bf16 v53, v35, v53, v73                         // 0000003D4730: CC1A4035 1D266B23
	v_dot2_f32_bf16 v73, v23, v61, v77                         // 0000003D4738: CC1A4049 1D367B17
	v_dot2_f32_bf16 v77, v27, v61, v81                         // 0000003D4740: CC1A404D 1D467B1B
	v_dot2_f32_bf16 v79, v31, v61, v86                         // 0000003D4748: CC1A404F 1D5A7B1F
	v_dot2_f32_bf16 v60, v35, v61, v60                         // 0000003D4750: CC1A403C 1CF27B23
	v_dot2_f32_bf16 v61, v23, v57, v88                         // 0000003D4758: CC1A403D 1D627317
	v_dot2_f32_bf16 v81, v27, v57, v89                         // 0000003D4760: CC1A4051 1D66731B
	v_dot2_f32_bf16 v86, v31, v57, v90                         // 0000003D4768: CC1A4056 1D6A731F
	v_dot2_f32_bf16 v88, v35, v57, v56                         // 0000003D4770: CC1A4058 1CE27323
	s_waitcnt vmcnt(3)                                         // 0000003D4778: BF890FF7
	v_dot2_f32_bf16 v56, v36, v84, v58                         // 0000003D477C: CC1A4038 1CEAA924
	s_waitcnt vmcnt(2)                                         // 0000003D4784: BF890BF7
	v_dot2_f32_bf16 v57, v40, v84, v59                         // 0000003D4788: CC1A4039 1CEEA928
	s_waitcnt vmcnt(1)                                         // 0000003D4790: BF8907F7
	v_dot2_f32_bf16 v58, v44, v84, v76                         // 0000003D4794: CC1A403A 1D32A92C
	s_waitcnt vmcnt(0)                                         // 0000003D479C: BF8903F7
	v_dot2_f32_bf16 v53, v48, v84, v53                         // 0000003D47A0: CC1A4035 1CD6A930
	v_dot2_f32_bf16 v59, v36, v78, v73                         // 0000003D47A8: CC1A403B 1D269D24
	v_dot2_f32_bf16 v73, v40, v78, v77                         // 0000003D47B0: CC1A4049 1D369D28
	v_dot2_f32_bf16 v76, v44, v78, v79                         // 0000003D47B8: CC1A404C 1D3E9D2C
	v_dot2_f32_bf16 v60, v48, v78, v60                         // 0000003D47C0: CC1A403C 1CF29D30
	v_dot2_f32_bf16 v61, v36, v75, v61                         // 0000003D47C8: CC1A403D 1CF69724
	v_dot2_f32_bf16 v77, v40, v75, v81                         // 0000003D47D0: CC1A404D 1D469728
	v_dot2_f32_bf16 v56, v37, v54, v56                         // 0000003D47D8: CC1A4038 1CE26D25
	v_dot2_f32_bf16 v57, v41, v54, v57                         // 0000003D47E0: CC1A4039 1CE66D29
	v_dot2_f32_bf16 v58, v45, v54, v58                         // 0000003D47E8: CC1A403A 1CEA6D2D
	v_dot2_f32_bf16 v53, v49, v54, v53                         // 0000003D47F0: CC1A4035 1CD66D31
	v_dot2_f32_bf16 v54, v37, v62, v59                         // 0000003D47F8: CC1A4036 1CEE7D25
	v_dot2_f32_bf16 v59, v41, v62, v73                         // 0000003D4800: CC1A403B 1D267D29
	v_dot2_f32_bf16 v73, v45, v62, v76                         // 0000003D4808: CC1A4049 1D327D2D
	v_dot2_f32_bf16 v60, v49, v62, v60                         // 0000003D4810: CC1A403C 1CF27D31
	v_dot2_f32_bf16 v78, v44, v75, v86                         // 0000003D4818: CC1A404E 1D5A972C
	v_dot2_f32_bf16 v61, v37, v83, v61                         // 0000003D4820: CC1A403D 1CF6A725
	v_dot2_f32_bf16 v62, v41, v83, v77                         // 0000003D4828: CC1A403E 1D36A729
	v_dot2_f32_bf16 v56, v38, v87, v56                         // 0000003D4830: CC1A4038 1CE2AF26
	v_dot2_f32_bf16 v57, v42, v87, v57                         // 0000003D4838: CC1A4039 1CE6AF2A
	v_dot2_f32_bf16 v58, v46, v87, v58                         // 0000003D4840: CC1A403A 1CEAAF2E
	v_dot2_f32_bf16 v53, v50, v87, v53                         // 0000003D4848: CC1A4035 1CD6AF32
	v_dot2_f32_bf16 v54, v38, v82, v54                         // 0000003D4850: CC1A4036 1CDAA526
	v_dot2_f32_bf16 v59, v42, v82, v59                         // 0000003D4858: CC1A403B 1CEEA52A
	v_dot2_f32_bf16 v73, v46, v82, v73                         // 0000003D4860: CC1A4049 1D26A52E
	v_dot2_f32_bf16 v60, v50, v82, v60                         // 0000003D4868: CC1A403C 1CF2A532
	v_dot2_f32_bf16 v76, v45, v83, v78                         // 0000003D4870: CC1A404C 1D3AA72D
	v_dot2_f32_bf16 v61, v38, v80, v61                         // 0000003D4878: CC1A403D 1CF6A126
	v_dot2_f32_bf16 v62, v42, v80, v62                         // 0000003D4880: CC1A403E 1CFAA12A
	v_dot2_f32_bf16 v56, v39, v55, v56                         // 0000003D4888: CC1A4038 1CE26F27
	v_dot2_f32_bf16 v57, v43, v55, v57                         // 0000003D4890: CC1A4039 1CE66F2B
	v_dot2_f32_bf16 v58, v47, v55, v58                         // 0000003D4898: CC1A403A 1CEA6F2F
	v_dot2_f32_bf16 v53, v51, v55, v53                         // 0000003D48A0: CC1A4035 1CD66F33
	v_dot2_f32_bf16 v54, v39, v74, v54                         // 0000003D48A8: CC1A4036 1CDA9527
	v_dot2_f32_bf16 v55, v43, v74, v59                         // 0000003D48B0: CC1A4037 1CEE952B
	v_dot2_f32_bf16 v73, v47, v74, v73                         // 0000003D48B8: CC1A4049 1D26952F
	v_dot2_f32_bf16 v74, v51, v74, v60                         // 0000003D48C0: CC1A404A 1CF29533
	v_dot2_f32_bf16 v76, v46, v80, v76                         // 0000003D48C8: CC1A404C 1D32A12E
	v_dot2_f32_bf16 v77, v39, v85, v61                         // 0000003D48D0: CC1A404D 1CF6AB27
	v_dot2_f32_bf16 v78, v43, v85, v62                         // 0000003D48D8: CC1A404E 1CFAAB2B
	v_dual_add_f32 v62, 0, v56 :: v_dual_add_f32 v59, 0, v53   // 0000003D48E0: C9087080 3E3A6A80
	v_dual_add_f32 v61, 0, v57 :: v_dual_add_f32 v60, 0, v58   // 0000003D48E8: C9087280 3D3C7480
	v_dual_add_f32 v57, 0, v55 :: v_dual_add_f32 v56, 0, v73   // 0000003D48F0: C9086E80 39389280
	v_add_f32_e32 v55, 0, v74                                  // 0000003D48F8: 066E9480
	v_fma_mix_f32 v73, v63, v71, v71 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D48FC: CC206049 151E8F3F
	v_cvt_f32_ubyte1_e32 v74, v16                              // 0000003D4904: 7E942510
	v_dot2_f32_bf16 v76, v47, v85, v76                         // 0000003D4908: CC1A404C 1D32AB2F
	v_add_f32_e32 v58, 0, v54                                  // 0000003D4910: 06746C80
	v_dual_add_f32 v54, 0, v77 :: v_dual_add_f32 v53, 0, v78   // 0000003D4914: C9089A80 36349C80
	v_bfe_u32 v77, v73, 16, 1                                  // 0000003D491C: D610004D 02052149
	v_fma_mix_f32 v74, v74, v71, v71 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D4924: CC20604A 151E8F4A
	v_add_f32_e32 v63, 0, v76                                  // 0000003D492C: 067E9880
	v_fma_mix_f32 v76, v114, v71, v71 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D4930: CC20604C 151E8F72
	v_cvt_f32_ubyte3_e32 v16, v16                              // 0000003D4938: 7E202910
	v_add3_u32 v73, v73, v77, 0x7fff                           // 0000003D493C: D6550049 03FE9B49 00007FFF
	v_bfe_u32 v77, v74, 16, 1                                  // 0000003D4948: D610004D 0205214A
	v_dot2_f32_bf16 v75, v48, v75, v88                         // 0000003D4950: CC1A404B 1D629730
	v_bfe_u32 v78, v76, 16, 1                                  // 0000003D4958: D610004E 0205214C
	v_fma_mix_f32 v16, v16, v71, v71 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D4960: CC206010 151E8F10
	.long 0x7e6839c9                                           // 0000003D4968: 7E6839C9
	v_add3_u32 v73, v74, v77, 0x7fff                           // 0000003D496C: D6550049 03FE9B4A 00007FFF
	v_cvt_f32_ubyte0_e32 v74, v17                              // 0000003D4978: 7E942311
	v_add3_u32 v76, v76, v78, 0x7fff                           // 0000003D497C: D655004C 03FE9D4C 00007FFF
	v_bfe_u32 v77, v16, 16, 1                                  // 0000003D4988: D610004D 02052110
	v_cvt_f32_ubyte2_e32 v78, v17                              // 0000003D4990: 7E9C2711
	v_dot2_f32_bf16 v75, v49, v83, v75                         // 0000003D4994: CC1A404B 1D2EA731
	v_fma_mix_f32 v74, v74, v71, v71 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D499C: CC20604A 151E8F4A
	.long 0x7e9839cc                                           // 0000003D49A4: 7E9839CC
	.long 0x7f9839b4                                           // 0000003D49A8: 7F9839B4
	v_add3_u32 v16, v16, v77, 0x7fff                           // 0000003D49AC: D6550010 03FE9B10 00007FFF
	v_cvt_f32_ubyte1_e32 v77, v17                              // 0000003D49B8: 7E9A2511
	v_bfe_u32 v79, v74, 16, 1                                  // 0000003D49BC: D610004F 0205214A
	v_fma_mix_f32 v78, v78, v71, v71 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D49C4: CC20604E 151E8F4E
	v_cvt_f32_ubyte3_e32 v17, v17                              // 0000003D49CC: 7E222911
	v_and_or_b32 v16, 0xffff0000, v16, v76                     // 0000003D49D0: D6570010 053220FF FFFF0000
	v_fma_mix_f32 v76, v77, v71, v71 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D49DC: CC20604C 151E8F4D
	v_add3_u32 v74, v74, v79, 0x7fff                           // 0000003D49E4: D655004A 03FE9F4A 00007FFF
	v_cvt_f32_ubyte0_e32 v79, v18                              // 0000003D49F0: 7E9E2312
	v_dot2_f32_bf16 v75, v50, v80, v75                         // 0000003D49F4: CC1A404B 1D2EA132
	v_and_or_b32 v73, 0xffff0000, v73, v52                     // 0000003D49FC: D6570049 04D292FF FFFF0000
	v_bfe_u32 v77, v78, 16, 1                                  // 0000003D4A08: D610004D 0205214E
	v_bfe_u32 v80, v76, 16, 1                                  // 0000003D4A10: D6100050 0205214C
	v_fma_mix_f32 v17, v17, v71, v71 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D4A18: CC206011 151E8F11
	.long 0x7e6839ca                                           // 0000003D4A20: 7E6839CA
	v_fma_mix_f32 v74, v79, v71, v71 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D4A24: CC20604A 151E8F4F
	v_add3_u32 v77, v78, v77, 0x7fff                           // 0000003D4A2C: D655004D 03FE9B4E 00007FFF
	v_add3_u32 v76, v76, v80, 0x7fff                           // 0000003D4A38: D655004C 03FEA14C 00007FFF
	v_bfe_u32 v78, v17, 16, 1                                  // 0000003D4A44: D610004E 02052111
	v_cvt_f32_ubyte1_e32 v79, v18                              // 0000003D4A4C: 7E9E2512
	v_bfe_u32 v80, v74, 16, 1                                  // 0000003D4A50: D6100050 0205214A
	v_cvt_f32_ubyte2_e32 v81, v18                              // 0000003D4A58: 7EA22712
	.long 0x7e9a39cd                                           // 0000003D4A5C: 7E9A39CD
	.long 0x7f9a39b4                                           // 0000003D4A60: 7F9A39B4
	v_add3_u32 v17, v17, v78, 0x7fff                           // 0000003D4A64: D6550011 03FE9D11 00007FFF
	v_fma_mix_f32 v78, v79, v71, v71 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D4A70: CC20604E 151E8F4F
	v_add3_u32 v74, v74, v80, 0x7fff                           // 0000003D4A78: D655004A 03FEA14A 00007FFF
	v_fma_mix_f32 v79, v81, v71, v71 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D4A84: CC20604F 151E8F51
	v_and_or_b32 v76, 0xffff0000, v76, v52                     // 0000003D4A8C: D657004C 04D298FF FFFF0000
	v_and_or_b32 v17, 0xffff0000, v17, v77                     // 0000003D4A98: D6570011 053622FF FFFF0000
	v_bfe_u32 v77, v78, 16, 1                                  // 0000003D4AA4: D610004D 0205214E
	.long 0x7e6839ca                                           // 0000003D4AAC: 7E6839CA
	v_bfe_u32 v74, v79, 16, 1                                  // 0000003D4AB0: D610004A 0205214F
	v_cvt_f32_ubyte3_e32 v18, v18                              // 0000003D4AB8: 7E242912
	v_cvt_f32_ubyte0_e32 v80, v19                              // 0000003D4ABC: 7EA02313
	v_dot2_f32_bf16 v20, v20, v73, 0                           // 0000003D4AC0: CC1A4014 1A029314
	v_dot2_f32_bf16 v24, v24, v73, 0                           // 0000003D4AC8: CC1A4018 1A029318
	v_dot2_f32_bf16 v28, v28, v73, 0                           // 0000003D4AD0: CC1A401C 1A02931C
	v_dot2_f32_bf16 v32, v32, v73, 0                           // 0000003D4AD8: CC1A4020 1A029320
	v_add3_u32 v77, v78, v77, 0x7fff                           // 0000003D4AE0: D655004D 03FE9B4E 00007FFF
	v_cvt_f32_ubyte2_e32 v78, v19                              // 0000003D4AEC: 7E9C2713
	v_add3_u32 v74, v79, v74, 0x7fff                           // 0000003D4AF0: D655004A 03FE954F 00007FFF
	v_fma_mix_f32 v18, v18, v71, v71 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D4AFC: CC206012 151E8F12
	v_fma_mix_f32 v79, v80, v71, v71 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D4B04: CC20604F 151E8F50
	v_cvt_f32_ubyte1_e32 v80, v19                              // 0000003D4B0C: 7EA02513
	v_cvt_f32_ubyte3_e32 v19, v19                              // 0000003D4B10: 7E262913
	v_dot2_f32_bf16 v20, v21, v16, v20                         // 0000003D4B14: CC1A4014 1C522115
	v_dot2_f32_bf16 v21, v25, v16, v24                         // 0000003D4B1C: CC1A4015 1C622119
	v_dot2_f32_bf16 v24, v29, v16, v28                         // 0000003D4B24: CC1A4018 1C72211D
	v_dot2_f32_bf16 v16, v33, v16, v32                         // 0000003D4B2C: CC1A4010 1C822121
	v_fma_mix_f32 v78, v78, v71, v71 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D4B34: CC20604E 151E8F4E
	v_bfe_u32 v81, v18, 16, 1                                  // 0000003D4B3C: D6100051 02052112
	v_bfe_u32 v82, v79, 16, 1                                  // 0000003D4B44: D6100052 0205214F
	v_fma_mix_f32 v80, v80, v71, v71 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D4B4C: CC206050 151E8F50
	v_fma_mix_f32 v19, v19, v71, v71 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D4B54: CC206013 151E8F13
	v_dot2_f32_bf16 v20, v22, v76, v20                         // 0000003D4B5C: CC1A4014 1C529916
	v_dot2_f32_bf16 v21, v26, v76, v21                         // 0000003D4B64: CC1A4015 1C56991A
	v_dot2_f32_bf16 v22, v30, v76, v24                         // 0000003D4B6C: CC1A4016 1C62991E
	v_dot2_f32_bf16 v16, v34, v76, v16                         // 0000003D4B74: CC1A4010 1C429922
	.long 0x7e9439ca                                           // 0000003D4B7C: 7E9439CA
	v_bfe_u32 v83, v78, 16, 1                                  // 0000003D4B80: D6100053 0205214E
	.long 0x7f9439b4                                           // 0000003D4B88: 7F9439B4
	v_add3_u32 v18, v18, v81, 0x7fff                           // 0000003D4B8C: D6550012 03FEA312 00007FFF
	v_add3_u32 v79, v79, v82, 0x7fff                           // 0000003D4B98: D655004F 03FEA54F 00007FFF
	v_bfe_u32 v81, v80, 16, 1                                  // 0000003D4BA4: D6100051 02052150
	v_and_or_b32 v77, 0xffff0000, v77, v52                     // 0000003D4BAC: D657004D 04D29AFF FFFF0000
	v_bfe_u32 v24, v19, 16, 1                                  // 0000003D4BB8: D6100018 02052113
	v_dot2_f32_bf16 v20, v23, v17, v20                         // 0000003D4BC0: CC1A4014 1C522317
	v_dot2_f32_bf16 v21, v27, v17, v21                         // 0000003D4BC8: CC1A4015 1C56231B
	v_dot2_f32_bf16 v22, v31, v17, v22                         // 0000003D4BD0: CC1A4016 1C5A231F
	v_dot2_f32_bf16 v16, v35, v17, v16                         // 0000003D4BD8: CC1A4010 1C422323
	v_add3_u32 v78, v78, v83, 0x7fff                           // 0000003D4BE0: D655004E 03FEA74E 00007FFF
	v_and_or_b32 v18, 0xffff0000, v18, v74                     // 0000003D4BEC: D6570012 052A24FF FFFF0000
	.long 0x7e6839cf                                           // 0000003D4BF8: 7E6839CF
	v_add3_u32 v74, v80, v81, 0x7fff                           // 0000003D4BFC: D655004A 03FEA350 00007FFF
	v_add3_u32 v17, v19, v24, 0x7fff                           // 0000003D4C08: D6550011 03FE3113 00007FFF
	v_dot2_f32_bf16 v19, v36, v77, v20                         // 0000003D4C14: CC1A4013 1C529B24
	v_dot2_f32_bf16 v20, v40, v77, v21                         // 0000003D4C1C: CC1A4014 1C569B28
	v_dot2_f32_bf16 v21, v44, v77, v22                         // 0000003D4C24: CC1A4015 1C5A9B2C
	v_dot2_f32_bf16 v16, v48, v77, v16                         // 0000003D4C2C: CC1A4010 1C429B30
	.long 0x7e9c39ce                                           // 0000003D4C34: 7E9C39CE
	.long 0x7f9c39b4                                           // 0000003D4C38: 7F9C39B4
	v_and_or_b32 v22, 0xffff0000, v74, v52                     // 0000003D4C3C: D6570016 04D294FF FFFF0000
	v_dot2_f32_bf16 v19, v37, v18, v19                         // 0000003D4C48: CC1A4013 1C4E2525
	v_dot2_f32_bf16 v20, v41, v18, v20                         // 0000003D4C50: CC1A4014 1C522529
	v_dot2_f32_bf16 v21, v45, v18, v21                         // 0000003D4C58: CC1A4015 1C56252D
	v_dot2_f32_bf16 v16, v49, v18, v16                         // 0000003D4C60: CC1A4010 1C422531
	v_and_or_b32 v17, 0xffff0000, v17, v78                     // 0000003D4C68: D6570011 053A22FF FFFF0000
	v_dot2_f32_bf16 v18, v38, v22, v19                         // 0000003D4C74: CC1A4012 1C4E2D26
	v_dot2_f32_bf16 v19, v42, v22, v20                         // 0000003D4C7C: CC1A4013 1C522D2A
	v_dot2_f32_bf16 v20, v46, v22, v21                         // 0000003D4C84: CC1A4014 1C562D2E
	v_dot2_f32_bf16 v16, v50, v22, v16                         // 0000003D4C8C: CC1A4010 1C422D32
	v_dot2_f32_bf16 v21, v51, v85, v75                         // 0000003D4C94: CC1A4015 1D2EAB33
	v_dot2_f32_bf16 v18, v39, v17, v18                         // 0000003D4C9C: CC1A4012 1C4A2327
	v_dot2_f32_bf16 v19, v43, v17, v19                         // 0000003D4CA4: CC1A4013 1C4E232B
	v_dot2_f32_bf16 v20, v47, v17, v20                         // 0000003D4CAC: CC1A4014 1C52232F
	v_dot2_f32_bf16 v16, v51, v17, v16                         // 0000003D4CB4: CC1A4010 1C422333
	v_add_f32_e32 v71, 0, v21                                  // 0000003D4CBC: 068E2A80
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003D4CC0: BF870214
	v_dual_add_f32 v51, 0, v18 :: v_dual_add_f32 v50, 0, v19   // 0000003D4CC4: C9082480 33322680
	v_add_f32_e32 v49, 0, v20                                  // 0000003D4CCC: 06622880
	s_delay_alu instid0(VALU_DEP_4)                            // 0000003D4CD0: BF870004
	v_add_f32_e32 v48, 0, v16                                  // 0000003D4CD4: 06602080
	v_cmpx_gt_u32_e32 20, v70                                  // 0000003D4CD8: 7D988C94
	s_cbranch_execz 963                                        // 0000003D4CDC: BFA503C3 <_ZN7halogen12_GLOBAL__N_17k_hcup8ILi4EEEvPKhPKtS5_PtPf+0x1fec>
	.long 0xd7000124                                           // 0000003D4CE0: D7000124
	v_cndmask_b32_e32 v1, s6, v72, vcc_lo                      // 0000003D4CE4: 02029006
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003D4CE8: BF870001
	v_add_co_ci_u32_e64 v37, null, s7, 0, s1                   // 0000003D4CEC: D5207C25 00050007
	v_cvt_f32_ubyte0_e32 v72, v12                              // 0000003D4CF4: 7E90230C
	v_cvt_f32_ubyte1_e32 v73, v12                              // 0000003D4CF8: 7E92250C
	v_cvt_f32_ubyte2_e32 v74, v12                              // 0000003D4CFC: 7E94270C
	s_clause 0x7                                               // 0000003D4D00: BF850007
	global_load_b128 v[16:19], v[36:37], off offset:512        // 0000003D4D04: DC5E0200 107C0024
	global_load_b128 v[20:23], v[36:37], off offset:1152       // 0000003D4D0C: DC5E0480 147C0024
	global_load_b128 v[40:43], v[36:37], off offset:1792       // 0000003D4D14: DC5E0700 287C0024
	global_load_b128 v[44:47], v[36:37], off offset:2432       // 0000003D4D1C: DC5E0980 2C7C0024
	global_load_b128 v[24:27], v[36:37], off offset:528        // 0000003D4D24: DC5E0210 187C0024
	global_load_b128 v[28:31], v[36:37], off offset:1168       // 0000003D4D2C: DC5E0490 1C7C0024
	global_load_b128 v[32:35], v[36:37], off offset:1808       // 0000003D4D34: DC5E0710 207C0024
	global_load_b128 v[36:39], v[36:37], off offset:2448       // 0000003D4D3C: DC5E0990 247C0024
	v_cvt_f32_ubyte3_e32 v75, v12                              // 0000003D4D44: 7E96290C
	v_cvt_f32_ubyte0_e32 v76, v13                              // 0000003D4D48: 7E98230D
	v_cvt_f32_ubyte1_e32 v77, v13                              // 0000003D4D4C: 7E9A250D
	v_cvt_f32_ubyte2_e32 v78, v13                              // 0000003D4D50: 7E9C270D
	v_cvt_f32_ubyte3_e32 v79, v13                              // 0000003D4D54: 7E9E290D
	v_cvt_f32_ubyte0_e32 v80, v14                              // 0000003D4D58: 7EA0230E
	v_cvt_f32_ubyte1_e32 v81, v14                              // 0000003D4D5C: 7EA2250E
	v_cvt_f32_ubyte2_e32 v82, v14                              // 0000003D4D60: 7EA4270E
	v_cvt_f32_ubyte3_e32 v83, v14                              // 0000003D4D64: 7EA6290E
	v_cvt_f32_ubyte0_e32 v84, v15                              // 0000003D4D68: 7EA8230F
	v_cvt_f32_ubyte1_e32 v85, v15                              // 0000003D4D6C: 7EAA250F
	v_cvt_f32_ubyte2_e32 v86, v15                              // 0000003D4D70: 7EAC270F
	v_cvt_f32_ubyte3_e32 v87, v15                              // 0000003D4D74: 7EAE290F
	v_cvt_f32_ubyte0_e32 v88, v8                               // 0000003D4D78: 7EB02308
	v_cvt_f32_ubyte1_e32 v89, v8                               // 0000003D4D7C: 7EB22508
	v_cvt_f32_ubyte2_e32 v90, v8                               // 0000003D4D80: 7EB42708
	v_cvt_f32_ubyte3_e32 v91, v8                               // 0000003D4D84: 7EB62908
	v_cvt_f32_ubyte0_e32 v92, v9                               // 0000003D4D88: 7EB82309
	v_cvt_f32_ubyte1_e32 v93, v9                               // 0000003D4D8C: 7EBA2509
	v_cvt_f32_ubyte2_e32 v94, v9                               // 0000003D4D90: 7EBC2709
	v_cvt_f32_ubyte3_e32 v95, v9                               // 0000003D4D94: 7EBE2909
	v_cvt_f32_ubyte0_e32 v96, v10                              // 0000003D4D98: 7EC0230A
	v_cvt_f32_ubyte1_e32 v97, v10                              // 0000003D4D9C: 7EC2250A
	v_cvt_f32_ubyte2_e32 v98, v10                              // 0000003D4DA0: 7EC4270A
	v_cvt_f32_ubyte3_e32 v10, v10                              // 0000003D4DA4: 7E14290A
	v_cvt_f32_ubyte0_e32 v99, v11                              // 0000003D4DA8: 7EC6230B
	v_cvt_f32_ubyte1_e32 v100, v11                             // 0000003D4DAC: 7EC8250B
	v_cvt_f32_ubyte2_e32 v101, v11                             // 0000003D4DB0: 7ECA270B
	v_cvt_f32_ubyte3_e32 v11, v11                              // 0000003D4DB4: 7E16290B
	v_cvt_f32_ubyte0_e32 v103, v4                              // 0000003D4DB8: 7ECE2304
	v_cvt_f32_ubyte1_e32 v104, v4                              // 0000003D4DBC: 7ED02504
	v_cvt_f32_ubyte2_e32 v105, v4                              // 0000003D4DC0: 7ED22704
	v_cvt_f32_ubyte3_e32 v4, v4                                // 0000003D4DC4: 7E082904
	v_cvt_f32_ubyte0_e32 v106, v5                              // 0000003D4DC8: 7ED42305
	v_cvt_f32_ubyte1_e32 v107, v5                              // 0000003D4DCC: 7ED62505
	v_cvt_f32_ubyte2_e32 v108, v5                              // 0000003D4DD0: 7ED82705
	v_cvt_f32_ubyte3_e32 v5, v5                                // 0000003D4DD4: 7E0A2905
	v_cvt_f32_ubyte0_e32 v109, v6                              // 0000003D4DD8: 7EDA2306
	v_cvt_f32_ubyte1_e32 v110, v6                              // 0000003D4DDC: 7EDC2506
	v_cvt_f32_ubyte2_e32 v111, v6                              // 0000003D4DE0: 7EDE2706
	v_cvt_f32_ubyte3_e32 v6, v6                                // 0000003D4DE4: 7E0C2906
	v_cvt_f32_ubyte0_e32 v112, v7                              // 0000003D4DE8: 7EE02307
	v_cvt_f32_ubyte1_e32 v113, v7                              // 0000003D4DEC: 7EE22507
	v_cvt_f32_ubyte2_e32 v114, v7                              // 0000003D4DF0: 7EE42707
	v_cvt_f32_ubyte3_e32 v7, v7                                // 0000003D4DF4: 7E0E2907
	v_fma_mix_f32 v72, v72, v68, v68 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D4DF8: CC206048 15128948
	v_fma_mix_f32 v73, v73, v68, v68 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D4E00: CC206049 15128949
	v_fma_mix_f32 v74, v74, v68, v68 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D4E08: CC20604A 1512894A
	v_fma_mix_f32 v75, v75, v68, v68 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D4E10: CC20604B 1512894B
	v_fma_mix_f32 v76, v76, v68, v68 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D4E18: CC20604C 1512894C
	v_fma_mix_f32 v77, v77, v68, v68 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D4E20: CC20604D 1512894D
	v_fma_mix_f32 v78, v78, v68, v68 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D4E28: CC20604E 1512894E
	v_fma_mix_f32 v79, v79, v68, v68 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D4E30: CC20604F 1512894F
	v_fma_mix_f32 v80, v80, v68, v68 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D4E38: CC206050 15128950
	v_fma_mix_f32 v81, v81, v68, v68 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D4E40: CC206051 15128951
	v_fma_mix_f32 v82, v82, v68, v68 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D4E48: CC206052 15128952
	v_fma_mix_f32 v83, v83, v68, v68 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D4E50: CC206053 15128953
	v_fma_mix_f32 v84, v84, v68, v68 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D4E58: CC206054 15128954
	v_fma_mix_f32 v85, v85, v68, v68 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D4E60: CC206055 15128955
	v_fma_mix_f32 v86, v86, v68, v68 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D4E68: CC206056 15128956
	v_fma_mix_f32 v68, v87, v68, v68 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D4E70: CC206044 15128957
	v_fma_mix_f32 v87, v88, v69, v69 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D4E78: CC206057 15168B58
	v_fma_mix_f32 v88, v89, v69, v69 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D4E80: CC206058 15168B59
	v_fma_mix_f32 v89, v90, v69, v69 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D4E88: CC206059 15168B5A
	v_fma_mix_f32 v90, v91, v69, v69 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D4E90: CC20605A 15168B5B
	v_fma_mix_f32 v91, v92, v69, v69 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D4E98: CC20605B 15168B5C
	v_fma_mix_f32 v92, v93, v69, v69 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D4EA0: CC20605C 15168B5D
	v_fma_mix_f32 v93, v94, v69, v69 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D4EA8: CC20605D 15168B5E
	v_fma_mix_f32 v94, v95, v69, v69 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D4EB0: CC20605E 15168B5F
	v_fma_mix_f32 v95, v96, v69, v69 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D4EB8: CC20605F 15168B60
	v_fma_mix_f32 v96, v97, v69, v69 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D4EC0: CC206060 15168B61
	v_fma_mix_f32 v97, v98, v69, v69 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D4EC8: CC206061 15168B62
	v_fma_mix_f32 v10, v10, v69, v69 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D4ED0: CC20600A 15168B0A
	v_fma_mix_f32 v98, v99, v69, v69 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D4ED8: CC206062 15168B63
	v_fma_mix_f32 v99, v100, v69, v69 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D4EE0: CC206063 15168B64
	v_fma_mix_f32 v100, v101, v69, v69 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D4EE8: CC206064 15168B65
	v_fma_mix_f32 v11, v11, v69, v69 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D4EF0: CC20600B 15168B0B
	v_fma_mix_f32 v69, v103, v67, v67 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D4EF8: CC206045 150E8767
	v_fma_mix_f32 v101, v104, v67, v67 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D4F00: CC206065 150E8768
	v_fma_mix_f32 v103, v105, v67, v67 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D4F08: CC206067 150E8769
	v_fma_mix_f32 v4, v4, v67, v67 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D4F10: CC206004 150E8704
	v_fma_mix_f32 v104, v106, v67, v67 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D4F18: CC206068 150E876A
	v_fma_mix_f32 v105, v107, v67, v67 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D4F20: CC206069 150E876B
	v_fma_mix_f32 v106, v108, v67, v67 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D4F28: CC20606A 150E876C
	v_fma_mix_f32 v5, v5, v67, v67 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D4F30: CC206005 150E8705
	v_fma_mix_f32 v107, v109, v67, v67 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D4F38: CC20606B 150E876D
	v_fma_mix_f32 v108, v110, v67, v67 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D4F40: CC20606C 150E876E
	v_fma_mix_f32 v109, v111, v67, v67 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D4F48: CC20606D 150E876F
	v_fma_mix_f32 v6, v6, v67, v67 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D4F50: CC206006 150E8706
	v_fma_mix_f32 v110, v112, v67, v67 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D4F58: CC20606E 150E8770
	v_fma_mix_f32 v111, v113, v67, v67 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D4F60: CC20606F 150E8771
	v_fma_mix_f32 v112, v114, v67, v67 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D4F68: CC206070 150E8772
	v_fma_mix_f32 v7, v7, v67, v67 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D4F70: CC206007 150E8707
	v_bfe_u32 v67, v72, 16, 1                                  // 0000003D4F78: D6100043 02052148
	v_bfe_u32 v113, v73, 16, 1                                 // 0000003D4F80: D6100071 02052149
	v_bfe_u32 v121, v76, 16, 1                                 // 0000003D4F88: D6100079 0205214C
	v_bfe_u32 v122, v77, 16, 1                                 // 0000003D4F90: D610007A 0205214D
	v_bfe_u32 v125, v80, 16, 1                                 // 0000003D4F98: D610007D 02052150
	v_add3_u32 v67, v72, v67, 0x7fff                           // 0000003D4FA0: D6550043 03FE8748 00007FFF
	v_add3_u32 v73, v73, v113, 0x7fff                          // 0000003D4FAC: D6550049 03FEE349 00007FFF
	v_add3_u32 v76, v76, v121, 0x7fff                          // 0000003D4FB8: D655004C 03FEF34C 00007FFF
	v_bfe_u32 v126, v81, 16, 1                                 // 0000003D4FC4: D610007E 02052151
	v_bfe_u32 v129, v84, 16, 1                                 // 0000003D4FCC: D6100081 02052154
	.long 0x7e6839c3                                           // 0000003D4FD4: 7E6839C3
	v_add3_u32 v77, v77, v122, 0x7fff                          // 0000003D4FD8: D655004D 03FEF54D 00007FFF
	v_add3_u32 v80, v80, v125, 0x7fff                          // 0000003D4FE4: D6550050 03FEFB50 00007FFF
	v_bfe_u32 v130, v85, 16, 1                                 // 0000003D4FF0: D6100082 02052155
	v_bfe_u32 v133, v87, 16, 1                                 // 0000003D4FF8: D6100085 02052157
	v_and_or_b32 v73, 0xffff0000, v73, v52                     // 0000003D5000: D6570049 04D292FF FFFF0000
	.long 0x7e6839cc                                           // 0000003D500C: 7E6839CC
	v_add3_u32 v81, v81, v126, 0x7fff                          // 0000003D5010: D6550051 03FEFD51 00007FFF
	v_add3_u32 v84, v84, v129, 0x7fff                          // 0000003D501C: D6550054 03FF0354 00007FFF
	v_bfe_u32 v134, v88, 16, 1                                 // 0000003D5028: D6100086 02052158
	v_bfe_u32 v137, v91, 16, 1                                 // 0000003D5030: D6100089 0205215B
	v_and_or_b32 v77, 0xffff0000, v77, v52                     // 0000003D5038: D657004D 04D29AFF FFFF0000
	.long 0x7e6839d0                                           // 0000003D5044: 7E6839D0
	v_add3_u32 v85, v85, v130, 0x7fff                          // 0000003D5048: D6550055 03FF0555 00007FFF
	v_add3_u32 v87, v87, v133, 0x7fff                          // 0000003D5054: D6550057 03FF0B57 00007FFF
	v_bfe_u32 v120, v75, 16, 1                                 // 0000003D5060: D6100078 0205214B
	v_bfe_u32 v138, v92, 16, 1                                 // 0000003D5068: D610008A 0205215C
	v_and_or_b32 v81, 0xffff0000, v81, v52                     // 0000003D5070: D6570051 04D2A2FF FFFF0000
	.long 0x7e6839d4                                           // 0000003D507C: 7E6839D4
	v_bfe_u32 v141, v95, 16, 1                                 // 0000003D5080: D610008D 0205215F
	v_add3_u32 v88, v88, v134, 0x7fff                          // 0000003D5088: D6550058 03FF0D58 00007FFF
	v_add3_u32 v91, v91, v137, 0x7fff                          // 0000003D5094: D655005B 03FF135B 00007FFF
	v_bfe_u32 v124, v79, 16, 1                                 // 0000003D50A0: D610007C 0205214F
	v_and_or_b32 v85, 0xffff0000, v85, v52                     // 0000003D50A8: D6570055 04D2AAFF FFFF0000
	.long 0x7e6839d7                                           // 0000003D50B4: 7E6839D7
	v_bfe_u32 v72, v96, 16, 1                                  // 0000003D50B8: D6100048 02052160
	v_add3_u32 v75, v75, v120, 0x7fff                          // 0000003D50C0: D655004B 03FEF14B 00007FFF
	v_bfe_u32 v120, v98, 16, 1                                 // 0000003D50CC: D6100078 02052162
	v_add3_u32 v92, v92, v138, 0x7fff                          // 0000003D50D4: D655005C 03FF155C 00007FFF
	v_add3_u32 v67, v95, v141, 0x7fff                          // 0000003D50E0: D6550043 03FF1B5F 00007FFF
	v_and_or_b32 v88, 0xffff0000, v88, v52                     // 0000003D50EC: D6570058 04D2B0FF FFFF0000
	.long 0x7e6839db                                           // 0000003D50F8: 7E6839DB
	v_bfe_u32 v121, v99, 16, 1                                 // 0000003D50FC: D6100079 02052163
	v_add3_u32 v79, v79, v124, 0x7fff                          // 0000003D5104: D655004F 03FEF94F 00007FFF
	v_bfe_u32 v124, v69, 16, 1                                 // 0000003D5110: D610007C 02052145
	v_add3_u32 v72, v96, v72, 0x7fff                           // 0000003D5118: D6550048 03FE9160 00007FFF
	v_add3_u32 v76, v98, v120, 0x7fff                          // 0000003D5124: D655004C 03FEF162 00007FFF
	v_and_or_b32 v92, 0xffff0000, v92, v52                     // 0000003D5130: D657005C 04D2B8FF FFFF0000
	.long 0x7e6839c3                                           // 0000003D513C: 7E6839C3
	v_bfe_u32 v114, v74, 16, 1                                 // 0000003D5140: D6100072 0205214A
	v_bfe_u32 v123, v78, 16, 1                                 // 0000003D5148: D610007B 0205214E
	v_bfe_u32 v127, v82, 16, 1                                 // 0000003D5150: D610007F 02052152
	v_bfe_u32 v128, v83, 16, 1                                 // 0000003D5158: D6100080 02052153
	v_bfe_u32 v135, v89, 16, 1                                 // 0000003D5160: D6100087 02052159
	v_bfe_u32 v125, v101, 16, 1                                // 0000003D5168: D610007D 02052165
	v_bfe_u32 v126, v103, 16, 1                                // 0000003D5170: D610007E 02052167
	v_add3_u32 v96, v99, v121, 0x7fff                          // 0000003D5178: D6550060 03FEF363 00007FFF
	v_add3_u32 v69, v69, v124, 0x7fff                          // 0000003D5184: D6550045 03FEF945 00007FFF
	v_and_or_b32 v67, 0xffff0000, v72, v52                     // 0000003D5190: D6570043 04D290FF FFFF0000
	.long 0x7e6839cc                                           // 0000003D519C: 7E6839CC
	v_bfe_u32 v131, v86, 16, 1                                 // 0000003D51A0: D6100083 02052156
	v_bfe_u32 v132, v68, 16, 1                                 // 0000003D51A8: D6100084 02052144
	v_bfe_u32 v136, v90, 16, 1                                 // 0000003D51B0: D6100088 0205215A
	v_add3_u32 v74, v74, v114, 0x7fff                          // 0000003D51B8: D655004A 03FEE54A 00007FFF
	v_add3_u32 v78, v78, v123, 0x7fff                          // 0000003D51C4: D655004E 03FEF74E 00007FFF
	v_add3_u32 v82, v82, v127, 0x7fff                          // 0000003D51D0: D6550052 03FEFF52 00007FFF
	v_bfe_u32 v127, v4, 16, 1                                  // 0000003D51DC: D610007F 02052104
	v_add3_u32 v83, v83, v128, 0x7fff                          // 0000003D51E4: D6550053 03FF0153 00007FFF
	v_bfe_u32 v128, v104, 16, 1                                // 0000003D51F0: D6100080 02052168
	v_add3_u32 v89, v89, v135, 0x7fff                          // 0000003D51F8: D6550059 03FF0F59 00007FFF
	v_add3_u32 v80, v101, v125, 0x7fff                         // 0000003D5204: D6550050 03FEFB65 00007FFF
	v_add3_u32 v98, v103, v126, 0x7fff                         // 0000003D5210: D6550062 03FEFD67 00007FFF
	v_and_or_b32 v72, 0xffff0000, v96, v52                     // 0000003D521C: D6570048 04D2C0FF FFFF0000
	.long 0x7e6839c5                                           // 0000003D5228: 7E6839C5
	.long 0x7f8c39b4                                           // 0000003D522C: 7F8C39B4
	.long 0x7f1839b4                                           // 0000003D5230: 7F1839B4
	.long 0x7f1a39b4                                           // 0000003D5234: 7F1A39B4
	.long 0x7f1e39b4                                           // 0000003D5238: 7F1E39B4
	.long 0x7fe639b4                                           // 0000003D523C: 7FE639B4
	v_bfe_u32 v139, v93, 16, 1                                 // 0000003D5240: D610008B 0205215D
	v_bfe_u32 v113, v97, 16, 1                                 // 0000003D5248: D6100071 02052161
	v_bfe_u32 v122, v100, 16, 1                                // 0000003D5250: D610007A 02052164
	v_bfe_u32 v129, v105, 16, 1                                // 0000003D5258: D6100081 02052169
	v_bfe_u32 v130, v106, 16, 1                                // 0000003D5260: D6100082 0205216A
	v_add3_u32 v86, v86, v131, 0x7fff                          // 0000003D5268: D6550056 03FF0756 00007FFF
	v_add3_u32 v68, v68, v132, 0x7fff                          // 0000003D5274: D6550044 03FF0944 00007FFF
	v_bfe_u32 v132, v107, 16, 1                                // 0000003D5280: D6100084 0205216B
	v_add3_u32 v90, v90, v136, 0x7fff                          // 0000003D5288: D655005A 03FF115A 00007FFF
	v_add3_u32 v4, v4, v127, 0x7fff                            // 0000003D5294: D6550004 03FEFF04 00007FFF
	v_add3_u32 v84, v104, v128, 0x7fff                         // 0000003D52A0: D6550054 03FF0168 00007FFF
	.long 0x7e8c39ca                                           // 0000003D52AC: 7E8C39CA
	.long 0x7e1839ce                                           // 0000003D52B0: 7E1839CE
	.long 0x7e1a39d2                                           // 0000003D52B4: 7E1A39D2
	.long 0x7e1e39d9                                           // 0000003D52B8: 7E1E39D9
	.long 0x7ee639e2                                           // 0000003D52BC: 7EE639E2
	v_and_or_b32 v69, 0xffff0000, v80, v52                     // 0000003D52C0: D6570045 04D2A0FF FFFF0000
	.long 0x7f1c39b4                                           // 0000003D52CC: 7F1C39B4
	v_bfe_u32 v140, v94, 16, 1                                 // 0000003D52D0: D610008C 0205215E
	v_bfe_u32 v131, v5, 16, 1                                  // 0000003D52D8: D6100083 02052105
	v_add3_u32 v93, v93, v139, 0x7fff                          // 0000003D52E0: D655005D 03FF175D 00007FFF
	v_add3_u32 v95, v97, v113, 0x7fff                          // 0000003D52EC: D655005F 03FEE361 00007FFF
	v_add3_u32 v97, v100, v122, 0x7fff                         // 0000003D52F8: D6550061 03FEF564 00007FFF
	v_add3_u32 v99, v105, v129, 0x7fff                         // 0000003D5304: D6550063 03FF0369 00007FFF
	v_add3_u32 v100, v106, v130, 0x7fff                        // 0000003D5310: D6550064 03FF056A 00007FFF
	v_add3_u32 v87, v107, v132, 0x7fff                         // 0000003D531C: D6550057 03FF096B 00007FFF
	.long 0x7e1c39d6                                           // 0000003D5328: 7E1C39D6
	.long 0x7e6839d4                                           // 0000003D532C: 7E6839D4
	v_and_or_b32 v70, 0xffff0000, v75, v70                     // 0000003D5330: D6570046 051A96FF FFFF0000
	v_and_or_b32 v12, 0xffff0000, v79, v12                     // 0000003D533C: D657000C 04329EFF FFFF0000
	v_and_or_b32 v13, 0xffff0000, v83, v13                     // 0000003D5348: D657000D 0436A6FF FFFF0000
	v_and_or_b32 v15, 0xffff0000, v90, v15                     // 0000003D5354: D657000F 043EB4FF FFFF0000
	v_and_or_b32 v4, 0xffff0000, v4, v115                      // 0000003D5360: D6570004 05CE08FF FFFF0000
	.long 0x7f1039b4                                           // 0000003D536C: 7F1039B4
	.long 0x7fe839b4                                           // 0000003D5370: 7FE839B4
	v_bfe_u32 v114, v10, 16, 1                                 // 0000003D5374: D6100072 0205210A
	v_bfe_u32 v123, v11, 16, 1                                 // 0000003D537C: D610007B 0205210B
	v_bfe_u32 v133, v108, 16, 1                                // 0000003D5384: D6100085 0205216C
	v_bfe_u32 v134, v109, 16, 1                                // 0000003D538C: D6100086 0205216D
	v_add3_u32 v94, v94, v140, 0x7fff                          // 0000003D5394: D655005E 03FF195E 00007FFF
	v_add3_u32 v5, v5, v131, 0x7fff                            // 0000003D53A0: D6550005 03FF0705 00007FFF
	.long 0x7e1039dd                                           // 0000003D53AC: 7E1039DD
	.long 0x7ee839e4                                           // 0000003D53B0: 7EE839E4
	v_and_or_b32 v14, 0xffff0000, v68, v14                     // 0000003D53B4: D657000E 043A88FF FFFF0000
	v_and_or_b32 v68, 0xffff0000, v99, v52                     // 0000003D53C0: D6570044 04D2C6FF FFFF0000
	.long 0x7e6839d7                                           // 0000003D53CC: 7E6839D7
	.long 0x7f1239b4                                           // 0000003D53D0: 7F1239B4
	.long 0x7fcc39b4                                           // 0000003D53D4: 7FCC39B4
	v_bfe_u32 v135, v6, 16, 1                                  // 0000003D53D8: D6100087 02052106
	v_bfe_u32 v136, v110, 16, 1                                // 0000003D53E0: D6100088 0205216E
	v_add3_u32 v10, v10, v114, 0x7fff                          // 0000003D53E8: D655000A 03FEE50A 00007FFF
	v_add3_u32 v11, v11, v123, 0x7fff                          // 0000003D53F4: D655000B 03FEF70B 00007FFF
	v_add3_u32 v101, v108, v133, 0x7fff                        // 0000003D5400: D6550065 03FF0B6C 00007FFF
	v_add3_u32 v103, v109, v134, 0x7fff                        // 0000003D540C: D6550067 03FF0D6D 00007FFF
	.long 0x7e1239df                                           // 0000003D5418: 7E1239DF
	.long 0x7ecc39e1                                           // 0000003D541C: 7ECC39E1
	v_and_or_b32 v8, 0xffff0000, v94, v8                       // 0000003D5420: D6570008 0422BCFF FFFF0000
	v_and_or_b32 v5, 0xffff0000, v5, v116                      // 0000003D542C: D6570005 05D20AFF FFFF0000
	.long 0x7fea39b4                                           // 0000003D5438: 7FEA39B4
	v_bfe_u32 v137, v111, 16, 1                                // 0000003D543C: D6100089 0205216F
	v_bfe_u32 v138, v112, 16, 1                                // 0000003D5444: D610008A 02052170
	v_add3_u32 v6, v6, v135, 0x7fff                            // 0000003D544C: D6550006 03FF0F06 00007FFF
	v_add3_u32 v91, v110, v136, 0x7fff                         // 0000003D5458: D655005B 03FF116E 00007FFF
	.long 0x7eea39e7                                           // 0000003D5464: 7EEA39E7
	v_and_or_b32 v9, 0xffff0000, v10, v9                       // 0000003D5468: D6570009 042614FF FFFF0000
	v_and_or_b32 v10, 0xffff0000, v11, v102                    // 0000003D5474: D657000A 059A16FF FFFF0000
	v_and_or_b32 v11, 0xffff0000, v101, v52                    // 0000003D5480: D657000B 04D2CAFF FFFF0000
	v_bfe_u32 v139, v7, 16, 1                                  // 0000003D548C: D610008B 02052107
	v_add3_u32 v104, v111, v137, 0x7fff                        // 0000003D5494: D6550068 03FF136F 00007FFF
	v_add3_u32 v105, v112, v138, 0x7fff                        // 0000003D54A0: D6550069 03FF1570 00007FFF
	.long 0x7e6839db                                           // 0000003D54AC: 7E6839DB
	v_and_or_b32 v6, 0xffff0000, v6, v117                      // 0000003D54B0: D6570006 05D60CFF FFFF0000
	.long 0x7fec39b4                                           // 0000003D54BC: 7FEC39B4
	v_add3_u32 v7, v7, v139, 0x7fff                            // 0000003D54C0: D6550007 03FF1707 00007FFF
	.long 0x7eec39e9                                           // 0000003D54CC: 7EEC39E9
	v_and_or_b32 v74, 0xffff0000, v104, v52                    // 0000003D54D0: D657004A 04D2D0FF FFFF0000
	v_cvt_f32_ubyte0_e32 v119, v0                              // 0000003D54DC: 7EEE2300
	s_delay_alu instid0(VALU_DEP_3)                            // 0000003D54E0: BF870003
	v_and_or_b32 v7, 0xffff0000, v7, v118                      // 0000003D54E4: D6570007 05DA0EFF FFFF0000
	s_waitcnt vmcnt(7)                                         // 0000003D54F0: BF891FF7
	v_dot2_f32_bf16 v75, v16, v73, 0                           // 0000003D54F4: CC1A404B 1A029310
	s_waitcnt vmcnt(6)                                         // 0000003D54FC: BF891BF7
	v_dot2_f32_bf16 v76, v20, v73, 0                           // 0000003D5500: CC1A404C 1A029314
	s_waitcnt vmcnt(5)                                         // 0000003D5508: BF8917F7
	v_dot2_f32_bf16 v78, v40, v73, 0                           // 0000003D550C: CC1A404E 1A029328
	s_waitcnt vmcnt(4)                                         // 0000003D5514: BF8913F7
	v_dot2_f32_bf16 v73, v44, v73, 0                           // 0000003D5518: CC1A4049 1A02932C
	v_dot2_f32_bf16 v79, v16, v88, 0                           // 0000003D5520: CC1A404F 1A02B110
	v_dot2_f32_bf16 v80, v20, v88, 0                           // 0000003D5528: CC1A4050 1A02B114
	v_dot2_f32_bf16 v82, v40, v88, 0                           // 0000003D5530: CC1A4052 1A02B128
	v_dot2_f32_bf16 v83, v44, v88, 0                           // 0000003D5538: CC1A4053 1A02B12C
	v_dot2_f32_bf16 v84, v16, v69, 0                           // 0000003D5540: CC1A4054 1A028B10
	v_dot2_f32_bf16 v86, v20, v69, 0                           // 0000003D5548: CC1A4056 1A028B14
	v_dot2_f32_bf16 v87, v40, v69, 0                           // 0000003D5550: CC1A4057 1A028B28
	v_dot2_f32_bf16 v69, v44, v69, 0                           // 0000003D5558: CC1A4045 1A028B2C
	v_dot2_f32_bf16 v75, v17, v70, v75                         // 0000003D5560: CC1A404B 1D2E8D11
	v_dot2_f32_bf16 v76, v21, v70, v76                         // 0000003D5568: CC1A404C 1D328D15
	v_dot2_f32_bf16 v78, v41, v70, v78                         // 0000003D5570: CC1A404E 1D3A8D29
	v_dot2_f32_bf16 v70, v45, v70, v73                         // 0000003D5578: CC1A4046 1D268D2D
	v_dot2_f32_bf16 v73, v17, v15, v79                         // 0000003D5580: CC1A4049 1D3E1F11
	v_dot2_f32_bf16 v79, v21, v15, v80                         // 0000003D5588: CC1A404F 1D421F15
	v_dot2_f32_bf16 v80, v41, v15, v82                         // 0000003D5590: CC1A4050 1D4A1F29
	v_dot2_f32_bf16 v15, v45, v15, v83                         // 0000003D5598: CC1A400F 1D4E1F2D
	v_dot2_f32_bf16 v82, v17, v4, v84                          // 0000003D55A0: CC1A4052 1D520911
	v_dot2_f32_bf16 v83, v21, v4, v86                          // 0000003D55A8: CC1A4053 1D5A0915
	v_dot2_f32_bf16 v84, v41, v4, v87                          // 0000003D55B0: CC1A4054 1D5E0929
	v_dot2_f32_bf16 v4, v45, v4, v69                           // 0000003D55B8: CC1A4004 1D16092D
	v_dot2_f32_bf16 v69, v18, v77, v75                         // 0000003D55C0: CC1A4045 1D2E9B12
	v_dot2_f32_bf16 v75, v22, v77, v76                         // 0000003D55C8: CC1A404B 1D329B16
	v_dot2_f32_bf16 v76, v42, v77, v78                         // 0000003D55D0: CC1A404C 1D3A9B2A
	v_dot2_f32_bf16 v70, v46, v77, v70                         // 0000003D55D8: CC1A4046 1D1A9B2E
	v_dot2_f32_bf16 v73, v18, v92, v73                         // 0000003D55E0: CC1A4049 1D26B912
	v_dot2_f32_bf16 v77, v22, v92, v79                         // 0000003D55E8: CC1A404D 1D3EB916
	v_dot2_f32_bf16 v78, v42, v92, v80                         // 0000003D55F0: CC1A404E 1D42B92A
	v_dot2_f32_bf16 v15, v46, v92, v15                         // 0000003D55F8: CC1A400F 1C3EB92E
	v_dot2_f32_bf16 v79, v18, v68, v82                         // 0000003D5600: CC1A404F 1D4A8912
	v_dot2_f32_bf16 v80, v22, v68, v83                         // 0000003D5608: CC1A4050 1D4E8916
	v_dot2_f32_bf16 v82, v42, v68, v84                         // 0000003D5610: CC1A4052 1D52892A
	v_dot2_f32_bf16 v4, v46, v68, v4                           // 0000003D5618: CC1A4004 1C12892E
	v_dot2_f32_bf16 v68, v19, v12, v69                         // 0000003D5620: CC1A4044 1D161913
	v_dot2_f32_bf16 v69, v23, v12, v75                         // 0000003D5628: CC1A4045 1D2E1917
	v_dot2_f32_bf16 v75, v43, v12, v76                         // 0000003D5630: CC1A404B 1D32192B
	v_dot2_f32_bf16 v12, v47, v12, v70                         // 0000003D5638: CC1A400C 1D1A192F
	v_dot2_f32_bf16 v70, v19, v8, v73                          // 0000003D5640: CC1A4046 1D261113
	v_dot2_f32_bf16 v73, v23, v8, v77                          // 0000003D5648: CC1A4049 1D361117
	v_dot2_f32_bf16 v76, v43, v8, v78                          // 0000003D5650: CC1A404C 1D3A112B
	v_dot2_f32_bf16 v8, v47, v8, v15                           // 0000003D5658: CC1A4008 1C3E112F
	v_dot2_f32_bf16 v15, v19, v5, v79                          // 0000003D5660: CC1A400F 1D3E0B13
	v_dot2_f32_bf16 v77, v23, v5, v80                          // 0000003D5668: CC1A404D 1D420B17
	v_dot2_f32_bf16 v78, v43, v5, v82                          // 0000003D5670: CC1A404E 1D4A0B2B
	v_dot2_f32_bf16 v4, v47, v5, v4                            // 0000003D5678: CC1A4004 1C120B2F
	s_waitcnt vmcnt(3)                                         // 0000003D5680: BF890FF7
	v_dot2_f32_bf16 v5, v24, v81, v68                          // 0000003D5684: CC1A4005 1D12A318
	s_waitcnt vmcnt(2)                                         // 0000003D568C: BF890BF7
	v_dot2_f32_bf16 v68, v28, v81, v69                         // 0000003D5690: CC1A4044 1D16A31C
	s_waitcnt vmcnt(1)                                         // 0000003D5698: BF8907F7
	v_dot2_f32_bf16 v69, v32, v81, v75                         // 0000003D569C: CC1A4045 1D2EA320
	s_waitcnt vmcnt(0)                                         // 0000003D56A4: BF8903F7
	v_dot2_f32_bf16 v12, v36, v81, v12                         // 0000003D56A8: CC1A400C 1C32A324
	v_dot2_f32_bf16 v70, v24, v67, v70                         // 0000003D56B0: CC1A4046 1D1A8718
	v_dot2_f32_bf16 v73, v28, v67, v73                         // 0000003D56B8: CC1A4049 1D26871C
	v_dot2_f32_bf16 v75, v32, v67, v76                         // 0000003D56C0: CC1A404B 1D328720
	v_dot2_f32_bf16 v8, v36, v67, v8                           // 0000003D56C8: CC1A4008 1C228724
	v_dot2_f32_bf16 v15, v24, v11, v15                         // 0000003D56D0: CC1A400F 1C3E1718
	v_dot2_f32_bf16 v67, v28, v11, v77                         // 0000003D56D8: CC1A4043 1D36171C
	v_dot2_f32_bf16 v76, v32, v11, v78                         // 0000003D56E0: CC1A404C 1D3A1720
	v_dot2_f32_bf16 v5, v25, v13, v5                           // 0000003D56E8: CC1A4005 1C161B19
	v_dot2_f32_bf16 v68, v29, v13, v68                         // 0000003D56F0: CC1A4044 1D121B1D
	v_dot2_f32_bf16 v69, v33, v13, v69                         // 0000003D56F8: CC1A4045 1D161B21
	v_dot2_f32_bf16 v12, v37, v13, v12                         // 0000003D5700: CC1A400C 1C321B25
	v_dot2_f32_bf16 v13, v25, v9, v70                          // 0000003D5708: CC1A400D 1D1A1319
	v_dot2_f32_bf16 v70, v29, v9, v73                          // 0000003D5710: CC1A4046 1D26131D
	v_dot2_f32_bf16 v73, v33, v9, v75                          // 0000003D5718: CC1A4049 1D2E1321
	v_dot2_f32_bf16 v8, v37, v9, v8                            // 0000003D5720: CC1A4008 1C221325
	v_dot2_f32_bf16 v9, v25, v6, v15                           // 0000003D5728: CC1A4009 1C3E0D19
	v_dot2_f32_bf16 v15, v29, v6, v67                          // 0000003D5730: CC1A400F 1D0E0D1D
	v_dot2_f32_bf16 v67, v33, v6, v76                          // 0000003D5738: CC1A4043 1D320D21
	v_dot2_f32_bf16 v5, v26, v85, v5                           // 0000003D5740: CC1A4005 1C16AB1A
	v_dot2_f32_bf16 v68, v30, v85, v68                         // 0000003D5748: CC1A4044 1D12AB1E
	v_dot2_f32_bf16 v69, v34, v85, v69                         // 0000003D5750: CC1A4045 1D16AB22
	v_dot2_f32_bf16 v12, v38, v85, v12                         // 0000003D5758: CC1A400C 1C32AB26
	v_dot2_f32_bf16 v70, v30, v72, v70                         // 0000003D5760: CC1A4046 1D1A911E
	v_dot2_f32_bf16 v73, v34, v72, v73                         // 0000003D5768: CC1A4049 1D269122
	v_dot2_f32_bf16 v8, v38, v72, v8                           // 0000003D5770: CC1A4008 1C229126
	v_dot2_f32_bf16 v9, v26, v74, v9                           // 0000003D5778: CC1A4009 1C26951A
	v_dot2_f32_bf16 v13, v26, v72, v13                         // 0000003D5780: CC1A400D 1C36911A
	v_dot2_f32_bf16 v15, v30, v74, v15                         // 0000003D5788: CC1A400F 1C3E951E
	v_dot2_f32_bf16 v67, v34, v74, v67                         // 0000003D5790: CC1A4043 1D0E9522
	v_dot2_f32_bf16 v5, v27, v14, v5                           // 0000003D5798: CC1A4005 1C161D1B
	v_dot2_f32_bf16 v68, v31, v14, v68                         // 0000003D57A0: CC1A4044 1D121D1F
	v_dot2_f32_bf16 v69, v35, v14, v69                         // 0000003D57A8: CC1A4045 1D161D23
	v_dot2_f32_bf16 v12, v39, v14, v12                         // 0000003D57B0: CC1A400C 1C321D27
	v_dot2_f32_bf16 v14, v31, v10, v70                         // 0000003D57B8: CC1A400E 1D1A151F
	v_dot2_f32_bf16 v70, v35, v10, v73                         // 0000003D57C0: CC1A4046 1D261523
	v_dot2_f32_bf16 v8, v39, v10, v8                           // 0000003D57C8: CC1A4008 1C221527
	v_dot2_f32_bf16 v9, v27, v7, v9                            // 0000003D57D0: CC1A4009 1C260F1B
	v_dot2_f32_bf16 v13, v27, v10, v13                         // 0000003D57D8: CC1A400D 1C36151B
	v_dot2_f32_bf16 v10, v31, v7, v15                          // 0000003D57E0: CC1A400A 1C3E0F1F
	v_dual_add_f32 v62, v62, v5 :: v_dual_add_f32 v61, v61, v68// 0000003D57E8: C9080B3E 3E3C893D
	v_dual_add_f32 v56, v56, v70 :: v_dual_add_f32 v55, v55, v8// 0000003D57F0: C9088D38 38361137
	s_delay_alu instid0(VALU_DEP_3)                            // 0000003D57F8: BF870003
	v_dual_add_f32 v54, v54, v9 :: v_dual_add_f32 v53, v53, v10// 0000003D57FC: C9081336 36341535
	v_dot2_f32_bf16 v5, v35, v7, v67                           // 0000003D5804: CC1A4005 1D0E0F23
	v_cvt_f32_ubyte2_e32 v8, v0                                // 0000003D580C: 7E102700
	v_fma_mix_f32 v9, v119, v66, v66 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D5810: CC206009 150A8577
	v_cvt_f32_ubyte1_e32 v10, v0                               // 0000003D5818: 7E142500
	v_dot2_f32_bf16 v4, v36, v11, v4                           // 0000003D581C: CC1A4004 1C121724
	v_add_f32_e32 v63, v63, v5                                 // 0000003D5824: 067E0B3F
	v_fma_mix_f32 v5, v8, v66, v66 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D5828: CC206005 150A8508
	v_bfe_u32 v8, v9, 16, 1                                    // 0000003D5830: D6100008 02052109
	v_fma_mix_f32 v10, v10, v66, v66 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D5838: CC20600A 150A850A
	v_cvt_f32_ubyte3_e32 v0, v0                                // 0000003D5840: 7E002900
	v_dot2_f32_bf16 v4, v37, v6, v4                            // 0000003D5844: CC1A4004 1C120D25
	v_bfe_u32 v6, v5, 16, 1                                    // 0000003D584C: D6100006 02052105
	v_add3_u32 v8, v9, v8, 0x7fff                              // 0000003D5854: D6550008 03FE1109 00007FFF
	v_bfe_u32 v9, v10, 16, 1                                   // 0000003D5860: D6100009 0205210A
	v_fma_mix_f32 v0, v0, v66, v66 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D5868: CC206000 150A8500
	v_dual_add_f32 v60, v60, v69 :: v_dual_add_f32 v59, v59, v12// 0000003D5870: C9088B3C 3C3A193B
	s_delay_alu instid0(VALU_DEP_4)                            // 0000003D5878: BF870004
	.long 0x7e683988                                           // 0000003D587C: 7E683988
	v_cvt_f32_ubyte0_e32 v8, v1                                // 0000003D5880: 7E102301
	v_add3_u32 v5, v5, v6, 0x7fff                              // 0000003D5884: D6550005 03FE0D05 00007FFF
	v_add3_u32 v6, v10, v9, 0x7fff                             // 0000003D5890: D6550006 03FE130A 00007FFF
	v_bfe_u32 v9, v0, 16, 1                                    // 0000003D589C: D6100009 02052100
	v_cvt_f32_ubyte2_e32 v10, v1                               // 0000003D58A4: 7E142701
	v_fma_mix_f32 v8, v8, v66, v66 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D58A8: CC206008 150A8508
	.long 0x7e0a3985                                           // 0000003D58B0: 7E0A3985
	.long 0x7f0a39b4                                           // 0000003D58B4: 7F0A39B4
	v_add3_u32 v0, v0, v9, 0x7fff                              // 0000003D58B8: D6550000 03FE1300 00007FFF
	v_cvt_f32_ubyte1_e32 v9, v1                                // 0000003D58C4: 7E122501
	v_bfe_u32 v11, v8, 16, 1                                   // 0000003D58C8: D610000B 02052108
	v_fma_mix_f32 v10, v10, v66, v66 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D58D0: CC20600A 150A850A
	v_cvt_f32_ubyte3_e32 v1, v1                                // 0000003D58D8: 7E022901
	v_and_or_b32 v0, 0xffff0000, v0, v5                        // 0000003D58DC: D6570000 041600FF FFFF0000
	v_fma_mix_f32 v5, v9, v66, v66 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D58E8: CC206005 150A8509
	v_add3_u32 v8, v8, v11, 0x7fff                             // 0000003D58F0: D6550008 03FE1708 00007FFF
	v_cvt_f32_ubyte0_e32 v11, v2                               // 0000003D58FC: 7E162302
	v_and_or_b32 v6, 0xffff0000, v6, v52                       // 0000003D5900: D6570006 04D20CFF FFFF0000
	v_bfe_u32 v9, v10, 16, 1                                   // 0000003D590C: D6100009 0205210A
	v_bfe_u32 v12, v5, 16, 1                                   // 0000003D5914: D610000C 02052105
	v_fma_mix_f32 v1, v1, v66, v66 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D591C: CC206001 150A8501
	.long 0x7e683988                                           // 0000003D5924: 7E683988
	v_fma_mix_f32 v8, v11, v66, v66 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D5928: CC206008 150A850B
	v_dual_add_f32 v58, v58, v13 :: v_dual_add_f32 v57, v57, v14// 0000003D5930: C9081B3A 3A381D39
	v_add3_u32 v9, v10, v9, 0x7fff                             // 0000003D5938: D6550009 03FE130A 00007FFF
	v_add3_u32 v5, v5, v12, 0x7fff                             // 0000003D5944: D6550005 03FE1905 00007FFF
	v_bfe_u32 v10, v1, 16, 1                                   // 0000003D5950: D610000A 02052101
	v_cvt_f32_ubyte1_e32 v11, v2                               // 0000003D5958: 7E162502
	v_bfe_u32 v12, v8, 16, 1                                   // 0000003D595C: D610000C 02052108
	v_cvt_f32_ubyte2_e32 v13, v2                               // 0000003D5964: 7E1A2702
	v_and_or_b32 v5, 0xffff0000, v5, v52                       // 0000003D5968: D6570005 04D20AFF FFFF0000
	v_add3_u32 v1, v1, v10, 0x7fff                             // 0000003D5974: D6550001 03FE1501 00007FFF
	v_fma_mix_f32 v10, v11, v66, v66 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D5980: CC20600A 150A850B
	v_add3_u32 v8, v8, v12, 0x7fff                             // 0000003D5988: D6550008 03FE1908 00007FFF
	v_fma_mix_f32 v11, v13, v66, v66 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D5994: CC20600B 150A850D
	v_cvt_f32_ubyte3_e32 v2, v2                                // 0000003D599C: 7E042902
	v_cvt_f32_ubyte0_e32 v12, v3                               // 0000003D59A0: 7E182303
	.long 0x7e123989                                           // 0000003D59A4: 7E123989
	.long 0x7e683988                                           // 0000003D59A8: 7E683988
	v_bfe_u32 v8, v11, 16, 1                                   // 0000003D59AC: D6100008 0205210B
	.long 0x7f1239b4                                           // 0000003D59B4: 7F1239B4
	v_fma_mix_f32 v2, v2, v66, v66 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D59B8: CC206002 150A8502
	v_dot2_f32_bf16 v4, v38, v74, v4                           // 0000003D59C0: CC1A4004 1C129526
	s_delay_alu instid0(VALU_DEP_4)                            // 0000003D59C8: BF870004
	v_add3_u32 v8, v11, v8, 0x7fff                             // 0000003D59CC: D6550008 03FE110B 00007FFF
	v_fma_mix_f32 v11, v12, v66, v66 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D59D8: CC20600B 150A850C
	v_cvt_f32_ubyte1_e32 v12, v3                               // 0000003D59E0: 7E182503
	v_and_or_b32 v1, 0xffff0000, v1, v9                        // 0000003D59E4: D6570001 042602FF FFFF0000
	v_bfe_u32 v9, v10, 16, 1                                   // 0000003D59F0: D6100009 0205210A
	v_bfe_u32 v13, v2, 16, 1                                   // 0000003D59F8: D610000D 02052102
	v_bfe_u32 v14, v11, 16, 1                                  // 0000003D5A00: D610000E 0205210B
	v_fma_mix_f32 v12, v12, v66, v66 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D5A08: CC20600C 150A850C
	.long 0x7e103988                                           // 0000003D5A10: 7E103988
	v_add3_u32 v9, v10, v9, 0x7fff                             // 0000003D5A14: D6550009 03FE130A 00007FFF
	.long 0x7f1039b4                                           // 0000003D5A20: 7F1039B4
	v_add3_u32 v2, v2, v13, 0x7fff                             // 0000003D5A24: D6550002 03FE1B02 00007FFF
	v_add3_u32 v11, v11, v14, 0x7fff                           // 0000003D5A30: D655000B 03FE1D0B 00007FFF
	v_bfe_u32 v13, v12, 16, 1                                  // 0000003D5A3C: D610000D 0205210C
	v_and_or_b32 v9, 0xffff0000, v9, v52                       // 0000003D5A44: D6570009 04D212FF FFFF0000
	v_cvt_f32_ubyte2_e32 v10, v3                               // 0000003D5A50: 7E142703
	v_and_or_b32 v2, 0xffff0000, v2, v8                        // 0000003D5A54: D6570002 042204FF FFFF0000
	.long 0x7e68398b                                           // 0000003D5A60: 7E68398B
	v_add3_u32 v8, v12, v13, 0x7fff                            // 0000003D5A64: D6550008 03FE1B0C 00007FFF
	v_dot2_f32_bf16 v11, v16, v6, 0                            // 0000003D5A70: CC1A400B 1A020D10
	v_dot2_f32_bf16 v12, v20, v6, 0                            // 0000003D5A78: CC1A400C 1A020D14
	v_dot2_f32_bf16 v13, v40, v6, 0                            // 0000003D5A80: CC1A400D 1A020D28
	v_dot2_f32_bf16 v6, v44, v6, 0                             // 0000003D5A88: CC1A4006 1A020D2C
	v_cvt_f32_ubyte3_e32 v3, v3                                // 0000003D5A90: 7E062903
	v_dot2_f32_bf16 v11, v17, v0, v11                          // 0000003D5A94: CC1A400B 1C2E0111
	v_dot2_f32_bf16 v12, v21, v0, v12                          // 0000003D5A9C: CC1A400C 1C320115
	v_dot2_f32_bf16 v13, v41, v0, v13                          // 0000003D5AA4: CC1A400D 1C360129
	v_dot2_f32_bf16 v0, v45, v0, v6                            // 0000003D5AAC: CC1A4000 1C1A012D
	v_fma_mix_f32 v10, v10, v66, v66 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D5AB4: CC20600A 150A850A
	v_fma_mix_f32 v3, v3, v66, v66 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D5ABC: CC206003 150A8503
	v_dot2_f32_bf16 v6, v18, v5, v11                           // 0000003D5AC4: CC1A4006 1C2E0B12
	v_dot2_f32_bf16 v11, v22, v5, v12                          // 0000003D5ACC: CC1A400B 1C320B16
	v_dot2_f32_bf16 v12, v42, v5, v13                          // 0000003D5AD4: CC1A400C 1C360B2A
	v_dot2_f32_bf16 v0, v46, v5, v0                            // 0000003D5ADC: CC1A4000 1C020B2E
	v_bfe_u32 v15, v10, 16, 1                                  // 0000003D5AE4: D610000F 0205210A
	v_bfe_u32 v5, v3, 16, 1                                    // 0000003D5AEC: D6100005 02052103
	v_dot2_f32_bf16 v6, v19, v1, v6                            // 0000003D5AF4: CC1A4006 1C1A0313
	v_dot2_f32_bf16 v11, v23, v1, v11                          // 0000003D5AFC: CC1A400B 1C2E0317
	v_dot2_f32_bf16 v12, v43, v1, v12                          // 0000003D5B04: CC1A400C 1C32032B
	v_dot2_f32_bf16 v0, v47, v1, v0                            // 0000003D5B0C: CC1A4000 1C02032F
	v_add3_u32 v10, v10, v15, 0x7fff                           // 0000003D5B14: D655000A 03FE1F0A 00007FFF
	v_add3_u32 v1, v3, v5, 0x7fff                              // 0000003D5B20: D6550001 03FE0B03 00007FFF
	v_dot2_f32_bf16 v3, v24, v9, v6                            // 0000003D5B2C: CC1A4003 1C1A1318
	v_dot2_f32_bf16 v5, v28, v9, v11                           // 0000003D5B34: CC1A4005 1C2E131C
	v_dot2_f32_bf16 v6, v32, v9, v12                           // 0000003D5B3C: CC1A4006 1C321320
	v_dot2_f32_bf16 v0, v36, v9, v0                            // 0000003D5B44: CC1A4000 1C021324
	.long 0x7e14398a                                           // 0000003D5B4C: 7E14398A
	.long 0x7f1439b4                                           // 0000003D5B50: 7F1439B4
	v_and_or_b32 v8, 0xffff0000, v8, v52                       // 0000003D5B54: D6570008 04D210FF FFFF0000
	v_dot2_f32_bf16 v3, v25, v2, v3                            // 0000003D5B60: CC1A4003 1C0E0519
	v_dot2_f32_bf16 v5, v29, v2, v5                            // 0000003D5B68: CC1A4005 1C16051D
	v_dot2_f32_bf16 v6, v33, v2, v6                            // 0000003D5B70: CC1A4006 1C1A0521
	v_dot2_f32_bf16 v0, v37, v2, v0                            // 0000003D5B78: CC1A4000 1C020525
	v_and_or_b32 v1, 0xffff0000, v1, v10                       // 0000003D5B80: D6570001 042A02FF FFFF0000
	v_dot2_f32_bf16 v2, v26, v8, v3                            // 0000003D5B8C: CC1A4002 1C0E111A
	v_dot2_f32_bf16 v3, v30, v8, v5                            // 0000003D5B94: CC1A4003 1C16111E
	v_dot2_f32_bf16 v5, v34, v8, v6                            // 0000003D5B9C: CC1A4005 1C1A1122
	v_dot2_f32_bf16 v0, v38, v8, v0                            // 0000003D5BA4: CC1A4000 1C021126
	v_dot2_f32_bf16 v4, v39, v7, v4                            // 0000003D5BAC: CC1A4004 1C120F27
	v_dot2_f32_bf16 v2, v27, v1, v2                            // 0000003D5BB4: CC1A4002 1C0A031B
	v_dot2_f32_bf16 v3, v31, v1, v3                            // 0000003D5BBC: CC1A4003 1C0E031F
	v_dot2_f32_bf16 v5, v35, v1, v5                            // 0000003D5BC4: CC1A4005 1C160323
	v_dot2_f32_bf16 v0, v39, v1, v0                            // 0000003D5BCC: CC1A4000 1C020327
	v_add_f32_e32 v71, v71, v4                                 // 0000003D5BD4: 068E0947
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003D5BD8: BF870194
	v_dual_add_f32 v51, v51, v2 :: v_dual_add_f32 v50, v50, v3 // 0000003D5BDC: C9080533 33320732
	v_dual_add_f32 v49, v49, v5 :: v_dual_add_f32 v48, v48, v0 // 0000003D5BE4: C9080B31 31300130
	s_or_b32 exec_lo, exec_lo, s0                              // 0000003D5BEC: 8C7E007E
	.long 0xd71f0000                                           // 0000003D5BF0: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000003D5BF4: 020100C1
	s_mov_b32 s0, exec_lo                                      // 0000003D5BF8: BE80007E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000003D5BFC: BF8701B1
	v_xor_b32_e32 v1, 8, v0                                    // 0000003D5C00: 3A020088
	v_xor_b32_e32 v2, 4, v0                                    // 0000003D5C04: 3A040084
	v_xor_b32_e32 v17, 2, v0                                   // 0000003D5C08: 3A220082
	v_cmp_gt_u32_e32 vcc_lo, 32, v1                            // 0000003D5C0C: 7C9802A0
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 0000003D5C10: 02020300
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000003D5C14: BF870134
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 0000003D5C18: 7C9804A0
	v_cndmask_b32_e32 v2, v0, v2, vcc_lo                       // 0000003D5C1C: 02040500
	v_cmp_gt_u32_e32 vcc_lo, 32, v17                           // 0000003D5C20: 7C9822A0
	v_lshlrev_b32_e32 v2, 2, v2                                // 0000003D5C24: 30040482
	v_lshlrev_b32_e32 v1, 2, v1                                // 0000003D5C28: 30020282
	ds_bpermute_b32 v4, v1, v61                                // 0000003D5C2C: DACC0000 04003D01
	s_waitcnt lgkmcnt(0)                                       // 0000003D5C34: BF89FC07
	v_add_f32_e32 v4, v61, v4                                  // 0000003D5C38: 0608093D
	ds_bpermute_b32 v3, v1, v62                                // 0000003D5C3C: DACC0000 03003E01
	ds_bpermute_b32 v5, v1, v60                                // 0000003D5C44: DACC0000 05003C01
	ds_bpermute_b32 v6, v1, v59                                // 0000003D5C4C: DACC0000 06003B01
	ds_bpermute_b32 v7, v1, v58                                // 0000003D5C54: DACC0000 07003A01
	ds_bpermute_b32 v8, v1, v57                                // 0000003D5C5C: DACC0000 08003901
	ds_bpermute_b32 v14, v1, v71                               // 0000003D5C64: DACC0000 0E004701
	ds_bpermute_b32 v15, v1, v51                               // 0000003D5C6C: DACC0000 0F003301
	ds_bpermute_b32 v9, v1, v56                                // 0000003D5C74: DACC0000 09003801
	ds_bpermute_b32 v10, v1, v55                               // 0000003D5C7C: DACC0000 0A003701
	ds_bpermute_b32 v11, v1, v54                               // 0000003D5C84: DACC0000 0B003601
	ds_bpermute_b32 v12, v1, v53                               // 0000003D5C8C: DACC0000 0C003501
	ds_bpermute_b32 v13, v1, v63                               // 0000003D5C94: DACC0000 0D003F01
	ds_bpermute_b32 v16, v1, v50                               // 0000003D5C9C: DACC0000 10003201
	ds_bpermute_b32 v18, v1, v49                               // 0000003D5CA4: DACC0000 12003101
	ds_bpermute_b32 v1, v1, v48                                // 0000003D5CAC: DACC0000 01003001
	ds_bpermute_b32 v20, v2, v4                                // 0000003D5CB4: DACC0000 14000402
	s_waitcnt lgkmcnt(15)                                      // 0000003D5CBC: BF89FCF7
	v_add_f32_e32 v3, v62, v3                                  // 0000003D5CC0: 0606073E
	s_waitcnt lgkmcnt(13)                                      // 0000003D5CC4: BF89FCD7
	v_dual_add_f32 v5, v60, v5 :: v_dual_add_f32 v6, v59, v6   // 0000003D5CC8: C9080B3C 05060D3B
	s_waitcnt lgkmcnt(11)                                      // 0000003D5CD0: BF89FCB7
	v_dual_add_f32 v7, v58, v7 :: v_dual_add_f32 v8, v57, v8   // 0000003D5CD4: C9080F3A 07081139
	s_waitcnt lgkmcnt(10)                                      // 0000003D5CDC: BF89FCA7
	v_add_f32_e32 v14, v71, v14                                // 0000003D5CE0: 061C1D47
	s_waitcnt lgkmcnt(9)                                       // 0000003D5CE4: BF89FC97
	v_add_f32_e32 v15, v51, v15                                // 0000003D5CE8: 061E1F33
	ds_bpermute_b32 v19, v2, v3                                // 0000003D5CEC: DACC0000 13000302
	ds_bpermute_b32 v21, v2, v5                                // 0000003D5CF4: DACC0000 15000502
	ds_bpermute_b32 v22, v2, v6                                // 0000003D5CFC: DACC0000 16000602
	ds_bpermute_b32 v23, v2, v7                                // 0000003D5D04: DACC0000 17000702
	ds_bpermute_b32 v24, v2, v8                                // 0000003D5D0C: DACC0000 18000802
	s_waitcnt lgkmcnt(12)                                      // 0000003D5D14: BF89FCC7
	v_dual_add_f32 v9, v56, v9 :: v_dual_add_f32 v10, v55, v10 // 0000003D5D18: C9081338 090A1537
	s_waitcnt lgkmcnt(7)                                       // 0000003D5D20: BF89FC77
	v_add_f32_e32 v18, v49, v18                                // 0000003D5D24: 06242531
	ds_bpermute_b32 v31, v2, v15                               // 0000003D5D28: DACC0000 1F000F02
	s_waitcnt lgkmcnt(7)                                       // 0000003D5D30: BF89FC77
	v_add_f32_e32 v1, v48, v1                                  // 0000003D5D34: 06020330
	ds_bpermute_b32 v30, v2, v14                               // 0000003D5D38: DACC0000 1E000E02
	v_dual_add_f32 v11, v54, v11 :: v_dual_add_f32 v12, v53, v12// 0000003D5D40: C9081736 0B0C1935
	v_dual_add_f32 v13, v63, v13 :: v_dual_add_f32 v16, v50, v16// 0000003D5D48: C9081B3F 0D102132
	ds_bpermute_b32 v25, v2, v9                                // 0000003D5D50: DACC0000 19000902
	v_cndmask_b32_e32 v17, v0, v17, vcc_lo                     // 0000003D5D58: 02222300
	ds_bpermute_b32 v26, v2, v10                               // 0000003D5D5C: DACC0000 1A000A02
	ds_bpermute_b32 v27, v2, v11                               // 0000003D5D64: DACC0000 1B000B02
	ds_bpermute_b32 v28, v2, v12                               // 0000003D5D6C: DACC0000 1C000C02
	ds_bpermute_b32 v29, v2, v13                               // 0000003D5D74: DACC0000 1D000D02
	ds_bpermute_b32 v32, v2, v16                               // 0000003D5D7C: DACC0000 20001002
	ds_bpermute_b32 v33, v2, v18                               // 0000003D5D84: DACC0000 21001202
	ds_bpermute_b32 v2, v2, v1                                 // 0000003D5D8C: DACC0000 02000102
	s_waitcnt lgkmcnt(14)                                      // 0000003D5D94: BF89FCE7
	v_dual_add_f32 v3, v3, v19 :: v_dual_add_f32 v4, v4, v20   // 0000003D5D98: C9082703 03042904
	s_waitcnt lgkmcnt(10)                                      // 0000003D5DA0: BF89FCA7
	v_dual_add_f32 v5, v5, v21 :: v_dual_add_f32 v8, v8, v24   // 0000003D5DA4: C9082B05 05083108
	v_dual_add_f32 v6, v6, v22 :: v_dual_lshlrev_b32 v17, 2, v17// 0000003D5DAC: C9222D06 06102282
	s_waitcnt lgkmcnt(9)                                       // 0000003D5DB4: BF89FC97
	v_add_f32_e32 v20, v15, v31                                // 0000003D5DB8: 06283F0F
	v_add_f32_e32 v7, v7, v23                                  // 0000003D5DBC: 060E2F07
	ds_bpermute_b32 v15, v17, v4                               // 0000003D5DC0: DACC0000 0F000411
	s_waitcnt lgkmcnt(9)                                       // 0000003D5DC8: BF89FC97
	v_add_f32_e32 v19, v14, v30                                // 0000003D5DCC: 06263D0E
	ds_bpermute_b32 v14, v17, v3                               // 0000003D5DD0: DACC0000 0E000311
	ds_bpermute_b32 v21, v17, v5                               // 0000003D5DD8: DACC0000 15000511
	ds_bpermute_b32 v23, v17, v6                               // 0000003D5DE0: DACC0000 17000611
	s_waitcnt lgkmcnt(8)                                       // 0000003D5DE8: BF89FC87
	v_dual_add_f32 v9, v9, v25 :: v_dual_add_f32 v12, v12, v28 // 0000003D5DEC: C9083309 090C390C
	v_dual_add_f32 v10, v10, v26 :: v_dual_add_f32 v11, v11, v27// 0000003D5DF4: C908350A 0A0A370B
	s_waitcnt lgkmcnt(5)                                       // 0000003D5DFC: BF89FC57
	v_add_f32_e32 v18, v18, v33                                // 0000003D5E00: 06244312
	v_add_f32_e32 v13, v13, v29                                // 0000003D5E04: 061A3B0D
	v_add_f32_e32 v25, v16, v32                                // 0000003D5E08: 06324110
	ds_bpermute_b32 v26, v17, v9                               // 0000003D5E0C: DACC0000 1A000911
	s_waitcnt lgkmcnt(5)                                       // 0000003D5E14: BF89FC57
	v_add_f32_e32 v1, v1, v2                                   // 0000003D5E18: 06020501
	ds_bpermute_b32 v16, v17, v7                               // 0000003D5E1C: DACC0000 10000711
	ds_bpermute_b32 v24, v17, v8                               // 0000003D5E24: DACC0000 18000811
	ds_bpermute_b32 v27, v17, v10                              // 0000003D5E2C: DACC0000 1B000A11
	ds_bpermute_b32 v28, v17, v11                              // 0000003D5E34: DACC0000 1C000B11
	ds_bpermute_b32 v29, v17, v12                              // 0000003D5E3C: DACC0000 1D000C11
	ds_bpermute_b32 v32, v17, v20                              // 0000003D5E44: DACC0000 20001411
	ds_bpermute_b32 v34, v17, v18                              // 0000003D5E4C: DACC0000 22001211
	s_waitcnt lgkmcnt(11)                                      // 0000003D5E54: BF89FCB7
	v_add_f32_e32 v22, v4, v15                                 // 0000003D5E58: 062C1F04
	ds_bpermute_b32 v31, v17, v19                              // 0000003D5E5C: DACC0000 1F001311
	s_waitcnt lgkmcnt(11)                                      // 0000003D5E64: BF89FCB7
	v_add_f32_e32 v2, v3, v14                                  // 0000003D5E68: 06041D03
	ds_bpermute_b32 v30, v17, v13                              // 0000003D5E6C: DACC0000 1E000D11
	s_waitcnt lgkmcnt(11)                                      // 0000003D5E74: BF89FCB7
	v_add_f32_e32 v14, v5, v21                                 // 0000003D5E78: 061C2B05
	ds_bpermute_b32 v33, v17, v25                              // 0000003D5E7C: DACC0000 21001911
	s_waitcnt lgkmcnt(11)                                      // 0000003D5E84: BF89FCB7
	v_add_f32_e32 v6, v6, v23                                  // 0000003D5E88: 060C2F06
	ds_bpermute_b32 v35, v17, v1                               // 0000003D5E8C: DACC0000 23000111
	v_xor_b32_e32 v4, 1, v0                                    // 0000003D5E94: 3A080081
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003D5E98: BF870001
	v_cmp_gt_u32_e32 vcc_lo, 32, v4                            // 0000003D5E9C: 7C9808A0
	s_waitcnt lgkmcnt(11)                                      // 0000003D5EA0: BF89FCB7
	v_add_f32_e32 v15, v9, v26                                 // 0000003D5EA4: 061E3509
	s_waitcnt lgkmcnt(10)                                      // 0000003D5EA8: BF89FCA7
	v_add_f32_e32 v3, v7, v16                                  // 0000003D5EAC: 06062107
	s_waitcnt lgkmcnt(9)                                       // 0000003D5EB0: BF89FC97
	v_add_f32_e32 v23, v8, v24                                 // 0000003D5EB4: 062E3108
	s_waitcnt lgkmcnt(8)                                       // 0000003D5EB8: BF89FC87
	v_dual_add_f32 v7, v10, v27 :: v_dual_cndmask_b32 v0, v0, v4// 0000003D5EBC: C912370A 07000900
	s_waitcnt lgkmcnt(7)                                       // 0000003D5EC4: BF89FC77
	v_add_f32_e32 v4, v11, v28                                 // 0000003D5EC8: 0608390B
	s_waitcnt lgkmcnt(6)                                       // 0000003D5ECC: BF89FC67
	v_add_f32_e32 v24, v12, v29                                // 0000003D5ED0: 06303B0C
	s_waitcnt lgkmcnt(3)                                       // 0000003D5ED4: BF89FC37
	v_dual_add_f32 v8, v19, v31 :: v_dual_add_f32 v5, v20, v32 // 0000003D5ED8: C9083F13 08044114
	s_waitcnt lgkmcnt(2)                                       // 0000003D5EE0: BF89FC27
	v_add_f32_e32 v16, v13, v30                                // 0000003D5EE4: 06203D0D
	s_waitcnt lgkmcnt(1)                                       // 0000003D5EE8: BF89FC17
	v_dual_add_f32 v25, v25, v33 :: v_dual_lshlrev_b32 v0, 2, v0// 0000003D5EEC: C9224319 19000082
	v_add_f32_e32 v17, v18, v34                                // 0000003D5EF4: 06224512
	s_waitcnt lgkmcnt(0)                                       // 0000003D5EF8: BF89FC07
	v_add_f32_e32 v9, v1, v35                                  // 0000003D5EFC: 06124701
	ds_bpermute_b32 v30, v0, v2                                // 0000003D5F00: DACC0000 1E000200
	ds_bpermute_b32 v26, v0, v22                               // 0000003D5F08: DACC0000 1A001600
	ds_bpermute_b32 v18, v0, v14                               // 0000003D5F10: DACC0000 12000E00
	ds_bpermute_b32 v10, v0, v6                                // 0000003D5F18: DACC0000 0A000600
	ds_bpermute_b32 v31, v0, v3                                // 0000003D5F20: DACC0000 1F000300
	ds_bpermute_b32 v27, v0, v23                               // 0000003D5F28: DACC0000 1B001700
	ds_bpermute_b32 v19, v0, v15                               // 0000003D5F30: DACC0000 13000F00
	ds_bpermute_b32 v11, v0, v7                                // 0000003D5F38: DACC0000 0B000700
	ds_bpermute_b32 v32, v0, v4                                // 0000003D5F40: DACC0000 20000400
	ds_bpermute_b32 v28, v0, v24                               // 0000003D5F48: DACC0000 1C001800
	ds_bpermute_b32 v20, v0, v16                               // 0000003D5F50: DACC0000 14001000
	ds_bpermute_b32 v12, v0, v8                                // 0000003D5F58: DACC0000 0C000800
	ds_bpermute_b32 v33, v0, v5                                // 0000003D5F60: DACC0000 21000500
	ds_bpermute_b32 v29, v0, v25                               // 0000003D5F68: DACC0000 1D001900
	ds_bpermute_b32 v21, v0, v17                               // 0000003D5F70: DACC0000 15001100
	ds_bpermute_b32 v13, v0, v9                                // 0000003D5F78: DACC0000 0D000900
	v_cmpx_eq_u32_e32 0, v65                                   // 0000003D5F80: 7D948280
	s_cbranch_execz 1030                                       // 0000003D5F84: BFA50406 <_ZN7halogen12_GLOBAL__N_17k_hcup8ILi4EEEvPKhPKtS5_PtPf+0x33a0>
	v_ashrrev_i32_e32 v65, 31, v64                             // 0000003D5F88: 3482809F
	s_waitcnt lgkmcnt(11)                                      // 0000003D5F8C: BF89FCB7
	v_dual_add_f32 v2, v2, v30 :: v_dual_add_f32 v3, v3, v31   // 0000003D5F90: C9083D02 02023F03
	s_waitcnt lgkmcnt(3)                                       // 0000003D5F98: BF89FC37
	v_dual_add_f32 v4, v4, v32 :: v_dual_add_f32 v5, v5, v33   // 0000003D5F9C: C9084104 04044305
	.long 0xd73c0022                                           // 0000003D5FA4: D73C0022
	v_cndmask_b32_e32 v1, 1, v64, vcc_lo                       // 0000003D5FA8: 02028081
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000003D5FAC: BF870223
	v_bfe_u32 v30, v2, 16, 1                                   // 0000003D5FB0: D610001E 02052102
	v_bfe_u32 v31, v3, 16, 1                                   // 0000003D5FB8: D610001F 02052103
	v_bfe_u32 v32, v4, 16, 1                                   // 0000003D5FC0: D6100020 02052104
	v_bfe_u32 v33, v5, 16, 1                                   // 0000003D5FC8: D6100021 02052105
	s_cmp_lg_u64 s[4:5], 0                                     // 0000003D5FD0: BF118004
	.long 0xd7006a00                                           // 0000003D5FD4: D7006A00
	v_cndmask_b32_e32 v1, s8, v34, vcc_lo                      // 0000003D5FD8: 02024408
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000003D5FDC: BF8701A1
	v_add_co_ci_u32_e64 v1, null, s9, v35, vcc_lo              // 0000003D5FE0: D5207C01 01AA4609
	v_add3_u32 v3, v3, v31, 0x7fff                             // 0000003D5FE8: D6550003 03FE3F03 00007FFF
	.long 0xd7006a24                                           // 0000003D5FF4: D7006A24
	v_cndmask_b32_e32 v1, 0x2000, v0, vcc_lo                   // 0000003D5FF8: 020200FF 00002000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003D6000: BF8700A1
	v_add_co_ci_u32_e64 v37, null, 0, v1, vcc_lo               // 0000003D6004: D5207C25 01AA0280
	.long 0xd7006a26                                           // 0000003D600C: D7006A26
	v_cndmask_b32_e32 v1, 0x3000, v0, vcc_lo                   // 0000003D6010: 020200FF 00003000
	v_add_co_ci_u32_e64 v39, null, 0, v1, vcc_lo               // 0000003D6018: D5207C27 01AA0280
	.long 0xd7006a28                                           // 0000003D6020: D7006A28
	v_cndmask_b32_e32 v1, 0x1000, v0, vcc_lo                   // 0000003D6024: 020200FF 00001000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003D602C: BF870001
	v_add_co_ci_u32_e64 v41, null, 0, v1, vcc_lo               // 0000003D6030: D5207C29 01AA0280
	s_clause 0x3                                               // 0000003D6038: BF850003
	global_load_u16 v36, v[36:37], off offset:2048             // 0000003D603C: DC4A0800 247C0024
	global_load_u16 v37, v[38:39], off offset:3072             // 0000003D6044: DC4A0C00 257C0026
	global_load_u16 v38, v[0:1], off                           // 0000003D604C: DC4A0000 267C0000
	global_load_u16 v39, v[40:41], off offset:1024             // 0000003D6054: DC4A0400 277C0028
	v_and_b32_e32 v3, 0xffff0000, v3                           // 0000003D605C: 360606FF FFFF0000
	v_add3_u32 v2, v2, v30, 0x7fff                             // 0000003D6064: D6550002 03FE3D02 00007FFF
	v_add3_u32 v5, v5, v33, 0x7fff                             // 0000003D6070: D6550005 03FE4305 00007FFF
	v_add3_u32 v4, v4, v32, 0x7fff                             // 0000003D607C: D6550004 03FE4104 00007FFF
	s_cselect_b32 s3, -1, 0                                    // 0000003D6088: 980380C1
	v_mul_f32_e32 v3, 0xbfb8aa3b, v3                           // 0000003D608C: 100606FF BFB8AA3B
	s_cmp_eq_u64 s[4:5], 0                                     // 0000003D6094: BF108004
	v_and_b32_e32 v5, 0xffff0000, v5                           // 0000003D6098: 360A0AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000003D60A0: BF870122
	v_exp_f32_e32 v3, v3                                       // 0000003D60A4: 7E064B03
	v_and_b32_e32 v2, 0xffff0000, v2                           // 0000003D60A8: 360404FF FFFF0000
	v_mul_f32_e32 v5, 0xbfb8aa3b, v5                           // 0000003D60B0: 100A0AFF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 0000003D60B8: BF870311
	v_exp_f32_e32 v5, v5                                       // 0000003D60BC: 7E0A4B05
	v_dual_add_f32 v3, 1.0, v3 :: v_dual_and_b32 v4, 0xffff0000, v4// 0000003D60C0: C92406F2 030408FF FFFF0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003D60CC: BF870113
	v_mul_f32_e32 v2, 0xbfb8aa3b, v2                           // 0000003D60D0: 100404FF BFB8AA3B
	v_div_scale_f32 v31, null, v3, v3, 1.0                     // 0000003D60D8: D6FC7C1F 03CA0703
	s_delay_alu instid0(VALU_DEP_2)                            // 0000003D60E0: BF870002
	v_exp_f32_e32 v2, v2                                       // 0000003D60E4: 7E044B02
	s_delay_alu instid0(TRANS32_DEP_2) | instid1(VALU_DEP_3)   // 0000003D60E8: BF870186
	v_dual_add_f32 v5, 1.0, v5 :: v_dual_mul_f32 v4, 0xbfb8aa3b, v4// 0000003D60EC: C9060AF2 050408FF BFB8AA3B
	v_div_scale_f32 v45, s0, 1.0, v3, 1.0                      // 0000003D60F8: D6FC002D 03CA06F2
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003D6100: BF870113
	v_rcp_f32_e32 v41, v31                                     // 0000003D6104: 7E52551F
	v_div_scale_f32 v33, null, v5, v5, 1.0                     // 0000003D6108: D6FC7C21 03CA0B05
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_3)// 0000003D6110: BF870393
	v_exp_f32_e32 v4, v4                                       // 0000003D6114: 7E084B04
	v_add_f32_e32 v2, 1.0, v2                                  // 0000003D6118: 060404F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_3)// 0000003D611C: BF870392
	v_rcp_f32_e32 v43, v33                                     // 0000003D6120: 7E565521
	v_fma_f32 v47, -v31, v41, 1.0                              // 0000003D6124: D613002F 23CA531F
	s_delay_alu instid0(VALU_DEP_2)                            // 0000003D612C: BF870002
	v_div_scale_f32 v30, null, v2, v2, 1.0                     // 0000003D6130: D6FC7C1E 03CA0502
	v_div_scale_f32 v44, vcc_lo, 1.0, v2, 1.0                  // 0000003D6138: D6FC6A2C 03CA04F2
	s_delay_alu instid0(TRANS32_DEP_2) | instid1(VALU_DEP_3)   // 0000003D6140: BF870186
	v_dual_add_f32 v4, 1.0, v4 :: v_dual_fmac_f32 v41, v47, v41// 0000003D6144: C90008F2 0428532F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 0000003D614C: BF870313
	v_rcp_f32_e32 v40, v30                                     // 0000003D6150: 7E50551E
	v_fma_f32 v50, -v33, v43, 1.0                              // 0000003D6154: D6130032 23CA5721
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000003D615C: BF8701A2
	v_div_scale_f32 v32, null, v4, v4, 1.0                     // 0000003D6160: D6FC7C20 03CA0904
	v_div_scale_f32 v49, s1, 1.0, v4, 1.0                      // 0000003D6168: D6FC0131 03CA08F2
	v_fmac_f32_e32 v43, v50, v43                               // 0000003D6170: 56565732
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 0000003D6174: BF870313
	v_rcp_f32_e32 v42, v32                                     // 0000003D6178: 7E545520
	v_fma_f32 v46, -v30, v40, 1.0                              // 0000003D617C: D613002E 23CA511E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(TRANS32_DEP_1)// 0000003D6184: BF8702A1
	v_fmac_f32_e32 v40, v46, v40                               // 0000003D6188: 5650512E
	v_div_scale_f32 v46, s2, 1.0, v5, 1.0                      // 0000003D618C: D6FC022E 03CA0AF2
	v_fma_f32 v48, -v32, v42, 1.0                              // 0000003D6194: D6130030 23CA5520
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003D619C: BF870113
	v_mul_f32_e32 v47, v44, v40                                // 0000003D61A0: 105E512C
	v_dual_mul_f32 v51, v46, v43 :: v_dual_fmac_f32 v42, v48, v42// 0000003D61A4: C8C0572E 332A5530
	v_mul_f32_e32 v48, v45, v41                                // 0000003D61AC: 1060532D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003D61B0: BF870193
	v_fma_f32 v52, -v30, v47, v44                              // 0000003D61B4: D6130034 24B25F1E
	v_fma_f32 v55, -v33, v51, v46                              // 0000003D61BC: D6130037 24BA6721
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003D61C4: BF870214
	v_mul_f32_e32 v50, v49, v42                                // 0000003D61C8: 10645531
	v_fma_f32 v53, -v31, v48, v45                              // 0000003D61CC: D6130035 24B6611F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003D61D4: BF870214
	v_fmac_f32_e32 v47, v52, v40                               // 0000003D61D8: 565E5134
	v_fmac_f32_e32 v51, v55, v43                               // 0000003D61DC: 56665737
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003D61E0: BF870214
	v_fma_f32 v54, -v32, v50, v49                              // 0000003D61E4: D6130036 24C66520
	v_fmac_f32_e32 v48, v53, v41                               // 0000003D61EC: 56605335
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003D61F0: BF870214
	v_fma_f32 v30, -v30, v47, v44                              // 0000003D61F4: D613001E 24B25F1E
	v_fma_f32 v33, -v33, v51, v46                              // 0000003D61FC: D6130021 24BA6721
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003D6204: BF870214
	v_fmac_f32_e32 v50, v54, v42                               // 0000003D6208: 56645536
	v_fma_f32 v31, -v31, v48, v45                              // 0000003D620C: D613001F 24B6611F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000003D6214: BF8701A4
	v_div_fmas_f32 v30, v30, v40, v47                          // 0000003D6218: D637001E 04BE511E
	s_mov_b32 vcc_lo, s0                                       // 0000003D6220: BEEA0000
	v_fma_f32 v32, -v32, v50, v49                              // 0000003D6224: D6130020 24C66520
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000003D622C: BF8701B3
	v_div_fmas_f32 v31, v31, v41, v48                          // 0000003D6230: D637001F 04C2531F
	s_mov_b32 vcc_lo, s1                                       // 0000003D6238: BEEA0001
	v_div_fixup_f32 v2, v30, v2, 1.0                           // 0000003D623C: D6270002 03CA051E
	v_div_fmas_f32 v30, v32, v42, v50                          // 0000003D6244: D637001E 04CA5520
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000003D624C: BF8701A3
	v_div_fixup_f32 v3, v31, v3, 1.0                           // 0000003D6250: D6270003 03CA071F
	s_mov_b32 vcc_lo, s2                                       // 0000003D6258: BEEA0002
	v_bfe_u32 v31, v2, 16, 1                                   // 0000003D625C: D610001F 02052102
	v_div_fmas_f32 v32, v33, v43, v51                          // 0000003D6264: D6370020 04CE5721
	v_div_fixup_f32 v4, v30, v4, 1.0                           // 0000003D626C: D6270004 03CA091E
	v_bfe_u32 v30, v3, 16, 1                                   // 0000003D6274: D610001E 02052103
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003D627C: BF870214
	v_add3_u32 v2, v2, v31, 0x7fff                             // 0000003D6280: D6550002 03FE3F02 00007FFF
	v_div_fixup_f32 v5, v32, v5, 1.0                           // 0000003D628C: D6270005 03CA0B20
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003D6294: BF870214
	v_bfe_u32 v31, v4, 16, 1                                   // 0000003D6298: D610001F 02052104
	v_add3_u32 v3, v3, v30, 0x7fff                             // 0000003D62A0: D6550003 03FE3D03 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003D62AC: BF870214
	v_and_b32_e32 v2, 0xffff0000, v2                           // 0000003D62B0: 360404FF FFFF0000
	v_bfe_u32 v32, v5, 16, 1                                   // 0000003D62B8: D6100020 02052105
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003D62C0: BF870114
	v_add3_u32 v4, v4, v31, 0x7fff                             // 0000003D62C4: D6550004 03FE3F04 00007FFF
	v_add3_u32 v5, v5, v32, 0x7fff                             // 0000003D62D0: D6550005 03FE4105 00007FFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 0000003D62DC: BF870152
	v_and_b32_e32 v4, 0xffff0000, v4                           // 0000003D62E0: 360808FF FFFF0000
	s_waitcnt vmcnt(1)                                         // 0000003D62E8: BF8907F7
	v_lshlrev_b32_e32 v30, 16, v38                             // 0000003D62EC: 303C4C90
	s_waitcnt vmcnt(0)                                         // 0000003D62F0: BF8903F7
	v_lshlrev_b32_e32 v31, 16, v39                             // 0000003D62F4: 303E4E90
	v_fma_f32 v2, v2, v30, 0                                   // 0000003D62F8: D6130002 02023D02
	v_lshlrev_b32_e32 v30, 16, v36                             // 0000003D6300: 303C4890
	v_and_b32_e32 v3, 0xffff0000, v3                           // 0000003D6304: 360606FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003D630C: BF870091
	v_dual_fmac_f32 v2, v3, v31 :: v_dual_and_b32 v3, 0xffff0000, v5// 0000003D6310: C8243F03 02020AFF FFFF0000
	v_dual_fmac_f32 v2, v4, v30 :: v_dual_lshlrev_b32 v5, 16, v37// 0000003D631C: C8223D04 02044A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003D6324: BF870091
	v_fmac_f32_e32 v2, v3, v5                                  // 0000003D6328: 56040B03
	v_mul_f32_e32 v30, 0x3e800000, v2                          // 0000003D632C: 103C04FF 3E800000
	.long 0xd7006a02                                           // 0000003D6334: D7006A02
	v_cndmask_b32_e32 v1, s10, v34, vcc_lo                     // 0000003D6338: 0202440A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003D633C: BF870191
	v_add_co_ci_u32_e64 v3, null, s11, v35, vcc_lo             // 0000003D6340: D5207C03 01AA460B
	v_bfe_u32 v4, v30, 16, 1                                   // 0000003D6348: D6100004 0205211E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003D6350: BF870001
	v_add3_u32 v31, v30, v4, 0x7fff                            // 0000003D6354: D655001F 03FE091E 00007FFF
	.long 0xd73c0004                                           // 0000003D6360: D73C0004
	v_cndmask_b32_e32 v1, 2, v64, vcc_lo                       // 0000003D6364: 02028082
	global_store_d16_hi_b16 v[2:3], v31, off                   // 0000003D6368: DC960000 007C1F02
	s_cbranch_scc1 7                                           // 0000003D6370: BFA20007 <_ZN7halogen12_GLOBAL__N_17k_hcup8ILi4EEEvPKhPKtS5_PtPf+0x2790>
	.long 0xd7006a1f                                           // 0000003D6374: D7006A1F
	v_cndmask_b32_e32 v1, s4, v4, vcc_lo                       // 0000003D6378: 02020804
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003D637C: BF870001
	v_add_co_ci_u32_e64 v32, null, s5, v5, vcc_lo              // 0000003D6380: D5207C20 01AA0A05
	global_store_b32 v[31:32], v30, off                        // 0000003D6388: DC6A0000 007C1E1F
	.long 0xd7006a1e                                           // 0000003D6390: D7006A1E
	v_cndmask_b32_e32 v1, 0x5000, v0, vcc_lo                   // 0000003D6394: 020200FF 00005000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003D639C: BF8700A1
	v_add_co_ci_u32_e64 v31, null, 0, v1, vcc_lo               // 0000003D63A0: D5207C1F 01AA0280
	.long 0xd7006a20                                           // 0000003D63A8: D7006A20
	v_cndmask_b32_e32 v1, 0x6000, v0, vcc_lo                   // 0000003D63AC: 020200FF 00006000
	v_add_co_ci_u32_e64 v33, null, 0, v1, vcc_lo               // 0000003D63B4: D5207C21 01AA0280
	s_clause 0x1                                               // 0000003D63BC: BF850001
	global_load_u16 v34, v[30:31], off                         // 0000003D63C0: DC4A0000 227C001E
	global_load_u16 v35, v[32:33], off offset:1024             // 0000003D63C8: DC4A0400 237C0020
	.long 0xd7006a1e                                           // 0000003D63D0: D7006A1E
	v_cndmask_b32_e32 v1, 0x7000, v0, vcc_lo                   // 0000003D63D4: 020200FF 00007000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003D63DC: BF8700A1
	v_add_co_ci_u32_e64 v31, null, 0, v1, vcc_lo               // 0000003D63E0: D5207C1F 01AA0280
	.long 0xd7006a20                                           // 0000003D63E8: D7006A20
	v_cndmask_b32_e32 v1, 0x8000, v0, vcc_lo                   // 0000003D63EC: 020200FF 00008000
	v_add_co_ci_u32_e64 v33, null, 0, v1, vcc_lo               // 0000003D63F4: D5207C21 01AA0280
	s_clause 0x1                                               // 0000003D63FC: BF850001
	global_load_u16 v30, v[30:31], off offset:2048             // 0000003D6400: DC4A0800 1E7C001E
	global_load_u16 v31, v[32:33], off offset:3072             // 0000003D6408: DC4A0C00 1F7C0020
	v_dual_add_f32 v22, v22, v26 :: v_dual_add_f32 v23, v23, v27// 0000003D6410: C9083516 16163717
	s_waitcnt lgkmcnt(2)                                       // 0000003D6418: BF89FC27
	v_dual_add_f32 v24, v24, v28 :: v_dual_add_f32 v25, v25, v29// 0000003D641C: C9083918 18183B19
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003D6424: BF870192
	v_bfe_u32 v26, v22, 16, 1                                  // 0000003D6428: D610001A 02052116
	v_bfe_u32 v27, v23, 16, 1                                  // 0000003D6430: D610001B 02052117
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003D6438: BF870213
	v_bfe_u32 v28, v24, 16, 1                                  // 0000003D643C: D610001C 02052118
	v_bfe_u32 v29, v25, 16, 1                                  // 0000003D6444: D610001D 02052119
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003D644C: BF870214
	v_add3_u32 v22, v22, v26, 0x7fff                           // 0000003D6450: D6550016 03FE3516 00007FFF
	v_add3_u32 v23, v23, v27, 0x7fff                           // 0000003D645C: D6550017 03FE3717 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003D6468: BF870214
	v_add3_u32 v24, v24, v28, 0x7fff                           // 0000003D646C: D6550018 03FE3918 00007FFF
	v_add3_u32 v25, v25, v29, 0x7fff                           // 0000003D6478: D6550019 03FE3B19 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003D6484: BF870113
	v_and_b32_e32 v23, 0xffff0000, v23                         // 0000003D6488: 362E2EFF FFFF0000
	v_and_b32_e32 v25, 0xffff0000, v25                         // 0000003D6490: 363232FF FFFF0000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003D6498: BF870112
	v_mul_f32_e32 v23, 0xbfb8aa3b, v23                         // 0000003D649C: 102E2EFF BFB8AA3B
	v_mul_f32_e32 v25, 0xbfb8aa3b, v25                         // 0000003D64A4: 103232FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000003D64AC: BF870122
	v_exp_f32_e32 v23, v23                                     // 0000003D64B0: 7E2E4B17
	v_and_b32_e32 v22, 0xffff0000, v22                         // 0000003D64B4: 362C2CFF FFFF0000
	v_exp_f32_e32 v25, v25                                     // 0000003D64BC: 7E324B19
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000003D64C0: BF870296
	v_dual_add_f32 v23, 1.0, v23 :: v_dual_and_b32 v24, 0xffff0000, v24// 0000003D64C4: C9242EF2 171830FF FFFF0000
	v_dual_mul_f32 v22, 0xbfb8aa3b, v22 :: v_dual_add_f32 v25, 1.0, v25// 0000003D64D0: C8C82CFF 161832F2 BFB8AA3B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003D64DC: BF870192
	v_mul_f32_e32 v24, 0xbfb8aa3b, v24                         // 0000003D64E0: 103030FF BFB8AA3B
	v_div_scale_f32 v27, null, v23, v23, 1.0                   // 0000003D64E8: D6FC7C1B 03CA2F17
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003D64F0: BF870193
	v_exp_f32_e32 v22, v22                                     // 0000003D64F4: 7E2C4B16
	v_div_scale_f32 v29, null, v25, v25, 1.0                   // 0000003D64F8: D6FC7C1D 03CA3319
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000003D6500: BF870133
	v_exp_f32_e32 v24, v24                                     // 0000003D6504: 7E304B18
	v_div_scale_f32 v39, s0, 1.0, v23, 1.0                     // 0000003D6508: D6FC0027 03CA2EF2
	v_rcp_f32_e32 v33, v27                                     // 0000003D6510: 7E42551B
	v_rcp_f32_e32 v37, v29                                     // 0000003D6514: 7E4A551D
	v_add_f32_e32 v22, 1.0, v22                                // 0000003D6518: 062C2CF2
	s_delay_alu instid0(TRANS32_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 0000003D651C: BF870317
	v_add_f32_e32 v24, 1.0, v24                                // 0000003D6520: 063030F2
	v_fma_f32 v41, -v27, v33, 1.0                              // 0000003D6524: D6130029 23CA431B
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000003D652C: BF870223
	v_div_scale_f32 v26, null, v22, v22, 1.0                   // 0000003D6530: D6FC7C1A 03CA2D16
	v_div_scale_f32 v38, vcc_lo, 1.0, v22, 1.0                 // 0000003D6538: D6FC6A26 03CA2CF2
	v_div_scale_f32 v28, null, v24, v24, 1.0                   // 0000003D6540: D6FC7C1C 03CA3118
	v_div_scale_f32 v43, s1, 1.0, v24, 1.0                     // 0000003D6548: D6FC012B 03CA30F2
	v_fmac_f32_e32 v33, v41, v33                               // 0000003D6550: 56424329
	v_rcp_f32_e32 v32, v26                                     // 0000003D6554: 7E40551A
	v_fma_f32 v44, -v29, v37, 1.0                              // 0000003D6558: D613002C 23CA4B1D
	v_rcp_f32_e32 v36, v28                                     // 0000003D6560: 7E48551C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 0000003D6564: BF870311
	v_fmac_f32_e32 v37, v44, v37                               // 0000003D6568: 564A4B2C
	v_fma_f32 v40, -v26, v32, 1.0                              // 0000003D656C: D6130028 23CA411A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003D6574: BF870115
	v_fma_f32 v42, -v28, v36, 1.0                              // 0000003D6578: D613002A 23CA491C
	v_fmac_f32_e32 v32, v40, v32                               // 0000003D6580: 56404128
	v_div_scale_f32 v40, s2, 1.0, v25, 1.0                     // 0000003D6584: D6FC0228 03CA32F2
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003D658C: BF870193
	v_fmac_f32_e32 v36, v42, v36                               // 0000003D6590: 5648492A
	v_dual_mul_f32 v42, v39, v33 :: v_dual_mul_f32 v41, v38, v32// 0000003D6594: C8C64327 2A284126
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003D659C: BF870112
	v_dual_mul_f32 v45, v40, v37 :: v_dual_mul_f32 v44, v43, v36// 0000003D65A0: C8C64B28 2D2C492B
	v_fma_f32 v47, -v27, v42, v39                              // 0000003D65A8: D613002F 249E551B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003D65B0: BF870193
	v_fma_f32 v46, -v26, v41, v38                              // 0000003D65B4: D613002E 249A531A
	v_fma_f32 v49, -v29, v45, v40                              // 0000003D65BC: D6130031 24A25B1D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003D65C4: BF870194
	v_fma_f32 v48, -v28, v44, v43                              // 0000003D65C8: D6130030 24AE591C
	v_dual_fmac_f32 v42, v47, v33 :: v_dual_fmac_f32 v41, v46, v32// 0000003D65D0: C800432F 2A28412E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003D65D8: BF870112
	v_dual_fmac_f32 v45, v49, v37 :: v_dual_fmac_f32 v44, v48, v36// 0000003D65DC: C8004B31 2D2C4930
	v_fma_f32 v27, -v27, v42, v39                              // 0000003D65E4: D613001B 249E551B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003D65EC: BF870193
	v_fma_f32 v26, -v26, v41, v38                              // 0000003D65F0: D613001A 249A531A
	v_fma_f32 v29, -v29, v45, v40                              // 0000003D65F8: D613001D 24A25B1D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003D6600: BF870194
	v_fma_f32 v28, -v28, v44, v43                              // 0000003D6604: D613001C 24AE591C
	v_div_fmas_f32 v26, v26, v32, v41                          // 0000003D660C: D637001A 04A6411A
	s_mov_b32 vcc_lo, s0                                       // 0000003D6614: BEEA0000
	v_div_fmas_f32 v27, v27, v33, v42                          // 0000003D6618: D637001B 04AA431B
	s_mov_b32 vcc_lo, s1                                       // 0000003D6620: BEEA0001
	s_delay_alu instid0(VALU_DEP_2)                            // 0000003D6624: BF870002
	v_div_fixup_f32 v22, v26, v22, 1.0                         // 0000003D6628: D6270016 03CA2D1A
	v_div_fmas_f32 v26, v28, v36, v44                          // 0000003D6630: D637001A 04B2491C
	s_mov_b32 vcc_lo, s2                                       // 0000003D6638: BEEA0002
	v_div_fixup_f32 v23, v27, v23, 1.0                         // 0000003D663C: D6270017 03CA2F1B
	v_div_fmas_f32 v28, v29, v37, v45                          // 0000003D6644: D637001C 04B64B1D
	v_bfe_u32 v27, v22, 16, 1                                  // 0000003D664C: D610001B 02052116
	v_div_fixup_f32 v24, v26, v24, 1.0                         // 0000003D6654: D6270018 03CA311A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003D665C: BF870214
	v_bfe_u32 v26, v23, 16, 1                                  // 0000003D6660: D610001A 02052117
	v_div_fixup_f32 v25, v28, v25, 1.0                         // 0000003D6668: D6270019 03CA331C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003D6670: BF870214
	v_add3_u32 v22, v22, v27, 0x7fff                           // 0000003D6674: D6550016 03FE3716 00007FFF
	v_bfe_u32 v27, v24, 16, 1                                  // 0000003D6680: D610001B 02052118
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003D6688: BF870214
	v_add3_u32 v23, v23, v26, 0x7fff                           // 0000003D668C: D6550017 03FE3517 00007FFF
	v_bfe_u32 v28, v25, 16, 1                                  // 0000003D6698: D610001C 02052119
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003D66A0: BF870214
	v_and_b32_e32 v22, 0xffff0000, v22                         // 0000003D66A4: 362C2CFF FFFF0000
	v_add3_u32 v24, v24, v27, 0x7fff                           // 0000003D66AC: D6550018 03FE3718 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003D66B8: BF870113
	v_add3_u32 v25, v25, v28, 0x7fff                           // 0000003D66BC: D6550019 03FE3919 00007FFF
	v_and_b32_e32 v24, 0xffff0000, v24                         // 0000003D66C8: 363030FF FFFF0000
	s_waitcnt vmcnt(3)                                         // 0000003D66D0: BF890FF7
	v_lshlrev_b32_e32 v26, 16, v34                             // 0000003D66D4: 30344490
	s_waitcnt vmcnt(2)                                         // 0000003D66D8: BF890BF7
	v_lshlrev_b32_e32 v27, 16, v35                             // 0000003D66DC: 30364690
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000003D66E0: BF8700C2
	v_fma_f32 v22, v22, v26, 0                                 // 0000003D66E4: D6130016 02023516
	s_waitcnt vmcnt(1)                                         // 0000003D66EC: BF8907F7
	v_lshlrev_b32_e32 v26, 16, v30                             // 0000003D66F0: 30343C90
	v_and_b32_e32 v23, 0xffff0000, v23                         // 0000003D66F4: 362E2EFF FFFF0000
	v_dual_fmac_f32 v22, v23, v27 :: v_dual_and_b32 v23, 0xffff0000, v25// 0000003D66FC: C8243717 161632FF FFFF0000
	s_waitcnt vmcnt(0)                                         // 0000003D6708: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003D670C: BF870091
	v_dual_fmac_f32 v22, v24, v26 :: v_dual_lshlrev_b32 v25, 16, v31// 0000003D6710: C8223518 16183E90
	v_fmac_f32_e32 v22, v23, v25                               // 0000003D6718: 562C3317
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000003D671C: BF870121
	v_mul_f32_e32 v23, 0x3e800000, v22                         // 0000003D6720: 102E2CFF 3E800000
	v_cndmask_b32_e64 v22, 0, 1, s3                            // 0000003D6728: D5010016 000D0280
	v_bfe_u32 v24, v23, 16, 1                                  // 0000003D6730: D6100018 02052117
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003D6738: BF8700A1
	v_add3_u32 v26, v23, v24, 0x7fff                           // 0000003D673C: D655001A 03FE3117 00007FFF
	.long 0xd7006a18                                           // 0000003D6748: D7006A18
	v_cndmask_b32_e32 v1, 0x1000, v2, vcc_lo                   // 0000003D674C: 020204FF 00001000
	v_add_co_ci_u32_e64 v25, null, 0, v3, vcc_lo               // 0000003D6754: D5207C19 01AA0680
	s_and_not1_b32 vcc_lo, exec_lo, s3                         // 0000003D675C: 916A037E
	global_store_d16_hi_b16 v[24:25], v26, off offset:1024     // 0000003D6760: DC960400 007C1A18
	s_cbranch_vccnz 13                                         // 0000003D6768: BFA4000D <_ZN7halogen12_GLOBAL__N_17k_hcup8ILi4EEEvPKhPKtS5_PtPf+0x2ba0>
	.long 0xd7006a18                                           // 0000003D676C: D7006A18
	v_cndmask_b32_e32 v1, s4, v4, vcc_lo                       // 0000003D6770: 02020804
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003D6774: BF870111
	v_add_co_ci_u32_e64 v25, null, s5, v5, vcc_lo              // 0000003D6778: D5207C19 01AA0A05
	.long 0xd7006a18                                           // 0000003D6780: D7006A18
	v_cndmask_b32_e32 v1, 0x2000, v24, vcc_lo                  // 0000003D6784: 020230FF 00002000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003D678C: BF870001
	v_add_co_ci_u32_e64 v25, null, 0, v25, vcc_lo              // 0000003D6790: D5207C19 01AA3280
	global_store_b32 v[24:25], v23, off offset:2048            // 0000003D6798: DC6A0800 007C1718
	.long 0xd7006a17                                           // 0000003D67A0: D7006A17
	v_cndmask_b32_e32 v1, 0xa000, v0, vcc_lo                   // 0000003D67A4: 020200FF 0000A000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003D67AC: BF8700A1
	v_add_co_ci_u32_e64 v24, null, 0, v1, vcc_lo               // 0000003D67B0: D5207C18 01AA0280
	.long 0xd7006a19                                           // 0000003D67B8: D7006A19
	v_cndmask_b32_e32 v1, 0xb000, v0, vcc_lo                   // 0000003D67BC: 020200FF 0000B000
	v_add_co_ci_u32_e64 v26, null, 0, v1, vcc_lo               // 0000003D67C4: D5207C1A 01AA0280
	s_clause 0x1                                               // 0000003D67CC: BF850001
	global_load_u16 v27, v[23:24], off                         // 0000003D67D0: DC4A0000 1B7C0017
	global_load_u16 v28, v[25:26], off offset:1024             // 0000003D67D8: DC4A0400 1C7C0019
	.long 0xd7006a17                                           // 0000003D67E0: D7006A17
	v_cndmask_b32_e32 v1, 0xc000, v0, vcc_lo                   // 0000003D67E4: 020200FF 0000C000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003D67EC: BF8700A1
	v_add_co_ci_u32_e64 v24, null, 0, v1, vcc_lo               // 0000003D67F0: D5207C18 01AA0280
	.long 0xd7006a19                                           // 0000003D67F8: D7006A19
	v_cndmask_b32_e32 v1, 0xd000, v0, vcc_lo                   // 0000003D67FC: 020200FF 0000D000
	v_add_co_ci_u32_e64 v26, null, 0, v1, vcc_lo               // 0000003D6804: D5207C1A 01AA0280
	s_clause 0x1                                               // 0000003D680C: BF850001
	global_load_u16 v23, v[23:24], off offset:2048             // 0000003D6810: DC4A0800 177C0017
	global_load_u16 v24, v[25:26], off offset:3072             // 0000003D6818: DC4A0C00 187C0019
	v_dual_add_f32 v14, v14, v18 :: v_dual_add_f32 v15, v15, v19// 0000003D6820: C908250E 0E0E270F
	s_waitcnt lgkmcnt(1)                                       // 0000003D6828: BF89FC17
	v_dual_add_f32 v16, v16, v20 :: v_dual_add_f32 v17, v17, v21// 0000003D682C: C9082910 10102B11
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003D6834: BF870192
	v_bfe_u32 v18, v14, 16, 1                                  // 0000003D6838: D6100012 0205210E
	v_bfe_u32 v19, v15, 16, 1                                  // 0000003D6840: D6100013 0205210F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003D6848: BF870213
	v_bfe_u32 v20, v16, 16, 1                                  // 0000003D684C: D6100014 02052110
	v_bfe_u32 v21, v17, 16, 1                                  // 0000003D6854: D6100015 02052111
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003D685C: BF870214
	v_add3_u32 v14, v14, v18, 0x7fff                           // 0000003D6860: D655000E 03FE250E 00007FFF
	v_add3_u32 v15, v15, v19, 0x7fff                           // 0000003D686C: D655000F 03FE270F 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003D6878: BF870214
	v_add3_u32 v16, v16, v20, 0x7fff                           // 0000003D687C: D6550010 03FE2910 00007FFF
	v_add3_u32 v17, v17, v21, 0x7fff                           // 0000003D6888: D6550011 03FE2B11 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003D6894: BF870113
	v_and_b32_e32 v15, 0xffff0000, v15                         // 0000003D6898: 361E1EFF FFFF0000
	v_and_b32_e32 v17, 0xffff0000, v17                         // 0000003D68A0: 362222FF FFFF0000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003D68A8: BF870112
	v_mul_f32_e32 v15, 0xbfb8aa3b, v15                         // 0000003D68AC: 101E1EFF BFB8AA3B
	v_mul_f32_e32 v17, 0xbfb8aa3b, v17                         // 0000003D68B4: 102222FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000003D68BC: BF870122
	v_exp_f32_e32 v15, v15                                     // 0000003D68C0: 7E1E4B0F
	v_and_b32_e32 v14, 0xffff0000, v14                         // 0000003D68C4: 361C1CFF FFFF0000
	v_exp_f32_e32 v17, v17                                     // 0000003D68CC: 7E224B11
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000003D68D0: BF870296
	v_dual_add_f32 v15, 1.0, v15 :: v_dual_and_b32 v16, 0xffff0000, v16// 0000003D68D4: C9241EF2 0F1020FF FFFF0000
	v_dual_mul_f32 v14, 0xbfb8aa3b, v14 :: v_dual_add_f32 v17, 1.0, v17// 0000003D68E0: C8C81CFF 0E1022F2 BFB8AA3B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003D68EC: BF870192
	v_mul_f32_e32 v16, 0xbfb8aa3b, v16                         // 0000003D68F0: 102020FF BFB8AA3B
	v_div_scale_f32 v19, null, v15, v15, 1.0                   // 0000003D68F8: D6FC7C13 03CA1F0F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003D6900: BF870193
	v_exp_f32_e32 v14, v14                                     // 0000003D6904: 7E1C4B0E
	v_div_scale_f32 v21, null, v17, v17, 1.0                   // 0000003D6908: D6FC7C15 03CA2311
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000003D6910: BF870133
	v_exp_f32_e32 v16, v16                                     // 0000003D6914: 7E204B10
	v_div_scale_f32 v32, s0, 1.0, v15, 1.0                     // 0000003D6918: D6FC0020 03CA1EF2
	v_rcp_f32_e32 v26, v19                                     // 0000003D6920: 7E345513
	v_rcp_f32_e32 v30, v21                                     // 0000003D6924: 7E3C5515
	v_add_f32_e32 v14, 1.0, v14                                // 0000003D6928: 061C1CF2
	s_delay_alu instid0(TRANS32_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 0000003D692C: BF870317
	v_add_f32_e32 v16, 1.0, v16                                // 0000003D6930: 062020F2
	v_fma_f32 v34, -v19, v26, 1.0                              // 0000003D6934: D6130022 23CA3513
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000003D693C: BF870223
	v_div_scale_f32 v18, null, v14, v14, 1.0                   // 0000003D6940: D6FC7C12 03CA1D0E
	v_div_scale_f32 v31, vcc_lo, 1.0, v14, 1.0                 // 0000003D6948: D6FC6A1F 03CA1CF2
	v_div_scale_f32 v20, null, v16, v16, 1.0                   // 0000003D6950: D6FC7C14 03CA2110
	v_div_scale_f32 v36, s1, 1.0, v16, 1.0                     // 0000003D6958: D6FC0124 03CA20F2
	v_fmac_f32_e32 v26, v34, v26                               // 0000003D6960: 56343522
	v_rcp_f32_e32 v25, v18                                     // 0000003D6964: 7E325512
	v_fma_f32 v37, -v21, v30, 1.0                              // 0000003D6968: D6130025 23CA3D15
	v_rcp_f32_e32 v29, v20                                     // 0000003D6970: 7E3A5514
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 0000003D6974: BF870311
	v_fmac_f32_e32 v30, v37, v30                               // 0000003D6978: 563C3D25
	v_fma_f32 v33, -v18, v25, 1.0                              // 0000003D697C: D6130021 23CA3312
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003D6984: BF870115
	v_fma_f32 v35, -v20, v29, 1.0                              // 0000003D6988: D6130023 23CA3B14
	v_fmac_f32_e32 v25, v33, v25                               // 0000003D6990: 56323321
	v_div_scale_f32 v33, s2, 1.0, v17, 1.0                     // 0000003D6994: D6FC0221 03CA22F2
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003D699C: BF870193
	v_fmac_f32_e32 v29, v35, v29                               // 0000003D69A0: 563A3B23
	v_dual_mul_f32 v35, v32, v26 :: v_dual_mul_f32 v34, v31, v25// 0000003D69A4: C8C63520 2322331F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003D69AC: BF870112
	v_dual_mul_f32 v38, v33, v30 :: v_dual_mul_f32 v37, v36, v29// 0000003D69B0: C8C63D21 26243B24
	v_fma_f32 v40, -v19, v35, v32                              // 0000003D69B8: D6130028 24824713
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003D69C0: BF870193
	v_fma_f32 v39, -v18, v34, v31                              // 0000003D69C4: D6130027 247E4512
	v_fma_f32 v42, -v21, v38, v33                              // 0000003D69CC: D613002A 24864D15
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003D69D4: BF870194
	v_fma_f32 v41, -v20, v37, v36                              // 0000003D69D8: D6130029 24924B14
	v_dual_fmac_f32 v35, v40, v26 :: v_dual_fmac_f32 v34, v39, v25// 0000003D69E0: C8003528 23223327
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003D69E8: BF870112
	v_dual_fmac_f32 v38, v42, v30 :: v_dual_fmac_f32 v37, v41, v29// 0000003D69EC: C8003D2A 26243B29
	v_fma_f32 v19, -v19, v35, v32                              // 0000003D69F4: D6130013 24824713
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003D69FC: BF870193
	v_fma_f32 v18, -v18, v34, v31                              // 0000003D6A00: D6130012 247E4512
	v_fma_f32 v21, -v21, v38, v33                              // 0000003D6A08: D6130015 24864D15
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003D6A10: BF870194
	v_fma_f32 v20, -v20, v37, v36                              // 0000003D6A14: D6130014 24924B14
	v_div_fmas_f32 v18, v18, v25, v34                          // 0000003D6A1C: D6370012 048A3312
	s_mov_b32 vcc_lo, s0                                       // 0000003D6A24: BEEA0000
	v_div_fmas_f32 v19, v19, v26, v35                          // 0000003D6A28: D6370013 048E3513
	s_mov_b32 vcc_lo, s1                                       // 0000003D6A30: BEEA0001
	s_delay_alu instid0(VALU_DEP_2)                            // 0000003D6A34: BF870002
	v_div_fixup_f32 v14, v18, v14, 1.0                         // 0000003D6A38: D627000E 03CA1D12
	v_div_fmas_f32 v18, v20, v29, v37                          // 0000003D6A40: D6370012 04963B14
	s_mov_b32 vcc_lo, s2                                       // 0000003D6A48: BEEA0002
	v_div_fixup_f32 v15, v19, v15, 1.0                         // 0000003D6A4C: D627000F 03CA1F13
	v_div_fmas_f32 v20, v21, v30, v38                          // 0000003D6A54: D6370014 049A3D15
	v_bfe_u32 v19, v14, 16, 1                                  // 0000003D6A5C: D6100013 0205210E
	v_div_fixup_f32 v16, v18, v16, 1.0                         // 0000003D6A64: D6270010 03CA2112
	v_cmp_ne_u32_e32 vcc_lo, 1, v22                            // 0000003D6A6C: 7C9A2C81
	v_bfe_u32 v18, v15, 16, 1                                  // 0000003D6A70: D6100012 0205210F
	v_div_fixup_f32 v17, v20, v17, 1.0                         // 0000003D6A78: D6270011 03CA2314
	v_add3_u32 v14, v14, v19, 0x7fff                           // 0000003D6A80: D655000E 03FE270E 00007FFF
	v_bfe_u32 v19, v16, 16, 1                                  // 0000003D6A8C: D6100013 02052110
	s_and_b32 vcc_lo, exec_lo, vcc_lo                          // 0000003D6A94: 8B6A6A7E
	v_add3_u32 v15, v15, v18, 0x7fff                           // 0000003D6A98: D655000F 03FE250F 00007FFF
	v_bfe_u32 v20, v17, 16, 1                                  // 0000003D6AA4: D6100014 02052111
	v_and_b32_e32 v14, 0xffff0000, v14                         // 0000003D6AAC: 361C1CFF FFFF0000
	v_add3_u32 v16, v16, v19, 0x7fff                           // 0000003D6AB4: D6550010 03FE2710 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003D6AC0: BF870113
	v_add3_u32 v17, v17, v20, 0x7fff                           // 0000003D6AC4: D6550011 03FE2911 00007FFF
	v_and_b32_e32 v16, 0xffff0000, v16                         // 0000003D6AD0: 362020FF FFFF0000
	s_waitcnt vmcnt(3)                                         // 0000003D6AD8: BF890FF7
	v_lshlrev_b32_e32 v18, 16, v27                             // 0000003D6ADC: 30243690
	s_waitcnt vmcnt(2)                                         // 0000003D6AE0: BF890BF7
	v_lshlrev_b32_e32 v19, 16, v28                             // 0000003D6AE4: 30263890
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000003D6AE8: BF8700C2
	v_fma_f32 v14, v14, v18, 0                                 // 0000003D6AEC: D613000E 0202250E
	s_waitcnt vmcnt(1)                                         // 0000003D6AF4: BF8907F7
	v_lshlrev_b32_e32 v18, 16, v23                             // 0000003D6AF8: 30242E90
	v_and_b32_e32 v15, 0xffff0000, v15                         // 0000003D6AFC: 361E1EFF FFFF0000
	v_dual_fmac_f32 v14, v15, v19 :: v_dual_and_b32 v15, 0xffff0000, v17// 0000003D6B04: C824270F 0E0E22FF FFFF0000
	s_waitcnt vmcnt(0)                                         // 0000003D6B10: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003D6B14: BF870091
	v_dual_fmac_f32 v14, v16, v18 :: v_dual_lshlrev_b32 v17, 16, v24// 0000003D6B18: C8222510 0E103090
	v_fmac_f32_e32 v14, v15, v17                               // 0000003D6B20: 561C230F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003D6B24: BF870091
	v_mul_f32_e32 v14, 0x3e800000, v14                         // 0000003D6B28: 101C1CFF 3E800000
	v_bfe_u32 v15, v14, 16, 1                                  // 0000003D6B30: D610000F 0205210E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003D6B38: BF8700A1
	v_add3_u32 v17, v14, v15, 0x7fff                           // 0000003D6B3C: D6550011 03FE1F0E 00007FFF
	.long 0xd700000f                                           // 0000003D6B48: D700000F
	v_cndmask_b32_e32 v1, 0x2000, v2, vcc_lo                   // 0000003D6B4C: 020204FF 00002000
	v_add_co_ci_u32_e64 v16, null, 0, v3, s0                   // 0000003D6B54: D5207C10 00020680
	global_store_d16_hi_b16 v[15:16], v17, off offset:2048     // 0000003D6B5C: DC960800 007C110F
	s_cbranch_vccnz 13                                         // 0000003D6B64: BFA4000D <_ZN7halogen12_GLOBAL__N_17k_hcup8ILi4EEEvPKhPKtS5_PtPf+0x2f9c>
	.long 0xd7006a0f                                           // 0000003D6B68: D7006A0F
	v_cndmask_b32_e32 v1, s4, v4, vcc_lo                       // 0000003D6B6C: 02020804
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003D6B70: BF870111
	v_add_co_ci_u32_e64 v16, null, s5, v5, vcc_lo              // 0000003D6B74: D5207C10 01AA0A05
	.long 0xd7006a0f                                           // 0000003D6B7C: D7006A0F
	v_cndmask_b32_e32 v1, 0x5000, v15, vcc_lo                  // 0000003D6B80: 02021EFF 00005000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003D6B88: BF870001
	v_add_co_ci_u32_e64 v16, null, 0, v16, vcc_lo              // 0000003D6B8C: D5207C10 01AA2080
	global_store_b32 v[15:16], v14, off                        // 0000003D6B94: DC6A0000 007C0E0F
	.long 0xd7006a0e                                           // 0000003D6B9C: D7006A0E
	v_cndmask_b32_e32 v1, 0xf000, v0, vcc_lo                   // 0000003D6BA0: 020200FF 0000F000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003D6BA8: BF8700A1
	v_add_co_ci_u32_e64 v15, null, 0, v1, vcc_lo               // 0000003D6BAC: D5207C0F 01AA0280
	.long 0xd7006a10                                           // 0000003D6BB4: D7006A10
	v_cndmask_b32_e32 v1, 0x10000, v0, vcc_lo                  // 0000003D6BB8: 020200FF 00010000
	v_add_co_ci_u32_e64 v17, null, 0, v1, vcc_lo               // 0000003D6BC0: D5207C11 01AA0280
	s_clause 0x1                                               // 0000003D6BC8: BF850001
	global_load_u16 v18, v[14:15], off                         // 0000003D6BCC: DC4A0000 127C000E
	global_load_u16 v16, v[16:17], off offset:1024             // 0000003D6BD4: DC4A0400 107C0010
	.long 0xd7006a0e                                           // 0000003D6BDC: D7006A0E
	v_cndmask_b32_e32 v1, 0x11000, v0, vcc_lo                  // 0000003D6BE0: 020200FF 00011000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003D6BE8: BF8700A1
	v_add_co_ci_u32_e64 v15, null, 0, v1, vcc_lo               // 0000003D6BEC: D5207C0F 01AA0280
	.long 0xd7006a00                                           // 0000003D6BF4: D7006A00
	v_cndmask_b32_e32 v1, 0x12000, v0, vcc_lo                  // 0000003D6BF8: 020200FF 00012000
	v_add_co_ci_u32_e64 v1, null, 0, v1, vcc_lo                // 0000003D6C00: D5207C01 01AA0280
	s_clause 0x1                                               // 0000003D6C08: BF850001
	global_load_u16 v14, v[14:15], off offset:2048             // 0000003D6C0C: DC4A0800 0E7C000E
	global_load_u16 v0, v[0:1], off offset:3072                // 0000003D6C14: DC4A0C00 007C0000
	v_dual_add_f32 v1, v6, v10 :: v_dual_add_f32 v6, v7, v11   // 0000003D6C1C: C9081506 01061707
	s_waitcnt lgkmcnt(0)                                       // 0000003D6C24: BF89FC07
	v_dual_add_f32 v7, v8, v12 :: v_dual_add_f32 v8, v9, v13   // 0000003D6C28: C9081908 07081B09
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003D6C30: BF870192
	v_bfe_u32 v9, v1, 16, 1                                    // 0000003D6C34: D6100009 02052101
	v_bfe_u32 v10, v6, 16, 1                                   // 0000003D6C3C: D610000A 02052106
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003D6C44: BF870213
	v_bfe_u32 v11, v7, 16, 1                                   // 0000003D6C48: D610000B 02052107
	v_bfe_u32 v12, v8, 16, 1                                   // 0000003D6C50: D610000C 02052108
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003D6C58: BF870214
	v_add3_u32 v1, v1, v9, 0x7fff                              // 0000003D6C5C: D6550001 03FE1301 00007FFF
	v_add3_u32 v6, v6, v10, 0x7fff                             // 0000003D6C68: D6550006 03FE1506 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003D6C74: BF870214
	v_add3_u32 v7, v7, v11, 0x7fff                             // 0000003D6C78: D6550007 03FE1707 00007FFF
	v_add3_u32 v8, v8, v12, 0x7fff                             // 0000003D6C84: D6550008 03FE1908 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003D6C90: BF870113
	v_and_b32_e32 v6, 0xffff0000, v6                           // 0000003D6C94: 360C0CFF FFFF0000
	v_and_b32_e32 v8, 0xffff0000, v8                           // 0000003D6C9C: 361010FF FFFF0000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003D6CA4: BF870112
	v_mul_f32_e32 v6, 0xbfb8aa3b, v6                           // 0000003D6CA8: 100C0CFF BFB8AA3B
	v_mul_f32_e32 v8, 0xbfb8aa3b, v8                           // 0000003D6CB0: 101010FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000003D6CB8: BF870122
	v_exp_f32_e32 v6, v6                                       // 0000003D6CBC: 7E0C4B06
	v_and_b32_e32 v1, 0xffff0000, v1                           // 0000003D6CC0: 360202FF FFFF0000
	v_exp_f32_e32 v8, v8                                       // 0000003D6CC8: 7E104B08
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000003D6CCC: BF870296
	v_dual_add_f32 v6, 1.0, v6 :: v_dual_and_b32 v7, 0xffff0000, v7// 0000003D6CD0: C9240CF2 06060EFF FFFF0000
	v_dual_mul_f32 v1, 0xbfb8aa3b, v1 :: v_dual_add_f32 v8, 1.0, v8// 0000003D6CDC: C8C802FF 010810F2 BFB8AA3B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003D6CE8: BF870192
	v_mul_f32_e32 v7, 0xbfb8aa3b, v7                           // 0000003D6CEC: 100E0EFF BFB8AA3B
	v_div_scale_f32 v10, null, v6, v6, 1.0                     // 0000003D6CF4: D6FC7C0A 03CA0D06
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000003D6CFC: BF8701A3
	v_exp_f32_e32 v1, v1                                       // 0000003D6D00: 7E024B01
	v_div_scale_f32 v21, s0, 1.0, v6, 1.0                      // 0000003D6D04: D6FC0015 03CA0CF2
	v_exp_f32_e32 v7, v7                                       // 0000003D6D0C: 7E0E4B07
	v_div_scale_f32 v12, null, v8, v8, 1.0                     // 0000003D6D10: D6FC7C0C 03CA1108
	v_rcp_f32_e32 v15, v10                                     // 0000003D6D18: 7E1E550A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(TRANS32_DEP_3)// 0000003D6D1C: BF8703A1
	v_rcp_f32_e32 v19, v12                                     // 0000003D6D20: 7E26550C
	v_add_f32_e32 v1, 1.0, v1                                  // 0000003D6D24: 060202F2
	v_add_f32_e32 v7, 1.0, v7                                  // 0000003D6D28: 060E0EF2
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003D6D2C: BF870196
	v_fma_f32 v24, -v10, v15, 1.0                              // 0000003D6D30: D6130018 23CA1F0A
	v_div_scale_f32 v9, null, v1, v1, 1.0                      // 0000003D6D38: D6FC7C09 03CA0301
	v_div_scale_f32 v20, vcc_lo, 1.0, v1, 1.0                  // 0000003D6D40: D6FC6A14 03CA02F2
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000003D6D48: BF870294
	v_div_scale_f32 v11, null, v7, v7, 1.0                     // 0000003D6D4C: D6FC7C0B 03CA0F07
	v_fma_f32 v27, -v12, v19, 1.0                              // 0000003D6D54: D613001B 23CA270C
	v_div_scale_f32 v26, s1, 1.0, v7, 1.0                      // 0000003D6D5C: D6FC011A 03CA0EF2
	v_rcp_f32_e32 v13, v9                                      // 0000003D6D64: 7E1A5509
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003D6D68: BF870113
	v_rcp_f32_e32 v17, v11                                     // 0000003D6D6C: 7E22550B
	v_fmac_f32_e32 v19, v27, v19                               // 0000003D6D70: 5626271B
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000003D6D74: BF870296
	v_fma_f32 v23, -v9, v13, 1.0                               // 0000003D6D78: D6130017 23CA1B09
	v_fma_f32 v25, -v11, v17, 1.0                              // 0000003D6D80: D6130019 23CA230B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003D6D88: BF8700A2
	v_fmac_f32_e32 v13, v23, v13                               // 0000003D6D8C: 561A1B17
	v_div_scale_f32 v23, s2, 1.0, v8, 1.0                      // 0000003D6D90: D6FC0217 03CA10F2
	v_dual_fmac_f32 v17, v25, v17 :: v_dual_mul_f32 v28, v23, v19// 0000003D6D98: C8062319 111C2717
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003D6DA0: BF870111
	v_mul_f32_e32 v27, v26, v17                                // 0000003D6DA4: 1036231A
	v_fma_f32 v32, -v12, v28, v23                              // 0000003D6DA8: D6130020 245E390C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003D6DB0: BF870112
	v_fma_f32 v31, -v11, v27, v26                              // 0000003D6DB4: D613001F 246A370B
	v_fmac_f32_e32 v28, v32, v19                               // 0000003D6DBC: 56382720
	v_fmac_f32_e32 v15, v24, v15                               // 0000003D6DC0: 561E1F18
	v_mul_f32_e32 v24, v20, v13                                // 0000003D6DC4: 10301B14
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003D6DC8: BF870214
	v_fmac_f32_e32 v27, v31, v17                               // 0000003D6DCC: 5636231F
	v_fma_f32 v12, -v12, v28, v23                              // 0000003D6DD0: D613000C 245E390C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003D6DD8: BF870093
	v_fma_f32 v29, -v9, v24, v20                               // 0000003D6DDC: D613001D 24523109
	v_fmac_f32_e32 v24, v29, v13                               // 0000003D6DE4: 56301B1D
	v_mul_f32_e32 v25, v21, v15                                // 0000003D6DE8: 10321F15
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003D6DEC: BF870112
	v_fma_f32 v9, -v9, v24, v20                                // 0000003D6DF0: D6130009 24523109
	v_fma_f32 v30, -v10, v25, v21                              // 0000003D6DF8: D613001E 2456330A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003D6E00: BF870112
	v_div_fmas_f32 v9, v9, v13, v24                            // 0000003D6E04: D6370009 04621B09
	v_fmac_f32_e32 v25, v30, v15                               // 0000003D6E0C: 56321F1E
	s_mov_b32 vcc_lo, s0                                       // 0000003D6E10: BEEA0000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003D6E14: BF870112
	v_div_fixup_f32 v1, v9, v1, 1.0                            // 0000003D6E18: D6270001 03CA0309
	v_fma_f32 v10, -v10, v25, v21                              // 0000003D6E20: D613000A 2456330A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003D6E28: BF8700A1
	v_div_fmas_f32 v10, v10, v15, v25                          // 0000003D6E2C: D637000A 04661F0A
	s_mov_b32 vcc_lo, s1                                       // 0000003D6E34: BEEA0001
	v_div_fixup_f32 v6, v10, v6, 1.0                           // 0000003D6E38: D6270006 03CA0D0A
	v_bfe_u32 v10, v1, 16, 1                                   // 0000003D6E40: D610000A 02052101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003D6E48: BF870091
	v_add3_u32 v1, v1, v10, 0x7fff                             // 0000003D6E4C: D6550001 03FE1501 00007FFF
	v_and_b32_e32 v1, 0xffff0000, v1                           // 0000003D6E58: 360202FF FFFF0000
	s_waitcnt vmcnt(0)                                         // 0000003D6E60: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 0000003D6E64: 30000090
	v_fma_f32 v11, -v11, v27, v26                              // 0000003D6E68: D613000B 246A370B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000003D6E70: BF8701C1
	v_div_fmas_f32 v9, v11, v17, v27                           // 0000003D6E74: D6370009 046E230B
	s_mov_b32 vcc_lo, s2                                       // 0000003D6E7C: BEEA0002
	v_div_fmas_f32 v11, v12, v19, v28                          // 0000003D6E80: D637000B 0472270C
	v_cmp_ne_u32_e32 vcc_lo, 1, v22                            // 0000003D6E88: 7C9A2C81
	v_div_fixup_f32 v7, v9, v7, 1.0                            // 0000003D6E8C: D6270007 03CA0F09
	v_bfe_u32 v9, v6, 16, 1                                    // 0000003D6E94: D6100009 02052106
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000003D6E9C: BF8701A4
	v_div_fixup_f32 v8, v11, v8, 1.0                           // 0000003D6EA0: D6270008 03CA110B
	s_and_b32 vcc_lo, exec_lo, vcc_lo                          // 0000003D6EA8: 8B6A6A7E
	v_bfe_u32 v10, v7, 16, 1                                   // 0000003D6EAC: D610000A 02052107
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000003D6EB4: BF870233
	v_add3_u32 v6, v6, v9, 0x7fff                              // 0000003D6EB8: D6550006 03FE1306 00007FFF
	v_lshlrev_b32_e32 v9, 16, v18                              // 0000003D6EC4: 30122490
	v_bfe_u32 v11, v8, 16, 1                                   // 0000003D6EC8: D610000B 02052108
	v_add3_u32 v7, v7, v10, 0x7fff                             // 0000003D6ED0: D6550007 03FE1507 00007FFF
	s_delay_alu instid0(VALU_DEP_4)                            // 0000003D6EDC: BF870004
	v_and_b32_e32 v6, 0xffff0000, v6                           // 0000003D6EE0: 360C0CFF FFFF0000
	v_lshlrev_b32_e32 v10, 16, v16                             // 0000003D6EE8: 30142090
	v_fma_f32 v1, v1, v9, 0                                    // 0000003D6EEC: D6130001 02021301
	v_add3_u32 v8, v8, v11, 0x7fff                             // 0000003D6EF4: D6550008 03FE1708 00007FFF
	v_and_b32_e32 v7, 0xffff0000, v7                           // 0000003D6F00: 360E0EFF FFFF0000
	v_lshlrev_b32_e32 v9, 16, v14                              // 0000003D6F08: 30121C90
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003D6F0C: BF870093
	v_dual_fmac_f32 v1, v6, v10 :: v_dual_and_b32 v6, 0xffff0000, v8// 0000003D6F10: C8241506 010610FF FFFF0000
	v_fmac_f32_e32 v1, v7, v9                                  // 0000003D6F1C: 56021307
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003D6F20: BF870091
	v_fmac_f32_e32 v1, v6, v0                                  // 0000003D6F24: 56020106
	v_mul_f32_e32 v0, 0x3e800000, v1                           // 0000003D6F28: 100002FF 3E800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003D6F30: BF870091
	v_bfe_u32 v1, v0, 16, 1                                    // 0000003D6F34: D6100001 02052100
	v_add3_u32 v6, v0, v1, 0x7fff                              // 0000003D6F3C: D6550006 03FE0300 00007FFF
	.long 0xd7000001                                           // 0000003D6F48: D7000001
	v_cndmask_b32_e32 v1, 0x3000, v2, vcc_lo                   // 0000003D6F4C: 020204FF 00003000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003D6F54: BF870001
	v_add_co_ci_u32_e64 v2, null, 0, v3, s0                    // 0000003D6F58: D5207C02 00020680
	global_store_d16_hi_b16 v[1:2], v6, off offset:3072        // 0000003D6F60: DC960C00 007C0601
	s_cbranch_vccnz 13                                         // 0000003D6F68: BFA4000D <_ZN7halogen12_GLOBAL__N_17k_hcup8ILi4EEEvPKhPKtS5_PtPf+0x33a0>
	.long 0xd7006a01                                           // 0000003D6F6C: D7006A01
	v_cndmask_b32_e32 v1, s4, v4, vcc_lo                       // 0000003D6F70: 02020804
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003D6F74: BF870111
	v_add_co_ci_u32_e64 v2, null, s5, v5, vcc_lo               // 0000003D6F78: D5207C02 01AA0A05
	.long 0xd7006a01                                           // 0000003D6F80: D7006A01
	v_cndmask_b32_e32 v1, 0x7000, v1, vcc_lo                   // 0000003D6F84: 020202FF 00007000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003D6F8C: BF870001
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 0000003D6F90: D5207C02 01AA0480
	global_store_b32 v[1:2], v0, off offset:2048               // 0000003D6F98: DC6A0800 007C0001
	s_nop 0                                                    // 0000003D6FA0: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 0000003D6FA4: BFB60003
	s_endpgm                                                   // 0000003D6FA8: BFB00000
		...

