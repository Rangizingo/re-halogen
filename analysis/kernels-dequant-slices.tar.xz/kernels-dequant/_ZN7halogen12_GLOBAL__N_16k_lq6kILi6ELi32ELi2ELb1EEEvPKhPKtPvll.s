0000000000719200 <_ZN7halogen12_GLOBAL__N_16k_lq6kILi6ELi32ELi2ELb1EEEvPKhPKtPvll>:
; _ZN7halogen12_GLOBAL__N_16k_lq6kILi6ELi32ELi2ELb1EEEvPKhPKtPvll():
	s_load_b256 s[4:11], s[0:1], null                          // 000000719200: F40C0100 F8000000
	s_mov_b32 s3, 0                                            // 000000719208: BE830080
	v_bfe_u32 v5, v0, 5, 1                                     // 00000071920C: D6100005 02050B00
	s_lshl_b64 s[14:15], s[2:3], 2                             // 000000719214: 848E8202
	v_dual_mov_b32 v12, 0 :: v_dual_and_b32 v7, 31, v0         // 000000719218: CA240080 0C06009F
	v_dual_mov_b32 v13, 0 :: v_dual_mov_b32 v8, 0              // 000000719220: CA100080 0D080080
	v_mov_b32_e32 v15, 0                                       // 000000719228: 7E1E0280
	v_lshrrev_b32_e32 v6, 6, v0                                // 00000071922C: 320C0086
	v_dual_mov_b32 v11, 0 :: v_dual_mov_b32 v14, 0             // 000000719230: CA100080 0B0E0080
	s_waitcnt lgkmcnt(0)                                       // 000000719238: BF89FC07
	s_ashr_i32 s12, s11, 31                                    // 00000071923C: 860C9F0B
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000719240: BF870499
	s_lshr_b32 s12, s12, 28                                    // 000000719244: 850C9C0C
	s_add_u32 s12, s10, s12                                    // 000000719248: 800C0C0A
	s_addc_u32 s13, s11, 0                                     // 00000071924C: 820D800B
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000719250: BF870499
	s_lshr_b64 s[16:17], s[12:13], 4                           // 000000719254: 8590840C
	s_add_i32 s2, s16, 1                                       // 000000719258: 81028110
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000071925C: BF870499
	s_lshr_b32 s12, s2, 31                                     // 000000719260: 850C9F02
	s_add_i32 s2, s2, s12                                      // 000000719264: 81020C02
	s_load_b64 s[12:13], s[0:1], 0x20                          // 000000719268: F4040300 F8000020
	s_ashr_i32 s2, s2, 1                                       // 000000719270: 86028102
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000719274: BF870099
	.long 0xd72c0001                                           // 000000719278: D72C0001
	v_cndmask_b32_e32 v1, s2, v5, vcc_lo                       // 00000071927C: 02020A02
	v_add_nc_u32_e32 v2, s2, v1                                // 000000719280: 4A040202
	v_add_nc_u32_e32 v9, v1, v7                                // 000000719284: 4A120F01
	s_mov_b32 s2, exec_lo                                      // 000000719288: BE82007E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000071928C: BF870092
	v_min_i32_e32 v10, s16, v2                                 // 000000719290: 22140410
	.long 0xd4c1007e                                           // 000000719294: D4C1007E
	v_cndmask_b32_e32 v1, v9, v10, vcc_lo                      // 000000719298: 02021509
	s_cbranch_execz 603                                        // 00000071929C: BFA5025B <_ZN7halogen12_GLOBAL__N_16k_lq6kILi6ELi32ELi2ELb1EEEvPKhPKtPvll+0xa0c>
	.long 0xd7000001                                           // 0000007192A0: D7000001
	v_cndmask_b32_e32 v1, s14, v6, vcc_lo                      // 0000007192A4: 02020C0E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007192A8: BF870001
	v_add_co_ci_u32_e64 v2, null, s15, 0, s0                   // 0000007192AC: D5207C02 0001000F
	s_ashr_i32 s0, s11, 31                                     // 0000007192B4: 86009F0B
	v_dual_mov_b32 v8, 0 :: v_dual_lshlrev_b32 v3, 4, v9       // 0000007192B8: CA220080 08021284
	s_lshr_b32 s0, s0, 24                                      // 0000007192C0: 85009800
	s_waitcnt lgkmcnt(0)                                       // 0000007192C4: BF89FC07
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[1:2]                  // 0000007192C8: 7CA8020C
	s_add_u32 s0, s10, s0                                      // 0000007192CC: 8000000A
	s_addc_u32 s1, s11, 0                                      // 0000007192D0: 8201800B
	v_dual_mov_b32 v15, 0 :: v_dual_mov_b32 v14, 0             // 0000007192D4: CA100080 0F0E0080
	s_ashr_i64 s[0:1], s[0:1], 8                               // 0000007192DC: 86808800
	v_dual_cndmask_b32 v2, 0, v2 :: v_dual_cndmask_b32 v1, 0, v1// 0000007192E0: CA520480 02000280
	s_mulk_i32 s1, 0xd2                                        // 0000007192E8: B80100D2
	s_mul_hi_u32 s16, s0, 0xd2                                 // 0000007192EC: 9690FF00 000000D2
	s_mulk_i32 s0, 0xd2                                        // 0000007192F4: B80000D2
	s_add_i32 s16, s16, s1                                     // 0000007192F8: 81100110
	.long 0xd72c000b                                           // 0000007192FC: D72C000B
	v_cndmask_b32_e32 v1, s0, v2, vcc_lo                       // 000000719300: 02020400
	.long 0xd72c0004                                           // 000000719304: D72C0004
	v_cndmask_b32_e32 v1, s16, v1, vcc_lo                      // 000000719308: 02020210
	v_mad_u64_u32 v[1:2], null, s0, v1, s[4:5]                 // 00000071930C: D6FE7C01 00120200
	v_dual_mov_b32 v13, 0 :: v_dual_mov_b32 v12, 0             // 000000719314: CA100080 0D0C0080
	s_mul_i32 s4, s11, 6                                       // 00000071931C: 9604860B
	s_mul_hi_u32 s5, s10, 6                                    // 000000719320: 9685860A
	s_lshl_b64 s[0:1], s[10:11], 2                             // 000000719324: 8480820A
	s_add_i32 s16, s5, s4                                      // 000000719328: 81100405
	s_mul_i32 s17, s10, 6                                      // 00000071932C: 9611860A
	s_delay_alu instid0(VALU_DEP_2)                            // 000000719330: BF870002
	v_add3_u32 v2, v4, v2, v11                                 // 000000719334: D6550002 042E0504
	v_mov_b32_e32 v11, 0                                       // 00000071933C: 7E160280
	s_lshl_b64 s[4:5], s[10:11], 1                             // 000000719340: 8484810A
	v_ashrrev_i32_e32 v4, 4, v9                                // 000000719344: 34081284
	v_bfe_u32 v21, v9, 3, 1                                    // 000000719348: D6100015 02050709
	v_and_b32_e32 v17, 32, v3                                  // 000000719350: 362206A0
	v_and_b32_e32 v22, 16, v3                                  // 000000719354: 362C0690
	v_and_b32_e32 v27, 15, v9                                  // 000000719358: 3636128F
	.long 0xd72c0004                                           // 00000071935C: D72C0004
	v_cndmask_b32_e32 v1, 0xd2, v4, vcc_lo                     // 000000719360: 020208FF 000000D2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000719368: BF8701B1
	v_ashrrev_i32_e32 v16, 31, v4                              // 00000071936C: 3420089F
	.long 0xd7006a19                                           // 000000719370: D7006A19
	v_cndmask_b32_e32 v1, v1, v4, vcc_lo                       // 000000719374: 02020901
	v_lshlrev_b32_e32 v4, 6, v21                               // 000000719378: 30082A86
	v_add_co_ci_u32_e64 v26, null, v2, v16, vcc_lo             // 00000071937C: D5207C1A 01AA2102
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000719384: BF870092
	.long 0xd7006a04                                           // 000000719388: D7006A04
	v_cndmask_b32_e32 v1, v25, v4, vcc_lo                      // 00000071938C: 02020919
	v_add_co_ci_u32_e64 v16, null, 0, v26, vcc_lo              // 000000719390: D5207C10 01AA3480
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000719398: BF870092
	.long 0xd7006a04                                           // 00000071939C: D7006A04
	v_cndmask_b32_e32 v1, v4, v17, vcc_lo                      // 0000007193A0: 02022304
	v_add_co_ci_u32_e64 v17, null, 0, v16, vcc_lo              // 0000007193A4: D5207C11 01AA2080
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007193AC: BF8701A2
	.long 0xd7006a10                                           // 0000007193B0: D7006A10
	v_cndmask_b32_e32 v1, v4, v22, vcc_lo                      // 0000007193B4: 02022D04
	v_lshlrev_b32_e32 v4, 5, v21                               // 0000007193B8: 30082A85
	v_add_co_ci_u32_e64 v17, null, 0, v17, vcc_lo              // 0000007193BC: D5207C11 01AA2280
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000007193C4: BF8700C2
	.long 0xd7006a04                                           // 0000007193C8: D7006A04
	v_cndmask_b32_e32 v1, v25, v4, vcc_lo                      // 0000007193CC: 02020919
	global_load_b128 v[17:20], v[16:17], off                   // 0000007193D0: DC5E0000 117C0010
	v_add_co_ci_u32_e64 v16, null, 0, v26, vcc_lo              // 0000007193D8: D5207C10 01AA3480
	.long 0xd7006a15                                           // 0000007193E0: D7006A15
	v_cndmask_b32_e32 v1, v4, v22, vcc_lo                      // 0000007193E4: 02022D04
	v_add_co_ci_u32_e64 v22, null, 0, v16, vcc_lo              // 0000007193E8: D5207C16 01AA2080
	.long 0xd7006a1b                                           // 0000007193F0: D7006A1B
	v_cndmask_b32_e32 v1, v25, v27, vcc_lo                     // 0000007193F4: 02023719
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007193F8: BF870001
	v_add_co_ci_u32_e64 v28, null, 0, v26, vcc_lo              // 0000007193FC: D5207C1C 01AA3480
	s_clause 0x2                                               // 000000719404: BF850002
	global_load_b128 v[21:24], v[21:22], off offset:128        // 000000719408: DC5E0080 157C0015
	global_load_d16_b16 v16, v[25:26], off offset:208          // 000000719410: DC8200D0 107C0019
	global_load_i8 v4, v[27:28], off offset:192                // 000000719418: DC4600C0 047C001B
	s_waitcnt vmcnt(0)                                         // 000000719420: BF8903F7
	v_cvt_f32_i32_e32 v4, v4                                   // 000000719424: 7E080B04
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000719428: BF8701C1
	v_fma_mix_f32 v4, v16, v4, neg(0) op_sel_hi:[1,0,0]        // 00000071942C: CC200004 8A020910
	v_and_b32_e32 v26, 6, v9                                   // 000000719434: 36341286
	v_and_b32_e32 v25, 4, v9                                   // 000000719438: 36321284
	v_add_nc_u32_e32 v9, 32, v9                                // 00000071943C: 4A1212A0
	v_lshrrev_b32_e32 v27, v26, v21                            // 000000719440: 32362B1A
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 000000719444: BF870253
	v_bfe_u32 v16, v17, v25, 4                                 // 000000719448: D6100010 02123311
	v_or_b32_e32 v29, 8, v26                                   // 000000719450: 383A3488
	v_or_b32_e32 v28, 8, v25                                   // 000000719454: 38383288
	v_or_b32_e32 v32, 16, v26                                  // 000000719458: 38403490
	v_lshlrev_b32_e32 v27, 4, v27                              // 00000071945C: 30363684
	v_lshrrev_b32_e32 v30, v29, v21                            // 000000719460: 323C2B1D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000719464: BF870193
	v_lshrrev_b32_e32 v33, v32, v21                            // 000000719468: 32422B20
	v_and_or_b32 v16, v27, 48, v16                             // 00000071946C: D6570010 0441611B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000719474: BF870193
	v_lshlrev_b32_e32 v30, 4, v30                              // 000000719478: 303C3C84
	v_lshlrev_b32_e32 v33, 4, v33                              // 00000071947C: 30424284
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000719480: BF870093
	v_subrev_nc_u32_e32 v16, 32, v16                           // 000000719484: 4E2020A0
	v_cvt_f32_i32_e32 v16, v16                                 // 000000719488: 7E200B10
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000071948C: BF870091
	v_mul_f32_e32 v16, v4, v16                                 // 000000719490: 10202104
	v_bfe_u32 v27, v16, 16, 1                                  // 000000719494: D610001B 02052110
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000071949C: BF8700A1
	v_add3_u32 v27, v16, v27, 0x7fff                           // 0000007194A0: D655001B 03FE3710 00007FFF
	v_bfe_u32 v16, v17, v28, 4                                 // 0000007194AC: D6100010 02123911
	v_and_or_b32 v16, v30, 48, v16                             // 0000007194B4: D6570010 0441611E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007194BC: BF870091
	v_subrev_nc_u32_e32 v16, 32, v16                           // 0000007194C0: 4E2020A0
	v_cvt_f32_i32_e32 v16, v16                                 // 0000007194C4: 7E200B10
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007194C8: BF870091
	v_mul_f32_e32 v16, v4, v16                                 // 0000007194CC: 10202104
	v_bfe_u32 v30, v16, 16, 1                                  // 0000007194D0: D610001E 02052110
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000007194D8: BF8701C1
	v_add3_u32 v16, v16, v30, 0x7fff                           // 0000007194DC: D6550010 03FE3D10 00007FFF
	v_or_b32_e32 v30, 16, v25                                  // 0000007194E8: 383C3290
	.long 0x7e20399b                                           // 0000007194EC: 7E20399B
	v_lshrrev_b32_e32 v27, v29, v22                            // 0000007194F0: 32362D1D
	v_bfe_u32 v31, v17, v30, 4                                 // 0000007194F4: D610001F 02123D11
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007194FC: BF870112
	v_lshlrev_b32_e32 v27, 4, v27                              // 000000719500: 30363684
	v_and_or_b32 v31, v33, 48, v31                             // 000000719504: D657001F 047D6121
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000071950C: BF870091
	v_subrev_nc_u32_e32 v31, 32, v31                           // 000000719510: 4E3E3EA0
	v_cvt_f32_i32_e32 v31, v31                                 // 000000719514: 7E3E0B1F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000719518: BF870121
	v_mul_f32_e32 v31, v4, v31                                 // 00000071951C: 103E3F04
	v_or_b32_e32 v34, 24, v26                                  // 000000719520: 38443498
	v_bfe_u32 v33, v31, 16, 1                                  // 000000719524: D6100021 0205211F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000071952C: BF870112
	v_lshrrev_b32_e32 v21, v34, v21                            // 000000719530: 322A2B22
	v_add3_u32 v31, v31, v33, 0x7fff                           // 000000719534: D655001F 03FE431F 00007FFF
	v_or_b32_e32 v33, 24, v25                                  // 000000719540: 38423298
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000719544: BF870113
	v_lshlrev_b32_e32 v21, 4, v21                              // 000000719548: 302A2A84
	v_bfe_u32 v17, v17, v33, 4                                 // 00000071954C: D6100011 02124311
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000719554: BF870091
	v_and_or_b32 v17, v21, 48, v17                             // 000000719558: D6570011 04456115
	v_subrev_nc_u32_e32 v17, 32, v17                           // 000000719560: 4E2222A0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000719564: BF870091
	v_cvt_f32_i32_e32 v17, v17                                 // 000000719568: 7E220B11
	v_mul_f32_e32 v17, v4, v17                                 // 00000071956C: 10222304
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000719570: BF870091
	v_bfe_u32 v21, v17, 16, 1                                  // 000000719574: D6100015 02052111
	v_add3_u32 v35, v17, v21, 0x7fff                           // 00000071957C: D6550023 03FE2B11 00007FFF
	v_lshrrev_b32_e32 v21, v26, v22                            // 000000719588: 322A2D1A
	v_bfe_u32 v17, v18, v25, 4                                 // 00000071958C: D6100011 02123312
	.long 0x7e46399f                                           // 000000719594: 7E46399F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000719598: BF870093
	v_lshlrev_b32_e32 v21, 4, v21                              // 00000071959C: 302A2A84
	v_and_or_b32 v17, v21, 48, v17                             // 0000007195A0: D6570011 04456115
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007195A8: BF870091
	v_subrev_nc_u32_e32 v17, 32, v17                           // 0000007195AC: 4E2222A0
	v_cvt_f32_i32_e32 v17, v17                                 // 0000007195B0: 7E220B11
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007195B4: BF870091
	v_mul_f32_e32 v17, v4, v17                                 // 0000007195B8: 10222304
	v_bfe_u32 v21, v17, 16, 1                                  // 0000007195BC: D6100015 02052111
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007195C4: BF8700A1
	v_add3_u32 v17, v17, v21, 0x7fff                           // 0000007195C8: D6550011 03FE2B11 00007FFF
	v_bfe_u32 v21, v18, v28, 4                                 // 0000007195D4: D6100015 02123912
	v_and_or_b32 v21, v27, 48, v21                             // 0000007195DC: D6570015 0455611B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007195E4: BF870091
	v_subrev_nc_u32_e32 v21, 32, v21                           // 0000007195E8: 4E2A2AA0
	v_cvt_f32_i32_e32 v21, v21                                 // 0000007195EC: 7E2A0B15
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007195F0: BF870091
	v_mul_f32_e32 v21, v4, v21                                 // 0000007195F4: 102A2B04
	v_bfe_u32 v27, v21, 16, 1                                  // 0000007195F8: D610001B 02052115
	s_delay_alu instid0(VALU_DEP_1)                            // 000000719600: BF870001
	v_add3_u32 v31, v21, v27, 0x7fff                           // 000000719604: D655001F 03FE3715 00007FFF
	v_lshrrev_b32_e32 v27, v32, v22                            // 000000719610: 32362D20
	v_lshrrev_b32_e32 v22, v34, v22                            // 000000719614: 322C2D22
	v_bfe_u32 v21, v18, v30, 4                                 // 000000719618: D6100015 02123D12
	v_bfe_u32 v18, v18, v33, 4                                 // 000000719620: D6100012 02124312
	.long 0x7e3e3991                                           // 000000719628: 7E3E3991
	v_lshlrev_b32_e32 v27, 4, v27                              // 00000071962C: 30363684
	v_lshlrev_b32_e32 v22, 4, v22                              // 000000719630: 302C2C84
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000719634: BF870112
	v_and_or_b32 v21, v27, 48, v21                             // 000000719638: D6570015 0455611B
	v_and_or_b32 v18, v22, 48, v18                             // 000000719640: D6570012 04496116
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000719648: BF870112
	v_subrev_nc_u32_e32 v21, 32, v21                           // 00000071964C: 4E2A2AA0
	v_subrev_nc_u32_e32 v18, 32, v18                           // 000000719650: 4E2424A0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000719654: BF870112
	v_cvt_f32_i32_e32 v21, v21                                 // 000000719658: 7E2A0B15
	v_cvt_f32_i32_e32 v18, v18                                 // 00000071965C: 7E240B12
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000719660: BF870121
	v_mul_f32_e32 v18, v4, v18                                 // 000000719664: 10242504
	v_bfe_u32 v17, v19, v25, 4                                 // 000000719668: D6100011 02123313
	v_bfe_u32 v22, v18, 16, 1                                  // 000000719670: D6100016 02052112
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000719678: BF8700A1
	v_add3_u32 v36, v18, v22, 0x7fff                           // 00000071967C: D6550024 03FE2D12 00007FFF
	v_lshrrev_b32_e32 v18, v26, v23                            // 000000719688: 32242F1A
	v_dual_mul_f32 v21, v4, v21 :: v_dual_lshlrev_b32 v18, 4, v18// 00000071968C: C8E22B04 15122484
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000719694: BF870111
	v_bfe_u32 v27, v21, 16, 1                                  // 000000719698: D610001B 02052115
	v_and_or_b32 v17, v18, 48, v17                             // 0000007196A0: D6570011 04456112
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007196A8: BF870112
	v_add3_u32 v21, v21, v27, 0x7fff                           // 0000007196AC: D6550015 03FE3715 00007FFF
	v_subrev_nc_u32_e32 v17, 32, v17                           // 0000007196B8: 4E2222A0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007196BC: BF8701A2
	.long 0x7e483995                                           // 0000007196C0: 7E483995
	v_lshrrev_b32_e32 v21, v29, v23                            // 0000007196C4: 322A2F1D
	v_cvt_f32_i32_e32 v17, v17                                 // 0000007196C8: 7E220B11
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007196CC: BF870112
	v_lshlrev_b32_e32 v21, 4, v21                              // 0000007196D0: 302A2A84
	v_mul_f32_e32 v17, v4, v17                                 // 0000007196D4: 10222304
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007196D8: BF870091
	v_bfe_u32 v18, v17, 16, 1                                  // 0000007196DC: D6100012 02052111
	v_add3_u32 v17, v17, v18, 0x7fff                           // 0000007196E4: D6550011 03FE2511 00007FFF
	v_bfe_u32 v18, v19, v28, 4                                 // 0000007196F0: D6100012 02123913
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007196F8: BF870091
	v_and_or_b32 v18, v21, 48, v18                             // 0000007196FC: D6570012 04496115
	v_subrev_nc_u32_e32 v18, 32, v18                           // 000000719704: 4E2424A0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000719708: BF870091
	v_cvt_f32_i32_e32 v18, v18                                 // 00000071970C: 7E240B12
	v_mul_f32_e32 v18, v4, v18                                 // 000000719710: 10242504
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000719714: BF870091
	v_bfe_u32 v21, v18, 16, 1                                  // 000000719718: D6100015 02052112
	v_add3_u32 v37, v18, v21, 0x7fff                           // 000000719720: D6550025 03FE2B12 00007FFF
	v_lshrrev_b32_e32 v21, v32, v23                            // 00000071972C: 322A2F20
	v_bfe_u32 v18, v19, v30, 4                                 // 000000719730: D6100012 02123D13
	v_bfe_u32 v19, v19, v33, 4                                 // 000000719738: D6100013 02124313
	.long 0x7e4a3991                                           // 000000719740: 7E4A3991
	v_bfe_u32 v17, v20, v25, 4                                 // 000000719744: D6100011 02123314
	v_lshlrev_b32_e32 v21, 4, v21                              // 00000071974C: 302A2A84
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000719750: BF870091
	v_and_or_b32 v18, v21, 48, v18                             // 000000719754: D6570012 04496115
	v_subrev_nc_u32_e32 v18, 32, v18                           // 00000071975C: 4E2424A0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000719760: BF870091
	v_cvt_f32_i32_e32 v18, v18                                 // 000000719764: 7E240B12
	v_mul_f32_e32 v18, v4, v18                                 // 000000719768: 10242504
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000071976C: BF870091
	v_bfe_u32 v21, v18, 16, 1                                  // 000000719770: D6100015 02052112
	v_add3_u32 v18, v18, v21, 0x7fff                           // 000000719778: D6550012 03FE2B12 00007FFF
	v_lshrrev_b32_e32 v21, v34, v23                            // 000000719784: 322A2F22
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000719788: BF870091
	v_lshlrev_b32_e32 v21, 4, v21                              // 00000071978C: 302A2A84
	v_and_or_b32 v19, v21, 48, v19                             // 000000719790: D6570013 044D6115
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000719798: BF870091
	v_subrev_nc_u32_e32 v19, 32, v19                           // 00000071979C: 4E2626A0
	v_cvt_f32_i32_e32 v19, v19                                 // 0000007197A0: 7E260B13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007197A4: BF870091
	v_mul_f32_e32 v19, v4, v19                                 // 0000007197A8: 10262704
	v_bfe_u32 v21, v19, 16, 1                                  // 0000007197AC: D6100015 02052113
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000007197B4: BF870141
	v_add3_u32 v38, v19, v21, 0x7fff                           // 0000007197B8: D6550026 03FE2B13 00007FFF
	.long 0x7e4c3992                                           // 0000007197C4: 7E4C3992
	v_lshrrev_b32_e32 v18, v26, v24                            // 0000007197C8: 3224311A
	v_lshrrev_b32_e32 v19, v29, v24                            // 0000007197CC: 3226311D
	v_lshlrev_b32_e32 v18, 4, v18                              // 0000007197D0: 30242484
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007197D4: BF870112
	v_lshlrev_b32_e32 v19, 4, v19                              // 0000007197D8: 30262684
	v_and_or_b32 v17, v18, 48, v17                             // 0000007197DC: D6570011 04456112
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007197E4: BF870091
	v_subrev_nc_u32_e32 v17, 32, v17                           // 0000007197E8: 4E2222A0
	v_cvt_f32_i32_e32 v17, v17                                 // 0000007197EC: 7E220B11
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007197F0: BF870091
	v_mul_f32_e32 v17, v4, v17                                 // 0000007197F4: 10222304
	v_bfe_u32 v18, v17, 16, 1                                  // 0000007197F8: D6100012 02052111
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000719800: BF8700A1
	v_add3_u32 v17, v17, v18, 0x7fff                           // 000000719804: D6550011 03FE2511 00007FFF
	v_bfe_u32 v18, v20, v28, 4                                 // 000000719810: D6100012 02123914
	v_and_or_b32 v18, v19, 48, v18                             // 000000719818: D6570012 04496113
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000719820: BF870091
	v_subrev_nc_u32_e32 v18, 32, v18                           // 000000719824: 4E2424A0
	v_cvt_f32_i32_e32 v18, v18                                 // 000000719828: 7E240B12
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000071982C: BF870091
	v_mul_f32_e32 v18, v4, v18                                 // 000000719830: 10242504
	v_bfe_u32 v19, v18, 16, 1                                  // 000000719834: D6100013 02052112
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000071983C: BF8701C1
	v_add3_u32 v29, v18, v19, 0x7fff                           // 000000719840: D655001D 03FE2712 00007FFF
	v_lshrrev_b32_e32 v19, v32, v24                            // 00000071984C: 32263120
	v_bfe_u32 v18, v20, v30, 4                                 // 000000719850: D6100012 02123D14
	.long 0x7e3a3991                                           // 000000719858: 7E3A3991
	v_lshlrev_b32_e32 v19, 4, v19                              // 00000071985C: 30262684
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000719860: BF870091
	v_and_or_b32 v18, v19, 48, v18                             // 000000719864: D6570012 04496113
	v_subrev_nc_u32_e32 v18, 32, v18                           // 00000071986C: 4E2424A0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000719870: BF870091
	v_cvt_f32_i32_e32 v18, v18                                 // 000000719874: 7E240B12
	v_mul_f32_e32 v18, v4, v18                                 // 000000719878: 10242504
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000071987C: BF870091
	v_bfe_u32 v19, v18, 16, 1                                  // 000000719880: D6100013 02052112
	v_add3_u32 v18, v18, v19, 0x7fff                           // 000000719888: D6550012 03FE2712 00007FFF
	v_bfe_u32 v19, v20, v33, 4                                 // 000000719894: D6100013 02124314
	v_lshrrev_b32_e32 v20, v34, v24                            // 00000071989C: 32283122
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007198A0: BF870091
	v_lshlrev_b32_e32 v20, 4, v20                              // 0000007198A4: 30282884
	v_and_or_b32 v19, v20, 48, v19                             // 0000007198A8: D6570013 044D6114
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007198B0: BF870091
	v_subrev_nc_u32_e32 v19, 32, v19                           // 0000007198B4: 4E2626A0
	v_cvt_f32_i32_e32 v19, v19                                 // 0000007198B8: 7E260B13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007198BC: BF870091
	v_mul_f32_e32 v4, v4, v19                                  // 0000007198C0: 10082704
	v_bfe_u32 v19, v4, 16, 1                                   // 0000007198C4: D6100013 02052104
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000007198CC: BF870131
	v_add3_u32 v30, v4, v19, 0x7fff                            // 0000007198D0: D655001E 03FE2704 00007FFF
	v_ashrrev_i32_e32 v4, 31, v3                               // 0000007198DC: 3408069F
	.long 0x7e3c3992                                           // 0000007198E0: 7E3C3992
	.long 0xd73c0011                                           // 0000007198E4: D73C0011
	v_cndmask_b32_e32 v1, 1, v3, vcc_lo                        // 0000007198E8: 02020681
	v_add_nc_u32_e32 v3, 0x200, v3                             // 0000007198EC: 4A0606FF 00000200
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007198F4: BF870092
	.long 0xd7006a19                                           // 0000007198F8: D7006A19
	v_cndmask_b32_e32 v1, s6, v17, vcc_lo                      // 0000007198FC: 02022206
	v_add_co_ci_u32_e64 v26, null, s7, v18, vcc_lo             // 000000719900: D5207C1A 01AA2407
	s_clause 0x1                                               // 000000719908: BF850001
	global_load_b128 v[17:20], v[25:26], off                   // 00000071990C: DC5E0000 117C0019
	global_load_b128 v[21:24], v[25:26], off offset:16         // 000000719914: DC5E0010 157C0019
	s_waitcnt vmcnt(1)                                         // 00000071991C: BF8907F7
	v_dot2_f32_bf16 v4, v17, v16, 0                            // 000000719920: CC1A4004 1A022111
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000719928: BF870091
	v_dot2_f32_bf16 v4, v18, v35, v4                           // 00000071992C: CC1A4004 1C124712
	v_dot2_f32_bf16 v4, v19, v31, v4                           // 000000719934: CC1A4004 1C123F13
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000071993C: BF8700A1
	v_dot2_f32_bf16 v4, v20, v36, v4                           // 000000719940: CC1A4004 1C124914
	s_waitcnt vmcnt(0)                                         // 000000719948: BF8903F7
	v_dot2_f32_bf16 v4, v21, v37, v4                           // 00000071994C: CC1A4004 1C124B15
	.long 0xd7006a15                                           // 000000719954: D7006A15
	v_cndmask_b32_e32 v0, v25, v4, vcc_lo                      // 000000719958: 02000919
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000071995C: BF8701B2
	v_dot2_f32_bf16 v4, v22, v38, v4                           // 000000719960: CC1A4004 1C124D16
	v_add_co_ci_u32_e64 v22, null, s5, v26, vcc_lo             // 000000719968: D5207C16 01AA3405
	.long 0xd7006a1b                                           // 000000719970: D7006A1B
	v_cndmask_b32_e32 v0, v25, v0, vcc_lo                      // 000000719974: 02000119
	v_dot2_f32_bf16 v4, v23, v29, v4                           // 000000719978: CC1A4004 1C123B17
	v_add_co_ci_u32_e64 v28, null, s1, v26, vcc_lo             // 000000719980: D5207C1C 01AA3401
	.long 0xd7006a19                                           // 000000719988: D7006A19
	v_cndmask_b32_e32 v0, v25, v17, vcc_lo                     // 00000071998C: 02002319
	s_delay_alu instid0(VALU_DEP_3)                            // 000000719990: BF870003
	v_dot2_f32_bf16 v4, v24, v30, v4                           // 000000719994: CC1A4004 1C123D18
	s_clause 0x1                                               // 00000071999C: BF850001
	global_load_b128 v[17:20], v[21:22], off                   // 0000007199A0: DC5E0000 117C0015
	global_load_b128 v[21:24], v[21:22], off offset:16         // 0000007199A8: DC5E0010 157C0015
	v_add_co_ci_u32_e64 v26, null, s16, v26, vcc_lo            // 0000007199B0: D5207C1A 01AA3410
	v_add_f32_e32 v8, v8, v4                                   // 0000007199B8: 06100908
	s_waitcnt vmcnt(1)                                         // 0000007199BC: BF8907F7
	v_dot2_f32_bf16 v4, v17, v16, 0                            // 0000007199C0: CC1A4004 1A022111
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007199C8: BF870091
	v_dot2_f32_bf16 v4, v18, v35, v4                           // 0000007199CC: CC1A4004 1C124712
	v_dot2_f32_bf16 v4, v19, v31, v4                           // 0000007199D4: CC1A4004 1C123F13
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007199DC: BF8700A1
	v_dot2_f32_bf16 v4, v20, v36, v4                           // 0000007199E0: CC1A4004 1C124914
	s_waitcnt vmcnt(0)                                         // 0000007199E8: BF8903F7
	v_dot2_f32_bf16 v4, v21, v37, v4                           // 0000007199EC: CC1A4004 1C124B15
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007199F4: BF870091
	v_dot2_f32_bf16 v4, v22, v38, v4                           // 0000007199F8: CC1A4004 1C124D16
	v_dot2_f32_bf16 v4, v23, v29, v4                           // 000000719A00: CC1A4004 1C123B17
	s_delay_alu instid0(VALU_DEP_1)                            // 000000719A08: BF870001
	v_dot2_f32_bf16 v4, v24, v30, v4                           // 000000719A0C: CC1A4004 1C123D18
	s_clause 0x1                                               // 000000719A14: BF850001
	global_load_b128 v[17:20], v[27:28], off                   // 000000719A18: DC5E0000 117C001B
	global_load_b128 v[21:24], v[27:28], off offset:16         // 000000719A20: DC5E0010 157C001B
	v_add_f32_e32 v15, v15, v4                                 // 000000719A28: 061E090F
	s_waitcnt vmcnt(1)                                         // 000000719A2C: BF8907F7
	v_dot2_f32_bf16 v4, v17, v16, 0                            // 000000719A30: CC1A4004 1A022111
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000719A38: BF870091
	v_dot2_f32_bf16 v4, v18, v35, v4                           // 000000719A3C: CC1A4004 1C124712
	v_dot2_f32_bf16 v4, v19, v31, v4                           // 000000719A44: CC1A4004 1C123F13
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000719A4C: BF8700A1
	v_dot2_f32_bf16 v4, v20, v36, v4                           // 000000719A50: CC1A4004 1C124914
	s_waitcnt vmcnt(0)                                         // 000000719A58: BF8903F7
	v_dot2_f32_bf16 v4, v21, v37, v4                           // 000000719A5C: CC1A4004 1C124B15
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000719A64: BF870091
	v_dot2_f32_bf16 v4, v22, v38, v4                           // 000000719A68: CC1A4004 1C124D16
	v_dot2_f32_bf16 v4, v23, v29, v4                           // 000000719A70: CC1A4004 1C123B17
	s_delay_alu instid0(VALU_DEP_1)                            // 000000719A78: BF870001
	v_dot2_f32_bf16 v4, v24, v30, v4                           // 000000719A7C: CC1A4004 1C123D18
	s_clause 0x1                                               // 000000719A84: BF850001
	global_load_b128 v[17:20], v[25:26], off                   // 000000719A88: DC5E0000 117C0019
	global_load_b128 v[21:24], v[25:26], off offset:16         // 000000719A90: DC5E0010 157C0019
	v_add_f32_e32 v14, v14, v4                                 // 000000719A98: 061C090E
	s_waitcnt vmcnt(1)                                         // 000000719A9C: BF8907F7
	v_dot2_f32_bf16 v4, v17, v16, 0                            // 000000719AA0: CC1A4004 1A022111
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000719AA8: BF870091
	v_dot2_f32_bf16 v4, v18, v35, v4                           // 000000719AAC: CC1A4004 1C124712
	v_dot2_f32_bf16 v4, v19, v31, v4                           // 000000719AB4: CC1A4004 1C123F13
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000719ABC: BF8700A1
	v_dot2_f32_bf16 v4, v20, v36, v4                           // 000000719AC0: CC1A4004 1C124914
	s_waitcnt vmcnt(0)                                         // 000000719AC8: BF8903F7
	v_dot2_f32_bf16 v4, v21, v37, v4                           // 000000719ACC: CC1A4004 1C124B15
	.long 0xd7006a15                                           // 000000719AD4: D7006A15
	v_cndmask_b32_e32 v0, v27, v0, vcc_lo                      // 000000719AD8: 0200011B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000719ADC: BF870122
	v_dot2_f32_bf16 v4, v22, v38, v4                           // 000000719AE0: CC1A4004 1C124D16
	v_add_co_ci_u32_e64 v22, null, s1, v28, vcc_lo             // 000000719AE8: D5207C16 01AA3801
	v_dot2_f32_bf16 v4, v23, v29, v4                           // 000000719AF0: CC1A4004 1C123B17
	s_delay_alu instid0(VALU_DEP_1)                            // 000000719AF8: BF870001
	v_dot2_f32_bf16 v4, v24, v30, v4                           // 000000719AFC: CC1A4004 1C123D18
	s_clause 0x1                                               // 000000719B04: BF850001
	global_load_b128 v[17:20], v[21:22], off                   // 000000719B08: DC5E0000 117C0015
	global_load_b128 v[21:24], v[21:22], off offset:16         // 000000719B10: DC5E0010 157C0015
	v_add_f32_e32 v13, v13, v4                                 // 000000719B18: 061A090D
	s_waitcnt vmcnt(1)                                         // 000000719B1C: BF8907F7
	v_dot2_f32_bf16 v4, v17, v16, 0                            // 000000719B20: CC1A4004 1A022111
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000719B28: BF870091
	v_dot2_f32_bf16 v4, v18, v35, v4                           // 000000719B2C: CC1A4004 1C124712
	v_dot2_f32_bf16 v4, v19, v31, v4                           // 000000719B34: CC1A4004 1C123F13
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000719B3C: BF8700A1
	v_dot2_f32_bf16 v4, v20, v36, v4                           // 000000719B40: CC1A4004 1C124914
	s_waitcnt vmcnt(0)                                         // 000000719B48: BF8903F7
	v_dot2_f32_bf16 v4, v21, v37, v4                           // 000000719B4C: CC1A4004 1C124B15
	.long 0xd7006a15                                           // 000000719B54: D7006A15
	v_cndmask_b32_e32 v0, v25, v0, vcc_lo                      // 000000719B58: 02000119
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000719B5C: BF8701B2
	v_dot2_f32_bf16 v4, v22, v38, v4                           // 000000719B60: CC1A4004 1C124D16
	v_add_co_ci_u32_e64 v22, null, s1, v26, vcc_lo             // 000000719B68: D5207C16 01AA3401
	v_cmp_ge_i32_e32 vcc_lo, v9, v10                           // 000000719B70: 7C8C1509
	v_dot2_f32_bf16 v4, v23, v29, v4                           // 000000719B74: CC1A4004 1C123B17
	s_or_b32 s3, vcc_lo, s3                                    // 000000719B7C: 8C03036A
	s_delay_alu instid0(VALU_DEP_1)                            // 000000719B80: BF870001
	v_dot2_f32_bf16 v4, v24, v30, v4                           // 000000719B84: CC1A4004 1C123D18
	s_clause 0x1                                               // 000000719B8C: BF850001
	global_load_b128 v[17:20], v[21:22], off                   // 000000719B90: DC5E0000 117C0015
	global_load_b128 v[21:24], v[21:22], off offset:16         // 000000719B98: DC5E0010 157C0015
	v_add_f32_e32 v12, v12, v4                                 // 000000719BA0: 0618090C
	s_waitcnt vmcnt(1)                                         // 000000719BA4: BF8907F7
	v_dot2_f32_bf16 v4, v17, v16, 0                            // 000000719BA8: CC1A4004 1A022111
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000719BB0: BF870091
	v_dot2_f32_bf16 v4, v18, v35, v4                           // 000000719BB4: CC1A4004 1C124712
	v_dot2_f32_bf16 v4, v19, v31, v4                           // 000000719BBC: CC1A4004 1C123F13
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000719BC4: BF8700A1
	v_dot2_f32_bf16 v4, v20, v36, v4                           // 000000719BC8: CC1A4004 1C124914
	s_waitcnt vmcnt(0)                                         // 000000719BD0: BF8903F7
	v_dot2_f32_bf16 v4, v21, v37, v4                           // 000000719BD4: CC1A4004 1C124B15
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000719BDC: BF870091
	v_dot2_f32_bf16 v4, v22, v38, v4                           // 000000719BE0: CC1A4004 1C124D16
	v_dot2_f32_bf16 v4, v23, v29, v4                           // 000000719BE8: CC1A4004 1C123B17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000719BF0: BF870091
	v_dot2_f32_bf16 v4, v24, v30, v4                           // 000000719BF4: CC1A4004 1C123D18
	v_add_f32_e32 v11, v11, v4                                 // 000000719BFC: 0616090B
	s_and_not1_b32 exec_lo, exec_lo, s3                        // 000000719C00: 917E037E
	s_cbranch_execnz 64975                                     // 000000719C04: BFA6FDCF <_ZN7halogen12_GLOBAL__N_16k_lq6kILi6ELi32ELi2ELb1EEEvPKhPKtPvll+0x144>
	s_or_b32 exec_lo, exec_lo, s3                              // 000000719C08: 8C7E037E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000719C0C: BF8700B9
	s_or_b32 exec_lo, exec_lo, s2                              // 000000719C10: 8C7E027E
	.long 0xd71f0001                                           // 000000719C14: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 000000719C18: 020100C1
	s_mov_b32 s0, exec_lo                                      // 000000719C1C: BE80007E
	v_xor_b32_e32 v2, 16, v1                                   // 000000719C20: 3A040290
	v_xor_b32_e32 v17, 8, v1                                   // 000000719C24: 3A220288
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000719C28: BF8701A2
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 000000719C2C: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 000000719C30: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v17                           // 000000719C34: 7C9822A0
	v_cndmask_b32_e32 v17, v1, v17, vcc_lo                     // 000000719C38: 02222301
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000719C3C: BF870211
	v_lshlrev_b32_e32 v17, 2, v17                              // 000000719C40: 30222282
	v_lshlrev_b32_e32 v2, 2, v2                                // 000000719C44: 30040482
	ds_bpermute_b32 v3, v2, v8                                 // 000000719C48: DACC0000 03000802
	s_waitcnt lgkmcnt(0)                                       // 000000719C50: BF89FC07
	v_add_f32_e32 v3, v8, v3                                   // 000000719C54: 06060708
	ds_bpermute_b32 v9, v2, v14                                // 000000719C58: DACC0000 09000E02
	ds_bpermute_b32 v4, v2, v15                                // 000000719C60: DACC0000 04000F02
	ds_bpermute_b32 v10, v2, v13                               // 000000719C68: DACC0000 0A000D02
	ds_bpermute_b32 v16, v2, v12                               // 000000719C70: DACC0000 10000C02
	ds_bpermute_b32 v2, v2, v11                                // 000000719C78: DACC0000 02000B02
	s_waitcnt lgkmcnt(4)                                       // 000000719C80: BF89FC47
	v_add_f32_e32 v8, v14, v9                                  // 000000719C84: 0610130E
	s_waitcnt lgkmcnt(2)                                       // 000000719C88: BF89FC27
	v_dual_add_f32 v4, v15, v4 :: v_dual_add_f32 v9, v13, v10  // 000000719C8C: C908090F 0408150D
	s_waitcnt lgkmcnt(1)                                       // 000000719C94: BF89FC17
	v_add_f32_e32 v10, v12, v16                                // 000000719C98: 0614210C
	s_waitcnt lgkmcnt(0)                                       // 000000719C9C: BF89FC07
	v_add_f32_e32 v2, v11, v2                                  // 000000719CA0: 0604050B
	ds_bpermute_b32 v13, v17, v8                               // 000000719CA4: DACC0000 0D000811
	ds_bpermute_b32 v11, v17, v3                               // 000000719CAC: DACC0000 0B000311
	ds_bpermute_b32 v12, v17, v4                               // 000000719CB4: DACC0000 0C000411
	ds_bpermute_b32 v14, v17, v9                               // 000000719CBC: DACC0000 0E000911
	ds_bpermute_b32 v15, v17, v10                              // 000000719CC4: DACC0000 0F000A11
	ds_bpermute_b32 v16, v17, v2                               // 000000719CCC: DACC0000 10000211
	v_xor_b32_e32 v17, 4, v1                                   // 000000719CD4: 3A220284
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000719CD8: BF870141
	v_cmp_gt_u32_e32 vcc_lo, 32, v17                           // 000000719CDC: 7C9822A0
	v_cndmask_b32_e32 v17, v1, v17, vcc_lo                     // 000000719CE0: 02222301
	s_waitcnt lgkmcnt(5)                                       // 000000719CE4: BF89FC57
	v_add_f32_e32 v8, v8, v13                                  // 000000719CE8: 06101B08
	v_lshlrev_b32_e32 v17, 2, v17                              // 000000719CEC: 30222282
	s_waitcnt lgkmcnt(3)                                       // 000000719CF0: BF89FC37
	v_dual_add_f32 v3, v3, v11 :: v_dual_add_f32 v4, v4, v12   // 000000719CF4: C9081703 03041904
	s_waitcnt lgkmcnt(1)                                       // 000000719CFC: BF89FC17
	v_dual_add_f32 v9, v9, v14 :: v_dual_add_f32 v10, v10, v15 // 000000719D00: C9081D09 090A1F0A
	s_waitcnt lgkmcnt(0)                                       // 000000719D08: BF89FC07
	v_add_f32_e32 v2, v2, v16                                  // 000000719D0C: 06042102
	ds_bpermute_b32 v13, v17, v8                               // 000000719D10: DACC0000 0D000811
	ds_bpermute_b32 v11, v17, v3                               // 000000719D18: DACC0000 0B000311
	ds_bpermute_b32 v12, v17, v4                               // 000000719D20: DACC0000 0C000411
	ds_bpermute_b32 v14, v17, v9                               // 000000719D28: DACC0000 0E000911
	ds_bpermute_b32 v15, v17, v10                              // 000000719D30: DACC0000 0F000A11
	ds_bpermute_b32 v16, v17, v2                               // 000000719D38: DACC0000 10000211
	v_xor_b32_e32 v17, 2, v1                                   // 000000719D40: 3A220282
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000719D44: BF870141
	v_cmp_gt_u32_e32 vcc_lo, 32, v17                           // 000000719D48: 7C9822A0
	v_cndmask_b32_e32 v17, v1, v17, vcc_lo                     // 000000719D4C: 02222301
	s_waitcnt lgkmcnt(5)                                       // 000000719D50: BF89FC57
	v_add_f32_e32 v8, v8, v13                                  // 000000719D54: 06101B08
	v_lshlrev_b32_e32 v17, 2, v17                              // 000000719D58: 30222282
	s_waitcnt lgkmcnt(3)                                       // 000000719D5C: BF89FC37
	v_dual_add_f32 v3, v3, v11 :: v_dual_add_f32 v4, v4, v12   // 000000719D60: C9081703 03041904
	s_waitcnt lgkmcnt(1)                                       // 000000719D68: BF89FC17
	v_dual_add_f32 v9, v9, v14 :: v_dual_add_f32 v10, v10, v15 // 000000719D6C: C9081D09 090A1F0A
	ds_bpermute_b32 v13, v17, v8                               // 000000719D74: DACC0000 0D000811
	s_waitcnt lgkmcnt(1)                                       // 000000719D7C: BF89FC17
	v_add_f32_e32 v11, v2, v16                                 // 000000719D80: 06162102
	ds_bpermute_b32 v2, v17, v3                                // 000000719D84: DACC0000 02000311
	ds_bpermute_b32 v12, v17, v4                               // 000000719D8C: DACC0000 0C000411
	ds_bpermute_b32 v14, v17, v9                               // 000000719D94: DACC0000 0E000911
	ds_bpermute_b32 v15, v17, v10                              // 000000719D9C: DACC0000 0F000A11
	ds_bpermute_b32 v16, v17, v11                              // 000000719DA4: DACC0000 10000B11
	v_xor_b32_e32 v17, 1, v1                                   // 000000719DAC: 3A220281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000719DB0: BF8700A1
	v_cmp_gt_u32_e32 vcc_lo, 32, v17                           // 000000719DB4: 7C9822A0
	v_cndmask_b32_e32 v1, v1, v17, vcc_lo                      // 000000719DB8: 02022301
	v_lshlrev_b32_e32 v17, 2, v1                               // 000000719DBC: 30220282
	s_waitcnt lgkmcnt(3)                                       // 000000719DC0: BF89FC37
	v_dual_add_f32 v1, v3, v2 :: v_dual_add_f32 v2, v4, v12    // 000000719DC4: C9080503 01021904
	v_add_f32_e32 v4, v8, v13                                  // 000000719DCC: 06081B08
	s_waitcnt lgkmcnt(1)                                       // 000000719DD0: BF89FC17
	v_dual_add_f32 v8, v9, v14 :: v_dual_add_f32 v3, v10, v15  // 000000719DD4: C9081D09 08021F0A
	s_waitcnt lgkmcnt(0)                                       // 000000719DDC: BF89FC07
	v_add_f32_e32 v14, v11, v16                                // 000000719DE0: 061C210B
	ds_bpermute_b32 v9, v17, v1                                // 000000719DE4: DACC0000 09000111
	ds_bpermute_b32 v10, v17, v2                               // 000000719DEC: DACC0000 0A000211
	ds_bpermute_b32 v12, v17, v4                               // 000000719DF4: DACC0000 0C000411
	ds_bpermute_b32 v13, v17, v8                               // 000000719DFC: DACC0000 0D000811
	ds_bpermute_b32 v11, v17, v3                               // 000000719E04: DACC0000 0B000311
	ds_bpermute_b32 v15, v17, v14                              // 000000719E0C: DACC0000 0F000E11
	v_cmpx_eq_u32_e32 0, v7                                    // 000000719E14: 7D940E80
	s_cbranch_execz 15                                         // 000000719E18: BFA5000F <_ZN7halogen12_GLOBAL__N_16k_lq6kILi6ELi32ELi2ELb1EEEvPKhPKtPvll+0xc58>
	s_waitcnt lgkmcnt(0)                                       // 000000719E1C: BF89FC07
	v_dual_add_f32 v7, v14, v15 :: v_dual_add_f32 v4, v4, v12  // 000000719E20: C9081F0E 07041904
	v_mul_u32_u24_e32 v14, 24, v5                              // 000000719E28: 161C0A98
	v_dual_add_f32 v5, v8, v13 :: v_dual_add_f32 v2, v2, v10   // 000000719E2C: C9081B08 05021502
	v_add_f32_e32 v1, v1, v9                                   // 000000719E34: 06021301
	s_delay_alu instid0(VALU_DEP_3)                            // 000000719E38: BF870003
	v_mad_u32_u24 v8, v6, 48, v14                              // 000000719E3C: D60B0008 04396106
	v_add_f32_e32 v6, v3, v11                                  // 000000719E44: 060C1703
	ds_store_2addr_b64 v8, v[1:2], v[4:5] offset1:1            // 000000719E48: D9380100 00040108
	ds_store_b64 v8, v[6:7] offset:16                          // 000000719E50: D9340010 00000608
	s_or_b32 exec_lo, exec_lo, s0                              // 000000719E58: 8C7E007E
	.long 0xd7050001                                           // 000000719E5C: D7050001
	v_cndmask_b32_e32 v1, 0xab, v0, vcc_lo                     // 000000719E60: 020200FF 000000AB
	.long 0x7f063880                                           // 000000719E68: 7F063880
	s_waitcnt lgkmcnt(0)                                       // 000000719E6C: BF89FC07
	s_barrier                                                  // 000000719E70: BFBD0000
	buffer_gl0_inv                                             // 000000719E74: E0AC0000 00000000
	.long 0xd7390003                                           // 000000719E7C: D7390003
	v_cndmask_b32_e32 v1, 10, v1, vcc_lo                       // 000000719E80: 0202028A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000719E84: BF870091
	.long 0xd7000001                                           // 000000719E88: D7000001
	v_cndmask_b32_e32 v1, s14, v3, vcc_lo                      // 000000719E8C: 0202060E
	v_add_co_ci_u32_e64 v2, null, s15, 0, s0                   // 000000719E90: D5207C02 0001000F
	.long 0xd44c0000                                           // 000000719E98: D44C0000
	v_cndmask_b32_e32 v1, 24, v0, vcc_lo                       // 000000719E9C: 02020098
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000719EA0: BF8704A2
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[1:2]                  // 000000719EA4: 7CA8020C
	s_and_b32 s0, s0, vcc_lo                                   // 000000719EA8: 8B006A00
	s_and_saveexec_b32 s1, s0                                  // 000000719EAC: BE812000
	s_cbranch_execz 37                                         // 000000719EB0: BFA50025 <_ZN7halogen12_GLOBAL__N_16k_lq6kILi6ELi32ELi2ELb1EEEvPKhPKtPvll+0xd48>
	.long 0xd7054000                                           // 000000719EB4: D7054000
	v_cndmask_b32_e32 v0, v3, v134, vcc_lo                     // 000000719EB8: 02010D03
	v_mul_u32_u24_e32 v3, 48, v3                               // 000000719EBC: 160606B0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000719EC0: BF870092
	.long 0xd7041000                                           // 000000719EC4: D7041000
	v_cndmask_b32_e32 v1, v0, v0, vcc_lo                       // 000000719EC8: 02020100
	v_and_b32_e32 v0, 0xff, v0                                 // 000000719ECC: 360000FF 000000FF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 000000719ED4: BF870151
	v_lshl_add_u32 v5, v0, 2, v3                               // 000000719ED8: D6460005 040D0500
	v_mad_u64_u32 v[3:4], null, s12, v0, 0                     // 000000719EE0: D6FE7C03 0202000C
	ds_load_2addr_b32 v[6:7], v5 offset1:6                     // 000000719EE8: D8DC0600 06000005
	v_mad_u64_u32 v[4:5], null, s13, v0, v[4:5]                // 000000719EF0: D6FE7C04 0412000D
	.long 0xd73c0000                                           // 000000719EF8: D73C0000
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 000000719EFC: 02020282
	.long 0xd73c0003                                           // 000000719F00: D73C0003
	v_cndmask_b32_e32 v1, 2, v3, vcc_lo                        // 000000719F04: 02020682
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000719F08: BF8701B1
	.long 0xd7006a03                                           // 000000719F0C: D7006A03
	v_cndmask_b32_e32 v1, s8, v3, vcc_lo                       // 000000719F10: 02020608
	s_waitcnt lgkmcnt(0)                                       // 000000719F14: BF89FC07
	v_add_f32_e32 v2, 0, v6                                    // 000000719F18: 06040C80
	v_add_co_ci_u32_e64 v4, null, s9, v4, vcc_lo               // 000000719F1C: D5207C04 01AA0809
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000719F24: BF870193
	.long 0xd7006a00                                           // 000000719F28: D7006A00
	v_cndmask_b32_e32 v1, v3, v0, vcc_lo                       // 000000719F2C: 02020103
	v_add_f32_e32 v2, v2, v7                                   // 000000719F30: 06040F02
	s_delay_alu instid0(VALU_DEP_3)                            // 000000719F34: BF870003
	v_add_co_ci_u32_e64 v1, null, v4, v1, vcc_lo               // 000000719F38: D5207C01 01AA0304
	global_store_b32 v[0:1], v2, off                           // 000000719F40: DC6A0000 007C0200
	s_endpgm                                                   // 000000719F48: BFB00000
		...

