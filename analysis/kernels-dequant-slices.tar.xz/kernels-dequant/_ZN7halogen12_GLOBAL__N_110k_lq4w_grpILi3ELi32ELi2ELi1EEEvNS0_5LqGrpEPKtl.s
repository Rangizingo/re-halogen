0000000000299d00 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi32ELi2ELi1EEEvNS0_5LqGrpEPKtl>:
; _ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi32ELi2ELi1EEEvNS0_5LqGrpEPKtl():
	s_clause 0x3                                               // 000000299D00: BF850003
	s_load_b32 s3, s[0:1], 0x120                               // 000000299D04: F40000C0 F8000120
	s_load_b32 s4, s[0:1], 0x88                                // 000000299D0C: F4000100 F8000088
	s_load_b32 s5, s[0:1], 0xd0                                // 000000299D14: F4000140 F80000D0
	s_load_b32 s6, s[0:1], 0x118                               // 000000299D1C: F4000180 F8000118
	v_lshrrev_b32_e32 v2, 2, v0                                // 000000299D24: 32040082
	s_load_b128 s[12:15], s[0:1], 0x128                        // 000000299D28: F4080300 F8000128
	v_and_b32_e32 v23, 31, v0                                  // 000000299D30: 362E009F
	s_delay_alu instid0(VALU_DEP_2)                            // 000000299D34: BF870002
	v_and_b32_e32 v2, 60, v2                                   // 000000299D38: 360404BC
	s_waitcnt lgkmcnt(0)                                       // 000000299D3C: BF89FC07
	s_cmp_gt_i32 s3, 1                                         // 000000299D40: BF028103
	s_cselect_b32 s7, -1, 0                                    // 000000299D44: 980780C1
	s_cmp_ge_i32 s2, s4                                        // 000000299D48: BF030402
	s_cselect_b32 s4, -1, 0                                    // 000000299D4C: 980480C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000299D50: BF870009
	s_and_b32 s4, s7, s4                                       // 000000299D54: 8B040407
	s_cmp_gt_i32 s3, 2                                         // 000000299D58: BF028203
	v_cndmask_b32_e64 v1, 0, 1, s4                             // 000000299D5C: D5010001 00110280
	s_cselect_b32 s7, -1, 0                                    // 000000299D64: 980780C1
	s_cmp_ge_i32 s2, s5                                        // 000000299D68: BF030502
	s_cselect_b32 s5, -1, 0                                    // 000000299D6C: 980580C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000299D70: BF870009
	s_and_b32 s4, s7, s5                                       // 000000299D74: 8B040507
	s_cmp_gt_i32 s3, 3                                         // 000000299D78: BF028303
	v_readfirstlane_b32 s5, v1                                 // 000000299D7C: 7E0A0501
	s_cselect_b32 s3, -1, 0                                    // 000000299D80: 980380C1
	s_cmp_ge_i32 s2, s6                                        // 000000299D84: BF030602
	v_and_b32_e32 v1, 15, v0                                   // 000000299D88: 3602008F
	s_cselect_b32 s6, -1, 0                                    // 000000299D8C: 980680C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000299D90: BF870009
	s_and_b32 s3, s3, s6                                       // 000000299D94: 8B030603
	s_and_b32 s4, s4, exec_lo                                  // 000000299D98: 8B047E04
	s_cselect_b32 s4, 2, s5                                    // 000000299D9C: 98040582
	s_and_b32 s3, s3, exec_lo                                  // 000000299DA0: 8B037E03
	s_cselect_b32 s3, 3, s4                                    // 000000299DA4: 98030483
	v_lshlrev_b32_e32 v1, 2, v1                                // 000000299DA8: 30020282
	s_mulk_i32 s3, 0x48                                        // 000000299DAC: B8030048
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000299DB0: BF870009
	s_add_u32 s16, s0, s3                                      // 000000299DB4: 80100300
	s_addc_u32 s17, s1, 0                                      // 000000299DB8: 82118001
	s_clause 0x1                                               // 000000299DBC: BF850001
	s_load_b64 s[18:19], s[16:17], null                        // 000000299DC0: F4040488 F8000000
	s_load_b256 s[4:11], s[16:17], 0x18                        // 000000299DC8: F40C0108 F8000018
	s_waitcnt lgkmcnt(0)                                       // 000000299DD0: BF89FC07
	s_clause 0x1                                               // 000000299DD4: BF850001
	global_load_b32 v1, v1, s[18:19]                           // 000000299DD8: DC520000 01120001
	global_load_b32 v2, v2, s[18:19]                           // 000000299DE0: DC520000 02120002
	.long 0xd4510014                                           // 000000299DE8: D4510014
	v_cndmask_b32_e32 v0, s10, v137, vcc_lo                    // 000000299DEC: 0201120A
	s_and_b32 s3, s20, exec_lo                                 // 000000299DF0: 8B037E14
	s_cselect_b32 s3, 8, 2                                     // 000000299DF4: 98038288
	s_cselect_b32 s21, 3, 1                                    // 000000299DF8: 98158183
	s_add_i32 s26, s3, -1                                      // 000000299DFC: 811AC103
	s_waitcnt vmcnt(1)                                         // 000000299E00: BF8907F7
	v_bfe_u32 v3, v1, 16, 1                                    // 000000299E04: D6100003 02052101
	s_waitcnt vmcnt(0)                                         // 000000299E0C: BF8903F7
	v_bfe_u32 v4, v2, 16, 1                                    // 000000299E10: D6100004 02052102
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000299E18: BF8701A2
	v_add3_u32 v1, v1, v3, 0x7fff                              // 000000299E1C: D6550001 03FE0701 00007FFF
	.long 0x7f063880                                           // 000000299E28: 7F063880
	v_add3_u32 v2, v2, v4, 0x7fff                              // 000000299E2C: D6550002 03FE0902 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000299E38: BF870123
	.long 0x7e063981                                           // 000000299E3C: 7E063981
	v_lshlrev_b32_e32 v1, 2, v0                                // 000000299E40: 30020082
	v_and_or_b32 v2, 0xffff0000, v2, v3                        // 000000299E44: D6570002 040E04FF FFFF0000
	v_lshrrev_b32_e32 v3, 5, v0                                // 000000299E50: 32060085
	ds_store_b32 v1, v2                                        // 000000299E54: D8340000 00000201
	v_cvt_f32_ubyte0_e32 v1, s3                                // 000000299E5C: 7E022203
	v_lshrrev_b32_e32 v21, s21, v3                             // 000000299E60: 322A0615
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000299E64: BF870292
	v_rcp_iflag_f32_e32 v1, v1                                 // 000000299E68: 7E025701
	v_readfirstlane_b32 s23, v1                                // 000000299E6C: 7E2E0501
	s_mul_f32 s23, s23, 0x4f7ffffe                             // 000000299E70: A217FF17 4F7FFFFE
	s_delay_alu instid0(SALU_CYCLE_3)                          // 000000299E78: BF87000B
	s_cvt_u32_f32 s23, s23                                     // 000000299E7C: BE976717
	s_waitcnt lgkmcnt(0)                                       // 000000299E80: BF89FC07
	s_barrier                                                  // 000000299E84: BFBD0000
	buffer_gl0_inv                                             // 000000299E88: E0AC0000 00000000
	s_load_b32 s22, s[16:17], 0x40                             // 000000299E90: F4000588 F8000040
	s_waitcnt lgkmcnt(0)                                       // 000000299E98: BF89FC07
	s_sub_i32 s0, s2, s22                                      // 000000299E9C: 81801602
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 000000299EA0: BF8704B9
	s_ashr_i32 s1, s0, 31                                      // 000000299EA4: 86019F00
	s_and_b32 s22, s20, exec_lo                                // 000000299EA8: 8B167E14
	s_cselect_b32 s22, 0, 2                                    // 000000299EAC: 98168280
	s_lshl_b64 s[0:1], s[0:1], s22                             // 000000299EB0: 84801600
	s_add_u32 s6, s18, s6                                      // 000000299EB4: 80060612
	s_addc_u32 s7, s19, s7                                     // 000000299EB8: 82070713
	s_ashr_i32 s24, s15, 31                                    // 000000299EBC: 86189F0F
	.long 0xd7000001                                           // 000000299EC0: D7000001
	v_cndmask_b32_e32 v1, s0, v21, vcc_lo                      // 000000299EC4: 02022A00
	s_lshr_b32 s24, s24, 27                                    // 000000299EC8: 85189B18
	v_add_co_ci_u32_e64 v2, null, s1, 0, s0                    // 000000299ECC: D5207C02 00010001
	s_add_u32 s24, s14, s24                                    // 000000299ED4: 8018180E
	s_addc_u32 s25, s15, 0                                     // 000000299ED8: 8219800F
	s_sub_i32 s27, 0, s3                                       // 000000299EDC: 819B0380
	s_lshr_b64 s[24:25], s[24:25], 5                           // 000000299EE0: 85988518
	s_mul_i32 s27, s27, s23                                    // 000000299EE4: 961B171B
	s_add_i32 s25, s26, s24                                    // 000000299EE8: 8119181A
	s_mul_hi_u32 s27, s23, s27                                 // 000000299EEC: 969B1B17
	s_abs_i32 s28, s25                                         // 000000299EF0: BE9C1519
	s_add_i32 s23, s23, s27                                    // 000000299EF4: 81171B17
	s_ashr_i32 s25, s25, 31                                    // 000000299EF8: 86199F19
	s_mul_hi_u32 s23, s28, s23                                 // 000000299EFC: 9697171C
	v_cmp_gt_i64_e32 vcc_lo, s[10:11], v[1:2]                  // 000000299F00: 7CA8020A
	s_mul_i32 s27, s23, s3                                     // 000000299F04: 961B0317
	v_and_b32_e32 v22, s26, v3                                 // 000000299F08: 362C061A
	s_sub_i32 s27, s28, s27                                    // 000000299F0C: 819B1B1C
	s_add_i32 s28, s23, 1                                      // 000000299F10: 811C8117
	s_sub_i32 s29, s27, s3                                     // 000000299F14: 819D031B
	s_cmp_ge_u32 s27, s3                                       // 000000299F18: BF09031B
	v_cndmask_b32_e32 v9, 0, v2, vcc_lo                        // 000000299F1C: 02120480
	s_cselect_b32 s0, s28, s23                                 // 000000299F20: 9800171C
	s_cselect_b32 s1, s29, s27                                 // 000000299F24: 98011B1D
	s_add_i32 s23, s0, 1                                       // 000000299F28: 81178100
	s_cmp_ge_u32 s1, s3                                        // 000000299F2C: BF090301
	v_cndmask_b32_e32 v10, 0, v1, vcc_lo                       // 000000299F30: 02140280
	s_cselect_b32 s0, s23, s0                                  // 000000299F34: 98000017
	.long 0xd72c0002                                           // 000000299F38: D72C0002
	v_cndmask_b32_e32 v0, v9, v8, vcc_lo                       // 000000299F3C: 02001109
	s_xor_b32 s0, s0, s25                                      // 000000299F40: 8D001900
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000299F44: BF870009
	s_sub_i32 s1, s0, s25                                      // 000000299F48: 81811900
	.long 0xd72c0003                                           // 000000299F4C: D72C0003
	v_cndmask_b32_e32 v0, v10, v9, vcc_lo                      // 000000299F50: 0200130A
	.long 0xd72c000d                                           // 000000299F54: D72C000D
	v_cndmask_b32_e32 v1, s1, v22, vcc_lo                      // 000000299F58: 02022C01
	v_mad_u64_u32 v[17:18], null, v10, s8, s[6:7]              // 000000299F5C: D6FE7C11 0018110A
	s_cmpk_lt_i32 s1, 0x101                                    // 000000299F64: B3810101
	s_cselect_b32 s0, -1, 0                                    // 000000299F68: 980080C1
	s_cmpk_gt_i32 s1, 0x100                                    // 000000299F6C: B2810100
	s_cselect_b32 s6, -1, 0                                    // 000000299F70: 980680C1
	v_add_nc_u32_e32 v1, s1, v13                               // 000000299F74: 4A021A01
	v_add_nc_u32_e32 v25, v13, v23                             // 000000299F78: 4A322F0D
	v_add3_u32 v26, v2, v18, v3                                // 000000299F7C: D655001A 040E2502
	s_and_b32 vcc_lo, exec_lo, s6                              // 000000299F84: 8B6A067E
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000299F88: BF870123
	v_min_i32_e32 v24, s24, v1                                 // 000000299F8C: 22300218
	v_mov_b32_e32 v1, 0                                        // 000000299F90: 7E020280
	.long 0xd4410001                                           // 000000299F94: D4410001
	v_cndmask_b32_e32 v1, v25, v24, vcc_lo                     // 000000299F98: 02023119
	s_cbranch_vccnz 153                                        // 000000299F9C: BFA40099 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi32ELi2ELi1EEEvNS0_5LqGrpEPKtl+0x504>
	s_and_saveexec_b32 s7, s1                                  // 000000299FA0: BE872001
	s_cbranch_execz 11                                         // 000000299FA4: BFA5000B <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi32ELi2ELi1EEEvNS0_5LqGrpEPKtl+0x2d4>
	v_lshlrev_b32_e32 v1, 1, v25                               // 000000299FA8: 30023281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000299FAC: BF8700A1
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000299FB0: 3404029F
	.long 0xd7006a01                                           // 000000299FB4: D7006A01
	v_cndmask_b32_e32 v1, v17, v1, vcc_lo                      // 000000299FB8: 02020311
	v_add_co_ci_u32_e64 v2, null, v26, v2, vcc_lo              // 000000299FBC: D5207C02 01AA051A
	global_load_d16_b16 v1, v[1:2], off                        // 000000299FC4: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 000000299FCC: BF8903F7
	v_cvt_f32_f16_e32 v1, v1                                   // 000000299FD0: 7E021701
	s_or_b32 exec_lo, exec_lo, s7                              // 000000299FD4: 8C7E077E
	v_dual_mov_b32 v3, 0 :: v_dual_add_nc_u32 v4, 32, v25      // 000000299FD8: CA200080 030432A0
	v_mov_b32_e32 v2, 0                                        // 000000299FE0: 7E040280
	s_mov_b32 s1, exec_lo                                      // 000000299FE4: BE81007E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000299FE8: BF870002
	.long 0xd4c1007e                                           // 000000299FEC: D4C1007E
	v_cndmask_b32_e32 v1, v4, v24, vcc_lo                      // 000000299FF0: 02023104
	s_cbranch_execz 11                                         // 000000299FF4: BFA5000B <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi32ELi2ELi1EEEvNS0_5LqGrpEPKtl+0x324>
	v_lshlrev_b32_e32 v2, 1, v4                                // 000000299FF8: 30040881
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000299FFC: BF8700A1
	v_ashrrev_i32_e32 v5, 31, v2                               // 00000029A000: 340A049F
	.long 0xd7006a04                                           // 00000029A004: D7006A04
	v_cndmask_b32_e32 v1, v17, v2, vcc_lo                      // 00000029A008: 02020511
	v_add_co_ci_u32_e64 v5, null, v26, v5, vcc_lo              // 00000029A00C: D5207C05 01AA0B1A
	global_load_d16_b16 v2, v[4:5], off                        // 00000029A014: DC820000 027C0004
	s_waitcnt vmcnt(0)                                         // 00000029A01C: BF8903F7
	v_cvt_f32_f16_e32 v2, v2                                   // 00000029A020: 7E041702
	s_or_b32 exec_lo, exec_lo, s1                              // 00000029A024: 8C7E017E
	v_add_nc_u32_e32 v4, 64, v25                               // 00000029A028: 4A0832C0
	s_mov_b32 s1, exec_lo                                      // 00000029A02C: BE81007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000029A030: BF870001
	.long 0xd4c1007e                                           // 00000029A034: D4C1007E
	v_cndmask_b32_e32 v1, v4, v24, vcc_lo                      // 00000029A038: 02023104
	s_cbranch_execz 11                                         // 00000029A03C: BFA5000B <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi32ELi2ELi1EEEvNS0_5LqGrpEPKtl+0x36c>
	v_lshlrev_b32_e32 v3, 1, v4                                // 00000029A040: 30060881
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000029A044: BF8700A1
	v_ashrrev_i32_e32 v4, 31, v3                               // 00000029A048: 3408069F
	.long 0xd7006a03                                           // 00000029A04C: D7006A03
	v_cndmask_b32_e32 v1, v17, v3, vcc_lo                      // 00000029A050: 02020711
	v_add_co_ci_u32_e64 v4, null, v26, v4, vcc_lo              // 00000029A054: D5207C04 01AA091A
	global_load_d16_b16 v3, v[3:4], off                        // 00000029A05C: DC820000 037C0003
	s_waitcnt vmcnt(0)                                         // 00000029A064: BF8903F7
	v_cvt_f32_f16_e32 v3, v3                                   // 00000029A068: 7E061703
	s_or_b32 exec_lo, exec_lo, s1                              // 00000029A06C: 8C7E017E
	v_dual_mov_b32 v5, 0 :: v_dual_add_nc_u32 v6, 0x60, v25    // 00000029A070: CA200080 050632FF 00000060
	v_mov_b32_e32 v4, 0                                        // 00000029A07C: 7E080280
	s_mov_b32 s1, exec_lo                                      // 00000029A080: BE81007E
	s_delay_alu instid0(VALU_DEP_2)                            // 00000029A084: BF870002
	.long 0xd4c1007e                                           // 00000029A088: D4C1007E
	v_cndmask_b32_e32 v1, v6, v24, vcc_lo                      // 00000029A08C: 02023106
	s_cbranch_execz 11                                         // 00000029A090: BFA5000B <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi32ELi2ELi1EEEvNS0_5LqGrpEPKtl+0x3c0>
	v_lshlrev_b32_e32 v4, 1, v6                                // 00000029A094: 30080C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000029A098: BF8700A1
	v_ashrrev_i32_e32 v7, 31, v4                               // 00000029A09C: 340E089F
	.long 0xd7006a06                                           // 00000029A0A0: D7006A06
	v_cndmask_b32_e32 v1, v17, v4, vcc_lo                      // 00000029A0A4: 02020911
	v_add_co_ci_u32_e64 v7, null, v26, v7, vcc_lo              // 00000029A0A8: D5207C07 01AA0F1A
	global_load_d16_b16 v4, v[6:7], off                        // 00000029A0B0: DC820000 047C0006
	s_waitcnt vmcnt(0)                                         // 00000029A0B8: BF8903F7
	v_cvt_f32_f16_e32 v4, v4                                   // 00000029A0BC: 7E081704
	s_or_b32 exec_lo, exec_lo, s1                              // 00000029A0C0: 8C7E017E
	v_add_nc_u32_e32 v6, 0x80, v25                             // 00000029A0C4: 4A0C32FF 00000080
	s_mov_b32 s1, exec_lo                                      // 00000029A0CC: BE81007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000029A0D0: BF870001
	.long 0xd4c1007e                                           // 00000029A0D4: D4C1007E
	v_cndmask_b32_e32 v1, v6, v24, vcc_lo                      // 00000029A0D8: 02023106
	s_cbranch_execz 11                                         // 00000029A0DC: BFA5000B <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi32ELi2ELi1EEEvNS0_5LqGrpEPKtl+0x40c>
	v_lshlrev_b32_e32 v5, 1, v6                                // 00000029A0E0: 300A0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000029A0E4: BF8700A1
	v_ashrrev_i32_e32 v6, 31, v5                               // 00000029A0E8: 340C0A9F
	.long 0xd7006a05                                           // 00000029A0EC: D7006A05
	v_cndmask_b32_e32 v1, v17, v5, vcc_lo                      // 00000029A0F0: 02020B11
	v_add_co_ci_u32_e64 v6, null, v26, v6, vcc_lo              // 00000029A0F4: D5207C06 01AA0D1A
	global_load_d16_b16 v5, v[5:6], off                        // 00000029A0FC: DC820000 057C0005
	s_waitcnt vmcnt(0)                                         // 00000029A104: BF8903F7
	v_cvt_f32_f16_e32 v5, v5                                   // 00000029A108: 7E0A1705
	s_or_b32 exec_lo, exec_lo, s1                              // 00000029A10C: 8C7E017E
	v_dual_mov_b32 v7, 0 :: v_dual_add_nc_u32 v8, 0xa0, v25    // 00000029A110: CA200080 070832FF 000000A0
	v_mov_b32_e32 v6, 0                                        // 00000029A11C: 7E0C0280
	s_mov_b32 s1, exec_lo                                      // 00000029A120: BE81007E
	s_delay_alu instid0(VALU_DEP_2)                            // 00000029A124: BF870002
	.long 0xd4c1007e                                           // 00000029A128: D4C1007E
	v_cndmask_b32_e32 v1, v8, v24, vcc_lo                      // 00000029A12C: 02023108
	s_cbranch_execz 11                                         // 00000029A130: BFA5000B <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi32ELi2ELi1EEEvNS0_5LqGrpEPKtl+0x460>
	v_lshlrev_b32_e32 v6, 1, v8                                // 00000029A134: 300C1081
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000029A138: BF8700A1
	v_ashrrev_i32_e32 v8, 31, v6                               // 00000029A13C: 34100C9F
	.long 0xd7006a0b                                           // 00000029A140: D7006A0B
	v_cndmask_b32_e32 v1, v17, v6, vcc_lo                      // 00000029A144: 02020D11
	v_add_co_ci_u32_e64 v12, null, v26, v8, vcc_lo             // 00000029A148: D5207C0C 01AA111A
	global_load_d16_b16 v6, v[11:12], off                      // 00000029A150: DC820000 067C000B
	s_waitcnt vmcnt(0)                                         // 00000029A158: BF8903F7
	v_cvt_f32_f16_e32 v6, v6                                   // 00000029A15C: 7E0C1706
	s_or_b32 exec_lo, exec_lo, s1                              // 00000029A160: 8C7E017E
	v_add_nc_u32_e32 v8, 0xc0, v25                             // 00000029A164: 4A1032FF 000000C0
	s_mov_b32 s1, exec_lo                                      // 00000029A16C: BE81007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000029A170: BF870001
	.long 0xd4c1007e                                           // 00000029A174: D4C1007E
	v_cndmask_b32_e32 v1, v8, v24, vcc_lo                      // 00000029A178: 02023108
	s_cbranch_execz 11                                         // 00000029A17C: BFA5000B <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi32ELi2ELi1EEEvNS0_5LqGrpEPKtl+0x4ac>
	v_lshlrev_b32_e32 v7, 1, v8                                // 00000029A180: 300E1081
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000029A184: BF8700A1
	v_ashrrev_i32_e32 v8, 31, v7                               // 00000029A188: 34100E9F
	.long 0xd7006a07                                           // 00000029A18C: D7006A07
	v_cndmask_b32_e32 v1, v17, v7, vcc_lo                      // 00000029A190: 02020F11
	v_add_co_ci_u32_e64 v8, null, v26, v8, vcc_lo              // 00000029A194: D5207C08 01AA111A
	global_load_d16_b16 v7, v[7:8], off                        // 00000029A19C: DC820000 077C0007
	s_waitcnt vmcnt(0)                                         // 00000029A1A4: BF8903F7
	v_cvt_f32_f16_e32 v7, v7                                   // 00000029A1A8: 7E0E1707
	s_or_b32 exec_lo, exec_lo, s1                              // 00000029A1AC: 8C7E017E
	v_dual_mov_b32 v8, 0 :: v_dual_add_nc_u32 v11, 0xe0, v25   // 00000029A1B0: CA200080 080A32FF 000000E0
	s_mov_b32 s1, exec_lo                                      // 00000029A1BC: BE81007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000029A1C0: BF870001
	.long 0xd4c1007e                                           // 00000029A1C4: D4C1007E
	v_cndmask_b32_e32 v1, v11, v24, vcc_lo                     // 00000029A1C8: 0202310B
	s_cbranch_execz 11                                         // 00000029A1CC: BFA5000B <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi32ELi2ELi1EEEvNS0_5LqGrpEPKtl+0x4fc>
	v_lshlrev_b32_e32 v8, 1, v11                               // 00000029A1D0: 30101681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000029A1D4: BF8700A1
	v_ashrrev_i32_e32 v12, 31, v8                              // 00000029A1D8: 3418109F
	.long 0xd7006a0b                                           // 00000029A1DC: D7006A0B
	v_cndmask_b32_e32 v1, v17, v8, vcc_lo                      // 00000029A1E0: 02021111
	v_add_co_ci_u32_e64 v12, null, v26, v12, vcc_lo            // 00000029A1E4: D5207C0C 01AA191A
	global_load_d16_b16 v8, v[11:12], off                      // 00000029A1EC: DC820000 087C000B
	s_waitcnt vmcnt(0)                                         // 00000029A1F4: BF8903F7
	v_cvt_f32_f16_e32 v8, v8                                   // 00000029A1F8: 7E101708
	s_or_b32 exec_lo, exec_lo, s1                              // 00000029A1FC: 8C7E017E
	s_branch 9                                                 // 00000029A200: BFA00009 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi32ELi2ELi1EEEvNS0_5LqGrpEPKtl+0x528>
	v_mov_b32_e32 v1, 0                                        // 00000029A204: 7E020280
	s_delay_alu instid0(VALU_DEP_1)                            // 00000029A208: BF870001
	v_mov_b32_e32 v2, v1                                       // 00000029A20C: 7E040301
	v_mov_b32_e32 v3, v1                                       // 00000029A210: 7E060301
	v_mov_b32_e32 v4, v1                                       // 00000029A214: 7E080301
	v_mov_b32_e32 v5, v1                                       // 00000029A218: 7E0A0301
	v_mov_b32_e32 v6, v1                                       // 00000029A21C: 7E0C0301
	v_mov_b32_e32 v7, v1                                       // 00000029A220: 7E0E0301
	v_mov_b32_e32 v8, v1                                       // 00000029A224: 7E100301
	s_add_u32 s4, s18, s4                                      // 00000029A228: 80040412
	s_addc_u32 s5, s19, s5                                     // 00000029A22C: 82050513
	s_lshr_b32 s1, s15, 31                                     // 00000029A230: 85019F0F
	v_mov_b32_e32 v27, 0                                       // 00000029A234: 7E360280
	s_add_u32 s8, s14, s1                                      // 00000029A238: 8008010E
	s_addc_u32 s9, s15, 0                                      // 00000029A23C: 8209800F
	.long 0xd4410001                                           // 00000029A240: D4410001
	v_cndmask_b32_e32 v1, v25, v24, vcc_lo                     // 00000029A244: 02023119
	s_ashr_i64 s[8:9], s[8:9], 1                               // 00000029A248: 86888108
	v_cndmask_b32_e64 v28, 0, 1, s6                            // 00000029A24C: D501001C 00190280
	v_mad_u64_u32 v[18:19], null, v10, s8, s[4:5]              // 00000029A254: D6FE7C12 0010110A
	.long 0xd72c000c                                           // 00000029A25C: D72C000C
	v_cndmask_b32_e32 v0, v10, v9, vcc_lo                      // 00000029A260: 0200130A
	.long 0xd72c000e                                           // 00000029A264: D72C000E
	v_cndmask_b32_e32 v0, v9, v8, vcc_lo                       // 00000029A268: 02001109
	v_dual_mov_b32 v9, 0 :: v_dual_mov_b32 v10, 0              // 00000029A26C: CA100080 090A0080
	v_mov_b32_e32 v35, 0                                       // 00000029A274: 7E460280
	v_mov_b32_e32 v11, 0                                       // 00000029A278: 7E160280
	s_delay_alu instid0(VALU_DEP_4)                            // 00000029A27C: BF870004
	v_add3_u32 v29, v14, v19, v12                              // 00000029A280: D655001D 0432270E
	v_mov_b32_e32 v12, 0                                       // 00000029A288: 7E180280
	s_and_saveexec_b32 s4, s1                                  // 00000029A28C: BE842001
	s_cbranch_execz 22                                         // 00000029A290: BFA50016 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi32ELi2ELi1EEEvNS0_5LqGrpEPKtl+0x5ec>
	v_lshlrev_b32_e32 v9, 4, v25                               // 00000029A294: 30123284
	v_mov_b32_e32 v35, 0                                       // 00000029A298: 7E460280
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000029A29C: BF8700A2
	v_ashrrev_i32_e32 v10, 31, v9                              // 00000029A2A0: 3414129F
	.long 0xd7006a09                                           // 00000029A2A4: D7006A09
	v_cndmask_b32_e32 v1, v18, v9, vcc_lo                      // 00000029A2A8: 02021312
	v_add_co_ci_u32_e64 v10, null, v29, v10, vcc_lo            // 00000029A2AC: D5207C0A 01AA151D
	s_and_not1_b32 vcc_lo, exec_lo, s6                         // 00000029A2B4: 916A067E
	global_load_b128 v[9:12], v[9:10], off                     // 00000029A2B8: DC5E0000 097C0009
	s_cbranch_vccnz 10                                         // 00000029A2C0: BFA4000A <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi32ELi2ELi1EEEvNS0_5LqGrpEPKtl+0x5ec>
	v_lshlrev_b32_e32 v14, 1, v25                              // 00000029A2C4: 301C3281
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029A2C8: BF870091
	.long 0xd7006a0e                                           // 00000029A2CC: D7006A0E
	v_cndmask_b32_e32 v1, v17, v14, vcc_lo                     // 00000029A2D0: 02021D11
	v_add_co_ci_u32_e64 v15, null, 0, v26, vcc_lo              // 00000029A2D4: D5207C0F 01AA3480
	global_load_d16_b16 v14, v[14:15], off                     // 00000029A2DC: DC820000 0E7C000E
	s_waitcnt vmcnt(0)                                         // 00000029A2E4: BF8903F7
	v_cvt_f32_f16_e32 v35, v14                                 // 00000029A2E8: 7E46170E
	s_or_b32 exec_lo, exec_lo, s4                              // 00000029A2EC: 8C7E047E
	v_dual_mov_b32 v31, 0 :: v_dual_mov_b32 v30, 0             // 00000029A2F0: CA100080 1F1E0080
	s_and_saveexec_b32 s8, s1                                  // 00000029A2F8: BE882001
	s_cbranch_execz 340                                        // 00000029A2FC: BFA50154 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi32ELi2ELi1EEEvNS0_5LqGrpEPKtl+0xb50>
	v_dual_mov_b32 v31, 0 :: v_dual_lshlrev_b32 v14, 5, v23    // 00000029A300: CA220080 1F0E2E85
	v_dual_mov_b32 v30, 0 :: v_dual_add_nc_u32 v15, 32, v25    // 00000029A308: CA200080 1E0E32A0
	s_lshl_b64 s[4:5], s[14:15], 2                             // 00000029A310: 8484820E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000029A314: BF870112
	v_lshl_add_u32 v19, v13, 5, v14                            // 00000029A318: D6460013 04390B0D
	v_dual_mov_b32 v27, 0 :: v_dual_lshlrev_b32 v32, 4, v15    // 00000029A320: CA220080 1B201E84
	v_dual_mov_b32 v34, v35 :: v_dual_lshlrev_b32 v33, 1, v15  // 00000029A328: CA220123 22201E81
	s_mov_b32 s9, 0                                            // 00000029A330: BE890080
	s_lshl_b64 s[6:7], s[14:15], 1                             // 00000029A334: 8486810E
	s_branch 289                                               // 00000029A338: BFA00121 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi32ELi2ELi1EEEvNS0_5LqGrpEPKtl+0xac0>
	s_or_b32 exec_lo, exec_lo, s14                             // 00000029A33C: 8C7E0E7E
	v_ashrrev_i32_e32 v20, 31, v19                             // 00000029A340: 3428269F
	v_cndmask_b32_e64 v84, v35, v1, s0                         // 00000029A344: D5010054 00020323
	v_lshrrev_b32_e32 v35, 6, v9                               // 00000029A34C: 32461286
	v_lshrrev_b32_e32 v85, 14, v9                              // 00000029A350: 32AA128E
	v_and_b32_e32 v86, 0xff, v10                               // 00000029A354: 36AC14FF 000000FF
	.long 0xd73c0024                                           // 00000029A35C: D73C0024
	v_cndmask_b32_e32 v1, 1, v19, vcc_lo                       // 00000029A360: 02022681
	v_and_b32_e32 v20, 0xff, v9                                // 00000029A364: 362812FF 000000FF
	v_and_b32_e32 v35, 0x3fc, v35                              // 00000029A36C: 364646FF 000003FC
	v_and_b32_e32 v85, 0x3fc, v85                              // 00000029A374: 36AAAAFF 000003FC
	v_lshrrev_b32_e32 v9, 22, v9                               // 00000029A37C: 32121296
	v_lshrrev_b32_e32 v87, 6, v10                              // 00000029A380: 32AE1486
	.long 0xd7006a48                                           // 00000029A384: D7006A48
	v_cndmask_b32_e32 v1, s12, v36, vcc_lo                     // 00000029A388: 0202480C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000029A38C: BF8701A1
	v_add_co_ci_u32_e64 v73, null, s13, v37, vcc_lo            // 00000029A390: D5207C49 01AA4A0D
	v_lshlrev_b32_e32 v20, 2, v20                              // 00000029A398: 30282882
	.long 0xd7006a4c                                           // 00000029A39C: D7006A4C
	v_cndmask_b32_e32 v0, v72, v6, vcc_lo                      // 00000029A3A0: 02000D48
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000029A3A4: BF8700A1
	v_add_co_ci_u32_e64 v77, null, s7, v73, vcc_lo             // 00000029A3A8: D5207C4D 01AA9207
	.long 0xd7006a50                                           // 00000029A3B0: D7006A50
	v_cndmask_b32_e32 v0, v72, v4, vcc_lo                      // 00000029A3B4: 02000948
	v_add_co_ci_u32_e64 v81, null, s5, v73, vcc_lo             // 00000029A3B8: D5207C51 01AA9205
	s_clause 0xb                                               // 00000029A3C0: BF85000B
	global_load_b128 v[36:39], v[72:73], off                   // 00000029A3C4: DC5E0000 247C0048
	global_load_b128 v[40:43], v[76:77], off                   // 00000029A3CC: DC5E0000 287C004C
	global_load_b128 v[44:47], v[80:81], off                   // 00000029A3D4: DC5E0000 2C7C0050
	global_load_b128 v[48:51], v[72:73], off offset:16         // 00000029A3DC: DC5E0010 307C0048
	global_load_b128 v[52:55], v[76:77], off offset:16         // 00000029A3E4: DC5E0010 347C004C
	global_load_b128 v[56:59], v[80:81], off offset:16         // 00000029A3EC: DC5E0010 387C0050
	global_load_b128 v[60:63], v[72:73], off offset:32         // 00000029A3F4: DC5E0020 3C7C0048
	global_load_b128 v[64:67], v[76:77], off offset:32         // 00000029A3FC: DC5E0020 407C004C
	global_load_b128 v[68:71], v[80:81], off offset:32         // 00000029A404: DC5E0020 447C0050
	global_load_b128 v[72:75], v[72:73], off offset:48         // 00000029A40C: DC5E0030 487C0048
	global_load_b128 v[76:79], v[76:77], off offset:48         // 00000029A414: DC5E0030 4C7C004C
	global_load_b128 v[80:83], v[80:81], off offset:48         // 00000029A41C: DC5E0030 507C0050
	ds_load_b32 v20, v20                                       // 00000029A424: D8D80000 14000014
	ds_load_b32 v35, v35                                       // 00000029A42C: D8D80000 23000023
	ds_load_b32 v85, v85                                       // 00000029A434: D8D80000 55000055
	v_lshrrev_b32_e32 v88, 14, v10                             // 00000029A43C: 32B0148E
	v_lshrrev_b32_e32 v10, 22, v10                             // 00000029A440: 32141496
	v_lshlrev_b32_e32 v86, 2, v86                              // 00000029A444: 30ACAC82
	v_and_b32_e32 v87, 0x3fc, v87                              // 00000029A448: 36AEAEFF 000003FC
	v_and_b32_e32 v89, 0xff, v11                               // 00000029A450: 36B216FF 000000FF
	v_and_b32_e32 v88, 0x3fc, v88                              // 00000029A458: 36B0B0FF 000003FC
	v_lshrrev_b32_e32 v90, 6, v11                              // 00000029A460: 32B41686
	v_lshrrev_b32_e32 v91, 14, v11                             // 00000029A464: 32B6168E
	v_lshrrev_b32_e32 v11, 22, v11                             // 00000029A468: 32161696
	v_lshrrev_b32_e32 v93, 14, v12                             // 00000029A46C: 32BA188E
	v_add_nc_u32_e32 v33, 64, v33                              // 00000029A470: 4A4242C0
	v_add_nc_u32_e32 v19, 0x400, v19                           // 00000029A474: 4A2626FF 00000400
	s_and_b32 s1, exec_lo, s1                                  // 00000029A47C: 8B01017E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000029A480: BF870009
	s_or_b32 s9, s1, s9                                        // 00000029A484: 8C090901
	s_waitcnt vmcnt(11) lgkmcnt(2)                             // 00000029A488: BF892C27
	v_dot2_f32_bf16 v36, v36, v20, 0                           // 00000029A48C: CC1A4024 1A022924
	s_waitcnt vmcnt(10)                                        // 00000029A494: BF892BF7
	v_dot2_f32_bf16 v40, v40, v20, 0                           // 00000029A498: CC1A4028 1A022928
	s_waitcnt vmcnt(9)                                         // 00000029A4A0: BF8927F7
	v_dot2_f32_bf16 v20, v44, v20, 0                           // 00000029A4A4: CC1A4014 1A02292C
	v_lshrrev_b32_e32 v44, 6, v12                              // 00000029A4AC: 32581886
	s_waitcnt lgkmcnt(1)                                       // 00000029A4B0: BF89FC17
	v_dot2_f32_bf16 v36, v37, v35, v36                         // 00000029A4B4: CC1A4024 1C924725
	v_dot2_f32_bf16 v37, v41, v35, v40                         // 00000029A4BC: CC1A4025 1CA24729
	v_dot2_f32_bf16 v20, v45, v35, v20                         // 00000029A4C4: CC1A4014 1C52472D
	v_and_b32_e32 v40, 0x3fc, v91                              // 00000029A4CC: 3650B6FF 000003FC
	v_and_b32_e32 v41, 0x3fc, v93                              // 00000029A4D4: 3652BAFF 000003FC
	s_waitcnt lgkmcnt(0)                                       // 00000029A4DC: BF89FC07
	v_dot2_f32_bf16 v36, v38, v85, v36                         // 00000029A4E0: CC1A4024 1C92AB26
	v_dot2_f32_bf16 v37, v42, v85, v37                         // 00000029A4E8: CC1A4025 1C96AB2A
	v_cndmask_b32_e64 v42, v7, v8, s0                          // 00000029A4F0: D501002A 00021107
	v_and_b32_e32 v9, 0x3fc, v9                                // 00000029A4F8: 361212FF 000003FC
	v_and_b32_e32 v10, 0x3fc, v10                              // 00000029A500: 361414FF 000003FC
	ds_load_b32 v9, v9                                         // 00000029A508: D8D80000 09000009
	ds_load_b32 v86, v86                                       // 00000029A510: D8D80000 56000056
	ds_load_b32 v87, v87                                       // 00000029A518: D8D80000 57000057
	ds_load_b32 v88, v88                                       // 00000029A520: D8D80000 58000058
	ds_load_b32 v10, v10                                       // 00000029A528: D8D80000 0A00000A
	v_dot2_f32_bf16 v20, v46, v85, v20                         // 00000029A530: CC1A4014 1C52AB2E
	v_lshlrev_b32_e32 v35, 2, v89                              // 00000029A538: 3046B282
	v_and_b32_e32 v38, 0x3fc, v90                              // 00000029A53C: 364CB4FF 000003FC
	ds_load_b32 v35, v35                                       // 00000029A544: D8D80000 23000023
	ds_load_b32 v38, v38                                       // 00000029A54C: D8D80000 26000026
	s_waitcnt lgkmcnt(6)                                       // 00000029A554: BF89FC67
	v_dot2_f32_bf16 v36, v39, v9, v36                          // 00000029A558: CC1A4024 1C921327
	v_dot2_f32_bf16 v37, v43, v9, v37                          // 00000029A560: CC1A4025 1C96132B
	v_dot2_f32_bf16 v9, v47, v9, v20                           // 00000029A568: CC1A4009 1C52132F
	ds_load_b32 v43, v40                                       // 00000029A570: D8D80000 2B000028
	v_and_b32_e32 v92, 0xff, v12                               // 00000029A578: 36B818FF 000000FF
	s_waitcnt vmcnt(8) lgkmcnt(6)                              // 00000029A580: BF892067
	v_dot2_f32_bf16 v36, v48, v86, v36                         // 00000029A584: CC1A4024 1C92AD30
	s_waitcnt vmcnt(7)                                         // 00000029A58C: BF891FF7
	v_dot2_f32_bf16 v37, v52, v86, v37                         // 00000029A590: CC1A4025 1C96AD34
	s_waitcnt vmcnt(6)                                         // 00000029A598: BF891BF7
	v_dot2_f32_bf16 v9, v56, v86, v9                           // 00000029A59C: CC1A4009 1C26AD38
	v_lshrrev_b32_e32 v12, 22, v12                             // 00000029A5A4: 32181896
	v_cndmask_b32_e64 v40, v5, v6, s0                          // 00000029A5A8: D5010028 00020D05
	s_waitcnt lgkmcnt(5)                                       // 00000029A5B0: BF89FC57
	v_dot2_f32_bf16 v36, v49, v87, v36                         // 00000029A5B4: CC1A4024 1C92AF31
	v_dot2_f32_bf16 v37, v53, v87, v37                         // 00000029A5BC: CC1A4025 1C96AF35
	v_dot2_f32_bf16 v9, v57, v87, v9                           // 00000029A5C4: CC1A4009 1C26AF39
	v_and_b32_e32 v11, 0x3fc, v11                              // 00000029A5CC: 361616FF 000003FC
	v_lshlrev_b32_e32 v20, 2, v92                              // 00000029A5D4: 3028B882
	s_waitcnt lgkmcnt(4)                                       // 00000029A5D8: BF89FC47
	v_dot2_f32_bf16 v36, v50, v88, v36                         // 00000029A5DC: CC1A4024 1C92B132
	v_dot2_f32_bf16 v37, v54, v88, v37                         // 00000029A5E4: CC1A4025 1C96B136
	v_dot2_f32_bf16 v9, v58, v88, v9                           // 00000029A5EC: CC1A4009 1C26B13A
	v_and_b32_e32 v39, 0x3fc, v44                              // 00000029A5F4: 364E58FF 000003FC
	v_and_b32_e32 v12, 0x3fc, v12                              // 00000029A5FC: 361818FF 000003FC
	s_waitcnt lgkmcnt(3)                                       // 00000029A604: BF89FC37
	v_dot2_f32_bf16 v36, v51, v10, v36                         // 00000029A608: CC1A4024 1C921533
	v_dot2_f32_bf16 v37, v55, v10, v37                         // 00000029A610: CC1A4025 1C961537
	v_dot2_f32_bf16 v9, v59, v10, v9                           // 00000029A618: CC1A4009 1C26153B
	ds_load_b32 v10, v11                                       // 00000029A620: D8D80000 0A00000B
	ds_load_b32 v11, v20                                       // 00000029A628: D8D80000 0B000014
	ds_load_b32 v20, v39                                       // 00000029A630: D8D80000 14000027
	ds_load_b32 v44, v41                                       // 00000029A638: D8D80000 2C000029
	ds_load_b32 v45, v12                                       // 00000029A640: D8D80000 2D00000C
	v_cndmask_b32_e64 v41, v6, v7, s0                          // 00000029A648: D5010029 00020F06
	s_waitcnt vmcnt(5) lgkmcnt(7)                              // 00000029A650: BF891477
	v_dot2_f32_bf16 v12, v60, v35, v36                         // 00000029A654: CC1A400C 1C92473C
	s_waitcnt vmcnt(4)                                         // 00000029A65C: BF8913F7
	v_dot2_f32_bf16 v36, v64, v35, v37                         // 00000029A660: CC1A4024 1C964740
	s_waitcnt vmcnt(3)                                         // 00000029A668: BF890FF7
	v_dot2_f32_bf16 v9, v68, v35, v9                           // 00000029A66C: CC1A4009 1C264744
	v_cndmask_b32_e64 v39, v4, v5, s0                          // 00000029A674: D5010027 00020B04
	v_cndmask_b32_e64 v37, v2, v3, s0                          // 00000029A67C: D5010025 00020702
	s_waitcnt lgkmcnt(6)                                       // 00000029A684: BF89FC67
	v_dot2_f32_bf16 v7, v61, v38, v12                          // 00000029A688: CC1A4007 1C324D3D
	v_dot2_f32_bf16 v12, v65, v38, v36                         // 00000029A690: CC1A400C 1C924D41
	v_dot2_f32_bf16 v9, v69, v38, v9                           // 00000029A698: CC1A4009 1C264D45
	v_cndmask_b32_e64 v38, v3, v4, s0                          // 00000029A6A0: D5010026 00020903
	v_cndmask_b32_e64 v36, v1, v2, s0                          // 00000029A6A8: D5010024 00020501
	s_waitcnt lgkmcnt(5)                                       // 00000029A6B0: BF89FC57
	v_dot2_f32_bf16 v5, v62, v43, v7                           // 00000029A6B4: CC1A4005 1C1E573E
	v_dot2_f32_bf16 v6, v66, v43, v12                          // 00000029A6BC: CC1A4006 1C325742
	v_dot2_f32_bf16 v7, v70, v43, v9                           // 00000029A6C4: CC1A4007 1C265746
	v_dual_mov_b32 v43, v8 :: v_dual_add_nc_u32 v32, 0x200, v32// 00000029A6CC: CA200108 2B2040FF 00000200
	s_waitcnt lgkmcnt(4)                                       // 00000029A6D8: BF89FC47
	v_dot2_f32_bf16 v3, v63, v10, v5                           // 00000029A6DC: CC1A4003 1C16153F
	v_dot2_f32_bf16 v4, v67, v10, v6                           // 00000029A6E4: CC1A4004 1C1A1543
	v_dot2_f32_bf16 v5, v71, v10, v7                           // 00000029A6EC: CC1A4005 1C1E1547
	v_mov_b32_e32 v12, v16                                     // 00000029A6F4: 7E180310
	v_mov_b32_e32 v10, v14                                     // 00000029A6F8: 7E14030E
	s_waitcnt vmcnt(2) lgkmcnt(3)                              // 00000029A6FC: BF890837
	v_dot2_f32_bf16 v1, v72, v11, v3                           // 00000029A700: CC1A4001 1C0E1748
	s_waitcnt vmcnt(1)                                         // 00000029A708: BF8907F7
	v_dot2_f32_bf16 v2, v76, v11, v4                           // 00000029A70C: CC1A4002 1C12174C
	s_waitcnt vmcnt(0)                                         // 00000029A714: BF8903F7
	v_dot2_f32_bf16 v3, v80, v11, v5                           // 00000029A718: CC1A4003 1C161750
	v_mov_b32_e32 v11, v15                                     // 00000029A720: 7E16030F
	v_mov_b32_e32 v9, v13                                      // 00000029A724: 7E12030D
	s_waitcnt lgkmcnt(2)                                       // 00000029A728: BF89FC27
	v_dot2_f32_bf16 v1, v73, v20, v1                           // 00000029A72C: CC1A4001 1C062949
	v_dot2_f32_bf16 v2, v77, v20, v2                           // 00000029A734: CC1A4002 1C0A294D
	v_dot2_f32_bf16 v3, v81, v20, v3                           // 00000029A73C: CC1A4003 1C0E2951
	v_mov_b32_e32 v35, v34                                     // 00000029A744: 7E460322
	s_waitcnt lgkmcnt(1)                                       // 00000029A748: BF89FC17
	v_dot2_f32_bf16 v1, v74, v44, v1                           // 00000029A74C: CC1A4001 1C06594A
	v_dot2_f32_bf16 v2, v78, v44, v2                           // 00000029A754: CC1A4002 1C0A594E
	v_dot2_f32_bf16 v3, v82, v44, v3                           // 00000029A75C: CC1A4003 1C0E5952
	s_waitcnt lgkmcnt(0)                                       // 00000029A764: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000029A768: BF870193
	v_dot2_f32_bf16 v1, v75, v45, v1                           // 00000029A76C: CC1A4001 1C065B4B
	v_dot2_f32_bf16 v2, v79, v45, v2                           // 00000029A774: CC1A4002 1C0A5B4F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000029A77C: BF870193
	v_dot2_f32_bf16 v3, v83, v45, v3                           // 00000029A780: CC1A4003 1C0E5B53
	v_fmac_f32_e32 v30, v84, v1                                // 00000029A788: 563C0354
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000029A78C: BF870193
	v_fmac_f32_e32 v31, v84, v2                                // 00000029A790: 563E0554
	v_fmac_f32_e32 v27, v84, v3                                // 00000029A794: 56360754
	v_dual_mov_b32 v1, v36 :: v_dual_mov_b32 v2, v37           // 00000029A798: CA100124 01020125
	v_dual_mov_b32 v3, v38 :: v_dual_mov_b32 v4, v39           // 00000029A7A0: CA100126 03040127
	v_dual_mov_b32 v5, v40 :: v_dual_mov_b32 v6, v41           // 00000029A7A8: CA100128 05060129
	v_dual_mov_b32 v7, v42 :: v_dual_mov_b32 v8, v43           // 00000029A7B0: CA10012A 0708012B
	s_and_not1_b32 exec_lo, exec_lo, s9                        // 00000029A7B8: 917E097E
	s_cbranch_execz 35                                         // 00000029A7BC: BFA50023 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi32ELi2ELi1EEEvNS0_5LqGrpEPKtl+0xb4c>
	s_waitcnt vmcnt(0)                                         // 00000029A7C0: BF8903F7
	v_dual_mov_b32 v14, v10 :: v_dual_add_nc_u32 v25, 32, v25  // 00000029A7C4: CA20010A 0E1832A0
	v_dual_mov_b32 v13, v9 :: v_dual_mov_b32 v16, v12          // 00000029A7CC: CA100109 0D10010C
	v_mov_b32_e32 v15, v11                                     // 00000029A7D4: 7E1E030B
	s_delay_alu instid0(VALU_DEP_3)                            // 00000029A7D8: BF870003
	.long 0xd4460001                                           // 00000029A7DC: D4460001
	v_cndmask_b32_e32 v1, v25, v24, vcc_lo                     // 00000029A7E0: 02023119
	s_mov_b32 s14, exec_lo                                     // 00000029A7E4: BE8E007E
	.long 0xd4c1007e                                           // 00000029A7E8: D4C1007E
	v_cndmask_b32_e32 v1, v25, v24, vcc_lo                     // 00000029A7EC: 02023119
	s_cbranch_execz 65234                                      // 00000029A7F0: BFA5FED2 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi32ELi2ELi1EEEvNS0_5LqGrpEPKtl+0x63c>
	v_ashrrev_i32_e32 v14, 31, v32                             // 00000029A7F4: 341C409F
	.long 0xd7006a0d                                           // 00000029A7F8: D7006A0D
	v_cndmask_b32_e32 v1, v18, v32, vcc_lo                     // 00000029A7FC: 02024112
	v_mov_b32_e32 v34, v35                                     // 00000029A800: 7E440323
	s_delay_alu instid0(VALU_DEP_3)                            // 00000029A804: BF870003
	v_add_co_ci_u32_e64 v14, null, v29, v14, vcc_lo            // 00000029A808: D5207C0E 01AA1D1D
	v_cmp_ne_u32_e32 vcc_lo, 1, v28                            // 00000029A810: 7C9A3881
	global_load_b128 v[13:16], v[13:14], off                   // 00000029A814: DC5E0000 0D7C000D
	s_cbranch_vccnz 65223                                      // 00000029A81C: BFA4FEC7 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi32ELi2ELi1EEEvNS0_5LqGrpEPKtl+0x63c>
	v_ashrrev_i32_e32 v20, 31, v33                             // 00000029A820: 3428429F
	.long 0xd7006a24                                           // 00000029A824: D7006A24
	v_cndmask_b32_e32 v1, v17, v33, vcc_lo                     // 00000029A828: 02024311
	s_delay_alu instid0(VALU_DEP_1)                            // 00000029A82C: BF870001
	v_add_co_ci_u32_e64 v37, null, v26, v20, vcc_lo            // 00000029A830: D5207C25 01AA291A
	global_load_d16_b16 v20, v[36:37], off                     // 00000029A838: DC820000 147C0024
	s_waitcnt vmcnt(0)                                         // 00000029A840: BF8903F7
	v_cvt_f32_f16_e32 v34, v20                                 // 00000029A844: 7E441714
	s_branch 65212                                             // 00000029A848: BFA0FEBC <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi32ELi2ELi1EEEvNS0_5LqGrpEPKtl+0x63c>
	s_or_b32 exec_lo, exec_lo, s9                              // 00000029A84C: 8C7E097E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000029A850: BF8700B9
	s_or_b32 exec_lo, exec_lo, s8                              // 00000029A854: 8C7E087E
	.long 0xd71f0001                                           // 00000029A858: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 00000029A85C: 020100C1
	s_mov_b32 s0, exec_lo                                      // 00000029A860: BE80007E
	v_xor_b32_e32 v2, 16, v1                                   // 00000029A864: 3A040290
	v_xor_b32_e32 v5, 8, v1                                    // 00000029A868: 3A0A0288
	v_xor_b32_e32 v8, 4, v1                                    // 00000029A86C: 3A100284
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000029A870: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 00000029A874: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 00000029A878: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v5                            // 00000029A87C: 7C980AA0
	v_cndmask_b32_e32 v5, v1, v5, vcc_lo                       // 00000029A880: 020A0B01
	v_cmp_gt_u32_e32 vcc_lo, 32, v8                            // 00000029A884: 7C9810A0
	s_delay_alu instid0(VALU_DEP_2)                            // 00000029A888: BF870002
	v_lshlrev_b32_e32 v5, 2, v5                                // 00000029A88C: 300A0A82
	v_lshlrev_b32_e32 v2, 2, v2                                // 00000029A890: 30040482
	ds_bpermute_b32 v3, v2, v30                                // 00000029A894: DACC0000 03001E02
	s_waitcnt lgkmcnt(0)                                       // 00000029A89C: BF89FC07
	v_add_f32_e32 v3, v30, v3                                  // 00000029A8A0: 0606071E
	ds_bpermute_b32 v4, v2, v31                                // 00000029A8A4: DACC0000 04001F02
	ds_bpermute_b32 v2, v2, v27                                // 00000029A8AC: DACC0000 02001B02
	ds_bpermute_b32 v6, v5, v3                                 // 00000029A8B4: DACC0000 06000305
	v_cndmask_b32_e32 v8, v1, v8, vcc_lo                       // 00000029A8BC: 02101101
	s_waitcnt lgkmcnt(2)                                       // 00000029A8C0: BF89FC27
	v_add_f32_e32 v4, v31, v4                                  // 00000029A8C4: 0608091F
	s_waitcnt lgkmcnt(1)                                       // 00000029A8C8: BF89FC17
	v_add_f32_e32 v2, v27, v2                                  // 00000029A8CC: 0604051B
	s_waitcnt lgkmcnt(0)                                       // 00000029A8D0: BF89FC07
	v_add_f32_e32 v3, v3, v6                                   // 00000029A8D4: 06060D03
	ds_bpermute_b32 v7, v5, v4                                 // 00000029A8D8: DACC0000 07000405
	ds_bpermute_b32 v5, v5, v2                                 // 00000029A8E0: DACC0000 05000205
	v_lshlrev_b32_e32 v8, 2, v8                                // 00000029A8E8: 30101082
	s_waitcnt lgkmcnt(0)                                       // 00000029A8EC: BF89FC07
	v_add_f32_e32 v2, v2, v5                                   // 00000029A8F0: 06040B02
	ds_bpermute_b32 v5, v8, v3                                 // 00000029A8F4: DACC0000 05000308
	s_waitcnt lgkmcnt(0)                                       // 00000029A8FC: BF89FC07
	v_dual_add_f32 v3, v3, v5 :: v_dual_add_f32 v4, v4, v7     // 00000029A900: C9080B03 03040F04
	ds_bpermute_b32 v7, v8, v2                                 // 00000029A908: DACC0000 07000208
	ds_bpermute_b32 v6, v8, v4                                 // 00000029A910: DACC0000 06000408
	v_xor_b32_e32 v8, 2, v1                                    // 00000029A918: 3A100282
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000029A91C: BF8700A1
	v_cmp_gt_u32_e32 vcc_lo, 32, v8                            // 00000029A920: 7C9810A0
	v_cndmask_b32_e32 v8, v1, v8, vcc_lo                       // 00000029A924: 02101101
	v_lshlrev_b32_e32 v8, 2, v8                                // 00000029A928: 30101082
	s_waitcnt lgkmcnt(1)                                       // 00000029A92C: BF89FC17
	v_add_f32_e32 v2, v2, v7                                   // 00000029A930: 06040F02
	s_waitcnt lgkmcnt(0)                                       // 00000029A934: BF89FC07
	v_add_f32_e32 v4, v4, v6                                   // 00000029A938: 06080D04
	ds_bpermute_b32 v5, v8, v3                                 // 00000029A93C: DACC0000 05000308
	ds_bpermute_b32 v7, v8, v2                                 // 00000029A944: DACC0000 07000208
	ds_bpermute_b32 v6, v8, v4                                 // 00000029A94C: DACC0000 06000408
	v_xor_b32_e32 v8, 1, v1                                    // 00000029A954: 3A100281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000029A958: BF8700A1
	v_cmp_gt_u32_e32 vcc_lo, 32, v8                            // 00000029A95C: 7C9810A0
	v_cndmask_b32_e32 v1, v1, v8, vcc_lo                       // 00000029A960: 02021101
	v_lshlrev_b32_e32 v8, 2, v1                                // 00000029A964: 30100282
	s_waitcnt lgkmcnt(1)                                       // 00000029A968: BF89FC17
	v_dual_add_f32 v1, v3, v5 :: v_dual_add_f32 v2, v2, v7     // 00000029A96C: C9080B03 01020F02
	s_waitcnt lgkmcnt(0)                                       // 00000029A974: BF89FC07
	v_add_f32_e32 v3, v4, v6                                   // 00000029A978: 06060D04
	ds_bpermute_b32 v4, v8, v1                                 // 00000029A97C: DACC0000 04000108
	ds_bpermute_b32 v5, v8, v2                                 // 00000029A984: DACC0000 05000208
	ds_bpermute_b32 v6, v8, v3                                 // 00000029A98C: DACC0000 06000308
	v_cmpx_eq_u32_e32 0, v23                                   // 00000029A994: 7D942E80
	s_cbranch_execz 14                                         // 00000029A998: BFA5000E <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi32ELi2ELi1EEEvNS0_5LqGrpEPKtl+0xcd4>
	v_lshl_add_u32 v7, v21, s21, v22                           // 00000029A99C: D6460007 04582B15
	s_waitcnt lgkmcnt(0)                                       // 00000029A9A4: BF89FC07
	v_dual_add_f32 v3, v3, v6 :: v_dual_add_f32 v2, v2, v5     // 00000029A9A8: C9080D03 03020B02
	v_add_f32_e32 v1, v1, v4                                   // 00000029A9B0: 06020901
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029A9B4: BF870093
	v_mul_u32_u24_e32 v7, 12, v7                               // 00000029A9B8: 160E0E8C
	v_or_b32_e32 v4, 0x400, v7                                 // 00000029A9BC: 38080EFF 00000400
	ds_store_2addr_b32 v4, v1, v3 offset1:1                    // 00000029A9C4: D8380100 00030104
	ds_store_b32 v7, v2 offset:1032                            // 00000029A9CC: D8340408 00000207
	s_or_b32 exec_lo, exec_lo, s0                              // 00000029A9D4: 8C7E007E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000029A9D8: BF870009
	s_and_b32 s0, s20, exec_lo                                 // 00000029A9DC: 8B007E14
	s_cselect_b32 s0, 3, 12                                    // 00000029A9E0: 98008C83
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000029A9E4: BF890007
	v_cmp_gt_u32_e32 vcc_lo, s0, v0                            // 00000029A9E8: 7C980000
	s_barrier                                                  // 00000029A9EC: BFBD0000
	buffer_gl0_inv                                             // 00000029A9F0: E0AC0000 00000000
	s_and_saveexec_b32 s0, vcc_lo                              // 00000029A9F8: BE80206A
	s_cbranch_execz 413                                        // 00000029A9FC: BFA5019D <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi32ELi2ELi1EEEvNS0_5LqGrpEPKtl+0x1374>
	s_load_b32 s0, s[16:17], 0x40                              // 00000029AA00: F4000008 F8000040
	.long 0xd7054000                                           // 00000029AA08: D7054000
	v_cndmask_b32_e32 v1, 0xab, v0, vcc_lo                     // 00000029AA0C: 020200FF 000000AB
	.long 0x7f063880                                           // 00000029AA14: 7F063880
	v_mov_b32_e32 v4, 0                                        // 00000029AA18: 7E080280
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 00000029AA1C: BF8704B3
	.long 0xd7391003                                           // 00000029AA20: D7391003
	v_cndmask_b32_e32 v1, 9, v0, vcc_lo                        // 00000029AA24: 02020089
	s_waitcnt lgkmcnt(0)                                       // 00000029AA28: BF89FC07
	s_sub_i32 s0, s2, s0                                       // 00000029AA2C: 81800002
	s_ashr_i32 s1, s0, 31                                      // 00000029AA30: 86019F00
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000029AA34: BF870499
	s_lshl_b64 s[0:1], s[0:1], s22                             // 00000029AA38: 84801600
	.long 0xd7000001                                           // 00000029AA3C: D7000001
	v_cndmask_b32_e32 v1, s0, v3, vcc_lo                       // 00000029AA40: 02020600
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029AA44: BF870091
	v_add_co_ci_u32_e64 v2, null, s1, 0, s0                    // 00000029AA48: D5207C02 00010001
	v_cmp_gt_i64_e32 vcc_lo, s[10:11], v[1:2]                  // 00000029AA50: 7CA8020A
	s_and_b32 exec_lo, exec_lo, vcc_lo                         // 00000029AA54: 8B7E6A7E
	s_cbranch_execz 390                                        // 00000029AA58: BFA50186 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi32ELi2ELi1EEEvNS0_5LqGrpEPKtl+0x1374>
	.long 0xd7054000                                           // 00000029AA5C: D7054000
	v_cndmask_b32_e32 v0, v3, v131, vcc_lo                     // 00000029AA60: 02010703
	v_lshlrev_b32_e32 v3, s21, v3                              // 00000029AA64: 30060615
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000029AA68: BF870112
	.long 0xd7041000                                           // 00000029AA6C: D7041000
	v_cndmask_b32_e32 v1, v0, v0, vcc_lo                       // 00000029AA70: 02020100
	v_mul_u32_u24_e32 v3, 12, v3                               // 00000029AA74: 1606068C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029AA78: BF870092
	v_and_b32_e32 v5, 0xff, v0                                 // 00000029AA7C: 360A00FF 000000FF
	v_lshl_add_u32 v3, v5, 2, v3                               // 00000029AA84: D6460003 040D0505
	ds_load_b32 v5, v3 offset:1024                             // 00000029AA8C: D8D80400 05000003
	v_add_nc_u32_e32 v3, 12, v3                                // 00000029AA94: 4A06068C
	s_add_i32 s3, s3, -1                                       // 00000029AA98: 8103C103
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000029AA9C: BF870009
	s_cmp_eq_u32 s3, 0                                         // 00000029AAA0: BF068003
	s_waitcnt lgkmcnt(0)                                       // 00000029AAA4: BF89FC07
	v_add_f32_e32 v4, v4, v5                                   // 00000029AAA8: 06080B04
	s_cbranch_scc0 65527                                       // 00000029AAAC: BFA1FFF7 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi32ELi2ELi1EEEvNS0_5LqGrpEPKtl+0xd8c>
	s_clause 0x1                                               // 00000029AAB0: BF850001
	s_load_b64 s[4:5], s[16:17], 0x38                          // 00000029AAB4: F4040108 F8000038
	s_load_b64 s[2:3], s[16:17], 0x8                           // 00000029AABC: F4040088 F8000008
	v_and_b32_e32 v3, 0xff, v0                                 // 00000029AAC4: 360600FF 000000FF
	s_mov_b32 s6, -1                                           // 00000029AACC: BE8600C1
	s_mov_b32 s1, 0                                            // 00000029AAD0: BE810080
	s_mov_b32 s0, 0                                            // 00000029AAD4: BE800080
	s_waitcnt lgkmcnt(0)                                       // 00000029AAD8: BF89FC07
	s_cmp_lt_i32 s5, 3                                         // 00000029AADC: BF048305
	s_cbranch_scc1 191                                         // 00000029AAE0: BFA200BF <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi32ELi2ELi1EEEvNS0_5LqGrpEPKtl+0x10e0>
	s_cmp_gt_i32 s5, 3                                         // 00000029AAE4: BF028305
	s_cbranch_scc0 125                                         // 00000029AAE8: BFA1007D <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi32ELi2ELi1EEEvNS0_5LqGrpEPKtl+0xfe0>
	s_cmp_gt_i32 s5, 4                                         // 00000029AAEC: BF028405
	s_cbranch_scc0 70                                          // 00000029AAF0: BFA10046 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi32ELi2ELi1EEEvNS0_5LqGrpEPKtl+0xf0c>
	s_cmp_eq_u32 s5, 5                                         // 00000029AAF4: BF068505
	s_mov_b32 s0, -1                                           // 00000029AAF8: BE8000C1
	s_cbranch_scc0 66                                          // 00000029AAFC: BFA10042 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi32ELi2ELi1EEEvNS0_5LqGrpEPKtl+0xf08>
	v_lshrrev_b32_e32 v0, 23, v2                               // 00000029AB00: 32000497
	s_lshr_b32 s0, s11, 31                                     // 00000029AB04: 85009F0B
	s_load_b64 s[8:9], s[16:17], 0x10                          // 00000029AB08: F4040208 F8000010
	s_add_u32 s6, s10, s0                                      // 00000029AB10: 8006000A
	s_addc_u32 s7, s11, 0                                      // 00000029AB14: 8207800B
	.long 0xd7006a00                                           // 00000029AB18: D7006A00
	v_cndmask_b32_e32 v1, v1, v0, vcc_lo                       // 00000029AB1C: 02020101
	s_ashr_i64 s[6:7], s[6:7], 1                               // 00000029AB20: 86868106
	v_add_co_ci_u32_e64 v10, null, 0, v2, vcc_lo               // 00000029AB24: D5207C0A 01AA0480
	v_dual_mov_b32 v11, s3 :: v_dual_and_b32 v0, 0xfffffe00, v0// 00000029AB2C: CA240003 0B0000FF FFFFFE00
	v_mad_u64_u32 v[5:6], null, s6, v3, 0                      // 00000029AB38: D6FE7C05 02020606
	v_bfe_u32 v14, v4, 16, 1                                   // 00000029AB40: D610000E 02052104
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029AB48: BF870093
	.long 0xd7016a08                                           // 00000029AB4C: D7016A08
	v_cndmask_b32_e32 v1, v1, v0, vcc_lo                       // 00000029AB50: 02020101
	v_sub_co_ci_u32_e64 v9, null, v2, v10, vcc_lo              // 00000029AB54: D5217C09 01AA1502
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000029AB5C: BF870194
	v_mad_u64_u32 v[6:7], null, s7, v3, v[6:7]                 // 00000029AB60: D6FE7C06 041A0607
	.long 0xd700000c                                           // 00000029AB68: D700000C
	v_cndmask_b32_e32 v1, 0xffffff00, v8, vcc_lo               // 00000029AB6C: 020210FF FFFFFF00
	s_delay_alu instid0(VALU_DEP_3)                            // 00000029AB74: BF870003
	v_cmp_gt_i64_e32 vcc_lo, 0x100, v[8:9]                     // 00000029AB78: 7CA810FF 00000100
	v_mov_b32_e32 v7, s2                                       // 00000029AB80: 7E0E0202
	v_add_co_ci_u32_e64 v13, null, -1, v9, s0                  // 00000029AB84: D5207C0D 000212C1
	s_mov_b32 s0, 0                                            // 00000029AB8C: BE800080
	.long 0xd73c0005                                           // 00000029AB90: D73C0005
	v_cndmask_b32_e32 v1, 1, v5, vcc_lo                        // 00000029AB94: 02020A81
	s_waitcnt lgkmcnt(0)                                       // 00000029AB98: BF89FC07
	v_dual_cndmask_b32 v8, v12, v8 :: v_dual_cndmask_b32 v7, s8, v7// 00000029AB9C: CA52110C 08060E08
	v_cndmask_b32_e32 v11, s9, v11, vcc_lo                     // 00000029ABA4: 02161609
	v_cndmask_b32_e32 v9, v13, v9, vcc_lo                      // 00000029ABA8: 0212130D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029ABAC: BF870093
	.long 0xd7006a07                                           // 00000029ABB0: D7006A07
	v_cndmask_b32_e32 v1, v7, v5, vcc_lo                       // 00000029ABB4: 02020B07
	v_add_co_ci_u32_e64 v11, null, v11, v6, vcc_lo             // 00000029ABB8: D5207C0B 01AA0D0B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000029ABC0: BF870193
	.long 0xd73c0005                                           // 00000029ABC4: D73C0005
	v_cndmask_b32_e32 v1, 1, v8, vcc_lo                        // 00000029ABC8: 02021081
	.long 0xd7006a00                                           // 00000029ABCC: D7006A00
	v_cndmask_b32_e32 v1, v7, v0, vcc_lo                       // 00000029ABD0: 02020107
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000029ABD4: BF8701A1
	v_add_co_ci_u32_e64 v7, null, v11, v10, vcc_lo             // 00000029ABD8: D5207C07 01AA150B
	v_add3_u32 v8, v4, v14, 0x7fff                             // 00000029ABE0: D6550008 03FE1D04 00007FFF
	.long 0xd7006a05                                           // 00000029ABEC: D7006A05
	v_cndmask_b32_e32 v1, v0, v5, vcc_lo                       // 00000029ABF0: 02020B00
	s_delay_alu instid0(VALU_DEP_1)                            // 00000029ABF4: BF870001
	v_add_co_ci_u32_e64 v6, null, v7, v6, vcc_lo               // 00000029ABF8: D5207C06 01AA0D07
	global_store_d16_hi_b16 v[5:6], v8, off                    // 00000029AC00: DC960000 007C0805
	s_mov_b32 s6, 0                                            // 00000029AC08: BE860080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000029AC0C: BF870009
	s_and_b32 vcc_lo, exec_lo, s6                              // 00000029AC10: 8B6A067E
	s_cbranch_vccz 49                                          // 00000029AC14: BFA30031 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi32ELi2ELi1EEEvNS0_5LqGrpEPKtl+0xfdc>
	v_mul_f32_e32 v0, 0xbfb8aa3b, v4                           // 00000029AC18: 100008FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000029AC20: BF870291
	v_exp_f32_e32 v0, v0                                       // 00000029AC24: 7E004B00
	v_add_f32_e32 v0, 1.0, v0                                  // 00000029AC28: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000029AC2C: BF870121
	v_div_scale_f32 v8, null, v0, v0, 1.0                      // 00000029AC30: D6FC7C08 03CA0100
	v_div_scale_f32 v10, vcc_lo, 1.0, v0, 1.0                  // 00000029AC38: D6FC6A0A 03CA00F2
	v_rcp_f32_e32 v9, v8                                       // 00000029AC40: 7E125508
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029AC44: BF870095
	v_fma_f32 v5, -v8, v9, 1.0                                 // 00000029AC48: D6130005 23CA1308
	v_fmac_f32_e32 v9, v5, v9                                  // 00000029AC50: 56121305
	v_mad_u64_u32 v[5:6], null, s10, v3, 0                     // 00000029AC54: D6FE7C05 0202060A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000029AC5C: BF870112
	v_mul_f32_e32 v11, v10, v9                                 // 00000029AC60: 1016130A
	v_mad_u64_u32 v[6:7], null, s11, v3, v[6:7]                // 00000029AC64: D6FE7C06 041A060B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029AC6C: BF870092
	v_fma_f32 v12, -v8, v11, v10                               // 00000029AC70: D613000C 242A1708
	v_fmac_f32_e32 v11, v12, v9                                // 00000029AC78: 5616130C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000029AC7C: BF870113
	.long 0xd73c0005                                           // 00000029AC80: D73C0005
	v_cndmask_b32_e32 v1, 2, v5, vcc_lo                        // 00000029AC84: 02020A82
	v_fma_f32 v10, -v8, v11, v10                               // 00000029AC88: D613000A 242A1708
	.long 0xd73c0007                                           // 00000029AC90: D73C0007
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 00000029AC94: 02020282
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000029AC98: BF870212
	v_div_fmas_f32 v9, v10, v9, v11                            // 00000029AC9C: D6370009 042E130A
	.long 0xd7006a05                                           // 00000029ACA4: D7006A05
	v_cndmask_b32_e32 v1, s2, v5, vcc_lo                       // 00000029ACA8: 02020A02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000029ACAC: BF870191
	v_add_co_ci_u32_e64 v6, null, s3, v6, vcc_lo               // 00000029ACB0: D5207C06 01AA0C03
	v_div_fixup_f32 v0, v9, v0, 1.0                            // 00000029ACB8: D6270000 03CA0109
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029ACC0: BF870093
	.long 0xd7006a05                                           // 00000029ACC4: D7006A05
	v_cndmask_b32_e32 v1, v5, v7, vcc_lo                       // 00000029ACC8: 02020F05
	v_add_co_ci_u32_e64 v6, null, v6, v8, vcc_lo               // 00000029ACCC: D5207C06 01AA1106
	global_store_b32 v[5:6], v0, off                           // 00000029ACD4: DC6A0000 007C0005
	s_mov_b32 s6, 0                                            // 00000029ACDC: BE860080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000029ACE0: BF870009
	s_and_b32 vcc_lo, exec_lo, s6                              // 00000029ACE4: 8B6A067E
	s_cbranch_vccz 60                                          // 00000029ACE8: BFA3003C <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi32ELi2ELi1EEEvNS0_5LqGrpEPKtl+0x10dc>
	v_bfe_u32 v0, v4, 16, 1                                    // 00000029ACEC: D6100000 02052104
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029ACF4: BF870091
	v_add3_u32 v0, v4, v0, 0x7fff                              // 00000029ACF8: D6550000 03FE0104 00007FFF
	v_and_b32_e32 v0, 0xffff0000, v0                           // 00000029AD04: 360000FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029AD0C: BF870091
	v_mul_f32_e32 v0, s4, v0                                   // 00000029AD10: 10000004
	v_mul_f32_e32 v0, 0xbfb8aa3b, v0                           // 00000029AD14: 100000FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000029AD1C: BF870291
	v_exp_f32_e32 v0, v0                                       // 00000029AD20: 7E004B00
	v_add_f32_e32 v0, 1.0, v0                                  // 00000029AD24: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000029AD28: BF870121
	v_div_scale_f32 v8, null, v0, v0, 1.0                      // 00000029AD2C: D6FC7C08 03CA0100
	v_div_scale_f32 v10, vcc_lo, 1.0, v0, 1.0                  // 00000029AD34: D6FC6A0A 03CA00F2
	v_rcp_f32_e32 v9, v8                                       // 00000029AD3C: 7E125508
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029AD40: BF870095
	v_fma_f32 v5, -v8, v9, 1.0                                 // 00000029AD44: D6130005 23CA1308
	v_fmac_f32_e32 v9, v5, v9                                  // 00000029AD4C: 56121305
	v_mad_u64_u32 v[5:6], null, s10, v3, 0                     // 00000029AD50: D6FE7C05 0202060A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029AD58: BF870092
	v_mul_f32_e32 v11, v10, v9                                 // 00000029AD5C: 1016130A
	v_fma_f32 v7, -v8, v11, v10                                // 00000029AD60: D6130007 242A1708
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000029AD68: BF870211
	v_fmac_f32_e32 v11, v7, v9                                 // 00000029AD6C: 56161307
	v_mad_u64_u32 v[6:7], null, s11, v3, v[6:7]                // 00000029AD70: D6FE7C06 041A060B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000029AD78: BF870112
	v_fma_f32 v7, -v8, v11, v10                                // 00000029AD7C: D6130007 242A1708
	.long 0xd73c0005                                           // 00000029AD84: D73C0005
	v_cndmask_b32_e32 v1, 2, v5, vcc_lo                        // 00000029AD88: 02020A82
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000029AD8C: BF8701A2
	v_div_fmas_f32 v9, v7, v9, v11                             // 00000029AD90: D6370009 042E1307
	.long 0xd73c0007                                           // 00000029AD98: D73C0007
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 00000029AD9C: 02020282
	.long 0xd7006a05                                           // 00000029ADA0: D7006A05
	v_cndmask_b32_e32 v1, s2, v5, vcc_lo                       // 00000029ADA4: 02020A02
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000029ADA8: BF8701A3
	v_div_fixup_f32 v0, v9, v0, 1.0                            // 00000029ADAC: D6270000 03CA0109
	v_add_co_ci_u32_e64 v6, null, s3, v6, vcc_lo               // 00000029ADB4: D5207C06 01AA0C03
	.long 0xd7006a05                                           // 00000029ADBC: D7006A05
	v_cndmask_b32_e32 v1, v5, v7, vcc_lo                       // 00000029ADC0: 02020F05
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000029ADC4: BF870193
	v_add_f32_e32 v0, v0, v0                                   // 00000029ADC8: 06000100
	v_add_co_ci_u32_e64 v6, null, v6, v8, vcc_lo               // 00000029ADCC: D5207C06 01AA1106
	global_store_b32 v[5:6], v0, off                           // 00000029ADD4: DC6A0000 007C0005
	s_mov_b32 s6, 0                                            // 00000029ADDC: BE860080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000029ADE0: BF870009
	s_and_b32 vcc_lo, exec_lo, s6                              // 00000029ADE4: 8B6A067E
	s_cbranch_vccz 73                                          // 00000029ADE8: BFA30049 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi32ELi2ELi1EEEvNS0_5LqGrpEPKtl+0x1210>
	s_cmp_gt_i32 s5, 1                                         // 00000029ADEC: BF028105
	s_mov_b32 s1, -1                                           // 00000029ADF0: BE8100C1
	s_cbranch_scc0 64                                          // 00000029ADF4: BFA10040 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi32ELi2ELi1EEEvNS0_5LqGrpEPKtl+0x11f8>
	v_bfe_u32 v0, v4, 16, 1                                    // 00000029ADF8: D6100000 02052104
	s_mov_b32 s1, 0                                            // 00000029AE00: BE810080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029AE04: BF870091
	v_add3_u32 v0, v4, v0, 0x7fff                              // 00000029AE08: D6550000 03FE0104 00007FFF
	v_and_b32_e32 v0, 0xffff0000, v0                           // 00000029AE14: 360000FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029AE1C: BF870091
	v_mul_f32_e32 v0, 0xbfb8aa3b, v0                           // 00000029AE20: 100000FF BFB8AA3B
	v_exp_f32_e32 v0, v0                                       // 00000029AE28: 7E004B00
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029AE2C: BF870095
	v_add_f32_e32 v0, 1.0, v0                                  // 00000029AE30: 060000F2
	v_div_scale_f32 v7, null, v0, v0, 1.0                      // 00000029AE34: D6FC7C07 03CA0100
	v_div_scale_f32 v9, vcc_lo, 1.0, v0, 1.0                   // 00000029AE3C: D6FC6A09 03CA00F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000029AE44: BF870292
	v_rcp_f32_e32 v8, v7                                       // 00000029AE48: 7E105507
	v_fma_f32 v5, -v7, v8, 1.0                                 // 00000029AE4C: D6130005 23CA1107
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000029AE54: BF870121
	v_fmac_f32_e32 v8, v5, v8                                  // 00000029AE58: 56101105
	v_mad_u64_u32 v[5:6], null, s10, v3, 0                     // 00000029AE5C: D6FE7C05 0202060A
	v_mul_f32_e32 v10, v9, v8                                  // 00000029AE64: 10141109
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029AE68: BF870091
	v_fma_f32 v11, -v7, v10, v9                                // 00000029AE6C: D613000B 24261507
	v_fmac_f32_e32 v10, v11, v8                                // 00000029AE74: 5614110B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000029AE78: BF870121
	v_fma_f32 v9, -v7, v10, v9                                 // 00000029AE7C: D6130009 24261507
	v_mad_u64_u32 v[6:7], null, s11, v3, v[6:7]                // 00000029AE84: D6FE7C06 041A060B
	v_div_fmas_f32 v7, v9, v8, v10                             // 00000029AE8C: D6370007 042A1109
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000029AE94: BF870112
	.long 0xd73c0005                                           // 00000029AE98: D73C0005
	v_cndmask_b32_e32 v1, 1, v5, vcc_lo                        // 00000029AE9C: 02020A81
	v_div_fixup_f32 v0, v7, v0, 1.0                            // 00000029AEA0: D6270000 03CA0107
	.long 0xd73c0007                                           // 00000029AEA8: D73C0007
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 00000029AEAC: 02020281
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000029AEB0: BF870193
	.long 0xd7006a05                                           // 00000029AEB4: D7006A05
	v_cndmask_b32_e32 v1, s2, v5, vcc_lo                       // 00000029AEB8: 02020A02
	v_bfe_u32 v9, v0, 16, 1                                    // 00000029AEBC: D6100009 02052100
	v_add_co_ci_u32_e64 v6, null, s3, v6, vcc_lo               // 00000029AEC4: D5207C06 01AA0C03
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000029AECC: BF870193
	.long 0xd7006a05                                           // 00000029AED0: D7006A05
	v_cndmask_b32_e32 v1, v5, v7, vcc_lo                       // 00000029AED4: 02020F05
	v_add3_u32 v0, v0, v9, 0x7fff                              // 00000029AED8: D6550000 03FE1300 00007FFF
	s_delay_alu instid0(VALU_DEP_3)                            // 00000029AEE4: BF870003
	v_add_co_ci_u32_e64 v6, null, v6, v8, vcc_lo               // 00000029AEE8: D5207C06 01AA1106
	global_store_d16_hi_b16 v[5:6], v0, off                    // 00000029AEF0: DC960000 007C0005
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 00000029AEF8: 916A017E
	s_mov_b32 s1, 0                                            // 00000029AEFC: BE810080
	s_cbranch_vccnz 3                                          // 00000029AF00: BFA40003 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi32ELi2ELi1EEEvNS0_5LqGrpEPKtl+0x1210>
	s_cmp_lg_u32 s5, 1                                         // 00000029AF04: BF078105
	s_mov_b32 s1, -1                                           // 00000029AF08: BE8100C1
	s_cselect_b32 s0, -1, 0                                    // 00000029AF0C: 980080C1
	v_bfe_u32 v5, v4, 16, 1                                    // 00000029AF10: D6100005 02052104
	.long 0xd73c0000                                           // 00000029AF18: D73C0000
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 00000029AF1C: 02020281
	s_and_b32 vcc_lo, exec_lo, s0                              // 00000029AF20: 8B6A007E
	s_delay_alu instid0(VALU_DEP_2)                            // 00000029AF24: BF870002
	v_add3_u32 v2, v4, v5, 0x7fff                              // 00000029AF28: D6550002 03FE0B04 00007FFF
	s_cbranch_vccz 20                                          // 00000029AF34: BFA30014 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi32ELi2ELi1EEEvNS0_5LqGrpEPKtl+0x1288>
	v_mad_u64_u32 v[4:5], null, s10, v3, 0                     // 00000029AF38: D6FE7C04 0202060A
	s_mov_b32 s1, 0                                            // 00000029AF40: BE810080
	v_mad_u64_u32 v[5:6], null, s11, v3, v[5:6]                // 00000029AF44: D6FE7C05 0416060B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029AF4C: BF870091
	.long 0xd73c0004                                           // 00000029AF50: D73C0004
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 00000029AF54: 02020881
	.long 0xd7006a04                                           // 00000029AF58: D7006A04
	v_cndmask_b32_e32 v1, s2, v4, vcc_lo                       // 00000029AF5C: 02020802
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000029AF60: BF870111
	v_add_co_ci_u32_e64 v5, null, s3, v5, vcc_lo               // 00000029AF64: D5207C05 01AA0A03
	.long 0xd7006a04                                           // 00000029AF6C: D7006A04
	v_cndmask_b32_e32 v1, v4, v0, vcc_lo                       // 00000029AF70: 02020104
	s_delay_alu instid0(VALU_DEP_1)                            // 00000029AF74: BF870001
	v_add_co_ci_u32_e64 v5, null, v5, v1, vcc_lo               // 00000029AF78: D5207C05 01AA0305
	global_store_d16_hi_b16 v[4:5], v2, off                    // 00000029AF80: DC960000 007C0204
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 00000029AF88: 916A017E
	s_cbranch_vccnz 57                                         // 00000029AF8C: BFA40039 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi32ELi2ELi1EEEvNS0_5LqGrpEPKtl+0x1374>
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029AF90: BF870091
	v_and_b32_e32 v2, 0xffff0000, v2                           // 00000029AF94: 360404FF FFFF0000
	v_mul_f32_e32 v2, s4, v2                                   // 00000029AF9C: 10040404
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029AFA0: BF870091
	v_mul_f32_e32 v4, 0xbfb8aa3b, v2                           // 00000029AFA4: 100804FF BFB8AA3B
	v_exp_f32_e32 v4, v4                                       // 00000029AFAC: 7E084B04
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029AFB0: BF870095
	v_add_f32_e32 v7, 1.0, v4                                  // 00000029AFB4: 060E08F2
	v_div_scale_f32 v6, null, v7, v7, v2                       // 00000029AFB8: D6FC7C06 040A0F07
	v_div_scale_f32 v9, vcc_lo, v2, v7, v2                     // 00000029AFC0: D6FC6A09 040A0F02
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000029AFC8: BF870292
	v_rcp_f32_e32 v8, v6                                       // 00000029AFCC: 7E105506
	v_fma_f32 v4, -v6, v8, 1.0                                 // 00000029AFD0: D6130004 23CA1106
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000029AFD8: BF870121
	v_fmac_f32_e32 v8, v4, v8                                  // 00000029AFDC: 56101104
	v_mad_u64_u32 v[4:5], null, s10, v3, 0                     // 00000029AFE0: D6FE7C04 0202060A
	v_mul_f32_e32 v10, v9, v8                                  // 00000029AFE8: 10141109
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029AFEC: BF870091
	v_fma_f32 v11, -v6, v10, v9                                // 00000029AFF0: D613000B 24261506
	v_fmac_f32_e32 v10, v11, v8                                // 00000029AFF8: 5614110B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000029AFFC: BF870121
	v_fma_f32 v9, -v6, v10, v9                                 // 00000029B000: D6130009 24261506
	v_mad_u64_u32 v[5:6], null, s11, v3, v[5:6]                // 00000029B008: D6FE7C05 0416060B
	v_div_fmas_f32 v3, v9, v8, v10                             // 00000029B010: D6370003 042A1109
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000029B018: BF870191
	v_div_fixup_f32 v6, v3, v7, v2                             // 00000029B01C: D6270006 040A0F03
	.long 0xd73c0002                                           // 00000029B024: D73C0002
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 00000029B028: 02020881
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000029B02C: BF870112
	v_bfe_u32 v4, v6, 16, 1                                    // 00000029B030: D6100004 02052106
	.long 0xd7006a02                                           // 00000029B038: D7006A02
	v_cndmask_b32_e32 v1, s2, v2, vcc_lo                       // 00000029B03C: 02020402
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000029B040: BF870191
	v_add_co_ci_u32_e64 v3, null, s3, v3, vcc_lo               // 00000029B044: D5207C03 01AA0603
	v_add3_u32 v4, v6, v4, 0x7fff                              // 00000029B04C: D6550004 03FE0906 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029B058: BF870093
	.long 0xd7006a00                                           // 00000029B05C: D7006A00
	v_cndmask_b32_e32 v1, v2, v0, vcc_lo                       // 00000029B060: 02020102
	v_add_co_ci_u32_e64 v1, null, v3, v1, vcc_lo               // 00000029B064: D5207C01 01AA0303
	global_store_d16_hi_b16 v[0:1], v4, off                    // 00000029B06C: DC960000 007C0400
	s_endpgm                                                   // 00000029B074: BFB00000
		...

