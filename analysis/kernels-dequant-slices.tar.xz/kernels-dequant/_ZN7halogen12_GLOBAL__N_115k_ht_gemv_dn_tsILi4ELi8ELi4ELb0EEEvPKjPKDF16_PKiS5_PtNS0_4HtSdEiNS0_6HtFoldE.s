0000000000964300 <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_dn_tsILi4ELi8ELi4ELb0EEEvPKjPKDF16_PKiS5_PtNS0_4HtSdEiNS0_6HtFoldE>:
; _ZN7halogen12_GLOBAL__N_115k_ht_gemv_dn_tsILi4ELi8ELi4ELb0EEEvPKjPKDF16_PKiS5_PtNS0_4HtSdEiNS0_6HtFoldE():
	s_clause 0x1                                               // 000000964300: BF850001
	s_load_b32 s3, s[0:1], 0x80                                // 000000964304: F40000C0 F8000080
	s_load_b512 s[12:27], s[0:1], null                         // 00000096430C: F4100300 F8000000
	v_and_b32_e32 v20, 31, v0                                  // 000000964314: 3628009F
	v_lshrrev_b32_e32 v19, 5, v0                               // 000000964318: 32260085
	s_mov_b32 s4, -1                                           // 00000096431C: BE8400C1
	s_waitcnt lgkmcnt(0)                                       // 000000964320: BF89FC07
	s_cmp_lt_i32 s2, s3                                        // 000000964324: BF040302
	s_cbranch_scc1 2674                                        // 000000964328: BFA20A72 <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_dn_tsILi4ELi8ELi4ELb0EEEvPKjPKDF16_PKiS5_PtNS0_4HtSdEiNS0_6HtFoldE+0x29f4>
	s_load_b64 s[8:9], s[0:1], 0x74                            // 00000096432C: F4040200 F8000074
	s_sub_i32 s44, s2, s3                                      // 000000964334: 81AC0302
	s_clause 0x2                                               // 000000964338: BF850002
	s_load_b128 s[28:31], s[0:1], 0x68                         // 00000096433C: F4080700 F8000068
	s_load_b64 s[34:35], s[0:1], 0x60                          // 000000964344: F4040880 F8000060
	s_load_b256 s[36:43], s[0:1], 0x40                         // 00000096434C: F40C0900 F8000040
	s_mov_b32 s47, 0                                           // 000000964354: BEAF0080
	s_mov_b32 s45, exec_lo                                     // 000000964358: BEAD007E
	s_waitcnt lgkmcnt(0)                                       // 00000096435C: BF89FC07
	s_abs_i32 s4, s9                                           // 000000964360: BE841509
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_2)// 000000964364: BF870529
	s_cvt_f32_u32 s5, s4                                       // 000000964368: BE856504
	s_sub_i32 s6, 0, s4                                        // 00000096436C: 81860480
	v_rcp_iflag_f32_e32 v1, s5                                 // 000000964370: 7E025605
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_3)// 000000964374: BF8705A5
	v_readfirstlane_b32 s5, v1                                 // 000000964378: 7E0A0501
	s_mul_f32 s5, s5, 0x4f7ffffe                               // 00000096437C: A205FF05 4F7FFFFE
	s_cvt_u32_f32 s5, s5                                       // 000000964384: BE856705
	s_delay_alu instid0(SALU_CYCLE_3) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000964388: BF87049B
	s_mul_i32 s6, s6, s5                                       // 00000096438C: 96060506
	s_mul_hi_u32 s6, s5, s6                                    // 000000964390: 96860605
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 000000964394: BF8704B9
	s_add_i32 s5, s5, s6                                       // 000000964398: 81050605
	s_ashr_i32 s6, s9, 31                                      // 00000096439C: 86069F09
	s_mul_hi_u32 s3, s44, s5                                   // 0000009643A0: 9683052C
	s_mul_i32 s5, s3, s4                                       // 0000009643A4: 96050403
	s_add_i32 s7, s3, 1                                        // 0000009643A8: 81078103
	s_sub_i32 s5, s44, s5                                      // 0000009643AC: 8185052C
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000009643B0: BF870009
	s_sub_i32 s10, s5, s4                                      // 0000009643B4: 818A0405
	s_cmp_ge_u32 s5, s4                                        // 0000009643B8: BF090405
	s_cselect_b32 s3, s7, s3                                   // 0000009643BC: 98030307
	s_cselect_b32 s5, s10, s5                                  // 0000009643C0: 9805050A
	s_add_i32 s7, s3, 1                                        // 0000009643C4: 81078103
	s_cmp_ge_u32 s5, s4                                        // 0000009643C8: BF090405
	s_cselect_b32 s3, s7, s3                                   // 0000009643CC: 98030307
	s_ashr_i32 s11, s30, 31                                    // 0000009643D0: 860B9F1E
	s_xor_b32 s3, s3, s6                                       // 0000009643D4: 8D030603
	s_lshr_b32 s0, s11, 25                                     // 0000009643D8: 8500990B
	s_sub_i32 s10, s3, s6                                      // 0000009643DC: 818A0603
	s_add_i32 s0, s30, s0                                      // 0000009643E0: 8100001E
	s_mul_i32 s46, s10, s9                                     // 0000009643E4: 962E090A
	s_ashr_i32 s0, s0, 7                                       // 0000009643E8: 86008700
	s_sub_i32 s31, s44, s46                                    // 0000009643EC: 819F2E2C
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000009643F0: BF870499
	s_mul_i32 s31, s31, s8                                     // 0000009643F4: 961F081F
	s_add_i32 s1, s31, s8                                      // 0000009643F8: 8101081F
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000009643FC: BF870499
	s_min_i32 s0, s0, s1                                       // 000000964400: 89000100
	s_sub_i32 s49, s0, s31                                     // 000000964404: 81B11F00
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000964408: BF870499
	s_lshl_b32 s33, s49, 2                                     // 00000096440C: 84218231
	.long 0xd4c4007e                                           // 000000964410: D4C4007E
	v_cndmask_b32_e32 v1, s33, v19, vcc_lo                     // 000000964414: 02022621
	s_cbranch_execz 503                                        // 000000964418: BFA501F7 <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_dn_tsILi4ELi8ELi4ELb0EEEvPKjPKDF16_PKiS5_PtNS0_4HtSdEiNS0_6HtFoldE+0x8f8>
	s_add_i32 s48, s28, -1                                     // 00000096441C: 8130C11C
	s_cmp_lg_u64 s[38:39], 0                                   // 000000964420: BF118026
	v_dual_mov_b32 v8, v19 :: v_dual_and_b32 v1, 1, v0         // 000000964424: CA240113 08000081
	s_cselect_b32 s50, -1, 0                                   // 00000096442C: 983280C1
	s_abs_i32 s51, s49                                         // 000000964430: BEB31531
	v_and_b32_e32 v2, 2, v0                                    // 000000964434: 36040082
	s_cvt_f32_u32 s0, s51                                      // 000000964438: BE806533
	v_lshlrev_b32_e32 v6, 3, v20                               // 00000096443C: 300C2883
	v_lshlrev_b32_e32 v7, 7, v19                               // 000000964440: 300E2687
	v_and_b32_e32 v3, 4, v0                                    // 000000964444: 36060084
	v_rcp_iflag_f32_e32 v4, s0                                 // 000000964448: 7E085600
	v_and_b32_e32 v5, 8, v0                                    // 00000096444C: 360A0088
	.long 0xd44a0001                                           // 000000964450: D44A0001
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 000000964454: 02020280
	.long 0xd44a0003                                           // 000000964458: D44A0003
	v_cndmask_b32_e32 v1, 0, v2, vcc_lo                        // 00000096445C: 02020480
	v_lshl_or_b32 v1, v19, 8, v6                               // 000000964460: D6560001 04191113
	v_lshl_add_u32 v2, s31, 7, v7                              // 000000964468: D6460002 041D0E1F
	s_ashr_i32 s53, s49, 31                                    // 000000964470: 86359F31
	s_sub_i32 s55, 0, s51                                      // 000000964474: 81B73380
	s_mul_i32 s8, s53, 0x1400                                  // 000000964478: 9608FF35 00001400
	.long 0xd44c0000                                           // 000000964480: D44C0000
	v_cndmask_b32_e32 v1, 16, v20, vcc_lo                      // 000000964484: 02022890
	v_readfirstlane_b32 s5, v4                                 // 000000964488: 7E0A0504
	.long 0xd44a0004                                           // 00000096448C: D44A0004
	v_cndmask_b32_e32 v1, 0, v3, vcc_lo                        // 000000964490: 02020680
	v_subrev_nc_u32_e32 v9, s8, v1                             // 000000964494: 4E120208
	v_lshl_or_b32 v1, v20, 2, v2                               // 000000964498: D6560001 04090514
	s_lshl_b32 s6, s49, 7                                      // 0000009644A0: 84068731
	s_mul_f32 s7, s5, 0x4f7ffffe                               // 0000009644A4: A207FF05 4F7FFFFE
	.long 0xd44a0005                                           // 0000009644AC: D44A0005
	v_cndmask_b32_e32 v1, 0, v5, vcc_lo                        // 0000009644B0: 02020A80
	s_mov_b32 s52, 0x76543210                                  // 0000009644B4: BEB400FF 76543210
	s_lshl_b32 s54, s49, 8                                     // 0000009644BC: 84368831
	s_cvt_u32_f32 s7, s7                                       // 0000009644C0: BE876707
	s_mov_b32 s57, 0x3db504f3                                  // 0000009644C4: BEB900FF 3DB504F3
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000009644CC: BF87049A
	s_mul_i32 s55, s55, s7                                     // 0000009644D0: 96370737
	s_mul_hi_u32 s8, s7, s55                                   // 0000009644D4: 96883707
	s_sub_i32 s55, 0, s6                                       // 0000009644D8: 81B70680
	s_add_i32 s56, s7, s8                                      // 0000009644DC: 81380807
	s_branch 164                                               // 0000009644E0: BFA000A4 <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_dn_tsILi4ELi8ELi4ELb0EEEvPKjPKDF16_PKiS5_PtNS0_4HtSdEiNS0_6HtFoldE+0x474>
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000009644E4: BF870091
	.long 0xd7006a02                                           // 0000009644E8: D7006A02
	v_cndmask_b32_e32 v1, s24, v2, vcc_lo                      // 0000009644EC: 02020418
	v_add_co_ci_u32_e64 v3, null, s25, v3, vcc_lo              // 0000009644F0: D5207C03 01AA0619
	v_sub_f32_e32 v4, v15, v13                                 // 0000009644F8: 08081B0F
	v_add_nc_u32_e32 v1, 0x400, v1                             // 0000009644FC: 4A0202FF 00000400
	global_load_d16_b16 v2, v[2:3], off offset:6               // 000000964504: DC820006 027C0002
	s_waitcnt vmcnt(0)                                         // 00000096450C: BF8903F7
	v_fma_mix_f32 v5, v14, v2, v12 op_sel_hi:[0,1,0]           // 000000964510: CC200005 1432050E
	v_fma_mix_f32 v2, -v14, v2, v12 op_sel_hi:[0,1,0]          // 000000964518: CC200002 3432050E
	v_add_f32_e32 v3, v15, v13                                 // 000000964520: 06061B0F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000964524: BF8701A2
	v_add_f32_e32 v7, v4, v2                                   // 000000964528: 060E0504
	v_sub_f32_e32 v2, v4, v2                                   // 00000096452C: 08040504
	v_add_f32_e32 v6, v3, v5                                   // 000000964530: 060C0B03
	v_sub_f32_e32 v3, v3, v5                                   // 000000964534: 08060B03
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000964538: BF870193
	v_mov_b32_dpp v13, v2 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000096453C: 7E1A02FA FF016102
	v_mov_b32_dpp v4, v6 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000964544: 7E0802FA FF016106
	v_cndmask_b32_e64 v6, -v6, v6, s1                          // 00000096454C: D5010006 20060D06
	v_cndmask_b32_e64 v2, -v2, v2, s1                          // 000000964554: D5010002 20060502
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 00000096455C: BF870142
	v_add_f32_e32 v4, v6, v4                                   // 000000964560: 06080906
	v_mov_b32_dpp v5, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000964564: 7E0A02FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, s1                          // 00000096456C: D5010007 20060F07
	.long 0xd72c0006                                           // 000000964574: D72C0006
	v_cndmask_b32_e32 v1, 0x1400, v11, vcc_lo                  // 000000964578: 020216FF 00001400
	v_add_f32_e32 v5, v7, v5                                   // 000000964580: 060A0B07
	v_mov_b32_dpp v7, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000964584: 7E0E02FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, s3                          // 00000096458C: D5010004 200E0904
	s_delay_alu instid0(VALU_DEP_1)                            // 000000964594: BF870001
	v_add_f32_e32 v4, v4, v7                                   // 000000964598: 06080F04
	v_mov_b32_dpp v12, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000096459C: 7E1802FA FF016103
	v_cndmask_b32_e64 v3, -v3, v3, s1                          // 0000009645A4: D5010003 20060703
	.long 0xd72c0007                                           // 0000009645AC: D72C0007
	v_cndmask_b32_e32 v1, s54, v10, vcc_lo                     // 0000009645B0: 02021436
	v_add_f32_e32 v2, v2, v13                                  // 0000009645B4: 06041B02
	v_mov_b32_dpp v10, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009645B8: 7E1402FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s4                          // 0000009645C0: D5010004 20120904
	v_add_f32_e32 v3, v3, v12                                  // 0000009645C8: 06061903
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000009645CC: BF870224
	v_mov_b32_dpp v13, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009645D0: 7E1A02FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, s3                          // 0000009645D8: D5010002 200E0502
	v_add_f32_e32 v4, v4, v10                                  // 0000009645E0: 06081504
	v_mov_b32_dpp v11, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009645E4: 7E1602FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, s3                          // 0000009645EC: D5010005 200E0B05
	v_mov_b32_dpp v12, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009645F4: 7E1802FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, s3                          // 0000009645FC: D5010003 200E0703
	v_add_f32_e32 v2, v2, v13                                  // 000000964604: 06041B02
	v_mov_b32_dpp v10, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000964608: 7E1402FA FF016804
	v_add_f32_e32 v5, v5, v11                                  // 000000964610: 060A1705
	v_cndmask_b32_e64 v4, -v4, v4, s5                          // 000000964614: D5010004 20160904
	v_add_f32_e32 v3, v3, v12                                  // 00000096461C: 06061903
	v_mov_b32_dpp v13, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000964620: 7E1A02FA FF016402
	v_cndmask_b32_e64 v2, -v2, v2, s4                          // 000000964628: D5010002 20120502
	v_mov_b32_dpp v11, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000964630: 7E1602FA FF016405
	v_cndmask_b32_e64 v5, -v5, v5, s4                          // 000000964638: D5010005 20120B05
	v_mov_b32_dpp v12, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000964640: 7E1802FA FF016403
	v_cndmask_b32_e64 v3, -v3, v3, s4                          // 000000964648: D5010003 20120703
	v_add_f32_e32 v2, v2, v13                                  // 000000964650: 06041B02
	v_sub_nc_u32_e32 v6, v6, v7                                // 000000964654: 4C0C0F06
	v_add_f32_e32 v5, v5, v11                                  // 000000964658: 060A1705
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000096465C: BF870214
	v_add_f32_e32 v3, v3, v12                                  // 000000964660: 06061903
	v_mov_b32_dpp v13, v2 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000964664: 7E1A02FA FF016802
	v_cndmask_b32_e64 v2, -v2, v2, s5                          // 00000096466C: D5010002 20160502
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 000000964674: BF870254
	v_mov_b32_dpp v11, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000964678: 7E1602FA FF016805
	v_cndmask_b32_e64 v5, -v5, v5, s5                          // 000000964680: D5010005 20160B05
	v_add_nc_u32_e32 v8, 8, v8                                 // 000000964688: 4A101088
	v_mov_b32_dpp v12, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000096468C: 7E1802FA FF016803
	v_cndmask_b32_e64 v3, -v3, v3, s5                          // 000000964694: D5010003 20160703
	v_dual_add_f32 v4, v4, v10 :: v_dual_add_f32 v5, v5, v11   // 00000096469C: C9081504 04041705
	v_add_f32_e32 v2, v2, v13                                  // 0000009646A4: 06041B02
	v_cmp_le_i32_e32 vcc_lo, s33, v8                           // 0000009646A8: 7C861021
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009646AC: BF870214
	v_dual_add_f32 v3, v3, v12 :: v_dual_add_nc_u32 v6, v9, v6 // 0000009646B0: C9201903 03060D09
	v_dual_mov_b32 v11, v5 :: v_dual_mov_b32 v10, v4           // 0000009646B8: CA100105 0B0A0104
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000009646C0: BF870234
	v_mov_b32_e32 v13, v2                                      // 0000009646C4: 7E1A0302
	v_cndmask_b32_e64 v5, -v5, v5, s0                          // 0000009646C8: D5010005 20020B05
	v_cndmask_b32_e64 v4, -v4, v4, s0                          // 0000009646D0: D5010004 20020904
	v_permlanex16_b32 v11, v11, s52, 0xfedcba98                // 0000009646D8: D65C000B 03FC690B FEDCBA98
	v_mov_b32_e32 v12, v3                                      // 0000009646E4: 7E180303
	v_cndmask_b32_e64 v2, -v2, v2, s0                          // 0000009646E8: D5010002 20020502
	v_cndmask_b32_e64 v3, -v3, v3, s0                          // 0000009646F0: D5010003 20020703
	v_permlanex16_b32 v10, v10, s52, 0xfedcba98                // 0000009646F8: D65C000A 03FC690A FEDCBA98
	v_permlanex16_b32 v13, v13, s52, 0xfedcba98                // 000000964704: D65C000D 03FC690D FEDCBA98
	v_add_f32_e32 v5, v5, v11                                  // 000000964710: 060A1705
	v_permlanex16_b32 v12, v12, s52, 0xfedcba98                // 000000964714: D65C000C 03FC690C FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000964720: BF870214
	v_dual_add_f32 v4, v4, v10 :: v_dual_add_nc_u32 v9, 0x800, v9// 000000964724: C9201504 040812FF 00000800
	v_add_f32_e32 v7, v2, v13                                  // 000000964730: 060E1B02
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000964734: BF870214
	v_fma_mixhi_f16 v2, v5, s57, 0                             // 000000964738: CC220002 02007305
	v_add_f32_e32 v10, v3, v12                                 // 000000964740: 06141903
	s_or_b32 s47, vcc_lo, s47                                  // 000000964744: 8C2F2F6A
	v_fma_mixlo_f16 v2, v4, s57, 0                             // 000000964748: CC210002 02007304
	v_fma_mixhi_f16 v3, v7, s57, 0                             // 000000964750: CC220003 02007307
	s_delay_alu instid0(VALU_DEP_3)                            // 000000964758: BF870003
	v_fma_mixlo_f16 v3, v10, s57, 0                            // 00000096475C: CC210003 0200730A
	ds_store_b64 v6, v[2:3]                                    // 000000964764: D9340000 00000206
	s_and_not1_b32 exec_lo, exec_lo, s47                       // 00000096476C: 917E2F7E
	s_cbranch_execz 289                                        // 000000964770: BFA50121 <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_dn_tsILi4ELi8ELi4ELb0EEEvPKjPKDF16_PKiS5_PtNS0_4HtSdEiNS0_6HtFoldE+0x8f8>
	.long 0xd72d0002                                           // 000000964774: D72D0002
	v_cndmask_b32_e32 v0, v8, v56, vcc_lo                      // 000000964778: 02007108
	s_mov_b32 s6, -1                                           // 00000096477C: BE8600C1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000964780: BF870091
	.long 0xd72c0003                                           // 000000964784: D72C0003
	v_cndmask_b32_e32 v0, v2, v51, vcc_lo                      // 000000964788: 02006702
	v_sub_nc_u32_e32 v3, v8, v3                                // 00000096478C: 4C060708
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000964790: BF870121
	v_subrev_nc_u32_e32 v5, s51, v3                            // 000000964794: 4E0A0633
	v_cmp_le_u32_e32 vcc_lo, s51, v3                           // 000000964798: 7C960633
	v_dual_cndmask_b32 v3, v3, v5 :: v_dual_add_nc_u32 v4, 1, v2// 00000096479C: CA600B03 03040481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000009647A4: BF870111
	v_cndmask_b32_e32 v2, v2, v4, vcc_lo                       // 0000009647A8: 02040902
	v_cmp_le_u32_e32 vcc_lo, s51, v3                           // 0000009647AC: 7C960633
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000009647B0: BF870092
	v_add_nc_u32_e32 v4, 1, v2                                 // 0000009647B4: 4A080481
	v_cndmask_b32_e32 v2, v2, v4, vcc_lo                       // 0000009647B8: 02040902
	s_and_not1_b32 vcc_lo, exec_lo, s50                        // 0000009647BC: 916A327E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000009647C0: BF870091
	v_xor_b32_e32 v11, s53, v2                                 // 0000009647C4: 3A160435
	v_subrev_nc_u32_e32 v10, s53, v11                          // 0000009647C8: 4E141635
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000009647CC: BF8700A1
	v_mad_u64_u32 v[6:7], null, s55, v10, v[1:2]               // 0000009647D0: D6FE7C06 04061437
	v_min_i32_e32 v2, s48, v10                                 // 0000009647D8: 22041430
	v_mad_i64_i32 v[4:5], null, v2, s30, 0                     // 0000009647DC: D6FF7C04 02003D02
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000009647E4: BF870093
	v_ashrrev_i32_e32 v7, 31, v6                               // 0000009647E8: 340E0C9F
	.long 0xd73c0002                                           // 0000009647EC: D73C0002
	v_cndmask_b32_e32 v1, 1, v6, vcc_lo                        // 0000009647F0: 02020C81
	s_cbranch_vccnz 212                                        // 0000009647F4: BFA400D4 <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_dn_tsILi4ELi8ELi4ELb0EEEvPKjPKDF16_PKiS5_PtNS0_4HtSdEiNS0_6HtFoldE+0x848>
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000009647F8: BF870093
	.long 0xd7006a06                                           // 0000009647FC: D7006A06
	v_cndmask_b32_e32 v1, v4, v6, vcc_lo                       // 000000964800: 02020D04
	v_add_co_ci_u32_e64 v7, null, v5, v7, vcc_lo               // 000000964804: D5207C07 01AA0F05
	.long 0x7f3c3880                                           // 00000096480C: 7F3C3880
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000964810: BF870112
	.long 0xd73c0006                                           // 000000964814: D73C0006
	v_cndmask_b32_e32 v1, 1, v6, vcc_lo                        // 000000964818: 02020C81
	.long 0x7f42399e                                           // 00000096481C: 7F42399E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000964820: BF870092
	.long 0xd7006a0c                                           // 000000964824: D7006A0C
	v_cndmask_b32_e32 v1, s36, v6, vcc_lo                      // 000000964828: 02020C24
	v_add_co_ci_u32_e64 v13, null, s37, v7, vcc_lo             // 00000096482C: D5207C0D 01AA0E25
	.long 0xd7006a06                                           // 000000964834: D7006A06
	v_cndmask_b32_e32 v1, s38, v6, vcc_lo                      // 000000964838: 02020C26
	s_delay_alu instid0(VALU_DEP_1)                            // 00000096483C: BF870001
	v_add_co_ci_u32_e64 v7, null, s39, v7, vcc_lo              // 000000964840: D5207C07 01AA0E27
	global_load_b64 v[12:13], v[12:13], off                    // 000000964848: DC560000 0C7C000C
	.long 0xd7006a0e                                           // 000000964850: D7006A0E
	v_cndmask_b32_e32 v1, s24, v2, vcc_lo                      // 000000964854: 02020418
	global_load_b64 v[6:7], v[6:7], off                        // 000000964858: DC560000 067C0006
	v_add_co_ci_u32_e64 v15, null, s25, v3, vcc_lo             // 000000964860: D5207C0F 01AA0619
	s_clause 0x1                                               // 000000964868: BF850001
	global_load_b32 v16, v[14:15], off                         // 00000096486C: DC520000 107C000E
	global_load_d16_b16 v14, v[14:15], off offset:4            // 000000964874: DC820004 0E7C000E
	s_waitcnt vmcnt(3)                                         // 00000096487C: BF890FF7
	.long 0x7e1e390c                                           // 000000964880: 7E1E390C
	s_waitcnt vmcnt(2)                                         // 000000964884: BF890BF7
	v_and_b32_e32 v40, 0xffff0000, v6                          // 000000964888: 36500CFF FFFF0000
	v_lshlrev_b32_e32 v6, 16, v6                               // 000000964890: 300C0C90
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000964894: BF870093
	v_lshlrev_b32_e32 v15, 16, v15                             // 000000964898: 301E1E90
	v_mul_f32_e32 v21, 0xbfb8aa3b, v15                         // 00000096489C: 102A1EFF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000009648A4: BF870291
	v_exp_f32_e32 v21, v21                                     // 0000009648A8: 7E2A4B15
	v_dual_add_f32 v21, 1.0, v21 :: v_dual_and_b32 v12, 0xffff0000, v12// 0000009648AC: C9242AF2 150C18FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000009648B8: BF870111
	v_mul_f32_e32 v18, 0xbfb8aa3b, v12                         // 0000009648BC: 102418FF BFB8AA3B
	v_div_scale_f32 v25, null, v21, v21, v15                   // 0000009648C4: D6FC7C19 043E2B15
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000009648CC: BF8701B2
	v_exp_f32_e32 v18, v18                                     // 0000009648D0: 7E244B12
	v_lshlrev_b32_e32 v17, 16, v13                             // 0000009648D4: 30221A90
	v_div_scale_f32 v38, s7, v15, v21, v15                     // 0000009648D8: D6FC0726 043E2B0F
	v_rcp_f32_e32 v29, v25                                     // 0000009648E0: 7E3A5519
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009648E4: BF870196
	v_add_f32_e32 v18, 1.0, v18                                // 0000009648E8: 062424F2
	v_mul_f32_e32 v22, 0xbfb8aa3b, v17                         // 0000009648EC: 102C22FF BFB8AA3B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009648F4: BF870195
	v_fma_f32 v37, -v25, v29, 1.0                              // 0000009648F8: D6130025 23CA3B19
	v_div_scale_f32 v24, null, v18, v18, v12                   // 000000964900: D6FC7C18 04322512
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000964908: BF8701B3
	v_exp_f32_e32 v22, v22                                     // 00000096490C: 7E2C4B16
	v_and_b32_e32 v13, 0xffff0000, v13                         // 000000964910: 361A1AFF FFFF0000
	v_div_scale_f32 v34, vcc_lo, v12, v18, v12                 // 000000964918: D6FC6A22 0432250C
	v_rcp_f32_e32 v27, v24                                     // 000000964920: 7E365518
	s_delay_alu instid0(TRANS32_DEP_2) | instid1(VALU_DEP_2)   // 000000964924: BF870106
	v_dual_add_f32 v22, 1.0, v22 :: v_dual_mul_f32 v23, 0xbfb8aa3b, v13// 000000964928: C9062CF2 16161AFF BFB8AA3B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000964934: BF870115
	v_fma_f32 v35, -v24, v27, 1.0                              // 000000964938: D6130023 23CA3718
	v_div_scale_f32 v26, null, v22, v22, v17                   // 000000964940: D6FC7C1A 04462D16
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000964948: BF8701A3
	v_exp_f32_e32 v23, v23                                     // 00000096494C: 7E2E4B17
	v_div_scale_f32 v36, s6, v17, v22, v17                     // 000000964950: D6FC0624 04462D11
	v_fmac_f32_e32 v27, v35, v27                               // 000000964958: 56363723
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 00000096495C: BF870313
	v_rcp_f32_e32 v31, v26                                     // 000000964960: 7E3E551A
	v_add_f32_e32 v23, 1.0, v23                                // 000000964964: 062E2EF2
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000964968: BF870115
	v_fma_f32 v39, -v26, v31, 1.0                              // 00000096496C: D6130027 23CA3F1A
	v_div_scale_f32 v28, null, v23, v23, v13                   // 000000964974: D6FC7C1C 04362F17
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000096497C: BF8701A2
	v_fmac_f32_e32 v31, v39, v31                               // 000000964980: 563E3F27
	v_mul_f32_e32 v39, v34, v27                                // 000000964984: 104E3722
	v_rcp_f32_e32 v32, v28                                     // 000000964988: 7E40551C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000096498C: BF870112
	v_mul_f32_e32 v41, v36, v31                                // 000000964990: 10523F24
	v_fma_f32 v42, -v24, v39, v34                              // 000000964994: D613002A 248A4F18
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000096499C: BF870112
	v_fma_f32 v45, -v26, v41, v36                              // 0000009649A0: D613002D 2492531A
	v_fmac_f32_e32 v39, v42, v27                               // 0000009649A8: 564E372A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009649AC: BF870195
	v_fma_f32 v35, -v28, v32, 1.0                              // 0000009649B0: D6130023 23CA411C
	v_fmac_f32_e32 v41, v45, v31                               // 0000009649B8: 56523F2D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009649BC: BF870193
	v_fma_f32 v24, -v24, v39, v34                              // 0000009649C0: D6130018 248A4F18
	v_fmac_f32_e32 v32, v35, v32                               // 0000009649C8: 56404123
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009649CC: BF870193
	v_fma_f32 v26, -v26, v41, v36                              // 0000009649D0: D613001A 2492531A
	v_div_fmas_f32 v24, v24, v27, v39                          // 0000009649D8: D6370018 049E3718
	s_mov_b32 vcc_lo, s7                                       // 0000009649E0: BEEA0007
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000009649E4: BF870131
	v_div_fixup_f32 v12, v24, v18, v12                         // 0000009649E8: D627000C 04322518
	v_fmac_f32_e32 v29, v37, v29                               // 0000009649F0: 563A3B25
	v_div_scale_f32 v37, s8, v13, v23, v13                     // 0000009649F4: D6FC0825 04362F0D
	v_dual_mul_f32 v12, v12, v40 :: v_dual_mul_f32 v35, v38, v29// 0000009649FC: C8C6510C 0C223B26
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000964A04: BF870112
	v_mul_f32_e32 v43, v37, v32                                // 000000964A08: 10564125
	.long 0x7e3c398c                                           // 000000964A0C: 7E3C398C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000964A10: BF870193
	v_fma_f32 v44, -v25, v35, v38                              // 000000964A14: D613002C 249A4719
	v_fma_f32 v42, -v28, v43, v37                              // 000000964A1C: D613002A 2496571C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000964A24: BF870112
	v_fmac_f32_e32 v35, v44, v29                               // 000000964A28: 56463B2C
	v_fmac_f32_e32 v43, v42, v32                               // 000000964A2C: 5656412A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000964A30: BF870112
	v_fma_f32 v25, -v25, v35, v38                              // 000000964A34: D6130019 249A4719
	v_fma_f32 v24, -v28, v43, v37                              // 000000964A3C: D6130018 2496571C
	s_delay_alu instid0(VALU_DEP_2)                            // 000000964A44: BF870002
	v_div_fmas_f32 v25, v25, v29, v35                          // 000000964A48: D6370019 048E3B19
	s_mov_b32 vcc_lo, s6                                       // 000000964A50: BEEA0006
	s_mov_b32 s6, 0                                            // 000000964A54: BE860080
	v_div_fmas_f32 v18, v26, v31, v41                          // 000000964A58: D6370012 04A63F1A
	s_mov_b32 vcc_lo, s8                                       // 000000964A60: BEEA0008
	v_div_fixup_f32 v15, v25, v21, v15                         // 000000964A64: D627000F 043E2B19
	v_lshlrev_b32_e32 v21, 16, v7                              // 000000964A6C: 302A0E90
	v_and_b32_e32 v7, 0xffff0000, v7                           // 000000964A70: 360E0EFF FFFF0000
	v_div_fixup_f32 v17, v18, v22, v17                         // 000000964A78: D6270011 04462D12
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000964A80: BF8701A4
	v_mul_f32_e32 v6, v15, v6                                  // 000000964A84: 100C0D0F
	v_div_fmas_f32 v15, v24, v32, v43                          // 000000964A88: D637000F 04AE4118
	v_mul_f32_e32 v17, v17, v21                                // 000000964A90: 10222B11
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000964A94: BF870193
	.long 0x7e423986                                           // 000000964A98: 7E423986
	v_div_fixup_f32 v13, v15, v23, v13                         // 000000964A9C: D627000D 04362F0F
	v_and_b32_e32 v15, 1, v30                                  // 000000964AA4: 361E3C81
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000964AA8: BF870214
	v_bfe_u32 v18, v17, 16, 1                                  // 000000964AAC: D6100012 02052111
	v_and_b32_e32 v21, 1, v33                                  // 000000964AB4: 362A4281
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000964AB8: BF870214
	v_mul_f32_e32 v7, v13, v7                                  // 000000964ABC: 100E0F0D
	v_add3_u32 v12, v12, v15, 0x7fff                           // 000000964AC0: D655000C 03FE1F0C 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000964ACC: BF870214
	v_add3_u32 v13, v17, v18, 0x7fff                           // 000000964AD0: D655000D 03FE2511 00007FFF
	v_add3_u32 v6, v6, v21, 0x7fff                             // 000000964ADC: D6550006 03FE2B06 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000964AE8: BF870214
	v_bfe_u32 v15, v7, 16, 1                                   // 000000964AEC: D610000F 02052107
	v_and_b32_e32 v12, 0xffff0000, v12                         // 000000964AF4: 361818FF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000964AFC: BF870214
	v_and_b32_e32 v17, 0xffff0000, v13                         // 000000964B00: 36221AFF FFFF0000
	v_and_b32_e32 v6, 0xffff0000, v6                           // 000000964B08: 360C0CFF FFFF0000
	s_delay_alu instid0(VALU_DEP_4)                            // 000000964B10: BF870004
	v_add3_u32 v7, v7, v15, 0x7fff                             // 000000964B14: D6550007 03FE1F07 00007FFF
	s_waitcnt vmcnt(1)                                         // 000000964B20: BF8907F7
	v_fma_mix_f32 v13, v16, v12, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000964B24: CC20080D 8A021910
	s_waitcnt vmcnt(0)                                         // 000000964B2C: BF8903F7
	v_fma_mix_f32 v12, v14, v17, neg(0) op_sel_hi:[1,0,0]      // 000000964B30: CC20000C 8A02230E
	v_fma_mix_f32 v15, v16, v6, neg(0) op_sel_hi:[1,0,0]       // 000000964B38: CC20000F 8A020D10
	v_and_b32_e32 v14, 0xffff0000, v7                          // 000000964B40: 361C0EFF FFFF0000
	s_and_not1_b32 vcc_lo, exec_lo, s6                         // 000000964B48: 916A067E
	s_cbranch_vccnz 65125                                      // 000000964B4C: BFA4FE65 <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_dn_tsILi4ELi8ELi4ELb0EEEvPKjPKDF16_PKiS5_PtNS0_4HtSdEiNS0_6HtFoldE+0x1e4>
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000964B50: BF870093
	.long 0xd73c0004                                           // 000000964B54: D73C0004
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 000000964B58: 02020881
	.long 0xd7006a04                                           // 000000964B5C: D7006A04
	v_cndmask_b32_e32 v1, s36, v4, vcc_lo                      // 000000964B60: 02020824
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000964B64: BF870111
	v_add_co_ci_u32_e64 v5, null, s37, v5, vcc_lo              // 000000964B68: D5207C05 01AA0A25
	.long 0xd7006a04                                           // 000000964B70: D7006A04
	v_cndmask_b32_e32 v1, v4, v2, vcc_lo                       // 000000964B74: 02020504
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000964B78: BF8700A1
	v_add_co_ci_u32_e64 v5, null, v5, v3, vcc_lo               // 000000964B7C: D5207C05 01AA0705
	.long 0xd7006a06                                           // 000000964B84: D7006A06
	v_cndmask_b32_e32 v1, s24, v2, vcc_lo                      // 000000964B88: 02020418
	v_add_co_ci_u32_e64 v7, null, s25, v3, vcc_lo              // 000000964B8C: D5207C07 01AA0619
	global_load_b64 v[4:5], v[4:5], off                        // 000000964B94: DC560000 047C0004
	s_clause 0x1                                               // 000000964B9C: BF850001
	global_load_b32 v14, v[6:7], off                           // 000000964BA0: DC520000 0E7C0006
	global_load_d16_b16 v6, v[6:7], off offset:4               // 000000964BA8: DC820004 067C0006
	s_waitcnt vmcnt(2)                                         // 000000964BB0: BF890BF7
	.long 0x7e0e3904                                           // 000000964BB4: 7E0E3904
	v_and_b32_e32 v4, 0xffff0000, v4                           // 000000964BB8: 360808FF FFFF0000
	v_lshlrev_b32_e32 v12, 16, v5                              // 000000964BC0: 30180A90
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000964BC4: BF8701A3
	v_lshlrev_b32_e32 v7, 16, v7                               // 000000964BC8: 300E0E90
	s_waitcnt vmcnt(1)                                         // 000000964BCC: BF8907F7
	v_fma_mix_f32 v13, v14, v4, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000964BD0: CC20080D 8A02090E
	s_waitcnt vmcnt(0)                                         // 000000964BD8: BF8903F7
	v_fma_mix_f32 v12, v6, v12, neg(0) op_sel_hi:[1,0,0]       // 000000964BDC: CC20000C 8A021906
	v_fma_mix_f32 v15, v14, v7, neg(0) op_sel_hi:[1,0,0]       // 000000964BE4: CC20000F 8A020F0E
	v_and_b32_e32 v14, 0xffff0000, v5                          // 000000964BEC: 361C0AFF FFFF0000
	s_branch 65083                                             // 000000964BF4: BFA0FE3B <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_dn_tsILi4ELi8ELi4ELb0EEEvPKjPKDF16_PKiS5_PtNS0_4HtSdEiNS0_6HtFoldE+0x1e4>
	s_or_b32 exec_lo, exec_lo, s45                             // 000000964BF8: 8C7E2D7E
	s_bfe_i32 s48, s49, 0x1001c                                // 000000964BFC: 93B0FF31 0001001C
	s_lshr_b32 s3, s11, 28                                     // 000000964C04: 85039C0B
	s_lshr_b64 s[0:1], s[48:49], 29                            // 000000964C08: 85809D30
	s_add_i32 s3, s30, s3                                      // 000000964C0C: 8103031E
	s_add_i32 s0, s0, 7                                        // 000000964C10: 81008700
	s_lshl_b32 s1, s49, 3                                      // 000000964C14: 84018331
	s_ashr_i32 s0, s0, 3                                       // 000000964C18: 86008300
	s_lshl_b32 s4, s31, 3                                      // 000000964C1C: 8404831F
	.long 0xd72c0001                                           // 000000964C20: D72C0001
	v_cndmask_b32_e32 v1, s0, v19, vcc_lo                      // 000000964C24: 02022600
	v_lshlrev_b32_e32 v21, 2, v20                              // 000000964C28: 302A2882
	s_waitcnt lgkmcnt(0)                                       // 000000964C2C: BF89FC07
	s_barrier                                                  // 000000964C30: BFBD0000
	buffer_gl0_inv                                             // 000000964C34: E0AC0000 00000000
	v_add_nc_u32_e32 v2, s0, v1                                // 000000964C3C: 4A040200
	s_ashr_i32 s0, s3, 4                                       // 000000964C40: 86008403
	s_ashr_i32 s3, s4, 31                                      // 000000964C44: 86039F04
	s_mul_hi_i32 s5, s10, s0                                   // 000000964C48: 9705000A
	s_mul_i32 s0, s10, s0                                      // 000000964C4C: 9600000A
	v_min_i32_e32 v23, s1, v2                                  // 000000964C50: 222E0401
	s_add_u32 s0, s0, s4                                       // 000000964C54: 80000400
	s_addc_u32 s1, s5, s3                                      // 000000964C58: 82010305
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000964C5C: BF870099
	s_lshl_b64 s[4:5], s[0:1], 10                              // 000000964C60: 84848A00
	v_cmp_lt_i32_e32 vcc_lo, v1, v23                           // 000000964C64: 7C822F01
	s_add_u32 s1, s22, s4                                      // 000000964C68: 80010416
	s_addc_u32 s3, s23, s5                                     // 000000964C6C: 82030517
	s_and_saveexec_b32 s4, vcc_lo                              // 000000964C70: BE84206A
	s_cbranch_execz 93                                         // 000000964C74: BFA5005D <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_dn_tsILi4ELi8ELi4ELb0EEEvPKjPKDF16_PKiS5_PtNS0_4HtSdEiNS0_6HtFoldE+0xaec>
	.long 0xd7010002                                           // 000000964C78: D7010002
	v_cndmask_b32_e32 v0, v20, v129, vcc_lo                    // 000000964C7C: 02010314
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000964C80: BF870121
	v_cndmask_b32_e64 v3, v2, 31, s0                           // 000000964C84: D5010003 00013F02
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000964C8C: 3404029F
	.long 0xd44c0000                                           // 000000964C90: D44C0000
	v_cndmask_b32_e32 v1, 31, v3, vcc_lo                       // 000000964C94: 0202069F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000964C98: BF870091
	v_cndmask_b32_e64 v5, 0xe1, 1, s0                          // 000000964C9C: D5010005 000102FF 000000E1
	v_dual_mov_b32 v4, 0 :: v_dual_add_nc_u32 v7, v5, v3       // 000000964CA8: CA200080 04060705
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000964CB0: BF870114
	.long 0xd73c0005                                           // 000000964CB4: D73C0005
	v_cndmask_b32_e32 v1, 10, v1, vcc_lo                       // 000000964CB8: 0202028A
	.long 0xd73c0002                                           // 000000964CBC: D73C0002
	v_cndmask_b32_e32 v1, 2, v3, vcc_lo                        // 000000964CC0: 02020682
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000964CC4: BF870223
	v_lshlrev_b32_e32 v4, 24, v7                               // 000000964CC8: 30080E98
	v_bfe_i32 v7, v7, 7, 1                                     // 000000964CCC: D6110007 02050F07
	.long 0xd7000008                                           // 000000964CD4: D7000008
	v_cndmask_b32_e32 v1, s1, v5, vcc_lo                       // 000000964CD8: 02020A01
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000964CDC: BF870211
	v_add_co_ci_u32_e64 v9, null, s3, v6, s0                   // 000000964CE0: D5207C09 00020C03
	v_ashrrev_i32_e32 v6, 22, v4                               // 000000964CE8: 340C0896
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000964CEC: BF870093
	.long 0xd7000004                                           // 000000964CF0: D7000004
	v_cndmask_b32_e32 v1, v8, v2, vcc_lo                       // 000000964CF4: 02020508
	v_add_co_ci_u32_e64 v5, null, v9, v3, s0                   // 000000964CF8: D5207C05 00020709
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000964D00: BF870093
	.long 0xd7000006                                           // 000000964D04: D7000006
	v_cndmask_b32_e32 v1, v8, v6, vcc_lo                       // 000000964D08: 02020D08
	v_add_co_ci_u32_e64 v7, null, v9, v7, s0                   // 000000964D0C: D5207C07 00020F09
	.long 0xd7000008                                           // 000000964D14: D7000008
	v_cndmask_b32_e32 v1, v8, v21, vcc_lo                      // 000000964D18: 02022B08
	s_delay_alu instid0(VALU_DEP_1)                            // 000000964D1C: BF870001
	v_add_co_ci_u32_e64 v9, null, 0, v9, s0                    // 000000964D20: D5207C09 00021280
	s_clause 0x17                                              // 000000964D28: BF850017
	global_load_b32 v2, v[4:5], off                            // 000000964D2C: DC520000 027C0004
	global_load_b32 v92, v[4:5], off offset:128                // 000000964D34: DC520080 5C7C0004
	global_load_b32 v89, v[4:5], off offset:256                // 000000964D3C: DC520100 597C0004
	global_load_b32 v86, v[4:5], off offset:384                // 000000964D44: DC520180 567C0004
	global_load_b32 v83, v[4:5], off offset:512                // 000000964D4C: DC520200 537C0004
	global_load_b32 v80, v[4:5], off offset:640                // 000000964D54: DC520280 507C0004
	global_load_b32 v77, v[4:5], off offset:768                // 000000964D5C: DC520300 4D7C0004
	global_load_b32 v59, v[4:5], off offset:896                // 000000964D64: DC520380 3B7C0004
	global_load_b32 v4, v[6:7], off                            // 000000964D6C: DC520000 047C0006
	global_load_b32 v93, v[6:7], off offset:128                // 000000964D74: DC520080 5D7C0006
	global_load_b32 v90, v[6:7], off offset:256                // 000000964D7C: DC520100 5A7C0006
	global_load_b32 v87, v[6:7], off offset:384                // 000000964D84: DC520180 577C0006
	global_load_b32 v84, v[6:7], off offset:512                // 000000964D8C: DC520200 547C0006
	global_load_b32 v81, v[6:7], off offset:640                // 000000964D94: DC520280 517C0006
	global_load_b32 v78, v[6:7], off offset:768                // 000000964D9C: DC520300 4E7C0006
	global_load_b32 v60, v[6:7], off offset:896                // 000000964DA4: DC520380 3C7C0006
	global_load_b32 v3, v[8:9], off                            // 000000964DAC: DC520000 037C0008
	global_load_b32 v91, v[8:9], off offset:128                // 000000964DB4: DC520080 5B7C0008
	global_load_b32 v88, v[8:9], off offset:256                // 000000964DBC: DC520100 587C0008
	global_load_b32 v85, v[8:9], off offset:384                // 000000964DC4: DC520180 557C0008
	global_load_b32 v82, v[8:9], off offset:512                // 000000964DCC: DC520200 527C0008
	global_load_b32 v79, v[8:9], off offset:640                // 000000964DD4: DC520280 4F7C0008
	global_load_b32 v76, v[8:9], off offset:768                // 000000964DDC: DC520300 4C7C0008
	global_load_b32 v58, v[8:9], off offset:896                // 000000964DE4: DC520380 3A7C0008
	s_or_b32 exec_lo, exec_lo, s4                              // 000000964DEC: 8C7E047E
	v_dual_mov_b32 v22, 0 :: v_dual_mov_b32 v25, 0             // 000000964DF0: CA100080 16180080
	v_dual_mov_b32 v24, 0 :: v_dual_mov_b32 v27, 0             // 000000964DF8: CA100080 181A0080
	v_dual_mov_b32 v26, 0 :: v_dual_mov_b32 v31, 0             // 000000964E00: CA100080 1A1E0080
	v_dual_mov_b32 v28, 0 :: v_dual_mov_b32 v33, 0             // 000000964E08: CA100080 1C200080
	v_dual_mov_b32 v30, 0 :: v_dual_mov_b32 v35, 0             // 000000964E10: CA100080 1E220080
	v_dual_mov_b32 v32, 0 :: v_dual_mov_b32 v37, 0             // 000000964E18: CA100080 20240080
	v_dual_mov_b32 v34, 0 :: v_dual_mov_b32 v39, 0             // 000000964E20: CA100080 22260080
	v_dual_mov_b32 v36, 0 :: v_dual_mov_b32 v43, 0             // 000000964E28: CA100080 242A0080
	v_dual_mov_b32 v38, 0 :: v_dual_mov_b32 v45, 0             // 000000964E30: CA100080 262C0080
	v_dual_mov_b32 v40, 0 :: v_dual_mov_b32 v29, 0             // 000000964E38: CA100080 281C0080
	v_dual_mov_b32 v42, 0 :: v_dual_mov_b32 v49, 0             // 000000964E40: CA100080 2A300080
	v_dual_mov_b32 v44, 0 :: v_dual_mov_b32 v53, 0             // 000000964E48: CA100080 2C340080
	v_dual_mov_b32 v46, 0 :: v_dual_mov_b32 v47, 0             // 000000964E50: CA100080 2E2E0080
	v_dual_mov_b32 v48, 0 :: v_dual_mov_b32 v41, 0             // 000000964E58: CA100080 30280080
	v_dual_mov_b32 v52, 0 :: v_dual_mov_b32 v51, 0             // 000000964E60: CA100080 34320080
	v_mov_b32_e32 v50, 0                                       // 000000964E68: 7E640280
	v_mov_b32_e32 v54, 0                                       // 000000964E6C: 7E6C0280
	s_ashr_i32 s11, s10, 31                                    // 000000964E70: 860B9F0A
	s_and_saveexec_b32 s0, vcc_lo                              // 000000964E74: BE80206A
	s_cbranch_execz 1080                                       // 000000964E78: BFA50438 <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_dn_tsILi4ELi8ELi4ELb0EEEvPKjPKDF16_PKiS5_PtNS0_4HtSdEiNS0_6HtFoldE+0x1c5c>
	v_dual_mov_b32 v22, 0 :: v_dual_add_nc_u32 v5, -1, v0      // 000000964E7C: CA200080 160400C1
	v_dual_mov_b32 v24, 0 :: v_dual_and_b32 v55, 16, v0        // 000000964E84: CA240080 18360090
	v_dual_mov_b32 v25, 0 :: v_dual_lshlrev_b32 v56, 2, v20    // 000000964E8C: CA220080 19382882
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000964E94: BF870123
	v_dual_mov_b32 v26, 0 :: v_dual_and_b32 v5, 31, v5         // 000000964E98: CA240080 1A040A9F
	v_dual_mov_b32 v27, 0 :: v_dual_mov_b32 v28, 0             // 000000964EA0: CA100080 1B1C0080
	v_dual_mov_b32 v30, 0 :: v_dual_lshlrev_b32 v57, 2, v5     // 000000964EA8: CA220080 1E380A82
	v_dual_mov_b32 v31, 0 :: v_dual_mov_b32 v32, 0             // 000000964EB0: CA100080 1F200080
	v_dual_mov_b32 v33, 0 :: v_dual_mov_b32 v34, 0             // 000000964EB8: CA100080 21220080
	v_dual_mov_b32 v35, 0 :: v_dual_mov_b32 v36, 0             // 000000964EC0: CA100080 23240080
	v_dual_mov_b32 v37, 0 :: v_dual_mov_b32 v38, 0             // 000000964EC8: CA100080 25260080
	v_dual_mov_b32 v39, 0 :: v_dual_mov_b32 v40, 0             // 000000964ED0: CA100080 27280080
	v_dual_mov_b32 v42, 0 :: v_dual_mov_b32 v43, 0             // 000000964ED8: CA100080 2A2A0080
	v_dual_mov_b32 v44, 0 :: v_dual_mov_b32 v45, 0             // 000000964EE0: CA100080 2C2C0080
	v_dual_mov_b32 v46, 0 :: v_dual_mov_b32 v29, 0             // 000000964EE8: CA100080 2E1C0080
	v_dual_mov_b32 v48, 0 :: v_dual_mov_b32 v49, 0             // 000000964EF0: CA100080 30300080
	v_dual_mov_b32 v52, 0 :: v_dual_mov_b32 v53, 0             // 000000964EF8: CA100080 34340080
	v_dual_mov_b32 v47, 0 :: v_dual_mov_b32 v50, 0             // 000000964F00: CA100080 2F320080
	v_dual_mov_b32 v41, 0 :: v_dual_mov_b32 v54, 0             // 000000964F08: CA100080 29360080
	v_mov_b32_e32 v51, 0                                       // 000000964F10: 7E660280
	s_mov_b32 s4, 0                                            // 000000964F14: BE840080
	s_movk_i32 s5, 0x1eee                                      // 000000964F18: B0051EEE
	s_branch 980                                               // 000000964F1C: BFA003D4 <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_dn_tsILi4ELi8ELi4ELb0EEEvPKjPKDF16_PKiS5_PtNS0_4HtSdEiNS0_6HtFoldE+0x1b70>
	s_or_b32 exec_lo, exec_lo, s6                              // 000000964F20: 8C7E067E
	s_waitcnt vmcnt(15)                                        // 000000964F24: BF893FF7
	v_alignbit_b32 v2, v2, v4, 16                              // 000000964F28: D6160002 02420902
	v_lshl_or_b32 v13, v1, 5, v55                              // 000000964F30: D656000D 04DD0B01
	s_waitcnt vmcnt(7)                                         // 000000964F38: BF891FF7
	v_bfe_u32 v14, v3, 12, 16                                  // 000000964F3C: D610000E 02411903
	v_bfe_u32 v15, v3, 8, 16                                   // 000000964F44: D610000F 02411103
	v_bfe_u32 v16, v3, 4, 16                                   // 000000964F4C: D6100010 02410903
	v_bfe_u32 v1, v2, 12, 16                                   // 000000964F54: D6100001 02411902
	v_bfe_u32 v5, v2, 8, 16                                    // 000000964F5C: D6100005 02411102
	.long 0xd72c000e                                           // 000000964F64: D72C000E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v14, vcc_lo              // 000000964F68: 02021CFF 83DCD12D
	.long 0xd72c000f                                           // 000000964F70: D72C000F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v15, vcc_lo              // 000000964F74: 02021EFF 83DCD12D
	v_alignbit_b32 v92, v92, v93, 16                           // 000000964F7C: D616005C 0242BB5C
	.long 0xd72c005f                                           // 000000964F84: D72C005F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v1, vcc_lo               // 000000964F88: 020202FF 83DCD12D
	.long 0xd72c0061                                           // 000000964F90: D72C0061
	v_cndmask_b32_e32 v1, 0x83dcd12d, v5, vcc_lo               // 000000964F94: 02020AFF 83DCD12D
	s_waitcnt vmcnt(6)                                         // 000000964F9C: BF891BF7
	v_bfe_u32 v100, v91, 4, 16                                 // 000000964FA0: D6100064 0241095B
	v_alignbit_b32 v89, v89, v90, 16                           // 000000964FA8: D6160059 0242B559
	v_bfe_u32 v93, v92, 12, 16                                 // 000000964FB0: D610005D 0241195C
	v_sad_u8 v14, v14, 0, 0x6400                               // 000000964FB8: D622000E 03FD010E 00006400
	v_sad_u8 v99, v15, 0, 0x6400                               // 000000964FC4: D6220063 03FD010F 00006400
	v_alignbit_b32 v86, v86, v87, 16                           // 000000964FD0: D6160056 0242AF56
	v_sad_u8 v95, v95, 0, 0x6400                               // 000000964FD8: D622005F 03FD015F 00006400
	v_sad_u8 v97, v97, 0, 0x6400                               // 000000964FE4: D6220061 03FD0161 00006400
	.long 0xd72c005d                                           // 000000964FF0: D72C005D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v93, vcc_lo              // 000000964FF4: 0202BAFF 83DCD12D
	v_bfe_u32 v90, v89, 12, 16                                 // 000000964FFC: D610005A 02411959
	v_bfe_u32 v87, v86, 12, 16                                 // 000000965004: D6100057 02411956
	v_and_b32_e32 v95, 0xffff, v95                             // 00000096500C: 36BEBEFF 0000FFFF
	v_alignbit_b32 v83, v83, v84, 16                           // 000000965014: D6160053 0242A953
	v_alignbit_b32 v80, v80, v81, 16                           // 00000096501C: D6160050 0242A350
	.long 0xd72c005a                                           // 000000965024: D72C005A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v90, vcc_lo              // 000000965028: 0202B4FF 83DCD12D
	.long 0xd72c0057                                           // 000000965030: D72C0057
	v_cndmask_b32_e32 v1, 0x83dcd12d, v87, vcc_lo              // 000000965034: 0202AEFF 83DCD12D
	v_lshl_or_b32 v95, v97, 16, v95                            // 00000096503C: D656005F 057D2161
	.long 0xd72c0061                                           // 000000965044: D72C0061
	v_cndmask_b32_e32 v1, 0x83dcd12d, v16, vcc_lo              // 000000965048: 020220FF 83DCD12D
	v_sad_u8 v93, v93, 0, 0x6400                               // 000000965050: D622005D 03FD015D 00006400
	v_bfe_u32 v84, v83, 12, 16                                 // 00000096505C: D6100054 02411953
	v_bfe_u32 v81, v80, 12, 16                                 // 000000965064: D6100051 02411950
	v_pk_fma_f16 v95, v95, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000096506C: CC0E005F 0BFC0B5F 0000C931
	v_and_b32_e32 v4, 0xffff, v2                               // 000000965078: 360804FF 0000FFFF
	v_bfe_u32 v2, v2, 4, 16                                    // 000000965080: D6100002 02410902
	v_sad_u8 v90, v90, 0, 0x6400                               // 000000965088: D622005A 03FD015A 00006400
	v_sad_u8 v97, v97, 0, 0x6400                               // 000000965094: D6220061 03FD0161 00006400
	v_sad_u8 v87, v87, 0, 0x6400                               // 0000009650A0: D6220057 03FD0157 00006400
	.long 0xd72c0060                                           // 0000009650AC: D72C0060
	v_cndmask_b32_e32 v1, 0x83dcd12d, v4, vcc_lo               // 0000009650B0: 020208FF 83DCD12D
	.long 0xd72c0062                                           // 0000009650B8: D72C0062
	v_cndmask_b32_e32 v1, 0x83dcd12d, v2, vcc_lo               // 0000009650BC: 020204FF 83DCD12D
	.long 0xd72c0054                                           // 0000009650C4: D72C0054
	v_cndmask_b32_e32 v1, 0x83dcd12d, v84, vcc_lo              // 0000009650C8: 0202A8FF 83DCD12D
	.long 0xd72c0051                                           // 0000009650D0: D72C0051
	v_cndmask_b32_e32 v1, 0x83dcd12d, v81, vcc_lo              // 0000009650D4: 0202A2FF 83DCD12D
	v_alignbit_b32 v77, v77, v78, 16                           // 0000009650DC: D616004D 02429D4D
	v_alignbit_b32 v59, v59, v60, 16                           // 0000009650E4: D616003B 0242793B
	v_cmp_eq_u32_e32 vcc_lo, v17, v23                          // 0000009650EC: 7C942F11
	v_and_b32_e32 v93, 0xffff, v93                             // 0000009650F0: 36BABAFF 0000FFFF
	v_sad_u8 v96, v96, 0, 0x6400                               // 0000009650F8: D6220060 03FD0160 00006400
	v_sad_u8 v98, v98, 0, 0x6400                               // 000000965104: D6220062 03FD0162 00006400
	v_sad_u8 v84, v84, 0, 0x6400                               // 000000965110: D6220054 03FD0154 00006400
	v_sad_u8 v81, v81, 0, 0x6400                               // 00000096511C: D6220051 03FD0151 00006400
	v_bfe_u32 v78, v77, 12, 16                                 // 000000965128: D610004E 0241194D
	v_lshlrev_b32_e32 v96, 16, v96                             // 000000965130: 30C0C090
	v_bfe_u32 v60, v59, 12, 16                                 // 000000965134: D610003C 0241193B
	s_or_b32 s4, vcc_lo, s4                                    // 00000096513C: 8C04046A
	v_and_b32_e32 v90, 0xffff, v90                             // 000000965140: 36B4B4FF 0000FFFF
	.long 0xd72c004e                                           // 000000965148: D72C004E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 00000096514C: 02029CFF 83DCD12D
	v_and_or_b32 v96, 0xffff, v98, v96                         // 000000965154: D6570060 0582C4FF 0000FFFF
	.long 0xd72c003c                                           // 000000965160: D72C003C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v60, vcc_lo              // 000000965164: 020278FF 83DCD12D
	v_and_b32_e32 v84, 0xffff, v84                             // 00000096516C: 36A8A8FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3)                            // 000000965174: BF870003
	v_pk_fma_f16 v96, v96, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000965178: CC0E0060 0BFC0B60 0000C931
	v_and_b32_e32 v94, 0xffff, v3                              // 000000965184: 36BC06FF 0000FFFF
	ds_load_b128 v[1:4], v13                                   // 00000096518C: DBFC0000 0100000D
	ds_load_b128 v[5:8], v13 offset:5120                       // 000000965194: DBFC1400 0500000D
	ds_load_b128 v[9:12], v13 offset:10240                     // 00000096519C: DBFC2800 0900000D
	v_and_b32_e32 v87, 0xffff, v87                             // 0000009651A4: 36AEAEFF 0000FFFF
	v_sad_u8 v78, v78, 0, 0x6400                               // 0000009651AC: D622004E 03FD014E 00006400
	v_sad_u8 v60, v60, 0, 0x6400                               // 0000009651B8: D622003C 03FD013C 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000009651C4: BF870112
	v_and_b32_e32 v78, 0xffff, v78                             // 0000009651C8: 369C9CFF 0000FFFF
	v_and_b32_e32 v60, 0xffff, v60                             // 0000009651D0: 367878FF 0000FFFF
	s_waitcnt lgkmcnt(2)                                       // 0000009651D8: BF89FC27
	v_dot2acc_f32_f16 v54, v95, v1                             // 0000009651DC: 046C035F
	s_waitcnt lgkmcnt(1)                                       // 0000009651E0: BF89FC17
	v_dot2acc_f32_f16 v51, v95, v5                             // 0000009651E4: 04660B5F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000009651E8: BF8700A1
	v_dot2acc_f32_f16 v51, v96, v6                             // 0000009651EC: 04660D60
	.long 0xd72c005e                                           // 0000009651F0: D72C005E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v94, vcc_lo              // 0000009651F4: 0202BCFF 83DCD12D
	v_sad_u8 v94, v94, 0, 0x6400                               // 0000009651FC: D622005E 03FD015E 00006400
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000965208: BF870091
	v_lshlrev_b32_e32 v94, 16, v94                             // 00000096520C: 30BCBC90
	v_and_or_b32 v94, 0xffff, v97, v94                         // 000000965210: D657005E 057AC2FF 0000FFFF
	v_dual_dot2acc_f32_f16 v54, v96, v2 :: v_dual_and_b32 v97, 0xffff, v92// 00000096521C: CB240560 3660B8FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_2)                            // 000000965228: BF870002
	v_pk_fma_f16 v94, v94, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000096522C: CC0E005E 0BFC0B5E 0000C931
	v_and_b32_e32 v98, 0xffff, v14                             // 000000965238: 36C41CFF 0000FFFF
	ds_load_b128 v[13:16], v13 offset:15360                    // 000000965240: DBFC3C00 0D00000D
	.long 0xd72c0061                                           // 000000965248: D72C0061
	v_cndmask_b32_e32 v1, 0x83dcd12d, v97, vcc_lo              // 00000096524C: 0202C2FF 83DCD12D
	v_lshl_or_b32 v98, v99, 16, v98                            // 000000965254: D6560062 05892163
	v_bfe_u32 v99, v91, 8, 16                                  // 00000096525C: D6100063 0241115B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000965264: BF870212
	v_pk_fma_f16 v98, v98, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000965268: CC0E0062 0BFC0B62 0000C931
	v_sad_u8 v97, v97, 0, 0x6400                               // 000000965274: D6220061 03FD0161 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000965280: BF870113
	.long 0xd72c0063                                           // 000000965284: D72C0063
	v_cndmask_b32_e32 v1, 0x83dcd12d, v99, vcc_lo              // 000000965288: 0202C6FF 83DCD12D
	v_dual_dot2acc_f32_f16 v54, v98, v3 :: v_dual_lshlrev_b32 v97, 16, v97// 000000965290: CB220762 3660C290
	v_dot2acc_f32_f16 v51, v98, v7                             // 000000965298: 04660F62
	s_waitcnt lgkmcnt(0)                                       // 00000096529C: BF89FC07
	v_dot2acc_f32_f16 v41, v95, v13                            // 0000009652A0: 04521B5F
	v_dot2acc_f32_f16 v50, v95, v9                             // 0000009652A4: 0464135F
	v_bfe_u32 v95, v92, 8, 16                                  // 0000009652A8: D610005F 0241115C
	v_bfe_u32 v92, v92, 4, 16                                  // 0000009652B0: D610005C 0241095C
	v_dot2acc_f32_f16 v51, v94, v8                             // 0000009652B8: 0466115E
	v_dot2acc_f32_f16 v41, v96, v14                            // 0000009652BC: 04521D60
	v_dot2acc_f32_f16 v50, v96, v10                            // 0000009652C0: 04641560
	.long 0xd72c005f                                           // 0000009652C4: D72C005F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v95, vcc_lo              // 0000009652C8: 0202BEFF 83DCD12D
	v_bfe_u32 v96, v91, 12, 16                                 // 0000009652D0: D6100060 0241195B
	.long 0xd72c005c                                           // 0000009652D8: D72C005C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v92, vcc_lo              // 0000009652DC: 0202B8FF 83DCD12D
	v_and_b32_e32 v91, 0xffff, v91                             // 0000009652E4: 36B6B6FF 0000FFFF
	v_dot2acc_f32_f16 v50, v98, v11                            // 0000009652EC: 04641762
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000009652F0: BF870224
	.long 0xd72c0060                                           // 0000009652F4: D72C0060
	v_cndmask_b32_e32 v1, 0x83dcd12d, v96, vcc_lo              // 0000009652F8: 0202C0FF 83DCD12D
	v_sad_u8 v95, v95, 0, 0x6400                               // 000000965300: D622005F 03FD015F 00006400
	.long 0xd72c005b                                           // 00000096530C: D72C005B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v91, vcc_lo              // 000000965310: 0202B6FF 83DCD12D
	v_sad_u8 v92, v92, 0, 0x6400                               // 000000965318: D622005C 03FD015C 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000965324: BF8701A3
	v_lshl_or_b32 v93, v95, 16, v93                            // 000000965328: D656005D 0575215F
	v_sad_u8 v96, v96, 0, 0x6400                               // 000000965330: D6220060 03FD0160 00006400
	v_and_or_b32 v92, 0xffff, v92, v97                         // 00000096533C: D657005C 0586B8FF 0000FFFF
	v_sad_u8 v91, v91, 0, 0x6400                               // 000000965348: D622005B 03FD015B 00006400
	s_delay_alu instid0(VALU_DEP_4)                            // 000000965354: BF870004
	v_pk_fma_f16 v93, v93, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000965358: CC0E005D 0BFC0B5D 0000C931
	v_dot2acc_f32_f16 v41, v98, v15                            // 000000965364: 04521F62
	.long 0xd72c0062                                           // 000000965368: D72C0062
	v_cndmask_b32_e32 v1, 0x83dcd12d, v100, vcc_lo             // 00000096536C: 0202C8FF 83DCD12D
	v_pk_fma_f16 v92, v92, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000965374: CC0E005C 0BFC0B5C 0000C931
	v_dual_dot2acc_f32_f16 v54, v94, v4 :: v_dual_lshlrev_b32 v91, 16, v91// 000000965380: CB22095E 365AB690
	v_dual_dot2acc_f32_f16 v52, v93, v9 :: v_dual_and_b32 v95, 0xffff, v96// 000000965388: CB24135D 345EC0FF 0000FFFF
	v_sad_u8 v96, v99, 0, 0x6400                               // 000000965394: D6220060 03FD0163 00006400
	v_dual_dot2acc_f32_f16 v50, v94, v12 :: v_dual_dot2acc_f32_f16 v47, v93, v1// 0000009653A0: CB18195E 322E035D
	v_sad_u8 v97, v98, 0, 0x6400                               // 0000009653A8: D6220061 03FD0162 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009653B4: BF870214
	v_dot2acc_f32_f16 v52, v92, v10                            // 0000009653B8: 0468155C
	v_lshl_or_b32 v95, v96, 16, v95                            // 0000009653BC: D656005F 057D2160
	s_waitcnt vmcnt(5)                                         // 0000009653C4: BF8917F7
	v_bfe_u32 v96, v88, 12, 16                                 // 0000009653C8: D6100060 02411958
	v_dot2acc_f32_f16 v41, v94, v16                            // 0000009653D0: 0452215E
	v_and_or_b32 v91, 0xffff, v97, v91                         // 0000009653D4: D657005B 056EC2FF 0000FFFF
	v_bfe_u32 v97, v88, 8, 16                                  // 0000009653E0: D6100061 02411158
	v_pk_fma_f16 v95, v95, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009653E8: CC0E005F 0BFC0B5F 0000C931
	.long 0xd72c0060                                           // 0000009653F4: D72C0060
	v_cndmask_b32_e32 v1, 0x83dcd12d, v96, vcc_lo              // 0000009653F8: 0202C0FF 83DCD12D
	v_dot2acc_f32_f16 v53, v93, v5                             // 000000965400: 046A0B5D
	v_pk_fma_f16 v91, v91, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000965404: CC0E005B 0BFC0B5B 0000C931
	v_and_b32_e32 v94, 0xffff, v89                             // 000000965410: 36BCB2FF 0000FFFF
	v_dual_dot2acc_f32_f16 v52, v95, v11 :: v_dual_dot2acc_f32_f16 v47, v92, v2// 000000965418: CB18175F 342E055C
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000965420: BF870234
	v_dot2acc_f32_f16 v53, v92, v6                             // 000000965424: 046A0D5C
	v_bfe_u32 v98, v88, 4, 16                                  // 000000965428: D6100062 02410958
	v_and_b32_e32 v88, 0xffff, v88                             // 000000965430: 36B0B0FF 0000FFFF
	v_dot2acc_f32_f16 v52, v91, v12                            // 000000965438: 0468195B
	v_dot2acc_f32_f16 v47, v95, v3                             // 00000096543C: 045E075F
	.long 0xd72c0061                                           // 000000965440: D72C0061
	v_cndmask_b32_e32 v1, 0x83dcd12d, v97, vcc_lo              // 000000965444: 0202C2FF 83DCD12D
	v_sad_u8 v96, v96, 0, 0x6400                               // 00000096544C: D6220060 03FD0160 00006400
	v_dot2acc_f32_f16 v49, v93, v13                            // 000000965458: 04621B5D
	v_bfe_u32 v93, v89, 8, 16                                  // 00000096545C: D610005D 02411159
	v_bfe_u32 v89, v89, 4, 16                                  // 000000965464: D6100059 02410959
	.long 0xd72c005e                                           // 00000096546C: D72C005E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v94, vcc_lo              // 000000965470: 0202BCFF 83DCD12D
	.long 0xd72c0058                                           // 000000965478: D72C0058
	v_cndmask_b32_e32 v1, 0x83dcd12d, v88, vcc_lo              // 00000096547C: 0202B0FF 83DCD12D
	v_and_b32_e32 v96, 0xffff, v96                             // 000000965484: 36C0C0FF 0000FFFF
	.long 0xd72c005d                                           // 00000096548C: D72C005D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v93, vcc_lo              // 000000965490: 0202BAFF 83DCD12D
	v_sad_u8 v97, v97, 0, 0x6400                               // 000000965498: D6220061 03FD0161 00006400
	.long 0xd72c0059                                           // 0000009654A4: D72C0059
	v_cndmask_b32_e32 v1, 0x83dcd12d, v89, vcc_lo              // 0000009654A8: 0202B2FF 83DCD12D
	v_dot2acc_f32_f16 v53, v95, v7                             // 0000009654B0: 046A0F5F
	v_sad_u8 v94, v94, 0, 0x6400                               // 0000009654B4: D622005E 03FD015E 00006400
	v_sad_u8 v88, v88, 0, 0x6400                               // 0000009654C0: D6220058 03FD0158 00006400
	v_dot2acc_f32_f16 v49, v92, v14                            // 0000009654CC: 04621D5C
	v_sad_u8 v93, v93, 0, 0x6400                               // 0000009654D0: D622005D 03FD015D 00006400
	v_lshl_or_b32 v92, v97, 16, v96                            // 0000009654DC: D656005C 05812161
	v_sad_u8 v89, v89, 0, 0x6400                               // 0000009654E4: D6220059 03FD0159 00006400
	v_lshlrev_b32_e32 v88, 16, v88                             // 0000009654F0: 30B0B090
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009654F4: BF870214
	v_lshl_or_b32 v90, v93, 16, v90                            // 0000009654F8: D656005A 0569215D
	v_pk_fma_f16 v92, v92, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000965500: CC0E005C 0BFC0B5C 0000C931
	v_lshlrev_b32_e32 v93, 16, v94                             // 00000096550C: 30BABC90
	.long 0xd72c005e                                           // 000000965510: D72C005E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v98, vcc_lo              // 000000965514: 0202C4FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000096551C: BF870224
	v_pk_fma_f16 v90, v90, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000965520: CC0E005A 0BFC0B5A 0000C931
	v_dot2acc_f32_f16 v53, v91, v8                             // 00000096552C: 046A115B
	v_and_or_b32 v89, 0xffff, v89, v93                         // 000000965530: D6570059 0576B2FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000096553C: BF8701A3
	v_dual_dot2acc_f32_f16 v47, v91, v4 :: v_dual_dot2acc_f32_f16 v48, v90, v5// 000000965540: CB18095B 2F300B5A
	v_sad_u8 v93, v94, 0, 0x6400                               // 000000965548: D622005D 03FD015E 00006400
	v_pk_fma_f16 v89, v89, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000965554: CC0E0059 0BFC0B59 0000C931
	v_dot2acc_f32_f16 v46, v90, v9                             // 000000965560: 045C135A
	v_dot2acc_f32_f16 v29, v90, v1                             // 000000965564: 043A035A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000965568: BF870214
	v_and_or_b32 v88, 0xffff, v93, v88                         // 00000096556C: D6570058 0562BAFF 0000FFFF
	v_dot2acc_f32_f16 v48, v89, v6                             // 000000965578: 04600D59
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000096557C: BF870214
	v_dot2acc_f32_f16 v46, v89, v10                            // 000000965580: 045C1559
	v_dot2acc_f32_f16 v29, v89, v2                             // 000000965584: 043A0559
	s_waitcnt vmcnt(4)                                         // 000000965588: BF8913F7
	v_bfe_u32 v93, v85, 4, 16                                  // 00000096558C: D610005D 02410955
	v_pk_fma_f16 v88, v88, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000965594: CC0E0058 0BFC0B58 0000C931
	v_dot2acc_f32_f16 v48, v92, v7                             // 0000009655A0: 04600F5C
	v_dual_dot2acc_f32_f16 v46, v92, v11 :: v_dual_dot2acc_f32_f16 v45, v90, v13// 0000009655A4: CB18175C 2E2C1B5A
	v_dual_dot2acc_f32_f16 v29, v92, v3 :: v_dual_and_b32 v90, 0xffff, v86// 0000009655AC: CB24075C 1D5AACFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009655B8: BF870193
	v_dual_dot2acc_f32_f16 v49, v95, v15 :: v_dual_dot2acc_f32_f16 v48, v88, v8// 0000009655BC: CB181F5F 31301158
	v_dual_dot2acc_f32_f16 v46, v88, v12 :: v_dual_dot2acc_f32_f16 v45, v89, v14// 0000009655C4: CB181958 2E2C1D59
	v_bfe_u32 v89, v86, 8, 16                                  // 0000009655CC: D6100059 02411156
	v_bfe_u32 v86, v86, 4, 16                                  // 0000009655D4: D6100056 02410956
	.long 0xd72c005a                                           // 0000009655DC: D72C005A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v90, vcc_lo              // 0000009655E0: 0202B4FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009655E8: BF870193
	.long 0xd72c0059                                           // 0000009655EC: D72C0059
	v_cndmask_b32_e32 v1, 0x83dcd12d, v89, vcc_lo              // 0000009655F0: 0202B2FF 83DCD12D
	.long 0xd72c0056                                           // 0000009655F8: D72C0056
	v_cndmask_b32_e32 v1, 0x83dcd12d, v86, vcc_lo              // 0000009655FC: 0202ACFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3)                            // 000000965604: BF870003
	v_sad_u8 v90, v90, 0, 0x6400                               // 000000965608: D622005A 03FD015A 00006400
	v_dot2acc_f32_f16 v49, v91, v16                            // 000000965614: 0462215B
	v_bfe_u32 v91, v85, 12, 16                                 // 000000965618: D610005B 02411955
	v_sad_u8 v89, v89, 0, 0x6400                               // 000000965620: D6220059 03FD0159 00006400
	v_sad_u8 v86, v86, 0, 0x6400                               // 00000096562C: D6220056 03FD0156 00006400
	v_lshlrev_b32_e32 v90, 16, v90                             // 000000965638: 30B4B490
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000096563C: BF870214
	.long 0xd72c005b                                           // 000000965640: D72C005B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v91, vcc_lo              // 000000965644: 0202B6FF 83DCD12D
	v_lshl_or_b32 v87, v89, 16, v87                            // 00000096564C: D6560057 055D2159
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000965654: BF870113
	v_and_or_b32 v86, 0xffff, v86, v90                         // 000000965658: D6570056 056AACFF 0000FFFF
	v_pk_fma_f16 v87, v87, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000965664: CC0E0057 0BFC0B57 0000C931
	v_dot2acc_f32_f16 v29, v88, v4                             // 000000965670: 043A0958
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000965674: BF870223
	v_pk_fma_f16 v86, v86, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000965678: CC0E0056 0BFC0B56 0000C931
	v_sad_u8 v91, v91, 0, 0x6400                               // 000000965684: D622005B 03FD015B 00006400
	v_dot2acc_f32_f16 v44, v87, v1                             // 000000965690: 04580357
	v_dual_dot2acc_f32_f16 v42, v87, v9 :: v_dual_dot2acc_f32_f16 v45, v92, v15// 000000965694: CB181357 2A2C1F5C
	v_bfe_u32 v92, v85, 8, 16                                  // 00000096569C: D610005C 02411155
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009656A4: BF870193
	v_dual_dot2acc_f32_f16 v44, v86, v2 :: v_dual_and_b32 v85, 0xffff, v85// 0000009656A8: CB240556 2C54AAFF 0000FFFF
	v_dual_dot2acc_f32_f16 v42, v86, v10 :: v_dual_dot2acc_f32_f16 v45, v88, v16// 0000009656B4: CB181556 2A2C2158
	v_dot2acc_f32_f16 v40, v87, v13                            // 0000009656BC: 04501B57
	s_delay_alu instid0(VALU_DEP_3)                            // 0000009656C0: BF870003
	.long 0xd72c0055                                           // 0000009656C4: D72C0055
	v_cndmask_b32_e32 v1, 0x83dcd12d, v85, vcc_lo              // 0000009656C8: 0202AAFF 83DCD12D
	.long 0xd72c0058                                           // 0000009656D0: D72C0058
	v_cndmask_b32_e32 v1, 0x83dcd12d, v93, vcc_lo              // 0000009656D4: 0202BAFF 83DCD12D
	.long 0xd72c005c                                           // 0000009656DC: D72C005C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v92, vcc_lo              // 0000009656E0: 0202B8FF 83DCD12D
	v_mov_b32_e32 v93, v74                                     // 0000009656E8: 7EBA034A
	v_dot2acc_f32_f16 v40, v86, v14                            // 0000009656EC: 04501D56
	v_sad_u8 v85, v85, 0, 0x6400                               // 0000009656F0: D6220055 03FD0155 00006400
	v_sad_u8 v88, v88, 0, 0x6400                               // 0000009656FC: D6220058 03FD0158 00006400
	v_sad_u8 v90, v92, 0, 0x6400                               // 000000965708: D622005A 03FD015C 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000965714: BF870093
	v_dual_mov_b32 v92, v68 :: v_dual_lshlrev_b32 v85, 16, v85 // 000000965718: CA220144 5C54AA90
	v_and_or_b32 v85, 0xffff, v88, v85                         // 000000965720: D6570055 0556B0FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 00000096572C: BF870141
	v_pk_fma_f16 v85, v85, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000965730: CC0E0055 0BFC0B55 0000C931
	v_and_b32_e32 v89, 0xffff, v91                             // 00000096573C: 36B2B6FF 0000FFFF
	s_waitcnt vmcnt(3)                                         // 000000965744: BF890FF7
	v_bfe_u32 v91, v82, 4, 16                                  // 000000965748: D610005B 02410952
	v_lshl_or_b32 v89, v90, 16, v89                            // 000000965750: D6560059 0565215A
	v_bfe_u32 v90, v82, 8, 16                                  // 000000965758: D610005A 02411152
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 000000965760: BF870252
	v_pk_fma_f16 v88, v89, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000965764: CC0E0058 0BFC0B59 0000C931
	v_dot2acc_f32_f16 v43, v87, v5                             // 000000965770: 04560B57
	v_bfe_u32 v89, v82, 12, 16                                 // 000000965774: D6100059 02411952
	v_and_b32_e32 v82, 0xffff, v82                             // 00000096577C: 36A4A4FF 0000FFFF
	.long 0xd72c005a                                           // 000000965784: D72C005A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v90, vcc_lo              // 000000965788: 0202B4FF 83DCD12D
	v_dual_dot2acc_f32_f16 v42, v88, v11 :: v_dual_dot2acc_f32_f16 v43, v86, v6// 000000965790: CB181758 2A2A0D56
	v_bfe_u32 v86, v83, 8, 16                                  // 000000965798: D6100056 02411153
	.long 0xd72c0059                                           // 0000009657A0: D72C0059
	v_cndmask_b32_e32 v1, 0x83dcd12d, v89, vcc_lo              // 0000009657A4: 0202B2FF 83DCD12D
	.long 0xd72c0052                                           // 0000009657AC: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 0000009657B0: 0202A4FF 83DCD12D
	v_dot2acc_f32_f16 v44, v88, v3                             // 0000009657B8: 04580758
	v_dot2acc_f32_f16 v43, v88, v7                             // 0000009657BC: 04560F58
	.long 0xd72c0056                                           // 0000009657C0: D72C0056
	v_cndmask_b32_e32 v1, 0x83dcd12d, v86, vcc_lo              // 0000009657C4: 0202ACFF 83DCD12D
	v_sad_u8 v90, v90, 0, 0x6400                               // 0000009657CC: D622005A 03FD015A 00006400
	v_dot2acc_f32_f16 v42, v85, v12                            // 0000009657D8: 04541955
	v_dot2acc_f32_f16 v44, v85, v4                             // 0000009657DC: 04580955
	v_dot2acc_f32_f16 v43, v85, v8                             // 0000009657E0: 04561155
	v_sad_u8 v89, v89, 0, 0x6400                               // 0000009657E4: D6220059 03FD0159 00006400
	v_sad_u8 v82, v82, 0, 0x6400                               // 0000009657F0: D6220052 03FD0152 00006400
	v_sad_u8 v86, v86, 0, 0x6400                               // 0000009657FC: D6220056 03FD0156 00006400
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000965808: BF870091
	v_lshl_or_b32 v84, v86, 16, v84                            // 00000096580C: D6560054 05512156
	v_pk_fma_f16 v84, v84, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000965814: CC0E0054 0BFC0B54 0000C931
	v_and_b32_e32 v87, 0xffff, v83                             // 000000965820: 36AEA6FF 0000FFFF
	v_bfe_u32 v83, v83, 4, 16                                  // 000000965828: D6100053 02410953
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000965830: BF870223
	v_dual_dot2acc_f32_f16 v39, v84, v1 :: v_dual_lshlrev_b32 v82, 16, v82// 000000965834: CB220354 2752A490
	v_dot2acc_f32_f16 v38, v84, v5                             // 00000096583C: 044C0B54
	.long 0xd72c0057                                           // 000000965840: D72C0057
	v_cndmask_b32_e32 v1, 0x83dcd12d, v87, vcc_lo              // 000000965844: 0202AEFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4)                            // 00000096584C: BF870004
	.long 0xd72c0053                                           // 000000965850: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v83, vcc_lo              // 000000965854: 0202A6FF 83DCD12D
	v_dot2acc_f32_f16 v37, v84, v9                             // 00000096585C: 044A1354
	v_dot2acc_f32_f16 v40, v88, v15                            // 000000965860: 04501F58
	v_dot2acc_f32_f16 v36, v84, v13                            // 000000965864: 04481B54
	v_bfe_u32 v84, v80, 8, 16                                  // 000000965868: D6100054 02411150
	s_waitcnt vmcnt(2)                                         // 000000965870: BF890BF7
	v_bfe_u32 v88, v79, 4, 16                                  // 000000965874: D6100058 0241094F
	v_sad_u8 v87, v87, 0, 0x6400                               // 00000096587C: D6220057 03FD0157 00006400
	v_sad_u8 v83, v83, 0, 0x6400                               // 000000965888: D6220053 03FD0153 00006400
	v_dot2acc_f32_f16 v40, v85, v16                            // 000000965894: 04502155
	v_bfe_u32 v85, v79, 12, 16                                 // 000000965898: D6100055 0241194F
	.long 0xd72c0054                                           // 0000009658A0: D72C0054
	v_cndmask_b32_e32 v1, 0x83dcd12d, v84, vcc_lo              // 0000009658A4: 0202A8FF 83DCD12D
	v_lshlrev_b32_e32 v87, 16, v87                             // 0000009658AC: 30AEAE90
	.long 0xd72c0058                                           // 0000009658B0: D72C0058
	v_cndmask_b32_e32 v1, 0x83dcd12d, v88, vcc_lo              // 0000009658B4: 0202B0FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009658BC: BF870194
	.long 0xd72c0055                                           // 0000009658C0: D72C0055
	v_cndmask_b32_e32 v1, 0x83dcd12d, v85, vcc_lo              // 0000009658C4: 0202AAFF 83DCD12D
	v_and_or_b32 v83, 0xffff, v83, v87                         // 0000009658CC: D6570053 055EA6FF 0000FFFF
	v_sad_u8 v84, v84, 0, 0x6400                               // 0000009658D8: D6220054 03FD0154 00006400
	s_delay_alu instid0(VALU_DEP_2)                            // 0000009658E4: BF870002
	v_pk_fma_f16 v83, v83, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009658E8: CC0E0053 0BFC0B53 0000C931
	v_and_b32_e32 v86, 0xffff, v89                             // 0000009658F4: 36ACB2FF 0000FFFF
	.long 0xd72c0059                                           // 0000009658FC: D72C0059
	v_cndmask_b32_e32 v1, 0x83dcd12d, v91, vcc_lo              // 000000965900: 0202B6FF 83DCD12D
	v_sad_u8 v85, v85, 0, 0x6400                               // 000000965908: D6220055 03FD0155 00006400
	v_mov_b32_e32 v91, v74                                     // 000000965914: 7EB6034A
	v_dot2acc_f32_f16 v39, v83, v2                             // 000000965918: 044E0553
	v_lshl_or_b32 v86, v90, 16, v86                            // 00000096591C: D6560056 0559215A
	v_dot2acc_f32_f16 v38, v83, v6                             // 000000965924: 044C0D53
	v_dot2acc_f32_f16 v37, v83, v10                            // 000000965928: 044A1553
	v_dual_dot2acc_f32_f16 v36, v83, v14 :: v_dual_and_b32 v83, 0xffff, v80// 00000096592C: CB241D53 2452A0FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4)                            // 000000965938: BF870004
	v_pk_fma_f16 v86, v86, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000096593C: CC0E0056 0BFC0B56 0000C931
	v_sad_u8 v87, v89, 0, 0x6400                               // 000000965948: D6220057 03FD0159 00006400
	v_bfe_u32 v80, v80, 4, 16                                  // 000000965954: D6100050 02410950
	v_and_b32_e32 v81, 0xffff, v81                             // 00000096595C: 36A2A2FF 0000FFFF
	.long 0xd72c0053                                           // 000000965964: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v83, vcc_lo              // 000000965968: 0202A6FF 83DCD12D
	v_dot2acc_f32_f16 v39, v86, v3                             // 000000965970: 044E0756
	v_dot2acc_f32_f16 v38, v86, v7                             // 000000965974: 044C0F56
	v_dot2acc_f32_f16 v37, v86, v11                            // 000000965978: 044A1756
	v_and_or_b32 v82, 0xffff, v87, v82                         // 00000096597C: D6570052 054AAEFF 0000FFFF
	v_bfe_u32 v87, v79, 8, 16                                  // 000000965988: D6100057 0241114F
	.long 0xd72c0050                                           // 000000965990: D72C0050
	v_cndmask_b32_e32 v1, 0x83dcd12d, v80, vcc_lo              // 000000965994: 0202A0FF 83DCD12D
	v_dot2acc_f32_f16 v36, v86, v15                            // 00000096599C: 04481F56
	v_sad_u8 v83, v83, 0, 0x6400                               // 0000009659A0: D6220053 03FD0153 00006400
	v_pk_fma_f16 v82, v82, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009659AC: CC0E0052 0BFC0B52 0000C931
	.long 0xd72c0057                                           // 0000009659B8: D72C0057
	v_cndmask_b32_e32 v1, 0x83dcd12d, v87, vcc_lo              // 0000009659BC: 0202AEFF 83DCD12D
	v_lshl_or_b32 v81, v84, 16, v81                            // 0000009659C4: D6560051 05452154
	v_and_b32_e32 v79, 0xffff, v79                             // 0000009659CC: 369E9EFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4)                            // 0000009659D4: BF870004
	v_dual_dot2acc_f32_f16 v36, v82, v16 :: v_dual_lshlrev_b32 v83, 16, v83// 0000009659D8: CB222152 2452A690
	v_sad_u8 v80, v80, 0, 0x6400                               // 0000009659E0: D6220050 03FD0150 00006400
	v_dot2acc_f32_f16 v38, v82, v8                             // 0000009659EC: 044C1152
	v_pk_fma_f16 v81, v81, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009659F0: CC0E0051 0BFC0B51 0000C931
	v_sad_u8 v84, v87, 0, 0x6400                               // 0000009659FC: D6220054 03FD0157 00006400
	.long 0xd72c004f                                           // 000000965A08: D72C004F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v79, vcc_lo              // 000000965A0C: 02029EFF 83DCD12D
	v_and_or_b32 v80, 0xffff, v80, v83                         // 000000965A14: D6570050 054EA0FF 0000FFFF
	v_and_b32_e32 v83, 0xffff, v85                             // 000000965A20: 36A6AAFF 0000FFFF
	v_dual_dot2acc_f32_f16 v39, v82, v4 :: v_dual_dot2acc_f32_f16 v34, v81, v5// 000000965A28: CB180952 27220B51
	v_sad_u8 v85, v88, 0, 0x6400                               // 000000965A30: D6220055 03FD0158 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000965A3C: BF870214
	v_pk_fma_f16 v80, v80, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000965A40: CC0E0050 0BFC0B50 0000C931
	v_lshl_or_b32 v83, v84, 16, v83                            // 000000965A4C: D6560053 054D2154
	v_dot2acc_f32_f16 v37, v82, v12                            // 000000965A54: 044A1952
	v_sad_u8 v79, v79, 0, 0x6400                               // 000000965A58: D622004F 03FD014F 00006400
	v_and_b32_e32 v82, 0xffff, v77                             // 000000965A64: 36A49AFF 0000FFFF
	v_dot2acc_f32_f16 v34, v80, v6                             // 000000965A6C: 04440D50
	v_pk_fma_f16 v83, v83, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000965A70: CC0E0053 0BFC0B53 0000C931
	v_dot2acc_f32_f16 v35, v81, v1                             // 000000965A7C: 04460351
	v_dual_dot2acc_f32_f16 v32, v81, v13 :: v_dual_lshlrev_b32 v79, 16, v79// 000000965A80: CB221B51 204E9E90
	v_bfe_u32 v84, v77, 8, 16                                  // 000000965A88: D6100054 0241114D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000965A90: BF870193
	v_dual_dot2acc_f32_f16 v34, v83, v7 :: v_dual_dot2acc_f32_f16 v35, v80, v2// 000000965A94: CB180F53 22220550
	v_and_or_b32 v79, 0xffff, v85, v79                         // 000000965A9C: D657004F 053EAAFF 0000FFFF
	v_bfe_u32 v77, v77, 4, 16                                  // 000000965AA8: D610004D 0241094D
	.long 0xd72c0052                                           // 000000965AB0: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 000000965AB4: 0202A4FF 83DCD12D
	s_waitcnt vmcnt(1)                                         // 000000965ABC: BF8907F7
	v_bfe_u32 v85, v76, 12, 16                                 // 000000965AC0: D6100055 0241194C
	.long 0xd72c0054                                           // 000000965AC8: D72C0054
	v_cndmask_b32_e32 v1, 0x83dcd12d, v84, vcc_lo              // 000000965ACC: 0202A8FF 83DCD12D
	v_dot2acc_f32_f16 v33, v81, v9                             // 000000965AD4: 04421351
	v_bfe_u32 v86, v76, 8, 16                                  // 000000965AD8: D6100056 0241114C
	.long 0xd72c004d                                           // 000000965AE0: D72C004D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v77, vcc_lo              // 000000965AE4: 02029AFF 83DCD12D
	v_bfe_u32 v87, v76, 4, 16                                  // 000000965AEC: D6100057 0241094C
	.long 0xd72c0055                                           // 000000965AF4: D72C0055
	v_cndmask_b32_e32 v1, 0x83dcd12d, v85, vcc_lo              // 000000965AF8: 0202AAFF 83DCD12D
	v_and_b32_e32 v76, 0xffff, v76                             // 000000965B00: 369898FF 0000FFFF
	v_pk_fma_f16 v79, v79, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000965B08: CC0E004F 0BFC0B4F 0000C931
	v_dot2acc_f32_f16 v35, v83, v3                             // 000000965B14: 04460753
	v_sad_u8 v82, v82, 0, 0x6400                               // 000000965B18: D6220052 03FD0152 00006400
	v_sad_u8 v84, v84, 0, 0x6400                               // 000000965B24: D6220054 03FD0154 00006400
	.long 0xd72c0056                                           // 000000965B30: D72C0056
	v_cndmask_b32_e32 v1, 0x83dcd12d, v86, vcc_lo              // 000000965B34: 0202ACFF 83DCD12D
	.long 0xd72c004c                                           // 000000965B3C: D72C004C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v76, vcc_lo              // 000000965B40: 020298FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4)                            // 000000965B48: BF870004
	v_dual_dot2acc_f32_f16 v35, v79, v4 :: v_dual_lshlrev_b32 v82, 16, v82// 000000965B4C: CB22094F 2352A490
	v_sad_u8 v77, v77, 0, 0x6400                               // 000000965B54: D622004D 03FD014D 00006400
	v_sad_u8 v85, v85, 0, 0x6400                               // 000000965B60: D6220055 03FD0155 00006400
	v_lshl_or_b32 v78, v84, 16, v78                            // 000000965B6C: D656004E 05392154
	.long 0xd72c0051                                           // 000000965B74: D72C0051
	v_cndmask_b32_e32 v1, 0x83dcd12d, v87, vcc_lo              // 000000965B78: 0202AEFF 83DCD12D
	v_dot2acc_f32_f16 v33, v80, v10                            // 000000965B80: 04421550
	v_and_or_b32 v77, 0xffff, v77, v82                         // 000000965B84: D657004D 054A9AFF 0000FFFF
	v_and_b32_e32 v82, 0xffff, v85                             // 000000965B90: 36A4AAFF 0000FFFF
	v_sad_u8 v84, v86, 0, 0x6400                               // 000000965B98: D6220054 03FD0156 00006400
	v_sad_u8 v76, v76, 0, 0x6400                               // 000000965BA4: D622004C 03FD014C 00006400
	v_pk_fma_f16 v78, v78, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000965BB0: CC0E004E 0BFC0B4E 0000C931
	v_dual_dot2acc_f32_f16 v33, v83, v11 :: v_dual_dot2acc_f32_f16 v32, v80, v14// 000000965BBC: CB181753 21201D50
	v_pk_fma_f16 v77, v77, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000965BC4: CC0E004D 0BFC0B4D 0000C931
	v_lshl_or_b32 v80, v84, 16, v82                            // 000000965BD0: D6560050 05492154
	v_sad_u8 v81, v81, 0, 0x6400                               // 000000965BD8: D6220051 03FD0151 00006400
	v_dual_dot2acc_f32_f16 v31, v78, v1 :: v_dual_lshlrev_b32 v76, 16, v76// 000000965BE4: CB22034E 1F4C9890
	v_dual_dot2acc_f32_f16 v33, v79, v12 :: v_dual_dot2acc_f32_f16 v30, v78, v5// 000000965BEC: CB18194F 211E0B4E
	v_dot2acc_f32_f16 v28, v78, v9                             // 000000965BF4: 0438134E
	v_pk_fma_f16 v80, v80, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000965BF8: CC0E0050 0BFC0B50 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000965C04: BF870244
	v_and_or_b32 v76, 0xffff, v81, v76                         // 000000965C08: D657004C 0532A2FF 0000FFFF
	v_dot2acc_f32_f16 v31, v77, v2                             // 000000965C14: 043E054D
	v_dot2acc_f32_f16 v30, v77, v6                             // 000000965C18: 043C0D4D
	v_dual_dot2acc_f32_f16 v32, v83, v15 :: v_dual_dot2acc_f32_f16 v27, v78, v13// 000000965C1C: CB181F53 201A1B4E
	v_pk_fma_f16 v76, v76, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000965C24: CC0E004C 0BFC0B4C 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000965C30: BF870194
	v_dual_dot2acc_f32_f16 v31, v80, v3 :: v_dual_dot2acc_f32_f16 v28, v77, v10// 000000965C34: CB180750 1F1C154D
	v_dual_dot2acc_f32_f16 v34, v79, v8 :: v_dual_dot2acc_f32_f16 v27, v77, v14// 000000965C3C: CB18114F 221A1D4D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000965C44: BF870194
	v_dot2acc_f32_f16 v32, v79, v16                            // 000000965C48: 0440214F
	v_dot2acc_f32_f16 v31, v76, v4                             // 000000965C4C: 043E094C
	s_delay_alu instid0(VALU_DEP_4)                            // 000000965C50: BF870004
	v_dot2acc_f32_f16 v28, v80, v11                            // 000000965C54: 04381750
	v_bfe_u32 v79, v59, 8, 16                                  // 000000965C58: D610004F 0241113B
	s_waitcnt vmcnt(0)                                         // 000000965C60: BF8903F7
	v_bfe_u32 v81, v58, 12, 16                                 // 000000965C64: D6100051 0241193A
	v_bfe_u32 v82, v58, 8, 16                                  // 000000965C6C: D6100052 0241113A
	v_bfe_u32 v83, v58, 4, 16                                  // 000000965C74: D6100053 0241093A
	v_dot2acc_f32_f16 v27, v80, v15                            // 000000965C7C: 04361F50
	.long 0xd72c004f                                           // 000000965C80: D72C004F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v79, vcc_lo              // 000000965C84: 02029EFF 83DCD12D
	v_dual_mov_b32 v85, v72 :: v_dual_and_b32 v58, 0xffff, v58 // 000000965C8C: CA240148 553A74FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000965C98: BF870214
	.long 0xd72c004d                                           // 000000965C9C: D72C004D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v83, vcc_lo              // 000000965CA0: 0202A6FF 83DCD12D
	v_dot2acc_f32_f16 v27, v76, v16                            // 000000965CA8: 0436214C
	.long 0xd72c0051                                           // 000000965CAC: D72C0051
	v_cndmask_b32_e32 v1, 0x83dcd12d, v81, vcc_lo              // 000000965CB0: 0202A2FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4)                            // 000000965CB8: BF870004
	.long 0xd72c003a                                           // 000000965CBC: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 000000965CC0: 020274FF 83DCD12D
	v_mov_b32_e32 v87, v72                                     // 000000965CC8: 7EAE0348
	v_sad_u8 v79, v79, 0, 0x6400                               // 000000965CCC: D622004F 03FD014F 00006400
	.long 0xd72c0052                                           // 000000965CD8: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 000000965CDC: 0202A4FF 83DCD12D
	v_mov_b32_e32 v89, v65                                     // 000000965CE4: 7EB20341
	v_sad_u8 v77, v77, 0, 0x6400                               // 000000965CE8: D622004D 03FD014D 00006400
	v_mov_b32_e32 v86, v64                                     // 000000965CF4: 7EAC0340
	v_lshl_or_b32 v60, v79, 16, v60                            // 000000965CF8: D656003C 04F1214F
	v_sad_u8 v58, v58, 0, 0x6400                               // 000000965D00: D622003A 03FD013A 00006400
	v_sad_u8 v81, v81, 0, 0x6400                               // 000000965D0C: D6220051 03FD0151 00006400
	v_dot2acc_f32_f16 v30, v80, v7                             // 000000965D18: 043C0F50
	v_sad_u8 v82, v82, 0, 0x6400                               // 000000965D1C: D6220052 03FD0152 00006400
	v_pk_fma_f16 v60, v60, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000965D28: CC0E003C 0BFC0B3C 0000C931
	v_and_b32_e32 v78, 0xffff, v59                             // 000000965D34: 369C76FF 0000FFFF
	v_bfe_u32 v59, v59, 4, 16                                  // 000000965D3C: D610003B 0241093B
	v_lshlrev_b32_e32 v58, 16, v58                             // 000000965D44: 30747490
	v_and_b32_e32 v81, 0xffff, v81                             // 000000965D48: 36A2A2FF 0000FFFF
	v_dot2acc_f32_f16 v25, v60, v5                             // 000000965D50: 04320B3C
	.long 0xd72c004e                                           // 000000965D54: D72C004E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 000000965D58: 02029CFF 83DCD12D
	.long 0xd72c003b                                           // 000000965D60: D72C003B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 000000965D64: 020276FF 83DCD12D
	v_dot2acc_f32_f16 v26, v60, v1                             // 000000965D6C: 0434033C
	v_and_or_b32 v1, 0xffff, v77, v58                          // 000000965D70: D6570001 04EA9AFF 0000FFFF
	v_dot2acc_f32_f16 v24, v60, v9                             // 000000965D7C: 0430133C
	v_dual_dot2acc_f32_f16 v22, v60, v13 :: v_dual_mov_b32 v79, v70// 000000965D80: CB101B3C 164E0146
	v_mov_b32_e32 v77, v61                                     // 000000965D88: 7E9A033D
	v_sad_u8 v78, v78, 0, 0x6400                               // 000000965D8C: D622004E 03FD014E 00006400
	v_sad_u8 v59, v59, 0, 0x6400                               // 000000965D98: D622003B 03FD013B 00006400
	v_pk_fma_f16 v1, v1, s5, 0xc931 op_sel_hi:[1,0,0]          // 000000965DA4: CC0E0001 0BFC0B01 0000C931
	v_mov_b32_e32 v88, v73                                     // 000000965DB0: 7EB00349
	v_mov_b32_e32 v90, v73                                     // 000000965DB4: 7EB40349
	v_dual_mov_b32 v83, v63 :: v_dual_lshlrev_b32 v78, 16, v78 // 000000965DB8: CA22013F 534E9C90
	v_mov_b32_e32 v84, v71                                     // 000000965DC0: 7EA80347
	v_mov_b32_e32 v80, v62                                     // 000000965DC4: 7EA0033E
	v_mov_b32_e32 v60, v67                                     // 000000965DC8: 7E780343
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000965DCC: BF870244
	v_and_or_b32 v59, 0xffff, v59, v78                         // 000000965DD0: D657003B 053A76FF 0000FFFF
	v_lshl_or_b32 v78, v82, 16, v81                            // 000000965DDC: D656004E 05452152
	v_dual_mov_b32 v81, v70 :: v_dual_mov_b32 v82, v71         // 000000965DE4: CA100146 51520147
	v_mov_b32_e32 v58, v67                                     // 000000965DEC: 7E740343
	v_pk_fma_f16 v59, v59, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000965DF0: CC0E003B 0BFC0B3B 0000C931
	v_dot2acc_f32_f16 v30, v76, v8                             // 000000965DFC: 043C114C
	v_pk_fma_f16 v78, v78, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000965E00: CC0E004E 0BFC0B4E 0000C931
	s_delay_alu instid0(VALU_DEP_3)                            // 000000965E0C: BF870003
	v_dot2acc_f32_f16 v26, v59, v2                             // 000000965E10: 0434053B
	v_dot2acc_f32_f16 v25, v59, v6                             // 000000965E14: 04320D3B
	v_dot2acc_f32_f16 v24, v59, v10                            // 000000965E18: 0430153B
	v_dot2acc_f32_f16 v22, v59, v14                            // 000000965E1C: 042C1D3B
	v_dot2acc_f32_f16 v28, v76, v12                            // 000000965E20: 0438194C
	v_dual_dot2acc_f32_f16 v26, v78, v3 :: v_dual_mov_b32 v3, v75// 000000965E24: CB10074E 1A02014B
	v_dot2acc_f32_f16 v25, v78, v7                             // 000000965E2C: 04320F4E
	v_dot2acc_f32_f16 v24, v78, v11                            // 000000965E30: 0430174E
	v_dot2acc_f32_f16 v22, v78, v15                            // 000000965E34: 042C1F4E
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000965E38: BF870214
	v_dual_dot2acc_f32_f16 v26, v1, v4 :: v_dual_mov_b32 v59, v18// 000000965E3C: CB100901 1A3A0112
	v_dot2acc_f32_f16 v25, v1, v8                              // 000000965E44: 04321101
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000965E48: BF870214
	v_dot2acc_f32_f16 v24, v1, v12                             // 000000965E4C: 04301901
	v_dot2acc_f32_f16 v22, v1, v16                             // 000000965E50: 042C2101
	v_mov_b32_e32 v4, v75                                      // 000000965E54: 7E08034B
	v_mov_b32_e32 v2, v66                                      // 000000965E58: 7E040342
	v_mov_b32_e32 v78, v69                                     // 000000965E5C: 7E9C0345
	v_mov_b32_e32 v76, v69                                     // 000000965E60: 7E980345
	v_mov_b32_e32 v1, v17                                      // 000000965E64: 7E020311
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000965E68: 917E047E
	s_cbranch_execz 58                                         // 000000965E6C: BFA5003A <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_dn_tsILi4ELi8ELi4ELb0EEEvPKjPKDF16_PKiS5_PtNS0_4HtSdEiNS0_6HtFoldE+0x1c58>
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000965E70: BF8700A1
	v_add_nc_u32_e32 v17, 1, v1                                // 000000965E74: 4A220281
	s_mov_b32 s6, exec_lo                                      // 000000965E78: BE86007E
	.long 0xd4c1007e                                           // 000000965E7C: D4C1007E
	v_cndmask_b32_e32 v1, v17, v23, vcc_lo                     // 000000965E80: 02022F11
	s_cbranch_execz 64550                                      // 000000965E84: BFA5FC26 <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_dn_tsILi4ELi8ELi4ELb0EEEvPKjPKDF16_PKiS5_PtNS0_4HtSdEiNS0_6HtFoldE+0xc20>
	v_ashrrev_i32_e32 v18, 31, v17                             // 000000965E88: 3424229F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000965E8C: BF870091
	.long 0xd73c0005                                           // 000000965E90: D73C0005
	v_cndmask_b32_e32 v1, 10, v17, vcc_lo                      // 000000965E94: 0202228A
	.long 0xd7006a07                                           // 000000965E98: D7006A07
	v_cndmask_b32_e32 v1, s1, v5, vcc_lo                       // 000000965E9C: 02020A01
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000965EA0: BF870111
	v_add_co_ci_u32_e64 v8, null, s3, v6, vcc_lo               // 000000965EA4: D5207C08 01AA0C03
	.long 0xd7006a05                                           // 000000965EAC: D7006A05
	v_cndmask_b32_e32 v1, v7, v57, vcc_lo                      // 000000965EB0: 02027307
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000965EB4: BF8700A1
	v_add_co_ci_u32_e64 v6, null, 0, v8, vcc_lo                // 000000965EB8: D5207C06 01AA1080
	.long 0xd7006a07                                           // 000000965EC0: D7006A07
	v_cndmask_b32_e32 v1, v7, v56, vcc_lo                      // 000000965EC4: 02027107
	v_add_co_ci_u32_e64 v8, null, 0, v8, vcc_lo                // 000000965EC8: D5207C08 01AA1080
	s_clause 0xf                                               // 000000965ED0: BF85000F
	global_load_b32 v66, v[5:6], off                           // 000000965ED4: DC520000 427C0005
	global_load_b32 v68, v[5:6], off offset:128                // 000000965EDC: DC520080 447C0005
	global_load_b32 v65, v[5:6], off offset:256                // 000000965EE4: DC520100 417C0005
	global_load_b32 v64, v[5:6], off offset:384                // 000000965EEC: DC520180 407C0005
	global_load_b32 v63, v[5:6], off offset:512                // 000000965EF4: DC520200 3F7C0005
	global_load_b32 v62, v[5:6], off offset:640                // 000000965EFC: DC520280 3E7C0005
	global_load_b32 v61, v[5:6], off offset:768                // 000000965F04: DC520300 3D7C0005
	global_load_b32 v18, v[5:6], off offset:896                // 000000965F0C: DC520380 127C0005
	global_load_b32 v75, v[7:8], off                           // 000000965F14: DC520000 4B7C0007
	global_load_b32 v74, v[7:8], off offset:128                // 000000965F1C: DC520080 4A7C0007
	global_load_b32 v73, v[7:8], off offset:256                // 000000965F24: DC520100 497C0007
	global_load_b32 v72, v[7:8], off offset:384                // 000000965F2C: DC520180 487C0007
	global_load_b32 v71, v[7:8], off offset:512                // 000000965F34: DC520200 477C0007
	global_load_b32 v70, v[7:8], off offset:640                // 000000965F3C: DC520280 467C0007
	global_load_b32 v69, v[7:8], off offset:768                // 000000965F44: DC520300 457C0007
	global_load_b32 v67, v[7:8], off offset:896                // 000000965F4C: DC520380 437C0007
	s_branch 64498                                             // 000000965F54: BFA0FBF2 <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_dn_tsILi4ELi8ELi4ELb0EEEvPKjPKDF16_PKiS5_PtNS0_4HtSdEiNS0_6HtFoldE+0xc20>
	s_or_b32 exec_lo, exec_lo, s4                              // 000000965F58: 8C7E047E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000965F5C: BF870009
	s_or_b32 exec_lo, exec_lo, s0                              // 000000965F60: 8C7E007E
	s_waitcnt vmcnt(23)                                        // 000000965F64: BF895FF7
	v_dual_mov_b32 v1, v54 :: v_dual_mov_b32 v2, v51           // 000000965F68: CA100136 01020133
	s_waitcnt vmcnt(7)                                         // 000000965F70: BF891FF7
	v_dual_mov_b32 v4, v50 :: v_dual_mov_b32 v3, v41           // 000000965F74: CA100132 04020129
	v_dual_mov_b32 v5, v47 :: v_dual_mov_b32 v8, v52           // 000000965F7C: CA10012F 05080134
	v_dual_mov_b32 v7, v53 :: v_dual_mov_b32 v10, v48          // 000000965F84: CA100135 070A0130
	v_dual_mov_b32 v9, v49 :: v_dual_mov_b32 v14, v43          // 000000965F8C: CA100131 090E012B
	v_dual_mov_b32 v6, v29 :: v_dual_mov_b32 v11, v46          // 000000965F94: CA10011D 060A012E
	v_dual_mov_b32 v12, v45 :: v_dual_mov_b32 v13, v44         // 000000965F9C: CA10012D 0C0C012C
	v_dual_mov_b32 v15, v42 :: v_dual_mov_b32 v16, v40         // 000000965FA4: CA10012A 0F100128
	v_dual_mov_b32 v17, v39 :: v_dual_mov_b32 v18, v38         // 000000965FAC: CA100127 11120126
	v_dual_mov_b32 v23, v37 :: v_dual_mov_b32 v56, v35         // 000000965FB4: CA100125 17380123
	s_waitcnt vmcnt(0)                                         // 000000965FBC: BF8903F7
	v_dual_mov_b32 v55, v36 :: v_dual_mov_b32 v58, v33         // 000000965FC0: CA100124 373A0121
	v_dual_mov_b32 v57, v34 :: v_dual_mov_b32 v60, v31         // 000000965FC8: CA100122 393C011F
	v_dual_mov_b32 v59, v32 :: v_dual_mov_b32 v64, v26         // 000000965FD0: CA100120 3B40011A
	v_dual_mov_b32 v61, v30 :: v_dual_mov_b32 v62, v28         // 000000965FD8: CA10011E 3D3E011C
	v_dual_mov_b32 v63, v27 :: v_dual_mov_b32 v66, v24         // 000000965FE0: CA10011B 3F420118
	v_mov_b32_e32 v65, v25                                     // 000000965FE8: 7E820319
	v_mov_b32_e32 v67, v22                                     // 000000965FEC: 7E860316
	s_mov_b32 s0, 0x76543210                                   // 000000965FF0: BE8000FF 76543210
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000965FF8: BF870009
	v_permlanex16_b32 v1, v1, s0, 0xfedcba98                   // 000000965FFC: D65C0001 03FC0101 FEDCBA98
	v_permlanex16_b32 v2, v2, s0, 0xfedcba98                   // 000000966008: D65C0002 03FC0102 FEDCBA98
	v_permlanex16_b32 v4, v4, s0, 0xfedcba98                   // 000000966014: D65C0004 03FC0104 FEDCBA98
	v_permlanex16_b32 v3, v3, s0, 0xfedcba98                   // 000000966020: D65C0003 03FC0103 FEDCBA98
	v_permlanex16_b32 v5, v5, s0, 0xfedcba98                   // 00000096602C: D65C0005 03FC0105 FEDCBA98
	v_permlanex16_b32 v7, v7, s0, 0xfedcba98                   // 000000966038: D65C0007 03FC0107 FEDCBA98
	v_permlanex16_b32 v8, v8, s0, 0xfedcba98                   // 000000966044: D65C0008 03FC0108 FEDCBA98
	v_permlanex16_b32 v9, v9, s0, 0xfedcba98                   // 000000966050: D65C0009 03FC0109 FEDCBA98
	v_permlanex16_b32 v6, v6, s0, 0xfedcba98                   // 00000096605C: D65C0006 03FC0106 FEDCBA98
	v_permlanex16_b32 v10, v10, s0, 0xfedcba98                 // 000000966068: D65C000A 03FC010A FEDCBA98
	v_permlanex16_b32 v11, v11, s0, 0xfedcba98                 // 000000966074: D65C000B 03FC010B FEDCBA98
	v_permlanex16_b32 v12, v12, s0, 0xfedcba98                 // 000000966080: D65C000C 03FC010C FEDCBA98
	v_permlanex16_b32 v13, v13, s0, 0xfedcba98                 // 00000096608C: D65C000D 03FC010D FEDCBA98
	v_permlanex16_b32 v14, v14, s0, 0xfedcba98                 // 000000966098: D65C000E 03FC010E FEDCBA98
	v_permlanex16_b32 v15, v15, s0, 0xfedcba98                 // 0000009660A4: D65C000F 03FC010F FEDCBA98
	v_permlanex16_b32 v16, v16, s0, 0xfedcba98                 // 0000009660B0: D65C0010 03FC0110 FEDCBA98
	v_permlanex16_b32 v17, v17, s0, 0xfedcba98                 // 0000009660BC: D65C0011 03FC0111 FEDCBA98
	v_permlanex16_b32 v18, v18, s0, 0xfedcba98                 // 0000009660C8: D65C0012 03FC0112 FEDCBA98
	v_permlanex16_b32 v23, v23, s0, 0xfedcba98                 // 0000009660D4: D65C0017 03FC0117 FEDCBA98
	v_permlanex16_b32 v55, v55, s0, 0xfedcba98                 // 0000009660E0: D65C0037 03FC0137 FEDCBA98
	v_permlanex16_b32 v56, v56, s0, 0xfedcba98                 // 0000009660EC: D65C0038 03FC0138 FEDCBA98
	v_permlanex16_b32 v57, v57, s0, 0xfedcba98                 // 0000009660F8: D65C0039 03FC0139 FEDCBA98
	v_permlanex16_b32 v58, v58, s0, 0xfedcba98                 // 000000966104: D65C003A 03FC013A FEDCBA98
	v_permlanex16_b32 v59, v59, s0, 0xfedcba98                 // 000000966110: D65C003B 03FC013B FEDCBA98
	v_permlanex16_b32 v60, v60, s0, 0xfedcba98                 // 00000096611C: D65C003C 03FC013C FEDCBA98
	v_permlanex16_b32 v61, v61, s0, 0xfedcba98                 // 000000966128: D65C003D 03FC013D FEDCBA98
	v_permlanex16_b32 v62, v62, s0, 0xfedcba98                 // 000000966134: D65C003E 03FC013E FEDCBA98
	v_permlanex16_b32 v63, v63, s0, 0xfedcba98                 // 000000966140: D65C003F 03FC013F FEDCBA98
	v_permlanex16_b32 v64, v64, s0, 0xfedcba98                 // 00000096614C: D65C0040 03FC0140 FEDCBA98
	v_permlanex16_b32 v65, v65, s0, 0xfedcba98                 // 000000966158: D65C0041 03FC0141 FEDCBA98
	v_permlanex16_b32 v66, v66, s0, 0xfedcba98                 // 000000966164: D65C0042 03FC0142 FEDCBA98
	v_permlanex16_b32 v67, v67, s0, 0xfedcba98                 // 000000966170: D65C0043 03FC0143 FEDCBA98
	.long 0xd44c0000                                           // 00000096617C: D44C0000
	v_cndmask_b32_e32 v1, 16, v20, vcc_lo                      // 000000966180: 02022890
	s_barrier                                                  // 000000966184: BFBD0000
	buffer_gl0_inv                                             // 000000966188: E0AC0000 00000000
	s_and_saveexec_b32 s1, s0                                  // 000000966190: BE812000
	s_cbranch_execz 68                                         // 000000966194: BFA50044 <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_dn_tsILi4ELi8ELi4ELb0EEEvPKjPKDF16_PKiS5_PtNS0_4HtSdEiNS0_6HtFoldE+0x1fa8>
	v_lshl_or_b32 v21, v19, 11, v21                            // 000000966198: D6560015 04551713
	v_dual_add_f32 v12, v45, v12 :: v_dual_add_f32 v5, v47, v5 // 0000009661A0: C908192D 0C040B2F
	v_dual_add_f32 v8, v52, v8 :: v_dual_add_f32 v1, v54, v1   // 0000009661A8: C9081134 08000336
	v_dual_add_f32 v10, v48, v10 :: v_dual_add_f32 v7, v53, v7 // 0000009661B0: C9081530 0A060F35
	v_dual_add_f32 v2, v51, v2 :: v_dual_add_f32 v3, v41, v3   // 0000009661B8: C9080533 02020729
	v_dual_add_f32 v34, v34, v57 :: v_dual_add_f32 v23, v37, v23// 0000009661C0: C9087322 22162F25
	v_dual_add_f32 v4, v50, v4 :: v_dual_add_nc_u32 v37, 0x400, v21// 0000009661C8: C9200932 04242AFF 00000400
	v_dual_add_f32 v36, v36, v55 :: v_dual_add_f32 v9, v49, v9 // 0000009661D4: C9086F24 24081331
	v_dual_add_f32 v18, v38, v18 :: v_dual_add_f32 v13, v44, v13// 0000009661DC: C9082526 120C1B2C
	v_add_f32_e32 v6, v29, v6                                  // 0000009661E4: 060C0D1D
	v_dual_add_f32 v22, v22, v67 :: v_dual_add_f32 v25, v25, v65// 0000009661E8: C9088716 16188319
	v_dual_add_f32 v24, v24, v66 :: v_dual_add_f32 v27, v27, v63// 0000009661F0: C9088518 181A7F1B
	v_dual_add_f32 v26, v26, v64 :: v_dual_add_f32 v33, v33, v58// 0000009661F8: C908811A 1A207521
	v_dual_add_f32 v28, v28, v62 :: v_dual_add_f32 v31, v31, v60// 000000966200: C9087D1C 1C1E791F
	v_dual_add_f32 v30, v30, v61 :: v_dual_add_f32 v35, v35, v56// 000000966208: C9087B1E 1E227123
	v_dual_add_f32 v32, v32, v59 :: v_dual_add_f32 v17, v39, v17// 000000966210: C9087720 20102327
	v_dual_add_f32 v16, v40, v16 :: v_dual_add_f32 v15, v42, v15// 000000966218: C9082128 100E1F2A
	v_dual_add_f32 v14, v43, v14 :: v_dual_add_f32 v11, v46, v11// 000000966220: C9081D2B 0E0A172E
	ds_store_2addr_b32 v21, v1, v5 offset1:16                  // 000000966228: D8381000 00050115
	ds_store_2addr_b32 v21, v2, v7 offset0:128 offset1:144     // 000000966230: D8389080 00070215
	ds_store_2addr_b32 v37, v4, v8 offset1:16                  // 000000966238: D8381000 00080425
	ds_store_2addr_b32 v37, v3, v9 offset0:128 offset1:144     // 000000966240: D8389080 00090325
	ds_store_2addr_b32 v21, v6, v13 offset0:32 offset1:48      // 000000966248: D8383020 000D0615
	ds_store_2addr_b32 v21, v10, v14 offset0:160 offset1:176   // 000000966250: D838B0A0 000E0A15
	ds_store_2addr_b32 v37, v11, v15 offset0:32 offset1:48     // 000000966258: D8383020 000F0B25
	ds_store_2addr_b32 v37, v12, v16 offset0:160 offset1:176   // 000000966260: D838B0A0 00100C25
	ds_store_2addr_b32 v21, v17, v35 offset0:64 offset1:80     // 000000966268: D8385040 00231115
	ds_store_2addr_b32 v21, v18, v34 offset0:192 offset1:208   // 000000966270: D838D0C0 00221215
	ds_store_2addr_b32 v37, v23, v33 offset0:64 offset1:80     // 000000966278: D8385040 00211725
	ds_store_2addr_b32 v37, v36, v32 offset0:192 offset1:208   // 000000966280: D838D0C0 00202425
	ds_store_2addr_b32 v21, v31, v26 offset0:96 offset1:112    // 000000966288: D8387060 001A1F15
	ds_store_2addr_b32 v21, v30, v25 offset0:224 offset1:240   // 000000966290: D838F0E0 00191E15
	ds_store_2addr_b32 v37, v28, v24 offset0:96 offset1:112    // 000000966298: D8387060 00181C25
	ds_store_2addr_b32 v37, v27, v22 offset0:224 offset1:240   // 0000009662A0: D838F0E0 00161B25
	s_or_b32 exec_lo, exec_lo, s1                              // 0000009662A8: 8C7E017E
	.long 0xd44c0001                                           // 0000009662AC: D44C0001
	v_cndmask_b32_e32 v1, 0x200, v0, vcc_lo                    // 0000009662B0: 020200FF 00000200
	s_waitcnt lgkmcnt(0)                                       // 0000009662B8: BF89FC07
	s_barrier                                                  // 0000009662BC: BFBD0000
	buffer_gl0_inv                                             // 0000009662C0: E0AC0000 00000000
	s_and_saveexec_b32 s3, s1                                  // 0000009662C8: BE832001
	s_cbranch_execz 47                                         // 0000009662CC: BFA5002F <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_dn_tsILi4ELi8ELi4ELb0EEEvPKjPKDF16_PKiS5_PtNS0_4HtSdEiNS0_6HtFoldE+0x208c>
	v_mov_b32_e32 v1, v0                                       // 0000009662D0: 7E020300
	s_mov_b32 s4, 0                                            // 0000009662D4: BE840080
	s_nop 0                                                    // 0000009662D8: BF800000
	s_nop 0                                                    // 0000009662DC: BF800000
	s_nop 0                                                    // 0000009662E0: BF800000
	s_nop 0                                                    // 0000009662E4: BF800000
	s_nop 0                                                    // 0000009662E8: BF800000
	s_nop 0                                                    // 0000009662EC: BF800000
	s_nop 0                                                    // 0000009662F0: BF800000
	s_nop 0                                                    // 0000009662F4: BF800000
	s_nop 0                                                    // 0000009662F8: BF800000
	s_nop 0                                                    // 0000009662FC: BF800000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000966300: BF870001
	v_lshlrev_b32_e32 v8, 2, v1                                // 000000966304: 30100282
	v_cmp_lt_u32_e32 vcc_lo, 0xff, v1                          // 000000966308: 7C9202FF 000000FF
	ds_load_2addr_stride64_b32 v[2:3], v8 offset1:8            // 000000966310: D8E00800 02000008
	ds_load_2addr_stride64_b32 v[4:5], v8 offset0:16 offset1:24// 000000966318: D8E01810 04000008
	ds_load_2addr_stride64_b32 v[6:7], v8 offset0:32 offset1:40// 000000966320: D8E02820 06000008
	s_or_b32 s4, vcc_lo, s4                                    // 000000966328: 8C04046A
	s_waitcnt lgkmcnt(2)                                       // 00000096632C: BF89FC27
	v_add_f32_e32 v2, 0, v2                                    // 000000966330: 06040480
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000966334: BF8700C1
	v_add_f32_e32 v9, v2, v3                                   // 000000966338: 06120702
	ds_load_2addr_stride64_b32 v[2:3], v8 offset0:48 offset1:56// 00000096633C: D8E03830 02000008
	s_waitcnt lgkmcnt(2)                                       // 000000966344: BF89FC27
	v_add_f32_e32 v4, v9, v4                                   // 000000966348: 06080909
	v_add_f32_e32 v4, v4, v5                                   // 00000096634C: 06080B04
	s_waitcnt lgkmcnt(1)                                       // 000000966350: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000966354: BF870091
	v_add_f32_e32 v4, v4, v6                                   // 000000966358: 06080D04
	v_add_f32_e32 v4, v4, v7                                   // 00000096635C: 06080F04
	s_waitcnt lgkmcnt(0)                                       // 000000966360: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000966364: BF8700A1
	v_add_f32_e32 v2, v4, v2                                   // 000000966368: 06040504
	v_add_nc_u32_e32 v4, 0x100, v1                             // 00000096636C: 4A0802FF 00000100
	v_dual_add_f32 v2, v2, v3 :: v_dual_mov_b32 v1, v4         // 000000966374: C9100702 02000104
	ds_store_b32 v8, v2 offset:16384                           // 00000096637C: D8344000 00000208
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000966384: 917E047E
	s_cbranch_execnz 65501                                     // 000000966388: BFA6FFDD <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_dn_tsILi4ELi8ELi4ELb0EEEvPKjPKDF16_PKiS5_PtNS0_4HtSdEiNS0_6HtFoldE+0x2000>
	s_or_b32 exec_lo, exec_lo, s3                              // 00000096638C: 8C7E037E
	s_cmp_lt_i32 s9, 2                                         // 000000966390: BF048209
	s_mov_b32 s3, -1                                           // 000000966394: BE8300C1
	s_cbranch_scc1 212                                         // 000000966398: BFA200D4 <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_dn_tsILi4ELi8ELi4ELb0EEEvPKjPKDF16_PKiS5_PtNS0_4HtSdEiNS0_6HtFoldE+0x23ec>
	s_waitcnt lgkmcnt(0)                                       // 00000096639C: BF89FC07
	s_barrier                                                  // 0000009663A0: BFBD0000
	buffer_gl0_inv                                             // 0000009663A4: E0AC0000 00000000
	s_and_saveexec_b32 s3, s1                                  // 0000009663AC: BE832001
	s_cbranch_execz 71                                         // 0000009663B0: BFA50047 <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_dn_tsILi4ELi8ELi4ELb0EEEvPKjPKDF16_PKiS5_PtNS0_4HtSdEiNS0_6HtFoldE+0x21d0>
	v_lshrrev_b32_e32 v1, 7, v0                                // 0000009663B4: 32020087
	s_ashr_i32 s45, s44, 31                                    // 0000009663B8: 862D9F2C
	s_ashr_i32 s47, s46, 31                                    // 0000009663BC: 862F9F2E
	s_lshl_b64 s[4:5], s[44:45], 2                             // 0000009663C0: 8484822C
	s_lshl_b32 s6, s10, 7                                      // 0000009663C4: 8406870A
	v_or_b32_e32 v1, s4, v1                                    // 0000009663C8: 38020204
	v_mov_b32_e32 v2, s5                                       // 0000009663CC: 7E040205
	s_lshl_b64 s[4:5], s[46:47], 2                             // 0000009663D0: 8484822E
	s_ashr_i32 s7, s6, 31                                      // 0000009663D4: 86079F06
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000009663D8: BF8700A9
	s_lshl_b64 s[6:7], s[6:7], 2                               // 0000009663DC: 84868206
	.long 0xd7016a01                                           // 0000009663E0: D7016A01
	v_cndmask_b32_e32 v0, v1, v4, vcc_lo                       // 0000009663E4: 02000901
	v_subrev_co_ci_u32_e64 v2, null, s5, v2, vcc_lo            // 0000009663E8: D5227C02 01AA0405
	s_ashr_i32 s5, s29, 31                                     // 0000009663F0: 86059F1D
	s_mov_b32 s4, s29                                          // 0000009663F4: BE84001D
	.long 0xd72c0004                                           // 0000009663F8: D72C0004
	v_cndmask_b32_e32 v0, v1, v5, vcc_lo                       // 0000009663FC: 02000B01
	.long 0xd72c0003                                           // 000000966400: D72C0003
	v_cndmask_b32_e32 v0, v2, v29, vcc_lo                      // 000000966404: 02003B02
	v_mad_u64_u32 v[1:2], null, v1, s29, 0                     // 000000966408: D6FE7C01 02003B01
	s_lshl_b64 s[4:5], s[4:5], 3                               // 000000966410: 84848304
	v_add3_u32 v2, v2, v4, v3                                  // 000000966414: D6550002 040E0902
	v_and_b32_e32 v3, 0x7f, v0                                 // 00000096641C: 360600FF 0000007F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000966424: BF870112
	.long 0xd73c0001                                           // 000000966428: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 00000096642C: 02020282
	v_lshlrev_b32_e32 v4, 2, v3                                // 000000966430: 30080682
	v_lshlrev_b32_e32 v3, 2, v0                                // 000000966434: 30060082
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000966438: BF870093
	.long 0xd7006a01                                           // 00000096643C: D7006A01
	v_cndmask_b32_e32 v0, v1, v6, vcc_lo                       // 000000966440: 02000D01
	v_add_co_ci_u32_e64 v2, null, s7, v2, vcc_lo               // 000000966444: D5207C02 01AA0407
	s_mov_b32 s6, 0                                            // 00000096644C: BE860080
	.long 0xd7006a01                                           // 000000966450: D7006A01
	v_cndmask_b32_e32 v1, v1, v4, vcc_lo                       // 000000966454: 02020901
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000966458: BF8701A1
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 00000096645C: D5207C02 01AA0480
	v_or_b32_e32 v4, 0xffffff00, v0                            // 000000966464: 380800FF FFFFFF00
	.long 0xd7006a01                                           // 00000096646C: D7006A01
	v_cndmask_b32_e32 v1, s42, v1, vcc_lo                      // 000000966470: 0202022A
	s_delay_alu instid0(VALU_DEP_1)                            // 000000966474: BF870001
	v_add_co_ci_u32_e64 v2, null, s43, v2, vcc_lo              // 000000966478: D5207C02 01AA042B
	ds_load_b32 v5, v3 offset:16384                            // 000000966480: D8D84000 05000003
	.long 0xd7000704                                           // 000000966488: D7000704
	v_cndmask_b32_e32 v1, 0x100, v4, vcc_lo                    // 00000096648C: 020208FF 00000100
	s_xor_b32 s7, s7, -1                                       // 000000966494: 8D07C107
	v_add_nc_u32_e32 v3, 0x400, v3                             // 000000966498: 4A0606FF 00000400
	s_and_b32 s7, exec_lo, s7                                  // 0000009664A0: 8B07077E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000009664A4: BF8700C9
	s_or_b32 s6, s7, s6                                        // 0000009664A8: 8C060607
	s_waitcnt lgkmcnt(0)                                       // 0000009664AC: BF89FC07
	global_store_b32 v[1:2], v5, off                           // 0000009664B0: DC6A0000 007C0501
	.long 0xd7006a01                                           // 0000009664B8: D7006A01
	v_cndmask_b32_e32 v0, v1, v4, vcc_lo                       // 0000009664BC: 02000901
	v_add_co_ci_u32_e64 v2, null, s5, v2, vcc_lo               // 0000009664C0: D5207C02 01AA0405
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 0000009664C8: 917E067E
	s_cbranch_execnz 65516                                     // 0000009664CC: BFA6FFEC <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_dn_tsILi4ELi8ELi4ELb0EEEvPKjPKDF16_PKiS5_PtNS0_4HtSdEiNS0_6HtFoldE+0x2180>
	s_or_b32 exec_lo, exec_lo, s3                              // 0000009664D0: 8C7E037E
	.long 0xd44a0003                                           // 0000009664D4: D44A0003
	v_cndmask_b32_e32 v1, 0, v0, vcc_lo                        // 0000009664D8: 02020080
	s_waitcnt_vscnt null, 0x0                                  // 0000009664DC: BC7C0000
	buffer_gl1_inv                                             // 0000009664E0: E0B00000 00000000
	buffer_gl0_inv                                             // 0000009664E8: E0AC0000 00000000
	s_barrier                                                  // 0000009664F0: BFBD0000
	buffer_gl0_inv                                             // 0000009664F4: E0AC0000 00000000
	s_and_saveexec_b32 s4, s3                                  // 0000009664FC: BE842003
	s_cbranch_execz 29                                         // 000000966500: BFA5001D <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_dn_tsILi4ELi8ELi4ELb0EEEvPKjPKDF16_PKiS5_PtNS0_4HtSdEiNS0_6HtFoldE+0x2278>
	s_mov_b32 s6, exec_lo                                      // 000000966504: BE86007E
	s_mov_b32 s5, exec_lo                                      // 000000966508: BE85007E
	.long 0xd71f0001                                           // 00000096650C: D71F0001
	v_cndmask_b32_e32 v0, s6, v128, vcc_lo                     // 000000966510: 02010006
	s_delay_alu instid0(VALU_DEP_1)                            // 000000966514: BF870001
	v_cmpx_eq_u32_e32 0, v1                                    // 000000966518: 7D940280
	s_cbranch_execz 9                                          // 00000096651C: BFA50009 <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_dn_tsILi4ELi8ELi4ELb0EEEvPKjPKDF16_PKiS5_PtNS0_4HtSdEiNS0_6HtFoldE+0x2244>
	s_lshl_b64 s[22:23], s[10:11], 2                           // 000000966520: 8496820A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 000000966524: BF8704B9
	s_add_u32 s22, s34, s22                                    // 000000966528: 80161622
	s_addc_u32 s23, s35, s23                                   // 00000096652C: 82171723
	s_bcnt1_i32_b32 s6, s6                                     // 000000966530: BE861806
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v3, s6              // 000000966534: CA100080 02020006
	global_atomic_add_u32 v2, v2, v3, s[22:23] glc             // 00000096653C: DCD64000 02160302
	s_or_b32 exec_lo, exec_lo, s5                              // 000000966544: 8C7E057E
	s_waitcnt vmcnt(0)                                         // 000000966548: BF8903F7
	v_readfirstlane_b32 s5, v2                                 // 00000096654C: 7E0A0502
	s_delay_alu instid0(VALU_DEP_1)                            // 000000966550: BF870001
	v_dual_mov_b32 v2, 0 :: v_dual_add_nc_u32 v1, s5, v1       // 000000966554: CA200080 02000205
	s_add_i32 s5, s9, -1                                       // 00000096655C: 8105C109
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 000000966560: BF870481
	v_cmp_eq_u32_e32 vcc_lo, s5, v1                            // 000000966564: 7C940205
	v_cndmask_b32_e64 v1, 0, 1, vcc_lo                         // 000000966568: D5010001 01A90280
	ds_store_b32 v2, v1 offset:30208                           // 000000966570: D8347600 00000102
	s_or_b32 exec_lo, exec_lo, s4                              // 000000966578: 8C7E047E
	v_mov_b32_e32 v1, 0                                        // 00000096657C: 7E020280
	s_waitcnt lgkmcnt(0)                                       // 000000966580: BF89FC07
	s_barrier                                                  // 000000966584: BFBD0000
	buffer_gl0_inv                                             // 000000966588: E0AC0000 00000000
	ds_load_b32 v1, v1 offset:30208                            // 000000966590: D8D87600 01000001
	s_waitcnt lgkmcnt(0)                                       // 000000966598: BF89FC07
	v_cmp_eq_u32_e32 vcc_lo, 0, v1                             // 00000096659C: 7C940280
	s_cbranch_vccnz 2150                                       // 0000009665A0: BFA40866 <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_dn_tsILi4ELi8ELi4ELb0EEEvPKjPKDF16_PKiS5_PtNS0_4HtSdEiNS0_6HtFoldE+0x443c>
	buffer_gl1_inv                                             // 0000009665A4: E0B00000 00000000
	buffer_gl0_inv                                             // 0000009665AC: E0AC0000 00000000
	s_and_saveexec_b32 s8, s1                                  // 0000009665B4: BE882001
	s_cbranch_execz 65                                         // 0000009665B8: BFA50041 <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_dn_tsILi4ELi8ELi4ELb0EEEvPKjPKDF16_PKiS5_PtNS0_4HtSdEiNS0_6HtFoldE+0x23c0>
	v_lshrrev_b32_e32 v1, 7, v0                                // 0000009665BC: 32020087
	s_lshl_b32 s4, s10, 7                                      // 0000009665C0: 8404870A
	v_and_b32_e32 v3, 0x7f, v0                                 // 0000009665C4: 360600FF 0000007F
	s_ashr_i32 s5, s4, 31                                      // 0000009665CC: 86059F04
	v_mov_b32_e32 v5, v0                                       // 0000009665D0: 7E0A0300
	v_mad_i64_i32 v[1:2], null, v1, s29, 0                     // 0000009665D4: D6FF7C01 02003B01
	s_lshl_b64 s[4:5], s[4:5], 2                               // 0000009665DC: 84848204
	v_lshlrev_b32_e32 v3, 2, v3                                // 0000009665E0: 30060682
	s_ashr_i32 s7, s29, 31                                     // 0000009665E4: 86079F1D
	s_mov_b32 s6, s29                                          // 0000009665E8: BE86001D
	s_mov_b32 s22, 0                                           // 0000009665EC: BE960080
	.long 0xd73c0001                                           // 0000009665F0: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 0000009665F4: 02020282
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000009665F8: BF870091
	.long 0xd7006a01                                           // 0000009665FC: D7006A01
	v_cndmask_b32_e32 v0, v1, v4, vcc_lo                       // 000000966600: 02000901
	v_add_co_ci_u32_e64 v2, null, s5, v2, vcc_lo               // 000000966604: D5207C02 01AA0405
	s_lshl_b64 s[4:5], s[6:7], 3                               // 00000096660C: 84848306
	.long 0xd7006a01                                           // 000000966610: D7006A01
	v_cndmask_b32_e32 v1, v1, v3, vcc_lo                       // 000000966614: 02020701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000966618: BF8700B1
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 00000096661C: D5207C02 01AA0480
	s_lshl_b64 s[6:7], s[6:7], 4                               // 000000966624: 84868406
	.long 0xd7006a01                                           // 000000966628: D7006A01
	v_cndmask_b32_e32 v1, s42, v1, vcc_lo                      // 00000096662C: 0202022A
	v_add_co_ci_u32_e64 v2, null, s43, v2, vcc_lo              // 000000966630: D5207C02 01AA042B
	s_nop 0                                                    // 000000966638: BF800000
	s_nop 0                                                    // 00000096663C: BF800000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000966640: BF870001
	v_dual_mov_b32 v4, v2 :: v_dual_mov_b32 v3, v1             // 000000966644: CA100102 04020101
	v_mov_b32_e32 v6, 0                                        // 00000096664C: 7E0C0280
	s_mov_b32 s1, s9                                           // 000000966650: BE810009
	global_load_b32 v7, v[3:4], off glc                        // 000000966654: DC524000 077C0003
	.long 0xd7006a03                                           // 00000096665C: D7006A03
	v_cndmask_b32_e32 v0, v3, v6, vcc_lo                       // 000000966660: 02000D03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000966664: BF8704A1
	v_add_co_ci_u32_e64 v4, null, s7, v4, vcc_lo               // 000000966668: D5207C04 01AA0807
	s_add_i32 s1, s1, -1                                       // 000000966670: 8101C101
	s_cmp_eq_u32 s1, 0                                         // 000000966674: BF068001
	s_waitcnt vmcnt(0)                                         // 000000966678: BF8903F7
	v_add_f32_e32 v6, v6, v7                                   // 00000096667C: 060C0F06
	s_cbranch_scc0 65524                                       // 000000966680: BFA1FFF4 <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_dn_tsILi4ELi8ELi4ELb0EEEvPKjPKDF16_PKiS5_PtNS0_4HtSdEiNS0_6HtFoldE+0x2354>
	v_add_nc_u32_e32 v4, 0x100, v5                             // 000000966684: 4A080AFF 00000100
	v_cmp_lt_u32_e32 vcc_lo, 0xff, v5                          // 00000096668C: 7C920AFF 000000FF
	.long 0xd7000101                                           // 000000966694: D7000101
	v_cndmask_b32_e32 v0, v1, v4, vcc_lo                       // 000000966698: 02000901
	v_lshlrev_b32_e32 v3, 2, v5                                // 00000096669C: 30060A82
	v_add_co_ci_u32_e64 v2, null, s5, v2, s1                   // 0000009666A0: D5207C02 00060405
	v_mov_b32_e32 v5, v4                                       // 0000009666A8: 7E0A0304
	s_or_b32 s22, vcc_lo, s22                                  // 0000009666AC: 8C16166A
	ds_store_b32 v3, v6 offset:16384                           // 0000009666B0: D8344000 00000603
	s_and_not1_b32 exec_lo, exec_lo, s22                       // 0000009666B8: 917E167E
	s_cbranch_execnz 65504                                     // 0000009666BC: BFA6FFE0 <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_dn_tsILi4ELi8ELi4ELb0EEEvPKjPKDF16_PKiS5_PtNS0_4HtSdEiNS0_6HtFoldE+0x2340>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000009666C0: 8C7E087E
	s_and_saveexec_b32 s1, s3                                  // 0000009666C4: BE812003
	s_cbranch_execz 6                                          // 0000009666C8: BFA50006 <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_dn_tsILi4ELi8ELi4ELb0EEEvPKjPKDF16_PKiS5_PtNS0_4HtSdEiNS0_6HtFoldE+0x23e4>
	s_lshl_b64 s[4:5], s[10:11], 2                             // 0000009666CC: 8484820A
	v_mov_b32_e32 v1, 0                                        // 0000009666D0: 7E020280
	s_add_u32 s4, s34, s4                                      // 0000009666D4: 80040422
	s_addc_u32 s5, s35, s5                                     // 0000009666D8: 82050523
	global_store_b32 v1, v1, s[4:5]                            // 0000009666DC: DC6A0000 00040101
	s_or_b32 exec_lo, exec_lo, s1                              // 0000009666E4: 8C7E017E
	s_mov_b32 s3, -1                                           // 0000009666E8: BE8300C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000009666EC: BF870009
	s_and_b32 vcc_lo, exec_lo, s3                              // 0000009666F0: 8B6A037E
	s_cbranch_vccz 382                                         // 0000009666F4: BFA3017E <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_dn_tsILi4ELi8ELi4ELb0EEEvPKjPKDF16_PKiS5_PtNS0_4HtSdEiNS0_6HtFoldE+0x29f0>
	v_cmp_gt_i32_e32 vcc_lo, s28, v19                          // 0000009666F8: 7C88261C
	.long 0xd44c0001                                           // 0000009666FC: D44C0001
	v_cndmask_b32_e32 v1, 0x80, v0, vcc_lo                     // 000000966700: 020200FF 00000080
	s_waitcnt lgkmcnt(0)                                       // 000000966708: BF89FC07
	s_waitcnt_vscnt null, 0x0                                  // 00000096670C: BC7C0000
	s_barrier                                                  // 000000966710: BFBD0000
	buffer_gl0_inv                                             // 000000966714: E0AC0000 00000000
	s_and_b32 s1, vcc_lo, s1                                   // 00000096671C: 8B01016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000966720: BF870009
	s_and_saveexec_b32 s3, s1                                  // 000000966724: BE832001
	s_cbranch_execz 368                                        // 000000966728: BFA50170 <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_dn_tsILi4ELi8ELi4ELb0EEEvPKjPKDF16_PKiS5_PtNS0_4HtSdEiNS0_6HtFoldE+0x29ec>
	v_and_b32_e32 v1, 15, v0                                   // 00000096672C: 3602008F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000966730: BF870091
	v_lshlrev_b32_e32 v2, 2, v1                                // 000000966734: 30040282
	v_lshl_or_b32 v2, v19, 9, v2                               // 000000966738: D6560002 04091313
	s_delay_alu instid0(VALU_DEP_1)                            // 000000966740: BF870001
	v_add_nc_u32_e32 v8, 0x4000, v2                            // 000000966744: 4A1004FF 00004000
	ds_load_2addr_b32 v[2:3], v8 offset1:16                    // 00000096674C: D8DC1000 02000008
	ds_load_2addr_b32 v[4:5], v8 offset0:32 offset1:48         // 000000966754: D8DC3020 04000008
	ds_load_2addr_b32 v[6:7], v8 offset0:64 offset1:80         // 00000096675C: D8DC5040 06000008
	ds_load_2addr_b32 v[8:9], v8 offset0:96 offset1:112        // 000000966764: D8DC7060 08000008
	v_and_b32_e32 v10, 1, v0                                   // 00000096676C: 36140081
	v_and_b32_e32 v11, 2, v0                                   // 000000966770: 36160082
	s_waitcnt lgkmcnt(3)                                       // 000000966774: BF89FC37
	v_dual_add_f32 v13, v2, v3 :: v_dual_and_b32 v12, 4, v0    // 000000966778: C9240702 0D0C0084
	s_waitcnt lgkmcnt(2)                                       // 000000966780: BF89FC27
	v_dual_sub_f32 v2, v2, v3 :: v_dual_add_f32 v3, v4, v5     // 000000966784: C9480702 02020B04
	s_waitcnt lgkmcnt(1)                                       // 00000096678C: BF89FC17
	v_dual_sub_f32 v4, v4, v5 :: v_dual_add_f32 v5, v6, v7     // 000000966790: C9480B04 04040F06
	s_waitcnt lgkmcnt(0)                                       // 000000966798: BF89FC07
	v_dual_sub_f32 v6, v6, v7 :: v_dual_add_f32 v7, v8, v9     // 00000096679C: C9480F06 06061308
	v_dual_sub_f32 v8, v8, v9 :: v_dual_add_f32 v9, v13, v3    // 0000009667A4: C9481308 0808070D
	v_sub_f32_e32 v3, v13, v3                                  // 0000009667AC: 0806070D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000009667B0: BF870243
	v_dual_add_f32 v13, v2, v4 :: v_dual_add_f32 v14, v5, v7   // 0000009667B4: C9080902 0D0E0F05
	v_dual_sub_f32 v2, v2, v4 :: v_dual_sub_f32 v5, v5, v7     // 0000009667BC: C94A0902 02040F05
	v_cmp_eq_u32_e32 vcc_lo, 0, v10                            // 0000009667C4: 7C941480
	.long 0xd44a0001                                           // 0000009667C8: D44A0001
	v_cndmask_b32_e32 v1, 0, v12, vcc_lo                       // 0000009667CC: 02021880
	v_dual_add_f32 v7, v9, v14 :: v_dual_add_f32 v4, v6, v8    // 0000009667D0: C9081D09 07041106
	v_sub_f32_e32 v6, v6, v8                                   // 0000009667D8: 080C1106
	v_sub_f32_e32 v8, v9, v14                                  // 0000009667DC: 08101D09
	s_delay_alu instid0(VALU_DEP_3)                            // 0000009667E0: BF870003
	v_add_f32_e32 v9, v13, v4                                  // 0000009667E4: 0612090D
	v_dual_sub_f32 v4, v13, v4 :: v_dual_add_f32 v13, v3, v5   // 0000009667E8: C948090D 040C0B03
	v_sub_f32_e32 v3, v3, v5                                   // 0000009667F0: 08060B03
	v_add_f32_e32 v5, v2, v6                                   // 0000009667F4: 060A0D02
	v_sub_f32_e32 v2, v2, v6                                   // 0000009667F8: 08040D02
	v_mov_b32_dpp v6, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009667FC: 7E0C02FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, vcc_lo                      // 000000966804: D5010007 21AA0F07
	v_mov_b32_dpp v10, v9 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000096680C: 7E1402FA FF016109
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 000000966814: D5010009 21AA1309
	v_mov_b32_dpp v14, v13 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000096681C: 7E1C02FA FF01610D
	v_cndmask_b32_e64 v13, -v13, v13, vcc_lo                   // 000000966824: D501000D 21AA1B0D
	v_mov_b32_dpp v15, v5 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000096682C: 7E1E02FA FF016105
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 000000966834: D5010005 21AA0B05
	v_mov_b32_dpp v16, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000096683C: 7E2002FA FF016108
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 000000966844: D5010008 21AA1108
	v_mov_b32_dpp v17, v4 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000096684C: 7E2202FA FF016104
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 000000966854: D5010004 21AA0904
	v_mov_b32_dpp v18, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000096685C: 7E2402FA FF016103
	v_cndmask_b32_e64 v21, -v3, v3, vcc_lo                     // 000000966864: D5010015 21AA0703
	v_cndmask_b32_e64 v23, -v2, v2, vcc_lo                     // 00000096686C: D5010017 21AA0502
	v_cmp_eq_u32_e32 vcc_lo, 0, v11                            // 000000966874: 7C941680
	v_dual_add_f32 v3, v7, v6 :: v_dual_add_f32 v8, v8, v16    // 000000966878: C9080D07 03082108
	v_mov_b32_dpp v22, v2 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000966880: 7E2C02FA FF016102
	v_dual_add_f32 v2, v9, v10 :: v_dual_add_f32 v9, v4, v17   // 000000966888: C9081509 02082304
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000966890: BF870233
	v_mov_b32_dpp v4, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000966894: 7E0802FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 00000096689C: D5010003 21AA0703
	v_add_f32_e32 v6, v13, v14                                 // 0000009668A4: 060C1D0D
	v_mov_b32_dpp v7, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009668A8: 7E0E02FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, vcc_lo                      // 0000009668B0: D5010002 21AA0502
	v_mov_b32_dpp v12, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009668B8: 7E1802FA FF016208
	v_add_f32_e32 v3, v3, v4                                   // 0000009668C0: 06060903
	v_mov_b32_dpp v10, v6 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009668C4: 7E1402FA FF016206
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 0000009668CC: D5010006 21AA0D06
	v_add_f32_e32 v5, v5, v15                                  // 0000009668D4: 060A1F05
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 0000009668D8: D5010008 21AA1108
	v_add_f32_e32 v13, v23, v22                                // 0000009668E0: 061A2D17
	v_mov_b32_dpp v14, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009668E4: 7E1C02FA FF016209
	v_add_f32_e32 v6, v6, v10                                  // 0000009668EC: 060C1506
	v_mov_b32_dpp v11, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009668F0: 7E1602FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 0000009668F8: D5010005 21AA0B05
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 000000966900: D5010009 21AA1309
	v_add_f32_e32 v8, v8, v12                                  // 000000966908: 06101908
	v_mov_b32_dpp v15, v13 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000096690C: 7E1E02FA FF01620D
	v_cndmask_b32_e64 v13, -v13, v13, vcc_lo                   // 000000966914: D501000D 21AA1B0D
	v_add_f32_e32 v4, v5, v11                                  // 00000096691C: 06081705
	v_mov_b32_dpp v5, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000966920: 7E0A02FA FF016403
	v_cndmask_b32_e64 v3, -v3, v3, s1                          // 000000966928: D5010003 20060703
	v_add_f32_e32 v2, v2, v7                                   // 000000966930: 06040F02
	v_mov_b32_dpp v11, v6 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000966934: 7E1602FA FF016406
	v_cndmask_b32_e64 v6, -v6, v6, s1                          // 00000096693C: D5010006 20060D06
	v_add_f32_e32 v9, v9, v14                                  // 000000966944: 06121D09
	v_add_f32_e32 v3, v3, v5                                   // 000000966948: 06060B03
	v_cndmask_b32_e64 v7, -v2, v2, s1                          // 00000096694C: D5010007 20060502
	v_mov_b32_dpp v2, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000966954: 7E0402FA FF016402
	v_add_f32_e32 v6, v6, v11                                  // 00000096695C: 060C1706
	v_mov_b32_dpp v11, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000966960: 7E1602FA FF016408
	v_cndmask_b32_e64 v14, -v8, v8, s1                         // 000000966968: D501000E 20061108
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000966970: BF870234
	v_add_f32_e32 v7, v7, v2                                   // 000000966974: 060E0507
	v_mov_b32_dpp v10, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000966978: 7E1402FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s1                          // 000000966980: D5010004 20060904
	v_add_f32_e32 v14, v14, v11                                // 000000966988: 061C170E
	v_mov_b32_dpp v2, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000096698C: 7E0402FA FF016803
	v_mov_b32_dpp v5, v7 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000966994: 7E0A02FA FF016807
	v_mov_b32_dpp v8, v6 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000096699C: 7E1002FA FF016806
	v_add_f32_e32 v4, v4, v10                                  // 0000009669A4: 06081504
	v_add_f32_e32 v10, v21, v18                                // 0000009669A8: 06142515
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000009669AC: BF8700A1
	v_mov_b32_dpp v12, v10 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009669B0: 7E1802FA FF01620A
	v_cndmask_b32_e64 v10, -v10, v10, vcc_lo                   // 0000009669B8: D501000A 21AA150A
	v_add_f32_e32 v10, v10, v12                                // 0000009669C0: 0614190A
	v_add_f32_e32 v12, v13, v15                                // 0000009669C4: 06181F0D
	v_mov_b32_dpp v13, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009669C8: 7E1A02FA FF016409
	v_cndmask_b32_e64 v9, -v9, v9, s1                          // 0000009669D0: D5010009 20061309
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009669D8: BF870214
	v_mov_b32_dpp v15, v10 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009669DC: 7E1E02FA FF01640A
	v_mov_b32_dpp v17, v12 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009669E4: 7E2202FA FF01640C
	v_cndmask_b32_e64 v10, -v10, v10, s1                       // 0000009669EC: D501000A 2006150A
	v_cndmask_b32_e64 v12, -v12, v12, s1                       // 0000009669F4: D501000C 2006190C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000009669FC: BF870112
	v_dual_add_f32 v16, v9, v13 :: v_dual_add_f32 v15, v10, v15// 000000966A00: C9081B09 100E1F0A
	v_add_f32_e32 v17, v12, v17                                // 000000966A08: 0622230C
	v_mov_b32_dpp v9, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000966A0C: 7E1202FA FF016804
	v_mov_b32_dpp v10, v14 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000966A14: 7E1402FA FF01680E
	s_delay_alu instid0(VALU_DEP_4)                            // 000000966A1C: BF870004
	v_mov_b32_dpp v11, v16 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000966A20: 7E1602FA FF016810
	v_mov_b32_dpp v12, v15 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000966A28: 7E1802FA FF01680F
	v_mov_b32_dpp v13, v17 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000966A30: 7E1A02FA FF016811
	s_and_b32 exec_lo, exec_lo, s0                             // 000000966A38: 8B7E007E
	s_cbranch_execz 171                                        // 000000966A3C: BFA500AB <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_dn_tsILi4ELi8ELi4ELb0EEEvPKjPKDF16_PKiS5_PtNS0_4HtSdEiNS0_6HtFoldE+0x29ec>
	v_lshl_or_b32 v21, s10, 7, v1                              // 000000966A40: D6560015 04050E0A
	v_and_b32_e32 v1, 8, v0                                    // 000000966A48: 36020088
	.long 0x7f243880                                           // 000000966A4C: 7F243880
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000966A50: BF870113
	v_ashrrev_i32_e32 v22, 31, v21                             // 000000966A54: 342C2A9F
	.long 0x7f323992                                           // 000000966A58: 7F323992
	.long 0x7f363992                                           // 000000966A5C: 7F363992
	.long 0x7f343992                                           // 000000966A60: 7F343992
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000966A64: BF870094
	.long 0xd73c0015                                           // 000000966A68: D73C0015
	v_cndmask_b32_e32 v1, 1, v21, vcc_lo                       // 000000966A6C: 02022A81
	.long 0xd7006a17                                           // 000000966A70: D7006A17
	v_cndmask_b32_e32 v1, s26, v21, vcc_lo                     // 000000966A74: 02022A1A
	s_delay_alu instid0(VALU_DEP_1)                            // 000000966A78: BF870001
	v_add_co_ci_u32_e64 v24, null, s27, v22, vcc_lo            // 000000966A7C: D5207C18 01AA2C1B
	v_cmp_eq_u32_e32 vcc_lo, 0, v1                             // 000000966A84: 7C940280
	s_clause 0x7                                               // 000000966A88: BF850007
	global_load_d16_b16 v18, v[23:24], off offset:32           // 000000966A8C: DC820020 127C0017
	global_load_d16_b16 v25, v[23:24], off                     // 000000966A94: DC820000 197C0017
	global_load_d16_b16 v26, v[23:24], off offset:64           // 000000966A9C: DC820040 1A7C0017
	global_load_d16_b16 v27, v[23:24], off offset:96           // 000000966AA4: DC820060 1B7C0017
	global_load_d16_b16 v28, v[23:24], off offset:128          // 000000966AAC: DC820080 1C7C0017
	global_load_d16_b16 v29, v[23:24], off offset:160          // 000000966AB4: DC8200A0 1D7C0017
	global_load_d16_b16 v30, v[23:24], off offset:192          // 000000966ABC: DC8200C0 1E7C0017
	global_load_d16_b16 v31, v[23:24], off offset:224          // 000000966AC4: DC8200E0 1F7C0017
	v_mad_i64_i32 v[23:24], null, s29, v19, 0                  // 000000966ACC: D6FF7C17 0202261D
	v_cndmask_b32_e64 v1, -v7, v7, vcc_lo                      // 000000966AD4: D5010001 21AA0F07
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 000000966ADC: D5010003 21AA0703
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 000000966AE4: D5010004 21AA0904
	v_cndmask_b32_e64 v14, -v14, v14, vcc_lo                   // 000000966AEC: D501000E 21AA1D0E
	v_cndmask_b32_e64 v15, -v15, v15, vcc_lo                   // 000000966AF4: D501000F 21AA1F0F
	v_add_f32_e32 v1, v1, v5                                   // 000000966AFC: 06020B01
	v_cndmask_b32_e64 v5, -v6, v6, vcc_lo                      // 000000966B00: D5010005 21AA0D06
	.long 0xd73c0017                                           // 000000966B08: D73C0017
	v_cndmask_b32_e32 v1, 1, v23, vcc_lo                       // 000000966B0C: 02022E81
	v_cndmask_b32_e64 v6, -v16, v16, vcc_lo                    // 000000966B10: D5010006 21AA2110
	v_cndmask_b32_e64 v16, -v17, v17, vcc_lo                   // 000000966B18: D5010010 21AA2311
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000966B20: BF8700B4
	v_dual_add_f32 v4, v4, v9 :: v_dual_add_f32 v5, v5, v8     // 000000966B24: C9081304 04041105
	v_add_f32_e32 v8, v14, v10                                 // 000000966B2C: 0610150E
	.long 0xd7006a11                                           // 000000966B30: D7006A11
	v_cndmask_b32_e32 v1, s40, v23, vcc_lo                     // 000000966B34: 02022E28
	v_add_co_ci_u32_e64 v23, null, s41, v24, vcc_lo            // 000000966B38: D5207C17 01AA3029
	v_dual_add_f32 v3, v3, v2 :: v_dual_mul_f32 v24, 0x3db504f3, v1// 000000966B40: C9060503 031802FF 3DB504F3
	v_add_f32_e32 v6, v6, v11                                  // 000000966B4C: 060C1706
	v_mul_f32_e32 v4, 0x3db504f3, v4                           // 000000966B50: 100808FF 3DB504F3
	v_dual_add_f32 v9, v15, v12 :: v_dual_add_f32 v10, v16, v13// 000000966B58: C908190F 090A1B10
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000966B60: BF870214
	v_mul_f32_e32 v3, 0x3db504f3, v3                           // 000000966B64: 100606FF 3DB504F3
	v_dual_mul_f32 v5, 0x3db504f3, v5 :: v_dual_mul_f32 v6, 0x3db504f3, v6// 000000966B6C: C8C60AFF 05060CFF 3DB504F3
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000966B78: BF8700C3
	v_dual_mul_f32 v8, 0x3db504f3, v8 :: v_dual_mul_f32 v9, 0x3db504f3, v9// 000000966B7C: C8C610FF 080812FF 3DB504F3
	s_waitcnt vmcnt(7)                                         // 000000966B88: BF891FF7
	.long 0x7f0e3992                                           // 000000966B8C: 7F0E3992
	.long 0xd7006a01                                           // 000000966B90: D7006A01
	v_cndmask_b32_e32 v1, v17, v21, vcc_lo                     // 000000966B94: 02022B11
	v_add_co_ci_u32_e64 v2, null, v23, v22, vcc_lo             // 000000966B98: D5207C02 01AA2D17
	v_fma_mix_f32 v11, v18, v24, neg(0) op_sel_hi:[1,0,0]      // 000000966BA0: CC20000B 8A023112
	s_waitcnt vmcnt(6)                                         // 000000966BA8: BF891BF7
	v_fma_mix_f32 v3, v25, v3, neg(0) op_sel_hi:[1,0,0]        // 000000966BAC: CC200003 8A020719
	s_waitcnt vmcnt(5)                                         // 000000966BB4: BF8917F7
	v_fma_mix_f32 v5, v26, v5, neg(0) op_sel_hi:[1,0,0]        // 000000966BB8: CC200005 8A020B1A
	s_waitcnt vmcnt(4)                                         // 000000966BC0: BF8913F7
	v_fma_mix_f32 v4, v27, v4, neg(0) op_sel_hi:[1,0,0]        // 000000966BC4: CC200004 8A02091B
	s_waitcnt vmcnt(3)                                         // 000000966BCC: BF890FF7
	v_fma_mix_f32 v8, v28, v8, neg(0) op_sel_hi:[1,0,0]        // 000000966BD0: CC200008 8A02111C
	.long 0x7e24398b                                           // 000000966BD8: 7E24398B
	s_waitcnt vmcnt(2)                                         // 000000966BDC: BF890BF7
	v_fma_mix_f32 v6, v29, v6, neg(0) op_sel_hi:[1,0,0]        // 000000966BE0: CC200006 8A020D1D
	.long 0x7e0e3983                                           // 000000966BE8: 7E0E3983
	v_mul_f32_e32 v10, 0x3db504f3, v10                         // 000000966BEC: 101414FF 3DB504F3
	s_waitcnt vmcnt(1)                                         // 000000966BF4: BF8907F7
	v_fma_mix_f32 v9, v30, v9, neg(0) op_sel_hi:[1,0,0]        // 000000966BF8: CC200009 8A02131E
	v_and_b32_e32 v12, 1, v18                                  // 000000966C00: 36182481
	.long 0x7e243984                                           // 000000966C04: 7E243984
	v_and_b32_e32 v7, 1, v7                                    // 000000966C08: 360E0E81
	s_waitcnt vmcnt(0)                                         // 000000966C0C: BF8903F7
	v_fma_mix_f32 v10, v31, v10, neg(0) op_sel_hi:[1,0,0]      // 000000966C10: CC20000A 8A02151F
	.long 0x7e323985                                           // 000000966C18: 7E323985
	.long 0x7e343988                                           // 000000966C1C: 7E343988
	v_and_b32_e32 v13, 1, v18                                  // 000000966C20: 361A2481
	.long 0x7e243986                                           // 000000966C24: 7E243986
	.long 0x7e363989                                           // 000000966C28: 7E363989
	v_and_b32_e32 v14, 1, v25                                  // 000000966C2C: 361C3281
	v_and_b32_e32 v15, 1, v26                                  // 000000966C30: 361E3481
	v_add3_u32 v3, v3, v7, 0x7fff                              // 000000966C34: D6550003 03FE0F03 00007FFF
	v_and_b32_e32 v16, 1, v18                                  // 000000966C40: 36202481
	.long 0x7e24398a                                           // 000000966C44: 7E24398A
	v_and_b32_e32 v17, 1, v27                                  // 000000966C48: 36223681
	v_add3_u32 v11, v11, v12, 0x7fff                           // 000000966C4C: D655000B 03FE190B 00007FFF
	v_add3_u32 v5, v5, v14, 0x7fff                             // 000000966C58: D6550005 03FE1D05 00007FFF
	v_add3_u32 v4, v4, v13, 0x7fff                             // 000000966C64: D6550004 03FE1B04 00007FFF
	v_and_b32_e32 v7, 1, v18                                   // 000000966C70: 360E2481
	v_add3_u32 v8, v8, v15, 0x7fff                             // 000000966C74: D6550008 03FE1F08 00007FFF
	v_add3_u32 v9, v9, v17, 0x7fff                             // 000000966C80: D6550009 03FE2309 00007FFF
	v_add3_u32 v6, v6, v16, 0x7fff                             // 000000966C8C: D6550006 03FE2106 00007FFF
	s_delay_alu instid0(VALU_DEP_4)                            // 000000966C98: BF870004
	v_add3_u32 v7, v10, v7, 0x7fff                             // 000000966C9C: D6550007 03FE0F0A 00007FFF
	s_clause 0x7                                               // 000000966CA8: BF850007
	global_store_d16_hi_b16 v[1:2], v3, off                    // 000000966CAC: DC960000 007C0301
	global_store_d16_hi_b16 v[1:2], v11, off offset:32         // 000000966CB4: DC960020 007C0B01
	global_store_d16_hi_b16 v[1:2], v5, off offset:64          // 000000966CBC: DC960040 007C0501
	global_store_d16_hi_b16 v[1:2], v4, off offset:96          // 000000966CC4: DC960060 007C0401
	global_store_d16_hi_b16 v[1:2], v8, off offset:128         // 000000966CCC: DC960080 007C0801
	global_store_d16_hi_b16 v[1:2], v6, off offset:160         // 000000966CD4: DC9600A0 007C0601
	global_store_d16_hi_b16 v[1:2], v9, off offset:192         // 000000966CDC: DC9600C0 007C0901
	global_store_d16_hi_b16 v[1:2], v7, off offset:224         // 000000966CE4: DC9600E0 007C0701
	s_or_b32 exec_lo, exec_lo, s3                              // 000000966CEC: 8C7E037E
	s_mov_b32 s4, 0                                            // 000000966CF0: BE840080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000966CF4: BF870009
	s_and_b32 vcc_lo, exec_lo, s4                              // 000000966CF8: 8B6A047E
	s_cbranch_vccz 1676                                        // 000000966CFC: BFA3068C <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_dn_tsILi4ELi8ELi4ELb0EEEvPKjPKDF16_PKiS5_PtNS0_4HtSdEiNS0_6HtFoldE+0x4430>
	s_mul_hi_i32 s0, s2, 0x66666667                            // 000000966D00: 9700FF02 66666667
	v_mov_b32_e32 v8, 0                                        // 000000966D08: 7E100280
	s_lshr_b32 s1, s0, 31                                      // 000000966D0C: 85019F00
	s_ashr_i32 s0, s0, 3                                       // 000000966D10: 86008300
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000966D14: BF870499
	s_add_i32 s4, s0, s1                                       // 000000966D18: 81040100
	s_ashr_i32 s5, s4, 31                                      // 000000966D1C: 86059F04
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000966D20: BF870499
	s_lshl_b64 s[0:1], s[4:5], 2                               // 000000966D24: 84808204
	s_add_u32 s0, s16, s0                                      // 000000966D28: 80000010
	s_addc_u32 s1, s17, s1                                     // 000000966D2C: 82010111
	global_load_b32 v1, v8, s[0:1]                             // 000000966D30: DC520000 01000008
	s_mov_b32 s0, exec_lo                                      // 000000966D38: BE80007E
	s_waitcnt vmcnt(0)                                         // 000000966D3C: BF8903F7
	v_readfirstlane_b32 s3, v1                                 // 000000966D40: 7E060501
	v_cmpx_gt_u32_e32 0x50, v0                                 // 000000966D44: 7D9800FF 00000050
	s_cbranch_execz 12                                         // 000000966D4C: BFA5000C <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_dn_tsILi4ELi8ELi4ELb0EEEvPKjPKDF16_PKiS5_PtNS0_4HtSdEiNS0_6HtFoldE+0x2a80>
	s_mul_i32 s1, s4, 0x500                                    // 000000966D50: 9601FF04 00000500
	v_lshlrev_b32_e32 v5, 4, v0                                // 000000966D58: 300A0084
	s_mul_hi_i32 s5, s4, 0x500                                 // 000000966D5C: 9705FF04 00000500
	s_add_u32 s6, s14, s1                                      // 000000966D64: 8006010E
	s_addc_u32 s7, s15, s5                                     // 000000966D68: 8207050F
	global_load_b128 v[1:4], v5, s[6:7]                        // 000000966D6C: DC5E0000 01060005
	s_waitcnt vmcnt(0)                                         // 000000966D74: BF8903F7
	ds_store_b128 v5, v[1:4] offset:20480                      // 000000966D78: DB7C5000 00000105
	s_or_b32 exec_lo, exec_lo, s0                              // 000000966D80: 8C7E007E
	v_mul_u32_u24_e32 v1, 5, v19                               // 000000966D84: 16022685
	s_mul_i32 s5, s4, 0xffffffec                               // 000000966D88: 9605FF04 FFFFFFEC
	v_dual_mov_b32 v12, 0 :: v_dual_lshlrev_b32 v7, 2, v20     // 000000966D90: CA220080 0C062882
	v_dual_mov_b32 v11, 0 :: v_dual_mov_b32 v14, 0             // 000000966D98: CA100080 0B0E0080
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000966DA0: BF870243
	v_min_u32_e32 v2, 35, v1                                   // 000000966DA4: 260402A3
	v_dual_mov_b32 v13, 0 :: v_dual_mov_b32 v16, 0             // 000000966DA8: CA100080 0D100080
	v_mov_b32_e32 v15, 0                                       // 000000966DB0: 7E1E0280
	v_mov_b32_e32 v17, 0                                       // 000000966DB4: 7E220280
	v_add_nc_u32_e32 v9, 5, v2                                 // 000000966DB8: 4A120485
	s_add_i32 s5, s5, s2                                       // 000000966DBC: 81050205
	s_mul_hi_i32 s6, s3, 0xc8000                               // 000000966DC0: 9706FF03 000C8000
	s_mul_i32 s7, s3, 0xc8000                                  // 000000966DC8: 9607FF03 000C8000
	s_mul_hi_i32 s2, s5, 0xa000                                // 000000966DD0: 9702FF05 0000A000
	v_cmp_lt_u32_e32 vcc_lo, v1, v9                            // 000000966DD8: 7C921301
	s_mul_i32 s8, s5, 0xa000                                   // 000000966DDC: 9608FF05 0000A000
	s_waitcnt lgkmcnt(0)                                       // 000000966DE4: BF89FC07
	s_waitcnt_vscnt null, 0x0                                  // 000000966DE8: BC7C0000
	s_barrier                                                  // 000000966DEC: BFBD0000
	buffer_gl0_inv                                             // 000000966DF0: E0AC0000 00000000
	s_and_saveexec_b32 s1, vcc_lo                              // 000000966DF8: BE81206A
	s_cbranch_execz 33                                         // 000000966DFC: BFA50021 <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_dn_tsILi4ELi8ELi4ELb0EEEvPKjPKDF16_PKiS5_PtNS0_4HtSdEiNS0_6HtFoldE+0x2b84>
	v_mul_u32_u24_e32 v3, 0x1400, v19                          // 000000966E00: 160626FF 00001400
	s_add_u32 s0, s12, s7                                      // 000000966E08: 8000070C
	s_addc_u32 s9, s13, s6                                     // 000000966E0C: 8209060D
	s_add_u32 s0, s0, s8                                       // 000000966E10: 80000800
	s_addc_u32 s9, s9, s2                                      // 000000966E14: 82090209
	.long 0xd7000003                                           // 000000966E18: D7000003
	v_cndmask_b32_e32 v1, s0, v3, vcc_lo                       // 000000966E1C: 02020600
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000966E20: BF870111
	v_add_co_ci_u32_e64 v4, null, s9, 0, s0                    // 000000966E24: D5207C04 00010009
	.long 0xd7000003                                           // 000000966E2C: D7000003
	v_cndmask_b32_e32 v1, v3, v7, vcc_lo                       // 000000966E30: 02020F03
	s_delay_alu instid0(VALU_DEP_1)                            // 000000966E34: BF870001
	v_add_co_ci_u32_e64 v4, null, 0, v4, s0                    // 000000966E38: D5207C04 00020880
	s_clause 0x7                                               // 000000966E40: BF850007
	global_load_b32 v8, v[3:4], off                            // 000000966E44: DC520000 087C0003
	global_load_b32 v11, v[3:4], off offset:128                // 000000966E4C: DC520080 0B7C0003
	global_load_b32 v12, v[3:4], off offset:256                // 000000966E54: DC520100 0C7C0003
	global_load_b32 v13, v[3:4], off offset:384                // 000000966E5C: DC520180 0D7C0003
	global_load_b32 v14, v[3:4], off offset:512                // 000000966E64: DC520200 0E7C0003
	global_load_b32 v15, v[3:4], off offset:640                // 000000966E6C: DC520280 0F7C0003
	global_load_b32 v16, v[3:4], off offset:768                // 000000966E74: DC520300 107C0003
	global_load_b32 v17, v[3:4], off offset:896                // 000000966E7C: DC520380 117C0003
	s_or_b32 exec_lo, exec_lo, s1                              // 000000966E84: 8C7E017E
	v_dual_mov_b32 v26, 0 :: v_dual_mov_b32 v21, 0             // 000000966E88: CA100080 1A140080
	v_dual_mov_b32 v18, 0 :: v_dual_mov_b32 v23, 0             // 000000966E90: CA100080 12160080
	v_dual_mov_b32 v22, 0 :: v_dual_mov_b32 v25, 0             // 000000966E98: CA100080 16180080
	v_mov_b32_e32 v24, 0                                       // 000000966EA0: 7E300280
	v_mov_b32_e32 v10, 0                                       // 000000966EA4: 7E140280
	s_and_saveexec_b32 s1, vcc_lo                              // 000000966EA8: BE81206A
	s_cbranch_execz 985                                        // 000000966EAC: BFA503D9 <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_dn_tsILi4ELi8ELi4ELb0EEEvPKjPKDF16_PKiS5_PtNS0_4HtSdEiNS0_6HtFoldE+0x3b14>
	v_dual_mov_b32 v10, 0 :: v_dual_lshlrev_b32 v3, 5, v20     // 000000966EB0: CA220080 0A022885
	v_cmp_ne_u32_e32 vcc_lo, 0, v20                            // 000000966EB8: 7C9A2880
	v_dual_mov_b32 v25, 0 :: v_dual_and_b32 v6, 16, v0         // 000000966EBC: CA240080 19060090
	s_delay_alu instid0(VALU_DEP_3)                            // 000000966EC4: BF870003
	v_add_nc_u32_e32 v4, 0x3f0, v3                             // 000000966EC8: 4A0806FF 000003F0
	v_lshlrev_b32_e32 v18, 10, v1                              // 000000966ED0: 3024028A
	s_movk_i32 s0, 0x420                                       // 000000966ED4: B0000420
	s_add_u32 s7, s7, s8                                       // 000000966ED8: 80070807
	s_addc_u32 s2, s6, s2                                      // 000000966EDC: 82020206
	v_lshrrev_b32_e32 v5, 5, v4                                // 000000966EE0: 320A0885
	v_mad_u32_u24 v21, v19, s0, 0x5000                         // 000000966EE4: D60B0015 03FC0113 00005000
	v_lshl_or_b32 v27, v1, 5, v6                               // 000000966EF0: D656001B 04190B01
	v_sub_nc_u32_e32 v29, 0, v2                                // 000000966EF8: 4C3A0480
	v_add_nc_u32_e32 v30, 1, v1                                // 000000966EFC: 4A3C0281
	v_subrev_nc_u32_e32 v5, 32, v5                             // 000000966F00: 4E0A0AA0
	v_add_nc_u32_e32 v22, v21, v7                              // 000000966F04: 4A2C0F15
	s_movk_i32 s6, 0x1eee                                      // 000000966F08: B0061EEE
	v_mov_b32_e32 v24, 0                                       // 000000966F0C: 7E300280
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000966F10: BF870123
	v_dual_mov_b32 v26, 0 :: v_dual_cndmask_b32 v5, 31, v5     // 000000966F14: CA120080 1A040A9F
	v_and_b32_e32 v4, 0x7e0, v4                                // 000000966F1C: 360808FF 000007E0
	v_add_nc_u32_e32 v23, 1, v5                                // 000000966F24: 4A2E0A81
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000966F28: BF870112
	v_sub_nc_u32_e32 v3, v4, v3                                // 000000966F2C: 4C060704
	v_dual_mov_b32 v23, 0 :: v_dual_and_b32 v4, 31, v23        // 000000966F30: CA240080 17042E9F
	.long 0xd7000006                                           // 000000966F38: D7000006
	v_cndmask_b32_e32 v1, s7, v18, vcc_lo                      // 000000966F3C: 02022407
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000966F40: BF870211
	v_add_co_ci_u32_e64 v18, null, s2, 0, s0                   // 000000966F44: D5207C12 00010002
	v_add_nc_u32_e32 v28, 0xfffffc30, v3                       // 000000966F4C: 4A3806FF FFFFFC30
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000966F54: BF870093
	.long 0xd7006a06                                           // 000000966F58: D7006A06
	v_cndmask_b32_e32 v1, v6, v7, vcc_lo                       // 000000966F5C: 02020F06
	v_add_co_ci_u32_e64 v18, null, 0, v18, vcc_lo              // 000000966F60: D5207C12 01AA2480
	v_lshl_add_u32 v3, v5, 2, v21                              // 000000966F68: D6460003 04550505
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000966F70: BF870093
	.long 0xd7006a06                                           // 000000966F74: D7006A06
	v_cndmask_b32_e32 v1, s12, v6, vcc_lo                      // 000000966F78: 02020C0C
	v_add_co_ci_u32_e64 v18, null, s13, v18, vcc_lo            // 000000966F7C: D5207C12 01AA240D
	v_lshl_add_u32 v4, v4, 2, v21                              // 000000966F84: D6460004 04550504
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000966F8C: BF870093
	.long 0xd7006a05                                           // 000000966F90: D7006A05
	v_cndmask_b32_e32 v1, 0x400, v6, vcc_lo                    // 000000966F94: 02020CFF 00000400
	v_add_co_ci_u32_e64 v6, null, 0, v18, vcc_lo               // 000000966F9C: D5207C06 01AA2480
	v_dual_mov_b32 v18, 0 :: v_dual_add_nc_u32 v33, 0x400, v3  // 000000966FA4: CA200080 122006FF 00000400
	s_delay_alu instid0(VALU_DEP_4)                            // 000000966FB0: BF870004
	v_add_nc_u32_e32 v34, 0x400, v4                            // 000000966FB4: 4A4408FF 00000400
	v_add_nc_u32_e32 v35, 0x800, v3                            // 000000966FBC: 4A4606FF 00000800
	v_dual_mov_b32 v21, 0 :: v_dual_add_nc_u32 v36, 0x800, v4  // 000000966FC4: CA200080 152408FF 00000800
	v_add_nc_u32_e32 v31, 0x400, v22                           // 000000966FD0: 4A3E2CFF 00000400
	v_add_nc_u32_e32 v32, 0x800, v22                           // 000000966FD8: 4A402CFF 00000800
	v_mov_b32_e32 v22, 0                                       // 000000966FE0: 7E2C0280
	s_mov_b32 s2, 0                                            // 000000966FE4: BE820080
	s_branch 871                                               // 000000966FE8: BFA00367 <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_dn_tsILi4ELi8ELi4ELb0EEEvPKjPKDF16_PKiS5_PtNS0_4HtSdEiNS0_6HtFoldE+0x3a88>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000966FEC: 8C7E007E
	ds_load_2addr_b32 v[37:38], v34 offset0:64 offset1:96      // 000000966FF0: D8DC6040 25000022
	ds_load_2addr_b32 v[43:44], v31 offset0:64 offset1:96      // 000000966FF8: D8DC6040 2B00001F
	ds_load_2addr_b32 v[41:42], v33 offset0:64 offset1:96      // 000000967000: D8DC6040 29000021
	ds_load_b128 v[1:4], v27 offset:20480                      // 000000967008: DBFC5000 0100001B
	v_add_nc_u32_e32 v30, 1, v30                               // 000000967010: 4A3C3C81
	.long 0xd7000005                                           // 000000967014: D7000005
	v_cndmask_b32_e32 v1, 0x400, v5, vcc_lo                    // 000000967018: 02020AFF 00000400
	v_add_nc_u32_e32 v27, 32, v27                              // 000000967020: 4A3636A0
	v_add_co_ci_u32_e64 v6, null, 0, v6, s0                    // 000000967024: D5207C06 00020C80
	s_waitcnt lgkmcnt(3)                                       // 00000096702C: BF89FC37
	v_mov_b32_e32 v40, v37                                     // 000000967030: 7E500325
	s_waitcnt lgkmcnt(2)                                       // 000000967034: BF89FC27
	v_bfe_u32 v37, v43, 12, 16                                 // 000000967038: D6100025 0241192B
	s_waitcnt lgkmcnt(1)                                       // 000000967040: BF89FC17
	v_mov_b32_e32 v39, v42                                     // 000000967044: 7E4E032A
	v_bfe_u32 v45, v43, 8, 16                                  // 000000967048: D610002D 0241112B
	v_bfe_u32 v46, v43, 4, 16                                  // 000000967050: D610002E 0241092B
	v_and_b32_e32 v43, 0xffff, v43                             // 000000967058: 365656FF 0000FFFF
	.long 0xd73d0028                                           // 000000967060: D73D0028
	v_cndmask_b32_e32 v1, v28, v40, vcc_lo                     // 000000967064: 0202511C
	v_bfe_u32 v42, v44, 12, 16                                 // 000000967068: D610002A 0241192C
	v_bfe_u32 v47, v44, 8, 16                                  // 000000967070: D610002F 0241112C
	v_bfe_u32 v48, v44, 4, 16                                  // 000000967078: D6100030 0241092C
	v_and_b32_e32 v44, 0xffff, v44                             // 000000967080: 365858FF 0000FFFF
	.long 0xd72c0029                                           // 000000967088: D72C0029
	v_cndmask_b32_e32 v1, 0x83dcd12d, v37, vcc_lo              // 00000096708C: 02024AFF 83DCD12D
	.long 0xd73d0025                                           // 000000967094: D73D0025
	v_cndmask_b32_e32 v1, v28, v38, vcc_lo                     // 000000967098: 02024D1C
	.long 0xd72c002b                                           // 00000096709C: D72C002B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v43, vcc_lo              // 0000009670A0: 020256FF 83DCD12D
	.long 0xd72c002e                                           // 0000009670A8: D72C002E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v46, vcc_lo              // 0000009670AC: 02025CFF 83DCD12D
	.long 0xd72c002d                                           // 0000009670B4: D72C002D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v45, vcc_lo              // 0000009670B8: 02025AFF 83DCD12D
	v_bfe_u32 v49, v40, 4, 16                                  // 0000009670C0: D6100031 02410928
	v_bfe_u32 v38, v40, 12, 16                                 // 0000009670C8: D6100026 02411928
	v_bfe_u32 v50, v37, 12, 16                                 // 0000009670D0: D6100032 02411925
	v_bfe_u32 v51, v37, 8, 16                                  // 0000009670D8: D6100033 02411125
	v_sad_u8 v41, v41, 0, 0x6400                               // 0000009670E0: D6220029 03FD0129 00006400
	v_sad_u8 v43, v43, 0, 0x6400                               // 0000009670EC: D622002B 03FD012B 00006400
	v_sad_u8 v46, v46, 0, 0x6400                               // 0000009670F8: D622002E 03FD012E 00006400
	.long 0xd72c0032                                           // 000000967104: D72C0032
	v_cndmask_b32_e32 v1, 0x83dcd12d, v50, vcc_lo              // 000000967108: 020264FF 83DCD12D
	.long 0xd72c0031                                           // 000000967110: D72C0031
	v_cndmask_b32_e32 v1, 0x83dcd12d, v49, vcc_lo              // 000000967114: 020262FF 83DCD12D
	.long 0xd72c0033                                           // 00000096711C: D72C0033
	v_cndmask_b32_e32 v1, 0x83dcd12d, v51, vcc_lo              // 000000967120: 020266FF 83DCD12D
	v_lshlrev_b32_e32 v43, 16, v43                             // 000000967128: 30565690
	v_sad_u8 v45, v45, 0, 0x6400                               // 00000096712C: D622002D 03FD012D 00006400
	v_and_b32_e32 v41, 0xffff, v41                             // 000000967138: 365252FF 0000FFFF
	.long 0xd72c0027                                           // 000000967140: D72C0027
	v_cndmask_b32_e32 v1, 0x83dcd12d, v42, vcc_lo              // 000000967144: 020254FF 83DCD12D
	v_bfe_u32 v42, v40, 8, 16                                  // 00000096714C: D610002A 02411128
	v_and_or_b32 v46, 0xffff, v46, v43                         // 000000967154: D657002E 04AE5CFF 0000FFFF
	v_sad_u8 v43, v50, 0, 0x6400                               // 000000967160: D622002B 03FD0132 00006400
	v_lshl_or_b32 v41, v45, 16, v41                            // 00000096716C: D6560029 04A5212D
	v_sad_u8 v45, v49, 0, 0x6400                               // 000000967174: D622002D 03FD0131 00006400
	v_sad_u8 v49, v51, 0, 0x6400                               // 000000967180: D6220031 03FD0133 00006400
	.long 0xd72c0026                                           // 00000096718C: D72C0026
	v_cndmask_b32_e32 v1, 0x83dcd12d, v38, vcc_lo              // 000000967190: 02024CFF 83DCD12D
	v_and_b32_e32 v43, 0xffff, v43                             // 000000967198: 365656FF 0000FFFF
	.long 0xd72c002a                                           // 0000009671A0: D72C002A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v42, vcc_lo              // 0000009671A4: 020254FF 83DCD12D
	v_bfe_u32 v52, v37, 4, 16                                  // 0000009671AC: D6100034 02410925
	.long 0xd72c002f                                           // 0000009671B4: D72C002F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v47, vcc_lo              // 0000009671B8: 02025EFF 83DCD12D
	v_sad_u8 v39, v39, 0, 0x6400                               // 0000009671C0: D6220027 03FD0127 00006400
	v_lshl_or_b32 v43, v49, 16, v43                            // 0000009671CC: D656002B 04AD2131
	.long 0xd72c002c                                           // 0000009671D4: D72C002C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v44, vcc_lo              // 0000009671D8: 020258FF 83DCD12D
	v_sad_u8 v38, v38, 0, 0x6400                               // 0000009671E0: D6220026 03FD0126 00006400
	.long 0xd72c0034                                           // 0000009671EC: D72C0034
	v_cndmask_b32_e32 v1, 0x83dcd12d, v52, vcc_lo              // 0000009671F0: 020268FF 83DCD12D
	v_sad_u8 v42, v42, 0, 0x6400                               // 0000009671F8: D622002A 03FD012A 00006400
	v_pk_fma_f16 v49, v43, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000967204: CC0E0031 0BFC0D2B 0000C931
	v_and_b32_e32 v40, 0xffff, v40                             // 000000967210: 365050FF 0000FFFF
	v_and_b32_e32 v38, 0xffff, v38                             // 000000967218: 364C4CFF 0000FFFF
	v_and_b32_e32 v39, 0xffff, v39                             // 000000967220: 364E4EFF 0000FFFF
	v_sad_u8 v47, v47, 0, 0x6400                               // 000000967228: D622002F 03FD012F 00006400
	s_waitcnt lgkmcnt(0)                                       // 000000967234: BF89FC07
	v_dot2acc_f32_f16 v25, v49, v1                             // 000000967238: 04320331
	.long 0xd72c0028                                           // 00000096723C: D72C0028
	v_cndmask_b32_e32 v1, 0x83dcd12d, v40, vcc_lo              // 000000967240: 020250FF 83DCD12D
	v_lshl_or_b32 v38, v42, 16, v38                            // 000000967248: D6560026 0499212A
	v_sad_u8 v52, v52, 0, 0x6400                               // 000000967250: D6220034 03FD0134 00006400
	v_lshl_or_b32 v47, v47, 16, v39                            // 00000096725C: D656002F 049D212F
	.long 0xd72c0030                                           // 000000967264: D72C0030
	v_cndmask_b32_e32 v1, 0x83dcd12d, v48, vcc_lo              // 000000967268: 020260FF 83DCD12D
	v_sad_u8 v44, v44, 0, 0x6400                               // 000000967270: D622002C 03FD012C 00006400
	v_pk_fma_f16 v50, v38, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000096727C: CC0E0032 0BFC0D26 0000C931
	v_sad_u8 v40, v40, 0, 0x6400                               // 000000967288: D6220028 03FD0128 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000967294: BF8701A2
	v_dot2acc_f32_f16 v10, v50, v1                             // 000000967298: 04140332
	v_sad_u8 v48, v48, 0, 0x6400                               // 00000096729C: D6220030 03FD0130 00006400
	v_lshlrev_b32_e32 v40, 16, v40                             // 0000009672A8: 30505090
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000009672AC: BF870121
	v_and_or_b32 v40, 0xffff, v45, v40                         // 0000009672B0: D6570028 04A25AFF 0000FFFF
	v_pk_fma_f16 v45, v41, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000009672BC: CC0E002D 0BFC0D29 0000C931
	v_pk_fma_f16 v51, v40, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000009672C8: CC0E0033 0BFC0D28 0000C931
	v_and_b32_e32 v37, 0xffff, v37                             // 0000009672D4: 364A4AFF 0000FFFF
	ds_load_2addr_b32 v[40:41], v33 offset0:128 offset1:160    // 0000009672DC: D8DCA080 28000021
	v_lshlrev_b32_e32 v44, 16, v44                             // 0000009672E4: 30585890
	v_dot2acc_f32_f16 v10, v51, v2                             // 0000009672E8: 04140533
	.long 0xd72c0025                                           // 0000009672EC: D72C0025
	v_cndmask_b32_e32 v1, 0x83dcd12d, v37, vcc_lo              // 0000009672F0: 02024AFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009672F8: BF870193
	v_and_or_b32 v44, 0xffff, v48, v44                         // 0000009672FC: D657002C 04B260FF 0000FFFF
	v_dot2acc_f32_f16 v10, v45, v3                             // 000000967308: 0414072D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000096730C: BF870212
	v_pk_fma_f16 v44, v44, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000967310: CC0E002C 0BFC0D2C 0000C931
	v_sad_u8 v42, v37, 0, 0x6400                               // 00000096731C: D622002A 03FD0125 00006400
	ds_load_2addr_b32 v[37:38], v34 offset0:128 offset1:160    // 000000967328: D8DCA080 25000022
	s_waitcnt lgkmcnt(0)                                       // 000000967330: BF89FC07
	v_mov_b32_e32 v39, v37                                     // 000000967334: 7E4E0325
	v_pk_fma_f16 v37, v47, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000967338: CC0E0025 0BFC0D2F 0000C931
	v_lshlrev_b32_e32 v42, 16, v42                             // 000000967344: 30545490
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000967348: BF8701A3
	.long 0xd73d0027                                           // 00000096734C: D73D0027
	v_cndmask_b32_e32 v1, v28, v39, vcc_lo                     // 000000967350: 02024F1C
	v_pk_fma_f16 v40, v46, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000967354: CC0E0028 0BFC0D2E 0000C931
	v_and_or_b32 v42, 0xffff, v52, v42                         // 000000967360: D657002A 04AA68FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000096736C: BF870112
	v_dot2acc_f32_f16 v10, v40, v4                             // 000000967370: 04140928
	v_pk_fma_f16 v50, v42, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000967374: CC0E0032 0BFC0D2A 0000C931
	ds_load_2addr_b32 v[42:43], v31 offset0:128 offset1:160    // 000000967380: D8DCA080 2A00001F
	v_bfe_u32 v45, v39, 8, 16                                  // 000000967388: D610002D 02411127
	v_dual_dot2acc_f32_f16 v25, v50, v2 :: v_dual_and_b32 v40, 0xffff, v39// 000000967390: CB240532 19284EFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000096739C: BF870112
	.long 0xd72c002d                                           // 0000009673A0: D72C002D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v45, vcc_lo              // 0000009673A4: 02025AFF 83DCD12D
	.long 0xd72c0028                                           // 0000009673AC: D72C0028
	v_cndmask_b32_e32 v1, 0x83dcd12d, v40, vcc_lo              // 0000009673B0: 020250FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000009673B8: BF8701B3
	v_dot2acc_f32_f16 v25, v37, v3                             // 0000009673BC: 04320725
	v_bfe_u32 v37, v39, 12, 16                                 // 0000009673C0: D6100025 02411927
	v_bfe_u32 v39, v39, 4, 16                                  // 0000009673C8: D6100027 02410927
	v_dot2acc_f32_f16 v25, v44, v4                             // 0000009673D0: 0432092C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009673D4: BF870193
	.long 0xd72c0025                                           // 0000009673D8: D72C0025
	v_cndmask_b32_e32 v1, 0x83dcd12d, v37, vcc_lo              // 0000009673DC: 02024AFF 83DCD12D
	.long 0xd72c0027                                           // 0000009673E4: D72C0027
	v_cndmask_b32_e32 v1, 0x83dcd12d, v39, vcc_lo              // 0000009673E8: 02024EFF 83DCD12D
	v_sad_u8 v40, v40, 0, 0x6400                               // 0000009673F0: D6220028 03FD0128 00006400
	v_sad_u8 v45, v45, 0, 0x6400                               // 0000009673FC: D622002D 03FD012D 00006400
	s_waitcnt lgkmcnt(0)                                       // 000000967408: BF89FC07
	v_bfe_u32 v44, v42, 12, 16                                 // 00000096740C: D610002C 0241192A
	v_bfe_u32 v46, v42, 8, 16                                  // 000000967414: D610002E 0241112A
	v_lshlrev_b32_e32 v40, 16, v40                             // 00000096741C: 30505090
	v_bfe_u32 v47, v42, 4, 16                                  // 000000967420: D610002F 0241092A
	v_sad_u8 v48, v39, 0, 0x6400                               // 000000967428: D6220030 03FD0127 00006400
	.long 0xd72c002c                                           // 000000967434: D72C002C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v44, vcc_lo              // 000000967438: 020258FF 83DCD12D
	v_and_b32_e32 v42, 0xffff, v42                             // 000000967440: 365454FF 0000FFFF
	v_sad_u8 v37, v37, 0, 0x6400                               // 000000967448: D6220025 03FD0125 00006400
	.long 0xd72c002e                                           // 000000967454: D72C002E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v46, vcc_lo              // 000000967458: 02025CFF 83DCD12D
	v_and_or_b32 v40, 0xffff, v48, v40                         // 000000967460: D6570028 04A260FF 0000FFFF
	v_mov_b32_e32 v39, v41                                     // 00000096746C: 7E4E0329
	.long 0xd72c002a                                           // 000000967470: D72C002A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v42, vcc_lo              // 000000967474: 020254FF 83DCD12D
	.long 0xd72c002f                                           // 00000096747C: D72C002F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v47, vcc_lo              // 000000967480: 02025EFF 83DCD12D
	v_sad_u8 v44, v44, 0, 0x6400                               // 000000967488: D622002C 03FD012C 00006400
	v_pk_fma_f16 v40, v40, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000967494: CC0E0028 0BFC0D28 0000C931
	v_and_b32_e32 v37, 0xffff, v37                             // 0000009674A0: 364A4AFF 0000FFFF
	v_sad_u8 v41, v46, 0, 0x6400                               // 0000009674A8: D6220029 03FD012E 00006400
	v_bfe_u32 v48, v43, 8, 16                                  // 0000009674B4: D6100030 0241112B
	v_and_b32_e32 v44, 0xffff, v44                             // 0000009674BC: 365858FF 0000FFFF
	v_sad_u8 v42, v42, 0, 0x6400                               // 0000009674C4: D622002A 03FD012A 00006400
	v_lshl_or_b32 v45, v45, 16, v37                            // 0000009674D0: D656002D 0495212D
	.long 0xd73d0025                                           // 0000009674D8: D73D0025
	v_cndmask_b32_e32 v1, v28, v38, vcc_lo                     // 0000009674DC: 02024D1C
	v_sad_u8 v39, v47, 0, 0x6400                               // 0000009674E0: D6220027 03FD012F 00006400
	v_lshl_or_b32 v38, v41, 16, v44                            // 0000009674EC: D6560026 04B12129
	v_lshlrev_b32_e32 v41, 16, v42                             // 0000009674F4: 30525490
	v_pk_fma_f16 v42, v45, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000009674F8: CC0E002A 0BFC0D2D 0000C931
	v_bfe_u32 v47, v43, 12, 16                                 // 000000967504: D610002F 0241192B
	v_bfe_u32 v44, v37, 12, 16                                 // 00000096750C: D610002C 02411925
	v_pk_fma_f16 v45, v38, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000967514: CC0E002D 0BFC0D26 0000C931
	v_bfe_u32 v50, v43, 4, 16                                  // 000000967520: D6100032 0241092B
	v_dot2acc_f32_f16 v24, v42, v1                             // 000000967528: 0430032A
	v_and_b32_e32 v42, 0xffff, v37                             // 00000096752C: 36544AFF 0000FFFF
	.long 0xd72c002f                                           // 000000967534: D72C002F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v47, vcc_lo              // 000000967538: 02025EFF 83DCD12D
	.long 0xd72c0030                                           // 000000967540: D72C0030
	v_cndmask_b32_e32 v1, 0x83dcd12d, v48, vcc_lo              // 000000967544: 020260FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000096754C: BF8701B4
	v_dot2acc_f32_f16 v24, v40, v2                             // 000000967550: 04300528
	v_bfe_u32 v40, v37, 4, 16                                  // 000000967554: D6100028 02410925
	.long 0xd72c002a                                           // 00000096755C: D72C002A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v42, vcc_lo              // 000000967560: 020254FF 83DCD12D
	v_dot2acc_f32_f16 v24, v45, v3                             // 000000967568: 0430072D
	v_and_or_b32 v38, 0xffff, v39, v41                         // 00000096756C: D6570026 04A64EFF 0000FFFF
	v_bfe_u32 v39, v37, 8, 16                                  // 000000967578: D6100027 02411125
	.long 0xd72c0029                                           // 000000967580: D72C0029
	v_cndmask_b32_e32 v1, 0x83dcd12d, v44, vcc_lo              // 000000967584: 020258FF 83DCD12D
	.long 0xd72c0031                                           // 00000096758C: D72C0031
	v_cndmask_b32_e32 v1, 0x83dcd12d, v40, vcc_lo              // 000000967590: 020250FF 83DCD12D
	v_sad_u8 v42, v42, 0, 0x6400                               // 000000967598: D622002A 03FD012A 00006400
	v_pk_fma_f16 v44, v38, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000009675A4: CC0E002C 0BFC0D26 0000C931
	ds_load_2addr_b32 v[37:38], v34 offset0:192 offset1:224    // 0000009675B0: D8DCE0C0 25000022
	.long 0xd72c0027                                           // 0000009675B8: D72C0027
	v_cndmask_b32_e32 v1, 0x83dcd12d, v39, vcc_lo              // 0000009675BC: 02024EFF 83DCD12D
	v_and_b32_e32 v43, 0xffff, v43                             // 0000009675C4: 365656FF 0000FFFF
	v_lshlrev_b32_e32 v42, 16, v42                             // 0000009675CC: 30545490
	v_sad_u8 v46, v41, 0, 0x6400                               // 0000009675D0: D622002E 03FD0129 00006400
	ds_load_2addr_b32 v[40:41], v33 offset0:192 offset1:224    // 0000009675DC: D8DCE0C0 28000021
	v_dot2acc_f32_f16 v24, v44, v4                             // 0000009675E4: 0430092C
	.long 0xd72c002b                                           // 0000009675E8: D72C002B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v43, vcc_lo              // 0000009675EC: 020256FF 83DCD12D
	v_sad_u8 v47, v47, 0, 0x6400                               // 0000009675F4: D622002F 03FD012F 00006400
	v_and_b32_e32 v46, 0xffff, v46                             // 000000967600: 365C5CFF 0000FFFF
	v_sad_u8 v39, v39, 0, 0x6400                               // 000000967608: D6220027 03FD0127 00006400
	v_sad_u8 v48, v48, 0, 0x6400                               // 000000967614: D6220030 03FD0130 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000967620: BF870194
	v_and_b32_e32 v47, 0xffff, v47                             // 000000967624: 365E5EFF 0000FFFF
	v_lshl_or_b32 v39, v39, 16, v46                            // 00000096762C: D6560027 04B92127
	v_sad_u8 v46, v49, 0, 0x6400                               // 000000967634: D622002E 03FD0131 00006400
	s_delay_alu instid0(VALU_DEP_2)                            // 000000967640: BF870002
	v_pk_fma_f16 v49, v39, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000967644: CC0E0031 0BFC0D27 0000C931
	s_waitcnt lgkmcnt(1)                                       // 000000967650: BF89FC17
	v_mov_b32_e32 v39, v37                                     // 000000967654: 7E4E0325
	.long 0xd72c0025                                           // 000000967658: D72C0025
	v_cndmask_b32_e32 v1, 0x83dcd12d, v50, vcc_lo              // 00000096765C: 020264FF 83DCD12D
	v_and_or_b32 v46, 0xffff, v46, v42                         // 000000967664: D657002E 04AA5CFF 0000FFFF
	v_sad_u8 v50, v43, 0, 0x6400                               // 000000967670: D6220032 03FD012B 00006400
	ds_load_2addr_b32 v[42:43], v31 offset0:192 offset1:224    // 00000096767C: D8DCE0C0 2A00001F
	s_waitcnt lgkmcnt(1)                                       // 000000967684: BF89FC17
	.long 0xd73d0027                                           // 000000967688: D73D0027
	v_cndmask_b32_e32 v1, v28, v39, vcc_lo                     // 00000096768C: 02024F1C
	v_dot2acc_f32_f16 v23, v49, v1                             // 000000967690: 042E0331
	v_pk_fma_f16 v40, v46, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000967694: CC0E0028 0BFC0D2E 0000C931
	v_lshl_or_b32 v46, v48, 16, v47                            // 0000009676A0: D656002E 04BD2130
	v_sad_u8 v37, v37, 0, 0x6400                               // 0000009676A8: D6220025 03FD0125 00006400
	v_lshlrev_b32_e32 v47, 16, v50                             // 0000009676B4: 305E6490
	v_bfe_u32 v48, v39, 12, 16                                 // 0000009676B8: D6100030 02411927
	v_dot2acc_f32_f16 v23, v40, v2                             // 0000009676C0: 042E0528
	v_pk_fma_f16 v45, v46, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000009676C4: CC0E002D 0BFC0D2E 0000C931
	v_bfe_u32 v46, v39, 8, 16                                  // 0000009676D0: D610002E 02411127
	v_and_or_b32 v37, 0xffff, v37, v47                         // 0000009676D8: D6570025 04BE4AFF 0000FFFF
	.long 0xd72c0028                                           // 0000009676E4: D72C0028
	v_cndmask_b32_e32 v1, 0x83dcd12d, v48, vcc_lo              // 0000009676E8: 020260FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009676F0: BF870214
	v_dot2acc_f32_f16 v23, v45, v3                             // 0000009676F4: 042E072D
	.long 0xd72c002d                                           // 0000009676F8: D72C002D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v46, vcc_lo              // 0000009676FC: 02025CFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4)                            // 000000967704: BF870004
	v_pk_fma_f16 v44, v37, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000967708: CC0E002C 0BFC0D25 0000C931
	v_bfe_u32 v37, v39, 4, 16                                  // 000000967714: D6100025 02410927
	v_and_b32_e32 v39, 0xffff, v39                             // 00000096771C: 364E4EFF 0000FFFF
	s_waitcnt lgkmcnt(0)                                       // 000000967724: BF89FC07
	v_bfe_u32 v46, v42, 12, 16                                 // 000000967728: D610002E 0241192A
	v_and_b32_e32 v48, 0xffff, v42                             // 000000967730: 366054FF 0000FFFF
	v_sad_u8 v40, v40, 0, 0x6400                               // 000000967738: D6220028 03FD0128 00006400
	.long 0xd72c0027                                           // 000000967744: D72C0027
	v_cndmask_b32_e32 v1, 0x83dcd12d, v39, vcc_lo              // 000000967748: 02024EFF 83DCD12D
	.long 0xd72c0025                                           // 000000967750: D72C0025
	v_cndmask_b32_e32 v1, 0x83dcd12d, v37, vcc_lo              // 000000967754: 02024AFF 83DCD12D
	.long 0xd72c002e                                           // 00000096775C: D72C002E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v46, vcc_lo              // 000000967760: 02025CFF 83DCD12D
	.long 0xd72c0030                                           // 000000967768: D72C0030
	v_cndmask_b32_e32 v1, 0x83dcd12d, v48, vcc_lo              // 00000096776C: 020260FF 83DCD12D
	v_bfe_u32 v47, v42, 8, 16                                  // 000000967774: D610002F 0241112A
	v_and_b32_e32 v40, 0xffff, v40                             // 00000096777C: 365050FF 0000FFFF
	v_sad_u8 v45, v45, 0, 0x6400                               // 000000967784: D622002D 03FD012D 00006400
	v_bfe_u32 v42, v42, 4, 16                                  // 000000967790: D610002A 0241092A
	v_sad_u8 v39, v39, 0, 0x6400                               // 000000967798: D6220027 03FD0127 00006400
	v_dot2acc_f32_f16 v23, v44, v4                             // 0000009677A4: 042E092C
	v_sad_u8 v46, v46, 0, 0x6400                               // 0000009677A8: D622002E 03FD012E 00006400
	v_lshl_or_b32 v40, v45, 16, v40                            // 0000009677B4: D6560028 04A1212D
	.long 0xd72c002d                                           // 0000009677BC: D72C002D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v47, vcc_lo              // 0000009677C0: 02025EFF 83DCD12D
	.long 0xd72c002a                                           // 0000009677C8: D72C002A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v42, vcc_lo              // 0000009677CC: 020254FF 83DCD12D
	v_sad_u8 v47, v37, 0, 0x6400                               // 0000009677D4: D622002F 03FD0125 00006400
	v_lshlrev_b32_e32 v49, 16, v39                             // 0000009677E0: 30624E90
	v_sad_u8 v37, v48, 0, 0x6400                               // 0000009677E4: D6220025 03FD0130 00006400
	v_mov_b32_e32 v39, v41                                     // 0000009677F0: 7E4E0329
	v_and_b32_e32 v41, 0xffff, v46                             // 0000009677F4: 36525CFF 0000FFFF
	v_sad_u8 v45, v45, 0, 0x6400                               // 0000009677FC: D622002D 03FD012D 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000967808: BF870214
	v_lshlrev_b32_e32 v46, 16, v37                             // 00000096780C: 305C4A90
	.long 0xd73d0025                                           // 000000967810: D73D0025
	v_cndmask_b32_e32 v1, v28, v38, vcc_lo                     // 000000967814: 02024D1C
	v_sad_u8 v42, v42, 0, 0x6400                               // 000000967818: D622002A 03FD012A 00006400
	v_pk_fma_f16 v39, v40, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000967824: CC0E0027 0BFC0D28 0000C931
	v_lshl_or_b32 v40, v45, 16, v41                            // 000000967830: D6560028 04A5212D
	v_and_or_b32 v38, 0xffff, v47, v49                         // 000000967838: D6570026 04C65EFF 0000FFFF
	v_bfe_u32 v47, v43, 4, 16                                  // 000000967844: D610002F 0241092B
	v_and_or_b32 v41, 0xffff, v42, v46                         // 00000096784C: D6570029 04BA54FF 0000FFFF
	v_bfe_u32 v42, v37, 12, 16                                 // 000000967858: D610002A 02411925
	v_dot2acc_f32_f16 v22, v39, v1                             // 000000967860: 042C0327
	v_pk_fma_f16 v44, v40, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000967864: CC0E002C 0BFC0D28 0000C931
	v_bfe_u32 v40, v37, 8, 16                                  // 000000967870: D6100028 02411125
	v_pk_fma_f16 v38, v38, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000967878: CC0E0026 0BFC0D26 0000C931
	.long 0xd72c0027                                           // 000000967884: D72C0027
	v_cndmask_b32_e32 v1, 0x83dcd12d, v42, vcc_lo              // 000000967888: 020254FF 83DCD12D
	v_pk_fma_f16 v45, v41, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000967890: CC0E002D 0BFC0D29 0000C931
	v_bfe_u32 v41, v37, 4, 16                                  // 00000096789C: D6100029 02410925
	v_and_b32_e32 v37, 0xffff, v37                             // 0000009678A4: 364A4AFF 0000FFFF
	.long 0xd72c0028                                           // 0000009678AC: D72C0028
	v_cndmask_b32_e32 v1, 0x83dcd12d, v40, vcc_lo              // 0000009678B0: 020250FF 83DCD12D
	v_dot2acc_f32_f16 v22, v38, v2                             // 0000009678B8: 042C0526
	v_bfe_u32 v42, v43, 12, 16                                 // 0000009678BC: D610002A 0241192B
	v_bfe_u32 v46, v43, 8, 16                                  // 0000009678C4: D610002E 0241112B
	v_sad_u8 v39, v39, 0, 0x6400                               // 0000009678CC: D6220027 03FD0127 00006400
	.long 0xd72c0030                                           // 0000009678D8: D72C0030
	v_cndmask_b32_e32 v1, 0x83dcd12d, v37, vcc_lo              // 0000009678DC: 02024AFF 83DCD12D
	ds_load_2addr_b32 v[37:38], v36 offset1:32                 // 0000009678E4: D8DC2000 25000024
	v_and_b32_e32 v43, 0xffff, v43                             // 0000009678EC: 365656FF 0000FFFF
	v_sad_u8 v49, v40, 0, 0x6400                               // 0000009678F4: D6220031 03FD0128 00006400
	.long 0xd72c0032                                           // 000000967900: D72C0032
	v_cndmask_b32_e32 v1, 0x83dcd12d, v41, vcc_lo              // 000000967904: 020252FF 83DCD12D
	ds_load_2addr_b32 v[40:41], v35 offset1:32                 // 00000096790C: D8DC2000 28000023
	v_dot2acc_f32_f16 v22, v44, v3                             // 000000967914: 042C072C
	v_and_b32_e32 v39, 0xffff, v39                             // 000000967918: 364E4EFF 0000FFFF
	.long 0xd72c002b                                           // 000000967920: D72C002B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v43, vcc_lo              // 000000967924: 020256FF 83DCD12D
	.long 0xd72c002a                                           // 00000096792C: D72C002A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v42, vcc_lo              // 000000967930: 020254FF 83DCD12D
	.long 0xd72c002e                                           // 000000967938: D72C002E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v46, vcc_lo              // 00000096793C: 02025CFF 83DCD12D
	v_dot2acc_f32_f16 v22, v45, v4                             // 000000967944: 042C092D
	v_lshl_or_b32 v49, v49, 16, v39                            // 000000967948: D6560031 049D2131
	v_sad_u8 v39, v48, 0, 0x6400                               // 000000967950: D6220027 03FD0130 00006400
	v_sad_u8 v50, v50, 0, 0x6400                               // 00000096795C: D6220032 03FD0132 00006400
	.long 0xd72c002f                                           // 000000967968: D72C002F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v47, vcc_lo              // 00000096796C: 02025EFF 83DCD12D
	v_sad_u8 v48, v42, 0, 0x6400                               // 000000967974: D6220030 03FD012A 00006400
	s_delay_alu instid0(VALU_DEP_4)                            // 000000967980: BF870004
	v_lshlrev_b32_e32 v51, 16, v39                             // 000000967984: 30664E90
	v_sad_u8 v39, v43, 0, 0x6400                               // 000000967988: D6220027 03FD012B 00006400
	v_sad_u8 v46, v46, 0, 0x6400                               // 000000967994: D622002E 03FD012E 00006400
	v_pk_fma_f16 v49, v49, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000009679A0: CC0E0031 0BFC0D31 0000C931
	v_and_b32_e32 v48, 0xffff, v48                             // 0000009679AC: 366060FF 0000FFFF
	ds_load_2addr_b32 v[42:43], v32 offset1:32                 // 0000009679B4: D8DC2000 2A000020
	s_waitcnt lgkmcnt(2)                                       // 0000009679BC: BF89FC27
	v_dual_mov_b32 v39, v37 :: v_dual_lshlrev_b32 v52, 16, v39 // 0000009679C0: CA220125 27344E90
	v_and_or_b32 v37, 0xffff, v50, v51                         // 0000009679C8: D6570025 04CE64FF 0000FFFF
	v_sad_u8 v47, v47, 0, 0x6400                               // 0000009679D4: D622002F 03FD012F 00006400
	v_lshl_or_b32 v46, v46, 16, v48                            // 0000009679E0: D656002E 04C1212E
	v_dot2acc_f32_f16 v21, v49, v1                             // 0000009679E8: 042A0331
	s_waitcnt lgkmcnt(1)                                       // 0000009679EC: BF89FC17
	.long 0xd73d0027                                           // 0000009679F0: D73D0027
	v_cndmask_b32_e32 v1, v28, v39, vcc_lo                     // 0000009679F4: 02024F1C
	v_pk_fma_f16 v37, v37, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000009679F8: CC0E0025 0BFC0D25 0000C931
	v_and_or_b32 v47, 0xffff, v47, v52                         // 000000967A04: D657002F 04D25EFF 0000FFFF
	v_pk_fma_f16 v40, v46, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000967A10: CC0E0028 0BFC0D2E 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000967A1C: BF870214
	v_bfe_u32 v46, v39, 12, 16                                 // 000000967A20: D610002E 02411927
	v_dot2acc_f32_f16 v21, v37, v2                             // 000000967A28: 042A0525
	v_and_b32_e32 v37, 0xffff, v39                             // 000000967A2C: 364A4EFF 0000FFFF
	v_pk_fma_f16 v44, v47, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000967A34: CC0E002C 0BFC0D2F 0000C931
	v_bfe_u32 v47, v39, 8, 16                                  // 000000967A40: D610002F 02411127
	.long 0xd72c002e                                           // 000000967A48: D72C002E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v46, vcc_lo              // 000000967A4C: 02025CFF 83DCD12D
	v_bfe_u32 v39, v39, 4, 16                                  // 000000967A54: D6100027 02410927
	.long 0xd72c0025                                           // 000000967A5C: D72C0025
	v_cndmask_b32_e32 v1, 0x83dcd12d, v37, vcc_lo              // 000000967A60: 02024AFF 83DCD12D
	s_waitcnt lgkmcnt(0)                                       // 000000967A68: BF89FC07
	v_bfe_u32 v48, v42, 12, 16                                 // 000000967A6C: D6100030 0241192A
	.long 0xd72c002f                                           // 000000967A74: D72C002F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v47, vcc_lo              // 000000967A78: 02025EFF 83DCD12D
	v_bfe_u32 v49, v42, 8, 16                                  // 000000967A80: D6100031 0241112A
	.long 0xd72c0027                                           // 000000967A88: D72C0027
	v_cndmask_b32_e32 v1, 0x83dcd12d, v39, vcc_lo              // 000000967A8C: 02024EFF 83DCD12D
	v_bfe_u32 v50, v42, 4, 16                                  // 000000967A94: D6100032 0241092A
	v_sad_u8 v46, v46, 0, 0x6400                               // 000000967A9C: D622002E 03FD012E 00006400
	.long 0xd72c0030                                           // 000000967AA8: D72C0030
	v_cndmask_b32_e32 v1, 0x83dcd12d, v48, vcc_lo              // 000000967AAC: 020260FF 83DCD12D
	v_sad_u8 v37, v37, 0, 0x6400                               // 000000967AB4: D6220025 03FD0125 00006400
	.long 0xd72c0031                                           // 000000967AC0: D72C0031
	v_cndmask_b32_e32 v1, 0x83dcd12d, v49, vcc_lo              // 000000967AC4: 020262FF 83DCD12D
	v_sad_u8 v47, v47, 0, 0x6400                               // 000000967ACC: D622002F 03FD012F 00006400
	v_and_b32_e32 v46, 0xffff, v46                             // 000000967AD8: 365C5CFF 0000FFFF
	v_sad_u8 v51, v39, 0, 0x6400                               // 000000967AE0: D6220033 03FD0127 00006400
	v_lshlrev_b32_e32 v37, 16, v37                             // 000000967AEC: 304A4A90
	v_dual_mov_b32 v39, v41 :: v_dual_and_b32 v42, 0xffff, v42 // 000000967AF0: CA240129 272A54FF 0000FFFF
	v_dot2acc_f32_f16 v21, v40, v3                             // 000000967AFC: 042A0728
	v_lshl_or_b32 v46, v47, 16, v46                            // 000000967B00: D656002E 04B9212F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000967B08: BF870214
	v_and_or_b32 v47, 0xffff, v51, v37                         // 000000967B0C: D657002F 049666FF 0000FFFF
	.long 0xd73d0025                                           // 000000967B18: D73D0025
	v_cndmask_b32_e32 v1, v28, v38, vcc_lo                     // 000000967B1C: 02024D1C
	v_sad_u8 v48, v48, 0, 0x6400                               // 000000967B20: D6220030 03FD0130 00006400
	v_sad_u8 v41, v49, 0, 0x6400                               // 000000967B2C: D6220029 03FD0131 00006400
	.long 0xd72c0031                                           // 000000967B38: D72C0031
	v_cndmask_b32_e32 v1, 0x83dcd12d, v50, vcc_lo              // 000000967B3C: 020264FF 83DCD12D
	.long 0xd72c0027                                           // 000000967B44: D72C0027
	v_cndmask_b32_e32 v1, 0x83dcd12d, v42, vcc_lo              // 000000967B48: 020254FF 83DCD12D
	v_pk_fma_f16 v40, v46, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000967B50: CC0E0028 0BFC0D2E 0000C931
	v_and_b32_e32 v48, 0xffff, v48                             // 000000967B5C: 366060FF 0000FFFF
	v_bfe_u32 v42, v37, 12, 16                                 // 000000967B64: D610002A 02411925
	v_bfe_u32 v50, v43, 8, 16                                  // 000000967B6C: D6100032 0241112B
	v_bfe_u32 v51, v43, 4, 16                                  // 000000967B74: D6100033 0241092B
	v_dot2acc_f32_f16 v18, v40, v1                             // 000000967B7C: 04240328
	v_lshl_or_b32 v38, v41, 16, v48                            // 000000967B80: D6560026 04C12129
	v_sad_u8 v46, v49, 0, 0x6400                               // 000000967B88: D622002E 03FD0131 00006400
	.long 0xd72c002a                                           // 000000967B94: D72C002A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v42, vcc_lo              // 000000967B98: 020254FF 83DCD12D
	v_bfe_u32 v48, v37, 8, 16                                  // 000000967BA0: D6100030 02411125
	v_bfe_u32 v49, v43, 12, 16                                 // 000000967BA8: D6100031 0241192B
	v_and_b32_e32 v43, 0xffff, v43                             // 000000967BB0: 365656FF 0000FFFF
	.long 0xd72c0032                                           // 000000967BB8: D72C0032
	v_cndmask_b32_e32 v1, 0x83dcd12d, v50, vcc_lo              // 000000967BBC: 020264FF 83DCD12D
	v_sad_u8 v39, v39, 0, 0x6400                               // 000000967BC4: D6220027 03FD0127 00006400
	.long 0xd72c0030                                           // 000000967BD0: D72C0030
	v_cndmask_b32_e32 v1, 0x83dcd12d, v48, vcc_lo              // 000000967BD4: 020260FF 83DCD12D
	.long 0xd72c0031                                           // 000000967BDC: D72C0031
	v_cndmask_b32_e32 v1, 0x83dcd12d, v49, vcc_lo              // 000000967BE0: 020262FF 83DCD12D
	v_sad_u8 v42, v42, 0, 0x6400                               // 000000967BE8: D622002A 03FD012A 00006400
	.long 0xd72c002b                                           // 000000967BF4: D72C002B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v43, vcc_lo              // 000000967BF8: 020256FF 83DCD12D
	v_lshlrev_b32_e32 v39, 16, v39                             // 000000967C00: 304E4E90
	v_pk_fma_f16 v41, v47, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000967C04: CC0E0029 0BFC0D2F 0000C931
	v_pk_fma_f16 v38, v38, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000967C10: CC0E0026 0BFC0D26 0000C931
	v_and_b32_e32 v42, 0xffff, v42                             // 000000967C1C: 365454FF 0000FFFF
	v_sad_u8 v48, v48, 0, 0x6400                               // 000000967C24: D6220030 03FD0130 00006400
	v_sad_u8 v49, v49, 0, 0x6400                               // 000000967C30: D6220031 03FD0131 00006400
	v_dot2acc_f32_f16 v18, v41, v2                             // 000000967C3C: 04240529
	v_sad_u8 v40, v43, 0, 0x6400                               // 000000967C40: D6220028 03FD012B 00006400
	v_dot2acc_f32_f16 v21, v44, v4                             // 000000967C4C: 042A092C
	v_lshl_or_b32 v42, v48, 16, v42                            // 000000967C50: D656002A 04A92130
	v_and_b32_e32 v48, 0xffff, v49                             // 000000967C58: 366062FF 0000FFFF
	v_sad_u8 v49, v50, 0, 0x6400                               // 000000967C60: D6220031 03FD0132 00006400
	v_lshlrev_b32_e32 v40, 16, v40                             // 000000967C6C: 30505090
	v_dot2acc_f32_f16 v18, v38, v3                             // 000000967C70: 04240726
	v_pk_fma_f16 v42, v42, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000967C74: CC0E002A 0BFC0D2A 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000967C80: BF870114
	v_lshl_or_b32 v43, v49, 16, v48                            // 000000967C84: D656002B 04C12131
	v_dot2acc_f32_f16 v26, v42, v1                             // 000000967C8C: 0434032A
	v_and_or_b32 v1, 0xffff, v46, v39                          // 000000967C90: D6570001 049E5CFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000967C9C: BF870233
	v_pk_fma_f16 v39, v43, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000967CA0: CC0E0027 0BFC0D2B 0000C931
	v_and_b32_e32 v47, 0xffff, v37                             // 000000967CAC: 365E4AFF 0000FFFF
	v_bfe_u32 v37, v37, 4, 16                                  // 000000967CB4: D6100025 02410925
	v_pk_fma_f16 v1, v1, s6, 0xc931 op_sel_hi:[1,0,0]          // 000000967CBC: CC0E0001 0BFC0D01 0000C931
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000967CC8: BF870193
	.long 0xd72c002f                                           // 000000967CCC: D72C002F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v47, vcc_lo              // 000000967CD0: 02025EFF 83DCD12D
	.long 0xd72c0025                                           // 000000967CD8: D72C0025
	v_cndmask_b32_e32 v1, 0x83dcd12d, v37, vcc_lo              // 000000967CDC: 02024AFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000967CE4: BF870193
	v_dot2acc_f32_f16 v18, v1, v4                              // 000000967CE8: 04240901
	v_sad_u8 v47, v47, 0, 0x6400                               // 000000967CEC: D622002F 03FD012F 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000967CF8: BF870113
	v_sad_u8 v37, v37, 0, 0x6400                               // 000000967CFC: D6220025 03FD0125 00006400
	v_lshlrev_b32_e32 v47, 16, v47                             // 000000967D08: 305E5E90
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000967D0C: BF870121
	v_and_or_b32 v37, 0xffff, v37, v47                         // 000000967D10: D6570025 04BE4AFF 0000FFFF
	.long 0xd72c002f                                           // 000000967D1C: D72C002F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v51, vcc_lo              // 000000967D20: 020266FF 83DCD12D
	v_pk_fma_f16 v37, v37, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000967D28: CC0E0025 0BFC0D25 0000C931
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000967D34: BF870112
	v_sad_u8 v47, v47, 0, 0x6400                               // 000000967D38: D622002F 03FD012F 00006400
	v_dot2acc_f32_f16 v26, v37, v2                             // 000000967D44: 04340525
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000967D48: BF870112
	v_and_or_b32 v40, 0xffff, v47, v40                         // 000000967D4C: D6570028 04A25EFF 0000FFFF
	v_dual_dot2acc_f32_f16 v26, v39, v3 :: v_dual_add_nc_u32 v3, v29, v30// 000000967D58: CB200727 1A023D1D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000967D60: BF870112
	v_pk_fma_f16 v2, v40, s6, 0xc931 op_sel_hi:[1,0,0]         // 000000967D64: CC0E0002 0BFC0D28 0000C931
	v_cmp_eq_u32_e32 vcc_lo, 6, v3                             // 000000967D70: 7C940686
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000967D74: BF8704A2
	v_dot2acc_f32_f16 v26, v2, v4                              // 000000967D78: 04340902
	s_or_b32 s2, vcc_lo, s2                                    // 000000967D7C: 8C02026A
	s_and_not1_b32 exec_lo, exec_lo, s2                        // 000000967D80: 917E027E
	s_cbranch_execz 34                                         // 000000967D84: BFA50022 <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_dn_tsILi4ELi8ELi4ELb0EEEvPKjPKDF16_PKiS5_PtNS0_4HtSdEiNS0_6HtFoldE+0x3b10>
	s_mov_b32 s0, exec_lo                                      // 000000967D88: BE80007E
	s_waitcnt vmcnt(6)                                         // 000000967D8C: BF891BF7
	ds_store_2addr_b32 v31, v8, v11 offset0:64 offset1:96      // 000000967D90: D8386040 000B081F
	s_waitcnt vmcnt(4)                                         // 000000967D98: BF8913F7
	ds_store_2addr_b32 v31, v12, v13 offset0:128 offset1:160   // 000000967D9C: D838A080 000D0C1F
	s_waitcnt vmcnt(2)                                         // 000000967DA4: BF890BF7
	ds_store_2addr_b32 v31, v14, v15 offset0:192 offset1:224   // 000000967DA8: D838E0C0 000F0E1F
	s_waitcnt vmcnt(0)                                         // 000000967DB0: BF8903F7
	ds_store_2addr_b32 v32, v16, v17 offset1:32                // 000000967DB4: D8382000 00111020
	.long 0xd4c9007e                                           // 000000967DBC: D4C9007E
	v_cndmask_b32_e32 v1, v30, v9, vcc_lo                      // 000000967DC0: 0202131E
	s_cbranch_execz 64649                                      // 000000967DC4: BFA5FC89 <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_dn_tsILi4ELi8ELi4ELb0EEEvPKjPKDF16_PKiS5_PtNS0_4HtSdEiNS0_6HtFoldE+0x2cec>
	s_clause 0x7                                               // 000000967DC8: BF850007
	global_load_b32 v8, v[5:6], off                            // 000000967DCC: DC520000 087C0005
	global_load_b32 v11, v[5:6], off offset:128                // 000000967DD4: DC520080 0B7C0005
	global_load_b32 v12, v[5:6], off offset:256                // 000000967DDC: DC520100 0C7C0005
	global_load_b32 v13, v[5:6], off offset:384                // 000000967DE4: DC520180 0D7C0005
	global_load_b32 v14, v[5:6], off offset:512                // 000000967DEC: DC520200 0E7C0005
	global_load_b32 v15, v[5:6], off offset:640                // 000000967DF4: DC520280 0F7C0005
	global_load_b32 v16, v[5:6], off offset:768                // 000000967DFC: DC520300 107C0005
	global_load_b32 v17, v[5:6], off offset:896                // 000000967E04: DC520380 117C0005
	s_branch 64631                                             // 000000967E0C: BFA0FC77 <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_dn_tsILi4ELi8ELi4ELb0EEEvPKjPKDF16_PKiS5_PtNS0_4HtSdEiNS0_6HtFoldE+0x2cec>
	s_or_b32 exec_lo, exec_lo, s2                              // 000000967E10: 8C7E027E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000967E14: BF870099
	s_or_b32 exec_lo, exec_lo, s1                              // 000000967E18: 8C7E017E
	v_dual_mov_b32 v1, v10 :: v_dual_mov_b32 v2, v25           // 000000967E1C: CA10010A 01020119
	v_dual_mov_b32 v3, v24 :: v_dual_mov_b32 v4, v23           // 000000967E24: CA100118 03040117
	v_dual_mov_b32 v5, v22 :: v_dual_mov_b32 v6, v21           // 000000967E2C: CA100116 05060115
	s_waitcnt vmcnt(7)                                         // 000000967E34: BF891FF7
	v_mov_b32_e32 v8, v18                                      // 000000967E38: 7E100312
	v_mov_b32_e32 v9, v26                                      // 000000967E3C: 7E12031A
	s_mov_b32 s0, 0x76543210                                   // 000000967E40: BE8000FF 76543210
	v_cmp_gt_u32_e32 vcc_lo, 16, v20                           // 000000967E48: 7C982890
	v_permlanex16_b32 v1, v1, s0, 0xfedcba98                   // 000000967E4C: D65C0001 03FC0101 FEDCBA98
	v_permlanex16_b32 v2, v2, s0, 0xfedcba98                   // 000000967E58: D65C0002 03FC0102 FEDCBA98
	v_permlanex16_b32 v3, v3, s0, 0xfedcba98                   // 000000967E64: D65C0003 03FC0103 FEDCBA98
	v_permlanex16_b32 v4, v4, s0, 0xfedcba98                   // 000000967E70: D65C0004 03FC0104 FEDCBA98
	v_permlanex16_b32 v5, v5, s0, 0xfedcba98                   // 000000967E7C: D65C0005 03FC0105 FEDCBA98
	v_permlanex16_b32 v6, v6, s0, 0xfedcba98                   // 000000967E88: D65C0006 03FC0106 FEDCBA98
	v_permlanex16_b32 v8, v8, s0, 0xfedcba98                   // 000000967E94: D65C0008 03FC0108 FEDCBA98
	v_permlanex16_b32 v9, v9, s0, 0xfedcba98                   // 000000967EA0: D65C0009 03FC0109 FEDCBA98
	s_waitcnt vmcnt(0)                                         // 000000967EAC: BF8903F7
	s_barrier                                                  // 000000967EB0: BFBD0000
	buffer_gl0_inv                                             // 000000967EB4: E0AC0000 00000000
	s_and_saveexec_b32 s0, vcc_lo                              // 000000967EBC: BE80206A
	s_cbranch_execz 21                                         // 000000967EC0: BFA50015 <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_dn_tsILi4ELi8ELi4ELb0EEEvPKjPKDF16_PKiS5_PtNS0_4HtSdEiNS0_6HtFoldE+0x3c18>
	v_lshl_or_b32 v7, v19, 9, v7                               // 000000967EC4: D6560007 041D1313
	v_dual_add_f32 v9, v26, v9 :: v_dual_add_f32 v2, v25, v2   // 000000967ECC: C908131A 09020519
	v_dual_add_f32 v1, v10, v1 :: v_dual_add_f32 v4, v23, v4   // 000000967ED4: C908030A 01040917
	s_delay_alu instid0(VALU_DEP_3)                            // 000000967EDC: BF870003
	v_dual_add_f32 v8, v18, v8 :: v_dual_add_nc_u32 v7, 0x5000, v7// 000000967EE0: C9201112 08060EFF 00005000
	v_dual_add_f32 v3, v24, v3 :: v_dual_add_f32 v6, v21, v6   // 000000967EEC: C9080718 03060D15
	v_add_f32_e32 v5, v22, v5                                  // 000000967EF4: 060A0B16
	ds_store_2addr_b32 v7, v1, v2 offset1:16                   // 000000967EF8: D8381000 00020107
	ds_store_2addr_b32 v7, v3, v4 offset0:32 offset1:48        // 000000967F00: D8383020 00040307
	ds_store_2addr_b32 v7, v5, v6 offset0:64 offset1:80        // 000000967F08: D8385040 00060507
	ds_store_2addr_b32 v7, v8, v9 offset0:96 offset1:112       // 000000967F10: D8387060 00090807
	s_or_b32 exec_lo, exec_lo, s0                              // 000000967F18: 8C7E007E
	s_waitcnt lgkmcnt(0)                                       // 000000967F1C: BF89FC07
	s_barrier                                                  // 000000967F20: BFBD0000
	buffer_gl0_inv                                             // 000000967F24: E0AC0000 00000000
	s_mov_b32 s1, exec_lo                                      // 000000967F2C: BE81007E
	v_cmpx_eq_u32_e32 0, v19                                   // 000000967F30: 7D942680
	s_cbranch_execz 510                                        // 000000967F34: BFA501FE <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_dn_tsILi4ELi8ELi4ELb0EEEvPKjPKDF16_PKiS5_PtNS0_4HtSdEiNS0_6HtFoldE+0x4430>
	v_and_b32_e32 v1, 15, v0                                   // 000000967F38: 3602008F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000967F3C: BF870091
	v_lshlrev_b32_e32 v2, 2, v1                                // 000000967F40: 30040282
	v_add_nc_u32_e32 v48, 0x5000, v2                           // 000000967F44: 4A6004FF 00005000
	v_add_nc_u32_e32 v52, 0x5400, v2                           // 000000967F4C: 4A6804FF 00005400
	v_add_nc_u32_e32 v56, 0x5800, v2                           // 000000967F54: 4A7004FF 00005800
	v_add_nc_u32_e32 v57, 0x5c00, v2                           // 000000967F5C: 4A7204FF 00005C00
	ds_load_2addr_b32 v[2:3], v48 offset1:16                   // 000000967F64: D8DC1000 02000030
	ds_load_2addr_b32 v[4:5], v48 offset0:128 offset1:144      // 000000967F6C: D8DC9080 04000030
	ds_load_2addr_b32 v[6:7], v52 offset1:16                   // 000000967F74: D8DC1000 06000034
	ds_load_2addr_b32 v[8:9], v52 offset0:128 offset1:144      // 000000967F7C: D8DC9080 08000034
	ds_load_2addr_b32 v[10:11], v56 offset1:16                 // 000000967F84: D8DC1000 0A000038
	ds_load_2addr_b32 v[12:13], v56 offset0:128 offset1:144    // 000000967F8C: D8DC9080 0C000038
	ds_load_2addr_b32 v[14:15], v57 offset1:16                 // 000000967F94: D8DC1000 0E000039
	ds_load_2addr_b32 v[16:17], v57 offset0:128 offset1:144    // 000000967F9C: D8DC9080 10000039
	ds_load_2addr_b32 v[18:19], v48 offset0:32 offset1:48      // 000000967FA4: D8DC3020 12000030
	ds_load_2addr_b32 v[20:21], v48 offset0:160 offset1:176    // 000000967FAC: D8DCB0A0 14000030
	ds_load_2addr_b32 v[22:23], v52 offset0:32 offset1:48      // 000000967FB4: D8DC3020 16000034
	ds_load_2addr_b32 v[24:25], v52 offset0:160 offset1:176    // 000000967FBC: D8DCB0A0 18000034
	ds_load_2addr_b32 v[26:27], v56 offset0:32 offset1:48      // 000000967FC4: D8DC3020 1A000038
	ds_load_2addr_b32 v[28:29], v56 offset0:160 offset1:176    // 000000967FCC: D8DCB0A0 1C000038
	ds_load_2addr_b32 v[30:31], v57 offset0:32 offset1:48      // 000000967FD4: D8DC3020 1E000039
	ds_load_2addr_b32 v[32:33], v48 offset0:64 offset1:80      // 000000967FDC: D8DC5040 20000030
	ds_load_2addr_b32 v[34:35], v57 offset0:160 offset1:176    // 000000967FE4: D8DCB0A0 22000039
	ds_load_2addr_b32 v[36:37], v48 offset0:192 offset1:208    // 000000967FEC: D8DCD0C0 24000030
	ds_load_2addr_b32 v[38:39], v52 offset0:64 offset1:80      // 000000967FF4: D8DC5040 26000034
	ds_load_2addr_b32 v[40:41], v52 offset0:192 offset1:208    // 000000967FFC: D8DCD0C0 28000034
	ds_load_2addr_b32 v[42:43], v48 offset0:96 offset1:112     // 000000968004: D8DC7060 2A000030
	ds_load_2addr_b32 v[44:45], v56 offset0:64 offset1:80      // 00000096800C: D8DC5040 2C000038
	ds_load_2addr_b32 v[46:47], v56 offset0:192 offset1:208    // 000000968014: D8DCD0C0 2E000038
	ds_load_2addr_b32 v[48:49], v48 offset0:224 offset1:240    // 00000096801C: D8DCF0E0 30000030
	ds_load_2addr_b32 v[50:51], v52 offset0:96 offset1:112     // 000000968024: D8DC7060 32000034
	ds_load_2addr_b32 v[52:53], v52 offset0:224 offset1:240    // 00000096802C: D8DCF0E0 34000034
	ds_load_2addr_b32 v[54:55], v56 offset0:96 offset1:112     // 000000968034: D8DC7060 36000038
	s_waitcnt lgkmcnt(26)                                      // 00000096803C: BF89FDA7
	v_dual_add_f32 v59, 0, v3 :: v_dual_add_f32 v58, 0, v2     // 000000968040: C9080680 3B3A0480
	s_waitcnt lgkmcnt(18)                                      // 000000968048: BF89FD27
	v_add_f32_e32 v19, 0, v19                                  // 00000096804C: 06262680
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000968050: BF870092
	v_dual_add_f32 v5, v59, v5 :: v_dual_add_f32 v4, v58, v4   // 000000968054: C9080B3B 0504093A
	v_dual_add_f32 v5, v5, v7 :: v_dual_add_f32 v18, 0, v18    // 00000096805C: C9080F05 05122480
	ds_load_2addr_b32 v[2:3], v56 offset0:224 offset1:240      // 000000968064: D8DCF0E0 02000038
	s_waitcnt lgkmcnt(7)                                       // 00000096806C: BF89FC77
	v_add_f32_e32 v7, 0, v42                                   // 000000968070: 060E5480
	v_dual_add_f32 v4, v4, v6 :: v_dual_add_f32 v5, v5, v9     // 000000968074: C9080D04 04041305
	v_add_f32_e32 v18, v18, v20                                // 00000096807C: 06242912
	v_add_f32_e32 v20, 0, v32                                  // 000000968080: 06284080
	s_waitcnt lgkmcnt(4)                                       // 000000968084: BF89FC47
	v_add_f32_e32 v7, v7, v48                                  // 000000968088: 060E6107
	v_dual_add_f32 v5, v5, v11 :: v_dual_add_f32 v32, 0, v33   // 00000096808C: C9081705 05204280
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000968094: BF870113
	v_dual_add_f32 v9, v20, v36 :: v_dual_add_f32 v6, v18, v22 // 000000968098: C9084914 09062D12
	v_dual_add_f32 v18, 0, v43 :: v_dual_add_f32 v5, v5, v13   // 0000009680A0: C9085680 12041B05
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000009680A8: BF8701C2
	v_dual_add_f32 v4, v4, v8 :: v_dual_add_f32 v9, v9, v38    // 0000009680AC: C9081104 04084D09
	v_add_f32_e32 v8, v19, v21                                 // 0000009680B4: 06102B13
	s_waitcnt lgkmcnt(3)                                       // 0000009680B8: BF89FC37
	v_add_f32_e32 v11, v7, v50                                 // 0000009680BC: 06166507
	v_dual_add_f32 v5, v5, v15 :: v_dual_add_f32 v4, v4, v10   // 0000009680C0: C9081F05 05041504
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000009680C8: BF870113
	v_dual_add_f32 v13, v9, v40 :: v_dual_add_f32 v8, v8, v23  // 0000009680CC: C9085109 0D082F08
	v_dual_add_f32 v6, v6, v24 :: v_dual_add_f32 v15, v5, v17  // 0000009680D4: C9083106 060E2305
	s_delay_alu instid0(VALU_DEP_2)                            // 0000009680DC: BF870002
	v_dual_add_f32 v10, v32, v37 :: v_dual_add_f32 v13, v13, v44// 0000009680E0: C9084B20 0A0C590D
	s_waitcnt lgkmcnt(2)                                       // 0000009680E8: BF89FC27
	v_add_f32_e32 v19, v11, v52                                // 0000009680EC: 0626690B
	v_add_f32_e32 v4, v4, v12                                  // 0000009680F0: 06081904
	v_add_f32_e32 v12, v8, v25                                 // 0000009680F4: 06183308
	v_add_f32_e32 v8, v18, v49                                 // 0000009680F8: 06106312
	v_add_f32_e32 v6, v6, v26                                  // 0000009680FC: 060C3506
	s_waitcnt lgkmcnt(1)                                       // 000000968100: BF89FC17
	v_add_f32_e32 v19, v19, v54                                // 000000968104: 06266D13
	v_add_f32_e32 v13, v13, v46                                // 000000968108: 061A5D0D
	v_add_f32_e32 v17, v8, v51                                 // 00000096810C: 06226708
	ds_load_2addr_b32 v[8:9], v57 offset0:192 offset1:208      // 000000968110: D8DCD0C0 08000039
	v_add_f32_e32 v10, v10, v39                                // 000000968118: 06144F0A
	v_dual_add_f32 v6, v6, v28 :: v_dual_add_f32 v17, v17, v53 // 00000096811C: C9083906 06106B11
	v_add_f32_e32 v4, v4, v14                                  // 000000968124: 06081D04
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000968128: BF8700C3
	v_add_f32_e32 v18, v10, v41                                // 00000096812C: 0624530A
	ds_load_2addr_b32 v[10:11], v57 offset0:224 offset1:240    // 000000968130: D8DCF0E0 0A000039
	v_dual_add_f32 v17, v17, v55 :: v_dual_add_f32 v6, v6, v30 // 000000968138: C9086F11 11063D06
	s_waitcnt lgkmcnt(2)                                       // 000000968140: BF89FC27
	v_dual_add_f32 v18, v18, v45 :: v_dual_add_f32 v3, v17, v3 // 000000968144: C9085B12 12020711
	s_delay_alu instid0(VALU_DEP_1)                            // 00000096814C: BF870001
	v_add_f32_e32 v18, v18, v47                                // 000000968150: 06245F12
	v_add_f32_e32 v14, v4, v16                                 // 000000968154: 061C2104
	ds_load_2addr_b32 v[4:5], v57 offset0:64 offset1:80        // 000000968158: D8DC5040 04000039
	v_add_f32_e32 v16, v6, v34                                 // 000000968160: 06204506
	ds_load_2addr_b32 v[6:7], v57 offset0:96 offset1:112       // 000000968164: D8DC7060 06000039
	s_waitcnt lgkmcnt(1)                                       // 00000096816C: BF89FC17
	v_dual_add_f32 v5, v18, v5 :: v_dual_add_f32 v2, v19, v2   // 000000968170: C9080B12 05020513
	s_waitcnt lgkmcnt(0)                                       // 000000968178: BF89FC07
	v_add_f32_e32 v3, v3, v7                                   // 00000096817C: 06060F03
	v_add_f32_e32 v7, v14, v15                                 // 000000968180: 060E1F0E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000968184: BF870193
	v_dual_add_f32 v12, v12, v27 :: v_dual_add_f32 v5, v5, v9  // 000000968188: C908370C 0C041305
	v_dual_add_f32 v2, v2, v6 :: v_dual_add_f32 v3, v3, v11    // 000000968190: C9080D02 02021703
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000968198: BF870091
	v_add_f32_e32 v2, v2, v10                                  // 00000096819C: 06041502
	v_dual_add_f32 v12, v12, v29 :: v_dual_add_f32 v11, v2, v3 // 0000009681A0: C9083B0C 0C0A0702
	v_add_f32_e32 v4, v13, v4                                  // 0000009681A8: 0608090D
	v_sub_f32_e32 v2, v2, v3                                   // 0000009681AC: 08040702
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000009681B0: BF870122
	v_add_f32_e32 v4, v4, v8                                   // 0000009681B4: 06081104
	v_sub_f32_e32 v8, v14, v15                                 // 0000009681B8: 08101F0E
	v_add_f32_e32 v10, v4, v5                                  // 0000009681BC: 06140B04
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000009681C0: BF870121
	v_dual_sub_f32 v4, v4, v5 :: v_dual_add_f32 v5, v10, v11   // 0000009681C4: C9480B04 0404170A
	v_add_f32_e32 v12, v12, v31                                // 0000009681CC: 06183F0C
	v_dual_sub_f32 v10, v10, v11 :: v_dual_add_f32 v13, v4, v2 // 0000009681D0: C948170A 0A0C0504
	v_sub_f32_e32 v2, v4, v2                                   // 0000009681D8: 08040504
	v_and_b32_e32 v14, 1, v0                                   // 0000009681DC: 361C0081
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000009681E0: BF8701A4
	v_add_f32_e32 v6, v12, v35                                 // 0000009681E4: 060C470C
	v_and_b32_e32 v4, 2, v0                                    // 0000009681E8: 36080082
	.long 0xd44a0000                                           // 0000009681EC: D44A0000
	v_cndmask_b32_e32 v1, 0, v14, vcc_lo                       // 0000009681F0: 02021C80
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009681F4: BF870193
	v_add_f32_e32 v9, v16, v6                                  // 0000009681F8: 06120D10
	.long 0xd44a0001                                           // 0000009681FC: D44A0001
	v_cndmask_b32_e32 v1, 0, v4, vcc_lo                        // 000000968200: 02020880
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000968204: BF870122
	v_add_f32_e32 v3, v7, v9                                   // 000000968208: 06061307
	v_sub_f32_e32 v7, v7, v9                                   // 00000096820C: 080E1307
	v_add_f32_e32 v9, v3, v5                                   // 000000968210: 06120B03
	v_sub_f32_e32 v5, v3, v5                                   // 000000968214: 080A0B03
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000968218: BF870223
	v_add_f32_e32 v4, v7, v10                                  // 00000096821C: 06081507
	v_dual_sub_f32 v7, v7, v10 :: v_dual_and_b32 v10, 4, v0    // 000000968220: C9641507 070A0084
	v_mov_b32_dpp v11, v9 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000968228: 7E1602FA FF016109
	v_cndmask_b32_e64 v9, -v9, v9, s0                          // 000000968230: D5010009 20021309
	v_cndmask_b32_e64 v15, -v5, v5, s0                         // 000000968238: D501000F 20020B05
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000968240: BF870194
	.long 0xd44a0002                                           // 000000968244: D44A0002
	v_cndmask_b32_e32 v1, 0, v10, vcc_lo                       // 000000968248: 02021480
	v_add_f32_e32 v3, v9, v11                                  // 00000096824C: 06061709
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000968250: BF8700A1
	v_mov_b32_dpp v11, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000968254: 7E1602FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, s1                          // 00000096825C: D5010003 20060703
	v_dual_sub_f32 v6, v16, v6 :: v_dual_add_f32 v3, v3, v11   // 000000968264: C9480D10 06021703
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000096826C: BF8700A1
	v_mov_b32_dpp v10, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000968270: 7E1402FA FF016403
	v_cndmask_b32_e64 v3, -v3, v3, s2                          // 000000968278: D5010003 200A0703
	v_add_f32_e32 v3, v3, v10                                  // 000000968280: 06061503
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000968284: BF870124
	v_add_f32_e32 v12, v8, v6                                  // 000000968288: 06180D08
	v_sub_f32_e32 v8, v8, v6                                   // 00000096828C: 08100D08
	v_add_f32_e32 v6, v12, v13                                 // 000000968290: 060C1B0C
	v_sub_f32_e32 v9, v12, v13                                 // 000000968294: 08121B0C
	s_delay_alu instid0(VALU_DEP_3)                            // 000000968298: BF870003
	v_add_f32_e32 v13, v8, v2                                  // 00000096829C: 061A0508
	v_sub_f32_e32 v8, v8, v2                                   // 0000009682A0: 08100508
	v_mov_b32_dpp v2, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009682A4: 7E0402FA FF016803
	v_mov_b32_dpp v14, v6 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009682AC: 7E1C02FA FF016106
	v_cndmask_b32_e64 v6, -v6, v6, s0                          // 0000009682B4: D5010006 20020D06
	v_mov_b32_dpp v11, v13 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009682BC: 7E1602FA FF01610D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000009682C4: BF870092
	v_add_f32_e32 v6, v6, v14                                  // 0000009682C8: 060C1D06
	v_mov_b32_dpp v12, v6 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009682CC: 7E1802FA FF016206
	v_cndmask_b32_e64 v6, -v6, v6, s1                          // 0000009682D4: D5010006 20060D06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000009682DC: BF8701C1
	v_add_f32_e32 v6, v6, v12                                  // 0000009682E0: 060C1906
	v_cndmask_b32_e64 v12, -v13, v13, s0                       // 0000009682E4: D501000C 20021B0D
	v_mov_b32_dpp v13, v4 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009682EC: 7E1A02FA FF016104
	v_cndmask_b32_e64 v4, -v4, v4, s0                          // 0000009682F4: D5010004 20020904
	v_add_f32_e32 v11, v12, v11                                // 0000009682FC: 0616170C
	v_mov_b32_dpp v12, v6 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000968300: 7E1802FA FF016406
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000968308: BF870223
	v_add_f32_e32 v4, v4, v13                                  // 00000096830C: 06081B04
	v_cndmask_b32_e64 v6, -v6, v6, s2                          // 000000968310: D5010006 200A0D06
	v_mov_b32_dpp v13, v11 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000968318: 7E1A02FA FF01620B
	v_cndmask_b32_e64 v11, -v11, v11, s1                       // 000000968320: D501000B 2006170B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000968328: BF870134
	v_mov_b32_dpp v14, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000096832C: 7E1C02FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, s1                          // 000000968334: D5010004 20060904
	v_add_f32_e32 v6, v6, v12                                  // 00000096833C: 060C1906
	v_dual_add_f32 v10, v11, v13 :: v_dual_add_f32 v11, v4, v14// 000000968340: C9081B0B 0A0A1D04
	v_mov_b32_dpp v14, v5 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000968348: 7E1C02FA FF016105
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000968350: BF870193
	v_mov_b32_dpp v4, v6 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000968354: 7E0802FA FF016806
	v_mov_b32_dpp v12, v10 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000096835C: 7E1802FA FF01640A
	v_cndmask_b32_e64 v10, -v10, v10, s2                       // 000000968364: D501000A 200A150A
	v_mov_b32_dpp v13, v11 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000096836C: 7E1A02FA FF01640B
	v_cndmask_b32_e64 v11, -v11, v11, s2                       // 000000968374: D501000B 200A170B
	s_delay_alu instid0(VALU_DEP_3)                            // 00000096837C: BF870003
	v_add_f32_e32 v5, v10, v12                                 // 000000968380: 060A190A
	v_mov_b32_dpp v10, v9 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000968384: 7E1402FA FF016109
	v_cndmask_b32_e64 v9, -v9, v9, s0                          // 00000096838C: D5010009 20021309
	v_add_f32_e32 v12, v15, v14                                // 000000968394: 06181D0F
	v_mov_b32_dpp v14, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000968398: 7E1C02FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, s0                          // 0000009683A0: D5010007 20020F07
	v_mov_b32_dpp v15, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009683A8: 7E1E02FA FF016108
	v_cndmask_b32_e64 v8, -v8, v8, s0                          // 0000009683B0: D5010008 20021108
	v_add_f32_e32 v9, v9, v10                                  // 0000009683B8: 06121509
	v_mov_b32_dpp v10, v12 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009683BC: 7E1402FA FF01620C
	v_cndmask_b32_e64 v12, -v12, v12, s1                       // 0000009683C4: D501000C 2006190C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009683CC: BF870214
	v_dual_add_f32 v7, v7, v14 :: v_dual_add_f32 v8, v8, v15   // 0000009683D0: C9081D07 07081F08
	v_mov_b32_dpp v14, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009683D8: 7E1C02FA FF016209
	v_cndmask_b32_e64 v9, -v9, v9, s1                          // 0000009683E0: D5010009 20061309
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009683E8: BF870214
	v_add_f32_e32 v10, v12, v10                                // 0000009683EC: 0614150C
	v_mov_b32_dpp v12, v7 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009683F0: 7E1802FA FF016207
	v_mov_b32_dpp v15, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009683F8: 7E1E02FA FF016208
	v_cndmask_b32_e64 v16, -v7, v7, s1                         // 000000968400: D5010010 20060F07
	v_cndmask_b32_e64 v8, -v8, v8, s1                          // 000000968408: D5010008 20061108
	v_add_f32_e32 v9, v9, v14                                  // 000000968410: 06121D09
	v_add_f32_e32 v7, v11, v13                                 // 000000968414: 060E1B0B
	v_mov_b32_dpp v11, v10 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000968418: 7E1602FA FF01640A
	v_add_f32_e32 v12, v16, v12                                // 000000968420: 06181910
	v_add_f32_e32 v8, v8, v15                                  // 000000968424: 06101F08
	v_mov_b32_dpp v13, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000968428: 7E1A02FA FF016409
	v_cndmask_b32_e64 v9, -v9, v9, s2                          // 000000968430: D5010009 200A1309
	v_cndmask_b32_e64 v10, -v10, v10, s2                       // 000000968438: D501000A 200A150A
	v_mov_b32_dpp v15, v12 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000968440: 7E1E02FA FF01640C
	v_mov_b32_dpp v17, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000968448: 7E2202FA FF016408
	v_cndmask_b32_e64 v12, -v12, v12, s2                       // 000000968450: D501000C 200A190C
	v_cndmask_b32_e64 v18, -v8, v8, s2                         // 000000968458: D5010012 200A1108
	v_add_f32_e32 v14, v10, v11                                // 000000968460: 061C170A
	v_add_f32_e32 v16, v9, v13                                 // 000000968464: 06201B09
	v_mov_b32_dpp v8, v7 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000968468: 7E1002FA FF016807
	v_add_f32_e32 v15, v12, v15                                // 000000968470: 061E1F0C
	v_add_f32_e32 v17, v18, v17                                // 000000968474: 06222312
	v_mov_b32_dpp v9, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000968478: 7E1202FA FF016805
	v_mov_b32_dpp v10, v14 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000968480: 7E1402FA FF01680E
	v_mov_b32_dpp v11, v16 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000968488: 7E1602FA FF016810
	v_mov_b32_dpp v12, v15 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000968490: 7E1802FA FF01680F
	v_mov_b32_dpp v13, v17 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000968498: 7E1A02FA FF016811
	s_and_b32 exec_lo, exec_lo, vcc_lo                         // 0000009684A0: 8B7E6A7E
	s_cbranch_execz 162                                        // 0000009684A4: BFA500A2 <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_dn_tsILi4ELi8ELi4ELb0EEEvPKjPKDF16_PKiS5_PtNS0_4HtSdEiNS0_6HtFoldE+0x4430>
	v_and_b32_e32 v0, 8, v0                                    // 0000009684A8: 36000088
	s_mul_i32 s0, s3, 0x1400                                   // 0000009684AC: 9600FF03 00001400
	s_mul_hi_i32 s1, s3, 0x1400                                // 0000009684B4: 9701FF03 00001400
	s_add_u32 s2, s18, s0                                      // 0000009684BC: 80020012
	s_addc_u32 s3, s19, s1                                     // 0000009684C0: 82030113
	v_cmp_eq_u32_e32 vcc_lo, 0, v0                             // 0000009684C4: 7C940080
	s_lshl_b32 s0, s5, 7                                       // 0000009684C8: 84008705
	.long 0x7f243880                                           // 0000009684CC: 7F243880
	s_ashr_i32 s1, s0, 31                                      // 0000009684D0: 86019F00
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000009684D4: BF870009
	s_lshl_b64 s[0:1], s[0:1], 1                               // 0000009684D8: 84808100
	v_cndmask_b32_e64 v0, -v6, v6, vcc_lo                      // 0000009684DC: D5010000 21AA0D06
	v_lshlrev_b32_e32 v1, 1, v1                                // 0000009684E4: 30020281
	s_add_u32 s2, s2, s0                                       // 0000009684E8: 80020002
	s_addc_u32 s3, s3, s1                                      // 0000009684EC: 82030103
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 0000009684F0: D5010003 21AA0703
	v_add_f32_e32 v0, v0, v4                                   // 0000009684F8: 06000900
	s_clause 0x7                                               // 0000009684FC: BF850007
	global_load_d16_b16 v18, v1, s[2:3] offset:32              // 000000968500: DC820020 12020001
	global_load_d16_b16 v19, v1, s[2:3]                        // 000000968508: DC820000 13020001
	global_load_d16_b16 v20, v1, s[2:3] offset:64              // 000000968510: DC820040 14020001
	global_load_d16_b16 v21, v1, s[2:3] offset:96              // 000000968518: DC820060 15020001
	global_load_d16_b16 v22, v1, s[2:3] offset:128             // 000000968520: DC820080 16020001
	global_load_d16_b16 v23, v1, s[2:3] offset:160             // 000000968528: DC8200A0 17020001
	global_load_d16_b16 v24, v1, s[2:3] offset:192             // 000000968530: DC8200C0 18020001
	global_load_d16_b16 v25, v1, s[2:3] offset:224             // 000000968538: DC8200E0 19020001
	v_cndmask_b32_e64 v4, -v5, v5, vcc_lo                      // 000000968540: D5010004 21AA0B05
	v_cndmask_b32_e64 v5, -v7, v7, vcc_lo                      // 000000968548: D5010005 21AA0F07
	v_cndmask_b32_e64 v7, -v16, v16, vcc_lo                    // 000000968550: D5010007 21AA2110
	v_cndmask_b32_e64 v14, -v14, v14, vcc_lo                   // 000000968558: D501000E 21AA1D0E
	v_add_f32_e32 v2, v3, v2                                   // 000000968560: 06040503
	v_mul_f32_e32 v0, 0x3db504f3, v0                           // 000000968564: 100000FF 3DB504F3
	v_dual_add_f32 v3, v5, v8 :: v_dual_add_f32 v4, v4, v9     // 00000096856C: C9081105 03041304
	v_cndmask_b32_e64 v16, -v17, v17, vcc_lo                   // 000000968574: D5010010 21AA2311
	v_cndmask_b32_e64 v15, -v15, v15, vcc_lo                   // 00000096857C: D501000F 21AA1F0F
	v_add_f32_e32 v5, v14, v10                                 // 000000968584: 060A150E
	v_add_f32_e32 v7, v7, v11                                  // 000000968588: 060E1707
	v_dual_mul_f32 v3, 0x3db504f3, v3 :: v_dual_mul_f32 v4, 0x3db504f3, v4// 00000096858C: C8C606FF 030408FF 3DB504F3
	s_waitcnt vmcnt(4)                                         // 000000968598: BF8913F7
	.long 0x7f2a3992                                           // 00000096859C: 7F2A3992
	v_dual_add_f32 v8, v15, v12 :: v_dual_add_f32 v9, v16, v13 // 0000009685A0: C908190F 08081B10
	v_dual_mul_f32 v2, 0x3db504f3, v2 :: v_dual_mul_f32 v7, 0x3db504f3, v7// 0000009685A8: C8C604FF 02060EFF 3DB504F3
	v_mul_f32_e32 v5, 0x3db504f3, v5                           // 0000009685B4: 100A0AFF 3DB504F3
	.long 0x7f263992                                           // 0000009685BC: 7F263992
	s_delay_alu instid0(VALU_DEP_4)                            // 0000009685C0: BF870004
	v_dual_mul_f32 v9, 0x3db504f3, v9 :: v_dual_mul_f32 v8, 0x3db504f3, v8// 0000009685C4: C8C612FF 090810FF 3DB504F3
	.long 0x7f283992                                           // 0000009685D0: 7F283992
	.long 0x7f0c3992                                           // 0000009685D4: 7F0C3992
	s_mul_i32 s3, s4, 0x1400                                   // 0000009685D8: 9603FF04 00001400
	s_mul_hi_i32 s2, s4, 0x1400                                // 0000009685E0: 9702FF04 00001400
	s_add_u32 s3, s20, s3                                      // 0000009685E8: 80030314
	s_addc_u32 s2, s21, s2                                     // 0000009685EC: 82020215
	s_add_u32 s0, s3, s0                                       // 0000009685F0: 80000003
	s_addc_u32 s1, s2, s1                                      // 0000009685F4: 82010102
	v_fma_mix_f32 v0, v18, v0, neg(0) op_sel_hi:[1,0,0]        // 0000009685F8: CC200000 8A020112
	v_fma_mix_f32 v2, v19, v2, neg(0) op_sel_hi:[1,0,0]        // 000000968600: CC200002 8A020513
	v_fma_mix_f32 v3, v20, v3, neg(0) op_sel_hi:[1,0,0]        // 000000968608: CC200003 8A020714
	v_fma_mix_f32 v4, v21, v4, neg(0) op_sel_hi:[1,0,0]        // 000000968610: CC200004 8A020915
	s_waitcnt vmcnt(3)                                         // 000000968618: BF890FF7
	v_fma_mix_f32 v5, v22, v5, neg(0) op_sel_hi:[1,0,0]        // 00000096861C: CC200005 8A020B16
	.long 0x7e243980                                           // 000000968624: 7E243980
	s_waitcnt vmcnt(2)                                         // 000000968628: BF890BF7
	v_fma_mix_f32 v7, v23, v7, neg(0) op_sel_hi:[1,0,0]        // 00000096862C: CC200007 8A020F17
	s_waitcnt vmcnt(1)                                         // 000000968634: BF8907F7
	v_fma_mix_f32 v8, v24, v8, neg(0) op_sel_hi:[1,0,0]        // 000000968638: CC200008 8A021118
	s_waitcnt vmcnt(0)                                         // 000000968640: BF8903F7
	v_fma_mix_f32 v9, v25, v9, neg(0) op_sel_hi:[1,0,0]        // 000000968644: CC200009 8A021319
	.long 0x7e0c3982                                           // 00000096864C: 7E0C3982
	v_and_b32_e32 v10, 1, v18                                  // 000000968650: 36142481
	.long 0x7e243984                                           // 000000968654: 7E243984
	.long 0x7e263983                                           // 000000968658: 7E263983
	.long 0x7e283985                                           // 00000096865C: 7E283985
	.long 0x7e2a3988                                           // 000000968660: 7E2A3988
	v_and_b32_e32 v6, 1, v6                                    // 000000968664: 360C0C81
	v_and_b32_e32 v11, 1, v18                                  // 000000968668: 36162481
	.long 0x7e243987                                           // 00000096866C: 7E243987
	v_and_b32_e32 v12, 1, v19                                  // 000000968670: 36182681
	v_and_b32_e32 v13, 1, v20                                  // 000000968674: 361A2881
	v_and_b32_e32 v15, 1, v21                                  // 000000968678: 361E2A81
	v_add3_u32 v2, v2, v6, 0x7fff                              // 00000096867C: D6550002 03FE0D02 00007FFF
	v_and_b32_e32 v14, 1, v18                                  // 000000968688: 361C2481
	.long 0x7e243989                                           // 00000096868C: 7E243989
	v_add3_u32 v0, v0, v10, 0x7fff                             // 000000968690: D6550000 03FE1500 00007FFF
	v_add3_u32 v3, v3, v12, 0x7fff                             // 00000096869C: D6550003 03FE1903 00007FFF
	v_add3_u32 v4, v4, v11, 0x7fff                             // 0000009686A8: D6550004 03FE1704 00007FFF
	v_add3_u32 v5, v5, v13, 0x7fff                             // 0000009686B4: D6550005 03FE1B05 00007FFF
	v_and_b32_e32 v6, 1, v18                                   // 0000009686C0: 360C2481
	v_add3_u32 v8, v8, v15, 0x7fff                             // 0000009686C4: D6550008 03FE1F08 00007FFF
	v_add3_u32 v7, v7, v14, 0x7fff                             // 0000009686D0: D6550007 03FE1D07 00007FFF
	s_delay_alu instid0(VALU_DEP_3)                            // 0000009686DC: BF870003
	v_add3_u32 v6, v9, v6, 0x7fff                              // 0000009686E0: D6550006 03FE0D09 00007FFF
	s_clause 0x7                                               // 0000009686EC: BF850007
	global_store_d16_hi_b16 v1, v2, s[0:1]                     // 0000009686F0: DC960000 00000201
	global_store_d16_hi_b16 v1, v0, s[0:1] offset:32           // 0000009686F8: DC960020 00000001
	global_store_d16_hi_b16 v1, v3, s[0:1] offset:64           // 000000968700: DC960040 00000301
	global_store_d16_hi_b16 v1, v4, s[0:1] offset:96           // 000000968708: DC960060 00000401
	global_store_d16_hi_b16 v1, v5, s[0:1] offset:128          // 000000968710: DC960080 00000501
	global_store_d16_hi_b16 v1, v7, s[0:1] offset:160          // 000000968718: DC9600A0 00000701
	global_store_d16_hi_b16 v1, v8, s[0:1] offset:192          // 000000968720: DC9600C0 00000801
	global_store_d16_hi_b16 v1, v6, s[0:1] offset:224          // 000000968728: DC9600E0 00000601
	s_nop 0                                                    // 000000968730: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 000000968734: BFB60003
	s_endpgm                                                   // 000000968738: BFB00000
	s_branch 63852                                             // 00000096873C: BFA0F96C <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_dn_tsILi4ELi8ELi4ELb0EEEvPKjPKDF16_PKiS5_PtNS0_4HtSdEiNS0_6HtFoldE+0x29f0>
		...

