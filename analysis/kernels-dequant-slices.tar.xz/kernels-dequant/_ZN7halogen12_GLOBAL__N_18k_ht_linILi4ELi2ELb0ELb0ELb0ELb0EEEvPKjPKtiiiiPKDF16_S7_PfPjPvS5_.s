0000000000481700 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi2ELb0ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_>:
; _ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi2ELb0ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_():
	s_clause 0x3                                               // 000000481700: BF850003
	s_load_b256 s[12:19], s[0:1], null                         // 000000481704: F40C0300 F8000000
	s_load_b256 s[20:27], s[0:1], 0x20                         // 00000048170C: F40C0500 F8000020
	s_load_b128 s[28:31], s[0:1], 0x40                         // 000000481714: F4080700 F8000040
	s_load_b32 s33, s[0:1], 0x54                               // 00000048171C: F4000840 F8000054
	v_and_b32_e32 v13, 31, v0                                  // 000000481724: 361A009F
	v_lshrrev_b32_e32 v11, 5, v0                               // 000000481728: 32160085
	s_mov_b32 s4, s3                                           // 00000048172C: BE840003
	s_delay_alu instid0(VALU_DEP_2)                            // 000000481730: BF870002
	v_lshlrev_b32_e32 v12, 2, v13                              // 000000481734: 30181A82
	s_waitcnt lgkmcnt(0)                                       // 000000481738: BF89FC07
	s_ashr_i32 s34, s17, 31                                    // 00000048173C: 86229F11
	s_mul_i32 s35, s19, s3                                     // 000000481740: 96230313
	s_lshr_b32 s0, s34, 25                                     // 000000481744: 85009922
	s_add_i32 s1, s35, s19                                     // 000000481748: 81011323
	s_add_i32 s0, s17, s0                                      // 00000048174C: 81000011
	s_mov_b32 s19, exec_lo                                     // 000000481750: BE93007E
	s_ashr_i32 s0, s0, 7                                       // 000000481754: 86008700
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000481758: BF870499
	s_min_i32 s0, s0, s1                                       // 00000048175C: 89000100
	s_sub_i32 s11, s0, s35                                     // 000000481760: 818B2300
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000481764: BF870499
	s_lshl_b32 s10, s11, 1                                     // 000000481768: 840A810B
	.long 0xd4c4007e                                           // 00000048176C: D4C4007E
	v_cndmask_b32_e32 v1, s10, v11, vcc_lo                     // 000000481770: 0202160A
	s_cbranch_execz 506                                        // 000000481774: BFA501FA <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi2ELb0ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x860>
	s_add_i32 s36, s16, -1                                     // 000000481778: 8124C110
	s_cmp_lg_u64 s[30:31], 0                                   // 00000048177C: BF11801E
	v_and_b32_e32 v2, 2, v0                                    // 000000481780: 36040082
	s_cselect_b32 s37, -1, 0                                   // 000000481784: 982580C1
	s_abs_i32 s38, s11                                         // 000000481788: BEA6150B
	v_lshlrev_b32_e32 v6, 3, v13                               // 00000048178C: 300C1A83
	s_cvt_f32_u32 s0, s38                                      // 000000481790: BE806526
	v_dual_mov_b32 v8, v11 :: v_dual_and_b32 v1, 1, v0         // 000000481794: CA24010B 08000081
	v_and_b32_e32 v4, 4, v0                                    // 00000048179C: 36080084
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000004817A0: BF870009
	v_rcp_iflag_f32_e32 v3, s0                                 // 0000004817A4: 7E065600
	v_and_b32_e32 v5, 8, v0                                    // 0000004817A8: 360A0088
	v_add_nc_u32_e32 v7, s35, v11                              // 0000004817AC: 4A0E1623
	.long 0xd44a0003                                           // 0000004817B0: D44A0003
	v_cndmask_b32_e32 v1, 0, v2, vcc_lo                        // 0000004817B4: 02020480
	v_lshl_or_b32 v2, v11, 8, v6                               // 0000004817B8: D6560002 0419110B
	s_ashr_i32 s42, s11, 31                                    // 0000004817C0: 862A9F0B
	s_sub_i32 s9, 0, s38                                       // 0000004817C4: 81892680
	s_mul_i32 s44, s42, 0x1400                                 // 0000004817C8: 962CFF2A 00001400
	.long 0xd44c0000                                           // 0000004817D0: D44C0000
	v_cndmask_b32_e32 v1, 16, v13, vcc_lo                      // 0000004817D4: 02021A90
	.long 0xd44a0001                                           // 0000004817D8: D44A0001
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 0000004817DC: 02020280
	v_readfirstlane_b32 s5, v3                                 // 0000004817E0: 7E0A0503
	.long 0xd44a0006                                           // 0000004817E4: D44A0006
	v_cndmask_b32_e32 v1, 0, v5, vcc_lo                        // 0000004817E8: 02020A80
	v_lshl_or_b32 v1, v7, 7, v12                               // 0000004817EC: D6560001 04310F07
	v_subrev_nc_u32_e32 v9, s44, v2                            // 0000004817F4: 4E12042C
	s_lshl_b32 s7, s11, 7                                      // 0000004817F8: 8407870B
	s_mul_f32 s8, s5, 0x4f7ffffe                               // 0000004817FC: A208FF05 4F7FFFFE
	.long 0xd44a0005                                           // 000000481804: D44A0005
	v_cndmask_b32_e32 v1, 0, v4, vcc_lo                        // 000000481808: 02020880
	s_mov_b32 s39, s17                                         // 00000048180C: BEA70011
	s_mov_b32 s40, 0                                           // 000000481810: BEA80080
	s_cvt_u32_f32 s8, s8                                       // 000000481814: BE886708
	s_mov_b32 s41, 0x76543210                                  // 000000481818: BEA900FF 76543210
	s_lshl_b32 s43, s11, 8                                     // 000000481820: 842B880B
	s_sub_i32 s44, 0, s7                                       // 000000481824: 81AC0780
	s_mul_i32 s9, s9, s8                                       // 000000481828: 96090809
	s_mov_b32 s46, 0x3db504f3                                  // 00000048182C: BEAE00FF 3DB504F3
	s_mul_hi_u32 s9, s8, s9                                    // 000000481834: 96890908
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000481838: BF870009
	s_add_i32 s45, s8, s9                                      // 00000048183C: 812D0908
	s_branch 168                                               // 000000481840: BFA000A8 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi2ELb0ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x3e4>
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000481844: BF870091
	.long 0xd7006a02                                           // 000000481848: D7006A02
	v_cndmask_b32_e32 v1, s20, v2, vcc_lo                      // 00000048184C: 02020414
	v_add_co_ci_u32_e64 v3, null, s21, v3, vcc_lo              // 000000481850: D5207C03 01AA0615
	v_add_nc_u32_e32 v1, 0x400, v1                             // 000000481858: 4A0202FF 00000400
	global_load_d16_b16 v2, v[2:3], off offset:6               // 000000481860: DC820006 027C0002
	s_waitcnt vmcnt(0)                                         // 000000481868: BF8903F7
	v_fma_mix_f32 v5, v17, v2, v15 op_sel_hi:[0,1,0]           // 00000048186C: CC200005 143E0511
	v_sub_f32_e32 v4, v18, v16                                 // 000000481874: 08082112
	v_fma_mix_f32 v2, -v17, v2, v15 op_sel_hi:[0,1,0]          // 000000481878: CC200002 343E0511
	v_add_f32_e32 v3, v18, v16                                 // 000000481880: 06062112
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000481884: BF8701A2
	v_add_f32_e32 v7, v4, v2                                   // 000000481888: 060E0504
	v_sub_f32_e32 v2, v4, v2                                   // 00000048188C: 08040504
	v_add_f32_e32 v6, v3, v5                                   // 000000481890: 060C0B03
	v_sub_f32_e32 v3, v3, v5                                   // 000000481894: 08060B03
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000481898: BF870193
	v_mov_b32_dpp v16, v2 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000048189C: 7E2002FA FF016102
	v_mov_b32_dpp v4, v6 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000004818A4: 7E0802FA FF016106
	v_cndmask_b32_e64 v6, -v6, v6, s1                          // 0000004818AC: D5010006 20060D06
	v_cndmask_b32_e64 v2, -v2, v2, s1                          // 0000004818B4: D5010002 20060502
	v_mov_b32_dpp v15, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000004818BC: 7E1E02FA FF016103
	v_cndmask_b32_e64 v3, -v3, v3, s1                          // 0000004818C4: D5010003 20060703
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000004818CC: BF870144
	v_add_f32_e32 v4, v6, v4                                   // 0000004818D0: 06080906
	v_mov_b32_dpp v5, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000004818D4: 7E0A02FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, s1                          // 0000004818DC: D5010007 20060F07
	.long 0xd72c0006                                           // 0000004818E4: D72C0006
	v_cndmask_b32_e32 v1, 0x1400, v14, vcc_lo                  // 0000004818E8: 02021CFF 00001400
	v_dual_add_f32 v2, v2, v16 :: v_dual_add_f32 v5, v7, v5    // 0000004818F0: C9082102 02040B07
	v_mov_b32_dpp v7, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000004818F8: 7E0E02FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, s3                          // 000000481900: D5010004 200E0904
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000481908: BF8701C3
	v_mov_b32_dpp v16, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000048190C: 7E2002FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, s3                          // 000000481914: D5010002 200E0502
	v_mov_b32_dpp v14, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000048191C: 7E1C02FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, s3                          // 000000481924: D5010005 200E0B05
	v_dual_add_f32 v3, v3, v15 :: v_dual_add_f32 v2, v2, v16   // 00000048192C: C9081F03 03022102
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000481934: BF870112
	v_add_f32_e32 v5, v5, v14                                  // 000000481938: 060A1D05
	v_mov_b32_dpp v15, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000048193C: 7E1E02FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, s3                          // 000000481944: D5010003 200E0703
	s_delay_alu instid0(VALU_DEP_4)                            // 00000048194C: BF870004
	v_mov_b32_dpp v16, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000481950: 7E2002FA FF016402
	v_cndmask_b32_e64 v2, -v2, v2, s5                          // 000000481958: D5010002 20160502
	v_mov_b32_dpp v14, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000481960: 7E1C02FA FF016405
	v_cndmask_b32_e64 v5, -v5, v5, s5                          // 000000481968: D5010005 20160B05
	v_add_f32_e32 v4, v4, v7                                   // 000000481970: 06080F04
	.long 0xd72c0007                                           // 000000481974: D72C0007
	v_cndmask_b32_e32 v1, s43, v10, vcc_lo                     // 000000481978: 0202142B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000048197C: BF870193
	v_add_f32_e32 v5, v5, v14                                  // 000000481980: 060A1D05
	v_mov_b32_dpp v10, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000481984: 7E1402FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s5                          // 00000048198C: D5010004 20160904
	v_add_f32_e32 v3, v3, v15                                  // 000000481994: 06061F03
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000481998: BF870224
	v_mov_b32_dpp v14, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000048199C: 7E1C02FA FF016805
	v_cndmask_b32_e64 v5, -v5, v5, s6                          // 0000004819A4: D5010005 201A0B05
	v_add_f32_e32 v4, v4, v10                                  // 0000004819AC: 06081504
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 0000004819B0: BF870254
	v_mov_b32_dpp v15, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000004819B4: 7E1E02FA FF016403
	v_cndmask_b32_e64 v3, -v3, v3, s5                          // 0000004819BC: D5010003 20160703
	v_add_nc_u32_e32 v8, 8, v8                                 // 0000004819C4: 4A101088
	v_dual_add_f32 v2, v2, v16 :: v_dual_add_f32 v5, v5, v14   // 0000004819C8: C9082102 02041D05
	v_mov_b32_dpp v10, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000004819D0: 7E1402FA FF016804
	v_add_f32_e32 v3, v3, v15                                  // 0000004819D8: 06061F03
	v_cndmask_b32_e64 v4, -v4, v4, s6                          // 0000004819DC: D5010004 201A0904
	s_delay_alu instid0(VALU_DEP_4)                            // 0000004819E4: BF870004
	v_mov_b32_dpp v16, v2 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000004819E8: 7E2002FA FF016802
	v_cndmask_b32_e64 v2, -v2, v2, s6                          // 0000004819F0: D5010002 201A0502
	v_sub_nc_u32_e32 v6, v6, v7                                // 0000004819F8: 4C0C0F06
	v_mov_b32_dpp v15, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000004819FC: 7E1E02FA FF016803
	v_cndmask_b32_e64 v3, -v3, v3, s6                          // 000000481A04: D5010003 201A0703
	v_add_f32_e32 v4, v4, v10                                  // 000000481A0C: 06081504
	v_cmp_le_i32_e32 vcc_lo, s10, v8                           // 000000481A10: 7C86100A
	v_add_nc_u32_e32 v6, v9, v6                                // 000000481A14: 4A0C0D09
	v_add_nc_u32_e32 v9, 0x800, v9                             // 000000481A18: 4A1212FF 00000800
	v_dual_add_f32 v3, v3, v15 :: v_dual_add_f32 v2, v2, v16   // 000000481A20: C9081F03 03022102
	s_or_b32 s40, vcc_lo, s40                                  // 000000481A28: 8C28286A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000481A2C: BF8701B1
	v_dual_mov_b32 v15, v3 :: v_dual_mov_b32 v16, v2           // 000000481A30: CA100103 0F100102
	v_cndmask_b32_e64 v2, -v2, v2, s0                          // 000000481A38: D5010002 20020502
	v_cndmask_b32_e64 v3, -v3, v3, s0                          // 000000481A40: D5010003 20020703
	v_permlanex16_b32 v15, v15, s41, 0xfedcba98                // 000000481A48: D65C000F 03FC530F FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000481A54: BF8701B4
	v_permlanex16_b32 v16, v16, s41, 0xfedcba98                // 000000481A58: D65C0010 03FC5310 FEDCBA98
	v_mov_b32_e32 v14, v5                                      // 000000481A64: 7E1C0305
	v_cndmask_b32_e64 v5, -v5, v5, s0                          // 000000481A68: D5010005 20020B05
	v_add_f32_e32 v7, v2, v16                                  // 000000481A70: 060E2102
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000481A74: BF8701B3
	v_permlanex16_b32 v14, v14, s41, 0xfedcba98                // 000000481A78: D65C000E 03FC530E FEDCBA98
	v_mov_b32_e32 v10, v4                                      // 000000481A84: 7E140304
	v_cndmask_b32_e64 v4, -v4, v4, s0                          // 000000481A88: D5010004 20020904
	v_add_f32_e32 v5, v5, v14                                  // 000000481A90: 060A1D05
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000481A94: BF870113
	v_permlanex16_b32 v10, v10, s41, 0xfedcba98                // 000000481A98: D65C000A 03FC530A FEDCBA98
	v_fma_mixhi_f16 v2, v5, s46, 0                             // 000000481AA4: CC220002 02005D05
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000481AAC: BF8701B2
	v_add_f32_e32 v4, v4, v10                                  // 000000481AB0: 06081504
	v_add_f32_e32 v10, v3, v15                                 // 000000481AB4: 06141F03
	v_fma_mixhi_f16 v3, v7, s46, 0                             // 000000481AB8: CC220003 02005D07
	v_fma_mixlo_f16 v2, v4, s46, 0                             // 000000481AC0: CC210002 02005D04
	s_delay_alu instid0(VALU_DEP_3)                            // 000000481AC8: BF870003
	v_fma_mixlo_f16 v3, v10, s46, 0                            // 000000481ACC: CC210003 02005D0A
	ds_store_b64 v6, v[2:3]                                    // 000000481AD4: D9340000 00000206
	s_and_not1_b32 exec_lo, exec_lo, s40                       // 000000481ADC: 917E287E
	s_cbranch_execz 287                                        // 000000481AE0: BFA5011F <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi2ELb0ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x860>
	.long 0xd72d0002                                           // 000000481AE4: D72D0002
	v_cndmask_b32_e32 v0, v8, v45, vcc_lo                      // 000000481AE8: 02005B08
	s_mov_b32 s7, -1                                           // 000000481AEC: BE8700C1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000481AF0: BF870091
	.long 0xd72c0003                                           // 000000481AF4: D72C0003
	v_cndmask_b32_e32 v0, v2, v38, vcc_lo                      // 000000481AF8: 02004D02
	v_sub_nc_u32_e32 v3, v8, v3                                // 000000481AFC: 4C060708
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000481B00: BF870121
	v_subrev_nc_u32_e32 v5, s38, v3                            // 000000481B04: 4E0A0626
	v_cmp_le_u32_e32 vcc_lo, s38, v3                           // 000000481B08: 7C960626
	v_dual_cndmask_b32 v3, v3, v5 :: v_dual_add_nc_u32 v4, 1, v2// 000000481B0C: CA600B03 03040481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000481B14: BF870111
	v_cndmask_b32_e32 v2, v2, v4, vcc_lo                       // 000000481B18: 02040902
	v_cmp_le_u32_e32 vcc_lo, s38, v3                           // 000000481B1C: 7C960626
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000481B20: BF870092
	v_add_nc_u32_e32 v4, 1, v2                                 // 000000481B24: 4A080481
	v_cndmask_b32_e32 v2, v2, v4, vcc_lo                       // 000000481B28: 02040902
	s_and_not1_b32 vcc_lo, exec_lo, s37                        // 000000481B2C: 916A257E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000481B30: BF870091
	v_xor_b32_e32 v14, s42, v2                                 // 000000481B34: 3A1C042A
	v_subrev_nc_u32_e32 v10, s42, v14                          // 000000481B38: 4E141C2A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000481B3C: BF8700A1
	v_mad_u64_u32 v[6:7], null, s44, v10, v[1:2]               // 000000481B40: D6FE7C06 0406142C
	v_min_i32_e32 v2, s36, v10                                 // 000000481B48: 22041424
	v_mad_i64_i32 v[4:5], null, v2, s39, 0                     // 000000481B4C: D6FF7C04 02004F02
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000481B54: BF870093
	v_ashrrev_i32_e32 v7, 31, v6                               // 000000481B58: 340E0C9F
	.long 0xd73c0002                                           // 000000481B5C: D73C0002
	v_cndmask_b32_e32 v1, 1, v6, vcc_lo                        // 000000481B60: 02020C81
	s_cbranch_vccnz 210                                        // 000000481B64: BFA400D2 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi2ELb0ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x7b0>
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000481B68: BF870093
	.long 0xd7006a06                                           // 000000481B6C: D7006A06
	v_cndmask_b32_e32 v1, v4, v6, vcc_lo                       // 000000481B70: 02020D04
	v_add_co_ci_u32_e64 v7, null, v5, v7, vcc_lo               // 000000481B74: D5207C07 01AA0F05
	.long 0x7f3e3880                                           // 000000481B7C: 7F3E3880
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000481B80: BF870112
	.long 0xd73c0006                                           // 000000481B84: D73C0006
	v_cndmask_b32_e32 v1, 1, v6, vcc_lo                        // 000000481B88: 02020C81
	.long 0x7f44399f                                           // 000000481B8C: 7F44399F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000481B90: BF870092
	.long 0xd7006a0f                                           // 000000481B94: D7006A0F
	v_cndmask_b32_e32 v1, s14, v6, vcc_lo                      // 000000481B98: 02020C0E
	v_add_co_ci_u32_e64 v16, null, s15, v7, vcc_lo             // 000000481B9C: D5207C10 01AA0E0F
	.long 0xd7006a06                                           // 000000481BA4: D7006A06
	v_cndmask_b32_e32 v1, s30, v6, vcc_lo                      // 000000481BA8: 02020C1E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000481BAC: BF870001
	v_add_co_ci_u32_e64 v7, null, s31, v7, vcc_lo              // 000000481BB0: D5207C07 01AA0E1F
	global_load_b64 v[15:16], v[15:16], off                    // 000000481BB8: DC560000 0F7C000F
	.long 0xd7006a11                                           // 000000481BC0: D7006A11
	v_cndmask_b32_e32 v1, s20, v2, vcc_lo                      // 000000481BC4: 02020414
	global_load_b64 v[6:7], v[6:7], off                        // 000000481BC8: DC560000 067C0006
	v_add_co_ci_u32_e64 v18, null, s21, v3, vcc_lo             // 000000481BD0: D5207C12 01AA0615
	s_clause 0x1                                               // 000000481BD8: BF850001
	global_load_b32 v19, v[17:18], off                         // 000000481BDC: DC520000 137C0011
	global_load_d16_b16 v17, v[17:18], off offset:4            // 000000481BE4: DC820004 117C0011
	s_waitcnt vmcnt(3)                                         // 000000481BEC: BF890FF7
	.long 0x7e24390f                                           // 000000481BF0: 7E24390F
	s_waitcnt vmcnt(2)                                         // 000000481BF4: BF890BF7
	v_and_b32_e32 v41, 0xffff0000, v6                          // 000000481BF8: 36520CFF FFFF0000
	v_lshlrev_b32_e32 v6, 16, v6                               // 000000481C00: 300C0C90
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000481C04: BF870093
	v_lshlrev_b32_e32 v18, 16, v18                             // 000000481C08: 30242490
	v_mul_f32_e32 v22, 0xbfb8aa3b, v18                         // 000000481C0C: 102C24FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000481C14: BF870291
	v_exp_f32_e32 v22, v22                                     // 000000481C18: 7E2C4B16
	v_dual_add_f32 v22, 1.0, v22 :: v_dual_and_b32 v15, 0xffff0000, v15// 000000481C1C: C9242CF2 160E1EFF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000481C28: BF870111
	v_mul_f32_e32 v21, 0xbfb8aa3b, v15                         // 000000481C2C: 102A1EFF BFB8AA3B
	v_div_scale_f32 v26, null, v22, v22, v18                   // 000000481C34: D6FC7C1A 044A2D16
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000481C3C: BF8701B2
	v_exp_f32_e32 v21, v21                                     // 000000481C40: 7E2A4B15
	v_lshlrev_b32_e32 v20, 16, v16                             // 000000481C44: 30282090
	v_div_scale_f32 v39, s8, v18, v22, v18                     // 000000481C48: D6FC0827 044A2D12
	v_rcp_f32_e32 v30, v26                                     // 000000481C50: 7E3C551A
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000481C54: BF870196
	v_add_f32_e32 v21, 1.0, v21                                // 000000481C58: 062A2AF2
	v_mul_f32_e32 v23, 0xbfb8aa3b, v20                         // 000000481C5C: 102E28FF BFB8AA3B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000481C64: BF870195
	v_fma_f32 v38, -v26, v30, 1.0                              // 000000481C68: D6130026 23CA3D1A
	v_div_scale_f32 v25, null, v21, v21, v15                   // 000000481C70: D6FC7C19 043E2B15
	s_delay_alu instid0(VALU_DEP_3)                            // 000000481C78: BF870003
	v_exp_f32_e32 v23, v23                                     // 000000481C7C: 7E2E4B17
	v_and_b32_e32 v16, 0xffff0000, v16                         // 000000481C80: 362020FF FFFF0000
	v_div_scale_f32 v35, vcc_lo, v15, v21, v15                 // 000000481C88: D6FC6A23 043E2B0F
	v_fmac_f32_e32 v30, v38, v30                               // 000000481C90: 563C3D26
	v_rcp_f32_e32 v28, v25                                     // 000000481C94: 7E385519
	s_delay_alu instid0(TRANS32_DEP_2) | instid1(VALU_DEP_3)   // 000000481C98: BF870186
	v_dual_add_f32 v23, 1.0, v23 :: v_dual_mul_f32 v24, 0xbfb8aa3b, v16// 000000481C9C: C9062EF2 171820FF BFB8AA3B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000481CA8: BF870115
	v_fma_f32 v36, -v25, v28, 1.0                              // 000000481CAC: D6130024 23CA3919
	v_div_scale_f32 v27, null, v23, v23, v20                   // 000000481CB4: D6FC7C1B 04522F17
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000481CBC: BF8701A3
	v_exp_f32_e32 v24, v24                                     // 000000481CC0: 7E304B18
	v_div_scale_f32 v37, s7, v20, v23, v20                     // 000000481CC4: D6FC0725 04522F14
	v_fmac_f32_e32 v28, v36, v28                               // 000000481CCC: 56383924
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 000000481CD0: BF870313
	v_rcp_f32_e32 v32, v27                                     // 000000481CD4: 7E40551B
	v_add_f32_e32 v24, 1.0, v24                                // 000000481CD8: 063030F2
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000481CDC: BF870115
	v_fma_f32 v40, -v27, v32, 1.0                              // 000000481CE0: D6130028 23CA411B
	v_div_scale_f32 v29, null, v24, v24, v16                   // 000000481CE8: D6FC7C1D 04423118
	v_div_scale_f32 v38, s9, v16, v24, v16                     // 000000481CF0: D6FC0926 04423110
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000481CF8: BF870193
	v_fmac_f32_e32 v32, v40, v32                               // 000000481CFC: 56404128
	v_rcp_f32_e32 v33, v29                                     // 000000481D00: 7E42551D
	v_mul_f32_e32 v40, v35, v28                                // 000000481D04: 10503923
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000481D08: BF870112
	v_mul_f32_e32 v42, v37, v32                                // 000000481D0C: 10544125
	v_fma_f32 v43, -v25, v40, v35                              // 000000481D10: D613002B 248E5119
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000481D18: BF870292
	v_fma_f32 v46, -v27, v42, v37                              // 000000481D1C: D613002E 2496551B
	v_fma_f32 v36, -v29, v33, 1.0                              // 000000481D24: D6130024 23CA431D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000481D2C: BF870113
	v_fmac_f32_e32 v40, v43, v28                               // 000000481D30: 5650392B
	v_dual_fmac_f32 v42, v46, v32 :: v_dual_fmac_f32 v33, v36, v33// 000000481D34: C800412E 2A204324
	v_mul_f32_e32 v36, v39, v30                                // 000000481D3C: 10483D27
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000481D40: BF870193
	v_fma_f32 v25, -v25, v40, v35                              // 000000481D44: D6130019 248E5119
	v_fma_f32 v27, -v27, v42, v37                              // 000000481D4C: D613001B 2496551B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000481D54: BF870214
	v_mul_f32_e32 v44, v38, v33                                // 000000481D58: 10584326
	v_fma_f32 v45, -v26, v36, v39                              // 000000481D5C: D613002D 249E491A
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000481D64: BF8701A4
	v_div_fmas_f32 v25, v25, v28, v40                          // 000000481D68: D6370019 04A23919
	s_mov_b32 vcc_lo, s8                                       // 000000481D70: BEEA0008
	v_fma_f32 v43, -v29, v44, v38                              // 000000481D74: D613002B 249A591D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000481D7C: BF870193
	v_fmac_f32_e32 v36, v45, v30                               // 000000481D80: 56483D2D
	v_div_fixup_f32 v15, v25, v21, v15                         // 000000481D84: D627000F 043E2B19
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000481D8C: BF870193
	v_fmac_f32_e32 v44, v43, v33                               // 000000481D90: 5658432B
	v_fma_f32 v26, -v26, v36, v39                              // 000000481D94: D613001A 249E491A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000481D9C: BF870193
	v_mul_f32_e32 v15, v15, v41                                // 000000481DA0: 101E530F
	v_fma_f32 v25, -v29, v44, v38                              // 000000481DA4: D6130019 249A591D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000481DAC: BF8701A3
	v_div_fmas_f32 v26, v26, v30, v36                          // 000000481DB0: D637001A 04923D1A
	s_mov_b32 vcc_lo, s7                                       // 000000481DB8: BEEA0007
	.long 0x7e3e398f                                           // 000000481DBC: 7E3E398F
	v_div_fmas_f32 v21, v27, v32, v42                          // 000000481DC0: D6370015 04AA411B
	s_mov_b32 vcc_lo, s9                                       // 000000481DC8: BEEA0009
	v_div_fixup_f32 v18, v26, v22, v18                         // 000000481DCC: D6270012 044A2D1A
	v_lshlrev_b32_e32 v22, 16, v7                              // 000000481DD4: 302C0E90
	v_and_b32_e32 v7, 0xffff0000, v7                           // 000000481DD8: 360E0EFF FFFF0000
	v_div_fixup_f32 v20, v21, v23, v20                         // 000000481DE0: D6270014 04522F15
	s_mov_b32 s7, 0                                            // 000000481DE8: BE870080
	v_mul_f32_e32 v6, v18, v6                                  // 000000481DEC: 100C0D12
	v_div_fmas_f32 v18, v25, v33, v44                          // 000000481DF0: D6370012 04B24319
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000481DF8: BF870193
	v_mul_f32_e32 v20, v20, v22                                // 000000481DFC: 10282D14
	.long 0x7e443986                                           // 000000481E00: 7E443986
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000481E04: BF870223
	v_div_fixup_f32 v16, v18, v24, v16                         // 000000481E08: D6270010 04423112
	v_and_b32_e32 v18, 1, v31                                  // 000000481E10: 36243E81
	v_bfe_u32 v21, v20, 16, 1                                  // 000000481E14: D6100015 02052114
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000481E1C: BF870193
	v_dual_mul_f32 v7, v16, v7 :: v_dual_and_b32 v22, 1, v34   // 000000481E20: C8E40F10 07164481
	v_add3_u32 v15, v15, v18, 0x7fff                           // 000000481E28: D655000F 03FE250F 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000481E34: BF870193
	v_add3_u32 v16, v20, v21, 0x7fff                           // 000000481E38: D6550010 03FE2B14 00007FFF
	v_add3_u32 v6, v6, v22, 0x7fff                             // 000000481E44: D6550006 03FE2D06 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000481E50: BF870214
	v_bfe_u32 v18, v7, 16, 1                                   // 000000481E54: D6100012 02052107
	v_and_b32_e32 v15, 0xffff0000, v15                         // 000000481E5C: 361E1EFF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000481E64: BF870214
	v_and_b32_e32 v20, 0xffff0000, v16                         // 000000481E68: 362820FF FFFF0000
	v_and_b32_e32 v6, 0xffff0000, v6                           // 000000481E70: 360C0CFF FFFF0000
	s_delay_alu instid0(VALU_DEP_4)                            // 000000481E78: BF870004
	v_add3_u32 v7, v7, v18, 0x7fff                             // 000000481E7C: D6550007 03FE2507 00007FFF
	s_waitcnt vmcnt(1)                                         // 000000481E88: BF8907F7
	v_fma_mix_f32 v16, v19, v15, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000481E8C: CC200810 8A021F13
	s_waitcnt vmcnt(0)                                         // 000000481E94: BF8903F7
	v_fma_mix_f32 v15, v17, v20, neg(0) op_sel_hi:[1,0,0]      // 000000481E98: CC20000F 8A022911
	v_fma_mix_f32 v18, v19, v6, neg(0) op_sel_hi:[1,0,0]       // 000000481EA0: CC200012 8A020D13
	v_and_b32_e32 v17, 0xffff0000, v7                          // 000000481EA8: 36220EFF FFFF0000
	s_and_not1_b32 vcc_lo, exec_lo, s7                         // 000000481EB0: 916A077E
	s_cbranch_vccnz 65123                                      // 000000481EB4: BFA4FE63 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi2ELb0ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x144>
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000481EB8: BF870093
	.long 0xd73c0004                                           // 000000481EBC: D73C0004
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 000000481EC0: 02020881
	.long 0xd7006a04                                           // 000000481EC4: D7006A04
	v_cndmask_b32_e32 v1, s14, v4, vcc_lo                      // 000000481EC8: 0202080E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000481ECC: BF870111
	v_add_co_ci_u32_e64 v5, null, s15, v5, vcc_lo              // 000000481ED0: D5207C05 01AA0A0F
	.long 0xd7006a04                                           // 000000481ED8: D7006A04
	v_cndmask_b32_e32 v1, v4, v2, vcc_lo                       // 000000481EDC: 02020504
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000481EE0: BF8700A1
	v_add_co_ci_u32_e64 v5, null, v5, v3, vcc_lo               // 000000481EE4: D5207C05 01AA0705
	.long 0xd7006a06                                           // 000000481EEC: D7006A06
	v_cndmask_b32_e32 v1, s20, v2, vcc_lo                      // 000000481EF0: 02020414
	v_add_co_ci_u32_e64 v7, null, s21, v3, vcc_lo              // 000000481EF4: D5207C07 01AA0615
	global_load_b64 v[4:5], v[4:5], off                        // 000000481EFC: DC560000 047C0004
	s_clause 0x1                                               // 000000481F04: BF850001
	global_load_b32 v17, v[6:7], off                           // 000000481F08: DC520000 117C0006
	global_load_d16_b16 v6, v[6:7], off offset:4               // 000000481F10: DC820004 067C0006
	s_waitcnt vmcnt(2)                                         // 000000481F18: BF890BF7
	.long 0x7e0e3904                                           // 000000481F1C: 7E0E3904
	v_and_b32_e32 v4, 0xffff0000, v4                           // 000000481F20: 360808FF FFFF0000
	v_lshlrev_b32_e32 v15, 16, v5                              // 000000481F28: 301E0A90
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000481F2C: BF8701A3
	v_lshlrev_b32_e32 v7, 16, v7                               // 000000481F30: 300E0E90
	s_waitcnt vmcnt(1)                                         // 000000481F34: BF8907F7
	v_fma_mix_f32 v16, v17, v4, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000481F38: CC200810 8A020911
	s_waitcnt vmcnt(0)                                         // 000000481F40: BF8903F7
	v_fma_mix_f32 v15, v6, v15, neg(0) op_sel_hi:[1,0,0]       // 000000481F44: CC20000F 8A021F06
	v_fma_mix_f32 v18, v17, v7, neg(0) op_sel_hi:[1,0,0]       // 000000481F4C: CC200012 8A020F11
	v_and_b32_e32 v17, 0xffff0000, v5                          // 000000481F54: 36220AFF FFFF0000
	s_branch 65081                                             // 000000481F5C: BFA0FE39 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi2ELb0ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x144>
	s_or_b32 exec_lo, exec_lo, s19                             // 000000481F60: 8C7E137E
	s_bfe_i32 s10, s11, 0x1001c                                // 000000481F64: 938AFF0B 0001001C
	s_lshr_b32 s5, s34, 28                                     // 000000481F6C: 85059C22
	s_lshr_b64 s[0:1], s[10:11], 29                            // 000000481F70: 85809D0A
	s_lshl_b32 s3, s11, 3                                      // 000000481F74: 8403830B
	s_add_i32 s0, s0, 7                                        // 000000481F78: 81008700
	s_lshl_b32 s1, s35, 3                                      // 000000481F7C: 84018323
	s_ashr_i32 s0, s0, 3                                       // 000000481F80: 86008300
	v_dual_mov_b32 v14, 0 :: v_dual_mov_b32 v19, 0             // 000000481F84: CA100080 0E120080
	.long 0xd72c0001                                           // 000000481F8C: D72C0001
	v_cndmask_b32_e32 v1, s0, v11, vcc_lo                      // 000000481F90: 02021600
	v_dual_mov_b32 v18, 0 :: v_dual_mov_b32 v21, 0             // 000000481F94: CA100080 12140080
	v_dual_mov_b32 v20, 0 :: v_dual_mov_b32 v27, 0             // 000000481F9C: CA100080 141A0080
	v_dual_mov_b32 v22, 0 :: v_dual_mov_b32 v35, 0             // 000000481FA4: CA100080 16220080
	v_mov_b32_e32 v24, 0                                       // 000000481FAC: 7E300280
	v_add_nc_u32_e32 v2, s0, v1                                // 000000481FB0: 4A040200
	s_add_i32 s0, s17, s5                                      // 000000481FB4: 81000511
	s_ashr_i32 s5, s1, 31                                      // 000000481FB8: 86059F01
	s_ashr_i32 s0, s0, 4                                       // 000000481FBC: 86008400
	s_waitcnt lgkmcnt(0)                                       // 000000481FC0: BF89FC07
	v_min_i32_e32 v16, s3, v2                                  // 000000481FC4: 22200403
	s_mul_i32 s3, s0, s2                                       // 000000481FC8: 96030200
	s_mul_hi_i32 s6, s0, s2                                    // 000000481FCC: 97060200
	s_add_u32 s0, s3, s1                                       // 000000481FD0: 80000103
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000481FD4: 3404029F
	v_cmp_lt_i32_e32 vcc_lo, v1, v16                           // 000000481FD8: 7C822101
	s_addc_u32 s1, s6, s5                                      // 000000481FDC: 82010506
	s_barrier                                                  // 000000481FE0: BFBD0000
	s_lshl_b64 s[6:7], s[0:1], 10                              // 000000481FE4: 84868A00
	buffer_gl0_inv                                             // 000000481FE8: E0AC0000 00000000
	s_and_saveexec_b32 s1, vcc_lo                              // 000000481FF0: BE81206A
	s_cbranch_execz 31                                         // 000000481FF4: BFA5001F <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi2ELb0ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x974>
	.long 0xd73c0003                                           // 000000481FF8: D73C0003
	v_cndmask_b32_e32 v1, 10, v1, vcc_lo                       // 000000481FFC: 0202028A
	s_add_u32 s0, s12, s6                                      // 000000482000: 8000060C
	s_addc_u32 s3, s13, s7                                     // 000000482004: 8203070D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000482008: BF870091
	.long 0xd7000003                                           // 00000048200C: D7000003
	v_cndmask_b32_e32 v1, s0, v3, vcc_lo                       // 000000482010: 02020600
	v_add_co_ci_u32_e64 v4, null, s3, v4, s0                   // 000000482014: D5207C04 00020803
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000048201C: BF870092
	.long 0xd7000003                                           // 000000482020: D7000003
	v_cndmask_b32_e32 v1, v3, v12, vcc_lo                      // 000000482024: 02021903
	v_add_co_ci_u32_e64 v4, null, 0, v4, s0                    // 000000482028: D5207C04 00020880
	s_clause 0x7                                               // 000000482030: BF850007
	global_load_b32 v18, v[3:4], off                           // 000000482034: DC520000 127C0003
	global_load_b32 v19, v[3:4], off offset:128                // 00000048203C: DC520080 137C0003
	global_load_b32 v20, v[3:4], off offset:256                // 000000482044: DC520100 147C0003
	global_load_b32 v21, v[3:4], off offset:384                // 00000048204C: DC520180 157C0003
	global_load_b32 v22, v[3:4], off offset:512                // 000000482054: DC520200 167C0003
	global_load_b32 v24, v[3:4], off offset:640                // 00000048205C: DC520280 187C0003
	global_load_b32 v27, v[3:4], off offset:768                // 000000482064: DC520300 1B7C0003
	global_load_b32 v35, v[3:4], off offset:896                // 00000048206C: DC520380 237C0003
	s_or_b32 exec_lo, exec_lo, s1                              // 000000482074: 8C7E017E
	v_dual_mov_b32 v38, 0 :: v_dual_mov_b32 v37, 0             // 000000482078: CA100080 26240080
	v_dual_mov_b32 v36, 0 :: v_dual_mov_b32 v33, 0             // 000000482080: CA100080 24200080
	v_dual_mov_b32 v34, 0 :: v_dual_mov_b32 v23, 0             // 000000482088: CA100080 22160080
	v_dual_mov_b32 v32, 0 :: v_dual_mov_b32 v31, 0             // 000000482090: CA100080 201E0080
	v_dual_mov_b32 v30, 0 :: v_dual_mov_b32 v25, 0             // 000000482098: CA100080 1E180080
	v_dual_mov_b32 v26, 0 :: v_dual_mov_b32 v29, 0             // 0000004820A0: CA100080 1A1C0080
	v_dual_mov_b32 v28, 0 :: v_dual_mov_b32 v17, 0             // 0000004820A8: CA100080 1C100080
	v_mov_b32_e32 v15, 0                                       // 0000004820B0: 7E1E0280
	s_ashr_i32 s3, s2, 31                                      // 0000004820B4: 86039F02
	s_and_saveexec_b32 s1, vcc_lo                              // 0000004820B8: BE81206A
	s_cbranch_execz 1032                                       // 0000004820BC: BFA50408 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi2ELb0ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x19e0>
	v_dual_mov_b32 v15, 0 :: v_dual_lshlrev_b32 v4, 5, v13     // 0000004820C0: CA220080 0F041A85
	v_mad_u32_u24 v7, 0x420, v11, v12                          // 0000004820C8: D60B0007 043216FF 00000420
	v_dual_mov_b32 v26, 0 :: v_dual_and_b32 v9, 16, v0         // 0000004820D4: CA240080 1A080090
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000004820DC: BF870243
	v_dual_mov_b32 v28, 0 :: v_dual_add_nc_u32 v5, 0x3f0, v4   // 0000004820E0: CA200080 1C0408FF 000003F0
	v_cmp_ne_u32_e32 vcc_lo, 0, v13                            // 0000004820EC: 7C9A1A80
	.long 0xd73c0002                                           // 0000004820F0: D73C0002
	v_cndmask_b32_e32 v1, 10, v1, vcc_lo                       // 0000004820F4: 0202028A
	v_dual_mov_b32 v17, 0 :: v_dual_add_nc_u32 v40, 1, v1      // 0000004820F8: CA200080 11280281
	v_lshrrev_b32_e32 v8, 5, v5                                // 000000482100: 32100A85
	v_lshl_or_b32 v41, v1, 5, v9                               // 000000482104: D6560029 04250B01
	v_dual_mov_b32 v30, 0 :: v_dual_and_b32 v5, 0x7e0, v5      // 00000048210C: CA240080 1E040AFF 000007E0
	v_mul_u32_u24_e32 v6, 0x420, v11                           // 000000482118: 160C16FF 00000420
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000482120: BF870224
	v_subrev_nc_u32_e32 v8, 32, v8                             // 000000482124: 4E1010A0
	v_add_nc_u32_e32 v42, 0x2800, v7                           // 000000482128: 4A540EFF 00002800
	v_sub_nc_u32_e32 v4, v5, v4                                // 000000482130: 4C080905
	v_sub_nc_u32_e32 v39, 0, v16                               // 000000482134: 4C4E2080
	v_dual_mov_b32 v25, 0 :: v_dual_mov_b32 v14, 0             // 000000482138: CA100080 190E0080
	v_cndmask_b32_e32 v1, 31, v8, vcc_lo                       // 000000482140: 0202109F
	.long 0xd7006a02                                           // 000000482144: D7006A02
	v_cndmask_b32_e32 v1, s6, v2, vcc_lo                       // 000000482148: 02020406
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000048214C: BF870191
	v_add_co_ci_u32_e64 v3, null, s7, v3, vcc_lo               // 000000482150: D5207C03 01AA0607
	v_dual_mov_b32 v32, 0 :: v_dual_add_nc_u32 v7, 1, v1       // 000000482158: CA200080 20060281
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000482160: BF870093
	.long 0xd7006a02                                           // 000000482164: D7006A02
	v_cndmask_b32_e32 v1, v2, v12, vcc_lo                      // 000000482168: 02021902
	v_add_co_ci_u32_e64 v3, null, 0, v3, vcc_lo                // 00000048216C: D5207C03 01AA0680
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000482174: BF870193
	v_dual_mov_b32 v34, 0 :: v_dual_and_b32 v5, 31, v7         // 000000482178: CA240080 22040E9F
	.long 0xd7006a02                                           // 000000482180: D7006A02
	v_cndmask_b32_e32 v1, s12, v2, vcc_lo                      // 000000482184: 0202040C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000482188: BF8700D1
	v_add_co_ci_u32_e64 v3, null, s13, v3, vcc_lo              // 00000048218C: D5207C03 01AA060D
	v_dual_mov_b32 v36, 0 :: v_dual_add_nc_u32 v43, 0xfffffc30, v4// 000000482194: CA200080 242A08FF FFFFFC30
	v_lshl_add_u32 v1, v1, 2, v6                               // 0000004821A0: D6460001 04190501
	v_lshl_add_u32 v4, v5, 2, v6                               // 0000004821A8: D6460004 04190505
	.long 0xd7006a09                                           // 0000004821B0: D7006A09
	v_cndmask_b32_e32 v1, 0x400, v2, vcc_lo                    // 0000004821B4: 020204FF 00000400
	v_add_co_ci_u32_e64 v10, null, 0, v3, vcc_lo               // 0000004821BC: D5207C0A 01AA0680
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004821C4: BF870214
	v_dual_mov_b32 v29, 0 :: v_dual_add_nc_u32 v44, 0x2800, v1 // 0000004821C8: CA200080 1D2C02FF 00002800
	v_dual_mov_b32 v38, 0 :: v_dual_add_nc_u32 v45, 0x2800, v4 // 0000004821D4: CA200080 262C08FF 00002800
	v_mov_b32_e32 v31, 0                                       // 0000004821E0: 7E3E0280
	v_mov_b32_e32 v23, 0                                       // 0000004821E4: 7E2E0280
	v_mov_b32_e32 v33, 0                                       // 0000004821E8: 7E420280
	v_mov_b32_e32 v37, 0                                       // 0000004821EC: 7E4A0280
	s_mov_b32 s5, 0                                            // 0000004821F0: BE850080
	s_movk_i32 s6, 0x1eee                                      // 0000004821F4: B0061EEE
	s_branch 918                                               // 0000004821F8: BFA00396 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi2ELb0ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1954>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000004821FC: 8C7E007E
	ds_load_2addr_b32 v[46:47], v45 offset1:32                 // 000000482200: D8DC2000 2E00002D
	ds_load_2addr_b32 v[56:57], v42 offset1:32                 // 000000482208: D8DC2000 3800002A
	ds_load_2addr_b32 v[50:51], v44 offset1:32                 // 000000482210: D8DC2000 3200002C
	ds_load_b128 v[1:4], v41                                   // 000000482218: DBFC0000 01000029
	ds_load_b128 v[5:8], v41 offset:5120                       // 000000482220: DBFC1400 05000029
	ds_load_2addr_b32 v[52:53], v44 offset0:64 offset1:96      // 000000482228: D8DC6040 3400002C
	ds_load_2addr_b32 v[54:55], v45 offset0:64 offset1:96      // 000000482230: D8DC6040 3600002D
	v_add_nc_u32_e32 v40, 1, v40                               // 000000482238: 4A505081
	.long 0xd7000009                                           // 00000048223C: D7000009
	v_cndmask_b32_e32 v1, 0x400, v9, vcc_lo                    // 000000482240: 020212FF 00000400
	s_delay_alu instid0(VALU_DEP_1)                            // 000000482248: BF870001
	v_add_co_ci_u32_e64 v10, null, 0, v10, s0                  // 00000048224C: D5207C0A 00021480
	v_add_nc_u32_e32 v41, 32, v41                              // 000000482254: 4A5252A0
	s_waitcnt lgkmcnt(6)                                       // 000000482258: BF89FC67
	v_mov_b32_e32 v49, v46                                     // 00000048225C: 7E62032E
	s_waitcnt lgkmcnt(5)                                       // 000000482260: BF89FC57
	v_bfe_u32 v46, v56, 12, 16                                 // 000000482264: D610002E 02411938
	v_bfe_u32 v58, v56, 8, 16                                  // 00000048226C: D610003A 02411138
	v_bfe_u32 v59, v56, 4, 16                                  // 000000482274: D610003B 02410938
	v_and_b32_e32 v56, 0xffff, v56                             // 00000048227C: 367070FF 0000FFFF
	s_waitcnt lgkmcnt(4)                                       // 000000482284: BF89FC47
	.long 0xd73d0031                                           // 000000482288: D73D0031
	v_cndmask_b32_e32 v1, v43, v49, vcc_lo                     // 00000048228C: 0202632B
	v_mov_b32_e32 v48, v51                                     // 000000482290: 7E600333
	v_bfe_u32 v60, v57, 8, 16                                  // 000000482294: D610003C 02411139
	v_bfe_u32 v51, v57, 12, 16                                 // 00000048229C: D6100033 02411939
	v_bfe_u32 v61, v57, 4, 16                                  // 0000004822A4: D610003D 02410939
	v_and_b32_e32 v57, 0xffff, v57                             // 0000004822AC: 367272FF 0000FFFF
	.long 0xd72c0032                                           // 0000004822B4: D72C0032
	v_cndmask_b32_e32 v1, 0x83dcd12d, v46, vcc_lo              // 0000004822B8: 02025CFF 83DCD12D
	.long 0xd73d002e                                           // 0000004822C0: D73D002E
	v_cndmask_b32_e32 v1, v43, v47, vcc_lo                     // 0000004822C4: 02025F2B
	.long 0xd72c0030                                           // 0000004822C8: D72C0030
	v_cndmask_b32_e32 v1, 0x83dcd12d, v60, vcc_lo              // 0000004822CC: 020278FF 83DCD12D
	v_bfe_u32 v60, v49, 12, 16                                 // 0000004822D4: D610003C 02411931
	.long 0xd72c002f                                           // 0000004822DC: D72C002F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v51, vcc_lo              // 0000004822E0: 020266FF 83DCD12D
	.long 0xd72c0033                                           // 0000004822E8: D72C0033
	v_cndmask_b32_e32 v1, 0x83dcd12d, v61, vcc_lo              // 0000004822EC: 02027AFF 83DCD12D
	v_bfe_u32 v61, v49, 8, 16                                  // 0000004822F4: D610003D 02411131
	.long 0xd72c003a                                           // 0000004822FC: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 000000482300: 020274FF 83DCD12D
	.long 0xd72c003c                                           // 000000482308: D72C003C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v60, vcc_lo              // 00000048230C: 020278FF 83DCD12D
	v_sad_u8 v50, v50, 0, 0x6400                               // 000000482314: D6220032 03FD0132 00006400
	.long 0xd72c0038                                           // 000000482320: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v56, vcc_lo              // 000000482324: 020270FF 83DCD12D
	.long 0xd72c003d                                           // 00000048232C: D72C003D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v61, vcc_lo              // 000000482330: 02027AFF 83DCD12D
	.long 0xd72c003b                                           // 000000482338: D72C003B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 00000048233C: 020276FF 83DCD12D
	v_bfe_u32 v63, v46, 12, 16                                 // 000000482344: D610003F 0241192E
	v_and_b32_e32 v50, 0xffff, v50                             // 00000048234C: 366464FF 0000FFFF
	v_sad_u8 v58, v58, 0, 0x6400                               // 000000482354: D622003A 03FD013A 00006400
	v_sad_u8 v60, v60, 0, 0x6400                               // 000000482360: D622003C 03FD013C 00006400
	v_bfe_u32 v64, v46, 8, 16                                  // 00000048236C: D6100040 0241112E
	v_sad_u8 v56, v56, 0, 0x6400                               // 000000482374: D6220038 03FD0138 00006400
	v_sad_u8 v61, v61, 0, 0x6400                               // 000000482380: D622003D 03FD013D 00006400
	v_lshl_or_b32 v50, v58, 16, v50                            // 00000048238C: D6560032 04C9213A
	v_and_b32_e32 v60, 0xffff, v60                             // 000000482394: 367878FF 0000FFFF
	v_bfe_u32 v65, v46, 4, 16                                  // 00000048239C: D6100041 0241092E
	.long 0xd72c003f                                           // 0000004823A4: D72C003F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v63, vcc_lo              // 0000004823A8: 02027EFF 83DCD12D
	v_sad_u8 v59, v59, 0, 0x6400                               // 0000004823B0: D622003B 03FD013B 00006400
	v_pk_fma_f16 v50, v50, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000004823BC: CC0E0032 0BFC0D32 0000C931
	v_lshl_or_b32 v60, v61, 16, v60                            // 0000004823C8: D656003C 04F1213D
	v_lshlrev_b32_e32 v56, 16, v56                             // 0000004823D0: 30707090
	.long 0xd72c0040                                           // 0000004823D4: D72C0040
	v_cndmask_b32_e32 v1, 0x83dcd12d, v64, vcc_lo              // 0000004823D8: 020280FF 83DCD12D
	.long 0xd72c003d                                           // 0000004823E0: D72C003D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v65, vcc_lo              // 0000004823E4: 020282FF 83DCD12D
	v_sad_u8 v47, v47, 0, 0x6400                               // 0000004823EC: D622002F 03FD012F 00006400
	v_pk_fma_f16 v58, v60, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000004823F8: CC0E003A 0BFC0D3C 0000C931
	v_and_b32_e32 v46, 0xffff, v46                             // 000000482404: 365C5CFF 0000FFFF
	v_and_or_b32 v56, 0xffff, v59, v56                         // 00000048240C: D6570038 04E276FF 0000FFFF
	v_sad_u8 v59, v63, 0, 0x6400                               // 000000482418: D622003B 03FD013F 00006400
	v_and_b32_e32 v47, 0xffff, v47                             // 000000482424: 365E5EFF 0000FFFF
	s_waitcnt lgkmcnt(3)                                       // 00000048242C: BF89FC37
	v_dot2acc_f32_f16 v15, v58, v1                             // 000000482430: 041E033A
	.long 0xd72c002e                                           // 000000482434: D72C002E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v46, vcc_lo              // 000000482438: 02025CFF 83DCD12D
	v_sad_u8 v60, v64, 0, 0x6400                               // 000000482440: D622003C 03FD0140 00006400
	v_and_b32_e32 v59, 0xffff, v59                             // 00000048244C: 367676FF 0000FFFF
	v_sad_u8 v61, v61, 0, 0x6400                               // 000000482454: D622003D 03FD013D 00006400
	v_sad_u8 v48, v48, 0, 0x6400                               // 000000482460: D6220030 03FD0130 00006400
	.long 0xd72c0039                                           // 00000048246C: D72C0039
	v_cndmask_b32_e32 v1, 0x83dcd12d, v57, vcc_lo              // 000000482470: 020272FF 83DCD12D
	s_waitcnt lgkmcnt(2)                                       // 000000482478: BF89FC27
	v_dot2acc_f32_f16 v17, v58, v5                             // 00000048247C: 04220B3A
	v_lshl_or_b32 v59, v60, 16, v59                            // 000000482480: D656003B 04ED213C
	v_sad_u8 v46, v46, 0, 0x6400                               // 000000482488: D622002E 03FD012E 00006400
	v_lshl_or_b32 v60, v48, 16, v47                            // 000000482494: D656003C 04BD2130
	v_sad_u8 v48, v51, 0, 0x6400                               // 00000048249C: D6220030 03FD0133 00006400
	s_waitcnt lgkmcnt(0)                                       // 0000004824A8: BF89FC07
	v_mov_b32_e32 v51, v54                                     // 0000004824AC: 7E660336
	v_pk_fma_f16 v58, v59, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000004824B0: CC0E003A 0BFC0D3B 0000C931
	v_lshlrev_b32_e32 v46, 16, v46                             // 0000004824BC: 305C5C90
	v_bfe_u32 v62, v49, 4, 16                                  // 0000004824C0: D610003E 02410931
	v_sad_u8 v57, v57, 0, 0x6400                               // 0000004824C8: D6220039 03FD0139 00006400
	v_pk_fma_f16 v56, v56, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000004824D4: CC0E0038 0BFC0D38 0000C931
	v_dot2acc_f32_f16 v28, v58, v1                             // 0000004824E0: 0438033A
	v_and_or_b32 v46, 0xffff, v61, v46                         // 0000004824E4: D657002E 04BA7AFF 0000FFFF
	.long 0xd72c003e                                           // 0000004824F0: D72C003E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v62, vcc_lo              // 0000004824F4: 02027CFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_2)                            // 0000004824FC: BF870002
	v_pk_fma_f16 v59, v46, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000482500: CC0E003B 0BFC0D2E 0000C931
	v_and_b32_e32 v49, 0xffff, v49                             // 00000048250C: 366262FF 0000FFFF
	ds_load_2addr_b32 v[46:47], v42 offset0:64 offset1:96      // 000000482514: D8DC6040 2E00002A
	v_sad_u8 v62, v62, 0, 0x6400                               // 00000048251C: D622003E 03FD013E 00006400
	v_dot2acc_f32_f16 v28, v59, v2                             // 000000482528: 0438053B
	.long 0xd72c0031                                           // 00000048252C: D72C0031
	v_cndmask_b32_e32 v1, 0x83dcd12d, v49, vcc_lo              // 000000482530: 020262FF 83DCD12D
	v_lshlrev_b32_e32 v57, 16, v57                             // 000000482538: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000048253C: BF870191
	v_and_or_b32 v54, 0xffff, v48, v57                         // 000000482540: D6570036 04E660FF 0000FFFF
	v_sad_u8 v49, v49, 0, 0x6400                               // 00000048254C: D6220031 03FD0131 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000482558: BF870112
	v_pk_fma_f16 v54, v54, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000048255C: CC0E0036 0BFC0D36 0000C931
	v_lshlrev_b32_e32 v49, 16, v49                             // 000000482568: 30626290
	s_waitcnt lgkmcnt(0)                                       // 00000048256C: BF89FC07
	v_bfe_u32 v57, v46, 4, 16                                  // 000000482570: D6100039 0241092E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000482578: BF870112
	v_and_or_b32 v49, 0xffff, v62, v49                         // 00000048257C: D6570031 04C67CFF 0000FFFF
	.long 0xd72c0039                                           // 000000482588: D72C0039
	v_cndmask_b32_e32 v1, 0x83dcd12d, v57, vcc_lo              // 00000048258C: 020272FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000482594: BF870092
	v_pk_fma_f16 v49, v49, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000482598: CC0E0031 0BFC0D31 0000C931
	v_dot2acc_f32_f16 v15, v49, v2                             // 0000004825A4: 041E0531
	v_dot2acc_f32_f16 v17, v49, v6                             // 0000004825A8: 04220D31
	.long 0xd73d0030                                           // 0000004825AC: D73D0030
	v_cndmask_b32_e32 v1, v43, v51, vcc_lo                     // 0000004825B0: 0202672B
	v_pk_fma_f16 v49, v60, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000004825B4: CC0E0031 0BFC0D3C 0000C931
	v_bfe_u32 v52, v46, 12, 16                                 // 0000004825C0: D6100034 0241192E
	v_dot2acc_f32_f16 v15, v50, v3                             // 0000004825C8: 041E0732
	v_dot2acc_f32_f16 v17, v50, v7                             // 0000004825CC: 04220F32
	v_bfe_u32 v50, v48, 12, 16                                 // 0000004825D0: D6100032 02411930
	v_dual_dot2acc_f32_f16 v28, v49, v3 :: v_dual_and_b32 v51, 0xffff, v48// 0000004825D8: CB240731 1C3260FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000004825E4: BF870224
	v_dot2acc_f32_f16 v15, v56, v4                             // 0000004825E8: 041E0938
	.long 0xd72c0034                                           // 0000004825EC: D72C0034
	v_cndmask_b32_e32 v1, 0x83dcd12d, v52, vcc_lo              // 0000004825F0: 020268FF 83DCD12D
	.long 0xd72c0032                                           // 0000004825F8: D72C0032
	v_cndmask_b32_e32 v1, 0x83dcd12d, v50, vcc_lo              // 0000004825FC: 020264FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000482604: BF870224
	v_dot2acc_f32_f16 v28, v54, v4                             // 000000482608: 04380936
	.long 0xd72c0033                                           // 00000048260C: D72C0033
	v_cndmask_b32_e32 v1, 0x83dcd12d, v51, vcc_lo              // 000000482610: 020266FF 83DCD12D
	v_sad_u8 v52, v52, 0, 0x6400                               // 000000482618: D6220034 03FD0134 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000482624: BF870224
	v_sad_u8 v50, v50, 0, 0x6400                               // 000000482628: D6220032 03FD0132 00006400
	v_dot2acc_f32_f16 v29, v58, v5                             // 000000482634: 043A0B3A
	v_sad_u8 v51, v51, 0, 0x6400                               // 000000482638: D6220033 03FD0133 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000482644: BF870193
	v_and_b32_e32 v50, 0xffff, v50                             // 000000482648: 366464FF 0000FFFF
	v_dot2acc_f32_f16 v29, v59, v6                             // 000000482650: 043A0D3B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000482654: BF870113
	v_lshlrev_b32_e32 v51, 16, v51                             // 000000482658: 30666690
	v_dot2acc_f32_f16 v29, v49, v7                             // 00000048265C: 043A0F31
	v_bfe_u32 v49, v48, 8, 16                                  // 000000482660: D6100031 02411130
	v_bfe_u32 v48, v48, 4, 16                                  // 000000482668: D6100030 02410930
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000482670: BF870112
	.long 0xd72c0031                                           // 000000482674: D72C0031
	v_cndmask_b32_e32 v1, 0x83dcd12d, v49, vcc_lo              // 000000482678: 020262FF 83DCD12D
	.long 0xd72c0030                                           // 000000482680: D72C0030
	v_cndmask_b32_e32 v1, 0x83dcd12d, v48, vcc_lo              // 000000482684: 020260FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000048268C: BF870112
	v_sad_u8 v49, v49, 0, 0x6400                               // 000000482690: D6220031 03FD0131 00006400
	v_sad_u8 v48, v48, 0, 0x6400                               // 00000048269C: D6220030 03FD0130 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000004826A8: BF870112
	v_lshl_or_b32 v50, v49, 16, v50                            // 0000004826AC: D6560032 04C92131
	v_and_or_b32 v51, 0xffff, v48, v51                         // 0000004826B4: D6570033 04CE60FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000004826C0: BF870112
	v_pk_fma_f16 v50, v50, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000004826C4: CC0E0032 0BFC0D32 0000C931
	v_pk_fma_f16 v51, v51, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000004826D0: CC0E0033 0BFC0D33 0000C931
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000004826DC: BF8701B2
	v_dual_dot2acc_f32_f16 v26, v50, v1 :: v_dual_dot2acc_f32_f16 v17, v56, v8// 0000004826E0: CB180332 1A101138
	v_bfe_u32 v56, v46, 8, 16                                  // 0000004826E8: D6100038 0241112E
	v_dual_dot2acc_f32_f16 v25, v50, v5 :: v_dual_and_b32 v46, 0xffff, v46// 0000004826F0: CB240B32 192E5CFF 0000FFFF
	v_dot2acc_f32_f16 v26, v51, v2                             // 0000004826FC: 04340533
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000482700: BF870223
	.long 0xd72c003a                                           // 000000482704: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v56, vcc_lo              // 000000482708: 020270FF 83DCD12D
	v_mov_b32_e32 v56, v53                                     // 000000482710: 7E700335
	.long 0xd72c002e                                           // 000000482714: D72C002E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v46, vcc_lo              // 000000482718: 02025CFF 83DCD12D
	v_sad_u8 v53, v57, 0, 0x6400                               // 000000482720: D6220035 03FD0139 00006400
	v_bfe_u32 v57, v47, 4, 16                                  // 00000048272C: D6100039 0241092F
	s_delay_alu instid0(VALU_DEP_4)                            // 000000482734: BF870004
	.long 0xd73d0030                                           // 000000482738: D73D0030
	v_cndmask_b32_e32 v1, v43, v55, vcc_lo                     // 00000048273C: 02026F2B
	v_and_b32_e32 v49, 0xffff, v52                             // 000000482740: 366268FF 0000FFFF
	v_sad_u8 v52, v58, 0, 0x6400                               // 000000482748: D6220034 03FD013A 00006400
	v_and_b32_e32 v58, 0xffff, v47                             // 000000482754: 36745EFF 0000FFFF
	v_sad_u8 v46, v46, 0, 0x6400                               // 00000048275C: D622002E 03FD012E 00006400
	.long 0xd72c0039                                           // 000000482768: D72C0039
	v_cndmask_b32_e32 v1, 0x83dcd12d, v57, vcc_lo              // 00000048276C: 020272FF 83DCD12D
	v_bfe_u32 v55, v48, 12, 16                                 // 000000482774: D6100037 02411930
	v_lshl_or_b32 v49, v52, 16, v49                            // 00000048277C: D6560031 04C52134
	.long 0xd72c003a                                           // 000000482784: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 000000482788: 020274FF 83DCD12D
	v_lshlrev_b32_e32 v46, 16, v46                             // 000000482790: 305C5C90
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000482794: BF870214
	.long 0xd72c0034                                           // 000000482798: D72C0034
	v_cndmask_b32_e32 v1, 0x83dcd12d, v55, vcc_lo              // 00000048279C: 02026EFF 83DCD12D
	v_pk_fma_f16 v55, v49, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000004827A4: CC0E0037 0BFC0D31 0000C931
	v_and_b32_e32 v49, 0xffff, v48                             // 0000004827B0: 366260FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4)                            // 0000004827B8: BF870004
	v_and_or_b32 v46, 0xffff, v53, v46                         // 0000004827BC: D657002E 04BA6AFF 0000FFFF
	v_bfe_u32 v53, v48, 8, 16                                  // 0000004827C8: D6100035 02411130
	v_bfe_u32 v48, v48, 4, 16                                  // 0000004827D0: D6100030 02410930
	v_dot2acc_f32_f16 v26, v55, v3                             // 0000004827D8: 04340737
	.long 0xd72c0031                                           // 0000004827DC: D72C0031
	v_cndmask_b32_e32 v1, 0x83dcd12d, v49, vcc_lo              // 0000004827E0: 020262FF 83DCD12D
	v_pk_fma_f16 v56, v46, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000004827E8: CC0E0038 0BFC0D2E 0000C931
	.long 0xd72c002e                                           // 0000004827F4: D72C002E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v53, vcc_lo              // 0000004827F8: 02026AFF 83DCD12D
	v_sad_u8 v50, v52, 0, 0x6400                               // 000000482800: D6220032 03FD0134 00006400
	v_bfe_u32 v52, v47, 12, 16                                 // 00000048280C: D6100034 0241192F
	v_bfe_u32 v53, v47, 8, 16                                  // 000000482814: D6100035 0241112F
	.long 0xd72c0030                                           // 00000048281C: D72C0030
	v_cndmask_b32_e32 v1, 0x83dcd12d, v48, vcc_lo              // 000000482820: 020260FF 83DCD12D
	v_sad_u8 v57, v57, 0, 0x6400                               // 000000482828: D6220039 03FD0139 00006400
	v_and_b32_e32 v50, 0xffff, v50                             // 000000482834: 366464FF 0000FFFF
	.long 0xd72c0034                                           // 00000048283C: D72C0034
	v_cndmask_b32_e32 v1, 0x83dcd12d, v52, vcc_lo              // 000000482840: 020268FF 83DCD12D
	v_sad_u8 v46, v46, 0, 0x6400                               // 000000482848: D622002E 03FD012E 00006400
	v_sad_u8 v49, v49, 0, 0x6400                               // 000000482854: D6220031 03FD0131 00006400
	.long 0xd72c0035                                           // 000000482860: D72C0035
	v_cndmask_b32_e32 v1, 0x83dcd12d, v53, vcc_lo              // 000000482864: 02026AFF 83DCD12D
	v_dot2acc_f32_f16 v26, v56, v4                             // 00000048286C: 04340938
	v_sad_u8 v48, v48, 0, 0x6400                               // 000000482870: D6220030 03FD0130 00006400
	v_lshl_or_b32 v59, v46, 16, v50                            // 00000048287C: D656003B 04C9212E
	ds_load_2addr_b32 v[46:47], v45 offset0:128 offset1:160    // 000000482884: D8DCA080 2E00002D
	v_sad_u8 v52, v52, 0, 0x6400                               // 00000048288C: D6220034 03FD0134 00006400
	v_dot2acc_f32_f16 v29, v54, v8                             // 000000482898: 043A1136
	v_sad_u8 v53, v53, 0, 0x6400                               // 00000048289C: D6220035 03FD0135 00006400
	s_delay_alu instid0(VALU_DEP_3)                            // 0000004828A8: BF870003
	v_and_b32_e32 v52, 0xffff, v52                             // 0000004828AC: 366868FF 0000FFFF
	v_dual_dot2acc_f32_f16 v25, v51, v6 :: v_dual_lshlrev_b32 v60, 16, v49// 0000004828B4: CB220D33 193C6290
	ds_load_2addr_b32 v[49:50], v44 offset0:128 offset1:160    // 0000004828BC: D8DCA080 3100002C
	v_sad_u8 v51, v58, 0, 0x6400                               // 0000004828C4: D6220033 03FD013A 00006400
	v_lshl_or_b32 v52, v53, 16, v52                            // 0000004828D0: D6560034 04D12135
	v_and_or_b32 v48, 0xffff, v48, v60                         // 0000004828D8: D6570030 04F260FF 0000FFFF
	v_pk_fma_f16 v58, v59, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000004828E4: CC0E003A 0BFC0D3B 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004828F0: BF870214
	v_lshlrev_b32_e32 v59, 16, v51                             // 0000004828F4: 30766690
	v_pk_fma_f16 v60, v52, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000004828F8: CC0E003C 0BFC0D34 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000482904: BF870214
	v_pk_fma_f16 v53, v48, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000482908: CC0E0035 0BFC0D30 0000C931
	v_dot2acc_f32_f16 v30, v58, v1                             // 000000482914: 043C033A
	ds_load_2addr_b32 v[51:52], v42 offset0:128 offset1:160    // 000000482918: D8DCA080 3300002A
	s_waitcnt lgkmcnt(2)                                       // 000000482920: BF89FC27
	v_mov_b32_e32 v48, v46                                     // 000000482924: 7E60032E
	v_and_or_b32 v46, 0xffff, v57, v59                         // 000000482928: D657002E 04EE72FF 0000FFFF
	v_dual_dot2acc_f32_f16 v31, v58, v5 :: v_dual_dot2acc_f32_f16 v30, v53, v2// 000000482934: CB180B3A 1F1E0535
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000048293C: BF8700C1
	v_dual_dot2acc_f32_f16 v31, v53, v6 :: v_dual_dot2acc_f32_f16 v30, v60, v3// 000000482940: CB180D35 1F1E073C
	s_waitcnt lgkmcnt(1)                                       // 000000482948: BF89FC17
	.long 0xd73d0030                                           // 00000048294C: D73D0030
	v_cndmask_b32_e32 v1, v43, v48, vcc_lo                     // 000000482950: 0202612B
	v_pk_fma_f16 v49, v46, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000482954: CC0E0031 0BFC0D2E 0000C931
	v_dual_dot2acc_f32_f16 v25, v55, v7 :: v_dual_dot2acc_f32_f16 v30, v49, v4// 000000482960: CB180F37 191E0931
	s_delay_alu instid0(VALU_DEP_3)                            // 000000482968: BF870003
	v_bfe_u32 v46, v48, 12, 16                                 // 00000048296C: D610002E 02411930
	v_bfe_u32 v55, v48, 8, 16                                  // 000000482974: D6100037 02411130
	v_and_b32_e32 v54, 0xffff, v48                             // 00000048297C: 366C60FF 0000FFFF
	v_bfe_u32 v48, v48, 4, 16                                  // 000000482984: D6100030 02410930
	s_waitcnt lgkmcnt(0)                                       // 00000048298C: BF89FC07
	v_bfe_u32 v53, v51, 12, 16                                 // 000000482990: D6100035 02411933
	.long 0xd72c002e                                           // 000000482998: D72C002E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v46, vcc_lo              // 00000048299C: 02025CFF 83DCD12D
	.long 0xd72c0037                                           // 0000004829A4: D72C0037
	v_cndmask_b32_e32 v1, 0x83dcd12d, v55, vcc_lo              // 0000004829A8: 02026EFF 83DCD12D
	.long 0xd72c0036                                           // 0000004829B0: D72C0036
	v_cndmask_b32_e32 v1, 0x83dcd12d, v54, vcc_lo              // 0000004829B4: 02026CFF 83DCD12D
	.long 0xd72c0030                                           // 0000004829BC: D72C0030
	v_cndmask_b32_e32 v1, 0x83dcd12d, v48, vcc_lo              // 0000004829C0: 020260FF 83DCD12D
	v_bfe_u32 v57, v51, 4, 16                                  // 0000004829C8: D6100039 02410933
	.long 0xd72c0035                                           // 0000004829D0: D72C0035
	v_cndmask_b32_e32 v1, 0x83dcd12d, v53, vcc_lo              // 0000004829D4: 02026AFF 83DCD12D
	v_sad_u8 v46, v46, 0, 0x6400                               // 0000004829DC: D622002E 03FD012E 00006400
	v_dot2acc_f32_f16 v25, v56, v8                             // 0000004829E8: 04321138
	v_sad_u8 v55, v55, 0, 0x6400                               // 0000004829EC: D6220037 03FD0137 00006400
	v_sad_u8 v58, v48, 0, 0x6400                               // 0000004829F8: D622003A 03FD0130 00006400
	v_mov_b32_e32 v48, v50                                     // 000000482A04: 7E600332
	v_and_b32_e32 v46, 0xffff, v46                             // 000000482A08: 365C5CFF 0000FFFF
	v_bfe_u32 v56, v51, 8, 16                                  // 000000482A10: D6100038 02411133
	v_sad_u8 v54, v54, 0, 0x6400                               // 000000482A18: D6220036 03FD0136 00006400
	.long 0xd72c0039                                           // 000000482A24: D72C0039
	v_cndmask_b32_e32 v1, 0x83dcd12d, v57, vcc_lo              // 000000482A28: 020272FF 83DCD12D
	v_sad_u8 v53, v53, 0, 0x6400                               // 000000482A30: D6220035 03FD0135 00006400
	v_lshl_or_b32 v55, v55, 16, v46                            // 000000482A3C: D6560037 04B92137
	.long 0xd73d002e                                           // 000000482A44: D73D002E
	v_cndmask_b32_e32 v1, v43, v47, vcc_lo                     // 000000482A48: 02025F2B
	.long 0xd72c0038                                           // 000000482A4C: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v56, vcc_lo              // 000000482A50: 020270FF 83DCD12D
	v_dual_dot2acc_f32_f16 v31, v60, v7 :: v_dual_and_b32 v60, 0xffff, v52// 000000482A58: CB240F3C 1F3C68FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000482A64: BF870244
	v_pk_fma_f16 v47, v55, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000482A68: CC0E002F 0BFC0D37 0000C931
	v_and_b32_e32 v51, 0xffff, v51                             // 000000482A74: 366666FF 0000FFFF
	v_lshlrev_b32_e32 v54, 16, v54                             // 000000482A7C: 306C6C90
	v_bfe_u32 v55, v52, 12, 16                                 // 000000482A80: D6100037 02411934
	v_dot2acc_f32_f16 v32, v47, v5                             // 000000482A88: 04400B2F
	s_delay_alu instid0(VALU_DEP_4)                            // 000000482A8C: BF870004
	.long 0xd72c0033                                           // 000000482A90: D72C0033
	v_cndmask_b32_e32 v1, 0x83dcd12d, v51, vcc_lo              // 000000482A94: 020266FF 83DCD12D
	v_dot2acc_f32_f16 v23, v47, v1                             // 000000482A9C: 042E032F
	v_and_or_b32 v50, 0xffff, v58, v54                         // 000000482AA0: D6570032 04DA74FF 0000FFFF
	v_sad_u8 v54, v56, 0, 0x6400                               // 000000482AAC: D6220036 03FD0138 00006400
	v_bfe_u32 v56, v52, 8, 16                                  // 000000482AB8: D6100038 02411134
	v_bfe_u32 v52, v52, 4, 16                                  // 000000482AC0: D6100034 02410934
	.long 0xd72c0037                                           // 000000482AC8: D72C0037
	v_cndmask_b32_e32 v1, 0x83dcd12d, v55, vcc_lo              // 000000482ACC: 02026EFF 83DCD12D
	v_pk_fma_f16 v48, v50, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000482AD4: CC0E0030 0BFC0D32 0000C931
	v_sad_u8 v51, v51, 0, 0x6400                               // 000000482AE0: D6220033 03FD0133 00006400
	v_and_b32_e32 v53, 0xffff, v53                             // 000000482AEC: 366A6AFF 0000FFFF
	v_sad_u8 v50, v57, 0, 0x6400                               // 000000482AF4: D6220032 03FD0139 00006400
	.long 0xd72c0038                                           // 000000482B00: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v56, vcc_lo              // 000000482B04: 020270FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000482B0C: BF870214
	v_dual_dot2acc_f32_f16 v32, v48, v6 :: v_dual_lshlrev_b32 v51, 16, v51// 000000482B10: CB220D30 20326690
	v_lshl_or_b32 v53, v54, 16, v53                            // 000000482B18: D6560035 04D52136
	v_bfe_u32 v54, v46, 12, 16                                 // 000000482B20: D6100036 0241192E
	v_dot2acc_f32_f16 v23, v48, v2                             // 000000482B28: 042E0530
	.long 0xd72c0034                                           // 000000482B2C: D72C0034
	v_cndmask_b32_e32 v1, 0x83dcd12d, v52, vcc_lo              // 000000482B30: 020268FF 83DCD12D
	v_and_or_b32 v50, 0xffff, v50, v51                         // 000000482B38: D6570032 04CE64FF 0000FFFF
	v_sad_u8 v55, v55, 0, 0x6400                               // 000000482B44: D6220037 03FD0137 00006400
	.long 0xd72c0033                                           // 000000482B50: D72C0033
	v_cndmask_b32_e32 v1, 0x83dcd12d, v54, vcc_lo              // 000000482B54: 02026CFF 83DCD12D
	v_pk_fma_f16 v53, v53, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000482B5C: CC0E0035 0BFC0D35 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000482B68: BF870224
	v_pk_fma_f16 v54, v50, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000482B6C: CC0E0036 0BFC0D32 0000C931
	v_and_b32_e32 v50, 0xffff, v46                             // 000000482B78: 36645CFF 0000FFFF
	v_sad_u8 v47, v51, 0, 0x6400                               // 000000482B80: D622002F 03FD0133 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000482B8C: BF8701A2
	.long 0xd72c0032                                           // 000000482B90: D72C0032
	v_cndmask_b32_e32 v1, 0x83dcd12d, v50, vcc_lo              // 000000482B94: 020264FF 83DCD12D
	v_bfe_u32 v51, v46, 4, 16                                  // 000000482B9C: D6100033 0241092E
	v_and_b32_e32 v57, 0xffff, v47                             // 000000482BA4: 36725EFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000482BAC: BF870212
	.long 0xd72c0033                                           // 000000482BB0: D72C0033
	v_cndmask_b32_e32 v1, 0x83dcd12d, v51, vcc_lo              // 000000482BB4: 020266FF 83DCD12D
	v_sad_u8 v59, v50, 0, 0x6400                               // 000000482BBC: D622003B 03FD0132 00006400
	v_dot2acc_f32_f16 v31, v49, v8                             // 000000482BC8: 043E1131
	v_bfe_u32 v49, v46, 8, 16                                  // 000000482BCC: D6100031 0241112E
	ds_load_2addr_b32 v[46:47], v45 offset0:192 offset1:224    // 000000482BD4: D8DCE0C0 2E00002D
	v_sad_u8 v51, v51, 0, 0x6400                               // 000000482BDC: D6220033 03FD0133 00006400
	.long 0xd72c0031                                           // 000000482BE8: D72C0031
	v_cndmask_b32_e32 v1, 0x83dcd12d, v49, vcc_lo              // 000000482BEC: 020262FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_1)                            // 000000482BF4: BF870001
	v_sad_u8 v58, v49, 0, 0x6400                               // 000000482BF8: D622003A 03FD0131 00006400
	ds_load_2addr_b32 v[49:50], v44 offset0:192 offset1:224    // 000000482C04: D8DCE0C0 3100002C
	v_lshl_or_b32 v57, v58, 16, v57                            // 000000482C0C: D6560039 04E5213A
	v_lshlrev_b32_e32 v58, 16, v59                             // 000000482C14: 30747690
	.long 0xd72c003b                                           // 000000482C18: D72C003B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v60, vcc_lo              // 000000482C1C: 020278FF 83DCD12D
	s_waitcnt lgkmcnt(1)                                       // 000000482C24: BF89FC17
	v_mov_b32_e32 v48, v46                                     // 000000482C28: 7E60032E
	v_sad_u8 v46, v56, 0, 0x6400                               // 000000482C2C: D622002E 03FD0138 00006400
	v_pk_fma_f16 v57, v57, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000482C38: CC0E0039 0BFC0D39 0000C931
	v_and_or_b32 v51, 0xffff, v51, v58                         // 000000482C44: D6570033 04EA66FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000482C50: BF8701A2
	v_dual_dot2acc_f32_f16 v34, v57, v5 :: v_dual_and_b32 v55, 0xffff, v55// 000000482C54: CB240B39 22366EFF 0000FFFF
	v_sad_u8 v58, v59, 0, 0x6400                               // 000000482C60: D622003A 03FD013B 00006400
	v_pk_fma_f16 v56, v51, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000482C6C: CC0E0038 0BFC0D33 0000C931
	v_sad_u8 v59, v52, 0, 0x6400                               // 000000482C78: D622003B 03FD0134 00006400
	ds_load_2addr_b32 v[51:52], v42 offset0:192 offset1:224    // 000000482C84: D8DCE0C0 3300002A
	v_dual_dot2acc_f32_f16 v23, v53, v3 :: v_dual_lshlrev_b32 v58, 16, v58// 000000482C8C: CB220735 173A7490
	s_waitcnt lgkmcnt(1)                                       // 000000482C94: BF89FC17
	.long 0xd73d0030                                           // 000000482C98: D73D0030
	v_cndmask_b32_e32 v1, v43, v48, vcc_lo                     // 000000482C9C: 0202612B
	v_dot2acc_f32_f16 v32, v53, v7                             // 000000482CA0: 04400F35
	v_lshl_or_b32 v46, v46, 16, v55                            // 000000482CA4: D656002E 04DD212E
	v_dual_dot2acc_f32_f16 v33, v57, v1 :: v_dual_dot2acc_f32_f16 v34, v56, v6// 000000482CAC: CB180339 21220D38
	v_dot2acc_f32_f16 v23, v54, v4                             // 000000482CB4: 042E0936
	v_bfe_u32 v53, v48, 12, 16                                 // 000000482CB8: D6100035 02411930
	v_bfe_u32 v55, v48, 8, 16                                  // 000000482CC0: D6100037 02411130
	v_pk_fma_f16 v46, v46, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000482CC8: CC0E002E 0BFC0D2E 0000C931
	v_dual_dot2acc_f32_f16 v32, v54, v8 :: v_dual_dot2acc_f32_f16 v33, v56, v2// 000000482CD4: CB181136 20200538
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000482CDC: BF870214
	.long 0xd72c0035                                           // 000000482CE0: D72C0035
	v_cndmask_b32_e32 v1, 0x83dcd12d, v53, vcc_lo              // 000000482CE4: 02026AFF 83DCD12D
	.long 0xd72c0036                                           // 000000482CEC: D72C0036
	v_cndmask_b32_e32 v1, 0x83dcd12d, v55, vcc_lo              // 000000482CF0: 02026EFF 83DCD12D
	v_and_or_b32 v49, 0xffff, v59, v58                         // 000000482CF8: D6570031 04EA76FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4)                            // 000000482D04: BF870004
	v_dot2acc_f32_f16 v33, v46, v3                             // 000000482D08: 0442072E
	s_waitcnt lgkmcnt(0)                                       // 000000482D0C: BF89FC07
	v_bfe_u32 v55, v51, 12, 16                                 // 000000482D10: D6100037 02411933
	v_and_b32_e32 v56, 0xffff, v51                             // 000000482D18: 367066FF 0000FFFF
	v_sad_u8 v53, v53, 0, 0x6400                               // 000000482D20: D6220035 03FD0135 00006400
	v_dot2acc_f32_f16 v34, v46, v7                             // 000000482D2C: 04440F2E
	v_and_b32_e32 v46, 0xffff, v48                             // 000000482D30: 365C60FF 0000FFFF
	v_bfe_u32 v48, v48, 4, 16                                  // 000000482D38: D6100030 02410930
	.long 0xd72c0037                                           // 000000482D40: D72C0037
	v_cndmask_b32_e32 v1, 0x83dcd12d, v55, vcc_lo              // 000000482D44: 02026EFF 83DCD12D
	v_and_b32_e32 v53, 0xffff, v53                             // 000000482D4C: 366A6AFF 0000FFFF
	v_sad_u8 v54, v54, 0, 0x6400                               // 000000482D54: D6220036 03FD0136 00006400
	.long 0xd72c002e                                           // 000000482D60: D72C002E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v46, vcc_lo              // 000000482D64: 02025CFF 83DCD12D
	v_bfe_u32 v57, v51, 8, 16                                  // 000000482D6C: D6100039 02411133
	.long 0xd72c0030                                           // 000000482D74: D72C0030
	v_cndmask_b32_e32 v1, 0x83dcd12d, v48, vcc_lo              // 000000482D78: 020260FF 83DCD12D
	v_bfe_u32 v51, v51, 4, 16                                  // 000000482D80: D6100033 02410933
	v_lshl_or_b32 v53, v54, 16, v53                            // 000000482D88: D6560035 04D52136
	.long 0xd72c0036                                           // 000000482D90: D72C0036
	v_cndmask_b32_e32 v1, 0x83dcd12d, v56, vcc_lo              // 000000482D94: 020270FF 83DCD12D
	v_pk_fma_f16 v49, v49, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000482D9C: CC0E0031 0BFC0D31 0000C931
	v_sad_u8 v55, v55, 0, 0x6400                               // 000000482DA8: D6220037 03FD0137 00006400
	v_sad_u8 v46, v46, 0, 0x6400                               // 000000482DB4: D622002E 03FD012E 00006400
	.long 0xd72c0038                                           // 000000482DC0: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v57, vcc_lo              // 000000482DC4: 020272FF 83DCD12D
	.long 0xd72c0033                                           // 000000482DCC: D72C0033
	v_cndmask_b32_e32 v1, 0x83dcd12d, v51, vcc_lo              // 000000482DD0: 020266FF 83DCD12D
	v_dot2acc_f32_f16 v33, v49, v4                             // 000000482DD8: 04420931
	v_sad_u8 v57, v48, 0, 0x6400                               // 000000482DDC: D6220039 03FD0130 00006400
	v_lshlrev_b32_e32 v46, 16, v46                             // 000000482DE8: 305C5C90
	v_dual_mov_b32 v48, v50 :: v_dual_and_b32 v55, 0xffff, v55 // 000000482DEC: CA240132 30366EFF 0000FFFF
	v_sad_u8 v54, v54, 0, 0x6400                               // 000000482DF8: D6220036 03FD0136 00006400
	v_sad_u8 v50, v56, 0, 0x6400                               // 000000482E04: D6220032 03FD0138 00006400
	s_delay_alu instid0(VALU_DEP_4)                            // 000000482E10: BF870004
	v_and_or_b32 v56, 0xffff, v57, v46                         // 000000482E14: D6570038 04BA72FF 0000FFFF
	v_pk_fma_f16 v53, v53, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000482E20: CC0E0035 0BFC0D35 0000C931
	.long 0xd73d002e                                           // 000000482E2C: D73D002E
	v_cndmask_b32_e32 v1, v43, v47, vcc_lo                     // 000000482E30: 02025F2B
	v_sad_u8 v51, v51, 0, 0x6400                               // 000000482E34: D6220033 03FD0133 00006400
	v_lshlrev_b32_e32 v54, 16, v54                             // 000000482E40: 306C6C90
	v_dot2acc_f32_f16 v34, v49, v8                             // 000000482E44: 04441131
	v_lshl_or_b32 v47, v50, 16, v55                            // 000000482E48: D656002F 04DD2132
	v_dot2acc_f32_f16 v37, v53, v5                             // 000000482E50: 044A0B35
	v_bfe_u32 v50, v46, 12, 16                                 // 000000482E54: D6100032 0241192E
	v_and_or_b32 v48, 0xffff, v51, v54                         // 000000482E5C: D6570030 04DA66FF 0000FFFF
	v_and_b32_e32 v51, 0xffff, v46                             // 000000482E68: 36665CFF 0000FFFF
	v_bfe_u32 v54, v46, 8, 16                                  // 000000482E70: D6100036 0241112E
	v_pk_fma_f16 v49, v56, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000482E78: CC0E0031 0BFC0D38 0000C931
	.long 0xd72c0032                                           // 000000482E84: D72C0032
	v_cndmask_b32_e32 v1, 0x83dcd12d, v50, vcc_lo              // 000000482E88: 020264FF 83DCD12D
	v_bfe_u32 v46, v46, 4, 16                                  // 000000482E90: D610002E 0241092E
	.long 0xd72c0033                                           // 000000482E98: D72C0033
	v_cndmask_b32_e32 v1, 0x83dcd12d, v51, vcc_lo              // 000000482E9C: 020266FF 83DCD12D
	v_bfe_u32 v55, v52, 12, 16                                 // 000000482EA4: D6100037 02411934
	.long 0xd72c0036                                           // 000000482EAC: D72C0036
	v_cndmask_b32_e32 v1, 0x83dcd12d, v54, vcc_lo              // 000000482EB0: 02026CFF 83DCD12D
	v_pk_fma_f16 v47, v47, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000482EB8: CC0E002F 0BFC0D2F 0000C931
	v_bfe_u32 v56, v52, 8, 16                                  // 000000482EC4: D6100038 02411134
	v_bfe_u32 v57, v52, 4, 16                                  // 000000482ECC: D6100039 02410934
	v_sad_u8 v50, v50, 0, 0x6400                               // 000000482ED4: D6220032 03FD0132 00006400
	v_dual_dot2acc_f32_f16 v37, v49, v6 :: v_dual_and_b32 v52, 0xffff, v52// 000000482EE0: CB240D31 253468FF 0000FFFF
	v_sad_u8 v51, v51, 0, 0x6400                               // 000000482EEC: D6220033 03FD0133 00006400
	v_dot2acc_f32_f16 v36, v53, v1                             // 000000482EF8: 04480335
	.long 0xd72c002e                                           // 000000482EFC: D72C002E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v46, vcc_lo              // 000000482F00: 02025CFF 83DCD12D
	.long 0xd72c0037                                           // 000000482F08: D72C0037
	v_cndmask_b32_e32 v1, 0x83dcd12d, v55, vcc_lo              // 000000482F0C: 02026EFF 83DCD12D
	v_pk_fma_f16 v48, v48, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000482F14: CC0E0030 0BFC0D30 0000C931
	v_sad_u8 v54, v54, 0, 0x6400                               // 000000482F20: D6220036 03FD0136 00006400
	v_dual_dot2acc_f32_f16 v36, v49, v2 :: v_dual_lshlrev_b32 v51, 16, v51// 000000482F2C: CB220531 24326690
	v_dual_dot2acc_f32_f16 v37, v47, v7 :: v_dual_and_b32 v50, 0xffff, v50// 000000482F34: CB240F2F 253264FF 0000FFFF
	.long 0xd72c0038                                           // 000000482F40: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v56, vcc_lo              // 000000482F44: 020270FF 83DCD12D
	v_sad_u8 v46, v46, 0, 0x6400                               // 000000482F4C: D622002E 03FD012E 00006400
	.long 0xd72c0034                                           // 000000482F58: D72C0034
	v_cndmask_b32_e32 v1, 0x83dcd12d, v52, vcc_lo              // 000000482F5C: 020268FF 83DCD12D
	v_sad_u8 v55, v55, 0, 0x6400                               // 000000482F64: D6220037 03FD0137 00006400
	v_dot2acc_f32_f16 v37, v48, v8                             // 000000482F70: 044A1130
	v_lshl_or_b32 v50, v54, 16, v50                            // 000000482F74: D6560032 04C92136
	v_and_or_b32 v46, 0xffff, v46, v51                         // 000000482F7C: D657002E 04CE5CFF 0000FFFF
	.long 0xd72c0033                                           // 000000482F88: D72C0033
	v_cndmask_b32_e32 v1, 0x83dcd12d, v57, vcc_lo              // 000000482F8C: 020272FF 83DCD12D
	v_and_b32_e32 v54, 0xffff, v55                             // 000000482F94: 366C6EFF 0000FFFF
	v_sad_u8 v55, v56, 0, 0x6400                               // 000000482F9C: D6220037 03FD0138 00006400
	v_pk_fma_f16 v50, v50, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000482FA8: CC0E0032 0BFC0D32 0000C931
	v_sad_u8 v52, v52, 0, 0x6400                               // 000000482FB4: D6220034 03FD0134 00006400
	v_pk_fma_f16 v46, v46, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000482FC0: CC0E002E 0BFC0D2E 0000C931
	v_dot2acc_f32_f16 v36, v47, v3                             // 000000482FCC: 0448072F
	v_lshl_or_b32 v53, v55, 16, v54                            // 000000482FD0: D6560035 04D92137
	v_dot2acc_f32_f16 v38, v50, v1                             // 000000482FD8: 044C0332
	v_dot2acc_f32_f16 v14, v50, v5                             // 000000482FDC: 041C0B32
	v_sad_u8 v51, v51, 0, 0x6400                               // 000000482FE0: D6220033 03FD0133 00006400
	v_lshlrev_b32_e32 v52, 16, v52                             // 000000482FEC: 30686890
	v_pk_fma_f16 v1, v53, s6, 0xc931 op_sel_hi:[1,0,0]         // 000000482FF0: CC0E0001 0BFC0D35 0000C931
	v_dot2acc_f32_f16 v38, v46, v2                             // 000000482FFC: 044C052E
	v_dot2acc_f32_f16 v14, v46, v6                             // 000000483000: 041C0D2E
	v_dot2acc_f32_f16 v36, v48, v4                             // 000000483004: 04480930
	v_and_or_b32 v5, 0xffff, v51, v52                          // 000000483008: D6570005 04D266FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000483014: BF870214
	v_dot2acc_f32_f16 v38, v1, v3                              // 000000483018: 044C0701
	v_dual_dot2acc_f32_f16 v14, v1, v7 :: v_dual_add_nc_u32 v1, v39, v40// 00000048301C: CB200F01 0E005127
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000483024: BF870113
	v_pk_fma_f16 v2, v5, s6, 0xc931 op_sel_hi:[1,0,0]          // 000000483028: CC0E0002 0BFC0D05 0000C931
	v_cmp_eq_u32_e32 vcc_lo, 1, v1                             // 000000483034: 7C940281
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000483038: BF870212
	v_dot2acc_f32_f16 v38, v2, v4                              // 00000048303C: 044C0902
	v_dot2acc_f32_f16 v14, v2, v8                              // 000000483040: 041C1102
	s_or_b32 s5, vcc_lo, s5                                    // 000000483044: 8C05056A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000483048: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s5                        // 00000048304C: 917E057E
	s_cbranch_execz 34                                         // 000000483050: BFA50022 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi2ELb0ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x19dc>
	s_mov_b32 s0, exec_lo                                      // 000000483054: BE80007E
	s_waitcnt vmcnt(6)                                         // 000000483058: BF891BF7
	ds_store_2addr_b32 v42, v18, v19 offset1:32                // 00000048305C: D8382000 0013122A
	s_waitcnt vmcnt(4)                                         // 000000483064: BF8913F7
	ds_store_2addr_b32 v42, v20, v21 offset0:64 offset1:96     // 000000483068: D8386040 0015142A
	s_waitcnt vmcnt(2)                                         // 000000483070: BF890BF7
	ds_store_2addr_b32 v42, v22, v24 offset0:128 offset1:160   // 000000483074: D838A080 0018162A
	s_waitcnt vmcnt(0)                                         // 00000048307C: BF8903F7
	ds_store_2addr_b32 v42, v27, v35 offset0:192 offset1:224   // 000000483080: D838E0C0 00231B2A
	.long 0xd4c1007e                                           // 000000483088: D4C1007E
	v_cndmask_b32_e32 v1, v40, v16, vcc_lo                     // 00000048308C: 02022128
	s_cbranch_execz 64602                                      // 000000483090: BFA5FC5A <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi2ELb0ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0xafc>
	s_clause 0x7                                               // 000000483094: BF850007
	global_load_b32 v18, v[9:10], off                          // 000000483098: DC520000 127C0009
	global_load_b32 v19, v[9:10], off offset:128               // 0000004830A0: DC520080 137C0009
	global_load_b32 v20, v[9:10], off offset:256               // 0000004830A8: DC520100 147C0009
	global_load_b32 v21, v[9:10], off offset:384               // 0000004830B0: DC520180 157C0009
	global_load_b32 v22, v[9:10], off offset:512               // 0000004830B8: DC520200 167C0009
	global_load_b32 v24, v[9:10], off offset:640               // 0000004830C0: DC520280 187C0009
	global_load_b32 v27, v[9:10], off offset:768               // 0000004830C8: DC520300 1B7C0009
	global_load_b32 v35, v[9:10], off offset:896               // 0000004830D0: DC520380 237C0009
	s_branch 64584                                             // 0000004830D8: BFA0FC48 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi2ELb0ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0xafc>
	s_or_b32 exec_lo, exec_lo, s5                              // 0000004830DC: 8C7E057E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000004830E0: BF870009
	s_or_b32 exec_lo, exec_lo, s1                              // 0000004830E4: 8C7E017E
	v_dual_mov_b32 v1, v15 :: v_dual_mov_b32 v2, v17           // 0000004830E8: CA10010F 01020111
	v_dual_mov_b32 v3, v28 :: v_dual_mov_b32 v6, v29           // 0000004830F0: CA10011C 0306011D
	v_dual_mov_b32 v4, v26 :: v_dual_mov_b32 v5, v25           // 0000004830F8: CA10011A 04040119
	v_dual_mov_b32 v8, v30 :: v_dual_mov_b32 v9, v31           // 000000483100: CA10011E 0808011F
	v_dual_mov_b32 v7, v23 :: v_dual_mov_b32 v10, v32          // 000000483108: CA100117 070A0120
	s_waitcnt vmcnt(6)                                         // 000000483110: BF891BF7
	v_dual_mov_b32 v16, v33 :: v_dual_mov_b32 v19, v36         // 000000483114: CA100121 10120124
	v_mov_b32_e32 v18, v34                                     // 00000048311C: 7E240322
	s_waitcnt vmcnt(4)                                         // 000000483120: BF8913F7
	v_dual_mov_b32 v20, v37 :: v_dual_mov_b32 v21, v38         // 000000483124: CA100125 14140126
	s_waitcnt vmcnt(3)                                         // 00000048312C: BF890FF7
	v_mov_b32_e32 v22, v14                                     // 000000483130: 7E2C030E
	s_mov_b32 s0, 0x76543210                                   // 000000483134: BE8000FF 76543210
	s_waitcnt vmcnt(0)                                         // 00000048313C: BF8903F7
	v_permlanex16_b32 v1, v1, s0, 0xfedcba98                   // 000000483140: D65C0001 03FC0101 FEDCBA98
	v_permlanex16_b32 v2, v2, s0, 0xfedcba98                   // 00000048314C: D65C0002 03FC0102 FEDCBA98
	v_permlanex16_b32 v3, v3, s0, 0xfedcba98                   // 000000483158: D65C0003 03FC0103 FEDCBA98
	v_permlanex16_b32 v6, v6, s0, 0xfedcba98                   // 000000483164: D65C0006 03FC0106 FEDCBA98
	v_permlanex16_b32 v4, v4, s0, 0xfedcba98                   // 000000483170: D65C0004 03FC0104 FEDCBA98
	v_permlanex16_b32 v5, v5, s0, 0xfedcba98                   // 00000048317C: D65C0005 03FC0105 FEDCBA98
	v_permlanex16_b32 v8, v8, s0, 0xfedcba98                   // 000000483188: D65C0008 03FC0108 FEDCBA98
	v_permlanex16_b32 v9, v9, s0, 0xfedcba98                   // 000000483194: D65C0009 03FC0109 FEDCBA98
	v_permlanex16_b32 v7, v7, s0, 0xfedcba98                   // 0000004831A0: D65C0007 03FC0107 FEDCBA98
	v_permlanex16_b32 v10, v10, s0, 0xfedcba98                 // 0000004831AC: D65C000A 03FC010A FEDCBA98
	v_permlanex16_b32 v16, v16, s0, 0xfedcba98                 // 0000004831B8: D65C0010 03FC0110 FEDCBA98
	v_permlanex16_b32 v18, v18, s0, 0xfedcba98                 // 0000004831C4: D65C0012 03FC0112 FEDCBA98
	v_permlanex16_b32 v19, v19, s0, 0xfedcba98                 // 0000004831D0: D65C0013 03FC0113 FEDCBA98
	v_permlanex16_b32 v20, v20, s0, 0xfedcba98                 // 0000004831DC: D65C0014 03FC0114 FEDCBA98
	v_permlanex16_b32 v21, v21, s0, 0xfedcba98                 // 0000004831E8: D65C0015 03FC0115 FEDCBA98
	v_permlanex16_b32 v22, v22, s0, 0xfedcba98                 // 0000004831F4: D65C0016 03FC0116 FEDCBA98
	.long 0xd44c0000                                           // 000000483200: D44C0000
	v_cndmask_b32_e32 v1, 16, v13, vcc_lo                      // 000000483204: 02021A90
	s_barrier                                                  // 000000483208: BFBD0000
	buffer_gl0_inv                                             // 00000048320C: E0AC0000 00000000
	s_and_saveexec_b32 s1, s0                                  // 000000483214: BE812000
	s_cbranch_execz 34                                         // 000000483218: BFA50022 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi2ELb0ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1ba4>
	v_dual_add_f32 v16, v33, v16 :: v_dual_add_f32 v3, v28, v3 // 00000048321C: C9082121 1002071C
	v_dual_add_f32 v10, v32, v10 :: v_dual_add_f32 v1, v15, v1 // 000000483224: C9081520 0A00030F
	v_lshl_or_b32 v12, v11, 10, v12                            // 00000048322C: D656000C 0431150B
	v_dual_add_f32 v6, v29, v6 :: v_dual_add_f32 v7, v23, v7   // 000000483234: C9080D1D 06060F17
	v_add_f32_e32 v2, v17, v2                                  // 00000048323C: 06040511
	v_dual_add_f32 v8, v30, v8 :: v_dual_add_f32 v5, v25, v5   // 000000483240: C908111E 08040B19
	v_add_f32_e32 v4, v26, v4                                  // 000000483248: 0608091A
	v_dual_add_f32 v18, v34, v18 :: v_dual_add_f32 v9, v31, v9 // 00000048324C: C9082522 1208131F
	v_dual_add_f32 v13, v14, v22 :: v_dual_add_f32 v20, v37, v20// 000000483254: C9082D0E 0D142925
	v_dual_add_f32 v14, v38, v21 :: v_dual_add_f32 v19, v36, v19// 00000048325C: C9082B26 0E122724
	ds_store_2addr_b32 v12, v1, v3 offset1:16                  // 000000483264: D8381000 0003010C
	ds_store_2addr_b32 v12, v2, v6 offset0:128 offset1:144     // 00000048326C: D8389080 0006020C
	ds_store_2addr_b32 v12, v4, v8 offset0:32 offset1:48       // 000000483274: D8383020 0008040C
	ds_store_2addr_b32 v12, v5, v9 offset0:160 offset1:176     // 00000048327C: D838B0A0 0009050C
	ds_store_2addr_b32 v12, v7, v16 offset0:64 offset1:80      // 000000483284: D8385040 0010070C
	ds_store_2addr_b32 v12, v10, v18 offset0:192 offset1:208   // 00000048328C: D838D0C0 00120A0C
	ds_store_2addr_b32 v12, v19, v14 offset0:96 offset1:112    // 000000483294: D8387060 000E130C
	ds_store_2addr_b32 v12, v20, v13 offset0:224 offset1:240   // 00000048329C: D838F0E0 000D140C
	s_or_b32 exec_lo, exec_lo, s1                              // 0000004832A4: 8C7E017E
	.long 0xd44c0001                                           // 0000004832A8: D44C0001
	v_cndmask_b32_e32 v1, 0x100, v0, vcc_lo                    // 0000004832AC: 020200FF 00000100
	s_waitcnt lgkmcnt(0)                                       // 0000004832B4: BF89FC07
	s_barrier                                                  // 0000004832B8: BFBD0000
	buffer_gl0_inv                                             // 0000004832BC: E0AC0000 00000000
	s_and_saveexec_b32 s5, s1                                  // 0000004832C4: BE852001
	s_cbranch_execnz 7                                         // 0000004832C8: BFA60007 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi2ELb0ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1be8>
	s_or_b32 exec_lo, exec_lo, s5                              // 0000004832CC: 8C7E057E
	s_cmp_lt_i32 s33, 2                                        // 0000004832D0: BF048221
	s_mov_b32 s5, -1                                           // 0000004832D4: BE8500C1
	s_cbranch_scc0 33                                          // 0000004832D8: BFA10021 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi2ELb0ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1c60>
	s_and_b32 vcc_lo, exec_lo, s5                              // 0000004832DC: 8B6A057E
	s_cbranch_vccnz 203                                        // 0000004832E0: BFA400CB <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi2ELb0ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1f10>
	s_endpgm                                                   // 0000004832E4: BFB00000
	v_lshlrev_b32_e32 v7, 2, v0                                // 0000004832E8: 300E0082
	ds_load_2addr_stride64_b32 v[1:2], v7 offset1:4            // 0000004832EC: D8E00400 01000007
	ds_load_2addr_stride64_b32 v[3:4], v7 offset0:8 offset1:12 // 0000004832F4: D8E00C08 03000007
	ds_load_2addr_stride64_b32 v[5:6], v7 offset0:16 offset1:20// 0000004832FC: D8E01410 05000007
	s_waitcnt lgkmcnt(2)                                       // 000000483304: BF89FC27
	v_add_f32_e32 v1, 0, v1                                    // 000000483308: 06020280
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000048330C: BF8700A1
	v_add_f32_e32 v1, v1, v2                                   // 000000483310: 06020501
	s_waitcnt lgkmcnt(1)                                       // 000000483314: BF89FC17
	v_add_f32_e32 v3, v1, v3                                   // 000000483318: 06060701
	ds_load_2addr_stride64_b32 v[1:2], v7 offset0:24 offset1:28// 00000048331C: D8E01C18 01000007
	v_add_f32_e32 v3, v3, v4                                   // 000000483324: 06060903
	s_waitcnt lgkmcnt(1)                                       // 000000483328: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000048332C: BF870091
	v_add_f32_e32 v3, v3, v5                                   // 000000483330: 06060B03
	v_add_f32_e32 v3, v3, v6                                   // 000000483334: 06060D03
	s_waitcnt lgkmcnt(0)                                       // 000000483338: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000048333C: BF870091
	v_add_f32_e32 v1, v3, v1                                   // 000000483340: 06020303
	v_add_f32_e32 v1, v1, v2                                   // 000000483344: 06020501
	ds_store_b32 v7, v1 offset:8192                            // 000000483348: D8342000 00000107
	s_or_b32 exec_lo, exec_lo, s5                              // 000000483350: 8C7E057E
	s_cmp_lt_i32 s33, 2                                        // 000000483354: BF048221
	s_mov_b32 s5, -1                                           // 000000483358: BE8500C1
	s_cbranch_scc1 65503                                       // 00000048335C: BFA2FFDF <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi2ELb0ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1bdc>
	s_waitcnt lgkmcnt(0)                                       // 000000483360: BF89FC07
	s_barrier                                                  // 000000483364: BFBD0000
	buffer_gl0_inv                                             // 000000483368: E0AC0000 00000000
	s_and_saveexec_b32 s5, s1                                  // 000000483370: BE852001
	s_cbranch_execz 41                                         // 000000483374: BFA50029 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi2ELb0ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1d1c>
	v_lshrrev_b32_e32 v1, 7, v0                                // 000000483378: 32020087
	s_ashr_i32 s6, s18, 31                                     // 00000048337C: 86069F12
	v_lshlrev_b32_e32 v4, 2, v0                                // 000000483380: 30080082
	s_delay_alu instid0(VALU_DEP_2)                            // 000000483384: BF870002
	v_lshl_or_b32 v1, s4, 1, v1                                // 000000483388: D6560001 04050204
	s_ashr_i32 s4, s4, 31                                      // 000000483390: 86049F04
	ds_load_b32 v4, v4 offset:8192                             // 000000483394: D8D82000 04000004
	s_mul_i32 s4, s4, s18                                      // 00000048339C: 96041204
	.long 0xd72c0003                                           // 0000004833A0: D72C0003
	v_cndmask_b32_e32 v0, v1, v6, vcc_lo                       // 0000004833A4: 02000D01
	v_mad_u64_u32 v[1:2], null, v1, s18, 0                     // 0000004833A8: D6FE7C01 02002501
	s_lshl_b32 s6, s2, 7                                       // 0000004833B0: 84068702
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000004833B4: BF870499
	s_ashr_i32 s7, s6, 31                                      // 0000004833B8: 86079F06
	s_lshl_b64 s[6:7], s[6:7], 2                               // 0000004833BC: 84868206
	v_add3_u32 v2, v2, v3, s4                                  // 0000004833C0: D6550002 00120702
	v_and_b32_e32 v3, 0x7f, v0                                 // 0000004833C8: 360600FF 0000007F
	s_add_u32 s4, s24, s6                                      // 0000004833D0: 80040618
	s_addc_u32 s6, s25, s7                                     // 0000004833D4: 82060719
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000004833D8: BF870112
	.long 0xd73c0001                                           // 0000004833DC: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 0000004833E0: 02020282
	v_lshlrev_b32_e32 v3, 2, v3                                // 0000004833E4: 30060682
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004833E8: BF870092
	.long 0xd7006a01                                           // 0000004833EC: D7006A01
	v_cndmask_b32_e32 v1, s4, v1, vcc_lo                       // 0000004833F0: 02020204
	v_add_co_ci_u32_e64 v2, null, s6, v2, vcc_lo               // 0000004833F4: D5207C02 01AA0406
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004833FC: BF870092
	.long 0xd7006a01                                           // 000000483400: D7006A01
	v_cndmask_b32_e32 v1, v1, v3, vcc_lo                       // 000000483404: 02020701
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 000000483408: D5207C02 01AA0480
	s_waitcnt lgkmcnt(0)                                       // 000000483410: BF89FC07
	global_store_b32 v[1:2], v4, off                           // 000000483414: DC6A0000 007C0401
	s_or_b32 exec_lo, exec_lo, s5                              // 00000048341C: 8C7E057E
	.long 0xd44a0004                                           // 000000483420: D44A0004
	v_cndmask_b32_e32 v1, 0, v0, vcc_lo                        // 000000483424: 02020080
	s_waitcnt_vscnt null, 0x0                                  // 000000483428: BC7C0000
	buffer_gl1_inv                                             // 00000048342C: E0B00000 00000000
	buffer_gl0_inv                                             // 000000483434: E0AC0000 00000000
	s_barrier                                                  // 00000048343C: BFBD0000
	buffer_gl0_inv                                             // 000000483440: E0AC0000 00000000
	s_and_saveexec_b32 s5, s4                                  // 000000483448: BE852004
	s_cbranch_execz 29                                         // 00000048344C: BFA5001D <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi2ELb0ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1dc4>
	s_mov_b32 s7, exec_lo                                      // 000000483450: BE87007E
	s_mov_b32 s6, exec_lo                                      // 000000483454: BE86007E
	.long 0xd71f0001                                           // 000000483458: D71F0001
	v_cndmask_b32_e32 v0, s7, v128, vcc_lo                     // 00000048345C: 02010007
	s_delay_alu instid0(VALU_DEP_1)                            // 000000483460: BF870001
	v_cmpx_eq_u32_e32 0, v1                                    // 000000483464: 7D940280
	s_cbranch_execz 9                                          // 000000483468: BFA50009 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi2ELb0ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1d90>
	s_lshl_b64 s[8:9], s[2:3], 2                               // 00000048346C: 84888202
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 000000483470: BF8704B9
	s_add_u32 s8, s26, s8                                      // 000000483474: 8008081A
	s_addc_u32 s9, s27, s9                                     // 000000483478: 8209091B
	s_bcnt1_i32_b32 s7, s7                                     // 00000048347C: BE871807
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v3, s7              // 000000483480: CA100080 02020007
	global_atomic_add_u32 v2, v2, v3, s[8:9] glc               // 000000483488: DCD64000 02080302
	s_or_b32 exec_lo, exec_lo, s6                              // 000000483490: 8C7E067E
	s_waitcnt vmcnt(0)                                         // 000000483494: BF8903F7
	v_readfirstlane_b32 s6, v2                                 // 000000483498: 7E0C0502
	s_delay_alu instid0(VALU_DEP_1)                            // 00000048349C: BF870001
	v_dual_mov_b32 v2, 0 :: v_dual_add_nc_u32 v1, s6, v1       // 0000004834A0: CA200080 02000206
	s_add_i32 s6, s33, -1                                      // 0000004834A8: 8106C121
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 0000004834AC: BF870481
	v_cmp_eq_u32_e32 vcc_lo, s6, v1                            // 0000004834B0: 7C940206
	v_cndmask_b32_e64 v1, 0, 1, vcc_lo                         // 0000004834B4: D5010001 01A90280
	ds_store_b32 v2, v1 offset:18688                           // 0000004834BC: D8344900 00000102
	s_or_b32 exec_lo, exec_lo, s5                              // 0000004834C4: 8C7E057E
	v_mov_b32_e32 v1, 0                                        // 0000004834C8: 7E020280
	s_waitcnt lgkmcnt(0)                                       // 0000004834CC: BF89FC07
	s_barrier                                                  // 0000004834D0: BFBD0000
	buffer_gl0_inv                                             // 0000004834D4: E0AC0000 00000000
	ds_load_b32 v1, v1 offset:18688                            // 0000004834DC: D8D84900 01000001
	s_waitcnt lgkmcnt(0)                                       // 0000004834E4: BF89FC07
	v_cmp_eq_u32_e32 vcc_lo, 0, v1                             // 0000004834E8: 7C940280
	s_cbranch_vccnz 71                                         // 0000004834EC: BFA40047 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi2ELb0ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1f0c>
	buffer_gl1_inv                                             // 0000004834F0: E0B00000 00000000
	buffer_gl0_inv                                             // 0000004834F8: E0AC0000 00000000
	s_and_saveexec_b32 s5, s1                                  // 000000483500: BE852001
	s_cbranch_execz 53                                         // 000000483504: BFA50035 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi2ELb0ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1edc>
	v_and_b32_e32 v2, 0x7f, v0                                 // 000000483508: 360400FF 0000007F
	s_lshl_b32 s6, s2, 7                                       // 000000483510: 84068702
	s_ashr_i32 s1, s18, 31                                     // 000000483514: 86019F12
	s_ashr_i32 s7, s6, 31                                      // 000000483518: 86079F06
	v_lshrrev_b32_e32 v1, 7, v0                                // 00000048351C: 32020087
	v_dual_mov_b32 v2, 0 :: v_dual_lshlrev_b32 v3, 2, v2       // 000000483520: CA220080 02020482
	s_lshl_b64 s[6:7], s[6:7], 2                               // 000000483528: 84868206
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000048352C: BF8700A9
	s_add_u32 s6, s24, s6                                      // 000000483530: 80060618
	s_addc_u32 s7, s25, s7                                     // 000000483534: 82070719
	.long 0xd7000603                                           // 000000483538: D7000603
	v_cndmask_b32_e32 v1, s6, v3, vcc_lo                       // 00000048353C: 02020606
	s_delay_alu instid0(VALU_DEP_1)                            // 000000483540: BF870001
	v_add_co_ci_u32_e64 v4, null, s7, 0, s6                    // 000000483544: D5207C04 00190007
	s_nop 0                                                    // 00000048354C: BF800000
	s_nop 0                                                    // 000000483550: BF800000
	s_nop 0                                                    // 000000483554: BF800000
	s_nop 0                                                    // 000000483558: BF800000
	s_nop 0                                                    // 00000048355C: BF800000
	s_nop 0                                                    // 000000483560: BF800000
	s_nop 0                                                    // 000000483564: BF800000
	s_nop 0                                                    // 000000483568: BF800000
	s_nop 0                                                    // 00000048356C: BF800000
	s_nop 0                                                    // 000000483570: BF800000
	s_nop 0                                                    // 000000483574: BF800000
	s_nop 0                                                    // 000000483578: BF800000
	s_nop 0                                                    // 00000048357C: BF800000
	v_mad_u64_u32 v[5:6], null, v1, s18, 0                     // 000000483580: D6FE7C05 02002501
	s_add_i32 s33, s33, -1                                     // 000000483588: 8121C121
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000048358C: BF870139
	s_cmp_eq_u32 s33, 0                                        // 000000483590: BF068021
	v_mad_u64_u32 v[6:7], null, v1, s1, v[6:7]                 // 000000483594: D6FE7C06 04180301
	v_add_nc_u32_e32 v1, 2, v1                                 // 00000048359C: 4A020282
	.long 0xd73c0005                                           // 0000004835A0: D73C0005
	v_cndmask_b32_e32 v1, 2, v5, vcc_lo                        // 0000004835A4: 02020A82
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004835A8: BF870091
	.long 0xd7006a05                                           // 0000004835AC: D7006A05
	v_cndmask_b32_e32 v1, v3, v5, vcc_lo                       // 0000004835B0: 02020B03
	v_add_co_ci_u32_e64 v6, null, v4, v6, vcc_lo               // 0000004835B4: D5207C06 01AA0D04
	global_load_b32 v5, v[5:6], off glc                        // 0000004835BC: DC524000 057C0005
	s_waitcnt vmcnt(0)                                         // 0000004835C4: BF8903F7
	v_add_f32_e32 v2, v2, v5                                   // 0000004835C8: 06040B02
	s_cbranch_scc0 65516                                       // 0000004835CC: BFA1FFEC <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi2ELb0ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1e80>
	v_lshlrev_b32_e32 v1, 2, v0                                // 0000004835D0: 30020082
	ds_store_b32 v1, v2 offset:8192                            // 0000004835D4: D8342000 00000201
	s_or_b32 exec_lo, exec_lo, s5                              // 0000004835DC: 8C7E057E
	s_and_saveexec_b32 s1, s4                                  // 0000004835E0: BE812004
	s_cbranch_execz 6                                          // 0000004835E4: BFA50006 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi2ELb0ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1f00>
	s_lshl_b64 s[4:5], s[2:3], 2                               // 0000004835E8: 84848202
	v_mov_b32_e32 v1, 0                                        // 0000004835EC: 7E020280
	s_add_u32 s4, s26, s4                                      // 0000004835F0: 8004041A
	s_addc_u32 s5, s27, s5                                     // 0000004835F4: 8205051B
	global_store_b32 v1, v1, s[4:5]                            // 0000004835F8: DC6A0000 00040101
	s_or_b32 exec_lo, exec_lo, s1                              // 000000483600: 8C7E017E
	s_cbranch_execz 65335                                      // 000000483604: BFA5FF37 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi2ELb0ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1be4>
	s_branch 1                                                 // 000000483608: BFA00001 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi2ELb0ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1f10>
	s_branch 65333                                             // 00000048360C: BFA0FF35 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi2ELb0ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1be4>
	v_cmp_gt_i32_e32 vcc_lo, s16, v11                          // 000000483610: 7C881610
	.long 0xd44c0001                                           // 000000483614: D44C0001
	v_cndmask_b32_e32 v1, 64, v0, vcc_lo                       // 000000483618: 020200C0
	s_waitcnt lgkmcnt(0)                                       // 00000048361C: BF89FC07
	s_waitcnt_vscnt null, 0x0                                  // 000000483620: BC7C0000
	s_barrier                                                  // 000000483624: BFBD0000
	buffer_gl0_inv                                             // 000000483628: E0AC0000 00000000
	s_and_b32 s1, vcc_lo, s1                                   // 000000483630: 8B01016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000483634: BF870009
	s_and_saveexec_b32 s3, s1                                  // 000000483638: BE832001
	s_cbranch_execz 65321                                      // 00000048363C: BFA5FF29 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi2ELb0ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1be4>
	v_and_b32_e32 v1, 15, v0                                   // 000000483640: 3602008F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000483644: BF870091
	v_lshlrev_b32_e32 v2, 2, v1                                // 000000483648: 30040282
	v_lshl_or_b32 v2, v11, 9, v2                               // 00000048364C: D6560002 0409130B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000483654: BF870001
	v_add_nc_u32_e32 v8, 0x2000, v2                            // 000000483658: 4A1004FF 00002000
	ds_load_2addr_b32 v[2:3], v8 offset1:16                    // 000000483660: D8DC1000 02000008
	ds_load_2addr_b32 v[4:5], v8 offset0:32 offset1:48         // 000000483668: D8DC3020 04000008
	ds_load_2addr_b32 v[6:7], v8 offset0:64 offset1:80         // 000000483670: D8DC5040 06000008
	ds_load_2addr_b32 v[8:9], v8 offset0:96 offset1:112        // 000000483678: D8DC7060 08000008
	v_and_b32_e32 v10, 1, v0                                   // 000000483680: 36140081
	s_waitcnt lgkmcnt(3)                                       // 000000483684: BF89FC37
	v_dual_add_f32 v14, v2, v3 :: v_dual_and_b32 v13, 4, v0    // 000000483688: C9240702 0E0C0084
	s_waitcnt lgkmcnt(2)                                       // 000000483690: BF89FC27
	v_dual_sub_f32 v2, v2, v3 :: v_dual_add_f32 v3, v4, v5     // 000000483694: C9480702 02020B04
	s_waitcnt lgkmcnt(1)                                       // 00000048369C: BF89FC17
	v_dual_sub_f32 v4, v4, v5 :: v_dual_add_f32 v5, v6, v7     // 0000004836A0: C9480B04 04040F06
	s_waitcnt lgkmcnt(0)                                       // 0000004836A8: BF89FC07
	v_dual_sub_f32 v6, v6, v7 :: v_dual_add_f32 v7, v8, v9     // 0000004836AC: C9480F06 06061308
	v_sub_f32_e32 v8, v8, v9                                   // 0000004836B4: 08101308
	v_dual_add_f32 v9, v14, v3 :: v_dual_and_b32 v12, 2, v0    // 0000004836B8: C924070E 090C0082
	v_sub_f32_e32 v3, v14, v3                                  // 0000004836C0: 0806070E
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000004836C4: BF8701B4
	v_dual_add_f32 v14, v2, v4 :: v_dual_add_f32 v15, v5, v7   // 0000004836C8: C9080902 0E0E0F05
	v_sub_f32_e32 v2, v2, v4                                   // 0000004836D0: 08040902
	v_dual_add_f32 v4, v6, v8 :: v_dual_sub_f32 v5, v5, v7     // 0000004836D4: C90A1106 04040F05
	v_dual_sub_f32 v6, v6, v8 :: v_dual_add_f32 v7, v9, v15    // 0000004836DC: C9481106 06061F09
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000004836E4: BF870222
	v_dual_sub_f32 v8, v9, v15 :: v_dual_add_f32 v9, v14, v4   // 0000004836E8: C9481F09 0808090E
	v_sub_f32_e32 v4, v14, v4                                  // 0000004836F0: 0808090E
	v_add_f32_e32 v14, v3, v5                                  // 0000004836F4: 061C0B03
	v_sub_f32_e32 v3, v3, v5                                   // 0000004836F8: 08060B03
	v_add_f32_e32 v5, v2, v6                                   // 0000004836FC: 060A0D02
	v_cmp_eq_u32_e32 vcc_lo, 0, v10                            // 000000483700: 7C941480
	v_mov_b32_dpp v10, v9 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000483704: 7E1402FA FF016109
	v_mov_b32_dpp v18, v4 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000048370C: 7E2402FA FF016104
	v_mov_b32_dpp v15, v14 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000483714: 7E1E02FA FF01610E
	v_mov_b32_dpp v16, v5 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000048371C: 7E2002FA FF016105
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 000000483724: D5010009 21AA1309
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 00000048372C: D5010005 21AA0B05
	v_sub_f32_e32 v2, v2, v6                                   // 000000483734: 08040D02
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 000000483738: D5010004 21AA0904
	v_cndmask_b32_e64 v14, -v14, v14, vcc_lo                   // 000000483740: D501000E 21AA1D0E
	v_mov_b32_dpp v17, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000483748: 7E2202FA FF016108
	v_add_f32_e32 v5, v5, v16                                  // 000000483750: 060A2105
	v_mov_b32_dpp v21, v2 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000483754: 7E2A02FA FF016102
	v_cndmask_b32_e64 v22, -v2, v2, vcc_lo                     // 00000048375C: D5010016 21AA0502
	v_add_f32_e32 v2, v9, v10                                  // 000000483764: 06041509
	v_add_f32_e32 v9, v4, v18                                  // 000000483768: 06122504
	v_mov_b32_dpp v6, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000048376C: 7E0C02FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, vcc_lo                      // 000000483774: D5010007 21AA0F07
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 00000048377C: D5010008 21AA1108
	v_mov_b32_dpp v19, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000483784: 7E2602FA FF016103
	v_cndmask_b32_e64 v20, -v3, v3, vcc_lo                     // 00000048378C: D5010014 21AA0703
	v_cmp_eq_u32_e32 vcc_lo, 0, v12                            // 000000483794: 7C941880
	v_add_f32_e32 v3, v7, v6                                   // 000000483798: 06060D07
	.long 0xd44a0001                                           // 00000048379C: D44A0001
	v_cndmask_b32_e32 v1, 0, v13, vcc_lo                       // 0000004837A0: 02021A80
	v_mov_b32_dpp v12, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000004837A4: 7E1802FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 0000004837AC: D5010005 21AA0B05
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000004837B4: BF8700A4
	v_mov_b32_dpp v4, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000004837B8: 7E0802FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 0000004837C0: D5010003 21AA0703
	v_add_f32_e32 v3, v3, v4                                   // 0000004837C8: 06060903
	v_mov_b32_dpp v7, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000004837CC: 7E0E02FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, vcc_lo                      // 0000004837D4: D5010002 21AA0502
	v_add_f32_e32 v4, v5, v12                                  // 0000004837DC: 06081905
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000004837E0: BF8700A4
	v_mov_b32_dpp v5, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000004837E4: 7E0A02FA FF016403
	v_cndmask_b32_e64 v3, -v3, v3, s1                          // 0000004837EC: D5010003 20060703
	v_dual_add_f32 v2, v2, v7 :: v_dual_add_f32 v3, v3, v5     // 0000004837F4: C9080F02 02020B03
	s_delay_alu instid0(VALU_DEP_1)                            // 0000004837FC: BF870001
	v_cndmask_b32_e64 v7, -v2, v2, s1                          // 000000483800: D5010007 20060502
	v_mov_b32_dpp v2, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000483808: 7E0402FA FF016402
	v_add_f32_e32 v6, v14, v15                                 // 000000483810: 060C1F0E
	v_add_f32_e32 v14, v22, v21                                // 000000483814: 061C2B16
	v_mov_b32_dpp v15, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000483818: 7E1E02FA FF016209
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 000000483820: D5010009 21AA1309
	v_add_f32_e32 v7, v7, v2                                   // 000000483828: 060E0507
	v_mov_b32_dpp v10, v6 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000048382C: 7E1402FA FF016206
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 000000483834: D5010006 21AA0D06
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000048383C: BF870234
	v_dual_add_f32 v8, v8, v17 :: v_dual_add_f32 v9, v9, v15   // 000000483840: C9082308 08081F09
	v_mov_b32_dpp v16, v14 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000483848: 7E2002FA FF01620E
	v_cndmask_b32_e64 v14, -v14, v14, vcc_lo                   // 000000483850: D501000E 21AA1D0E
	v_add_f32_e32 v6, v6, v10                                  // 000000483858: 060C1506
	v_mov_b32_dpp v10, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000048385C: 7E1402FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s1                          // 000000483864: D5010004 20060904
	v_mov_b32_dpp v13, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000048386C: 7E1A02FA FF016208
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 000000483874: D5010008 21AA1108
	v_mov_b32_dpp v12, v6 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000048387C: 7E1802FA FF016406
	v_cndmask_b32_e64 v6, -v6, v6, s1                          // 000000483884: D5010006 20060D06
	v_add_f32_e32 v4, v4, v10                                  // 00000048388C: 06081504
	v_add_f32_e32 v10, v20, v19                                // 000000483890: 06142714
	v_add_f32_e32 v8, v8, v13                                  // 000000483894: 06101B08
	v_mov_b32_dpp v2, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000483898: 7E0402FA FF016803
	v_add_f32_e32 v6, v6, v12                                  // 0000004838A0: 060C1906
	v_mov_b32_dpp v5, v7 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000004838A4: 7E0A02FA FF016807
	v_mov_b32_dpp v13, v10 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000004838AC: 7E1A02FA FF01620A
	v_cndmask_b32_e64 v10, -v10, v10, vcc_lo                   // 0000004838B4: D501000A 21AA150A
	v_mov_b32_dpp v12, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000004838BC: 7E1802FA FF016408
	v_cndmask_b32_e64 v15, -v8, v8, s1                         // 0000004838C4: D501000F 20061108
	v_mov_b32_dpp v8, v6 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000004838CC: 7E1002FA FF016806
	s_delay_alu instid0(VALU_DEP_4)                            // 0000004838D4: BF870004
	v_add_f32_e32 v10, v10, v13                                // 0000004838D8: 06141B0A
	v_add_f32_e32 v13, v14, v16                                // 0000004838DC: 061A210E
	v_mov_b32_dpp v14, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000004838E0: 7E1C02FA FF016409
	v_cndmask_b32_e64 v9, -v9, v9, s1                          // 0000004838E8: D5010009 20061309
	v_add_f32_e32 v15, v15, v12                                // 0000004838F0: 061E190F
	v_mov_b32_dpp v16, v10 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000004838F4: 7E2002FA FF01640A
	v_mov_b32_dpp v18, v13 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000004838FC: 7E2402FA FF01640D
	v_cndmask_b32_e64 v10, -v10, v10, s1                       // 000000483904: D501000A 2006150A
	v_cndmask_b32_e64 v13, -v13, v13, s1                       // 00000048390C: D501000D 20061B0D
	v_add_f32_e32 v17, v9, v14                                 // 000000483914: 06221D09
	v_mov_b32_dpp v9, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000483918: 7E1202FA FF016804
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000483920: BF870214
	v_add_f32_e32 v16, v10, v16                                // 000000483924: 0620210A
	v_add_f32_e32 v18, v13, v18                                // 000000483928: 0624250D
	v_mov_b32_dpp v10, v15 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000048392C: 7E1402FA FF01680F
	v_mov_b32_dpp v12, v17 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000483934: 7E1802FA FF016811
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000048393C: BF870214
	v_mov_b32_dpp v13, v16 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000483940: 7E1A02FA FF016810
	v_mov_b32_dpp v14, v18 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000483948: 7E1C02FA FF016812
	s_and_b32 exec_lo, exec_lo, s0                             // 000000483950: 8B7E007E
	s_cbranch_execz 65123                                      // 000000483954: BFA5FE63 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi2ELb0ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1be4>
	v_lshl_or_b32 v19, s2, 7, v1                               // 000000483958: D6560013 04050E02
	.long 0x7f2e3880                                           // 000000483960: 7F2E3880
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000483964: BF870112
	v_ashrrev_i32_e32 v20, 31, v19                             // 000000483968: 3428269F
	.long 0x7f303997                                           // 00000048396C: 7F303997
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000483970: BF870092
	.long 0xd73c0013                                           // 000000483974: D73C0013
	v_cndmask_b32_e32 v1, 1, v19, vcc_lo                       // 000000483978: 02022681
	.long 0xd7006a15                                           // 00000048397C: D7006A15
	v_cndmask_b32_e32 v1, s22, v19, vcc_lo                     // 000000483980: 02022616
	s_delay_alu instid0(VALU_DEP_1)                            // 000000483984: BF870001
	v_add_co_ci_u32_e64 v22, null, s23, v20, vcc_lo            // 000000483988: D5207C16 01AA2817
	s_clause 0x7                                               // 000000483990: BF850007
	global_load_d16_b16 v23, v[21:22], off offset:32           // 000000483994: DC820020 177C0015
	global_load_d16_b16 v24, v[21:22], off                     // 00000048399C: DC820000 187C0015
	global_load_d16_b16 v25, v[21:22], off offset:64           // 0000004839A4: DC820040 197C0015
	global_load_d16_b16 v26, v[21:22], off offset:96           // 0000004839AC: DC820060 1A7C0015
	global_load_d16_b16 v27, v[21:22], off offset:128          // 0000004839B4: DC820080 1B7C0015
	global_load_d16_b16 v28, v[21:22], off offset:160          // 0000004839BC: DC8200A0 1C7C0015
	global_load_d16_b16 v29, v[21:22], off offset:192          // 0000004839C4: DC8200C0 1D7C0015
	global_load_d16_b16 v21, v[21:22], off offset:224          // 0000004839CC: DC8200E0 157C0015
	v_and_b32_e32 v22, 8, v0                                   // 0000004839D4: 362C0088
	v_mad_i64_i32 v[0:1], null, s18, v11, 0                    // 0000004839D8: D6FF7C00 02021612
	s_waitcnt vmcnt(7)                                         // 0000004839E0: BF891FF7
	.long 0x7f163997                                           // 0000004839E4: 7F163997
	s_waitcnt vmcnt(0)                                         // 0000004839E8: BF8903F7
	.long 0x7f2a3997                                           // 0000004839EC: 7F2A3997
	v_cmp_eq_u32_e32 vcc_lo, 0, v22                            // 0000004839F0: 7C942C80
	.long 0x7f2c3997                                           // 0000004839F4: 7F2C3997
	.long 0xd73c0000                                           // 0000004839F8: D73C0000
	v_cndmask_b32_e32 v1, 1, v0, vcc_lo                        // 0000004839FC: 02020081
	v_cndmask_b32_e64 v7, -v7, v7, vcc_lo                      // 000000483A00: D5010007 21AA0F07
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 000000483A08: D5010003 21AA0703
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 000000483A10: D5010004 21AA0904
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 000000483A18: D5010006 21AA0D06
	v_cndmask_b32_e64 v16, -v16, v16, vcc_lo                   // 000000483A20: D5010010 21AA2110
	v_add_f32_e32 v5, v7, v5                                   // 000000483A28: 060A0B07
	v_cndmask_b32_e64 v7, -v17, v17, vcc_lo                    // 000000483A2C: D5010007 21AA2311
	v_cndmask_b32_e64 v17, -v18, v18, vcc_lo                   // 000000483A34: D5010011 21AA2512
	v_add_f32_e32 v2, v3, v2                                   // 000000483A3C: 06040503
	v_add_f32_e32 v4, v4, v9                                   // 000000483A40: 06081304
	v_mul_f32_e32 v3, 0x3db504f3, v5                           // 000000483A44: 10060AFF 3DB504F3
	v_add_f32_e32 v5, v6, v8                                   // 000000483A4C: 060A1106
	v_cndmask_b32_e64 v15, -v15, v15, vcc_lo                   // 000000483A50: D501000F 21AA1F0F
	v_dual_add_f32 v7, v7, v12 :: v_dual_add_f32 v8, v16, v13  // 000000483A58: C9081907 07081B10
	v_dual_add_f32 v9, v17, v14 :: v_dual_mul_f32 v4, 0x3db504f3, v4// 000000483A60: C9061D11 090408FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000483A6C: BF870212
	v_dual_mul_f32 v2, 0x3db504f3, v2 :: v_dual_mul_f32 v7, 0x3db504f3, v7// 000000483A70: C8C604FF 02060EFF 3DB504F3
	v_dual_add_f32 v6, v15, v10 :: v_dual_mul_f32 v5, 0x3db504f3, v5// 000000483A7C: C906150F 06040AFF 3DB504F3
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000483A88: BF8701A3
	v_mul_f32_e32 v9, 0x3db504f3, v9                           // 000000483A8C: 101212FF 3DB504F3
	.long 0xd7006a00                                           // 000000483A94: D7006A00
	v_cndmask_b32_e32 v1, s28, v0, vcc_lo                      // 000000483A98: 0202001C
	v_mul_f32_e32 v6, 0x3db504f3, v6                           // 000000483A9C: 100C0CFF 3DB504F3
	v_add_co_ci_u32_e64 v1, null, s29, v1, vcc_lo              // 000000483AA4: D5207C01 01AA021D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000483AAC: BF870093
	.long 0xd7006a00                                           // 000000483AB0: D7006A00
	v_cndmask_b32_e32 v1, v0, v19, vcc_lo                      // 000000483AB4: 02022700
	v_add_co_ci_u32_e64 v1, null, v1, v20, vcc_lo              // 000000483AB8: D5207C01 01AA2901
	v_fma_mix_f32 v3, v23, v3, neg(0) op_sel_hi:[1,0,0]        // 000000483AC0: CC200003 8A020717
	v_fma_mix_f32 v2, v24, v2, neg(0) op_sel_hi:[1,0,0]        // 000000483AC8: CC200002 8A020518
	v_fma_mix_f32 v5, v25, v5, neg(0) op_sel_hi:[1,0,0]        // 000000483AD0: CC200005 8A020B19
	v_fma_mix_f32 v4, v26, v4, neg(0) op_sel_hi:[1,0,0]        // 000000483AD8: CC200004 8A02091A
	v_fma_mix_f32 v6, v27, v6, neg(0) op_sel_hi:[1,0,0]        // 000000483AE0: CC200006 8A020D1B
	.long 0x7e2e3983                                           // 000000483AE8: 7E2E3983
	v_fma_mix_f32 v7, v28, v7, neg(0) op_sel_hi:[1,0,0]        // 000000483AEC: CC200007 8A020F1C
	.long 0x7e163982                                           // 000000483AF4: 7E163982
	v_mul_f32_e32 v8, 0x3db504f3, v8                           // 000000483AF8: 101010FF 3DB504F3
	v_fma_mix_f32 v9, v21, v9, neg(0) op_sel_hi:[1,0,0]        // 000000483B00: CC200009 8A021315
	v_and_b32_e32 v10, 1, v23                                  // 000000483B08: 36142E81
	.long 0x7e2e3984                                           // 000000483B0C: 7E2E3984
	v_and_b32_e32 v11, 1, v11                                  // 000000483B10: 36161681
	v_fma_mix_f32 v8, v29, v8, neg(0) op_sel_hi:[1,0,0]        // 000000483B14: CC200008 8A02111D
	.long 0x7e2a3985                                           // 000000483B1C: 7E2A3985
	.long 0x7e2c3986                                           // 000000483B20: 7E2C3986
	v_and_b32_e32 v12, 1, v23                                  // 000000483B24: 36182E81
	.long 0x7e2e3987                                           // 000000483B28: 7E2E3987
	.long 0x7e303988                                           // 000000483B2C: 7E303988
	v_and_b32_e32 v13, 1, v21                                  // 000000483B30: 361A2A81
	v_and_b32_e32 v14, 1, v22                                  // 000000483B34: 361C2C81
	v_add3_u32 v3, v3, v10, 0x7fff                             // 000000483B38: D6550003 03FE1503 00007FFF
	v_and_b32_e32 v15, 1, v23                                  // 000000483B44: 361E2E81
	.long 0x7e2e3989                                           // 000000483B48: 7E2E3989
	v_and_b32_e32 v16, 1, v24                                  // 000000483B4C: 36203081
	v_add3_u32 v2, v2, v11, 0x7fff                             // 000000483B50: D6550002 03FE1702 00007FFF
	v_add3_u32 v5, v5, v13, 0x7fff                             // 000000483B5C: D6550005 03FE1B05 00007FFF
	v_add3_u32 v4, v4, v12, 0x7fff                             // 000000483B68: D6550004 03FE1904 00007FFF
	v_and_b32_e32 v10, 1, v23                                  // 000000483B74: 36142E81
	v_add3_u32 v6, v6, v14, 0x7fff                             // 000000483B78: D6550006 03FE1D06 00007FFF
	v_add3_u32 v8, v8, v16, 0x7fff                             // 000000483B84: D6550008 03FE2108 00007FFF
	v_add3_u32 v7, v7, v15, 0x7fff                             // 000000483B90: D6550007 03FE1F07 00007FFF
	s_delay_alu instid0(VALU_DEP_4)                            // 000000483B9C: BF870004
	v_add3_u32 v9, v9, v10, 0x7fff                             // 000000483BA0: D6550009 03FE1509 00007FFF
	s_clause 0x7                                               // 000000483BAC: BF850007
	global_store_d16_hi_b16 v[0:1], v2, off                    // 000000483BB0: DC960000 007C0200
	global_store_d16_hi_b16 v[0:1], v3, off offset:32          // 000000483BB8: DC960020 007C0300
	global_store_d16_hi_b16 v[0:1], v5, off offset:64          // 000000483BC0: DC960040 007C0500
	global_store_d16_hi_b16 v[0:1], v4, off offset:96          // 000000483BC8: DC960060 007C0400
	global_store_d16_hi_b16 v[0:1], v6, off offset:128         // 000000483BD0: DC960080 007C0600
	global_store_d16_hi_b16 v[0:1], v7, off offset:160         // 000000483BD8: DC9600A0 007C0700
	global_store_d16_hi_b16 v[0:1], v8, off offset:192         // 000000483BE0: DC9600C0 007C0800
	global_store_d16_hi_b16 v[0:1], v9, off offset:224         // 000000483BE8: DC9600E0 007C0900
	s_endpgm                                                   // 000000483BF0: BFB00000
		...

