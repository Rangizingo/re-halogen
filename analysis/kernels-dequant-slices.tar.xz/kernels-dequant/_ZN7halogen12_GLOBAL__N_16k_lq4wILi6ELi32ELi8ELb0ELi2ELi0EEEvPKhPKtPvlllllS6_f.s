0000000000815100 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi8ELb0ELi2ELi0EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi8ELb0ELi2ELi0EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 000000815100: F4100100 F8000000
	v_dual_mov_b32 v6, 0 :: v_dual_and_b32 v1, 15, v0          // 000000815108: CA240080 0600008F
	v_lshrrev_b32_e32 v2, 2, v0                                // 000000815110: 32040082
	s_ashr_i32 s3, s2, 31                                      // 000000815114: 86039F02
	v_mov_b32_e32 v5, 0                                        // 000000815118: 7E0A0280
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000081511C: BF870193
	v_dual_mov_b32 v8, 0 :: v_dual_lshlrev_b32 v1, 2, v1       // 000000815120: CA220080 08000282
	v_and_b32_e32 v2, 60, v2                                   // 000000815128: 360404BC
	v_lshrrev_b32_e32 v15, 5, v0                               // 00000081512C: 321E0085
	v_dual_mov_b32 v29, 0 :: v_dual_and_b32 v16, 31, v0        // 000000815130: CA240080 1D10009F
	.long 0x7f263880                                           // 000000815138: 7F263880
	v_dual_mov_b32 v17, 0 :: v_dual_lshlrev_b32 v14, 2, v0     // 00000081513C: CA220080 110E0082
	s_waitcnt lgkmcnt(0)                                       // 000000815144: BF89FC07
	s_clause 0x1                                               // 000000815148: BF850001
	global_load_b32 v11, v1, s[4:5]                            // 00000081514C: DC520000 0B040001
	global_load_b32 v13, v2, s[4:5]                            // 000000815154: DC520000 0D040002
	.long 0xd4510000                                           // 00000081515C: D4510000
	v_cndmask_b32_e32 v0, s2, v12, vcc_lo                      // 000000815160: 02001802
	s_and_b32 s0, s0, exec_lo                                  // 000000815164: 8B007E00
	s_cselect_b32 s22, s3, 0                                   // 000000815168: 98168003
	s_cselect_b32 s23, s2, 0                                   // 00000081516C: 98178002
	s_add_u32 s0, s4, s14                                      // 000000815170: 80000E04
	s_addc_u32 s1, s5, s15                                     // 000000815174: 82010F05
	s_lshr_b32 s14, s11, 31                                    // 000000815178: 850E9F0B
	v_dual_mov_b32 v7, 0 :: v_dual_mov_b32 v2, s1              // 00000081517C: CA100080 07020001
	s_add_u32 s14, s10, s14                                    // 000000815184: 800E0E0A
	s_addc_u32 s15, s11, 0                                     // 000000815188: 820F800B
	s_ashr_i32 s20, s11, 31                                    // 00000081518C: 86149F0B
	s_ashr_i64 s[14:15], s[14:15], 1                           // 000000815190: 868E810E
	s_lshr_b32 s20, s20, 27                                    // 000000815194: 85149B14
	v_mov_b32_e32 v1, s0                                       // 000000815198: 7E020200
	s_add_u32 s20, s10, s20                                    // 00000081519C: 8014140A
	s_addc_u32 s21, s11, 0                                     // 0000008151A0: 8215800B
	s_mul_i32 s19, s19, s23                                    // 0000008151A4: 96131713
	s_lshr_b64 s[20:21], s[20:21], 5                           // 0000008151A8: 85948514
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000008151AC: BF870499
	s_add_i32 s21, s20, 7                                      // 0000008151B0: 81158714
	s_ashr_i32 s24, s21, 31                                    // 0000008151B4: 86189F15
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000008151B8: BF870499
	s_lshr_b32 s24, s24, 29                                    // 0000008151BC: 85189D18
	s_add_i32 s21, s21, s24                                    // 0000008151C0: 81151815
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000008151C4: BF870009
	s_ashr_i32 s21, s21, 3                                     // 0000008151C8: 86158315
	s_add_u32 s0, s4, s16                                      // 0000008151CC: 80001004
	s_addc_u32 s1, s5, s17                                     // 0000008151D0: 82011105
	.long 0xd72c0012                                           // 0000008151D4: D72C0012
	v_cndmask_b32_e32 v1, s21, v15, vcc_lo                     // 0000008151D8: 02021E15
	v_mov_b32_e32 v4, s1                                       // 0000008151DC: 7E080201
	v_mad_u64_u32 v[9:10], null, s23, s14, v[1:2]              // 0000008151E0: D6FE7C09 04041C17
	v_mov_b32_e32 v3, s0                                       // 0000008151E8: 7E060200
	s_mul_i32 s0, s22, s14                                     // 0000008151EC: 96000E16
	s_waitcnt vmcnt(1)                                         // 0000008151F0: BF8907F7
	v_bfe_u32 v12, v11, 16, 1                                  // 0000008151F4: D610000C 0205210B
	s_waitcnt vmcnt(0)                                         // 0000008151FC: BF8903F7
	v_bfe_u32 v1, v13, 16, 1                                   // 000000815200: D6100001 0205210D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000815208: BF870112
	v_add3_u32 v2, v11, v12, 0x7fff                            // 00000081520C: D6550002 03FE190B 00007FFF
	v_add3_u32 v1, v13, v1, 0x7fff                             // 000000815218: D6550001 03FE030D 00007FFF
	s_delay_alu instid0(VALU_DEP_2)                            // 000000815224: BF870002
	.long 0x7e263982                                           // 000000815228: 7E263982
	v_add_nc_u32_e32 v2, s0, v10                               // 00000081522C: 4A041400
	v_mad_u64_u32 v[11:12], null, s18, s23, v[3:4]             // 000000815230: D6FE7C0B 040C2E12
	v_add_nc_u32_e32 v3, s21, v18                              // 000000815238: 4A062415
	v_add_nc_u32_e32 v10, v18, v16                             // 00000081523C: 4A142112
	s_mul_i32 s23, s23, s15                                    // 000000815240: 96170F17
	s_mul_i32 s0, s18, s22                                     // 000000815244: 96001612
	v_and_or_b32 v1, 0xffff0000, v1, v19                       // 000000815248: D6570001 044E02FF FFFF0000
	v_min_i32_e32 v18, s20, v3                                 // 000000815254: 22240614
	v_add_nc_u32_e32 v19, s23, v2                              // 000000815258: 4A260417
	v_add_nc_u32_e32 v3, s19, v12                              // 00000081525C: 4A061813
	ds_store_b32 v14, v1                                       // 000000815260: D8340000 0000010E
	v_cmp_lt_i32_e32 vcc_lo, v10, v18                          // 000000815268: 7C82250A
	v_add_nc_u32_e32 v20, s0, v3                               // 00000081526C: 4A280600
	s_waitcnt lgkmcnt(0)                                       // 000000815270: BF89FC07
	s_barrier                                                  // 000000815274: BFBD0000
	buffer_gl0_inv                                             // 000000815278: E0AC0000 00000000
	s_and_saveexec_b32 s1, vcc_lo                              // 000000815280: BE81206A
	s_cbranch_execz 21                                         // 000000815284: BFA50015 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi8ELb0ELi2ELi0EEEvPKhPKtPvlllllS6_f+0x1dc>
	v_lshlrev_b32_e32 v1, 1, v10                               // 000000815288: 30021481
	v_lshlrev_b32_e32 v3, 4, v10                               // 00000081528C: 30061484
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000815290: BF870112
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000815294: 3404029F
	v_ashrrev_i32_e32 v4, 31, v3                               // 000000815298: 3408069F
	.long 0xd7000001                                           // 00000081529C: D7000001
	v_cndmask_b32_e32 v1, v11, v1, vcc_lo                      // 0000008152A0: 0202030B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008152A4: BF8700A1
	v_add_co_ci_u32_e64 v2, null, v20, v2, s0                  // 0000008152A8: D5207C02 00020514
	.long 0xd7000003                                           // 0000008152B0: D7000003
	v_cndmask_b32_e32 v1, v9, v3, vcc_lo                       // 0000008152B4: 02020709
	v_add_co_ci_u32_e64 v4, null, v19, v4, s0                  // 0000008152B8: D5207C04 00020913
	s_clause 0x1                                               // 0000008152C0: BF850001
	global_load_d16_b16 v1, v[1:2], off                        // 0000008152C4: DC820000 017C0001
	global_load_b128 v[5:8], v[3:4], off                       // 0000008152CC: DC5E0000 057C0003
	s_waitcnt vmcnt(1)                                         // 0000008152D4: BF8907F7
	v_cvt_f32_f16_e32 v29, v1                                  // 0000008152D8: 7E3A1701
	s_or_b32 exec_lo, exec_lo, s1                              // 0000008152DC: 8C7E017E
	v_dual_mov_b32 v22, 0 :: v_dual_mov_b32 v23, 0             // 0000008152E0: CA100080 16160080
	v_dual_mov_b32 v24, 0 :: v_dual_mov_b32 v25, 0             // 0000008152E8: CA100080 18180080
	v_mov_b32_e32 v21, 0                                       // 0000008152F0: 7E2A0280
	s_and_saveexec_b32 s1, vcc_lo                              // 0000008152F4: BE81206A
	s_cbranch_execz 519                                        // 0000008152F8: BFA50207 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi8ELb0ELi2ELi0EEEvPKhPKtPvlllllS6_f+0xa18>
	v_dual_mov_b32 v24, 0 :: v_dual_add_nc_u32 v1, 32, v10     // 0000008152FC: CA200080 180014A0
	v_dual_mov_b32 v21, 0 :: v_dual_lshlrev_b32 v12, 5, v10    // 000000815304: CA220080 150C1485
	v_dual_mov_b32 v23, 0 :: v_dual_mov_b32 v28, v29           // 00000081530C: CA100080 171C011D
	s_delay_alu instid0(VALU_DEP_3)                            // 000000815314: BF870003
	v_dual_mov_b32 v25, 0 :: v_dual_lshlrev_b32 v26, 4, v1     // 000000815318: CA220080 191A0284
	v_dual_mov_b32 v22, 0 :: v_dual_lshlrev_b32 v27, 1, v1     // 000000815320: CA220080 161A0281
	v_mov_b32_e32 v17, 0                                       // 000000815328: 7E220280
	s_mul_i32 s0, s11, 6                                       // 00000081532C: 9600860B
	s_mul_hi_u32 s14, s10, 6                                   // 000000815330: 968E860A
	s_lshl_b64 s[4:5], s[10:11], 2                             // 000000815334: 8484820A
	s_add_i32 s14, s14, s0                                     // 000000815338: 810E000E
	s_mul_i32 s16, s10, 6                                      // 00000081533C: 9610860A
	s_mov_b32 s15, 0                                           // 000000815340: BE8F0080
	s_lshl_b64 s[10:11], s[10:11], 1                           // 000000815344: 848A810A
	s_branch 467                                               // 000000815348: BFA001D3 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi8ELb0ELi2ELi0EEEvPKhPKtPvlllllS6_f+0x998>
	s_or_b32 exec_lo, exec_lo, s17                             // 00000081534C: 8C7E117E
	v_and_b32_e32 v13, 0xff, v5                                // 000000815350: 361A0AFF 000000FF
	s_and_b32 s0, exec_lo, vcc_lo                              // 000000815358: 8B006A7E
	v_add_nc_u32_e32 v26, 0x200, v26                           // 00000081535C: 4A3434FF 00000200
	s_or_b32 s15, s0, s15                                      // 000000815364: 8C0F0F00
	v_add_nc_u32_e32 v27, 64, v27                              // 000000815368: 4A3636C0
	v_lshlrev_b32_e32 v13, 2, v13                              // 00000081536C: 301A1A82
	ds_load_b32 v46, v13                                       // 000000815370: D8D80000 2E00000D
	v_lshrrev_b32_e32 v13, 6, v5                               // 000000815378: 321A0A86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 00000081537C: BF870141
	v_and_b32_e32 v13, 0x3fc, v13                              // 000000815380: 361A1AFF 000003FC
	ds_load_b32 v47, v13                                       // 000000815388: D8D80000 2F00000D
	v_lshrrev_b32_e32 v13, 14, v5                              // 000000815390: 321A0A8E
	v_lshrrev_b32_e32 v5, 22, v5                               // 000000815394: 320A0A96
	v_and_b32_e32 v13, 0x3fc, v13                              // 000000815398: 361A1AFF 000003FC
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 0000008153A0: BF870152
	v_and_b32_e32 v5, 0x3fc, v5                                // 0000008153A4: 360A0AFF 000003FC
	ds_load_b32 v48, v13                                       // 0000008153AC: D8D80000 3000000D
	ds_load_b32 v49, v5                                        // 0000008153B4: D8D80000 31000005
	v_and_b32_e32 v5, 0xff, v6                                 // 0000008153BC: 360A0CFF 000000FF
	v_ashrrev_i32_e32 v13, 31, v12                             // 0000008153C4: 341A189F
	v_lshlrev_b32_e32 v5, 2, v5                                // 0000008153C8: 300A0A82
	ds_load_b32 v50, v5                                        // 0000008153CC: D8D80000 32000005
	v_lshrrev_b32_e32 v5, 6, v6                                // 0000008153D4: 320A0C86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008153D8: BF8700B1
	v_and_b32_e32 v5, 0x3fc, v5                                // 0000008153DC: 360A0AFF 000003FC
	ds_load_b32 v51, v5                                        // 0000008153E4: D8D80000 33000005
	v_lshrrev_b32_e32 v5, 14, v6                               // 0000008153EC: 320A0C8E
	v_and_b32_e32 v5, 0x3fc, v5                                // 0000008153F0: 360A0AFF 000003FC
	ds_load_b32 v52, v5                                        // 0000008153F8: D8D80000 34000005
	v_lshrrev_b32_e32 v5, 22, v6                               // 000000815400: 320A0C96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000815404: BF8700B1
	v_and_b32_e32 v5, 0x3fc, v5                                // 000000815408: 360A0AFF 000003FC
	ds_load_b32 v53, v5                                        // 000000815410: D8D80000 35000005
	v_and_b32_e32 v5, 0xff, v7                                 // 000000815418: 360A0EFF 000000FF
	v_lshlrev_b32_e32 v5, 2, v5                                // 000000815420: 300A0A82
	ds_load_b32 v54, v5                                        // 000000815424: D8D80000 36000005
	v_lshrrev_b32_e32 v5, 6, v7                                // 00000081542C: 320A0E86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000815430: BF8700B1
	v_and_b32_e32 v5, 0x3fc, v5                                // 000000815434: 360A0AFF 000003FC
	ds_load_b32 v55, v5                                        // 00000081543C: D8D80000 37000005
	v_lshrrev_b32_e32 v5, 14, v7                               // 000000815444: 320A0E8E
	v_and_b32_e32 v5, 0x3fc, v5                                // 000000815448: 360A0AFF 000003FC
	ds_load_b32 v56, v5                                        // 000000815450: D8D80000 38000005
	v_lshrrev_b32_e32 v5, 22, v7                               // 000000815458: 320A0E96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000081545C: BF8700B1
	v_and_b32_e32 v5, 0x3fc, v5                                // 000000815460: 360A0AFF 000003FC
	ds_load_b32 v57, v5                                        // 000000815468: D8D80000 39000005
	v_and_b32_e32 v5, 0xff, v8                                 // 000000815470: 360A10FF 000000FF
	v_lshlrev_b32_e32 v5, 2, v5                                // 000000815478: 300A0A82
	ds_load_b32 v58, v5                                        // 00000081547C: D8D80000 3A000005
	v_lshrrev_b32_e32 v5, 6, v8                                // 000000815484: 320A1086
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000815488: BF8700B1
	v_and_b32_e32 v5, 0x3fc, v5                                // 00000081548C: 360A0AFF 000003FC
	ds_load_b32 v59, v5                                        // 000000815494: D8D80000 3B000005
	v_lshrrev_b32_e32 v5, 14, v8                               // 00000081549C: 320A108E
	v_and_b32_e32 v5, 0x3fc, v5                                // 0000008154A0: 360A0AFF 000003FC
	ds_load_b32 v60, v5                                        // 0000008154A8: D8D80000 3C000005
	v_lshrrev_b32_e32 v5, 22, v8                               // 0000008154B0: 320A1096
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000008154B4: BF870141
	v_and_b32_e32 v5, 0x3fc, v5                                // 0000008154B8: 360A0AFF 000003FC
	ds_load_b32 v61, v5                                        // 0000008154C0: D8D80000 3D000005
	.long 0xd73c0005                                           // 0000008154C8: D73C0005
	v_cndmask_b32_e32 v1, 1, v12, vcc_lo                       // 0000008154CC: 02021881
	v_add_nc_u32_e32 v12, 0x400, v12                           // 0000008154D0: 4A1818FF 00000400
	.long 0xd7006a2a                                           // 0000008154D8: D7006A2A
	v_cndmask_b32_e32 v1, s6, v5, vcc_lo                       // 0000008154DC: 02020A06
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008154E0: BF870001
	v_add_co_ci_u32_e64 v43, null, s7, v6, vcc_lo              // 0000008154E4: D5207C2B 01AA0C07
	s_clause 0x3                                               // 0000008154EC: BF850003
	global_load_b128 v[5:8], v[42:43], off                     // 0000008154F0: DC5E0000 057C002A
	global_load_b128 v[30:33], v[42:43], off offset:16         // 0000008154F8: DC5E0010 1E7C002A
	global_load_b128 v[34:37], v[42:43], off offset:32         // 000000815500: DC5E0020 227C002A
	global_load_b128 v[38:41], v[42:43], off offset:48         // 000000815508: DC5E0030 267C002A
	s_waitcnt vmcnt(3) lgkmcnt(15)                             // 000000815510: BF890CF7
	v_dot2_f32_bf16 v5, v5, v46, 0                             // 000000815514: CC1A4005 1A025D05
	s_waitcnt lgkmcnt(14)                                      // 00000081551C: BF89FCE7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000815520: BF8700A1
	v_dot2_f32_bf16 v5, v6, v47, v5                            // 000000815524: CC1A4005 1C165F06
	s_waitcnt lgkmcnt(13)                                      // 00000081552C: BF89FCD7
	v_dot2_f32_bf16 v5, v7, v48, v5                            // 000000815530: CC1A4005 1C166107
	s_waitcnt lgkmcnt(12)                                      // 000000815538: BF89FCC7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000081553C: BF8700A1
	v_dot2_f32_bf16 v5, v8, v49, v5                            // 000000815540: CC1A4005 1C166308
	s_waitcnt vmcnt(2) lgkmcnt(11)                             // 000000815548: BF8908B7
	v_dot2_f32_bf16 v5, v30, v50, v5                           // 00000081554C: CC1A4005 1C16651E
	s_waitcnt lgkmcnt(10)                                      // 000000815554: BF89FCA7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000815558: BF8700A1
	v_dot2_f32_bf16 v5, v31, v51, v5                           // 00000081555C: CC1A4005 1C16671F
	s_waitcnt lgkmcnt(9)                                       // 000000815564: BF89FC97
	v_dot2_f32_bf16 v5, v32, v52, v5                           // 000000815568: CC1A4005 1C166920
	s_waitcnt lgkmcnt(8)                                       // 000000815570: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000815574: BF8700A1
	v_dot2_f32_bf16 v5, v33, v53, v5                           // 000000815578: CC1A4005 1C166B21
	s_waitcnt vmcnt(1) lgkmcnt(7)                              // 000000815580: BF890477
	v_dot2_f32_bf16 v5, v34, v54, v5                           // 000000815584: CC1A4005 1C166D22
	s_waitcnt lgkmcnt(6)                                       // 00000081558C: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000815590: BF8700A1
	v_dot2_f32_bf16 v5, v35, v55, v5                           // 000000815594: CC1A4005 1C166F23
	s_waitcnt lgkmcnt(5)                                       // 00000081559C: BF89FC57
	v_dot2_f32_bf16 v5, v36, v56, v5                           // 0000008155A0: CC1A4005 1C167124
	s_waitcnt lgkmcnt(4)                                       // 0000008155A8: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008155AC: BF8700A1
	v_dot2_f32_bf16 v5, v37, v57, v5                           // 0000008155B0: CC1A4005 1C167325
	s_waitcnt vmcnt(0) lgkmcnt(3)                              // 0000008155B8: BF890037
	v_dot2_f32_bf16 v5, v38, v58, v5                           // 0000008155BC: CC1A4005 1C167526
	.long 0xd7006a26                                           // 0000008155C4: D7006A26
	v_cndmask_b32_e32 v0, v42, v10, vcc_lo                     // 0000008155C8: 0200152A
	s_waitcnt lgkmcnt(2)                                       // 0000008155CC: BF89FC27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000008155D0: BF8701C2
	v_dot2_f32_bf16 v5, v39, v59, v5                           // 0000008155D4: CC1A4005 1C167727
	v_add_co_ci_u32_e64 v39, null, s11, v43, vcc_lo            // 0000008155DC: D5207C27 01AA560B
	.long 0xd7006a2c                                           // 0000008155E4: D7006A2C
	v_cndmask_b32_e32 v0, v42, v4, vcc_lo                      // 0000008155E8: 0200092A
	s_waitcnt lgkmcnt(1)                                       // 0000008155EC: BF89FC17
	v_dot2_f32_bf16 v5, v40, v60, v5                           // 0000008155F0: CC1A4005 1C167928
	v_add_co_ci_u32_e64 v45, null, s5, v43, vcc_lo             // 0000008155F8: D5207C2D 01AA5605
	.long 0xd7006a2a                                           // 000000815600: D7006A2A
	v_cndmask_b32_e32 v0, v42, v16, vcc_lo                     // 000000815604: 0200212A
	s_waitcnt lgkmcnt(0)                                       // 000000815608: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000081560C: BF870123
	v_dot2_f32_bf16 v5, v41, v61, v5                           // 000000815610: CC1A4005 1C167B29
	v_add_co_ci_u32_e64 v43, null, s14, v43, vcc_lo            // 000000815618: D5207C2B 01AA560E
	v_fmac_f32_e32 v21, v29, v5                                // 000000815620: 562A0B1D
	s_clause 0x3                                               // 000000815624: BF850003
	global_load_b128 v[5:8], v[38:39], off                     // 000000815628: DC5E0000 057C0026
	global_load_b128 v[30:33], v[38:39], off offset:16         // 000000815630: DC5E0010 1E7C0026
	global_load_b128 v[34:37], v[38:39], off offset:32         // 000000815638: DC5E0020 227C0026
	global_load_b128 v[38:41], v[38:39], off offset:48         // 000000815640: DC5E0030 267C0026
	s_waitcnt vmcnt(3)                                         // 000000815648: BF890FF7
	v_dot2_f32_bf16 v5, v5, v46, 0                             // 00000081564C: CC1A4005 1A025D05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000815654: BF870091
	v_dot2_f32_bf16 v5, v6, v47, v5                            // 000000815658: CC1A4005 1C165F06
	v_dot2_f32_bf16 v5, v7, v48, v5                            // 000000815660: CC1A4005 1C166107
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000815668: BF8700A1
	v_dot2_f32_bf16 v5, v8, v49, v5                            // 00000081566C: CC1A4005 1C166308
	s_waitcnt vmcnt(2)                                         // 000000815674: BF890BF7
	v_dot2_f32_bf16 v5, v30, v50, v5                           // 000000815678: CC1A4005 1C16651E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000815680: BF870091
	v_dot2_f32_bf16 v5, v31, v51, v5                           // 000000815684: CC1A4005 1C16671F
	v_dot2_f32_bf16 v5, v32, v52, v5                           // 00000081568C: CC1A4005 1C166920
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000815694: BF8700A1
	v_dot2_f32_bf16 v5, v33, v53, v5                           // 000000815698: CC1A4005 1C166B21
	s_waitcnt vmcnt(1)                                         // 0000008156A0: BF8907F7
	v_dot2_f32_bf16 v5, v34, v54, v5                           // 0000008156A4: CC1A4005 1C166D22
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008156AC: BF870091
	v_dot2_f32_bf16 v5, v35, v55, v5                           // 0000008156B0: CC1A4005 1C166F23
	v_dot2_f32_bf16 v5, v36, v56, v5                           // 0000008156B8: CC1A4005 1C167124
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008156C0: BF8700A1
	v_dot2_f32_bf16 v5, v37, v57, v5                           // 0000008156C4: CC1A4005 1C167325
	s_waitcnt vmcnt(0)                                         // 0000008156CC: BF8903F7
	v_dot2_f32_bf16 v5, v38, v58, v5                           // 0000008156D0: CC1A4005 1C167526
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008156D8: BF870091
	v_dot2_f32_bf16 v5, v39, v59, v5                           // 0000008156DC: CC1A4005 1C167727
	v_dot2_f32_bf16 v5, v40, v60, v5                           // 0000008156E4: CC1A4005 1C167928
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008156EC: BF870091
	v_dot2_f32_bf16 v5, v41, v61, v5                           // 0000008156F0: CC1A4005 1C167B29
	v_fmac_f32_e32 v25, v29, v5                                // 0000008156F8: 56320B1D
	s_clause 0x3                                               // 0000008156FC: BF850003
	global_load_b128 v[5:8], v[44:45], off                     // 000000815700: DC5E0000 057C002C
	global_load_b128 v[30:33], v[44:45], off offset:16         // 000000815708: DC5E0010 1E7C002C
	global_load_b128 v[34:37], v[44:45], off offset:32         // 000000815710: DC5E0020 227C002C
	global_load_b128 v[38:41], v[44:45], off offset:48         // 000000815718: DC5E0030 267C002C
	s_waitcnt vmcnt(3)                                         // 000000815720: BF890FF7
	v_dot2_f32_bf16 v5, v5, v46, 0                             // 000000815724: CC1A4005 1A025D05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000081572C: BF870091
	v_dot2_f32_bf16 v5, v6, v47, v5                            // 000000815730: CC1A4005 1C165F06
	v_dot2_f32_bf16 v5, v7, v48, v5                            // 000000815738: CC1A4005 1C166107
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000815740: BF8700A1
	v_dot2_f32_bf16 v5, v8, v49, v5                            // 000000815744: CC1A4005 1C166308
	s_waitcnt vmcnt(2)                                         // 00000081574C: BF890BF7
	v_dot2_f32_bf16 v5, v30, v50, v5                           // 000000815750: CC1A4005 1C16651E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000815758: BF870091
	v_dot2_f32_bf16 v5, v31, v51, v5                           // 00000081575C: CC1A4005 1C16671F
	v_dot2_f32_bf16 v5, v32, v52, v5                           // 000000815764: CC1A4005 1C166920
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000081576C: BF8700A1
	v_dot2_f32_bf16 v5, v33, v53, v5                           // 000000815770: CC1A4005 1C166B21
	s_waitcnt vmcnt(1)                                         // 000000815778: BF8907F7
	v_dot2_f32_bf16 v5, v34, v54, v5                           // 00000081577C: CC1A4005 1C166D22
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000815784: BF870091
	v_dot2_f32_bf16 v5, v35, v55, v5                           // 000000815788: CC1A4005 1C166F23
	v_dot2_f32_bf16 v5, v36, v56, v5                           // 000000815790: CC1A4005 1C167124
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000815798: BF8700A1
	v_dot2_f32_bf16 v5, v37, v57, v5                           // 00000081579C: CC1A4005 1C167325
	s_waitcnt vmcnt(0)                                         // 0000008157A4: BF8903F7
	v_dot2_f32_bf16 v5, v38, v58, v5                           // 0000008157A8: CC1A4005 1C167526
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008157B0: BF870091
	v_dot2_f32_bf16 v5, v39, v59, v5                           // 0000008157B4: CC1A4005 1C167727
	v_dot2_f32_bf16 v5, v40, v60, v5                           // 0000008157BC: CC1A4005 1C167928
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008157C4: BF870091
	v_dot2_f32_bf16 v5, v41, v61, v5                           // 0000008157C8: CC1A4005 1C167B29
	v_fmac_f32_e32 v24, v29, v5                                // 0000008157D0: 56300B1D
	s_clause 0x3                                               // 0000008157D4: BF850003
	global_load_b128 v[5:8], v[42:43], off                     // 0000008157D8: DC5E0000 057C002A
	global_load_b128 v[30:33], v[42:43], off offset:16         // 0000008157E0: DC5E0010 1E7C002A
	global_load_b128 v[34:37], v[42:43], off offset:32         // 0000008157E8: DC5E0020 227C002A
	global_load_b128 v[38:41], v[42:43], off offset:48         // 0000008157F0: DC5E0030 267C002A
	s_waitcnt vmcnt(3)                                         // 0000008157F8: BF890FF7
	v_dot2_f32_bf16 v5, v5, v46, 0                             // 0000008157FC: CC1A4005 1A025D05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000815804: BF870091
	v_dot2_f32_bf16 v5, v6, v47, v5                            // 000000815808: CC1A4005 1C165F06
	v_dot2_f32_bf16 v5, v7, v48, v5                            // 000000815810: CC1A4005 1C166107
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000815818: BF8700A1
	v_dot2_f32_bf16 v5, v8, v49, v5                            // 00000081581C: CC1A4005 1C166308
	s_waitcnt vmcnt(2)                                         // 000000815824: BF890BF7
	v_dot2_f32_bf16 v5, v30, v50, v5                           // 000000815828: CC1A4005 1C16651E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000815830: BF870091
	v_dot2_f32_bf16 v5, v31, v51, v5                           // 000000815834: CC1A4005 1C16671F
	v_dot2_f32_bf16 v5, v32, v52, v5                           // 00000081583C: CC1A4005 1C166920
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000815844: BF8700A1
	v_dot2_f32_bf16 v5, v33, v53, v5                           // 000000815848: CC1A4005 1C166B21
	s_waitcnt vmcnt(1)                                         // 000000815850: BF8907F7
	v_dot2_f32_bf16 v5, v34, v54, v5                           // 000000815854: CC1A4005 1C166D22
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000081585C: BF870091
	v_dot2_f32_bf16 v5, v35, v55, v5                           // 000000815860: CC1A4005 1C166F23
	v_dot2_f32_bf16 v5, v36, v56, v5                           // 000000815868: CC1A4005 1C167124
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000815870: BF8700A1
	v_dot2_f32_bf16 v5, v37, v57, v5                           // 000000815874: CC1A4005 1C167325
	s_waitcnt vmcnt(0)                                         // 00000081587C: BF8903F7
	v_dot2_f32_bf16 v5, v38, v58, v5                           // 000000815880: CC1A4005 1C167526
	.long 0xd7006a26                                           // 000000815888: D7006A26
	v_cndmask_b32_e32 v0, v44, v4, vcc_lo                      // 00000081588C: 0200092C
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000815890: BF870122
	v_dot2_f32_bf16 v5, v39, v59, v5                           // 000000815894: CC1A4005 1C167727
	v_add_co_ci_u32_e64 v39, null, s5, v45, vcc_lo             // 00000081589C: D5207C27 01AA5A05
	v_dot2_f32_bf16 v5, v40, v60, v5                           // 0000008158A4: CC1A4005 1C167928
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008158AC: BF870091
	v_dot2_f32_bf16 v5, v41, v61, v5                           // 0000008158B0: CC1A4005 1C167B29
	v_fmac_f32_e32 v23, v29, v5                                // 0000008158B8: 562E0B1D
	s_clause 0x3                                               // 0000008158BC: BF850003
	global_load_b128 v[5:8], v[38:39], off                     // 0000008158C0: DC5E0000 057C0026
	global_load_b128 v[30:33], v[38:39], off offset:16         // 0000008158C8: DC5E0010 1E7C0026
	global_load_b128 v[34:37], v[38:39], off offset:32         // 0000008158D0: DC5E0020 227C0026
	global_load_b128 v[38:41], v[38:39], off offset:48         // 0000008158D8: DC5E0030 267C0026
	s_waitcnt vmcnt(3)                                         // 0000008158E0: BF890FF7
	v_dot2_f32_bf16 v5, v5, v46, 0                             // 0000008158E4: CC1A4005 1A025D05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008158EC: BF870091
	v_dot2_f32_bf16 v5, v6, v47, v5                            // 0000008158F0: CC1A4005 1C165F06
	v_dot2_f32_bf16 v5, v7, v48, v5                            // 0000008158F8: CC1A4005 1C166107
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000815900: BF8700A1
	v_dot2_f32_bf16 v5, v8, v49, v5                            // 000000815904: CC1A4005 1C166308
	s_waitcnt vmcnt(2)                                         // 00000081590C: BF890BF7
	v_dot2_f32_bf16 v5, v30, v50, v5                           // 000000815910: CC1A4005 1C16651E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000815918: BF870091
	v_dot2_f32_bf16 v5, v31, v51, v5                           // 00000081591C: CC1A4005 1C16671F
	v_dot2_f32_bf16 v5, v32, v52, v5                           // 000000815924: CC1A4005 1C166920
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000081592C: BF8700A1
	v_dot2_f32_bf16 v5, v33, v53, v5                           // 000000815930: CC1A4005 1C166B21
	s_waitcnt vmcnt(1)                                         // 000000815938: BF8907F7
	v_dot2_f32_bf16 v5, v34, v54, v5                           // 00000081593C: CC1A4005 1C166D22
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000815944: BF870091
	v_dot2_f32_bf16 v5, v35, v55, v5                           // 000000815948: CC1A4005 1C166F23
	v_dot2_f32_bf16 v5, v36, v56, v5                           // 000000815950: CC1A4005 1C167124
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000815958: BF8700A1
	v_dot2_f32_bf16 v5, v37, v57, v5                           // 00000081595C: CC1A4005 1C167325
	s_waitcnt vmcnt(0)                                         // 000000815964: BF8903F7
	v_dot2_f32_bf16 v5, v38, v58, v5                           // 000000815968: CC1A4005 1C167526
	.long 0xd7006a26                                           // 000000815970: D7006A26
	v_cndmask_b32_e32 v0, v42, v4, vcc_lo                      // 000000815974: 0200092A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000815978: BF870122
	v_dot2_f32_bf16 v5, v39, v59, v5                           // 00000081597C: CC1A4005 1C167727
	v_add_co_ci_u32_e64 v39, null, s5, v43, vcc_lo             // 000000815984: D5207C27 01AA5605
	v_dot2_f32_bf16 v5, v40, v60, v5                           // 00000081598C: CC1A4005 1C167928
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000815994: BF870091
	v_dot2_f32_bf16 v5, v41, v61, v5                           // 000000815998: CC1A4005 1C167B29
	v_fmac_f32_e32 v22, v29, v5                                // 0000008159A0: 562C0B1D
	s_clause 0x3                                               // 0000008159A4: BF850003
	global_load_b128 v[5:8], v[38:39], off                     // 0000008159A8: DC5E0000 057C0026
	global_load_b128 v[30:33], v[38:39], off offset:16         // 0000008159B0: DC5E0010 1E7C0026
	global_load_b128 v[34:37], v[38:39], off offset:32         // 0000008159B8: DC5E0020 227C0026
	global_load_b128 v[38:41], v[38:39], off offset:48         // 0000008159C0: DC5E0030 267C0026
	s_waitcnt vmcnt(3)                                         // 0000008159C8: BF890FF7
	v_dot2_f32_bf16 v5, v5, v46, 0                             // 0000008159CC: CC1A4005 1A025D05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000008159D4: BF870121
	v_dot2_f32_bf16 v5, v6, v47, v5                            // 0000008159D8: CC1A4005 1C165F06
	v_mov_b32_e32 v6, v2                                       // 0000008159E0: 7E0C0302
	v_dot2_f32_bf16 v5, v7, v48, v5                            // 0000008159E4: CC1A4005 1C166107
	v_mov_b32_e32 v7, v3                                       // 0000008159EC: 7E0E0303
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000008159F0: BF870132
	v_dot2_f32_bf16 v5, v8, v49, v5                            // 0000008159F4: CC1A4005 1C166308
	v_mov_b32_e32 v8, v4                                       // 0000008159FC: 7E100304
	s_waitcnt vmcnt(2)                                         // 000000815A00: BF890BF7
	v_dot2_f32_bf16 v5, v30, v50, v5                           // 000000815A04: CC1A4005 1C16651E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000815A0C: BF870091
	v_dot2_f32_bf16 v5, v31, v51, v5                           // 000000815A10: CC1A4005 1C16671F
	v_dot2_f32_bf16 v5, v32, v52, v5                           // 000000815A18: CC1A4005 1C166920
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000815A20: BF8700A1
	v_dot2_f32_bf16 v5, v33, v53, v5                           // 000000815A24: CC1A4005 1C166B21
	s_waitcnt vmcnt(1)                                         // 000000815A2C: BF8907F7
	v_dot2_f32_bf16 v5, v34, v54, v5                           // 000000815A30: CC1A4005 1C166D22
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000815A38: BF870091
	v_dot2_f32_bf16 v5, v35, v55, v5                           // 000000815A3C: CC1A4005 1C166F23
	v_dot2_f32_bf16 v5, v36, v56, v5                           // 000000815A44: CC1A4005 1C167124
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000815A4C: BF8700A1
	v_dot2_f32_bf16 v5, v37, v57, v5                           // 000000815A50: CC1A4005 1C167325
	s_waitcnt vmcnt(0)                                         // 000000815A58: BF8903F7
	v_dot2_f32_bf16 v5, v38, v58, v5                           // 000000815A5C: CC1A4005 1C167526
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000815A64: BF870091
	v_dot2_f32_bf16 v5, v39, v59, v5                           // 000000815A68: CC1A4005 1C167727
	v_dot2_f32_bf16 v5, v40, v60, v5                           // 000000815A70: CC1A4005 1C167928
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000815A78: BF870091
	v_dot2_f32_bf16 v5, v41, v61, v5                           // 000000815A7C: CC1A4005 1C167B29
	v_fmac_f32_e32 v17, v29, v5                                // 000000815A84: 56220B1D
	v_mov_b32_e32 v5, v1                                       // 000000815A88: 7E0A0301
	v_mov_b32_e32 v29, v28                                     // 000000815A8C: 7E3A031C
	s_and_not1_b32 exec_lo, exec_lo, s15                       // 000000815A90: 917E0F7E
	s_cbranch_execz 31                                         // 000000815A94: BFA5001F <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi8ELb0ELi2ELi0EEEvPKhPKtPvlllllS6_f+0xa14>
	s_waitcnt vmcnt(0)                                         // 000000815A98: BF8903F7
	v_dual_mov_b32 v1, v5 :: v_dual_add_nc_u32 v10, 32, v10    // 000000815A9C: CA200105 010A14A0
	v_dual_mov_b32 v2, v6 :: v_dual_mov_b32 v3, v7             // 000000815AA4: CA100106 02020107
	v_mov_b32_e32 v4, v8                                       // 000000815AAC: 7E080308
	s_mov_b32 s17, exec_lo                                     // 000000815AB0: BE91007E
	s_delay_alu instid0(VALU_DEP_3)                            // 000000815AB4: BF870003
	v_cmp_ge_i32_e32 vcc_lo, v10, v18                          // 000000815AB8: 7C8C250A
	.long 0xd4c1007e                                           // 000000815ABC: D4C1007E
	v_cndmask_b32_e32 v1, v10, v18, vcc_lo                     // 000000815AC0: 0202250A
	s_cbranch_execz 65057                                      // 000000815AC4: BFA5FE21 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi8ELb0ELi2ELi0EEEvPKhPKtPvlllllS6_f+0x24c>
	v_ashrrev_i32_e32 v2, 31, v27                              // 000000815AC8: 3404369F
	v_ashrrev_i32_e32 v4, 31, v26                              // 000000815ACC: 3408349F
	.long 0xd7000001                                           // 000000815AD0: D7000001
	v_cndmask_b32_e32 v1, v11, v27, vcc_lo                     // 000000815AD4: 0202370B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000815AD8: BF8700A1
	v_add_co_ci_u32_e64 v2, null, v20, v2, s0                  // 000000815ADC: D5207C02 00020514
	.long 0xd7000003                                           // 000000815AE4: D7000003
	v_cndmask_b32_e32 v1, v9, v26, vcc_lo                      // 000000815AE8: 02023509
	v_add_co_ci_u32_e64 v4, null, v19, v4, s0                  // 000000815AEC: D5207C04 00020913
	s_clause 0x1                                               // 000000815AF4: BF850001
	global_load_d16_b16 v13, v[1:2], off                       // 000000815AF8: DC820000 0D7C0001
	global_load_b128 v[1:4], v[3:4], off                       // 000000815B00: DC5E0000 017C0003
	s_waitcnt vmcnt(1)                                         // 000000815B08: BF8907F7
	v_cvt_f32_f16_e32 v28, v13                                 // 000000815B0C: 7E38170D
	s_branch 65038                                             // 000000815B10: BFA0FE0E <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi8ELb0ELi2ELi0EEEvPKhPKtPvlllllS6_f+0x24c>
	s_or_b32 exec_lo, exec_lo, s15                             // 000000815B14: 8C7E0F7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000815B18: BF8700B9
	s_or_b32 exec_lo, exec_lo, s1                              // 000000815B1C: 8C7E017E
	.long 0xd71f0001                                           // 000000815B20: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 000000815B24: 020100C1
	s_mov_b32 s0, exec_lo                                      // 000000815B28: BE80007E
	v_xor_b32_e32 v2, 16, v1                                   // 000000815B2C: 3A040290
	s_waitcnt vmcnt(0)                                         // 000000815B30: BF8903F7
	v_xor_b32_e32 v8, 8, v1                                    // 000000815B34: 3A100288
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000815B38: BF8701A2
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 000000815B3C: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 000000815B40: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v8                            // 000000815B44: 7C9810A0
	s_delay_alu instid0(VALU_DEP_2)                            // 000000815B48: BF870002
	v_lshlrev_b32_e32 v2, 2, v2                                // 000000815B4C: 30040482
	ds_bpermute_b32 v3, v2, v21                                // 000000815B50: DACC0000 03001502
	s_waitcnt lgkmcnt(0)                                       // 000000815B58: BF89FC07
	v_add_f32_e32 v3, v21, v3                                  // 000000815B5C: 06060715
	ds_bpermute_b32 v4, v2, v25                                // 000000815B60: DACC0000 04001902
	ds_bpermute_b32 v5, v2, v24                                // 000000815B68: DACC0000 05001802
	ds_bpermute_b32 v6, v2, v23                                // 000000815B70: DACC0000 06001702
	ds_bpermute_b32 v7, v2, v22                                // 000000815B78: DACC0000 07001602
	ds_bpermute_b32 v2, v2, v17                                // 000000815B80: DACC0000 02001102
	s_waitcnt lgkmcnt(3)                                       // 000000815B88: BF89FC37
	v_dual_cndmask_b32 v8, v1, v8 :: v_dual_add_f32 v5, v24, v5// 000000815B8C: CA481101 08040B18
	s_waitcnt lgkmcnt(0)                                       // 000000815B94: BF89FC07
	v_dual_add_f32 v7, v22, v7 :: v_dual_add_f32 v2, v17, v2   // 000000815B98: C9080F16 07020511
	v_xor_b32_e32 v17, 4, v1                                   // 000000815BA0: 3A220284
	s_delay_alu instid0(VALU_DEP_1)                            // 000000815BA4: BF870001
	v_cmp_gt_u32_e32 vcc_lo, 32, v17                           // 000000815BA8: 7C9822A0
	v_dual_cndmask_b32 v17, v1, v17 :: v_dual_lshlrev_b32 v8, 2, v8// 000000815BAC: CA622301 11081082
	ds_bpermute_b32 v9, v8, v3                                 // 000000815BB4: DACC0000 09000308
	ds_bpermute_b32 v11, v8, v5                                // 000000815BBC: DACC0000 0B000508
	v_add_f32_e32 v4, v25, v4                                  // 000000815BC4: 06080919
	v_add_f32_e32 v6, v23, v6                                  // 000000815BC8: 060C0D17
	ds_bpermute_b32 v13, v8, v7                                // 000000815BCC: DACC0000 0D000708
	v_lshlrev_b32_e32 v17, 2, v17                              // 000000815BD4: 30222282
	ds_bpermute_b32 v10, v8, v4                                // 000000815BD8: DACC0000 0A000408
	s_waitcnt lgkmcnt(3)                                       // 000000815BE0: BF89FC37
	v_add_f32_e32 v3, v3, v9                                   // 000000815BE4: 06061303
	s_waitcnt lgkmcnt(2)                                       // 000000815BE8: BF89FC27
	v_add_f32_e32 v5, v5, v11                                  // 000000815BEC: 060A1705
	ds_bpermute_b32 v12, v8, v6                                // 000000815BF0: DACC0000 0C000608
	ds_bpermute_b32 v8, v8, v2                                 // 000000815BF8: DACC0000 08000208
	s_waitcnt lgkmcnt(2)                                       // 000000815C00: BF89FC27
	v_dual_add_f32 v7, v7, v13 :: v_dual_add_f32 v4, v4, v10   // 000000815C04: C9081B07 07041504
	ds_bpermute_b32 v10, v17, v5                               // 000000815C0C: DACC0000 0A000511
	ds_bpermute_b32 v9, v17, v4                                // 000000815C14: DACC0000 09000411
	s_waitcnt lgkmcnt(3)                                       // 000000815C1C: BF89FC37
	v_add_f32_e32 v6, v6, v12                                  // 000000815C20: 060C1906
	s_waitcnt lgkmcnt(2)                                       // 000000815C24: BF89FC27
	v_add_f32_e32 v2, v2, v8                                   // 000000815C28: 06041102
	ds_bpermute_b32 v8, v17, v3                                // 000000815C2C: DACC0000 08000311
	ds_bpermute_b32 v12, v17, v7                               // 000000815C34: DACC0000 0C000711
	ds_bpermute_b32 v11, v17, v6                               // 000000815C3C: DACC0000 0B000611
	ds_bpermute_b32 v13, v17, v2                               // 000000815C44: DACC0000 0D000211
	v_xor_b32_e32 v17, 2, v1                                   // 000000815C4C: 3A220282
	s_waitcnt lgkmcnt(4)                                       // 000000815C50: BF89FC47
	v_add_f32_e32 v4, v4, v9                                   // 000000815C54: 06081304
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000815C58: BF870132
	v_cmp_gt_u32_e32 vcc_lo, 32, v17                           // 000000815C5C: 7C9822A0
	v_cndmask_b32_e32 v17, v1, v17, vcc_lo                     // 000000815C60: 02222301
	v_add_f32_e32 v5, v5, v10                                  // 000000815C64: 060A1505
	v_lshlrev_b32_e32 v17, 2, v17                              // 000000815C68: 30222282
	s_waitcnt lgkmcnt(3)                                       // 000000815C6C: BF89FC37
	v_add_f32_e32 v3, v3, v8                                   // 000000815C70: 06061103
	s_waitcnt lgkmcnt(1)                                       // 000000815C74: BF89FC17
	v_dual_add_f32 v7, v7, v12 :: v_dual_add_f32 v6, v6, v11   // 000000815C78: C9081907 07061706
	s_waitcnt lgkmcnt(0)                                       // 000000815C80: BF89FC07
	v_add_f32_e32 v8, v2, v13                                  // 000000815C84: 06101B02
	ds_bpermute_b32 v9, v17, v4                                // 000000815C88: DACC0000 09000411
	ds_bpermute_b32 v2, v17, v3                                // 000000815C90: DACC0000 02000311
	ds_bpermute_b32 v10, v17, v5                               // 000000815C98: DACC0000 0A000511
	ds_bpermute_b32 v11, v17, v6                               // 000000815CA0: DACC0000 0B000611
	ds_bpermute_b32 v12, v17, v7                               // 000000815CA8: DACC0000 0C000711
	ds_bpermute_b32 v13, v17, v8                               // 000000815CB0: DACC0000 0D000811
	v_xor_b32_e32 v17, 1, v1                                   // 000000815CB8: 3A220281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000815CBC: BF8700A1
	v_cmp_gt_u32_e32 vcc_lo, 32, v17                           // 000000815CC0: 7C9822A0
	v_cndmask_b32_e32 v1, v1, v17, vcc_lo                      // 000000815CC4: 02022301
	v_lshlrev_b32_e32 v17, 2, v1                               // 000000815CC8: 30220282
	s_waitcnt lgkmcnt(4)                                       // 000000815CCC: BF89FC47
	v_dual_add_f32 v1, v3, v2 :: v_dual_add_f32 v2, v4, v9     // 000000815CD0: C9080503 01021304
	s_waitcnt lgkmcnt(2)                                       // 000000815CD8: BF89FC27
	v_dual_add_f32 v4, v5, v10 :: v_dual_add_f32 v5, v6, v11   // 000000815CDC: C9081505 04041706
	s_waitcnt lgkmcnt(1)                                       // 000000815CE4: BF89FC17
	v_add_f32_e32 v3, v7, v12                                  // 000000815CE8: 06061907
	s_waitcnt lgkmcnt(0)                                       // 000000815CEC: BF89FC07
	v_add_f32_e32 v9, v8, v13                                  // 000000815CF0: 06121B08
	ds_bpermute_b32 v6, v17, v1                                // 000000815CF4: DACC0000 06000111
	ds_bpermute_b32 v7, v17, v2                                // 000000815CFC: DACC0000 07000211
	ds_bpermute_b32 v10, v17, v4                               // 000000815D04: DACC0000 0A000411
	ds_bpermute_b32 v11, v17, v5                               // 000000815D0C: DACC0000 0B000511
	ds_bpermute_b32 v8, v17, v3                                // 000000815D14: DACC0000 08000311
	ds_bpermute_b32 v12, v17, v9                               // 000000815D1C: DACC0000 0C000911
	v_cmpx_eq_u32_e32 0, v16                                   // 000000815D24: 7D942080
	s_cbranch_execz 12                                         // 000000815D28: BFA5000C <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi8ELb0ELi2ELi0EEEvPKhPKtPvlllllS6_f+0xc5c>
	s_waitcnt lgkmcnt(0)                                       // 000000815D2C: BF89FC07
	v_dual_add_f32 v9, v9, v12 :: v_dual_add_f32 v4, v4, v10   // 000000815D30: C9081909 09041504
	v_dual_add_f32 v5, v5, v11 :: v_dual_add_f32 v8, v3, v8    // 000000815D38: C9081705 05081103
	v_dual_add_f32 v2, v2, v7 :: v_dual_add_f32 v1, v1, v6     // 000000815D40: C9080F02 02000D01
	v_mul_u32_u24_e32 v6, 24, v15                              // 000000815D48: 160C1E98
	ds_store_2addr_b64 v6, v[1:2], v[4:5] offset0:128 offset1:129// 000000815D4C: D9388180 00040106
	ds_store_b64 v6, v[8:9] offset:1040                        // 000000815D54: D9340410 00000806
	s_or_b32 exec_lo, exec_lo, s0                              // 000000815D5C: 8C7E007E
	.long 0xd4510000                                           // 000000815D60: D4510000
	v_cndmask_b32_e32 v0, s2, v12, vcc_lo                      // 000000815D64: 02001802
	v_cmp_gt_u32_e32 vcc_lo, 6, v0                             // 000000815D68: 7C980086
	s_waitcnt lgkmcnt(0)                                       // 000000815D6C: BF89FC07
	s_barrier                                                  // 000000815D70: BFBD0000
	buffer_gl0_inv                                             // 000000815D74: E0AC0000 00000000
	s_and_b32 s0, vcc_lo, s0                                   // 000000815D7C: 8B00006A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000815D80: BF870009
	s_and_saveexec_b32 s1, s0                                  // 000000815D84: BE812000
	s_cbranch_execz 88                                         // 000000815D88: BFA50058 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi8ELb0ELi2ELi0EEEvPKhPKtPvlllllS6_f+0xdec>
	v_add_nc_u32_e32 v7, 0x400, v14                            // 000000815D8C: 4A0E1CFF 00000400
	s_lshl_b64 s[0:1], s[2:3], 1                               // 000000815D94: 84808102
	ds_load_2addr_b32 v[1:2], v7 offset1:6                     // 000000815D98: D8DC0600 01000007
	ds_load_2addr_b32 v[3:4], v7 offset0:12 offset1:18         // 000000815DA0: D8DC120C 03000007
	ds_load_2addr_b32 v[5:6], v7 offset0:24 offset1:30         // 000000815DA8: D8DC1E18 05000007
	s_waitcnt lgkmcnt(2)                                       // 000000815DB0: BF89FC27
	v_add_f32_e32 v1, 0, v1                                    // 000000815DB4: 06020280
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000815DB8: BF8700C1
	v_add_f32_e32 v8, v1, v2                                   // 000000815DBC: 06100501
	ds_load_2addr_b32 v[1:2], v7 offset0:36 offset1:42         // 000000815DC0: D8DC2A24 01000007
	s_waitcnt lgkmcnt(2)                                       // 000000815DC8: BF89FC27
	v_add_f32_e32 v3, v8, v3                                   // 000000815DCC: 06060708
	v_add_f32_e32 v3, v3, v4                                   // 000000815DD0: 06060903
	s_waitcnt lgkmcnt(1)                                       // 000000815DD4: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000815DD8: BF870091
	v_add_f32_e32 v3, v3, v5                                   // 000000815DDC: 06060B03
	v_add_f32_e32 v3, v3, v6                                   // 000000815DE0: 06060D03
	s_waitcnt lgkmcnt(0)                                       // 000000815DE4: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000815DE8: BF870091
	v_add_f32_e32 v1, v3, v1                                   // 000000815DEC: 06020303
	v_add_f32_e32 v1, v1, v2                                   // 000000815DF0: 06020501
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000815DF4: BF870091
	v_bfe_u32 v2, v1, 16, 1                                    // 000000815DF8: D6100002 02052101
	v_add3_u32 v1, v1, v2, 0x7fff                              // 000000815E00: D6550001 03FE0501 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000815E0C: BF870091
	v_and_b32_e32 v1, 0xffff0000, v1                           // 000000815E10: 360202FF FFFF0000
	v_mul_f32_e32 v1, 0xbfb8aa3b, v1                           // 000000815E18: 100202FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000815E20: BF870291
	v_exp_f32_e32 v1, v1                                       // 000000815E24: 7E024B01
	v_add_f32_e32 v4, 1.0, v1                                  // 000000815E28: 060802F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000815E2C: BF870121
	v_div_scale_f32 v3, null, v4, v4, 1.0                      // 000000815E30: D6FC7C03 03CA0904
	v_div_scale_f32 v6, vcc_lo, 1.0, v4, 1.0                   // 000000815E38: D6FC6A06 03CA08F2
	v_rcp_f32_e32 v5, v3                                       // 000000815E40: 7E0A5503
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000815E44: BF870095
	v_fma_f32 v1, -v3, v5, 1.0                                 // 000000815E48: D6130001 23CA0B03
	v_fmac_f32_e32 v5, v1, v5                                  // 000000815E50: 560A0B01
	v_mad_u64_u32 v[1:2], null, s12, v0, 0                     // 000000815E54: D6FE7C01 0202000C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000815E5C: BF870092
	v_mul_f32_e32 v7, v6, v5                                   // 000000815E60: 100E0B06
	v_fma_f32 v8, -v3, v7, v6                                  // 000000815E64: D6130008 241A0F03
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000815E6C: BF870091
	v_fmac_f32_e32 v7, v8, v5                                  // 000000815E70: 560E0B08
	v_fma_f32 v6, -v3, v7, v6                                  // 000000815E74: D6130006 241A0F03
	v_mad_u64_u32 v[2:3], null, s13, v0, v[2:3]                // 000000815E7C: D6FE7C02 040A000D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000815E84: BF870092
	v_div_fmas_f32 v0, v6, v5, v7                              // 000000815E88: D6370000 041E0B06
	v_div_fixup_f32 v3, v0, v4, 1.0                            // 000000815E90: D6270003 03CA0900
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000815E98: BF870113
	.long 0xd73c0000                                           // 000000815E9C: D73C0000
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 000000815EA0: 02020281
	v_bfe_u32 v2, v3, 16, 1                                    // 000000815EA4: D6100002 02052103
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000815EAC: BF870092
	.long 0xd7006a00                                           // 000000815EB0: D7006A00
	v_cndmask_b32_e32 v1, s8, v0, vcc_lo                       // 000000815EB4: 02020008
	v_add_co_ci_u32_e64 v1, null, s9, v1, vcc_lo               // 000000815EB8: D5207C01 01AA0209
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000815EC0: BF870193
	v_add3_u32 v2, v3, v2, 0x7fff                              // 000000815EC4: D6550002 03FE0503 00007FFF
	.long 0xd7006a00                                           // 000000815ED0: D7006A00
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 000000815ED4: 02000100
	s_delay_alu instid0(VALU_DEP_1)                            // 000000815ED8: BF870001
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 000000815EDC: D5207C01 01AA0201
	global_store_d16_hi_b16 v[0:1], v2, off                    // 000000815EE4: DC960000 007C0200
	s_endpgm                                                   // 000000815EEC: BFB00000
		...

