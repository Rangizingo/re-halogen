000000000034f200 <_ZN7halogen12_GLOBAL__N_16k_lq6wILi7ELi32ELi1EEEvPKhPKtPtll>:
; _ZN7halogen12_GLOBAL__N_16k_lq6wILi7ELi32ELi1EEEvPKhPKtPtll():
	s_load_b256 s[4:11], s[0:1], null                          // 00000034F200: F40C0100 F8000000
	s_mov_b32 s3, 0                                            // 00000034F208: BE830080
	v_lshrrev_b32_e32 v1, 5, v0                                // 00000034F20C: 32020085
	s_lshl_b64 s[12:13], s[2:3], 3                             // 00000034F210: 848C8302
	s_load_b64 s[2:3], s[0:1], 0x20                            // 00000034F214: F4040080 F8000020
	v_mov_b32_e32 v9, s13                                      // 00000034F21C: 7E12020D
	v_dual_mov_b32 v6, 0 :: v_dual_and_b32 v17, 31, v0         // 00000034F220: CA240080 0610009F
	v_or_b32_e32 v8, s12, v1                                   // 00000034F228: 3810020C
	v_dual_mov_b32 v4, 0 :: v_dual_mov_b32 v5, 0               // 00000034F22C: CA100080 04040080
	v_dual_mov_b32 v7, 0 :: v_dual_mov_b32 v16, 0              // 00000034F234: CA100080 07100080
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(SALU_CYCLE_1)// 00000034F23C: BF8704D3
	.long 0xd73c0001                                           // 00000034F240: D73C0001
	v_cndmask_b32_e32 v1, 4, v8, vcc_lo                        // 00000034F244: 02021084
	v_dual_mov_b32 v15, 0 :: v_dual_mov_b32 v46, 0             // 00000034F248: CA100080 0F2E0080
	v_mov_b32_e32 v18, 0                                       // 00000034F250: 7E240280
	s_waitcnt lgkmcnt(0)                                       // 00000034F254: BF89FC07
	s_ashr_i32 s16, s11, 31                                    // 00000034F258: 86109F0B
	s_lshr_b32 s0, s16, 27                                     // 00000034F25C: 85009B10
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000034F260: BF870009
	s_add_u32 s0, s10, s0                                      // 00000034F264: 8000000A
	s_addc_u32 s1, s11, 0                                      // 00000034F268: 8201800B
	s_lshr_b32 s14, s11, 31                                    // 00000034F26C: 850E9F0B
	s_lshr_b64 s[12:13], s[0:1], 5                             // 00000034F270: 858C8500
	s_add_u32 s0, s10, s14                                     // 00000034F274: 80000E0A
	s_addc_u32 s1, s11, 0                                      // 00000034F278: 8201800B
	s_lshr_b32 s13, s16, 30                                    // 00000034F27C: 850D9E10
	s_ashr_i64 s[14:15], s[0:1], 1                             // 00000034F280: 868E8100
	s_add_u32 s0, s10, s13                                     // 00000034F284: 80000D0A
	s_addc_u32 s1, s11, 0                                      // 00000034F288: 8201800B
	s_lshr_b32 s13, s16, 28                                    // 00000034F28C: 850D9C10
	s_ashr_i64 s[16:17], s[0:1], 2                             // 00000034F290: 86908200
	s_add_u32 s0, s10, s13                                     // 00000034F294: 80000D0A
	s_addc_u32 s1, s11, 0                                      // 00000034F298: 8201800B
	v_cmp_gt_i64_e32 vcc_lo, s[2:3], v[8:9]                    // 00000034F29C: 7CA81002
	s_ashr_i64 s[0:1], s[0:1], 4                               // 00000034F2A0: 86808400
	s_add_u32 s13, s16, s14                                    // 00000034F2A4: 800D0E10
	s_addc_u32 s18, s17, s15                                   // 00000034F2A8: 82120F11
	s_add_u32 s0, s13, s0                                      // 00000034F2AC: 8000000D
	s_addc_u32 s1, s18, s1                                     // 00000034F2B0: 82010112
	s_add_u32 s0, s0, 15                                       // 00000034F2B4: 80008F00
	s_addc_u32 s1, s1, 0                                       // 00000034F2B8: 82018001
	v_cndmask_b32_e32 v2, 0, v2, vcc_lo                        // 00000034F2BC: 02040480
	s_ashr_i32 s13, s1, 31                                     // 00000034F2C0: 860D9F01
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 00000034F2C4: 02020280
	s_lshr_b32 s13, s13, 28                                    // 00000034F2C8: 850D9C0D
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000034F2CC: BF8704A9
	s_add_u32 s0, s0, s13                                      // 00000034F2D0: 80000D00
	s_addc_u32 s1, s1, 0                                       // 00000034F2D4: 82018001
	s_ashr_i64 s[0:1], s[0:1], 4                               // 00000034F2D8: 86808400
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 00000034F2DC: BF870149
	.long 0xd72c0003                                           // 00000034F2E0: D72C0003
	v_cndmask_b32_e32 v0, v1, v1, vcc_lo                       // 00000034F2E4: 02000301
	.long 0xd72c0002                                           // 00000034F2E8: D72C0002
	v_cndmask_b32_e32 v0, v2, v0, vcc_lo                       // 00000034F2EC: 02000102
	v_mad_u64_u32 v[10:11], null, v1, s0, s[4:5]               // 00000034F2F0: D6FE7C0A 00100101
	.long 0xd4440000                                           // 00000034F2F8: D4440000
	v_cndmask_b32_e32 v1, s12, v17, vcc_lo                     // 00000034F2FC: 0202220C
	v_add3_u32 v19, v2, v11, v3                                // 00000034F300: D6550013 040E1702
	s_and_saveexec_b32 s4, s0                                  // 00000034F308: BE842000
	s_cbranch_execz 35                                         // 00000034F30C: BFA50023 <_ZN7halogen12_GLOBAL__N_16k_lq6wILi7ELi32ELi1EEEvPKhPKtPtll+0x19c>
	v_lshlrev_b32_e32 v1, 4, v17                               // 00000034F310: 30022284
	v_lshlrev_b32_e32 v0, 1, v0                                // 00000034F314: 30000081
	v_lshlrev_b32_e32 v5, 3, v17                               // 00000034F318: 300A2283
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034F31C: BF870093
	.long 0xd7000101                                           // 00000034F320: D7000101
	v_cndmask_b32_e32 v1, v10, v1, vcc_lo                      // 00000034F324: 0202030A
	v_add_co_ci_u32_e64 v2, null, 0, v19, s1                   // 00000034F328: D5207C02 00062680
	.long 0xd7000103                                           // 00000034F330: D7000103
	v_cndmask_b32_e32 v0, v10, v14, vcc_lo                     // 00000034F334: 02001D0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000034F338: BF8701A1
	v_add_co_ci_u32_e64 v4, null, s15, v19, s1                 // 00000034F33C: D5207C04 0006260F
	v_and_b32_e32 v0, 60, v0                                   // 00000034F344: 360000BC
	.long 0xd7000106                                           // 00000034F348: D7000106
	v_cndmask_b32_e32 v0, v3, v16, vcc_lo                      // 00000034F34C: 02002103
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000034F350: BF8700A1
	v_add_co_ci_u32_e64 v7, null, s17, v4, s1                  // 00000034F354: D5207C07 00060811
	.long 0xd700010b                                           // 00000034F35C: D700010B
	v_cndmask_b32_e32 v1, v3, v5, vcc_lo                       // 00000034F360: 02020B03
	v_add_co_ci_u32_e64 v12, null, 0, v4, s1                   // 00000034F364: D5207C0C 00060880
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034F36C: BF870094
	.long 0xd700010d                                           // 00000034F370: D700010D
	v_cndmask_b32_e32 v1, v6, v0, vcc_lo                       // 00000034F374: 02020106
	v_add_co_ci_u32_e64 v14, null, 0, v7, s1                   // 00000034F378: D5207C0E 00060E80
	s_clause 0x2                                               // 00000034F380: BF850002
	global_load_b128 v[4:7], v[1:2], off                       // 00000034F384: DC5E0000 047C0001
	global_load_b64 v[15:16], v[11:12], off                    // 00000034F38C: DC560000 0F7C000B
	global_load_b32 v46, v[13:14], off                         // 00000034F394: DC520000 2E7C000D
	s_or_b32 exec_lo, exec_lo, s4                              // 00000034F39C: 8C7E047E
	v_dual_mov_b32 v20, 0 :: v_dual_mov_b32 v21, 0             // 00000034F3A0: CA100080 14140080
	v_dual_mov_b32 v22, 0 :: v_dual_mov_b32 v23, 0             // 00000034F3A8: CA100080 16160080
	v_dual_mov_b32 v24, 0 :: v_dual_mov_b32 v25, 0             // 00000034F3B0: CA100080 18180080
	s_and_saveexec_b32 s13, s0                                 // 00000034F3B8: BE8D2000
	s_cbranch_execz 1074                                       // 00000034F3BC: BFA50432 <_ZN7halogen12_GLOBAL__N_16k_lq6wILi7ELi32ELi1EEEvPKhPKtPtll+0x1288>
	.long 0xd700001a                                           // 00000034F3C0: D700001A
	v_cndmask_b32_e32 v0, v10, v14, vcc_lo                     // 00000034F3C4: 02001D0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000034F3C8: BF8701A1
	v_add_co_ci_u32_e64 v27, null, s15, v19, s0                // 00000034F3CC: D5207C1B 0002260F
	v_dual_mov_b32 v12, 0 :: v_dual_lshlrev_b32 v11, 5, v17    // 00000034F3D4: CA220080 0C0A2285
	.long 0xd700001c                                           // 00000034F3DC: D700001C
	v_cndmask_b32_e32 v0, v26, v16, vcc_lo                     // 00000034F3E0: 0200211A
	s_delay_alu instid0(VALU_DEP_1)                            // 00000034F3E4: BF870001
	v_add_co_ci_u32_e64 v29, null, s17, v27, s0                // 00000034F3E8: D5207C1D 00023611
	v_lshl_or_b32 v30, v17, 4, 0x200                           // 00000034F3F0: D656001E 03FD0911 00000200
	v_lshl_or_b32 v31, v17, 3, 0x100                           // 00000034F3FC: D656001F 03FD0711 00000100
	v_lshl_or_b32 v32, v17, 1, 64                              // 00000034F408: D6560020 03010311
	v_dual_mov_b32 v18, v12 :: v_dual_mov_b32 v33, v17         // 00000034F410: CA10010C 12200111
	v_mov_b32_e32 v20, v12                                     // 00000034F418: 7E28030C
	s_waitcnt vmcnt(0)                                         // 00000034F41C: BF8903F7
	v_dual_mov_b32 v21, v12 :: v_dual_mov_b32 v34, v46         // 00000034F420: CA10010C 1522012E
	v_mov_b32_e32 v22, v12                                     // 00000034F428: 7E2C030C
	v_mov_b32_e32 v23, v12                                     // 00000034F42C: 7E2E030C
	v_mov_b32_e32 v24, v12                                     // 00000034F430: 7E30030C
	v_mov_b32_e32 v25, v12                                     // 00000034F434: 7E32030C
	s_mul_i32 s0, s11, 6                                       // 00000034F438: 9600860B
	s_mul_hi_u32 s1, s10, 6                                    // 00000034F43C: 9681860A
	s_lshl_b64 s[4:5], s[10:11], 2                             // 00000034F440: 8484820A
	s_add_i32 s14, s1, s0                                      // 00000034F444: 810E0001
	s_mul_i32 s16, s10, 6                                      // 00000034F448: 9610860A
	s_mov_b32 s15, 0                                           // 00000034F44C: BE8F0080
	s_lshl_b64 s[10:11], s[10:11], 1                           // 00000034F450: 848A810A
	s_branch 997                                               // 00000034F454: BFA003E5 <_ZN7halogen12_GLOBAL__N_16k_lq6wILi7ELi32ELi1EEEvPKhPKtPtll+0x11ec>
	s_or_b32 exec_lo, exec_lo, s17                             // 00000034F458: 8C7E117E
	v_lshlrev_b32_e32 v35, 4, v15                              // 00000034F45C: 30461E84
	v_lshlrev_b32_e32 v37, 2, v15                              // 00000034F460: 304A1E82
	v_lshrrev_b32_e32 v36, 4, v4                               // 00000034F464: 32480884
	.long 0x7f5e3880                                           // 00000034F468: 7F5E3880
	v_lshrrev_b32_e32 v39, 6, v15                              // 00000034F46C: 324E1E86
	v_and_b32_e32 v35, 48, v35                                 // 00000034F470: 364646B0
	v_and_b32_e32 v37, 48, v37                                 // 00000034F474: 364A4AB0
	v_lshrrev_b32_e32 v42, 22, v15                             // 00000034F478: 32541E96
	v_lshrrev_b32_e32 v45, 6, v16                              // 00000034F47C: 325A2086
	v_and_b32_e32 v39, 48, v39                                 // 00000034F480: 364E4EB0
	v_and_or_b32 v35, v4, 15, v35                              // 00000034F484: D6570023 048D1F04
	v_and_or_b32 v36, v36, 15, v37                             // 00000034F48C: D6570024 04951F24
	v_and_b32_e32 v42, 48, v42                                 // 00000034F494: 365454B0
	v_lshrrev_b32_e32 v44, 20, v6                              // 00000034F498: 32580C94
	v_and_b32_e32 v45, 48, v45                                 // 00000034F49C: 365A5AB0
	v_cvt_f32_ubyte0_e32 v35, v35                              // 00000034F4A0: 7E462323
	v_lshrrev_b32_e32 v49, 18, v16                             // 00000034F4A4: 32622092
	v_lshrrev_b32_e32 v50, 22, v16                             // 00000034F4A8: 32642096
	s_and_b32 s0, exec_lo, s0                                  // 00000034F4AC: 8B00007E
	v_and_or_b32 v44, v44, 15, v45                             // 00000034F4B0: D657002C 04B51F2C
	v_fma_mix_f32 v35, v35, v46, v46 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000034F4B8: CC206023 14BA5D23
	v_and_b32_e32 v49, 48, v49                                 // 00000034F4C0: 366262B0
	v_and_b32_e32 v50, 48, v50                                 // 00000034F4C4: 366464B0
	s_or_b32 s15, s0, s15                                      // 00000034F4C8: 8C0F0F00
	v_add_nc_u32_e32 v30, 0x200, v30                           // 00000034F4CC: 4A3C3CFF 00000200
	v_bfe_u32 v37, v35, 16, 1                                  // 00000034F4D4: D6100025 02052123
	v_add_nc_u32_e32 v31, 0x100, v31                           // 00000034F4DC: 4A3E3EFF 00000100
	v_add_nc_u32_e32 v32, 64, v32                              // 00000034F4E4: 4A4040C0
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000034F4E8: BF870123
	v_add3_u32 v35, v35, v37, 0x7fff                           // 00000034F4EC: D6550023 03FE4B23 00007FFF
	v_lshrrev_b32_e32 v37, 2, v15                              // 00000034F4F8: 324A1E82
	.long 0x7e5e39a3                                           // 00000034F4FC: 7E5E39A3
	v_cvt_f32_ubyte0_e32 v35, v36                              // 00000034F500: 7E462324
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000034F504: BF870113
	v_and_b32_e32 v37, 48, v37                                 // 00000034F508: 364A4AB0
	v_fma_mix_f32 v35, v35, v46, v46 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000034F50C: CC206023 14BA5D23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034F514: BF870091
	v_bfe_u32 v36, v35, 16, 1                                  // 00000034F518: D6100024 02052123
	v_add3_u32 v35, v35, v36, 0x7fff                           // 00000034F520: D6550023 03FE4923 00007FFF
	v_and_b32_e32 v36, 48, v15                                 // 00000034F52C: 36481EB0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000034F530: BF8700A2
	v_and_or_b32 v38, 0xffff0000, v35, v47                     // 00000034F534: D6570026 04BE46FF FFFF0000
	v_lshrrev_b32_e32 v35, 8, v4                               // 00000034F540: 32460888
	v_and_or_b32 v35, v35, 15, v36                             // 00000034F544: D6570023 04911F23
	v_lshrrev_b32_e32 v36, 12, v4                              // 00000034F54C: 3248088C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000034F550: BF870112
	v_cvt_f32_ubyte0_e32 v35, v35                              // 00000034F554: 7E462323
	v_and_or_b32 v36, v36, 15, v37                             // 00000034F558: D6570024 04951F24
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034F560: BF870092
	v_fma_mix_f32 v35, v35, v46, v46 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000034F564: CC206023 14BA5D23
	v_bfe_u32 v37, v35, 16, 1                                  // 00000034F56C: D6100025 02052123
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000034F574: BF870121
	v_add3_u32 v35, v35, v37, 0x7fff                           // 00000034F578: D6550023 03FE4B23 00007FFF
	v_lshrrev_b32_e32 v37, 20, v4                              // 00000034F584: 324A0894
	.long 0x7e5e39a3                                           // 00000034F588: 7E5E39A3
	v_cvt_f32_ubyte0_e32 v35, v36                              // 00000034F58C: 7E462324
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000034F590: BF870113
	v_and_or_b32 v37, v37, 15, v39                             // 00000034F594: D6570025 049D1F25
	v_fma_mix_f32 v35, v35, v46, v46 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000034F59C: CC206023 14BA5D23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034F5A4: BF870091
	v_bfe_u32 v36, v35, 16, 1                                  // 00000034F5A8: D6100024 02052123
	v_add3_u32 v35, v35, v36, 0x7fff                           // 00000034F5B0: D6550023 03FE4923 00007FFF
	v_lshrrev_b32_e32 v36, 4, v15                              // 00000034F5BC: 32481E84
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000034F5C0: BF8701A2
	v_and_or_b32 v40, 0xffff0000, v35, v47                     // 00000034F5C4: D6570028 04BE46FF FFFF0000
	.long 0x7e5e3984                                           // 00000034F5D0: 7E5E3984
	v_and_b32_e32 v36, 48, v36                                 // 00000034F5D4: 364848B0
	v_lshrrev_b32_e32 v35, 8, v15                              // 00000034F5D8: 32461E88
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000034F5DC: BF870112
	v_and_or_b32 v36, v47, 15, v36                             // 00000034F5E0: D6570024 04911F2F
	v_and_b32_e32 v35, 48, v35                                 // 00000034F5E8: 364646B0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034F5EC: BF870092
	v_cvt_f32_ubyte0_e32 v36, v36                              // 00000034F5F0: 7E482324
	v_fma_mix_f32 v36, v36, v46, v46 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000034F5F4: CC206024 14BA5D24
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034F5FC: BF870091
	v_bfe_u32 v39, v36, 16, 1                                  // 00000034F600: D6100027 02052124
	v_add3_u32 v36, v36, v39, 0x7fff                           // 00000034F608: D6550024 03FE4F24 00007FFF
	v_lshrrev_b32_e32 v39, 18, v15                             // 00000034F614: 324E1E92
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000034F618: BF8701A2
	.long 0x7e5e39a4                                           // 00000034F61C: 7E5E39A4
	v_cvt_f32_ubyte0_e32 v36, v37                              // 00000034F620: 7E482325
	v_and_b32_e32 v39, 48, v39                                 // 00000034F624: 364E4EB0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034F628: BF870092
	v_fma_mix_f32 v36, v36, v46, v46 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000034F62C: CC206024 14BA5D24
	v_bfe_u32 v37, v36, 16, 1                                  // 00000034F634: D6100025 02052124
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000034F63C: BF870121
	v_add3_u32 v36, v36, v37, 0x7fff                           // 00000034F640: D6550024 03FE4B24 00007FFF
	v_lshrrev_b32_e32 v37, 12, v15                             // 00000034F64C: 324A1E8C
	v_and_or_b32 v41, 0xffff0000, v36, v47                     // 00000034F650: D6570029 04BE48FF FFFF0000
	v_lshrrev_b32_e32 v36, 24, v4                              // 00000034F65C: 32480898
	v_lshrrev_b32_e32 v4, 28, v4                               // 00000034F660: 3208089C
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000034F664: BF870122
	v_and_or_b32 v35, v36, 15, v35                             // 00000034F668: D6570023 048D1F24
	v_lshrrev_b32_e32 v36, 10, v15                             // 00000034F670: 32481E8A
	v_cvt_f32_ubyte0_e32 v35, v35                              // 00000034F674: 7E462323
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000034F678: BF870112
	v_and_or_b32 v4, v36, 48, v4                               // 00000034F67C: D6570004 04116124
	v_fma_mix_f32 v35, v35, v46, v46 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000034F684: CC206023 14BA5D23
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000034F68C: BF870112
	v_cvt_f32_ubyte0_e32 v4, v4                                // 00000034F690: 7E082304
	v_bfe_u32 v36, v35, 16, 1                                  // 00000034F694: D6100024 02052123
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000034F69C: BF870112
	v_fma_mix_f32 v4, v4, v46, v46 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000034F6A0: CC206004 14BA5D04
	v_add3_u32 v35, v35, v36, 0x7fff                           // 00000034F6A8: D6550023 03FE4923 00007FFF
	v_lshrrev_b32_e32 v36, 14, v15                             // 00000034F6B4: 32481E8E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000034F6B8: BF870212
	.long 0x7e5e39a3                                           // 00000034F6BC: 7E5E39A3
	v_bfe_u32 v35, v4, 16, 1                                   // 00000034F6C0: D6100023 02052104
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000034F6C8: BF870113
	v_and_b32_e32 v36, 48, v36                                 // 00000034F6CC: 364848B0
	v_add3_u32 v4, v4, v35, 0x7fff                             // 00000034F6D0: D6550004 03FE4704 00007FFF
	v_lshrrev_b32_e32 v35, 4, v5                               // 00000034F6DC: 32460A84
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000034F6E0: BF8701A2
	v_and_or_b32 v43, 0xffff0000, v4, v47                      // 00000034F6E4: D657002B 04BE08FF FFFF0000
	v_and_b32_e32 v4, 48, v37                                  // 00000034F6F0: 36084AB0
	v_and_or_b32 v35, v35, 15, v36                             // 00000034F6F4: D6570023 04911F23
	.long 0x7e5e398f                                           // 00000034F6FC: 7E5E398F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000034F700: BF870193
	v_and_or_b32 v4, v5, 15, v4                                // 00000034F704: D6570004 04111F05
	v_cvt_f32_ubyte0_e32 v35, v35                              // 00000034F70C: 7E462323
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000034F710: BF870193
	v_and_b32_e32 v37, 48, v47                                 // 00000034F714: 364A5EB0
	v_cvt_f32_ubyte0_e32 v4, v4                                // 00000034F718: 7E082304
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000034F71C: BF870113
	v_fma_mix_f32 v35, v35, v46, v46 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000034F720: CC206023 14BA5D23
	v_fma_mix_f32 v4, v4, v46, v46 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000034F728: CC206004 14BA5D04
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034F730: BF870091
	v_bfe_u32 v36, v4, 16, 1                                   // 00000034F734: D6100024 02052104
	v_add3_u32 v4, v4, v36, 0x7fff                             // 00000034F73C: D6550004 03FE4904 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000034F748: BF870114
	v_bfe_u32 v36, v35, 16, 1                                  // 00000034F74C: D6100024 02052123
	.long 0x7e083984                                           // 00000034F754: 7E083984
	.long 0x7f0839af                                           // 00000034F758: 7F0839AF
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000034F75C: BF870123
	v_add3_u32 v35, v35, v36, 0x7fff                           // 00000034F760: D6550023 03FE4923 00007FFF
	v_lshrrev_b32_e32 v36, 20, v15                             // 00000034F76C: 32481E94
	v_and_or_b32 v4, 0xffff0000, v35, v4                       // 00000034F770: D6570004 041246FF FFFF0000
	v_lshrrev_b32_e32 v35, 8, v5                               // 00000034F77C: 32460A88
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000034F780: BF870113
	v_and_b32_e32 v36, 48, v36                                 // 00000034F784: 364848B0
	v_and_or_b32 v35, v35, 15, v37                             // 00000034F788: D6570023 04951F23
	v_lshrrev_b32_e32 v37, 12, v5                              // 00000034F790: 324A0A8C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000034F794: BF870112
	v_cvt_f32_ubyte0_e32 v35, v35                              // 00000034F798: 7E462323
	v_and_or_b32 v37, v37, 15, v39                             // 00000034F79C: D6570025 049D1F25
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034F7A4: BF870092
	v_fma_mix_f32 v35, v35, v46, v46 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000034F7A8: CC206023 14BA5D23
	v_bfe_u32 v39, v35, 16, 1                                  // 00000034F7B0: D6100027 02052123
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000034F7B8: BF870121
	v_add3_u32 v35, v35, v39, 0x7fff                           // 00000034F7BC: D6550023 03FE4F23 00007FFF
	v_lshrrev_b32_e32 v39, 20, v5                              // 00000034F7C8: 324E0A94
	.long 0x7e5e39a3                                           // 00000034F7CC: 7E5E39A3
	v_cvt_f32_ubyte0_e32 v35, v37                              // 00000034F7D0: 7E462325
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000034F7D4: BF870113
	v_and_or_b32 v39, v39, 15, v42                             // 00000034F7D8: D6570027 04A91F27
	v_fma_mix_f32 v35, v35, v46, v46 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000034F7E0: CC206023 14BA5D23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034F7E8: BF870091
	v_bfe_u32 v37, v35, 16, 1                                  // 00000034F7EC: D6100025 02052123
	v_add3_u32 v35, v35, v37, 0x7fff                           // 00000034F7F4: D6550023 03FE4B23 00007FFF
	v_lshrrev_b32_e32 v37, 24, v15                             // 00000034F800: 324A1E98
	v_lshrrev_b32_e32 v15, 26, v15                             // 00000034F804: 321E1E9A
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000034F808: BF870223
	v_and_or_b32 v35, 0xffff0000, v35, v47                     // 00000034F80C: D6570023 04BE46FF FFFF0000
	.long 0x7e5e3985                                           // 00000034F818: 7E5E3985
	v_and_b32_e32 v37, 48, v37                                 // 00000034F81C: 364A4AB0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034F820: BF870092
	v_and_or_b32 v36, v47, 15, v36                             // 00000034F824: D6570024 04911F2F
	v_cvt_f32_ubyte0_e32 v36, v36                              // 00000034F82C: 7E482324
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034F830: BF870091
	v_fma_mix_f32 v36, v36, v46, v46 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000034F834: CC206024 14BA5D24
	v_bfe_u32 v42, v36, 16, 1                                  // 00000034F83C: D610002A 02052124
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000034F844: BF870121
	v_add3_u32 v36, v36, v42, 0x7fff                           // 00000034F848: D6550024 03FE5524 00007FFF
	v_lshrrev_b32_e32 v42, 2, v16                              // 00000034F854: 32542082
	.long 0x7e5e39a4                                           // 00000034F858: 7E5E39A4
	v_cvt_f32_ubyte0_e32 v36, v39                              // 00000034F85C: 7E482327
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000034F860: BF870113
	v_and_b32_e32 v42, 48, v42                                 // 00000034F864: 365454B0
	v_fma_mix_f32 v36, v36, v46, v46 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000034F868: CC206024 14BA5D24
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034F870: BF870091
	v_bfe_u32 v39, v36, 16, 1                                  // 00000034F874: D6100027 02052124
	v_add3_u32 v36, v36, v39, 0x7fff                           // 00000034F87C: D6550024 03FE4F24 00007FFF
	v_lshrrev_b32_e32 v39, 24, v5                              // 00000034F888: 324E0A98
	v_lshrrev_b32_e32 v5, 28, v5                               // 00000034F88C: 320A0A9C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000034F890: BF870193
	v_and_or_b32 v36, 0xffff0000, v36, v47                     // 00000034F894: D6570024 04BE48FF FFFF0000
	v_and_or_b32 v37, v39, 15, v37                             // 00000034F8A0: D6570025 04951F27
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000034F8A8: BF8701A3
	v_and_or_b32 v5, v15, 48, v5                               // 00000034F8AC: D6570005 0415610F
	v_lshlrev_b32_e32 v39, 2, v16                              // 00000034F8B4: 304E2082
	v_cvt_f32_ubyte0_e32 v15, v37                              // 00000034F8B8: 7E1E2325
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000034F8BC: BF870193
	v_cvt_f32_ubyte0_e32 v5, v5                                // 00000034F8C0: 7E0A2305
	v_and_b32_e32 v39, 48, v39                                 // 00000034F8C4: 364E4EB0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000034F8C8: BF870193
	v_fma_mix_f32 v15, v15, v46, v46 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000034F8CC: CC20600F 14BA5D0F
	v_fma_mix_f32 v5, v5, v46, v46 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000034F8D4: CC206005 14BA5D05
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034F8DC: BF870092
	v_bfe_u32 v37, v15, 16, 1                                  // 00000034F8E0: D6100025 0205210F
	v_add3_u32 v15, v15, v37, 0x7fff                           // 00000034F8E8: D655000F 03FE4B0F 00007FFF
	v_lshrrev_b32_e32 v37, 4, v6                               // 00000034F8F4: 324A0C84
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000034F8F8: BF8701A2
	.long 0x7e5e398f                                           // 00000034F8FC: 7E5E398F
	v_bfe_u32 v15, v5, 16, 1                                   // 00000034F900: D610000F 02052105
	v_and_or_b32 v37, v37, 15, v39                             // 00000034F908: D6570025 049D1F25
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000034F910: BF870122
	v_add3_u32 v5, v5, v15, 0x7fff                             // 00000034F914: D6550005 03FE1F05 00007FFF
	v_lshlrev_b32_e32 v15, 4, v16                              // 00000034F920: 301E2084
	v_and_or_b32 v5, 0xffff0000, v5, v47                       // 00000034F924: D6570005 04BE0AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034F930: BF870092
	v_and_b32_e32 v15, 48, v15                                 // 00000034F934: 361E1EB0
	v_and_or_b32 v15, v6, 15, v15                              // 00000034F938: D657000F 043D1F06
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034F940: BF870091
	v_cvt_f32_ubyte0_e32 v15, v15                              // 00000034F944: 7E1E230F
	v_fma_mix_f32 v15, v15, v46, v46 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000034F948: CC20600F 14BA5D0F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034F950: BF870091
	v_bfe_u32 v39, v15, 16, 1                                  // 00000034F954: D6100027 0205210F
	v_add3_u32 v15, v15, v39, 0x7fff                           // 00000034F95C: D655000F 03FE4F0F 00007FFF
	v_and_b32_e32 v39, 48, v16                                 // 00000034F968: 364E20B0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000034F96C: BF8700A2
	.long 0x7e5e398f                                           // 00000034F970: 7E5E398F
	v_cvt_f32_ubyte0_e32 v15, v37                              // 00000034F974: 7E1E2325
	v_fma_mix_f32 v15, v15, v46, v46 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000034F978: CC20600F 14BA5D0F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034F980: BF870091
	v_bfe_u32 v37, v15, 16, 1                                  // 00000034F984: D6100025 0205210F
	v_add3_u32 v15, v15, v37, 0x7fff                           // 00000034F98C: D655000F 03FE4B0F 00007FFF
	v_lshrrev_b32_e32 v37, 8, v6                               // 00000034F998: 324A0C88
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000034F99C: BF870112
	v_and_or_b32 v15, 0xffff0000, v15, v47                     // 00000034F9A0: D657000F 04BE1EFF FFFF0000
	v_and_or_b32 v37, v37, 15, v39                             // 00000034F9AC: D6570025 049D1F25
	v_lshrrev_b32_e32 v39, 12, v6                              // 00000034F9B4: 324E0C8C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000034F9B8: BF870112
	v_cvt_f32_ubyte0_e32 v37, v37                              // 00000034F9BC: 7E4A2325
	v_and_or_b32 v39, v39, 15, v42                             // 00000034F9C0: D6570027 04A91F27
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034F9C8: BF870092
	v_fma_mix_f32 v37, v37, v46, v46 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000034F9CC: CC206025 14BA5D25
	v_bfe_u32 v42, v37, 16, 1                                  // 00000034F9D4: D610002A 02052125
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000034F9DC: BF870121
	v_add3_u32 v37, v37, v42, 0x7fff                           // 00000034F9E0: D6550025 03FE5525 00007FFF
	v_lshrrev_b32_e32 v42, 8, v16                              // 00000034F9EC: 32542088
	.long 0x7e5e39a5                                           // 00000034F9F0: 7E5E39A5
	v_cvt_f32_ubyte0_e32 v37, v39                              // 00000034F9F4: 7E4A2327
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000034F9F8: BF870113
	v_and_b32_e32 v42, 48, v42                                 // 00000034F9FC: 365454B0
	v_fma_mix_f32 v37, v37, v46, v46 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000034FA00: CC206025 14BA5D25
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034FA08: BF870091
	v_bfe_u32 v39, v37, 16, 1                                  // 00000034FA0C: D6100027 02052125
	v_add3_u32 v37, v37, v39, 0x7fff                           // 00000034FA14: D6550025 03FE4F25 00007FFF
	v_lshrrev_b32_e32 v39, 4, v16                              // 00000034FA20: 324E2084
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000034FA24: BF8701A2
	v_and_or_b32 v37, 0xffff0000, v37, v47                     // 00000034FA28: D6570025 04BE4AFF FFFF0000
	.long 0x7e5e3986                                           // 00000034FA34: 7E5E3986
	v_and_b32_e32 v39, 48, v39                                 // 00000034FA38: 364E4EB0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034FA3C: BF870091
	v_and_or_b32 v39, v47, 15, v39                             // 00000034FA40: D6570027 049D1F2F
	v_cvt_f32_ubyte0_e32 v39, v39                              // 00000034FA48: 7E4E2327
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034FA4C: BF870091
	v_fma_mix_f32 v39, v39, v46, v46 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000034FA50: CC206027 14BA5D27
	v_bfe_u32 v45, v39, 16, 1                                  // 00000034FA58: D610002D 02052127
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000034FA60: BF870121
	v_add3_u32 v39, v39, v45, 0x7fff                           // 00000034FA64: D6550027 03FE5B27 00007FFF
	v_lshrrev_b32_e32 v45, 12, v16                             // 00000034FA70: 325A208C
	.long 0x7e5e39a7                                           // 00000034FA74: 7E5E39A7
	v_cvt_f32_ubyte0_e32 v39, v44                              // 00000034FA78: 7E4E232C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034FA7C: BF870091
	v_fma_mix_f32 v39, v39, v46, v46 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000034FA80: CC206027 14BA5D27
	v_bfe_u32 v44, v39, 16, 1                                  // 00000034FA88: D610002C 02052127
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000034FA90: BF8701B1
	v_add3_u32 v39, v39, v44, 0x7fff                           // 00000034FA94: D6550027 03FE5927 00007FFF
	v_lshrrev_b32_e32 v44, 24, v6                              // 00000034FAA0: 32580C98
	v_lshrrev_b32_e32 v6, 28, v6                               // 00000034FAA4: 320C0C9C
	v_and_or_b32 v39, 0xffff0000, v39, v47                     // 00000034FAA8: D6570027 04BE4EFF FFFF0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000034FAB4: BF870123
	v_and_or_b32 v42, v44, 15, v42                             // 00000034FAB8: D657002A 04A91F2C
	v_lshrrev_b32_e32 v44, 10, v16                             // 00000034FAC0: 3258208A
	v_cvt_f32_ubyte0_e32 v42, v42                              // 00000034FAC4: 7E54232A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000034FAC8: BF870112
	v_and_or_b32 v6, v44, 48, v6                               // 00000034FACC: D6570006 0419612C
	v_fma_mix_f32 v42, v42, v46, v46 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000034FAD4: CC20602A 14BA5D2A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000034FADC: BF870112
	v_cvt_f32_ubyte0_e32 v6, v6                                // 00000034FAE0: 7E0C2306
	v_bfe_u32 v44, v42, 16, 1                                  // 00000034FAE4: D610002C 0205212A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000034FAEC: BF870112
	v_fma_mix_f32 v6, v6, v46, v46 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000034FAF0: CC206006 14BA5D06
	v_add3_u32 v42, v42, v44, 0x7fff                           // 00000034FAF8: D655002A 03FE592A 00007FFF
	v_lshrrev_b32_e32 v44, 4, v7                               // 00000034FB04: 32580E84
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000034FB08: BF870212
	.long 0x7e5e39aa                                           // 00000034FB0C: 7E5E39AA
	v_bfe_u32 v42, v6, 16, 1                                   // 00000034FB10: D610002A 02052106
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000034FB18: BF870121
	v_add3_u32 v6, v6, v42, 0x7fff                             // 00000034FB1C: D6550006 03FE5506 00007FFF
	v_and_b32_e32 v42, 15, v7                                  // 00000034FB28: 36540E8F
	v_and_or_b32 v6, 0xffff0000, v6, v47                       // 00000034FB2C: D6570006 04BE0CFF FFFF0000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000034FB38: BF8701B2
	v_and_or_b32 v42, v45, 48, v42                             // 00000034FB3C: D657002A 04A9612D
	v_lshrrev_b32_e32 v45, 14, v16                             // 00000034FB44: 325A208E
	.long 0x7e5e3990                                           // 00000034FB48: 7E5E3990
	v_cvt_f32_ubyte0_e32 v42, v42                              // 00000034FB4C: 7E54232A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000034FB50: BF870193
	v_and_b32_e32 v45, 48, v45                                 // 00000034FB54: 365A5AB0
	v_and_b32_e32 v48, 48, v47                                 // 00000034FB58: 36605EB0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000034FB5C: BF870193
	v_fma_mix_f32 v42, v42, v46, v46 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000034FB60: CC20602A 14BA5D2A
	v_and_or_b32 v44, v44, 15, v45                             // 00000034FB68: D657002C 04B51F2C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000034FB70: BF870112
	v_bfe_u32 v45, v42, 16, 1                                  // 00000034FB74: D610002D 0205212A
	v_cvt_f32_ubyte0_e32 v44, v44                              // 00000034FB7C: 7E58232C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000034FB80: BF870112
	v_add3_u32 v42, v42, v45, 0x7fff                           // 00000034FB84: D655002A 03FE5B2A 00007FFF
	v_fma_mix_f32 v44, v44, v46, v46 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000034FB90: CC20602C 14BA5D2C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000034FB98: BF870112
	.long 0x7e5439aa                                           // 00000034FB9C: 7E5439AA
	v_bfe_u32 v45, v44, 16, 1                                  // 00000034FBA0: D610002D 0205212C
	.long 0x7f5439af                                           // 00000034FBA8: 7F5439AF
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000034FBAC: BF870122
	v_add3_u32 v44, v44, v45, 0x7fff                           // 00000034FBB0: D655002C 03FE5B2C 00007FFF
	v_lshrrev_b32_e32 v45, 20, v16                             // 00000034FBBC: 325A2094
	v_and_or_b32 v42, 0xffff0000, v44, v42                     // 00000034FBC0: D657002A 04AA58FF FFFF0000
	v_lshrrev_b32_e32 v44, 8, v7                               // 00000034FBCC: 32580E88
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000034FBD0: BF870113
	v_and_b32_e32 v45, 48, v45                                 // 00000034FBD4: 365A5AB0
	v_and_or_b32 v44, v44, 15, v48                             // 00000034FBD8: D657002C 04C11F2C
	v_lshrrev_b32_e32 v48, 12, v7                              // 00000034FBE0: 32600E8C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000034FBE4: BF870112
	v_cvt_f32_ubyte0_e32 v44, v44                              // 00000034FBE8: 7E58232C
	v_and_or_b32 v48, v48, 15, v49                             // 00000034FBEC: D6570030 04C51F30
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034FBF4: BF870092
	v_fma_mix_f32 v44, v44, v46, v46 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000034FBF8: CC20602C 14BA5D2C
	v_bfe_u32 v49, v44, 16, 1                                  // 00000034FC00: D6100031 0205212C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000034FC08: BF870121
	v_add3_u32 v44, v44, v49, 0x7fff                           // 00000034FC0C: D655002C 03FE632C 00007FFF
	v_lshrrev_b32_e32 v49, 20, v7                              // 00000034FC18: 32620E94
	.long 0x7e5e39ac                                           // 00000034FC1C: 7E5E39AC
	v_cvt_f32_ubyte0_e32 v44, v48                              // 00000034FC20: 7E582330
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000034FC24: BF870113
	v_and_or_b32 v49, v49, 15, v50                             // 00000034FC28: D6570031 04C91F31
	v_fma_mix_f32 v44, v44, v46, v46 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000034FC30: CC20602C 14BA5D2C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034FC38: BF870091
	v_bfe_u32 v48, v44, 16, 1                                  // 00000034FC3C: D6100030 0205212C
	v_add3_u32 v44, v44, v48, 0x7fff                           // 00000034FC44: D655002C 03FE612C 00007FFF
	v_lshrrev_b32_e32 v48, 24, v16                             // 00000034FC50: 32602098
	v_lshrrev_b32_e32 v16, 26, v16                             // 00000034FC54: 3220209A
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000034FC58: BF870223
	v_and_or_b32 v44, 0xffff0000, v44, v47                     // 00000034FC5C: D657002C 04BE58FF FFFF0000
	.long 0x7e5e3987                                           // 00000034FC68: 7E5E3987
	v_and_b32_e32 v48, 48, v48                                 // 00000034FC6C: 366060B0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034FC70: BF870092
	v_and_or_b32 v45, v47, 15, v45                             // 00000034FC74: D657002D 04B51F2F
	v_cvt_f32_ubyte0_e32 v45, v45                              // 00000034FC7C: 7E5A232D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034FC80: BF870091
	v_fma_mix_f32 v45, v45, v46, v46 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000034FC84: CC20602D 14BA5D2D
	v_bfe_u32 v50, v45, 16, 1                                  // 00000034FC8C: D6100032 0205212D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034FC94: BF870091
	v_add3_u32 v45, v45, v50, 0x7fff                           // 00000034FC98: D655002D 03FE652D 00007FFF
	.long 0x7e5e39ad                                           // 00000034FCA4: 7E5E39AD
	v_cvt_f32_ubyte0_e32 v45, v49                              // 00000034FCA8: 7E5A2331
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034FCAC: BF870091
	v_fma_mix_f32 v45, v45, v46, v46 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000034FCB0: CC20602D 14BA5D2D
	v_bfe_u32 v49, v45, 16, 1                                  // 00000034FCB8: D6100031 0205212D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000034FCC0: BF8701B1
	v_add3_u32 v45, v45, v49, 0x7fff                           // 00000034FCC4: D655002D 03FE632D 00007FFF
	v_lshrrev_b32_e32 v49, 24, v7                              // 00000034FCD0: 32620E98
	v_lshrrev_b32_e32 v7, 28, v7                               // 00000034FCD4: 320E0E9C
	v_and_or_b32 v45, 0xffff0000, v45, v47                     // 00000034FCD8: D657002D 04BE5AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000034FCE4: BF870193
	v_and_or_b32 v48, v49, 15, v48                             // 00000034FCE8: D6570030 04C11F31
	v_and_or_b32 v7, v16, 48, v7                               // 00000034FCF0: D6570007 041D6110
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000034FCF8: BF870112
	v_cvt_f32_ubyte0_e32 v16, v48                              // 00000034FCFC: 7E202330
	v_cvt_f32_ubyte0_e32 v7, v7                                // 00000034FD00: 7E0E2307
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000034FD04: BF870112
	v_fma_mix_f32 v16, v16, v46, v46 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000034FD08: CC206010 14BA5D10
	v_fma_mix_f32 v7, v7, v46, v46 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000034FD10: CC206007 14BA5D07
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034FD18: BF870092
	v_bfe_u32 v48, v16, 16, 1                                  // 00000034FD1C: D6100030 02052110
	v_add3_u32 v16, v16, v48, 0x7fff                           // 00000034FD24: D6550010 03FE6110 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000034FD30: BF870211
	.long 0x7e5e3990                                           // 00000034FD34: 7E5E3990
	v_bfe_u32 v16, v7, 16, 1                                   // 00000034FD38: D6100010 02052107
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034FD40: BF870091
	v_add3_u32 v7, v7, v16, 0x7fff                             // 00000034FD44: D6550007 03FE2107 00007FFF
	v_and_or_b32 v7, 0xffff0000, v7, v47                       // 00000034FD50: D6570007 04BE0EFF FFFF0000
	.long 0xd73c002e                                           // 00000034FD5C: D73C002E
	v_cndmask_b32_e32 v1, 1, v11, vcc_lo                       // 00000034FD60: 02021681
	v_add_nc_u32_e32 v11, 0x400, v11                           // 00000034FD64: 4A1616FF 00000400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034FD6C: BF870092
	.long 0xd700003e                                           // 00000034FD70: D700003E
	v_cndmask_b32_e32 v1, s6, v46, vcc_lo                      // 00000034FD74: 02025C06
	v_add_co_ci_u32_e64 v63, null, s7, v47, s0                 // 00000034FD78: D5207C3F 00025E07
	s_clause 0x3                                               // 00000034FD80: BF850003
	global_load_b128 v[46:49], v[62:63], off                   // 00000034FD84: DC5E0000 2E7C003E
	global_load_b128 v[50:53], v[62:63], off offset:16         // 00000034FD8C: DC5E0010 327C003E
	global_load_b128 v[54:57], v[62:63], off offset:32         // 00000034FD94: DC5E0020 367C003E
	global_load_b128 v[58:61], v[62:63], off offset:48         // 00000034FD9C: DC5E0030 3A7C003E
	s_waitcnt vmcnt(3)                                         // 00000034FDA4: BF890FF7
	v_dot2_f32_bf16 v16, v46, v38, 0                           // 00000034FDA8: CC1A4010 1A024D2E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034FDB0: BF870091
	v_dot2_f32_bf16 v16, v47, v40, v16                         // 00000034FDB4: CC1A4010 1C42512F
	v_dot2_f32_bf16 v16, v48, v41, v16                         // 00000034FDBC: CC1A4010 1C425330
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000034FDC4: BF8700A1
	v_dot2_f32_bf16 v16, v49, v43, v16                         // 00000034FDC8: CC1A4010 1C425731
	s_waitcnt vmcnt(2)                                         // 00000034FDD0: BF890BF7
	v_dot2_f32_bf16 v16, v50, v4, v16                          // 00000034FDD4: CC1A4010 1C420932
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034FDDC: BF870091
	v_dot2_f32_bf16 v16, v51, v35, v16                         // 00000034FDE0: CC1A4010 1C424733
	v_dot2_f32_bf16 v16, v52, v36, v16                         // 00000034FDE8: CC1A4010 1C424934
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000034FDF0: BF8700A1
	v_dot2_f32_bf16 v16, v53, v5, v16                          // 00000034FDF4: CC1A4010 1C420B35
	s_waitcnt vmcnt(1)                                         // 00000034FDFC: BF8907F7
	v_dot2_f32_bf16 v16, v54, v15, v16                         // 00000034FE00: CC1A4010 1C421F36
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034FE08: BF870091
	v_dot2_f32_bf16 v16, v55, v37, v16                         // 00000034FE0C: CC1A4010 1C424B37
	v_dot2_f32_bf16 v16, v56, v39, v16                         // 00000034FE14: CC1A4010 1C424F38
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000034FE1C: BF8700A1
	v_dot2_f32_bf16 v16, v57, v6, v16                          // 00000034FE20: CC1A4010 1C420D39
	s_waitcnt vmcnt(0)                                         // 00000034FE28: BF8903F7
	v_dot2_f32_bf16 v16, v58, v42, v16                         // 00000034FE2C: CC1A4010 1C42553A
	.long 0xd700003a                                           // 00000034FE34: D700003A
	v_cndmask_b32_e32 v0, v62, v10, vcc_lo                     // 00000034FE38: 0200153E
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000034FE3C: BF8701B2
	v_dot2_f32_bf16 v16, v59, v44, v16                         // 00000034FE40: CC1A4010 1C42593B
	v_add_co_ci_u32_e64 v59, null, s11, v63, s0                // 00000034FE48: D5207C3B 00027E0B
	.long 0xd7000040                                           // 00000034FE50: D7000040
	v_cndmask_b32_e32 v0, v62, v4, vcc_lo                      // 00000034FE54: 0200093E
	v_dot2_f32_bf16 v16, v60, v45, v16                         // 00000034FE58: CC1A4010 1C425B3C
	v_add_co_ci_u32_e64 v65, null, s5, v63, s0                 // 00000034FE60: D5207C41 00027E05
	.long 0xd700003e                                           // 00000034FE68: D700003E
	v_cndmask_b32_e32 v0, v62, v16, vcc_lo                     // 00000034FE6C: 0200213E
	s_delay_alu instid0(VALU_DEP_3)                            // 00000034FE70: BF870003
	v_dot2_f32_bf16 v16, v61, v7, v16                          // 00000034FE74: CC1A4010 1C420F3D
	s_clause 0x3                                               // 00000034FE7C: BF850003
	global_load_b128 v[46:49], v[58:59], off                   // 00000034FE80: DC5E0000 2E7C003A
	global_load_b128 v[50:53], v[58:59], off offset:16         // 00000034FE88: DC5E0010 327C003A
	global_load_b128 v[54:57], v[58:59], off offset:32         // 00000034FE90: DC5E0020 367C003A
	global_load_b128 v[58:61], v[58:59], off offset:48         // 00000034FE98: DC5E0030 3A7C003A
	v_add_co_ci_u32_e64 v63, null, s14, v63, s0                // 00000034FEA0: D5207C3F 00027E0E
	v_add_f32_e32 v25, v25, v16                                // 00000034FEA8: 06322119
	s_waitcnt vmcnt(3)                                         // 00000034FEAC: BF890FF7
	v_dot2_f32_bf16 v16, v46, v38, 0                           // 00000034FEB0: CC1A4010 1A024D2E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034FEB8: BF870091
	v_dot2_f32_bf16 v16, v47, v40, v16                         // 00000034FEBC: CC1A4010 1C42512F
	v_dot2_f32_bf16 v16, v48, v41, v16                         // 00000034FEC4: CC1A4010 1C425330
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000034FECC: BF8700A1
	v_dot2_f32_bf16 v16, v49, v43, v16                         // 00000034FED0: CC1A4010 1C425731
	s_waitcnt vmcnt(2)                                         // 00000034FED8: BF890BF7
	v_dot2_f32_bf16 v16, v50, v4, v16                          // 00000034FEDC: CC1A4010 1C420932
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034FEE4: BF870091
	v_dot2_f32_bf16 v16, v51, v35, v16                         // 00000034FEE8: CC1A4010 1C424733
	v_dot2_f32_bf16 v16, v52, v36, v16                         // 00000034FEF0: CC1A4010 1C424934
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000034FEF8: BF8700A1
	v_dot2_f32_bf16 v16, v53, v5, v16                          // 00000034FEFC: CC1A4010 1C420B35
	s_waitcnt vmcnt(1)                                         // 00000034FF04: BF8907F7
	v_dot2_f32_bf16 v16, v54, v15, v16                         // 00000034FF08: CC1A4010 1C421F36
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034FF10: BF870091
	v_dot2_f32_bf16 v16, v55, v37, v16                         // 00000034FF14: CC1A4010 1C424B37
	v_dot2_f32_bf16 v16, v56, v39, v16                         // 00000034FF1C: CC1A4010 1C424F38
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000034FF24: BF8700A1
	v_dot2_f32_bf16 v16, v57, v6, v16                          // 00000034FF28: CC1A4010 1C420D39
	s_waitcnt vmcnt(0)                                         // 00000034FF30: BF8903F7
	v_dot2_f32_bf16 v16, v58, v42, v16                         // 00000034FF34: CC1A4010 1C42553A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034FF3C: BF870091
	v_dot2_f32_bf16 v16, v59, v44, v16                         // 00000034FF40: CC1A4010 1C42593B
	v_dot2_f32_bf16 v16, v60, v45, v16                         // 00000034FF48: CC1A4010 1C425B3C
	s_delay_alu instid0(VALU_DEP_1)                            // 00000034FF50: BF870001
	v_dot2_f32_bf16 v16, v61, v7, v16                          // 00000034FF54: CC1A4010 1C420F3D
	s_clause 0x3                                               // 00000034FF5C: BF850003
	global_load_b128 v[46:49], v[64:65], off                   // 00000034FF60: DC5E0000 2E7C0040
	global_load_b128 v[50:53], v[64:65], off offset:16         // 00000034FF68: DC5E0010 327C0040
	global_load_b128 v[54:57], v[64:65], off offset:32         // 00000034FF70: DC5E0020 367C0040
	global_load_b128 v[58:61], v[64:65], off offset:48         // 00000034FF78: DC5E0030 3A7C0040
	.long 0xd7000040                                           // 00000034FF80: D7000040
	v_cndmask_b32_e32 v0, v64, v4, vcc_lo                      // 00000034FF84: 02000940
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000034FF88: BF8700C1
	v_add_co_ci_u32_e64 v65, null, s5, v65, s0                 // 00000034FF8C: D5207C41 00028205
	v_add_f32_e32 v24, v24, v16                                // 00000034FF94: 06302118
	s_waitcnt vmcnt(3)                                         // 00000034FF98: BF890FF7
	v_dot2_f32_bf16 v16, v46, v38, 0                           // 00000034FF9C: CC1A4010 1A024D2E
	v_dot2_f32_bf16 v16, v47, v40, v16                         // 00000034FFA4: CC1A4010 1C42512F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034FFAC: BF870091
	v_dot2_f32_bf16 v16, v48, v41, v16                         // 00000034FFB0: CC1A4010 1C425330
	v_dot2_f32_bf16 v16, v49, v43, v16                         // 00000034FFB8: CC1A4010 1C425731
	s_waitcnt vmcnt(2)                                         // 00000034FFC0: BF890BF7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034FFC4: BF870091
	v_dot2_f32_bf16 v16, v50, v4, v16                          // 00000034FFC8: CC1A4010 1C420932
	v_dot2_f32_bf16 v16, v51, v35, v16                         // 00000034FFD0: CC1A4010 1C424733
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034FFD8: BF870091
	v_dot2_f32_bf16 v16, v52, v36, v16                         // 00000034FFDC: CC1A4010 1C424934
	v_dot2_f32_bf16 v16, v53, v5, v16                          // 00000034FFE4: CC1A4010 1C420B35
	s_waitcnt vmcnt(1)                                         // 00000034FFEC: BF8907F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034FFF0: BF870091
	v_dot2_f32_bf16 v16, v54, v15, v16                         // 00000034FFF4: CC1A4010 1C421F36
	v_dot2_f32_bf16 v16, v55, v37, v16                         // 00000034FFFC: CC1A4010 1C424B37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000350004: BF870091
	v_dot2_f32_bf16 v16, v56, v39, v16                         // 000000350008: CC1A4010 1C424F38
	v_dot2_f32_bf16 v16, v57, v6, v16                          // 000000350010: CC1A4010 1C420D39
	s_waitcnt vmcnt(0)                                         // 000000350018: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000035001C: BF870091
	v_dot2_f32_bf16 v16, v58, v42, v16                         // 000000350020: CC1A4010 1C42553A
	v_dot2_f32_bf16 v16, v59, v44, v16                         // 000000350028: CC1A4010 1C42593B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000350030: BF870091
	v_dot2_f32_bf16 v16, v60, v45, v16                         // 000000350034: CC1A4010 1C425B3C
	v_dot2_f32_bf16 v16, v61, v7, v16                          // 00000035003C: CC1A4010 1C420F3D
	s_clause 0x3                                               // 000000350044: BF850003
	global_load_b128 v[46:49], v[62:63], off                   // 000000350048: DC5E0000 2E7C003E
	global_load_b128 v[50:53], v[62:63], off offset:16         // 000000350050: DC5E0010 327C003E
	global_load_b128 v[54:57], v[62:63], off offset:32         // 000000350058: DC5E0020 367C003E
	global_load_b128 v[58:61], v[62:63], off offset:48         // 000000350060: DC5E0030 3A7C003E
	v_add_f32_e32 v23, v23, v16                                // 000000350068: 062E2117
	s_waitcnt vmcnt(3)                                         // 00000035006C: BF890FF7
	v_dot2_f32_bf16 v16, v46, v38, 0                           // 000000350070: CC1A4010 1A024D2E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000350078: BF870091
	v_dot2_f32_bf16 v16, v47, v40, v16                         // 00000035007C: CC1A4010 1C42512F
	v_dot2_f32_bf16 v16, v48, v41, v16                         // 000000350084: CC1A4010 1C425330
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000035008C: BF8700A1
	v_dot2_f32_bf16 v16, v49, v43, v16                         // 000000350090: CC1A4010 1C425731
	s_waitcnt vmcnt(2)                                         // 000000350098: BF890BF7
	v_dot2_f32_bf16 v16, v50, v4, v16                          // 00000035009C: CC1A4010 1C420932
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003500A4: BF870091
	v_dot2_f32_bf16 v16, v51, v35, v16                         // 0000003500A8: CC1A4010 1C424733
	v_dot2_f32_bf16 v16, v52, v36, v16                         // 0000003500B0: CC1A4010 1C424934
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003500B8: BF8700A1
	v_dot2_f32_bf16 v16, v53, v5, v16                          // 0000003500BC: CC1A4010 1C420B35
	s_waitcnt vmcnt(1)                                         // 0000003500C4: BF8907F7
	v_dot2_f32_bf16 v16, v54, v15, v16                         // 0000003500C8: CC1A4010 1C421F36
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003500D0: BF870091
	v_dot2_f32_bf16 v16, v55, v37, v16                         // 0000003500D4: CC1A4010 1C424B37
	v_dot2_f32_bf16 v16, v56, v39, v16                         // 0000003500DC: CC1A4010 1C424F38
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003500E4: BF8700A1
	v_dot2_f32_bf16 v16, v57, v6, v16                          // 0000003500E8: CC1A4010 1C420D39
	s_waitcnt vmcnt(0)                                         // 0000003500F0: BF8903F7
	v_dot2_f32_bf16 v16, v58, v42, v16                         // 0000003500F4: CC1A4010 1C42553A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003500FC: BF870091
	v_dot2_f32_bf16 v16, v59, v44, v16                         // 000000350100: CC1A4010 1C42593B
	v_dot2_f32_bf16 v16, v60, v45, v16                         // 000000350108: CC1A4010 1C425B3C
	s_delay_alu instid0(VALU_DEP_1)                            // 000000350110: BF870001
	v_dot2_f32_bf16 v16, v61, v7, v16                          // 000000350114: CC1A4010 1C420F3D
	s_clause 0x3                                               // 00000035011C: BF850003
	global_load_b128 v[46:49], v[64:65], off                   // 000000350120: DC5E0000 2E7C0040
	global_load_b128 v[50:53], v[64:65], off offset:16         // 000000350128: DC5E0010 327C0040
	global_load_b128 v[54:57], v[64:65], off offset:32         // 000000350130: DC5E0020 367C0040
	global_load_b128 v[58:61], v[64:65], off offset:48         // 000000350138: DC5E0030 3A7C0040
	v_add_f32_e32 v22, v22, v16                                // 000000350140: 062C2116
	s_waitcnt vmcnt(3)                                         // 000000350144: BF890FF7
	v_dot2_f32_bf16 v16, v46, v38, 0                           // 000000350148: CC1A4010 1A024D2E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000350150: BF870091
	v_dot2_f32_bf16 v16, v47, v40, v16                         // 000000350154: CC1A4010 1C42512F
	v_dot2_f32_bf16 v16, v48, v41, v16                         // 00000035015C: CC1A4010 1C425330
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000350164: BF8700A1
	v_dot2_f32_bf16 v16, v49, v43, v16                         // 000000350168: CC1A4010 1C425731
	s_waitcnt vmcnt(2)                                         // 000000350170: BF890BF7
	v_dot2_f32_bf16 v16, v50, v4, v16                          // 000000350174: CC1A4010 1C420932
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000035017C: BF870091
	v_dot2_f32_bf16 v16, v51, v35, v16                         // 000000350180: CC1A4010 1C424733
	v_dot2_f32_bf16 v16, v52, v36, v16                         // 000000350188: CC1A4010 1C424934
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000350190: BF8700A1
	v_dot2_f32_bf16 v16, v53, v5, v16                          // 000000350194: CC1A4010 1C420B35
	s_waitcnt vmcnt(1)                                         // 00000035019C: BF8907F7
	v_dot2_f32_bf16 v16, v54, v15, v16                         // 0000003501A0: CC1A4010 1C421F36
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003501A8: BF870091
	v_dot2_f32_bf16 v16, v55, v37, v16                         // 0000003501AC: CC1A4010 1C424B37
	v_dot2_f32_bf16 v16, v56, v39, v16                         // 0000003501B4: CC1A4010 1C424F38
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003501BC: BF8700A1
	v_dot2_f32_bf16 v16, v57, v6, v16                          // 0000003501C0: CC1A4010 1C420D39
	s_waitcnt vmcnt(0)                                         // 0000003501C8: BF8903F7
	v_dot2_f32_bf16 v16, v58, v42, v16                         // 0000003501CC: CC1A4010 1C42553A
	.long 0xd700003a                                           // 0000003501D4: D700003A
	v_cndmask_b32_e32 v0, v62, v4, vcc_lo                      // 0000003501D8: 0200093E
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000003501DC: BF870122
	v_dot2_f32_bf16 v16, v59, v44, v16                         // 0000003501E0: CC1A4010 1C42593B
	v_add_co_ci_u32_e64 v59, null, s5, v63, s0                 // 0000003501E8: D5207C3B 00027E05
	v_dot2_f32_bf16 v16, v60, v45, v16                         // 0000003501F0: CC1A4010 1C425B3C
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003501F8: BF870001
	v_dot2_f32_bf16 v16, v61, v7, v16                          // 0000003501FC: CC1A4010 1C420F3D
	s_clause 0x3                                               // 000000350204: BF850003
	global_load_b128 v[46:49], v[58:59], off                   // 000000350208: DC5E0000 2E7C003A
	global_load_b128 v[50:53], v[58:59], off offset:16         // 000000350210: DC5E0010 327C003A
	global_load_b128 v[54:57], v[58:59], off offset:32         // 000000350218: DC5E0020 367C003A
	global_load_b128 v[58:61], v[58:59], off offset:48         // 000000350220: DC5E0030 3A7C003A
	v_add_f32_e32 v21, v21, v16                                // 000000350228: 062A2115
	s_waitcnt vmcnt(3)                                         // 00000035022C: BF890FF7
	v_dot2_f32_bf16 v16, v46, v38, 0                           // 000000350230: CC1A4010 1A024D2E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000350238: BF870091
	v_dot2_f32_bf16 v16, v47, v40, v16                         // 00000035023C: CC1A4010 1C42512F
	v_dot2_f32_bf16 v16, v48, v41, v16                         // 000000350244: CC1A4010 1C425330
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000035024C: BF8700A1
	v_dot2_f32_bf16 v16, v49, v43, v16                         // 000000350250: CC1A4010 1C425731
	s_waitcnt vmcnt(2)                                         // 000000350258: BF890BF7
	v_dot2_f32_bf16 v16, v50, v4, v16                          // 00000035025C: CC1A4010 1C420932
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000350264: BF870091
	v_dot2_f32_bf16 v16, v51, v35, v16                         // 000000350268: CC1A4010 1C424733
	v_dot2_f32_bf16 v16, v52, v36, v16                         // 000000350270: CC1A4010 1C424934
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000350278: BF8700A1
	v_dot2_f32_bf16 v16, v53, v5, v16                          // 00000035027C: CC1A4010 1C420B35
	s_waitcnt vmcnt(1)                                         // 000000350284: BF8907F7
	v_dot2_f32_bf16 v16, v54, v15, v16                         // 000000350288: CC1A4010 1C421F36
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000350290: BF870091
	v_dot2_f32_bf16 v16, v55, v37, v16                         // 000000350294: CC1A4010 1C424B37
	v_dot2_f32_bf16 v16, v56, v39, v16                         // 00000035029C: CC1A4010 1C424F38
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003502A4: BF8700A1
	v_dot2_f32_bf16 v16, v57, v6, v16                          // 0000003502A8: CC1A4010 1C420D39
	s_waitcnt vmcnt(0)                                         // 0000003502B0: BF8903F7
	v_dot2_f32_bf16 v16, v58, v42, v16                         // 0000003502B4: CC1A4010 1C42553A
	.long 0xd700003a                                           // 0000003502BC: D700003A
	v_cndmask_b32_e32 v0, v64, v4, vcc_lo                      // 0000003502C0: 02000940
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000003502C4: BF870122
	v_dot2_f32_bf16 v16, v59, v44, v16                         // 0000003502C8: CC1A4010 1C42593B
	v_add_co_ci_u32_e64 v59, null, s5, v65, s0                 // 0000003502D0: D5207C3B 00028205
	v_dot2_f32_bf16 v16, v60, v45, v16                         // 0000003502D8: CC1A4010 1C425B3C
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003502E0: BF870001
	v_dot2_f32_bf16 v16, v61, v7, v16                          // 0000003502E4: CC1A4010 1C420F3D
	s_clause 0x3                                               // 0000003502EC: BF850003
	global_load_b128 v[46:49], v[58:59], off                   // 0000003502F0: DC5E0000 2E7C003A
	global_load_b128 v[50:53], v[58:59], off offset:16         // 0000003502F8: DC5E0010 327C003A
	global_load_b128 v[54:57], v[58:59], off offset:32         // 000000350300: DC5E0020 367C003A
	global_load_b128 v[58:61], v[58:59], off offset:48         // 000000350308: DC5E0030 3A7C003A
	v_add_f32_e32 v20, v20, v16                                // 000000350310: 06282114
	s_waitcnt vmcnt(3)                                         // 000000350314: BF890FF7
	v_dot2_f32_bf16 v16, v46, v38, 0                           // 000000350318: CC1A4010 1A024D2E
	v_mov_b32_e32 v46, v34                                     // 000000350320: 7E5C0322
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000350324: BF870092
	v_dot2_f32_bf16 v16, v47, v40, v16                         // 000000350328: CC1A4010 1C42512F
	v_dot2_f32_bf16 v16, v48, v41, v16                         // 000000350330: CC1A4010 1C425330
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000350338: BF8700A1
	v_dot2_f32_bf16 v16, v49, v43, v16                         // 00000035033C: CC1A4010 1C425731
	s_waitcnt vmcnt(2)                                         // 000000350344: BF890BF7
	v_dot2_f32_bf16 v4, v50, v4, v16                           // 000000350348: CC1A4004 1C420932
	v_mov_b32_e32 v16, v14                                     // 000000350350: 7E20030E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000350354: BF870092
	v_dot2_f32_bf16 v4, v51, v35, v4                           // 000000350358: CC1A4004 1C124733
	v_dot2_f32_bf16 v4, v52, v36, v4                           // 000000350360: CC1A4004 1C124934
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000350368: BF870131
	v_dot2_f32_bf16 v4, v53, v5, v4                            // 00000035036C: CC1A4004 1C120B35
	v_mov_b32_e32 v5, v1                                       // 000000350374: 7E0A0301
	s_waitcnt vmcnt(1)                                         // 000000350378: BF8907F7
	v_dot2_f32_bf16 v4, v54, v15, v4                           // 00000035037C: CC1A4004 1C121F36
	v_mov_b32_e32 v15, v13                                     // 000000350384: 7E1E030D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000350388: BF870092
	v_dot2_f32_bf16 v4, v55, v37, v4                           // 00000035038C: CC1A4004 1C124B37
	v_dot2_f32_bf16 v4, v56, v39, v4                           // 000000350394: CC1A4004 1C124F38
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000035039C: BF870131
	v_dot2_f32_bf16 v4, v57, v6, v4                            // 0000003503A0: CC1A4004 1C120D39
	v_mov_b32_e32 v6, v2                                       // 0000003503A8: 7E0C0302
	s_waitcnt vmcnt(0)                                         // 0000003503AC: BF8903F7
	v_dot2_f32_bf16 v4, v58, v42, v4                           // 0000003503B0: CC1A4004 1C12553A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003503B8: BF870091
	v_dot2_f32_bf16 v4, v59, v44, v4                           // 0000003503BC: CC1A4004 1C12593B
	v_dot2_f32_bf16 v4, v60, v45, v4                           // 0000003503C4: CC1A4004 1C125B3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003503CC: BF870091
	v_dot2_f32_bf16 v4, v61, v7, v4                            // 0000003503D0: CC1A4004 1C120F3D
	v_dual_mov_b32 v7, v3 :: v_dual_add_f32 v18, v18, v4       // 0000003503D8: CA080103 07120912
	v_mov_b32_e32 v4, v0                                       // 0000003503E0: 7E080300
	s_and_not1_b32 exec_lo, exec_lo, s15                       // 0000003503E4: 917E0F7E
	s_cbranch_execz 38                                         // 0000003503E8: BFA50026 <_ZN7halogen12_GLOBAL__N_16k_lq6wILi7ELi32ELi1EEEvPKhPKtPtll+0x1284>
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000003503EC: BF8701B1
	v_dual_mov_b32 v0, v4 :: v_dual_add_nc_u32 v33, 32, v33    // 0000003503F0: CA200104 002042A0
	v_dual_mov_b32 v1, v5 :: v_dual_mov_b32 v2, v6             // 0000003503F8: CA100105 01020106
	v_dual_mov_b32 v3, v7 :: v_dual_mov_b32 v14, v16           // 000000350400: CA100107 030E0110
	.long 0xd4430000                                           // 000000350408: D4430000
	v_cndmask_b32_e32 v1, s12, v33, vcc_lo                     // 00000035040C: 0202420C
	v_mov_b32_e32 v13, v15                                     // 000000350410: 7E1A030F
	s_mov_b32 s17, exec_lo                                     // 000000350414: BE91007E
	.long 0xd4c4007e                                           // 000000350418: D4C4007E
	v_cndmask_b32_e32 v1, s12, v33, vcc_lo                     // 00000035041C: 0202420C
	s_cbranch_execz 64525                                      // 000000350420: BFA5FC0D <_ZN7halogen12_GLOBAL__N_16k_lq6wILi7ELi32ELi1EEEvPKhPKtPtll+0x258>
	v_and_b32_e32 v2, 0x7ffffffc, v32                          // 000000350424: 360440FF 7FFFFFFC
	.long 0xd7000100                                           // 00000035042C: D7000100
	v_cndmask_b32_e32 v1, v10, v30, vcc_lo                     // 000000350430: 02023D0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000350434: BF8700A1
	v_add_co_ci_u32_e64 v1, null, 0, v19, s1                   // 000000350438: D5207C01 00062680
	.long 0xd700010d                                           // 000000350440: D700010D
	v_cndmask_b32_e32 v1, v26, v31, vcc_lo                     // 000000350444: 02023F1A
	v_add_co_ci_u32_e64 v14, null, 0, v27, s1                  // 000000350448: D5207C0E 00063680
	.long 0xd7000122                                           // 000000350450: D7000122
	v_cndmask_b32_e32 v1, v28, v2, vcc_lo                      // 000000350454: 0202051C
	s_delay_alu instid0(VALU_DEP_1)                            // 000000350458: BF870001
	v_add_co_ci_u32_e64 v35, null, 0, v29, s1                  // 00000035045C: D5207C23 00063A80
	s_clause 0x2                                               // 000000350464: BF850002
	global_load_b128 v[0:3], v[0:1], off                       // 000000350468: DC5E0000 007C0000
	global_load_b64 v[13:14], v[13:14], off                    // 000000350470: DC560000 0D7C000D
	global_load_b32 v34, v[34:35], off                         // 000000350478: DC520000 227C0022
	s_branch 64501                                             // 000000350480: BFA0FBF5 <_ZN7halogen12_GLOBAL__N_16k_lq6wILi7ELi32ELi1EEEvPKhPKtPtll+0x258>
	s_or_b32 exec_lo, exec_lo, s15                             // 000000350484: 8C7E0F7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000350488: BF8700A9
	s_or_b32 exec_lo, exec_lo, s13                             // 00000035048C: 8C7E0D7E
	.long 0xd71f0000                                           // 000000350490: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 000000350494: 020100C1
	v_xor_b32_e32 v1, 16, v0                                   // 000000350498: 3A020090
	v_xor_b32_e32 v10, 8, v0                                   // 00000035049C: 3A140088
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003504A0: BF870092
	.long 0xd44c0000                                           // 0000003504A4: D44C0000
	v_cndmask_b32_e32 v1, 32, v1, vcc_lo                       // 0000003504A8: 020202A0
	v_cndmask_b32_e64 v1, v0, v1, s0                           // 0000003504AC: D5010001 00020300
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003504B4: BF870113
	.long 0xd44c0000                                           // 0000003504B8: D44C0000
	v_cndmask_b32_e32 v1, 32, v10, vcc_lo                      // 0000003504BC: 020214A0
	v_lshlrev_b32_e32 v1, 2, v1                                // 0000003504C0: 30020282
	s_delay_alu instid0(VALU_DEP_2)                            // 0000003504C4: BF870002
	v_cndmask_b32_e64 v10, v0, v10, s0                         // 0000003504C8: D501000A 00021500
	ds_bpermute_b32 v2, v1, v18                                // 0000003504D0: DACC0000 02001201
	s_waitcnt lgkmcnt(0)                                       // 0000003504D8: BF89FC07
	v_add_f32_e32 v2, v18, v2                                  // 0000003504DC: 06040512
	s_waitcnt vmcnt(2)                                         // 0000003504E0: BF890BF7
	ds_bpermute_b32 v4, v1, v25                                // 0000003504E4: DACC0000 04001901
	ds_bpermute_b32 v3, v1, v24                                // 0000003504EC: DACC0000 03001801
	ds_bpermute_b32 v5, v1, v22                                // 0000003504F4: DACC0000 05001601
	ds_bpermute_b32 v6, v1, v23                                // 0000003504FC: DACC0000 06001701
	ds_bpermute_b32 v7, v1, v20                                // 000000350504: DACC0000 07001401
	ds_bpermute_b32 v1, v1, v21                                // 00000035050C: DACC0000 01001501
	v_lshlrev_b32_e32 v10, 2, v10                              // 000000350514: 30141482
	v_xor_b32_e32 v18, 4, v0                                   // 000000350518: 3A240084
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000035051C: BF870091
	.long 0xd44c0000                                           // 000000350520: D44C0000
	v_cndmask_b32_e32 v1, 32, v18, vcc_lo                      // 000000350524: 020224A0
	v_cndmask_b32_e64 v18, v0, v18, s0                         // 000000350528: D5010012 00022500
	s_waitcnt lgkmcnt(4)                                       // 000000350530: BF89FC47
	v_dual_add_f32 v4, v25, v4 :: v_dual_add_f32 v3, v24, v3   // 000000350534: C9080919 04020718
	s_waitcnt lgkmcnt(3)                                       // 00000035053C: BF89FC37
	v_add_f32_e32 v5, v22, v5                                  // 000000350540: 060A0B16
	ds_bpermute_b32 v11, v10, v2                               // 000000350544: DACC0000 0B00020A
	s_waitcnt lgkmcnt(2)                                       // 00000035054C: BF89FC27
	v_dual_add_f32 v6, v23, v6 :: v_dual_add_f32 v7, v20, v7   // 000000350550: C9080D17 06060F14
	ds_bpermute_b32 v13, v10, v4                               // 000000350558: DACC0000 0D00040A
	ds_bpermute_b32 v12, v10, v3                               // 000000350560: DACC0000 0C00030A
	ds_bpermute_b32 v14, v10, v5                               // 000000350568: DACC0000 0E00050A
	s_waitcnt lgkmcnt(4)                                       // 000000350570: BF89FC47
	v_dual_add_f32 v1, v21, v1 :: v_dual_lshlrev_b32 v18, 2, v18// 000000350574: C9220315 01122482
	s_waitcnt vmcnt(1)                                         // 00000035057C: BF8907F7
	ds_bpermute_b32 v15, v10, v6                               // 000000350580: DACC0000 0F00060A
	ds_bpermute_b32 v16, v10, v7                               // 000000350588: DACC0000 1000070A
	ds_bpermute_b32 v10, v10, v1                               // 000000350590: DACC0000 0A00010A
	s_waitcnt lgkmcnt(6)                                       // 000000350598: BF89FC67
	v_add_f32_e32 v2, v2, v11                                  // 00000035059C: 06041702
	s_waitcnt lgkmcnt(4)                                       // 0000003505A0: BF89FC47
	v_dual_add_f32 v4, v4, v13 :: v_dual_add_f32 v3, v3, v12   // 0000003505A4: C9081B04 04021903
	s_waitcnt lgkmcnt(3)                                       // 0000003505AC: BF89FC37
	v_add_f32_e32 v5, v5, v14                                  // 0000003505B0: 060A1D05
	ds_bpermute_b32 v12, v18, v4                               // 0000003505B4: DACC0000 0C000412
	s_waitcnt lgkmcnt(2)                                       // 0000003505BC: BF89FC27
	v_dual_add_f32 v6, v6, v15 :: v_dual_add_f32 v7, v7, v16   // 0000003505C0: C9081F06 06062107
	s_waitcnt lgkmcnt(1)                                       // 0000003505C8: BF89FC17
	v_add_f32_e32 v1, v1, v10                                  // 0000003505CC: 06021501
	ds_bpermute_b32 v11, v18, v3                               // 0000003505D0: DACC0000 0B000312
	ds_bpermute_b32 v10, v18, v2                               // 0000003505D8: DACC0000 0A000212
	ds_bpermute_b32 v13, v18, v5                               // 0000003505E0: DACC0000 0D000512
	ds_bpermute_b32 v14, v18, v6                               // 0000003505E8: DACC0000 0E000612
	ds_bpermute_b32 v15, v18, v7                               // 0000003505F0: DACC0000 0F000712
	s_waitcnt lgkmcnt(5)                                       // 0000003505F8: BF89FC57
	v_add_f32_e32 v4, v4, v12                                  // 0000003505FC: 06081904
	ds_bpermute_b32 v16, v18, v1                               // 000000350600: DACC0000 10000112
	v_xor_b32_e32 v18, 2, v0                                   // 000000350608: 3A240082
	v_xor_b32_e32 v12, 1, v0                                   // 00000035060C: 3A180081
	s_waitcnt lgkmcnt(4)                                       // 000000350610: BF89FC47
	v_dual_add_f32 v3, v3, v11 :: v_dual_add_f32 v2, v2, v10   // 000000350614: C9081703 03021502
	s_waitcnt lgkmcnt(3)                                       // 00000035061C: BF89FC37
	v_add_f32_e32 v5, v5, v13                                  // 000000350620: 060A1B05
	.long 0xd44c0000                                           // 000000350624: D44C0000
	v_cndmask_b32_e32 v1, 32, v18, vcc_lo                      // 000000350628: 020224A0
	s_waitcnt lgkmcnt(1)                                       // 00000035062C: BF89FC17
	v_dual_add_f32 v6, v6, v14 :: v_dual_add_f32 v7, v7, v15   // 000000350630: C9081D06 06061F07
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000350638: BF870122
	v_cndmask_b32_e64 v18, v0, v18, s0                         // 00000035063C: D5010012 00022500
	.long 0xd44c0000                                           // 000000350644: D44C0000
	v_cndmask_b32_e32 v1, 32, v12, vcc_lo                      // 000000350648: 020218A0
	v_lshlrev_b32_e32 v18, 2, v18                              // 00000035064C: 30242482
	s_delay_alu instid0(VALU_DEP_2)                            // 000000350650: BF870002
	v_cndmask_b32_e64 v0, v0, v12, s0                          // 000000350654: D5010000 00021900
	.long 0xd44a0000                                           // 00000035065C: D44A0000
	v_cndmask_b32_e32 v1, 0, v17, vcc_lo                       // 000000350660: 02022280
	ds_bpermute_b32 v10, v18, v3                               // 000000350664: DACC0000 0A000312
	s_waitcnt lgkmcnt(1)                                       // 00000035066C: BF89FC17
	v_add_f32_e32 v1, v1, v16                                  // 000000350670: 06022101
	ds_bpermute_b32 v11, v18, v4                               // 000000350674: DACC0000 0B000412
	ds_bpermute_b32 v14, v18, v5                               // 00000035067C: DACC0000 0E000512
	ds_bpermute_b32 v15, v18, v6                               // 000000350684: DACC0000 0F000612
	ds_bpermute_b32 v16, v18, v7                               // 00000035068C: DACC0000 10000712
	v_lshlrev_b32_e32 v20, 2, v0                               // 000000350694: 30280082
	s_and_b32 s0, s0, vcc_lo                                   // 000000350698: 8B006A00
	s_waitcnt lgkmcnt(4)                                       // 00000035069C: BF89FC47
	v_add_f32_e32 v12, v3, v10                                 // 0000003506A0: 06181503
	ds_bpermute_b32 v19, v18, v1                               // 0000003506A4: DACC0000 13000112
	ds_bpermute_b32 v18, v18, v2                               // 0000003506AC: DACC0000 12000212
	s_waitcnt lgkmcnt(4)                                       // 0000003506B4: BF89FC47
	v_dual_add_f32 v13, v4, v11 :: v_dual_add_f32 v4, v5, v14  // 0000003506B8: C9081704 0D041D05
	s_waitcnt lgkmcnt(2)                                       // 0000003506C0: BF89FC27
	v_dual_add_f32 v5, v6, v15 :: v_dual_add_f32 v0, v7, v16   // 0000003506C4: C9081F06 05002107
	ds_bpermute_b32 v15, v20, v12                              // 0000003506CC: DACC0000 0F000C14
	ds_bpermute_b32 v14, v20, v13                              // 0000003506D4: DACC0000 0E000D14
	ds_bpermute_b32 v7, v20, v4                                // 0000003506DC: DACC0000 07000414
	ds_bpermute_b32 v6, v20, v5                                // 0000003506E4: DACC0000 06000514
	s_waitcnt lgkmcnt(4)                                       // 0000003506EC: BF89FC47
	v_dual_add_f32 v1, v1, v19 :: v_dual_add_f32 v10, v2, v18  // 0000003506F0: C9082701 010A2502
	ds_bpermute_b32 v3, v20, v0                                // 0000003506F8: DACC0000 03000014
	ds_bpermute_b32 v2, v20, v1                                // 000000350700: DACC0000 02000114
	ds_bpermute_b32 v11, v20, v10                              // 000000350708: DACC0000 0B000A14
	s_and_saveexec_b32 s1, s0                                  // 000000350710: BE812000
	s_cbranch_execz 102                                        // 000000350714: BFA50066 <_ZN7halogen12_GLOBAL__N_16k_lq6wILi7ELi32ELi1EEEvPKhPKtPtll+0x16b0>
	s_waitcnt lgkmcnt(5)                                       // 000000350718: BF89FC57
	v_dual_add_f32 v12, v12, v15 :: v_dual_add_f32 v13, v13, v14// 00000035071C: C9081F0C 0C0C1D0D
	.long 0x7f1c3880                                           // 000000350724: 7F1C3880
	.long 0xd73c0008                                           // 000000350728: D73C0008
	v_cndmask_b32_e32 v1, 1, v8, vcc_lo                        // 00000035072C: 02021081
	s_lshl_b64 s[0:1], s[2:3], 1                               // 000000350730: 84808102
	s_delay_alu instid0(VALU_DEP_3)                            // 000000350734: BF870003
	.long 0x7e1c398c                                           // 000000350738: 7E1C398C
	.long 0x7e1e398d                                           // 00000035073C: 7E1E398D
	.long 0x7f1e398e                                           // 000000350740: 7F1E398E
	s_waitcnt lgkmcnt(0)                                       // 000000350744: BF89FC07
	v_add_f32_e32 v10, v10, v11                                // 000000350748: 0614170A
	.long 0xd7006a08                                           // 00000035074C: D7006A08
	v_cndmask_b32_e32 v1, s8, v8, vcc_lo                       // 000000350750: 02021008
	v_dual_add_f32 v7, v4, v7 :: v_dual_and_b32 v16, 1, v14    // 000000350754: C9240F04 07101C81
	v_dual_add_f32 v6, v5, v6 :: v_dual_and_b32 v15, 1, v15    // 00000035075C: C9240D05 060E1E81
	v_add_co_ci_u32_e64 v9, null, s9, v9, vcc_lo               // 000000350764: D5207C09 01AA1209
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000035076C: BF870223
	v_add3_u32 v16, v12, v16, 0x7fff                           // 000000350770: D6550010 03FE210C 00007FFF
	.long 0xd7006a0c                                           // 00000035077C: D7006A0C
	v_cndmask_b32_e32 v0, v8, v0, vcc_lo                       // 000000350780: 02000108
	v_add3_u32 v15, v13, v15, 0x7fff                           // 000000350784: D655000F 03FE1F0D 00007FFF
	s_delay_alu instid0(VALU_DEP_4)                            // 000000350790: BF870004
	v_add_co_ci_u32_e64 v13, null, s1, v9, vcc_lo              // 000000350794: D5207C0D 01AA1201
	s_clause 0x1                                               // 00000035079C: BF850001
	global_store_d16_hi_b16 v[8:9], v15, off                   // 0000003507A0: DC960000 007C0F08
	global_store_d16_hi_b16 v[12:13], v16, off                 // 0000003507A8: DC960000 007C100C
	.long 0x7e1c3987                                           // 0000003507B0: 7E1C3987
	v_add_f32_e32 v13, v1, v2                                  // 0000003507B4: 061A0501
	s_lshl_b64 s[0:1], s[2:3], 2                               // 0000003507B8: 84808202
	.long 0x7e163986                                           // 0000003507BC: 7E163986
	.long 0xd7006a04                                           // 0000003507C0: D7006A04
	v_cndmask_b32_e32 v0, v8, v0, vcc_lo                       // 0000003507C4: 02000108
	.long 0x7f16398e                                           // 0000003507C8: 7F16398E
	v_add_f32_e32 v12, v0, v3                                  // 0000003507CC: 06180700
	v_mad_u64_u32 v[0:1], null, s2, 6, v[8:9]                  // 0000003507D0: D6FE7C00 04210C02
	v_and_b32_e32 v2, 1, v14                                   // 0000003507D8: 36041C81
	.long 0x7e10398d                                           // 0000003507DC: 7E10398D
	.long 0x7f10398e                                           // 0000003507E0: 7F10398E
	v_and_b32_e32 v3, 1, v11                                   // 0000003507E4: 36061681
	v_add_co_ci_u32_e64 v5, null, s1, v9, vcc_lo               // 0000003507E8: D5207C05 01AA1201
	v_add3_u32 v11, v7, v2, 0x7fff                             // 0000003507F0: D655000B 03FE0507 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 0000003507FC: BF870254
	v_and_b32_e32 v7, 1, v8                                    // 000000350800: 360E1081
	.long 0x7e1c398c                                           // 000000350804: 7E1C398C
	v_mad_u64_u32 v[1:2], null, s3, 6, v[1:2]                  // 000000350808: D6FE7C01 04050C03
	v_add3_u32 v15, v6, v3, 0x7fff                             // 000000350810: D655000F 03FE0706 00007FFF
	.long 0xd7006a02                                           // 00000035081C: D7006A02
	v_cndmask_b32_e32 v0, v4, v0, vcc_lo                       // 000000350820: 02000104
	v_and_b32_e32 v6, 1, v14                                   // 000000350824: 360C1C81
	v_bfe_u32 v8, v10, 16, 1                                   // 000000350828: D6100008 0205210A
	v_add_co_ci_u32_e64 v3, null, s1, v5, vcc_lo               // 000000350830: D5207C03 01AA0A01
	v_add3_u32 v13, v13, v7, 0x7fff                            // 000000350838: D655000D 03FE0F0D 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000350844: BF8700A4
	v_add3_u32 v12, v12, v6, 0x7fff                            // 000000350848: D655000C 03FE0D0C 00007FFF
	.long 0xd7006a06                                           // 000000350854: D7006A06
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 000000350858: 02000100
	v_add_co_ci_u32_e64 v7, null, s1, v1, vcc_lo               // 00000035085C: D5207C07 01AA0201
	v_add3_u32 v10, v10, v8, 0x7fff                            // 000000350864: D655000A 03FE110A 00007FFF
	.long 0xd7006a08                                           // 000000350870: D7006A08
	v_cndmask_b32_e32 v0, v2, v0, vcc_lo                       // 000000350874: 02000102
	s_delay_alu instid0(VALU_DEP_1)                            // 000000350878: BF870001
	v_add_co_ci_u32_e64 v9, null, s1, v3, vcc_lo               // 00000035087C: D5207C09 01AA0601
	s_clause 0x4                                               // 000000350884: BF850004
	global_store_d16_hi_b16 v[4:5], v15, off                   // 000000350888: DC960000 007C0F04
	global_store_d16_hi_b16 v[0:1], v11, off                   // 000000350890: DC960000 007C0B00
	global_store_d16_hi_b16 v[2:3], v13, off                   // 000000350898: DC960000 007C0D02
	global_store_d16_hi_b16 v[6:7], v12, off                   // 0000003508A0: DC960000 007C0C06
	global_store_d16_hi_b16 v[8:9], v10, off                   // 0000003508A8: DC960000 007C0A08
	s_endpgm                                                   // 0000003508B0: BFB00000
		...

