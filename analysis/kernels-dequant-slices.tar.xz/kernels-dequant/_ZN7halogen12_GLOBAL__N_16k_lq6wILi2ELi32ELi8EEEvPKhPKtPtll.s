0000000000333300 <_ZN7halogen12_GLOBAL__N_16k_lq6wILi2ELi32ELi8EEEvPKhPKtPtll>:
; _ZN7halogen12_GLOBAL__N_16k_lq6wILi2ELi32ELi8EEEvPKhPKtPtll():
	s_load_b256 s[4:11], s[0:1], null                          // 000000333300: F40C0100 F8000000
	v_mov_b32_e32 v6, 0                                        // 000000333308: 7E0C0280
	s_mov_b32 s3, 0                                            // 00000033330C: BE830080
	v_lshrrev_b32_e32 v16, 5, v0                               // 000000333310: 32200085
	v_dual_mov_b32 v18, 0 :: v_dual_mov_b32 v5, 0              // 000000333314: CA100080 12040080
	v_dual_mov_b32 v7, 0 :: v_dual_mov_b32 v8, 0               // 00000033331C: CA100080 07080080
	v_mov_b32_e32 v15, 0                                       // 000000333324: 7E1E0280
	v_mov_b32_e32 v11, 0                                       // 000000333328: 7E160280
	v_dual_mov_b32 v14, 0 :: v_dual_and_b32 v17, 31, v0        // 00000033332C: CA240080 0E10009F
	s_waitcnt lgkmcnt(0)                                       // 000000333334: BF89FC07
	s_ashr_i32 s14, s11, 31                                    // 000000333338: 860E9F0B
	v_mov_b32_e32 v1, s4                                       // 00000033333C: 7E020204
	s_lshr_b32 s12, s14, 27                                    // 000000333340: 850C9B0E
	v_mov_b32_e32 v2, s5                                       // 000000333344: 7E040205
	s_add_u32 s12, s10, s12                                    // 000000333348: 800C0C0A
	s_addc_u32 s13, s11, 0                                     // 00000033334C: 820D800B
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 000000333350: BF8704B9
	s_lshr_b64 s[18:19], s[12:13], 5                           // 000000333354: 8592850C
	s_load_b64 s[12:13], s[0:1], 0x20                          // 000000333358: F4040300 F8000020
	s_add_i32 s15, s18, 7                                      // 000000333360: 810F8712
	s_ashr_i32 s16, s15, 31                                    // 000000333364: 86109F0F
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000333368: BF870499
	s_lshr_b32 s0, s16, 29                                     // 00000033336C: 85009D10
	s_add_i32 s15, s15, s0                                     // 000000333370: 810F000F
	s_lshr_b32 s0, s11, 31                                     // 000000333374: 85009F0B
	s_ashr_i32 s19, s15, 3                                     // 000000333378: 8613830F
	s_add_u32 s0, s10, s0                                      // 00000033337C: 8000000A
	s_addc_u32 s1, s11, 0                                      // 000000333380: 8201800B
	s_lshr_b32 s15, s14, 30                                    // 000000333384: 850F9E0E
	s_ashr_i64 s[16:17], s[0:1], 1                             // 000000333388: 86908100
	s_add_u32 s0, s10, s15                                     // 00000033338C: 80000F0A
	s_addc_u32 s1, s11, 0                                      // 000000333390: 8201800B
	s_lshr_b32 s20, s14, 28                                    // 000000333394: 85149C0E
	s_ashr_i64 s[14:15], s[0:1], 2                             // 000000333398: 868E8200
	s_add_u32 s0, s10, s20                                     // 00000033339C: 8000140A
	s_addc_u32 s1, s11, 0                                      // 0000003333A0: 8201800B
	.long 0xd72c0003                                           // 0000003333A4: D72C0003
	v_cndmask_b32_e32 v1, s19, v16, vcc_lo                     // 0000003333A8: 02022013
	s_ashr_i64 s[0:1], s[0:1], 4                               // 0000003333AC: 86808400
	s_add_u32 s4, s14, s16                                     // 0000003333B0: 8004100E
	s_addc_u32 s20, s15, s17                                   // 0000003333B4: 8214110F
	s_add_u32 s0, s4, s0                                       // 0000003333B8: 80000004
	s_addc_u32 s1, s20, s1                                     // 0000003333BC: 82010114
	s_add_u32 s0, s0, 15                                       // 0000003333C0: 80008F00
	s_addc_u32 s1, s1, 0                                       // 0000003333C4: 82018001
	s_waitcnt lgkmcnt(0)                                       // 0000003333C8: BF89FC07
	.long 0xd4510014                                           // 0000003333CC: D4510014
	v_cndmask_b32_e32 v0, s2, v12, vcc_lo                      // 0000003333D0: 02001802
	s_ashr_i32 s4, s1, 31                                      // 0000003333D4: 86049F01
	v_add_nc_u32_e32 v19, v3, v17                              // 0000003333D8: 4A262303
	s_lshr_b32 s4, s4, 28                                      // 0000003333DC: 85049C04
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000003333E0: BF870009
	s_add_u32 s0, s0, s4                                       // 0000003333E4: 80000400
	s_addc_u32 s1, s1, 0                                       // 0000003333E8: 82018001
	s_lshl_b64 s[4:5], s[2:3], 4                               // 0000003333EC: 84848402
	s_ashr_i64 s[0:1], s[0:1], 4                               // 0000003333F0: 86808400
	s_and_b32 s20, s20, exec_lo                                // 0000003333F4: 8B147E14
	s_cselect_b32 s4, s4, 0                                    // 0000003333F8: 98048004
	s_cselect_b32 s5, s5, 0                                    // 0000003333FC: 98058005
	v_mad_u64_u32 v[9:10], null, s4, s0, v[1:2]                // 000000333400: D6FE7C09 04040004
	v_add_nc_u32_e32 v1, s19, v3                               // 000000333408: 4A020613
	s_mul_i32 s5, s5, s0                                       // 00000033340C: 96050005
	s_mul_i32 s4, s4, s1                                       // 000000333410: 96040104
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000333414: BF870191
	v_min_i32_e32 v20, s18, v1                                 // 000000333418: 22280212
	v_add_nc_u32_e32 v1, s5, v10                               // 00000033341C: 4A021405
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000333420: BF870112
	v_cmp_lt_i32_e32 vcc_lo, v19, v20                          // 000000333424: 7C822913
	v_add_nc_u32_e32 v21, s4, v1                               // 000000333428: 4A2A0204
	s_and_saveexec_b32 s1, vcc_lo                              // 00000033342C: BE81206A
	s_cbranch_execz 39                                         // 000000333430: BFA50027 <_ZN7halogen12_GLOBAL__N_16k_lq6wILi2ELi32ELi8EEEvPKhPKtPtll+0x1d0>
	v_lshlrev_b32_e32 v1, 4, v19                               // 000000333434: 30022684
	v_lshlrev_b32_e32 v4, 1, v19                               // 000000333438: 30082681
	v_lshlrev_b32_e32 v3, 3, v19                               // 00000033343C: 30062683
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000333440: BF870223
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000333444: 3404029F
	.long 0xd7000001                                           // 000000333448: D7000001
	v_cndmask_b32_e32 v1, v9, v1, vcc_lo                       // 00000033344C: 02020309
	v_and_b32_e32 v8, -4, v4                                   // 000000333450: 361008C4
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000333454: BF870214
	v_ashrrev_i32_e32 v7, 31, v3                               // 000000333458: 340E069F
	v_add_co_ci_u32_e64 v2, null, v21, v2, s0                  // 00000033345C: D5207C02 00020515
	.long 0xd7000005                                           // 000000333464: D7000005
	v_cndmask_b32_e32 v0, v9, v16, vcc_lo                      // 000000333468: 02002109
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000033346C: BF8701A1
	v_add_co_ci_u32_e64 v6, null, s17, v21, s0                 // 000000333470: D5207C06 00022A11
	v_ashrrev_i32_e32 v12, 31, v8                              // 000000333478: 3418109F
	.long 0xd700000a                                           // 00000033347C: D700000A
	v_cndmask_b32_e32 v0, v5, v14, vcc_lo                      // 000000333480: 02001D05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000333484: BF8700A1
	v_add_co_ci_u32_e64 v11, null, s15, v6, s0                 // 000000333488: D5207C0B 00020C0F
	.long 0xd7000003                                           // 000000333490: D7000003
	v_cndmask_b32_e32 v1, v5, v3, vcc_lo                       // 000000333494: 02020705
	v_add_co_ci_u32_e64 v4, null, v6, v7, s0                   // 000000333498: D5207C04 00020F06
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003334A0: BF870094
	.long 0xd700000a                                           // 0000003334A4: D700000A
	v_cndmask_b32_e32 v1, v10, v8, vcc_lo                      // 0000003334A8: 0202110A
	v_add_co_ci_u32_e64 v11, null, v11, v12, s0                // 0000003334AC: D5207C0B 0002190B
	s_clause 0x2                                               // 0000003334B4: BF850002
	global_load_b128 v[5:8], v[1:2], off                       // 0000003334B8: DC5E0000 057C0001
	global_load_b64 v[14:15], v[3:4], off                      // 0000003334C0: DC560000 0E7C0003
	global_load_b32 v11, v[10:11], off                         // 0000003334C8: DC520000 0B7C000A
	s_or_b32 exec_lo, exec_lo, s1                              // 0000003334D0: 8C7E017E
	v_mov_b32_e32 v22, 0                                       // 0000003334D4: 7E2C0280
	s_and_saveexec_b32 s1, vcc_lo                              // 0000003334D8: BE81206A
	s_cbranch_execz 769                                        // 0000003334DC: BFA50301 <_ZN7halogen12_GLOBAL__N_16k_lq6wILi2ELi32ELi8EEEvPKhPKtPtll+0xde4>
	.long 0xd7006a17                                           // 0000003334E0: D7006A17
	v_cndmask_b32_e32 v0, v9, v16, vcc_lo                      // 0000003334E4: 02002109
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000003334E8: BF8701A1
	v_add_co_ci_u32_e64 v24, null, s17, v21, vcc_lo            // 0000003334EC: D5207C18 01AA2A11
	v_dual_mov_b32 v18, 0 :: v_dual_add_nc_u32 v1, 32, v19     // 0000003334F4: CA200080 120026A0
	.long 0xd7006a19                                           // 0000003334FC: D7006A19
	v_cndmask_b32_e32 v0, v23, v14, vcc_lo                     // 000000333500: 02001D17
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000333504: BF870221
	v_add_co_ci_u32_e64 v26, null, s15, v24, vcc_lo            // 000000333508: D5207C1A 01AA300F
	v_lshlrev_b32_e32 v10, 5, v19                              // 000000333510: 30142685
	v_dual_mov_b32 v22, 0 :: v_dual_lshlrev_b32 v27, 4, v1     // 000000333514: CA220080 161A0284
	v_lshlrev_b32_e32 v28, 3, v1                               // 00000033351C: 30380283
	s_waitcnt vmcnt(0)                                         // 000000333520: BF8903F7
	v_dual_mov_b32 v30, v11 :: v_dual_lshlrev_b32 v29, 1, v1   // 000000333524: CA22010B 1E1C0281
	s_mov_b32 s14, 0                                           // 00000033352C: BE8E0080
	s_lshl_b64 s[4:5], s[10:11], 1                             // 000000333530: 8484810A
	s_branch 707                                               // 000000333534: BFA002C3 <_ZN7halogen12_GLOBAL__N_16k_lq6wILi2ELi32ELi8EEEvPKhPKtPtll+0xd44>
	s_or_b32 exec_lo, exec_lo, s10                             // 000000333538: 8C7E0A7E
	v_lshlrev_b32_e32 v31, 4, v14                              // 00000033353C: 303E1C84
	v_lshlrev_b32_e32 v33, 2, v14                              // 000000333540: 30421C82
	v_lshrrev_b32_e32 v32, 4, v5                               // 000000333544: 32400A84
	v_lshrrev_b32_e32 v34, 2, v14                              // 000000333548: 32441C82
	.long 0x7f4a3880                                           // 00000033354C: 7F4A3880
	v_and_b32_e32 v31, 48, v31                                 // 000000333550: 363E3EB0
	v_and_b32_e32 v33, 48, v33                                 // 000000333554: 364242B0
	v_lshrrev_b32_e32 v36, 6, v14                              // 000000333558: 32481C86
	v_and_b32_e32 v34, 48, v34                                 // 00000033355C: 364444B0
	v_lshrrev_b32_e32 v35, 20, v5                              // 000000333560: 32460A94
	v_and_or_b32 v31, v5, 15, v31                              // 000000333564: D657001F 047D1F05
	v_and_or_b32 v32, v32, 15, v33                             // 00000033356C: D6570020 04851F20
	v_and_b32_e32 v36, 48, v36                                 // 000000333574: 364848B0
	v_lshrrev_b32_e32 v39, 18, v14                             // 000000333578: 324E1C92
	v_lshrrev_b32_e32 v40, 22, v14                             // 00000033357C: 32501C96
	v_cvt_f32_ubyte0_e32 v31, v31                              // 000000333580: 7E3E231F
	v_lshrrev_b32_e32 v41, 6, v15                              // 000000333584: 32521E86
	v_and_or_b32 v35, v35, 15, v36                             // 000000333588: D6570023 04911F23
	v_and_b32_e32 v39, 48, v39                                 // 000000333590: 364E4EB0
	v_and_b32_e32 v40, 48, v40                                 // 000000333594: 365050B0
	v_fma_mix_f32 v31, v31, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000333598: CC20601F 142E171F
	v_and_b32_e32 v41, 48, v41                                 // 0000003335A0: 365252B0
	s_and_b32 s0, exec_lo, vcc_lo                              // 0000003335A4: 8B006A7E
	v_add_nc_u32_e32 v27, 0x200, v27                           // 0000003335A8: 4A3636FF 00000200
	v_add_nc_u32_e32 v28, 0x100, v28                           // 0000003335B0: 4A3838FF 00000100
	v_bfe_u32 v33, v31, 16, 1                                  // 0000003335B8: D6100021 0205211F
	v_add_nc_u32_e32 v29, 64, v29                              // 0000003335C0: 4A3A3AC0
	s_or_b32 s14, s0, s14                                      // 0000003335C4: 8C0E0E00
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000003335C8: BF870122
	v_add3_u32 v31, v31, v33, 0x7fff                           // 0000003335CC: D655001F 03FE431F 00007FFF
	v_and_b32_e32 v33, 48, v14                                 // 0000003335D8: 36421CB0
	.long 0x7e4a399f                                           // 0000003335DC: 7E4A399F
	v_cvt_f32_ubyte0_e32 v31, v32                              // 0000003335E0: 7E3E2320
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003335E4: BF870091
	v_fma_mix_f32 v31, v31, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003335E8: CC20601F 142E171F
	v_bfe_u32 v32, v31, 16, 1                                  // 0000003335F0: D6100020 0205211F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000003335F8: BF870121
	v_add3_u32 v31, v31, v32, 0x7fff                           // 0000003335FC: D655001F 03FE411F 00007FFF
	v_lshrrev_b32_e32 v32, 8, v5                               // 000000333608: 32400A88
	v_and_or_b32 v31, 0xffff0000, v31, v37                     // 00000033360C: D657001F 04963EFF FFFF0000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000333618: BF870122
	v_and_or_b32 v32, v32, 15, v33                             // 00000033361C: D6570020 04851F20
	v_lshrrev_b32_e32 v33, 12, v5                              // 000000333624: 32420A8C
	v_cvt_f32_ubyte0_e32 v32, v32                              // 000000333628: 7E402320
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000033362C: BF870112
	v_and_or_b32 v33, v33, 15, v34                             // 000000333630: D6570021 04891F21
	v_fma_mix_f32 v32, v32, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000333638: CC206020 142E1720
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000333640: BF870091
	v_bfe_u32 v34, v32, 16, 1                                  // 000000333644: D6100022 02052120
	v_add3_u32 v32, v32, v34, 0x7fff                           // 00000033364C: D6550020 03FE4520 00007FFF
	v_lshrrev_b32_e32 v34, 8, v14                              // 000000333658: 32441C88
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000033365C: BF8701A2
	.long 0x7e4a39a0                                           // 000000333660: 7E4A39A0
	v_cvt_f32_ubyte0_e32 v32, v33                              // 000000333664: 7E402321
	v_and_b32_e32 v34, 48, v34                                 // 000000333668: 364444B0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000033366C: BF870092
	v_fma_mix_f32 v32, v32, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000333670: CC206020 142E1720
	v_bfe_u32 v33, v32, 16, 1                                  // 000000333678: D6100021 02052120
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000333680: BF870121
	v_add3_u32 v32, v32, v33, 0x7fff                           // 000000333684: D6550020 03FE4320 00007FFF
	v_lshrrev_b32_e32 v33, 4, v14                              // 000000333690: 32421C84
	v_and_or_b32 v32, 0xffff0000, v32, v37                     // 000000333694: D6570020 049640FF FFFF0000
	.long 0x7e4a3985                                           // 0000003336A0: 7E4A3985
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003336A4: BF870093
	v_and_b32_e32 v33, 48, v33                                 // 0000003336A8: 364242B0
	v_and_or_b32 v33, v37, 15, v33                             // 0000003336AC: D6570021 04851F25
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003336B4: BF870091
	v_cvt_f32_ubyte0_e32 v33, v33                              // 0000003336B8: 7E422321
	v_fma_mix_f32 v33, v33, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003336BC: CC206021 142E1721
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003336C4: BF870091
	v_bfe_u32 v36, v33, 16, 1                                  // 0000003336C8: D6100024 02052121
	v_add3_u32 v33, v33, v36, 0x7fff                           // 0000003336D0: D6550021 03FE4921 00007FFF
	v_lshrrev_b32_e32 v36, 12, v14                             // 0000003336DC: 32481C8C
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003336E0: BF8700A2
	.long 0x7e4a39a1                                           // 0000003336E4: 7E4A39A1
	v_cvt_f32_ubyte0_e32 v33, v35                              // 0000003336E8: 7E422323
	v_fma_mix_f32 v33, v33, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003336EC: CC206021 142E1721
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003336F4: BF870091
	v_bfe_u32 v35, v33, 16, 1                                  // 0000003336F8: D6100023 02052121
	v_add3_u32 v33, v33, v35, 0x7fff                           // 000000333700: D6550021 03FE4721 00007FFF
	v_lshrrev_b32_e32 v35, 24, v5                              // 00000033370C: 32460A98
	v_lshrrev_b32_e32 v5, 28, v5                               // 000000333710: 320A0A9C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000333714: BF870193
	v_and_or_b32 v33, 0xffff0000, v33, v37                     // 000000333718: D6570021 049642FF FFFF0000
	v_and_or_b32 v34, v35, 15, v34                             // 000000333724: D6570022 04891F23
	v_lshrrev_b32_e32 v35, 10, v14                             // 00000033372C: 32461C8A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000333730: BF870112
	v_cvt_f32_ubyte0_e32 v34, v34                              // 000000333734: 7E442322
	v_and_or_b32 v5, v35, 48, v5                               // 000000333738: D6570005 04156123
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000333740: BF870112
	v_fma_mix_f32 v34, v34, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000333744: CC206022 142E1722
	v_cvt_f32_ubyte0_e32 v5, v5                                // 00000033374C: 7E0A2305
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000333750: BF870112
	v_bfe_u32 v35, v34, 16, 1                                  // 000000333754: D6100023 02052122
	v_fma_mix_f32 v5, v5, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000033375C: CC206005 142E1705
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000333764: BF870122
	v_add3_u32 v34, v34, v35, 0x7fff                           // 000000333768: D6550022 03FE4722 00007FFF
	v_lshrrev_b32_e32 v35, 4, v6                               // 000000333774: 32460C84
	.long 0x7e4a39a2                                           // 000000333778: 7E4A39A2
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000033377C: BF870094
	v_bfe_u32 v34, v5, 16, 1                                   // 000000333780: D6100022 02052105
	v_add3_u32 v5, v5, v34, 0x7fff                             // 000000333788: D6550005 03FE4505 00007FFF
	v_and_b32_e32 v34, 48, v36                                 // 000000333794: 364448B0
	v_lshrrev_b32_e32 v36, 14, v14                             // 000000333798: 32481C8E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000033379C: BF870193
	v_and_or_b32 v5, 0xffff0000, v5, v37                       // 0000003337A0: D6570005 04960AFF FFFF0000
	v_and_or_b32 v34, v6, 15, v34                              // 0000003337AC: D6570022 04891F06
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000003337B4: BF8701A3
	v_and_b32_e32 v36, 48, v36                                 // 0000003337B8: 364848B0
	.long 0x7e4a398e                                           // 0000003337BC: 7E4A398E
	v_cvt_f32_ubyte0_e32 v34, v34                              // 0000003337C0: 7E442322
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003337C4: BF870193
	v_and_or_b32 v35, v35, 15, v36                             // 0000003337C8: D6570023 04911F23
	v_and_b32_e32 v38, 48, v37                                 // 0000003337D0: 364C4AB0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003337D4: BF870193
	v_fma_mix_f32 v34, v34, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003337D8: CC206022 142E1722
	v_cvt_f32_ubyte0_e32 v35, v35                              // 0000003337E0: 7E462323
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003337E4: BF870112
	v_bfe_u32 v36, v34, 16, 1                                  // 0000003337E8: D6100024 02052122
	v_fma_mix_f32 v35, v35, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003337F0: CC206023 142E1723
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003337F8: BF870112
	v_add3_u32 v34, v34, v36, 0x7fff                           // 0000003337FC: D6550022 03FE4922 00007FFF
	v_bfe_u32 v36, v35, 16, 1                                  // 000000333808: D6100024 02052123
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000333810: BF8701A2
	.long 0x7e4439a2                                           // 000000333814: 7E4439A2
	.long 0x7f4439a5                                           // 000000333818: 7F4439A5
	v_add3_u32 v35, v35, v36, 0x7fff                           // 00000033381C: D6550023 03FE4923 00007FFF
	v_lshrrev_b32_e32 v36, 20, v14                             // 000000333828: 32481C94
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000033382C: BF8701A2
	v_and_or_b32 v34, 0xffff0000, v35, v34                     // 000000333830: D6570022 048A46FF FFFF0000
	v_lshrrev_b32_e32 v35, 8, v6                               // 00000033383C: 32460C88
	v_and_b32_e32 v36, 48, v36                                 // 000000333840: 364848B0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000333844: BF870122
	v_and_or_b32 v35, v35, 15, v38                             // 000000333848: D6570023 04991F23
	v_lshrrev_b32_e32 v38, 12, v6                              // 000000333850: 324C0C8C
	v_cvt_f32_ubyte0_e32 v35, v35                              // 000000333854: 7E462323
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000333858: BF870112
	v_and_or_b32 v38, v38, 15, v39                             // 00000033385C: D6570026 049D1F26
	v_fma_mix_f32 v35, v35, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000333864: CC206023 142E1723
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000033386C: BF870091
	v_bfe_u32 v39, v35, 16, 1                                  // 000000333870: D6100027 02052123
	v_add3_u32 v35, v35, v39, 0x7fff                           // 000000333878: D6550023 03FE4F23 00007FFF
	v_lshrrev_b32_e32 v39, 20, v6                              // 000000333884: 324E0C94
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000333888: BF8701A2
	.long 0x7e4a39a3                                           // 00000033388C: 7E4A39A3
	v_cvt_f32_ubyte0_e32 v35, v38                              // 000000333890: 7E462326
	v_and_or_b32 v39, v39, 15, v40                             // 000000333894: D6570027 04A11F27
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000033389C: BF870092
	v_fma_mix_f32 v35, v35, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003338A0: CC206023 142E1723
	v_bfe_u32 v38, v35, 16, 1                                  // 0000003338A8: D6100026 02052123
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000003338B0: BF8701B1
	v_add3_u32 v35, v35, v38, 0x7fff                           // 0000003338B4: D6550023 03FE4D23 00007FFF
	v_lshrrev_b32_e32 v38, 24, v14                             // 0000003338C0: 324C1C98
	v_lshrrev_b32_e32 v14, 26, v14                             // 0000003338C4: 321C1C9A
	v_and_or_b32 v35, 0xffff0000, v35, v37                     // 0000003338C8: D6570023 049646FF FFFF0000
	.long 0x7e4a3986                                           // 0000003338D4: 7E4A3986
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003338D8: BF870114
	v_and_b32_e32 v38, 48, v38                                 // 0000003338DC: 364C4CB0
	v_and_or_b32 v36, v37, 15, v36                             // 0000003338E0: D6570024 04911F25
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003338E8: BF870091
	v_cvt_f32_ubyte0_e32 v36, v36                              // 0000003338EC: 7E482324
	v_fma_mix_f32 v36, v36, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003338F0: CC206024 142E1724
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003338F8: BF870091
	v_bfe_u32 v40, v36, 16, 1                                  // 0000003338FC: D6100028 02052124
	v_add3_u32 v36, v36, v40, 0x7fff                           // 000000333904: D6550024 03FE5124 00007FFF
	v_lshrrev_b32_e32 v40, 2, v15                              // 000000333910: 32501E82
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000333914: BF8701A2
	.long 0x7e4a39a4                                           // 000000333918: 7E4A39A4
	v_cvt_f32_ubyte0_e32 v36, v39                              // 00000033391C: 7E482327
	v_and_b32_e32 v40, 48, v40                                 // 000000333920: 365050B0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000333924: BF870092
	v_fma_mix_f32 v36, v36, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000333928: CC206024 142E1724
	v_bfe_u32 v39, v36, 16, 1                                  // 000000333930: D6100027 02052124
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000333938: BF8701B1
	v_add3_u32 v36, v36, v39, 0x7fff                           // 00000033393C: D6550024 03FE4F24 00007FFF
	v_lshrrev_b32_e32 v39, 24, v6                              // 000000333948: 324E0C98
	v_lshrrev_b32_e32 v6, 28, v6                               // 00000033394C: 320C0C9C
	v_and_or_b32 v36, 0xffff0000, v36, v37                     // 000000333950: D6570024 049648FF FFFF0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000033395C: BF870193
	v_and_or_b32 v38, v39, 15, v38                             // 000000333960: D6570026 04991F27
	v_and_or_b32 v6, v14, 48, v6                               // 000000333968: D6570006 0419610E
	v_lshlrev_b32_e32 v39, 2, v15                              // 000000333970: 304E1E82
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000333974: BF870193
	v_cvt_f32_ubyte0_e32 v14, v38                              // 000000333978: 7E1C2326
	v_cvt_f32_ubyte0_e32 v6, v6                                // 00000033397C: 7E0C2306
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000333980: BF870193
	v_and_b32_e32 v39, 48, v39                                 // 000000333984: 364E4EB0
	v_fma_mix_f32 v14, v14, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000333988: CC20600E 142E170E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000333990: BF870113
	v_fma_mix_f32 v6, v6, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000333994: CC206006 142E1706
	v_bfe_u32 v38, v14, 16, 1                                  // 00000033399C: D6100026 0205210E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000003339A4: BF870121
	v_add3_u32 v14, v14, v38, 0x7fff                           // 0000003339A8: D655000E 03FE4D0E 00007FFF
	v_lshrrev_b32_e32 v38, 4, v7                               // 0000003339B4: 324C0E84
	.long 0x7e4a398e                                           // 0000003339B8: 7E4A398E
	v_bfe_u32 v14, v6, 16, 1                                   // 0000003339BC: D610000E 02052106
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003339C4: BF870113
	v_and_or_b32 v38, v38, 15, v39                             // 0000003339C8: D6570026 049D1F26
	v_add3_u32 v6, v6, v14, 0x7fff                             // 0000003339D0: D6550006 03FE1D06 00007FFF
	v_lshlrev_b32_e32 v14, 4, v15                              // 0000003339DC: 301C1E84
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003339E0: BF870112
	v_and_or_b32 v6, 0xffff0000, v6, v37                       // 0000003339E4: D6570006 04960CFF FFFF0000
	v_and_b32_e32 v14, 48, v14                                 // 0000003339F0: 361C1CB0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003339F4: BF870091
	v_and_or_b32 v14, v7, 15, v14                              // 0000003339F8: D657000E 04391F07
	v_cvt_f32_ubyte0_e32 v14, v14                              // 000000333A00: 7E1C230E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000333A04: BF870091
	v_fma_mix_f32 v14, v14, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000333A08: CC20600E 142E170E
	v_bfe_u32 v39, v14, 16, 1                                  // 000000333A10: D6100027 0205210E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000333A18: BF870121
	v_add3_u32 v14, v14, v39, 0x7fff                           // 000000333A1C: D655000E 03FE4F0E 00007FFF
	v_and_b32_e32 v39, 48, v15                                 // 000000333A28: 364E1EB0
	.long 0x7e4a398e                                           // 000000333A2C: 7E4A398E
	v_cvt_f32_ubyte0_e32 v14, v38                              // 000000333A30: 7E1C2326
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000333A34: BF870091
	v_fma_mix_f32 v14, v14, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000333A38: CC20600E 142E170E
	v_bfe_u32 v38, v14, 16, 1                                  // 000000333A40: D6100026 0205210E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000333A48: BF870121
	v_add3_u32 v14, v14, v38, 0x7fff                           // 000000333A4C: D655000E 03FE4D0E 00007FFF
	v_lshrrev_b32_e32 v38, 8, v7                               // 000000333A58: 324C0E88
	v_and_or_b32 v14, 0xffff0000, v14, v37                     // 000000333A5C: D657000E 04961CFF FFFF0000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000333A68: BF870122
	v_and_or_b32 v38, v38, 15, v39                             // 000000333A6C: D6570026 049D1F26
	v_lshrrev_b32_e32 v39, 12, v7                              // 000000333A74: 324E0E8C
	v_cvt_f32_ubyte0_e32 v38, v38                              // 000000333A78: 7E4C2326
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000333A7C: BF870112
	v_and_or_b32 v39, v39, 15, v40                             // 000000333A80: D6570027 04A11F27
	v_fma_mix_f32 v38, v38, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000333A88: CC206026 142E1726
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000333A90: BF870091
	v_bfe_u32 v40, v38, 16, 1                                  // 000000333A94: D6100028 02052126
	v_add3_u32 v38, v38, v40, 0x7fff                           // 000000333A9C: D6550026 03FE5126 00007FFF
	v_lshrrev_b32_e32 v40, 20, v7                              // 000000333AA8: 32500E94
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000333AAC: BF8701A2
	.long 0x7e4a39a6                                           // 000000333AB0: 7E4A39A6
	v_cvt_f32_ubyte0_e32 v38, v39                              // 000000333AB4: 7E4C2327
	v_and_or_b32 v40, v40, 15, v41                             // 000000333AB8: D6570028 04A51F28
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000333AC0: BF870092
	v_fma_mix_f32 v38, v38, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000333AC4: CC206026 142E1726
	v_bfe_u32 v39, v38, 16, 1                                  // 000000333ACC: D6100027 02052126
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000333AD4: BF870121
	v_add3_u32 v38, v38, v39, 0x7fff                           // 000000333AD8: D6550026 03FE4F26 00007FFF
	v_lshrrev_b32_e32 v39, 4, v15                              // 000000333AE4: 324E1E84
	v_and_or_b32 v53, 0xffff0000, v38, v37                     // 000000333AE8: D6570035 04964CFF FFFF0000
	.long 0x7e4a3987                                           // 000000333AF4: 7E4A3987
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000333AF8: BF870123
	v_and_b32_e32 v39, 48, v39                                 // 000000333AFC: 364E4EB0
	v_lshrrev_b32_e32 v38, 8, v15                              // 000000333B00: 324C1E88
	v_and_or_b32 v39, v37, 15, v39                             // 000000333B04: D6570027 049D1F25
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000333B0C: BF870112
	v_and_b32_e32 v38, 48, v38                                 // 000000333B10: 364C4CB0
	v_cvt_f32_ubyte0_e32 v39, v39                              // 000000333B14: 7E4E2327
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000333B18: BF870091
	v_fma_mix_f32 v39, v39, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000333B1C: CC206027 142E1727
	v_bfe_u32 v41, v39, 16, 1                                  // 000000333B24: D6100029 02052127
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000333B2C: BF870091
	v_add3_u32 v39, v39, v41, 0x7fff                           // 000000333B30: D6550027 03FE5327 00007FFF
	.long 0x7e4a39a7                                           // 000000333B3C: 7E4A39A7
	v_cvt_f32_ubyte0_e32 v39, v40                              // 000000333B40: 7E4E2328
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000333B44: BF870091
	v_fma_mix_f32 v39, v39, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000333B48: CC206027 142E1727
	v_bfe_u32 v40, v39, 16, 1                                  // 000000333B50: D6100028 02052127
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000333B58: BF870121
	v_add3_u32 v39, v39, v40, 0x7fff                           // 000000333B5C: D6550027 03FE5127 00007FFF
	v_lshrrev_b32_e32 v40, 12, v15                             // 000000333B68: 32501E8C
	v_and_or_b32 v54, 0xffff0000, v39, v37                     // 000000333B6C: D6570036 04964EFF FFFF0000
	v_lshrrev_b32_e32 v39, 24, v7                              // 000000333B78: 324E0E98
	v_lshrrev_b32_e32 v7, 28, v7                               // 000000333B7C: 320E0E9C
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000333B80: BF870122
	v_and_or_b32 v38, v39, 15, v38                             // 000000333B84: D6570026 04991F27
	v_lshrrev_b32_e32 v39, 10, v15                             // 000000333B8C: 324E1E8A
	v_cvt_f32_ubyte0_e32 v38, v38                              // 000000333B90: 7E4C2326
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000333B94: BF870112
	v_and_or_b32 v7, v39, 48, v7                               // 000000333B98: D6570007 041D6127
	v_fma_mix_f32 v38, v38, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000333BA0: CC206026 142E1726
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000333BA8: BF870112
	v_cvt_f32_ubyte0_e32 v7, v7                                // 000000333BAC: 7E0E2307
	v_bfe_u32 v39, v38, 16, 1                                  // 000000333BB0: D6100027 02052126
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000333BB8: BF870112
	v_fma_mix_f32 v7, v7, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000333BBC: CC206007 142E1707
	v_add3_u32 v38, v38, v39, 0x7fff                           // 000000333BC4: D6550026 03FE4F26 00007FFF
	v_lshrrev_b32_e32 v39, 14, v15                             // 000000333BD0: 324E1E8E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000333BD4: BF870212
	.long 0x7e4a39a6                                           // 000000333BD8: 7E4A39A6
	v_bfe_u32 v38, v7, 16, 1                                   // 000000333BDC: D6100026 02052107
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000333BE4: BF870113
	v_and_b32_e32 v39, 48, v39                                 // 000000333BE8: 364E4EB0
	v_add3_u32 v7, v7, v38, 0x7fff                             // 000000333BEC: D6550007 03FE4D07 00007FFF
	v_lshrrev_b32_e32 v38, 4, v8                               // 000000333BF8: 324C1084
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000333BFC: BF8701A2
	v_and_or_b32 v55, 0xffff0000, v7, v37                      // 000000333C00: D6570037 04960EFF FFFF0000
	v_and_b32_e32 v7, 15, v8                                   // 000000333C0C: 360E108F
	v_and_or_b32 v38, v38, 15, v39                             // 000000333C10: D6570026 049D1F26
	.long 0x7e4a398f                                           // 000000333C18: 7E4A398F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000333C1C: BF870193
	v_and_or_b32 v7, v40, 48, v7                               // 000000333C20: D6570007 041D6128
	v_cvt_f32_ubyte0_e32 v38, v38                              // 000000333C28: 7E4C2326
	v_lshrrev_b32_e32 v40, 18, v15                             // 000000333C2C: 32501E92
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000333C30: BF870193
	v_cvt_f32_ubyte0_e32 v7, v7                                // 000000333C34: 7E0E2307
	v_fma_mix_f32 v38, v38, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000333C38: CC206026 142E1726
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000333C40: BF870193
	v_and_b32_e32 v40, 48, v40                                 // 000000333C44: 365050B0
	v_fma_mix_f32 v7, v7, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000333C48: CC206007 142E1707
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000333C50: BF870091
	v_bfe_u32 v39, v7, 16, 1                                   // 000000333C54: D6100027 02052107
	v_add3_u32 v7, v7, v39, 0x7fff                             // 000000333C5C: D6550007 03FE4F07 00007FFF
	v_bfe_u32 v39, v38, 16, 1                                  // 000000333C68: D6100027 02052126
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000333C70: BF8701A2
	.long 0x7e0e3987                                           // 000000333C74: 7E0E3987
	.long 0x7f0e39a5                                           // 000000333C78: 7F0E39A5
	v_add3_u32 v38, v38, v39, 0x7fff                           // 000000333C7C: D6550026 03FE4F26 00007FFF
	v_and_b32_e32 v39, 48, v37                                 // 000000333C88: 364E4AB0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000333C8C: BF870132
	v_and_or_b32 v56, 0xffff0000, v38, v7                      // 000000333C90: D6570038 041E4CFF FFFF0000
	v_lshrrev_b32_e32 v7, 8, v8                                // 000000333C9C: 320E1088
	v_lshrrev_b32_e32 v38, 20, v15                             // 000000333CA0: 324C1E94
	v_and_or_b32 v7, v7, 15, v39                               // 000000333CA4: D6570007 049D1F07
	v_lshrrev_b32_e32 v39, 12, v8                              // 000000333CAC: 324E108C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000333CB0: BF870193
	v_and_b32_e32 v38, 48, v38                                 // 000000333CB4: 364C4CB0
	v_cvt_f32_ubyte0_e32 v7, v7                                // 000000333CB8: 7E0E2307
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000333CBC: BF870113
	v_and_or_b32 v39, v39, 15, v40                             // 000000333CC0: D6570027 04A11F27
	v_fma_mix_f32 v7, v7, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000333CC8: CC206007 142E1707
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000333CD0: BF870091
	v_bfe_u32 v40, v7, 16, 1                                   // 000000333CD4: D6100028 02052107
	v_add3_u32 v7, v7, v40, 0x7fff                             // 000000333CDC: D6550007 03FE5107 00007FFF
	v_lshrrev_b32_e32 v40, 22, v15                             // 000000333CE8: 32501E96
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000333CEC: BF8701A2
	.long 0x7e4a3987                                           // 000000333CF0: 7E4A3987
	v_cvt_f32_ubyte0_e32 v7, v39                               // 000000333CF4: 7E0E2327
	v_and_b32_e32 v40, 48, v40                                 // 000000333CF8: 365050B0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000333CFC: BF870092
	v_fma_mix_f32 v7, v7, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000333D00: CC206007 142E1707
	v_bfe_u32 v39, v7, 16, 1                                   // 000000333D08: D6100027 02052107
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000333D10: BF870121
	v_add3_u32 v7, v7, v39, 0x7fff                             // 000000333D14: D6550007 03FE4F07 00007FFF
	v_lshrrev_b32_e32 v39, 20, v8                              // 000000333D20: 324E1094
	v_and_or_b32 v57, 0xffff0000, v7, v37                      // 000000333D24: D6570039 04960EFF FFFF0000
	.long 0x7e4a3988                                           // 000000333D30: 7E4A3988
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000333D34: BF870233
	v_and_or_b32 v39, v39, 15, v40                             // 000000333D38: D6570027 04A11F27
	v_lshrrev_b32_e32 v7, 24, v15                              // 000000333D40: 320E1E98
	v_lshrrev_b32_e32 v15, 26, v15                             // 000000333D44: 321E1E9A
	v_and_or_b32 v38, v37, 15, v38                             // 000000333D48: D6570026 04991F25
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000333D50: BF870113
	v_and_b32_e32 v7, 48, v7                                   // 000000333D54: 360E0EB0
	v_cvt_f32_ubyte0_e32 v38, v38                              // 000000333D58: 7E4C2326
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000333D5C: BF870091
	v_fma_mix_f32 v38, v38, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000333D60: CC206026 142E1726
	v_bfe_u32 v40, v38, 16, 1                                  // 000000333D68: D6100028 02052126
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000333D70: BF870091
	v_add3_u32 v38, v38, v40, 0x7fff                           // 000000333D74: D6550026 03FE5126 00007FFF
	.long 0x7e4a39a6                                           // 000000333D80: 7E4A39A6
	v_cvt_f32_ubyte0_e32 v38, v39                              // 000000333D84: 7E4C2327
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000333D88: BF870091
	v_fma_mix_f32 v38, v38, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000333D8C: CC206026 142E1726
	v_bfe_u32 v39, v38, 16, 1                                  // 000000333D94: D6100027 02052126
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000333D9C: BF870091
	v_add3_u32 v38, v38, v39, 0x7fff                           // 000000333DA0: D6550026 03FE4F26 00007FFF
	v_and_or_b32 v58, 0xffff0000, v38, v37                     // 000000333DAC: D657003A 04964CFF FFFF0000
	v_lshrrev_b32_e32 v38, 24, v8                              // 000000333DB8: 324C1098
	v_lshrrev_b32_e32 v8, 28, v8                               // 000000333DBC: 3210109C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000333DC0: BF870112
	v_and_or_b32 v7, v38, 15, v7                               // 000000333DC4: D6570007 041D1F26
	v_and_or_b32 v8, v15, 48, v8                               // 000000333DCC: D6570008 0421610F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000333DD4: BF870092
	v_cvt_f32_ubyte0_e32 v7, v7                                // 000000333DD8: 7E0E2307
	v_fma_mix_f32 v7, v7, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000333DDC: CC206007 142E1707
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000333DE4: BF870091
	v_bfe_u32 v15, v7, 16, 1                                   // 000000333DE8: D610000F 02052107
	v_add3_u32 v7, v7, v15, 0x7fff                             // 000000333DF0: D6550007 03FE1F07 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000333DFC: BF8700A1
	.long 0x7e4a3987                                           // 000000333E00: 7E4A3987
	v_cvt_f32_ubyte0_e32 v7, v8                                // 000000333E04: 7E0E2308
	v_fma_mix_f32 v7, v7, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000333E08: CC206007 142E1707
	v_ashrrev_i32_e32 v11, 31, v10                             // 000000333E10: 3416149F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000333E14: BF870092
	v_bfe_u32 v8, v7, 16, 1                                    // 000000333E18: D6100008 02052107
	v_add3_u32 v7, v7, v8, 0x7fff                              // 000000333E20: D6550007 03FE1107 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000333E2C: BF870211
	v_and_or_b32 v15, 0xffff0000, v7, v37                      // 000000333E30: D657000F 04960EFF FFFF0000
	.long 0xd73c0007                                           // 000000333E3C: D73C0007
	v_cndmask_b32_e32 v1, 1, v10, vcc_lo                       // 000000333E40: 02021481
	v_add_nc_u32_e32 v10, 0x400, v10                           // 000000333E44: 4A1414FF 00000400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000333E4C: BF870092
	.long 0xd7006a07                                           // 000000333E50: D7006A07
	v_cndmask_b32_e32 v1, s6, v7, vcc_lo                       // 000000333E54: 02020E06
	v_add_co_ci_u32_e64 v8, null, s7, v8, vcc_lo               // 000000333E58: D5207C08 01AA1007
	s_clause 0x3                                               // 000000333E60: BF850003
	global_load_b128 v[37:40], v[7:8], off                     // 000000333E64: DC5E0000 257C0007
	global_load_b128 v[41:44], v[7:8], off offset:16           // 000000333E6C: DC5E0010 297C0007
	global_load_b128 v[45:48], v[7:8], off offset:32           // 000000333E74: DC5E0020 2D7C0007
	global_load_b128 v[49:52], v[7:8], off offset:48           // 000000333E7C: DC5E0030 317C0007
	.long 0xd7006a07                                           // 000000333E84: D7006A07
	v_cndmask_b32_e32 v0, v7, v4, vcc_lo                       // 000000333E88: 02000907
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000333E8C: BF8700B1
	v_add_co_ci_u32_e64 v8, null, s5, v8, vcc_lo               // 000000333E90: D5207C08 01AA1005
	s_waitcnt vmcnt(3)                                         // 000000333E98: BF890FF7
	v_dot2_f32_bf16 v11, v37, v31, 0                           // 000000333E9C: CC1A400B 1A023F25
	v_dot2_f32_bf16 v11, v38, v32, v11                         // 000000333EA4: CC1A400B 1C2E4126
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000333EAC: BF870091
	v_dot2_f32_bf16 v11, v39, v33, v11                         // 000000333EB0: CC1A400B 1C2E4327
	v_dot2_f32_bf16 v11, v40, v5, v11                          // 000000333EB8: CC1A400B 1C2E0B28
	s_waitcnt vmcnt(2)                                         // 000000333EC0: BF890BF7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000333EC4: BF870091
	v_dot2_f32_bf16 v11, v41, v34, v11                         // 000000333EC8: CC1A400B 1C2E4529
	v_dot2_f32_bf16 v11, v42, v35, v11                         // 000000333ED0: CC1A400B 1C2E472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000333ED8: BF870091
	v_dot2_f32_bf16 v11, v43, v36, v11                         // 000000333EDC: CC1A400B 1C2E492B
	v_dot2_f32_bf16 v11, v44, v6, v11                          // 000000333EE4: CC1A400B 1C2E0D2C
	s_waitcnt vmcnt(1)                                         // 000000333EEC: BF8907F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000333EF0: BF870091
	v_dot2_f32_bf16 v11, v45, v14, v11                         // 000000333EF4: CC1A400B 1C2E1D2D
	v_dot2_f32_bf16 v11, v46, v53, v11                         // 000000333EFC: CC1A400B 1C2E6B2E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000333F04: BF870091
	v_dot2_f32_bf16 v11, v47, v54, v11                         // 000000333F08: CC1A400B 1C2E6D2F
	v_dot2_f32_bf16 v11, v48, v55, v11                         // 000000333F10: CC1A400B 1C2E6F30
	s_waitcnt vmcnt(0)                                         // 000000333F18: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000333F1C: BF870091
	v_dot2_f32_bf16 v11, v49, v56, v11                         // 000000333F20: CC1A400B 1C2E7131
	v_dot2_f32_bf16 v11, v50, v57, v11                         // 000000333F28: CC1A400B 1C2E7332
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000333F30: BF870091
	v_dot2_f32_bf16 v11, v51, v58, v11                         // 000000333F34: CC1A400B 1C2E7533
	v_dot2_f32_bf16 v11, v52, v15, v11                         // 000000333F3C: CC1A400B 1C2E1F34
	s_clause 0x3                                               // 000000333F44: BF850003
	global_load_b128 v[37:40], v[7:8], off                     // 000000333F48: DC5E0000 257C0007
	global_load_b128 v[41:44], v[7:8], off offset:16           // 000000333F50: DC5E0010 297C0007
	global_load_b128 v[45:48], v[7:8], off offset:32           // 000000333F58: DC5E0020 2D7C0007
	global_load_b128 v[49:52], v[7:8], off offset:48           // 000000333F60: DC5E0030 317C0007
	v_mov_b32_e32 v8, v4                                       // 000000333F68: 7E100304
	v_add_f32_e32 v22, v22, v11                                // 000000333F6C: 062C1716
	v_mov_b32_e32 v11, v30                                     // 000000333F70: 7E16031E
	s_waitcnt vmcnt(3)                                         // 000000333F74: BF890FF7
	v_dot2_f32_bf16 v7, v37, v31, 0                            // 000000333F78: CC1A4007 1A023F25
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000333F80: BF870091
	v_dot2_f32_bf16 v7, v38, v32, v7                           // 000000333F84: CC1A4007 1C1E4126
	v_dot2_f32_bf16 v7, v39, v33, v7                           // 000000333F8C: CC1A4007 1C1E4327
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000333F94: BF870131
	v_dot2_f32_bf16 v5, v40, v5, v7                            // 000000333F98: CC1A4005 1C1E0B28
	v_mov_b32_e32 v7, v3                                       // 000000333FA0: 7E0E0303
	s_waitcnt vmcnt(2)                                         // 000000333FA4: BF890BF7
	v_dot2_f32_bf16 v5, v41, v34, v5                           // 000000333FA8: CC1A4005 1C164529
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000333FB0: BF870091
	v_dot2_f32_bf16 v5, v42, v35, v5                           // 000000333FB4: CC1A4005 1C16472A
	v_dot2_f32_bf16 v5, v43, v36, v5                           // 000000333FBC: CC1A4005 1C16492B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000333FC4: BF870131
	v_dot2_f32_bf16 v5, v44, v6, v5                            // 000000333FC8: CC1A4005 1C160D2C
	v_mov_b32_e32 v6, v2                                       // 000000333FD0: 7E0C0302
	s_waitcnt vmcnt(1)                                         // 000000333FD4: BF8907F7
	v_dot2_f32_bf16 v5, v45, v14, v5                           // 000000333FD8: CC1A4005 1C161D2D
	v_mov_b32_e32 v14, v12                                     // 000000333FE0: 7E1C030C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000333FE4: BF870092
	v_dot2_f32_bf16 v5, v46, v53, v5                           // 000000333FE8: CC1A4005 1C166B2E
	v_dot2_f32_bf16 v5, v47, v54, v5                           // 000000333FF0: CC1A4005 1C166D2F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000333FF8: BF8700A1
	v_dot2_f32_bf16 v5, v48, v55, v5                           // 000000333FFC: CC1A4005 1C166F30
	s_waitcnt vmcnt(0)                                         // 000000334004: BF8903F7
	v_dot2_f32_bf16 v5, v49, v56, v5                           // 000000334008: CC1A4005 1C167131
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000334010: BF870091
	v_dot2_f32_bf16 v5, v50, v57, v5                           // 000000334014: CC1A4005 1C167332
	v_dot2_f32_bf16 v5, v51, v58, v5                           // 00000033401C: CC1A4005 1C167533
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000334024: BF870091
	v_dot2_f32_bf16 v5, v52, v15, v5                           // 000000334028: CC1A4005 1C161F34
	v_dual_mov_b32 v15, v13 :: v_dual_add_f32 v18, v18, v5     // 000000334030: CA08010D 0F120B12
	v_mov_b32_e32 v5, v1                                       // 000000334038: 7E0A0301
	s_and_not1_b32 exec_lo, exec_lo, s14                       // 00000033403C: 917E0E7E
	s_cbranch_execz 39                                         // 000000334040: BFA50027 <_ZN7halogen12_GLOBAL__N_16k_lq6wILi2ELi32ELi8EEEvPKhPKtPtll+0xde0>
	v_dual_mov_b32 v2, v6 :: v_dual_add_nc_u32 v19, 32, v19    // 000000334044: CA200106 021226A0
	s_delay_alu instid0(VALU_DEP_2)                            // 00000033404C: BF870002
	v_dual_mov_b32 v1, v5 :: v_dual_mov_b32 v4, v8             // 000000334050: CA100105 01040108
	v_dual_mov_b32 v3, v7 :: v_dual_mov_b32 v12, v14           // 000000334058: CA100107 030C010E
	v_mov_b32_e32 v13, v15                                     // 000000334060: 7E1A030F
	s_mov_b32 s10, exec_lo                                     // 000000334064: BE8A007E
	v_cmp_ge_i32_e32 vcc_lo, v19, v20                          // 000000334068: 7C8C2913
	.long 0xd4c1007e                                           // 00000033406C: D4C1007E
	v_cndmask_b32_e32 v1, v19, v20, vcc_lo                     // 000000334070: 02022913
	s_cbranch_execz 64816                                      // 000000334074: BFA5FD30 <_ZN7halogen12_GLOBAL__N_16k_lq6wILi2ELi32ELi8EEEvPKhPKtPtll+0x238>
	v_and_b32_e32 v3, -4, v29                                  // 000000334078: 36063AC4
	v_ashrrev_i32_e32 v2, 31, v27                              // 00000033407C: 3404369F
	v_ashrrev_i32_e32 v4, 31, v28                              // 000000334080: 3408389F
	.long 0xd7000001                                           // 000000334084: D7000001
	v_cndmask_b32_e32 v1, v9, v27, vcc_lo                      // 000000334088: 02023709
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000033408C: BF870214
	v_ashrrev_i32_e32 v31, 31, v3                              // 000000334090: 343E069F
	v_add_co_ci_u32_e64 v2, null, v21, v2, s0                  // 000000334094: D5207C02 00020515
	.long 0xd700000c                                           // 00000033409C: D700000C
	v_cndmask_b32_e32 v1, v23, v28, vcc_lo                     // 0000003340A0: 02023917
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003340A4: BF8700A1
	v_add_co_ci_u32_e64 v13, null, v24, v4, s0                 // 0000003340A8: D5207C0D 00020918
	.long 0xd700001e                                           // 0000003340B0: D700001E
	v_cndmask_b32_e32 v1, v25, v3, vcc_lo                      // 0000003340B4: 02020719
	v_add_co_ci_u32_e64 v31, null, v26, v31, s0                // 0000003340B8: D5207C1F 00023F1A
	s_clause 0x2                                               // 0000003340C0: BF850002
	global_load_b128 v[1:4], v[1:2], off                       // 0000003340C4: DC5E0000 017C0001
	global_load_b64 v[12:13], v[12:13], off                    // 0000003340CC: DC560000 0C7C000C
	global_load_b32 v30, v[30:31], off                         // 0000003340D4: DC520000 1E7C001E
	s_branch 64790                                             // 0000003340DC: BFA0FD16 <_ZN7halogen12_GLOBAL__N_16k_lq6wILi2ELi32ELi8EEEvPKhPKtPtll+0x238>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000003340E0: 8C7E0E7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000003340E4: BF8700B9
	s_or_b32 exec_lo, exec_lo, s1                              // 0000003340E8: 8C7E017E
	.long 0xd71f0001                                           // 0000003340EC: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000003340F0: 020100C1
	s_mov_b32 s0, exec_lo                                      // 0000003340F4: BE80007E
	v_xor_b32_e32 v2, 16, v1                                   // 0000003340F8: 3A040290
	v_xor_b32_e32 v4, 8, v1                                    // 0000003340FC: 3A080288
	s_waitcnt vmcnt(2)                                         // 000000334100: BF890BF7
	v_xor_b32_e32 v6, 4, v1                                    // 000000334104: 3A0C0284
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000334108: BF870133
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 00000033410C: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 000000334110: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v4                            // 000000334114: 7C9808A0
	v_lshlrev_b32_e32 v2, 2, v2                                // 000000334118: 30040482
	v_cndmask_b32_e32 v4, v1, v4, vcc_lo                       // 00000033411C: 02080901
	v_cmp_gt_u32_e32 vcc_lo, 32, v6                            // 000000334120: 7C980CA0
	ds_bpermute_b32 v3, v2, v22                                // 000000334124: DACC0000 03001602
	v_lshlrev_b32_e32 v4, 2, v4                                // 00000033412C: 30080882
	v_cndmask_b32_e32 v6, v1, v6, vcc_lo                       // 000000334130: 020C0D01
	s_waitcnt lgkmcnt(0)                                       // 000000334134: BF89FC07
	s_delay_alu instid0(VALU_DEP_1)                            // 000000334138: BF870001
	v_dual_add_f32 v3, v22, v3 :: v_dual_lshlrev_b32 v6, 2, v6 // 00000033413C: C9220716 03060C82
	ds_bpermute_b32 v5, v4, v3                                 // 000000334144: DACC0000 05000304
	s_waitcnt lgkmcnt(0)                                       // 00000033414C: BF89FC07
	v_add_f32_e32 v3, v3, v5                                   // 000000334150: 06060B03
	ds_bpermute_b32 v2, v2, v18                                // 000000334154: DACC0000 02001202
	s_waitcnt lgkmcnt(0)                                       // 00000033415C: BF89FC07
	v_add_f32_e32 v2, v18, v2                                  // 000000334160: 06040512
	ds_bpermute_b32 v4, v4, v2                                 // 000000334164: DACC0000 04000204
	s_waitcnt lgkmcnt(0)                                       // 00000033416C: BF89FC07
	v_add_f32_e32 v2, v2, v4                                   // 000000334170: 06040902
	ds_bpermute_b32 v4, v6, v3                                 // 000000334174: DACC0000 04000306
	ds_bpermute_b32 v5, v6, v2                                 // 00000033417C: DACC0000 05000206
	v_xor_b32_e32 v6, 2, v1                                    // 000000334184: 3A0C0282
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000334188: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v6                            // 00000033418C: 7C980CA0
	v_cndmask_b32_e32 v6, v1, v6, vcc_lo                       // 000000334190: 020C0D01
	s_waitcnt lgkmcnt(1)                                       // 000000334194: BF89FC17
	v_dual_add_f32 v3, v3, v4 :: v_dual_lshlrev_b32 v6, 2, v6  // 000000334198: C9220903 03060C82
	s_waitcnt lgkmcnt(0)                                       // 0000003341A0: BF89FC07
	v_add_f32_e32 v2, v2, v5                                   // 0000003341A4: 06040B02
	ds_bpermute_b32 v4, v6, v3                                 // 0000003341A8: DACC0000 04000306
	ds_bpermute_b32 v5, v6, v2                                 // 0000003341B0: DACC0000 05000206
	v_xor_b32_e32 v6, 1, v1                                    // 0000003341B8: 3A0C0281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000003341BC: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v6                            // 0000003341C0: 7C980CA0
	v_cndmask_b32_e32 v1, v1, v6, vcc_lo                       // 0000003341C4: 02020D01
	s_waitcnt lgkmcnt(1)                                       // 0000003341C8: BF89FC17
	v_dual_add_f32 v1, v3, v4 :: v_dual_lshlrev_b32 v6, 2, v1  // 0000003341CC: C9220903 01060282
	s_waitcnt lgkmcnt(0)                                       // 0000003341D4: BF89FC07
	v_add_f32_e32 v2, v2, v5                                   // 0000003341D8: 06040B02
	ds_bpermute_b32 v3, v6, v1                                 // 0000003341DC: DACC0000 03000106
	ds_bpermute_b32 v4, v6, v2                                 // 0000003341E4: DACC0000 04000206
	v_cmpx_eq_u32_e32 0, v17                                   // 0000003341EC: 7D942280
	s_cbranch_execz 6                                          // 0000003341F0: BFA50006 <_ZN7halogen12_GLOBAL__N_16k_lq6wILi2ELi32ELi8EEEvPKhPKtPtll+0xf0c>
	s_waitcnt lgkmcnt(0)                                       // 0000003341F4: BF89FC07
	v_dual_add_f32 v2, v2, v4 :: v_dual_add_f32 v1, v1, v3     // 0000003341F8: C9080902 02000701
	v_lshlrev_b32_e32 v3, 3, v16                               // 000000334200: 30062083
	ds_store_b64 v3, v[1:2]                                    // 000000334204: D9340000 00000103
	s_or_b32 exec_lo, exec_lo, s0                              // 00000033420C: 8C7E007E
	.long 0xd4510000                                           // 000000334210: D4510000
	v_cndmask_b32_e32 v0, s2, v12, vcc_lo                      // 000000334214: 02001802
	v_cmp_gt_u32_e32 vcc_lo, 2, v0                             // 000000334218: 7C980082
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000033421C: BF890007
	s_barrier                                                  // 000000334220: BFBD0000
	buffer_gl0_inv                                             // 000000334224: E0AC0000 00000000
	s_and_b32 s0, vcc_lo, s0                                   // 00000033422C: 8B00006A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000334230: BF870009
	s_and_saveexec_b32 s1, s0                                  // 000000334234: BE812000
	s_cbranch_execz 50                                         // 000000334238: BFA50032 <_ZN7halogen12_GLOBAL__N_16k_lq6wILi2ELi32ELi8EEEvPKhPKtPtll+0x1004>
	v_lshlrev_b32_e32 v7, 2, v0                                // 00000033423C: 300E0082
	s_lshl_b64 s[0:1], s[2:3], 1                               // 000000334240: 84808102
	ds_load_2addr_b32 v[1:2], v7 offset1:2                     // 000000334244: D8DC0200 01000007
	ds_load_2addr_b32 v[3:4], v7 offset0:4 offset1:6           // 00000033424C: D8DC0604 03000007
	ds_load_2addr_b32 v[5:6], v7 offset0:8 offset1:10          // 000000334254: D8DC0A08 05000007
	s_waitcnt lgkmcnt(2)                                       // 00000033425C: BF89FC27
	v_add_f32_e32 v1, 0, v1                                    // 000000334260: 06020280
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000334264: BF8700A1
	v_add_f32_e32 v1, v1, v2                                   // 000000334268: 06020501
	s_waitcnt lgkmcnt(1)                                       // 00000033426C: BF89FC17
	v_add_f32_e32 v1, v1, v3                                   // 000000334270: 06020701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000334274: BF870131
	v_add_f32_e32 v3, v1, v4                                   // 000000334278: 06060901
	v_mad_u64_u32 v[1:2], null, s12, v0, 0                     // 00000033427C: D6FE7C01 0202000C
	s_waitcnt lgkmcnt(0)                                       // 000000334284: BF89FC07
	v_add_f32_e32 v3, v3, v5                                   // 000000334288: 06060B03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000033428C: BF8700D1
	v_add_f32_e32 v4, v3, v6                                   // 000000334290: 06080D03
	ds_load_2addr_b32 v[7:8], v7 offset0:12 offset1:14         // 000000334294: D8DC0E0C 07000007
	v_mad_u64_u32 v[2:3], null, s13, v0, v[2:3]                // 00000033429C: D6FE7C02 040A000D
	s_waitcnt lgkmcnt(0)                                       // 0000003342A4: BF89FC07
	v_add_f32_e32 v0, v4, v7                                   // 0000003342A8: 06000F04
	v_add_f32_e32 v3, v0, v8                                   // 0000003342AC: 06061100
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003342B0: BF870113
	.long 0xd73c0000                                           // 0000003342B4: D73C0000
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 0000003342B8: 02020281
	v_bfe_u32 v2, v3, 16, 1                                    // 0000003342BC: D6100002 02052103
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003342C4: BF870092
	.long 0xd7006a00                                           // 0000003342C8: D7006A00
	v_cndmask_b32_e32 v1, s8, v0, vcc_lo                       // 0000003342CC: 02020008
	v_add_co_ci_u32_e64 v1, null, s9, v1, vcc_lo               // 0000003342D0: D5207C01 01AA0209
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003342D8: BF870193
	v_add3_u32 v2, v3, v2, 0x7fff                              // 0000003342DC: D6550002 03FE0503 00007FFF
	.long 0xd7006a00                                           // 0000003342E8: D7006A00
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 0000003342EC: 02000100
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003342F0: BF870001
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 0000003342F4: D5207C01 01AA0201
	global_store_d16_hi_b16 v[0:1], v2, off                    // 0000003342FC: DC960000 007C0200
	s_endpgm                                                   // 000000334304: BFB00000
		...

