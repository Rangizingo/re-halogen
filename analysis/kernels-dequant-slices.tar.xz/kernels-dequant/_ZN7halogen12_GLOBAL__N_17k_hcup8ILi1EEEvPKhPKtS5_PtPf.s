00000000003cca00 <_ZN7halogen12_GLOBAL__N_17k_hcup8ILi1EEEvPKhPKtS5_PtPf>:
; _ZN7halogen12_GLOBAL__N_17k_hcup8ILi1EEEvPKhPKtS5_PtPf():
	s_load_b256 s[4:11], s[0:1], null                          // 0000003CCA00: F40C0100 F8000000
	v_lshrrev_b32_e32 v1, 4, v0                                // 0000003CCA08: 32020084
	v_bfe_u32 v2, v0, 4, 1                                     // 0000003CCA0C: D6100002 02050900
	s_lshl_b32 s2, s2, 4                                       // 0000003CCA14: 84028402
	v_and_b32_e32 v37, 15, v0                                  // 0000003CCA18: 364A008F
	v_and_b32_e32 v0, 12, v0                                   // 0000003CCA1C: 3600008C
	v_and_b32_e32 v1, 14, v1                                   // 0000003CCA20: 3602028E
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000003CCA24: BF8701A3
	v_lshlrev_b32_e32 v38, 4, v37                              // 0000003CCA28: 304C4A84
	v_or_b32_e32 v43, 16, v37                                  // 0000003CCA2C: 38564A90
	v_or3_b32 v36, v1, s2, v2                                  // 0000003CCA30: D6580024 04080501
	s_waitcnt lgkmcnt(0)                                       // 0000003CCA38: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000003CCA3C: BF8700C1
	v_mad_i64_i32 v[1:2], null, 0x154, v36, s[4:5]             // 0000003CCA40: D6FF7C01 001248FF 00000154
	s_load_b64 s[4:5], s[0:1], 0x20                            // 0000003CCA4C: F4040100 F8000020
	s_mov_b32 s0, exec_lo                                      // 0000003CCA54: BE80007E
	.long 0xd7006a08                                           // 0000003CCA58: D7006A08
	v_cndmask_b32_e32 v1, v1, v38, vcc_lo                      // 0000003CCA5C: 02024D01
	v_add_co_ci_u32_e64 v9, null, 0, v2, vcc_lo                // 0000003CCA60: D5207C09 01AA0480
	.long 0xd7006a06                                           // 0000003CCA68: D7006A06
	v_cndmask_b32_e32 v1, v1, v0, vcc_lo                       // 0000003CCA6C: 02020101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003CCA70: BF870211
	v_add_co_ci_u32_e64 v7, null, 0, v2, vcc_lo                // 0000003CCA74: D5207C07 01AA0480
	.long 0xd7006a04                                           // 0000003CCA7C: D7006A04
	v_cndmask_b32_e32 v1, 0xd4000, v8, vcc_lo                  // 0000003CCA80: 020210FF 000D4000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003CCA88: BF870211
	v_add_co_ci_u32_e64 v5, null, 0, v9, vcc_lo                // 0000003CCA8C: D5207C05 01AA1280
	.long 0xd7006a0a                                           // 0000003CCA94: D7006A0A
	v_cndmask_b32_e32 v1, 0xd4000, v6, vcc_lo                  // 0000003CCA98: 02020CFF 000D4000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003CCAA0: BF8700A1
	v_add_co_ci_u32_e64 v11, null, 0, v7, vcc_lo               // 0000003CCAA4: D5207C0B 01AA0E80
	.long 0xd7006a10                                           // 0000003CCAAC: D7006A10
	v_cndmask_b32_e32 v1, 0x1a9000, v8, vcc_lo                 // 0000003CCAB0: 020210FF 001A9000
	v_add_co_ci_u32_e64 v17, null, 0, v9, vcc_lo               // 0000003CCAB8: D5207C11 01AA1280
	.long 0xd7006a0c                                           // 0000003CCAC0: D7006A0C
	v_cndmask_b32_e32 v1, 0x1a9000, v6, vcc_lo                 // 0000003CCAC4: 02020CFF 001A9000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003CCACC: BF8700A1
	v_add_co_ci_u32_e64 v13, null, 0, v7, vcc_lo               // 0000003CCAD0: D5207C0D 01AA0E80
	.long 0xd7006a12                                           // 0000003CCAD8: D7006A12
	v_cndmask_b32_e32 v1, 0x27d000, v8, vcc_lo                 // 0000003CCADC: 020210FF 0027D000
	v_add_co_ci_u32_e64 v19, null, 0, v9, vcc_lo               // 0000003CCAE4: D5207C13 01AA1280
	.long 0xd7006a0e                                           // 0000003CCAEC: D7006A0E
	v_cndmask_b32_e32 v1, 0x27d000, v6, vcc_lo                 // 0000003CCAF0: 02020CFF 0027D000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003CCAF8: BF870001
	v_add_co_ci_u32_e64 v15, null, 0, v7, vcc_lo               // 0000003CCAFC: D5207C0F 01AA0E80
	s_clause 0x7                                               // 0000003CCB04: BF850007
	global_load_b32 v48, v[6:7], off offset:320                // 0000003CCB08: DC520140 307C0006
	global_load_b128 v[32:35], v[4:5], off offset:2048         // 0000003CCB10: DC5E0800 207C0004
	global_load_b32 v47, v[10:11], off offset:2368             // 0000003CCB18: DC520940 2F7C000A
	global_load_b128 v[28:31], v[16:17], off                   // 0000003CCB20: DC5E0000 1C7C0010
	global_load_b32 v46, v[12:13], off offset:320              // 0000003CCB28: DC520140 2E7C000C
	global_load_b128 v[24:27], v[18:19], off offset:2048       // 0000003CCB30: DC5E0800 187C0012
	global_load_b32 v45, v[14:15], off offset:2368             // 0000003CCB38: DC520940 2D7C000E
	global_load_b128 v[20:23], v[8:9], off                     // 0000003CCB40: DC5E0000 147C0008
	v_cmpx_gt_u32_e32 20, v43                                  // 0000003CCB48: 7D985694
	s_cbranch_execz 34                                         // 0000003CCB4C: BFA50022 <_ZN7halogen12_GLOBAL__N_17k_hcup8ILi1EEEvPKhPKtS5_PtPf+0x1d8>
	.long 0xd7006a27                                           // 0000003CCB50: D7006A27
	v_cndmask_b32_e32 v1, 0xd4000, v1, vcc_lo                  // 0000003CCB54: 020202FF 000D4000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003CCB5C: BF8700A1
	v_add_co_ci_u32_e64 v40, null, 0, v2, vcc_lo               // 0000003CCB60: D5207C28 01AA0480
	.long 0xd7006a31                                           // 0000003CCB68: D7006A31
	v_cndmask_b32_e32 v1, 0x1a9000, v1, vcc_lo                 // 0000003CCB6C: 020202FF 001A9000
	v_add_co_ci_u32_e64 v50, null, 0, v2, vcc_lo               // 0000003CCB74: D5207C32 01AA0480
	.long 0xd7006a00                                           // 0000003CCB7C: D7006A00
	v_cndmask_b32_e32 v1, 0x27d000, v1, vcc_lo                 // 0000003CCB80: 020202FF 0027D000
	s_clause 0x1                                               // 0000003CCB88: BF850001
	global_load_b128 v[12:15], v[8:9], off offset:256          // 0000003CCB8C: DC5E0100 0C7C0008
	global_load_b32 v41, v[1:2], off offset:336                // 0000003CCB94: DC520150 297C0001
	v_add_co_ci_u32_e64 v1, null, 0, v2, vcc_lo                // 0000003CCB9C: D5207C01 01AA0480
	s_clause 0x5                                               // 0000003CCBA4: BF850005
	global_load_b128 v[8:11], v[4:5], off offset:2304          // 0000003CCBA8: DC5E0900 087C0004
	global_load_b128 v[4:7], v[16:17], off offset:256          // 0000003CCBB0: DC5E0100 047C0010
	global_load_b32 v42, v[39:40], off offset:2384             // 0000003CCBB8: DC520950 2A7C0027
	global_load_b32 v40, v[49:50], off offset:336              // 0000003CCBC0: DC520150 287C0031
	global_load_b32 v39, v[0:1], off offset:2384               // 0000003CCBC8: DC520950 277C0000
	global_load_b128 v[0:3], v[18:19], off offset:2304         // 0000003CCBD0: DC5E0900 007C0012
	s_or_b32 exec_lo, exec_lo, s0                              // 0000003CCBD8: 8C7E007E
	v_lshlrev_b32_e32 v44, 1, v38                              // 0000003CCBDC: 30584C81
	s_waitcnt vmcnt(0)                                         // 0000003CCBE0: BF8903F7
	v_cvt_f32_ubyte0_e32 v49, v20                              // 0000003CCBE4: 7E622314
	v_cvt_f32_ubyte1_e32 v50, v20                              // 0000003CCBE8: 7E642514
	v_cvt_f32_ubyte2_e32 v51, v20                              // 0000003CCBEC: 7E662714
	v_cvt_f32_ubyte3_e32 v52, v20                              // 0000003CCBF0: 7E682914
	global_load_b128 v[16:19], v44, s[6:7]                     // 0000003CCBF4: DC5E0000 1006002C
	v_cvt_f32_ubyte0_e32 v53, v21                              // 0000003CCBFC: 7E6A2315
	v_cvt_f32_ubyte1_e32 v54, v21                              // 0000003CCC00: 7E6C2515
	v_cvt_f32_ubyte2_e32 v55, v21                              // 0000003CCC04: 7E6E2715
	v_cvt_f32_ubyte3_e32 v56, v21                              // 0000003CCC08: 7E702915
	v_cvt_f32_ubyte0_e32 v57, v22                              // 0000003CCC0C: 7E722316
	v_cvt_f32_ubyte1_e32 v58, v22                              // 0000003CCC10: 7E742516
	v_cvt_f32_ubyte2_e32 v59, v22                              // 0000003CCC14: 7E762716
	v_cvt_f32_ubyte3_e32 v60, v22                              // 0000003CCC18: 7E782916
	v_cvt_f32_ubyte0_e32 v61, v23                              // 0000003CCC1C: 7E7A2317
	v_cvt_f32_ubyte1_e32 v62, v23                              // 0000003CCC20: 7E7C2517
	v_cvt_f32_ubyte2_e32 v63, v23                              // 0000003CCC24: 7E7E2717
	v_cvt_f32_ubyte3_e32 v64, v23                              // 0000003CCC28: 7E802917
	global_load_b128 v[20:23], v44, s[6:7] offset:16           // 0000003CCC2C: DC5E0010 1406002C
	v_fma_mix_f32 v49, v49, v48, v48 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CCC34: CC206031 14C26131
	v_fma_mix_f32 v50, v50, v48, v48 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CCC3C: CC206032 14C26132
	v_fma_mix_f32 v53, v53, v48, v48 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CCC44: CC206035 14C26135
	v_fma_mix_f32 v54, v54, v48, v48 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CCC4C: CC206036 14C26136
	v_fma_mix_f32 v57, v57, v48, v48 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CCC54: CC206039 14C26139
	v_bfe_u32 v112, v49, 16, 1                                 // 0000003CCC5C: D6100070 02052131
	v_bfe_u32 v113, v50, 16, 1                                 // 0000003CCC64: D6100071 02052132
	v_bfe_u32 v116, v53, 16, 1                                 // 0000003CCC6C: D6100074 02052135
	.long 0x7f4c3880                                           // 0000003CCC74: 7F4C3880
	v_cvt_f32_ubyte0_e32 v65, v32                              // 0000003CCC78: 7E822320
	v_add3_u32 v49, v49, v112, 0x7fff                          // 0000003CCC7C: D6550031 03FEE131 00007FFF
	v_fma_mix_f32 v58, v58, v48, v48 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CCC88: CC20603A 14C2613A
	v_fma_mix_f32 v61, v61, v48, v48 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CCC90: CC20603D 14C2613D
	v_bfe_u32 v117, v54, 16, 1                                 // 0000003CCC98: D6100075 02052136
	v_bfe_u32 v120, v57, 16, 1                                 // 0000003CCCA0: D6100078 02052139
	v_add3_u32 v50, v50, v113, 0x7fff                          // 0000003CCCA8: D6550032 03FEE332 00007FFF
	v_add3_u32 v53, v53, v116, 0x7fff                          // 0000003CCCB4: D6550035 03FEE935 00007FFF
	.long 0x7e4c39b1                                           // 0000003CCCC0: 7E4C39B1
	v_cvt_f32_ubyte1_e32 v66, v32                              // 0000003CCCC4: 7E842520
	v_cvt_f32_ubyte0_e32 v68, v33                              // 0000003CCCC8: 7E882321
	v_fma_mix_f32 v51, v51, v48, v48 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CCCCC: CC206033 14C26133
	v_fma_mix_f32 v52, v52, v48, v48 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CCCD4: CC206034 14C26134
	v_fma_mix_f32 v55, v55, v48, v48 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CCCDC: CC206037 14C26137
	v_fma_mix_f32 v56, v56, v48, v48 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CCCE4: CC206038 14C26138
	v_fma_mix_f32 v59, v59, v48, v48 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CCCEC: CC20603B 14C2613B
	v_fma_mix_f32 v60, v60, v48, v48 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CCCF4: CC20603C 14C2613C
	v_fma_mix_f32 v62, v62, v48, v48 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CCCFC: CC20603E 14C2613E
	v_fma_mix_f32 v63, v63, v48, v48 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CCD04: CC20603F 14C2613F
	v_fma_mix_f32 v48, v64, v48, v48 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CCD0C: CC206030 14C26140
	v_fma_mix_f32 v64, v65, v47, v47 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CCD14: CC206040 14BE5F41
	v_bfe_u32 v121, v58, 16, 1                                 // 0000003CCD1C: D6100079 0205213A
	v_bfe_u32 v124, v61, 16, 1                                 // 0000003CCD24: D610007C 0205213D
	v_add3_u32 v54, v54, v117, 0x7fff                          // 0000003CCD2C: D6550036 03FEEB36 00007FFF
	v_add3_u32 v57, v57, v120, 0x7fff                          // 0000003CCD38: D6550039 03FEF139 00007FFF
	v_and_or_b32 v50, 0xffff0000, v50, v38                     // 0000003CCD44: D6570032 049A64FF FFFF0000
	.long 0x7e4c39b5                                           // 0000003CCD50: 7E4C39B5
	v_cvt_f32_ubyte1_e32 v69, v33                              // 0000003CCD54: 7E8A2521
	v_cvt_f32_ubyte0_e32 v71, v34                              // 0000003CCD58: 7E8E2322
	v_fma_mix_f32 v65, v66, v47, v47 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CCD5C: CC206041 14BE5F42
	v_fma_mix_f32 v68, v68, v47, v47 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CCD64: CC206044 14BE5F44
	v_bfe_u32 v125, v62, 16, 1                                 // 0000003CCD6C: D610007D 0205213E
	v_bfe_u32 v128, v64, 16, 1                                 // 0000003CCD74: D6100080 02052140
	v_add3_u32 v58, v58, v121, 0x7fff                          // 0000003CCD7C: D655003A 03FEF33A 00007FFF
	v_add3_u32 v61, v61, v124, 0x7fff                          // 0000003CCD88: D655003D 03FEF93D 00007FFF
	v_and_or_b32 v54, 0xffff0000, v54, v38                     // 0000003CCD94: D6570036 049A6CFF FFFF0000
	.long 0x7e4c39b9                                           // 0000003CCDA0: 7E4C39B9
	v_cvt_f32_ubyte1_e32 v72, v34                              // 0000003CCDA4: 7E902522
	v_cvt_f32_ubyte0_e32 v74, v35                              // 0000003CCDA8: 7E942323
	v_fma_mix_f32 v69, v69, v47, v47 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CCDAC: CC206045 14BE5F45
	v_fma_mix_f32 v71, v71, v47, v47 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CCDB4: CC206047 14BE5F47
	v_bfe_u32 v129, v65, 16, 1                                 // 0000003CCDBC: D6100081 02052141
	v_bfe_u32 v132, v68, 16, 1                                 // 0000003CCDC4: D6100084 02052144
	v_add3_u32 v62, v62, v125, 0x7fff                          // 0000003CCDCC: D655003E 03FEFB3E 00007FFF
	v_add3_u32 v64, v64, v128, 0x7fff                          // 0000003CCDD8: D6550040 03FF0140 00007FFF
	v_and_or_b32 v58, 0xffff0000, v58, v38                     // 0000003CCDE4: D657003A 049A74FF FFFF0000
	.long 0x7e4c39bd                                           // 0000003CCDF0: 7E4C39BD
	v_cvt_f32_ubyte2_e32 v67, v32                              // 0000003CCDF4: 7E862720
	v_cvt_f32_ubyte3_e32 v32, v32                              // 0000003CCDF8: 7E402920
	v_cvt_f32_ubyte2_e32 v70, v33                              // 0000003CCDFC: 7E8C2721
	v_cvt_f32_ubyte3_e32 v33, v33                              // 0000003CCE00: 7E422921
	v_cvt_f32_ubyte2_e32 v73, v34                              // 0000003CCE04: 7E922722
	v_cvt_f32_ubyte3_e32 v34, v34                              // 0000003CCE08: 7E442922
	v_cvt_f32_ubyte1_e32 v75, v35                              // 0000003CCE0C: 7E962523
	v_cvt_f32_ubyte2_e32 v76, v35                              // 0000003CCE10: 7E982723
	v_cvt_f32_ubyte3_e32 v35, v35                              // 0000003CCE14: 7E462923
	v_cvt_f32_ubyte0_e32 v77, v28                              // 0000003CCE18: 7E9A231C
	v_fma_mix_f32 v72, v72, v47, v47 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CCE1C: CC206048 14BE5F48
	v_fma_mix_f32 v74, v74, v47, v47 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CCE24: CC20604A 14BE5F4A
	v_bfe_u32 v114, v51, 16, 1                                 // 0000003CCE2C: D6100072 02052133
	v_bfe_u32 v133, v69, 16, 1                                 // 0000003CCE34: D6100085 02052145
	v_bfe_u32 v136, v71, 16, 1                                 // 0000003CCE3C: D6100088 02052147
	v_add3_u32 v65, v65, v129, 0x7fff                          // 0000003CCE44: D6550041 03FF0341 00007FFF
	v_add3_u32 v68, v68, v132, 0x7fff                          // 0000003CCE50: D6550044 03FF0944 00007FFF
	v_and_or_b32 v62, 0xffff0000, v62, v38                     // 0000003CCE5C: D657003E 049A7CFF FFFF0000
	.long 0x7e4c39c0                                           // 0000003CCE68: 7E4C39C0
	v_cvt_f32_ubyte1_e32 v78, v28                              // 0000003CCE6C: 7E9C251C
	v_cvt_f32_ubyte2_e32 v79, v28                              // 0000003CCE70: 7E9E271C
	v_cvt_f32_ubyte0_e32 v80, v29                              // 0000003CCE74: 7EA0231D
	v_fma_mix_f32 v66, v67, v47, v47 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CCE78: CC206042 14BE5F43
	v_fma_mix_f32 v32, v32, v47, v47 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CCE80: CC206020 14BE5F20
	v_fma_mix_f32 v70, v70, v47, v47 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CCE88: CC206046 14BE5F46
	v_fma_mix_f32 v33, v33, v47, v47 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CCE90: CC206021 14BE5F21
	v_fma_mix_f32 v73, v73, v47, v47 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CCE98: CC206049 14BE5F49
	v_fma_mix_f32 v34, v34, v47, v47 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CCEA0: CC206022 14BE5F22
	v_fma_mix_f32 v75, v75, v47, v47 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CCEA8: CC20604B 14BE5F4B
	v_fma_mix_f32 v76, v76, v47, v47 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CCEB0: CC20604C 14BE5F4C
	v_fma_mix_f32 v35, v35, v47, v47 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CCEB8: CC206023 14BE5F23
	v_fma_mix_f32 v47, v77, v46, v46 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CCEC0: CC20602F 14BA5D4D
	v_bfe_u32 v115, v52, 16, 1                                 // 0000003CCEC8: D6100073 02052134
	v_bfe_u32 v118, v55, 16, 1                                 // 0000003CCED0: D6100076 02052137
	v_bfe_u32 v137, v72, 16, 1                                 // 0000003CCED8: D6100089 02052148
	v_add3_u32 v51, v51, v114, 0x7fff                          // 0000003CCEE0: D6550033 03FEE533 00007FFF
	v_bfe_u32 v114, v74, 16, 1                                 // 0000003CCEEC: D6100072 0205214A
	v_add3_u32 v69, v69, v133, 0x7fff                          // 0000003CCEF4: D6550045 03FF0B45 00007FFF
	v_add3_u32 v71, v71, v136, 0x7fff                          // 0000003CCF00: D6550047 03FF1147 00007FFF
	v_and_or_b32 v65, 0xffff0000, v65, v38                     // 0000003CCF0C: D6570041 049A82FF FFFF0000
	.long 0x7e4c39c4                                           // 0000003CCF18: 7E4C39C4
	v_cvt_f32_ubyte1_e32 v81, v29                              // 0000003CCF1C: 7EA2251D
	v_cvt_f32_ubyte2_e32 v82, v29                              // 0000003CCF20: 7EA4271D
	v_cvt_f32_ubyte0_e32 v83, v30                              // 0000003CCF24: 7EA6231E
	v_fma_mix_f32 v77, v78, v46, v46 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CCF28: CC20604D 14BA5D4E
	v_fma_mix_f32 v78, v79, v46, v46 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CCF30: CC20604E 14BA5D4F
	v_fma_mix_f32 v79, v80, v46, v46 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CCF38: CC20604F 14BA5D50
	v_bfe_u32 v119, v56, 16, 1                                 // 0000003CCF40: D6100077 02052138
	v_bfe_u32 v122, v59, 16, 1                                 // 0000003CCF48: D610007A 0205213B
	v_add3_u32 v52, v52, v115, 0x7fff                          // 0000003CCF50: D6550034 03FEE734 00007FFF
	v_bfe_u32 v115, v75, 16, 1                                 // 0000003CCF5C: D6100073 0205214B
	v_add3_u32 v55, v55, v118, 0x7fff                          // 0000003CCF64: D6550037 03FEED37 00007FFF
	v_bfe_u32 v118, v47, 16, 1                                 // 0000003CCF70: D6100076 0205212F
	v_add3_u32 v72, v72, v137, 0x7fff                          // 0000003CCF78: D6550048 03FF1348 00007FFF
	v_add3_u32 v74, v74, v114, 0x7fff                          // 0000003CCF84: D655004A 03FEE54A 00007FFF
	.long 0x7eca39b3                                           // 0000003CCF90: 7ECA39B3
	v_and_or_b32 v51, 0xffff0000, v69, v38                     // 0000003CCF94: D6570033 049A8AFF FFFF0000
	.long 0x7e4c39c7                                           // 0000003CCFA0: 7E4C39C7
	v_cvt_f32_ubyte1_e32 v84, v30                              // 0000003CCFA4: 7EA8251E
	v_cvt_f32_ubyte2_e32 v85, v30                              // 0000003CCFA8: 7EAA271E
	v_cvt_f32_ubyte0_e32 v86, v31                              // 0000003CCFAC: 7EAC231F
	v_fma_mix_f32 v80, v81, v46, v46 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CCFB0: CC206050 14BA5D51
	v_fma_mix_f32 v81, v82, v46, v46 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CCFB8: CC206051 14BA5D52
	v_fma_mix_f32 v82, v83, v46, v46 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CCFC0: CC206052 14BA5D53
	v_bfe_u32 v123, v60, 16, 1                                 // 0000003CCFC8: D610007B 0205213C
	v_bfe_u32 v126, v63, 16, 1                                 // 0000003CCFD0: D610007E 0205213F
	v_add3_u32 v56, v56, v119, 0x7fff                          // 0000003CCFD8: D6550038 03FEEF38 00007FFF
	v_bfe_u32 v119, v77, 16, 1                                 // 0000003CCFE4: D6100077 0205214D
	v_add3_u32 v59, v59, v122, 0x7fff                          // 0000003CCFEC: D655003B 03FEF53B 00007FFF
	v_bfe_u32 v122, v79, 16, 1                                 // 0000003CCFF8: D610007A 0205214F
	v_add3_u32 v75, v75, v115, 0x7fff                          // 0000003CD000: D655004B 03FEE74B 00007FFF
	v_add3_u32 v47, v47, v118, 0x7fff                          // 0000003CD00C: D655002F 03FEED2F 00007FFF
	.long 0x7ecc39b7                                           // 0000003CD018: 7ECC39B7
	v_and_or_b32 v55, 0xffff0000, v72, v38                     // 0000003CD01C: D6570037 049A90FF FFFF0000
	.long 0x7e4c39ca                                           // 0000003CD028: 7E4C39CA
	v_cvt_f32_ubyte3_e32 v28, v28                              // 0000003CD02C: 7E38291C
	v_cvt_f32_ubyte3_e32 v29, v29                              // 0000003CD030: 7E3A291D
	v_cvt_f32_ubyte3_e32 v30, v30                              // 0000003CD034: 7E3C291E
	v_cvt_f32_ubyte1_e32 v87, v31                              // 0000003CD038: 7EAE251F
	v_cvt_f32_ubyte2_e32 v88, v31                              // 0000003CD03C: 7EB0271F
	v_cvt_f32_ubyte3_e32 v31, v31                              // 0000003CD040: 7E3E291F
	v_cvt_f32_ubyte0_e32 v89, v24                              // 0000003CD044: 7EB22318
	v_fma_mix_f32 v83, v84, v46, v46 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CD048: CC206053 14BA5D54
	v_fma_mix_f32 v84, v85, v46, v46 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CD050: CC206054 14BA5D55
	v_fma_mix_f32 v85, v86, v46, v46 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CD058: CC206055 14BA5D56
	v_bfe_u32 v127, v48, 16, 1                                 // 0000003CD060: D610007F 02052130
	v_bfe_u32 v130, v66, 16, 1                                 // 0000003CD068: D6100082 02052142
	v_add3_u32 v60, v60, v123, 0x7fff                          // 0000003CD070: D655003C 03FEF73C 00007FFF
	v_bfe_u32 v123, v80, 16, 1                                 // 0000003CD07C: D610007B 02052150
	v_add3_u32 v63, v63, v126, 0x7fff                          // 0000003CD084: D655003F 03FEFD3F 00007FFF
	v_bfe_u32 v126, v82, 16, 1                                 // 0000003CD090: D610007E 02052152
	v_add3_u32 v77, v77, v119, 0x7fff                          // 0000003CD098: D655004D 03FEEF4D 00007FFF
	v_add3_u32 v79, v79, v122, 0x7fff                          // 0000003CD0A4: D655004F 03FEF54F 00007FFF
	.long 0x7ece39bb                                           // 0000003CD0B0: 7ECE39BB
	v_and_or_b32 v59, 0xffff0000, v75, v38                     // 0000003CD0B4: D657003B 049A96FF FFFF0000
	.long 0x7e4c39af                                           // 0000003CD0C0: 7E4C39AF
	v_cvt_f32_ubyte1_e32 v90, v24                              // 0000003CD0C4: 7EB42518
	v_cvt_f32_ubyte2_e32 v91, v24                              // 0000003CD0C8: 7EB62718
	v_fma_mix_f32 v28, v28, v46, v46 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CD0CC: CC20601C 14BA5D1C
	v_fma_mix_f32 v29, v29, v46, v46 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CD0D4: CC20601D 14BA5D1D
	v_fma_mix_f32 v30, v30, v46, v46 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CD0DC: CC20601E 14BA5D1E
	v_fma_mix_f32 v86, v87, v46, v46 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CD0E4: CC206056 14BA5D57
	v_fma_mix_f32 v87, v88, v46, v46 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CD0EC: CC206057 14BA5D58
	v_fma_mix_f32 v31, v31, v46, v46 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CD0F4: CC20601F 14BA5D1F
	v_fma_mix_f32 v46, v89, v45, v45 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CD0FC: CC20602E 14B65B59
	v_bfe_u32 v131, v32, 16, 1                                 // 0000003CD104: D6100083 02052120
	v_bfe_u32 v134, v70, 16, 1                                 // 0000003CD10C: D6100086 02052146
	v_bfe_u32 v116, v76, 16, 1                                 // 0000003CD114: D6100074 0205214C
	v_add3_u32 v48, v48, v127, 0x7fff                          // 0000003CD11C: D6550030 03FEFF30 00007FFF
	v_bfe_u32 v127, v83, 16, 1                                 // 0000003CD128: D610007F 02052153
	v_add3_u32 v66, v66, v130, 0x7fff                          // 0000003CD130: D6550042 03FF0542 00007FFF
	v_bfe_u32 v130, v85, 16, 1                                 // 0000003CD13C: D6100082 02052155
	v_add3_u32 v80, v80, v123, 0x7fff                          // 0000003CD144: D6550050 03FEF750 00007FFF
	v_add3_u32 v49, v82, v126, 0x7fff                          // 0000003CD150: D6550031 03FEFD52 00007FFF
	v_and_or_b32 v47, 0xffff0000, v77, v38                     // 0000003CD15C: D657002F 049A9AFF FFFF0000
	.long 0x7e4c39cf                                           // 0000003CD168: 7E4C39CF
	v_cvt_f32_ubyte3_e32 v24, v24                              // 0000003CD16C: 7E302918
	v_cvt_f32_ubyte0_e32 v92, v25                              // 0000003CD170: 7EB82319
	v_cvt_f32_ubyte1_e32 v93, v25                              // 0000003CD174: 7EBA2519
	v_cvt_f32_ubyte2_e32 v94, v25                              // 0000003CD178: 7EBC2719
	v_cvt_f32_ubyte3_e32 v25, v25                              // 0000003CD17C: 7E322919
	v_cvt_f32_ubyte0_e32 v95, v26                              // 0000003CD180: 7EBE231A
	v_cvt_f32_ubyte1_e32 v96, v26                              // 0000003CD184: 7EC0251A
	v_cvt_f32_ubyte2_e32 v97, v26                              // 0000003CD188: 7EC2271A
	v_cvt_f32_ubyte3_e32 v26, v26                              // 0000003CD18C: 7E34291A
	v_cvt_f32_ubyte0_e32 v98, v27                              // 0000003CD190: 7EC4231B
	v_cvt_f32_ubyte1_e32 v99, v27                              // 0000003CD194: 7EC6251B
	v_cvt_f32_ubyte2_e32 v100, v27                             // 0000003CD198: 7EC8271B
	v_cvt_f32_ubyte3_e32 v27, v27                              // 0000003CD19C: 7E36291B
	.long 0x7fce39a6                                           // 0000003CD1A0: 7FCE39A6
	v_fma_mix_f32 v88, v90, v45, v45 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CD1A4: CC206058 14B65B5A
	v_fma_mix_f32 v89, v91, v45, v45 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CD1AC: CC206059 14B65B5B
	v_bfe_u32 v135, v33, 16, 1                                 // 0000003CD1B4: D6100087 02052121
	v_bfe_u32 v117, v35, 16, 1                                 // 0000003CD1BC: D6100075 02052123
	v_bfe_u32 v120, v78, 16, 1                                 // 0000003CD1C4: D6100078 0205214E
	v_bfe_u32 v128, v84, 16, 1                                 // 0000003CD1CC: D6100080 02052154
	v_add3_u32 v32, v32, v131, 0x7fff                          // 0000003CD1D4: D6550020 03FF0720 00007FFF
	v_bfe_u32 v131, v86, 16, 1                                 // 0000003CD1E0: D6100083 02052156
	v_add3_u32 v70, v70, v134, 0x7fff                          // 0000003CD1E8: D6550046 03FF0D46 00007FFF
	v_bfe_u32 v134, v46, 16, 1                                 // 0000003CD1F4: D6100086 0205212E
	v_add3_u32 v76, v76, v116, 0x7fff                          // 0000003CD1FC: D655004C 03FEE94C 00007FFF
	v_add3_u32 v82, v83, v127, 0x7fff                          // 0000003CD208: D6550052 03FEFF53 00007FFF
	v_add3_u32 v53, v85, v130, 0x7fff                          // 0000003CD214: D6550035 03FF0555 00007FFF
	.long 0x7ed039bf                                           // 0000003CD220: 7ED039BF
	v_and_or_b32 v63, 0xffff0000, v80, v38                     // 0000003CD224: D657003F 049AA0FF FFFF0000
	.long 0x7e4c39b1                                           // 0000003CD230: 7E4C39B1
	.long 0x7fca39a6                                           // 0000003CD234: 7FCA39A6
	v_fma_mix_f32 v24, v24, v45, v45 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CD238: CC206018 14B65B18
	v_fma_mix_f32 v90, v92, v45, v45 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CD240: CC20605A 14B65B5C
	v_fma_mix_f32 v91, v93, v45, v45 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CD248: CC20605B 14B65B5D
	v_fma_mix_f32 v92, v94, v45, v45 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CD250: CC20605C 14B65B5E
	v_fma_mix_f32 v25, v25, v45, v45 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CD258: CC206019 14B65B19
	v_fma_mix_f32 v93, v95, v45, v45 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CD260: CC20605D 14B65B5F
	v_fma_mix_f32 v94, v96, v45, v45 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CD268: CC20605E 14B65B60
	v_fma_mix_f32 v95, v97, v45, v45 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CD270: CC20605F 14B65B61
	v_fma_mix_f32 v26, v26, v45, v45 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CD278: CC20601A 14B65B1A
	v_fma_mix_f32 v96, v98, v45, v45 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CD280: CC206060 14B65B62
	v_fma_mix_f32 v97, v99, v45, v45 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CD288: CC206061 14B65B63
	v_fma_mix_f32 v98, v100, v45, v45 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CD290: CC206062 14B65B64
	v_fma_mix_f32 v27, v27, v45, v45 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CD298: CC20601B 14B65B1B
	.long 0x7f5a39a6                                           // 0000003CD2A0: 7F5A39A6
	v_bfe_u32 v112, v73, 16, 1                                 // 0000003CD2A4: D6100070 02052149
	v_bfe_u32 v121, v28, 16, 1                                 // 0000003CD2AC: D6100079 0205211C
	v_add3_u32 v33, v33, v135, 0x7fff                          // 0000003CD2B4: D6550021 03FF0F21 00007FFF
	v_bfe_u32 v135, v88, 16, 1                                 // 0000003CD2C0: D6100087 02052158
	v_bfe_u32 v136, v89, 16, 1                                 // 0000003CD2C8: D6100088 02052159
	v_add3_u32 v35, v35, v117, 0x7fff                          // 0000003CD2D0: D6550023 03FEEB23 00007FFF
	v_add3_u32 v78, v78, v120, 0x7fff                          // 0000003CD2DC: D655004E 03FEF14E 00007FFF
	v_add3_u32 v83, v84, v128, 0x7fff                          // 0000003CD2E8: D6550053 03FF0154 00007FFF
	v_add3_u32 v84, v86, v131, 0x7fff                          // 0000003CD2F4: D6550054 03FF0756 00007FFF
	v_add3_u32 v46, v46, v134, 0x7fff                          // 0000003CD300: D655002E 03FF0D2E 00007FFF
	.long 0x7e5a39cc                                           // 0000003CD30C: 7E5A39CC
	v_and_or_b32 v49, 0xffff0000, v60, v103                    // 0000003CD310: D6570031 059E78FF FFFF0000
	v_and_or_b32 v60, 0xffff0000, v82, v38                     // 0000003CD31C: D657003C 049AA4FF FFFF0000
	.long 0x7e4c39b5                                           // 0000003CD328: 7E4C39B5
	.long 0x7fc639a6                                           // 0000003CD32C: 7FC639A6
	v_bfe_u32 v113, v34, 16, 1                                 // 0000003CD330: D6100071 02052122
	v_bfe_u32 v124, v81, 16, 1                                 // 0000003CD338: D610007C 02052151
	v_bfe_u32 v137, v24, 16, 1                                 // 0000003CD340: D6100089 02052118
	v_add3_u32 v73, v73, v112, 0x7fff                          // 0000003CD348: D6550049 03FEE149 00007FFF
	v_bfe_u32 v112, v90, 16, 1                                 // 0000003CD354: D6100070 0205215A
	v_add3_u32 v28, v28, v121, 0x7fff                          // 0000003CD35C: D655001C 03FEF31C 00007FFF
	v_add3_u32 v57, v88, v135, 0x7fff                          // 0000003CD368: D6550039 03FF0F58 00007FFF
	v_add3_u32 v86, v89, v136, 0x7fff                          // 0000003CD374: D6550056 03FF1159 00007FFF
	.long 0x7ec639ce                                           // 0000003CD380: 7EC639CE
	v_and_or_b32 v52, 0xffff0000, v52, v101                    // 0000003CD384: D6570034 059668FF FFFF0000
	v_and_or_b32 v35, 0xffff0000, v35, v45                     // 0000003CD390: D6570023 04B646FF FFFF0000
	v_and_or_b32 v45, 0xffff0000, v84, v38                     // 0000003CD39C: D657002D 049AA8FF FFFF0000
	.long 0x7e4c39ae                                           // 0000003CD3A8: 7E4C39AE
	.long 0x7fcc39a6                                           // 0000003CD3AC: 7FCC39A6
	.long 0x7f8639a6                                           // 0000003CD3B0: 7F8639A6
	.long 0x7fda39a6                                           // 0000003CD3B4: 7FDA39A6
	v_bfe_u32 v125, v29, 16, 1                                 // 0000003CD3B8: D610007D 0205211D
	v_bfe_u32 v132, v87, 16, 1                                 // 0000003CD3C0: D6100084 02052157
	v_add3_u32 v34, v34, v113, 0x7fff                          // 0000003CD3C8: D6550022 03FEE322 00007FFF
	v_bfe_u32 v113, v91, 16, 1                                 // 0000003CD3D4: D6100071 0205215B
	v_bfe_u32 v114, v92, 16, 1                                 // 0000003CD3DC: D6100072 0205215C
	v_add3_u32 v81, v81, v124, 0x7fff                          // 0000003CD3E4: D6550051 03FEF951 00007FFF
	v_add3_u32 v24, v24, v137, 0x7fff                          // 0000003CD3F0: D6550018 03FF1318 00007FFF
	v_add3_u32 v61, v90, v112, 0x7fff                          // 0000003CD3FC: D655003D 03FEE15A 00007FFF
	.long 0x7e8639c2                                           // 0000003CD408: 7E8639C2
	.long 0x7eda39d6                                           // 0000003CD40C: 7EDA39D6
	v_and_or_b32 v28, 0xffff0000, v28, v99                     // 0000003CD410: D657001C 058E38FF FFFF0000
	.long 0x7fc839a6                                           // 0000003CD41C: 7FC839A6
	v_bfe_u32 v115, v25, 16, 1                                 // 0000003CD420: D6100073 02052119
	v_bfe_u32 v116, v93, 16, 1                                 // 0000003CD428: D6100074 0205215D
	v_add3_u32 v29, v29, v125, 0x7fff                          // 0000003CD430: D655001D 03FEFB1D 00007FFF
	v_add3_u32 v85, v87, v132, 0x7fff                          // 0000003CD43C: D6550055 03FF0957 00007FFF
	v_add3_u32 v87, v91, v113, 0x7fff                          // 0000003CD448: D6550057 03FEE35B 00007FFF
	v_add3_u32 v88, v92, v114, 0x7fff                          // 0000003CD454: D6550058 03FEE55C 00007FFF
	.long 0x7ec839d1                                           // 0000003CD460: 7EC839D1
	v_and_or_b32 v56, 0xffff0000, v56, v102                    // 0000003CD464: D6570038 059A70FF FFFF0000
	v_and_or_b32 v32, 0xffff0000, v32, v67                     // 0000003CD470: D6570020 050E40FF FFFF0000
	v_and_or_b32 v24, 0xffff0000, v24, v109                    // 0000003CD47C: D6570018 05B630FF FFFF0000
	.long 0x7fd239a6                                           // 0000003CD488: 7FD239A6
	.long 0x7fdc39a6                                           // 0000003CD48C: 7FDC39A6
	v_bfe_u32 v117, v94, 16, 1                                 // 0000003CD490: D6100075 0205215E
	v_bfe_u32 v118, v95, 16, 1                                 // 0000003CD498: D6100076 0205215F
	v_add3_u32 v25, v25, v115, 0x7fff                          // 0000003CD4A0: D6550019 03FEE719 00007FFF
	v_add3_u32 v64, v93, v116, 0x7fff                          // 0000003CD4AC: D6550040 03FEE95D 00007FFF
	.long 0x7ed239c6                                           // 0000003CD4B8: 7ED239C6
	.long 0x7edc39d8                                           // 0000003CD4BC: 7EDC39D8
	v_and_or_b32 v29, 0xffff0000, v29, v100                    // 0000003CD4C0: D657001D 05923AFF FFFF0000
	v_bfe_u32 v129, v30, 16, 1                                 // 0000003CD4CC: D6100081 0205211E
	v_bfe_u32 v119, v26, 16, 1                                 // 0000003CD4D4: D6100077 0205211A
	v_bfe_u32 v120, v96, 16, 1                                 // 0000003CD4DC: D6100078 02052160
	v_add3_u32 v89, v94, v117, 0x7fff                          // 0000003CD4E4: D6550059 03FEEB5E 00007FFF
	v_add3_u32 v90, v95, v118, 0x7fff                          // 0000003CD4F0: D655005A 03FEED5F 00007FFF
	v_and_or_b32 v33, 0xffff0000, v33, v105                    // 0000003CD4FC: D6570021 05A642FF FFFF0000
	v_and_or_b32 v25, 0xffff0000, v25, v110                    // 0000003CD508: D6570019 05BA32FF FFFF0000
	.long 0x7fd439a6                                           // 0000003CD514: 7FD439A6
	.long 0x7fd639a6                                           // 0000003CD518: 7FD639A6
	.long 0x7fde39a6                                           // 0000003CD51C: 7FDE39A6
	v_bfe_u32 v121, v98, 16, 1                                 // 0000003CD520: D6100079 02052162
	v_bfe_u32 v122, v97, 16, 1                                 // 0000003CD528: D610007A 02052161
	v_add3_u32 v30, v30, v129, 0x7fff                          // 0000003CD530: D655001E 03FF031E 00007FFF
	v_add3_u32 v26, v26, v119, 0x7fff                          // 0000003CD53C: D655001A 03FEEF1A 00007FFF
	v_add3_u32 v68, v96, v120, 0x7fff                          // 0000003CD548: D6550044 03FEF160 00007FFF
	.long 0x7ed439c9                                           // 0000003CD554: 7ED439C9
	.long 0x7ed639d3                                           // 0000003CD558: 7ED639D3
	.long 0x7ede39da                                           // 0000003CD55C: 7EDE39DA
	v_bfe_u32 v133, v31, 16, 1                                 // 0000003CD560: D6100085 0205211F
	v_bfe_u32 v123, v27, 16, 1                                 // 0000003CD568: D610007B 0205211B
	v_add3_u32 v91, v98, v121, 0x7fff                          // 0000003CD570: D655005B 03FEF362 00007FFF
	v_and_or_b32 v34, 0xffff0000, v34, v106                    // 0000003CD57C: D6570022 05AA44FF FFFF0000
	v_and_or_b32 v30, 0xffff0000, v30, v107                    // 0000003CD588: D657001E 05AE3CFF FFFF0000
	v_and_or_b32 v26, 0xffff0000, v26, v111                    // 0000003CD594: D657001A 05BE34FF FFFF0000
	.long 0x7fd039a6                                           // 0000003CD5A0: 7FD039A6
	.long 0x7fd839a6                                           // 0000003CD5A4: 7FD839A6
	v_add3_u32 v31, v31, v133, 0x7fff                          // 0000003CD5A8: D655001F 03FF0B1F 00007FFF
	s_waitcnt vmcnt(1)                                         // 0000003CD5B4: BF8907F7
	v_dot2_f32_bf16 v46, v16, v50, 0                           // 0000003CD5B8: CC1A402E 1A026510
	v_and_or_b32 v50, 0xffff0000, v57, v38                     // 0000003CD5C0: D6570032 049A72FF FFFF0000
	v_dot2_f32_bf16 v47, v16, v47, 0                           // 0000003CD5CC: CC1A402F 1A025F10
	v_dot2_f32_bf16 v53, v16, v65, 0                           // 0000003CD5D4: CC1A4035 1A028310
	.long 0x7e4c39bd                                           // 0000003CD5DC: 7E4C39BD
	v_dot2_f32_bf16 v46, v17, v52, v46                         // 0000003CD5E0: CC1A402E 1CBA6911
	v_dot2_f32_bf16 v16, v16, v50, 0                           // 0000003CD5E8: CC1A4010 1A026510
	v_dot2_f32_bf16 v28, v17, v28, v47                         // 0000003CD5F0: CC1A401C 1CBE3911
	v_dot2_f32_bf16 v32, v17, v32, v53                         // 0000003CD5F8: CC1A4020 1CD64111
	v_and_or_b32 v47, 0xffff0000, v87, v38                     // 0000003CD600: D657002F 049AAEFF FFFF0000
	v_dot2_f32_bf16 v46, v18, v54, v46                         // 0000003CD60C: CC1A402E 1CBA6D12
	v_dot2_f32_bf16 v16, v17, v24, v16                         // 0000003CD614: CC1A4010 1C423111
	v_dot2_f32_bf16 v28, v18, v63, v28                         // 0000003CD61C: CC1A401C 1C727F12
	v_dot2_f32_bf16 v32, v18, v51, v32                         // 0000003CD624: CC1A4020 1C826712
	.long 0x7e4c39c0                                           // 0000003CD62C: 7E4C39C0
	v_dot2_f32_bf16 v46, v19, v56, v46                         // 0000003CD630: CC1A402E 1CBA7113
	v_dot2_f32_bf16 v16, v18, v47, v16                         // 0000003CD638: CC1A4010 1C425F12
	v_dot2_f32_bf16 v24, v19, v29, v28                         // 0000003CD640: CC1A4018 1C723B13
	v_dot2_f32_bf16 v17, v19, v33, v32                         // 0000003CD648: CC1A4011 1C824313
	v_and_or_b32 v29, 0xffff0000, v89, v38                     // 0000003CD650: D657001D 049AB2FF FFFF0000
	s_waitcnt vmcnt(0)                                         // 0000003CD65C: BF8903F7
	v_dot2_f32_bf16 v28, v20, v58, v46                         // 0000003CD660: CC1A401C 1CBA7514
	v_dot2_f32_bf16 v16, v19, v25, v16                         // 0000003CD668: CC1A4010 1C423313
	v_dot2_f32_bf16 v18, v20, v60, v24                         // 0000003CD670: CC1A4012 1C627914
	v_dot2_f32_bf16 v17, v20, v55, v17                         // 0000003CD678: CC1A4011 1C466F14
	.long 0x7e4c39c4                                           // 0000003CD680: 7E4C39C4
	v_dot2_f32_bf16 v24, v21, v49, v28                         // 0000003CD684: CC1A4018 1C726315
	v_dot2_f32_bf16 v16, v20, v29, v16                         // 0000003CD68C: CC1A4010 1C423B14
	.long 0x7ed839d5                                           // 0000003CD694: 7ED839D5
	v_dot2_f32_bf16 v17, v21, v34, v17                         // 0000003CD698: CC1A4011 1C464515
	v_dot2_f32_bf16 v18, v21, v30, v18                         // 0000003CD6A0: CC1A4012 1C4A3D15
	v_dot2_f32_bf16 v19, v22, v62, v24                         // 0000003CD6A8: CC1A4013 1C627D16
	v_add3_u32 v24, v97, v122, 0x7fff                          // 0000003CD6B0: D6550018 03FEF561 00007FFF
	.long 0x7e2839db                                           // 0000003CD6BC: 7E2839DB
	.long 0x7f2839a6                                           // 0000003CD6C0: 7F2839A6
	v_add3_u32 v25, v27, v123, 0x7fff                          // 0000003CD6C4: D6550019 03FEF71B 00007FFF
	v_dot2_f32_bf16 v16, v21, v26, v16                         // 0000003CD6D0: CC1A4010 1C423515
	v_and_or_b32 v24, 0xffff0000, v24, v38                     // 0000003CD6D8: D6570018 049A30FF FFFF0000
	v_and_or_b32 v48, 0xffff0000, v48, v104                    // 0000003CD6E4: D6570030 05A260FF FFFF0000
	v_dot2_f32_bf16 v17, v22, v59, v17                         // 0000003CD6F0: CC1A4011 1C467716
	v_and_or_b32 v21, 0xffff0000, v31, v108                    // 0000003CD6F8: D6570015 05B23EFF FFFF0000
	v_dot2_f32_bf16 v18, v22, v45, v18                         // 0000003CD704: CC1A4012 1C4A5B16
	v_and_or_b32 v20, 0xffff0000, v25, v20                     // 0000003CD70C: D6570014 045232FF FFFF0000
	v_dot2_f32_bf16 v16, v22, v24, v16                         // 0000003CD718: CC1A4010 1C423116
	v_dot2_f32_bf16 v19, v23, v48, v19                         // 0000003CD720: CC1A4013 1C4E6117
	v_dot2_f32_bf16 v17, v23, v35, v17                         // 0000003CD728: CC1A4011 1C464717
	v_dot2_f32_bf16 v18, v23, v21, v18                         // 0000003CD730: CC1A4012 1C4A2B17
	s_mov_b32 s0, exec_lo                                      // 0000003CD738: BE80007E
	v_dot2_f32_bf16 v16, v23, v20, v16                         // 0000003CD73C: CC1A4010 1C422917
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003CD744: BF870113
	v_dual_add_f32 v20, 0, v19 :: v_dual_add_f32 v21, 0, v17   // 0000003CD748: C9082680 14142280
	v_dual_add_f32 v22, 0, v18 :: v_dual_add_f32 v23, 0, v16   // 0000003CD750: C9082480 16162080
	v_cmpx_gt_u32_e32 20, v43                                  // 0000003CD758: 7D985694
	s_cbranch_execz 737                                        // 0000003CD75C: BFA502E1 <_ZN7halogen12_GLOBAL__N_17k_hcup8ILi1EEEvPKhPKtS5_PtPf+0x18e4>
	.long 0xd700011c                                           // 0000003CD760: D700011C
	v_cndmask_b32_e32 v1, s6, v44, vcc_lo                      // 0000003CD764: 02025806
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003CD768: BF870001
	v_add_co_ci_u32_e64 v29, null, s7, 0, s1                   // 0000003CD76C: D5207C1D 00050007
	v_cvt_f32_ubyte0_e32 v30, v12                              // 0000003CD774: 7E3C230C
	v_cvt_f32_ubyte1_e32 v31, v12                              // 0000003CD778: 7E3E250C
	v_cvt_f32_ubyte2_e32 v32, v12                              // 0000003CD77C: 7E40270C
	global_load_b128 v[16:19], v[28:29], off offset:512        // 0000003CD780: DC5E0200 107C001C
	v_cvt_f32_ubyte3_e32 v33, v12                              // 0000003CD788: 7E42290C
	v_cvt_f32_ubyte0_e32 v34, v13                              // 0000003CD78C: 7E44230D
	v_cvt_f32_ubyte1_e32 v35, v13                              // 0000003CD790: 7E46250D
	v_cvt_f32_ubyte2_e32 v43, v13                              // 0000003CD794: 7E56270D
	v_cvt_f32_ubyte3_e32 v44, v13                              // 0000003CD798: 7E58290D
	v_cvt_f32_ubyte0_e32 v45, v14                              // 0000003CD79C: 7E5A230E
	v_cvt_f32_ubyte1_e32 v46, v14                              // 0000003CD7A0: 7E5C250E
	v_cvt_f32_ubyte2_e32 v47, v14                              // 0000003CD7A4: 7E5E270E
	v_cvt_f32_ubyte3_e32 v48, v14                              // 0000003CD7A8: 7E60290E
	v_cvt_f32_ubyte0_e32 v49, v15                              // 0000003CD7AC: 7E62230F
	v_cvt_f32_ubyte1_e32 v50, v15                              // 0000003CD7B0: 7E64250F
	v_cvt_f32_ubyte2_e32 v51, v15                              // 0000003CD7B4: 7E66270F
	v_cvt_f32_ubyte3_e32 v52, v15                              // 0000003CD7B8: 7E68290F
	global_load_b128 v[12:15], v[28:29], off offset:528        // 0000003CD7BC: DC5E0210 0C7C001C
	v_cvt_f32_ubyte0_e32 v29, v8                               // 0000003CD7C4: 7E3A2308
	v_cvt_f32_ubyte1_e32 v53, v8                               // 0000003CD7C8: 7E6A2508
	v_cvt_f32_ubyte2_e32 v54, v8                               // 0000003CD7CC: 7E6C2708
	v_cvt_f32_ubyte3_e32 v55, v8                               // 0000003CD7D0: 7E6E2908
	v_cvt_f32_ubyte0_e32 v56, v9                               // 0000003CD7D4: 7E702309
	v_cvt_f32_ubyte1_e32 v57, v9                               // 0000003CD7D8: 7E722509
	v_cvt_f32_ubyte2_e32 v58, v9                               // 0000003CD7DC: 7E742709
	v_cvt_f32_ubyte3_e32 v9, v9                                // 0000003CD7E0: 7E122909
	v_cvt_f32_ubyte0_e32 v59, v10                              // 0000003CD7E4: 7E76230A
	v_cvt_f32_ubyte1_e32 v60, v10                              // 0000003CD7E8: 7E78250A
	v_cvt_f32_ubyte2_e32 v61, v10                              // 0000003CD7EC: 7E7A270A
	v_cvt_f32_ubyte3_e32 v10, v10                              // 0000003CD7F0: 7E14290A
	v_cvt_f32_ubyte0_e32 v63, v11                              // 0000003CD7F4: 7E7E230B
	v_cvt_f32_ubyte1_e32 v64, v11                              // 0000003CD7F8: 7E80250B
	v_cvt_f32_ubyte2_e32 v65, v11                              // 0000003CD7FC: 7E82270B
	v_cvt_f32_ubyte3_e32 v11, v11                              // 0000003CD800: 7E16290B
	v_cvt_f32_ubyte0_e32 v67, v4                               // 0000003CD804: 7E862304
	v_cvt_f32_ubyte1_e32 v68, v4                               // 0000003CD808: 7E882504
	v_cvt_f32_ubyte2_e32 v69, v4                               // 0000003CD80C: 7E8A2704
	v_cvt_f32_ubyte3_e32 v4, v4                                // 0000003CD810: 7E082904
	v_cvt_f32_ubyte0_e32 v71, v5                               // 0000003CD814: 7E8E2305
	v_cvt_f32_ubyte1_e32 v72, v5                               // 0000003CD818: 7E902505
	v_cvt_f32_ubyte2_e32 v73, v5                               // 0000003CD81C: 7E922705
	v_cvt_f32_ubyte3_e32 v5, v5                                // 0000003CD820: 7E0A2905
	v_cvt_f32_ubyte0_e32 v75, v6                               // 0000003CD824: 7E962306
	v_cvt_f32_ubyte1_e32 v76, v6                               // 0000003CD828: 7E982506
	v_cvt_f32_ubyte2_e32 v77, v6                               // 0000003CD82C: 7E9A2706
	v_cvt_f32_ubyte3_e32 v6, v6                                // 0000003CD830: 7E0C2906
	v_cvt_f32_ubyte0_e32 v79, v7                               // 0000003CD834: 7E9E2307
	v_cvt_f32_ubyte1_e32 v80, v7                               // 0000003CD838: 7EA02507
	v_cvt_f32_ubyte2_e32 v81, v7                               // 0000003CD83C: 7EA22707
	v_cvt_f32_ubyte3_e32 v7, v7                                // 0000003CD840: 7E0E2907
	v_cvt_f32_ubyte0_e32 v83, v0                               // 0000003CD844: 7EA62300
	v_cvt_f32_ubyte1_e32 v84, v0                               // 0000003CD848: 7EA82500
	v_cvt_f32_ubyte2_e32 v85, v0                               // 0000003CD84C: 7EAA2700
	v_cvt_f32_ubyte3_e32 v0, v0                                // 0000003CD850: 7E002900
	v_cvt_f32_ubyte0_e32 v87, v1                               // 0000003CD854: 7EAE2301
	v_cvt_f32_ubyte1_e32 v88, v1                               // 0000003CD858: 7EB02501
	v_cvt_f32_ubyte2_e32 v89, v1                               // 0000003CD85C: 7EB22701
	v_cvt_f32_ubyte3_e32 v1, v1                                // 0000003CD860: 7E022901
	v_cvt_f32_ubyte0_e32 v91, v2                               // 0000003CD864: 7EB62302
	v_cvt_f32_ubyte1_e32 v92, v2                               // 0000003CD868: 7EB82502
	v_cvt_f32_ubyte2_e32 v93, v2                               // 0000003CD86C: 7EBA2702
	v_cvt_f32_ubyte3_e32 v2, v2                                // 0000003CD870: 7E042902
	v_cvt_f32_ubyte0_e32 v95, v3                               // 0000003CD874: 7EBE2303
	v_cvt_f32_ubyte1_e32 v96, v3                               // 0000003CD878: 7EC02503
	v_cvt_f32_ubyte2_e32 v97, v3                               // 0000003CD87C: 7EC22703
	v_cvt_f32_ubyte3_e32 v3, v3                                // 0000003CD880: 7E062903
	v_fma_mix_f32 v30, v30, v41, v41 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CD884: CC20601E 14A6531E
	v_fma_mix_f32 v31, v31, v41, v41 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CD88C: CC20601F 14A6531F
	v_fma_mix_f32 v32, v32, v41, v41 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CD894: CC206020 14A65320
	v_fma_mix_f32 v33, v33, v41, v41 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CD89C: CC206021 14A65321
	v_fma_mix_f32 v34, v34, v41, v41 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CD8A4: CC206022 14A65322
	v_fma_mix_f32 v35, v35, v41, v41 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CD8AC: CC206023 14A65323
	v_fma_mix_f32 v43, v43, v41, v41 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CD8B4: CC20602B 14A6532B
	v_fma_mix_f32 v44, v44, v41, v41 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CD8BC: CC20602C 14A6532C
	v_fma_mix_f32 v45, v45, v41, v41 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CD8C4: CC20602D 14A6532D
	v_fma_mix_f32 v46, v46, v41, v41 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CD8CC: CC20602E 14A6532E
	v_fma_mix_f32 v47, v47, v41, v41 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CD8D4: CC20602F 14A6532F
	v_fma_mix_f32 v48, v48, v41, v41 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CD8DC: CC206030 14A65330
	v_fma_mix_f32 v49, v49, v41, v41 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CD8E4: CC206031 14A65331
	v_fma_mix_f32 v50, v50, v41, v41 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CD8EC: CC206032 14A65332
	v_fma_mix_f32 v51, v51, v41, v41 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CD8F4: CC206033 14A65333
	v_fma_mix_f32 v41, v52, v41, v41 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CD8FC: CC206029 14A65334
	v_fma_mix_f32 v29, v29, v42, v42 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CD904: CC20601D 14AA551D
	v_fma_mix_f32 v52, v53, v42, v42 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CD90C: CC206034 14AA5535
	v_fma_mix_f32 v53, v54, v42, v42 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CD914: CC206035 14AA5536
	v_fma_mix_f32 v54, v55, v42, v42 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CD91C: CC206036 14AA5537
	v_fma_mix_f32 v55, v56, v42, v42 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CD924: CC206037 14AA5538
	v_fma_mix_f32 v56, v57, v42, v42 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CD92C: CC206038 14AA5539
	v_fma_mix_f32 v57, v58, v42, v42 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CD934: CC206039 14AA553A
	v_fma_mix_f32 v9, v9, v42, v42 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CD93C: CC206009 14AA5509
	v_fma_mix_f32 v58, v59, v42, v42 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CD944: CC20603A 14AA553B
	v_fma_mix_f32 v59, v60, v42, v42 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CD94C: CC20603B 14AA553C
	v_fma_mix_f32 v60, v61, v42, v42 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CD954: CC20603C 14AA553D
	v_fma_mix_f32 v10, v10, v42, v42 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CD95C: CC20600A 14AA550A
	v_fma_mix_f32 v61, v63, v42, v42 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CD964: CC20603D 14AA553F
	v_fma_mix_f32 v63, v64, v42, v42 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CD96C: CC20603F 14AA5540
	v_fma_mix_f32 v64, v65, v42, v42 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CD974: CC206040 14AA5541
	v_fma_mix_f32 v11, v11, v42, v42 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CD97C: CC20600B 14AA550B
	v_fma_mix_f32 v42, v67, v40, v40 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CD984: CC20602A 14A25143
	v_fma_mix_f32 v65, v68, v40, v40 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CD98C: CC206041 14A25144
	v_fma_mix_f32 v67, v69, v40, v40 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CD994: CC206043 14A25145
	v_fma_mix_f32 v4, v4, v40, v40 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CD99C: CC206004 14A25104
	v_fma_mix_f32 v68, v71, v40, v40 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CD9A4: CC206044 14A25147
	v_fma_mix_f32 v69, v72, v40, v40 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CD9AC: CC206045 14A25148
	v_fma_mix_f32 v71, v73, v40, v40 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CD9B4: CC206047 14A25149
	v_fma_mix_f32 v5, v5, v40, v40 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CD9BC: CC206005 14A25105
	v_fma_mix_f32 v72, v75, v40, v40 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CD9C4: CC206048 14A2514B
	v_fma_mix_f32 v73, v76, v40, v40 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CD9CC: CC206049 14A2514C
	v_fma_mix_f32 v75, v77, v40, v40 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CD9D4: CC20604B 14A2514D
	v_fma_mix_f32 v6, v6, v40, v40 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CD9DC: CC206006 14A25106
	v_fma_mix_f32 v76, v79, v40, v40 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CD9E4: CC20604C 14A2514F
	v_fma_mix_f32 v77, v80, v40, v40 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CD9EC: CC20604D 14A25150
	v_fma_mix_f32 v79, v81, v40, v40 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CD9F4: CC20604F 14A25151
	v_fma_mix_f32 v7, v7, v40, v40 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CD9FC: CC206007 14A25107
	v_fma_mix_f32 v40, v83, v39, v39 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CDA04: CC206028 149E4F53
	v_fma_mix_f32 v80, v84, v39, v39 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CDA0C: CC206050 149E4F54
	v_fma_mix_f32 v81, v85, v39, v39 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CDA14: CC206051 149E4F55
	v_fma_mix_f32 v0, v0, v39, v39 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CDA1C: CC206000 149E4F00
	v_fma_mix_f32 v83, v87, v39, v39 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CDA24: CC206053 149E4F57
	v_fma_mix_f32 v84, v88, v39, v39 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CDA2C: CC206054 149E4F58
	v_fma_mix_f32 v85, v89, v39, v39 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CDA34: CC206055 149E4F59
	v_fma_mix_f32 v1, v1, v39, v39 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CDA3C: CC206001 149E4F01
	v_fma_mix_f32 v87, v91, v39, v39 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CDA44: CC206057 149E4F5B
	v_fma_mix_f32 v88, v92, v39, v39 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CDA4C: CC206058 149E4F5C
	v_fma_mix_f32 v89, v93, v39, v39 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CDA54: CC206059 149E4F5D
	v_fma_mix_f32 v2, v2, v39, v39 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CDA5C: CC206002 149E4F02
	v_fma_mix_f32 v91, v95, v39, v39 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CDA64: CC20605B 149E4F5F
	v_fma_mix_f32 v92, v96, v39, v39 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CDA6C: CC20605C 149E4F60
	v_fma_mix_f32 v93, v97, v39, v39 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CDA74: CC20605D 149E4F61
	v_fma_mix_f32 v3, v3, v39, v39 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CDA7C: CC206003 149E4F03
	v_bfe_u32 v39, v30, 16, 1                                  // 0000003CDA84: D6100027 0205211E
	v_bfe_u32 v95, v31, 16, 1                                  // 0000003CDA8C: D610005F 0205211F
	v_bfe_u32 v98, v34, 16, 1                                  // 0000003CDA94: D6100062 02052122
	v_bfe_u32 v99, v35, 16, 1                                  // 0000003CDA9C: D6100063 02052123
	v_bfe_u32 v102, v45, 16, 1                                 // 0000003CDAA4: D6100066 0205212D
	v_add3_u32 v30, v30, v39, 0x7fff                           // 0000003CDAAC: D655001E 03FE4F1E 00007FFF
	v_add3_u32 v31, v31, v95, 0x7fff                           // 0000003CDAB8: D655001F 03FEBF1F 00007FFF
	v_add3_u32 v34, v34, v98, 0x7fff                           // 0000003CDAC4: D6550022 03FEC522 00007FFF
	v_bfe_u32 v103, v46, 16, 1                                 // 0000003CDAD0: D6100067 0205212E
	v_bfe_u32 v106, v49, 16, 1                                 // 0000003CDAD8: D610006A 02052131
	.long 0x7e4c399e                                           // 0000003CDAE0: 7E4C399E
	v_add3_u32 v35, v35, v99, 0x7fff                           // 0000003CDAE4: D6550023 03FEC723 00007FFF
	v_add3_u32 v45, v45, v102, 0x7fff                          // 0000003CDAF0: D655002D 03FECD2D 00007FFF
	v_bfe_u32 v107, v50, 16, 1                                 // 0000003CDAFC: D610006B 02052132
	v_bfe_u32 v110, v29, 16, 1                                 // 0000003CDB04: D610006E 0205211D
	v_and_or_b32 v31, 0xffff0000, v31, v38                     // 0000003CDB0C: D657001F 049A3EFF FFFF0000
	.long 0x7e4c39a2                                           // 0000003CDB18: 7E4C39A2
	v_add3_u32 v46, v46, v103, 0x7fff                          // 0000003CDB1C: D655002E 03FECF2E 00007FFF
	v_add3_u32 v49, v49, v106, 0x7fff                          // 0000003CDB28: D6550031 03FED531 00007FFF
	v_bfe_u32 v96, v32, 16, 1                                  // 0000003CDB34: D6100060 02052120
	v_bfe_u32 v111, v52, 16, 1                                 // 0000003CDB3C: D610006F 02052134
	v_and_or_b32 v35, 0xffff0000, v35, v38                     // 0000003CDB44: D6570023 049A46FF FFFF0000
	.long 0x7e4c39ad                                           // 0000003CDB50: 7E4C39AD
	v_bfe_u32 v114, v55, 16, 1                                 // 0000003CDB54: D6100072 02052137
	v_add3_u32 v50, v50, v107, 0x7fff                          // 0000003CDB5C: D6550032 03FED732 00007FFF
	v_add3_u32 v29, v29, v110, 0x7fff                          // 0000003CDB68: D655001D 03FEDD1D 00007FFF
	v_bfe_u32 v100, v43, 16, 1                                 // 0000003CDB74: D6100064 0205212B
	v_and_or_b32 v46, 0xffff0000, v46, v38                     // 0000003CDB7C: D657002E 049A5CFF FFFF0000
	.long 0x7e4c39b1                                           // 0000003CDB88: 7E4C39B1
	v_bfe_u32 v115, v56, 16, 1                                 // 0000003CDB8C: D6100073 02052138
	v_bfe_u32 v118, v58, 16, 1                                 // 0000003CDB94: D6100076 0205213A
	v_add3_u32 v32, v32, v96, 0x7fff                           // 0000003CDB9C: D6550020 03FEC120 00007FFF
	v_add3_u32 v52, v52, v111, 0x7fff                          // 0000003CDBA8: D6550034 03FEDF34 00007FFF
	v_add3_u32 v55, v55, v114, 0x7fff                          // 0000003CDBB4: D6550037 03FEE537 00007FFF
	v_and_or_b32 v50, 0xffff0000, v50, v38                     // 0000003CDBC0: D6570032 049A64FF FFFF0000
	.long 0x7e4c399d                                           // 0000003CDBCC: 7E4C399D
	v_bfe_u32 v104, v47, 16, 1                                 // 0000003CDBD0: D6100068 0205212F
	v_bfe_u32 v119, v59, 16, 1                                 // 0000003CDBD8: D6100077 0205213B
	v_bfe_u32 v122, v61, 16, 1                                 // 0000003CDBE0: D610007A 0205213D
	v_add3_u32 v43, v43, v100, 0x7fff                          // 0000003CDBE8: D655002B 03FEC92B 00007FFF
	v_add3_u32 v56, v56, v115, 0x7fff                          // 0000003CDBF4: D6550038 03FEE738 00007FFF
	v_add3_u32 v58, v58, v118, 0x7fff                          // 0000003CDC00: D655003A 03FEED3A 00007FFF
	.long 0x7e3039a0                                           // 0000003CDC0C: 7E3039A0
	v_and_or_b32 v32, 0xffff0000, v52, v38                     // 0000003CDC10: D6570020 049A68FF FFFF0000
	.long 0x7e4c39b7                                           // 0000003CDC1C: 7E4C39B7
	v_bfe_u32 v123, v63, 16, 1                                 // 0000003CDC20: D610007B 0205213F
	v_bfe_u32 v126, v42, 16, 1                                 // 0000003CDC28: D610007E 0205212A
	v_bfe_u32 v39, v40, 16, 1                                  // 0000003CDC30: D6100027 02052128
	v_bfe_u32 v96, v81, 16, 1                                  // 0000003CDC38: D6100060 02052151
	v_add3_u32 v47, v47, v104, 0x7fff                          // 0000003CDC40: D655002F 03FED12F 00007FFF
	v_add3_u32 v59, v59, v119, 0x7fff                          // 0000003CDC4C: D655003B 03FEEF3B 00007FFF
	v_add3_u32 v61, v61, v122, 0x7fff                          // 0000003CDC58: D655003D 03FEF53D 00007FFF
	.long 0x7e3239ab                                           // 0000003CDC64: 7E3239AB
	v_and_or_b32 v43, 0xffff0000, v56, v38                     // 0000003CDC68: D657002B 049A70FF FFFF0000
	.long 0x7e4c39ba                                           // 0000003CDC74: 7E4C39BA
	v_bfe_u32 v97, v33, 16, 1                                  // 0000003CDC78: D6100061 02052121
	v_bfe_u32 v116, v57, 16, 1                                 // 0000003CDC80: D6100074 02052139
	v_bfe_u32 v127, v65, 16, 1                                 // 0000003CDC88: D610007F 02052141
	v_bfe_u32 v130, v68, 16, 1                                 // 0000003CDC90: D6100082 02052144
	v_add3_u32 v63, v63, v123, 0x7fff                          // 0000003CDC98: D655003F 03FEF73F 00007FFF
	v_add3_u32 v42, v42, v126, 0x7fff                          // 0000003CDCA4: D655002A 03FEFD2A 00007FFF
	v_add3_u32 v34, v40, v39, 0x7fff                           // 0000003CDCB0: D6550022 03FE4F28 00007FFF
	v_add3_u32 v40, v81, v96, 0x7fff                           // 0000003CDCBC: D6550028 03FEC151 00007FFF
	.long 0x7e3439af                                           // 0000003CDCC8: 7E3439AF
	v_and_or_b32 v47, 0xffff0000, v59, v38                     // 0000003CDCCC: D657002F 049A76FF FFFF0000
	.long 0x7e4c39bd                                           // 0000003CDCD8: 7E4C39BD
	.long 0x7f3039a6                                           // 0000003CDCDC: 7F3039A6
	v_bfe_u32 v108, v51, 16, 1                                 // 0000003CDCE0: D610006C 02052133
	v_bfe_u32 v117, v9, 16, 1                                  // 0000003CDCE8: D6100075 02052109
	v_bfe_u32 v131, v69, 16, 1                                 // 0000003CDCF0: D6100083 02052145
	v_bfe_u32 v134, v72, 16, 1                                 // 0000003CDCF8: D6100086 02052148
	v_add3_u32 v33, v33, v97, 0x7fff                           // 0000003CDD00: D6550021 03FEC321 00007FFF
	v_add3_u32 v57, v57, v116, 0x7fff                          // 0000003CDD0C: D6550039 03FEE939 00007FFF
	v_add3_u32 v65, v65, v127, 0x7fff                          // 0000003CDD18: D6550041 03FEFF41 00007FFF
	v_add3_u32 v68, v68, v130, 0x7fff                          // 0000003CDD24: D6550044 03FF0544 00007FFF
	.long 0x7eac39a8                                           // 0000003CDD30: 7EAC39A8
	v_and_or_b32 v40, 0xffff0000, v63, v38                     // 0000003CDD34: D6570028 049A7EFF FFFF0000
	.long 0x7e4c39aa                                           // 0000003CDD40: 7E4C39AA
	.long 0x7f1039a6                                           // 0000003CDD44: 7F1039A6
	v_bfe_u32 v109, v41, 16, 1                                 // 0000003CDD48: D610006D 02052129
	v_bfe_u32 v135, v73, 16, 1                                 // 0000003CDD50: D6100087 02052149
	v_bfe_u32 v138, v76, 16, 1                                 // 0000003CDD58: D610008A 0205214C
	v_add3_u32 v51, v51, v108, 0x7fff                          // 0000003CDD60: D6550033 03FED933 00007FFF
	v_add3_u32 v9, v9, v117, 0x7fff                            // 0000003CDD6C: D6550009 03FEEB09 00007FFF
	v_add3_u32 v69, v69, v131, 0x7fff                          // 0000003CDD78: D6550045 03FF0745 00007FFF
	v_add3_u32 v72, v72, v134, 0x7fff                          // 0000003CDD84: D6550048 03FF0D48 00007FFF
	.long 0x7e1039b9                                           // 0000003CDD90: 7E1039B9
	v_and_or_b32 v24, 0xffff0000, v33, v24                     // 0000003CDD94: D6570018 046242FF FFFF0000
	v_and_or_b32 v33, 0xffff0000, v65, v38                     // 0000003CDDA0: D6570021 049A82FF FFFF0000
	.long 0x7e4c39c4                                           // 0000003CDDAC: 7E4C39C4
	.long 0x7f3639a6                                           // 0000003CDDB0: 7F3639A6
	v_bfe_u32 v112, v53, 16, 1                                 // 0000003CDDB4: D6100070 02052135
	v_bfe_u32 v128, v67, 16, 1                                 // 0000003CDDBC: D6100080 02052143
	v_bfe_u32 v139, v77, 16, 1                                 // 0000003CDDC4: D610008B 0205214D
	v_add3_u32 v41, v41, v109, 0x7fff                          // 0000003CDDCC: D6550029 03FEDB29 00007FFF
	v_add3_u32 v73, v73, v135, 0x7fff                          // 0000003CDDD8: D6550049 03FF0F49 00007FFF
	v_add3_u32 v30, v76, v138, 0x7fff                          // 0000003CDDE4: D655001E 03FF154C 00007FFF
	.long 0x7e3639b3                                           // 0000003CDDF0: 7E3639B3
	v_and_or_b32 v8, 0xffff0000, v9, v8                        // 0000003CDDF4: D6570008 042212FF FFFF0000
	v_and_or_b32 v9, 0xffff0000, v69, v38                      // 0000003CDE00: D6570009 049A8AFF FFFF0000
	.long 0x7e4c39c8                                           // 0000003CDE0C: 7E4C39C8
	v_bfe_u32 v113, v54, 16, 1                                 // 0000003CDE10: D6100071 02052136
	v_bfe_u32 v129, v4, 16, 1                                  // 0000003CDE18: D6100081 02052104
	v_bfe_u32 v95, v80, 16, 1                                  // 0000003CDE20: D610005F 02052150
	v_add3_u32 v53, v53, v112, 0x7fff                          // 0000003CDE28: D6550035 03FEE135 00007FFF
	v_add3_u32 v67, v67, v128, 0x7fff                          // 0000003CDE34: D6550043 03FF0143 00007FFF
	v_add3_u32 v76, v77, v139, 0x7fff                          // 0000003CDE40: D655004C 03FF174D 00007FFF
	v_and_or_b32 v27, 0xffff0000, v41, v27                     // 0000003CDE4C: D657001B 046E52FF FFFF0000
	v_and_or_b32 v41, 0xffff0000, v73, v38                     // 0000003CDE58: D6570029 049A92FF FFFF0000
	.long 0x7e4c399e                                           // 0000003CDE64: 7E4C399E
	.long 0x7f3839a6                                           // 0000003CDE68: 7F3839A6
	.long 0x7f8c39a6                                           // 0000003CDE6C: 7F8C39A6
	v_bfe_u32 v101, v44, 16, 1                                 // 0000003CDE70: D6100065 0205212C
	v_bfe_u32 v132, v71, 16, 1                                 // 0000003CDE78: D6100084 02052147
	v_bfe_u32 v97, v0, 16, 1                                   // 0000003CDE80: D6100061 02052100
	v_bfe_u32 v98, v83, 16, 1                                  // 0000003CDE88: D6100062 02052153
	v_add3_u32 v54, v54, v113, 0x7fff                          // 0000003CDE90: D6550036 03FEE336 00007FFF
	v_add3_u32 v4, v4, v129, 0x7fff                            // 0000003CDE9C: D6550004 03FF0304 00007FFF
	v_add3_u32 v39, v80, v95, 0x7fff                           // 0000003CDEA8: D6550027 03FEBF50 00007FFF
	.long 0x7e3839b5                                           // 0000003CDEB4: 7E3839B5
	.long 0x7e8c39c3                                           // 0000003CDEB8: 7E8C39C3
	.long 0x7f3239a6                                           // 0000003CDEBC: 7F3239A6
	.long 0x7fac39a6                                           // 0000003CDEC0: 7FAC39A6
	v_bfe_u32 v133, v5, 16, 1                                  // 0000003CDEC4: D6100085 02052105
	v_bfe_u32 v140, v79, 16, 1                                 // 0000003CDECC: D610008C 0205214F
	v_bfe_u32 v99, v84, 16, 1                                  // 0000003CDED4: D6100063 02052154
	v_bfe_u32 v100, v85, 16, 1                                 // 0000003CDEDC: D6100064 02052155
	v_add3_u32 v44, v44, v101, 0x7fff                          // 0000003CDEE4: D655002C 03FECB2C 00007FFF
	v_add3_u32 v71, v71, v132, 0x7fff                          // 0000003CDEF0: D6550047 03FF0947 00007FFF
	v_add3_u32 v0, v0, v97, 0x7fff                             // 0000003CDEFC: D6550000 03FEC300 00007FFF
	v_add3_u32 v45, v83, v98, 0x7fff                           // 0000003CDF08: D655002D 03FEC553 00007FFF
	v_and_or_b32 v28, 0xffff0000, v54, v28                     // 0000003CDF14: D657001C 04726CFF FFFF0000
	v_and_or_b32 v4, 0xffff0000, v4, v70                       // 0000003CDF20: D6570004 051A08FF FFFF0000
	.long 0x7f9439a6                                           // 0000003CDF2C: 7F9439A6
	v_bfe_u32 v120, v60, 16, 1                                 // 0000003CDF30: D6100078 0205213C
	v_bfe_u32 v136, v75, 16, 1                                 // 0000003CDF38: D6100088 0205214B
	v_bfe_u32 v101, v1, 16, 1                                  // 0000003CDF40: D6100065 02052101
	v_bfe_u32 v102, v87, 16, 1                                 // 0000003CDF48: D6100066 02052157
	v_add3_u32 v5, v5, v133, 0x7fff                            // 0000003CDF50: D6550005 03FF0B05 00007FFF
	v_add3_u32 v77, v79, v140, 0x7fff                          // 0000003CDF5C: D655004D 03FF194F 00007FFF
	v_add3_u32 v79, v84, v99, 0x7fff                           // 0000003CDF68: D655004F 03FEC754 00007FFF
	v_add3_u32 v80, v85, v100, 0x7fff                          // 0000003CDF74: D6550050 03FEC955 00007FFF
	.long 0x7e9439c7                                           // 0000003CDF80: 7E9439C7
	v_and_or_b32 v25, 0xffff0000, v44, v25                     // 0000003CDF84: D6570019 046658FF FFFF0000
	v_and_or_b32 v0, 0xffff0000, v0, v86                       // 0000003CDF90: D6570000 055A00FF FFFF0000
	.long 0x7fb439a6                                           // 0000003CDF9C: 7FB439A6
	v_bfe_u32 v105, v48, 16, 1                                 // 0000003CDFA0: D6100069 02052130
	v_bfe_u32 v121, v10, 16, 1                                 // 0000003CDFA8: D6100079 0205210A
	v_bfe_u32 v137, v6, 16, 1                                  // 0000003CDFB0: D6100089 02052106
	v_bfe_u32 v103, v88, 16, 1                                 // 0000003CDFB8: D6100067 02052158
	v_bfe_u32 v104, v89, 16, 1                                 // 0000003CDFC0: D6100068 02052159
	v_add3_u32 v60, v60, v120, 0x7fff                          // 0000003CDFC8: D655003C 03FEF13C 00007FFF
	v_add3_u32 v75, v75, v136, 0x7fff                          // 0000003CDFD4: D655004B 03FF114B 00007FFF
	v_add3_u32 v1, v1, v101, 0x7fff                            // 0000003CDFE0: D6550001 03FECB01 00007FFF
	v_add3_u32 v49, v87, v102, 0x7fff                          // 0000003CDFEC: D6550031 03FECD57 00007FFF
	.long 0x7eb439d0                                           // 0000003CDFF8: 7EB439D0
	v_and_or_b32 v5, 0xffff0000, v5, v74                       // 0000003CDFFC: D6570005 052A0AFF FFFF0000
	.long 0x7f7c39a6                                           // 0000003CE008: 7F7C39A6
	.long 0x7f9c39a6                                           // 0000003CE00C: 7F9C39A6
	v_add3_u32 v48, v48, v105, 0x7fff                          // 0000003CE010: D6550030 03FED330 00007FFF
	v_bfe_u32 v105, v2, 16, 1                                  // 0000003CE01C: D6100069 02052102
	v_bfe_u32 v106, v91, 16, 1                                 // 0000003CE024: D610006A 0205215B
	v_add3_u32 v10, v10, v121, 0x7fff                          // 0000003CE02C: D655000A 03FEF30A 00007FFF
	v_add3_u32 v6, v6, v137, 0x7fff                            // 0000003CE038: D6550006 03FF1306 00007FFF
	v_add3_u32 v81, v88, v103, 0x7fff                          // 0000003CE044: D6550051 03FECF58 00007FFF
	v_add3_u32 v83, v89, v104, 0x7fff                          // 0000003CE050: D6550053 03FED159 00007FFF
	.long 0x7e7c39bc                                           // 0000003CE05C: 7E7C39BC
	.long 0x7e9c39cb                                           // 0000003CE060: 7E9C39CB
	v_and_or_b32 v1, 0xffff0000, v1, v90                       // 0000003CE064: D6570001 056A02FF FFFF0000
	.long 0x7f3439a6                                           // 0000003CE070: 7F3439A6
	.long 0x7fbc39a6                                           // 0000003CE074: 7FBC39A6
	v_bfe_u32 v124, v64, 16, 1                                 // 0000003CE078: D610007C 02052140
	v_bfe_u32 v107, v92, 16, 1                                 // 0000003CE080: D610006B 0205215C
	v_bfe_u32 v108, v93, 16, 1                                 // 0000003CE088: D610006C 0205215D
	v_add3_u32 v2, v2, v105, 0x7fff                            // 0000003CE090: D6550002 03FED302 00007FFF
	v_add3_u32 v29, v91, v106, 0x7fff                          // 0000003CE09C: D655001D 03FED55B 00007FFF
	.long 0x7ebc39d3                                           // 0000003CE0A8: 7EBC39D3
	v_and_or_b32 v10, 0xffff0000, v10, v62                     // 0000003CE0AC: D657000A 04FA14FF FFFF0000
	v_and_or_b32 v6, 0xffff0000, v6, v78                       // 0000003CE0B8: D6570006 053A0CFF FFFF0000
	v_bfe_u32 v125, v11, 16, 1                                 // 0000003CE0C4: D610007D 0205210B
	v_bfe_u32 v141, v7, 16, 1                                  // 0000003CE0CC: D610008D 02052107
	v_add3_u32 v64, v64, v124, 0x7fff                          // 0000003CE0D4: D6550040 03FEF940 00007FFF
	v_add3_u32 v84, v93, v108, 0x7fff                          // 0000003CE0E0: D6550054 03FED95D 00007FFF
	v_and_or_b32 v26, 0xffff0000, v48, v26                     // 0000003CE0EC: D657001A 046A60FF FFFF0000
	v_and_or_b32 v2, 0xffff0000, v2, v94                       // 0000003CE0F8: D6570002 057A04FF FFFF0000
	.long 0x7f8439a6                                           // 0000003CE104: 7F8439A6
	.long 0x7fa439a6                                           // 0000003CE108: 7FA439A6
	v_add3_u32 v11, v11, v125, 0x7fff                          // 0000003CE10C: D655000B 03FEFB0B 00007FFF
	v_add3_u32 v7, v7, v141, 0x7fff                            // 0000003CE118: D6550007 03FF1B07 00007FFF
	.long 0x7e8439c0                                           // 0000003CE124: 7E8439C0
	.long 0x7ea439cd                                           // 0000003CE128: 7EA439CD
	s_waitcnt vmcnt(1)                                         // 0000003CE12C: BF8907F7
	v_dot2_f32_bf16 v30, v16, v31, 0                           // 0000003CE130: CC1A401E 1A023F10
	v_and_or_b32 v31, 0xffff0000, v76, v38                     // 0000003CE138: D657001F 049A98FF FFFF0000
	.long 0x7e4c39a2                                           // 0000003CE144: 7E4C39A2
	v_dot2_f32_bf16 v32, v16, v32, 0                           // 0000003CE148: CC1A4020 1A024110
	v_dot2_f32_bf16 v33, v16, v33, 0                           // 0000003CE150: CC1A4021 1A024310
	v_dot2_f32_bf16 v24, v17, v24, v30                         // 0000003CE158: CC1A4018 1C7A3111
	v_and_or_b32 v11, 0xffff0000, v11, v66                     // 0000003CE160: D657000B 050A16FF FFFF0000
	v_and_or_b32 v30, 0xffff0000, v39, v38                     // 0000003CE16C: D657001E 049A4EFF FFFF0000
	v_dot2_f32_bf16 v28, v17, v28, v32                         // 0000003CE178: CC1A401C 1C823911
	v_dot2_f32_bf16 v4, v17, v4, v33                           // 0000003CE180: CC1A4004 1C860911
	v_dot2_f32_bf16 v24, v18, v35, v24                         // 0000003CE188: CC1A4018 1C624712
	.long 0x7e4c39ad                                           // 0000003CE190: 7E4C39AD
	v_dot2_f32_bf16 v16, v16, v30, 0                           // 0000003CE194: CC1A4010 1A023D10
	v_dot2_f32_bf16 v28, v18, v43, v28                         // 0000003CE19C: CC1A401C 1C725712
	v_dot2_f32_bf16 v4, v18, v9, v4                            // 0000003CE1A4: CC1A4004 1C121312
	v_dot2_f32_bf16 v9, v19, v25, v24                          // 0000003CE1AC: CC1A4009 1C623313
	v_and_or_b32 v24, 0xffff0000, v79, v38                     // 0000003CE1B4: D6570018 049A9EFF FFFF0000
	v_dot2_f32_bf16 v0, v17, v0, v16                           // 0000003CE1C0: CC1A4000 1C420111
	v_dot2_f32_bf16 v8, v19, v8, v28                           // 0000003CE1C8: CC1A4008 1C721113
	v_dot2_f32_bf16 v4, v19, v5, v4                            // 0000003CE1D0: CC1A4004 1C120B13
	.long 0x7e4c39b1                                           // 0000003CE1D8: 7E4C39B1
	s_waitcnt vmcnt(0)                                         // 0000003CE1DC: BF8903F7
	v_dot2_f32_bf16 v5, v12, v46, v9                           // 0000003CE1E0: CC1A4005 1C265D0C
	v_dot2_f32_bf16 v0, v18, v24, v0                           // 0000003CE1E8: CC1A4000 1C023112
	v_dot2_f32_bf16 v8, v12, v47, v8                           // 0000003CE1F0: CC1A4008 1C225F0C
	v_dot2_f32_bf16 v4, v12, v41, v4                           // 0000003CE1F8: CC1A4004 1C12530C
	v_and_or_b32 v9, 0xffff0000, v81, v38                      // 0000003CE200: D6570009 049AA2FF FFFF0000
	.long 0x7e4c399d                                           // 0000003CE20C: 7E4C399D
	v_dot2_f32_bf16 v0, v19, v1, v0                            // 0000003CE210: CC1A4000 1C020313
	v_dot2_f32_bf16 v1, v13, v10, v8                           // 0000003CE218: CC1A4001 1C22150D
	v_dot2_f32_bf16 v4, v13, v6, v4                            // 0000003CE220: CC1A4004 1C120D0D
	v_bfe_u32 v6, v3, 16, 1                                    // 0000003CE228: D6100006 02052103
	v_add3_u32 v8, v92, v107, 0x7fff                           // 0000003CE230: D6550008 03FED75C 00007FFF
	v_dot2_f32_bf16 v0, v12, v9, v0                            // 0000003CE23C: CC1A4000 1C02130C
	v_dot2_f32_bf16 v5, v13, v26, v5                           // 0000003CE244: CC1A4005 1C16350D
	.long 0x7e1239d4                                           // 0000003CE24C: 7E1239D4
	.long 0x7f1239a6                                           // 0000003CE250: 7F1239A6
	v_add3_u32 v3, v3, v6, 0x7fff                              // 0000003CE254: D6550003 03FE0D03 00007FFF
	v_and_or_b32 v6, 0xffff0000, v8, v38                       // 0000003CE260: D6570006 049A10FF FFFF0000
	v_dot2_f32_bf16 v0, v13, v2, v0                            // 0000003CE26C: CC1A4000 1C02050D
	v_dot2_f32_bf16 v5, v14, v50, v5                           // 0000003CE274: CC1A4005 1C16650E
	v_dot2_f32_bf16 v1, v14, v40, v1                           // 0000003CE27C: CC1A4001 1C06510E
	v_and_or_b32 v2, 0xffff0000, v7, v82                       // 0000003CE284: D6570002 054A0EFF FFFF0000
	v_dot2_f32_bf16 v4, v14, v31, v4                           // 0000003CE290: CC1A4004 1C123F0E
	v_and_or_b32 v3, 0xffff0000, v3, v9                        // 0000003CE298: D6570003 042606FF FFFF0000
	v_dot2_f32_bf16 v0, v14, v6, v0                            // 0000003CE2A4: CC1A4000 1C020D0E
	v_dot2_f32_bf16 v5, v15, v27, v5                           // 0000003CE2AC: CC1A4005 1C16370F
	v_dot2_f32_bf16 v1, v15, v11, v1                           // 0000003CE2B4: CC1A4001 1C06170F
	v_dot2_f32_bf16 v2, v15, v2, v4                            // 0000003CE2BC: CC1A4002 1C12050F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003CE2C4: BF870214
	v_dot2_f32_bf16 v0, v15, v3, v0                            // 0000003CE2C8: CC1A4000 1C02070F
	v_add_f32_e32 v20, v20, v5                                 // 0000003CE2D0: 06280B14
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003CE2D4: BF870193
	v_dual_add_f32 v21, v21, v1 :: v_dual_add_f32 v22, v22, v2 // 0000003CE2D8: C9080315 15160516
	v_add_f32_e32 v23, v23, v0                                 // 0000003CE2E0: 062E0117
	s_or_b32 exec_lo, exec_lo, s0                              // 0000003CE2E4: 8C7E007E
	.long 0xd71f0000                                           // 0000003CE2E8: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000003CE2EC: 020100C1
	s_mov_b32 s0, exec_lo                                      // 0000003CE2F0: BE80007E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000003CE2F4: BF8701B1
	v_xor_b32_e32 v1, 8, v0                                    // 0000003CE2F8: 3A020088
	v_xor_b32_e32 v5, 4, v0                                    // 0000003CE2FC: 3A0A0084
	v_xor_b32_e32 v9, 2, v0                                    // 0000003CE300: 3A120082
	v_cmp_gt_u32_e32 vcc_lo, 32, v1                            // 0000003CE304: 7C9802A0
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 0000003CE308: 02020300
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003CE30C: BF870114
	v_cmp_gt_u32_e32 vcc_lo, 32, v5                            // 0000003CE310: 7C980AA0
	v_lshlrev_b32_e32 v1, 2, v1                                // 0000003CE314: 30020282
	ds_bpermute_b32 v2, v1, v20                                // 0000003CE318: DACC0000 02001401
	s_waitcnt lgkmcnt(0)                                       // 0000003CE320: BF89FC07
	v_add_f32_e32 v2, v20, v2                                  // 0000003CE324: 06040514
	ds_bpermute_b32 v4, v1, v22                                // 0000003CE328: DACC0000 04001601
	v_cndmask_b32_e32 v5, v0, v5, vcc_lo                       // 0000003CE330: 020A0B00
	ds_bpermute_b32 v3, v1, v21                                // 0000003CE334: DACC0000 03001501
	ds_bpermute_b32 v1, v1, v23                                // 0000003CE33C: DACC0000 01001701
	v_cmp_gt_u32_e32 vcc_lo, 32, v9                            // 0000003CE344: 7C9812A0
	s_waitcnt lgkmcnt(2)                                       // 0000003CE348: BF89FC27
	v_dual_cndmask_b32 v9, v0, v9 :: v_dual_add_f32 v4, v22, v4// 0000003CE34C: CA481300 09040916
	v_lshlrev_b32_e32 v5, 2, v5                                // 0000003CE354: 300A0A82
	s_waitcnt lgkmcnt(1)                                       // 0000003CE358: BF89FC17
	v_add_f32_e32 v3, v21, v3                                  // 0000003CE35C: 06060715
	s_waitcnt lgkmcnt(0)                                       // 0000003CE360: BF89FC07
	v_add_f32_e32 v1, v23, v1                                  // 0000003CE364: 06020317
	ds_bpermute_b32 v8, v5, v4                                 // 0000003CE368: DACC0000 08000405
	s_waitcnt lgkmcnt(0)                                       // 0000003CE370: BF89FC07
	v_add_f32_e32 v4, v4, v8                                   // 0000003CE374: 06081104
	ds_bpermute_b32 v6, v5, v2                                 // 0000003CE378: DACC0000 06000205
	ds_bpermute_b32 v7, v5, v3                                 // 0000003CE380: DACC0000 07000305
	v_lshlrev_b32_e32 v9, 2, v9                                // 0000003CE388: 30121282
	ds_bpermute_b32 v5, v5, v1                                 // 0000003CE38C: DACC0000 05000105
	s_waitcnt lgkmcnt(1)                                       // 0000003CE394: BF89FC17
	v_dual_add_f32 v2, v2, v6 :: v_dual_add_f32 v3, v3, v7     // 0000003CE398: C9080D02 02020F03
	ds_bpermute_b32 v7, v9, v4                                 // 0000003CE3A0: DACC0000 07000409
	s_waitcnt lgkmcnt(0)                                       // 0000003CE3A8: BF89FC07
	v_dual_add_f32 v1, v1, v5 :: v_dual_add_f32 v4, v4, v7     // 0000003CE3AC: C9080B01 01040F04
	ds_bpermute_b32 v5, v9, v2                                 // 0000003CE3B4: DACC0000 05000209
	ds_bpermute_b32 v8, v9, v1                                 // 0000003CE3BC: DACC0000 08000109
	s_waitcnt lgkmcnt(1)                                       // 0000003CE3C4: BF89FC17
	v_add_f32_e32 v2, v2, v5                                   // 0000003CE3C8: 06040B02
	ds_bpermute_b32 v6, v9, v3                                 // 0000003CE3CC: DACC0000 06000309
	v_xor_b32_e32 v9, 1, v0                                    // 0000003CE3D4: 3A120081
	s_waitcnt lgkmcnt(1)                                       // 0000003CE3D8: BF89FC17
	v_add_f32_e32 v5, v1, v8                                   // 0000003CE3DC: 060A1101
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000003CE3E0: BF8700B2
	v_cmp_gt_u32_e32 vcc_lo, 32, v9                            // 0000003CE3E4: 7C9812A0
	v_cndmask_b32_e32 v0, v0, v9, vcc_lo                       // 0000003CE3E8: 02001300
	s_waitcnt lgkmcnt(0)                                       // 0000003CE3EC: BF89FC07
	v_dual_add_f32 v3, v3, v6 :: v_dual_lshlrev_b32 v0, 2, v0  // 0000003CE3F0: C9220D03 03000082
	ds_bpermute_b32 v6, v0, v2                                 // 0000003CE3F8: DACC0000 06000200
	ds_bpermute_b32 v8, v0, v4                                 // 0000003CE400: DACC0000 08000400
	ds_bpermute_b32 v9, v0, v5                                 // 0000003CE408: DACC0000 09000500
	ds_bpermute_b32 v7, v0, v3                                 // 0000003CE410: DACC0000 07000300
	v_cmpx_eq_u32_e32 0, v37                                   // 0000003CE418: 7D944A80
	s_cbranch_execz 257                                        // 0000003CE41C: BFA50101 <_ZN7halogen12_GLOBAL__N_17k_hcup8ILi1EEEvPKhPKtS5_PtPf+0x1e24>
	v_ashrrev_i32_e32 v37, 31, v36                             // 0000003CE420: 344A489F
	s_waitcnt lgkmcnt(0)                                       // 0000003CE424: BF89FC07
	v_dual_add_f32 v2, v2, v6 :: v_dual_add_f32 v3, v3, v7     // 0000003CE428: C9080D02 02020F03
	v_dual_add_f32 v4, v4, v8 :: v_dual_add_f32 v5, v5, v9     // 0000003CE430: C9081104 04041305
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003CE438: BF870193
	.long 0xd73c0000                                           // 0000003CE43C: D73C0000
	v_cndmask_b32_e32 v1, 1, v36, vcc_lo                       // 0000003CE440: 02024881
	v_bfe_u32 v6, v2, 16, 1                                    // 0000003CE444: D6100006 02052102
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003CE44C: BF870214
	v_bfe_u32 v7, v3, 16, 1                                    // 0000003CE450: D6100007 02052103
	v_bfe_u32 v8, v4, 16, 1                                    // 0000003CE458: D6100008 02052104
	v_bfe_u32 v9, v5, 16, 1                                    // 0000003CE460: D6100009 02052105
	s_cmp_eq_u64 s[4:5], 0                                     // 0000003CE468: BF108004
	.long 0xd7006a0a                                           // 0000003CE46C: D7006A0A
	v_cndmask_b32_e32 v1, s8, v0, vcc_lo                       // 0000003CE470: 02020008
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000003CE474: BF8701A1
	v_add_co_ci_u32_e64 v11, null, s9, v1, vcc_lo              // 0000003CE478: D5207C0B 01AA0209
	v_add3_u32 v3, v3, v7, 0x7fff                              // 0000003CE480: D6550003 03FE0F03 00007FFF
	.long 0xd7006a0c                                           // 0000003CE48C: D7006A0C
	v_cndmask_b32_e32 v1, 0x1000, v10, vcc_lo                  // 0000003CE490: 020214FF 00001000
	global_load_u16 v16, v[10:11], off                         // 0000003CE498: DC4A0000 107C000A
	v_add_co_ci_u32_e64 v13, null, 0, v11, vcc_lo              // 0000003CE4A0: D5207C0D 01AA1680
	.long 0xd7006a0e                                           // 0000003CE4A8: D7006A0E
	v_cndmask_b32_e32 v1, 0x2000, v10, vcc_lo                  // 0000003CE4AC: 020214FF 00002000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000003CE4B4: BF8700D1
	v_add_co_ci_u32_e64 v15, null, 0, v11, vcc_lo              // 0000003CE4B8: D5207C0F 01AA1680
	s_clause 0x1                                               // 0000003CE4C0: BF850001
	global_load_u16 v12, v[12:13], off offset:1024             // 0000003CE4C4: DC4A0400 0C7C000C
	global_load_u16 v13, v[14:15], off offset:2048             // 0000003CE4CC: DC4A0800 0D7C000E
	.long 0xd7006a0a                                           // 0000003CE4D4: D7006A0A
	v_cndmask_b32_e32 v1, 0x3000, v10, vcc_lo                  // 0000003CE4D8: 020214FF 00003000
	v_add_co_ci_u32_e64 v11, null, 0, v11, vcc_lo              // 0000003CE4E0: D5207C0B 01AA1680
	v_and_b32_e32 v3, 0xffff0000, v3                           // 0000003CE4E8: 360606FF FFFF0000
	v_add3_u32 v2, v2, v6, 0x7fff                              // 0000003CE4F0: D6550002 03FE0D02 00007FFF
	v_add3_u32 v5, v5, v9, 0x7fff                              // 0000003CE4FC: D6550005 03FE1305 00007FFF
	global_load_u16 v10, v[10:11], off offset:3072             // 0000003CE508: DC4A0C00 0A7C000A
	v_add3_u32 v4, v4, v8, 0x7fff                              // 0000003CE510: D6550004 03FE1104 00007FFF
	v_mul_f32_e32 v3, 0xbfb8aa3b, v3                           // 0000003CE51C: 100606FF BFB8AA3B
	v_and_b32_e32 v5, 0xffff0000, v5                           // 0000003CE524: 360A0AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000003CE52C: BF870122
	v_exp_f32_e32 v3, v3                                       // 0000003CE530: 7E064B03
	v_and_b32_e32 v2, 0xffff0000, v2                           // 0000003CE534: 360404FF FFFF0000
	v_mul_f32_e32 v5, 0xbfb8aa3b, v5                           // 0000003CE53C: 100A0AFF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 0000003CE544: BF870311
	v_exp_f32_e32 v5, v5                                       // 0000003CE548: 7E0A4B05
	v_dual_add_f32 v3, 1.0, v3 :: v_dual_and_b32 v4, 0xffff0000, v4// 0000003CE54C: C92406F2 030408FF FFFF0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003CE558: BF870113
	v_mul_f32_e32 v2, 0xbfb8aa3b, v2                           // 0000003CE55C: 100404FF BFB8AA3B
	v_div_scale_f32 v7, null, v3, v3, 1.0                      // 0000003CE564: D6FC7C07 03CA0703
	s_delay_alu instid0(VALU_DEP_2)                            // 0000003CE56C: BF870002
	v_exp_f32_e32 v2, v2                                       // 0000003CE570: 7E044B02
	s_delay_alu instid0(TRANS32_DEP_2) | instid1(VALU_DEP_3)   // 0000003CE574: BF870186
	v_dual_add_f32 v5, 1.0, v5 :: v_dual_mul_f32 v4, 0xbfb8aa3b, v4// 0000003CE578: C9060AF2 050408FF BFB8AA3B
	v_div_scale_f32 v19, s0, 1.0, v3, 1.0                      // 0000003CE584: D6FC0013 03CA06F2
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003CE58C: BF870113
	v_rcp_f32_e32 v14, v7                                      // 0000003CE590: 7E1C5507
	v_div_scale_f32 v9, null, v5, v5, 1.0                      // 0000003CE594: D6FC7C09 03CA0B05
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_3)// 0000003CE59C: BF870393
	v_exp_f32_e32 v4, v4                                       // 0000003CE5A0: 7E084B04
	v_add_f32_e32 v2, 1.0, v2                                  // 0000003CE5A4: 060404F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_3)// 0000003CE5A8: BF870392
	v_rcp_f32_e32 v17, v9                                      // 0000003CE5AC: 7E225509
	v_fma_f32 v21, -v7, v14, 1.0                               // 0000003CE5B0: D6130015 23CA1D07
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(TRANS32_DEP_2)// 0000003CE5B8: BF870322
	v_div_scale_f32 v6, null, v2, v2, 1.0                      // 0000003CE5BC: D6FC7C06 03CA0502
	v_div_scale_f32 v18, vcc_lo, 1.0, v2, 1.0                  // 0000003CE5C4: D6FC6A12 03CA04F2
	v_add_f32_e32 v4, 1.0, v4                                  // 0000003CE5CC: 060808F2
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003CE5D0: BF870214
	v_fmac_f32_e32 v14, v21, v14                               // 0000003CE5D4: 561C1D15
	v_rcp_f32_e32 v11, v6                                      // 0000003CE5D8: 7E165506
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003CE5DC: BF870196
	v_fma_f32 v24, -v9, v17, 1.0                               // 0000003CE5E0: D6130018 23CA2309
	v_div_scale_f32 v8, null, v4, v4, 1.0                      // 0000003CE5E8: D6FC7C08 03CA0904
	v_div_scale_f32 v23, s1, 1.0, v4, 1.0                      // 0000003CE5F0: D6FC0117 03CA08F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 0000003CE5F8: BF870312
	v_rcp_f32_e32 v15, v8                                      // 0000003CE5FC: 7E1E5508
	v_fma_f32 v20, -v6, v11, 1.0                               // 0000003CE600: D6130014 23CA1706
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(TRANS32_DEP_1)// 0000003CE608: BF8702A1
	v_fmac_f32_e32 v11, v20, v11                               // 0000003CE60C: 56161714
	v_div_scale_f32 v20, s2, 1.0, v5, 1.0                      // 0000003CE610: D6FC0214 03CA0AF2
	v_fma_f32 v22, -v8, v15, 1.0                               // 0000003CE618: D6130016 23CA1F08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003CE620: BF870091
	v_dual_fmac_f32 v15, v22, v15 :: v_dual_mul_f32 v22, v19, v14// 0000003CE624: C8061F16 0F161D13
	v_dual_fmac_f32 v17, v24, v17 :: v_dual_mul_f32 v24, v23, v15// 0000003CE62C: C8062318 11181F17
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000003CE634: BF8701A2
	v_fma_f32 v27, -v7, v22, v19                               // 0000003CE638: D613001B 244E2D07
	v_mul_f32_e32 v21, v18, v11                                // 0000003CE640: 102A1712
	v_fma_f32 v28, -v8, v24, v23                               // 0000003CE644: D613001C 245E3108
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003CE64C: BF870193
	v_fmac_f32_e32 v22, v27, v14                               // 0000003CE650: 562C1D1B
	v_fma_f32 v26, -v6, v21, v18                               // 0000003CE654: D613001A 244A2B06
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003CE65C: BF870112
	v_fma_f32 v7, -v7, v22, v19                                // 0000003CE660: D6130007 244E2D07
	v_fmac_f32_e32 v21, v26, v11                               // 0000003CE668: 562A171A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003CE66C: BF870091
	v_fma_f32 v6, -v6, v21, v18                                // 0000003CE670: D6130006 244A2B06
	v_div_fmas_f32 v6, v6, v11, v21                            // 0000003CE678: D6370006 04561706
	s_mov_b32 vcc_lo, s0                                       // 0000003CE680: BEEA0000
	v_div_fmas_f32 v7, v7, v14, v22                            // 0000003CE684: D6370007 045A1D07
	s_mov_b32 vcc_lo, s1                                       // 0000003CE68C: BEEA0001
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003CE690: BF870112
	v_div_fixup_f32 v2, v6, v2, 1.0                            // 0000003CE694: D6270002 03CA0506
	v_div_fixup_f32 v3, v7, v3, 1.0                            // 0000003CE69C: D6270003 03CA0707
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003CE6A4: BF870092
	v_bfe_u32 v7, v2, 16, 1                                    // 0000003CE6A8: D6100007 02052102
	v_add3_u32 v2, v2, v7, 0x7fff                              // 0000003CE6B0: D6550002 03FE0F02 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003CE6BC: BF870091
	v_dual_mul_f32 v25, v20, v17 :: v_dual_and_b32 v2, 0xffff0000, v2// 0000003CE6C0: C8E42314 190204FF FFFF0000
	v_fma_f32 v29, -v9, v25, v20                               // 0000003CE6CC: D613001D 24523309
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003CE6D4: BF870091
	v_dual_fmac_f32 v24, v28, v15 :: v_dual_fmac_f32 v25, v29, v17// 0000003CE6D8: C8001F1C 1818231D
	v_fma_f32 v8, -v8, v24, v23                                // 0000003CE6E0: D6130008 245E3108
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003CE6E8: BF870112
	v_fma_f32 v9, -v9, v25, v20                                // 0000003CE6EC: D6130009 24523309
	v_div_fmas_f32 v6, v8, v15, v24                            // 0000003CE6F4: D6370006 04621F08
	s_mov_b32 vcc_lo, s2                                       // 0000003CE6FC: BEEA0002
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003CE700: BF870112
	v_div_fmas_f32 v8, v9, v17, v25                            // 0000003CE704: D6370008 04662309
	v_div_fixup_f32 v4, v6, v4, 1.0                            // 0000003CE70C: D6270004 03CA0906
	v_bfe_u32 v6, v3, 16, 1                                    // 0000003CE714: D6100006 02052103
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003CE71C: BF870193
	v_div_fixup_f32 v5, v8, v5, 1.0                            // 0000003CE720: D6270005 03CA0B08
	v_bfe_u32 v7, v4, 16, 1                                    // 0000003CE728: D6100007 02052104
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003CE730: BF870193
	v_add3_u32 v3, v3, v6, 0x7fff                              // 0000003CE734: D6550003 03FE0D03 00007FFF
	v_bfe_u32 v8, v5, 16, 1                                    // 0000003CE740: D6100008 02052105
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003CE748: BF870193
	v_add3_u32 v4, v4, v7, 0x7fff                              // 0000003CE74C: D6550004 03FE0F04 00007FFF
	v_and_b32_e32 v3, 0xffff0000, v3                           // 0000003CE758: 360606FF FFFF0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003CE760: BF870193
	v_add3_u32 v5, v5, v8, 0x7fff                              // 0000003CE764: D6550005 03FE1105 00007FFF
	v_and_b32_e32 v4, 0xffff0000, v4                           // 0000003CE770: 360808FF FFFF0000
	s_waitcnt vmcnt(3)                                         // 0000003CE778: BF890FF7
	v_lshlrev_b32_e32 v6, 16, v16                              // 0000003CE77C: 300C2090
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000003CE780: BF8700C1
	v_fma_f32 v2, v2, v6, 0                                    // 0000003CE784: D6130002 02020D02
	s_waitcnt vmcnt(2)                                         // 0000003CE78C: BF890BF7
	v_lshlrev_b32_e32 v6, 16, v12                              // 0000003CE790: 300C1890
	s_waitcnt vmcnt(1)                                         // 0000003CE794: BF8907F7
	v_dual_fmac_f32 v2, v3, v6 :: v_dual_lshlrev_b32 v7, 16, v13// 0000003CE798: C8220D03 02061A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000003CE7A0: BF8700B1
	v_dual_fmac_f32 v2, v4, v7 :: v_dual_and_b32 v3, 0xffff0000, v5// 0000003CE7A4: C8240F04 02020AFF FFFF0000
	s_waitcnt vmcnt(0)                                         // 0000003CE7B0: BF8903F7
	v_lshlrev_b32_e32 v4, 16, v10                              // 0000003CE7B4: 30081490
	v_fmac_f32_e32 v2, v3, v4                                  // 0000003CE7B8: 56040903
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003CE7BC: BF870001
	v_mul_f32_e32 v2, 0x3e800000, v2                           // 0000003CE7C0: 100404FF 3E800000
	s_cbranch_scc1 9                                           // 0000003CE7C8: BFA20009 <_ZN7halogen12_GLOBAL__N_17k_hcup8ILi1EEEvPKhPKtS5_PtPf+0x1df0>
	.long 0xd73c0003                                           // 0000003CE7CC: D73C0003
	v_cndmask_b32_e32 v1, 2, v36, vcc_lo                       // 0000003CE7D0: 02024882
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003CE7D4: BF870091
	.long 0xd7006a03                                           // 0000003CE7D8: D7006A03
	v_cndmask_b32_e32 v1, s4, v3, vcc_lo                       // 0000003CE7DC: 02020604
	v_add_co_ci_u32_e64 v4, null, s5, v4, vcc_lo               // 0000003CE7E0: D5207C04 01AA0805
	global_store_b32 v[3:4], v2, off                           // 0000003CE7E8: DC6A0000 007C0203
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003CE7F0: BF8700A1
	v_bfe_u32 v3, v2, 16, 1                                    // 0000003CE7F4: D6100003 02052102
	.long 0xd7006a00                                           // 0000003CE7FC: D7006A00
	v_cndmask_b32_e32 v1, s10, v0, vcc_lo                      // 0000003CE800: 0202000A
	v_add_co_ci_u32_e64 v1, null, s11, v1, vcc_lo              // 0000003CE804: D5207C01 01AA020B
	s_delay_alu instid0(VALU_DEP_3)                            // 0000003CE80C: BF870003
	v_add3_u32 v2, v2, v3, 0x7fff                              // 0000003CE810: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off                    // 0000003CE81C: DC960000 007C0200
	s_nop 0                                                    // 0000003CE824: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 0000003CE828: BFB60003
	s_endpgm                                                   // 0000003CE82C: BFB00000
		...

