00000000002f8000 <_ZN7halogen12_GLOBAL__N_110k_lq8w_grpILi5ELi32ELi2EEEvNS0_5LqGrpEPKtl>:
; _ZN7halogen12_GLOBAL__N_110k_lq8w_grpILi5ELi32ELi2EEEvNS0_5LqGrpEPKtl():
	s_clause 0x3                                               // 0000002F8000: BF850003
	s_load_b32 s3, s[0:1], 0x120                               // 0000002F8004: F40000C0 F8000120
	s_load_b32 s4, s[0:1], 0x88                                // 0000002F800C: F4000100 F8000088
	s_load_b32 s5, s[0:1], 0xd0                                // 0000002F8014: F4000140 F80000D0
	s_load_b32 s6, s[0:1], 0x118                               // 0000002F801C: F4000180 F8000118
	v_lshrrev_b32_e32 v3, 5, v0                                // 0000002F8024: 32060085
	v_dual_mov_b32 v16, 0 :: v_dual_and_b32 v15, 31, v0        // 0000002F8028: CA240080 100E009F
	v_mov_b32_e32 v25, 0                                       // 0000002F8030: 7E320280
	s_waitcnt lgkmcnt(0)                                       // 0000002F8034: BF89FC07
	s_cmp_gt_i32 s3, 1                                         // 0000002F8038: BF028103
	s_cselect_b32 s7, -1, 0                                    // 0000002F803C: 980780C1
	s_cmp_ge_i32 s2, s4                                        // 0000002F8040: BF030402
	s_cselect_b32 s4, -1, 0                                    // 0000002F8044: 980480C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002F8048: BF870009
	s_and_b32 s4, s7, s4                                       // 0000002F804C: 8B040407
	s_cmp_gt_i32 s3, 2                                         // 0000002F8050: BF028203
	v_cndmask_b32_e64 v1, 0, 1, s4                             // 0000002F8054: D5010001 00110280
	s_cselect_b32 s7, -1, 0                                    // 0000002F805C: 980780C1
	s_cmp_ge_i32 s2, s5                                        // 0000002F8060: BF030502
	s_cselect_b32 s5, -1, 0                                    // 0000002F8064: 980580C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002F8068: BF870009
	s_and_b32 s4, s7, s5                                       // 0000002F806C: 8B040507
	s_cmp_gt_i32 s3, 3                                         // 0000002F8070: BF028303
	v_readfirstlane_b32 s5, v1                                 // 0000002F8074: 7E0A0501
	s_cselect_b32 s3, -1, 0                                    // 0000002F8078: 980380C1
	s_cmp_ge_i32 s2, s6                                        // 0000002F807C: BF030602
	s_cselect_b32 s6, -1, 0                                    // 0000002F8080: 980680C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002F8084: BF870009
	s_and_b32 s3, s3, s6                                       // 0000002F8088: 8B030603
	s_and_b32 s4, s4, exec_lo                                  // 0000002F808C: 8B047E04
	s_cselect_b32 s4, 2, s5                                    // 0000002F8090: 98040582
	s_and_b32 s3, s3, exec_lo                                  // 0000002F8094: 8B037E03
	s_cselect_b32 s3, 3, s4                                    // 0000002F8098: 98030483
	s_load_b128 s[4:7], s[0:1], 0x128                          // 0000002F809C: F4080100 F8000128
	s_mulk_i32 s3, 0x48                                        // 0000002F80A4: B8030048
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002F80A8: BF870009
	s_add_u32 s10, s0, s3                                      // 0000002F80AC: 800A0300
	s_addc_u32 s11, s1, 0                                      // 0000002F80B0: 820B8001
	s_clause 0x1                                               // 0000002F80B4: BF850001
	s_load_b64 s[8:9], s[10:11], 0x30                          // 0000002F80B8: F4040205 F8000030
	s_load_b32 s12, s[10:11], 0x40                             // 0000002F80C0: F4000305 F8000040
	s_waitcnt lgkmcnt(0)                                       // 0000002F80C8: BF89FC07
	.long 0xd451000e                                           // 0000002F80CC: D451000E
	v_cndmask_b32_e32 v0, s8, v137, vcc_lo                     // 0000002F80D0: 02011208
	s_and_b32 s0, s14, exec_lo                                 // 0000002F80D4: 8B007E0E
	s_cselect_b32 s1, 8, 2                                     // 0000002F80D8: 98018288
	s_cselect_b32 s3, 3, 1                                     // 0000002F80DC: 98038183
	v_cvt_f32_ubyte0_e32 v1, s1                                // 0000002F80E0: 7E022201
	s_sub_i32 s12, s2, s12                                     // 0000002F80E4: 818C0C02
	s_add_i32 s0, s1, -1                                       // 0000002F80E8: 8100C101
	s_ashr_i32 s13, s12, 31                                    // 0000002F80EC: 860D9F0C
	s_and_b32 s15, s14, exec_lo                                // 0000002F80F0: 8B0F7E0E
	v_rcp_iflag_f32_e32 v1, v1                                 // 0000002F80F4: 7E025701
	s_cselect_b32 s15, 0, 2                                    // 0000002F80F8: 980F8280
	s_ashr_i32 s16, s7, 31                                     // 0000002F80FC: 86109F07
	s_lshl_b64 s[12:13], s[12:13], s15                         // 0000002F8100: 848C0F0C
	s_lshr_b32 s16, s16, 28                                    // 0000002F8104: 85109C10
	v_lshrrev_b32_e32 v13, s3, v3                              // 0000002F8108: 321A0603
	s_add_u32 s16, s6, s16                                     // 0000002F810C: 80101006
	s_addc_u32 s17, s7, 0                                      // 0000002F8110: 82118007
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002F8114: BF870299
	s_ashr_i64 s[16:17], s[16:17], 4                           // 0000002F8118: 86908410
	v_readfirstlane_b32 s18, v1                                // 0000002F811C: 7E240501
	s_add_u32 s20, s16, s6                                     // 0000002F8120: 80140610
	s_addc_u32 s17, s17, s7                                    // 0000002F8124: 82110711
	s_sub_i32 s19, 0, s1                                       // 0000002F8128: 81930180
	s_add_i32 s21, s0, s16                                     // 0000002F812C: 81151000
	s_mul_f32 s18, s18, 0x4f7ffffe                             // 0000002F8130: A212FF12 4F7FFFFE
	s_abs_i32 s22, s21                                         // 0000002F8138: BE961515
	.long 0xd7000c01                                           // 0000002F813C: D7000C01
	v_cndmask_b32_e32 v1, s12, v13, vcc_lo                     // 0000002F8140: 02021A0C
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000002F8144: BF8704B9
	s_cvt_u32_f32 s18, s18                                     // 0000002F8148: BE926712
	v_add_co_ci_u32_e64 v2, null, s13, 0, s12                  // 0000002F814C: D5207C02 0031000D
	s_ashr_i32 s13, s21, 31                                    // 0000002F8154: 860D9F15
	s_mul_i32 s19, s19, s18                                    // 0000002F8158: 96131213
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002F815C: BF870009
	s_mul_hi_u32 s19, s18, s19                                 // 0000002F8160: 96931312
	v_cmp_gt_i64_e32 vcc_lo, s[8:9], v[1:2]                    // 0000002F8164: 7CA80208
	s_add_i32 s23, s18, s19                                    // 0000002F8168: 81171312
	s_load_b64 s[18:19], s[10:11], null                        // 0000002F816C: F4040485 F8000000
	s_mul_hi_u32 s23, s22, s23                                 // 0000002F8174: 96971716
	v_and_b32_e32 v14, s0, v3                                  // 0000002F8178: 361C0600
	s_mul_i32 s12, s23, s1                                     // 0000002F817C: 960C0117
	s_add_i32 s21, s23, 1                                      // 0000002F8180: 81158117
	s_sub_i32 s12, s22, s12                                    // 0000002F8184: 818C0C16
	v_cndmask_b32_e32 v2, 0, v2, vcc_lo                        // 0000002F8188: 02040480
	s_sub_i32 s22, s12, s1                                     // 0000002F818C: 8196010C
	s_cmp_ge_u32 s12, s1                                       // 0000002F8190: BF09010C
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 0000002F8194: 02020280
	s_cselect_b32 s21, s21, s23                                // 0000002F8198: 98151715
	s_cselect_b32 s12, s22, s12                                // 0000002F819C: 980C0C16
	s_add_i32 s22, s21, 1                                      // 0000002F81A0: 81168115
	s_cmp_ge_u32 s12, s1                                       // 0000002F81A4: BF09010C
	.long 0xd72c0004                                           // 0000002F81A8: D72C0004
	v_cndmask_b32_e32 v0, v2, v20, vcc_lo                      // 0000002F81AC: 02002902
	s_cselect_b32 s0, s22, s21                                 // 0000002F81B0: 98001516
	.long 0xd72c0006                                           // 0000002F81B4: D72C0006
	v_cndmask_b32_e32 v0, v1, v17, vcc_lo                      // 0000002F81B8: 02002301
	s_xor_b32 s0, s0, s13                                      // 0000002F81BC: 8D000D00
	v_mov_b32_e32 v2, 0                                        // 0000002F81C0: 7E040280
	s_sub_i32 s0, s0, s13                                      // 0000002F81C4: 81800D00
	s_waitcnt lgkmcnt(0)                                       // 0000002F81C8: BF89FC07
	v_mad_u64_u32 v[9:10], null, v1, s20, s[18:19]             // 0000002F81CC: D6FE7C09 00482901
	.long 0xd72c0005                                           // 0000002F81D4: D72C0005
	v_cndmask_b32_e32 v0, v14, v0, vcc_lo                      // 0000002F81D8: 0200010E
	v_mov_b32_e32 v1, 0                                        // 0000002F81DC: 7E020280
	v_mov_b32_e32 v3, 0                                        // 0000002F81E0: 7E060280
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002F81E4: BF870214
	v_add3_u32 v10, v4, v10, v6                                // 0000002F81E8: D655000A 041A1504
	v_dual_mov_b32 v4, 0 :: v_dual_add_nc_u32 v7, s0, v5       // 0000002F81F0: CA200080 04060A00
	v_add_nc_u32_e32 v17, v5, v15                              // 0000002F81F8: 4A221F05
	.long 0xd7006a13                                           // 0000002F81FC: D7006A13
	v_cndmask_b32_e32 v0, v9, v6, vcc_lo                       // 0000002F8200: 02000D09
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002F8204: BF870123
	v_min_i32_e32 v18, s16, v7                                 // 0000002F8208: 22240E10
	v_add_co_ci_u32_e64 v20, null, s7, v10, vcc_lo             // 0000002F820C: D5207C14 01AA1407
	v_cmp_lt_i32_e32 vcc_lo, v17, v18                          // 0000002F8214: 7C822511
	s_and_saveexec_b32 s12, vcc_lo                             // 0000002F8218: BE8C206A
	s_cbranch_execz 19                                         // 0000002F821C: BFA50013 <_ZN7halogen12_GLOBAL__N_110k_lq8w_grpILi5ELi32ELi2EEEvNS0_5LqGrpEPKtl+0x26c>
	v_lshlrev_b32_e32 v1, 4, v17                               // 0000002F8220: 30022284
	v_and_b32_e32 v3, -4, v17                                  // 0000002F8224: 360622C4
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002F8228: BF870112
	v_ashrrev_i32_e32 v2, 31, v1                               // 0000002F822C: 3404029F
	v_ashrrev_i32_e32 v4, 31, v3                               // 0000002F8230: 3408069F
	.long 0xd7000001                                           // 0000002F8234: D7000001
	v_cndmask_b32_e32 v1, v9, v1, vcc_lo                       // 0000002F8238: 02020309
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002F823C: BF8700A1
	v_add_co_ci_u32_e64 v2, null, v10, v2, s0                  // 0000002F8240: D5207C02 0002050A
	.long 0xd7000006                                           // 0000002F8248: D7000006
	v_cndmask_b32_e32 v1, v19, v3, vcc_lo                      // 0000002F824C: 02020713
	v_add_co_ci_u32_e64 v7, null, v20, v4, s0                  // 0000002F8250: D5207C07 00020914
	s_clause 0x1                                               // 0000002F8258: BF850001
	global_load_b128 v[1:4], v[1:2], off                       // 0000002F825C: DC5E0000 017C0001
	global_load_b32 v25, v[6:7], off                           // 0000002F8264: DC520000 197C0006
	s_or_b32 exec_lo, exec_lo, s12                             // 0000002F826C: 8C7E0C7E
	v_dual_mov_b32 v22, 0 :: v_dual_mov_b32 v23, 0             // 0000002F8270: CA100080 16160080
	v_dual_mov_b32 v24, 0 :: v_dual_mov_b32 v21, 0             // 0000002F8278: CA100080 18140080
	s_and_saveexec_b32 s16, vcc_lo                             // 0000002F8280: BE90206A
	s_cbranch_execz 378                                        // 0000002F8284: BFA5017A <_ZN7halogen12_GLOBAL__N_110k_lq8w_grpILi5ELi32ELi2EEEvNS0_5LqGrpEPKtl+0x870>
	v_dual_mov_b32 v21, 0 :: v_dual_lshlrev_b32 v6, 4, v15     // 0000002F8288: CA220080 15061E84
	v_dual_mov_b32 v24, 0 :: v_dual_mov_b32 v23, 0             // 0000002F8290: CA100080 18160080
	v_mov_b32_e32 v22, 0                                       // 0000002F8298: 7E2C0280
	s_delay_alu instid0(VALU_DEP_3)                            // 0000002F829C: BF870003
	v_lshl_add_u32 v11, v5, 4, v6                              // 0000002F82A0: D646000B 04190905
	v_mov_b32_e32 v16, 0                                       // 0000002F82A8: 7E200280
	s_mul_i32 s0, s7, 6                                        // 0000002F82AC: 96008607
	s_mul_hi_u32 s17, s6, 6                                    // 0000002F82B0: 96918606
	s_lshl_b64 s[12:13], s[6:7], 2                             // 0000002F82B4: 848C8206
	s_add_i32 s17, s17, s0                                     // 0000002F82B8: 81110011
	s_mul_i32 s19, s6, 6                                       // 0000002F82BC: 96138606
	s_mov_b32 s18, 0                                           // 0000002F82C0: BE920080
	s_lshl_b64 s[6:7], s[6:7], 1                               // 0000002F82C4: 84868106
	s_branch 323                                               // 0000002F82C8: BFA00143 <_ZN7halogen12_GLOBAL__N_110k_lq8w_grpILi5ELi32ELi2EEEvNS0_5LqGrpEPKtl+0x7d8>
	s_or_b32 exec_lo, exec_lo, s20                             // 0000002F82CC: 8C7E147E
	v_ashrrev_i32_e32 v12, 31, v11                             // 0000002F82D0: 3418169F
	v_cvt_f32_ubyte1_e32 v68, v1                               // 0000002F82D4: 7E882501
	v_cvt_f32_ubyte2_e32 v69, v1                               // 0000002F82D8: 7E8A2701
	v_cvt_f32_ubyte3_e32 v70, v1                               // 0000002F82DC: 7E8C2901
	v_cvt_f32_ubyte0_e32 v71, v2                               // 0000002F82E0: 7E8E2302
	.long 0xd73c000b                                           // 0000002F82E4: D73C000B
	v_cndmask_b32_e32 v1, 1, v11, vcc_lo                       // 0000002F82E8: 02021681
	v_cvt_f32_ubyte1_e32 v72, v2                               // 0000002F82EC: 7E902502
	v_cvt_f32_ubyte2_e32 v73, v2                               // 0000002F82F0: 7E922702
	v_cvt_f32_ubyte3_e32 v74, v2                               // 0000002F82F4: 7E942902
	s_waitcnt vmcnt(1)                                         // 0000002F82F8: BF8907F7
	v_mov_b32_e32 v2, v6                                       // 0000002F82FC: 7E040306
	v_cvt_f32_ubyte0_e32 v75, v3                               // 0000002F8300: 7E962303
	.long 0xd700000b                                           // 0000002F8304: D700000B
	v_cndmask_b32_e32 v1, s4, v11, vcc_lo                      // 0000002F8308: 02021604
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000002F830C: BF8701A1
	v_add_co_ci_u32_e64 v12, null, s5, v12, s0                 // 0000002F8310: D5207C0C 00021805
	v_cvt_f32_ubyte1_e32 v76, v3                               // 0000002F8318: 7E982503
	.long 0xd7000034                                           // 0000002F831C: D7000034
	v_cndmask_b32_e32 v0, v11, v6, vcc_lo                      // 0000002F8320: 02000D0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002F8324: BF8700A1
	v_add_co_ci_u32_e64 v53, null, s7, v12, s0                 // 0000002F8328: D5207C35 00021807
	.long 0xd7000038                                           // 0000002F8330: D7000038
	v_cndmask_b32_e32 v0, v11, v12, vcc_lo                     // 0000002F8334: 0200190B
	v_add_co_ci_u32_e64 v57, null, s13, v12, s0                // 0000002F8338: D5207C39 0002180D
	.long 0xd700003c                                           // 0000002F8340: D700003C
	v_cndmask_b32_e32 v0, v11, v19, vcc_lo                     // 0000002F8344: 0200270B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002F8348: BF870211
	v_add_co_ci_u32_e64 v61, null, s17, v12, s0                // 0000002F834C: D5207C3D 00021811
	.long 0xd7000040                                           // 0000002F8354: D7000040
	v_cndmask_b32_e32 v0, v56, v12, vcc_lo                     // 0000002F8358: 02001938
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002F835C: BF870001
	v_add_co_ci_u32_e64 v65, null, s13, v57, s0                // 0000002F8360: D5207C41 0002720D
	s_clause 0x9                                               // 0000002F8368: BF850009
	global_load_b128 v[28:31], v[11:12], off                   // 0000002F836C: DC5E0000 1C7C000B
	global_load_b128 v[32:35], v[52:53], off                   // 0000002F8374: DC5E0000 207C0034
	global_load_b128 v[36:39], v[56:57], off                   // 0000002F837C: DC5E0000 247C0038
	global_load_b128 v[40:43], v[60:61], off                   // 0000002F8384: DC5E0000 287C003C
	global_load_b128 v[44:47], v[64:65], off                   // 0000002F838C: DC5E0000 2C7C0040
	global_load_b128 v[48:51], v[11:12], off offset:16         // 0000002F8394: DC5E0010 307C000B
	global_load_b128 v[52:55], v[52:53], off offset:16         // 0000002F839C: DC5E0010 347C0034
	global_load_b128 v[56:59], v[56:57], off offset:16         // 0000002F83A4: DC5E0010 387C0038
	global_load_b128 v[60:63], v[60:61], off offset:16         // 0000002F83AC: DC5E0010 3C7C003C
	global_load_b128 v[64:67], v[64:65], off offset:16         // 0000002F83B4: DC5E0010 407C0040
	v_cvt_f32_ubyte0_e32 v11, v1                               // 0000002F83BC: 7E162301
	v_mov_b32_e32 v1, v5                                       // 0000002F83C0: 7E020305
	v_cvt_f32_ubyte2_e32 v77, v3                               // 0000002F83C4: 7E9A2703
	v_cvt_f32_ubyte3_e32 v78, v3                               // 0000002F83C8: 7E9C2903
	v_cvt_f32_ubyte0_e32 v79, v4                               // 0000002F83CC: 7E9E2304
	v_fma_mix_f32 v5, v11, v25, v25 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002F83D0: CC206005 1466330B
	v_cvt_f32_ubyte1_e32 v80, v4                               // 0000002F83D8: 7EA02504
	v_cvt_f32_ubyte2_e32 v81, v4                               // 0000002F83DC: 7EA22704
	v_cvt_f32_ubyte3_e32 v82, v4                               // 0000002F83E0: 7EA42904
	v_dual_mov_b32 v4, v8 :: v_dual_mov_b32 v3, v7             // 0000002F83E4: CA100108 04020107
	v_fma_mix_f32 v6, v68, v25, v25 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002F83EC: CC206006 14663344
	v_fma_mix_f32 v7, v69, v25, v25 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002F83F4: CC206007 14663345
	v_mov_b32_e32 v11, v27                                     // 0000002F83FC: 7E16031B
	v_bfe_u32 v27, v5, 16, 1                                   // 0000002F8400: D610001B 02052105
	v_fma_mix_f32 v68, v70, v25, v25 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002F8408: CC206044 14663346
	v_fma_mix_f32 v69, v71, v25, v25 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002F8410: CC206045 14663347
	v_fma_mix_f32 v70, v72, v25, v25 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002F8418: CC206046 14663348
	v_fma_mix_f32 v71, v73, v25, v25 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002F8420: CC206047 14663349
	v_fma_mix_f32 v73, v74, v25, v25 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002F8428: CC206049 1466334A
	v_fma_mix_f32 v74, v75, v25, v25 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002F8430: CC20604A 1466334B
	v_fma_mix_f32 v75, v76, v25, v25 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002F8438: CC20604B 1466334C
	v_fma_mix_f32 v76, v77, v25, v25 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002F8440: CC20604C 1466334D
	v_fma_mix_f32 v78, v78, v25, v25 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002F8448: CC20604E 1466334E
	v_fma_mix_f32 v79, v79, v25, v25 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002F8450: CC20604F 1466334F
	v_fma_mix_f32 v80, v80, v25, v25 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002F8458: CC206050 14663350
	v_fma_mix_f32 v81, v81, v25, v25 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002F8460: CC206051 14663351
	v_fma_mix_f32 v25, v82, v25, v25 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002F8468: CC206019 14663352
	v_bfe_u32 v82, v6, 16, 1                                   // 0000002F8470: D6100052 02052106
	v_bfe_u32 v84, v7, 16, 1                                   // 0000002F8478: D6100054 02052107
	v_add3_u32 v5, v5, v27, 0x7fff                             // 0000002F8480: D6550005 03FE3705 00007FFF
	.long 0x7f183880                                           // 0000002F848C: 7F183880
	v_bfe_u32 v85, v68, 16, 1                                  // 0000002F8490: D6100055 02052144
	v_bfe_u32 v86, v69, 16, 1                                  // 0000002F8498: D6100056 02052145
	v_add3_u32 v6, v6, v82, 0x7fff                             // 0000002F84A0: D6550006 03FEA506 00007FFF
	v_add3_u32 v7, v7, v84, 0x7fff                             // 0000002F84AC: D6550007 03FEA907 00007FFF
	.long 0x7e183985                                           // 0000002F84B8: 7E183985
	.long 0x7f10398c                                           // 0000002F84BC: 7F10398C
	v_bfe_u32 v87, v70, 16, 1                                  // 0000002F84C0: D6100057 02052146
	v_bfe_u32 v88, v71, 16, 1                                  // 0000002F84C8: D6100058 02052147
	v_add3_u32 v27, v68, v85, 0x7fff                           // 0000002F84D0: D655001B 03FEAB44 00007FFF
	v_add3_u32 v68, v69, v86, 0x7fff                           // 0000002F84DC: D6550044 03FEAD45 00007FFF
	v_and_or_b32 v6, 0xffff0000, v6, v12                       // 0000002F84E8: D6570006 04320CFF FFFF0000
	.long 0x7e103987                                           // 0000002F84F4: 7E103987
	v_bfe_u32 v89, v73, 16, 1                                  // 0000002F84F8: D6100059 02052149
	v_bfe_u32 v90, v74, 16, 1                                  // 0000002F8500: D610005A 0205214A
	v_add3_u32 v69, v70, v87, 0x7fff                           // 0000002F8508: D6550045 03FEAF46 00007FFF
	v_add3_u32 v70, v71, v88, 0x7fff                           // 0000002F8514: D6550046 03FEB147 00007FFF
	.long 0x7e1839c4                                           // 0000002F8520: 7E1839C4
	v_and_or_b32 v7, 0xffff0000, v27, v8                       // 0000002F8524: D6570007 042236FF FFFF0000
	.long 0x7f90398c                                           // 0000002F8530: 7F90398C
	v_bfe_u32 v91, v75, 16, 1                                  // 0000002F8534: D610005B 0205214B
	v_bfe_u32 v92, v76, 16, 1                                  // 0000002F853C: D610005C 0205214C
	v_add3_u32 v71, v73, v89, 0x7fff                           // 0000002F8544: D6550047 03FEB349 00007FFF
	v_add3_u32 v5, v74, v90, 0x7fff                            // 0000002F8550: D6550005 03FEB54A 00007FFF
	v_and_or_b32 v69, 0xffff0000, v69, v12                     // 0000002F855C: D6570045 04328AFF FFFF0000
	.long 0x7e9039c6                                           // 0000002F8568: 7E9039C6
	v_bfe_u32 v93, v78, 16, 1                                  // 0000002F856C: D610005D 0205214E
	v_bfe_u32 v94, v79, 16, 1                                  // 0000002F8574: D610005E 0205214F
	v_add3_u32 v73, v75, v91, 0x7fff                           // 0000002F857C: D6550049 03FEB74B 00007FFF
	v_add3_u32 v74, v76, v92, 0x7fff                           // 0000002F8588: D655004A 03FEB94C 00007FFF
	.long 0x7e183985                                           // 0000002F8594: 7E183985
	v_and_or_b32 v8, 0xffff0000, v71, v72                      // 0000002F8598: D6570008 05228EFF FFFF0000
	.long 0x7f9a398c                                           // 0000002F85A4: 7F9A398C
	v_bfe_u32 v95, v80, 16, 1                                  // 0000002F85A8: D610005F 02052150
	v_bfe_u32 v96, v81, 16, 1                                  // 0000002F85B0: D6100060 02052151
	v_add3_u32 v75, v78, v93, 0x7fff                           // 0000002F85B8: D655004B 03FEBB4E 00007FFF
	v_add3_u32 v68, v79, v94, 0x7fff                           // 0000002F85C4: D6550044 03FEBD4F 00007FFF
	.long 0x7e9a39ca                                           // 0000002F85D0: 7E9A39CA
	v_and_or_b32 v5, 0xffff0000, v73, v12                      // 0000002F85D4: D6570005 043292FF FFFF0000
	v_bfe_u32 v97, v25, 16, 1                                  // 0000002F85E0: D6100061 02052119
	v_add3_u32 v76, v80, v95, 0x7fff                           // 0000002F85E8: D655004C 03FEBF50 00007FFF
	v_add3_u32 v78, v81, v96, 0x7fff                           // 0000002F85F4: D655004E 03FEC151 00007FFF
	.long 0x7e1839c4                                           // 0000002F8600: 7E1839C4
	v_and_or_b32 v27, 0xffff0000, v75, v77                     // 0000002F8604: D657001B 053696FF FFFF0000
	.long 0x7fa6398c                                           // 0000002F8610: 7FA6398C
	v_add3_u32 v25, v25, v97, 0x7fff                           // 0000002F8614: D6550019 03FEC319 00007FFF
	.long 0x7ea639ce                                           // 0000002F8620: 7EA639CE
	v_and_or_b32 v12, 0xffff0000, v76, v12                     // 0000002F8624: D657000C 043298FF FFFF0000
	s_and_b32 s0, exec_lo, vcc_lo                              // 0000002F8630: 8B006A7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002F8634: BF870119
	s_or_b32 s18, s0, s18                                      // 0000002F8638: 8C121200
	v_and_or_b32 v25, 0xffff0000, v25, v83                     // 0000002F863C: D6570019 054E32FF FFFF0000
	s_waitcnt vmcnt(9)                                         // 0000002F8648: BF8927F7
	v_dot2_f32_bf16 v28, v28, v6, 0                            // 0000002F864C: CC1A401C 1A020D1C
	s_waitcnt vmcnt(8)                                         // 0000002F8654: BF8923F7
	v_dot2_f32_bf16 v32, v32, v6, 0                            // 0000002F8658: CC1A4020 1A020D20
	s_waitcnt vmcnt(7)                                         // 0000002F8660: BF891FF7
	v_dot2_f32_bf16 v36, v36, v6, 0                            // 0000002F8664: CC1A4024 1A020D24
	s_waitcnt vmcnt(6)                                         // 0000002F866C: BF891BF7
	v_dot2_f32_bf16 v40, v40, v6, 0                            // 0000002F8670: CC1A4028 1A020D28
	s_waitcnt vmcnt(5)                                         // 0000002F8678: BF8917F7
	v_dot2_f32_bf16 v6, v44, v6, 0                             // 0000002F867C: CC1A4006 1A020D2C
	v_dot2_f32_bf16 v28, v29, v7, v28                          // 0000002F8684: CC1A401C 1C720F1D
	v_dot2_f32_bf16 v29, v33, v7, v32                          // 0000002F868C: CC1A401D 1C820F21
	v_dot2_f32_bf16 v32, v37, v7, v36                          // 0000002F8694: CC1A4020 1C920F25
	v_dot2_f32_bf16 v33, v41, v7, v40                          // 0000002F869C: CC1A4021 1CA20F29
	v_dot2_f32_bf16 v6, v45, v7, v6                            // 0000002F86A4: CC1A4006 1C1A0F2D
	v_dot2_f32_bf16 v7, v30, v69, v28                          // 0000002F86AC: CC1A4007 1C728B1E
	v_dot2_f32_bf16 v28, v34, v69, v29                         // 0000002F86B4: CC1A401C 1C768B22
	v_dot2_f32_bf16 v29, v38, v69, v32                         // 0000002F86BC: CC1A401D 1C828B26
	v_dot2_f32_bf16 v30, v42, v69, v33                         // 0000002F86C4: CC1A401E 1C868B2A
	v_dot2_f32_bf16 v6, v46, v69, v6                           // 0000002F86CC: CC1A4006 1C1A8B2E
	v_dot2_f32_bf16 v7, v31, v8, v7                            // 0000002F86D4: CC1A4007 1C1E111F
	v_dot2_f32_bf16 v28, v35, v8, v28                          // 0000002F86DC: CC1A401C 1C721123
	v_dot2_f32_bf16 v29, v39, v8, v29                          // 0000002F86E4: CC1A401D 1C761127
	v_dot2_f32_bf16 v30, v43, v8, v30                          // 0000002F86EC: CC1A401E 1C7A112B
	v_dot2_f32_bf16 v6, v47, v8, v6                            // 0000002F86F4: CC1A4006 1C1A112F
	s_waitcnt vmcnt(4)                                         // 0000002F86FC: BF8913F7
	v_dot2_f32_bf16 v7, v48, v5, v7                            // 0000002F8700: CC1A4007 1C1E0B30
	s_waitcnt vmcnt(3)                                         // 0000002F8708: BF890FF7
	v_dot2_f32_bf16 v8, v52, v5, v28                           // 0000002F870C: CC1A4008 1C720B34
	s_waitcnt vmcnt(2)                                         // 0000002F8714: BF890BF7
	v_dot2_f32_bf16 v28, v56, v5, v29                          // 0000002F8718: CC1A401C 1C760B38
	s_waitcnt vmcnt(1)                                         // 0000002F8720: BF8907F7
	v_dot2_f32_bf16 v29, v60, v5, v30                          // 0000002F8724: CC1A401D 1C7A0B3C
	s_waitcnt vmcnt(0)                                         // 0000002F872C: BF8903F7
	v_dot2_f32_bf16 v5, v64, v5, v6                            // 0000002F8730: CC1A4005 1C1A0B40
	v_dot2_f32_bf16 v6, v49, v27, v7                           // 0000002F8738: CC1A4006 1C1E3731
	v_dot2_f32_bf16 v7, v53, v27, v8                           // 0000002F8740: CC1A4007 1C223735
	v_dot2_f32_bf16 v8, v57, v27, v28                          // 0000002F8748: CC1A4008 1C723739
	v_dot2_f32_bf16 v28, v61, v27, v29                         // 0000002F8750: CC1A401C 1C76373D
	v_dot2_f32_bf16 v5, v65, v27, v5                           // 0000002F8758: CC1A4005 1C163741
	v_dot2_f32_bf16 v6, v50, v12, v6                           // 0000002F8760: CC1A4006 1C1A1932
	v_dot2_f32_bf16 v7, v54, v12, v7                           // 0000002F8768: CC1A4007 1C1E1936
	v_dot2_f32_bf16 v8, v58, v12, v8                           // 0000002F8770: CC1A4008 1C22193A
	v_dot2_f32_bf16 v27, v62, v12, v28                         // 0000002F8778: CC1A401B 1C72193E
	v_dot2_f32_bf16 v5, v66, v12, v5                           // 0000002F8780: CC1A4005 1C161942
	v_dot2_f32_bf16 v6, v51, v25, v6                           // 0000002F8788: CC1A4006 1C1A3333
	v_dot2_f32_bf16 v7, v55, v25, v7                           // 0000002F8790: CC1A4007 1C1E3337
	v_dot2_f32_bf16 v8, v59, v25, v8                           // 0000002F8798: CC1A4008 1C22333B
	v_dot2_f32_bf16 v12, v63, v25, v27                         // 0000002F87A0: CC1A400C 1C6E333F
	v_dot2_f32_bf16 v5, v67, v25, v5                           // 0000002F87A8: CC1A4005 1C163343
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002F87B0: BF870214
	v_dual_add_f32 v21, v21, v6 :: v_dual_add_f32 v24, v24, v7 // 0000002F87B4: C9080D15 15180F18
	v_add_f32_e32 v23, v23, v8                                 // 0000002F87BC: 062E1117
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002F87C0: BF870214
	v_add_f32_e32 v22, v22, v12                                // 0000002F87C4: 062C1916
	v_dual_add_f32 v16, v16, v5 :: v_dual_mov_b32 v25, v26     // 0000002F87C8: C9100B10 1018011A
	s_and_not1_b32 exec_lo, exec_lo, s18                       // 0000002F87D0: 917E127E
	s_cbranch_execz 37                                         // 0000002F87D4: BFA50025 <_ZN7halogen12_GLOBAL__N_110k_lq8w_grpILi5ELi32ELi2EEEvNS0_5LqGrpEPKtl+0x86c>
	v_add_nc_u32_e32 v17, 32, v17                              // 0000002F87D8: 4A2222A0
	v_add_nc_u32_e32 v27, 0x200, v11                           // 0000002F87DC: 4A3616FF 00000200
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000002F87E4: BF8704A2
	v_cmp_ge_i32_e32 vcc_lo, v17, v18                          // 0000002F87E8: 7C8C2511
	s_and_saveexec_b32 s0, vcc_lo                              // 0000002F87EC: BE80206A
	s_xor_b32 s0, exec_lo, s0                                  // 0000002F87F0: 8D00007E
	v_add_nc_u32_e32 v27, 0x200, v11                           // 0000002F87F4: 4A3616FF 00000200
	s_or_saveexec_b32 s20, s0                                  // 0000002F87FC: BE942200
	s_waitcnt vmcnt(0)                                         // 0000002F8800: BF8903F7
	v_dual_mov_b32 v26, v25 :: v_dual_mov_b32 v7, v3           // 0000002F8804: CA100119 1A060103
	v_dual_mov_b32 v5, v1 :: v_dual_mov_b32 v6, v2             // 0000002F880C: CA100101 05060102
	v_mov_b32_e32 v8, v4                                       // 0000002F8814: 7E100304
	s_xor_b32 exec_lo, exec_lo, s20                            // 0000002F8818: 8D7E147E
	s_cbranch_execz 65195                                      // 0000002F881C: BFA5FEAB <_ZN7halogen12_GLOBAL__N_110k_lq8w_grpILi5ELi32ELi2EEEvNS0_5LqGrpEPKtl+0x2cc>
	v_and_b32_e32 v7, -4, v17                                  // 0000002F8820: 360E22C4
	v_ashrrev_i32_e32 v6, 31, v27                              // 0000002F8824: 340C369F
	.long 0xd7000005                                           // 0000002F8828: D7000005
	v_cndmask_b32_e32 v1, v9, v27, vcc_lo                      // 0000002F882C: 02023709
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002F8830: BF870193
	v_ashrrev_i32_e32 v8, 31, v7                               // 0000002F8834: 34100E9F
	v_add_co_ci_u32_e64 v6, null, v10, v6, s0                  // 0000002F8838: D5207C06 00020D0A
	.long 0xd700001c                                           // 0000002F8840: D700001C
	v_cndmask_b32_e32 v1, v19, v7, vcc_lo                      // 0000002F8844: 02020F13
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002F8848: BF870001
	v_add_co_ci_u32_e64 v29, null, v20, v8, s0                 // 0000002F884C: D5207C1D 00021114
	s_clause 0x1                                               // 0000002F8854: BF850001
	global_load_b128 v[5:8], v[5:6], off                       // 0000002F8858: DC5E0000 057C0005
	global_load_b32 v26, v[28:29], off                         // 0000002F8860: DC520000 1A7C001C
	s_branch 65176                                             // 0000002F8868: BFA0FE98 <_ZN7halogen12_GLOBAL__N_110k_lq8w_grpILi5ELi32ELi2EEEvNS0_5LqGrpEPKtl+0x2cc>
	s_or_b32 exec_lo, exec_lo, s18                             // 0000002F886C: 8C7E127E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000002F8870: BF8700C9
	s_or_b32 exec_lo, exec_lo, s16                             // 0000002F8874: 8C7E107E
	s_waitcnt vmcnt(1)                                         // 0000002F8878: BF8907F7
	.long 0xd71f0001                                           // 0000002F887C: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000002F8880: 020100C1
	s_mov_b32 s0, exec_lo                                      // 0000002F8884: BE80007E
	v_xor_b32_e32 v2, 16, v1                                   // 0000002F8888: 3A040290
	v_xor_b32_e32 v7, 8, v1                                    // 0000002F888C: 3A0E0288
	v_xor_b32_e32 v12, 4, v1                                   // 0000002F8890: 3A180284
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000002F8894: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 0000002F8898: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 0000002F889C: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v7                            // 0000002F88A0: 7C980EA0
	v_cndmask_b32_e32 v7, v1, v7, vcc_lo                       // 0000002F88A4: 020E0F01
	v_cmp_gt_u32_e32 vcc_lo, 32, v12                           // 0000002F88A8: 7C9818A0
	s_delay_alu instid0(VALU_DEP_2)                            // 0000002F88AC: BF870002
	v_lshlrev_b32_e32 v7, 2, v7                                // 0000002F88B0: 300E0E82
	v_lshlrev_b32_e32 v2, 2, v2                                // 0000002F88B4: 30040482
	ds_bpermute_b32 v3, v2, v21                                // 0000002F88B8: DACC0000 03001502
	s_waitcnt lgkmcnt(0)                                       // 0000002F88C0: BF89FC07
	v_add_f32_e32 v3, v21, v3                                  // 0000002F88C4: 06060715
	ds_bpermute_b32 v4, v2, v24                                // 0000002F88C8: DACC0000 04001802
	ds_bpermute_b32 v5, v2, v23                                // 0000002F88D0: DACC0000 05001702
	ds_bpermute_b32 v6, v2, v22                                // 0000002F88D8: DACC0000 06001602
	ds_bpermute_b32 v2, v2, v16                                // 0000002F88E0: DACC0000 02001002
	ds_bpermute_b32 v8, v7, v3                                 // 0000002F88E8: DACC0000 08000307
	s_waitcnt lgkmcnt(3)                                       // 0000002F88F0: BF89FC37
	v_dual_add_f32 v4, v24, v4 :: v_dual_add_f32 v5, v23, v5   // 0000002F88F4: C9080918 04040B17
	s_waitcnt lgkmcnt(2)                                       // 0000002F88FC: BF89FC27
	v_add_f32_e32 v6, v22, v6                                  // 0000002F8900: 060C0D16
	s_waitcnt lgkmcnt(0)                                       // 0000002F8904: BF89FC07
	v_dual_add_f32 v2, v16, v2 :: v_dual_add_f32 v3, v3, v8    // 0000002F8908: C9080510 02021103
	ds_bpermute_b32 v9, v7, v4                                 // 0000002F8910: DACC0000 09000407
	ds_bpermute_b32 v10, v7, v5                                // 0000002F8918: DACC0000 0A000507
	ds_bpermute_b32 v11, v7, v6                                // 0000002F8920: DACC0000 0B000607
	ds_bpermute_b32 v7, v7, v2                                 // 0000002F8928: DACC0000 07000207
	v_cndmask_b32_e32 v12, v1, v12, vcc_lo                     // 0000002F8930: 02181901
	s_waitcnt lgkmcnt(2)                                       // 0000002F8934: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002F8938: BF870001
	v_dual_add_f32 v5, v5, v10 :: v_dual_lshlrev_b32 v12, 2, v12// 0000002F893C: C9221505 050C1882
	s_waitcnt lgkmcnt(1)                                       // 0000002F8944: BF89FC17
	v_add_f32_e32 v6, v6, v11                                  // 0000002F8948: 060C1706
	s_waitcnt lgkmcnt(0)                                       // 0000002F894C: BF89FC07
	v_add_f32_e32 v2, v2, v7                                   // 0000002F8950: 06040F02
	ds_bpermute_b32 v7, v12, v3                                // 0000002F8954: DACC0000 0700030C
	ds_bpermute_b32 v11, v12, v2                               // 0000002F895C: DACC0000 0B00020C
	v_add_f32_e32 v4, v4, v9                                   // 0000002F8964: 06081304
	ds_bpermute_b32 v9, v12, v5                                // 0000002F8968: DACC0000 0900050C
	s_waitcnt lgkmcnt(2)                                       // 0000002F8970: BF89FC27
	v_add_f32_e32 v3, v3, v7                                   // 0000002F8974: 06060F03
	s_waitcnt lgkmcnt(1)                                       // 0000002F8978: BF89FC17
	v_add_f32_e32 v7, v2, v11                                  // 0000002F897C: 060E1702
	ds_bpermute_b32 v8, v12, v4                                // 0000002F8980: DACC0000 0800040C
	s_waitcnt lgkmcnt(1)                                       // 0000002F8988: BF89FC17
	v_add_f32_e32 v5, v5, v9                                   // 0000002F898C: 060A1305
	ds_bpermute_b32 v10, v12, v6                               // 0000002F8990: DACC0000 0A00060C
	v_xor_b32_e32 v12, 2, v1                                   // 0000002F8998: 3A180282
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000002F899C: BF870141
	v_cmp_gt_u32_e32 vcc_lo, 32, v12                           // 0000002F89A0: 7C9818A0
	v_cndmask_b32_e32 v12, v1, v12, vcc_lo                     // 0000002F89A4: 02181901
	s_waitcnt lgkmcnt(0)                                       // 0000002F89A8: BF89FC07
	v_add_f32_e32 v6, v6, v10                                  // 0000002F89AC: 060C1506
	v_lshlrev_b32_e32 v12, 2, v12                              // 0000002F89B0: 30181882
	ds_bpermute_b32 v11, v12, v7                               // 0000002F89B4: DACC0000 0B00070C
	v_add_f32_e32 v4, v4, v8                                   // 0000002F89BC: 06081104
	ds_bpermute_b32 v2, v12, v3                                // 0000002F89C0: DACC0000 0200030C
	ds_bpermute_b32 v9, v12, v5                                // 0000002F89C8: DACC0000 0900050C
	ds_bpermute_b32 v10, v12, v6                               // 0000002F89D0: DACC0000 0A00060C
	ds_bpermute_b32 v8, v12, v4                                // 0000002F89D8: DACC0000 0800040C
	v_xor_b32_e32 v12, 1, v1                                   // 0000002F89E0: 3A180281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000002F89E4: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v12                           // 0000002F89E8: 7C9818A0
	v_cndmask_b32_e32 v1, v1, v12, vcc_lo                      // 0000002F89EC: 02021901
	s_waitcnt lgkmcnt(3)                                       // 0000002F89F0: BF89FC37
	v_dual_add_f32 v1, v3, v2 :: v_dual_lshlrev_b32 v12, 2, v1 // 0000002F89F4: C9220503 010C0282
	s_waitcnt lgkmcnt(1)                                       // 0000002F89FC: BF89FC17
	v_dual_add_f32 v2, v5, v9 :: v_dual_add_f32 v5, v6, v10    // 0000002F8A00: C9081305 02041506
	s_waitcnt lgkmcnt(0)                                       // 0000002F8A08: BF89FC07
	v_dual_add_f32 v3, v7, v11 :: v_dual_add_f32 v4, v4, v8    // 0000002F8A0C: C9081707 03041104
	ds_bpermute_b32 v6, v12, v1                                // 0000002F8A14: DACC0000 0600010C
	ds_bpermute_b32 v7, v12, v2                                // 0000002F8A1C: DACC0000 0700020C
	ds_bpermute_b32 v10, v12, v5                               // 0000002F8A24: DACC0000 0A00050C
	ds_bpermute_b32 v8, v12, v3                                // 0000002F8A2C: DACC0000 0800030C
	ds_bpermute_b32 v9, v12, v4                                // 0000002F8A34: DACC0000 0900040C
	v_cmpx_eq_u32_e32 0, v15                                   // 0000002F8A3C: 7D941E80
	s_cbranch_execz 16                                         // 0000002F8A40: BFA50010 <_ZN7halogen12_GLOBAL__N_110k_lq8w_grpILi5ELi32ELi2EEEvNS0_5LqGrpEPKtl+0xa84>
	v_lshl_add_u32 v11, v13, s3, v14                           // 0000002F8A44: D646000B 0438070D
	s_waitcnt lgkmcnt(0)                                       // 0000002F8A4C: BF89FC07
	v_dual_add_f32 v5, v5, v10 :: v_dual_add_f32 v4, v4, v9    // 0000002F8A50: C9081505 05041304
	v_dual_add_f32 v1, v1, v6 :: v_dual_add_f32 v2, v2, v7     // 0000002F8A58: C9080D01 01020F02
	s_delay_alu instid0(VALU_DEP_3)                            // 0000002F8A60: BF870003
	v_mul_u32_u24_e32 v6, 20, v11                              // 0000002F8A64: 160C1694
	v_add_f32_e32 v3, v3, v8                                   // 0000002F8A68: 06061103
	ds_store_2addr_b32 v6, v1, v4 offset1:1                    // 0000002F8A6C: D8380100 00040106
	ds_store_2addr_b32 v6, v2, v5 offset0:2 offset1:3          // 0000002F8A74: D8380302 00050206
	ds_store_b32 v6, v3 offset:16                              // 0000002F8A7C: D8340010 00000306
	s_or_b32 exec_lo, exec_lo, s0                              // 0000002F8A84: 8C7E007E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002F8A88: BF870009
	s_and_b32 s0, s14, exec_lo                                 // 0000002F8A8C: 8B007E0E
	s_cselect_b32 s0, 5, 20                                    // 0000002F8A90: 98009485
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000002F8A94: BF890007
	v_cmp_gt_u32_e32 vcc_lo, s0, v0                            // 0000002F8A98: 7C980000
	s_barrier                                                  // 0000002F8A9C: BFBD0000
	buffer_gl0_inv                                             // 0000002F8AA0: E0AC0000 00000000
	s_and_saveexec_b32 s0, vcc_lo                              // 0000002F8AA8: BE80206A
	s_cbranch_execz 413                                        // 0000002F8AAC: BFA5019D <_ZN7halogen12_GLOBAL__N_110k_lq8w_grpILi5ELi32ELi2EEEvNS0_5LqGrpEPKtl+0x1124>
	s_load_b32 s0, s[10:11], 0x40                              // 0000002F8AB0: F4000005 F8000040
	.long 0xd7054000                                           // 0000002F8AB8: D7054000
	v_cndmask_b32_e32 v1, 0xcd, v0, vcc_lo                     // 0000002F8ABC: 020200FF 000000CD
	.long 0x7f063880                                           // 0000002F8AC4: 7F063880
	v_mov_b32_e32 v4, 0                                        // 0000002F8AC8: 7E080280
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000002F8ACC: BF8704B3
	.long 0xd7391003                                           // 0000002F8AD0: D7391003
	v_cndmask_b32_e32 v1, 10, v0, vcc_lo                       // 0000002F8AD4: 0202008A
	s_waitcnt lgkmcnt(0)                                       // 0000002F8AD8: BF89FC07
	s_sub_i32 s4, s2, s0                                       // 0000002F8ADC: 81840002
	s_ashr_i32 s5, s4, 31                                      // 0000002F8AE0: 86059F04
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000002F8AE4: BF870499
	s_lshl_b64 s[4:5], s[4:5], s15                             // 0000002F8AE8: 84840F04
	.long 0xd7000001                                           // 0000002F8AEC: D7000001
	v_cndmask_b32_e32 v1, s4, v3, vcc_lo                       // 0000002F8AF0: 02020604
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002F8AF4: BF870091
	v_add_co_ci_u32_e64 v2, null, s5, 0, s0                    // 0000002F8AF8: D5207C02 00010005
	v_cmp_gt_i64_e32 vcc_lo, s[8:9], v[1:2]                    // 0000002F8B00: 7CA80208
	s_and_b32 exec_lo, exec_lo, vcc_lo                         // 0000002F8B04: 8B7E6A7E
	s_cbranch_execz 390                                        // 0000002F8B08: BFA50186 <_ZN7halogen12_GLOBAL__N_110k_lq8w_grpILi5ELi32ELi2EEEvNS0_5LqGrpEPKtl+0x1124>
	.long 0xd7054000                                           // 0000002F8B0C: D7054000
	v_cndmask_b32_e32 v0, v3, v133, vcc_lo                     // 0000002F8B10: 02010B03
	v_lshlrev_b32_e32 v3, s3, v3                               // 0000002F8B14: 30060603
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002F8B18: BF870112
	.long 0xd7041000                                           // 0000002F8B1C: D7041000
	v_cndmask_b32_e32 v1, v0, v0, vcc_lo                       // 0000002F8B20: 02020100
	v_mul_u32_u24_e32 v3, 20, v3                               // 0000002F8B24: 16060694
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002F8B28: BF870092
	v_and_b32_e32 v5, 0xff, v0                                 // 0000002F8B2C: 360A00FF 000000FF
	v_lshl_add_u32 v3, v5, 2, v3                               // 0000002F8B34: D6460003 040D0505
	ds_load_b32 v5, v3                                         // 0000002F8B3C: D8D80000 05000003
	v_add_nc_u32_e32 v3, 20, v3                                // 0000002F8B44: 4A060694
	s_add_i32 s1, s1, -1                                       // 0000002F8B48: 8101C101
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002F8B4C: BF870009
	s_cmp_eq_u32 s1, 0                                         // 0000002F8B50: BF068001
	s_waitcnt lgkmcnt(0)                                       // 0000002F8B54: BF89FC07
	v_add_f32_e32 v4, v4, v5                                   // 0000002F8B58: 06080B04
	s_cbranch_scc0 65527                                       // 0000002F8B5C: BFA1FFF7 <_ZN7halogen12_GLOBAL__N_110k_lq8w_grpILi5ELi32ELi2EEEvNS0_5LqGrpEPKtl+0xb3c>
	s_clause 0x1                                               // 0000002F8B60: BF850001
	s_load_b64 s[4:5], s[10:11], 0x38                          // 0000002F8B64: F4040105 F8000038
	s_load_b64 s[2:3], s[10:11], 0x8                           // 0000002F8B6C: F4040085 F8000008
	v_and_b32_e32 v3, 0xff, v0                                 // 0000002F8B74: 360600FF 000000FF
	s_mov_b32 s6, -1                                           // 0000002F8B7C: BE8600C1
	s_mov_b32 s1, 0                                            // 0000002F8B80: BE810080
	s_mov_b32 s0, 0                                            // 0000002F8B84: BE800080
	s_waitcnt lgkmcnt(0)                                       // 0000002F8B88: BF89FC07
	s_cmp_lt_i32 s5, 3                                         // 0000002F8B8C: BF048305
	s_cbranch_scc1 191                                         // 0000002F8B90: BFA200BF <_ZN7halogen12_GLOBAL__N_110k_lq8w_grpILi5ELi32ELi2EEEvNS0_5LqGrpEPKtl+0xe90>
	s_cmp_gt_i32 s5, 3                                         // 0000002F8B94: BF028305
	s_cbranch_scc0 125                                         // 0000002F8B98: BFA1007D <_ZN7halogen12_GLOBAL__N_110k_lq8w_grpILi5ELi32ELi2EEEvNS0_5LqGrpEPKtl+0xd90>
	s_cmp_gt_i32 s5, 4                                         // 0000002F8B9C: BF028405
	s_cbranch_scc0 70                                          // 0000002F8BA0: BFA10046 <_ZN7halogen12_GLOBAL__N_110k_lq8w_grpILi5ELi32ELi2EEEvNS0_5LqGrpEPKtl+0xcbc>
	s_cmp_eq_u32 s5, 5                                         // 0000002F8BA4: BF068505
	s_mov_b32 s0, -1                                           // 0000002F8BA8: BE8000C1
	s_cbranch_scc0 66                                          // 0000002F8BAC: BFA10042 <_ZN7halogen12_GLOBAL__N_110k_lq8w_grpILi5ELi32ELi2EEEvNS0_5LqGrpEPKtl+0xcb8>
	v_lshrrev_b32_e32 v0, 23, v2                               // 0000002F8BB0: 32000497
	s_lshr_b32 s0, s9, 31                                      // 0000002F8BB4: 85009F09
	s_load_b64 s[10:11], s[10:11], 0x10                        // 0000002F8BB8: F4040285 F8000010
	s_add_u32 s6, s8, s0                                       // 0000002F8BC0: 80060008
	s_addc_u32 s7, s9, 0                                       // 0000002F8BC4: 82078009
	.long 0xd7006a00                                           // 0000002F8BC8: D7006A00
	v_cndmask_b32_e32 v1, v1, v0, vcc_lo                       // 0000002F8BCC: 02020101
	s_ashr_i64 s[6:7], s[6:7], 1                               // 0000002F8BD0: 86868106
	v_add_co_ci_u32_e64 v10, null, 0, v2, vcc_lo               // 0000002F8BD4: D5207C0A 01AA0480
	v_dual_mov_b32 v11, s3 :: v_dual_and_b32 v0, 0xfffffe00, v0// 0000002F8BDC: CA240003 0B0000FF FFFFFE00
	v_mad_u64_u32 v[5:6], null, s6, v3, 0                      // 0000002F8BE8: D6FE7C05 02020606
	v_bfe_u32 v14, v4, 16, 1                                   // 0000002F8BF0: D610000E 02052104
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002F8BF8: BF870093
	.long 0xd7016a08                                           // 0000002F8BFC: D7016A08
	v_cndmask_b32_e32 v1, v1, v0, vcc_lo                       // 0000002F8C00: 02020101
	v_sub_co_ci_u32_e64 v9, null, v2, v10, vcc_lo              // 0000002F8C04: D5217C09 01AA1502
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002F8C0C: BF870194
	v_mad_u64_u32 v[6:7], null, s7, v3, v[6:7]                 // 0000002F8C10: D6FE7C06 041A0607
	.long 0xd700000c                                           // 0000002F8C18: D700000C
	v_cndmask_b32_e32 v1, 0xffffff00, v8, vcc_lo               // 0000002F8C1C: 020210FF FFFFFF00
	s_delay_alu instid0(VALU_DEP_3)                            // 0000002F8C24: BF870003
	v_cmp_gt_i64_e32 vcc_lo, 0x100, v[8:9]                     // 0000002F8C28: 7CA810FF 00000100
	v_mov_b32_e32 v7, s2                                       // 0000002F8C30: 7E0E0202
	v_add_co_ci_u32_e64 v13, null, -1, v9, s0                  // 0000002F8C34: D5207C0D 000212C1
	s_mov_b32 s0, 0                                            // 0000002F8C3C: BE800080
	.long 0xd73c0005                                           // 0000002F8C40: D73C0005
	v_cndmask_b32_e32 v1, 1, v5, vcc_lo                        // 0000002F8C44: 02020A81
	s_waitcnt lgkmcnt(0)                                       // 0000002F8C48: BF89FC07
	v_dual_cndmask_b32 v8, v12, v8 :: v_dual_cndmask_b32 v7, s10, v7// 0000002F8C4C: CA52110C 08060E0A
	v_cndmask_b32_e32 v11, s11, v11, vcc_lo                    // 0000002F8C54: 0216160B
	v_cndmask_b32_e32 v9, v13, v9, vcc_lo                      // 0000002F8C58: 0212130D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002F8C5C: BF870093
	.long 0xd7006a07                                           // 0000002F8C60: D7006A07
	v_cndmask_b32_e32 v1, v7, v5, vcc_lo                       // 0000002F8C64: 02020B07
	v_add_co_ci_u32_e64 v11, null, v11, v6, vcc_lo             // 0000002F8C68: D5207C0B 01AA0D0B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002F8C70: BF870193
	.long 0xd73c0005                                           // 0000002F8C74: D73C0005
	v_cndmask_b32_e32 v1, 1, v8, vcc_lo                        // 0000002F8C78: 02021081
	.long 0xd7006a00                                           // 0000002F8C7C: D7006A00
	v_cndmask_b32_e32 v1, v7, v0, vcc_lo                       // 0000002F8C80: 02020107
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000002F8C84: BF8701A1
	v_add_co_ci_u32_e64 v7, null, v11, v10, vcc_lo             // 0000002F8C88: D5207C07 01AA150B
	v_add3_u32 v8, v4, v14, 0x7fff                             // 0000002F8C90: D6550008 03FE1D04 00007FFF
	.long 0xd7006a05                                           // 0000002F8C9C: D7006A05
	v_cndmask_b32_e32 v1, v0, v5, vcc_lo                       // 0000002F8CA0: 02020B00
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002F8CA4: BF870001
	v_add_co_ci_u32_e64 v6, null, v7, v6, vcc_lo               // 0000002F8CA8: D5207C06 01AA0D07
	global_store_d16_hi_b16 v[5:6], v8, off                    // 0000002F8CB0: DC960000 007C0805
	s_mov_b32 s6, 0                                            // 0000002F8CB8: BE860080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002F8CBC: BF870009
	s_and_b32 vcc_lo, exec_lo, s6                              // 0000002F8CC0: 8B6A067E
	s_cbranch_vccz 49                                          // 0000002F8CC4: BFA30031 <_ZN7halogen12_GLOBAL__N_110k_lq8w_grpILi5ELi32ELi2EEEvNS0_5LqGrpEPKtl+0xd8c>
	v_mul_f32_e32 v0, 0xbfb8aa3b, v4                           // 0000002F8CC8: 100008FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002F8CD0: BF870291
	v_exp_f32_e32 v0, v0                                       // 0000002F8CD4: 7E004B00
	v_add_f32_e32 v0, 1.0, v0                                  // 0000002F8CD8: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002F8CDC: BF870121
	v_div_scale_f32 v8, null, v0, v0, 1.0                      // 0000002F8CE0: D6FC7C08 03CA0100
	v_div_scale_f32 v10, vcc_lo, 1.0, v0, 1.0                  // 0000002F8CE8: D6FC6A0A 03CA00F2
	v_rcp_f32_e32 v9, v8                                       // 0000002F8CF0: 7E125508
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002F8CF4: BF870095
	v_fma_f32 v5, -v8, v9, 1.0                                 // 0000002F8CF8: D6130005 23CA1308
	v_fmac_f32_e32 v9, v5, v9                                  // 0000002F8D00: 56121305
	v_mad_u64_u32 v[5:6], null, s8, v3, 0                      // 0000002F8D04: D6FE7C05 02020608
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002F8D0C: BF870112
	v_mul_f32_e32 v11, v10, v9                                 // 0000002F8D10: 1016130A
	v_mad_u64_u32 v[6:7], null, s9, v3, v[6:7]                 // 0000002F8D14: D6FE7C06 041A0609
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002F8D1C: BF870092
	v_fma_f32 v12, -v8, v11, v10                               // 0000002F8D20: D613000C 242A1708
	v_fmac_f32_e32 v11, v12, v9                                // 0000002F8D28: 5616130C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002F8D2C: BF870113
	.long 0xd73c0005                                           // 0000002F8D30: D73C0005
	v_cndmask_b32_e32 v1, 2, v5, vcc_lo                        // 0000002F8D34: 02020A82
	v_fma_f32 v10, -v8, v11, v10                               // 0000002F8D38: D613000A 242A1708
	.long 0xd73c0007                                           // 0000002F8D40: D73C0007
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 0000002F8D44: 02020282
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002F8D48: BF870212
	v_div_fmas_f32 v9, v10, v9, v11                            // 0000002F8D4C: D6370009 042E130A
	.long 0xd7006a05                                           // 0000002F8D54: D7006A05
	v_cndmask_b32_e32 v1, s2, v5, vcc_lo                       // 0000002F8D58: 02020A02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002F8D5C: BF870191
	v_add_co_ci_u32_e64 v6, null, s3, v6, vcc_lo               // 0000002F8D60: D5207C06 01AA0C03
	v_div_fixup_f32 v0, v9, v0, 1.0                            // 0000002F8D68: D6270000 03CA0109
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002F8D70: BF870093
	.long 0xd7006a05                                           // 0000002F8D74: D7006A05
	v_cndmask_b32_e32 v1, v5, v7, vcc_lo                       // 0000002F8D78: 02020F05
	v_add_co_ci_u32_e64 v6, null, v6, v8, vcc_lo               // 0000002F8D7C: D5207C06 01AA1106
	global_store_b32 v[5:6], v0, off                           // 0000002F8D84: DC6A0000 007C0005
	s_mov_b32 s6, 0                                            // 0000002F8D8C: BE860080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002F8D90: BF870009
	s_and_b32 vcc_lo, exec_lo, s6                              // 0000002F8D94: 8B6A067E
	s_cbranch_vccz 60                                          // 0000002F8D98: BFA3003C <_ZN7halogen12_GLOBAL__N_110k_lq8w_grpILi5ELi32ELi2EEEvNS0_5LqGrpEPKtl+0xe8c>
	v_bfe_u32 v0, v4, 16, 1                                    // 0000002F8D9C: D6100000 02052104
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002F8DA4: BF870091
	v_add3_u32 v0, v4, v0, 0x7fff                              // 0000002F8DA8: D6550000 03FE0104 00007FFF
	v_and_b32_e32 v0, 0xffff0000, v0                           // 0000002F8DB4: 360000FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002F8DBC: BF870091
	v_mul_f32_e32 v0, s4, v0                                   // 0000002F8DC0: 10000004
	v_mul_f32_e32 v0, 0xbfb8aa3b, v0                           // 0000002F8DC4: 100000FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002F8DCC: BF870291
	v_exp_f32_e32 v0, v0                                       // 0000002F8DD0: 7E004B00
	v_add_f32_e32 v0, 1.0, v0                                  // 0000002F8DD4: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002F8DD8: BF870121
	v_div_scale_f32 v8, null, v0, v0, 1.0                      // 0000002F8DDC: D6FC7C08 03CA0100
	v_div_scale_f32 v10, vcc_lo, 1.0, v0, 1.0                  // 0000002F8DE4: D6FC6A0A 03CA00F2
	v_rcp_f32_e32 v9, v8                                       // 0000002F8DEC: 7E125508
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002F8DF0: BF870095
	v_fma_f32 v5, -v8, v9, 1.0                                 // 0000002F8DF4: D6130005 23CA1308
	v_fmac_f32_e32 v9, v5, v9                                  // 0000002F8DFC: 56121305
	v_mad_u64_u32 v[5:6], null, s8, v3, 0                      // 0000002F8E00: D6FE7C05 02020608
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002F8E08: BF870092
	v_mul_f32_e32 v11, v10, v9                                 // 0000002F8E0C: 1016130A
	v_fma_f32 v7, -v8, v11, v10                                // 0000002F8E10: D6130007 242A1708
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002F8E18: BF870211
	v_fmac_f32_e32 v11, v7, v9                                 // 0000002F8E1C: 56161307
	v_mad_u64_u32 v[6:7], null, s9, v3, v[6:7]                 // 0000002F8E20: D6FE7C06 041A0609
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002F8E28: BF870112
	v_fma_f32 v7, -v8, v11, v10                                // 0000002F8E2C: D6130007 242A1708
	.long 0xd73c0005                                           // 0000002F8E34: D73C0005
	v_cndmask_b32_e32 v1, 2, v5, vcc_lo                        // 0000002F8E38: 02020A82
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000002F8E3C: BF8701A2
	v_div_fmas_f32 v9, v7, v9, v11                             // 0000002F8E40: D6370009 042E1307
	.long 0xd73c0007                                           // 0000002F8E48: D73C0007
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 0000002F8E4C: 02020282
	.long 0xd7006a05                                           // 0000002F8E50: D7006A05
	v_cndmask_b32_e32 v1, s2, v5, vcc_lo                       // 0000002F8E54: 02020A02
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000002F8E58: BF8701A3
	v_div_fixup_f32 v0, v9, v0, 1.0                            // 0000002F8E5C: D6270000 03CA0109
	v_add_co_ci_u32_e64 v6, null, s3, v6, vcc_lo               // 0000002F8E64: D5207C06 01AA0C03
	.long 0xd7006a05                                           // 0000002F8E6C: D7006A05
	v_cndmask_b32_e32 v1, v5, v7, vcc_lo                       // 0000002F8E70: 02020F05
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002F8E74: BF870193
	v_add_f32_e32 v0, v0, v0                                   // 0000002F8E78: 06000100
	v_add_co_ci_u32_e64 v6, null, v6, v8, vcc_lo               // 0000002F8E7C: D5207C06 01AA1106
	global_store_b32 v[5:6], v0, off                           // 0000002F8E84: DC6A0000 007C0005
	s_mov_b32 s6, 0                                            // 0000002F8E8C: BE860080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002F8E90: BF870009
	s_and_b32 vcc_lo, exec_lo, s6                              // 0000002F8E94: 8B6A067E
	s_cbranch_vccz 73                                          // 0000002F8E98: BFA30049 <_ZN7halogen12_GLOBAL__N_110k_lq8w_grpILi5ELi32ELi2EEEvNS0_5LqGrpEPKtl+0xfc0>
	s_cmp_gt_i32 s5, 1                                         // 0000002F8E9C: BF028105
	s_mov_b32 s1, -1                                           // 0000002F8EA0: BE8100C1
	s_cbranch_scc0 64                                          // 0000002F8EA4: BFA10040 <_ZN7halogen12_GLOBAL__N_110k_lq8w_grpILi5ELi32ELi2EEEvNS0_5LqGrpEPKtl+0xfa8>
	v_bfe_u32 v0, v4, 16, 1                                    // 0000002F8EA8: D6100000 02052104
	s_mov_b32 s1, 0                                            // 0000002F8EB0: BE810080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002F8EB4: BF870091
	v_add3_u32 v0, v4, v0, 0x7fff                              // 0000002F8EB8: D6550000 03FE0104 00007FFF
	v_and_b32_e32 v0, 0xffff0000, v0                           // 0000002F8EC4: 360000FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002F8ECC: BF870091
	v_mul_f32_e32 v0, 0xbfb8aa3b, v0                           // 0000002F8ED0: 100000FF BFB8AA3B
	v_exp_f32_e32 v0, v0                                       // 0000002F8ED8: 7E004B00
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002F8EDC: BF870095
	v_add_f32_e32 v0, 1.0, v0                                  // 0000002F8EE0: 060000F2
	v_div_scale_f32 v7, null, v0, v0, 1.0                      // 0000002F8EE4: D6FC7C07 03CA0100
	v_div_scale_f32 v9, vcc_lo, 1.0, v0, 1.0                   // 0000002F8EEC: D6FC6A09 03CA00F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002F8EF4: BF870292
	v_rcp_f32_e32 v8, v7                                       // 0000002F8EF8: 7E105507
	v_fma_f32 v5, -v7, v8, 1.0                                 // 0000002F8EFC: D6130005 23CA1107
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002F8F04: BF870121
	v_fmac_f32_e32 v8, v5, v8                                  // 0000002F8F08: 56101105
	v_mad_u64_u32 v[5:6], null, s8, v3, 0                      // 0000002F8F0C: D6FE7C05 02020608
	v_mul_f32_e32 v10, v9, v8                                  // 0000002F8F14: 10141109
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002F8F18: BF870091
	v_fma_f32 v11, -v7, v10, v9                                // 0000002F8F1C: D613000B 24261507
	v_fmac_f32_e32 v10, v11, v8                                // 0000002F8F24: 5614110B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002F8F28: BF870121
	v_fma_f32 v9, -v7, v10, v9                                 // 0000002F8F2C: D6130009 24261507
	v_mad_u64_u32 v[6:7], null, s9, v3, v[6:7]                 // 0000002F8F34: D6FE7C06 041A0609
	v_div_fmas_f32 v7, v9, v8, v10                             // 0000002F8F3C: D6370007 042A1109
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002F8F44: BF870112
	.long 0xd73c0005                                           // 0000002F8F48: D73C0005
	v_cndmask_b32_e32 v1, 1, v5, vcc_lo                        // 0000002F8F4C: 02020A81
	v_div_fixup_f32 v0, v7, v0, 1.0                            // 0000002F8F50: D6270000 03CA0107
	.long 0xd73c0007                                           // 0000002F8F58: D73C0007
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 0000002F8F5C: 02020281
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002F8F60: BF870193
	.long 0xd7006a05                                           // 0000002F8F64: D7006A05
	v_cndmask_b32_e32 v1, s2, v5, vcc_lo                       // 0000002F8F68: 02020A02
	v_bfe_u32 v9, v0, 16, 1                                    // 0000002F8F6C: D6100009 02052100
	v_add_co_ci_u32_e64 v6, null, s3, v6, vcc_lo               // 0000002F8F74: D5207C06 01AA0C03
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002F8F7C: BF870193
	.long 0xd7006a05                                           // 0000002F8F80: D7006A05
	v_cndmask_b32_e32 v1, v5, v7, vcc_lo                       // 0000002F8F84: 02020F05
	v_add3_u32 v0, v0, v9, 0x7fff                              // 0000002F8F88: D6550000 03FE1300 00007FFF
	s_delay_alu instid0(VALU_DEP_3)                            // 0000002F8F94: BF870003
	v_add_co_ci_u32_e64 v6, null, v6, v8, vcc_lo               // 0000002F8F98: D5207C06 01AA1106
	global_store_d16_hi_b16 v[5:6], v0, off                    // 0000002F8FA0: DC960000 007C0005
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 0000002F8FA8: 916A017E
	s_mov_b32 s1, 0                                            // 0000002F8FAC: BE810080
	s_cbranch_vccnz 3                                          // 0000002F8FB0: BFA40003 <_ZN7halogen12_GLOBAL__N_110k_lq8w_grpILi5ELi32ELi2EEEvNS0_5LqGrpEPKtl+0xfc0>
	s_cmp_lg_u32 s5, 1                                         // 0000002F8FB4: BF078105
	s_mov_b32 s1, -1                                           // 0000002F8FB8: BE8100C1
	s_cselect_b32 s0, -1, 0                                    // 0000002F8FBC: 980080C1
	v_bfe_u32 v5, v4, 16, 1                                    // 0000002F8FC0: D6100005 02052104
	.long 0xd73c0000                                           // 0000002F8FC8: D73C0000
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 0000002F8FCC: 02020281
	s_and_b32 vcc_lo, exec_lo, s0                              // 0000002F8FD0: 8B6A007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000002F8FD4: BF870002
	v_add3_u32 v2, v4, v5, 0x7fff                              // 0000002F8FD8: D6550002 03FE0B04 00007FFF
	s_cbranch_vccz 20                                          // 0000002F8FE4: BFA30014 <_ZN7halogen12_GLOBAL__N_110k_lq8w_grpILi5ELi32ELi2EEEvNS0_5LqGrpEPKtl+0x1038>
	v_mad_u64_u32 v[4:5], null, s8, v3, 0                      // 0000002F8FE8: D6FE7C04 02020608
	s_mov_b32 s1, 0                                            // 0000002F8FF0: BE810080
	v_mad_u64_u32 v[5:6], null, s9, v3, v[5:6]                 // 0000002F8FF4: D6FE7C05 04160609
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002F8FFC: BF870091
	.long 0xd73c0004                                           // 0000002F9000: D73C0004
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 0000002F9004: 02020881
	.long 0xd7006a04                                           // 0000002F9008: D7006A04
	v_cndmask_b32_e32 v1, s2, v4, vcc_lo                       // 0000002F900C: 02020802
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002F9010: BF870111
	v_add_co_ci_u32_e64 v5, null, s3, v5, vcc_lo               // 0000002F9014: D5207C05 01AA0A03
	.long 0xd7006a04                                           // 0000002F901C: D7006A04
	v_cndmask_b32_e32 v1, v4, v0, vcc_lo                       // 0000002F9020: 02020104
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002F9024: BF870001
	v_add_co_ci_u32_e64 v5, null, v5, v1, vcc_lo               // 0000002F9028: D5207C05 01AA0305
	global_store_d16_hi_b16 v[4:5], v2, off                    // 0000002F9030: DC960000 007C0204
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 0000002F9038: 916A017E
	s_cbranch_vccnz 57                                         // 0000002F903C: BFA40039 <_ZN7halogen12_GLOBAL__N_110k_lq8w_grpILi5ELi32ELi2EEEvNS0_5LqGrpEPKtl+0x1124>
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002F9040: BF870091
	v_and_b32_e32 v2, 0xffff0000, v2                           // 0000002F9044: 360404FF FFFF0000
	v_mul_f32_e32 v2, s4, v2                                   // 0000002F904C: 10040404
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002F9050: BF870091
	v_mul_f32_e32 v4, 0xbfb8aa3b, v2                           // 0000002F9054: 100804FF BFB8AA3B
	v_exp_f32_e32 v4, v4                                       // 0000002F905C: 7E084B04
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002F9060: BF870095
	v_add_f32_e32 v7, 1.0, v4                                  // 0000002F9064: 060E08F2
	v_div_scale_f32 v6, null, v7, v7, v2                       // 0000002F9068: D6FC7C06 040A0F07
	v_div_scale_f32 v9, vcc_lo, v2, v7, v2                     // 0000002F9070: D6FC6A09 040A0F02
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002F9078: BF870292
	v_rcp_f32_e32 v8, v6                                       // 0000002F907C: 7E105506
	v_fma_f32 v4, -v6, v8, 1.0                                 // 0000002F9080: D6130004 23CA1106
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002F9088: BF870121
	v_fmac_f32_e32 v8, v4, v8                                  // 0000002F908C: 56101104
	v_mad_u64_u32 v[4:5], null, s8, v3, 0                      // 0000002F9090: D6FE7C04 02020608
	v_mul_f32_e32 v10, v9, v8                                  // 0000002F9098: 10141109
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002F909C: BF870091
	v_fma_f32 v11, -v6, v10, v9                                // 0000002F90A0: D613000B 24261506
	v_fmac_f32_e32 v10, v11, v8                                // 0000002F90A8: 5614110B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002F90AC: BF870121
	v_fma_f32 v9, -v6, v10, v9                                 // 0000002F90B0: D6130009 24261506
	v_mad_u64_u32 v[5:6], null, s9, v3, v[5:6]                 // 0000002F90B8: D6FE7C05 04160609
	v_div_fmas_f32 v3, v9, v8, v10                             // 0000002F90C0: D6370003 042A1109
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002F90C8: BF870191
	v_div_fixup_f32 v6, v3, v7, v2                             // 0000002F90CC: D6270006 040A0F03
	.long 0xd73c0002                                           // 0000002F90D4: D73C0002
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 0000002F90D8: 02020881
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002F90DC: BF870112
	v_bfe_u32 v4, v6, 16, 1                                    // 0000002F90E0: D6100004 02052106
	.long 0xd7006a02                                           // 0000002F90E8: D7006A02
	v_cndmask_b32_e32 v1, s2, v2, vcc_lo                       // 0000002F90EC: 02020402
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002F90F0: BF870191
	v_add_co_ci_u32_e64 v3, null, s3, v3, vcc_lo               // 0000002F90F4: D5207C03 01AA0603
	v_add3_u32 v4, v6, v4, 0x7fff                              // 0000002F90FC: D6550004 03FE0906 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002F9108: BF870093
	.long 0xd7006a00                                           // 0000002F910C: D7006A00
	v_cndmask_b32_e32 v1, v2, v0, vcc_lo                       // 0000002F9110: 02020102
	v_add_co_ci_u32_e64 v1, null, v3, v1, vcc_lo               // 0000002F9114: D5207C01 01AA0303
	global_store_d16_hi_b16 v[0:1], v4, off                    // 0000002F911C: DC960000 007C0400
	s_nop 0                                                    // 0000002F9124: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 0000002F9128: BFB60003
	s_endpgm                                                   // 0000002F912C: BFB00000
		...

