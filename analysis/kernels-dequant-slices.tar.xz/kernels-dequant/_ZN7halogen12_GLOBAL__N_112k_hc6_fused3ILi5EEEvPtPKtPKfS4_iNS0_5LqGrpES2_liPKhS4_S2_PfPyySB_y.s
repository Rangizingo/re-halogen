00000000003bec00 <_ZN7halogen12_GLOBAL__N_112k_hc6_fused3ILi5EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y>:
; _ZN7halogen12_GLOBAL__N_112k_hc6_fused3ILi5EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y():
	s_clause 0x2                                               // 0000003BEC00: BF850002
	s_load_b32 s24, s[0:1], 0x20                               // 0000003BEC04: F4000600 F8000020
	s_load_b128 s[20:23], s[0:1], 0x150                        // 0000003BEC0C: F4080500 F8000150
	s_load_b512 s[4:19], s[0:1], 0x168                         // 0000003BEC14: F4100100 F8000168
	s_mov_b32 s3, -1                                           // 0000003BEC1C: BE8300C1
	s_waitcnt lgkmcnt(0)                                       // 0000003BEC20: BF89FC07
	s_cmp_ge_i32 s2, s24                                       // 0000003BEC24: BF031802
	s_cbranch_scc0 2301                                        // 0000003BEC28: BFA108FD <_ZN7halogen12_GLOBAL__N_112k_hc6_fused3ILi5EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x2420>
	s_load_b32 s25, s[0:1], 0x160                              // 0000003BEC2C: F4000640 F8000160
	s_waitcnt lgkmcnt(0)                                       // 0000003BEC34: BF89FC07
	s_add_i32 s25, s25, s24                                    // 0000003BEC38: 81191819
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000003BEC3C: BF870009
	s_cmp_ge_i32 s2, s25                                       // 0000003BEC40: BF031902
	s_cbranch_scc0 1223                                        // 0000003BEC44: BFA104C7 <_ZN7halogen12_GLOBAL__N_112k_hc6_fused3ILi5EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x1364>
	v_dual_mov_b32 v8, 0 :: v_dual_and_b32 v7, 15, v0          // 0000003BEC48: CA240080 0806008F
	v_dual_mov_b32 v6, 0 :: v_dual_mov_b32 v5, 0               // 0000003BEC50: CA100080 06040080
	v_dual_mov_b32 v4, 0 :: v_dual_mov_b32 v3, 0               // 0000003BEC58: CA100080 04020080
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000003BEC60: BF8704B3
	.long 0xd44c0003                                           // 0000003BEC64: D44C0003
	v_cndmask_b32_e32 v1, 10, v7, vcc_lo                       // 0000003BEC68: 02020E8A
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v1, 0               // 0000003BEC6C: CA100080 02000080
	s_sub_i32 s25, s2, s25                                     // 0000003BEC74: 81991902
	s_lshl_b32 s25, s25, 2                                     // 0000003BEC78: 84198219
	s_and_saveexec_b32 s26, s3                                 // 0000003BEC7C: BE9A2003
	s_cbranch_execz 45                                         // 0000003BEC80: BFA5002D <_ZN7halogen12_GLOBAL__N_112k_hc6_fused3ILi5EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x138>
	v_lshrrev_b32_e32 v1, 6, v0                                // 0000003BEC84: 32020086
	v_bfe_u32 v2, v0, 4, 2                                     // 0000003BEC88: D6100002 02090900
	v_lshlrev_b32_e32 v4, 1, v0                                // 0000003BEC90: 30080081
	v_lshlrev_b32_e32 v5, 4, v7                                // 0000003BEC94: 300A0E84
	v_lshlrev_b32_e32 v6, 3, v7                                // 0000003BEC98: 300C0E83
	v_add_nc_u32_e32 v1, s25, v1                               // 0000003BEC9C: 4A020219
	v_mul_u32_u24_e32 v2, 0xa00, v2                            // 0000003BECA0: 160404FF 00000A00
	v_and_b32_e32 v4, 28, v4                                   // 0000003BECA8: 3608089C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003BECAC: BF870193
	v_ashrrev_i32_e32 v3, 31, v1                               // 0000003BECB0: 3406029F
	.long 0xd7006a01                                           // 0000003BECB4: D7006A01
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 0000003BECB8: 02020501
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003BECBC: BF870111
	v_add_co_ci_u32_e64 v3, null, 0, v3, vcc_lo                // 0000003BECC0: D5207C03 01AA0680
	v_mad_u64_u32 v[1:2], null, 0x110, v1, s[4:5]              // 0000003BECC8: D6FE7C01 001202FF 00000110
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003BECD4: BF870111
	v_mad_i32_i24 v9, 0x110, v3, v2                            // 0000003BECD8: D60A0009 040A06FF 00000110
	.long 0xd7006a02                                           // 0000003BECE4: D7006A02
	v_cndmask_b32_e32 v1, v1, v5, vcc_lo                       // 0000003BECE8: 02020B01
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003BECEC: BF8700A1
	v_add_co_ci_u32_e64 v3, null, 0, v9, vcc_lo                // 0000003BECF0: D5207C03 01AA1280
	.long 0xd7006a05                                           // 0000003BECF8: D7006A05
	v_cndmask_b32_e32 v1, v1, v6, vcc_lo                       // 0000003BECFC: 02020D01
	v_add_co_ci_u32_e64 v6, null, 0, v9, vcc_lo                // 0000003BED00: D5207C06 01AA1280
	.long 0xd7006a08                                           // 0000003BED08: D7006A08
	v_cndmask_b32_e32 v1, v1, v4, vcc_lo                       // 0000003BED0C: 02020901
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003BED10: BF870001
	v_add_co_ci_u32_e64 v9, null, 0, v9, vcc_lo                // 0000003BED14: D5207C09 01AA1280
	s_clause 0x2                                               // 0000003BED1C: BF850002
	global_load_b128 v[1:4], v[2:3], off                       // 0000003BED20: DC5E0000 017C0002
	global_load_b64 v[5:6], v[5:6], off offset:160             // 0000003BED28: DC5600A0 057C0005
	global_load_b32 v8, v[8:9], off offset:240                 // 0000003BED30: DC5200F0 087C0008
	s_or_b32 exec_lo, exec_lo, s26                             // 0000003BED38: 8C7E1A7E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000003BED3C: BF870009
	s_mov_b32 s4, exec_lo                                      // 0000003BED40: BE84007E
	v_cmpx_eq_u32_e32 0, v0                                    // 0000003BED44: 7D940080
	s_cbranch_execz 20                                         // 0000003BED48: BFA50014 <_ZN7halogen12_GLOBAL__N_112k_hc6_fused3ILi5EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x19c>
	v_mov_b32_e32 v9, 0                                        // 0000003BED4C: 7E120280
	global_load_b64 v[10:11], v9, s[16:17] glc                 // 0000003BED50: DC564000 0A100009
	s_waitcnt vmcnt(0)                                         // 0000003BED58: BF8903F7
	buffer_gl1_inv                                             // 0000003BED5C: E0B00000 00000000
	buffer_gl0_inv                                             // 0000003BED64: E0AC0000 00000000
	v_cmp_le_u64_e32 vcc_lo, s[18:19], v[10:11]                // 0000003BED6C: 7CB61412
	s_cbranch_vccnz 10                                         // 0000003BED70: BFA4000A <_ZN7halogen12_GLOBAL__N_112k_hc6_fused3ILi5EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x19c>
	s_sleep 1                                                  // 0000003BED74: BF830001
	global_load_b64 v[10:11], v9, s[16:17] glc                 // 0000003BED78: DC564000 0A100009
	s_waitcnt vmcnt(0)                                         // 0000003BED80: BF8903F7
	buffer_gl1_inv                                             // 0000003BED84: E0B00000 00000000
	buffer_gl0_inv                                             // 0000003BED8C: E0AC0000 00000000
	v_cmp_gt_u64_e32 vcc_lo, s[18:19], v[10:11]                // 0000003BED94: 7CB81412
	s_cbranch_vccnz 65526                                      // 0000003BED98: BFA4FFF6 <_ZN7halogen12_GLOBAL__N_112k_hc6_fused3ILi5EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x174>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000003BED9C: 8C7E047E
	v_dual_mov_b32 v12, 0 :: v_dual_mov_b32 v13, 0             // 0000003BEDA0: CA100080 0C0C0080
	v_dual_mov_b32 v9, 0 :: v_dual_mov_b32 v10, 0              // 0000003BEDA8: CA100080 090A0080
	v_mov_b32_e32 v11, 0                                       // 0000003BEDB0: 7E160280
	s_waitcnt vmcnt(0)                                         // 0000003BEDB4: BF8903F7
	s_barrier                                                  // 0000003BEDB8: BFBD0000
	buffer_gl0_inv                                             // 0000003BEDBC: E0AC0000 00000000
	buffer_gl1_inv                                             // 0000003BEDC4: E0B00000 00000000
	buffer_gl0_inv                                             // 0000003BEDCC: E0AC0000 00000000
	s_and_saveexec_b32 s4, s3                                  // 0000003BEDD4: BE842003
	s_cbranch_execz 713                                        // 0000003BEDD8: BFA502C9 <_ZN7halogen12_GLOBAL__N_112k_hc6_fused3ILi5EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0xd00>
	v_lshlrev_b32_e32 v85, 6, v7                               // 0000003BEDDC: 30AA0E86
	v_lshlrev_b32_e32 v29, 4, v5                               // 0000003BEDE0: 303A0A84
	v_lshlrev_b32_e32 v30, 2, v5                               // 0000003BEDE4: 303C0A82
	v_lshrrev_b32_e32 v31, 8, v1                               // 0000003BEDE8: 323E0288
	v_and_b32_e32 v32, 48, v5                                  // 0000003BEDEC: 36400AB0
	s_clause 0x4                                               // 0000003BEDF0: BF850004
	global_load_b128 v[9:12], v85, s[6:7]                      // 0000003BEDF4: DC5E0000 09060055
	global_load_b128 v[13:16], v85, s[6:7] offset:640          // 0000003BEDFC: DC5E0280 0D060055
	global_load_b128 v[17:20], v85, s[6:7] offset:1280         // 0000003BEE04: DC5E0500 11060055
	global_load_b128 v[21:24], v85, s[6:7] offset:1920         // 0000003BEE0C: DC5E0780 15060055
	global_load_b128 v[25:28], v85, s[6:7] offset:2560         // 0000003BEE14: DC5E0A00 19060055
	v_lshrrev_b32_e32 v33, 2, v5                               // 0000003BEE1C: 32420A82
	v_and_b32_e32 v37, 48, v29                                 // 0000003BEE20: 364A3AB0
	v_lshrrev_b32_e32 v49, 4, v1                               // 0000003BEE24: 32620284
	v_and_b32_e32 v50, 48, v30                                 // 0000003BEE28: 36643CB0
	v_and_or_b32 v58, v31, 15, v32                             // 0000003BEE2C: D657003A 04811F1F
	v_and_b32_e32 v59, 48, v33                                 // 0000003BEE34: 367642B0
	s_clause 0x1                                               // 0000003BEE38: BF850001
	global_load_b128 v[29:32], v85, s[6:7] offset:16           // 0000003BEE3C: DC5E0010 1D060055
	global_load_b128 v[33:36], v85, s[6:7] offset:656          // 0000003BEE44: DC5E0290 21060055
	v_and_or_b32 v51, v1, 15, v37                              // 0000003BEE4C: D6570033 04951F01
	s_clause 0x2                                               // 0000003BEE54: BF850002
	global_load_b128 v[37:40], v85, s[6:7] offset:1296         // 0000003BEE58: DC5E0510 25060055
	global_load_b128 v[41:44], v85, s[6:7] offset:1936         // 0000003BEE60: DC5E0790 29060055
	global_load_b128 v[45:48], v85, s[6:7] offset:2576         // 0000003BEE68: DC5E0A10 2D060055
	v_lshrrev_b32_e32 v57, 12, v1                              // 0000003BEE70: 3272028C
	v_and_or_b32 v60, v49, 15, v50                             // 0000003BEE74: D657003C 04C91F31
	.long 0x7fb23880                                           // 0000003BEE7C: 7FB23880
	v_cvt_f32_ubyte0_e32 v61, v51                              // 0000003BEE80: 7E7A2333
	s_clause 0x1                                               // 0000003BEE84: BF850001
	global_load_b128 v[49:52], v85, s[6:7] offset:32           // 0000003BEE88: DC5E0020 31060055
	global_load_b128 v[53:56], v85, s[6:7] offset:672          // 0000003BEE90: DC5E02A0 35060055
	v_and_or_b32 v62, v57, 15, v59                             // 0000003BEE98: D657003E 04ED1F39
	v_cvt_f32_ubyte0_e32 v63, v60                              // 0000003BEEA0: 7E7E233C
	v_lshrrev_b32_e32 v70, 4, v5                               // 0000003BEEA4: 328C0A84
	v_fma_mix_f32 v65, v61, v8, v8 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003BEEA8: CC206041 1422113D
	v_cvt_f32_ubyte0_e32 v61, v58                              // 0000003BEEB0: 7E7A233A
	v_cvt_f32_ubyte0_e32 v66, v62                              // 0000003BEEB4: 7E84233E
	v_fma_mix_f32 v71, v63, v8, v8 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003BEEB8: CC206047 1422113F
	global_load_b128 v[57:60], v85, s[6:7] offset:1312         // 0000003BEEC0: DC5E0520 39060055
	v_bfe_u32 v67, v65, 16, 1                                  // 0000003BEEC8: D6100043 02052141
	v_fma_mix_f32 v72, v61, v8, v8 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003BEED0: CC206048 1422113D
	global_load_b128 v[61:64], v85, s[6:7] offset:1952         // 0000003BEED8: DC5E07A0 3D060055
	v_fma_mix_f32 v73, v66, v8, v8 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003BEEE0: CC206049 14221142
	v_bfe_u32 v74, v71, 16, 1                                  // 0000003BEEE8: D610004A 02052147
	v_add3_u32 v75, v65, v67, 0x7fff                           // 0000003BEEF0: D655004B 03FE8741 00007FFF
	v_bfe_u32 v76, v72, 16, 1                                  // 0000003BEEFC: D610004C 02052148
	global_load_b128 v[65:68], v85, s[6:7] offset:2592         // 0000003BEF04: DC5E0A20 41060055
	v_bfe_u32 v77, v73, 16, 1                                  // 0000003BEF0C: D610004D 02052149
	v_add3_u32 v71, v71, v74, 0x7fff                           // 0000003BEF14: D6550047 03FE9547 00007FFF
	.long 0x7eb239cb                                           // 0000003BEF20: 7EB239CB
	v_add3_u32 v72, v72, v76, 0x7fff                           // 0000003BEF24: D6550048 03FE9948 00007FFF
	v_lshrrev_b32_e32 v69, 8, v5                               // 0000003BEF30: 328A0A88
	v_add3_u32 v73, v73, v77, 0x7fff                           // 0000003BEF34: D6550049 03FE9B49 00007FFF
	v_lshrrev_b32_e32 v74, 6, v5                               // 0000003BEF40: 32940A86
	v_and_or_b32 v91, 0xffff0000, v71, v89                     // 0000003BEF44: D657005B 05668EFF FFFF0000
	.long 0x7eb239c8                                           // 0000003BEF50: 7EB239C8
	v_and_b32_e32 v86, 48, v70                                 // 0000003BEF54: 36AC8CB0
	v_and_b32_e32 v94, 48, v69                                 // 0000003BEF58: 36BC8AB0
	v_and_b32_e32 v93, 48, v74                                 // 0000003BEF5C: 36BA94B0
	v_lshrrev_b32_e32 v90, 20, v1                              // 0000003BEF60: 32B40294
	v_and_or_b32 v95, 0xffff0000, v73, v89                     // 0000003BEF64: D657005F 056692FF FFFF0000
	.long 0x7eb23981                                           // 0000003BEF70: 7EB23981
	s_clause 0x3                                               // 0000003BEF74: BF850003
	global_load_b128 v[69:72], v85, s[6:7] offset:48           // 0000003BEF78: DC5E0030 45060055
	global_load_b128 v[73:76], v85, s[6:7] offset:688          // 0000003BEF80: DC5E02B0 49060055
	global_load_b128 v[77:80], v85, s[6:7] offset:1328         // 0000003BEF88: DC5E0530 4D060055
	global_load_b128 v[81:84], v85, s[6:7] offset:1968         // 0000003BEF90: DC5E07B0 51060055
	v_lshrrev_b32_e32 v92, 24, v1                              // 0000003BEF98: 32B80298
	v_lshrrev_b32_e32 v1, 28, v1                               // 0000003BEF9C: 3202029C
	v_lshrrev_b32_e32 v97, 10, v5                              // 0000003BEFA0: 32C20A8A
	v_and_or_b32 v96, v89, 15, v86                             // 0000003BEFA4: D6570060 05591F59
	global_load_b128 v[85:88], v85, s[6:7] offset:2608         // 0000003BEFAC: DC5E0A30 55060055
	v_and_or_b32 v90, v90, 15, v93                             // 0000003BEFB4: D657005A 05751F5A
	v_and_or_b32 v92, v92, 15, v94                             // 0000003BEFBC: D657005C 05791F5C
	v_and_or_b32 v1, v97, 48, v1                               // 0000003BEFC4: D6570001 04056161
	v_cvt_f32_ubyte0_e32 v93, v96                              // 0000003BEFCC: 7EBA2360
	v_lshrrev_b32_e32 v98, 24, v5                              // 0000003BEFD0: 32C40A98
	v_cvt_f32_ubyte0_e32 v90, v90                              // 0000003BEFD4: 7EB4235A
	v_cvt_f32_ubyte0_e32 v92, v92                              // 0000003BEFD8: 7EB8235C
	v_cvt_f32_ubyte0_e32 v1, v1                                // 0000003BEFDC: 7E022301
	v_fma_mix_f32 v93, v93, v8, v8 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003BEFE0: CC20605D 1422115D
	v_lshrrev_b32_e32 v99, 22, v5                              // 0000003BEFE8: 32C60A96
	v_fma_mix_f32 v90, v90, v8, v8 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003BEFEC: CC20605A 1422115A
	v_fma_mix_f32 v92, v92, v8, v8 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003BEFF4: CC20605C 1422115C
	v_fma_mix_f32 v1, v1, v8, v8 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003BEFFC: CC206001 14221101
	v_bfe_u32 v94, v93, 16, 1                                  // 0000003BF004: D610005E 0205215D
	v_lshrrev_b32_e32 v100, 24, v2                             // 0000003BF00C: 32C80498
	v_bfe_u32 v96, v90, 16, 1                                  // 0000003BF010: D6100060 0205215A
	v_lshrrev_b32_e32 v101, 26, v5                             // 0000003BF018: 32CA0A9A
	v_bfe_u32 v97, v1, 16, 1                                   // 0000003BF01C: D6100061 02052101
	v_add3_u32 v93, v93, v94, 0x7fff                           // 0000003BF024: D655005D 03FEBD5D 00007FFF
	v_bfe_u32 v94, v92, 16, 1                                  // 0000003BF030: D610005E 0205215C
	v_add3_u32 v90, v90, v96, 0x7fff                           // 0000003BF038: D655005A 03FEC15A 00007FFF
	v_lshrrev_b32_e32 v96, 20, v5                              // 0000003BF044: 32C00A94
	v_add3_u32 v1, v1, v97, 0x7fff                             // 0000003BF048: D6550001 03FEC301 00007FFF
	.long 0x7eb239dd                                           // 0000003BF054: 7EB239DD
	v_add3_u32 v92, v92, v94, 0x7fff                           // 0000003BF058: D655005C 03FEBD5C 00007FFF
	v_lshrrev_b32_e32 v93, 18, v5                              // 0000003BF064: 32BA0A92
	v_lshrrev_b32_e32 v97, 12, v2                              // 0000003BF068: 32C2048C
	v_and_b32_e32 v96, 48, v96                                 // 0000003BF06C: 36C0C0B0
	v_and_or_b32 v90, 0xffff0000, v90, v89                     // 0000003BF070: D657005A 0566B4FF FFFF0000
	.long 0x7eb239dc                                           // 0000003BF07C: 7EB239DC
	v_lshrrev_b32_e32 v92, 8, v2                               // 0000003BF080: 32B80488
	v_and_b32_e32 v93, 48, v93                                 // 0000003BF084: 36BABAB0
	v_lshlrev_b32_e32 v102, 4, v6                              // 0000003BF088: 30CC0C84
	v_and_b32_e32 v99, 48, v99                                 // 0000003BF08C: 36C6C6B0
	v_and_or_b32 v1, 0xffff0000, v1, v89                       // 0000003BF090: D6570001 056602FF FFFF0000
	.long 0x7eb23985                                           // 0000003BF09C: 7EB23985
	v_and_or_b32 v93, v97, 15, v93                             // 0000003BF0A0: D657005D 05751F61
	v_lshrrev_b32_e32 v97, 28, v2                              // 0000003BF0A8: 32C2049C
	v_and_b32_e32 v98, 48, v98                                 // 0000003BF0AC: 36C4C4B0
	v_lshlrev_b32_e32 v104, 2, v6                              // 0000003BF0B0: 30D00C82
	v_and_b32_e32 v94, 48, v89                                 // 0000003BF0B4: 36BCB2B0
	v_cvt_f32_ubyte0_e32 v93, v93                              // 0000003BF0B8: 7EBA235D
	v_lshrrev_b32_e32 v105, 8, v3                              // 0000003BF0BC: 32D20688
	v_and_b32_e32 v107, 48, v6                                 // 0000003BF0C0: 36D60CB0
	v_and_or_b32 v98, v100, 15, v98                            // 0000003BF0C4: D6570062 05891F64
	v_and_or_b32 v92, v92, 15, v94                             // 0000003BF0CC: D657005C 05791F5C
	v_fma_mix_f32 v93, v93, v8, v8 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003BF0D4: CC20605D 1422115D
	v_lshrrev_b32_e32 v94, 20, v2                              // 0000003BF0DC: 32BC0494
	v_lshrrev_b32_e32 v103, 4, v3                              // 0000003BF0E0: 32CE0684
	v_lshrrev_b32_e32 v109, 2, v6                              // 0000003BF0E4: 32DA0C82
	v_cvt_f32_ubyte0_e32 v92, v92                              // 0000003BF0E8: 7EB8235C
	v_bfe_u32 v110, v93, 16, 1                                 // 0000003BF0EC: D610006E 0205215D
	v_and_or_b32 v94, v94, 15, v99                             // 0000003BF0F4: D657005E 058D1F5E
	v_cvt_f32_ubyte0_e32 v98, v98                              // 0000003BF0FC: 7EC42362
	v_lshrrev_b32_e32 v108, 12, v3                             // 0000003BF100: 32D8068C
	v_fma_mix_f32 v92, v92, v8, v8 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003BF104: CC20605C 1422115C
	v_add3_u32 v93, v93, v110, 0x7fff                          // 0000003BF10C: D655005D 03FEDD5D 00007FFF
	v_cvt_f32_ubyte0_e32 v94, v94                              // 0000003BF118: 7EBC235E
	v_fma_mix_f32 v98, v98, v8, v8 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003BF11C: CC206062 14221162
	v_lshrrev_b32_e32 v112, 22, v6                             // 0000003BF124: 32E00C96
	v_bfe_u32 v106, v92, 16, 1                                 // 0000003BF128: D610006A 0205215C
	v_lshrrev_b32_e32 v111, 20, v4                             // 0000003BF130: 32DE0894
	v_fma_mix_f32 v94, v94, v8, v8 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003BF134: CC20605E 1422115E
	v_lshrrev_b32_e32 v113, 24, v4                             // 0000003BF13C: 32E20898
	v_and_b32_e32 v112, 48, v112                               // 0000003BF140: 36E0E0B0
	v_add3_u32 v92, v92, v106, 0x7fff                          // 0000003BF144: D655005C 03FED55C 00007FFF
	v_lshrrev_b32_e32 v106, 20, v6                             // 0000003BF150: 32D40C94
	s_delay_alu instid0(VALU_DEP_2)                            // 0000003BF154: BF870002
	.long 0x7eb239dc                                           // 0000003BF158: 7EB239DC
	v_and_or_b32 v92, v101, 48, v97                            // 0000003BF15C: D657005C 05856165
	v_and_b32_e32 v97, 48, v102                                // 0000003BF164: 36C2CCB0
	v_and_b32_e32 v101, 48, v104                               // 0000003BF168: 36CAD0B0
	v_and_or_b32 v102, v105, 15, v107                          // 0000003BF16C: D6570066 05AD1F69
	v_and_or_b32 v93, 0xffff0000, v93, v89                     // 0000003BF174: D657005D 0566BAFF FFFF0000
	.long 0x7eb23982                                           // 0000003BF180: 7EB23982
	v_and_or_b32 v97, v3, 15, v97                              // 0000003BF184: D6570061 05851F03
	v_and_b32_e32 v104, 48, v109                               // 0000003BF18C: 36D0DAB0
	v_cvt_f32_ubyte0_e32 v92, v92                              // 0000003BF190: 7EB8235C
	v_and_or_b32 v99, v103, 15, v101                           // 0000003BF194: D6570063 05951F67
	v_and_or_b32 v96, v89, 15, v96                             // 0000003BF19C: D6570060 05811F59
	v_cvt_f32_ubyte0_e32 v101, v102                            // 0000003BF1A4: 7ECA2366
	v_cvt_f32_ubyte0_e32 v97, v97                              // 0000003BF1A8: 7EC22361
	v_and_or_b32 v100, v108, 15, v104                          // 0000003BF1AC: D6570064 05A11F6C
	v_fma_mix_f32 v92, v92, v8, v8 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003BF1B4: CC20605C 1422115C
	v_cvt_f32_ubyte0_e32 v96, v96                              // 0000003BF1BC: 7EC02360
	v_cvt_f32_ubyte0_e32 v99, v99                              // 0000003BF1C0: 7EC62363
	v_fma_mix_f32 v97, v97, v8, v8 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003BF1C4: CC206061 14221161
	v_bfe_u32 v104, v94, 16, 1                                 // 0000003BF1CC: D6100068 0205215E
	v_fma_mix_f32 v101, v101, v8, v8 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003BF1D4: CC206065 14221165
	v_fma_mix_f32 v96, v96, v8, v8 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003BF1DC: CC206060 14221160
	v_cvt_f32_ubyte0_e32 v100, v100                            // 0000003BF1E4: 7EC82364
	v_bfe_u32 v103, v92, 16, 1                                 // 0000003BF1E8: D6100067 0205215C
	v_fma_mix_f32 v99, v99, v8, v8 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003BF1F0: CC206063 14221163
	v_add3_u32 v94, v94, v104, 0x7fff                          // 0000003BF1F8: D655005E 03FED15E 00007FFF
	v_bfe_u32 v102, v96, 16, 1                                 // 0000003BF204: D6100066 02052160
	v_fma_mix_f32 v100, v100, v8, v8 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003BF20C: CC206064 14221164
	v_add3_u32 v92, v92, v103, 0x7fff                          // 0000003BF214: D655005C 03FECF5C 00007FFF
	v_lshrrev_b32_e32 v103, 10, v6                             // 0000003BF220: 32CE0C8A
	v_lshrrev_b32_e32 v108, 18, v6                             // 0000003BF224: 32D80C92
	v_add3_u32 v96, v96, v102, 0x7fff                          // 0000003BF228: D6550060 03FECD60 00007FFF
	v_bfe_u32 v102, v98, 16, 1                                 // 0000003BF234: D6100066 02052162
	v_lshrrev_b32_e32 v107, 12, v4                             // 0000003BF23C: 32D6088C
	v_lshrrev_b32_e32 v109, 24, v6                             // 0000003BF240: 32DA0C98
	v_and_b32_e32 v108, 48, v108                               // 0000003BF244: 36D8D8B0
	.long 0x7eb239e0                                           // 0000003BF248: 7EB239E0
	v_add3_u32 v96, v98, v102, 0x7fff                          // 0000003BF24C: D6550060 03FECD62 00007FFF
	v_bfe_u32 v98, v97, 16, 1                                  // 0000003BF258: D6100062 02052161
	v_bfe_u32 v102, v99, 16, 1                                 // 0000003BF260: D6100066 02052163
	v_and_or_b32 v107, v107, 15, v108                          // 0000003BF268: D657006B 05B11F6B
	v_and_or_b32 v94, 0xffff0000, v94, v89                     // 0000003BF270: D657005E 0566BCFF FFFF0000
	.long 0x7eb239e0                                           // 0000003BF27C: 7EB239E0
	v_add3_u32 v96, v97, v98, 0x7fff                           // 0000003BF280: D6550060 03FEC561 00007FFF
	v_bfe_u32 v97, v101, 16, 1                                 // 0000003BF28C: D6100061 02052165
	v_bfe_u32 v98, v100, 16, 1                                 // 0000003BF294: D6100062 02052164
	v_add3_u32 v99, v99, v102, 0x7fff                          // 0000003BF29C: D6550063 03FECD63 00007FFF
	v_and_or_b32 v92, 0xffff0000, v92, v89                     // 0000003BF2A8: D657005C 0566B8FF FFFF0000
	.long 0x7eb239e0                                           // 0000003BF2B4: 7EB239E0
	v_add3_u32 v96, v101, v97, 0x7fff                          // 0000003BF2B8: D6550060 03FEC365 00007FFF
	v_lshrrev_b32_e32 v97, 4, v6                               // 0000003BF2C4: 32C20C84
	v_add3_u32 v98, v100, v98, 0x7fff                          // 0000003BF2C8: D6550062 03FEC564 00007FFF
	v_lshrrev_b32_e32 v100, 8, v6                              // 0000003BF2D4: 32C80C88
	v_and_or_b32 v99, 0xffff0000, v99, v89                     // 0000003BF2D8: D6570063 0566C6FF FFFF0000
	.long 0x7eb239e0                                           // 0000003BF2E4: 7EB239E0
	v_lshrrev_b32_e32 v96, 6, v6                               // 0000003BF2E8: 32C00C86
	v_and_b32_e32 v97, 48, v97                                 // 0000003BF2EC: 36C2C2B0
	v_lshrrev_b32_e32 v101, 20, v3                             // 0000003BF2F0: 32CA0694
	v_lshrrev_b32_e32 v102, 24, v3                             // 0000003BF2F4: 32CC0698
	v_and_or_b32 v98, 0xffff0000, v98, v89                     // 0000003BF2F8: D6570062 0566C4FF FFFF0000
	.long 0x7eb23983                                           // 0000003BF304: 7EB23983
	v_and_b32_e32 v96, 48, v96                                 // 0000003BF308: 36C0C0B0
	v_and_b32_e32 v100, 48, v100                               // 0000003BF30C: 36C8C8B0
	v_lshrrev_b32_e32 v3, 28, v3                               // 0000003BF310: 3206069C
	v_lshrrev_b32_e32 v104, 4, v2                              // 0000003BF314: 32D00484
	v_and_or_b32 v97, v89, 15, v97                             // 0000003BF318: D6570061 05851F59
	v_and_or_b32 v96, v101, 15, v96                            // 0000003BF320: D6570060 05811F65
	v_and_or_b32 v100, v102, 15, v100                          // 0000003BF328: D6570064 05911F66
	v_and_or_b32 v3, v103, 48, v3                              // 0000003BF330: D6570003 040D6167
	v_lshrrev_b32_e32 v102, 12, v5                             // 0000003BF338: 32CC0A8C
	v_cvt_f32_ubyte0_e32 v97, v97                              // 0000003BF33C: 7EC22361
	v_cvt_f32_ubyte0_e32 v96, v96                              // 0000003BF340: 7EC02360
	v_cvt_f32_ubyte0_e32 v100, v100                            // 0000003BF344: 7EC82364
	v_cvt_f32_ubyte0_e32 v3, v3                                // 0000003BF348: 7E062303
	v_lshrrev_b32_e32 v5, 14, v5                               // 0000003BF34C: 320A0A8E
	v_fma_mix_f32 v97, v97, v8, v8 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003BF350: CC206061 14221161
	v_fma_mix_f32 v96, v96, v8, v8 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003BF358: CC206060 14221160
	v_fma_mix_f32 v100, v100, v8, v8 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003BF360: CC206064 14221164
	v_fma_mix_f32 v3, v3, v8, v8 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003BF368: CC206003 14221103
	v_and_b32_e32 v5, 48, v5                                   // 0000003BF370: 360A0AB0
	v_bfe_u32 v101, v97, 16, 1                                 // 0000003BF374: D6100065 02052161
	v_bfe_u32 v103, v96, 16, 1                                 // 0000003BF37C: D6100067 02052160
	v_and_b32_e32 v106, 48, v106                               // 0000003BF384: 36D4D4B0
	v_bfe_u32 v105, v3, 16, 1                                  // 0000003BF388: D6100069 02052103
	v_and_or_b32 v5, v104, 15, v5                              // 0000003BF390: D6570005 04151F68
	v_add3_u32 v97, v97, v101, 0x7fff                          // 0000003BF398: D6550061 03FECB61 00007FFF
	v_bfe_u32 v101, v100, 16, 1                                // 0000003BF3A4: D6100065 02052164
	v_add3_u32 v96, v96, v103, 0x7fff                          // 0000003BF3AC: D6550060 03FECF60 00007FFF
	v_add3_u32 v3, v3, v105, 0x7fff                            // 0000003BF3B8: D6550003 03FED303 00007FFF
	v_lshrrev_b32_e32 v105, 8, v4                              // 0000003BF3C4: 32D20888
	.long 0x7eb239e1                                           // 0000003BF3C8: 7EB239E1
	v_add3_u32 v97, v100, v101, 0x7fff                         // 0000003BF3CC: D6550061 03FECB64 00007FFF
	v_lshrrev_b32_e32 v100, 12, v6                             // 0000003BF3D8: 32C80C8C
	v_lshrrev_b32_e32 v103, 14, v6                             // 0000003BF3DC: 32CE0C8E
	v_lshrrev_b32_e32 v101, 4, v4                              // 0000003BF3E0: 32CA0884
	v_and_or_b32 v96, 0xffff0000, v96, v89                     // 0000003BF3E4: D6570060 0566C0FF FFFF0000
	.long 0x7eb239e1                                           // 0000003BF3F0: 7EB239E1
	v_and_b32_e32 v97, 15, v4                                  // 0000003BF3F4: 36C2088F
	v_and_b32_e32 v103, 48, v103                               // 0000003BF3F8: 36CECEB0
	v_and_b32_e32 v102, 48, v102                               // 0000003BF3FC: 36CCCCB0
	v_and_b32_e32 v109, 48, v109                               // 0000003BF400: 36DADAB0
	v_and_or_b32 v3, 0xffff0000, v3, v89                       // 0000003BF404: D6570003 056606FF FFFF0000
	.long 0x7eb23986                                           // 0000003BF410: 7EB23986
	v_and_or_b32 v97, v100, 48, v97                            // 0000003BF414: D6570061 05856164
	v_cvt_f32_ubyte0_e32 v100, v107                            // 0000003BF41C: 7EC8236B
	v_lshrrev_b32_e32 v6, 26, v6                               // 0000003BF420: 320C0C9A
	v_and_or_b32 v101, v101, 15, v103                          // 0000003BF424: D6570065 059D1F65
	v_and_b32_e32 v110, 48, v89                                // 0000003BF42C: 36DCB2B0
	v_cvt_f32_ubyte0_e32 v97, v97                              // 0000003BF430: 7EC22361
	v_fma_mix_f32 v100, v100, v8, v8 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003BF434: CC206064 14221164
	v_and_or_b32 v2, v2, 15, v102                              // 0000003BF43C: D6570002 05991F02
	v_and_or_b32 v102, v111, 15, v112                          // 0000003BF444: D6570066 05C11F6F
	v_and_or_b32 v105, v105, 15, v110                          // 0000003BF44C: D6570069 05B91F69
	v_lshrrev_b32_e32 v110, 28, v4                             // 0000003BF454: 32DC089C
	v_and_or_b32 v103, v113, 15, v109                          // 0000003BF458: D6570067 05B51F71
	v_cvt_f32_ubyte0_e32 v2, v2                                // 0000003BF460: 7E042302
	v_cvt_f32_ubyte0_e32 v102, v102                            // 0000003BF464: 7ECC2366
	v_cvt_f32_ubyte0_e32 v105, v105                            // 0000003BF468: 7ED22369
	v_and_or_b32 v6, v6, 48, v110                              // 0000003BF46C: D6570006 05B96106
	v_bfe_u32 v110, v100, 16, 1                                // 0000003BF474: D610006E 02052164
	v_cvt_f32_ubyte0_e32 v103, v103                            // 0000003BF47C: 7ECE2367
	v_fma_mix_f32 v2, v2, v8, v8 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003BF480: CC206002 14221102
	v_fma_mix_f32 v105, v105, v8, v8 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003BF488: CC206069 14221169
	v_cvt_f32_ubyte0_e32 v6, v6                                // 0000003BF490: 7E0C2306
	v_add3_u32 v100, v100, v110, 0x7fff                        // 0000003BF494: D6550064 03FEDD64 00007FFF
	v_fma_mix_f32 v102, v102, v8, v8 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003BF4A0: CC206066 14221166
	.long 0x7fd839d9                                           // 0000003BF4A8: 7FD839D9
	v_bfe_u32 v114, v105, 16, 1                                // 0000003BF4AC: D6100072 02052169
	v_fma_mix_f32 v6, v6, v8, v8 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003BF4B4: CC206006 14221106
	.long 0x7fd639d9                                           // 0000003BF4BC: 7FD639D9
	v_bfe_u32 v110, v102, 16, 1                                // 0000003BF4C0: D610006E 02052166
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003BF4C8: BF870114
	v_add3_u32 v105, v105, v114, 0x7fff                        // 0000003BF4CC: D6550069 03FEE569 00007FFF
	v_add3_u32 v102, v102, v110, 0x7fff                        // 0000003BF4D8: D6550066 03FEDD66 00007FFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000003BF4E4: BF870122
	.long 0x7eb239e9                                           // 0000003BF4E8: 7EB239E9
	v_bfe_u32 v105, v2, 16, 1                                  // 0000003BF4EC: D6100069 02052102
	v_and_or_b32 v100, 0xffff0000, v100, v89                   // 0000003BF4F4: D6570064 0566C8FF FFFF0000
	.long 0x7eb23984                                           // 0000003BF500: 7EB23984
	v_cvt_f32_ubyte0_e32 v4, v5                                // 0000003BF504: 7E082305
	v_fma_mix_f32 v5, v97, v8, v8 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003BF508: CC206005 14221161
	v_cvt_f32_ubyte0_e32 v97, v101                             // 0000003BF510: 7EC22365
	v_add3_u32 v2, v2, v105, 0x7fff                            // 0000003BF514: D6550002 03FED302 00007FFF
	v_and_or_b32 v101, v89, 15, v106                           // 0000003BF520: D6570065 05A91F59
	v_fma_mix_f32 v4, v4, v8, v8 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003BF528: CC206004 14221104
	v_bfe_u32 v104, v5, 16, 1                                  // 0000003BF530: D6100068 02052105
	v_fma_mix_f32 v97, v97, v8, v8 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003BF538: CC206061 14221161
	.long 0x7ed83982                                           // 0000003BF540: 7ED83982
	v_cvt_f32_ubyte0_e32 v101, v101                            // 0000003BF544: 7ECA2365
	v_bfe_u32 v106, v4, 16, 1                                  // 0000003BF548: D610006A 02052104
	v_add3_u32 v5, v5, v104, 0x7fff                            // 0000003BF550: D6550005 03FED105 00007FFF
	v_bfe_u32 v104, v97, 16, 1                                 // 0000003BF55C: D6100068 02052161
	s_delay_alu instid0(VALU_DEP_4)                            // 0000003BF564: BF870004
	v_fma_mix_f32 v101, v101, v8, v8 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003BF568: CC206065 14221165
	v_fma_mix_f32 v8, v103, v8, v8 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003BF570: CC206008 14221167
	v_add3_u32 v4, v4, v106, 0x7fff                            // 0000003BF578: D6550004 03FED504 00007FFF
	.long 0x7ed63985                                           // 0000003BF584: 7ED63985
	v_add3_u32 v5, v97, v104, 0x7fff                           // 0000003BF588: D6550005 03FED161 00007FFF
	v_bfe_u32 v109, v101, 16, 1                                // 0000003BF594: D610006D 02052165
	v_bfe_u32 v111, v8, 16, 1                                  // 0000003BF59C: D610006F 02052108
	v_and_or_b32 v4, 0xffff0000, v4, v108                      // 0000003BF5A4: D6570004 05B208FF FFFF0000
	v_bfe_u32 v103, v6, 16, 1                                  // 0000003BF5B0: D6100067 02052106
	v_and_or_b32 v5, 0xffff0000, v5, v107                      // 0000003BF5B8: D6570005 05AE0AFF FFFF0000
	v_add3_u32 v101, v101, v109, 0x7fff                        // 0000003BF5C4: D6550065 03FEDB65 00007FFF
	v_add3_u32 v8, v8, v111, 0x7fff                            // 0000003BF5D0: D6550008 03FEDF08 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003BF5DC: BF870194
	v_add3_u32 v6, v6, v103, 0x7fff                            // 0000003BF5E0: D6550006 03FECF06 00007FFF
	.long 0x7eb239e5                                           // 0000003BF5EC: 7EB239E5
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003BF5F0: BF870211
	v_and_or_b32 v2, 0xffff0000, v102, v89                     // 0000003BF5F4: D6570002 0566CCFF FFFF0000
	.long 0x7eb23988                                           // 0000003BF600: 7EB23988
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003BF604: BF870001
	v_and_or_b32 v6, 0xffff0000, v6, v89                       // 0000003BF608: D6570006 05660CFF FFFF0000
	s_waitcnt vmcnt(19)                                        // 0000003BF614: BF894FF7
	v_dot2_f32_bf16 v8, v9, v91, 0                             // 0000003BF618: CC1A4008 1A02B709
	s_waitcnt vmcnt(18)                                        // 0000003BF620: BF894BF7
	v_dot2_f32_bf16 v9, v13, v91, 0                            // 0000003BF624: CC1A4009 1A02B70D
	s_waitcnt vmcnt(17)                                        // 0000003BF62C: BF8947F7
	v_dot2_f32_bf16 v13, v17, v91, 0                           // 0000003BF630: CC1A400D 1A02B711
	s_waitcnt vmcnt(16)                                        // 0000003BF638: BF8943F7
	v_dot2_f32_bf16 v17, v21, v91, 0                           // 0000003BF63C: CC1A4011 1A02B715
	s_waitcnt vmcnt(15)                                        // 0000003BF644: BF893FF7
	v_dot2_f32_bf16 v21, v25, v91, 0                           // 0000003BF648: CC1A4015 1A02B719
	v_dot2_f32_bf16 v8, v10, v95, v8                           // 0000003BF650: CC1A4008 1C22BF0A
	v_dot2_f32_bf16 v9, v14, v95, v9                           // 0000003BF658: CC1A4009 1C26BF0E
	v_dot2_f32_bf16 v10, v18, v95, v13                         // 0000003BF660: CC1A400A 1C36BF12
	v_dot2_f32_bf16 v13, v22, v95, v17                         // 0000003BF668: CC1A400D 1C46BF16
	v_dot2_f32_bf16 v14, v26, v95, v21                         // 0000003BF670: CC1A400E 1C56BF1A
	v_dot2_f32_bf16 v8, v11, v90, v8                           // 0000003BF678: CC1A4008 1C22B50B
	v_dot2_f32_bf16 v9, v15, v90, v9                           // 0000003BF680: CC1A4009 1C26B50F
	v_dot2_f32_bf16 v10, v19, v90, v10                         // 0000003BF688: CC1A400A 1C2AB513
	v_dot2_f32_bf16 v11, v23, v90, v13                         // 0000003BF690: CC1A400B 1C36B517
	v_dot2_f32_bf16 v13, v27, v90, v14                         // 0000003BF698: CC1A400D 1C3AB51B
	v_dot2_f32_bf16 v8, v12, v1, v8                            // 0000003BF6A0: CC1A4008 1C22030C
	v_dot2_f32_bf16 v9, v16, v1, v9                            // 0000003BF6A8: CC1A4009 1C260310
	v_dot2_f32_bf16 v10, v20, v1, v10                          // 0000003BF6B0: CC1A400A 1C2A0314
	v_dot2_f32_bf16 v11, v24, v1, v11                          // 0000003BF6B8: CC1A400B 1C2E0318
	v_dot2_f32_bf16 v1, v28, v1, v13                           // 0000003BF6C0: CC1A4001 1C36031C
	s_waitcnt vmcnt(14)                                        // 0000003BF6C8: BF893BF7
	v_dot2_f32_bf16 v8, v29, v4, v8                            // 0000003BF6CC: CC1A4008 1C22091D
	s_waitcnt vmcnt(13)                                        // 0000003BF6D4: BF8937F7
	v_dot2_f32_bf16 v9, v33, v4, v9                            // 0000003BF6D8: CC1A4009 1C260921
	s_waitcnt vmcnt(12)                                        // 0000003BF6E0: BF8933F7
	v_dot2_f32_bf16 v10, v37, v4, v10                          // 0000003BF6E4: CC1A400A 1C2A0925
	s_waitcnt vmcnt(11)                                        // 0000003BF6EC: BF892FF7
	v_dot2_f32_bf16 v11, v41, v4, v11                          // 0000003BF6F0: CC1A400B 1C2E0929
	s_waitcnt vmcnt(10)                                        // 0000003BF6F8: BF892BF7
	v_dot2_f32_bf16 v1, v45, v4, v1                            // 0000003BF6FC: CC1A4001 1C06092D
	v_dot2_f32_bf16 v4, v30, v93, v8                           // 0000003BF704: CC1A4004 1C22BB1E
	v_dot2_f32_bf16 v8, v34, v93, v9                           // 0000003BF70C: CC1A4008 1C26BB22
	v_dot2_f32_bf16 v9, v38, v93, v10                          // 0000003BF714: CC1A4009 1C2ABB26
	v_dot2_f32_bf16 v10, v42, v93, v11                         // 0000003BF71C: CC1A400A 1C2EBB2A
	v_dot2_f32_bf16 v1, v46, v93, v1                           // 0000003BF724: CC1A4001 1C06BB2E
	v_dot2_f32_bf16 v4, v31, v94, v4                           // 0000003BF72C: CC1A4004 1C12BD1F
	v_dot2_f32_bf16 v8, v35, v94, v8                           // 0000003BF734: CC1A4008 1C22BD23
	v_dot2_f32_bf16 v9, v39, v94, v9                           // 0000003BF73C: CC1A4009 1C26BD27
	v_dot2_f32_bf16 v10, v43, v94, v10                         // 0000003BF744: CC1A400A 1C2ABD2B
	v_dot2_f32_bf16 v1, v47, v94, v1                           // 0000003BF74C: CC1A4001 1C06BD2F
	v_dot2_f32_bf16 v4, v32, v92, v4                           // 0000003BF754: CC1A4004 1C12B920
	v_dot2_f32_bf16 v8, v36, v92, v8                           // 0000003BF75C: CC1A4008 1C22B924
	v_dot2_f32_bf16 v9, v40, v92, v9                           // 0000003BF764: CC1A4009 1C26B928
	v_dot2_f32_bf16 v10, v44, v92, v10                         // 0000003BF76C: CC1A400A 1C2AB92C
	v_dot2_f32_bf16 v1, v48, v92, v1                           // 0000003BF774: CC1A4001 1C06B930
	s_waitcnt vmcnt(9)                                         // 0000003BF77C: BF8927F7
	v_dot2_f32_bf16 v4, v49, v99, v4                           // 0000003BF780: CC1A4004 1C12C731
	s_waitcnt vmcnt(8)                                         // 0000003BF788: BF8923F7
	v_dot2_f32_bf16 v8, v53, v99, v8                           // 0000003BF78C: CC1A4008 1C22C735
	s_waitcnt vmcnt(7)                                         // 0000003BF794: BF891FF7
	v_dot2_f32_bf16 v9, v57, v99, v9                           // 0000003BF798: CC1A4009 1C26C739
	s_waitcnt vmcnt(6)                                         // 0000003BF7A0: BF891BF7
	v_dot2_f32_bf16 v10, v61, v99, v10                         // 0000003BF7A4: CC1A400A 1C2AC73D
	s_waitcnt vmcnt(5)                                         // 0000003BF7AC: BF8917F7
	v_dot2_f32_bf16 v1, v65, v99, v1                           // 0000003BF7B0: CC1A4001 1C06C741
	v_dot2_f32_bf16 v4, v50, v98, v4                           // 0000003BF7B8: CC1A4004 1C12C532
	v_dot2_f32_bf16 v8, v54, v98, v8                           // 0000003BF7C0: CC1A4008 1C22C536
	v_dot2_f32_bf16 v9, v58, v98, v9                           // 0000003BF7C8: CC1A4009 1C26C53A
	v_dot2_f32_bf16 v10, v62, v98, v10                         // 0000003BF7D0: CC1A400A 1C2AC53E
	v_dot2_f32_bf16 v1, v66, v98, v1                           // 0000003BF7D8: CC1A4001 1C06C542
	v_dot2_f32_bf16 v4, v51, v96, v4                           // 0000003BF7E0: CC1A4004 1C12C133
	v_dot2_f32_bf16 v8, v55, v96, v8                           // 0000003BF7E8: CC1A4008 1C22C137
	v_dot2_f32_bf16 v9, v59, v96, v9                           // 0000003BF7F0: CC1A4009 1C26C13B
	v_dot2_f32_bf16 v10, v63, v96, v10                         // 0000003BF7F8: CC1A400A 1C2AC13F
	v_dot2_f32_bf16 v1, v67, v96, v1                           // 0000003BF800: CC1A4001 1C06C143
	v_dot2_f32_bf16 v4, v52, v3, v4                            // 0000003BF808: CC1A4004 1C120734
	v_dot2_f32_bf16 v8, v56, v3, v8                            // 0000003BF810: CC1A4008 1C220738
	v_dot2_f32_bf16 v9, v60, v3, v9                            // 0000003BF818: CC1A4009 1C26073C
	v_dot2_f32_bf16 v10, v64, v3, v10                          // 0000003BF820: CC1A400A 1C2A0740
	v_dot2_f32_bf16 v1, v68, v3, v1                            // 0000003BF828: CC1A4001 1C060744
	s_waitcnt vmcnt(4)                                         // 0000003BF830: BF8913F7
	v_dot2_f32_bf16 v3, v69, v5, v4                            // 0000003BF834: CC1A4003 1C120B45
	s_waitcnt vmcnt(3)                                         // 0000003BF83C: BF890FF7
	v_dot2_f32_bf16 v4, v73, v5, v8                            // 0000003BF840: CC1A4004 1C220B49
	s_waitcnt vmcnt(2)                                         // 0000003BF848: BF890BF7
	v_dot2_f32_bf16 v8, v77, v5, v9                            // 0000003BF84C: CC1A4008 1C260B4D
	s_waitcnt vmcnt(1)                                         // 0000003BF854: BF8907F7
	v_dot2_f32_bf16 v9, v81, v5, v10                           // 0000003BF858: CC1A4009 1C2A0B51
	s_waitcnt vmcnt(0)                                         // 0000003BF860: BF8903F7
	v_dot2_f32_bf16 v1, v85, v5, v1                            // 0000003BF864: CC1A4001 1C060B55
	v_dot2_f32_bf16 v3, v70, v100, v3                          // 0000003BF86C: CC1A4003 1C0EC946
	v_dot2_f32_bf16 v4, v74, v100, v4                          // 0000003BF874: CC1A4004 1C12C94A
	v_dot2_f32_bf16 v5, v78, v100, v8                          // 0000003BF87C: CC1A4005 1C22C94E
	v_dot2_f32_bf16 v8, v82, v100, v9                          // 0000003BF884: CC1A4008 1C26C952
	v_dot2_f32_bf16 v1, v86, v100, v1                          // 0000003BF88C: CC1A4001 1C06C956
	v_dot2_f32_bf16 v3, v71, v2, v3                            // 0000003BF894: CC1A4003 1C0E0547
	v_dot2_f32_bf16 v4, v75, v2, v4                            // 0000003BF89C: CC1A4004 1C12054B
	v_dot2_f32_bf16 v5, v79, v2, v5                            // 0000003BF8A4: CC1A4005 1C16054F
	v_dot2_f32_bf16 v8, v83, v2, v8                            // 0000003BF8AC: CC1A4008 1C220553
	v_dot2_f32_bf16 v1, v87, v2, v1                            // 0000003BF8B4: CC1A4001 1C060557
	v_dot2_f32_bf16 v2, v72, v6, v3                            // 0000003BF8BC: CC1A4002 1C0E0D48
	v_dot2_f32_bf16 v3, v76, v6, v4                            // 0000003BF8C4: CC1A4003 1C120D4C
	v_dot2_f32_bf16 v4, v80, v6, v5                            // 0000003BF8CC: CC1A4004 1C160D50
	v_dot2_f32_bf16 v5, v84, v6, v8                            // 0000003BF8D4: CC1A4005 1C220D54
	v_dot2_f32_bf16 v1, v88, v6, v1                            // 0000003BF8DC: CC1A4001 1C060D58
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003BF8E4: BF870194
	v_dual_add_f32 v12, 0, v2 :: v_dual_add_f32 v13, 0, v3     // 0000003BF8E8: C9080480 0C0C0680
	v_dual_add_f32 v9, 0, v4 :: v_dual_add_f32 v10, 0, v5      // 0000003BF8F0: C9080880 090A0A80
	s_delay_alu instid0(VALU_DEP_3)                            // 0000003BF8F8: BF870003
	v_add_f32_e32 v11, 0, v1                                   // 0000003BF8FC: 06160280
	s_or_b32 exec_lo, exec_lo, s4                              // 0000003BF900: 8C7E047E
	.long 0xd71f0001                                           // 0000003BF904: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000003BF908: 020100C1
	s_mov_b32 s3, exec_lo                                      // 0000003BF90C: BE83007E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000003BF910: BF870121
	v_xor_b32_e32 v2, 8, v1                                    // 0000003BF914: 3A040288
	v_xor_b32_e32 v8, 4, v1                                    // 0000003BF918: 3A100284
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 0000003BF91C: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 0000003BF920: 02040501
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003BF924: BF870113
	v_cmp_gt_u32_e32 vcc_lo, 32, v8                            // 0000003BF928: 7C9810A0
	v_lshlrev_b32_e32 v2, 2, v2                                // 0000003BF92C: 30040482
	v_cndmask_b32_e32 v8, v1, v8, vcc_lo                       // 0000003BF930: 02101101
	ds_bpermute_b32 v5, v2, v9                                 // 0000003BF934: DACC0000 05000902
	s_waitcnt lgkmcnt(0)                                       // 0000003BF93C: BF89FC07
	v_add_f32_e32 v5, v9, v5                                   // 0000003BF940: 060A0B09
	ds_bpermute_b32 v4, v2, v13                                // 0000003BF944: DACC0000 04000D02
	ds_bpermute_b32 v6, v2, v10                                // 0000003BF94C: DACC0000 06000A02
	ds_bpermute_b32 v3, v2, v12                                // 0000003BF954: DACC0000 03000C02
	ds_bpermute_b32 v2, v2, v11                                // 0000003BF95C: DACC0000 02000B02
	s_waitcnt lgkmcnt(3)                                       // 0000003BF964: BF89FC37
	v_add_f32_e32 v4, v13, v4                                  // 0000003BF968: 0608090D
	v_xor_b32_e32 v13, 2, v1                                   // 0000003BF96C: 3A1A0282
	s_waitcnt lgkmcnt(0)                                       // 0000003BF970: BF89FC07
	v_dual_add_f32 v3, v12, v3 :: v_dual_add_f32 v2, v11, v2   // 0000003BF974: C908070C 0302050B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003BF97C: BF8700A2
	v_cmp_gt_u32_e32 vcc_lo, 32, v13                           // 0000003BF980: 7C981AA0
	v_dual_add_f32 v6, v10, v6 :: v_dual_cndmask_b32 v13, v1, v13// 0000003BF984: C9120D0A 060C1B01
	v_lshlrev_b32_e32 v13, 2, v13                              // 0000003BF98C: 301A1A82
	v_lshlrev_b32_e32 v8, 2, v8                                // 0000003BF990: 30101082
	ds_bpermute_b32 v9, v8, v3                                 // 0000003BF994: DACC0000 09000308
	s_waitcnt lgkmcnt(0)                                       // 0000003BF99C: BF89FC07
	v_add_f32_e32 v3, v3, v9                                   // 0000003BF9A0: 06061303
	ds_bpermute_b32 v11, v8, v5                                // 0000003BF9A4: DACC0000 0B000508
	ds_bpermute_b32 v10, v8, v4                                // 0000003BF9AC: DACC0000 0A000408
	ds_bpermute_b32 v12, v8, v6                                // 0000003BF9B4: DACC0000 0C000608
	s_waitcnt lgkmcnt(2)                                       // 0000003BF9BC: BF89FC27
	v_add_f32_e32 v5, v5, v11                                  // 0000003BF9C0: 060A1705
	ds_bpermute_b32 v8, v8, v2                                 // 0000003BF9C4: DACC0000 08000208
	s_waitcnt lgkmcnt(2)                                       // 0000003BF9CC: BF89FC27
	v_add_f32_e32 v4, v4, v10                                  // 0000003BF9D0: 06081504
	ds_bpermute_b32 v10, v13, v5                               // 0000003BF9D4: DACC0000 0A00050D
	ds_bpermute_b32 v9, v13, v4                                // 0000003BF9DC: DACC0000 0900040D
	s_waitcnt lgkmcnt(3)                                       // 0000003BF9E4: BF89FC37
	v_add_f32_e32 v6, v6, v12                                  // 0000003BF9E8: 060C1906
	ds_bpermute_b32 v11, v13, v6                               // 0000003BF9EC: DACC0000 0B00060D
	s_waitcnt lgkmcnt(3)                                       // 0000003BF9F4: BF89FC37
	v_add_f32_e32 v2, v2, v8                                   // 0000003BF9F8: 06041102
	ds_bpermute_b32 v8, v13, v3                                // 0000003BF9FC: DACC0000 0800030D
	ds_bpermute_b32 v12, v13, v2                               // 0000003BFA04: DACC0000 0C00020D
	v_xor_b32_e32 v13, 1, v1                                   // 0000003BFA0C: 3A1A0281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 0000003BFA10: BF870151
	v_cmp_gt_u32_e32 vcc_lo, 32, v13                           // 0000003BFA14: 7C981AA0
	v_cndmask_b32_e32 v1, v1, v13, vcc_lo                      // 0000003BFA18: 02021B01
	s_waitcnt lgkmcnt(3)                                       // 0000003BFA1C: BF89FC37
	v_dual_add_f32 v9, v4, v9 :: v_dual_add_f32 v4, v5, v10    // 0000003BFA20: C9081304 09041505
	s_waitcnt lgkmcnt(1)                                       // 0000003BFA28: BF89FC17
	v_dual_add_f32 v8, v3, v8 :: v_dual_lshlrev_b32 v13, 2, v1 // 0000003BFA2C: C9221103 080C0282
	v_add_f32_e32 v3, v6, v11                                  // 0000003BFA34: 06061706
	s_waitcnt lgkmcnt(0)                                       // 0000003BFA38: BF89FC07
	v_add_f32_e32 v1, v2, v12                                  // 0000003BFA3C: 06021902
	ds_bpermute_b32 v11, v13, v9                               // 0000003BFA40: DACC0000 0B00090D
	ds_bpermute_b32 v10, v13, v8                               // 0000003BFA48: DACC0000 0A00080D
	ds_bpermute_b32 v6, v13, v4                                // 0000003BFA50: DACC0000 0600040D
	ds_bpermute_b32 v5, v13, v3                                // 0000003BFA58: DACC0000 0500030D
	ds_bpermute_b32 v2, v13, v1                                // 0000003BFA60: DACC0000 0200010D
	v_cmpx_eq_u32_e32 0, v7                                    // 0000003BFA68: 7D940E80
	s_cbranch_execz 46                                         // 0000003BFA6C: BFA5002E <_ZN7halogen12_GLOBAL__N_112k_hc6_fused3ILi5EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0xf28>
	s_waitcnt lgkmcnt(3)                                       // 0000003BFA70: BF89FC37
	v_dual_add_f32 v7, v9, v11 :: v_dual_add_f32 v8, v8, v10   // 0000003BFA74: C9081709 07081508
	s_waitcnt lgkmcnt(1)                                       // 0000003BFA7C: BF89FC17
	v_dual_add_f32 v4, v4, v6 :: v_dual_add_f32 v3, v3, v5     // 0000003BFA80: C9080D04 04020B03
	.long 0x7f0c3880                                           // 0000003BFA88: 7F0C3880
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000003BFA8C: BF870223
	.long 0x7e0c3987                                           // 0000003BFA90: 7E0C3987
	.long 0x7e123988                                           // 0000003BFA94: 7E123988
	.long 0x7e0a3984                                           // 0000003BFA98: 7E0A3984
	v_lshrrev_b32_e32 v10, 4, v0                               // 0000003BFA9C: 32140084
	.long 0x7f0a3986                                           // 0000003BFAA0: 7F0A3986
	.long 0x7f123986                                           // 0000003BFAA4: 7F123986
	v_and_b32_e32 v11, 1, v6                                   // 0000003BFAA8: 36160C81
	.long 0x7e0c3983                                           // 0000003BFAAC: 7E0C3983
	s_waitcnt lgkmcnt(0)                                       // 0000003BFAB0: BF89FC07
	v_dual_add_f32 v12, v1, v2 :: v_dual_and_b32 v5, 1, v5     // 0000003BFAB4: C9240501 0C040A81
	v_and_b32_e32 v9, 1, v9                                    // 0000003BFABC: 36121281
	v_add3_u32 v1, v7, v11, 0x7fff                             // 0000003BFAC0: D6550001 03FE1707 00007FFF
	v_and_b32_e32 v2, 1, v6                                    // 0000003BFACC: 36040C81
	s_delay_alu instid0(VALU_DEP_4)                            // 0000003BFAD0: BF870004
	v_bfe_u32 v6, v12, 16, 1                                   // 0000003BFAD4: D6100006 0205210C
	v_add3_u32 v4, v4, v5, 0x7fff                              // 0000003BFADC: D6550004 03FE0B04 00007FFF
	v_add3_u32 v5, v8, v9, 0x7fff                              // 0000003BFAE8: D6550005 03FE1308 00007FFF
	v_mul_u32_u24_e32 v10, 10, v10                             // 0000003BFAF4: 1614148A
	v_add3_u32 v2, v3, v2, 0x7fff                              // 0000003BFAF8: D6550002 03FE0503 00007FFF
	v_add3_u32 v3, v12, v6, 0x7fff                             // 0000003BFB04: D6550003 03FE0D0C 00007FFF
	.long 0x7e043984                                           // 0000003BFB10: 7E043984
	.long 0x7e023985                                           // 0000003BFB14: 7E023985
	ds_store_b64 v10, v[1:2] offset:1024                       // 0000003BFB18: D9340400 0000010A
	ds_store_b16_d16_hi v10, v3 offset:1032                    // 0000003BFB20: DA840408 0000030A
	s_or_b32 exec_lo, exec_lo, s3                              // 0000003BFB28: 8C7E037E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000003BFB2C: BF870009
	s_mov_b32 s6, exec_lo                                      // 0000003BFB30: BE86007E
	s_waitcnt lgkmcnt(0)                                       // 0000003BFB34: BF89FC07
	s_barrier                                                  // 0000003BFB38: BFBD0000
	buffer_gl0_inv                                             // 0000003BFB3C: E0AC0000 00000000
	v_cmpx_gt_u32_e32 20, v0                                   // 0000003BFB44: 7D980094
	s_cbranch_execz 260                                        // 0000003BFB48: BFA50104 <_ZN7halogen12_GLOBAL__N_112k_hc6_fused3ILi5EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x135c>
	.long 0xd7050001                                           // 0000003BFB4C: D7050001
	v_cndmask_b32_e32 v1, 0xcd, v0, vcc_lo                     // 0000003BFB50: 020200FF 000000CD
	.long 0x7f163880                                           // 0000003BFB58: 7F163880
	s_cmp_eq_u64 s[10:11], 0                                   // 0000003BFB5C: BF10800A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003BFB60: BF870092
	.long 0xd739000b                                           // 0000003BFB64: D739000B
	v_cndmask_b32_e32 v1, 10, v1, vcc_lo                       // 0000003BFB68: 0202028A
	.long 0xd7050001                                           // 0000003BFB6C: D7050001
	v_cndmask_b32_e32 v0, v11, v133, vcc_lo                    // 0000003BFB70: 02010B0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000003BFB74: BF870121
	.long 0xd7040002                                           // 0000003BFB78: D7040002
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 0000003BFB7C: 02020300
	v_add_nc_u32_e32 v1, s25, v11                              // 0000003BFB80: 4A021619
	v_and_b32_e32 v12, 0xff, v2                                // 0000003BFB84: 361804FF 000000FF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003BFB8C: BF870112
	v_ashrrev_i32_e32 v2, 31, v1                               // 0000003BFB90: 3404029F
	v_mad_u64_u32 v[3:4], null, 0x5000, v12, s[20:21]          // 0000003BFB94: D6FE7C03 005218FF 00005000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003BFBA0: BF870092
	.long 0xd73c0005                                           // 0000003BFBA4: D73C0005
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 0000003BFBA8: 02020281
	.long 0xd7006a03                                           // 0000003BFBAC: D7006A03
	v_cndmask_b32_e32 v1, v3, v5, vcc_lo                       // 0000003BFBB0: 02020B03
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003BFBB4: BF870111
	v_add_co_ci_u32_e64 v4, null, v4, v6, vcc_lo               // 0000003BFBB8: D5207C04 01AA0D04
	.long 0xd7006a05                                           // 0000003BFBC0: D7006A05
	v_cndmask_b32_e32 v1, 0x2000, v3, vcc_lo                   // 0000003BFBC4: 020206FF 00002000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003BFBCC: BF8700A1
	v_add_co_ci_u32_e64 v6, null, 0, v4, vcc_lo                // 0000003BFBD0: D5207C06 01AA0880
	.long 0xd7006a07                                           // 0000003BFBD8: D7006A07
	v_cndmask_b32_e32 v1, 0x3000, v3, vcc_lo                   // 0000003BFBDC: 020206FF 00003000
	v_add_co_ci_u32_e64 v8, null, 0, v4, vcc_lo                // 0000003BFBE4: D5207C08 01AA0880
	.long 0xd7006a09                                           // 0000003BFBEC: D7006A09
	v_cndmask_b32_e32 v1, 0x1000, v3, vcc_lo                   // 0000003BFBF0: 020206FF 00001000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003BFBF8: BF870001
	v_add_co_ci_u32_e64 v10, null, 0, v4, vcc_lo               // 0000003BFBFC: D5207C0A 01AA0880
	s_clause 0x3                                               // 0000003BFC04: BF850003
	global_load_u16 v5, v[5:6], off offset:2048                // 0000003BFC08: DC4A0800 057C0005
	global_load_u16 v6, v[7:8], off offset:3072                // 0000003BFC10: DC4A0C00 067C0007
	global_load_u16 v3, v[3:4], off                            // 0000003BFC18: DC4A0000 037C0003
	global_load_u16 v4, v[9:10], off offset:1024               // 0000003BFC20: DC4A0400 047C0009
	v_mul_u32_u24_e32 v7, 40, v11                              // 0000003BFC28: 160E16A8
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003BFC2C: BF870001
	v_lshl_add_u32 v7, v12, 1, v7                              // 0000003BFC30: D6460007 041D030C
	ds_load_u16 v8, v7 offset:1024                             // 0000003BFC38: D8F00400 08000007
	ds_load_u16 v9, v7 offset:1034                             // 0000003BFC40: D8F0040A 09000007
	ds_load_u16 v10, v7 offset:1044                            // 0000003BFC48: D8F00414 0A000007
	ds_load_u16 v7, v7 offset:1054                             // 0000003BFC50: D8F0041E 07000007
	s_waitcnt lgkmcnt(0)                                       // 0000003BFC58: BF89FC07
	v_lshlrev_b32_e32 v7, 16, v7                               // 0000003BFC5C: 300E0E90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003BFC60: BF870091
	v_dual_mul_f32 v7, 0xbfb8aa3b, v7 :: v_dual_lshlrev_b32 v10, 16, v10// 0000003BFC64: C8E20EFF 070A1490 BFB8AA3B
	v_dual_mul_f32 v10, 0xbfb8aa3b, v10 :: v_dual_lshlrev_b32 v9, 16, v9// 0000003BFC70: C8E214FF 0A081290 BFB8AA3B
	v_lshlrev_b32_e32 v8, 16, v8                               // 0000003BFC7C: 30101090
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003BFC80: BF870113
	v_exp_f32_e32 v7, v7                                       // 0000003BFC84: 7E0E4B07
	v_mul_f32_e32 v9, 0xbfb8aa3b, v9                           // 0000003BFC88: 101212FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003BFC90: BF870113
	v_exp_f32_e32 v10, v10                                     // 0000003BFC94: 7E144B0A
	v_mul_f32_e32 v8, 0xbfb8aa3b, v8                           // 0000003BFC98: 101010FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003BFCA0: BF870092
	v_exp_f32_e32 v9, v9                                       // 0000003BFCA4: 7E124B09
	v_exp_f32_e32 v8, v8                                       // 0000003BFCA8: 7E104B08
	s_delay_alu instid0(TRANS32_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003BFCAC: BF870097
	v_dual_add_f32 v7, 1.0, v7 :: v_dual_add_f32 v10, 1.0, v10 // 0000003BFCB0: C9080EF2 070A14F2
	v_div_scale_f32 v15, null, v7, v7, 1.0                     // 0000003BFCB8: D6FC7C0F 03CA0F07
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003BFCC0: BF870196
	v_add_f32_e32 v9, 1.0, v9                                  // 0000003BFCC4: 061212F2
	v_div_scale_f32 v14, null, v10, v10, 1.0                   // 0000003BFCC8: D6FC7C0E 03CA150A
	s_delay_alu instid0(TRANS32_DEP_1)                         // 0000003BFCD0: BF870005
	v_add_f32_e32 v8, 1.0, v8                                  // 0000003BFCD4: 061010F2
	v_div_scale_f32 v25, s4, 1.0, v10, 1.0                     // 0000003BFCD8: D6FC0419 03CA14F2
	v_rcp_f32_e32 v19, v15                                     // 0000003BFCE0: 7E26550F
	v_div_scale_f32 v13, null, v9, v9, 1.0                     // 0000003BFCE4: D6FC7C0D 03CA1309
	v_rcp_f32_e32 v18, v14                                     // 0000003BFCEC: 7E24550E
	v_div_scale_f32 v11, null, v8, v8, 1.0                     // 0000003BFCF0: D6FC7C0B 03CA1108
	v_div_scale_f32 v20, vcc_lo, 1.0, v8, 1.0                  // 0000003BFCF8: D6FC6A14 03CA10F2
	v_div_scale_f32 v21, s3, 1.0, v9, 1.0                      // 0000003BFD00: D6FC0315 03CA12F2
	v_rcp_f32_e32 v17, v13                                     // 0000003BFD08: 7E22550D
	v_mad_u64_u32 v[1:2], null, 0xa00, v12, v[1:2]             // 0000003BFD0C: D6FE7C01 040618FF 00000A00
	v_rcp_f32_e32 v16, v11                                     // 0000003BFD18: 7E20550B
	v_fma_f32 v26, -v15, v19, 1.0                              // 0000003BFD1C: D613001A 23CA270F
	s_delay_alu instid0(TRANS32_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003BFD24: BF870117
	v_fma_f32 v24, -v14, v18, 1.0                              // 0000003BFD28: D6130018 23CA250E
	v_fmac_f32_e32 v19, v26, v19                               // 0000003BFD30: 5626271A
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003BFD34: BF870196
	v_fma_f32 v23, -v13, v17, 1.0                              // 0000003BFD38: D6130017 23CA230D
	v_fmac_f32_e32 v18, v24, v18                               // 0000003BFD40: 56242518
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003BFD44: BF870095
	v_fma_f32 v22, -v11, v16, 1.0                              // 0000003BFD48: D6130016 23CA210B
	v_dual_fmac_f32 v17, v23, v17 :: v_dual_fmac_f32 v16, v22, v16// 0000003BFD50: C8002317 11102116
	v_div_scale_f32 v22, s5, 1.0, v7, 1.0                      // 0000003BFD58: D6FC0516 03CA0EF2
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003BFD60: BF870194
	v_mul_f32_e32 v26, v25, v18                                // 0000003BFD64: 10342519
	v_dual_mul_f32 v24, v21, v17 :: v_dual_mul_f32 v23, v20, v16// 0000003BFD68: C8C62315 18162114
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003BFD70: BF870193
	v_mul_f32_e32 v27, v22, v19                                // 0000003BFD74: 10362716
	v_fma_f32 v30, -v14, v26, v25                              // 0000003BFD78: D613001E 2466350E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003BFD80: BF870213
	v_fma_f32 v29, -v13, v24, v21                              // 0000003BFD84: D613001D 2456310D
	v_fma_f32 v28, -v11, v23, v20                              // 0000003BFD8C: D613001C 24522F0B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003BFD94: BF870214
	v_fma_f32 v31, -v15, v27, v22                              // 0000003BFD98: D613001F 245A370F
	v_fmac_f32_e32 v26, v30, v18                               // 0000003BFDA0: 5634251E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003BFDA4: BF870193
	v_dual_fmac_f32 v24, v29, v17 :: v_dual_fmac_f32 v23, v28, v16// 0000003BFDA8: C800231D 1816211C
	v_fmac_f32_e32 v27, v31, v19                               // 0000003BFDB0: 5636271F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003BFDB4: BF870193
	v_fma_f32 v14, -v14, v26, v25                              // 0000003BFDB8: D613000E 2466350E
	v_fma_f32 v13, -v13, v24, v21                              // 0000003BFDC0: D613000D 2456310D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003BFDC8: BF870214
	v_fma_f32 v11, -v11, v23, v20                              // 0000003BFDCC: D613000B 24522F0B
	v_fma_f32 v15, -v15, v27, v22                              // 0000003BFDD4: D613000F 245A370F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000003BFDDC: BF870142
	v_div_fmas_f32 v11, v11, v16, v23                          // 0000003BFDE0: D637000B 045E210B
	s_mov_b32 vcc_lo, s3                                       // 0000003BFDE8: BEEA0003
	v_div_fmas_f32 v13, v13, v17, v24                          // 0000003BFDEC: D637000D 0462230D
	s_mov_b32 vcc_lo, s4                                       // 0000003BFDF4: BEEA0004
	v_div_fixup_f32 v8, v11, v8, 1.0                           // 0000003BFDF8: D6270008 03CA110B
	v_div_fmas_f32 v11, v14, v18, v26                          // 0000003BFE00: D637000B 046A250E
	s_mov_b32 vcc_lo, s5                                       // 0000003BFE08: BEEA0005
	v_div_fixup_f32 v9, v13, v9, 1.0                           // 0000003BFE0C: D6270009 03CA130D
	v_div_fmas_f32 v14, v15, v19, v27                          // 0000003BFE14: D637000E 046E270F
	v_bfe_u32 v13, v8, 16, 1                                   // 0000003BFE1C: D610000D 02052108
	v_div_fixup_f32 v10, v11, v10, 1.0                         // 0000003BFE24: D627000A 03CA150B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003BFE2C: BF870214
	v_bfe_u32 v11, v9, 16, 1                                   // 0000003BFE30: D610000B 02052109
	v_div_fixup_f32 v7, v14, v7, 1.0                           // 0000003BFE38: D6270007 03CA0F0E
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003BFE40: BF870214
	v_add3_u32 v8, v8, v13, 0x7fff                             // 0000003BFE44: D6550008 03FE1B08 00007FFF
	v_bfe_u32 v13, v10, 16, 1                                  // 0000003BFE50: D610000D 0205210A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003BFE58: BF870214
	v_add3_u32 v9, v9, v11, 0x7fff                             // 0000003BFE5C: D6550009 03FE1709 00007FFF
	v_bfe_u32 v11, v7, 16, 1                                   // 0000003BFE68: D610000B 02052107
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003BFE70: BF870193
	v_add3_u32 v10, v10, v13, 0x7fff                           // 0000003BFE74: D655000A 03FE1B0A 00007FFF
	v_and_b32_e32 v9, 0xffff0000, v9                           // 0000003BFE80: 361212FF FFFF0000
	s_delay_alu instid0(VALU_DEP_3)                            // 0000003BFE88: BF870003
	v_add3_u32 v7, v7, v11, 0x7fff                             // 0000003BFE8C: D6550007 03FE1707 00007FFF
	s_waitcnt vmcnt(3)                                         // 0000003BFE98: BF890FF7
	v_lshlrev_b32_e32 v5, 16, v5                               // 0000003BFE9C: 300A0A90
	s_waitcnt vmcnt(2)                                         // 0000003BFEA0: BF890BF7
	v_lshlrev_b32_e32 v6, 16, v6                               // 0000003BFEA4: 300C0C90
	s_waitcnt vmcnt(1)                                         // 0000003BFEA8: BF8907F7
	v_lshlrev_b32_e32 v3, 16, v3                               // 0000003BFEAC: 30060690
	s_waitcnt vmcnt(0)                                         // 0000003BFEB0: BF8903F7
	v_lshlrev_b32_e32 v4, 16, v4                               // 0000003BFEB4: 30080890
	v_and_b32_e32 v8, 0xffff0000, v8                           // 0000003BFEB8: 361010FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003BFEC0: BF870091
	v_fma_f32 v3, v3, v8, 0                                    // 0000003BFEC4: D6130003 02021103
	v_dual_fmac_f32 v3, v4, v9 :: v_dual_and_b32 v4, 0xffff0000, v7// 0000003BFECC: C8241304 03040EFF FFFF0000
	v_and_b32_e32 v8, 0xffff0000, v10                          // 0000003BFED8: 361014FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003BFEE0: BF870091
	v_fmac_f32_e32 v3, v5, v8                                  // 0000003BFEE4: 56061105
	v_fmac_f32_e32 v3, v6, v4                                  // 0000003BFEE8: 56060906
	.long 0xd73c0004                                           // 0000003BFEEC: D73C0004
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 0000003BFEF0: 02020281
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003BFEF4: BF870112
	v_mul_f32_e32 v3, 0x3e800000, v3                           // 0000003BFEF8: 100606FF 3E800000
	.long 0xd7006a04                                           // 0000003BFF00: D7006A04
	v_cndmask_b32_e32 v1, s8, v4, vcc_lo                       // 0000003BFF04: 02020808
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003BFF08: BF870191
	v_add_co_ci_u32_e64 v5, null, s9, v5, vcc_lo               // 0000003BFF0C: D5207C05 01AA0A09
	v_bfe_u32 v6, v3, 16, 1                                    // 0000003BFF14: D6100006 02052103
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003BFF1C: BF870001
	v_add3_u32 v6, v3, v6, 0x7fff                              // 0000003BFF20: D6550006 03FE0D03 00007FFF
	global_store_d16_hi_b16 v[4:5], v6, off                    // 0000003BFF2C: DC960000 007C0604
	s_cbranch_scc1 9                                           // 0000003BFF34: BFA20009 <_ZN7halogen12_GLOBAL__N_112k_hc6_fused3ILi5EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x135c>
	.long 0xd73c0001                                           // 0000003BFF38: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 0000003BFF3C: 02020282
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003BFF40: BF870091
	.long 0xd7006a01                                           // 0000003BFF44: D7006A01
	v_cndmask_b32_e32 v1, s10, v1, vcc_lo                      // 0000003BFF48: 0202020A
	v_add_co_ci_u32_e64 v2, null, s11, v2, vcc_lo              // 0000003BFF4C: D5207C02 01AA040B
	global_store_b32 v[1:2], v3, off                           // 0000003BFF54: DC6A0000 007C0301
	s_or_b32 exec_lo, exec_lo, s6                              // 0000003BFF5C: 8C7E067E
	s_mov_b32 s3, 0                                            // 0000003BFF60: BE830080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000003BFF64: BF870009
	s_and_b32 vcc_lo, exec_lo, s3                              // 0000003BFF68: 8B6A037E
	s_cbranch_vccz 1067                                        // 0000003BFF6C: BFA3042B <_ZN7halogen12_GLOBAL__N_112k_hc6_fused3ILi5EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x241c>
	s_clause 0x3                                               // 0000003BFF70: BF850003
	s_load_b32 s3, s[0:1], 0x148                               // 0000003BFF74: F40000C0 F8000148
	s_load_b32 s4, s[0:1], 0xb0                                // 0000003BFF7C: F4000100 F80000B0
	s_load_b32 s5, s[0:1], 0xf8                                // 0000003BFF84: F4000140 F80000F8
	s_load_b32 s6, s[0:1], 0x140                               // 0000003BFF8C: F4000180 F8000140
	s_sub_i32 s24, s2, s24                                     // 0000003BFF94: 81981802
	v_lshrrev_b32_e32 v5, 5, v0                                // 0000003BFF98: 320A0085
	v_and_b32_e32 v50, 31, v0                                  // 0000003BFF9C: 3664009F
	v_mov_b32_e32 v36, 0                                       // 0000003BFFA0: 7E480280
	v_dual_mov_b32 v68, 0 :: v_dual_mov_b32 v37, 0             // 0000003BFFA4: CA100080 44240080
	s_waitcnt lgkmcnt(0)                                       // 0000003BFFAC: BF89FC07
	s_cmp_gt_i32 s3, 1                                         // 0000003BFFB0: BF028103
	s_cselect_b32 s7, -1, 0                                    // 0000003BFFB4: 980780C1
	s_cmp_ge_i32 s24, s4                                       // 0000003BFFB8: BF030418
	s_cselect_b32 s4, -1, 0                                    // 0000003BFFBC: 980480C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000003BFFC0: BF870009
	s_and_b32 s4, s7, s4                                       // 0000003BFFC4: 8B040407
	s_cmp_gt_i32 s3, 2                                         // 0000003BFFC8: BF028203
	v_cndmask_b32_e64 v1, 0, 1, s4                             // 0000003BFFCC: D5010001 00110280
	s_cselect_b32 s7, -1, 0                                    // 0000003BFFD4: 980780C1
	s_cmp_ge_i32 s24, s5                                       // 0000003BFFD8: BF030518
	s_cselect_b32 s5, -1, 0                                    // 0000003BFFDC: 980580C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000003BFFE0: BF870009
	s_and_b32 s4, s7, s5                                       // 0000003BFFE4: 8B040507
	s_cmp_gt_i32 s3, 3                                         // 0000003BFFE8: BF028303
	v_readfirstlane_b32 s5, v1                                 // 0000003BFFEC: 7E0A0501
	s_cselect_b32 s3, -1, 0                                    // 0000003BFFF0: 980380C1
	s_cmp_ge_i32 s24, s6                                       // 0000003BFFF4: BF030618
	s_cselect_b32 s6, -1, 0                                    // 0000003BFFF8: 980680C1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(SALU_CYCLE_1)// 0000003BFFFC: BF8704D9
	s_and_b32 s3, s3, s6                                       // 0000003C0000: 8B030603
	s_and_b32 s4, s4, exec_lo                                  // 0000003C0004: 8B047E04
	s_cselect_b32 s4, 2, s5                                    // 0000003C0008: 98040582
	s_and_b32 s3, s3, exec_lo                                  // 0000003C000C: 8B037E03
	s_cselect_b32 s3, 3, s4                                    // 0000003C0010: 98030483
	s_mulk_i32 s3, 0x48                                        // 0000003C0014: B8030048
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000003C0018: BF870009
	s_add_u32 s4, s0, s3                                       // 0000003C001C: 80040300
	s_addc_u32 s5, s1, 0                                       // 0000003C0020: 82058001
	s_clause 0x1                                               // 0000003C0024: BF850001
	s_load_b64 s[6:7], s[4:5], 0x58                            // 0000003C0028: F4040182 F8000058
	s_load_b32 s3, s[4:5], 0x68                                // 0000003C0030: F40000C2 F8000068
	s_add_u32 s8, s4, 40                                       // 0000003C0038: 8008A804
	s_addc_u32 s9, s5, 0                                       // 0000003C003C: 82098005
	s_load_b64 s[4:5], s[4:5], 0x28                            // 0000003C0040: F4040102 F8000028
	s_waitcnt lgkmcnt(0)                                       // 0000003C0048: BF89FC07
	.long 0xd451001a                                           // 0000003C004C: D451001A
	v_cndmask_b32_e32 v0, s6, v137, vcc_lo                     // 0000003C0050: 02011206
	s_and_b32 s10, s26, exec_lo                                // 0000003C0054: 8B0A7E1A
	s_cselect_b32 s25, 8, 2                                    // 0000003C0058: 98198288
	s_cselect_b32 s27, 3, 1                                    // 0000003C005C: 981B8183
	v_cvt_f32_ubyte0_e32 v1, s25                               // 0000003C0060: 7E022219
	s_sub_i32 s10, s24, s3                                     // 0000003C0064: 818A0318
	s_add_i32 s3, s25, -1                                      // 0000003C0068: 8103C119
	s_ashr_i32 s11, s10, 31                                    // 0000003C006C: 860B9F0A
	s_and_b32 s19, s26, exec_lo                                // 0000003C0070: 8B137E1A
	v_rcp_iflag_f32_e32 v2, v1                                 // 0000003C0074: 7E045701
	s_cselect_b32 s28, 0, 2                                    // 0000003C0078: 981C8280
	s_ashr_i32 s29, s23, 31                                    // 0000003C007C: 861D9F17
	s_lshl_b64 s[10:11], s[10:11], s28                         // 0000003C0080: 848A1C0A
	v_lshrrev_b32_e32 v51, s27, v5                             // 0000003C0084: 32660A1B
	v_dual_mov_b32 v1, 0 :: v_dual_and_b32 v52, s3, v5         // 0000003C0088: CA240080 01340A03
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000003C0090: BF870292
	.long 0xd7000a03                                           // 0000003C0094: D7000A03
	v_cndmask_b32_e32 v1, s10, v51, vcc_lo                     // 0000003C0098: 0202660A
	v_readfirstlane_b32 s18, v2                                // 0000003C009C: 7E240502
	v_add_co_ci_u32_e64 v4, null, s11, 0, s10                  // 0000003C00A0: D5207C04 0029000B
	s_mul_f32 s19, s18, 0x4f7ffffe                             // 0000003C00A8: A213FF12 4F7FFFFE
	s_lshr_b32 s18, s29, 27                                    // 0000003C00B0: 85129B1D
	v_cmp_gt_i64_e32 vcc_lo, s[6:7], v[3:4]                    // 0000003C00B4: 7CA80606
	s_add_u32 s18, s22, s18                                    // 0000003C00B8: 80121216
	s_cvt_u32_f32 s33, s19                                     // 0000003C00BC: BEA16713
	s_addc_u32 s19, s23, 0                                     // 0000003C00C0: 82138017
	s_sub_i32 s34, 0, s25                                      // 0000003C00C4: 81A21980
	s_lshr_b64 s[30:31], s[18:19], 5                           // 0000003C00C8: 859E8512
	s_mul_i32 s34, s34, s33                                    // 0000003C00CC: 96222122
	s_add_i32 s18, s3, s30                                     // 0000003C00D0: 81121E03
	s_mul_hi_u32 s19, s33, s34                                 // 0000003C00D4: 96932221
	s_abs_i32 s31, s18                                         // 0000003C00D8: BE9F1512
	s_add_i32 s33, s33, s19                                    // 0000003C00DC: 81211321
	s_ashr_i32 s18, s18, 31                                    // 0000003C00E0: 86129F12
	s_mul_hi_u32 s19, s31, s33                                 // 0000003C00E4: 9693211F
	v_dual_mov_b32 v2, 0 :: v_dual_cndmask_b32 v3, 0, v3       // 0000003C00E8: CA120080 02020680
	s_mul_i32 s33, s19, s25                                    // 0000003C00F0: 96211913
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000003C00F4: BF870009
	s_sub_i32 s31, s31, s33                                    // 0000003C00F8: 819F211F
	s_add_i32 s33, s19, 1                                      // 0000003C00FC: 81218113
	s_sub_i32 s34, s31, s25                                    // 0000003C0100: 81A2191F
	s_cmp_ge_u32 s31, s25                                      // 0000003C0104: BF09191F
	s_cselect_b32 s10, s33, s19                                // 0000003C0108: 980A1321
	s_cselect_b32 s11, s34, s31                                // 0000003C010C: 980B1F22
	s_add_i32 s19, s10, 1                                      // 0000003C0110: 8113810A
	s_cmp_ge_u32 s11, s25                                      // 0000003C0114: BF09190B
	s_cselect_b32 s3, s19, s10                                 // 0000003C0118: 98030A13
	s_lshr_b32 s10, s23, 31                                    // 0000003C011C: 850A9F17
	s_xor_b32 s3, s3, s18                                      // 0000003C0120: 8D031203
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000003C0124: BF870009
	s_sub_i32 s3, s3, s18                                      // 0000003C0128: 81831203
	s_add_u32 s10, s22, s10                                    // 0000003C012C: 800A0A16
	s_addc_u32 s11, s23, 0                                     // 0000003C0130: 820B8017
	s_lshr_b32 s18, s29, 30                                    // 0000003C0134: 85129E1D
	s_ashr_i64 s[10:11], s[10:11], 1                           // 0000003C0138: 868A810A
	s_add_u32 s18, s22, s18                                    // 0000003C013C: 80121216
	s_addc_u32 s19, s23, 0                                     // 0000003C0140: 82138017
	s_lshr_b32 s29, s29, 28                                    // 0000003C0144: 851D9C1D
	s_ashr_i64 s[18:19], s[18:19], 2                           // 0000003C0148: 86928212
	s_add_u32 s34, s22, s29                                    // 0000003C014C: 80221D16
	s_addc_u32 s35, s23, 0                                     // 0000003C0150: 82238017
	.long 0xd72c0005                                           // 0000003C0154: D72C0005
	v_cndmask_b32_e32 v0, v52, v3, vcc_lo                      // 0000003C0158: 02000734
	s_ashr_i64 s[34:35], s[34:35], 4                           // 0000003C015C: 86A28422
	s_add_u32 s29, s18, s10                                    // 0000003C0160: 801D0A12
	s_addc_u32 s31, s19, s11                                   // 0000003C0164: 821F0B13
	s_add_u32 s29, s29, s34                                    // 0000003C0168: 801D221D
	s_addc_u32 s31, s31, s35                                   // 0000003C016C: 821F231F
	s_add_u32 s29, s29, 15                                     // 0000003C0170: 801D8F1D
	s_addc_u32 s31, s31, 0                                     // 0000003C0174: 821F801F
	v_dual_cndmask_b32 v4, 0, v4 :: v_dual_add_nc_u32 v53, v5, v50// 0000003C0178: CA600880 04346505
	s_ashr_i32 s33, s31, 31                                    // 0000003C0180: 86219F1F
	v_add_nc_u32_e32 v6, s3, v5                                // 0000003C0184: 4A0C0A03
	s_lshr_b32 s33, s33, 28                                    // 0000003C0188: 85219C21
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000003C018C: BF870009
	s_add_u32 s3, s29, s33                                     // 0000003C0190: 8003211D
	s_addc_u32 s29, s31, 0                                     // 0000003C0194: 821D801F
	s_and_b32 s3, s3, -16                                      // 0000003C0198: 8B03D003
	.long 0xd72c0007                                           // 0000003C019C: D72C0007
	v_cndmask_b32_e32 v1, s29, v3, vcc_lo                      // 0000003C01A0: 0202061D
	.long 0xd72c0008                                           // 0000003C01A4: D72C0008
	v_cndmask_b32_e32 v1, s3, v4, vcc_lo                       // 0000003C01A8: 02020803
	v_mad_u64_u32 v[33:34], null, s3, v3, s[4:5]               // 0000003C01AC: D6FE7C21 00120603
	v_min_i32_e32 v54, s30, v6                                 // 0000003C01B4: 226C0C1E
	v_dual_mov_b32 v3, 0 :: v_dual_mov_b32 v4, 0               // 0000003C01B8: CA100080 03040080
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003C01C0: BF870212
	.long 0xd4410004                                           // 0000003C01C4: D4410004
	v_cndmask_b32_e32 v1, v53, v54, vcc_lo                     // 0000003C01C8: 02026D35
	v_add3_u32 v55, v7, v34, v8                                // 0000003C01CC: D6550037 04224507
	s_and_saveexec_b32 s3, s4                                  // 0000003C01D4: BE832004
	s_cbranch_execz 39                                         // 0000003C01D8: BFA50027 <_ZN7halogen12_GLOBAL__N_112k_hc6_fused3ILi5EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x1678>
	v_lshlrev_b32_e32 v1, 4, v53                               // 0000003C01DC: 30026A84
	v_lshlrev_b32_e32 v4, 1, v53                               // 0000003C01E0: 30086A81
	v_lshlrev_b32_e32 v3, 3, v53                               // 0000003C01E4: 30066A83
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000003C01E8: BF870223
	v_ashrrev_i32_e32 v2, 31, v1                               // 0000003C01EC: 3404029F
	.long 0xd7006a01                                           // 0000003C01F0: D7006A01
	v_cndmask_b32_e32 v1, v33, v1, vcc_lo                      // 0000003C01F4: 02020321
	v_and_b32_e32 v4, -4, v4                                   // 0000003C01F8: 360808C4
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003C01FC: BF870214
	v_ashrrev_i32_e32 v8, 31, v3                               // 0000003C0200: 3410069F
	v_add_co_ci_u32_e64 v2, null, v55, v2, vcc_lo              // 0000003C0204: D5207C02 01AA0537
	.long 0xd7006a06                                           // 0000003C020C: D7006A06
	v_cndmask_b32_e32 v0, v33, v10, vcc_lo                     // 0000003C0210: 02001521
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000003C0214: BF8701A1
	v_add_co_ci_u32_e64 v7, null, s11, v55, vcc_lo             // 0000003C0218: D5207C07 01AA6E0B
	v_ashrrev_i32_e32 v11, 31, v4                              // 0000003C0220: 3416089F
	.long 0xd7006a09                                           // 0000003C0224: D7006A09
	v_cndmask_b32_e32 v0, v6, v18, vcc_lo                      // 0000003C0228: 02002506
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003C022C: BF8700A1
	v_add_co_ci_u32_e64 v10, null, s19, v7, vcc_lo             // 0000003C0230: D5207C0A 01AA0E13
	.long 0xd7006a06                                           // 0000003C0238: D7006A06
	v_cndmask_b32_e32 v1, v6, v3, vcc_lo                       // 0000003C023C: 02020706
	v_add_co_ci_u32_e64 v7, null, v7, v8, vcc_lo               // 0000003C0240: D5207C07 01AA1107
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003C0248: BF870094
	.long 0xd7006a08                                           // 0000003C024C: D7006A08
	v_cndmask_b32_e32 v1, v9, v4, vcc_lo                       // 0000003C0250: 02020909
	v_add_co_ci_u32_e64 v9, null, v10, v11, vcc_lo             // 0000003C0254: D5207C09 01AA170A
	s_clause 0x2                                               // 0000003C025C: BF850002
	global_load_b128 v[1:4], v[1:2], off                       // 0000003C0260: DC5E0000 017C0001
	global_load_b64 v[36:37], v[6:7], off                      // 0000003C0268: DC560000 247C0006
	global_load_b32 v68, v[8:9], off                           // 0000003C0270: DC520000 447C0008
	s_or_b32 exec_lo, exec_lo, s3                              // 0000003C0278: 8C7E037E
	.long 0xd44a0003                                           // 0000003C027C: D44A0003
	v_cndmask_b32_e32 v1, 0, v0, vcc_lo                        // 0000003C0280: 02020080
	s_and_saveexec_b32 s5, s3                                  // 0000003C0284: BE852003
	s_cbranch_execz 20                                         // 0000003C0288: BFA50014 <_ZN7halogen12_GLOBAL__N_112k_hc6_fused3ILi5EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x16dc>
	v_mov_b32_e32 v6, 0                                        // 0000003C028C: 7E0C0280
	global_load_b64 v[7:8], v6, s[12:13] glc                   // 0000003C0290: DC564000 070C0006
	s_waitcnt vmcnt(0)                                         // 0000003C0298: BF8903F7
	buffer_gl1_inv                                             // 0000003C029C: E0B00000 00000000
	buffer_gl0_inv                                             // 0000003C02A4: E0AC0000 00000000
	v_cmp_le_u64_e32 vcc_lo, s[14:15], v[7:8]                  // 0000003C02AC: 7CB60E0E
	s_cbranch_vccnz 10                                         // 0000003C02B0: BFA4000A <_ZN7halogen12_GLOBAL__N_112k_hc6_fused3ILi5EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x16dc>
	s_sleep 1                                                  // 0000003C02B4: BF830001
	global_load_b64 v[7:8], v6, s[12:13] glc                   // 0000003C02B8: DC564000 070C0006
	s_waitcnt vmcnt(0)                                         // 0000003C02C0: BF8903F7
	buffer_gl1_inv                                             // 0000003C02C4: E0B00000 00000000
	buffer_gl0_inv                                             // 0000003C02CC: E0AC0000 00000000
	v_cmp_gt_u64_e32 vcc_lo, s[14:15], v[7:8]                  // 0000003C02D4: 7CB80E0E
	s_cbranch_vccnz 65526                                      // 0000003C02D8: BFA4FFF6 <_ZN7halogen12_GLOBAL__N_112k_hc6_fused3ILi5EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x16b4>
	s_or_b32 exec_lo, exec_lo, s5                              // 0000003C02DC: 8C7E057E
	v_dual_mov_b32 v56, 0 :: v_dual_mov_b32 v57, 0             // 0000003C02E0: CA100080 38380080
	v_dual_mov_b32 v58, 0 :: v_dual_mov_b32 v59, 0             // 0000003C02E8: CA100080 3A3A0080
	v_mov_b32_e32 v60, 0                                       // 0000003C02F0: 7E780280
	s_waitcnt vmcnt(0)                                         // 0000003C02F4: BF8903F7
	s_waitcnt_vscnt null, 0x0                                  // 0000003C02F8: BC7C0000
	s_barrier                                                  // 0000003C02FC: BFBD0000
	buffer_gl0_inv                                             // 0000003C0300: E0AC0000 00000000
	buffer_gl1_inv                                             // 0000003C0308: E0B00000 00000000
	buffer_gl0_inv                                             // 0000003C0310: E0AC0000 00000000
	s_and_saveexec_b32 s5, s4                                  // 0000003C0318: BE852004
	s_cbranch_execz 1221                                       // 0000003C031C: BFA504C5 <_ZN7halogen12_GLOBAL__N_112k_hc6_fused3ILi5EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x2a34>
	.long 0xd7006a3d                                           // 0000003C0320: D7006A3D
	v_cndmask_b32_e32 v0, v33, v10, vcc_lo                     // 0000003C0324: 02001521
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000003C0328: BF870231
	v_add_co_ci_u32_e64 v62, null, s11, v55, vcc_lo            // 0000003C032C: D5207C3E 01AA6E0B
	v_dual_mov_b32 v57, 0 :: v_dual_lshlrev_b32 v6, 5, v50     // 0000003C0334: CA220080 39066485
	v_dual_mov_b32 v56, 0 :: v_dual_add_nc_u32 v7, 32, v53     // 0000003C033C: CA200080 38066AA0
	.long 0xd7006a3f                                           // 0000003C0344: D7006A3F
	v_cndmask_b32_e32 v0, v61, v18, vcc_lo                     // 0000003C0348: 0200253D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003C034C: BF870211
	v_add_co_ci_u32_e64 v64, null, s19, v62, vcc_lo            // 0000003C0350: D5207C40 01AA7C13
	v_lshl_add_u32 v34, v5, 5, v6                              // 0000003C0358: D6460022 04190B05
	s_delay_alu instid0(VALU_DEP_4)                            // 0000003C0360: BF870004
	v_dual_mov_b32 v58, 0 :: v_dual_lshlrev_b32 v65, 4, v7     // 0000003C0364: CA220080 3A400E84
	v_dual_mov_b32 v59, 0 :: v_dual_lshlrev_b32 v66, 3, v7     // 0000003C036C: CA220080 3B420E83
	v_dual_mov_b32 v60, 0 :: v_dual_lshlrev_b32 v67, 1, v7     // 0000003C0374: CA220080 3C420E81
	v_mov_b32_e32 v69, v68                                     // 0000003C037C: 7E8A0344
	s_mul_i32 s4, s23, 6                                       // 0000003C0380: 96048617
	s_mul_hi_u32 s14, s22, 6                                   // 0000003C0384: 968E8616
	s_lshl_b64 s[10:11], s[22:23], 2                           // 0000003C0388: 848A8216
	s_add_i32 s18, s14, s4                                     // 0000003C038C: 8112040E
	s_mul_i32 s29, s22, 6                                      // 0000003C0390: 961D8616
	s_mov_b32 s19, 0                                           // 0000003C0394: BE930080
	s_lshl_b64 s[14:15], s[22:23], 1                           // 0000003C0398: 848E8116
	s_branch 760                                               // 0000003C039C: BFA002F8 <_ZN7halogen12_GLOBAL__N_112k_hc6_fused3ILi5EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x2380>
	s_or_b32 exec_lo, exec_lo, s22                             // 0000003C03A0: 8C7E167E
	v_lshlrev_b32_e32 v11, 4, v36                              // 0000003C03A4: 30164884
	v_lshlrev_b32_e32 v13, 2, v36                              // 0000003C03A8: 301A4882
	v_lshrrev_b32_e32 v15, 4, v1                               // 0000003C03AC: 321E0284
	v_lshrrev_b32_e32 v16, 8, v1                               // 0000003C03B0: 32200288
	v_lshrrev_b32_e32 v17, 2, v36                              // 0000003C03B4: 32224882
	v_and_b32_e32 v14, 48, v11                                 // 0000003C03B8: 361C16B0
	v_and_b32_e32 v13, 48, v13                                 // 0000003C03BC: 361A1AB0
	v_and_b32_e32 v18, 48, v36                                 // 0000003C03C0: 362448B0
	v_lshrrev_b32_e32 v19, 12, v1                              // 0000003C03C4: 3226028C
	v_and_b32_e32 v17, 48, v17                                 // 0000003C03C8: 362222B0
	v_and_or_b32 v14, v1, 15, v14                              // 0000003C03CC: D657000E 04391F01
	v_and_or_b32 v20, v15, 15, v13                             // 0000003C03D4: D6570014 04351F0F
	v_and_or_b32 v18, v16, 15, v18                             // 0000003C03DC: D6570012 04491F10
	v_ashrrev_i32_e32 v35, 31, v34                             // 0000003C03E4: 3446449F
	v_and_or_b32 v17, v19, 15, v17                             // 0000003C03E8: D6570011 04451F13
	v_cvt_f32_ubyte0_e32 v21, v14                              // 0000003C03F0: 7E2A230E
	v_cvt_f32_ubyte0_e32 v19, v20                              // 0000003C03F4: 7E262314
	v_cvt_f32_ubyte0_e32 v18, v18                              // 0000003C03F8: 7E242312
	.long 0xd73c0009                                           // 0000003C03FC: D73C0009
	v_cndmask_b32_e32 v1, 1, v34, vcc_lo                       // 0000003C0400: 02024481
	v_cvt_f32_ubyte0_e32 v17, v17                              // 0000003C0404: 7E222311
	v_fma_mix_f32 v20, v21, v68, v68 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003C0408: CC206014 15128915
	v_fma_mix_f32 v19, v19, v68, v68 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003C0410: CC206013 15128913
	v_fma_mix_f32 v18, v18, v68, v68 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003C0418: CC206012 15128912
	.long 0x7f463880                                           // 0000003C0420: 7F463880
	v_fma_mix_f32 v17, v17, v68, v68 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003C0424: CC206011 15128911
	v_bfe_u32 v25, v20, 16, 1                                  // 0000003C042C: D6100019 02052114
	v_bfe_u32 v26, v19, 16, 1                                  // 0000003C0434: D610001A 02052113
	v_lshrrev_b32_e32 v70, 4, v36                              // 0000003C043C: 328C4884
	v_lshrrev_b32_e32 v73, 6, v36                              // 0000003C0440: 32924886
	v_bfe_u32 v29, v17, 16, 1                                  // 0000003C0444: D610001D 02052111
	v_add3_u32 v20, v20, v25, 0x7fff                           // 0000003C044C: D6550014 03FE3314 00007FFF
	v_bfe_u32 v25, v18, 16, 1                                  // 0000003C0458: D6100019 02052112
	v_add3_u32 v19, v19, v26, 0x7fff                           // 0000003C0460: D6550013 03FE3513 00007FFF
	v_and_b32_e32 v74, 48, v70                                 // 0000003C046C: 36948CB0
	v_add3_u32 v71, v17, v29, 0x7fff                           // 0000003C0470: D6550047 03FE3B11 00007FFF
	.long 0x7e463994                                           // 0000003C047C: 7E463994
	v_add3_u32 v18, v18, v25, 0x7fff                           // 0000003C0480: D6550012 03FE3312 00007FFF
	v_lshrrev_b32_e32 v75, 20, v1                              // 0000003C048C: 32960294
	v_lshrrev_b32_e32 v76, 24, v1                              // 0000003C0490: 32980298
	v_and_b32_e32 v73, 48, v73                                 // 0000003C0494: 369292B0
	v_and_or_b32 v72, 0xffff0000, v19, v35                     // 0000003C0498: D6570048 048E26FF FFFF0000
	.long 0x7e463992                                           // 0000003C04A4: 7E463992
	v_lshrrev_b32_e32 v77, 10, v36                             // 0000003C04A8: 329A488A
	v_lshrrev_b32_e32 v82, 22, v36                             // 0000003C04AC: 32A44896
	v_and_or_b32 v73, v75, 15, v73                             // 0000003C04B0: D6570049 05251F4B
	v_lshrrev_b32_e32 v83, 24, v2                              // 0000003C04B8: 32A60498
	v_and_or_b32 v70, 0xffff0000, v71, v35                     // 0000003C04BC: D6570046 048E8EFF FFFF0000
	.long 0x7e463981                                           // 0000003C04C8: 7E463981
	v_lshrrev_b32_e32 v71, 8, v36                              // 0000003C04CC: 328E4888
	v_lshrrev_b32_e32 v1, 28, v1                               // 0000003C04D0: 3202029C
	v_cvt_f32_ubyte0_e32 v73, v73                              // 0000003C04D4: 7E922349
	v_lshlrev_b32_e32 v85, 4, v37                              // 0000003C04D8: 30AA4A84
	v_and_or_b32 v74, v35, 15, v74                             // 0000003C04DC: D657004A 05291F23
	v_and_b32_e32 v71, 48, v71                                 // 0000003C04E4: 368E8EB0
	v_and_or_b32 v1, v77, 48, v1                               // 0000003C04E8: D6570001 0405614D
	v_fma_mix_f32 v73, v73, v68, v68 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003C04F0: CC206049 15128949
	v_lshrrev_b32_e32 v77, 8, v2                               // 0000003C04F8: 329A0488
	v_cvt_f32_ubyte0_e32 v74, v74                              // 0000003C04FC: 7E94234A
	v_and_or_b32 v71, v76, 15, v71                             // 0000003C0500: D6570047 051D1F4C
	v_cvt_f32_ubyte0_e32 v1, v1                                // 0000003C0508: 7E022301
	v_bfe_u32 v76, v73, 16, 1                                  // 0000003C050C: D610004C 02052149
	v_lshrrev_b32_e32 v89, 8, v3                               // 0000003C0514: 32B20688
	v_fma_mix_f32 v74, v74, v68, v68 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003C0518: CC20604A 1512894A
	v_cvt_f32_ubyte0_e32 v71, v71                              // 0000003C0520: 7E8E2347
	v_fma_mix_f32 v1, v1, v68, v68 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003C0524: CC206001 15128901
	v_add3_u32 v73, v73, v76, 0x7fff                           // 0000003C052C: D6550049 03FE9949 00007FFF
	v_lshrrev_b32_e32 v76, 12, v2                              // 0000003C0538: 3298048C
	v_bfe_u32 v75, v74, 16, 1                                  // 0000003C053C: D610004B 0205214A
	v_fma_mix_f32 v71, v71, v68, v68 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003C0544: CC206047 15128947
	v_bfe_u32 v81, v1, 16, 1                                   // 0000003C054C: D6100051 02052101
	v_and_b32_e32 v82, 48, v82                                 // 0000003C0554: 36A4A4B0
	v_lshrrev_b32_e32 v78, 12, v36                             // 0000003C0558: 329C488C
	v_add3_u32 v74, v74, v75, 0x7fff                           // 0000003C055C: D655004A 03FE974A 00007FFF
	v_bfe_u32 v75, v71, 16, 1                                  // 0000003C0568: D610004B 02052147
	v_add3_u32 v1, v1, v81, 0x7fff                             // 0000003C0570: D6550001 03FEA301 00007FFF
	v_lshrrev_b32_e32 v81, 20, v2                              // 0000003C057C: 32A20494
	v_lshrrev_b32_e32 v80, 14, v36                             // 0000003C0580: 32A0488E
	.long 0x7e4639ca                                           // 0000003C0584: 7E4639CA
	v_add3_u32 v74, v71, v75, 0x7fff                           // 0000003C0588: D655004A 03FE9747 00007FFF
	v_lshrrev_b32_e32 v75, 20, v36                             // 0000003C0594: 32964894
	v_lshrrev_b32_e32 v84, 28, v2                              // 0000003C0598: 32A8049C
	v_lshlrev_b32_e32 v88, 2, v37                              // 0000003C059C: 30B04A82
	v_and_or_b32 v71, 0xffff0000, v73, v35                     // 0000003C05A0: D6570047 048E92FF FFFF0000
	.long 0x7e4639ca                                           // 0000003C05AC: 7E4639CA
	v_lshrrev_b32_e32 v73, 18, v36                             // 0000003C05B0: 32924892
	v_lshrrev_b32_e32 v74, 24, v36                             // 0000003C05B4: 32944898
	v_lshrrev_b32_e32 v91, 2, v37                              // 0000003C05B8: 32B64A82
	v_and_b32_e32 v85, 48, v85                                 // 0000003C05BC: 36AAAAB0
	v_and_or_b32 v1, 0xffff0000, v1, v35                       // 0000003C05C0: D6570001 048E02FF FFFF0000
	.long 0x7e4639a4                                           // 0000003C05CC: 7E4639A4
	v_and_b32_e32 v73, 48, v73                                 // 0000003C05D0: 369292B0
	v_and_b32_e32 v74, 48, v74                                 // 0000003C05D4: 369494B0
	v_lshrrev_b32_e32 v36, 26, v36                             // 0000003C05D8: 3248489A
	v_and_or_b32 v81, v81, 15, v82                             // 0000003C05DC: D6570051 05491F51
	v_and_b32_e32 v86, 48, v35                                 // 0000003C05E4: 36AC46B0
	v_and_or_b32 v73, v76, 15, v73                             // 0000003C05E8: D6570049 05251F4C
	v_and_or_b32 v74, v83, 15, v74                             // 0000003C05F0: D657004A 05291F53
	v_lshrrev_b32_e32 v87, 4, v3                               // 0000003C05F8: 32AE0684
	v_lshrrev_b32_e32 v90, 12, v3                              // 0000003C05FC: 32B4068C
	v_and_or_b32 v77, v77, 15, v86                             // 0000003C0600: D657004D 05591F4D
	v_cvt_f32_ubyte0_e32 v73, v73                              // 0000003C0608: 7E922349
	v_and_b32_e32 v86, 48, v37                                 // 0000003C060C: 36AC4AB0
	v_and_or_b32 v36, v36, 48, v84                             // 0000003C0610: D6570024 05516124
	v_and_or_b32 v82, v3, 15, v85                              // 0000003C0618: D6570052 05551F03
	v_cvt_f32_ubyte0_e32 v76, v77                              // 0000003C0620: 7E98234D
	v_fma_mix_f32 v73, v73, v68, v68 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003C0624: CC206049 15128949
	v_cvt_f32_ubyte0_e32 v81, v81                              // 0000003C062C: 7EA22351
	v_cvt_f32_ubyte0_e32 v74, v74                              // 0000003C0630: 7E94234A
	v_cvt_f32_ubyte0_e32 v36, v36                              // 0000003C0634: 7E482324
	v_fma_mix_f32 v76, v76, v68, v68 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003C0638: CC20604C 1512894C
	v_bfe_u32 v101, v73, 16, 1                                 // 0000003C0640: D6100065 02052149
	v_cvt_f32_ubyte0_e32 v82, v82                              // 0000003C0648: 7EA42352
	v_fma_mix_f32 v74, v74, v68, v68 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003C064C: CC20604A 1512894A
	v_fma_mix_f32 v36, v36, v68, v68 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003C0654: CC206024 15128924
	v_bfe_u32 v77, v76, 16, 1                                  // 0000003C065C: D610004D 0205214C
	v_add3_u32 v73, v73, v101, 0x7fff                          // 0000003C0664: D6550049 03FECB49 00007FFF
	v_fma_mix_f32 v82, v82, v68, v68 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003C0670: CC206052 15128952
	v_lshrrev_b32_e32 v93, 4, v37                              // 0000003C0678: 32BA4A84
	v_lshrrev_b32_e32 v92, 8, v37                              // 0000003C067C: 32B84A88
	v_add3_u32 v76, v76, v77, 0x7fff                           // 0000003C0680: D655004C 03FE9B4C 00007FFF
	v_and_or_b32 v77, v89, 15, v86                             // 0000003C068C: D657004D 05591F59
	v_and_b32_e32 v86, 48, v88                                 // 0000003C0694: 36ACB0B0
	v_lshrrev_b32_e32 v95, 6, v37                              // 0000003C0698: 32BE4A86
	v_lshrrev_b32_e32 v94, 20, v3                              // 0000003C069C: 32BC0694
	.long 0x7e4639cc                                           // 0000003C06A0: 7E4639CC
	v_and_b32_e32 v76, 48, v75                                 // 0000003C06A4: 369896B0
	v_cvt_f32_ubyte0_e32 v77, v77                              // 0000003C06A8: 7E9A234D
	v_and_or_b32 v83, v87, 15, v86                             // 0000003C06AC: D6570053 05591F57
	v_bfe_u32 v86, v36, 16, 1                                  // 0000003C06B4: D6100056 02052124
	v_and_or_b32 v75, 0xffff0000, v73, v35                     // 0000003C06BC: D657004B 048E92FF FFFF0000
	.long 0x7e463982                                           // 0000003C06C8: 7E463982
	v_and_b32_e32 v73, 48, v91                                 // 0000003C06CC: 3692B6B0
	v_fma_mix_f32 v85, v77, v68, v68 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003C06D0: CC206055 1512894D
	v_fma_mix_f32 v77, v81, v68, v68 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003C06D8: CC20604D 15128951
	v_cvt_f32_ubyte0_e32 v83, v83                              // 0000003C06E0: 7EA62353
	v_and_or_b32 v76, v35, 15, v76                             // 0000003C06E4: D657004C 05311F23
	v_and_or_b32 v73, v90, 15, v73                             // 0000003C06EC: D6570049 05251F5A
	v_add3_u32 v36, v36, v86, 0x7fff                           // 0000003C06F4: D6550024 03FEAD24 00007FFF
	v_bfe_u32 v87, v77, 16, 1                                  // 0000003C0700: D6100057 0205214D
	v_fma_mix_f32 v83, v83, v68, v68 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003C0708: CC206053 15128953
	v_cvt_f32_ubyte0_e32 v76, v76                              // 0000003C0710: 7E98234C
	v_cvt_f32_ubyte0_e32 v73, v73                              // 0000003C0714: 7E922349
	v_and_b32_e32 v86, 48, v93                                 // 0000003C0718: 36ACBAB0
	v_lshrrev_b32_e32 v96, 24, v3                              // 0000003C071C: 32C00698
	v_and_b32_e32 v90, 48, v92                                 // 0000003C0720: 36B4B8B0
	v_fma_mix_f32 v76, v76, v68, v68 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003C0724: CC20604C 1512894C
	v_fma_mix_f32 v88, v73, v68, v68 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003C072C: CC206058 15128949
	v_add3_u32 v73, v77, v87, 0x7fff                           // 0000003C0734: D6550049 03FEAF4D 00007FFF
	v_lshrrev_b32_e32 v98, 28, v3                              // 0000003C0740: 32C4069C
	v_lshrrev_b32_e32 v99, 10, v37                             // 0000003C0744: 32C64A8A
	v_bfe_u32 v81, v76, 16, 1                                  // 0000003C0748: D6100051 0205214C
	v_and_or_b32 v90, v96, 15, v90                             // 0000003C0750: D657005A 05691F60
	.long 0xd7000430                                           // 0000003C0758: D7000430
	v_cndmask_b32_e32 v1, s20, v9, vcc_lo                      // 0000003C075C: 02021214
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003C0760: BF870211
	v_add_co_ci_u32_e64 v49, null, s21, v10, s4                // 0000003C0764: D5207C31 00121415
	v_add3_u32 v76, v76, v81, 0x7fff                           // 0000003C076C: D655004C 03FEA34C 00007FFF
	v_bfe_u32 v81, v74, 16, 1                                  // 0000003C0778: D6100051 0205214A
	v_cvt_f32_ubyte0_e32 v90, v90                              // 0000003C0780: 7EB4235A
	.long 0xd700042c                                           // 0000003C0784: D700042C
	v_cndmask_b32_e32 v0, v48, v14, vcc_lo                     // 0000003C0788: 02001D30
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003C078C: BF870214
	.long 0x7e4639cc                                           // 0000003C0790: 7E4639CC
	v_add3_u32 v74, v74, v81, 0x7fff                           // 0000003C0794: D655004A 03FEA34A 00007FFF
	v_bfe_u32 v76, v82, 16, 1                                  // 0000003C07A0: D610004C 02052152
	v_bfe_u32 v81, v83, 16, 1                                  // 0000003C07A8: D6100051 02052153
	v_fma_mix_f32 v90, v90, v68, v68 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003C07B0: CC20605A 1512895A
	v_and_or_b32 v77, 0xffff0000, v73, v35                     // 0000003C07B8: D657004D 048E92FF FFFF0000
	.long 0x7e4639ca                                           // 0000003C07C4: 7E4639CA
	v_add3_u32 v74, v82, v76, 0x7fff                           // 0000003C07C8: D655004A 03FE9952 00007FFF
	v_bfe_u32 v76, v85, 16, 1                                  // 0000003C07D4: D610004C 02052155
	v_bfe_u32 v82, v88, 16, 1                                  // 0000003C07DC: D6100052 02052158
	v_add3_u32 v81, v83, v81, 0x7fff                           // 0000003C07E4: D6550051 03FEA353 00007FFF
	v_and_or_b32 v73, 0xffff0000, v36, v35                     // 0000003C07F0: D6570049 048E48FF FFFF0000
	.long 0x7e4639ca                                           // 0000003C07FC: 7E4639CA
	v_add3_u32 v36, v85, v76, 0x7fff                           // 0000003C0800: D6550024 03FE9955 00007FFF
	v_add3_u32 v76, v88, v82, 0x7fff                           // 0000003C080C: D655004C 03FEA558 00007FFF
	v_and_b32_e32 v88, 48, v95                                 // 0000003C0818: 36B0BEB0
	s_clause 0x1                                               // 0000003C081C: BF850001
	global_load_b128 v[29:32], v[48:49], off                   // 0000003C0820: DC5E0000 1D7C0030
	global_load_b128 v[17:20], v[48:49], off offset:16         // 0000003C0828: DC5E0010 117C0030
	v_and_or_b32 v74, 0xffff0000, v81, v35                     // 0000003C0830: D657004A 048EA2FF FFFF0000
	.long 0x7e4639a4                                           // 0000003C083C: 7E4639A4
	v_add_co_ci_u32_e64 v45, null, s15, v49, s4                // 0000003C0840: D5207C2D 0012620F
	v_and_or_b32 v88, v94, 15, v88                             // 0000003C0848: D6570058 05611F5E
	v_and_or_b32 v94, v99, 48, v98                             // 0000003C0850: D657005E 05896163
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 0000003C0858: BF870254
	v_and_or_b32 v76, 0xffff0000, v76, v35                     // 0000003C085C: D657004C 048E98FF FFFF0000
	.long 0x7e463983                                           // 0000003C0868: 7E463983
	.long 0xd700042a                                           // 0000003C086C: D700042A
	v_cndmask_b32_e32 v0, v48, v10, vcc_lo                     // 0000003C0870: 02001530
	v_cvt_f32_ubyte0_e32 v88, v88                              // 0000003C0874: 7EB02358
	v_cvt_f32_ubyte0_e32 v94, v94                              // 0000003C0878: 7EBC235E
	v_and_or_b32 v86, v35, 15, v86                             // 0000003C087C: D6570056 05591F23
	v_add_co_ci_u32_e64 v43, null, s11, v49, s4                // 0000003C0884: D5207C2B 0012620B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003C088C: BF870214
	v_fma_mix_f32 v88, v88, v68, v68 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003C0890: CC206058 15128958
	v_fma_mix_f32 v94, v94, v68, v68 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003C0898: CC20605E 1512895E
	s_delay_alu instid0(VALU_DEP_4)                            // 0000003C08A0: BF870004
	v_cvt_f32_ubyte0_e32 v86, v86                              // 0000003C08A4: 7EAC2356
	v_lshrrev_b32_e32 v79, 4, v2                               // 0000003C08A8: 329E0484
	v_and_b32_e32 v78, 48, v78                                 // 0000003C08AC: 369C9CB0
	v_bfe_u32 v96, v88, 16, 1                                  // 0000003C08B0: D6100060 02052158
	v_and_b32_e32 v80, 48, v80                                 // 0000003C08B8: 36A0A0B0
	v_fma_mix_f32 v86, v86, v68, v68 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003C08BC: CC206056 15128956
	.long 0xd7000428                                           // 0000003C08C4: D7000428
	v_cndmask_b32_e32 v0, v48, v29, vcc_lo                     // 0000003C08C8: 02003B30
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000003C08CC: BF870224
	v_add3_u32 v88, v88, v96, 0x7fff                           // 0000003C08D0: D6550058 03FEC158 00007FFF
	v_bfe_u32 v96, v94, 16, 1                                  // 0000003C08DC: D6100060 0205215E
	v_bfe_u32 v95, v86, 16, 1                                  // 0000003C08E4: D610005F 02052156
	v_add_co_ci_u32_e64 v41, null, s18, v49, s4                // 0000003C08EC: D5207C29 00126212
	.long 0xd700042e                                           // 0000003C08F4: D700042E
	v_cndmask_b32_e32 v0, v42, v10, vcc_lo                     // 0000003C08F8: 0200152A
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000003C08FC: BF870243
	v_add3_u32 v86, v86, v95, 0x7fff                           // 0000003C0900: D6550056 03FEBF56 00007FFF
	v_bfe_u32 v95, v90, 16, 1                                  // 0000003C090C: D610005F 0205215A
	v_add3_u32 v94, v94, v96, 0x7fff                           // 0000003C0914: D655005E 03FEC15E 00007FFF
	v_add_co_ci_u32_e64 v47, null, s11, v43, s4                // 0000003C0920: D5207C2F 0012560B
	.long 0x7e4639d6                                           // 0000003C0928: 7E4639D6
	s_delay_alu instid0(VALU_DEP_4)                            // 0000003C092C: BF870004
	v_add3_u32 v86, v90, v95, 0x7fff                           // 0000003C0930: D6550056 03FEBF5A 00007FFF
	v_lshrrev_b32_e32 v85, 8, v4                               // 0000003C093C: 32AA0888
	v_and_or_b32 v2, v2, 15, v78                               // 0000003C0940: D6570002 05391F02
	v_and_or_b32 v78, v79, 15, v80                             // 0000003C0948: D657004E 05411F4F
	v_and_or_b32 v122, 0xffff0000, v88, v35                    // 0000003C0950: D657007A 048EB0FF FFFF0000
	.long 0x7e4639d6                                           // 0000003C095C: 7E4639D6
	s_clause 0x3                                               // 0000003C0960: BF850003
	global_load_b128 v[9:12], v[44:45], off                    // 0000003C0964: DC5E0000 097C002C
	global_load_b128 v[118:121], v[44:45], off offset:48       // 0000003C096C: DC5E0030 767C002C
	global_load_b128 v[13:16], v[42:43], off                   // 0000003C0974: DC5E0000 0D7C002A
	global_load_b128 v[21:24], v[40:41], off                   // 0000003C097C: DC5E0000 157C0028
	v_and_or_b32 v124, 0xffff0000, v94, v35                    // 0000003C0984: D657007C 048EBCFF FFFF0000
	.long 0x7e4639a5                                           // 0000003C0990: 7E4639A5
	s_clause 0x1                                               // 0000003C0994: BF850001
	global_load_b128 v[25:28], v[46:47], off                   // 0000003C0998: DC5E0000 197C002E
	global_load_b128 v[114:117], v[46:47], off offset:32       // 0000003C09A0: DC5E0020 727C002E
	v_lshrrev_b32_e32 v83, 14, v37                             // 0000003C09A8: 32A64A8E
	v_lshrrev_b32_e32 v82, 18, v37                             // 0000003C09AC: 32A44A92
	v_and_b32_e32 v79, 48, v35                                 // 0000003C09B0: 369E46B0
	v_lshrrev_b32_e32 v97, 12, v37                             // 0000003C09B4: 32C24A8C
	v_and_b32_e32 v100, 15, v4                                 // 0000003C09B8: 36C8088F
	v_lshrrev_b32_e32 v84, 4, v4                               // 0000003C09BC: 32A80884
	v_lshrrev_b32_e32 v81, 12, v4                              // 0000003C09C0: 32A2088C
	v_and_or_b32 v79, v85, 15, v79                             // 0000003C09C4: D657004F 053D1F55
	v_lshrrev_b32_e32 v89, 22, v37                             // 0000003C09CC: 32B24A96
	v_and_b32_e32 v83, 48, v83                                 // 0000003C09D0: 36A6A6B0
	v_and_b32_e32 v82, 48, v82                                 // 0000003C09D4: 36A4A4B0
	v_lshrrev_b32_e32 v3, 24, v37                              // 0000003C09D8: 32064A98
	v_cvt_f32_ubyte0_e32 v79, v79                              // 0000003C09DC: 7E9E234F
	v_lshrrev_b32_e32 v87, 20, v4                              // 0000003C09E0: 32AE0894
	v_and_or_b32 v90, v97, 48, v100                            // 0000003C09E4: D657005A 05916161
	v_and_b32_e32 v86, 48, v89                                 // 0000003C09EC: 36ACB2B0
	v_and_or_b32 v80, v84, 15, v83                             // 0000003C09F0: D6570050 054D1F54
	v_and_or_b32 v81, v81, 15, v82                             // 0000003C09F8: D6570051 05491F51
	v_cvt_f32_ubyte0_e32 v78, v78                              // 0000003C0A00: 7E9C234E
	v_fma_mix_f32 v79, v79, v68, v68 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003C0A04: CC20604F 1512894F
	v_lshrrev_b32_e32 v91, 24, v4                              // 0000003C0A0C: 32B60898
	v_lshrrev_b32_e32 v92, 28, v4                              // 0000003C0A10: 32B8089C
	v_lshrrev_b32_e32 v93, 26, v37                             // 0000003C0A14: 32BA4A9A
	v_and_b32_e32 v3, 48, v3                                   // 0000003C0A18: 360606B0
	v_cvt_f32_ubyte0_e32 v83, v90                              // 0000003C0A1C: 7EA6235A
	v_and_or_b32 v82, v87, 15, v86                             // 0000003C0A20: D6570052 05591F57
	v_cvt_f32_ubyte0_e32 v2, v2                                // 0000003C0A28: 7E042302
	v_cvt_f32_ubyte0_e32 v103, v80                             // 0000003C0A2C: 7ECE2350
	v_cvt_f32_ubyte0_e32 v80, v81                              // 0000003C0A30: 7EA02351
	v_fma_mix_f32 v105, v78, v68, v68 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003C0A34: CC206069 1512894E
	v_bfe_u32 v78, v79, 16, 1                                  // 0000003C0A3C: D610004E 0205214F
	v_lshrrev_b32_e32 v36, 20, v37                             // 0000003C0A44: 32484A94
	v_and_or_b32 v37, v93, 48, v92                             // 0000003C0A48: D6570025 0571615D
	v_and_or_b32 v3, v91, 15, v3                               // 0000003C0A50: D6570003 040D1F5B
	v_fma_mix_f32 v125, v83, v68, v68 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003C0A58: CC20607D 15128953
	v_cvt_f32_ubyte0_e32 v104, v82                             // 0000003C0A60: 7ED02352
	v_fma_mix_f32 v2, v2, v68, v68 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003C0A64: CC206002 15128902
	v_fma_mix_f32 v94, v80, v68, v68 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003C0A6C: CC20605E 15128950
	v_add3_u32 v97, v79, v78, 0x7fff                           // 0000003C0A74: D6550061 03FE9D4F 00007FFF
	s_clause 0x3                                               // 0000003C0A80: BF850003
	global_load_b128 v[78:81], v[44:45], off offset:16         // 0000003C0A84: DC5E0010 4E7C002C
	global_load_b128 v[82:85], v[42:43], off offset:16         // 0000003C0A8C: DC5E0010 527C002A
	global_load_b128 v[86:89], v[40:41], off offset:16         // 0000003C0A94: DC5E0010 567C0028
	global_load_b128 v[90:93], v[46:47], off offset:16         // 0000003C0A9C: DC5E0010 5A7C002E
	v_bfe_u32 v106, v105, 16, 1                                // 0000003C0AA4: D610006A 02052169
	v_bfe_u32 v95, v2, 16, 1                                   // 0000003C0AAC: D610005F 02052102
	v_bfe_u32 v96, v94, 16, 1                                  // 0000003C0AB4: D6100060 0205215E
	.long 0x7e4639e1                                           // 0000003C0ABC: 7E4639E1
	.long 0x7fcc39a3                                           // 0000003C0AC0: 7FCC39A3
	v_and_b32_e32 v36, 48, v36                                 // 0000003C0AC4: 364848B0
	v_add3_u32 v2, v2, v95, 0x7fff                             // 0000003C0AC8: D6550002 03FEBF02 00007FFF
	v_add3_u32 v107, v94, v96, 0x7fff                          // 0000003C0AD4: D655006B 03FEC15E 00007FFF
	s_clause 0x1                                               // 0000003C0AE0: BF850001
	global_load_b128 v[94:97], v[48:49], off offset:32         // 0000003C0AE4: DC5E0020 5E7C0030
	global_load_b128 v[98:101], v[48:49], off offset:48        // 0000003C0AEC: DC5E0030 627C0030
	v_add3_u32 v48, v105, v106, 0x7fff                         // 0000003C0AF4: D6550030 03FED569 00007FFF
	v_cvt_f32_ubyte0_e32 v37, v37                              // 0000003C0B00: 7E4A2325
	.long 0x7ecc3982                                           // 0000003C0B04: 7ECC3982
	v_and_or_b32 v126, 0xffff0000, v107, v35                   // 0000003C0B08: D657007E 048ED6FF FFFF0000
	.long 0x7e463984                                           // 0000003C0B14: 7E463984
	v_fma_mix_f32 v4, v103, v68, v68 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003C0B18: CC206004 15128967
	v_cvt_f32_ubyte0_e32 v3, v3                                // 0000003C0B20: 7E062303
	v_and_or_b32 v127, 0xffff0000, v48, v102                   // 0000003C0B24: D657007F 059A60FF FFFF0000
	v_fma_mix_f32 v48, v104, v68, v68 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003C0B30: CC206030 15128968
	v_and_or_b32 v36, v35, 15, v36                             // 0000003C0B38: D6570024 04911F23
	s_clause 0x2                                               // 0000003C0B40: BF850002
	global_load_b128 v[102:105], v[44:45], off offset:32       // 0000003C0B44: DC5E0020 667C002C
	global_load_b128 v[106:109], v[42:43], off offset:32       // 0000003C0B4C: DC5E0020 6A7C002A
	global_load_b128 v[110:113], v[40:41], off offset:32       // 0000003C0B54: DC5E0020 6E7C0028
	v_fma_mix_f32 v37, v37, v68, v68 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003C0B5C: CC206025 15128925
	v_bfe_u32 v2, v125, 16, 1                                  // 0000003C0B64: D6100002 0205217D
	v_fma_mix_f32 v3, v3, v68, v68 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003C0B6C: CC206003 15128903
	v_cvt_f32_ubyte0_e32 v36, v36                              // 0000003C0B74: 7E482324
	v_bfe_u32 v44, v4, 16, 1                                   // 0000003C0B78: D610002C 02052104
	v_bfe_u32 v49, v37, 16, 1                                  // 0000003C0B80: D6100031 02052125
	v_add3_u32 v2, v125, v2, 0x7fff                            // 0000003C0B88: D6550002 03FE057D 00007FFF
	v_bfe_u32 v45, v48, 16, 1                                  // 0000003C0B94: D610002D 02052130
	v_fma_mix_f32 v36, v36, v68, v68 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003C0B9C: CC206024 15128924
	v_add3_u32 v4, v4, v44, 0x7fff                             // 0000003C0BA4: D6550004 03FE5904 00007FFF
	v_add3_u32 v68, v37, v49, 0x7fff                           // 0000003C0BB0: D6550044 03FE6325 00007FFF
	v_bfe_u32 v37, v3, 16, 1                                   // 0000003C0BBC: D6100025 02052103
	.long 0x7ef63982                                           // 0000003C0BC4: 7EF63982
	v_bfe_u32 v2, v36, 16, 1                                   // 0000003C0BC8: D6100002 02052124
	v_add3_u32 v125, v48, v45, 0x7fff                          // 0000003C0BD0: D655007D 03FE5B30 00007FFF
	global_load_b128 v[42:45], v[42:43], off offset:48         // 0000003C0BDC: DC5E0030 2A7C002A
	v_add3_u32 v3, v3, v37, 0x7fff                             // 0000003C0BE4: D6550003 03FE4B03 00007FFF
	s_waitcnt vmcnt(19)                                        // 0000003C0BF0: BF894FF7
	v_mov_b32_e32 v37, v39                                     // 0000003C0BF4: 7E4A0327
	v_add3_u32 v2, v36, v2, 0x7fff                             // 0000003C0BF8: D6550002 03FE0524 00007FFF
	v_mov_b32_e32 v36, v38                                     // 0000003C0C04: 7E480326
	s_clause 0x1                                               // 0000003C0C08: BF850001
	global_load_b128 v[38:41], v[40:41], off offset:48         // 0000003C0C0C: DC5E0030 267C0028
	global_load_b128 v[46:49], v[46:47], off offset:48         // 0000003C0C14: DC5E0030 2E7C002E
	.long 0x7ff639a3                                           // 0000003C0C1C: 7FF639A3
	.long 0x7e463982                                           // 0000003C0C20: 7E463982
	v_add_nc_u32_e32 v65, 0x200, v65                           // 0000003C0C24: 4A8282FF 00000200
	v_add_nc_u32_e32 v66, 0x100, v66                           // 0000003C0C2C: 4A8484FF 00000100
	v_add_nc_u32_e32 v67, 64, v67                              // 0000003C0C34: 4A8686C0
	v_and_or_b32 v123, 0xffff0000, v4, v123                    // 0000003C0C38: D657007B 05EE08FF FFFF0000
	v_add_nc_u32_e32 v34, 0x400, v34                           // 0000003C0C44: 4A4444FF 00000400
	s_and_b32 s4, exec_lo, vcc_lo                              // 0000003C0C4C: 8B046A7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(VALU_DEP_3)// 0000003C0C50: BF8701D9
	s_or_b32 s19, s4, s19                                      // 0000003C0C54: 8C131304
	s_waitcnt vmcnt(19)                                        // 0000003C0C58: BF894FF7
	v_dot2_f32_bf16 v2, v29, v72, 0                            // 0000003C0C5C: CC1A4002 1A02911D
	v_and_or_b32 v29, 0xffff0000, v125, v35                    // 0000003C0C64: D657001D 048EFAFF FFFF0000
	.long 0x7e463983                                           // 0000003C0C70: 7E463983
	v_dot2_f32_bf16 v2, v30, v70, v2                           // 0000003C0C74: CC1A4002 1C0A8D1E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000003C0C7C: BF870131
	v_dot2_f32_bf16 v2, v31, v71, v2                           // 0000003C0C80: CC1A4002 1C0A8F1F
	s_waitcnt vmcnt(17)                                        // 0000003C0C88: BF8947F7
	v_dot2_f32_bf16 v3, v9, v72, 0                             // 0000003C0C8C: CC1A4003 1A029109
	v_dot2_f32_bf16 v9, v32, v1, v2                            // 0000003C0C94: CC1A4009 1C0A0320
	s_waitcnt vmcnt(15)                                        // 0000003C0C9C: BF893FF7
	v_dot2_f32_bf16 v2, v13, v72, 0                            // 0000003C0CA0: CC1A4002 1A02910D
	s_waitcnt vmcnt(14)                                        // 0000003C0CA8: BF893BF7
	v_dot2_f32_bf16 v4, v21, v72, 0                            // 0000003C0CAC: CC1A4004 1A029115
	v_and_or_b32 v21, 0xffff0000, v68, v35                     // 0000003C0CB4: D6570015 048E88FF FFFF0000
	v_dot2_f32_bf16 v10, v10, v70, v3                          // 0000003C0CC0: CC1A400A 1C0E8D0A
	s_waitcnt vmcnt(13)                                        // 0000003C0CC8: BF8937F7
	v_dot2_f32_bf16 v13, v25, v72, 0                           // 0000003C0CCC: CC1A400D 1A029119
	v_dot2_f32_bf16 v14, v14, v70, v2                          // 0000003C0CD4: CC1A400E 1C0A8D0E
	v_dot2_f32_bf16 v22, v22, v70, v4                          // 0000003C0CDC: CC1A4016 1C128D16
	v_dual_mov_b32 v2, v6 :: v_dual_mov_b32 v3, v7             // 0000003C0CE4: CA100106 02020107
	s_delay_alu instid0(VALU_DEP_4)                            // 0000003C0CEC: BF870004
	v_dot2_f32_bf16 v13, v26, v70, v13                         // 0000003C0CF0: CC1A400D 1C368D1A
	v_mov_b32_e32 v4, v8                                       // 0000003C0CF8: 7E080308
	v_dot2_f32_bf16 v6, v11, v71, v10                          // 0000003C0CFC: CC1A4006 1C2A8F0B
	v_dot2_f32_bf16 v7, v15, v71, v14                          // 0000003C0D04: CC1A4007 1C3A8F0F
	v_dot2_f32_bf16 v8, v23, v71, v22                          // 0000003C0D0C: CC1A4008 1C5A8F17
	v_dot2_f32_bf16 v10, v27, v71, v13                         // 0000003C0D14: CC1A400A 1C368F1B
	v_dot2_f32_bf16 v9, v17, v127, v9                          // 0000003C0D1C: CC1A4009 1C26FF11
	v_dot2_f32_bf16 v6, v12, v1, v6                            // 0000003C0D24: CC1A4006 1C1A030C
	v_dot2_f32_bf16 v7, v16, v1, v7                            // 0000003C0D2C: CC1A4007 1C1E0310
	v_dot2_f32_bf16 v8, v24, v1, v8                            // 0000003C0D34: CC1A4008 1C220318
	v_dot2_f32_bf16 v1, v28, v1, v10                           // 0000003C0D3C: CC1A4001 1C2A031C
	v_dot2_f32_bf16 v9, v18, v75, v9                           // 0000003C0D44: CC1A4009 1C269712
	v_mov_b32_e32 v68, v69                                     // 0000003C0D4C: 7E880345
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003C0D50: BF870092
	v_dot2_f32_bf16 v9, v19, v77, v9                           // 0000003C0D54: CC1A4009 1C269B13
	v_dot2_f32_bf16 v9, v20, v73, v9                           // 0000003C0D5C: CC1A4009 1C269314
	s_waitcnt vmcnt(11)                                        // 0000003C0D64: BF892FF7
	v_dot2_f32_bf16 v6, v78, v127, v6                          // 0000003C0D68: CC1A4006 1C1AFF4E
	s_waitcnt vmcnt(10)                                        // 0000003C0D70: BF892BF7
	v_dot2_f32_bf16 v7, v82, v127, v7                          // 0000003C0D74: CC1A4007 1C1EFF52
	s_waitcnt vmcnt(9)                                         // 0000003C0D7C: BF8927F7
	v_dot2_f32_bf16 v8, v86, v127, v8                          // 0000003C0D80: CC1A4008 1C22FF56
	s_waitcnt vmcnt(8)                                         // 0000003C0D88: BF8923F7
	v_dot2_f32_bf16 v1, v90, v127, v1                          // 0000003C0D8C: CC1A4001 1C06FF5A
	v_dot2_f32_bf16 v6, v79, v75, v6                           // 0000003C0D94: CC1A4006 1C1A974F
	v_dot2_f32_bf16 v7, v83, v75, v7                           // 0000003C0D9C: CC1A4007 1C1E9753
	v_dot2_f32_bf16 v8, v87, v75, v8                           // 0000003C0DA4: CC1A4008 1C229757
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003C0DAC: BF870214
	v_dot2_f32_bf16 v1, v91, v75, v1                           // 0000003C0DB0: CC1A4001 1C06975B
	v_dot2_f32_bf16 v6, v80, v77, v6                           // 0000003C0DB8: CC1A4006 1C1A9B50
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003C0DC0: BF870214
	v_dot2_f32_bf16 v7, v84, v77, v7                           // 0000003C0DC4: CC1A4007 1C1E9B54
	v_dot2_f32_bf16 v8, v88, v77, v8                           // 0000003C0DCC: CC1A4008 1C229B58
	s_delay_alu instid0(VALU_DEP_4)                            // 0000003C0DD4: BF870004
	v_dot2_f32_bf16 v1, v92, v77, v1                           // 0000003C0DD8: CC1A4001 1C069B5C
	s_waitcnt vmcnt(7)                                         // 0000003C0DE0: BF891FF7
	v_dot2_f32_bf16 v9, v94, v74, v9                           // 0000003C0DE4: CC1A4009 1C26955E
	v_dot2_f32_bf16 v6, v81, v73, v6                           // 0000003C0DEC: CC1A4006 1C1A9351
	v_dot2_f32_bf16 v7, v85, v73, v7                           // 0000003C0DF4: CC1A4007 1C1E9355
	v_dot2_f32_bf16 v8, v89, v73, v8                           // 0000003C0DFC: CC1A4008 1C229359
	v_dot2_f32_bf16 v1, v93, v73, v1                           // 0000003C0E04: CC1A4001 1C06935D
	v_dot2_f32_bf16 v9, v95, v76, v9                           // 0000003C0E0C: CC1A4009 1C26995F
	s_waitcnt vmcnt(5)                                         // 0000003C0E14: BF8917F7
	v_dot2_f32_bf16 v6, v102, v74, v6                          // 0000003C0E18: CC1A4006 1C1A9566
	s_waitcnt vmcnt(4)                                         // 0000003C0E20: BF8913F7
	v_dot2_f32_bf16 v7, v106, v74, v7                          // 0000003C0E24: CC1A4007 1C1E956A
	s_waitcnt vmcnt(3)                                         // 0000003C0E2C: BF890FF7
	v_dot2_f32_bf16 v8, v110, v74, v8                          // 0000003C0E30: CC1A4008 1C22956E
	v_dot2_f32_bf16 v1, v114, v74, v1                          // 0000003C0E38: CC1A4001 1C069572
	v_dot2_f32_bf16 v9, v96, v122, v9                          // 0000003C0E40: CC1A4009 1C26F560
	v_dot2_f32_bf16 v6, v103, v76, v6                          // 0000003C0E48: CC1A4006 1C1A9967
	v_dot2_f32_bf16 v7, v107, v76, v7                          // 0000003C0E50: CC1A4007 1C1E996B
	v_dot2_f32_bf16 v8, v111, v76, v8                          // 0000003C0E58: CC1A4008 1C22996F
	v_dot2_f32_bf16 v1, v115, v76, v1                          // 0000003C0E60: CC1A4001 1C069973
	v_dot2_f32_bf16 v9, v97, v124, v9                          // 0000003C0E68: CC1A4009 1C26F961
	v_dot2_f32_bf16 v6, v104, v122, v6                         // 0000003C0E70: CC1A4006 1C1AF568
	v_dot2_f32_bf16 v7, v108, v122, v7                         // 0000003C0E78: CC1A4007 1C1EF56C
	v_dot2_f32_bf16 v8, v112, v122, v8                         // 0000003C0E80: CC1A4008 1C22F570
	v_dot2_f32_bf16 v1, v116, v122, v1                         // 0000003C0E88: CC1A4001 1C06F574
	v_dot2_f32_bf16 v9, v98, v123, v9                          // 0000003C0E90: CC1A4009 1C26F762
	v_dot2_f32_bf16 v6, v105, v124, v6                         // 0000003C0E98: CC1A4006 1C1AF969
	v_dot2_f32_bf16 v7, v109, v124, v7                         // 0000003C0EA0: CC1A4007 1C1EF96D
	v_dot2_f32_bf16 v8, v113, v124, v8                         // 0000003C0EA8: CC1A4008 1C22F971
	v_dot2_f32_bf16 v1, v117, v124, v1                         // 0000003C0EB0: CC1A4001 1C06F975
	v_dot2_f32_bf16 v9, v99, v126, v9                          // 0000003C0EB8: CC1A4009 1C26FD63
	v_dot2_f32_bf16 v6, v118, v123, v6                         // 0000003C0EC0: CC1A4006 1C1AF776
	s_waitcnt vmcnt(2)                                         // 0000003C0EC8: BF890BF7
	v_dot2_f32_bf16 v7, v42, v123, v7                          // 0000003C0ECC: CC1A4007 1C1EF72A
	s_waitcnt vmcnt(1)                                         // 0000003C0ED4: BF8907F7
	v_dot2_f32_bf16 v8, v38, v123, v8                          // 0000003C0ED8: CC1A4008 1C22F726
	s_waitcnt vmcnt(0)                                         // 0000003C0EE0: BF8903F7
	v_dot2_f32_bf16 v1, v46, v123, v1                          // 0000003C0EE4: CC1A4001 1C06F72E
	v_dot2_f32_bf16 v6, v119, v126, v6                         // 0000003C0EEC: CC1A4006 1C1AFD77
	v_dot2_f32_bf16 v7, v43, v126, v7                          // 0000003C0EF4: CC1A4007 1C1EFD2B
	v_dot2_f32_bf16 v9, v100, v29, v9                          // 0000003C0EFC: CC1A4009 1C263B64
	v_dot2_f32_bf16 v8, v39, v126, v8                          // 0000003C0F04: CC1A4008 1C22FD27
	v_dot2_f32_bf16 v1, v47, v126, v1                          // 0000003C0F0C: CC1A4001 1C06FD2F
	v_dot2_f32_bf16 v6, v120, v29, v6                          // 0000003C0F14: CC1A4006 1C1A3B78
	v_dot2_f32_bf16 v7, v44, v29, v7                           // 0000003C0F1C: CC1A4007 1C1E3B2C
	v_dot2_f32_bf16 v9, v101, v21, v9                          // 0000003C0F24: CC1A4009 1C262B65
	v_dot2_f32_bf16 v8, v40, v29, v8                           // 0000003C0F2C: CC1A4008 1C223B28
	v_dot2_f32_bf16 v1, v48, v29, v1                           // 0000003C0F34: CC1A4001 1C063B30
	v_dot2_f32_bf16 v6, v121, v21, v6                          // 0000003C0F3C: CC1A4006 1C1A2B79
	v_dot2_f32_bf16 v7, v45, v21, v7                           // 0000003C0F44: CC1A4007 1C1E2B2D
	v_add_f32_e32 v60, v60, v9                                 // 0000003C0F4C: 0678133C
	v_dot2_f32_bf16 v8, v41, v21, v8                           // 0000003C0F50: CC1A4008 1C222B29
	v_dot2_f32_bf16 v1, v49, v21, v1                           // 0000003C0F58: CC1A4001 1C062B31
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003C0F60: BF870114
	v_dual_add_f32 v59, v59, v6 :: v_dual_add_f32 v58, v58, v7 // 0000003C0F64: C9080D3B 3B3A0F3A
	v_dual_add_f32 v57, v57, v8 :: v_dual_add_f32 v56, v56, v1 // 0000003C0F6C: C9081139 39380338
	v_mov_b32_e32 v1, v5                                       // 0000003C0F74: 7E020305
	s_and_not1_b32 exec_lo, exec_lo, s19                       // 0000003C0F78: 917E137E
	s_cbranch_execz 428                                        // 0000003C0F7C: BFA501AC <_ZN7halogen12_GLOBAL__N_112k_hc6_fused3ILi5EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x2a30>
	v_dual_mov_b32 v6, v2 :: v_dual_add_nc_u32 v53, 32, v53    // 0000003C0F80: CA200102 06346AA0
	s_delay_alu instid0(VALU_DEP_2)                            // 0000003C0F88: BF870002
	v_dual_mov_b32 v5, v1 :: v_dual_mov_b32 v8, v4             // 0000003C0F8C: CA100101 05080104
	v_dual_mov_b32 v7, v3 :: v_dual_mov_b32 v38, v36           // 0000003C0F94: CA100103 07260124
	v_mov_b32_e32 v39, v37                                     // 0000003C0F9C: 7E4E0325
	s_mov_b32 s22, exec_lo                                     // 0000003C0FA0: BE96007E
	v_cmp_ge_i32_e32 vcc_lo, v53, v54                          // 0000003C0FA4: 7C8C6D35
	.long 0xd4c1007e                                           // 0000003C0FA8: D4C1007E
	v_cndmask_b32_e32 v1, v53, v54, vcc_lo                     // 0000003C0FAC: 02026D35
	s_cbranch_execz 64763                                      // 0000003C0FB0: BFA5FCFB <_ZN7halogen12_GLOBAL__N_112k_hc6_fused3ILi5EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x17a0>
	v_and_b32_e32 v7, -4, v67                                  // 0000003C0FB4: 360E86C4
	v_ashrrev_i32_e32 v6, 31, v65                              // 0000003C0FB8: 340C829F
	v_ashrrev_i32_e32 v8, 31, v66                              // 0000003C0FBC: 3410849F
	.long 0xd7000405                                           // 0000003C0FC0: D7000405
	v_cndmask_b32_e32 v1, v33, v65, vcc_lo                     // 0000003C0FC4: 02028321
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003C0FC8: BF870214
	v_ashrrev_i32_e32 v12, 31, v7                              // 0000003C0FCC: 34180E9F
	v_add_co_ci_u32_e64 v6, null, v55, v6, s4                  // 0000003C0FD0: D5207C06 00120D37
	.long 0xd7000409                                           // 0000003C0FD8: D7000409
	v_cndmask_b32_e32 v1, v61, v66, vcc_lo                     // 0000003C0FDC: 0202853D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003C0FE0: BF8700A1
	v_add_co_ci_u32_e64 v10, null, v62, v8, s4                 // 0000003C0FE4: D5207C0A 0012113E
	.long 0xd700040b                                           // 0000003C0FEC: D700040B
	v_cndmask_b32_e32 v1, v63, v7, vcc_lo                      // 0000003C0FF0: 02020F3F
	v_add_co_ci_u32_e64 v12, null, v64, v12, s4                // 0000003C0FF4: D5207C0C 00121940
	s_clause 0x2                                               // 0000003C0FFC: BF850002
	global_load_b128 v[5:8], v[5:6], off                       // 0000003C1000: DC5E0000 057C0005
	global_load_b64 v[38:39], v[9:10], off                     // 0000003C1008: DC560000 267C0009
	global_load_b32 v69, v[11:12], off                         // 0000003C1010: DC520000 457C000B
	s_branch 64737                                             // 0000003C1018: BFA0FCE1 <_ZN7halogen12_GLOBAL__N_112k_hc6_fused3ILi5EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x17a0>
	s_mov_b32 s3, 0                                            // 0000003C101C: BE830080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000003C1020: BF870009
	s_and_not1_b32 vcc_lo, exec_lo, s3                         // 0000003C1024: 916A037E
	s_cbranch_vccnz 979                                        // 0000003C1028: BFA403D3 <_ZN7halogen12_GLOBAL__N_112k_hc6_fused3ILi5EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x3378>
	s_load_b256 s[4:11], s[0:1], null                          // 0000003C102C: F40C0100 F8000000
	s_ashr_i32 s3, s2, 31                                      // 0000003C1034: 86039F02
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v5, v0              // 0000003C1038: CA100080 02040100
	s_lshr_b32 s14, s3, 30                                     // 0000003C1040: 850E9E03
	s_load_b32 s1, s[0:1], 0x1b4                               // 0000003C1044: F4000040 F80001B4
	s_add_i32 s16, s2, s14                                     // 0000003C104C: 81100E02
	s_lshl_b64 s[14:15], s[2:3], 2                             // 0000003C1050: 848E8202
	s_ashr_i32 s3, s16, 2                                      // 0000003C1054: 86038210
	s_mul_i32 s0, s2, 0x1400                                   // 0000003C1058: 9600FF02 00001400
	v_dual_mov_b32 v4, 0 :: v_dual_mov_b32 v1, v0              // 0000003C1060: CA100080 04000100
	s_waitcnt lgkmcnt(0)                                       // 0000003C1068: BF89FC07
	s_add_u32 s8, s8, s14                                      // 0000003C106C: 80080E08
	s_addc_u32 s9, s9, s15                                     // 0000003C1070: 82090F09
	s_add_u32 s0, s4, s0                                       // 0000003C1074: 80000004
	global_load_b32 v3, v2, s[8:9]                             // 0000003C1078: DC520000 03080002
	s_mul_hi_i32 s8, s2, 0x1400                                // 0000003C1080: 9708FF02 00001400
	s_mul_i32 s9, s3, 0x1400                                   // 0000003C1088: 9609FF03 00001400
	s_addc_u32 s8, s5, s8                                      // 0000003C1090: 82080805
	s_mul_hi_i32 s14, s3, 0x1400                               // 0000003C1094: 970EFF03 00001400
	s_add_u32 s6, s6, s9                                       // 0000003C109C: 80060906
	s_addc_u32 s7, s7, s14                                     // 0000003C10A0: 82070E07
	s_and_b32 s1, s1, 0xffff                                   // 0000003C10A4: 8B01FF01 0000FFFF
	s_mov_b32 s9, 0                                            // 0000003C10AC: BE890080
	s_set_inst_prefetch_distance 0x1                           // 0000003C10B0: BF840001
	s_nop 0                                                    // 0000003C10B4: BF800000
	s_nop 0                                                    // 0000003C10B8: BF800000
	s_nop 0                                                    // 0000003C10BC: BF800000
	.long 0xd73c0006                                           // 0000003C10C0: D73C0006
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 0000003C10C4: 02020281
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003C10C8: BF870091
	.long 0xd7006a08                                           // 0000003C10CC: D7006A08
	v_cndmask_b32_e32 v1, s0, v6, vcc_lo                       // 0000003C10D0: 02020C00
	v_add_co_ci_u32_e64 v9, null, s8, v7, vcc_lo               // 0000003C10D4: D5207C09 01AA0E08
	.long 0xd7006a06                                           // 0000003C10DC: D7006A06
	v_cndmask_b32_e32 v1, s6, v6, vcc_lo                       // 0000003C10E0: 02020C06
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003C10E4: BF870001
	v_add_co_ci_u32_e64 v7, null, s7, v7, vcc_lo               // 0000003C10E8: D5207C07 01AA0E07
	global_load_u16 v10, v[8:9], off                           // 0000003C10F0: DC4A0000 0A7C0008
	global_load_u16 v6, v[6:7], off                            // 0000003C10F8: DC4A0000 067C0006
	s_waitcnt vmcnt(1)                                         // 0000003C1100: BF8907F7
	v_lshlrev_b32_e32 v7, 16, v10                              // 0000003C1104: 300E1490
	s_waitcnt vmcnt(0)                                         // 0000003C1108: BF8903F7
	v_lshlrev_b32_e32 v6, 16, v6                               // 0000003C110C: 300C0C90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003C1110: BF870091
	v_fmac_f32_e32 v7, v3, v6                                  // 0000003C1114: 560E0D03
	v_bfe_u32 v6, v7, 16, 1                                    // 0000003C1118: D6100006 02052107
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003C1120: BF870091
	v_add3_u32 v6, v7, v6, 0x7fff                              // 0000003C1124: D6550006 03FE0D07 00007FFF
	v_and_b32_e32 v7, 0xffff0000, v6                           // 0000003C1130: 360E0CFF FFFF0000
	v_add_nc_u32_e32 v1, s1, v1                                // 0000003C1138: 4A020201
	global_store_d16_hi_b16 v[8:9], v6, off                    // 0000003C113C: DC960000 007C0608
	v_fmac_f32_e32 v4, v7, v7                                  // 0000003C1144: 56080F07
	v_cmp_lt_u32_e32 vcc_lo, 0x9ff, v1                         // 0000003C1148: 7C9202FF 000009FF
	s_or_b32 s9, vcc_lo, s9                                    // 0000003C1150: 8C09096A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000003C1154: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s9                        // 0000003C1158: 917E097E
	s_cbranch_execnz 65496                                     // 0000003C115C: BFA6FFD8 <_ZN7halogen12_GLOBAL__N_112k_hc6_fused3ILi5EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x24c0>
	s_set_inst_prefetch_distance 0x2                           // 0000003C1160: BF840002
	s_or_b32 exec_lo, exec_lo, s9                              // 0000003C1164: 8C7E097E
	v_lshlrev_b32_e32 v1, 2, v0                                // 0000003C1168: 30020082
	s_lshr_b32 s6, s1, 1                                       // 0000003C116C: 85068101
	s_mov_b32 s0, 0                                            // 0000003C1170: BE800080
	ds_store_b32 v1, v4                                        // 0000003C1174: D8340000 00000401
	s_waitcnt lgkmcnt(0)                                       // 0000003C117C: BF89FC07
	s_waitcnt_vscnt null, 0x0                                  // 0000003C1180: BC7C0000
	s_barrier                                                  // 0000003C1184: BFBD0000
	s_branch 17                                                // 0000003C1188: BFA00011 <_ZN7halogen12_GLOBAL__N_112k_hc6_fused3ILi5EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x25d0>
	s_nop 0                                                    // 0000003C118C: BF800000
	s_nop 0                                                    // 0000003C1190: BF800000
	s_nop 0                                                    // 0000003C1194: BF800000
	s_nop 0                                                    // 0000003C1198: BF800000
	s_nop 0                                                    // 0000003C119C: BF800000
	s_nop 0                                                    // 0000003C11A0: BF800000
	s_nop 0                                                    // 0000003C11A4: BF800000
	s_nop 0                                                    // 0000003C11A8: BF800000
	s_nop 0                                                    // 0000003C11AC: BF800000
	s_nop 0                                                    // 0000003C11B0: BF800000
	s_nop 0                                                    // 0000003C11B4: BF800000
	s_nop 0                                                    // 0000003C11B8: BF800000
	s_nop 0                                                    // 0000003C11BC: BF800000
	s_or_b32 exec_lo, exec_lo, s7                              // 0000003C11C0: 8C7E077E
	s_waitcnt lgkmcnt(0)                                       // 0000003C11C4: BF89FC07
	s_barrier                                                  // 0000003C11C8: BFBD0000
	s_lshr_b32 s6, s6, 1                                       // 0000003C11CC: 85068106
	buffer_gl0_inv                                             // 0000003C11D0: E0AC0000 00000000
	s_cbranch_scc0 15                                          // 0000003C11D8: BFA1000F <_ZN7halogen12_GLOBAL__N_112k_hc6_fused3ILi5EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x2618>
	s_mov_b32 s7, exec_lo                                      // 0000003C11DC: BE87007E
	.long 0xd4cc007e                                           // 0000003C11E0: D4CC007E
	v_cndmask_b32_e32 v1, s6, v0, vcc_lo                       // 0000003C11E4: 02020006
	s_cbranch_execz 65525                                      // 0000003C11E8: BFA5FFF5 <_ZN7halogen12_GLOBAL__N_112k_hc6_fused3ILi5EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x25c0>
	v_lshl_add_u32 v2, s6, 2, v1                               // 0000003C11EC: D6460002 04050406
	ds_load_b32 v2, v2                                         // 0000003C11F4: D8D80000 02000002
	ds_load_b32 v3, v1                                         // 0000003C11FC: D8D80000 03000001
	s_waitcnt lgkmcnt(0)                                       // 0000003C1204: BF89FC07
	v_add_f32_e32 v2, v2, v3                                   // 0000003C1208: 06040702
	ds_store_b32 v1, v2                                        // 0000003C120C: D8340000 00000201
	s_branch 65514                                             // 0000003C1214: BFA0FFEA <_ZN7halogen12_GLOBAL__N_112k_hc6_fused3ILi5EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x25c0>
	v_mov_b32_e32 v1, 0                                        // 0000003C1218: 7E020280
	s_cmp_eq_u32 s1, 1                                         // 0000003C121C: BF068101
	s_mul_hi_i32 s6, s2, 0x1400                                // 0000003C1220: 9706FF02 00001400
	s_mul_i32 s7, s2, 0x1400                                   // 0000003C1228: 9607FF02 00001400
	ds_load_b32 v1, v1                                         // 0000003C1230: D8D80000 01000001
	s_waitcnt lgkmcnt(0)                                       // 0000003C1238: BF89FC07
	v_div_scale_f32 v2, null, 0x45200000, 0x45200000, v1       // 0000003C123C: D6FC7C02 0405FEFF 45200000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003C1248: BF870001
	v_rcp_f32_e32 v3, v2                                       // 0000003C124C: 7E065502
	v_xor_b32_e32 v2, 0x80000000, v2                           // 0000003C1250: 3A0404FF 80000000
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(VALU_DEP_1)   // 0000003C1258: BF870085
	v_fma_f32 v4, v2, v3, 1.0                                  // 0000003C125C: D6130004 03CA0702
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003C1264: BF8700A1
	v_fmac_f32_e32 v3, v4, v3                                  // 0000003C1268: 56060704
	v_div_scale_f32 v4, vcc_lo, v1, 0x45200000, v1             // 0000003C126C: D6FC6A04 0405FF01 45200000
	v_mul_f32_e32 v6, v4, v3                                   // 0000003C1278: 100C0704
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003C127C: BF870091
	v_fma_f32 v7, v2, v6, v4                                   // 0000003C1280: D6130007 04120D02
	v_fmac_f32_e32 v6, v7, v3                                  // 0000003C1288: 560C0707
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003C128C: BF870091
	v_fmac_f32_e32 v4, v2, v6                                  // 0000003C1290: 56080D02
	v_div_fmas_f32 v2, v4, v3, v6                              // 0000003C1294: D6370002 041A0704
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003C129C: BF870091
	v_div_fixup_f32 v1, v2, 0x45200000, v1                     // 0000003C12A0: D6270001 0405FF02 45200000
	v_add_f32_e32 v1, 0x358637bd, v1                           // 0000003C12AC: 060202FF 358637BD
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000003C12B4: BF870121
	v_mul_f32_e32 v2, 0x4b800000, v1                           // 0000003C12B8: 100402FF 4B800000
	v_cmp_gt_f32_e32 vcc_lo, 0x800000, v1                      // 0000003C12C0: 7C2802FF 00800000
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 0000003C12C8: 02020501
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000003C12CC: BF870291
	v_rsq_f32_e32 v1, v1                                       // 0000003C12D0: 7E025D01
	v_mul_f32_e32 v2, 0x45800000, v1                           // 0000003C12D4: 100402FF 45800000
	s_cbranch_scc1 5                                           // 0000003C12DC: BFA20005 <_ZN7halogen12_GLOBAL__N_112k_hc6_fused3ILi5EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x26f4>
	s_mov_b32 s0, -1                                           // 0000003C12E0: BE8000C1
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003C12E4: BF870001
	v_cndmask_b32_e32 v7, v1, v2, vcc_lo                       // 0000003C12E8: 020E0501
	s_cbranch_execz 3                                          // 0000003C12EC: BFA50003 <_ZN7halogen12_GLOBAL__N_112k_hc6_fused3ILi5EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x26fc>
	s_branch 95                                                // 0000003C12F0: BFA0005F <_ZN7halogen12_GLOBAL__N_112k_hc6_fused3ILi5EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x2870>
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003C12F4: BF870001
	v_cndmask_b32_e32 v7, v1, v2, vcc_lo                       // 0000003C12F8: 020E0501
	v_sub_nc_u32_e32 v8, 0xa00, v0                             // 0000003C12FC: 4C1000FF 00000A00
	v_lshl_or_b32 v2, v0, 1, s7                                // 0000003C1304: D6560002 001D0300
	s_mul_i32 s0, s2, 0xa00                                    // 0000003C130C: 9600FF02 00000A00
	v_mov_b32_e32 v6, s6                                       // 0000003C1314: 7E0C0206
	v_or_b32_e32 v1, s0, v0                                    // 0000003C1318: 38020000
	v_and_b32_e32 v9, 0xbfe, v8                                // 0000003C131C: 361210FF 00000BFE
	.long 0xd7006a03                                           // 0000003C1324: D7006A03
	v_cndmask_b32_e32 v1, s4, v2, vcc_lo                       // 0000003C1328: 02020404
	s_mul_i32 s0, s3, 0x2800                                   // 0000003C132C: 9600FF03 00002800
	v_add_co_ci_u32_e64 v4, null, s5, v6, vcc_lo               // 0000003C1334: D5207C04 01AA0C05
	.long 0xd7006a05                                           // 0000003C133C: D7006A05
	v_cndmask_b32_e32 v1, s20, v2, vcc_lo                      // 0000003C1340: 02020414
	v_subrev_nc_u32_e32 v1, s0, v1                             // 0000003C1344: 4E020200
	v_add_co_ci_u32_e64 v6, null, s21, v6, vcc_lo              // 0000003C1348: D5207C06 01AA0C15
	v_mov_b32_e32 v10, v9                                      // 0000003C1350: 7E140309
	s_mov_b32 s8, 0                                            // 0000003C1354: BE880080
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000003C1358: BF8700B3
	v_ashrrev_i32_e32 v2, 31, v1                               // 0000003C135C: 3404029F
	global_load_b32 v13, v[3:4], off                           // 0000003C1360: DC520000 0D7C0003
	.long 0xd73c000b                                           // 0000003C1368: D73C000B
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 0000003C136C: 02020281
	.long 0xd7006a0b                                           // 0000003C1370: D7006A0B
	v_cndmask_b32_e32 v1, s10, v11, vcc_lo                     // 0000003C1374: 0202160A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003C1378: BF8700A1
	v_add_co_ci_u32_e64 v12, null, s11, v12, vcc_lo            // 0000003C137C: D5207C0C 01AA180B
	.long 0xd7006a03                                           // 0000003C1384: D7006A03
	v_cndmask_b32_e32 v0, v3, v132, vcc_lo                     // 0000003C1388: 02010903
	v_add_co_ci_u32_e64 v4, null, 0, v4, vcc_lo                // 0000003C138C: D5207C04 01AA0880
	global_load_b32 v2, v[11:12], off                          // 0000003C1394: DC520000 027C000B
	.long 0x7f163880                                           // 0000003C139C: 7F163880
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000003C13A0: BF8700D1
	.long 0x7f18398b                                           // 0000003C13A4: 7F18398B
	s_waitcnt vmcnt(1)                                         // 0000003C13A8: BF8907F7
	.long 0x7e1c390d                                           // 0000003C13AC: 7E1C390D
	s_waitcnt vmcnt(0)                                         // 0000003C13B0: BF8903F7
	.long 0x7e1e3902                                           // 0000003C13B4: 7E1E3902
	v_lshlrev_b32_e32 v15, 16, v15                             // 0000003C13B8: 301E1E90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003C13BC: BF870091
	v_dual_add_f32 v15, 1.0, v15 :: v_dual_lshlrev_b32 v14, 16, v14// 0000003C13C0: C9221EF2 0F0E1C90
	v_dual_mul_f32 v14, v7, v14 :: v_dual_add_nc_u32 v1, 2, v1 // 0000003C13C8: C8E01D07 0E000282
	v_and_b32_e32 v2, 0xffff0000, v2                           // 0000003C13D0: 360404FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003C13D8: BF870091
	v_dual_add_f32 v2, 1.0, v2 :: v_dual_and_b32 v13, 0xffff0000, v13// 0000003C13DC: C92404F2 020C1AFF FFFF0000
	v_dual_mul_f32 v13, v7, v13 :: v_dual_add_nc_u32 v10, -2, v10// 0000003C13E8: C8E01B07 0D0A14C2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003C13F0: BF870111
	v_cmp_eq_u32_e32 vcc_lo, 0, v10                            // 0000003C13F4: 7C941480
	v_dual_mul_f32 v2, v13, v2 :: v_dual_mul_f32 v13, v14, v15 // 0000003C13F8: C8C6050D 020C1F0E
	s_or_b32 s8, vcc_lo, s8                                    // 0000003C1400: 8C08086A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003C1404: BF870111
	.long 0x7e163982                                           // 0000003C1408: 7E163982
	.long 0x7e18398d                                           // 0000003C140C: 7E18398D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003C1410: BF870112
	v_and_b32_e32 v11, 1, v11                                  // 0000003C1414: 36161681
	v_and_b32_e32 v12, 1, v12                                  // 0000003C1418: 36181881
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003C141C: BF870112
	v_add3_u32 v2, v2, v11, 0x7fff                             // 0000003C1420: D6550002 03FE1702 00007FFF
	v_add3_u32 v11, v13, v12, 0x7fff                           // 0000003C142C: D655000B 03FE190D 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000003C1438: BF8700B1
	.long 0x7e04398b                                           // 0000003C143C: 7E04398B
	global_store_b32 v[5:6], v2, off                           // 0000003C1440: DC6A0000 007C0205
	.long 0xd7000005                                           // 0000003C1448: D7000005
	v_cndmask_b32_e32 v0, v5, v132, vcc_lo                     // 0000003C144C: 02010905
	v_add_co_ci_u32_e64 v6, null, 0, v6, s0                    // 0000003C1450: D5207C06 00020C80
	s_and_not1_b32 exec_lo, exec_lo, s8                        // 0000003C1458: 917E087E
	s_cbranch_execnz 65470                                     // 0000003C145C: BFA6FFBE <_ZN7halogen12_GLOBAL__N_112k_hc6_fused3ILi5EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x2758>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000003C1460: 8C7E087E
	v_add_nc_u32_e32 v5, v0, v9                                // 0000003C1464: 4A0A1300
	.long 0xd44d0000                                           // 0000003C1468: D44D0000
	v_cndmask_b32_e32 v1, v8, v9, vcc_lo                       // 0000003C146C: 02021308
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003C1470: BF870001
	s_and_saveexec_b32 s8, s0                                  // 0000003C1474: BE882000
	s_cbranch_execz 79                                         // 0000003C1478: BFA5004F <_ZN7halogen12_GLOBAL__N_112k_hc6_fused3ILi5EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x29b8>
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000003C147C: BF8704A2
	v_lshlrev_b32_e32 v1, 1, v5                                // 0000003C1480: 30020A81
	s_lshl_b32 s0, s3, 2                                       // 0000003C1484: 84008203
	s_sub_i32 s2, s2, s0                                       // 0000003C1488: 81820002
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003C148C: BF870099
	s_mulk_i32 s2, 0xa00                                       // 0000003C1490: B8020A00
	.long 0xd7000303                                           // 0000003C1494: D7000303
	v_cndmask_b32_e32 v1, s7, v1, vcc_lo                       // 0000003C1498: 02020207
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000003C149C: BF8700B1
	v_add_co_ci_u32_e64 v4, null, s6, 0, s3                    // 0000003C14A0: D5207C04 000D0006
	s_lshl_b32 s3, s1, 1                                       // 0000003C14A8: 84038101
	.long 0xd7006a01                                           // 0000003C14AC: D7006A01
	v_cndmask_b32_e32 v1, s4, v3, vcc_lo                       // 0000003C14B0: 02020604
	v_add_co_ci_u32_e64 v2, null, s5, v4, vcc_lo               // 0000003C14B4: D5207C02 01AA0805
	.long 0xd7006a03                                           // 0000003C14BC: D7006A03
	v_cndmask_b32_e32 v1, s20, v3, vcc_lo                      // 0000003C14C0: 02020614
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003C14C4: BF870001
	v_add_co_ci_u32_e64 v4, null, s21, v4, vcc_lo              // 0000003C14C8: D5207C04 01AA0815
	s_mov_b32 s4, 0                                            // 0000003C14D0: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000003C14D4: BF840001
	s_nop 0                                                    // 0000003C14D8: BF800000
	s_nop 0                                                    // 0000003C14DC: BF800000
	s_nop 0                                                    // 0000003C14E0: BF800000
	s_nop 0                                                    // 0000003C14E4: BF800000
	s_nop 0                                                    // 0000003C14E8: BF800000
	s_nop 0                                                    // 0000003C14EC: BF800000
	s_nop 0                                                    // 0000003C14F0: BF800000
	s_nop 0                                                    // 0000003C14F4: BF800000
	s_nop 0                                                    // 0000003C14F8: BF800000
	s_nop 0                                                    // 0000003C14FC: BF800000
	v_add_nc_u32_e32 v8, s2, v5                                // 0000003C1500: 4A100A02
	global_load_u16 v6, v[1:2], off                            // 0000003C1504: DC4A0000 067C0001
	v_ashrrev_i32_e32 v9, 31, v8                               // 0000003C150C: 3412109F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003C1510: BF870091
	.long 0xd73c0008                                           // 0000003C1514: D73C0008
	v_cndmask_b32_e32 v1, 1, v8, vcc_lo                        // 0000003C1518: 02021081
	.long 0xd7006a08                                           // 0000003C151C: D7006A08
	v_cndmask_b32_e32 v1, s10, v8, vcc_lo                      // 0000003C1520: 0202100A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003C1524: BF8700A1
	v_add_co_ci_u32_e64 v9, null, s11, v9, vcc_lo              // 0000003C1528: D5207C09 01AA120B
	.long 0xd7006a01                                           // 0000003C1530: D7006A01
	v_cndmask_b32_e32 v0, v1, v3, vcc_lo                       // 0000003C1534: 02000701
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 0000003C1538: D5207C02 01AA0480
	global_load_u16 v8, v[8:9], off                            // 0000003C1540: DC4A0000 087C0008
	s_waitcnt vmcnt(1)                                         // 0000003C1548: BF8907F7
	v_lshlrev_b32_e32 v6, 16, v6                               // 0000003C154C: 300C0C90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003C1550: BF870091
	v_dual_mul_f32 v6, v7, v6 :: v_dual_add_nc_u32 v5, s1, v5  // 0000003C1554: C8E00D07 06040A01
	v_cmp_lt_u32_e32 vcc_lo, 0x9ff, v5                         // 0000003C155C: 7C920AFF 000009FF
	s_or_b32 s4, vcc_lo, s4                                    // 0000003C1564: 8C04046A
	s_waitcnt vmcnt(0)                                         // 0000003C1568: BF8903F7
	v_lshlrev_b32_e32 v8, 16, v8                               // 0000003C156C: 30101090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003C1570: BF870091
	v_add_f32_e32 v8, 1.0, v8                                  // 0000003C1574: 061010F2
	v_mul_f32_e32 v6, v6, v8                                   // 0000003C1578: 100C1106
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003C157C: BF870091
	v_bfe_u32 v8, v6, 16, 1                                    // 0000003C1580: D6100008 02052106
	v_add3_u32 v6, v6, v8, 0x7fff                              // 0000003C1588: D6550006 03FE1106 00007FFF
	global_store_d16_hi_b16 v[3:4], v6, off                    // 0000003C1594: DC960000 007C0603
	.long 0xd7000003                                           // 0000003C159C: D7000003
	v_cndmask_b32_e32 v0, v3, v3, vcc_lo                       // 0000003C15A0: 02000703
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003C15A4: BF870001
	v_add_co_ci_u32_e64 v4, null, 0, v4, s0                    // 0000003C15A8: D5207C04 00020880
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000003C15B0: 917E047E
	s_cbranch_execnz 65490                                     // 0000003C15B4: BFA6FFD2 <_ZN7halogen12_GLOBAL__N_112k_hc6_fused3ILi5EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x2900>
	s_set_inst_prefetch_distance 0x2                           // 0000003C15B8: BF840002
	s_or_b32 exec_lo, exec_lo, s8                              // 0000003C15BC: 8C7E087E
	s_waitcnt_vscnt null, 0x0                                  // 0000003C15C0: BC7C0000
	s_barrier                                                  // 0000003C15C4: BFBD0000
	buffer_gl0_inv                                             // 0000003C15C8: E0AC0000 00000000
	s_mov_b32 s0, exec_lo                                      // 0000003C15D0: BE80007E
	v_cmpx_eq_u32_e32 0, v0                                    // 0000003C15D4: 7D940080
	s_cbranch_execz 615                                        // 0000003C15D8: BFA50267 <_ZN7halogen12_GLOBAL__N_112k_hc6_fused3ILi5EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x3378>
	s_mov_b32 s0, exec_lo                                      // 0000003C15DC: BE80007E
	buffer_gl1_inv                                             // 0000003C15E0: E0B00000 00000000
	buffer_gl0_inv                                             // 0000003C15E8: E0AC0000 00000000
	.long 0xd71f0000                                           // 0000003C15F0: D71F0000
	v_cndmask_b32_e32 v0, s0, v128, vcc_lo                     // 0000003C15F4: 02010000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000003C15F8: BF8704A1
	v_cmp_eq_u32_e32 vcc_lo, 0, v0                             // 0000003C15FC: 7C940080
	s_and_b32 s1, exec_lo, vcc_lo                              // 0000003C1600: 8B016A7E
	s_mov_b32 exec_lo, s1                                      // 0000003C1604: BEFE0001
	s_cbranch_execz 603                                        // 0000003C1608: BFA5025B <_ZN7halogen12_GLOBAL__N_112k_hc6_fused3ILi5EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x3378>
	s_bcnt1_i32_b32 s0, s0                                     // 0000003C160C: BE801800
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000003C1610: BF870009
	v_dual_mov_b32 v1, 0 :: v_dual_mov_b32 v0, s0              // 0000003C1614: CA100080 01000000
	global_atomic_add_u64 v1, v[0:1], s[12:13]                 // 0000003C161C: DD0E0000 000C0001
	s_nop 0                                                    // 0000003C1624: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 0000003C1628: BFB60003
	s_endpgm                                                   // 0000003C162C: BFB00000
	s_or_b32 exec_lo, exec_lo, s19                             // 0000003C1630: 8C7E137E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000003C1634: BF8700B9
	s_or_b32 exec_lo, exec_lo, s5                              // 0000003C1638: 8C7E057E
	.long 0xd71f0001                                           // 0000003C163C: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000003C1640: 020100C1
	s_mov_b32 s4, exec_lo                                      // 0000003C1644: BE84007E
	v_xor_b32_e32 v2, 16, v1                                   // 0000003C1648: 3A040290
	v_xor_b32_e32 v7, 8, v1                                    // 0000003C164C: 3A0E0288
	v_xor_b32_e32 v12, 4, v1                                   // 0000003C1650: 3A180284
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000003C1654: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 0000003C1658: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 0000003C165C: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v7                            // 0000003C1660: 7C980EA0
	v_cndmask_b32_e32 v7, v1, v7, vcc_lo                       // 0000003C1664: 020E0F01
	v_cmp_gt_u32_e32 vcc_lo, 32, v12                           // 0000003C1668: 7C9818A0
	s_delay_alu instid0(VALU_DEP_2)                            // 0000003C166C: BF870002
	v_lshlrev_b32_e32 v7, 2, v7                                // 0000003C1670: 300E0E82
	v_lshlrev_b32_e32 v2, 2, v2                                // 0000003C1674: 30040482
	ds_bpermute_b32 v3, v2, v60                                // 0000003C1678: DACC0000 03003C02
	s_waitcnt lgkmcnt(0)                                       // 0000003C1680: BF89FC07
	v_add_f32_e32 v3, v60, v3                                  // 0000003C1684: 0606073C
	ds_bpermute_b32 v4, v2, v59                                // 0000003C1688: DACC0000 04003B02
	ds_bpermute_b32 v5, v2, v58                                // 0000003C1690: DACC0000 05003A02
	ds_bpermute_b32 v6, v2, v57                                // 0000003C1698: DACC0000 06003902
	ds_bpermute_b32 v2, v2, v56                                // 0000003C16A0: DACC0000 02003802
	ds_bpermute_b32 v8, v7, v3                                 // 0000003C16A8: DACC0000 08000307
	s_waitcnt lgkmcnt(3)                                       // 0000003C16B0: BF89FC37
	v_dual_add_f32 v4, v59, v4 :: v_dual_add_f32 v5, v58, v5   // 0000003C16B4: C908093B 04040B3A
	s_waitcnt lgkmcnt(2)                                       // 0000003C16BC: BF89FC27
	v_add_f32_e32 v6, v57, v6                                  // 0000003C16C0: 060C0D39
	s_waitcnt lgkmcnt(0)                                       // 0000003C16C4: BF89FC07
	v_dual_add_f32 v2, v56, v2 :: v_dual_add_f32 v3, v3, v8    // 0000003C16C8: C9080538 02021103
	ds_bpermute_b32 v9, v7, v4                                 // 0000003C16D0: DACC0000 09000407
	ds_bpermute_b32 v10, v7, v5                                // 0000003C16D8: DACC0000 0A000507
	ds_bpermute_b32 v11, v7, v6                                // 0000003C16E0: DACC0000 0B000607
	ds_bpermute_b32 v7, v7, v2                                 // 0000003C16E8: DACC0000 07000207
	v_cndmask_b32_e32 v12, v1, v12, vcc_lo                     // 0000003C16F0: 02181901
	s_waitcnt lgkmcnt(2)                                       // 0000003C16F4: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003C16F8: BF870001
	v_dual_add_f32 v5, v5, v10 :: v_dual_lshlrev_b32 v12, 2, v12// 0000003C16FC: C9221505 050C1882
	s_waitcnt lgkmcnt(1)                                       // 0000003C1704: BF89FC17
	v_add_f32_e32 v6, v6, v11                                  // 0000003C1708: 060C1706
	s_waitcnt lgkmcnt(0)                                       // 0000003C170C: BF89FC07
	v_add_f32_e32 v2, v2, v7                                   // 0000003C1710: 06040F02
	ds_bpermute_b32 v7, v12, v3                                // 0000003C1714: DACC0000 0700030C
	ds_bpermute_b32 v11, v12, v2                               // 0000003C171C: DACC0000 0B00020C
	v_add_f32_e32 v4, v4, v9                                   // 0000003C1724: 06081304
	ds_bpermute_b32 v9, v12, v5                                // 0000003C1728: DACC0000 0900050C
	s_waitcnt lgkmcnt(2)                                       // 0000003C1730: BF89FC27
	v_add_f32_e32 v3, v3, v7                                   // 0000003C1734: 06060F03
	s_waitcnt lgkmcnt(1)                                       // 0000003C1738: BF89FC17
	v_add_f32_e32 v7, v2, v11                                  // 0000003C173C: 060E1702
	ds_bpermute_b32 v8, v12, v4                                // 0000003C1740: DACC0000 0800040C
	s_waitcnt lgkmcnt(1)                                       // 0000003C1748: BF89FC17
	v_add_f32_e32 v5, v5, v9                                   // 0000003C174C: 060A1305
	ds_bpermute_b32 v10, v12, v6                               // 0000003C1750: DACC0000 0A00060C
	v_xor_b32_e32 v12, 2, v1                                   // 0000003C1758: 3A180282
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003C175C: BF8700A1
	v_cmp_gt_u32_e32 vcc_lo, 32, v12                           // 0000003C1760: 7C9818A0
	v_cndmask_b32_e32 v12, v1, v12, vcc_lo                     // 0000003C1764: 02181901
	v_lshlrev_b32_e32 v12, 2, v12                              // 0000003C1768: 30181882
	ds_bpermute_b32 v11, v12, v7                               // 0000003C176C: DACC0000 0B00070C
	s_waitcnt lgkmcnt(1)                                       // 0000003C1774: BF89FC17
	v_add_f32_e32 v6, v6, v10                                  // 0000003C1778: 060C1506
	ds_bpermute_b32 v2, v12, v3                                // 0000003C177C: DACC0000 0200030C
	ds_bpermute_b32 v9, v12, v5                                // 0000003C1784: DACC0000 0900050C
	ds_bpermute_b32 v10, v12, v6                               // 0000003C178C: DACC0000 0A00060C
	v_add_f32_e32 v4, v4, v8                                   // 0000003C1794: 06081104
	ds_bpermute_b32 v8, v12, v4                                // 0000003C1798: DACC0000 0800040C
	v_xor_b32_e32 v12, 1, v1                                   // 0000003C17A0: 3A180281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000003C17A4: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v12                           // 0000003C17A8: 7C9818A0
	v_cndmask_b32_e32 v1, v1, v12, vcc_lo                      // 0000003C17AC: 02021901
	s_waitcnt lgkmcnt(3)                                       // 0000003C17B0: BF89FC37
	v_dual_add_f32 v1, v3, v2 :: v_dual_lshlrev_b32 v12, 2, v1 // 0000003C17B4: C9220503 010C0282
	s_waitcnt lgkmcnt(2)                                       // 0000003C17BC: BF89FC27
	v_add_f32_e32 v3, v5, v9                                   // 0000003C17C0: 06061305
	v_add_f32_e32 v9, v7, v11                                  // 0000003C17C4: 06121707
	s_waitcnt lgkmcnt(0)                                       // 0000003C17C8: BF89FC07
	v_dual_add_f32 v5, v6, v10 :: v_dual_add_f32 v2, v4, v8    // 0000003C17CC: C9081506 05021104
	ds_bpermute_b32 v4, v12, v1                                // 0000003C17D4: DACC0000 0400010C
	ds_bpermute_b32 v7, v12, v3                                // 0000003C17DC: DACC0000 0700030C
	ds_bpermute_b32 v10, v12, v9                               // 0000003C17E4: DACC0000 0A00090C
	ds_bpermute_b32 v8, v12, v5                                // 0000003C17EC: DACC0000 0800050C
	ds_bpermute_b32 v6, v12, v2                                // 0000003C17F4: DACC0000 0600020C
	v_cmpx_eq_u32_e32 0, v50                                   // 0000003C17FC: 7D946480
	s_cbranch_execz 22                                         // 0000003C1800: BFA50016 <_ZN7halogen12_GLOBAL__N_112k_hc6_fused3ILi5EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x2c5c>
	s_waitcnt lgkmcnt(2)                                       // 0000003C1804: BF89FC27
	v_add_f32_e32 v9, v9, v10                                  // 0000003C1808: 06121509
	v_lshl_add_u32 v10, v51, s27, v52                          // 0000003C180C: D646000A 04D03733
	s_waitcnt lgkmcnt(0)                                       // 0000003C1814: BF89FC07
	v_dual_add_f32 v5, v5, v8 :: v_dual_add_f32 v2, v2, v6     // 0000003C1818: C9081105 05020D02
	v_add_f32_e32 v1, v1, v4                                   // 0000003C1820: 06020901
	v_add_f32_e32 v3, v3, v7                                   // 0000003C1824: 06060F03
	v_mad_u32_u24 v4, v10, 20, 0x4a0                           // 0000003C1828: D60B0004 03FD290A 000004A0
	v_mad_u32_u24 v6, v10, 20, 0x4a8                           // 0000003C1834: D60B0006 03FD290A 000004A8
	v_mul_u32_u24_e32 v7, 20, v10                              // 0000003C1840: 160E1494
	ds_store_2addr_b32 v4, v1, v2 offset1:1                    // 0000003C1844: D8380100 00020104
	ds_store_2addr_b32 v6, v3, v5 offset1:1                    // 0000003C184C: D8380100 00050306
	ds_store_b32 v7, v9 offset:1200                            // 0000003C1854: D83404B0 00000907
	s_or_b32 exec_lo, exec_lo, s4                              // 0000003C185C: 8C7E047E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000003C1860: BF870009
	s_and_b32 s4, s26, exec_lo                                 // 0000003C1864: 8B047E1A
	s_cselect_b32 s4, 5, 20                                    // 0000003C1868: 98049485
	s_mov_b32 s5, exec_lo                                      // 0000003C186C: BE85007E
	s_waitcnt lgkmcnt(0)                                       // 0000003C1870: BF89FC07
	s_barrier                                                  // 0000003C1874: BFBD0000
	buffer_gl0_inv                                             // 0000003C1878: E0AC0000 00000000
	.long 0xd4cc007e                                           // 0000003C1880: D4CC007E
	v_cndmask_b32_e32 v1, s4, v0, vcc_lo                       // 0000003C1884: 02020004
	s_cbranch_execz 416                                        // 0000003C1888: BFA501A0 <_ZN7halogen12_GLOBAL__N_112k_hc6_fused3ILi5EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x330c>
	s_load_b32 s4, s[8:9], 0x40                                // 0000003C188C: F4000104 F8000040
	.long 0xd7050001                                           // 0000003C1894: D7050001
	v_cndmask_b32_e32 v1, 0xcd, v0, vcc_lo                     // 0000003C1898: 020200FF 000000CD
	.long 0x7f0a3880                                           // 0000003C18A0: 7F0A3880
	v_mov_b32_e32 v4, 0                                        // 0000003C18A4: 7E080280
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000003C18A8: BF8704B3
	.long 0xd7390005                                           // 0000003C18AC: D7390005
	v_cndmask_b32_e32 v1, 10, v1, vcc_lo                       // 0000003C18B0: 0202028A
	s_waitcnt lgkmcnt(0)                                       // 0000003C18B4: BF89FC07
	s_sub_i32 s10, s24, s4                                     // 0000003C18B8: 818A0418
	s_ashr_i32 s11, s10, 31                                    // 0000003C18BC: 860B9F0A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000003C18C0: BF870499
	s_lshl_b64 s[10:11], s[10:11], s28                         // 0000003C18C4: 848A1C0A
	.long 0xd7000401                                           // 0000003C18C8: D7000401
	v_cndmask_b32_e32 v1, s10, v5, vcc_lo                      // 0000003C18CC: 02020A0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003C18D0: BF870091
	v_add_co_ci_u32_e64 v2, null, s11, 0, s4                   // 0000003C18D4: D5207C02 0011000B
	v_cmp_gt_i64_e32 vcc_lo, s[6:7], v[1:2]                    // 0000003C18DC: 7CA80206
	s_and_b32 exec_lo, exec_lo, vcc_lo                         // 0000003C18E0: 8B7E6A7E
	s_cbranch_execz 393                                        // 0000003C18E4: BFA50189 <_ZN7halogen12_GLOBAL__N_112k_hc6_fused3ILi5EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x330c>
	.long 0xd7050003                                           // 0000003C18E8: D7050003
	v_cndmask_b32_e32 v0, v5, v133, vcc_lo                     // 0000003C18EC: 02010B05
	v_lshlrev_b32_e32 v5, s27, v5                              // 0000003C18F0: 300A0A1B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003C18F4: BF870112
	.long 0xd7040003                                           // 0000003C18F8: D7040003
	v_cndmask_b32_e32 v1, v0, v3, vcc_lo                       // 0000003C18FC: 02020700
	v_mul_u32_u24_e32 v5, 20, v5                               // 0000003C1900: 160A0A94
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003C1904: BF870092
	v_and_b32_e32 v6, 0xff, v3                                 // 0000003C1908: 360C06FF 000000FF
	v_lshl_add_u32 v5, v6, 2, v5                               // 0000003C1910: D6460005 04150506
	ds_load_b32 v6, v5 offset:1184                             // 0000003C1918: D8D804A0 06000005
	v_add_nc_u32_e32 v5, 20, v5                                // 0000003C1920: 4A0A0A94
	s_add_i32 s25, s25, -1                                     // 0000003C1924: 8119C119
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000003C1928: BF870009
	s_cmp_eq_u32 s25, 0                                        // 0000003C192C: BF068019
	s_waitcnt lgkmcnt(0)                                       // 0000003C1930: BF89FC07
	v_add_f32_e32 v4, v4, v6                                   // 0000003C1934: 06080D04
	s_cbranch_scc0 65527                                       // 0000003C1938: BFA1FFF7 <_ZN7halogen12_GLOBAL__N_112k_hc6_fused3ILi5EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x2d18>
	s_clause 0x1                                               // 0000003C193C: BF850001
	s_load_b64 s[14:15], s[8:9], 0x38                          // 0000003C1940: F4040384 F8000038
	s_load_b64 s[10:11], s[8:9], 0x8                           // 0000003C1948: F4040284 F8000008
	v_and_b32_e32 v3, 0xff, v3                                 // 0000003C1950: 360606FF 000000FF
	s_mov_b32 s19, -1                                          // 0000003C1958: BE9300C1
	s_mov_b32 s18, 0                                           // 0000003C195C: BE920080
	s_mov_b32 s4, 0                                            // 0000003C1960: BE840080
	s_waitcnt lgkmcnt(0)                                       // 0000003C1964: BF89FC07
	s_cmp_lt_i32 s15, 3                                        // 0000003C1968: BF04830F
	s_cbranch_scc1 195                                         // 0000003C196C: BFA200C3 <_ZN7halogen12_GLOBAL__N_112k_hc6_fused3ILi5EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x307c>
	s_cmp_gt_i32 s15, 3                                        // 0000003C1970: BF02830F
	s_cbranch_scc0 73                                          // 0000003C1974: BFA10049 <_ZN7halogen12_GLOBAL__N_112k_hc6_fused3ILi5EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x2e9c>
	s_cmp_gt_i32 s15, 4                                        // 0000003C1978: BF02840F
	s_cbranch_scc0 73                                          // 0000003C197C: BFA10049 <_ZN7halogen12_GLOBAL__N_112k_hc6_fused3ILi5EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x2ea4>
	s_cmp_eq_u32 s15, 5                                        // 0000003C1980: BF06850F
	s_mov_b32 s4, -1                                           // 0000003C1984: BE8400C1
	s_cbranch_scc0 66                                          // 0000003C1988: BFA10042 <_ZN7halogen12_GLOBAL__N_112k_hc6_fused3ILi5EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x2e94>
	v_lshrrev_b32_e32 v5, 23, v2                               // 0000003C198C: 320A0497
	s_lshr_b32 s4, s7, 31                                      // 0000003C1990: 85049F07
	s_load_b64 s[8:9], s[8:9], 0x10                            // 0000003C1994: F4040204 F8000010
	s_add_u32 s22, s6, s4                                      // 0000003C199C: 80160406
	s_addc_u32 s23, s7, 0                                      // 0000003C19A0: 82178007
	.long 0xd7006a05                                           // 0000003C19A4: D7006A05
	v_cndmask_b32_e32 v1, v1, v5, vcc_lo                       // 0000003C19A8: 02020B01
	s_ashr_i64 s[22:23], s[22:23], 1                           // 0000003C19AC: 86968116
	v_add_co_ci_u32_e64 v10, null, 0, v2, vcc_lo               // 0000003C19B0: D5207C0A 01AA0480
	v_dual_mov_b32 v12, s11 :: v_dual_and_b32 v11, 0xfffffe00, v5// 0000003C19B8: CA24000B 0C0A0AFF FFFFFE00
	v_mad_u64_u32 v[5:6], null, s22, v3, 0                     // 0000003C19C4: D6FE7C05 02020616
	v_bfe_u32 v15, v4, 16, 1                                   // 0000003C19CC: D610000F 02052104
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003C19D4: BF870093
	.long 0xd7016a08                                           // 0000003C19D8: D7016A08
	v_cndmask_b32_e32 v1, v1, v11, vcc_lo                      // 0000003C19DC: 02021701
	v_sub_co_ci_u32_e64 v9, null, v2, v10, vcc_lo              // 0000003C19E0: D5217C09 01AA1502
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003C19E8: BF870194
	v_mad_u64_u32 v[6:7], null, s23, v3, v[6:7]                // 0000003C19EC: D6FE7C06 041A0617
	.long 0xd700040d                                           // 0000003C19F4: D700040D
	v_cndmask_b32_e32 v1, 0xffffff00, v8, vcc_lo               // 0000003C19F8: 020210FF FFFFFF00
	s_delay_alu instid0(VALU_DEP_3)                            // 0000003C1A00: BF870003
	v_cmp_gt_i64_e32 vcc_lo, 0x100, v[8:9]                     // 0000003C1A04: 7CA810FF 00000100
	v_mov_b32_e32 v7, s10                                      // 0000003C1A0C: 7E0E020A
	v_add_co_ci_u32_e64 v14, null, -1, v9, s4                  // 0000003C1A10: D5207C0E 001212C1
	s_mov_b32 s4, 0                                            // 0000003C1A18: BE840080
	.long 0xd73c0005                                           // 0000003C1A1C: D73C0005
	v_cndmask_b32_e32 v1, 1, v5, vcc_lo                        // 0000003C1A20: 02020A81
	s_waitcnt lgkmcnt(0)                                       // 0000003C1A24: BF89FC07
	v_dual_cndmask_b32 v8, v13, v8 :: v_dual_cndmask_b32 v7, s8, v7// 0000003C1A28: CA52110D 08060E08
	v_dual_cndmask_b32 v12, s9, v12 :: v_dual_cndmask_b32 v9, v14, v9// 0000003C1A30: CA521809 0C08130E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003C1A38: BF870092
	.long 0xd7006a07                                           // 0000003C1A3C: D7006A07
	v_cndmask_b32_e32 v1, v7, v5, vcc_lo                       // 0000003C1A40: 02020B07
	v_add_co_ci_u32_e64 v12, null, v12, v6, vcc_lo             // 0000003C1A44: D5207C0C 01AA0D0C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003C1A4C: BF870193
	.long 0xd73c0005                                           // 0000003C1A50: D73C0005
	v_cndmask_b32_e32 v1, 1, v8, vcc_lo                        // 0000003C1A54: 02021081
	.long 0xd7006a07                                           // 0000003C1A58: D7006A07
	v_cndmask_b32_e32 v1, v7, v11, vcc_lo                      // 0000003C1A5C: 02021707
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000003C1A60: BF8701A1
	v_add_co_ci_u32_e64 v8, null, v12, v10, vcc_lo             // 0000003C1A64: D5207C08 01AA150C
	v_add3_u32 v9, v4, v15, 0x7fff                             // 0000003C1A6C: D6550009 03FE1F04 00007FFF
	.long 0xd7006a05                                           // 0000003C1A78: D7006A05
	v_cndmask_b32_e32 v1, v7, v5, vcc_lo                       // 0000003C1A7C: 02020B07
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003C1A80: BF870001
	v_add_co_ci_u32_e64 v6, null, v8, v6, vcc_lo               // 0000003C1A84: D5207C06 01AA0D08
	global_store_d16_hi_b16 v[5:6], v9, off                    // 0000003C1A8C: DC960000 007C0905
	s_mov_b32 s8, 0                                            // 0000003C1A94: BE880080
	s_branch 3                                                 // 0000003C1A98: BFA00003 <_ZN7halogen12_GLOBAL__N_112k_hc6_fused3ILi5EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x2ea8>
	s_mov_b32 s8, -1                                           // 0000003C1A9C: BE8800C1
	s_branch 54                                                // 0000003C1AA0: BFA00036 <_ZN7halogen12_GLOBAL__N_112k_hc6_fused3ILi5EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x2f7c>
	s_mov_b32 s8, -1                                           // 0000003C1AA4: BE8800C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000003C1AA8: BF870009
	s_and_b32 vcc_lo, exec_lo, s8                              // 0000003C1AAC: 8B6A087E
	s_cbranch_vccz 49                                          // 0000003C1AB0: BFA30031 <_ZN7halogen12_GLOBAL__N_112k_hc6_fused3ILi5EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x2f78>
	v_mul_f32_e32 v5, 0xbfb8aa3b, v4                           // 0000003C1AB4: 100A08FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000003C1ABC: BF870291
	v_exp_f32_e32 v5, v5                                       // 0000003C1AC0: 7E0A4B05
	v_add_f32_e32 v9, 1.0, v5                                  // 0000003C1AC4: 06120AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003C1AC8: BF870091
	v_div_scale_f32 v8, null, v9, v9, 1.0                      // 0000003C1ACC: D6FC7C08 03CA1309
	v_rcp_f32_e32 v10, v8                                      // 0000003C1AD4: 7E145508
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003C1AD8: BF870095
	v_fma_f32 v5, -v8, v10, 1.0                                // 0000003C1ADC: D6130005 23CA1508
	v_fmac_f32_e32 v10, v5, v10                                // 0000003C1AE4: 56141505
	v_div_scale_f32 v11, vcc_lo, 1.0, v9, 1.0                  // 0000003C1AE8: D6FC6A0B 03CA12F2
	v_mad_u64_u32 v[5:6], null, s6, v3, 0                      // 0000003C1AF0: D6FE7C05 02020606
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003C1AF8: BF870112
	v_mul_f32_e32 v12, v11, v10                                // 0000003C1AFC: 1018150B
	v_mad_u64_u32 v[6:7], null, s7, v3, v[6:7]                 // 0000003C1B00: D6FE7C06 041A0607
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003C1B08: BF870092
	v_fma_f32 v13, -v8, v12, v11                               // 0000003C1B0C: D613000D 242E1908
	v_fmac_f32_e32 v12, v13, v10                               // 0000003C1B14: 5618150D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003C1B18: BF870113
	.long 0xd73c0005                                           // 0000003C1B1C: D73C0005
	v_cndmask_b32_e32 v1, 2, v5, vcc_lo                        // 0000003C1B20: 02020A82
	v_fma_f32 v11, -v8, v12, v11                               // 0000003C1B24: D613000B 242E1908
	.long 0xd73c0007                                           // 0000003C1B2C: D73C0007
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 0000003C1B30: 02020282
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003C1B34: BF870212
	v_div_fmas_f32 v10, v11, v10, v12                          // 0000003C1B38: D637000A 0432150B
	.long 0xd7006a05                                           // 0000003C1B40: D7006A05
	v_cndmask_b32_e32 v1, s10, v5, vcc_lo                      // 0000003C1B44: 02020A0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003C1B48: BF870191
	v_add_co_ci_u32_e64 v6, null, s11, v6, vcc_lo              // 0000003C1B4C: D5207C06 01AA0C0B
	v_div_fixup_f32 v9, v10, v9, 1.0                           // 0000003C1B54: D6270009 03CA130A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003C1B5C: BF870093
	.long 0xd7006a05                                           // 0000003C1B60: D7006A05
	v_cndmask_b32_e32 v1, v5, v7, vcc_lo                       // 0000003C1B64: 02020F05
	v_add_co_ci_u32_e64 v6, null, v6, v8, vcc_lo               // 0000003C1B68: D5207C06 01AA1106
	global_store_b32 v[5:6], v9, off                           // 0000003C1B70: DC6A0000 007C0905
	s_mov_b32 s8, 0                                            // 0000003C1B78: BE880080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000003C1B7C: BF870009
	s_and_b32 vcc_lo, exec_lo, s8                              // 0000003C1B80: 8B6A087E
	s_cbranch_vccz 60                                          // 0000003C1B84: BFA3003C <_ZN7halogen12_GLOBAL__N_112k_hc6_fused3ILi5EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x3078>
	v_bfe_u32 v5, v4, 16, 1                                    // 0000003C1B88: D6100005 02052104
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003C1B90: BF870091
	v_add3_u32 v5, v4, v5, 0x7fff                              // 0000003C1B94: D6550005 03FE0B04 00007FFF
	v_and_b32_e32 v5, 0xffff0000, v5                           // 0000003C1BA0: 360A0AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003C1BA8: BF870091
	v_mul_f32_e32 v5, s14, v5                                  // 0000003C1BAC: 100A0A0E
	v_mul_f32_e32 v5, 0xbfb8aa3b, v5                           // 0000003C1BB0: 100A0AFF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000003C1BB8: BF870291
	v_exp_f32_e32 v5, v5                                       // 0000003C1BBC: 7E0A4B05
	v_add_f32_e32 v9, 1.0, v5                                  // 0000003C1BC0: 06120AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003C1BC4: BF870091
	v_div_scale_f32 v8, null, v9, v9, 1.0                      // 0000003C1BC8: D6FC7C08 03CA1309
	v_rcp_f32_e32 v10, v8                                      // 0000003C1BD0: 7E145508
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003C1BD4: BF870095
	v_fma_f32 v5, -v8, v10, 1.0                                // 0000003C1BD8: D6130005 23CA1508
	v_fmac_f32_e32 v10, v5, v10                                // 0000003C1BE0: 56141505
	v_div_scale_f32 v11, vcc_lo, 1.0, v9, 1.0                  // 0000003C1BE4: D6FC6A0B 03CA12F2
	v_mad_u64_u32 v[5:6], null, s6, v3, 0                      // 0000003C1BEC: D6FE7C05 02020606
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003C1BF4: BF870092
	v_mul_f32_e32 v12, v11, v10                                // 0000003C1BF8: 1018150B
	v_fma_f32 v7, -v8, v12, v11                                // 0000003C1BFC: D6130007 242E1908
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003C1C04: BF870211
	v_fmac_f32_e32 v12, v7, v10                                // 0000003C1C08: 56181507
	v_mad_u64_u32 v[6:7], null, s7, v3, v[6:7]                 // 0000003C1C0C: D6FE7C06 041A0607
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003C1C14: BF870112
	v_fma_f32 v7, -v8, v12, v11                                // 0000003C1C18: D6130007 242E1908
	.long 0xd73c0005                                           // 0000003C1C20: D73C0005
	v_cndmask_b32_e32 v1, 2, v5, vcc_lo                        // 0000003C1C24: 02020A82
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000003C1C28: BF8701A2
	v_div_fmas_f32 v10, v7, v10, v12                           // 0000003C1C2C: D637000A 04321507
	.long 0xd73c0007                                           // 0000003C1C34: D73C0007
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 0000003C1C38: 02020282
	.long 0xd7006a05                                           // 0000003C1C3C: D7006A05
	v_cndmask_b32_e32 v1, s10, v5, vcc_lo                      // 0000003C1C40: 02020A0A
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000003C1C44: BF8701A3
	v_div_fixup_f32 v9, v10, v9, 1.0                           // 0000003C1C48: D6270009 03CA130A
	v_add_co_ci_u32_e64 v6, null, s11, v6, vcc_lo              // 0000003C1C50: D5207C06 01AA0C0B
	.long 0xd7006a05                                           // 0000003C1C58: D7006A05
	v_cndmask_b32_e32 v1, v5, v7, vcc_lo                       // 0000003C1C5C: 02020F05
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003C1C60: BF870193
	v_add_f32_e32 v9, v9, v9                                   // 0000003C1C64: 06121309
	v_add_co_ci_u32_e64 v6, null, v6, v8, vcc_lo               // 0000003C1C68: D5207C06 01AA1106
	global_store_b32 v[5:6], v9, off                           // 0000003C1C70: DC6A0000 007C0905
	s_mov_b32 s19, 0                                           // 0000003C1C78: BE930080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000003C1C7C: BF870009
	s_and_b32 vcc_lo, exec_lo, s19                             // 0000003C1C80: 8B6A137E
	s_cbranch_vccz 72                                          // 0000003C1C84: BFA30048 <_ZN7halogen12_GLOBAL__N_112k_hc6_fused3ILi5EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x31a8>
	s_cmp_gt_i32 s15, 1                                        // 0000003C1C88: BF02810F
	s_mov_b32 s8, -1                                           // 0000003C1C8C: BE8800C1
	s_cbranch_scc0 64                                          // 0000003C1C90: BFA10040 <_ZN7halogen12_GLOBAL__N_112k_hc6_fused3ILi5EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x3194>
	v_bfe_u32 v5, v4, 16, 1                                    // 0000003C1C94: D6100005 02052104
	s_mov_b32 s8, 0                                            // 0000003C1C9C: BE880080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003C1CA0: BF870091
	v_add3_u32 v5, v4, v5, 0x7fff                              // 0000003C1CA4: D6550005 03FE0B04 00007FFF
	v_and_b32_e32 v5, 0xffff0000, v5                           // 0000003C1CB0: 360A0AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003C1CB8: BF870091
	v_mul_f32_e32 v5, 0xbfb8aa3b, v5                           // 0000003C1CBC: 100A0AFF BFB8AA3B
	v_exp_f32_e32 v5, v5                                       // 0000003C1CC4: 7E0A4B05
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003C1CC8: BF870095
	v_add_f32_e32 v8, 1.0, v5                                  // 0000003C1CCC: 06100AF2
	v_div_scale_f32 v7, null, v8, v8, 1.0                      // 0000003C1CD0: D6FC7C07 03CA1108
	v_div_scale_f32 v10, vcc_lo, 1.0, v8, 1.0                  // 0000003C1CD8: D6FC6A0A 03CA10F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000003C1CE0: BF870292
	v_rcp_f32_e32 v9, v7                                       // 0000003C1CE4: 7E125507
	v_fma_f32 v5, -v7, v9, 1.0                                 // 0000003C1CE8: D6130005 23CA1307
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000003C1CF0: BF870121
	v_fmac_f32_e32 v9, v5, v9                                  // 0000003C1CF4: 56121305
	v_mad_u64_u32 v[5:6], null, s6, v3, 0                      // 0000003C1CF8: D6FE7C05 02020606
	v_mul_f32_e32 v11, v10, v9                                 // 0000003C1D00: 1016130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003C1D04: BF870091
	v_fma_f32 v12, -v7, v11, v10                               // 0000003C1D08: D613000C 242A1707
	v_fmac_f32_e32 v11, v12, v9                                // 0000003C1D10: 5616130C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000003C1D14: BF870121
	v_fma_f32 v10, -v7, v11, v10                               // 0000003C1D18: D613000A 242A1707
	v_mad_u64_u32 v[6:7], null, s7, v3, v[6:7]                 // 0000003C1D20: D6FE7C06 041A0607
	v_div_fmas_f32 v7, v10, v9, v11                            // 0000003C1D28: D6370007 042E130A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003C1D30: BF870112
	.long 0xd73c0005                                           // 0000003C1D34: D73C0005
	v_cndmask_b32_e32 v1, 1, v5, vcc_lo                        // 0000003C1D38: 02020A81
	v_div_fixup_f32 v9, v7, v8, 1.0                            // 0000003C1D3C: D6270009 03CA1107
	.long 0xd73c0007                                           // 0000003C1D44: D73C0007
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 0000003C1D48: 02020281
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003C1D4C: BF870193
	.long 0xd7006a05                                           // 0000003C1D50: D7006A05
	v_cndmask_b32_e32 v1, s10, v5, vcc_lo                      // 0000003C1D54: 02020A0A
	v_bfe_u32 v10, v9, 16, 1                                   // 0000003C1D58: D610000A 02052109
	v_add_co_ci_u32_e64 v6, null, s11, v6, vcc_lo              // 0000003C1D60: D5207C06 01AA0C0B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003C1D68: BF870193
	.long 0xd7006a05                                           // 0000003C1D6C: D7006A05
	v_cndmask_b32_e32 v1, v5, v7, vcc_lo                       // 0000003C1D70: 02020F05
	v_add3_u32 v9, v9, v10, 0x7fff                             // 0000003C1D74: D6550009 03FE1509 00007FFF
	s_delay_alu instid0(VALU_DEP_3)                            // 0000003C1D80: BF870003
	v_add_co_ci_u32_e64 v6, null, v6, v8, vcc_lo               // 0000003C1D84: D5207C06 01AA1106
	global_store_d16_hi_b16 v[5:6], v9, off                    // 0000003C1D8C: DC960000 007C0905
	s_and_not1_b32 vcc_lo, exec_lo, s8                         // 0000003C1D94: 916A087E
	s_cbranch_vccnz 3                                          // 0000003C1D98: BFA40003 <_ZN7halogen12_GLOBAL__N_112k_hc6_fused3ILi5EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x31a8>
	s_cmp_lg_u32 s15, 1                                        // 0000003C1D9C: BF07810F
	s_mov_b32 s18, -1                                          // 0000003C1DA0: BE9200C1
	s_cselect_b32 s4, -1, 0                                    // 0000003C1DA4: 980480C1
	v_bfe_u32 v5, v4, 16, 1                                    // 0000003C1DA8: D6100005 02052104
	.long 0xd73c0001                                           // 0000003C1DB0: D73C0001
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 0000003C1DB4: 02020281
	s_and_b32 vcc_lo, exec_lo, s4                              // 0000003C1DB8: 8B6A047E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000003C1DBC: BF870002
	v_add3_u32 v4, v4, v5, 0x7fff                              // 0000003C1DC0: D6550004 03FE0B04 00007FFF
	s_cbranch_vccz 20                                          // 0000003C1DCC: BFA30014 <_ZN7halogen12_GLOBAL__N_112k_hc6_fused3ILi5EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x3220>
	v_mad_u64_u32 v[5:6], null, s6, v3, 0                      // 0000003C1DD0: D6FE7C05 02020606
	s_mov_b32 s18, 0                                           // 0000003C1DD8: BE920080
	v_mad_u64_u32 v[6:7], null, s7, v3, v[6:7]                 // 0000003C1DDC: D6FE7C06 041A0607
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003C1DE4: BF870091
	.long 0xd73c0005                                           // 0000003C1DE8: D73C0005
	v_cndmask_b32_e32 v1, 1, v5, vcc_lo                        // 0000003C1DEC: 02020A81
	.long 0xd7006a05                                           // 0000003C1DF0: D7006A05
	v_cndmask_b32_e32 v1, s10, v5, vcc_lo                      // 0000003C1DF4: 02020A0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003C1DF8: BF870111
	v_add_co_ci_u32_e64 v6, null, s11, v6, vcc_lo              // 0000003C1DFC: D5207C06 01AA0C0B
	.long 0xd7006a05                                           // 0000003C1E04: D7006A05
	v_cndmask_b32_e32 v1, v5, v1, vcc_lo                       // 0000003C1E08: 02020305
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003C1E0C: BF870001
	v_add_co_ci_u32_e64 v6, null, v6, v2, vcc_lo               // 0000003C1E10: D5207C06 01AA0506
	global_store_d16_hi_b16 v[5:6], v4, off                    // 0000003C1E18: DC960000 007C0405
	s_and_not1_b32 vcc_lo, exec_lo, s18                        // 0000003C1E20: 916A127E
	s_cbranch_vccnz 57                                         // 0000003C1E24: BFA40039 <_ZN7halogen12_GLOBAL__N_112k_hc6_fused3ILi5EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x330c>
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003C1E28: BF870091
	v_and_b32_e32 v4, 0xffff0000, v4                           // 0000003C1E2C: 360808FF FFFF0000
	v_mul_f32_e32 v7, s14, v4                                  // 0000003C1E34: 100E080E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003C1E38: BF870091
	v_mul_f32_e32 v4, 0xbfb8aa3b, v7                           // 0000003C1E3C: 10080EFF BFB8AA3B
	v_exp_f32_e32 v4, v4                                       // 0000003C1E44: 7E084B04
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003C1E48: BF870095
	v_add_f32_e32 v8, 1.0, v4                                  // 0000003C1E4C: 061008F2
	v_div_scale_f32 v6, null, v8, v8, v7                       // 0000003C1E50: D6FC7C06 041E1108
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000003C1E58: BF870291
	v_rcp_f32_e32 v9, v6                                       // 0000003C1E5C: 7E125506
	v_fma_f32 v4, -v6, v9, 1.0                                 // 0000003C1E60: D6130004 23CA1306
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000003C1E68: BF870131
	v_fmac_f32_e32 v9, v4, v9                                  // 0000003C1E6C: 56121304
	v_div_scale_f32 v10, vcc_lo, v7, v8, v7                    // 0000003C1E70: D6FC6A0A 041E1107
	v_mad_u64_u32 v[4:5], null, s6, v3, 0                      // 0000003C1E78: D6FE7C04 02020606
	v_mul_f32_e32 v11, v10, v9                                 // 0000003C1E80: 1016130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003C1E84: BF870091
	v_fma_f32 v12, -v6, v11, v10                               // 0000003C1E88: D613000C 242A1706
	v_fmac_f32_e32 v11, v12, v9                                // 0000003C1E90: 5616130C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000003C1E94: BF870121
	v_fma_f32 v10, -v6, v11, v10                               // 0000003C1E98: D613000A 242A1706
	v_mad_u64_u32 v[5:6], null, s7, v3, v[5:6]                 // 0000003C1EA0: D6FE7C05 04160607
	v_div_fmas_f32 v3, v10, v9, v11                            // 0000003C1EA8: D6370003 042E130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003C1EB0: BF870191
	v_div_fixup_f32 v6, v3, v8, v7                             // 0000003C1EB4: D6270006 041E1103
	.long 0xd73c0003                                           // 0000003C1EBC: D73C0003
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 0000003C1EC0: 02020881
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003C1EC4: BF870112
	v_bfe_u32 v5, v6, 16, 1                                    // 0000003C1EC8: D6100005 02052106
	.long 0xd7006a03                                           // 0000003C1ED0: D7006A03
	v_cndmask_b32_e32 v1, s10, v3, vcc_lo                      // 0000003C1ED4: 0202060A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003C1ED8: BF870191
	v_add_co_ci_u32_e64 v4, null, s11, v4, vcc_lo              // 0000003C1EDC: D5207C04 01AA080B
	v_add3_u32 v5, v6, v5, 0x7fff                              // 0000003C1EE4: D6550005 03FE0B06 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003C1EF0: BF870093
	.long 0xd7006a01                                           // 0000003C1EF4: D7006A01
	v_cndmask_b32_e32 v1, v3, v1, vcc_lo                       // 0000003C1EF8: 02020303
	v_add_co_ci_u32_e64 v2, null, v4, v2, vcc_lo               // 0000003C1EFC: D5207C02 01AA0504
	global_store_d16_hi_b16 v[1:2], v5, off                    // 0000003C1F04: DC960000 007C0501
	s_or_b32 exec_lo, exec_lo, s5                              // 0000003C1F0C: 8C7E057E
	s_waitcnt_vscnt null, 0x0                                  // 0000003C1F10: BC7C0000
	s_barrier                                                  // 0000003C1F14: BFBD0000
	buffer_gl0_inv                                             // 0000003C1F18: E0AC0000 00000000
	s_and_saveexec_b32 s4, s3                                  // 0000003C1F20: BE842003
	s_cbranch_execz 18                                         // 0000003C1F24: BFA50012 <_ZN7halogen12_GLOBAL__N_112k_hc6_fused3ILi5EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x3370>
	s_mov_b32 s3, exec_lo                                      // 0000003C1F28: BE83007E
	buffer_gl1_inv                                             // 0000003C1F2C: E0B00000 00000000
	buffer_gl0_inv                                             // 0000003C1F34: E0AC0000 00000000
	.long 0xd71f0001                                           // 0000003C1F3C: D71F0001
	v_cndmask_b32_e32 v0, s3, v128, vcc_lo                     // 0000003C1F40: 02010003
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000003C1F44: BF8704A1
	v_cmp_eq_u32_e32 vcc_lo, 0, v1                             // 0000003C1F48: 7C940280
	s_and_b32 s5, exec_lo, vcc_lo                              // 0000003C1F4C: 8B056A7E
	s_mov_b32 exec_lo, s5                                      // 0000003C1F50: BEFE0005
	s_cbranch_execz 6                                          // 0000003C1F54: BFA50006 <_ZN7halogen12_GLOBAL__N_112k_hc6_fused3ILi5EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x3370>
	s_bcnt1_i32_b32 s3, s3                                     // 0000003C1F58: BE831803
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000003C1F5C: BF870009
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v1, s3              // 0000003C1F60: CA100080 02000003
	global_atomic_add_u64 v2, v[1:2], s[16:17]                 // 0000003C1F68: DD0E0000 00100102
	s_or_b32 exec_lo, exec_lo, s4                              // 0000003C1F70: 8C7E047E
	s_cbranch_execz 64557                                      // 0000003C1F74: BFA5FC2D <_ZN7halogen12_GLOBAL__N_112k_hc6_fused3ILi5EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x242c>
	s_nop 0                                                    // 0000003C1F78: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 0000003C1F7C: BFB60003
	s_endpgm                                                   // 0000003C1F80: BFB00000
		...

