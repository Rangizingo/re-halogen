0000000000a72700 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi0EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi>:
; _ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi0EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi():
	s_clause 0x1                                               // 000000A72700: BF850001
	s_load_b32 s3, s[0:1], 0x88                                // 000000A72704: F40000C0 F8000088
	s_load_b512 s[12:27], s[0:1], null                         // 000000A7270C: F4100300 F8000000
	v_and_b32_e32 v25, 31, v0                                  // 000000A72714: 3632009F
	v_lshrrev_b32_e32 v24, 5, v0                               // 000000A72718: 32300085
	s_mov_b32 s4, -1                                           // 000000A7271C: BE8400C1
	s_waitcnt lgkmcnt(0)                                       // 000000A72720: BF89FC07
	s_cmp_lt_i32 s2, s3                                        // 000000A72724: BF040302
	s_cbranch_scc1 2674                                        // 000000A72728: BFA20A72 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi0EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x29f4>
	s_load_b64 s[8:9], s[0:1], 0x7c                            // 000000A7272C: F4040200 F800007C
	s_sub_i32 s28, s2, s3                                      // 000000A72734: 819C0302
	s_clause 0x1                                               // 000000A72738: BF850001
	s_load_b256 s[44:51], s[0:1], 0x60                         // 000000A7273C: F40C0B00 F8000060
	s_load_b256 s[36:43], s[0:1], 0x40                         // 000000A72744: F40C0900 F8000040
	s_mov_b32 s34, 0                                           // 000000A7274C: BEA20080
	s_mov_b32 s33, exec_lo                                     // 000000A72750: BEA1007E
	s_waitcnt lgkmcnt(0)                                       // 000000A72754: BF89FC07
	s_abs_i32 s4, s9                                           // 000000A72758: BE841509
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_2)// 000000A7275C: BF870529
	s_cvt_f32_u32 s5, s4                                       // 000000A72760: BE856504
	s_sub_i32 s6, 0, s4                                        // 000000A72764: 81860480
	v_rcp_iflag_f32_e32 v1, s5                                 // 000000A72768: 7E025605
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_3)// 000000A7276C: BF8705A5
	v_readfirstlane_b32 s5, v1                                 // 000000A72770: 7E0A0501
	s_mul_f32 s5, s5, 0x4f7ffffe                               // 000000A72774: A205FF05 4F7FFFFE
	s_cvt_u32_f32 s5, s5                                       // 000000A7277C: BE856705
	s_delay_alu instid0(SALU_CYCLE_3) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000A72780: BF87049B
	s_mul_i32 s6, s6, s5                                       // 000000A72784: 96060506
	s_mul_hi_u32 s6, s5, s6                                    // 000000A72788: 96860605
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 000000A7278C: BF8704B9
	s_add_i32 s5, s5, s6                                       // 000000A72790: 81050605
	s_ashr_i32 s6, s9, 31                                      // 000000A72794: 86069F09
	s_mul_hi_u32 s3, s28, s5                                   // 000000A72798: 9683051C
	s_mul_i32 s5, s3, s4                                       // 000000A7279C: 96050403
	s_add_i32 s7, s3, 1                                        // 000000A727A0: 81078103
	s_sub_i32 s5, s28, s5                                      // 000000A727A4: 8185051C
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000A727A8: BF870009
	s_sub_i32 s10, s5, s4                                      // 000000A727AC: 818A0405
	s_cmp_ge_u32 s5, s4                                        // 000000A727B0: BF090405
	s_cselect_b32 s3, s7, s3                                   // 000000A727B4: 98030307
	s_cselect_b32 s5, s10, s5                                  // 000000A727B8: 9805050A
	s_add_i32 s7, s3, 1                                        // 000000A727BC: 81078103
	s_cmp_ge_u32 s5, s4                                        // 000000A727C0: BF090405
	s_cselect_b32 s3, s7, s3                                   // 000000A727C4: 98030307
	s_ashr_i32 s11, s50, 31                                    // 000000A727C8: 860B9F32
	s_xor_b32 s3, s3, s6                                       // 000000A727CC: 8D030603
	s_lshr_b32 s0, s11, 25                                     // 000000A727D0: 8500990B
	s_sub_i32 s10, s3, s6                                      // 000000A727D4: 818A0603
	s_add_i32 s0, s50, s0                                      // 000000A727D8: 81000032
	s_mul_i32 s30, s10, s9                                     // 000000A727DC: 961E090A
	s_ashr_i32 s0, s0, 7                                       // 000000A727E0: 86008700
	s_sub_i32 s29, s28, s30                                    // 000000A727E4: 819D1E1C
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000A727E8: BF870499
	s_mul_i32 s29, s29, s8                                     // 000000A727EC: 961D081D
	s_add_i32 s1, s29, s8                                      // 000000A727F0: 8101081D
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000A727F4: BF870499
	s_min_i32 s0, s0, s1                                       // 000000A727F8: 89000100
	s_sub_i32 s35, s0, s29                                     // 000000A727FC: 81A31D00
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000A72800: BF870499
	s_lshl_b32 s31, s35, 2                                     // 000000A72804: 841F8223
	.long 0xd4c4007e                                           // 000000A72808: D4C4007E
	v_cndmask_b32_e32 v1, s31, v24, vcc_lo                     // 000000A7280C: 0202301F
	s_cbranch_execz 503                                        // 000000A72810: BFA501F7 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi0EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x8f0>
	s_add_i32 s51, s48, -1                                     // 000000A72814: 8133C130
	s_cmp_lg_u64 s[40:41], 0                                   // 000000A72818: BF118028
	v_dual_mov_b32 v8, v24 :: v_dual_and_b32 v1, 1, v0         // 000000A7281C: CA240118 08000081
	s_cselect_b32 s52, -1, 0                                   // 000000A72824: 983480C1
	s_abs_i32 s53, s35                                         // 000000A72828: BEB51523
	v_and_b32_e32 v2, 2, v0                                    // 000000A7282C: 36040082
	s_cvt_f32_u32 s0, s53                                      // 000000A72830: BE806535
	v_lshlrev_b32_e32 v6, 3, v25                               // 000000A72834: 300C3283
	v_lshlrev_b32_e32 v7, 7, v24                               // 000000A72838: 300E3087
	v_and_b32_e32 v3, 4, v0                                    // 000000A7283C: 36060084
	v_rcp_iflag_f32_e32 v4, s0                                 // 000000A72840: 7E085600
	v_and_b32_e32 v5, 8, v0                                    // 000000A72844: 360A0088
	.long 0xd44a0001                                           // 000000A72848: D44A0001
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 000000A7284C: 02020280
	.long 0xd44a0003                                           // 000000A72850: D44A0003
	v_cndmask_b32_e32 v1, 0, v2, vcc_lo                        // 000000A72854: 02020480
	v_lshl_or_b32 v1, v24, 8, v6                               // 000000A72858: D6560001 04191118
	v_lshl_add_u32 v2, s29, 7, v7                              // 000000A72860: D6460002 041D0E1D
	s_ashr_i32 s55, s35, 31                                    // 000000A72868: 86379F23
	s_sub_i32 s57, 0, s53                                      // 000000A7286C: 81B93580
	s_mul_i32 s8, s55, 0x1400                                  // 000000A72870: 9608FF37 00001400
	.long 0xd44c0000                                           // 000000A72878: D44C0000
	v_cndmask_b32_e32 v1, 16, v25, vcc_lo                      // 000000A7287C: 02023290
	v_readfirstlane_b32 s5, v4                                 // 000000A72880: 7E0A0504
	.long 0xd44a0004                                           // 000000A72884: D44A0004
	v_cndmask_b32_e32 v1, 0, v3, vcc_lo                        // 000000A72888: 02020680
	v_subrev_nc_u32_e32 v9, s8, v1                             // 000000A7288C: 4E120208
	v_lshl_or_b32 v1, v25, 2, v2                               // 000000A72890: D6560001 04090519
	s_lshl_b32 s6, s35, 7                                      // 000000A72898: 84068723
	s_mul_f32 s7, s5, 0x4f7ffffe                               // 000000A7289C: A207FF05 4F7FFFFE
	.long 0xd44a0005                                           // 000000A728A4: D44A0005
	v_cndmask_b32_e32 v1, 0, v5, vcc_lo                        // 000000A728A8: 02020A80
	s_mov_b32 s54, 0x76543210                                  // 000000A728AC: BEB600FF 76543210
	s_lshl_b32 s56, s35, 8                                     // 000000A728B4: 84388823
	s_cvt_u32_f32 s7, s7                                       // 000000A728B8: BE876707
	s_mov_b32 s59, 0x3db504f3                                  // 000000A728BC: BEBB00FF 3DB504F3
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000A728C4: BF87049A
	s_mul_i32 s57, s57, s7                                     // 000000A728C8: 96390739
	s_mul_hi_u32 s8, s7, s57                                   // 000000A728CC: 96883907
	s_sub_i32 s57, 0, s6                                       // 000000A728D0: 81B90680
	s_add_i32 s58, s7, s8                                      // 000000A728D4: 813A0807
	s_branch 164                                               // 000000A728D8: BFA000A4 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi0EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x46c>
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A728DC: BF870091
	.long 0xd7006a02                                           // 000000A728E0: D7006A02
	v_cndmask_b32_e32 v1, s26, v2, vcc_lo                      // 000000A728E4: 0202041A
	v_add_co_ci_u32_e64 v3, null, s27, v3, vcc_lo              // 000000A728E8: D5207C03 01AA061B
	v_sub_f32_e32 v4, v15, v13                                 // 000000A728F0: 08081B0F
	v_add_nc_u32_e32 v1, 0x400, v1                             // 000000A728F4: 4A0202FF 00000400
	global_load_d16_b16 v2, v[2:3], off offset:6               // 000000A728FC: DC820006 027C0002
	s_waitcnt vmcnt(0)                                         // 000000A72904: BF8903F7
	v_fma_mix_f32 v5, v14, v2, v12 op_sel_hi:[0,1,0]           // 000000A72908: CC200005 1432050E
	v_fma_mix_f32 v2, -v14, v2, v12 op_sel_hi:[0,1,0]          // 000000A72910: CC200002 3432050E
	v_add_f32_e32 v3, v15, v13                                 // 000000A72918: 06061B0F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000A7291C: BF8701A2
	v_add_f32_e32 v7, v4, v2                                   // 000000A72920: 060E0504
	v_sub_f32_e32 v2, v4, v2                                   // 000000A72924: 08040504
	v_add_f32_e32 v6, v3, v5                                   // 000000A72928: 060C0B03
	v_sub_f32_e32 v3, v3, v5                                   // 000000A7292C: 08060B03
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A72930: BF870193
	v_mov_b32_dpp v13, v2 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A72934: 7E1A02FA FF016102
	v_mov_b32_dpp v4, v6 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A7293C: 7E0802FA FF016106
	v_cndmask_b32_e64 v6, -v6, v6, s1                          // 000000A72944: D5010006 20060D06
	v_cndmask_b32_e64 v2, -v2, v2, s1                          // 000000A7294C: D5010002 20060502
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000A72954: BF870142
	v_add_f32_e32 v4, v6, v4                                   // 000000A72958: 06080906
	v_mov_b32_dpp v5, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A7295C: 7E0A02FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, s1                          // 000000A72964: D5010007 20060F07
	.long 0xd72c0006                                           // 000000A7296C: D72C0006
	v_cndmask_b32_e32 v1, 0x1400, v11, vcc_lo                  // 000000A72970: 020216FF 00001400
	v_add_f32_e32 v5, v7, v5                                   // 000000A72978: 060A0B07
	v_mov_b32_dpp v7, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A7297C: 7E0E02FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, s3                          // 000000A72984: D5010004 200E0904
	s_delay_alu instid0(VALU_DEP_1)                            // 000000A7298C: BF870001
	v_add_f32_e32 v4, v4, v7                                   // 000000A72990: 06080F04
	v_mov_b32_dpp v12, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A72994: 7E1802FA FF016103
	v_cndmask_b32_e64 v3, -v3, v3, s1                          // 000000A7299C: D5010003 20060703
	.long 0xd72c0007                                           // 000000A729A4: D72C0007
	v_cndmask_b32_e32 v1, s56, v10, vcc_lo                     // 000000A729A8: 02021438
	v_add_f32_e32 v2, v2, v13                                  // 000000A729AC: 06041B02
	v_mov_b32_dpp v10, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A729B0: 7E1402FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s4                          // 000000A729B8: D5010004 20120904
	v_add_f32_e32 v3, v3, v12                                  // 000000A729C0: 06061903
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000A729C4: BF870224
	v_mov_b32_dpp v13, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A729C8: 7E1A02FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, s3                          // 000000A729D0: D5010002 200E0502
	v_add_f32_e32 v4, v4, v10                                  // 000000A729D8: 06081504
	v_mov_b32_dpp v11, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A729DC: 7E1602FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, s3                          // 000000A729E4: D5010005 200E0B05
	v_mov_b32_dpp v12, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A729EC: 7E1802FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, s3                          // 000000A729F4: D5010003 200E0703
	v_add_f32_e32 v2, v2, v13                                  // 000000A729FC: 06041B02
	v_mov_b32_dpp v10, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A72A00: 7E1402FA FF016804
	v_add_f32_e32 v5, v5, v11                                  // 000000A72A08: 060A1705
	v_cndmask_b32_e64 v4, -v4, v4, s5                          // 000000A72A0C: D5010004 20160904
	v_add_f32_e32 v3, v3, v12                                  // 000000A72A14: 06061903
	v_mov_b32_dpp v13, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A72A18: 7E1A02FA FF016402
	v_cndmask_b32_e64 v2, -v2, v2, s4                          // 000000A72A20: D5010002 20120502
	v_mov_b32_dpp v11, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A72A28: 7E1602FA FF016405
	v_cndmask_b32_e64 v5, -v5, v5, s4                          // 000000A72A30: D5010005 20120B05
	v_mov_b32_dpp v12, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A72A38: 7E1802FA FF016403
	v_cndmask_b32_e64 v3, -v3, v3, s4                          // 000000A72A40: D5010003 20120703
	v_add_f32_e32 v2, v2, v13                                  // 000000A72A48: 06041B02
	v_sub_nc_u32_e32 v6, v6, v7                                // 000000A72A4C: 4C0C0F06
	v_add_f32_e32 v5, v5, v11                                  // 000000A72A50: 060A1705
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A72A54: BF870214
	v_add_f32_e32 v3, v3, v12                                  // 000000A72A58: 06061903
	v_mov_b32_dpp v13, v2 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A72A5C: 7E1A02FA FF016802
	v_cndmask_b32_e64 v2, -v2, v2, s5                          // 000000A72A64: D5010002 20160502
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 000000A72A6C: BF870254
	v_mov_b32_dpp v11, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A72A70: 7E1602FA FF016805
	v_cndmask_b32_e64 v5, -v5, v5, s5                          // 000000A72A78: D5010005 20160B05
	v_add_nc_u32_e32 v8, 8, v8                                 // 000000A72A80: 4A101088
	v_mov_b32_dpp v12, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A72A84: 7E1802FA FF016803
	v_cndmask_b32_e64 v3, -v3, v3, s5                          // 000000A72A8C: D5010003 20160703
	v_dual_add_f32 v4, v4, v10 :: v_dual_add_f32 v5, v5, v11   // 000000A72A94: C9081504 04041705
	v_add_f32_e32 v2, v2, v13                                  // 000000A72A9C: 06041B02
	v_cmp_le_i32_e32 vcc_lo, s31, v8                           // 000000A72AA0: 7C86101F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A72AA4: BF870214
	v_dual_add_f32 v3, v3, v12 :: v_dual_add_nc_u32 v6, v9, v6 // 000000A72AA8: C9201903 03060D09
	v_dual_mov_b32 v11, v5 :: v_dual_mov_b32 v10, v4           // 000000A72AB0: CA100105 0B0A0104
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000A72AB8: BF870234
	v_mov_b32_e32 v13, v2                                      // 000000A72ABC: 7E1A0302
	v_cndmask_b32_e64 v5, -v5, v5, s0                          // 000000A72AC0: D5010005 20020B05
	v_cndmask_b32_e64 v4, -v4, v4, s0                          // 000000A72AC8: D5010004 20020904
	v_permlanex16_b32 v11, v11, s54, 0xfedcba98                // 000000A72AD0: D65C000B 03FC6D0B FEDCBA98
	v_mov_b32_e32 v12, v3                                      // 000000A72ADC: 7E180303
	v_cndmask_b32_e64 v2, -v2, v2, s0                          // 000000A72AE0: D5010002 20020502
	v_cndmask_b32_e64 v3, -v3, v3, s0                          // 000000A72AE8: D5010003 20020703
	v_permlanex16_b32 v10, v10, s54, 0xfedcba98                // 000000A72AF0: D65C000A 03FC6D0A FEDCBA98
	v_permlanex16_b32 v13, v13, s54, 0xfedcba98                // 000000A72AFC: D65C000D 03FC6D0D FEDCBA98
	v_add_f32_e32 v5, v5, v11                                  // 000000A72B08: 060A1705
	v_permlanex16_b32 v12, v12, s54, 0xfedcba98                // 000000A72B0C: D65C000C 03FC6D0C FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A72B18: BF870214
	v_dual_add_f32 v4, v4, v10 :: v_dual_add_nc_u32 v9, 0x800, v9// 000000A72B1C: C9201504 040812FF 00000800
	v_add_f32_e32 v7, v2, v13                                  // 000000A72B28: 060E1B02
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A72B2C: BF870214
	v_fma_mixhi_f16 v2, v5, s59, 0                             // 000000A72B30: CC220002 02007705
	v_add_f32_e32 v10, v3, v12                                 // 000000A72B38: 06141903
	s_or_b32 s34, vcc_lo, s34                                  // 000000A72B3C: 8C22226A
	v_fma_mixlo_f16 v2, v4, s59, 0                             // 000000A72B40: CC210002 02007704
	v_fma_mixhi_f16 v3, v7, s59, 0                             // 000000A72B48: CC220003 02007707
	s_delay_alu instid0(VALU_DEP_3)                            // 000000A72B50: BF870003
	v_fma_mixlo_f16 v3, v10, s59, 0                            // 000000A72B54: CC210003 0200770A
	ds_store_b64 v6, v[2:3] offset:22016                       // 000000A72B5C: D9345600 00000206
	s_and_not1_b32 exec_lo, exec_lo, s34                       // 000000A72B64: 917E227E
	s_cbranch_execz 289                                        // 000000A72B68: BFA50121 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi0EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x8f0>
	.long 0xd72d0002                                           // 000000A72B6C: D72D0002
	v_cndmask_b32_e32 v0, v8, v58, vcc_lo                      // 000000A72B70: 02007508
	s_mov_b32 s6, -1                                           // 000000A72B74: BE8600C1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A72B78: BF870091
	.long 0xd72c0003                                           // 000000A72B7C: D72C0003
	v_cndmask_b32_e32 v0, v2, v53, vcc_lo                      // 000000A72B80: 02006B02
	v_sub_nc_u32_e32 v3, v8, v3                                // 000000A72B84: 4C060708
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000A72B88: BF870121
	v_subrev_nc_u32_e32 v5, s53, v3                            // 000000A72B8C: 4E0A0635
	v_cmp_le_u32_e32 vcc_lo, s53, v3                           // 000000A72B90: 7C960635
	v_dual_cndmask_b32 v3, v3, v5 :: v_dual_add_nc_u32 v4, 1, v2// 000000A72B94: CA600B03 03040481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A72B9C: BF870111
	v_cndmask_b32_e32 v2, v2, v4, vcc_lo                       // 000000A72BA0: 02040902
	v_cmp_le_u32_e32 vcc_lo, s53, v3                           // 000000A72BA4: 7C960635
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A72BA8: BF870092
	v_add_nc_u32_e32 v4, 1, v2                                 // 000000A72BAC: 4A080481
	v_cndmask_b32_e32 v2, v2, v4, vcc_lo                       // 000000A72BB0: 02040902
	s_and_not1_b32 vcc_lo, exec_lo, s52                        // 000000A72BB4: 916A347E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A72BB8: BF870091
	v_xor_b32_e32 v11, s55, v2                                 // 000000A72BBC: 3A160437
	v_subrev_nc_u32_e32 v10, s55, v11                          // 000000A72BC0: 4E141637
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000A72BC4: BF8700A1
	v_mad_u64_u32 v[6:7], null, s57, v10, v[1:2]               // 000000A72BC8: D6FE7C06 04061439
	v_min_i32_e32 v2, s51, v10                                 // 000000A72BD0: 22041433
	v_mad_i64_i32 v[4:5], null, v2, s50, 0                     // 000000A72BD4: D6FF7C04 02006502
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A72BDC: BF870093
	v_ashrrev_i32_e32 v7, 31, v6                               // 000000A72BE0: 340E0C9F
	.long 0xd73c0002                                           // 000000A72BE4: D73C0002
	v_cndmask_b32_e32 v1, 1, v6, vcc_lo                        // 000000A72BE8: 02020C81
	s_cbranch_vccnz 212                                        // 000000A72BEC: BFA400D4 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi0EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x840>
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A72BF0: BF870093
	.long 0xd7006a06                                           // 000000A72BF4: D7006A06
	v_cndmask_b32_e32 v1, v4, v6, vcc_lo                       // 000000A72BF8: 02020D04
	v_add_co_ci_u32_e64 v7, null, v5, v7, vcc_lo               // 000000A72BFC: D5207C07 01AA0F05
	.long 0x7f3c3880                                           // 000000A72C04: 7F3C3880
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A72C08: BF870112
	.long 0xd73c0006                                           // 000000A72C0C: D73C0006
	v_cndmask_b32_e32 v1, 1, v6, vcc_lo                        // 000000A72C10: 02020C81
	.long 0x7f42399e                                           // 000000A72C14: 7F42399E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A72C18: BF870092
	.long 0xd7006a0c                                           // 000000A72C1C: D7006A0C
	v_cndmask_b32_e32 v1, s38, v6, vcc_lo                      // 000000A72C20: 02020C26
	v_add_co_ci_u32_e64 v13, null, s39, v7, vcc_lo             // 000000A72C24: D5207C0D 01AA0E27
	.long 0xd7006a06                                           // 000000A72C2C: D7006A06
	v_cndmask_b32_e32 v1, s40, v6, vcc_lo                      // 000000A72C30: 02020C28
	s_delay_alu instid0(VALU_DEP_1)                            // 000000A72C34: BF870001
	v_add_co_ci_u32_e64 v7, null, s41, v7, vcc_lo              // 000000A72C38: D5207C07 01AA0E29
	global_load_b64 v[12:13], v[12:13], off                    // 000000A72C40: DC560000 0C7C000C
	.long 0xd7006a0e                                           // 000000A72C48: D7006A0E
	v_cndmask_b32_e32 v1, s26, v2, vcc_lo                      // 000000A72C4C: 0202041A
	global_load_b64 v[6:7], v[6:7], off                        // 000000A72C50: DC560000 067C0006
	v_add_co_ci_u32_e64 v15, null, s27, v3, vcc_lo             // 000000A72C58: D5207C0F 01AA061B
	s_clause 0x1                                               // 000000A72C60: BF850001
	global_load_b32 v16, v[14:15], off                         // 000000A72C64: DC520000 107C000E
	global_load_d16_b16 v14, v[14:15], off offset:4            // 000000A72C6C: DC820004 0E7C000E
	s_waitcnt vmcnt(3)                                         // 000000A72C74: BF890FF7
	.long 0x7e1e390c                                           // 000000A72C78: 7E1E390C
	s_waitcnt vmcnt(2)                                         // 000000A72C7C: BF890BF7
	v_and_b32_e32 v40, 0xffff0000, v6                          // 000000A72C80: 36500CFF FFFF0000
	v_lshlrev_b32_e32 v6, 16, v6                               // 000000A72C88: 300C0C90
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A72C8C: BF870093
	v_lshlrev_b32_e32 v15, 16, v15                             // 000000A72C90: 301E1E90
	v_mul_f32_e32 v19, 0xbfb8aa3b, v15                         // 000000A72C94: 10261EFF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000A72C9C: BF870291
	v_exp_f32_e32 v19, v19                                     // 000000A72CA0: 7E264B13
	v_dual_add_f32 v19, 1.0, v19 :: v_dual_and_b32 v12, 0xffff0000, v12// 000000A72CA4: C92426F2 130C18FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A72CB0: BF870111
	v_mul_f32_e32 v18, 0xbfb8aa3b, v12                         // 000000A72CB4: 102418FF BFB8AA3B
	v_div_scale_f32 v23, null, v19, v19, v15                   // 000000A72CBC: D6FC7C17 043E2713
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000A72CC4: BF8701B2
	v_exp_f32_e32 v18, v18                                     // 000000A72CC8: 7E244B12
	v_lshlrev_b32_e32 v17, 16, v13                             // 000000A72CCC: 30221A90
	v_div_scale_f32 v38, s7, v15, v19, v15                     // 000000A72CD0: D6FC0726 043E270F
	v_rcp_f32_e32 v29, v23                                     // 000000A72CD8: 7E3A5517
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A72CDC: BF870196
	v_add_f32_e32 v18, 1.0, v18                                // 000000A72CE0: 062424F2
	v_mul_f32_e32 v20, 0xbfb8aa3b, v17                         // 000000A72CE4: 102822FF BFB8AA3B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A72CEC: BF870195
	v_fma_f32 v37, -v23, v29, 1.0                              // 000000A72CF0: D6130025 23CA3B17
	v_div_scale_f32 v22, null, v18, v18, v12                   // 000000A72CF8: D6FC7C16 04322512
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000A72D00: BF8701B3
	v_exp_f32_e32 v20, v20                                     // 000000A72D04: 7E284B14
	v_and_b32_e32 v13, 0xffff0000, v13                         // 000000A72D08: 361A1AFF FFFF0000
	v_div_scale_f32 v34, vcc_lo, v12, v18, v12                 // 000000A72D10: D6FC6A22 0432250C
	v_rcp_f32_e32 v27, v22                                     // 000000A72D18: 7E365516
	s_delay_alu instid0(TRANS32_DEP_2) | instid1(VALU_DEP_2)   // 000000A72D1C: BF870106
	v_dual_add_f32 v20, 1.0, v20 :: v_dual_mul_f32 v21, 0xbfb8aa3b, v13// 000000A72D20: C90628F2 14141AFF BFB8AA3B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A72D2C: BF870115
	v_fma_f32 v35, -v22, v27, 1.0                              // 000000A72D30: D6130023 23CA3716
	v_div_scale_f32 v26, null, v20, v20, v17                   // 000000A72D38: D6FC7C1A 04462914
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000A72D40: BF8701A3
	v_exp_f32_e32 v21, v21                                     // 000000A72D44: 7E2A4B15
	v_div_scale_f32 v36, s6, v17, v20, v17                     // 000000A72D48: D6FC0624 04462911
	v_fmac_f32_e32 v27, v35, v27                               // 000000A72D50: 56363723
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 000000A72D54: BF870313
	v_rcp_f32_e32 v31, v26                                     // 000000A72D58: 7E3E551A
	v_add_f32_e32 v21, 1.0, v21                                // 000000A72D5C: 062A2AF2
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A72D60: BF870115
	v_fma_f32 v39, -v26, v31, 1.0                              // 000000A72D64: D6130027 23CA3F1A
	v_div_scale_f32 v28, null, v21, v21, v13                   // 000000A72D6C: D6FC7C1C 04362B15
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000A72D74: BF8701A2
	v_fmac_f32_e32 v31, v39, v31                               // 000000A72D78: 563E3F27
	v_mul_f32_e32 v39, v34, v27                                // 000000A72D7C: 104E3722
	v_rcp_f32_e32 v32, v28                                     // 000000A72D80: 7E40551C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A72D84: BF870112
	v_mul_f32_e32 v41, v36, v31                                // 000000A72D88: 10523F24
	v_fma_f32 v42, -v22, v39, v34                              // 000000A72D8C: D613002A 248A4F16
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A72D94: BF870112
	v_fma_f32 v45, -v26, v41, v36                              // 000000A72D98: D613002D 2492531A
	v_fmac_f32_e32 v39, v42, v27                               // 000000A72DA0: 564E372A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A72DA4: BF870195
	v_fma_f32 v35, -v28, v32, 1.0                              // 000000A72DA8: D6130023 23CA411C
	v_fmac_f32_e32 v41, v45, v31                               // 000000A72DB0: 56523F2D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A72DB4: BF870193
	v_fma_f32 v22, -v22, v39, v34                              // 000000A72DB8: D6130016 248A4F16
	v_fmac_f32_e32 v32, v35, v32                               // 000000A72DC0: 56404123
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A72DC4: BF870193
	v_fma_f32 v26, -v26, v41, v36                              // 000000A72DC8: D613001A 2492531A
	v_div_fmas_f32 v22, v22, v27, v39                          // 000000A72DD0: D6370016 049E3716
	s_mov_b32 vcc_lo, s7                                       // 000000A72DD8: BEEA0007
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000A72DDC: BF870131
	v_div_fixup_f32 v12, v22, v18, v12                         // 000000A72DE0: D627000C 04322516
	v_fmac_f32_e32 v29, v37, v29                               // 000000A72DE8: 563A3B25
	v_div_scale_f32 v37, s8, v13, v21, v13                     // 000000A72DEC: D6FC0825 04362B0D
	v_dual_mul_f32 v12, v12, v40 :: v_dual_mul_f32 v35, v38, v29// 000000A72DF4: C8C6510C 0C223B26
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A72DFC: BF870112
	v_mul_f32_e32 v43, v37, v32                                // 000000A72E00: 10564125
	.long 0x7e3c398c                                           // 000000A72E04: 7E3C398C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A72E08: BF870193
	v_fma_f32 v44, -v23, v35, v38                              // 000000A72E0C: D613002C 249A4717
	v_fma_f32 v42, -v28, v43, v37                              // 000000A72E14: D613002A 2496571C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A72E1C: BF870112
	v_fmac_f32_e32 v35, v44, v29                               // 000000A72E20: 56463B2C
	v_fmac_f32_e32 v43, v42, v32                               // 000000A72E24: 5656412A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A72E28: BF870112
	v_fma_f32 v23, -v23, v35, v38                              // 000000A72E2C: D6130017 249A4717
	v_fma_f32 v22, -v28, v43, v37                              // 000000A72E34: D6130016 2496571C
	s_delay_alu instid0(VALU_DEP_2)                            // 000000A72E3C: BF870002
	v_div_fmas_f32 v23, v23, v29, v35                          // 000000A72E40: D6370017 048E3B17
	s_mov_b32 vcc_lo, s6                                       // 000000A72E48: BEEA0006
	s_mov_b32 s6, 0                                            // 000000A72E4C: BE860080
	v_div_fmas_f32 v18, v26, v31, v41                          // 000000A72E50: D6370012 04A63F1A
	s_mov_b32 vcc_lo, s8                                       // 000000A72E58: BEEA0008
	v_div_fixup_f32 v15, v23, v19, v15                         // 000000A72E5C: D627000F 043E2717
	v_lshlrev_b32_e32 v19, 16, v7                              // 000000A72E64: 30260E90
	v_and_b32_e32 v7, 0xffff0000, v7                           // 000000A72E68: 360E0EFF FFFF0000
	v_div_fixup_f32 v17, v18, v20, v17                         // 000000A72E70: D6270011 04462912
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000A72E78: BF8701A4
	v_mul_f32_e32 v6, v15, v6                                  // 000000A72E7C: 100C0D0F
	v_div_fmas_f32 v15, v22, v32, v43                          // 000000A72E80: D637000F 04AE4116
	v_mul_f32_e32 v17, v17, v19                                // 000000A72E88: 10222711
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A72E8C: BF870193
	.long 0x7e423986                                           // 000000A72E90: 7E423986
	v_div_fixup_f32 v13, v15, v21, v13                         // 000000A72E94: D627000D 04362B0F
	v_and_b32_e32 v15, 1, v30                                  // 000000A72E9C: 361E3C81
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A72EA0: BF870214
	v_bfe_u32 v18, v17, 16, 1                                  // 000000A72EA4: D6100012 02052111
	v_and_b32_e32 v19, 1, v33                                  // 000000A72EAC: 36264281
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A72EB0: BF870214
	v_mul_f32_e32 v7, v13, v7                                  // 000000A72EB4: 100E0F0D
	v_add3_u32 v12, v12, v15, 0x7fff                           // 000000A72EB8: D655000C 03FE1F0C 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A72EC4: BF870214
	v_add3_u32 v13, v17, v18, 0x7fff                           // 000000A72EC8: D655000D 03FE2511 00007FFF
	v_add3_u32 v6, v6, v19, 0x7fff                             // 000000A72ED4: D6550006 03FE2706 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A72EE0: BF870214
	v_bfe_u32 v15, v7, 16, 1                                   // 000000A72EE4: D610000F 02052107
	v_and_b32_e32 v12, 0xffff0000, v12                         // 000000A72EEC: 361818FF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A72EF4: BF870214
	v_and_b32_e32 v17, 0xffff0000, v13                         // 000000A72EF8: 36221AFF FFFF0000
	v_and_b32_e32 v6, 0xffff0000, v6                           // 000000A72F00: 360C0CFF FFFF0000
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A72F08: BF870004
	v_add3_u32 v7, v7, v15, 0x7fff                             // 000000A72F0C: D6550007 03FE1F07 00007FFF
	s_waitcnt vmcnt(1)                                         // 000000A72F18: BF8907F7
	v_fma_mix_f32 v13, v16, v12, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000A72F1C: CC20080D 8A021910
	s_waitcnt vmcnt(0)                                         // 000000A72F24: BF8903F7
	v_fma_mix_f32 v12, v14, v17, neg(0) op_sel_hi:[1,0,0]      // 000000A72F28: CC20000C 8A02230E
	v_fma_mix_f32 v15, v16, v6, neg(0) op_sel_hi:[1,0,0]       // 000000A72F30: CC20000F 8A020D10
	v_and_b32_e32 v14, 0xffff0000, v7                          // 000000A72F38: 361C0EFF FFFF0000
	s_and_not1_b32 vcc_lo, exec_lo, s6                         // 000000A72F40: 916A067E
	s_cbranch_vccnz 65125                                      // 000000A72F44: BFA4FE65 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi0EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x1dc>
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A72F48: BF870093
	.long 0xd73c0004                                           // 000000A72F4C: D73C0004
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 000000A72F50: 02020881
	.long 0xd7006a04                                           // 000000A72F54: D7006A04
	v_cndmask_b32_e32 v1, s38, v4, vcc_lo                      // 000000A72F58: 02020826
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A72F5C: BF870111
	v_add_co_ci_u32_e64 v5, null, s39, v5, vcc_lo              // 000000A72F60: D5207C05 01AA0A27
	.long 0xd7006a04                                           // 000000A72F68: D7006A04
	v_cndmask_b32_e32 v1, v4, v2, vcc_lo                       // 000000A72F6C: 02020504
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000A72F70: BF8700A1
	v_add_co_ci_u32_e64 v5, null, v5, v3, vcc_lo               // 000000A72F74: D5207C05 01AA0705
	.long 0xd7006a06                                           // 000000A72F7C: D7006A06
	v_cndmask_b32_e32 v1, s26, v2, vcc_lo                      // 000000A72F80: 0202041A
	v_add_co_ci_u32_e64 v7, null, s27, v3, vcc_lo              // 000000A72F84: D5207C07 01AA061B
	global_load_b64 v[4:5], v[4:5], off                        // 000000A72F8C: DC560000 047C0004
	s_clause 0x1                                               // 000000A72F94: BF850001
	global_load_b32 v14, v[6:7], off                           // 000000A72F98: DC520000 0E7C0006
	global_load_d16_b16 v6, v[6:7], off offset:4               // 000000A72FA0: DC820004 067C0006
	s_waitcnt vmcnt(2)                                         // 000000A72FA8: BF890BF7
	.long 0x7e0e3904                                           // 000000A72FAC: 7E0E3904
	v_and_b32_e32 v4, 0xffff0000, v4                           // 000000A72FB0: 360808FF FFFF0000
	v_lshlrev_b32_e32 v12, 16, v5                              // 000000A72FB8: 30180A90
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000A72FBC: BF8701A3
	v_lshlrev_b32_e32 v7, 16, v7                               // 000000A72FC0: 300E0E90
	s_waitcnt vmcnt(1)                                         // 000000A72FC4: BF8907F7
	v_fma_mix_f32 v13, v14, v4, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000A72FC8: CC20080D 8A02090E
	s_waitcnt vmcnt(0)                                         // 000000A72FD0: BF8903F7
	v_fma_mix_f32 v12, v6, v12, neg(0) op_sel_hi:[1,0,0]       // 000000A72FD4: CC20000C 8A021906
	v_fma_mix_f32 v15, v14, v7, neg(0) op_sel_hi:[1,0,0]       // 000000A72FDC: CC20000F 8A020F0E
	v_and_b32_e32 v14, 0xffff0000, v5                          // 000000A72FE4: 361C0AFF FFFF0000
	s_branch 65083                                             // 000000A72FEC: BFA0FE3B <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi0EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x1dc>
	s_or_b32 exec_lo, exec_lo, s33                             // 000000A72FF0: 8C7E217E
	s_bfe_i32 s34, s35, 0x1001c                                // 000000A72FF4: 93A2FF23 0001001C
	s_lshr_b32 s3, s11, 28                                     // 000000A72FFC: 85039C0B
	s_lshr_b64 s[0:1], s[34:35], 29                            // 000000A73000: 85809D22
	s_add_i32 s3, s50, s3                                      // 000000A73004: 81030332
	s_add_i32 s0, s0, 7                                        // 000000A73008: 81008700
	s_lshl_b32 s1, s35, 3                                      // 000000A7300C: 84018323
	s_ashr_i32 s0, s0, 3                                       // 000000A73010: 86008300
	s_lshl_b32 s4, s29, 3                                      // 000000A73014: 8404831D
	.long 0xd72c0001                                           // 000000A73018: D72C0001
	v_cndmask_b32_e32 v1, s0, v24, vcc_lo                      // 000000A7301C: 02023000
	v_lshlrev_b32_e32 v19, 2, v25                              // 000000A73020: 30263282
	s_waitcnt lgkmcnt(0)                                       // 000000A73024: BF89FC07
	s_barrier                                                  // 000000A73028: BFBD0000
	buffer_gl0_inv                                             // 000000A7302C: E0AC0000 00000000
	v_add_nc_u32_e32 v2, s0, v1                                // 000000A73034: 4A040200
	s_ashr_i32 s0, s3, 4                                       // 000000A73038: 86008403
	s_ashr_i32 s3, s4, 31                                      // 000000A7303C: 86039F04
	s_mul_hi_i32 s5, s10, s0                                   // 000000A73040: 9705000A
	s_mul_i32 s0, s10, s0                                      // 000000A73044: 9600000A
	v_min_i32_e32 v21, s1, v2                                  // 000000A73048: 222A0401
	s_add_u32 s0, s0, s4                                       // 000000A7304C: 80000400
	s_addc_u32 s1, s5, s3                                      // 000000A73050: 82010305
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A73054: BF870099
	s_lshl_b64 s[4:5], s[0:1], 10                              // 000000A73058: 84848A00
	v_cmp_lt_i32_e32 vcc_lo, v1, v21                           // 000000A7305C: 7C822B01
	s_add_u32 s1, s24, s4                                      // 000000A73060: 80010418
	s_addc_u32 s3, s25, s5                                     // 000000A73064: 82030519
	s_and_saveexec_b32 s4, vcc_lo                              // 000000A73068: BE84206A
	s_cbranch_execz 93                                         // 000000A7306C: BFA5005D <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi0EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0xae4>
	.long 0xd7010002                                           // 000000A73070: D7010002
	v_cndmask_b32_e32 v0, v25, v129, vcc_lo                    // 000000A73074: 02010319
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000A73078: BF870121
	v_cndmask_b32_e64 v3, v2, 31, s0                           // 000000A7307C: D5010003 00013F02
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000A73084: 3404029F
	.long 0xd44c0000                                           // 000000A73088: D44C0000
	v_cndmask_b32_e32 v1, 31, v3, vcc_lo                       // 000000A7308C: 0202069F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A73090: BF870091
	v_cndmask_b32_e64 v5, 0xe1, 1, s0                          // 000000A73094: D5010005 000102FF 000000E1
	v_dual_mov_b32 v4, 0 :: v_dual_add_nc_u32 v7, v5, v3       // 000000A730A0: CA200080 04060705
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A730A8: BF870114
	.long 0xd73c0005                                           // 000000A730AC: D73C0005
	v_cndmask_b32_e32 v1, 10, v1, vcc_lo                       // 000000A730B0: 0202028A
	.long 0xd73c0002                                           // 000000A730B4: D73C0002
	v_cndmask_b32_e32 v1, 2, v3, vcc_lo                        // 000000A730B8: 02020682
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000A730BC: BF870223
	v_lshlrev_b32_e32 v4, 24, v7                               // 000000A730C0: 30080E98
	v_bfe_i32 v7, v7, 7, 1                                     // 000000A730C4: D6110007 02050F07
	.long 0xd7000008                                           // 000000A730CC: D7000008
	v_cndmask_b32_e32 v1, s1, v5, vcc_lo                       // 000000A730D0: 02020A01
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A730D4: BF870211
	v_add_co_ci_u32_e64 v9, null, s3, v6, s0                   // 000000A730D8: D5207C09 00020C03
	v_ashrrev_i32_e32 v6, 22, v4                               // 000000A730E0: 340C0896
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A730E4: BF870093
	.long 0xd7000004                                           // 000000A730E8: D7000004
	v_cndmask_b32_e32 v1, v8, v2, vcc_lo                       // 000000A730EC: 02020508
	v_add_co_ci_u32_e64 v5, null, v9, v3, s0                   // 000000A730F0: D5207C05 00020709
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A730F8: BF870093
	.long 0xd7000006                                           // 000000A730FC: D7000006
	v_cndmask_b32_e32 v1, v8, v6, vcc_lo                       // 000000A73100: 02020D08
	v_add_co_ci_u32_e64 v7, null, v9, v7, s0                   // 000000A73104: D5207C07 00020F09
	.long 0xd7000008                                           // 000000A7310C: D7000008
	v_cndmask_b32_e32 v1, v8, v19, vcc_lo                      // 000000A73110: 02022708
	s_delay_alu instid0(VALU_DEP_1)                            // 000000A73114: BF870001
	v_add_co_ci_u32_e64 v9, null, 0, v9, s0                    // 000000A73118: D5207C09 00021280
	s_clause 0x17                                              // 000000A73120: BF850017
	global_load_b32 v2, v[4:5], off                            // 000000A73124: DC520000 027C0004
	global_load_b32 v92, v[4:5], off offset:128                // 000000A7312C: DC520080 5C7C0004
	global_load_b32 v89, v[4:5], off offset:256                // 000000A73134: DC520100 597C0004
	global_load_b32 v86, v[4:5], off offset:384                // 000000A7313C: DC520180 567C0004
	global_load_b32 v83, v[4:5], off offset:512                // 000000A73144: DC520200 537C0004
	global_load_b32 v80, v[4:5], off offset:640                // 000000A7314C: DC520280 507C0004
	global_load_b32 v77, v[4:5], off offset:768                // 000000A73154: DC520300 4D7C0004
	global_load_b32 v59, v[4:5], off offset:896                // 000000A7315C: DC520380 3B7C0004
	global_load_b32 v4, v[6:7], off                            // 000000A73164: DC520000 047C0006
	global_load_b32 v93, v[6:7], off offset:128                // 000000A7316C: DC520080 5D7C0006
	global_load_b32 v90, v[6:7], off offset:256                // 000000A73174: DC520100 5A7C0006
	global_load_b32 v87, v[6:7], off offset:384                // 000000A7317C: DC520180 577C0006
	global_load_b32 v84, v[6:7], off offset:512                // 000000A73184: DC520200 547C0006
	global_load_b32 v81, v[6:7], off offset:640                // 000000A7318C: DC520280 517C0006
	global_load_b32 v78, v[6:7], off offset:768                // 000000A73194: DC520300 4E7C0006
	global_load_b32 v60, v[6:7], off offset:896                // 000000A7319C: DC520380 3C7C0006
	global_load_b32 v3, v[8:9], off                            // 000000A731A4: DC520000 037C0008
	global_load_b32 v91, v[8:9], off offset:128                // 000000A731AC: DC520080 5B7C0008
	global_load_b32 v88, v[8:9], off offset:256                // 000000A731B4: DC520100 587C0008
	global_load_b32 v85, v[8:9], off offset:384                // 000000A731BC: DC520180 557C0008
	global_load_b32 v82, v[8:9], off offset:512                // 000000A731C4: DC520200 527C0008
	global_load_b32 v79, v[8:9], off offset:640                // 000000A731CC: DC520280 4F7C0008
	global_load_b32 v76, v[8:9], off offset:768                // 000000A731D4: DC520300 4C7C0008
	global_load_b32 v58, v[8:9], off offset:896                // 000000A731DC: DC520380 3A7C0008
	s_or_b32 exec_lo, exec_lo, s4                              // 000000A731E4: 8C7E047E
	v_dual_mov_b32 v20, 0 :: v_dual_mov_b32 v23, 0             // 000000A731E8: CA100080 14160080
	v_dual_mov_b32 v22, 0 :: v_dual_mov_b32 v29, 0             // 000000A731F0: CA100080 161C0080
	v_dual_mov_b32 v26, 0 :: v_dual_mov_b32 v31, 0             // 000000A731F8: CA100080 1A1E0080
	v_dual_mov_b32 v28, 0 :: v_dual_mov_b32 v33, 0             // 000000A73200: CA100080 1C200080
	v_dual_mov_b32 v30, 0 :: v_dual_mov_b32 v35, 0             // 000000A73208: CA100080 1E220080
	v_dual_mov_b32 v32, 0 :: v_dual_mov_b32 v37, 0             // 000000A73210: CA100080 20240080
	v_dual_mov_b32 v34, 0 :: v_dual_mov_b32 v39, 0             // 000000A73218: CA100080 22260080
	v_dual_mov_b32 v36, 0 :: v_dual_mov_b32 v41, 0             // 000000A73220: CA100080 24280080
	v_dual_mov_b32 v38, 0 :: v_dual_mov_b32 v45, 0             // 000000A73228: CA100080 262C0080
	v_dual_mov_b32 v40, 0 :: v_dual_mov_b32 v27, 0             // 000000A73230: CA100080 281A0080
	v_dual_mov_b32 v42, 0 :: v_dual_mov_b32 v51, 0             // 000000A73238: CA100080 2A320080
	v_dual_mov_b32 v44, 0 :: v_dual_mov_b32 v53, 0             // 000000A73240: CA100080 2C340080
	v_dual_mov_b32 v46, 0 :: v_dual_mov_b32 v47, 0             // 000000A73248: CA100080 2E2E0080
	v_dual_mov_b32 v48, 0 :: v_dual_mov_b32 v49, 0             // 000000A73250: CA100080 30300080
	v_dual_mov_b32 v50, 0 :: v_dual_mov_b32 v43, 0             // 000000A73258: CA100080 322A0080
	v_mov_b32_e32 v52, 0                                       // 000000A73260: 7E680280
	v_mov_b32_e32 v54, 0                                       // 000000A73264: 7E6C0280
	s_ashr_i32 s11, s10, 31                                    // 000000A73268: 860B9F0A
	s_and_saveexec_b32 s0, vcc_lo                              // 000000A7326C: BE80206A
	s_cbranch_execz 1077                                       // 000000A73270: BFA50435 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi0EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x1c48>
	v_dual_mov_b32 v20, 0 :: v_dual_add_nc_u32 v5, -1, v0      // 000000A73274: CA200080 140400C1
	v_mov_b32_e32 v22, 0                                       // 000000A7327C: 7E2C0280
	v_and_or_b32 v55, v0, 16, 0x5600                           // 000000A73280: D6570037 03FD2100 00005600
	v_dual_mov_b32 v23, 0 :: v_dual_lshlrev_b32 v56, 2, v25    // 000000A7328C: CA220080 17383282
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000A73294: BF8701B4
	v_dual_mov_b32 v26, 0 :: v_dual_and_b32 v5, 31, v5         // 000000A73298: CA240080 1A040A9F
	v_dual_mov_b32 v29, 0 :: v_dual_mov_b32 v28, 0             // 000000A732A0: CA100080 1D1C0080
	v_dual_mov_b32 v30, 0 :: v_dual_mov_b32 v31, 0             // 000000A732A8: CA100080 1E1E0080
	v_dual_mov_b32 v32, 0 :: v_dual_lshlrev_b32 v57, 2, v5     // 000000A732B0: CA220080 20380A82
	v_dual_mov_b32 v33, 0 :: v_dual_mov_b32 v34, 0             // 000000A732B8: CA100080 21220080
	v_dual_mov_b32 v35, 0 :: v_dual_mov_b32 v36, 0             // 000000A732C0: CA100080 23240080
	v_dual_mov_b32 v37, 0 :: v_dual_mov_b32 v38, 0             // 000000A732C8: CA100080 25260080
	v_dual_mov_b32 v39, 0 :: v_dual_mov_b32 v40, 0             // 000000A732D0: CA100080 27280080
	v_dual_mov_b32 v41, 0 :: v_dual_mov_b32 v42, 0             // 000000A732D8: CA100080 292A0080
	v_dual_mov_b32 v45, 0 :: v_dual_mov_b32 v44, 0             // 000000A732E0: CA100080 2D2C0080
	v_dual_mov_b32 v27, 0 :: v_dual_mov_b32 v46, 0             // 000000A732E8: CA100080 1B2E0080
	v_dual_mov_b32 v51, 0 :: v_dual_mov_b32 v48, 0             // 000000A732F0: CA100080 33300080
	v_dual_mov_b32 v53, 0 :: v_dual_mov_b32 v50, 0             // 000000A732F8: CA100080 35320080
	v_mov_b32_e32 v47, 0                                       // 000000A73300: 7E5E0280
	v_dual_mov_b32 v49, 0 :: v_dual_mov_b32 v52, 0             // 000000A73304: CA100080 31340080
	v_dual_mov_b32 v43, 0 :: v_dual_mov_b32 v54, 0             // 000000A7330C: CA100080 2B360080
	s_mov_b32 s4, 0                                            // 000000A73314: BE840080
	s_movk_i32 s5, 0x1eee                                      // 000000A73318: B0051EEE
	s_branch 975                                               // 000000A7331C: BFA003CF <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi0EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x1b5c>
	s_or_b32 exec_lo, exec_lo, s6                              // 000000A73320: 8C7E067E
	s_waitcnt vmcnt(15)                                        // 000000A73324: BF893FF7
	v_alignbit_b32 v2, v2, v4, 16                              // 000000A73328: D6160002 02420902
	v_lshl_add_u32 v13, v1, 5, v55                             // 000000A73330: D646000D 04DD0B01
	s_waitcnt vmcnt(7)                                         // 000000A73338: BF891FF7
	v_bfe_u32 v14, v3, 12, 16                                  // 000000A7333C: D610000E 02411903
	v_bfe_u32 v15, v3, 8, 16                                   // 000000A73344: D610000F 02411103
	v_bfe_u32 v16, v3, 4, 16                                   // 000000A7334C: D6100010 02410903
	v_bfe_u32 v1, v2, 12, 16                                   // 000000A73354: D6100001 02411902
	v_bfe_u32 v5, v2, 8, 16                                    // 000000A7335C: D6100005 02411102
	.long 0xd72c000e                                           // 000000A73364: D72C000E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v14, vcc_lo              // 000000A73368: 02021CFF 83DCD12D
	.long 0xd72c000f                                           // 000000A73370: D72C000F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v15, vcc_lo              // 000000A73374: 02021EFF 83DCD12D
	v_alignbit_b32 v92, v92, v93, 16                           // 000000A7337C: D616005C 0242BB5C
	.long 0xd72c005f                                           // 000000A73384: D72C005F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v1, vcc_lo               // 000000A73388: 020202FF 83DCD12D
	.long 0xd72c0061                                           // 000000A73390: D72C0061
	v_cndmask_b32_e32 v1, 0x83dcd12d, v5, vcc_lo               // 000000A73394: 02020AFF 83DCD12D
	s_waitcnt vmcnt(6)                                         // 000000A7339C: BF891BF7
	v_bfe_u32 v100, v91, 4, 16                                 // 000000A733A0: D6100064 0241095B
	v_alignbit_b32 v89, v89, v90, 16                           // 000000A733A8: D6160059 0242B559
	v_bfe_u32 v93, v92, 12, 16                                 // 000000A733B0: D610005D 0241195C
	v_sad_u8 v14, v14, 0, 0x6400                               // 000000A733B8: D622000E 03FD010E 00006400
	v_sad_u8 v99, v15, 0, 0x6400                               // 000000A733C4: D6220063 03FD010F 00006400
	v_alignbit_b32 v86, v86, v87, 16                           // 000000A733D0: D6160056 0242AF56
	v_sad_u8 v95, v95, 0, 0x6400                               // 000000A733D8: D622005F 03FD015F 00006400
	v_sad_u8 v97, v97, 0, 0x6400                               // 000000A733E4: D6220061 03FD0161 00006400
	.long 0xd72c005d                                           // 000000A733F0: D72C005D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v93, vcc_lo              // 000000A733F4: 0202BAFF 83DCD12D
	v_bfe_u32 v90, v89, 12, 16                                 // 000000A733FC: D610005A 02411959
	v_bfe_u32 v87, v86, 12, 16                                 // 000000A73404: D6100057 02411956
	v_and_b32_e32 v95, 0xffff, v95                             // 000000A7340C: 36BEBEFF 0000FFFF
	v_alignbit_b32 v83, v83, v84, 16                           // 000000A73414: D6160053 0242A953
	v_alignbit_b32 v80, v80, v81, 16                           // 000000A7341C: D6160050 0242A350
	.long 0xd72c005a                                           // 000000A73424: D72C005A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v90, vcc_lo              // 000000A73428: 0202B4FF 83DCD12D
	.long 0xd72c0057                                           // 000000A73430: D72C0057
	v_cndmask_b32_e32 v1, 0x83dcd12d, v87, vcc_lo              // 000000A73434: 0202AEFF 83DCD12D
	v_lshl_or_b32 v95, v97, 16, v95                            // 000000A7343C: D656005F 057D2161
	.long 0xd72c0061                                           // 000000A73444: D72C0061
	v_cndmask_b32_e32 v1, 0x83dcd12d, v16, vcc_lo              // 000000A73448: 020220FF 83DCD12D
	v_sad_u8 v93, v93, 0, 0x6400                               // 000000A73450: D622005D 03FD015D 00006400
	v_bfe_u32 v84, v83, 12, 16                                 // 000000A7345C: D6100054 02411953
	v_bfe_u32 v81, v80, 12, 16                                 // 000000A73464: D6100051 02411950
	v_pk_fma_f16 v95, v95, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A7346C: CC0E005F 0BFC0B5F 0000C931
	v_and_b32_e32 v4, 0xffff, v2                               // 000000A73478: 360804FF 0000FFFF
	v_bfe_u32 v2, v2, 4, 16                                    // 000000A73480: D6100002 02410902
	v_sad_u8 v90, v90, 0, 0x6400                               // 000000A73488: D622005A 03FD015A 00006400
	v_sad_u8 v97, v97, 0, 0x6400                               // 000000A73494: D6220061 03FD0161 00006400
	v_sad_u8 v87, v87, 0, 0x6400                               // 000000A734A0: D6220057 03FD0157 00006400
	.long 0xd72c0060                                           // 000000A734AC: D72C0060
	v_cndmask_b32_e32 v1, 0x83dcd12d, v4, vcc_lo               // 000000A734B0: 020208FF 83DCD12D
	.long 0xd72c0062                                           // 000000A734B8: D72C0062
	v_cndmask_b32_e32 v1, 0x83dcd12d, v2, vcc_lo               // 000000A734BC: 020204FF 83DCD12D
	.long 0xd72c0054                                           // 000000A734C4: D72C0054
	v_cndmask_b32_e32 v1, 0x83dcd12d, v84, vcc_lo              // 000000A734C8: 0202A8FF 83DCD12D
	.long 0xd72c0051                                           // 000000A734D0: D72C0051
	v_cndmask_b32_e32 v1, 0x83dcd12d, v81, vcc_lo              // 000000A734D4: 0202A2FF 83DCD12D
	v_alignbit_b32 v77, v77, v78, 16                           // 000000A734DC: D616004D 02429D4D
	v_alignbit_b32 v59, v59, v60, 16                           // 000000A734E4: D616003B 0242793B
	v_cmp_eq_u32_e32 vcc_lo, v17, v21                          // 000000A734EC: 7C942B11
	v_and_b32_e32 v93, 0xffff, v93                             // 000000A734F0: 36BABAFF 0000FFFF
	v_sad_u8 v96, v96, 0, 0x6400                               // 000000A734F8: D6220060 03FD0160 00006400
	v_sad_u8 v98, v98, 0, 0x6400                               // 000000A73504: D6220062 03FD0162 00006400
	v_sad_u8 v84, v84, 0, 0x6400                               // 000000A73510: D6220054 03FD0154 00006400
	v_sad_u8 v81, v81, 0, 0x6400                               // 000000A7351C: D6220051 03FD0151 00006400
	v_bfe_u32 v78, v77, 12, 16                                 // 000000A73528: D610004E 0241194D
	v_lshlrev_b32_e32 v96, 16, v96                             // 000000A73530: 30C0C090
	v_bfe_u32 v60, v59, 12, 16                                 // 000000A73534: D610003C 0241193B
	s_or_b32 s4, vcc_lo, s4                                    // 000000A7353C: 8C04046A
	v_and_b32_e32 v90, 0xffff, v90                             // 000000A73540: 36B4B4FF 0000FFFF
	.long 0xd72c004e                                           // 000000A73548: D72C004E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 000000A7354C: 02029CFF 83DCD12D
	v_and_or_b32 v96, 0xffff, v98, v96                         // 000000A73554: D6570060 0582C4FF 0000FFFF
	.long 0xd72c003c                                           // 000000A73560: D72C003C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v60, vcc_lo              // 000000A73564: 020278FF 83DCD12D
	v_and_b32_e32 v84, 0xffff, v84                             // 000000A7356C: 36A8A8FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3)                            // 000000A73574: BF870003
	v_pk_fma_f16 v96, v96, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A73578: CC0E0060 0BFC0B60 0000C931
	v_and_b32_e32 v94, 0xffff, v3                              // 000000A73584: 36BC06FF 0000FFFF
	ds_load_b128 v[1:4], v13                                   // 000000A7358C: DBFC0000 0100000D
	ds_load_b128 v[5:8], v13 offset:5120                       // 000000A73594: DBFC1400 0500000D
	ds_load_b128 v[9:12], v13 offset:10240                     // 000000A7359C: DBFC2800 0900000D
	v_sad_u8 v78, v78, 0, 0x6400                               // 000000A735A4: D622004E 03FD014E 00006400
	v_sad_u8 v60, v60, 0, 0x6400                               // 000000A735B0: D622003C 03FD013C 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000A735BC: BF8700D2
	v_and_b32_e32 v78, 0xffff, v78                             // 000000A735C0: 369C9CFF 0000FFFF
	s_waitcnt lgkmcnt(2)                                       // 000000A735C8: BF89FC27
	v_dot2acc_f32_f16 v54, v95, v1                             // 000000A735CC: 046C035F
	s_waitcnt lgkmcnt(0)                                       // 000000A735D0: BF89FC07
	v_dot2acc_f32_f16 v43, v95, v9                             // 000000A735D4: 0456135F
	v_dot2acc_f32_f16 v43, v96, v10                            // 000000A735D8: 04561560
	.long 0xd72c005e                                           // 000000A735DC: D72C005E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v94, vcc_lo              // 000000A735E0: 0202BCFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A735E8: BF870091
	v_sad_u8 v94, v94, 0, 0x6400                               // 000000A735EC: D622005E 03FD015E 00006400
	v_lshlrev_b32_e32 v94, 16, v94                             // 000000A735F8: 30BCBC90
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000A735FC: BF870121
	v_and_or_b32 v94, 0xffff, v97, v94                         // 000000A73600: D657005E 057AC2FF 0000FFFF
	v_dual_dot2acc_f32_f16 v54, v96, v2 :: v_dual_and_b32 v97, 0xffff, v92// 000000A7360C: CB240560 3660B8FF 0000FFFF
	v_pk_fma_f16 v94, v94, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A73618: CC0E005E 0BFC0B5E 0000C931
	v_and_b32_e32 v98, 0xffff, v14                             // 000000A73624: 36C41CFF 0000FFFF
	ds_load_b128 v[13:16], v13 offset:15360                    // 000000A7362C: DBFC3C00 0D00000D
	.long 0xd72c0061                                           // 000000A73634: D72C0061
	v_cndmask_b32_e32 v1, 0x83dcd12d, v97, vcc_lo              // 000000A73638: 0202C2FF 83DCD12D
	v_lshl_or_b32 v98, v99, 16, v98                            // 000000A73640: D6560062 05892163
	v_bfe_u32 v99, v91, 8, 16                                  // 000000A73648: D6100063 0241115B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A73650: BF870212
	v_pk_fma_f16 v98, v98, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A73654: CC0E0062 0BFC0B62 0000C931
	v_sad_u8 v97, v97, 0, 0x6400                               // 000000A73660: D6220061 03FD0161 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A7366C: BF870113
	.long 0xd72c0063                                           // 000000A73670: D72C0063
	v_cndmask_b32_e32 v1, 0x83dcd12d, v99, vcc_lo              // 000000A73674: 0202C6FF 83DCD12D
	v_dual_dot2acc_f32_f16 v54, v98, v3 :: v_dual_lshlrev_b32 v97, 16, v97// 000000A7367C: CB220762 3660C290
	v_dot2acc_f32_f16 v43, v98, v11                            // 000000A73684: 04561762
	s_waitcnt lgkmcnt(0)                                       // 000000A73688: BF89FC07
	v_dot2acc_f32_f16 v49, v95, v13                            // 000000A7368C: 04621B5F
	v_dot2acc_f32_f16 v52, v95, v5                             // 000000A73690: 04680B5F
	v_bfe_u32 v95, v92, 8, 16                                  // 000000A73694: D610005F 0241115C
	v_bfe_u32 v92, v92, 4, 16                                  // 000000A7369C: D610005C 0241095C
	v_dot2acc_f32_f16 v43, v94, v12                            // 000000A736A4: 0456195E
	v_dot2acc_f32_f16 v49, v96, v14                            // 000000A736A8: 04621D60
	v_dot2acc_f32_f16 v52, v96, v6                             // 000000A736AC: 04680D60
	.long 0xd72c005f                                           // 000000A736B0: D72C005F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v95, vcc_lo              // 000000A736B4: 0202BEFF 83DCD12D
	v_bfe_u32 v96, v91, 12, 16                                 // 000000A736BC: D6100060 0241195B
	.long 0xd72c005c                                           // 000000A736C4: D72C005C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v92, vcc_lo              // 000000A736C8: 0202B8FF 83DCD12D
	v_and_b32_e32 v91, 0xffff, v91                             // 000000A736D0: 36B6B6FF 0000FFFF
	v_dot2acc_f32_f16 v52, v98, v7                             // 000000A736D8: 04680F62
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000A736DC: BF870224
	.long 0xd72c0060                                           // 000000A736E0: D72C0060
	v_cndmask_b32_e32 v1, 0x83dcd12d, v96, vcc_lo              // 000000A736E4: 0202C0FF 83DCD12D
	v_sad_u8 v95, v95, 0, 0x6400                               // 000000A736EC: D622005F 03FD015F 00006400
	.long 0xd72c005b                                           // 000000A736F8: D72C005B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v91, vcc_lo              // 000000A736FC: 0202B6FF 83DCD12D
	v_sad_u8 v92, v92, 0, 0x6400                               // 000000A73704: D622005C 03FD015C 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000A73710: BF8701A3
	v_lshl_or_b32 v93, v95, 16, v93                            // 000000A73714: D656005D 0575215F
	v_sad_u8 v96, v96, 0, 0x6400                               // 000000A7371C: D6220060 03FD0160 00006400
	v_and_or_b32 v92, 0xffff, v92, v97                         // 000000A73728: D657005C 0586B8FF 0000FFFF
	v_sad_u8 v91, v91, 0, 0x6400                               // 000000A73734: D622005B 03FD015B 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000A73740: BF870224
	v_pk_fma_f16 v93, v93, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A73744: CC0E005D 0BFC0B5D 0000C931
	v_dot2acc_f32_f16 v49, v98, v15                            // 000000A73750: 04621F62
	v_pk_fma_f16 v92, v92, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A73754: CC0E005C 0BFC0B5C 0000C931
	v_dot2acc_f32_f16 v52, v94, v8                             // 000000A73760: 0468115E
	.long 0xd72c0062                                           // 000000A73764: D72C0062
	v_cndmask_b32_e32 v1, 0x83dcd12d, v100, vcc_lo             // 000000A73768: 0202C8FF 83DCD12D
	v_dual_dot2acc_f32_f16 v50, v93, v13 :: v_dual_and_b32 v95, 0xffff, v96// 000000A73770: CB241B5D 325EC0FF 0000FFFF
	v_sad_u8 v96, v99, 0, 0x6400                               // 000000A7377C: D6220060 03FD0163 00006400
	v_dual_dot2acc_f32_f16 v47, v93, v1 :: v_dual_dot2acc_f32_f16 v54, v94, v4// 000000A73788: CB18035D 2F36095E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A73790: BF870193
	v_dual_dot2acc_f32_f16 v50, v92, v14 :: v_dual_lshlrev_b32 v91, 16, v91// 000000A73794: CB221D5C 325AB690
	v_lshl_or_b32 v95, v96, 16, v95                            // 000000A7379C: D656005F 057D2160
	v_dot2acc_f32_f16 v53, v93, v5                             // 000000A737A4: 046A0B5D
	v_dot2acc_f32_f16 v51, v93, v9                             // 000000A737A8: 0466135D
	v_dot2acc_f32_f16 v47, v92, v2                             // 000000A737AC: 045E055C
	v_bfe_u32 v93, v89, 8, 16                                  // 000000A737B0: D610005D 02411159
	v_pk_fma_f16 v95, v95, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A737B8: CC0E005F 0BFC0B5F 0000C931
	v_dual_dot2acc_f32_f16 v49, v94, v16 :: v_dual_and_b32 v94, 0xffff, v89// 000000A737C4: CB24215E 315EB2FF 0000FFFF
	v_sad_u8 v97, v98, 0, 0x6400                               // 000000A737D0: D6220061 03FD0162 00006400
	v_bfe_u32 v89, v89, 4, 16                                  // 000000A737DC: D6100059 02410959
	s_waitcnt vmcnt(5)                                         // 000000A737E4: BF8917F7
	v_bfe_u32 v96, v88, 12, 16                                 // 000000A737E8: D6100060 02411958
	.long 0xd72c005d                                           // 000000A737F0: D72C005D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v93, vcc_lo              // 000000A737F4: 0202BAFF 83DCD12D
	.long 0xd72c005e                                           // 000000A737FC: D72C005E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v94, vcc_lo              // 000000A73800: 0202BCFF 83DCD12D
	v_and_or_b32 v91, 0xffff, v97, v91                         // 000000A73808: D657005B 056EC2FF 0000FFFF
	v_bfe_u32 v97, v88, 8, 16                                  // 000000A73814: D6100061 02411158
	.long 0xd72c0060                                           // 000000A7381C: D72C0060
	v_cndmask_b32_e32 v1, 0x83dcd12d, v96, vcc_lo              // 000000A73820: 0202C0FF 83DCD12D
	v_bfe_u32 v98, v88, 4, 16                                  // 000000A73828: D6100062 02410958
	v_and_b32_e32 v88, 0xffff, v88                             // 000000A73830: 36B0B0FF 0000FFFF
	.long 0xd72c0059                                           // 000000A73838: D72C0059
	v_cndmask_b32_e32 v1, 0x83dcd12d, v89, vcc_lo              // 000000A7383C: 0202B2FF 83DCD12D
	v_sad_u8 v93, v93, 0, 0x6400                               // 000000A73844: D622005D 03FD015D 00006400
	v_sad_u8 v94, v94, 0, 0x6400                               // 000000A73850: D622005E 03FD015E 00006400
	.long 0xd72c0061                                           // 000000A7385C: D72C0061
	v_cndmask_b32_e32 v1, 0x83dcd12d, v97, vcc_lo              // 000000A73860: 0202C2FF 83DCD12D
	.long 0xd72c0058                                           // 000000A73868: D72C0058
	v_cndmask_b32_e32 v1, 0x83dcd12d, v88, vcc_lo              // 000000A7386C: 0202B0FF 83DCD12D
	v_pk_fma_f16 v91, v91, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A73874: CC0E005B 0BFC0B5B 0000C931
	v_sad_u8 v96, v96, 0, 0x6400                               // 000000A73880: D6220060 03FD0160 00006400
	v_lshl_or_b32 v90, v93, 16, v90                            // 000000A7388C: D656005A 0569215D
	v_sad_u8 v89, v89, 0, 0x6400                               // 000000A73894: D6220059 03FD0159 00006400
	v_dual_dot2acc_f32_f16 v50, v95, v15 :: v_dual_lshlrev_b32 v93, 16, v94// 000000A738A0: CB221F5F 325CBC90
	.long 0xd72c005e                                           // 000000A738A8: D72C005E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v98, vcc_lo              // 000000A738AC: 0202C4FF 83DCD12D
	v_dual_dot2acc_f32_f16 v53, v92, v6 :: v_dual_and_b32 v96, 0xffff, v96// 000000A738B4: CB240D5C 3560C0FF 0000FFFF
	v_sad_u8 v97, v97, 0, 0x6400                               // 000000A738C0: D6220061 03FD0161 00006400
	v_sad_u8 v88, v88, 0, 0x6400                               // 000000A738CC: D6220058 03FD0158 00006400
	v_pk_fma_f16 v90, v90, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A738D8: CC0E005A 0BFC0B5A 0000C931
	v_dot2acc_f32_f16 v50, v91, v16                            // 000000A738E4: 0464215B
	v_and_or_b32 v89, 0xffff, v89, v93                         // 000000A738E8: D6570059 0576B2FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A738F4: BF870214
	v_dual_dot2acc_f32_f16 v51, v92, v10 :: v_dual_lshlrev_b32 v88, 16, v88// 000000A738F8: CB22155C 3358B090
	v_dual_dot2acc_f32_f16 v47, v95, v3 :: v_dual_dot2acc_f32_f16 v48, v90, v5// 000000A73900: CB18075F 2F300B5A
	v_lshl_or_b32 v92, v97, 16, v96                            // 000000A73908: D656005C 05812161
	v_sad_u8 v93, v94, 0, 0x6400                               // 000000A73910: D622005D 03FD015E 00006400
	v_pk_fma_f16 v89, v89, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A7391C: CC0E0059 0BFC0B59 0000C931
	v_dual_dot2acc_f32_f16 v53, v95, v7 :: v_dual_dot2acc_f32_f16 v46, v90, v9// 000000A73928: CB180F5F 352E135A
	v_dot2acc_f32_f16 v51, v95, v11                            // 000000A73930: 0466175F
	v_pk_fma_f16 v92, v92, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A73934: CC0E005C 0BFC0B5C 0000C931
	v_and_or_b32 v88, 0xffff, v93, v88                         // 000000A73940: D6570058 0562BAFF 0000FFFF
	v_dual_dot2acc_f32_f16 v48, v89, v6 :: v_dual_dot2acc_f32_f16 v47, v91, v4// 000000A7394C: CB180D59 302E095B
	v_dual_dot2acc_f32_f16 v46, v89, v10 :: v_dual_dot2acc_f32_f16 v53, v91, v8// 000000A73954: CB181559 2E34115B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A7395C: BF870193
	v_pk_fma_f16 v88, v88, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A73960: CC0E0058 0BFC0B58 0000C931
	v_dual_dot2acc_f32_f16 v48, v92, v7 :: v_dual_dot2acc_f32_f16 v27, v90, v1// 000000A7396C: CB180F5C 301A035A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A73974: BF870113
	v_dual_dot2acc_f32_f16 v51, v91, v12 :: v_dual_dot2acc_f32_f16 v46, v92, v11// 000000A73978: CB18195B 332E175C
	v_dual_dot2acc_f32_f16 v45, v90, v13 :: v_dual_dot2acc_f32_f16 v48, v88, v8// 000000A73980: CB181B5A 2D301158
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000A73988: BF8701A3
	v_dot2acc_f32_f16 v27, v89, v2                             // 000000A7398C: 04360559
	v_and_b32_e32 v90, 0xffff, v86                             // 000000A73990: 36B4ACFF 0000FFFF
	v_dual_dot2acc_f32_f16 v46, v88, v12 :: v_dual_dot2acc_f32_f16 v45, v89, v14// 000000A73998: CB181958 2E2C1D59
	v_bfe_u32 v89, v86, 8, 16                                  // 000000A739A0: D6100059 02411156
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A739A8: BF870004
	v_dot2acc_f32_f16 v27, v92, v3                             // 000000A739AC: 0436075C
	v_bfe_u32 v86, v86, 4, 16                                  // 000000A739B0: D6100056 02410956
	.long 0xd72c005a                                           // 000000A739B8: D72C005A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v90, vcc_lo              // 000000A739BC: 0202B4FF 83DCD12D
	s_waitcnt vmcnt(4)                                         // 000000A739C4: BF8913F7
	v_bfe_u32 v91, v85, 12, 16                                 // 000000A739C8: D610005B 02411955
	.long 0xd72c0059                                           // 000000A739D0: D72C0059
	v_cndmask_b32_e32 v1, 0x83dcd12d, v89, vcc_lo              // 000000A739D4: 0202B2FF 83DCD12D
	v_bfe_u32 v93, v85, 4, 16                                  // 000000A739DC: D610005D 02410955
	.long 0xd72c0056                                           // 000000A739E4: D72C0056
	v_cndmask_b32_e32 v1, 0x83dcd12d, v86, vcc_lo              // 000000A739E8: 0202ACFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 000000A739F0: BF870254
	.long 0xd72c005b                                           // 000000A739F4: D72C005B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v91, vcc_lo              // 000000A739F8: 0202B6FF 83DCD12D
	v_sad_u8 v90, v90, 0, 0x6400                               // 000000A73A00: D622005A 03FD015A 00006400
	v_dot2acc_f32_f16 v27, v88, v4                             // 000000A73A0C: 04360958
	v_sad_u8 v89, v89, 0, 0x6400                               // 000000A73A10: D6220059 03FD0159 00006400
	v_sad_u8 v86, v86, 0, 0x6400                               // 000000A73A1C: D6220056 03FD0156 00006400
	v_lshlrev_b32_e32 v90, 16, v90                             // 000000A73A28: 30B4B490
	v_sad_u8 v91, v91, 0, 0x6400                               // 000000A73A2C: D622005B 03FD015B 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A73A38: BF870092
	v_and_or_b32 v86, 0xffff, v86, v90                         // 000000A73A3C: D6570056 056AACFF 0000FFFF
	v_pk_fma_f16 v86, v86, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A73A48: CC0E0056 0BFC0B56 0000C931
	v_and_b32_e32 v87, 0xffff, v87                             // 000000A73A54: 36AEAEFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A73A5C: BF870091
	v_lshl_or_b32 v87, v89, 16, v87                            // 000000A73A60: D6560057 055D2159
	v_pk_fma_f16 v87, v87, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A73A68: CC0E0057 0BFC0B57 0000C931
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000A73A74: BF8701B1
	v_dual_dot2acc_f32_f16 v44, v87, v1 :: v_dual_dot2acc_f32_f16 v45, v92, v15// 000000A73A78: CB180357 2C2C1F5C
	v_dot2acc_f32_f16 v42, v87, v5                             // 000000A73A80: 04540B57
	v_bfe_u32 v92, v85, 8, 16                                  // 000000A73A84: D610005C 02411155
	v_dual_dot2acc_f32_f16 v44, v86, v2 :: v_dual_and_b32 v85, 0xffff, v85// 000000A73A8C: CB240556 2C54AAFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000A73A98: BF8701A4
	v_dual_dot2acc_f32_f16 v45, v88, v16 :: v_dual_dot2acc_f32_f16 v40, v87, v13// 000000A73A9C: CB182158 2D281B57
	.long 0xd72c0058                                           // 000000A73AA4: D72C0058
	v_cndmask_b32_e32 v1, 0x83dcd12d, v93, vcc_lo              // 000000A73AA8: 0202BAFF 83DCD12D
	.long 0xd72c0055                                           // 000000A73AB0: D72C0055
	v_cndmask_b32_e32 v1, 0x83dcd12d, v85, vcc_lo              // 000000A73AB4: 0202AAFF 83DCD12D
	v_dot2acc_f32_f16 v42, v86, v6                             // 000000A73ABC: 04540D56
	.long 0xd72c005c                                           // 000000A73AC0: D72C005C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v92, vcc_lo              // 000000A73AC4: 0202B8FF 83DCD12D
	v_dot2acc_f32_f16 v40, v86, v14                            // 000000A73ACC: 04501D56
	v_mov_b32_e32 v93, v74                                     // 000000A73AD0: 7EBA034A
	v_sad_u8 v88, v88, 0, 0x6400                               // 000000A73AD4: D6220058 03FD0158 00006400
	v_sad_u8 v85, v85, 0, 0x6400                               // 000000A73AE0: D6220055 03FD0155 00006400
	v_sad_u8 v90, v92, 0, 0x6400                               // 000000A73AEC: D622005A 03FD015C 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A73AF8: BF870092
	v_dual_mov_b32 v92, v68 :: v_dual_lshlrev_b32 v85, 16, v85 // 000000A73AFC: CA220144 5C54AA90
	v_and_or_b32 v85, 0xffff, v88, v85                         // 000000A73B04: D6570055 0556B0FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000A73B10: BF870141
	v_pk_fma_f16 v85, v85, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A73B14: CC0E0055 0BFC0B55 0000C931
	v_and_b32_e32 v89, 0xffff, v91                             // 000000A73B20: 36B2B6FF 0000FFFF
	s_waitcnt vmcnt(3)                                         // 000000A73B28: BF890FF7
	v_bfe_u32 v91, v82, 4, 16                                  // 000000A73B2C: D610005B 02410952
	v_lshl_or_b32 v89, v90, 16, v89                            // 000000A73B34: D6560059 0565215A
	v_bfe_u32 v90, v82, 8, 16                                  // 000000A73B3C: D610005A 02411152
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000A73B44: BF870232
	v_pk_fma_f16 v88, v89, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A73B48: CC0E0058 0BFC0B59 0000C931
	v_bfe_u32 v89, v82, 12, 16                                 // 000000A73B54: D6100059 02411952
	v_and_b32_e32 v82, 0xffff, v82                             // 000000A73B5C: 36A4A4FF 0000FFFF
	.long 0xd72c005a                                           // 000000A73B64: D72C005A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v90, vcc_lo              // 000000A73B68: 0202B4FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A73B70: BF870214
	v_dual_dot2acc_f32_f16 v42, v88, v7 :: v_dual_dot2acc_f32_f16 v41, v87, v9// 000000A73B74: CB180F58 2A281357
	.long 0xd72c0059                                           // 000000A73B7C: D72C0059
	v_cndmask_b32_e32 v1, 0x83dcd12d, v89, vcc_lo              // 000000A73B80: 0202B2FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000A73B88: BF870224
	.long 0xd72c0052                                           // 000000A73B8C: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 000000A73B90: 0202A4FF 83DCD12D
	v_dot2acc_f32_f16 v44, v88, v3                             // 000000A73B98: 04580758
	v_dual_dot2acc_f32_f16 v42, v85, v8 :: v_dual_dot2acc_f32_f16 v41, v86, v10// 000000A73B9C: CB181155 2A281556
	v_bfe_u32 v86, v83, 8, 16                                  // 000000A73BA4: D6100056 02411153
	v_sad_u8 v90, v90, 0, 0x6400                               // 000000A73BAC: D622005A 03FD015A 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_3)// 000000A73BB8: BF8701D4
	v_dot2acc_f32_f16 v44, v85, v4                             // 000000A73BBC: 04580955
	v_sad_u8 v89, v89, 0, 0x6400                               // 000000A73BC0: D6220059 03FD0159 00006400
	v_dot2acc_f32_f16 v41, v88, v11                            // 000000A73BCC: 04521758
	.long 0xd72c0056                                           // 000000A73BD0: D72C0056
	v_cndmask_b32_e32 v1, 0x83dcd12d, v86, vcc_lo              // 000000A73BD4: 0202ACFF 83DCD12D
	v_sad_u8 v82, v82, 0, 0x6400                               // 000000A73BDC: D6220052 03FD0152 00006400
	v_dot2acc_f32_f16 v41, v85, v12                            // 000000A73BE8: 04521955
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A73BEC: BF870093
	v_sad_u8 v86, v86, 0, 0x6400                               // 000000A73BF0: D6220056 03FD0156 00006400
	v_lshl_or_b32 v84, v86, 16, v84                            // 000000A73BFC: D6560054 05512156
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000A73C04: BF8701B1
	v_pk_fma_f16 v84, v84, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A73C08: CC0E0054 0BFC0B54 0000C931
	v_and_b32_e32 v87, 0xffff, v83                             // 000000A73C14: 36AEA6FF 0000FFFF
	v_bfe_u32 v83, v83, 4, 16                                  // 000000A73C1C: D6100053 02410953
	v_dual_dot2acc_f32_f16 v39, v84, v1 :: v_dual_lshlrev_b32 v82, 16, v82// 000000A73C24: CB220354 2752A490
	v_dot2acc_f32_f16 v38, v84, v5                             // 000000A73C2C: 044C0B54
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A73C30: BF870214
	.long 0xd72c0057                                           // 000000A73C34: D72C0057
	v_cndmask_b32_e32 v1, 0x83dcd12d, v87, vcc_lo              // 000000A73C38: 0202AEFF 83DCD12D
	.long 0xd72c0053                                           // 000000A73C40: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v83, vcc_lo              // 000000A73C44: 0202A6FF 83DCD12D
	v_dot2acc_f32_f16 v37, v84, v9                             // 000000A73C4C: 044A1354
	v_dot2acc_f32_f16 v40, v88, v15                            // 000000A73C50: 04501F58
	v_dot2acc_f32_f16 v36, v84, v13                            // 000000A73C54: 04481B54
	v_bfe_u32 v84, v80, 8, 16                                  // 000000A73C58: D6100054 02411150
	s_waitcnt vmcnt(2)                                         // 000000A73C60: BF890BF7
	v_bfe_u32 v88, v79, 4, 16                                  // 000000A73C64: D6100058 0241094F
	v_sad_u8 v87, v87, 0, 0x6400                               // 000000A73C6C: D6220057 03FD0157 00006400
	v_sad_u8 v83, v83, 0, 0x6400                               // 000000A73C78: D6220053 03FD0153 00006400
	v_dot2acc_f32_f16 v40, v85, v16                            // 000000A73C84: 04502155
	v_bfe_u32 v85, v79, 12, 16                                 // 000000A73C88: D6100055 0241194F
	.long 0xd72c0054                                           // 000000A73C90: D72C0054
	v_cndmask_b32_e32 v1, 0x83dcd12d, v84, vcc_lo              // 000000A73C94: 0202A8FF 83DCD12D
	v_lshlrev_b32_e32 v87, 16, v87                             // 000000A73C9C: 30AEAE90
	.long 0xd72c0058                                           // 000000A73CA0: D72C0058
	v_cndmask_b32_e32 v1, 0x83dcd12d, v88, vcc_lo              // 000000A73CA4: 0202B0FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A73CAC: BF870194
	.long 0xd72c0055                                           // 000000A73CB0: D72C0055
	v_cndmask_b32_e32 v1, 0x83dcd12d, v85, vcc_lo              // 000000A73CB4: 0202AAFF 83DCD12D
	v_and_or_b32 v83, 0xffff, v83, v87                         // 000000A73CBC: D6570053 055EA6FF 0000FFFF
	v_sad_u8 v84, v84, 0, 0x6400                               // 000000A73CC8: D6220054 03FD0154 00006400
	s_delay_alu instid0(VALU_DEP_2)                            // 000000A73CD4: BF870002
	v_pk_fma_f16 v83, v83, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A73CD8: CC0E0053 0BFC0B53 0000C931
	v_and_b32_e32 v86, 0xffff, v89                             // 000000A73CE4: 36ACB2FF 0000FFFF
	.long 0xd72c0059                                           // 000000A73CEC: D72C0059
	v_cndmask_b32_e32 v1, 0x83dcd12d, v91, vcc_lo              // 000000A73CF0: 0202B6FF 83DCD12D
	v_sad_u8 v85, v85, 0, 0x6400                               // 000000A73CF8: D6220055 03FD0155 00006400
	v_mov_b32_e32 v91, v74                                     // 000000A73D04: 7EB6034A
	v_dot2acc_f32_f16 v39, v83, v2                             // 000000A73D08: 044E0553
	v_lshl_or_b32 v86, v90, 16, v86                            // 000000A73D0C: D6560056 0559215A
	v_dot2acc_f32_f16 v38, v83, v6                             // 000000A73D14: 044C0D53
	v_dot2acc_f32_f16 v37, v83, v10                            // 000000A73D18: 044A1553
	v_dual_dot2acc_f32_f16 v36, v83, v14 :: v_dual_and_b32 v83, 0xffff, v80// 000000A73D1C: CB241D53 2452A0FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A73D28: BF870004
	v_pk_fma_f16 v86, v86, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A73D2C: CC0E0056 0BFC0B56 0000C931
	v_sad_u8 v87, v89, 0, 0x6400                               // 000000A73D38: D6220057 03FD0159 00006400
	v_bfe_u32 v80, v80, 4, 16                                  // 000000A73D44: D6100050 02410950
	v_and_b32_e32 v81, 0xffff, v81                             // 000000A73D4C: 36A2A2FF 0000FFFF
	.long 0xd72c0053                                           // 000000A73D54: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v83, vcc_lo              // 000000A73D58: 0202A6FF 83DCD12D
	v_dot2acc_f32_f16 v39, v86, v3                             // 000000A73D60: 044E0756
	v_dot2acc_f32_f16 v38, v86, v7                             // 000000A73D64: 044C0F56
	v_dot2acc_f32_f16 v37, v86, v11                            // 000000A73D68: 044A1756
	v_and_or_b32 v82, 0xffff, v87, v82                         // 000000A73D6C: D6570052 054AAEFF 0000FFFF
	v_bfe_u32 v87, v79, 8, 16                                  // 000000A73D78: D6100057 0241114F
	.long 0xd72c0050                                           // 000000A73D80: D72C0050
	v_cndmask_b32_e32 v1, 0x83dcd12d, v80, vcc_lo              // 000000A73D84: 0202A0FF 83DCD12D
	v_dot2acc_f32_f16 v36, v86, v15                            // 000000A73D8C: 04481F56
	v_sad_u8 v83, v83, 0, 0x6400                               // 000000A73D90: D6220053 03FD0153 00006400
	v_pk_fma_f16 v82, v82, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A73D9C: CC0E0052 0BFC0B52 0000C931
	.long 0xd72c0057                                           // 000000A73DA8: D72C0057
	v_cndmask_b32_e32 v1, 0x83dcd12d, v87, vcc_lo              // 000000A73DAC: 0202AEFF 83DCD12D
	v_lshl_or_b32 v81, v84, 16, v81                            // 000000A73DB4: D6560051 05452154
	v_and_b32_e32 v79, 0xffff, v79                             // 000000A73DBC: 369E9EFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A73DC4: BF870004
	v_dual_dot2acc_f32_f16 v36, v82, v16 :: v_dual_lshlrev_b32 v83, 16, v83// 000000A73DC8: CB222152 2452A690
	v_sad_u8 v80, v80, 0, 0x6400                               // 000000A73DD0: D6220050 03FD0150 00006400
	v_dot2acc_f32_f16 v38, v82, v8                             // 000000A73DDC: 044C1152
	v_pk_fma_f16 v81, v81, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A73DE0: CC0E0051 0BFC0B51 0000C931
	v_sad_u8 v84, v87, 0, 0x6400                               // 000000A73DEC: D6220054 03FD0157 00006400
	.long 0xd72c004f                                           // 000000A73DF8: D72C004F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v79, vcc_lo              // 000000A73DFC: 02029EFF 83DCD12D
	v_and_or_b32 v80, 0xffff, v80, v83                         // 000000A73E04: D6570050 054EA0FF 0000FFFF
	v_and_b32_e32 v83, 0xffff, v85                             // 000000A73E10: 36A6AAFF 0000FFFF
	v_dual_dot2acc_f32_f16 v39, v82, v4 :: v_dual_dot2acc_f32_f16 v34, v81, v5// 000000A73E18: CB180952 27220B51
	v_sad_u8 v85, v88, 0, 0x6400                               // 000000A73E20: D6220055 03FD0158 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A73E2C: BF870214
	v_pk_fma_f16 v80, v80, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A73E30: CC0E0050 0BFC0B50 0000C931
	v_lshl_or_b32 v83, v84, 16, v83                            // 000000A73E3C: D6560053 054D2154
	v_dot2acc_f32_f16 v37, v82, v12                            // 000000A73E44: 044A1952
	v_sad_u8 v79, v79, 0, 0x6400                               // 000000A73E48: D622004F 03FD014F 00006400
	v_and_b32_e32 v82, 0xffff, v77                             // 000000A73E54: 36A49AFF 0000FFFF
	v_dot2acc_f32_f16 v34, v80, v6                             // 000000A73E5C: 04440D50
	v_pk_fma_f16 v83, v83, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A73E60: CC0E0053 0BFC0B53 0000C931
	v_dot2acc_f32_f16 v35, v81, v1                             // 000000A73E6C: 04460351
	v_dual_dot2acc_f32_f16 v32, v81, v13 :: v_dual_lshlrev_b32 v79, 16, v79// 000000A73E70: CB221B51 204E9E90
	v_bfe_u32 v84, v77, 8, 16                                  // 000000A73E78: D6100054 0241114D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A73E80: BF870193
	v_dual_dot2acc_f32_f16 v34, v83, v7 :: v_dual_dot2acc_f32_f16 v35, v80, v2// 000000A73E84: CB180F53 22220550
	v_and_or_b32 v79, 0xffff, v85, v79                         // 000000A73E8C: D657004F 053EAAFF 0000FFFF
	v_bfe_u32 v77, v77, 4, 16                                  // 000000A73E98: D610004D 0241094D
	.long 0xd72c0052                                           // 000000A73EA0: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 000000A73EA4: 0202A4FF 83DCD12D
	s_waitcnt vmcnt(1)                                         // 000000A73EAC: BF8907F7
	v_bfe_u32 v85, v76, 12, 16                                 // 000000A73EB0: D6100055 0241194C
	.long 0xd72c0054                                           // 000000A73EB8: D72C0054
	v_cndmask_b32_e32 v1, 0x83dcd12d, v84, vcc_lo              // 000000A73EBC: 0202A8FF 83DCD12D
	v_dot2acc_f32_f16 v33, v81, v9                             // 000000A73EC4: 04421351
	v_bfe_u32 v86, v76, 8, 16                                  // 000000A73EC8: D6100056 0241114C
	.long 0xd72c004d                                           // 000000A73ED0: D72C004D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v77, vcc_lo              // 000000A73ED4: 02029AFF 83DCD12D
	v_bfe_u32 v87, v76, 4, 16                                  // 000000A73EDC: D6100057 0241094C
	.long 0xd72c0055                                           // 000000A73EE4: D72C0055
	v_cndmask_b32_e32 v1, 0x83dcd12d, v85, vcc_lo              // 000000A73EE8: 0202AAFF 83DCD12D
	v_and_b32_e32 v76, 0xffff, v76                             // 000000A73EF0: 369898FF 0000FFFF
	v_pk_fma_f16 v79, v79, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A73EF8: CC0E004F 0BFC0B4F 0000C931
	v_dot2acc_f32_f16 v35, v83, v3                             // 000000A73F04: 04460753
	v_sad_u8 v82, v82, 0, 0x6400                               // 000000A73F08: D6220052 03FD0152 00006400
	v_sad_u8 v84, v84, 0, 0x6400                               // 000000A73F14: D6220054 03FD0154 00006400
	.long 0xd72c0056                                           // 000000A73F20: D72C0056
	v_cndmask_b32_e32 v1, 0x83dcd12d, v86, vcc_lo              // 000000A73F24: 0202ACFF 83DCD12D
	.long 0xd72c004c                                           // 000000A73F2C: D72C004C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v76, vcc_lo              // 000000A73F30: 020298FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A73F38: BF870004
	v_dual_dot2acc_f32_f16 v35, v79, v4 :: v_dual_lshlrev_b32 v82, 16, v82// 000000A73F3C: CB22094F 2352A490
	v_sad_u8 v77, v77, 0, 0x6400                               // 000000A73F44: D622004D 03FD014D 00006400
	v_sad_u8 v85, v85, 0, 0x6400                               // 000000A73F50: D6220055 03FD0155 00006400
	v_lshl_or_b32 v78, v84, 16, v78                            // 000000A73F5C: D656004E 05392154
	.long 0xd72c0051                                           // 000000A73F64: D72C0051
	v_cndmask_b32_e32 v1, 0x83dcd12d, v87, vcc_lo              // 000000A73F68: 0202AEFF 83DCD12D
	v_dot2acc_f32_f16 v33, v80, v10                            // 000000A73F70: 04421550
	v_and_or_b32 v77, 0xffff, v77, v82                         // 000000A73F74: D657004D 054A9AFF 0000FFFF
	v_and_b32_e32 v82, 0xffff, v85                             // 000000A73F80: 36A4AAFF 0000FFFF
	v_sad_u8 v84, v86, 0, 0x6400                               // 000000A73F88: D6220054 03FD0156 00006400
	v_sad_u8 v76, v76, 0, 0x6400                               // 000000A73F94: D622004C 03FD014C 00006400
	v_pk_fma_f16 v78, v78, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A73FA0: CC0E004E 0BFC0B4E 0000C931
	v_dual_dot2acc_f32_f16 v33, v83, v11 :: v_dual_dot2acc_f32_f16 v32, v80, v14// 000000A73FAC: CB181753 21201D50
	v_pk_fma_f16 v77, v77, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A73FB4: CC0E004D 0BFC0B4D 0000C931
	v_lshl_or_b32 v80, v84, 16, v82                            // 000000A73FC0: D6560050 05492154
	v_sad_u8 v81, v81, 0, 0x6400                               // 000000A73FC8: D6220051 03FD0151 00006400
	v_dual_dot2acc_f32_f16 v31, v78, v1 :: v_dual_lshlrev_b32 v76, 16, v76// 000000A73FD4: CB22034E 1F4C9890
	v_dual_dot2acc_f32_f16 v33, v79, v12 :: v_dual_dot2acc_f32_f16 v30, v78, v5// 000000A73FDC: CB18194F 211E0B4E
	v_dot2acc_f32_f16 v29, v78, v9                             // 000000A73FE4: 043A134E
	v_pk_fma_f16 v80, v80, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A73FE8: CC0E0050 0BFC0B50 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000A73FF4: BF870244
	v_and_or_b32 v76, 0xffff, v81, v76                         // 000000A73FF8: D657004C 0532A2FF 0000FFFF
	v_dual_dot2acc_f32_f16 v31, v77, v2 :: v_dual_dot2acc_f32_f16 v32, v83, v15// 000000A74004: CB18054D 1F201F53
	v_dot2acc_f32_f16 v30, v77, v6                             // 000000A7400C: 043C0D4D
	v_dot2acc_f32_f16 v29, v77, v10                            // 000000A74010: 043A154D
	v_pk_fma_f16 v76, v76, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A74014: CC0E004C 0BFC0B4C 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A74020: BF870214
	v_dual_dot2acc_f32_f16 v31, v80, v3 :: v_dual_dot2acc_f32_f16 v32, v79, v16// 000000A74024: CB180750 1F20214F
	v_dot2acc_f32_f16 v30, v80, v7                             // 000000A7402C: 043C0F50
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A74030: BF870194
	v_dual_dot2acc_f32_f16 v29, v80, v11 :: v_dual_dot2acc_f32_f16 v28, v78, v13// 000000A74034: CB181750 1D1C1B4E
	v_dual_dot2acc_f32_f16 v31, v76, v4 :: v_dual_and_b32 v78, 0xffff, v59// 000000A7403C: CB24094C 1F4E76FF 0000FFFF
	v_dot2acc_f32_f16 v34, v79, v8                             // 000000A74048: 0444114F
	v_bfe_u32 v79, v59, 8, 16                                  // 000000A7404C: D610004F 0241113B
	v_bfe_u32 v59, v59, 4, 16                                  // 000000A74054: D610003B 0241093B
	s_waitcnt vmcnt(0)                                         // 000000A7405C: BF8903F7
	v_bfe_u32 v81, v58, 12, 16                                 // 000000A74060: D6100051 0241193A
	.long 0xd72c004e                                           // 000000A74068: D72C004E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 000000A7406C: 02029CFF 83DCD12D
	v_bfe_u32 v82, v58, 8, 16                                  // 000000A74074: D6100052 0241113A
	.long 0xd72c004f                                           // 000000A7407C: D72C004F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v79, vcc_lo              // 000000A74080: 02029EFF 83DCD12D
	.long 0xd72c003b                                           // 000000A74088: D72C003B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 000000A7408C: 020276FF 83DCD12D
	.long 0xd72c0051                                           // 000000A74094: D72C0051
	v_cndmask_b32_e32 v1, 0x83dcd12d, v81, vcc_lo              // 000000A74098: 0202A2FF 83DCD12D
	v_dot2acc_f32_f16 v29, v76, v12                            // 000000A740A0: 043A194C
	.long 0xd72c0052                                           // 000000A740A4: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 000000A740A8: 0202A4FF 83DCD12D
	v_bfe_u32 v83, v58, 4, 16                                  // 000000A740B0: D6100053 0241093A
	v_sad_u8 v78, v78, 0, 0x6400                               // 000000A740B8: D622004E 03FD014E 00006400
	v_and_b32_e32 v58, 0xffff, v58                             // 000000A740C4: 367474FF 0000FFFF
	v_sad_u8 v79, v79, 0, 0x6400                               // 000000A740CC: D622004F 03FD014F 00006400
	v_sad_u8 v59, v59, 0, 0x6400                               // 000000A740D8: D622003B 03FD013B 00006400
	v_sad_u8 v81, v81, 0, 0x6400                               // 000000A740E4: D6220051 03FD0151 00006400
	v_lshlrev_b32_e32 v78, 16, v78                             // 000000A740F0: 309C9C90
	v_dot2acc_f32_f16 v30, v76, v8                             // 000000A740F4: 043C114C
	v_sad_u8 v82, v82, 0, 0x6400                               // 000000A740F8: D6220052 03FD0152 00006400
	.long 0xd72c003a                                           // 000000A74104: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 000000A74108: 020274FF 83DCD12D
	v_and_b32_e32 v81, 0xffff, v81                             // 000000A74110: 36A2A2FF 0000FFFF
	v_and_or_b32 v59, 0xffff, v59, v78                         // 000000A74118: D657003B 053A76FF 0000FFFF
	v_mov_b32_e32 v85, v72                                     // 000000A74124: 7EAA0348
	v_mov_b32_e32 v89, v65                                     // 000000A74128: 7EB20341
	v_mov_b32_e32 v87, v72                                     // 000000A7412C: 7EAE0348
	v_lshl_or_b32 v78, v82, 16, v81                            // 000000A74130: D656004E 05452152
	v_pk_fma_f16 v59, v59, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A74138: CC0E003B 0BFC0B3B 0000C931
	v_and_b32_e32 v60, 0xffff, v60                             // 000000A74144: 367878FF 0000FFFF
	v_sad_u8 v58, v58, 0, 0x6400                               // 000000A7414C: D622003A 03FD013A 00006400
	v_mov_b32_e32 v81, v70                                     // 000000A74158: 7EA20346
	v_pk_fma_f16 v78, v78, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A7415C: CC0E004E 0BFC0B4E 0000C931
	v_mov_b32_e32 v86, v64                                     // 000000A74168: 7EAC0340
	v_lshl_or_b32 v60, v79, 16, v60                            // 000000A7416C: D656003C 04F1214F
	v_dual_mov_b32 v79, v70 :: v_dual_lshlrev_b32 v58, 16, v58 // 000000A74174: CA220146 4F3A7490
	v_mov_b32_e32 v88, v73                                     // 000000A7417C: 7EB00349
	v_mov_b32_e32 v90, v73                                     // 000000A74180: 7EB40349
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000A74184: BF870124
	v_pk_fma_f16 v60, v60, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A74188: CC0E003C 0BFC0B3C 0000C931
	v_mov_b32_e32 v84, v71                                     // 000000A74194: 7EA80347
	v_dual_mov_b32 v82, v71 :: v_dual_dot2acc_f32_f16 v23, v60, v5// 000000A74198: CA180147 52160B3C
	v_dot2acc_f32_f16 v26, v60, v1                             // 000000A741A0: 0434033C
	v_dot2acc_f32_f16 v22, v60, v9                             // 000000A741A4: 042C133C
	v_dot2acc_f32_f16 v20, v60, v13                            // 000000A741A8: 04281B3C
	v_mov_b32_e32 v60, v67                                     // 000000A741AC: 7E780343
	v_dot2acc_f32_f16 v23, v59, v6                             // 000000A741B0: 042E0D3B
	v_dot2acc_f32_f16 v28, v77, v14                            // 000000A741B4: 04381D4D
	.long 0xd72c004d                                           // 000000A741B8: D72C004D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v83, vcc_lo              // 000000A741BC: 0202A6FF 83DCD12D
	v_dot2acc_f32_f16 v26, v59, v2                             // 000000A741C4: 0434053B
	v_dot2acc_f32_f16 v22, v59, v10                            // 000000A741C8: 042C153B
	v_dual_dot2acc_f32_f16 v20, v59, v14 :: v_dual_dot2acc_f32_f16 v23, v78, v7// 000000A741CC: CB181D3B 14160F4E
	v_mov_b32_e32 v2, v66                                      // 000000A741D4: 7E040342
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 000000A741D8: BF870254
	v_dual_dot2acc_f32_f16 v26, v78, v3 :: v_dual_mov_b32 v3, v75// 000000A741DC: CB10074E 1A02014B
	v_sad_u8 v77, v77, 0, 0x6400                               // 000000A741E4: D622004D 03FD014D 00006400
	v_dual_dot2acc_f32_f16 v22, v78, v11 :: v_dual_mov_b32 v83, v63// 000000A741F0: CB10174E 1652013F
	v_dot2acc_f32_f16 v20, v78, v15                            // 000000A741F8: 04281F4E
	v_mov_b32_e32 v78, v69                                     // 000000A741FC: 7E9C0345
	v_and_or_b32 v1, 0xffff, v77, v58                          // 000000A74200: D6570001 04EA9AFF 0000FFFF
	v_mov_b32_e32 v77, v61                                     // 000000A7420C: 7E9A033D
	v_dual_mov_b32 v59, v18 :: v_dual_mov_b32 v58, v67         // 000000A74210: CA100112 3B3A0143
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000A74218: BF8701B3
	v_pk_fma_f16 v1, v1, s5, 0xc931 op_sel_hi:[1,0,0]          // 000000A7421C: CC0E0001 0BFC0B01 0000C931
	v_dot2acc_f32_f16 v28, v80, v15                            // 000000A74228: 04381F50
	v_mov_b32_e32 v80, v62                                     // 000000A7422C: 7EA0033E
	v_dot2acc_f32_f16 v26, v1, v4                              // 000000A74230: 04340901
	v_dot2acc_f32_f16 v23, v1, v8                              // 000000A74234: 042E1101
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A74238: BF870004
	v_dot2acc_f32_f16 v28, v76, v16                            // 000000A7423C: 0438214C
	v_dot2acc_f32_f16 v22, v1, v12                             // 000000A74240: 042C1901
	v_dot2acc_f32_f16 v20, v1, v16                             // 000000A74244: 04282101
	v_mov_b32_e32 v4, v75                                      // 000000A74248: 7E08034B
	v_mov_b32_e32 v76, v69                                     // 000000A7424C: 7E980345
	v_mov_b32_e32 v1, v17                                      // 000000A74250: 7E020311
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000A74254: 917E047E
	s_cbranch_execz 58                                         // 000000A74258: BFA5003A <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi0EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x1c44>
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000A7425C: BF8700A1
	v_add_nc_u32_e32 v17, 1, v1                                // 000000A74260: 4A220281
	s_mov_b32 s6, exec_lo                                      // 000000A74264: BE86007E
	.long 0xd4c1007e                                           // 000000A74268: D4C1007E
	v_cndmask_b32_e32 v1, v17, v21, vcc_lo                     // 000000A7426C: 02022B11
	s_cbranch_execz 64555                                      // 000000A74270: BFA5FC2B <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi0EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0xc20>
	v_ashrrev_i32_e32 v18, 31, v17                             // 000000A74274: 3424229F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A74278: BF870091
	.long 0xd73c0005                                           // 000000A7427C: D73C0005
	v_cndmask_b32_e32 v1, 10, v17, vcc_lo                      // 000000A74280: 0202228A
	.long 0xd7006a07                                           // 000000A74284: D7006A07
	v_cndmask_b32_e32 v1, s1, v5, vcc_lo                       // 000000A74288: 02020A01
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A7428C: BF870111
	v_add_co_ci_u32_e64 v8, null, s3, v6, vcc_lo               // 000000A74290: D5207C08 01AA0C03
	.long 0xd7006a05                                           // 000000A74298: D7006A05
	v_cndmask_b32_e32 v1, v7, v57, vcc_lo                      // 000000A7429C: 02027307
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000A742A0: BF8700A1
	v_add_co_ci_u32_e64 v6, null, 0, v8, vcc_lo                // 000000A742A4: D5207C06 01AA1080
	.long 0xd7006a07                                           // 000000A742AC: D7006A07
	v_cndmask_b32_e32 v1, v7, v56, vcc_lo                      // 000000A742B0: 02027107
	v_add_co_ci_u32_e64 v8, null, 0, v8, vcc_lo                // 000000A742B4: D5207C08 01AA1080
	s_clause 0xf                                               // 000000A742BC: BF85000F
	global_load_b32 v66, v[5:6], off                           // 000000A742C0: DC520000 427C0005
	global_load_b32 v68, v[5:6], off offset:128                // 000000A742C8: DC520080 447C0005
	global_load_b32 v65, v[5:6], off offset:256                // 000000A742D0: DC520100 417C0005
	global_load_b32 v64, v[5:6], off offset:384                // 000000A742D8: DC520180 407C0005
	global_load_b32 v63, v[5:6], off offset:512                // 000000A742E0: DC520200 3F7C0005
	global_load_b32 v62, v[5:6], off offset:640                // 000000A742E8: DC520280 3E7C0005
	global_load_b32 v61, v[5:6], off offset:768                // 000000A742F0: DC520300 3D7C0005
	global_load_b32 v18, v[5:6], off offset:896                // 000000A742F8: DC520380 127C0005
	global_load_b32 v75, v[7:8], off                           // 000000A74300: DC520000 4B7C0007
	global_load_b32 v74, v[7:8], off offset:128                // 000000A74308: DC520080 4A7C0007
	global_load_b32 v73, v[7:8], off offset:256                // 000000A74310: DC520100 497C0007
	global_load_b32 v72, v[7:8], off offset:384                // 000000A74318: DC520180 487C0007
	global_load_b32 v71, v[7:8], off offset:512                // 000000A74320: DC520200 477C0007
	global_load_b32 v70, v[7:8], off offset:640                // 000000A74328: DC520280 467C0007
	global_load_b32 v69, v[7:8], off offset:768                // 000000A74330: DC520300 457C0007
	global_load_b32 v67, v[7:8], off offset:896                // 000000A74338: DC520380 437C0007
	s_branch 64503                                             // 000000A74340: BFA0FBF7 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi0EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0xc20>
	s_or_b32 exec_lo, exec_lo, s4                              // 000000A74344: 8C7E047E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000A74348: BF870009
	s_or_b32 exec_lo, exec_lo, s0                              // 000000A7434C: 8C7E007E
	s_waitcnt vmcnt(23)                                        // 000000A74350: BF895FF7
	v_dual_mov_b32 v1, v54 :: v_dual_mov_b32 v2, v43           // 000000A74354: CA100136 0102012B
	s_waitcnt vmcnt(7)                                         // 000000A7435C: BF891FF7
	v_dual_mov_b32 v3, v52 :: v_dual_mov_b32 v4, v49           // 000000A74360: CA100134 03040131
	v_dual_mov_b32 v5, v47 :: v_dual_mov_b32 v10, v48          // 000000A74368: CA10012F 050A0130
	v_dual_mov_b32 v7, v53 :: v_dual_mov_b32 v8, v51           // 000000A74370: CA100135 07080133
	v_dual_mov_b32 v9, v50 :: v_dual_mov_b32 v6, v27           // 000000A74378: CA100132 0906011B
	v_dual_mov_b32 v11, v46 :: v_dual_mov_b32 v12, v45         // 000000A74380: CA10012E 0B0C012D
	v_dual_mov_b32 v13, v44 :: v_dual_mov_b32 v14, v42         // 000000A74388: CA10012C 0D0E012A
	v_dual_mov_b32 v15, v41 :: v_dual_mov_b32 v16, v40         // 000000A74390: CA100129 0F100128
	v_dual_mov_b32 v17, v39 :: v_dual_mov_b32 v18, v38         // 000000A74398: CA100127 11120126
	v_dual_mov_b32 v21, v37 :: v_dual_mov_b32 v56, v35         // 000000A743A0: CA100125 15380123
	s_waitcnt vmcnt(0)                                         // 000000A743A8: BF8903F7
	v_dual_mov_b32 v55, v36 :: v_dual_mov_b32 v58, v33         // 000000A743AC: CA100124 373A0121
	v_dual_mov_b32 v57, v34 :: v_dual_mov_b32 v60, v31         // 000000A743B4: CA100122 393C011F
	v_dual_mov_b32 v59, v32 :: v_dual_mov_b32 v62, v29         // 000000A743BC: CA100120 3B3E011D
	v_mov_b32_e32 v61, v30                                     // 000000A743C4: 7E7A031E
	v_dual_mov_b32 v63, v28 :: v_dual_mov_b32 v64, v26         // 000000A743C8: CA10011C 3F40011A
	v_dual_mov_b32 v65, v23 :: v_dual_mov_b32 v66, v22         // 000000A743D0: CA100117 41420116
	v_mov_b32_e32 v67, v20                                     // 000000A743D8: 7E860314
	s_mov_b32 s0, 0x76543210                                   // 000000A743DC: BE8000FF 76543210
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000A743E4: BF870009
	v_permlanex16_b32 v1, v1, s0, 0xfedcba98                   // 000000A743E8: D65C0001 03FC0101 FEDCBA98
	v_permlanex16_b32 v3, v3, s0, 0xfedcba98                   // 000000A743F4: D65C0003 03FC0103 FEDCBA98
	v_permlanex16_b32 v2, v2, s0, 0xfedcba98                   // 000000A74400: D65C0002 03FC0102 FEDCBA98
	v_permlanex16_b32 v4, v4, s0, 0xfedcba98                   // 000000A7440C: D65C0004 03FC0104 FEDCBA98
	v_permlanex16_b32 v5, v5, s0, 0xfedcba98                   // 000000A74418: D65C0005 03FC0105 FEDCBA98
	v_permlanex16_b32 v7, v7, s0, 0xfedcba98                   // 000000A74424: D65C0007 03FC0107 FEDCBA98
	v_permlanex16_b32 v8, v8, s0, 0xfedcba98                   // 000000A74430: D65C0008 03FC0108 FEDCBA98
	v_permlanex16_b32 v9, v9, s0, 0xfedcba98                   // 000000A7443C: D65C0009 03FC0109 FEDCBA98
	v_permlanex16_b32 v6, v6, s0, 0xfedcba98                   // 000000A74448: D65C0006 03FC0106 FEDCBA98
	v_permlanex16_b32 v10, v10, s0, 0xfedcba98                 // 000000A74454: D65C000A 03FC010A FEDCBA98
	v_permlanex16_b32 v11, v11, s0, 0xfedcba98                 // 000000A74460: D65C000B 03FC010B FEDCBA98
	v_permlanex16_b32 v12, v12, s0, 0xfedcba98                 // 000000A7446C: D65C000C 03FC010C FEDCBA98
	v_permlanex16_b32 v13, v13, s0, 0xfedcba98                 // 000000A74478: D65C000D 03FC010D FEDCBA98
	v_permlanex16_b32 v14, v14, s0, 0xfedcba98                 // 000000A74484: D65C000E 03FC010E FEDCBA98
	v_permlanex16_b32 v15, v15, s0, 0xfedcba98                 // 000000A74490: D65C000F 03FC010F FEDCBA98
	v_permlanex16_b32 v16, v16, s0, 0xfedcba98                 // 000000A7449C: D65C0010 03FC0110 FEDCBA98
	v_permlanex16_b32 v17, v17, s0, 0xfedcba98                 // 000000A744A8: D65C0011 03FC0111 FEDCBA98
	v_permlanex16_b32 v18, v18, s0, 0xfedcba98                 // 000000A744B4: D65C0012 03FC0112 FEDCBA98
	v_permlanex16_b32 v21, v21, s0, 0xfedcba98                 // 000000A744C0: D65C0015 03FC0115 FEDCBA98
	v_permlanex16_b32 v55, v55, s0, 0xfedcba98                 // 000000A744CC: D65C0037 03FC0137 FEDCBA98
	v_permlanex16_b32 v56, v56, s0, 0xfedcba98                 // 000000A744D8: D65C0038 03FC0138 FEDCBA98
	v_permlanex16_b32 v57, v57, s0, 0xfedcba98                 // 000000A744E4: D65C0039 03FC0139 FEDCBA98
	v_permlanex16_b32 v58, v58, s0, 0xfedcba98                 // 000000A744F0: D65C003A 03FC013A FEDCBA98
	v_permlanex16_b32 v59, v59, s0, 0xfedcba98                 // 000000A744FC: D65C003B 03FC013B FEDCBA98
	v_permlanex16_b32 v60, v60, s0, 0xfedcba98                 // 000000A74508: D65C003C 03FC013C FEDCBA98
	v_permlanex16_b32 v61, v61, s0, 0xfedcba98                 // 000000A74514: D65C003D 03FC013D FEDCBA98
	v_permlanex16_b32 v62, v62, s0, 0xfedcba98                 // 000000A74520: D65C003E 03FC013E FEDCBA98
	v_permlanex16_b32 v63, v63, s0, 0xfedcba98                 // 000000A7452C: D65C003F 03FC013F FEDCBA98
	v_permlanex16_b32 v64, v64, s0, 0xfedcba98                 // 000000A74538: D65C0040 03FC0140 FEDCBA98
	v_permlanex16_b32 v65, v65, s0, 0xfedcba98                 // 000000A74544: D65C0041 03FC0141 FEDCBA98
	v_permlanex16_b32 v66, v66, s0, 0xfedcba98                 // 000000A74550: D65C0042 03FC0142 FEDCBA98
	v_permlanex16_b32 v67, v67, s0, 0xfedcba98                 // 000000A7455C: D65C0043 03FC0143 FEDCBA98
	.long 0xd44c0000                                           // 000000A74568: D44C0000
	v_cndmask_b32_e32 v1, 16, v25, vcc_lo                      // 000000A7456C: 02023290
	s_barrier                                                  // 000000A74570: BFBD0000
	buffer_gl0_inv                                             // 000000A74574: E0AC0000 00000000
	s_and_saveexec_b32 s1, s0                                  // 000000A7457C: BE812000
	s_cbranch_execz 73                                         // 000000A74580: BFA50049 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi0EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x1fa8>
	v_lshl_or_b32 v19, v24, 11, v19                            // 000000A74584: D6560013 044D1718
	v_dual_add_f32 v32, v32, v59 :: v_dual_add_f32 v21, v37, v21// 000000A7458C: C9087720 20142B25
	v_dual_add_f32 v10, v48, v10 :: v_dual_add_f32 v5, v47, v5 // 000000A74594: C9081530 0A040B2F
	v_dual_add_f32 v4, v49, v4 :: v_dual_add_f32 v1, v54, v1   // 000000A7459C: C9080931 04000336
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A745A4: BF870004
	v_dual_add_f32 v2, v43, v2 :: v_dual_add_nc_u32 v37, 0x5400, v19// 000000A745A8: C920052B 022426FF 00005400
	v_dual_add_f32 v18, v38, v18 :: v_dual_add_f32 v13, v44, v13// 000000A745B4: C9082526 120C1B2C
	v_dual_add_f32 v14, v42, v14 :: v_dual_add_f32 v7, v53, v7 // 000000A745BC: C9081D2A 0E060F35
	v_dual_add_f32 v8, v51, v8 :: v_dual_add_f32 v3, v52, v3   // 000000A745C4: C9081133 08020734
	v_add_nc_u32_e32 v38, 0x5800, v19                          // 000000A745CC: 4A4C26FF 00005800
	v_dual_add_f32 v12, v45, v12 :: v_dual_add_f32 v9, v50, v9 // 000000A745D4: C908192D 0C081332
	v_dual_add_f32 v6, v27, v6 :: v_dual_add_nc_u32 v19, 0x5c00, v19// 000000A745DC: C9200D1B 061226FF 00005C00
	v_dual_add_f32 v20, v20, v67 :: v_dual_add_f32 v23, v23, v65// 000000A745E8: C9088714 14168317
	v_dual_add_f32 v22, v22, v66 :: v_dual_add_f32 v31, v31, v60// 000000A745F0: C9088516 161E791F
	v_dual_add_f32 v26, v26, v64 :: v_dual_add_f32 v29, v29, v62// 000000A745F8: C908811A 1A1C7D1D
	v_dual_add_f32 v28, v28, v63 :: v_dual_add_f32 v33, v33, v58// 000000A74600: C9087F1C 1C207521
	v_dual_add_f32 v30, v30, v61 :: v_dual_add_f32 v35, v35, v56// 000000A74608: C9087B1E 1E227123
	v_dual_add_f32 v34, v34, v57 :: v_dual_add_f32 v15, v41, v15// 000000A74610: C9087322 220E1F29
	v_dual_add_f32 v36, v36, v55 :: v_dual_add_f32 v17, v39, v17// 000000A74618: C9086F24 24102327
	v_dual_add_f32 v16, v40, v16 :: v_dual_add_f32 v11, v46, v11// 000000A74620: C9082128 100A172E
	ds_store_2addr_b32 v37, v1, v5 offset0:128 offset1:144     // 000000A74628: D8389080 00050125
	ds_store_2addr_b32 v38, v3, v7 offset1:16                  // 000000A74630: D8381000 00070326
	ds_store_2addr_b32 v38, v2, v8 offset0:128 offset1:144     // 000000A74638: D8389080 00080226
	ds_store_2addr_b32 v19, v4, v9 offset1:16                  // 000000A74640: D8381000 00090413
	ds_store_2addr_b32 v37, v6, v13 offset0:160 offset1:176    // 000000A74648: D838B0A0 000D0625
	ds_store_2addr_b32 v38, v10, v14 offset0:32 offset1:48     // 000000A74650: D8383020 000E0A26
	ds_store_2addr_b32 v38, v11, v15 offset0:160 offset1:176   // 000000A74658: D838B0A0 000F0B26
	ds_store_2addr_b32 v19, v12, v16 offset0:32 offset1:48     // 000000A74660: D8383020 00100C13
	ds_store_2addr_b32 v37, v17, v35 offset0:192 offset1:208   // 000000A74668: D838D0C0 00231125
	ds_store_2addr_b32 v38, v18, v34 offset0:64 offset1:80     // 000000A74670: D8385040 00221226
	ds_store_2addr_b32 v38, v21, v33 offset0:192 offset1:208   // 000000A74678: D838D0C0 00211526
	ds_store_2addr_b32 v19, v36, v32 offset0:64 offset1:80     // 000000A74680: D8385040 00202413
	ds_store_2addr_b32 v37, v31, v26 offset0:224 offset1:240   // 000000A74688: D838F0E0 001A1F25
	ds_store_2addr_b32 v38, v30, v23 offset0:96 offset1:112    // 000000A74690: D8387060 00171E26
	ds_store_2addr_b32 v38, v29, v22 offset0:224 offset1:240   // 000000A74698: D838F0E0 00161D26
	ds_store_2addr_b32 v19, v28, v20 offset0:96 offset1:112    // 000000A746A0: D8387060 00141C13
	s_or_b32 exec_lo, exec_lo, s1                              // 000000A746A8: 8C7E017E
	.long 0xd44c0001                                           // 000000A746AC: D44C0001
	v_cndmask_b32_e32 v1, 0x200, v0, vcc_lo                    // 000000A746B0: 020200FF 00000200
	s_waitcnt lgkmcnt(0)                                       // 000000A746B8: BF89FC07
	s_barrier                                                  // 000000A746BC: BFBD0000
	buffer_gl0_inv                                             // 000000A746C0: E0AC0000 00000000
	s_and_saveexec_b32 s3, s1                                  // 000000A746C8: BE832001
	s_cbranch_execz 47                                         // 000000A746CC: BFA5002F <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi0EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x208c>
	v_mov_b32_e32 v1, v0                                       // 000000A746D0: 7E020300
	s_mov_b32 s4, 0                                            // 000000A746D4: BE840080
	s_nop 0                                                    // 000000A746D8: BF800000
	s_nop 0                                                    // 000000A746DC: BF800000
	s_nop 0                                                    // 000000A746E0: BF800000
	s_nop 0                                                    // 000000A746E4: BF800000
	s_nop 0                                                    // 000000A746E8: BF800000
	s_nop 0                                                    // 000000A746EC: BF800000
	s_nop 0                                                    // 000000A746F0: BF800000
	s_nop 0                                                    // 000000A746F4: BF800000
	s_nop 0                                                    // 000000A746F8: BF800000
	s_nop 0                                                    // 000000A746FC: BF800000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000A74700: BF870001
	v_lshlrev_b32_e32 v8, 2, v1                                // 000000A74704: 30100282
	v_cmp_lt_u32_e32 vcc_lo, 0xff, v1                          // 000000A74708: 7C9202FF 000000FF
	ds_load_2addr_stride64_b32 v[2:3], v8 offset0:86 offset1:94// 000000A74710: D8E05E56 02000008
	ds_load_2addr_stride64_b32 v[4:5], v8 offset0:102 offset1:110// 000000A74718: D8E06E66 04000008
	ds_load_2addr_stride64_b32 v[6:7], v8 offset0:118 offset1:126// 000000A74720: D8E07E76 06000008
	s_or_b32 s4, vcc_lo, s4                                    // 000000A74728: 8C04046A
	s_waitcnt lgkmcnt(2)                                       // 000000A7472C: BF89FC27
	v_add_f32_e32 v2, 0, v2                                    // 000000A74730: 06040480
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000A74734: BF8700C1
	v_add_f32_e32 v9, v2, v3                                   // 000000A74738: 06120702
	ds_load_2addr_stride64_b32 v[2:3], v8 offset0:134 offset1:142// 000000A7473C: D8E08E86 02000008
	s_waitcnt lgkmcnt(2)                                       // 000000A74744: BF89FC27
	v_add_f32_e32 v4, v9, v4                                   // 000000A74748: 06080909
	v_add_f32_e32 v4, v4, v5                                   // 000000A7474C: 06080B04
	s_waitcnt lgkmcnt(1)                                       // 000000A74750: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A74754: BF870091
	v_add_f32_e32 v4, v4, v6                                   // 000000A74758: 06080D04
	v_add_f32_e32 v4, v4, v7                                   // 000000A7475C: 06080F04
	s_waitcnt lgkmcnt(0)                                       // 000000A74760: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000A74764: BF8700A1
	v_add_f32_e32 v2, v4, v2                                   // 000000A74768: 06040504
	v_add_nc_u32_e32 v4, 0x100, v1                             // 000000A7476C: 4A0802FF 00000100
	v_dual_add_f32 v2, v2, v3 :: v_dual_mov_b32 v1, v4         // 000000A74774: C9100702 02000104
	ds_store_b32 v8, v2 offset:38400                           // 000000A7477C: D8349600 00000208
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000A74784: 917E047E
	s_cbranch_execnz 65501                                     // 000000A74788: BFA6FFDD <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi0EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x2000>
	s_or_b32 exec_lo, exec_lo, s3                              // 000000A7478C: 8C7E037E
	s_cmp_lt_i32 s9, 2                                         // 000000A74790: BF048209
	s_mov_b32 s3, -1                                           // 000000A74794: BE8300C1
	s_cbranch_scc1 212                                         // 000000A74798: BFA200D4 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi0EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x23ec>
	s_waitcnt lgkmcnt(0)                                       // 000000A7479C: BF89FC07
	s_barrier                                                  // 000000A747A0: BFBD0000
	buffer_gl0_inv                                             // 000000A747A4: E0AC0000 00000000
	s_and_saveexec_b32 s3, s1                                  // 000000A747AC: BE832001
	s_cbranch_execz 71                                         // 000000A747B0: BFA50047 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi0EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x21d0>
	v_lshrrev_b32_e32 v1, 7, v0                                // 000000A747B4: 32020087
	s_ashr_i32 s29, s28, 31                                    // 000000A747B8: 861D9F1C
	s_ashr_i32 s31, s30, 31                                    // 000000A747BC: 861F9F1E
	s_lshl_b64 s[4:5], s[28:29], 2                             // 000000A747C0: 8484821C
	s_lshl_b32 s6, s10, 7                                      // 000000A747C4: 8406870A
	v_or_b32_e32 v1, s4, v1                                    // 000000A747C8: 38020204
	v_mov_b32_e32 v2, s5                                       // 000000A747CC: 7E040205
	s_lshl_b64 s[4:5], s[30:31], 2                             // 000000A747D0: 8484821E
	s_ashr_i32 s7, s6, 31                                      // 000000A747D4: 86079F06
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000A747D8: BF8700A9
	s_lshl_b64 s[6:7], s[6:7], 2                               // 000000A747DC: 84868206
	.long 0xd7016a01                                           // 000000A747E0: D7016A01
	v_cndmask_b32_e32 v0, v1, v4, vcc_lo                       // 000000A747E4: 02000901
	v_subrev_co_ci_u32_e64 v2, null, s5, v2, vcc_lo            // 000000A747E8: D5227C02 01AA0405
	s_ashr_i32 s5, s49, 31                                     // 000000A747F0: 86059F31
	s_mov_b32 s4, s49                                          // 000000A747F4: BE840031
	.long 0xd72c0004                                           // 000000A747F8: D72C0004
	v_cndmask_b32_e32 v0, v1, v5, vcc_lo                       // 000000A747FC: 02000B01
	.long 0xd72c0003                                           // 000000A74800: D72C0003
	v_cndmask_b32_e32 v0, v2, v49, vcc_lo                      // 000000A74804: 02006302
	v_mad_u64_u32 v[1:2], null, v1, s49, 0                     // 000000A74808: D6FE7C01 02006301
	s_lshl_b64 s[4:5], s[4:5], 3                               // 000000A74810: 84848304
	v_add3_u32 v2, v2, v4, v3                                  // 000000A74814: D6550002 040E0902
	v_and_b32_e32 v3, 0x7f, v0                                 // 000000A7481C: 360600FF 0000007F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A74824: BF870112
	.long 0xd73c0001                                           // 000000A74828: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 000000A7482C: 02020282
	v_lshlrev_b32_e32 v4, 2, v3                                // 000000A74830: 30080682
	v_lshlrev_b32_e32 v3, 2, v0                                // 000000A74834: 30060082
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A74838: BF870093
	.long 0xd7006a01                                           // 000000A7483C: D7006A01
	v_cndmask_b32_e32 v0, v1, v6, vcc_lo                       // 000000A74840: 02000D01
	v_add_co_ci_u32_e64 v2, null, s7, v2, vcc_lo               // 000000A74844: D5207C02 01AA0407
	s_mov_b32 s6, 0                                            // 000000A7484C: BE860080
	.long 0xd7006a01                                           // 000000A74850: D7006A01
	v_cndmask_b32_e32 v1, v1, v4, vcc_lo                       // 000000A74854: 02020901
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000A74858: BF8701A1
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 000000A7485C: D5207C02 01AA0480
	v_or_b32_e32 v4, 0xffffff00, v0                            // 000000A74864: 380800FF FFFFFF00
	.long 0xd7006a01                                           // 000000A7486C: D7006A01
	v_cndmask_b32_e32 v1, s44, v1, vcc_lo                      // 000000A74870: 0202022C
	s_delay_alu instid0(VALU_DEP_1)                            // 000000A74874: BF870001
	v_add_co_ci_u32_e64 v2, null, s45, v2, vcc_lo              // 000000A74878: D5207C02 01AA042D
	ds_load_b32 v5, v3 offset:38400                            // 000000A74880: D8D89600 05000003
	.long 0xd7000704                                           // 000000A74888: D7000704
	v_cndmask_b32_e32 v1, 0x100, v4, vcc_lo                    // 000000A7488C: 020208FF 00000100
	s_xor_b32 s7, s7, -1                                       // 000000A74894: 8D07C107
	v_add_nc_u32_e32 v3, 0x400, v3                             // 000000A74898: 4A0606FF 00000400
	s_and_b32 s7, exec_lo, s7                                  // 000000A748A0: 8B07077E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000A748A4: BF8700C9
	s_or_b32 s6, s7, s6                                        // 000000A748A8: 8C060607
	s_waitcnt lgkmcnt(0)                                       // 000000A748AC: BF89FC07
	global_store_b32 v[1:2], v5, off                           // 000000A748B0: DC6A0000 007C0501
	.long 0xd7006a01                                           // 000000A748B8: D7006A01
	v_cndmask_b32_e32 v0, v1, v4, vcc_lo                       // 000000A748BC: 02000901
	v_add_co_ci_u32_e64 v2, null, s5, v2, vcc_lo               // 000000A748C0: D5207C02 01AA0405
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 000000A748C8: 917E067E
	s_cbranch_execnz 65516                                     // 000000A748CC: BFA6FFEC <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi0EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x2180>
	s_or_b32 exec_lo, exec_lo, s3                              // 000000A748D0: 8C7E037E
	.long 0xd44a0003                                           // 000000A748D4: D44A0003
	v_cndmask_b32_e32 v1, 0, v0, vcc_lo                        // 000000A748D8: 02020080
	s_waitcnt_vscnt null, 0x0                                  // 000000A748DC: BC7C0000
	buffer_gl1_inv                                             // 000000A748E0: E0B00000 00000000
	buffer_gl0_inv                                             // 000000A748E8: E0AC0000 00000000
	s_barrier                                                  // 000000A748F0: BFBD0000
	buffer_gl0_inv                                             // 000000A748F4: E0AC0000 00000000
	s_and_saveexec_b32 s4, s3                                  // 000000A748FC: BE842003
	s_cbranch_execz 29                                         // 000000A74900: BFA5001D <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi0EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x2278>
	s_mov_b32 s6, exec_lo                                      // 000000A74904: BE86007E
	s_mov_b32 s5, exec_lo                                      // 000000A74908: BE85007E
	.long 0xd71f0001                                           // 000000A7490C: D71F0001
	v_cndmask_b32_e32 v0, s6, v128, vcc_lo                     // 000000A74910: 02010006
	s_delay_alu instid0(VALU_DEP_1)                            // 000000A74914: BF870001
	v_cmpx_eq_u32_e32 0, v1                                    // 000000A74918: 7D940280
	s_cbranch_execz 9                                          // 000000A7491C: BFA50009 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi0EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x2244>
	s_lshl_b64 s[24:25], s[10:11], 2                           // 000000A74920: 8498820A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 000000A74924: BF8704B9
	s_add_u32 s24, s46, s24                                    // 000000A74928: 8018182E
	s_addc_u32 s25, s47, s25                                   // 000000A7492C: 8219192F
	s_bcnt1_i32_b32 s6, s6                                     // 000000A74930: BE861806
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v3, s6              // 000000A74934: CA100080 02020006
	global_atomic_add_u32 v2, v2, v3, s[24:25] glc             // 000000A7493C: DCD64000 02180302
	s_or_b32 exec_lo, exec_lo, s5                              // 000000A74944: 8C7E057E
	s_waitcnt vmcnt(0)                                         // 000000A74948: BF8903F7
	v_readfirstlane_b32 s5, v2                                 // 000000A7494C: 7E0A0502
	s_delay_alu instid0(VALU_DEP_1)                            // 000000A74950: BF870001
	v_dual_mov_b32 v2, 0 :: v_dual_add_nc_u32 v1, s5, v1       // 000000A74954: CA200080 02000205
	s_add_i32 s5, s9, -1                                       // 000000A7495C: 8105C109
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 000000A74960: BF870481
	v_cmp_eq_u32_e32 vcc_lo, s5, v1                            // 000000A74964: 7C940205
	v_cndmask_b32_e64 v1, 0, 1, vcc_lo                         // 000000A74968: D5010001 01A90280
	ds_store_b32 v2, v1 offset:42496                           // 000000A74970: D834A600 00000102
	s_or_b32 exec_lo, exec_lo, s4                              // 000000A74978: 8C7E047E
	v_mov_b32_e32 v1, 0                                        // 000000A7497C: 7E020280
	s_waitcnt lgkmcnt(0)                                       // 000000A74980: BF89FC07
	s_barrier                                                  // 000000A74984: BFBD0000
	buffer_gl0_inv                                             // 000000A74988: E0AC0000 00000000
	ds_load_b32 v1, v1 offset:42496                            // 000000A74990: D8D8A600 01000001
	s_waitcnt lgkmcnt(0)                                       // 000000A74998: BF89FC07
	v_cmp_eq_u32_e32 vcc_lo, 0, v1                             // 000000A7499C: 7C940280
	s_cbranch_vccnz 3998                                       // 000000A749A0: BFA40F9E <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi0EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x611c>
	buffer_gl1_inv                                             // 000000A749A4: E0B00000 00000000
	buffer_gl0_inv                                             // 000000A749AC: E0AC0000 00000000
	s_and_saveexec_b32 s8, s1                                  // 000000A749B4: BE882001
	s_cbranch_execz 65                                         // 000000A749B8: BFA50041 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi0EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x23c0>
	v_lshrrev_b32_e32 v1, 7, v0                                // 000000A749BC: 32020087
	s_lshl_b32 s4, s10, 7                                      // 000000A749C0: 8404870A
	v_and_b32_e32 v3, 0x7f, v0                                 // 000000A749C4: 360600FF 0000007F
	s_ashr_i32 s5, s4, 31                                      // 000000A749CC: 86059F04
	v_mov_b32_e32 v5, v0                                       // 000000A749D0: 7E0A0300
	v_mad_i64_i32 v[1:2], null, v1, s49, 0                     // 000000A749D4: D6FF7C01 02006301
	s_lshl_b64 s[4:5], s[4:5], 2                               // 000000A749DC: 84848204
	v_lshlrev_b32_e32 v3, 2, v3                                // 000000A749E0: 30060682
	s_ashr_i32 s7, s49, 31                                     // 000000A749E4: 86079F31
	s_mov_b32 s6, s49                                          // 000000A749E8: BE860031
	s_mov_b32 s24, 0                                           // 000000A749EC: BE980080
	.long 0xd73c0001                                           // 000000A749F0: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 000000A749F4: 02020282
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A749F8: BF870091
	.long 0xd7006a01                                           // 000000A749FC: D7006A01
	v_cndmask_b32_e32 v0, v1, v4, vcc_lo                       // 000000A74A00: 02000901
	v_add_co_ci_u32_e64 v2, null, s5, v2, vcc_lo               // 000000A74A04: D5207C02 01AA0405
	s_lshl_b64 s[4:5], s[6:7], 3                               // 000000A74A0C: 84848306
	.long 0xd7006a01                                           // 000000A74A10: D7006A01
	v_cndmask_b32_e32 v1, v1, v3, vcc_lo                       // 000000A74A14: 02020701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000A74A18: BF8700B1
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 000000A74A1C: D5207C02 01AA0480
	s_lshl_b64 s[6:7], s[6:7], 4                               // 000000A74A24: 84868406
	.long 0xd7006a01                                           // 000000A74A28: D7006A01
	v_cndmask_b32_e32 v1, s44, v1, vcc_lo                      // 000000A74A2C: 0202022C
	v_add_co_ci_u32_e64 v2, null, s45, v2, vcc_lo              // 000000A74A30: D5207C02 01AA042D
	s_nop 0                                                    // 000000A74A38: BF800000
	s_nop 0                                                    // 000000A74A3C: BF800000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000A74A40: BF870001
	v_dual_mov_b32 v4, v2 :: v_dual_mov_b32 v3, v1             // 000000A74A44: CA100102 04020101
	v_mov_b32_e32 v6, 0                                        // 000000A74A4C: 7E0C0280
	s_mov_b32 s1, s9                                           // 000000A74A50: BE810009
	global_load_b32 v7, v[3:4], off glc                        // 000000A74A54: DC524000 077C0003
	.long 0xd7006a03                                           // 000000A74A5C: D7006A03
	v_cndmask_b32_e32 v0, v3, v6, vcc_lo                       // 000000A74A60: 02000D03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000A74A64: BF8704A1
	v_add_co_ci_u32_e64 v4, null, s7, v4, vcc_lo               // 000000A74A68: D5207C04 01AA0807
	s_add_i32 s1, s1, -1                                       // 000000A74A70: 8101C101
	s_cmp_eq_u32 s1, 0                                         // 000000A74A74: BF068001
	s_waitcnt vmcnt(0)                                         // 000000A74A78: BF8903F7
	v_add_f32_e32 v6, v6, v7                                   // 000000A74A7C: 060C0F06
	s_cbranch_scc0 65524                                       // 000000A74A80: BFA1FFF4 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi0EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x2354>
	v_add_nc_u32_e32 v4, 0x100, v5                             // 000000A74A84: 4A080AFF 00000100
	v_cmp_lt_u32_e32 vcc_lo, 0xff, v5                          // 000000A74A8C: 7C920AFF 000000FF
	.long 0xd7000101                                           // 000000A74A94: D7000101
	v_cndmask_b32_e32 v0, v1, v4, vcc_lo                       // 000000A74A98: 02000901
	v_lshlrev_b32_e32 v3, 2, v5                                // 000000A74A9C: 30060A82
	v_add_co_ci_u32_e64 v2, null, s5, v2, s1                   // 000000A74AA0: D5207C02 00060405
	v_mov_b32_e32 v5, v4                                       // 000000A74AA8: 7E0A0304
	s_or_b32 s24, vcc_lo, s24                                  // 000000A74AAC: 8C18186A
	ds_store_b32 v3, v6 offset:38400                           // 000000A74AB0: D8349600 00000603
	s_and_not1_b32 exec_lo, exec_lo, s24                       // 000000A74AB8: 917E187E
	s_cbranch_execnz 65504                                     // 000000A74ABC: BFA6FFE0 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi0EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x2340>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000A74AC0: 8C7E087E
	s_and_saveexec_b32 s1, s3                                  // 000000A74AC4: BE812003
	s_cbranch_execz 6                                          // 000000A74AC8: BFA50006 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi0EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x23e4>
	s_lshl_b64 s[4:5], s[10:11], 2                             // 000000A74ACC: 8484820A
	v_mov_b32_e32 v1, 0                                        // 000000A74AD0: 7E020280
	s_add_u32 s4, s46, s4                                      // 000000A74AD4: 8004042E
	s_addc_u32 s5, s47, s5                                     // 000000A74AD8: 8205052F
	global_store_b32 v1, v1, s[4:5]                            // 000000A74ADC: DC6A0000 00040101
	s_or_b32 exec_lo, exec_lo, s1                              // 000000A74AE4: 8C7E017E
	s_mov_b32 s3, -1                                           // 000000A74AE8: BE8300C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000A74AEC: BF870009
	s_and_b32 vcc_lo, exec_lo, s3                              // 000000A74AF0: 8B6A037E
	s_cbranch_vccz 382                                         // 000000A74AF4: BFA3017E <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi0EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x29f0>
	v_cmp_gt_i32_e32 vcc_lo, s48, v24                          // 000000A74AF8: 7C883030
	.long 0xd44c0001                                           // 000000A74AFC: D44C0001
	v_cndmask_b32_e32 v1, 0x80, v0, vcc_lo                     // 000000A74B00: 020200FF 00000080
	s_waitcnt lgkmcnt(0)                                       // 000000A74B08: BF89FC07
	s_waitcnt_vscnt null, 0x0                                  // 000000A74B0C: BC7C0000
	s_barrier                                                  // 000000A74B10: BFBD0000
	buffer_gl0_inv                                             // 000000A74B14: E0AC0000 00000000
	s_and_b32 s1, vcc_lo, s1                                   // 000000A74B1C: 8B01016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000A74B20: BF870009
	s_and_saveexec_b32 s3, s1                                  // 000000A74B24: BE832001
	s_cbranch_execz 368                                        // 000000A74B28: BFA50170 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi0EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x29ec>
	v_and_b32_e32 v1, 15, v0                                   // 000000A74B2C: 3602008F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A74B30: BF870091
	v_lshlrev_b32_e32 v2, 2, v1                                // 000000A74B34: 30040282
	v_lshl_or_b32 v2, v24, 9, v2                               // 000000A74B38: D6560002 04091318
	s_delay_alu instid0(VALU_DEP_1)                            // 000000A74B40: BF870001
	v_add_nc_u32_e32 v8, 0x9400, v2                            // 000000A74B44: 4A1004FF 00009400
	ds_load_2addr_b32 v[2:3], v8 offset0:128 offset1:144       // 000000A74B4C: D8DC9080 02000008
	ds_load_2addr_b32 v[4:5], v8 offset0:160 offset1:176       // 000000A74B54: D8DCB0A0 04000008
	ds_load_2addr_b32 v[6:7], v8 offset0:192 offset1:208       // 000000A74B5C: D8DCD0C0 06000008
	ds_load_2addr_b32 v[8:9], v8 offset0:224 offset1:240       // 000000A74B64: D8DCF0E0 08000008
	v_and_b32_e32 v10, 1, v0                                   // 000000A74B6C: 36140081
	v_and_b32_e32 v11, 2, v0                                   // 000000A74B70: 36160082
	s_waitcnt lgkmcnt(3)                                       // 000000A74B74: BF89FC37
	v_dual_add_f32 v13, v2, v3 :: v_dual_and_b32 v12, 4, v0    // 000000A74B78: C9240702 0D0C0084
	s_waitcnt lgkmcnt(2)                                       // 000000A74B80: BF89FC27
	v_dual_sub_f32 v2, v2, v3 :: v_dual_add_f32 v3, v4, v5     // 000000A74B84: C9480702 02020B04
	s_waitcnt lgkmcnt(1)                                       // 000000A74B8C: BF89FC17
	v_dual_sub_f32 v4, v4, v5 :: v_dual_add_f32 v5, v6, v7     // 000000A74B90: C9480B04 04040F06
	s_waitcnt lgkmcnt(0)                                       // 000000A74B98: BF89FC07
	v_dual_sub_f32 v6, v6, v7 :: v_dual_add_f32 v7, v8, v9     // 000000A74B9C: C9480F06 06061308
	v_dual_sub_f32 v8, v8, v9 :: v_dual_add_f32 v9, v13, v3    // 000000A74BA4: C9481308 0808070D
	v_sub_f32_e32 v3, v13, v3                                  // 000000A74BAC: 0806070D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000A74BB0: BF870243
	v_dual_add_f32 v13, v2, v4 :: v_dual_add_f32 v14, v5, v7   // 000000A74BB4: C9080902 0D0E0F05
	v_dual_sub_f32 v2, v2, v4 :: v_dual_sub_f32 v5, v5, v7     // 000000A74BBC: C94A0902 02040F05
	v_cmp_eq_u32_e32 vcc_lo, 0, v10                            // 000000A74BC4: 7C941480
	.long 0xd44a0001                                           // 000000A74BC8: D44A0001
	v_cndmask_b32_e32 v1, 0, v12, vcc_lo                       // 000000A74BCC: 02021880
	v_dual_add_f32 v7, v9, v14 :: v_dual_add_f32 v4, v6, v8    // 000000A74BD0: C9081D09 07041106
	v_sub_f32_e32 v6, v6, v8                                   // 000000A74BD8: 080C1106
	v_sub_f32_e32 v8, v9, v14                                  // 000000A74BDC: 08101D09
	s_delay_alu instid0(VALU_DEP_3)                            // 000000A74BE0: BF870003
	v_add_f32_e32 v9, v13, v4                                  // 000000A74BE4: 0612090D
	v_dual_sub_f32 v4, v13, v4 :: v_dual_add_f32 v13, v3, v5   // 000000A74BE8: C948090D 040C0B03
	v_sub_f32_e32 v3, v3, v5                                   // 000000A74BF0: 08060B03
	v_add_f32_e32 v5, v2, v6                                   // 000000A74BF4: 060A0D02
	v_sub_f32_e32 v2, v2, v6                                   // 000000A74BF8: 08040D02
	v_mov_b32_dpp v6, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A74BFC: 7E0C02FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, vcc_lo                      // 000000A74C04: D5010007 21AA0F07
	v_mov_b32_dpp v10, v9 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A74C0C: 7E1402FA FF016109
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 000000A74C14: D5010009 21AA1309
	v_mov_b32_dpp v14, v13 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A74C1C: 7E1C02FA FF01610D
	v_cndmask_b32_e64 v13, -v13, v13, vcc_lo                   // 000000A74C24: D501000D 21AA1B0D
	v_mov_b32_dpp v15, v5 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A74C2C: 7E1E02FA FF016105
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 000000A74C34: D5010005 21AA0B05
	v_mov_b32_dpp v16, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A74C3C: 7E2002FA FF016108
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 000000A74C44: D5010008 21AA1108
	v_mov_b32_dpp v17, v4 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A74C4C: 7E2202FA FF016104
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 000000A74C54: D5010004 21AA0904
	v_mov_b32_dpp v18, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A74C5C: 7E2402FA FF016103
	v_cndmask_b32_e64 v19, -v3, v3, vcc_lo                     // 000000A74C64: D5010013 21AA0703
	v_cndmask_b32_e64 v21, -v2, v2, vcc_lo                     // 000000A74C6C: D5010015 21AA0502
	v_cmp_eq_u32_e32 vcc_lo, 0, v11                            // 000000A74C74: 7C941680
	v_dual_add_f32 v3, v7, v6 :: v_dual_add_f32 v8, v8, v16    // 000000A74C78: C9080D07 03082108
	v_mov_b32_dpp v20, v2 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A74C80: 7E2802FA FF016102
	v_dual_add_f32 v2, v9, v10 :: v_dual_add_f32 v9, v4, v17   // 000000A74C88: C9081509 02082304
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000A74C90: BF870233
	v_mov_b32_dpp v4, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A74C94: 7E0802FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 000000A74C9C: D5010003 21AA0703
	v_add_f32_e32 v6, v13, v14                                 // 000000A74CA4: 060C1D0D
	v_mov_b32_dpp v7, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A74CA8: 7E0E02FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, vcc_lo                      // 000000A74CB0: D5010002 21AA0502
	v_mov_b32_dpp v12, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A74CB8: 7E1802FA FF016208
	v_add_f32_e32 v3, v3, v4                                   // 000000A74CC0: 06060903
	v_mov_b32_dpp v10, v6 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A74CC4: 7E1402FA FF016206
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 000000A74CCC: D5010006 21AA0D06
	v_add_f32_e32 v5, v5, v15                                  // 000000A74CD4: 060A1F05
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 000000A74CD8: D5010008 21AA1108
	v_add_f32_e32 v13, v21, v20                                // 000000A74CE0: 061A2915
	v_mov_b32_dpp v14, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A74CE4: 7E1C02FA FF016209
	v_add_f32_e32 v6, v6, v10                                  // 000000A74CEC: 060C1506
	v_mov_b32_dpp v11, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A74CF0: 7E1602FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 000000A74CF8: D5010005 21AA0B05
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 000000A74D00: D5010009 21AA1309
	v_add_f32_e32 v8, v8, v12                                  // 000000A74D08: 06101908
	v_mov_b32_dpp v15, v13 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A74D0C: 7E1E02FA FF01620D
	v_cndmask_b32_e64 v13, -v13, v13, vcc_lo                   // 000000A74D14: D501000D 21AA1B0D
	v_add_f32_e32 v4, v5, v11                                  // 000000A74D1C: 06081705
	v_mov_b32_dpp v5, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A74D20: 7E0A02FA FF016403
	v_cndmask_b32_e64 v3, -v3, v3, s1                          // 000000A74D28: D5010003 20060703
	v_add_f32_e32 v2, v2, v7                                   // 000000A74D30: 06040F02
	v_mov_b32_dpp v11, v6 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A74D34: 7E1602FA FF016406
	v_cndmask_b32_e64 v6, -v6, v6, s1                          // 000000A74D3C: D5010006 20060D06
	v_add_f32_e32 v9, v9, v14                                  // 000000A74D44: 06121D09
	v_add_f32_e32 v3, v3, v5                                   // 000000A74D48: 06060B03
	v_cndmask_b32_e64 v7, -v2, v2, s1                          // 000000A74D4C: D5010007 20060502
	v_mov_b32_dpp v2, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A74D54: 7E0402FA FF016402
	v_add_f32_e32 v6, v6, v11                                  // 000000A74D5C: 060C1706
	v_mov_b32_dpp v11, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A74D60: 7E1602FA FF016408
	v_cndmask_b32_e64 v14, -v8, v8, s1                         // 000000A74D68: D501000E 20061108
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000A74D70: BF870234
	v_add_f32_e32 v7, v7, v2                                   // 000000A74D74: 060E0507
	v_mov_b32_dpp v10, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A74D78: 7E1402FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s1                          // 000000A74D80: D5010004 20060904
	v_add_f32_e32 v14, v14, v11                                // 000000A74D88: 061C170E
	v_mov_b32_dpp v2, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A74D8C: 7E0402FA FF016803
	v_mov_b32_dpp v5, v7 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A74D94: 7E0A02FA FF016807
	v_mov_b32_dpp v8, v6 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A74D9C: 7E1002FA FF016806
	v_add_f32_e32 v4, v4, v10                                  // 000000A74DA4: 06081504
	v_add_f32_e32 v10, v19, v18                                // 000000A74DA8: 06142513
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000A74DAC: BF8700A1
	v_mov_b32_dpp v12, v10 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A74DB0: 7E1802FA FF01620A
	v_cndmask_b32_e64 v10, -v10, v10, vcc_lo                   // 000000A74DB8: D501000A 21AA150A
	v_add_f32_e32 v10, v10, v12                                // 000000A74DC0: 0614190A
	v_add_f32_e32 v12, v13, v15                                // 000000A74DC4: 06181F0D
	v_mov_b32_dpp v13, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A74DC8: 7E1A02FA FF016409
	v_cndmask_b32_e64 v9, -v9, v9, s1                          // 000000A74DD0: D5010009 20061309
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A74DD8: BF870214
	v_mov_b32_dpp v15, v10 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A74DDC: 7E1E02FA FF01640A
	v_mov_b32_dpp v17, v12 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A74DE4: 7E2202FA FF01640C
	v_cndmask_b32_e64 v10, -v10, v10, s1                       // 000000A74DEC: D501000A 2006150A
	v_cndmask_b32_e64 v12, -v12, v12, s1                       // 000000A74DF4: D501000C 2006190C
	v_add_f32_e32 v16, v9, v13                                 // 000000A74DFC: 06201B09
	v_mov_b32_dpp v9, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A74E00: 7E1202FA FF016804
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A74E08: BF870214
	v_add_f32_e32 v15, v10, v15                                // 000000A74E0C: 061E1F0A
	v_add_f32_e32 v17, v12, v17                                // 000000A74E10: 0622230C
	v_mov_b32_dpp v10, v14 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A74E14: 7E1402FA FF01680E
	v_mov_b32_dpp v11, v16 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A74E1C: 7E1602FA FF016810
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A74E24: BF870214
	v_mov_b32_dpp v12, v15 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A74E28: 7E1802FA FF01680F
	v_mov_b32_dpp v13, v17 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A74E30: 7E1A02FA FF016811
	s_and_b32 exec_lo, exec_lo, s0                             // 000000A74E38: 8B7E007E
	s_cbranch_execz 171                                        // 000000A74E3C: BFA500AB <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi0EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x29ec>
	v_lshl_or_b32 v18, s10, 7, v1                              // 000000A74E40: D6560012 04050E0A
	v_and_b32_e32 v1, 8, v0                                    // 000000A74E48: 36020088
	.long 0x7f2c3880                                           // 000000A74E4C: 7F2C3880
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A74E50: BF870113
	v_ashrrev_i32_e32 v19, 31, v18                             // 000000A74E54: 3426249F
	.long 0x7f363996                                           // 000000A74E58: 7F363996
	.long 0x7f2e3996                                           // 000000A74E5C: 7F2E3996
	.long 0x7f343996                                           // 000000A74E60: 7F343996
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A74E64: BF870094
	.long 0xd73c0012                                           // 000000A74E68: D73C0012
	v_cndmask_b32_e32 v1, 1, v18, vcc_lo                       // 000000A74E6C: 02022481
	.long 0xd7006a14                                           // 000000A74E70: D7006A14
	v_cndmask_b32_e32 v1, s36, v18, vcc_lo                     // 000000A74E74: 02022424
	s_delay_alu instid0(VALU_DEP_1)                            // 000000A74E78: BF870001
	v_add_co_ci_u32_e64 v21, null, s37, v19, vcc_lo            // 000000A74E7C: D5207C15 01AA2625
	v_cmp_eq_u32_e32 vcc_lo, 0, v1                             // 000000A74E84: 7C940280
	s_clause 0x7                                               // 000000A74E88: BF850007
	global_load_d16_b16 v22, v[20:21], off offset:32           // 000000A74E8C: DC820020 167C0014
	global_load_d16_b16 v23, v[20:21], off                     // 000000A74E94: DC820000 177C0014
	global_load_d16_b16 v26, v[20:21], off offset:64           // 000000A74E9C: DC820040 1A7C0014
	global_load_d16_b16 v27, v[20:21], off offset:96           // 000000A74EA4: DC820060 1B7C0014
	global_load_d16_b16 v28, v[20:21], off offset:128          // 000000A74EAC: DC820080 1C7C0014
	global_load_d16_b16 v29, v[20:21], off offset:160          // 000000A74EB4: DC8200A0 1D7C0014
	global_load_d16_b16 v30, v[20:21], off offset:192          // 000000A74EBC: DC8200C0 1E7C0014
	global_load_d16_b16 v31, v[20:21], off offset:224          // 000000A74EC4: DC8200E0 1F7C0014
	v_mad_i64_i32 v[20:21], null, s49, v24, 0                  // 000000A74ECC: D6FF7C14 02023031
	v_cndmask_b32_e64 v1, -v7, v7, vcc_lo                      // 000000A74ED4: D5010001 21AA0F07
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 000000A74EDC: D5010004 21AA0904
	v_cndmask_b32_e64 v14, -v14, v14, vcc_lo                   // 000000A74EE4: D501000E 21AA1D0E
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 000000A74EEC: D5010003 21AA0703
	v_cndmask_b32_e64 v15, -v15, v15, vcc_lo                   // 000000A74EF4: D501000F 21AA1F0F
	v_add_f32_e32 v1, v1, v5                                   // 000000A74EFC: 06020B01
	v_cndmask_b32_e64 v5, -v6, v6, vcc_lo                      // 000000A74F00: D5010005 21AA0D06
	.long 0xd73c0014                                           // 000000A74F08: D73C0014
	v_cndmask_b32_e32 v1, 1, v20, vcc_lo                       // 000000A74F0C: 02022881
	v_cndmask_b32_e64 v6, -v16, v16, vcc_lo                    // 000000A74F10: D5010006 21AA2110
	v_cndmask_b32_e64 v16, -v17, v17, vcc_lo                   // 000000A74F18: D5010010 21AA2311
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000A74F20: BF8700B4
	v_dual_add_f32 v4, v4, v9 :: v_dual_add_f32 v5, v5, v8     // 000000A74F24: C9081304 04041105
	v_add_f32_e32 v8, v14, v10                                 // 000000A74F2C: 0610150E
	.long 0xd7006a11                                           // 000000A74F30: D7006A11
	v_cndmask_b32_e32 v1, s42, v20, vcc_lo                     // 000000A74F34: 0202282A
	v_add_co_ci_u32_e64 v20, null, s43, v21, vcc_lo            // 000000A74F38: D5207C14 01AA2A2B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000A74F40: BF8701C4
	v_dual_mul_f32 v21, 0x3db504f3, v1 :: v_dual_mul_f32 v4, 0x3db504f3, v4// 000000A74F44: C8C602FF 150408FF 3DB504F3
	v_dual_add_f32 v3, v3, v2 :: v_dual_add_f32 v6, v6, v11    // 000000A74F50: C9080503 03061706
	v_dual_add_f32 v9, v15, v12 :: v_dual_add_f32 v10, v16, v13// 000000A74F58: C908190F 090A1B10
	v_mul_f32_e32 v5, 0x3db504f3, v5                           // 000000A74F60: 100A0AFF 3DB504F3
	v_dual_mul_f32 v3, 0x3db504f3, v3 :: v_dual_mul_f32 v8, 0x3db504f3, v8// 000000A74F68: C8C606FF 030810FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A74F74: BF870214
	v_mul_f32_e32 v6, 0x3db504f3, v6                           // 000000A74F78: 100C0CFF 3DB504F3
	v_mul_f32_e32 v10, 0x3db504f3, v10                         // 000000A74F80: 101414FF 3DB504F3
	s_waitcnt vmcnt(7)                                         // 000000A74F88: BF891FF7
	.long 0x7f0e3996                                           // 000000A74F8C: 7F0E3996
	.long 0xd7006a01                                           // 000000A74F90: D7006A01
	v_cndmask_b32_e32 v1, v17, v18, vcc_lo                     // 000000A74F94: 02022511
	s_delay_alu instid0(VALU_DEP_1)                            // 000000A74F98: BF870001
	v_add_co_ci_u32_e64 v2, null, v20, v19, vcc_lo             // 000000A74F9C: D5207C02 01AA2714
	v_fma_mix_f32 v11, v22, v21, neg(0) op_sel_hi:[1,0,0]      // 000000A74FA4: CC20000B 8A022B16
	s_waitcnt vmcnt(6)                                         // 000000A74FAC: BF891BF7
	v_fma_mix_f32 v3, v23, v3, neg(0) op_sel_hi:[1,0,0]        // 000000A74FB0: CC200003 8A020717
	s_waitcnt vmcnt(5)                                         // 000000A74FB8: BF8917F7
	v_fma_mix_f32 v5, v26, v5, neg(0) op_sel_hi:[1,0,0]        // 000000A74FBC: CC200005 8A020B1A
	s_waitcnt vmcnt(4)                                         // 000000A74FC4: BF8913F7
	v_fma_mix_f32 v4, v27, v4, neg(0) op_sel_hi:[1,0,0]        // 000000A74FC8: CC200004 8A02091B
	s_waitcnt vmcnt(3)                                         // 000000A74FD0: BF890FF7
	v_fma_mix_f32 v8, v28, v8, neg(0) op_sel_hi:[1,0,0]        // 000000A74FD4: CC200008 8A02111C
	.long 0x7e2c398b                                           // 000000A74FDC: 7E2C398B
	v_mul_f32_e32 v9, 0x3db504f3, v9                           // 000000A74FE0: 101212FF 3DB504F3
	s_waitcnt vmcnt(2)                                         // 000000A74FE8: BF890BF7
	v_fma_mix_f32 v6, v29, v6, neg(0) op_sel_hi:[1,0,0]        // 000000A74FEC: CC200006 8A020D1D
	s_waitcnt vmcnt(0)                                         // 000000A74FF4: BF8903F7
	v_fma_mix_f32 v10, v31, v10, neg(0) op_sel_hi:[1,0,0]      // 000000A74FF8: CC20000A 8A02151F
	.long 0x7e0e3983                                           // 000000A75000: 7E0E3983
	v_and_b32_e32 v12, 1, v22                                  // 000000A75004: 36182C81
	.long 0x7e2c3984                                           // 000000A75008: 7E2C3984
	v_fma_mix_f32 v9, v30, v9, neg(0) op_sel_hi:[1,0,0]        // 000000A7500C: CC200009 8A02131E
	.long 0x7e2e3985                                           // 000000A75014: 7E2E3985
	.long 0x7e343988                                           // 000000A75018: 7E343988
	v_and_b32_e32 v7, 1, v7                                    // 000000A7501C: 360E0E81
	v_and_b32_e32 v13, 1, v22                                  // 000000A75020: 361A2C81
	.long 0x7e2c3986                                           // 000000A75024: 7E2C3986
	.long 0x7e363989                                           // 000000A75028: 7E363989
	v_and_b32_e32 v14, 1, v23                                  // 000000A7502C: 361C2E81
	v_and_b32_e32 v15, 1, v26                                  // 000000A75030: 361E3481
	v_add3_u32 v3, v3, v7, 0x7fff                              // 000000A75034: D6550003 03FE0F03 00007FFF
	v_and_b32_e32 v16, 1, v22                                  // 000000A75040: 36202C81
	.long 0x7e2c398a                                           // 000000A75044: 7E2C398A
	v_and_b32_e32 v17, 1, v27                                  // 000000A75048: 36223681
	v_add3_u32 v11, v11, v12, 0x7fff                           // 000000A7504C: D655000B 03FE190B 00007FFF
	v_add3_u32 v5, v5, v14, 0x7fff                             // 000000A75058: D6550005 03FE1D05 00007FFF
	v_add3_u32 v4, v4, v13, 0x7fff                             // 000000A75064: D6550004 03FE1B04 00007FFF
	v_and_b32_e32 v7, 1, v22                                   // 000000A75070: 360E2C81
	v_add3_u32 v8, v8, v15, 0x7fff                             // 000000A75074: D6550008 03FE1F08 00007FFF
	v_add3_u32 v9, v9, v17, 0x7fff                             // 000000A75080: D6550009 03FE2309 00007FFF
	v_add3_u32 v6, v6, v16, 0x7fff                             // 000000A7508C: D6550006 03FE2106 00007FFF
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A75098: BF870004
	v_add3_u32 v7, v10, v7, 0x7fff                             // 000000A7509C: D6550007 03FE0F0A 00007FFF
	s_clause 0x7                                               // 000000A750A8: BF850007
	global_store_d16_hi_b16 v[1:2], v3, off                    // 000000A750AC: DC960000 007C0301
	global_store_d16_hi_b16 v[1:2], v11, off offset:32         // 000000A750B4: DC960020 007C0B01
	global_store_d16_hi_b16 v[1:2], v5, off offset:64          // 000000A750BC: DC960040 007C0501
	global_store_d16_hi_b16 v[1:2], v4, off offset:96          // 000000A750C4: DC960060 007C0401
	global_store_d16_hi_b16 v[1:2], v8, off offset:128         // 000000A750CC: DC960080 007C0801
	global_store_d16_hi_b16 v[1:2], v6, off offset:160         // 000000A750D4: DC9600A0 007C0601
	global_store_d16_hi_b16 v[1:2], v9, off offset:192         // 000000A750DC: DC9600C0 007C0901
	global_store_d16_hi_b16 v[1:2], v7, off offset:224         // 000000A750E4: DC9600E0 007C0701
	s_or_b32 exec_lo, exec_lo, s3                              // 000000A750EC: 8C7E037E
	s_mov_b32 s4, 0                                            // 000000A750F0: BE840080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000A750F4: BF870009
	s_and_b32 vcc_lo, exec_lo, s4                              // 000000A750F8: 8B6A047E
	s_cbranch_vccz 3524                                        // 000000A750FC: BFA30DC4 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi0EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x6110>
	s_mul_hi_i32 s0, s2, 0x66666667                            // 000000A75100: 9700FF02 66666667
	v_mov_b32_e32 v1, 0                                        // 000000A75108: 7E020280
	s_lshr_b32 s1, s0, 31                                      // 000000A7510C: 85019F00
	s_ashr_i32 s0, s0, 1                                       // 000000A75110: 86008100
	s_mov_b32 s3, exec_lo                                      // 000000A75114: BE83007E
	s_add_i32 s10, s0, s1                                      // 000000A75118: 810A0100
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000A7511C: BF870499
	s_ashr_i32 s11, s10, 31                                    // 000000A75120: 860B9F0A
	s_lshl_b64 s[0:1], s[10:11], 2                             // 000000A75124: 8480820A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000A75128: BF870009
	s_add_u32 s0, s16, s0                                      // 000000A7512C: 80000010
	s_addc_u32 s1, s17, s1                                     // 000000A75130: 82010111
	global_load_b32 v1, v1, s[0:1]                             // 000000A75134: DC520000 01000001
	s_waitcnt vmcnt(0)                                         // 000000A7513C: BF8903F7
	v_readfirstlane_b32 s1, v1                                 // 000000A75140: 7E020501
	v_cmpx_gt_u32_e32 0x140, v0                                // 000000A75144: 7D9800FF 00000140
	s_cbranch_execz 48                                         // 000000A7514C: BFA50030 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi0EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x2b10>
	s_mul_hi_i32 s0, s2, 0x51eb851f                            // 000000A75150: 9700FF02 51EB851F
	v_lshlrev_b32_e32 v4, 4, v0                                // 000000A75158: 30080084
	s_lshr_b32 s4, s0, 31                                      // 000000A7515C: 85049F00
	s_ashr_i32 s0, s0, 4                                       // 000000A75160: 86008400
	v_or_b32_e32 v3, 0xffffff00, v0                            // 000000A75164: 380600FF FFFFFF00
	s_add_i32 s0, s0, s4                                       // 000000A7516C: 81000400
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000A75170: BF8700D9
	s_mul_i32 s4, s0, 0x1400                                   // 000000A75174: 9604FF00 00001400
	s_mul_hi_i32 s0, s0, 0x1400                                // 000000A7517C: 9700FF00 00001400
	s_add_u32 s4, s14, s4                                      // 000000A75184: 8004040E
	s_addc_u32 s0, s15, s0                                     // 000000A75188: 8200000F
	.long 0xd7000401                                           // 000000A7518C: D7000401
	v_cndmask_b32_e32 v1, s4, v4, vcc_lo                       // 000000A75190: 02020804
	v_add_co_ci_u32_e64 v2, null, s0, 0, s4                    // 000000A75194: D5207C02 00110000
	s_mov_b32 s4, 0                                            // 000000A7519C: BE840080
	s_nop 0                                                    // 000000A751A0: BF800000
	s_nop 0                                                    // 000000A751A4: BF800000
	s_nop 0                                                    // 000000A751A8: BF800000
	s_nop 0                                                    // 000000A751AC: BF800000
	s_nop 0                                                    // 000000A751B0: BF800000
	s_nop 0                                                    // 000000A751B4: BF800000
	s_nop 0                                                    // 000000A751B8: BF800000
	s_nop 0                                                    // 000000A751BC: BF800000
	global_load_b128 v[5:8], v[1:2], off                       // 000000A751C0: DC5E0000 057C0001
	v_add_nc_u32_e32 v3, 0x100, v3                             // 000000A751C8: 4A0606FF 00000100
	.long 0xd7006a01                                           // 000000A751D0: D7006A01
	v_cndmask_b32_e32 v1, 0x1000, v1, vcc_lo                   // 000000A751D4: 020202FF 00001000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A751DC: BF870191
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 000000A751E0: D5207C02 01AA0480
	.long 0xd4490000                                           // 000000A751E8: D4490000
	v_cndmask_b32_e32 v1, 63, v3, vcc_lo                       // 000000A751EC: 020206BF
	s_or_b32 s4, s0, s4                                        // 000000A751F0: 8C040400
	s_waitcnt vmcnt(0)                                         // 000000A751F4: BF8903F7
	ds_store_b128 v4, v[5:8]                                   // 000000A751F8: DB7C0000 00000504
	v_add_nc_u32_e32 v4, 0x1000, v4                            // 000000A75200: 4A0808FF 00001000
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000A75208: 917E047E
	s_cbranch_execnz 65516                                     // 000000A7520C: BFA6FFEC <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi0EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x2ac0>
	s_or_b32 exec_lo, exec_lo, s3                              // 000000A75210: 8C7E037E
	v_mul_u32_u24_e32 v18, 20, v24                             // 000000A75214: 16243094
	v_dual_mov_b32 v1, 0 :: v_dual_lshlrev_b32 v26, 2, v25     // 000000A75218: CA220080 011A3282
	s_mul_i32 s0, s10, -5                                      // 000000A75220: 9600C50A
	s_mul_hi_i32 s4, s1, 0x190000                              // 000000A75224: 9704FF01 00190000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A7522C: BF870112
	v_min_u32_e32 v19, 0x8c, v18                               // 000000A75230: 262624FF 0000008C
	v_mov_b32_e32 v16, v1                                      // 000000A75238: 7E200301
	v_mov_b32_e32 v2, v1                                       // 000000A7523C: 7E040301
	v_mov_b32_e32 v3, v1                                       // 000000A75240: 7E060301
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A75244: BF870004
	v_dual_mov_b32 v4, v1 :: v_dual_add_nc_u32 v27, 20, v19    // 000000A75248: CA200101 041A2694
	v_mov_b32_e32 v5, v1                                       // 000000A75250: 7E0A0301
	v_mov_b32_e32 v6, v1                                       // 000000A75254: 7E0C0301
	v_mov_b32_e32 v7, v1                                       // 000000A75258: 7E0E0301
	v_mov_b32_e32 v8, v1                                       // 000000A7525C: 7E100301
	v_mov_b32_e32 v9, v1                                       // 000000A75260: 7E120301
	v_mov_b32_e32 v10, v1                                      // 000000A75264: 7E140301
	v_mov_b32_e32 v11, v1                                      // 000000A75268: 7E160301
	v_mov_b32_e32 v12, v1                                      // 000000A7526C: 7E180301
	v_mov_b32_e32 v13, v1                                      // 000000A75270: 7E1A0301
	v_mov_b32_e32 v14, v1                                      // 000000A75274: 7E1C0301
	v_mov_b32_e32 v15, v1                                      // 000000A75278: 7E1E0301
	v_mov_b32_e32 v17, v16                                     // 000000A7527C: 7E220310
	v_cmp_lt_u32_e32 vcc_lo, v18, v27                          // 000000A75280: 7C923712
	s_delay_alu instid0(VALU_DEP_3)                            // 000000A75284: BF870003
	v_mov_b32_e32 v16, v15                                     // 000000A75288: 7E20030F
	v_mov_b32_e32 v15, v14                                     // 000000A7528C: 7E1E030E
	v_mov_b32_e32 v14, v13                                     // 000000A75290: 7E1C030D
	v_mov_b32_e32 v13, v12                                     // 000000A75294: 7E1A030C
	v_mov_b32_e32 v12, v11                                     // 000000A75298: 7E18030B
	v_mov_b32_e32 v11, v10                                     // 000000A7529C: 7E16030A
	v_mov_b32_e32 v10, v9                                      // 000000A752A0: 7E140309
	v_mov_b32_e32 v9, v8                                       // 000000A752A4: 7E120308
	v_mov_b32_e32 v8, v7                                       // 000000A752A8: 7E100307
	v_mov_b32_e32 v7, v6                                       // 000000A752AC: 7E0E0306
	v_mov_b32_e32 v6, v5                                       // 000000A752B0: 7E0C0305
	v_mov_b32_e32 v5, v4                                       // 000000A752B4: 7E0A0304
	v_mov_b32_e32 v4, v3                                       // 000000A752B8: 7E080303
	v_mov_b32_e32 v3, v2                                       // 000000A752BC: 7E060302
	v_mov_b32_e32 v2, v1                                       // 000000A752C0: 7E040301
	s_add_i32 s2, s0, s2                                       // 000000A752C4: 81020200
	s_mul_i32 s6, s1, 0x190000                                 // 000000A752C8: 9606FF01 00190000
	s_mul_hi_i32 s5, s2, 0x50000                               // 000000A752D0: 9705FF02 00050000
	s_mul_i32 s7, s2, 0x50000                                  // 000000A752D8: 9607FF02 00050000
	s_waitcnt lgkmcnt(0)                                       // 000000A752E0: BF89FC07
	s_waitcnt_vscnt null, 0x0                                  // 000000A752E4: BC7C0000
	s_barrier                                                  // 000000A752E8: BFBD0000
	buffer_gl0_inv                                             // 000000A752EC: E0AC0000 00000000
	s_and_saveexec_b32 s3, vcc_lo                              // 000000A752F4: BE83206A
	s_cbranch_execz 49                                         // 000000A752F8: BFA50031 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi0EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x2cc0>
	v_mul_u32_u24_e32 v2, 0xa000, v24                          // 000000A752FC: 160430FF 0000A000
	s_add_u32 s0, s12, s6                                      // 000000A75304: 8000060C
	s_addc_u32 s8, s13, s4                                     // 000000A75308: 8208040D
	s_add_u32 s0, s0, s7                                       // 000000A7530C: 80000700
	s_addc_u32 s8, s8, s5                                      // 000000A75310: 82080508
	.long 0xd7000002                                           // 000000A75314: D7000002
	v_cndmask_b32_e32 v1, s0, v2, vcc_lo                       // 000000A75318: 02020400
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A7531C: BF870111
	v_add_co_ci_u32_e64 v3, null, s8, 0, s0                    // 000000A75320: D5207C03 00010008
	.long 0xd7000014                                           // 000000A75328: D7000014
	v_cndmask_b32_e32 v1, v2, v26, vcc_lo                      // 000000A7532C: 02023502
	s_delay_alu instid0(VALU_DEP_1)                            // 000000A75330: BF870001
	v_add_co_ci_u32_e64 v21, null, 0, v3, s0                   // 000000A75334: D5207C15 00020680
	s_clause 0xf                                               // 000000A7533C: BF85000F
	global_load_b32 v2, v[20:21], off                          // 000000A75340: DC520000 027C0014
	global_load_b32 v3, v[20:21], off offset:128               // 000000A75348: DC520080 037C0014
	global_load_b32 v4, v[20:21], off offset:256               // 000000A75350: DC520100 047C0014
	global_load_b32 v5, v[20:21], off offset:384               // 000000A75358: DC520180 057C0014
	global_load_b32 v6, v[20:21], off offset:512               // 000000A75360: DC520200 067C0014
	global_load_b32 v7, v[20:21], off offset:640               // 000000A75368: DC520280 077C0014
	global_load_b32 v8, v[20:21], off offset:768               // 000000A75370: DC520300 087C0014
	global_load_b32 v9, v[20:21], off offset:896               // 000000A75378: DC520380 097C0014
	global_load_b32 v10, v[20:21], off offset:1024             // 000000A75380: DC520400 0A7C0014
	global_load_b32 v11, v[20:21], off offset:1152             // 000000A75388: DC520480 0B7C0014
	global_load_b32 v12, v[20:21], off offset:1280             // 000000A75390: DC520500 0C7C0014
	global_load_b32 v13, v[20:21], off offset:1408             // 000000A75398: DC520580 0D7C0014
	global_load_b32 v14, v[20:21], off offset:1536             // 000000A753A0: DC520600 0E7C0014
	global_load_b32 v15, v[20:21], off offset:1664             // 000000A753A8: DC520680 0F7C0014
	global_load_b32 v16, v[20:21], off offset:1792             // 000000A753B0: DC520700 107C0014
	global_load_b32 v17, v[20:21], off offset:1920             // 000000A753B8: DC520780 117C0014
	s_or_b32 exec_lo, exec_lo, s3                              // 000000A753C0: 8C7E037E
	v_dual_mov_b32 v29, 0 :: v_dual_mov_b32 v30, 0             // 000000A753C4: CA100080 1D1E0080
	v_dual_mov_b32 v31, 0 :: v_dual_mov_b32 v32, 0             // 000000A753CC: CA100080 1F200080
	v_dual_mov_b32 v33, 0 :: v_dual_mov_b32 v34, 0             // 000000A753D4: CA100080 21220080
	v_dual_mov_b32 v35, 0 :: v_dual_mov_b32 v36, 0             // 000000A753DC: CA100080 23240080
	v_dual_mov_b32 v37, 0 :: v_dual_mov_b32 v38, 0             // 000000A753E4: CA100080 25260080
	v_dual_mov_b32 v39, 0 :: v_dual_mov_b32 v40, 0             // 000000A753EC: CA100080 27280080
	v_dual_mov_b32 v41, 0 :: v_dual_mov_b32 v42, 0             // 000000A753F4: CA100080 292A0080
	v_mov_b32_e32 v28, 0                                       // 000000A753FC: 7E380280
	s_and_saveexec_b32 s3, vcc_lo                              // 000000A75400: BE83206A
	s_cbranch_execz 1871                                       // 000000A75404: BFA5074F <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi0EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x4a44>
	v_dual_mov_b32 v28, 0 :: v_dual_lshlrev_b32 v1, 5, v25     // 000000A75408: CA220080 1C003285
	v_cmp_ne_u32_e32 vcc_lo, 0, v25                            // 000000A75410: 7C9A3280
	v_dual_mov_b32 v39, 0 :: v_dual_lshlrev_b32 v30, 11, v18   // 000000A75414: CA220080 271E248B
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000A7541C: BF870143
	v_dual_mov_b32 v41, 0 :: v_dual_add_nc_u32 v20, 0x3f0, v1  // 000000A75420: CA200080 291402FF 000003F0
	s_add_u32 s0, s6, s7                                       // 000000A7542C: 80000706
	s_addc_u32 s4, s4, s5                                      // 000000A75430: 82040504
	v_mul_u32_u24_e32 v21, 0x840, v24                          // 000000A75434: 162A30FF 00000840
	v_lshrrev_b32_e32 v22, 5, v20                              // 000000A7543C: 322C2885
	v_dual_mov_b32 v37, 0 :: v_dual_and_b32 v20, 0x7e0, v20    // 000000A75440: CA240080 251428FF 000007E0
	v_mad_u32_u24 v29, 0x840, v24, v26                         // 000000A7544C: D60B001D 046A30FF 00000840
	v_sub_nc_u32_e32 v45, 0, v19                               // 000000A75458: 4C5A2680
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A7545C: BF870004
	v_subrev_nc_u32_e32 v22, 32, v22                           // 000000A75460: 4E2C2CA0
	v_and_b32_e32 v23, 16, v0                                  // 000000A75464: 362E0090
	v_sub_nc_u32_e32 v1, v20, v1                               // 000000A75468: 4C020314
	v_add_nc_u32_e32 v46, 1, v18                               // 000000A7546C: 4A5C2481
	v_dual_mov_b32 v40, 0 :: v_dual_add_nc_u32 v47, 0x1400, v29// 000000A75470: CA200080 282E3AFF 00001400
	v_cndmask_b32_e32 v22, 31, v22, vcc_lo                     // 000000A7547C: 022C2C9F
	v_lshl_or_b32 v43, v18, 5, v23                             // 000000A75480: D656002B 045D0B12
	.long 0xd7000017                                           // 000000A75488: D7000017
	v_cndmask_b32_e32 v1, s0, v30, vcc_lo                      // 000000A7548C: 02023C00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A75490: BF870211
	v_add_co_ci_u32_e64 v30, null, s4, 0, s0                   // 000000A75494: D5207C1E 00010004
	v_dual_mov_b32 v42, 0 :: v_dual_add_nc_u32 v31, 1, v22     // 000000A7549C: CA200080 2A1E2C81
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A754A4: BF870093
	.long 0xd7006a17                                           // 000000A754A8: D7006A17
	v_cndmask_b32_e32 v1, v23, v26, vcc_lo                     // 000000A754AC: 02023517
	v_add_co_ci_u32_e64 v30, null, 0, v30, vcc_lo              // 000000A754B0: D5207C1E 01AA3C80
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A754B8: BF870193
	v_dual_mov_b32 v35, 0 :: v_dual_and_b32 v20, 31, v31       // 000000A754BC: CA240080 23143E9F
	.long 0xd7006a17                                           // 000000A754C4: D7006A17
	v_cndmask_b32_e32 v1, s12, v23, vcc_lo                     // 000000A754C8: 02022E0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000A754CC: BF8700D1
	v_add_co_ci_u32_e64 v30, null, s13, v30, vcc_lo            // 000000A754D0: D5207C1E 01AA3C0D
	v_dual_mov_b32 v33, 0 :: v_dual_add_nc_u32 v44, 0xfffffc30, v1// 000000A754D8: CA200080 212C02FF FFFFFC30
	v_lshl_add_u32 v1, v22, 2, v21                             // 000000A754E4: D6460001 04550516
	v_lshl_add_u32 v20, v20, 2, v21                            // 000000A754EC: D6460014 04550514
	.long 0xd7006a16                                           // 000000A754F4: D7006A16
	v_cndmask_b32_e32 v1, 0x800, v23, vcc_lo                   // 000000A754F8: 02022EFF 00000800
	v_add_co_ci_u32_e64 v23, null, 0, v30, vcc_lo              // 000000A75500: D5207C17 01AA3C80
	v_dual_mov_b32 v29, 0 :: v_dual_add_nc_u32 v48, 0x1800, v29// 000000A75508: CA200080 1D303AFF 00001800
	v_dual_mov_b32 v38, 0 :: v_dual_add_nc_u32 v49, 0x1400, v1 // 000000A75514: CA200080 263002FF 00001400
	v_add_nc_u32_e32 v50, 0x1400, v20                          // 000000A75520: 4A6428FF 00001400
	v_dual_mov_b32 v36, 0 :: v_dual_add_nc_u32 v51, 0x1800, v1 // 000000A75528: CA200080 243202FF 00001800
	v_add_nc_u32_e32 v52, 0x1800, v20                          // 000000A75534: 4A6828FF 00001800
	v_mov_b32_e32 v34, 0                                       // 000000A7553C: 7E440280
	v_dual_mov_b32 v32, 0 :: v_dual_mov_b32 v31, 0             // 000000A75540: CA100080 201E0080
	v_dual_mov_b32 v30, 0 :: v_dual_mov_b32 v1, 0              // 000000A75548: CA100080 1E000080
	s_mov_b32 s4, 0                                            // 000000A75550: BE840080
	s_movk_i32 s5, 0x1eee                                      // 000000A75554: B0051EEE
	s_branch 1723                                              // 000000A75558: BFA006BB <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi0EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x4948>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000A7555C: 8C7E007E
	ds_load_2addr_b32 v[53:54], v50 offset1:32                 // 000000A75560: D8DC2000 35000032
	ds_load_2addr_b32 v[63:64], v47 offset1:32                 // 000000A75568: D8DC2000 3F00002F
	ds_load_2addr_b32 v[57:58], v49 offset1:32                 // 000000A75570: D8DC2000 39000031
	ds_load_b128 v[18:21], v43                                 // 000000A75578: DBFC0000 1200002B
	ds_load_2addr_b32 v[59:60], v49 offset0:64 offset1:96      // 000000A75580: D8DC6040 3B000031
	ds_load_2addr_b32 v[61:62], v50 offset0:64 offset1:96      // 000000A75588: D8DC6040 3D000032
	.long 0xd7000016                                           // 000000A75590: D7000016
	v_cndmask_b32_e32 v1, 0x800, v22, vcc_lo                   // 000000A75594: 02022CFF 00000800
	v_add_nc_u32_e32 v43, 32, v43                              // 000000A7559C: 4A5656A0
	v_add_co_ci_u32_e64 v23, null, 0, v23, s0                  // 000000A755A0: D5207C17 00022E80
	s_waitcnt lgkmcnt(5)                                       // 000000A755A8: BF89FC57
	v_mov_b32_e32 v56, v53                                     // 000000A755AC: 7E700335
	s_waitcnt lgkmcnt(4)                                       // 000000A755B0: BF89FC47
	v_bfe_u32 v53, v63, 12, 16                                 // 000000A755B4: D6100035 0241193F
	v_bfe_u32 v65, v63, 8, 16                                  // 000000A755BC: D6100041 0241113F
	v_bfe_u32 v66, v63, 4, 16                                  // 000000A755C4: D6100042 0241093F
	v_and_b32_e32 v63, 0xffff, v63                             // 000000A755CC: 367E7EFF 0000FFFF
	s_waitcnt lgkmcnt(3)                                       // 000000A755D4: BF89FC37
	.long 0xd73d0038                                           // 000000A755D8: D73D0038
	v_cndmask_b32_e32 v1, v44, v56, vcc_lo                     // 000000A755DC: 0202712C
	v_mov_b32_e32 v55, v58                                     // 000000A755E0: 7E6E033A
	v_bfe_u32 v58, v64, 12, 16                                 // 000000A755E4: D610003A 02411940
	v_bfe_u32 v67, v64, 8, 16                                  // 000000A755EC: D6100043 02411140
	v_bfe_u32 v68, v64, 4, 16                                  // 000000A755F4: D6100044 02410940
	v_and_b32_e32 v64, 0xffff, v64                             // 000000A755FC: 368080FF 0000FFFF
	.long 0xd72c0039                                           // 000000A75604: D72C0039
	v_cndmask_b32_e32 v1, 0x83dcd12d, v53, vcc_lo              // 000000A75608: 02026AFF 83DCD12D
	.long 0xd73d0035                                           // 000000A75610: D73D0035
	v_cndmask_b32_e32 v1, v44, v54, vcc_lo                     // 000000A75614: 02026D2C
	v_bfe_u32 v55, v56, 12, 16                                 // 000000A75618: D6100037 02411938
	.long 0xd72c0036                                           // 000000A75620: D72C0036
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 000000A75624: 020274FF 83DCD12D
	v_bfe_u32 v58, v56, 8, 16                                  // 000000A7562C: D610003A 02411138
	v_bfe_u32 v69, v56, 4, 16                                  // 000000A75634: D6100045 02410938
	v_and_b32_e32 v56, 0xffff, v56                             // 000000A7563C: 367070FF 0000FFFF
	.long 0xd72c0037                                           // 000000A75644: D72C0037
	v_cndmask_b32_e32 v1, 0x83dcd12d, v55, vcc_lo              // 000000A75648: 02026EFF 83DCD12D
	.long 0xd72c0041                                           // 000000A75650: D72C0041
	v_cndmask_b32_e32 v1, 0x83dcd12d, v65, vcc_lo              // 000000A75654: 020282FF 83DCD12D
	.long 0xd72c003a                                           // 000000A7565C: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 000000A75660: 020274FF 83DCD12D
	v_sad_u8 v57, v57, 0, 0x6400                               // 000000A75668: D6220039 03FD0139 00006400
	.long 0xd72c0038                                           // 000000A75674: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v56, vcc_lo              // 000000A75678: 020270FF 83DCD12D
	.long 0xd72c0045                                           // 000000A75680: D72C0045
	v_cndmask_b32_e32 v1, 0x83dcd12d, v69, vcc_lo              // 000000A75684: 02028AFF 83DCD12D
	v_bfe_u32 v70, v53, 12, 16                                 // 000000A7568C: D6100046 02411935
	v_bfe_u32 v71, v53, 8, 16                                  // 000000A75694: D6100047 02411135
	v_sad_u8 v55, v55, 0, 0x6400                               // 000000A7569C: D6220037 03FD0137 00006400
	v_bfe_u32 v72, v53, 4, 16                                  // 000000A756A8: D6100048 02410935
	v_sad_u8 v58, v58, 0, 0x6400                               // 000000A756B0: D622003A 03FD013A 00006400
	v_sad_u8 v65, v65, 0, 0x6400                               // 000000A756BC: D6220041 03FD0141 00006400
	v_sad_u8 v56, v56, 0, 0x6400                               // 000000A756C8: D6220038 03FD0138 00006400
	v_and_b32_e32 v55, 0xffff, v55                             // 000000A756D4: 366E6EFF 0000FFFF
	.long 0xd72c003f                                           // 000000A756DC: D72C003F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v63, vcc_lo              // 000000A756E0: 02027EFF 83DCD12D
	.long 0xd72c0042                                           // 000000A756E8: D72C0042
	v_cndmask_b32_e32 v1, 0x83dcd12d, v66, vcc_lo              // 000000A756EC: 020284FF 83DCD12D
	.long 0xd72c0046                                           // 000000A756F4: D72C0046
	v_cndmask_b32_e32 v1, 0x83dcd12d, v70, vcc_lo              // 000000A756F8: 02028CFF 83DCD12D
	v_lshlrev_b32_e32 v56, 16, v56                             // 000000A75700: 30707090
	v_lshl_or_b32 v55, v58, 16, v55                            // 000000A75704: D6560037 04DD213A
	.long 0xd72c0047                                           // 000000A7570C: D72C0047
	v_cndmask_b32_e32 v1, 0x83dcd12d, v71, vcc_lo              // 000000A75710: 02028EFF 83DCD12D
	.long 0xd72c0043                                           // 000000A75718: D72C0043
	v_cndmask_b32_e32 v1, 0x83dcd12d, v67, vcc_lo              // 000000A7571C: 020286FF 83DCD12D
	v_sad_u8 v54, v54, 0, 0x6400                               // 000000A75724: D6220036 03FD0136 00006400
	v_sad_u8 v63, v63, 0, 0x6400                               // 000000A75730: D622003F 03FD013F 00006400
	v_pk_fma_f16 v55, v55, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A7573C: CC0E0037 0BFC0B37 0000C931
	v_and_b32_e32 v53, 0xffff, v53                             // 000000A75748: 366A6AFF 0000FFFF
	v_sad_u8 v66, v66, 0, 0x6400                               // 000000A75750: D6220042 03FD0142 00006400
	.long 0xd72c0048                                           // 000000A7575C: D72C0048
	v_cndmask_b32_e32 v1, 0x83dcd12d, v72, vcc_lo              // 000000A75760: 020290FF 83DCD12D
	.long 0xd72c0040                                           // 000000A75768: D72C0040
	v_cndmask_b32_e32 v1, 0x83dcd12d, v64, vcc_lo              // 000000A7576C: 020280FF 83DCD12D
	s_waitcnt lgkmcnt(2)                                       // 000000A75774: BF89FC27
	v_dual_dot2acc_f32_f16 v28, v55, v18 :: v_dual_and_b32 v57, 0xffff, v57// 000000A75778: CB242537 1C3872FF 0000FFFF
	.long 0xd72c0035                                           // 000000A75784: D72C0035
	v_cndmask_b32_e32 v1, 0x83dcd12d, v53, vcc_lo              // 000000A75788: 02026AFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000A75790: BF8701A2
	v_lshl_or_b32 v57, v65, 16, v57                            // 000000A75794: D6560039 04E52141
	v_sad_u8 v65, v69, 0, 0x6400                               // 000000A7579C: D6220041 03FD0145 00006400
	v_sad_u8 v53, v53, 0, 0x6400                               // 000000A757A8: D6220035 03FD0135 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A757B4: BF870193
	v_pk_fma_f16 v69, v57, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A757B8: CC0E0045 0BFC0B39 0000C931
	v_and_or_b32 v56, 0xffff, v65, v56                         // 000000A757C4: D6570038 04E282FF 0000FFFF
	v_sad_u8 v65, v72, 0, 0x6400                               // 000000A757D0: D6220041 03FD0148 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A757DC: BF870092
	v_pk_fma_f16 v56, v56, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A757E0: CC0E0038 0BFC0B38 0000C931
	v_dot2acc_f32_f16 v28, v56, v19                            // 000000A757EC: 04382738
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A757F0: BF870091
	v_dual_dot2acc_f32_f16 v28, v69, v20 :: v_dual_lshlrev_b32 v63, 16, v63// 000000A757F4: CB222945 1C3E7E90
	v_and_or_b32 v58, 0xffff, v66, v63                         // 000000A757FC: D657003A 04FE84FF 0000FFFF
	v_sad_u8 v63, v70, 0, 0x6400                               // 000000A75808: D622003F 03FD0146 00006400
	v_sad_u8 v66, v71, 0, 0x6400                               // 000000A75814: D6220042 03FD0147 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000A75820: BF8701A3
	v_pk_fma_f16 v70, v58, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A75824: CC0E0046 0BFC0B3A 0000C931
	s_waitcnt lgkmcnt(0)                                       // 000000A75830: BF89FC07
	v_dual_mov_b32 v58, v61 :: v_dual_and_b32 v63, 0xffff, v63 // 000000A75834: CA24013D 3A3E7EFF 0000FFFF
	v_sad_u8 v61, v67, 0, 0x6400                               // 000000A75840: D622003D 03FD0143 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A7584C: BF870193
	v_dot2acc_f32_f16 v28, v70, v21                            // 000000A75850: 04382B46
	v_lshl_or_b32 v63, v66, 16, v63                            // 000000A75854: D656003F 04FD2142
	v_and_b32_e32 v66, 0xffff, v54                             // 000000A7585C: 36846CFF 0000FFFF
	.long 0xd73d0038                                           // 000000A75864: D73D0038
	v_cndmask_b32_e32 v1, v44, v58, vcc_lo                     // 000000A75868: 0202752C
	v_sad_u8 v59, v64, 0, 0x6400                               // 000000A7586C: D622003B 03FD0140 00006400
	ds_load_2addr_b32 v[54:55], v47 offset0:64 offset1:96      // 000000A75878: D8DC6040 3600002F
	v_pk_fma_f16 v58, v63, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A75880: CC0E003A 0BFC0B3F 0000C931
	v_lshl_or_b32 v57, v61, 16, v66                            // 000000A7588C: D6560039 0509213D
	v_bfe_u32 v61, v56, 12, 16                                 // 000000A75894: D610003D 02411938
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A7589C: BF870193
	v_dual_dot2acc_f32_f16 v42, v58, v18 :: v_dual_lshlrev_b32 v59, 16, v59// 000000A758A0: CB22253A 2A3A7690
	v_pk_fma_f16 v64, v57, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A758A8: CC0E0040 0BFC0B39 0000C931
	v_lshlrev_b32_e32 v53, 16, v53                             // 000000A758B4: 306A6A90
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A758B8: BF870114
	.long 0xd72c003d                                           // 000000A758BC: D72C003D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v61, vcc_lo              // 000000A758C0: 02027AFF 83DCD12D
	v_and_or_b32 v53, 0xffff, v65, v53                         // 000000A758C8: D6570035 04D682FF 0000FFFF
	.long 0xd72c0041                                           // 000000A758D4: D72C0041
	v_cndmask_b32_e32 v1, 0x83dcd12d, v68, vcc_lo              // 000000A758D8: 020288FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A758E0: BF870193
	v_sad_u8 v61, v61, 0, 0x6400                               // 000000A758E4: D622003D 03FD013D 00006400
	v_pk_fma_f16 v53, v53, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A758F0: CC0E0035 0BFC0B35 0000C931
	v_and_b32_e32 v63, 0xffff, v56                             // 000000A758FC: 367E70FF 0000FFFF
	s_waitcnt lgkmcnt(0)                                       // 000000A75904: BF89FC07
	v_bfe_u32 v66, v54, 12, 16                                 // 000000A75908: D6100042 02411936
	v_bfe_u32 v67, v54, 8, 16                                  // 000000A75910: D6100043 02411136
	v_sad_u8 v57, v65, 0, 0x6400                               // 000000A75918: D6220039 03FD0141 00006400
	v_bfe_u32 v65, v56, 8, 16                                  // 000000A75924: D6100041 02411138
	v_and_b32_e32 v61, 0xffff, v61                             // 000000A7592C: 367A7AFF 0000FFFF
	v_bfe_u32 v56, v56, 4, 16                                  // 000000A75934: D6100038 02410938
	v_dot2acc_f32_f16 v42, v53, v19                            // 000000A7593C: 04542735
	.long 0xd72c003f                                           // 000000A75940: D72C003F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v63, vcc_lo              // 000000A75944: 02027EFF 83DCD12D
	.long 0xd72c0041                                           // 000000A7594C: D72C0041
	v_cndmask_b32_e32 v1, 0x83dcd12d, v65, vcc_lo              // 000000A75950: 020282FF 83DCD12D
	v_and_or_b32 v57, 0xffff, v57, v59                         // 000000A75958: D6570039 04EE72FF 0000FFFF
	.long 0xd72c0038                                           // 000000A75964: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v56, vcc_lo              // 000000A75968: 020270FF 83DCD12D
	.long 0xd72c0042                                           // 000000A75970: D72C0042
	v_cndmask_b32_e32 v1, 0x83dcd12d, v66, vcc_lo              // 000000A75974: 020284FF 83DCD12D
	.long 0xd72c0043                                           // 000000A7597C: D72C0043
	v_cndmask_b32_e32 v1, 0x83dcd12d, v67, vcc_lo              // 000000A75980: 020286FF 83DCD12D
	v_dot2acc_f32_f16 v42, v64, v20                            // 000000A75988: 04542940
	v_bfe_u32 v68, v54, 4, 16                                  // 000000A7598C: D6100044 02410936
	v_sad_u8 v63, v63, 0, 0x6400                               // 000000A75994: D622003F 03FD013F 00006400
	v_sad_u8 v65, v65, 0, 0x6400                               // 000000A759A0: D6220041 03FD0141 00006400
	v_sad_u8 v56, v56, 0, 0x6400                               // 000000A759AC: D6220038 03FD0138 00006400
	v_sad_u8 v66, v66, 0, 0x6400                               // 000000A759B8: D6220042 03FD0142 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000A759C4: BF8701B3
	v_lshl_or_b32 v59, v65, 16, v61                            // 000000A759C8: D656003B 04F52141
	v_sad_u8 v65, v67, 0, 0x6400                               // 000000A759D0: D6220041 03FD0143 00006400
	.long 0xd72c003d                                           // 000000A759DC: D72C003D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v68, vcc_lo              // 000000A759E0: 020288FF 83DCD12D
	v_pk_fma_f16 v58, v59, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A759E8: CC0E003A 0BFC0B3B 0000C931
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000A759F4: BF8701C1
	v_dot2acc_f32_f16 v41, v58, v18                            // 000000A759F8: 0452253A
	v_pk_fma_f16 v58, v57, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A759FC: CC0E003A 0BFC0B39 0000C931
	v_lshlrev_b32_e32 v63, 16, v63                             // 000000A75A08: 307E7E90
	v_sad_u8 v61, v61, 0, 0x6400                               // 000000A75A0C: D622003D 03FD013D 00006400
	v_dot2acc_f32_f16 v42, v58, v21                            // 000000A75A18: 04542B3A
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000A75A1C: BF870123
	v_and_or_b32 v56, 0xffff, v56, v63                         // 000000A75A20: D6570038 04FE70FF 0000FFFF
	v_and_b32_e32 v63, 0xffff, v66                             // 000000A75A2C: 367E84FF 0000FFFF
	v_pk_fma_f16 v56, v56, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A75A34: CC0E0038 0BFC0B38 0000C931
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000A75A40: BF8701A2
	v_lshl_or_b32 v59, v65, 16, v63                            // 000000A75A44: D656003B 04FD2141
	v_mov_b32_e32 v63, v60                                     // 000000A75A4C: 7E7E033C
	v_dot2acc_f32_f16 v41, v56, v19                            // 000000A75A50: 04522738
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000A75A54: BF870223
	v_pk_fma_f16 v53, v59, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A75A58: CC0E0035 0BFC0B3B 0000C931
	v_and_b32_e32 v54, 0xffff, v54                             // 000000A75A64: 366C6CFF 0000FFFF
	.long 0xd73d0038                                           // 000000A75A6C: D73D0038
	v_cndmask_b32_e32 v1, v44, v62, vcc_lo                     // 000000A75A70: 02027D2C
	v_bfe_u32 v62, v55, 8, 16                                  // 000000A75A74: D610003E 02411137
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A75A7C: BF870214
	v_dot2acc_f32_f16 v41, v53, v20                            // 000000A75A80: 04522935
	.long 0xd72c0036                                           // 000000A75A84: D72C0036
	v_cndmask_b32_e32 v1, 0x83dcd12d, v54, vcc_lo              // 000000A75A88: 02026CFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000A75A90: BF870244
	v_bfe_u32 v53, v56, 12, 16                                 // 000000A75A94: D6100035 02411938
	v_bfe_u32 v57, v56, 8, 16                                  // 000000A75A9C: D6100039 02411138
	v_bfe_u32 v58, v56, 4, 16                                  // 000000A75AA4: D610003A 02410938
	v_and_b32_e32 v60, 0xffff, v56                             // 000000A75AAC: 367870FF 0000FFFF
	.long 0xd72c003b                                           // 000000A75AB4: D72C003B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v53, vcc_lo              // 000000A75AB8: 02026AFF 83DCD12D
	v_sad_u8 v54, v54, 0, 0x6400                               // 000000A75AC0: D6220036 03FD0136 00006400
	.long 0xd72c003f                                           // 000000A75ACC: D72C003F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v57, vcc_lo              // 000000A75AD0: 020272FF 83DCD12D
	ds_load_2addr_b32 v[56:57], v49 offset0:128 offset1:160    // 000000A75AD8: D8DCA080 38000031
	v_and_b32_e32 v64, 0xffff, v55                             // 000000A75AE0: 36806EFF 0000FFFF
	.long 0xd72c003a                                           // 000000A75AE8: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 000000A75AEC: 020274FF 83DCD12D
	v_lshlrev_b32_e32 v54, 16, v54                             // 000000A75AF4: 306C6C90
	.long 0xd72c003c                                           // 000000A75AF8: D72C003C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v60, vcc_lo              // 000000A75AFC: 020278FF 83DCD12D
	v_sad_u8 v59, v59, 0, 0x6400                               // 000000A75B04: D622003B 03FD013B 00006400
	.long 0xd72c0040                                           // 000000A75B10: D72C0040
	v_cndmask_b32_e32 v1, 0x83dcd12d, v64, vcc_lo              // 000000A75B14: 020280FF 83DCD12D
	v_sad_u8 v63, v63, 0, 0x6400                               // 000000A75B1C: D622003F 03FD013F 00006400
	v_and_or_b32 v54, 0xffff, v61, v54                         // 000000A75B28: D6570036 04DA7AFF 0000FFFF
	v_bfe_u32 v61, v55, 12, 16                                 // 000000A75B34: D610003D 02411937
	v_bfe_u32 v55, v55, 4, 16                                  // 000000A75B3C: D6100037 02410937
	v_sad_u8 v66, v58, 0, 0x6400                               // 000000A75B44: D6220042 03FD013A 00006400
	v_and_b32_e32 v65, 0xffff, v59                             // 000000A75B50: 368276FF 0000FFFF
	v_pk_fma_f16 v54, v54, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A75B58: CC0E0036 0BFC0B36 0000C931
	.long 0xd72c003d                                           // 000000A75B64: D72C003D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v61, vcc_lo              // 000000A75B68: 02027AFF 83DCD12D
	v_sad_u8 v58, v60, 0, 0x6400                               // 000000A75B70: D622003A 03FD013C 00006400
	v_sad_u8 v64, v64, 0, 0x6400                               // 000000A75B7C: D6220040 03FD0140 00006400
	v_lshl_or_b32 v63, v63, 16, v65                            // 000000A75B88: D656003F 0505213F
	v_dot2acc_f32_f16 v41, v54, v21                            // 000000A75B90: 04522B36
	ds_load_2addr_b32 v[53:54], v50 offset0:128 offset1:160    // 000000A75B94: D8DCA080 35000032
	v_sad_u8 v60, v61, 0, 0x6400                               // 000000A75B9C: D622003C 03FD013D 00006400
	.long 0xd72c003d                                           // 000000A75BA8: D72C003D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v62, vcc_lo              // 000000A75BAC: 02027CFF 83DCD12D
	.long 0xd72c003e                                           // 000000A75BB4: D72C003E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v55, vcc_lo              // 000000A75BB8: 02026EFF 83DCD12D
	s_waitcnt lgkmcnt(0)                                       // 000000A75BC0: BF89FC07
	s_delay_alu instid0(VALU_DEP_3)                            // 000000A75BC4: BF870003
	v_dual_mov_b32 v55, v53 :: v_dual_and_b32 v60, 0xffff, v60 // 000000A75BC8: CA240135 373C78FF 0000FFFF
	v_lshlrev_b32_e32 v53, 16, v58                             // 000000A75BD4: 306A7490
	ds_load_2addr_b32 v[58:59], v47 offset0:128 offset1:160    // 000000A75BD8: D8DCA080 3A00002F
	.long 0xd73d0037                                           // 000000A75BE0: D73D0037
	v_cndmask_b32_e32 v1, v44, v55, vcc_lo                     // 000000A75BE4: 02026F2C
	v_sad_u8 v56, v61, 0, 0x6400                               // 000000A75BE8: D6220038 03FD013D 00006400
	v_sad_u8 v61, v62, 0, 0x6400                               // 000000A75BF4: D622003D 03FD013E 00006400
	v_lshlrev_b32_e32 v62, 16, v64                             // 000000A75C00: 307C8090
	v_and_or_b32 v53, 0xffff, v66, v53                         // 000000A75C04: D6570035 04D684FF 0000FFFF
	v_bfe_u32 v64, v55, 12, 16                                 // 000000A75C10: D6100040 02411937
	v_lshl_or_b32 v56, v56, 16, v60                            // 000000A75C18: D6560038 04F12138
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A75C20: BF870004
	v_and_or_b32 v60, 0xffff, v61, v62                         // 000000A75C24: D657003C 04FA7AFF 0000FFFF
	v_pk_fma_f16 v61, v63, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A75C30: CC0E003D 0BFC0B3F 0000C931
	v_pk_fma_f16 v53, v53, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A75C3C: CC0E0035 0BFC0B35 0000C931
	.long 0xd72c003e                                           // 000000A75C48: D72C003E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v64, vcc_lo              // 000000A75C4C: 020280FF 83DCD12D
	v_and_b32_e32 v63, 0xffff, v55                             // 000000A75C54: 367E6EFF 0000FFFF
	v_pk_fma_f16 v56, v56, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A75C5C: CC0E0038 0BFC0B38 0000C931
	v_dot2acc_f32_f16 v40, v61, v18                            // 000000A75C68: 0450253D
	v_bfe_u32 v61, v55, 8, 16                                  // 000000A75C6C: D610003D 02411137
	v_bfe_u32 v55, v55, 4, 16                                  // 000000A75C74: D6100037 02410937
	s_waitcnt lgkmcnt(0)                                       // 000000A75C7C: BF89FC07
	v_bfe_u32 v64, v58, 12, 16                                 // 000000A75C80: D6100040 0241193A
	.long 0xd72c003f                                           // 000000A75C88: D72C003F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v63, vcc_lo              // 000000A75C8C: 02027EFF 83DCD12D
	v_sad_u8 v62, v62, 0, 0x6400                               // 000000A75C94: D622003E 03FD013E 00006400
	.long 0xd72c003d                                           // 000000A75CA0: D72C003D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v61, vcc_lo              // 000000A75CA4: 02027AFF 83DCD12D
	v_dot2acc_f32_f16 v40, v53, v19                            // 000000A75CAC: 04502735
	v_bfe_u32 v53, v58, 8, 16                                  // 000000A75CB0: D6100035 0241113A
	.long 0xd72c0037                                           // 000000A75CB8: D72C0037
	v_cndmask_b32_e32 v1, 0x83dcd12d, v55, vcc_lo              // 000000A75CBC: 02026EFF 83DCD12D
	v_and_b32_e32 v62, 0xffff, v62                             // 000000A75CC4: 367C7CFF 0000FFFF
	.long 0xd72c0040                                           // 000000A75CCC: D72C0040
	v_cndmask_b32_e32 v1, 0x83dcd12d, v64, vcc_lo              // 000000A75CD0: 020280FF 83DCD12D
	v_bfe_u32 v65, v58, 4, 16                                  // 000000A75CD8: D6100041 0241093A
	.long 0xd72c0035                                           // 000000A75CE0: D72C0035
	v_cndmask_b32_e32 v1, 0x83dcd12d, v53, vcc_lo              // 000000A75CE4: 02026AFF 83DCD12D
	v_sad_u8 v61, v61, 0, 0x6400                               // 000000A75CEC: D622003D 03FD013D 00006400
	v_and_b32_e32 v58, 0xffff, v58                             // 000000A75CF8: 367474FF 0000FFFF
	v_sad_u8 v63, v63, 0, 0x6400                               // 000000A75D00: D622003F 03FD013F 00006400
	v_dot2acc_f32_f16 v40, v56, v20                            // 000000A75D0C: 04502938
	v_pk_fma_f16 v60, v60, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A75D10: CC0E003C 0BFC0B3C 0000C931
	v_lshl_or_b32 v61, v61, 16, v62                            // 000000A75D1C: D656003D 04F9213D
	v_sad_u8 v62, v55, 0, 0x6400                               // 000000A75D24: D622003E 03FD0137 00006400
	v_mov_b32_e32 v55, v57                                     // 000000A75D30: 7E6E0339
	.long 0xd72c0039                                           // 000000A75D34: D72C0039
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 000000A75D38: 020274FF 83DCD12D
	v_sad_u8 v64, v64, 0, 0x6400                               // 000000A75D40: D6220040 03FD0140 00006400
	v_sad_u8 v58, v53, 0, 0x6400                               // 000000A75D4C: D622003A 03FD0135 00006400
	v_lshlrev_b32_e32 v63, 16, v63                             // 000000A75D58: 307E7E90
	.long 0xd73d0035                                           // 000000A75D5C: D73D0035
	v_cndmask_b32_e32 v1, v44, v54, vcc_lo                     // 000000A75D60: 02026D2C
	v_pk_fma_f16 v55, v61, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A75D64: CC0E0037 0BFC0B3D 0000C931
	v_and_b32_e32 v64, 0xffff, v64                             // 000000A75D70: 368080FF 0000FFFF
	v_bfe_u32 v67, v59, 4, 16                                  // 000000A75D78: D6100043 0241093B
	v_sad_u8 v56, v57, 0, 0x6400                               // 000000A75D80: D6220038 03FD0139 00006400
	v_and_or_b32 v62, 0xffff, v62, v63                         // 000000A75D8C: D657003E 04FE7CFF 0000FFFF
	v_bfe_u32 v57, v53, 12, 16                                 // 000000A75D98: D6100039 02411935
	v_lshl_or_b32 v54, v58, 16, v64                            // 000000A75DA0: D6560036 0501213A
	v_bfe_u32 v58, v59, 12, 16                                 // 000000A75DA8: D610003A 0241193B
	v_lshlrev_b32_e32 v64, 16, v56                             // 000000A75DB0: 30807090
	v_pk_fma_f16 v61, v62, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A75DB4: CC0E003D 0BFC0B3E 0000C931
	.long 0xd72c0038                                           // 000000A75DC0: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v57, vcc_lo              // 000000A75DC4: 020272FF 83DCD12D
	v_bfe_u32 v57, v53, 8, 16                                  // 000000A75DCC: D6100039 02411135
	v_pk_fma_f16 v62, v54, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A75DD4: CC0E003E 0BFC0B36 0000C931
	v_and_b32_e32 v54, 0xffff, v53                             // 000000A75DE0: 366C6AFF 0000FFFF
	v_bfe_u32 v53, v53, 4, 16                                  // 000000A75DE8: D6100035 02410935
	.long 0xd72c003f                                           // 000000A75DF0: D72C003F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v65, vcc_lo              // 000000A75DF4: 020282FF 83DCD12D
	.long 0xd72c0039                                           // 000000A75DFC: D72C0039
	v_cndmask_b32_e32 v1, 0x83dcd12d, v57, vcc_lo              // 000000A75E00: 020272FF 83DCD12D
	v_bfe_u32 v65, v59, 8, 16                                  // 000000A75E08: D6100041 0241113B
	.long 0xd72c0042                                           // 000000A75E10: D72C0042
	v_cndmask_b32_e32 v1, 0x83dcd12d, v54, vcc_lo              // 000000A75E14: 02026CFF 83DCD12D
	v_sad_u8 v56, v56, 0, 0x6400                               // 000000A75E1C: D6220038 03FD0138 00006400
	.long 0xd72c0044                                           // 000000A75E28: D72C0044
	v_cndmask_b32_e32 v1, 0x83dcd12d, v53, vcc_lo              // 000000A75E2C: 02026AFF 83DCD12D
	ds_load_2addr_b32 v[53:54], v50 offset0:192 offset1:224    // 000000A75E34: D8DCE0C0 35000032
	v_dual_dot2acc_f32_f16 v40, v60, v21 :: v_dual_and_b32 v59, 0xffff, v59// 000000A75E3C: CB242B3C 283A76FF 0000FFFF
	.long 0xd72c003a                                           // 000000A75E48: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 000000A75E4C: 020274FF 83DCD12D
	v_and_b32_e32 v69, 0xffff, v56                             // 000000A75E54: 368A70FF 0000FFFF
	v_sad_u8 v70, v57, 0, 0x6400                               // 000000A75E5C: D6220046 03FD0139 00006400
	ds_load_2addr_b32 v[56:57], v49 offset0:192 offset1:224    // 000000A75E68: D8DCE0C0 38000031
	.long 0xd72c0041                                           // 000000A75E70: D72C0041
	v_cndmask_b32_e32 v1, 0x83dcd12d, v65, vcc_lo              // 000000A75E74: 020282FF 83DCD12D
	.long 0xd72c003b                                           // 000000A75E7C: D72C003B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 000000A75E80: 020276FF 83DCD12D
	v_sad_u8 v66, v66, 0, 0x6400                               // 000000A75E88: D6220042 03FD0142 00006400
	.long 0xd72c0043                                           // 000000A75E94: D72C0043
	v_cndmask_b32_e32 v1, 0x83dcd12d, v67, vcc_lo              // 000000A75E98: 020286FF 83DCD12D
	v_sad_u8 v58, v58, 0, 0x6400                               // 000000A75EA0: D622003A 03FD013A 00006400
	v_sad_u8 v68, v68, 0, 0x6400                               // 000000A75EAC: D6220044 03FD0144 00006400
	v_dot2acc_f32_f16 v39, v55, v18                            // 000000A75EB8: 044E2537
	v_lshlrev_b32_e32 v66, 16, v66                             // 000000A75EBC: 30848490
	v_lshl_or_b32 v55, v70, 16, v69                            // 000000A75EC0: D6560037 05152146
	v_and_b32_e32 v58, 0xffff, v58                             // 000000A75EC8: 367474FF 0000FFFF
	v_sad_u8 v65, v65, 0, 0x6400                               // 000000A75ED0: D6220041 03FD0141 00006400
	v_sad_u8 v59, v59, 0, 0x6400                               // 000000A75EDC: D622003B 03FD013B 00006400
	v_and_or_b32 v66, 0xffff, v68, v66                         // 000000A75EE8: D6570042 050A88FF 0000FFFF
	v_pk_fma_f16 v68, v55, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A75EF4: CC0E0044 0BFC0B37 0000C931
	s_waitcnt lgkmcnt(1)                                       // 000000A75F00: BF89FC17
	v_mov_b32_e32 v55, v53                                     // 000000A75F04: 7E6E0335
	v_sad_u8 v63, v63, 0, 0x6400                               // 000000A75F08: D622003F 03FD013F 00006400
	v_lshl_or_b32 v53, v65, 16, v58                            // 000000A75F14: D6560035 04E92141
	v_sad_u8 v65, v67, 0, 0x6400                               // 000000A75F1C: D6220041 03FD0143 00006400
	v_lshlrev_b32_e32 v67, 16, v59                             // 000000A75F28: 30867690
	ds_load_2addr_b32 v[58:59], v47 offset0:192 offset1:224    // 000000A75F2C: D8DCE0C0 3A00002F
	s_waitcnt lgkmcnt(1)                                       // 000000A75F34: BF89FC17
	.long 0xd73d0037                                           // 000000A75F38: D73D0037
	v_cndmask_b32_e32 v1, v44, v55, vcc_lo                     // 000000A75F3C: 02026F2C
	v_pk_fma_f16 v66, v66, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A75F40: CC0E0042 0BFC0B42 0000C931
	v_dot2acc_f32_f16 v38, v68, v18                            // 000000A75F4C: 044C2544
	v_and_or_b32 v56, 0xffff, v63, v64                         // 000000A75F50: D6570038 05027EFF 0000FFFF
	v_dot2acc_f32_f16 v39, v61, v19                            // 000000A75F5C: 044E273D
	v_pk_fma_f16 v53, v53, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A75F60: CC0E0035 0BFC0B35 0000C931
	v_bfe_u32 v63, v55, 12, 16                                 // 000000A75F6C: D610003F 02411937
	v_dot2acc_f32_f16 v38, v66, v19                            // 000000A75F74: 044C2742
	v_pk_fma_f16 v56, v56, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A75F78: CC0E0038 0BFC0B38 0000C931
	v_dot2acc_f32_f16 v39, v62, v20                            // 000000A75F84: 044E293E
	v_and_or_b32 v61, 0xffff, v65, v67                         // 000000A75F88: D657003D 050E82FF 0000FFFF
	v_bfe_u32 v62, v55, 8, 16                                  // 000000A75F94: D610003E 02411137
	v_dot2acc_f32_f16 v38, v53, v20                            // 000000A75F9C: 044C2935
	.long 0xd72c0035                                           // 000000A75FA0: D72C0035
	v_cndmask_b32_e32 v1, 0x83dcd12d, v63, vcc_lo              // 000000A75FA4: 02027EFF 83DCD12D
	v_dot2acc_f32_f16 v39, v56, v21                            // 000000A75FAC: 044E2B38
	v_bfe_u32 v56, v55, 4, 16                                  // 000000A75FB0: D6100038 02410937
	v_and_b32_e32 v55, 0xffff, v55                             // 000000A75FB8: 366E6EFF 0000FFFF
	v_pk_fma_f16 v61, v61, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A75FC0: CC0E003D 0BFC0B3D 0000C931
	.long 0xd72c003c                                           // 000000A75FCC: D72C003C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v62, vcc_lo              // 000000A75FD0: 02027CFF 83DCD12D
	s_waitcnt lgkmcnt(0)                                       // 000000A75FD8: BF89FC07
	v_and_b32_e32 v63, 0xffff, v58                             // 000000A75FDC: 367E74FF 0000FFFF
	v_bfe_u32 v62, v58, 8, 16                                  // 000000A75FE4: D610003E 0241113A
	.long 0xd72c0037                                           // 000000A75FEC: D72C0037
	v_cndmask_b32_e32 v1, 0x83dcd12d, v55, vcc_lo              // 000000A75FF0: 02026EFF 83DCD12D
	v_dot2acc_f32_f16 v38, v61, v21                            // 000000A75FF8: 044C2B3D
	v_bfe_u32 v61, v58, 12, 16                                 // 000000A75FFC: D610003D 0241193A
	v_sad_u8 v53, v53, 0, 0x6400                               // 000000A76004: D6220035 03FD0135 00006400
	v_bfe_u32 v58, v58, 4, 16                                  // 000000A76010: D610003A 0241093A
	.long 0xd72c0038                                           // 000000A76018: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v56, vcc_lo              // 000000A7601C: 020270FF 83DCD12D
	.long 0xd72c003f                                           // 000000A76024: D72C003F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v63, vcc_lo              // 000000A76028: 02027EFF 83DCD12D
	.long 0xd72c003d                                           // 000000A76030: D72C003D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v61, vcc_lo              // 000000A76034: 02027AFF 83DCD12D
	v_and_b32_e32 v53, 0xffff, v53                             // 000000A7603C: 366A6AFF 0000FFFF
	v_sad_u8 v60, v60, 0, 0x6400                               // 000000A76044: D622003C 03FD013C 00006400
	v_sad_u8 v64, v55, 0, 0x6400                               // 000000A76050: D6220040 03FD0137 00006400
	v_mov_b32_e32 v55, v57                                     // 000000A7605C: 7E6E0339
	.long 0xd72c003e                                           // 000000A76060: D72C003E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v62, vcc_lo              // 000000A76064: 02027CFF 83DCD12D
	.long 0xd72c0039                                           // 000000A7606C: D72C0039
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 000000A76070: 020274FF 83DCD12D
	v_lshl_or_b32 v60, v60, 16, v53                            // 000000A76078: D656003C 04D5213C
	v_sad_u8 v58, v61, 0, 0x6400                               // 000000A76080: D622003A 03FD013D 00006400
	.long 0xd73d0035                                           // 000000A7608C: D73D0035
	v_cndmask_b32_e32 v1, v44, v54, vcc_lo                     // 000000A76090: 02026D2C
	v_sad_u8 v56, v56, 0, 0x6400                               // 000000A76094: D6220038 03FD0138 00006400
	v_sad_u8 v61, v63, 0, 0x6400                               // 000000A760A0: D622003D 03FD013F 00006400
	v_lshlrev_b32_e32 v54, 16, v64                             // 000000A760AC: 306C8090
	v_and_b32_e32 v55, 0xffff, v58                             // 000000A760B0: 366E74FF 0000FFFF
	v_sad_u8 v58, v62, 0, 0x6400                               // 000000A760B8: D622003A 03FD013E 00006400
	v_sad_u8 v57, v57, 0, 0x6400                               // 000000A760C4: D6220039 03FD0139 00006400
	v_lshlrev_b32_e32 v61, 16, v61                             // 000000A760D0: 307A7A90
	v_pk_fma_f16 v60, v60, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A760D4: CC0E003C 0BFC0B3C 0000C931
	v_and_or_b32 v54, 0xffff, v56, v54                         // 000000A760E0: D6570036 04DA70FF 0000FFFF
	v_bfe_u32 v62, v53, 12, 16                                 // 000000A760EC: D610003E 02411935
	v_lshl_or_b32 v55, v58, 16, v55                            // 000000A760F4: D6560037 04DD213A
	v_and_or_b32 v56, 0xffff, v57, v61                         // 000000A760FC: D6570038 04F672FF 0000FFFF
	v_dot2acc_f32_f16 v37, v60, v18                            // 000000A76108: 044A253C
	v_pk_fma_f16 v61, v54, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A7610C: CC0E003D 0BFC0B36 0000C931
	.long 0xd72c0039                                           // 000000A76118: D72C0039
	v_cndmask_b32_e32 v1, 0x83dcd12d, v62, vcc_lo              // 000000A7611C: 02027CFF 83DCD12D
	v_pk_fma_f16 v62, v55, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A76124: CC0E003E 0BFC0B37 0000C931
	v_bfe_u32 v58, v53, 8, 16                                  // 000000A76130: D610003A 02411135
	v_pk_fma_f16 v63, v56, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A76138: CC0E003F 0BFC0B38 0000C931
	v_dual_dot2acc_f32_f16 v37, v61, v19 :: v_dual_and_b32 v54, 0xffff, v53// 000000A76144: CB24273D 25366AFF 0000FFFF
	v_bfe_u32 v65, v59, 8, 16                                  // 000000A76150: D6100041 0241113B
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A76158: BF870004
	.long 0xd72c0037                                           // 000000A7615C: D72C0037
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 000000A76160: 020274FF 83DCD12D
	v_sad_u8 v56, v57, 0, 0x6400                               // 000000A76168: D6220038 03FD0139 00006400
	v_bfe_u32 v57, v53, 4, 16                                  // 000000A76174: D6100039 02410935
	v_dot2acc_f32_f16 v37, v62, v20                            // 000000A7617C: 044A293E
	.long 0xd72c003c                                           // 000000A76180: D72C003C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v54, vcc_lo              // 000000A76184: 02026CFF 83DCD12D
	ds_load_2addr_b32 v[53:54], v52 offset1:32                 // 000000A7618C: D8DC2000 35000034
	v_and_b32_e32 v64, 0xffff, v56                             // 000000A76194: 368070FF 0000FFFF
	.long 0xd72c0042                                           // 000000A7619C: D72C0042
	v_cndmask_b32_e32 v1, 0x83dcd12d, v57, vcc_lo              // 000000A761A0: 020272FF 83DCD12D
	ds_load_2addr_b32 v[56:57], v51 offset1:32                 // 000000A761A8: D8DC2000 38000033
	v_bfe_u32 v58, v59, 12, 16                                 // 000000A761B0: D610003A 0241193B
	v_sad_u8 v55, v55, 0, 0x6400                               // 000000A761B8: D6220037 03FD0137 00006400
	v_and_b32_e32 v67, 0xffff, v59                             // 000000A761C4: 368676FF 0000FFFF
	v_sad_u8 v60, v60, 0, 0x6400                               // 000000A761CC: D622003C 03FD013C 00006400
	v_bfe_u32 v59, v59, 4, 16                                  // 000000A761D8: D610003B 0241093B
	.long 0xd72c003a                                           // 000000A761E0: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 000000A761E4: 020274FF 83DCD12D
	v_lshl_or_b32 v55, v55, 16, v64                            // 000000A761EC: D6560037 05012137
	.long 0xd72c0041                                           // 000000A761F4: D72C0041
	v_cndmask_b32_e32 v1, 0x83dcd12d, v65, vcc_lo              // 000000A761F8: 020282FF 83DCD12D
	.long 0xd72c0040                                           // 000000A76200: D72C0040
	v_cndmask_b32_e32 v1, 0x83dcd12d, v67, vcc_lo              // 000000A76204: 020286FF 83DCD12D
	v_sad_u8 v66, v66, 0, 0x6400                               // 000000A7620C: D6220042 03FD0142 00006400
	v_lshlrev_b32_e32 v60, 16, v60                             // 000000A76218: 30787890
	v_pk_fma_f16 v67, v55, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A7621C: CC0E0043 0BFC0B37 0000C931
	.long 0xd72c0044                                           // 000000A76228: D72C0044
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 000000A7622C: 020276FF 83DCD12D
	v_sad_u8 v69, v58, 0, 0x6400                               // 000000A76234: D6220045 03FD013A 00006400
	ds_load_2addr_b32 v[58:59], v48 offset1:32                 // 000000A76240: D8DC2000 3A000030
	v_and_or_b32 v60, 0xffff, v66, v60                         // 000000A76248: D657003C 04F284FF 0000FFFF
	s_waitcnt lgkmcnt(2)                                       // 000000A76254: BF89FC27
	v_mov_b32_e32 v55, v53                                     // 000000A76258: 7E6E0335
	v_sad_u8 v65, v65, 0, 0x6400                               // 000000A7625C: D6220041 03FD0141 00006400
	v_and_b32_e32 v53, 0xffff, v69                             // 000000A76268: 366A8AFF 0000FFFF
	v_sad_u8 v64, v64, 0, 0x6400                               // 000000A76270: D6220040 03FD0140 00006400
	v_dot2acc_f32_f16 v36, v67, v18                            // 000000A7627C: 04482543
	s_waitcnt lgkmcnt(1)                                       // 000000A76280: BF89FC17
	.long 0xd73d0037                                           // 000000A76284: D73D0037
	v_cndmask_b32_e32 v1, v44, v55, vcc_lo                     // 000000A76288: 02026F2C
	v_pk_fma_f16 v56, v60, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A7628C: CC0E0038 0BFC0B3C 0000C931
	v_lshl_or_b32 v53, v65, 16, v53                            // 000000A76298: D6560035 04D52141
	v_sad_u8 v66, v68, 0, 0x6400                               // 000000A762A0: D6220042 03FD0144 00006400
	v_dual_dot2acc_f32_f16 v37, v63, v21 :: v_dual_lshlrev_b32 v64, 16, v64// 000000A762AC: CB222B3F 25408090
	v_bfe_u32 v61, v55, 12, 16                                 // 000000A762B4: D610003D 02411937
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A762BC: BF870004
	v_pk_fma_f16 v62, v53, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A762C0: CC0E003E 0BFC0B35 0000C931
	v_dot2acc_f32_f16 v36, v56, v19                            // 000000A762CC: 04482738
	v_bfe_u32 v56, v55, 8, 16                                  // 000000A762D0: D6100038 02411137
	v_and_or_b32 v60, 0xffff, v66, v64                         // 000000A762D8: D657003C 050284FF 0000FFFF
	.long 0xd72c0035                                           // 000000A762E4: D72C0035
	v_cndmask_b32_e32 v1, 0x83dcd12d, v61, vcc_lo              // 000000A762E8: 02027AFF 83DCD12D
	v_and_b32_e32 v61, 0xffff, v55                             // 000000A762F0: 367A6EFF 0000FFFF
	v_bfe_u32 v55, v55, 4, 16                                  // 000000A762F8: D6100037 02410937
	s_waitcnt lgkmcnt(0)                                       // 000000A76300: BF89FC07
	v_bfe_u32 v64, v58, 12, 16                                 // 000000A76304: D6100040 0241193A
	.long 0xd72c0038                                           // 000000A7630C: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v56, vcc_lo              // 000000A76310: 020270FF 83DCD12D
	v_bfe_u32 v65, v58, 8, 16                                  // 000000A76318: D6100041 0241113A
	.long 0xd72c003d                                           // 000000A76320: D72C003D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v61, vcc_lo              // 000000A76324: 02027AFF 83DCD12D
	.long 0xd72c0037                                           // 000000A7632C: D72C0037
	v_cndmask_b32_e32 v1, 0x83dcd12d, v55, vcc_lo              // 000000A76330: 02026EFF 83DCD12D
	v_sad_u8 v53, v53, 0, 0x6400                               // 000000A76338: D6220035 03FD0135 00006400
	.long 0xd72c0040                                           // 000000A76344: D72C0040
	v_cndmask_b32_e32 v1, 0x83dcd12d, v64, vcc_lo              // 000000A76348: 020280FF 83DCD12D
	.long 0xd72c0041                                           // 000000A76350: D72C0041
	v_cndmask_b32_e32 v1, 0x83dcd12d, v65, vcc_lo              // 000000A76354: 020282FF 83DCD12D
	v_bfe_u32 v66, v58, 4, 16                                  // 000000A7635C: D6100042 0241093A
	v_sad_u8 v56, v56, 0, 0x6400                               // 000000A76364: D6220038 03FD0138 00006400
	v_and_b32_e32 v53, 0xffff, v53                             // 000000A76370: 366A6AFF 0000FFFF
	v_sad_u8 v61, v61, 0, 0x6400                               // 000000A76378: D622003D 03FD013D 00006400
	v_sad_u8 v67, v55, 0, 0x6400                               // 000000A76384: D6220043 03FD0137 00006400
	v_mov_b32_e32 v55, v57                                     // 000000A76390: 7E6E0339
	v_sad_u8 v64, v64, 0, 0x6400                               // 000000A76394: D6220040 03FD0140 00006400
	v_lshl_or_b32 v56, v56, 16, v53                            // 000000A763A0: D6560038 04D52138
	v_lshlrev_b32_e32 v61, 16, v61                             // 000000A763A8: 307A7A90
	.long 0xd72c0042                                           // 000000A763AC: D72C0042
	v_cndmask_b32_e32 v1, 0x83dcd12d, v66, vcc_lo              // 000000A763B0: 020284FF 83DCD12D
	.long 0xd73d0035                                           // 000000A763B8: D73D0035
	v_cndmask_b32_e32 v1, v44, v54, vcc_lo                     // 000000A763BC: 02026D2C
	v_and_b32_e32 v57, 0xffff, v64                             // 000000A763C0: 367280FF 0000FFFF
	v_sad_u8 v64, v65, 0, 0x6400                               // 000000A763C8: D6220040 03FD0141 00006400
	v_and_or_b32 v54, 0xffff, v67, v61                         // 000000A763D4: D6570036 04F686FF 0000FFFF
	v_pk_fma_f16 v61, v56, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A763E0: CC0E003D 0BFC0B38 0000C931
	v_bfe_u32 v67, v59, 4, 16                                  // 000000A763EC: D6100043 0241093B
	v_bfe_u32 v56, v53, 12, 16                                 // 000000A763F4: D6100038 02411935
	v_lshl_or_b32 v55, v64, 16, v57                            // 000000A763FC: D6560037 04E52140
	v_pk_fma_f16 v64, v54, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A76404: CC0E0040 0BFC0B36 0000C931
	v_dot2acc_f32_f16 v35, v61, v18                            // 000000A76410: 0446253D
	v_and_b32_e32 v58, 0xffff, v58                             // 000000A76414: 367474FF 0000FFFF
	v_sad_u8 v57, v66, 0, 0x6400                               // 000000A7641C: D6220039 03FD0142 00006400
	v_pk_fma_f16 v65, v55, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A76428: CC0E0041 0BFC0B37 0000C931
	.long 0xd72c0037                                           // 000000A76434: D72C0037
	v_cndmask_b32_e32 v1, 0x83dcd12d, v56, vcc_lo              // 000000A76438: 020270FF 83DCD12D
	v_dot2acc_f32_f16 v35, v64, v19                            // 000000A76440: 04462740
	.long 0xd72c003a                                           // 000000A76444: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 000000A76448: 020274FF 83DCD12D
	v_bfe_u32 v56, v53, 8, 16                                  // 000000A76450: D6100038 02411135
	.long 0xd72c0043                                           // 000000A76458: D72C0043
	v_cndmask_b32_e32 v1, 0x83dcd12d, v67, vcc_lo              // 000000A7645C: 020286FF 83DCD12D
	v_pk_fma_f16 v60, v60, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A76464: CC0E003C 0BFC0B3C 0000C931
	v_dot2acc_f32_f16 v35, v65, v20                            // 000000A76470: 04462941
	v_dot2acc_f32_f16 v36, v62, v20                            // 000000A76474: 0448293E
	.long 0xd72c0038                                           // 000000A76478: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v56, vcc_lo              // 000000A7647C: 020270FF 83DCD12D
	v_sad_u8 v55, v55, 0, 0x6400                               // 000000A76484: D6220037 03FD0137 00006400
	v_sad_u8 v58, v58, 0, 0x6400                               // 000000A76490: D622003A 03FD013A 00006400
	v_sad_u8 v67, v67, 0, 0x6400                               // 000000A7649C: D6220043 03FD0143 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A764A8: BF870193
	v_dual_dot2acc_f32_f16 v36, v60, v21 :: v_dual_and_b32 v55, 0xffff, v55// 000000A764AC: CB242B3C 24366EFF 0000FFFF
	v_lshlrev_b32_e32 v58, 16, v58                             // 000000A764B8: 30747490
	v_sad_u8 v69, v56, 0, 0x6400                               // 000000A764BC: D6220045 03FD0138 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000A764C8: BF8701A2
	v_and_or_b32 v66, 0xffff, v57, v58                         // 000000A764CC: D6570042 04EA72FF 0000FFFF
	v_bfe_u32 v57, v59, 12, 16                                 // 000000A764D8: D6100039 0241193B
	v_lshl_or_b32 v55, v69, 16, v55                            // 000000A764E0: D6560037 04DD2145
	v_bfe_u32 v58, v59, 8, 16                                  // 000000A764E8: D610003A 0241113B
	v_and_b32_e32 v59, 0xffff, v59                             // 000000A764F0: 367676FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A764F8: BF870214
	.long 0xd72c0039                                           // 000000A764FC: D72C0039
	v_cndmask_b32_e32 v1, 0x83dcd12d, v57, vcc_lo              // 000000A76500: 020272FF 83DCD12D
	v_pk_fma_f16 v55, v55, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A76508: CC0E0037 0BFC0B37 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A76514: BF870214
	.long 0xd72c003a                                           // 000000A76518: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 000000A7651C: 020274FF 83DCD12D
	.long 0xd72c003b                                           // 000000A76524: D72C003B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 000000A76528: 020276FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3)                            // 000000A76530: BF870003
	v_dot2acc_f32_f16 v34, v55, v18                            // 000000A76534: 04442537
	v_sad_u8 v71, v57, 0, 0x6400                               // 000000A76538: D6220047 03FD0139 00006400
	ds_load_2addr_b32 v[56:57], v51 offset0:64 offset1:96      // 000000A76544: D8DC6040 38000033
	v_and_b32_e32 v54, 0xffff, v53                             // 000000A7654C: 366C6AFF 0000FFFF
	v_bfe_u32 v53, v53, 4, 16                                  // 000000A76554: D6100035 02410935
	v_sad_u8 v58, v58, 0, 0x6400                               // 000000A7655C: D622003A 03FD013A 00006400
	v_and_b32_e32 v69, 0xffff, v71                             // 000000A76568: 368A8EFF 0000FFFF
	v_sad_u8 v59, v59, 0, 0x6400                               // 000000A76570: D622003B 03FD013B 00006400
	.long 0xd72c0036                                           // 000000A7657C: D72C0036
	v_cndmask_b32_e32 v1, 0x83dcd12d, v54, vcc_lo              // 000000A76580: 02026CFF 83DCD12D
	.long 0xd72c0035                                           // 000000A76588: D72C0035
	v_cndmask_b32_e32 v1, 0x83dcd12d, v53, vcc_lo              // 000000A7658C: 02026AFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A76594: BF870112
	v_sad_u8 v68, v54, 0, 0x6400                               // 000000A76598: D6220044 03FD0136 00006400
	v_sad_u8 v70, v53, 0, 0x6400                               // 000000A765A4: D6220046 03FD0135 00006400
	ds_load_2addr_b32 v[53:54], v52 offset0:64 offset1:96      // 000000A765B0: D8DC6040 35000034
	s_waitcnt lgkmcnt(0)                                       // 000000A765B8: BF89FC07
	v_mov_b32_e32 v55, v53                                     // 000000A765BC: 7E6E0335
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000A765C0: BF8700A1
	.long 0xd73d0037                                           // 000000A765C4: D73D0037
	v_cndmask_b32_e32 v1, v44, v55, vcc_lo                     // 000000A765C8: 02026F2C
	v_pk_fma_f16 v56, v66, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A765CC: CC0E0038 0BFC0B42 0000C931
	v_dual_dot2acc_f32_f16 v35, v56, v21 :: v_dual_lshlrev_b32 v68, 16, v68// 000000A765D8: CB222B38 23448890
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A765E0: BF870211
	v_and_or_b32 v68, 0xffff, v70, v68                         // 000000A765E4: D6570044 05128CFF 0000FFFF
	v_and_b32_e32 v56, 0xffff, v55                             // 000000A765F0: 36706EFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_2)                            // 000000A765F8: BF870002
	v_pk_fma_f16 v61, v68, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A765FC: CC0E003D 0BFC0B44 0000C931
	v_lshl_or_b32 v68, v58, 16, v69                            // 000000A76608: D6560044 0515213A
	v_lshlrev_b32_e32 v69, 16, v59                             // 000000A76610: 308A7690
	ds_load_2addr_b32 v[58:59], v48 offset0:64 offset1:96      // 000000A76614: D8DC6040 3A000030
	v_dot2acc_f32_f16 v34, v61, v19                            // 000000A7661C: 0444273D
	v_pk_fma_f16 v53, v68, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A76620: CC0E0035 0BFC0B44 0000C931
	v_and_or_b32 v64, 0xffff, v67, v69                         // 000000A7662C: D6570040 051686FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A76638: BF870112
	v_dot2acc_f32_f16 v34, v53, v20                            // 000000A7663C: 04442935
	v_pk_fma_f16 v61, v64, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A76640: CC0E003D 0BFC0B40 0000C931
	v_bfe_u32 v53, v55, 12, 16                                 // 000000A7664C: D6100035 02411937
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A76654: BF870112
	v_dot2acc_f32_f16 v34, v61, v21                            // 000000A76658: 04442B3D
	.long 0xd72c0035                                           // 000000A7665C: D72C0035
	v_cndmask_b32_e32 v1, 0x83dcd12d, v53, vcc_lo              // 000000A76660: 02026AFF 83DCD12D
	v_bfe_u32 v61, v55, 8, 16                                  // 000000A76668: D610003D 02411137
	v_bfe_u32 v55, v55, 4, 16                                  // 000000A76670: D6100037 02410937
	s_waitcnt lgkmcnt(0)                                       // 000000A76678: BF89FC07
	v_bfe_u32 v60, v58, 12, 16                                 // 000000A7667C: D610003C 0241193A
	v_bfe_u32 v62, v58, 8, 16                                  // 000000A76684: D610003E 0241113A
	.long 0xd72c003d                                           // 000000A7668C: D72C003D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v61, vcc_lo              // 000000A76690: 02027AFF 83DCD12D
	v_bfe_u32 v63, v58, 4, 16                                  // 000000A76698: D610003F 0241093A
	v_and_b32_e32 v58, 0xffff, v58                             // 000000A766A0: 367474FF 0000FFFF
	.long 0xd72c003c                                           // 000000A766A8: D72C003C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v60, vcc_lo              // 000000A766AC: 020278FF 83DCD12D
	v_sad_u8 v53, v53, 0, 0x6400                               // 000000A766B4: D6220035 03FD0135 00006400
	.long 0xd72c0037                                           // 000000A766C0: D72C0037
	v_cndmask_b32_e32 v1, 0x83dcd12d, v55, vcc_lo              // 000000A766C4: 02026EFF 83DCD12D
	.long 0xd72c003e                                           // 000000A766CC: D72C003E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v62, vcc_lo              // 000000A766D0: 02027CFF 83DCD12D
	.long 0xd72c003a                                           // 000000A766D8: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 000000A766DC: 020274FF 83DCD12D
	v_sad_u8 v61, v61, 0, 0x6400                               // 000000A766E4: D622003D 03FD013D 00006400
	v_and_b32_e32 v53, 0xffff, v53                             // 000000A766F0: 366A6AFF 0000FFFF
	.long 0xd72c003f                                           // 000000A766F8: D72C003F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v63, vcc_lo              // 000000A766FC: 02027EFF 83DCD12D
	v_sad_u8 v60, v60, 0, 0x6400                               // 000000A76704: D622003C 03FD013C 00006400
	v_bfe_u32 v66, v59, 4, 16                                  // 000000A76710: D6100042 0241093B
	v_sad_u8 v64, v55, 0, 0x6400                               // 000000A76718: D6220040 03FD0137 00006400
	v_mov_b32_e32 v55, v57                                     // 000000A76724: 7E6E0339
	v_sad_u8 v57, v62, 0, 0x6400                               // 000000A76728: D6220039 03FD013E 00006400
	v_and_b32_e32 v60, 0xffff, v60                             // 000000A76734: 367878FF 0000FFFF
	v_lshl_or_b32 v61, v61, 16, v53                            // 000000A7673C: D656003D 04D5213D
	v_sad_u8 v58, v58, 0, 0x6400                               // 000000A76744: D622003A 03FD013A 00006400
	.long 0xd73d0035                                           // 000000A76750: D73D0035
	v_cndmask_b32_e32 v1, v44, v54, vcc_lo                     // 000000A76754: 02026D2C
	v_sad_u8 v55, v63, 0, 0x6400                               // 000000A76758: D6220037 03FD013F 00006400
	v_lshl_or_b32 v54, v57, 16, v60                            // 000000A76764: D6560036 04F12139
	v_bfe_u32 v63, v59, 12, 16                                 // 000000A7676C: D610003F 0241193B
	v_lshlrev_b32_e32 v57, 16, v58                             // 000000A76774: 30727490
	v_pk_fma_f16 v58, v61, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A76778: CC0E003A 0BFC0B3D 0000C931
	v_bfe_u32 v60, v53, 12, 16                                 // 000000A76784: D610003C 02411935
	v_pk_fma_f16 v61, v54, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A7678C: CC0E003D 0BFC0B36 0000C931
	.long 0xd72c003f                                           // 000000A76798: D72C003F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v63, vcc_lo              // 000000A7679C: 02027EFF 83DCD12D
	v_and_or_b32 v54, 0xffff, v55, v57                         // 000000A767A4: D6570036 04E66EFF 0000FFFF
	v_dot2acc_f32_f16 v33, v58, v18                            // 000000A767B0: 0442253A
	.long 0xd72c0038                                           // 000000A767B4: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v56, vcc_lo              // 000000A767B8: 020270FF 83DCD12D
	v_bfe_u32 v55, v53, 8, 16                                  // 000000A767C0: D6100037 02411135
	.long 0xd72c0039                                           // 000000A767C8: D72C0039
	v_cndmask_b32_e32 v1, 0x83dcd12d, v60, vcc_lo              // 000000A767CC: 020278FF 83DCD12D
	v_pk_fma_f16 v60, v54, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A767D4: CC0E003C 0BFC0B36 0000C931
	v_sad_u8 v63, v63, 0, 0x6400                               // 000000A767E0: D622003F 03FD013F 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000A767EC: BF870234
	.long 0xd72c0037                                           // 000000A767F0: D72C0037
	v_cndmask_b32_e32 v1, 0x83dcd12d, v55, vcc_lo              // 000000A767F4: 02026EFF 83DCD12D
	v_sad_u8 v56, v56, 0, 0x6400                               // 000000A767FC: D6220038 03FD0138 00006400
	v_sad_u8 v62, v57, 0, 0x6400                               // 000000A76808: D622003E 03FD0139 00006400
	v_and_b32_e32 v63, 0xffff, v63                             // 000000A76814: 367E7EFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000A7681C: BF870123
	v_lshlrev_b32_e32 v56, 16, v56                             // 000000A76820: 30707090
	v_sad_u8 v55, v55, 0, 0x6400                               // 000000A76824: D6220037 03FD0137 00006400
	v_and_or_b32 v56, 0xffff, v64, v56                         // 000000A76830: D6570038 04E280FF 0000FFFF
	v_bfe_u32 v64, v59, 8, 16                                  // 000000A7683C: D6100040 0241113B
	v_and_b32_e32 v59, 0xffff, v59                             // 000000A76844: 367676FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A7684C: BF870193
	v_pk_fma_f16 v56, v56, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A76850: CC0E0038 0BFC0B38 0000C931
	.long 0xd72c0040                                           // 000000A7685C: D72C0040
	v_cndmask_b32_e32 v1, 0x83dcd12d, v64, vcc_lo              // 000000A76860: 020280FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A76868: BF870193
	.long 0xd72c003b                                           // 000000A7686C: D72C003B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 000000A76870: 020276FF 83DCD12D
	v_dual_dot2acc_f32_f16 v33, v56, v19 :: v_dual_and_b32 v58, 0xffff, v53// 000000A76878: CB242738 213A6AFF 0000FFFF
	v_bfe_u32 v56, v53, 4, 16                                  // 000000A76884: D6100038 02410935
	ds_load_2addr_b32 v[53:54], v52 offset0:128 offset1:160    // 000000A7688C: D8DCA080 35000034
	v_sad_u8 v64, v64, 0, 0x6400                               // 000000A76894: D6220040 03FD0140 00006400
	v_dot2acc_f32_f16 v33, v61, v20                            // 000000A768A0: 0442293D
	.long 0xd72c003a                                           // 000000A768A4: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 000000A768A8: 020274FF 83DCD12D
	.long 0xd72c0041                                           // 000000A768B0: D72C0041
	v_cndmask_b32_e32 v1, 0x83dcd12d, v56, vcc_lo              // 000000A768B4: 020270FF 83DCD12D
	ds_load_2addr_b32 v[56:57], v51 offset0:128 offset1:160    // 000000A768BC: D8DCA080 38000033
	v_dual_dot2acc_f32_f16 v33, v60, v21 :: v_dual_and_b32 v62, 0xffff, v62// 000000A768C4: CB242B3C 213E7CFF 0000FFFF
	v_sad_u8 v58, v58, 0, 0x6400                               // 000000A768D0: D622003A 03FD013A 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000A768DC: BF8701A2
	v_lshl_or_b32 v55, v55, 16, v62                            // 000000A768E0: D6560037 04F92137
	v_sad_u8 v62, v65, 0, 0x6400                               // 000000A768E8: D622003E 03FD0141 00006400
	v_lshlrev_b32_e32 v58, 16, v58                             // 000000A768F4: 30747490
	s_delay_alu instid0(VALU_DEP_3)                            // 000000A768F8: BF870003
	v_pk_fma_f16 v65, v55, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A768FC: CC0E0041 0BFC0B37 0000C931
	s_waitcnt lgkmcnt(1)                                       // 000000A76908: BF89FC17
	v_mov_b32_e32 v55, v53                                     // 000000A7690C: 7E6E0335
	.long 0xd72c0035                                           // 000000A76910: D72C0035
	v_cndmask_b32_e32 v1, 0x83dcd12d, v66, vcc_lo              // 000000A76914: 020284FF 83DCD12D
	v_and_or_b32 v62, 0xffff, v62, v58                         // 000000A7691C: D657003E 04EA7CFF 0000FFFF
	v_sad_u8 v66, v59, 0, 0x6400                               // 000000A76928: D6220042 03FD013B 00006400
	ds_load_2addr_b32 v[58:59], v48 offset0:128 offset1:160    // 000000A76934: D8DCA080 3A000030
	s_waitcnt lgkmcnt(1)                                       // 000000A7693C: BF89FC17
	.long 0xd73d0037                                           // 000000A76940: D73D0037
	v_cndmask_b32_e32 v1, v44, v55, vcc_lo                     // 000000A76944: 02026F2C
	v_dot2acc_f32_f16 v32, v65, v18                            // 000000A76948: 04402541
	v_pk_fma_f16 v56, v62, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A7694C: CC0E0038 0BFC0B3E 0000C931
	v_lshl_or_b32 v62, v64, 16, v63                            // 000000A76958: D656003E 04FD2140
	v_sad_u8 v53, v53, 0, 0x6400                               // 000000A76960: D6220035 03FD0135 00006400
	v_lshlrev_b32_e32 v63, 16, v66                             // 000000A7696C: 307E8490
	v_bfe_u32 v64, v55, 12, 16                                 // 000000A76970: D6100040 02411937
	v_dot2acc_f32_f16 v32, v56, v19                            // 000000A76978: 04402738
	v_pk_fma_f16 v61, v62, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A7697C: CC0E003D 0BFC0B3E 0000C931
	v_bfe_u32 v62, v55, 8, 16                                  // 000000A76988: D610003E 02411137
	v_and_or_b32 v53, 0xffff, v53, v63                         // 000000A76990: D6570035 04FE6AFF 0000FFFF
	.long 0xd72c0038                                           // 000000A7699C: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v64, vcc_lo              // 000000A769A0: 020280FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A769A8: BF870214
	v_dot2acc_f32_f16 v32, v61, v20                            // 000000A769AC: 0440293D
	.long 0xd72c003d                                           // 000000A769B0: D72C003D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v62, vcc_lo              // 000000A769B4: 02027CFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A769BC: BF870004
	v_pk_fma_f16 v60, v53, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A769C0: CC0E003C 0BFC0B35 0000C931
	v_bfe_u32 v53, v55, 4, 16                                  // 000000A769CC: D6100035 02410937
	v_and_b32_e32 v55, 0xffff, v55                             // 000000A769D4: 366E6EFF 0000FFFF
	s_waitcnt lgkmcnt(0)                                       // 000000A769DC: BF89FC07
	v_bfe_u32 v62, v58, 12, 16                                 // 000000A769E0: D610003E 0241193A
	v_and_b32_e32 v64, 0xffff, v58                             // 000000A769E8: 368074FF 0000FFFF
	v_sad_u8 v56, v56, 0, 0x6400                               // 000000A769F0: D6220038 03FD0138 00006400
	.long 0xd72c0037                                           // 000000A769FC: D72C0037
	v_cndmask_b32_e32 v1, 0x83dcd12d, v55, vcc_lo              // 000000A76A00: 02026EFF 83DCD12D
	.long 0xd72c0035                                           // 000000A76A08: D72C0035
	v_cndmask_b32_e32 v1, 0x83dcd12d, v53, vcc_lo              // 000000A76A0C: 02026AFF 83DCD12D
	.long 0xd72c003e                                           // 000000A76A14: D72C003E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v62, vcc_lo              // 000000A76A18: 02027CFF 83DCD12D
	.long 0xd72c0040                                           // 000000A76A20: D72C0040
	v_cndmask_b32_e32 v1, 0x83dcd12d, v64, vcc_lo              // 000000A76A24: 020280FF 83DCD12D
	v_bfe_u32 v63, v58, 8, 16                                  // 000000A76A2C: D610003F 0241113A
	v_and_b32_e32 v56, 0xffff, v56                             // 000000A76A34: 367070FF 0000FFFF
	v_sad_u8 v61, v61, 0, 0x6400                               // 000000A76A3C: D622003D 03FD013D 00006400
	v_bfe_u32 v58, v58, 4, 16                                  // 000000A76A48: D610003A 0241093A
	v_sad_u8 v55, v55, 0, 0x6400                               // 000000A76A50: D6220037 03FD0137 00006400
	v_dot2acc_f32_f16 v32, v60, v21                            // 000000A76A5C: 04402B3C
	v_sad_u8 v62, v62, 0, 0x6400                               // 000000A76A60: D622003E 03FD013E 00006400
	v_lshl_or_b32 v56, v61, 16, v56                            // 000000A76A6C: D6560038 04E1213D
	.long 0xd72c003d                                           // 000000A76A74: D72C003D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v63, vcc_lo              // 000000A76A78: 02027EFF 83DCD12D
	v_sad_u8 v63, v53, 0, 0x6400                               // 000000A76A80: D622003F 03FD0135 00006400
	v_lshlrev_b32_e32 v65, 16, v55                             // 000000A76A8C: 30826E90
	v_sad_u8 v53, v64, 0, 0x6400                               // 000000A76A90: D6220035 03FD0140 00006400
	v_mov_b32_e32 v55, v57                                     // 000000A76A9C: 7E6E0339
	v_and_b32_e32 v57, 0xffff, v62                             // 000000A76AA0: 36727CFF 0000FFFF
	.long 0xd72c003a                                           // 000000A76AA8: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 000000A76AAC: 020274FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A76AB4: BF870214
	v_lshlrev_b32_e32 v62, 16, v53                             // 000000A76AB8: 307C6A90
	.long 0xd73d0035                                           // 000000A76ABC: D73D0035
	v_cndmask_b32_e32 v1, v44, v54, vcc_lo                     // 000000A76AC0: 02026D2C
	v_sad_u8 v61, v61, 0, 0x6400                               // 000000A76AC4: D622003D 03FD013D 00006400
	v_and_or_b32 v54, 0xffff, v63, v65                         // 000000A76AD0: D6570036 05067EFF 0000FFFF
	v_pk_fma_f16 v55, v56, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A76ADC: CC0E0037 0BFC0B38 0000C931
	v_bfe_u32 v63, v59, 4, 16                                  // 000000A76AE8: D610003F 0241093B
	v_sad_u8 v58, v58, 0, 0x6400                               // 000000A76AF0: D622003A 03FD013A 00006400
	v_lshl_or_b32 v56, v61, 16, v57                            // 000000A76AFC: D6560038 04E5213D
	v_pk_fma_f16 v54, v54, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A76B04: CC0E0036 0BFC0B36 0000C931
	v_dot2acc_f32_f16 v31, v55, v18                            // 000000A76B10: 043E2537
	.long 0xd72c003f                                           // 000000A76B14: D72C003F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v63, vcc_lo              // 000000A76B18: 02027EFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000A76B20: BF870224
	v_pk_fma_f16 v60, v56, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A76B24: CC0E003C 0BFC0B38 0000C931
	v_bfe_u32 v56, v53, 8, 16                                  // 000000A76B30: D6100038 02411135
	v_dot2acc_f32_f16 v31, v54, v19                            // 000000A76B38: 043E2736
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A76B3C: BF870112
	.long 0xd72c0038                                           // 000000A76B40: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v56, vcc_lo              // 000000A76B44: 020270FF 83DCD12D
	v_dot2acc_f32_f16 v31, v60, v20                            // 000000A76B4C: 043E293C
	v_and_or_b32 v57, 0xffff, v58, v62                         // 000000A76B50: D6570039 04FA74FF 0000FFFF
	v_bfe_u32 v58, v53, 12, 16                                 // 000000A76B5C: D610003A 02411935
	v_bfe_u32 v62, v59, 8, 16                                  // 000000A76B64: D610003E 0241113B
	v_sad_u8 v63, v63, 0, 0x6400                               // 000000A76B6C: D622003F 03FD013F 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A76B78: BF870214
	v_pk_fma_f16 v61, v57, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A76B7C: CC0E003D 0BFC0B39 0000C931
	.long 0xd72c0037                                           // 000000A76B88: D72C0037
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 000000A76B8C: 020274FF 83DCD12D
	v_bfe_u32 v57, v53, 4, 16                                  // 000000A76B94: D6100039 02410935
	v_and_b32_e32 v53, 0xffff, v53                             // 000000A76B9C: 366A6AFF 0000FFFF
	v_bfe_u32 v58, v59, 12, 16                                 // 000000A76BA4: D610003A 0241193B
	v_and_b32_e32 v59, 0xffff, v59                             // 000000A76BAC: 367676FF 0000FFFF
	v_sad_u8 v65, v56, 0, 0x6400                               // 000000A76BB4: D6220041 03FD0138 00006400
	.long 0xd72c0042                                           // 000000A76BC0: D72C0042
	v_cndmask_b32_e32 v1, 0x83dcd12d, v57, vcc_lo              // 000000A76BC4: 020272FF 83DCD12D
	.long 0xd72c0040                                           // 000000A76BCC: D72C0040
	v_cndmask_b32_e32 v1, 0x83dcd12d, v53, vcc_lo              // 000000A76BD0: 02026AFF 83DCD12D
	v_sad_u8 v55, v55, 0, 0x6400                               // 000000A76BD8: D6220037 03FD0137 00006400
	ds_load_2addr_b32 v[53:54], v52 offset0:192 offset1:224    // 000000A76BE4: D8DCE0C0 35000034
	ds_load_2addr_b32 v[56:57], v51 offset0:192 offset1:224    // 000000A76BEC: D8DCE0C0 38000033
	.long 0xd72c003b                                           // 000000A76BF4: D72C003B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 000000A76BF8: 020276FF 83DCD12D
	.long 0xd72c003a                                           // 000000A76C00: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 000000A76C04: 020274FF 83DCD12D
	v_and_b32_e32 v55, 0xffff, v55                             // 000000A76C0C: 366E6EFF 0000FFFF
	.long 0xd72c003e                                           // 000000A76C14: D72C003E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v62, vcc_lo              // 000000A76C18: 02027CFF 83DCD12D
	v_sad_u8 v66, v66, 0, 0x6400                               // 000000A76C20: D6220042 03FD0142 00006400
	v_dot2acc_f32_f16 v31, v61, v21                            // 000000A76C2C: 043E2B3D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000A76C30: BF870244
	v_lshl_or_b32 v65, v65, 16, v55                            // 000000A76C34: D6560041 04DD2141
	v_sad_u8 v55, v64, 0, 0x6400                               // 000000A76C3C: D6220037 03FD0140 00006400
	v_sad_u8 v64, v58, 0, 0x6400                               // 000000A76C48: D6220040 03FD013A 00006400
	v_sad_u8 v62, v62, 0, 0x6400                               // 000000A76C54: D622003E 03FD013E 00006400
	v_pk_fma_f16 v65, v65, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A76C60: CC0E0041 0BFC0B41 0000C931
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A76C6C: BF870004
	v_lshlrev_b32_e32 v67, 16, v55                             // 000000A76C70: 30866E90
	v_sad_u8 v55, v59, 0, 0x6400                               // 000000A76C74: D6220037 03FD013B 00006400
	ds_load_2addr_b32 v[58:59], v48 offset0:192 offset1:224    // 000000A76C80: D8DCE0C0 3A000030
	v_and_b32_e32 v64, 0xffff, v64                             // 000000A76C88: 368080FF 0000FFFF
	v_dot2acc_f32_f16 v30, v65, v18                            // 000000A76C90: 043C2541
	s_waitcnt lgkmcnt(2)                                       // 000000A76C94: BF89FC27
	v_dual_mov_b32 v55, v53 :: v_dual_lshlrev_b32 v68, 16, v55 // 000000A76C98: CA220135 37446E90
	v_and_or_b32 v53, 0xffff, v66, v67                         // 000000A76CA0: D6570035 050E84FF 0000FFFF
	v_lshl_or_b32 v62, v62, 16, v64                            // 000000A76CAC: D656003E 0501213E
	s_delay_alu instid0(VALU_DEP_3)                            // 000000A76CB4: BF870003
	v_and_or_b32 v63, 0xffff, v63, v68                         // 000000A76CB8: D657003F 05127EFF 0000FFFF
	s_waitcnt lgkmcnt(1)                                       // 000000A76CC4: BF89FC17
	.long 0xd73d0037                                           // 000000A76CC8: D73D0037
	v_cndmask_b32_e32 v1, v44, v55, vcc_lo                     // 000000A76CCC: 02026F2C
	v_pk_fma_f16 v53, v53, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A76CD0: CC0E0035 0BFC0B35 0000C931
	v_pk_fma_f16 v56, v62, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A76CDC: CC0E0038 0BFC0B3E 0000C931
	v_pk_fma_f16 v60, v63, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A76CE8: CC0E003C 0BFC0B3F 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A76CF4: BF870214
	v_bfe_u32 v62, v55, 12, 16                                 // 000000A76CF8: D610003E 02411937
	v_dot2acc_f32_f16 v30, v53, v19                            // 000000A76D00: 043C2735
	v_and_b32_e32 v53, 0xffff, v55                             // 000000A76D04: 366A6EFF 0000FFFF
	v_bfe_u32 v63, v55, 8, 16                                  // 000000A76D0C: D610003F 02411137
	s_waitcnt lgkmcnt(0)                                       // 000000A76D14: BF89FC07
	v_bfe_u32 v64, v58, 12, 16                                 // 000000A76D18: D6100040 0241193A
	.long 0xd72c003e                                           // 000000A76D20: D72C003E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v62, vcc_lo              // 000000A76D24: 02027CFF 83DCD12D
	v_bfe_u32 v55, v55, 4, 16                                  // 000000A76D2C: D6100037 02410937
	.long 0xd72c0035                                           // 000000A76D34: D72C0035
	v_cndmask_b32_e32 v1, 0x83dcd12d, v53, vcc_lo              // 000000A76D38: 02026AFF 83DCD12D
	.long 0xd72c003f                                           // 000000A76D40: D72C003F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v63, vcc_lo              // 000000A76D44: 02027EFF 83DCD12D
	v_bfe_u32 v65, v58, 8, 16                                  // 000000A76D4C: D6100041 0241113A
	.long 0xd72c0040                                           // 000000A76D54: D72C0040
	v_cndmask_b32_e32 v1, 0x83dcd12d, v64, vcc_lo              // 000000A76D58: 020280FF 83DCD12D
	.long 0xd72c0037                                           // 000000A76D60: D72C0037
	v_cndmask_b32_e32 v1, 0x83dcd12d, v55, vcc_lo              // 000000A76D64: 02026EFF 83DCD12D
	v_dot2acc_f32_f16 v30, v56, v20                            // 000000A76D6C: 043C2938
	v_sad_u8 v62, v62, 0, 0x6400                               // 000000A76D70: D622003E 03FD013E 00006400
	.long 0xd72c0041                                           // 000000A76D7C: D72C0041
	v_cndmask_b32_e32 v1, 0x83dcd12d, v65, vcc_lo              // 000000A76D80: 020282FF 83DCD12D
	v_sad_u8 v53, v53, 0, 0x6400                               // 000000A76D88: D6220035 03FD0135 00006400
	v_sad_u8 v63, v63, 0, 0x6400                               // 000000A76D94: D622003F 03FD013F 00006400
	v_bfe_u32 v66, v58, 4, 16                                  // 000000A76DA0: D6100042 0241093A
	v_and_b32_e32 v62, 0xffff, v62                             // 000000A76DA8: 367C7CFF 0000FFFF
	v_sad_u8 v64, v64, 0, 0x6400                               // 000000A76DB0: D6220040 03FD0140 00006400
	v_sad_u8 v67, v55, 0, 0x6400                               // 000000A76DBC: D6220043 03FD0137 00006400
	v_lshlrev_b32_e32 v53, 16, v53                             // 000000A76DC8: 306A6A90
	v_mov_b32_e32 v55, v57                                     // 000000A76DCC: 7E6E0339
	v_lshl_or_b32 v62, v63, 16, v62                            // 000000A76DD0: D656003E 04F9213F
	v_and_b32_e32 v64, 0xffff, v64                             // 000000A76DD8: 368080FF 0000FFFF
	v_sad_u8 v57, v65, 0, 0x6400                               // 000000A76DE0: D6220039 03FD0141 00006400
	v_and_or_b32 v63, 0xffff, v67, v53                         // 000000A76DEC: D657003F 04D686FF 0000FFFF
	.long 0xd73d0035                                           // 000000A76DF8: D73D0035
	v_cndmask_b32_e32 v1, v44, v54, vcc_lo                     // 000000A76DFC: 02026D2C
	v_pk_fma_f16 v56, v62, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A76E00: CC0E0038 0BFC0B3E 0000C931
	.long 0xd72c0041                                           // 000000A76E0C: D72C0041
	v_cndmask_b32_e32 v1, 0x83dcd12d, v66, vcc_lo              // 000000A76E10: 020284FF 83DCD12D
	v_lshl_or_b32 v54, v57, 16, v64                            // 000000A76E18: D6560036 05012139
	v_pk_fma_f16 v57, v63, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A76E20: CC0E0039 0BFC0B3F 0000C931
	v_bfe_u32 v66, v59, 8, 16                                  // 000000A76E2C: D6100042 0241113B
	v_dot2acc_f32_f16 v29, v56, v18                            // 000000A76E34: 043A2538
	v_and_b32_e32 v58, 0xffff, v58                             // 000000A76E38: 367474FF 0000FFFF
	v_and_b32_e32 v63, 0xffff, v53                             // 000000A76E40: 367E6AFF 0000FFFF
	v_bfe_u32 v64, v53, 8, 16                                  // 000000A76E48: D6100040 02411135
	v_pk_fma_f16 v54, v54, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A76E50: CC0E0036 0BFC0B36 0000C931
	v_dot2acc_f32_f16 v29, v57, v19                            // 000000A76E5C: 043A2739
	.long 0xd72c0037                                           // 000000A76E60: D72C0037
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 000000A76E64: 020274FF 83DCD12D
	v_bfe_u32 v58, v53, 12, 16                                 // 000000A76E6C: D610003A 02411935
	v_bfe_u32 v53, v53, 4, 16                                  // 000000A76E74: D6100035 02410935
	.long 0xd72c003f                                           // 000000A76E7C: D72C003F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v63, vcc_lo              // 000000A76E80: 02027EFF 83DCD12D
	.long 0xd72c0040                                           // 000000A76E88: D72C0040
	v_cndmask_b32_e32 v1, 0x83dcd12d, v64, vcc_lo              // 000000A76E8C: 020280FF 83DCD12D
	v_sad_u8 v62, v65, 0, 0x6400                               // 000000A76E94: D622003E 03FD0141 00006400
	.long 0xd72c003a                                           // 000000A76EA0: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 000000A76EA4: 020274FF 83DCD12D
	.long 0xd72c0035                                           // 000000A76EAC: D72C0035
	v_cndmask_b32_e32 v1, 0x83dcd12d, v53, vcc_lo              // 000000A76EB0: 02026AFF 83DCD12D
	v_bfe_u32 v65, v59, 12, 16                                 // 000000A76EB8: D6100041 0241193B
	v_dot2acc_f32_f16 v29, v54, v20                            // 000000A76EC0: 043A2936
	v_bfe_u32 v67, v59, 4, 16                                  // 000000A76EC4: D6100043 0241093B
	v_sad_u8 v63, v63, 0, 0x6400                               // 000000A76ECC: D622003F 03FD013F 00006400
	v_sad_u8 v64, v64, 0, 0x6400                               // 000000A76ED8: D6220040 03FD0140 00006400
	.long 0xd72c0041                                           // 000000A76EE4: D72C0041
	v_cndmask_b32_e32 v1, 0x83dcd12d, v65, vcc_lo              // 000000A76EE8: 020282FF 83DCD12D
	v_sad_u8 v58, v58, 0, 0x6400                               // 000000A76EF0: D622003A 03FD013A 00006400
	v_sad_u8 v53, v53, 0, 0x6400                               // 000000A76EFC: D6220035 03FD0135 00006400
	v_lshlrev_b32_e32 v63, 16, v63                             // 000000A76F08: 307E7E90
	v_and_b32_e32 v59, 0xffff, v59                             // 000000A76F0C: 367676FF 0000FFFF
	.long 0xd72c0042                                           // 000000A76F14: D72C0042
	v_cndmask_b32_e32 v1, 0x83dcd12d, v66, vcc_lo              // 000000A76F18: 020284FF 83DCD12D
	v_and_b32_e32 v58, 0xffff, v58                             // 000000A76F20: 367474FF 0000FFFF
	v_sad_u8 v55, v55, 0, 0x6400                               // 000000A76F28: D6220037 03FD0137 00006400
	v_and_or_b32 v53, 0xffff, v53, v63                         // 000000A76F34: D6570035 04FE6AFF 0000FFFF
	.long 0xd72c003b                                           // 000000A76F40: D72C003B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 000000A76F44: 020276FF 83DCD12D
	v_sad_u8 v65, v65, 0, 0x6400                               // 000000A76F4C: D6220041 03FD0141 00006400
	v_lshl_or_b32 v58, v64, 16, v58                            // 000000A76F58: D656003A 04E92140
	.long 0xd72c003f                                           // 000000A76F60: D72C003F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v67, vcc_lo              // 000000A76F64: 020286FF 83DCD12D
	v_pk_fma_f16 v53, v53, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A76F6C: CC0E0035 0BFC0B35 0000C931
	v_dual_dot2acc_f32_f16 v30, v60, v21 :: v_dual_lshlrev_b32 v55, 16, v55// 000000A76F78: CB222B3C 1E366E90
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000A76F80: BF870134
	v_pk_fma_f16 v58, v58, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A76F84: CC0E003A 0BFC0B3A 0000C931
	v_sad_u8 v56, v59, 0, 0x6400                               // 000000A76F90: D6220038 03FD013B 00006400
	v_sad_u8 v63, v63, 0, 0x6400                               // 000000A76F9C: D622003F 03FD013F 00006400
	v_dual_dot2acc_f32_f16 v1, v58, v18 :: v_dual_lshlrev_b32 v56, 16, v56// 000000A76FA8: CB22253A 01387090
	v_and_or_b32 v18, 0xffff, v62, v55                         // 000000A76FB0: D6570012 04DE7CFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000A76FBC: BF870222
	v_dual_dot2acc_f32_f16 v1, v53, v19 :: v_dual_and_b32 v64, 0xffff, v65// 000000A76FC0: CB242735 014082FF 0000FFFF
	v_sad_u8 v65, v66, 0, 0x6400                               // 000000A76FCC: D6220041 03FD0142 00006400
	v_and_or_b32 v56, 0xffff, v63, v56                         // 000000A76FD8: D6570038 04E27EFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000A76FE4: BF870224
	v_pk_fma_f16 v18, v18, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A76FE8: CC0E0012 0BFC0B12 0000C931
	v_add_nc_u32_e32 v46, 1, v46                               // 000000A76FF4: 4A5C5C81
	v_lshl_or_b32 v59, v65, 16, v64                            // 000000A76FF8: D656003B 05012141
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A77000: BF870214
	v_pk_fma_f16 v19, v56, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A77004: CC0E0013 0BFC0B38 0000C931
	v_dot2acc_f32_f16 v29, v18, v21                            // 000000A77010: 043A2B12
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A77014: BF870093
	v_pk_fma_f16 v55, v59, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A77018: CC0E0037 0BFC0B3B 0000C931
	v_dual_dot2acc_f32_f16 v1, v55, v20 :: v_dual_add_nc_u32 v20, v45, v46// 000000A77024: CB202937 01145D2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A7702C: BF870111
	v_dot2acc_f32_f16 v1, v19, v21                             // 000000A77030: 04022B13
	v_cmp_eq_u32_e32 vcc_lo, 21, v20                           // 000000A77034: 7C942895
	s_or_b32 s4, vcc_lo, s4                                    // 000000A77038: 8C04046A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000A7703C: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000A77040: 917E047E
	s_cbranch_execz 62                                         // 000000A77044: BFA5003E <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi0EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x4a40>
	s_mov_b32 s0, exec_lo                                      // 000000A77048: BE80007E
	s_waitcnt vmcnt(14)                                        // 000000A7704C: BF893BF7
	ds_store_2addr_b32 v47, v2, v3 offset1:32                  // 000000A77050: D8382000 0003022F
	s_waitcnt vmcnt(12)                                        // 000000A77058: BF8933F7
	ds_store_2addr_b32 v47, v4, v5 offset0:64 offset1:96       // 000000A7705C: D8386040 0005042F
	s_waitcnt vmcnt(10)                                        // 000000A77064: BF892BF7
	ds_store_2addr_b32 v47, v6, v7 offset0:128 offset1:160     // 000000A77068: D838A080 0007062F
	s_waitcnt vmcnt(8)                                         // 000000A77070: BF8923F7
	ds_store_2addr_b32 v47, v8, v9 offset0:192 offset1:224     // 000000A77074: D838E0C0 0009082F
	s_waitcnt vmcnt(6)                                         // 000000A7707C: BF891BF7
	ds_store_2addr_b32 v48, v10, v11 offset1:32                // 000000A77080: D8382000 000B0A30
	s_waitcnt vmcnt(4)                                         // 000000A77088: BF8913F7
	ds_store_2addr_b32 v48, v12, v13 offset0:64 offset1:96     // 000000A7708C: D8386040 000D0C30
	s_waitcnt vmcnt(2)                                         // 000000A77094: BF890BF7
	ds_store_2addr_b32 v48, v14, v15 offset0:128 offset1:160   // 000000A77098: D838A080 000F0E30
	s_waitcnt vmcnt(0)                                         // 000000A770A0: BF8903F7
	ds_store_2addr_b32 v48, v16, v17 offset0:192 offset1:224   // 000000A770A4: D838E0C0 00111030
	.long 0xd4c9007e                                           // 000000A770AC: D4C9007E
	v_cndmask_b32_e32 v1, v46, v27, vcc_lo                     // 000000A770B0: 0202372E
	s_cbranch_execz 63785                                      // 000000A770B4: BFA5F929 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi0EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x2e5c>
	s_clause 0xf                                               // 000000A770B8: BF85000F
	global_load_b32 v2, v[22:23], off                          // 000000A770BC: DC520000 027C0016
	global_load_b32 v3, v[22:23], off offset:128               // 000000A770C4: DC520080 037C0016
	global_load_b32 v4, v[22:23], off offset:256               // 000000A770CC: DC520100 047C0016
	global_load_b32 v5, v[22:23], off offset:384               // 000000A770D4: DC520180 057C0016
	global_load_b32 v6, v[22:23], off offset:512               // 000000A770DC: DC520200 067C0016
	global_load_b32 v7, v[22:23], off offset:640               // 000000A770E4: DC520280 077C0016
	global_load_b32 v8, v[22:23], off offset:768               // 000000A770EC: DC520300 087C0016
	global_load_b32 v9, v[22:23], off offset:896               // 000000A770F4: DC520380 097C0016
	global_load_b32 v10, v[22:23], off offset:1024             // 000000A770FC: DC520400 0A7C0016
	global_load_b32 v11, v[22:23], off offset:1152             // 000000A77104: DC520480 0B7C0016
	global_load_b32 v12, v[22:23], off offset:1280             // 000000A7710C: DC520500 0C7C0016
	global_load_b32 v13, v[22:23], off offset:1408             // 000000A77114: DC520580 0D7C0016
	global_load_b32 v14, v[22:23], off offset:1536             // 000000A7711C: DC520600 0E7C0016
	global_load_b32 v15, v[22:23], off offset:1664             // 000000A77124: DC520680 0F7C0016
	global_load_b32 v16, v[22:23], off offset:1792             // 000000A7712C: DC520700 107C0016
	global_load_b32 v17, v[22:23], off offset:1920             // 000000A77134: DC520780 117C0016
	s_branch 63751                                             // 000000A7713C: BFA0F907 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi0EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x2e5c>
	s_or_b32 exec_lo, exec_lo, s4                              // 000000A77140: 8C7E047E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000A77144: BF870009
	s_or_b32 exec_lo, exec_lo, s3                              // 000000A77148: 8C7E037E
	s_waitcnt vmcnt(14)                                        // 000000A7714C: BF893BF7
	v_dual_mov_b32 v2, v28 :: v_dual_mov_b32 v3, v42           // 000000A77150: CA10011C 0202012A
	s_waitcnt vmcnt(12)                                        // 000000A77158: BF8933F7
	v_dual_mov_b32 v4, v41 :: v_dual_mov_b32 v5, v40           // 000000A7715C: CA100129 04040128
	s_waitcnt vmcnt(10)                                        // 000000A77164: BF892BF7
	v_dual_mov_b32 v6, v39 :: v_dual_mov_b32 v7, v38           // 000000A77168: CA100127 06060126
	s_waitcnt vmcnt(8)                                         // 000000A77170: BF8923F7
	v_dual_mov_b32 v8, v37 :: v_dual_mov_b32 v9, v36           // 000000A77174: CA100125 08080124
	s_waitcnt vmcnt(6)                                         // 000000A7717C: BF891BF7
	v_dual_mov_b32 v10, v35 :: v_dual_mov_b32 v11, v34         // 000000A77180: CA100123 0A0A0122
	s_waitcnt vmcnt(4)                                         // 000000A77188: BF8913F7
	v_dual_mov_b32 v12, v33 :: v_dual_mov_b32 v13, v32         // 000000A7718C: CA100121 0C0C0120
	s_waitcnt vmcnt(2)                                         // 000000A77194: BF890BF7
	v_dual_mov_b32 v14, v31 :: v_dual_mov_b32 v15, v30         // 000000A77198: CA10011F 0E0E011E
	s_waitcnt vmcnt(1)                                         // 000000A771A0: BF8907F7
	v_mov_b32_e32 v16, v29                                     // 000000A771A4: 7E20031D
	s_waitcnt vmcnt(0)                                         // 000000A771A8: BF8903F7
	v_mov_b32_e32 v17, v1                                      // 000000A771AC: 7E220301
	s_mov_b32 s0, 0x76543210                                   // 000000A771B0: BE8000FF 76543210
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000A771B8: BF870009
	v_permlanex16_b32 v2, v2, s0, 0xfedcba98                   // 000000A771BC: D65C0002 03FC0102 FEDCBA98
	v_permlanex16_b32 v3, v3, s0, 0xfedcba98                   // 000000A771C8: D65C0003 03FC0103 FEDCBA98
	v_permlanex16_b32 v4, v4, s0, 0xfedcba98                   // 000000A771D4: D65C0004 03FC0104 FEDCBA98
	v_permlanex16_b32 v5, v5, s0, 0xfedcba98                   // 000000A771E0: D65C0005 03FC0105 FEDCBA98
	v_permlanex16_b32 v6, v6, s0, 0xfedcba98                   // 000000A771EC: D65C0006 03FC0106 FEDCBA98
	v_permlanex16_b32 v7, v7, s0, 0xfedcba98                   // 000000A771F8: D65C0007 03FC0107 FEDCBA98
	v_permlanex16_b32 v8, v8, s0, 0xfedcba98                   // 000000A77204: D65C0008 03FC0108 FEDCBA98
	v_permlanex16_b32 v9, v9, s0, 0xfedcba98                   // 000000A77210: D65C0009 03FC0109 FEDCBA98
	v_permlanex16_b32 v10, v10, s0, 0xfedcba98                 // 000000A7721C: D65C000A 03FC010A FEDCBA98
	v_permlanex16_b32 v11, v11, s0, 0xfedcba98                 // 000000A77228: D65C000B 03FC010B FEDCBA98
	v_permlanex16_b32 v12, v12, s0, 0xfedcba98                 // 000000A77234: D65C000C 03FC010C FEDCBA98
	v_permlanex16_b32 v13, v13, s0, 0xfedcba98                 // 000000A77240: D65C000D 03FC010D FEDCBA98
	v_permlanex16_b32 v14, v14, s0, 0xfedcba98                 // 000000A7724C: D65C000E 03FC010E FEDCBA98
	v_permlanex16_b32 v15, v15, s0, 0xfedcba98                 // 000000A77258: D65C000F 03FC010F FEDCBA98
	v_permlanex16_b32 v16, v16, s0, 0xfedcba98                 // 000000A77264: D65C0010 03FC0110 FEDCBA98
	v_permlanex16_b32 v17, v17, s0, 0xfedcba98                 // 000000A77270: D65C0011 03FC0111 FEDCBA98
	.long 0xd44c0000                                           // 000000A7727C: D44C0000
	v_cndmask_b32_e32 v1, 16, v25, vcc_lo                      // 000000A77280: 02023290
	s_barrier                                                  // 000000A77284: BFBD0000
	buffer_gl0_inv                                             // 000000A77288: E0AC0000 00000000
	s_and_saveexec_b32 s3, s0                                  // 000000A77290: BE832000
	s_cbranch_execz 34                                         // 000000A77294: BFA50022 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi0EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x4c20>
	v_dual_add_f32 v1, v1, v17 :: v_dual_add_f32 v2, v28, v2   // 000000A77298: C9082301 0102051C
	v_dual_add_f32 v3, v42, v3 :: v_dual_add_f32 v4, v41, v4   // 000000A772A0: C908072A 03040929
	v_lshl_or_b32 v17, v24, 10, v26                            // 000000A772A8: D6560011 04691518
	v_dual_add_f32 v5, v40, v5 :: v_dual_add_f32 v6, v39, v6   // 000000A772B0: C9080B28 05060D27
	v_dual_add_f32 v7, v38, v7 :: v_dual_add_f32 v8, v37, v8   // 000000A772B8: C9080F26 07081125
	v_dual_add_f32 v9, v36, v9 :: v_dual_add_f32 v10, v35, v10 // 000000A772C0: C9081324 090A1523
	v_dual_add_f32 v11, v34, v11 :: v_dual_add_f32 v12, v33, v12// 000000A772C8: C9081722 0B0C1921
	v_dual_add_f32 v13, v32, v13 :: v_dual_add_f32 v14, v31, v14// 000000A772D0: C9081B20 0D0E1D1F
	v_dual_add_f32 v15, v30, v15 :: v_dual_add_f32 v16, v29, v16// 000000A772D8: C9081F1E 0F10211D
	ds_store_2addr_b32 v17, v2, v3 offset1:16                  // 000000A772E0: D8381000 00030211
	ds_store_2addr_b32 v17, v4, v5 offset0:32 offset1:48       // 000000A772E8: D8383020 00050411
	ds_store_2addr_b32 v17, v6, v7 offset0:64 offset1:80       // 000000A772F0: D8385040 00070611
	ds_store_2addr_b32 v17, v8, v9 offset0:96 offset1:112      // 000000A772F8: D8387060 00090811
	ds_store_2addr_b32 v17, v10, v11 offset0:128 offset1:144   // 000000A77300: D8389080 000B0A11
	ds_store_2addr_b32 v17, v12, v13 offset0:160 offset1:176   // 000000A77308: D838B0A0 000D0C11
	ds_store_2addr_b32 v17, v14, v15 offset0:192 offset1:208   // 000000A77310: D838D0C0 000F0E11
	ds_store_2addr_b32 v17, v16, v1 offset0:224 offset1:240    // 000000A77318: D838F0E0 00011011
	s_or_b32 exec_lo, exec_lo, s3                              // 000000A77320: 8C7E037E
	s_waitcnt lgkmcnt(0)                                       // 000000A77324: BF89FC07
	s_barrier                                                  // 000000A77328: BFBD0000
	buffer_gl0_inv                                             // 000000A7732C: E0AC0000 00000000
	s_mov_b32 s3, exec_lo                                      // 000000A77334: BE83007E
	v_cmpx_eq_u32_e32 0, v24                                   // 000000A77338: 7D943080
	s_cbranch_execz 1332                                       // 000000A7733C: BFA50534 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi0EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x6110>
	v_and_b32_e32 v3, 15, v0                                   // 000000A77340: 3606008F
	s_mul_i32 s3, s1, 0xa00                                    // 000000A77344: 9603FF01 00000A00
	s_mul_hi_i32 s4, s1, 0xa00                                 // 000000A7734C: 9704FF01 00000A00
	s_add_u32 s5, s18, s3                                      // 000000A77354: 80050312
	s_addc_u32 s4, s19, s4                                     // 000000A77358: 82040413
	v_lshlrev_b32_e32 v4, 2, v3                                // 000000A7735C: 30080682
	s_lshl_b32 s2, s2, 7                                       // 000000A77360: 84028702
	ds_load_2addr_b32 v[1:2], v4 offset1:16                    // 000000A77364: D8DC1000 01000004
	ds_load_2addr_b32 v[5:6], v4 offset0:128 offset1:144       // 000000A7736C: D8DC9080 05000004
	s_ashr_i32 s3, s2, 31                                      // 000000A77374: 86039F02
	v_lshlrev_b32_e32 v52, 1, v0                               // 000000A77378: 30680081
	s_lshl_b64 s[12:13], s[2:3], 1                             // 000000A7737C: 848C8102
	s_mul_i32 s2, s1, 0x500                                    // 000000A77380: 9602FF01 00000500
	s_add_u32 s6, s5, s12                                      // 000000A77388: 80060C05
	s_addc_u32 s7, s4, s13                                     // 000000A7738C: 82070D04
	s_mul_hi_i32 s1, s1, 0x500                                 // 000000A77390: 9701FF01 00000500
	s_add_u32 s2, s20, s2                                      // 000000A77398: 80020214
	s_addc_u32 s1, s21, s1                                     // 000000A7739C: 82010115
	s_add_u32 s8, s2, s12                                      // 000000A773A0: 80080C02
	s_addc_u32 s9, s1, s13                                     // 000000A773A4: 82090D01
	s_waitcnt lgkmcnt(1)                                       // 000000A773A8: BF89FC17
	v_add_f32_e32 v1, 0, v1                                    // 000000A773AC: 06020280
	v_add_nc_u32_e32 v45, 0x400, v4                            // 000000A773B0: 4A5A08FF 00000400
	s_waitcnt lgkmcnt(0)                                       // 000000A773B8: BF89FC07
	v_dual_add_f32 v5, 0, v5 :: v_dual_add_nc_u32 v46, 0x800, v4// 000000A773BC: C9200A80 052E08FF 00000800
	v_add_nc_u32_e32 v47, 0xc00, v4                            // 000000A773C8: 4A5E08FF 00000C00
	v_add_nc_u32_e32 v48, 0x1000, v4                           // 000000A773D0: 4A6008FF 00001000
	v_add_nc_u32_e32 v49, 0x1400, v4                           // 000000A773D8: 4A6208FF 00001400
	v_add_nc_u32_e32 v50, 0x1800, v4                           // 000000A773E0: 4A6408FF 00001800
	v_add_nc_u32_e32 v51, 0x1c00, v4                           // 000000A773E8: 4A6608FF 00001C00
	ds_load_2addr_b32 v[7:8], v45 offset1:16                   // 000000A773F0: D8DC1000 0700002D
	ds_load_2addr_b32 v[9:10], v4 offset0:32 offset1:48        // 000000A773F8: D8DC3020 09000004
	ds_load_2addr_b32 v[11:12], v4 offset0:160 offset1:176     // 000000A77400: D8DCB0A0 0B000004
	ds_load_2addr_b32 v[13:14], v45 offset0:128 offset1:144    // 000000A77408: D8DC9080 0D00002D
	ds_load_2addr_b32 v[15:16], v46 offset1:16                 // 000000A77410: D8DC1000 0F00002E
	ds_load_2addr_b32 v[17:18], v46 offset0:128 offset1:144    // 000000A77418: D8DC9080 1100002E
	ds_load_2addr_b32 v[19:20], v47 offset1:16                 // 000000A77420: D8DC1000 1300002F
	ds_load_2addr_b32 v[21:22], v47 offset0:128 offset1:144    // 000000A77428: D8DC9080 1500002F
	ds_load_2addr_b32 v[23:24], v48 offset1:16                 // 000000A77430: D8DC1000 17000030
	ds_load_2addr_b32 v[25:26], v48 offset0:128 offset1:144    // 000000A77438: D8DC9080 19000030
	ds_load_2addr_b32 v[27:28], v49 offset1:16                 // 000000A77440: D8DC1000 1B000031
	ds_load_2addr_b32 v[29:30], v49 offset0:128 offset1:144    // 000000A77448: D8DC9080 1D000031
	ds_load_2addr_b32 v[31:32], v50 offset1:16                 // 000000A77450: D8DC1000 1F000032
	ds_load_2addr_b32 v[33:34], v50 offset0:128 offset1:144    // 000000A77458: D8DC9080 21000032
	ds_load_2addr_b32 v[35:36], v51 offset1:16                 // 000000A77460: D8DC1000 23000033
	v_add_f32_e32 v2, 0, v2                                    // 000000A77468: 06040480
	ds_load_2addr_b32 v[43:44], v46 offset0:32 offset1:48      // 000000A7746C: D8DC3020 2B00002E
	s_waitcnt lgkmcnt(15)                                      // 000000A77474: BF89FCF7
	v_add_f32_e32 v1, v1, v7                                   // 000000A77478: 06020F01
	v_dual_add_f32 v7, 0, v6 :: v_dual_add_f32 v2, v2, v8      // 000000A7747C: C9080C80 07021102
	s_waitcnt lgkmcnt(12)                                      // 000000A77484: BF89FCC7
	v_add_f32_e32 v13, v5, v13                                 // 000000A77488: 061A1B05
	ds_load_2addr_b32 v[5:6], v46 offset0:160 offset1:176      // 000000A7748C: D8DCB0A0 0500002E
	s_waitcnt lgkmcnt(12)                                      // 000000A77494: BF89FCC7
	v_dual_add_f32 v1, v1, v15 :: v_dual_add_f32 v14, v7, v14  // 000000A77498: C9081F01 010E1D07
	s_waitcnt lgkmcnt(11)                                      // 000000A774A0: BF89FCB7
	v_dual_add_f32 v2, v2, v16 :: v_dual_add_f32 v13, v13, v17 // 000000A774A4: C9082102 020C230D
	ds_load_2addr_b32 v[15:16], v48 offset0:32 offset1:48      // 000000A774AC: D8DC3020 0F000030
	v_add_f32_e32 v14, v14, v18                                // 000000A774B4: 061C250E
	s_waitcnt lgkmcnt(11)                                      // 000000A774B8: BF89FCB7
	v_dual_add_f32 v2, v2, v20 :: v_dual_add_f32 v1, v1, v19   // 000000A774BC: C9082902 02002701
	ds_load_2addr_b32 v[7:8], v47 offset0:32 offset1:48        // 000000A774C4: D8DC3020 0700002F
	ds_load_2addr_b32 v[17:18], v48 offset0:160 offset1:176    // 000000A774CC: D8DCB0A0 11000030
	s_waitcnt lgkmcnt(12)                                      // 000000A774D4: BF89FCC7
	v_add_f32_e32 v14, v14, v22                                // 000000A774D8: 061C2D0E
	s_waitcnt lgkmcnt(11)                                      // 000000A774DC: BF89FCB7
	v_dual_add_f32 v2, v2, v24 :: v_dual_add_f32 v1, v1, v23   // 000000A774E0: C9083102 02002F01
	ds_load_2addr_b32 v[19:20], v49 offset0:32 offset1:48      // 000000A774E8: D8DC3020 13000031
	s_waitcnt lgkmcnt(11)                                      // 000000A774F0: BF89FCB7
	v_add_f32_e32 v14, v14, v26                                // 000000A774F4: 061C350E
	ds_load_2addr_b32 v[37:38], v51 offset0:128 offset1:144    // 000000A774F8: D8DC9080 25000033
	ds_load_2addr_b32 v[39:40], v45 offset0:32 offset1:48      // 000000A77500: D8DC3020 2700002D
	ds_load_2addr_b32 v[41:42], v45 offset0:160 offset1:176    // 000000A77508: D8DCB0A0 2900002D
	v_add_f32_e32 v13, v13, v21                                // 000000A77510: 061A2B0D
	s_waitcnt lgkmcnt(13)                                      // 000000A77514: BF89FCD7
	v_add_f32_e32 v1, v1, v27                                  // 000000A77518: 06023701
	v_add_f32_e32 v23, v2, v28                                 // 000000A7751C: 062E3902
	s_waitcnt lgkmcnt(12)                                      // 000000A77520: BF89FCC7
	v_dual_add_f32 v24, v14, v30 :: v_dual_add_f32 v9, 0, v9   // 000000A77524: C9083D0E 18081280
	ds_load_2addr_b32 v[21:22], v49 offset0:160 offset1:176    // 000000A7752C: D8DCB0A0 15000031
	v_add_f32_e32 v11, 0, v11                                  // 000000A77534: 06161680
	s_waitcnt lgkmcnt(11)                                      // 000000A77538: BF89FCB7
	v_dual_add_f32 v1, v1, v31 :: v_dual_add_f32 v26, v24, v34 // 000000A7753C: C9083F01 011A4518
	s_waitcnt lgkmcnt(3)                                       // 000000A77544: BF89FC37
	s_delay_alu instid0(VALU_DEP_1)                            // 000000A77548: BF870001
	v_dual_add_f32 v13, v13, v25 :: v_dual_add_f32 v54, v26, v38// 000000A7754C: C908330D 0D364D1A
	s_waitcnt lgkmcnt(2)                                       // 000000A77554: BF89FC27
	v_add_f32_e32 v9, v9, v39                                  // 000000A77558: 06124F09
	v_add_f32_e32 v39, v1, v35                                 // 000000A7755C: 064E4701
	v_lshlrev_b32_e32 v1, 1, v3                                // 000000A77560: 30020681
	s_waitcnt lgkmcnt(1)                                       // 000000A77564: BF89FC17
	v_add_f32_e32 v3, v11, v41                                 // 000000A77568: 0606530B
	v_add_f32_e32 v11, v23, v32                                // 000000A7756C: 06164117
	v_add_f32_e32 v9, v9, v43                                  // 000000A77570: 06125709
	ds_load_2addr_b32 v[23:24], v50 offset0:32 offset1:48      // 000000A77574: D8DC3020 17000032
	v_or_b32_e32 v41, 32, v52                                  // 000000A7757C: 385268A0
	v_add_f32_e32 v5, v3, v5                                   // 000000A77580: 060A0B03
	v_add_f32_e32 v53, v11, v36                                // 000000A77584: 066A490B
	v_add_f32_e32 v7, v9, v7                                   // 000000A77588: 060E0F09
	global_load_d16_b16 v3, v41, s[6:7]                        // 000000A7758C: DC820000 03060029
	v_add_f32_e32 v7, v7, v15                                  // 000000A77594: 060E1F07
	v_add_f32_e32 v15, 0, v12                                  // 000000A77598: 061E1880
	ds_load_2addr_b32 v[11:12], v4 offset0:192 offset1:208     // 000000A7759C: D8DCD0C0 0B000004
	ds_load_2addr_b32 v[27:28], v51 offset0:32 offset1:48      // 000000A775A4: D8DC3020 1B000033
	v_add_f32_e32 v7, v7, v19                                  // 000000A775AC: 060E2707
	s_waitcnt lgkmcnt(2)                                       // 000000A775B0: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 000000A775B4: BF870001
	v_add_f32_e32 v19, v7, v23                                 // 000000A775B8: 06262F07
	v_add_f32_e32 v13, v13, v29                                // 000000A775BC: 061A3B0D
	ds_load_2addr_b32 v[29:30], v45 offset0:64 offset1:80      // 000000A775C0: D8DC5040 1D00002D
	ds_load_2addr_b32 v[31:32], v45 offset0:192 offset1:208    // 000000A775C8: D8DCD0C0 1F00002D
	v_add_f32_e32 v25, v13, v33                                // 000000A775D0: 0632430D
	ds_load_2addr_b32 v[13:14], v47 offset0:160 offset1:176    // 000000A775D4: D8DCB0A0 0D00002F
	s_waitcnt lgkmcnt(4)                                       // 000000A775DC: BF89FC47
	v_add_f32_e32 v11, 0, v11                                  // 000000A775E0: 06161680
	v_add_f32_e32 v43, v25, v37                                // 000000A775E4: 06564B19
	ds_load_2addr_b32 v[25:26], v50 offset0:160 offset1:176    // 000000A775E8: D8DCB0A0 19000032
	ds_load_2addr_b32 v[37:38], v48 offset0:192 offset1:208    // 000000A775F0: D8DCD0C0 25000030
	s_waitcnt lgkmcnt(3)                                       // 000000A775F8: BF89FC37
	v_add_f32_e32 v11, v11, v31                                // 000000A775FC: 06163F0B
	s_waitcnt lgkmcnt(2)                                       // 000000A77600: BF89FC27
	v_add_f32_e32 v5, v5, v13                                  // 000000A77604: 060A1B05
	v_add_f32_e32 v13, 0, v10                                  // 000000A77608: 061A1480
	ds_load_2addr_b32 v[9:10], v4 offset0:64 offset1:80        // 000000A7760C: D8DC5040 09000004
	v_add_f32_e32 v5, v5, v17                                  // 000000A77614: 060A2305
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000A77618: BF8701C1
	v_add_f32_e32 v17, v5, v21                                 // 000000A7761C: 06222B05
	v_add_f32_e32 v5, v13, v40                                 // 000000A77620: 060A510D
	v_add_f32_e32 v13, v15, v42                                // 000000A77624: 061A550F
	s_waitcnt lgkmcnt(2)                                       // 000000A77628: BF89FC27
	v_dual_add_f32 v40, v19, v27 :: v_dual_add_f32 v21, v17, v25// 000000A7762C: C9083713 28143311
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A77634: BF870193
	v_add_f32_e32 v7, v5, v44                                  // 000000A77638: 060E5905
	v_add_f32_e32 v13, v13, v6                                 // 000000A7763C: 061A0D0D
	ds_load_2addr_b32 v[5:6], v46 offset0:64 offset1:80        // 000000A77640: D8DC5040 0500002E
	ds_load_2addr_b32 v[33:34], v46 offset0:192 offset1:208    // 000000A77648: D8DCD0C0 2100002E
	ds_load_2addr_b32 v[35:36], v51 offset0:160 offset1:176    // 000000A77650: D8DCB0A0 23000033
	v_add_f32_e32 v15, v7, v8                                  // 000000A77658: 061E1107
	ds_load_2addr_b32 v[7:8], v47 offset0:64 offset1:80        // 000000A7765C: D8DC5040 0700002F
	v_add_f32_e32 v17, v13, v14                                // 000000A77664: 06221D0D
	ds_load_2addr_b32 v[13:14], v47 offset0:192 offset1:208    // 000000A77668: D8DCD0C0 0D00002F
	s_waitcnt lgkmcnt(5)                                       // 000000A77670: BF89FC57
	v_add_f32_e32 v9, 0, v9                                    // 000000A77674: 06121280
	v_add_f32_e32 v23, v15, v16                                // 000000A77678: 062E210F
	ds_load_2addr_b32 v[15:16], v48 offset0:64 offset1:80      // 000000A7767C: D8DC5040 0F000030
	v_add_f32_e32 v17, v17, v18                                // 000000A77684: 06222511
	v_add_f32_e32 v9, v9, v29                                  // 000000A77688: 06123B09
	v_add_f32_e32 v23, v23, v20                                // 000000A7768C: 062E2917
	ds_load_2addr_b32 v[19:20], v49 offset0:192 offset1:208    // 000000A77690: D8DCD0C0 13000031
	v_add_f32_e32 v22, v17, v22                                // 000000A77698: 062C2D11
	ds_load_2addr_b32 v[17:18], v49 offset0:64 offset1:80      // 000000A7769C: D8DC5040 11000031
	s_waitcnt lgkmcnt(7)                                       // 000000A776A4: BF89FC77
	v_add_f32_e32 v5, v9, v5                                   // 000000A776A8: 060A0B09
	s_waitcnt lgkmcnt(5)                                       // 000000A776AC: BF89FC57
	v_dual_add_f32 v9, v11, v33 :: v_dual_add_f32 v42, v21, v35// 000000A776B0: C908430B 092A4715
	v_add_f32_e32 v27, v23, v24                                // 000000A776B8: 06363117
	v_add_f32_e32 v33, v22, v26                                // 000000A776BC: 06423516
	ds_load_2addr_b32 v[21:22], v50 offset0:64 offset1:80      // 000000A776C0: D8DC5040 15000032
	ds_load_2addr_b32 v[23:24], v50 offset0:192 offset1:208    // 000000A776C8: D8DCD0C0 17000032
	s_waitcnt lgkmcnt(6)                                       // 000000A776D0: BF89FC67
	v_add_f32_e32 v5, v5, v7                                   // 000000A776D4: 060A0F05
	s_waitcnt lgkmcnt(5)                                       // 000000A776D8: BF89FC57
	v_add_f32_e32 v7, v9, v13                                  // 000000A776DC: 060E1B09
	s_waitcnt lgkmcnt(4)                                       // 000000A776E0: BF89FC47
	s_delay_alu instid0(VALU_DEP_2)                            // 000000A776E4: BF870002
	v_add_f32_e32 v13, v5, v15                                 // 000000A776E8: 061A1F05
	v_add_f32_e32 v5, 0, v10                                   // 000000A776EC: 060A1480
	ds_load_2addr_b32 v[9:10], v51 offset0:64 offset1:80       // 000000A776F0: D8DC5040 09000033
	ds_load_2addr_b32 v[25:26], v51 offset0:192 offset1:208    // 000000A776F8: D8DCD0C0 19000033
	v_add_f32_e32 v7, v7, v37                                  // 000000A77700: 060E4B07
	v_add_f32_e32 v15, 0, v12                                  // 000000A77704: 061E1880
	ds_load_2addr_b32 v[11:12], v4 offset0:96 offset1:112      // 000000A77708: D8DC7060 0B000004
	v_add_f32_e32 v31, v5, v30                                 // 000000A77710: 063E3D05
	ds_load_2addr_b32 v[29:30], v4 offset0:224 offset1:240     // 000000A77714: D8DCF0E0 1D000004
	s_waitcnt lgkmcnt(6)                                       // 000000A7771C: BF89FC67
	v_dual_add_f32 v13, v13, v17 :: v_dual_add_f32 v4, v15, v32// 000000A77720: C908230D 0D04410F
	v_add_f32_e32 v15, v7, v19                                 // 000000A77728: 061E2707
	v_add_f32_e32 v17, v31, v6                                 // 000000A7772C: 06220D1F
	ds_load_2addr_b32 v[6:7], v45 offset0:96 offset1:112       // 000000A77730: D8DC7060 0600002D
	ds_load_2addr_b32 v[31:32], v45 offset0:224 offset1:240    // 000000A77738: D8DCF0E0 1F00002D
	s_waitcnt lgkmcnt(7)                                       // 000000A77740: BF89FC77
	v_dual_add_f32 v13, v13, v21 :: v_dual_add_f32 v4, v4, v34 // 000000A77744: C9082B0D 0D044504
	s_waitcnt lgkmcnt(6)                                       // 000000A7774C: BF89FC67
	v_dual_add_f32 v15, v15, v23 :: v_dual_add_f32 v8, v17, v8 // 000000A77750: C9082F0F 0F081111
	s_clause 0x1                                               // 000000A77758: BF850001
	global_load_d16_b16 v2, v1, s[6:7]                         // 000000A7775C: DC820000 02060001
	global_load_d16_b16 v5, v1, s[6:7] offset:64               // 000000A77764: DC820040 05060001
	v_dual_add_f32 v4, v4, v14 :: v_dual_add_f32 v37, v27, v28 // 000000A7776C: C9081D04 0424391B
	s_waitcnt lgkmcnt(5)                                       // 000000A77774: BF89FC57
	v_add_f32_e32 v23, v13, v9                                 // 000000A77778: 062E130D
	s_waitcnt lgkmcnt(4)                                       // 000000A7777C: BF89FC47
	v_dual_add_f32 v25, v15, v25 :: v_dual_add_f32 v8, v8, v16 // 000000A77780: C908330F 19082108
	ds_load_2addr_b32 v[13:14], v46 offset0:96 offset1:112     // 000000A77788: D8DC7060 0D00002E
	ds_load_2addr_b32 v[15:16], v46 offset0:224 offset1:240    // 000000A77790: D8DCF0E0 0F00002E
	v_add_f32_e32 v9, v4, v38                                  // 000000A77798: 06124D04
	s_waitcnt lgkmcnt(5)                                       // 000000A7779C: BF89FC57
	v_add_f32_e32 v11, 0, v11                                  // 000000A777A0: 06161680
	s_waitcnt lgkmcnt(4)                                       // 000000A777A4: BF89FC47
	v_dual_add_f32 v17, 0, v29 :: v_dual_add_f32 v38, v8, v18  // 000000A777A8: C9083A80 11262508
	v_add_f32_e32 v21, v33, v36                                // 000000A777B0: 062A4921
	v_add_f32_e32 v44, v9, v20                                 // 000000A777B4: 06582909
	s_waitcnt lgkmcnt(2)                                       // 000000A777B8: BF89FC27
	s_delay_alu instid0(VALU_DEP_3)                            // 000000A777BC: BF870003
	v_dual_add_f32 v8, v11, v6 :: v_dual_add_f32 v11, v17, v31 // 000000A777C0: C9080D0B 080A3F11
	ds_load_2addr_b32 v[17:18], v47 offset0:96 offset1:112     // 000000A777C8: D8DC7060 1100002F
	ds_load_2addr_b32 v[19:20], v47 offset0:224 offset1:240    // 000000A777D0: D8DCF0E0 1300002F
	ds_load_2addr_b32 v[27:28], v48 offset0:96 offset1:112     // 000000A777D8: D8DC7060 1B000030
	ds_load_2addr_b32 v[33:34], v48 offset0:224 offset1:240    // 000000A777E0: D8DCF0E0 21000030
	v_add_f32_e32 v31, 0, v12                                  // 000000A777E8: 063E1880
	v_add_f32_e32 v35, 0, v30                                  // 000000A777EC: 06463C80
	s_clause 0x1                                               // 000000A777F0: BF850001
	global_load_d16_b16 v6, v41, s[6:7] offset:1280            // 000000A777F4: DC820500 06060029
	global_load_d16_b16 v4, v1, s[6:7] offset:1280             // 000000A777FC: DC820500 04060001
	v_or_b32_e32 v45, 0x60, v52                                // 000000A77804: 385A68FF 00000060
	v_add_f32_e32 v7, v31, v7                                  // 000000A7780C: 060E0F1F
	s_waitcnt lgkmcnt(5)                                       // 000000A77810: BF89FC57
	v_add_f32_e32 v13, v8, v13                                 // 000000A77814: 061A1B08
	global_load_d16_b16 v8, v41, s[8:9]                        // 000000A77818: DC820000 08080029
	s_waitcnt lgkmcnt(4)                                       // 000000A77820: BF89FC47
	v_add_f32_e32 v15, v11, v15                                // 000000A77824: 061E1F0B
	ds_load_2addr_b32 v[11:12], v49 offset0:96 offset1:112     // 000000A77828: D8DC7060 0B000031
	ds_load_2addr_b32 v[29:30], v49 offset0:224 offset1:240    // 000000A77830: D8DCF0E0 1D000031
	v_add_f32_e32 v41, v35, v32                                // 000000A77838: 06524123
	ds_load_2addr_b32 v[31:32], v50 offset0:96 offset1:112     // 000000A7783C: D8DC7060 1F000032
	ds_load_2addr_b32 v[35:36], v50 offset0:224 offset1:240    // 000000A77844: D8DCF0E0 23000032
	v_add_f32_e32 v7, v7, v14                                  // 000000A7784C: 060E1D07
	global_load_d16_b16 v9, v45, s[6:7]                        // 000000A77850: DC820000 0906002D
	v_add_f32_e32 v41, v41, v16                                // 000000A77858: 06522129
	s_waitcnt lgkmcnt(7)                                       // 000000A7785C: BF89FC77
	v_add_f32_e32 v17, v13, v17                                // 000000A77860: 0622230D
	s_waitcnt lgkmcnt(6)                                       // 000000A77864: BF89FC67
	v_add_f32_e32 v19, v15, v19                                // 000000A77868: 0626270F
	ds_load_2addr_b32 v[13:14], v51 offset0:96 offset1:112     // 000000A7786C: D8DC7060 0D000033
	ds_load_2addr_b32 v[15:16], v51 offset0:224 offset1:240    // 000000A77874: D8DCF0E0 0F000033
	v_dual_add_f32 v7, v7, v18 :: v_dual_add_f32 v18, v41, v20 // 000000A7787C: C9082507 07122929
	s_waitcnt lgkmcnt(7)                                       // 000000A77884: BF89FC77
	v_add_f32_e32 v17, v17, v27                                // 000000A77888: 06223711
	s_waitcnt lgkmcnt(6)                                       // 000000A7788C: BF89FC67
	v_dual_add_f32 v19, v19, v33 :: v_dual_add_f32 v20, v38, v22// 000000A77890: C9084313 13142D26
	v_dual_add_f32 v7, v7, v28 :: v_dual_add_f32 v18, v18, v34 // 000000A77898: C9083907 07124512
	v_add_f32_e32 v22, v44, v24                                // 000000A778A0: 062C312C
	v_or_b32_e32 v28, 0xa0, v52                                // 000000A778A4: 383868FF 000000A0
	s_waitcnt lgkmcnt(5)                                       // 000000A778AC: BF89FC57
	v_add_f32_e32 v11, v17, v11                                // 000000A778B0: 06161711
	s_waitcnt lgkmcnt(4)                                       // 000000A778B4: BF89FC47
	v_add_f32_e32 v17, v19, v29                                // 000000A778B8: 06223B13
	v_dual_add_f32 v7, v7, v12 :: v_dual_add_f32 v12, v18, v30 // 000000A778BC: C9081907 070C3D12
	s_waitcnt lgkmcnt(3)                                       // 000000A778C4: BF89FC37
	v_dual_add_f32 v10, v20, v10 :: v_dual_add_f32 v11, v11, v31// 000000A778C8: C9081514 0A0A3F0B
	s_waitcnt lgkmcnt(2)                                       // 000000A778D0: BF89FC27
	v_dual_add_f32 v17, v17, v35 :: v_dual_add_f32 v18, v22, v26// 000000A778D4: C9084711 11123516
	v_add_f32_e32 v12, v12, v36                                // 000000A778DC: 0618490C
	v_add_f32_e32 v7, v7, v32                                  // 000000A778E0: 060E4107
	s_waitcnt lgkmcnt(1)                                       // 000000A778E4: BF89FC17
	v_add_f32_e32 v11, v11, v13                                // 000000A778E8: 06161B0B
	s_waitcnt lgkmcnt(0)                                       // 000000A778EC: BF89FC07
	v_add_f32_e32 v13, v17, v15                                // 000000A778F0: 061A1F11
	v_dual_add_f32 v19, v23, v10 :: v_dual_add_f32 v12, v12, v16// 000000A778F4: C9081517 130C210C
	v_sub_f32_e32 v10, v23, v10                                // 000000A778FC: 08141517
	v_dual_add_f32 v22, v43, v54 :: v_dual_add_f32 v23, v42, v21// 000000A77900: C9086D2B 16162B2A
	v_add_f32_e32 v24, v25, v18                                // 000000A77908: 06302519
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A7790C: BF870004
	v_add_f32_e32 v27, v13, v12                                // 000000A77910: 0636190D
	v_add_f32_e32 v7, v7, v14                                  // 000000A77914: 060E1D07
	v_sub_f32_e32 v15, v39, v53                                // 000000A77918: 081E6B27
	v_add_f32_e32 v16, v40, v37                                // 000000A7791C: 06204B28
	v_dual_sub_f32 v17, v40, v37 :: v_dual_add_f32 v30, v22, v23// 000000A77920: C9484B28 111E2F16
	v_add_f32_e32 v31, v24, v27                                // 000000A77928: 063E3718
	v_dual_add_f32 v20, v11, v7 :: v_dual_and_b32 v37, 1, v0   // 000000A7792C: C9240F0B 14240081
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000A77934: BF870223
	v_add_f32_e32 v36, v15, v17                                // 000000A77938: 0648230F
	v_sub_f32_e32 v15, v15, v17                                // 000000A7793C: 081E230F
	v_add_f32_e32 v17, v30, v31                                // 000000A77940: 06223F1E
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A77944: BF870004
	.long 0xd44a0002                                           // 000000A77948: D44A0002
	v_cndmask_b32_e32 v1, 0, v37, vcc_lo                       // 000000A7794C: 02024A80
	v_add_f32_e32 v14, v39, v53                                // 000000A77950: 061C6B27
	v_add_f32_e32 v39, v19, v20                                // 000000A77954: 064E2913
	v_sub_f32_e32 v19, v19, v20                                // 000000A77958: 08262913
	v_mov_b32_dpp v20, v17 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A7795C: 7E2802FA FF016111
	v_cndmask_b32_e64 v17, -v17, v17, s2                       // 000000A77964: D5010011 200A2311
	v_sub_f32_e32 v37, v43, v54                                // 000000A7796C: 084A6D2B
	v_dual_sub_f32 v21, v42, v21 :: v_dual_sub_f32 v18, v25, v18// 000000A77970: C94A2B2A 15122519
	v_dual_sub_f32 v12, v13, v12 :: v_dual_sub_f32 v11, v11, v7// 000000A77978: C94A190D 0C0A0F0B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000A77980: BF8701A4
	v_add_f32_e32 v13, v17, v20                                // 000000A77984: 061A2911
	v_and_b32_e32 v17, 2, v0                                   // 000000A77988: 36220082
	v_dual_add_f32 v25, v37, v21 :: v_dual_add_f32 v40, v18, v12// 000000A7798C: C9082B25 19281912
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000A77994: BF870224
	v_add_f32_e32 v20, v10, v11                                // 000000A77998: 0628170A
	v_sub_f32_e32 v10, v10, v11                                // 000000A7799C: 0814170A
	.long 0xd44a0003                                           // 000000A779A0: D44A0003
	v_cndmask_b32_e32 v1, 0, v17, vcc_lo                       // 000000A779A4: 02022280
	v_sub_f32_e32 v17, v22, v23                                // 000000A779A8: 08222F16
	v_dual_add_f32 v11, v25, v40 :: v_dual_sub_f32 v22, v24, v27// 000000A779AC: C90A5119 0B163718
	v_and_b32_e32 v23, 4, v0                                   // 000000A779B4: 362E0084
	v_mov_b32_dpp v41, v13 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A779B8: 7E5202FA FF01620D
	v_cndmask_b32_e64 v13, -v13, v13, s3                       // 000000A779C0: D501000D 200E1B0D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 000000A779C8: BF870254
	v_mov_b32_dpp v24, v11 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A779CC: 7E3002FA FF01610B
	v_cndmask_b32_e64 v11, -v11, v11, s2                       // 000000A779D4: D501000B 200A170B
	v_add_f32_e32 v27, v17, v22                                // 000000A779DC: 06362D11
	.long 0xd44a0004                                           // 000000A779E0: D44A0004
	v_cndmask_b32_e32 v1, 0, v23, vcc_lo                       // 000000A779E4: 02022E80
	v_dual_add_f32 v13, v13, v41 :: v_dual_and_b32 v0, 8, v0   // 000000A779E8: C924530D 0D000088
	v_add_f32_e32 v11, v11, v24                                // 000000A779F0: 0616310B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000A779F4: BF870224
	v_mov_b32_dpp v23, v27 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A779F8: 7E2E02FA FF01611B
	v_cndmask_b32_e64 v24, -v27, v27, s2                       // 000000A77A00: D5010018 200A371B
	.long 0xd44a0001                                           // 000000A77A08: D44A0001
	v_cndmask_b32_e32 v1, 0, v0, vcc_lo                        // 000000A77A0C: 02020080
	v_sub_f32_e32 v0, v37, v21                                 // 000000A77A10: 08002B25
	v_mov_b32_dpp v27, v11 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A77A14: 7E3602FA FF01620B
	v_cndmask_b32_e64 v11, -v11, v11, s3                       // 000000A77A1C: D501000B 200E170B
	v_dual_add_f32 v23, v24, v23 :: v_dual_sub_f32 v12, v18, v12// 000000A77A24: C90A2F18 170C1912
	v_mov_b32_dpp v41, v13 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A77A2C: 7E5202FA FF01640D
	v_cndmask_b32_e64 v13, -v13, v13, s4                       // 000000A77A34: D501000D 20121B0D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A77A3C: BF870214
	v_add_f32_e32 v11, v11, v27                                // 000000A77A40: 0616370B
	v_mov_b32_dpp v18, v23 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A77A44: 7E2402FA FF016217
	v_cndmask_b32_e64 v21, -v23, v23, s3                       // 000000A77A4C: D5010015 200E2F17
	v_sub_f32_e32 v24, v25, v40                                // 000000A77A54: 08305119
	v_add_f32_e32 v13, v13, v41                                // 000000A77A58: 061A530D
	v_mov_b32_dpp v25, v11 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A77A5C: 7E3202FA FF01640B
	v_cndmask_b32_e64 v11, -v11, v11, s4                       // 000000A77A64: D501000B 2012170B
	v_dual_add_f32 v18, v21, v18 :: v_dual_add_f32 v21, v0, v12// 000000A77A6C: C9082515 12141900
	v_sub_f32_e32 v23, v30, v31                                // 000000A77A74: 082E3F1E
	v_sub_f32_e32 v17, v17, v22                                // 000000A77A78: 08222D11
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A77A7C: BF870214
	v_add_f32_e32 v11, v11, v25                                // 000000A77A80: 0616330B
	v_mov_b32_dpp v25, v18 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A77A84: 7E3202FA FF016412
	v_cndmask_b32_e64 v18, -v18, v18, s4                       // 000000A77A8C: D5010012 20122512
	v_mov_b32_dpp v30, v21 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A77A94: 7E3C02FA FF016115
	v_cndmask_b32_e64 v21, -v21, v21, s2                       // 000000A77A9C: D5010015 200A2B15
	v_mov_b32_dpp v22, v13 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A77AA4: 7E2C02FA FF01680D
	v_cndmask_b32_e64 v13, -v13, v13, s1                       // 000000A77AAC: D501000D 20061B0D
	v_add_f32_e32 v18, v18, v25                                // 000000A77AB4: 06243312
	v_add_f32_e32 v29, v14, v16                                // 000000A77AB8: 063A210E
	v_dual_add_f32 v21, v21, v30 :: v_dual_sub_f32 v14, v14, v16// 000000A77ABC: C90A3D15 150E210E
	v_or_b32_e32 v16, 0xe0, v52                                // 000000A77AC4: 382068FF 000000E0
	v_sub_f32_e32 v0, v0, v12                                  // 000000A77ACC: 08001900
	v_add_f32_e32 v12, v13, v22                                // 000000A77AD0: 06182D0D
	v_mov_b32_dpp v13, v18 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A77AD4: 7E1A02FA FF016812
	v_mov_b32_dpp v22, v21 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A77ADC: 7E2C02FA FF016215
	v_cndmask_b32_e64 v21, -v21, v21, s3                       // 000000A77AE4: D5010015 200E2B15
	v_cndmask_b32_e64 v18, -v18, v18, s1                       // 000000A77AEC: D5010012 20062512
	v_mov_b32_dpp v25, v23 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A77AF4: 7E3202FA FF016117
	v_cndmask_b32_e64 v23, -v23, v23, s2                       // 000000A77AFC: D5010017 200A2F17
	global_load_d16_b16 v38, v16, s[6:7]                       // 000000A77B04: DC820000 26060010
	v_add_f32_e32 v21, v21, v22                                // 000000A77B0C: 062A2D15
	v_add_f32_e32 v13, v18, v13                                // 000000A77B10: 061A1B12
	global_load_d16_b16 v22, v28, s[6:7] offset:1280           // 000000A77B14: DC820500 1606001C
	v_add_f32_e32 v18, v23, v25                                // 000000A77B1C: 06243317
	s_clause 0x7                                               // 000000A77B20: BF850007
	global_load_d16_b16 v25, v16, s[6:7] offset:1280           // 000000A77B24: DC820500 19060010
	global_load_d16_b16 v26, v1, s[6:7] offset:128             // 000000A77B2C: DC820080 1A060001
	global_load_d16_b16 v32, v28, s[6:7]                       // 000000A77B34: DC820000 2006001C
	global_load_d16_b16 v33, v1, s[6:7] offset:1344            // 000000A77B3C: DC820540 21060001
	global_load_d16_b16 v7, v1, s[6:7] offset:1408             // 000000A77B44: DC820580 07060001
	global_load_d16_b16 v34, v1, s[6:7] offset:1472            // 000000A77B4C: DC8205C0 22060001
	global_load_d16_b16 v35, v1, s[6:7] offset:192             // 000000A77B54: DC8200C0 23060001
	global_load_d16_b16 v27, v45, s[6:7] offset:1280           // 000000A77B5C: DC820500 1B06002D
	v_mov_b32_dpp v23, v21 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A77B64: 7E2E02FA FF016415
	v_cndmask_b32_e64 v21, -v21, v21, s4                       // 000000A77B6C: D5010015 20122B15
	s_clause 0x5                                               // 000000A77B74: BF850005
	global_load_d16_b16 v28, v28, s[8:9]                       // 000000A77B78: DC820000 1C08001C
	global_load_d16_b16 v16, v16, s[8:9]                       // 000000A77B80: DC820000 10080010
	global_load_d16_b16 v37, v1, s[8:9]                        // 000000A77B88: DC820000 25080001
	global_load_d16_b16 v40, v1, s[8:9] offset:64              // 000000A77B90: DC820040 28080001
	global_load_d16_b16 v41, v1, s[8:9] offset:128             // 000000A77B98: DC820080 29080001
	global_load_d16_b16 v42, v1, s[8:9] offset:192             // 000000A77BA0: DC8200C0 2A080001
	v_mov_b32_dpp v31, v11 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A77BA8: 7E3E02FA FF01680B
	v_add_f32_e32 v21, v21, v23                                // 000000A77BB0: 062A2F15
	global_load_d16_b16 v23, v45, s[8:9]                       // 000000A77BB4: DC820000 1708002D
	v_cndmask_b32_e64 v11, -v11, v11, s1                       // 000000A77BBC: D501000B 2006170B
	v_mov_b32_dpp v30, v18 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A77BC4: 7E3C02FA FF016212
	v_cndmask_b32_e64 v18, -v18, v18, s3                       // 000000A77BCC: D5010012 200E2512
	v_add_f32_e32 v43, v36, v20                                // 000000A77BD4: 06562924
	v_mov_b32_dpp v47, v24 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A77BD8: 7E5E02FA FF016118
	v_add_f32_e32 v11, v11, v31                                // 000000A77BE0: 06163F0B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A77BE4: BF870214
	v_dual_add_f32 v31, v29, v39 :: v_dual_add_f32 v18, v18, v30// 000000A77BE8: C9084F1D 1F123D12
	v_mov_b32_dpp v45, v43 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A77BF0: 7E5A02FA FF01612B
	v_cndmask_b32_e64 v43, -v43, v43, s2                       // 000000A77BF8: D501002B 200A572B
	v_cndmask_b32_e64 v24, -v24, v24, s2                       // 000000A77C00: D5010018 200A3118
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A77C08: BF870004
	v_mov_b32_dpp v30, v31 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A77C0C: 7E3C02FA FF01611F
	v_cndmask_b32_e64 v31, -v31, v31, s2                       // 000000A77C14: D501001F 200A3F1F
	v_mov_b32_dpp v44, v21 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A77C1C: 7E5802FA FF016815
	v_add_f32_e32 v43, v43, v45                                // 000000A77C24: 06565B2B
	v_cndmask_b32_e64 v21, -v21, v21, s1                       // 000000A77C28: D5010015 20062B15
	v_add_f32_e32 v24, v24, v47                                // 000000A77C30: 06305F18
	v_add_f32_e32 v30, v31, v30                                // 000000A77C34: 063C3D1F
	v_mov_b32_dpp v31, v18 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A77C38: 7E3E02FA FF016412
	v_cndmask_b32_e64 v18, -v18, v18, s4                       // 000000A77C40: D5010012 20122512
	v_add_f32_e32 v21, v21, v44                                // 000000A77C48: 062A5915
	v_mul_f32_e32 v12, 0x3db504f3, v12                         // 000000A77C4C: 101818FF 3DB504F3
	v_mov_b32_dpp v46, v30 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A77C54: 7E5C02FA FF01621E
	v_cndmask_b32_e64 v30, -v30, v30, s3                       // 000000A77C5C: D501001E 200E3D1E
	v_add_f32_e32 v18, v18, v31                                // 000000A77C64: 06243F12
	v_mov_b32_dpp v31, v43 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A77C68: 7E3E02FA FF01622B
	v_cndmask_b32_e64 v43, -v43, v43, s3                       // 000000A77C70: D501002B 200E572B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000A77C78: BF870234
	v_dual_sub_f32 v29, v29, v39 :: v_dual_add_f32 v30, v30, v46// 000000A77C7C: C9484F1D 1D1E5D1E
	v_mov_b32_dpp v46, v24 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A77C84: 7E5C02FA FF016218
	v_cndmask_b32_e64 v24, -v24, v24, s3                       // 000000A77C8C: D5010018 200E3118
	v_add_f32_e32 v31, v43, v31                                // 000000A77C94: 063E3F2B
	v_mov_b32_dpp v43, v18 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A77C98: 7E5602FA FF016812
	v_mov_b32_dpp v45, v30 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A77CA0: 7E5A02FA FF01641E
	v_cndmask_b32_e64 v30, -v30, v30, s4                       // 000000A77CA8: D501001E 20123D1E
	v_add_f32_e32 v24, v24, v46                                // 000000A77CB0: 06305D18
	v_mov_b32_dpp v44, v31 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A77CB4: 7E5802FA FF01641F
	v_cndmask_b32_e64 v31, -v31, v31, s4                       // 000000A77CBC: D501001F 20123F1F
	v_mov_b32_dpp v46, v17 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A77CC4: 7E5C02FA FF016111
	v_add_f32_e32 v30, v30, v45                                // 000000A77CCC: 063C5B1E
	v_cndmask_b32_e64 v17, -v17, v17, s2                       // 000000A77CD0: D5010011 200A2311
	v_cndmask_b32_e64 v18, -v18, v18, s1                       // 000000A77CD8: D5010012 20062512
	v_add_f32_e32 v31, v31, v44                                // 000000A77CE0: 063E591F
	v_mov_b32_dpp v44, v24 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A77CE4: 7E5802FA FF016418
	v_mov_b32_dpp v45, v30 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A77CEC: 7E5A02FA FF01681E
	v_cndmask_b32_e64 v30, -v30, v30, s1                       // 000000A77CF4: D501001E 20063D1E
	v_add_f32_e32 v17, v17, v46                                // 000000A77CFC: 06225D11
	v_cndmask_b32_e64 v24, -v24, v24, s4                       // 000000A77D00: D5010018 20123118
	v_add_f32_e32 v18, v18, v43                                // 000000A77D08: 06245712
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A77D0C: BF870004
	v_dual_mul_f32 v11, 0x3db504f3, v11 :: v_dual_add_f32 v30, v30, v45// 000000A77D10: C8C816FF 0B1E5B1E 3DB504F3
	v_mov_b32_dpp v45, v31 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A77D1C: 7E5A02FA FF01681F
	v_cndmask_b32_e64 v31, -v31, v31, s1                       // 000000A77D24: D501001F 20063F1F
	v_mov_b32_dpp v46, v17 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A77D2C: 7E5C02FA FF016211
	v_cndmask_b32_e64 v17, -v17, v17, s3                       // 000000A77D34: D5010011 200E2311
	v_mul_f32_e32 v30, 0x3db504f3, v30                         // 000000A77D3C: 103C3CFF 3DB504F3
	v_add_f32_e32 v24, v24, v44                                // 000000A77D44: 06305918
	v_dual_sub_f32 v20, v36, v20 :: v_dual_mul_f32 v13, 0x3db504f3, v13// 000000A77D48: C9462924 140C1AFF 3DB504F3
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000A77D54: BF8701A4
	v_add_f32_e32 v17, v17, v46                                // 000000A77D58: 06225D11
	v_dual_mul_f32 v21, 0x3db504f3, v21 :: v_dual_mul_f32 v18, 0x3db504f3, v18// 000000A77D5C: C8C62AFF 151224FF 3DB504F3
	v_mov_b32_dpp v36, v20 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A77D68: 7E4802FA FF016114
	v_cndmask_b32_e64 v20, -v20, v20, s2                       // 000000A77D70: D5010014 200A2914
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000A77D78: BF8700A4
	v_mov_b32_dpp v44, v17 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A77D7C: 7E5802FA FF016411
	v_cndmask_b32_e64 v17, -v17, v17, s4                       // 000000A77D84: D5010011 20122311
	v_add_f32_e32 v17, v17, v44                                // 000000A77D8C: 06225911
	v_mov_b32_dpp v44, v0 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A77D90: 7E5802FA FF016100
	v_cndmask_b32_e64 v0, -v0, v0, s2                          // 000000A77D98: D5010000 200A0100
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A77DA0: BF870211
	v_add_f32_e32 v0, v0, v44                                  // 000000A77DA4: 06005900
	v_mov_b32_dpp v44, v17 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A77DA8: 7E5802FA FF016811
	v_cndmask_b32_e64 v17, -v17, v17, s1                       // 000000A77DB0: D5010011 20062311
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A77DB8: BF870091
	v_add_f32_e32 v17, v17, v44                                // 000000A77DBC: 06225911
	v_mul_f32_e32 v17, 0x3db504f3, v17                         // 000000A77DC0: 102222FF 3DB504F3
	s_waitcnt vmcnt(22)                                        // 000000A77DC8: BF895BF7
	v_fma_mix_f32 v2, v2, v30, neg(0) op_sel_hi:[1,0,0]        // 000000A77DCC: CC200002 8A023D02
	v_add_f32_e32 v30, v31, v45                                // 000000A77DD4: 063C5B1F
	v_mov_b32_dpp v31, v24 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A77DD8: 7E3E02FA FF016818
	v_cndmask_b32_e64 v24, -v24, v24, s1                       // 000000A77DE0: D5010018 20063118
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A77DE8: BF870214
	v_mul_f32_e32 v43, 0xbfb8aa3b, v2                          // 000000A77DEC: 105604FF BFB8AA3B
	v_mul_f32_e32 v30, 0x3db504f3, v30                         // 000000A77DF4: 103C3CFF 3DB504F3
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000A77DFC: BF870223
	v_add_f32_e32 v24, v24, v31                                // 000000A77E00: 06303F18
	v_add_f32_e32 v31, v14, v19                                // 000000A77E04: 063E270E
	v_exp_f32_e32 v43, v43                                     // 000000A77E08: 7E564B2B
	s_delay_alu instid0(VALU_DEP_3)                            // 000000A77E0C: BF870003
	v_fma_mix_f32 v3, v3, v30, neg(0) op_sel_hi:[1,0,0]        // 000000A77E10: CC200003 8A023D03
	v_sub_f32_e32 v14, v14, v19                                // 000000A77E18: 081C270E
	v_mul_f32_e32 v24, 0x3db504f3, v24                         // 000000A77E1C: 103030FF 3DB504F3
	v_mov_b32_dpp v45, v31 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A77E24: 7E5A02FA FF01611F
	v_cndmask_b32_e64 v31, -v31, v31, s2                       // 000000A77E2C: D501001F 200A3F1F
	v_mul_f32_e32 v30, 0xbfb8aa3b, v3                          // 000000A77E34: 103C06FF BFB8AA3B
	v_mov_b32_dpp v19, v14 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A77E3C: 7E2602FA FF01610E
	v_cndmask_b32_e64 v14, -v14, v14, s2                       // 000000A77E44: D501000E 200A1D0E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A77E4C: BF870215
	v_add_f32_e32 v43, 1.0, v43                                // 000000A77E50: 065656F2
	v_exp_f32_e32 v30, v30                                     // 000000A77E54: 7E3C4B1E
	v_add_f32_e32 v31, v31, v45                                // 000000A77E58: 063E5B1F
	v_mov_b32_dpp v45, v0 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A77E5C: 7E5A02FA FF016200
	v_cndmask_b32_e64 v0, -v0, v0, s3                          // 000000A77E64: D5010000 200E0100
	v_div_scale_f32 v46, null, v43, v43, v2                    // 000000A77E6C: D6FC7C2E 040A572B
	s_waitcnt vmcnt(19)                                        // 000000A77E74: BF894FF7
	v_fma_mix_f32 v4, v4, v12, neg(0) op_sel_hi:[1,0,0]        // 000000A77E78: CC200004 8A021904
	v_mov_b32_dpp v48, v31 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A77E80: 7E6002FA FF01621F
	v_cndmask_b32_e64 v31, -v31, v31, s3                       // 000000A77E88: D501001F 200E3F1F
	v_add_f32_e32 v0, v0, v45                                  // 000000A77E90: 06005B00
	v_rcp_f32_e32 v47, v46                                     // 000000A77E94: 7E5E552E
	v_add_f32_e32 v30, 1.0, v30                                // 000000A77E98: 063C3CF2
	v_fma_mix_f32 v6, v6, v11, neg(0) op_sel_hi:[1,0,0]        // 000000A77E9C: CC200006 8A021706
	v_add_f32_e32 v31, v31, v48                                // 000000A77EA4: 063E611F
	v_mov_b32_dpp v44, v0 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A77EA8: 7E5802FA FF016400
	v_cndmask_b32_e64 v0, -v0, v0, s4                          // 000000A77EB0: D5010000 20120100
	v_div_scale_f32 v45, null, v30, v30, v3                    // 000000A77EB8: D6FC7C2D 040E3D1E
	v_add_f32_e32 v14, v14, v19                                // 000000A77EC0: 061C270E
	v_mov_b32_dpp v50, v31 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A77EC4: 7E6402FA FF01641F
	v_cndmask_b32_e64 v31, -v31, v31, s4                       // 000000A77ECC: D501001F 20123F1F
	v_add_f32_e32 v0, v0, v44                                  // 000000A77ED4: 06005900
	v_rcp_f32_e32 v48, v45                                     // 000000A77ED8: 7E60552D
	v_add_f32_e32 v44, v15, v10                                // 000000A77EDC: 0658150F
	v_fma_f32 v49, -v46, v47, 1.0                              // 000000A77EE0: D6130031 23CA5F2E
	v_add_f32_e32 v31, v31, v50                                // 000000A77EE8: 063E651F
	v_sub_f32_e32 v10, v15, v10                                // 000000A77EEC: 0814150F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(TRANS32_DEP_1)// 000000A77EF0: BF8702C4
	v_mov_b32_dpp v51, v44 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A77EF4: 7E6602FA FF01612C
	v_cndmask_b32_e64 v44, -v44, v44, s2                       // 000000A77EFC: D501002C 200A592C
	v_fmac_f32_e32 v47, v49, v47                               // 000000A77F04: 565E5F31
	v_div_scale_f32 v49, vcc_lo, v2, v43, v2                   // 000000A77F08: D6FC6A31 040A5702
	v_fma_f32 v50, -v45, v48, 1.0                              // 000000A77F10: D6130032 23CA612D
	v_mov_b32_dpp v52, v31 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A77F18: 7E6802FA FF01681F
	v_cndmask_b32_e64 v31, -v31, v31, s1                       // 000000A77F20: D501001F 20063F1F
	v_add_f32_e32 v44, v44, v51                                // 000000A77F28: 0658672C
	v_mov_b32_dpp v51, v0 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A77F2C: 7E6602FA FF016800
	v_fmac_f32_e32 v48, v50, v48                               // 000000A77F34: 56606132
	v_div_scale_f32 v50, s5, v3, v30, v3                       // 000000A77F38: D6FC0532 040E3D03
	v_dual_add_f32 v31, v31, v52 :: v_dual_mul_f32 v52, v49, v47// 000000A77F40: C906691F 1F345F31
	v_mov_b32_dpp v54, v44 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A77F48: 7E6C02FA FF01622C
	v_cndmask_b32_e64 v44, -v44, v44, s3                       // 000000A77F50: D501002C 200E592C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A77F58: BF870214
	v_mul_f32_e32 v53, v50, v48                                // 000000A77F5C: 106A6132
	v_mul_f32_e32 v31, 0x3db504f3, v31                         // 000000A77F60: 103E3EFF 3DB504F3
	v_fma_f32 v55, -v46, v52, v49                              // 000000A77F68: D6130037 24C6692E
	v_cndmask_b32_e64 v0, -v0, v0, s1                          // 000000A77F70: D5010000 20060100
	v_add_f32_e32 v44, v44, v54                                // 000000A77F78: 06586D2C
	v_fma_f32 v56, -v45, v53, v50                              // 000000A77F7C: D6130038 24CA6B2D
	v_fma_mix_f32 v5, v5, v31, neg(0) op_sel_hi:[1,0,0]        // 000000A77F84: CC200005 8A023F05
	v_fmac_f32_e32 v52, v55, v47                               // 000000A77F8C: 56685F37
	v_add_f32_e32 v0, v0, v51                                  // 000000A77F90: 06006700
	v_mov_b32_dpp v31, v44 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A77F94: 7E3E02FA FF01642C
	v_cndmask_b32_e64 v44, -v44, v44, s4                       // 000000A77F9C: D501002C 2012592C
	v_fmac_f32_e32 v53, v56, v48                               // 000000A77FA4: 566A6138
	v_fma_f32 v46, -v46, v52, v49                              // 000000A77FA8: D613002E 24C6692E
	v_mul_f32_e32 v51, 0xbfb8aa3b, v5                          // 000000A77FB0: 10660AFF BFB8AA3B
	v_mov_b32_dpp v19, v10 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A77FB8: 7E2602FA FF01610A
	v_add_f32_e32 v31, v44, v31                                // 000000A77FC0: 063E3F2C
	v_fma_f32 v45, -v45, v53, v50                              // 000000A77FC4: D613002D 24CA6B2D
	v_div_fmas_f32 v44, v46, v47, v52                          // 000000A77FCC: D637002C 04D25F2E
	s_mov_b32 vcc_lo, s5                                       // 000000A77FD4: BEEA0005
	v_exp_f32_e32 v49, v51                                     // 000000A77FD8: 7E624B33
	v_mov_b32_dpp v46, v31 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A77FDC: 7E5C02FA FF01681F
	v_cndmask_b32_e64 v31, -v31, v31, s1                       // 000000A77FE4: D501001F 20063F1F
	v_div_fmas_f32 v45, v45, v48, v53                          // 000000A77FEC: D637002D 04D6612D
	v_div_fixup_f32 v2, v44, v43, v2                           // 000000A77FF4: D6270002 040A572C
	v_cndmask_b32_e64 v10, -v10, v10, s2                       // 000000A77FFC: D501000A 200A150A
	v_mul_f32_e32 v0, 0x3db504f3, v0                           // 000000A78004: 100000FF 3DB504F3
	v_add_f32_e32 v12, v31, v46                                // 000000A7800C: 06185D1F
	v_mov_b32_dpp v31, v29 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A78010: 7E3E02FA FF01611D
	v_cndmask_b32_e64 v29, -v29, v29, s2                       // 000000A78018: D501001D 200A3B1D
	v_div_fixup_f32 v3, v45, v30, v3                           // 000000A78020: D6270003 040E3D2D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000A78028: BF870224
	v_dual_mul_f32 v2, v4, v2 :: v_dual_mul_f32 v11, 0x3db504f3, v12// 000000A7802C: C8C60504 020A18FF 3DB504F3
	v_add_f32_e32 v10, v10, v19                                // 000000A78038: 0614270A
	v_add_f32_e32 v4, v29, v31                                 // 000000A7803C: 06083F1D
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A78040: BF870004
	v_mul_f32_e32 v3, v6, v3                                   // 000000A78044: 10060706
	v_add_f32_e32 v47, 1.0, v49                                // 000000A78048: 065E62F2
	s_waitcnt vmcnt(17)                                        // 000000A7804C: BF8947F7
	v_fma_mix_f32 v6, v9, v11, neg(0) op_sel_hi:[1,0,0]        // 000000A78050: CC200006 8A021709
	v_add_f32_e32 v9, v20, v36                                 // 000000A78058: 06124914
	v_mov_b32_dpp v20, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A7805C: 7E2802FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, s3                          // 000000A78064: D5010004 200E0904
	v_fma_mix_f32 v3, v8, v3, neg(0) op_sel_hi:[1,0,0]         // 000000A7806C: CC200003 8A020708
	v_mul_f32_e32 v8, 0xbfb8aa3b, v6                           // 000000A78074: 10100CFF BFB8AA3B
	v_mov_b32_dpp v29, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A7807C: 7E3A02FA FF016209
	v_cndmask_b32_e64 v9, -v9, v9, s3                          // 000000A78084: D5010009 200E1309
	v_add_f32_e32 v4, v4, v20                                  // 000000A7808C: 06082904
	v_div_scale_f32 v30, null, v47, v47, v5                    // 000000A78090: D6FC7C1E 04165F2F
	v_exp_f32_e32 v8, v8                                       // 000000A78098: 7E104B08
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A7809C: BF870193
	v_add_f32_e32 v9, v9, v29                                  // 000000A780A0: 06123B09
	v_mov_b32_dpp v15, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A780A4: 7E1E02FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s4                          // 000000A780AC: D5010004 20120904
	v_mov_b32_dpp v29, v14 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A780B4: 7E3A02FA FF01620E
	v_cndmask_b32_e64 v14, -v14, v14, s3                       // 000000A780BC: D501000E 200E1D0E
	v_mov_b32_dpp v20, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A780C4: 7E2802FA FF016409
	v_cndmask_b32_e64 v9, -v9, v9, s4                          // 000000A780CC: D5010009 20121309
	v_add_f32_e32 v4, v4, v15                                  // 000000A780D4: 06081F04
	v_mov_b32_dpp v15, v10 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A780D8: 7E1E02FA FF01620A
	v_add_f32_e32 v14, v14, v29                                // 000000A780E0: 061C3B0E
	v_cndmask_b32_e64 v10, -v10, v10, s3                       // 000000A780E4: D501000A 200E150A
	v_add_f32_e32 v9, v9, v20                                  // 000000A780EC: 06122909
	v_mov_b32_dpp v19, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A780F0: 7E2602FA FF016804
	v_cndmask_b32_e64 v4, -v4, v4, s1                          // 000000A780F8: D5010004 20060904
	v_mov_b32_dpp v20, v14 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A78100: 7E2802FA FF01640E
	v_cndmask_b32_e64 v14, -v14, v14, s4                       // 000000A78108: D501000E 20121D0E
	v_add_f32_e32 v10, v10, v15                                // 000000A78110: 06141F0A
	v_rcp_f32_e32 v12, v30                                     // 000000A78114: 7E18551E
	v_mov_b32_dpp v15, v9 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A78118: 7E1E02FA FF016809
	v_cndmask_b32_e64 v9, -v9, v9, s1                          // 000000A78120: D5010009 20061309
	v_add_f32_e32 v4, v4, v19                                  // 000000A78128: 06082704
	v_add_f32_e32 v14, v14, v20                                // 000000A7812C: 061C290E
	v_mov_b32_dpp v19, v10 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A78130: 7E2602FA FF01640A
	v_cndmask_b32_e64 v10, -v10, v10, s4                       // 000000A78138: D501000A 2012150A
	v_dual_add_f32 v8, 1.0, v8 :: v_dual_add_f32 v9, v9, v15   // 000000A78140: C90810F2 08081F09
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000A78148: BF870224
	v_mov_b32_dpp v15, v14 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A7814C: 7E1E02FA FF01680E
	v_cndmask_b32_e64 v14, -v14, v14, s1                       // 000000A78154: D501000E 20061D0E
	v_add_f32_e32 v10, v10, v19                                // 000000A7815C: 0614270A
	v_fma_f32 v11, -v30, v12, 1.0                              // 000000A78160: D613000B 23CA191E
	v_mul_f32_e32 v4, 0x3db504f3, v4                           // 000000A78168: 100808FF 3DB504F3
	v_div_scale_f32 v19, null, v8, v8, v6                      // 000000A78170: D6FC7C13 041A1108
	v_add_f32_e32 v14, v14, v15                                // 000000A78178: 061C1F0E
	v_mov_b32_dpp v15, v10 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A7817C: 7E1E02FA FF01680A
	v_cndmask_b32_e64 v10, -v10, v10, s1                       // 000000A78184: D501000A 2006150A
	v_fmac_f32_e32 v12, v11, v12                               // 000000A7818C: 5618190B
	v_div_scale_f32 v11, vcc_lo, v5, v47, v5                   // 000000A78190: D6FC6A0B 04165F05
	v_mul_f32_e32 v9, 0x3db504f3, v9                           // 000000A78198: 101212FF 3DB504F3
	v_rcp_f32_e32 v20, v19                                     // 000000A781A0: 7E285513
	v_add_f32_e32 v10, v10, v15                                // 000000A781A4: 06141F0A
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000A781A8: BF8701B3
	v_dual_mul_f32 v14, 0x3db504f3, v14 :: v_dual_mul_f32 v15, v11, v12// 000000A781AC: C8C61CFF 0E0E190B 3DB504F3
	s_waitcnt vmcnt(12)                                        // 000000A781B8: BF8933F7
	v_fma_mix_f32 v9, v32, v9, neg(0) op_sel_hi:[1,0,0]        // 000000A781BC: CC200009 8A021320
	v_mul_f32_e32 v10, 0x3db504f3, v10                         // 000000A781C4: 101414FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_3)                            // 000000A781CC: BF870003
	v_fma_f32 v31, -v30, v15, v11                              // 000000A781D0: D613001F 242E1F1E
	v_fma_mix_f32 v4, v26, v4, neg(0) op_sel_hi:[1,0,0]        // 000000A781D8: CC200004 8A02091A
	s_waitcnt vmcnt(8)                                         // 000000A781E0: BF8923F7
	v_fma_mix_f32 v14, v35, v14, neg(0) op_sel_hi:[1,0,0]      // 000000A781E4: CC20000E 8A021D23
	v_mul_f32_e32 v29, 0xbfb8aa3b, v9                          // 000000A781EC: 103A12FF BFB8AA3B
	v_fma_f32 v32, -v19, v20, 1.0                              // 000000A781F4: D6130020 23CA2913
	v_fma_mix_f32 v10, v38, v10, neg(0) op_sel_hi:[1,0,0]      // 000000A781FC: CC20000A 8A021526
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A78204: BF870214
	v_dual_mul_f32 v26, 0xbfb8aa3b, v4 :: v_dual_mul_f32 v35, 0xbfb8aa3b, v14// 000000A78208: C8C608FF 1A221CFF BFB8AA3B
	v_exp_f32_e32 v29, v29                                     // 000000A78214: 7E3A4B1D
	v_fmac_f32_e32 v15, v31, v12                               // 000000A78218: 561E191F
	v_fmac_f32_e32 v20, v32, v20                               // 000000A7821C: 56282920
	s_delay_alu instid0(VALU_DEP_3)                            // 000000A78220: BF870003
	v_exp_f32_e32 v26, v26                                     // 000000A78224: 7E344B1A
	v_mul_f32_e32 v32, 0xbfb8aa3b, v10                         // 000000A78228: 104014FF BFB8AA3B
	v_exp_f32_e32 v31, v35                                     // 000000A78230: 7E3E4B23
	v_fma_f32 v11, -v30, v15, v11                              // 000000A78234: D613000B 242E1F1E
	v_div_scale_f32 v35, s5, v6, v8, v6                        // 000000A7823C: D6FC0523 041A1106
	v_fma_mix_f32 v13, v33, v13, neg(0) op_sel_hi:[1,0,0]      // 000000A78244: CC20000D 8A021B21
	v_exp_f32_e32 v30, v32                                     // 000000A7824C: 7E3C4B20
	v_add_f32_e32 v29, 1.0, v29                                // 000000A78250: 063A3AF2
	v_div_fmas_f32 v11, v11, v12, v15                          // 000000A78254: D637000B 043E190B
	v_mul_f32_e32 v32, v35, v20                                // 000000A7825C: 10402923
	v_add_f32_e32 v26, 1.0, v26                                // 000000A78260: 063434F2
	s_mov_b32 vcc_lo, s5                                       // 000000A78264: BEEA0005
	v_add_f32_e32 v31, 1.0, v31                                // 000000A78268: 063E3EF2
	v_div_scale_f32 v39, null, v29, v29, v9                    // 000000A7826C: D6FC7C27 04263B1D
	v_fma_f32 v15, -v19, v32, v35                              // 000000A78274: D613000F 248E4113
	v_div_scale_f32 v36, null, v26, v26, v4                    // 000000A7827C: D6FC7C24 0412351A
	v_add_f32_e32 v30, 1.0, v30                                // 000000A78284: 063C3CF2
	v_div_scale_f32 v12, null, v31, v31, v14                   // 000000A78288: D6FC7C0C 043A3F1F
	v_rcp_f32_e32 v43, v39                                     // 000000A78290: 7E565527
	v_fmac_f32_e32 v32, v15, v20                               // 000000A78294: 5640290F
	v_rcp_f32_e32 v38, v36                                     // 000000A78298: 7E4C5524
	v_div_scale_f32 v33, null, v30, v30, v10                   // 000000A7829C: D6FC7C21 042A3D1E
	v_rcp_f32_e32 v45, v12                                     // 000000A782A4: 7E5A550C
	v_div_fixup_f32 v5, v11, v47, v5                           // 000000A782A8: D6270005 04165F0B
	v_div_scale_f32 v11, s6, v4, v26, v4                       // 000000A782B0: D6FC060B 04123504
	v_fma_f32 v19, -v19, v32, v35                              // 000000A782B8: D6130013 248E4113
	v_rcp_f32_e32 v15, v33                                     // 000000A782C0: 7E1E5521
	s_waitcnt vmcnt(7)                                         // 000000A782C4: BF891FF7
	v_fma_mix_f32 v21, v27, v21, neg(0) op_sel_hi:[1,0,0]      // 000000A782C8: CC200015 8A022B1B
	v_mul_f32_e32 v5, v13, v5                                  // 000000A782D0: 100A0B0D
	v_fma_mix_f32 v0, v25, v0, neg(0) op_sel_hi:[1,0,0]        // 000000A782D4: CC200000 8A020119
	v_fma_f32 v44, -v36, v38, 1.0                              // 000000A782DC: D613002C 23CA4D24
	v_div_fmas_f32 v19, v19, v20, v32                          // 000000A782E4: D6370013 04822913
	v_fma_f32 v13, -v12, v45, 1.0                              // 000000A782EC: D613000D 23CA5B0C
	s_mov_b32 vcc_lo, s6                                       // 000000A782F4: BEEA0006
	v_fma_mix_f32 v7, v7, v18, neg(0) op_sel_hi:[1,0,0]        // 000000A782F8: CC200007 8A022507
	v_fmac_f32_e32 v38, v44, v38                               // 000000A78300: 564C4D2C
	v_fma_f32 v44, -v39, v43, 1.0                              // 000000A78304: D613002C 23CA5727
	v_fma_f32 v46, -v33, v15, 1.0                              // 000000A7830C: D613002E 23CA1F21
	v_fmac_f32_e32 v45, v13, v45                               // 000000A78314: 565A5B0D
	v_div_scale_f32 v13, s8, v14, v31, v14                     // 000000A78318: D6FC080D 043A3F0E
	v_mul_f32_e32 v35, v11, v38                                // 000000A78320: 10464D0B
	v_fmac_f32_e32 v43, v44, v43                               // 000000A78324: 5656572C
	v_div_scale_f32 v44, s7, v9, v29, v9                       // 000000A78328: D6FC072C 04263B09
	v_fmac_f32_e32 v15, v46, v15                               // 000000A78330: 561E1F2E
	v_div_scale_f32 v46, s5, v10, v30, v10                     // 000000A78334: D6FC052E 042A3D0A
	v_fma_f32 v20, -v36, v35, v11                              // 000000A7833C: D6130014 242E4724
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000A78344: BF8701A4
	v_dual_mul_f32 v47, v13, v45 :: v_dual_mul_f32 v32, v44, v43// 000000A78348: C8C65B0D 2F20572C
	v_div_fixup_f32 v6, v19, v8, v6                            // 000000A78350: D6270006 041A1113
	v_dual_fmac_f32 v35, v20, v38 :: v_dual_mul_f32 v20, v46, v15// 000000A78358: C8064D14 23141F2E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A78360: BF870213
	v_fma_f32 v8, -v39, v32, v44                               // 000000A78364: D6130008 24B24127
	v_fma_f32 v19, -v12, v47, v13                              // 000000A7836C: D6130013 24365F0C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A78374: BF870214
	v_mul_f32_e32 v6, v21, v6                                  // 000000A78378: 100C0D15
	v_fma_f32 v11, -v36, v35, v11                              // 000000A7837C: D613000B 242E4724
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000A78384: BF870234
	v_fmac_f32_e32 v32, v8, v43                                // 000000A78388: 56405708
	v_fma_f32 v8, -v33, v20, v46                               // 000000A7838C: D6130008 24BA2921
	v_fmac_f32_e32 v47, v19, v45                               // 000000A78394: 565E5B13
	v_div_fmas_f32 v11, v11, v38, v35                          // 000000A78398: D637000B 048E4D0B
	s_mov_b32 vcc_lo, s7                                       // 000000A783A0: BEEA0007
	v_fma_f32 v19, -v39, v32, v44                              // 000000A783A4: D6130013 24B24127
	v_fmac_f32_e32 v20, v8, v15                                // 000000A783AC: 56281F08
	v_fma_f32 v8, -v12, v47, v13                               // 000000A783B0: D6130008 24365F0C
	v_div_fixup_f32 v4, v11, v26, v4                           // 000000A783B8: D6270004 0412350B
	v_fma_mix_f32 v11, v34, v17, neg(0) op_sel_hi:[1,0,0]      // 000000A783C0: CC20000B 8A022322
	v_div_fmas_f32 v12, v19, v43, v32                          // 000000A783C8: D637000C 04825713
	v_fma_f32 v13, -v33, v20, v46                              // 000000A783D0: D613000D 24BA2921
	s_mov_b32 vcc_lo, s8                                       // 000000A783D8: BEEA0008
	s_waitcnt vmcnt(0)                                         // 000000A783DC: BF8903F7
	v_fma_mix_f32 v6, v23, v6, neg(0) op_sel_hi:[1,0,0]        // 000000A783E0: CC200006 8A020D17
	v_div_fmas_f32 v8, v8, v45, v47                            // 000000A783E8: D6370008 04BE5B08
	s_mov_b32 vcc_lo, s5                                       // 000000A783F0: BEEA0005
	v_div_fixup_f32 v9, v12, v29, v9                           // 000000A783F4: D6270009 04263B0C
	v_div_fmas_f32 v13, v13, v15, v20                          // 000000A783FC: D637000D 04521F0D
	v_fma_mix_f32 v12, v22, v24, neg(0) op_sel_hi:[1,0,0]      // 000000A78404: CC20000C 8A023116
	v_div_fixup_f32 v8, v8, v31, v14                           // 000000A7840C: D6270008 043A3F08
	v_mul_f32_e32 v4, v7, v4                                   // 000000A78414: 10080907
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A78418: BF870194
	v_div_fixup_f32 v10, v13, v30, v10                         // 000000A7841C: D627000A 042A3D0D
	v_dual_mul_f32 v9, v12, v9 :: v_dual_mul_f32 v8, v11, v8   // 000000A78424: C8C6130C 0908110B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A7842C: BF870112
	v_mul_f32_e32 v0, v0, v10                                  // 000000A78430: 10001500
	v_fma_mix_f32 v7, v28, v9, neg(0) op_sel_hi:[1,0,0]        // 000000A78434: CC200007 8A02131C
	v_fma_mix_f32 v9, v2, v37, v3 op_sel_hi:[0,1,0]            // 000000A7843C: CC200009 140E4B02
	v_fma_mix_f32 v10, v5, v40, v6 op_sel_hi:[0,1,0]           // 000000A78444: CC20000A 141A5105
	v_fma_mix_f32 v2, v2, v37, -v3 op_sel_hi:[0,1,0]           // 000000A7844C: CC200002 940E4B02
	v_fma_mix_f32 v0, v16, v0, neg(0) op_sel_hi:[1,0,0]        // 000000A78454: CC200000 8A020110
	v_fma_mix_f32 v11, v4, v41, v7 op_sel_hi:[0,1,0]           // 000000A7845C: CC20000B 141E5304
	v_fma_mix_f32 v3, v5, v40, -v6 op_sel_hi:[0,1,0]           // 000000A78464: CC200003 941A5105
	v_fma_mix_f32 v4, v4, v41, -v7 op_sel_hi:[0,1,0]           // 000000A7846C: CC200004 941E5304
	v_add_f32_e32 v5, v9, v10                                  // 000000A78474: 060A1509
	v_fma_mix_f32 v12, v8, v42, v0 op_sel_hi:[0,1,0]           // 000000A78478: CC20000C 14025508
	v_fma_mix_f32 v0, v8, v42, -v0 op_sel_hi:[0,1,0]           // 000000A78480: CC200000 94025508
	v_dual_sub_f32 v7, v9, v10 :: v_dual_add_f32 v8, v2, v3    // 000000A78488: C9481509 07080702
	v_sub_f32_e32 v2, v2, v3                                   // 000000A78490: 08040702
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000A78494: BF8701B4
	v_add_f32_e32 v6, v11, v12                                 // 000000A78498: 060C190B
	v_sub_f32_e32 v9, v11, v12                                 // 000000A7849C: 0812190B
	v_add_f32_e32 v10, v4, v0                                  // 000000A784A0: 06140104
	v_dual_sub_f32 v0, v4, v0 :: v_dual_add_f32 v3, v5, v6     // 000000A784A4: C9480104 00020D05
	v_sub_f32_e32 v4, v5, v6                                   // 000000A784AC: 08080D05
	s_delay_alu instid0(VALU_DEP_3)                            // 000000A784B0: BF870003
	v_add_f32_e32 v6, v8, v10                                  // 000000A784B4: 060C1508
	v_sub_f32_e32 v8, v8, v10                                  // 000000A784B8: 08101508
	v_add_f32_e32 v10, v7, v9                                  // 000000A784BC: 06141307
	v_mov_b32_dpp v5, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A784C0: 7E0A02FA FF016103
	v_cndmask_b32_e64 v3, -v3, v3, s2                          // 000000A784C8: D5010003 200A0703
	v_sub_f32_e32 v7, v7, v9                                   // 000000A784D0: 080E1307
	v_mov_b32_dpp v14, v4 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A784D4: 7E1C02FA FF016104
	v_mov_b32_dpp v9, v10 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A784DC: 7E1202FA FF01610A
	v_cndmask_b32_e64 v10, -v10, v10, s2                       // 000000A784E4: D501000A 200A150A
	v_add_f32_e32 v3, v3, v5                                   // 000000A784EC: 06060B03
	v_mov_b32_dpp v5, v6 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A784F0: 7E0A02FA FF016106
	v_cndmask_b32_e64 v6, -v6, v6, s2                          // 000000A784F8: D5010006 200A0D06
	v_cndmask_b32_e64 v15, -v4, v4, s2                         // 000000A78500: D501000F 200A0904
	v_add_f32_e32 v9, v10, v9                                  // 000000A78508: 0612130A
	v_mov_b32_dpp v11, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A7850C: 7E1602FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, s3                          // 000000A78514: D5010003 200E0703
	v_add_f32_e32 v5, v6, v5                                   // 000000A7851C: 060A0B06
	v_add_f32_e32 v6, v2, v0                                   // 000000A78520: 060C0102
	v_sub_f32_e32 v10, v2, v0                                  // 000000A78524: 08140102
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A78528: BF870214
	v_add_f32_e32 v0, v3, v11                                  // 000000A7852C: 06001703
	v_mov_b32_dpp v2, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A78530: 7E0402FA FF016205
	v_cndmask_b32_e64 v3, -v5, v5, s3                          // 000000A78538: D5010003 200E0B05
	v_mov_b32_dpp v5, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A78540: 7E0A02FA FF016209
	v_cndmask_b32_e64 v9, -v9, v9, s3                          // 000000A78548: D5010009 200E1309
	v_mov_b32_dpp v11, v6 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A78550: 7E1602FA FF016106
	v_cndmask_b32_e64 v6, -v6, v6, s2                          // 000000A78558: D5010006 200A0D06
	v_add_f32_e32 v2, v3, v2                                   // 000000A78560: 06040503
	v_mov_b32_dpp v16, v10 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A78564: 7E2002FA FF01610A
	v_add_f32_e32 v5, v9, v5                                   // 000000A7856C: 060A0B09
	v_cndmask_b32_e64 v10, -v10, v10, s2                       // 000000A78570: D501000A 200A150A
	v_add_f32_e32 v6, v6, v11                                  // 000000A78578: 060C1706
	v_mov_b32_dpp v9, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A7857C: 7E1202FA FF016402
	v_cndmask_b32_e64 v2, -v2, v2, s4                          // 000000A78584: D5010002 20120502
	v_mov_b32_dpp v11, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A7858C: 7E1602FA FF016405
	v_cndmask_b32_e64 v5, -v5, v5, s4                          // 000000A78594: D5010005 20120B05
	v_mov_b32_dpp v12, v6 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A7859C: 7E1802FA FF016206
	v_cndmask_b32_e64 v13, -v6, v6, s3                         // 000000A785A4: D501000D 200E0D06
	v_add_f32_e32 v4, v2, v9                                   // 000000A785AC: 06081302
	v_add_f32_e32 v10, v10, v16                                // 000000A785B0: 0614210A
	v_dual_add_f32 v6, v5, v11 :: v_dual_add_f32 v11, v15, v14 // 000000A785B4: C9081705 060A1D0F
	v_mov_b32_dpp v14, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A785BC: 7E1C02FA FF016108
	v_cndmask_b32_e64 v8, -v8, v8, s2                          // 000000A785C4: D5010008 200A1108
	v_mov_b32_dpp v15, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A785CC: 7E1E02FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, s2                          // 000000A785D4: D5010007 200A0F07
	v_add_f32_e32 v9, v13, v12                                 // 000000A785DC: 0612190D
	v_mov_b32_dpp v13, v11 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A785E0: 7E1A02FA FF01620B
	v_cndmask_b32_e64 v11, -v11, v11, s3                       // 000000A785E8: D501000B 200E170B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000A785F0: BF870234
	v_dual_add_f32 v8, v8, v14 :: v_dual_add_f32 v7, v7, v15   // 000000A785F4: C9081D08 08061F07
	v_mov_b32_dpp v15, v10 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A785FC: 7E1E02FA FF01620A
	v_cndmask_b32_e64 v10, -v10, v10, s3                       // 000000A78604: D501000A 200E150A
	v_add_f32_e32 v11, v11, v13                                // 000000A7860C: 06161B0B
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A78610: BF870004
	v_mov_b32_dpp v13, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A78614: 7E1A02FA FF016208
	v_cndmask_b32_e64 v8, -v8, v8, s3                          // 000000A7861C: D5010008 200E1108
	v_mov_b32_dpp v14, v7 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A78624: 7E1C02FA FF016207
	v_cndmask_b32_e64 v7, -v7, v7, s3                          // 000000A7862C: D5010007 200E0F07
	v_add_f32_e32 v10, v10, v15                                // 000000A78634: 06141F0A
	v_mov_b32_dpp v3, v0 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A78638: 7E0602FA FF016400
	v_add_f32_e32 v8, v8, v13                                  // 000000A78640: 06101B08
	v_cndmask_b32_e64 v0, -v0, v0, s4                          // 000000A78644: D5010000 20120100
	v_add_f32_e32 v7, v7, v14                                  // 000000A7864C: 060E1D07
	v_mov_b32_dpp v12, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A78650: 7E1802FA FF016409
	v_cndmask_b32_e64 v9, -v9, v9, s4                          // 000000A78658: D5010009 20121309
	v_mov_b32_dpp v13, v11 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A78660: 7E1A02FA FF01640B
	v_cndmask_b32_e64 v11, -v11, v11, s4                       // 000000A78668: D501000B 2012170B
	v_mov_b32_dpp v14, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A78670: 7E1C02FA FF016408
	v_cndmask_b32_e64 v8, -v8, v8, s4                          // 000000A78678: D5010008 20121108
	v_mov_b32_dpp v15, v7 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A78680: 7E1E02FA FF016407
	v_cndmask_b32_e64 v7, -v7, v7, s4                          // 000000A78688: D5010007 20120F07
	v_mov_b32_dpp v16, v10 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A78690: 7E2002FA FF01640A
	v_cndmask_b32_e64 v17, -v10, v10, s4                       // 000000A78698: D5010011 2012150A
	v_dual_add_f32 v0, v0, v3 :: v_dual_add_f32 v9, v9, v12    // 000000A786A0: C9080700 00081909
	v_dual_add_f32 v10, v11, v13 :: v_dual_add_f32 v11, v8, v14// 000000A786A8: C9081B0B 0A0A1D08
	v_add_f32_e32 v13, v7, v15                                 // 000000A786B0: 061A1F07
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A786B4: BF870214
	v_add_f32_e32 v15, v17, v16                                // 000000A786B8: 061E2111
	v_mov_b32_dpp v2, v0 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A786BC: 7E0402FA FF016800
	v_mov_b32_dpp v3, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A786C4: 7E0602FA FF016804
	v_mov_b32_dpp v5, v6 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A786CC: 7E0A02FA FF016806
	v_mov_b32_dpp v7, v9 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A786D4: 7E0E02FA FF016809
	v_mov_b32_dpp v8, v10 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A786DC: 7E1002FA FF01680A
	v_mov_b32_dpp v12, v11 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A786E4: 7E1802FA FF01680B
	v_mov_b32_dpp v14, v13 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A786EC: 7E1C02FA FF01680D
	v_mov_b32_dpp v16, v15 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A786F4: 7E2002FA FF01680F
	s_mov_b32 s2, 0x3db504f3                                   // 000000A786FC: BE8200FF 3DB504F3
	s_and_b32 exec_lo, exec_lo, s0                             // 000000A78704: 8B7E007E
	s_cbranch_execz 65                                         // 000000A78708: BFA50041 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi0EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x6110>
	v_cndmask_b32_e64 v15, -v15, v15, s1                       // 000000A7870C: D501000F 20061F0F
	v_cndmask_b32_e64 v0, -v0, v0, s1                          // 000000A78714: D5010000 20060100
	v_cndmask_b32_e64 v4, -v4, v4, s1                          // 000000A7871C: D5010004 20060904
	v_cndmask_b32_e64 v6, -v6, v6, s1                          // 000000A78724: D5010006 20060D06
	v_cndmask_b32_e64 v9, -v9, v9, s1                          // 000000A7872C: D5010009 20061309
	v_cndmask_b32_e64 v13, -v13, v13, s1                       // 000000A78734: D501000D 20061B0D
	v_cndmask_b32_e64 v10, -v10, v10, s1                       // 000000A7873C: D501000A 2006150A
	v_cndmask_b32_e64 v11, -v11, v11, s1                       // 000000A78744: D501000B 2006170B
	v_dual_add_f32 v15, v15, v16 :: v_dual_add_f32 v0, v0, v2  // 000000A7874C: C908210F 0F000500
	v_add_f32_e32 v3, v4, v3                                   // 000000A78754: 06060704
	v_add_f32_e32 v5, v6, v5                                   // 000000A78758: 060A0B06
	v_add_f32_e32 v7, v9, v7                                   // 000000A7875C: 060E0F09
	s_mul_i32 s0, s10, 0x500                                   // 000000A78760: 9600FF0A 00000500
	v_dual_add_f32 v13, v13, v14 :: v_dual_add_f32 v8, v10, v8 // 000000A78768: C9081D0D 0D08110A
	s_mul_hi_i32 s1, s10, 0x500                                // 000000A78770: 9701FF0A 00000500
	v_add_f32_e32 v11, v11, v12                                // 000000A78778: 0616190B
	s_add_u32 s0, s22, s0                                      // 000000A7877C: 80000016
	v_fma_mixlo_f16 v0, v0, s2, 0                              // 000000A78780: CC210000 02000500
	s_addc_u32 s1, s23, s1                                     // 000000A78788: 82010117
	v_fma_mixhi_f16 v0, v3, s2, 0                              // 000000A7878C: CC220000 02000503
	s_add_u32 s0, s0, s12                                      // 000000A78794: 80000C00
	v_fma_mixlo_f16 v2, v5, s2, 0                              // 000000A78798: CC210002 02000505
	s_addc_u32 s1, s1, s13                                     // 000000A787A0: 82010D01
	v_fma_mixhi_f16 v2, v7, s2, 0                              // 000000A787A4: CC220002 02000507
	v_fma_mixlo_f16 v3, v8, s2, 0                              // 000000A787AC: CC210003 02000508
	v_fma_mixhi_f16 v3, v11, s2, 0                             // 000000A787B4: CC220003 0200050B
	v_fma_mixlo_f16 v4, v13, s2, 0                             // 000000A787BC: CC210004 0200050D
	v_fma_mixhi_f16 v4, v15, s2, 0                             // 000000A787C4: CC220004 0200050F
	s_clause 0x7                                               // 000000A787CC: BF850007
	global_store_b16 v1, v0, s[0:1]                            // 000000A787D0: DC660000 00000001
	global_store_d16_hi_b16 v1, v0, s[0:1] offset:32           // 000000A787D8: DC960020 00000001
	global_store_b16 v1, v2, s[0:1] offset:64                  // 000000A787E0: DC660040 00000201
	global_store_d16_hi_b16 v1, v2, s[0:1] offset:96           // 000000A787E8: DC960060 00000201
	global_store_b16 v1, v3, s[0:1] offset:128                 // 000000A787F0: DC660080 00000301
	global_store_d16_hi_b16 v1, v3, s[0:1] offset:160          // 000000A787F8: DC9600A0 00000301
	global_store_b16 v1, v4, s[0:1] offset:192                 // 000000A78800: DC6600C0 00000401
	global_store_d16_hi_b16 v1, v4, s[0:1] offset:224          // 000000A78808: DC9600E0 00000401
	s_nop 0                                                    // 000000A78810: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 000000A78814: BFB60003
	s_endpgm                                                   // 000000A78818: BFB00000
	s_branch 62004                                             // 000000A7881C: BFA0F234 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi4ELi0EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x29f0>
		...

