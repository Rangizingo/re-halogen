0000000000819400 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi16ELi1ELb0ELi2ELi0EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi16ELi1ELb0ELi2ELi0EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 000000819400: F4100100 F8000000
	v_dual_mov_b32 v4, 0 :: v_dual_and_b32 v15, 15, v0         // 000000819408: CA240080 040E008F
	v_lshrrev_b32_e32 v1, 4, v0                                // 000000819410: 32020084
	s_ashr_i32 s3, s2, 31                                      // 000000819414: 86039F02
	v_mov_b32_e32 v16, 0                                       // 000000819418: 7E200280
	s_lshl_b64 s[0:1], s[2:3], 4                               // 00000081941C: 84808402
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000819420: BF870009
	v_dual_mov_b32 v9, s1 :: v_dual_lshlrev_b32 v2, 2, v15     // 000000819424: CA220001 09021E82
	v_lshlrev_b32_e32 v3, 2, v1                                // 00000081942C: 30060282
	v_or_b32_e32 v8, s0, v1                                    // 000000819430: 38100200
	.long 0x7f183880                                           // 000000819434: 7F183880
	v_dual_mov_b32 v26, 0 :: v_dual_mov_b32 v5, 0              // 000000819438: CA100080 1A040080
	v_mov_b32_e32 v6, 0                                        // 000000819440: 7E0C0280
	s_waitcnt lgkmcnt(0)                                       // 000000819444: BF89FC07
	s_clause 0x1                                               // 000000819448: BF850001
	global_load_b32 v7, v2, s[4:5]                             // 00000081944C: DC520000 07040002
	global_load_b32 v3, v3, s[4:5]                             // 000000819454: DC520000 03040003
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[8:9]                  // 00000081945C: 7CA8100C
	s_add_u32 s2, s4, s14                                      // 000000819460: 80020E04
	s_addc_u32 s3, s5, s15                                     // 000000819464: 82030F05
	s_lshr_b32 s0, s11, 31                                     // 000000819468: 85009F0B
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000081946C: BF870009
	s_add_u32 s14, s10, s0                                     // 000000819470: 800E000A
	v_cndmask_b32_e32 v10, 0, v8, vcc_lo                       // 000000819474: 02141080
	v_cndmask_b32_e64 v14, 0, s1, vcc_lo                       // 000000819478: D501000E 01A80280
	s_addc_u32 s15, s11, 0                                     // 000000819480: 820F800B
	s_ashr_i32 s20, s11, 31                                    // 000000819484: 86149F0B
	s_ashr_i64 s[0:1], s[14:15], 1                             // 000000819488: 8680810E
	s_lshr_b32 s14, s20, 27                                    // 00000081948C: 850E9B14
	.long 0xd72c0013                                           // 000000819490: D72C0013
	v_cndmask_b32_e32 v0, v14, v0, vcc_lo                      // 000000819494: 0200010E
	.long 0xd72c000e                                           // 000000819498: D72C000E
	v_cndmask_b32_e32 v1, s18, v14, vcc_lo                     // 00000081949C: 02021C12
	s_waitcnt vmcnt(1)                                         // 0000008194A0: BF8907F7
	v_bfe_u32 v11, v7, 16, 1                                   // 0000008194A4: D610000B 02052107
	s_waitcnt vmcnt(0)                                         // 0000008194AC: BF8903F7
	v_bfe_u32 v18, v3, 16, 1                                   // 0000008194B0: D6100012 02052103
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000008194B8: BF870112
	v_add3_u32 v7, v7, v11, 0x7fff                             // 0000008194BC: D6550007 03FE1707 00007FFF
	v_add3_u32 v3, v3, v18, 0x7fff                             // 0000008194C8: D6550003 03FE2503 00007FFF
	v_lshlrev_b32_e32 v18, 2, v0                               // 0000008194D4: 30240082
	s_delay_alu instid0(VALU_DEP_3)                            // 0000008194D8: BF870003
	.long 0x7e183987                                           // 0000008194DC: 7E183987
	v_mov_b32_e32 v7, 0                                        // 0000008194E0: 7E0E0280
	.long 0xd72c000d                                           // 0000008194E4: D72C000D
	v_cndmask_b32_e32 v1, s19, v10, vcc_lo                     // 0000008194E8: 02021413
	v_mad_u64_u32 v[1:2], null, s18, v10, 0                    // 0000008194EC: D6FE7C01 02021412
	.long 0xd72c0011                                           // 0000008194F4: D72C0011
	v_cndmask_b32_e32 v0, v10, v1, vcc_lo                      // 0000008194F8: 0200030A
	v_mad_u64_u32 v[10:11], null, v10, s0, s[2:3]              // 0000008194FC: D6FE7C0A 0008010A
	s_add_u32 s2, s10, s14                                     // 000000819504: 80020E0A
	s_addc_u32 s3, s11, 0                                      // 000000819508: 8203800B
	v_and_or_b32 v3, 0xffff0000, v3, v12                       // 00000081950C: D6570003 043206FF FFFF0000
	s_lshr_b64 s[2:3], s[2:3], 5                               // 000000819518: 85828502
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000081951C: BF870009
	.long 0xd4440000                                           // 000000819520: D4440000
	v_cndmask_b32_e32 v1, s2, v15, vcc_lo                      // 000000819524: 02021E02
	v_add3_u32 v0, v2, v14, v13                                // 000000819528: D6550000 04361D02
	v_add3_u32 v17, v19, v11, v17                              // 000000819530: D6550011 04461713
	ds_store_b32 v18, v3                                       // 000000819538: D8340000 00000312
	s_waitcnt lgkmcnt(0)                                       // 000000819540: BF89FC07
	s_barrier                                                  // 000000819544: BFBD0000
	buffer_gl0_inv                                             // 000000819548: E0AC0000 00000000
	s_and_saveexec_b32 s3, s0                                  // 000000819550: BE832000
	s_cbranch_execz 26                                         // 000000819554: BFA5001A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi16ELi1ELb0ELi2ELi0EEEvPKhPKtPvlllllS6_f+0x1c0>
	s_add_u32 s1, s4, s16                                      // 000000819558: 80011004
	s_addc_u32 s14, s5, s17                                    // 00000081955C: 820E1105
	v_lshlrev_b32_e32 v2, 1, v15                               // 000000819560: 30041E81
	.long 0xd7000103                                           // 000000819564: D7000103
	v_cndmask_b32_e32 v1, s1, v1, vcc_lo                       // 000000819568: 02020201
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000081956C: BF8701A1
	v_add_co_ci_u32_e64 v4, null, s14, v0, s1                  // 000000819570: D5207C04 0006000E
	v_lshlrev_b32_e32 v5, 4, v15                               // 000000819578: 300A1E84
	.long 0xd7000102                                           // 00000081957C: D7000102
	v_cndmask_b32_e32 v1, v3, v2, vcc_lo                       // 000000819580: 02020503
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000819584: BF870191
	v_add_co_ci_u32_e64 v3, null, 0, v4, s1                    // 000000819588: D5207C03 00060880
	.long 0xd7000104                                           // 000000819590: D7000104
	v_cndmask_b32_e32 v1, v10, v5, vcc_lo                      // 000000819594: 02020B0A
	s_delay_alu instid0(VALU_DEP_1)                            // 000000819598: BF870001
	v_add_co_ci_u32_e64 v5, null, 0, v17, s1                   // 00000081959C: D5207C05 00062280
	s_clause 0x1                                               // 0000008195A4: BF850001
	global_load_d16_b16 v2, v[2:3], off                        // 0000008195A8: DC820000 027C0002
	global_load_b128 v[4:7], v[4:5], off                       // 0000008195B0: DC5E0000 047C0004
	s_waitcnt vmcnt(1)                                         // 0000008195B8: BF8907F7
	v_cvt_f32_f16_e32 v26, v2                                  // 0000008195BC: 7E341702
	s_or_b32 exec_lo, exec_lo, s3                              // 0000008195C0: 8C7E037E
	v_dual_mov_b32 v18, 0 :: v_dual_mov_b32 v19, 0             // 0000008195C4: CA100080 12120080
	v_dual_mov_b32 v20, 0 :: v_dual_mov_b32 v21, 0             // 0000008195CC: CA100080 14140080
	v_mov_b32_e32 v22, 0                                       // 0000008195D4: 7E2C0280
	s_and_saveexec_b32 s3, s0                                  // 0000008195D8: BE832000
	s_cbranch_execz 537                                        // 0000008195DC: BFA50219 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi16ELi1ELb0ELi2ELi0EEEvPKhPKtPvlllllS6_f+0xa44>
	s_mul_i32 s0, s11, 6                                       // 0000008195E0: 9600860B
	s_mul_hi_u32 s1, s10, 6                                    // 0000008195E4: 9681860A
	v_dual_mov_b32 v12, 0 :: v_dual_lshlrev_b32 v11, 5, v15    // 0000008195E8: CA220080 0C0A1E85
	s_add_i32 s18, s1, s0                                      // 0000008195F0: 81120001
	v_lshlrev_b32_e32 v2, 1, v15                               // 0000008195F4: 30041E81
	.long 0xd7000001                                           // 0000008195F8: D7000001
	v_cndmask_b32_e32 v1, s16, v1, vcc_lo                      // 0000008195FC: 02020210
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000819600: BF8701A1
	v_add_co_ci_u32_e64 v0, null, s17, v0, s0                  // 000000819604: D5207C00 00020011
	v_mov_b32_e32 v21, v12                                     // 00000081960C: 7E2A030C
	.long 0xd7000001                                           // 000000819610: D7000001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 000000819614: 02020501
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000819618: BF8701A1
	v_add_co_ci_u32_e64 v0, null, 0, v0, s0                    // 00000081961C: D5207C00 00020080
	v_lshl_or_b32 v23, v15, 4, 0x100                           // 000000819624: D6560017 03FD090F 00000100
	.long 0xd7000001                                           // 000000819630: D7000001
	v_cndmask_b32_e32 v1, s4, v1, vcc_lo                       // 000000819634: 02020204
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000819638: BF8701A1
	v_add_co_ci_u32_e64 v0, null, s5, v0, s0                   // 00000081963C: D5207C00 00020005
	v_dual_mov_b32 v24, v15 :: v_dual_mov_b32 v19, v12         // 000000819644: CA10010F 1812010C
	.long 0xd700000d                                           // 00000081964C: D700000D
	v_cndmask_b32_e32 v0, v1, v160, vcc_lo                     // 000000819650: 02014101
	s_delay_alu instid0(VALU_DEP_1)                            // 000000819654: BF870001
	v_add_co_ci_u32_e64 v14, null, 0, v0, s0                   // 000000819658: D5207C0E 00020080
	v_dual_mov_b32 v22, v12 :: v_dual_mov_b32 v25, v26         // 000000819660: CA10010C 1618011A
	v_mov_b32_e32 v20, v12                                     // 000000819668: 7E28030C
	v_mov_b32_e32 v18, v12                                     // 00000081966C: 7E24030C
	v_mov_b32_e32 v16, v12                                     // 000000819670: 7E20030C
	s_lshl_b64 s[14:15], s[10:11], 2                           // 000000819674: 848E820A
	s_mul_i32 s17, s10, 6                                      // 000000819678: 9611860A
	s_mov_b32 s16, 0                                           // 00000081967C: BE900080
	s_lshl_b64 s[4:5], s[10:11], 1                             // 000000819680: 8484810A
	s_branch 469                                               // 000000819684: BFA001D5 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi16ELi1ELb0ELi2ELi0EEEvPKhPKtPvlllllS6_f+0x9dc>
	s_or_b32 exec_lo, exec_lo, s10                             // 000000819688: 8C7E0A7E
	v_and_b32_e32 v27, 0xff, v4                                // 00000081968C: 363608FF 000000FF
	s_and_b32 s0, exec_lo, s0                                  // 000000819694: 8B00007E
	v_add_nc_u32_e32 v23, 0x100, v23                           // 000000819698: 4A2E2EFF 00000100
	s_or_b32 s16, s0, s16                                      // 0000008196A0: 8C101000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008196A4: BF8700B2
	v_lshlrev_b32_e32 v27, 2, v27                              // 0000008196A8: 30363682
	ds_load_b32 v43, v27                                       // 0000008196AC: D8D80000 2B00001B
	v_lshrrev_b32_e32 v27, 6, v4                               // 0000008196B4: 32360886
	v_and_b32_e32 v27, 0x3fc, v27                              // 0000008196B8: 363636FF 000003FC
	ds_load_b32 v44, v27                                       // 0000008196C0: D8D80000 2C00001B
	v_lshrrev_b32_e32 v27, 14, v4                              // 0000008196C8: 3236088E
	v_lshrrev_b32_e32 v4, 22, v4                               // 0000008196CC: 32080896
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000008196D0: BF870112
	v_and_b32_e32 v27, 0x3fc, v27                              // 0000008196D4: 363636FF 000003FC
	v_and_b32_e32 v4, 0x3fc, v4                                // 0000008196DC: 360808FF 000003FC
	ds_load_b32 v45, v27                                       // 0000008196E4: D8D80000 2D00001B
	ds_load_b32 v46, v4                                        // 0000008196EC: D8D80000 2E000004
	v_and_b32_e32 v4, 0xff, v5                                 // 0000008196F4: 36080AFF 000000FF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008196FC: BF8700B1
	v_lshlrev_b32_e32 v4, 2, v4                                // 000000819700: 30080882
	ds_load_b32 v47, v4                                        // 000000819704: D8D80000 2F000004
	v_lshrrev_b32_e32 v4, 6, v5                                // 00000081970C: 32080A86
	v_and_b32_e32 v4, 0x3fc, v4                                // 000000819710: 360808FF 000003FC
	ds_load_b32 v48, v4                                        // 000000819718: D8D80000 30000004
	v_lshrrev_b32_e32 v4, 14, v5                               // 000000819720: 32080A8E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000819724: BF8700B1
	v_and_b32_e32 v4, 0x3fc, v4                                // 000000819728: 360808FF 000003FC
	ds_load_b32 v49, v4                                        // 000000819730: D8D80000 31000004
	v_lshrrev_b32_e32 v4, 22, v5                               // 000000819738: 32080A96
	v_and_b32_e32 v4, 0x3fc, v4                                // 00000081973C: 360808FF 000003FC
	ds_load_b32 v50, v4                                        // 000000819744: D8D80000 32000004
	v_and_b32_e32 v4, 0xff, v6                                 // 00000081974C: 36080CFF 000000FF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000819754: BF8700B1
	v_lshlrev_b32_e32 v4, 2, v4                                // 000000819758: 30080882
	ds_load_b32 v51, v4                                        // 00000081975C: D8D80000 33000004
	v_lshrrev_b32_e32 v4, 6, v6                                // 000000819764: 32080C86
	v_and_b32_e32 v4, 0x3fc, v4                                // 000000819768: 360808FF 000003FC
	ds_load_b32 v52, v4                                        // 000000819770: D8D80000 34000004
	v_lshrrev_b32_e32 v4, 14, v6                               // 000000819778: 32080C8E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000081977C: BF8700B1
	v_and_b32_e32 v4, 0x3fc, v4                                // 000000819780: 360808FF 000003FC
	ds_load_b32 v53, v4                                        // 000000819788: D8D80000 35000004
	v_lshrrev_b32_e32 v4, 22, v6                               // 000000819790: 32080C96
	v_and_b32_e32 v4, 0x3fc, v4                                // 000000819794: 360808FF 000003FC
	ds_load_b32 v54, v4                                        // 00000081979C: D8D80000 36000004
	v_and_b32_e32 v4, 0xff, v7                                 // 0000008197A4: 36080EFF 000000FF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008197AC: BF8700B1
	v_lshlrev_b32_e32 v4, 2, v4                                // 0000008197B0: 30080882
	ds_load_b32 v55, v4                                        // 0000008197B4: D8D80000 37000004
	v_lshrrev_b32_e32 v4, 6, v7                                // 0000008197BC: 32080E86
	v_and_b32_e32 v4, 0x3fc, v4                                // 0000008197C0: 360808FF 000003FC
	ds_load_b32 v56, v4                                        // 0000008197C8: D8D80000 38000004
	v_lshrrev_b32_e32 v4, 14, v7                               // 0000008197D0: 32080E8E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008197D4: BF8700B1
	v_and_b32_e32 v4, 0x3fc, v4                                // 0000008197D8: 360808FF 000003FC
	ds_load_b32 v57, v4                                        // 0000008197E0: D8D80000 39000004
	v_lshrrev_b32_e32 v4, 22, v7                               // 0000008197E8: 32080E96
	v_and_b32_e32 v4, 0x3fc, v4                                // 0000008197EC: 360808FF 000003FC
	ds_load_b32 v58, v4                                        // 0000008197F4: D8D80000 3A000004
	.long 0xd73c0004                                           // 0000008197FC: D73C0004
	v_cndmask_b32_e32 v1, 1, v11, vcc_lo                       // 000000819800: 02021681
	v_add_nc_u32_e32 v11, 0x200, v11                           // 000000819804: 4A1616FF 00000200
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000081980C: BF870092
	.long 0xd7000027                                           // 000000819810: D7000027
	v_cndmask_b32_e32 v1, s6, v4, vcc_lo                       // 000000819814: 02020806
	v_add_co_ci_u32_e64 v40, null, s7, v5, s0                  // 000000819818: D5207C28 00020A07
	s_clause 0x3                                               // 000000819820: BF850003
	global_load_b128 v[4:7], v[39:40], off                     // 000000819824: DC5E0000 047C0027
	global_load_b128 v[27:30], v[39:40], off offset:16         // 00000081982C: DC5E0010 1B7C0027
	global_load_b128 v[31:34], v[39:40], off offset:32         // 000000819834: DC5E0020 1F7C0027
	global_load_b128 v[35:38], v[39:40], off offset:48         // 00000081983C: DC5E0030 237C0027
	s_waitcnt vmcnt(3) lgkmcnt(15)                             // 000000819844: BF890CF7
	v_dot2_f32_bf16 v4, v4, v43, 0                             // 000000819848: CC1A4004 1A025704
	s_waitcnt lgkmcnt(14)                                      // 000000819850: BF89FCE7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000819854: BF8700A1
	v_dot2_f32_bf16 v4, v5, v44, v4                            // 000000819858: CC1A4004 1C125905
	s_waitcnt lgkmcnt(13)                                      // 000000819860: BF89FCD7
	v_dot2_f32_bf16 v4, v6, v45, v4                            // 000000819864: CC1A4004 1C125B06
	s_waitcnt lgkmcnt(12)                                      // 00000081986C: BF89FCC7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000819870: BF8700A1
	v_dot2_f32_bf16 v4, v7, v46, v4                            // 000000819874: CC1A4004 1C125D07
	s_waitcnt vmcnt(2) lgkmcnt(11)                             // 00000081987C: BF8908B7
	v_dot2_f32_bf16 v4, v27, v47, v4                           // 000000819880: CC1A4004 1C125F1B
	s_waitcnt lgkmcnt(10)                                      // 000000819888: BF89FCA7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000081988C: BF8700A1
	v_dot2_f32_bf16 v4, v28, v48, v4                           // 000000819890: CC1A4004 1C12611C
	s_waitcnt lgkmcnt(9)                                       // 000000819898: BF89FC97
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 00000081989C: CC1A4004 1C12631D
	s_waitcnt lgkmcnt(8)                                       // 0000008198A4: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008198A8: BF8700A1
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 0000008198AC: CC1A4004 1C12651E
	s_waitcnt vmcnt(1) lgkmcnt(7)                              // 0000008198B4: BF890477
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 0000008198B8: CC1A4004 1C12671F
	s_waitcnt lgkmcnt(6)                                       // 0000008198C0: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008198C4: BF8700A1
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 0000008198C8: CC1A4004 1C126920
	s_waitcnt lgkmcnt(5)                                       // 0000008198D0: BF89FC57
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 0000008198D4: CC1A4004 1C126B21
	s_waitcnt lgkmcnt(4)                                       // 0000008198DC: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008198E0: BF8700A1
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 0000008198E4: CC1A4004 1C126D22
	s_waitcnt vmcnt(0) lgkmcnt(3)                              // 0000008198EC: BF890037
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 0000008198F0: CC1A4004 1C126F23
	.long 0xd7000023                                           // 0000008198F8: D7000023
	v_cndmask_b32_e32 v0, v39, v4, vcc_lo                      // 0000008198FC: 02000927
	s_waitcnt lgkmcnt(2)                                       // 000000819900: BF89FC27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000819904: BF8701C2
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 000000819908: CC1A4004 1C127124
	v_add_co_ci_u32_e64 v36, null, s5, v40, s0                 // 000000819910: D5207C24 00025005
	.long 0xd7000029                                           // 000000819918: D7000029
	v_cndmask_b32_e32 v0, v39, v14, vcc_lo                     // 00000081991C: 02001D27
	s_waitcnt lgkmcnt(1)                                       // 000000819920: BF89FC17
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 000000819924: CC1A4004 1C127325
	v_add_co_ci_u32_e64 v42, null, s15, v40, s0                // 00000081992C: D5207C2A 0002500F
	.long 0xd7000027                                           // 000000819934: D7000027
	v_cndmask_b32_e32 v0, v39, v17, vcc_lo                     // 000000819938: 02002327
	s_waitcnt lgkmcnt(0)                                       // 00000081993C: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000819940: BF870123
	v_dot2_f32_bf16 v4, v38, v58, v4                           // 000000819944: CC1A4004 1C127526
	v_add_co_ci_u32_e64 v40, null, s18, v40, s0                // 00000081994C: D5207C28 00025012
	v_fmac_f32_e32 v22, v26, v4                                // 000000819954: 562C091A
	s_clause 0x3                                               // 000000819958: BF850003
	global_load_b128 v[4:7], v[35:36], off                     // 00000081995C: DC5E0000 047C0023
	global_load_b128 v[27:30], v[35:36], off offset:16         // 000000819964: DC5E0010 1B7C0023
	global_load_b128 v[31:34], v[35:36], off offset:32         // 00000081996C: DC5E0020 1F7C0023
	global_load_b128 v[35:38], v[35:36], off offset:48         // 000000819974: DC5E0030 237C0023
	s_waitcnt vmcnt(3)                                         // 00000081997C: BF890FF7
	v_dot2_f32_bf16 v4, v4, v43, 0                             // 000000819980: CC1A4004 1A025704
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000819988: BF870091
	v_dot2_f32_bf16 v4, v5, v44, v4                            // 00000081998C: CC1A4004 1C125905
	v_dot2_f32_bf16 v4, v6, v45, v4                            // 000000819994: CC1A4004 1C125B06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000081999C: BF8700A1
	v_dot2_f32_bf16 v4, v7, v46, v4                            // 0000008199A0: CC1A4004 1C125D07
	s_waitcnt vmcnt(2)                                         // 0000008199A8: BF890BF7
	v_dot2_f32_bf16 v4, v27, v47, v4                           // 0000008199AC: CC1A4004 1C125F1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008199B4: BF870091
	v_dot2_f32_bf16 v4, v28, v48, v4                           // 0000008199B8: CC1A4004 1C12611C
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 0000008199C0: CC1A4004 1C12631D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008199C8: BF8700A1
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 0000008199CC: CC1A4004 1C12651E
	s_waitcnt vmcnt(1)                                         // 0000008199D4: BF8907F7
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 0000008199D8: CC1A4004 1C12671F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008199E0: BF870091
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 0000008199E4: CC1A4004 1C126920
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 0000008199EC: CC1A4004 1C126B21
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008199F4: BF8700A1
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 0000008199F8: CC1A4004 1C126D22
	s_waitcnt vmcnt(0)                                         // 000000819A00: BF8903F7
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 000000819A04: CC1A4004 1C126F23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000819A0C: BF870091
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 000000819A10: CC1A4004 1C127124
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 000000819A18: CC1A4004 1C127325
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000819A20: BF870091
	v_dot2_f32_bf16 v4, v38, v58, v4                           // 000000819A24: CC1A4004 1C127526
	v_fmac_f32_e32 v21, v26, v4                                // 000000819A2C: 562A091A
	s_clause 0x3                                               // 000000819A30: BF850003
	global_load_b128 v[4:7], v[41:42], off                     // 000000819A34: DC5E0000 047C0029
	global_load_b128 v[27:30], v[41:42], off offset:16         // 000000819A3C: DC5E0010 1B7C0029
	global_load_b128 v[31:34], v[41:42], off offset:32         // 000000819A44: DC5E0020 1F7C0029
	global_load_b128 v[35:38], v[41:42], off offset:48         // 000000819A4C: DC5E0030 237C0029
	s_waitcnt vmcnt(3)                                         // 000000819A54: BF890FF7
	v_dot2_f32_bf16 v4, v4, v43, 0                             // 000000819A58: CC1A4004 1A025704
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000819A60: BF870091
	v_dot2_f32_bf16 v4, v5, v44, v4                            // 000000819A64: CC1A4004 1C125905
	v_dot2_f32_bf16 v4, v6, v45, v4                            // 000000819A6C: CC1A4004 1C125B06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000819A74: BF8700A1
	v_dot2_f32_bf16 v4, v7, v46, v4                            // 000000819A78: CC1A4004 1C125D07
	s_waitcnt vmcnt(2)                                         // 000000819A80: BF890BF7
	v_dot2_f32_bf16 v4, v27, v47, v4                           // 000000819A84: CC1A4004 1C125F1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000819A8C: BF870091
	v_dot2_f32_bf16 v4, v28, v48, v4                           // 000000819A90: CC1A4004 1C12611C
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 000000819A98: CC1A4004 1C12631D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000819AA0: BF8700A1
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 000000819AA4: CC1A4004 1C12651E
	s_waitcnt vmcnt(1)                                         // 000000819AAC: BF8907F7
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 000000819AB0: CC1A4004 1C12671F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000819AB8: BF870091
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 000000819ABC: CC1A4004 1C126920
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 000000819AC4: CC1A4004 1C126B21
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000819ACC: BF8700A1
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 000000819AD0: CC1A4004 1C126D22
	s_waitcnt vmcnt(0)                                         // 000000819AD8: BF8903F7
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 000000819ADC: CC1A4004 1C126F23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000819AE4: BF870091
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 000000819AE8: CC1A4004 1C127124
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 000000819AF0: CC1A4004 1C127325
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000819AF8: BF870091
	v_dot2_f32_bf16 v4, v38, v58, v4                           // 000000819AFC: CC1A4004 1C127526
	v_fmac_f32_e32 v20, v26, v4                                // 000000819B04: 5628091A
	s_clause 0x3                                               // 000000819B08: BF850003
	global_load_b128 v[4:7], v[39:40], off                     // 000000819B0C: DC5E0000 047C0027
	global_load_b128 v[27:30], v[39:40], off offset:16         // 000000819B14: DC5E0010 1B7C0027
	global_load_b128 v[31:34], v[39:40], off offset:32         // 000000819B1C: DC5E0020 1F7C0027
	global_load_b128 v[35:38], v[39:40], off offset:48         // 000000819B24: DC5E0030 237C0027
	s_waitcnt vmcnt(3)                                         // 000000819B2C: BF890FF7
	v_dot2_f32_bf16 v4, v4, v43, 0                             // 000000819B30: CC1A4004 1A025704
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000819B38: BF870091
	v_dot2_f32_bf16 v4, v5, v44, v4                            // 000000819B3C: CC1A4004 1C125905
	v_dot2_f32_bf16 v4, v6, v45, v4                            // 000000819B44: CC1A4004 1C125B06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000819B4C: BF8700A1
	v_dot2_f32_bf16 v4, v7, v46, v4                            // 000000819B50: CC1A4004 1C125D07
	s_waitcnt vmcnt(2)                                         // 000000819B58: BF890BF7
	v_dot2_f32_bf16 v4, v27, v47, v4                           // 000000819B5C: CC1A4004 1C125F1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000819B64: BF870091
	v_dot2_f32_bf16 v4, v28, v48, v4                           // 000000819B68: CC1A4004 1C12611C
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 000000819B70: CC1A4004 1C12631D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000819B78: BF8700A1
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 000000819B7C: CC1A4004 1C12651E
	s_waitcnt vmcnt(1)                                         // 000000819B84: BF8907F7
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 000000819B88: CC1A4004 1C12671F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000819B90: BF870091
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 000000819B94: CC1A4004 1C126920
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 000000819B9C: CC1A4004 1C126B21
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000819BA4: BF8700A1
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 000000819BA8: CC1A4004 1C126D22
	s_waitcnt vmcnt(0)                                         // 000000819BB0: BF8903F7
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 000000819BB4: CC1A4004 1C126F23
	.long 0xd7000023                                           // 000000819BBC: D7000023
	v_cndmask_b32_e32 v0, v41, v14, vcc_lo                     // 000000819BC0: 02001D29
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000819BC4: BF870122
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 000000819BC8: CC1A4004 1C127124
	v_add_co_ci_u32_e64 v36, null, s15, v42, s0                // 000000819BD0: D5207C24 0002540F
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 000000819BD8: CC1A4004 1C127325
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000819BE0: BF870091
	v_dot2_f32_bf16 v4, v38, v58, v4                           // 000000819BE4: CC1A4004 1C127526
	v_fmac_f32_e32 v19, v26, v4                                // 000000819BEC: 5626091A
	s_clause 0x3                                               // 000000819BF0: BF850003
	global_load_b128 v[4:7], v[35:36], off                     // 000000819BF4: DC5E0000 047C0023
	global_load_b128 v[27:30], v[35:36], off offset:16         // 000000819BFC: DC5E0010 1B7C0023
	global_load_b128 v[31:34], v[35:36], off offset:32         // 000000819C04: DC5E0020 1F7C0023
	global_load_b128 v[35:38], v[35:36], off offset:48         // 000000819C0C: DC5E0030 237C0023
	s_waitcnt vmcnt(3)                                         // 000000819C14: BF890FF7
	v_dot2_f32_bf16 v4, v4, v43, 0                             // 000000819C18: CC1A4004 1A025704
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000819C20: BF870091
	v_dot2_f32_bf16 v4, v5, v44, v4                            // 000000819C24: CC1A4004 1C125905
	v_dot2_f32_bf16 v4, v6, v45, v4                            // 000000819C2C: CC1A4004 1C125B06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000819C34: BF8700A1
	v_dot2_f32_bf16 v4, v7, v46, v4                            // 000000819C38: CC1A4004 1C125D07
	s_waitcnt vmcnt(2)                                         // 000000819C40: BF890BF7
	v_dot2_f32_bf16 v4, v27, v47, v4                           // 000000819C44: CC1A4004 1C125F1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000819C4C: BF870091
	v_dot2_f32_bf16 v4, v28, v48, v4                           // 000000819C50: CC1A4004 1C12611C
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 000000819C58: CC1A4004 1C12631D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000819C60: BF8700A1
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 000000819C64: CC1A4004 1C12651E
	s_waitcnt vmcnt(1)                                         // 000000819C6C: BF8907F7
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 000000819C70: CC1A4004 1C12671F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000819C78: BF870091
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 000000819C7C: CC1A4004 1C126920
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 000000819C84: CC1A4004 1C126B21
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000819C8C: BF8700A1
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 000000819C90: CC1A4004 1C126D22
	s_waitcnt vmcnt(0)                                         // 000000819C98: BF8903F7
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 000000819C9C: CC1A4004 1C126F23
	.long 0xd7000023                                           // 000000819CA4: D7000023
	v_cndmask_b32_e32 v0, v39, v14, vcc_lo                     // 000000819CA8: 02001D27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000819CAC: BF8701B2
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 000000819CB0: CC1A4004 1C127124
	v_add_co_ci_u32_e64 v36, null, s15, v40, s0                // 000000819CB8: D5207C24 0002500F
	.long 0xd700000d                                           // 000000819CC0: D700000D
	v_cndmask_b32_e32 v0, v13, v160, vcc_lo                    // 000000819CC4: 0201410D
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 000000819CC8: CC1A4004 1C127325
	v_add_co_ci_u32_e64 v14, null, 0, v14, s0                  // 000000819CD0: D5207C0E 00021C80
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000819CD8: BF870092
	v_dot2_f32_bf16 v4, v38, v58, v4                           // 000000819CDC: CC1A4004 1C127526
	v_fmac_f32_e32 v18, v26, v4                                // 000000819CE4: 5624091A
	s_clause 0x3                                               // 000000819CE8: BF850003
	global_load_b128 v[4:7], v[35:36], off                     // 000000819CEC: DC5E0000 047C0023
	global_load_b128 v[27:30], v[35:36], off offset:16         // 000000819CF4: DC5E0010 1B7C0023
	global_load_b128 v[31:34], v[35:36], off offset:32         // 000000819CFC: DC5E0020 1F7C0023
	global_load_b128 v[35:38], v[35:36], off offset:48         // 000000819D04: DC5E0030 237C0023
	s_waitcnt vmcnt(3)                                         // 000000819D0C: BF890FF7
	v_dot2_f32_bf16 v4, v4, v43, 0                             // 000000819D10: CC1A4004 1A025704
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000819D18: BF870121
	v_dot2_f32_bf16 v4, v5, v44, v4                            // 000000819D1C: CC1A4004 1C125905
	v_mov_b32_e32 v5, v1                                       // 000000819D24: 7E0A0301
	v_dot2_f32_bf16 v4, v6, v45, v4                            // 000000819D28: CC1A4004 1C125B06
	v_mov_b32_e32 v6, v2                                       // 000000819D30: 7E0C0302
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000819D34: BF870132
	v_dot2_f32_bf16 v4, v7, v46, v4                            // 000000819D38: CC1A4004 1C125D07
	v_mov_b32_e32 v7, v3                                       // 000000819D40: 7E0E0303
	s_waitcnt vmcnt(2)                                         // 000000819D44: BF890BF7
	v_dot2_f32_bf16 v4, v27, v47, v4                           // 000000819D48: CC1A4004 1C125F1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000819D50: BF870091
	v_dot2_f32_bf16 v4, v28, v48, v4                           // 000000819D54: CC1A4004 1C12611C
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 000000819D5C: CC1A4004 1C12631D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000819D64: BF8700A1
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 000000819D68: CC1A4004 1C12651E
	s_waitcnt vmcnt(1)                                         // 000000819D70: BF8907F7
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 000000819D74: CC1A4004 1C12671F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000819D7C: BF870091
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 000000819D80: CC1A4004 1C126920
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 000000819D88: CC1A4004 1C126B21
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000819D90: BF8700A1
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 000000819D94: CC1A4004 1C126D22
	s_waitcnt vmcnt(0)                                         // 000000819D9C: BF8903F7
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 000000819DA0: CC1A4004 1C126F23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000819DA8: BF870091
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 000000819DAC: CC1A4004 1C127124
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 000000819DB4: CC1A4004 1C127325
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000819DBC: BF870091
	v_dot2_f32_bf16 v4, v38, v58, v4                           // 000000819DC0: CC1A4004 1C127526
	v_fmac_f32_e32 v16, v26, v4                                // 000000819DC8: 5620091A
	v_mov_b32_e32 v4, v0                                       // 000000819DCC: 7E080300
	v_mov_b32_e32 v26, v25                                     // 000000819DD0: 7E340319
	s_and_not1_b32 exec_lo, exec_lo, s16                       // 000000819DD4: 917E107E
	s_cbranch_execz 25                                         // 000000819DD8: BFA50019 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi16ELi1ELb0ELi2ELi0EEEvPKhPKtPvlllllS6_f+0xa40>
	s_waitcnt vmcnt(0)                                         // 000000819DDC: BF8903F7
	v_dual_mov_b32 v1, v5 :: v_dual_add_nc_u32 v24, 16, v24    // 000000819DE0: CA200105 01183090
	v_dual_mov_b32 v0, v4 :: v_dual_mov_b32 v3, v7             // 000000819DE8: CA100104 00020107
	v_mov_b32_e32 v2, v6                                       // 000000819DF0: 7E040306
	s_delay_alu instid0(VALU_DEP_3)                            // 000000819DF4: BF870003
	.long 0xd4430000                                           // 000000819DF8: D4430000
	v_cndmask_b32_e32 v1, s2, v24, vcc_lo                      // 000000819DFC: 02023002
	s_mov_b32 s10, exec_lo                                     // 000000819E00: BE8A007E
	.long 0xd4c4007e                                           // 000000819E04: D4C4007E
	v_cndmask_b32_e32 v1, s2, v24, vcc_lo                      // 000000819E08: 02023002
	s_cbranch_execz 65054                                      // 000000819E0C: BFA5FE1E <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi16ELi1ELb0ELi2ELi0EEEvPKhPKtPvlllllS6_f+0x288>
	.long 0xd7000100                                           // 000000819E10: D7000100
	v_cndmask_b32_e32 v1, v10, v23, vcc_lo                     // 000000819E14: 02022F0A
	s_delay_alu instid0(VALU_DEP_1)                            // 000000819E18: BF870001
	v_add_co_ci_u32_e64 v1, null, 0, v17, s1                   // 000000819E1C: D5207C01 00062280
	global_load_d16_b16 v25, v[13:14], off                     // 000000819E24: DC820000 197C000D
	global_load_b128 v[0:3], v[0:1], off                       // 000000819E2C: DC5E0000 007C0000
	s_waitcnt vmcnt(1)                                         // 000000819E34: BF8907F7
	v_cvt_f32_f16_e32 v25, v25                                 // 000000819E38: 7E321719
	s_branch 65042                                             // 000000819E3C: BFA0FE12 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi16ELi1ELb0ELi2ELi0EEEvPKhPKtPvlllllS6_f+0x288>
	s_or_b32 exec_lo, exec_lo, s16                             // 000000819E40: 8C7E107E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000819E44: BF8700A9
	s_or_b32 exec_lo, exec_lo, s3                              // 000000819E48: 8C7E037E
	.long 0xd71f0000                                           // 000000819E4C: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 000000819E50: 020100C1
	v_xor_b32_e32 v1, 8, v0                                    // 000000819E54: 3A020088
	s_waitcnt vmcnt(0)                                         // 000000819E58: BF8903F7
	v_xor_b32_e32 v7, 4, v0                                    // 000000819E5C: 3A0E0084
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000819E60: BF870092
	.long 0xd44c0000                                           // 000000819E64: D44C0000
	v_cndmask_b32_e32 v1, 32, v1, vcc_lo                       // 000000819E68: 020202A0
	v_cndmask_b32_e64 v1, v0, v1, s0                           // 000000819E6C: D5010001 00020300
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000819E74: BF870113
	.long 0xd44c0000                                           // 000000819E78: D44C0000
	v_cndmask_b32_e32 v1, 32, v7, vcc_lo                       // 000000819E7C: 02020EA0
	v_lshlrev_b32_e32 v1, 2, v1                                // 000000819E80: 30020282
	s_delay_alu instid0(VALU_DEP_2)                            // 000000819E84: BF870002
	v_cndmask_b32_e64 v7, v0, v7, s0                           // 000000819E88: D5010007 00020F00
	ds_bpermute_b32 v2, v1, v22                                // 000000819E90: DACC0000 02001601
	s_waitcnt lgkmcnt(0)                                       // 000000819E98: BF89FC07
	v_add_f32_e32 v2, v22, v2                                  // 000000819E9C: 06040516
	ds_bpermute_b32 v3, v1, v21                                // 000000819EA0: DACC0000 03001501
	ds_bpermute_b32 v4, v1, v20                                // 000000819EA8: DACC0000 04001401
	ds_bpermute_b32 v5, v1, v19                                // 000000819EB0: DACC0000 05001301
	ds_bpermute_b32 v6, v1, v18                                // 000000819EB8: DACC0000 06001201
	ds_bpermute_b32 v1, v1, v16                                // 000000819EC0: DACC0000 01001001
	v_lshlrev_b32_e32 v7, 2, v7                                // 000000819EC8: 300E0E82
	s_waitcnt lgkmcnt(3)                                       // 000000819ECC: BF89FC37
	v_dual_add_f32 v3, v21, v3 :: v_dual_add_f32 v4, v20, v4   // 000000819ED0: C9080715 03040914
	ds_bpermute_b32 v10, v7, v2                                // 000000819ED8: DACC0000 0A000207
	s_waitcnt lgkmcnt(1)                                       // 000000819EE0: BF89FC17
	v_dual_add_f32 v6, v18, v6 :: v_dual_add_f32 v1, v16, v1   // 000000819EE4: C9080D12 06000310
	v_xor_b32_e32 v16, 2, v0                                   // 000000819EEC: 3A200082
	ds_bpermute_b32 v11, v7, v3                                // 000000819EF0: DACC0000 0B000307
	ds_bpermute_b32 v12, v7, v4                                // 000000819EF8: DACC0000 0C000407
	ds_bpermute_b32 v14, v7, v6                                // 000000819F00: DACC0000 0E000607
	.long 0xd44c0000                                           // 000000819F08: D44C0000
	v_cndmask_b32_e32 v1, 32, v16, vcc_lo                      // 000000819F0C: 020220A0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000819F10: BF870091
	v_cndmask_b32_e64 v16, v0, v16, s0                         // 000000819F14: D5010010 00022100
	v_dual_add_f32 v5, v19, v5 :: v_dual_lshlrev_b32 v16, 2, v16// 000000819F1C: C9220B13 05102082
	ds_bpermute_b32 v13, v7, v5                                // 000000819F24: DACC0000 0D000507
	s_waitcnt lgkmcnt(4)                                       // 000000819F2C: BF89FC47
	v_add_f32_e32 v2, v2, v10                                  // 000000819F30: 06041502
	ds_bpermute_b32 v7, v7, v1                                 // 000000819F34: DACC0000 07000107
	s_waitcnt lgkmcnt(3)                                       // 000000819F3C: BF89FC37
	v_dual_add_f32 v3, v3, v11 :: v_dual_add_f32 v4, v4, v12   // 000000819F40: C9081703 03041904
	s_waitcnt lgkmcnt(2)                                       // 000000819F48: BF89FC27
	v_add_f32_e32 v11, v6, v14                                 // 000000819F4C: 06161D06
	ds_bpermute_b32 v6, v16, v3                                // 000000819F50: DACC0000 06000310
	ds_bpermute_b32 v12, v16, v4                               // 000000819F58: DACC0000 0C000410
	ds_bpermute_b32 v14, v16, v11                              // 000000819F60: DACC0000 0E000B10
	s_waitcnt lgkmcnt(4)                                       // 000000819F68: BF89FC47
	v_add_f32_e32 v10, v5, v13                                 // 000000819F6C: 06141B05
	v_xor_b32_e32 v5, 1, v0                                    // 000000819F70: 3A0A0081
	s_waitcnt lgkmcnt(3)                                       // 000000819F74: BF89FC37
	v_add_f32_e32 v7, v1, v7                                   // 000000819F78: 060E0F01
	ds_bpermute_b32 v1, v16, v2                                // 000000819F7C: DACC0000 01000210
	ds_bpermute_b32 v13, v16, v10                              // 000000819F84: DACC0000 0D000A10
	.long 0xd44c0000                                           // 000000819F8C: D44C0000
	v_cndmask_b32_e32 v1, 32, v5, vcc_lo                       // 000000819F90: 02020AA0
	s_waitcnt lgkmcnt(4)                                       // 000000819F94: BF89FC47
	v_add_f32_e32 v6, v3, v6                                   // 000000819F98: 060C0D03
	ds_bpermute_b32 v16, v16, v7                               // 000000819F9C: DACC0000 10000710
	v_cndmask_b32_e64 v0, v0, v5, s0                           // 000000819FA4: D5010000 00020B00
	.long 0xd44a0000                                           // 000000819FAC: D44A0000
	v_cndmask_b32_e32 v1, 0, v15, vcc_lo                       // 000000819FB0: 02021E80
	s_waitcnt lgkmcnt(4)                                       // 000000819FB4: BF89FC47
	v_add_f32_e32 v4, v4, v12                                  // 000000819FB8: 06081904
	s_delay_alu instid0(VALU_DEP_3)                            // 000000819FBC: BF870003
	v_lshlrev_b32_e32 v17, 2, v0                               // 000000819FC0: 30220082
	s_and_b32 s0, s0, vcc_lo                                   // 000000819FC4: 8B006A00
	s_waitcnt lgkmcnt(2)                                       // 000000819FC8: BF89FC27
	v_add_f32_e32 v5, v2, v1                                   // 000000819FCC: 060A0302
	s_waitcnt lgkmcnt(1)                                       // 000000819FD0: BF89FC17
	v_dual_add_f32 v1, v11, v14 :: v_dual_add_f32 v0, v10, v13 // 000000819FD4: C9081D0B 01001B0A
	ds_bpermute_b32 v12, v17, v6                               // 000000819FDC: DACC0000 0C000611
	ds_bpermute_b32 v10, v17, v4                               // 000000819FE4: DACC0000 0A000411
	ds_bpermute_b32 v11, v17, v5                               // 000000819FEC: DACC0000 0B000511
	ds_bpermute_b32 v3, v17, v1                                // 000000819FF4: DACC0000 03000111
	ds_bpermute_b32 v2, v17, v0                                // 000000819FFC: DACC0000 02000011
	s_waitcnt lgkmcnt(5)                                       // 00000081A004: BF89FC57
	v_add_f32_e32 v7, v7, v16                                  // 00000081A008: 060E2107
	ds_bpermute_b32 v13, v17, v7                               // 00000081A00C: DACC0000 0D000711
	s_and_saveexec_b32 s1, s0                                  // 00000081A014: BE812000
	s_cbranch_execz 286                                        // 00000081A018: BFA5011E <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi16ELi1ELb0ELi2ELi0EEEvPKhPKtPvlllllS6_f+0x1094>
	s_waitcnt lgkmcnt(3)                                       // 00000081A01C: BF89FC37
	v_dual_add_f32 v5, v5, v11 :: v_dual_add_f32 v6, v6, v12   // 00000081A020: C9081705 05061906
	s_waitcnt lgkmcnt(1)                                       // 00000081A028: BF89FC17
	v_dual_add_f32 v2, v0, v2 :: v_dual_add_f32 v3, v1, v3     // 00000081A02C: C9080500 02020701
	s_waitcnt lgkmcnt(0)                                       // 00000081A034: BF89FC07
	v_dual_add_f32 v7, v7, v13 :: v_dual_add_f32 v4, v4, v10   // 00000081A038: C9081B07 07041504
	v_bfe_u32 v11, v6, 16, 1                                   // 00000081A040: D610000B 02052106
	v_bfe_u32 v10, v5, 16, 1                                   // 00000081A048: D610000A 02052105
	.long 0xd73c0000                                           // 00000081A050: D73C0000
	v_cndmask_b32_e32 v1, 1, v8, vcc_lo                        // 00000081A054: 02021081
	s_delay_alu instid0(VALU_DEP_4)                            // 00000081A058: BF870004
	v_bfe_u32 v13, v7, 16, 1                                   // 00000081A05C: D610000D 02052107
	v_bfe_u32 v9, v4, 16, 1                                    // 00000081A064: D6100009 02052104
	v_add3_u32 v6, v6, v11, 0x7fff                             // 00000081A06C: D6550006 03FE1706 00007FFF
	v_bfe_u32 v11, v3, 16, 1                                   // 00000081A078: D610000B 02052103
	v_add3_u32 v5, v5, v10, 0x7fff                             // 00000081A080: D6550005 03FE1505 00007FFF
	v_bfe_u32 v10, v2, 16, 1                                   // 00000081A08C: D610000A 02052102
	v_add3_u32 v4, v4, v9, 0x7fff                              // 00000081A094: D6550004 03FE1304 00007FFF
	v_and_b32_e32 v6, 0xffff0000, v6                           // 00000081A0A0: 360C0CFF FFFF0000
	v_add3_u32 v3, v3, v11, 0x7fff                             // 00000081A0A8: D6550003 03FE1703 00007FFF
	v_add3_u32 v7, v7, v13, 0x7fff                             // 00000081A0B4: D6550007 03FE1B07 00007FFF
	v_add3_u32 v2, v2, v10, 0x7fff                             // 00000081A0C0: D6550002 03FE1502 00007FFF
	v_and_b32_e32 v4, 0xffff0000, v4                           // 00000081A0CC: 360808FF FFFF0000
	.long 0xd7006a00                                           // 00000081A0D4: D7006A00
	v_cndmask_b32_e32 v1, s8, v0, vcc_lo                       // 00000081A0D8: 02020008
	v_and_b32_e32 v3, 0xffff0000, v3                           // 00000081A0DC: 360606FF FFFF0000
	v_mul_f32_e32 v6, 0xbfb8aa3b, v6                           // 00000081A0E4: 100C0CFF BFB8AA3B
	v_and_b32_e32 v2, 0xffff0000, v2                           // 00000081A0EC: 360404FF FFFF0000
	v_add_co_ci_u32_e64 v1, null, s9, v1, vcc_lo               // 00000081A0F4: D5207C01 01AA0209
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000081A0FC: BF870214
	v_mul_f32_e32 v11, 0xbfb8aa3b, v3                          // 00000081A100: 101606FF BFB8AA3B
	v_exp_f32_e32 v6, v6                                       // 00000081A108: 7E0C4B06
	v_and_b32_e32 v5, 0xffff0000, v5                           // 00000081A10C: 360A0AFF FFFF0000
	s_lshl_b64 s[0:1], s[12:13], 1                             // 00000081A114: 8480810C
	.long 0x7f183880                                           // 00000081A118: 7F183880
	.long 0xd7006a03                                           // 00000081A11C: D7006A03
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 00000081A120: 02000100
	v_mul_f32_e32 v2, 0xbfb8aa3b, v2                           // 00000081A124: 100404FF BFB8AA3B
	v_exp_f32_e32 v11, v11                                     // 00000081A12C: 7E164B0B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 00000081A130: BF870313
	.long 0x7f10398c                                           // 00000081A134: 7F10398C
	v_dual_add_f32 v6, 1.0, v6 :: v_dual_mul_f32 v5, 0xbfb8aa3b, v5// 00000081A138: C9060CF2 06040AFF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000081A144: BF870093
	v_exp_f32_e32 v2, v2                                       // 00000081A148: 7E044B02
	v_div_scale_f32 v10, null, v6, v6, 1.0                     // 00000081A14C: D6FC7C0A 03CA0D06
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000081A154: BF870122
	v_exp_f32_e32 v5, v5                                       // 00000081A158: 7E0A4B05
	v_div_scale_f32 v19, s0, 1.0, v6, 1.0                      // 00000081A15C: D6FC0013 03CA0CF2
	v_rcp_f32_e32 v14, v10                                     // 00000081A164: 7E1C550A
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000081A168: BF870296
	v_dual_add_f32 v2, 1.0, v2 :: v_dual_add_f32 v5, 1.0, v5   // 00000081A16C: C90804F2 02040AF2
	v_fma_f32 v17, -v10, v14, 1.0                              // 00000081A174: D6130011 23CA1D0A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000081A17C: BF870112
	v_div_scale_f32 v9, null, v5, v5, 1.0                      // 00000081A180: D6FC7C09 03CA0B05
	v_dual_fmac_f32 v14, v17, v14 :: v_dual_and_b32 v7, 0xffff0000, v7// 00000081A188: C8241D11 0E060EFF FFFF0000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000081A194: BF870092
	v_rcp_f32_e32 v13, v9                                      // 00000081A198: 7E1A5509
	v_dual_mul_f32 v4, 0xbfb8aa3b, v4 :: v_dual_mul_f32 v7, 0xbfb8aa3b, v7// 00000081A19C: C8C608FF 04060EFF BFB8AA3B
	v_div_scale_f32 v17, null, v2, v2, 1.0                     // 00000081A1A8: D6FC7C11 03CA0502
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000081A1B0: BF870193
	v_mul_f32_e32 v21, v19, v14                                // 00000081A1B4: 102A1D13
	v_exp_f32_e32 v15, v4                                      // 00000081A1B8: 7E1E4B04
	v_add_co_ci_u32_e64 v4, null, s1, v1, vcc_lo               // 00000081A1BC: D5207C04 01AA0201
	v_div_scale_f32 v18, vcc_lo, 1.0, v5, 1.0                  // 00000081A1C4: D6FC6A12 03CA0AF2
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 00000081A1CC: BF870146
	v_fma_f32 v16, -v9, v13, 1.0                               // 00000081A1D0: D6130010 23CA1B09
	v_exp_f32_e32 v7, v7                                       // 00000081A1D8: 7E0E4B07
	v_rcp_f32_e32 v23, v17                                     // 00000081A1DC: 7E2E5511
	v_fma_f32 v25, -v10, v21, v19                              // 00000081A1E0: D6130019 244E2B0A
	v_fmac_f32_e32 v13, v16, v13                               // 00000081A1E8: 561A1B10
	s_delay_alu instid0(TRANS32_DEP_3) | instid1(VALU_DEP_1)   // 00000081A1EC: BF870087
	v_dual_add_f32 v15, 1.0, v15 :: v_dual_mul_f32 v20, v18, v13// 00000081A1F0: C9061EF2 0F141B12
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(TRANS32_DEP_1)// 00000081A1F8: BF8702A1
	v_div_scale_f32 v16, null, v15, v15, 1.0                   // 00000081A1FC: D6FC7C10 03CA1F0F
	v_div_scale_f32 v26, s1, 1.0, v15, 1.0                     // 00000081A204: D6FC011A 03CA1EF2
	v_fma_f32 v28, -v17, v23, 1.0                              // 00000081A20C: D613001C 23CA2F11
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000081A214: BF8701B4
	v_fma_f32 v24, -v9, v20, v18                               // 00000081A218: D6130018 244A2909
	v_add_f32_e32 v11, 1.0, v11                                // 00000081A220: 061616F2
	v_rcp_f32_e32 v22, v16                                     // 00000081A224: 7E2C5510
	v_fmac_f32_e32 v23, v28, v23                               // 00000081A228: 562E2F1C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000081A22C: BF870193
	v_fmac_f32_e32 v20, v24, v13                               // 00000081A230: 56281B18
	v_div_scale_f32 v27, null, v11, v11, 1.0                   // 00000081A234: D6FC7C1B 03CA170B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000081A23C: BF870122
	v_fma_f32 v9, -v9, v20, v18                                // 00000081A240: D6130009 244A2909
	v_div_scale_f32 v18, s2, 1.0, v2, 1.0                      // 00000081A248: D6FC0212 03CA04F2
	v_div_fmas_f32 v9, v9, v13, v20                            // 00000081A250: D6370009 04521B09
	s_mov_b32 vcc_lo, s0                                       // 00000081A258: BEEA0000
	v_div_scale_f32 v13, s3, 1.0, v11, 1.0                     // 00000081A25C: D6FC030D 03CA16F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000081A264: BF870092
	v_div_fixup_f32 v5, v9, v5, 1.0                            // 00000081A268: D6270005 03CA0B09
	.long 0x7e103985                                           // 00000081A270: 7E103985
	v_fmac_f32_e32 v21, v25, v14                               // 00000081A274: 562A1D19
	v_fma_f32 v25, -v16, v22, 1.0                              // 00000081A278: D6130019 23CA2D10
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000081A280: BF870193
	v_dual_add_f32 v7, 1.0, v7 :: v_dual_and_b32 v8, 1, v8     // 00000081A284: C9240EF2 07081081
	v_fma_f32 v10, -v10, v21, v19                              // 00000081A28C: D613000A 244E2B0A
	v_rcp_f32_e32 v19, v27                                     // 00000081A294: 7E26551B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000081A298: BF870193
	v_fmac_f32_e32 v22, v25, v22                               // 00000081A29C: 562C2D19
	v_div_scale_f32 v24, null, v7, v7, 1.0                     // 00000081A2A0: D6FC7C18 03CA0F07
	v_div_scale_f32 v20, s4, 1.0, v7, 1.0                      // 00000081A2A8: D6FC0414 03CA0EF2
	v_div_fmas_f32 v10, v10, v14, v21                          // 00000081A2B0: D637000A 04561D0A
	v_add3_u32 v5, v5, v8, 0x7fff                              // 00000081A2B8: D6550005 03FE1105 00007FFF
	s_mov_b32 vcc_lo, s1                                       // 00000081A2C4: BEEA0001
	v_rcp_f32_e32 v29, v24                                     // 00000081A2C8: 7E3A5518
	s_lshl_b64 s[0:1], s[12:13], 2                             // 00000081A2CC: 8480820C
	v_div_fixup_f32 v6, v10, v6, 1.0                           // 00000081A2D0: D6270006 03CA0D0A
	v_fma_f32 v9, -v27, v19, 1.0                               // 00000081A2D8: D6130009 23CA271B
	v_mul_f32_e32 v10, v26, v22                                // 00000081A2E0: 10142D1A
	global_store_d16_hi_b16 v[0:1], v5, off                    // 00000081A2E4: DC960000 007C0500
	.long 0x7e183986                                           // 00000081A2EC: 7E183986
	v_fmac_f32_e32 v19, v9, v19                                // 00000081A2F0: 56262709
	v_fma_f32 v9, -v16, v10, v26                               // 00000081A2F4: D6130009 246A1510
	v_fma_f32 v14, -v24, v29, 1.0                              // 00000081A2FC: D613000E 23CA3B18
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000081A304: BF870112
	v_dual_mul_f32 v21, v18, v23 :: v_dual_fmac_f32 v10, v9, v22// 00000081A308: C8C02F12 150A2D09
	v_fmac_f32_e32 v29, v14, v29                               // 00000081A310: 563A3B0E
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000081A314: BF870222
	v_fma_f32 v8, -v17, v21, v18                               // 00000081A318: D6130008 244A2B11
	v_dual_mul_f32 v9, v13, v19 :: v_dual_and_b32 v14, 1, v12  // 00000081A320: C8E4270D 090E1881
	v_fma_f32 v5, -v16, v10, v26                               // 00000081A328: D6130005 246A1510
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000081A330: BF870223
	v_fmac_f32_e32 v21, v8, v23                                // 00000081A334: 562A2F08
	v_mul_f32_e32 v8, v20, v29                                 // 00000081A338: 10103B14
	v_add3_u32 v14, v6, v14, 0x7fff                            // 00000081A33C: D655000E 03FE1D06 00007FFF
	v_fma_f32 v6, -v27, v9, v13                                // 00000081A348: D6130006 2436131B
	v_div_fmas_f32 v5, v5, v22, v10                            // 00000081A350: D6370005 042A2D05
	v_fma_f32 v10, -v17, v21, v18                              // 00000081A358: D613000A 244A2B11
	v_fma_f32 v16, -v24, v8, v20                               // 00000081A360: D6130010 24521118
	s_mov_b32 vcc_lo, s2                                       // 00000081A368: BEEA0002
	v_fmac_f32_e32 v9, v6, v19                                 // 00000081A36C: 56122706
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000081A370: BF870193
	v_div_fmas_f32 v6, v10, v23, v21                           // 00000081A374: D6370006 04562F0A
	v_fmac_f32_e32 v8, v16, v29                                // 00000081A37C: 56103B10
	v_div_fixup_f32 v10, v5, v15, 1.0                          // 00000081A380: D627000A 03CA1F05
	s_delay_alu instid0(VALU_DEP_4)                            // 00000081A388: BF870004
	v_fma_f32 v5, -v27, v9, v13                                // 00000081A38C: D6130005 2436131B
	s_mov_b32 vcc_lo, s3                                       // 00000081A394: BEEA0003
	v_div_fixup_f32 v2, v6, v2, 1.0                            // 00000081A398: D6270002 03CA0506
	v_fma_f32 v6, -v24, v8, v20                                // 00000081A3A0: D6130006 24521118
	.long 0x7e1a398a                                           // 00000081A3A8: 7E1A398A
	v_div_fmas_f32 v9, v5, v19, v9                             // 00000081A3AC: D6370009 04262705
	s_mov_b32 vcc_lo, s4                                       // 00000081A3B4: BEEA0004
	.long 0x7e183982                                           // 00000081A3B8: 7E183982
	v_div_fmas_f32 v8, v6, v29, v8                             // 00000081A3BC: D6370008 04223B06
	.long 0xd7006a05                                           // 00000081A3C4: D7006A05
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 00000081A3C8: 02000100
	.long 0x7f1a398c                                           // 00000081A3CC: 7F1A398C
	v_div_fixup_f32 v9, v9, v11, 1.0                           // 00000081A3D0: D6270009 03CA1709
	v_add_co_ci_u32_e64 v6, null, s1, v1, vcc_lo               // 00000081A3D8: D5207C06 01AA0201
	v_mad_u64_u32 v[0:1], null, s12, 6, v[0:1]                 // 00000081A3E0: D6FE7C00 04010C0C
	v_div_fixup_f32 v15, v8, v7, 1.0                           // 00000081A3E8: D627000F 03CA0F08
	v_and_b32_e32 v7, 1, v12                                   // 00000081A3F0: 360E1881
	v_and_b32_e32 v8, 1, v13                                   // 00000081A3F4: 36101A81
	.long 0x7e163989                                           // 00000081A3F8: 7E163989
	.long 0x7f16398c                                           // 00000081A3FC: 7F16398C
	.long 0x7e18398f                                           // 00000081A400: 7E18398F
	v_add3_u32 v13, v2, v7, 0x7fff                             // 00000081A404: D655000D 03FE0F02 00007FFF
	v_mad_u64_u32 v[1:2], null, s13, 6, v[1:2]                 // 00000081A410: D6FE7C01 04050C0D
	v_add3_u32 v16, v10, v8, 0x7fff                            // 00000081A418: D6550010 03FE110A 00007FFF
	v_and_b32_e32 v10, 1, v11                                  // 00000081A424: 36141681
	v_and_b32_e32 v2, 1, v12                                   // 00000081A428: 36041881
	.long 0xd7006a07                                           // 00000081A42C: D7006A07
	v_cndmask_b32_e32 v0, v5, v0, vcc_lo                       // 00000081A430: 02000105
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000081A434: BF870211
	v_add_co_ci_u32_e64 v8, null, s1, v6, vcc_lo               // 00000081A438: D5207C08 01AA0C01
	v_add3_u32 v11, v9, v10, 0x7fff                            // 00000081A440: D655000B 03FE1509 00007FFF
	.long 0xd7006a09                                           // 00000081A44C: D7006A09
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 00000081A450: 02000100
	v_add3_u32 v2, v15, v2, 0x7fff                             // 00000081A454: D6550002 03FE050F 00007FFF
	v_add_co_ci_u32_e64 v10, null, s1, v1, vcc_lo              // 00000081A460: D5207C0A 01AA0201
	s_clause 0x4                                               // 00000081A468: BF850004
	global_store_d16_hi_b16 v[3:4], v14, off                   // 00000081A46C: DC960000 007C0E03
	global_store_d16_hi_b16 v[5:6], v16, off                   // 00000081A474: DC960000 007C1005
	global_store_d16_hi_b16 v[0:1], v13, off                   // 00000081A47C: DC960000 007C0D00
	global_store_d16_hi_b16 v[7:8], v11, off                   // 00000081A484: DC960000 007C0B07
	global_store_d16_hi_b16 v[9:10], v2, off                   // 00000081A48C: DC960000 007C0209
	s_endpgm                                                   // 00000081A494: BFB00000
		...

