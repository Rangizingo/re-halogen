0000000000711800 <_ZN7halogen12_GLOBAL__N_16k_lq6kILi3ELi16ELi1ELb1EEEvPKhPKtPvll>:
; _ZN7halogen12_GLOBAL__N_16k_lq6kILi3ELi16ELi1ELb1EEEvPKhPKtPvll():
	s_clause 0x1                                               // 000000711800: BF850001
	s_load_b256 s[4:11], s[0:1], null                          // 000000711804: F40C0100 F8000000
	s_load_b64 s[12:13], s[0:1], 0x20                          // 00000071180C: F4040300 F8000020
	s_mov_b32 s3, 0                                            // 000000711814: BE830080
	v_lshrrev_b32_e32 v1, 4, v0                                // 000000711818: 32020084
	s_lshl_b64 s[0:1], s[2:3], 4                               // 00000071181C: 84808402
	v_dual_mov_b32 v8, 0 :: v_dual_and_b32 v7, 15, v0          // 000000711820: CA240080 0806008F
	v_dual_mov_b32 v2, s1 :: v_dual_mov_b32 v9, 0              // 000000711828: CA100001 02080080
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000711830: BF870143
	v_or_b32_e32 v1, s0, v1                                    // 000000711834: 38020200
	v_mov_b32_e32 v10, 0                                       // 000000711838: 7E140280
	s_waitcnt lgkmcnt(0)                                       // 00000071183C: BF89FC07
	s_ashr_i32 s1, s11, 31                                     // 000000711840: 86019F0B
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[1:2]                  // 000000711844: 7CA8020C
	s_lshr_b32 s1, s1, 28                                      // 000000711848: 85019C01
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000071184C: BF8704A9
	s_add_u32 s0, s10, s1                                      // 000000711850: 8000010A
	s_addc_u32 s1, s11, 0                                      // 000000711854: 8201800B
	s_lshr_b64 s[14:15], s[0:1], 4                             // 000000711858: 858E8400
	s_mov_b32 s1, exec_lo                                      // 00000071185C: BE81007E
	.long 0xd4c4007e                                           // 000000711860: D4C4007E
	v_cndmask_b32_e32 v1, s14, v7, vcc_lo                      // 000000711864: 02020E0E
	s_cbranch_execz 425                                        // 000000711868: BFA501A9 <_ZN7halogen12_GLOBAL__N_16k_lq6kILi3ELi16ELi1ELb1EEEvPKhPKtPvll+0x710>
	s_ashr_i32 s0, s11, 31                                     // 00000071186C: 86009F0B
	v_cndmask_b32_e32 v3, 0, v2, vcc_lo                        // 000000711870: 02060480
	s_lshr_b32 s0, s0, 24                                      // 000000711874: 85009800
	v_dual_cndmask_b32 v5, 0, v1 :: v_dual_mov_b32 v6, 0       // 000000711878: CA500280 05060080
	s_add_u32 s16, s10, s0                                     // 000000711880: 8010000A
	s_addc_u32 s17, s11, 0                                     // 000000711884: 8211800B
	v_dual_mov_b32 v20, 0 :: v_dual_and_b32 v11, 4, v0         // 000000711888: CA240080 140A0084
	s_ashr_i64 s[16:17], s[16:17], 8                           // 000000711890: 86908810
	v_and_b32_e32 v0, 6, v0                                    // 000000711894: 36000086
	s_mul_i32 s0, s17, 0xd2                                    // 000000711898: 9600FF11 000000D2
	s_mul_hi_u32 s2, s16, 0xd2                                 // 0000007118A0: 9682FF10 000000D2
	s_mul_i32 s15, s16, 0xd2                                   // 0000007118A8: 960FFF10 000000D2
	s_add_i32 s2, s2, s0                                       // 0000007118B0: 81020002
	.long 0xd72c0008                                           // 0000007118B4: D72C0008
	v_cndmask_b32_e32 v1, s15, v3, vcc_lo                      // 0000007118B8: 0202060F
	v_mad_u64_u32 v[3:4], null, s15, v5, s[4:5]                // 0000007118BC: D6FE7C03 00120A0F
	.long 0xd72c0005                                           // 0000007118C4: D72C0005
	v_cndmask_b32_e32 v1, s2, v5, vcc_lo                       // 0000007118C8: 02020A02
	v_lshrrev_b32_e32 v9, 3, v7                                // 0000007118CC: 32120E83
	v_or_b32_e32 v14, 8, v11                                   // 0000007118D0: 381C1688
	v_or_b32_e32 v15, 8, v0                                    // 0000007118D4: 381E0088
	v_or_b32_e32 v16, 16, v11                                  // 0000007118D8: 38201690
	v_or_b32_e32 v17, 16, v0                                   // 0000007118DC: 38220090
	v_dual_mov_b32 v21, v7 :: v_dual_lshlrev_b32 v12, 6, v9    // 0000007118E0: CA220107 150C1286
	v_dual_mov_b32 v10, v6 :: v_dual_lshlrev_b32 v13, 5, v9    // 0000007118E8: CA220106 0A0C1285
	v_add3_u32 v4, v5, v4, v8                                  // 0000007118F0: D6550004 04220905
	v_or_b32_e32 v18, 24, v11                                  // 0000007118F8: 38241698
	v_or_b32_e32 v19, 24, v0                                   // 0000007118FC: 38260098
	v_dual_mov_b32 v8, v6 :: v_dual_lshlrev_b32 v5, 4, v7      // 000000711900: CA220106 08040E84
	v_mov_b32_e32 v9, v6                                       // 000000711908: 7E120306
	s_lshl_b64 s[4:5], s[10:11], 2                             // 00000071190C: 8484820A
	s_lshl_b64 s[10:11], s[10:11], 1                           // 000000711910: 848A810A
	.long 0xd700001e                                           // 000000711914: D700001E
	v_cndmask_b32_e32 v1, v3, v20, vcc_lo                      // 000000711918: 02022903
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000071191C: BF8701A1
	v_add_co_ci_u32_e64 v31, null, 0, v4, s0                   // 000000711920: D5207C1F 00020880
	v_and_b32_e32 v26, 16, v5                                  // 000000711928: 36340A90
	.long 0xd700001c                                           // 00000071192C: D700001C
	v_cndmask_b32_e32 v1, v30, v12, vcc_lo                     // 000000711930: 0202191E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000711934: BF8700D1
	v_add_co_ci_u32_e64 v29, null, 0, v31, s0                  // 000000711938: D5207C1D 00023E80
	.long 0xd7000018                                           // 000000711940: D7000018
	v_cndmask_b32_e32 v1, v30, v13, vcc_lo                     // 000000711944: 02021B1E
	v_and_b32_e32 v27, 32, v5                                  // 000000711948: 36360AA0
	v_add_co_ci_u32_e64 v25, null, 0, v31, s0                  // 00000071194C: D5207C19 00023E80
	.long 0xd7000016                                           // 000000711954: D7000016
	v_cndmask_b32_e32 v1, v30, v7, vcc_lo                      // 000000711958: 02020F1E
	v_add_co_ci_u32_e64 v23, null, 0, v31, s0                  // 00000071195C: D5207C17 00023E80
	.long 0xd7000018                                           // 000000711964: D7000018
	v_cndmask_b32_e32 v1, v24, v26, vcc_lo                     // 000000711968: 02023518
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000071196C: BF8700A1
	v_add_co_ci_u32_e64 v25, null, 0, v25, s0                  // 000000711970: D5207C19 00023280
	.long 0xd700001b                                           // 000000711978: D700001B
	v_cndmask_b32_e32 v1, v28, v27, vcc_lo                     // 00000071197C: 0202371C
	v_add_co_ci_u32_e64 v28, null, 0, v29, s0                  // 000000711980: D5207C1C 00023A80
	s_clause 0x1                                               // 000000711988: BF850001
	global_load_i8 v54, v[22:23], off offset:192               // 00000071198C: DC4600C0 367C0016
	global_load_b128 v[22:25], v[24:25], off offset:128        // 000000711994: DC5E0080 167C0018
	.long 0xd700001a                                           // 00000071199C: D700001A
	v_cndmask_b32_e32 v1, v27, v26, vcc_lo                     // 0000007119A0: 0202351B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007119A4: BF870001
	v_add_co_ci_u32_e64 v27, null, 0, v28, s0                  // 0000007119A8: D5207C1B 00023880
	s_clause 0x1                                               // 0000007119B0: BF850001
	global_load_b128 v[26:29], v[26:27], off                   // 0000007119B4: DC5E0000 1A7C001A
	global_load_d16_b16 v55, v[30:31], off offset:208          // 0000007119BC: DC8200D0 377C001E
	.long 0xd73c001e                                           // 0000007119C4: D73C001E
	v_cndmask_b32_e32 v1, 1, v5, vcc_lo                        // 0000007119C8: 02020A81
	v_add_nc_u32_e32 v5, 0x100, v5                             // 0000007119CC: 4A0A0AFF 00000100
	v_add_nc_u32_e32 v20, 0xd2, v20                            // 0000007119D4: 4A2828FF 000000D2
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007119DC: BF870093
	.long 0xd700002a                                           // 0000007119E0: D700002A
	v_cndmask_b32_e32 v1, s6, v30, vcc_lo                      // 0000007119E4: 02023C06
	v_add_co_ci_u32_e64 v43, null, s7, v31, s0                 // 0000007119E8: D5207C2B 00023E07
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007119F0: BF870092
	.long 0xd700002e                                           // 0000007119F4: D700002E
	v_cndmask_b32_e32 v0, v42, v10, vcc_lo                     // 0000007119F8: 0200152A
	v_add_co_ci_u32_e64 v47, null, s11, v43, s0                // 0000007119FC: D5207C2F 0002560B
	.long 0xd7000032                                           // 000000711A04: D7000032
	v_cndmask_b32_e32 v0, v42, v4, vcc_lo                      // 000000711A08: 0200092A
	s_delay_alu instid0(VALU_DEP_1)                            // 000000711A0C: BF870001
	v_add_co_ci_u32_e64 v51, null, s5, v43, s0                 // 000000711A10: D5207C33 00025605
	s_clause 0x5                                               // 000000711A18: BF850005
	global_load_b128 v[30:33], v[42:43], off                   // 000000711A1C: DC5E0000 1E7C002A
	global_load_b128 v[34:37], v[46:47], off                   // 000000711A24: DC5E0000 227C002E
	global_load_b128 v[38:41], v[50:51], off                   // 000000711A2C: DC5E0000 267C0032
	global_load_b128 v[42:45], v[42:43], off offset:16         // 000000711A34: DC5E0010 2A7C002A
	global_load_b128 v[46:49], v[46:47], off offset:16         // 000000711A3C: DC5E0010 2E7C002E
	global_load_b128 v[50:53], v[50:51], off offset:16         // 000000711A44: DC5E0010 327C0032
	s_waitcnt vmcnt(9)                                         // 000000711A4C: BF8927F7
	v_cvt_f32_i32_e32 v54, v54                                 // 000000711A50: 7E6C0B36
	s_waitcnt vmcnt(8)                                         // 000000711A54: BF8923F7
	v_lshrrev_b32_e32 v59, v0, v23                             // 000000711A58: 32762F00
	v_lshrrev_b32_e32 v60, v15, v23                            // 000000711A5C: 32782F0F
	v_lshrrev_b32_e32 v61, v17, v23                            // 000000711A60: 327A2F11
	v_lshrrev_b32_e32 v23, v19, v23                            // 000000711A64: 322E2F13
	v_lshrrev_b32_e32 v65, v0, v25                             // 000000711A68: 32823300
	v_lshrrev_b32_e32 v66, v15, v25                            // 000000711A6C: 3284330F
	v_lshrrev_b32_e32 v67, v17, v25                            // 000000711A70: 32863311
	v_lshrrev_b32_e32 v25, v19, v25                            // 000000711A74: 32323313
	s_waitcnt vmcnt(6)                                         // 000000711A78: BF891BF7
	v_fma_mix_f32 v54, v55, v54, neg(0) op_sel_hi:[1,0,0]      // 000000711A7C: CC200036 8A026D37
	v_bfe_u32 v70, v27, v11, 4                                 // 000000711A84: D6100046 0212171B
	v_bfe_u32 v71, v27, v14, 4                                 // 000000711A8C: D6100047 02121D1B
	v_bfe_u32 v72, v27, v16, 4                                 // 000000711A94: D6100048 0212211B
	v_bfe_u32 v27, v27, v18, 4                                 // 000000711A9C: D610001B 0212251B
	v_lshlrev_b32_e32 v23, 4, v23                              // 000000711AA4: 302E2E84
	v_bfe_u32 v76, v29, v11, 4                                 // 000000711AA8: D610004C 0212171D
	v_bfe_u32 v77, v29, v14, 4                                 // 000000711AB0: D610004D 02121D1D
	v_bfe_u32 v78, v29, v16, 4                                 // 000000711AB8: D610004E 0212211D
	v_bfe_u32 v29, v29, v18, 4                                 // 000000711AC0: D610001D 0212251D
	v_lshlrev_b32_e32 v25, 4, v25                              // 000000711AC8: 30323284
	v_and_or_b32 v23, v23, 48, v27                             // 000000711ACC: D6570017 046D6117
	v_lshrrev_b32_e32 v56, v0, v22                             // 000000711AD4: 32702D00
	v_lshrrev_b32_e32 v57, v15, v22                            // 000000711AD8: 32722D0F
	v_lshrrev_b32_e32 v58, v17, v22                            // 000000711ADC: 32742D11
	v_and_or_b32 v25, v25, 48, v29                             // 000000711AE0: D6570019 04756119
	v_lshrrev_b32_e32 v22, v19, v22                            // 000000711AE8: 322C2D13
	v_subrev_nc_u32_e32 v23, 32, v23                           // 000000711AEC: 4E2E2EA0
	v_lshrrev_b32_e32 v62, v0, v24                             // 000000711AF0: 327C3100
	v_lshrrev_b32_e32 v63, v15, v24                            // 000000711AF4: 327E310F
	v_lshrrev_b32_e32 v64, v17, v24                            // 000000711AF8: 32803111
	v_lshrrev_b32_e32 v24, v19, v24                            // 000000711AFC: 32303113
	v_subrev_nc_u32_e32 v25, 32, v25                           // 000000711B00: 4E3232A0
	v_bfe_u32 v55, v26, v11, 4                                 // 000000711B04: D6100037 0212171A
	v_bfe_u32 v68, v26, v14, 4                                 // 000000711B0C: D6100044 02121D1A
	v_bfe_u32 v69, v26, v16, 4                                 // 000000711B14: D6100045 0212211A
	v_bfe_u32 v26, v26, v18, 4                                 // 000000711B1C: D610001A 0212251A
	v_cvt_f32_i32_e32 v23, v23                                 // 000000711B24: 7E2E0B17
	v_lshlrev_b32_e32 v22, 4, v22                              // 000000711B28: 302C2C84
	v_bfe_u32 v73, v28, v11, 4                                 // 000000711B2C: D6100049 0212171C
	v_lshlrev_b32_e32 v62, 4, v62                              // 000000711B34: 307C7C84
	v_bfe_u32 v74, v28, v14, 4                                 // 000000711B38: D610004A 02121D1C
	v_bfe_u32 v75, v28, v16, 4                                 // 000000711B40: D610004B 0212211C
	v_bfe_u32 v28, v28, v18, 4                                 // 000000711B48: D610001C 0212251C
	v_cvt_f32_i32_e32 v25, v25                                 // 000000711B50: 7E320B19
	v_dual_mul_f32 v23, v54, v23 :: v_dual_lshlrev_b32 v24, 4, v24// 000000711B54: C8E22F36 17183084
	v_and_or_b32 v22, v22, 48, v26                             // 000000711B5C: D6570016 04696116
	v_and_or_b32 v27, v62, 48, v73                             // 000000711B64: D657001B 0525613E
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000711B6C: BF870214
	v_mul_f32_e32 v25, v54, v25                                // 000000711B70: 10323336
	v_and_or_b32 v24, v24, 48, v28                             // 000000711B74: D6570018 04716118
	v_lshlrev_b32_e32 v56, 4, v56                              // 000000711B7C: 30707084
	v_subrev_nc_u32_e32 v22, 32, v22                           // 000000711B80: 4E2C2CA0
	v_subrev_nc_u32_e32 v27, 32, v27                           // 000000711B84: 4E3636A0
	v_lshlrev_b32_e32 v58, 4, v58                              // 000000711B88: 30747484
	v_subrev_nc_u32_e32 v24, 32, v24                           // 000000711B8C: 4E3030A0
	v_lshlrev_b32_e32 v59, 4, v59                              // 000000711B90: 30767684
	v_cvt_f32_i32_e32 v22, v22                                 // 000000711B94: 7E2C0B16
	v_lshlrev_b32_e32 v57, 4, v57                              // 000000711B98: 30727284
	v_lshlrev_b32_e32 v61, 4, v61                              // 000000711B9C: 307A7A84
	v_lshlrev_b32_e32 v64, 4, v64                              // 000000711BA0: 30808084
	v_lshlrev_b32_e32 v65, 4, v65                              // 000000711BA4: 30828284
	v_lshlrev_b32_e32 v66, 4, v66                              // 000000711BA8: 30848484
	v_lshlrev_b32_e32 v67, 4, v67                              // 000000711BAC: 30868684
	v_and_or_b32 v55, v56, 48, v55                             // 000000711BB0: D6570037 04DD6138
	v_cvt_f32_i32_e32 v27, v27                                 // 000000711BB8: 7E360B1B
	v_lshlrev_b32_e32 v60, 4, v60                              // 000000711BBC: 30787884
	v_cvt_f32_i32_e32 v24, v24                                 // 000000711BC0: 7E300B18
	v_dual_mul_f32 v22, v54, v22 :: v_dual_lshlrev_b32 v63, 4, v63// 000000711BC4: C8E22D36 163E7E84
	v_and_or_b32 v56, v57, 48, v68                             // 000000711BCC: D6570038 05116139
	v_and_or_b32 v57, v58, 48, v69                             // 000000711BD4: D6570039 0515613A
	v_and_or_b32 v26, v59, 48, v70                             // 000000711BDC: D657001A 0519613B
	v_and_or_b32 v59, v61, 48, v72                             // 000000711BE4: D657003B 0521613D
	v_and_or_b32 v61, v64, 48, v75                             // 000000711BEC: D657003D 052D6140
	v_and_or_b32 v28, v65, 48, v76                             // 000000711BF4: D657001C 05316141
	v_and_or_b32 v62, v66, 48, v77                             // 000000711BFC: D657003E 05356142
	v_subrev_nc_u32_e32 v29, 32, v55                           // 000000711C04: 4E3A6EA0
	v_mul_f32_e32 v27, v54, v27                                // 000000711C08: 10363736
	v_and_or_b32 v58, v60, 48, v71                             // 000000711C0C: D657003A 051D613C
	v_mul_f32_e32 v24, v54, v24                                // 000000711C14: 10303136
	v_and_or_b32 v60, v63, 48, v74                             // 000000711C18: D657003C 0529613F
	v_and_or_b32 v63, v67, 48, v78                             // 000000711C20: D657003F 05396143
	v_subrev_nc_u32_e32 v55, 32, v56                           // 000000711C28: 4E6E70A0
	v_subrev_nc_u32_e32 v56, 32, v57                           // 000000711C2C: 4E7072A0
	v_subrev_nc_u32_e32 v26, 32, v26                           // 000000711C30: 4E3434A0
	v_subrev_nc_u32_e32 v57, 32, v58                           // 000000711C34: 4E7274A0
	v_subrev_nc_u32_e32 v58, 32, v59                           // 000000711C38: 4E7476A0
	v_subrev_nc_u32_e32 v59, 32, v60                           // 000000711C3C: 4E7678A0
	v_subrev_nc_u32_e32 v60, 32, v61                           // 000000711C40: 4E787AA0
	v_subrev_nc_u32_e32 v28, 32, v28                           // 000000711C44: 4E3838A0
	v_subrev_nc_u32_e32 v61, 32, v62                           // 000000711C48: 4E7A7CA0
	v_subrev_nc_u32_e32 v62, 32, v63                           // 000000711C4C: 4E7C7EA0
	v_cvt_f32_i32_e32 v29, v29                                 // 000000711C50: 7E3A0B1D
	v_cvt_f32_i32_e32 v55, v55                                 // 000000711C54: 7E6E0B37
	v_cvt_f32_i32_e32 v56, v56                                 // 000000711C58: 7E700B38
	v_cvt_f32_i32_e32 v26, v26                                 // 000000711C5C: 7E340B1A
	v_cvt_f32_i32_e32 v57, v57                                 // 000000711C60: 7E720B39
	v_cvt_f32_i32_e32 v58, v58                                 // 000000711C64: 7E740B3A
	v_cvt_f32_i32_e32 v59, v59                                 // 000000711C68: 7E760B3B
	v_cvt_f32_i32_e32 v60, v60                                 // 000000711C6C: 7E780B3C
	v_cvt_f32_i32_e32 v28, v28                                 // 000000711C70: 7E380B1C
	v_cvt_f32_i32_e32 v61, v61                                 // 000000711C74: 7E7A0B3D
	v_cvt_f32_i32_e32 v62, v62                                 // 000000711C78: 7E7C0B3E
	v_mul_f32_e32 v29, v54, v29                                // 000000711C7C: 103A3B36
	v_mul_f32_e32 v55, v54, v55                                // 000000711C80: 106E6F36
	v_mul_f32_e32 v56, v54, v56                                // 000000711C84: 10707136
	v_mul_f32_e32 v26, v54, v26                                // 000000711C88: 10343536
	v_mul_f32_e32 v57, v54, v57                                // 000000711C8C: 10727336
	v_mul_f32_e32 v58, v54, v58                                // 000000711C90: 10747536
	v_mul_f32_e32 v59, v54, v59                                // 000000711C94: 10767736
	v_mul_f32_e32 v60, v54, v60                                // 000000711C98: 10787936
	v_mul_f32_e32 v28, v54, v28                                // 000000711C9C: 10383936
	v_mul_f32_e32 v61, v54, v61                                // 000000711CA0: 107A7B36
	v_mul_f32_e32 v62, v54, v62                                // 000000711CA4: 107C7D36
	v_bfe_u32 v54, v29, 16, 1                                  // 000000711CA8: D6100036 0205211D
	v_bfe_u32 v63, v55, 16, 1                                  // 000000711CB0: D610003F 02052137
	v_bfe_u32 v64, v56, 16, 1                                  // 000000711CB8: D6100040 02052138
	v_bfe_u32 v65, v22, 16, 1                                  // 000000711CC0: D6100041 02052116
	v_bfe_u32 v66, v26, 16, 1                                  // 000000711CC8: D6100042 0205211A
	v_add3_u32 v29, v29, v54, 0x7fff                           // 000000711CD0: D655001D 03FE6D1D 00007FFF
	v_add3_u32 v54, v55, v63, 0x7fff                           // 000000711CDC: D6550036 03FE7F37 00007FFF
	v_add3_u32 v55, v56, v64, 0x7fff                           // 000000711CE8: D6550037 03FE8138 00007FFF
	v_bfe_u32 v67, v57, 16, 1                                  // 000000711CF4: D6100043 02052139
	v_add3_u32 v22, v22, v65, 0x7fff                           // 000000711CFC: D6550016 03FE8316 00007FFF
	.long 0x7e6c399d                                           // 000000711D08: 7E6C399D
	v_bfe_u32 v68, v58, 16, 1                                  // 000000711D0C: D6100044 0205213A
	v_add3_u32 v26, v26, v66, 0x7fff                           // 000000711D14: D655001A 03FE851A 00007FFF
	.long 0x7e2c39b7                                           // 000000711D20: 7E2C39B7
	v_bfe_u32 v69, v23, 16, 1                                  // 000000711D24: D6100045 02052117
	s_waitcnt vmcnt(5)                                         // 000000711D2C: BF8917F7
	v_dot2_f32_bf16 v30, v30, v54, 0                           // 000000711D30: CC1A401E 1A026D1E
	s_waitcnt vmcnt(4)                                         // 000000711D38: BF8913F7
	v_dot2_f32_bf16 v34, v34, v54, 0                           // 000000711D3C: CC1A4022 1A026D22
	s_waitcnt vmcnt(3)                                         // 000000711D44: BF890FF7
	v_dot2_f32_bf16 v38, v38, v54, 0                           // 000000711D48: CC1A4026 1A026D26
	v_add3_u32 v56, v57, v67, 0x7fff                           // 000000711D50: D6550038 03FE8739 00007FFF
	v_bfe_u32 v70, v27, 16, 1                                  // 000000711D5C: D6100046 0205211B
	v_add3_u32 v57, v58, v68, 0x7fff                           // 000000711D64: D6550039 03FE893A 00007FFF
	.long 0x7e70399a                                           // 000000711D70: 7E70399A
	v_dot2_f32_bf16 v26, v31, v22, v30                         // 000000711D74: CC1A401A 1C7A2D1F
	v_dot2_f32_bf16 v30, v35, v22, v34                         // 000000711D7C: CC1A401E 1C8A2D23
	v_dot2_f32_bf16 v22, v39, v22, v38                         // 000000711D84: CC1A4016 1C9A2D27
	v_bfe_u32 v71, v59, 16, 1                                  // 000000711D8C: D6100047 0205213B
	v_add3_u32 v23, v23, v69, 0x7fff                           // 000000711D94: D6550017 03FE8B17 00007FFF
	v_bfe_u32 v72, v60, 16, 1                                  // 000000711DA0: D6100048 0205213C
	v_add3_u32 v27, v27, v70, 0x7fff                           // 000000711DA8: D655001B 03FE8D1B 00007FFF
	.long 0x7e2e39b9                                           // 000000711DB4: 7E2E39B9
	v_dot2_f32_bf16 v22, v40, v56, v22                         // 000000711DB8: CC1A4016 1C5A7128
	v_dot2_f32_bf16 v26, v32, v56, v26                         // 000000711DC0: CC1A401A 1C6A7120
	v_dot2_f32_bf16 v30, v36, v56, v30                         // 000000711DC8: CC1A401E 1C7A7124
	v_bfe_u32 v73, v24, 16, 1                                  // 000000711DD0: D6100049 02052118
	v_add3_u32 v29, v59, v71, 0x7fff                           // 000000711DD8: D655001D 03FE8F3B 00007FFF
	v_bfe_u32 v74, v28, 16, 1                                  // 000000711DE4: D610004A 0205211C
	v_add3_u32 v54, v60, v72, 0x7fff                           // 000000711DEC: D6550036 03FE913C 00007FFF
	.long 0x7e3a399b                                           // 000000711DF8: 7E3A399B
	v_dot2_f32_bf16 v22, v41, v23, v22                         // 000000711DFC: CC1A4016 1C5A2F29
	v_dot2_f32_bf16 v26, v33, v23, v26                         // 000000711E04: CC1A401A 1C6A2F21
	v_dot2_f32_bf16 v27, v37, v23, v30                         // 000000711E0C: CC1A401B 1C7A2F25
	v_bfe_u32 v75, v61, 16, 1                                  // 000000711E14: D610004B 0205213D
	v_add3_u32 v24, v24, v73, 0x7fff                           // 000000711E1C: D6550018 03FE9318 00007FFF
	v_bfe_u32 v76, v62, 16, 1                                  // 000000711E28: D610004C 0205213E
	v_add3_u32 v28, v28, v74, 0x7fff                           // 000000711E30: D655001C 03FE951C 00007FFF
	.long 0x7e3039b6                                           // 000000711E3C: 7E3039B6
	s_waitcnt vmcnt(0)                                         // 000000711E40: BF8903F7
	v_dot2_f32_bf16 v22, v50, v29, v22                         // 000000711E44: CC1A4016 1C5A3B32
	v_dot2_f32_bf16 v26, v42, v29, v26                         // 000000711E4C: CC1A401A 1C6A3B2A
	v_dot2_f32_bf16 v27, v46, v29, v27                         // 000000711E54: CC1A401B 1C6E3B2E
	v_bfe_u32 v77, v25, 16, 1                                  // 000000711E5C: D610004D 02052119
	v_add3_u32 v23, v61, v75, 0x7fff                           // 000000711E64: D6550017 03FE973D 00007FFF
	v_add3_u32 v29, v62, v76, 0x7fff                           // 000000711E70: D655001D 03FE993E 00007FFF
	.long 0x7e2e399c                                           // 000000711E7C: 7E2E399C
	v_dot2_f32_bf16 v22, v51, v24, v22                         // 000000711E80: CC1A4016 1C5A3133
	v_dot2_f32_bf16 v26, v43, v24, v26                         // 000000711E88: CC1A401A 1C6A312B
	v_dot2_f32_bf16 v27, v47, v24, v27                         // 000000711E90: CC1A401B 1C6E312F
	v_add3_u32 v24, v25, v77, 0x7fff                           // 000000711E98: D6550018 03FE9B19 00007FFF
	.long 0x7e30399d                                           // 000000711EA4: 7E30399D
	v_dot2_f32_bf16 v22, v52, v23, v22                         // 000000711EA8: CC1A4016 1C5A2F34
	v_dot2_f32_bf16 v25, v44, v23, v26                         // 000000711EB0: CC1A4019 1C6A2F2C
	v_dot2_f32_bf16 v26, v48, v23, v27                         // 000000711EB8: CC1A401A 1C6E2F30
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000711EC0: BF870223
	v_dot2_f32_bf16 v22, v53, v24, v22                         // 000000711EC4: CC1A4016 1C5A3135
	v_add_nc_u32_e32 v21, 16, v21                              // 000000711ECC: 4A2A2A90
	v_dot2_f32_bf16 v23, v45, v24, v25                         // 000000711ED0: CC1A4017 1C66312D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000711ED8: BF870214
	v_dot2_f32_bf16 v25, v49, v24, v26                         // 000000711EDC: CC1A4019 1C6A3131
	v_add_f32_e32 v8, v8, v22                                  // 000000711EE4: 06102D08
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000711EE8: BF870194
	.long 0xd4430000                                           // 000000711EEC: D4430000
	v_cndmask_b32_e32 v1, s14, v21, vcc_lo                     // 000000711EF0: 02022A0E
	v_dual_add_f32 v10, v10, v23 :: v_dual_add_f32 v9, v9, v25 // 000000711EF4: C9082F0A 0A083309
	s_or_b32 s3, s0, s3                                        // 000000711EFC: 8C030300
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000711F00: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s3                        // 000000711F04: 917E037E
	s_cbranch_execnz 65154                                     // 000000711F08: BFA6FE82 <_ZN7halogen12_GLOBAL__N_16k_lq6kILi3ELi16ELi1ELb1EEEvPKhPKtPvll+0x114>
	s_or_b32 exec_lo, exec_lo, s3                              // 000000711F0C: 8C7E037E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000711F10: BF8700A9
	s_or_b32 exec_lo, exec_lo, s1                              // 000000711F14: 8C7E017E
	.long 0xd71f0000                                           // 000000711F18: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 000000711F1C: 020100C1
	v_xor_b32_e32 v3, 8, v0                                    // 000000711F20: 3A060088
	v_xor_b32_e32 v6, 4, v0                                    // 000000711F24: 3A0C0084
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000711F28: BF870092
	.long 0xd44c0000                                           // 000000711F2C: D44C0000
	v_cndmask_b32_e32 v1, 32, v3, vcc_lo                       // 000000711F30: 020206A0
	v_cndmask_b32_e64 v3, v0, v3, s0                           // 000000711F34: D5010003 00020700
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000711F3C: BF870113
	.long 0xd44c0000                                           // 000000711F40: D44C0000
	v_cndmask_b32_e32 v1, 32, v6, vcc_lo                       // 000000711F44: 02020CA0
	v_lshlrev_b32_e32 v3, 2, v3                                // 000000711F48: 30060682
	s_delay_alu instid0(VALU_DEP_2)                            // 000000711F4C: BF870002
	v_cndmask_b32_e64 v6, v0, v6, s0                           // 000000711F50: D5010006 00020D00
	ds_bpermute_b32 v4, v3, v10                                // 000000711F58: DACC0000 04000A03
	s_waitcnt lgkmcnt(0)                                       // 000000711F60: BF89FC07
	v_add_f32_e32 v4, v10, v4                                  // 000000711F64: 0608090A
	ds_bpermute_b32 v5, v3, v9                                 // 000000711F68: DACC0000 05000903
	ds_bpermute_b32 v3, v3, v8                                 // 000000711F70: DACC0000 03000803
	v_xor_b32_e32 v10, 2, v0                                   // 000000711F78: 3A140082
	v_lshlrev_b32_e32 v6, 2, v6                                // 000000711F7C: 300C0C82
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000711F80: BF870092
	.long 0xd44c0000                                           // 000000711F84: D44C0000
	v_cndmask_b32_e32 v1, 32, v10, vcc_lo                      // 000000711F88: 020214A0
	v_cndmask_b32_e64 v10, v0, v10, s0                         // 000000711F8C: D501000A 00021500
	s_waitcnt lgkmcnt(1)                                       // 000000711F94: BF89FC17
	s_delay_alu instid0(VALU_DEP_1)                            // 000000711F98: BF870001
	v_dual_add_f32 v5, v9, v5 :: v_dual_lshlrev_b32 v10, 2, v10// 000000711F9C: C9220B09 050A1482
	s_waitcnt lgkmcnt(0)                                       // 000000711FA4: BF89FC07
	v_add_f32_e32 v3, v8, v3                                   // 000000711FA8: 06060708
	ds_bpermute_b32 v8, v6, v4                                 // 000000711FAC: DACC0000 08000406
	ds_bpermute_b32 v9, v6, v5                                 // 000000711FB4: DACC0000 09000506
	ds_bpermute_b32 v6, v6, v3                                 // 000000711FBC: DACC0000 06000306
	s_waitcnt lgkmcnt(1)                                       // 000000711FC4: BF89FC17
	v_dual_add_f32 v4, v4, v8 :: v_dual_add_f32 v5, v5, v9     // 000000711FC8: C9081104 04041305
	ds_bpermute_b32 v8, v10, v5                                // 000000711FD0: DACC0000 0800050A
	s_waitcnt lgkmcnt(1)                                       // 000000711FD8: BF89FC17
	v_add_f32_e32 v6, v3, v6                                   // 000000711FDC: 060C0D03
	ds_bpermute_b32 v3, v10, v4                                // 000000711FE0: DACC0000 0300040A
	ds_bpermute_b32 v9, v10, v6                                // 000000711FE8: DACC0000 0900060A
	v_xor_b32_e32 v10, 1, v0                                   // 000000711FF0: 3A140081
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000711FF4: BF870091
	.long 0xd44c0000                                           // 000000711FF8: D44C0000
	v_cndmask_b32_e32 v1, 32, v10, vcc_lo                      // 000000711FFC: 020214A0
	v_cndmask_b32_e64 v0, v0, v10, s0                          // 000000712000: D5010000 00021500
	.long 0xd44a0000                                           // 000000712008: D44A0000
	v_cndmask_b32_e32 v1, 0, v7, vcc_lo                        // 00000071200C: 02020E80
	s_delay_alu instid0(VALU_DEP_2)                            // 000000712010: BF870002
	v_lshlrev_b32_e32 v10, 2, v0                               // 000000712014: 30140082
	s_waitcnt lgkmcnt(1)                                       // 000000712018: BF89FC17
	v_dual_add_f32 v0, v4, v3 :: v_dual_add_f32 v3, v5, v8     // 00000071201C: C9080704 00021105
	s_and_b32 s0, s0, vcc_lo                                   // 000000712024: 8B006A00
	s_waitcnt lgkmcnt(0)                                       // 000000712028: BF89FC07
	v_add_f32_e32 v5, v6, v9                                   // 00000071202C: 060A1306
	ds_bpermute_b32 v4, v10, v0                                // 000000712030: DACC0000 0400000A
	ds_bpermute_b32 v6, v10, v3                                // 000000712038: DACC0000 0600030A
	ds_bpermute_b32 v8, v10, v5                                // 000000712040: DACC0000 0800050A
	s_and_saveexec_b32 s1, s0                                  // 000000712048: BE812000
	s_cbranch_execz 30                                         // 00000071204C: BFA5001E <_ZN7halogen12_GLOBAL__N_16k_lq6kILi3ELi16ELi1ELb1EEEvPKhPKtPvll+0x8c8>
	.long 0xd73c0001                                           // 000000712050: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 000000712054: 02020282
	s_waitcnt lgkmcnt(0)                                       // 000000712058: BF89FC07
	v_dual_add_f32 v7, v5, v8 :: v_dual_add_f32 v6, v3, v6     // 00000071205C: C9081105 07060D03
	v_add_f32_e32 v8, v0, v4                                   // 000000712064: 06100900
	s_lshl_b64 s[0:1], s[12:13], 2                             // 000000712068: 8480820C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000071206C: BF870093
	.long 0xd7006a00                                           // 000000712070: D7006A00
	v_cndmask_b32_e32 v1, s8, v1, vcc_lo                       // 000000712074: 02020208
	v_add_co_ci_u32_e64 v1, null, s9, v2, vcc_lo               // 000000712078: D5207C01 01AA0409
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000712080: BF870092
	.long 0xd7006a02                                           // 000000712084: D7006A02
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 000000712088: 02000100
	v_add_co_ci_u32_e64 v3, null, s1, v1, vcc_lo               // 00000071208C: D5207C03 01AA0201
	s_lshl_b64 s[0:1], s[12:13], 3                             // 000000712094: 8480830C
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000712098: BF870099
	.long 0xd7006a04                                           // 00000071209C: D7006A04
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 0000007120A0: 02000100
	v_add_co_ci_u32_e64 v5, null, s1, v1, vcc_lo               // 0000007120A4: D5207C05 01AA0201
	s_clause 0x2                                               // 0000007120AC: BF850002
	global_store_b32 v[0:1], v8, off                           // 0000007120B0: DC6A0000 007C0800
	global_store_b32 v[2:3], v6, off                           // 0000007120B8: DC6A0000 007C0602
	global_store_b32 v[4:5], v7, off                           // 0000007120C0: DC6A0000 007C0704
	s_endpgm                                                   // 0000007120C8: BFB00000
		...

