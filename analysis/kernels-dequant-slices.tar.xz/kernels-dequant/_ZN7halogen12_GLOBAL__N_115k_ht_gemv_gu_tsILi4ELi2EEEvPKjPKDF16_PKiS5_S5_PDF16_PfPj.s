0000000000943100 <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_gu_tsILi4ELi2EEEvPKjPKDF16_PKiS5_S5_PDF16_PfPj>:
; _ZN7halogen12_GLOBAL__N_115k_ht_gemv_gu_tsILi4ELi2EEEvPKjPKDF16_PKiS5_S5_PDF16_PfPj():
	s_load_b512 s[4:19], s[0:1], null                          // 000000943100: F4100100 F8000000
	s_mul_hi_i32 s0, s2, 0x66666667                            // 000000943108: 9700FF02 66666667
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000943110: BF8704A9
	s_lshr_b32 s1, s0, 31                                      // 000000943114: 85019F00
	s_ashr_i32 s0, s0, 2                                       // 000000943118: 86008200
	s_add_i32 s20, s0, s1                                      // 00000094311C: 81140100
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000943120: BF870499
	s_ashr_i32 s21, s20, 31                                    // 000000943124: 86159F14
	s_lshl_b64 s[0:1], s[20:21], 2                             // 000000943128: 84808214
	s_waitcnt lgkmcnt(0)                                       // 00000094312C: BF89FC07
	s_add_u32 s0, s8, s0                                       // 000000943130: 80000008
	s_addc_u32 s1, s9, s1                                      // 000000943134: 82010109
	s_load_b32 s8, s[0:1], null                                // 000000943138: F4000200 F8000000
	s_mov_b32 s1, exec_lo                                      // 000000943140: BE81007E
	v_cmpx_gt_u32_e32 0x140, v0                                // 000000943144: 7D9800FF 00000140
	s_cbranch_execz 49                                         // 00000094314C: BFA50031 <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_gu_tsILi4ELi2EEEvPKjPKDF16_PKiS5_S5_PDF16_PfPj+0x114>
	s_mul_hi_i32 s0, s2, 0x51eb851f                            // 000000943150: 9700FF02 51EB851F
	v_lshlrev_b32_e32 v4, 4, v0                                // 000000943158: 30080084
	s_lshr_b32 s3, s0, 31                                      // 00000094315C: 85039F00
	s_ashr_i32 s0, s0, 5                                       // 000000943160: 86008500
	v_or_b32_e32 v3, 0xffffff80, v0                            // 000000943164: 380600FF FFFFFF80
	s_add_i32 s0, s0, s3                                       // 00000094316C: 81000300
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000943170: BF8700D9
	s_mul_i32 s3, s0, 0x1400                                   // 000000943174: 9603FF00 00001400
	s_mul_hi_i32 s0, s0, 0x1400                                // 00000094317C: 9700FF00 00001400
	s_add_u32 s3, s6, s3                                       // 000000943184: 80030306
	s_addc_u32 s0, s7, s0                                      // 000000943188: 82000007
	.long 0xd7000301                                           // 00000094318C: D7000301
	v_cndmask_b32_e32 v1, s3, v4, vcc_lo                       // 000000943190: 02020803
	v_add_co_ci_u32_e64 v2, null, s0, 0, s3                    // 000000943194: D5207C02 000D0000
	s_mov_b32 s3, 0                                            // 00000094319C: BE830080
	s_nop 0                                                    // 0000009431A0: BF800000
	s_nop 0                                                    // 0000009431A4: BF800000
	s_nop 0                                                    // 0000009431A8: BF800000
	s_nop 0                                                    // 0000009431AC: BF800000
	s_nop 0                                                    // 0000009431B0: BF800000
	s_nop 0                                                    // 0000009431B4: BF800000
	s_nop 0                                                    // 0000009431B8: BF800000
	s_nop 0                                                    // 0000009431BC: BF800000
	global_load_b128 v[5:8], v[1:2], off                       // 0000009431C0: DC5E0000 057C0001
	v_add_nc_u32_e32 v3, 0x80, v3                              // 0000009431C8: 4A0606FF 00000080
	.long 0xd7006a01                                           // 0000009431D0: D7006A01
	v_cndmask_b32_e32 v1, 0x800, v1, vcc_lo                    // 0000009431D4: 020202FF 00000800
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009431DC: BF870191
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 0000009431E0: D5207C02 01AA0480
	.long 0xd4490000                                           // 0000009431E8: D4490000
	v_cndmask_b32_e32 v1, 0xbf, v3, vcc_lo                     // 0000009431EC: 020206FF 000000BF
	s_or_b32 s3, s0, s3                                        // 0000009431F4: 8C030300
	s_waitcnt vmcnt(0)                                         // 0000009431F8: BF8903F7
	ds_store_b128 v4, v[5:8]                                   // 0000009431FC: DB7C0000 00000504
	v_add_nc_u32_e32 v4, 0x800, v4                             // 000000943204: 4A0808FF 00000800
	s_and_not1_b32 exec_lo, exec_lo, s3                        // 00000094320C: 917E037E
	s_cbranch_execnz 65515                                     // 000000943210: BFA6FFEB <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_gu_tsILi4ELi2EEEvPKjPKDF16_PKiS5_S5_PDF16_PfPj+0xc0>
	s_or_b32 exec_lo, exec_lo, s1                              // 000000943214: 8C7E017E
	s_lshr_b32 s0, s2, 31                                      // 000000943218: 85009F02
	v_lshrrev_b32_e32 v25, 5, v0                               // 00000094321C: 32320085
	s_add_i32 s0, s2, s0                                       // 000000943220: 81000002
	v_and_b32_e32 v27, 31, v0                                  // 000000943224: 3636009F
	s_ashr_i32 s6, s0, 1                                       // 000000943228: 86068100
	s_lshl_b32 s0, s2, 2                                       // 00000094322C: 84008202
	s_lshl_b32 s1, s6, 3                                       // 000000943230: 84018306
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000943234: BF870141
	v_dual_mov_b32 v1, 0 :: v_dual_lshlrev_b32 v26, 2, v27     // 000000943238: CA220080 011A3682
	s_sub_i32 s0, s0, s1                                       // 000000943240: 81800100
	s_mul_i32 s3, s20, -5                                      // 000000943244: 9603C514
	v_or_b32_e32 v22, s0, v25                                  // 000000943248: 382C3200
	v_mov_b32_e32 v16, v1                                      // 00000094324C: 7E200301
	v_mov_b32_e32 v2, v1                                       // 000000943250: 7E040301
	v_mov_b32_e32 v3, v1                                       // 000000943254: 7E060301
	v_mov_b32_e32 v5, v1                                       // 000000943258: 7E0A0301
	.long 0xd72c0012                                           // 00000094325C: D72C0012
	v_cndmask_b32_e32 v0, v22, v148, vcc_lo                    // 000000943260: 02012916
	v_mov_b32_e32 v6, v1                                       // 000000943264: 7E0C0301
	v_mov_b32_e32 v7, v1                                       // 000000943268: 7E0E0301
	v_mov_b32_e32 v8, v1                                       // 00000094326C: 7E100301
	v_mov_b32_e32 v9, v1                                       // 000000943270: 7E120301
	v_mov_b32_e32 v10, v1                                      // 000000943274: 7E140301
	v_mov_b32_e32 v11, v1                                      // 000000943278: 7E160301
	v_mov_b32_e32 v12, v1                                      // 00000094327C: 7E180301
	v_min_i32_e32 v20, 0x8c, v18                               // 000000943280: 222824FF 0000008C
	v_mov_b32_e32 v4, v1                                       // 000000943288: 7E080301
	v_mov_b32_e32 v13, v1                                      // 00000094328C: 7E1A0301
	v_mov_b32_e32 v14, v1                                      // 000000943290: 7E1C0301
	v_mov_b32_e32 v15, v1                                      // 000000943294: 7E1E0301
	v_add_nc_u32_e32 v29, 20, v20                              // 000000943298: 4A3A2894
	v_mov_b32_e32 v17, v16                                     // 00000094329C: 7E220310
	v_ashrrev_i32_e32 v19, 31, v18                             // 0000009432A0: 3426249F
	s_delay_alu instid0(VALU_DEP_4)                            // 0000009432A4: BF870004
	v_mov_b32_e32 v16, v15                                     // 0000009432A8: 7E20030F
	v_mov_b32_e32 v15, v14                                     // 0000009432AC: 7E1E030E
	v_cmp_lt_i32_e32 vcc_lo, v18, v29                          // 0000009432B0: 7C823B12
	v_mov_b32_e32 v14, v13                                     // 0000009432B4: 7E1C030D
	v_mov_b32_e32 v13, v12                                     // 0000009432B8: 7E1A030C
	v_mov_b32_e32 v12, v11                                     // 0000009432BC: 7E18030B
	v_mov_b32_e32 v11, v10                                     // 0000009432C0: 7E16030A
	v_mov_b32_e32 v10, v9                                      // 0000009432C4: 7E140309
	v_mov_b32_e32 v9, v8                                       // 0000009432C8: 7E120308
	v_mov_b32_e32 v8, v7                                       // 0000009432CC: 7E100307
	v_mov_b32_e32 v7, v6                                       // 0000009432D0: 7E0E0306
	v_mov_b32_e32 v6, v5                                       // 0000009432D4: 7E0C0305
	v_mov_b32_e32 v5, v4                                       // 0000009432D8: 7E0A0304
	v_mov_b32_e32 v4, v3                                       // 0000009432DC: 7E080303
	v_mov_b32_e32 v3, v2                                       // 0000009432E0: 7E060302
	v_mov_b32_e32 v2, v1                                       // 0000009432E4: 7E040301
	s_add_i32 s2, s3, s6                                       // 0000009432E8: 81020603
	s_waitcnt lgkmcnt(0)                                       // 0000009432EC: BF89FC07
	s_mul_hi_i32 s1, s8, 0x190000                              // 0000009432F0: 9701FF08 00190000
	s_mul_i32 s7, s8, 0x190000                                 // 0000009432F8: 9607FF08 00190000
	s_mul_hi_i32 s9, s2, 0x50000                               // 000000943300: 9709FF02 00050000
	s_mul_i32 s21, s2, 0x50000                                 // 000000943308: 9615FF02 00050000
	s_barrier                                                  // 000000943310: BFBD0000
	buffer_gl0_inv                                             // 000000943314: E0AC0000 00000000
	s_and_saveexec_b32 s3, vcc_lo                              // 00000094331C: BE83206A
	s_cbranch_execz 49                                         // 000000943320: BFA50031 <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_gu_tsILi4ELi2EEEvPKjPKDF16_PKiS5_S5_PDF16_PfPj+0x2e8>
	.long 0xd73c0002                                           // 000000943324: D73C0002
	v_cndmask_b32_e32 v1, 11, v18, vcc_lo                      // 000000943328: 0202248B
	s_add_u32 s0, s4, s7                                       // 00000094332C: 80000704
	s_addc_u32 s22, s5, s1                                     // 000000943330: 82160105
	s_add_u32 s0, s0, s21                                      // 000000943334: 80001500
	s_addc_u32 s22, s22, s9                                    // 000000943338: 82160916
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000094333C: BF870091
	.long 0xd7000002                                           // 000000943340: D7000002
	v_cndmask_b32_e32 v1, s0, v2, vcc_lo                       // 000000943344: 02020400
	v_add_co_ci_u32_e64 v3, null, s22, v3, s0                  // 000000943348: D5207C03 00020616
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000943350: BF870092
	.long 0xd7000017                                           // 000000943354: D7000017
	v_cndmask_b32_e32 v1, v2, v26, vcc_lo                      // 000000943358: 02023502
	v_add_co_ci_u32_e64 v24, null, 0, v3, s0                   // 00000094335C: D5207C18 00020680
	s_clause 0xf                                               // 000000943364: BF85000F
	global_load_b32 v2, v[23:24], off                          // 000000943368: DC520000 027C0017
	global_load_b32 v3, v[23:24], off offset:128               // 000000943370: DC520080 037C0017
	global_load_b32 v4, v[23:24], off offset:256               // 000000943378: DC520100 047C0017
	global_load_b32 v5, v[23:24], off offset:384               // 000000943380: DC520180 057C0017
	global_load_b32 v6, v[23:24], off offset:512               // 000000943388: DC520200 067C0017
	global_load_b32 v7, v[23:24], off offset:640               // 000000943390: DC520280 077C0017
	global_load_b32 v8, v[23:24], off offset:768               // 000000943398: DC520300 087C0017
	global_load_b32 v9, v[23:24], off offset:896               // 0000009433A0: DC520380 097C0017
	global_load_b32 v10, v[23:24], off offset:1024             // 0000009433A8: DC520400 0A7C0017
	global_load_b32 v11, v[23:24], off offset:1152             // 0000009433B0: DC520480 0B7C0017
	global_load_b32 v12, v[23:24], off offset:1280             // 0000009433B8: DC520500 0C7C0017
	global_load_b32 v13, v[23:24], off offset:1408             // 0000009433C0: DC520580 0D7C0017
	global_load_b32 v14, v[23:24], off offset:1536             // 0000009433C8: DC520600 0E7C0017
	global_load_b32 v15, v[23:24], off offset:1664             // 0000009433D0: DC520680 0F7C0017
	global_load_b32 v16, v[23:24], off offset:1792             // 0000009433D8: DC520700 107C0017
	global_load_b32 v17, v[23:24], off offset:1920             // 0000009433E0: DC520780 117C0017
	s_or_b32 exec_lo, exec_lo, s3                              // 0000009433E8: 8C7E037E
	.long 0xd44a0000                                           // 0000009433EC: D44A0000
	v_cndmask_b32_e32 v1, 0, v27, vcc_lo                       // 0000009433F0: 02023680
	v_dual_mov_b32 v30, 0 :: v_dual_mov_b32 v31, 0             // 0000009433F4: CA100080 1E1E0080
	v_dual_mov_b32 v32, 0 :: v_dual_mov_b32 v33, 0             // 0000009433FC: CA100080 20200080
	v_dual_mov_b32 v34, 0 :: v_dual_mov_b32 v35, 0             // 000000943404: CA100080 22220080
	v_dual_mov_b32 v36, 0 :: v_dual_mov_b32 v37, 0             // 00000094340C: CA100080 24240080
	v_dual_mov_b32 v38, 0 :: v_dual_mov_b32 v39, 0             // 000000943414: CA100080 26260080
	v_dual_mov_b32 v40, 0 :: v_dual_mov_b32 v41, 0             // 00000094341C: CA100080 28280080
	v_dual_mov_b32 v42, 0 :: v_dual_mov_b32 v43, 0             // 000000943424: CA100080 2A2A0080
	v_mov_b32_e32 v28, 0                                       // 00000094342C: 7E380280
	s_and_saveexec_b32 s3, vcc_lo                              // 000000943430: BE83206A
	s_cbranch_execz 1859                                       // 000000943434: BFA50743 <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_gu_tsILi4ELi2EEEvPKjPKDF16_PKiS5_S5_PDF16_PfPj+0x2044>
	v_dual_mov_b32 v28, 0 :: v_dual_lshlrev_b32 v1, 5, v27     // 000000943438: CA220080 1C003685
	.long 0xd73c0017                                           // 000000943440: D73C0017
	v_cndmask_b32_e32 v1, 11, v18, vcc_lo                      // 000000943444: 0202248B
	.long 0xd72c0013                                           // 000000943448: D72C0013
	v_cndmask_b32_e32 v1, 0x280, v22, vcc_lo                   // 00000094344C: 02022CFF 00000280
	s_add_u32 s7, s7, s21                                      // 000000943454: 80071507
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000943458: BF8701A3
	v_dual_mov_b32 v42, 0 :: v_dual_add_nc_u32 v21, 0x3f0, v1  // 00000094345C: CA200080 2A1402FF 000003F0
	s_addc_u32 s1, s1, s9                                      // 000000943468: 82010901
	.long 0xd7006a17                                           // 00000094346C: D7006A17
	v_cndmask_b32_e32 v1, s7, v23, vcc_lo                      // 000000943470: 02022E07
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000943474: BF870212
	v_lshrrev_b32_e32 v32, 5, v21                              // 000000943478: 32402A85
	v_and_or_b32 v44, v0, 16, v19                              // 00000094347C: D657002C 044D2100
	v_dual_mov_b32 v40, 0 :: v_dual_and_b32 v19, 0x7e0, v21    // 000000943484: CA240080 28122AFF 000007E0
	v_add_co_ci_u32_e64 v24, null, s1, v24, vcc_lo             // 000000943490: D5207C18 01AA3001
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000943498: BF870194
	v_subrev_nc_u32_e32 v32, 32, v32                           // 00000094349C: 4E4040A0
	v_sub_nc_u32_e32 v1, v19, v1                               // 0000009434A0: 4C020313
	.long 0xd7006a17                                           // 0000009434A4: D7006A17
	v_cndmask_b32_e32 v1, v23, v26, vcc_lo                     // 0000009434A8: 02023517
	v_mul_u32_u24_e32 v30, 0x840, v25                          // 0000009434AC: 163C32FF 00000840
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000009434B4: BF8701B4
	v_cndmask_b32_e64 v21, v32, 31, s0                         // 0000009434B8: D5010015 00013F20
	v_add_co_ci_u32_e64 v24, null, 0, v24, vcc_lo              // 0000009434C0: D5207C18 01AA3080
	v_dual_mov_b32 v36, 0 :: v_dual_add_nc_u32 v45, 0xfffffc30, v1// 0000009434C8: CA200080 242C02FF FFFFFC30
	v_dual_mov_b32 v38, 0 :: v_dual_add_nc_u32 v19, 1, v21     // 0000009434D4: CA200080 26122A81
	.long 0xd7006a17                                           // 0000009434DC: D7006A17
	v_cndmask_b32_e32 v1, s4, v23, vcc_lo                      // 0000009434E0: 02022E04
	v_mad_u32_u24 v31, 0x840, v25, v26                         // 0000009434E4: D60B001F 046A32FF 00000840
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000009434F0: BF8701B3
	v_dual_mov_b32 v34, 0 :: v_dual_and_b32 v1, 31, v19        // 0000009434F4: CA240080 2200269F
	v_add_co_ci_u32_e64 v24, null, s5, v24, vcc_lo             // 0000009434FC: D5207C18 01AA3005
	v_lshl_add_u32 v19, v21, 2, v30                            // 000000943504: D6460013 04790515
	v_lshl_add_u32 v1, v1, 2, v30                              // 00000094350C: D6460001 04790501
	.long 0xd7006a17                                           // 000000943514: D7006A17
	v_cndmask_b32_e32 v1, 0x800, v23, vcc_lo                   // 000000943518: 02022EFF 00000800
	s_delay_alu instid0(VALU_DEP_1)                            // 000000943520: BF870001
	v_add_co_ci_u32_e64 v24, null, 0, v24, vcc_lo              // 000000943524: D5207C18 01AA3080
	v_sub_nc_u32_e32 v46, 0, v20                               // 00000094352C: 4C5C2880
	v_dual_mov_b32 v32, 0 :: v_dual_add_nc_u32 v47, 1, v18     // 000000943530: CA200080 202E2481
	v_dual_mov_b32 v43, 0 :: v_dual_add_nc_u32 v48, 0x1400, v31// 000000943538: CA200080 2B303EFF 00001400
	v_dual_mov_b32 v30, 0 :: v_dual_add_nc_u32 v49, 0x1800, v31// 000000943544: CA200080 1E303EFF 00001800
	v_dual_mov_b32 v41, 0 :: v_dual_add_nc_u32 v50, 0x1400, v19// 000000943550: CA200080 293226FF 00001400
	v_add_nc_u32_e32 v51, 0x1400, v1                           // 00000094355C: 4A6602FF 00001400
	v_dual_mov_b32 v39, 0 :: v_dual_add_nc_u32 v52, 0x1800, v19// 000000943564: CA200080 273426FF 00001800
	v_add_nc_u32_e32 v53, 0x1800, v1                           // 000000943570: 4A6A02FF 00001800
	v_mov_b32_e32 v37, 0                                       // 000000943578: 7E4A0280
	v_mov_b32_e32 v35, 0                                       // 00000094357C: 7E460280
	v_mov_b32_e32 v33, 0                                       // 000000943580: 7E420280
	v_mov_b32_e32 v31, 0                                       // 000000943584: 7E3E0280
	v_mov_b32_e32 v1, 0                                        // 000000943588: 7E020280
	s_mov_b32 s4, 0                                            // 00000094358C: BE840080
	s_movk_i32 s5, 0x1eee                                      // 000000943590: B0051EEE
	s_branch 1708                                              // 000000943594: BFA006AC <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_gu_tsILi4ELi2EEEvPKjPKDF16_PKiS5_S5_PDF16_PfPj+0x1f48>
	s_or_b32 exec_lo, exec_lo, s1                              // 000000943598: 8C7E017E
	ds_load_2addr_b32 v[54:55], v51 offset1:32                 // 00000094359C: D8DC2000 36000033
	ds_load_2addr_b32 v[64:65], v48 offset1:32                 // 0000009435A4: D8DC2000 40000030
	ds_load_2addr_b32 v[58:59], v50 offset1:32                 // 0000009435AC: D8DC2000 3A000032
	ds_load_b128 v[18:21], v44                                 // 0000009435B4: DBFC0000 1200002C
	ds_load_2addr_b32 v[60:61], v50 offset0:64 offset1:96      // 0000009435BC: D8DC6040 3C000032
	ds_load_2addr_b32 v[62:63], v51 offset0:64 offset1:96      // 0000009435C4: D8DC6040 3E000033
	.long 0xd7000117                                           // 0000009435CC: D7000117
	v_cndmask_b32_e32 v1, 0x800, v23, vcc_lo                   // 0000009435D0: 02022EFF 00000800
	v_add_nc_u32_e32 v44, 32, v44                              // 0000009435D8: 4A5858A0
	v_add_co_ci_u32_e64 v24, null, 0, v24, s1                  // 0000009435DC: D5207C18 00063080
	s_waitcnt lgkmcnt(5)                                       // 0000009435E4: BF89FC57
	v_mov_b32_e32 v57, v54                                     // 0000009435E8: 7E720336
	s_waitcnt lgkmcnt(4)                                       // 0000009435EC: BF89FC47
	v_bfe_u32 v54, v64, 12, 16                                 // 0000009435F0: D6100036 02411940
	v_bfe_u32 v66, v64, 8, 16                                  // 0000009435F8: D6100042 02411140
	v_bfe_u32 v67, v64, 4, 16                                  // 000000943600: D6100043 02410940
	v_and_b32_e32 v64, 0xffff, v64                             // 000000943608: 368080FF 0000FFFF
	s_waitcnt lgkmcnt(3)                                       // 000000943610: BF89FC37
	.long 0xd73d0039                                           // 000000943614: D73D0039
	v_cndmask_b32_e32 v1, v45, v57, vcc_lo                     // 000000943618: 0202732D
	v_mov_b32_e32 v56, v59                                     // 00000094361C: 7E70033B
	v_bfe_u32 v59, v65, 12, 16                                 // 000000943620: D610003B 02411941
	v_bfe_u32 v68, v65, 8, 16                                  // 000000943628: D6100044 02411141
	v_bfe_u32 v69, v65, 4, 16                                  // 000000943630: D6100045 02410941
	v_and_b32_e32 v65, 0xffff, v65                             // 000000943638: 368282FF 0000FFFF
	.long 0xd72c003a                                           // 000000943640: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v54, vcc_lo              // 000000943644: 02026CFF 83DCD12D
	.long 0xd73d0036                                           // 00000094364C: D73D0036
	v_cndmask_b32_e32 v1, v45, v55, vcc_lo                     // 000000943650: 02026F2D
	v_bfe_u32 v56, v57, 12, 16                                 // 000000943654: D6100038 02411939
	.long 0xd72c0037                                           // 00000094365C: D72C0037
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 000000943660: 020276FF 83DCD12D
	v_bfe_u32 v59, v57, 8, 16                                  // 000000943668: D610003B 02411139
	.long 0xd72c0042                                           // 000000943670: D72C0042
	v_cndmask_b32_e32 v1, 0x83dcd12d, v66, vcc_lo              // 000000943674: 020284FF 83DCD12D
	v_bfe_u32 v70, v57, 4, 16                                  // 00000094367C: D6100046 02410939
	.long 0xd72c0038                                           // 000000943684: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v56, vcc_lo              // 000000943688: 020270FF 83DCD12D
	.long 0xd72c0040                                           // 000000943690: D72C0040
	v_cndmask_b32_e32 v1, 0x83dcd12d, v64, vcc_lo              // 000000943694: 020280FF 83DCD12D
	.long 0xd72c003b                                           // 00000094369C: D72C003B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 0000009436A0: 020276FF 83DCD12D
	v_sad_u8 v58, v58, 0, 0x6400                               // 0000009436A8: D622003A 03FD013A 00006400
	.long 0xd72c0043                                           // 0000009436B4: D72C0043
	v_cndmask_b32_e32 v1, 0x83dcd12d, v67, vcc_lo              // 0000009436B8: 020286FF 83DCD12D
	v_bfe_u32 v71, v54, 12, 16                                 // 0000009436C0: D6100047 02411936
	v_sad_u8 v66, v66, 0, 0x6400                               // 0000009436C8: D6220042 03FD0142 00006400
	.long 0xd72c0046                                           // 0000009436D4: D72C0046
	v_cndmask_b32_e32 v1, 0x83dcd12d, v70, vcc_lo              // 0000009436D8: 02028CFF 83DCD12D
	v_sad_u8 v56, v56, 0, 0x6400                               // 0000009436E0: D6220038 03FD0138 00006400
	v_and_b32_e32 v58, 0xffff, v58                             // 0000009436EC: 367474FF 0000FFFF
	v_sad_u8 v59, v59, 0, 0x6400                               // 0000009436F4: D622003B 03FD013B 00006400
	v_sad_u8 v64, v64, 0, 0x6400                               // 000000943700: D6220040 03FD0140 00006400
	v_bfe_u32 v72, v54, 8, 16                                  // 00000094370C: D6100048 02411136
	v_and_b32_e32 v56, 0xffff, v56                             // 000000943714: 367070FF 0000FFFF
	.long 0xd72c0047                                           // 00000094371C: D72C0047
	v_cndmask_b32_e32 v1, 0x83dcd12d, v71, vcc_lo              // 000000943720: 02028EFF 83DCD12D
	v_lshl_or_b32 v58, v66, 16, v58                            // 000000943728: D656003A 04E92142
	v_sad_u8 v67, v67, 0, 0x6400                               // 000000943730: D6220043 03FD0143 00006400
	v_lshlrev_b32_e32 v64, 16, v64                             // 00000094373C: 30808090
	v_lshl_or_b32 v56, v59, 16, v56                            // 000000943740: D6560038 04E1213B
	.long 0xd72c0048                                           // 000000943748: D72C0048
	v_cndmask_b32_e32 v1, 0x83dcd12d, v72, vcc_lo              // 00000094374C: 020290FF 83DCD12D
	v_sad_u8 v66, v70, 0, 0x6400                               // 000000943754: D6220042 03FD0146 00006400
	v_pk_fma_f16 v70, v58, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000943760: CC0E0046 0BFC0B3A 0000C931
	v_and_or_b32 v59, 0xffff, v67, v64                         // 00000094376C: D657003B 050286FF 0000FFFF
	v_pk_fma_f16 v56, v56, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000943778: CC0E0038 0BFC0B38 0000C931
	v_and_b32_e32 v57, 0xffff, v57                             // 000000943784: 367272FF 0000FFFF
	v_sad_u8 v64, v71, 0, 0x6400                               // 00000094378C: D6220040 03FD0147 00006400
	.long 0xd72c0044                                           // 000000943798: D72C0044
	v_cndmask_b32_e32 v1, 0x83dcd12d, v68, vcc_lo              // 00000094379C: 020288FF 83DCD12D
	v_bfe_u32 v73, v54, 4, 16                                  // 0000009437A4: D6100049 02410936
	s_waitcnt lgkmcnt(2)                                       // 0000009437AC: BF89FC27
	v_dot2acc_f32_f16 v28, v56, v18                            // 0000009437B0: 04382538
	.long 0xd72c0039                                           // 0000009437B4: D72C0039
	v_cndmask_b32_e32 v1, 0x83dcd12d, v57, vcc_lo              // 0000009437B8: 020272FF 83DCD12D
	v_and_b32_e32 v54, 0xffff, v54                             // 0000009437C0: 366C6CFF 0000FFFF
	v_sad_u8 v55, v55, 0, 0x6400                               // 0000009437C8: D6220037 03FD0137 00006400
	v_sad_u8 v67, v72, 0, 0x6400                               // 0000009437D4: D6220043 03FD0148 00006400
	v_and_b32_e32 v64, 0xffff, v64                             // 0000009437E0: 368080FF 0000FFFF
	v_pk_fma_f16 v71, v59, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009437E8: CC0E0047 0BFC0B3B 0000C931
	s_waitcnt lgkmcnt(0)                                       // 0000009437F4: BF89FC07
	v_mov_b32_e32 v59, v62                                     // 0000009437F8: 7E76033E
	.long 0xd72c0036                                           // 0000009437FC: D72C0036
	v_cndmask_b32_e32 v1, 0x83dcd12d, v54, vcc_lo              // 000000943800: 02026CFF 83DCD12D
	v_sad_u8 v57, v57, 0, 0x6400                               // 000000943808: D6220039 03FD0139 00006400
	v_lshl_or_b32 v64, v67, 16, v64                            // 000000943814: D6560040 05012143
	v_and_b32_e32 v67, 0xffff, v55                             // 00000094381C: 36866EFF 0000FFFF
	v_sad_u8 v62, v68, 0, 0x6400                               // 000000943824: D622003E 03FD0144 00006400
	.long 0xd72c0049                                           // 000000943830: D72C0049
	v_cndmask_b32_e32 v1, 0x83dcd12d, v73, vcc_lo              // 000000943834: 020292FF 83DCD12D
	v_lshlrev_b32_e32 v57, 16, v57                             // 00000094383C: 30727290
	.long 0xd72c0041                                           // 000000943840: D72C0041
	v_cndmask_b32_e32 v1, 0x83dcd12d, v65, vcc_lo              // 000000943844: 020282FF 83DCD12D
	ds_load_2addr_b32 v[55:56], v48 offset0:64 offset1:96      // 00000094384C: D8DC6040 37000030
	v_sad_u8 v54, v54, 0, 0x6400                               // 000000943854: D6220036 03FD0136 00006400
	v_and_or_b32 v57, 0xffff, v66, v57                         // 000000943860: D6570039 04E684FF 0000FFFF
	v_sad_u8 v66, v73, 0, 0x6400                               // 00000094386C: D6220042 03FD0149 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000943878: BF870092
	v_pk_fma_f16 v57, v57, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000094387C: CC0E0039 0BFC0B39 0000C931
	v_dot2acc_f32_f16 v28, v57, v19                            // 000000943888: 04382739
	.long 0xd73d0039                                           // 00000094388C: D73D0039
	v_cndmask_b32_e32 v1, v45, v59, vcc_lo                     // 000000943890: 0202772D
	v_lshl_or_b32 v58, v62, 16, v67                            // 000000943894: D656003A 050D213E
	v_sad_u8 v60, v65, 0, 0x6400                               // 00000094389C: D622003C 03FD0141 00006400
	v_pk_fma_f16 v59, v64, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009438A8: CC0E003B 0BFC0B40 0000C931
	s_delay_alu instid0(VALU_DEP_3)                            // 0000009438B4: BF870003
	v_pk_fma_f16 v65, v58, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009438B8: CC0E0041 0BFC0B3A 0000C931
	v_lshlrev_b32_e32 v54, 16, v54                             // 0000009438C4: 306C6C90
	v_bfe_u32 v62, v57, 12, 16                                 // 0000009438C8: D610003E 02411939
	v_and_b32_e32 v64, 0xffff, v57                             // 0000009438D0: 368072FF 0000FFFF
	s_waitcnt lgkmcnt(0)                                       // 0000009438D8: BF89FC07
	v_bfe_u32 v67, v55, 12, 16                                 // 0000009438DC: D6100043 02411937
	v_bfe_u32 v68, v55, 8, 16                                  // 0000009438E4: D6100044 02411137
	v_and_or_b32 v54, 0xffff, v66, v54                         // 0000009438EC: D6570036 04DA84FF 0000FFFF
	.long 0xd72c0042                                           // 0000009438F8: D72C0042
	v_cndmask_b32_e32 v1, 0x83dcd12d, v69, vcc_lo              // 0000009438FC: 02028AFF 83DCD12D
	.long 0xd72c003e                                           // 000000943904: D72C003E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v62, vcc_lo              // 000000943908: 02027CFF 83DCD12D
	.long 0xd72c0040                                           // 000000943910: D72C0040
	v_cndmask_b32_e32 v1, 0x83dcd12d, v64, vcc_lo              // 000000943914: 020280FF 83DCD12D
	.long 0xd72c0043                                           // 00000094391C: D72C0043
	v_cndmask_b32_e32 v1, 0x83dcd12d, v67, vcc_lo              // 000000943920: 020286FF 83DCD12D
	.long 0xd72c0044                                           // 000000943928: D72C0044
	v_cndmask_b32_e32 v1, 0x83dcd12d, v68, vcc_lo              // 00000094392C: 020288FF 83DCD12D
	v_lshlrev_b32_e32 v60, 16, v60                             // 000000943934: 30787890
	v_bfe_u32 v69, v55, 4, 16                                  // 000000943938: D6100045 02410937
	v_and_b32_e32 v55, 0xffff, v55                             // 000000943940: 366E6EFF 0000FFFF
	v_sad_u8 v58, v66, 0, 0x6400                               // 000000943948: D622003A 03FD0142 00006400
	v_bfe_u32 v66, v57, 8, 16                                  // 000000943954: D6100042 02411139
	v_bfe_u32 v57, v57, 4, 16                                  // 00000094395C: D6100039 02410939
	v_sad_u8 v62, v62, 0, 0x6400                               // 000000943964: D622003E 03FD013E 00006400
	v_sad_u8 v64, v64, 0, 0x6400                               // 000000943970: D6220040 03FD0140 00006400
	v_sad_u8 v67, v67, 0, 0x6400                               // 00000094397C: D6220043 03FD0143 00006400
	.long 0xd72c0042                                           // 000000943988: D72C0042
	v_cndmask_b32_e32 v1, 0x83dcd12d, v66, vcc_lo              // 00000094398C: 020284FF 83DCD12D
	.long 0xd72c0039                                           // 000000943994: D72C0039
	v_cndmask_b32_e32 v1, 0x83dcd12d, v57, vcc_lo              // 000000943998: 020272FF 83DCD12D
	v_and_b32_e32 v62, 0xffff, v62                             // 0000009439A0: 367C7CFF 0000FFFF
	v_lshlrev_b32_e32 v64, 16, v64                             // 0000009439A8: 30808090
	v_and_or_b32 v58, 0xffff, v58, v60                         // 0000009439AC: D657003A 04F274FF 0000FFFF
	v_dot2acc_f32_f16 v43, v59, v18                            // 0000009439B8: 0456253B
	v_pk_fma_f16 v54, v54, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009439BC: CC0E0036 0BFC0B36 0000C931
	v_sad_u8 v66, v66, 0, 0x6400                               // 0000009439C8: D6220042 03FD0142 00006400
	v_sad_u8 v57, v57, 0, 0x6400                               // 0000009439D4: D6220039 03FD0139 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009439E0: BF870193
	v_dot2acc_f32_f16 v43, v54, v19                            // 0000009439E4: 04562736
	v_lshl_or_b32 v60, v66, 16, v62                            // 0000009439E8: D656003C 04F92142
	s_delay_alu instid0(VALU_DEP_3)                            // 0000009439F0: BF870003
	v_and_or_b32 v57, 0xffff, v57, v64                         // 0000009439F4: D6570039 050272FF 0000FFFF
	v_and_b32_e32 v64, 0xffff, v67                             // 000000943A00: 368086FF 0000FFFF
	v_sad_u8 v66, v68, 0, 0x6400                               // 000000943A08: D6220042 03FD0144 00006400
	.long 0xd72c003e                                           // 000000943A14: D72C003E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v69, vcc_lo              // 000000943A18: 02028AFF 83DCD12D
	v_pk_fma_f16 v59, v60, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000943A20: CC0E003B 0BFC0B3C 0000C931
	v_pk_fma_f16 v57, v57, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000943A2C: CC0E0039 0BFC0B39 0000C931
	v_dot2acc_f32_f16 v43, v65, v20                            // 000000943A38: 04562941
	v_lshl_or_b32 v60, v66, 16, v64                            // 000000943A3C: D656003C 05012142
	v_mov_b32_e32 v64, v61                                     // 000000943A44: 7E80033D
	.long 0xd72c0037                                           // 000000943A48: D72C0037
	v_cndmask_b32_e32 v1, 0x83dcd12d, v55, vcc_lo              // 000000943A4C: 02026EFF 83DCD12D
	v_dot2acc_f32_f16 v42, v59, v18                            // 000000943A54: 0454253B
	v_sad_u8 v62, v62, 0, 0x6400                               // 000000943A58: D622003E 03FD013E 00006400
	v_pk_fma_f16 v54, v60, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000943A64: CC0E0036 0BFC0B3C 0000C931
	v_and_b32_e32 v65, 0xffff, v56                             // 000000943A70: 368270FF 0000FFFF
	v_pk_fma_f16 v59, v58, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000943A78: CC0E003B 0BFC0B3A 0000C931
	v_dot2acc_f32_f16 v42, v57, v19                            // 000000943A84: 04542739
	.long 0xd73d0039                                           // 000000943A88: D73D0039
	v_cndmask_b32_e32 v1, v45, v63, vcc_lo                     // 000000943A8C: 02027F2D
	v_sad_u8 v55, v55, 0, 0x6400                               // 000000943A90: D6220037 03FD0137 00006400
	v_bfe_u32 v63, v56, 8, 16                                  // 000000943A9C: D610003F 02411138
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000943AA4: BF870224
	v_dual_dot2acc_f32_f16 v43, v59, v21 :: v_dual_dot2acc_f32_f16 v42, v54, v20// 000000943AA8: CB182B3B 2B2A2936
	.long 0xd72c0041                                           // 000000943AB0: D72C0041
	v_cndmask_b32_e32 v1, 0x83dcd12d, v65, vcc_lo              // 000000943AB4: 020282FF 83DCD12D
	v_lshlrev_b32_e32 v55, 16, v55                             // 000000943ABC: 306E6E90
	v_bfe_u32 v54, v57, 12, 16                                 // 000000943AC0: D6100036 02411939
	v_bfe_u32 v58, v57, 8, 16                                  // 000000943AC8: D610003A 02411139
	v_bfe_u32 v59, v57, 4, 16                                  // 000000943AD0: D610003B 02410939
	v_and_b32_e32 v61, 0xffff, v57                             // 000000943AD8: 367A72FF 0000FFFF
	v_and_or_b32 v55, 0xffff, v62, v55                         // 000000943AE0: D6570037 04DE7CFF 0000FFFF
	.long 0xd72c003c                                           // 000000943AEC: D72C003C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v54, vcc_lo              // 000000943AF0: 02026CFF 83DCD12D
	v_bfe_u32 v62, v56, 12, 16                                 // 000000943AF8: D610003E 02411938
	.long 0xd72c0040                                           // 000000943B00: D72C0040
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 000000943B04: 020274FF 83DCD12D
	ds_load_2addr_b32 v[57:58], v50 offset0:128 offset1:160    // 000000943B0C: D8DCA080 39000032
	v_pk_fma_f16 v55, v55, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000943B14: CC0E0037 0BFC0B37 0000C931
	.long 0xd72c003b                                           // 000000943B20: D72C003B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 000000943B24: 020276FF 83DCD12D
	.long 0xd72c003d                                           // 000000943B2C: D72C003D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v61, vcc_lo              // 000000943B30: 02027AFF 83DCD12D
	.long 0xd72c003e                                           // 000000943B38: D72C003E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v62, vcc_lo              // 000000943B3C: 02027CFF 83DCD12D
	v_bfe_u32 v56, v56, 4, 16                                  // 000000943B44: D6100038 02410938
	v_dot2acc_f32_f16 v42, v55, v21                            // 000000943B4C: 04542B37
	ds_load_2addr_b32 v[54:55], v51 offset0:128 offset1:160    // 000000943B50: D8DCA080 36000033
	v_sad_u8 v65, v65, 0, 0x6400                               // 000000943B58: D6220041 03FD0141 00006400
	v_sad_u8 v60, v60, 0, 0x6400                               // 000000943B64: D622003C 03FD013C 00006400
	v_sad_u8 v67, v59, 0, 0x6400                               // 000000943B70: D6220043 03FD013B 00006400
	v_sad_u8 v59, v61, 0, 0x6400                               // 000000943B7C: D622003B 03FD013D 00006400
	v_sad_u8 v61, v62, 0, 0x6400                               // 000000943B88: D622003D 03FD013E 00006400
	.long 0xd72c003e                                           // 000000943B94: D72C003E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v63, vcc_lo              // 000000943B98: 02027EFF 83DCD12D
	.long 0xd72c003f                                           // 000000943BA0: D72C003F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v56, vcc_lo              // 000000943BA4: 020270FF 83DCD12D
	v_sad_u8 v64, v64, 0, 0x6400                               // 000000943BAC: D6220040 03FD0140 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000943BB8: BF870144
	v_dual_dot2acc_f32_f16 v28, v70, v20 :: v_dual_and_b32 v61, 0xffff, v61// 000000943BBC: CB242946 1C3C7AFF 0000FFFF
	s_waitcnt lgkmcnt(0)                                       // 000000943BC8: BF89FC07
	v_mov_b32_e32 v56, v54                                     // 000000943BCC: 7E700336
	v_lshlrev_b32_e32 v54, 16, v59                             // 000000943BD0: 306C7690
	.long 0xd73d0038                                           // 000000943BD4: D73D0038
	v_cndmask_b32_e32 v1, v45, v56, vcc_lo                     // 000000943BD8: 0202712D
	v_sad_u8 v57, v62, 0, 0x6400                               // 000000943BDC: D6220039 03FD013E 00006400
	v_sad_u8 v62, v63, 0, 0x6400                               // 000000943BE8: D622003E 03FD013F 00006400
	v_lshlrev_b32_e32 v63, 16, v65                             // 000000943BF4: 307E8290
	v_and_or_b32 v54, 0xffff, v67, v54                         // 000000943BF8: D6570036 04DA86FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000943C04: BF870224
	v_lshl_or_b32 v57, v57, 16, v61                            // 000000943C08: D6560039 04F52139
	v_bfe_u32 v65, v56, 12, 16                                 // 000000943C10: D6100041 02411938
	v_and_or_b32 v61, 0xffff, v62, v63                         // 000000943C18: D657003D 04FE7CFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000943C24: BF870214
	v_pk_fma_f16 v54, v54, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000943C28: CC0E0036 0BFC0B36 0000C931
	v_pk_fma_f16 v57, v57, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000943C34: CC0E0039 0BFC0B39 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000943C40: BF870214
	.long 0xd72c003f                                           // 000000943C44: D72C003F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v65, vcc_lo              // 000000943C48: 020282FF 83DCD12D
	v_pk_fma_f16 v61, v61, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000943C50: CC0E003D 0BFC0B3D 0000C931
	v_and_b32_e32 v66, 0xffff, v60                             // 000000943C5C: 368478FF 0000FFFF
	ds_load_2addr_b32 v[59:60], v48 offset0:128 offset1:160    // 000000943C64: D8DCA080 3B000030
	v_lshl_or_b32 v64, v64, 16, v66                            // 000000943C6C: D6560040 05092140
	v_sad_u8 v63, v63, 0, 0x6400                               // 000000943C74: D622003F 03FD013F 00006400
	v_dot2acc_f32_f16 v28, v71, v21                            // 000000943C80: 04382B47
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000943C84: BF870223
	v_pk_fma_f16 v62, v64, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000943C88: CC0E003E 0BFC0B40 0000C931
	v_and_b32_e32 v64, 0xffff, v56                             // 000000943C94: 368070FF 0000FFFF
	v_and_b32_e32 v63, 0xffff, v63                             // 000000943C9C: 367E7EFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000943CA4: BF870243
	v_dot2acc_f32_f16 v41, v62, v18                            // 000000943CA8: 0452253E
	v_bfe_u32 v62, v56, 8, 16                                  // 000000943CAC: D610003E 02411138
	v_bfe_u32 v56, v56, 4, 16                                  // 000000943CB4: D6100038 02410938
	.long 0xd72c0040                                           // 000000943CBC: D72C0040
	v_cndmask_b32_e32 v1, 0x83dcd12d, v64, vcc_lo              // 000000943CC0: 020280FF 83DCD12D
	v_dot2acc_f32_f16 v41, v54, v19                            // 000000943CC8: 04522736
	s_delay_alu instid0(VALU_DEP_4)                            // 000000943CCC: BF870004
	.long 0xd72c003e                                           // 000000943CD0: D72C003E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v62, vcc_lo              // 000000943CD4: 02027CFF 83DCD12D
	s_waitcnt lgkmcnt(0)                                       // 000000943CDC: BF89FC07
	v_bfe_u32 v65, v59, 12, 16                                 // 000000943CE0: D6100041 0241193B
	v_bfe_u32 v54, v59, 8, 16                                  // 000000943CE8: D6100036 0241113B
	.long 0xd72c0038                                           // 000000943CF0: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v56, vcc_lo              // 000000943CF4: 020270FF 83DCD12D
	v_bfe_u32 v66, v59, 4, 16                                  // 000000943CFC: D6100042 0241093B
	v_and_b32_e32 v59, 0xffff, v59                             // 000000943D04: 367676FF 0000FFFF
	.long 0xd72c0041                                           // 000000943D0C: D72C0041
	v_cndmask_b32_e32 v1, 0x83dcd12d, v65, vcc_lo              // 000000943D10: 020282FF 83DCD12D
	.long 0xd72c0036                                           // 000000943D18: D72C0036
	v_cndmask_b32_e32 v1, 0x83dcd12d, v54, vcc_lo              // 000000943D1C: 02026CFF 83DCD12D
	v_sad_u8 v62, v62, 0, 0x6400                               // 000000943D24: D622003E 03FD013E 00006400
	v_sad_u8 v64, v64, 0, 0x6400                               // 000000943D30: D6220040 03FD0140 00006400
	v_dot2acc_f32_f16 v41, v57, v20                            // 000000943D3C: 04522939
	v_bfe_u32 v68, v60, 4, 16                                  // 000000943D40: D6100044 0241093C
	s_delay_alu instid0(VALU_DEP_4)                            // 000000943D48: BF870004
	v_lshl_or_b32 v62, v62, 16, v63                            // 000000943D4C: D656003E 04FD213E
	v_sad_u8 v63, v56, 0, 0x6400                               // 000000943D54: D622003F 03FD0138 00006400
	v_mov_b32_e32 v56, v58                                     // 000000943D60: 7E70033A
	.long 0xd72c003a                                           // 000000943D64: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 000000943D68: 020276FF 83DCD12D
	v_sad_u8 v65, v65, 0, 0x6400                               // 000000943D70: D6220041 03FD0141 00006400
	v_sad_u8 v59, v54, 0, 0x6400                               // 000000943D7C: D622003B 03FD0136 00006400
	v_lshlrev_b32_e32 v64, 16, v64                             // 000000943D88: 30808090
	.long 0xd73d0036                                           // 000000943D8C: D73D0036
	v_cndmask_b32_e32 v1, v45, v55, vcc_lo                     // 000000943D90: 02026F2D
	v_pk_fma_f16 v56, v62, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000943D94: CC0E0038 0BFC0B3E 0000C931
	v_and_b32_e32 v65, 0xffff, v65                             // 000000943DA0: 368282FF 0000FFFF
	.long 0xd72c0044                                           // 000000943DA8: D72C0044
	v_cndmask_b32_e32 v1, 0x83dcd12d, v68, vcc_lo              // 000000943DAC: 020288FF 83DCD12D
	v_sad_u8 v57, v58, 0, 0x6400                               // 000000943DB4: D6220039 03FD013A 00006400
	v_and_or_b32 v63, 0xffff, v63, v64                         // 000000943DC0: D657003F 05027EFF 0000FFFF
	v_bfe_u32 v58, v54, 12, 16                                 // 000000943DCC: D610003A 02411936
	v_dot2acc_f32_f16 v40, v56, v18                            // 000000943DD4: 04502538
	v_lshl_or_b32 v55, v59, 16, v65                            // 000000943DD8: D6560037 0505213B
	v_lshlrev_b32_e32 v65, 16, v57                             // 000000943DE0: 30827290
	v_pk_fma_f16 v62, v63, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000943DE4: CC0E003E 0BFC0B3F 0000C931
	.long 0xd72c0039                                           // 000000943DF0: D72C0039
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 000000943DF4: 020274FF 83DCD12D
	v_bfe_u32 v58, v54, 8, 16                                  // 000000943DFC: D610003A 02411136
	v_pk_fma_f16 v63, v55, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000943E04: CC0E003F 0BFC0B37 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000943E10: BF870224
	v_dual_dot2acc_f32_f16 v40, v62, v19 :: v_dual_and_b32 v55, 0xffff, v54// 000000943E14: CB24273E 28366CFF 0000FFFF
	v_bfe_u32 v54, v54, 4, 16                                  // 000000943E20: D6100036 02410936
	.long 0xd72c003a                                           // 000000943E28: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 000000943E2C: 020274FF 83DCD12D
	.long 0xd72c0040                                           // 000000943E34: D72C0040
	v_cndmask_b32_e32 v1, 0x83dcd12d, v66, vcc_lo              // 000000943E38: 020284FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4)                            // 000000943E40: BF870004
	.long 0xd72c0043                                           // 000000943E44: D72C0043
	v_cndmask_b32_e32 v1, 0x83dcd12d, v55, vcc_lo              // 000000943E48: 02026EFF 83DCD12D
	v_sad_u8 v57, v57, 0, 0x6400                               // 000000943E50: D6220039 03FD0139 00006400
	.long 0xd72c0045                                           // 000000943E5C: D72C0045
	v_cndmask_b32_e32 v1, 0x83dcd12d, v54, vcc_lo              // 000000943E60: 02026CFF 83DCD12D
	ds_load_2addr_b32 v[54:55], v51 offset0:192 offset1:224    // 000000943E68: D8DCE0C0 36000033
	v_bfe_u32 v59, v60, 12, 16                                 // 000000943E70: D610003B 0241193C
	v_bfe_u32 v66, v60, 8, 16                                  // 000000943E78: D6100042 0241113C
	v_and_b32_e32 v70, 0xffff, v57                             // 000000943E80: 368C72FF 0000FFFF
	v_sad_u8 v71, v58, 0, 0x6400                               // 000000943E88: D6220047 03FD013A 00006400
	ds_load_2addr_b32 v[57:58], v50 offset0:192 offset1:224    // 000000943E94: D8DCE0C0 39000032
	v_sad_u8 v67, v67, 0, 0x6400                               // 000000943E9C: D6220043 03FD0143 00006400
	v_sad_u8 v69, v69, 0, 0x6400                               // 000000943EA8: D6220045 03FD0145 00006400
	v_and_b32_e32 v60, 0xffff, v60                             // 000000943EB4: 367878FF 0000FFFF
	v_lshl_or_b32 v56, v71, 16, v70                            // 000000943EBC: D6560038 05192147
	.long 0xd72c003b                                           // 000000943EC4: D72C003B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 000000943EC8: 020276FF 83DCD12D
	v_dual_dot2acc_f32_f16 v40, v63, v20 :: v_dual_lshlrev_b32 v67, 16, v67// 000000943ED0: CB22293F 28428690
	v_sad_u8 v64, v64, 0, 0x6400                               // 000000943ED8: D6220040 03FD0140 00006400
	.long 0xd72c0042                                           // 000000943EE4: D72C0042
	v_cndmask_b32_e32 v1, 0x83dcd12d, v66, vcc_lo              // 000000943EE8: 020284FF 83DCD12D
	.long 0xd72c003c                                           // 000000943EF0: D72C003C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v60, vcc_lo              // 000000943EF4: 020278FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4)                            // 000000943EFC: BF870004
	v_and_or_b32 v67, 0xffff, v69, v67                         // 000000943F00: D6570043 050E8AFF 0000FFFF
	v_pk_fma_f16 v69, v56, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000943F0C: CC0E0045 0BFC0B38 0000C931
	v_sad_u8 v59, v59, 0, 0x6400                               // 000000943F18: D622003B 03FD013B 00006400
	s_waitcnt lgkmcnt(1)                                       // 000000943F24: BF89FC17
	v_dual_dot2acc_f32_f16 v41, v61, v21 :: v_dual_mov_b32 v56, v54// 000000943F28: CB102B3D 29380136
	v_pk_fma_f16 v67, v67, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000943F30: CC0E0043 0BFC0B43 0000C931
	v_sad_u8 v66, v66, 0, 0x6400                               // 000000943F3C: D6220042 03FD0142 00006400
	v_sad_u8 v60, v60, 0, 0x6400                               // 000000943F48: D622003C 03FD013C 00006400
	v_dot2acc_f32_f16 v39, v69, v18                            // 000000943F54: 044E2545
	s_waitcnt lgkmcnt(0)                                       // 000000943F58: BF89FC07
	.long 0xd73d0038                                           // 000000943F5C: D73D0038
	v_cndmask_b32_e32 v1, v45, v56, vcc_lo                     // 000000943F60: 0202712D
	v_and_or_b32 v57, 0xffff, v64, v65                         // 000000943F64: D6570039 050680FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000943F70: BF870113
	v_dot2acc_f32_f16 v39, v67, v19                            // 000000943F74: 044E2743
	v_pk_fma_f16 v57, v57, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000943F78: CC0E0039 0BFC0B39 0000C931
	v_and_b32_e32 v59, 0xffff, v59                             // 000000943F84: 367676FF 0000FFFF
	v_bfe_u32 v64, v56, 12, 16                                 // 000000943F8C: D6100040 02411938
	v_bfe_u32 v63, v56, 8, 16                                  // 000000943F94: D610003F 02411138
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000943F9C: BF870214
	v_dot2acc_f32_f16 v40, v57, v21                            // 000000943FA0: 04502B39
	v_lshl_or_b32 v54, v66, 16, v59                            // 000000943FA4: D6560036 04ED2142
	v_sad_u8 v66, v68, 0, 0x6400                               // 000000943FAC: D6220042 03FD0144 00006400
	v_lshlrev_b32_e32 v68, 16, v60                             // 000000943FB8: 30887890
	ds_load_2addr_b32 v[59:60], v48 offset0:192 offset1:224    // 000000943FBC: D8DCE0C0 3B000030
	v_bfe_u32 v57, v56, 4, 16                                  // 000000943FC4: D6100039 02410938
	v_pk_fma_f16 v54, v54, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000943FCC: CC0E0036 0BFC0B36 0000C931
	v_and_b32_e32 v56, 0xffff, v56                             // 000000943FD8: 367070FF 0000FFFF
	v_and_or_b32 v62, 0xffff, v66, v68                         // 000000943FE0: D657003E 051284FF 0000FFFF
	.long 0xd72c003d                                           // 000000943FEC: D72C003D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v63, vcc_lo              // 000000943FF0: 02027EFF 83DCD12D
	.long 0xd72c0039                                           // 000000943FF8: D72C0039
	v_cndmask_b32_e32 v1, 0x83dcd12d, v57, vcc_lo              // 000000943FFC: 020272FF 83DCD12D
	v_dot2acc_f32_f16 v39, v54, v20                            // 000000944004: 044E2936
	.long 0xd72c0036                                           // 000000944008: D72C0036
	v_cndmask_b32_e32 v1, 0x83dcd12d, v64, vcc_lo              // 00000094400C: 020280FF 83DCD12D
	v_pk_fma_f16 v62, v62, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000944014: CC0E003E 0BFC0B3E 0000C931
	.long 0xd72c0038                                           // 000000944020: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v56, vcc_lo              // 000000944024: 020270FF 83DCD12D
	v_sad_u8 v61, v61, 0, 0x6400                               // 00000094402C: D622003D 03FD013D 00006400
	s_delay_alu instid0(VALU_DEP_3)                            // 000000944038: BF870003
	v_dot2acc_f32_f16 v39, v62, v21                            // 00000094403C: 044E2B3E
	v_sad_u8 v57, v57, 0, 0x6400                               // 000000944040: D6220039 03FD0139 00006400
	v_sad_u8 v54, v54, 0, 0x6400                               // 00000094404C: D6220036 03FD0136 00006400
	v_sad_u8 v65, v56, 0, 0x6400                               // 000000944058: D6220041 03FD0138 00006400
	v_mov_b32_e32 v56, v58                                     // 000000944064: 7E70033A
	s_waitcnt lgkmcnt(0)                                       // 000000944068: BF89FC07
	v_bfe_u32 v62, v59, 12, 16                                 // 00000094406C: D610003E 0241193B
	v_and_b32_e32 v64, 0xffff, v59                             // 000000944074: 368076FF 0000FFFF
	v_bfe_u32 v63, v59, 8, 16                                  // 00000094407C: D610003F 0241113B
	v_bfe_u32 v59, v59, 4, 16                                  // 000000944084: D610003B 0241093B
	v_and_b32_e32 v54, 0xffff, v54                             // 00000094408C: 366C6CFF 0000FFFF
	.long 0xd72c003e                                           // 000000944094: D72C003E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v62, vcc_lo              // 000000944098: 02027CFF 83DCD12D
	.long 0xd72c0040                                           // 0000009440A0: D72C0040
	v_cndmask_b32_e32 v1, 0x83dcd12d, v64, vcc_lo              // 0000009440A4: 020280FF 83DCD12D
	.long 0xd72c003f                                           // 0000009440AC: D72C003F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v63, vcc_lo              // 0000009440B0: 02027EFF 83DCD12D
	.long 0xd72c003a                                           // 0000009440B8: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 0000009440BC: 020276FF 83DCD12D
	v_lshl_or_b32 v61, v61, 16, v54                            // 0000009440C4: D656003D 04D9213D
	.long 0xd73d0036                                           // 0000009440CC: D73D0036
	v_cndmask_b32_e32 v1, v45, v55, vcc_lo                     // 0000009440D0: 02026F2D
	v_lshlrev_b32_e32 v55, 16, v65                             // 0000009440D4: 306E8290
	v_bfe_u32 v66, v60, 8, 16                                  // 0000009440D8: D6100042 0241113C
	v_sad_u8 v59, v62, 0, 0x6400                               // 0000009440E0: D622003B 03FD013E 00006400
	v_sad_u8 v62, v64, 0, 0x6400                               // 0000009440EC: D622003E 03FD0140 00006400
	v_pk_fma_f16 v61, v61, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009440F8: CC0E003D 0BFC0B3D 0000C931
	v_sad_u8 v58, v58, 0, 0x6400                               // 000000944104: D622003A 03FD013A 00006400
	v_and_or_b32 v55, 0xffff, v57, v55                         // 000000944110: D6570037 04DE72FF 0000FFFF
	v_and_b32_e32 v56, 0xffff, v59                             // 00000094411C: 367076FF 0000FFFF
	v_sad_u8 v59, v63, 0, 0x6400                               // 000000944124: D622003B 03FD013F 00006400
	v_lshlrev_b32_e32 v62, 16, v62                             // 000000944130: 307C7C90
	v_bfe_u32 v63, v54, 12, 16                                 // 000000944134: D610003F 02411936
	v_and_b32_e32 v68, 0xffff, v60                             // 00000094413C: 368878FF 0000FFFF
	.long 0xd72c0042                                           // 000000944144: D72C0042
	v_cndmask_b32_e32 v1, 0x83dcd12d, v66, vcc_lo              // 000000944148: 020284FF 83DCD12D
	v_lshl_or_b32 v56, v59, 16, v56                            // 000000944150: D6560038 04E1213B
	v_and_or_b32 v57, 0xffff, v58, v62                         // 000000944158: D6570039 04FA74FF 0000FFFF
	.long 0xd72c003a                                           // 000000944164: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v63, vcc_lo              // 000000944168: 02027EFF 83DCD12D
	v_pk_fma_f16 v62, v55, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000944170: CC0E003E 0BFC0B37 0000C931
	v_and_b32_e32 v55, 0xffff, v54                             // 00000094417C: 366E6CFF 0000FFFF
	v_bfe_u32 v59, v54, 8, 16                                  // 000000944184: D610003B 02411136
	v_pk_fma_f16 v64, v57, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000094418C: CC0E0040 0BFC0B39 0000C931
	v_pk_fma_f16 v63, v56, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000944198: CC0E003F 0BFC0B38 0000C931
	v_sad_u8 v66, v66, 0, 0x6400                               // 0000009441A4: D6220042 03FD0142 00006400
	v_sad_u8 v57, v58, 0, 0x6400                               // 0000009441B0: D6220039 03FD013A 00006400
	v_dot2acc_f32_f16 v38, v61, v18                            // 0000009441BC: 044C253D
	v_bfe_u32 v58, v54, 4, 16                                  // 0000009441C0: D610003A 02410936
	.long 0xd72c003d                                           // 0000009441C8: D72C003D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v55, vcc_lo              // 0000009441CC: 02026EFF 83DCD12D
	ds_load_2addr_b32 v[54:55], v53 offset1:32                 // 0000009441D4: D8DC2000 36000035
	.long 0xd72c0038                                           // 0000009441DC: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 0000009441E0: 020276FF 83DCD12D
	v_and_b32_e32 v65, 0xffff, v57                             // 0000009441E8: 368272FF 0000FFFF
	.long 0xd72c0043                                           // 0000009441F0: D72C0043
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 0000009441F4: 020274FF 83DCD12D
	ds_load_2addr_b32 v[57:58], v52 offset1:32                 // 0000009441FC: D8DC2000 39000034
	v_bfe_u32 v59, v60, 12, 16                                 // 000000944204: D610003B 0241193C
	v_bfe_u32 v60, v60, 4, 16                                  // 00000094420C: D610003C 0241093C
	v_sad_u8 v61, v61, 0, 0x6400                               // 000000944214: D622003D 03FD013D 00006400
	v_dot2acc_f32_f16 v38, v62, v19                            // 000000944220: 044C273E
	v_sad_u8 v56, v56, 0, 0x6400                               // 000000944224: D6220038 03FD0138 00006400
	.long 0xd72c003b                                           // 000000944230: D72C003B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 000000944234: 020276FF 83DCD12D
	.long 0xd72c0045                                           // 00000094423C: D72C0045
	v_cndmask_b32_e32 v1, 0x83dcd12d, v60, vcc_lo              // 000000944240: 020278FF 83DCD12D
	v_sad_u8 v67, v67, 0, 0x6400                               // 000000944248: D6220043 03FD0143 00006400
	v_lshlrev_b32_e32 v61, 16, v61                             // 000000944254: 307A7A90
	v_lshl_or_b32 v56, v56, 16, v65                            // 000000944258: D6560038 05052138
	.long 0xd72c0041                                           // 000000944260: D72C0041
	v_cndmask_b32_e32 v1, 0x83dcd12d, v68, vcc_lo              // 000000944264: 020288FF 83DCD12D
	v_dot2acc_f32_f16 v38, v63, v20                            // 00000094426C: 044C293F
	v_sad_u8 v70, v59, 0, 0x6400                               // 000000944270: D6220046 03FD013B 00006400
	ds_load_2addr_b32 v[59:60], v49 offset1:32                 // 00000094427C: D8DC2000 3B000031
	v_pk_fma_f16 v68, v56, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000944284: CC0E0044 0BFC0B38 0000C931
	s_waitcnt lgkmcnt(2)                                       // 000000944290: BF89FC27
	v_mov_b32_e32 v56, v54                                     // 000000944294: 7E700336
	v_and_or_b32 v61, 0xffff, v67, v61                         // 000000944298: D657003D 04F686FF 0000FFFF
	v_and_b32_e32 v54, 0xffff, v70                             // 0000009442A4: 366C8CFF 0000FFFF
	v_sad_u8 v65, v65, 0, 0x6400                               // 0000009442AC: D6220041 03FD0141 00006400
	v_dot2acc_f32_f16 v37, v68, v18                            // 0000009442B8: 044A2544
	s_waitcnt lgkmcnt(1)                                       // 0000009442BC: BF89FC17
	.long 0xd73d0038                                           // 0000009442C0: D73D0038
	v_cndmask_b32_e32 v1, v45, v56, vcc_lo                     // 0000009442C4: 0202712D
	v_pk_fma_f16 v57, v61, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009442C8: CC0E0039 0BFC0B3D 0000C931
	v_lshl_or_b32 v54, v66, 16, v54                            // 0000009442D4: D6560036 04D92142
	v_sad_u8 v67, v69, 0, 0x6400                               // 0000009442DC: D6220043 03FD0145 00006400
	v_lshlrev_b32_e32 v65, 16, v65                             // 0000009442E8: 30828290
	v_bfe_u32 v62, v56, 12, 16                                 // 0000009442EC: D610003E 02411938
	s_delay_alu instid0(VALU_DEP_4)                            // 0000009442F4: BF870004
	v_pk_fma_f16 v63, v54, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009442F8: CC0E003F 0BFC0B36 0000C931
	v_dot2acc_f32_f16 v37, v57, v19                            // 000000944304: 044A2739
	v_bfe_u32 v57, v56, 8, 16                                  // 000000944308: D6100039 02411138
	v_and_or_b32 v61, 0xffff, v67, v65                         // 000000944310: D657003D 050686FF 0000FFFF
	.long 0xd72c0036                                           // 00000094431C: D72C0036
	v_cndmask_b32_e32 v1, 0x83dcd12d, v62, vcc_lo              // 000000944320: 02027CFF 83DCD12D
	v_and_b32_e32 v62, 0xffff, v56                             // 000000944328: 367C70FF 0000FFFF
	v_bfe_u32 v56, v56, 4, 16                                  // 000000944330: D6100038 02410938
	s_waitcnt lgkmcnt(0)                                       // 000000944338: BF89FC07
	v_bfe_u32 v65, v59, 12, 16                                 // 00000094433C: D6100041 0241193B
	.long 0xd72c0039                                           // 000000944344: D72C0039
	v_cndmask_b32_e32 v1, 0x83dcd12d, v57, vcc_lo              // 000000944348: 020272FF 83DCD12D
	v_bfe_u32 v66, v59, 8, 16                                  // 000000944350: D6100042 0241113B
	.long 0xd72c003e                                           // 000000944358: D72C003E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v62, vcc_lo              // 00000094435C: 02027CFF 83DCD12D
	.long 0xd72c0038                                           // 000000944364: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v56, vcc_lo              // 000000944368: 020270FF 83DCD12D
	.long 0xd72c0041                                           // 000000944370: D72C0041
	v_cndmask_b32_e32 v1, 0x83dcd12d, v65, vcc_lo              // 000000944374: 020282FF 83DCD12D
	v_sad_u8 v54, v54, 0, 0x6400                               // 00000094437C: D6220036 03FD0136 00006400
	v_bfe_u32 v67, v59, 4, 16                                  // 000000944388: D6100043 0241093B
	v_and_b32_e32 v59, 0xffff, v59                             // 000000944390: 367676FF 0000FFFF
	.long 0xd72c0042                                           // 000000944398: D72C0042
	v_cndmask_b32_e32 v1, 0x83dcd12d, v66, vcc_lo              // 00000094439C: 020284FF 83DCD12D
	v_sad_u8 v57, v57, 0, 0x6400                               // 0000009443A4: D6220039 03FD0139 00006400
	v_sad_u8 v62, v62, 0, 0x6400                               // 0000009443B0: D622003E 03FD013E 00006400
	v_and_b32_e32 v54, 0xffff, v54                             // 0000009443BC: 366C6CFF 0000FFFF
	v_sad_u8 v68, v56, 0, 0x6400                               // 0000009443C4: D6220044 03FD0138 00006400
	v_mov_b32_e32 v56, v58                                     // 0000009443D0: 7E70033A
	.long 0xd72c003b                                           // 0000009443D4: D72C003B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 0000009443D8: 020276FF 83DCD12D
	v_sad_u8 v65, v65, 0, 0x6400                               // 0000009443E0: D6220041 03FD0141 00006400
	v_lshlrev_b32_e32 v62, 16, v62                             // 0000009443EC: 307C7C90
	.long 0xd72c0043                                           // 0000009443F0: D72C0043
	v_cndmask_b32_e32 v1, 0x83dcd12d, v67, vcc_lo              // 0000009443F4: 020286FF 83DCD12D
	v_lshl_or_b32 v57, v57, 16, v54                            // 0000009443FC: D6560039 04D92139
	.long 0xd73d0036                                           // 000000944404: D73D0036
	v_cndmask_b32_e32 v1, v45, v55, vcc_lo                     // 000000944408: 02026F2D
	v_and_b32_e32 v58, 0xffff, v65                             // 00000094440C: 367482FF 0000FFFF
	v_sad_u8 v65, v66, 0, 0x6400                               // 000000944414: D6220041 03FD0142 00006400
	v_sad_u8 v59, v59, 0, 0x6400                               // 000000944420: D622003B 03FD013B 00006400
	v_and_or_b32 v55, 0xffff, v68, v62                         // 00000094442C: D6570037 04FA88FF 0000FFFF
	v_pk_fma_f16 v62, v57, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000944438: CC0E003E 0BFC0B39 0000C931
	v_bfe_u32 v57, v54, 12, 16                                 // 000000944444: D6100039 02411936
	v_lshl_or_b32 v56, v65, 16, v58                            // 00000094444C: D6560038 04E92141
	v_sad_u8 v58, v67, 0, 0x6400                               // 000000944454: D622003A 03FD0143 00006400
	s_delay_alu instid0(VALU_DEP_4)                            // 000000944460: BF870004
	v_dual_dot2acc_f32_f16 v36, v62, v18 :: v_dual_lshlrev_b32 v59, 16, v59// 000000944464: CB22253E 243A7690
	v_pk_fma_f16 v65, v55, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000094446C: CC0E0041 0BFC0B37 0000C931
	v_and_b32_e32 v55, 0xffff, v54                             // 000000944478: 366E6CFF 0000FFFF
	v_pk_fma_f16 v66, v56, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000944480: CC0E0042 0BFC0B38 0000C931
	.long 0xd72c0038                                           // 00000094448C: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v57, vcc_lo              // 000000944490: 020272FF 83DCD12D
	v_bfe_u32 v57, v54, 8, 16                                  // 000000944498: D6100039 02411136
	v_bfe_u32 v54, v54, 4, 16                                  // 0000009444A0: D6100036 02410936
	v_and_or_b32 v67, 0xffff, v58, v59                         // 0000009444A8: D6570043 04EE74FF 0000FFFF
	v_bfe_u32 v58, v60, 12, 16                                 // 0000009444B4: D610003A 0241193C
	.long 0xd72c0037                                           // 0000009444BC: D72C0037
	v_cndmask_b32_e32 v1, 0x83dcd12d, v55, vcc_lo              // 0000009444C0: 02026EFF 83DCD12D
	v_bfe_u32 v59, v60, 8, 16                                  // 0000009444C8: D610003B 0241113C
	.long 0xd72c0036                                           // 0000009444D0: D72C0036
	v_cndmask_b32_e32 v1, 0x83dcd12d, v54, vcc_lo              // 0000009444D4: 02026CFF 83DCD12D
	.long 0xd72c0039                                           // 0000009444DC: D72C0039
	v_cndmask_b32_e32 v1, 0x83dcd12d, v57, vcc_lo              // 0000009444E0: 020272FF 83DCD12D
	v_bfe_u32 v68, v60, 4, 16                                  // 0000009444E8: D6100044 0241093C
	v_and_b32_e32 v60, 0xffff, v60                             // 0000009444F0: 367878FF 0000FFFF
	.long 0xd72c003a                                           // 0000009444F8: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 0000009444FC: 020274FF 83DCD12D
	v_sad_u8 v56, v56, 0, 0x6400                               // 000000944504: D6220038 03FD0138 00006400
	v_sad_u8 v69, v55, 0, 0x6400                               // 000000944510: D6220045 03FD0137 00006400
	.long 0xd72c003b                                           // 00000094451C: D72C003B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 000000944520: 020276FF 83DCD12D
	.long 0xd72c003c                                           // 000000944528: D72C003C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v60, vcc_lo              // 00000094452C: 020278FF 83DCD12D
	v_sad_u8 v71, v54, 0, 0x6400                               // 000000944534: D6220047 03FD0136 00006400
	ds_load_2addr_b32 v[54:55], v53 offset0:64 offset1:96      // 000000944540: D8DC6040 36000035
	v_and_b32_e32 v56, 0xffff, v56                             // 000000944548: 367070FF 0000FFFF
	v_sad_u8 v70, v57, 0, 0x6400                               // 000000944550: D6220046 03FD0139 00006400
	v_dual_dot2acc_f32_f16 v36, v65, v19 :: v_dual_lshlrev_b32 v69, 16, v69// 00000094455C: CB222741 24448A90
	v_sad_u8 v72, v58, 0, 0x6400                               // 000000944564: D6220048 03FD013A 00006400
	ds_load_2addr_b32 v[57:58], v52 offset0:64 offset1:96      // 000000944570: D8DC6040 39000034
	v_lshl_or_b32 v56, v70, 16, v56                            // 000000944578: D6560038 04E12146
	v_and_or_b32 v69, 0xffff, v71, v69                         // 000000944580: D6570045 05168EFF 0000FFFF
	v_sad_u8 v59, v59, 0, 0x6400                               // 00000094458C: D622003B 03FD013B 00006400
	v_and_b32_e32 v70, 0xffff, v72                             // 000000944598: 368C90FF 0000FFFF
	v_sad_u8 v60, v60, 0, 0x6400                               // 0000009445A0: D622003C 03FD013C 00006400
	.long 0xd72c0044                                           // 0000009445AC: D72C0044
	v_cndmask_b32_e32 v1, 0x83dcd12d, v68, vcc_lo              // 0000009445B0: 020288FF 83DCD12D
	v_pk_fma_f16 v62, v69, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009445B8: CC0E003E 0BFC0B45 0000C931
	v_pk_fma_f16 v56, v56, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009445C4: CC0E0038 0BFC0B38 0000C931
	v_lshl_or_b32 v69, v59, 16, v70                            // 0000009445D0: D6560045 0519213B
	v_lshlrev_b32_e32 v70, 16, v60                             // 0000009445D8: 308C7890
	ds_load_2addr_b32 v[59:60], v49 offset0:64 offset1:96      // 0000009445DC: D8DC6040 3B000031
	v_pk_fma_f16 v61, v61, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009445E4: CC0E003D 0BFC0B3D 0000C931
	s_waitcnt lgkmcnt(2)                                       // 0000009445F0: BF89FC27
	v_dual_dot2acc_f32_f16 v35, v56, v18 :: v_dual_mov_b32 v56, v54// 0000009445F4: CB102538 23380136
	v_sad_u8 v68, v68, 0, 0x6400                               // 0000009445FC: D6220044 03FD0144 00006400
	v_pk_fma_f16 v54, v69, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000944608: CC0E0036 0BFC0B45 0000C931
	v_dot2acc_f32_f16 v37, v63, v20                            // 000000944614: 044A293F
	s_delay_alu instid0(VALU_DEP_4)                            // 000000944618: BF870004
	v_dot2acc_f32_f16 v35, v62, v19                            // 00000094461C: 0446273E
	v_dot2acc_f32_f16 v36, v66, v20                            // 000000944620: 04482942
	s_waitcnt lgkmcnt(1)                                       // 000000944624: BF89FC17
	.long 0xd73d0038                                           // 000000944628: D73D0038
	v_cndmask_b32_e32 v1, v45, v56, vcc_lo                     // 00000094462C: 0202712D
	v_and_or_b32 v65, 0xffff, v68, v70                         // 000000944630: D6570041 051A88FF 0000FFFF
	v_pk_fma_f16 v57, v67, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000094463C: CC0E0039 0BFC0B43 0000C931
	v_dual_dot2acc_f32_f16 v35, v54, v20 :: v_dual_dot2acc_f32_f16 v38, v64, v21// 000000944648: CB182936 23262B40
	v_dot2acc_f32_f16 v37, v61, v21                            // 000000944650: 044A2B3D
	s_delay_alu instid0(VALU_DEP_4)                            // 000000944654: BF870004
	v_pk_fma_f16 v62, v65, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000944658: CC0E003E 0BFC0B41 0000C931
	v_bfe_u32 v54, v56, 12, 16                                 // 000000944664: D6100036 02411938
	s_waitcnt lgkmcnt(0)                                       // 00000094466C: BF89FC07
	v_bfe_u32 v61, v59, 12, 16                                 // 000000944670: D610003D 0241193B
	v_bfe_u32 v63, v59, 8, 16                                  // 000000944678: D610003F 0241113B
	v_bfe_u32 v64, v59, 4, 16                                  // 000000944680: D6100040 0241093B
	v_dual_dot2acc_f32_f16 v36, v57, v21 :: v_dual_and_b32 v59, 0xffff, v59// 000000944688: CB242B39 243A76FF 0000FFFF
	v_and_b32_e32 v57, 0xffff, v56                             // 000000944694: 367270FF 0000FFFF
	v_dot2acc_f32_f16 v35, v62, v21                            // 00000094469C: 04462B3E
	.long 0xd72c0036                                           // 0000009446A0: D72C0036
	v_cndmask_b32_e32 v1, 0x83dcd12d, v54, vcc_lo              // 0000009446A4: 02026CFF 83DCD12D
	v_bfe_u32 v62, v56, 8, 16                                  // 0000009446AC: D610003E 02411138
	v_bfe_u32 v56, v56, 4, 16                                  // 0000009446B4: D6100038 02410938
	.long 0xd72c0039                                           // 0000009446BC: D72C0039
	v_cndmask_b32_e32 v1, 0x83dcd12d, v57, vcc_lo              // 0000009446C0: 020272FF 83DCD12D
	.long 0xd72c003d                                           // 0000009446C8: D72C003D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v61, vcc_lo              // 0000009446CC: 02027AFF 83DCD12D
	.long 0xd72c003f                                           // 0000009446D4: D72C003F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v63, vcc_lo              // 0000009446D8: 02027EFF 83DCD12D
	.long 0xd72c003e                                           // 0000009446E0: D72C003E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v62, vcc_lo              // 0000009446E4: 02027CFF 83DCD12D
	.long 0xd72c0038                                           // 0000009446EC: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v56, vcc_lo              // 0000009446F0: 020270FF 83DCD12D
	v_sad_u8 v54, v54, 0, 0x6400                               // 0000009446F8: D6220036 03FD0136 00006400
	.long 0xd72c003b                                           // 000000944704: D72C003B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 000000944708: 020276FF 83DCD12D
	.long 0xd72c0040                                           // 000000944710: D72C0040
	v_cndmask_b32_e32 v1, 0x83dcd12d, v64, vcc_lo              // 000000944714: 020280FF 83DCD12D
	v_sad_u8 v57, v57, 0, 0x6400                               // 00000094471C: D6220039 03FD0139 00006400
	v_sad_u8 v61, v61, 0, 0x6400                               // 000000944728: D622003D 03FD013D 00006400
	v_and_b32_e32 v54, 0xffff, v54                             // 000000944734: 366C6CFF 0000FFFF
	v_sad_u8 v62, v62, 0, 0x6400                               // 00000094473C: D622003E 03FD013E 00006400
	v_sad_u8 v65, v56, 0, 0x6400                               // 000000944748: D6220041 03FD0138 00006400
	v_dual_mov_b32 v56, v58 :: v_dual_lshlrev_b32 v57, 16, v57 // 000000944754: CA22013A 38387290
	v_and_b32_e32 v61, 0xffff, v61                             // 00000094475C: 367A7AFF 0000FFFF
	v_sad_u8 v58, v63, 0, 0x6400                               // 000000944764: D622003A 03FD013F 00006400
	v_lshl_or_b32 v62, v62, 16, v54                            // 000000944770: D656003E 04D9213E
	v_sad_u8 v59, v59, 0, 0x6400                               // 000000944778: D622003B 03FD013B 00006400
	.long 0xd73d0036                                           // 000000944784: D73D0036
	v_cndmask_b32_e32 v1, v45, v55, vcc_lo                     // 000000944788: 02026F2D
	v_and_or_b32 v57, 0xffff, v65, v57                         // 00000094478C: D6570039 04E682FF 0000FFFF
	v_lshl_or_b32 v55, v58, 16, v61                            // 000000944798: D6560037 04F5213A
	v_sad_u8 v56, v64, 0, 0x6400                               // 0000009447A0: D6220038 03FD0140 00006400
	v_lshlrev_b32_e32 v58, 16, v59                             // 0000009447AC: 30747690
	v_pk_fma_f16 v59, v62, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009447B0: CC0E003B 0BFC0B3E 0000C931
	v_bfe_u32 v61, v54, 12, 16                                 // 0000009447BC: D610003D 02411936
	v_pk_fma_f16 v57, v57, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009447C4: CC0E0039 0BFC0B39 0000C931
	v_pk_fma_f16 v62, v55, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009447D0: CC0E003E 0BFC0B37 0000C931
	v_and_or_b32 v55, 0xffff, v56, v58                         // 0000009447DC: D6570037 04EA70FF 0000FFFF
	v_dot2acc_f32_f16 v34, v59, v18                            // 0000009447E8: 0444253B
	v_bfe_u32 v56, v54, 8, 16                                  // 0000009447EC: D6100038 02411136
	.long 0xd72c003a                                           // 0000009447F4: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v61, vcc_lo              // 0000009447F8: 02027AFF 83DCD12D
	v_and_b32_e32 v59, 0xffff, v54                             // 000000944800: 36766CFF 0000FFFF
	v_pk_fma_f16 v61, v55, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000944808: CC0E003D 0BFC0B37 0000C931
	v_dot2acc_f32_f16 v34, v57, v19                            // 000000944814: 04442739
	v_bfe_u32 v57, v54, 4, 16                                  // 000000944818: D6100039 02410936
	ds_load_2addr_b32 v[54:55], v53 offset0:128 offset1:160    // 000000944820: D8DCA080 36000035
	.long 0xd72c0038                                           // 000000944828: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v56, vcc_lo              // 00000094482C: 020270FF 83DCD12D
	.long 0xd72c003b                                           // 000000944834: D72C003B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 000000944838: 020276FF 83DCD12D
	v_sad_u8 v63, v58, 0, 0x6400                               // 000000944840: D622003F 03FD013A 00006400
	.long 0xd72c0042                                           // 00000094484C: D72C0042
	v_cndmask_b32_e32 v1, 0x83dcd12d, v57, vcc_lo              // 000000944850: 020272FF 83DCD12D
	ds_load_2addr_b32 v[57:58], v52 offset0:128 offset1:160    // 000000944858: D8DCA080 39000034
	v_bfe_u32 v64, v60, 12, 16                                 // 000000944860: D6100040 0241193C
	v_bfe_u32 v65, v60, 8, 16                                  // 000000944868: D6100041 0241113C
	v_and_b32_e32 v63, 0xffff, v63                             // 000000944870: 367E7EFF 0000FFFF
	v_sad_u8 v56, v56, 0, 0x6400                               // 000000944878: D6220038 03FD0138 00006400
	v_sad_u8 v59, v59, 0, 0x6400                               // 000000944884: D622003B 03FD013B 00006400
	.long 0xd72c0040                                           // 000000944890: D72C0040
	v_cndmask_b32_e32 v1, 0x83dcd12d, v64, vcc_lo              // 000000944894: 020280FF 83DCD12D
	.long 0xd72c0041                                           // 00000094489C: D72C0041
	v_cndmask_b32_e32 v1, 0x83dcd12d, v65, vcc_lo              // 0000009448A0: 020282FF 83DCD12D
	v_bfe_u32 v67, v60, 4, 16                                  // 0000009448A8: D6100043 0241093C
	v_lshl_or_b32 v56, v56, 16, v63                            // 0000009448B0: D6560038 04FD2138
	v_sad_u8 v63, v66, 0, 0x6400                               // 0000009448B8: D622003F 03FD0142 00006400
	v_lshlrev_b32_e32 v59, 16, v59                             // 0000009448C4: 30767690
	v_and_b32_e32 v60, 0xffff, v60                             // 0000009448C8: 367878FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4)                            // 0000009448D0: BF870004
	v_pk_fma_f16 v66, v56, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009448D4: CC0E0042 0BFC0B38 0000C931
	s_waitcnt lgkmcnt(1)                                       // 0000009448E0: BF89FC17
	v_mov_b32_e32 v56, v54                                     // 0000009448E4: 7E700336
	v_sad_u8 v64, v64, 0, 0x6400                               // 0000009448E8: D6220040 03FD0140 00006400
	v_and_or_b32 v63, 0xffff, v63, v59                         // 0000009448F4: D657003F 04EE7EFF 0000FFFF
	v_sad_u8 v65, v65, 0, 0x6400                               // 000000944900: D6220041 03FD0141 00006400
	.long 0xd72c003c                                           // 00000094490C: D72C003C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v60, vcc_lo              // 000000944910: 020278FF 83DCD12D
	s_waitcnt lgkmcnt(0)                                       // 000000944918: BF89FC07
	.long 0xd73d0038                                           // 00000094491C: D73D0038
	v_cndmask_b32_e32 v1, v45, v56, vcc_lo                     // 000000944920: 0202712D
	v_and_b32_e32 v64, 0xffff, v64                             // 000000944924: 368080FF 0000FFFF
	v_pk_fma_f16 v57, v63, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000094492C: CC0E0039 0BFC0B3F 0000C931
	v_dot2acc_f32_f16 v33, v66, v18                            // 000000944938: 04422542
	.long 0xd72c0036                                           // 00000094493C: D72C0036
	v_cndmask_b32_e32 v1, 0x83dcd12d, v67, vcc_lo              // 000000944940: 020286FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000944948: BF870224
	v_lshl_or_b32 v63, v65, 16, v64                            // 00000094494C: D656003F 05012141
	v_bfe_u32 v65, v56, 12, 16                                 // 000000944954: D6100041 02411938
	v_dot2acc_f32_f16 v33, v57, v19                            // 00000094495C: 04422739
	v_sad_u8 v67, v60, 0, 0x6400                               // 000000944960: D6220043 03FD013C 00006400
	ds_load_2addr_b32 v[59:60], v49 offset0:128 offset1:160    // 00000094496C: D8DCA080 3B000031
	.long 0xd72c0039                                           // 000000944974: D72C0039
	v_cndmask_b32_e32 v1, 0x83dcd12d, v65, vcc_lo              // 000000944978: 020282FF 83DCD12D
	v_sad_u8 v54, v54, 0, 0x6400                               // 000000944980: D6220036 03FD0136 00006400
	v_lshlrev_b32_e32 v64, 16, v67                             // 00000094498C: 30808690
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000944990: BF870211
	v_and_or_b32 v54, 0xffff, v54, v64                         // 000000944994: D6570036 05026CFF 0000FFFF
	v_sad_u8 v57, v57, 0, 0x6400                               // 0000009449A0: D6220039 03FD0139 00006400
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000009449AC: BF8701C1
	v_dual_dot2acc_f32_f16 v34, v62, v20 :: v_dual_and_b32 v57, 0xffff, v57// 0000009449B0: CB24293E 223872FF 0000FFFF
	v_pk_fma_f16 v62, v63, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009449BC: CC0E003E 0BFC0B3F 0000C931
	v_bfe_u32 v63, v56, 8, 16                                  // 0000009449C8: D610003F 02411138
	s_waitcnt lgkmcnt(0)                                       // 0000009449D0: BF89FC07
	v_dual_dot2acc_f32_f16 v34, v61, v21 :: v_dual_and_b32 v65, 0xffff, v59// 0000009449D4: CB242B3D 224076FF 0000FFFF
	v_pk_fma_f16 v61, v54, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009449E0: CC0E003D 0BFC0B36 0000C931
	v_bfe_u32 v54, v56, 4, 16                                  // 0000009449EC: D6100036 02410938
	v_and_b32_e32 v56, 0xffff, v56                             // 0000009449F4: 367070FF 0000FFFF
	v_dot2acc_f32_f16 v33, v62, v20                            // 0000009449FC: 0442293E
	.long 0xd72c003e                                           // 000000944A00: D72C003E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v63, vcc_lo              // 000000944A04: 02027EFF 83DCD12D
	v_bfe_u32 v63, v59, 12, 16                                 // 000000944A0C: D610003F 0241193B
	.long 0xd72c0036                                           // 000000944A14: D72C0036
	v_cndmask_b32_e32 v1, 0x83dcd12d, v54, vcc_lo              // 000000944A18: 02026CFF 83DCD12D
	.long 0xd72c0038                                           // 000000944A20: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v56, vcc_lo              // 000000944A24: 020270FF 83DCD12D
	.long 0xd72c0041                                           // 000000944A2C: D72C0041
	v_cndmask_b32_e32 v1, 0x83dcd12d, v65, vcc_lo              // 000000944A30: 020282FF 83DCD12D
	v_bfe_u32 v64, v59, 8, 16                                  // 000000944A38: D6100040 0241113B
	.long 0xd72c003f                                           // 000000944A40: D72C003F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v63, vcc_lo              // 000000944A44: 02027EFF 83DCD12D
	v_bfe_u32 v59, v59, 4, 16                                  // 000000944A4C: D610003B 0241093B
	v_sad_u8 v62, v62, 0, 0x6400                               // 000000944A54: D622003E 03FD013E 00006400
	v_dot2acc_f32_f16 v33, v61, v21                            // 000000944A60: 04422B3D
	v_sad_u8 v56, v56, 0, 0x6400                               // 000000944A64: D6220038 03FD0138 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000944A70: BF870214
	.long 0xd72c003b                                           // 000000944A74: D72C003B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 000000944A78: 020276FF 83DCD12D
	v_lshl_or_b32 v57, v62, 16, v57                            // 000000944A80: D6560039 04E5213E
	.long 0xd72c003e                                           // 000000944A88: D72C003E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v64, vcc_lo              // 000000944A8C: 020280FF 83DCD12D
	v_sad_u8 v63, v63, 0, 0x6400                               // 000000944A94: D622003F 03FD013F 00006400
	v_sad_u8 v64, v54, 0, 0x6400                               // 000000944AA0: D6220040 03FD0136 00006400
	v_lshlrev_b32_e32 v66, 16, v56                             // 000000944AAC: 30847090
	v_sad_u8 v54, v65, 0, 0x6400                               // 000000944AB0: D6220036 03FD0141 00006400
	v_mov_b32_e32 v56, v58                                     // 000000944ABC: 7E70033A
	v_and_b32_e32 v58, 0xffff, v63                             // 000000944AC0: 36747EFF 0000FFFF
	v_sad_u8 v59, v59, 0, 0x6400                               // 000000944AC8: D622003B 03FD013B 00006400
	v_sad_u8 v62, v62, 0, 0x6400                               // 000000944AD4: D622003E 03FD013E 00006400
	v_lshlrev_b32_e32 v63, 16, v54                             // 000000944AE0: 307E6C90
	.long 0xd73d0036                                           // 000000944AE4: D73D0036
	v_cndmask_b32_e32 v1, v45, v55, vcc_lo                     // 000000944AE8: 02026F2D
	v_pk_fma_f16 v56, v57, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000944AEC: CC0E0038 0BFC0B39 0000C931
	v_and_or_b32 v55, 0xffff, v64, v66                         // 000000944AF8: D6570037 050A80FF 0000FFFF
	v_lshl_or_b32 v57, v62, 16, v58                            // 000000944B04: D6560039 04E9213E
	v_and_or_b32 v58, 0xffff, v59, v63                         // 000000944B0C: D657003A 04FE76FF 0000FFFF
	v_bfe_u32 v63, v60, 8, 16                                  // 000000944B18: D610003F 0241113C
	v_bfe_u32 v59, v54, 12, 16                                 // 000000944B20: D610003B 02411936
	v_dot2acc_f32_f16 v32, v56, v18                            // 000000944B28: 04402538
	v_pk_fma_f16 v61, v57, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000944B2C: CC0E003D 0BFC0B39 0000C931
	v_bfe_u32 v57, v54, 8, 16                                  // 000000944B38: D6100039 02411136
	v_pk_fma_f16 v62, v58, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000944B40: CC0E003E 0BFC0B3A 0000C931
	.long 0xd72c0038                                           // 000000944B4C: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 000000944B50: 020276FF 83DCD12D
	v_bfe_u32 v58, v54, 4, 16                                  // 000000944B58: D610003A 02410936
	v_and_b32_e32 v54, 0xffff, v54                             // 000000944B60: 366C6CFF 0000FFFF
	v_bfe_u32 v59, v60, 12, 16                                 // 000000944B68: D610003B 0241193C
	.long 0xd72c0039                                           // 000000944B70: D72C0039
	v_cndmask_b32_e32 v1, 0x83dcd12d, v57, vcc_lo              // 000000944B74: 020272FF 83DCD12D
	v_bfe_u32 v64, v60, 4, 16                                  // 000000944B7C: D6100040 0241093C
	v_and_b32_e32 v60, 0xffff, v60                             // 000000944B84: 367878FF 0000FFFF
	.long 0xd72c0041                                           // 000000944B8C: D72C0041
	v_cndmask_b32_e32 v1, 0x83dcd12d, v54, vcc_lo              // 000000944B90: 02026CFF 83DCD12D
	v_sad_u8 v56, v56, 0, 0x6400                               // 000000944B98: D6220038 03FD0138 00006400
	.long 0xd72c003b                                           // 000000944BA4: D72C003B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 000000944BA8: 020276FF 83DCD12D
	v_pk_fma_f16 v55, v55, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000944BB0: CC0E0037 0BFC0B37 0000C931
	.long 0xd72c003c                                           // 000000944BBC: D72C003C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v60, vcc_lo              // 000000944BC0: 020278FF 83DCD12D
	v_sad_u8 v66, v57, 0, 0x6400                               // 000000944BC8: D6220042 03FD0139 00006400
	v_and_b32_e32 v56, 0xffff, v56                             // 000000944BD4: 367070FF 0000FFFF
	.long 0xd72c0043                                           // 000000944BDC: D72C0043
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 000000944BE0: 020274FF 83DCD12D
	ds_load_2addr_b32 v[57:58], v52 offset0:192 offset1:224    // 000000944BE8: D8DCE0C0 39000034
	.long 0xd72c003f                                           // 000000944BF0: D72C003F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v63, vcc_lo              // 000000944BF4: 02027EFF 83DCD12D
	.long 0xd72c0040                                           // 000000944BFC: D72C0040
	v_cndmask_b32_e32 v1, 0x83dcd12d, v64, vcc_lo              // 000000944C00: 020280FF 83DCD12D
	v_lshl_or_b32 v66, v66, 16, v56                            // 000000944C08: D6560042 04E12142
	v_sad_u8 v56, v65, 0, 0x6400                               // 000000944C10: D6220038 03FD0141 00006400
	v_sad_u8 v65, v59, 0, 0x6400                               // 000000944C1C: D6220041 03FD013B 00006400
	v_sad_u8 v67, v67, 0, 0x6400                               // 000000944C28: D6220043 03FD0143 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000944C34: BF870214
	v_pk_fma_f16 v66, v66, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000944C38: CC0E0042 0BFC0B42 0000C931
	v_lshlrev_b32_e32 v68, 16, v56                             // 000000944C44: 30887090
	v_sad_u8 v56, v60, 0, 0x6400                               // 000000944C48: D6220038 03FD013C 00006400
	v_dual_dot2acc_f32_f16 v32, v55, v19 :: v_dual_and_b32 v65, 0xffff, v65// 000000944C54: CB242737 204082FF 0000FFFF
	ds_load_2addr_b32 v[54:55], v53 offset0:192 offset1:224    // 000000944C60: D8DCE0C0 36000035
	ds_load_2addr_b32 v[59:60], v49 offset0:192 offset1:224    // 000000944C68: D8DCE0C0 3B000031
	v_sad_u8 v63, v63, 0, 0x6400                               // 000000944C70: D622003F 03FD013F 00006400
	v_lshlrev_b32_e32 v69, 16, v56                             // 000000944C7C: 308A7090
	v_dot2acc_f32_f16 v31, v66, v18                            // 000000944C80: 043E2542
	v_sad_u8 v64, v64, 0, 0x6400                               // 000000944C84: D6220040 03FD0140 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000944C90: BF870114
	v_lshl_or_b32 v63, v63, 16, v65                            // 000000944C94: D656003F 0505213F
	v_and_or_b32 v64, 0xffff, v64, v69                         // 000000944C9C: D6570040 051680FF 0000FFFF
	s_waitcnt lgkmcnt(1)                                       // 000000944CA8: BF89FC17
	v_mov_b32_e32 v56, v54                                     // 000000944CAC: 7E700336
	v_and_or_b32 v54, 0xffff, v67, v68                         // 000000944CB0: D6570036 051286FF 0000FFFF
	s_waitcnt lgkmcnt(0)                                       // 000000944CBC: BF89FC07
	v_bfe_u32 v65, v59, 12, 16                                 // 000000944CC0: D6100041 0241193B
	v_bfe_u32 v66, v59, 8, 16                                  // 000000944CC8: D6100042 0241113B
	v_bfe_u32 v67, v59, 4, 16                                  // 000000944CD0: D6100043 0241093B
	v_and_b32_e32 v59, 0xffff, v59                             // 000000944CD8: 367676FF 0000FFFF
	.long 0xd73d0038                                           // 000000944CE0: D73D0038
	v_cndmask_b32_e32 v1, v45, v56, vcc_lo                     // 000000944CE4: 0202712D
	v_pk_fma_f16 v57, v63, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000944CE8: CC0E0039 0BFC0B3F 0000C931
	v_pk_fma_f16 v54, v54, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000944CF4: CC0E0036 0BFC0B36 0000C931
	.long 0xd72c0041                                           // 000000944D00: D72C0041
	v_cndmask_b32_e32 v1, 0x83dcd12d, v65, vcc_lo              // 000000944D04: 020282FF 83DCD12D
	.long 0xd72c0042                                           // 000000944D0C: D72C0042
	v_cndmask_b32_e32 v1, 0x83dcd12d, v66, vcc_lo              // 000000944D10: 020284FF 83DCD12D
	v_bfe_u32 v63, v56, 12, 16                                 // 000000944D18: D610003F 02411938
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000944D20: BF870114
	v_dual_dot2acc_f32_f16 v31, v54, v19 :: v_dual_and_b32 v54, 0xffff, v56// 000000944D24: CB242736 1F3670FF 0000FFFF
	.long 0xd72c003f                                           // 000000944D30: D72C003F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v63, vcc_lo              // 000000944D34: 02027EFF 83DCD12D
	v_sad_u8 v65, v65, 0, 0x6400                               // 000000944D3C: D6220041 03FD0141 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000944D48: BF870213
	.long 0xd72c0036                                           // 000000944D4C: D72C0036
	v_cndmask_b32_e32 v1, 0x83dcd12d, v54, vcc_lo              // 000000944D50: 02026CFF 83DCD12D
	v_dot2acc_f32_f16 v31, v57, v20                            // 000000944D58: 043E2939
	s_delay_alu instid0(VALU_DEP_3)                            // 000000944D5C: BF870003
	v_and_b32_e32 v65, 0xffff, v65                             // 000000944D60: 368282FF 0000FFFF
	v_sad_u8 v63, v63, 0, 0x6400                               // 000000944D68: D622003F 03FD013F 00006400
	v_dot2acc_f32_f16 v32, v61, v20                            // 000000944D74: 0440293D
	v_pk_fma_f16 v61, v64, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000944D78: CC0E003D 0BFC0B40 0000C931
	v_bfe_u32 v64, v56, 8, 16                                  // 000000944D84: D6100040 02411138
	v_bfe_u32 v56, v56, 4, 16                                  // 000000944D8C: D6100038 02410938
	v_sad_u8 v54, v54, 0, 0x6400                               // 000000944D94: D6220036 03FD0136 00006400
	v_and_b32_e32 v63, 0xffff, v63                             // 000000944DA0: 367E7EFF 0000FFFF
	v_dual_dot2acc_f32_f16 v32, v62, v21 :: v_dual_add_nc_u32 v47, 1, v47// 000000944DA8: CB202B3E 202E5E81
	.long 0xd72c0040                                           // 000000944DB0: D72C0040
	v_cndmask_b32_e32 v1, 0x83dcd12d, v64, vcc_lo              // 000000944DB4: 020280FF 83DCD12D
	.long 0xd72c0038                                           // 000000944DBC: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v56, vcc_lo              // 000000944DC0: 020270FF 83DCD12D
	v_dual_dot2acc_f32_f16 v31, v61, v21 :: v_dual_lshlrev_b32 v54, 16, v54// 000000944DC8: CB222B3D 1F366C90
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000944DD0: BF870193
	v_sad_u8 v64, v64, 0, 0x6400                               // 000000944DD4: D6220040 03FD0140 00006400
	v_sad_u8 v68, v56, 0, 0x6400                               // 000000944DE0: D6220044 03FD0138 00006400
	v_mov_b32_e32 v56, v58                                     // 000000944DEC: 7E70033A
	v_sad_u8 v58, v66, 0, 0x6400                               // 000000944DF0: D622003A 03FD0142 00006400
	.long 0xd72c0042                                           // 000000944DFC: D72C0042
	v_cndmask_b32_e32 v1, 0x83dcd12d, v67, vcc_lo              // 000000944E00: 020286FF 83DCD12D
	v_lshl_or_b32 v63, v64, 16, v63                            // 000000944E08: D656003F 04FD2140
	v_and_or_b32 v64, 0xffff, v68, v54                         // 000000944E10: D6570040 04DA88FF 0000FFFF
	.long 0xd73d0036                                           // 000000944E1C: D73D0036
	v_cndmask_b32_e32 v1, v45, v55, vcc_lo                     // 000000944E20: 02026F2D
	.long 0xd72c0038                                           // 000000944E24: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 000000944E28: 020276FF 83DCD12D
	v_lshl_or_b32 v55, v58, 16, v65                            // 000000944E30: D6560037 0505213A
	v_pk_fma_f16 v57, v63, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000944E38: CC0E0039 0BFC0B3F 0000C931
	v_pk_fma_f16 v58, v64, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000944E44: CC0E003A 0BFC0B40 0000C931
	v_sad_u8 v63, v66, 0, 0x6400                               // 000000944E50: D622003F 03FD0142 00006400
	v_bfe_u32 v59, v54, 12, 16                                 // 000000944E5C: D610003B 02411936
	v_and_b32_e32 v64, 0xffff, v54                             // 000000944E64: 36806CFF 0000FFFF
	v_bfe_u32 v65, v54, 8, 16                                  // 000000944E6C: D6100041 02411136
	v_bfe_u32 v54, v54, 4, 16                                  // 000000944E74: D6100036 02410936
	v_bfe_u32 v66, v60, 12, 16                                 // 000000944E7C: D6100042 0241193C
	.long 0xd72c003b                                           // 000000944E84: D72C003B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 000000944E88: 020276FF 83DCD12D
	.long 0xd72c0040                                           // 000000944E90: D72C0040
	v_cndmask_b32_e32 v1, 0x83dcd12d, v64, vcc_lo              // 000000944E94: 020280FF 83DCD12D
	.long 0xd72c0041                                           // 000000944E9C: D72C0041
	v_cndmask_b32_e32 v1, 0x83dcd12d, v65, vcc_lo              // 000000944EA0: 020282FF 83DCD12D
	.long 0xd72c0036                                           // 000000944EA8: D72C0036
	v_cndmask_b32_e32 v1, 0x83dcd12d, v54, vcc_lo              // 000000944EAC: 02026CFF 83DCD12D
	v_bfe_u32 v67, v60, 8, 16                                  // 000000944EB4: D6100043 0241113C
	.long 0xd72c0042                                           // 000000944EBC: D72C0042
	v_cndmask_b32_e32 v1, 0x83dcd12d, v66, vcc_lo              // 000000944EC0: 020284FF 83DCD12D
	v_bfe_u32 v68, v60, 4, 16                                  // 000000944EC8: D6100044 0241093C
	v_and_b32_e32 v60, 0xffff, v60                             // 000000944ED0: 367878FF 0000FFFF
	v_sad_u8 v59, v59, 0, 0x6400                               // 000000944ED8: D622003B 03FD013B 00006400
	v_sad_u8 v64, v64, 0, 0x6400                               // 000000944EE4: D6220040 03FD0140 00006400
	v_sad_u8 v65, v65, 0, 0x6400                               // 000000944EF0: D6220041 03FD0141 00006400
	.long 0xd72c0043                                           // 000000944EFC: D72C0043
	v_cndmask_b32_e32 v1, 0x83dcd12d, v67, vcc_lo              // 000000944F00: 020286FF 83DCD12D
	v_sad_u8 v54, v54, 0, 0x6400                               // 000000944F08: D6220036 03FD0136 00006400
	v_dual_dot2acc_f32_f16 v30, v57, v18 :: v_dual_and_b32 v59, 0xffff, v59// 000000944F14: CB242539 1E3A76FF 0000FFFF
	v_lshlrev_b32_e32 v64, 16, v64                             // 000000944F20: 30808090
	.long 0xd72c003c                                           // 000000944F24: D72C003C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v60, vcc_lo              // 000000944F28: 020278FF 83DCD12D
	v_sad_u8 v66, v66, 0, 0x6400                               // 000000944F30: D6220042 03FD0142 00006400
	s_delay_alu instid0(VALU_DEP_4)                            // 000000944F3C: BF870004
	v_lshl_or_b32 v59, v65, 16, v59                            // 000000944F40: D656003B 04ED2141
	v_sad_u8 v56, v56, 0, 0x6400                               // 000000944F48: D6220038 03FD0138 00006400
	v_and_or_b32 v54, 0xffff, v54, v64                         // 000000944F54: D6570036 05026CFF 0000FFFF
	.long 0xd72c0040                                           // 000000944F60: D72C0040
	v_cndmask_b32_e32 v1, 0x83dcd12d, v68, vcc_lo              // 000000944F64: 020288FF 83DCD12D
	v_dual_dot2acc_f32_f16 v30, v58, v19 :: v_dual_and_b32 v65, 0xffff, v66// 000000944F6C: CB24273A 1E4084FF 0000FFFF
	v_sad_u8 v66, v67, 0, 0x6400                               // 000000944F78: D6220042 03FD0143 00006400
	v_pk_fma_f16 v59, v59, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000944F84: CC0E003B 0BFC0B3B 0000C931
	v_sad_u8 v57, v60, 0, 0x6400                               // 000000944F90: D6220039 03FD013C 00006400
	v_lshlrev_b32_e32 v56, 16, v56                             // 000000944F9C: 30707090
	v_pk_fma_f16 v54, v54, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000944FA0: CC0E0036 0BFC0B36 0000C931
	v_lshl_or_b32 v60, v66, 16, v65                            // 000000944FAC: D656003C 05052142
	v_dot2acc_f32_f16 v1, v59, v18                             // 000000944FB4: 0402253B
	v_pk_fma_f16 v55, v55, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000944FB8: CC0E0037 0BFC0B37 0000C931
	v_sad_u8 v64, v64, 0, 0x6400                               // 000000944FC4: D6220040 03FD0140 00006400
	v_lshlrev_b32_e32 v57, 16, v57                             // 000000944FD0: 30727290
	v_and_or_b32 v18, 0xffff, v63, v56                         // 000000944FD4: D6570012 04E27EFF 0000FFFF
	v_pk_fma_f16 v56, v60, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000944FE0: CC0E0038 0BFC0B3C 0000C931
	v_dual_dot2acc_f32_f16 v1, v54, v19 :: v_dual_dot2acc_f32_f16 v30, v55, v20// 000000944FEC: CB182736 011E2937
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000944FF4: BF870214
	v_and_or_b32 v57, 0xffff, v64, v57                         // 000000944FF8: D6570039 04E680FF 0000FFFF
	v_pk_fma_f16 v18, v18, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000945004: CC0E0012 0BFC0B12 0000C931
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000945010: BF870193
	v_dual_dot2acc_f32_f16 v1, v56, v20 :: v_dual_add_nc_u32 v20, v46, v47// 000000945014: CB202938 01145F2E
	v_pk_fma_f16 v19, v57, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000094501C: CC0E0013 0BFC0B39 0000C931
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000945028: BF870193
	v_dot2acc_f32_f16 v30, v18, v21                            // 00000094502C: 043C2B12
	v_cmp_eq_u32_e32 vcc_lo, 21, v20                           // 000000945030: 7C942895
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000945034: BF8704A3
	v_dot2acc_f32_f16 v1, v19, v21                             // 000000945038: 04022B13
	s_or_b32 s4, vcc_lo, s4                                    // 00000094503C: 8C04046A
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000945040: 917E047E
	s_cbranch_execz 62                                         // 000000945044: BFA5003E <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_gu_tsILi4ELi2EEEvPKjPKDF16_PKiS5_S5_PDF16_PfPj+0x2040>
	s_mov_b32 s1, exec_lo                                      // 000000945048: BE81007E
	s_waitcnt vmcnt(14)                                        // 00000094504C: BF893BF7
	ds_store_2addr_b32 v48, v2, v3 offset1:32                  // 000000945050: D8382000 00030230
	s_waitcnt vmcnt(12)                                        // 000000945058: BF8933F7
	ds_store_2addr_b32 v48, v4, v5 offset0:64 offset1:96       // 00000094505C: D8386040 00050430
	s_waitcnt vmcnt(10)                                        // 000000945064: BF892BF7
	ds_store_2addr_b32 v48, v6, v7 offset0:128 offset1:160     // 000000945068: D838A080 00070630
	s_waitcnt vmcnt(8)                                         // 000000945070: BF8923F7
	ds_store_2addr_b32 v48, v8, v9 offset0:192 offset1:224     // 000000945074: D838E0C0 00090830
	s_waitcnt vmcnt(6)                                         // 00000094507C: BF891BF7
	ds_store_2addr_b32 v49, v10, v11 offset1:32                // 000000945080: D8382000 000B0A31
	s_waitcnt vmcnt(4)                                         // 000000945088: BF8913F7
	ds_store_2addr_b32 v49, v12, v13 offset0:64 offset1:96     // 00000094508C: D8386040 000D0C31
	s_waitcnt vmcnt(2)                                         // 000000945094: BF890BF7
	ds_store_2addr_b32 v49, v14, v15 offset0:128 offset1:160   // 000000945098: D838A080 000F0E31
	s_waitcnt vmcnt(0)                                         // 0000009450A0: BF8903F7
	ds_store_2addr_b32 v49, v16, v17 offset0:192 offset1:224   // 0000009450A4: D838E0C0 00111031
	.long 0xd4c1007e                                           // 0000009450AC: D4C1007E
	v_cndmask_b32_e32 v1, v47, v29, vcc_lo                     // 0000009450B0: 02023B2F
	s_cbranch_execz 63800                                      // 0000009450B4: BFA5F938 <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_gu_tsILi4ELi2EEEvPKjPKDF16_PKiS5_S5_PDF16_PfPj+0x498>
	s_clause 0xf                                               // 0000009450B8: BF85000F
	global_load_b32 v2, v[23:24], off                          // 0000009450BC: DC520000 027C0017
	global_load_b32 v3, v[23:24], off offset:128               // 0000009450C4: DC520080 037C0017
	global_load_b32 v4, v[23:24], off offset:256               // 0000009450CC: DC520100 047C0017
	global_load_b32 v5, v[23:24], off offset:384               // 0000009450D4: DC520180 057C0017
	global_load_b32 v6, v[23:24], off offset:512               // 0000009450DC: DC520200 067C0017
	global_load_b32 v7, v[23:24], off offset:640               // 0000009450E4: DC520280 077C0017
	global_load_b32 v8, v[23:24], off offset:768               // 0000009450EC: DC520300 087C0017
	global_load_b32 v9, v[23:24], off offset:896               // 0000009450F4: DC520380 097C0017
	global_load_b32 v10, v[23:24], off offset:1024             // 0000009450FC: DC520400 0A7C0017
	global_load_b32 v11, v[23:24], off offset:1152             // 000000945104: DC520480 0B7C0017
	global_load_b32 v12, v[23:24], off offset:1280             // 00000094510C: DC520500 0C7C0017
	global_load_b32 v13, v[23:24], off offset:1408             // 000000945114: DC520580 0D7C0017
	global_load_b32 v14, v[23:24], off offset:1536             // 00000094511C: DC520600 0E7C0017
	global_load_b32 v15, v[23:24], off offset:1664             // 000000945124: DC520680 0F7C0017
	global_load_b32 v16, v[23:24], off offset:1792             // 00000094512C: DC520700 107C0017
	global_load_b32 v17, v[23:24], off offset:1920             // 000000945134: DC520780 117C0017
	s_branch 63766                                             // 00000094513C: BFA0F916 <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_gu_tsILi4ELi2EEEvPKjPKDF16_PKiS5_S5_PDF16_PfPj+0x498>
	s_or_b32 exec_lo, exec_lo, s4                              // 000000945140: 8C7E047E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000945144: BF870009
	s_or_b32 exec_lo, exec_lo, s3                              // 000000945148: 8C7E037E
	s_waitcnt vmcnt(10)                                        // 00000094514C: BF892BF7
	v_dual_mov_b32 v2, v28 :: v_dual_mov_b32 v7, v42           // 000000945150: CA10011C 0206012A
	v_dual_mov_b32 v4, v43 :: v_dual_mov_b32 v5, v40           // 000000945158: CA10012B 04040128
	s_waitcnt vmcnt(8)                                         // 000000945160: BF8923F7
	v_dual_mov_b32 v8, v41 :: v_dual_mov_b32 v9, v38           // 000000945164: CA100129 08080126
	s_waitcnt vmcnt(6)                                         // 00000094516C: BF891BF7
	v_dual_mov_b32 v6, v39 :: v_dual_mov_b32 v11, v37          // 000000945170: CA100127 060A0125
	s_waitcnt vmcnt(4)                                         // 000000945178: BF8913F7
	v_dual_mov_b32 v13, v36 :: v_dual_mov_b32 v10, v33         // 00000094517C: CA100124 0D0A0121
	s_waitcnt vmcnt(2)                                         // 000000945184: BF890BF7
	v_dual_mov_b32 v15, v35 :: v_dual_mov_b32 v12, v32         // 000000945188: CA100123 0F0C0120
	v_dual_mov_b32 v3, v34 :: v_dual_mov_b32 v14, v31          // 000000945190: CA100122 030E011F
	s_waitcnt vmcnt(0)                                         // 000000945198: BF8903F7
	v_dual_mov_b32 v16, v30 :: v_dual_mov_b32 v17, v1          // 00000094519C: CA10011E 10100101
	s_mov_b32 s1, 0x76543210                                   // 0000009451A4: BE8100FF 76543210
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000009451AC: BF870009
	v_permlanex16_b32 v2, v2, s1, 0xfedcba98                   // 0000009451B0: D65C0002 03FC0302 FEDCBA98
	v_permlanex16_b32 v4, v4, s1, 0xfedcba98                   // 0000009451BC: D65C0004 03FC0304 FEDCBA98
	v_permlanex16_b32 v7, v7, s1, 0xfedcba98                   // 0000009451C8: D65C0007 03FC0307 FEDCBA98
	v_permlanex16_b32 v8, v8, s1, 0xfedcba98                   // 0000009451D4: D65C0008 03FC0308 FEDCBA98
	v_permlanex16_b32 v5, v5, s1, 0xfedcba98                   // 0000009451E0: D65C0005 03FC0305 FEDCBA98
	v_permlanex16_b32 v6, v6, s1, 0xfedcba98                   // 0000009451EC: D65C0006 03FC0306 FEDCBA98
	v_permlanex16_b32 v9, v9, s1, 0xfedcba98                   // 0000009451F8: D65C0009 03FC0309 FEDCBA98
	v_permlanex16_b32 v11, v11, s1, 0xfedcba98                 // 000000945204: D65C000B 03FC030B FEDCBA98
	v_permlanex16_b32 v13, v13, s1, 0xfedcba98                 // 000000945210: D65C000D 03FC030D FEDCBA98
	v_permlanex16_b32 v15, v15, s1, 0xfedcba98                 // 00000094521C: D65C000F 03FC030F FEDCBA98
	v_permlanex16_b32 v3, v3, s1, 0xfedcba98                   // 000000945228: D65C0003 03FC0303 FEDCBA98
	v_permlanex16_b32 v10, v10, s1, 0xfedcba98                 // 000000945234: D65C000A 03FC030A FEDCBA98
	v_permlanex16_b32 v12, v12, s1, 0xfedcba98                 // 000000945240: D65C000C 03FC030C FEDCBA98
	v_permlanex16_b32 v14, v14, s1, 0xfedcba98                 // 00000094524C: D65C000E 03FC030E FEDCBA98
	v_permlanex16_b32 v16, v16, s1, 0xfedcba98                 // 000000945258: D65C0010 03FC0310 FEDCBA98
	v_permlanex16_b32 v17, v17, s1, 0xfedcba98                 // 000000945264: D65C0011 03FC0311 FEDCBA98
	.long 0xd44c0001                                           // 000000945270: D44C0001
	v_cndmask_b32_e32 v1, 16, v27, vcc_lo                      // 000000945274: 02023690
	s_and_saveexec_b32 s3, s1                                  // 000000945278: BE832001
	s_cbranch_execz 72                                         // 00000094527C: BFA50048 <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_gu_tsILi4ELi2EEEvPKjPKDF16_PKiS5_S5_PDF16_PfPj+0x22a0>
	v_ashrrev_i32_e32 v23, 31, v22                             // 000000945280: 342E2C9F
	v_dual_add_f32 v17, v1, v17 :: v_dual_add_f32 v18, v28, v2 // 000000945284: C9082301 1112051C
	s_ashr_i32 s7, s6, 31                                      // 00000094528C: 86079F06
	v_dual_add_f32 v4, v43, v4 :: v_dual_add_f32 v7, v42, v7   // 000000945290: C908092B 04060F2A
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000945298: BF8701C3
	.long 0xd73c0001                                           // 00000094529C: D73C0001
	v_cndmask_b32_e32 v1, 4, v22, vcc_lo                       // 0000009452A0: 02022C84
	s_lshl_b64 s[4:5], s[6:7], 7                               // 0000009452A4: 84848706
	v_dual_add_f32 v8, v41, v8 :: v_dual_add_f32 v5, v40, v5   // 0000009452A8: C9081129 08040B28
	v_dual_add_f32 v6, v39, v6 :: v_dual_add_f32 v9, v38, v9   // 0000009452B0: C9080D27 06081326
	.long 0xd7006a01                                           // 0000009452B8: D7006A01
	v_cndmask_b32_e32 v0, v1, v4, vcc_lo                       // 0000009452BC: 02000901
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000009452C0: BF8700A1
	v_add_co_ci_u32_e64 v2, null, s5, v2, vcc_lo               // 0000009452C4: D5207C02 01AA0405
	.long 0xd7000413                                           // 0000009452CC: D7000413
	v_cndmask_b32_e32 v1, s16, v26, vcc_lo                     // 0000009452D0: 02023410
	v_add_co_ci_u32_e64 v20, null, s17, 0, s4                  // 0000009452D4: D5207C14 00110011
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000009452DC: BF870243
	.long 0xd73c0001                                           // 0000009452E0: D73C0001
	v_cndmask_b32_e32 v1, 6, v1, vcc_lo                        // 0000009452E4: 02020286
	v_dual_add_f32 v11, v37, v11 :: v_dual_add_f32 v12, v32, v12// 0000009452E8: C9081725 0B0C1920
	v_dual_add_f32 v13, v36, v13 :: v_dual_add_f32 v10, v33, v10// 0000009452F0: C9081B24 0D0A1521
	v_dual_add_f32 v15, v35, v15 :: v_dual_add_f32 v16, v30, v16// 0000009452F8: C9081F23 0F10211E
	.long 0xd7006a01                                           // 000000945300: D7006A01
	v_cndmask_b32_e32 v1, v19, v1, vcc_lo                      // 000000945304: 02020313
	s_delay_alu instid0(VALU_DEP_1)                            // 000000945308: BF870001
	v_add_co_ci_u32_e64 v2, null, v20, v2, vcc_lo              // 00000094530C: D5207C02 01AA0514
	v_dual_add_f32 v3, v34, v3 :: v_dual_add_f32 v14, v31, v14 // 000000945314: C9080722 030E1D1F
	s_clause 0xf                                               // 00000094531C: BF85000F
	global_store_b32 v[1:2], v18, off                          // 000000945320: DC6A0000 007C1201
	global_store_b32 v[1:2], v4, off offset:64                 // 000000945328: DC6A0040 007C0401
	global_store_b32 v[1:2], v7, off offset:128                // 000000945330: DC6A0080 007C0701
	global_store_b32 v[1:2], v8, off offset:192                // 000000945338: DC6A00C0 007C0801
	global_store_b32 v[1:2], v5, off offset:256                // 000000945340: DC6A0100 007C0501
	global_store_b32 v[1:2], v6, off offset:320                // 000000945348: DC6A0140 007C0601
	global_store_b32 v[1:2], v9, off offset:384                // 000000945350: DC6A0180 007C0901
	global_store_b32 v[1:2], v11, off offset:448               // 000000945358: DC6A01C0 007C0B01
	global_store_b32 v[1:2], v13, off offset:512               // 000000945360: DC6A0200 007C0D01
	global_store_b32 v[1:2], v15, off offset:576               // 000000945368: DC6A0240 007C0F01
	global_store_b32 v[1:2], v3, off offset:640                // 000000945370: DC6A0280 007C0301
	global_store_b32 v[1:2], v10, off offset:704               // 000000945378: DC6A02C0 007C0A01
	global_store_b32 v[1:2], v12, off offset:768               // 000000945380: DC6A0300 007C0C01
	global_store_b32 v[1:2], v14, off offset:832               // 000000945388: DC6A0340 007C0E01
	global_store_b32 v[1:2], v16, off offset:896               // 000000945390: DC6A0380 007C1001
	global_store_b32 v[1:2], v17, off offset:960               // 000000945398: DC6A03C0 007C1101
	s_or_b32 exec_lo, exec_lo, s3                              // 0000009453A0: 8C7E037E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000009453A4: BF870009
	s_mov_b32 s3, exec_lo                                      // 0000009453A8: BE83007E
	s_waitcnt_vscnt null, 0x0                                  // 0000009453AC: BC7C0000
	buffer_gl1_inv                                             // 0000009453B0: E0B00000 00000000
	buffer_gl0_inv                                             // 0000009453B8: E0AC0000 00000000
	s_barrier                                                  // 0000009453C0: BFBD0000
	buffer_gl0_inv                                             // 0000009453C4: E0AC0000 00000000
	v_cmpx_eq_u32_e32 0, v0                                    // 0000009453CC: 7D940080
	s_cbranch_execz 29                                         // 0000009453D0: BFA5001D <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_gu_tsILi4ELi2EEEvPKjPKDF16_PKiS5_S5_PDF16_PfPj+0x2348>
	s_mov_b32 s5, exec_lo                                      // 0000009453D4: BE85007E
	s_mov_b32 s4, exec_lo                                      // 0000009453D8: BE84007E
	.long 0xd71f0001                                           // 0000009453DC: D71F0001
	v_cndmask_b32_e32 v0, s5, v128, vcc_lo                     // 0000009453E0: 02010005
	s_delay_alu instid0(VALU_DEP_1)                            // 0000009453E4: BF870001
	v_cmpx_eq_u32_e32 0, v1                                    // 0000009453E8: 7D940280
	s_cbranch_execz 11                                         // 0000009453EC: BFA5000B <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_gu_tsILi4ELi2EEEvPKjPKDF16_PKiS5_S5_PDF16_PfPj+0x231c>
	s_ashr_i32 s7, s6, 31                                      // 0000009453F0: 86079F06
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000009453F4: BF870499
	s_lshl_b64 s[22:23], s[6:7], 2                             // 0000009453F8: 84968206
	s_add_u32 s22, s18, s22                                    // 0000009453FC: 80161612
	s_addc_u32 s23, s19, s23                                   // 000000945400: 82171713
	s_bcnt1_i32_b32 s5, s5                                     // 000000945404: BE851805
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000945408: BF870009
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v3, s5              // 00000094540C: CA100080 02020005
	global_atomic_add_u32 v2, v2, v3, s[22:23] glc             // 000000945414: DCD64000 02160302
	s_or_b32 exec_lo, exec_lo, s4                              // 00000094541C: 8C7E047E
	s_waitcnt vmcnt(0)                                         // 000000945420: BF8903F7
	v_readfirstlane_b32 s4, v2                                 // 000000945424: 7E080502
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000945428: BF870091
	v_dual_mov_b32 v2, 0 :: v_dual_add_nc_u32 v1, s4, v1       // 00000094542C: CA200080 02000204
	v_cmp_eq_u32_e32 vcc_lo, 1, v1                             // 000000945434: 7C940281
	v_cndmask_b32_e64 v1, 0, 1, vcc_lo                         // 000000945438: D5010001 01A90280
	ds_store_b32 v2, v1 offset:13568                           // 000000945440: D8343500 00000102
	s_or_b32 exec_lo, exec_lo, s3                              // 000000945448: 8C7E037E
	v_mov_b32_e32 v1, 0                                        // 00000094544C: 7E020280
	s_waitcnt lgkmcnt(0)                                       // 000000945450: BF89FC07
	s_barrier                                                  // 000000945454: BFBD0000
	buffer_gl0_inv                                             // 000000945458: E0AC0000 00000000
	ds_load_b32 v1, v1 offset:13568                            // 000000945460: D8D83500 01000001
	s_waitcnt lgkmcnt(0)                                       // 000000945468: BF89FC07
	v_cmp_eq_u32_e32 vcc_lo, 0, v1                             // 00000094546C: 7C940280
	s_cbranch_vccnz 1456                                       // 000000945470: BFA405B0 <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_gu_tsILi4ELi2EEEvPKjPKDF16_PKiS5_S5_PDF16_PfPj+0x3a34>
	buffer_gl1_inv                                             // 000000945474: E0B00000 00000000
	buffer_gl0_inv                                             // 00000094547C: E0AC0000 00000000
	s_mov_b32 s3, exec_lo                                      // 000000945484: BE83007E
	v_cmpx_eq_u32_e32 0, v25                                   // 000000945488: 7D943280
	s_cbranch_execz 1449                                       // 00000094548C: BFA505A9 <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_gu_tsILi4ELi2EEEvPKjPKDF16_PKiS5_S5_PDF16_PfPj+0x3a34>
	v_dual_mov_b32 v98, 0 :: v_dual_and_b32 v1, 15, v0         // 000000945490: CA240080 6200008F
	s_ashr_i32 s7, s6, 31                                      // 000000945498: 86079F06
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000094549C: BF870099
	s_lshl_b64 s[4:5], s[6:7], 13                              // 0000009454A0: 84848D06
	v_lshlrev_b32_e32 v2, 2, v1                                // 0000009454A4: 30040282
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000009454A8: BF870091
	.long 0xd7000302                                           // 0000009454AC: D7000302
	v_cndmask_b32_e32 v1, s16, v2, vcc_lo                      // 0000009454B0: 02020410
	v_add_co_ci_u32_e64 v3, null, s17, 0, s3                   // 0000009454B4: D5207C03 000D0011
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000009454BC: BF870092
	.long 0xd7006a34                                           // 0000009454C0: D7006A34
	v_cndmask_b32_e32 v0, v2, v4, vcc_lo                       // 0000009454C4: 02000902
	v_add_co_ci_u32_e64 v53, null, s5, v3, vcc_lo              // 0000009454C8: D5207C35 01AA0605
	s_clause 0x3                                               // 0000009454D0: BF850003
	global_load_b32 v99, v[52:53], off glc                     // 0000009454D4: DC524000 637C0034
	global_load_b32 v100, v[52:53], off offset:512 glc         // 0000009454DC: DC524200 647C0034
	global_load_b32 v102, v[52:53], off offset:1024 glc        // 0000009454E4: DC524400 667C0034
	global_load_b32 v103, v[52:53], off offset:1536 glc        // 0000009454EC: DC524600 677C0034
	.long 0xd7006a83                                           // 0000009454F4: D7006A83
	v_cndmask_b32_e32 v1, 0x1000, v52, vcc_lo                  // 0000009454F8: 020268FF 00001000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000945500: BF870001
	v_add_co_ci_u32_e64 v132, null, 0, v53, vcc_lo             // 000000945504: D5207C84 01AA6A80
	s_clause 0x1f                                              // 00000094550C: BF85001F
	global_load_b32 v70, v[52:53], off offset:2048 glc         // 000000945510: DC524800 467C0034
	global_load_b32 v71, v[52:53], off offset:2560 glc         // 000000945518: DC524A00 477C0034
	global_load_b32 v64, v[52:53], off offset:3072 glc         // 000000945520: DC524C00 407C0034
	global_load_b32 v65, v[52:53], off offset:3584 glc         // 000000945528: DC524E00 417C0034
	global_load_b32 v14, v[131:132], off glc                   // 000000945530: DC524000 0E7C0083
	global_load_b32 v15, v[131:132], off offset:512 glc        // 000000945538: DC524200 0F7C0083
	global_load_b32 v8, v[131:132], off offset:1024 glc        // 000000945540: DC524400 087C0083
	global_load_b32 v9, v[131:132], off offset:1536 glc        // 000000945548: DC524600 097C0083
	global_load_b32 v4, v[131:132], off offset:2048 glc        // 000000945550: DC524800 047C0083
	global_load_b32 v5, v[131:132], off offset:2560 glc        // 000000945558: DC524A00 057C0083
	global_load_b32 v2, v[131:132], off offset:3072 glc        // 000000945560: DC524C00 027C0083
	global_load_b32 v3, v[131:132], off offset:3584 glc        // 000000945568: DC524E00 037C0083
	global_load_b32 v101, v[52:53], off offset:64 glc          // 000000945570: DC524040 657C0034
	global_load_b32 v108, v[52:53], off offset:576 glc         // 000000945578: DC524240 6C7C0034
	global_load_b32 v104, v[52:53], off offset:1088 glc        // 000000945580: DC524440 687C0034
	global_load_b32 v105, v[52:53], off offset:1600 glc        // 000000945588: DC524640 697C0034
	global_load_b32 v74, v[52:53], off offset:2112 glc         // 000000945590: DC524840 4A7C0034
	global_load_b32 v75, v[52:53], off offset:2624 glc         // 000000945598: DC524A40 4B7C0034
	global_load_b32 v68, v[52:53], off offset:3136 glc         // 0000009455A0: DC524C40 447C0034
	global_load_b32 v69, v[52:53], off offset:3648 glc         // 0000009455A8: DC524E40 457C0034
	global_load_b32 v22, v[131:132], off offset:64 glc         // 0000009455B0: DC524040 167C0083
	global_load_b32 v23, v[131:132], off offset:576 glc        // 0000009455B8: DC524240 177C0083
	global_load_b32 v16, v[131:132], off offset:1088 glc       // 0000009455C0: DC524440 107C0083
	global_load_b32 v17, v[131:132], off offset:1600 glc       // 0000009455C8: DC524640 117C0083
	global_load_b32 v10, v[131:132], off offset:2112 glc       // 0000009455D0: DC524840 0A7C0083
	global_load_b32 v11, v[131:132], off offset:2624 glc       // 0000009455D8: DC524A40 0B7C0083
	global_load_b32 v6, v[131:132], off offset:3136 glc        // 0000009455E0: DC524C40 067C0083
	global_load_b32 v7, v[131:132], off offset:3648 glc        // 0000009455E8: DC524E40 077C0083
	global_load_b32 v111, v[52:53], off offset:128 glc         // 0000009455F0: DC524080 6F7C0034
	global_load_b32 v112, v[52:53], off offset:640 glc         // 0000009455F8: DC524280 707C0034
	global_load_b32 v106, v[52:53], off offset:1152 glc        // 000000945600: DC524480 6A7C0034
	global_load_b32 v107, v[52:53], off offset:1664 glc        // 000000945608: DC524680 6B7C0034
	s_clause 0x1f                                              // 000000945610: BF85001F
	global_load_b32 v78, v[52:53], off offset:2176 glc         // 000000945614: DC524880 4E7C0034
	global_load_b32 v79, v[52:53], off offset:2688 glc         // 00000094561C: DC524A80 4F7C0034
	global_load_b32 v72, v[52:53], off offset:3200 glc         // 000000945624: DC524C80 487C0034
	global_load_b32 v73, v[52:53], off offset:3712 glc         // 00000094562C: DC524E80 497C0034
	global_load_b32 v30, v[131:132], off offset:128 glc        // 000000945634: DC524080 1E7C0083
	global_load_b32 v31, v[131:132], off offset:640 glc        // 00000094563C: DC524280 1F7C0083
	global_load_b32 v24, v[131:132], off offset:1152 glc       // 000000945644: DC524480 187C0083
	global_load_b32 v25, v[131:132], off offset:1664 glc       // 00000094564C: DC524680 197C0083
	global_load_b32 v18, v[131:132], off offset:2176 glc       // 000000945654: DC524880 127C0083
	global_load_b32 v19, v[131:132], off offset:2688 glc       // 00000094565C: DC524A80 137C0083
	global_load_b32 v12, v[131:132], off offset:3200 glc       // 000000945664: DC524C80 0C7C0083
	global_load_b32 v13, v[131:132], off offset:3712 glc       // 00000094566C: DC524E80 0D7C0083
	global_load_b32 v115, v[52:53], off offset:192 glc         // 000000945674: DC5240C0 737C0034
	global_load_b32 v116, v[52:53], off offset:704 glc         // 00000094567C: DC5242C0 747C0034
	global_load_b32 v109, v[52:53], off offset:1216 glc        // 000000945684: DC5244C0 6D7C0034
	global_load_b32 v110, v[52:53], off offset:1728 glc        // 00000094568C: DC5246C0 6E7C0034
	global_load_b32 v82, v[52:53], off offset:2240 glc         // 000000945694: DC5248C0 527C0034
	global_load_b32 v83, v[52:53], off offset:2752 glc         // 00000094569C: DC524AC0 537C0034
	global_load_b32 v76, v[52:53], off offset:3264 glc         // 0000009456A4: DC524CC0 4C7C0034
	global_load_b32 v77, v[52:53], off offset:3776 glc         // 0000009456AC: DC524EC0 4D7C0034
	global_load_b32 v38, v[131:132], off offset:192 glc        // 0000009456B4: DC5240C0 267C0083
	global_load_b32 v39, v[131:132], off offset:704 glc        // 0000009456BC: DC5242C0 277C0083
	global_load_b32 v32, v[131:132], off offset:1216 glc       // 0000009456C4: DC5244C0 207C0083
	global_load_b32 v33, v[131:132], off offset:1728 glc       // 0000009456CC: DC5246C0 217C0083
	global_load_b32 v26, v[131:132], off offset:2240 glc       // 0000009456D4: DC5248C0 1A7C0083
	global_load_b32 v27, v[131:132], off offset:2752 glc       // 0000009456DC: DC524AC0 1B7C0083
	global_load_b32 v20, v[131:132], off offset:3264 glc       // 0000009456E4: DC524CC0 147C0083
	global_load_b32 v21, v[131:132], off offset:3776 glc       // 0000009456EC: DC524EC0 157C0083
	global_load_b32 v119, v[52:53], off offset:256 glc         // 0000009456F4: DC524100 777C0034
	global_load_b32 v120, v[52:53], off offset:768 glc         // 0000009456FC: DC524300 787C0034
	global_load_b32 v113, v[52:53], off offset:1280 glc        // 000000945704: DC524500 717C0034
	global_load_b32 v114, v[52:53], off offset:1792 glc        // 00000094570C: DC524700 727C0034
	s_clause 0x1f                                              // 000000945714: BF85001F
	global_load_b32 v86, v[52:53], off offset:2304 glc         // 000000945718: DC524900 567C0034
	global_load_b32 v87, v[52:53], off offset:2816 glc         // 000000945720: DC524B00 577C0034
	global_load_b32 v80, v[52:53], off offset:3328 glc         // 000000945728: DC524D00 507C0034
	global_load_b32 v81, v[52:53], off offset:3840 glc         // 000000945730: DC524F00 517C0034
	global_load_b32 v46, v[131:132], off offset:256 glc        // 000000945738: DC524100 2E7C0083
	global_load_b32 v47, v[131:132], off offset:768 glc        // 000000945740: DC524300 2F7C0083
	global_load_b32 v40, v[131:132], off offset:1280 glc       // 000000945748: DC524500 287C0083
	global_load_b32 v41, v[131:132], off offset:1792 glc       // 000000945750: DC524700 297C0083
	global_load_b32 v34, v[131:132], off offset:2304 glc       // 000000945758: DC524900 227C0083
	global_load_b32 v35, v[131:132], off offset:2816 glc       // 000000945760: DC524B00 237C0083
	global_load_b32 v28, v[131:132], off offset:3328 glc       // 000000945768: DC524D00 1C7C0083
	global_load_b32 v29, v[131:132], off offset:3840 glc       // 000000945770: DC524F00 1D7C0083
	global_load_b32 v123, v[52:53], off offset:320 glc         // 000000945778: DC524140 7B7C0034
	global_load_b32 v124, v[52:53], off offset:832 glc         // 000000945780: DC524340 7C7C0034
	global_load_b32 v117, v[52:53], off offset:1344 glc        // 000000945788: DC524540 757C0034
	global_load_b32 v118, v[52:53], off offset:1856 glc        // 000000945790: DC524740 767C0034
	global_load_b32 v90, v[52:53], off offset:2368 glc         // 000000945798: DC524940 5A7C0034
	global_load_b32 v91, v[52:53], off offset:2880 glc         // 0000009457A0: DC524B40 5B7C0034
	global_load_b32 v84, v[52:53], off offset:3392 glc         // 0000009457A8: DC524D40 547C0034
	global_load_b32 v85, v[52:53], off offset:3904 glc         // 0000009457B0: DC524F40 557C0034
	global_load_b32 v54, v[131:132], off offset:320 glc        // 0000009457B8: DC524140 367C0083
	global_load_b32 v55, v[131:132], off offset:832 glc        // 0000009457C0: DC524340 377C0083
	global_load_b32 v48, v[131:132], off offset:1344 glc       // 0000009457C8: DC524540 307C0083
	global_load_b32 v49, v[131:132], off offset:1856 glc       // 0000009457D0: DC524740 317C0083
	global_load_b32 v42, v[131:132], off offset:2368 glc       // 0000009457D8: DC524940 2A7C0083
	global_load_b32 v43, v[131:132], off offset:2880 glc       // 0000009457E0: DC524B40 2B7C0083
	global_load_b32 v36, v[131:132], off offset:3392 glc       // 0000009457E8: DC524D40 247C0083
	global_load_b32 v37, v[131:132], off offset:3904 glc       // 0000009457F0: DC524F40 257C0083
	global_load_b32 v127, v[52:53], off offset:384 glc         // 0000009457F8: DC524180 7F7C0034
	global_load_b32 v128, v[52:53], off offset:896 glc         // 000000945800: DC524380 807C0034
	global_load_b32 v121, v[52:53], off offset:1408 glc        // 000000945808: DC524580 797C0034
	global_load_b32 v122, v[52:53], off offset:1920 glc        // 000000945810: DC524780 7A7C0034
	s_clause 0x1b                                              // 000000945818: BF85001B
	global_load_b32 v94, v[52:53], off offset:2432 glc         // 00000094581C: DC524980 5E7C0034
	global_load_b32 v95, v[52:53], off offset:2944 glc         // 000000945824: DC524B80 5F7C0034
	global_load_b32 v88, v[52:53], off offset:3456 glc         // 00000094582C: DC524D80 587C0034
	global_load_b32 v89, v[52:53], off offset:3968 glc         // 000000945834: DC524F80 597C0034
	global_load_b32 v60, v[131:132], off offset:384 glc        // 00000094583C: DC524180 3C7C0083
	global_load_b32 v61, v[131:132], off offset:896 glc        // 000000945844: DC524380 3D7C0083
	global_load_b32 v56, v[131:132], off offset:1408 glc       // 00000094584C: DC524580 387C0083
	global_load_b32 v57, v[131:132], off offset:1920 glc       // 000000945854: DC524780 397C0083
	global_load_b32 v50, v[131:132], off offset:2432 glc       // 00000094585C: DC524980 327C0083
	global_load_b32 v51, v[131:132], off offset:2944 glc       // 000000945864: DC524B80 337C0083
	global_load_b32 v44, v[131:132], off offset:3456 glc       // 00000094586C: DC524D80 2C7C0083
	global_load_b32 v45, v[131:132], off offset:3968 glc       // 000000945874: DC524F80 2D7C0083
	global_load_b32 v129, v[52:53], off offset:448 glc         // 00000094587C: DC5241C0 817C0034
	global_load_b32 v130, v[52:53], off offset:960 glc         // 000000945884: DC5243C0 827C0034
	global_load_b32 v125, v[52:53], off offset:1472 glc        // 00000094588C: DC5245C0 7D7C0034
	global_load_b32 v126, v[52:53], off offset:1984 glc        // 000000945894: DC5247C0 7E7C0034
	global_load_b32 v96, v[52:53], off offset:2496 glc         // 00000094589C: DC5249C0 607C0034
	global_load_b32 v97, v[52:53], off offset:3008 glc         // 0000009458A4: DC524BC0 617C0034
	global_load_b32 v92, v[52:53], off offset:3520 glc         // 0000009458AC: DC524DC0 5C7C0034
	global_load_b32 v93, v[52:53], off offset:4032 glc         // 0000009458B4: DC524FC0 5D7C0034
	global_load_b32 v66, v[131:132], off offset:448 glc        // 0000009458BC: DC5241C0 427C0083
	global_load_b32 v67, v[131:132], off offset:960 glc        // 0000009458C4: DC5243C0 437C0083
	global_load_b32 v62, v[131:132], off offset:1472 glc       // 0000009458CC: DC5245C0 3E7C0083
	global_load_b32 v63, v[131:132], off offset:1984 glc       // 0000009458D4: DC5247C0 3F7C0083
	global_load_b32 v58, v[131:132], off offset:2496 glc       // 0000009458DC: DC5249C0 3A7C0083
	global_load_b32 v59, v[131:132], off offset:3008 glc       // 0000009458E4: DC524BC0 3B7C0083
	global_load_b32 v52, v[131:132], off offset:3520 glc       // 0000009458EC: DC524DC0 347C0083
	global_load_b32 v53, v[131:132], off offset:4032 glc       // 0000009458F4: DC524FC0 357C0083
	s_and_saveexec_b32 s3, s0                                  // 0000009458FC: BE832000
	s_cbranch_execz 6                                          // 000000945900: BFA50006 <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_gu_tsILi4ELi2EEEvPKjPKDF16_PKiS5_S5_PDF16_PfPj+0x281c>
	s_lshl_b64 s[4:5], s[6:7], 2                               // 000000945904: 84848206
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000945908: BF870009
	s_add_u32 s4, s18, s4                                      // 00000094590C: 80040412
	s_addc_u32 s5, s19, s5                                     // 000000945910: 82050513
	global_store_b32 v98, v98, s[4:5]                          // 000000945914: DC6A0000 00046262
	s_or_b32 exec_lo, exec_lo, s3                              // 00000094591C: 8C7E037E
	s_mul_i32 s0, s8, 0xa00                                    // 000000945920: 9600FF08 00000A00
	s_mul_hi_i32 s3, s8, 0xa00                                 // 000000945928: 9703FF08 00000A00
	s_add_u32 s0, s10, s0                                      // 000000945930: 8000000A
	s_waitcnt vmcnt(14)                                        // 000000945934: BF893BF7
	v_dual_add_f32 v130, 0, v130 :: v_dual_lshlrev_b32 v131, 1, v0// 000000945938: C9230480 82820081
	s_addc_u32 s4, s11, s3                                     // 000000945940: 8204030B
	s_lshl_b32 s2, s2, 7                                       // 000000945944: 84028702
	v_dual_add_f32 v134, 0, v100 :: v_dual_lshlrev_b32 v1, 1, v1// 000000945948: C922C880 86000281
	s_ashr_i32 s3, s2, 31                                      // 000000945950: 86039F02
	v_or_b32_e32 v132, 32, v131                                // 000000945954: 390906A0
	s_lshl_b64 s[10:11], s[2:3], 1                             // 000000945958: 848A8102
	v_dual_add_f32 v133, 0, v99 :: v_dual_add_f32 v108, 0, v108// 00000094595C: C908C680 856CD880
	s_add_u32 s2, s0, s10                                      // 000000945964: 80020A00
	s_addc_u32 s3, s4, s11                                     // 000000945968: 82030B04
	v_dual_add_f32 v135, 0, v101 :: v_dual_add_f32 v112, 0, v112// 00000094596C: C908CA80 8770E080
	s_clause 0x1                                               // 000000945974: BF850001
	global_load_d16_b16 v98, v1, s[2:3]                        // 000000945978: DC820000 62020001
	global_load_d16_b16 v99, v132, s[2:3]                      // 000000945980: DC820000 63020084
	v_dual_add_f32 v111, 0, v111 :: v_dual_add_f32 v116, 0, v116// 000000945988: C908DE80 6F74E880
	v_dual_add_f32 v115, 0, v115 :: v_dual_add_f32 v120, 0, v120// 000000945990: C908E680 7378F080
	v_dual_add_f32 v127, 0, v127 :: v_dual_and_b32 v136, 1, v0 // 000000945998: C924FE80 7F880081
	v_dual_add_f32 v129, 0, v129 :: v_dual_and_b32 v100, 4, v0 // 0000009459A0: C9250280 81640084
	v_dual_add_f32 v102, v133, v102 :: v_dual_and_b32 v101, 2, v0// 0000009459A8: C924CD85 66640082
	v_dual_add_f32 v103, v134, v103 :: v_dual_and_b32 v0, 8, v0// 0000009459B0: C924CF86 67000088
	v_dual_add_f32 v104, v135, v104 :: v_dual_add_f32 v105, v108, v105// 0000009459B8: C908D187 6868D36C
	v_dual_add_f32 v106, v111, v106 :: v_dual_add_f32 v107, v112, v107// 0000009459C0: C908D56F 6A6AD770
	v_dual_add_f32 v108, v115, v109 :: v_dual_add_f32 v109, v116, v110// 0000009459C8: C908DB73 6C6CDD74
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009459D0: BF870214
	v_dual_add_f32 v102, v102, v70 :: v_dual_add_f32 v103, v103, v71// 0000009459D4: C9088D66 66668F67
	v_dual_add_f32 v74, v104, v74 :: v_dual_add_f32 v75, v105, v75// 0000009459DC: C9089568 4A4A9769
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009459E4: BF870214
	v_dual_add_f32 v104, v106, v78 :: v_dual_add_f32 v79, v107, v79// 0000009459E8: C9089D6A 684E9F6B
	v_dual_add_f32 v82, v108, v82 :: v_dual_add_f32 v83, v109, v83// 0000009459F0: C908A56C 5252A76D
	s_clause 0x6                                               // 0000009459F8: BF850006
	global_load_d16_b16 v105, v1, s[2:3] offset:1280           // 0000009459FC: DC820500 69020001
	global_load_d16_b16 v106, v1, s[2:3] offset:64             // 000000945A04: DC820040 6A020001
	global_load_d16_b16 v78, v1, s[2:3] offset:1344            // 000000945A0C: DC820540 4E020001
	global_load_d16_b16 v107, v1, s[2:3] offset:128            // 000000945A14: DC820080 6B020001
	global_load_d16_b16 v71, v1, s[2:3] offset:1408            // 000000945A1C: DC820580 47020001
	global_load_d16_b16 v70, v1, s[2:3] offset:1472            // 000000945A24: DC8205C0 46020001
	global_load_d16_b16 v108, v1, s[2:3] offset:192            // 000000945A2C: DC8200C0 6C020001
	v_dual_add_f32 v119, 0, v119 :: v_dual_add_f32 v124, 0, v124// 000000945A34: C908EE80 777CF880
	v_dual_add_f32 v123, 0, v123 :: v_dual_add_f32 v128, 0, v128// 000000945A3C: C908F680 7B810080
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000945A44: BF870112
	v_dual_add_f32 v111, v120, v114 :: v_dual_add_f32 v110, v119, v113// 000000945A48: C908E578 6F6EE377
	v_dual_add_f32 v113, v124, v118 :: v_dual_add_f32 v112, v123, v117// 000000945A50: C908ED7C 7170EB7B
	s_delay_alu instid0(VALU_DEP_3)                            // 000000945A58: BF870003
	v_dual_add_f32 v114, v127, v121 :: v_dual_add_f32 v115, v128, v122// 000000945A5C: C908F37F 7272F580
	s_waitcnt vmcnt(21)                                        // 000000945A64: BF8957F7
	v_dual_add_f32 v116, v129, v125 :: v_dual_add_f32 v117, v130, v126// 000000945A68: C908FB81 7474FD82
	v_dual_add_f32 v86, v110, v86 :: v_dual_add_f32 v87, v111, v87// 000000945A70: C908AD6E 5656AF6F
	v_dual_add_f32 v90, v112, v90 :: v_dual_add_f32 v91, v113, v91// 000000945A78: C908B570 5A5AB771
	v_dual_add_f32 v94, v114, v94 :: v_dual_add_f32 v95, v115, v95// 000000945A80: C908BD72 5E5EBF73
	s_waitcnt vmcnt(19)                                        // 000000945A88: BF894FF7
	v_dual_add_f32 v96, v116, v96 :: v_dual_add_f32 v97, v117, v97// 000000945A8C: C908C174 6060C375
	v_dual_add_f32 v102, v102, v64 :: v_dual_add_f32 v103, v103, v65// 000000945A94: C9088166 66668367
	v_dual_add_f32 v109, v74, v68 :: v_dual_add_f32 v110, v75, v69// 000000945A9C: C908894A 6D6E8B4B
	v_dual_add_f32 v104, v104, v72 :: v_dual_add_f32 v79, v79, v73// 000000945AA4: C9089168 684E934F
	v_dual_add_f32 v76, v82, v76 :: v_dual_add_f32 v77, v83, v77// 000000945AAC: C9089952 4C4C9B53
	v_dual_add_f32 v80, v86, v80 :: v_dual_add_f32 v81, v87, v81// 000000945AB4: C908A156 5050A357
	v_dual_add_f32 v82, v90, v84 :: v_dual_add_f32 v83, v91, v85// 000000945ABC: C908A95A 5252AB5B
	v_dual_add_f32 v84, v94, v88 :: v_dual_add_f32 v85, v95, v89// 000000945AC4: C908B15E 5454B35F
	s_waitcnt vmcnt(17)                                        // 000000945ACC: BF8947F7
	v_dual_add_f32 v86, v96, v92 :: v_dual_add_f32 v87, v97, v93// 000000945AD0: C908B960 5656BB61
	v_dual_add_f32 v14, v102, v14 :: v_dual_add_f32 v15, v103, v15// 000000945AD8: C9081D66 0E0E1F67
	v_dual_add_f32 v22, v109, v22 :: v_dual_add_f32 v23, v110, v23// 000000945AE0: C9082D6D 16162F6E
	v_dual_add_f32 v30, v104, v30 :: v_dual_add_f32 v31, v79, v31// 000000945AE8: C9083D68 1E1E3F4F
	v_dual_add_f32 v38, v76, v38 :: v_dual_add_f32 v39, v77, v39// 000000945AF0: C9084D4C 26264F4D
	v_dual_add_f32 v46, v80, v46 :: v_dual_add_f32 v47, v81, v47// 000000945AF8: C9085D50 2E2E5F51
	v_dual_add_f32 v54, v82, v54 :: v_dual_add_f32 v55, v83, v55// 000000945B00: C9086D52 36366F53
	v_dual_add_f32 v60, v84, v60 :: v_dual_add_f32 v61, v85, v61// 000000945B08: C9087954 3C3C7B55
	s_waitcnt vmcnt(15)                                        // 000000945B10: BF893FF7
	v_dual_add_f32 v66, v86, v66 :: v_dual_add_f32 v67, v87, v67// 000000945B14: C9088556 42428757
	s_mul_hi_i32 s0, s8, 0x500                                 // 000000945B1C: 9700FF08 00000500
	s_mulk_i32 s8, 0x500                                       // 000000945B24: B8080500
	v_dual_add_f32 v8, v14, v8 :: v_dual_add_f32 v9, v15, v9   // 000000945B28: C908110E 0808130F
	s_add_u32 s4, s12, s8                                      // 000000945B30: 8004080C
	v_dual_add_f32 v14, v22, v16 :: v_dual_add_f32 v15, v23, v17// 000000945B34: C9082116 0E0E2317
	v_dual_add_f32 v16, v30, v24 :: v_dual_add_f32 v17, v31, v25// 000000945B3C: C908311E 1010331F
	v_dual_add_f32 v22, v38, v32 :: v_dual_add_f32 v23, v39, v33// 000000945B44: C9084126 16164327
	v_dual_add_f32 v24, v46, v40 :: v_dual_add_f32 v25, v47, v41// 000000945B4C: C908512E 1818532F
	v_dual_add_f32 v30, v54, v48 :: v_dual_add_f32 v31, v55, v49// 000000945B54: C9086136 1E1E6337
	v_dual_add_f32 v32, v60, v56 :: v_dual_add_f32 v33, v61, v57// 000000945B5C: C908713C 2020733D
	s_waitcnt vmcnt(13)                                        // 000000945B64: BF8937F7
	v_dual_add_f32 v38, v66, v62 :: v_dual_add_f32 v39, v67, v63// 000000945B68: C9087D42 26267F43
	v_or_b32_e32 v118, 0x60, v131                              // 000000945B70: 38ED06FF 00000060
	s_addc_u32 s0, s13, s0                                     // 000000945B78: 8200000D
	s_add_u32 s4, s4, s10                                      // 000000945B7C: 80040A04
	s_addc_u32 s5, s0, s11                                     // 000000945B80: 82050B00
	v_or_b32_e32 v119, 0xa0, v131                              // 000000945B84: 38EF06FF 000000A0
	v_or_b32_e32 v120, 0xe0, v131                              // 000000945B8C: 38F106FF 000000E0
	s_clause 0x1                                               // 000000945B94: BF850001
	global_load_d16_b16 v88, v132, s[2:3] offset:1280          // 000000945B98: DC820500 58020084
	global_load_d16_b16 v89, v132, s[4:5]                      // 000000945BA0: DC820000 59040084
	s_clause 0x2                                               // 000000945BA8: BF850002
	global_load_d16_b16 v90, v118, s[2:3]                      // 000000945BAC: DC820000 5A020076
	global_load_d16_b16 v75, v118, s[2:3] offset:1280          // 000000945BB4: DC820500 4B020076
	global_load_d16_b16 v72, v118, s[4:5]                      // 000000945BBC: DC820000 48040076
	s_clause 0x6                                               // 000000945BC4: BF850006
	global_load_d16_b16 v91, v119, s[2:3]                      // 000000945BC8: DC820000 5B020077
	global_load_d16_b16 v74, v119, s[2:3] offset:1280          // 000000945BD0: DC820500 4A020077
	global_load_d16_b16 v73, v119, s[4:5]                      // 000000945BD8: DC820000 49040077
	global_load_d16_b16 v65, v1, s[4:5]                        // 000000945BE0: DC820000 41040001
	global_load_d16_b16 v68, v1, s[4:5] offset:64              // 000000945BE8: DC820040 44040001
	global_load_d16_b16 v69, v1, s[4:5] offset:128             // 000000945BF0: DC820080 45040001
	global_load_d16_b16 v64, v1, s[4:5] offset:192             // 000000945BF8: DC8200C0 40040001
	s_clause 0x2                                               // 000000945C00: BF850002
	global_load_d16_b16 v92, v120, s[2:3]                      // 000000945C04: DC820000 5C020078
	global_load_d16_b16 v93, v120, s[2:3] offset:1280          // 000000945C0C: DC820500 5D020078
	global_load_d16_b16 v94, v120, s[4:5]                      // 000000945C14: DC820000 5E040078
	v_dual_add_f32 v4, v8, v4 :: v_dual_add_f32 v5, v9, v5     // 000000945C1C: C9080908 04040B09
	v_dual_add_f32 v8, v14, v10 :: v_dual_add_f32 v9, v15, v11 // 000000945C24: C908150E 0808170F
	v_dual_add_f32 v10, v16, v18 :: v_dual_add_f32 v11, v17, v19// 000000945C2C: C9082510 0A0A2711
	v_dual_add_f32 v14, v22, v26 :: v_dual_add_f32 v15, v23, v27// 000000945C34: C9083516 0E0E3717
	v_dual_add_f32 v16, v24, v34 :: v_dual_add_f32 v17, v25, v35// 000000945C3C: C9084518 10104719
	v_dual_add_f32 v18, v30, v42 :: v_dual_add_f32 v19, v31, v43// 000000945C44: C908551E 1212571F
	v_dual_add_f32 v22, v32, v50 :: v_dual_add_f32 v23, v33, v51// 000000945C4C: C9086520 16166721
	s_waitcnt vmcnt(26)                                        // 000000945C54: BF896BF7
	v_dual_add_f32 v24, v38, v58 :: v_dual_add_f32 v25, v39, v59// 000000945C58: C9087526 18187727
	v_dual_add_f32 v2, v4, v2 :: v_dual_add_f32 v3, v5, v3     // 000000945C60: C9080504 02020705
	v_dual_add_f32 v4, v8, v6 :: v_dual_add_f32 v5, v9, v7     // 000000945C68: C9080D08 04040F09
	v_dual_add_f32 v6, v10, v12 :: v_dual_add_f32 v7, v11, v13 // 000000945C70: C908190A 06061B0B
	v_dual_add_f32 v8, v14, v20 :: v_dual_add_f32 v9, v15, v21 // 000000945C78: C908290E 08082B0F
	v_dual_add_f32 v10, v16, v28 :: v_dual_add_f32 v11, v17, v29// 000000945C80: C9083910 0A0A3B11
	v_dual_add_f32 v12, v18, v36 :: v_dual_add_f32 v13, v19, v37// 000000945C88: C9084912 0C0C4B13
	v_dual_add_f32 v14, v22, v44 :: v_dual_add_f32 v15, v23, v45// 000000945C90: C9085916 0E0E5B17
	s_waitcnt vmcnt(24)                                        // 000000945C98: BF8963F7
	v_dual_add_f32 v16, v24, v52 :: v_dual_add_f32 v17, v25, v53// 000000945C9C: C9086918 10106B19
	v_add_f32_e32 v18, v2, v4                                  // 000000945CA4: 06240902
	v_sub_f32_e32 v2, v2, v4                                   // 000000945CA8: 08040902
	v_add_f32_e32 v4, v6, v8                                   // 000000945CAC: 06081106
	v_sub_f32_e32 v6, v6, v8                                   // 000000945CB0: 080C1106
	v_add_f32_e32 v8, v10, v12                                 // 000000945CB4: 0610190A
	v_sub_f32_e32 v10, v10, v12                                // 000000945CB8: 0814190A
	v_add_f32_e32 v12, v14, v16                                // 000000945CBC: 0618210E
	v_sub_f32_e32 v14, v14, v16                                // 000000945CC0: 081C210E
	v_add_f32_e32 v16, v3, v5                                  // 000000945CC4: 06200B03
	v_sub_f32_e32 v3, v3, v5                                   // 000000945CC8: 08060B03
	v_add_f32_e32 v5, v7, v9                                   // 000000945CCC: 060A1307
	v_sub_f32_e32 v7, v7, v9                                   // 000000945CD0: 080E1307
	v_add_f32_e32 v9, v11, v13                                 // 000000945CD4: 06121B0B
	v_sub_f32_e32 v11, v11, v13                                // 000000945CD8: 08161B0B
	v_add_f32_e32 v13, v15, v17                                // 000000945CDC: 061A230F
	v_sub_f32_e32 v15, v15, v17                                // 000000945CE0: 081E230F
	v_add_f32_e32 v17, v18, v4                                 // 000000945CE4: 06220912
	v_sub_f32_e32 v4, v18, v4                                  // 000000945CE8: 08080912
	v_add_f32_e32 v18, v2, v6                                  // 000000945CEC: 06240D02
	v_sub_f32_e32 v2, v2, v6                                   // 000000945CF0: 08040D02
	v_add_f32_e32 v6, v8, v12                                  // 000000945CF4: 060C1908
	v_sub_f32_e32 v8, v8, v12                                  // 000000945CF8: 08101908
	v_add_f32_e32 v12, v10, v14                                // 000000945CFC: 06181D0A
	v_sub_f32_e32 v10, v10, v14                                // 000000945D00: 08141D0A
	v_add_f32_e32 v14, v16, v5                                 // 000000945D04: 061C0B10
	v_dual_sub_f32 v5, v16, v5 :: v_dual_add_f32 v16, v3, v7   // 000000945D08: C9480B10 05100F03
	v_add_f32_e32 v19, v9, v13                                 // 000000945D10: 06261B09
	v_sub_f32_e32 v3, v3, v7                                   // 000000945D14: 08060F03
	v_sub_f32_e32 v7, v9, v13                                  // 000000945D18: 080E1B09
	v_add_f32_e32 v9, v11, v15                                 // 000000945D1C: 06121F0B
	v_sub_f32_e32 v11, v11, v15                                // 000000945D20: 08161F0B
	.long 0xd44a0000                                           // 000000945D24: D44A0000
	v_cndmask_b32_e32 v1, 0, v136, vcc_lo                      // 000000945D28: 02031080
	v_add_f32_e32 v21, v4, v8                                  // 000000945D2C: 062A1104
	.long 0xd44a0002                                           // 000000945D30: D44A0002
	v_cndmask_b32_e32 v1, 0, v101, vcc_lo                      // 000000945D34: 0202CA80
	v_add_f32_e32 v15, v16, v9                                 // 000000945D38: 061E1310
	v_dual_sub_f32 v9, v16, v9 :: v_dual_add_f32 v16, v5, v7   // 000000945D3C: C9481310 09100F05
	v_sub_f32_e32 v5, v5, v7                                   // 000000945D44: 080A0F05
	v_dual_add_f32 v7, v3, v11 :: v_dual_add_f32 v20, v2, v10  // 000000945D48: C9081703 07141502
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000945D50: BF870214
	v_mov_b32_dpp v23, v15 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000945D54: 7E2E02FA FF01610F
	v_mov_b32_dpp v24, v16 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000945D5C: 7E3002FA FF016110
	v_cndmask_b32_e64 v16, -v16, v16, s0                       // 000000945D64: D5010010 20022110
	v_add_f32_e32 v13, v14, v19                                // 000000945D6C: 061A270E
	v_dual_sub_f32 v14, v14, v19 :: v_dual_add_f32 v19, v17, v6// 000000945D70: C948270E 0E120D11
	v_cndmask_b32_e64 v15, -v15, v15, s0                       // 000000945D78: D501000F 20021F0F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000945D80: BF870214
	v_add_f32_e32 v16, v16, v24                                // 000000945D84: 06203110
	v_mov_b32_dpp v22, v13 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000945D88: 7E2C02FA FF01610D
	s_delay_alu instid0(VALU_DEP_4)                            // 000000945D90: BF870004
	v_mov_b32_dpp v26, v14 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000945D94: 7E3402FA FF01610E
	v_cndmask_b32_e64 v14, -v14, v14, s0                       // 000000945D9C: D501000E 20021D0E
	v_sub_f32_e32 v3, v3, v11                                  // 000000945DA4: 08061703
	v_cndmask_b32_e64 v13, -v13, v13, s0                       // 000000945DA8: D501000D 20021B0D
	v_mov_b32_dpp v24, v16 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000945DB0: 7E3002FA FF016210
	v_cndmask_b32_e64 v16, -v16, v16, s2                       // 000000945DB8: D5010010 200A2110
	v_add_f32_e32 v14, v14, v26                                // 000000945DC0: 061C350E
	v_mov_b32_dpp v25, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000945DC4: 7E3202FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, s0                          // 000000945DCC: D5010007 20020F07
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000945DD4: BF870214
	v_dual_add_f32 v13, v13, v22 :: v_dual_add_f32 v16, v16, v24// 000000945DD8: C9082D0D 0D103110
	v_mov_b32_dpp v26, v14 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000945DE0: 7E3402FA FF01620E
	v_cndmask_b32_e64 v14, -v14, v14, s2                       // 000000945DE8: D501000E 200A1D0E
	.long 0xd44a0004                                           // 000000945DF0: D44A0004
	v_cndmask_b32_e32 v1, 0, v100, vcc_lo                      // 000000945DF4: 0202C880
	v_mov_b32_dpp v27, v9 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000945DF8: 7E3602FA FF016109
	v_cndmask_b32_e64 v9, -v9, v9, s0                          // 000000945E00: D5010009 20021309
	s_delay_alu instid0(VALU_DEP_4)                            // 000000945E08: BF870004
	v_dual_add_f32 v15, v15, v23 :: v_dual_add_f32 v14, v14, v26// 000000945E0C: C9082F0F 0F0E350E
	v_mov_b32_dpp v24, v16 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000945E14: 7E3002FA FF016410
	v_cndmask_b32_e64 v16, -v16, v16, s4                       // 000000945E1C: D5010010 20122110
	v_add_f32_e32 v7, v7, v25                                  // 000000945E24: 060E3307
	v_add_f32_e32 v11, v18, v12                                // 000000945E28: 06161912
	v_mov_b32_dpp v26, v14 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000945E2C: 7E3402FA FF01640E
	v_cndmask_b32_e64 v14, -v14, v14, s4                       // 000000945E34: D501000E 20121D0E
	v_dual_add_f32 v9, v9, v27 :: v_dual_add_f32 v16, v16, v24 // 000000945E3C: C9083709 09103110
	v_mov_b32_dpp v25, v7 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000945E44: 7E3202FA FF016207
	v_cndmask_b32_e64 v7, -v7, v7, s2                          // 000000945E4C: D5010007 200A0F07
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000945E54: BF870214
	v_add_f32_e32 v14, v14, v26                                // 000000945E58: 061C350E
	v_mov_b32_dpp v27, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000945E5C: 7E3602FA FF016209
	v_cndmask_b32_e64 v9, -v9, v9, s2                          // 000000945E64: D5010009 200A1309
	v_mov_b32_dpp v31, v11 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000945E6C: 7E3E02FA FF01610B
	v_add_f32_e32 v7, v7, v25                                  // 000000945E74: 060E3307
	v_cndmask_b32_e64 v11, -v11, v11, s0                       // 000000945E78: D501000B 2002170B
	v_mov_b32_dpp v33, v20 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000945E80: 7E4202FA FF016114
	v_cndmask_b32_e64 v20, -v20, v20, s0                       // 000000945E88: D5010014 20022914
	v_add_f32_e32 v9, v9, v27                                  // 000000945E90: 06123709
	v_mov_b32_dpp v25, v7 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000945E94: 7E3202FA FF016407
	v_cndmask_b32_e64 v7, -v7, v7, s4                          // 000000945E9C: D5010007 20120F07
	.long 0xd44a0003                                           // 000000945EA4: D44A0003
	v_cndmask_b32_e32 v1, 0, v0, vcc_lo                        // 000000945EA8: 02020080
	v_mov_b32_dpp v30, v19 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000945EAC: 7E3C02FA FF016113
	v_cndmask_b32_e64 v19, -v19, v19, s0                       // 000000945EB4: D5010013 20022713
	v_add_f32_e32 v20, v20, v33                                // 000000945EBC: 06284314
	v_mov_b32_dpp v27, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000945EC0: 7E3602FA FF016409
	v_cndmask_b32_e64 v9, -v9, v9, s4                          // 000000945EC8: D5010009 20121309
	v_add_f32_e32 v7, v7, v25                                  // 000000945ED0: 060E3307
	v_mov_b32_dpp v25, v16 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000945ED4: 7E3202FA FF016810
	v_cndmask_b32_e64 v16, -v16, v16, s3                       // 000000945EDC: D5010010 200E2110
	v_add_f32_e32 v11, v11, v31                                // 000000945EE4: 06163F0B
	v_add_f32_e32 v9, v9, v27                                  // 000000945EE8: 06123709
	v_mov_b32_dpp v27, v14 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000945EEC: 7E3602FA FF01680E
	v_cndmask_b32_e64 v14, -v14, v14, s3                       // 000000945EF4: D501000E 200E1D0E
	v_dual_add_f32 v19, v19, v30 :: v_dual_add_f32 v16, v16, v25// 000000945EFC: C9083D13 13103310
	v_mov_b32_dpp v31, v11 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000945F04: 7E3E02FA FF01620B
	v_cndmask_b32_e64 v11, -v11, v11, s2                       // 000000945F0C: D501000B 200A170B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000945F14: BF870214
	v_add_f32_e32 v14, v14, v27                                // 000000945F18: 061C370E
	v_mov_b32_dpp v30, v19 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000945F1C: 7E3C02FA FF016213
	v_cndmask_b32_e64 v19, -v19, v19, s2                       // 000000945F24: D5010013 200A2713
	v_mov_b32_dpp v29, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000945F2C: 7E3A02FA FF016103
	v_add_f32_e32 v11, v11, v31                                // 000000945F34: 06163F0B
	v_cndmask_b32_e64 v3, -v3, v3, s0                          // 000000945F38: D5010003 20020703
	v_mov_b32_dpp v32, v21 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000945F40: 7E4002FA FF016115
	v_cndmask_b32_e64 v21, -v21, v21, s0                       // 000000945F48: D5010015 20022B15
	v_add_f32_e32 v19, v19, v30                                // 000000945F50: 06263D13
	v_mov_b32_dpp v30, v11 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000945F54: 7E3C02FA FF01640B
	v_cndmask_b32_e64 v11, -v11, v11, s4                       // 000000945F5C: D501000B 2012170B
	v_add_f32_e32 v3, v3, v29                                  // 000000945F64: 06063B03
	v_dual_add_f32 v21, v21, v32 :: v_dual_mul_f32 v14, 0x3db504f3, v14// 000000945F68: C9064115 150E1CFF 3DB504F3
	v_mov_b32_dpp v28, v5 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000945F74: 7E3802FA FF016105
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000945F7C: BF870214
	v_add_f32_e32 v11, v11, v30                                // 000000945F80: 06163D0B
	v_mov_b32_dpp v29, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000945F84: 7E3A02FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, s2                          // 000000945F8C: D5010003 200A0703
	v_mov_b32_dpp v32, v21 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000945F94: 7E4002FA FF016215
	v_cndmask_b32_e64 v21, -v21, v21, s2                       // 000000945F9C: D5010015 200A2B15
	v_mov_b32_dpp v30, v11 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000945FA4: 7E3C02FA FF01680B
	v_cndmask_b32_e64 v11, -v11, v11, s3                       // 000000945FAC: D501000B 200E170B
	v_cndmask_b32_e64 v5, -v5, v5, s0                          // 000000945FB4: D5010005 20020B05
	v_mov_b32_dpp v22, v13 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000945FBC: 7E2C02FA FF01620D
	v_add_f32_e32 v21, v21, v32                                // 000000945FC4: 062A4115
	v_mov_b32_dpp v32, v20 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000945FC8: 7E4002FA FF016214
	v_dual_add_f32 v11, v11, v30 :: v_dual_sub_f32 v4, v4, v8  // 000000945FD0: C90A3D0B 0B041104
	v_cndmask_b32_e64 v20, -v20, v20, s2                       // 000000945FD8: D5010014 200A2914
	v_add_f32_e32 v3, v3, v29                                  // 000000945FE0: 06063B03
	v_mov_b32_dpp v29, v19 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000945FE4: 7E3A02FA FF016413
	v_cndmask_b32_e64 v19, -v19, v19, s4                       // 000000945FEC: D5010013 20122713
	v_cndmask_b32_e64 v13, -v13, v13, s2                       // 000000945FF4: D501000D 200A1B0D
	v_dual_mul_f32 v11, 0x3db504f3, v11 :: v_dual_add_f32 v20, v20, v32// 000000945FFC: C8C816FF 0B144114 3DB504F3
	v_mov_b32_dpp v0, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000946008: 7E0002FA FF016403
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000946010: BF8701B4
	v_dual_add_f32 v19, v19, v29 :: v_dual_sub_f32 v6, v17, v6 // 000000946014: C90A3B13 13060D11
	v_cndmask_b32_e64 v3, -v3, v3, s4                          // 00000094601C: D5010003 20120703
	v_dual_add_f32 v13, v13, v22 :: v_dual_sub_f32 v12, v18, v12// 000000946024: C90A2D0D 0D0C1912
	v_mov_b32_dpp v29, v19 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000094602C: 7E3A02FA FF016813
	v_cndmask_b32_e64 v19, -v19, v19, s3                       // 000000946034: D5010013 200E2713
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000094603C: BF870214
	v_add_f32_e32 v0, v3, v0                                   // 000000946040: 06000103
	v_mov_b32_dpp v22, v13 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000946044: 7E2C02FA FF01640D
	v_cndmask_b32_e64 v13, -v13, v13, s4                       // 00000094604C: D501000D 20121B0D
	v_mov_b32_dpp v23, v15 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000946054: 7E2E02FA FF01620F
	v_add_f32_e32 v19, v19, v29                                // 00000094605C: 06263B13
	v_mov_b32_dpp v30, v0 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000946060: 7E3C02FA FF016800
	v_cndmask_b32_e64 v0, -v0, v0, s3                          // 000000946068: D5010000 200E0100
	v_add_f32_e32 v13, v13, v22                                // 000000946070: 061A2D0D
	v_cndmask_b32_e64 v15, -v15, v15, s2                       // 000000946074: D501000F 200A1F0F
	v_dual_mul_f32 v19, 0x3db504f3, v19 :: v_dual_mul_f32 v16, 0x3db504f3, v16// 00000094607C: C8C626FF 131020FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_4)                            // 000000946088: BF870004
	v_add_f32_e32 v0, v0, v30                                  // 00000094608C: 06003D00
	v_mov_b32_dpp v30, v20 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000946090: 7E3C02FA FF016414
	v_cndmask_b32_e64 v20, -v20, v20, s4                       // 000000946098: D5010014 20122914
	v_cndmask_b32_e64 v22, -v13, v13, s3                       // 0000009460A0: D5010016 200E1B0D
	v_mov_b32_dpp v13, v13 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009460A8: 7E1A02FA FF01680D
	v_dual_add_f32 v15, v15, v23 :: v_dual_mul_f32 v0, 0x3db504f3, v0// 0000009460B0: C9062F0F 0F0000FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_4)                            // 0000009460BC: BF870004
	v_add_f32_e32 v20, v20, v30                                // 0000009460C0: 06283D14
	v_mov_b32_dpp v31, v21 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009460C4: 7E3E02FA FF016415
	v_cndmask_b32_e64 v21, -v21, v21, s4                       // 0000009460CC: D5010015 20122B15
	v_add_f32_e32 v13, v22, v13                                // 0000009460D4: 061A1B16
	v_mov_b32_dpp v23, v15 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009460D8: 7E2E02FA FF01640F
	v_cndmask_b32_e64 v15, -v15, v15, s4                       // 0000009460E0: D501000F 20121F0F
	v_sub_f32_e32 v2, v2, v10                                  // 0000009460E8: 08041502
	s_waitcnt vmcnt(23)                                        // 0000009460EC: BF895FF7
	v_fma_mix_f32 v19, v98, v19, neg(0) op_sel_hi:[1,0,0]      // 0000009460F0: CC200013 8A022762
	s_waitcnt vmcnt(22)                                        // 0000009460F8: BF895BF7
	v_fma_mix_f32 v3, v99, v11, neg(0) op_sel_hi:[1,0,0]       // 0000009460FC: CC200003 8A021763
	v_add_f32_e32 v5, v5, v28                                  // 000000946104: 060A3905
	v_add_f32_e32 v11, v21, v31                                // 000000946108: 06163F15
	v_mul_f32_e32 v21, 0xbfb8aa3b, v19                         // 00000094610C: 102A26FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000946114: BF870214
	v_mul_f32_e32 v24, 0xbfb8aa3b, v3                          // 000000946118: 103006FF BFB8AA3B
	v_mov_b32_dpp v28, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000946120: 7E3802FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, s2                          // 000000946128: D5010005 200A0B05
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000946130: BF870194
	v_exp_f32_e32 v21, v21                                     // 000000946134: 7E2A4B15
	v_exp_f32_e32 v24, v24                                     // 000000946138: 7E304B18
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000094613C: BF870091
	v_add_f32_e32 v5, v5, v28                                  // 000000946140: 060A3905
	v_mov_b32_dpp v28, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000946144: 7E3802FA FF016405
	v_cndmask_b32_e64 v5, -v5, v5, s4                          // 00000094614C: D5010005 20120B05
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000946154: BF870115
	v_dual_add_f32 v21, 1.0, v21 :: v_dual_add_f32 v24, 1.0, v24// 000000946158: C9082AF2 151830F2
	v_add_f32_e32 v5, v5, v28                                  // 000000946160: 060A3905
	s_waitcnt vmcnt(19)                                        // 000000946164: BF894FF7
	v_fma_mix_f32 v16, v78, v16, neg(0) op_sel_hi:[1,0,0]      // 000000946168: CC200010 8A02214E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000946170: BF870193
	v_div_scale_f32 v22, null, v21, v21, v19                   // 000000946174: D6FC7C16 044E2B15
	v_mov_b32_dpp v29, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000094617C: 7E3A02FA FF016805
	v_cndmask_b32_e64 v5, -v5, v5, s3                          // 000000946184: D5010005 200E0B05
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000094618C: BF870093
	v_rcp_f32_e32 v25, v22                                     // 000000946190: 7E325516
	v_add_f32_e32 v5, v5, v29                                  // 000000946194: 060A3B05
	v_div_scale_f32 v29, vcc_lo, v19, v21, v19                 // 000000946198: D6FC6A1D 044E2B13
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000009461A0: BF870095
	v_fma_f32 v27, -v22, v25, 1.0                              // 0000009461A4: D613001B 23CA3316
	v_fmac_f32_e32 v25, v27, v25                               // 0000009461AC: 5632331B
	v_mov_b32_dpp v27, v11 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009461B0: 7E3602FA FF01680B
	v_cndmask_b32_e64 v11, -v11, v11, s3                       // 0000009461B8: D501000B 200E170B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009461C0: BF870211
	v_add_f32_e32 v11, v11, v27                                // 0000009461C4: 0616370B
	v_mul_f32_e32 v27, v29, v25                                // 0000009461C8: 1036331D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000009461CC: BF870112
	v_mul_f32_e32 v11, 0x3db504f3, v11                         // 0000009461D0: 101616FF 3DB504F3
	v_fma_f32 v33, -v22, v27, v29                              // 0000009461D8: D6130021 24763716
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000009461E0: BF870092
	v_fma_mix_f32 v11, v106, v11, neg(0) op_sel_hi:[1,0,0]     // 0000009461E4: CC20000B 8A02176A
	v_dual_fmac_f32 v27, v33, v25 :: v_dual_mul_f32 v32, 0xbfb8aa3b, v11// 0000009461EC: C8063321 1B2016FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000009461F8: BF870091
	v_fma_f32 v22, -v22, v27, v29                              // 0000009461FC: D6130016 24763716
	v_div_fmas_f32 v22, v22, v25, v27                          // 000000946204: D6370016 046E3316
	v_mov_b32_dpp v25, v20 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000094620C: 7E3202FA FF016814
	v_cndmask_b32_e64 v20, -v20, v20, s3                       // 000000946214: D5010014 200E2914
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000094621C: BF8701A3
	v_div_fixup_f32 v19, v22, v21, v19                         // 000000946220: D6270013 044E2B16
	v_mov_b32_dpp v22, v12 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000946228: 7E2C02FA FF01610C
	v_add_f32_e32 v20, v20, v25                                // 000000946230: 06283314
	v_cndmask_b32_e64 v12, -v12, v12, s0                       // 000000946234: D501000C 2002190C
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000094623C: BF870232
	v_mul_f32_e32 v17, 0x3db504f3, v20                         // 000000946240: 102228FF 3DB504F3
	v_mov_b32_dpp v20, v6 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000946248: 7E2802FA FF016106
	v_cndmask_b32_e64 v6, -v6, v6, s0                          // 000000946250: D5010006 20020D06
	v_dual_add_f32 v15, v15, v23 :: v_dual_add_f32 v12, v12, v22// 000000946258: C9082F0F 0F0C2D0C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000946260: BF870112
	v_add_f32_e32 v6, v6, v20                                  // 000000946264: 060C2906
	v_mov_b32_dpp v23, v15 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000946268: 7E2E02FA FF01680F
	v_cndmask_b32_e64 v15, -v15, v15, s3                       // 000000946270: D501000F 200E1F0F
	s_delay_alu instid0(VALU_DEP_4)                            // 000000946278: BF870004
	v_mov_b32_dpp v22, v12 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000094627C: 7E2C02FA FF01620C
	v_cndmask_b32_e64 v12, -v12, v12, s2                       // 000000946284: D501000C 200A190C
	v_mov_b32_dpp v20, v6 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000094628C: 7E2802FA FF016206
	v_cndmask_b32_e64 v6, -v6, v6, s2                          // 000000946294: D5010006 200A0D06
	v_add_f32_e32 v15, v15, v23                                // 00000094629C: 061E2F0F
	v_div_scale_f32 v23, null, v24, v24, v3                    // 0000009462A0: D6FC7C17 040E3118
	v_add_f32_e32 v12, v12, v22                                // 0000009462A8: 06182D0C
	v_mov_b32_dpp v26, v7 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009462AC: 7E3402FA FF016807
	v_cndmask_b32_e64 v7, -v7, v7, s3                          // 0000009462B4: D5010007 200E0F07
	v_add_f32_e32 v6, v6, v20                                  // 0000009462BC: 060C2906
	v_mov_b32_dpp v28, v9 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009462C0: 7E3802FA FF016809
	v_cndmask_b32_e64 v9, -v9, v9, s3                          // 0000009462C8: D5010009 200E1309
	v_mov_b32_dpp v20, v12 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009462D0: 7E2802FA FF01640C
	v_add_f32_e32 v7, v7, v26                                  // 0000009462D8: 060E3507
	v_rcp_f32_e32 v26, v23                                     // 0000009462DC: 7E345517
	v_cndmask_b32_e64 v12, -v12, v12, s4                       // 0000009462E0: D501000C 2012190C
	v_add_f32_e32 v9, v9, v28                                  // 0000009462E8: 06123909
	s_waitcnt vmcnt(1)                                         // 0000009462EC: BF8907F7
	v_fma_mix_f32 v0, v93, v0, neg(0) op_sel_hi:[1,0,0]        // 0000009462F0: CC200000 8A02015D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000009462F8: BF870293
	v_dual_add_f32 v12, v12, v20 :: v_dual_mul_f32 v13, 0x3db504f3, v13// 0000009462FC: C906290C 0C0C1AFF 3DB504F3
	v_fma_f32 v28, -v23, v26, 1.0                              // 000000946308: D613001C 23CA3517
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000946310: BF870112
	v_fma_mix_f32 v13, v105, v13, neg(0) op_sel_hi:[1,0,0]     // 000000946314: CC20000D 8A021B69
	v_fmac_f32_e32 v26, v28, v26                               // 00000094631C: 5634351C
	v_div_scale_f32 v28, s5, v3, v24, v3                       // 000000946320: D6FC051C 040E3103
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000946328: BF870123
	v_mul_f32_e32 v13, v13, v19                                // 00000094632C: 101A270D
	s_mov_b32 vcc_lo, s5                                       // 000000946330: BEEA0005
	v_mul_f32_e32 v31, v28, v26                                // 000000946334: 103E351C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000946338: BF870091
	v_fma_f32 v34, -v23, v31, v28                              // 00000094633C: D6130022 24723F17
	v_fmac_f32_e32 v31, v34, v26                               // 000000946344: 563E3522
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000946348: BF8700A1
	v_fma_f32 v23, -v23, v31, v28                              // 00000094634C: D6130017 24723F17
	v_exp_f32_e32 v28, v32                                     // 000000946354: 7E384B20
	v_div_fmas_f32 v23, v23, v26, v31                          // 000000946358: D6370017 047E3517
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000946360: BF870291
	v_div_fixup_f32 v3, v23, v24, v3                           // 000000946364: D6270003 040E3117
	v_add_f32_e32 v26, 1.0, v28                                // 00000094636C: 063438F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000946370: BF870121
	v_div_scale_f32 v21, null, v26, v26, v11                   // 000000946374: D6FC7C15 042E351A
	v_div_scale_f32 v8, vcc_lo, v11, v26, v11                  // 00000094637C: D6FC6A08 042E350B
	v_rcp_f32_e32 v18, v21                                     // 000000946384: 7E245515
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000946388: BF870095
	v_fma_f32 v19, -v21, v18, 1.0                              // 00000094638C: D6130013 23CA2515
	v_fmac_f32_e32 v18, v19, v18                               // 000000946394: 56242513
	v_mov_b32_dpp v19, v4 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000946398: 7E2602FA FF016104
	v_cndmask_b32_e64 v4, -v4, v4, s0                          // 0000009463A0: D5010004 20020904
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000009463A8: BF8701B1
	v_add_f32_e32 v4, v4, v19                                  // 0000009463AC: 06082704
	v_mov_b32_dpp v19, v2 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009463B0: 7E2602FA FF016102
	v_cndmask_b32_e64 v2, -v2, v2, s0                          // 0000009463B8: D5010002 20020502
	v_mov_b32_dpp v22, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009463C0: 7E2C02FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, s2                          // 0000009463C8: D5010004 200A0904
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000009463D0: BF870113
	v_add_f32_e32 v2, v2, v19                                  // 0000009463D4: 06042702
	v_dual_add_f32 v4, v4, v22 :: v_dual_mul_f32 v15, 0x3db504f3, v15// 0000009463D8: C9062D04 040E1EFF 3DB504F3
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000009463E4: BF870111
	v_mov_b32_dpp v20, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009463E8: 7E2802FA FF016404
	v_fma_mix_f32 v15, v88, v15, neg(0) op_sel_hi:[1,0,0]      // 0000009463F0: CC20000F 8A021F58
	v_cndmask_b32_e64 v4, -v4, v4, s4                          // 0000009463F8: D5010004 20120904
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000946400: BF8700A2
	v_mul_f32_e32 v3, v15, v3                                  // 000000946404: 1006070F
	v_fma_mix_f32 v15, v90, v17, neg(0) op_sel_hi:[1,0,0]      // 000000946408: CC20000F 8A02235A
	v_dual_add_f32 v4, v4, v20 :: v_dual_mul_f32 v17, 0xbfb8aa3b, v15// 000000946410: C9062904 04101EFF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000094641C: BF8700B1
	v_exp_f32_e32 v10, v17                                     // 000000946420: 7E144B11
	v_mov_b32_dpp v17, v6 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000946424: 7E2202FA FF016406
	v_cndmask_b32_e64 v6, -v6, v6, s4                          // 00000094642C: D5010006 20120D06
	v_add_f32_e32 v6, v6, v17                                  // 000000946434: 060C2306
	v_mov_b32_dpp v17, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000946438: 7E2202FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, s2                          // 000000946440: D5010002 200A0502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000946448: BF870215
	v_add_f32_e32 v10, 1.0, v10                                // 00000094644C: 061414F2
	v_mov_b32_dpp v19, v6 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000946450: 7E2602FA FF016806
	v_cndmask_b32_e64 v6, -v6, v6, s3                          // 000000946458: D5010006 200E0D06
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000946460: BF870234
	v_add_f32_e32 v2, v2, v17                                  // 000000946464: 06042302
	v_mov_b32_dpp v17, v12 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000946468: 7E2202FA FF01680C
	v_cndmask_b32_e64 v12, -v12, v12, s3                       // 000000946470: D501000C 200E190C
	v_add_f32_e32 v6, v6, v19                                  // 000000946478: 060C2706
	s_delay_alu instid0(VALU_DEP_4)                            // 00000094647C: BF870004
	v_mov_b32_dpp v19, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000946480: 7E2602FA FF016402
	v_cndmask_b32_e64 v2, -v2, v2, s4                          // 000000946488: D5010002 20120502
	v_mul_f32_e32 v9, 0x3db504f3, v9                           // 000000946490: 101212FF 3DB504F3
	v_add_f32_e32 v12, v12, v17                                // 000000946498: 0618230C
	v_mov_b32_dpp v17, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000094649C: 7E2202FA FF016804
	v_cndmask_b32_e64 v4, -v4, v4, s3                          // 0000009464A4: D5010004 200E0904
	v_add_f32_e32 v2, v2, v19                                  // 0000009464AC: 06042702
	v_dual_mul_f32 v7, 0x3db504f3, v7 :: v_dual_mul_f32 v6, 0x3db504f3, v6// 0000009464B0: C8C60EFF 07060CFF 3DB504F3
	v_dual_mul_f32 v5, 0x3db504f3, v5 :: v_dual_mul_f32 v12, 0x3db504f3, v12// 0000009464BC: C8C60AFF 050C18FF 3DB504F3
	v_div_scale_f32 v19, null, v10, v10, v15                   // 0000009464C8: D6FC7C13 043E150A
	v_add_f32_e32 v4, v4, v17                                  // 0000009464D0: 06082304
	v_mov_b32_dpp v17, v2 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009464D4: 7E2202FA FF016802
	v_cndmask_b32_e64 v2, -v2, v2, s3                          // 0000009464DC: D5010002 200E0502
	v_fma_mix_f32 v6, v107, v6, neg(0) op_sel_hi:[1,0,0]       // 0000009464E4: CC200006 8A020D6B
	v_rcp_f32_e32 v20, v19                                     // 0000009464EC: 7E285513
	v_fma_mix_f32 v12, v91, v12, neg(0) op_sel_hi:[1,0,0]      // 0000009464F0: CC20000C 8A02195B
	v_mul_f32_e32 v4, 0x3db504f3, v4                           // 0000009464F8: 100808FF 3DB504F3
	v_add_f32_e32 v2, v2, v17                                  // 000000946500: 06042302
	v_mul_f32_e32 v22, 0xbfb8aa3b, v6                          // 000000946504: 102C0CFF BFB8AA3B
	v_fma_mix_f32 v5, v70, v5, neg(0) op_sel_hi:[1,0,0]        // 00000094650C: CC200005 8A020B46
	v_mul_f32_e32 v17, v8, v18                                 // 000000946514: 10222508
	v_mul_f32_e32 v23, 0xbfb8aa3b, v12                         // 000000946518: 102E18FF BFB8AA3B
	v_mul_f32_e32 v2, 0x3db504f3, v2                           // 000000946520: 100404FF 3DB504F3
	v_fma_mix_f32 v4, v108, v4, neg(0) op_sel_hi:[1,0,0]       // 000000946528: CC200004 8A02096C
	v_exp_f32_e32 v22, v22                                     // 000000946530: 7E2C4B16
	v_fma_f32 v24, -v21, v17, v8                               // 000000946534: D6130018 24222315
	v_fma_f32 v25, -v19, v20, 1.0                              // 00000094653C: D6130019 23CA2913
	v_exp_f32_e32 v23, v23                                     // 000000946544: 7E2E4B17
	v_fma_mix_f32 v2, v92, v2, neg(0) op_sel_hi:[1,0,0]        // 000000946548: CC200002 8A02055C
	v_mul_f32_e32 v27, 0xbfb8aa3b, v4                          // 000000946550: 103608FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000946558: BF870223
	v_dual_fmac_f32 v17, v24, v18 :: v_dual_fmac_f32 v20, v25, v20// 00000094655C: C8002518 11142919
	v_fma_mix_f32 v7, v75, v7, neg(0) op_sel_hi:[1,0,0]        // 000000946564: CC200007 8A020F4B
	v_mul_f32_e32 v25, 0xbfb8aa3b, v2                          // 00000094656C: 103204FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(TRANS32_DEP_2)// 000000946574: BF870334
	v_exp_f32_e32 v24, v27                                     // 000000946578: 7E304B1B
	v_add_f32_e32 v22, 1.0, v22                                // 00000094657C: 062C2CF2
	v_fma_f32 v8, -v21, v17, v8                                // 000000946580: D6130008 24222315
	v_add_f32_e32 v21, 1.0, v23                                // 000000946588: 062A2EF2
	v_exp_f32_e32 v23, v25                                     // 00000094658C: 7E2E4B19
	v_div_scale_f32 v27, s5, v15, v10, v15                     // 000000946590: D6FC051B 043E150F
	v_div_scale_f32 v28, null, v22, v22, v6                    // 000000946598: D6FC7C1C 041A2D16
	v_div_fmas_f32 v8, v8, v18, v17                            // 0000009465A0: D6370008 04462508
	v_div_scale_f32 v30, null, v21, v21, v12                   // 0000009465A8: D6FC7C1E 04322B15
	s_mov_b32 vcc_lo, s5                                       // 0000009465B0: BEEA0005
	v_add_f32_e32 v24, 1.0, v24                                // 0000009465B4: 063030F2
	v_mul_f32_e32 v25, v27, v20                                // 0000009465B8: 1032291B
	v_rcp_f32_e32 v29, v28                                     // 0000009465BC: 7E3A551C
	v_rcp_f32_e32 v31, v30                                     // 0000009465C0: 7E3E551E
	v_add_f32_e32 v23, 1.0, v23                                // 0000009465C4: 062E2EF2
	v_div_scale_f32 v17, null, v24, v24, v4                    // 0000009465C8: D6FC7C11 04123118
	v_fma_f32 v18, -v19, v25, v27                              // 0000009465D0: D6130012 246E3313
	v_div_fixup_f32 v8, v8, v26, v11                           // 0000009465D8: D6270008 042E3508
	v_div_scale_f32 v11, s6, v6, v22, v6                       // 0000009465E0: D6FC060B 041A2D06
	v_div_scale_f32 v34, null, v23, v23, v2                    // 0000009465E8: D6FC7C22 040A2F17
	v_rcp_f32_e32 v33, v17                                     // 0000009465F0: 7E425511
	v_fmac_f32_e32 v25, v18, v20                               // 0000009465F4: 56322912
	v_fma_f32 v32, -v28, v29, 1.0                              // 0000009465F8: D6130020 23CA3B1C
	v_fma_f32 v26, -v30, v31, 1.0                              // 000000946600: D613001A 23CA3F1E
	v_rcp_f32_e32 v18, v34                                     // 000000946608: 7E245522
	v_mul_f32_e32 v8, v16, v8                                  // 00000094660C: 10101110
	v_fma_f32 v19, -v19, v25, v27                              // 000000946610: D6130013 246E3313
	v_fmac_f32_e32 v29, v32, v29                               // 000000946618: 563A3B20
	v_fmac_f32_e32 v31, v26, v31                               // 00000094661C: 563E3F1A
	v_div_scale_f32 v26, s7, v12, v21, v12                     // 000000946620: D6FC071A 04322B0C
	v_fma_f32 v16, -v17, v33, 1.0                              // 000000946628: D6130010 23CA4311
	v_div_fmas_f32 v19, v19, v20, v25                          // 000000946630: D6370013 04662913
	v_mul_f32_e32 v27, v11, v29                                // 000000946638: 10363B0B
	s_mov_b32 vcc_lo, s6                                       // 00000094663C: BEEA0006
	v_fma_f32 v32, -v34, v18, 1.0                              // 000000946640: D6130020 23CA2522
	v_fmac_f32_e32 v33, v16, v33                               // 000000946648: 56424310
	v_div_scale_f32 v16, s8, v4, v24, v4                       // 00000094664C: D6FC0810 04123104
	v_fma_f32 v20, -v28, v27, v11                              // 000000946654: D6130014 242E371C
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000094665C: BF870224
	v_dual_mul_f32 v25, v26, v31 :: v_dual_fmac_f32 v18, v32, v18// 000000946660: C8C03F1A 19122520
	v_div_scale_f32 v32, s5, v2, v23, v2                       // 000000946668: D6FC0520 040A2F02
	v_mul_f32_e32 v35, v16, v33                                // 000000946670: 10464310
	v_div_fixup_f32 v10, v19, v10, v15                         // 000000946674: D627000A 043E1513
	v_fmac_f32_e32 v27, v20, v29                               // 00000094667C: 56363B14
	v_fma_f32 v15, -v30, v25, v26                              // 000000946680: D613000F 246A331E
	v_mul_f32_e32 v20, v32, v18                                // 000000946688: 10282520
	v_fma_f32 v19, -v17, v35, v16                              // 00000094668C: D6130013 24424711
	v_mul_f32_e32 v7, v7, v10                                  // 000000946694: 100E1507
	v_fma_f32 v11, -v28, v27, v11                              // 000000946698: D613000B 242E371C
	v_fmac_f32_e32 v25, v15, v31                               // 0000009466A0: 56323F0F
	v_fma_f32 v15, -v34, v20, v32                              // 0000009466A4: D613000F 24822922
	v_fmac_f32_e32 v35, v19, v33                               // 0000009466AC: 56464313
	v_fma_mix_f32 v9, v74, v9, neg(0) op_sel_hi:[1,0,0]        // 0000009466B0: CC200009 8A02134A
	v_div_fmas_f32 v11, v11, v29, v27                          // 0000009466B8: D637000B 046E3B0B
	v_fma_f32 v19, -v30, v25, v26                              // 0000009466C0: D6130013 246A331E
	v_fmac_f32_e32 v20, v15, v18                               // 0000009466C8: 5628250F
	v_fma_f32 v15, -v17, v35, v16                              // 0000009466CC: D613000F 24424711
	s_mov_b32 vcc_lo, s7                                       // 0000009466D4: BEEA0007
	v_div_fixup_f32 v6, v11, v22, v6                           // 0000009466D8: D6270006 041A2D0B
	v_div_fmas_f32 v16, v19, v31, v25                          // 0000009466E0: D6370010 04663F13
	v_fma_f32 v17, -v34, v20, v32                              // 0000009466E8: D6130011 24822922
	s_mov_b32 vcc_lo, s8                                       // 0000009466F0: BEEA0008
	v_fma_mix_f32 v3, v89, v3, neg(0) op_sel_hi:[1,0,0]        // 0000009466F4: CC200003 8A020759
	v_div_fmas_f32 v15, v15, v33, v35                          // 0000009466FC: D637000F 048E430F
	s_mov_b32 vcc_lo, s5                                       // 000000946704: BEEA0005
	v_div_fixup_f32 v10, v16, v21, v12                         // 000000946708: D627000A 04322B10
	v_div_fmas_f32 v17, v17, v18, v20                          // 000000946710: D6370011 04522511
	v_fma_mix_f32 v12, v71, v14, neg(0) op_sel_hi:[1,0,0]      // 000000946718: CC20000C 8A021D47
	v_div_fixup_f32 v4, v15, v24, v4                           // 000000946720: D6270004 0412310F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000946728: BF870214
	v_mul_f32_e32 v9, v9, v10                                  // 00000094672C: 10121509
	v_div_fixup_f32 v2, v17, v23, v2                           // 000000946730: D6270002 040A2F11
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000946738: BF870214
	v_mul_f32_e32 v6, v12, v6                                  // 00000094673C: 100C0D0C
	v_mul_f32_e32 v4, v5, v4                                   // 000000946740: 10080905
	v_fma_mix_f32 v5, v13, v65, v3 op_sel_hi:[0,1,0]           // 000000946744: CC200005 140E830D
	v_fma_mix_f32 v3, v13, v65, -v3 op_sel_hi:[0,1,0]          // 00000094674C: CC200003 940E830D
	v_mul_f32_e32 v0, v0, v2                                   // 000000946754: 10000500
	v_fma_mix_f32 v2, v72, v7, neg(0) op_sel_hi:[1,0,0]        // 000000946758: CC200002 8A020F48
	v_fma_mix_f32 v7, v73, v9, neg(0) op_sel_hi:[1,0,0]        // 000000946760: CC200007 8A021349
	s_waitcnt vmcnt(0)                                         // 000000946768: BF8903F7
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000094676C: BF870193
	v_fma_mix_f32 v0, v94, v0, neg(0) op_sel_hi:[1,0,0]        // 000000946770: CC200000 8A02015E
	v_fma_mix_f32 v9, v8, v68, v2 op_sel_hi:[0,1,0]            // 000000946778: CC200009 140A8908
	s_delay_alu instid0(VALU_DEP_3)                            // 000000946780: BF870003
	v_fma_mix_f32 v10, v6, v69, v7 op_sel_hi:[0,1,0]           // 000000946784: CC20000A 141E8B06
	v_fma_mix_f32 v2, v8, v68, -v2 op_sel_hi:[0,1,0]           // 00000094678C: CC200002 940A8908
	v_fma_mix_f32 v6, v6, v69, -v7 op_sel_hi:[0,1,0]           // 000000946794: CC200006 941E8B06
	v_fma_mix_f32 v11, v4, v64, v0 op_sel_hi:[0,1,0]           // 00000094679C: CC20000B 14028104
	v_add_f32_e32 v7, v5, v9                                   // 0000009467A4: 060E1305
	v_fma_mix_f32 v0, v4, v64, -v0 op_sel_hi:[0,1,0]           // 0000009467A8: CC200000 94028104
	v_dual_sub_f32 v4, v5, v9 :: v_dual_add_f32 v5, v3, v2     // 0000009467B0: C9481305 04040503
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000009467B8: BF870224
	v_add_f32_e32 v8, v10, v11                                 // 0000009467BC: 0610170A
	v_dual_sub_f32 v2, v3, v2 :: v_dual_sub_f32 v9, v10, v11   // 0000009467C0: C94A0503 0208170A
	v_add_f32_e32 v10, v6, v0                                  // 0000009467C8: 06140106
	v_sub_f32_e32 v0, v6, v0                                   // 0000009467CC: 08000106
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000009467D0: BF870224
	v_add_f32_e32 v3, v7, v8                                   // 0000009467D4: 06061107
	v_sub_f32_e32 v6, v7, v8                                   // 0000009467D8: 080C1107
	v_add_f32_e32 v8, v5, v10                                  // 0000009467DC: 06101505
	v_sub_f32_e32 v10, v5, v10                                 // 0000009467E0: 08141505
	s_delay_alu instid0(VALU_DEP_4)                            // 0000009467E4: BF870004
	v_mov_b32_dpp v7, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009467E8: 7E0E02FA FF016103
	v_cndmask_b32_e64 v3, -v3, v3, s0                          // 0000009467F0: D5010003 20020703
	v_add_f32_e32 v5, v4, v9                                   // 0000009467F8: 060A1304
	v_sub_f32_e32 v9, v4, v9                                   // 0000009467FC: 08121304
	v_mov_b32_dpp v4, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000946800: 7E0802FA FF016108
	v_mov_b32_dpp v14, v6 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000946808: 7E1C02FA FF016106
	v_add_f32_e32 v3, v3, v7                                   // 000000946810: 06060F03
	v_cndmask_b32_e64 v7, -v8, v8, s0                          // 000000946814: D5010007 20021108
	v_mov_b32_dpp v8, v5 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000094681C: 7E1002FA FF016105
	v_cndmask_b32_e64 v5, -v5, v5, s0                          // 000000946824: D5010005 20020B05
	v_cndmask_b32_e64 v15, -v6, v6, s0                         // 00000094682C: D501000F 20020D06
	v_mov_b32_dpp v11, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000946834: 7E1602FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, s2                          // 00000094683C: D5010003 200A0703
	v_add_f32_e32 v4, v7, v4                                   // 000000946844: 06080907
	v_add_f32_e32 v5, v5, v8                                   // 000000946848: 060A1105
	v_add_f32_e32 v7, v2, v0                                   // 00000094684C: 060E0102
	v_sub_f32_e32 v8, v2, v0                                   // 000000946850: 08100102
	v_add_f32_e32 v0, v3, v11                                  // 000000946854: 06001703
	v_mov_b32_dpp v2, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000946858: 7E0402FA FF016204
	v_cndmask_b32_e64 v3, -v4, v4, s2                          // 000000946860: D5010003 200A0904
	v_mov_b32_dpp v4, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000946868: 7E0802FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, s2                          // 000000946870: D5010005 200A0B05
	v_mov_b32_dpp v11, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000946878: 7E1602FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, s0                          // 000000946880: D5010007 20020F07
	v_add_f32_e32 v2, v3, v2                                   // 000000946888: 06040503
	v_mov_b32_dpp v16, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000094688C: 7E2002FA FF016108
	v_add_f32_e32 v4, v5, v4                                   // 000000946894: 06080905
	v_cndmask_b32_e64 v8, -v8, v8, s0                          // 000000946898: D5010008 20021108
	v_add_f32_e32 v5, v7, v11                                  // 0000009468A0: 060A1707
	v_mov_b32_dpp v7, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009468A4: 7E0E02FA FF016402
	v_cndmask_b32_e64 v2, -v2, v2, s4                          // 0000009468AC: D5010002 20120502
	v_mov_b32_dpp v11, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009468B4: 7E1602FA FF016404
	v_cndmask_b32_e64 v12, -v4, v4, s4                         // 0000009468BC: D501000C 20120904
	v_mov_b32_dpp v13, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009468C4: 7E1A02FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, s2                          // 0000009468CC: D5010005 200A0B05
	v_add_f32_e32 v4, v2, v7                                   // 0000009468D4: 06080F02
	v_add_f32_e32 v8, v8, v16                                  // 0000009468D8: 06102108
	v_dual_add_f32 v6, v12, v11 :: v_dual_add_f32 v11, v15, v14// 0000009468DC: C908170C 060A1D0F
	v_mov_b32_dpp v14, v10 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009468E4: 7E1C02FA FF01610A
	v_cndmask_b32_e64 v10, -v10, v10, s0                       // 0000009468EC: D501000A 2002150A
	v_mov_b32_dpp v15, v9 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009468F4: 7E1E02FA FF016109
	v_cndmask_b32_e64 v9, -v9, v9, s0                          // 0000009468FC: D5010009 20021309
	v_add_f32_e32 v7, v5, v13                                  // 000000946904: 060E1B05
	v_mov_b32_dpp v13, v11 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000946908: 7E1A02FA FF01620B
	v_cndmask_b32_e64 v11, -v11, v11, s2                       // 000000946910: D501000B 200A170B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000946918: BF870234
	v_dual_add_f32 v10, v10, v14 :: v_dual_add_f32 v9, v9, v15 // 00000094691C: C9081D0A 0A081F09
	v_mov_b32_dpp v15, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000946924: 7E1E02FA FF016208
	v_cndmask_b32_e64 v8, -v8, v8, s2                          // 00000094692C: D5010008 200A1108
	v_add_f32_e32 v11, v11, v13                                // 000000946934: 06161B0B
	s_delay_alu instid0(VALU_DEP_4)                            // 000000946938: BF870004
	v_mov_b32_dpp v13, v10 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000094693C: 7E1A02FA FF01620A
	v_cndmask_b32_e64 v10, -v10, v10, s2                       // 000000946944: D501000A 200A150A
	v_mov_b32_dpp v14, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000094694C: 7E1C02FA FF016209
	v_cndmask_b32_e64 v9, -v9, v9, s2                          // 000000946954: D5010009 200A1309
	v_add_f32_e32 v8, v8, v15                                  // 00000094695C: 06101F08
	v_mov_b32_dpp v3, v0 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000946960: 7E0602FA FF016400
	v_add_f32_e32 v10, v10, v13                                // 000000946968: 06141B0A
	v_cndmask_b32_e64 v0, -v0, v0, s4                          // 00000094696C: D5010000 20120100
	v_add_f32_e32 v9, v9, v14                                  // 000000946974: 06121D09
	v_mov_b32_dpp v12, v7 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000946978: 7E1802FA FF016407
	v_cndmask_b32_e64 v7, -v7, v7, s4                          // 000000946980: D5010007 20120F07
	v_mov_b32_dpp v13, v11 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000946988: 7E1A02FA FF01640B
	v_cndmask_b32_e64 v11, -v11, v11, s4                       // 000000946990: D501000B 2012170B
	v_mov_b32_dpp v14, v10 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000946998: 7E1C02FA FF01640A
	v_cndmask_b32_e64 v15, -v10, v10, s4                       // 0000009469A0: D501000F 2012150A
	v_mov_b32_dpp v16, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009469A8: 7E2002FA FF016409
	v_cndmask_b32_e64 v17, -v9, v9, s4                         // 0000009469B0: D5010011 20121309
	v_mov_b32_dpp v18, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009469B8: 7E2402FA FF016408
	v_cndmask_b32_e64 v8, -v8, v8, s4                          // 0000009469C0: D5010008 20121108
	v_dual_add_f32 v0, v0, v3 :: v_dual_add_f32 v9, v7, v12    // 0000009469C8: C9080700 00081907
	v_add_f32_e32 v10, v11, v13                                // 0000009469D0: 06141B0B
	v_add_f32_e32 v11, v15, v14                                // 0000009469D4: 06161D0F
	v_add_f32_e32 v13, v17, v16                                // 0000009469D8: 061A2111
	v_add_f32_e32 v15, v8, v18                                 // 0000009469DC: 061E2508
	v_mov_b32_dpp v2, v0 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009469E0: 7E0402FA FF016800
	v_mov_b32_dpp v3, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009469E8: 7E0602FA FF016804
	v_mov_b32_dpp v5, v6 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009469F0: 7E0A02FA FF016806
	v_mov_b32_dpp v7, v9 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009469F8: 7E0E02FA FF016809
	v_mov_b32_dpp v8, v10 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000946A00: 7E1002FA FF01680A
	v_mov_b32_dpp v12, v11 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000946A08: 7E1802FA FF01680B
	v_mov_b32_dpp v14, v13 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000946A10: 7E1C02FA FF01680D
	v_mov_b32_dpp v16, v15 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000946A18: 7E2002FA FF01680F
	s_mov_b32 s0, 0x3db504f3                                   // 000000946A20: BE8000FF 3DB504F3
	s_and_b32 exec_lo, exec_lo, s1                             // 000000946A28: 8B7E017E
	s_cbranch_execz 65                                         // 000000946A2C: BFA50041 <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_gu_tsILi4ELi2EEEvPKjPKDF16_PKiS5_S5_PDF16_PfPj+0x3a34>
	v_cndmask_b32_e64 v15, -v15, v15, s3                       // 000000946A30: D501000F 200E1F0F
	v_cndmask_b32_e64 v0, -v0, v0, s3                          // 000000946A38: D5010000 200E0100
	v_cndmask_b32_e64 v4, -v4, v4, s3                          // 000000946A40: D5010004 200E0904
	v_cndmask_b32_e64 v6, -v6, v6, s3                          // 000000946A48: D5010006 200E0D06
	v_cndmask_b32_e64 v9, -v9, v9, s3                          // 000000946A50: D5010009 200E1309
	v_cndmask_b32_e64 v13, -v13, v13, s3                       // 000000946A58: D501000D 200E1B0D
	v_cndmask_b32_e64 v10, -v10, v10, s3                       // 000000946A60: D501000A 200E150A
	v_cndmask_b32_e64 v11, -v11, v11, s3                       // 000000946A68: D501000B 200E170B
	v_dual_add_f32 v15, v15, v16 :: v_dual_add_f32 v0, v0, v2  // 000000946A70: C908210F 0F000500
	v_add_f32_e32 v3, v4, v3                                   // 000000946A78: 06060704
	v_add_f32_e32 v5, v6, v5                                   // 000000946A7C: 060A0B06
	v_add_f32_e32 v7, v9, v7                                   // 000000946A80: 060E0F09
	s_mul_i32 s1, s20, 0x500                                   // 000000946A84: 9601FF14 00000500
	v_dual_add_f32 v13, v13, v14 :: v_dual_add_f32 v8, v10, v8 // 000000946A8C: C9081D0D 0D08110A
	s_mul_hi_i32 s2, s20, 0x500                                // 000000946A94: 9702FF14 00000500
	v_add_f32_e32 v11, v11, v12                                // 000000946A9C: 0616190B
	s_add_u32 s1, s14, s1                                      // 000000946AA0: 8001010E
	v_fma_mixlo_f16 v0, v0, s0, 0                              // 000000946AA4: CC210000 02000100
	s_addc_u32 s3, s15, s2                                     // 000000946AAC: 8203020F
	v_fma_mixhi_f16 v0, v3, s0, 0                              // 000000946AB0: CC220000 02000103
	s_add_u32 s2, s1, s10                                      // 000000946AB8: 80020A01
	v_fma_mixlo_f16 v2, v5, s0, 0                              // 000000946ABC: CC210002 02000105
	s_addc_u32 s3, s3, s11                                     // 000000946AC4: 82030B03
	v_fma_mixhi_f16 v2, v7, s0, 0                              // 000000946AC8: CC220002 02000107
	v_fma_mixlo_f16 v3, v8, s0, 0                              // 000000946AD0: CC210003 02000108
	v_fma_mixhi_f16 v3, v11, s0, 0                             // 000000946AD8: CC220003 0200010B
	v_fma_mixlo_f16 v4, v13, s0, 0                             // 000000946AE0: CC210004 0200010D
	v_fma_mixhi_f16 v4, v15, s0, 0                             // 000000946AE8: CC220004 0200010F
	s_clause 0x7                                               // 000000946AF0: BF850007
	global_store_b16 v1, v0, s[2:3]                            // 000000946AF4: DC660000 00020001
	global_store_d16_hi_b16 v1, v0, s[2:3] offset:32           // 000000946AFC: DC960020 00020001
	global_store_b16 v1, v2, s[2:3] offset:64                  // 000000946B04: DC660040 00020201
	global_store_d16_hi_b16 v1, v2, s[2:3] offset:96           // 000000946B0C: DC960060 00020201
	global_store_b16 v1, v3, s[2:3] offset:128                 // 000000946B14: DC660080 00020301
	global_store_d16_hi_b16 v1, v3, s[2:3] offset:160          // 000000946B1C: DC9600A0 00020301
	global_store_b16 v1, v4, s[2:3] offset:192                 // 000000946B24: DC6600C0 00020401
	global_store_d16_hi_b16 v1, v4, s[2:3] offset:224          // 000000946B2C: DC9600E0 00020401
	s_nop 0                                                    // 000000946B34: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 000000946B38: BFB60003
	s_endpgm                                                   // 000000946B3C: BFB00000
		...

