0000000000569200 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi2ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi2ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 000000569200: F4100100 F8000000
	s_ashr_i32 s3, s2, 31                                      // 000000569208: 86039F02
	v_lshrrev_b32_e32 v2, 2, v0                                // 00000056920C: 32040082
	s_lshl_b64 s[2:3], s[2:3], 2                               // 000000569210: 84828202
	v_and_b32_e32 v1, 15, v0                                   // 000000569214: 3602008F
	v_mov_b32_e32 v5, 0                                        // 000000569218: 7E0A0280
	v_lshrrev_b32_e32 v14, 6, v0                               // 00000056921C: 321C0086
	v_and_b32_e32 v2, 60, v2                                   // 000000569220: 360404BC
	s_delay_alu instid0(VALU_DEP_4)                            // 000000569224: BF870004
	v_dual_mov_b32 v6, 0 :: v_dual_lshlrev_b32 v1, 2, v1       // 000000569228: CA220080 06000282
	v_bfe_u32 v15, v0, 5, 1                                    // 000000569230: D610000F 02050B00
	v_dual_mov_b32 v17, 0 :: v_dual_and_b32 v16, 31, v0        // 000000569238: CA240080 1110009F
	.long 0x7f103880                                           // 000000569240: 7F103880
	s_waitcnt lgkmcnt(0)                                       // 000000569244: BF89FC07
	s_clause 0x1                                               // 000000569248: BF850001
	global_load_b32 v3, v1, s[4:5]                             // 00000056924C: DC520000 03040001
	global_load_b32 v4, v2, s[4:5]                             // 000000569254: DC520000 04040002
	v_mov_b32_e32 v2, s3                                       // 00000056925C: 7E040203
	v_or_b32_e32 v1, s2, v14                                   // 000000569260: 38021C02
	s_add_u32 s0, s4, s14                                      // 000000569264: 80000E04
	s_addc_u32 s1, s5, s15                                     // 000000569268: 82010F05
	s_lshr_b32 s14, s11, 31                                    // 00000056926C: 850E9F0B
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000569270: BF870009
	s_add_u32 s14, s10, s14                                    // 000000569274: 800E0E0A
	s_addc_u32 s15, s11, 0                                     // 000000569278: 820F800B
	s_ashr_i32 s20, s11, 31                                    // 00000056927C: 86149F0B
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[1:2]                  // 000000569280: 7CA8020C
	s_lshr_b32 s20, s20, 27                                    // 000000569284: 85149B14
	s_ashr_i64 s[14:15], s[14:15], 1                           // 000000569288: 868E810E
	s_add_u32 s20, s10, s20                                    // 00000056928C: 8014140A
	s_addc_u32 s21, s11, 0                                     // 000000569290: 8215800B
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 000000569294: 02020280
	s_lshr_b64 s[20:21], s[20:21], 5                           // 000000569298: 85948514
	v_cndmask_b32_e64 v7, 0, s3, vcc_lo                        // 00000056929C: D5010007 01A80680
	s_add_i32 s21, s20, 1                                      // 0000005692A4: 81158114
	s_delay_alu instid0(VALU_DEP_2)                            // 0000005692A8: BF870002
	.long 0xd72c0002                                           // 0000005692AC: D72C0002
	v_cndmask_b32_e32 v1, s19, v1, vcc_lo                      // 0000005692B0: 02020213
	s_lshr_b32 s19, s21, 31                                    // 0000005692B4: 85139F15
	.long 0xd72c000d                                           // 0000005692B8: D72C000D
	v_cndmask_b32_e32 v0, v1, v15, vcc_lo                      // 0000005692BC: 02001F01
	s_add_i32 s21, s21, s19                                    // 0000005692C0: 81151315
	v_mad_u64_u32 v[9:10], null, v1, s14, s[0:1]               // 0000005692C4: D6FE7C09 00001D01
	s_ashr_i32 s15, s21, 1                                     // 0000005692CC: 860F8115
	s_add_u32 s0, s4, s16                                      // 0000005692D0: 80001004
	.long 0xd72c0012                                           // 0000005692D4: D72C0012
	v_cndmask_b32_e32 v1, s15, v15, vcc_lo                     // 0000005692D8: 02021E0F
	s_addc_u32 s1, s5, s17                                     // 0000005692DC: 82011105
	.long 0xd72c0014                                           // 0000005692E0: D72C0014
	v_cndmask_b32_e32 v0, v7, v14, vcc_lo                      // 0000005692E4: 02001D07
	.long 0xd72c0015                                           // 0000005692E8: D72C0015
	v_cndmask_b32_e32 v1, s18, v7, vcc_lo                      // 0000005692EC: 02020E12
	v_mov_b32_e32 v29, 0                                       // 0000005692F0: 7E3A0280
	v_mov_b32_e32 v7, 0                                        // 0000005692F4: 7E0E0280
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 0000005692F8: BF870154
	v_add3_u32 v10, v20, v10, v13                              // 0000005692FC: D655000A 04361514
	s_waitcnt vmcnt(1)                                         // 000000569304: BF8907F7
	v_bfe_u32 v11, v3, 16, 1                                   // 000000569308: D610000B 02052103
	s_waitcnt vmcnt(0)                                         // 000000569310: BF8903F7
	v_bfe_u32 v19, v4, 16, 1                                   // 000000569314: D6100013 02052104
	v_add3_u32 v3, v3, v11, 0x7fff                             // 00000056931C: D6550003 03FE1703 00007FFF
	v_mad_u64_u32 v[11:12], null, s18, v1, s[0:1]              // 000000569328: D6FE7C0B 00020212
	v_add_nc_u32_e32 v1, s15, v18                              // 000000569330: 4A02240F
	s_delay_alu instid0(VALU_DEP_4)                            // 000000569334: BF870004
	v_add3_u32 v4, v4, v19, 0x7fff                             // 000000569338: D6550004 03FE2704 00007FFF
	v_add_nc_u32_e32 v18, v18, v16                             // 000000569344: 4A242112
	.long 0x7e103983                                           // 000000569348: 7E103983
	v_lshlrev_b32_e32 v3, 2, v0                                // 00000056934C: 30060082
	v_min_i32_e32 v19, s20, v1                                 // 000000569350: 22260214
	v_add3_u32 v20, v2, v12, v21                               // 000000569354: D6550014 04561902
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000056935C: BF870224
	v_and_or_b32 v1, 0xffff0000, v4, v8                        // 000000569360: D6570001 042208FF FFFF0000
	v_mov_b32_e32 v8, 0                                        // 00000056936C: 7E100280
	v_cmp_lt_i32_e32 vcc_lo, v18, v19                          // 000000569370: 7C822712
	ds_store_b32 v3, v1                                        // 000000569374: D8340000 00000103
	s_waitcnt lgkmcnt(0)                                       // 00000056937C: BF89FC07
	s_barrier                                                  // 000000569380: BFBD0000
	buffer_gl0_inv                                             // 000000569384: E0AC0000 00000000
	s_and_saveexec_b32 s1, vcc_lo                              // 00000056938C: BE81206A
	s_cbranch_execz 21                                         // 000000569390: BFA50015 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi2ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x1e8>
	v_lshlrev_b32_e32 v1, 1, v18                               // 000000569394: 30022481
	v_lshlrev_b32_e32 v3, 4, v18                               // 000000569398: 30062484
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000056939C: BF870112
	v_ashrrev_i32_e32 v2, 31, v1                               // 0000005693A0: 3404029F
	v_ashrrev_i32_e32 v4, 31, v3                               // 0000005693A4: 3408069F
	.long 0xd7000001                                           // 0000005693A8: D7000001
	v_cndmask_b32_e32 v1, v11, v1, vcc_lo                      // 0000005693AC: 0202030B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000005693B0: BF8700A1
	v_add_co_ci_u32_e64 v2, null, v20, v2, s0                  // 0000005693B4: D5207C02 00020514
	.long 0xd7000003                                           // 0000005693BC: D7000003
	v_cndmask_b32_e32 v1, v9, v3, vcc_lo                       // 0000005693C0: 02020709
	v_add_co_ci_u32_e64 v4, null, v10, v4, s0                  // 0000005693C4: D5207C04 0002090A
	s_clause 0x1                                               // 0000005693CC: BF850001
	global_load_d16_b16 v1, v[1:2], off                        // 0000005693D0: DC820000 017C0001
	global_load_b128 v[5:8], v[3:4], off                       // 0000005693D8: DC5E0000 057C0003
	s_waitcnt vmcnt(1)                                         // 0000005693E0: BF8907F7
	v_cvt_f32_f16_e32 v29, v1                                  // 0000005693E4: 7E3A1701
	s_or_b32 exec_lo, exec_lo, s1                              // 0000005693E8: 8C7E017E
	v_dual_mov_b32 v22, 0 :: v_dual_mov_b32 v23, 0             // 0000005693EC: CA100080 16160080
	v_dual_mov_b32 v24, 0 :: v_dual_mov_b32 v25, 0             // 0000005693F4: CA100080 18180080
	v_mov_b32_e32 v21, 0                                       // 0000005693FC: 7E2A0280
	s_and_saveexec_b32 s1, vcc_lo                              // 000000569400: BE81206A
	s_cbranch_execz 519                                        // 000000569404: BFA50207 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi2ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0xa24>
	v_dual_mov_b32 v24, 0 :: v_dual_add_nc_u32 v1, 32, v18     // 000000569408: CA200080 180024A0
	v_dual_mov_b32 v21, 0 :: v_dual_lshlrev_b32 v12, 5, v18    // 000000569410: CA220080 150C2485
	v_dual_mov_b32 v23, 0 :: v_dual_mov_b32 v28, v29           // 000000569418: CA100080 171C011D
	s_delay_alu instid0(VALU_DEP_3)                            // 000000569420: BF870003
	v_dual_mov_b32 v25, 0 :: v_dual_lshlrev_b32 v26, 4, v1     // 000000569424: CA220080 191A0284
	v_dual_mov_b32 v22, 0 :: v_dual_lshlrev_b32 v27, 1, v1     // 00000056942C: CA220080 161A0281
	v_mov_b32_e32 v17, 0                                       // 000000569434: 7E220280
	s_mul_i32 s0, s11, 6                                       // 000000569438: 9600860B
	s_mul_hi_u32 s14, s10, 6                                   // 00000056943C: 968E860A
	s_lshl_b64 s[4:5], s[10:11], 2                             // 000000569440: 8484820A
	s_add_i32 s14, s14, s0                                     // 000000569444: 810E000E
	s_mul_i32 s16, s10, 6                                      // 000000569448: 9610860A
	s_mov_b32 s15, 0                                           // 00000056944C: BE8F0080
	s_lshl_b64 s[10:11], s[10:11], 1                           // 000000569450: 848A810A
	s_branch 467                                               // 000000569454: BFA001D3 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi2ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x9a4>
	s_or_b32 exec_lo, exec_lo, s17                             // 000000569458: 8C7E117E
	v_and_b32_e32 v13, 0xff, v5                                // 00000056945C: 361A0AFF 000000FF
	s_and_b32 s0, exec_lo, vcc_lo                              // 000000569464: 8B006A7E
	v_add_nc_u32_e32 v26, 0x200, v26                           // 000000569468: 4A3434FF 00000200
	s_or_b32 s15, s0, s15                                      // 000000569470: 8C0F0F00
	v_add_nc_u32_e32 v27, 64, v27                              // 000000569474: 4A3636C0
	v_lshlrev_b32_e32 v13, 2, v13                              // 000000569478: 301A1A82
	ds_load_b32 v46, v13                                       // 00000056947C: D8D80000 2E00000D
	v_lshrrev_b32_e32 v13, 6, v5                               // 000000569484: 321A0A86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000569488: BF870141
	v_and_b32_e32 v13, 0x3fc, v13                              // 00000056948C: 361A1AFF 000003FC
	ds_load_b32 v47, v13                                       // 000000569494: D8D80000 2F00000D
	v_lshrrev_b32_e32 v13, 14, v5                              // 00000056949C: 321A0A8E
	v_lshrrev_b32_e32 v5, 22, v5                               // 0000005694A0: 320A0A96
	v_and_b32_e32 v13, 0x3fc, v13                              // 0000005694A4: 361A1AFF 000003FC
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 0000005694AC: BF870152
	v_and_b32_e32 v5, 0x3fc, v5                                // 0000005694B0: 360A0AFF 000003FC
	ds_load_b32 v48, v13                                       // 0000005694B8: D8D80000 3000000D
	ds_load_b32 v49, v5                                        // 0000005694C0: D8D80000 31000005
	v_and_b32_e32 v5, 0xff, v6                                 // 0000005694C8: 360A0CFF 000000FF
	v_ashrrev_i32_e32 v13, 31, v12                             // 0000005694D0: 341A189F
	v_lshlrev_b32_e32 v5, 2, v5                                // 0000005694D4: 300A0A82
	ds_load_b32 v50, v5                                        // 0000005694D8: D8D80000 32000005
	v_lshrrev_b32_e32 v5, 6, v6                                // 0000005694E0: 320A0C86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000005694E4: BF8700B1
	v_and_b32_e32 v5, 0x3fc, v5                                // 0000005694E8: 360A0AFF 000003FC
	ds_load_b32 v51, v5                                        // 0000005694F0: D8D80000 33000005
	v_lshrrev_b32_e32 v5, 14, v6                               // 0000005694F8: 320A0C8E
	v_and_b32_e32 v5, 0x3fc, v5                                // 0000005694FC: 360A0AFF 000003FC
	ds_load_b32 v52, v5                                        // 000000569504: D8D80000 34000005
	v_lshrrev_b32_e32 v5, 22, v6                               // 00000056950C: 320A0C96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000569510: BF8700B1
	v_and_b32_e32 v5, 0x3fc, v5                                // 000000569514: 360A0AFF 000003FC
	ds_load_b32 v53, v5                                        // 00000056951C: D8D80000 35000005
	v_and_b32_e32 v5, 0xff, v7                                 // 000000569524: 360A0EFF 000000FF
	v_lshlrev_b32_e32 v5, 2, v5                                // 00000056952C: 300A0A82
	ds_load_b32 v54, v5                                        // 000000569530: D8D80000 36000005
	v_lshrrev_b32_e32 v5, 6, v7                                // 000000569538: 320A0E86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000056953C: BF8700B1
	v_and_b32_e32 v5, 0x3fc, v5                                // 000000569540: 360A0AFF 000003FC
	ds_load_b32 v55, v5                                        // 000000569548: D8D80000 37000005
	v_lshrrev_b32_e32 v5, 14, v7                               // 000000569550: 320A0E8E
	v_and_b32_e32 v5, 0x3fc, v5                                // 000000569554: 360A0AFF 000003FC
	ds_load_b32 v56, v5                                        // 00000056955C: D8D80000 38000005
	v_lshrrev_b32_e32 v5, 22, v7                               // 000000569564: 320A0E96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000569568: BF8700B1
	v_and_b32_e32 v5, 0x3fc, v5                                // 00000056956C: 360A0AFF 000003FC
	ds_load_b32 v57, v5                                        // 000000569574: D8D80000 39000005
	v_and_b32_e32 v5, 0xff, v8                                 // 00000056957C: 360A10FF 000000FF
	v_lshlrev_b32_e32 v5, 2, v5                                // 000000569584: 300A0A82
	ds_load_b32 v58, v5                                        // 000000569588: D8D80000 3A000005
	v_lshrrev_b32_e32 v5, 6, v8                                // 000000569590: 320A1086
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000569594: BF8700B1
	v_and_b32_e32 v5, 0x3fc, v5                                // 000000569598: 360A0AFF 000003FC
	ds_load_b32 v59, v5                                        // 0000005695A0: D8D80000 3B000005
	v_lshrrev_b32_e32 v5, 14, v8                               // 0000005695A8: 320A108E
	v_and_b32_e32 v5, 0x3fc, v5                                // 0000005695AC: 360A0AFF 000003FC
	ds_load_b32 v60, v5                                        // 0000005695B4: D8D80000 3C000005
	v_lshrrev_b32_e32 v5, 22, v8                               // 0000005695BC: 320A1096
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000005695C0: BF870141
	v_and_b32_e32 v5, 0x3fc, v5                                // 0000005695C4: 360A0AFF 000003FC
	ds_load_b32 v61, v5                                        // 0000005695CC: D8D80000 3D000005
	.long 0xd73c0005                                           // 0000005695D4: D73C0005
	v_cndmask_b32_e32 v1, 1, v12, vcc_lo                       // 0000005695D8: 02021881
	v_add_nc_u32_e32 v12, 0x400, v12                           // 0000005695DC: 4A1818FF 00000400
	.long 0xd7006a2a                                           // 0000005695E4: D7006A2A
	v_cndmask_b32_e32 v1, s6, v5, vcc_lo                       // 0000005695E8: 02020A06
	s_delay_alu instid0(VALU_DEP_1)                            // 0000005695EC: BF870001
	v_add_co_ci_u32_e64 v43, null, s7, v6, vcc_lo              // 0000005695F0: D5207C2B 01AA0C07
	s_clause 0x3                                               // 0000005695F8: BF850003
	global_load_b128 v[5:8], v[42:43], off                     // 0000005695FC: DC5E0000 057C002A
	global_load_b128 v[30:33], v[42:43], off offset:16         // 000000569604: DC5E0010 1E7C002A
	global_load_b128 v[34:37], v[42:43], off offset:32         // 00000056960C: DC5E0020 227C002A
	global_load_b128 v[38:41], v[42:43], off offset:48         // 000000569614: DC5E0030 267C002A
	s_waitcnt vmcnt(3) lgkmcnt(15)                             // 00000056961C: BF890CF7
	v_dot2_f32_bf16 v5, v5, v46, 0                             // 000000569620: CC1A4005 1A025D05
	s_waitcnt lgkmcnt(14)                                      // 000000569628: BF89FCE7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000056962C: BF8700A1
	v_dot2_f32_bf16 v5, v6, v47, v5                            // 000000569630: CC1A4005 1C165F06
	s_waitcnt lgkmcnt(13)                                      // 000000569638: BF89FCD7
	v_dot2_f32_bf16 v5, v7, v48, v5                            // 00000056963C: CC1A4005 1C166107
	s_waitcnt lgkmcnt(12)                                      // 000000569644: BF89FCC7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000569648: BF8700A1
	v_dot2_f32_bf16 v5, v8, v49, v5                            // 00000056964C: CC1A4005 1C166308
	s_waitcnt vmcnt(2) lgkmcnt(11)                             // 000000569654: BF8908B7
	v_dot2_f32_bf16 v5, v30, v50, v5                           // 000000569658: CC1A4005 1C16651E
	s_waitcnt lgkmcnt(10)                                      // 000000569660: BF89FCA7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000569664: BF8700A1
	v_dot2_f32_bf16 v5, v31, v51, v5                           // 000000569668: CC1A4005 1C16671F
	s_waitcnt lgkmcnt(9)                                       // 000000569670: BF89FC97
	v_dot2_f32_bf16 v5, v32, v52, v5                           // 000000569674: CC1A4005 1C166920
	s_waitcnt lgkmcnt(8)                                       // 00000056967C: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000569680: BF8700A1
	v_dot2_f32_bf16 v5, v33, v53, v5                           // 000000569684: CC1A4005 1C166B21
	s_waitcnt vmcnt(1) lgkmcnt(7)                              // 00000056968C: BF890477
	v_dot2_f32_bf16 v5, v34, v54, v5                           // 000000569690: CC1A4005 1C166D22
	s_waitcnt lgkmcnt(6)                                       // 000000569698: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000056969C: BF8700A1
	v_dot2_f32_bf16 v5, v35, v55, v5                           // 0000005696A0: CC1A4005 1C166F23
	s_waitcnt lgkmcnt(5)                                       // 0000005696A8: BF89FC57
	v_dot2_f32_bf16 v5, v36, v56, v5                           // 0000005696AC: CC1A4005 1C167124
	s_waitcnt lgkmcnt(4)                                       // 0000005696B4: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000005696B8: BF8700A1
	v_dot2_f32_bf16 v5, v37, v57, v5                           // 0000005696BC: CC1A4005 1C167325
	s_waitcnt vmcnt(0) lgkmcnt(3)                              // 0000005696C4: BF890037
	v_dot2_f32_bf16 v5, v38, v58, v5                           // 0000005696C8: CC1A4005 1C167526
	.long 0xd7006a26                                           // 0000005696D0: D7006A26
	v_cndmask_b32_e32 v0, v42, v10, vcc_lo                     // 0000005696D4: 0200152A
	s_waitcnt lgkmcnt(2)                                       // 0000005696D8: BF89FC27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000005696DC: BF8701C2
	v_dot2_f32_bf16 v5, v39, v59, v5                           // 0000005696E0: CC1A4005 1C167727
	v_add_co_ci_u32_e64 v39, null, s11, v43, vcc_lo            // 0000005696E8: D5207C27 01AA560B
	.long 0xd7006a2c                                           // 0000005696F0: D7006A2C
	v_cndmask_b32_e32 v0, v42, v4, vcc_lo                      // 0000005696F4: 0200092A
	s_waitcnt lgkmcnt(1)                                       // 0000005696F8: BF89FC17
	v_dot2_f32_bf16 v5, v40, v60, v5                           // 0000005696FC: CC1A4005 1C167928
	v_add_co_ci_u32_e64 v45, null, s5, v43, vcc_lo             // 000000569704: D5207C2D 01AA5605
	.long 0xd7006a2a                                           // 00000056970C: D7006A2A
	v_cndmask_b32_e32 v0, v42, v16, vcc_lo                     // 000000569710: 0200212A
	s_waitcnt lgkmcnt(0)                                       // 000000569714: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000569718: BF870123
	v_dot2_f32_bf16 v5, v41, v61, v5                           // 00000056971C: CC1A4005 1C167B29
	v_add_co_ci_u32_e64 v43, null, s14, v43, vcc_lo            // 000000569724: D5207C2B 01AA560E
	v_fmac_f32_e32 v21, v29, v5                                // 00000056972C: 562A0B1D
	s_clause 0x3                                               // 000000569730: BF850003
	global_load_b128 v[5:8], v[38:39], off                     // 000000569734: DC5E0000 057C0026
	global_load_b128 v[30:33], v[38:39], off offset:16         // 00000056973C: DC5E0010 1E7C0026
	global_load_b128 v[34:37], v[38:39], off offset:32         // 000000569744: DC5E0020 227C0026
	global_load_b128 v[38:41], v[38:39], off offset:48         // 00000056974C: DC5E0030 267C0026
	s_waitcnt vmcnt(3)                                         // 000000569754: BF890FF7
	v_dot2_f32_bf16 v5, v5, v46, 0                             // 000000569758: CC1A4005 1A025D05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000569760: BF870091
	v_dot2_f32_bf16 v5, v6, v47, v5                            // 000000569764: CC1A4005 1C165F06
	v_dot2_f32_bf16 v5, v7, v48, v5                            // 00000056976C: CC1A4005 1C166107
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000569774: BF8700A1
	v_dot2_f32_bf16 v5, v8, v49, v5                            // 000000569778: CC1A4005 1C166308
	s_waitcnt vmcnt(2)                                         // 000000569780: BF890BF7
	v_dot2_f32_bf16 v5, v30, v50, v5                           // 000000569784: CC1A4005 1C16651E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000056978C: BF870091
	v_dot2_f32_bf16 v5, v31, v51, v5                           // 000000569790: CC1A4005 1C16671F
	v_dot2_f32_bf16 v5, v32, v52, v5                           // 000000569798: CC1A4005 1C166920
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000005697A0: BF8700A1
	v_dot2_f32_bf16 v5, v33, v53, v5                           // 0000005697A4: CC1A4005 1C166B21
	s_waitcnt vmcnt(1)                                         // 0000005697AC: BF8907F7
	v_dot2_f32_bf16 v5, v34, v54, v5                           // 0000005697B0: CC1A4005 1C166D22
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005697B8: BF870091
	v_dot2_f32_bf16 v5, v35, v55, v5                           // 0000005697BC: CC1A4005 1C166F23
	v_dot2_f32_bf16 v5, v36, v56, v5                           // 0000005697C4: CC1A4005 1C167124
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000005697CC: BF8700A1
	v_dot2_f32_bf16 v5, v37, v57, v5                           // 0000005697D0: CC1A4005 1C167325
	s_waitcnt vmcnt(0)                                         // 0000005697D8: BF8903F7
	v_dot2_f32_bf16 v5, v38, v58, v5                           // 0000005697DC: CC1A4005 1C167526
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005697E4: BF870091
	v_dot2_f32_bf16 v5, v39, v59, v5                           // 0000005697E8: CC1A4005 1C167727
	v_dot2_f32_bf16 v5, v40, v60, v5                           // 0000005697F0: CC1A4005 1C167928
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005697F8: BF870091
	v_dot2_f32_bf16 v5, v41, v61, v5                           // 0000005697FC: CC1A4005 1C167B29
	v_fmac_f32_e32 v25, v29, v5                                // 000000569804: 56320B1D
	s_clause 0x3                                               // 000000569808: BF850003
	global_load_b128 v[5:8], v[44:45], off                     // 00000056980C: DC5E0000 057C002C
	global_load_b128 v[30:33], v[44:45], off offset:16         // 000000569814: DC5E0010 1E7C002C
	global_load_b128 v[34:37], v[44:45], off offset:32         // 00000056981C: DC5E0020 227C002C
	global_load_b128 v[38:41], v[44:45], off offset:48         // 000000569824: DC5E0030 267C002C
	s_waitcnt vmcnt(3)                                         // 00000056982C: BF890FF7
	v_dot2_f32_bf16 v5, v5, v46, 0                             // 000000569830: CC1A4005 1A025D05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000569838: BF870091
	v_dot2_f32_bf16 v5, v6, v47, v5                            // 00000056983C: CC1A4005 1C165F06
	v_dot2_f32_bf16 v5, v7, v48, v5                            // 000000569844: CC1A4005 1C166107
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000056984C: BF8700A1
	v_dot2_f32_bf16 v5, v8, v49, v5                            // 000000569850: CC1A4005 1C166308
	s_waitcnt vmcnt(2)                                         // 000000569858: BF890BF7
	v_dot2_f32_bf16 v5, v30, v50, v5                           // 00000056985C: CC1A4005 1C16651E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000569864: BF870091
	v_dot2_f32_bf16 v5, v31, v51, v5                           // 000000569868: CC1A4005 1C16671F
	v_dot2_f32_bf16 v5, v32, v52, v5                           // 000000569870: CC1A4005 1C166920
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000569878: BF8700A1
	v_dot2_f32_bf16 v5, v33, v53, v5                           // 00000056987C: CC1A4005 1C166B21
	s_waitcnt vmcnt(1)                                         // 000000569884: BF8907F7
	v_dot2_f32_bf16 v5, v34, v54, v5                           // 000000569888: CC1A4005 1C166D22
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000569890: BF870091
	v_dot2_f32_bf16 v5, v35, v55, v5                           // 000000569894: CC1A4005 1C166F23
	v_dot2_f32_bf16 v5, v36, v56, v5                           // 00000056989C: CC1A4005 1C167124
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000005698A4: BF8700A1
	v_dot2_f32_bf16 v5, v37, v57, v5                           // 0000005698A8: CC1A4005 1C167325
	s_waitcnt vmcnt(0)                                         // 0000005698B0: BF8903F7
	v_dot2_f32_bf16 v5, v38, v58, v5                           // 0000005698B4: CC1A4005 1C167526
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005698BC: BF870091
	v_dot2_f32_bf16 v5, v39, v59, v5                           // 0000005698C0: CC1A4005 1C167727
	v_dot2_f32_bf16 v5, v40, v60, v5                           // 0000005698C8: CC1A4005 1C167928
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005698D0: BF870091
	v_dot2_f32_bf16 v5, v41, v61, v5                           // 0000005698D4: CC1A4005 1C167B29
	v_fmac_f32_e32 v24, v29, v5                                // 0000005698DC: 56300B1D
	s_clause 0x3                                               // 0000005698E0: BF850003
	global_load_b128 v[5:8], v[42:43], off                     // 0000005698E4: DC5E0000 057C002A
	global_load_b128 v[30:33], v[42:43], off offset:16         // 0000005698EC: DC5E0010 1E7C002A
	global_load_b128 v[34:37], v[42:43], off offset:32         // 0000005698F4: DC5E0020 227C002A
	global_load_b128 v[38:41], v[42:43], off offset:48         // 0000005698FC: DC5E0030 267C002A
	s_waitcnt vmcnt(3)                                         // 000000569904: BF890FF7
	v_dot2_f32_bf16 v5, v5, v46, 0                             // 000000569908: CC1A4005 1A025D05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000569910: BF870091
	v_dot2_f32_bf16 v5, v6, v47, v5                            // 000000569914: CC1A4005 1C165F06
	v_dot2_f32_bf16 v5, v7, v48, v5                            // 00000056991C: CC1A4005 1C166107
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000569924: BF8700A1
	v_dot2_f32_bf16 v5, v8, v49, v5                            // 000000569928: CC1A4005 1C166308
	s_waitcnt vmcnt(2)                                         // 000000569930: BF890BF7
	v_dot2_f32_bf16 v5, v30, v50, v5                           // 000000569934: CC1A4005 1C16651E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000056993C: BF870091
	v_dot2_f32_bf16 v5, v31, v51, v5                           // 000000569940: CC1A4005 1C16671F
	v_dot2_f32_bf16 v5, v32, v52, v5                           // 000000569948: CC1A4005 1C166920
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000569950: BF8700A1
	v_dot2_f32_bf16 v5, v33, v53, v5                           // 000000569954: CC1A4005 1C166B21
	s_waitcnt vmcnt(1)                                         // 00000056995C: BF8907F7
	v_dot2_f32_bf16 v5, v34, v54, v5                           // 000000569960: CC1A4005 1C166D22
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000569968: BF870091
	v_dot2_f32_bf16 v5, v35, v55, v5                           // 00000056996C: CC1A4005 1C166F23
	v_dot2_f32_bf16 v5, v36, v56, v5                           // 000000569974: CC1A4005 1C167124
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000056997C: BF8700A1
	v_dot2_f32_bf16 v5, v37, v57, v5                           // 000000569980: CC1A4005 1C167325
	s_waitcnt vmcnt(0)                                         // 000000569988: BF8903F7
	v_dot2_f32_bf16 v5, v38, v58, v5                           // 00000056998C: CC1A4005 1C167526
	.long 0xd7006a26                                           // 000000569994: D7006A26
	v_cndmask_b32_e32 v0, v44, v4, vcc_lo                      // 000000569998: 0200092C
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000056999C: BF870122
	v_dot2_f32_bf16 v5, v39, v59, v5                           // 0000005699A0: CC1A4005 1C167727
	v_add_co_ci_u32_e64 v39, null, s5, v45, vcc_lo             // 0000005699A8: D5207C27 01AA5A05
	v_dot2_f32_bf16 v5, v40, v60, v5                           // 0000005699B0: CC1A4005 1C167928
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005699B8: BF870091
	v_dot2_f32_bf16 v5, v41, v61, v5                           // 0000005699BC: CC1A4005 1C167B29
	v_fmac_f32_e32 v23, v29, v5                                // 0000005699C4: 562E0B1D
	s_clause 0x3                                               // 0000005699C8: BF850003
	global_load_b128 v[5:8], v[38:39], off                     // 0000005699CC: DC5E0000 057C0026
	global_load_b128 v[30:33], v[38:39], off offset:16         // 0000005699D4: DC5E0010 1E7C0026
	global_load_b128 v[34:37], v[38:39], off offset:32         // 0000005699DC: DC5E0020 227C0026
	global_load_b128 v[38:41], v[38:39], off offset:48         // 0000005699E4: DC5E0030 267C0026
	s_waitcnt vmcnt(3)                                         // 0000005699EC: BF890FF7
	v_dot2_f32_bf16 v5, v5, v46, 0                             // 0000005699F0: CC1A4005 1A025D05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005699F8: BF870091
	v_dot2_f32_bf16 v5, v6, v47, v5                            // 0000005699FC: CC1A4005 1C165F06
	v_dot2_f32_bf16 v5, v7, v48, v5                            // 000000569A04: CC1A4005 1C166107
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000569A0C: BF8700A1
	v_dot2_f32_bf16 v5, v8, v49, v5                            // 000000569A10: CC1A4005 1C166308
	s_waitcnt vmcnt(2)                                         // 000000569A18: BF890BF7
	v_dot2_f32_bf16 v5, v30, v50, v5                           // 000000569A1C: CC1A4005 1C16651E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000569A24: BF870091
	v_dot2_f32_bf16 v5, v31, v51, v5                           // 000000569A28: CC1A4005 1C16671F
	v_dot2_f32_bf16 v5, v32, v52, v5                           // 000000569A30: CC1A4005 1C166920
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000569A38: BF8700A1
	v_dot2_f32_bf16 v5, v33, v53, v5                           // 000000569A3C: CC1A4005 1C166B21
	s_waitcnt vmcnt(1)                                         // 000000569A44: BF8907F7
	v_dot2_f32_bf16 v5, v34, v54, v5                           // 000000569A48: CC1A4005 1C166D22
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000569A50: BF870091
	v_dot2_f32_bf16 v5, v35, v55, v5                           // 000000569A54: CC1A4005 1C166F23
	v_dot2_f32_bf16 v5, v36, v56, v5                           // 000000569A5C: CC1A4005 1C167124
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000569A64: BF8700A1
	v_dot2_f32_bf16 v5, v37, v57, v5                           // 000000569A68: CC1A4005 1C167325
	s_waitcnt vmcnt(0)                                         // 000000569A70: BF8903F7
	v_dot2_f32_bf16 v5, v38, v58, v5                           // 000000569A74: CC1A4005 1C167526
	.long 0xd7006a26                                           // 000000569A7C: D7006A26
	v_cndmask_b32_e32 v0, v42, v4, vcc_lo                      // 000000569A80: 0200092A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000569A84: BF870122
	v_dot2_f32_bf16 v5, v39, v59, v5                           // 000000569A88: CC1A4005 1C167727
	v_add_co_ci_u32_e64 v39, null, s5, v43, vcc_lo             // 000000569A90: D5207C27 01AA5605
	v_dot2_f32_bf16 v5, v40, v60, v5                           // 000000569A98: CC1A4005 1C167928
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000569AA0: BF870091
	v_dot2_f32_bf16 v5, v41, v61, v5                           // 000000569AA4: CC1A4005 1C167B29
	v_fmac_f32_e32 v22, v29, v5                                // 000000569AAC: 562C0B1D
	s_clause 0x3                                               // 000000569AB0: BF850003
	global_load_b128 v[5:8], v[38:39], off                     // 000000569AB4: DC5E0000 057C0026
	global_load_b128 v[30:33], v[38:39], off offset:16         // 000000569ABC: DC5E0010 1E7C0026
	global_load_b128 v[34:37], v[38:39], off offset:32         // 000000569AC4: DC5E0020 227C0026
	global_load_b128 v[38:41], v[38:39], off offset:48         // 000000569ACC: DC5E0030 267C0026
	s_waitcnt vmcnt(3)                                         // 000000569AD4: BF890FF7
	v_dot2_f32_bf16 v5, v5, v46, 0                             // 000000569AD8: CC1A4005 1A025D05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000569AE0: BF870121
	v_dot2_f32_bf16 v5, v6, v47, v5                            // 000000569AE4: CC1A4005 1C165F06
	v_mov_b32_e32 v6, v2                                       // 000000569AEC: 7E0C0302
	v_dot2_f32_bf16 v5, v7, v48, v5                            // 000000569AF0: CC1A4005 1C166107
	v_mov_b32_e32 v7, v3                                       // 000000569AF8: 7E0E0303
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000569AFC: BF870132
	v_dot2_f32_bf16 v5, v8, v49, v5                            // 000000569B00: CC1A4005 1C166308
	v_mov_b32_e32 v8, v4                                       // 000000569B08: 7E100304
	s_waitcnt vmcnt(2)                                         // 000000569B0C: BF890BF7
	v_dot2_f32_bf16 v5, v30, v50, v5                           // 000000569B10: CC1A4005 1C16651E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000569B18: BF870091
	v_dot2_f32_bf16 v5, v31, v51, v5                           // 000000569B1C: CC1A4005 1C16671F
	v_dot2_f32_bf16 v5, v32, v52, v5                           // 000000569B24: CC1A4005 1C166920
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000569B2C: BF8700A1
	v_dot2_f32_bf16 v5, v33, v53, v5                           // 000000569B30: CC1A4005 1C166B21
	s_waitcnt vmcnt(1)                                         // 000000569B38: BF8907F7
	v_dot2_f32_bf16 v5, v34, v54, v5                           // 000000569B3C: CC1A4005 1C166D22
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000569B44: BF870091
	v_dot2_f32_bf16 v5, v35, v55, v5                           // 000000569B48: CC1A4005 1C166F23
	v_dot2_f32_bf16 v5, v36, v56, v5                           // 000000569B50: CC1A4005 1C167124
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000569B58: BF8700A1
	v_dot2_f32_bf16 v5, v37, v57, v5                           // 000000569B5C: CC1A4005 1C167325
	s_waitcnt vmcnt(0)                                         // 000000569B64: BF8903F7
	v_dot2_f32_bf16 v5, v38, v58, v5                           // 000000569B68: CC1A4005 1C167526
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000569B70: BF870091
	v_dot2_f32_bf16 v5, v39, v59, v5                           // 000000569B74: CC1A4005 1C167727
	v_dot2_f32_bf16 v5, v40, v60, v5                           // 000000569B7C: CC1A4005 1C167928
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000569B84: BF870091
	v_dot2_f32_bf16 v5, v41, v61, v5                           // 000000569B88: CC1A4005 1C167B29
	v_fmac_f32_e32 v17, v29, v5                                // 000000569B90: 56220B1D
	v_mov_b32_e32 v5, v1                                       // 000000569B94: 7E0A0301
	v_mov_b32_e32 v29, v28                                     // 000000569B98: 7E3A031C
	s_and_not1_b32 exec_lo, exec_lo, s15                       // 000000569B9C: 917E0F7E
	s_cbranch_execz 31                                         // 000000569BA0: BFA5001F <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi2ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0xa20>
	s_waitcnt vmcnt(0)                                         // 000000569BA4: BF8903F7
	v_dual_mov_b32 v1, v5 :: v_dual_add_nc_u32 v18, 32, v18    // 000000569BA8: CA200105 011224A0
	v_dual_mov_b32 v2, v6 :: v_dual_mov_b32 v3, v7             // 000000569BB0: CA100106 02020107
	v_mov_b32_e32 v4, v8                                       // 000000569BB8: 7E080308
	s_mov_b32 s17, exec_lo                                     // 000000569BBC: BE91007E
	s_delay_alu instid0(VALU_DEP_3)                            // 000000569BC0: BF870003
	v_cmp_ge_i32_e32 vcc_lo, v18, v19                          // 000000569BC4: 7C8C2712
	.long 0xd4c1007e                                           // 000000569BC8: D4C1007E
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 000000569BCC: 02022712
	s_cbranch_execz 65057                                      // 000000569BD0: BFA5FE21 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi2ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x258>
	v_ashrrev_i32_e32 v2, 31, v27                              // 000000569BD4: 3404369F
	v_ashrrev_i32_e32 v4, 31, v26                              // 000000569BD8: 3408349F
	.long 0xd7000001                                           // 000000569BDC: D7000001
	v_cndmask_b32_e32 v1, v11, v27, vcc_lo                     // 000000569BE0: 0202370B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000569BE4: BF8700A1
	v_add_co_ci_u32_e64 v2, null, v20, v2, s0                  // 000000569BE8: D5207C02 00020514
	.long 0xd7000003                                           // 000000569BF0: D7000003
	v_cndmask_b32_e32 v1, v9, v26, vcc_lo                      // 000000569BF4: 02023509
	v_add_co_ci_u32_e64 v4, null, v10, v4, s0                  // 000000569BF8: D5207C04 0002090A
	s_clause 0x1                                               // 000000569C00: BF850001
	global_load_d16_b16 v13, v[1:2], off                       // 000000569C04: DC820000 0D7C0001
	global_load_b128 v[1:4], v[3:4], off                       // 000000569C0C: DC5E0000 017C0003
	s_waitcnt vmcnt(1)                                         // 000000569C14: BF8907F7
	v_cvt_f32_f16_e32 v28, v13                                 // 000000569C18: 7E38170D
	s_branch 65038                                             // 000000569C1C: BFA0FE0E <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi2ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x258>
	s_or_b32 exec_lo, exec_lo, s15                             // 000000569C20: 8C7E0F7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000569C24: BF8700B9
	s_or_b32 exec_lo, exec_lo, s1                              // 000000569C28: 8C7E017E
	.long 0xd71f0001                                           // 000000569C2C: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 000000569C30: 020100C1
	s_mov_b32 s0, exec_lo                                      // 000000569C34: BE80007E
	v_xor_b32_e32 v2, 16, v1                                   // 000000569C38: 3A040290
	s_waitcnt vmcnt(0)                                         // 000000569C3C: BF8903F7
	v_xor_b32_e32 v8, 8, v1                                    // 000000569C40: 3A100288
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000569C44: BF8701A2
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 000000569C48: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 000000569C4C: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v8                            // 000000569C50: 7C9810A0
	s_delay_alu instid0(VALU_DEP_2)                            // 000000569C54: BF870002
	v_lshlrev_b32_e32 v2, 2, v2                                // 000000569C58: 30040482
	ds_bpermute_b32 v3, v2, v21                                // 000000569C5C: DACC0000 03001502
	s_waitcnt lgkmcnt(0)                                       // 000000569C64: BF89FC07
	v_add_f32_e32 v3, v21, v3                                  // 000000569C68: 06060715
	ds_bpermute_b32 v4, v2, v25                                // 000000569C6C: DACC0000 04001902
	ds_bpermute_b32 v5, v2, v24                                // 000000569C74: DACC0000 05001802
	ds_bpermute_b32 v6, v2, v23                                // 000000569C7C: DACC0000 06001702
	ds_bpermute_b32 v7, v2, v22                                // 000000569C84: DACC0000 07001602
	ds_bpermute_b32 v2, v2, v17                                // 000000569C8C: DACC0000 02001102
	s_waitcnt lgkmcnt(3)                                       // 000000569C94: BF89FC37
	v_dual_cndmask_b32 v8, v1, v8 :: v_dual_add_f32 v5, v24, v5// 000000569C98: CA481101 08040B18
	s_waitcnt lgkmcnt(0)                                       // 000000569CA0: BF89FC07
	v_dual_add_f32 v7, v22, v7 :: v_dual_add_f32 v2, v17, v2   // 000000569CA4: C9080F16 07020511
	v_xor_b32_e32 v17, 4, v1                                   // 000000569CAC: 3A220284
	s_delay_alu instid0(VALU_DEP_1)                            // 000000569CB0: BF870001
	v_cmp_gt_u32_e32 vcc_lo, 32, v17                           // 000000569CB4: 7C9822A0
	v_dual_cndmask_b32 v17, v1, v17 :: v_dual_lshlrev_b32 v8, 2, v8// 000000569CB8: CA622301 11081082
	ds_bpermute_b32 v9, v8, v3                                 // 000000569CC0: DACC0000 09000308
	ds_bpermute_b32 v11, v8, v5                                // 000000569CC8: DACC0000 0B000508
	v_add_f32_e32 v4, v25, v4                                  // 000000569CD0: 06080919
	v_add_f32_e32 v6, v23, v6                                  // 000000569CD4: 060C0D17
	ds_bpermute_b32 v13, v8, v7                                // 000000569CD8: DACC0000 0D000708
	v_lshlrev_b32_e32 v17, 2, v17                              // 000000569CE0: 30222282
	ds_bpermute_b32 v10, v8, v4                                // 000000569CE4: DACC0000 0A000408
	s_waitcnt lgkmcnt(3)                                       // 000000569CEC: BF89FC37
	v_add_f32_e32 v3, v3, v9                                   // 000000569CF0: 06061303
	s_waitcnt lgkmcnt(2)                                       // 000000569CF4: BF89FC27
	v_add_f32_e32 v5, v5, v11                                  // 000000569CF8: 060A1705
	ds_bpermute_b32 v12, v8, v6                                // 000000569CFC: DACC0000 0C000608
	ds_bpermute_b32 v8, v8, v2                                 // 000000569D04: DACC0000 08000208
	s_waitcnt lgkmcnt(2)                                       // 000000569D0C: BF89FC27
	v_dual_add_f32 v7, v7, v13 :: v_dual_add_f32 v4, v4, v10   // 000000569D10: C9081B07 07041504
	ds_bpermute_b32 v10, v17, v5                               // 000000569D18: DACC0000 0A000511
	ds_bpermute_b32 v9, v17, v4                                // 000000569D20: DACC0000 09000411
	s_waitcnt lgkmcnt(3)                                       // 000000569D28: BF89FC37
	v_add_f32_e32 v6, v6, v12                                  // 000000569D2C: 060C1906
	s_waitcnt lgkmcnt(2)                                       // 000000569D30: BF89FC27
	v_add_f32_e32 v2, v2, v8                                   // 000000569D34: 06041102
	ds_bpermute_b32 v8, v17, v3                                // 000000569D38: DACC0000 08000311
	ds_bpermute_b32 v12, v17, v7                               // 000000569D40: DACC0000 0C000711
	ds_bpermute_b32 v11, v17, v6                               // 000000569D48: DACC0000 0B000611
	ds_bpermute_b32 v13, v17, v2                               // 000000569D50: DACC0000 0D000211
	v_xor_b32_e32 v17, 2, v1                                   // 000000569D58: 3A220282
	s_waitcnt lgkmcnt(4)                                       // 000000569D5C: BF89FC47
	v_add_f32_e32 v4, v4, v9                                   // 000000569D60: 06081304
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000569D64: BF870132
	v_cmp_gt_u32_e32 vcc_lo, 32, v17                           // 000000569D68: 7C9822A0
	v_cndmask_b32_e32 v17, v1, v17, vcc_lo                     // 000000569D6C: 02222301
	v_add_f32_e32 v5, v5, v10                                  // 000000569D70: 060A1505
	v_lshlrev_b32_e32 v17, 2, v17                              // 000000569D74: 30222282
	s_waitcnt lgkmcnt(3)                                       // 000000569D78: BF89FC37
	v_add_f32_e32 v3, v3, v8                                   // 000000569D7C: 06061103
	s_waitcnt lgkmcnt(1)                                       // 000000569D80: BF89FC17
	v_dual_add_f32 v7, v7, v12 :: v_dual_add_f32 v6, v6, v11   // 000000569D84: C9081907 07061706
	s_waitcnt lgkmcnt(0)                                       // 000000569D8C: BF89FC07
	v_add_f32_e32 v8, v2, v13                                  // 000000569D90: 06101B02
	ds_bpermute_b32 v9, v17, v4                                // 000000569D94: DACC0000 09000411
	ds_bpermute_b32 v2, v17, v3                                // 000000569D9C: DACC0000 02000311
	ds_bpermute_b32 v10, v17, v5                               // 000000569DA4: DACC0000 0A000511
	ds_bpermute_b32 v11, v17, v6                               // 000000569DAC: DACC0000 0B000611
	ds_bpermute_b32 v12, v17, v7                               // 000000569DB4: DACC0000 0C000711
	ds_bpermute_b32 v13, v17, v8                               // 000000569DBC: DACC0000 0D000811
	v_xor_b32_e32 v17, 1, v1                                   // 000000569DC4: 3A220281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000569DC8: BF8700A1
	v_cmp_gt_u32_e32 vcc_lo, 32, v17                           // 000000569DCC: 7C9822A0
	v_cndmask_b32_e32 v1, v1, v17, vcc_lo                      // 000000569DD0: 02022301
	v_lshlrev_b32_e32 v17, 2, v1                               // 000000569DD4: 30220282
	s_waitcnt lgkmcnt(4)                                       // 000000569DD8: BF89FC47
	v_dual_add_f32 v1, v3, v2 :: v_dual_add_f32 v2, v4, v9     // 000000569DDC: C9080503 01021304
	s_waitcnt lgkmcnt(2)                                       // 000000569DE4: BF89FC27
	v_dual_add_f32 v4, v5, v10 :: v_dual_add_f32 v5, v6, v11   // 000000569DE8: C9081505 04041706
	s_waitcnt lgkmcnt(1)                                       // 000000569DF0: BF89FC17
	v_add_f32_e32 v3, v7, v12                                  // 000000569DF4: 06061907
	s_waitcnt lgkmcnt(0)                                       // 000000569DF8: BF89FC07
	v_add_f32_e32 v9, v8, v13                                  // 000000569DFC: 06121B08
	ds_bpermute_b32 v6, v17, v1                                // 000000569E00: DACC0000 06000111
	ds_bpermute_b32 v7, v17, v2                                // 000000569E08: DACC0000 07000211
	ds_bpermute_b32 v10, v17, v4                               // 000000569E10: DACC0000 0A000411
	ds_bpermute_b32 v11, v17, v5                               // 000000569E18: DACC0000 0B000511
	ds_bpermute_b32 v8, v17, v3                                // 000000569E20: DACC0000 08000311
	ds_bpermute_b32 v12, v17, v9                               // 000000569E28: DACC0000 0C000911
	v_cmpx_eq_u32_e32 0, v16                                   // 000000569E30: 7D942080
	s_cbranch_execz 16                                         // 000000569E34: BFA50010 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi2ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0xc78>
	.long 0xd72c000d                                           // 000000569E38: D72C000D
	v_cndmask_b32_e32 v0, v14, v176, vcc_lo                    // 000000569E3C: 0201610E
	s_waitcnt lgkmcnt(0)                                       // 000000569E40: BF89FC07
	v_dual_add_f32 v9, v9, v12 :: v_dual_add_f32 v4, v4, v10   // 000000569E44: C9081909 09041504
	v_dual_add_f32 v5, v5, v11 :: v_dual_add_f32 v8, v3, v8    // 000000569E4C: C9081705 05081103
	v_dual_add_f32 v2, v2, v7 :: v_dual_add_f32 v1, v1, v6     // 000000569E54: C9080F02 02000D01
	s_delay_alu instid0(VALU_DEP_4)                            // 000000569E5C: BF870004
	v_mad_u32_u24 v6, v15, 24, v13                             // 000000569E60: D60B0006 0435310F
	ds_store_2addr_b64 v6, v[1:2], v[4:5] offset0:128 offset1:129// 000000569E68: D9388180 00040106
	ds_store_b64 v6, v[8:9] offset:1040                        // 000000569E70: D9340410 00000806
	s_or_b32 exec_lo, exec_lo, s0                              // 000000569E78: 8C7E007E
	.long 0xd7050001                                           // 000000569E7C: D7050001
	v_cndmask_b32_e32 v1, 0xab, v0, vcc_lo                     // 000000569E80: 020200FF 000000AB
	.long 0x7f063880                                           // 000000569E88: 7F063880
	s_waitcnt lgkmcnt(0)                                       // 000000569E8C: BF89FC07
	s_barrier                                                  // 000000569E90: BFBD0000
	buffer_gl0_inv                                             // 000000569E94: E0AC0000 00000000
	.long 0xd7390003                                           // 000000569E9C: D7390003
	v_cndmask_b32_e32 v1, 10, v1, vcc_lo                       // 000000569EA0: 0202028A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000569EA4: BF870091
	.long 0xd7000001                                           // 000000569EA8: D7000001
	v_cndmask_b32_e32 v1, s2, v3, vcc_lo                       // 000000569EAC: 02020602
	v_add_co_ci_u32_e64 v2, null, s3, 0, s0                    // 000000569EB0: D5207C02 00010003
	.long 0xd44c0000                                           // 000000569EB8: D44C0000
	v_cndmask_b32_e32 v1, 24, v0, vcc_lo                       // 000000569EBC: 02020098
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000569EC0: BF8704A2
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[1:2]                  // 000000569EC4: 7CA8020C
	s_and_b32 s0, s0, vcc_lo                                   // 000000569EC8: 8B006A00
	s_and_saveexec_b32 s1, s0                                  // 000000569ECC: BE812000
	s_cbranch_execz 45                                         // 000000569ED0: BFA5002D <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi2ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0xd88>
	.long 0xd7054000                                           // 000000569ED4: D7054000
	v_cndmask_b32_e32 v0, v3, v134, vcc_lo                     // 000000569ED8: 02010D03
	v_mul_u32_u24_e32 v3, 48, v3                               // 000000569EDC: 160606B0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000569EE0: BF870092
	.long 0xd7041000                                           // 000000569EE4: D7041000
	v_cndmask_b32_e32 v1, v0, v0, vcc_lo                       // 000000569EE8: 02020100
	v_and_b32_e32 v0, 0xff, v0                                 // 000000569EEC: 360000FF 000000FF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000569EF4: BF870091
	v_lshl_add_u32 v3, v0, 2, v3                               // 000000569EF8: D6460003 040D0500
	v_add_nc_u32_e32 v3, 0x400, v3                             // 000000569F00: 4A0606FF 00000400
	ds_load_2addr_b32 v[6:7], v3 offset1:6                     // 000000569F08: D8DC0600 06000003
	v_mad_u64_u32 v[3:4], null, s12, v0, 0                     // 000000569F10: D6FE7C03 0202000C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000569F18: BF870091
	v_mad_u64_u32 v[4:5], null, s13, v0, v[4:5]                // 000000569F1C: D6FE7C04 0412000D
	.long 0xd73c0003                                           // 000000569F24: D73C0003
	v_cndmask_b32_e32 v1, 1, v3, vcc_lo                        // 000000569F28: 02020681
	s_waitcnt lgkmcnt(0)                                       // 000000569F2C: BF89FC07
	v_add_f32_e32 v0, 0, v6                                    // 000000569F30: 06000C80
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000569F34: BF870112
	.long 0xd7006a03                                           // 000000569F38: D7006A03
	v_cndmask_b32_e32 v1, s8, v3, vcc_lo                       // 000000569F3C: 02020608
	v_add_f32_e32 v5, v0, v7                                   // 000000569F40: 060A0F00
	.long 0xd73c0000                                           // 000000569F44: D73C0000
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 000000569F48: 02020281
	v_add_co_ci_u32_e64 v4, null, s9, v4, vcc_lo               // 000000569F4C: D5207C04 01AA0809
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000569F54: BF870193
	v_bfe_u32 v2, v5, 16, 1                                    // 000000569F58: D6100002 02052105
	.long 0xd7006a00                                           // 000000569F60: D7006A00
	v_cndmask_b32_e32 v1, v3, v0, vcc_lo                       // 000000569F64: 02020103
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000569F68: BF870191
	v_add_co_ci_u32_e64 v1, null, v4, v1, vcc_lo               // 000000569F6C: D5207C01 01AA0304
	v_add3_u32 v2, v5, v2, 0x7fff                              // 000000569F74: D6550002 03FE0505 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off                    // 000000569F80: DC960000 007C0200
	s_endpgm                                                   // 000000569F88: BFB00000
		...

