00000000007bde00 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi2ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi2ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 0000007BDE00: F4100100 F8000000
	s_ashr_i32 s3, s2, 31                                      // 0000007BDE08: 86039F02
	v_lshrrev_b32_e32 v2, 2, v0                                // 0000007BDE0C: 32040082
	s_lshl_b64 s[20:21], s[2:3], 2                             // 0000007BDE10: 84948202
	v_and_b32_e32 v1, 15, v0                                   // 0000007BDE14: 3602008F
	v_lshrrev_b32_e32 v21, 6, v0                               // 0000007BDE18: 322A0086
	v_bfe_u32 v22, v0, 5, 1                                    // 0000007BDE1C: D6100016 02050B00
	v_and_b32_e32 v2, 60, v2                                   // 0000007BDE24: 360404BC
	v_and_b32_e32 v23, 31, v0                                  // 0000007BDE28: 362E009F
	v_lshlrev_b32_e32 v1, 2, v1                                // 0000007BDE2C: 30020282
	.long 0x7f0a3880                                           // 0000007BDE30: 7F0A3880
	s_waitcnt lgkmcnt(0)                                       // 0000007BDE34: BF89FC07
	s_clause 0x1                                               // 0000007BDE38: BF850001
	global_load_b32 v3, v1, s[4:5]                             // 0000007BDE3C: DC520000 03040001
	global_load_b32 v4, v2, s[4:5]                             // 0000007BDE44: DC520000 04040002
	s_add_u32 s2, s4, s16                                      // 0000007BDE4C: 80021004
	s_addc_u32 s3, s5, s17                                     // 0000007BDE50: 82031105
	s_ashr_i32 s16, s11, 31                                    // 0000007BDE54: 86109F0B
	v_mov_b32_e32 v2, s21                                      // 0000007BDE58: 7E040215
	s_lshr_b32 s16, s16, 27                                    // 0000007BDE5C: 85109B10
	v_or_b32_e32 v1, s20, v21                                  // 0000007BDE60: 38022A14
	s_add_u32 s16, s10, s16                                    // 0000007BDE64: 8010100A
	s_addc_u32 s17, s11, 0                                     // 0000007BDE68: 8211800B
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007BDE6C: BF870099
	s_lshr_b64 s[16:17], s[16:17], 5                           // 0000007BDE70: 85908510
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[1:2]                  // 0000007BDE74: 7CA8020C
	s_add_i32 s17, s16, 1                                      // 0000007BDE78: 81118110
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000007BDE7C: BF870499
	s_lshr_b32 s22, s17, 31                                    // 0000007BDE80: 85169F11
	s_add_i32 s17, s17, s22                                    // 0000007BDE84: 81111611
	v_cndmask_b32_e32 v9, 0, v1, vcc_lo                        // 0000007BDE88: 02120280
	s_ashr_i32 s17, s17, 1                                     // 0000007BDE8C: 86118111
	v_cndmask_b32_e64 v10, 0, s21, vcc_lo                      // 0000007BDE90: D501000A 01A82A80
	.long 0xd72c0002                                           // 0000007BDE98: D72C0002
	v_cndmask_b32_e32 v1, s17, v22, vcc_lo                     // 0000007BDE9C: 02022C11
	s_cmpk_lt_i32 s16, 0x201                                   // 0000007BDEA0: B3900201
	.long 0xd72c0007                                           // 0000007BDEA4: D72C0007
	v_cndmask_b32_e32 v1, s19, v9, vcc_lo                      // 0000007BDEA8: 02021213
	v_mad_u64_u32 v[17:18], null, s18, v9, s[2:3]              // 0000007BDEAC: D6FE7C11 000A1212
	s_cselect_b32 s2, -1, 0                                    // 0000007BDEB4: 980280C1
	s_cmpk_gt_i32 s16, 0x200                                   // 0000007BDEB8: B2900200
	v_lshlrev_b32_e32 v1, 2, v0                                // 0000007BDEBC: 30020082
	v_add_nc_u32_e32 v11, s17, v2                              // 0000007BDEC0: 4A160411
	v_add_nc_u32_e32 v24, v2, v23                              // 0000007BDEC4: 4A302F02
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000007BDEC8: BF8704A2
	v_min_i32_e32 v25, s16, v11                                // 0000007BDECC: 22321610
	s_cselect_b32 s16, -1, 0                                   // 0000007BDED0: 981080C1
	s_and_b32 vcc_lo, exec_lo, s16                             // 0000007BDED4: 8B6A107E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 0000007BDED8: BF870151
	.long 0xd4410003                                           // 0000007BDEDC: D4410003
	v_cndmask_b32_e32 v1, v24, v25, vcc_lo                     // 0000007BDEE0: 02023318
	s_waitcnt vmcnt(1)                                         // 0000007BDEE4: BF8907F7
	v_bfe_u32 v6, v3, 16, 1                                    // 0000007BDEE8: D6100006 02052103
	s_waitcnt vmcnt(0)                                         // 0000007BDEF0: BF8903F7
	v_bfe_u32 v8, v4, 16, 1                                    // 0000007BDEF4: D6100008 02052104
	v_add3_u32 v3, v3, v6, 0x7fff                              // 0000007BDEFC: D6550003 03FE0D03 00007FFF
	.long 0xd72c0006                                           // 0000007BDF08: D72C0006
	v_cndmask_b32_e32 v1, s18, v10, vcc_lo                     // 0000007BDF0C: 02021412
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007BDF10: BF870193
	v_add3_u32 v4, v4, v8, 0x7fff                              // 0000007BDF14: D6550004 03FE1104 00007FFF
	.long 0x7e0a3983                                           // 0000007BDF20: 7E0A3983
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007BDF24: BF870113
	v_add3_u32 v26, v7, v18, v6                                // 0000007BDF28: D655001A 041A2507
	v_and_or_b32 v2, 0xffff0000, v4, v5                        // 0000007BDF30: D6570002 041608FF FFFF0000
	ds_store_b32 v1, v2                                        // 0000007BDF3C: D8340000 00000201
	s_waitcnt lgkmcnt(0)                                       // 0000007BDF44: BF89FC07
	s_barrier                                                  // 0000007BDF48: BFBD0000
	buffer_gl0_inv                                             // 0000007BDF4C: E0AC0000 00000000
	s_cbranch_vccnz 154                                        // 0000007BDF54: BFA4009A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi2ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x3c0>
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v1, 0               // 0000007BDF58: CA100080 02000080
	s_and_saveexec_b32 s17, s3                                 // 0000007BDF60: BE912003
	s_cbranch_execz 11                                         // 0000007BDF64: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi2ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x194>
	v_lshlrev_b32_e32 v1, 1, v24                               // 0000007BDF68: 30023081
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007BDF6C: BF8700A1
	v_ashrrev_i32_e32 v4, 31, v1                               // 0000007BDF70: 3408029F
	.long 0xd7006a03                                           // 0000007BDF74: D7006A03
	v_cndmask_b32_e32 v1, v17, v1, vcc_lo                      // 0000007BDF78: 02020311
	v_add_co_ci_u32_e64 v4, null, v26, v4, vcc_lo              // 0000007BDF7C: D5207C04 01AA091A
	global_load_d16_b16 v1, v[3:4], off                        // 0000007BDF84: DC820000 017C0003
	s_waitcnt vmcnt(0)                                         // 0000007BDF8C: BF8903F7
	v_cvt_f32_f16_e32 v1, v1                                   // 0000007BDF90: 7E021701
	s_or_b32 exec_lo, exec_lo, s17                             // 0000007BDF94: 8C7E117E
	v_add_nc_u32_e32 v3, 32, v24                               // 0000007BDF98: 4A0630A0
	s_mov_b32 s3, exec_lo                                      // 0000007BDF9C: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007BDFA0: BF870001
	.long 0xd4c1007e                                           // 0000007BDFA4: D4C1007E
	v_cndmask_b32_e32 v1, v3, v25, vcc_lo                      // 0000007BDFA8: 02023303
	s_cbranch_execz 11                                         // 0000007BDFAC: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi2ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x1dc>
	v_lshlrev_b32_e32 v2, 1, v3                                // 0000007BDFB0: 30040681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007BDFB4: BF8700A1
	v_ashrrev_i32_e32 v3, 31, v2                               // 0000007BDFB8: 3406049F
	.long 0xd7006a02                                           // 0000007BDFBC: D7006A02
	v_cndmask_b32_e32 v1, v17, v2, vcc_lo                      // 0000007BDFC0: 02020511
	v_add_co_ci_u32_e64 v3, null, v26, v3, vcc_lo              // 0000007BDFC4: D5207C03 01AA071A
	global_load_d16_b16 v2, v[2:3], off                        // 0000007BDFCC: DC820000 027C0002
	s_waitcnt vmcnt(0)                                         // 0000007BDFD4: BF8903F7
	v_cvt_f32_f16_e32 v2, v2                                   // 0000007BDFD8: 7E041702
	s_or_b32 exec_lo, exec_lo, s3                              // 0000007BDFDC: 8C7E037E
	v_dual_mov_b32 v4, 0 :: v_dual_add_nc_u32 v5, 64, v24      // 0000007BDFE0: CA200080 040430C0
	v_mov_b32_e32 v3, 0                                        // 0000007BDFE8: 7E060280
	s_mov_b32 s3, exec_lo                                      // 0000007BDFEC: BE83007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007BDFF0: BF870002
	.long 0xd4c1007e                                           // 0000007BDFF4: D4C1007E
	v_cndmask_b32_e32 v1, v5, v25, vcc_lo                      // 0000007BDFF8: 02023305
	s_cbranch_execz 11                                         // 0000007BDFFC: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi2ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x22c>
	v_lshlrev_b32_e32 v3, 1, v5                                // 0000007BE000: 30060A81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007BE004: BF8700A1
	v_ashrrev_i32_e32 v6, 31, v3                               // 0000007BE008: 340C069F
	.long 0xd7006a05                                           // 0000007BE00C: D7006A05
	v_cndmask_b32_e32 v1, v17, v3, vcc_lo                      // 0000007BE010: 02020711
	v_add_co_ci_u32_e64 v6, null, v26, v6, vcc_lo              // 0000007BE014: D5207C06 01AA0D1A
	global_load_d16_b16 v3, v[5:6], off                        // 0000007BE01C: DC820000 037C0005
	s_waitcnt vmcnt(0)                                         // 0000007BE024: BF8903F7
	v_cvt_f32_f16_e32 v3, v3                                   // 0000007BE028: 7E061703
	s_or_b32 exec_lo, exec_lo, s3                              // 0000007BE02C: 8C7E037E
	v_add_nc_u32_e32 v5, 0x60, v24                             // 0000007BE030: 4A0A30FF 00000060
	s_mov_b32 s3, exec_lo                                      // 0000007BE038: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007BE03C: BF870001
	.long 0xd4c1007e                                           // 0000007BE040: D4C1007E
	v_cndmask_b32_e32 v1, v5, v25, vcc_lo                      // 0000007BE044: 02023305
	s_cbranch_execz 11                                         // 0000007BE048: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi2ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x278>
	v_lshlrev_b32_e32 v4, 1, v5                                // 0000007BE04C: 30080A81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007BE050: BF8700A1
	v_ashrrev_i32_e32 v5, 31, v4                               // 0000007BE054: 340A089F
	.long 0xd7006a04                                           // 0000007BE058: D7006A04
	v_cndmask_b32_e32 v1, v17, v4, vcc_lo                      // 0000007BE05C: 02020911
	v_add_co_ci_u32_e64 v5, null, v26, v5, vcc_lo              // 0000007BE060: D5207C05 01AA0B1A
	global_load_d16_b16 v4, v[4:5], off                        // 0000007BE068: DC820000 047C0004
	s_waitcnt vmcnt(0)                                         // 0000007BE070: BF8903F7
	v_cvt_f32_f16_e32 v4, v4                                   // 0000007BE074: 7E081704
	s_or_b32 exec_lo, exec_lo, s3                              // 0000007BE078: 8C7E037E
	v_dual_mov_b32 v6, 0 :: v_dual_add_nc_u32 v7, 0x80, v24    // 0000007BE07C: CA200080 060630FF 00000080
	v_mov_b32_e32 v5, 0                                        // 0000007BE088: 7E0A0280
	s_mov_b32 s3, exec_lo                                      // 0000007BE08C: BE83007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007BE090: BF870002
	.long 0xd4c1007e                                           // 0000007BE094: D4C1007E
	v_cndmask_b32_e32 v1, v7, v25, vcc_lo                      // 0000007BE098: 02023307
	s_cbranch_execz 11                                         // 0000007BE09C: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi2ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x2cc>
	v_lshlrev_b32_e32 v5, 1, v7                                // 0000007BE0A0: 300A0E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007BE0A4: BF8700A1
	v_ashrrev_i32_e32 v8, 31, v5                               // 0000007BE0A8: 34100A9F
	.long 0xd7006a07                                           // 0000007BE0AC: D7006A07
	v_cndmask_b32_e32 v1, v17, v5, vcc_lo                      // 0000007BE0B0: 02020B11
	v_add_co_ci_u32_e64 v8, null, v26, v8, vcc_lo              // 0000007BE0B4: D5207C08 01AA111A
	global_load_d16_b16 v5, v[7:8], off                        // 0000007BE0BC: DC820000 057C0007
	s_waitcnt vmcnt(0)                                         // 0000007BE0C4: BF8903F7
	v_cvt_f32_f16_e32 v5, v5                                   // 0000007BE0C8: 7E0A1705
	s_or_b32 exec_lo, exec_lo, s3                              // 0000007BE0CC: 8C7E037E
	v_add_nc_u32_e32 v7, 0xa0, v24                             // 0000007BE0D0: 4A0E30FF 000000A0
	s_mov_b32 s3, exec_lo                                      // 0000007BE0D8: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007BE0DC: BF870001
	.long 0xd4c1007e                                           // 0000007BE0E0: D4C1007E
	v_cndmask_b32_e32 v1, v7, v25, vcc_lo                      // 0000007BE0E4: 02023307
	s_cbranch_execz 11                                         // 0000007BE0E8: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi2ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x318>
	v_lshlrev_b32_e32 v6, 1, v7                                // 0000007BE0EC: 300C0E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007BE0F0: BF8700A1
	v_ashrrev_i32_e32 v7, 31, v6                               // 0000007BE0F4: 340E0C9F
	.long 0xd7006a06                                           // 0000007BE0F8: D7006A06
	v_cndmask_b32_e32 v1, v17, v6, vcc_lo                      // 0000007BE0FC: 02020D11
	v_add_co_ci_u32_e64 v7, null, v26, v7, vcc_lo              // 0000007BE100: D5207C07 01AA0F1A
	global_load_d16_b16 v6, v[6:7], off                        // 0000007BE108: DC820000 067C0006
	s_waitcnt vmcnt(0)                                         // 0000007BE110: BF8903F7
	v_cvt_f32_f16_e32 v6, v6                                   // 0000007BE114: 7E0C1706
	s_or_b32 exec_lo, exec_lo, s3                              // 0000007BE118: 8C7E037E
	v_dual_mov_b32 v8, 0 :: v_dual_add_nc_u32 v11, 0xc0, v24   // 0000007BE11C: CA200080 080A30FF 000000C0
	v_mov_b32_e32 v7, 0                                        // 0000007BE128: 7E0E0280
	s_mov_b32 s3, exec_lo                                      // 0000007BE12C: BE83007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007BE130: BF870002
	.long 0xd4c1007e                                           // 0000007BE134: D4C1007E
	v_cndmask_b32_e32 v1, v11, v25, vcc_lo                     // 0000007BE138: 0202330B
	s_cbranch_execz 11                                         // 0000007BE13C: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi2ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x36c>
	v_lshlrev_b32_e32 v7, 1, v11                               // 0000007BE140: 300E1681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007BE144: BF8700A1
	v_ashrrev_i32_e32 v12, 31, v7                              // 0000007BE148: 34180E9F
	.long 0xd7006a0b                                           // 0000007BE14C: D7006A0B
	v_cndmask_b32_e32 v1, v17, v7, vcc_lo                      // 0000007BE150: 02020F11
	v_add_co_ci_u32_e64 v12, null, v26, v12, vcc_lo            // 0000007BE154: D5207C0C 01AA191A
	global_load_d16_b16 v7, v[11:12], off                      // 0000007BE15C: DC820000 077C000B
	s_waitcnt vmcnt(0)                                         // 0000007BE164: BF8903F7
	v_cvt_f32_f16_e32 v7, v7                                   // 0000007BE168: 7E0E1707
	s_or_b32 exec_lo, exec_lo, s3                              // 0000007BE16C: 8C7E037E
	v_add_nc_u32_e32 v11, 0xe0, v24                            // 0000007BE170: 4A1630FF 000000E0
	s_mov_b32 s3, exec_lo                                      // 0000007BE178: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007BE17C: BF870001
	.long 0xd4c1007e                                           // 0000007BE180: D4C1007E
	v_cndmask_b32_e32 v1, v11, v25, vcc_lo                     // 0000007BE184: 0202330B
	s_cbranch_execz 11                                         // 0000007BE188: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi2ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x3b8>
	v_lshlrev_b32_e32 v8, 1, v11                               // 0000007BE18C: 30101681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007BE190: BF8700A1
	v_ashrrev_i32_e32 v12, 31, v8                              // 0000007BE194: 3418109F
	.long 0xd7006a0b                                           // 0000007BE198: D7006A0B
	v_cndmask_b32_e32 v1, v17, v8, vcc_lo                      // 0000007BE19C: 02021111
	v_add_co_ci_u32_e64 v12, null, v26, v12, vcc_lo            // 0000007BE1A0: D5207C0C 01AA191A
	global_load_d16_b16 v8, v[11:12], off                      // 0000007BE1A8: DC820000 087C000B
	s_waitcnt vmcnt(0)                                         // 0000007BE1B0: BF8903F7
	v_cvt_f32_f16_e32 v8, v8                                   // 0000007BE1B4: 7E101708
	s_or_b32 exec_lo, exec_lo, s3                              // 0000007BE1B8: 8C7E037E
	s_branch 9                                                 // 0000007BE1BC: BFA00009 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi2ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x3e4>
	v_mov_b32_e32 v1, 0                                        // 0000007BE1C0: 7E020280
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007BE1C4: BF870001
	v_mov_b32_e32 v2, v1                                       // 0000007BE1C8: 7E040301
	v_mov_b32_e32 v3, v1                                       // 0000007BE1CC: 7E060301
	v_mov_b32_e32 v4, v1                                       // 0000007BE1D0: 7E080301
	v_mov_b32_e32 v5, v1                                       // 0000007BE1D4: 7E0A0301
	v_mov_b32_e32 v6, v1                                       // 0000007BE1D8: 7E0C0301
	v_mov_b32_e32 v7, v1                                       // 0000007BE1DC: 7E0E0301
	v_mov_b32_e32 v8, v1                                       // 0000007BE1E0: 7E100301
	s_add_u32 s4, s4, s14                                      // 0000007BE1E4: 80040E04
	s_addc_u32 s5, s5, s15                                     // 0000007BE1E8: 82050F05
	s_lshr_b32 s3, s11, 31                                     // 0000007BE1EC: 85039F0B
	v_mov_b32_e32 v27, 0                                       // 0000007BE1F0: 7E360280
	s_add_u32 s14, s10, s3                                     // 0000007BE1F4: 800E030A
	s_addc_u32 s15, s11, 0                                     // 0000007BE1F8: 820F800B
	.long 0xd4410003                                           // 0000007BE1FC: D4410003
	v_cndmask_b32_e32 v1, v24, v25, vcc_lo                     // 0000007BE200: 02023318
	s_ashr_i64 s[14:15], s[14:15], 1                           // 0000007BE204: 868E810E
	v_cndmask_b32_e64 v28, 0, 1, s16                           // 0000007BE208: D501001C 00410280
	v_mad_u64_u32 v[18:19], null, v9, s14, s[4:5]              // 0000007BE210: D6FE7C12 00101D09
	.long 0xd72c000c                                           // 0000007BE218: D72C000C
	v_cndmask_b32_e32 v0, v9, v15, vcc_lo                      // 0000007BE21C: 02001F09
	.long 0xd72c000d                                           // 0000007BE220: D72C000D
	v_cndmask_b32_e32 v0, v10, v14, vcc_lo                     // 0000007BE224: 02001D0A
	v_dual_mov_b32 v9, 0 :: v_dual_mov_b32 v10, 0              // 0000007BE228: CA100080 090A0080
	v_mov_b32_e32 v31, 0                                       // 0000007BE230: 7E3E0280
	v_mov_b32_e32 v11, 0                                       // 0000007BE234: 7E160280
	s_delay_alu instid0(VALU_DEP_4)                            // 0000007BE238: BF870004
	v_add3_u32 v29, v13, v19, v12                              // 0000007BE23C: D655001D 0432270D
	v_mov_b32_e32 v12, 0                                       // 0000007BE244: 7E180280
	s_and_saveexec_b32 s4, s3                                  // 0000007BE248: BE842003
	s_cbranch_execz 22                                         // 0000007BE24C: BFA50016 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi2ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x4a8>
	v_lshlrev_b32_e32 v9, 4, v24                               // 0000007BE250: 30123084
	v_mov_b32_e32 v31, 0                                       // 0000007BE254: 7E3E0280
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007BE258: BF8700A2
	v_ashrrev_i32_e32 v10, 31, v9                              // 0000007BE25C: 3414129F
	.long 0xd7006a09                                           // 0000007BE260: D7006A09
	v_cndmask_b32_e32 v1, v18, v9, vcc_lo                      // 0000007BE264: 02021312
	v_add_co_ci_u32_e64 v10, null, v29, v10, vcc_lo            // 0000007BE268: D5207C0A 01AA151D
	s_and_not1_b32 vcc_lo, exec_lo, s16                        // 0000007BE270: 916A107E
	global_load_b128 v[9:12], v[9:10], off                     // 0000007BE274: DC5E0000 097C0009
	s_cbranch_vccnz 10                                         // 0000007BE27C: BFA4000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi2ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x4a8>
	v_lshlrev_b32_e32 v13, 1, v24                              // 0000007BE280: 301A3081
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007BE284: BF870091
	.long 0xd7006a0d                                           // 0000007BE288: D7006A0D
	v_cndmask_b32_e32 v1, v17, v13, vcc_lo                     // 0000007BE28C: 02021B11
	v_add_co_ci_u32_e64 v14, null, 0, v26, vcc_lo              // 0000007BE290: D5207C0E 01AA3480
	global_load_d16_b16 v13, v[13:14], off                     // 0000007BE298: DC820000 0D7C000D
	s_waitcnt vmcnt(0)                                         // 0000007BE2A0: BF8903F7
	v_cvt_f32_f16_e32 v31, v13                                 // 0000007BE2A4: 7E3E170D
	s_or_b32 exec_lo, exec_lo, s4                              // 0000007BE2A8: 8C7E047E
	v_mov_b32_e32 v30, 0                                       // 0000007BE2AC: 7E3C0280
	s_and_saveexec_b32 s14, s3                                 // 0000007BE2B0: BE8E2003
	s_cbranch_execz 290                                        // 0000007BE2B4: BFA50122 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi2ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x940>
	v_dual_mov_b32 v30, 0 :: v_dual_add_nc_u32 v13, 32, v24    // 0000007BE2B8: CA200080 1E0C30A0
	v_dual_mov_b32 v34, v31 :: v_dual_lshlrev_b32 v19, 5, v24  // 0000007BE2C0: CA22011F 22123085
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007BE2C8: BF870002
	v_dual_mov_b32 v27, 0 :: v_dual_lshlrev_b32 v32, 4, v13    // 0000007BE2CC: CA220080 1B201A84
	v_lshlrev_b32_e32 v33, 1, v13                              // 0000007BE2D4: 30421A81
	s_mov_b32 s15, 0                                           // 0000007BE2D8: BE8F0080
	s_lshl_b64 s[4:5], s[10:11], 1                             // 0000007BE2DC: 8484810A
	s_branch 243                                               // 0000007BE2E0: BFA000F3 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi2ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x8b0>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000007BE2E4: 8C7E0A7E
	v_ashrrev_i32_e32 v20, 31, v19                             // 0000007BE2E8: 3428269F
	v_lshrrev_b32_e32 v67, 6, v9                               // 0000007BE2EC: 32861286
	v_lshrrev_b32_e32 v68, 14, v9                              // 0000007BE2F0: 3288128E
	v_and_b32_e32 v69, 0xff, v10                               // 0000007BE2F4: 368A14FF 000000FF
	v_lshrrev_b32_e32 v70, 6, v10                              // 0000007BE2FC: 328C1486
	.long 0xd73c0023                                           // 0000007BE300: D73C0023
	v_cndmask_b32_e32 v1, 1, v19, vcc_lo                       // 0000007BE304: 02022681
	v_and_b32_e32 v20, 0xff, v9                                // 0000007BE308: 362812FF 000000FF
	v_and_b32_e32 v67, 0x3fc, v67                              // 0000007BE310: 368686FF 000003FC
	v_and_b32_e32 v68, 0x3fc, v68                              // 0000007BE318: 368888FF 000003FC
	v_lshrrev_b32_e32 v9, 22, v9                               // 0000007BE320: 32121296
	v_lshrrev_b32_e32 v71, 14, v10                             // 0000007BE324: 328E148E
	.long 0xd7006a3b                                           // 0000007BE328: D7006A3B
	v_cndmask_b32_e32 v1, s6, v35, vcc_lo                      // 0000007BE32C: 02024606
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007BE330: BF8701A1
	v_add_co_ci_u32_e64 v60, null, s7, v36, vcc_lo             // 0000007BE334: D5207C3C 01AA4807
	v_lshlrev_b32_e32 v20, 2, v20                              // 0000007BE33C: 30282882
	.long 0xd7006a3f                                           // 0000007BE340: D7006A3F
	v_cndmask_b32_e32 v0, v59, v4, vcc_lo                      // 0000007BE344: 0200093B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007BE348: BF870001
	v_add_co_ci_u32_e64 v64, null, s5, v60, vcc_lo             // 0000007BE34C: D5207C40 01AA7805
	ds_load_b32 v20, v20                                       // 0000007BE354: D8D80000 14000014
	ds_load_b32 v67, v67                                       // 0000007BE35C: D8D80000 43000043
	ds_load_b32 v68, v68                                       // 0000007BE364: D8D80000 44000044
	s_clause 0x7                                               // 0000007BE36C: BF850007
	global_load_b128 v[35:38], v[59:60], off                   // 0000007BE370: DC5E0000 237C003B
	global_load_b128 v[39:42], v[63:64], off                   // 0000007BE378: DC5E0000 277C003F
	global_load_b128 v[43:46], v[59:60], off offset:16         // 0000007BE380: DC5E0010 2B7C003B
	global_load_b128 v[47:50], v[63:64], off offset:16         // 0000007BE388: DC5E0010 2F7C003F
	global_load_b128 v[51:54], v[59:60], off offset:32         // 0000007BE390: DC5E0020 337C003B
	global_load_b128 v[55:58], v[63:64], off offset:32         // 0000007BE398: DC5E0020 377C003F
	global_load_b128 v[59:62], v[59:60], off offset:48         // 0000007BE3A0: DC5E0030 3B7C003B
	global_load_b128 v[63:66], v[63:64], off offset:48         // 0000007BE3A8: DC5E0030 3F7C003F
	v_lshrrev_b32_e32 v10, 22, v10                             // 0000007BE3B0: 32141496
	v_and_b32_e32 v9, 0x3fc, v9                                // 0000007BE3B4: 361212FF 000003FC
	v_lshlrev_b32_e32 v69, 2, v69                              // 0000007BE3BC: 308A8A82
	v_and_b32_e32 v70, 0x3fc, v70                              // 0000007BE3C0: 368C8CFF 000003FC
	v_and_b32_e32 v71, 0x3fc, v71                              // 0000007BE3C8: 368E8EFF 000003FC
	v_and_b32_e32 v10, 0x3fc, v10                              // 0000007BE3D0: 361414FF 000003FC
	ds_load_b32 v9, v9                                         // 0000007BE3D8: D8D80000 09000009
	ds_load_b32 v69, v69                                       // 0000007BE3E0: D8D80000 45000045
	ds_load_b32 v70, v70                                       // 0000007BE3E8: D8D80000 46000046
	ds_load_b32 v71, v71                                       // 0000007BE3F0: D8D80000 47000047
	ds_load_b32 v10, v10                                       // 0000007BE3F8: D8D80000 0A00000A
	v_add_nc_u32_e32 v32, 0x200, v32                           // 0000007BE400: 4A4040FF 00000200
	s_and_b32 s3, exec_lo, s3                                  // 0000007BE408: 8B03037E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000007BE40C: BF870009
	s_or_b32 s15, s3, s15                                      // 0000007BE410: 8C0F0F03
	s_waitcnt vmcnt(7) lgkmcnt(7)                              // 0000007BE414: BF891C77
	v_dot2_f32_bf16 v35, v35, v20, 0                           // 0000007BE418: CC1A4023 1A022923
	s_waitcnt vmcnt(6)                                         // 0000007BE420: BF891BF7
	v_dot2_f32_bf16 v20, v39, v20, 0                           // 0000007BE424: CC1A4014 1A022927
	v_and_b32_e32 v39, 0xff, v11                               // 0000007BE42C: 364E16FF 000000FF
	s_waitcnt lgkmcnt(6)                                       // 0000007BE434: BF89FC67
	v_dot2_f32_bf16 v35, v36, v67, v35                         // 0000007BE438: CC1A4023 1C8E8724
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007BE440: BF870003
	v_dot2_f32_bf16 v20, v40, v67, v20                         // 0000007BE444: CC1A4014 1C528728
	v_lshrrev_b32_e32 v36, 6, v11                              // 0000007BE44C: 32481686
	v_lshrrev_b32_e32 v40, 14, v11                             // 0000007BE450: 3250168E
	v_lshrrev_b32_e32 v11, 22, v11                             // 0000007BE454: 32161696
	s_waitcnt lgkmcnt(5)                                       // 0000007BE458: BF89FC57
	v_dot2_f32_bf16 v35, v37, v68, v35                         // 0000007BE45C: CC1A4023 1C8E8925
	v_dot2_f32_bf16 v20, v41, v68, v20                         // 0000007BE464: CC1A4014 1C528929
	v_and_b32_e32 v36, 0x3fc, v36                              // 0000007BE46C: 364848FF 000003FC
	v_lshrrev_b32_e32 v41, 6, v12                              // 0000007BE474: 32521886
	v_and_b32_e32 v37, 0xff, v12                               // 0000007BE478: 364A18FF 000000FF
	s_waitcnt lgkmcnt(4)                                       // 0000007BE480: BF89FC47
	v_dot2_f32_bf16 v35, v38, v9, v35                          // 0000007BE484: CC1A4023 1C8E1326
	v_dot2_f32_bf16 v9, v42, v9, v20                           // 0000007BE48C: CC1A4009 1C52132A
	v_lshlrev_b32_e32 v20, 2, v39                              // 0000007BE494: 30284E82
	v_and_b32_e32 v38, 0x3fc, v40                              // 0000007BE498: 364C50FF 000003FC
	v_lshrrev_b32_e32 v67, 14, v12                             // 0000007BE4A0: 3286188E
	s_waitcnt vmcnt(5) lgkmcnt(3)                              // 0000007BE4A4: BF891437
	v_dot2_f32_bf16 v35, v43, v69, v35                         // 0000007BE4A8: CC1A4023 1C8E8B2B
	s_waitcnt vmcnt(4)                                         // 0000007BE4B0: BF8913F7
	v_dot2_f32_bf16 v9, v47, v69, v9                           // 0000007BE4B4: CC1A4009 1C268B2F
	ds_load_b32 v20, v20                                       // 0000007BE4BC: D8D80000 14000014
	ds_load_b32 v36, v36                                       // 0000007BE4C4: D8D80000 24000024
	ds_load_b32 v38, v38                                       // 0000007BE4CC: D8D80000 26000026
	s_waitcnt lgkmcnt(5)                                       // 0000007BE4D4: BF89FC57
	v_dot2_f32_bf16 v35, v44, v70, v35                         // 0000007BE4D8: CC1A4023 1C8E8D2C
	v_dot2_f32_bf16 v9, v48, v70, v9                           // 0000007BE4E0: CC1A4009 1C268D30
	v_lshrrev_b32_e32 v12, 22, v12                             // 0000007BE4E8: 32181896
	v_and_b32_e32 v39, 0x3fc, v41                              // 0000007BE4EC: 364E52FF 000003FC
	v_cndmask_b32_e64 v41, v7, v8, s2                          // 0000007BE4F4: D5010029 000A1107
	s_waitcnt lgkmcnt(4)                                       // 0000007BE4FC: BF89FC47
	v_dot2_f32_bf16 v35, v45, v71, v35                         // 0000007BE500: CC1A4023 1C8E8F2D
	v_dot2_f32_bf16 v9, v49, v71, v9                           // 0000007BE508: CC1A4009 1C268F31
	v_and_b32_e32 v11, 0x3fc, v11                              // 0000007BE510: 361616FF 000003FC
	v_lshlrev_b32_e32 v37, 2, v37                              // 0000007BE518: 304A4A82
	v_and_b32_e32 v40, 0x3fc, v67                              // 0000007BE51C: 365086FF 000003FC
	s_waitcnt lgkmcnt(3)                                       // 0000007BE524: BF89FC37
	v_dot2_f32_bf16 v35, v46, v10, v35                         // 0000007BE528: CC1A4023 1C8E152E
	v_dot2_f32_bf16 v9, v50, v10, v9                           // 0000007BE530: CC1A4009 1C261532
	v_and_b32_e32 v12, 0x3fc, v12                              // 0000007BE538: 361818FF 000003FC
	ds_load_b32 v10, v11                                       // 0000007BE540: D8D80000 0A00000B
	ds_load_b32 v11, v37                                       // 0000007BE548: D8D80000 0B000025
	ds_load_b32 v42, v39                                       // 0000007BE550: D8D80000 2A000027
	ds_load_b32 v43, v40                                       // 0000007BE558: D8D80000 2B000028
	ds_load_b32 v44, v12                                       // 0000007BE560: D8D80000 2C00000C
	v_cndmask_b32_e64 v40, v6, v7, s2                          // 0000007BE568: D5010028 000A0F06
	v_cndmask_b32_e64 v39, v5, v6, s2                          // 0000007BE570: D5010027 000A0D05
	v_cndmask_b32_e64 v37, v3, v4, s2                          // 0000007BE578: D5010025 000A0903
	s_waitcnt vmcnt(3) lgkmcnt(7)                              // 0000007BE580: BF890C77
	v_dot2_f32_bf16 v12, v51, v20, v35                         // 0000007BE584: CC1A400C 1C8E2933
	s_waitcnt vmcnt(2)                                         // 0000007BE58C: BF890BF7
	v_dot2_f32_bf16 v9, v55, v20, v9                           // 0000007BE590: CC1A4009 1C262937
	v_cndmask_b32_e64 v20, v31, v1, s2                         // 0000007BE598: D5010014 000A031F
	v_cndmask_b32_e64 v35, v1, v2, s2                          // 0000007BE5A0: D5010023 000A0501
	v_mov_b32_e32 v31, v34                                     // 0000007BE5A8: 7E3E0322
	s_waitcnt lgkmcnt(6)                                       // 0000007BE5AC: BF89FC67
	v_dot2_f32_bf16 v12, v52, v36, v12                         // 0000007BE5B0: CC1A400C 1C324934
	v_dot2_f32_bf16 v9, v56, v36, v9                           // 0000007BE5B8: CC1A4009 1C264938
	v_cndmask_b32_e64 v36, v2, v3, s2                          // 0000007BE5C0: D5010024 000A0702
	s_waitcnt lgkmcnt(5)                                       // 0000007BE5C8: BF89FC57
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007BE5CC: BF870193
	v_dot2_f32_bf16 v12, v53, v38, v12                         // 0000007BE5D0: CC1A400C 1C324D35
	v_dot2_f32_bf16 v9, v57, v38, v9                           // 0000007BE5D8: CC1A4009 1C264D39
	v_cndmask_b32_e64 v38, v4, v5, s2                          // 0000007BE5E0: D5010026 000A0B04
	s_waitcnt lgkmcnt(4)                                       // 0000007BE5E8: BF89FC47
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007BE5EC: BF870193
	v_dot2_f32_bf16 v12, v54, v10, v12                         // 0000007BE5F0: CC1A400C 1C321536
	v_dot2_f32_bf16 v9, v58, v10, v9                           // 0000007BE5F8: CC1A4009 1C26153A
	v_mov_b32_e32 v10, v14                                     // 0000007BE600: 7E14030E
	s_waitcnt vmcnt(1) lgkmcnt(3)                              // 0000007BE604: BF890437
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007BE608: BF870003
	v_dot2_f32_bf16 v5, v59, v11, v12                          // 0000007BE60C: CC1A4005 1C32173B
	s_waitcnt vmcnt(0)                                         // 0000007BE614: BF8903F7
	v_dot2_f32_bf16 v6, v63, v11, v9                           // 0000007BE618: CC1A4006 1C26173F
	v_dual_mov_b32 v12, v16 :: v_dual_mov_b32 v11, v15         // 0000007BE620: CA100110 0C0A010F
	v_mov_b32_e32 v9, v13                                      // 0000007BE628: 7E12030D
	s_waitcnt lgkmcnt(2)                                       // 0000007BE62C: BF89FC27
	v_dot2_f32_bf16 v1, v60, v42, v5                           // 0000007BE630: CC1A4001 1C16553C
	v_dot2_f32_bf16 v2, v64, v42, v6                           // 0000007BE638: CC1A4002 1C1A5540
	v_dual_mov_b32 v42, v8 :: v_dual_add_nc_u32 v33, 64, v33   // 0000007BE640: CA200108 2A2042C0
	v_add_nc_u32_e32 v19, 0x400, v19                           // 0000007BE648: 4A2626FF 00000400
	s_waitcnt lgkmcnt(1)                                       // 0000007BE650: BF89FC17
	v_dot2_f32_bf16 v1, v61, v43, v1                           // 0000007BE654: CC1A4001 1C06573D
	v_dot2_f32_bf16 v2, v65, v43, v2                           // 0000007BE65C: CC1A4002 1C0A5741
	s_waitcnt lgkmcnt(0)                                       // 0000007BE664: BF89FC07
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007BE668: BF870112
	v_dot2_f32_bf16 v1, v62, v44, v1                           // 0000007BE66C: CC1A4001 1C06593E
	v_dot2_f32_bf16 v2, v66, v44, v2                           // 0000007BE674: CC1A4002 1C0A5942
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007BE67C: BF870112
	v_fmac_f32_e32 v30, v20, v1                                // 0000007BE680: 563C0314
	v_fmac_f32_e32 v27, v20, v2                                // 0000007BE684: 56360514
	v_dual_mov_b32 v1, v35 :: v_dual_mov_b32 v2, v36           // 0000007BE688: CA100123 01020124
	v_dual_mov_b32 v3, v37 :: v_dual_mov_b32 v4, v38           // 0000007BE690: CA100125 03040126
	v_dual_mov_b32 v5, v39 :: v_dual_mov_b32 v6, v40           // 0000007BE698: CA100127 05060128
	v_dual_mov_b32 v7, v41 :: v_dual_mov_b32 v8, v42           // 0000007BE6A0: CA100129 0708012A
	s_and_not1_b32 exec_lo, exec_lo, s15                       // 0000007BE6A8: 917E0F7E
	s_cbranch_execz 35                                         // 0000007BE6AC: BFA50023 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi2ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x93c>
	s_waitcnt vmcnt(0)                                         // 0000007BE6B0: BF8903F7
	v_dual_mov_b32 v13, v9 :: v_dual_add_nc_u32 v24, 32, v24   // 0000007BE6B4: CA200109 0D1830A0
	v_dual_mov_b32 v14, v10 :: v_dual_mov_b32 v15, v11         // 0000007BE6BC: CA10010A 0E0E010B
	v_mov_b32_e32 v16, v12                                     // 0000007BE6C4: 7E20030C
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007BE6C8: BF870003
	.long 0xd4460003                                           // 0000007BE6CC: D4460003
	v_cndmask_b32_e32 v1, v24, v25, vcc_lo                     // 0000007BE6D0: 02023318
	s_mov_b32 s10, exec_lo                                     // 0000007BE6D4: BE8A007E
	.long 0xd4c1007e                                           // 0000007BE6D8: D4C1007E
	v_cndmask_b32_e32 v1, v24, v25, vcc_lo                     // 0000007BE6DC: 02023318
	s_cbranch_execz 65280                                      // 0000007BE6E0: BFA5FF00 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi2ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x4e4>
	v_ashrrev_i32_e32 v14, 31, v32                             // 0000007BE6E4: 341C409F
	.long 0xd7006a0d                                           // 0000007BE6E8: D7006A0D
	v_cndmask_b32_e32 v1, v18, v32, vcc_lo                     // 0000007BE6EC: 02024112
	v_mov_b32_e32 v34, v31                                     // 0000007BE6F0: 7E44031F
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007BE6F4: BF870003
	v_add_co_ci_u32_e64 v14, null, v29, v14, vcc_lo            // 0000007BE6F8: D5207C0E 01AA1D1D
	v_cmp_ne_u32_e32 vcc_lo, 1, v28                            // 0000007BE700: 7C9A3881
	global_load_b128 v[13:16], v[13:14], off                   // 0000007BE704: DC5E0000 0D7C000D
	s_cbranch_vccnz 65269                                      // 0000007BE70C: BFA4FEF5 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi2ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x4e4>
	v_ashrrev_i32_e32 v20, 31, v33                             // 0000007BE710: 3428429F
	.long 0xd7006a22                                           // 0000007BE714: D7006A22
	v_cndmask_b32_e32 v1, v17, v33, vcc_lo                     // 0000007BE718: 02024311
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007BE71C: BF870001
	v_add_co_ci_u32_e64 v35, null, v26, v20, vcc_lo            // 0000007BE720: D5207C23 01AA291A
	global_load_d16_b16 v20, v[34:35], off                     // 0000007BE728: DC820000 147C0022
	s_waitcnt vmcnt(0)                                         // 0000007BE730: BF8903F7
	v_cvt_f32_f16_e32 v34, v20                                 // 0000007BE734: 7E441714
	s_branch 65258                                             // 0000007BE738: BFA0FEEA <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi2ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x4e4>
	s_or_b32 exec_lo, exec_lo, s15                             // 0000007BE73C: 8C7E0F7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007BE740: BF8700B9
	s_or_b32 exec_lo, exec_lo, s14                             // 0000007BE744: 8C7E0E7E
	.long 0xd71f0001                                           // 0000007BE748: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000007BE74C: 020100C1
	s_mov_b32 s2, exec_lo                                      // 0000007BE750: BE82007E
	v_xor_b32_e32 v2, 16, v1                                   // 0000007BE754: 3A040290
	v_xor_b32_e32 v4, 8, v1                                    // 0000007BE758: 3A080288
	v_xor_b32_e32 v6, 4, v1                                    // 0000007BE75C: 3A0C0284
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000007BE760: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 0000007BE764: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 0000007BE768: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v4                            // 0000007BE76C: 7C9808A0
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007BE770: BF870002
	v_lshlrev_b32_e32 v2, 2, v2                                // 0000007BE774: 30040482
	v_cndmask_b32_e32 v4, v1, v4, vcc_lo                       // 0000007BE778: 02080901
	v_cmp_gt_u32_e32 vcc_lo, 32, v6                            // 0000007BE77C: 7C980CA0
	ds_bpermute_b32 v3, v2, v30                                // 0000007BE780: DACC0000 03001E02
	s_waitcnt lgkmcnt(0)                                       // 0000007BE788: BF89FC07
	v_dual_add_f32 v3, v30, v3 :: v_dual_lshlrev_b32 v4, 2, v4 // 0000007BE78C: C922071E 03040882
	ds_bpermute_b32 v5, v4, v3                                 // 0000007BE794: DACC0000 05000304
	s_waitcnt lgkmcnt(0)                                       // 0000007BE79C: BF89FC07
	v_add_f32_e32 v3, v3, v5                                   // 0000007BE7A0: 06060B03
	ds_bpermute_b32 v2, v2, v27                                // 0000007BE7A4: DACC0000 02001B02
	v_cndmask_b32_e32 v6, v1, v6, vcc_lo                       // 0000007BE7AC: 020C0D01
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007BE7B0: BF870001
	v_lshlrev_b32_e32 v6, 2, v6                                // 0000007BE7B4: 300C0C82
	s_waitcnt lgkmcnt(0)                                       // 0000007BE7B8: BF89FC07
	v_add_f32_e32 v2, v27, v2                                  // 0000007BE7BC: 0604051B
	ds_bpermute_b32 v4, v4, v2                                 // 0000007BE7C0: DACC0000 04000204
	s_waitcnt lgkmcnt(0)                                       // 0000007BE7C8: BF89FC07
	v_add_f32_e32 v2, v2, v4                                   // 0000007BE7CC: 06040902
	ds_bpermute_b32 v4, v6, v3                                 // 0000007BE7D0: DACC0000 04000306
	ds_bpermute_b32 v5, v6, v2                                 // 0000007BE7D8: DACC0000 05000206
	v_xor_b32_e32 v6, 2, v1                                    // 0000007BE7E0: 3A0C0282
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007BE7E4: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v6                            // 0000007BE7E8: 7C980CA0
	v_cndmask_b32_e32 v6, v1, v6, vcc_lo                       // 0000007BE7EC: 020C0D01
	s_waitcnt lgkmcnt(1)                                       // 0000007BE7F0: BF89FC17
	v_dual_add_f32 v3, v3, v4 :: v_dual_lshlrev_b32 v6, 2, v6  // 0000007BE7F4: C9220903 03060C82
	s_waitcnt lgkmcnt(0)                                       // 0000007BE7FC: BF89FC07
	v_add_f32_e32 v4, v2, v5                                   // 0000007BE800: 06080B02
	ds_bpermute_b32 v2, v6, v3                                 // 0000007BE804: DACC0000 02000306
	ds_bpermute_b32 v5, v6, v4                                 // 0000007BE80C: DACC0000 05000406
	v_xor_b32_e32 v6, 1, v1                                    // 0000007BE814: 3A0C0281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007BE818: BF8700A1
	v_cmp_gt_u32_e32 vcc_lo, 32, v6                            // 0000007BE81C: 7C980CA0
	v_cndmask_b32_e32 v1, v1, v6, vcc_lo                       // 0000007BE820: 02020D01
	v_lshlrev_b32_e32 v6, 2, v1                                // 0000007BE824: 300C0282
	s_waitcnt lgkmcnt(0)                                       // 0000007BE828: BF89FC07
	v_dual_add_f32 v2, v3, v2 :: v_dual_add_f32 v1, v4, v5     // 0000007BE82C: C9080503 02000B04
	ds_bpermute_b32 v4, v6, v2                                 // 0000007BE834: DACC0000 04000206
	ds_bpermute_b32 v3, v6, v1                                 // 0000007BE83C: DACC0000 03000106
	v_cmpx_eq_u32_e32 0, v23                                   // 0000007BE844: 7D942E80
	s_cbranch_execz 10                                         // 0000007BE848: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi2ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0xa74>
	s_waitcnt lgkmcnt(1)                                       // 0000007BE84C: BF89FC17
	v_dual_add_f32 v2, v2, v4 :: v_dual_lshlrev_b32 v5, 3, v22 // 0000007BE850: C9220902 02042C83
	s_waitcnt lgkmcnt(0)                                       // 0000007BE858: BF89FC07
	v_add_f32_e32 v3, v1, v3                                   // 0000007BE85C: 06060701
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007BE860: BF870002
	v_lshl_or_b32 v4, v21, 4, v5                               // 0000007BE864: D6560004 04150915
	ds_store_b64 v4, v[2:3] offset:1024                        // 0000007BE86C: D9340400 00000204
	s_or_b32 exec_lo, exec_lo, s2                              // 0000007BE874: 8C7E027E
	s_waitcnt lgkmcnt(0)                                       // 0000007BE878: BF89FC07
	v_lshrrev_b32_e32 v3, 1, v0                                // 0000007BE87C: 32060081
	v_mov_b32_e32 v2, s21                                      // 0000007BE880: 7E040215
	.long 0xd44c0002                                           // 0000007BE884: D44C0002
	v_cndmask_b32_e32 v1, 8, v0, vcc_lo                        // 0000007BE888: 02020088
	s_waitcnt vmcnt(0)                                         // 0000007BE88C: BF8903F7
	s_barrier                                                  // 0000007BE890: BFBD0000
	v_or_b32_e32 v1, s20, v3                                   // 0000007BE894: 38020614
	buffer_gl0_inv                                             // 0000007BE898: E0AC0000 00000000
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[1:2]                  // 0000007BE8A0: 7CA8020C
	s_and_b32 s2, s2, vcc_lo                                   // 0000007BE8A4: 8B026A02
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000007BE8A8: BF870009
	s_and_saveexec_b32 s3, s2                                  // 0000007BE8AC: BE832002
	s_cbranch_execz 80                                         // 0000007BE8B0: BFA50050 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi2ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0xbf4>
	v_and_b32_e32 v0, 1, v0                                    // 0000007BE8B4: 36000081
	s_load_b32 s0, s[0:1], 0x48                                // 0000007BE8B8: F4000000 F8000048
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007BE8C0: BF870091
	v_lshlrev_b32_e32 v4, 2, v0                                // 0000007BE8C4: 30080082
	v_lshl_or_b32 v3, v3, 4, v4                                // 0000007BE8C8: D6560003 04110903
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000007BE8D0: BF8700C1
	v_add_nc_u32_e32 v3, 0x400, v3                             // 0000007BE8D4: 4A0606FF 00000400
	ds_load_2addr_b32 v[3:4], v3 offset1:2                     // 0000007BE8DC: D8DC0200 03000003
	s_waitcnt lgkmcnt(0)                                       // 0000007BE8E4: BF89FC07
	v_add_f32_e32 v3, 0, v3                                    // 0000007BE8E8: 06060680
	v_add_f32_e32 v3, v3, v4                                   // 0000007BE8EC: 06060903
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007BE8F0: BF870091
	v_bfe_u32 v4, v3, 16, 1                                    // 0000007BE8F4: D6100004 02052103
	v_add3_u32 v3, v3, v4, 0x7fff                              // 0000007BE8FC: D6550003 03FE0903 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007BE908: BF870091
	v_and_b32_e32 v3, 0xffff0000, v3                           // 0000007BE90C: 360606FF FFFF0000
	v_mul_f32_e32 v5, s0, v3                                   // 0000007BE914: 100A0600
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007BE918: BF870091
	v_mul_f32_e32 v3, 0xbfb8aa3b, v5                           // 0000007BE91C: 10060AFF BFB8AA3B
	v_exp_f32_e32 v3, v3                                       // 0000007BE924: 7E064B03
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007BE928: BF870095
	v_add_f32_e32 v6, 1.0, v3                                  // 0000007BE92C: 060C06F2
	v_div_scale_f32 v3, null, v6, v6, v5                       // 0000007BE930: D6FC7C03 04160D06
	v_div_scale_f32 v8, vcc_lo, v5, v6, v5                     // 0000007BE938: D6FC6A08 04160D05
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000007BE940: BF870292
	v_rcp_f32_e32 v7, v3                                       // 0000007BE944: 7E0E5503
	v_fma_f32 v4, -v3, v7, 1.0                                 // 0000007BE948: D6130004 23CA0F03
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007BE950: BF870091
	v_fmac_f32_e32 v7, v4, v7                                  // 0000007BE954: 560E0F04
	v_mul_f32_e32 v9, v8, v7                                   // 0000007BE958: 10120F08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007BE95C: BF870091
	v_fma_f32 v4, -v3, v9, v8                                  // 0000007BE960: D6130004 24221303
	v_fmac_f32_e32 v9, v4, v7                                  // 0000007BE968: 56120F04
	.long 0xd72c0004                                           // 0000007BE96C: D72C0004
	v_cndmask_b32_e32 v1, s13, v0, vcc_lo                      // 0000007BE970: 0202000D
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000007BE974: BF870122
	v_fma_f32 v8, -v3, v9, v8                                  // 0000007BE978: D6130008 24221303
	.long 0xd72c0003                                           // 0000007BE980: D72C0003
	v_cndmask_b32_e32 v1, s12, v0, vcc_lo                      // 0000007BE984: 0202000C
	v_div_fmas_f32 v0, v8, v7, v9                              // 0000007BE988: D6370000 04260F08
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007BE990: BF870112
	.long 0xd73c0003                                           // 0000007BE994: D73C0003
	v_cndmask_b32_e32 v1, 1, v3, vcc_lo                        // 0000007BE998: 02020681
	v_div_fixup_f32 v5, v0, v6, v5                             // 0000007BE99C: D6270005 04160D00
	.long 0xd73c0000                                           // 0000007BE9A4: D73C0000
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 0000007BE9A8: 02020281
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007BE9AC: BF870193
	.long 0xd7006a03                                           // 0000007BE9B0: D7006A03
	v_cndmask_b32_e32 v1, s8, v3, vcc_lo                       // 0000007BE9B4: 02020608
	v_bfe_u32 v2, v5, 16, 1                                    // 0000007BE9B8: D6100002 02052105
	v_add_co_ci_u32_e64 v4, null, s9, v4, vcc_lo               // 0000007BE9C0: D5207C04 01AA0809
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007BE9C8: BF870193
	.long 0xd7006a00                                           // 0000007BE9CC: D7006A00
	v_cndmask_b32_e32 v1, v3, v0, vcc_lo                       // 0000007BE9D0: 02020103
	v_add3_u32 v2, v5, v2, 0x7fff                              // 0000007BE9D4: D6550002 03FE0505 00007FFF
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007BE9E0: BF870003
	v_add_co_ci_u32_e64 v1, null, v4, v1, vcc_lo               // 0000007BE9E4: D5207C01 01AA0304
	global_store_d16_hi_b16 v[0:1], v2, off                    // 0000007BE9EC: DC960000 007C0200
	s_endpgm                                                   // 0000007BE9F4: BFB00000
		...

