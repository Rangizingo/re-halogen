0000000000916b00 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi4ELi2EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi>:
; _ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi4ELi2EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi():
	s_clause 0x1                                               // 000000916B00: BF850001
	s_load_b32 s3, s[0:1], 0x88                                // 000000916B04: F40000C0 F8000088
	s_load_b512 s[12:27], s[0:1], null                         // 000000916B0C: F4100300 F8000000
	s_mov_b32 s4, -1                                           // 000000916B14: BE8400C1
	s_waitcnt lgkmcnt(0)                                       // 000000916B18: BF89FC07
	s_cmp_lt_i32 s2, s3                                        // 000000916B1C: BF040302
	s_cbranch_scc1 2427                                        // 000000916B20: BFA2097B <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi4ELi2EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0x2610>
	s_load_b64 s[8:9], s[0:1], 0x7c                            // 000000916B24: F4040200 F800007C
	s_sub_i32 s3, s2, s3                                       // 000000916B2C: 81830302
	s_clause 0x1                                               // 000000916B30: BF850001
	s_load_b256 s[44:51], s[0:1], 0x60                         // 000000916B34: F40C0B00 F8000060
	s_load_b256 s[36:43], s[0:1], 0x40                         // 000000916B3C: F40C0900 F8000040
	v_lshrrev_b32_e32 v11, 5, v0                               // 000000916B44: 32160085
	v_and_b32_e32 v12, 31, v0                                  // 000000916B48: 3618009F
	s_mov_b32 s34, 0                                           // 000000916B4C: BEA20080
	s_mov_b32 s33, exec_lo                                     // 000000916B50: BEA1007E
	s_waitcnt lgkmcnt(0)                                       // 000000916B54: BF89FC07
	s_abs_i32 s4, s9                                           // 000000916B58: BE841509
	s_ashr_i32 s7, s9, 31                                      // 000000916B5C: 86079F09
	s_cvt_f32_u32 s5, s4                                       // 000000916B60: BE856504
	s_sub_i32 s6, 0, s4                                        // 000000916B64: 81860480
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000916B68: BF87029A
	v_rcp_iflag_f32_e32 v1, s5                                 // 000000916B6C: 7E025605
	v_readfirstlane_b32 s5, v1                                 // 000000916B70: 7E0A0501
	s_mul_f32 s5, s5, 0x4f7ffffe                               // 000000916B74: A205FF05 4F7FFFFE
	s_delay_alu instid0(SALU_CYCLE_3) | instskip(NEXT) | instid1(SALU_CYCLE_3)// 000000916B7C: BF87059B
	s_cvt_u32_f32 s5, s5                                       // 000000916B80: BE856705
	s_mul_i32 s6, s6, s5                                       // 000000916B84: 96060506
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000916B88: BF870499
	s_mul_hi_u32 s6, s5, s6                                    // 000000916B8C: 96860605
	s_add_i32 s5, s5, s6                                       // 000000916B90: 81050605
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000916B94: BF870499
	s_mul_hi_u32 s5, s3, s5                                    // 000000916B98: 96850503
	s_mul_i32 s6, s5, s4                                       // 000000916B9C: 96060405
	s_add_i32 s10, s5, 1                                       // 000000916BA0: 810A8105
	s_sub_i32 s6, s3, s6                                       // 000000916BA4: 81860603
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000916BA8: BF870009
	s_sub_i32 s11, s6, s4                                      // 000000916BAC: 818B0406
	s_cmp_ge_u32 s6, s4                                        // 000000916BB0: BF090406
	s_cselect_b32 s5, s10, s5                                  // 000000916BB4: 9805050A
	s_cselect_b32 s6, s11, s6                                  // 000000916BB8: 9806060B
	s_add_i32 s10, s5, 1                                       // 000000916BBC: 810A8105
	s_cmp_ge_u32 s6, s4                                        // 000000916BC0: BF090406
	s_cselect_b32 s4, s10, s5                                  // 000000916BC4: 9804050A
	s_ashr_i32 s11, s50, 31                                    // 000000916BC8: 860B9F32
	s_xor_b32 s4, s4, s7                                       // 000000916BCC: 8D040704
	s_lshr_b32 s1, s11, 25                                     // 000000916BD0: 8501990B
	s_sub_i32 s10, s4, s7                                      // 000000916BD4: 818A0704
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000916BD8: BF870499
	s_mul_i32 s0, s10, s9                                      // 000000916BDC: 9600090A
	s_sub_i32 s30, s3, s0                                      // 000000916BE0: 819E0003
	s_add_i32 s0, s50, s1                                      // 000000916BE4: 81000132
	s_mul_i32 s31, s30, s8                                     // 000000916BE8: 961F081E
	s_ashr_i32 s0, s0, 7                                       // 000000916BEC: 86008700
	s_add_i32 s1, s31, s8                                      // 000000916BF0: 8101081F
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000916BF4: BF870499
	s_min_i32 s0, s0, s1                                       // 000000916BF8: 89000100
	s_sub_i32 s29, s0, s31                                     // 000000916BFC: 819D1F00
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000916C00: BF870499
	s_lshl_b32 s28, s29, 1                                     // 000000916C04: 841C811D
	.long 0xd4c4007e                                           // 000000916C08: D4C4007E
	v_cndmask_b32_e32 v1, s28, v11, vcc_lo                     // 000000916C0C: 0202161C
	s_cbranch_execz 505                                        // 000000916C10: BFA501F9 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi4ELi2EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0x8f8>
	s_add_i32 s35, s48, -1                                     // 000000916C14: 8123C130
	s_cmp_lg_u64 s[40:41], 0                                   // 000000916C18: BF118028
	v_dual_mov_b32 v8, v11 :: v_dual_and_b32 v1, 1, v0         // 000000916C1C: CA24010B 08000081
	s_cselect_b32 s51, -1, 0                                   // 000000916C24: 983380C1
	s_abs_i32 s52, s29                                         // 000000916C28: BEB4151D
	v_and_b32_e32 v2, 2, v0                                    // 000000916C2C: 36040082
	s_cvt_f32_u32 s0, s52                                      // 000000916C30: BE806534
	v_lshlrev_b32_e32 v6, 3, v12                               // 000000916C34: 300C1883
	v_lshlrev_b32_e32 v7, 7, v11                               // 000000916C38: 300E1687
	v_and_b32_e32 v3, 4, v0                                    // 000000916C3C: 36060084
	v_rcp_iflag_f32_e32 v4, s0                                 // 000000916C40: 7E085600
	v_and_b32_e32 v5, 8, v0                                    // 000000916C44: 360A0088
	.long 0xd44a0001                                           // 000000916C48: D44A0001
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 000000916C4C: 02020280
	.long 0xd44a0003                                           // 000000916C50: D44A0003
	v_cndmask_b32_e32 v1, 0, v2, vcc_lo                        // 000000916C54: 02020480
	v_lshl_or_b32 v1, v11, 8, v6                               // 000000916C58: D6560001 0419110B
	v_lshl_add_u32 v2, s31, 7, v7                              // 000000916C60: D6460002 041D0E1F
	s_ashr_i32 s54, s29, 31                                    // 000000916C68: 86369F1D
	s_sub_i32 s56, 0, s52                                      // 000000916C6C: 81B83480
	s_mul_i32 s8, s54, 0x1400                                  // 000000916C70: 9608FF36 00001400
	.long 0xd44c0000                                           // 000000916C78: D44C0000
	v_cndmask_b32_e32 v1, 16, v12, vcc_lo                      // 000000916C7C: 02021890
	v_readfirstlane_b32 s5, v4                                 // 000000916C80: 7E0A0504
	.long 0xd44a0004                                           // 000000916C84: D44A0004
	v_cndmask_b32_e32 v1, 0, v3, vcc_lo                        // 000000916C88: 02020680
	v_subrev_nc_u32_e32 v9, s8, v1                             // 000000916C8C: 4E120208
	v_lshl_or_b32 v1, v12, 2, v2                               // 000000916C90: D6560001 0409050C
	s_lshl_b32 s6, s29, 7                                      // 000000916C98: 8406871D
	s_mul_f32 s7, s5, 0x4f7ffffe                               // 000000916C9C: A207FF05 4F7FFFFE
	.long 0xd44a0005                                           // 000000916CA4: D44A0005
	v_cndmask_b32_e32 v1, 0, v5, vcc_lo                        // 000000916CA8: 02020A80
	s_mov_b32 s53, 0x76543210                                  // 000000916CAC: BEB500FF 76543210
	s_lshl_b32 s55, s29, 8                                     // 000000916CB4: 8437881D
	s_cvt_u32_f32 s7, s7                                       // 000000916CB8: BE876707
	s_mov_b32 s58, 0x3db504f3                                  // 000000916CBC: BEBA00FF 3DB504F3
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000916CC4: BF87049A
	s_mul_i32 s56, s56, s7                                     // 000000916CC8: 96380738
	s_mul_hi_u32 s8, s7, s56                                   // 000000916CCC: 96883807
	s_sub_i32 s56, 0, s6                                       // 000000916CD0: 81B80680
	s_add_i32 s57, s7, s8                                      // 000000916CD4: 81390807
	s_branch 166                                               // 000000916CD8: BFA000A6 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi4ELi2EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0x474>
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000916CDC: BF870091
	.long 0xd7006a02                                           // 000000916CE0: D7006A02
	v_cndmask_b32_e32 v1, s26, v2, vcc_lo                      // 000000916CE4: 0202041A
	v_add_co_ci_u32_e64 v3, null, s27, v3, vcc_lo              // 000000916CE8: D5207C03 01AA061B
	v_add_nc_u32_e32 v1, 0x400, v1                             // 000000916CF0: 4A0202FF 00000400
	v_add_nc_u32_e32 v8, 8, v8                                 // 000000916CF8: 4A101088
	global_load_d16_b16 v2, v[2:3], off offset:6               // 000000916CFC: DC820006 027C0002
	v_cmp_le_i32_e32 vcc_lo, s28, v8                           // 000000916D04: 7C86101C
	s_or_b32 s34, vcc_lo, s34                                  // 000000916D08: 8C22226A
	s_waitcnt vmcnt(0)                                         // 000000916D0C: BF8903F7
	v_fma_mix_f32 v5, v16, v2, v14 op_sel_hi:[0,1,0]           // 000000916D10: CC200005 143A0510
	v_sub_f32_e32 v4, v17, v15                                 // 000000916D18: 08081F11
	v_fma_mix_f32 v2, -v16, v2, v14 op_sel_hi:[0,1,0]          // 000000916D1C: CC200002 343A0510
	v_add_f32_e32 v3, v17, v15                                 // 000000916D24: 06061F11
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000916D28: BF8701A2
	v_add_f32_e32 v7, v4, v2                                   // 000000916D2C: 060E0504
	v_sub_f32_e32 v2, v4, v2                                   // 000000916D30: 08040504
	v_add_f32_e32 v6, v3, v5                                   // 000000916D34: 060C0B03
	v_sub_f32_e32 v3, v3, v5                                   // 000000916D38: 08060B03
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000916D3C: BF870193
	v_mov_b32_dpp v15, v2 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000916D40: 7E1E02FA FF016102
	v_mov_b32_dpp v4, v6 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000916D48: 7E0802FA FF016106
	v_cndmask_b32_e64 v6, -v6, v6, s1                          // 000000916D50: D5010006 20060D06
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000916D58: BF870234
	v_mov_b32_dpp v14, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000916D5C: 7E1C02FA FF016103
	v_cndmask_b32_e64 v2, -v2, v2, s1                          // 000000916D64: D5010002 20060502
	v_cndmask_b32_e64 v3, -v3, v3, s1                          // 000000916D6C: D5010003 20060703
	v_add_f32_e32 v4, v6, v4                                   // 000000916D74: 06080906
	v_mov_b32_dpp v5, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000916D78: 7E0A02FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, s1                          // 000000916D80: D5010007 20060F07
	.long 0xd72c0006                                           // 000000916D88: D72C0006
	v_cndmask_b32_e32 v1, 0x1400, v13, vcc_lo                  // 000000916D8C: 02021AFF 00001400
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000916D94: BF870242
	v_dual_add_f32 v2, v2, v15 :: v_dual_add_f32 v5, v7, v5    // 000000916D98: C9081F02 02040B07
	v_mov_b32_dpp v7, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000916DA0: 7E0E02FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, s3                          // 000000916DA8: D5010004 200E0904
	v_add_f32_e32 v3, v3, v14                                  // 000000916DB0: 06061D03
	v_mov_b32_dpp v15, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000916DB4: 7E1E02FA FF016202
	v_mov_b32_dpp v13, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000916DBC: 7E1A02FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, s3                          // 000000916DC4: D5010005 200E0B05
	v_cndmask_b32_e64 v2, -v2, v2, s3                          // 000000916DCC: D5010002 200E0502
	v_add_f32_e32 v4, v4, v7                                   // 000000916DD4: 06080F04
	v_mov_b32_dpp v14, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000916DD8: 7E1C02FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, s3                          // 000000916DE0: D5010003 200E0703
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000916DE8: BF870234
	v_dual_add_f32 v5, v5, v13 :: v_dual_add_f32 v2, v2, v15   // 000000916DEC: C9081B05 05021F02
	.long 0xd72c0007                                           // 000000916DF4: D72C0007
	v_cndmask_b32_e32 v1, s55, v10, vcc_lo                     // 000000916DF8: 02021437
	v_mov_b32_dpp v10, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000916DFC: 7E1402FA FF016404
	v_add_f32_e32 v3, v3, v14                                  // 000000916E04: 06061D03
	s_delay_alu instid0(VALU_DEP_4)                            // 000000916E08: BF870004
	v_mov_b32_dpp v13, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000916E0C: 7E1A02FA FF016405
	v_cndmask_b32_e64 v4, -v4, v4, s4                          // 000000916E14: D5010004 20120904
	v_cndmask_b32_e64 v5, -v5, v5, s4                          // 000000916E1C: D5010005 20120B05
	v_mov_b32_dpp v15, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000916E24: 7E1E02FA FF016402
	v_mov_b32_dpp v14, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000916E2C: 7E1C02FA FF016403
	v_cndmask_b32_e64 v2, -v2, v2, s4                          // 000000916E34: D5010002 20120502
	v_cndmask_b32_e64 v3, -v3, v3, s4                          // 000000916E3C: D5010003 20120703
	v_dual_add_f32 v4, v4, v10 :: v_dual_add_f32 v5, v5, v13   // 000000916E44: C9081504 04041B05
	v_sub_nc_u32_e32 v6, v6, v7                                // 000000916E4C: 4C0C0F06
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000916E50: BF870193
	v_dual_add_f32 v2, v2, v15 :: v_dual_add_f32 v3, v3, v14   // 000000916E54: C9081F02 02021D03
	v_mov_b32_dpp v10, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000916E5C: 7E1402FA FF016804
	s_delay_alu instid0(VALU_DEP_4)                            // 000000916E64: BF870004
	v_mov_b32_dpp v13, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000916E68: 7E1A02FA FF016805
	v_cndmask_b32_e64 v4, -v4, v4, s5                          // 000000916E70: D5010004 20160904
	v_cndmask_b32_e64 v5, -v5, v5, s5                          // 000000916E78: D5010005 20160B05
	v_mov_b32_dpp v14, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000916E80: 7E1C02FA FF016803
	v_mov_b32_dpp v15, v2 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000916E88: 7E1E02FA FF016802
	v_cndmask_b32_e64 v2, -v2, v2, s5                          // 000000916E90: D5010002 20160502
	v_cndmask_b32_e64 v3, -v3, v3, s5                          // 000000916E98: D5010003 20160703
	v_dual_add_f32 v4, v4, v10 :: v_dual_add_f32 v5, v5, v13   // 000000916EA0: C9081504 04041B05
	v_add_nc_u32_e32 v6, v9, v6                                // 000000916EA8: 4A0C0D09
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000916EAC: BF870193
	v_dual_add_f32 v2, v2, v15 :: v_dual_add_f32 v3, v3, v14   // 000000916EB0: C9081F02 02021D03
	v_dual_mov_b32 v10, v4 :: v_dual_mov_b32 v13, v5           // 000000916EB8: CA100104 0A0C0105
	v_cndmask_b32_e64 v5, -v5, v5, s0                          // 000000916EC0: D5010005 20020B05
	s_delay_alu instid0(VALU_DEP_3)                            // 000000916EC8: BF870003
	v_mov_b32_e32 v15, v2                                      // 000000916ECC: 7E1E0302
	v_cndmask_b32_e64 v4, -v4, v4, s0                          // 000000916ED0: D5010004 20020904
	v_cndmask_b32_e64 v2, -v2, v2, s0                          // 000000916ED8: D5010002 20020502
	v_permlanex16_b32 v13, v13, s53, 0xfedcba98                // 000000916EE0: D65C000D 03FC6B0D FEDCBA98
	v_mov_b32_e32 v14, v3                                      // 000000916EEC: 7E1C0303
	v_cndmask_b32_e64 v3, -v3, v3, s0                          // 000000916EF0: D5010003 20020703
	v_permlanex16_b32 v10, v10, s53, 0xfedcba98                // 000000916EF8: D65C000A 03FC6B0A FEDCBA98
	v_permlanex16_b32 v15, v15, s53, 0xfedcba98                // 000000916F04: D65C000F 03FC6B0F FEDCBA98
	v_add_f32_e32 v5, v5, v13                                  // 000000916F10: 060A1B05
	v_permlanex16_b32 v14, v14, s53, 0xfedcba98                // 000000916F14: D65C000E 03FC6B0E FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000916F20: BF870214
	v_dual_add_f32 v4, v4, v10 :: v_dual_add_nc_u32 v9, 0x800, v9// 000000916F24: C9201504 040812FF 00000800
	v_add_f32_e32 v7, v2, v15                                  // 000000916F30: 060E1F02
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000916F34: BF870214
	v_fma_mixhi_f16 v2, v5, s58, 0                             // 000000916F38: CC220002 02007505
	v_add_f32_e32 v10, v3, v14                                 // 000000916F40: 06141D03
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000916F44: BF870214
	v_fma_mixlo_f16 v2, v4, s58, 0                             // 000000916F48: CC210002 02007504
	v_fma_mixhi_f16 v3, v7, s58, 0                             // 000000916F50: CC220003 02007507
	s_delay_alu instid0(VALU_DEP_3)                            // 000000916F58: BF870003
	v_fma_mixlo_f16 v3, v10, s58, 0                            // 000000916F5C: CC210003 0200750A
	ds_store_b64 v6, v[2:3] offset:16384                       // 000000916F64: D9344000 00000206
	s_and_not1_b32 exec_lo, exec_lo, s34                       // 000000916F6C: 917E227E
	s_cbranch_execz 289                                        // 000000916F70: BFA50121 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi4ELi2EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0x8f8>
	.long 0xd72d0002                                           // 000000916F74: D72D0002
	v_cndmask_b32_e32 v0, v8, v57, vcc_lo                      // 000000916F78: 02007308
	s_mov_b32 s6, -1                                           // 000000916F7C: BE8600C1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000916F80: BF870091
	.long 0xd72c0003                                           // 000000916F84: D72C0003
	v_cndmask_b32_e32 v0, v2, v52, vcc_lo                      // 000000916F88: 02006902
	v_sub_nc_u32_e32 v3, v8, v3                                // 000000916F8C: 4C060708
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000916F90: BF870121
	v_subrev_nc_u32_e32 v5, s52, v3                            // 000000916F94: 4E0A0634
	v_cmp_le_u32_e32 vcc_lo, s52, v3                           // 000000916F98: 7C960634
	v_dual_cndmask_b32 v3, v3, v5 :: v_dual_add_nc_u32 v4, 1, v2// 000000916F9C: CA600B03 03040481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000916FA4: BF870111
	v_cndmask_b32_e32 v2, v2, v4, vcc_lo                       // 000000916FA8: 02040902
	v_cmp_le_u32_e32 vcc_lo, s52, v3                           // 000000916FAC: 7C960634
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000916FB0: BF870092
	v_add_nc_u32_e32 v4, 1, v2                                 // 000000916FB4: 4A080481
	v_cndmask_b32_e32 v2, v2, v4, vcc_lo                       // 000000916FB8: 02040902
	s_and_not1_b32 vcc_lo, exec_lo, s51                        // 000000916FBC: 916A337E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000916FC0: BF870091
	v_xor_b32_e32 v13, s54, v2                                 // 000000916FC4: 3A1A0436
	v_subrev_nc_u32_e32 v10, s54, v13                          // 000000916FC8: 4E141A36
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000916FCC: BF8700A1
	v_mad_u64_u32 v[6:7], null, s56, v10, v[1:2]               // 000000916FD0: D6FE7C06 04061438
	v_min_i32_e32 v2, s35, v10                                 // 000000916FD8: 22041423
	v_mad_i64_i32 v[4:5], null, v2, s50, 0                     // 000000916FDC: D6FF7C04 02006502
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000916FE4: BF870093
	v_ashrrev_i32_e32 v7, 31, v6                               // 000000916FE8: 340E0C9F
	.long 0xd73c0002                                           // 000000916FEC: D73C0002
	v_cndmask_b32_e32 v1, 1, v6, vcc_lo                        // 000000916FF0: 02020C81
	s_cbranch_vccnz 212                                        // 000000916FF4: BFA400D4 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi4ELi2EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0x848>
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000916FF8: BF870093
	.long 0xd7006a06                                           // 000000916FFC: D7006A06
	v_cndmask_b32_e32 v1, v4, v6, vcc_lo                       // 000000917000: 02020D04
	v_add_co_ci_u32_e64 v7, null, v5, v7, vcc_lo               // 000000917004: D5207C07 01AA0F05
	.long 0x7f3c3880                                           // 00000091700C: 7F3C3880
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000917010: BF870112
	.long 0xd73c0006                                           // 000000917014: D73C0006
	v_cndmask_b32_e32 v1, 1, v6, vcc_lo                        // 000000917018: 02020C81
	.long 0x7f42399e                                           // 00000091701C: 7F42399E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000917020: BF870092
	.long 0xd7006a0e                                           // 000000917024: D7006A0E
	v_cndmask_b32_e32 v1, s38, v6, vcc_lo                      // 000000917028: 02020C26
	v_add_co_ci_u32_e64 v15, null, s39, v7, vcc_lo             // 00000091702C: D5207C0F 01AA0E27
	.long 0xd7006a06                                           // 000000917034: D7006A06
	v_cndmask_b32_e32 v1, s40, v6, vcc_lo                      // 000000917038: 02020C28
	s_delay_alu instid0(VALU_DEP_1)                            // 00000091703C: BF870001
	v_add_co_ci_u32_e64 v7, null, s41, v7, vcc_lo              // 000000917040: D5207C07 01AA0E29
	global_load_b64 v[14:15], v[14:15], off                    // 000000917048: DC560000 0E7C000E
	.long 0xd7006a10                                           // 000000917050: D7006A10
	v_cndmask_b32_e32 v1, s26, v2, vcc_lo                      // 000000917054: 0202041A
	global_load_b64 v[6:7], v[6:7], off                        // 000000917058: DC560000 067C0006
	v_add_co_ci_u32_e64 v17, null, s27, v3, vcc_lo             // 000000917060: D5207C11 01AA061B
	s_clause 0x1                                               // 000000917068: BF850001
	global_load_b32 v18, v[16:17], off                         // 00000091706C: DC520000 127C0010
	global_load_d16_b16 v16, v[16:17], off offset:4            // 000000917074: DC820004 107C0010
	s_waitcnt vmcnt(3)                                         // 00000091707C: BF890FF7
	.long 0x7e22390e                                           // 000000917080: 7E22390E
	s_waitcnt vmcnt(2)                                         // 000000917084: BF890BF7
	v_and_b32_e32 v40, 0xffff0000, v6                          // 000000917088: 36500CFF FFFF0000
	v_lshlrev_b32_e32 v6, 16, v6                               // 000000917090: 300C0C90
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000917094: BF870093
	v_lshlrev_b32_e32 v17, 16, v17                             // 000000917098: 30222290
	v_mul_f32_e32 v21, 0xbfb8aa3b, v17                         // 00000091709C: 102A22FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000009170A4: BF870291
	v_exp_f32_e32 v21, v21                                     // 0000009170A8: 7E2A4B15
	v_dual_add_f32 v21, 1.0, v21 :: v_dual_and_b32 v14, 0xffff0000, v14// 0000009170AC: C9242AF2 150E1CFF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000009170B8: BF870111
	v_mul_f32_e32 v20, 0xbfb8aa3b, v14                         // 0000009170BC: 10281CFF BFB8AA3B
	v_div_scale_f32 v25, null, v21, v21, v17                   // 0000009170C4: D6FC7C19 04462B15
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000009170CC: BF8701B2
	v_exp_f32_e32 v20, v20                                     // 0000009170D0: 7E284B14
	v_lshlrev_b32_e32 v19, 16, v15                             // 0000009170D4: 30261E90
	v_div_scale_f32 v38, s7, v17, v21, v17                     // 0000009170D8: D6FC0726 04462B11
	v_rcp_f32_e32 v29, v25                                     // 0000009170E0: 7E3A5519
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009170E4: BF870196
	v_add_f32_e32 v20, 1.0, v20                                // 0000009170E8: 062828F2
	v_mul_f32_e32 v22, 0xbfb8aa3b, v19                         // 0000009170EC: 102C26FF BFB8AA3B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009170F4: BF870195
	v_fma_f32 v37, -v25, v29, 1.0                              // 0000009170F8: D6130025 23CA3B19
	v_div_scale_f32 v24, null, v20, v20, v14                   // 000000917100: D6FC7C18 043A2914
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000917108: BF8701B3
	v_exp_f32_e32 v22, v22                                     // 00000091710C: 7E2C4B16
	v_and_b32_e32 v15, 0xffff0000, v15                         // 000000917110: 361E1EFF FFFF0000
	v_div_scale_f32 v34, vcc_lo, v14, v20, v14                 // 000000917118: D6FC6A22 043A290E
	v_rcp_f32_e32 v27, v24                                     // 000000917120: 7E365518
	s_delay_alu instid0(TRANS32_DEP_2) | instid1(VALU_DEP_2)   // 000000917124: BF870106
	v_dual_add_f32 v22, 1.0, v22 :: v_dual_mul_f32 v23, 0xbfb8aa3b, v15// 000000917128: C9062CF2 16161EFF BFB8AA3B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000917134: BF870115
	v_fma_f32 v35, -v24, v27, 1.0                              // 000000917138: D6130023 23CA3718
	v_div_scale_f32 v26, null, v22, v22, v19                   // 000000917140: D6FC7C1A 044E2D16
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000917148: BF8701A3
	v_exp_f32_e32 v23, v23                                     // 00000091714C: 7E2E4B17
	v_div_scale_f32 v36, s6, v19, v22, v19                     // 000000917150: D6FC0624 044E2D13
	v_fmac_f32_e32 v27, v35, v27                               // 000000917158: 56363723
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 00000091715C: BF870313
	v_rcp_f32_e32 v31, v26                                     // 000000917160: 7E3E551A
	v_add_f32_e32 v23, 1.0, v23                                // 000000917164: 062E2EF2
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000917168: BF870115
	v_fma_f32 v39, -v26, v31, 1.0                              // 00000091716C: D6130027 23CA3F1A
	v_div_scale_f32 v28, null, v23, v23, v15                   // 000000917174: D6FC7C1C 043E2F17
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000091717C: BF8701A2
	v_fmac_f32_e32 v31, v39, v31                               // 000000917180: 563E3F27
	v_mul_f32_e32 v39, v34, v27                                // 000000917184: 104E3722
	v_rcp_f32_e32 v32, v28                                     // 000000917188: 7E40551C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000091718C: BF870091
	v_fma_f32 v42, -v24, v39, v34                              // 000000917190: D613002A 248A4F18
	v_fmac_f32_e32 v39, v42, v27                               // 000000917198: 564E372A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000091719C: BF870115
	v_fma_f32 v35, -v28, v32, 1.0                              // 0000009171A0: D6130023 23CA411C
	v_fma_f32 v24, -v24, v39, v34                              // 0000009171A8: D6130018 248A4F18
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000009171B0: BF870112
	v_fmac_f32_e32 v32, v35, v32                               // 0000009171B4: 56404123
	v_div_fmas_f32 v24, v24, v27, v39                          // 0000009171B8: D6370018 049E3718
	s_mov_b32 vcc_lo, s7                                       // 0000009171C0: BEEA0007
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000009171C4: BF8701B1
	v_div_fixup_f32 v14, v24, v20, v14                         // 0000009171C8: D627000E 043A2918
	v_fmac_f32_e32 v29, v37, v29                               // 0000009171D0: 563A3B25
	v_div_scale_f32 v37, s8, v15, v23, v15                     // 0000009171D4: D6FC0825 043E2F0F
	v_mul_f32_e32 v14, v14, v40                                // 0000009171DC: 101C510E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009171E0: BF870193
	v_mul_f32_e32 v35, v38, v29                                // 0000009171E4: 10463B26
	v_mul_f32_e32 v43, v37, v32                                // 0000009171E8: 10564125
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009171EC: BF870193
	.long 0x7e3c398e                                           // 0000009171F0: 7E3C398E
	v_fma_f32 v44, -v25, v35, v38                              // 0000009171F4: D613002C 249A4719
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000009171FC: BF870113
	v_fma_f32 v42, -v28, v43, v37                              // 000000917200: D613002A 2496571C
	v_fmac_f32_e32 v35, v44, v29                               // 000000917208: 56463B2C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000091720C: BF870112
	v_fmac_f32_e32 v43, v42, v32                               // 000000917210: 5656412A
	v_fma_f32 v25, -v25, v35, v38                              // 000000917214: D6130019 249A4719
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000091721C: BF870112
	v_fma_f32 v24, -v28, v43, v37                              // 000000917220: D6130018 2496571C
	v_div_fmas_f32 v25, v25, v29, v35                          // 000000917228: D6370019 048E3B19
	s_mov_b32 vcc_lo, s6                                       // 000000917230: BEEA0006
	s_mov_b32 s6, 0                                            // 000000917234: BE860080
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000917238: BF870121
	v_div_fixup_f32 v17, v25, v21, v17                         // 00000091723C: D6270011 04462B19
	v_lshlrev_b32_e32 v21, 16, v7                              // 000000917244: 302A0E90
	v_dual_mul_f32 v6, v17, v6 :: v_dual_and_b32 v7, 0xffff0000, v7// 000000917248: C8E40D11 06060EFF FFFF0000
	v_mul_f32_e32 v41, v36, v31                                // 000000917254: 10523F24
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000917258: BF870112
	.long 0x7e423986                                           // 00000091725C: 7E423986
	v_fma_f32 v45, -v26, v41, v36                              // 000000917260: D613002D 2492531A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000917268: BF870091
	v_fmac_f32_e32 v41, v45, v31                               // 00000091726C: 56523F2D
	v_fma_f32 v26, -v26, v41, v36                              // 000000917270: D613001A 2492531A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000917278: BF870131
	v_div_fmas_f32 v20, v26, v31, v41                          // 00000091727C: D6370014 04A63F1A
	s_mov_b32 vcc_lo, s8                                       // 000000917284: BEEA0008
	v_div_fmas_f32 v17, v24, v32, v43                          // 000000917288: D6370011 04AE4118
	v_div_fixup_f32 v19, v20, v22, v19                         // 000000917290: D6270013 044E2D14
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000917298: BF8701A2
	v_div_fixup_f32 v15, v17, v23, v15                         // 00000091729C: D627000F 043E2F11
	v_and_b32_e32 v17, 1, v30                                  // 0000009172A4: 36223C81
	v_mul_f32_e32 v19, v19, v21                                // 0000009172A8: 10262B13
	v_and_b32_e32 v21, 1, v33                                  // 0000009172AC: 362A4281
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009172B0: BF870214
	v_mul_f32_e32 v7, v15, v7                                  // 0000009172B4: 100E0F0F
	v_add3_u32 v14, v14, v17, 0x7fff                           // 0000009172B8: D655000E 03FE230E 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009172C4: BF870214
	v_bfe_u32 v20, v19, 16, 1                                  // 0000009172C8: D6100014 02052113
	v_add3_u32 v6, v6, v21, 0x7fff                             // 0000009172D0: D6550006 03FE2B06 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009172DC: BF870214
	v_bfe_u32 v17, v7, 16, 1                                   // 0000009172E0: D6100011 02052107
	v_and_b32_e32 v14, 0xffff0000, v14                         // 0000009172E8: 361C1CFF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009172F0: BF870214
	v_add3_u32 v15, v19, v20, 0x7fff                           // 0000009172F4: D655000F 03FE2913 00007FFF
	v_and_b32_e32 v6, 0xffff0000, v6                           // 000000917300: 360C0CFF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000917308: BF870194
	v_add3_u32 v7, v7, v17, 0x7fff                             // 00000091730C: D6550007 03FE2307 00007FFF
	v_and_b32_e32 v19, 0xffff0000, v15                         // 000000917318: 36261EFF FFFF0000
	s_waitcnt vmcnt(1)                                         // 000000917320: BF8907F7
	v_fma_mix_f32 v15, v18, v14, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000917324: CC20080F 8A021D12
	v_fma_mix_f32 v17, v18, v6, neg(0) op_sel_hi:[1,0,0]       // 00000091732C: CC200011 8A020D12
	s_waitcnt vmcnt(0)                                         // 000000917334: BF8903F7
	v_fma_mix_f32 v14, v16, v19, neg(0) op_sel_hi:[1,0,0]      // 000000917338: CC20000E 8A022710
	v_and_b32_e32 v16, 0xffff0000, v7                          // 000000917340: 36200EFF FFFF0000
	s_and_not1_b32 vcc_lo, exec_lo, s6                         // 000000917348: 916A067E
	s_cbranch_vccnz 65123                                      // 00000091734C: BFA4FE63 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi4ELi2EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0x1dc>
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000917350: BF870093
	.long 0xd73c0004                                           // 000000917354: D73C0004
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 000000917358: 02020881
	.long 0xd7006a04                                           // 00000091735C: D7006A04
	v_cndmask_b32_e32 v1, s38, v4, vcc_lo                      // 000000917360: 02020826
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000917364: BF870111
	v_add_co_ci_u32_e64 v5, null, s39, v5, vcc_lo              // 000000917368: D5207C05 01AA0A27
	.long 0xd7006a04                                           // 000000917370: D7006A04
	v_cndmask_b32_e32 v1, v4, v2, vcc_lo                       // 000000917374: 02020504
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000917378: BF8700A1
	v_add_co_ci_u32_e64 v5, null, v5, v3, vcc_lo               // 00000091737C: D5207C05 01AA0705
	.long 0xd7006a06                                           // 000000917384: D7006A06
	v_cndmask_b32_e32 v1, s26, v2, vcc_lo                      // 000000917388: 0202041A
	v_add_co_ci_u32_e64 v7, null, s27, v3, vcc_lo              // 00000091738C: D5207C07 01AA061B
	global_load_b64 v[4:5], v[4:5], off                        // 000000917394: DC560000 047C0004
	s_clause 0x1                                               // 00000091739C: BF850001
	global_load_b32 v16, v[6:7], off                           // 0000009173A0: DC520000 107C0006
	global_load_d16_b16 v6, v[6:7], off offset:4               // 0000009173A8: DC820004 067C0006
	s_waitcnt vmcnt(2)                                         // 0000009173B0: BF890BF7
	.long 0x7e0e3904                                           // 0000009173B4: 7E0E3904
	v_and_b32_e32 v4, 0xffff0000, v4                           // 0000009173B8: 360808FF FFFF0000
	v_lshlrev_b32_e32 v14, 16, v5                              // 0000009173C0: 301C0A90
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000009173C4: BF8701A3
	v_lshlrev_b32_e32 v7, 16, v7                               // 0000009173C8: 300E0E90
	s_waitcnt vmcnt(1)                                         // 0000009173CC: BF8907F7
	v_fma_mix_f32 v15, v16, v4, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 0000009173D0: CC20080F 8A020910
	s_waitcnt vmcnt(0)                                         // 0000009173D8: BF8903F7
	v_fma_mix_f32 v14, v6, v14, neg(0) op_sel_hi:[1,0,0]       // 0000009173DC: CC20000E 8A021D06
	v_fma_mix_f32 v17, v16, v7, neg(0) op_sel_hi:[1,0,0]       // 0000009173E4: CC200011 8A020F10
	v_and_b32_e32 v16, 0xffff0000, v5                          // 0000009173EC: 36200AFF FFFF0000
	s_branch 65081                                             // 0000009173F4: BFA0FE39 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi4ELi2EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0x1dc>
	s_or_b32 exec_lo, exec_lo, s33                             // 0000009173F8: 8C7E217E
	s_bfe_i32 s28, s29, 0x1001c                                // 0000009173FC: 939CFF1D 0001001C
	s_lshr_b32 s3, s11, 28                                     // 000000917404: 85039C0B
	s_lshr_b64 s[0:1], s[28:29], 29                            // 000000917408: 85809D1C
	s_add_i32 s3, s50, s3                                      // 00000091740C: 81030332
	s_add_i32 s0, s0, 7                                        // 000000917410: 81008700
	s_lshl_b32 s1, s29, 3                                      // 000000917414: 8401831D
	s_ashr_i32 s0, s0, 3                                       // 000000917418: 86008300
	s_lshl_b32 s4, s31, 3                                      // 00000091741C: 8404831F
	.long 0xd72c0001                                           // 000000917420: D72C0001
	v_cndmask_b32_e32 v1, s0, v11, vcc_lo                      // 000000917424: 02021600
	v_lshlrev_b32_e32 v13, 2, v12                              // 000000917428: 301A1882
	s_waitcnt lgkmcnt(0)                                       // 00000091742C: BF89FC07
	s_barrier                                                  // 000000917430: BFBD0000
	buffer_gl0_inv                                             // 000000917434: E0AC0000 00000000
	v_add_nc_u32_e32 v2, s0, v1                                // 00000091743C: 4A040200
	s_ashr_i32 s0, s3, 4                                       // 000000917440: 86008403
	s_ashr_i32 s3, s4, 31                                      // 000000917444: 86039F04
	s_mul_hi_i32 s5, s10, s0                                   // 000000917448: 9705000A
	s_mul_i32 s0, s10, s0                                      // 00000091744C: 9600000A
	v_min_i32_e32 v14, s1, v2                                  // 000000917450: 221C0401
	s_add_u32 s0, s0, s4                                       // 000000917454: 80000400
	s_addc_u32 s1, s5, s3                                      // 000000917458: 82010305
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000091745C: BF870099
	s_lshl_b64 s[4:5], s[0:1], 10                              // 000000917460: 84848A00
	v_cmp_lt_i32_e32 vcc_lo, v1, v14                           // 000000917464: 7C821D01
	s_add_u32 s1, s24, s4                                      // 000000917468: 80010418
	s_addc_u32 s3, s25, s5                                     // 00000091746C: 82030519
	s_and_saveexec_b32 s4, vcc_lo                              // 000000917470: BE84206A
	s_cbranch_execz 93                                         // 000000917474: BFA5005D <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi4ELi2EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0xaec>
	.long 0xd7010002                                           // 000000917478: D7010002
	v_cndmask_b32_e32 v0, v12, v129, vcc_lo                    // 00000091747C: 0201030C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000917480: BF870121
	v_cndmask_b32_e64 v3, v2, 31, s0                           // 000000917484: D5010003 00013F02
	v_ashrrev_i32_e32 v2, 31, v1                               // 00000091748C: 3404029F
	.long 0xd44c0000                                           // 000000917490: D44C0000
	v_cndmask_b32_e32 v1, 31, v3, vcc_lo                       // 000000917494: 0202069F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000917498: BF870091
	v_cndmask_b32_e64 v5, 0xe1, 1, s0                          // 00000091749C: D5010005 000102FF 000000E1
	v_dual_mov_b32 v4, 0 :: v_dual_add_nc_u32 v7, v5, v3       // 0000009174A8: CA200080 04060705
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000009174B0: BF870114
	.long 0xd73c0005                                           // 0000009174B4: D73C0005
	v_cndmask_b32_e32 v1, 10, v1, vcc_lo                       // 0000009174B8: 0202028A
	.long 0xd73c0002                                           // 0000009174BC: D73C0002
	v_cndmask_b32_e32 v1, 2, v3, vcc_lo                        // 0000009174C0: 02020682
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000009174C4: BF870223
	v_lshlrev_b32_e32 v4, 24, v7                               // 0000009174C8: 30080E98
	v_bfe_i32 v8, v7, 7, 1                                     // 0000009174CC: D6110008 02050F07
	.long 0xd7000009                                           // 0000009174D4: D7000009
	v_cndmask_b32_e32 v1, s1, v5, vcc_lo                       // 0000009174D8: 02020A01
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009174DC: BF870211
	v_add_co_ci_u32_e64 v10, null, s3, v6, s0                  // 0000009174E0: D5207C0A 00020C03
	v_ashrrev_i32_e32 v4, 22, v4                               // 0000009174E8: 34080896
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000009174EC: BF870093
	.long 0xd7000005                                           // 0000009174F0: D7000005
	v_cndmask_b32_e32 v1, v9, v2, vcc_lo                       // 0000009174F4: 02020509
	v_add_co_ci_u32_e64 v6, null, v10, v3, s0                  // 0000009174F8: D5207C06 0002070A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000917500: BF870093
	.long 0xd7000007                                           // 000000917504: D7000007
	v_cndmask_b32_e32 v1, v9, v4, vcc_lo                       // 000000917508: 02020909
	v_add_co_ci_u32_e64 v8, null, v10, v8, s0                  // 00000091750C: D5207C08 0002110A
	.long 0xd7000009                                           // 000000917514: D7000009
	v_cndmask_b32_e32 v1, v9, v13, vcc_lo                      // 000000917518: 02021B09
	s_delay_alu instid0(VALU_DEP_1)                            // 00000091751C: BF870001
	v_add_co_ci_u32_e64 v10, null, 0, v10, s0                  // 000000917520: D5207C0A 00021480
	s_clause 0x17                                              // 000000917528: BF850017
	global_load_b32 v4, v[5:6], off                            // 00000091752C: DC520000 047C0005
	global_load_b32 v2, v[5:6], off offset:128                 // 000000917534: DC520080 027C0005
	global_load_b32 v65, v[5:6], off offset:256                // 00000091753C: DC520100 417C0005
	global_load_b32 v62, v[5:6], off offset:384                // 000000917544: DC520180 3E7C0005
	global_load_b32 v59, v[5:6], off offset:512                // 00000091754C: DC520200 3B7C0005
	global_load_b32 v56, v[5:6], off offset:640                // 000000917554: DC520280 387C0005
	global_load_b32 v53, v[5:6], off offset:768                // 00000091755C: DC520300 357C0005
	global_load_b32 v35, v[5:6], off offset:896                // 000000917564: DC520380 237C0005
	global_load_b32 v6, v[7:8], off                            // 00000091756C: DC520000 067C0007
	global_load_b32 v3, v[7:8], off offset:128                 // 000000917574: DC520080 037C0007
	global_load_b32 v66, v[7:8], off offset:256                // 00000091757C: DC520100 427C0007
	global_load_b32 v63, v[7:8], off offset:384                // 000000917584: DC520180 3F7C0007
	global_load_b32 v60, v[7:8], off offset:512                // 00000091758C: DC520200 3C7C0007
	global_load_b32 v57, v[7:8], off offset:640                // 000000917594: DC520280 397C0007
	global_load_b32 v55, v[7:8], off offset:768                // 00000091759C: DC520300 377C0007
	global_load_b32 v36, v[7:8], off offset:896                // 0000009175A4: DC520380 247C0007
	global_load_b32 v5, v[9:10], off                           // 0000009175AC: DC520000 057C0009
	global_load_b32 v67, v[9:10], off offset:128               // 0000009175B4: DC520080 437C0009
	global_load_b32 v64, v[9:10], off offset:256               // 0000009175BC: DC520100 407C0009
	global_load_b32 v61, v[9:10], off offset:384               // 0000009175C4: DC520180 3D7C0009
	global_load_b32 v58, v[9:10], off offset:512               // 0000009175CC: DC520200 3A7C0009
	global_load_b32 v54, v[9:10], off offset:640               // 0000009175D4: DC520280 367C0009
	global_load_b32 v52, v[9:10], off offset:768               // 0000009175DC: DC520300 347C0009
	global_load_b32 v34, v[9:10], off offset:896               // 0000009175E4: DC520380 227C0009
	s_or_b32 exec_lo, exec_lo, s4                              // 0000009175EC: 8C7E047E
	v_dual_mov_b32 v15, 0 :: v_dual_mov_b32 v18, 0             // 0000009175F0: CA100080 0F120080
	v_dual_mov_b32 v20, 0 :: v_dual_mov_b32 v23, 0             // 0000009175F8: CA100080 14160080
	v_dual_mov_b32 v22, 0 :: v_dual_mov_b32 v25, 0             // 000000917600: CA100080 16180080
	v_dual_mov_b32 v24, 0 :: v_dual_mov_b32 v29, 0             // 000000917608: CA100080 181C0080
	v_dual_mov_b32 v16, 0 :: v_dual_mov_b32 v21, 0             // 000000917610: CA100080 10140080
	v_dual_mov_b32 v17, 0 :: v_dual_mov_b32 v26, 0             // 000000917618: CA100080 111A0080
	v_dual_mov_b32 v19, 0 :: v_dual_mov_b32 v28, 0             // 000000917620: CA100080 131C0080
	v_dual_mov_b32 v27, 0 :: v_dual_mov_b32 v30, 0             // 000000917628: CA100080 1B1E0080
	s_ashr_i32 s11, s10, 31                                    // 000000917630: 860B9F0A
	s_and_saveexec_b32 s0, vcc_lo                              // 000000917634: BE80206A
	s_cbranch_execz 1002                                       // 000000917638: BFA503EA <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi4ELi2EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0x1ae4>
	v_dual_mov_b32 v18, 0 :: v_dual_add_nc_u32 v7, -1, v0      // 00000091763C: CA200080 120600C1
	v_dual_mov_b32 v15, 0 :: v_dual_lshlrev_b32 v32, 2, v12    // 000000917644: CA220080 0F201882
	v_and_or_b32 v31, v0, 16, 0x4000                           // 00000091764C: D657001F 03FD2100 00004000
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000917658: BF870123
	v_dual_mov_b32 v20, 0 :: v_dual_and_b32 v7, 31, v7         // 00000091765C: CA240080 14060E9F
	v_dual_mov_b32 v22, 0 :: v_dual_mov_b32 v23, 0             // 000000917664: CA100080 16160080
	v_dual_mov_b32 v24, 0 :: v_dual_lshlrev_b32 v33, 2, v7     // 00000091766C: CA220080 18200E82
	v_dual_mov_b32 v25, 0 :: v_dual_mov_b32 v16, 0             // 000000917674: CA100080 19100080
	v_dual_mov_b32 v29, 0 :: v_dual_mov_b32 v26, 0             // 00000091767C: CA100080 1D1A0080
	v_dual_mov_b32 v21, 0 :: v_dual_mov_b32 v28, 0             // 000000917684: CA100080 151C0080
	v_dual_mov_b32 v17, 0 :: v_dual_mov_b32 v30, 0             // 00000091768C: CA100080 111E0080
	v_mov_b32_e32 v19, 0                                       // 000000917694: 7E260280
	v_mov_b32_e32 v27, 0                                       // 000000917698: 7E360280
	s_mov_b32 s4, 0                                            // 00000091769C: BE840080
	s_movk_i32 s5, 0x1eee                                      // 0000009176A0: B0051EEE
	s_branch 916                                               // 0000009176A4: BFA00394 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi4ELi2EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0x19f8>
	s_or_b32 exec_lo, exec_lo, s6                              // 0000009176A8: 8C7E067E
	s_waitcnt vmcnt(15)                                        // 0000009176AC: BF893FF7
	v_alignbit_b32 v4, v4, v6, 16                              // 0000009176B0: D6160004 02420D04
	s_waitcnt vmcnt(7)                                         // 0000009176B8: BF891FF7
	v_bfe_u32 v68, v5, 12, 16                                  // 0000009176BC: D6100044 02411905
	v_bfe_u32 v69, v5, 8, 16                                   // 0000009176C4: D6100045 02411105
	v_bfe_u32 v70, v5, 4, 16                                   // 0000009176CC: D6100046 02410905
	v_lshl_add_u32 v1, v1, 5, v31                              // 0000009176D4: D6460001 047D0B01
	v_and_b32_e32 v7, 0xffff, v4                               // 0000009176DC: 360E08FF 0000FFFF
	v_bfe_u32 v74, v4, 4, 16                                   // 0000009176E4: D610004A 02410904
	.long 0xd72c0044                                           // 0000009176EC: D72C0044
	v_cndmask_b32_e32 v1, 0x83dcd12d, v68, vcc_lo              // 0000009176F0: 020288FF 83DCD12D
	.long 0xd72c0045                                           // 0000009176F8: D72C0045
	v_cndmask_b32_e32 v1, 0x83dcd12d, v69, vcc_lo              // 0000009176FC: 02028AFF 83DCD12D
	v_bfe_u32 v6, v4, 12, 16                                   // 000000917704: D6100006 02411904
	.long 0xd72c004c                                           // 00000091770C: D72C004C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v7, vcc_lo               // 000000917710: 02020EFF 83DCD12D
	.long 0xd72c004a                                           // 000000917718: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 00000091771C: 020294FF 83DCD12D
	v_alignbit_b32 v72, v2, v3, 16                             // 000000917724: D6160048 02420702
	.long 0xd72c0046                                           // 00000091772C: D72C0046
	v_cndmask_b32_e32 v1, 0x83dcd12d, v70, vcc_lo              // 000000917730: 02028CFF 83DCD12D
	.long 0xd72c0049                                           // 000000917738: D72C0049
	v_cndmask_b32_e32 v1, 0x83dcd12d, v6, vcc_lo               // 00000091773C: 02020CFF 83DCD12D
	v_sad_u8 v68, v68, 0, 0x6400                               // 000000917744: D6220044 03FD0144 00006400
	v_sad_u8 v69, v69, 0, 0x6400                               // 000000917750: D6220045 03FD0145 00006400
	s_waitcnt vmcnt(6)                                         // 00000091775C: BF891BF7
	v_bfe_u32 v77, v67, 4, 16                                  // 000000917760: D610004D 02410943
	v_sad_u8 v76, v76, 0, 0x6400                               // 000000917768: D622004C 03FD014C 00006400
	v_sad_u8 v74, v74, 0, 0x6400                               // 000000917774: D622004A 03FD014A 00006400
	v_and_b32_e32 v68, 0xffff, v68                             // 000000917780: 368888FF 0000FFFF
	v_sad_u8 v70, v70, 0, 0x6400                               // 000000917788: D6220046 03FD0146 00006400
	v_sad_u8 v73, v73, 0, 0x6400                               // 000000917794: D6220049 03FD0149 00006400
	v_lshlrev_b32_e32 v76, 16, v76                             // 0000009177A0: 30989890
	v_alignbit_b32 v65, v65, v66, 16                           // 0000009177A4: D6160041 02428541
	v_lshl_or_b32 v68, v69, 16, v68                            // 0000009177AC: D6560044 05112145
	v_alignbit_b32 v62, v62, v63, 16                           // 0000009177B4: D616003E 02427F3E
	v_alignbit_b32 v59, v59, v60, 16                           // 0000009177BC: D616003B 0242793B
	v_and_or_b32 v74, 0xffff, v74, v76                         // 0000009177C4: D657004A 053294FF 0000FFFF
	v_bfe_u32 v76, v67, 8, 16                                  // 0000009177D0: D610004C 02411143
	v_pk_fma_f16 v68, v68, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009177D8: CC0E0044 0BFC0B44 0000C931
	v_alignbit_b32 v56, v56, v57, 16                           // 0000009177E4: D6160038 02427338
	v_alignbit_b32 v53, v53, v55, 16                           // 0000009177EC: D6160035 02426F35
	v_pk_fma_f16 v69, v74, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009177F4: CC0E0045 0BFC0B4A 0000C931
	v_and_b32_e32 v71, 0xffff, v5                              // 000000917800: 368E0AFF 0000FFFF
	v_bfe_u32 v5, v4, 8, 16                                    // 000000917808: D6100005 02411104
	v_bfe_u32 v74, v72, 12, 16                                 // 000000917810: D610004A 02411948
	.long 0xd72c004c                                           // 000000917818: D72C004C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v76, vcc_lo              // 00000091781C: 020298FF 83DCD12D
	v_bfe_u32 v55, v53, 12, 16                                 // 000000917824: D6100037 02411935
	v_alignbit_b32 v35, v35, v36, 16                           // 00000091782C: D6160023 02424923
	.long 0xd72c004b                                           // 000000917834: D72C004B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v5, vcc_lo               // 000000917838: 02020AFF 83DCD12D
	ds_load_b128 v[5:8], v1                                    // 000000917840: DBFC0000 05000001
	ds_load_b128 v[1:4], v1 offset:5120                        // 000000917848: DBFC1400 01000001
	v_and_b32_e32 v73, 0xffff, v73                             // 000000917850: 369292FF 0000FFFF
	.long 0xd72c004a                                           // 000000917858: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 00000091785C: 020294FF 83DCD12D
	.long 0xd72c0037                                           // 000000917864: D72C0037
	v_cndmask_b32_e32 v1, 0x83dcd12d, v55, vcc_lo              // 000000917868: 02026EFF 83DCD12D
	v_sad_u8 v76, v76, 0, 0x6400                               // 000000917870: D622004C 03FD014C 00006400
	v_cmp_eq_u32_e32 vcc_lo, v9, v14                           // 00000091787C: 7C941D09
	v_sad_u8 v75, v75, 0, 0x6400                               // 000000917880: D622004B 03FD014B 00006400
	v_sad_u8 v74, v74, 0, 0x6400                               // 00000091788C: D622004A 03FD014A 00006400
	v_sad_u8 v55, v55, 0, 0x6400                               // 000000917898: D6220037 03FD0137 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000009178A4: BF8701B3
	v_lshl_or_b32 v73, v75, 16, v73                            // 0000009178A8: D6560049 0525214B
	v_bfe_u32 v75, v72, 8, 16                                  // 0000009178B0: D610004B 02411148
	s_or_b32 s4, vcc_lo, s4                                    // 0000009178B8: 8C04046A
	v_and_b32_e32 v55, 0xffff, v55                             // 0000009178BC: 366E6EFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009178C4: BF870193
	v_pk_fma_f16 v73, v73, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009178C8: CC0E0049 0BFC0B49 0000C931
	.long 0xd72c004b                                           // 0000009178D4: D72C004B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v75, vcc_lo              // 0000009178D8: 020296FF 83DCD12D
	s_waitcnt lgkmcnt(1)                                       // 0000009178E0: BF89FC17
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000009178E4: BF870242
	v_dot2acc_f32_f16 v30, v73, v5                             // 0000009178E8: 043C0B49
	s_waitcnt lgkmcnt(0)                                       // 0000009178EC: BF89FC07
	v_dot2acc_f32_f16 v27, v73, v1                             // 0000009178F0: 04360349
	v_bfe_u32 v73, v67, 12, 16                                 // 0000009178F4: D6100049 02411943
	v_sad_u8 v75, v75, 0, 0x6400                               // 0000009178FC: D622004B 03FD014B 00006400
	v_dot2acc_f32_f16 v30, v69, v6                             // 000000917908: 043C0D45
	.long 0xd72c0047                                           // 00000091790C: D72C0047
	v_cndmask_b32_e32 v1, 0x83dcd12d, v71, vcc_lo              // 000000917910: 02028EFF 83DCD12D
	v_dot2acc_f32_f16 v27, v69, v2                             // 000000917918: 04360545
	v_and_b32_e32 v74, 0xffff, v74                             // 00000091791C: 369494FF 0000FFFF
	.long 0xd72c0049                                           // 000000917924: D72C0049
	v_cndmask_b32_e32 v1, 0x83dcd12d, v73, vcc_lo              // 000000917928: 020292FF 83DCD12D
	v_dot2acc_f32_f16 v30, v68, v7                             // 000000917930: 043C0F44
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000917934: BF870214
	v_dot2acc_f32_f16 v27, v68, v3                             // 000000917938: 04360744
	v_lshl_or_b32 v74, v75, 16, v74                            // 00000091793C: D656004A 0529214B
	v_sad_u8 v71, v71, 0, 0x6400                               // 000000917944: D6220047 03FD0147 00006400
	.long 0xd72c004b                                           // 000000917950: D72C004B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v77, vcc_lo              // 000000917954: 02029AFF 83DCD12D
	v_bfe_u32 v68, v65, 4, 16                                  // 00000091795C: D6100044 02410941
	v_sad_u8 v73, v73, 0, 0x6400                               // 000000917964: D6220049 03FD0149 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000917970: BF870194
	v_lshlrev_b32_e32 v71, 16, v71                             // 000000917974: 308E8E90
	.long 0xd72c0044                                           // 000000917978: D72C0044
	v_cndmask_b32_e32 v1, 0x83dcd12d, v68, vcc_lo              // 00000091797C: 020288FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000917984: BF8701B2
	v_and_or_b32 v70, 0xffff, v70, v71                         // 000000917988: D6570046 051E8CFF 0000FFFF
	v_and_b32_e32 v71, 0xffff, v72                             // 000000917994: 368E90FF 0000FFFF
	v_bfe_u32 v72, v72, 4, 16                                  // 00000091799C: D6100048 02410948
	v_pk_fma_f16 v70, v70, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009179A4: CC0E0046 0BFC0B46 0000C931
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009179B0: BF870193
	.long 0xd72c0047                                           // 0000009179B4: D72C0047
	v_cndmask_b32_e32 v1, 0x83dcd12d, v71, vcc_lo              // 0000009179B8: 02028EFF 83DCD12D
	.long 0xd72c0048                                           // 0000009179C0: D72C0048
	v_cndmask_b32_e32 v1, 0x83dcd12d, v72, vcc_lo              // 0000009179C4: 020290FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3)                            // 0000009179CC: BF870003
	v_dot2acc_f32_f16 v30, v70, v8                             // 0000009179D0: 043C1146
	v_dot2acc_f32_f16 v27, v70, v4                             // 0000009179D4: 04360946
	s_waitcnt vmcnt(5)                                         // 0000009179D8: BF8917F7
	v_bfe_u32 v70, v64, 8, 16                                  // 0000009179DC: D6100046 02411140
	v_sad_u8 v71, v71, 0, 0x6400                               // 0000009179E4: D6220047 03FD0147 00006400
	v_sad_u8 v72, v72, 0, 0x6400                               // 0000009179F0: D6220048 03FD0148 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009179FC: BF870193
	.long 0xd72c0046                                           // 000000917A00: D72C0046
	v_cndmask_b32_e32 v1, 0x83dcd12d, v70, vcc_lo              // 000000917A04: 02028CFF 83DCD12D
	v_lshlrev_b32_e32 v71, 16, v71                             // 000000917A0C: 308E8E90
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000917A10: BF870241
	v_and_or_b32 v69, 0xffff, v72, v71                         // 000000917A14: D6570045 051E90FF 0000FFFF
	v_pk_fma_f16 v71, v74, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000917A20: CC0E0047 0BFC0B4A 0000C931
	v_and_b32_e32 v67, 0xffff, v67                             // 000000917A2C: 368686FF 0000FFFF
	v_sad_u8 v70, v70, 0, 0x6400                               // 000000917A34: D6220046 03FD0146 00006400
	v_pk_fma_f16 v69, v69, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000917A40: CC0E0045 0BFC0B45 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000917A4C: BF870214
	v_dot2acc_f32_f16 v28, v71, v5                             // 000000917A50: 04380B47
	.long 0xd72c0043                                           // 000000917A54: D72C0043
	v_cndmask_b32_e32 v1, 0x83dcd12d, v67, vcc_lo              // 000000917A58: 020286FF 83DCD12D
	v_dot2acc_f32_f16 v26, v71, v1                             // 000000917A60: 04340347
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000917A64: BF870113
	v_dual_dot2acc_f32_f16 v28, v69, v6 :: v_dual_and_b32 v73, 0xffff, v73// 000000917A68: CB240D45 1C4892FF 0000FFFF
	v_dot2acc_f32_f16 v26, v69, v2                             // 000000917A74: 04340545
	v_bfe_u32 v69, v64, 12, 16                                 // 000000917A78: D6100045 02411940
	v_sad_u8 v67, v67, 0, 0x6400                               // 000000917A80: D6220043 03FD0143 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000917A8C: BF870224
	v_lshl_or_b32 v72, v76, 16, v73                            // 000000917A90: D6560048 0525214C
	v_sad_u8 v73, v75, 0, 0x6400                               // 000000917A98: D6220049 03FD014B 00006400
	.long 0xd72c0045                                           // 000000917AA4: D72C0045
	v_cndmask_b32_e32 v1, 0x83dcd12d, v69, vcc_lo              // 000000917AA8: 02028AFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000917AB0: BF870214
	v_lshlrev_b32_e32 v67, 16, v67                             // 000000917AB4: 30868690
	v_pk_fma_f16 v71, v72, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000917AB8: CC0E0047 0BFC0B48 0000C931
	s_waitcnt vmcnt(4)                                         // 000000917AC4: BF8913F7
	v_bfe_u32 v72, v61, 4, 16                                  // 000000917AC8: D6100048 0241093D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000917AD0: BF870193
	v_and_or_b32 v67, 0xffff, v73, v67                         // 000000917AD4: D6570043 050E92FF 0000FFFF
	v_dot2acc_f32_f16 v28, v71, v7                             // 000000917AE0: 04380F47
	v_dual_dot2acc_f32_f16 v26, v71, v3 :: v_dual_and_b32 v71, 0xffff, v64// 000000917AE4: CB240747 1A4680FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3)                            // 000000917AF0: BF870003
	v_pk_fma_f16 v66, v67, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000917AF4: CC0E0042 0BFC0B43 0000C931
	v_bfe_u32 v67, v65, 12, 16                                 // 000000917B00: D6100043 02411941
	v_bfe_u32 v64, v64, 4, 16                                  // 000000917B08: D6100040 02410940
	v_sad_u8 v69, v69, 0, 0x6400                               // 000000917B10: D6220045 03FD0145 00006400
	.long 0xd72c0047                                           // 000000917B1C: D72C0047
	v_cndmask_b32_e32 v1, 0x83dcd12d, v71, vcc_lo              // 000000917B20: 02028EFF 83DCD12D
	v_dot2acc_f32_f16 v28, v66, v8                             // 000000917B28: 04381142
	.long 0xd72c0043                                           // 000000917B2C: D72C0043
	v_cndmask_b32_e32 v1, 0x83dcd12d, v67, vcc_lo              // 000000917B30: 020286FF 83DCD12D
	.long 0xd72c0040                                           // 000000917B38: D72C0040
	v_cndmask_b32_e32 v1, 0x83dcd12d, v64, vcc_lo              // 000000917B3C: 020280FF 83DCD12D
	v_and_b32_e32 v69, 0xffff, v69                             // 000000917B44: 368A8AFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000917B4C: BF870211
	v_lshl_or_b32 v63, v70, 16, v69                            // 000000917B50: D656003F 05152146
	v_sad_u8 v67, v67, 0, 0x6400                               // 000000917B58: D6220043 03FD0143 00006400
	v_dot2acc_f32_f16 v26, v66, v4                             // 000000917B64: 04340942
	v_bfe_u32 v66, v65, 8, 16                                  // 000000917B68: D6100042 02411141
	v_and_b32_e32 v65, 0xffff, v65                             // 000000917B70: 368282FF 0000FFFF
	v_sad_u8 v64, v64, 0, 0x6400                               // 000000917B78: D6220040 03FD0140 00006400
	v_and_b32_e32 v67, 0xffff, v67                             // 000000917B84: 368686FF 0000FFFF
	v_pk_fma_f16 v63, v63, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000917B8C: CC0E003F 0BFC0B3F 0000C931
	.long 0xd72c0042                                           // 000000917B98: D72C0042
	v_cndmask_b32_e32 v1, 0x83dcd12d, v66, vcc_lo              // 000000917B9C: 020284FF 83DCD12D
	.long 0xd72c0041                                           // 000000917BA4: D72C0041
	v_cndmask_b32_e32 v1, 0x83dcd12d, v65, vcc_lo              // 000000917BA8: 020282FF 83DCD12D
	v_bfe_u32 v69, v62, 8, 16                                  // 000000917BB0: D6100045 0241113E
	v_bfe_u32 v70, v61, 12, 16                                 // 000000917BB8: D6100046 0241193D
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000917BC0: BF870232
	.long 0xd72c0045                                           // 000000917BC4: D72C0045
	v_cndmask_b32_e32 v1, 0x83dcd12d, v69, vcc_lo              // 000000917BC8: 02028AFF 83DCD12D
	v_sad_u8 v66, v66, 0, 0x6400                               // 000000917BD0: D6220042 03FD0142 00006400
	v_sad_u8 v65, v65, 0, 0x6400                               // 000000917BDC: D6220041 03FD0141 00006400
	.long 0xd72c0046                                           // 000000917BE8: D72C0046
	v_cndmask_b32_e32 v1, 0x83dcd12d, v70, vcc_lo              // 000000917BEC: 02028CFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000917BF4: BF870223
	v_lshl_or_b32 v66, v66, 16, v67                            // 000000917BF8: D6560042 050D2142
	v_sad_u8 v67, v68, 0, 0x6400                               // 000000917C00: D6220043 03FD0144 00006400
	v_lshlrev_b32_e32 v65, 16, v65                             // 000000917C0C: 30828290
	v_sad_u8 v68, v71, 0, 0x6400                               // 000000917C10: D6220044 03FD0147 00006400
	v_sad_u8 v69, v69, 0, 0x6400                               // 000000917C1C: D6220045 03FD0145 00006400
	v_pk_fma_f16 v66, v66, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000917C28: CC0E0042 0BFC0B42 0000C931
	v_bfe_u32 v71, v61, 8, 16                                  // 000000917C34: D6100047 0241113D
	v_and_or_b32 v65, 0xffff, v67, v65                         // 000000917C3C: D6570041 050686FF 0000FFFF
	v_lshlrev_b32_e32 v68, 16, v68                             // 000000917C48: 30888890
	v_bfe_u32 v67, v62, 12, 16                                 // 000000917C4C: D6100043 0241193E
	v_dot2acc_f32_f16 v19, v66, v5                             // 000000917C54: 04260B42
	.long 0xd72c0047                                           // 000000917C58: D72C0047
	v_cndmask_b32_e32 v1, 0x83dcd12d, v71, vcc_lo              // 000000917C5C: 02028EFF 83DCD12D
	v_pk_fma_f16 v65, v65, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000917C64: CC0E0041 0BFC0B41 0000C931
	v_and_or_b32 v64, 0xffff, v64, v68                         // 000000917C70: D6570040 051280FF 0000FFFF
	.long 0xd72c0043                                           // 000000917C7C: D72C0043
	v_cndmask_b32_e32 v1, 0x83dcd12d, v67, vcc_lo              // 000000917C80: 020286FF 83DCD12D
	v_sad_u8 v70, v70, 0, 0x6400                               // 000000917C88: D6220046 03FD0146 00006400
	v_dot2acc_f32_f16 v17, v66, v1                             // 000000917C94: 04220342
	v_dot2acc_f32_f16 v19, v65, v6                             // 000000917C98: 04260D41
	v_and_b32_e32 v68, 0xffff, v62                             // 000000917C9C: 36887CFF 0000FFFF
	v_bfe_u32 v62, v62, 4, 16                                  // 000000917CA4: D610003E 0241093E
	v_pk_fma_f16 v64, v64, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000917CAC: CC0E0040 0BFC0B40 0000C931
	v_and_b32_e32 v61, 0xffff, v61                             // 000000917CB8: 367A7AFF 0000FFFF
	v_dot2acc_f32_f16 v19, v63, v7                             // 000000917CC0: 04260F3F
	.long 0xd72c0044                                           // 000000917CC4: D72C0044
	v_cndmask_b32_e32 v1, 0x83dcd12d, v68, vcc_lo              // 000000917CC8: 020288FF 83DCD12D
	v_sad_u8 v67, v67, 0, 0x6400                               // 000000917CD0: D6220043 03FD0143 00006400
	.long 0xd72c003e                                           // 000000917CDC: D72C003E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v62, vcc_lo              // 000000917CE0: 02027CFF 83DCD12D
	.long 0xd72c003d                                           // 000000917CE8: D72C003D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v61, vcc_lo              // 000000917CEC: 02027AFF 83DCD12D
	v_dot2acc_f32_f16 v19, v64, v8                             // 000000917CF4: 04261140
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000917CF8: BF8701B4
	v_and_b32_e32 v67, 0xffff, v67                             // 000000917CFC: 368686FF 0000FFFF
	v_sad_u8 v68, v68, 0, 0x6400                               // 000000917D04: D6220044 03FD0144 00006400
	v_sad_u8 v62, v62, 0, 0x6400                               // 000000917D10: D622003E 03FD013E 00006400
	v_lshl_or_b32 v67, v69, 16, v67                            // 000000917D1C: D6560043 050D2145
	v_and_b32_e32 v69, 0xffff, v70                             // 000000917D24: 368A8CFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000917D2C: BF870244
	v_lshlrev_b32_e32 v68, 16, v68                             // 000000917D30: 30888890
	v_sad_u8 v70, v71, 0, 0x6400                               // 000000917D34: D6220046 03FD0147 00006400
	v_sad_u8 v61, v61, 0, 0x6400                               // 000000917D40: D622003D 03FD013D 00006400
	v_pk_fma_f16 v66, v67, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000917D4C: CC0E0042 0BFC0B43 0000C931
	v_and_or_b32 v62, 0xffff, v62, v68                         // 000000917D58: D657003E 05127CFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000917D64: BF870224
	v_lshl_or_b32 v67, v70, 16, v69                            // 000000917D68: D6560043 05152146
	.long 0xd72c0044                                           // 000000917D70: D72C0044
	v_cndmask_b32_e32 v1, 0x83dcd12d, v72, vcc_lo              // 000000917D74: 020290FF 83DCD12D
	v_dot2acc_f32_f16 v21, v66, v5                             // 000000917D7C: 042A0B42
	v_dot2acc_f32_f16 v29, v66, v1                             // 000000917D80: 043A0342
	v_pk_fma_f16 v62, v62, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000917D84: CC0E003E 0BFC0B3E 0000C931
	s_waitcnt vmcnt(2)                                         // 000000917D90: BF890BF7
	v_bfe_u32 v66, v54, 4, 16                                  // 000000917D94: D6100042 02410936
	s_delay_alu instid0(VALU_DEP_2)                            // 000000917D9C: BF870002
	v_dot2acc_f32_f16 v21, v62, v6                             // 000000917DA0: 042A0D3E
	v_dual_dot2acc_f32_f16 v29, v62, v2 :: v_dual_and_b32 v62, 0xffff, v59// 000000917DA4: CB24053E 1D3E76FF 0000FFFF
	v_dot2acc_f32_f16 v17, v65, v2                             // 000000917DB0: 04220541
	v_pk_fma_f16 v65, v67, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000917DB4: CC0E0041 0BFC0B43 0000C931
	v_sad_u8 v68, v68, 0, 0x6400                               // 000000917DC0: D6220044 03FD0144 00006400
	v_mov_b32_e32 v67, v50                                     // 000000917DCC: 7E860332
	.long 0xd72c003e                                           // 000000917DD0: D72C003E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v62, vcc_lo              // 000000917DD4: 02027CFF 83DCD12D
	v_dot2acc_f32_f16 v17, v63, v3                             // 000000917DDC: 0422073F
	v_dot2acc_f32_f16 v21, v65, v7                             // 000000917DE0: 042A0F41
	v_dot2acc_f32_f16 v29, v65, v3                             // 000000917DE4: 043A0741
	v_bfe_u32 v63, v58, 12, 16                                 // 000000917DE8: D610003F 0241193A
	v_bfe_u32 v65, v58, 4, 16                                  // 000000917DF0: D6100041 0241093A
	v_dot2acc_f32_f16 v17, v64, v4                             // 000000917DF8: 04220940
	v_bfe_u32 v64, v58, 8, 16                                  // 000000917DFC: D6100040 0241113A
	v_and_b32_e32 v58, 0xffff, v58                             // 000000917E04: 367474FF 0000FFFF
	.long 0xd72c003f                                           // 000000917E0C: D72C003F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v63, vcc_lo              // 000000917E10: 02027EFF 83DCD12D
	.long 0xd72c0041                                           // 000000917E18: D72C0041
	v_cndmask_b32_e32 v1, 0x83dcd12d, v65, vcc_lo              // 000000917E1C: 020282FF 83DCD12D
	v_sad_u8 v62, v62, 0, 0x6400                               // 000000917E24: D622003E 03FD013E 00006400
	.long 0xd72c0040                                           // 000000917E30: D72C0040
	v_cndmask_b32_e32 v1, 0x83dcd12d, v64, vcc_lo              // 000000917E34: 020280FF 83DCD12D
	.long 0xd72c003a                                           // 000000917E3C: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 000000917E40: 020274FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 000000917E48: BF870253
	v_lshlrev_b32_e32 v62, 16, v62                             // 000000917E4C: 307C7C90
	v_sad_u8 v63, v63, 0, 0x6400                               // 000000917E50: D622003F 03FD013F 00006400
	v_sad_u8 v65, v65, 0, 0x6400                               // 000000917E5C: D6220041 03FD0141 00006400
	v_sad_u8 v64, v64, 0, 0x6400                               // 000000917E68: D6220040 03FD0140 00006400
	v_sad_u8 v58, v58, 0, 0x6400                               // 000000917E74: D622003A 03FD013A 00006400
	v_and_b32_e32 v63, 0xffff, v63                             // 000000917E80: 367E7EFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000917E88: BF870112
	v_lshlrev_b32_e32 v58, 16, v58                             // 000000917E8C: 30747490
	v_lshl_or_b32 v57, v64, 16, v63                            // 000000917E90: D6560039 04FD2140
	v_bfe_u32 v64, v54, 12, 16                                 // 000000917E98: D6100040 02411936
	v_bfe_u32 v63, v56, 8, 16                                  // 000000917EA0: D610003F 02411138
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000917EA8: BF870234
	v_and_or_b32 v58, 0xffff, v65, v58                         // 000000917EAC: D657003A 04EA82FF 0000FFFF
	v_bfe_u32 v65, v54, 8, 16                                  // 000000917EB8: D6100041 02411136
	v_and_b32_e32 v54, 0xffff, v54                             // 000000917EC0: 366C6CFF 0000FFFF
	.long 0xd72c003f                                           // 000000917EC8: D72C003F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v63, vcc_lo              // 000000917ECC: 02027EFF 83DCD12D
	.long 0xd72c0040                                           // 000000917ED4: D72C0040
	v_cndmask_b32_e32 v1, 0x83dcd12d, v64, vcc_lo              // 000000917ED8: 020280FF 83DCD12D
	v_pk_fma_f16 v58, v58, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000917EE0: CC0E003A 0BFC0B3A 0000C931
	v_lshlrev_b32_e32 v61, 16, v61                             // 000000917EEC: 307A7A90
	.long 0xd72c0041                                           // 000000917EF0: D72C0041
	v_cndmask_b32_e32 v1, 0x83dcd12d, v65, vcc_lo              // 000000917EF4: 020282FF 83DCD12D
	v_pk_fma_f16 v57, v57, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000917EFC: CC0E0039 0BFC0B39 0000C931
	.long 0xd72c0036                                           // 000000917F08: D72C0036
	v_cndmask_b32_e32 v1, 0x83dcd12d, v54, vcc_lo              // 000000917F0C: 02026CFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000917F14: BF8701B4
	v_and_or_b32 v61, 0xffff, v68, v61                         // 000000917F18: D657003D 04F688FF 0000FFFF
	v_sad_u8 v63, v63, 0, 0x6400                               // 000000917F24: D622003F 03FD013F 00006400
	v_sad_u8 v64, v64, 0, 0x6400                               // 000000917F30: D6220040 03FD0140 00006400
	v_pk_fma_f16 v60, v61, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000917F3C: CC0E003C 0BFC0B3D 0000C931
	v_bfe_u32 v61, v59, 12, 16                                 // 000000917F48: D610003D 0241193B
	v_sad_u8 v54, v54, 0, 0x6400                               // 000000917F50: D6220036 03FD0136 00006400
	s_delay_alu instid0(VALU_DEP_3)                            // 000000917F5C: BF870003
	v_dot2acc_f32_f16 v21, v60, v8                             // 000000917F60: 042A113C
	v_dot2acc_f32_f16 v29, v60, v4                             // 000000917F64: 043A093C
	v_bfe_u32 v60, v59, 8, 16                                  // 000000917F68: D610003C 0241113B
	.long 0xd72c003d                                           // 000000917F70: D72C003D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v61, vcc_lo              // 000000917F74: 02027AFF 83DCD12D
	v_bfe_u32 v59, v59, 4, 16                                  // 000000917F7C: D610003B 0241093B
	v_lshlrev_b32_e32 v54, 16, v54                             // 000000917F84: 306C6C90
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000917F88: BF870194
	.long 0xd72c003c                                           // 000000917F8C: D72C003C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v60, vcc_lo              // 000000917F90: 020278FF 83DCD12D
	.long 0xd72c003b                                           // 000000917F98: D72C003B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 000000917F9C: 020276FF 83DCD12D
	v_sad_u8 v61, v61, 0, 0x6400                               // 000000917FA4: D622003D 03FD013D 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000917FB0: BF870113
	v_sad_u8 v60, v60, 0, 0x6400                               // 000000917FB4: D622003C 03FD013C 00006400
	v_and_b32_e32 v61, 0xffff, v61                             // 000000917FC0: 367A7AFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000917FC8: BF870114
	v_sad_u8 v59, v59, 0, 0x6400                               // 000000917FCC: D622003B 03FD013B 00006400
	v_lshl_or_b32 v60, v60, 16, v61                            // 000000917FD8: D656003C 04F5213C
	v_bfe_u32 v61, v56, 12, 16                                 // 000000917FE0: D610003D 02411938
	s_delay_alu instid0(VALU_DEP_3)                            // 000000917FE8: BF870003
	v_and_or_b32 v59, 0xffff, v59, v62                         // 000000917FEC: D657003B 04FA76FF 0000FFFF
	v_and_b32_e32 v62, 0xffff, v56                             // 000000917FF8: 367C70FF 0000FFFF
	v_bfe_u32 v56, v56, 4, 16                                  // 000000918000: D6100038 02410938
	v_pk_fma_f16 v60, v60, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000918008: CC0E003C 0BFC0B3C 0000C931
	.long 0xd72c003d                                           // 000000918014: D72C003D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v61, vcc_lo              // 000000918018: 02027AFF 83DCD12D
	v_pk_fma_f16 v59, v59, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000918020: CC0E003B 0BFC0B3B 0000C931
	.long 0xd72c003e                                           // 00000091802C: D72C003E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v62, vcc_lo              // 000000918030: 02027CFF 83DCD12D
	.long 0xd72c0038                                           // 000000918038: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v56, vcc_lo              // 00000091803C: 020270FF 83DCD12D
	v_dot2acc_f32_f16 v16, v60, v5                             // 000000918044: 04200B3C
	v_dot2acc_f32_f16 v25, v60, v1                             // 000000918048: 0432033C
	v_sad_u8 v61, v61, 0, 0x6400                               // 00000091804C: D622003D 03FD013D 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000918058: BF8701B3
	v_dot2acc_f32_f16 v16, v59, v6                             // 00000091805C: 04200D3B
	v_sad_u8 v62, v62, 0, 0x6400                               // 000000918060: D622003E 03FD013E 00006400
	v_sad_u8 v56, v56, 0, 0x6400                               // 00000091806C: D6220038 03FD0138 00006400
	v_dual_dot2acc_f32_f16 v16, v57, v7 :: v_dual_and_b32 v61, 0xffff, v61// 000000918078: CB240F39 103C7AFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000918084: BF870113
	v_lshlrev_b32_e32 v62, 16, v62                             // 000000918088: 307C7C90
	v_lshl_or_b32 v61, v63, 16, v61                            // 00000091808C: D656003D 04F5213F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000918094: BF870193
	v_dot2acc_f32_f16 v16, v58, v8                             // 000000918098: 0420113A
	v_and_or_b32 v56, 0xffff, v56, v62                         // 00000091809C: D6570038 04FA70FF 0000FFFF
	.long 0xd72c003e                                           // 0000009180A8: D72C003E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v66, vcc_lo              // 0000009180AC: 020284FF 83DCD12D
	v_mov_b32_e32 v66, v49                                     // 0000009180B4: 7E840331
	v_pk_fma_f16 v60, v61, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009180B8: CC0E003C 0BFC0B3D 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000009180C4: BF870114
	v_pk_fma_f16 v56, v56, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009180C8: CC0E0038 0BFC0B38 0000C931
	v_dot2acc_f32_f16 v24, v60, v5                             // 0000009180D4: 04300B3C
	v_dot2acc_f32_f16 v23, v60, v1                             // 0000009180D8: 042E033C
	s_waitcnt vmcnt(1)                                         // 0000009180DC: BF8907F7
	v_bfe_u32 v60, v52, 4, 16                                  // 0000009180E0: D610003C 02410934
	v_sad_u8 v62, v62, 0, 0x6400                               // 0000009180E8: D622003E 03FD013E 00006400
	v_dot2acc_f32_f16 v24, v56, v6                             // 0000009180F4: 04300D38
	v_dot2acc_f32_f16 v23, v56, v2                             // 0000009180F8: 042E0538
	v_bfe_u32 v56, v53, 8, 16                                  // 0000009180FC: D6100038 02411135
	.long 0xd72c003c                                           // 000000918104: D72C003C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v60, vcc_lo              // 000000918108: 020278FF 83DCD12D
	v_and_or_b32 v54, 0xffff, v62, v54                         // 000000918110: D6570036 04DA7CFF 0000FFFF
	v_mov_b32_e32 v62, v40                                     // 00000091811C: 7E7C0328
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000918120: BF870194
	.long 0xd72c0038                                           // 000000918124: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v56, vcc_lo              // 000000918128: 020270FF 83DCD12D
	v_pk_fma_f16 v54, v54, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000918130: CC0E0036 0BFC0B36 0000C931
	v_sad_u8 v60, v60, 0, 0x6400                               // 00000091813C: D622003C 03FD013C 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000918148: BF870093
	v_sad_u8 v56, v56, 0, 0x6400                               // 00000091814C: D6220038 03FD0138 00006400
	v_lshl_or_b32 v55, v56, 16, v55                            // 000000918158: D6560037 04DD2138
	v_bfe_u32 v56, v35, 12, 16                                 // 000000918160: D6100038 02411923
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000918168: BF870112
	v_pk_fma_f16 v55, v55, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000091816C: CC0E0037 0BFC0B37 0000C931
	.long 0xd72c0038                                           // 000000918178: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v56, vcc_lo              // 00000091817C: 020270FF 83DCD12D
	v_and_b32_e32 v63, 0xffff, v64                             // 000000918184: 367E80FF 0000FFFF
	v_sad_u8 v64, v65, 0, 0x6400                               // 00000091818C: D6220040 03FD0141 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000918198: BF8701A4
	v_dual_mov_b32 v65, v41 :: v_dual_dot2acc_f32_f16 v20, v55, v1// 00000091819C: CA180129 41140337
	v_dot2acc_f32_f16 v22, v55, v5                             // 0000009181A4: 042C0B37
	v_lshl_or_b32 v61, v64, 16, v63                            // 0000009181A8: D656003D 04FD2140
	v_sad_u8 v56, v56, 0, 0x6400                               // 0000009181B0: D6220038 03FD0138 00006400
	v_dual_mov_b32 v63, v48 :: v_dual_mov_b32 v64, v49         // 0000009181BC: CA100130 3F400131
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009181C4: BF870212
	v_dual_dot2acc_f32_f16 v25, v59, v2 :: v_dual_and_b32 v56, 0xffff, v56// 0000009181C8: CB24053B 193870FF 0000FFFF
	v_pk_fma_f16 v59, v61, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009181D4: CC0E003B 0BFC0B3D 0000C931
	s_waitcnt vmcnt(0)                                         // 0000009181E0: BF8903F7
	v_bfe_u32 v61, v34, 4, 16                                  // 0000009181E4: D610003D 02410922
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009181EC: BF870193
	v_dot2acc_f32_f16 v25, v57, v3                             // 0000009181F0: 04320739
	v_dot2acc_f32_f16 v24, v59, v7                             // 0000009181F4: 04300F3B
	v_dot2acc_f32_f16 v23, v59, v3                             // 0000009181F8: 042E073B
	v_bfe_u32 v59, v52, 8, 16                                  // 0000009181FC: D610003B 02411134
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000918204: BF870234
	v_dot2acc_f32_f16 v25, v58, v4                             // 000000918208: 0432093A
	v_bfe_u32 v58, v52, 12, 16                                 // 00000091820C: D610003A 02411934
	v_and_b32_e32 v52, 0xffff, v52                             // 000000918214: 366868FF 0000FFFF
	.long 0xd72c003b                                           // 00000091821C: D72C003B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 000000918220: 020276FF 83DCD12D
	v_dot2acc_f32_f16 v24, v54, v8                             // 000000918228: 04301136
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000091822C: BF870214
	.long 0xd72c003a                                           // 000000918230: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 000000918234: 020274FF 83DCD12D
	.long 0xd72c0034                                           // 00000091823C: D72C0034
	v_cndmask_b32_e32 v1, 0x83dcd12d, v52, vcc_lo              // 000000918240: 020268FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000918248: BF870194
	v_sad_u8 v59, v59, 0, 0x6400                               // 00000091824C: D622003B 03FD013B 00006400
	v_sad_u8 v58, v58, 0, 0x6400                               // 000000918258: D622003A 03FD013A 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000918264: BF870113
	v_sad_u8 v52, v52, 0, 0x6400                               // 000000918268: D6220034 03FD0134 00006400
	v_and_b32_e32 v58, 0xffff, v58                             // 000000918274: 367474FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000091827C: BF870112
	v_lshlrev_b32_e32 v52, 16, v52                             // 000000918280: 30686890
	v_lshl_or_b32 v36, v59, 16, v58                            // 000000918284: D6560024 04E9213B
	v_bfe_u32 v58, v35, 8, 16                                  // 00000091828C: D610003A 02411123
	v_bfe_u32 v59, v34, 12, 16                                 // 000000918294: D610003B 02411922
	s_delay_alu instid0(VALU_DEP_4)                            // 00000091829C: BF870004
	v_and_or_b32 v52, 0xffff, v60, v52                         // 0000009182A0: D6570034 04D278FF 0000FFFF
	v_bfe_u32 v60, v34, 8, 16                                  // 0000009182AC: D610003C 02411122
	v_pk_fma_f16 v36, v36, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009182B4: CC0E0024 0BFC0B24 0000C931
	v_and_b32_e32 v57, 0xffff, v53                             // 0000009182C0: 36726AFF 0000FFFF
	v_bfe_u32 v53, v53, 4, 16                                  // 0000009182C8: D6100035 02410935
	.long 0xd72c003a                                           // 0000009182D0: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 0000009182D4: 020274FF 83DCD12D
	.long 0xd72c003b                                           // 0000009182DC: D72C003B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 0000009182E0: 020276FF 83DCD12D
	v_and_b32_e32 v34, 0xffff, v34                             // 0000009182E8: 364444FF 0000FFFF
	.long 0xd72c0039                                           // 0000009182F0: D72C0039
	v_cndmask_b32_e32 v1, 0x83dcd12d, v57, vcc_lo              // 0000009182F4: 020272FF 83DCD12D
	.long 0xd72c0035                                           // 0000009182FC: D72C0035
	v_cndmask_b32_e32 v1, 0x83dcd12d, v53, vcc_lo              // 000000918300: 02026AFF 83DCD12D
	v_pk_fma_f16 v52, v52, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000918308: CC0E0034 0BFC0B34 0000C931
	.long 0xd72c003c                                           // 000000918314: D72C003C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v60, vcc_lo              // 000000918318: 020278FF 83DCD12D
	.long 0xd72c0022                                           // 000000918320: D72C0022
	v_cndmask_b32_e32 v1, 0x83dcd12d, v34, vcc_lo              // 000000918324: 020244FF 83DCD12D
	v_sad_u8 v58, v58, 0, 0x6400                               // 00000091832C: D622003A 03FD013A 00006400
	v_sad_u8 v59, v59, 0, 0x6400                               // 000000918338: D622003B 03FD013B 00006400
	v_sad_u8 v57, v57, 0, 0x6400                               // 000000918344: D6220039 03FD0139 00006400
	v_sad_u8 v53, v53, 0, 0x6400                               // 000000918350: D6220035 03FD0135 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000091835C: BF870214
	v_lshl_or_b32 v56, v58, 16, v56                            // 000000918360: D6560038 04E1213A
	v_and_b32_e32 v58, 0xffff, v59                             // 000000918368: 367476FF 0000FFFF
	v_sad_u8 v59, v60, 0, 0x6400                               // 000000918370: D622003B 03FD013C 00006400
	v_lshlrev_b32_e32 v57, 16, v57                             // 00000091837C: 30727290
	v_sad_u8 v34, v34, 0, 0x6400                               // 000000918380: D6220022 03FD0122 00006400
	v_pk_fma_f16 v55, v56, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000091838C: CC0E0037 0BFC0B38 0000C931
	v_mov_b32_e32 v60, v47                                     // 000000918398: 7E78032F
	v_lshl_or_b32 v56, v59, 16, v58                            // 00000091839C: D6560038 04E9213B
	v_and_or_b32 v53, 0xffff, v53, v57                         // 0000009183A4: D6570035 04E66AFF 0000FFFF
	v_and_b32_e32 v57, 0xffff, v35                             // 0000009183B0: 367246FF 0000FFFF
	v_bfe_u32 v35, v35, 4, 16                                  // 0000009183B8: D6100023 02410923
	v_lshlrev_b32_e32 v34, 16, v34                             // 0000009183C0: 30444490
	v_dot2acc_f32_f16 v18, v55, v5                             // 0000009183C4: 04240B37
	v_pk_fma_f16 v53, v53, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009183C8: CC0E0035 0BFC0B35 0000C931
	.long 0xd72c0039                                           // 0000009183D4: D72C0039
	v_cndmask_b32_e32 v1, 0x83dcd12d, v57, vcc_lo              // 0000009183D8: 020272FF 83DCD12D
	.long 0xd72c0023                                           // 0000009183E0: D72C0023
	v_cndmask_b32_e32 v1, 0x83dcd12d, v35, vcc_lo              // 0000009183E4: 020246FF 83DCD12D
	v_dot2acc_f32_f16 v15, v55, v1                             // 0000009183EC: 041E0337
	v_pk_fma_f16 v1, v56, s5, 0xc931 op_sel_hi:[1,0,0]         // 0000009183F0: CC0E0001 0BFC0B38 0000C931
	v_dot2acc_f32_f16 v22, v53, v6                             // 0000009183FC: 042C0D35
	v_dot2acc_f32_f16 v20, v53, v2                             // 000000918400: 04280535
	v_mov_b32_e32 v56, v38                                     // 000000918404: 7E700326
	v_mov_b32_e32 v58, v47                                     // 000000918408: 7E74032F
	v_sad_u8 v57, v57, 0, 0x6400                               // 00000091840C: D6220039 03FD0139 00006400
	v_sad_u8 v35, v35, 0, 0x6400                               // 000000918418: D6220023 03FD0123 00006400
	v_dot2acc_f32_f16 v22, v36, v7                             // 000000918424: 042C0F24
	v_dual_dot2acc_f32_f16 v20, v36, v3 :: v_dual_mov_b32 v59, v39// 000000918428: CB100724 143A0127
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000918430: BF870194
	v_lshlrev_b32_e32 v57, 16, v57                             // 000000918434: 30727290
	v_dual_mov_b32 v53, v37 :: v_dual_dot2acc_f32_f16 v22, v52, v8// 000000918438: CA180125 35161134
	v_dot2acc_f32_f16 v23, v54, v4                             // 000000918440: 042E0936
	v_mov_b32_e32 v54, v46                                     // 000000918444: 7E6C032E
	s_delay_alu instid0(VALU_DEP_4)                            // 000000918448: BF870004
	v_and_or_b32 v35, 0xffff, v35, v57                         // 00000091844C: D6570023 04E646FF 0000FFFF
	.long 0xd72c0039                                           // 000000918458: D72C0039
	v_cndmask_b32_e32 v1, 0x83dcd12d, v61, vcc_lo              // 00000091845C: 02027AFF 83DCD12D
	v_dot2acc_f32_f16 v20, v52, v4                             // 000000918464: 04280934
	v_mov_b32_e32 v61, v48                                     // 000000918468: 7E7A0330
	v_mov_b32_e32 v55, v45                                     // 00000091846C: 7E6E032D
	v_pk_fma_f16 v35, v35, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000918470: CC0E0023 0BFC0B23 0000C931
	v_mov_b32_e32 v52, v45                                     // 00000091847C: 7E68032D
	v_mov_b32_e32 v36, v43                                     // 000000918480: 7E48032B
	v_sad_u8 v57, v57, 0, 0x6400                               // 000000918484: D6220039 03FD0139 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000918490: BF870234
	v_dot2acc_f32_f16 v18, v35, v6                             // 000000918494: 04240D23
	v_dot2acc_f32_f16 v15, v35, v2                             // 000000918498: 041E0523
	v_dual_mov_b32 v6, v51 :: v_dual_mov_b32 v35, v10          // 00000091849C: CA100133 0622010A
	v_and_or_b32 v5, 0xffff, v57, v34                          // 0000009184A4: D6570005 048A72FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009184B0: BF870214
	v_dot2acc_f32_f16 v18, v1, v7                              // 0000009184B4: 04240F01
	v_dot2acc_f32_f16 v15, v1, v3                              // 0000009184B8: 041E0701
	v_mov_b32_e32 v57, v46                                     // 0000009184BC: 7E72032E
	v_dual_mov_b32 v3, v50 :: v_dual_mov_b32 v34, v43          // 0000009184C0: CA100132 0322012B
	v_pk_fma_f16 v2, v5, s5, 0xc931 op_sel_hi:[1,0,0]          // 0000009184C8: CC0E0002 0BFC0B05 0000C931
	v_mov_b32_e32 v5, v51                                      // 0000009184D4: 7E0A0333
	s_delay_alu instid0(VALU_DEP_2)                            // 0000009184D8: BF870002
	v_dual_mov_b32 v1, v9 :: v_dual_dot2acc_f32_f16 v18, v2, v8// 0000009184DC: CA180109 01121102
	v_dual_dot2acc_f32_f16 v15, v2, v4 :: v_dual_mov_b32 v2, v44// 0000009184E4: CB100902 0F02012C
	v_mov_b32_e32 v4, v42                                      // 0000009184EC: 7E08032A
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000009184F0: 917E047E
	s_cbranch_execz 58                                         // 0000009184F4: BFA5003A <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi4ELi2EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0x1ae0>
	v_add_nc_u32_e32 v9, 1, v1                                 // 0000009184F8: 4A120281
	s_mov_b32 s6, exec_lo                                      // 0000009184FC: BE86007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000918500: BF870001
	.long 0xd4c1007e                                           // 000000918504: D4C1007E
	v_cndmask_b32_e32 v1, v9, v14, vcc_lo                      // 000000918508: 02021D09
	s_cbranch_execz 64614                                      // 00000091850C: BFA5FC66 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi4ELi2EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0xba8>
	v_ashrrev_i32_e32 v10, 31, v9                              // 000000918510: 3414129F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000918514: BF870091
	.long 0xd73c0007                                           // 000000918518: D73C0007
	v_cndmask_b32_e32 v1, 10, v9, vcc_lo                       // 00000091851C: 0202128A
	.long 0xd7006a0a                                           // 000000918520: D7006A0A
	v_cndmask_b32_e32 v1, s1, v7, vcc_lo                       // 000000918524: 02020E01
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000918528: BF870111
	v_add_co_ci_u32_e64 v37, null, s3, v8, vcc_lo              // 00000091852C: D5207C25 01AA1003
	.long 0xd7006a07                                           // 000000918534: D7006A07
	v_cndmask_b32_e32 v1, v10, v33, vcc_lo                     // 000000918538: 0202430A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000091853C: BF8700A1
	v_add_co_ci_u32_e64 v8, null, 0, v37, vcc_lo               // 000000918540: D5207C08 01AA4A80
	.long 0xd7006a44                                           // 000000918548: D7006A44
	v_cndmask_b32_e32 v1, v10, v32, vcc_lo                     // 00000091854C: 0202410A
	v_add_co_ci_u32_e64 v69, null, 0, v37, vcc_lo              // 000000918550: D5207C45 01AA4A80
	s_clause 0xf                                               // 000000918558: BF85000F
	global_load_b32 v42, v[7:8], off                           // 00000091855C: DC520000 2A7C0007
	global_load_b32 v44, v[7:8], off offset:128                // 000000918564: DC520080 2C7C0007
	global_load_b32 v41, v[7:8], off offset:256                // 00000091856C: DC520100 297C0007
	global_load_b32 v40, v[7:8], off offset:384                // 000000918574: DC520180 287C0007
	global_load_b32 v39, v[7:8], off offset:512                // 00000091857C: DC520200 277C0007
	global_load_b32 v38, v[7:8], off offset:640                // 000000918584: DC520280 267C0007
	global_load_b32 v37, v[7:8], off offset:768                // 00000091858C: DC520300 257C0007
	global_load_b32 v10, v[7:8], off offset:896                // 000000918594: DC520380 0A7C0007
	global_load_b32 v51, v[68:69], off                         // 00000091859C: DC520000 337C0044
	global_load_b32 v50, v[68:69], off offset:128              // 0000009185A4: DC520080 327C0044
	global_load_b32 v49, v[68:69], off offset:256              // 0000009185AC: DC520100 317C0044
	global_load_b32 v48, v[68:69], off offset:384              // 0000009185B4: DC520180 307C0044
	global_load_b32 v47, v[68:69], off offset:512              // 0000009185BC: DC520200 2F7C0044
	global_load_b32 v46, v[68:69], off offset:640              // 0000009185C4: DC520280 2E7C0044
	global_load_b32 v45, v[68:69], off offset:768              // 0000009185CC: DC520300 2D7C0044
	global_load_b32 v43, v[68:69], off offset:896              // 0000009185D4: DC520380 2B7C0044
	s_branch 64562                                             // 0000009185DC: BFA0FC32 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi4ELi2EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0xba8>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000009185E0: 8C7E047E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000009185E4: BF870009
	s_or_b32 exec_lo, exec_lo, s0                              // 0000009185E8: 8C7E007E
	s_waitcnt vmcnt(22)                                        // 0000009185EC: BF895BF7
	v_dual_mov_b32 v1, v30 :: v_dual_mov_b32 v2, v27           // 0000009185F0: CA10011E 0102011B
	s_waitcnt vmcnt(14)                                        // 0000009185F8: BF893BF7
	v_dual_mov_b32 v3, v28 :: v_dual_mov_b32 v6, v26           // 0000009185FC: CA10011C 0306011A
	s_waitcnt vmcnt(7)                                         // 000000918604: BF891FF7
	v_dual_mov_b32 v4, v19 :: v_dual_mov_b32 v5, v17           // 000000918608: CA100113 04040111
	v_dual_mov_b32 v8, v21 :: v_dual_mov_b32 v7, v16           // 000000918610: CA100115 08060110
	v_dual_mov_b32 v9, v29 :: v_dual_mov_b32 v14, v24          // 000000918618: CA10011D 090E0118
	v_dual_mov_b32 v10, v25 :: v_dual_mov_b32 v31, v23         // 000000918620: CA100119 0A1E0117
	v_dual_mov_b32 v32, v22 :: v_dual_mov_b32 v33, v20         // 000000918628: CA100116 20200114
	s_waitcnt vmcnt(0)                                         // 000000918630: BF8903F7
	v_dual_mov_b32 v34, v18 :: v_dual_mov_b32 v35, v15         // 000000918634: CA100112 2222010F
	s_mov_b32 s0, 0x76543210                                   // 00000091863C: BE8000FF 76543210
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000918644: BF870009
	v_permlanex16_b32 v1, v1, s0, 0xfedcba98                   // 000000918648: D65C0001 03FC0101 FEDCBA98
	v_permlanex16_b32 v2, v2, s0, 0xfedcba98                   // 000000918654: D65C0002 03FC0102 FEDCBA98
	v_permlanex16_b32 v3, v3, s0, 0xfedcba98                   // 000000918660: D65C0003 03FC0103 FEDCBA98
	v_permlanex16_b32 v6, v6, s0, 0xfedcba98                   // 00000091866C: D65C0006 03FC0106 FEDCBA98
	v_permlanex16_b32 v4, v4, s0, 0xfedcba98                   // 000000918678: D65C0004 03FC0104 FEDCBA98
	v_permlanex16_b32 v5, v5, s0, 0xfedcba98                   // 000000918684: D65C0005 03FC0105 FEDCBA98
	v_permlanex16_b32 v8, v8, s0, 0xfedcba98                   // 000000918690: D65C0008 03FC0108 FEDCBA98
	v_permlanex16_b32 v9, v9, s0, 0xfedcba98                   // 00000091869C: D65C0009 03FC0109 FEDCBA98
	v_permlanex16_b32 v7, v7, s0, 0xfedcba98                   // 0000009186A8: D65C0007 03FC0107 FEDCBA98
	v_permlanex16_b32 v10, v10, s0, 0xfedcba98                 // 0000009186B4: D65C000A 03FC010A FEDCBA98
	v_permlanex16_b32 v14, v14, s0, 0xfedcba98                 // 0000009186C0: D65C000E 03FC010E FEDCBA98
	v_permlanex16_b32 v31, v31, s0, 0xfedcba98                 // 0000009186CC: D65C001F 03FC011F FEDCBA98
	v_permlanex16_b32 v32, v32, s0, 0xfedcba98                 // 0000009186D8: D65C0020 03FC0120 FEDCBA98
	v_permlanex16_b32 v33, v33, s0, 0xfedcba98                 // 0000009186E4: D65C0021 03FC0121 FEDCBA98
	v_permlanex16_b32 v34, v34, s0, 0xfedcba98                 // 0000009186F0: D65C0022 03FC0122 FEDCBA98
	v_permlanex16_b32 v35, v35, s0, 0xfedcba98                 // 0000009186FC: D65C0023 03FC0123 FEDCBA98
	.long 0xd44c0000                                           // 000000918708: D44C0000
	v_cndmask_b32_e32 v1, 16, v12, vcc_lo                      // 00000091870C: 02021890
	s_barrier                                                  // 000000918710: BFBD0000
	buffer_gl0_inv                                             // 000000918714: E0AC0000 00000000
	s_and_saveexec_b32 s1, s0                                  // 00000091871C: BE812000
	s_cbranch_execz 36                                         // 000000918720: BFA50024 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi4ELi2EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0x1cb4>
	v_lshl_or_b32 v13, v11, 10, v13                            // 000000918724: D656000D 0435150B
	v_dual_add_f32 v12, v15, v35 :: v_dual_add_f32 v15, v18, v34// 00000091872C: C908470F 0C0E4512
	v_add_f32_e32 v18, v20, v33                                // 000000918734: 06244314
	v_dual_add_f32 v20, v22, v32 :: v_dual_add_f32 v9, v29, v9 // 000000918738: C9084116 1408131D
	v_dual_add_f32 v22, v23, v31 :: v_dual_add_f32 v1, v30, v1 // 000000918740: C9083F17 1600031E
	v_dual_add_f32 v14, v24, v14 :: v_dual_add_nc_u32 v13, 0x4000, v13// 000000918748: C9201D18 0E0C1AFF 00004000
	v_dual_add_f32 v10, v25, v10 :: v_dual_add_f32 v3, v28, v3 // 000000918754: C9081519 0A02071C
	v_dual_add_f32 v6, v26, v6 :: v_dual_add_f32 v5, v17, v5   // 00000091875C: C9080D1A 06040B11
	v_add_f32_e32 v2, v27, v2                                  // 000000918764: 0604051B
	v_dual_add_f32 v8, v21, v8 :: v_dual_add_f32 v7, v16, v7   // 000000918768: C9081115 08060F10
	v_add_f32_e32 v4, v19, v4                                  // 000000918770: 06080913
	ds_store_2addr_b32 v13, v1, v3 offset1:16                  // 000000918774: D8381000 0003010D
	ds_store_2addr_b32 v13, v2, v6 offset0:128 offset1:144     // 00000091877C: D8389080 0006020D
	ds_store_2addr_b32 v13, v4, v8 offset0:32 offset1:48       // 000000918784: D8383020 0008040D
	ds_store_2addr_b32 v13, v5, v9 offset0:160 offset1:176     // 00000091878C: D838B0A0 0009050D
	ds_store_2addr_b32 v13, v7, v14 offset0:64 offset1:80      // 000000918794: D8385040 000E070D
	ds_store_2addr_b32 v13, v10, v22 offset0:192 offset1:208   // 00000091879C: D838D0C0 00160A0D
	ds_store_2addr_b32 v13, v20, v15 offset0:96 offset1:112    // 0000009187A4: D8387060 000F140D
	ds_store_2addr_b32 v13, v18, v12 offset0:224 offset1:240   // 0000009187AC: D838F0E0 000C120D
	s_or_b32 exec_lo, exec_lo, s1                              // 0000009187B4: 8C7E017E
	.long 0xd44c0001                                           // 0000009187B8: D44C0001
	v_cndmask_b32_e32 v1, 0x100, v0, vcc_lo                    // 0000009187BC: 020200FF 00000100
	s_waitcnt lgkmcnt(0)                                       // 0000009187C4: BF89FC07
	s_barrier                                                  // 0000009187C8: BFBD0000
	buffer_gl0_inv                                             // 0000009187CC: E0AC0000 00000000
	s_and_saveexec_b32 s3, s1                                  // 0000009187D4: BE832001
	s_cbranch_execnz 7                                         // 0000009187D8: BFA60007 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi4ELi2EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0x1cf8>
	s_or_b32 exec_lo, exec_lo, s3                              // 0000009187DC: 8C7E037E
	s_cmp_lt_i32 s9, 2                                         // 0000009187E0: BF048209
	s_mov_b32 s3, -1                                           // 0000009187E4: BE8300C1
	s_cbranch_scc0 33                                          // 0000009187E8: BFA10021 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi4ELi2EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0x1d70>
	s_and_b32 vcc_lo, exec_lo, s3                              // 0000009187EC: 8B6A037E
	s_cbranch_vccnz 200                                        // 0000009187F0: BFA400C8 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi4ELi2EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0x2014>
	s_branch 581                                               // 0000009187F4: BFA00245 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi4ELi2EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0x260c>
	v_lshlrev_b32_e32 v7, 2, v0                                // 0000009187F8: 300E0082
	ds_load_2addr_stride64_b32 v[1:2], v7 offset0:64 offset1:68// 0000009187FC: D8E04440 01000007
	ds_load_2addr_stride64_b32 v[3:4], v7 offset0:72 offset1:76// 000000918804: D8E04C48 03000007
	ds_load_2addr_stride64_b32 v[5:6], v7 offset0:80 offset1:84// 00000091880C: D8E05450 05000007
	s_waitcnt lgkmcnt(2)                                       // 000000918814: BF89FC27
	v_add_f32_e32 v1, 0, v1                                    // 000000918818: 06020280
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000091881C: BF8700A1
	v_add_f32_e32 v1, v1, v2                                   // 000000918820: 06020501
	s_waitcnt lgkmcnt(1)                                       // 000000918824: BF89FC17
	v_add_f32_e32 v3, v1, v3                                   // 000000918828: 06060701
	ds_load_2addr_stride64_b32 v[1:2], v7 offset0:88 offset1:92// 00000091882C: D8E05C58 01000007
	v_add_f32_e32 v3, v3, v4                                   // 000000918834: 06060903
	s_waitcnt lgkmcnt(1)                                       // 000000918838: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000091883C: BF870091
	v_add_f32_e32 v3, v3, v5                                   // 000000918840: 06060B03
	v_add_f32_e32 v3, v3, v6                                   // 000000918844: 06060D03
	s_waitcnt lgkmcnt(0)                                       // 000000918848: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000091884C: BF870091
	v_add_f32_e32 v1, v3, v1                                   // 000000918850: 06020303
	v_add_f32_e32 v1, v1, v2                                   // 000000918854: 06020501
	ds_store_b32 v7, v1 offset:24576                           // 000000918858: D8346000 00000107
	s_or_b32 exec_lo, exec_lo, s3                              // 000000918860: 8C7E037E
	s_cmp_lt_i32 s9, 2                                         // 000000918864: BF048209
	s_mov_b32 s3, -1                                           // 000000918868: BE8300C1
	s_cbranch_scc1 65503                                       // 00000091886C: BFA2FFDF <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi4ELi2EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0x1cec>
	s_waitcnt lgkmcnt(0)                                       // 000000918870: BF89FC07
	s_barrier                                                  // 000000918874: BFBD0000
	buffer_gl0_inv                                             // 000000918878: E0AC0000 00000000
	s_and_saveexec_b32 s3, s1                                  // 000000918880: BE832001
	s_cbranch_execz 41                                         // 000000918884: BFA50029 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi4ELi2EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0x1e2c>
	v_lshrrev_b32_e32 v1, 7, v0                                // 000000918888: 32020087
	s_ashr_i32 s4, s49, 31                                     // 00000091888C: 86049F31
	v_lshlrev_b32_e32 v4, 2, v0                                // 000000918890: 30080082
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(SALU_CYCLE_1)// 000000918894: BF8704D2
	v_lshl_or_b32 v1, s30, 1, v1                               // 000000918898: D6560001 0405021E
	ds_load_b32 v4, v4 offset:24576                            // 0000009188A0: D8D86000 04000004
	.long 0xd72c0003                                           // 0000009188A8: D72C0003
	v_cndmask_b32_e32 v0, v1, v4, vcc_lo                       // 0000009188AC: 02000901
	v_mad_u64_u32 v[1:2], null, v1, s49, 0                     // 0000009188B0: D6FE7C01 02006301
	s_ashr_i32 s4, s30, 31                                     // 0000009188B8: 86049F1E
	s_mul_i32 s4, s4, s49                                      // 0000009188BC: 96043104
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000009188C0: BF870149
	v_add3_u32 v2, v2, v3, s4                                  // 0000009188C4: D6550002 00120702
	s_lshl_b32 s4, s10, 7                                      // 0000009188CC: 8404870A
	v_and_b32_e32 v3, 0x7f, v0                                 // 0000009188D0: 360600FF 0000007F
	s_ashr_i32 s5, s4, 31                                      // 0000009188D8: 86059F04
	.long 0xd73c0001                                           // 0000009188DC: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 0000009188E0: 02020282
	s_lshl_b64 s[4:5], s[4:5], 2                               // 0000009188E4: 84848204
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000009188E8: BF870132
	v_lshlrev_b32_e32 v3, 2, v3                                // 0000009188EC: 30060682
	s_add_u32 s4, s44, s4                                      // 0000009188F0: 8004042C
	s_addc_u32 s5, s45, s5                                     // 0000009188F4: 8205052D
	.long 0xd7006a01                                           // 0000009188F8: D7006A01
	v_cndmask_b32_e32 v1, s4, v1, vcc_lo                       // 0000009188FC: 02020204
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000918900: BF870111
	v_add_co_ci_u32_e64 v2, null, s5, v2, vcc_lo               // 000000918904: D5207C02 01AA0405
	.long 0xd7006a01                                           // 00000091890C: D7006A01
	v_cndmask_b32_e32 v1, v1, v3, vcc_lo                       // 000000918910: 02020701
	s_delay_alu instid0(VALU_DEP_1)                            // 000000918914: BF870001
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 000000918918: D5207C02 01AA0480
	s_waitcnt lgkmcnt(0)                                       // 000000918920: BF89FC07
	global_store_b32 v[1:2], v4, off                           // 000000918924: DC6A0000 007C0401
	s_or_b32 exec_lo, exec_lo, s3                              // 00000091892C: 8C7E037E
	.long 0xd44a0003                                           // 000000918930: D44A0003
	v_cndmask_b32_e32 v1, 0, v0, vcc_lo                        // 000000918934: 02020080
	s_waitcnt_vscnt null, 0x0                                  // 000000918938: BC7C0000
	buffer_gl1_inv                                             // 00000091893C: E0B00000 00000000
	buffer_gl0_inv                                             // 000000918944: E0AC0000 00000000
	s_barrier                                                  // 00000091894C: BFBD0000
	buffer_gl0_inv                                             // 000000918950: E0AC0000 00000000
	s_and_saveexec_b32 s4, s3                                  // 000000918958: BE842003
	s_cbranch_execz 29                                         // 00000091895C: BFA5001D <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi4ELi2EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0x1ed4>
	s_mov_b32 s6, exec_lo                                      // 000000918960: BE86007E
	s_mov_b32 s5, exec_lo                                      // 000000918964: BE85007E
	.long 0xd71f0001                                           // 000000918968: D71F0001
	v_cndmask_b32_e32 v0, s6, v128, vcc_lo                     // 00000091896C: 02010006
	s_delay_alu instid0(VALU_DEP_1)                            // 000000918970: BF870001
	v_cmpx_eq_u32_e32 0, v1                                    // 000000918974: 7D940280
	s_cbranch_execz 9                                          // 000000918978: BFA50009 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi4ELi2EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0x1ea0>
	s_lshl_b64 s[24:25], s[10:11], 2                           // 00000091897C: 8498820A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 000000918980: BF8704B9
	s_add_u32 s24, s46, s24                                    // 000000918984: 8018182E
	s_addc_u32 s25, s47, s25                                   // 000000918988: 8219192F
	s_bcnt1_i32_b32 s6, s6                                     // 00000091898C: BE861806
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v3, s6              // 000000918990: CA100080 02020006
	global_atomic_add_u32 v2, v2, v3, s[24:25] glc             // 000000918998: DCD64000 02180302
	s_or_b32 exec_lo, exec_lo, s5                              // 0000009189A0: 8C7E057E
	s_waitcnt vmcnt(0)                                         // 0000009189A4: BF8903F7
	v_readfirstlane_b32 s5, v2                                 // 0000009189A8: 7E0A0502
	s_delay_alu instid0(VALU_DEP_1)                            // 0000009189AC: BF870001
	v_dual_mov_b32 v2, 0 :: v_dual_add_nc_u32 v1, s5, v1       // 0000009189B0: CA200080 02000205
	s_add_i32 s5, s9, -1                                       // 0000009189B8: 8105C109
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 0000009189BC: BF870481
	v_cmp_eq_u32_e32 vcc_lo, s5, v1                            // 0000009189C0: 7C940205
	v_cndmask_b32_e64 v1, 0, 1, vcc_lo                         // 0000009189C4: D5010001 01A90280
	ds_store_b32 v2, v1 offset:26624                           // 0000009189CC: D8346800 00000102
	s_or_b32 exec_lo, exec_lo, s4                              // 0000009189D4: 8C7E047E
	v_mov_b32_e32 v1, 0                                        // 0000009189D8: 7E020280
	s_waitcnt lgkmcnt(0)                                       // 0000009189DC: BF89FC07
	s_barrier                                                  // 0000009189E0: BFBD0000
	buffer_gl0_inv                                             // 0000009189E4: E0AC0000 00000000
	ds_load_b32 v1, v1 offset:26624                            // 0000009189EC: D8D86800 01000001
	s_waitcnt lgkmcnt(0)                                       // 0000009189F4: BF89FC07
	v_cmp_eq_u32_e32 vcc_lo, 0, v1                             // 0000009189F8: 7C940280
	s_cbranch_vccnz 68                                         // 0000009189FC: BFA40044 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi4ELi2EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0x2010>
	buffer_gl1_inv                                             // 000000918A00: E0B00000 00000000
	buffer_gl0_inv                                             // 000000918A08: E0AC0000 00000000
	s_and_saveexec_b32 s4, s1                                  // 000000918A10: BE842001
	s_cbranch_execz 50                                         // 000000918A14: BFA50032 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi4ELi2EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0x1fe0>
	v_and_b32_e32 v2, 0x7f, v0                                 // 000000918A18: 360400FF 0000007F
	s_lshl_b32 s6, s10, 7                                      // 000000918A20: 8406870A
	s_ashr_i32 s1, s49, 31                                     // 000000918A24: 86019F31
	s_ashr_i32 s7, s6, 31                                      // 000000918A28: 86079F06
	v_lshrrev_b32_e32 v1, 7, v0                                // 000000918A2C: 32020087
	v_dual_mov_b32 v2, 0 :: v_dual_lshlrev_b32 v3, 2, v2       // 000000918A30: CA220080 02020482
	s_lshl_b64 s[6:7], s[6:7], 2                               // 000000918A38: 84868206
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000918A3C: BF8700A9
	s_add_u32 s5, s44, s6                                      // 000000918A40: 8005062C
	s_addc_u32 s6, s45, s7                                     // 000000918A44: 8206072D
	.long 0xd7000503                                           // 000000918A48: D7000503
	v_cndmask_b32_e32 v1, s5, v3, vcc_lo                       // 000000918A4C: 02020605
	s_delay_alu instid0(VALU_DEP_1)                            // 000000918A50: BF870001
	v_add_co_ci_u32_e64 v4, null, s6, 0, s5                    // 000000918A54: D5207C04 00150006
	s_mov_b32 s5, s49                                          // 000000918A5C: BE850031
	s_nop 0                                                    // 000000918A60: BF800000
	s_nop 0                                                    // 000000918A64: BF800000
	s_nop 0                                                    // 000000918A68: BF800000
	s_nop 0                                                    // 000000918A6C: BF800000
	s_nop 0                                                    // 000000918A70: BF800000
	s_nop 0                                                    // 000000918A74: BF800000
	s_nop 0                                                    // 000000918A78: BF800000
	s_nop 0                                                    // 000000918A7C: BF800000
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000918A80: BF8704A9
	v_mad_u64_u32 v[5:6], null, v1, s5, 0                      // 000000918A84: D6FE7C05 02000B01
	s_add_i32 s9, s9, -1                                       // 000000918A8C: 8109C109
	s_cmp_eq_u32 s9, 0                                         // 000000918A90: BF068009
	v_mad_u64_u32 v[6:7], null, v1, s1, v[6:7]                 // 000000918A94: D6FE7C06 04180301
	v_add_nc_u32_e32 v1, 2, v1                                 // 000000918A9C: 4A020282
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000918AA0: BF870092
	.long 0xd73c0005                                           // 000000918AA4: D73C0005
	v_cndmask_b32_e32 v1, 2, v5, vcc_lo                        // 000000918AA8: 02020A82
	.long 0xd7006a05                                           // 000000918AAC: D7006A05
	v_cndmask_b32_e32 v1, v3, v5, vcc_lo                       // 000000918AB0: 02020B03
	s_delay_alu instid0(VALU_DEP_1)                            // 000000918AB4: BF870001
	v_add_co_ci_u32_e64 v6, null, v4, v6, vcc_lo               // 000000918AB8: D5207C06 01AA0D04
	global_load_b32 v5, v[5:6], off glc                        // 000000918AC0: DC524000 057C0005
	s_waitcnt vmcnt(0)                                         // 000000918AC8: BF8903F7
	v_add_f32_e32 v2, v2, v5                                   // 000000918ACC: 06040B02
	s_cbranch_scc0 65515                                       // 000000918AD0: BFA1FFEB <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi4ELi2EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0x1f80>
	v_lshlrev_b32_e32 v1, 2, v0                                // 000000918AD4: 30020082
	ds_store_b32 v1, v2 offset:24576                           // 000000918AD8: D8346000 00000201
	s_or_b32 exec_lo, exec_lo, s4                              // 000000918AE0: 8C7E047E
	s_and_saveexec_b32 s1, s3                                  // 000000918AE4: BE812003
	s_cbranch_execz 6                                          // 000000918AE8: BFA50006 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi4ELi2EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0x2004>
	s_lshl_b64 s[4:5], s[10:11], 2                             // 000000918AEC: 8484820A
	v_mov_b32_e32 v1, 0                                        // 000000918AF0: 7E020280
	s_add_u32 s4, s46, s4                                      // 000000918AF4: 8004042E
	s_addc_u32 s5, s47, s5                                     // 000000918AF8: 8205052F
	global_store_b32 v1, v1, s[4:5]                            // 000000918AFC: DC6A0000 00040101
	s_or_b32 exec_lo, exec_lo, s1                              // 000000918B04: 8C7E017E
	s_cbranch_execnz 2                                         // 000000918B08: BFA60002 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi4ELi2EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0x2014>
	s_branch 383                                               // 000000918B0C: BFA0017F <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi4ELi2EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0x260c>
	s_branch 382                                               // 000000918B10: BFA0017E <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi4ELi2EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0x260c>
	v_cmp_gt_i32_e32 vcc_lo, s48, v11                          // 000000918B14: 7C881630
	.long 0xd44c0001                                           // 000000918B18: D44C0001
	v_cndmask_b32_e32 v1, 64, v0, vcc_lo                       // 000000918B1C: 020200C0
	s_waitcnt lgkmcnt(0)                                       // 000000918B20: BF89FC07
	s_waitcnt_vscnt null, 0x0                                  // 000000918B24: BC7C0000
	s_barrier                                                  // 000000918B28: BFBD0000
	buffer_gl0_inv                                             // 000000918B2C: E0AC0000 00000000
	s_and_b32 s1, vcc_lo, s1                                   // 000000918B34: 8B01016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000918B38: BF870009
	s_and_saveexec_b32 s3, s1                                  // 000000918B3C: BE832001
	s_cbranch_execz 369                                        // 000000918B40: BFA50171 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi4ELi2EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0x2608>
	v_and_b32_e32 v1, 15, v0                                   // 000000918B44: 3602008F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000918B48: BF870091
	v_lshlrev_b32_e32 v2, 2, v1                                // 000000918B4C: 30040282
	v_lshl_or_b32 v2, v11, 9, v2                               // 000000918B50: D6560002 0409130B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000918B58: BF870001
	v_add_nc_u32_e32 v8, 0x6000, v2                            // 000000918B5C: 4A1004FF 00006000
	ds_load_2addr_b32 v[2:3], v8 offset1:16                    // 000000918B64: D8DC1000 02000008
	ds_load_2addr_b32 v[4:5], v8 offset0:32 offset1:48         // 000000918B6C: D8DC3020 04000008
	ds_load_2addr_b32 v[6:7], v8 offset0:64 offset1:80         // 000000918B74: D8DC5040 06000008
	ds_load_2addr_b32 v[8:9], v8 offset0:96 offset1:112        // 000000918B7C: D8DC7060 08000008
	v_and_b32_e32 v10, 1, v0                                   // 000000918B84: 36140081
	s_waitcnt lgkmcnt(3)                                       // 000000918B88: BF89FC37
	v_dual_add_f32 v14, v2, v3 :: v_dual_and_b32 v13, 4, v0    // 000000918B8C: C9240702 0E0C0084
	s_waitcnt lgkmcnt(2)                                       // 000000918B94: BF89FC27
	v_dual_sub_f32 v2, v2, v3 :: v_dual_add_f32 v3, v4, v5     // 000000918B98: C9480702 02020B04
	s_waitcnt lgkmcnt(1)                                       // 000000918BA0: BF89FC17
	v_dual_sub_f32 v4, v4, v5 :: v_dual_add_f32 v5, v6, v7     // 000000918BA4: C9480B04 04040F06
	s_waitcnt lgkmcnt(0)                                       // 000000918BAC: BF89FC07
	v_dual_sub_f32 v6, v6, v7 :: v_dual_add_f32 v7, v8, v9     // 000000918BB0: C9480F06 06061308
	v_sub_f32_e32 v8, v8, v9                                   // 000000918BB8: 08101308
	v_dual_add_f32 v9, v14, v3 :: v_dual_and_b32 v12, 2, v0    // 000000918BBC: C924070E 090C0082
	v_sub_f32_e32 v3, v14, v3                                  // 000000918BC4: 0806070E
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000918BC8: BF8701B4
	v_dual_add_f32 v14, v2, v4 :: v_dual_add_f32 v15, v5, v7   // 000000918BCC: C9080902 0E0E0F05
	v_sub_f32_e32 v2, v2, v4                                   // 000000918BD4: 08040902
	v_dual_add_f32 v4, v6, v8 :: v_dual_sub_f32 v5, v5, v7     // 000000918BD8: C90A1106 04040F05
	v_dual_sub_f32 v6, v6, v8 :: v_dual_add_f32 v7, v9, v15    // 000000918BE0: C9481106 06061F09
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000918BE8: BF870222
	v_dual_sub_f32 v8, v9, v15 :: v_dual_add_f32 v9, v14, v4   // 000000918BEC: C9481F09 0808090E
	v_sub_f32_e32 v4, v14, v4                                  // 000000918BF4: 0808090E
	v_add_f32_e32 v14, v3, v5                                  // 000000918BF8: 061C0B03
	v_sub_f32_e32 v3, v3, v5                                   // 000000918BFC: 08060B03
	v_add_f32_e32 v5, v2, v6                                   // 000000918C00: 060A0D02
	v_cmp_eq_u32_e32 vcc_lo, 0, v10                            // 000000918C04: 7C941480
	v_mov_b32_dpp v10, v9 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000918C08: 7E1402FA FF016109
	v_mov_b32_dpp v18, v4 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000918C10: 7E2402FA FF016104
	v_mov_b32_dpp v15, v14 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000918C18: 7E1E02FA FF01610E
	v_mov_b32_dpp v16, v5 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000918C20: 7E2002FA FF016105
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 000000918C28: D5010009 21AA1309
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 000000918C30: D5010005 21AA0B05
	v_sub_f32_e32 v2, v2, v6                                   // 000000918C38: 08040D02
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 000000918C3C: D5010004 21AA0904
	v_cndmask_b32_e64 v14, -v14, v14, vcc_lo                   // 000000918C44: D501000E 21AA1D0E
	v_mov_b32_dpp v17, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000918C4C: 7E2202FA FF016108
	v_add_f32_e32 v5, v5, v16                                  // 000000918C54: 060A2105
	v_mov_b32_dpp v21, v2 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000918C58: 7E2A02FA FF016102
	v_cndmask_b32_e64 v22, -v2, v2, vcc_lo                     // 000000918C60: D5010016 21AA0502
	v_add_f32_e32 v2, v9, v10                                  // 000000918C68: 06041509
	v_add_f32_e32 v9, v4, v18                                  // 000000918C6C: 06122504
	v_mov_b32_dpp v6, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000918C70: 7E0C02FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, vcc_lo                      // 000000918C78: D5010007 21AA0F07
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 000000918C80: D5010008 21AA1108
	v_mov_b32_dpp v19, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000918C88: 7E2602FA FF016103
	v_cndmask_b32_e64 v20, -v3, v3, vcc_lo                     // 000000918C90: D5010014 21AA0703
	v_cmp_eq_u32_e32 vcc_lo, 0, v12                            // 000000918C98: 7C941880
	v_add_f32_e32 v3, v7, v6                                   // 000000918C9C: 06060D07
	.long 0xd44a0001                                           // 000000918CA0: D44A0001
	v_cndmask_b32_e32 v1, 0, v13, vcc_lo                       // 000000918CA4: 02021A80
	v_mov_b32_dpp v12, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000918CA8: 7E1802FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 000000918CB0: D5010005 21AA0B05
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000918CB8: BF8700A4
	v_mov_b32_dpp v4, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000918CBC: 7E0802FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 000000918CC4: D5010003 21AA0703
	v_add_f32_e32 v3, v3, v4                                   // 000000918CCC: 06060903
	v_mov_b32_dpp v7, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000918CD0: 7E0E02FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, vcc_lo                      // 000000918CD8: D5010002 21AA0502
	v_add_f32_e32 v4, v5, v12                                  // 000000918CE0: 06081905
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000918CE4: BF8700A4
	v_mov_b32_dpp v5, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000918CE8: 7E0A02FA FF016403
	v_cndmask_b32_e64 v3, -v3, v3, s1                          // 000000918CF0: D5010003 20060703
	v_dual_add_f32 v2, v2, v7 :: v_dual_add_f32 v3, v3, v5     // 000000918CF8: C9080F02 02020B03
	s_delay_alu instid0(VALU_DEP_1)                            // 000000918D00: BF870001
	v_cndmask_b32_e64 v7, -v2, v2, s1                          // 000000918D04: D5010007 20060502
	v_mov_b32_dpp v2, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000918D0C: 7E0402FA FF016402
	v_add_f32_e32 v6, v14, v15                                 // 000000918D14: 060C1F0E
	v_add_f32_e32 v14, v22, v21                                // 000000918D18: 061C2B16
	v_mov_b32_dpp v15, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000918D1C: 7E1E02FA FF016209
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 000000918D24: D5010009 21AA1309
	v_add_f32_e32 v7, v7, v2                                   // 000000918D2C: 060E0507
	v_mov_b32_dpp v10, v6 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000918D30: 7E1402FA FF016206
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 000000918D38: D5010006 21AA0D06
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000918D40: BF870234
	v_dual_add_f32 v8, v8, v17 :: v_dual_add_f32 v9, v9, v15   // 000000918D44: C9082308 08081F09
	v_mov_b32_dpp v16, v14 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000918D4C: 7E2002FA FF01620E
	v_cndmask_b32_e64 v14, -v14, v14, vcc_lo                   // 000000918D54: D501000E 21AA1D0E
	v_add_f32_e32 v6, v6, v10                                  // 000000918D5C: 060C1506
	v_mov_b32_dpp v10, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000918D60: 7E1402FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s1                          // 000000918D68: D5010004 20060904
	v_mov_b32_dpp v13, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000918D70: 7E1A02FA FF016208
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 000000918D78: D5010008 21AA1108
	v_mov_b32_dpp v12, v6 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000918D80: 7E1802FA FF016406
	v_cndmask_b32_e64 v6, -v6, v6, s1                          // 000000918D88: D5010006 20060D06
	v_add_f32_e32 v4, v4, v10                                  // 000000918D90: 06081504
	v_add_f32_e32 v10, v20, v19                                // 000000918D94: 06142714
	v_add_f32_e32 v8, v8, v13                                  // 000000918D98: 06101B08
	v_mov_b32_dpp v2, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000918D9C: 7E0402FA FF016803
	v_add_f32_e32 v6, v6, v12                                  // 000000918DA4: 060C1906
	v_mov_b32_dpp v5, v7 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000918DA8: 7E0A02FA FF016807
	v_mov_b32_dpp v13, v10 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000918DB0: 7E1A02FA FF01620A
	v_cndmask_b32_e64 v10, -v10, v10, vcc_lo                   // 000000918DB8: D501000A 21AA150A
	v_mov_b32_dpp v12, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000918DC0: 7E1802FA FF016408
	v_cndmask_b32_e64 v15, -v8, v8, s1                         // 000000918DC8: D501000F 20061108
	v_mov_b32_dpp v8, v6 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000918DD0: 7E1002FA FF016806
	s_delay_alu instid0(VALU_DEP_4)                            // 000000918DD8: BF870004
	v_add_f32_e32 v10, v10, v13                                // 000000918DDC: 06141B0A
	v_add_f32_e32 v13, v14, v16                                // 000000918DE0: 061A210E
	v_mov_b32_dpp v14, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000918DE4: 7E1C02FA FF016409
	v_cndmask_b32_e64 v9, -v9, v9, s1                          // 000000918DEC: D5010009 20061309
	v_add_f32_e32 v15, v15, v12                                // 000000918DF4: 061E190F
	v_mov_b32_dpp v16, v10 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000918DF8: 7E2002FA FF01640A
	v_mov_b32_dpp v18, v13 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000918E00: 7E2402FA FF01640D
	v_cndmask_b32_e64 v10, -v10, v10, s1                       // 000000918E08: D501000A 2006150A
	v_cndmask_b32_e64 v13, -v13, v13, s1                       // 000000918E10: D501000D 20061B0D
	v_add_f32_e32 v17, v9, v14                                 // 000000918E18: 06221D09
	v_mov_b32_dpp v9, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000918E1C: 7E1202FA FF016804
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000918E24: BF870214
	v_add_f32_e32 v16, v10, v16                                // 000000918E28: 0620210A
	v_add_f32_e32 v18, v13, v18                                // 000000918E2C: 0624250D
	v_mov_b32_dpp v10, v15 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000918E30: 7E1402FA FF01680F
	v_mov_b32_dpp v12, v17 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000918E38: 7E1802FA FF016811
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000918E40: BF870214
	v_mov_b32_dpp v13, v16 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000918E44: 7E1A02FA FF016810
	v_mov_b32_dpp v14, v18 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000918E4C: 7E1C02FA FF016812
	s_and_b32 exec_lo, exec_lo, s0                             // 000000918E54: 8B7E007E
	s_cbranch_execz 171                                        // 000000918E58: BFA500AB <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi4ELi2EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0x2608>
	v_lshl_or_b32 v19, s10, 7, v1                              // 000000918E5C: D6560013 04050E0A
	v_and_b32_e32 v1, 8, v0                                    // 000000918E64: 36020088
	.long 0x7f2e3880                                           // 000000918E68: 7F2E3880
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000918E6C: BF870113
	v_ashrrev_i32_e32 v20, 31, v19                             // 000000918E70: 3428269F
	.long 0x7f303997                                           // 000000918E74: 7F303997
	.long 0x7f323997                                           // 000000918E78: 7F323997
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000918E7C: BF870093
	.long 0xd73c0013                                           // 000000918E80: D73C0013
	v_cndmask_b32_e32 v1, 1, v19, vcc_lo                       // 000000918E84: 02022681
	.long 0xd7006a15                                           // 000000918E88: D7006A15
	v_cndmask_b32_e32 v1, s36, v19, vcc_lo                     // 000000918E8C: 02022624
	s_delay_alu instid0(VALU_DEP_1)                            // 000000918E90: BF870001
	v_add_co_ci_u32_e64 v22, null, s37, v20, vcc_lo            // 000000918E94: D5207C16 01AA2825
	v_cmp_eq_u32_e32 vcc_lo, 0, v1                             // 000000918E9C: 7C940280
	s_clause 0x7                                               // 000000918EA0: BF850007
	global_load_d16_b16 v23, v[21:22], off offset:32           // 000000918EA4: DC820020 177C0015
	global_load_d16_b16 v24, v[21:22], off                     // 000000918EAC: DC820000 187C0015
	global_load_d16_b16 v25, v[21:22], off offset:64           // 000000918EB4: DC820040 197C0015
	global_load_d16_b16 v26, v[21:22], off offset:96           // 000000918EBC: DC820060 1A7C0015
	global_load_d16_b16 v27, v[21:22], off offset:128          // 000000918EC4: DC820080 1B7C0015
	global_load_d16_b16 v28, v[21:22], off offset:160          // 000000918ECC: DC8200A0 1C7C0015
	global_load_d16_b16 v29, v[21:22], off offset:192          // 000000918ED4: DC8200C0 1D7C0015
	global_load_d16_b16 v30, v[21:22], off offset:224          // 000000918EDC: DC8200E0 1E7C0015
	v_mad_i64_i32 v[21:22], null, s49, v11, 0                  // 000000918EE4: D6FF7C15 02021631
	v_cndmask_b32_e64 v1, -v7, v7, vcc_lo                      // 000000918EEC: D5010001 21AA0F07
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 000000918EF4: D5010003 21AA0703
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 000000918EFC: D5010004 21AA0904
	v_cndmask_b32_e64 v15, -v15, v15, vcc_lo                   // 000000918F04: D501000F 21AA1F0F
	v_cndmask_b32_e64 v16, -v16, v16, vcc_lo                   // 000000918F0C: D5010010 21AA2110
	v_add_f32_e32 v1, v1, v5                                   // 000000918F14: 06020B01
	v_cndmask_b32_e64 v5, -v6, v6, vcc_lo                      // 000000918F18: D5010005 21AA0D06
	.long 0xd73c0015                                           // 000000918F20: D73C0015
	v_cndmask_b32_e32 v1, 1, v21, vcc_lo                       // 000000918F24: 02022A81
	v_cndmask_b32_e64 v6, -v17, v17, vcc_lo                    // 000000918F28: D5010006 21AA2311
	v_cndmask_b32_e64 v17, -v18, v18, vcc_lo                   // 000000918F30: D5010011 21AA2512
	v_add_f32_e32 v4, v4, v9                                   // 000000918F38: 06081304
	v_add_f32_e32 v9, v16, v13                                 // 000000918F3C: 06121B10
	s_waitcnt vmcnt(7)                                         // 000000918F40: BF891FF7
	.long 0x7f0e3997                                           // 000000918F44: 7F0E3997
	.long 0xd7006a12                                           // 000000918F48: D7006A12
	v_cndmask_b32_e32 v1, s42, v21, vcc_lo                     // 000000918F4C: 02022A2A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000918F50: BF8701C1
	v_add_co_ci_u32_e64 v21, null, s43, v22, vcc_lo            // 000000918F54: D5207C15 01AA2C2B
	v_add_f32_e32 v6, v6, v12                                  // 000000918F5C: 060C1906
	v_dual_add_f32 v5, v5, v8 :: v_dual_add_f32 v8, v15, v10   // 000000918F60: C9081105 0508150F
	v_dual_add_f32 v3, v3, v2 :: v_dual_mul_f32 v22, 0x3db504f3, v1// 000000918F68: C9060503 031602FF 3DB504F3
	v_mul_f32_e32 v6, 0x3db504f3, v6                           // 000000918F74: 100C0CFF 3DB504F3
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000918F7C: BF870193
	v_dual_mul_f32 v4, 0x3db504f3, v4 :: v_dual_mul_f32 v5, 0x3db504f3, v5// 000000918F80: C8C608FF 04040AFF 3DB504F3
	v_dual_add_f32 v10, v17, v14 :: v_dual_mul_f32 v3, 0x3db504f3, v3// 000000918F8C: C9061D11 0A0206FF 3DB504F3
	v_dual_mul_f32 v8, 0x3db504f3, v8 :: v_dual_mul_f32 v9, 0x3db504f3, v9// 000000918F98: C8C610FF 080812FF 3DB504F3
	.long 0x7f163997                                           // 000000918FA4: 7F163997
	.long 0xd7006a01                                           // 000000918FA8: D7006A01
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 000000918FAC: 02022712
	s_delay_alu instid0(VALU_DEP_1)                            // 000000918FB0: BF870001
	v_add_co_ci_u32_e64 v2, null, v21, v20, vcc_lo             // 000000918FB4: D5207C02 01AA2915
	v_fma_mix_f32 v12, v23, v22, neg(0) op_sel_hi:[1,0,0]      // 000000918FBC: CC20000C 8A022D17
	s_waitcnt vmcnt(6)                                         // 000000918FC4: BF891BF7
	v_fma_mix_f32 v3, v24, v3, neg(0) op_sel_hi:[1,0,0]        // 000000918FC8: CC200003 8A020718
	s_waitcnt vmcnt(5)                                         // 000000918FD0: BF8917F7
	v_fma_mix_f32 v5, v25, v5, neg(0) op_sel_hi:[1,0,0]        // 000000918FD4: CC200005 8A020B19
	s_waitcnt vmcnt(4)                                         // 000000918FDC: BF8913F7
	v_fma_mix_f32 v4, v26, v4, neg(0) op_sel_hi:[1,0,0]        // 000000918FE0: CC200004 8A02091A
	s_waitcnt vmcnt(3)                                         // 000000918FE8: BF890FF7
	v_fma_mix_f32 v8, v27, v8, neg(0) op_sel_hi:[1,0,0]        // 000000918FEC: CC200008 8A02111B
	.long 0x7e2e398c                                           // 000000918FF4: 7E2E398C
	v_mul_f32_e32 v10, 0x3db504f3, v10                         // 000000918FF8: 101414FF 3DB504F3
	s_waitcnt vmcnt(2)                                         // 000000919000: BF890BF7
	v_fma_mix_f32 v6, v28, v6, neg(0) op_sel_hi:[1,0,0]        // 000000919004: CC200006 8A020D1C
	s_waitcnt vmcnt(1)                                         // 00000091900C: BF8907F7
	v_fma_mix_f32 v9, v29, v9, neg(0) op_sel_hi:[1,0,0]        // 000000919010: CC200009 8A02131D
	.long 0x7e0e3983                                           // 000000919018: 7E0E3983
	v_and_b32_e32 v13, 1, v23                                  // 00000091901C: 361A2E81
	.long 0x7e2e3984                                           // 000000919020: 7E2E3984
	s_waitcnt vmcnt(0)                                         // 000000919024: BF8903F7
	v_fma_mix_f32 v10, v30, v10, neg(0) op_sel_hi:[1,0,0]      // 000000919028: CC20000A 8A02151E
	.long 0x7e163985                                           // 000000919030: 7E163985
	.long 0x7e303988                                           // 000000919034: 7E303988
	.long 0x7e323989                                           // 000000919038: 7E323989
	v_and_b32_e32 v14, 1, v23                                  // 00000091903C: 361C2E81
	.long 0x7e2e3986                                           // 000000919040: 7E2E3986
	v_and_b32_e32 v7, 1, v7                                    // 000000919044: 360E0E81
	v_and_b32_e32 v11, 1, v11                                  // 000000919048: 36161681
	v_and_b32_e32 v15, 1, v24                                  // 00000091904C: 361E3081
	v_and_b32_e32 v17, 1, v25                                  // 000000919050: 36223281
	v_and_b32_e32 v16, 1, v23                                  // 000000919054: 36202E81
	.long 0x7e2e398a                                           // 000000919058: 7E2E398A
	v_add3_u32 v3, v3, v7, 0x7fff                              // 00000091905C: D6550003 03FE0F03 00007FFF
	v_add3_u32 v12, v12, v13, 0x7fff                           // 000000919068: D655000C 03FE1B0C 00007FFF
	v_add3_u32 v5, v5, v11, 0x7fff                             // 000000919074: D6550005 03FE1705 00007FFF
	v_add3_u32 v4, v4, v14, 0x7fff                             // 000000919080: D6550004 03FE1D04 00007FFF
	v_and_b32_e32 v7, 1, v23                                   // 00000091908C: 360E2E81
	v_add3_u32 v8, v8, v15, 0x7fff                             // 000000919090: D6550008 03FE1F08 00007FFF
	v_add3_u32 v9, v9, v17, 0x7fff                             // 00000091909C: D6550009 03FE2309 00007FFF
	v_add3_u32 v6, v6, v16, 0x7fff                             // 0000009190A8: D6550006 03FE2106 00007FFF
	s_delay_alu instid0(VALU_DEP_4)                            // 0000009190B4: BF870004
	v_add3_u32 v7, v10, v7, 0x7fff                             // 0000009190B8: D6550007 03FE0F0A 00007FFF
	s_clause 0x7                                               // 0000009190C4: BF850007
	global_store_d16_hi_b16 v[1:2], v3, off                    // 0000009190C8: DC960000 007C0301
	global_store_d16_hi_b16 v[1:2], v12, off offset:32         // 0000009190D0: DC960020 007C0C01
	global_store_d16_hi_b16 v[1:2], v5, off offset:64          // 0000009190D8: DC960040 007C0501
	global_store_d16_hi_b16 v[1:2], v4, off offset:96          // 0000009190E0: DC960060 007C0401
	global_store_d16_hi_b16 v[1:2], v8, off offset:128         // 0000009190E8: DC960080 007C0801
	global_store_d16_hi_b16 v[1:2], v6, off offset:160         // 0000009190F0: DC9600A0 007C0601
	global_store_d16_hi_b16 v[1:2], v9, off offset:192         // 0000009190F8: DC9600C0 007C0901
	global_store_d16_hi_b16 v[1:2], v7, off offset:224         // 000000919100: DC9600E0 007C0701
	s_or_b32 exec_lo, exec_lo, s3                              // 000000919108: 8C7E037E
	s_mov_b32 s4, 0                                            // 00000091910C: BE840080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000919110: BF870009
	s_and_b32 vcc_lo, exec_lo, s4                              // 000000919114: 8B6A047E
	s_cbranch_vccz 2144                                        // 000000919118: BFA30860 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi4ELi2EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0x479c>
	v_mov_b32_e32 v1, 0                                        // 00000091911C: 7E020280
	global_load_b32 v2, v1, s[18:19]                           // 000000919120: DC520000 02120001
	s_waitcnt vmcnt(0)                                         // 000000919128: BF8903F7
	.long 0xd72c0002                                           // 00000091912C: D72C0002
	v_cndmask_b32_e32 v0, v2, v148, vcc_lo                     // 000000919130: 02012902
	s_delay_alu instid0(VALU_DEP_1)                            // 000000919134: BF870001
	v_cmp_ge_i32_e32 vcc_lo, s2, v2                            // 000000919138: 7C8C0402
	s_cbranch_vccnz 2135                                       // 00000091913C: BFA40857 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi4ELi2EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0x479c>
	s_mov_b32 s3, 0                                            // 000000919140: BE830080
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000919144: BF870499
	s_lshl_b64 s[0:1], s[2:3], 4                               // 000000919148: 84808402
	s_add_u32 s0, s16, s0                                      // 00000091914C: 80000010
	s_addc_u32 s1, s17, s1                                     // 000000919150: 82010111
	global_load_b128 v[1:4], v1, s[0:1]                        // 000000919154: DC5E0000 01000001
	s_mov_b32 s0, exec_lo                                      // 00000091915C: BE80007E
	s_waitcnt vmcnt(0)                                         // 000000919160: BF8903F7
	v_readfirstlane_b32 s5, v1                                 // 000000919164: 7E0A0501
	v_readfirstlane_b32 s4, v2                                 // 000000919168: 7E080502
	v_cmpx_gt_u32_e32 0x140, v0                                // 00000091916C: 7D9800FF 00000140
	s_cbranch_execz 58                                         // 000000919174: BFA5003A <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi4ELi2EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0x2760>
	v_add_nc_u32_e32 v1, -1, v4                                // 000000919178: 4A0208C1
	v_dual_mov_b32 v5, v0 :: v_dual_lshlrev_b32 v2, 4, v0      // 00000091917C: CA220100 05020084
	s_set_inst_prefetch_distance 0x1                           // 000000919184: BF840001
	s_nop 0                                                    // 000000919188: BF800000
	s_nop 0                                                    // 00000091918C: BF800000
	s_nop 0                                                    // 000000919190: BF800000
	s_nop 0                                                    // 000000919194: BF800000
	s_nop 0                                                    // 000000919198: BF800000
	s_nop 0                                                    // 00000091919C: BF800000
	s_nop 0                                                    // 0000009191A0: BF800000
	s_nop 0                                                    // 0000009191A4: BF800000
	s_nop 0                                                    // 0000009191A8: BF800000
	s_nop 0                                                    // 0000009191AC: BF800000
	s_nop 0                                                    // 0000009191B0: BF800000
	s_nop 0                                                    // 0000009191B4: BF800000
	s_nop 0                                                    // 0000009191B8: BF800000
	s_nop 0                                                    // 0000009191BC: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000009191C0: BF870131
	v_add_nc_u32_e32 v10, 0x100, v5                            // 0000009191C4: 4A140AFF 00000100
	v_and_b32_e32 v6, 0xffff, v5                               // 0000009191CC: 360C0AFF 0000FFFF
	.long 0x7f103880                                           // 0000009191D4: 7F103880
	v_mul_u32_u24_e32 v6, 0xcccd, v6                           // 0000009191D8: 160C0CFF 0000CCCD
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000009191E0: BF870091
	v_lshrrev_b32_e32 v6, 22, v6                               // 0000009191E4: 320C0C96
	v_add_nc_u32_e32 v7, v3, v6                                // 0000009191E8: 4A0E0D03
	.long 0xd7050006                                           // 0000009191EC: D7050006
	v_cndmask_b32_e32 v1, 0x50, v6, vcc_lo                     // 0000009191F0: 02020CFF 00000050
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000009191F8: BF870112
	v_min_i32_e32 v7, v7, v1                                   // 0000009191FC: 220E0307
	.long 0xd7040008                                           // 000000919200: D7040008
	v_cndmask_b32_e32 v1, v5, v6, vcc_lo                       // 000000919204: 02020D05
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000919208: BF870112
	v_mad_i64_i32 v[6:7], null, 0x500, v7, s[14:15]            // 00000091920C: D6FF7C06 003A0EFF 00000500
	v_lshlrev_b32_e32 v8, 4, v8                                // 000000919218: 30101084
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000091921C: BF870091
	.long 0xd7006a06                                           // 000000919220: D7006A06
	v_cndmask_b32_e32 v1, v6, v8, vcc_lo                       // 000000919224: 02021106
	v_add_co_ci_u32_e64 v7, null, 0, v7, vcc_lo                // 000000919228: D5207C07 01AA0E80
	v_cmp_lt_u32_e32 vcc_lo, 63, v5                            // 000000919230: 7C920ABF
	v_mov_b32_e32 v5, v10                                      // 000000919234: 7E0A030A
	global_load_b128 v[6:9], v[6:7], off                       // 000000919238: DC5E0000 067C0006
	s_or_b32 s3, vcc_lo, s3                                    // 000000919240: 8C03036A
	s_waitcnt vmcnt(0)                                         // 000000919244: BF8903F7
	ds_store_b128 v2, v[6:9]                                   // 000000919248: DB7C0000 00000602
	v_add_nc_u32_e32 v2, 0x1000, v2                            // 000000919250: 4A0404FF 00001000
	s_and_not1_b32 exec_lo, exec_lo, s3                        // 000000919258: 917E037E
	s_cbranch_execnz 65496                                     // 00000091925C: BFA6FFD8 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi4ELi2EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0x26c0>
	s_set_inst_prefetch_distance 0x2                           // 000000919260: BF840002
	s_or_b32 exec_lo, exec_lo, s0                              // 000000919264: 8C7E007E
	v_lshrrev_b32_e32 v21, 5, v0                               // 000000919268: 322A0085
	v_dual_mov_b32 v57, 0 :: v_dual_and_b32 v22, 31, v0        // 00000091926C: CA240080 3916009F
	v_dual_mov_b32 v56, 0 :: v_dual_mov_b32 v59, 0             // 000000919274: CA100080 383A0080
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000091927C: BF870193
	v_mul_u32_u24_e32 v5, 5, v21                               // 000000919280: 160A2A85
	v_dual_mov_b32 v58, 0 :: v_dual_lshlrev_b32 v1, 2, v22     // 000000919284: CA220080 3A002C82
	v_dual_mov_b32 v60, 0 :: v_dual_mov_b32 v61, 0             // 00000091928C: CA100080 3C3C0080
	s_delay_alu instid0(VALU_DEP_3)                            // 000000919294: BF870003
	v_min_u32_e32 v6, 35, v5                                   // 000000919298: 260C0AA3
	v_mov_b32_e32 v24, 0                                       // 00000091929C: 7E300280
	s_mul_hi_i32 s2, s5, 0x96000                               // 0000009192A0: 9702FF05 00096000
	s_mul_i32 s3, s5, 0x96000                                  // 0000009192A8: 9603FF05 00096000
	s_mul_hi_i32 s6, s4, 0x7800                                // 0000009192B0: 9706FF04 00007800
	v_add_nc_u32_e32 v55, 5, v6                                // 0000009192B8: 4A6E0C85
	s_mul_i32 s7, s4, 0x7800                                   // 0000009192BC: 9607FF04 00007800
	s_waitcnt lgkmcnt(0)                                       // 0000009192C4: BF89FC07
	s_waitcnt_vscnt null, 0x0                                  // 0000009192C8: BC7C0000
	s_barrier                                                  // 0000009192CC: BFBD0000
	buffer_gl0_inv                                             // 0000009192D0: E0AC0000 00000000
	v_cmp_lt_u32_e32 vcc_lo, v5, v55                           // 0000009192D8: 7C926F05
	s_and_saveexec_b32 s1, vcc_lo                              // 0000009192DC: BE81206A
	s_cbranch_execz 29                                         // 0000009192E0: BFA5001D <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi4ELi2EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0x2858>
	v_mul_u32_u24_e32 v2, 0xf00, v21                           // 0000009192E4: 16042AFF 00000F00
	s_add_u32 s0, s12, s3                                      // 0000009192EC: 8000030C
	s_addc_u32 s8, s13, s2                                     // 0000009192F0: 8208020D
	s_add_u32 s0, s0, s7                                       // 0000009192F4: 80000700
	s_addc_u32 s8, s8, s6                                      // 0000009192F8: 82080608
	.long 0xd7000002                                           // 0000009192FC: D7000002
	v_cndmask_b32_e32 v1, s0, v2, vcc_lo                       // 000000919300: 02020400
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000919304: BF870111
	v_add_co_ci_u32_e64 v8, null, s8, 0, s0                    // 000000919308: D5207C08 00010008
	.long 0xd7000007                                           // 000000919310: D7000007
	v_cndmask_b32_e32 v1, v2, v1, vcc_lo                       // 000000919314: 02020302
	s_delay_alu instid0(VALU_DEP_1)                            // 000000919318: BF870001
	v_add_co_ci_u32_e64 v8, null, 0, v8, s0                    // 00000091931C: D5207C08 00021080
	s_clause 0x5                                               // 000000919324: BF850005
	global_load_b32 v56, v[7:8], off                           // 000000919328: DC520000 387C0007
	global_load_b32 v57, v[7:8], off offset:128                // 000000919330: DC520080 397C0007
	global_load_b32 v58, v[7:8], off offset:256                // 000000919338: DC520100 3A7C0007
	global_load_b32 v59, v[7:8], off offset:384                // 000000919340: DC520180 3B7C0007
	global_load_b32 v60, v[7:8], off offset:512                // 000000919348: DC520200 3C7C0007
	global_load_b32 v61, v[7:8], off offset:640                // 000000919350: DC520280 3D7C0007
	s_or_b32 exec_lo, exec_lo, s1                              // 000000919358: 8C7E017E
	v_dual_mov_b32 v54, 0 :: v_dual_mov_b32 v53, 0             // 00000091935C: CA100080 36340080
	v_dual_mov_b32 v52, 0 :: v_dual_mov_b32 v51, 0             // 000000919364: CA100080 34320080
	v_dual_mov_b32 v50, 0 :: v_dual_mov_b32 v49, 0             // 00000091936C: CA100080 32300080
	v_dual_mov_b32 v48, 0 :: v_dual_mov_b32 v47, 0             // 000000919374: CA100080 302E0080
	v_dual_mov_b32 v46, 0 :: v_dual_mov_b32 v45, 0             // 00000091937C: CA100080 2E2C0080
	v_dual_mov_b32 v44, 0 :: v_dual_mov_b32 v43, 0             // 000000919384: CA100080 2C2A0080
	v_dual_mov_b32 v42, 0 :: v_dual_mov_b32 v41, 0             // 00000091938C: CA100080 2A280080
	v_dual_mov_b32 v40, 0 :: v_dual_mov_b32 v39, 0             // 000000919394: CA100080 28260080
	v_dual_mov_b32 v38, 0 :: v_dual_mov_b32 v37, 0             // 00000091939C: CA100080 26240080
	v_dual_mov_b32 v36, 0 :: v_dual_mov_b32 v35, 0             // 0000009193A4: CA100080 24220080
	v_dual_mov_b32 v34, 0 :: v_dual_mov_b32 v33, 0             // 0000009193AC: CA100080 22200080
	v_dual_mov_b32 v25, 0 :: v_dual_mov_b32 v32, 0             // 0000009193B4: CA100080 19200080
	v_dual_mov_b32 v31, 0 :: v_dual_mov_b32 v30, 0             // 0000009193BC: CA100080 1F1E0080
	v_dual_mov_b32 v29, 0 :: v_dual_mov_b32 v26, 0             // 0000009193C4: CA100080 1D1A0080
	v_dual_mov_b32 v28, 0 :: v_dual_mov_b32 v27, 0             // 0000009193CC: CA100080 1C1A0080
	v_mov_b32_e32 v23, 0                                       // 0000009193D4: 7E2E0280
	s_and_saveexec_b32 s1, vcc_lo                              // 0000009193D8: BE81206A
	s_cbranch_execz 1205                                       // 0000009193DC: BFA504B5 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi4ELi2EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0x3bb4>
	v_lshl_or_b32 v2, v22, 3, 4                                // 0000009193E0: D6560002 02110716
	v_mad_u32_u24 v11, v22, 24, 0x2f0                          // 0000009193E8: D60B000B 03FD3116 000002F0
	s_add_u32 s8, s3, s7                                       // 0000009193F4: 80080703
	s_addc_u32 s9, s2, s6                                      // 0000009193F8: 82090602
	v_mul_i32_i24_e32 v12, 0xffffffe8, v22                     // 0000009193FC: 12182CFF FFFFFFE8
	v_mad_u32_u24 v10, v2, 3, 0x2f0                            // 000000919404: D60B000A 03FD0702 000002F0
	v_cmp_lt_u32_e32 vcc_lo, 5, v2                             // 000000919410: 7C920485
	v_mul_i32_i24_e32 v16, -3, v2                              // 000000919414: 122004C3
	v_lshrrev_b32_e32 v15, 5, v11                              // 000000919418: 321E1685
	v_mad_u64_u32 v[7:8], null, 0x300, v5, s[8:9]              // 00000091941C: D6FE7C07 00220AFF 00000300
	v_lshrrev_b32_e32 v14, 5, v10                              // 000000919428: 321C1485
	v_mad_u32_u24 v13, 0x320, v21, v1                          // 00000091942C: D60B000D 04062AFF 00000320
	v_mul_u32_u24_e32 v9, 0x320, v21                           // 000000919438: 16122AFF 00000320
	v_subrev_nc_u32_e32 v15, 24, v15                           // 000000919440: 4E1E1E98
	v_sub_nc_u32_e32 v65, 0, v6                                // 000000919444: 4C820C80
	v_subrev_nc_u32_e32 v14, 24, v14                           // 000000919448: 4E1C1C98
	v_dual_mov_b32 v23, 0 :: v_dual_add_nc_u32 v66, 1, v5      // 00000091944C: CA200080 17420A81
	v_mov_b32_e32 v31, 0                                       // 000000919454: 7E3E0280
	v_dual_mov_b32 v26, 0 :: v_dual_add_nc_u32 v67, 0x1400, v13// 000000919458: CA200080 1A421AFF 00001400
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000919464: BF870244
	v_cndmask_b32_e32 v2, 23, v14, vcc_lo                      // 000000919468: 02041C97
	v_cmp_ne_u32_e32 vcc_lo, 0, v22                            // 00000091946C: 7C9A2C80
	v_and_b32_e32 v10, 0x7e0, v10                              // 000000919470: 361414FF 000007E0
	v_dual_mov_b32 v34, 0 :: v_dual_mov_b32 v35, 0             // 000000919478: CA100080 22220080
	v_subrev_nc_u32_e32 v14, 23, v2                            // 000000919480: 4E1C0497
	v_dual_mov_b32 v36, 0 :: v_dual_and_b32 v11, 0x7e0, v11    // 000000919484: CA240080 240A16FF 000007E0
	v_mov_b32_e32 v37, 0                                       // 000000919490: 7E4A0280
	v_dual_mov_b32 v27, 0 :: v_dual_mov_b32 v38, 0             // 000000919494: CA100080 1B260080
	v_mov_b32_e32 v39, 0                                       // 00000091949C: 7E4E0280
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000009194A0: BF8700B4
	v_add3_u32 v62, v12, v11, 0xfffffd34                       // 0000009194A4: D655003E 03FE170C FFFFFD34
	v_dual_cndmask_b32 v11, 23, v15 :: v_dual_add_nc_u32 v12, 1, v2// 0000009194B0: CA601E97 0B0C0481
	.long 0xd7006a01                                           // 0000009194B8: D7006A01
	v_cndmask_b32_e32 v1, v7, v1, vcc_lo                       // 0000009194BC: 02020307
	v_add_co_ci_u32_e64 v7, null, 0, v8, vcc_lo                // 0000009194C0: D5207C07 01AA1080
	s_delay_alu instid0(VALU_DEP_3)                            // 0000009194C8: BF870003
	v_cmp_gt_u32_e32 vcc_lo, 24, v12                           // 0000009194CC: 7C981898
	v_add3_u32 v63, v16, v10, 0xfffffd34                       // 0000009194D0: D655003F 03FE1510 FFFFFD34
	v_lshl_add_u32 v10, v11, 2, v9                             // 0000009194DC: D646000A 0425050B
	v_mov_b32_e32 v29, 0                                       // 0000009194E4: 7E3A0280
	v_dual_mov_b32 v25, 0 :: v_dual_cndmask_b32 v8, v14, v12   // 0000009194E8: CA120080 1908190E
	v_cmp_gt_i32_e32 vcc_lo, 23, v11                           // 0000009194F0: 7C881697
	v_lshl_add_u32 v12, v2, 2, v9                              // 0000009194F4: D646000C 04250502
	v_and_b32_e32 v2, 16, v0                                   // 0000009194FC: 36040090
	v_add_nc_u32_e32 v68, 0x1400, v10                          // 000000919500: 4A8814FF 00001400
	v_lshl_add_u32 v8, v8, 2, v9                               // 000000919508: D6460008 04250508
	v_cndmask_b32_e64 v11, 0xffffffa4, 4, vcc_lo               // 000000919510: D501000B 01A908FF FFFFFFA4
	.long 0xd7006a01                                           // 00000091951C: D7006A01
	v_cndmask_b32_e32 v1, s12, v1, vcc_lo                      // 000000919520: 0202020C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000919524: BF8701A1
	v_add_co_ci_u32_e64 v7, null, s13, v7, vcc_lo              // 000000919528: D5207C07 01AA0E0D
	v_lshl_or_b32 v64, v5, 5, v2                               // 000000919530: D6560040 04090B05
	.long 0xd7006a01                                           // 000000919538: D7006A01
	v_cndmask_b32_e32 v1, 0x300, v1, vcc_lo                    // 00000091953C: 020202FF 00000300
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000919544: BF8701C1
	v_add_co_ci_u32_e64 v2, null, 0, v7, vcc_lo                // 000000919548: D5207C02 01AA0E80
	v_dual_mov_b32 v28, 0 :: v_dual_add_nc_u32 v7, v10, v11    // 000000919550: CA200080 1C06170A
	v_dual_mov_b32 v33, 0 :: v_dual_add_nc_u32 v70, 0x1400, v12// 000000919558: CA200080 214618FF 00001400
	v_dual_mov_b32 v32, 0 :: v_dual_add_nc_u32 v71, 0x1400, v8 // 000000919564: CA200080 204610FF 00001400
	v_dual_mov_b32 v30, 0 :: v_dual_add_nc_u32 v69, 0x1400, v7 // 000000919570: CA200080 1E440EFF 00001400
	v_dual_mov_b32 v40, 0 :: v_dual_mov_b32 v41, 0             // 00000091957C: CA100080 28280080
	v_dual_mov_b32 v42, 0 :: v_dual_mov_b32 v43, 0             // 000000919584: CA100080 2A2A0080
	v_dual_mov_b32 v44, 0 :: v_dual_mov_b32 v45, 0             // 00000091958C: CA100080 2C2C0080
	v_dual_mov_b32 v46, 0 :: v_dual_mov_b32 v47, 0             // 000000919594: CA100080 2E2E0080
	v_dual_mov_b32 v48, 0 :: v_dual_mov_b32 v49, 0             // 00000091959C: CA100080 30300080
	v_dual_mov_b32 v50, 0 :: v_dual_mov_b32 v51, 0             // 0000009195A4: CA100080 32320080
	v_dual_mov_b32 v52, 0 :: v_dual_mov_b32 v53, 0             // 0000009195AC: CA100080 34340080
	v_mov_b32_e32 v54, 0                                       // 0000009195B4: 7E6C0280
	v_mov_b32_e32 v24, 0                                       // 0000009195B8: 7E300280
	s_mov_b32 s2, 0                                            // 0000009195BC: BE820080
	s_movk_i32 s3, 0x1eee                                      // 0000009195C0: B0031EEE
	s_branch 1055                                              // 0000009195C4: BFA0041F <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi4ELi2EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0x3b44>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000009195C8: 8C7E007E
	ds_load_2addr_b32 v[72:73], v69 offset1:24                 // 0000009195CC: D8DC1800 48000045
	ds_load_2addr_b32 v[74:75], v71 offset1:24                 // 0000009195D4: D8DC1800 4A000047
	ds_load_2addr_b32 v[14:15], v68 offset1:24                 // 0000009195DC: D8DC1800 0E000044
	ds_load_2addr_b32 v[78:79], v70 offset1:24                 // 0000009195E4: D8DC1800 4E000046
	ds_load_b128 v[9:12], v64                                  // 0000009195EC: DBFC0000 09000040
	ds_load_b128 v[5:8], v64 offset:1280                       // 0000009195F4: DBFC0500 05000040
	.long 0xd7000001                                           // 0000009195FC: D7000001
	v_cndmask_b32_e32 v1, 0x300, v1, vcc_lo                    // 000000919600: 020202FF 00000300
	s_delay_alu instid0(VALU_DEP_1)                            // 000000919608: BF870001
	v_add_co_ci_u32_e64 v2, null, 0, v2, s0                    // 00000091960C: D5207C02 00020480
	s_waitcnt lgkmcnt(5)                                       // 000000919614: BF89FC57
	v_dual_mov_b32 v13, v72 :: v_dual_add_nc_u32 v66, 1, v66   // 000000919618: CA200148 0D428481
	s_waitcnt lgkmcnt(3)                                       // 000000919620: BF89FC37
	v_dual_mov_b32 v77, v74 :: v_dual_mov_b32 v74, v15         // 000000919624: CA10014A 4D4A010F
	s_waitcnt lgkmcnt(2)                                       // 00000091962C: BF89FC27
	v_mov_b32_e32 v76, v79                                     // 000000919630: 7E98034F
	.long 0xd73d004f                                           // 000000919634: D73D004F
	v_cndmask_b32_e32 v1, v62, v13, vcc_lo                     // 000000919638: 02021B3E
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000091963C: BF870223
	.long 0xd73d004d                                           // 000000919640: D73D004D
	v_cndmask_b32_e32 v1, v63, v77, vcc_lo                     // 000000919644: 02029B3F
	.long 0xd73d0048                                           // 000000919648: D73D0048
	v_cndmask_b32_e32 v1, v62, v73, vcc_lo                     // 00000091964C: 0202933E
	.long 0xd73d0049                                           // 000000919650: D73D0049
	v_cndmask_b32_e32 v1, v63, v75, vcc_lo                     // 000000919654: 0202973F
	ds_load_b128 v[13:16], v64 offset:2560                     // 000000919658: DBFC0A00 0D000040
	ds_load_b128 v[17:20], v64 offset:3840                     // 000000919660: DBFC0F00 11000040
	v_add_nc_u32_e32 v64, 32, v64                              // 000000919668: 4A8080A0
	v_bfe_u32 v74, v79, 9, 16                                  // 00000091966C: D610004A 0241134F
	v_bfe_u32 v75, v79, 6, 16                                  // 000000919674: D610004B 02410D4F
	v_bfe_u32 v76, v79, 3, 16                                  // 00000091967C: D610004C 0241074F
	v_bfe_u32 v80, v77, 6, 16                                  // 000000919684: D6100050 02410D4D
	v_bfe_u32 v81, v77, 3, 16                                  // 00000091968C: D6100051 0241074D
	.long 0xd72c004a                                           // 000000919694: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 000000919698: 020294FF 83DCD12D
	.long 0xd72c004b                                           // 0000009196A0: D72C004B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v75, vcc_lo              // 0000009196A4: 020296FF 83DCD12D
	.long 0xd72c004c                                           // 0000009196AC: D72C004C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v76, vcc_lo              // 0000009196B0: 020298FF 83DCD12D
	.long 0xd72c0050                                           // 0000009196B8: D72C0050
	v_cndmask_b32_e32 v1, 0x83dcd12d, v80, vcc_lo              // 0000009196BC: 0202A0FF 83DCD12D
	.long 0xd72c0051                                           // 0000009196C4: D72C0051
	v_cndmask_b32_e32 v1, 0x83dcd12d, v81, vcc_lo              // 0000009196C8: 0202A2FF 83DCD12D
	v_bfe_u32 v82, v72, 9, 16                                  // 0000009196D0: D6100052 02411348
	v_bfe_u32 v83, v72, 6, 16                                  // 0000009196D8: D6100053 02410D48
	v_bfe_u32 v84, v72, 3, 16                                  // 0000009196E0: D6100054 02410748
	v_sad_u8 v74, v74, 0, 0x6400                               // 0000009196E8: D622004A 03FD014A 00006400
	v_sad_u8 v75, v75, 0, 0x6400                               // 0000009196F4: D622004B 03FD014B 00006400
	v_sad_u8 v76, v76, 0, 0x6400                               // 000000919700: D622004C 03FD014C 00006400
	v_sad_u8 v80, v80, 0, 0x6400                               // 00000091970C: D6220050 03FD0150 00006400
	.long 0xd72c0052                                           // 000000919718: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 00000091971C: 0202A4FF 83DCD12D
	v_and_b32_e32 v74, 0xffff, v74                             // 000000919724: 369494FF 0000FFFF
	.long 0xd72c0053                                           // 00000091972C: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v83, vcc_lo              // 000000919730: 0202A6FF 83DCD12D
	v_bfe_u32 v85, v73, 9, 16                                  // 000000919738: D6100055 02411349
	v_bfe_u32 v86, v73, 6, 16                                  // 000000919740: D6100056 02410D49
	.long 0xd72c0054                                           // 000000919748: D72C0054
	v_cndmask_b32_e32 v1, 0x83dcd12d, v84, vcc_lo              // 00000091974C: 0202A8FF 83DCD12D
	v_lshl_or_b32 v74, v75, 16, v74                            // 000000919754: D656004A 0529214B
	v_sad_u8 v75, v81, 0, 0x6400                               // 00000091975C: D622004B 03FD0151 00006400
	v_bfe_u32 v87, v73, 3, 16                                  // 000000919768: D6100057 02410749
	v_and_b32_e32 v73, 0xffff, v73                             // 000000919770: 369292FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000919778: BF8701C4
	v_pk_fma_f16 v74, v74, s3, 0xc931 op_sel_hi:[1,0,0]        // 00000091977C: CC0E004A 0BFC074A 0000C931
	v_and_b32_e32 v78, 0xffff, v79                             // 000000919788: 369C9EFF 0000FFFF
	v_bfe_u32 v79, v77, 9, 16                                  // 000000919790: D610004F 0241134D
	s_waitcnt lgkmcnt(2)                                       // 000000919798: BF89FC27
	v_dual_dot2acc_f32_f16 v27, v74, v5 :: v_dual_and_b32 v72, 0xffff, v72// 00000091979C: CB240B4A 1B4890FF 0000FFFF
	v_dot2acc_f32_f16 v23, v74, v9                             // 0000009197A8: 042E134A
	.long 0xd72c004e                                           // 0000009197AC: D72C004E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 0000009197B0: 02029CFF 83DCD12D
	.long 0xd72c004f                                           // 0000009197B8: D72C004F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v79, vcc_lo              // 0000009197BC: 02029EFF 83DCD12D
	s_waitcnt lgkmcnt(1)                                       // 0000009197C4: BF89FC17
	v_dot2acc_f32_f16 v28, v74, v13                            // 0000009197C8: 04381B4A
	.long 0xd72c0048                                           // 0000009197CC: D72C0048
	v_cndmask_b32_e32 v1, 0x83dcd12d, v72, vcc_lo              // 0000009197D0: 020290FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009197D8: BF870214
	v_sad_u8 v78, v78, 0, 0x6400                               // 0000009197DC: D622004E 03FD014E 00006400
	v_sad_u8 v79, v79, 0, 0x6400                               // 0000009197E8: D622004F 03FD014F 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009197F4: BF870193
	v_sad_u8 v72, v72, 0, 0x6400                               // 0000009197F8: D6220048 03FD0148 00006400
	v_lshlrev_b32_e32 v78, 16, v78                             // 000000919804: 309C9C90
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000919808: BF870113
	v_and_b32_e32 v79, 0xffff, v79                             // 00000091980C: 369E9EFF 0000FFFF
	v_and_or_b32 v76, 0xffff, v76, v78                         // 000000919814: D657004C 053A98FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000919820: BF870232
	v_lshl_or_b32 v79, v80, 16, v79                            // 000000919824: D656004F 053D2150
	.long 0xd72c004e                                           // 00000091982C: D72C004E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v85, vcc_lo              // 000000919830: 0202AAFF 83DCD12D
	.long 0xd72c0050                                           // 000000919838: D72C0050
	v_cndmask_b32_e32 v1, 0x83dcd12d, v73, vcc_lo              // 00000091983C: 020292FF 83DCD12D
	v_pk_fma_f16 v76, v76, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000919844: CC0E004C 0BFC074C 0000C931
	v_and_b32_e32 v77, 0xffff, v77                             // 000000919850: 369A9AFF 0000FFFF
	s_waitcnt lgkmcnt(0)                                       // 000000919858: BF89FC07
	v_dot2acc_f32_f16 v26, v74, v17                            // 00000091985C: 0434234A
	v_sad_u8 v74, v82, 0, 0x6400                               // 000000919860: D622004A 03FD0152 00006400
	.long 0xd72c0052                                           // 00000091986C: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v87, vcc_lo              // 000000919870: 0202AEFF 83DCD12D
	v_dot2acc_f32_f16 v28, v76, v14                            // 000000919878: 04381D4C
	.long 0xd72c004d                                           // 00000091987C: D72C004D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v77, vcc_lo              // 000000919880: 02029AFF 83DCD12D
	v_dot2acc_f32_f16 v23, v76, v10                            // 000000919888: 042E154C
	v_dot2acc_f32_f16 v26, v76, v18                            // 00000091988C: 0434254C
	v_and_b32_e32 v74, 0xffff, v74                             // 000000919890: 369494FF 0000FFFF
	v_sad_u8 v78, v78, 0, 0x6400                               // 000000919898: D622004E 03FD014E 00006400
	v_sad_u8 v82, v82, 0, 0x6400                               // 0000009198A4: D6220052 03FD0152 00006400
	v_sad_u8 v77, v77, 0, 0x6400                               // 0000009198B0: D622004D 03FD014D 00006400
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000009198BC: BF870091
	v_lshlrev_b32_e32 v77, 16, v77                             // 0000009198C0: 309A9A90
	v_and_or_b32 v75, 0xffff, v75, v77                         // 0000009198C4: D657004B 053696FF 0000FFFF
	v_pk_fma_f16 v77, v79, s3, 0xc931 op_sel_hi:[1,0,0]        // 0000009198D0: CC0E004D 0BFC074F 0000C931
	v_dot2acc_f32_f16 v27, v76, v6                             // 0000009198DC: 04360D4C
	v_sad_u8 v76, v84, 0, 0x6400                               // 0000009198E0: D622004C 03FD0154 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009198EC: BF870214
	v_pk_fma_f16 v79, v75, s3, 0xc931 op_sel_hi:[1,0,0]        // 0000009198F0: CC0E004F 0BFC074B 0000C931
	v_dot2acc_f32_f16 v28, v77, v15                            // 0000009198FC: 04381F4D
	s_delay_alu instid0(VALU_DEP_4)                            // 000000919900: BF870004
	v_dot2acc_f32_f16 v27, v77, v7                             // 000000919904: 04360F4D
	v_sad_u8 v75, v83, 0, 0x6400                               // 000000919908: D622004B 03FD0153 00006400
	v_dot2acc_f32_f16 v23, v77, v11                            // 000000919914: 042E174D
	v_dot2acc_f32_f16 v26, v77, v19                            // 000000919918: 0434274D
	.long 0xd72c004d                                           // 00000091991C: D72C004D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v86, vcc_lo              // 000000919920: 0202ACFF 83DCD12D
	v_dot2acc_f32_f16 v27, v79, v8                             // 000000919928: 0436114F
	v_lshl_or_b32 v74, v75, 16, v74                            // 00000091992C: D656004A 0529214B
	v_dot2acc_f32_f16 v28, v79, v16                            // 000000919934: 0438214F
	v_dot2acc_f32_f16 v23, v79, v12                            // 000000919938: 042E194F
	v_dot2acc_f32_f16 v26, v79, v20                            // 00000091993C: 0434294F
	s_delay_alu instid0(VALU_DEP_4)                            // 000000919940: BF870004
	v_pk_fma_f16 v83, v74, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000919944: CC0E0053 0BFC074A 0000C931
	v_lshlrev_b32_e32 v72, 16, v72                             // 000000919950: 30909090
	v_and_b32_e32 v78, 0xffff, v78                             // 000000919954: 369C9CFF 0000FFFF
	v_sad_u8 v77, v77, 0, 0x6400                               // 00000091995C: D622004D 03FD014D 00006400
	v_sad_u8 v74, v80, 0, 0x6400                               // 000000919968: D622004A 03FD0150 00006400
	v_dot2acc_f32_f16 v29, v83, v9                             // 000000919974: 043A1353
	v_and_or_b32 v81, 0xffff, v76, v72                         // 000000919978: D6570051 052298FF 0000FFFF
	ds_load_2addr_b32 v[72:73], v69 offset0:48 offset1:72      // 000000919984: D8DC4830 48000045
	ds_load_2addr_b32 v[75:76], v68 offset0:48 offset1:72      // 00000091998C: D8DC4830 4B000044
	v_dot2acc_f32_f16 v31, v83, v13                            // 000000919994: 043E1B53
	v_lshl_or_b32 v85, v77, 16, v78                            // 000000919998: D6560055 0539214D
	ds_load_2addr_b32 v[77:78], v71 offset0:48 offset1:72      // 0000009199A0: D8DC4830 4D000047
	v_pk_fma_f16 v84, v81, s3, 0xc931 op_sel_hi:[1,0,0]        // 0000009199A8: CC0E0054 0BFC0751 0000C931
	v_dot2acc_f32_f16 v30, v83, v5                             // 0000009199B4: 043C0B53
	ds_load_2addr_b32 v[80:81], v70 offset0:48 offset1:72      // 0000009199B8: D8DC4830 50000046
	v_pk_fma_f16 v85, v85, s3, 0xc931 op_sel_hi:[1,0,0]        // 0000009199C0: CC0E0055 0BFC0755 0000C931
	v_dual_dot2acc_f32_f16 v32, v83, v17 :: v_dual_dot2acc_f32_f16 v29, v84, v10// 0000009199CC: CB182353 201C1554
	v_lshlrev_b32_e32 v74, 16, v74                             // 0000009199D4: 30949490
	v_dot2acc_f32_f16 v31, v84, v14                            // 0000009199D8: 043E1D54
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009199DC: BF870193
	v_dual_dot2acc_f32_f16 v30, v84, v6 :: v_dual_dot2acc_f32_f16 v29, v85, v11// 0000009199E0: CB180D54 1E1C1755
	v_and_or_b32 v82, 0xffff, v82, v74                         // 0000009199E8: D6570052 052AA4FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009199F4: BF870193
	v_dot2acc_f32_f16 v31, v85, v15                            // 0000009199F8: 043E1F55
	v_dot2acc_f32_f16 v30, v85, v7                             // 0000009199FC: 043C0F55
	s_waitcnt lgkmcnt(3)                                       // 000000919A00: BF89FC37
	v_mov_b32_e32 v74, v72                                     // 000000919A04: 7E940348
	v_pk_fma_f16 v72, v82, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000919A08: CC0E0048 0BFC0752 0000C931
	s_waitcnt lgkmcnt(1)                                       // 000000919A14: BF89FC17
	v_mov_b32_e32 v79, v77                                     // 000000919A18: 7E9E034D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000919A1C: BF870193
	.long 0xd73d004a                                           // 000000919A20: D73D004A
	v_cndmask_b32_e32 v1, v62, v74, vcc_lo                     // 000000919A24: 0202953E
	v_dot2acc_f32_f16 v29, v72, v12                            // 000000919A28: 043A1948
	s_waitcnt lgkmcnt(0)                                       // 000000919A2C: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000919A30: BF870223
	.long 0xd73d004f                                           // 000000919A34: D73D004F
	v_cndmask_b32_e32 v1, v63, v79, vcc_lo                     // 000000919A38: 02029F3F
	v_dot2acc_f32_f16 v30, v72, v8                             // 000000919A3C: 043C1148
	v_bfe_u32 v75, v74, 9, 16                                  // 000000919A40: D610004B 0241134A
	v_and_b32_e32 v77, 0xffff, v74                             // 000000919A48: 369A94FF 0000FFFF
	v_bfe_u32 v80, v74, 6, 16                                  // 000000919A50: D6100050 02410D4A
	v_bfe_u32 v74, v74, 3, 16                                  // 000000919A58: D610004A 0241074A
	v_bfe_u32 v82, v79, 9, 16                                  // 000000919A60: D6100052 0241134F
	.long 0xd72c004b                                           // 000000919A68: D72C004B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v75, vcc_lo              // 000000919A6C: 020296FF 83DCD12D
	.long 0xd72c004d                                           // 000000919A74: D72C004D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v77, vcc_lo              // 000000919A78: 02029AFF 83DCD12D
	v_bfe_u32 v83, v79, 6, 16                                  // 000000919A80: D6100053 02410D4F
	.long 0xd72c0050                                           // 000000919A88: D72C0050
	v_cndmask_b32_e32 v1, 0x83dcd12d, v80, vcc_lo              // 000000919A8C: 0202A0FF 83DCD12D
	.long 0xd72c004a                                           // 000000919A94: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 000000919A98: 020294FF 83DCD12D
	.long 0xd72c0052                                           // 000000919AA0: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 000000919AA4: 0202A4FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4)                            // 000000919AAC: BF870004
	.long 0xd72c0053                                           // 000000919AB0: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v83, vcc_lo              // 000000919AB4: 0202A6FF 83DCD12D
	v_sad_u8 v75, v75, 0, 0x6400                               // 000000919ABC: D622004B 03FD014B 00006400
	v_dot2acc_f32_f16 v32, v84, v18                            // 000000919AC8: 04402554
	v_bfe_u32 v84, v79, 3, 16                                  // 000000919ACC: D6100054 0241074F
	v_and_b32_e32 v79, 0xffff, v79                             // 000000919AD4: 369E9EFF 0000FFFF
	v_sad_u8 v77, v77, 0, 0x6400                               // 000000919ADC: D622004D 03FD014D 00006400
	v_and_b32_e32 v75, 0xffff, v75                             // 000000919AE8: 369696FF 0000FFFF
	v_dual_dot2acc_f32_f16 v31, v72, v16 :: v_dual_dot2acc_f32_f16 v32, v85, v19// 000000919AF0: CB182148 1F202755
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000919AF8: BF870234
	.long 0xd72c004f                                           // 000000919AFC: D72C004F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v79, vcc_lo              // 000000919B00: 02029EFF 83DCD12D
	v_sad_u8 v80, v80, 0, 0x6400                               // 000000919B08: D6220050 03FD0150 00006400
	v_sad_u8 v74, v74, 0, 0x6400                               // 000000919B14: D622004A 03FD014A 00006400
	v_dual_dot2acc_f32_f16 v32, v72, v20 :: v_dual_lshlrev_b32 v77, 16, v77// 000000919B20: CB222948 204C9A90
	.long 0xd72c0054                                           // 000000919B28: D72C0054
	v_cndmask_b32_e32 v1, 0x83dcd12d, v84, vcc_lo              // 000000919B2C: 0202A8FF 83DCD12D
	v_sad_u8 v82, v82, 0, 0x6400                               // 000000919B34: D6220052 03FD0152 00006400
	v_lshl_or_b32 v75, v80, 16, v75                            // 000000919B40: D656004B 052D2150
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000919B48: BF870234
	v_and_or_b32 v74, 0xffff, v74, v77                         // 000000919B4C: D657004A 053694FF 0000FFFF
	v_sad_u8 v79, v79, 0, 0x6400                               // 000000919B58: D622004F 03FD014F 00006400
	v_sad_u8 v80, v83, 0, 0x6400                               // 000000919B64: D6220050 03FD0153 00006400
	v_pk_fma_f16 v75, v75, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000919B70: CC0E004B 0BFC074B 0000C931
	v_and_b32_e32 v77, 0xffff, v82                             // 000000919B7C: 369AA4FF 0000FFFF
	v_pk_fma_f16 v82, v74, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000919B84: CC0E0052 0BFC074A 0000C931
	v_sad_u8 v74, v84, 0, 0x6400                               // 000000919B90: D622004A 03FD0154 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000919B9C: BF870214
	v_dual_dot2acc_f32_f16 v34, v75, v13 :: v_dual_lshlrev_b32 v79, 16, v79// 000000919BA0: CB221B4B 224E9E90
	v_lshl_or_b32 v77, v80, 16, v77                            // 000000919BA8: D656004D 05352150
	v_dot2acc_f32_f16 v25, v75, v9                             // 000000919BB0: 0432134B
	v_dot2acc_f32_f16 v35, v75, v17                            // 000000919BB4: 0446234B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000919BB8: BF870244
	v_and_or_b32 v72, 0xffff, v74, v79                         // 000000919BBC: D6570048 053E94FF 0000FFFF
	v_dual_mov_b32 v74, v76 :: v_dual_mov_b32 v79, v81         // 000000919BC8: CA10014C 4A4E0151
	v_pk_fma_f16 v77, v77, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000919BD0: CC0E004D 0BFC074D 0000C931
	v_dot2acc_f32_f16 v34, v82, v14                            // 000000919BDC: 04441D52
	v_pk_fma_f16 v83, v72, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000919BE0: CC0E0053 0BFC0748 0000C931
	s_delay_alu instid0(VALU_DEP_4)                            // 000000919BEC: BF870004
	.long 0xd73d0048                                           // 000000919BF0: D73D0048
	v_cndmask_b32_e32 v1, v62, v73, vcc_lo                     // 000000919BF4: 0202933E
	v_dot2acc_f32_f16 v33, v75, v5                             // 000000919BF8: 04420B4B
	.long 0xd73d0049                                           // 000000919BFC: D73D0049
	v_cndmask_b32_e32 v1, v63, v78, vcc_lo                     // 000000919C00: 02029D3F
	v_dual_dot2acc_f32_f16 v34, v77, v15 :: v_dual_dot2acc_f32_f16 v25, v82, v10// 000000919C04: CB181F4D 22181552
	v_dot2acc_f32_f16 v35, v82, v18                            // 000000919C0C: 04462552
	v_bfe_u32 v75, v72, 9, 16                                  // 000000919C10: D610004B 02411348
	v_dual_dot2acc_f32_f16 v33, v82, v6 :: v_dual_and_b32 v76, 0xffff, v72// 000000919C18: CB240D52 214C90FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000919C24: BF870224
	v_dot2acc_f32_f16 v34, v83, v16                            // 000000919C28: 04442153
	v_bfe_u32 v78, v73, 6, 16                                  // 000000919C2C: D610004E 02410D49
	.long 0xd72c004a                                           // 000000919C34: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v75, vcc_lo              // 000000919C38: 020296FF 83DCD12D
	v_bfe_u32 v75, v72, 6, 16                                  // 000000919C40: D610004B 02410D48
	v_bfe_u32 v72, v72, 3, 16                                  // 000000919C48: D6100048 02410748
	.long 0xd72c004c                                           // 000000919C50: D72C004C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v76, vcc_lo              // 000000919C54: 020298FF 83DCD12D
	.long 0xd72c004e                                           // 000000919C5C: D72C004E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 000000919C60: 02029CFF 83DCD12D
	v_bfe_u32 v79, v73, 3, 16                                  // 000000919C68: D610004F 02410749
	.long 0xd72c004b                                           // 000000919C70: D72C004B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v75, vcc_lo              // 000000919C74: 020296FF 83DCD12D
	.long 0xd72c0048                                           // 000000919C7C: D72C0048
	v_cndmask_b32_e32 v1, 0x83dcd12d, v72, vcc_lo              // 000000919C80: 020290FF 83DCD12D
	v_sad_u8 v74, v74, 0, 0x6400                               // 000000919C88: D622004A 03FD014A 00006400
	v_dot2acc_f32_f16 v25, v77, v11                            // 000000919C94: 0432174D
	.long 0xd72c004f                                           // 000000919C98: D72C004F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v79, vcc_lo              // 000000919C9C: 02029EFF 83DCD12D
	v_sad_u8 v76, v76, 0, 0x6400                               // 000000919CA4: D622004C 03FD014C 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000919CB0: BF870234
	v_dual_dot2acc_f32_f16 v33, v77, v7 :: v_dual_and_b32 v74, 0xffff, v74// 000000919CB4: CB240F4D 214A94FF 0000FFFF
	v_sad_u8 v75, v75, 0, 0x6400                               // 000000919CC0: D622004B 03FD014B 00006400
	v_sad_u8 v72, v72, 0, 0x6400                               // 000000919CCC: D6220048 03FD0148 00006400
	v_lshlrev_b32_e32 v76, 16, v76                             // 000000919CD8: 30989890
	v_sad_u8 v78, v78, 0, 0x6400                               // 000000919CDC: D622004E 03FD014E 00006400
	v_sad_u8 v79, v79, 0, 0x6400                               // 000000919CE8: D622004F 03FD014F 00006400
	v_lshl_or_b32 v74, v75, 16, v74                            // 000000919CF4: D656004A 0529214B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_3)// 000000919CFC: BF8701D4
	v_and_or_b32 v81, 0xffff, v72, v76                         // 000000919D00: D6570051 053290FF 0000FFFF
	ds_load_2addr_b32 v[75:76], v68 offset0:96 offset1:120     // 000000919D0C: D8DC7860 4B000044
	v_pk_fma_f16 v82, v74, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000919D14: CC0E0052 0BFC074A 0000C931
	v_dot2acc_f32_f16 v33, v83, v8                             // 000000919D20: 04421153
	v_pk_fma_f16 v84, v81, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000919D24: CC0E0054 0BFC0751 0000C931
	v_dual_dot2acc_f32_f16 v25, v83, v12 :: v_dual_dot2acc_f32_f16 v36, v82, v9// 000000919D30: CB181953 19241352
	v_dual_dot2acc_f32_f16 v38, v82, v13 :: v_dual_dot2acc_f32_f16 v35, v77, v19// 000000919D38: CB181B52 2622274D
	v_bfe_u32 v77, v73, 9, 16                                  // 000000919D40: D610004D 02411349
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000919D48: BF870193
	v_dual_dot2acc_f32_f16 v39, v82, v17 :: v_dual_dot2acc_f32_f16 v36, v84, v10// 000000919D4C: CB182352 27241554
	v_dot2acc_f32_f16 v38, v84, v14                            // 000000919D54: 044C1D54
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000919D58: BF870193
	.long 0xd72c004d                                           // 000000919D5C: D72C004D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v77, vcc_lo              // 000000919D60: 02029AFF 83DCD12D
	v_dot2acc_f32_f16 v39, v84, v18                            // 000000919D68: 044E2554
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000919D6C: BF870092
	v_sad_u8 v77, v77, 0, 0x6400                               // 000000919D70: D622004D 03FD014D 00006400
	v_and_b32_e32 v77, 0xffff, v77                             // 000000919D7C: 369A9AFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000919D84: BF8700B1
	v_lshl_or_b32 v85, v78, 16, v77                            // 000000919D88: D6560055 0535214E
	ds_load_2addr_b32 v[77:78], v71 offset0:96 offset1:120     // 000000919D90: D8DC7860 4D000047
	v_pk_fma_f16 v85, v85, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000919D98: CC0E0055 0BFC0755 0000C931
	v_dual_dot2acc_f32_f16 v36, v85, v11 :: v_dual_and_b32 v73, 0xffff, v73// 000000919DA4: CB241755 244892FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_1)                            // 000000919DB0: BF870001
	.long 0xd72c0050                                           // 000000919DB4: D72C0050
	v_cndmask_b32_e32 v1, 0x83dcd12d, v73, vcc_lo              // 000000919DB8: 020292FF 83DCD12D
	ds_load_2addr_b32 v[72:73], v69 offset0:96 offset1:120     // 000000919DC0: D8DC7860 48000045
	v_dot2acc_f32_f16 v38, v85, v15                            // 000000919DC8: 044C1F55
	v_dot2acc_f32_f16 v39, v85, v19                            // 000000919DCC: 044E2755
	v_sad_u8 v74, v80, 0, 0x6400                               // 000000919DD0: D622004A 03FD0150 00006400
	ds_load_2addr_b32 v[80:81], v70 offset0:96 offset1:120     // 000000919DDC: D8DC7860 50000046
	v_lshlrev_b32_e32 v74, 16, v74                             // 000000919DE4: 30949490
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000919DE8: BF870131
	v_and_or_b32 v79, 0xffff, v79, v74                         // 000000919DEC: D657004F 052A9EFF 0000FFFF
	s_waitcnt lgkmcnt(1)                                       // 000000919DF8: BF89FC17
	v_mov_b32_e32 v74, v72                                     // 000000919DFC: 7E940348
	v_pk_fma_f16 v72, v79, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000919E00: CC0E0048 0BFC074F 0000C931
	v_mov_b32_e32 v79, v77                                     // 000000919E0C: 7E9E034D
	v_dot2acc_f32_f16 v37, v82, v5                             // 000000919E10: 044A0B52
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000919E14: BF870214
	.long 0xd73d004a                                           // 000000919E18: D73D004A
	v_cndmask_b32_e32 v1, v62, v74, vcc_lo                     // 000000919E1C: 0202953E
	v_dot2acc_f32_f16 v36, v72, v12                            // 000000919E20: 04481948
	s_waitcnt lgkmcnt(0)                                       // 000000919E24: BF89FC07
	.long 0xd73d004f                                           // 000000919E28: D73D004F
	v_cndmask_b32_e32 v1, v63, v79, vcc_lo                     // 000000919E2C: 02029F3F
	v_dot2acc_f32_f16 v38, v72, v16                            // 000000919E30: 044C2148
	v_dot2acc_f32_f16 v39, v72, v20                            // 000000919E34: 044E2948
	v_bfe_u32 v75, v74, 9, 16                                  // 000000919E38: D610004B 0241134A
	v_and_b32_e32 v77, 0xffff, v74                             // 000000919E40: 369A94FF 0000FFFF
	v_bfe_u32 v80, v74, 6, 16                                  // 000000919E48: D6100050 02410D4A
	v_bfe_u32 v74, v74, 3, 16                                  // 000000919E50: D610004A 0241074A
	v_bfe_u32 v82, v79, 9, 16                                  // 000000919E58: D6100052 0241134F
	.long 0xd72c004b                                           // 000000919E60: D72C004B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v75, vcc_lo              // 000000919E64: 020296FF 83DCD12D
	.long 0xd72c004d                                           // 000000919E6C: D72C004D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v77, vcc_lo              // 000000919E70: 02029AFF 83DCD12D
	.long 0xd72c0050                                           // 000000919E78: D72C0050
	v_cndmask_b32_e32 v1, 0x83dcd12d, v80, vcc_lo              // 000000919E7C: 0202A0FF 83DCD12D
	.long 0xd72c004a                                           // 000000919E84: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 000000919E88: 020294FF 83DCD12D
	.long 0xd72c0052                                           // 000000919E90: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 000000919E94: 0202A4FF 83DCD12D
	v_bfe_u32 v86, v79, 3, 16                                  // 000000919E9C: D6100056 0241074F
	v_sad_u8 v75, v75, 0, 0x6400                               // 000000919EA4: D622004B 03FD014B 00006400
	v_sad_u8 v77, v77, 0, 0x6400                               // 000000919EB0: D622004D 03FD014D 00006400
	v_sad_u8 v80, v80, 0, 0x6400                               // 000000919EBC: D6220050 03FD0150 00006400
	v_sad_u8 v74, v74, 0, 0x6400                               // 000000919EC8: D622004A 03FD014A 00006400
	v_sad_u8 v82, v82, 0, 0x6400                               // 000000919ED4: D6220052 03FD0152 00006400
	v_and_b32_e32 v75, 0xffff, v75                             // 000000919EE0: 369696FF 0000FFFF
	v_lshlrev_b32_e32 v77, 16, v77                             // 000000919EE8: 309A9A90
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000919EEC: BF870112
	v_lshl_or_b32 v75, v80, 16, v75                            // 000000919EF0: D656004B 052D2150
	v_and_or_b32 v74, 0xffff, v74, v77                         // 000000919EF8: D657004A 053694FF 0000FFFF
	v_and_b32_e32 v77, 0xffff, v82                             // 000000919F04: 369AA4FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000919F0C: BF870223
	v_pk_fma_f16 v75, v75, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000919F10: CC0E004B 0BFC074B 0000C931
	v_dot2acc_f32_f16 v37, v84, v6                             // 000000919F1C: 044A0D54
	v_pk_fma_f16 v82, v74, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000919F20: CC0E0052 0BFC074A 0000C931
	.long 0xd72c0054                                           // 000000919F2C: D72C0054
	v_cndmask_b32_e32 v1, 0x83dcd12d, v86, vcc_lo              // 000000919F30: 0202ACFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4)                            // 000000919F38: BF870004
	v_dot2acc_f32_f16 v40, v75, v9                             // 000000919F3C: 0450134B
	v_dot2acc_f32_f16 v35, v83, v20                            // 000000919F40: 04462953
	v_bfe_u32 v83, v79, 6, 16                                  // 000000919F44: D6100053 02410D4F
	v_dual_dot2acc_f32_f16 v42, v75, v13 :: v_dual_and_b32 v79, 0xffff, v79// 000000919F4C: CB241B4B 2A4E9EFF 0000FFFF
	v_dot2acc_f32_f16 v37, v85, v7                             // 000000919F58: 044A0F55
	v_sad_u8 v74, v84, 0, 0x6400                               // 000000919F5C: D622004A 03FD0154 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000919F68: BF870214
	.long 0xd72c0053                                           // 000000919F6C: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v83, vcc_lo              // 000000919F70: 0202A6FF 83DCD12D
	v_dot2acc_f32_f16 v42, v82, v14                            // 000000919F78: 04541D52
	.long 0xd72c004f                                           // 000000919F7C: D72C004F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v79, vcc_lo              // 000000919F80: 02029EFF 83DCD12D
	v_dual_dot2acc_f32_f16 v40, v82, v10 :: v_dual_dot2acc_f32_f16 v43, v75, v17// 000000919F88: CB181552 282A234B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000919F90: BF870114
	v_sad_u8 v80, v83, 0, 0x6400                               // 000000919F94: D6220050 03FD0153 00006400
	v_dot2acc_f32_f16 v43, v82, v18                            // 000000919FA0: 04562552
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000919FA4: BF870194
	v_sad_u8 v79, v79, 0, 0x6400                               // 000000919FA8: D622004F 03FD014F 00006400
	v_lshl_or_b32 v77, v80, 16, v77                            // 000000919FB4: D656004D 05352150
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000919FBC: BF870112
	v_lshlrev_b32_e32 v79, 16, v79                             // 000000919FC0: 309E9E90
	v_pk_fma_f16 v83, v77, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000919FC4: CC0E0053 0BFC074D 0000C931
	v_dot2acc_f32_f16 v37, v72, v8                             // 000000919FD0: 044A1148
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000919FD4: BF870193
	v_and_or_b32 v74, 0xffff, v74, v79                         // 000000919FD8: D657004A 053E94FF 0000FFFF
	v_dual_mov_b32 v79, v81 :: v_dual_dot2acc_f32_f16 v40, v83, v11// 000000919FE4: CA180151 4F281753
	v_dot2acc_f32_f16 v42, v83, v15                            // 000000919FEC: 04541F53
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000919FF0: BF870123
	v_pk_fma_f16 v84, v74, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000919FF4: CC0E0054 0BFC074A 0000C931
	v_mov_b32_e32 v74, v76                                     // 00000091A000: 7E94034C
	v_dot2acc_f32_f16 v40, v84, v12                            // 00000091A004: 04501954
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000091A008: BF8701B2
	.long 0xd73d0048                                           // 00000091A00C: D73D0048
	v_cndmask_b32_e32 v1, v62, v73, vcc_lo                     // 00000091A010: 0202933E
	.long 0xd73d0049                                           // 00000091A014: D73D0049
	v_cndmask_b32_e32 v1, v63, v78, vcc_lo                     // 00000091A018: 02029D3F
	v_dot2acc_f32_f16 v42, v84, v16                            // 00000091A01C: 04542154
	v_and_b32_e32 v76, 0xffff, v72                             // 00000091A020: 369890FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3)                            // 00000091A028: BF870003
	v_bfe_u32 v77, v73, 9, 16                                  // 00000091A02C: D610004D 02411349
	v_bfe_u32 v78, v73, 6, 16                                  // 00000091A034: D610004E 02410D49
	v_bfe_u32 v79, v73, 3, 16                                  // 00000091A03C: D610004F 02410749
	v_and_b32_e32 v73, 0xffff, v73                             // 00000091A044: 369292FF 0000FFFF
	.long 0xd72c004c                                           // 00000091A04C: D72C004C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v76, vcc_lo              // 00000091A050: 020298FF 83DCD12D
	.long 0xd72c004d                                           // 00000091A058: D72C004D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v77, vcc_lo              // 00000091A05C: 02029AFF 83DCD12D
	.long 0xd72c004e                                           // 00000091A064: D72C004E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 00000091A068: 02029CFF 83DCD12D
	.long 0xd72c004f                                           // 00000091A070: D72C004F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v79, vcc_lo              // 00000091A074: 02029EFF 83DCD12D
	.long 0xd72c0050                                           // 00000091A07C: D72C0050
	v_cndmask_b32_e32 v1, 0x83dcd12d, v73, vcc_lo              // 00000091A080: 020292FF 83DCD12D
	v_sad_u8 v76, v76, 0, 0x6400                               // 00000091A088: D622004C 03FD014C 00006400
	v_dot2acc_f32_f16 v41, v75, v5                             // 00000091A094: 04520B4B
	v_bfe_u32 v75, v72, 9, 16                                  // 00000091A098: D610004B 02411348
	v_sad_u8 v77, v77, 0, 0x6400                               // 00000091A0A0: D622004D 03FD014D 00006400
	v_sad_u8 v78, v78, 0, 0x6400                               // 00000091A0AC: D622004E 03FD014E 00006400
	v_lshlrev_b32_e32 v76, 16, v76                             // 00000091A0B8: 30989890
	v_sad_u8 v79, v79, 0, 0x6400                               // 00000091A0BC: D622004F 03FD014F 00006400
	.long 0xd72c004a                                           // 00000091A0C8: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v75, vcc_lo              // 00000091A0CC: 020296FF 83DCD12D
	v_bfe_u32 v75, v72, 6, 16                                  // 00000091A0D4: D610004B 02410D48
	v_bfe_u32 v72, v72, 3, 16                                  // 00000091A0DC: D6100048 02410748
	v_and_b32_e32 v77, 0xffff, v77                             // 00000091A0E4: 369A9AFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000091A0EC: BF870193
	.long 0xd72c004b                                           // 00000091A0F0: D72C004B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v75, vcc_lo              // 00000091A0F4: 020296FF 83DCD12D
	.long 0xd72c0048                                           // 00000091A0FC: D72C0048
	v_cndmask_b32_e32 v1, 0x83dcd12d, v72, vcc_lo              // 00000091A100: 020290FF 83DCD12D
	v_sad_u8 v74, v74, 0, 0x6400                               // 00000091A108: D622004A 03FD014A 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 00000091A114: BF870154
	v_lshl_or_b32 v86, v78, 16, v77                            // 00000091A118: D6560056 0535214E
	ds_load_2addr_b32 v[77:78], v71 offset0:144 offset1:168    // 00000091A120: D8DCA890 4D000047
	v_and_b32_e32 v74, 0xffff, v74                             // 00000091A128: 369494FF 0000FFFF
	v_sad_u8 v75, v75, 0, 0x6400                               // 00000091A130: D622004B 03FD014B 00006400
	v_sad_u8 v72, v72, 0, 0x6400                               // 00000091A13C: D6220048 03FD0148 00006400
	v_lshl_or_b32 v74, v75, 16, v74                            // 00000091A148: D656004A 0529214B
	s_delay_alu instid0(VALU_DEP_2)                            // 00000091A150: BF870002
	v_and_or_b32 v81, 0xffff, v72, v76                         // 00000091A154: D6570051 053290FF 0000FFFF
	ds_load_2addr_b32 v[72:73], v69 offset0:144 offset1:168    // 00000091A160: D8DCA890 48000045
	ds_load_2addr_b32 v[75:76], v68 offset0:144 offset1:168    // 00000091A168: D8DCA890 4B000044
	v_dot2acc_f32_f16 v41, v82, v6                             // 00000091A170: 04520D52
	v_pk_fma_f16 v82, v74, s3, 0xc931 op_sel_hi:[1,0,0]        // 00000091A174: CC0E0052 0BFC074A 0000C931
	v_sad_u8 v74, v80, 0, 0x6400                               // 00000091A180: D622004A 03FD0150 00006400
	v_pk_fma_f16 v85, v81, s3, 0xc931 op_sel_hi:[1,0,0]        // 00000091A18C: CC0E0055 0BFC0751 0000C931
	ds_load_2addr_b32 v[80:81], v70 offset0:144 offset1:168    // 00000091A198: D8DCA890 50000046
	v_dot2acc_f32_f16 v44, v82, v9                             // 00000091A1A0: 04581352
	v_dual_dot2acc_f32_f16 v45, v82, v5 :: v_dual_lshlrev_b32 v74, 16, v74// 00000091A1A4: CB220B52 2D4A9490
	v_dot2acc_f32_f16 v46, v82, v13                            // 00000091A1AC: 045C1B52
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000091A1B0: BF870193
	v_dual_dot2acc_f32_f16 v47, v82, v17 :: v_dual_dot2acc_f32_f16 v44, v85, v10// 00000091A1B4: CB182352 2F2C1555
	v_and_or_b32 v79, 0xffff, v79, v74                         // 00000091A1BC: D657004F 052A9EFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000091A1C8: BF8701A3
	v_dot2acc_f32_f16 v46, v85, v14                            // 00000091A1CC: 045C1D55
	s_waitcnt lgkmcnt(2)                                       // 00000091A1D0: BF89FC27
	v_dual_dot2acc_f32_f16 v47, v85, v18 :: v_dual_mov_b32 v74, v72// 00000091A1D4: CB102555 2F4A0148
	s_delay_alu instid0(VALU_DEP_3)                            // 00000091A1DC: BF870003
	v_pk_fma_f16 v72, v79, s3, 0xc931 op_sel_hi:[1,0,0]        // 00000091A1E0: CC0E0048 0BFC074F 0000C931
	v_mov_b32_e32 v79, v77                                     // 00000091A1EC: 7E9E034D
	v_dot2acc_f32_f16 v41, v83, v7                             // 00000091A1F0: 04520F53
	s_waitcnt lgkmcnt(1)                                       // 00000091A1F4: BF89FC17
	.long 0xd73d004a                                           // 00000091A1F8: D73D004A
	v_cndmask_b32_e32 v1, v62, v74, vcc_lo                     // 00000091A1FC: 0202953E
	s_waitcnt lgkmcnt(0)                                       // 00000091A200: BF89FC07
	.long 0xd73d004f                                           // 00000091A204: D73D004F
	v_cndmask_b32_e32 v1, v63, v79, vcc_lo                     // 00000091A208: 02029F3F
	s_delay_alu instid0(VALU_DEP_2)                            // 00000091A20C: BF870002
	v_bfe_u32 v75, v74, 9, 16                                  // 00000091A210: D610004B 0241134A
	v_and_b32_e32 v77, 0xffff, v74                             // 00000091A218: 369A94FF 0000FFFF
	v_bfe_u32 v80, v74, 6, 16                                  // 00000091A220: D6100050 02410D4A
	v_bfe_u32 v74, v74, 3, 16                                  // 00000091A228: D610004A 0241074A
	v_bfe_u32 v82, v79, 9, 16                                  // 00000091A230: D6100052 0241134F
	.long 0xd72c004b                                           // 00000091A238: D72C004B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v75, vcc_lo              // 00000091A23C: 020296FF 83DCD12D
	.long 0xd72c004d                                           // 00000091A244: D72C004D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v77, vcc_lo              // 00000091A248: 02029AFF 83DCD12D
	.long 0xd72c0050                                           // 00000091A250: D72C0050
	v_cndmask_b32_e32 v1, 0x83dcd12d, v80, vcc_lo              // 00000091A254: 0202A0FF 83DCD12D
	.long 0xd72c004a                                           // 00000091A25C: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 00000091A260: 020294FF 83DCD12D
	.long 0xd72c0052                                           // 00000091A268: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 00000091A26C: 0202A4FF 83DCD12D
	v_sad_u8 v75, v75, 0, 0x6400                               // 00000091A274: D622004B 03FD014B 00006400
	v_sad_u8 v77, v77, 0, 0x6400                               // 00000091A280: D622004D 03FD014D 00006400
	v_sad_u8 v80, v80, 0, 0x6400                               // 00000091A28C: D6220050 03FD0150 00006400
	v_sad_u8 v74, v74, 0, 0x6400                               // 00000091A298: D622004A 03FD014A 00006400
	v_sad_u8 v82, v82, 0, 0x6400                               // 00000091A2A4: D6220052 03FD0152 00006400
	v_and_b32_e32 v75, 0xffff, v75                             // 00000091A2B0: 369696FF 0000FFFF
	v_lshlrev_b32_e32 v77, 16, v77                             // 00000091A2B8: 309A9A90
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000091A2BC: BF870112
	v_lshl_or_b32 v75, v80, 16, v75                            // 00000091A2C0: D656004B 052D2150
	v_and_or_b32 v74, 0xffff, v74, v77                         // 00000091A2C8: D657004A 053694FF 0000FFFF
	v_and_b32_e32 v77, 0xffff, v82                             // 00000091A2D4: 369AA4FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000091A2DC: BF870223
	v_pk_fma_f16 v75, v75, s3, 0xc931 op_sel_hi:[1,0,0]        // 00000091A2E0: CC0E004B 0BFC074B 0000C931
	v_dot2acc_f32_f16 v45, v85, v6                             // 00000091A2EC: 045A0D55
	v_pk_fma_f16 v82, v74, s3, 0xc931 op_sel_hi:[1,0,0]        // 00000091A2F0: CC0E0052 0BFC074A 0000C931
	s_delay_alu instid0(VALU_DEP_3)                            // 00000091A2FC: BF870003
	v_dot2acc_f32_f16 v48, v75, v9                             // 00000091A300: 0460134B
	v_dot2acc_f32_f16 v50, v75, v13                            // 00000091A304: 04641B4B
	v_dot2acc_f32_f16 v43, v83, v19                            // 00000091A308: 04562753
	v_pk_fma_f16 v83, v86, s3, 0xc931 op_sel_hi:[1,0,0]        // 00000091A30C: CC0E0053 0BFC0756 0000C931
	v_dot2acc_f32_f16 v41, v84, v8                             // 00000091A318: 04521154
	v_bfe_u32 v86, v79, 3, 16                                  // 00000091A31C: D6100056 0241074F
	v_dot2acc_f32_f16 v48, v82, v10                            // 00000091A324: 04601552
	v_dual_dot2acc_f32_f16 v50, v82, v14 :: v_dual_dot2acc_f32_f16 v43, v84, v20// 00000091A328: CB181D52 322A2954
	v_bfe_u32 v84, v79, 6, 16                                  // 00000091A330: D6100054 02410D4F
	v_and_b32_e32 v79, 0xffff, v79                             // 00000091A338: 369E9EFF 0000FFFF
	.long 0xd72c0055                                           // 00000091A340: D72C0055
	v_cndmask_b32_e32 v1, 0x83dcd12d, v86, vcc_lo              // 00000091A344: 0202ACFF 83DCD12D
	v_dot2acc_f32_f16 v44, v83, v11                            // 00000091A34C: 04581753
	v_dot2acc_f32_f16 v46, v83, v15                            // 00000091A350: 045C1F53
	.long 0xd72c0054                                           // 00000091A354: D72C0054
	v_cndmask_b32_e32 v1, 0x83dcd12d, v84, vcc_lo              // 00000091A358: 0202A8FF 83DCD12D
	.long 0xd72c004f                                           // 00000091A360: D72C004F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v79, vcc_lo              // 00000091A364: 02029EFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000091A36C: BF870214
	v_dual_dot2acc_f32_f16 v47, v83, v19 :: v_dual_dot2acc_f32_f16 v44, v72, v12// 00000091A370: CB182753 2F2C1948
	v_dot2acc_f32_f16 v46, v72, v16                            // 00000091A378: 045C2148
	v_sad_u8 v74, v85, 0, 0x6400                               // 00000091A37C: D622004A 03FD0155 00006400
	v_dot2acc_f32_f16 v51, v75, v17                            // 00000091A388: 0466234B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000091A38C: BF870134
	v_dot2acc_f32_f16 v47, v72, v20                            // 00000091A390: 045E2948
	v_sad_u8 v80, v84, 0, 0x6400                               // 00000091A394: D6220050 03FD0154 00006400
	v_sad_u8 v79, v79, 0, 0x6400                               // 00000091A3A0: D622004F 03FD014F 00006400
	v_lshl_or_b32 v77, v80, 16, v77                            // 00000091A3AC: D656004D 05352150
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000091A3B4: BF870112
	v_lshlrev_b32_e32 v79, 16, v79                             // 00000091A3B8: 309E9E90
	v_pk_fma_f16 v77, v77, s3, 0xc931 op_sel_hi:[1,0,0]        // 00000091A3BC: CC0E004D 0BFC074D 0000C931
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000091A3C8: BF8701A2
	v_and_or_b32 v74, 0xffff, v74, v79                         // 00000091A3CC: D657004A 053E94FF 0000FFFF
	v_mov_b32_e32 v79, v81                                     // 00000091A3D8: 7E9E0351
	v_dot2acc_f32_f16 v48, v77, v11                            // 00000091A3DC: 0460174D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000091A3E0: BF8701B3
	v_pk_fma_f16 v80, v74, s3, 0xc931 op_sel_hi:[1,0,0]        // 00000091A3E4: CC0E0050 0BFC074A 0000C931
	v_dual_dot2acc_f32_f16 v45, v83, v7 :: v_dual_mov_b32 v74, v76// 00000091A3F0: CB100F53 2D4A014C
	v_dot2acc_f32_f16 v50, v77, v15                            // 00000091A3F8: 04641F4D
	v_dot2acc_f32_f16 v48, v80, v12                            // 00000091A3FC: 04601950
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000091A400: BF870213
	v_dot2acc_f32_f16 v45, v72, v8                             // 00000091A404: 045A1148
	.long 0xd73d0048                                           // 00000091A408: D73D0048
	v_cndmask_b32_e32 v1, v62, v73, vcc_lo                     // 00000091A40C: 0202933E
	.long 0xd73d0049                                           // 00000091A410: D73D0049
	v_cndmask_b32_e32 v1, v63, v78, vcc_lo                     // 00000091A414: 02029D3F
	v_dot2acc_f32_f16 v50, v80, v16                            // 00000091A418: 04642150
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000091A41C: BF870193
	v_and_b32_e32 v76, 0xffff, v72                             // 00000091A420: 369890FF 0000FFFF
	v_bfe_u32 v78, v73, 9, 16                                  // 00000091A428: D610004E 02411349
	v_bfe_u32 v79, v73, 6, 16                                  // 00000091A430: D610004F 02410D49
	v_bfe_u32 v81, v73, 3, 16                                  // 00000091A438: D6100051 02410749
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000091A440: BF870214
	.long 0xd72c004c                                           // 00000091A444: D72C004C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v76, vcc_lo              // 00000091A448: 020298FF 83DCD12D
	.long 0xd72c004e                                           // 00000091A450: D72C004E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 00000091A454: 02029CFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000091A45C: BF870194
	.long 0xd72c004f                                           // 00000091A460: D72C004F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v79, vcc_lo              // 00000091A464: 02029EFF 83DCD12D
	v_sad_u8 v76, v76, 0, 0x6400                               // 00000091A46C: D622004C 03FD014C 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 00000091A478: BF870243
	v_sad_u8 v78, v78, 0, 0x6400                               // 00000091A47C: D622004E 03FD014E 00006400
	v_dot2acc_f32_f16 v49, v75, v5                             // 00000091A488: 04620B4B
	v_bfe_u32 v75, v72, 9, 16                                  // 00000091A48C: D610004B 02411348
	v_sad_u8 v79, v79, 0, 0x6400                               // 00000091A494: D622004F 03FD014F 00006400
	v_and_b32_e32 v78, 0xffff, v78                             // 00000091A4A0: 369C9CFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000091A4A8: BF870133
	.long 0xd72c004a                                           // 00000091A4AC: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v75, vcc_lo              // 00000091A4B0: 020296FF 83DCD12D
	v_bfe_u32 v75, v72, 6, 16                                  // 00000091A4B8: D610004B 02410D48
	v_bfe_u32 v72, v72, 3, 16                                  // 00000091A4C0: D6100048 02410748
	.long 0xd72c004b                                           // 00000091A4C8: D72C004B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v75, vcc_lo              // 00000091A4CC: 020296FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000091A4D4: BF8700A2
	.long 0xd72c0048                                           // 00000091A4D8: D72C0048
	v_cndmask_b32_e32 v1, 0x83dcd12d, v72, vcc_lo              // 00000091A4DC: 020290FF 83DCD12D
	v_sad_u8 v74, v74, 0, 0x6400                               // 00000091A4E4: D622004A 03FD014A 00006400
	v_and_b32_e32 v74, 0xffff, v74                             // 00000091A4F0: 369494FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000091A4F8: BF870214
	v_sad_u8 v75, v75, 0, 0x6400                               // 00000091A4FC: D622004B 03FD014B 00006400
	v_sad_u8 v72, v72, 0, 0x6400                               // 00000091A508: D6220048 03FD0148 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000091A514: BF8701B2
	v_lshl_or_b32 v74, v75, 16, v74                            // 00000091A518: D656004A 0529214B
	v_lshlrev_b32_e32 v75, 16, v76                             // 00000091A520: 30969890
	.long 0xd72c004c                                           // 00000091A524: D72C004C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v81, vcc_lo              // 00000091A528: 0202A2FF 83DCD12D
	v_pk_fma_f16 v74, v74, s3, 0xc931 op_sel_hi:[1,0,0]        // 00000091A530: CC0E004A 0BFC074A 0000C931
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000091A53C: BF8701A3
	v_and_or_b32 v72, 0xffff, v72, v75                         // 00000091A540: D6570048 052E90FF 0000FFFF
	v_lshl_or_b32 v75, v79, 16, v78                            // 00000091A54C: D656004B 0539214F
	v_dot2acc_f32_f16 v54, v74, v13                            // 00000091A554: 046C1B4A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000091A558: BF870193
	v_pk_fma_f16 v72, v72, s3, 0xc931 op_sel_hi:[1,0,0]        // 00000091A55C: CC0E0048 0BFC0748 0000C931
	v_pk_fma_f16 v75, v75, s3, 0xc931 op_sel_hi:[1,0,0]        // 00000091A568: CC0E004B 0BFC074B 0000C931
	v_dot2acc_f32_f16 v24, v74, v17                            // 00000091A574: 0430234A
	v_sad_u8 v76, v76, 0, 0x6400                               // 00000091A578: D622004C 03FD014C 00006400
	v_dot2acc_f32_f16 v52, v74, v9                             // 00000091A584: 0468134A
	v_dot2acc_f32_f16 v54, v72, v14                            // 00000091A588: 046C1D48
	v_dot2acc_f32_f16 v49, v82, v6                             // 00000091A58C: 04620D52
	v_dual_dot2acc_f32_f16 v24, v72, v18 :: v_dual_dot2acc_f32_f16 v53, v74, v5// 00000091A590: CB182548 18340B4A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000091A598: BF870214
	v_dot2acc_f32_f16 v52, v72, v10                            // 00000091A59C: 04681548
	v_dot2acc_f32_f16 v54, v75, v15                            // 00000091A5A0: 046C1F4B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000091A5A4: BF870214
	v_dot2acc_f32_f16 v49, v77, v7                             // 00000091A5A8: 04620F4D
	v_dual_dot2acc_f32_f16 v24, v75, v19 :: v_dual_and_b32 v73, 0xffff, v73// 00000091A5AC: CB24274B 184892FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000091A5B8: BF870194
	v_dual_dot2acc_f32_f16 v52, v75, v11 :: v_dual_dot2acc_f32_f16 v53, v72, v6// 00000091A5BC: CB18174B 34340D48
	v_dual_dot2acc_f32_f16 v49, v80, v8 :: v_dual_add_nc_u32 v6, v65, v66// 00000091A5C4: CB201150 31068541
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000091A5CC: BF870193
	.long 0xd72c0049                                           // 00000091A5D0: D72C0049
	v_cndmask_b32_e32 v1, 0x83dcd12d, v73, vcc_lo              // 00000091A5D4: 020292FF 83DCD12D
	v_dot2acc_f32_f16 v53, v75, v7                             // 00000091A5DC: 046A0F4B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000091A5E0: BF870193
	v_cmp_eq_u32_e32 vcc_lo, 6, v6                             // 00000091A5E4: 7C940C86
	v_sad_u8 v73, v73, 0, 0x6400                               // 00000091A5E8: D6220049 03FD0149 00006400
	s_or_b32 s2, vcc_lo, s2                                    // 00000091A5F4: 8C02026A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000091A5F8: BF870091
	v_lshlrev_b32_e32 v73, 16, v73                             // 00000091A5FC: 30929290
	v_and_or_b32 v9, 0xffff, v76, v73                          // 00000091A600: D6570009 052698FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000091A60C: BF870091
	v_pk_fma_f16 v5, v9, s3, 0xc931 op_sel_hi:[1,0,0]          // 00000091A610: CC0E0005 0BFC0709 0000C931
	v_dual_dot2acc_f32_f16 v52, v5, v12 :: v_dual_dot2acc_f32_f16 v51, v82, v18// 00000091A61C: CB181905 34322552
	v_dot2acc_f32_f16 v54, v5, v16                             // 00000091A624: 046C2105
	v_dot2acc_f32_f16 v53, v5, v8                              // 00000091A628: 046A1105
	v_dot2acc_f32_f16 v24, v5, v20                             // 00000091A62C: 04302905
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000091A630: BF870094
	v_dot2acc_f32_f16 v51, v77, v19                            // 00000091A634: 0466274D
	v_dot2acc_f32_f16 v51, v80, v20                            // 00000091A638: 04662950
	s_and_not1_b32 exec_lo, exec_lo, s2                        // 00000091A63C: 917E027E
	s_cbranch_execz 27                                         // 00000091A640: BFA5001B <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi4ELi2EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0x3bb0>
	s_mov_b32 s0, exec_lo                                      // 00000091A644: BE80007E
	s_waitcnt vmcnt(4)                                         // 00000091A648: BF8913F7
	ds_store_2addr_b32 v67, v56, v57 offset1:32                // 00000091A64C: D8382000 00393843
	s_waitcnt vmcnt(2)                                         // 00000091A654: BF890BF7
	ds_store_2addr_b32 v67, v58, v59 offset0:64 offset1:96     // 00000091A658: D8386040 003B3A43
	s_waitcnt vmcnt(0)                                         // 00000091A660: BF8903F7
	ds_store_2addr_b32 v67, v60, v61 offset0:128 offset1:160   // 00000091A664: D838A080 003D3C43
	.long 0xd4c9007e                                           // 00000091A66C: D4C9007E
	v_cndmask_b32_e32 v1, v66, v55, vcc_lo                     // 00000091A670: 02026F42
	s_cbranch_execz 64468                                      // 00000091A674: BFA5FBD4 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi4ELi2EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0x2ac8>
	s_clause 0x5                                               // 00000091A678: BF850005
	global_load_b32 v56, v[1:2], off                           // 00000091A67C: DC520000 387C0001
	global_load_b32 v57, v[1:2], off offset:128                // 00000091A684: DC520080 397C0001
	global_load_b32 v58, v[1:2], off offset:256                // 00000091A68C: DC520100 3A7C0001
	global_load_b32 v59, v[1:2], off offset:384                // 00000091A694: DC520180 3B7C0001
	global_load_b32 v60, v[1:2], off offset:512                // 00000091A69C: DC520200 3C7C0001
	global_load_b32 v61, v[1:2], off offset:640                // 00000091A6A4: DC520280 3D7C0001
	s_branch 64454                                             // 00000091A6AC: BFA0FBC6 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi4ELi2EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0x2ac8>
	s_or_b32 exec_lo, exec_lo, s2                              // 00000091A6B0: 8C7E027E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000091A6B4: BF870099
	s_or_b32 exec_lo, exec_lo, s1                              // 00000091A6B8: 8C7E017E
	v_dual_mov_b32 v1, v23 :: v_dual_mov_b32 v6, v28           // 00000091A6BC: CA100117 0106011C
	v_dual_mov_b32 v2, v27 :: v_dual_mov_b32 v5, v26           // 00000091A6C4: CA10011B 0204011A
	v_dual_mov_b32 v7, v29 :: v_dual_mov_b32 v8, v30           // 00000091A6CC: CA10011D 0708011E
	v_dual_mov_b32 v10, v31 :: v_dual_mov_b32 v11, v32         // 00000091A6D4: CA10011F 0A0A0120
	v_dual_mov_b32 v9, v25 :: v_dual_mov_b32 v14, v35          // 00000091A6DC: CA100119 090E0123
	v_dual_mov_b32 v12, v33 :: v_dual_mov_b32 v13, v34         // 00000091A6E4: CA100121 0C0C0122
	v_dual_mov_b32 v15, v36 :: v_dual_mov_b32 v16, v37         // 00000091A6EC: CA100124 0F100125
	v_dual_mov_b32 v17, v38 :: v_dual_mov_b32 v18, v39         // 00000091A6F4: CA100126 11120127
	v_dual_mov_b32 v19, v40 :: v_dual_mov_b32 v20, v41         // 00000091A6FC: CA100128 13140129
	s_waitcnt vmcnt(5)                                         // 00000091A704: BF8917F7
	v_dual_mov_b32 v55, v42 :: v_dual_mov_b32 v56, v43         // 00000091A708: CA10012A 3738012B
	s_waitcnt vmcnt(3)                                         // 00000091A710: BF890FF7
	v_dual_mov_b32 v57, v44 :: v_dual_mov_b32 v58, v45         // 00000091A714: CA10012C 393A012D
	s_waitcnt vmcnt(1)                                         // 00000091A71C: BF8907F7
	v_dual_mov_b32 v59, v46 :: v_dual_mov_b32 v60, v47         // 00000091A720: CA10012E 3B3C012F
	s_waitcnt vmcnt(0)                                         // 00000091A728: BF8903F7
	v_dual_mov_b32 v61, v48 :: v_dual_mov_b32 v62, v49         // 00000091A72C: CA100130 3D3E0131
	v_dual_mov_b32 v63, v50 :: v_dual_mov_b32 v64, v51         // 00000091A734: CA100132 3F400133
	v_dual_mov_b32 v65, v52 :: v_dual_mov_b32 v66, v53         // 00000091A73C: CA100134 41420135
	v_dual_mov_b32 v67, v54 :: v_dual_mov_b32 v68, v24         // 00000091A744: CA100136 43440118
	s_mov_b32 s0, 0x76543210                                   // 00000091A74C: BE8000FF 76543210
	v_cmp_gt_u32_e32 vcc_lo, 16, v22                           // 00000091A754: 7C982C90
	v_permlanex16_b32 v1, v1, s0, 0xfedcba98                   // 00000091A758: D65C0001 03FC0101 FEDCBA98
	v_permlanex16_b32 v2, v2, s0, 0xfedcba98                   // 00000091A764: D65C0002 03FC0102 FEDCBA98
	v_permlanex16_b32 v6, v6, s0, 0xfedcba98                   // 00000091A770: D65C0006 03FC0106 FEDCBA98
	v_permlanex16_b32 v5, v5, s0, 0xfedcba98                   // 00000091A77C: D65C0005 03FC0105 FEDCBA98
	v_permlanex16_b32 v7, v7, s0, 0xfedcba98                   // 00000091A788: D65C0007 03FC0107 FEDCBA98
	v_permlanex16_b32 v8, v8, s0, 0xfedcba98                   // 00000091A794: D65C0008 03FC0108 FEDCBA98
	v_permlanex16_b32 v10, v10, s0, 0xfedcba98                 // 00000091A7A0: D65C000A 03FC010A FEDCBA98
	v_permlanex16_b32 v11, v11, s0, 0xfedcba98                 // 00000091A7AC: D65C000B 03FC010B FEDCBA98
	v_permlanex16_b32 v9, v9, s0, 0xfedcba98                   // 00000091A7B8: D65C0009 03FC0109 FEDCBA98
	v_permlanex16_b32 v12, v12, s0, 0xfedcba98                 // 00000091A7C4: D65C000C 03FC010C FEDCBA98
	v_permlanex16_b32 v13, v13, s0, 0xfedcba98                 // 00000091A7D0: D65C000D 03FC010D FEDCBA98
	v_permlanex16_b32 v14, v14, s0, 0xfedcba98                 // 00000091A7DC: D65C000E 03FC010E FEDCBA98
	v_permlanex16_b32 v15, v15, s0, 0xfedcba98                 // 00000091A7E8: D65C000F 03FC010F FEDCBA98
	v_permlanex16_b32 v16, v16, s0, 0xfedcba98                 // 00000091A7F4: D65C0010 03FC0110 FEDCBA98
	v_permlanex16_b32 v17, v17, s0, 0xfedcba98                 // 00000091A800: D65C0011 03FC0111 FEDCBA98
	v_permlanex16_b32 v18, v18, s0, 0xfedcba98                 // 00000091A80C: D65C0012 03FC0112 FEDCBA98
	v_permlanex16_b32 v19, v19, s0, 0xfedcba98                 // 00000091A818: D65C0013 03FC0113 FEDCBA98
	v_permlanex16_b32 v20, v20, s0, 0xfedcba98                 // 00000091A824: D65C0014 03FC0114 FEDCBA98
	v_permlanex16_b32 v55, v55, s0, 0xfedcba98                 // 00000091A830: D65C0037 03FC0137 FEDCBA98
	v_permlanex16_b32 v56, v56, s0, 0xfedcba98                 // 00000091A83C: D65C0038 03FC0138 FEDCBA98
	v_permlanex16_b32 v57, v57, s0, 0xfedcba98                 // 00000091A848: D65C0039 03FC0139 FEDCBA98
	v_permlanex16_b32 v58, v58, s0, 0xfedcba98                 // 00000091A854: D65C003A 03FC013A FEDCBA98
	v_permlanex16_b32 v59, v59, s0, 0xfedcba98                 // 00000091A860: D65C003B 03FC013B FEDCBA98
	v_permlanex16_b32 v60, v60, s0, 0xfedcba98                 // 00000091A86C: D65C003C 03FC013C FEDCBA98
	v_permlanex16_b32 v61, v61, s0, 0xfedcba98                 // 00000091A878: D65C003D 03FC013D FEDCBA98
	v_permlanex16_b32 v62, v62, s0, 0xfedcba98                 // 00000091A884: D65C003E 03FC013E FEDCBA98
	v_permlanex16_b32 v63, v63, s0, 0xfedcba98                 // 00000091A890: D65C003F 03FC013F FEDCBA98
	v_permlanex16_b32 v64, v64, s0, 0xfedcba98                 // 00000091A89C: D65C0040 03FC0140 FEDCBA98
	v_permlanex16_b32 v65, v65, s0, 0xfedcba98                 // 00000091A8A8: D65C0041 03FC0141 FEDCBA98
	v_permlanex16_b32 v66, v66, s0, 0xfedcba98                 // 00000091A8B4: D65C0042 03FC0142 FEDCBA98
	v_permlanex16_b32 v67, v67, s0, 0xfedcba98                 // 00000091A8C0: D65C0043 03FC0143 FEDCBA98
	v_permlanex16_b32 v68, v68, s0, 0xfedcba98                 // 00000091A8CC: D65C0044 03FC0144 FEDCBA98
	s_barrier                                                  // 00000091A8D8: BFBD0000
	buffer_gl0_inv                                             // 00000091A8DC: E0AC0000 00000000
	s_and_saveexec_b32 s0, vcc_lo                              // 00000091A8E4: BE80206A
	s_cbranch_execz 72                                         // 00000091A8E8: BFA50048 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi4ELi2EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0x3f0c>
	v_dual_add_f32 v18, v39, v18 :: v_dual_add_f32 v17, v38, v17// 00000091A8EC: C9082527 12102326
	v_dual_add_f32 v15, v36, v15 :: v_dual_lshlrev_b32 v38, 6, v0// 00000091A8F4: C9221F24 0F260086
	v_dual_add_f32 v16, v37, v16 :: v_dual_add_f32 v13, v34, v13// 00000091A8FC: C9082125 100C1B22
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000091A904: BF8701B2
	v_dual_add_f32 v5, v26, v5 :: v_dual_and_b32 v34, 0x3800, v38// 00000091A908: C9240B1A 05224CFF 00003800
	v_dual_add_f32 v44, v44, v57 :: v_dual_add_f32 v7, v29, v7 // 00000091A914: C908732C 2C060F1D
	v_dual_add_f32 v42, v42, v55 :: v_dual_add_f32 v1, v23, v1 // 00000091A91C: C9086F2A 2A000317
	v_lshl_or_b32 v22, v22, 2, v34                             // 00000091A924: D6560016 04890516
	v_add_f32_e32 v8, v30, v8                                  // 00000091A92C: 0610111E
	v_add_f32_e32 v2, v27, v2                                  // 00000091A930: 0604051B
	v_add_f32_e32 v12, v33, v12                                // 00000091A934: 06181921
	v_dual_add_f32 v10, v31, v10 :: v_dual_add_f32 v9, v25, v9 // 00000091A938: C908151F 0A081319
	v_add_f32_e32 v6, v28, v6                                  // 00000091A940: 060C0D1C
	v_add_nc_u32_e32 v23, 0x400, v22                           // 00000091A944: 4A2E2CFF 00000400
	v_dual_add_f32 v14, v35, v14 :: v_dual_add_f32 v11, v32, v11// 00000091A94C: C9081D23 0E0A1720
	v_dual_add_f32 v24, v24, v68 :: v_dual_add_f32 v53, v53, v66// 00000091A954: C9088918 18348535
	v_dual_add_f32 v54, v54, v67 :: v_dual_add_f32 v51, v51, v64// 00000091A95C: C9088736 36328133
	v_dual_add_f32 v52, v52, v65 :: v_dual_add_f32 v49, v49, v62// 00000091A964: C9088334 34307D31
	v_dual_add_f32 v50, v50, v63 :: v_dual_add_f32 v47, v47, v60// 00000091A96C: C9087F32 322E792F
	v_dual_add_f32 v48, v48, v61 :: v_dual_add_f32 v45, v45, v58// 00000091A974: C9087B30 302C752D
	v_dual_add_f32 v46, v46, v59 :: v_dual_add_f32 v43, v43, v56// 00000091A97C: C908772E 2E2A712B
	v_dual_add_f32 v20, v41, v20 :: v_dual_add_f32 v19, v40, v19// 00000091A984: C9082929 14122728
	ds_store_2addr_b32 v22, v1, v7 offset1:16                  // 00000091A98C: D8381000 00070116
	ds_store_2addr_b32 v22, v2, v8 offset0:128 offset1:144     // 00000091A994: D8389080 00080216
	ds_store_2addr_b32 v23, v6, v10 offset1:16                 // 00000091A99C: D8381000 000A0617
	ds_store_2addr_b32 v23, v5, v11 offset0:128 offset1:144    // 00000091A9A4: D8389080 000B0517
	ds_store_2addr_b32 v22, v9, v15 offset0:32 offset1:48      // 00000091A9AC: D8383020 000F0916
	ds_store_2addr_b32 v22, v12, v16 offset0:160 offset1:176   // 00000091A9B4: D838B0A0 00100C16
	ds_store_2addr_b32 v23, v13, v17 offset0:32 offset1:48     // 00000091A9BC: D8383020 00110D17
	ds_store_2addr_b32 v23, v14, v18 offset0:160 offset1:176   // 00000091A9C4: D838B0A0 00120E17
	ds_store_2addr_b32 v22, v19, v44 offset0:64 offset1:80     // 00000091A9CC: D8385040 002C1316
	ds_store_2addr_b32 v22, v20, v45 offset0:192 offset1:208   // 00000091A9D4: D838D0C0 002D1416
	ds_store_2addr_b32 v23, v42, v46 offset0:64 offset1:80     // 00000091A9DC: D8385040 002E2A17
	ds_store_2addr_b32 v23, v43, v47 offset0:192 offset1:208   // 00000091A9E4: D838D0C0 002F2B17
	ds_store_2addr_b32 v22, v48, v52 offset0:96 offset1:112    // 00000091A9EC: D8387060 00343016
	ds_store_2addr_b32 v22, v49, v53 offset0:224 offset1:240   // 00000091A9F4: D838F0E0 00353116
	ds_store_2addr_b32 v23, v50, v54 offset0:96 offset1:112    // 00000091A9FC: D8387060 00363217
	ds_store_2addr_b32 v23, v51, v24 offset0:224 offset1:240   // 00000091AA04: D838F0E0 00183317
	s_or_b32 exec_lo, exec_lo, s0                              // 00000091AA0C: 8C7E007E
	v_sub_nc_u32_e32 v1, v4, v3                                // 00000091AA10: 4C020704
	s_waitcnt lgkmcnt(0)                                       // 00000091AA14: BF89FC07
	s_barrier                                                  // 00000091AA18: BFBD0000
	buffer_gl0_inv                                             // 00000091AA1C: E0AC0000 00000000
	s_mov_b32 s1, exec_lo                                      // 00000091AA24: BE81007E
	v_min_i32_e32 v1, 4, v1                                    // 00000091AA28: 22020284
	s_delay_alu instid0(VALU_DEP_1)                            // 00000091AA2C: BF870001
	.long 0xd4c1007e                                           // 00000091AA30: D4C1007E
	v_cndmask_b32_e32 v1, v21, v1, vcc_lo                      // 00000091AA34: 02020315
	s_cbranch_execz 536                                        // 00000091AA38: BFA50218 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi4ELi2EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0x479c>
	v_and_b32_e32 v1, 15, v0                                   // 00000091AA3C: 3602008F
	v_lshlrev_b32_e32 v2, 9, v21                               // 00000091AA40: 30042A89
	s_delay_alu instid0(VALU_DEP_1)                            // 00000091AA44: BF870001
	v_lshl_or_b32 v2, v1, 2, v2                                // 00000091AA48: D6560002 04090501
	ds_load_2addr_b32 v[6:7], v2 offset0:32 offset1:48         // 00000091AA50: D8DC3020 06000002
	ds_load_2addr_b32 v[4:5], v2 offset1:16                    // 00000091AA58: D8DC1000 04000002
	v_add_nc_u32_e32 v46, 0x1000, v2                           // 00000091AA60: 4A5C04FF 00001000
	v_add_nc_u32_e32 v47, 0x1800, v2                           // 00000091AA68: 4A5E04FF 00001800
	v_add_nc_u32_e32 v48, 0x2000, v2                           // 00000091AA70: 4A6004FF 00002000
	v_add_nc_u32_e32 v50, 0x3000, v2                           // 00000091AA78: 4A6404FF 00003000
	v_add_nc_u32_e32 v51, 0x3800, v2                           // 00000091AA80: 4A6604FF 00003800
	s_waitcnt lgkmcnt(1)                                       // 00000091AA88: BF89FC17
	v_dual_add_f32 v7, 0, v7 :: v_dual_add_nc_u32 v20, 0x800, v2// 00000091AA8C: C9200E80 071404FF 00000800
	s_waitcnt lgkmcnt(0)                                       // 00000091AA98: BF89FC07
	v_dual_add_f32 v44, 0, v5 :: v_dual_add_nc_u32 v49, 0x2800, v2// 00000091AA9C: C9200A80 2C3004FF 00002800
	ds_load_2addr_b32 v[8:9], v2 offset0:64 offset1:80         // 00000091AAA8: D8DC5040 08000002
	ds_load_2addr_b32 v[10:11], v20 offset1:16                 // 00000091AAB0: D8DC1000 0A000014
	ds_load_2addr_b32 v[12:13], v2 offset0:96 offset1:112      // 00000091AAB8: D8DC7060 0C000002
	ds_load_2addr_b32 v[14:15], v20 offset0:32 offset1:48      // 00000091AAC0: D8DC3020 0E000014
	ds_load_2addr_b32 v[16:17], v46 offset1:16                 // 00000091AAC8: D8DC1000 1000002E
	ds_load_2addr_b32 v[18:19], v47 offset1:16                 // 00000091AAD0: D8DC1000 1200002F
	ds_load_2addr_b32 v[22:23], v48 offset1:16                 // 00000091AAD8: D8DC1000 16000030
	ds_load_2addr_b32 v[24:25], v49 offset1:16                 // 00000091AAE0: D8DC1000 18000031
	ds_load_2addr_b32 v[26:27], v46 offset0:32 offset1:48      // 00000091AAE8: D8DC3020 1A00002E
	ds_load_2addr_b32 v[28:29], v50 offset1:16                 // 00000091AAF0: D8DC1000 1C000032
	ds_load_2addr_b32 v[30:31], v51 offset1:16                 // 00000091AAF8: D8DC1000 1E000033
	ds_load_2addr_b32 v[32:33], v47 offset0:32 offset1:48      // 00000091AB00: D8DC3020 2000002F
	ds_load_2addr_b32 v[34:35], v48 offset0:32 offset1:48      // 00000091AB08: D8DC3020 22000030
	ds_load_2addr_b32 v[36:37], v49 offset0:32 offset1:48      // 00000091AB10: D8DC3020 24000031
	ds_load_2addr_b32 v[38:39], v50 offset0:32 offset1:48      // 00000091AB18: D8DC3020 26000032
	ds_load_2addr_b32 v[40:41], v51 offset0:32 offset1:48      // 00000091AB20: D8DC3020 28000033
	v_add_f32_e32 v2, 0, v4                                    // 00000091AB28: 06040880
	v_add_f32_e32 v6, 0, v6                                    // 00000091AB2C: 060C0C80
	s_waitcnt lgkmcnt(15)                                      // 00000091AB30: BF89FCF7
	v_add_f32_e32 v8, 0, v8                                    // 00000091AB34: 06101080
	s_waitcnt lgkmcnt(14)                                      // 00000091AB38: BF89FCE7
	v_add_f32_e32 v2, v2, v10                                  // 00000091AB3C: 06041502
	v_add_f32_e32 v52, v44, v11                                // 00000091AB40: 0668172C
	s_waitcnt lgkmcnt(12)                                      // 00000091AB44: BF89FCC7
	v_add_f32_e32 v7, v7, v15                                  // 00000091AB48: 060E1F07
	ds_load_2addr_b32 v[10:11], v47 offset0:64 offset1:80      // 00000091AB4C: D8DC5040 0A00002F
	ds_load_2addr_b32 v[44:45], v20 offset0:96 offset1:112     // 00000091AB54: D8DC7060 2C000014
	v_add_f32_e32 v6, v6, v14                                  // 00000091AB5C: 060C1D06
	s_waitcnt lgkmcnt(13)                                      // 00000091AB60: BF89FCD7
	v_add_f32_e32 v2, v2, v16                                  // 00000091AB64: 06042102
	s_waitcnt lgkmcnt(9)                                       // 00000091AB68: BF89FC97
	v_dual_add_f32 v14, v52, v17 :: v_dual_add_f32 v7, v7, v27 // 00000091AB6C: C9082334 0E063707
	ds_load_2addr_b32 v[4:5], v20 offset0:64 offset1:80        // 00000091AB74: D8DC5040 04000014
	ds_load_2addr_b32 v[42:43], v46 offset0:64 offset1:80      // 00000091AB7C: D8DC5040 2A00002E
	ds_load_2addr_b32 v[16:17], v46 offset0:96 offset1:112     // 00000091AB84: D8DC7060 1000002E
	ds_load_2addr_b32 v[46:47], v47 offset0:96 offset1:112     // 00000091AB8C: D8DC7060 2E00002F
	v_add_f32_e32 v2, v2, v18                                  // 00000091AB94: 06042502
	s_waitcnt lgkmcnt(10)                                      // 00000091AB98: BF89FCA7
	v_add_f32_e32 v20, v7, v33                                 // 00000091AB9C: 06284307
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000091ABA0: BF870122
	v_add_f32_e32 v2, v2, v22                                  // 00000091ABA4: 06042D02
	s_waitcnt lgkmcnt(9)                                       // 00000091ABA8: BF89FC97
	v_add_f32_e32 v20, v20, v35                                // 00000091ABAC: 06284714
	s_waitcnt lgkmcnt(8)                                       // 00000091ABB0: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000091ABB4: BF8700C1
	v_add_f32_e32 v20, v20, v37                                // 00000091ABB8: 06284B14
	s_waitcnt lgkmcnt(3)                                       // 00000091ABBC: BF89FC37
	v_add_f32_e32 v4, v8, v4                                   // 00000091ABC0: 06080908
	s_waitcnt lgkmcnt(2)                                       // 00000091ABC4: BF89FC27
	v_add_f32_e32 v4, v4, v42                                  // 00000091ABC8: 06085504
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000091ABCC: BF870131
	v_add_f32_e32 v22, v4, v10                                 // 00000091ABD0: 062C1504
	v_add_f32_e32 v10, 0, v12                                  // 00000091ABD4: 06141880
	v_add_f32_e32 v4, 0, v9                                    // 00000091ABD8: 06081280
	v_add_f32_e32 v10, v10, v44                                // 00000091ABDC: 0614590A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000091ABE0: BF8700D2
	v_add_f32_e32 v18, v4, v5                                  // 00000091ABE4: 06240B04
	ds_load_2addr_b32 v[4:5], v49 offset0:96 offset1:112       // 00000091ABE8: D8DC7060 04000031
	s_waitcnt lgkmcnt(2)                                       // 00000091ABF0: BF89FC27
	v_add_f32_e32 v10, v10, v16                                // 00000091ABF4: 0614210A
	s_waitcnt lgkmcnt(1)                                       // 00000091ABF8: BF89FC17
	v_add_f32_e32 v27, v10, v46                                // 00000091ABFC: 06365D0A
	v_add_f32_e32 v14, v14, v19                                // 00000091AC00: 061C270E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000091AC04: BF870091
	v_add_f32_e32 v14, v14, v23                                // 00000091AC08: 061C2F0E
	v_add_f32_e32 v8, v14, v25                                 // 00000091AC0C: 0610330E
	v_add_f32_e32 v14, 0, v13                                  // 00000091AC10: 061C1A80
	ds_load_2addr_b32 v[12:13], v49 offset0:64 offset1:80      // 00000091AC14: D8DC5040 0C000031
	v_add_f32_e32 v8, v8, v29                                  // 00000091AC1C: 06103B08
	v_add_f32_e32 v25, v14, v45                                // 00000091AC20: 06325B0E
	ds_load_2addr_b32 v[14:15], v50 offset0:64 offset1:80      // 00000091AC24: D8DC5040 0E000032
	v_add_f32_e32 v23, v8, v31                                 // 00000091AC2C: 062E3F08
	ds_load_2addr_b32 v[8:9], v48 offset0:96 offset1:112       // 00000091AC30: D8DC7060 08000030
	v_add_f32_e32 v25, v25, v17                                // 00000091AC38: 06322319
	ds_load_2addr_b32 v[16:17], v51 offset0:64 offset1:80      // 00000091AC3C: D8DC5040 10000033
	v_add_f32_e32 v25, v25, v47                                // 00000091AC44: 06325F19
	s_waitcnt lgkmcnt(1)                                       // 00000091AC48: BF89FC17
	s_delay_alu instid0(VALU_DEP_1)                            // 00000091AC4C: BF870001
	v_dual_add_f32 v9, v25, v9 :: v_dual_add_f32 v6, v6, v26   // 00000091AC50: C9081319 09063506
	v_add_f32_e32 v26, v18, v43                                // 00000091AC58: 06345712
	ds_load_2addr_b32 v[18:19], v50 offset0:96 offset1:112     // 00000091AC5C: D8DC7060 12000032
	v_dual_add_f32 v8, v27, v8 :: v_dual_add_f32 v5, v9, v5    // 00000091AC64: C908111B 08040B09
	v_add_f32_e32 v6, v6, v32                                  // 00000091AC6C: 060C4106
	v_add_f32_e32 v26, v26, v11                                // 00000091AC70: 0634171A
	ds_load_2addr_b32 v[10:11], v51 offset0:96 offset1:112     // 00000091AC74: D8DC7060 0A000033
	v_add_f32_e32 v4, v8, v4                                   // 00000091AC7C: 06080908
	v_add_f32_e32 v8, v20, v39                                 // 00000091AC80: 06104F14
	s_waitcnt lgkmcnt(1)                                       // 00000091AC84: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000091AC88: BF8701C1
	v_dual_add_f32 v8, v8, v41 :: v_dual_add_f32 v5, v5, v19   // 00000091AC8C: C9085308 08042705
	v_add_f32_e32 v6, v6, v34                                  // 00000091AC94: 060C4506
	v_add_f32_e32 v2, v2, v24                                  // 00000091AC98: 06043102
	s_waitcnt lgkmcnt(0)                                       // 00000091AC9C: BF89FC07
	v_dual_add_f32 v4, v4, v18 :: v_dual_add_f32 v5, v5, v11   // 00000091ACA0: C9082504 04041705
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000091ACA8: BF870113
	v_add_f32_e32 v6, v6, v36                                  // 00000091ACAC: 060C4906
	v_add_f32_e32 v4, v4, v10                                  // 00000091ACB0: 06081504
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000091ACB4: BF870092
	v_add_f32_e32 v6, v6, v38                                  // 00000091ACB8: 060C4D06
	v_add_f32_e32 v24, v6, v40                                 // 00000091ACBC: 06305106
	ds_load_2addr_b32 v[6:7], v48 offset0:64 offset1:80        // 00000091ACC0: D8DC5040 06000030
	v_add_f32_e32 v10, v24, v8                                 // 00000091ACC8: 06141118
	s_waitcnt lgkmcnt(0)                                       // 00000091ACCC: BF89FC07
	v_add_f32_e32 v6, v22, v6                                  // 00000091ACD0: 060C0D16
	v_add_f32_e32 v7, v26, v7                                  // 00000091ACD4: 060E0F1A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000091ACD8: BF8701B1
	v_dual_add_f32 v6, v6, v12 :: v_dual_add_f32 v7, v7, v13   // 00000091ACDC: C9081906 06061B07
	v_add_f32_e32 v12, v4, v5                                  // 00000091ACE4: 06180B04
	v_sub_f32_e32 v4, v4, v5                                   // 00000091ACE8: 08080B04
	v_dual_add_f32 v6, v6, v14 :: v_dual_add_f32 v7, v7, v15   // 00000091ACEC: C9081D06 06061F07
	v_and_b32_e32 v15, 1, v0                                   // 00000091ACF4: 361E0081
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000091ACF8: BF870112
	v_dual_add_f32 v6, v6, v16 :: v_dual_add_f32 v7, v7, v17   // 00000091ACFC: C9082106 06062307
	.long 0xd44a0000                                           // 00000091AD04: D44A0000
	v_cndmask_b32_e32 v1, 0, v15, vcc_lo                       // 00000091AD08: 02021E80
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000091AD0C: BF870092
	v_add_f32_e32 v11, v6, v7                                  // 00000091AD10: 06160F06
	v_dual_sub_f32 v6, v6, v7 :: v_dual_add_f32 v7, v11, v12   // 00000091AD14: C9480F06 0606190B
	v_sub_f32_e32 v11, v11, v12                                // 00000091AD1C: 0816190B
	v_add_f32_e32 v2, v2, v28                                  // 00000091AD20: 06043902
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000091AD24: BF870233
	v_add_f32_e32 v14, v6, v4                                  // 00000091AD28: 061C0906
	v_sub_f32_e32 v6, v6, v4                                   // 00000091AD2C: 080C0906
	v_and_b32_e32 v4, 2, v0                                    // 00000091AD30: 36080082
	v_add_f32_e32 v2, v2, v30                                  // 00000091AD34: 06043D02
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000091AD38: BF870112
	.long 0xd44a0001                                           // 00000091AD3C: D44A0001
	v_cndmask_b32_e32 v1, 0, v4, vcc_lo                        // 00000091AD40: 02020880
	v_add_f32_e32 v9, v2, v23                                  // 00000091AD44: 06122F02
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000091AD48: BF870121
	v_add_f32_e32 v5, v9, v10                                  // 00000091AD4C: 060A1509
	v_sub_f32_e32 v9, v9, v10                                  // 00000091AD50: 08121509
	v_add_f32_e32 v10, v5, v7                                  // 00000091AD54: 06140F05
	v_sub_f32_e32 v16, v5, v7                                  // 00000091AD58: 08200F05
	s_delay_alu instid0(VALU_DEP_3)                            // 00000091AD5C: BF870003
	v_add_f32_e32 v4, v9, v11                                  // 00000091AD60: 06081709
	v_sub_f32_e32 v9, v9, v11                                  // 00000091AD64: 08121709
	v_and_b32_e32 v11, 4, v0                                   // 00000091AD68: 36160084
	v_mov_b32_dpp v12, v10 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000091AD6C: 7E1802FA FF01610A
	v_cndmask_b32_e64 v10, -v10, v10, s0                       // 00000091AD74: D501000A 2002150A
	v_sub_f32_e32 v2, v2, v23                                  // 00000091AD7C: 08042F02
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000091AD80: BF870194
	.long 0xd44a0002                                           // 00000091AD84: D44A0002
	v_cndmask_b32_e32 v1, 0, v11, vcc_lo                       // 00000091AD88: 02021680
	v_add_f32_e32 v5, v10, v12                                 // 00000091AD8C: 060A190A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000091AD90: BF8700A1
	v_mov_b32_dpp v10, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000091AD94: 7E1402FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, s1                          // 00000091AD9C: D5010005 20060B05
	v_dual_add_f32 v5, v5, v10 :: v_dual_sub_f32 v8, v24, v8   // 00000091ADA4: C90A1505 05081118
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000091ADAC: BF870111
	v_mov_b32_dpp v11, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000091ADB0: 7E1602FA FF016405
	v_add_f32_e32 v13, v2, v8                                  // 00000091ADB8: 061A1102
	v_sub_f32_e32 v2, v2, v8                                   // 00000091ADBC: 08041102
	v_cndmask_b32_e64 v5, -v5, v5, s2                          // 00000091ADC0: D5010005 200A0B05
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000091ADC8: BF870093
	v_add_f32_e32 v8, v13, v14                                 // 00000091ADCC: 06101D0D
	v_mov_b32_dpp v15, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000091ADD0: 7E1E02FA FF016108
	v_cndmask_b32_e64 v8, -v8, v8, s0                          // 00000091ADD8: D5010008 20021108
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000091ADE0: BF870121
	v_dual_add_f32 v7, v8, v15 :: v_dual_sub_f32 v8, v13, v14  // 00000091ADE4: C90A1F08 07081D0D
	v_add_f32_e32 v13, v2, v6                                  // 00000091ADEC: 061A0D02
	v_mov_b32_dpp v12, v7 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000091ADF0: 7E1802FA FF016207
	v_cndmask_b32_e64 v7, -v7, v7, s1                          // 00000091ADF8: D5010007 20060F07
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000091AE00: BF870113
	v_mov_b32_dpp v10, v13 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000091AE04: 7E1402FA FF01610D
	v_add_f32_e32 v7, v7, v12                                  // 00000091AE0C: 060E1907
	v_cndmask_b32_e64 v12, -v13, v13, s0                       // 00000091AE10: D501000C 20021B0D
	v_mov_b32_dpp v13, v4 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000091AE18: 7E1A02FA FF016104
	v_cndmask_b32_e64 v4, -v4, v4, s0                          // 00000091AE20: D5010004 20020904
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000091AE28: BF8701A3
	v_add_f32_e32 v10, v12, v10                                // 00000091AE2C: 0614150C
	v_mov_b32_dpp v12, v7 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000091AE30: 7E1802FA FF016407
	v_add_f32_e32 v4, v4, v13                                  // 00000091AE38: 06081B04
	v_cndmask_b32_e64 v7, -v7, v7, s2                          // 00000091AE3C: D5010007 200A0F07
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000091AE44: BF870224
	v_mov_b32_dpp v13, v10 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000091AE48: 7E1A02FA FF01620A
	v_cndmask_b32_e64 v10, -v10, v10, s1                       // 00000091AE50: D501000A 2006150A
	v_mov_b32_dpp v14, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000091AE58: 7E1C02FA FF016204
	v_cndmask_b32_e64 v15, -v4, v4, s1                         // 00000091AE60: D501000F 20060904
	v_dual_add_f32 v4, v5, v11 :: v_dual_add_f32 v7, v7, v12   // 00000091AE68: C9081705 04061907
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000091AE70: BF870224
	v_add_f32_e32 v10, v10, v13                                // 00000091AE74: 06141B0A
	v_sub_f32_e32 v11, v2, v6                                  // 00000091AE78: 08160D02
	v_add_f32_e32 v6, v15, v14                                 // 00000091AE7C: 060C1D0F
	v_mov_b32_dpp v14, v16 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000091AE80: 7E1C02FA FF016110
	v_cndmask_b32_e64 v15, -v16, v16, s0                       // 00000091AE88: D501000F 20022110
	v_mov_b32_dpp v12, v10 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000091AE90: 7E1802FA FF01640A
	v_cndmask_b32_e64 v10, -v10, v10, s2                       // 00000091AE98: D501000A 200A150A
	v_mov_b32_dpp v13, v6 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000091AEA0: 7E1A02FA FF016406
	v_cndmask_b32_e64 v16, -v6, v6, s2                         // 00000091AEA8: D5010010 200A0D06
	v_mov_b32_dpp v2, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000091AEB0: 7E0402FA FF016804
	v_mov_b32_dpp v5, v7 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000091AEB8: 7E0A02FA FF016807
	v_add_f32_e32 v6, v10, v12                                 // 00000091AEC0: 060C190A
	v_mov_b32_dpp v10, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000091AEC4: 7E1402FA FF016108
	v_cndmask_b32_e64 v8, -v8, v8, s0                          // 00000091AECC: D5010008 20021108
	v_add_f32_e32 v12, v15, v14                                // 00000091AED4: 06181D0F
	v_mov_b32_dpp v14, v9 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000091AED8: 7E1C02FA FF016109
	v_cndmask_b32_e64 v9, -v9, v9, s0                          // 00000091AEE0: D5010009 20021309
	v_mov_b32_dpp v15, v11 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000091AEE8: 7E1E02FA FF01610B
	v_cndmask_b32_e64 v11, -v11, v11, s0                       // 00000091AEF0: D501000B 2002170B
	v_add_f32_e32 v8, v8, v10                                  // 00000091AEF8: 06101508
	v_mov_b32_dpp v10, v12 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000091AEFC: 7E1402FA FF01620C
	v_cndmask_b32_e64 v12, -v12, v12, s1                       // 00000091AF04: D501000C 2006190C
	v_add_f32_e32 v9, v9, v14                                  // 00000091AF0C: 06121D09
	v_add_f32_e32 v11, v11, v15                                // 00000091AF10: 06161F0B
	v_mov_b32_dpp v14, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000091AF14: 7E1C02FA FF016208
	v_cndmask_b32_e64 v8, -v8, v8, s1                          // 00000091AF1C: D5010008 20061108
	v_add_f32_e32 v10, v12, v10                                // 00000091AF24: 0614150C
	v_mov_b32_dpp v12, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000091AF28: 7E1802FA FF016209
	v_mov_b32_dpp v15, v11 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000091AF30: 7E1E02FA FF01620B
	v_cndmask_b32_e64 v9, -v9, v9, s1                          // 00000091AF38: D5010009 20061309
	v_cndmask_b32_e64 v11, -v11, v11, s1                       // 00000091AF40: D501000B 2006170B
	v_add_f32_e32 v14, v8, v14                                 // 00000091AF48: 061C1D08
	v_add_f32_e32 v8, v16, v13                                 // 00000091AF4C: 06101B10
	v_mov_b32_dpp v13, v10 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000091AF50: 7E1A02FA FF01640A
	v_add_f32_e32 v9, v9, v12                                  // 00000091AF58: 06121909
	v_add_f32_e32 v11, v11, v15                                // 00000091AF5C: 06161F0B
	v_mov_b32_dpp v12, v14 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000091AF60: 7E1802FA FF01640E
	v_cndmask_b32_e64 v14, -v14, v14, s2                       // 00000091AF68: D501000E 200A1D0E
	v_cndmask_b32_e64 v10, -v10, v10, s2                       // 00000091AF70: D501000A 200A150A
	v_mov_b32_dpp v16, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000091AF78: 7E2002FA FF016409
	v_mov_b32_dpp v18, v11 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000091AF80: 7E2402FA FF01640B
	v_cndmask_b32_e64 v19, -v9, v9, s2                         // 00000091AF88: D5010013 200A1309
	v_cndmask_b32_e64 v11, -v11, v11, s2                       // 00000091AF90: D501000B 200A170B
	v_add_f32_e32 v15, v10, v13                                // 00000091AF98: 061E1B0A
	v_add_f32_e32 v17, v14, v12                                // 00000091AF9C: 0622190E
	v_mov_b32_dpp v9, v8 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000091AFA0: 7E1202FA FF016808
	v_add_f32_e32 v16, v19, v16                                // 00000091AFA8: 06202113
	v_add_f32_e32 v18, v11, v18                                // 00000091AFAC: 0624250B
	v_mov_b32_dpp v10, v6 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000091AFB0: 7E1402FA FF016806
	v_mov_b32_dpp v11, v15 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000091AFB8: 7E1602FA FF01680F
	v_mov_b32_dpp v12, v17 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000091AFC0: 7E1802FA FF016811
	v_mov_b32_dpp v13, v16 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000091AFC8: 7E1A02FA FF016810
	v_mov_b32_dpp v14, v18 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000091AFD0: 7E1C02FA FF016812
	s_and_b32 exec_lo, exec_lo, vcc_lo                         // 00000091AFD8: 8B7E6A7E
	s_cbranch_execz 175                                        // 00000091AFDC: BFA500AF <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_gILi3ELi8ELi4ELi2EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_PtNS0_4HtSdEi+0x479c>
	v_lshlrev_b32_e32 v19, 1, v1                               // 00000091AFE0: 30260281
	v_add_nc_u32_e32 v1, v3, v21                               // 00000091AFE4: 4A022B03
	v_and_b32_e32 v3, 8, v0                                    // 00000091AFE8: 36060088
	s_mul_i32 s0, s5, 0x1400                                   // 00000091AFEC: 9600FF05 00001400
	s_mul_hi_i32 s1, s5, 0x1400                                // 00000091AFF4: 9701FF05 00001400
	s_add_u32 s2, s20, s0                                      // 00000091AFFC: 80020014
	s_addc_u32 s3, s21, s1                                     // 00000091B000: 82030115
	v_cmp_eq_u32_e32 vcc_lo, 0, v3                             // 00000091B004: 7C940680
	s_lshl_b32 s0, s4, 7                                       // 00000091B008: 84008704
	.long 0x7f283880                                           // 00000091B00C: 7F283880
	s_ashr_i32 s1, s0, 31                                      // 00000091B010: 86019F00
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000091B014: BF870009
	s_lshl_b64 s[0:1], s[0:1], 1                               // 00000091B018: 84808100
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 00000091B01C: D5010004 21AA0904
	s_add_u32 s2, s2, s0                                       // 00000091B024: 80020002
	s_addc_u32 s3, s3, s1                                      // 00000091B028: 82030103
	v_cndmask_b32_e64 v3, -v7, v7, vcc_lo                      // 00000091B02C: D5010003 21AA0F07
	v_cndmask_b32_e64 v15, -v15, v15, vcc_lo                   // 00000091B034: D501000F 21AA1F0F
	v_add_f32_e32 v2, v4, v2                                   // 00000091B03C: 06040504
	s_clause 0x7                                               // 00000091B040: BF850007
	global_load_d16_b16 v20, v19, s[2:3] offset:32             // 00000091B044: DC820020 14020013
	global_load_d16_b16 v22, v19, s[2:3]                       // 00000091B04C: DC820000 16020013
	global_load_d16_b16 v23, v19, s[2:3] offset:64             // 00000091B054: DC820040 17020013
	global_load_d16_b16 v24, v19, s[2:3] offset:96             // 00000091B05C: DC820060 18020013
	global_load_d16_b16 v25, v19, s[2:3] offset:128            // 00000091B064: DC820080 19020013
	global_load_d16_b16 v26, v19, s[2:3] offset:160            // 00000091B06C: DC8200A0 1A020013
	global_load_d16_b16 v27, v19, s[2:3] offset:192            // 00000091B074: DC8200C0 1B020013
	global_load_d16_b16 v28, v19, s[2:3] offset:224            // 00000091B07C: DC8200E0 1C020013
	v_cndmask_b32_e64 v16, -v16, v16, vcc_lo                   // 00000091B084: D5010010 21AA2110
	v_add_f32_e32 v3, v3, v5                                   // 00000091B08C: 06060B03
	v_cndmask_b32_e64 v5, -v6, v6, vcc_lo                      // 00000091B090: D5010005 21AA0D06
	v_cndmask_b32_e64 v6, -v8, v8, vcc_lo                      // 00000091B098: D5010006 21AA1108
	v_cndmask_b32_e64 v8, -v17, v17, vcc_lo                    // 00000091B0A0: D5010008 21AA2311
	v_cndmask_b32_e64 v17, -v18, v18, vcc_lo                   // 00000091B0A8: D5010011 21AA2512
	v_mul_f32_e32 v2, 0x3db504f3, v2                           // 00000091B0B0: 100404FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000091B0B8: BF870224
	v_dual_add_f32 v5, v5, v10 :: v_dual_add_f32 v4, v6, v9    // 00000091B0BC: C9081505 05041306
	v_add_f32_e32 v6, v15, v11                                 // 00000091B0C4: 060C170F
	v_dual_add_f32 v10, v17, v14 :: v_dual_mul_f32 v3, 0x3db504f3, v3// 00000091B0C8: C9061D11 0A0206FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000091B0D4: BF870213
	v_dual_add_f32 v8, v8, v12 :: v_dual_mul_f32 v5, 0x3db504f3, v5// 00000091B0D8: C9061908 08040AFF 3DB504F3
	v_dual_add_f32 v9, v16, v13 :: v_dual_mul_f32 v4, 0x3db504f3, v4// 00000091B0E4: C9061B10 090408FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000091B0F0: BF870194
	v_mul_f32_e32 v6, 0x3db504f3, v6                           // 00000091B0F4: 100C0CFF 3DB504F3
	v_mul_f32_e32 v8, 0x3db504f3, v8                           // 00000091B0FC: 101010FF 3DB504F3
	v_mad_i64_i32 v[0:1], null, 0x1400, v1, s[22:23]           // 00000091B104: D6FF7C00 005A02FF 00001400
	s_waitcnt vmcnt(6)                                         // 00000091B110: BF891BF7
	.long 0x7f2c3994                                           // 00000091B114: 7F2C3994
	v_mul_f32_e32 v9, 0x3db504f3, v9                           // 00000091B118: 101212FF 3DB504F3
	s_waitcnt vmcnt(5)                                         // 00000091B120: BF8917F7
	.long 0x7f2e3994                                           // 00000091B124: 7F2E3994
	.long 0x7f0e3994                                           // 00000091B128: 7F0E3994
	.long 0x7f2a3994                                           // 00000091B12C: 7F2A3994
	.long 0xd7006a00                                           // 00000091B130: D7006A00
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 00000091B134: 02000100
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000091B138: BF870111
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 00000091B13C: D5207C01 01AA0201
	.long 0xd7006a00                                           // 00000091B144: D7006A00
	v_cndmask_b32_e32 v1, v0, v19, vcc_lo                      // 00000091B148: 02022700
	s_delay_alu instid0(VALU_DEP_1)                            // 00000091B14C: BF870001
	v_add_co_ci_u32_e64 v1, null, 0, v1, vcc_lo                // 00000091B150: D5207C01 01AA0280
	v_fma_mix_f32 v3, v20, v3, neg(0) op_sel_hi:[1,0,0]        // 00000091B158: CC200003 8A020714
	v_fma_mix_f32 v2, v22, v2, neg(0) op_sel_hi:[1,0,0]        // 00000091B160: CC200002 8A020516
	v_fma_mix_f32 v4, v23, v4, neg(0) op_sel_hi:[1,0,0]        // 00000091B168: CC200004 8A020917
	s_waitcnt vmcnt(4)                                         // 00000091B170: BF8913F7
	v_fma_mix_f32 v5, v24, v5, neg(0) op_sel_hi:[1,0,0]        // 00000091B174: CC200005 8A020B18
	s_waitcnt vmcnt(3)                                         // 00000091B17C: BF890FF7
	v_fma_mix_f32 v6, v25, v6, neg(0) op_sel_hi:[1,0,0]        // 00000091B180: CC200006 8A020D19
	.long 0x7e283983                                           // 00000091B188: 7E283983
	v_mul_f32_e32 v10, 0x3db504f3, v10                         // 00000091B18C: 101414FF 3DB504F3
	s_waitcnt vmcnt(2)                                         // 00000091B194: BF890BF7
	v_fma_mix_f32 v8, v26, v8, neg(0) op_sel_hi:[1,0,0]        // 00000091B198: CC200008 8A02111A
	s_waitcnt vmcnt(1)                                         // 00000091B1A0: BF8907F7
	v_fma_mix_f32 v9, v27, v9, neg(0) op_sel_hi:[1,0,0]        // 00000091B1A4: CC200009 8A02131B
	.long 0x7e0e3982                                           // 00000091B1AC: 7E0E3982
	v_and_b32_e32 v11, 1, v20                                  // 00000091B1B0: 36162881
	.long 0x7e283985                                           // 00000091B1B4: 7E283985
	s_waitcnt vmcnt(0)                                         // 00000091B1B8: BF8903F7
	v_fma_mix_f32 v10, v28, v10, neg(0) op_sel_hi:[1,0,0]      // 00000091B1BC: CC20000A 8A02151C
	.long 0x7e2a3984                                           // 00000091B1C4: 7E2A3984
	.long 0x7e2c3986                                           // 00000091B1C8: 7E2C3986
	.long 0x7e2e3989                                           // 00000091B1CC: 7E2E3989
	v_and_b32_e32 v12, 1, v20                                  // 00000091B1D0: 36182881
	.long 0x7e283988                                           // 00000091B1D4: 7E283988
	v_and_b32_e32 v7, 1, v7                                    // 00000091B1D8: 360E0E81
	v_and_b32_e32 v13, 1, v21                                  // 00000091B1DC: 361A2A81
	v_and_b32_e32 v14, 1, v22                                  // 00000091B1E0: 361C2C81
	v_and_b32_e32 v16, 1, v23                                  // 00000091B1E4: 36202E81
	v_and_b32_e32 v15, 1, v20                                  // 00000091B1E8: 361E2881
	.long 0x7e28398a                                           // 00000091B1EC: 7E28398A
	v_add3_u32 v2, v2, v7, 0x7fff                              // 00000091B1F0: D6550002 03FE0F02 00007FFF
	v_add3_u32 v3, v3, v11, 0x7fff                             // 00000091B1FC: D6550003 03FE1703 00007FFF
	v_add3_u32 v4, v4, v13, 0x7fff                             // 00000091B208: D6550004 03FE1B04 00007FFF
	v_add3_u32 v5, v5, v12, 0x7fff                             // 00000091B214: D6550005 03FE1905 00007FFF
	v_and_b32_e32 v7, 1, v20                                   // 00000091B220: 360E2881
	v_add3_u32 v6, v6, v14, 0x7fff                             // 00000091B224: D6550006 03FE1D06 00007FFF
	v_add3_u32 v9, v9, v16, 0x7fff                             // 00000091B230: D6550009 03FE2109 00007FFF
	v_add3_u32 v8, v8, v15, 0x7fff                             // 00000091B23C: D6550008 03FE1F08 00007FFF
	s_delay_alu instid0(VALU_DEP_4)                            // 00000091B248: BF870004
	v_add3_u32 v7, v10, v7, 0x7fff                             // 00000091B24C: D6550007 03FE0F0A 00007FFF
	s_clause 0x7                                               // 00000091B258: BF850007
	global_store_d16_hi_b16 v[0:1], v2, off                    // 00000091B25C: DC960000 007C0200
	global_store_d16_hi_b16 v[0:1], v3, off offset:32          // 00000091B264: DC960020 007C0300
	global_store_d16_hi_b16 v[0:1], v4, off offset:64          // 00000091B26C: DC960040 007C0400
	global_store_d16_hi_b16 v[0:1], v5, off offset:96          // 00000091B274: DC960060 007C0500
	global_store_d16_hi_b16 v[0:1], v6, off offset:128         // 00000091B27C: DC960080 007C0600
	global_store_d16_hi_b16 v[0:1], v8, off offset:160         // 00000091B284: DC9600A0 007C0800
	global_store_d16_hi_b16 v[0:1], v9, off offset:192         // 00000091B28C: DC9600C0 007C0900
	global_store_d16_hi_b16 v[0:1], v7, off offset:224         // 00000091B294: DC9600E0 007C0700
	s_endpgm                                                   // 00000091B29C: BFB00000
		...

