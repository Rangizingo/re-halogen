0000000000555c00 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi16ELi1ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi16ELi1ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 000000555C00: F4100100 F8000000
	v_and_b32_e32 v23, 15, v0                                  // 000000555C08: 362E008F
	v_lshrrev_b32_e32 v1, 4, v0                                // 000000555C0C: 32020084
	s_ashr_i32 s3, s2, 31                                      // 000000555C10: 86039F02
	v_lshlrev_b32_e32 v0, 2, v0                                // 000000555C14: 30000082
	s_lshl_b64 s[0:1], s[2:3], 4                               // 000000555C18: 84808402
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000555C1C: BF870009
	v_dual_mov_b32 v17, s1 :: v_dual_lshlrev_b32 v2, 2, v23    // 000000555C20: CA220001 11022E82
	v_lshlrev_b32_e32 v3, 2, v1                                // 000000555C28: 30060282
	v_or_b32_e32 v16, s0, v1                                   // 000000555C2C: 38200200
	.long 0x7f023880                                           // 000000555C30: 7F023880
	s_waitcnt lgkmcnt(0)                                       // 000000555C34: BF89FC07
	s_clause 0x1                                               // 000000555C38: BF850001
	global_load_b32 v2, v2, s[4:5]                             // 000000555C3C: DC520000 02040002
	global_load_b32 v3, v3, s[4:5]                             // 000000555C44: DC520000 03040003
	.long 0xd4540000                                           // 000000555C4C: D4540000
	v_cndmask_b32_e32 v1, s12, v16, vcc_lo                     // 000000555C50: 0202200C
	s_add_u32 s22, s4, s16                                     // 000000555C54: 80161004
	s_addc_u32 s23, s5, s17                                    // 000000555C58: 82171105
	s_ashr_i32 s2, s11, 31                                     // 000000555C5C: 86029F0B
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 000000555C60: BF870159
	s_lshr_b32 s2, s2, 27                                      // 000000555C64: 85029B02
	v_cndmask_b32_e64 v8, 0, v16, s0                           // 000000555C68: D5010008 00022080
	v_cndmask_b32_e64 v9, 0, s1, s0                            // 000000555C70: D5010009 00000280
	s_add_u32 s2, s10, s2                                      // 000000555C78: 8002020A
	s_addc_u32 s3, s11, 0                                      // 000000555C7C: 8203800B
	.long 0xd72c0004                                           // 000000555C80: D72C0004
	v_cndmask_b32_e32 v1, s19, v8, vcc_lo                      // 000000555C84: 02021013
	v_mad_u64_u32 v[12:13], null, s18, v8, 0                   // 000000555C88: D6FE7C0C 02021012
	s_lshr_b64 s[20:21], s[2:3], 5                             // 000000555C90: 85948502
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000555C94: BF870009
	s_cmpk_lt_i32 s20, 0x81                                    // 000000555C98: B3940081
	.long 0xd4440002                                           // 000000555C9C: D4440002
	v_cndmask_b32_e32 v1, s20, v23, vcc_lo                     // 000000555CA0: 02022E14
	s_cselect_b32 s1, -1, 0                                    // 000000555CA4: 980180C1
	s_cmpk_gt_i32 s20, 0x80                                    // 000000555CA8: B2940080
	.long 0xd700030e                                           // 000000555CAC: D700030E
	v_cndmask_b32_e32 v1, s22, v12, vcc_lo                     // 000000555CB0: 02021816
	s_waitcnt vmcnt(1)                                         // 000000555CB4: BF8907F7
	v_bfe_u32 v5, v2, 16, 1                                    // 000000555CB8: D6100005 02052102
	s_waitcnt vmcnt(0)                                         // 000000555CC0: BF8903F7
	v_bfe_u32 v6, v3, 16, 1                                    // 000000555CC4: D6100006 02052103
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000555CCC: BF8701A2
	v_add3_u32 v2, v2, v5, 0x7fff                              // 000000555CD0: D6550002 03FE0B02 00007FFF
	.long 0xd72c0005                                           // 000000555CDC: D72C0005
	v_cndmask_b32_e32 v1, s18, v9, vcc_lo                      // 000000555CE0: 02021212
	v_add3_u32 v3, v3, v6, 0x7fff                              // 000000555CE4: D6550003 03FE0D03 00007FFF
	s_cselect_b32 s18, -1, 0                                   // 000000555CF0: 981280C1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000555CF4: BF8701A9
	s_and_b32 vcc_lo, exec_lo, s18                             // 000000555CF8: 8B6A127E
	.long 0x7e023982                                           // 000000555CFC: 7E023982
	v_add3_u32 v13, v13, v5, v4                                // 000000555D00: D655000D 04120B0D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000555D08: BF870112
	v_and_or_b32 v1, 0xffff0000, v3, v1                        // 000000555D0C: D6570001 040606FF FFFF0000
	v_add_co_ci_u32_e64 v15, null, s23, v13, s3                // 000000555D18: D5207C0F 000E1A17
	ds_store_b32 v0, v1                                        // 000000555D20: D8340000 00000100
	s_waitcnt lgkmcnt(0)                                       // 000000555D28: BF89FC07
	s_barrier                                                  // 000000555D2C: BFBD0000
	buffer_gl0_inv                                             // 000000555D30: E0AC0000 00000000
	s_cbranch_vccnz 144                                        // 000000555D38: BFA40090 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi16ELi1ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x37c>
	v_dual_mov_b32 v1, 0 :: v_dual_mov_b32 v0, 0               // 000000555D3C: CA100080 01000080
	s_and_saveexec_b32 s3, s2                                  // 000000555D44: BE832002
	s_cbranch_execz 10                                         // 000000555D48: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi16ELi1ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x174>
	v_lshlrev_b32_e32 v0, 1, v23                               // 000000555D4C: 30002E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000555D50: BF870091
	.long 0xd7006a02                                           // 000000555D54: D7006A02
	v_cndmask_b32_e32 v1, v14, v0, vcc_lo                      // 000000555D58: 0202010E
	v_add_co_ci_u32_e64 v3, null, 0, v15, vcc_lo               // 000000555D5C: D5207C03 01AA1E80
	global_load_d16_b16 v0, v[2:3], off                        // 000000555D64: DC820000 007C0002
	s_waitcnt vmcnt(0)                                         // 000000555D6C: BF8903F7
	v_cvt_f32_f16_e32 v0, v0                                   // 000000555D70: 7E001700
	s_or_b32 exec_lo, exec_lo, s3                              // 000000555D74: 8C7E037E
	v_or_b32_e32 v2, 16, v23                                   // 000000555D78: 38042E90
	s_mov_b32 s2, exec_lo                                      // 000000555D7C: BE82007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000555D80: BF870001
	.long 0xd4c4007e                                           // 000000555D84: D4C4007E
	v_cndmask_b32_e32 v1, s20, v2, vcc_lo                      // 000000555D88: 02020414
	s_cbranch_execz 10                                         // 000000555D8C: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi16ELi1ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x1b8>
	v_lshlrev_b32_e32 v1, 1, v2                                // 000000555D90: 30020481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000555D94: BF870091
	.long 0xd7006a01                                           // 000000555D98: D7006A01
	v_cndmask_b32_e32 v1, v14, v1, vcc_lo                      // 000000555D9C: 0202030E
	v_add_co_ci_u32_e64 v2, null, 0, v15, vcc_lo               // 000000555DA0: D5207C02 01AA1E80
	global_load_d16_b16 v1, v[1:2], off                        // 000000555DA8: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 000000555DB0: BF8903F7
	v_cvt_f32_f16_e32 v1, v1                                   // 000000555DB4: 7E021701
	s_or_b32 exec_lo, exec_lo, s2                              // 000000555DB8: 8C7E027E
	v_or_b32_e32 v4, 32, v23                                   // 000000555DBC: 38082EA0
	v_dual_mov_b32 v3, 0 :: v_dual_mov_b32 v2, 0               // 000000555DC0: CA100080 03020080
	s_mov_b32 s2, exec_lo                                      // 000000555DC8: BE82007E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000555DCC: BF870002
	.long 0xd4c4007e                                           // 000000555DD0: D4C4007E
	v_cndmask_b32_e32 v1, s20, v4, vcc_lo                      // 000000555DD4: 02020814
	s_cbranch_execz 10                                         // 000000555DD8: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi16ELi1ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x204>
	v_lshlrev_b32_e32 v2, 1, v4                                // 000000555DDC: 30040881
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000555DE0: BF870091
	.long 0xd7006a04                                           // 000000555DE4: D7006A04
	v_cndmask_b32_e32 v1, v14, v2, vcc_lo                      // 000000555DE8: 0202050E
	v_add_co_ci_u32_e64 v5, null, 0, v15, vcc_lo               // 000000555DEC: D5207C05 01AA1E80
	global_load_d16_b16 v2, v[4:5], off                        // 000000555DF4: DC820000 027C0004
	s_waitcnt vmcnt(0)                                         // 000000555DFC: BF8903F7
	v_cvt_f32_f16_e32 v2, v2                                   // 000000555E00: 7E041702
	s_or_b32 exec_lo, exec_lo, s2                              // 000000555E04: 8C7E027E
	v_or_b32_e32 v4, 48, v23                                   // 000000555E08: 38082EB0
	s_mov_b32 s2, exec_lo                                      // 000000555E0C: BE82007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000555E10: BF870001
	.long 0xd4c4007e                                           // 000000555E14: D4C4007E
	v_cndmask_b32_e32 v1, s20, v4, vcc_lo                      // 000000555E18: 02020814
	s_cbranch_execz 10                                         // 000000555E1C: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi16ELi1ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x248>
	v_lshlrev_b32_e32 v3, 1, v4                                // 000000555E20: 30060881
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000555E24: BF870091
	.long 0xd7006a03                                           // 000000555E28: D7006A03
	v_cndmask_b32_e32 v1, v14, v3, vcc_lo                      // 000000555E2C: 0202070E
	v_add_co_ci_u32_e64 v4, null, 0, v15, vcc_lo               // 000000555E30: D5207C04 01AA1E80
	global_load_d16_b16 v3, v[3:4], off                        // 000000555E38: DC820000 037C0003
	s_waitcnt vmcnt(0)                                         // 000000555E40: BF8903F7
	v_cvt_f32_f16_e32 v3, v3                                   // 000000555E44: 7E061703
	s_or_b32 exec_lo, exec_lo, s2                              // 000000555E48: 8C7E027E
	v_or_b32_e32 v6, 64, v23                                   // 000000555E4C: 380C2EC0
	v_dual_mov_b32 v5, 0 :: v_dual_mov_b32 v4, 0               // 000000555E50: CA100080 05040080
	s_mov_b32 s2, exec_lo                                      // 000000555E58: BE82007E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000555E5C: BF870002
	.long 0xd4c4007e                                           // 000000555E60: D4C4007E
	v_cndmask_b32_e32 v1, s20, v6, vcc_lo                      // 000000555E64: 02020C14
	s_cbranch_execz 10                                         // 000000555E68: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi16ELi1ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x294>
	v_lshlrev_b32_e32 v4, 1, v6                                // 000000555E6C: 30080C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000555E70: BF870091
	.long 0xd7006a06                                           // 000000555E74: D7006A06
	v_cndmask_b32_e32 v1, v14, v4, vcc_lo                      // 000000555E78: 0202090E
	v_add_co_ci_u32_e64 v7, null, 0, v15, vcc_lo               // 000000555E7C: D5207C07 01AA1E80
	global_load_d16_b16 v4, v[6:7], off                        // 000000555E84: DC820000 047C0006
	s_waitcnt vmcnt(0)                                         // 000000555E8C: BF8903F7
	v_cvt_f32_f16_e32 v4, v4                                   // 000000555E90: 7E081704
	s_or_b32 exec_lo, exec_lo, s2                              // 000000555E94: 8C7E027E
	v_or_b32_e32 v6, 0x50, v23                                 // 000000555E98: 380C2EFF 00000050
	s_mov_b32 s2, exec_lo                                      // 000000555EA0: BE82007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000555EA4: BF870001
	.long 0xd4c4007e                                           // 000000555EA8: D4C4007E
	v_cndmask_b32_e32 v1, s20, v6, vcc_lo                      // 000000555EAC: 02020C14
	s_cbranch_execz 10                                         // 000000555EB0: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi16ELi1ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x2dc>
	v_lshlrev_b32_e32 v5, 1, v6                                // 000000555EB4: 300A0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000555EB8: BF870091
	.long 0xd7006a05                                           // 000000555EBC: D7006A05
	v_cndmask_b32_e32 v1, v14, v5, vcc_lo                      // 000000555EC0: 02020B0E
	v_add_co_ci_u32_e64 v6, null, 0, v15, vcc_lo               // 000000555EC4: D5207C06 01AA1E80
	global_load_d16_b16 v5, v[5:6], off                        // 000000555ECC: DC820000 057C0005
	s_waitcnt vmcnt(0)                                         // 000000555ED4: BF8903F7
	v_cvt_f32_f16_e32 v5, v5                                   // 000000555ED8: 7E0A1705
	s_or_b32 exec_lo, exec_lo, s2                              // 000000555EDC: 8C7E027E
	v_or_b32_e32 v10, 0x60, v23                                // 000000555EE0: 38142EFF 00000060
	v_dual_mov_b32 v7, 0 :: v_dual_mov_b32 v6, 0               // 000000555EE8: CA100080 07060080
	s_mov_b32 s2, exec_lo                                      // 000000555EF0: BE82007E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000555EF4: BF870002
	.long 0xd4c4007e                                           // 000000555EF8: D4C4007E
	v_cndmask_b32_e32 v1, s20, v10, vcc_lo                     // 000000555EFC: 02021414
	s_cbranch_execz 10                                         // 000000555F00: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi16ELi1ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x32c>
	v_lshlrev_b32_e32 v6, 1, v10                               // 000000555F04: 300C1481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000555F08: BF870091
	.long 0xd7006a0a                                           // 000000555F0C: D7006A0A
	v_cndmask_b32_e32 v1, v14, v6, vcc_lo                      // 000000555F10: 02020D0E
	v_add_co_ci_u32_e64 v11, null, 0, v15, vcc_lo              // 000000555F14: D5207C0B 01AA1E80
	global_load_d16_b16 v6, v[10:11], off                      // 000000555F1C: DC820000 067C000A
	s_waitcnt vmcnt(0)                                         // 000000555F24: BF8903F7
	v_cvt_f32_f16_e32 v6, v6                                   // 000000555F28: 7E0C1706
	s_or_b32 exec_lo, exec_lo, s2                              // 000000555F2C: 8C7E027E
	v_or_b32_e32 v10, 0x70, v23                                // 000000555F30: 38142EFF 00000070
	s_mov_b32 s2, exec_lo                                      // 000000555F38: BE82007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000555F3C: BF870001
	.long 0xd4c4007e                                           // 000000555F40: D4C4007E
	v_cndmask_b32_e32 v1, s20, v10, vcc_lo                     // 000000555F44: 02021414
	s_cbranch_execz 10                                         // 000000555F48: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi16ELi1ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x374>
	v_lshlrev_b32_e32 v7, 1, v10                               // 000000555F4C: 300E1481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000555F50: BF870091
	.long 0xd7006a0a                                           // 000000555F54: D7006A0A
	v_cndmask_b32_e32 v1, v14, v7, vcc_lo                      // 000000555F58: 02020F0E
	v_add_co_ci_u32_e64 v11, null, 0, v15, vcc_lo              // 000000555F5C: D5207C0B 01AA1E80
	global_load_d16_b16 v7, v[10:11], off                      // 000000555F64: DC820000 077C000A
	s_waitcnt vmcnt(0)                                         // 000000555F6C: BF8903F7
	v_cvt_f32_f16_e32 v7, v7                                   // 000000555F70: 7E0E1707
	s_or_b32 exec_lo, exec_lo, s2                              // 000000555F74: 8C7E027E
	s_branch 9                                                 // 000000555F78: BFA00009 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi16ELi1ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x3a0>
	v_mov_b32_e32 v0, 0                                        // 000000555F7C: 7E000280
	s_delay_alu instid0(VALU_DEP_1)                            // 000000555F80: BF870001
	v_mov_b32_e32 v1, v0                                       // 000000555F84: 7E020300
	v_mov_b32_e32 v2, v0                                       // 000000555F88: 7E040300
	v_mov_b32_e32 v3, v0                                       // 000000555F8C: 7E060300
	v_mov_b32_e32 v4, v0                                       // 000000555F90: 7E080300
	v_mov_b32_e32 v5, v0                                       // 000000555F94: 7E0A0300
	v_mov_b32_e32 v6, v0                                       // 000000555F98: 7E0C0300
	v_mov_b32_e32 v7, v0                                       // 000000555F9C: 7E0E0300
	s_add_u32 s2, s4, s14                                      // 000000555FA0: 80020E04
	s_addc_u32 s3, s5, s15                                     // 000000555FA4: 82030F05
	s_lshr_b32 s14, s11, 31                                    // 000000555FA8: 850E9F0B
	v_cndmask_b32_e64 v24, 0, 1, s18                           // 000000555FAC: D5010018 00490280
	s_add_u32 s14, s10, s14                                    // 000000555FB4: 800E0E0A
	s_addc_u32 s15, s11, 0                                     // 000000555FB8: 820F800B
	v_mov_b32_e32 v32, 0                                       // 000000555FBC: 7E400280
	s_ashr_i64 s[14:15], s[14:15], 1                           // 000000555FC0: 868E810E
	v_mov_b32_e32 v25, 0                                       // 000000555FC4: 7E320280
	v_mad_u64_u32 v[18:19], null, v8, s14, s[2:3]              // 000000555FC8: D6FE7C12 00081D08
	.long 0xd72c000b                                           // 000000555FD0: D72C000B
	v_cndmask_b32_e32 v0, v8, v15, vcc_lo                      // 000000555FD4: 02001F08
	.long 0xd72c0014                                           // 000000555FD8: D72C0014
	v_cndmask_b32_e32 v0, v9, v14, vcc_lo                      // 000000555FDC: 02001D09
	.long 0xd4440002                                           // 000000555FE0: D4440002
	v_cndmask_b32_e32 v1, s20, v23, vcc_lo                     // 000000555FE4: 02022E14
	v_dual_mov_b32 v8, 0 :: v_dual_mov_b32 v9, 0               // 000000555FE8: CA100080 08080080
	v_mov_b32_e32 v10, 0                                       // 000000555FF0: 7E140280
	s_delay_alu instid0(VALU_DEP_4)                            // 000000555FF4: BF870004
	v_add3_u32 v26, v20, v19, v11                              // 000000555FF8: D655001A 042E2714
	v_mov_b32_e32 v11, 0                                       // 000000556000: 7E160280
	s_and_saveexec_b32 s3, s2                                  // 000000556004: BE832002
	s_cbranch_execz 21                                         // 000000556008: BFA50015 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi16ELi1ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x460>
	v_lshlrev_b32_e32 v8, 4, v23                               // 00000055600C: 30102E84
	v_mov_b32_e32 v32, 0                                       // 000000556010: 7E400280
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000556014: BF870092
	.long 0xd7006a08                                           // 000000556018: D7006A08
	v_cndmask_b32_e32 v1, v18, v8, vcc_lo                      // 00000055601C: 02021112
	v_add_co_ci_u32_e64 v9, null, 0, v26, vcc_lo               // 000000556020: D5207C09 01AA3480
	s_and_not1_b32 vcc_lo, exec_lo, s18                        // 000000556028: 916A127E
	global_load_b128 v[8:11], v[8:9], off                      // 00000055602C: DC5E0000 087C0008
	s_cbranch_vccnz 10                                         // 000000556034: BFA4000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi16ELi1ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x460>
	v_lshlrev_b32_e32 v19, 1, v23                              // 000000556038: 30262E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000055603C: BF870091
	.long 0xd7006a0e                                           // 000000556040: D7006A0E
	v_cndmask_b32_e32 v1, v14, v19, vcc_lo                     // 000000556044: 0202270E
	v_add_co_ci_u32_e64 v15, null, 0, v15, vcc_lo              // 000000556048: D5207C0F 01AA1E80
	global_load_d16_b16 v14, v[14:15], off                     // 000000556050: DC820000 0E7C000E
	s_waitcnt vmcnt(0)                                         // 000000556058: BF8903F7
	v_cvt_f32_f16_e32 v32, v14                                 // 00000055605C: 7E40170E
	s_or_b32 exec_lo, exec_lo, s3                              // 000000556060: 8C7E037E
	v_dual_mov_b32 v27, 0 :: v_dual_mov_b32 v28, 0             // 000000556064: CA100080 1B1C0080
	s_and_saveexec_b32 s3, s2                                  // 00000055606C: BE832002
	s_cbranch_execz 352                                        // 000000556070: BFA50160 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi16ELi1ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x9f4>
	.long 0xd7006a0c                                           // 000000556074: D7006A0C
	v_cndmask_b32_e32 v1, s16, v12, vcc_lo                     // 000000556078: 02021810
	v_dual_mov_b32 v20, 0 :: v_dual_lshlrev_b32 v19, 5, v23    // 00000055607C: CA220080 14122E85
	v_lshlrev_b32_e32 v14, 1, v23                              // 000000556084: 301C2E81
	v_add_co_ci_u32_e64 v13, null, s17, v13, vcc_lo            // 000000556088: D5207C0D 01AA1A11
	v_lshl_or_b32 v29, v23, 4, 0x100                           // 000000556090: D656001D 03FD0917 00000100
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000055609C: BF870214
	v_mov_b32_e32 v27, v20                                     // 0000005560A0: 7E360314
	.long 0xd7006a0c                                           // 0000005560A4: D7006A0C
	v_cndmask_b32_e32 v1, v12, v14, vcc_lo                     // 0000005560A8: 02021D0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000005560AC: BF8701A1
	v_add_co_ci_u32_e64 v13, null, 0, v13, vcc_lo              // 0000005560B0: D5207C0D 01AA1A80
	v_dual_mov_b32 v30, v23 :: v_dual_mov_b32 v25, v20         // 0000005560B8: CA100117 1E180114
	.long 0xd7006a0c                                           // 0000005560C0: D7006A0C
	v_cndmask_b32_e32 v1, s4, v12, vcc_lo                      // 0000005560C4: 02021804
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000005560C8: BF8701A1
	v_add_co_ci_u32_e64 v13, null, s5, v13, vcc_lo             // 0000005560CC: D5207C0D 01AA1A05
	v_mov_b32_e32 v28, v20                                     // 0000005560D4: 7E380314
	.long 0xd7006a15                                           // 0000005560D8: D7006A15
	v_cndmask_b32_e32 v0, v12, v160, vcc_lo                    // 0000005560DC: 0201410C
	s_delay_alu instid0(VALU_DEP_1)                            // 0000005560E0: BF870001
	v_add_co_ci_u32_e64 v22, null, 0, v13, vcc_lo              // 0000005560E4: D5207C16 01AA1A80
	v_mov_b32_e32 v31, v32                                     // 0000005560EC: 7E3E0320
	s_lshl_b64 s[4:5], s[10:11], 2                             // 0000005560F0: 8484820A
	s_mov_b32 s14, 0                                           // 0000005560F4: BE8E0080
	s_lshl_b64 s[10:11], s[10:11], 1                           // 0000005560F8: 848A810A
	s_branch 288                                               // 0000005560FC: BFA00120 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi16ELi1ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x980>
	s_or_b32 exec_lo, exec_lo, s15                             // 000000556100: 8C7E0F7E
	.long 0xd73c0021                                           // 000000556104: D73C0021
	v_cndmask_b32_e32 v1, 1, v19, vcc_lo                       // 000000556108: 02022681
	v_and_b32_e32 v81, 0xff, v8                                // 00000055610C: 36A210FF 000000FF
	v_cndmask_b32_e64 v82, v32, v0, s1                         // 000000556114: D5010052 00060120
	v_lshrrev_b32_e32 v32, 6, v8                               // 00000055611C: 32401086
	v_lshrrev_b32_e32 v83, 14, v8                              // 000000556120: 32A6108E
	v_lshrrev_b32_e32 v8, 22, v8                               // 000000556124: 32101096
	.long 0xd7006a45                                           // 000000556128: D7006A45
	v_cndmask_b32_e32 v1, s6, v33, vcc_lo                      // 00000055612C: 02024206
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000556130: BF8701A1
	v_add_co_ci_u32_e64 v70, null, s7, v34, vcc_lo             // 000000556134: D5207C46 01AA4407
	v_lshlrev_b32_e32 v81, 2, v81                              // 00000055613C: 30A2A282
	.long 0xd7006a49                                           // 000000556140: D7006A49
	v_cndmask_b32_e32 v0, v69, v10, vcc_lo                     // 000000556144: 02001545
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000556148: BF8700A1
	v_add_co_ci_u32_e64 v74, null, s11, v70, vcc_lo            // 00000055614C: D5207C4A 01AA8C0B
	.long 0xd7006a4d                                           // 000000556154: D7006A4D
	v_cndmask_b32_e32 v0, v69, v4, vcc_lo                      // 000000556158: 02000945
	v_add_co_ci_u32_e64 v78, null, s5, v70, vcc_lo             // 00000055615C: D5207C4E 01AA8C05
	s_clause 0xb                                               // 000000556164: BF85000B
	global_load_b128 v[33:36], v[69:70], off                   // 000000556168: DC5E0000 217C0045
	global_load_b128 v[37:40], v[73:74], off                   // 000000556170: DC5E0000 257C0049
	global_load_b128 v[41:44], v[77:78], off                   // 000000556178: DC5E0000 297C004D
	global_load_b128 v[45:48], v[69:70], off offset:16         // 000000556180: DC5E0010 2D7C0045
	global_load_b128 v[49:52], v[73:74], off offset:16         // 000000556188: DC5E0010 317C0049
	global_load_b128 v[53:56], v[77:78], off offset:16         // 000000556190: DC5E0010 357C004D
	global_load_b128 v[57:60], v[69:70], off offset:32         // 000000556198: DC5E0020 397C0045
	global_load_b128 v[61:64], v[73:74], off offset:32         // 0000005561A0: DC5E0020 3D7C0049
	global_load_b128 v[65:68], v[77:78], off offset:32         // 0000005561A8: DC5E0020 417C004D
	global_load_b128 v[69:72], v[69:70], off offset:48         // 0000005561B0: DC5E0030 457C0045
	global_load_b128 v[73:76], v[73:74], off offset:48         // 0000005561B8: DC5E0030 497C0049
	global_load_b128 v[77:80], v[77:78], off offset:48         // 0000005561C0: DC5E0030 4D7C004D
	v_and_b32_e32 v32, 0x3fc, v32                              // 0000005561C8: 364040FF 000003FC
	ds_load_b32 v81, v81                                       // 0000005561D0: D8D80000 51000051
	v_and_b32_e32 v83, 0x3fc, v83                              // 0000005561D8: 36A6A6FF 000003FC
	v_and_b32_e32 v84, 0xff, v9                                // 0000005561E0: 36A812FF 000000FF
	v_lshrrev_b32_e32 v85, 6, v9                               // 0000005561E8: 32AA1286
	v_lshrrev_b32_e32 v86, 14, v9                              // 0000005561EC: 32AC128E
	v_lshrrev_b32_e32 v9, 22, v9                               // 0000005561F0: 32121296
	ds_load_b32 v83, v83                                       // 0000005561F4: D8D80000 53000053
	ds_load_b32 v32, v32                                       // 0000005561FC: D8D80000 20000020
	v_and_b32_e32 v8, 0x3fc, v8                                // 000000556204: 361010FF 000003FC
	v_lshlrev_b32_e32 v84, 2, v84                              // 00000055620C: 30A8A882
	v_and_b32_e32 v85, 0x3fc, v85                              // 000000556210: 36AAAAFF 000003FC
	v_and_b32_e32 v86, 0x3fc, v86                              // 000000556218: 36ACACFF 000003FC
	v_and_b32_e32 v9, 0x3fc, v9                                // 000000556220: 361212FF 000003FC
	ds_load_b32 v8, v8                                         // 000000556228: D8D80000 08000008
	ds_load_b32 v84, v84                                       // 000000556230: D8D80000 54000054
	ds_load_b32 v85, v85                                       // 000000556238: D8D80000 55000055
	ds_load_b32 v86, v86                                       // 000000556240: D8D80000 56000056
	ds_load_b32 v9, v9                                         // 000000556248: D8D80000 09000009
	v_and_b32_e32 v87, 0xff, v10                               // 000000556250: 36AE14FF 000000FF
	v_lshrrev_b32_e32 v88, 6, v10                              // 000000556258: 32B01486
	v_lshrrev_b32_e32 v89, 14, v10                             // 00000055625C: 32B2148E
	v_lshrrev_b32_e32 v10, 22, v10                             // 000000556260: 32141496
	v_and_b32_e32 v90, 0xff, v11                               // 000000556264: 36B416FF 000000FF
	v_lshrrev_b32_e32 v91, 14, v11                             // 00000055626C: 32B6168E
	.long 0xd7006a15                                           // 000000556270: D7006A15
	v_cndmask_b32_e32 v0, v21, v160, vcc_lo                    // 000000556274: 02014115
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000556278: BF8704A1
	v_add_co_ci_u32_e64 v22, null, 0, v22, vcc_lo              // 00000055627C: D5207C16 01AA2C80
	s_and_b32 s2, exec_lo, s2                                  // 000000556284: 8B02027E
	s_or_b32 s14, s2, s14                                      // 000000556288: 8C0E0E02
	s_waitcnt vmcnt(11) lgkmcnt(7)                             // 00000055628C: BF892C77
	v_dot2_f32_bf16 v33, v33, v81, 0                           // 000000556290: CC1A4021 1A02A321
	s_waitcnt vmcnt(10)                                        // 000000556298: BF892BF7
	v_dot2_f32_bf16 v37, v37, v81, 0                           // 00000055629C: CC1A4025 1A02A325
	s_waitcnt vmcnt(9)                                         // 0000005562A4: BF8927F7
	v_dot2_f32_bf16 v41, v41, v81, 0                           // 0000005562A8: CC1A4029 1A02A329
	v_lshrrev_b32_e32 v81, 6, v11                              // 0000005562B0: 32A21686
	v_lshrrev_b32_e32 v11, 22, v11                             // 0000005562B4: 32161696
	s_waitcnt lgkmcnt(5)                                       // 0000005562B8: BF89FC57
	v_dot2_f32_bf16 v33, v34, v32, v33                         // 0000005562BC: CC1A4021 1C864122
	v_dot2_f32_bf16 v34, v38, v32, v37                         // 0000005562C4: CC1A4022 1C964126
	v_dot2_f32_bf16 v32, v42, v32, v41                         // 0000005562CC: CC1A4020 1CA6412A
	v_lshlrev_b32_e32 v37, 2, v87                              // 0000005562D4: 304AAE82
	v_and_b32_e32 v38, 0x3fc, v89                              // 0000005562D8: 364CB2FF 000003FC
	v_dot2_f32_bf16 v33, v35, v83, v33                         // 0000005562E0: CC1A4021 1C86A723
	v_dot2_f32_bf16 v34, v39, v83, v34                         // 0000005562E8: CC1A4022 1C8AA727
	v_dot2_f32_bf16 v32, v43, v83, v32                         // 0000005562F0: CC1A4020 1C82A72B
	v_and_b32_e32 v35, 0x3fc, v88                              // 0000005562F8: 3646B0FF 000003FC
	v_and_b32_e32 v39, 0x3fc, v91                              // 000000556300: 364EB6FF 000003FC
	s_waitcnt lgkmcnt(4)                                       // 000000556308: BF89FC47
	v_dot2_f32_bf16 v33, v36, v8, v33                          // 00000055630C: CC1A4021 1C861124
	v_dot2_f32_bf16 v34, v40, v8, v34                          // 000000556314: CC1A4022 1C8A1128
	v_dot2_f32_bf16 v8, v44, v8, v32                           // 00000055631C: CC1A4008 1C82112C
	ds_load_b32 v36, v37                                       // 000000556324: D8D80000 24000025
	ds_load_b32 v40, v38                                       // 00000055632C: D8D80000 28000026
	ds_load_b32 v35, v35                                       // 000000556334: D8D80000 23000023
	s_waitcnt vmcnt(8) lgkmcnt(6)                              // 00000055633C: BF892067
	v_dot2_f32_bf16 v33, v45, v84, v33                         // 000000556340: CC1A4021 1C86A92D
	s_waitcnt vmcnt(7)                                         // 000000556348: BF891FF7
	v_dot2_f32_bf16 v34, v49, v84, v34                         // 00000055634C: CC1A4022 1C8AA931
	s_waitcnt vmcnt(6)                                         // 000000556354: BF891BF7
	v_dot2_f32_bf16 v8, v53, v84, v8                           // 000000556358: CC1A4008 1C22A935
	v_cndmask_b32_e64 v38, v5, v6, s1                          // 000000556360: D5010026 00060D05
	v_and_b32_e32 v10, 0x3fc, v10                              // 000000556368: 361414FF 000003FC
	s_waitcnt lgkmcnt(5)                                       // 000000556370: BF89FC57
	v_dot2_f32_bf16 v33, v46, v85, v33                         // 000000556374: CC1A4021 1C86AB2E
	v_dot2_f32_bf16 v34, v50, v85, v34                         // 00000055637C: CC1A4022 1C8AAB32
	v_dot2_f32_bf16 v8, v54, v85, v8                           // 000000556384: CC1A4008 1C22AB36
	v_lshlrev_b32_e32 v32, 2, v90                              // 00000055638C: 3040B482
	v_and_b32_e32 v37, 0x3fc, v81                              // 000000556390: 364AA2FF 000003FC
	s_waitcnt lgkmcnt(4)                                       // 000000556398: BF89FC47
	v_dot2_f32_bf16 v33, v47, v86, v33                         // 00000055639C: CC1A4021 1C86AD2F
	v_dot2_f32_bf16 v34, v51, v86, v34                         // 0000005563A4: CC1A4022 1C8AAD33
	v_dot2_f32_bf16 v8, v55, v86, v8                           // 0000005563AC: CC1A4008 1C22AD37
	v_and_b32_e32 v11, 0x3fc, v11                              // 0000005563B4: 361616FF 000003FC
	s_waitcnt lgkmcnt(3)                                       // 0000005563BC: BF89FC37
	v_dot2_f32_bf16 v33, v48, v9, v33                          // 0000005563C0: CC1A4021 1C861330
	v_dot2_f32_bf16 v34, v52, v9, v34                          // 0000005563C8: CC1A4022 1C8A1334
	v_dot2_f32_bf16 v8, v56, v9, v8                            // 0000005563D0: CC1A4008 1C221338
	ds_load_b32 v9, v10                                        // 0000005563D8: D8D80000 0900000A
	ds_load_b32 v10, v32                                       // 0000005563E0: D8D80000 0A000020
	ds_load_b32 v32, v37                                       // 0000005563E8: D8D80000 20000025
	ds_load_b32 v41, v39                                       // 0000005563F0: D8D80000 29000027
	ds_load_b32 v42, v11                                       // 0000005563F8: D8D80000 2A00000B
	v_cndmask_b32_e64 v39, v6, v7, s1                          // 000000556400: D5010027 00060F06
	s_waitcnt vmcnt(5) lgkmcnt(7)                              // 000000556408: BF891477
	v_dot2_f32_bf16 v11, v57, v36, v33                         // 00000055640C: CC1A400B 1C864939
	s_waitcnt vmcnt(4)                                         // 000000556414: BF8913F7
	v_dot2_f32_bf16 v33, v61, v36, v34                         // 000000556418: CC1A4021 1C8A493D
	s_waitcnt vmcnt(3)                                         // 000000556420: BF890FF7
	v_dot2_f32_bf16 v8, v65, v36, v8                           // 000000556424: CC1A4008 1C224941
	v_cndmask_b32_e64 v37, v4, v5, s1                          // 00000055642C: D5010025 00060B04
	v_cndmask_b32_e64 v36, v3, v4, s1                          // 000000556434: D5010024 00060903
	s_waitcnt lgkmcnt(5)                                       // 00000055643C: BF89FC57
	v_dot2_f32_bf16 v6, v58, v35, v11                          // 000000556440: CC1A4006 1C2E473A
	v_dot2_f32_bf16 v11, v62, v35, v33                         // 000000556448: CC1A400B 1C86473E
	v_dot2_f32_bf16 v8, v66, v35, v8                           // 000000556450: CC1A4008 1C224742
	v_cndmask_b32_e64 v35, v2, v3, s1                          // 000000556458: D5010023 00060702
	v_cndmask_b32_e64 v34, v1, v2, s1                          // 000000556460: D5010022 00060501
	v_dot2_f32_bf16 v4, v59, v40, v6                           // 000000556468: CC1A4004 1C1A513B
	v_dot2_f32_bf16 v5, v63, v40, v11                          // 000000556470: CC1A4005 1C2E513F
	v_dot2_f32_bf16 v6, v67, v40, v8                           // 000000556478: CC1A4006 1C225143
	v_cndmask_b32_e64 v33, v0, v1, s1                          // 000000556480: D5010021 00060300
	v_mov_b32_e32 v40, v7                                      // 000000556488: 7E500307
	s_waitcnt lgkmcnt(4)                                       // 00000055648C: BF89FC47
	v_dot2_f32_bf16 v2, v60, v9, v4                            // 000000556490: CC1A4002 1C12133C
	v_dot2_f32_bf16 v3, v64, v9, v5                            // 000000556498: CC1A4003 1C161340
	v_dot2_f32_bf16 v4, v68, v9, v6                            // 0000005564A0: CC1A4004 1C1A1344
	v_add_nc_u32_e32 v19, 0x200, v19                           // 0000005564A8: 4A2626FF 00000200
	v_add_nc_u32_e32 v29, 0x100, v29                           // 0000005564B0: 4A3A3AFF 00000100
	s_waitcnt vmcnt(2) lgkmcnt(3)                              // 0000005564B8: BF890837
	v_dot2_f32_bf16 v0, v69, v10, v2                           // 0000005564BC: CC1A4000 1C0A1545
	s_waitcnt vmcnt(1)                                         // 0000005564C4: BF8907F7
	v_dot2_f32_bf16 v1, v73, v10, v3                           // 0000005564C8: CC1A4001 1C0E1549
	s_waitcnt vmcnt(0)                                         // 0000005564D0: BF8903F7
	v_dot2_f32_bf16 v2, v77, v10, v4                           // 0000005564D4: CC1A4002 1C12154D
	v_dual_mov_b32 v11, v15 :: v_dual_mov_b32 v10, v14         // 0000005564DC: CA10010F 0B0A010E
	s_waitcnt lgkmcnt(2)                                       // 0000005564E4: BF89FC27
	v_dot2_f32_bf16 v0, v70, v32, v0                           // 0000005564E8: CC1A4000 1C024146
	v_dot2_f32_bf16 v1, v74, v32, v1                           // 0000005564F0: CC1A4001 1C06414A
	v_dot2_f32_bf16 v2, v78, v32, v2                           // 0000005564F8: CC1A4002 1C0A414E
	v_dual_mov_b32 v9, v13 :: v_dual_mov_b32 v8, v12           // 000000556500: CA10010D 0908010C
	s_waitcnt lgkmcnt(1)                                       // 000000556508: BF89FC17
	v_dot2_f32_bf16 v0, v71, v41, v0                           // 00000055650C: CC1A4000 1C025347
	v_dot2_f32_bf16 v1, v75, v41, v1                           // 000000556514: CC1A4001 1C06534B
	v_dot2_f32_bf16 v2, v79, v41, v2                           // 00000055651C: CC1A4002 1C0A534F
	v_mov_b32_e32 v32, v31                                     // 000000556524: 7E40031F
	s_waitcnt lgkmcnt(0)                                       // 000000556528: BF89FC07
	v_dot2_f32_bf16 v0, v72, v42, v0                           // 00000055652C: CC1A4000 1C025548
	v_dot2_f32_bf16 v1, v76, v42, v1                           // 000000556534: CC1A4001 1C06554C
	v_dot2_f32_bf16 v2, v80, v42, v2                           // 00000055653C: CC1A4002 1C0A5550
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000556544: BF870193
	v_fmac_f32_e32 v28, v82, v0                                // 000000556548: 56380152
	v_fmac_f32_e32 v27, v82, v1                                // 00000055654C: 56360352
	s_delay_alu instid0(VALU_DEP_3)                            // 000000556550: BF870003
	v_dual_fmac_f32 v25, v82, v2 :: v_dual_mov_b32 v0, v33     // 000000556554: C8100552 19000121
	v_dual_mov_b32 v1, v34 :: v_dual_mov_b32 v2, v35           // 00000055655C: CA100122 01020123
	v_dual_mov_b32 v3, v36 :: v_dual_mov_b32 v4, v37           // 000000556564: CA100124 03040125
	v_dual_mov_b32 v5, v38 :: v_dual_mov_b32 v6, v39           // 00000055656C: CA100126 05060127
	v_mov_b32_e32 v7, v40                                      // 000000556574: 7E0E0328
	s_and_not1_b32 exec_lo, exec_lo, s14                       // 000000556578: 917E0E7E
	s_cbranch_execz 28                                         // 00000055657C: BFA5001C <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi16ELi1ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x9f0>
	s_waitcnt vmcnt(0)                                         // 000000556580: BF8903F7
	v_dual_mov_b32 v13, v9 :: v_dual_add_nc_u32 v30, 16, v30   // 000000556584: CA200109 0D1E3C90
	v_dual_mov_b32 v12, v8 :: v_dual_mov_b32 v15, v11          // 00000055658C: CA100108 0C0E010B
	v_mov_b32_e32 v14, v10                                     // 000000556594: 7E1C030A
	s_delay_alu instid0(VALU_DEP_3)                            // 000000556598: BF870003
	.long 0xd4430002                                           // 00000055659C: D4430002
	v_cndmask_b32_e32 v1, s20, v30, vcc_lo                     // 0000005565A0: 02023C14
	s_mov_b32 s15, exec_lo                                     // 0000005565A4: BE8F007E
	.long 0xd4c4007e                                           // 0000005565A8: D4C4007E
	v_cndmask_b32_e32 v1, s20, v30, vcc_lo                     // 0000005565AC: 02023C14
	s_cbranch_execz 65235                                      // 0000005565B0: BFA5FED3 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi16ELi1ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x500>
	.long 0xd7006a0c                                           // 0000005565B4: D7006A0C
	v_cndmask_b32_e32 v1, v18, v29, vcc_lo                     // 0000005565B8: 02023B12
	s_delay_alu instid0(VALU_DEP_1)                            // 0000005565BC: BF870001
	v_add_co_ci_u32_e64 v13, null, 0, v26, vcc_lo              // 0000005565C0: D5207C0D 01AA3480
	v_cmp_ne_u32_e32 vcc_lo, 1, v24                            // 0000005565C8: 7C9A3081
	v_mov_b32_e32 v31, v32                                     // 0000005565CC: 7E3E0320
	global_load_b128 v[12:15], v[12:13], off                   // 0000005565D0: DC5E0000 0C7C000C
	s_cbranch_vccnz 65225                                      // 0000005565D8: BFA4FEC9 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi16ELi1ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x500>
	global_load_d16_b16 v31, v[21:22], off                     // 0000005565DC: DC820000 1F7C0015
	s_waitcnt vmcnt(0)                                         // 0000005565E4: BF8903F7
	v_cvt_f32_f16_e32 v31, v31                                 // 0000005565E8: 7E3E171F
	s_branch 65220                                             // 0000005565EC: BFA0FEC4 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi16ELi1ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x500>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000005565F0: 8C7E0E7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000005565F4: BF8700A9
	s_or_b32 exec_lo, exec_lo, s3                              // 0000005565F8: 8C7E037E
	.long 0xd71f0000                                           // 0000005565FC: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 000000556600: 020100C1
	v_xor_b32_e32 v1, 8, v0                                    // 000000556604: 3A020088
	v_xor_b32_e32 v4, 4, v0                                    // 000000556608: 3A080084
	v_xor_b32_e32 v7, 2, v0                                    // 00000055660C: 3A0E0082
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000556610: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v1                            // 000000556614: 7C9802A0
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 000000556618: 02020300
	v_cmp_gt_u32_e32 vcc_lo, 32, v4                            // 00000055661C: 7C9808A0
	v_cndmask_b32_e32 v4, v0, v4, vcc_lo                       // 000000556620: 02080900
	v_cmp_gt_u32_e32 vcc_lo, 32, v7                            // 000000556624: 7C980EA0
	s_delay_alu instid0(VALU_DEP_2)                            // 000000556628: BF870002
	v_lshlrev_b32_e32 v4, 2, v4                                // 00000055662C: 30080882
	v_lshlrev_b32_e32 v1, 2, v1                                // 000000556630: 30020282
	ds_bpermute_b32 v2, v1, v28                                // 000000556634: DACC0000 02001C01
	s_waitcnt lgkmcnt(0)                                       // 00000055663C: BF89FC07
	v_add_f32_e32 v2, v28, v2                                  // 000000556640: 0604051C
	ds_bpermute_b32 v3, v1, v27                                // 000000556644: DACC0000 03001B01
	ds_bpermute_b32 v1, v1, v25                                // 00000055664C: DACC0000 01001901
	ds_bpermute_b32 v5, v4, v2                                 // 000000556654: DACC0000 05000204
	v_cndmask_b32_e32 v7, v0, v7, vcc_lo                       // 00000055665C: 020E0F00
	s_waitcnt lgkmcnt(2)                                       // 000000556660: BF89FC27
	v_add_f32_e32 v3, v27, v3                                  // 000000556664: 0606071B
	s_waitcnt lgkmcnt(1)                                       // 000000556668: BF89FC17
	v_add_f32_e32 v1, v25, v1                                  // 00000055666C: 06020319
	s_waitcnt lgkmcnt(0)                                       // 000000556670: BF89FC07
	v_add_f32_e32 v2, v2, v5                                   // 000000556674: 06040B02
	ds_bpermute_b32 v6, v4, v3                                 // 000000556678: DACC0000 06000304
	ds_bpermute_b32 v4, v4, v1                                 // 000000556680: DACC0000 04000104
	v_lshlrev_b32_e32 v7, 2, v7                                // 000000556688: 300E0E82
	s_waitcnt lgkmcnt(1)                                       // 00000055668C: BF89FC17
	v_add_f32_e32 v3, v3, v6                                   // 000000556690: 06060D03
	s_waitcnt lgkmcnt(0)                                       // 000000556694: BF89FC07
	v_add_f32_e32 v1, v1, v4                                   // 000000556698: 06020901
	ds_bpermute_b32 v4, v7, v2                                 // 00000055669C: DACC0000 04000207
	s_waitcnt lgkmcnt(0)                                       // 0000005566A4: BF89FC07
	v_add_f32_e32 v2, v2, v4                                   // 0000005566A8: 06040902
	ds_bpermute_b32 v5, v7, v3                                 // 0000005566AC: DACC0000 05000307
	ds_bpermute_b32 v6, v7, v1                                 // 0000005566B4: DACC0000 06000107
	v_xor_b32_e32 v7, 1, v0                                    // 0000005566BC: 3A0E0081
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000005566C0: BF870131
	v_cmp_gt_u32_e32 vcc_lo, 32, v7                            // 0000005566C4: 7C980EA0
	v_cndmask_b32_e32 v0, v0, v7, vcc_lo                       // 0000005566C8: 02000F00
	v_cmp_eq_u32_e32 vcc_lo, 0, v23                            // 0000005566CC: 7C942E80
	v_lshlrev_b32_e32 v7, 2, v0                                // 0000005566D0: 300E0082
	s_and_b32 s0, vcc_lo, s0                                   // 0000005566D4: 8B00006A
	s_waitcnt lgkmcnt(0)                                       // 0000005566D8: BF89FC07
	v_dual_add_f32 v3, v3, v5 :: v_dual_add_f32 v0, v1, v6     // 0000005566DC: C9080B03 03000D01
	ds_bpermute_b32 v4, v7, v2                                 // 0000005566E4: DACC0000 04000207
	ds_bpermute_b32 v5, v7, v3                                 // 0000005566EC: DACC0000 05000307
	ds_bpermute_b32 v1, v7, v0                                 // 0000005566F4: DACC0000 01000007
	s_and_saveexec_b32 s1, s0                                  // 0000005566FC: BE812000
	s_cbranch_execz 49                                         // 000000556700: BFA50031 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi16ELi1ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0xbc8>
	s_waitcnt lgkmcnt(1)                                       // 000000556704: BF89FC17
	v_dual_add_f32 v5, v3, v5 :: v_dual_add_f32 v4, v2, v4     // 000000556708: C9080B03 05040902
	.long 0x7f0c3880                                           // 000000556710: 7F0C3880
	.long 0xd73c0002                                           // 000000556714: D73C0002
	v_cndmask_b32_e32 v1, 1, v16, vcc_lo                       // 000000556718: 02022081
	s_lshl_b64 s[0:1], s[12:13], 1                             // 00000055671C: 8480810C
	s_delay_alu instid0(VALU_DEP_3)                            // 000000556720: BF870003
	.long 0x7e0c3985                                           // 000000556724: 7E0C3985
	.long 0x7e0e3984                                           // 000000556728: 7E0E3984
	.long 0x7f0e3986                                           // 00000055672C: 7F0E3986
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000556730: BF890007
	v_add_f32_e32 v8, v0, v1                                   // 000000556734: 06100300
	.long 0xd7006a00                                           // 000000556738: D7006A00
	v_cndmask_b32_e32 v1, s8, v2, vcc_lo                       // 00000055673C: 02020408
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000556740: BF870231
	v_add_co_ci_u32_e64 v1, null, s9, v3, vcc_lo               // 000000556744: D5207C01 01AA0609
	v_and_b32_e32 v7, 1, v7                                    // 00000055674C: 360E0E81
	v_and_b32_e32 v6, 1, v6                                    // 000000556750: 360C0C81
	.long 0xd7006a02                                           // 000000556754: D7006A02
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 000000556758: 02000100
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000055675C: BF870211
	v_add_co_ci_u32_e64 v3, null, s1, v1, vcc_lo               // 000000556760: D5207C03 01AA0201
	v_add3_u32 v7, v4, v7, 0x7fff                              // 000000556768: D6550007 03FE0F04 00007FFF
	v_bfe_u32 v4, v8, 16, 1                                    // 000000556774: D6100004 02052108
	s_lshl_b64 s[0:1], s[12:13], 2                             // 00000055677C: 8480820C
	v_add3_u32 v6, v5, v6, 0x7fff                              // 000000556780: D6550006 03FE0D05 00007FFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000055678C: BF8700A2
	v_add3_u32 v8, v8, v4, 0x7fff                              // 000000556790: D6550008 03FE0908 00007FFF
	.long 0xd7006a04                                           // 00000055679C: D7006A04
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 0000005567A0: 02000100
	v_add_co_ci_u32_e64 v5, null, s1, v1, vcc_lo               // 0000005567A4: D5207C05 01AA0201
	s_clause 0x2                                               // 0000005567AC: BF850002
	global_store_d16_hi_b16 v[0:1], v7, off                    // 0000005567B0: DC960000 007C0700
	global_store_d16_hi_b16 v[2:3], v6, off                    // 0000005567B8: DC960000 007C0602
	global_store_d16_hi_b16 v[4:5], v8, off                    // 0000005567C0: DC960000 007C0804
	s_endpgm                                                   // 0000005567C8: BFB00000
		...

