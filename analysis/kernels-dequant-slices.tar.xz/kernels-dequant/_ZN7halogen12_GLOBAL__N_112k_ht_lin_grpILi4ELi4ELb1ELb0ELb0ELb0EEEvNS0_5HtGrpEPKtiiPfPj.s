0000000000431000 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi4ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj>:
; _ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi4ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj():
	s_clause 0x1                                               // 000000431000: BF850001
	s_load_b64 s[4:5], s[0:1], 0x130                           // 000000431004: F4040100 F8000130
	s_load_b128 s[16:19], s[0:1], 0x198                        // 00000043100C: F4080400 F8000198
	s_waitcnt lgkmcnt(0)                                       // 000000431014: BF89FC07
	s_cmp_eq_u64 s[4:5], 0                                     // 000000431018: BF108004
	s_cbranch_scc1 246                                         // 00000043101C: BFA200F6 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi4ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3f8>
	s_load_b32 s6, s[0:1], 0x138                               // 000000431020: F4000180 F8000138
	s_waitcnt lgkmcnt(0)                                       // 000000431028: BF89FC07
	s_cmp_lt_i32 s2, s6                                        // 00000043102C: BF040602
	s_cselect_b32 s3, -1, 0                                    // 000000431030: 980380C1
	s_cmp_ge_i32 s2, s6                                        // 000000431034: BF030602
	s_cbranch_scc0 233                                         // 000000431038: BFA100E9 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi4ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3e0>
	v_lshrrev_b32_e32 v1, 5, v0                                // 00000043103C: 32020085
	s_sub_i32 s6, s2, s6                                       // 000000431040: 81860602
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 000000431044: BF870481
	v_lshl_or_b32 v1, s6, 3, v1                                // 000000431048: D6560001 04050606
	s_mul_i32 s6, s18, 20                                      // 000000431050: 96069412
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 000000431054: BF870481
	v_cmp_gt_i32_e32 vcc_lo, s6, v1                            // 000000431058: 7C880206
	s_and_saveexec_b32 s6, vcc_lo                              // 00000043105C: BE86206A
	s_cbranch_execz 222                                        // 000000431060: BFA500DE <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi4ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3dc>
	.long 0xd72e0002                                           // 000000431064: D72E0002
	v_cndmask_b32_e32 v1, 0x66666667, v1, vcc_lo               // 000000431068: 020202FF 66666667
	v_and_b32_e32 v9, 31, v0                                   // 000000431070: 3612009F
	s_load_b64 s[8:9], s[0:1], 0x128                           // 000000431074: F4040200 F8000128
	s_mov_b32 s7, 0x76543210                                   // 00000043107C: BE8700FF 76543210
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000431084: BF8700A2
	v_lshrrev_b32_e32 v3, 31, v2                               // 000000431088: 3206049F
	v_ashrrev_i32_e32 v2, 3, v2                                // 00000043108C: 34040483
	v_add_nc_u32_e32 v8, v2, v3                                // 000000431090: 4A100702
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000431094: BF870121
	.long 0xd72c0002                                           // 000000431098: D72C0002
	v_cndmask_b32_e32 v1, 0xffffffec, v8, vcc_lo               // 00000043109C: 020210FF FFFFFFEC
	v_mad_i64_i32 v[4:5], null, 0x1400, v8, s[16:17]           // 0000004310A4: D6FF7C04 004210FF 00001400
	v_add_lshl_u32 v1, v2, v1, 7                               // 0000004310B0: D6470001 021E0302
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004310B8: BF870091
	v_lshl_or_b32 v2, v9, 2, v1                                // 0000004310BC: D6560002 04050509
	v_ashrrev_i32_e32 v3, 31, v2                               // 0000004310C4: 3406049F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004310C8: BF870091
	.long 0xd73c0002                                           // 0000004310CC: D73C0002
	v_cndmask_b32_e32 v1, 1, v2, vcc_lo                        // 0000004310D0: 02020481
	.long 0xd7006a04                                           // 0000004310D4: D7006A04
	v_cndmask_b32_e32 v1, v4, v2, vcc_lo                       // 0000004310D8: 02020504
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000004310DC: BF8700B1
	v_add_co_ci_u32_e64 v5, null, v5, v3, vcc_lo               // 0000004310E0: D5207C05 01AA0705
	s_waitcnt lgkmcnt(0)                                       // 0000004310E8: BF89FC07
	.long 0xd7006a02                                           // 0000004310EC: D7006A02
	v_cndmask_b32_e32 v1, s8, v2, vcc_lo                       // 0000004310F0: 02020408
	v_add_co_ci_u32_e64 v3, null, s9, v3, vcc_lo               // 0000004310F4: D5207C03 01AA0609
	global_load_b64 v[4:5], v[4:5], off                        // 0000004310FC: DC560000 047C0004
	s_mov_b32 s8, 0x3db504f3                                   // 000000431104: BE8800FF 3DB504F3
	global_load_b64 v[6:7], v[2:3], off                        // 00000043110C: DC560000 067C0002
	s_waitcnt vmcnt(1)                                         // 000000431114: BF8907F7
	.long 0x7e043904                                           // 000000431118: 7E043904
	v_and_b32_e32 v3, 0xffff0000, v4                           // 00000043111C: 360608FF FFFF0000
	.long 0x7e083905                                           // 000000431124: 7E083905
	v_and_b32_e32 v5, 0xffff0000, v5                           // 000000431128: 360A0AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_4)                            // 000000431130: BF870004
	v_lshlrev_b32_e32 v14, 16, v2                              // 000000431134: 301C0490
	s_waitcnt vmcnt(0)                                         // 000000431138: BF8903F7
	v_fma_mix_f32 v3, v6, v3, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 00000043113C: CC200803 8A020706
	v_lshlrev_b32_e32 v4, 16, v4                               // 000000431144: 30080890
	v_fma_mix_f32 v5, v7, v5, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000431148: CC200805 8A020B07
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000431150: 3404029F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000431154: BF870224
	v_fma_mix_f32 v15, v6, v14, v3 op_sel_hi:[1,0,0]           // 000000431158: CC20000F 0C0E1D06
	v_fma_mix_f32 v6, v6, v14, -v3 op_sel_hi:[1,0,0]           // 000000431160: CC200006 8C0E1D06
	v_fma_mix_f32 v14, v7, v4, v5 op_sel_hi:[1,0,0]            // 000000431168: CC20000E 0C160907
	v_fma_mix_f32 v5, v7, v4, -v5 op_sel_hi:[1,0,0]            // 000000431170: CC200005 8C160907
	v_and_b32_e32 v10, 1, v0                                   // 000000431178: 36140081
	v_and_b32_e32 v11, 2, v0                                   // 00000043117C: 36160082
	v_and_b32_e32 v13, 8, v0                                   // 000000431180: 361A0088
	.long 0xd73c0001                                           // 000000431184: D73C0001
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 000000431188: 02020281
	v_add_f32_e32 v16, v6, v5                                  // 00000043118C: 06200B06
	v_sub_f32_e32 v5, v6, v5                                   // 000000431190: 080A0B06
	v_cmp_eq_u32_e32 vcc_lo, 0, v10                            // 000000431194: 7C941480
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000431198: BF870193
	v_mov_b32_dpp v10, v16 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000043119C: 7E1402FA FF016110
	v_mov_b32_dpp v17, v5 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000004311A4: 7E2202FA FF016105
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 0000004311AC: D5010005 21AA0B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_3)// 0000004311B4: BF8701D1
	v_add_f32_e32 v5, v5, v17                                  // 0000004311B8: 060A2305
	v_mad_i64_i32 v[3:4], null, 0x1400, v8, s[4:5]             // 0000004311BC: D6FF7C03 001210FF 00001400
	v_add_f32_e32 v8, v15, v14                                 // 0000004311C8: 06101D0F
	v_sub_f32_e32 v14, v15, v14                                // 0000004311CC: 081C1D0F
	v_cndmask_b32_e64 v15, -v16, v16, vcc_lo                   // 0000004311D0: D501000F 21AA2110
	v_mov_b32_dpp v6, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000004311D8: 7E0C02FA FF016108
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 0000004311E0: D5010008 21AA1108
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000004311E8: BF870234
	v_mov_b32_dpp v16, v14 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000004311EC: 7E2002FA FF01610E
	v_cndmask_b32_e64 v14, -v14, v14, vcc_lo                   // 0000004311F4: D501000E 21AA1D0E
	v_cmp_eq_u32_e32 vcc_lo, 0, v11                            // 0000004311FC: 7C941680
	v_dual_add_f32 v6, v8, v6 :: v_dual_lshlrev_b32 v7, 3, v9  // 000000431200: C9220D08 06061283
	v_add_f32_e32 v8, v15, v10                                 // 000000431208: 0610150F
	s_delay_alu instid0(VALU_DEP_4)                            // 00000043120C: BF870004
	v_add_f32_e32 v10, v14, v16                                // 000000431210: 0614210E
	v_mov_b32_dpp v16, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000431214: 7E2002FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 00000043121C: D5010005 21AA0B05
	v_mov_b32_dpp v11, v6 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000431224: 7E1602FA FF016206
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 00000043122C: D5010006 21AA0D06
	v_mov_b32_dpp v15, v10 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000431234: 7E1E02FA FF01620A
	v_cndmask_b32_e64 v10, -v10, v10, vcc_lo                   // 00000043123C: D501000A 21AA150A
	v_add_f32_e32 v5, v5, v16                                  // 000000431244: 060A2105
	v_mov_b32_dpp v14, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000431248: 7E1C02FA FF016208
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 000000431250: D5010008 21AA1108
	v_add_f32_e32 v6, v6, v11                                  // 000000431258: 060C1706
	v_add_f32_e32 v10, v10, v15                                // 00000043125C: 06141F0A
	v_mov_b32_dpp v15, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000431260: 7E1E02FA FF016405
	v_and_b32_e32 v12, 4, v0                                   // 000000431268: 36180084
	v_add_f32_e32 v8, v8, v14                                  // 00000043126C: 06101D08
	v_mov_b32_dpp v11, v6 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000431270: 7E1602FA FF016406
	v_mov_b32_dpp v14, v10 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000431278: 7E1C02FA FF01640A
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000431280: BF8701C4
	v_cmp_eq_u32_e32 vcc_lo, 0, v12                            // 000000431284: 7C941880
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 000000431288: D5010006 21AA0D06
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 000000431290: D5010005 21AA0B05
	v_cndmask_b32_e64 v10, -v10, v10, vcc_lo                   // 000000431298: D501000A 21AA150A
	v_add_f32_e32 v6, v6, v11                                  // 0000004312A0: 060C1706
	s_delay_alu instid0(VALU_DEP_3)                            // 0000004312A4: BF870003
	v_add_f32_e32 v5, v5, v15                                  // 0000004312A8: 060A1F05
	v_mov_b32_dpp v12, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000004312AC: 7E1802FA FF016408
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 0000004312B4: D5010008 21AA1108
	v_cmp_eq_u32_e32 vcc_lo, 0, v13                            // 0000004312BC: 7C941A80
	v_add_f32_e32 v10, v10, v14                                // 0000004312C0: 06141D0A
	v_mov_b32_dpp v11, v6 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000004312C4: 7E1602FA FF016806
	v_mov_b32_dpp v14, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000004312CC: 7E1C02FA FF016805
	v_add_f32_e32 v8, v8, v12                                  // 0000004312D4: 06101908
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 0000004312D8: D5010006 21AA0D06
	v_mov_b32_dpp v13, v10 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000004312E0: 7E1A02FA FF01680A
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 0000004312E8: D5010005 21AA0B05
	v_cndmask_b32_e64 v10, -v10, v10, vcc_lo                   // 0000004312F0: D501000A 21AA150A
	v_mov_b32_dpp v12, v8 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000004312F8: 7E1802FA FF016808
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 000000431300: D5010008 21AA1108
	v_add_f32_e32 v6, v6, v11                                  // 000000431308: 060C1706
	v_cmp_gt_u32_e32 vcc_lo, 16, v9                            // 00000043130C: 7C981290
	v_add_f32_e32 v5, v5, v14                                  // 000000431310: 060A1D05
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000431314: BF870214
	v_dual_add_f32 v9, v10, v13 :: v_dual_add_f32 v8, v8, v12  // 000000431318: C9081B0A 09081908
	v_mov_b32_e32 v10, v6                                      // 000000431320: 7E140306
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 000000431324: D5010006 21AA0D06
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000043132C: BF870214
	v_mov_b32_e32 v13, v5                                      // 000000431330: 7E1A0305
	v_mov_b32_e32 v12, v9                                      // 000000431334: 7E180309
	v_cndmask_b32_e64 v11, -v8, v8, vcc_lo                     // 000000431338: D501000B 21AA1108
	v_permlanex16_b32 v8, v8, s7, 0xfedcba98                   // 000000431340: D65C0008 03FC0F08 FEDCBA98
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 00000043134C: D5010005 21AA0B05
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 000000431354: D5010009 21AA1309
	v_permlanex16_b32 v10, v10, s7, 0xfedcba98                 // 00000043135C: D65C000A 03FC0F0A FEDCBA98
	v_permlanex16_b32 v12, v12, s7, 0xfedcba98                 // 000000431368: D65C000C 03FC0F0C FEDCBA98
	v_permlanex16_b32 v13, v13, s7, 0xfedcba98                 // 000000431374: D65C000D 03FC0F0D FEDCBA98
	.long 0xd7006a01                                           // 000000431380: D7006A01
	v_cndmask_b32_e32 v1, v3, v1, vcc_lo                       // 000000431384: 02020303
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000431388: BF8700D1
	v_add_co_ci_u32_e64 v2, null, v4, v2, vcc_lo               // 00000043138C: D5207C02 01AA0504
	v_dual_add_f32 v3, v11, v8 :: v_dual_add_f32 v4, v6, v10   // 000000431394: C908110B 03041506
	v_add_f32_e32 v6, v9, v12                                  // 00000043139C: 060C1909
	v_add_f32_e32 v5, v5, v13                                  // 0000004313A0: 060A1B05
	.long 0xd7006a01                                           // 0000004313A4: D7006A01
	v_cndmask_b32_e32 v1, v1, v7, vcc_lo                       // 0000004313A8: 02020F01
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 0000004313AC: D5207C02 01AA0480
	v_fma_mixhi_f16 v3, v3, s8, 0                              // 0000004313B4: CC220003 02001103
	v_fma_mixlo_f16 v3, v4, s8, 0                              // 0000004313BC: CC210003 02001104
	v_fma_mixhi_f16 v4, v5, s8, 0                              // 0000004313C4: CC220004 02001105
	v_fma_mixlo_f16 v4, v6, s8, 0                              // 0000004313CC: CC210004 02001106
	global_store_b64 v[1:2], v[3:4], off                       // 0000004313D4: DC6E0000 007C0301
	s_or_b32 exec_lo, exec_lo, s6                              // 0000004313DC: 8C7E067E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000004313E0: BF870009
	s_and_b32 vcc_lo, exec_lo, s3                              // 0000004313E4: 8B6A037E
	s_cbranch_vccnz 4                                          // 0000004313E8: BFA40004 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi4ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3fc>
	s_nop 0                                                    // 0000004313EC: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 0000004313F0: BFB60003
	s_endpgm                                                   // 0000004313F4: BFB00000
	s_cbranch_execz 65532                                      // 0000004313F8: BFA5FFFC <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi4ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3ec>
	s_clause 0x3                                               // 0000004313FC: BF850003
	s_load_b32 s3, s[0:1], 0x120                               // 000000431400: F40000C0 F8000120
	s_load_b32 s4, s[0:1], 0x7c                                // 000000431408: F4000100 F800007C
	s_load_b32 s5, s[0:1], 0xc4                                // 000000431410: F4000140 F80000C4
	s_load_b32 s6, s[0:1], 0x10c                               // 000000431418: F4000180 F800010C
	v_lshrrev_b32_e32 v19, 5, v0                               // 000000431420: 32260085
	v_and_b32_e32 v20, 31, v0                                  // 000000431424: 3628009F
	s_mov_b32 s33, 0                                           // 000000431428: BEA10080
	s_mov_b32 s31, exec_lo                                     // 00000043142C: BE9F007E
	s_waitcnt lgkmcnt(0)                                       // 000000431430: BF89FC07
	s_cmp_gt_i32 s3, 1                                         // 000000431434: BF028103
	s_cselect_b32 s7, -1, 0                                    // 000000431438: 980780C1
	s_cmp_ge_i32 s2, s4                                        // 00000043143C: BF030402
	s_cselect_b32 s4, -1, 0                                    // 000000431440: 980480C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000431444: BF870009
	s_and_b32 s4, s7, s4                                       // 000000431448: 8B040407
	s_cmp_gt_i32 s3, 2                                         // 00000043144C: BF028203
	v_cndmask_b32_e64 v1, 0, 1, s4                             // 000000431450: D5010001 00110280
	s_cselect_b32 s7, -1, 0                                    // 000000431458: 980780C1
	s_cmp_ge_i32 s2, s5                                        // 00000043145C: BF030502
	s_cselect_b32 s5, -1, 0                                    // 000000431460: 980580C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000431464: BF870009
	s_and_b32 s4, s7, s5                                       // 000000431468: 8B040507
	s_cmp_gt_i32 s3, 3                                         // 00000043146C: BF028303
	v_readfirstlane_b32 s5, v1                                 // 000000431470: 7E0A0501
	s_cselect_b32 s3, -1, 0                                    // 000000431474: 980380C1
	s_cmp_ge_i32 s2, s6                                        // 000000431478: BF030602
	s_cselect_b32 s6, -1, 0                                    // 00000043147C: 980680C1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(SALU_CYCLE_1)// 000000431480: BF8704D9
	s_and_b32 s3, s3, s6                                       // 000000431484: 8B030603
	s_and_b32 s4, s4, exec_lo                                  // 000000431488: 8B047E04
	s_cselect_b32 s4, 2, s5                                    // 00000043148C: 98040582
	s_and_b32 s3, s3, exec_lo                                  // 000000431490: 8B037E03
	s_cselect_b32 s3, 3, s4                                    // 000000431494: 98030483
	s_mulk_i32 s3, 0x48                                        // 000000431498: B8030048
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000043149C: BF870009
	s_add_u32 s4, s0, s3                                       // 0000004314A0: 80040300
	s_addc_u32 s5, s1, 0                                       // 0000004314A4: 82058001
	s_clause 0x3                                               // 0000004314A8: BF850003
	s_load_b32 s30, s[4:5], 0x38                               // 0000004314AC: F4000782 F8000038
	s_load_b64 s[28:29], s[4:5], 0x40                          // 0000004314B4: F4040702 F8000040
	s_load_b128 s[20:23], s[4:5], 0x28                         // 0000004314BC: F4080502 F8000028
	s_load_b64 s[24:25], s[4:5], 0x20                          // 0000004314C4: F4040602 F8000020
	s_waitcnt lgkmcnt(0)                                       // 0000004314CC: BF89FC07
	s_abs_i32 s3, s21                                          // 0000004314D0: BE831515
	s_sub_i32 s34, s2, s23                                     // 0000004314D4: 81A21702
	s_cvt_f32_u32 s6, s3                                       // 0000004314D8: BE866503
	s_sub_i32 s7, 0, s3                                        // 0000004314DC: 81870380
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000004314E0: BF87029A
	v_rcp_iflag_f32_e32 v1, s6                                 // 0000004314E4: 7E025606
	v_readfirstlane_b32 s6, v1                                 // 0000004314E8: 7E0C0501
	s_mul_f32 s6, s6, 0x4f7ffffe                               // 0000004314EC: A206FF06 4F7FFFFE
	s_delay_alu instid0(SALU_CYCLE_3) | instskip(NEXT) | instid1(SALU_CYCLE_3)// 0000004314F4: BF87059B
	s_cvt_u32_f32 s6, s6                                       // 0000004314F8: BE866706
	s_mul_i32 s7, s7, s6                                       // 0000004314FC: 96070607
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 000000431500: BF8704B9
	s_mul_hi_u32 s2, s6, s7                                    // 000000431504: 96820706
	s_abs_i32 s7, s34                                          // 000000431508: BE871522
	s_add_i32 s6, s6, s2                                       // 00000043150C: 81060206
	s_mul_hi_u32 s2, s7, s6                                    // 000000431510: 96820607
	s_xor_b32 s6, s34, s21                                     // 000000431514: 8D061522
	s_mul_i32 s8, s2, s3                                       // 000000431518: 96080302
	s_ashr_i32 s6, s6, 31                                      // 00000043151C: 86069F06
	s_sub_i32 s7, s7, s8                                       // 000000431520: 81870807
	s_add_i32 s8, s2, 1                                        // 000000431524: 81088102
	s_sub_i32 s9, s7, s3                                       // 000000431528: 81890307
	s_cmp_ge_u32 s7, s3                                        // 00000043152C: BF090307
	s_cselect_b32 s2, s8, s2                                   // 000000431530: 98020208
	s_cselect_b32 s7, s9, s7                                   // 000000431534: 98070709
	s_add_i32 s8, s2, 1                                        // 000000431538: 81088102
	s_cmp_ge_u32 s7, s3                                        // 00000043153C: BF090307
	s_cselect_b32 s2, s8, s2                                   // 000000431540: 98020208
	s_load_b256 s[8:15], s[4:5], null                          // 000000431544: F40C0202 F8000000
	s_xor_b32 s2, s2, s6                                       // 00000043154C: 8D020602
	s_ashr_i32 s23, s19, 31                                    // 000000431550: 86179F13
	s_sub_i32 s26, s2, s6                                      // 000000431554: 819A0602
	s_lshr_b32 s2, s23, 25                                     // 000000431558: 85029917
	s_mul_i32 s36, s26, s21                                    // 00000043155C: 9624151A
	s_add_i32 s2, s19, s2                                      // 000000431560: 81020213
	s_sub_i32 s3, s34, s36                                     // 000000431564: 81832422
	s_ashr_i32 s2, s2, 7                                       // 000000431568: 86028702
	s_mul_i32 s27, s22, s3                                     // 00000043156C: 961B0316
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000431570: BF870499
	s_add_i32 s3, s27, s22                                     // 000000431574: 8103161B
	s_min_i32 s2, s2, s3                                       // 000000431578: 89020302
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000043157C: BF870499
	s_sub_i32 s7, s2, s27                                      // 000000431580: 81871B02
	s_lshl_b32 s22, s7, 2                                      // 000000431584: 84168207
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000431588: BF870009
	.long 0xd4c4007e                                           // 00000043158C: D4C4007E
	v_cndmask_b32_e32 v1, s22, v19, vcc_lo                     // 000000431590: 02022616
	s_cbranch_execz 289                                        // 000000431594: BFA50121 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi4ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0xa1c>
	s_abs_i32 s35, s7                                          // 000000431598: BEA31507
	v_lshlrev_b32_e32 v7, 3, v20                               // 00000043159C: 300E2883
	s_cvt_f32_u32 s2, s35                                      // 0000004315A0: BE826523
	v_lshlrev_b32_e32 v8, 7, v19                               // 0000004315A4: 30102687
	v_and_b32_e32 v3, 2, v0                                    // 0000004315A8: 36060082
	v_and_b32_e32 v5, 8, v0                                    // 0000004315AC: 360A0088
	v_rcp_iflag_f32_e32 v1, s2                                 // 0000004315B0: 7E025602
	s_sub_i32 s2, 0, s35                                       // 0000004315B4: 81822380
	s_ashr_i32 s39, s7, 31                                     // 0000004315B8: 86279F07
	.long 0xd44a0003                                           // 0000004315BC: D44A0003
	v_cndmask_b32_e32 v1, 0, v3, vcc_lo                        // 0000004315C0: 02020680
	s_mul_i32 s41, s39, 0x1400                                 // 0000004315C4: 9629FF27 00001400
	.long 0xd44a0005                                           // 0000004315CC: D44A0005
	v_cndmask_b32_e32 v1, 0, v5, vcc_lo                        // 0000004315D0: 02020A80
	s_lshl_b32 s6, s7, 7                                       // 0000004315D4: 84068707
	s_add_i32 s37, s18, -1                                     // 0000004315D8: 8125C112
	s_mov_b32 s38, s19                                         // 0000004315DC: BEA60013
	s_lshl_b32 s40, s7, 8                                      // 0000004315E0: 84288807
	v_dual_mul_f32 v1, 0x4f7ffffe, v1 :: v_dual_and_b32 v2, 1, v0// 0000004315E4: C8E402FF 01020081 4F7FFFFE
	s_mov_b32 s42, 0x76543210                                  // 0000004315F0: BEAA00FF 76543210
	s_mov_b32 s43, 0x3db504f3                                  // 0000004315F8: BEAB00FF 3DB504F3
	v_cmp_gt_u32_e32 vcc_lo, 16, v20                           // 000000431600: 7C982890
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000431604: BF870122
	v_cvt_u32_f32_e32 v4, v1                                   // 000000431608: 7E080F01
	v_and_b32_e32 v1, 4, v0                                    // 00000043160C: 36020084
	.long 0xd72c0006                                           // 000000431610: D72C0006
	v_cndmask_b32_e32 v1, s2, v4, vcc_lo                       // 000000431614: 02020802
	.long 0xd44a0002                                           // 000000431618: D44A0002
	v_cndmask_b32_e32 v1, 0, v2, vcc_lo                        // 00000043161C: 02020480
	v_lshl_or_b32 v2, v19, 8, v7                               // 000000431620: D6560002 041D1113
	v_lshl_add_u32 v7, s27, 7, v8                              // 000000431628: D6460007 04210E1B
	.long 0xd44a0004                                           // 000000431630: D44A0004
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 000000431634: 02020280
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000431638: BF870223
	v_subrev_nc_u32_e32 v2, s41, v2                            // 00000043163C: 4E040429
	.long 0xd72d0006                                           // 000000431640: D72D0006
	v_cndmask_b32_e32 v1, v4, v6, vcc_lo                       // 000000431644: 02020D04
	v_lshl_or_b32 v1, v20, 2, v7                               // 000000431648: D6560001 041D0514
	s_sub_i32 s41, 0, s6                                       // 000000431650: 81A90680
	s_delay_alu instid0(VALU_DEP_2)                            // 000000431654: BF870002
	v_dual_mov_b32 v4, v19 :: v_dual_add_nc_u32 v3, v4, v6     // 000000431658: CA200113 04020D04
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000431660: BF870091
	.long 0xd72d0005                                           // 000000431664: D72D0005
	v_cndmask_b32_e32 v1, v4, v3, vcc_lo                       // 000000431668: 02020704
	.long 0xd72c0006                                           // 00000043166C: D72C0006
	v_cndmask_b32_e32 v0, v5, v35, vcc_lo                      // 000000431670: 02004705
	v_add_nc_u32_e32 v7, 1, v5                                 // 000000431674: 4A0E0A81
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000431678: BF870092
	v_sub_nc_u32_e32 v6, v4, v6                                // 00000043167C: 4C0C0D04
	v_subrev_nc_u32_e32 v8, s35, v6                            // 000000431680: 4E100C23
	.long 0xd44b0006                                           // 000000431684: D44B0006
	v_cndmask_b32_e32 v1, s35, v6, vcc_lo                      // 000000431688: 02020C23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000043168C: BF870191
	v_cndmask_b32_e64 v5, v5, v7, s6                           // 000000431690: D5010005 001A0F05
	v_cndmask_b32_e64 v6, v6, v8, s6                           // 000000431698: D5010006 001A1106
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000004316A0: BF870112
	v_add_nc_u32_e32 v7, 1, v5                                 // 0000004316A4: 4A0E0A81
	.long 0xd44b0006                                           // 0000004316A8: D44B0006
	v_cndmask_b32_e32 v1, s35, v6, vcc_lo                      // 0000004316AC: 02020C23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004316B0: BF870091
	v_cndmask_b32_e64 v5, v5, v7, s6                           // 0000004316B4: D5010005 001A0F05
	v_xor_b32_e32 v9, s39, v5                                  // 0000004316BC: 3A120A27
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000004316C0: BF870121
	v_subrev_nc_u32_e32 v10, s39, v9                           // 0000004316C4: 4E141227
	.long 0xd72c0009                                           // 0000004316C8: D72C0009
	v_cndmask_b32_e32 v1, 0x1400, v9, vcc_lo                   // 0000004316CC: 020212FF 00001400
	v_min_i32_e32 v7, s37, v10                                 // 0000004316D4: 220E1425
	v_mad_u64_u32 v[5:6], null, s41, v10, v[1:2]               // 0000004316D8: D6FE7C05 04061429
	.long 0xd72c000a                                           // 0000004316E0: D72C000A
	v_cndmask_b32_e32 v1, s40, v10, vcc_lo                     // 0000004316E4: 02021428
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000004316E8: BF870193
	v_mad_i64_i32 v[7:8], null, v7, s38, 0                     // 0000004316EC: D6FF7C07 02004D07
	v_ashrrev_i32_e32 v6, 31, v5                               // 0000004316F4: 340C0A9F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000004316F8: BF870193
	v_sub_nc_u32_e32 v9, v9, v10                               // 0000004316FC: 4C121509
	.long 0xd73c0007                                           // 000000431700: D73C0007
	v_cndmask_b32_e32 v1, 1, v7, vcc_lo                        // 000000431704: 02020E81
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000431708: BF870193
	.long 0xd73c0005                                           // 00000043170C: D73C0005
	v_cndmask_b32_e32 v1, 1, v5, vcc_lo                        // 000000431710: 02020A81
	v_add_nc_u32_e32 v9, v2, v9                                // 000000431714: 4A121302
	v_add_nc_u32_e32 v2, 0x800, v2                             // 000000431718: 4A0404FF 00000800
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000431720: BF870094
	.long 0xd700060b                                           // 000000431724: D700060B
	v_cndmask_b32_e32 v1, s16, v7, vcc_lo                      // 000000431728: 02020E10
	v_add_co_ci_u32_e64 v12, null, s17, v8, s6                 // 00000043172C: D5207C0C 001A1011
	s_waitcnt lgkmcnt(0)                                       // 000000431734: BF89FC07
	.long 0xd7000607                                           // 000000431738: D7000607
	v_cndmask_b32_e32 v1, s10, v5, vcc_lo                      // 00000043173C: 02020A0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000431740: BF8700A1
	v_add_co_ci_u32_e64 v8, null, s11, v6, s6                  // 000000431744: D5207C08 001A0C0B
	.long 0xd7000605                                           // 00000043174C: D7000605
	v_cndmask_b32_e32 v1, v11, v5, vcc_lo                      // 000000431750: 02020B0B
	v_add_co_ci_u32_e64 v6, null, v12, v6, s6                  // 000000431754: D5207C06 001A0D0C
	global_load_b64 v[5:6], v[5:6], off                        // 00000043175C: DC560000 057C0005
	global_load_b64 v[7:8], v[7:8], off                        // 000000431764: DC560000 077C0007
	s_waitcnt vmcnt(1)                                         // 00000043176C: BF8907F7
	.long 0x7e163905                                           // 000000431770: 7E163905
	v_and_b32_e32 v5, 0xffff0000, v5                           // 000000431774: 360A0AFF FFFF0000
	.long 0x7e183906                                           // 00000043177C: 7E183906
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000431780: BF8701A3
	v_lshlrev_b32_e32 v11, 16, v11                             // 000000431784: 30161690
	s_waitcnt vmcnt(0)                                         // 000000431788: BF8903F7
	v_fma_mix_f32 v5, v7, v5, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 00000043178C: CC200805 8A020B07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000431794: BF8701C1
	v_fma_mix_f32 v14, v7, v11, v5 op_sel_hi:[1,0,0]           // 000000431798: CC20000E 0C161707
	v_and_b32_e32 v6, 0xffff0000, v6                           // 0000004317A0: 360C0CFF FFFF0000
	v_fma_mix_f32 v5, v7, v11, -v5 op_sel_hi:[1,0,0]           // 0000004317A8: CC200005 8C161707
	v_lshlrev_b32_e32 v12, 16, v12                             // 0000004317B0: 30181890
	v_fma_mix_f32 v6, v8, v6, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 0000004317B4: CC200806 8A020D08
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000004317BC: BF870121
	v_fma_mix_f32 v13, v8, v12, v6 op_sel_hi:[1,0,0]           // 0000004317C0: CC20000D 0C1A1908
	v_fma_mix_f32 v6, v8, v12, -v6 op_sel_hi:[1,0,0]           // 0000004317C8: CC200006 8C1A1908
	v_dual_add_f32 v7, v14, v13 :: v_dual_add_nc_u32 v4, 8, v4 // 0000004317D0: C9201B0E 07040888
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000004317D8: BF870232
	v_add_f32_e32 v8, v6, v5                                   // 0000004317DC: 06100B06
	v_sub_f32_e32 v11, v14, v13                                // 0000004317E0: 08161B0E
	v_sub_f32_e32 v5, v5, v6                                   // 0000004317E4: 080A0D05
	.long 0xd4430006                                           // 0000004317E8: D4430006
	v_cndmask_b32_e32 v1, s22, v4, vcc_lo                      // 0000004317EC: 02020816
	v_mov_b32_dpp v6, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000004317F0: 7E0C02FA FF016107
	v_mov_b32_dpp v12, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000004317F8: 7E1802FA FF016108
	v_mov_b32_dpp v13, v11 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000431800: 7E1A02FA FF01610B
	v_cndmask_b32_e64 v7, -v7, v7, s2                          // 000000431808: D5010007 200A0F07
	v_cndmask_b32_e64 v8, -v8, v8, s2                          // 000000431810: D5010008 200A1108
	v_cndmask_b32_e64 v11, -v11, v11, s2                       // 000000431818: D501000B 200A170B
	v_add_nc_u32_e32 v1, 0x400, v1                             // 000000431820: 4A0202FF 00000400
	v_mov_b32_dpp v14, v5 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000431828: 7E1C02FA FF016105
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000431830: BF870214
	v_dual_add_f32 v6, v7, v6 :: v_dual_add_f32 v7, v8, v12    // 000000431834: C9080D07 06061908
	v_add_f32_e32 v8, v11, v13                                 // 00000043183C: 06101B0B
	v_cndmask_b32_e64 v5, -v5, v5, s2                          // 000000431840: D5010005 200A0B05
	s_or_b32 s33, s6, s33                                      // 000000431848: 8C212106
	s_delay_alu instid0(VALU_DEP_3)                            // 00000043184C: BF870003
	v_mov_b32_dpp v11, v6 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000431850: 7E1602FA FF016206
	v_mov_b32_dpp v12, v7 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000431858: 7E1802FA FF016207
	v_mov_b32_dpp v13, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000431860: 7E1A02FA FF016208
	v_cndmask_b32_e64 v8, -v8, v8, s3                          // 000000431868: D5010008 200E1108
	v_add_f32_e32 v5, v5, v14                                  // 000000431870: 060A1D05
	v_cndmask_b32_e64 v7, -v7, v7, s3                          // 000000431874: D5010007 200E0F07
	v_cndmask_b32_e64 v6, -v6, v6, s3                          // 00000043187C: D5010006 200E0D06
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000431884: BF870214
	v_add_f32_e32 v8, v8, v13                                  // 000000431888: 06101B08
	v_mov_b32_dpp v14, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000043188C: 7E1C02FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, s3                          // 000000431894: D5010005 200E0B05
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000043189C: BF870214
	v_add_f32_e32 v6, v6, v11                                  // 0000004318A0: 060C1706
	v_mov_b32_dpp v13, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000004318A4: 7E1A02FA FF016408
	v_cndmask_b32_e64 v8, -v8, v8, s4                          // 0000004318AC: D5010008 20121108
	v_add_f32_e32 v7, v7, v12                                  // 0000004318B4: 060E1907
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000004318B8: BF870224
	v_mov_b32_dpp v11, v6 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000004318BC: 7E1602FA FF016406
	v_cndmask_b32_e64 v6, -v6, v6, s4                          // 0000004318C4: D5010006 20120D06
	v_add_f32_e32 v8, v8, v13                                  // 0000004318CC: 06101B08
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000004318D0: BF870224
	v_mov_b32_dpp v12, v7 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000004318D4: 7E1802FA FF016407
	v_cndmask_b32_e64 v7, -v7, v7, s4                          // 0000004318DC: D5010007 20120F07
	v_add_f32_e32 v6, v6, v11                                  // 0000004318E4: 060C1706
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000004318E8: BF870234
	v_mov_b32_dpp v13, v8 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000004318EC: 7E1A02FA FF016808
	v_cndmask_b32_e64 v8, -v8, v8, s5                          // 0000004318F4: D5010008 20161108
	v_add_f32_e32 v5, v5, v14                                  // 0000004318FC: 060A1D05
	v_mov_b32_dpp v11, v6 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000431900: 7E1602FA FF016806
	v_cndmask_b32_e64 v6, -v6, v6, s5                          // 000000431908: D5010006 20160D06
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000431910: BF870214
	v_add_f32_e32 v8, v8, v13                                  // 000000431914: 06101B08
	v_mov_b32_dpp v14, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000431918: 7E1C02FA FF016405
	v_cndmask_b32_e64 v5, -v5, v5, s4                          // 000000431920: D5010005 20120B05
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000431928: BF8701A3
	v_dual_add_f32 v6, v6, v11 :: v_dual_mov_b32 v13, v8       // 00000043192C: C9101706 060C0108
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 000000431934: D5010008 21AA1108
	v_add_f32_e32 v5, v5, v14                                  // 00000043193C: 060A1D05
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000431940: BF870113
	v_permlanex16_b32 v13, v13, s42, 0xfedcba98                // 000000431944: D65C000D 03FC550D FEDCBA98
	v_mov_b32_dpp v14, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000431950: 7E1C02FA FF016805
	v_cndmask_b32_e64 v5, -v5, v5, s5                          // 000000431958: D5010005 20160B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000431960: BF870091
	v_dual_add_f32 v8, v8, v13 :: v_dual_add_f32 v5, v5, v14   // 000000431964: C9081B08 08041D05
	v_dual_add_f32 v7, v7, v12 :: v_dual_mov_b32 v14, v5       // 00000043196C: C9101907 070E0105
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000431974: BF870231
	v_mov_b32_dpp v12, v7 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000431978: 7E1802FA FF016807
	v_cndmask_b32_e64 v7, -v7, v7, s5                          // 000000431980: D5010007 20160F07
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 000000431988: D5010005 21AA0B05
	v_permlanex16_b32 v14, v14, s42, 0xfedcba98                // 000000431990: D65C000E 03FC550E FEDCBA98
	v_mov_b32_e32 v11, v6                                      // 00000043199C: 7E160306
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 0000004319A0: D5010006 21AA0D06
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000004319A8: BF870193
	v_add_f32_e32 v10, v5, v14                                 // 0000004319AC: 06141D05
	v_permlanex16_b32 v11, v11, s42, 0xfedcba98                // 0000004319B0: D65C000B 03FC550B FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004319BC: BF870091
	v_dual_add_f32 v7, v7, v12 :: v_dual_add_f32 v6, v6, v11   // 0000004319C0: C9081907 07061706
	v_mov_b32_e32 v12, v7                                      // 0000004319C8: 7E180307
	v_cndmask_b32_e64 v7, -v7, v7, vcc_lo                      // 0000004319CC: D5010007 21AA0F07
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000004319D4: BF870193
	v_fma_mixlo_f16 v5, v6, s43, 0                             // 0000004319D8: CC210005 02005706
	v_permlanex16_b32 v12, v12, s42, 0xfedcba98                // 0000004319E0: D65C000C 03FC550C FEDCBA98
	v_fma_mixhi_f16 v6, v10, s43, 0                            // 0000004319EC: CC220006 0200570A
	v_fma_mixlo_f16 v6, v8, s43, 0                             // 0000004319F4: CC210006 02005708
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004319FC: BF870093
	v_add_f32_e32 v7, v7, v12                                  // 000000431A00: 060E1907
	v_fma_mixhi_f16 v5, v7, s43, 0                             // 000000431A04: CC220005 02005707
	ds_store_b64 v9, v[5:6]                                    // 000000431A0C: D9340000 00000509
	s_and_not1_b32 exec_lo, exec_lo, s33                       // 000000431A14: 917E217E
	s_cbranch_execnz 65297                                     // 000000431A18: BFA6FF11 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi4ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x660>
	s_or_b32 exec_lo, exec_lo, s31                             // 000000431A1C: 8C7E1F7E
	s_bfe_i32 s6, s7, 0x1001c                                  // 000000431A20: 9386FF07 0001001C
	s_lshr_b32 s4, s23, 28                                     // 000000431A28: 85049C17
	s_lshr_b64 s[2:3], s[6:7], 29                              // 000000431A2C: 85829D06
	s_add_i32 s4, s19, s4                                      // 000000431A30: 81040413
	s_add_i32 s2, s2, 7                                        // 000000431A34: 81028702
	s_lshl_b32 s3, s7, 3                                       // 000000431A38: 84038307
	s_ashr_i32 s2, s2, 3                                       // 000000431A3C: 86028302
	s_lshl_b32 s5, s27, 3                                      // 000000431A40: 8405831B
	.long 0xd72c0001                                           // 000000431A44: D72C0001
	v_cndmask_b32_e32 v1, s2, v19, vcc_lo                      // 000000431A48: 02022602
	v_lshlrev_b32_e32 v21, 2, v20                              // 000000431A4C: 302A2882
	s_waitcnt lgkmcnt(0)                                       // 000000431A50: BF89FC07
	s_waitcnt_vscnt null, 0x0                                  // 000000431A54: BC7C0000
	s_barrier                                                  // 000000431A58: BFBD0000
	buffer_gl0_inv                                             // 000000431A5C: E0AC0000 00000000
	v_add_nc_u32_e32 v2, s2, v1                                // 000000431A64: 4A040202
	s_ashr_i32 s2, s4, 4                                       // 000000431A68: 86028404
	s_ashr_i32 s4, s5, 31                                      // 000000431A6C: 86049F05
	s_mul_hi_i32 s6, s26, s2                                   // 000000431A70: 9706021A
	s_mul_i32 s2, s26, s2                                      // 000000431A74: 9602021A
	v_min_i32_e32 v23, s3, v2                                  // 000000431A78: 222E0403
	s_add_u32 s2, s2, s5                                       // 000000431A7C: 80020502
	s_addc_u32 s3, s6, s4                                      // 000000431A80: 82030406
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000431A84: BF870099
	s_lshl_b64 s[4:5], s[2:3], 10                              // 000000431A88: 84848A02
	v_cmp_lt_i32_e32 vcc_lo, v1, v23                           // 000000431A8C: 7C822F01
	s_add_u32 s3, s8, s4                                       // 000000431A90: 80030408
	s_addc_u32 s4, s9, s5                                      // 000000431A94: 82040509
	s_and_saveexec_b32 s5, vcc_lo                              // 000000431A98: BE85206A
	s_cbranch_execz 93                                         // 000000431A9C: BFA5005D <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi4ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0xc14>
	.long 0xd7010202                                           // 000000431AA0: D7010202
	v_cndmask_b32_e32 v0, v20, v129, vcc_lo                    // 000000431AA4: 02010314
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000431AA8: BF870121
	v_cndmask_b32_e64 v3, v2, 31, s2                           // 000000431AAC: D5010003 00093F02
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000431AB4: 3404029F
	.long 0xd44c0002                                           // 000000431AB8: D44C0002
	v_cndmask_b32_e32 v1, 31, v3, vcc_lo                       // 000000431ABC: 0202069F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000431AC0: BF870091
	v_cndmask_b32_e64 v5, 0xe1, 1, s2                          // 000000431AC4: D5010005 000902FF 000000E1
	v_dual_mov_b32 v4, 0 :: v_dual_add_nc_u32 v7, v5, v3       // 000000431AD0: CA200080 04060705
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000431AD8: BF870114
	.long 0xd73c0005                                           // 000000431ADC: D73C0005
	v_cndmask_b32_e32 v1, 10, v1, vcc_lo                       // 000000431AE0: 0202028A
	.long 0xd73c0002                                           // 000000431AE4: D73C0002
	v_cndmask_b32_e32 v1, 2, v3, vcc_lo                        // 000000431AE8: 02020682
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000431AEC: BF870223
	v_lshlrev_b32_e32 v4, 24, v7                               // 000000431AF0: 30080E98
	v_bfe_i32 v7, v7, 7, 1                                     // 000000431AF4: D6110007 02050F07
	.long 0xd7000208                                           // 000000431AFC: D7000208
	v_cndmask_b32_e32 v1, s3, v5, vcc_lo                       // 000000431B00: 02020A03
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000431B04: BF870211
	v_add_co_ci_u32_e64 v9, null, s4, v6, s2                   // 000000431B08: D5207C09 000A0C04
	v_ashrrev_i32_e32 v6, 22, v4                               // 000000431B10: 340C0896
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000431B14: BF870093
	.long 0xd7000204                                           // 000000431B18: D7000204
	v_cndmask_b32_e32 v1, v8, v2, vcc_lo                       // 000000431B1C: 02020508
	v_add_co_ci_u32_e64 v5, null, v9, v3, s2                   // 000000431B20: D5207C05 000A0709
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000431B28: BF870093
	.long 0xd7000206                                           // 000000431B2C: D7000206
	v_cndmask_b32_e32 v1, v8, v6, vcc_lo                       // 000000431B30: 02020D08
	v_add_co_ci_u32_e64 v7, null, v9, v7, s2                   // 000000431B34: D5207C07 000A0F09
	.long 0xd7000208                                           // 000000431B3C: D7000208
	v_cndmask_b32_e32 v1, v8, v21, vcc_lo                      // 000000431B40: 02022B08
	s_delay_alu instid0(VALU_DEP_1)                            // 000000431B44: BF870001
	v_add_co_ci_u32_e64 v9, null, 0, v9, s2                    // 000000431B48: D5207C09 000A1280
	s_clause 0x17                                              // 000000431B50: BF850017
	global_load_b32 v2, v[4:5], off                            // 000000431B54: DC520000 027C0004
	global_load_b32 v92, v[4:5], off offset:128                // 000000431B5C: DC520080 5C7C0004
	global_load_b32 v89, v[4:5], off offset:256                // 000000431B64: DC520100 597C0004
	global_load_b32 v86, v[4:5], off offset:384                // 000000431B6C: DC520180 567C0004
	global_load_b32 v83, v[4:5], off offset:512                // 000000431B74: DC520200 537C0004
	global_load_b32 v80, v[4:5], off offset:640                // 000000431B7C: DC520280 507C0004
	global_load_b32 v77, v[4:5], off offset:768                // 000000431B84: DC520300 4D7C0004
	global_load_b32 v59, v[4:5], off offset:896                // 000000431B8C: DC520380 3B7C0004
	global_load_b32 v4, v[6:7], off                            // 000000431B94: DC520000 047C0006
	global_load_b32 v93, v[6:7], off offset:128                // 000000431B9C: DC520080 5D7C0006
	global_load_b32 v90, v[6:7], off offset:256                // 000000431BA4: DC520100 5A7C0006
	global_load_b32 v87, v[6:7], off offset:384                // 000000431BAC: DC520180 577C0006
	global_load_b32 v84, v[6:7], off offset:512                // 000000431BB4: DC520200 547C0006
	global_load_b32 v81, v[6:7], off offset:640                // 000000431BBC: DC520280 517C0006
	global_load_b32 v78, v[6:7], off offset:768                // 000000431BC4: DC520300 4E7C0006
	global_load_b32 v60, v[6:7], off offset:896                // 000000431BCC: DC520380 3C7C0006
	global_load_b32 v3, v[8:9], off                            // 000000431BD4: DC520000 037C0008
	global_load_b32 v91, v[8:9], off offset:128                // 000000431BDC: DC520080 5B7C0008
	global_load_b32 v88, v[8:9], off offset:256                // 000000431BE4: DC520100 587C0008
	global_load_b32 v85, v[8:9], off offset:384                // 000000431BEC: DC520180 557C0008
	global_load_b32 v82, v[8:9], off offset:512                // 000000431BF4: DC520200 527C0008
	global_load_b32 v79, v[8:9], off offset:640                // 000000431BFC: DC520280 4F7C0008
	global_load_b32 v76, v[8:9], off offset:768                // 000000431C04: DC520300 4C7C0008
	global_load_b32 v58, v[8:9], off offset:896                // 000000431C0C: DC520380 3A7C0008
	s_or_b32 exec_lo, exec_lo, s5                              // 000000431C14: 8C7E057E
	v_dual_mov_b32 v22, 0 :: v_dual_mov_b32 v25, 0             // 000000431C18: CA100080 16180080
	v_dual_mov_b32 v24, 0 :: v_dual_mov_b32 v27, 0             // 000000431C20: CA100080 181A0080
	v_dual_mov_b32 v26, 0 :: v_dual_mov_b32 v31, 0             // 000000431C28: CA100080 1A1E0080
	v_dual_mov_b32 v28, 0 :: v_dual_mov_b32 v33, 0             // 000000431C30: CA100080 1C200080
	v_dual_mov_b32 v30, 0 :: v_dual_mov_b32 v35, 0             // 000000431C38: CA100080 1E220080
	v_dual_mov_b32 v32, 0 :: v_dual_mov_b32 v37, 0             // 000000431C40: CA100080 20240080
	v_dual_mov_b32 v34, 0 :: v_dual_mov_b32 v39, 0             // 000000431C48: CA100080 22260080
	v_dual_mov_b32 v36, 0 :: v_dual_mov_b32 v43, 0             // 000000431C50: CA100080 242A0080
	v_dual_mov_b32 v38, 0 :: v_dual_mov_b32 v45, 0             // 000000431C58: CA100080 262C0080
	v_dual_mov_b32 v40, 0 :: v_dual_mov_b32 v29, 0             // 000000431C60: CA100080 281C0080
	v_dual_mov_b32 v42, 0 :: v_dual_mov_b32 v49, 0             // 000000431C68: CA100080 2A300080
	v_dual_mov_b32 v44, 0 :: v_dual_mov_b32 v53, 0             // 000000431C70: CA100080 2C340080
	v_dual_mov_b32 v46, 0 :: v_dual_mov_b32 v47, 0             // 000000431C78: CA100080 2E2E0080
	v_dual_mov_b32 v48, 0 :: v_dual_mov_b32 v41, 0             // 000000431C80: CA100080 30280080
	v_dual_mov_b32 v52, 0 :: v_dual_mov_b32 v51, 0             // 000000431C88: CA100080 34320080
	v_mov_b32_e32 v50, 0                                       // 000000431C90: 7E640280
	v_mov_b32_e32 v54, 0                                       // 000000431C94: 7E6C0280
	s_ashr_i32 s27, s26, 31                                    // 000000431C98: 861B9F1A
	s_and_saveexec_b32 s2, vcc_lo                              // 000000431C9C: BE82206A
	s_cbranch_execz 1080                                       // 000000431CA0: BFA50438 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi4ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x1d84>
	v_dual_mov_b32 v22, 0 :: v_dual_add_nc_u32 v5, -1, v0      // 000000431CA4: CA200080 160400C1
	v_dual_mov_b32 v24, 0 :: v_dual_and_b32 v55, 16, v0        // 000000431CAC: CA240080 18360090
	v_dual_mov_b32 v25, 0 :: v_dual_lshlrev_b32 v56, 2, v20    // 000000431CB4: CA220080 19382882
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000431CBC: BF870123
	v_dual_mov_b32 v26, 0 :: v_dual_and_b32 v5, 31, v5         // 000000431CC0: CA240080 1A040A9F
	v_dual_mov_b32 v27, 0 :: v_dual_mov_b32 v28, 0             // 000000431CC8: CA100080 1B1C0080
	v_dual_mov_b32 v30, 0 :: v_dual_lshlrev_b32 v57, 2, v5     // 000000431CD0: CA220080 1E380A82
	v_dual_mov_b32 v31, 0 :: v_dual_mov_b32 v32, 0             // 000000431CD8: CA100080 1F200080
	v_dual_mov_b32 v33, 0 :: v_dual_mov_b32 v34, 0             // 000000431CE0: CA100080 21220080
	v_dual_mov_b32 v35, 0 :: v_dual_mov_b32 v36, 0             // 000000431CE8: CA100080 23240080
	v_dual_mov_b32 v37, 0 :: v_dual_mov_b32 v38, 0             // 000000431CF0: CA100080 25260080
	v_dual_mov_b32 v39, 0 :: v_dual_mov_b32 v40, 0             // 000000431CF8: CA100080 27280080
	v_dual_mov_b32 v42, 0 :: v_dual_mov_b32 v43, 0             // 000000431D00: CA100080 2A2A0080
	v_dual_mov_b32 v44, 0 :: v_dual_mov_b32 v45, 0             // 000000431D08: CA100080 2C2C0080
	v_dual_mov_b32 v46, 0 :: v_dual_mov_b32 v29, 0             // 000000431D10: CA100080 2E1C0080
	v_dual_mov_b32 v48, 0 :: v_dual_mov_b32 v49, 0             // 000000431D18: CA100080 30300080
	v_dual_mov_b32 v52, 0 :: v_dual_mov_b32 v53, 0             // 000000431D20: CA100080 34340080
	v_dual_mov_b32 v47, 0 :: v_dual_mov_b32 v50, 0             // 000000431D28: CA100080 2F320080
	v_dual_mov_b32 v41, 0 :: v_dual_mov_b32 v54, 0             // 000000431D30: CA100080 29360080
	v_mov_b32_e32 v51, 0                                       // 000000431D38: 7E660280
	s_mov_b32 s5, 0                                            // 000000431D3C: BE850080
	s_movk_i32 s6, 0x1eee                                      // 000000431D40: B0061EEE
	s_branch 980                                               // 000000431D44: BFA003D4 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi4ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x1c98>
	s_or_b32 exec_lo, exec_lo, s7                              // 000000431D48: 8C7E077E
	s_waitcnt vmcnt(15)                                        // 000000431D4C: BF893FF7
	v_alignbit_b32 v2, v2, v4, 16                              // 000000431D50: D6160002 02420902
	v_lshl_or_b32 v13, v1, 5, v55                              // 000000431D58: D656000D 04DD0B01
	s_waitcnt vmcnt(7)                                         // 000000431D60: BF891FF7
	v_bfe_u32 v14, v3, 12, 16                                  // 000000431D64: D610000E 02411903
	v_bfe_u32 v15, v3, 8, 16                                   // 000000431D6C: D610000F 02411103
	v_bfe_u32 v16, v3, 4, 16                                   // 000000431D74: D6100010 02410903
	v_bfe_u32 v1, v2, 12, 16                                   // 000000431D7C: D6100001 02411902
	v_bfe_u32 v5, v2, 8, 16                                    // 000000431D84: D6100005 02411102
	.long 0xd72c000e                                           // 000000431D8C: D72C000E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v14, vcc_lo              // 000000431D90: 02021CFF 83DCD12D
	.long 0xd72c000f                                           // 000000431D98: D72C000F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v15, vcc_lo              // 000000431D9C: 02021EFF 83DCD12D
	v_alignbit_b32 v92, v92, v93, 16                           // 000000431DA4: D616005C 0242BB5C
	.long 0xd72c005f                                           // 000000431DAC: D72C005F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v1, vcc_lo               // 000000431DB0: 020202FF 83DCD12D
	.long 0xd72c0061                                           // 000000431DB8: D72C0061
	v_cndmask_b32_e32 v1, 0x83dcd12d, v5, vcc_lo               // 000000431DBC: 02020AFF 83DCD12D
	s_waitcnt vmcnt(6)                                         // 000000431DC4: BF891BF7
	v_bfe_u32 v100, v91, 4, 16                                 // 000000431DC8: D6100064 0241095B
	v_alignbit_b32 v89, v89, v90, 16                           // 000000431DD0: D6160059 0242B559
	v_bfe_u32 v93, v92, 12, 16                                 // 000000431DD8: D610005D 0241195C
	v_sad_u8 v14, v14, 0, 0x6400                               // 000000431DE0: D622000E 03FD010E 00006400
	v_sad_u8 v99, v15, 0, 0x6400                               // 000000431DEC: D6220063 03FD010F 00006400
	v_alignbit_b32 v86, v86, v87, 16                           // 000000431DF8: D6160056 0242AF56
	v_sad_u8 v95, v95, 0, 0x6400                               // 000000431E00: D622005F 03FD015F 00006400
	v_sad_u8 v97, v97, 0, 0x6400                               // 000000431E0C: D6220061 03FD0161 00006400
	.long 0xd72c005d                                           // 000000431E18: D72C005D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v93, vcc_lo              // 000000431E1C: 0202BAFF 83DCD12D
	v_bfe_u32 v90, v89, 12, 16                                 // 000000431E24: D610005A 02411959
	v_bfe_u32 v87, v86, 12, 16                                 // 000000431E2C: D6100057 02411956
	v_and_b32_e32 v95, 0xffff, v95                             // 000000431E34: 36BEBEFF 0000FFFF
	v_alignbit_b32 v83, v83, v84, 16                           // 000000431E3C: D6160053 0242A953
	v_alignbit_b32 v80, v80, v81, 16                           // 000000431E44: D6160050 0242A350
	.long 0xd72c005a                                           // 000000431E4C: D72C005A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v90, vcc_lo              // 000000431E50: 0202B4FF 83DCD12D
	.long 0xd72c0057                                           // 000000431E58: D72C0057
	v_cndmask_b32_e32 v1, 0x83dcd12d, v87, vcc_lo              // 000000431E5C: 0202AEFF 83DCD12D
	v_lshl_or_b32 v95, v97, 16, v95                            // 000000431E64: D656005F 057D2161
	.long 0xd72c0061                                           // 000000431E6C: D72C0061
	v_cndmask_b32_e32 v1, 0x83dcd12d, v16, vcc_lo              // 000000431E70: 020220FF 83DCD12D
	v_sad_u8 v93, v93, 0, 0x6400                               // 000000431E78: D622005D 03FD015D 00006400
	v_bfe_u32 v84, v83, 12, 16                                 // 000000431E84: D6100054 02411953
	v_bfe_u32 v81, v80, 12, 16                                 // 000000431E8C: D6100051 02411950
	v_pk_fma_f16 v95, v95, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000431E94: CC0E005F 0BFC0D5F 0000C931
	v_and_b32_e32 v4, 0xffff, v2                               // 000000431EA0: 360804FF 0000FFFF
	v_bfe_u32 v2, v2, 4, 16                                    // 000000431EA8: D6100002 02410902
	v_sad_u8 v90, v90, 0, 0x6400                               // 000000431EB0: D622005A 03FD015A 00006400
	v_sad_u8 v97, v97, 0, 0x6400                               // 000000431EBC: D6220061 03FD0161 00006400
	v_sad_u8 v87, v87, 0, 0x6400                               // 000000431EC8: D6220057 03FD0157 00006400
	.long 0xd72c0060                                           // 000000431ED4: D72C0060
	v_cndmask_b32_e32 v1, 0x83dcd12d, v4, vcc_lo               // 000000431ED8: 020208FF 83DCD12D
	.long 0xd72c0062                                           // 000000431EE0: D72C0062
	v_cndmask_b32_e32 v1, 0x83dcd12d, v2, vcc_lo               // 000000431EE4: 020204FF 83DCD12D
	.long 0xd72c0054                                           // 000000431EEC: D72C0054
	v_cndmask_b32_e32 v1, 0x83dcd12d, v84, vcc_lo              // 000000431EF0: 0202A8FF 83DCD12D
	.long 0xd72c0051                                           // 000000431EF8: D72C0051
	v_cndmask_b32_e32 v1, 0x83dcd12d, v81, vcc_lo              // 000000431EFC: 0202A2FF 83DCD12D
	v_alignbit_b32 v77, v77, v78, 16                           // 000000431F04: D616004D 02429D4D
	v_alignbit_b32 v59, v59, v60, 16                           // 000000431F0C: D616003B 0242793B
	v_cmp_eq_u32_e32 vcc_lo, v17, v23                          // 000000431F14: 7C942F11
	v_and_b32_e32 v93, 0xffff, v93                             // 000000431F18: 36BABAFF 0000FFFF
	v_sad_u8 v96, v96, 0, 0x6400                               // 000000431F20: D6220060 03FD0160 00006400
	v_sad_u8 v98, v98, 0, 0x6400                               // 000000431F2C: D6220062 03FD0162 00006400
	v_sad_u8 v84, v84, 0, 0x6400                               // 000000431F38: D6220054 03FD0154 00006400
	v_sad_u8 v81, v81, 0, 0x6400                               // 000000431F44: D6220051 03FD0151 00006400
	v_bfe_u32 v78, v77, 12, 16                                 // 000000431F50: D610004E 0241194D
	v_lshlrev_b32_e32 v96, 16, v96                             // 000000431F58: 30C0C090
	v_bfe_u32 v60, v59, 12, 16                                 // 000000431F5C: D610003C 0241193B
	s_or_b32 s5, vcc_lo, s5                                    // 000000431F64: 8C05056A
	v_and_b32_e32 v90, 0xffff, v90                             // 000000431F68: 36B4B4FF 0000FFFF
	.long 0xd72c004e                                           // 000000431F70: D72C004E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 000000431F74: 02029CFF 83DCD12D
	v_and_or_b32 v96, 0xffff, v98, v96                         // 000000431F7C: D6570060 0582C4FF 0000FFFF
	.long 0xd72c003c                                           // 000000431F88: D72C003C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v60, vcc_lo              // 000000431F8C: 020278FF 83DCD12D
	v_and_b32_e32 v84, 0xffff, v84                             // 000000431F94: 36A8A8FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3)                            // 000000431F9C: BF870003
	v_pk_fma_f16 v96, v96, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000431FA0: CC0E0060 0BFC0D60 0000C931
	v_and_b32_e32 v94, 0xffff, v3                              // 000000431FAC: 36BC06FF 0000FFFF
	ds_load_b128 v[1:4], v13                                   // 000000431FB4: DBFC0000 0100000D
	ds_load_b128 v[5:8], v13 offset:5120                       // 000000431FBC: DBFC1400 0500000D
	ds_load_b128 v[9:12], v13 offset:10240                     // 000000431FC4: DBFC2800 0900000D
	v_and_b32_e32 v87, 0xffff, v87                             // 000000431FCC: 36AEAEFF 0000FFFF
	v_sad_u8 v78, v78, 0, 0x6400                               // 000000431FD4: D622004E 03FD014E 00006400
	v_sad_u8 v60, v60, 0, 0x6400                               // 000000431FE0: D622003C 03FD013C 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000431FEC: BF870112
	v_and_b32_e32 v78, 0xffff, v78                             // 000000431FF0: 369C9CFF 0000FFFF
	v_and_b32_e32 v60, 0xffff, v60                             // 000000431FF8: 367878FF 0000FFFF
	s_waitcnt lgkmcnt(2)                                       // 000000432000: BF89FC27
	v_dot2acc_f32_f16 v54, v95, v1                             // 000000432004: 046C035F
	s_waitcnt lgkmcnt(1)                                       // 000000432008: BF89FC17
	v_dot2acc_f32_f16 v51, v95, v5                             // 00000043200C: 04660B5F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000432010: BF8700A1
	v_dot2acc_f32_f16 v51, v96, v6                             // 000000432014: 04660D60
	.long 0xd72c005e                                           // 000000432018: D72C005E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v94, vcc_lo              // 00000043201C: 0202BCFF 83DCD12D
	v_sad_u8 v94, v94, 0, 0x6400                               // 000000432024: D622005E 03FD015E 00006400
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000432030: BF870091
	v_lshlrev_b32_e32 v94, 16, v94                             // 000000432034: 30BCBC90
	v_and_or_b32 v94, 0xffff, v97, v94                         // 000000432038: D657005E 057AC2FF 0000FFFF
	v_dual_dot2acc_f32_f16 v54, v96, v2 :: v_dual_and_b32 v97, 0xffff, v92// 000000432044: CB240560 3660B8FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_2)                            // 000000432050: BF870002
	v_pk_fma_f16 v94, v94, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000432054: CC0E005E 0BFC0D5E 0000C931
	v_and_b32_e32 v98, 0xffff, v14                             // 000000432060: 36C41CFF 0000FFFF
	ds_load_b128 v[13:16], v13 offset:15360                    // 000000432068: DBFC3C00 0D00000D
	.long 0xd72c0061                                           // 000000432070: D72C0061
	v_cndmask_b32_e32 v1, 0x83dcd12d, v97, vcc_lo              // 000000432074: 0202C2FF 83DCD12D
	v_lshl_or_b32 v98, v99, 16, v98                            // 00000043207C: D6560062 05892163
	v_bfe_u32 v99, v91, 8, 16                                  // 000000432084: D6100063 0241115B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000043208C: BF870212
	v_pk_fma_f16 v98, v98, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000432090: CC0E0062 0BFC0D62 0000C931
	v_sad_u8 v97, v97, 0, 0x6400                               // 00000043209C: D6220061 03FD0161 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000004320A8: BF870113
	.long 0xd72c0063                                           // 0000004320AC: D72C0063
	v_cndmask_b32_e32 v1, 0x83dcd12d, v99, vcc_lo              // 0000004320B0: 0202C6FF 83DCD12D
	v_dual_dot2acc_f32_f16 v54, v98, v3 :: v_dual_lshlrev_b32 v97, 16, v97// 0000004320B8: CB220762 3660C290
	v_dot2acc_f32_f16 v51, v98, v7                             // 0000004320C0: 04660F62
	s_waitcnt lgkmcnt(0)                                       // 0000004320C4: BF89FC07
	v_dot2acc_f32_f16 v41, v95, v13                            // 0000004320C8: 04521B5F
	v_dot2acc_f32_f16 v50, v95, v9                             // 0000004320CC: 0464135F
	v_bfe_u32 v95, v92, 8, 16                                  // 0000004320D0: D610005F 0241115C
	v_bfe_u32 v92, v92, 4, 16                                  // 0000004320D8: D610005C 0241095C
	v_dot2acc_f32_f16 v51, v94, v8                             // 0000004320E0: 0466115E
	v_dot2acc_f32_f16 v41, v96, v14                            // 0000004320E4: 04521D60
	v_dot2acc_f32_f16 v50, v96, v10                            // 0000004320E8: 04641560
	.long 0xd72c005f                                           // 0000004320EC: D72C005F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v95, vcc_lo              // 0000004320F0: 0202BEFF 83DCD12D
	v_bfe_u32 v96, v91, 12, 16                                 // 0000004320F8: D6100060 0241195B
	.long 0xd72c005c                                           // 000000432100: D72C005C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v92, vcc_lo              // 000000432104: 0202B8FF 83DCD12D
	v_and_b32_e32 v91, 0xffff, v91                             // 00000043210C: 36B6B6FF 0000FFFF
	v_dot2acc_f32_f16 v50, v98, v11                            // 000000432114: 04641762
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000432118: BF870224
	.long 0xd72c0060                                           // 00000043211C: D72C0060
	v_cndmask_b32_e32 v1, 0x83dcd12d, v96, vcc_lo              // 000000432120: 0202C0FF 83DCD12D
	v_sad_u8 v95, v95, 0, 0x6400                               // 000000432128: D622005F 03FD015F 00006400
	.long 0xd72c005b                                           // 000000432134: D72C005B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v91, vcc_lo              // 000000432138: 0202B6FF 83DCD12D
	v_sad_u8 v92, v92, 0, 0x6400                               // 000000432140: D622005C 03FD015C 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000043214C: BF8701A3
	v_lshl_or_b32 v93, v95, 16, v93                            // 000000432150: D656005D 0575215F
	v_sad_u8 v96, v96, 0, 0x6400                               // 000000432158: D6220060 03FD0160 00006400
	v_and_or_b32 v92, 0xffff, v92, v97                         // 000000432164: D657005C 0586B8FF 0000FFFF
	v_sad_u8 v91, v91, 0, 0x6400                               // 000000432170: D622005B 03FD015B 00006400
	s_delay_alu instid0(VALU_DEP_4)                            // 00000043217C: BF870004
	v_pk_fma_f16 v93, v93, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000432180: CC0E005D 0BFC0D5D 0000C931
	v_dot2acc_f32_f16 v41, v98, v15                            // 00000043218C: 04521F62
	.long 0xd72c0062                                           // 000000432190: D72C0062
	v_cndmask_b32_e32 v1, 0x83dcd12d, v100, vcc_lo             // 000000432194: 0202C8FF 83DCD12D
	v_pk_fma_f16 v92, v92, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000043219C: CC0E005C 0BFC0D5C 0000C931
	v_dual_dot2acc_f32_f16 v54, v94, v4 :: v_dual_lshlrev_b32 v91, 16, v91// 0000004321A8: CB22095E 365AB690
	v_dual_dot2acc_f32_f16 v52, v93, v9 :: v_dual_and_b32 v95, 0xffff, v96// 0000004321B0: CB24135D 345EC0FF 0000FFFF
	v_sad_u8 v96, v99, 0, 0x6400                               // 0000004321BC: D6220060 03FD0163 00006400
	v_dual_dot2acc_f32_f16 v50, v94, v12 :: v_dual_dot2acc_f32_f16 v47, v93, v1// 0000004321C8: CB18195E 322E035D
	v_sad_u8 v97, v98, 0, 0x6400                               // 0000004321D0: D6220061 03FD0162 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004321DC: BF870214
	v_dot2acc_f32_f16 v52, v92, v10                            // 0000004321E0: 0468155C
	v_lshl_or_b32 v95, v96, 16, v95                            // 0000004321E4: D656005F 057D2160
	s_waitcnt vmcnt(5)                                         // 0000004321EC: BF8917F7
	v_bfe_u32 v96, v88, 12, 16                                 // 0000004321F0: D6100060 02411958
	v_dot2acc_f32_f16 v41, v94, v16                            // 0000004321F8: 0452215E
	v_and_or_b32 v91, 0xffff, v97, v91                         // 0000004321FC: D657005B 056EC2FF 0000FFFF
	v_bfe_u32 v97, v88, 8, 16                                  // 000000432208: D6100061 02411158
	v_pk_fma_f16 v95, v95, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000432210: CC0E005F 0BFC0D5F 0000C931
	.long 0xd72c0060                                           // 00000043221C: D72C0060
	v_cndmask_b32_e32 v1, 0x83dcd12d, v96, vcc_lo              // 000000432220: 0202C0FF 83DCD12D
	v_dot2acc_f32_f16 v53, v93, v5                             // 000000432228: 046A0B5D
	v_pk_fma_f16 v91, v91, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000043222C: CC0E005B 0BFC0D5B 0000C931
	v_and_b32_e32 v94, 0xffff, v89                             // 000000432238: 36BCB2FF 0000FFFF
	v_dual_dot2acc_f32_f16 v52, v95, v11 :: v_dual_dot2acc_f32_f16 v47, v92, v2// 000000432240: CB18175F 342E055C
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000432248: BF870234
	v_dot2acc_f32_f16 v53, v92, v6                             // 00000043224C: 046A0D5C
	v_bfe_u32 v98, v88, 4, 16                                  // 000000432250: D6100062 02410958
	v_and_b32_e32 v88, 0xffff, v88                             // 000000432258: 36B0B0FF 0000FFFF
	v_dot2acc_f32_f16 v52, v91, v12                            // 000000432260: 0468195B
	v_dot2acc_f32_f16 v47, v95, v3                             // 000000432264: 045E075F
	.long 0xd72c0061                                           // 000000432268: D72C0061
	v_cndmask_b32_e32 v1, 0x83dcd12d, v97, vcc_lo              // 00000043226C: 0202C2FF 83DCD12D
	v_sad_u8 v96, v96, 0, 0x6400                               // 000000432274: D6220060 03FD0160 00006400
	v_dot2acc_f32_f16 v49, v93, v13                            // 000000432280: 04621B5D
	v_bfe_u32 v93, v89, 8, 16                                  // 000000432284: D610005D 02411159
	v_bfe_u32 v89, v89, 4, 16                                  // 00000043228C: D6100059 02410959
	.long 0xd72c005e                                           // 000000432294: D72C005E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v94, vcc_lo              // 000000432298: 0202BCFF 83DCD12D
	.long 0xd72c0058                                           // 0000004322A0: D72C0058
	v_cndmask_b32_e32 v1, 0x83dcd12d, v88, vcc_lo              // 0000004322A4: 0202B0FF 83DCD12D
	v_and_b32_e32 v96, 0xffff, v96                             // 0000004322AC: 36C0C0FF 0000FFFF
	.long 0xd72c005d                                           // 0000004322B4: D72C005D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v93, vcc_lo              // 0000004322B8: 0202BAFF 83DCD12D
	v_sad_u8 v97, v97, 0, 0x6400                               // 0000004322C0: D6220061 03FD0161 00006400
	.long 0xd72c0059                                           // 0000004322CC: D72C0059
	v_cndmask_b32_e32 v1, 0x83dcd12d, v89, vcc_lo              // 0000004322D0: 0202B2FF 83DCD12D
	v_dot2acc_f32_f16 v53, v95, v7                             // 0000004322D8: 046A0F5F
	v_sad_u8 v94, v94, 0, 0x6400                               // 0000004322DC: D622005E 03FD015E 00006400
	v_sad_u8 v88, v88, 0, 0x6400                               // 0000004322E8: D6220058 03FD0158 00006400
	v_dot2acc_f32_f16 v49, v92, v14                            // 0000004322F4: 04621D5C
	v_sad_u8 v93, v93, 0, 0x6400                               // 0000004322F8: D622005D 03FD015D 00006400
	v_lshl_or_b32 v92, v97, 16, v96                            // 000000432304: D656005C 05812161
	v_sad_u8 v89, v89, 0, 0x6400                               // 00000043230C: D6220059 03FD0159 00006400
	v_lshlrev_b32_e32 v88, 16, v88                             // 000000432318: 30B0B090
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000043231C: BF870214
	v_lshl_or_b32 v90, v93, 16, v90                            // 000000432320: D656005A 0569215D
	v_pk_fma_f16 v92, v92, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000432328: CC0E005C 0BFC0D5C 0000C931
	v_lshlrev_b32_e32 v93, 16, v94                             // 000000432334: 30BABC90
	.long 0xd72c005e                                           // 000000432338: D72C005E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v98, vcc_lo              // 00000043233C: 0202C4FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000432344: BF870224
	v_pk_fma_f16 v90, v90, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000432348: CC0E005A 0BFC0D5A 0000C931
	v_dot2acc_f32_f16 v53, v91, v8                             // 000000432354: 046A115B
	v_and_or_b32 v89, 0xffff, v89, v93                         // 000000432358: D6570059 0576B2FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000432364: BF8701A3
	v_dual_dot2acc_f32_f16 v47, v91, v4 :: v_dual_dot2acc_f32_f16 v48, v90, v5// 000000432368: CB18095B 2F300B5A
	v_sad_u8 v93, v94, 0, 0x6400                               // 000000432370: D622005D 03FD015E 00006400
	v_pk_fma_f16 v89, v89, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000043237C: CC0E0059 0BFC0D59 0000C931
	v_dot2acc_f32_f16 v46, v90, v9                             // 000000432388: 045C135A
	v_dot2acc_f32_f16 v29, v90, v1                             // 00000043238C: 043A035A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000432390: BF870214
	v_and_or_b32 v88, 0xffff, v93, v88                         // 000000432394: D6570058 0562BAFF 0000FFFF
	v_dot2acc_f32_f16 v48, v89, v6                             // 0000004323A0: 04600D59
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004323A4: BF870214
	v_dot2acc_f32_f16 v46, v89, v10                            // 0000004323A8: 045C1559
	v_dot2acc_f32_f16 v29, v89, v2                             // 0000004323AC: 043A0559
	s_waitcnt vmcnt(4)                                         // 0000004323B0: BF8913F7
	v_bfe_u32 v93, v85, 4, 16                                  // 0000004323B4: D610005D 02410955
	v_pk_fma_f16 v88, v88, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000004323BC: CC0E0058 0BFC0D58 0000C931
	v_dot2acc_f32_f16 v48, v92, v7                             // 0000004323C8: 04600F5C
	v_dual_dot2acc_f32_f16 v46, v92, v11 :: v_dual_dot2acc_f32_f16 v45, v90, v13// 0000004323CC: CB18175C 2E2C1B5A
	v_dual_dot2acc_f32_f16 v29, v92, v3 :: v_dual_and_b32 v90, 0xffff, v86// 0000004323D4: CB24075C 1D5AACFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000004323E0: BF870193
	v_dual_dot2acc_f32_f16 v49, v95, v15 :: v_dual_dot2acc_f32_f16 v48, v88, v8// 0000004323E4: CB181F5F 31301158
	v_dual_dot2acc_f32_f16 v46, v88, v12 :: v_dual_dot2acc_f32_f16 v45, v89, v14// 0000004323EC: CB181958 2E2C1D59
	v_bfe_u32 v89, v86, 8, 16                                  // 0000004323F4: D6100059 02411156
	v_bfe_u32 v86, v86, 4, 16                                  // 0000004323FC: D6100056 02410956
	.long 0xd72c005a                                           // 000000432404: D72C005A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v90, vcc_lo              // 000000432408: 0202B4FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000432410: BF870193
	.long 0xd72c0059                                           // 000000432414: D72C0059
	v_cndmask_b32_e32 v1, 0x83dcd12d, v89, vcc_lo              // 000000432418: 0202B2FF 83DCD12D
	.long 0xd72c0056                                           // 000000432420: D72C0056
	v_cndmask_b32_e32 v1, 0x83dcd12d, v86, vcc_lo              // 000000432424: 0202ACFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3)                            // 00000043242C: BF870003
	v_sad_u8 v90, v90, 0, 0x6400                               // 000000432430: D622005A 03FD015A 00006400
	v_dot2acc_f32_f16 v49, v91, v16                            // 00000043243C: 0462215B
	v_bfe_u32 v91, v85, 12, 16                                 // 000000432440: D610005B 02411955
	v_sad_u8 v89, v89, 0, 0x6400                               // 000000432448: D6220059 03FD0159 00006400
	v_sad_u8 v86, v86, 0, 0x6400                               // 000000432454: D6220056 03FD0156 00006400
	v_lshlrev_b32_e32 v90, 16, v90                             // 000000432460: 30B4B490
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000432464: BF870214
	.long 0xd72c005b                                           // 000000432468: D72C005B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v91, vcc_lo              // 00000043246C: 0202B6FF 83DCD12D
	v_lshl_or_b32 v87, v89, 16, v87                            // 000000432474: D6560057 055D2159
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000043247C: BF870113
	v_and_or_b32 v86, 0xffff, v86, v90                         // 000000432480: D6570056 056AACFF 0000FFFF
	v_pk_fma_f16 v87, v87, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000043248C: CC0E0057 0BFC0D57 0000C931
	v_dot2acc_f32_f16 v29, v88, v4                             // 000000432498: 043A0958
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000043249C: BF870223
	v_pk_fma_f16 v86, v86, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000004324A0: CC0E0056 0BFC0D56 0000C931
	v_sad_u8 v91, v91, 0, 0x6400                               // 0000004324AC: D622005B 03FD015B 00006400
	v_dot2acc_f32_f16 v44, v87, v1                             // 0000004324B8: 04580357
	v_dual_dot2acc_f32_f16 v42, v87, v9 :: v_dual_dot2acc_f32_f16 v45, v92, v15// 0000004324BC: CB181357 2A2C1F5C
	v_bfe_u32 v92, v85, 8, 16                                  // 0000004324C4: D610005C 02411155
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000004324CC: BF870193
	v_dual_dot2acc_f32_f16 v44, v86, v2 :: v_dual_and_b32 v85, 0xffff, v85// 0000004324D0: CB240556 2C54AAFF 0000FFFF
	v_dual_dot2acc_f32_f16 v42, v86, v10 :: v_dual_dot2acc_f32_f16 v45, v88, v16// 0000004324DC: CB181556 2A2C2158
	v_dot2acc_f32_f16 v40, v87, v13                            // 0000004324E4: 04501B57
	s_delay_alu instid0(VALU_DEP_3)                            // 0000004324E8: BF870003
	.long 0xd72c0055                                           // 0000004324EC: D72C0055
	v_cndmask_b32_e32 v1, 0x83dcd12d, v85, vcc_lo              // 0000004324F0: 0202AAFF 83DCD12D
	.long 0xd72c0058                                           // 0000004324F8: D72C0058
	v_cndmask_b32_e32 v1, 0x83dcd12d, v93, vcc_lo              // 0000004324FC: 0202BAFF 83DCD12D
	.long 0xd72c005c                                           // 000000432504: D72C005C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v92, vcc_lo              // 000000432508: 0202B8FF 83DCD12D
	v_mov_b32_e32 v93, v74                                     // 000000432510: 7EBA034A
	v_dot2acc_f32_f16 v40, v86, v14                            // 000000432514: 04501D56
	v_sad_u8 v85, v85, 0, 0x6400                               // 000000432518: D6220055 03FD0155 00006400
	v_sad_u8 v88, v88, 0, 0x6400                               // 000000432524: D6220058 03FD0158 00006400
	v_sad_u8 v90, v92, 0, 0x6400                               // 000000432530: D622005A 03FD015C 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000043253C: BF870093
	v_dual_mov_b32 v92, v68 :: v_dual_lshlrev_b32 v85, 16, v85 // 000000432540: CA220144 5C54AA90
	v_and_or_b32 v85, 0xffff, v88, v85                         // 000000432548: D6570055 0556B0FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000432554: BF870141
	v_pk_fma_f16 v85, v85, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000432558: CC0E0055 0BFC0D55 0000C931
	v_and_b32_e32 v89, 0xffff, v91                             // 000000432564: 36B2B6FF 0000FFFF
	s_waitcnt vmcnt(3)                                         // 00000043256C: BF890FF7
	v_bfe_u32 v91, v82, 4, 16                                  // 000000432570: D610005B 02410952
	v_lshl_or_b32 v89, v90, 16, v89                            // 000000432578: D6560059 0565215A
	v_bfe_u32 v90, v82, 8, 16                                  // 000000432580: D610005A 02411152
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 000000432588: BF870252
	v_pk_fma_f16 v88, v89, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000043258C: CC0E0058 0BFC0D59 0000C931
	v_dot2acc_f32_f16 v43, v87, v5                             // 000000432598: 04560B57
	v_bfe_u32 v89, v82, 12, 16                                 // 00000043259C: D6100059 02411952
	v_and_b32_e32 v82, 0xffff, v82                             // 0000004325A4: 36A4A4FF 0000FFFF
	.long 0xd72c005a                                           // 0000004325AC: D72C005A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v90, vcc_lo              // 0000004325B0: 0202B4FF 83DCD12D
	v_dual_dot2acc_f32_f16 v42, v88, v11 :: v_dual_dot2acc_f32_f16 v43, v86, v6// 0000004325B8: CB181758 2A2A0D56
	v_bfe_u32 v86, v83, 8, 16                                  // 0000004325C0: D6100056 02411153
	.long 0xd72c0059                                           // 0000004325C8: D72C0059
	v_cndmask_b32_e32 v1, 0x83dcd12d, v89, vcc_lo              // 0000004325CC: 0202B2FF 83DCD12D
	.long 0xd72c0052                                           // 0000004325D4: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 0000004325D8: 0202A4FF 83DCD12D
	v_dot2acc_f32_f16 v44, v88, v3                             // 0000004325E0: 04580758
	v_dot2acc_f32_f16 v43, v88, v7                             // 0000004325E4: 04560F58
	.long 0xd72c0056                                           // 0000004325E8: D72C0056
	v_cndmask_b32_e32 v1, 0x83dcd12d, v86, vcc_lo              // 0000004325EC: 0202ACFF 83DCD12D
	v_sad_u8 v90, v90, 0, 0x6400                               // 0000004325F4: D622005A 03FD015A 00006400
	v_dot2acc_f32_f16 v42, v85, v12                            // 000000432600: 04541955
	v_dot2acc_f32_f16 v44, v85, v4                             // 000000432604: 04580955
	v_dot2acc_f32_f16 v43, v85, v8                             // 000000432608: 04561155
	v_sad_u8 v89, v89, 0, 0x6400                               // 00000043260C: D6220059 03FD0159 00006400
	v_sad_u8 v82, v82, 0, 0x6400                               // 000000432618: D6220052 03FD0152 00006400
	v_sad_u8 v86, v86, 0, 0x6400                               // 000000432624: D6220056 03FD0156 00006400
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000432630: BF870091
	v_lshl_or_b32 v84, v86, 16, v84                            // 000000432634: D6560054 05512156
	v_pk_fma_f16 v84, v84, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000043263C: CC0E0054 0BFC0D54 0000C931
	v_and_b32_e32 v87, 0xffff, v83                             // 000000432648: 36AEA6FF 0000FFFF
	v_bfe_u32 v83, v83, 4, 16                                  // 000000432650: D6100053 02410953
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000432658: BF870223
	v_dual_dot2acc_f32_f16 v39, v84, v1 :: v_dual_lshlrev_b32 v82, 16, v82// 00000043265C: CB220354 2752A490
	v_dot2acc_f32_f16 v38, v84, v5                             // 000000432664: 044C0B54
	.long 0xd72c0057                                           // 000000432668: D72C0057
	v_cndmask_b32_e32 v1, 0x83dcd12d, v87, vcc_lo              // 00000043266C: 0202AEFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4)                            // 000000432674: BF870004
	.long 0xd72c0053                                           // 000000432678: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v83, vcc_lo              // 00000043267C: 0202A6FF 83DCD12D
	v_dot2acc_f32_f16 v37, v84, v9                             // 000000432684: 044A1354
	v_dot2acc_f32_f16 v40, v88, v15                            // 000000432688: 04501F58
	v_dot2acc_f32_f16 v36, v84, v13                            // 00000043268C: 04481B54
	v_bfe_u32 v84, v80, 8, 16                                  // 000000432690: D6100054 02411150
	s_waitcnt vmcnt(2)                                         // 000000432698: BF890BF7
	v_bfe_u32 v88, v79, 4, 16                                  // 00000043269C: D6100058 0241094F
	v_sad_u8 v87, v87, 0, 0x6400                               // 0000004326A4: D6220057 03FD0157 00006400
	v_sad_u8 v83, v83, 0, 0x6400                               // 0000004326B0: D6220053 03FD0153 00006400
	v_dot2acc_f32_f16 v40, v85, v16                            // 0000004326BC: 04502155
	v_bfe_u32 v85, v79, 12, 16                                 // 0000004326C0: D6100055 0241194F
	.long 0xd72c0054                                           // 0000004326C8: D72C0054
	v_cndmask_b32_e32 v1, 0x83dcd12d, v84, vcc_lo              // 0000004326CC: 0202A8FF 83DCD12D
	v_lshlrev_b32_e32 v87, 16, v87                             // 0000004326D4: 30AEAE90
	.long 0xd72c0058                                           // 0000004326D8: D72C0058
	v_cndmask_b32_e32 v1, 0x83dcd12d, v88, vcc_lo              // 0000004326DC: 0202B0FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000004326E4: BF870194
	.long 0xd72c0055                                           // 0000004326E8: D72C0055
	v_cndmask_b32_e32 v1, 0x83dcd12d, v85, vcc_lo              // 0000004326EC: 0202AAFF 83DCD12D
	v_and_or_b32 v83, 0xffff, v83, v87                         // 0000004326F4: D6570053 055EA6FF 0000FFFF
	v_sad_u8 v84, v84, 0, 0x6400                               // 000000432700: D6220054 03FD0154 00006400
	s_delay_alu instid0(VALU_DEP_2)                            // 00000043270C: BF870002
	v_pk_fma_f16 v83, v83, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000432710: CC0E0053 0BFC0D53 0000C931
	v_and_b32_e32 v86, 0xffff, v89                             // 00000043271C: 36ACB2FF 0000FFFF
	.long 0xd72c0059                                           // 000000432724: D72C0059
	v_cndmask_b32_e32 v1, 0x83dcd12d, v91, vcc_lo              // 000000432728: 0202B6FF 83DCD12D
	v_sad_u8 v85, v85, 0, 0x6400                               // 000000432730: D6220055 03FD0155 00006400
	v_mov_b32_e32 v91, v74                                     // 00000043273C: 7EB6034A
	v_dot2acc_f32_f16 v39, v83, v2                             // 000000432740: 044E0553
	v_lshl_or_b32 v86, v90, 16, v86                            // 000000432744: D6560056 0559215A
	v_dot2acc_f32_f16 v38, v83, v6                             // 00000043274C: 044C0D53
	v_dot2acc_f32_f16 v37, v83, v10                            // 000000432750: 044A1553
	v_dual_dot2acc_f32_f16 v36, v83, v14 :: v_dual_and_b32 v83, 0xffff, v80// 000000432754: CB241D53 2452A0FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4)                            // 000000432760: BF870004
	v_pk_fma_f16 v86, v86, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000432764: CC0E0056 0BFC0D56 0000C931
	v_sad_u8 v87, v89, 0, 0x6400                               // 000000432770: D6220057 03FD0159 00006400
	v_bfe_u32 v80, v80, 4, 16                                  // 00000043277C: D6100050 02410950
	v_and_b32_e32 v81, 0xffff, v81                             // 000000432784: 36A2A2FF 0000FFFF
	.long 0xd72c0053                                           // 00000043278C: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v83, vcc_lo              // 000000432790: 0202A6FF 83DCD12D
	v_dot2acc_f32_f16 v39, v86, v3                             // 000000432798: 044E0756
	v_dot2acc_f32_f16 v38, v86, v7                             // 00000043279C: 044C0F56
	v_dot2acc_f32_f16 v37, v86, v11                            // 0000004327A0: 044A1756
	v_and_or_b32 v82, 0xffff, v87, v82                         // 0000004327A4: D6570052 054AAEFF 0000FFFF
	v_bfe_u32 v87, v79, 8, 16                                  // 0000004327B0: D6100057 0241114F
	.long 0xd72c0050                                           // 0000004327B8: D72C0050
	v_cndmask_b32_e32 v1, 0x83dcd12d, v80, vcc_lo              // 0000004327BC: 0202A0FF 83DCD12D
	v_dot2acc_f32_f16 v36, v86, v15                            // 0000004327C4: 04481F56
	v_sad_u8 v83, v83, 0, 0x6400                               // 0000004327C8: D6220053 03FD0153 00006400
	v_pk_fma_f16 v82, v82, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000004327D4: CC0E0052 0BFC0D52 0000C931
	.long 0xd72c0057                                           // 0000004327E0: D72C0057
	v_cndmask_b32_e32 v1, 0x83dcd12d, v87, vcc_lo              // 0000004327E4: 0202AEFF 83DCD12D
	v_lshl_or_b32 v81, v84, 16, v81                            // 0000004327EC: D6560051 05452154
	v_and_b32_e32 v79, 0xffff, v79                             // 0000004327F4: 369E9EFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4)                            // 0000004327FC: BF870004
	v_dual_dot2acc_f32_f16 v36, v82, v16 :: v_dual_lshlrev_b32 v83, 16, v83// 000000432800: CB222152 2452A690
	v_sad_u8 v80, v80, 0, 0x6400                               // 000000432808: D6220050 03FD0150 00006400
	v_dot2acc_f32_f16 v38, v82, v8                             // 000000432814: 044C1152
	v_pk_fma_f16 v81, v81, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000432818: CC0E0051 0BFC0D51 0000C931
	v_sad_u8 v84, v87, 0, 0x6400                               // 000000432824: D6220054 03FD0157 00006400
	.long 0xd72c004f                                           // 000000432830: D72C004F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v79, vcc_lo              // 000000432834: 02029EFF 83DCD12D
	v_and_or_b32 v80, 0xffff, v80, v83                         // 00000043283C: D6570050 054EA0FF 0000FFFF
	v_and_b32_e32 v83, 0xffff, v85                             // 000000432848: 36A6AAFF 0000FFFF
	v_dual_dot2acc_f32_f16 v39, v82, v4 :: v_dual_dot2acc_f32_f16 v34, v81, v5// 000000432850: CB180952 27220B51
	v_sad_u8 v85, v88, 0, 0x6400                               // 000000432858: D6220055 03FD0158 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000432864: BF870214
	v_pk_fma_f16 v80, v80, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000432868: CC0E0050 0BFC0D50 0000C931
	v_lshl_or_b32 v83, v84, 16, v83                            // 000000432874: D6560053 054D2154
	v_dot2acc_f32_f16 v37, v82, v12                            // 00000043287C: 044A1952
	v_sad_u8 v79, v79, 0, 0x6400                               // 000000432880: D622004F 03FD014F 00006400
	v_and_b32_e32 v82, 0xffff, v77                             // 00000043288C: 36A49AFF 0000FFFF
	v_dot2acc_f32_f16 v34, v80, v6                             // 000000432894: 04440D50
	v_pk_fma_f16 v83, v83, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000432898: CC0E0053 0BFC0D53 0000C931
	v_dot2acc_f32_f16 v35, v81, v1                             // 0000004328A4: 04460351
	v_dual_dot2acc_f32_f16 v32, v81, v13 :: v_dual_lshlrev_b32 v79, 16, v79// 0000004328A8: CB221B51 204E9E90
	v_bfe_u32 v84, v77, 8, 16                                  // 0000004328B0: D6100054 0241114D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000004328B8: BF870193
	v_dual_dot2acc_f32_f16 v34, v83, v7 :: v_dual_dot2acc_f32_f16 v35, v80, v2// 0000004328BC: CB180F53 22220550
	v_and_or_b32 v79, 0xffff, v85, v79                         // 0000004328C4: D657004F 053EAAFF 0000FFFF
	v_bfe_u32 v77, v77, 4, 16                                  // 0000004328D0: D610004D 0241094D
	.long 0xd72c0052                                           // 0000004328D8: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 0000004328DC: 0202A4FF 83DCD12D
	s_waitcnt vmcnt(1)                                         // 0000004328E4: BF8907F7
	v_bfe_u32 v85, v76, 12, 16                                 // 0000004328E8: D6100055 0241194C
	.long 0xd72c0054                                           // 0000004328F0: D72C0054
	v_cndmask_b32_e32 v1, 0x83dcd12d, v84, vcc_lo              // 0000004328F4: 0202A8FF 83DCD12D
	v_dot2acc_f32_f16 v33, v81, v9                             // 0000004328FC: 04421351
	v_bfe_u32 v86, v76, 8, 16                                  // 000000432900: D6100056 0241114C
	.long 0xd72c004d                                           // 000000432908: D72C004D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v77, vcc_lo              // 00000043290C: 02029AFF 83DCD12D
	v_bfe_u32 v87, v76, 4, 16                                  // 000000432914: D6100057 0241094C
	.long 0xd72c0055                                           // 00000043291C: D72C0055
	v_cndmask_b32_e32 v1, 0x83dcd12d, v85, vcc_lo              // 000000432920: 0202AAFF 83DCD12D
	v_and_b32_e32 v76, 0xffff, v76                             // 000000432928: 369898FF 0000FFFF
	v_pk_fma_f16 v79, v79, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000432930: CC0E004F 0BFC0D4F 0000C931
	v_dot2acc_f32_f16 v35, v83, v3                             // 00000043293C: 04460753
	v_sad_u8 v82, v82, 0, 0x6400                               // 000000432940: D6220052 03FD0152 00006400
	v_sad_u8 v84, v84, 0, 0x6400                               // 00000043294C: D6220054 03FD0154 00006400
	.long 0xd72c0056                                           // 000000432958: D72C0056
	v_cndmask_b32_e32 v1, 0x83dcd12d, v86, vcc_lo              // 00000043295C: 0202ACFF 83DCD12D
	.long 0xd72c004c                                           // 000000432964: D72C004C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v76, vcc_lo              // 000000432968: 020298FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4)                            // 000000432970: BF870004
	v_dual_dot2acc_f32_f16 v35, v79, v4 :: v_dual_lshlrev_b32 v82, 16, v82// 000000432974: CB22094F 2352A490
	v_sad_u8 v77, v77, 0, 0x6400                               // 00000043297C: D622004D 03FD014D 00006400
	v_sad_u8 v85, v85, 0, 0x6400                               // 000000432988: D6220055 03FD0155 00006400
	v_lshl_or_b32 v78, v84, 16, v78                            // 000000432994: D656004E 05392154
	.long 0xd72c0051                                           // 00000043299C: D72C0051
	v_cndmask_b32_e32 v1, 0x83dcd12d, v87, vcc_lo              // 0000004329A0: 0202AEFF 83DCD12D
	v_dot2acc_f32_f16 v33, v80, v10                            // 0000004329A8: 04421550
	v_and_or_b32 v77, 0xffff, v77, v82                         // 0000004329AC: D657004D 054A9AFF 0000FFFF
	v_and_b32_e32 v82, 0xffff, v85                             // 0000004329B8: 36A4AAFF 0000FFFF
	v_sad_u8 v84, v86, 0, 0x6400                               // 0000004329C0: D6220054 03FD0156 00006400
	v_sad_u8 v76, v76, 0, 0x6400                               // 0000004329CC: D622004C 03FD014C 00006400
	v_pk_fma_f16 v78, v78, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000004329D8: CC0E004E 0BFC0D4E 0000C931
	v_dual_dot2acc_f32_f16 v33, v83, v11 :: v_dual_dot2acc_f32_f16 v32, v80, v14// 0000004329E4: CB181753 21201D50
	v_pk_fma_f16 v77, v77, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000004329EC: CC0E004D 0BFC0D4D 0000C931
	v_lshl_or_b32 v80, v84, 16, v82                            // 0000004329F8: D6560050 05492154
	v_sad_u8 v81, v81, 0, 0x6400                               // 000000432A00: D6220051 03FD0151 00006400
	v_dual_dot2acc_f32_f16 v31, v78, v1 :: v_dual_lshlrev_b32 v76, 16, v76// 000000432A0C: CB22034E 1F4C9890
	v_dual_dot2acc_f32_f16 v33, v79, v12 :: v_dual_dot2acc_f32_f16 v30, v78, v5// 000000432A14: CB18194F 211E0B4E
	v_dot2acc_f32_f16 v28, v78, v9                             // 000000432A1C: 0438134E
	v_pk_fma_f16 v80, v80, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000432A20: CC0E0050 0BFC0D50 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000432A2C: BF870244
	v_and_or_b32 v76, 0xffff, v81, v76                         // 000000432A30: D657004C 0532A2FF 0000FFFF
	v_dot2acc_f32_f16 v31, v77, v2                             // 000000432A3C: 043E054D
	v_dot2acc_f32_f16 v30, v77, v6                             // 000000432A40: 043C0D4D
	v_dual_dot2acc_f32_f16 v32, v83, v15 :: v_dual_dot2acc_f32_f16 v27, v78, v13// 000000432A44: CB181F53 201A1B4E
	v_pk_fma_f16 v76, v76, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000432A4C: CC0E004C 0BFC0D4C 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000432A58: BF870194
	v_dual_dot2acc_f32_f16 v31, v80, v3 :: v_dual_dot2acc_f32_f16 v28, v77, v10// 000000432A5C: CB180750 1F1C154D
	v_dual_dot2acc_f32_f16 v34, v79, v8 :: v_dual_dot2acc_f32_f16 v27, v77, v14// 000000432A64: CB18114F 221A1D4D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000432A6C: BF870194
	v_dot2acc_f32_f16 v32, v79, v16                            // 000000432A70: 0440214F
	v_dot2acc_f32_f16 v31, v76, v4                             // 000000432A74: 043E094C
	s_delay_alu instid0(VALU_DEP_4)                            // 000000432A78: BF870004
	v_dot2acc_f32_f16 v28, v80, v11                            // 000000432A7C: 04381750
	v_bfe_u32 v79, v59, 8, 16                                  // 000000432A80: D610004F 0241113B
	s_waitcnt vmcnt(0)                                         // 000000432A88: BF8903F7
	v_bfe_u32 v81, v58, 12, 16                                 // 000000432A8C: D6100051 0241193A
	v_bfe_u32 v82, v58, 8, 16                                  // 000000432A94: D6100052 0241113A
	v_bfe_u32 v83, v58, 4, 16                                  // 000000432A9C: D6100053 0241093A
	v_dot2acc_f32_f16 v27, v80, v15                            // 000000432AA4: 04361F50
	.long 0xd72c004f                                           // 000000432AA8: D72C004F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v79, vcc_lo              // 000000432AAC: 02029EFF 83DCD12D
	v_dual_mov_b32 v85, v72 :: v_dual_and_b32 v58, 0xffff, v58 // 000000432AB4: CA240148 553A74FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000432AC0: BF870214
	.long 0xd72c004d                                           // 000000432AC4: D72C004D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v83, vcc_lo              // 000000432AC8: 0202A6FF 83DCD12D
	v_dot2acc_f32_f16 v27, v76, v16                            // 000000432AD0: 0436214C
	.long 0xd72c0051                                           // 000000432AD4: D72C0051
	v_cndmask_b32_e32 v1, 0x83dcd12d, v81, vcc_lo              // 000000432AD8: 0202A2FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4)                            // 000000432AE0: BF870004
	.long 0xd72c003a                                           // 000000432AE4: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 000000432AE8: 020274FF 83DCD12D
	v_mov_b32_e32 v87, v72                                     // 000000432AF0: 7EAE0348
	v_sad_u8 v79, v79, 0, 0x6400                               // 000000432AF4: D622004F 03FD014F 00006400
	.long 0xd72c0052                                           // 000000432B00: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 000000432B04: 0202A4FF 83DCD12D
	v_mov_b32_e32 v89, v65                                     // 000000432B0C: 7EB20341
	v_sad_u8 v77, v77, 0, 0x6400                               // 000000432B10: D622004D 03FD014D 00006400
	v_mov_b32_e32 v86, v64                                     // 000000432B1C: 7EAC0340
	v_lshl_or_b32 v60, v79, 16, v60                            // 000000432B20: D656003C 04F1214F
	v_sad_u8 v58, v58, 0, 0x6400                               // 000000432B28: D622003A 03FD013A 00006400
	v_sad_u8 v81, v81, 0, 0x6400                               // 000000432B34: D6220051 03FD0151 00006400
	v_dot2acc_f32_f16 v30, v80, v7                             // 000000432B40: 043C0F50
	v_sad_u8 v82, v82, 0, 0x6400                               // 000000432B44: D6220052 03FD0152 00006400
	v_pk_fma_f16 v60, v60, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000432B50: CC0E003C 0BFC0D3C 0000C931
	v_and_b32_e32 v78, 0xffff, v59                             // 000000432B5C: 369C76FF 0000FFFF
	v_bfe_u32 v59, v59, 4, 16                                  // 000000432B64: D610003B 0241093B
	v_lshlrev_b32_e32 v58, 16, v58                             // 000000432B6C: 30747490
	v_and_b32_e32 v81, 0xffff, v81                             // 000000432B70: 36A2A2FF 0000FFFF
	v_dot2acc_f32_f16 v25, v60, v5                             // 000000432B78: 04320B3C
	.long 0xd72c004e                                           // 000000432B7C: D72C004E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 000000432B80: 02029CFF 83DCD12D
	.long 0xd72c003b                                           // 000000432B88: D72C003B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 000000432B8C: 020276FF 83DCD12D
	v_dot2acc_f32_f16 v26, v60, v1                             // 000000432B94: 0434033C
	v_and_or_b32 v1, 0xffff, v77, v58                          // 000000432B98: D6570001 04EA9AFF 0000FFFF
	v_dot2acc_f32_f16 v24, v60, v9                             // 000000432BA4: 0430133C
	v_dual_dot2acc_f32_f16 v22, v60, v13 :: v_dual_mov_b32 v79, v70// 000000432BA8: CB101B3C 164E0146
	v_mov_b32_e32 v77, v61                                     // 000000432BB0: 7E9A033D
	v_sad_u8 v78, v78, 0, 0x6400                               // 000000432BB4: D622004E 03FD014E 00006400
	v_sad_u8 v59, v59, 0, 0x6400                               // 000000432BC0: D622003B 03FD013B 00006400
	v_pk_fma_f16 v1, v1, s6, 0xc931 op_sel_hi:[1,0,0]          // 000000432BCC: CC0E0001 0BFC0D01 0000C931
	v_mov_b32_e32 v88, v73                                     // 000000432BD8: 7EB00349
	v_mov_b32_e32 v90, v73                                     // 000000432BDC: 7EB40349
	v_dual_mov_b32 v83, v63 :: v_dual_lshlrev_b32 v78, 16, v78 // 000000432BE0: CA22013F 534E9C90
	v_mov_b32_e32 v84, v71                                     // 000000432BE8: 7EA80347
	v_mov_b32_e32 v80, v62                                     // 000000432BEC: 7EA0033E
	v_mov_b32_e32 v60, v67                                     // 000000432BF0: 7E780343
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000432BF4: BF870244
	v_and_or_b32 v59, 0xffff, v59, v78                         // 000000432BF8: D657003B 053A76FF 0000FFFF
	v_lshl_or_b32 v78, v82, 16, v81                            // 000000432C04: D656004E 05452152
	v_dual_mov_b32 v81, v70 :: v_dual_mov_b32 v82, v71         // 000000432C0C: CA100146 51520147
	v_mov_b32_e32 v58, v67                                     // 000000432C14: 7E740343
	v_pk_fma_f16 v59, v59, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000432C18: CC0E003B 0BFC0D3B 0000C931
	v_dot2acc_f32_f16 v30, v76, v8                             // 000000432C24: 043C114C
	v_pk_fma_f16 v78, v78, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000432C28: CC0E004E 0BFC0D4E 0000C931
	s_delay_alu instid0(VALU_DEP_3)                            // 000000432C34: BF870003
	v_dot2acc_f32_f16 v26, v59, v2                             // 000000432C38: 0434053B
	v_dot2acc_f32_f16 v25, v59, v6                             // 000000432C3C: 04320D3B
	v_dot2acc_f32_f16 v24, v59, v10                            // 000000432C40: 0430153B
	v_dot2acc_f32_f16 v22, v59, v14                            // 000000432C44: 042C1D3B
	v_dot2acc_f32_f16 v28, v76, v12                            // 000000432C48: 0438194C
	v_dual_dot2acc_f32_f16 v26, v78, v3 :: v_dual_mov_b32 v3, v75// 000000432C4C: CB10074E 1A02014B
	v_dot2acc_f32_f16 v25, v78, v7                             // 000000432C54: 04320F4E
	v_dot2acc_f32_f16 v24, v78, v11                            // 000000432C58: 0430174E
	v_dot2acc_f32_f16 v22, v78, v15                            // 000000432C5C: 042C1F4E
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000432C60: BF870214
	v_dual_dot2acc_f32_f16 v26, v1, v4 :: v_dual_mov_b32 v59, v18// 000000432C64: CB100901 1A3A0112
	v_dot2acc_f32_f16 v25, v1, v8                              // 000000432C6C: 04321101
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000432C70: BF870214
	v_dot2acc_f32_f16 v24, v1, v12                             // 000000432C74: 04301901
	v_dot2acc_f32_f16 v22, v1, v16                             // 000000432C78: 042C2101
	v_mov_b32_e32 v4, v75                                      // 000000432C7C: 7E08034B
	v_mov_b32_e32 v2, v66                                      // 000000432C80: 7E040342
	v_mov_b32_e32 v78, v69                                     // 000000432C84: 7E9C0345
	v_mov_b32_e32 v76, v69                                     // 000000432C88: 7E980345
	v_mov_b32_e32 v1, v17                                      // 000000432C8C: 7E020311
	s_and_not1_b32 exec_lo, exec_lo, s5                        // 000000432C90: 917E057E
	s_cbranch_execz 58                                         // 000000432C94: BFA5003A <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi4ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x1d80>
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000432C98: BF8700A1
	v_add_nc_u32_e32 v17, 1, v1                                // 000000432C9C: 4A220281
	s_mov_b32 s7, exec_lo                                      // 000000432CA0: BE87007E
	.long 0xd4c1007e                                           // 000000432CA4: D4C1007E
	v_cndmask_b32_e32 v1, v17, v23, vcc_lo                     // 000000432CA8: 02022F11
	s_cbranch_execz 64550                                      // 000000432CAC: BFA5FC26 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi4ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0xd48>
	v_ashrrev_i32_e32 v18, 31, v17                             // 000000432CB0: 3424229F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000432CB4: BF870091
	.long 0xd73c0005                                           // 000000432CB8: D73C0005
	v_cndmask_b32_e32 v1, 10, v17, vcc_lo                      // 000000432CBC: 0202228A
	.long 0xd7006a07                                           // 000000432CC0: D7006A07
	v_cndmask_b32_e32 v1, s3, v5, vcc_lo                       // 000000432CC4: 02020A03
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000432CC8: BF870111
	v_add_co_ci_u32_e64 v8, null, s4, v6, vcc_lo               // 000000432CCC: D5207C08 01AA0C04
	.long 0xd7006a05                                           // 000000432CD4: D7006A05
	v_cndmask_b32_e32 v1, v7, v57, vcc_lo                      // 000000432CD8: 02027307
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000432CDC: BF8700A1
	v_add_co_ci_u32_e64 v6, null, 0, v8, vcc_lo                // 000000432CE0: D5207C06 01AA1080
	.long 0xd7006a07                                           // 000000432CE8: D7006A07
	v_cndmask_b32_e32 v1, v7, v56, vcc_lo                      // 000000432CEC: 02027107
	v_add_co_ci_u32_e64 v8, null, 0, v8, vcc_lo                // 000000432CF0: D5207C08 01AA1080
	s_clause 0xf                                               // 000000432CF8: BF85000F
	global_load_b32 v66, v[5:6], off                           // 000000432CFC: DC520000 427C0005
	global_load_b32 v68, v[5:6], off offset:128                // 000000432D04: DC520080 447C0005
	global_load_b32 v65, v[5:6], off offset:256                // 000000432D0C: DC520100 417C0005
	global_load_b32 v64, v[5:6], off offset:384                // 000000432D14: DC520180 407C0005
	global_load_b32 v63, v[5:6], off offset:512                // 000000432D1C: DC520200 3F7C0005
	global_load_b32 v62, v[5:6], off offset:640                // 000000432D24: DC520280 3E7C0005
	global_load_b32 v61, v[5:6], off offset:768                // 000000432D2C: DC520300 3D7C0005
	global_load_b32 v18, v[5:6], off offset:896                // 000000432D34: DC520380 127C0005
	global_load_b32 v75, v[7:8], off                           // 000000432D3C: DC520000 4B7C0007
	global_load_b32 v74, v[7:8], off offset:128                // 000000432D44: DC520080 4A7C0007
	global_load_b32 v73, v[7:8], off offset:256                // 000000432D4C: DC520100 497C0007
	global_load_b32 v72, v[7:8], off offset:384                // 000000432D54: DC520180 487C0007
	global_load_b32 v71, v[7:8], off offset:512                // 000000432D5C: DC520200 477C0007
	global_load_b32 v70, v[7:8], off offset:640                // 000000432D64: DC520280 467C0007
	global_load_b32 v69, v[7:8], off offset:768                // 000000432D6C: DC520300 457C0007
	global_load_b32 v67, v[7:8], off offset:896                // 000000432D74: DC520380 437C0007
	s_branch 64498                                             // 000000432D7C: BFA0FBF2 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi4ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0xd48>
	s_or_b32 exec_lo, exec_lo, s5                              // 000000432D80: 8C7E057E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000432D84: BF870009
	s_or_b32 exec_lo, exec_lo, s2                              // 000000432D88: 8C7E027E
	s_waitcnt vmcnt(23)                                        // 000000432D8C: BF895FF7
	v_dual_mov_b32 v1, v54 :: v_dual_mov_b32 v2, v51           // 000000432D90: CA100136 01020133
	s_waitcnt vmcnt(7)                                         // 000000432D98: BF891FF7
	v_dual_mov_b32 v4, v50 :: v_dual_mov_b32 v3, v41           // 000000432D9C: CA100132 04020129
	v_dual_mov_b32 v5, v47 :: v_dual_mov_b32 v8, v52           // 000000432DA4: CA10012F 05080134
	v_dual_mov_b32 v7, v53 :: v_dual_mov_b32 v10, v48          // 000000432DAC: CA100135 070A0130
	v_dual_mov_b32 v9, v49 :: v_dual_mov_b32 v14, v43          // 000000432DB4: CA100131 090E012B
	v_dual_mov_b32 v6, v29 :: v_dual_mov_b32 v11, v46          // 000000432DBC: CA10011D 060A012E
	v_dual_mov_b32 v12, v45 :: v_dual_mov_b32 v13, v44         // 000000432DC4: CA10012D 0C0C012C
	v_dual_mov_b32 v15, v42 :: v_dual_mov_b32 v16, v40         // 000000432DCC: CA10012A 0F100128
	v_dual_mov_b32 v17, v39 :: v_dual_mov_b32 v18, v38         // 000000432DD4: CA100127 11120126
	v_dual_mov_b32 v23, v37 :: v_dual_mov_b32 v56, v35         // 000000432DDC: CA100125 17380123
	s_waitcnt vmcnt(0)                                         // 000000432DE4: BF8903F7
	v_dual_mov_b32 v55, v36 :: v_dual_mov_b32 v58, v33         // 000000432DE8: CA100124 373A0121
	v_dual_mov_b32 v57, v34 :: v_dual_mov_b32 v60, v31         // 000000432DF0: CA100122 393C011F
	v_dual_mov_b32 v59, v32 :: v_dual_mov_b32 v64, v26         // 000000432DF8: CA100120 3B40011A
	v_dual_mov_b32 v61, v30 :: v_dual_mov_b32 v62, v28         // 000000432E00: CA10011E 3D3E011C
	v_dual_mov_b32 v63, v27 :: v_dual_mov_b32 v66, v24         // 000000432E08: CA10011B 3F420118
	v_mov_b32_e32 v65, v25                                     // 000000432E10: 7E820319
	v_mov_b32_e32 v67, v22                                     // 000000432E14: 7E860316
	s_mov_b32 s2, 0x76543210                                   // 000000432E18: BE8200FF 76543210
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000432E20: BF870009
	v_permlanex16_b32 v1, v1, s2, 0xfedcba98                   // 000000432E24: D65C0001 03FC0501 FEDCBA98
	v_permlanex16_b32 v2, v2, s2, 0xfedcba98                   // 000000432E30: D65C0002 03FC0502 FEDCBA98
	v_permlanex16_b32 v4, v4, s2, 0xfedcba98                   // 000000432E3C: D65C0004 03FC0504 FEDCBA98
	v_permlanex16_b32 v3, v3, s2, 0xfedcba98                   // 000000432E48: D65C0003 03FC0503 FEDCBA98
	v_permlanex16_b32 v5, v5, s2, 0xfedcba98                   // 000000432E54: D65C0005 03FC0505 FEDCBA98
	v_permlanex16_b32 v7, v7, s2, 0xfedcba98                   // 000000432E60: D65C0007 03FC0507 FEDCBA98
	v_permlanex16_b32 v8, v8, s2, 0xfedcba98                   // 000000432E6C: D65C0008 03FC0508 FEDCBA98
	v_permlanex16_b32 v9, v9, s2, 0xfedcba98                   // 000000432E78: D65C0009 03FC0509 FEDCBA98
	v_permlanex16_b32 v6, v6, s2, 0xfedcba98                   // 000000432E84: D65C0006 03FC0506 FEDCBA98
	v_permlanex16_b32 v10, v10, s2, 0xfedcba98                 // 000000432E90: D65C000A 03FC050A FEDCBA98
	v_permlanex16_b32 v11, v11, s2, 0xfedcba98                 // 000000432E9C: D65C000B 03FC050B FEDCBA98
	v_permlanex16_b32 v12, v12, s2, 0xfedcba98                 // 000000432EA8: D65C000C 03FC050C FEDCBA98
	v_permlanex16_b32 v13, v13, s2, 0xfedcba98                 // 000000432EB4: D65C000D 03FC050D FEDCBA98
	v_permlanex16_b32 v14, v14, s2, 0xfedcba98                 // 000000432EC0: D65C000E 03FC050E FEDCBA98
	v_permlanex16_b32 v15, v15, s2, 0xfedcba98                 // 000000432ECC: D65C000F 03FC050F FEDCBA98
	v_permlanex16_b32 v16, v16, s2, 0xfedcba98                 // 000000432ED8: D65C0010 03FC0510 FEDCBA98
	v_permlanex16_b32 v17, v17, s2, 0xfedcba98                 // 000000432EE4: D65C0011 03FC0511 FEDCBA98
	v_permlanex16_b32 v18, v18, s2, 0xfedcba98                 // 000000432EF0: D65C0012 03FC0512 FEDCBA98
	v_permlanex16_b32 v23, v23, s2, 0xfedcba98                 // 000000432EFC: D65C0017 03FC0517 FEDCBA98
	v_permlanex16_b32 v55, v55, s2, 0xfedcba98                 // 000000432F08: D65C0037 03FC0537 FEDCBA98
	v_permlanex16_b32 v56, v56, s2, 0xfedcba98                 // 000000432F14: D65C0038 03FC0538 FEDCBA98
	v_permlanex16_b32 v57, v57, s2, 0xfedcba98                 // 000000432F20: D65C0039 03FC0539 FEDCBA98
	v_permlanex16_b32 v58, v58, s2, 0xfedcba98                 // 000000432F2C: D65C003A 03FC053A FEDCBA98
	v_permlanex16_b32 v59, v59, s2, 0xfedcba98                 // 000000432F38: D65C003B 03FC053B FEDCBA98
	v_permlanex16_b32 v60, v60, s2, 0xfedcba98                 // 000000432F44: D65C003C 03FC053C FEDCBA98
	v_permlanex16_b32 v61, v61, s2, 0xfedcba98                 // 000000432F50: D65C003D 03FC053D FEDCBA98
	v_permlanex16_b32 v62, v62, s2, 0xfedcba98                 // 000000432F5C: D65C003E 03FC053E FEDCBA98
	v_permlanex16_b32 v63, v63, s2, 0xfedcba98                 // 000000432F68: D65C003F 03FC053F FEDCBA98
	v_permlanex16_b32 v64, v64, s2, 0xfedcba98                 // 000000432F74: D65C0040 03FC0540 FEDCBA98
	v_permlanex16_b32 v65, v65, s2, 0xfedcba98                 // 000000432F80: D65C0041 03FC0541 FEDCBA98
	v_permlanex16_b32 v66, v66, s2, 0xfedcba98                 // 000000432F8C: D65C0042 03FC0542 FEDCBA98
	v_permlanex16_b32 v67, v67, s2, 0xfedcba98                 // 000000432F98: D65C0043 03FC0543 FEDCBA98
	.long 0xd44c0002                                           // 000000432FA4: D44C0002
	v_cndmask_b32_e32 v1, 16, v20, vcc_lo                      // 000000432FA8: 02022890
	s_barrier                                                  // 000000432FAC: BFBD0000
	buffer_gl0_inv                                             // 000000432FB0: E0AC0000 00000000
	s_and_saveexec_b32 s3, s2                                  // 000000432FB8: BE832002
	s_cbranch_execz 68                                         // 000000432FBC: BFA50044 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi4ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x20d0>
	v_lshl_or_b32 v21, v19, 11, v21                            // 000000432FC0: D6560015 04551713
	v_dual_add_f32 v12, v45, v12 :: v_dual_add_f32 v5, v47, v5 // 000000432FC8: C908192D 0C040B2F
	v_dual_add_f32 v8, v52, v8 :: v_dual_add_f32 v1, v54, v1   // 000000432FD0: C9081134 08000336
	v_dual_add_f32 v10, v48, v10 :: v_dual_add_f32 v7, v53, v7 // 000000432FD8: C9081530 0A060F35
	v_add_f32_e32 v2, v51, v2                                  // 000000432FE0: 06040533
	v_add_f32_e32 v20, v22, v67                                // 000000432FE4: 06288716
	v_add_f32_e32 v22, v24, v66                                // 000000432FE8: 062C8518
	v_dual_add_f32 v24, v25, v65 :: v_dual_add_f32 v25, v26, v64// 000000432FEC: C9088319 1818811A
	v_dual_add_f32 v26, v27, v63 :: v_dual_add_f32 v27, v28, v62// 000000432FF4: C9087F1B 1A1A7D1C
	v_add_f32_e32 v28, v30, v61                                // 000000432FFC: 06387B1E
	v_dual_add_f32 v30, v31, v60 :: v_dual_add_f32 v23, v37, v23// 000000433000: C908791F 1E162F25
	v_dual_add_f32 v31, v32, v59 :: v_dual_add_f32 v32, v33, v58// 000000433008: C9087720 1F207521
	v_add_f32_e32 v17, v39, v17                                // 000000433010: 06222327
	v_dual_add_f32 v33, v34, v57 :: v_dual_add_f32 v34, v35, v56// 000000433014: C9087322 21227123
	v_add_f32_e32 v15, v42, v15                                // 00000043301C: 061E1F2A
	v_dual_add_f32 v35, v36, v55 :: v_dual_add_f32 v4, v50, v4 // 000000433020: C9086F24 23040932
	v_dual_add_f32 v3, v41, v3 :: v_dual_add_nc_u32 v36, 0x400, v21// 000000433028: C9200729 03242AFF 00000400
	v_dual_add_f32 v14, v43, v14 :: v_dual_add_f32 v9, v49, v9 // 000000433034: C9081D2B 0E081331
	v_dual_add_f32 v18, v38, v18 :: v_dual_add_f32 v13, v44, v13// 00000043303C: C9082526 120C1B2C
	v_add_f32_e32 v6, v29, v6                                  // 000000433044: 060C0D1D
	v_dual_add_f32 v16, v40, v16 :: v_dual_add_f32 v11, v46, v11// 000000433048: C9082128 100A172E
	ds_store_2addr_b32 v21, v1, v5 offset1:16                  // 000000433050: D8381000 00050115
	ds_store_2addr_b32 v21, v2, v7 offset0:128 offset1:144     // 000000433058: D8389080 00070215
	ds_store_2addr_b32 v36, v4, v8 offset1:16                  // 000000433060: D8381000 00080424
	ds_store_2addr_b32 v36, v3, v9 offset0:128 offset1:144     // 000000433068: D8389080 00090324
	ds_store_2addr_b32 v21, v6, v13 offset0:32 offset1:48      // 000000433070: D8383020 000D0615
	ds_store_2addr_b32 v21, v10, v14 offset0:160 offset1:176   // 000000433078: D838B0A0 000E0A15
	ds_store_2addr_b32 v36, v11, v15 offset0:32 offset1:48     // 000000433080: D8383020 000F0B24
	ds_store_2addr_b32 v36, v12, v16 offset0:160 offset1:176   // 000000433088: D838B0A0 00100C24
	ds_store_2addr_b32 v21, v17, v34 offset0:64 offset1:80     // 000000433090: D8385040 00221115
	ds_store_2addr_b32 v21, v18, v33 offset0:192 offset1:208   // 000000433098: D838D0C0 00211215
	ds_store_2addr_b32 v36, v23, v32 offset0:64 offset1:80     // 0000004330A0: D8385040 00201724
	ds_store_2addr_b32 v36, v35, v31 offset0:192 offset1:208   // 0000004330A8: D838D0C0 001F2324
	ds_store_2addr_b32 v21, v30, v25 offset0:96 offset1:112    // 0000004330B0: D8387060 00191E15
	ds_store_2addr_b32 v21, v28, v24 offset0:224 offset1:240   // 0000004330B8: D838F0E0 00181C15
	ds_store_2addr_b32 v36, v27, v22 offset0:96 offset1:112    // 0000004330C0: D8387060 00161B24
	ds_store_2addr_b32 v36, v26, v20 offset0:224 offset1:240   // 0000004330C8: D838F0E0 00141A24
	s_or_b32 exec_lo, exec_lo, s3                              // 0000004330D0: 8C7E037E
	.long 0xd44c0003                                           // 0000004330D4: D44C0003
	v_cndmask_b32_e32 v1, 0x200, v0, vcc_lo                    // 0000004330D8: 020200FF 00000200
	s_waitcnt lgkmcnt(0)                                       // 0000004330E0: BF89FC07
	s_barrier                                                  // 0000004330E4: BFBD0000
	buffer_gl0_inv                                             // 0000004330E8: E0AC0000 00000000
	s_and_saveexec_b32 s4, s3                                  // 0000004330F0: BE842003
	s_cbranch_execz 37                                         // 0000004330F4: BFA50025 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi4ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x218c>
	v_mov_b32_e32 v1, v0                                       // 0000004330F8: 7E020300
	s_mov_b32 s5, 0                                            // 0000004330FC: BE850080
	s_delay_alu instid0(VALU_DEP_1)                            // 000000433100: BF870001
	v_lshlrev_b32_e32 v8, 2, v1                                // 000000433104: 30100282
	v_cmp_lt_u32_e32 vcc_lo, 0xff, v1                          // 000000433108: 7C9202FF 000000FF
	ds_load_2addr_stride64_b32 v[2:3], v8 offset1:8            // 000000433110: D8E00800 02000008
	ds_load_2addr_stride64_b32 v[4:5], v8 offset0:16 offset1:24// 000000433118: D8E01810 04000008
	ds_load_2addr_stride64_b32 v[6:7], v8 offset0:32 offset1:40// 000000433120: D8E02820 06000008
	s_or_b32 s5, vcc_lo, s5                                    // 000000433128: 8C05056A
	s_waitcnt lgkmcnt(2)                                       // 00000043312C: BF89FC27
	v_add_f32_e32 v2, 0, v2                                    // 000000433130: 06040480
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000433134: BF8700C1
	v_add_f32_e32 v9, v2, v3                                   // 000000433138: 06120702
	ds_load_2addr_stride64_b32 v[2:3], v8 offset0:48 offset1:56// 00000043313C: D8E03830 02000008
	s_waitcnt lgkmcnt(2)                                       // 000000433144: BF89FC27
	v_add_f32_e32 v4, v9, v4                                   // 000000433148: 06080909
	v_add_f32_e32 v4, v4, v5                                   // 00000043314C: 06080B04
	s_waitcnt lgkmcnt(1)                                       // 000000433150: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000433154: BF870091
	v_add_f32_e32 v4, v4, v6                                   // 000000433158: 06080D04
	v_add_f32_e32 v4, v4, v7                                   // 00000043315C: 06080F04
	s_waitcnt lgkmcnt(0)                                       // 000000433160: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000433164: BF8700A1
	v_add_f32_e32 v2, v4, v2                                   // 000000433168: 06040504
	v_add_nc_u32_e32 v4, 0x100, v1                             // 00000043316C: 4A0802FF 00000100
	v_dual_add_f32 v2, v2, v3 :: v_dual_mov_b32 v1, v4         // 000000433174: C9100702 02000104
	ds_store_b32 v8, v2 offset:16384                           // 00000043317C: D8344000 00000208
	s_and_not1_b32 exec_lo, exec_lo, s5                        // 000000433184: 917E057E
	s_cbranch_execnz 65501                                     // 000000433188: BFA6FFDD <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi4ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2100>
	s_or_b32 exec_lo, exec_lo, s4                              // 00000043318C: 8C7E047E
	s_cmp_lt_i32 s21, 2                                        // 000000433190: BF048215
	s_mov_b32 s4, -1                                           // 000000433194: BE8400C1
	s_cbranch_scc1 243                                         // 000000433198: BFA200F3 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi4ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2568>
	s_load_b128 s[4:7], s[0:1], 0x1a8                          // 00000043319C: F4080100 F80001A8
	s_waitcnt lgkmcnt(0)                                       // 0000004331A4: BF89FC07
	s_barrier                                                  // 0000004331A8: BFBD0000
	buffer_gl0_inv                                             // 0000004331AC: E0AC0000 00000000
	s_and_saveexec_b32 s8, s3                                  // 0000004331B4: BE882003
	s_cbranch_execz 85                                         // 0000004331B8: BFA50055 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi4ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2310>
	v_lshrrev_b32_e32 v1, 7, v0                                // 0000004331BC: 32020087
	s_ashr_i32 s35, s34, 31                                    // 0000004331C0: 86239F22
	s_ashr_i32 s37, s36, 31                                    // 0000004331C4: 86259F24
	s_lshl_b64 s[0:1], s[34:35], 2                             // 0000004331C8: 84808222
	s_lshl_b32 s10, s26, 7                                     // 0000004331CC: 840A871A
	v_or_b32_e32 v1, s0, v1                                    // 0000004331D0: 38020200
	v_mov_b32_e32 v2, s1                                       // 0000004331D4: 7E040201
	s_lshl_b64 s[0:1], s[36:37], 2                             // 0000004331D8: 84808224
	s_ashr_i32 s11, s10, 31                                    // 0000004331DC: 860B9F0A
	s_lshl_b64 s[16:17], s[28:29], 2                           // 0000004331E0: 8490821C
	.long 0xd7016a01                                           // 0000004331E4: D7016A01
	v_cndmask_b32_e32 v0, v1, v0, vcc_lo                       // 0000004331E8: 02000101
	s_delay_alu instid0(VALU_DEP_1)                            // 0000004331EC: BF870001
	v_subrev_co_ci_u32_e64 v2, null, s1, v2, vcc_lo            // 0000004331F0: D5227C02 01AA0401
	s_ashr_i32 s1, s20, 31                                     // 0000004331F8: 86019F14
	s_lshl_b64 s[10:11], s[10:11], 2                           // 0000004331FC: 848A820A
	.long 0xd72c0004                                           // 000000433200: D72C0004
	v_cndmask_b32_e32 v0, v1, v1, vcc_lo                       // 000000433204: 02000301
	.long 0xd72c0003                                           // 000000433208: D72C0003
	v_cndmask_b32_e32 v0, v2, v20, vcc_lo                      // 00000043320C: 02002902
	v_mad_u64_u32 v[1:2], null, v1, s20, 0                     // 000000433210: D6FE7C01 02002901
	s_add_u32 s9, s10, s16                                     // 000000433218: 8009100A
	s_addc_u32 s10, s11, s17                                   // 00000043321C: 820A110B
	s_mov_b32 s0, s20                                          // 000000433220: BE800014
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000433224: BF870139
	s_lshl_b64 s[0:1], s[0:1], 3                               // 000000433228: 84808300
	v_add3_u32 v2, v2, v4, v3                                  // 00000043322C: D6550002 040E0902
	v_and_b32_e32 v3, 0x7f, v0                                 // 000000433234: 360600FF 0000007F
	.long 0xd73c0001                                           // 00000043323C: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 000000433240: 02020282
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000433244: BF8701A2
	v_lshlrev_b32_e32 v4, 2, v3                                // 000000433248: 30080682
	v_lshlrev_b32_e32 v3, 2, v0                                // 00000043324C: 30060082
	.long 0xd7006a01                                           // 000000433250: D7006A01
	v_cndmask_b32_e32 v1, s9, v1, vcc_lo                       // 000000433254: 02020209
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000433258: BF8700B1
	v_add_co_ci_u32_e64 v2, null, s10, v2, vcc_lo              // 00000043325C: D5207C02 01AA040A
	s_mov_b32 s9, 0                                            // 000000433264: BE890080
	.long 0xd7006a01                                           // 000000433268: D7006A01
	v_cndmask_b32_e32 v1, v1, v4, vcc_lo                       // 00000043326C: 02020901
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 000000433270: D5207C02 01AA0480
	v_or_b32_e32 v4, 0xffffff00, v0                            // 000000433278: 380800FF FFFFFF00
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000433280: BF870093
	.long 0xd7006a01                                           // 000000433284: D7006A01
	v_cndmask_b32_e32 v1, s4, v1, vcc_lo                       // 000000433288: 02020204
	v_add_co_ci_u32_e64 v2, null, s5, v2, vcc_lo               // 00000043328C: D5207C02 01AA0405
	s_nop 0                                                    // 000000433294: BF800000
	s_nop 0                                                    // 000000433298: BF800000
	s_nop 0                                                    // 00000043329C: BF800000
	s_nop 0                                                    // 0000004332A0: BF800000
	s_nop 0                                                    // 0000004332A4: BF800000
	s_nop 0                                                    // 0000004332A8: BF800000
	s_nop 0                                                    // 0000004332AC: BF800000
	s_nop 0                                                    // 0000004332B0: BF800000
	s_nop 0                                                    // 0000004332B4: BF800000
	s_nop 0                                                    // 0000004332B8: BF800000
	s_nop 0                                                    // 0000004332BC: BF800000
	ds_load_b32 v5, v3 offset:16384                            // 0000004332C0: D8D84000 05000003
	.long 0xd7000a04                                           // 0000004332C8: D7000A04
	v_cndmask_b32_e32 v1, 0x100, v4, vcc_lo                    // 0000004332CC: 020208FF 00000100
	s_xor_b32 s10, s10, -1                                     // 0000004332D4: 8D0AC10A
	v_add_nc_u32_e32 v3, 0x400, v3                             // 0000004332D8: 4A0606FF 00000400
	s_and_b32 s10, exec_lo, s10                                // 0000004332E0: 8B0A0A7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000004332E4: BF8700C9
	s_or_b32 s9, s10, s9                                       // 0000004332E8: 8C09090A
	s_waitcnt lgkmcnt(0)                                       // 0000004332EC: BF89FC07
	global_store_b32 v[1:2], v5, off                           // 0000004332F0: DC6A0000 007C0501
	.long 0xd7006a01                                           // 0000004332F8: D7006A01
	v_cndmask_b32_e32 v0, v1, v0, vcc_lo                       // 0000004332FC: 02000101
	v_add_co_ci_u32_e64 v2, null, s1, v2, vcc_lo               // 000000433300: D5207C02 01AA0401
	s_and_not1_b32 exec_lo, exec_lo, s9                        // 000000433308: 917E097E
	s_cbranch_execnz 65516                                     // 00000043330C: BFA6FFEC <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi4ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x22c0>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000433310: 8C7E087E
	s_ashr_i32 s31, s30, 31                                    // 000000433314: 861F9F1E
	.long 0xd44a0000                                           // 000000433318: D44A0000
	v_cndmask_b32_e32 v1, 0, v0, vcc_lo                        // 00000043331C: 02020080
	s_lshl_b64 s[8:9], s[30:31], 2                             // 000000433320: 8488821E
	s_waitcnt_vscnt null, 0x0                                  // 000000433324: BC7C0000
	buffer_gl1_inv                                             // 000000433328: E0B00000 00000000
	buffer_gl0_inv                                             // 000000433330: E0AC0000 00000000
	s_add_u32 s8, s6, s8                                       // 000000433338: 80080806
	s_addc_u32 s9, s7, s9                                      // 00000043333C: 82090907
	s_barrier                                                  // 000000433340: BFBD0000
	buffer_gl0_inv                                             // 000000433344: E0AC0000 00000000
	s_and_saveexec_b32 s1, s0                                  // 00000043334C: BE812000
	s_cbranch_execz 29                                         // 000000433350: BFA5001D <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi4ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x23c8>
	s_mov_b32 s7, exec_lo                                      // 000000433354: BE87007E
	s_mov_b32 s6, exec_lo                                      // 000000433358: BE86007E
	.long 0xd71f0001                                           // 00000043335C: D71F0001
	v_cndmask_b32_e32 v0, s7, v128, vcc_lo                     // 000000433360: 02010007
	s_delay_alu instid0(VALU_DEP_1)                            // 000000433364: BF870001
	v_cmpx_eq_u32_e32 0, v1                                    // 000000433368: 7D940280
	s_cbranch_execz 9                                          // 00000043336C: BFA50009 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi4ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2394>
	s_lshl_b64 s[10:11], s[26:27], 2                           // 000000433370: 848A821A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 000000433374: BF8704B9
	s_add_u32 s10, s8, s10                                     // 000000433378: 800A0A08
	s_addc_u32 s11, s9, s11                                    // 00000043337C: 820B0B09
	s_bcnt1_i32_b32 s7, s7                                     // 000000433380: BE871807
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v3, s7              // 000000433384: CA100080 02020007
	global_atomic_add_u32 v2, v2, v3, s[10:11] glc             // 00000043338C: DCD64000 020A0302
	s_or_b32 exec_lo, exec_lo, s6                              // 000000433394: 8C7E067E
	s_waitcnt vmcnt(0)                                         // 000000433398: BF8903F7
	v_readfirstlane_b32 s6, v2                                 // 00000043339C: 7E0C0502
	s_delay_alu instid0(VALU_DEP_1)                            // 0000004333A0: BF870001
	v_dual_mov_b32 v2, 0 :: v_dual_add_nc_u32 v1, s6, v1       // 0000004333A4: CA200080 02000206
	s_add_i32 s6, s21, -1                                      // 0000004333AC: 8106C115
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 0000004333B0: BF870481
	v_cmp_eq_u32_e32 vcc_lo, s6, v1                            // 0000004333B4: 7C940206
	v_cndmask_b32_e64 v1, 0, 1, vcc_lo                         // 0000004333B8: D5010001 01A90280
	ds_store_b32 v2, v1 offset:20480                           // 0000004333C0: D8345000 00000102
	s_or_b32 exec_lo, exec_lo, s1                              // 0000004333C8: 8C7E017E
	v_mov_b32_e32 v1, 0                                        // 0000004333CC: 7E020280
	s_waitcnt lgkmcnt(0)                                       // 0000004333D0: BF89FC07
	s_barrier                                                  // 0000004333D4: BFBD0000
	buffer_gl0_inv                                             // 0000004333D8: E0AC0000 00000000
	ds_load_b32 v1, v1 offset:20480                            // 0000004333E0: D8D85000 01000001
	s_waitcnt lgkmcnt(0)                                       // 0000004333E8: BF89FC07
	v_cmp_eq_u32_e32 vcc_lo, 0, v1                             // 0000004333EC: 7C940280
	s_cbranch_vccnz 928                                        // 0000004333F0: BFA403A0 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi4ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3274>
	buffer_gl1_inv                                             // 0000004333F4: E0B00000 00000000
	buffer_gl0_inv                                             // 0000004333FC: E0AC0000 00000000
	s_and_saveexec_b32 s10, s3                                 // 000000433404: BE8A2003
	s_cbranch_execz 76                                         // 000000433408: BFA5004C <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi4ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x253c>
	v_lshrrev_b32_e32 v1, 7, v0                                // 00000043340C: 32020087
	s_lshl_b32 s16, s26, 7                                     // 000000433410: 8410871A
	v_and_b32_e32 v3, 0x7f, v0                                 // 000000433414: 360600FF 0000007F
	s_ashr_i32 s17, s16, 31                                    // 00000043341C: 86119F10
	s_lshl_b64 s[22:23], s[28:29], 2                           // 000000433420: 8496821C
	v_mad_i64_i32 v[1:2], null, v1, s20, 0                     // 000000433424: D6FF7C01 02002901
	s_lshl_b64 s[16:17], s[16:17], 2                           // 00000043342C: 84908210
	s_ashr_i32 s7, s20, 31                                     // 000000433430: 86079F14
	s_add_u32 s1, s16, s22                                     // 000000433434: 80011610
	v_lshlrev_b32_e32 v3, 2, v3                                // 000000433438: 30060682
	s_addc_u32 s3, s17, s23                                    // 00000043343C: 82031711
	v_mov_b32_e32 v5, v0                                       // 000000433440: 7E0A0300
	s_mov_b32 s6, s20                                          // 000000433444: BE860014
	.long 0xd73c0001                                           // 000000433448: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 00000043344C: 02020282
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000433450: BF870091
	.long 0xd7006a01                                           // 000000433454: D7006A01
	v_cndmask_b32_e32 v1, s1, v1, vcc_lo                       // 000000433458: 02020201
	v_add_co_ci_u32_e64 v2, null, s3, v2, vcc_lo               // 00000043345C: D5207C02 01AA0403
	s_mov_b32 s3, 0                                            // 000000433464: BE830080
	.long 0xd7006a01                                           // 000000433468: D7006A01
	v_cndmask_b32_e32 v1, v1, v3, vcc_lo                       // 00000043346C: 02020701
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000433470: BF870111
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 000000433474: D5207C02 01AA0480
	.long 0xd7006a01                                           // 00000043347C: D7006A01
	v_cndmask_b32_e32 v1, s4, v1, vcc_lo                       // 000000433480: 02020204
	s_delay_alu instid0(VALU_DEP_1)                            // 000000433484: BF870001
	v_add_co_ci_u32_e64 v2, null, s5, v2, vcc_lo               // 000000433488: D5207C02 01AA0405
	s_lshl_b64 s[4:5], s[6:7], 3                               // 000000433490: 84848306
	s_lshl_b64 s[6:7], s[6:7], 4                               // 000000433494: 84868406
	s_nop 0                                                    // 000000433498: BF800000
	s_nop 0                                                    // 00000043349C: BF800000
	s_nop 0                                                    // 0000004334A0: BF800000
	s_nop 0                                                    // 0000004334A4: BF800000
	s_nop 0                                                    // 0000004334A8: BF800000
	s_nop 0                                                    // 0000004334AC: BF800000
	s_nop 0                                                    // 0000004334B0: BF800000
	s_nop 0                                                    // 0000004334B4: BF800000
	s_nop 0                                                    // 0000004334B8: BF800000
	s_nop 0                                                    // 0000004334BC: BF800000
	v_dual_mov_b32 v4, v2 :: v_dual_mov_b32 v3, v1             // 0000004334C0: CA100102 04020101
	v_mov_b32_e32 v6, 0                                        // 0000004334C8: 7E0C0280
	s_mov_b32 s1, s21                                          // 0000004334CC: BE810015
	global_load_b32 v7, v[3:4], off glc                        // 0000004334D0: DC524000 077C0003
	.long 0xd7006a03                                           // 0000004334D8: D7006A03
	v_cndmask_b32_e32 v0, v3, v6, vcc_lo                       // 0000004334DC: 02000D03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000004334E0: BF8704A1
	v_add_co_ci_u32_e64 v4, null, s7, v4, vcc_lo               // 0000004334E4: D5207C04 01AA0807
	s_add_i32 s1, s1, -1                                       // 0000004334EC: 8101C101
	s_cmp_eq_u32 s1, 0                                         // 0000004334F0: BF068001
	s_waitcnt vmcnt(0)                                         // 0000004334F4: BF8903F7
	v_add_f32_e32 v6, v6, v7                                   // 0000004334F8: 060C0F06
	s_cbranch_scc0 65524                                       // 0000004334FC: BFA1FFF4 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi4ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x24d0>
	v_add_nc_u32_e32 v4, 0x100, v5                             // 000000433500: 4A080AFF 00000100
	v_cmp_lt_u32_e32 vcc_lo, 0xff, v5                          // 000000433508: 7C920AFF 000000FF
	.long 0xd7000101                                           // 000000433510: D7000101
	v_cndmask_b32_e32 v0, v1, v4, vcc_lo                       // 000000433514: 02000901
	v_lshlrev_b32_e32 v3, 2, v5                                // 000000433518: 30060A82
	v_add_co_ci_u32_e64 v2, null, s5, v2, s1                   // 00000043351C: D5207C02 00060405
	v_mov_b32_e32 v5, v4                                       // 000000433524: 7E0A0304
	s_or_b32 s3, vcc_lo, s3                                    // 000000433528: 8C03036A
	ds_store_b32 v3, v6 offset:16384                           // 00000043352C: D8344000 00000603
	s_and_not1_b32 exec_lo, exec_lo, s3                        // 000000433534: 917E037E
	s_cbranch_execnz 65505                                     // 000000433538: BFA6FFE1 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi4ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x24c0>
	s_or_b32 exec_lo, exec_lo, s10                             // 00000043353C: 8C7E0A7E
	s_and_saveexec_b32 s1, s0                                  // 000000433540: BE812000
	s_cbranch_execz 6                                          // 000000433544: BFA50006 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi4ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2560>
	s_lshl_b64 s[4:5], s[26:27], 2                             // 000000433548: 8484821A
	v_mov_b32_e32 v1, 0                                        // 00000043354C: 7E020280
	s_add_u32 s4, s8, s4                                       // 000000433550: 80040408
	s_addc_u32 s5, s9, s5                                      // 000000433554: 82050509
	global_store_b32 v1, v1, s[4:5]                            // 000000433558: DC6A0000 00040101
	s_or_b32 exec_lo, exec_lo, s1                              // 000000433560: 8C7E017E
	s_mov_b32 s4, -1                                           // 000000433564: BE8400C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000433568: BF870009
	s_and_b32 vcc_lo, exec_lo, s4                              // 00000043356C: 8B6A047E
	s_cbranch_vccz 63390                                       // 000000433570: BFA3F79E <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi4ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3ec>
	v_cmp_gt_i32_e32 vcc_lo, s18, v19                          // 000000433574: 7C882612
	.long 0xd44c0000                                           // 000000433578: D44C0000
	v_cndmask_b32_e32 v1, 0x80, v0, vcc_lo                     // 00000043357C: 020200FF 00000080
	s_waitcnt lgkmcnt(0)                                       // 000000433584: BF89FC07
	s_waitcnt_vscnt null, 0x0                                  // 000000433588: BC7C0000
	s_barrier                                                  // 00000043358C: BFBD0000
	buffer_gl0_inv                                             // 000000433590: E0AC0000 00000000
	s_and_b32 s0, vcc_lo, s0                                   // 000000433598: 8B00006A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000043359C: BF870009
	s_and_saveexec_b32 s1, s0                                  // 0000004335A0: BE812000
	s_cbranch_execz 63377                                      // 0000004335A4: BFA5F791 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi4ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3ec>
	v_and_b32_e32 v1, 15, v0                                   // 0000004335A8: 3602008F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004335AC: BF870091
	v_lshlrev_b32_e32 v2, 2, v1                                // 0000004335B0: 30040282
	v_lshl_or_b32 v2, v19, 9, v2                               // 0000004335B4: D6560002 04091313
	s_delay_alu instid0(VALU_DEP_1)                            // 0000004335BC: BF870001
	v_add_nc_u32_e32 v8, 0x4000, v2                            // 0000004335C0: 4A1004FF 00004000
	ds_load_2addr_b32 v[2:3], v8 offset1:16                    // 0000004335C8: D8DC1000 02000008
	ds_load_2addr_b32 v[4:5], v8 offset0:32 offset1:48         // 0000004335D0: D8DC3020 04000008
	ds_load_2addr_b32 v[6:7], v8 offset0:64 offset1:80         // 0000004335D8: D8DC5040 06000008
	ds_load_2addr_b32 v[8:9], v8 offset0:96 offset1:112        // 0000004335E0: D8DC7060 08000008
	v_and_b32_e32 v10, 1, v0                                   // 0000004335E8: 36140081
	v_and_b32_e32 v11, 2, v0                                   // 0000004335EC: 36160082
	s_waitcnt lgkmcnt(3)                                       // 0000004335F0: BF89FC37
	v_dual_add_f32 v13, v2, v3 :: v_dual_and_b32 v12, 4, v0    // 0000004335F4: C9240702 0D0C0084
	s_waitcnt lgkmcnt(2)                                       // 0000004335FC: BF89FC27
	v_dual_sub_f32 v2, v2, v3 :: v_dual_add_f32 v3, v4, v5     // 000000433600: C9480702 02020B04
	s_waitcnt lgkmcnt(1)                                       // 000000433608: BF89FC17
	v_dual_sub_f32 v4, v4, v5 :: v_dual_add_f32 v5, v6, v7     // 00000043360C: C9480B04 04040F06
	s_waitcnt lgkmcnt(0)                                       // 000000433614: BF89FC07
	v_dual_sub_f32 v6, v6, v7 :: v_dual_add_f32 v7, v8, v9     // 000000433618: C9480F06 06061308
	v_dual_sub_f32 v8, v8, v9 :: v_dual_add_f32 v9, v13, v3    // 000000433620: C9481308 0808070D
	v_sub_f32_e32 v3, v13, v3                                  // 000000433628: 0806070D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 00000043362C: BF870243
	v_dual_add_f32 v13, v2, v4 :: v_dual_add_f32 v14, v5, v7   // 000000433630: C9080902 0D0E0F05
	v_dual_sub_f32 v2, v2, v4 :: v_dual_sub_f32 v5, v5, v7     // 000000433638: C94A0902 02040F05
	v_cmp_eq_u32_e32 vcc_lo, 0, v10                            // 000000433640: 7C941480
	.long 0xd44a0000                                           // 000000433644: D44A0000
	v_cndmask_b32_e32 v1, 0, v12, vcc_lo                       // 000000433648: 02021880
	v_dual_add_f32 v7, v9, v14 :: v_dual_add_f32 v4, v6, v8    // 00000043364C: C9081D09 07041106
	v_sub_f32_e32 v6, v6, v8                                   // 000000433654: 080C1106
	v_sub_f32_e32 v8, v9, v14                                  // 000000433658: 08101D09
	s_delay_alu instid0(VALU_DEP_3)                            // 00000043365C: BF870003
	v_add_f32_e32 v9, v13, v4                                  // 000000433660: 0612090D
	v_dual_sub_f32 v4, v13, v4 :: v_dual_add_f32 v13, v3, v5   // 000000433664: C948090D 040C0B03
	v_sub_f32_e32 v3, v3, v5                                   // 00000043366C: 08060B03
	v_add_f32_e32 v5, v2, v6                                   // 000000433670: 060A0D02
	v_sub_f32_e32 v2, v2, v6                                   // 000000433674: 08040D02
	v_mov_b32_dpp v6, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000433678: 7E0C02FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, vcc_lo                      // 000000433680: D5010007 21AA0F07
	v_mov_b32_dpp v10, v9 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000433688: 7E1402FA FF016109
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 000000433690: D5010009 21AA1309
	v_mov_b32_dpp v14, v13 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000433698: 7E1C02FA FF01610D
	v_cndmask_b32_e64 v13, -v13, v13, vcc_lo                   // 0000004336A0: D501000D 21AA1B0D
	v_mov_b32_dpp v15, v5 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000004336A8: 7E1E02FA FF016105
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 0000004336B0: D5010005 21AA0B05
	v_mov_b32_dpp v16, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000004336B8: 7E2002FA FF016108
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 0000004336C0: D5010008 21AA1108
	v_mov_b32_dpp v17, v4 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000004336C8: 7E2202FA FF016104
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 0000004336D0: D5010004 21AA0904
	v_mov_b32_dpp v18, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000004336D8: 7E2402FA FF016103
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 0000004336E0: D5010003 21AA0703
	v_mov_b32_dpp v20, v2 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000004336E8: 7E2802FA FF016102
	v_cndmask_b32_e64 v2, -v2, v2, vcc_lo                      // 0000004336F0: D5010002 21AA0502
	v_dual_add_f32 v6, v7, v6 :: v_dual_add_f32 v5, v5, v15    // 0000004336F8: C9080D07 06041F05
	v_cmp_eq_u32_e32 vcc_lo, 0, v11                            // 000000433700: 7C941680
	v_dual_add_f32 v7, v9, v10 :: v_dual_add_f32 v8, v8, v16   // 000000433704: C9081509 07082108
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000043370C: BF870233
	v_mov_b32_dpp v10, v6 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000433710: 7E1402FA FF016206
	v_add_f32_e32 v4, v4, v17                                  // 000000433718: 06082304
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 00000043371C: D5010006 21AA0D06
	v_mov_b32_dpp v11, v7 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000433724: 7E1602FA FF016207
	v_cndmask_b32_e64 v7, -v7, v7, vcc_lo                      // 00000043372C: D5010007 21AA0F07
	v_add_f32_e32 v2, v2, v20                                  // 000000433734: 06042902
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000433738: BF870092
	v_dual_add_f32 v6, v6, v10 :: v_dual_add_f32 v7, v7, v11   // 00000043373C: C9081506 06061707
	v_mov_b32_dpp v10, v6 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000433744: 7E1402FA FF016406
	v_cndmask_b32_e64 v6, -v6, v6, s0                          // 00000043374C: D5010006 20020D06
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000433754: BF8700D3
	v_mov_b32_dpp v11, v7 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000433758: 7E1602FA FF016407
	v_cndmask_b32_e64 v7, -v7, v7, s0                          // 000000433760: D5010007 20020F07
	v_add_f32_e32 v9, v13, v14                                 // 000000433768: 06121D0D
	v_mov_b32_dpp v14, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000043376C: 7E1C02FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 000000433774: D5010005 21AA0B05
	v_dual_add_f32 v15, v5, v14 :: v_dual_add_f32 v14, v7, v11 // 00000043377C: C9081D05 0F0E1707
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000433784: BF8701A4
	v_mov_b32_dpp v13, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000433788: 7E1A02FA FF016209
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 000000433790: D5010009 21AA1309
	v_mov_b32_dpp v7, v15 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000433798: 7E0E02FA FF01640F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000004337A0: BF870194
	v_mov_b32_dpp v24, v14 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000004337A4: 7E3002FA FF01680E
	v_add_f32_e32 v9, v9, v13                                  // 0000004337AC: 06121B09
	v_mov_b32_dpp v13, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000004337B0: 7E1A02FA FF016208
	s_delay_alu instid0(VALU_DEP_2)                            // 0000004337B8: BF870002
	v_mov_b32_dpp v12, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000004337BC: 7E1802FA FF016409
	v_cndmask_b32_e64 v9, -v9, v9, s0                          // 0000004337C4: D5010009 20021309
	v_add_f32_e32 v5, v6, v10                                  // 0000004337CC: 060A1506
	v_cndmask_b32_e64 v6, -v8, v8, vcc_lo                      // 0000004337D0: D5010006 21AA1108
	v_add_f32_e32 v3, v3, v18                                  // 0000004337D8: 06062503
	v_mov_b32_dpp v10, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000004337DC: 7E1402FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 0000004337E4: D5010004 21AA0904
	v_add_f32_e32 v22, v9, v12                                 // 0000004337EC: 062C1909
	v_add_f32_e32 v6, v6, v13                                  // 0000004337F0: 060C1B06
	v_mov_b32_dpp v11, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000004337F4: 7E1602FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 0000004337FC: D5010003 21AA0703
	v_mov_b32_dpp v12, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000433804: 7E1802FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, vcc_lo                      // 00000043380C: D5010002 21AA0502
	v_add_f32_e32 v4, v4, v10                                  // 000000433814: 06081504
	v_cndmask_b32_e64 v9, -v15, v15, s0                        // 000000433818: D5010009 20021F0F
	v_add_f32_e32 v3, v3, v11                                  // 000000433820: 06061703
	v_mov_b32_dpp v10, v6 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000433824: 7E1402FA FF016406
	v_cndmask_b32_e64 v6, -v6, v6, s0                          // 00000043382C: D5010006 20020D06
	v_mov_b32_dpp v11, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000433834: 7E1602FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s0                          // 00000043383C: D5010004 20020904
	v_add_f32_e32 v2, v2, v12                                  // 000000433844: 06041902
	v_mov_b32_dpp v12, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000433848: 7E1802FA FF016403
	v_cndmask_b32_e64 v3, -v3, v3, s0                          // 000000433850: D5010003 20020703
	v_dual_add_f32 v20, v9, v7 :: v_dual_add_f32 v17, v6, v10  // 000000433858: C9080F09 14101506
	v_add_f32_e32 v15, v4, v11                                 // 000000433860: 061E1704
	v_mov_b32_dpp v13, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000433864: 7E1A02FA FF016402
	v_cndmask_b32_e64 v2, -v2, v2, s0                          // 00000043386C: D5010002 20020502
	v_add_f32_e32 v12, v3, v12                                 // 000000433874: 06181903
	v_mov_b32_dpp v8, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000433878: 7E1002FA FF016805
	v_mov_b32_dpp v23, v22 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000433880: 7E2E02FA FF016816
	v_mov_b32_dpp v21, v20 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000433888: 7E2A02FA FF016814
	v_add_f32_e32 v9, v2, v13                                  // 000000433890: 06121B02
	v_mov_b32_dpp v18, v17 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000433894: 7E2402FA FF016811
	v_mov_b32_dpp v16, v15 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000043389C: 7E2002FA FF01680F
	v_mov_b32_dpp v13, v12 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000004338A4: 7E1A02FA FF01680C
	s_delay_alu instid0(VALU_DEP_4)                            // 0000004338AC: BF870004
	v_mov_b32_dpp v10, v9 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000004338B0: 7E1402FA FF016809
	s_and_b32 exec_lo, exec_lo, s2                             // 0000004338B8: 8B7E027E
	s_cbranch_execz 63179                                      // 0000004338BC: BFA5F6CB <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi4ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3ec>
	v_lshl_or_b32 v3, s26, 7, v1                               // 0000004338C0: D6560003 04050E1A
	v_and_b32_e32 v0, 8, v0                                    // 0000004338C8: 36000088
	s_cmp_lg_u64 s[24:25], 0                                   // 0000004338CC: BF118018
	s_cselect_b32 s1, -1, 0                                    // 0000004338D0: 980180C1
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000004338D4: BF870112
	v_ashrrev_i32_e32 v4, 31, v3                               // 0000004338D8: 3408069F
	.long 0xd44a0000                                           // 0000004338DC: D44A0000
	v_cndmask_b32_e32 v1, 0, v0, vcc_lo                        // 0000004338E0: 02020080
	s_lshr_b32 s2, s20, 31                                     // 0000004338E4: 85029F14
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000004338E8: BF870009
	s_add_i32 s2, s20, s2                                      // 0000004338EC: 81020214
	.long 0xd73c0001                                           // 0000004338F0: D73C0001
	v_cndmask_b32_e32 v1, 1, v3, vcc_lo                        // 0000004338F4: 02020681
	v_cndmask_b32_e64 v0, -v5, v5, s0                          // 0000004338F8: D5010000 20020B05
	v_mad_i64_i32 v[4:5], null, s20, v19, 0                    // 000000433900: D6FF7C04 02022614
	s_ashr_i32 s2, s2, 1                                       // 000000433908: 86028102
	s_cmp_eq_u64 s[24:25], 0                                   // 00000043390C: BF108018
	v_mad_i64_i32 v[25:26], null, s2, v19, 0                   // 000000433910: D6FF7C19 02022602
	.long 0xd7006a06                                           // 000000433918: D7006A06
	v_cndmask_b32_e32 v1, s12, v1, vcc_lo                      // 00000043391C: 0202020C
	s_delay_alu instid0(VALU_DEP_1)                            // 000000433920: BF870001
	v_add_co_ci_u32_e64 v7, null, s13, v2, vcc_lo              // 000000433924: D5207C07 01AA040D
	v_add_f32_e32 v0, v0, v8                                   // 00000043392C: 06001100
	.long 0xd73c0004                                           // 000000433930: D73C0004
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 000000433934: 02020881
	global_load_d16_b16 v11, v[6:7], off                       // 000000433938: DC820000 0B7C0006
	v_mul_f32_e32 v0, 0x3db504f3, v0                           // 000000433940: 100000FF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 000000433948: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000043394C: BF8700A1
	v_fma_mix_f32 v27, v11, v0, neg(0) op_sel_hi:[1,0,0]       // 000000433950: CC20001B 8A02010B
	.long 0xd7006a00                                           // 000000433958: D7006A00
	v_cndmask_b32_e32 v1, s14, v4, vcc_lo                      // 00000043395C: 0202080E
	v_add_co_ci_u32_e64 v8, null, s15, v5, vcc_lo              // 000000433960: D5207C08 01AA0A0F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000433968: BF8701B3
	v_bfe_u32 v19, v27, 16, 1                                  // 00000043396C: D6100013 0205211B
	.long 0xd73c0004                                           // 000000433974: D73C0004
	v_cndmask_b32_e32 v1, 1, v25, vcc_lo                       // 000000433978: 02023281
	v_ashrrev_i32_e32 v11, 31, v3                              // 00000043397C: 3416069F
	v_add3_u32 v19, v27, v19, 0x7fff                           // 000000433980: D6550013 03FE271B 00007FFF
	s_cbranch_scc1 570                                         // 00000043398C: BFA2023A <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi4ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3278>
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000433990: BF870122
	v_lshrrev_b32_e32 v25, 23, v11                             // 000000433994: 32321697
	v_mov_b32_e32 v29, s14                                     // 000000433998: 7E3A020E
	v_add_nc_u32_e32 v25, v3, v25                              // 00000043399C: 4A323303
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004339A0: BF870091
	v_and_b32_e32 v26, 0xfffffe00, v25                         // 0000004339A4: 363432FF FFFFFE00
	v_sub_nc_u32_e32 v27, v3, v26                              // 0000004339AC: 4C363503
	v_mov_b32_e32 v26, s15                                     // 0000004339B0: 7E34020F
	v_ashrrev_i32_e32 v25, 9, v25                              // 0000004339B4: 34323289
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000004339B8: BF8701A3
	v_cmp_gt_i32_e32 vcc_lo, 0x100, v27                        // 0000004339BC: 7C8836FF 00000100
	v_add_nc_u32_e32 v28, 0xffffff00, v27                      // 0000004339C4: 4A3836FF FFFFFF00
	v_dual_cndmask_b32 v30, s25, v26 :: v_dual_lshlrev_b32 v25, 8, v25// 0000004339CC: CA623419 1E183288
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000004339D4: BF870112
	v_cndmask_b32_e32 v27, v28, v27, vcc_lo                    // 0000004339D8: 0236371C
	v_ashrrev_i32_e32 v26, 31, v25                             // 0000004339DC: 3434329F
	v_cndmask_b32_e32 v29, s24, v29, vcc_lo                    // 0000004339E0: 023A3A18
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000004339E4: BF870193
	v_ashrrev_i32_e32 v28, 31, v27                             // 0000004339E8: 3438369F
	.long 0xd73c0019                                           // 0000004339EC: D73C0019
	v_cndmask_b32_e32 v1, 1, v25, vcc_lo                       // 0000004339F0: 02023281
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004339F4: BF870093
	.long 0xd7006a1d                                           // 0000004339F8: D7006A1D
	v_cndmask_b32_e32 v1, v29, v4, vcc_lo                      // 0000004339FC: 0202091D
	v_add_co_ci_u32_e64 v30, null, v30, v5, vcc_lo             // 000000433A00: D5207C1E 01AA0B1E
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000433A08: BF870194
	.long 0xd73c001b                                           // 000000433A0C: D73C001B
	v_cndmask_b32_e32 v1, 1, v27, vcc_lo                       // 000000433A10: 02023681
	.long 0xd7006a19                                           // 000000433A14: D7006A19
	v_cndmask_b32_e32 v1, v29, v25, vcc_lo                     // 000000433A18: 0202331D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000433A1C: BF870111
	v_add_co_ci_u32_e64 v26, null, v30, v26, vcc_lo            // 000000433A20: D5207C1A 01AA351E
	.long 0xd7006a19                                           // 000000433A28: D7006A19
	v_cndmask_b32_e32 v1, v25, v27, vcc_lo                     // 000000433A2C: 02023719
	s_delay_alu instid0(VALU_DEP_1)                            // 000000433A30: BF870001
	v_add_co_ci_u32_e64 v26, null, v26, v28, vcc_lo            // 000000433A34: D5207C1A 01AA391A
	global_store_d16_hi_b16 v[25:26], v19, off                 // 000000433A3C: DC960000 007C1319
	s_cbranch_execnz 7                                         // 000000433A44: BFA60007 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi4ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2a64>
	.long 0xd7006a19                                           // 000000433A48: D7006A19
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 000000433A4C: 02020300
	s_delay_alu instid0(VALU_DEP_1)                            // 000000433A50: BF870001
	v_add_co_ci_u32_e64 v26, null, v8, v2, vcc_lo              // 000000433A54: D5207C1A 01AA0508
	global_store_d16_hi_b16 v[25:26], v19, off                 // 000000433A5C: DC960000 007C1319
	global_load_d16_b16 v19, v[6:7], off offset:32             // 000000433A64: DC820020 137C0006
	v_cndmask_b32_e64 v14, -v14, v14, s0                       // 000000433A6C: D501000E 20021D0E
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 000000433A74: 916A017E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000433A78: BF870091
	v_add_f32_e32 v14, v14, v24                                // 000000433A7C: 061C310E
	v_mul_f32_e32 v14, 0x3db504f3, v14                         // 000000433A80: 101C1CFF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 000000433A88: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000433A8C: BF870121
	v_fma_mix_f32 v19, v19, v14, neg(0) op_sel_hi:[1,0,0]      // 000000433A90: CC200013 8A021D13
	v_cndmask_b32_e64 v14, 0, 1, s1                            // 000000433A98: D501000E 00050280
	v_bfe_u32 v24, v19, 16, 1                                  // 000000433AA0: D6100018 02052113
	s_delay_alu instid0(VALU_DEP_1)                            // 000000433AA8: BF870001
	v_add3_u32 v19, v19, v24, 0x7fff                           // 000000433AAC: D6550013 03FE3113 00007FFF
	s_cbranch_vccnz 496                                        // 000000433AB8: BFA401F0 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi4ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x327c>
	v_or_b32_e32 v24, 16, v3                                   // 000000433ABC: 38300690
	v_lshrrev_b32_e32 v25, 23, v11                             // 000000433AC0: 32321697
	v_mov_b32_e32 v27, s15                                     // 000000433AC4: 7E36020F
	v_mov_b32_e32 v29, s14                                     // 000000433AC8: 7E3A020E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000433ACC: BF870093
	v_add_nc_u32_e32 v25, v24, v25                             // 000000433AD0: 4A323318
	v_and_b32_e32 v26, 0xfffffe00, v25                         // 000000433AD4: 363432FF FFFFFE00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000433ADC: BF870091
	v_sub_nc_u32_e32 v26, v24, v26                             // 000000433AE0: 4C343518
	v_cmp_gt_i32_e32 vcc_lo, 0x100, v26                        // 000000433AE4: 7C8834FF 00000100
	v_add_nc_u32_e32 v28, 0xffffff00, v26                      // 000000433AEC: 4A3834FF FFFFFF00
	v_cndmask_b32_e32 v30, s25, v27, vcc_lo                    // 000000433AF4: 023C3619
	v_ashrrev_i32_e32 v25, 9, v25                              // 000000433AF8: 34323289
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000433AFC: BF8701A3
	v_cndmask_b32_e32 v26, v28, v26, vcc_lo                    // 000000433B00: 0234351C
	v_cndmask_b32_e32 v28, s24, v29, vcc_lo                    // 000000433B04: 02383A18
	v_lshlrev_b32_e32 v24, 8, v25                              // 000000433B08: 30303288
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000433B0C: BF870193
	v_ashrrev_i32_e32 v27, 31, v26                             // 000000433B10: 3436349F
	.long 0xd7006a1c                                           // 000000433B14: D7006A1C
	v_cndmask_b32_e32 v1, v28, v4, vcc_lo                      // 000000433B18: 0202091C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000433B1C: BF870211
	v_add_co_ci_u32_e64 v29, null, v30, v5, vcc_lo             // 000000433B20: D5207C1D 01AA0B1E
	v_ashrrev_i32_e32 v25, 31, v24                             // 000000433B28: 3432309F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000433B2C: BF870114
	.long 0xd73c001a                                           // 000000433B30: D73C001A
	v_cndmask_b32_e32 v1, 1, v26, vcc_lo                       // 000000433B34: 02023481
	.long 0xd73c0018                                           // 000000433B38: D73C0018
	v_cndmask_b32_e32 v1, 1, v24, vcc_lo                       // 000000433B3C: 02023081
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000433B40: BF870091
	.long 0xd7006a18                                           // 000000433B44: D7006A18
	v_cndmask_b32_e32 v1, v28, v24, vcc_lo                     // 000000433B48: 0202311C
	v_add_co_ci_u32_e64 v25, null, v29, v25, vcc_lo            // 000000433B4C: D5207C19 01AA331D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000433B54: BF870092
	.long 0xd7006a18                                           // 000000433B58: D7006A18
	v_cndmask_b32_e32 v1, v24, v26, vcc_lo                     // 000000433B5C: 02023518
	v_add_co_ci_u32_e64 v25, null, v25, v27, vcc_lo            // 000000433B60: D5207C19 01AA3719
	global_store_d16_hi_b16 v[24:25], v19, off                 // 000000433B68: DC960000 007C1318
	s_cbranch_execnz 7                                         // 000000433B70: BFA60007 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi4ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2b90>
	.long 0xd7006a18                                           // 000000433B74: D7006A18
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 000000433B78: 02020300
	s_delay_alu instid0(VALU_DEP_1)                            // 000000433B7C: BF870001
	v_add_co_ci_u32_e64 v25, null, v8, v2, vcc_lo              // 000000433B80: D5207C19 01AA0508
	global_store_d16_hi_b16 v[24:25], v19, off offset:32       // 000000433B88: DC960020 007C1318
	global_load_d16_b16 v19, v[6:7], off offset:64             // 000000433B90: DC820040 137C0006
	v_cndmask_b32_e64 v22, -v22, v22, s0                       // 000000433B98: D5010016 20022D16
	v_cmp_ne_u32_e32 vcc_lo, 1, v14                            // 000000433BA0: 7C9A1C81
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000433BA4: BF8700A2
	v_add_f32_e32 v22, v22, v23                                // 000000433BA8: 062C2F16
	s_and_b32 vcc_lo, exec_lo, vcc_lo                          // 000000433BAC: 8B6A6A7E
	v_mul_f32_e32 v22, 0x3db504f3, v22                         // 000000433BB0: 102C2CFF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 000000433BB8: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000433BBC: BF870091
	v_fma_mix_f32 v19, v19, v22, neg(0) op_sel_hi:[1,0,0]      // 000000433BC0: CC200013 8A022D13
	v_bfe_u32 v22, v19, 16, 1                                  // 000000433BC8: D6100016 02052113
	s_delay_alu instid0(VALU_DEP_1)                            // 000000433BD0: BF870001
	v_add3_u32 v19, v19, v22, 0x7fff                           // 000000433BD4: D6550013 03FE2D13 00007FFF
	s_cbranch_vccnz 423                                        // 000000433BE0: BFA401A7 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi4ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3280>
	v_or_b32_e32 v22, 32, v3                                   // 000000433BE4: 382C06A0
	v_lshrrev_b32_e32 v23, 23, v11                             // 000000433BE8: 322E1697
	v_mov_b32_e32 v25, s15                                     // 000000433BEC: 7E32020F
	v_mov_b32_e32 v27, s14                                     // 000000433BF0: 7E36020E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000433BF4: BF870093
	v_add_nc_u32_e32 v23, v22, v23                             // 000000433BF8: 4A2E2F16
	v_and_b32_e32 v24, 0xfffffe00, v23                         // 000000433BFC: 36302EFF FFFFFE00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000433C04: BF870091
	v_sub_nc_u32_e32 v24, v22, v24                             // 000000433C08: 4C303116
	v_cmp_gt_i32_e32 vcc_lo, 0x100, v24                        // 000000433C0C: 7C8830FF 00000100
	v_add_nc_u32_e32 v26, 0xffffff00, v24                      // 000000433C14: 4A3430FF FFFFFF00
	v_cndmask_b32_e32 v28, s25, v25, vcc_lo                    // 000000433C1C: 02383219
	v_ashrrev_i32_e32 v23, 9, v23                              // 000000433C20: 342E2E89
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000433C24: BF8701A3
	v_cndmask_b32_e32 v24, v26, v24, vcc_lo                    // 000000433C28: 0230311A
	v_cndmask_b32_e32 v26, s24, v27, vcc_lo                    // 000000433C2C: 02343618
	v_lshlrev_b32_e32 v22, 8, v23                              // 000000433C30: 302C2E88
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000433C34: BF870193
	v_ashrrev_i32_e32 v25, 31, v24                             // 000000433C38: 3432309F
	.long 0xd7006a1a                                           // 000000433C3C: D7006A1A
	v_cndmask_b32_e32 v1, v26, v4, vcc_lo                      // 000000433C40: 0202091A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000433C44: BF870211
	v_add_co_ci_u32_e64 v27, null, v28, v5, vcc_lo             // 000000433C48: D5207C1B 01AA0B1C
	v_ashrrev_i32_e32 v23, 31, v22                             // 000000433C50: 342E2C9F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000433C54: BF870114
	.long 0xd73c0018                                           // 000000433C58: D73C0018
	v_cndmask_b32_e32 v1, 1, v24, vcc_lo                       // 000000433C5C: 02023081
	.long 0xd73c0016                                           // 000000433C60: D73C0016
	v_cndmask_b32_e32 v1, 1, v22, vcc_lo                       // 000000433C64: 02022C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000433C68: BF870091
	.long 0xd7006a16                                           // 000000433C6C: D7006A16
	v_cndmask_b32_e32 v1, v26, v22, vcc_lo                     // 000000433C70: 02022D1A
	v_add_co_ci_u32_e64 v23, null, v27, v23, vcc_lo            // 000000433C74: D5207C17 01AA2F1B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000433C7C: BF870092
	.long 0xd7006a16                                           // 000000433C80: D7006A16
	v_cndmask_b32_e32 v1, v22, v24, vcc_lo                     // 000000433C84: 02023116
	v_add_co_ci_u32_e64 v23, null, v23, v25, vcc_lo            // 000000433C88: D5207C17 01AA3317
	global_store_d16_hi_b16 v[22:23], v19, off                 // 000000433C90: DC960000 007C1316
	s_cbranch_execnz 7                                         // 000000433C98: BFA60007 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi4ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2cb8>
	.long 0xd7006a16                                           // 000000433C9C: D7006A16
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 000000433CA0: 02020300
	s_delay_alu instid0(VALU_DEP_1)                            // 000000433CA4: BF870001
	v_add_co_ci_u32_e64 v23, null, v8, v2, vcc_lo              // 000000433CA8: D5207C17 01AA0508
	global_store_d16_hi_b16 v[22:23], v19, off offset:64       // 000000433CB0: DC960040 007C1316
	global_load_d16_b16 v19, v[6:7], off offset:96             // 000000433CB8: DC820060 137C0006
	v_cndmask_b32_e64 v20, -v20, v20, s0                       // 000000433CC0: D5010014 20022914
	v_cmp_ne_u32_e32 vcc_lo, 1, v14                            // 000000433CC8: 7C9A1C81
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000433CCC: BF8700A2
	v_add_f32_e32 v20, v20, v21                                // 000000433CD0: 06282B14
	s_and_b32 vcc_lo, exec_lo, vcc_lo                          // 000000433CD4: 8B6A6A7E
	v_mul_f32_e32 v20, 0x3db504f3, v20                         // 000000433CD8: 102828FF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 000000433CE0: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000433CE4: BF870091
	v_fma_mix_f32 v19, v19, v20, neg(0) op_sel_hi:[1,0,0]      // 000000433CE8: CC200013 8A022913
	v_bfe_u32 v20, v19, 16, 1                                  // 000000433CF0: D6100014 02052113
	s_delay_alu instid0(VALU_DEP_1)                            // 000000433CF8: BF870001
	v_add3_u32 v19, v19, v20, 0x7fff                           // 000000433CFC: D6550013 03FE2913 00007FFF
	s_cbranch_vccnz 350                                        // 000000433D08: BFA4015E <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi4ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3284>
	v_or_b32_e32 v20, 48, v3                                   // 000000433D0C: 382806B0
	v_lshrrev_b32_e32 v21, 23, v11                             // 000000433D10: 322A1697
	v_mov_b32_e32 v23, s15                                     // 000000433D14: 7E2E020F
	v_mov_b32_e32 v25, s14                                     // 000000433D18: 7E32020E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000433D1C: BF870093
	v_add_nc_u32_e32 v21, v20, v21                             // 000000433D20: 4A2A2B14
	v_and_b32_e32 v22, 0xfffffe00, v21                         // 000000433D24: 362C2AFF FFFFFE00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000433D2C: BF870091
	v_sub_nc_u32_e32 v22, v20, v22                             // 000000433D30: 4C2C2D14
	v_cmp_gt_i32_e32 vcc_lo, 0x100, v22                        // 000000433D34: 7C882CFF 00000100
	v_add_nc_u32_e32 v24, 0xffffff00, v22                      // 000000433D3C: 4A302CFF FFFFFF00
	v_cndmask_b32_e32 v26, s25, v23, vcc_lo                    // 000000433D44: 02342E19
	v_ashrrev_i32_e32 v21, 9, v21                              // 000000433D48: 342A2A89
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000433D4C: BF8701A3
	v_cndmask_b32_e32 v22, v24, v22, vcc_lo                    // 000000433D50: 022C2D18
	v_cndmask_b32_e32 v24, s24, v25, vcc_lo                    // 000000433D54: 02303218
	v_lshlrev_b32_e32 v20, 8, v21                              // 000000433D58: 30282A88
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000433D5C: BF870193
	v_ashrrev_i32_e32 v23, 31, v22                             // 000000433D60: 342E2C9F
	.long 0xd7006a18                                           // 000000433D64: D7006A18
	v_cndmask_b32_e32 v1, v24, v4, vcc_lo                      // 000000433D68: 02020918
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000433D6C: BF870211
	v_add_co_ci_u32_e64 v25, null, v26, v5, vcc_lo             // 000000433D70: D5207C19 01AA0B1A
	v_ashrrev_i32_e32 v21, 31, v20                             // 000000433D78: 342A289F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000433D7C: BF870114
	.long 0xd73c0016                                           // 000000433D80: D73C0016
	v_cndmask_b32_e32 v1, 1, v22, vcc_lo                       // 000000433D84: 02022C81
	.long 0xd73c0014                                           // 000000433D88: D73C0014
	v_cndmask_b32_e32 v1, 1, v20, vcc_lo                       // 000000433D8C: 02022881
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000433D90: BF870091
	.long 0xd7006a14                                           // 000000433D94: D7006A14
	v_cndmask_b32_e32 v1, v24, v20, vcc_lo                     // 000000433D98: 02022918
	v_add_co_ci_u32_e64 v21, null, v25, v21, vcc_lo            // 000000433D9C: D5207C15 01AA2B19
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000433DA4: BF870092
	.long 0xd7006a14                                           // 000000433DA8: D7006A14
	v_cndmask_b32_e32 v1, v20, v22, vcc_lo                     // 000000433DAC: 02022D14
	v_add_co_ci_u32_e64 v21, null, v21, v23, vcc_lo            // 000000433DB0: D5207C15 01AA2F15
	global_store_d16_hi_b16 v[20:21], v19, off                 // 000000433DB8: DC960000 007C1314
	s_cbranch_execnz 7                                         // 000000433DC0: BFA60007 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi4ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2de0>
	.long 0xd7006a14                                           // 000000433DC4: D7006A14
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 000000433DC8: 02020300
	s_delay_alu instid0(VALU_DEP_1)                            // 000000433DCC: BF870001
	v_add_co_ci_u32_e64 v21, null, v8, v2, vcc_lo              // 000000433DD0: D5207C15 01AA0508
	global_store_d16_hi_b16 v[20:21], v19, off offset:96       // 000000433DD8: DC960060 007C1314
	global_load_d16_b16 v19, v[6:7], off offset:128            // 000000433DE0: DC820080 137C0006
	v_cndmask_b32_e64 v17, -v17, v17, s0                       // 000000433DE8: D5010011 20022311
	v_cmp_ne_u32_e32 vcc_lo, 1, v14                            // 000000433DF0: 7C9A1C81
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000433DF4: BF8700A2
	v_add_f32_e32 v17, v17, v18                                // 000000433DF8: 06222511
	s_and_b32 vcc_lo, exec_lo, vcc_lo                          // 000000433DFC: 8B6A6A7E
	v_mul_f32_e32 v17, 0x3db504f3, v17                         // 000000433E00: 102222FF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 000000433E08: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000433E0C: BF870091
	v_fma_mix_f32 v17, v19, v17, neg(0) op_sel_hi:[1,0,0]      // 000000433E10: CC200011 8A022313
	v_bfe_u32 v18, v17, 16, 1                                  // 000000433E18: D6100012 02052111
	s_delay_alu instid0(VALU_DEP_1)                            // 000000433E20: BF870001
	v_add3_u32 v17, v17, v18, 0x7fff                           // 000000433E24: D6550011 03FE2511 00007FFF
	s_cbranch_vccnz 277                                        // 000000433E30: BFA40115 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi4ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3288>
	v_or_b32_e32 v18, 64, v3                                   // 000000433E34: 382406C0
	v_lshrrev_b32_e32 v19, 23, v11                             // 000000433E38: 32261697
	v_mov_b32_e32 v21, s15                                     // 000000433E3C: 7E2A020F
	v_mov_b32_e32 v23, s14                                     // 000000433E40: 7E2E020E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000433E44: BF870093
	v_add_nc_u32_e32 v19, v18, v19                             // 000000433E48: 4A262712
	v_and_b32_e32 v20, 0xfffffe00, v19                         // 000000433E4C: 362826FF FFFFFE00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000433E54: BF870091
	v_sub_nc_u32_e32 v20, v18, v20                             // 000000433E58: 4C282912
	v_cmp_gt_i32_e32 vcc_lo, 0x100, v20                        // 000000433E5C: 7C8828FF 00000100
	v_add_nc_u32_e32 v22, 0xffffff00, v20                      // 000000433E64: 4A2C28FF FFFFFF00
	v_cndmask_b32_e32 v24, s25, v21, vcc_lo                    // 000000433E6C: 02302A19
	v_ashrrev_i32_e32 v19, 9, v19                              // 000000433E70: 34262689
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000433E74: BF8701A3
	v_cndmask_b32_e32 v20, v22, v20, vcc_lo                    // 000000433E78: 02282916
	v_cndmask_b32_e32 v22, s24, v23, vcc_lo                    // 000000433E7C: 022C2E18
	v_lshlrev_b32_e32 v18, 8, v19                              // 000000433E80: 30242688
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000433E84: BF870193
	v_ashrrev_i32_e32 v21, 31, v20                             // 000000433E88: 342A289F
	.long 0xd7006a16                                           // 000000433E8C: D7006A16
	v_cndmask_b32_e32 v1, v22, v4, vcc_lo                      // 000000433E90: 02020916
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000433E94: BF870211
	v_add_co_ci_u32_e64 v23, null, v24, v5, vcc_lo             // 000000433E98: D5207C17 01AA0B18
	v_ashrrev_i32_e32 v19, 31, v18                             // 000000433EA0: 3426249F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000433EA4: BF870114
	.long 0xd73c0014                                           // 000000433EA8: D73C0014
	v_cndmask_b32_e32 v1, 1, v20, vcc_lo                       // 000000433EAC: 02022881
	.long 0xd73c0012                                           // 000000433EB0: D73C0012
	v_cndmask_b32_e32 v1, 1, v18, vcc_lo                       // 000000433EB4: 02022481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000433EB8: BF870091
	.long 0xd7006a12                                           // 000000433EBC: D7006A12
	v_cndmask_b32_e32 v1, v22, v18, vcc_lo                     // 000000433EC0: 02022516
	v_add_co_ci_u32_e64 v19, null, v23, v19, vcc_lo            // 000000433EC4: D5207C13 01AA2717
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000433ECC: BF870092
	.long 0xd7006a12                                           // 000000433ED0: D7006A12
	v_cndmask_b32_e32 v1, v18, v20, vcc_lo                     // 000000433ED4: 02022912
	v_add_co_ci_u32_e64 v19, null, v19, v21, vcc_lo            // 000000433ED8: D5207C13 01AA2B13
	global_store_d16_hi_b16 v[18:19], v17, off                 // 000000433EE0: DC960000 007C1112
	s_cbranch_execnz 7                                         // 000000433EE8: BFA60007 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi4ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2f08>
	.long 0xd7006a12                                           // 000000433EEC: D7006A12
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 000000433EF0: 02020300
	s_delay_alu instid0(VALU_DEP_1)                            // 000000433EF4: BF870001
	v_add_co_ci_u32_e64 v19, null, v8, v2, vcc_lo              // 000000433EF8: D5207C13 01AA0508
	global_store_d16_hi_b16 v[18:19], v17, off offset:128      // 000000433F00: DC960080 007C1112
	global_load_d16_b16 v17, v[6:7], off offset:160            // 000000433F08: DC8200A0 117C0006
	v_cndmask_b32_e64 v15, -v15, v15, s0                       // 000000433F10: D501000F 20021F0F
	v_cmp_ne_u32_e32 vcc_lo, 1, v14                            // 000000433F18: 7C9A1C81
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000433F1C: BF8700A2
	v_add_f32_e32 v15, v15, v16                                // 000000433F20: 061E210F
	s_and_b32 vcc_lo, exec_lo, vcc_lo                          // 000000433F24: 8B6A6A7E
	v_mul_f32_e32 v15, 0x3db504f3, v15                         // 000000433F28: 101E1EFF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 000000433F30: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000433F34: BF870091
	v_fma_mix_f32 v15, v17, v15, neg(0) op_sel_hi:[1,0,0]      // 000000433F38: CC20000F 8A021F11
	v_bfe_u32 v16, v15, 16, 1                                  // 000000433F40: D6100010 0205210F
	s_delay_alu instid0(VALU_DEP_1)                            // 000000433F48: BF870001
	v_add3_u32 v15, v15, v16, 0x7fff                           // 000000433F4C: D655000F 03FE210F 00007FFF
	s_cbranch_vccnz 204                                        // 000000433F58: BFA400CC <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi4ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x328c>
	v_or_b32_e32 v16, 0x50, v3                                 // 000000433F5C: 382006FF 00000050
	v_lshrrev_b32_e32 v17, 23, v11                             // 000000433F64: 32221697
	v_mov_b32_e32 v19, s15                                     // 000000433F68: 7E26020F
	v_mov_b32_e32 v21, s14                                     // 000000433F6C: 7E2A020E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000433F70: BF870093
	v_add_nc_u32_e32 v17, v16, v17                             // 000000433F74: 4A222310
	v_and_b32_e32 v18, 0xfffffe00, v17                         // 000000433F78: 362422FF FFFFFE00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000433F80: BF870091
	v_sub_nc_u32_e32 v18, v16, v18                             // 000000433F84: 4C242510
	v_cmp_gt_i32_e32 vcc_lo, 0x100, v18                        // 000000433F88: 7C8824FF 00000100
	v_add_nc_u32_e32 v20, 0xffffff00, v18                      // 000000433F90: 4A2824FF FFFFFF00
	v_cndmask_b32_e32 v22, s25, v19, vcc_lo                    // 000000433F98: 022C2619
	v_ashrrev_i32_e32 v17, 9, v17                              // 000000433F9C: 34222289
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000433FA0: BF8701A3
	v_cndmask_b32_e32 v18, v20, v18, vcc_lo                    // 000000433FA4: 02242514
	v_cndmask_b32_e32 v20, s24, v21, vcc_lo                    // 000000433FA8: 02282A18
	v_lshlrev_b32_e32 v16, 8, v17                              // 000000433FAC: 30202288
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000433FB0: BF870193
	v_ashrrev_i32_e32 v19, 31, v18                             // 000000433FB4: 3426249F
	.long 0xd7006a14                                           // 000000433FB8: D7006A14
	v_cndmask_b32_e32 v1, v20, v4, vcc_lo                      // 000000433FBC: 02020914
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000433FC0: BF870211
	v_add_co_ci_u32_e64 v21, null, v22, v5, vcc_lo             // 000000433FC4: D5207C15 01AA0B16
	v_ashrrev_i32_e32 v17, 31, v16                             // 000000433FCC: 3422209F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000433FD0: BF870114
	.long 0xd73c0012                                           // 000000433FD4: D73C0012
	v_cndmask_b32_e32 v1, 1, v18, vcc_lo                       // 000000433FD8: 02022481
	.long 0xd73c0010                                           // 000000433FDC: D73C0010
	v_cndmask_b32_e32 v1, 1, v16, vcc_lo                       // 000000433FE0: 02022081
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000433FE4: BF870091
	.long 0xd7006a10                                           // 000000433FE8: D7006A10
	v_cndmask_b32_e32 v1, v20, v16, vcc_lo                     // 000000433FEC: 02022114
	v_add_co_ci_u32_e64 v17, null, v21, v17, vcc_lo            // 000000433FF0: D5207C11 01AA2315
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000433FF8: BF870092
	.long 0xd7006a10                                           // 000000433FFC: D7006A10
	v_cndmask_b32_e32 v1, v16, v18, vcc_lo                     // 000000434000: 02022510
	v_add_co_ci_u32_e64 v17, null, v17, v19, vcc_lo            // 000000434004: D5207C11 01AA2711
	global_store_d16_hi_b16 v[16:17], v15, off                 // 00000043400C: DC960000 007C0F10
	s_cbranch_execnz 7                                         // 000000434014: BFA60007 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi4ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3034>
	.long 0xd7006a10                                           // 000000434018: D7006A10
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 00000043401C: 02020300
	s_delay_alu instid0(VALU_DEP_1)                            // 000000434020: BF870001
	v_add_co_ci_u32_e64 v17, null, v8, v2, vcc_lo              // 000000434024: D5207C11 01AA0508
	global_store_d16_hi_b16 v[16:17], v15, off offset:160      // 00000043402C: DC9600A0 007C0F10
	global_load_d16_b16 v15, v[6:7], off offset:192            // 000000434034: DC8200C0 0F7C0006
	v_cndmask_b32_e64 v12, -v12, v12, s0                       // 00000043403C: D501000C 2002190C
	v_cmp_ne_u32_e32 vcc_lo, 1, v14                            // 000000434044: 7C9A1C81
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000434048: BF8700A2
	v_add_f32_e32 v12, v12, v13                                // 00000043404C: 06181B0C
	s_and_b32 vcc_lo, exec_lo, vcc_lo                          // 000000434050: 8B6A6A7E
	v_mul_f32_e32 v12, 0x3db504f3, v12                         // 000000434054: 101818FF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 00000043405C: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000434060: BF870091
	v_fma_mix_f32 v12, v15, v12, neg(0) op_sel_hi:[1,0,0]      // 000000434064: CC20000C 8A02190F
	v_bfe_u32 v13, v12, 16, 1                                  // 00000043406C: D610000D 0205210C
	s_delay_alu instid0(VALU_DEP_1)                            // 000000434074: BF870001
	v_add3_u32 v12, v12, v13, 0x7fff                           // 000000434078: D655000C 03FE1B0C 00007FFF
	s_cbranch_vccnz 130                                        // 000000434084: BFA40082 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi4ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3290>
	v_or_b32_e32 v13, 0x60, v3                                 // 000000434088: 381A06FF 00000060
	v_lshrrev_b32_e32 v15, 23, v11                             // 000000434090: 321E1697
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000434094: BF870091
	v_dual_mov_b32 v18, s14 :: v_dual_add_nc_u32 v15, v13, v15 // 000000434098: CA20000E 120E1F0D
	v_and_b32_e32 v16, 0xfffffe00, v15                         // 0000004340A0: 36201EFF FFFFFE00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000004340A8: BF8701B1
	v_sub_nc_u32_e32 v13, v13, v16                             // 0000004340AC: 4C1A210D
	v_mov_b32_e32 v16, s15                                     // 0000004340B0: 7E20020F
	v_ashrrev_i32_e32 v15, 9, v15                              // 0000004340B4: 341E1E89
	v_cmp_gt_i32_e32 vcc_lo, 0x100, v13                        // 0000004340B8: 7C881AFF 00000100
	v_add_nc_u32_e32 v17, 0xffffff00, v13                      // 0000004340C0: 4A221AFF FFFFFF00
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000004340C8: BF8701A3
	v_lshlrev_b32_e32 v15, 8, v15                              // 0000004340CC: 301E1E88
	v_cndmask_b32_e32 v19, s25, v16, vcc_lo                    // 0000004340D0: 02262019
	v_cndmask_b32_e32 v17, v17, v13, vcc_lo                    // 0000004340D4: 02221B11
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000004340D8: BF8701A3
	v_ashrrev_i32_e32 v16, 31, v15                             // 0000004340DC: 34201E9F
	v_cndmask_b32_e32 v13, s24, v18, vcc_lo                    // 0000004340E0: 021A2418
	v_ashrrev_i32_e32 v18, 31, v17                             // 0000004340E4: 3424229F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000004340E8: BF870193
	.long 0xd73c000f                                           // 0000004340EC: D73C000F
	v_cndmask_b32_e32 v1, 1, v15, vcc_lo                       // 0000004340F0: 02021E81
	.long 0xd7006a0d                                           // 0000004340F4: D7006A0D
	v_cndmask_b32_e32 v1, v13, v4, vcc_lo                      // 0000004340F8: 0202090D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004340FC: BF870211
	v_add_co_ci_u32_e64 v19, null, v19, v5, vcc_lo             // 000000434100: D5207C13 01AA0B13
	.long 0xd73c0011                                           // 000000434108: D73C0011
	v_cndmask_b32_e32 v1, 1, v17, vcc_lo                       // 00000043410C: 02022281
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000434110: BF870093
	.long 0xd7006a0d                                           // 000000434114: D7006A0D
	v_cndmask_b32_e32 v1, v13, v15, vcc_lo                     // 000000434118: 02021F0D
	v_add_co_ci_u32_e64 v16, null, v19, v16, vcc_lo            // 00000043411C: D5207C10 01AA2113
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000434124: BF870092
	.long 0xd7006a0f                                           // 000000434128: D7006A0F
	v_cndmask_b32_e32 v1, v13, v17, vcc_lo                     // 00000043412C: 0202230D
	v_add_co_ci_u32_e64 v16, null, v16, v18, vcc_lo            // 000000434130: D5207C10 01AA2510
	global_store_d16_hi_b16 v[15:16], v12, off                 // 000000434138: DC960000 007C0C0F
	s_cbranch_execnz 7                                         // 000000434140: BFA60007 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi4ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3160>
	.long 0xd7006a0f                                           // 000000434144: D7006A0F
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 000000434148: 02020300
	s_delay_alu instid0(VALU_DEP_1)                            // 00000043414C: BF870001
	v_add_co_ci_u32_e64 v16, null, v8, v2, vcc_lo              // 000000434150: D5207C10 01AA0508
	global_store_d16_hi_b16 v[15:16], v12, off offset:192      // 000000434158: DC9600C0 007C0C0F
	global_load_d16_b16 v6, v[6:7], off offset:224             // 000000434160: DC8200E0 067C0006
	v_cndmask_b32_e64 v7, -v9, v9, s0                          // 000000434168: D5010007 20021309
	v_cmp_ne_u32_e32 vcc_lo, 1, v14                            // 000000434170: 7C9A1C81
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000434174: BF8700A2
	v_add_f32_e32 v7, v7, v10                                  // 000000434178: 060E1507
	s_and_b32 vcc_lo, exec_lo, vcc_lo                          // 00000043417C: 8B6A6A7E
	v_mul_f32_e32 v7, 0x3db504f3, v7                           // 000000434180: 100E0EFF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 000000434188: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000043418C: BF870091
	v_fma_mix_f32 v6, v6, v7, neg(0) op_sel_hi:[1,0,0]         // 000000434190: CC200006 8A020F06
	v_bfe_u32 v7, v6, 16, 1                                    // 000000434198: D6100007 02052106
	s_delay_alu instid0(VALU_DEP_1)                            // 0000004341A0: BF870001
	v_add3_u32 v6, v6, v7, 0x7fff                              // 0000004341A4: D6550006 03FE0F06 00007FFF
	s_cbranch_vccnz 56                                         // 0000004341B0: BFA40038 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi4ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3294>
	v_or_b32_e32 v3, 0x70, v3                                  // 0000004341B4: 380606FF 00000070
	v_lshrrev_b32_e32 v7, 23, v11                              // 0000004341BC: 320E1697
	v_mov_b32_e32 v10, s15                                     // 0000004341C0: 7E14020F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004341C4: BF870092
	v_dual_mov_b32 v12, s14 :: v_dual_add_nc_u32 v7, v3, v7    // 0000004341C8: CA20000E 0C060F03
	v_and_b32_e32 v9, 0xfffffe00, v7                           // 0000004341D0: 36120EFF FFFFFE00
	v_ashrrev_i32_e32 v7, 9, v7                                // 0000004341D8: 340E0E89
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000004341DC: BF870112
	v_sub_nc_u32_e32 v3, v3, v9                                // 0000004341E0: 4C061303
	v_lshlrev_b32_e32 v9, 8, v7                                // 0000004341E4: 30120E88
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000004341E8: BF870232
	v_cmp_gt_i32_e32 vcc_lo, 0x100, v3                         // 0000004341EC: 7C8806FF 00000100
	v_add_nc_u32_e32 v7, 0xffffff00, v3                        // 0000004341F4: 4A0E06FF FFFFFF00
	v_cndmask_b32_e32 v13, s25, v10, vcc_lo                    // 0000004341FC: 021A1419
	v_ashrrev_i32_e32 v10, 31, v9                              // 000000434200: 3414129F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000434204: BF8701A3
	v_cndmask_b32_e32 v11, v7, v3, vcc_lo                      // 000000434208: 02160707
	v_cndmask_b32_e32 v3, s24, v12, vcc_lo                     // 00000043420C: 02061818
	.long 0xd73c0009                                           // 000000434210: D73C0009
	v_cndmask_b32_e32 v1, 1, v9, vcc_lo                        // 000000434214: 02021281
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000434218: BF870193
	v_ashrrev_i32_e32 v12, 31, v11                             // 00000043421C: 3418169F
	.long 0xd7006a07                                           // 000000434220: D7006A07
	v_cndmask_b32_e32 v1, v3, v4, vcc_lo                       // 000000434224: 02020903
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000434228: BF870191
	v_add_co_ci_u32_e64 v5, null, v13, v5, vcc_lo              // 00000043422C: D5207C05 01AA0B0D
	.long 0xd73c0003                                           // 000000434234: D73C0003
	v_cndmask_b32_e32 v1, 1, v11, vcc_lo                       // 000000434238: 02021681
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000043423C: BF870093
	.long 0xd7006a07                                           // 000000434240: D7006A07
	v_cndmask_b32_e32 v1, v7, v9, vcc_lo                       // 000000434244: 02021307
	v_add_co_ci_u32_e64 v5, null, v5, v10, vcc_lo              // 000000434248: D5207C05 01AA1505
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000434250: BF870092
	.long 0xd7006a03                                           // 000000434254: D7006A03
	v_cndmask_b32_e32 v1, v7, v3, vcc_lo                       // 000000434258: 02020707
	v_add_co_ci_u32_e64 v4, null, v5, v4, vcc_lo               // 00000043425C: D5207C04 01AA0905
	global_store_d16_hi_b16 v[3:4], v6, off                    // 000000434264: DC960000 007C0603
	s_cbranch_execnz 62559                                     // 00000043426C: BFA6F45F <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi4ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3ec>
	s_branch 8                                                 // 000000434270: BFA00008 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi4ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3294>
	s_branch 62557                                             // 000000434274: BFA0F45D <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi4ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3ec>
	s_branch 65011                                             // 000000434278: BFA0FDF3 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi4ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2a48>
	s_branch 65085                                             // 00000043427C: BFA0FE3D <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi4ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2b74>
	s_branch 65158                                             // 000000434280: BFA0FE86 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi4ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2c9c>
	s_branch 65231                                             // 000000434284: BFA0FECF <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi4ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2dc4>
	s_branch 65304                                             // 000000434288: BFA0FF18 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi4ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2eec>
	s_branch 65378                                             // 00000043428C: BFA0FF62 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi4ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3018>
	s_branch 65452                                             // 000000434290: BFA0FFAC <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi4ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3144>
	.long 0xd7006a00                                           // 000000434294: D7006A00
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 000000434298: 02020300
	s_delay_alu instid0(VALU_DEP_1)                            // 00000043429C: BF870001
	v_add_co_ci_u32_e64 v1, null, v8, v2, vcc_lo               // 0000004342A0: D5207C01 01AA0508
	global_store_d16_hi_b16 v[0:1], v6, off offset:224         // 0000004342A8: DC9600E0 007C0600
	s_nop 0                                                    // 0000004342B0: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 0000004342B4: BFB60003
	s_endpgm                                                   // 0000004342B8: BFB00000
		...

