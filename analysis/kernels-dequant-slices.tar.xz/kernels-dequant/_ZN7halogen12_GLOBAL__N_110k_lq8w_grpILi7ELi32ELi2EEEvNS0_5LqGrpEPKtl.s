00000000002fa400 <_ZN7halogen12_GLOBAL__N_110k_lq8w_grpILi7ELi32ELi2EEEvNS0_5LqGrpEPKtl>:
; _ZN7halogen12_GLOBAL__N_110k_lq8w_grpILi7ELi32ELi2EEEvNS0_5LqGrpEPKtl():
	s_clause 0x3                                               // 0000002FA400: BF850003
	s_load_b32 s3, s[0:1], 0x120                               // 0000002FA404: F40000C0 F8000120
	s_load_b32 s4, s[0:1], 0x88                                // 0000002FA40C: F4000100 F8000088
	s_load_b32 s5, s[0:1], 0xd0                                // 0000002FA414: F4000140 F80000D0
	s_load_b32 s6, s[0:1], 0x118                               // 0000002FA41C: F4000180 F8000118
	v_lshrrev_b32_e32 v3, 5, v0                                // 0000002FA424: 32060085
	v_dual_mov_b32 v16, 0 :: v_dual_and_b32 v15, 31, v0        // 0000002FA428: CA240080 100E009F
	v_mov_b32_e32 v27, 0                                       // 0000002FA430: 7E360280
	s_waitcnt lgkmcnt(0)                                       // 0000002FA434: BF89FC07
	s_cmp_gt_i32 s3, 1                                         // 0000002FA438: BF028103
	s_cselect_b32 s7, -1, 0                                    // 0000002FA43C: 980780C1
	s_cmp_ge_i32 s2, s4                                        // 0000002FA440: BF030402
	s_cselect_b32 s4, -1, 0                                    // 0000002FA444: 980480C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002FA448: BF870009
	s_and_b32 s4, s7, s4                                       // 0000002FA44C: 8B040407
	s_cmp_gt_i32 s3, 2                                         // 0000002FA450: BF028203
	v_cndmask_b32_e64 v1, 0, 1, s4                             // 0000002FA454: D5010001 00110280
	s_cselect_b32 s7, -1, 0                                    // 0000002FA45C: 980780C1
	s_cmp_ge_i32 s2, s5                                        // 0000002FA460: BF030502
	s_cselect_b32 s5, -1, 0                                    // 0000002FA464: 980580C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002FA468: BF870009
	s_and_b32 s4, s7, s5                                       // 0000002FA46C: 8B040507
	s_cmp_gt_i32 s3, 3                                         // 0000002FA470: BF028303
	v_readfirstlane_b32 s5, v1                                 // 0000002FA474: 7E0A0501
	s_cselect_b32 s3, -1, 0                                    // 0000002FA478: 980380C1
	s_cmp_ge_i32 s2, s6                                        // 0000002FA47C: BF030602
	s_cselect_b32 s6, -1, 0                                    // 0000002FA480: 980680C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002FA484: BF870009
	s_and_b32 s3, s3, s6                                       // 0000002FA488: 8B030603
	s_and_b32 s4, s4, exec_lo                                  // 0000002FA48C: 8B047E04
	s_cselect_b32 s4, 2, s5                                    // 0000002FA490: 98040582
	s_and_b32 s3, s3, exec_lo                                  // 0000002FA494: 8B037E03
	s_cselect_b32 s3, 3, s4                                    // 0000002FA498: 98030483
	s_load_b128 s[4:7], s[0:1], 0x128                          // 0000002FA49C: F4080100 F8000128
	s_mulk_i32 s3, 0x48                                        // 0000002FA4A4: B8030048
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002FA4A8: BF870009
	s_add_u32 s10, s0, s3                                      // 0000002FA4AC: 800A0300
	s_addc_u32 s11, s1, 0                                      // 0000002FA4B0: 820B8001
	s_clause 0x1                                               // 0000002FA4B4: BF850001
	s_load_b64 s[8:9], s[10:11], 0x30                          // 0000002FA4B8: F4040205 F8000030
	s_load_b32 s12, s[10:11], 0x40                             // 0000002FA4C0: F4000305 F8000040
	s_waitcnt lgkmcnt(0)                                       // 0000002FA4C8: BF89FC07
	.long 0xd451000e                                           // 0000002FA4CC: D451000E
	v_cndmask_b32_e32 v0, s8, v137, vcc_lo                     // 0000002FA4D0: 02011208
	s_and_b32 s0, s14, exec_lo                                 // 0000002FA4D4: 8B007E0E
	s_cselect_b32 s1, 8, 2                                     // 0000002FA4D8: 98018288
	s_cselect_b32 s3, 3, 1                                     // 0000002FA4DC: 98038183
	v_cvt_f32_ubyte0_e32 v1, s1                                // 0000002FA4E0: 7E022201
	s_sub_i32 s12, s2, s12                                     // 0000002FA4E4: 818C0C02
	s_add_i32 s0, s1, -1                                       // 0000002FA4E8: 8100C101
	s_ashr_i32 s13, s12, 31                                    // 0000002FA4EC: 860D9F0C
	s_and_b32 s15, s14, exec_lo                                // 0000002FA4F0: 8B0F7E0E
	v_rcp_iflag_f32_e32 v1, v1                                 // 0000002FA4F4: 7E025701
	s_cselect_b32 s15, 0, 2                                    // 0000002FA4F8: 980F8280
	s_ashr_i32 s16, s7, 31                                     // 0000002FA4FC: 86109F07
	s_lshl_b64 s[12:13], s[12:13], s15                         // 0000002FA500: 848C0F0C
	s_lshr_b32 s16, s16, 28                                    // 0000002FA504: 85109C10
	v_lshrrev_b32_e32 v13, s3, v3                              // 0000002FA508: 321A0603
	s_add_u32 s16, s6, s16                                     // 0000002FA50C: 80101006
	s_addc_u32 s17, s7, 0                                      // 0000002FA510: 82118007
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002FA514: BF870299
	s_ashr_i64 s[16:17], s[16:17], 4                           // 0000002FA518: 86908410
	v_readfirstlane_b32 s18, v1                                // 0000002FA51C: 7E240501
	s_add_u32 s20, s16, s6                                     // 0000002FA520: 80140610
	s_addc_u32 s17, s17, s7                                    // 0000002FA524: 82110711
	s_sub_i32 s19, 0, s1                                       // 0000002FA528: 81930180
	s_add_i32 s21, s0, s16                                     // 0000002FA52C: 81151000
	s_mul_f32 s18, s18, 0x4f7ffffe                             // 0000002FA530: A212FF12 4F7FFFFE
	s_abs_i32 s22, s21                                         // 0000002FA538: BE961515
	.long 0xd7000c01                                           // 0000002FA53C: D7000C01
	v_cndmask_b32_e32 v1, s12, v13, vcc_lo                     // 0000002FA540: 02021A0C
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000002FA544: BF8704B9
	s_cvt_u32_f32 s18, s18                                     // 0000002FA548: BE926712
	v_add_co_ci_u32_e64 v2, null, s13, 0, s12                  // 0000002FA54C: D5207C02 0031000D
	s_ashr_i32 s13, s21, 31                                    // 0000002FA554: 860D9F15
	s_mul_i32 s19, s19, s18                                    // 0000002FA558: 96131213
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002FA55C: BF870009
	s_mul_hi_u32 s19, s18, s19                                 // 0000002FA560: 96931312
	v_cmp_gt_i64_e32 vcc_lo, s[8:9], v[1:2]                    // 0000002FA564: 7CA80208
	s_add_i32 s23, s18, s19                                    // 0000002FA568: 81171312
	s_load_b64 s[18:19], s[10:11], null                        // 0000002FA56C: F4040485 F8000000
	s_mul_hi_u32 s23, s22, s23                                 // 0000002FA574: 96971716
	v_and_b32_e32 v14, s0, v3                                  // 0000002FA578: 361C0600
	s_mul_i32 s12, s23, s1                                     // 0000002FA57C: 960C0117
	s_add_i32 s21, s23, 1                                      // 0000002FA580: 81158117
	s_sub_i32 s12, s22, s12                                    // 0000002FA584: 818C0C16
	v_cndmask_b32_e32 v2, 0, v2, vcc_lo                        // 0000002FA588: 02040480
	s_sub_i32 s22, s12, s1                                     // 0000002FA58C: 8196010C
	s_cmp_ge_u32 s12, s1                                       // 0000002FA590: BF09010C
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 0000002FA594: 02020280
	s_cselect_b32 s21, s21, s23                                // 0000002FA598: 98151715
	s_cselect_b32 s12, s22, s12                                // 0000002FA59C: 980C0C16
	s_add_i32 s22, s21, 1                                      // 0000002FA5A0: 81168115
	s_cmp_ge_u32 s12, s1                                       // 0000002FA5A4: BF09010C
	.long 0xd72c0004                                           // 0000002FA5A8: D72C0004
	v_cndmask_b32_e32 v0, v2, v20, vcc_lo                      // 0000002FA5AC: 02002902
	s_cselect_b32 s0, s22, s21                                 // 0000002FA5B0: 98001516
	.long 0xd72c0006                                           // 0000002FA5B4: D72C0006
	v_cndmask_b32_e32 v0, v1, v17, vcc_lo                      // 0000002FA5B8: 02002301
	s_xor_b32 s0, s0, s13                                      // 0000002FA5BC: 8D000D00
	v_mov_b32_e32 v2, 0                                        // 0000002FA5C0: 7E040280
	s_sub_i32 s0, s0, s13                                      // 0000002FA5C4: 81800D00
	s_waitcnt lgkmcnt(0)                                       // 0000002FA5C8: BF89FC07
	v_mad_u64_u32 v[9:10], null, v1, s20, s[18:19]             // 0000002FA5CC: D6FE7C09 00482901
	.long 0xd72c0005                                           // 0000002FA5D4: D72C0005
	v_cndmask_b32_e32 v0, v14, v0, vcc_lo                      // 0000002FA5D8: 0200010E
	v_mov_b32_e32 v1, 0                                        // 0000002FA5DC: 7E020280
	v_mov_b32_e32 v3, 0                                        // 0000002FA5E0: 7E060280
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002FA5E4: BF870214
	v_add3_u32 v10, v4, v10, v6                                // 0000002FA5E8: D655000A 041A1504
	v_dual_mov_b32 v4, 0 :: v_dual_add_nc_u32 v7, s0, v5       // 0000002FA5F0: CA200080 04060A00
	v_add_nc_u32_e32 v17, v5, v15                              // 0000002FA5F8: 4A221F05
	.long 0xd7006a13                                           // 0000002FA5FC: D7006A13
	v_cndmask_b32_e32 v0, v9, v6, vcc_lo                       // 0000002FA600: 02000D09
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002FA604: BF870123
	v_min_i32_e32 v18, s16, v7                                 // 0000002FA608: 22240E10
	v_add_co_ci_u32_e64 v20, null, s7, v10, vcc_lo             // 0000002FA60C: D5207C14 01AA1407
	v_cmp_lt_i32_e32 vcc_lo, v17, v18                          // 0000002FA614: 7C822511
	s_and_saveexec_b32 s12, vcc_lo                             // 0000002FA618: BE8C206A
	s_cbranch_execz 19                                         // 0000002FA61C: BFA50013 <_ZN7halogen12_GLOBAL__N_110k_lq8w_grpILi7ELi32ELi2EEEvNS0_5LqGrpEPKtl+0x26c>
	v_lshlrev_b32_e32 v1, 4, v17                               // 0000002FA620: 30022284
	v_and_b32_e32 v3, -4, v17                                  // 0000002FA624: 360622C4
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002FA628: BF870112
	v_ashrrev_i32_e32 v2, 31, v1                               // 0000002FA62C: 3404029F
	v_ashrrev_i32_e32 v4, 31, v3                               // 0000002FA630: 3408069F
	.long 0xd7000001                                           // 0000002FA634: D7000001
	v_cndmask_b32_e32 v1, v9, v1, vcc_lo                       // 0000002FA638: 02020309
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002FA63C: BF8700A1
	v_add_co_ci_u32_e64 v2, null, v10, v2, s0                  // 0000002FA640: D5207C02 0002050A
	.long 0xd7000006                                           // 0000002FA648: D7000006
	v_cndmask_b32_e32 v1, v19, v3, vcc_lo                      // 0000002FA64C: 02020713
	v_add_co_ci_u32_e64 v7, null, v20, v4, s0                  // 0000002FA650: D5207C07 00020914
	s_clause 0x1                                               // 0000002FA658: BF850001
	global_load_b128 v[1:4], v[1:2], off                       // 0000002FA65C: DC5E0000 017C0001
	global_load_b32 v27, v[6:7], off                           // 0000002FA664: DC520000 1B7C0006
	s_or_b32 exec_lo, exec_lo, s12                             // 0000002FA66C: 8C7E0C7E
	v_dual_mov_b32 v22, 0 :: v_dual_mov_b32 v23, 0             // 0000002FA670: CA100080 16160080
	v_dual_mov_b32 v24, 0 :: v_dual_mov_b32 v25, 0             // 0000002FA678: CA100080 18180080
	v_dual_mov_b32 v26, 0 :: v_dual_mov_b32 v21, 0             // 0000002FA680: CA100080 1A140080
	s_and_saveexec_b32 s16, vcc_lo                             // 0000002FA688: BE90206A
	s_cbranch_execz 438                                        // 0000002FA68C: BFA501B6 <_ZN7halogen12_GLOBAL__N_110k_lq8w_grpILi7ELi32ELi2EEEvNS0_5LqGrpEPKtl+0x968>
	v_dual_mov_b32 v21, 0 :: v_dual_lshlrev_b32 v6, 4, v15     // 0000002FA690: CA220080 15061E84
	v_dual_mov_b32 v26, 0 :: v_dual_mov_b32 v25, 0             // 0000002FA698: CA100080 1A180080
	v_dual_mov_b32 v24, 0 :: v_dual_mov_b32 v23, 0             // 0000002FA6A0: CA100080 18160080
	s_delay_alu instid0(VALU_DEP_3)                            // 0000002FA6A8: BF870003
	v_lshl_add_u32 v11, v5, 4, v6                              // 0000002FA6AC: D646000B 04190905
	v_mov_b32_e32 v22, 0                                       // 0000002FA6B4: 7E2C0280
	v_mov_b32_e32 v16, 0                                       // 0000002FA6B8: 7E200280
	s_mul_i32 s0, s7, 6                                        // 0000002FA6BC: 96008607
	s_mul_hi_u32 s17, s6, 6                                    // 0000002FA6C0: 96918606
	s_lshl_b64 s[12:13], s[6:7], 2                             // 0000002FA6C4: 848C8206
	s_add_i32 s17, s17, s0                                     // 0000002FA6C8: 81110011
	s_mul_i32 s19, s6, 6                                       // 0000002FA6CC: 96138606
	s_mov_b32 s18, 0                                           // 0000002FA6D0: BE920080
	s_lshl_b64 s[6:7], s[6:7], 1                               // 0000002FA6D4: 84868106
	s_branch 381                                               // 0000002FA6D8: BFA0017D <_ZN7halogen12_GLOBAL__N_110k_lq8w_grpILi7ELi32ELi2EEEvNS0_5LqGrpEPKtl+0x8d0>
	s_or_b32 exec_lo, exec_lo, s20                             // 0000002FA6DC: 8C7E147E
	v_ashrrev_i32_e32 v12, 31, v11                             // 0000002FA6E0: 3418169F
	v_cvt_f32_ubyte2_e32 v86, v1                               // 0000002FA6E4: 7EAC2701
	v_cvt_f32_ubyte0_e32 v88, v2                               // 0000002FA6E8: 7EB02302
	v_cvt_f32_ubyte1_e32 v89, v2                               // 0000002FA6EC: 7EB22502
	v_cvt_f32_ubyte2_e32 v90, v2                               // 0000002FA6F0: 7EB42702
	.long 0xd73c000b                                           // 0000002FA6F4: D73C000B
	v_cndmask_b32_e32 v1, 1, v11, vcc_lo                       // 0000002FA6F8: 02021681
	v_cvt_f32_ubyte3_e32 v91, v2                               // 0000002FA6FC: 7EB62902
	s_waitcnt vmcnt(1)                                         // 0000002FA700: BF8907F7
	v_mov_b32_e32 v2, v6                                       // 0000002FA704: 7E040306
	v_cvt_f32_ubyte3_e32 v87, v1                               // 0000002FA708: 7EAE2901
	v_cvt_f32_ubyte0_e32 v92, v3                               // 0000002FA70C: 7EB82303
	v_cvt_f32_ubyte1_e32 v93, v3                               // 0000002FA710: 7EBA2503
	.long 0xd700000b                                           // 0000002FA714: D700000B
	v_cndmask_b32_e32 v1, s4, v11, vcc_lo                      // 0000002FA718: 02021604
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000002FA71C: BF8701A1
	v_add_co_ci_u32_e64 v12, null, s5, v12, s0                 // 0000002FA720: D5207C0C 00021805
	v_cvt_f32_ubyte2_e32 v94, v3                               // 0000002FA728: 7EBC2703
	.long 0xd700003e                                           // 0000002FA72C: D700003E
	v_cndmask_b32_e32 v0, v11, v6, vcc_lo                      // 0000002FA730: 02000D0B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002FA734: BF870001
	v_add_co_ci_u32_e64 v63, null, s7, v12, s0                 // 0000002FA738: D5207C3F 00021807
	.long 0xd7000042                                           // 0000002FA740: D7000042
	v_cndmask_b32_e32 v0, v11, v12, vcc_lo                     // 0000002FA744: 0200190B
	s_clause 0x1                                               // 0000002FA748: BF850001
	global_load_b128 v[30:33], v[11:12], off                   // 0000002FA74C: DC5E0000 1E7C000B
	global_load_b128 v[34:37], v[62:63], off                   // 0000002FA754: DC5E0000 227C003E
	v_add_co_ci_u32_e64 v67, null, s13, v12, s0                // 0000002FA75C: D5207C43 0002180D
	.long 0xd7000046                                           // 0000002FA764: D7000046
	v_cndmask_b32_e32 v0, v11, v19, vcc_lo                     // 0000002FA768: 0200270B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002FA76C: BF8700A1
	v_add_co_ci_u32_e64 v71, null, s17, v12, s0                // 0000002FA770: D5207C47 00021811
	.long 0xd700004a                                           // 0000002FA778: D700004A
	v_cndmask_b32_e32 v0, v66, v12, vcc_lo                     // 0000002FA77C: 02001942
	v_add_co_ci_u32_e64 v75, null, s13, v67, s0                // 0000002FA780: D5207C4B 0002860D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002FA788: BF870094
	.long 0xd700004e                                           // 0000002FA78C: D700004E
	v_cndmask_b32_e32 v0, v70, v12, vcc_lo                     // 0000002FA790: 02001946
	v_add_co_ci_u32_e64 v79, null, s13, v71, s0                // 0000002FA794: D5207C4F 00028E0D
	s_clause 0x3                                               // 0000002FA79C: BF850003
	global_load_b128 v[38:41], v[66:67], off                   // 0000002FA7A0: DC5E0000 267C0042
	global_load_b128 v[42:45], v[70:71], off                   // 0000002FA7A8: DC5E0000 2A7C0046
	global_load_b128 v[46:49], v[74:75], off                   // 0000002FA7B0: DC5E0000 2E7C004A
	global_load_b128 v[50:53], v[78:79], off                   // 0000002FA7B8: DC5E0000 327C004E
	.long 0xd7000052                                           // 0000002FA7C0: D7000052
	v_cndmask_b32_e32 v0, v74, v12, vcc_lo                     // 0000002FA7C4: 0200194A
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002FA7C8: BF870001
	v_add_co_ci_u32_e64 v83, null, s13, v75, s0                // 0000002FA7CC: D5207C53 0002960D
	s_clause 0x7                                               // 0000002FA7D4: BF850007
	global_load_b128 v[54:57], v[82:83], off                   // 0000002FA7D8: DC5E0000 367C0052
	global_load_b128 v[58:61], v[11:12], off offset:16         // 0000002FA7E0: DC5E0010 3A7C000B
	global_load_b128 v[62:65], v[62:63], off offset:16         // 0000002FA7E8: DC5E0010 3E7C003E
	global_load_b128 v[66:69], v[66:67], off offset:16         // 0000002FA7F0: DC5E0010 427C0042
	global_load_b128 v[70:73], v[70:71], off offset:16         // 0000002FA7F8: DC5E0010 467C0046
	global_load_b128 v[74:77], v[74:75], off offset:16         // 0000002FA800: DC5E0010 4A7C004A
	global_load_b128 v[78:81], v[78:79], off offset:16         // 0000002FA808: DC5E0010 4E7C004E
	global_load_b128 v[82:85], v[82:83], off offset:16         // 0000002FA810: DC5E0010 527C0052
	v_cvt_f32_ubyte0_e32 v11, v1                               // 0000002FA818: 7E162301
	v_cvt_f32_ubyte1_e32 v12, v1                               // 0000002FA81C: 7E182501
	v_cvt_f32_ubyte3_e32 v95, v3                               // 0000002FA820: 7EBE2903
	v_cvt_f32_ubyte0_e32 v96, v4                               // 0000002FA824: 7EC02304
	v_cvt_f32_ubyte1_e32 v97, v4                               // 0000002FA828: 7EC22504
	v_fma_mix_f32 v6, v11, v27, v27 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002FA82C: CC206006 146E370B
	v_cvt_f32_ubyte2_e32 v98, v4                               // 0000002FA834: 7EC42704
	v_cvt_f32_ubyte3_e32 v99, v4                               // 0000002FA838: 7EC62904
	v_dual_mov_b32 v4, v8 :: v_dual_mov_b32 v3, v7             // 0000002FA83C: CA100108 04020107
	v_fma_mix_f32 v7, v12, v27, v27 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002FA844: CC206007 146E370C
	v_fma_mix_f32 v8, v86, v27, v27 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002FA84C: CC206008 146E3756
	v_fma_mix_f32 v86, v88, v27, v27 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002FA854: CC206056 146E3758
	v_mov_b32_e32 v11, v29                                     // 0000002FA85C: 7E16031D
	v_bfe_u32 v29, v6, 16, 1                                   // 0000002FA860: D610001D 02052106
	v_fma_mix_f32 v12, v87, v27, v27 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002FA868: CC20600C 146E3757
	v_fma_mix_f32 v87, v89, v27, v27 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002FA870: CC206057 146E3759
	v_fma_mix_f32 v88, v90, v27, v27 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002FA878: CC206058 146E375A
	v_fma_mix_f32 v89, v91, v27, v27 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002FA880: CC206059 146E375B
	v_fma_mix_f32 v90, v92, v27, v27 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002FA888: CC20605A 146E375C
	v_bfe_u32 v101, v7, 16, 1                                  // 0000002FA890: D6100065 02052107
	v_bfe_u32 v102, v8, 16, 1                                  // 0000002FA898: D6100066 02052108
	v_bfe_u32 v104, v86, 16, 1                                 // 0000002FA8A0: D6100068 02052156
	v_add3_u32 v6, v6, v29, 0x7fff                             // 0000002FA8A8: D6550006 03FE3B06 00007FFF
	v_mov_b32_e32 v1, v5                                       // 0000002FA8B4: 7E020305
	.long 0x7f0a3880                                           // 0000002FA8B8: 7F0A3880
	v_fma_mix_f32 v91, v93, v27, v27 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002FA8BC: CC20605B 146E375D
	v_fma_mix_f32 v92, v94, v27, v27 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002FA8C4: CC20605C 146E375E
	v_fma_mix_f32 v93, v95, v27, v27 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002FA8CC: CC20605D 146E375F
	v_fma_mix_f32 v94, v96, v27, v27 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002FA8D4: CC20605E 146E3760
	v_bfe_u32 v103, v12, 16, 1                                 // 0000002FA8DC: D6100067 0205210C
	v_bfe_u32 v105, v87, 16, 1                                 // 0000002FA8E4: D6100069 02052157
	v_bfe_u32 v106, v88, 16, 1                                 // 0000002FA8EC: D610006A 02052158
	v_bfe_u32 v107, v89, 16, 1                                 // 0000002FA8F4: D610006B 02052159
	v_bfe_u32 v108, v90, 16, 1                                 // 0000002FA8FC: D610006C 0205215A
	v_add3_u32 v7, v7, v101, 0x7fff                            // 0000002FA904: D6550007 03FECB07 00007FFF
	v_add3_u32 v8, v8, v102, 0x7fff                            // 0000002FA910: D6550008 03FECD08 00007FFF
	v_add3_u32 v29, v86, v104, 0x7fff                          // 0000002FA91C: D655001D 03FED156 00007FFF
	.long 0x7e0a3986                                           // 0000002FA928: 7E0A3986
	v_fma_mix_f32 v95, v97, v27, v27 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002FA92C: CC20605F 146E3761
	.long 0x7fc23985                                           // 0000002FA934: 7FC23985
	v_bfe_u32 v109, v91, 16, 1                                 // 0000002FA938: D610006D 0205215B
	v_bfe_u32 v110, v92, 16, 1                                 // 0000002FA940: D610006E 0205215C
	v_bfe_u32 v111, v93, 16, 1                                 // 0000002FA948: D610006F 0205215D
	v_bfe_u32 v112, v94, 16, 1                                 // 0000002FA950: D6100070 0205215E
	v_add3_u32 v12, v12, v103, 0x7fff                          // 0000002FA958: D655000C 03FECF0C 00007FFF
	v_add3_u32 v86, v87, v105, 0x7fff                          // 0000002FA964: D6550056 03FED357 00007FFF
	v_add3_u32 v87, v88, v106, 0x7fff                          // 0000002FA970: D6550057 03FED558 00007FFF
	v_add3_u32 v88, v89, v107, 0x7fff                          // 0000002FA97C: D6550058 03FED759 00007FFF
	v_add3_u32 v89, v90, v108, 0x7fff                          // 0000002FA988: D6550059 03FED95A 00007FFF
	.long 0x7ec23988                                           // 0000002FA994: 7EC23988
	v_and_or_b32 v7, 0xffff0000, v7, v5                        // 0000002FA998: D6570007 04160EFF FFFF0000
	.long 0x7e0a399d                                           // 0000002FA9A4: 7E0A399D
	v_bfe_u32 v113, v95, 16, 1                                 // 0000002FA9A8: D6100071 0205215F
	v_add3_u32 v90, v91, v109, 0x7fff                          // 0000002FA9B0: D655005A 03FEDB5B 00007FFF
	v_add3_u32 v91, v92, v110, 0x7fff                          // 0000002FA9BC: D655005B 03FEDD5C 00007FFF
	v_add3_u32 v92, v93, v111, 0x7fff                          // 0000002FA9C8: D655005C 03FEDF5D 00007FFF
	v_add3_u32 v93, v94, v112, 0x7fff                          // 0000002FA9D4: D655005D 03FEE15E 00007FFF
	v_and_or_b32 v8, 0xffff0000, v12, v97                      // 0000002FA9E0: D6570008 058618FF FFFF0000
	v_and_or_b32 v12, 0xffff0000, v86, v5                      // 0000002FA9EC: D657000C 0416ACFF FFFF0000
	.long 0x7e0a39d9                                           // 0000002FA9F8: 7E0A39D9
	v_fma_mix_f32 v96, v98, v27, v27 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002FA9FC: CC206060 146E3762
	.long 0x7fc43985                                           // 0000002FAA04: 7FC43985
	v_add3_u32 v6, v95, v113, 0x7fff                           // 0000002FAA08: D6550006 03FEE35F 00007FFF
	.long 0x7ec439d7                                           // 0000002FAA14: 7EC439D7
	v_and_or_b32 v87, 0xffff0000, v90, v5                      // 0000002FAA18: D6570057 0416B4FF FFFF0000
	.long 0x7e0a39dd                                           // 0000002FAA24: 7E0A39DD
	v_fma_mix_f32 v27, v99, v27, v27 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002FAA28: CC20601B 146E3763
	.long 0x7fc63985                                           // 0000002FAA30: 7FC63985
	.long 0x7fc83985                                           // 0000002FAA34: 7FC83985
	v_and_or_b32 v29, 0xffff0000, v88, v98                     // 0000002FAA38: D657001D 058AB0FF FFFF0000
	v_and_or_b32 v5, 0xffff0000, v6, v5                        // 0000002FAA44: D6570005 04160CFF FFFF0000
	v_bfe_u32 v114, v96, 16, 1                                 // 0000002FAA50: D6100072 02052160
	.long 0x7ec639db                                           // 0000002FAA58: 7EC639DB
	v_bfe_u32 v115, v27, 16, 1                                 // 0000002FAA5C: D6100073 0205211B
	s_and_b32 s0, exec_lo, vcc_lo                              // 0000002FAA64: 8B006A7E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002FAA68: BF870193
	v_add3_u32 v94, v96, v114, 0x7fff                          // 0000002FAA6C: D655005E 03FEE560 00007FFF
	v_and_or_b32 v86, 0xffff0000, v92, v99                     // 0000002FAA78: D6570056 058EB8FF FFFF0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000002FAA84: BF8701A3
	v_add3_u32 v27, v27, v115, 0x7fff                          // 0000002FAA88: D655001B 03FEE71B 00007FFF
	s_or_b32 s18, s0, s18                                      // 0000002FAA94: 8C121200
	.long 0x7ec839de                                           // 0000002FAA98: 7EC839DE
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000002FAA9C: BF8700B1
	v_and_or_b32 v27, 0xffff0000, v27, v100                    // 0000002FAAA0: D657001B 059236FF FFFF0000
	s_waitcnt vmcnt(13)                                        // 0000002FAAAC: BF8937F7
	v_dot2_f32_bf16 v30, v30, v7, 0                            // 0000002FAAB0: CC1A401E 1A020F1E
	v_dot2_f32_bf16 v30, v31, v8, v30                          // 0000002FAAB8: CC1A401E 1C7A111F
	s_waitcnt vmcnt(12)                                        // 0000002FAAC0: BF8933F7
	v_dot2_f32_bf16 v31, v34, v7, 0                            // 0000002FAAC4: CC1A401F 1A020F22
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002FAACC: BF870112
	v_dot2_f32_bf16 v6, v32, v12, v30                          // 0000002FAAD0: CC1A4006 1C7A1920
	v_dot2_f32_bf16 v30, v35, v8, v31                          // 0000002FAAD8: CC1A401E 1C7E1123
	s_waitcnt vmcnt(11)                                        // 0000002FAAE0: BF892FF7
	v_dot2_f32_bf16 v34, v38, v7, 0                            // 0000002FAAE4: CC1A4022 1A020F26
	s_waitcnt vmcnt(10)                                        // 0000002FAAEC: BF892BF7
	v_dot2_f32_bf16 v38, v42, v7, 0                            // 0000002FAAF0: CC1A4026 1A020F2A
	v_dot2_f32_bf16 v6, v33, v29, v6                           // 0000002FAAF8: CC1A4006 1C1A3B21
	s_waitcnt vmcnt(8)                                         // 0000002FAB00: BF8923F7
	v_dot2_f32_bf16 v35, v50, v7, 0                            // 0000002FAB04: CC1A4023 1A020F32
	v_dot2_f32_bf16 v30, v36, v12, v30                         // 0000002FAB0C: CC1A401E 1C7A1924
	v_dot2_f32_bf16 v31, v39, v8, v34                          // 0000002FAB14: CC1A401F 1C8A1127
	v_dot2_f32_bf16 v32, v43, v8, v38                          // 0000002FAB1C: CC1A4020 1C9A112B
	v_dot2_f32_bf16 v34, v46, v7, 0                            // 0000002FAB24: CC1A4022 1A020F2E
	s_waitcnt vmcnt(7)                                         // 0000002FAB2C: BF891FF7
	v_dot2_f32_bf16 v7, v54, v7, 0                             // 0000002FAB30: CC1A4007 1A020F36
	s_waitcnt vmcnt(6)                                         // 0000002FAB38: BF891BF7
	v_dot2_f32_bf16 v6, v58, v87, v6                           // 0000002FAB3C: CC1A4006 1C1AAF3A
	v_dot2_f32_bf16 v31, v40, v12, v31                         // 0000002FAB44: CC1A401F 1C7E1928
	v_dot2_f32_bf16 v32, v44, v12, v32                         // 0000002FAB4C: CC1A4020 1C82192C
	v_dot2_f32_bf16 v33, v47, v8, v34                          // 0000002FAB54: CC1A4021 1C8A112F
	v_dot2_f32_bf16 v34, v51, v8, v35                          // 0000002FAB5C: CC1A4022 1C8E1133
	v_dot2_f32_bf16 v7, v55, v8, v7                            // 0000002FAB64: CC1A4007 1C1E1137
	v_dot2_f32_bf16 v30, v37, v29, v30                         // 0000002FAB6C: CC1A401E 1C7A3B25
	v_dot2_f32_bf16 v31, v41, v29, v31                         // 0000002FAB74: CC1A401F 1C7E3B29
	v_dot2_f32_bf16 v32, v45, v29, v32                         // 0000002FAB7C: CC1A4020 1C823B2D
	v_dot2_f32_bf16 v33, v48, v12, v33                         // 0000002FAB84: CC1A4021 1C861930
	v_dot2_f32_bf16 v34, v52, v12, v34                         // 0000002FAB8C: CC1A4022 1C8A1934
	v_dot2_f32_bf16 v6, v59, v86, v6                           // 0000002FAB94: CC1A4006 1C1AAD3B
	v_dot2_f32_bf16 v7, v56, v12, v7                           // 0000002FAB9C: CC1A4007 1C1E1938
	s_waitcnt vmcnt(5)                                         // 0000002FABA4: BF8917F7
	v_dot2_f32_bf16 v8, v62, v87, v30                          // 0000002FABA8: CC1A4008 1C7AAF3E
	s_waitcnt vmcnt(4)                                         // 0000002FABB0: BF8913F7
	v_dot2_f32_bf16 v30, v66, v87, v31                         // 0000002FABB4: CC1A401E 1C7EAF42
	s_waitcnt vmcnt(3)                                         // 0000002FABBC: BF890FF7
	v_dot2_f32_bf16 v31, v70, v87, v32                         // 0000002FABC0: CC1A401F 1C82AF46
	v_dot2_f32_bf16 v32, v49, v29, v33                         // 0000002FABC8: CC1A4020 1C863B31
	v_dot2_f32_bf16 v33, v53, v29, v34                         // 0000002FABD0: CC1A4021 1C8A3B35
	v_dot2_f32_bf16 v6, v60, v5, v6                            // 0000002FABD8: CC1A4006 1C1A0B3C
	v_dot2_f32_bf16 v7, v57, v29, v7                           // 0000002FABE0: CC1A4007 1C1E3B39
	v_dot2_f32_bf16 v8, v63, v86, v8                           // 0000002FABE8: CC1A4008 1C22AD3F
	v_dot2_f32_bf16 v12, v67, v86, v30                         // 0000002FABF0: CC1A400C 1C7AAD43
	v_dot2_f32_bf16 v30, v71, v86, v31                         // 0000002FABF8: CC1A401E 1C7EAD47
	s_waitcnt vmcnt(2)                                         // 0000002FAC00: BF890BF7
	v_dot2_f32_bf16 v31, v74, v87, v32                         // 0000002FAC04: CC1A401F 1C82AF4A
	s_waitcnt vmcnt(1)                                         // 0000002FAC0C: BF8907F7
	v_dot2_f32_bf16 v29, v78, v87, v33                         // 0000002FAC10: CC1A401D 1C86AF4E
	v_dot2_f32_bf16 v6, v61, v27, v6                           // 0000002FAC18: CC1A4006 1C1A373D
	s_waitcnt vmcnt(0)                                         // 0000002FAC20: BF8903F7
	v_dot2_f32_bf16 v7, v82, v87, v7                           // 0000002FAC24: CC1A4007 1C1EAF52
	v_dot2_f32_bf16 v8, v64, v5, v8                            // 0000002FAC2C: CC1A4008 1C220B40
	v_dot2_f32_bf16 v12, v68, v5, v12                          // 0000002FAC34: CC1A400C 1C320B44
	v_dot2_f32_bf16 v31, v75, v86, v31                         // 0000002FAC3C: CC1A401F 1C7EAD4B
	v_dot2_f32_bf16 v29, v79, v86, v29                         // 0000002FAC44: CC1A401D 1C76AD4F
	v_add_f32_e32 v21, v21, v6                                 // 0000002FAC4C: 062A0D15
	v_dot2_f32_bf16 v6, v83, v86, v7                           // 0000002FAC50: CC1A4006 1C1EAD53
	v_dot2_f32_bf16 v30, v72, v5, v30                          // 0000002FAC58: CC1A401E 1C7A0B48
	v_dot2_f32_bf16 v7, v65, v27, v8                           // 0000002FAC60: CC1A4007 1C223741
	v_dot2_f32_bf16 v8, v69, v27, v12                          // 0000002FAC68: CC1A4008 1C323745
	v_dot2_f32_bf16 v12, v76, v5, v31                          // 0000002FAC70: CC1A400C 1C7E0B4C
	v_dot2_f32_bf16 v29, v80, v5, v29                          // 0000002FAC78: CC1A401D 1C760B50
	v_dot2_f32_bf16 v5, v84, v5, v6                            // 0000002FAC80: CC1A4005 1C1A0B54
	v_dot2_f32_bf16 v6, v73, v27, v30                          // 0000002FAC88: CC1A4006 1C7A3749
	v_add_f32_e32 v26, v26, v7                                 // 0000002FAC90: 06340F1A
	v_dot2_f32_bf16 v7, v77, v27, v12                          // 0000002FAC94: CC1A4007 1C32374D
	v_dot2_f32_bf16 v12, v81, v27, v29                         // 0000002FAC9C: CC1A400C 1C763751
	v_dot2_f32_bf16 v5, v85, v27, v5                           // 0000002FACA4: CC1A4005 1C163755
	v_dual_add_f32 v25, v25, v8 :: v_dual_add_f32 v24, v24, v6 // 0000002FACAC: C9081119 19180D18
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002FACB4: BF870193
	v_dual_add_f32 v23, v23, v7 :: v_dual_add_f32 v22, v22, v12// 0000002FACB8: C9080F17 17161916
	v_add_f32_e32 v16, v16, v5                                 // 0000002FACC0: 06200B10
	v_mov_b32_e32 v27, v28                                     // 0000002FACC4: 7E36031C
	s_and_not1_b32 exec_lo, exec_lo, s18                       // 0000002FACC8: 917E127E
	s_cbranch_execz 37                                         // 0000002FACCC: BFA50025 <_ZN7halogen12_GLOBAL__N_110k_lq8w_grpILi7ELi32ELi2EEEvNS0_5LqGrpEPKtl+0x964>
	v_add_nc_u32_e32 v17, 32, v17                              // 0000002FACD0: 4A2222A0
	v_add_nc_u32_e32 v29, 0x200, v11                           // 0000002FACD4: 4A3A16FF 00000200
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000002FACDC: BF8704A2
	v_cmp_ge_i32_e32 vcc_lo, v17, v18                          // 0000002FACE0: 7C8C2511
	s_and_saveexec_b32 s0, vcc_lo                              // 0000002FACE4: BE80206A
	s_xor_b32 s0, exec_lo, s0                                  // 0000002FACE8: 8D00007E
	v_add_nc_u32_e32 v29, 0x200, v11                           // 0000002FACEC: 4A3A16FF 00000200
	s_or_saveexec_b32 s20, s0                                  // 0000002FACF4: BE942200
	s_waitcnt vmcnt(0)                                         // 0000002FACF8: BF8903F7
	v_dual_mov_b32 v28, v27 :: v_dual_mov_b32 v5, v1           // 0000002FACFC: CA10011B 1C040101
	v_dual_mov_b32 v6, v2 :: v_dual_mov_b32 v7, v3             // 0000002FAD04: CA100102 06060103
	v_mov_b32_e32 v8, v4                                       // 0000002FAD0C: 7E100304
	s_xor_b32 exec_lo, exec_lo, s20                            // 0000002FAD10: 8D7E147E
	s_cbranch_execz 65137                                      // 0000002FAD14: BFA5FE71 <_ZN7halogen12_GLOBAL__N_110k_lq8w_grpILi7ELi32ELi2EEEvNS0_5LqGrpEPKtl+0x2dc>
	v_and_b32_e32 v7, -4, v17                                  // 0000002FAD18: 360E22C4
	v_ashrrev_i32_e32 v6, 31, v29                              // 0000002FAD1C: 340C3A9F
	.long 0xd7000005                                           // 0000002FAD20: D7000005
	v_cndmask_b32_e32 v1, v9, v29, vcc_lo                      // 0000002FAD24: 02023B09
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002FAD28: BF870193
	v_ashrrev_i32_e32 v8, 31, v7                               // 0000002FAD2C: 34100E9F
	v_add_co_ci_u32_e64 v6, null, v10, v6, s0                  // 0000002FAD30: D5207C06 00020D0A
	.long 0xd700001e                                           // 0000002FAD38: D700001E
	v_cndmask_b32_e32 v1, v19, v7, vcc_lo                      // 0000002FAD3C: 02020F13
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002FAD40: BF870001
	v_add_co_ci_u32_e64 v31, null, v20, v8, s0                 // 0000002FAD44: D5207C1F 00021114
	s_clause 0x1                                               // 0000002FAD4C: BF850001
	global_load_b128 v[5:8], v[5:6], off                       // 0000002FAD50: DC5E0000 057C0005
	global_load_b32 v28, v[30:31], off                         // 0000002FAD58: DC520000 1C7C001E
	s_branch 65118                                             // 0000002FAD60: BFA0FE5E <_ZN7halogen12_GLOBAL__N_110k_lq8w_grpILi7ELi32ELi2EEEvNS0_5LqGrpEPKtl+0x2dc>
	s_or_b32 exec_lo, exec_lo, s18                             // 0000002FAD64: 8C7E127E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000002FAD68: BF8700C9
	s_or_b32 exec_lo, exec_lo, s16                             // 0000002FAD6C: 8C7E107E
	s_waitcnt vmcnt(1)                                         // 0000002FAD70: BF8907F7
	.long 0xd71f0001                                           // 0000002FAD74: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000002FAD78: 020100C1
	s_mov_b32 s0, exec_lo                                      // 0000002FAD7C: BE80007E
	v_xor_b32_e32 v2, 16, v1                                   // 0000002FAD80: 3A040290
	v_xor_b32_e32 v9, 8, v1                                    // 0000002FAD84: 3A120288
	v_xor_b32_e32 v19, 4, v1                                   // 0000002FAD88: 3A260284
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000002FAD8C: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 0000002FAD90: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 0000002FAD94: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v9                            // 0000002FAD98: 7C9812A0
	v_cndmask_b32_e32 v9, v1, v9, vcc_lo                       // 0000002FAD9C: 02121301
	v_cmp_gt_u32_e32 vcc_lo, 32, v19                           // 0000002FADA0: 7C9826A0
	s_delay_alu instid0(VALU_DEP_2)                            // 0000002FADA4: BF870002
	v_lshlrev_b32_e32 v9, 2, v9                                // 0000002FADA8: 30121282
	v_dual_cndmask_b32 v19, v1, v19 :: v_dual_lshlrev_b32 v2, 2, v2// 0000002FADAC: CA622701 13020482
	ds_bpermute_b32 v3, v2, v21                                // 0000002FADB4: DACC0000 03001502
	s_waitcnt lgkmcnt(0)                                       // 0000002FADBC: BF89FC07
	v_add_f32_e32 v3, v21, v3                                  // 0000002FADC0: 06060715
	ds_bpermute_b32 v4, v2, v26                                // 0000002FADC4: DACC0000 04001A02
	ds_bpermute_b32 v5, v2, v25                                // 0000002FADCC: DACC0000 05001902
	ds_bpermute_b32 v6, v2, v24                                // 0000002FADD4: DACC0000 06001802
	ds_bpermute_b32 v7, v2, v23                                // 0000002FADDC: DACC0000 07001702
	ds_bpermute_b32 v8, v2, v22                                // 0000002FADE4: DACC0000 08001602
	ds_bpermute_b32 v2, v2, v16                                // 0000002FADEC: DACC0000 02001002
	ds_bpermute_b32 v10, v9, v3                                // 0000002FADF4: DACC0000 0A000309
	s_waitcnt lgkmcnt(5)                                       // 0000002FADFC: BF89FC57
	v_dual_add_f32 v4, v26, v4 :: v_dual_add_f32 v5, v25, v5   // 0000002FAE00: C908091A 04040B19
	s_waitcnt lgkmcnt(3)                                       // 0000002FAE08: BF89FC37
	v_dual_add_f32 v6, v24, v6 :: v_dual_add_f32 v7, v23, v7   // 0000002FAE0C: C9080D18 06060F17
	s_waitcnt lgkmcnt(2)                                       // 0000002FAE14: BF89FC27
	v_add_f32_e32 v8, v22, v8                                  // 0000002FAE18: 06101116
	ds_bpermute_b32 v11, v9, v4                                // 0000002FAE1C: DACC0000 0B000409
	s_waitcnt lgkmcnt(2)                                       // 0000002FAE24: BF89FC27
	v_add_f32_e32 v2, v16, v2                                  // 0000002FAE28: 06040510
	ds_bpermute_b32 v16, v9, v6                                // 0000002FAE2C: DACC0000 10000609
	ds_bpermute_b32 v12, v9, v5                                // 0000002FAE34: DACC0000 0C000509
	ds_bpermute_b32 v17, v9, v7                                // 0000002FAE3C: DACC0000 11000709
	ds_bpermute_b32 v18, v9, v8                                // 0000002FAE44: DACC0000 12000809
	ds_bpermute_b32 v9, v9, v2                                 // 0000002FAE4C: DACC0000 09000209
	v_lshlrev_b32_e32 v19, 2, v19                              // 0000002FAE54: 30262682
	s_waitcnt lgkmcnt(5)                                       // 0000002FAE58: BF89FC57
	v_dual_add_f32 v3, v3, v10 :: v_dual_add_f32 v4, v4, v11   // 0000002FAE5C: C9081503 03041704
	s_waitcnt lgkmcnt(4)                                       // 0000002FAE64: BF89FC47
	v_add_f32_e32 v6, v6, v16                                  // 0000002FAE68: 060C2106
	s_waitcnt lgkmcnt(1)                                       // 0000002FAE6C: BF89FC17
	v_dual_add_f32 v5, v5, v12 :: v_dual_add_f32 v8, v8, v18   // 0000002FAE70: C9081905 05082508
	ds_bpermute_b32 v10, v19, v4                               // 0000002FAE78: DACC0000 0A000413
	v_add_f32_e32 v7, v7, v17                                  // 0000002FAE80: 060E2307
	s_waitcnt lgkmcnt(1)                                       // 0000002FAE84: BF89FC17
	v_add_f32_e32 v2, v2, v9                                   // 0000002FAE88: 06041302
	ds_bpermute_b32 v9, v19, v3                                // 0000002FAE8C: DACC0000 09000313
	ds_bpermute_b32 v11, v19, v5                               // 0000002FAE94: DACC0000 0B000513
	ds_bpermute_b32 v12, v19, v6                               // 0000002FAE9C: DACC0000 0C000613
	ds_bpermute_b32 v17, v19, v8                               // 0000002FAEA4: DACC0000 11000813
	ds_bpermute_b32 v18, v19, v2                               // 0000002FAEAC: DACC0000 12000213
	s_waitcnt lgkmcnt(5)                                       // 0000002FAEB4: BF89FC57
	v_add_f32_e32 v4, v4, v10                                  // 0000002FAEB8: 06081504
	ds_bpermute_b32 v16, v19, v7                               // 0000002FAEBC: DACC0000 10000713
	v_xor_b32_e32 v19, 2, v1                                   // 0000002FAEC4: 3A260282
	s_waitcnt lgkmcnt(3)                                       // 0000002FAEC8: BF89FC37
	v_dual_add_f32 v5, v5, v11 :: v_dual_add_f32 v6, v6, v12   // 0000002FAECC: C9081705 05061906
	s_waitcnt lgkmcnt(2)                                       // 0000002FAED4: BF89FC27
	v_add_f32_e32 v8, v8, v17                                  // 0000002FAED8: 06102308
	v_cmp_gt_u32_e32 vcc_lo, 32, v19                           // 0000002FAEDC: 7C9826A0
	v_cndmask_b32_e32 v19, v1, v19, vcc_lo                     // 0000002FAEE0: 02262701
	s_waitcnt lgkmcnt(1)                                       // 0000002FAEE4: BF89FC17
	v_dual_add_f32 v3, v3, v9 :: v_dual_add_f32 v10, v2, v18   // 0000002FAEE8: C9081303 030A2502
	s_delay_alu instid0(VALU_DEP_2)                            // 0000002FAEF0: BF870002
	v_lshlrev_b32_e32 v19, 2, v19                              // 0000002FAEF4: 30262682
	ds_bpermute_b32 v9, v19, v4                                // 0000002FAEF8: DACC0000 09000413
	s_waitcnt lgkmcnt(1)                                       // 0000002FAF00: BF89FC17
	v_add_f32_e32 v7, v7, v16                                  // 0000002FAF04: 060E2107
	ds_bpermute_b32 v2, v19, v3                                // 0000002FAF08: DACC0000 02000313
	ds_bpermute_b32 v11, v19, v5                               // 0000002FAF10: DACC0000 0B000513
	ds_bpermute_b32 v12, v19, v6                               // 0000002FAF18: DACC0000 0C000613
	ds_bpermute_b32 v17, v19, v8                               // 0000002FAF20: DACC0000 11000813
	ds_bpermute_b32 v18, v19, v10                              // 0000002FAF28: DACC0000 12000A13
	s_waitcnt lgkmcnt(5)                                       // 0000002FAF30: BF89FC57
	v_add_f32_e32 v4, v4, v9                                   // 0000002FAF34: 06081304
	ds_bpermute_b32 v16, v19, v7                               // 0000002FAF38: DACC0000 10000713
	v_xor_b32_e32 v19, 1, v1                                   // 0000002FAF40: 3A260281
	s_waitcnt lgkmcnt(2)                                       // 0000002FAF44: BF89FC27
	v_dual_add_f32 v6, v6, v12 :: v_dual_add_f32 v9, v8, v17   // 0000002FAF48: C9081906 06082308
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002FAF50: BF8700A2
	v_cmp_gt_u32_e32 vcc_lo, 32, v19                           // 0000002FAF54: 7C9826A0
	v_cndmask_b32_e32 v1, v1, v19, vcc_lo                      // 0000002FAF58: 02022701
	v_lshlrev_b32_e32 v19, 2, v1                               // 0000002FAF5C: 30260282
	v_dual_add_f32 v1, v3, v2 :: v_dual_add_f32 v2, v5, v11    // 0000002FAF60: C9080503 01021705
	s_waitcnt lgkmcnt(1)                                       // 0000002FAF68: BF89FC17
	v_add_f32_e32 v5, v10, v18                                 // 0000002FAF6C: 060A250A
	s_waitcnt lgkmcnt(0)                                       // 0000002FAF70: BF89FC07
	v_add_f32_e32 v3, v7, v16                                  // 0000002FAF74: 06062107
	ds_bpermute_b32 v11, v19, v4                               // 0000002FAF78: DACC0000 0B000413
	ds_bpermute_b32 v7, v19, v1                                // 0000002FAF80: DACC0000 07000113
	ds_bpermute_b32 v8, v19, v2                                // 0000002FAF88: DACC0000 08000213
	ds_bpermute_b32 v16, v19, v6                               // 0000002FAF90: DACC0000 10000613
	ds_bpermute_b32 v10, v19, v3                               // 0000002FAF98: DACC0000 0A000313
	ds_bpermute_b32 v17, v19, v9                               // 0000002FAFA0: DACC0000 11000913
	ds_bpermute_b32 v12, v19, v5                               // 0000002FAFA8: DACC0000 0C000513
	v_cmpx_eq_u32_e32 0, v15                                   // 0000002FAFB0: 7D941E80
	s_cbranch_execz 22                                         // 0000002FAFB4: BFA50016 <_ZN7halogen12_GLOBAL__N_110k_lq8w_grpILi7ELi32ELi2EEEvNS0_5LqGrpEPKtl+0xc10>
	v_lshl_add_u32 v13, v13, s3, v14                           // 0000002FAFB8: D646000D 0438070D
	s_waitcnt lgkmcnt(2)                                       // 0000002FAFC0: BF89FC27
	v_dual_add_f32 v4, v4, v11 :: v_dual_add_f32 v3, v3, v10   // 0000002FAFC4: C9081704 04021503
	v_dual_add_f32 v1, v1, v7 :: v_dual_add_f32 v2, v2, v8     // 0000002FAFCC: C9080F01 01021102
	s_delay_alu instid0(VALU_DEP_3)                            // 0000002FAFD4: BF870003
	v_mul_u32_u24_e32 v7, 28, v13                              // 0000002FAFD8: 160E1A9C
	s_waitcnt lgkmcnt(1)                                       // 0000002FAFDC: BF89FC17
	v_dual_add_f32 v9, v9, v17 :: v_dual_add_f32 v6, v6, v16   // 0000002FAFE0: C9082309 09062106
	s_waitcnt lgkmcnt(0)                                       // 0000002FAFE8: BF89FC07
	v_add_f32_e32 v5, v5, v12                                  // 0000002FAFEC: 060A1905
	ds_store_2addr_b32 v7, v1, v4 offset1:1                    // 0000002FAFF0: D8380100 00040107
	ds_store_2addr_b32 v7, v2, v6 offset0:2 offset1:3          // 0000002FAFF8: D8380302 00060207
	ds_store_2addr_b32 v7, v3, v9 offset0:4 offset1:5          // 0000002FB000: D8380504 00090307
	ds_store_b32 v7, v5 offset:24                              // 0000002FB008: D8340018 00000507
	s_or_b32 exec_lo, exec_lo, s0                              // 0000002FB010: 8C7E007E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002FB014: BF870009
	s_and_b32 s0, s14, exec_lo                                 // 0000002FB018: 8B007E0E
	s_cselect_b32 s0, 7, 28                                    // 0000002FB01C: 98009C87
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000002FB020: BF890007
	v_cmp_gt_u32_e32 vcc_lo, s0, v0                            // 0000002FB024: 7C980000
	s_barrier                                                  // 0000002FB028: BFBD0000
	buffer_gl0_inv                                             // 0000002FB02C: E0AC0000 00000000
	s_and_saveexec_b32 s0, vcc_lo                              // 0000002FB034: BE80206A
	s_cbranch_execz 425                                        // 0000002FB038: BFA501A9 <_ZN7halogen12_GLOBAL__N_110k_lq8w_grpILi7ELi32ELi2EEEvNS0_5LqGrpEPKtl+0x12e0>
	.long 0xd7054000                                           // 0000002FB03C: D7054000
	v_cndmask_b32_e32 v0, v0, v165, vcc_lo                     // 0000002FB040: 02014B00
	s_load_b32 s0, s[10:11], 0x40                              // 0000002FB044: F4000005 F8000040
	.long 0x7f063880                                           // 0000002FB04C: 7F063880
	v_mov_b32_e32 v4, 0                                        // 0000002FB050: 7E080280
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002FB054: BF870093
	.long 0xd7395000                                           // 0000002FB058: D7395000
	v_cndmask_b32_e32 v1, 8, v0, vcc_lo                        // 0000002FB05C: 02020088
	.long 0xd7041001                                           // 0000002FB060: D7041001
	v_cndmask_b32_e32 v1, v0, v0, vcc_lo                       // 0000002FB064: 02020100
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002FB068: BF870091
	.long 0xd7390001                                           // 0000002FB06C: D7390001
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 0000002FB070: 02020281
	.long 0xd7620001                                           // 0000002FB074: D7620001
	v_cndmask_b32_e32 v1, 0x7f, v1, vcc_lo                     // 0000002FB078: 020202FF 0000007F
	s_waitcnt lgkmcnt(0)                                       // 0000002FB080: BF89FC07
	s_sub_i32 s4, s2, s0                                       // 0000002FB084: 81840002
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000002FB088: BF870499
	s_ashr_i32 s5, s4, 31                                      // 0000002FB08C: 86059F04
	s_lshl_b64 s[4:5], s[4:5], s15                             // 0000002FB090: 84840F04
	.long 0xd7035000                                           // 0000002FB094: D7035000
	v_cndmask_b32_e32 v1, v1, v0, vcc_lo                       // 0000002FB098: 02020101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002FB09C: BF870091
	.long 0xd7391003                                           // 0000002FB0A0: D7391003
	v_cndmask_b32_e32 v1, 2, v0, vcc_lo                        // 0000002FB0A4: 02020082
	.long 0xd7000001                                           // 0000002FB0A8: D7000001
	v_cndmask_b32_e32 v1, s4, v3, vcc_lo                       // 0000002FB0AC: 02020604
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002FB0B0: BF870091
	v_add_co_ci_u32_e64 v2, null, s5, 0, s0                    // 0000002FB0B4: D5207C02 00010005
	v_cmp_gt_i64_e32 vcc_lo, s[8:9], v[1:2]                    // 0000002FB0BC: 7CA80208
	s_and_b32 exec_lo, exec_lo, vcc_lo                         // 0000002FB0C0: 8B7E6A7E
	s_cbranch_execz 390                                        // 0000002FB0C4: BFA50186 <_ZN7halogen12_GLOBAL__N_110k_lq8w_grpILi7ELi32ELi2EEEvNS0_5LqGrpEPKtl+0x12e0>
	.long 0xd7054000                                           // 0000002FB0C8: D7054000
	v_cndmask_b32_e32 v0, v3, v135, vcc_lo                     // 0000002FB0CC: 02010F03
	v_lshlrev_b32_e32 v3, s3, v3                               // 0000002FB0D0: 30060603
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002FB0D4: BF870112
	.long 0xd7041000                                           // 0000002FB0D8: D7041000
	v_cndmask_b32_e32 v1, v0, v0, vcc_lo                       // 0000002FB0DC: 02020100
	v_mul_u32_u24_e32 v3, 28, v3                               // 0000002FB0E0: 1606069C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002FB0E4: BF870092
	v_and_b32_e32 v5, 0xff, v0                                 // 0000002FB0E8: 360A00FF 000000FF
	v_lshl_add_u32 v3, v5, 2, v3                               // 0000002FB0F0: D6460003 040D0505
	ds_load_b32 v5, v3                                         // 0000002FB0F8: D8D80000 05000003
	v_add_nc_u32_e32 v3, 28, v3                                // 0000002FB100: 4A06069C
	s_add_i32 s1, s1, -1                                       // 0000002FB104: 8101C101
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002FB108: BF870009
	s_cmp_eq_u32 s1, 0                                         // 0000002FB10C: BF068001
	s_waitcnt lgkmcnt(0)                                       // 0000002FB110: BF89FC07
	v_add_f32_e32 v4, v4, v5                                   // 0000002FB114: 06080B04
	s_cbranch_scc0 65527                                       // 0000002FB118: BFA1FFF7 <_ZN7halogen12_GLOBAL__N_110k_lq8w_grpILi7ELi32ELi2EEEvNS0_5LqGrpEPKtl+0xcf8>
	s_clause 0x1                                               // 0000002FB11C: BF850001
	s_load_b64 s[4:5], s[10:11], 0x38                          // 0000002FB120: F4040105 F8000038
	s_load_b64 s[2:3], s[10:11], 0x8                           // 0000002FB128: F4040085 F8000008
	v_and_b32_e32 v3, 0xff, v0                                 // 0000002FB130: 360600FF 000000FF
	s_mov_b32 s6, -1                                           // 0000002FB138: BE8600C1
	s_mov_b32 s1, 0                                            // 0000002FB13C: BE810080
	s_mov_b32 s0, 0                                            // 0000002FB140: BE800080
	s_waitcnt lgkmcnt(0)                                       // 0000002FB144: BF89FC07
	s_cmp_lt_i32 s5, 3                                         // 0000002FB148: BF048305
	s_cbranch_scc1 191                                         // 0000002FB14C: BFA200BF <_ZN7halogen12_GLOBAL__N_110k_lq8w_grpILi7ELi32ELi2EEEvNS0_5LqGrpEPKtl+0x104c>
	s_cmp_gt_i32 s5, 3                                         // 0000002FB150: BF028305
	s_cbranch_scc0 125                                         // 0000002FB154: BFA1007D <_ZN7halogen12_GLOBAL__N_110k_lq8w_grpILi7ELi32ELi2EEEvNS0_5LqGrpEPKtl+0xf4c>
	s_cmp_gt_i32 s5, 4                                         // 0000002FB158: BF028405
	s_cbranch_scc0 70                                          // 0000002FB15C: BFA10046 <_ZN7halogen12_GLOBAL__N_110k_lq8w_grpILi7ELi32ELi2EEEvNS0_5LqGrpEPKtl+0xe78>
	s_cmp_eq_u32 s5, 5                                         // 0000002FB160: BF068505
	s_mov_b32 s0, -1                                           // 0000002FB164: BE8000C1
	s_cbranch_scc0 66                                          // 0000002FB168: BFA10042 <_ZN7halogen12_GLOBAL__N_110k_lq8w_grpILi7ELi32ELi2EEEvNS0_5LqGrpEPKtl+0xe74>
	v_lshrrev_b32_e32 v0, 23, v2                               // 0000002FB16C: 32000497
	s_lshr_b32 s0, s9, 31                                      // 0000002FB170: 85009F09
	s_load_b64 s[10:11], s[10:11], 0x10                        // 0000002FB174: F4040285 F8000010
	s_add_u32 s6, s8, s0                                       // 0000002FB17C: 80060008
	s_addc_u32 s7, s9, 0                                       // 0000002FB180: 82078009
	.long 0xd7006a00                                           // 0000002FB184: D7006A00
	v_cndmask_b32_e32 v1, v1, v0, vcc_lo                       // 0000002FB188: 02020101
	s_ashr_i64 s[6:7], s[6:7], 1                               // 0000002FB18C: 86868106
	v_add_co_ci_u32_e64 v10, null, 0, v2, vcc_lo               // 0000002FB190: D5207C0A 01AA0480
	v_dual_mov_b32 v11, s3 :: v_dual_and_b32 v0, 0xfffffe00, v0// 0000002FB198: CA240003 0B0000FF FFFFFE00
	v_mad_u64_u32 v[5:6], null, s6, v3, 0                      // 0000002FB1A4: D6FE7C05 02020606
	v_bfe_u32 v14, v4, 16, 1                                   // 0000002FB1AC: D610000E 02052104
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002FB1B4: BF870093
	.long 0xd7016a08                                           // 0000002FB1B8: D7016A08
	v_cndmask_b32_e32 v1, v1, v0, vcc_lo                       // 0000002FB1BC: 02020101
	v_sub_co_ci_u32_e64 v9, null, v2, v10, vcc_lo              // 0000002FB1C0: D5217C09 01AA1502
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002FB1C8: BF870194
	v_mad_u64_u32 v[6:7], null, s7, v3, v[6:7]                 // 0000002FB1CC: D6FE7C06 041A0607
	.long 0xd700000c                                           // 0000002FB1D4: D700000C
	v_cndmask_b32_e32 v1, 0xffffff00, v8, vcc_lo               // 0000002FB1D8: 020210FF FFFFFF00
	s_delay_alu instid0(VALU_DEP_3)                            // 0000002FB1E0: BF870003
	v_cmp_gt_i64_e32 vcc_lo, 0x100, v[8:9]                     // 0000002FB1E4: 7CA810FF 00000100
	v_mov_b32_e32 v7, s2                                       // 0000002FB1EC: 7E0E0202
	v_add_co_ci_u32_e64 v13, null, -1, v9, s0                  // 0000002FB1F0: D5207C0D 000212C1
	s_mov_b32 s0, 0                                            // 0000002FB1F8: BE800080
	.long 0xd73c0005                                           // 0000002FB1FC: D73C0005
	v_cndmask_b32_e32 v1, 1, v5, vcc_lo                        // 0000002FB200: 02020A81
	s_waitcnt lgkmcnt(0)                                       // 0000002FB204: BF89FC07
	v_dual_cndmask_b32 v8, v12, v8 :: v_dual_cndmask_b32 v7, s10, v7// 0000002FB208: CA52110C 08060E0A
	v_cndmask_b32_e32 v11, s11, v11, vcc_lo                    // 0000002FB210: 0216160B
	v_cndmask_b32_e32 v9, v13, v9, vcc_lo                      // 0000002FB214: 0212130D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002FB218: BF870093
	.long 0xd7006a07                                           // 0000002FB21C: D7006A07
	v_cndmask_b32_e32 v1, v7, v5, vcc_lo                       // 0000002FB220: 02020B07
	v_add_co_ci_u32_e64 v11, null, v11, v6, vcc_lo             // 0000002FB224: D5207C0B 01AA0D0B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002FB22C: BF870193
	.long 0xd73c0005                                           // 0000002FB230: D73C0005
	v_cndmask_b32_e32 v1, 1, v8, vcc_lo                        // 0000002FB234: 02021081
	.long 0xd7006a00                                           // 0000002FB238: D7006A00
	v_cndmask_b32_e32 v1, v7, v0, vcc_lo                       // 0000002FB23C: 02020107
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000002FB240: BF8701A1
	v_add_co_ci_u32_e64 v7, null, v11, v10, vcc_lo             // 0000002FB244: D5207C07 01AA150B
	v_add3_u32 v8, v4, v14, 0x7fff                             // 0000002FB24C: D6550008 03FE1D04 00007FFF
	.long 0xd7006a05                                           // 0000002FB258: D7006A05
	v_cndmask_b32_e32 v1, v0, v5, vcc_lo                       // 0000002FB25C: 02020B00
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002FB260: BF870001
	v_add_co_ci_u32_e64 v6, null, v7, v6, vcc_lo               // 0000002FB264: D5207C06 01AA0D07
	global_store_d16_hi_b16 v[5:6], v8, off                    // 0000002FB26C: DC960000 007C0805
	s_mov_b32 s6, 0                                            // 0000002FB274: BE860080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002FB278: BF870009
	s_and_b32 vcc_lo, exec_lo, s6                              // 0000002FB27C: 8B6A067E
	s_cbranch_vccz 49                                          // 0000002FB280: BFA30031 <_ZN7halogen12_GLOBAL__N_110k_lq8w_grpILi7ELi32ELi2EEEvNS0_5LqGrpEPKtl+0xf48>
	v_mul_f32_e32 v0, 0xbfb8aa3b, v4                           // 0000002FB284: 100008FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002FB28C: BF870291
	v_exp_f32_e32 v0, v0                                       // 0000002FB290: 7E004B00
	v_add_f32_e32 v0, 1.0, v0                                  // 0000002FB294: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002FB298: BF870121
	v_div_scale_f32 v8, null, v0, v0, 1.0                      // 0000002FB29C: D6FC7C08 03CA0100
	v_div_scale_f32 v10, vcc_lo, 1.0, v0, 1.0                  // 0000002FB2A4: D6FC6A0A 03CA00F2
	v_rcp_f32_e32 v9, v8                                       // 0000002FB2AC: 7E125508
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002FB2B0: BF870095
	v_fma_f32 v5, -v8, v9, 1.0                                 // 0000002FB2B4: D6130005 23CA1308
	v_fmac_f32_e32 v9, v5, v9                                  // 0000002FB2BC: 56121305
	v_mad_u64_u32 v[5:6], null, s8, v3, 0                      // 0000002FB2C0: D6FE7C05 02020608
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002FB2C8: BF870112
	v_mul_f32_e32 v11, v10, v9                                 // 0000002FB2CC: 1016130A
	v_mad_u64_u32 v[6:7], null, s9, v3, v[6:7]                 // 0000002FB2D0: D6FE7C06 041A0609
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002FB2D8: BF870092
	v_fma_f32 v12, -v8, v11, v10                               // 0000002FB2DC: D613000C 242A1708
	v_fmac_f32_e32 v11, v12, v9                                // 0000002FB2E4: 5616130C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002FB2E8: BF870113
	.long 0xd73c0005                                           // 0000002FB2EC: D73C0005
	v_cndmask_b32_e32 v1, 2, v5, vcc_lo                        // 0000002FB2F0: 02020A82
	v_fma_f32 v10, -v8, v11, v10                               // 0000002FB2F4: D613000A 242A1708
	.long 0xd73c0007                                           // 0000002FB2FC: D73C0007
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 0000002FB300: 02020282
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002FB304: BF870212
	v_div_fmas_f32 v9, v10, v9, v11                            // 0000002FB308: D6370009 042E130A
	.long 0xd7006a05                                           // 0000002FB310: D7006A05
	v_cndmask_b32_e32 v1, s2, v5, vcc_lo                       // 0000002FB314: 02020A02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002FB318: BF870191
	v_add_co_ci_u32_e64 v6, null, s3, v6, vcc_lo               // 0000002FB31C: D5207C06 01AA0C03
	v_div_fixup_f32 v0, v9, v0, 1.0                            // 0000002FB324: D6270000 03CA0109
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002FB32C: BF870093
	.long 0xd7006a05                                           // 0000002FB330: D7006A05
	v_cndmask_b32_e32 v1, v5, v7, vcc_lo                       // 0000002FB334: 02020F05
	v_add_co_ci_u32_e64 v6, null, v6, v8, vcc_lo               // 0000002FB338: D5207C06 01AA1106
	global_store_b32 v[5:6], v0, off                           // 0000002FB340: DC6A0000 007C0005
	s_mov_b32 s6, 0                                            // 0000002FB348: BE860080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002FB34C: BF870009
	s_and_b32 vcc_lo, exec_lo, s6                              // 0000002FB350: 8B6A067E
	s_cbranch_vccz 60                                          // 0000002FB354: BFA3003C <_ZN7halogen12_GLOBAL__N_110k_lq8w_grpILi7ELi32ELi2EEEvNS0_5LqGrpEPKtl+0x1048>
	v_bfe_u32 v0, v4, 16, 1                                    // 0000002FB358: D6100000 02052104
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002FB360: BF870091
	v_add3_u32 v0, v4, v0, 0x7fff                              // 0000002FB364: D6550000 03FE0104 00007FFF
	v_and_b32_e32 v0, 0xffff0000, v0                           // 0000002FB370: 360000FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002FB378: BF870091
	v_mul_f32_e32 v0, s4, v0                                   // 0000002FB37C: 10000004
	v_mul_f32_e32 v0, 0xbfb8aa3b, v0                           // 0000002FB380: 100000FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002FB388: BF870291
	v_exp_f32_e32 v0, v0                                       // 0000002FB38C: 7E004B00
	v_add_f32_e32 v0, 1.0, v0                                  // 0000002FB390: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002FB394: BF870121
	v_div_scale_f32 v8, null, v0, v0, 1.0                      // 0000002FB398: D6FC7C08 03CA0100
	v_div_scale_f32 v10, vcc_lo, 1.0, v0, 1.0                  // 0000002FB3A0: D6FC6A0A 03CA00F2
	v_rcp_f32_e32 v9, v8                                       // 0000002FB3A8: 7E125508
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002FB3AC: BF870095
	v_fma_f32 v5, -v8, v9, 1.0                                 // 0000002FB3B0: D6130005 23CA1308
	v_fmac_f32_e32 v9, v5, v9                                  // 0000002FB3B8: 56121305
	v_mad_u64_u32 v[5:6], null, s8, v3, 0                      // 0000002FB3BC: D6FE7C05 02020608
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002FB3C4: BF870092
	v_mul_f32_e32 v11, v10, v9                                 // 0000002FB3C8: 1016130A
	v_fma_f32 v7, -v8, v11, v10                                // 0000002FB3CC: D6130007 242A1708
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002FB3D4: BF870211
	v_fmac_f32_e32 v11, v7, v9                                 // 0000002FB3D8: 56161307
	v_mad_u64_u32 v[6:7], null, s9, v3, v[6:7]                 // 0000002FB3DC: D6FE7C06 041A0609
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002FB3E4: BF870112
	v_fma_f32 v7, -v8, v11, v10                                // 0000002FB3E8: D6130007 242A1708
	.long 0xd73c0005                                           // 0000002FB3F0: D73C0005
	v_cndmask_b32_e32 v1, 2, v5, vcc_lo                        // 0000002FB3F4: 02020A82
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000002FB3F8: BF8701A2
	v_div_fmas_f32 v9, v7, v9, v11                             // 0000002FB3FC: D6370009 042E1307
	.long 0xd73c0007                                           // 0000002FB404: D73C0007
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 0000002FB408: 02020282
	.long 0xd7006a05                                           // 0000002FB40C: D7006A05
	v_cndmask_b32_e32 v1, s2, v5, vcc_lo                       // 0000002FB410: 02020A02
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000002FB414: BF8701A3
	v_div_fixup_f32 v0, v9, v0, 1.0                            // 0000002FB418: D6270000 03CA0109
	v_add_co_ci_u32_e64 v6, null, s3, v6, vcc_lo               // 0000002FB420: D5207C06 01AA0C03
	.long 0xd7006a05                                           // 0000002FB428: D7006A05
	v_cndmask_b32_e32 v1, v5, v7, vcc_lo                       // 0000002FB42C: 02020F05
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002FB430: BF870193
	v_add_f32_e32 v0, v0, v0                                   // 0000002FB434: 06000100
	v_add_co_ci_u32_e64 v6, null, v6, v8, vcc_lo               // 0000002FB438: D5207C06 01AA1106
	global_store_b32 v[5:6], v0, off                           // 0000002FB440: DC6A0000 007C0005
	s_mov_b32 s6, 0                                            // 0000002FB448: BE860080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002FB44C: BF870009
	s_and_b32 vcc_lo, exec_lo, s6                              // 0000002FB450: 8B6A067E
	s_cbranch_vccz 73                                          // 0000002FB454: BFA30049 <_ZN7halogen12_GLOBAL__N_110k_lq8w_grpILi7ELi32ELi2EEEvNS0_5LqGrpEPKtl+0x117c>
	s_cmp_gt_i32 s5, 1                                         // 0000002FB458: BF028105
	s_mov_b32 s1, -1                                           // 0000002FB45C: BE8100C1
	s_cbranch_scc0 64                                          // 0000002FB460: BFA10040 <_ZN7halogen12_GLOBAL__N_110k_lq8w_grpILi7ELi32ELi2EEEvNS0_5LqGrpEPKtl+0x1164>
	v_bfe_u32 v0, v4, 16, 1                                    // 0000002FB464: D6100000 02052104
	s_mov_b32 s1, 0                                            // 0000002FB46C: BE810080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002FB470: BF870091
	v_add3_u32 v0, v4, v0, 0x7fff                              // 0000002FB474: D6550000 03FE0104 00007FFF
	v_and_b32_e32 v0, 0xffff0000, v0                           // 0000002FB480: 360000FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002FB488: BF870091
	v_mul_f32_e32 v0, 0xbfb8aa3b, v0                           // 0000002FB48C: 100000FF BFB8AA3B
	v_exp_f32_e32 v0, v0                                       // 0000002FB494: 7E004B00
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002FB498: BF870095
	v_add_f32_e32 v0, 1.0, v0                                  // 0000002FB49C: 060000F2
	v_div_scale_f32 v7, null, v0, v0, 1.0                      // 0000002FB4A0: D6FC7C07 03CA0100
	v_div_scale_f32 v9, vcc_lo, 1.0, v0, 1.0                   // 0000002FB4A8: D6FC6A09 03CA00F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002FB4B0: BF870292
	v_rcp_f32_e32 v8, v7                                       // 0000002FB4B4: 7E105507
	v_fma_f32 v5, -v7, v8, 1.0                                 // 0000002FB4B8: D6130005 23CA1107
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002FB4C0: BF870121
	v_fmac_f32_e32 v8, v5, v8                                  // 0000002FB4C4: 56101105
	v_mad_u64_u32 v[5:6], null, s8, v3, 0                      // 0000002FB4C8: D6FE7C05 02020608
	v_mul_f32_e32 v10, v9, v8                                  // 0000002FB4D0: 10141109
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002FB4D4: BF870091
	v_fma_f32 v11, -v7, v10, v9                                // 0000002FB4D8: D613000B 24261507
	v_fmac_f32_e32 v10, v11, v8                                // 0000002FB4E0: 5614110B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002FB4E4: BF870121
	v_fma_f32 v9, -v7, v10, v9                                 // 0000002FB4E8: D6130009 24261507
	v_mad_u64_u32 v[6:7], null, s9, v3, v[6:7]                 // 0000002FB4F0: D6FE7C06 041A0609
	v_div_fmas_f32 v7, v9, v8, v10                             // 0000002FB4F8: D6370007 042A1109
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002FB500: BF870112
	.long 0xd73c0005                                           // 0000002FB504: D73C0005
	v_cndmask_b32_e32 v1, 1, v5, vcc_lo                        // 0000002FB508: 02020A81
	v_div_fixup_f32 v0, v7, v0, 1.0                            // 0000002FB50C: D6270000 03CA0107
	.long 0xd73c0007                                           // 0000002FB514: D73C0007
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 0000002FB518: 02020281
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002FB51C: BF870193
	.long 0xd7006a05                                           // 0000002FB520: D7006A05
	v_cndmask_b32_e32 v1, s2, v5, vcc_lo                       // 0000002FB524: 02020A02
	v_bfe_u32 v9, v0, 16, 1                                    // 0000002FB528: D6100009 02052100
	v_add_co_ci_u32_e64 v6, null, s3, v6, vcc_lo               // 0000002FB530: D5207C06 01AA0C03
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002FB538: BF870193
	.long 0xd7006a05                                           // 0000002FB53C: D7006A05
	v_cndmask_b32_e32 v1, v5, v7, vcc_lo                       // 0000002FB540: 02020F05
	v_add3_u32 v0, v0, v9, 0x7fff                              // 0000002FB544: D6550000 03FE1300 00007FFF
	s_delay_alu instid0(VALU_DEP_3)                            // 0000002FB550: BF870003
	v_add_co_ci_u32_e64 v6, null, v6, v8, vcc_lo               // 0000002FB554: D5207C06 01AA1106
	global_store_d16_hi_b16 v[5:6], v0, off                    // 0000002FB55C: DC960000 007C0005
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 0000002FB564: 916A017E
	s_mov_b32 s1, 0                                            // 0000002FB568: BE810080
	s_cbranch_vccnz 3                                          // 0000002FB56C: BFA40003 <_ZN7halogen12_GLOBAL__N_110k_lq8w_grpILi7ELi32ELi2EEEvNS0_5LqGrpEPKtl+0x117c>
	s_cmp_lg_u32 s5, 1                                         // 0000002FB570: BF078105
	s_mov_b32 s1, -1                                           // 0000002FB574: BE8100C1
	s_cselect_b32 s0, -1, 0                                    // 0000002FB578: 980080C1
	v_bfe_u32 v5, v4, 16, 1                                    // 0000002FB57C: D6100005 02052104
	.long 0xd73c0000                                           // 0000002FB584: D73C0000
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 0000002FB588: 02020281
	s_and_b32 vcc_lo, exec_lo, s0                              // 0000002FB58C: 8B6A007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000002FB590: BF870002
	v_add3_u32 v2, v4, v5, 0x7fff                              // 0000002FB594: D6550002 03FE0B04 00007FFF
	s_cbranch_vccz 20                                          // 0000002FB5A0: BFA30014 <_ZN7halogen12_GLOBAL__N_110k_lq8w_grpILi7ELi32ELi2EEEvNS0_5LqGrpEPKtl+0x11f4>
	v_mad_u64_u32 v[4:5], null, s8, v3, 0                      // 0000002FB5A4: D6FE7C04 02020608
	s_mov_b32 s1, 0                                            // 0000002FB5AC: BE810080
	v_mad_u64_u32 v[5:6], null, s9, v3, v[5:6]                 // 0000002FB5B0: D6FE7C05 04160609
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002FB5B8: BF870091
	.long 0xd73c0004                                           // 0000002FB5BC: D73C0004
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 0000002FB5C0: 02020881
	.long 0xd7006a04                                           // 0000002FB5C4: D7006A04
	v_cndmask_b32_e32 v1, s2, v4, vcc_lo                       // 0000002FB5C8: 02020802
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002FB5CC: BF870111
	v_add_co_ci_u32_e64 v5, null, s3, v5, vcc_lo               // 0000002FB5D0: D5207C05 01AA0A03
	.long 0xd7006a04                                           // 0000002FB5D8: D7006A04
	v_cndmask_b32_e32 v1, v4, v0, vcc_lo                       // 0000002FB5DC: 02020104
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002FB5E0: BF870001
	v_add_co_ci_u32_e64 v5, null, v5, v1, vcc_lo               // 0000002FB5E4: D5207C05 01AA0305
	global_store_d16_hi_b16 v[4:5], v2, off                    // 0000002FB5EC: DC960000 007C0204
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 0000002FB5F4: 916A017E
	s_cbranch_vccnz 57                                         // 0000002FB5F8: BFA40039 <_ZN7halogen12_GLOBAL__N_110k_lq8w_grpILi7ELi32ELi2EEEvNS0_5LqGrpEPKtl+0x12e0>
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002FB5FC: BF870091
	v_and_b32_e32 v2, 0xffff0000, v2                           // 0000002FB600: 360404FF FFFF0000
	v_mul_f32_e32 v2, s4, v2                                   // 0000002FB608: 10040404
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002FB60C: BF870091
	v_mul_f32_e32 v4, 0xbfb8aa3b, v2                           // 0000002FB610: 100804FF BFB8AA3B
	v_exp_f32_e32 v4, v4                                       // 0000002FB618: 7E084B04
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002FB61C: BF870095
	v_add_f32_e32 v7, 1.0, v4                                  // 0000002FB620: 060E08F2
	v_div_scale_f32 v6, null, v7, v7, v2                       // 0000002FB624: D6FC7C06 040A0F07
	v_div_scale_f32 v9, vcc_lo, v2, v7, v2                     // 0000002FB62C: D6FC6A09 040A0F02
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002FB634: BF870292
	v_rcp_f32_e32 v8, v6                                       // 0000002FB638: 7E105506
	v_fma_f32 v4, -v6, v8, 1.0                                 // 0000002FB63C: D6130004 23CA1106
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002FB644: BF870121
	v_fmac_f32_e32 v8, v4, v8                                  // 0000002FB648: 56101104
	v_mad_u64_u32 v[4:5], null, s8, v3, 0                      // 0000002FB64C: D6FE7C04 02020608
	v_mul_f32_e32 v10, v9, v8                                  // 0000002FB654: 10141109
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002FB658: BF870091
	v_fma_f32 v11, -v6, v10, v9                                // 0000002FB65C: D613000B 24261506
	v_fmac_f32_e32 v10, v11, v8                                // 0000002FB664: 5614110B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002FB668: BF870121
	v_fma_f32 v9, -v6, v10, v9                                 // 0000002FB66C: D6130009 24261506
	v_mad_u64_u32 v[5:6], null, s9, v3, v[5:6]                 // 0000002FB674: D6FE7C05 04160609
	v_div_fmas_f32 v3, v9, v8, v10                             // 0000002FB67C: D6370003 042A1109
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002FB684: BF870191
	v_div_fixup_f32 v6, v3, v7, v2                             // 0000002FB688: D6270006 040A0F03
	.long 0xd73c0002                                           // 0000002FB690: D73C0002
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 0000002FB694: 02020881
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002FB698: BF870112
	v_bfe_u32 v4, v6, 16, 1                                    // 0000002FB69C: D6100004 02052106
	.long 0xd7006a02                                           // 0000002FB6A4: D7006A02
	v_cndmask_b32_e32 v1, s2, v2, vcc_lo                       // 0000002FB6A8: 02020402
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002FB6AC: BF870191
	v_add_co_ci_u32_e64 v3, null, s3, v3, vcc_lo               // 0000002FB6B0: D5207C03 01AA0603
	v_add3_u32 v4, v6, v4, 0x7fff                              // 0000002FB6B8: D6550004 03FE0906 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002FB6C4: BF870093
	.long 0xd7006a00                                           // 0000002FB6C8: D7006A00
	v_cndmask_b32_e32 v1, v2, v0, vcc_lo                       // 0000002FB6CC: 02020102
	v_add_co_ci_u32_e64 v1, null, v3, v1, vcc_lo               // 0000002FB6D0: D5207C01 01AA0303
	global_store_d16_hi_b16 v[0:1], v4, off                    // 0000002FB6D8: DC960000 007C0400
	s_nop 0                                                    // 0000002FB6E0: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 0000002FB6E4: BFB60003
	s_endpgm                                                   // 0000002FB6E8: BFB00000
		...

