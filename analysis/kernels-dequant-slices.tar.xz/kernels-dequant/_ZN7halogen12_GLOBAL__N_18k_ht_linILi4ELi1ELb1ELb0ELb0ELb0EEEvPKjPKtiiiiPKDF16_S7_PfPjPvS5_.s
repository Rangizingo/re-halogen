0000000000526800 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb1ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_>:
; _ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb1ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_():
	s_clause 0x3                                               // 000000526800: BF850003
	s_load_b256 s[20:27], s[0:1], null                         // 000000526804: F40C0500 F8000000
	s_load_b256 s[12:19], s[0:1], 0x20                         // 00000052680C: F40C0300 F8000020
	s_load_b128 s[28:31], s[0:1], 0x40                         // 000000526814: F4080700 F8000040
	s_load_b32 s33, s[0:1], 0x54                               // 00000052681C: F4000840 F8000054
	v_and_b32_e32 v10, 31, v0                                  // 000000526824: 3614009F
	v_lshrrev_b32_e32 v8, 5, v0                                // 000000526828: 32100085
	s_mov_b32 s4, s3                                           // 00000052682C: BE840003
	s_mov_b32 s10, exec_lo                                     // 000000526830: BE8A007E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000526834: BF870002
	v_lshlrev_b32_e32 v9, 2, v10                               // 000000526838: 30121482
	s_waitcnt lgkmcnt(0)                                       // 00000052683C: BF89FC07
	s_ashr_i32 s34, s25, 31                                    // 000000526840: 86229F19
	s_mul_i32 s35, s27, s3                                     // 000000526844: 9623031B
	s_lshr_b32 s0, s34, 25                                     // 000000526848: 85009922
	s_add_i32 s1, s35, s27                                     // 00000052684C: 81011B23
	s_add_i32 s0, s25, s0                                      // 000000526850: 81000019
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000526854: BF870499
	s_ashr_i32 s0, s0, 7                                       // 000000526858: 86008700
	s_min_i32 s0, s0, s1                                       // 00000052685C: 89000100
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000526860: BF870499
	s_sub_i32 s11, s0, s35                                     // 000000526864: 818B2300
	.long 0xd4c4007e                                           // 000000526868: D4C4007E
	v_cndmask_b32_e32 v1, s11, v8, vcc_lo                      // 00000052686C: 0202100B
	s_cbranch_execz 501                                        // 000000526870: BFA501F5 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb1ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x848>
	s_add_i32 s27, s24, -1                                     // 000000526874: 811BC118
	s_cmp_lg_u64 s[30:31], 0                                   // 000000526878: BF11801E
	v_dual_mov_b32 v11, v8 :: v_dual_and_b32 v2, 2, v0         // 00000052687C: CA240108 0B020082
	s_cselect_b32 s36, -1, 0                                   // 000000526884: 982480C1
	s_abs_i32 s37, s11                                         // 000000526888: BEA5150B
	v_lshlrev_b32_e32 v6, 3, v10                               // 00000052688C: 300C1483
	s_cvt_f32_u32 s0, s37                                      // 000000526890: BE806525
	v_and_b32_e32 v1, 1, v0                                    // 000000526894: 36020081
	v_and_b32_e32 v4, 4, v0                                    // 000000526898: 36080084
	v_and_b32_e32 v5, 8, v0                                    // 00000052689C: 360A0088
	v_rcp_iflag_f32_e32 v3, s0                                 // 0000005268A0: 7E065600
	v_add_nc_u32_e32 v7, s35, v8                               // 0000005268A4: 4A0E1023
	.long 0xd44a0003                                           // 0000005268A8: D44A0003
	v_cndmask_b32_e32 v1, 0, v2, vcc_lo                        // 0000005268AC: 02020480
	v_lshl_or_b32 v2, v8, 8, v6                                // 0000005268B0: D6560002 04191108
	s_ashr_i32 s41, s11, 31                                    // 0000005268B8: 86299F0B
	s_sub_i32 s9, 0, s37                                       // 0000005268BC: 81892580
	s_mul_i32 s43, s41, 0x1400                                 // 0000005268C0: 962BFF29 00001400
	.long 0xd44c0000                                           // 0000005268C8: D44C0000
	v_cndmask_b32_e32 v1, 16, v10, vcc_lo                      // 0000005268CC: 02021490
	.long 0xd44a0001                                           // 0000005268D0: D44A0001
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 0000005268D4: 02020280
	.long 0xd44a0006                                           // 0000005268D8: D44A0006
	v_cndmask_b32_e32 v1, 0, v5, vcc_lo                        // 0000005268DC: 02020A80
	v_readfirstlane_b32 s5, v3                                 // 0000005268E0: 7E0A0503
	v_lshl_or_b32 v1, v7, 7, v9                                // 0000005268E4: D6560001 04250F07
	v_subrev_nc_u32_e32 v12, s43, v2                           // 0000005268EC: 4E18042B
	s_lshl_b32 s7, s11, 7                                      // 0000005268F0: 8407870B
	s_mov_b32 s38, s25                                         // 0000005268F4: BEA60019
	s_mul_f32 s8, s5, 0x4f7ffffe                               // 0000005268F8: A208FF05 4F7FFFFE
	.long 0xd44a0005                                           // 000000526900: D44A0005
	v_cndmask_b32_e32 v1, 0, v4, vcc_lo                        // 000000526904: 02020880
	s_mov_b32 s39, 0                                           // 000000526908: BEA70080
	s_mov_b32 s40, 0x76543210                                  // 00000052690C: BEA800FF 76543210
	s_cvt_u32_f32 s8, s8                                       // 000000526914: BE886708
	s_lshl_b32 s42, s11, 8                                     // 000000526918: 842A880B
	s_sub_i32 s43, 0, s7                                       // 00000052691C: 81AB0780
	s_mov_b32 s45, 0x3db504f3                                  // 000000526920: BEAD00FF 3DB504F3
	s_mul_i32 s9, s9, s8                                       // 000000526928: 96090809
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000052692C: BF870499
	s_mul_hi_u32 s9, s8, s9                                    // 000000526930: 96890908
	s_add_i32 s44, s8, s9                                      // 000000526934: 812C0908
	s_branch 164                                               // 000000526938: BFA000A4 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb1ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x3cc>
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000052693C: BF870091
	.long 0xd7006a02                                           // 000000526940: D7006A02
	v_cndmask_b32_e32 v1, s12, v2, vcc_lo                      // 000000526944: 0202040C
	v_add_co_ci_u32_e64 v3, null, s13, v3, vcc_lo              // 000000526948: D5207C03 01AA060D
	v_add_nc_u32_e32 v1, 0x400, v1                             // 000000526950: 4A0202FF 00000400
	global_load_d16_b16 v2, v[2:3], off offset:6               // 000000526958: DC820006 027C0002
	s_waitcnt vmcnt(0)                                         // 000000526960: BF8903F7
	v_fma_mix_f32 v5, v17, v2, v15 op_sel_hi:[0,1,0]           // 000000526964: CC200005 143E0511
	v_sub_f32_e32 v4, v18, v16                                 // 00000052696C: 08082112
	v_fma_mix_f32 v2, -v17, v2, v15 op_sel_hi:[0,1,0]          // 000000526970: CC200002 343E0511
	v_add_f32_e32 v3, v18, v16                                 // 000000526978: 06062112
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000052697C: BF8701A2
	v_add_f32_e32 v7, v4, v2                                   // 000000526980: 060E0504
	v_sub_f32_e32 v2, v4, v2                                   // 000000526984: 08040504
	v_add_f32_e32 v6, v3, v5                                   // 000000526988: 060C0B03
	v_sub_f32_e32 v3, v3, v5                                   // 00000052698C: 08060B03
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000526990: BF870193
	v_mov_b32_dpp v16, v2 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000526994: 7E2002FA FF016102
	v_mov_b32_dpp v4, v6 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000052699C: 7E0802FA FF016106
	v_cndmask_b32_e64 v6, -v6, v6, s1                          // 0000005269A4: D5010006 20060D06
	v_cndmask_b32_e64 v2, -v2, v2, s1                          // 0000005269AC: D5010002 20060502
	v_mov_b32_dpp v15, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000005269B4: 7E1E02FA FF016103
	v_cndmask_b32_e64 v3, -v3, v3, s1                          // 0000005269BC: D5010003 20060703
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000005269C4: BF870144
	v_add_f32_e32 v4, v6, v4                                   // 0000005269C8: 06080906
	v_mov_b32_dpp v5, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000005269CC: 7E0A02FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, s1                          // 0000005269D4: D5010007 20060F07
	.long 0xd72c0006                                           // 0000005269DC: D72C0006
	v_cndmask_b32_e32 v1, 0x1400, v14, vcc_lo                  // 0000005269E0: 02021CFF 00001400
	v_dual_add_f32 v2, v2, v16 :: v_dual_add_f32 v5, v7, v5    // 0000005269E8: C9082102 02040B07
	v_mov_b32_dpp v7, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000005269F0: 7E0E02FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, s3                          // 0000005269F8: D5010004 200E0904
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000526A00: BF8701C3
	v_mov_b32_dpp v16, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000526A04: 7E2002FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, s3                          // 000000526A0C: D5010002 200E0502
	v_mov_b32_dpp v14, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000526A14: 7E1C02FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, s3                          // 000000526A1C: D5010005 200E0B05
	v_dual_add_f32 v3, v3, v15 :: v_dual_add_f32 v2, v2, v16   // 000000526A24: C9081F03 03022102
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000526A2C: BF870112
	v_add_f32_e32 v5, v5, v14                                  // 000000526A30: 060A1D05
	v_mov_b32_dpp v15, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000526A34: 7E1E02FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, s3                          // 000000526A3C: D5010003 200E0703
	s_delay_alu instid0(VALU_DEP_4)                            // 000000526A44: BF870004
	v_mov_b32_dpp v16, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000526A48: 7E2002FA FF016402
	v_cndmask_b32_e64 v2, -v2, v2, s5                          // 000000526A50: D5010002 20160502
	v_mov_b32_dpp v14, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000526A58: 7E1C02FA FF016405
	v_cndmask_b32_e64 v5, -v5, v5, s5                          // 000000526A60: D5010005 20160B05
	v_add_f32_e32 v4, v4, v7                                   // 000000526A68: 06080F04
	.long 0xd72c0007                                           // 000000526A6C: D72C0007
	v_cndmask_b32_e32 v1, s42, v13, vcc_lo                     // 000000526A70: 02021A2A
	v_dual_add_f32 v2, v2, v16 :: v_dual_add_nc_u32 v11, 8, v11// 000000526A74: C9202102 020A1688
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000526A7C: BF870214
	v_add_f32_e32 v5, v5, v14                                  // 000000526A80: 060A1D05
	v_mov_b32_dpp v13, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000526A84: 7E1A02FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s5                          // 000000526A8C: D5010004 20160904
	v_add_f32_e32 v3, v3, v15                                  // 000000526A94: 06061F03
	v_mov_b32_dpp v16, v2 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000526A98: 7E2002FA FF016802
	v_mov_b32_dpp v14, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000526AA0: 7E1C02FA FF016805
	v_cndmask_b32_e64 v5, -v5, v5, s6                          // 000000526AA8: D5010005 201A0B05
	v_add_f32_e32 v4, v4, v13                                  // 000000526AB0: 06081B04
	v_mov_b32_dpp v15, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000526AB4: 7E1E02FA FF016403
	v_cndmask_b32_e64 v3, -v3, v3, s5                          // 000000526ABC: D5010003 20160703
	v_cndmask_b32_e64 v2, -v2, v2, s6                          // 000000526AC4: D5010002 201A0502
	v_add_f32_e32 v5, v5, v14                                  // 000000526ACC: 060A1D05
	v_mov_b32_dpp v13, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000526AD0: 7E1A02FA FF016804
	v_cndmask_b32_e64 v4, -v4, v4, s6                          // 000000526AD8: D5010004 201A0904
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000526AE0: BF870214
	v_dual_add_f32 v3, v3, v15 :: v_dual_add_f32 v2, v2, v16   // 000000526AE4: C9081F03 03022102
	v_mov_b32_e32 v14, v5                                      // 000000526AEC: 7E1C0305
	v_cndmask_b32_e64 v5, -v5, v5, s0                          // 000000526AF0: D5010005 20020B05
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000526AF8: BF870214
	v_add_f32_e32 v4, v4, v13                                  // 000000526AFC: 06081B04
	v_mov_b32_dpp v15, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000526B00: 7E1E02FA FF016803
	v_cndmask_b32_e64 v3, -v3, v3, s6                          // 000000526B08: D5010003 201A0703
	v_mov_b32_e32 v16, v2                                      // 000000526B10: 7E200302
	v_cndmask_b32_e64 v2, -v2, v2, s0                          // 000000526B14: D5010002 20020502
	v_mov_b32_e32 v13, v4                                      // 000000526B1C: 7E1A0304
	v_cndmask_b32_e64 v4, -v4, v4, s0                          // 000000526B20: D5010004 20020904
	v_add_f32_e32 v3, v3, v15                                  // 000000526B28: 06061F03
	v_permlanex16_b32 v14, v14, s40, 0xfedcba98                // 000000526B2C: D65C000E 03FC510E FEDCBA98
	v_permlanex16_b32 v16, v16, s40, 0xfedcba98                // 000000526B38: D65C0010 03FC5110 FEDCBA98
	v_permlanex16_b32 v13, v13, s40, 0xfedcba98                // 000000526B44: D65C000D 03FC510D FEDCBA98
	v_sub_nc_u32_e32 v6, v6, v7                                // 000000526B50: 4C0C0F06
	v_mov_b32_e32 v15, v3                                      // 000000526B54: 7E1E0303
	v_cndmask_b32_e64 v3, -v3, v3, s0                          // 000000526B58: D5010003 20020703
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000526B60: BF870214
	v_dual_add_f32 v5, v5, v14 :: v_dual_add_f32 v4, v4, v13   // 000000526B64: C9081D05 05041B04
	v_dual_add_f32 v7, v2, v16 :: v_dual_add_nc_u32 v6, v12, v6// 000000526B6C: C9202102 07060D0C
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000526B74: BF870224
	v_permlanex16_b32 v15, v15, s40, 0xfedcba98                // 000000526B78: D65C000F 03FC510F FEDCBA98
	v_cmp_le_i32_e32 vcc_lo, s11, v11                          // 000000526B84: 7C86160B
	v_fma_mixlo_f16 v2, v4, s45, 0                             // 000000526B88: CC210002 02005B04
	v_add_nc_u32_e32 v12, 0x800, v12                           // 000000526B90: 4A1818FF 00000800
	v_fma_mixhi_f16 v2, v5, s45, 0                             // 000000526B98: CC220002 02005B05
	v_add_f32_e32 v13, v3, v15                                 // 000000526BA0: 061A1F03
	v_fma_mixhi_f16 v3, v7, s45, 0                             // 000000526BA4: CC220003 02005B07
	s_or_b32 s39, vcc_lo, s39                                  // 000000526BAC: 8C27276A
	s_delay_alu instid0(VALU_DEP_2)                            // 000000526BB0: BF870002
	v_fma_mixlo_f16 v3, v13, s45, 0                            // 000000526BB4: CC210003 02005B0D
	ds_store_b64 v6, v[2:3]                                    // 000000526BBC: D9340000 00000206
	s_and_not1_b32 exec_lo, exec_lo, s39                       // 000000526BC4: 917E277E
	s_cbranch_execz 287                                        // 000000526BC8: BFA5011F <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb1ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x848>
	.long 0xd72d0002                                           // 000000526BCC: D72D0002
	v_cndmask_b32_e32 v0, v11, v44, vcc_lo                     // 000000526BD0: 0200590B
	s_mov_b32 s7, -1                                           // 000000526BD4: BE8700C1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000526BD8: BF870091
	.long 0xd72c0003                                           // 000000526BDC: D72C0003
	v_cndmask_b32_e32 v0, v2, v37, vcc_lo                      // 000000526BE0: 02004B02
	v_sub_nc_u32_e32 v3, v11, v3                               // 000000526BE4: 4C06070B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000526BE8: BF870121
	v_subrev_nc_u32_e32 v5, s37, v3                            // 000000526BEC: 4E0A0625
	v_cmp_le_u32_e32 vcc_lo, s37, v3                           // 000000526BF0: 7C960625
	v_dual_cndmask_b32 v3, v3, v5 :: v_dual_add_nc_u32 v4, 1, v2// 000000526BF4: CA600B03 03040481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000526BFC: BF870111
	v_cndmask_b32_e32 v2, v2, v4, vcc_lo                       // 000000526C00: 02040902
	v_cmp_le_u32_e32 vcc_lo, s37, v3                           // 000000526C04: 7C960625
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000526C08: BF870092
	v_add_nc_u32_e32 v4, 1, v2                                 // 000000526C0C: 4A080481
	v_cndmask_b32_e32 v2, v2, v4, vcc_lo                       // 000000526C10: 02040902
	s_and_not1_b32 vcc_lo, exec_lo, s36                        // 000000526C14: 916A247E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000526C18: BF870091
	v_xor_b32_e32 v14, s41, v2                                 // 000000526C1C: 3A1C0429
	v_subrev_nc_u32_e32 v13, s41, v14                          // 000000526C20: 4E1A1C29
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000526C24: BF8700A1
	v_mad_u64_u32 v[6:7], null, s43, v13, v[1:2]               // 000000526C28: D6FE7C06 04061A2B
	v_min_i32_e32 v2, s27, v13                                 // 000000526C30: 22041A1B
	v_mad_i64_i32 v[4:5], null, v2, s38, 0                     // 000000526C34: D6FF7C04 02004D02
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000526C3C: BF870093
	v_ashrrev_i32_e32 v7, 31, v6                               // 000000526C40: 340E0C9F
	.long 0xd73c0002                                           // 000000526C44: D73C0002
	v_cndmask_b32_e32 v1, 1, v6, vcc_lo                        // 000000526C48: 02020C81
	s_cbranch_vccnz 210                                        // 000000526C4C: BFA400D2 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb1ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x798>
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000526C50: BF870093
	.long 0xd7006a06                                           // 000000526C54: D7006A06
	v_cndmask_b32_e32 v1, v4, v6, vcc_lo                       // 000000526C58: 02020D04
	v_add_co_ci_u32_e64 v7, null, v5, v7, vcc_lo               // 000000526C5C: D5207C07 01AA0F05
	.long 0x7f3e3880                                           // 000000526C64: 7F3E3880
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000526C68: BF870112
	.long 0xd73c0006                                           // 000000526C6C: D73C0006
	v_cndmask_b32_e32 v1, 1, v6, vcc_lo                        // 000000526C70: 02020C81
	.long 0x7f44399f                                           // 000000526C74: 7F44399F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000526C78: BF870092
	.long 0xd7006a0f                                           // 000000526C7C: D7006A0F
	v_cndmask_b32_e32 v1, s22, v6, vcc_lo                      // 000000526C80: 02020C16
	v_add_co_ci_u32_e64 v16, null, s23, v7, vcc_lo             // 000000526C84: D5207C10 01AA0E17
	.long 0xd7006a06                                           // 000000526C8C: D7006A06
	v_cndmask_b32_e32 v1, s30, v6, vcc_lo                      // 000000526C90: 02020C1E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000526C94: BF870001
	v_add_co_ci_u32_e64 v7, null, s31, v7, vcc_lo              // 000000526C98: D5207C07 01AA0E1F
	global_load_b64 v[15:16], v[15:16], off                    // 000000526CA0: DC560000 0F7C000F
	.long 0xd7006a11                                           // 000000526CA8: D7006A11
	v_cndmask_b32_e32 v1, s12, v2, vcc_lo                      // 000000526CAC: 0202040C
	global_load_b64 v[6:7], v[6:7], off                        // 000000526CB0: DC560000 067C0006
	v_add_co_ci_u32_e64 v18, null, s13, v3, vcc_lo             // 000000526CB8: D5207C12 01AA060D
	s_clause 0x1                                               // 000000526CC0: BF850001
	global_load_b32 v19, v[17:18], off                         // 000000526CC4: DC520000 137C0011
	global_load_d16_b16 v17, v[17:18], off offset:4            // 000000526CCC: DC820004 117C0011
	s_waitcnt vmcnt(3)                                         // 000000526CD4: BF890FF7
	.long 0x7e24390f                                           // 000000526CD8: 7E24390F
	s_waitcnt vmcnt(2)                                         // 000000526CDC: BF890BF7
	v_and_b32_e32 v41, 0xffff0000, v6                          // 000000526CE0: 36520CFF FFFF0000
	v_lshlrev_b32_e32 v6, 16, v6                               // 000000526CE8: 300C0C90
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000526CEC: BF870093
	v_lshlrev_b32_e32 v18, 16, v18                             // 000000526CF0: 30242490
	v_mul_f32_e32 v22, 0xbfb8aa3b, v18                         // 000000526CF4: 102C24FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000526CFC: BF870291
	v_exp_f32_e32 v22, v22                                     // 000000526D00: 7E2C4B16
	v_dual_add_f32 v22, 1.0, v22 :: v_dual_and_b32 v15, 0xffff0000, v15// 000000526D04: C9242CF2 160E1EFF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000526D10: BF870111
	v_mul_f32_e32 v21, 0xbfb8aa3b, v15                         // 000000526D14: 102A1EFF BFB8AA3B
	v_div_scale_f32 v26, null, v22, v22, v18                   // 000000526D1C: D6FC7C1A 044A2D16
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000526D24: BF8701B2
	v_exp_f32_e32 v21, v21                                     // 000000526D28: 7E2A4B15
	v_lshlrev_b32_e32 v20, 16, v16                             // 000000526D2C: 30282090
	v_div_scale_f32 v39, s8, v18, v22, v18                     // 000000526D30: D6FC0827 044A2D12
	v_rcp_f32_e32 v30, v26                                     // 000000526D38: 7E3C551A
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000526D3C: BF870196
	v_add_f32_e32 v21, 1.0, v21                                // 000000526D40: 062A2AF2
	v_mul_f32_e32 v23, 0xbfb8aa3b, v20                         // 000000526D44: 102E28FF BFB8AA3B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000526D4C: BF870195
	v_fma_f32 v38, -v26, v30, 1.0                              // 000000526D50: D6130026 23CA3D1A
	v_div_scale_f32 v25, null, v21, v21, v15                   // 000000526D58: D6FC7C19 043E2B15
	s_delay_alu instid0(VALU_DEP_3)                            // 000000526D60: BF870003
	v_exp_f32_e32 v23, v23                                     // 000000526D64: 7E2E4B17
	v_and_b32_e32 v16, 0xffff0000, v16                         // 000000526D68: 362020FF FFFF0000
	v_div_scale_f32 v35, vcc_lo, v15, v21, v15                 // 000000526D70: D6FC6A23 043E2B0F
	v_fmac_f32_e32 v30, v38, v30                               // 000000526D78: 563C3D26
	v_rcp_f32_e32 v28, v25                                     // 000000526D7C: 7E385519
	s_delay_alu instid0(TRANS32_DEP_2) | instid1(VALU_DEP_3)   // 000000526D80: BF870186
	v_dual_add_f32 v23, 1.0, v23 :: v_dual_mul_f32 v24, 0xbfb8aa3b, v16// 000000526D84: C9062EF2 171820FF BFB8AA3B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000526D90: BF870115
	v_fma_f32 v36, -v25, v28, 1.0                              // 000000526D94: D6130024 23CA3919
	v_div_scale_f32 v27, null, v23, v23, v20                   // 000000526D9C: D6FC7C1B 04522F17
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000526DA4: BF8701A3
	v_exp_f32_e32 v24, v24                                     // 000000526DA8: 7E304B18
	v_div_scale_f32 v37, s7, v20, v23, v20                     // 000000526DAC: D6FC0725 04522F14
	v_fmac_f32_e32 v28, v36, v28                               // 000000526DB4: 56383924
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 000000526DB8: BF870313
	v_rcp_f32_e32 v32, v27                                     // 000000526DBC: 7E40551B
	v_add_f32_e32 v24, 1.0, v24                                // 000000526DC0: 063030F2
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000526DC4: BF870115
	v_fma_f32 v40, -v27, v32, 1.0                              // 000000526DC8: D6130028 23CA411B
	v_div_scale_f32 v29, null, v24, v24, v16                   // 000000526DD0: D6FC7C1D 04423118
	v_div_scale_f32 v38, s9, v16, v24, v16                     // 000000526DD8: D6FC0926 04423110
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000526DE0: BF870193
	v_fmac_f32_e32 v32, v40, v32                               // 000000526DE4: 56404128
	v_rcp_f32_e32 v33, v29                                     // 000000526DE8: 7E42551D
	v_mul_f32_e32 v40, v35, v28                                // 000000526DEC: 10503923
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000526DF0: BF870112
	v_mul_f32_e32 v42, v37, v32                                // 000000526DF4: 10544125
	v_fma_f32 v43, -v25, v40, v35                              // 000000526DF8: D613002B 248E5119
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000526E00: BF870292
	v_fma_f32 v46, -v27, v42, v37                              // 000000526E04: D613002E 2496551B
	v_fma_f32 v36, -v29, v33, 1.0                              // 000000526E0C: D6130024 23CA431D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000526E14: BF870113
	v_fmac_f32_e32 v40, v43, v28                               // 000000526E18: 5650392B
	v_dual_fmac_f32 v42, v46, v32 :: v_dual_fmac_f32 v33, v36, v33// 000000526E1C: C800412E 2A204324
	v_mul_f32_e32 v36, v39, v30                                // 000000526E24: 10483D27
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000526E28: BF870193
	v_fma_f32 v25, -v25, v40, v35                              // 000000526E2C: D6130019 248E5119
	v_fma_f32 v27, -v27, v42, v37                              // 000000526E34: D613001B 2496551B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000526E3C: BF870214
	v_mul_f32_e32 v44, v38, v33                                // 000000526E40: 10584326
	v_fma_f32 v45, -v26, v36, v39                              // 000000526E44: D613002D 249E491A
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000526E4C: BF8701A4
	v_div_fmas_f32 v25, v25, v28, v40                          // 000000526E50: D6370019 04A23919
	s_mov_b32 vcc_lo, s8                                       // 000000526E58: BEEA0008
	v_fma_f32 v43, -v29, v44, v38                              // 000000526E5C: D613002B 249A591D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000526E64: BF870193
	v_fmac_f32_e32 v36, v45, v30                               // 000000526E68: 56483D2D
	v_div_fixup_f32 v15, v25, v21, v15                         // 000000526E6C: D627000F 043E2B19
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000526E74: BF870193
	v_fmac_f32_e32 v44, v43, v33                               // 000000526E78: 5658432B
	v_fma_f32 v26, -v26, v36, v39                              // 000000526E7C: D613001A 249E491A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000526E84: BF870193
	v_mul_f32_e32 v15, v15, v41                                // 000000526E88: 101E530F
	v_fma_f32 v25, -v29, v44, v38                              // 000000526E8C: D6130019 249A591D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000526E94: BF8701A3
	v_div_fmas_f32 v26, v26, v30, v36                          // 000000526E98: D637001A 04923D1A
	s_mov_b32 vcc_lo, s7                                       // 000000526EA0: BEEA0007
	.long 0x7e3e398f                                           // 000000526EA4: 7E3E398F
	v_div_fmas_f32 v21, v27, v32, v42                          // 000000526EA8: D6370015 04AA411B
	s_mov_b32 vcc_lo, s9                                       // 000000526EB0: BEEA0009
	v_div_fixup_f32 v18, v26, v22, v18                         // 000000526EB4: D6270012 044A2D1A
	v_lshlrev_b32_e32 v22, 16, v7                              // 000000526EBC: 302C0E90
	v_and_b32_e32 v7, 0xffff0000, v7                           // 000000526EC0: 360E0EFF FFFF0000
	v_div_fixup_f32 v20, v21, v23, v20                         // 000000526EC8: D6270014 04522F15
	s_mov_b32 s7, 0                                            // 000000526ED0: BE870080
	v_mul_f32_e32 v6, v18, v6                                  // 000000526ED4: 100C0D12
	v_div_fmas_f32 v18, v25, v33, v44                          // 000000526ED8: D6370012 04B24319
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000526EE0: BF870193
	v_mul_f32_e32 v20, v20, v22                                // 000000526EE4: 10282D14
	.long 0x7e443986                                           // 000000526EE8: 7E443986
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000526EEC: BF870223
	v_div_fixup_f32 v16, v18, v24, v16                         // 000000526EF0: D6270010 04423112
	v_and_b32_e32 v18, 1, v31                                  // 000000526EF8: 36243E81
	v_bfe_u32 v21, v20, 16, 1                                  // 000000526EFC: D6100015 02052114
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000526F04: BF870193
	v_dual_mul_f32 v7, v16, v7 :: v_dual_and_b32 v22, 1, v34   // 000000526F08: C8E40F10 07164481
	v_add3_u32 v15, v15, v18, 0x7fff                           // 000000526F10: D655000F 03FE250F 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000526F1C: BF870193
	v_add3_u32 v16, v20, v21, 0x7fff                           // 000000526F20: D6550010 03FE2B14 00007FFF
	v_add3_u32 v6, v6, v22, 0x7fff                             // 000000526F2C: D6550006 03FE2D06 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000526F38: BF870214
	v_bfe_u32 v18, v7, 16, 1                                   // 000000526F3C: D6100012 02052107
	v_and_b32_e32 v15, 0xffff0000, v15                         // 000000526F44: 361E1EFF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000526F4C: BF870214
	v_and_b32_e32 v20, 0xffff0000, v16                         // 000000526F50: 362820FF FFFF0000
	v_and_b32_e32 v6, 0xffff0000, v6                           // 000000526F58: 360C0CFF FFFF0000
	s_delay_alu instid0(VALU_DEP_4)                            // 000000526F60: BF870004
	v_add3_u32 v7, v7, v18, 0x7fff                             // 000000526F64: D6550007 03FE2507 00007FFF
	s_waitcnt vmcnt(1)                                         // 000000526F70: BF8907F7
	v_fma_mix_f32 v16, v19, v15, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000526F74: CC200810 8A021F13
	s_waitcnt vmcnt(0)                                         // 000000526F7C: BF8903F7
	v_fma_mix_f32 v15, v17, v20, neg(0) op_sel_hi:[1,0,0]      // 000000526F80: CC20000F 8A022911
	v_fma_mix_f32 v18, v19, v6, neg(0) op_sel_hi:[1,0,0]       // 000000526F88: CC200012 8A020D13
	v_and_b32_e32 v17, 0xffff0000, v7                          // 000000526F90: 36220EFF FFFF0000
	s_and_not1_b32 vcc_lo, exec_lo, s7                         // 000000526F98: 916A077E
	s_cbranch_vccnz 65127                                      // 000000526F9C: BFA4FE67 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb1ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x13c>
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000526FA0: BF870093
	.long 0xd73c0004                                           // 000000526FA4: D73C0004
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 000000526FA8: 02020881
	.long 0xd7006a04                                           // 000000526FAC: D7006A04
	v_cndmask_b32_e32 v1, s22, v4, vcc_lo                      // 000000526FB0: 02020816
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000526FB4: BF870111
	v_add_co_ci_u32_e64 v5, null, s23, v5, vcc_lo              // 000000526FB8: D5207C05 01AA0A17
	.long 0xd7006a04                                           // 000000526FC0: D7006A04
	v_cndmask_b32_e32 v1, v4, v2, vcc_lo                       // 000000526FC4: 02020504
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000526FC8: BF8700A1
	v_add_co_ci_u32_e64 v5, null, v5, v3, vcc_lo               // 000000526FCC: D5207C05 01AA0705
	.long 0xd7006a06                                           // 000000526FD4: D7006A06
	v_cndmask_b32_e32 v1, s12, v2, vcc_lo                      // 000000526FD8: 0202040C
	v_add_co_ci_u32_e64 v7, null, s13, v3, vcc_lo              // 000000526FDC: D5207C07 01AA060D
	global_load_b64 v[4:5], v[4:5], off                        // 000000526FE4: DC560000 047C0004
	s_clause 0x1                                               // 000000526FEC: BF850001
	global_load_b32 v17, v[6:7], off                           // 000000526FF0: DC520000 117C0006
	global_load_d16_b16 v6, v[6:7], off offset:4               // 000000526FF8: DC820004 067C0006
	s_waitcnt vmcnt(2)                                         // 000000527000: BF890BF7
	.long 0x7e0e3904                                           // 000000527004: 7E0E3904
	v_and_b32_e32 v4, 0xffff0000, v4                           // 000000527008: 360808FF FFFF0000
	v_lshlrev_b32_e32 v15, 16, v5                              // 000000527010: 301E0A90
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000527014: BF8701A3
	v_lshlrev_b32_e32 v7, 16, v7                               // 000000527018: 300E0E90
	s_waitcnt vmcnt(1)                                         // 00000052701C: BF8907F7
	v_fma_mix_f32 v16, v17, v4, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000527020: CC200810 8A020911
	s_waitcnt vmcnt(0)                                         // 000000527028: BF8903F7
	v_fma_mix_f32 v15, v6, v15, neg(0) op_sel_hi:[1,0,0]       // 00000052702C: CC20000F 8A021F06
	v_fma_mix_f32 v18, v17, v7, neg(0) op_sel_hi:[1,0,0]       // 000000527034: CC200012 8A020F11
	v_and_b32_e32 v17, 0xffff0000, v5                          // 00000052703C: 36220AFF FFFF0000
	s_branch 65085                                             // 000000527044: BFA0FE3D <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb1ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x13c>
	s_or_b32 exec_lo, exec_lo, s10                             // 000000527048: 8C7E0A7E
	s_bfe_i32 s10, s11, 0x1001c                                // 00000052704C: 938AFF0B 0001001C
	s_lshr_b32 s5, s34, 28                                     // 000000527054: 85059C22
	s_lshr_b64 s[0:1], s[10:11], 29                            // 000000527058: 85809D0A
	s_lshl_b32 s3, s11, 3                                      // 00000052705C: 8403830B
	s_add_i32 s0, s0, 7                                        // 000000527060: 81008700
	s_lshl_b32 s1, s35, 3                                      // 000000527064: 84018323
	s_ashr_i32 s0, s0, 3                                       // 000000527068: 86008300
	v_dual_mov_b32 v13, 0 :: v_dual_mov_b32 v12, 0             // 00000052706C: CA100080 0D0C0080
	.long 0xd72c0001                                           // 000000527074: D72C0001
	v_cndmask_b32_e32 v1, s0, v8, vcc_lo                       // 000000527078: 02021000
	v_dual_mov_b32 v11, 0 :: v_dual_mov_b32 v14, 0             // 00000052707C: CA100080 0B0E0080
	v_dual_mov_b32 v15, 0 :: v_dual_mov_b32 v16, 0             // 000000527084: CA100080 0F100080
	v_dual_mov_b32 v18, 0 :: v_dual_mov_b32 v19, 0             // 00000052708C: CA100080 12120080
	v_mov_b32_e32 v20, 0                                       // 000000527094: 7E280280
	v_add_nc_u32_e32 v2, s0, v1                                // 000000527098: 4A040200
	s_add_i32 s0, s25, s5                                      // 00000052709C: 81000519
	s_ashr_i32 s5, s1, 31                                      // 0000005270A0: 86059F01
	s_ashr_i32 s0, s0, 4                                       // 0000005270A4: 86008400
	s_waitcnt lgkmcnt(0)                                       // 0000005270A8: BF89FC07
	v_min_i32_e32 v7, s3, v2                                   // 0000005270AC: 220E0403
	s_mul_i32 s3, s0, s2                                       // 0000005270B0: 96030200
	s_mul_hi_i32 s6, s0, s2                                    // 0000005270B4: 97060200
	s_add_u32 s0, s3, s1                                       // 0000005270B8: 80000103
	v_ashrrev_i32_e32 v2, 31, v1                               // 0000005270BC: 3404029F
	v_cmp_lt_i32_e32 vcc_lo, v1, v7                            // 0000005270C0: 7C820F01
	s_addc_u32 s1, s6, s5                                      // 0000005270C4: 82010506
	s_barrier                                                  // 0000005270C8: BFBD0000
	s_lshl_b64 s[6:7], s[0:1], 10                              // 0000005270CC: 84868A00
	buffer_gl0_inv                                             // 0000005270D0: E0AC0000 00000000
	s_and_saveexec_b32 s1, vcc_lo                              // 0000005270D8: BE81206A
	s_cbranch_execz 31                                         // 0000005270DC: BFA5001F <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb1ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x95c>
	.long 0xd73c0003                                           // 0000005270E0: D73C0003
	v_cndmask_b32_e32 v1, 10, v1, vcc_lo                       // 0000005270E4: 0202028A
	s_add_u32 s0, s20, s6                                      // 0000005270E8: 80000614
	s_addc_u32 s3, s21, s7                                     // 0000005270EC: 82030715
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005270F0: BF870091
	.long 0xd7000003                                           // 0000005270F4: D7000003
	v_cndmask_b32_e32 v1, s0, v3, vcc_lo                       // 0000005270F8: 02020600
	v_add_co_ci_u32_e64 v4, null, s3, v4, s0                   // 0000005270FC: D5207C04 00020803
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000527104: BF870092
	.long 0xd7000003                                           // 000000527108: D7000003
	v_cndmask_b32_e32 v1, v3, v9, vcc_lo                       // 00000052710C: 02021303
	v_add_co_ci_u32_e64 v4, null, 0, v4, s0                    // 000000527110: D5207C04 00020880
	s_clause 0x7                                               // 000000527118: BF850007
	global_load_b32 v11, v[3:4], off                           // 00000052711C: DC520000 0B7C0003
	global_load_b32 v12, v[3:4], off offset:128                // 000000527124: DC520080 0C7C0003
	global_load_b32 v14, v[3:4], off offset:256                // 00000052712C: DC520100 0E7C0003
	global_load_b32 v15, v[3:4], off offset:384                // 000000527134: DC520180 0F7C0003
	global_load_b32 v16, v[3:4], off offset:512                // 00000052713C: DC520200 107C0003
	global_load_b32 v18, v[3:4], off offset:640                // 000000527144: DC520280 127C0003
	global_load_b32 v19, v[3:4], off offset:768                // 00000052714C: DC520300 137C0003
	global_load_b32 v20, v[3:4], off offset:896                // 000000527154: DC520380 147C0003
	s_or_b32 exec_lo, exec_lo, s1                              // 00000052715C: 8C7E017E
	v_dual_mov_b32 v22, 0 :: v_dual_mov_b32 v23, 0             // 000000527160: CA100080 16160080
	v_dual_mov_b32 v24, 0 :: v_dual_mov_b32 v25, 0             // 000000527168: CA100080 18180080
	v_dual_mov_b32 v26, 0 :: v_dual_mov_b32 v21, 0             // 000000527170: CA100080 1A140080
	v_mov_b32_e32 v17, 0                                       // 000000527178: 7E220280
	s_ashr_i32 s3, s2, 31                                      // 00000052717C: 86039F02
	s_and_saveexec_b32 s1, vcc_lo                              // 000000527180: BE81206A
	s_cbranch_execz 988                                        // 000000527184: BFA503DC <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb1ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x18f8>
	v_dual_mov_b32 v17, 0 :: v_dual_lshlrev_b32 v4, 5, v10     // 000000527188: CA220080 11041485
	v_and_b32_e32 v22, 16, v0                                  // 000000527190: 362C0090
	v_cmp_ne_u32_e32 vcc_lo, 0, v10                            // 000000527194: 7C9A1480
	.long 0xd73c0002                                           // 000000527198: D73C0002
	v_cndmask_b32_e32 v1, 10, v1, vcc_lo                       // 00000052719C: 0202028A
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000005271A0: BF870244
	v_dual_mov_b32 v26, 0 :: v_dual_add_nc_u32 v5, 0x3f0, v4   // 0000005271A4: CA200080 1A0408FF 000003F0
	v_mad_u32_u24 v13, 0x420, v8, v9                           // 0000005271B0: D60B000D 042610FF 00000420
	v_mul_u32_u24_e32 v6, 0x420, v8                            // 0000005271BC: 160C10FF 00000420
	v_sub_nc_u32_e32 v27, 0, v7                                // 0000005271C4: 4C360E80
	v_lshrrev_b32_e32 v21, 5, v5                               // 0000005271C8: 322A0A85
	v_dual_mov_b32 v24, 0 :: v_dual_and_b32 v5, 0x7e0, v5      // 0000005271CC: CA240080 18040AFF 000007E0
	v_dual_mov_b32 v25, 0 :: v_dual_add_nc_u32 v30, 0x1400, v13// 0000005271D8: CA200080 191E1AFF 00001400
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000005271E4: BF870243
	v_subrev_nc_u32_e32 v23, 32, v21                           // 0000005271E8: 4E2E2AA0
	v_dual_mov_b32 v21, 0 :: v_dual_add_nc_u32 v28, 1, v1      // 0000005271EC: CA200080 151C0281
	v_lshl_or_b32 v29, v1, 5, v22                              // 0000005271F4: D656001D 04590B01
	v_sub_nc_u32_e32 v4, v5, v4                                // 0000005271FC: 4C080905
	v_cndmask_b32_e32 v1, 31, v23, vcc_lo                      // 000000527200: 02022E9F
	.long 0xd7006a02                                           // 000000527204: D7006A02
	v_cndmask_b32_e32 v1, s6, v2, vcc_lo                       // 000000527208: 02020406
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000052720C: BF870191
	v_add_co_ci_u32_e64 v3, null, s7, v3, vcc_lo               // 000000527210: D5207C03 01AA0607
	v_dual_mov_b32 v22, 0 :: v_dual_add_nc_u32 v13, 1, v1      // 000000527218: CA200080 160C0281
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000527220: BF870093
	.long 0xd7006a02                                           // 000000527224: D7006A02
	v_cndmask_b32_e32 v1, v2, v9, vcc_lo                       // 000000527228: 02021302
	v_add_co_ci_u32_e64 v3, null, 0, v3, vcc_lo                // 00000052722C: D5207C03 01AA0680
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000527234: BF870193
	v_and_b32_e32 v5, 31, v13                                  // 000000527238: 360A1A9F
	.long 0xd7006a02                                           // 00000052723C: D7006A02
	v_cndmask_b32_e32 v1, s20, v2, vcc_lo                      // 000000527240: 02020414
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000527244: BF8700D1
	v_add_co_ci_u32_e64 v3, null, s21, v3, vcc_lo              // 000000527248: D5207C03 01AA0615
	v_add_nc_u32_e32 v31, 0xfffffc30, v4                       // 000000527250: 4A3E08FF FFFFFC30
	v_lshl_add_u32 v1, v1, 2, v6                               // 000000527258: D6460001 04190501
	v_lshl_add_u32 v4, v5, 2, v6                               // 000000527260: D6460004 04190505
	.long 0xd7006a05                                           // 000000527268: D7006A05
	v_cndmask_b32_e32 v1, 0x400, v2, vcc_lo                    // 00000052726C: 020204FF 00000400
	v_add_co_ci_u32_e64 v6, null, 0, v3, vcc_lo                // 000000527274: D5207C06 01AA0680
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000052727C: BF870214
	v_dual_mov_b32 v23, 0 :: v_dual_add_nc_u32 v32, 0x1400, v1 // 000000527280: CA200080 172002FF 00001400
	v_add_nc_u32_e32 v33, 0x1400, v4                           // 00000052728C: 4A4208FF 00001400
	v_mov_b32_e32 v13, 0                                       // 000000527294: 7E1A0280
	s_mov_b32 s5, 0                                            // 000000527298: BE850080
	s_movk_i32 s6, 0x1eee                                      // 00000052729C: B0061EEE
	s_branch 882                                               // 0000005272A0: BFA00372 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb1ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x186c>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000005272A4: 8C7E007E
	ds_load_2addr_b32 v[34:35], v33 offset1:32                 // 0000005272A8: D8DC2000 22000021
	ds_load_2addr_b32 v[40:41], v30 offset1:32                 // 0000005272B0: D8DC2000 2800001E
	ds_load_2addr_b32 v[38:39], v32 offset1:32                 // 0000005272B8: D8DC2000 26000020
	ds_load_b128 v[1:4], v29                                   // 0000005272C0: DBFC0000 0100001D
	v_add_nc_u32_e32 v28, 1, v28                               // 0000005272C8: 4A383881
	.long 0xd7000005                                           // 0000005272CC: D7000005
	v_cndmask_b32_e32 v1, 0x400, v5, vcc_lo                    // 0000005272D0: 02020AFF 00000400
	v_add_nc_u32_e32 v29, 32, v29                              // 0000005272D8: 4A3A3AA0
	v_add_co_ci_u32_e64 v6, null, 0, v6, s0                    // 0000005272DC: D5207C06 00020C80
	s_waitcnt lgkmcnt(3)                                       // 0000005272E4: BF89FC37
	v_mov_b32_e32 v37, v34                                     // 0000005272E8: 7E4A0322
	s_waitcnt lgkmcnt(2)                                       // 0000005272EC: BF89FC27
	v_bfe_u32 v34, v40, 12, 16                                 // 0000005272F0: D6100022 02411928
	v_bfe_u32 v42, v40, 8, 16                                  // 0000005272F8: D610002A 02411128
	v_bfe_u32 v43, v40, 4, 16                                  // 000000527300: D610002B 02410928
	v_and_b32_e32 v40, 0xffff, v40                             // 000000527308: 365050FF 0000FFFF
	s_waitcnt lgkmcnt(1)                                       // 000000527310: BF89FC17
	v_mov_b32_e32 v36, v39                                     // 000000527314: 7E480327
	.long 0xd73d0025                                           // 000000527318: D73D0025
	v_cndmask_b32_e32 v1, v31, v37, vcc_lo                     // 00000052731C: 02024B1F
	v_bfe_u32 v39, v41, 12, 16                                 // 000000527320: D6100027 02411929
	v_bfe_u32 v44, v41, 8, 16                                  // 000000527328: D610002C 02411129
	v_bfe_u32 v45, v41, 4, 16                                  // 000000527330: D610002D 02410929
	v_and_b32_e32 v41, 0xffff, v41                             // 000000527338: 365252FF 0000FFFF
	.long 0xd72c0026                                           // 000000527340: D72C0026
	v_cndmask_b32_e32 v1, 0x83dcd12d, v34, vcc_lo              // 000000527344: 020244FF 83DCD12D
	.long 0xd73d0022                                           // 00000052734C: D73D0022
	v_cndmask_b32_e32 v1, v31, v35, vcc_lo                     // 000000527350: 0202471F
	v_bfe_u32 v35, v37, 12, 16                                 // 000000527354: D6100023 02411925
	.long 0xd72c0024                                           // 00000052735C: D72C0024
	v_cndmask_b32_e32 v1, 0x83dcd12d, v39, vcc_lo              // 000000527360: 02024EFF 83DCD12D
	v_bfe_u32 v39, v37, 8, 16                                  // 000000527368: D6100027 02411125
	.long 0xd72c0028                                           // 000000527370: D72C0028
	v_cndmask_b32_e32 v1, 0x83dcd12d, v40, vcc_lo              // 000000527374: 020250FF 83DCD12D
	.long 0xd72c002b                                           // 00000052737C: D72C002B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v43, vcc_lo              // 000000527380: 020256FF 83DCD12D
	.long 0xd72c0023                                           // 000000527388: D72C0023
	v_cndmask_b32_e32 v1, 0x83dcd12d, v35, vcc_lo              // 00000052738C: 020246FF 83DCD12D
	v_bfe_u32 v47, v34, 12, 16                                 // 000000527394: D610002F 02411922
	.long 0xd72c0027                                           // 00000052739C: D72C0027
	v_cndmask_b32_e32 v1, 0x83dcd12d, v39, vcc_lo              // 0000005273A0: 02024EFF 83DCD12D
	v_bfe_u32 v48, v34, 8, 16                                  // 0000005273A8: D6100030 02411122
	v_bfe_u32 v49, v34, 4, 16                                  // 0000005273B0: D6100031 02410922
	.long 0xd72c002c                                           // 0000005273B8: D72C002C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v44, vcc_lo              // 0000005273BC: 020258FF 83DCD12D
	v_sad_u8 v40, v40, 0, 0x6400                               // 0000005273C4: D6220028 03FD0128 00006400
	.long 0xd72c002f                                           // 0000005273D0: D72C002F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v47, vcc_lo              // 0000005273D4: 02025EFF 83DCD12D
	v_sad_u8 v35, v35, 0, 0x6400                               // 0000005273DC: D6220023 03FD0123 00006400
	v_sad_u8 v43, v43, 0, 0x6400                               // 0000005273E8: D622002B 03FD012B 00006400
	v_sad_u8 v39, v39, 0, 0x6400                               // 0000005273F4: D6220027 03FD0127 00006400
	v_lshlrev_b32_e32 v40, 16, v40                             // 000000527400: 30505090
	v_sad_u8 v36, v36, 0, 0x6400                               // 000000527404: D6220024 03FD0124 00006400
	v_and_b32_e32 v35, 0xffff, v35                             // 000000527410: 364646FF 0000FFFF
	v_bfe_u32 v46, v37, 4, 16                                  // 000000527418: D610002E 02410925
	v_sad_u8 v44, v44, 0, 0x6400                               // 000000527420: D622002C 03FD012C 00006400
	v_and_or_b32 v43, 0xffff, v43, v40                         // 00000052742C: D657002B 04A256FF 0000FFFF
	v_sad_u8 v40, v47, 0, 0x6400                               // 000000527438: D6220028 03FD012F 00006400
	v_lshl_or_b32 v35, v39, 16, v35                            // 000000527444: D6560023 048D2127
	v_and_b32_e32 v36, 0xffff, v36                             // 00000052744C: 364848FF 0000FFFF
	.long 0xd72c002a                                           // 000000527454: D72C002A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v42, vcc_lo              // 000000527458: 020254FF 83DCD12D
	v_sad_u8 v38, v38, 0, 0x6400                               // 000000527460: D6220026 03FD0126 00006400
	.long 0xd72c002e                                           // 00000052746C: D72C002E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v46, vcc_lo              // 000000527470: 02025CFF 83DCD12D
	v_pk_fma_f16 v47, v35, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000527478: CC0E002F 0BFC0D23 0000C931
	v_and_b32_e32 v34, 0xffff, v34                             // 000000527484: 364444FF 0000FFFF
	v_lshl_or_b32 v44, v44, 16, v36                            // 00000052748C: D656002C 0491212C
	.long 0xd72c0031                                           // 000000527494: D72C0031
	v_cndmask_b32_e32 v1, 0x83dcd12d, v49, vcc_lo              // 000000527498: 020262FF 83DCD12D
	s_waitcnt lgkmcnt(0)                                       // 0000005274A0: BF89FC07
	v_dual_dot2acc_f32_f16 v17, v47, v1 :: v_dual_and_b32 v38, 0xffff, v38// 0000005274A4: CB24032F 11264CFF 0000FFFF
	.long 0xd72c0022                                           // 0000005274B0: D72C0022
	v_cndmask_b32_e32 v1, 0x83dcd12d, v34, vcc_lo              // 0000005274B4: 020244FF 83DCD12D
	v_sad_u8 v42, v42, 0, 0x6400                               // 0000005274BC: D622002A 03FD012A 00006400
	.long 0xd72c0030                                           // 0000005274C8: D72C0030
	v_cndmask_b32_e32 v1, 0x83dcd12d, v48, vcc_lo              // 0000005274CC: 020260FF 83DCD12D
	.long 0xd72c0029                                           // 0000005274D4: D72C0029
	v_cndmask_b32_e32 v1, 0x83dcd12d, v41, vcc_lo              // 0000005274D8: 020252FF 83DCD12D
	.long 0xd72c002d                                           // 0000005274E0: D72C002D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v45, vcc_lo              // 0000005274E4: 02025AFF 83DCD12D
	v_sad_u8 v49, v49, 0, 0x6400                               // 0000005274EC: D6220031 03FD0131 00006400
	v_lshl_or_b32 v38, v42, 16, v38                            // 0000005274F8: D6560026 0499212A
	v_sad_u8 v42, v46, 0, 0x6400                               // 000000527500: D622002A 03FD012E 00006400
	v_sad_u8 v39, v34, 0, 0x6400                               // 00000052750C: D6220027 03FD0122 00006400
	ds_load_2addr_b32 v[34:35], v33 offset0:64 offset1:96      // 000000527518: D8DC6040 22000021
	v_and_b32_e32 v37, 0xffff, v37                             // 000000527520: 364A4AFF 0000FFFF
	v_sad_u8 v46, v48, 0, 0x6400                               // 000000527528: D622002E 03FD0130 00006400
	v_sad_u8 v41, v41, 0, 0x6400                               // 000000527534: D6220029 03FD0129 00006400
	v_lshlrev_b32_e32 v39, 16, v39                             // 000000527540: 304E4E90
	v_sad_u8 v45, v45, 0, 0x6400                               // 000000527544: D622002D 03FD012D 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000527550: BF870193
	v_lshlrev_b32_e32 v41, 16, v41                             // 000000527554: 30525290
	v_and_or_b32 v39, 0xffff, v49, v39                         // 000000527558: D6570027 049E62FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000527564: BF870112
	v_and_or_b32 v41, 0xffff, v45, v41                         // 000000527568: D6570029 04A65AFF 0000FFFF
	v_pk_fma_f16 v47, v39, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000527574: CC0E002F 0BFC0D27 0000C931
	v_and_b32_e32 v40, 0xffff, v40                             // 000000527580: 365050FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3)                            // 000000527588: BF870003
	v_pk_fma_f16 v41, v41, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000052758C: CC0E0029 0BFC0D29 0000C931
	s_waitcnt lgkmcnt(0)                                       // 000000527598: BF89FC07
	v_mov_b32_e32 v36, v34                                     // 00000052759C: 7E480322
	.long 0xd72c0025                                           // 0000005275A0: D72C0025
	v_cndmask_b32_e32 v1, 0x83dcd12d, v37, vcc_lo              // 0000005275A4: 02024AFF 83DCD12D
	v_lshl_or_b32 v40, v46, 16, v40                            // 0000005275AC: D6560028 04A1212E
	v_pk_fma_f16 v34, v44, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000005275B4: CC0E0022 0BFC0D2C 0000C931
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000005275C0: BF870142
	v_pk_fma_f16 v46, v40, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000005275C4: CC0E002E 0BFC0D28 0000C931
	ds_load_2addr_b32 v[39:40], v30 offset0:64 offset1:96      // 0000005275D0: D8DC6040 2700001E
	v_sad_u8 v37, v37, 0, 0x6400                               // 0000005275D8: D6220025 03FD0125 00006400
	v_dot2acc_f32_f16 v21, v46, v1                             // 0000005275E4: 042A032E
	v_lshlrev_b32_e32 v37, 16, v37                             // 0000005275E8: 304A4A90
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000005275EC: BF870112
	v_dot2acc_f32_f16 v21, v47, v2                             // 0000005275F0: 042A052F
	v_and_or_b32 v37, 0xffff, v42, v37                         // 0000005275F4: D6570025 049654FF 0000FFFF
	v_pk_fma_f16 v42, v38, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000527600: CC0E002A 0BFC0D26 0000C931
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000052760C: BF870193
	v_dot2acc_f32_f16 v21, v34, v3                             // 000000527610: 042A0722
	v_pk_fma_f16 v48, v37, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000527614: CC0E0030 0BFC0D25 0000C931
	ds_load_2addr_b32 v[37:38], v32 offset0:64 offset1:96      // 000000527620: D8DC6040 25000020
	s_waitcnt lgkmcnt(1)                                       // 000000527628: BF89FC17
	v_bfe_u32 v44, v39, 4, 16                                  // 00000052762C: D610002C 02410927
	v_dot2acc_f32_f16 v17, v48, v2                             // 000000527634: 04220530
	v_bfe_u32 v47, v40, 4, 16                                  // 000000527638: D610002F 02410928
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000527640: BF870193
	.long 0xd72c002c                                           // 000000527644: D72C002C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v44, vcc_lo              // 000000527648: 020258FF 83DCD12D
	v_dot2acc_f32_f16 v17, v42, v3                             // 000000527650: 0422072A
	s_waitcnt lgkmcnt(0)                                       // 000000527654: BF89FC07
	.long 0xd73d0024                                           // 000000527658: D73D0024
	v_cndmask_b32_e32 v1, v31, v36, vcc_lo                     // 00000052765C: 0202491F
	v_pk_fma_f16 v37, v43, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000527660: CC0E0025 0BFC0D2B 0000C931
	v_bfe_u32 v43, v39, 8, 16                                  // 00000052766C: D610002B 02411127
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000527674: BF8701A3
	v_bfe_u32 v34, v36, 12, 16                                 // 000000527678: D6100022 02411924
	v_bfe_u32 v42, v36, 8, 16                                  // 000000527680: D610002A 02411124
	.long 0xd72c002b                                           // 000000527688: D72C002B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v43, vcc_lo              // 00000052768C: 020256FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000527694: BF870193
	.long 0xd72c0022                                           // 000000527698: D72C0022
	v_cndmask_b32_e32 v1, 0x83dcd12d, v34, vcc_lo              // 00000052769C: 020244FF 83DCD12D
	.long 0xd72c002a                                           // 0000005276A4: D72C002A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v42, vcc_lo              // 0000005276A8: 020254FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000005276B0: BF870112
	v_sad_u8 v34, v34, 0, 0x6400                               // 0000005276B4: D6220022 03FD0122 00006400
	v_sad_u8 v42, v42, 0, 0x6400                               // 0000005276C0: D622002A 03FD012A 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000005276CC: BF8701B2
	v_dual_dot2acc_f32_f16 v21, v41, v4 :: v_dual_and_b32 v34, 0xffff, v34// 0000005276D0: CB240929 152244FF 0000FFFF
	v_bfe_u32 v41, v39, 12, 16                                 // 0000005276DC: D6100029 02411927
	v_and_b32_e32 v39, 0xffff, v39                             // 0000005276E4: 364E4EFF 0000FFFF
	v_lshl_or_b32 v42, v42, 16, v34                            // 0000005276EC: D656002A 0489212A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000005276F4: BF870193
	.long 0xd72c0029                                           // 0000005276F8: D72C0029
	v_cndmask_b32_e32 v1, 0x83dcd12d, v41, vcc_lo              // 0000005276FC: 020252FF 83DCD12D
	.long 0xd72c0027                                           // 000000527704: D72C0027
	v_cndmask_b32_e32 v1, 0x83dcd12d, v39, vcc_lo              // 000000527708: 02024EFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000527710: BF870112
	v_sad_u8 v41, v41, 0, 0x6400                               // 000000527714: D6220029 03FD0129 00006400
	v_sad_u8 v39, v39, 0, 0x6400                               // 000000527720: D6220027 03FD0127 00006400
	v_dot2acc_f32_f16 v17, v37, v4                             // 00000052772C: 04220925
	v_and_b32_e32 v37, 0xffff, v36                             // 000000527730: 364A48FF 0000FFFF
	v_bfe_u32 v36, v36, 4, 16                                  // 000000527738: D6100024 02410924
	v_and_b32_e32 v41, 0xffff, v41                             // 000000527740: 365252FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000527748: BF870193
	.long 0xd72c0025                                           // 00000052774C: D72C0025
	v_cndmask_b32_e32 v1, 0x83dcd12d, v37, vcc_lo              // 000000527750: 02024AFF 83DCD12D
	.long 0xd72c0024                                           // 000000527758: D72C0024
	v_cndmask_b32_e32 v1, 0x83dcd12d, v36, vcc_lo              // 00000052775C: 020248FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000527764: BF870112
	v_sad_u8 v37, v37, 0, 0x6400                               // 000000527768: D6220025 03FD0125 00006400
	v_sad_u8 v45, v36, 0, 0x6400                               // 000000527774: D622002D 03FD0124 00006400
	v_mov_b32_e32 v36, v38                                     // 000000527780: 7E480326
	v_sad_u8 v38, v43, 0, 0x6400                               // 000000527784: D6220026 03FD012B 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000527790: BF870194
	v_lshlrev_b32_e32 v37, 16, v37                             // 000000527794: 304A4A90
	.long 0xd73d0022                                           // 000000527798: D73D0022
	v_cndmask_b32_e32 v1, v31, v35, vcc_lo                     // 00000052779C: 0202471F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000005277A0: BF870223
	v_lshl_or_b32 v35, v38, 16, v41                            // 0000005277A4: D6560023 04A52126
	v_sad_u8 v36, v44, 0, 0x6400                               // 0000005277AC: D6220024 03FD012C 00006400
	v_and_or_b32 v37, 0xffff, v45, v37                         // 0000005277B8: D6570025 04965AFF 0000FFFF
	v_lshlrev_b32_e32 v38, 16, v39                             // 0000005277C4: 304C4E90
	v_pk_fma_f16 v39, v42, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000005277C8: CC0E0027 0BFC0D2A 0000C931
	v_bfe_u32 v41, v34, 12, 16                                 // 0000005277D4: D6100029 02411922
	v_pk_fma_f16 v42, v35, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000005277DC: CC0E002A 0BFC0D23 0000C931
	v_pk_fma_f16 v37, v37, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000005277E8: CC0E0025 0BFC0D25 0000C931
	v_and_or_b32 v35, 0xffff, v36, v38                         // 0000005277F4: D6570023 049A48FF 0000FFFF
	v_dot2acc_f32_f16 v26, v39, v1                             // 000000527800: 04340327
	v_bfe_u32 v36, v34, 8, 16                                  // 000000527804: D6100024 02411122
	.long 0xd72c0026                                           // 00000052780C: D72C0026
	v_cndmask_b32_e32 v1, 0x83dcd12d, v41, vcc_lo              // 000000527810: 020252FF 83DCD12D
	v_and_b32_e32 v39, 0xffff, v34                             // 000000527818: 364E44FF 0000FFFF
	v_pk_fma_f16 v41, v35, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000527820: CC0E0029 0BFC0D23 0000C931
	v_dot2acc_f32_f16 v26, v37, v2                             // 00000052782C: 04340525
	v_bfe_u32 v37, v34, 4, 16                                  // 000000527830: D6100025 02410922
	ds_load_2addr_b32 v[34:35], v33 offset0:128 offset1:160    // 000000527838: D8DCA080 22000021
	.long 0xd72c0024                                           // 000000527840: D72C0024
	v_cndmask_b32_e32 v1, 0x83dcd12d, v36, vcc_lo              // 000000527844: 020248FF 83DCD12D
	.long 0xd72c0027                                           // 00000052784C: D72C0027
	v_cndmask_b32_e32 v1, 0x83dcd12d, v39, vcc_lo              // 000000527850: 02024EFF 83DCD12D
	v_sad_u8 v43, v38, 0, 0x6400                               // 000000527858: D622002B 03FD0126 00006400
	.long 0xd72c002e                                           // 000000527864: D72C002E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v37, vcc_lo              // 000000527868: 02024AFF 83DCD12D
	ds_load_2addr_b32 v[37:38], v32 offset0:128 offset1:160    // 000000527870: D8DCA080 25000020
	v_bfe_u32 v44, v40, 12, 16                                 // 000000527878: D610002C 02411928
	v_bfe_u32 v45, v40, 8, 16                                  // 000000527880: D610002D 02411128
	v_and_b32_e32 v43, 0xffff, v43                             // 000000527888: 365656FF 0000FFFF
	v_sad_u8 v36, v36, 0, 0x6400                               // 000000527890: D6220024 03FD0124 00006400
	v_sad_u8 v39, v39, 0, 0x6400                               // 00000052789C: D6220027 03FD0127 00006400
	.long 0xd72c002c                                           // 0000005278A8: D72C002C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v44, vcc_lo              // 0000005278AC: 020258FF 83DCD12D
	.long 0xd72c002d                                           // 0000005278B4: D72C002D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v45, vcc_lo              // 0000005278B8: 02025AFF 83DCD12D
	v_dot2acc_f32_f16 v26, v42, v3                             // 0000005278C0: 0434072A
	v_lshl_or_b32 v36, v36, 16, v43                            // 0000005278C4: D6560024 04AD2124
	v_sad_u8 v43, v46, 0, 0x6400                               // 0000005278CC: D622002B 03FD012E 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000005278D8: BF870193
	v_dual_dot2acc_f32_f16 v26, v41, v4 :: v_dual_lshlrev_b32 v39, 16, v39// 0000005278DC: CB220929 1A264E90
	v_pk_fma_f16 v46, v36, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000005278E4: CC0E002E 0BFC0D24 0000C931
	s_waitcnt lgkmcnt(1)                                       // 0000005278F0: BF89FC17
	v_mov_b32_e32 v36, v34                                     // 0000005278F4: 7E480322
	v_sad_u8 v44, v44, 0, 0x6400                               // 0000005278F8: D622002C 03FD012C 00006400
	v_and_or_b32 v43, 0xffff, v43, v39                         // 000000527904: D657002B 049E56FF 0000FFFF
	v_dual_dot2acc_f32_f16 v25, v46, v1 :: v_dual_and_b32 v40, 0xffff, v40// 000000527910: CB24032E 192850FF 0000FFFF
	s_waitcnt lgkmcnt(0)                                       // 00000052791C: BF89FC07
	.long 0xd73d0024                                           // 000000527920: D73D0024
	v_cndmask_b32_e32 v1, v31, v36, vcc_lo                     // 000000527924: 0202491F
	v_sad_u8 v45, v45, 0, 0x6400                               // 000000527928: D622002D 03FD012D 00006400
	v_pk_fma_f16 v37, v43, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000527934: CC0E0025 0BFC0D2B 0000C931
	v_and_b32_e32 v44, 0xffff, v44                             // 000000527940: 365858FF 0000FFFF
	.long 0xd72c0028                                           // 000000527948: D72C0028
	v_cndmask_b32_e32 v1, 0x83dcd12d, v40, vcc_lo              // 00000052794C: 020250FF 83DCD12D
	.long 0xd72c0022                                           // 000000527954: D72C0022
	v_cndmask_b32_e32 v1, 0x83dcd12d, v47, vcc_lo              // 000000527958: 02025EFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000527960: BF870214
	v_dot2acc_f32_f16 v25, v37, v2                             // 000000527964: 04320525
	v_lshl_or_b32 v43, v45, 16, v44                            // 000000527968: D656002B 04B1212D
	v_bfe_u32 v45, v36, 12, 16                                 // 000000527970: D610002D 02411924
	v_sad_u8 v47, v40, 0, 0x6400                               // 000000527978: D622002F 03FD0128 00006400
	ds_load_2addr_b32 v[39:40], v30 offset0:128 offset1:160    // 000000527984: D8DCA080 2700001E
	v_pk_fma_f16 v42, v43, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000052798C: CC0E002A 0BFC0D2B 0000C931
	v_sad_u8 v34, v34, 0, 0x6400                               // 000000527998: D6220022 03FD0122 00006400
	.long 0xd72c0025                                           // 0000005279A4: D72C0025
	v_cndmask_b32_e32 v1, 0x83dcd12d, v45, vcc_lo              // 0000005279A8: 02025AFF 83DCD12D
	v_bfe_u32 v43, v36, 8, 16                                  // 0000005279B0: D610002B 02411124
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000005279B8: BF8701A4
	v_dot2acc_f32_f16 v25, v42, v3                             // 0000005279BC: 0432072A
	v_lshlrev_b32_e32 v44, 16, v47                             // 0000005279C0: 30585E90
	.long 0xd72c002a                                           // 0000005279C4: D72C002A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v43, vcc_lo              // 0000005279C8: 020256FF 83DCD12D
	v_sad_u8 v37, v37, 0, 0x6400                               // 0000005279D0: D6220025 03FD0125 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000005279DC: BF870113
	v_and_or_b32 v34, 0xffff, v34, v44                         // 0000005279E0: D6570022 04B244FF 0000FFFF
	v_and_b32_e32 v37, 0xffff, v37                             // 0000005279EC: 364A4AFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_2)                            // 0000005279F4: BF870002
	v_pk_fma_f16 v41, v34, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000005279F8: CC0E0029 0BFC0D22 0000C931
	v_bfe_u32 v34, v36, 4, 16                                  // 000000527A04: D6100022 02410924
	v_and_b32_e32 v36, 0xffff, v36                             // 000000527A0C: 364848FF 0000FFFF
	s_waitcnt lgkmcnt(0)                                       // 000000527A14: BF89FC07
	v_bfe_u32 v43, v39, 12, 16                                 // 000000527A18: D610002B 02411927
	v_and_b32_e32 v45, 0xffff, v39                             // 000000527A20: 365A4EFF 0000FFFF
	v_bfe_u32 v44, v39, 8, 16                                  // 000000527A28: D610002C 02411127
	.long 0xd72c0022                                           // 000000527A30: D72C0022
	v_cndmask_b32_e32 v1, 0x83dcd12d, v34, vcc_lo              // 000000527A34: 020244FF 83DCD12D
	.long 0xd72c0024                                           // 000000527A3C: D72C0024
	v_cndmask_b32_e32 v1, 0x83dcd12d, v36, vcc_lo              // 000000527A40: 020248FF 83DCD12D
	.long 0xd72c002b                                           // 000000527A48: D72C002B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v43, vcc_lo              // 000000527A4C: 020256FF 83DCD12D
	.long 0xd72c002d                                           // 000000527A54: D72C002D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v45, vcc_lo              // 000000527A58: 02025AFF 83DCD12D
	v_sad_u8 v42, v42, 0, 0x6400                               // 000000527A60: D622002A 03FD012A 00006400
	v_bfe_u32 v39, v39, 4, 16                                  // 000000527A6C: D6100027 02410927
	v_dot2acc_f32_f16 v25, v41, v4                             // 000000527A74: 04320929
	v_sad_u8 v36, v36, 0, 0x6400                               // 000000527A78: D6220024 03FD0124 00006400
	s_delay_alu instid0(VALU_DEP_4)                            // 000000527A84: BF870004
	v_lshl_or_b32 v37, v42, 16, v37                            // 000000527A88: D6560025 0495212A
	.long 0xd72c002a                                           // 000000527A90: D72C002A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v44, vcc_lo              // 000000527A94: 020258FF 83DCD12D
	.long 0xd72c0027                                           // 000000527A9C: D72C0027
	v_cndmask_b32_e32 v1, 0x83dcd12d, v39, vcc_lo              // 000000527AA0: 02024EFF 83DCD12D
	v_sad_u8 v43, v43, 0, 0x6400                               // 000000527AA8: D622002B 03FD012B 00006400
	v_sad_u8 v44, v34, 0, 0x6400                               // 000000527AB4: D622002C 03FD0122 00006400
	v_lshlrev_b32_e32 v46, 16, v36                             // 000000527AC0: 305C4890
	v_sad_u8 v34, v45, 0, 0x6400                               // 000000527AC4: D6220022 03FD012D 00006400
	v_mov_b32_e32 v36, v38                                     // 000000527AD0: 7E480326
	v_and_b32_e32 v38, 0xffff, v43                             // 000000527AD4: 364C56FF 0000FFFF
	v_sad_u8 v42, v42, 0, 0x6400                               // 000000527ADC: D622002A 03FD012A 00006400
	v_sad_u8 v39, v39, 0, 0x6400                               // 000000527AE8: D6220027 03FD0127 00006400
	v_lshlrev_b32_e32 v43, 16, v34                             // 000000527AF4: 30564490
	.long 0xd73d0022                                           // 000000527AF8: D73D0022
	v_cndmask_b32_e32 v1, v31, v35, vcc_lo                     // 000000527AFC: 0202471F
	v_pk_fma_f16 v36, v37, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000527B00: CC0E0024 0BFC0D25 0000C931
	v_lshl_or_b32 v37, v42, 16, v38                            // 000000527B0C: D6560025 0499212A
	v_and_or_b32 v35, 0xffff, v44, v46                         // 000000527B14: D6570023 04BA58FF 0000FFFF
	v_and_or_b32 v38, 0xffff, v39, v43                         // 000000527B20: D6570026 04AE4EFF 0000FFFF
	v_bfe_u32 v43, v40, 8, 16                                  // 000000527B2C: D610002B 02411128
	v_bfe_u32 v39, v34, 12, 16                                 // 000000527B34: D6100027 02411922
	v_dot2acc_f32_f16 v24, v36, v1                             // 000000527B3C: 04300324
	v_pk_fma_f16 v41, v37, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000527B40: CC0E0029 0BFC0D25 0000C931
	v_bfe_u32 v37, v34, 8, 16                                  // 000000527B4C: D6100025 02411122
	v_pk_fma_f16 v35, v35, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000527B54: CC0E0023 0BFC0D23 0000C931
	.long 0xd72c0024                                           // 000000527B60: D72C0024
	v_cndmask_b32_e32 v1, 0x83dcd12d, v39, vcc_lo              // 000000527B64: 02024EFF 83DCD12D
	v_pk_fma_f16 v42, v38, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000527B6C: CC0E002A 0BFC0D26 0000C931
	v_bfe_u32 v38, v34, 4, 16                                  // 000000527B78: D6100026 02410922
	v_and_b32_e32 v34, 0xffff, v34                             // 000000527B80: 364444FF 0000FFFF
	.long 0xd72c0025                                           // 000000527B88: D72C0025
	v_cndmask_b32_e32 v1, 0x83dcd12d, v37, vcc_lo              // 000000527B8C: 02024AFF 83DCD12D
	v_dot2acc_f32_f16 v24, v35, v2                             // 000000527B94: 04300523
	v_bfe_u32 v39, v40, 12, 16                                 // 000000527B98: D6100027 02411928
	v_bfe_u32 v44, v40, 4, 16                                  // 000000527BA0: D610002C 02410928
	v_sad_u8 v36, v36, 0, 0x6400                               // 000000527BA8: D6220024 03FD0124 00006400
	.long 0xd72c002d                                           // 000000527BB4: D72C002D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v34, vcc_lo              // 000000527BB8: 020244FF 83DCD12D
	ds_load_2addr_b32 v[34:35], v33 offset0:192 offset1:224    // 000000527BC0: D8DCE0C0 22000021
	v_and_b32_e32 v40, 0xffff, v40                             // 000000527BC8: 365050FF 0000FFFF
	v_sad_u8 v46, v37, 0, 0x6400                               // 000000527BD0: D622002E 03FD0125 00006400
	v_and_b32_e32 v36, 0xffff, v36                             // 000000527BDC: 364848FF 0000FFFF
	.long 0xd72c002f                                           // 000000527BE4: D72C002F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v38, vcc_lo              // 000000527BE8: 02024CFF 83DCD12D
	ds_load_2addr_b32 v[37:38], v32 offset0:192 offset1:224    // 000000527BF0: D8DCE0C0 25000020
	.long 0xd72c0028                                           // 000000527BF8: D72C0028
	v_cndmask_b32_e32 v1, 0x83dcd12d, v40, vcc_lo              // 000000527BFC: 020250FF 83DCD12D
	.long 0xd72c0027                                           // 000000527C04: D72C0027
	v_cndmask_b32_e32 v1, 0x83dcd12d, v39, vcc_lo              // 000000527C08: 02024EFF 83DCD12D
	v_lshl_or_b32 v46, v46, 16, v36                            // 000000527C10: D656002E 0491212E
	v_sad_u8 v36, v45, 0, 0x6400                               // 000000527C18: D6220024 03FD012D 00006400
	.long 0xd72c002b                                           // 000000527C24: D72C002B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v43, vcc_lo              // 000000527C28: 020256FF 83DCD12D
	.long 0xd72c002c                                           // 000000527C30: D72C002C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v44, vcc_lo              // 000000527C34: 020258FF 83DCD12D
	v_sad_u8 v47, v47, 0, 0x6400                               // 000000527C3C: D622002F 03FD012F 00006400
	v_dot2acc_f32_f16 v24, v41, v3                             // 000000527C48: 04300729
	v_lshlrev_b32_e32 v48, 16, v36                             // 000000527C4C: 30604890
	v_sad_u8 v36, v40, 0, 0x6400                               // 000000527C50: D6220024 03FD0128 00006400
	v_sad_u8 v45, v39, 0, 0x6400                               // 000000527C5C: D622002D 03FD0127 00006400
	ds_load_2addr_b32 v[39:40], v30 offset0:192 offset1:224    // 000000527C68: D8DCE0C0 2700001E
	v_sad_u8 v43, v43, 0, 0x6400                               // 000000527C70: D622002B 03FD012B 00006400
	v_sad_u8 v44, v44, 0, 0x6400                               // 000000527C7C: D622002C 03FD012C 00006400
	s_waitcnt lgkmcnt(2)                                       // 000000527C88: BF89FC27
	v_dual_mov_b32 v36, v34 :: v_dual_lshlrev_b32 v49, 16, v36 // 000000527C8C: CA220122 24304890
	v_dual_dot2acc_f32_f16 v24, v42, v4 :: v_dual_and_b32 v45, 0xffff, v45// 000000527C94: CB24092A 182C5AFF 0000FFFF
	v_and_or_b32 v34, 0xffff, v47, v48                         // 000000527CA0: D6570022 04C25EFF 0000FFFF
	v_pk_fma_f16 v46, v46, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000527CAC: CC0E002E 0BFC0D2E 0000C931
	s_waitcnt lgkmcnt(1)                                       // 000000527CB8: BF89FC17
	.long 0xd73d0024                                           // 000000527CBC: D73D0024
	v_cndmask_b32_e32 v1, v31, v36, vcc_lo                     // 000000527CC0: 0202491F
	v_lshl_or_b32 v43, v43, 16, v45                            // 000000527CC4: D656002B 04B5212B
	v_and_or_b32 v44, 0xffff, v44, v49                         // 000000527CCC: D657002C 04C658FF 0000FFFF
	v_pk_fma_f16 v34, v34, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000527CD8: CC0E0022 0BFC0D22 0000C931
	v_dot2acc_f32_f16 v23, v46, v1                             // 000000527CE4: 042E032E
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000527CE8: BF870234
	v_pk_fma_f16 v37, v43, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000527CEC: CC0E0025 0BFC0D2B 0000C931
	v_bfe_u32 v43, v36, 12, 16                                 // 000000527CF8: D610002B 02411924
	v_pk_fma_f16 v41, v44, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000527D00: CC0E0029 0BFC0D2C 0000C931
	v_dual_dot2acc_f32_f16 v23, v34, v2 :: v_dual_and_b32 v34, 0xffff, v36// 000000527D0C: CB240522 172248FF 0000FFFF
	v_bfe_u32 v44, v36, 8, 16                                  // 000000527D18: D610002C 02411124
	s_delay_alu instid0(VALU_DEP_4)                            // 000000527D20: BF870004
	.long 0xd72c002b                                           // 000000527D24: D72C002B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v43, vcc_lo              // 000000527D28: 020256FF 83DCD12D
	s_waitcnt lgkmcnt(0)                                       // 000000527D30: BF89FC07
	v_bfe_u32 v45, v39, 12, 16                                 // 000000527D34: D610002D 02411927
	v_bfe_u32 v36, v36, 4, 16                                  // 000000527D3C: D6100024 02410924
	.long 0xd72c0022                                           // 000000527D44: D72C0022
	v_cndmask_b32_e32 v1, 0x83dcd12d, v34, vcc_lo              // 000000527D48: 020244FF 83DCD12D
	.long 0xd72c002c                                           // 000000527D50: D72C002C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v44, vcc_lo              // 000000527D54: 020258FF 83DCD12D
	v_bfe_u32 v46, v39, 8, 16                                  // 000000527D5C: D610002E 02411127
	.long 0xd72c002d                                           // 000000527D64: D72C002D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v45, vcc_lo              // 000000527D68: 02025AFF 83DCD12D
	.long 0xd72c0024                                           // 000000527D70: D72C0024
	v_cndmask_b32_e32 v1, 0x83dcd12d, v36, vcc_lo              // 000000527D74: 020248FF 83DCD12D
	v_sad_u8 v43, v43, 0, 0x6400                               // 000000527D7C: D622002B 03FD012B 00006400
	v_dot2acc_f32_f16 v23, v37, v3                             // 000000527D88: 042E0725
	.long 0xd72c002e                                           // 000000527D8C: D72C002E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v46, vcc_lo              // 000000527D90: 02025CFF 83DCD12D
	v_sad_u8 v34, v34, 0, 0x6400                               // 000000527D98: D6220022 03FD0122 00006400
	v_sad_u8 v44, v44, 0, 0x6400                               // 000000527DA4: D622002C 03FD012C 00006400
	v_and_b32_e32 v43, 0xffff, v43                             // 000000527DB0: 365656FF 0000FFFF
	v_sad_u8 v45, v45, 0, 0x6400                               // 000000527DB8: D622002D 03FD012D 00006400
	v_sad_u8 v48, v36, 0, 0x6400                               // 000000527DC4: D6220030 03FD0124 00006400
	v_dual_dot2acc_f32_f16 v23, v41, v4 :: v_dual_lshlrev_b32 v34, 16, v34// 000000527DD0: CB220929 17224490
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000527DD8: BF870214
	v_lshl_or_b32 v43, v44, 16, v43                            // 000000527DDC: D656002B 04AD212C
	v_dual_mov_b32 v36, v38 :: v_dual_and_b32 v45, 0xffff, v45 // 000000527DE4: CA240126 242C5AFF 0000FFFF
	v_sad_u8 v38, v46, 0, 0x6400                               // 000000527DF0: D6220026 03FD012E 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000527DFC: BF870214
	v_and_or_b32 v44, 0xffff, v48, v34                         // 000000527E00: D657002C 048A60FF 0000FFFF
	v_pk_fma_f16 v37, v43, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000527E0C: CC0E0025 0BFC0D2B 0000C931
	s_delay_alu instid0(VALU_DEP_4)                            // 000000527E18: BF870004
	.long 0xd73d0022                                           // 000000527E1C: D73D0022
	v_cndmask_b32_e32 v1, v31, v35, vcc_lo                     // 000000527E20: 0202471F
	v_bfe_u32 v47, v39, 4, 16                                  // 000000527E24: D610002F 02410927
	v_lshl_or_b32 v35, v38, 16, v45                            // 000000527E2C: D6560023 04B52126
	v_pk_fma_f16 v38, v44, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000527E34: CC0E0026 0BFC0D2C 0000C931
	v_dot2acc_f32_f16 v22, v37, v1                             // 000000527E40: 042C0325
	v_bfe_u32 v48, v40, 4, 16                                  // 000000527E44: D6100030 02410928
	.long 0xd72c002e                                           // 000000527E4C: D72C002E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v47, vcc_lo              // 000000527E50: 02025EFF 83DCD12D
	v_pk_fma_f16 v35, v35, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000527E58: CC0E0023 0BFC0D23 0000C931
	v_and_b32_e32 v44, 0xffff, v34                             // 000000527E64: 365844FF 0000FFFF
	v_dot2acc_f32_f16 v22, v38, v2                             // 000000527E6C: 042C0526
	v_bfe_u32 v45, v34, 8, 16                                  // 000000527E70: D610002D 02411122
	v_bfe_u32 v47, v40, 8, 16                                  // 000000527E78: D610002F 02411128
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000527E80: BF870214
	.long 0xd72c002c                                           // 000000527E84: D72C002C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v44, vcc_lo              // 000000527E88: 020258FF 83DCD12D
	v_dot2acc_f32_f16 v22, v35, v3                             // 000000527E90: 042C0723
	v_and_b32_e32 v39, 0xffff, v39                             // 000000527E94: 364E4EFF 0000FFFF
	v_sad_u8 v43, v46, 0, 0x6400                               // 000000527E9C: D622002B 03FD012E 00006400
	v_bfe_u32 v46, v40, 12, 16                                 // 000000527EA8: D610002E 02411928
	.long 0xd72c002d                                           // 000000527EB0: D72C002D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v45, vcc_lo              // 000000527EB4: 02025AFF 83DCD12D
	v_and_b32_e32 v40, 0xffff, v40                             // 000000527EBC: 365050FF 0000FFFF
	.long 0xd72c0024                                           // 000000527EC4: D72C0024
	v_cndmask_b32_e32 v1, 0x83dcd12d, v39, vcc_lo              // 000000527EC8: 02024EFF 83DCD12D
	v_bfe_u32 v39, v34, 12, 16                                 // 000000527ED0: D6100027 02411922
	v_bfe_u32 v34, v34, 4, 16                                  // 000000527ED8: D6100022 02410922
	.long 0xd72c002e                                           // 000000527EE0: D72C002E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v46, vcc_lo              // 000000527EE4: 02025CFF 83DCD12D
	v_sad_u8 v44, v44, 0, 0x6400                               // 000000527EEC: D622002C 03FD012C 00006400
	.long 0xd72c002f                                           // 000000527EF8: D72C002F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v47, vcc_lo              // 000000527EFC: 02025EFF 83DCD12D
	.long 0xd72c0027                                           // 000000527F04: D72C0027
	v_cndmask_b32_e32 v1, 0x83dcd12d, v39, vcc_lo              // 000000527F08: 02024EFF 83DCD12D
	.long 0xd72c0022                                           // 000000527F10: D72C0022
	v_cndmask_b32_e32 v1, 0x83dcd12d, v34, vcc_lo              // 000000527F14: 020244FF 83DCD12D
	v_sad_u8 v45, v45, 0, 0x6400                               // 000000527F1C: D622002D 03FD012D 00006400
	v_lshlrev_b32_e32 v44, 16, v44                             // 000000527F28: 30585890
	.long 0xd72c0028                                           // 000000527F2C: D72C0028
	v_cndmask_b32_e32 v1, 0x83dcd12d, v40, vcc_lo              // 000000527F30: 020250FF 83DCD12D
	v_sad_u8 v46, v46, 0, 0x6400                               // 000000527F38: D622002E 03FD012E 00006400
	v_sad_u8 v36, v36, 0, 0x6400                               // 000000527F44: D6220024 03FD0124 00006400
	v_sad_u8 v39, v39, 0, 0x6400                               // 000000527F50: D6220027 03FD0127 00006400
	v_sad_u8 v34, v34, 0, 0x6400                               // 000000527F5C: D6220022 03FD0122 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000527F68: BF870223
	v_lshlrev_b32_e32 v36, 16, v36                             // 000000527F6C: 30484890
	v_sad_u8 v37, v40, 0, 0x6400                               // 000000527F70: D6220025 03FD0128 00006400
	v_and_b32_e32 v39, 0xffff, v39                             // 000000527F7C: 364E4EFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000527F84: BF870224
	v_and_or_b32 v34, 0xffff, v34, v44                         // 000000527F88: D6570022 04B244FF 0000FFFF
	.long 0xd72c002c                                           // 000000527F94: D72C002C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v48, vcc_lo              // 000000527F98: 020260FF 83DCD12D
	v_lshlrev_b32_e32 v37, 16, v37                             // 000000527FA0: 304A4A90
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000527FA4: BF870244
	v_lshl_or_b32 v39, v45, 16, v39                            // 000000527FA8: D6560027 049D212D
	v_and_b32_e32 v45, 0xffff, v46                             // 000000527FB0: 365A5CFF 0000FFFF
	v_sad_u8 v46, v47, 0, 0x6400                               // 000000527FB8: D622002E 03FD012F 00006400
	v_pk_fma_f16 v34, v34, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000527FC4: CC0E0022 0BFC0D22 0000C931
	v_pk_fma_f16 v39, v39, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000527FD0: CC0E0027 0BFC0D27 0000C931
	v_sad_u8 v44, v44, 0, 0x6400                               // 000000527FDC: D622002C 03FD012C 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000527FE8: BF870194
	v_lshl_or_b32 v40, v46, 16, v45                            // 000000527FEC: D6560028 04B5212E
	v_dot2acc_f32_f16 v13, v39, v1                             // 000000527FF4: 041A0327
	v_and_or_b32 v1, 0xffff, v43, v36                          // 000000527FF8: D6570001 049256FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000528004: BF870223
	v_pk_fma_f16 v36, v40, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000528008: CC0E0024 0BFC0D28 0000C931
	v_and_or_b32 v37, 0xffff, v44, v37                         // 000000528014: D6570025 049658FF 0000FFFF
	v_dot2acc_f32_f16 v13, v34, v2                             // 000000528020: 041A0522
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000528024: BF870194
	v_pk_fma_f16 v1, v1, s6, 0xc931 op_sel_hi:[1,0,0]          // 000000528028: CC0E0001 0BFC0D01 0000C931
	v_pk_fma_f16 v2, v37, s6, 0xc931 op_sel_hi:[1,0,0]         // 000000528034: CC0E0002 0BFC0D25 0000C931
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000528040: BF870223
	v_dot2acc_f32_f16 v13, v36, v3                             // 000000528044: 041A0724
	v_add_nc_u32_e32 v3, v27, v28                              // 000000528048: 4A06391B
	v_dot2acc_f32_f16 v22, v1, v4                              // 00000052804C: 042C0901
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000528050: BF870193
	v_dot2acc_f32_f16 v13, v2, v4                              // 000000528054: 041A0902
	v_cmp_eq_u32_e32 vcc_lo, 1, v3                             // 000000528058: 7C940681
	s_or_b32 s5, vcc_lo, s5                                    // 00000052805C: 8C05056A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000528060: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s5                        // 000000528064: 917E057E
	s_cbranch_execz 34                                         // 000000528068: BFA50022 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb1ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x18f4>
	s_mov_b32 s0, exec_lo                                      // 00000052806C: BE80007E
	s_waitcnt vmcnt(6)                                         // 000000528070: BF891BF7
	ds_store_2addr_b32 v30, v11, v12 offset1:32                // 000000528074: D8382000 000C0B1E
	s_waitcnt vmcnt(4)                                         // 00000052807C: BF8913F7
	ds_store_2addr_b32 v30, v14, v15 offset0:64 offset1:96     // 000000528080: D8386040 000F0E1E
	s_waitcnt vmcnt(2)                                         // 000000528088: BF890BF7
	ds_store_2addr_b32 v30, v16, v18 offset0:128 offset1:160   // 00000052808C: D838A080 0012101E
	s_waitcnt vmcnt(0)                                         // 000000528094: BF8903F7
	ds_store_2addr_b32 v30, v19, v20 offset0:192 offset1:224   // 000000528098: D838E0C0 0014131E
	.long 0xd4c1007e                                           // 0000005280A0: D4C1007E
	v_cndmask_b32_e32 v1, v28, v7, vcc_lo                      // 0000005280A4: 02020F1C
	s_cbranch_execz 64638                                      // 0000005280A8: BFA5FC7E <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb1ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0xaa4>
	s_clause 0x7                                               // 0000005280AC: BF850007
	global_load_b32 v11, v[5:6], off                           // 0000005280B0: DC520000 0B7C0005
	global_load_b32 v12, v[5:6], off offset:128                // 0000005280B8: DC520080 0C7C0005
	global_load_b32 v14, v[5:6], off offset:256                // 0000005280C0: DC520100 0E7C0005
	global_load_b32 v15, v[5:6], off offset:384                // 0000005280C8: DC520180 0F7C0005
	global_load_b32 v16, v[5:6], off offset:512                // 0000005280D0: DC520200 107C0005
	global_load_b32 v18, v[5:6], off offset:640                // 0000005280D8: DC520280 127C0005
	global_load_b32 v19, v[5:6], off offset:768                // 0000005280E0: DC520300 137C0005
	global_load_b32 v20, v[5:6], off offset:896                // 0000005280E8: DC520380 147C0005
	s_branch 64620                                             // 0000005280F0: BFA0FC6C <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb1ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0xaa4>
	s_or_b32 exec_lo, exec_lo, s5                              // 0000005280F4: 8C7E057E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000005280F8: BF870009
	s_or_b32 exec_lo, exec_lo, s1                              // 0000005280FC: 8C7E017E
	v_dual_mov_b32 v1, v17 :: v_dual_mov_b32 v4, v24           // 000000528100: CA100111 01040118
	v_dual_mov_b32 v2, v21 :: v_dual_mov_b32 v3, v26           // 000000528108: CA100115 0202011A
	v_dual_mov_b32 v7, v25 :: v_dual_mov_b32 v6, v22           // 000000528110: CA100119 07060116
	v_mov_b32_e32 v5, v23                                      // 000000528118: 7E0A0317
	s_waitcnt vmcnt(7)                                         // 00000052811C: BF891FF7
	v_mov_b32_e32 v11, v13                                     // 000000528120: 7E16030D
	s_mov_b32 s0, 0x76543210                                   // 000000528124: BE8000FF 76543210
	s_waitcnt vmcnt(0)                                         // 00000052812C: BF8903F7
	v_permlanex16_b32 v1, v1, s0, 0xfedcba98                   // 000000528130: D65C0001 03FC0101 FEDCBA98
	v_permlanex16_b32 v2, v2, s0, 0xfedcba98                   // 00000052813C: D65C0002 03FC0102 FEDCBA98
	v_permlanex16_b32 v3, v3, s0, 0xfedcba98                   // 000000528148: D65C0003 03FC0103 FEDCBA98
	v_permlanex16_b32 v7, v7, s0, 0xfedcba98                   // 000000528154: D65C0007 03FC0107 FEDCBA98
	v_permlanex16_b32 v4, v4, s0, 0xfedcba98                   // 000000528160: D65C0004 03FC0104 FEDCBA98
	v_permlanex16_b32 v5, v5, s0, 0xfedcba98                   // 00000052816C: D65C0005 03FC0105 FEDCBA98
	v_permlanex16_b32 v6, v6, s0, 0xfedcba98                   // 000000528178: D65C0006 03FC0106 FEDCBA98
	v_permlanex16_b32 v11, v11, s0, 0xfedcba98                 // 000000528184: D65C000B 03FC010B FEDCBA98
	.long 0xd44c0000                                           // 000000528190: D44C0000
	v_cndmask_b32_e32 v1, 16, v10, vcc_lo                      // 000000528194: 02021490
	s_barrier                                                  // 000000528198: BFBD0000
	buffer_gl0_inv                                             // 00000052819C: E0AC0000 00000000
	s_and_saveexec_b32 s1, s0                                  // 0000005281A4: BE812000
	s_cbranch_execz 18                                         // 0000005281A8: BFA50012 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb1ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x19f4>
	v_dual_add_f32 v1, v17, v1 :: v_dual_add_f32 v4, v24, v4   // 0000005281AC: C9080311 01040918
	v_dual_add_f32 v2, v21, v2 :: v_dual_add_f32 v3, v26, v3   // 0000005281B4: C9080515 0202071A
	v_lshl_or_b32 v9, v8, 9, v9                                // 0000005281BC: D6560009 04251308
	v_dual_add_f32 v7, v25, v7 :: v_dual_add_f32 v6, v22, v6   // 0000005281C4: C9080F19 07060D16
	v_dual_add_f32 v10, v13, v11 :: v_dual_add_f32 v5, v23, v5 // 0000005281CC: C908170D 0A040B17
	ds_store_2addr_b32 v9, v1, v2 offset1:16                   // 0000005281D4: D8381000 00020109
	ds_store_2addr_b32 v9, v3, v7 offset0:32 offset1:48        // 0000005281DC: D8383020 00070309
	ds_store_2addr_b32 v9, v4, v5 offset0:64 offset1:80        // 0000005281E4: D8385040 00050409
	ds_store_2addr_b32 v9, v6, v10 offset0:96 offset1:112      // 0000005281EC: D8387060 000A0609
	s_or_b32 exec_lo, exec_lo, s1                              // 0000005281F4: 8C7E017E
	.long 0xd44c0001                                           // 0000005281F8: D44C0001
	v_cndmask_b32_e32 v1, 0x80, v0, vcc_lo                     // 0000005281FC: 020200FF 00000080
	s_waitcnt lgkmcnt(0)                                       // 000000528204: BF89FC07
	s_barrier                                                  // 000000528208: BFBD0000
	buffer_gl0_inv                                             // 00000052820C: E0AC0000 00000000
	s_and_saveexec_b32 s5, s1                                  // 000000528214: BE852001
	s_cbranch_execnz 7                                         // 000000528218: BFA60007 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb1ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1a38>
	s_or_b32 exec_lo, exec_lo, s5                              // 00000052821C: 8C7E057E
	s_cmp_lt_i32 s33, 2                                        // 000000528220: BF048221
	s_mov_b32 s5, -1                                           // 000000528224: BE8500C1
	s_cbranch_scc0 33                                          // 000000528228: BFA10021 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb1ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1ab0>
	s_and_b32 vcc_lo, exec_lo, s5                              // 00000052822C: 8B6A057E
	s_cbranch_vccnz 154                                        // 000000528230: BFA4009A <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb1ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1c9c>
	s_endpgm                                                   // 000000528234: BFB00000
	v_lshlrev_b32_e32 v7, 2, v0                                // 000000528238: 300E0082
	ds_load_2addr_stride64_b32 v[1:2], v7 offset1:2            // 00000052823C: D8E00200 01000007
	ds_load_2addr_stride64_b32 v[3:4], v7 offset0:4 offset1:6  // 000000528244: D8E00604 03000007
	ds_load_2addr_stride64_b32 v[5:6], v7 offset0:8 offset1:10 // 00000052824C: D8E00A08 05000007
	s_waitcnt lgkmcnt(2)                                       // 000000528254: BF89FC27
	v_add_f32_e32 v1, 0, v1                                    // 000000528258: 06020280
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000052825C: BF8700A1
	v_add_f32_e32 v1, v1, v2                                   // 000000528260: 06020501
	s_waitcnt lgkmcnt(1)                                       // 000000528264: BF89FC17
	v_add_f32_e32 v3, v1, v3                                   // 000000528268: 06060701
	ds_load_2addr_stride64_b32 v[1:2], v7 offset0:12 offset1:14// 00000052826C: D8E00E0C 01000007
	v_add_f32_e32 v3, v3, v4                                   // 000000528274: 06060903
	s_waitcnt lgkmcnt(1)                                       // 000000528278: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000052827C: BF870091
	v_add_f32_e32 v3, v3, v5                                   // 000000528280: 06060B03
	v_add_f32_e32 v3, v3, v6                                   // 000000528284: 06060D03
	s_waitcnt lgkmcnt(0)                                       // 000000528288: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000052828C: BF870091
	v_add_f32_e32 v1, v3, v1                                   // 000000528290: 06020303
	v_add_f32_e32 v1, v1, v2                                   // 000000528294: 06020501
	ds_store_b32 v7, v1 offset:4096                            // 000000528298: D8341000 00000107
	s_or_b32 exec_lo, exec_lo, s5                              // 0000005282A0: 8C7E057E
	s_cmp_lt_i32 s33, 2                                        // 0000005282A4: BF048221
	s_mov_b32 s5, -1                                           // 0000005282A8: BE8500C1
	s_cbranch_scc1 65503                                       // 0000005282AC: BFA2FFDF <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb1ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1a2c>
	s_waitcnt lgkmcnt(0)                                       // 0000005282B0: BF89FC07
	s_barrier                                                  // 0000005282B4: BFBD0000
	buffer_gl0_inv                                             // 0000005282B8: E0AC0000 00000000
	s_and_saveexec_b32 s5, s1                                  // 0000005282C0: BE852001
	s_cbranch_execz 17                                         // 0000005282C4: BFA50011 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb1ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1b0c>
	v_lshlrev_b32_e32 v1, 2, v0                                // 0000005282C8: 30020082
	s_mul_hi_i32 s7, s26, s4                                   // 0000005282CC: 9707041A
	s_mul_i32 s6, s26, s4                                      // 0000005282D0: 9606041A
	s_lshl_b32 s8, s2, 7                                       // 0000005282D4: 84088702
	s_lshl_b64 s[6:7], s[6:7], 2                               // 0000005282D8: 84868206
	ds_load_b32 v2, v1 offset:4096                             // 0000005282DC: D8D81000 02000001
	s_ashr_i32 s9, s8, 31                                      // 0000005282E4: 86099F08
	s_add_u32 s4, s16, s6                                      // 0000005282E8: 80040610
	s_addc_u32 s10, s17, s7                                    // 0000005282EC: 820A0711
	s_lshl_b64 s[6:7], s[8:9], 2                               // 0000005282F0: 84868208
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000005282F4: BF870009
	s_add_u32 s6, s4, s6                                       // 0000005282F8: 80060604
	s_addc_u32 s7, s10, s7                                     // 0000005282FC: 8207070A
	s_waitcnt lgkmcnt(0)                                       // 000000528300: BF89FC07
	global_store_b32 v1, v2, s[6:7]                            // 000000528304: DC6A0000 00060201
	s_or_b32 exec_lo, exec_lo, s5                              // 00000052830C: 8C7E057E
	.long 0xd44a0004                                           // 000000528310: D44A0004
	v_cndmask_b32_e32 v1, 0, v0, vcc_lo                        // 000000528314: 02020080
	s_waitcnt_vscnt null, 0x0                                  // 000000528318: BC7C0000
	buffer_gl1_inv                                             // 00000052831C: E0B00000 00000000
	buffer_gl0_inv                                             // 000000528324: E0AC0000 00000000
	s_barrier                                                  // 00000052832C: BFBD0000
	buffer_gl0_inv                                             // 000000528330: E0AC0000 00000000
	s_and_saveexec_b32 s5, s4                                  // 000000528338: BE852004
	s_cbranch_execz 29                                         // 00000052833C: BFA5001D <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb1ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1bb4>
	s_mov_b32 s7, exec_lo                                      // 000000528340: BE87007E
	s_mov_b32 s6, exec_lo                                      // 000000528344: BE86007E
	.long 0xd71f0001                                           // 000000528348: D71F0001
	v_cndmask_b32_e32 v0, s7, v128, vcc_lo                     // 00000052834C: 02010007
	s_delay_alu instid0(VALU_DEP_1)                            // 000000528350: BF870001
	v_cmpx_eq_u32_e32 0, v1                                    // 000000528354: 7D940280
	s_cbranch_execz 9                                          // 000000528358: BFA50009 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb1ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1b80>
	s_lshl_b64 s[8:9], s[2:3], 2                               // 00000052835C: 84888202
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 000000528360: BF8704B9
	s_add_u32 s8, s18, s8                                      // 000000528364: 80080812
	s_addc_u32 s9, s19, s9                                     // 000000528368: 82090913
	s_bcnt1_i32_b32 s7, s7                                     // 00000052836C: BE871807
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v3, s7              // 000000528370: CA100080 02020007
	global_atomic_add_u32 v2, v2, v3, s[8:9] glc               // 000000528378: DCD64000 02080302
	s_or_b32 exec_lo, exec_lo, s6                              // 000000528380: 8C7E067E
	s_waitcnt vmcnt(0)                                         // 000000528384: BF8903F7
	v_readfirstlane_b32 s6, v2                                 // 000000528388: 7E0C0502
	s_delay_alu instid0(VALU_DEP_1)                            // 00000052838C: BF870001
	v_dual_mov_b32 v2, 0 :: v_dual_add_nc_u32 v1, s6, v1       // 000000528390: CA200080 02000206
	s_add_i32 s6, s33, -1                                      // 000000528398: 8106C121
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 00000052839C: BF870481
	v_cmp_eq_u32_e32 vcc_lo, s6, v1                            // 0000005283A0: 7C940206
	v_cndmask_b32_e64 v1, 0, 1, vcc_lo                         // 0000005283A4: D5010001 01A90280
	ds_store_b32 v2, v1 offset:13568                           // 0000005283AC: D8343500 00000102
	s_or_b32 exec_lo, exec_lo, s5                              // 0000005283B4: 8C7E057E
	v_mov_b32_e32 v1, 0                                        // 0000005283B8: 7E020280
	s_waitcnt lgkmcnt(0)                                       // 0000005283BC: BF89FC07
	s_barrier                                                  // 0000005283C0: BFBD0000
	buffer_gl0_inv                                             // 0000005283C4: E0AC0000 00000000
	ds_load_b32 v1, v1 offset:13568                            // 0000005283CC: D8D83500 01000001
	s_waitcnt lgkmcnt(0)                                       // 0000005283D4: BF89FC07
	v_cmp_eq_u32_e32 vcc_lo, 0, v1                             // 0000005283D8: 7C940280
	s_cbranch_vccnz 46                                         // 0000005283DC: BFA4002E <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb1ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1c98>
	buffer_gl1_inv                                             // 0000005283E0: E0B00000 00000000
	buffer_gl0_inv                                             // 0000005283E8: E0AC0000 00000000
	s_and_saveexec_b32 s5, s1                                  // 0000005283F0: BE852001
	s_cbranch_execz 28                                         // 0000005283F4: BFA5001C <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb1ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1c68>
	s_lshl_b32 s6, s2, 7                                       // 0000005283F8: 84068702
	v_dual_mov_b32 v4, 0 :: v_dual_lshlrev_b32 v3, 2, v0       // 0000005283FC: CA220080 04020082
	s_ashr_i32 s7, s6, 31                                      // 000000528404: 86079F06
	s_ashr_i32 s27, s26, 31                                    // 000000528408: 861B9F1A
	s_lshl_b64 s[6:7], s[6:7], 2                               // 00000052840C: 84868206
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000528410: BF8700B9
	s_add_u32 s1, s16, s6                                      // 000000528414: 80010610
	s_addc_u32 s6, s17, s7                                     // 000000528418: 82060711
	.long 0xd7000101                                           // 00000052841C: D7000101
	v_cndmask_b32_e32 v1, s1, v3, vcc_lo                       // 000000528420: 02020601
	v_add_co_ci_u32_e64 v2, null, s6, 0, s1                    // 000000528424: D5207C02 00050006
	s_lshl_b64 s[6:7], s[26:27], 2                             // 00000052842C: 8486821A
	global_load_b32 v5, v[1:2], off glc                        // 000000528430: DC524000 057C0001
	.long 0xd7006a01                                           // 000000528438: D7006A01
	v_cndmask_b32_e32 v0, v1, v6, vcc_lo                       // 00000052843C: 02000D01
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000528440: BF8704A1
	v_add_co_ci_u32_e64 v2, null, s7, v2, vcc_lo               // 000000528444: D5207C02 01AA0407
	s_add_i32 s33, s33, -1                                     // 00000052844C: 8121C121
	s_cmp_eq_u32 s33, 0                                        // 000000528450: BF068021
	s_waitcnt vmcnt(0)                                         // 000000528454: BF8903F7
	v_add_f32_e32 v4, v4, v5                                   // 000000528458: 06080B04
	s_cbranch_scc0 65524                                       // 00000052845C: BFA1FFF4 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb1ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1c30>
	ds_store_b32 v3, v4 offset:4096                            // 000000528460: D8341000 00000403
	s_or_b32 exec_lo, exec_lo, s5                              // 000000528468: 8C7E057E
	s_and_saveexec_b32 s1, s4                                  // 00000052846C: BE812004
	s_cbranch_execz 6                                          // 000000528470: BFA50006 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb1ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1c8c>
	s_lshl_b64 s[4:5], s[2:3], 2                               // 000000528474: 84848202
	v_mov_b32_e32 v1, 0                                        // 000000528478: 7E020280
	s_add_u32 s4, s18, s4                                      // 00000052847C: 80040412
	s_addc_u32 s5, s19, s5                                     // 000000528480: 82050513
	global_store_b32 v1, v1, s[4:5]                            // 000000528484: DC6A0000 00040101
	s_or_b32 exec_lo, exec_lo, s1                              // 00000052848C: 8C7E017E
	s_cbranch_execz 65384                                      // 000000528490: BFA5FF68 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb1ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1a34>
	s_branch 1                                                 // 000000528494: BFA00001 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb1ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1c9c>
	s_branch 65382                                             // 000000528498: BFA0FF66 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb1ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1a34>
	v_cmp_eq_u32_e32 vcc_lo, 0, v8                             // 00000052849C: 7C941080
	s_cmp_gt_i32 s24, 0                                        // 0000005284A0: BF028018
	s_waitcnt lgkmcnt(0)                                       // 0000005284A4: BF89FC07
	s_waitcnt_vscnt null, 0x0                                  // 0000005284A8: BC7C0000
	s_cselect_b32 s1, -1, 0                                    // 0000005284AC: 980180C1
	s_barrier                                                  // 0000005284B0: BFBD0000
	s_and_b32 s1, vcc_lo, s1                                   // 0000005284B4: 8B01016A
	buffer_gl0_inv                                             // 0000005284B8: E0AC0000 00000000
	s_and_saveexec_b32 s3, s1                                  // 0000005284C0: BE832001
	s_cbranch_execz 65371                                      // 0000005284C4: BFA5FF5B <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb1ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1a34>
	v_and_b32_e32 v1, 15, v0                                   // 0000005284C8: 3602008F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005284CC: BF870091
	v_lshlrev_b32_e32 v2, 2, v1                                // 0000005284D0: 30040282
	v_add_nc_u32_e32 v8, 0x1000, v2                            // 0000005284D4: 4A1004FF 00001000
	ds_load_2addr_b32 v[2:3], v8 offset1:16                    // 0000005284DC: D8DC1000 02000008
	ds_load_2addr_b32 v[4:5], v8 offset0:32 offset1:48         // 0000005284E4: D8DC3020 04000008
	ds_load_2addr_b32 v[6:7], v8 offset0:64 offset1:80         // 0000005284EC: D8DC5040 06000008
	ds_load_2addr_b32 v[8:9], v8 offset0:96 offset1:112        // 0000005284F4: D8DC7060 08000008
	v_and_b32_e32 v10, 1, v0                                   // 0000005284FC: 36140081
	s_waitcnt lgkmcnt(3)                                       // 000000528500: BF89FC37
	v_dual_add_f32 v12, v2, v3 :: v_dual_and_b32 v11, 2, v0    // 000000528504: C9240702 0C0A0082
	s_waitcnt lgkmcnt(2)                                       // 00000052850C: BF89FC27
	v_dual_sub_f32 v2, v2, v3 :: v_dual_add_f32 v3, v4, v5     // 000000528510: C9480702 02020B04
	s_waitcnt lgkmcnt(1)                                       // 000000528518: BF89FC17
	v_dual_sub_f32 v4, v4, v5 :: v_dual_add_f32 v5, v6, v7     // 00000052851C: C9480B04 04040F06
	s_waitcnt lgkmcnt(0)                                       // 000000528524: BF89FC07
	v_dual_sub_f32 v6, v6, v7 :: v_dual_sub_f32 v7, v8, v9     // 000000528528: C94A0F06 06061308
	v_dual_add_f32 v8, v8, v9 :: v_dual_and_b32 v9, 4, v0      // 000000528530: C9241308 08080084
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000528538: BF870233
	v_add_f32_e32 v13, v2, v4                                  // 00000052853C: 061A0902
	v_cmp_eq_u32_e32 vcc_lo, 0, v10                            // 000000528540: 7C941480
	.long 0xd44a0001                                           // 000000528544: D44A0001
	v_cndmask_b32_e32 v1, 0, v11, vcc_lo                       // 000000528548: 02021680
	v_add_f32_e32 v16, v5, v8                                  // 00000052854C: 06201105
	v_dual_sub_f32 v5, v5, v8 :: v_dual_add_f32 v14, v12, v3   // 000000528550: C9481105 050E070C
	v_add_f32_e32 v15, v6, v7                                  // 000000528558: 061E0F06
	v_dual_sub_f32 v3, v12, v3 :: v_dual_sub_f32 v2, v2, v4    // 00000052855C: C94A070C 03020902
	v_sub_f32_e32 v4, v6, v7                                   // 000000528564: 08080F06
	.long 0xd44a0003                                           // 000000528568: D44A0003
	v_cndmask_b32_e32 v1, 0, v9, vcc_lo                        // 00000052856C: 02021280
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000528570: BF870214
	v_add_f32_e32 v6, v13, v15                                 // 000000528574: 060C1F0D
	v_dual_sub_f32 v8, v13, v15 :: v_dual_add_f32 v13, v3, v5  // 000000528578: C9481F0D 080C0B03
	v_add_f32_e32 v7, v14, v16                                 // 000000528580: 060E210E
	v_dual_sub_f32 v15, v3, v5 :: v_dual_add_f32 v12, v2, v4   // 000000528584: C9480B03 0F0C0902
	s_delay_alu instid0(VALU_DEP_4)                            // 00000052858C: BF870004
	v_mov_b32_dpp v3, v6 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000528590: 7E0602FA FF016106
	v_sub_f32_e32 v10, v14, v16                                // 000000528598: 0814210E
	v_sub_f32_e32 v14, v2, v4                                  // 00000052859C: 081C0902
	v_mov_b32_dpp v2, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000005285A0: 7E0402FA FF016107
	v_cndmask_b32_e64 v4, -v6, v6, vcc_lo                      // 0000005285A8: D5010004 21AA0D06
	v_cndmask_b32_e64 v5, -v7, v7, vcc_lo                      // 0000005285B0: D5010005 21AA0F07
	v_mov_b32_dpp v16, v13 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000005285B8: 7E2002FA FF01610D
	v_cndmask_b32_e64 v13, -v13, v13, vcc_lo                   // 0000005285C0: D501000D 21AA1B0D
	v_mov_b32_dpp v18, v15 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000005285C8: 7E2402FA FF01610F
	v_add_f32_e32 v3, v4, v3                                   // 0000005285D0: 06060704
	v_mov_b32_dpp v6, v10 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000005285D4: 7E0C02FA FF01610A
	v_cndmask_b32_e64 v10, -v10, v10, vcc_lo                   // 0000005285DC: D501000A 21AA150A
	v_add_f32_e32 v2, v5, v2                                   // 0000005285E4: 06040505
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000005285E8: BF870112
	v_add_f32_e32 v5, v10, v6                                  // 0000005285EC: 060A0D0A
	v_mov_b32_dpp v6, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000005285F0: 7E0C02FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, s1                          // 0000005285F8: D5010002 20060502
	v_mov_b32_dpp v7, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000528600: 7E0E02FA FF016108
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 000000528608: D5010008 21AA1108
	v_mov_b32_dpp v10, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000528610: 7E1402FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, s1                          // 000000528618: D5010005 20060B05
	v_add_f32_e32 v2, v2, v6                                   // 000000528620: 06040D02
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000528624: BF870112
	v_add_f32_e32 v10, v5, v10                                 // 000000528628: 06141505
	v_mov_b32_dpp v6, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000052862C: 7E0C02FA FF016402
	v_cndmask_b32_e64 v2, -v2, v2, s3                          // 000000528634: D5010002 200E0502
	v_add_f32_e32 v4, v8, v7                                   // 00000052863C: 06080F08
	v_cndmask_b32_e64 v8, -v3, v3, s1                          // 000000528640: D5010008 20060703
	v_mov_b32_dpp v3, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000528648: 7E0602FA FF016203
	v_add_f32_e32 v7, v13, v16                                 // 000000528650: 060E210D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000528654: BF870112
	v_add_f32_e32 v3, v8, v3                                   // 000000528658: 06060708
	v_mov_b32_dpp v13, v7 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000052865C: 7E1A02FA FF016207
	v_cndmask_b32_e64 v7, -v7, v7, s1                          // 000000528664: D5010007 20060F07
	v_mov_b32_dpp v17, v12 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000052866C: 7E2202FA FF01610C
	v_cndmask_b32_e64 v12, -v12, v12, vcc_lo                   // 000000528674: D501000C 21AA190C
	v_cndmask_b32_e64 v8, -v3, v3, s3                          // 00000052867C: D5010008 200E0703
	v_mov_b32_dpp v9, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000528684: 7E1202FA FF016403
	v_add_f32_e32 v3, v2, v6                                   // 00000052868C: 06060D02
	v_mov_b32_dpp v11, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000528690: 7E1602FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, s1                          // 000000528698: D5010004 20060904
	v_add_f32_e32 v13, v7, v13                                 // 0000005286A0: 061A1B07
	v_add_f32_e32 v5, v8, v9                                   // 0000005286A4: 060A1308
	v_mov_b32_dpp v8, v10 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000005286A8: 7E1002FA FF01640A
	v_cndmask_b32_e64 v9, -v10, v10, s3                        // 0000005286B0: D5010009 200E150A
	v_add_f32_e32 v4, v4, v11                                  // 0000005286B8: 06081704
	v_cndmask_b32_e64 v10, -v15, v15, vcc_lo                   // 0000005286BC: D501000A 21AA1F0F
	v_mov_b32_dpp v19, v14 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000005286C4: 7E2602FA FF01610E
	v_mov_b32_dpp v2, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000005286CC: 7E0402FA FF016803
	v_add_f32_e32 v7, v9, v8                                   // 0000005286D4: 060E1109
	v_mov_b32_dpp v11, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000005286D8: 7E1602FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s3                          // 0000005286E0: D5010004 200E0904
	v_mov_b32_dpp v9, v13 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000005286E8: 7E1202FA FF01640D
	v_cndmask_b32_e64 v13, -v13, v13, s3                       // 0000005286F0: D501000D 200E1B0D
	v_add_f32_e32 v10, v10, v18                                // 0000005286F8: 0614250A
	v_mov_b32_dpp v6, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000005286FC: 7E0C02FA FF016805
	v_add_f32_e32 v4, v4, v11                                  // 000000528704: 06081704
	v_cndmask_b32_e64 v11, -v14, v14, vcc_lo                   // 000000528708: D501000B 21AA1D0E
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000528710: BF8701A4
	v_mov_b32_dpp v15, v10 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000528714: 7E1E02FA FF01620A
	v_cndmask_b32_e64 v10, -v10, v10, s1                       // 00000052871C: D501000A 2006150A
	v_add_f32_e32 v11, v11, v19                                // 000000528724: 0616270B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000528728: BF870112
	v_dual_add_f32 v8, v10, v15 :: v_dual_add_f32 v15, v13, v9 // 00000052872C: C9081F0A 080E130D
	v_mov_b32_dpp v16, v11 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000528734: 7E2002FA FF01620B
	v_cndmask_b32_e64 v11, -v11, v11, s1                       // 00000052873C: D501000B 2006170B
	v_mov_b32_dpp v9, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000528744: 7E1202FA FF016804
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000052874C: BF870224
	v_cndmask_b32_e64 v18, -v8, v8, s3                         // 000000528750: D5010012 200E1108
	v_add_f32_e32 v12, v12, v17                                // 000000528758: 0618230C
	v_add_f32_e32 v10, v11, v16                                // 00000052875C: 0614210B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000528760: BF8701A2
	v_mov_b32_dpp v14, v12 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000528764: 7E1C02FA FF01620C
	v_cndmask_b32_e64 v12, -v12, v12, s1                       // 00000052876C: D501000C 2006190C
	v_mov_b32_dpp v16, v10 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000528774: 7E2002FA FF01640A
	v_cndmask_b32_e64 v10, -v10, v10, s3                       // 00000052877C: D501000A 200E150A
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000528784: BF8701A3
	v_add_f32_e32 v12, v12, v14                                // 000000528788: 06181D0C
	v_mov_b32_dpp v14, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000052878C: 7E1C02FA FF016408
	v_add_f32_e32 v16, v10, v16                                // 000000528794: 0620210A
	v_mov_b32_dpp v8, v7 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000528798: 7E1002FA FF016807
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000005287A0: BF870134
	v_mov_b32_dpp v11, v12 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000005287A4: 7E1602FA FF01640C
	v_cndmask_b32_e64 v12, -v12, v12, s3                       // 0000005287AC: D501000C 200E190C
	v_add_f32_e32 v13, v18, v14                                // 0000005287B4: 061A1D12
	v_add_f32_e32 v17, v12, v11                                // 0000005287B8: 0622170C
	v_mov_b32_dpp v11, v15 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000005287BC: 7E1602FA FF01680F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000005287C4: BF870223
	v_mov_b32_dpp v10, v13 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000005287C8: 7E1402FA FF01680D
	v_mov_b32_dpp v12, v16 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000005287D0: 7E1802FA FF016810
	v_mov_b32_dpp v14, v17 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000005287D8: 7E1C02FA FF016811
	s_and_b32 exec_lo, exec_lo, s0                             // 0000005287E0: 8B7E007E
	s_cbranch_execz 65171                                      // 0000005287E4: BFA5FE93 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb1ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1a34>
	v_lshl_or_b32 v18, s2, 7, v1                               // 0000005287E8: D6560012 04050E02
	v_and_b32_e32 v0, 8, v0                                    // 0000005287F0: 36000088
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005287F4: BF870092
	v_ashrrev_i32_e32 v19, 31, v18                             // 0000005287F8: 3426249F
	.long 0xd73c0014                                           // 0000005287FC: D73C0014
	v_cndmask_b32_e32 v1, 1, v18, vcc_lo                       // 000000528800: 02022481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000528804: BF870091
	.long 0xd7006a14                                           // 000000528808: D7006A14
	v_cndmask_b32_e32 v1, s14, v20, vcc_lo                     // 00000052880C: 0202280E
	v_add_co_ci_u32_e64 v21, null, s15, v21, vcc_lo            // 000000528810: D5207C15 01AA2A0F
	v_cmp_eq_u32_e32 vcc_lo, 0, v0                             // 000000528818: 7C940080
	.long 0xd73c0000                                           // 00000052881C: D73C0000
	v_cndmask_b32_e32 v1, 2, v18, vcc_lo                       // 000000528820: 02022482
	s_clause 0x7                                               // 000000528824: BF850007
	global_load_d16_b16 v22, v[20:21], off offset:32           // 000000528828: DC820020 167C0014
	global_load_d16_b16 v23, v[20:21], off                     // 000000528830: DC820000 177C0014
	global_load_d16_b16 v24, v[20:21], off offset:96           // 000000528838: DC820060 187C0014
	global_load_d16_b16 v25, v[20:21], off offset:64           // 000000528840: DC820040 197C0014
	global_load_d16_b16 v26, v[20:21], off offset:160          // 000000528848: DC8200A0 1A7C0014
	global_load_d16_b16 v27, v[20:21], off offset:128          // 000000528850: DC820080 1B7C0014
	global_load_d16_b16 v28, v[20:21], off offset:224          // 000000528858: DC8200E0 1C7C0014
	global_load_d16_b16 v20, v[20:21], off offset:192          // 000000528860: DC8200C0 147C0014
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 000000528868: D5010005 21AA0B05
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 000000528870: D5010003 21AA0703
	v_cndmask_b32_e64 v15, -v15, v15, vcc_lo                   // 000000528878: D501000F 21AA1F0F
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 000000528880: D5010004 21AA0904
	v_cndmask_b32_e64 v7, -v7, v7, vcc_lo                      // 000000528888: D5010007 21AA0F07
	v_add_f32_e32 v5, v5, v6                                   // 000000528890: 060A0D05
	v_cndmask_b32_e64 v6, -v17, v17, vcc_lo                    // 000000528894: D5010006 21AA2311
	v_cndmask_b32_e64 v16, -v16, v16, vcc_lo                   // 00000052889C: D5010010 21AA2110
	v_cndmask_b32_e64 v13, -v13, v13, vcc_lo                   // 0000005288A4: D501000D 21AA1B0D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000005288AC: BF870214
	v_dual_add_f32 v2, v3, v2 :: v_dual_mul_f32 v3, 0x3db504f3, v5// 0000005288B0: C9060503 02020AFF 3DB504F3
	v_dual_add_f32 v5, v6, v14 :: v_dual_add_f32 v6, v15, v11  // 0000005288BC: C9081D06 0506170F
	v_dual_add_f32 v4, v4, v9 :: v_dual_add_f32 v7, v7, v8     // 0000005288C4: C9081304 04061107
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000005288CC: BF870194
	v_dual_add_f32 v8, v16, v12 :: v_dual_add_f32 v9, v13, v10 // 0000005288D0: C9081910 0808150D
	v_dual_mul_f32 v2, 0x3db504f3, v2 :: v_dual_mul_f32 v5, 0x3db504f3, v5// 0000005288D8: C8C604FF 02040AFF 3DB504F3
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000005288E4: BF8700A3
	v_dual_mul_f32 v6, 0x3db504f3, v6 :: v_dual_mul_f32 v7, 0x3db504f3, v7// 0000005288E8: C8C60CFF 06060EFF 3DB504F3
	.long 0xd7006a00                                           // 0000005288F4: D7006A00
	v_cndmask_b32_e32 v1, s28, v0, vcc_lo                      // 0000005288F8: 0202001C
	v_add_co_ci_u32_e64 v1, null, s29, v1, vcc_lo              // 0000005288FC: D5207C01 01AA021D
	v_dual_mul_f32 v4, 0x3db504f3, v4 :: v_dual_mul_f32 v9, 0x3db504f3, v9// 000000528904: C8C608FF 040812FF 3DB504F3
	v_mul_f32_e32 v8, 0x3db504f3, v8                           // 000000528910: 101010FF 3DB504F3
	s_waitcnt vmcnt(7)                                         // 000000528918: BF891FF7
	v_fma_mix_f32 v3, v22, v3, neg(0) op_sel_hi:[1,0,0]        // 00000052891C: CC200003 8A020716
	s_waitcnt vmcnt(6)                                         // 000000528924: BF891BF7
	v_fma_mix_f32 v2, v23, v2, neg(0) op_sel_hi:[1,0,0]        // 000000528928: CC200002 8A020517
	s_waitcnt vmcnt(5)                                         // 000000528930: BF8917F7
	v_fma_mix_f32 v5, v24, v5, neg(0) op_sel_hi:[1,0,0]        // 000000528934: CC200005 8A020B18
	s_waitcnt vmcnt(4)                                         // 00000052893C: BF8913F7
	v_fma_mix_f32 v6, v25, v6, neg(0) op_sel_hi:[1,0,0]        // 000000528940: CC200006 8A020D19
	s_waitcnt vmcnt(3)                                         // 000000528948: BF890FF7
	v_fma_mix_f32 v4, v26, v4, neg(0) op_sel_hi:[1,0,0]        // 00000052894C: CC200004 8A02091A
	s_waitcnt vmcnt(2)                                         // 000000528954: BF890BF7
	v_fma_mix_f32 v7, v27, v7, neg(0) op_sel_hi:[1,0,0]        // 000000528958: CC200007 8A020F1B
	s_waitcnt vmcnt(1)                                         // 000000528960: BF8907F7
	v_fma_mix_f32 v8, v28, v8, neg(0) op_sel_hi:[1,0,0]        // 000000528964: CC200008 8A02111C
	s_waitcnt vmcnt(0)                                         // 00000052896C: BF8903F7
	v_fma_mix_f32 v9, v20, v9, neg(0) op_sel_hi:[1,0,0]        // 000000528970: CC200009 8A021314
	s_clause 0x7                                               // 000000528978: BF850007
	global_store_b32 v[0:1], v2, off                           // 00000052897C: DC6A0000 007C0200
	global_store_b32 v[0:1], v3, off offset:64                 // 000000528984: DC6A0040 007C0300
	global_store_b32 v[0:1], v6, off offset:128                // 00000052898C: DC6A0080 007C0600
	global_store_b32 v[0:1], v5, off offset:192                // 000000528994: DC6A00C0 007C0500
	global_store_b32 v[0:1], v7, off offset:256                // 00000052899C: DC6A0100 007C0700
	global_store_b32 v[0:1], v4, off offset:320                // 0000005289A4: DC6A0140 007C0400
	global_store_b32 v[0:1], v9, off offset:384                // 0000005289AC: DC6A0180 007C0900
	global_store_b32 v[0:1], v8, off offset:448                // 0000005289B4: DC6A01C0 007C0800
	s_endpgm                                                   // 0000005289BC: BFB00000
		...

