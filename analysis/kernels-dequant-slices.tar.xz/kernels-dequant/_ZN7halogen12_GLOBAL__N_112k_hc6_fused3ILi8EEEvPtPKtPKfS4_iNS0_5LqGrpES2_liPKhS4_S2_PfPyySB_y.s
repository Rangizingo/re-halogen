00000000003c8f00 <_ZN7halogen12_GLOBAL__N_112k_hc6_fused3ILi8EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y>:
; _ZN7halogen12_GLOBAL__N_112k_hc6_fused3ILi8EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y():
	s_clause 0x2                                               // 0000003C8F00: BF850002
	s_load_b32 s24, s[0:1], 0x20                               // 0000003C8F04: F4000600 F8000020
	s_load_b128 s[20:23], s[0:1], 0x150                        // 0000003C8F0C: F4080500 F8000150
	s_load_b512 s[4:19], s[0:1], 0x168                         // 0000003C8F14: F4100100 F8000168
	s_mov_b32 s3, -1                                           // 0000003C8F1C: BE8300C1
	s_waitcnt lgkmcnt(0)                                       // 0000003C8F20: BF89FC07
	s_cmp_ge_i32 s2, s24                                       // 0000003C8F24: BF031802
	s_cbranch_scc0 2684                                        // 0000003C8F28: BFA10A7C <_ZN7halogen12_GLOBAL__N_112k_hc6_fused3ILi8EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x2a1c>
	s_load_b32 s25, s[0:1], 0x160                              // 0000003C8F2C: F4000640 F8000160
	s_waitcnt lgkmcnt(0)                                       // 0000003C8F34: BF89FC07
	s_add_i32 s25, s25, s24                                    // 0000003C8F38: 81191819
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000003C8F3C: BF870009
	s_cmp_ge_i32 s2, s25                                       // 0000003C8F40: BF031902
	s_cbranch_scc0 1437                                        // 0000003C8F44: BFA1059D <_ZN7halogen12_GLOBAL__N_112k_hc6_fused3ILi8EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x16bc>
	v_dual_mov_b32 v20, 0 :: v_dual_and_b32 v19, 15, v0        // 0000003C8F48: CA240080 1412008F
	v_dual_mov_b32 v18, 0 :: v_dual_mov_b32 v17, 0             // 0000003C8F50: CA100080 12100080
	v_dual_mov_b32 v4, 0 :: v_dual_mov_b32 v3, 0               // 0000003C8F58: CA100080 04020080
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000003C8F60: BF8704B3
	.long 0xd44c0003                                           // 0000003C8F64: D44C0003
	v_cndmask_b32_e32 v1, 10, v19, vcc_lo                      // 0000003C8F68: 0202268A
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v1, 0               // 0000003C8F6C: CA100080 02000080
	s_sub_i32 s25, s2, s25                                     // 0000003C8F74: 81991902
	s_lshl_b32 s25, s25, 2                                     // 0000003C8F78: 84198219
	s_and_saveexec_b32 s26, s3                                 // 0000003C8F7C: BE9A2003
	s_cbranch_execz 45                                         // 0000003C8F80: BFA5002D <_ZN7halogen12_GLOBAL__N_112k_hc6_fused3ILi8EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x138>
	v_lshrrev_b32_e32 v1, 6, v0                                // 0000003C8F84: 32020086
	v_bfe_u32 v2, v0, 4, 2                                     // 0000003C8F88: D6100002 02090900
	v_lshlrev_b32_e32 v4, 1, v0                                // 0000003C8F90: 30080081
	v_lshlrev_b32_e32 v5, 4, v19                               // 0000003C8F94: 300A2684
	v_lshlrev_b32_e32 v6, 3, v19                               // 0000003C8F98: 300C2683
	v_add_nc_u32_e32 v1, s25, v1                               // 0000003C8F9C: 4A020219
	v_mul_u32_u24_e32 v2, 0xa00, v2                            // 0000003C8FA0: 160404FF 00000A00
	v_and_b32_e32 v4, 28, v4                                   // 0000003C8FA8: 3608089C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003C8FAC: BF870193
	v_ashrrev_i32_e32 v3, 31, v1                               // 0000003C8FB0: 3406029F
	.long 0xd7006a01                                           // 0000003C8FB4: D7006A01
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 0000003C8FB8: 02020501
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003C8FBC: BF870111
	v_add_co_ci_u32_e64 v3, null, 0, v3, vcc_lo                // 0000003C8FC0: D5207C03 01AA0680
	v_mad_u64_u32 v[1:2], null, 0x110, v1, s[4:5]              // 0000003C8FC8: D6FE7C01 001202FF 00000110
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003C8FD4: BF870111
	v_mad_i32_i24 v8, 0x110, v3, v2                            // 0000003C8FD8: D60A0008 040A06FF 00000110
	.long 0xd7006a02                                           // 0000003C8FE4: D7006A02
	v_cndmask_b32_e32 v1, v1, v5, vcc_lo                       // 0000003C8FE8: 02020B01
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003C8FEC: BF8700A1
	v_add_co_ci_u32_e64 v3, null, 0, v8, vcc_lo                // 0000003C8FF0: D5207C03 01AA1080
	.long 0xd7006a05                                           // 0000003C8FF8: D7006A05
	v_cndmask_b32_e32 v1, v1, v6, vcc_lo                       // 0000003C8FFC: 02020D01
	v_add_co_ci_u32_e64 v6, null, 0, v8, vcc_lo                // 0000003C9000: D5207C06 01AA1080
	.long 0xd7006a07                                           // 0000003C9008: D7006A07
	v_cndmask_b32_e32 v1, v1, v4, vcc_lo                       // 0000003C900C: 02020901
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003C9010: BF870001
	v_add_co_ci_u32_e64 v8, null, 0, v8, vcc_lo                // 0000003C9014: D5207C08 01AA1080
	s_clause 0x2                                               // 0000003C901C: BF850002
	global_load_b128 v[1:4], v[2:3], off                       // 0000003C9020: DC5E0000 017C0002
	global_load_b64 v[17:18], v[5:6], off offset:160           // 0000003C9028: DC5600A0 117C0005
	global_load_b32 v20, v[7:8], off offset:240                // 0000003C9030: DC5200F0 147C0007
	s_or_b32 exec_lo, exec_lo, s26                             // 0000003C9038: 8C7E1A7E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000003C903C: BF870009
	s_mov_b32 s4, exec_lo                                      // 0000003C9040: BE84007E
	v_cmpx_eq_u32_e32 0, v0                                    // 0000003C9044: 7D940080
	s_cbranch_execz 20                                         // 0000003C9048: BFA50014 <_ZN7halogen12_GLOBAL__N_112k_hc6_fused3ILi8EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x19c>
	v_mov_b32_e32 v5, 0                                        // 0000003C904C: 7E0A0280
	global_load_b64 v[6:7], v5, s[16:17] glc                   // 0000003C9050: DC564000 06100005
	s_waitcnt vmcnt(0)                                         // 0000003C9058: BF8903F7
	buffer_gl1_inv                                             // 0000003C905C: E0B00000 00000000
	buffer_gl0_inv                                             // 0000003C9064: E0AC0000 00000000
	v_cmp_le_u64_e32 vcc_lo, s[18:19], v[6:7]                  // 0000003C906C: 7CB60C12
	s_cbranch_vccnz 10                                         // 0000003C9070: BFA4000A <_ZN7halogen12_GLOBAL__N_112k_hc6_fused3ILi8EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x19c>
	s_sleep 1                                                  // 0000003C9074: BF830001
	global_load_b64 v[6:7], v5, s[16:17] glc                   // 0000003C9078: DC564000 06100005
	s_waitcnt vmcnt(0)                                         // 0000003C9080: BF8903F7
	buffer_gl1_inv                                             // 0000003C9084: E0B00000 00000000
	buffer_gl0_inv                                             // 0000003C908C: E0AC0000 00000000
	v_cmp_gt_u64_e32 vcc_lo, s[18:19], v[6:7]                  // 0000003C9094: 7CB80C12
	s_cbranch_vccnz 65526                                      // 0000003C9098: BFA4FFF6 <_ZN7halogen12_GLOBAL__N_112k_hc6_fused3ILi8EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x174>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000003C909C: 8C7E047E
	v_dual_mov_b32 v6, 0 :: v_dual_mov_b32 v7, 0               // 0000003C90A0: CA100080 06060080
	v_dual_mov_b32 v5, 0 :: v_dual_mov_b32 v12, 0              // 0000003C90A8: CA100080 050C0080
	v_dual_mov_b32 v10, 0 :: v_dual_mov_b32 v11, 0             // 0000003C90B0: CA100080 0A0A0080
	v_dual_mov_b32 v8, 0 :: v_dual_mov_b32 v9, 0               // 0000003C90B8: CA100080 08080080
	s_waitcnt vmcnt(0)                                         // 0000003C90C0: BF8903F7
	s_barrier                                                  // 0000003C90C4: BFBD0000
	buffer_gl0_inv                                             // 0000003C90C8: E0AC0000 00000000
	buffer_gl1_inv                                             // 0000003C90D0: E0B00000 00000000
	buffer_gl0_inv                                             // 0000003C90D8: E0AC0000 00000000
	s_and_saveexec_b32 s4, s3                                  // 0000003C90E0: BE842003
	s_cbranch_execz 865                                        // 0000003C90E4: BFA50361 <_ZN7halogen12_GLOBAL__N_112k_hc6_fused3ILi8EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0xf6c>
	v_lshlrev_b32_e32 v21, 6, v19                              // 0000003C90E8: 302A2686
	v_lshlrev_b32_e32 v22, 4, v17                              // 0000003C90EC: 302C2284
	v_lshlrev_b32_e32 v23, 2, v17                              // 0000003C90F0: 302E2282
	v_lshrrev_b32_e32 v24, 4, v1                               // 0000003C90F4: 32300284
	v_lshrrev_b32_e32 v25, 8, v1                               // 0000003C90F8: 32320288
	s_clause 0x2                                               // 0000003C90FC: BF850002
	global_load_b128 v[5:8], v21, s[6:7]                       // 0000003C9100: DC5E0000 05060015
	global_load_b128 v[9:12], v21, s[6:7] offset:640           // 0000003C9108: DC5E0280 09060015
	global_load_b128 v[13:16], v21, s[6:7] offset:1280         // 0000003C9110: DC5E0500 0D060015
	v_and_b32_e32 v22, 48, v22                                 // 0000003C9118: 362C2CB0
	v_lshrrev_b32_e32 v26, 2, v17                              // 0000003C911C: 32342282
	v_and_b32_e32 v23, 48, v23                                 // 0000003C9120: 362E2EB0
	v_and_b32_e32 v27, 48, v17                                 // 0000003C9124: 363622B0
	v_lshrrev_b32_e32 v28, 12, v1                              // 0000003C9128: 3238028C
	v_and_or_b32 v22, v1, 15, v22                              // 0000003C912C: D6570016 04591F01
	v_and_b32_e32 v26, 48, v26                                 // 0000003C9134: 363434B0
	v_and_or_b32 v23, v24, 15, v23                             // 0000003C9138: D6570017 045D1F18
	v_and_or_b32 v24, v25, 15, v27                             // 0000003C9140: D6570018 046D1F19
	v_lshrrev_b32_e32 v29, 8, v17                              // 0000003C9148: 323A2288
	v_cvt_f32_ubyte0_e32 v22, v22                              // 0000003C914C: 7E2C2316
	v_and_or_b32 v25, v28, 15, v26                             // 0000003C9150: D6570019 04691F1C
	v_cvt_f32_ubyte0_e32 v23, v23                              // 0000003C9158: 7E2E2317
	v_cvt_f32_ubyte0_e32 v24, v24                              // 0000003C915C: 7E302318
	v_and_b32_e32 v29, 48, v29                                 // 0000003C9160: 363A3AB0
	v_fma_mix_f32 v22, v22, v20, v20 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003C9164: CC206016 14522916
	v_cvt_f32_ubyte0_e32 v25, v25                              // 0000003C916C: 7E322319
	v_fma_mix_f32 v23, v23, v20, v20 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003C9170: CC206017 14522917
	v_fma_mix_f32 v27, v24, v20, v20 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003C9178: CC20601B 14522918
	.long 0x7f303880                                           // 0000003C9180: 7F303880
	v_bfe_u32 v26, v22, 16, 1                                  // 0000003C9184: D610001A 02052116
	v_fma_mix_f32 v25, v25, v20, v20 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003C918C: CC206019 14522919
	v_bfe_u32 v28, v23, 16, 1                                  // 0000003C9194: D610001C 02052117
	v_lshrrev_b32_e32 v31, 8, v2                               // 0000003C919C: 323E0488
	v_lshrrev_b32_e32 v32, 18, v17                             // 0000003C91A0: 32402292
	v_add3_u32 v22, v22, v26, 0x7fff                           // 0000003C91A4: D6550016 03FE3516 00007FFF
	v_bfe_u32 v26, v27, 16, 1                                  // 0000003C91B0: D610001A 0205211B
	v_bfe_u32 v30, v25, 16, 1                                  // 0000003C91B8: D610001E 02052119
	v_add3_u32 v23, v23, v28, 0x7fff                           // 0000003C91C0: D6550017 03FE3917 00007FFF
	v_lshrrev_b32_e32 v28, 6, v17                              // 0000003C91CC: 32382286
	.long 0x7e303996                                           // 0000003C91D0: 7E303996
	v_add3_u32 v22, v27, v26, 0x7fff                           // 0000003C91D4: D6550016 03FE351B 00007FFF
	v_lshrrev_b32_e32 v26, 4, v17                              // 0000003C91E0: 32342284
	v_add3_u32 v25, v25, v30, 0x7fff                           // 0000003C91E4: D6550019 03FE3D19 00007FFF
	v_lshrrev_b32_e32 v27, 20, v1                              // 0000003C91F0: 32360294
	v_and_or_b32 v23, 0xffff0000, v23, v24                     // 0000003C91F4: D6570017 04622EFF FFFF0000
	.long 0x7e303996                                           // 0000003C9200: 7E303996
	v_and_b32_e32 v26, 48, v26                                 // 0000003C9204: 363434B0
	v_lshrrev_b32_e32 v30, 24, v1                              // 0000003C9208: 323C0298
	v_and_b32_e32 v28, 48, v28                                 // 0000003C920C: 363838B0
	v_and_b32_e32 v32, 48, v32                                 // 0000003C9210: 364040B0
	v_and_or_b32 v22, 0xffff0000, v25, v24                     // 0000003C9214: D6570016 046232FF FFFF0000
	.long 0x7e303981                                           // 0000003C9220: 7E303981
	v_lshrrev_b32_e32 v1, 28, v1                               // 0000003C9224: 3202029C
	v_lshrrev_b32_e32 v25, 10, v17                             // 0000003C9228: 3232228A
	v_and_or_b32 v27, v27, 15, v28                             // 0000003C922C: D657001B 04711F1B
	v_and_or_b32 v28, v30, 15, v29                             // 0000003C9234: D657001C 04751F1E
	v_and_or_b32 v26, v24, 15, v26                             // 0000003C923C: D657001A 04691F18
	v_lshrrev_b32_e32 v29, 20, v17                             // 0000003C9244: 323A2294
	v_and_or_b32 v1, v25, 48, v1                               // 0000003C9248: D6570001 04056119
	v_cvt_f32_ubyte0_e32 v25, v27                              // 0000003C9250: 7E32231B
	v_cvt_f32_ubyte0_e32 v27, v28                              // 0000003C9254: 7E36231C
	v_cvt_f32_ubyte0_e32 v26, v26                              // 0000003C9258: 7E34231A
	v_lshrrev_b32_e32 v28, 12, v2                              // 0000003C925C: 3238048C
	v_cvt_f32_ubyte0_e32 v1, v1                                // 0000003C9260: 7E022301
	v_fma_mix_f32 v25, v25, v20, v20 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003C9264: CC206019 14522919
	v_fma_mix_f32 v27, v27, v20, v20 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003C926C: CC20601B 1452291B
	v_fma_mix_f32 v26, v26, v20, v20 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003C9274: CC20601A 1452291A
	v_and_or_b32 v28, v28, 15, v32                             // 0000003C927C: D657001C 04811F1C
	v_fma_mix_f32 v1, v1, v20, v20 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003C9284: CC206001 14522901
	v_bfe_u32 v33, v25, 16, 1                                  // 0000003C928C: D6100021 02052119
	v_lshrrev_b32_e32 v34, 24, v17                             // 0000003C9294: 32442298
	v_bfe_u32 v30, v26, 16, 1                                  // 0000003C9298: D610001E 0205211A
	v_cvt_f32_ubyte0_e32 v28, v28                              // 0000003C92A0: 7E38231C
	v_bfe_u32 v35, v1, 16, 1                                   // 0000003C92A4: D6100023 02052101
	v_add3_u32 v25, v25, v33, 0x7fff                           // 0000003C92AC: D6550019 03FE4319 00007FFF
	v_and_b32_e32 v29, 48, v29                                 // 0000003C92B8: 363A3AB0
	v_add3_u32 v26, v26, v30, 0x7fff                           // 0000003C92BC: D655001A 03FE3D1A 00007FFF
	v_bfe_u32 v30, v27, 16, 1                                  // 0000003C92C8: D610001E 0205211B
	v_add3_u32 v1, v1, v35, 0x7fff                             // 0000003C92D0: D6550001 03FE4701 00007FFF
	v_fma_mix_f32 v28, v28, v20, v20 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003C92DC: CC20601C 1452291C
	v_lshlrev_b32_e32 v35, 4, v18                              // 0000003C92E4: 30462484
	.long 0x7e30399a                                           // 0000003C92E8: 7E30399A
	v_add3_u32 v26, v27, v30, 0x7fff                           // 0000003C92EC: D655001A 03FE3D1B 00007FFF
	v_lshrrev_b32_e32 v30, 22, v17                             // 0000003C92F8: 323C2296
	v_bfe_u32 v47, v28, 16, 1                                  // 0000003C92FC: D610002F 0205211C
	v_lshrrev_b32_e32 v27, 20, v2                              // 0000003C9304: 32360494
	v_and_or_b32 v125, 0xffff0000, v25, v24                    // 0000003C9308: D657007D 046232FF FFFF0000
	.long 0x7e30399a                                           // 0000003C9314: 7E30399A
	v_lshrrev_b32_e32 v25, 24, v2                              // 0000003C9318: 32320498
	v_add3_u32 v28, v28, v47, 0x7fff                           // 0000003C931C: D655001C 03FE5F1C 00007FFF
	v_and_b32_e32 v30, 48, v30                                 // 0000003C9328: 363C3CB0
	v_lshrrev_b32_e32 v49, 12, v17                             // 0000003C932C: 3262228C
	v_and_or_b32 v126, 0xffff0000, v1, v24                     // 0000003C9330: D657007E 046202FF FFFF0000
	.long 0x7e303991                                           // 0000003C933C: 7E303991
	v_lshrrev_b32_e32 v50, 14, v17                             // 0000003C9340: 3264228E
	v_lshrrev_b32_e32 v26, 28, v2                              // 0000003C9344: 3234049C
	v_lshrrev_b32_e32 v33, 26, v17                             // 0000003C9348: 3242229A
	v_lshlrev_b32_e32 v17, 2, v18                              // 0000003C934C: 30222482
	v_and_b32_e32 v38, 48, v24                                 // 0000003C9350: 364C30B0
	v_and_or_b32 v27, v27, 15, v30                             // 0000003C9354: D657001B 04791F1B
	v_lshrrev_b32_e32 v1, 4, v3                                // 0000003C935C: 32020684
	v_lshrrev_b32_e32 v36, 8, v3                               // 0000003C9360: 32480688
	v_and_b32_e32 v37, 48, v18                                 // 0000003C9364: 364A24B0
	v_and_or_b32 v31, v31, 15, v38                             // 0000003C9368: D657001F 04991F1F
	v_lshrrev_b32_e32 v40, 2, v18                              // 0000003C9370: 32502482
	v_and_or_b32 v26, v33, 48, v26                             // 0000003C9374: D657001A 04696121
	v_and_b32_e32 v17, 48, v17                                 // 0000003C937C: 362222B0
	v_cvt_f32_ubyte0_e32 v27, v27                              // 0000003C9380: 7E36231B
	v_cvt_f32_ubyte0_e32 v31, v31                              // 0000003C9384: 7E3E231F
	v_lshrrev_b32_e32 v39, 12, v3                              // 0000003C9388: 324E068C
	v_and_or_b32 v33, v36, 15, v37                             // 0000003C938C: D6570021 04951F24
	v_cvt_f32_ubyte0_e32 v26, v26                              // 0000003C9394: 7E34231A
	v_and_or_b32 v1, v1, 15, v17                               // 0000003C9398: D6570001 04451F01
	v_fma_mix_f32 v31, v31, v20, v20 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003C93A0: CC20601F 1452291F
	v_fma_mix_f32 v27, v27, v20, v20 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003C93A8: CC20601B 1452291B
	v_lshrrev_b32_e32 v38, 4, v18                              // 0000003C93B0: 324C2484
	v_fma_mix_f32 v26, v26, v20, v20 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003C93B4: CC20601A 1452291A
	v_cvt_f32_ubyte0_e32 v1, v1                                // 0000003C93BC: 7E022301
	v_bfe_u32 v32, v31, 16, 1                                  // 0000003C93C0: D6100020 0205211F
	v_lshrrev_b32_e32 v41, 8, v18                              // 0000003C93C8: 32522488
	v_lshrrev_b32_e32 v43, 6, v18                              // 0000003C93CC: 32562486
	v_lshrrev_b32_e32 v42, 20, v3                              // 0000003C93D0: 32540694
	v_fma_mix_f32 v1, v1, v20, v20 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003C93D4: CC206001 14522901
	v_add3_u32 v31, v31, v32, 0x7fff                           // 0000003C93DC: D655001F 03FE411F 00007FFF
	v_and_b32_e32 v32, 48, v34                                 // 0000003C93E8: 364044B0
	v_lshrrev_b32_e32 v44, 24, v3                              // 0000003C93EC: 32580698
	v_lshrrev_b32_e32 v45, 28, v3                              // 0000003C93F0: 325A069C
	v_lshrrev_b32_e32 v46, 10, v18                             // 0000003C93F4: 325C248A
	.long 0x7e30399f                                           // 0000003C93F8: 7E30399F
	v_and_b32_e32 v31, 48, v35                                 // 0000003C93FC: 363E46B0
	v_and_or_b32 v25, v25, 15, v32                             // 0000003C9400: D6570019 04811F19
	v_bfe_u32 v32, v26, 16, 1                                  // 0000003C9408: D6100020 0205211A
	v_and_b32_e32 v35, 48, v41                                 // 0000003C9410: 364652B0
	v_and_or_b32 v127, 0xffff0000, v28, v24                    // 0000003C9414: D657007F 046238FF FFFF0000
	.long 0x7e303982                                           // 0000003C9420: 7E303982
	v_and_or_b32 v30, v3, 15, v31                              // 0000003C9424: D657001E 047D1F03
	v_cvt_f32_ubyte0_e32 v25, v25                              // 0000003C942C: 7E322319
	v_and_b32_e32 v28, 48, v40                                 // 0000003C9430: 363850B0
	v_add3_u32 v26, v26, v32, 0x7fff                           // 0000003C9434: D655001A 03FE411A 00007FFF
	v_and_or_b32 v29, v24, 15, v29                             // 0000003C9440: D657001D 04751F18
	v_cvt_f32_ubyte0_e32 v30, v30                              // 0000003C9448: 7E3C231E
	v_fma_mix_f32 v25, v25, v20, v20 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003C944C: CC206019 14522919
	v_and_or_b32 v17, v39, 15, v28                             // 0000003C9454: D6570011 04711F27
	v_cvt_f32_ubyte0_e32 v28, v33                              // 0000003C945C: 7E382321
	v_cvt_f32_ubyte0_e32 v29, v29                              // 0000003C9460: 7E3A231D
	v_fma_mix_f32 v30, v30, v20, v20 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003C9464: CC20601E 1452291E
	v_bfe_u32 v33, v27, 16, 1                                  // 0000003C946C: D6100021 0205211B
	v_cvt_f32_ubyte0_e32 v17, v17                              // 0000003C9474: 7E222311
	v_fma_mix_f32 v28, v28, v20, v20 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003C9478: CC20601C 1452291C
	v_fma_mix_f32 v29, v29, v20, v20 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003C9480: CC20601D 1452291D
	v_and_or_b32 v39, v44, 15, v35                             // 0000003C9488: D6570027 048D1F2C
	v_add3_u32 v27, v27, v33, 0x7fff                           // 0000003C9490: D655001B 03FE431B 00007FFF
	v_fma_mix_f32 v17, v17, v20, v20 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003C949C: CC206011 14522911
	v_and_b32_e32 v33, 48, v43                                 // 0000003C94A4: 364256B0
	v_bfe_u32 v31, v29, 16, 1                                  // 0000003C94A8: D610001F 0205211D
	v_and_or_b32 v41, v46, 48, v45                             // 0000003C94B0: D6570029 04B5612E
	v_cvt_f32_ubyte0_e32 v43, v39                              // 0000003C94B8: 7E562327
	v_lshrrev_b32_e32 v56, 18, v18                             // 0000003C94BC: 32702492
	v_and_or_b32 v37, v42, 15, v33                             // 0000003C94C0: D6570025 04851F2A
	v_add3_u32 v29, v29, v31, 0x7fff                           // 0000003C94C8: D655001D 03FE3F1D 00007FFF
	v_bfe_u32 v31, v25, 16, 1                                  // 0000003C94D4: D610001F 02052119
	v_cvt_f32_ubyte0_e32 v46, v41                              // 0000003C94DC: 7E5C2329
	v_fma_mix_f32 v61, v43, v20, v20 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003C94E0: CC20603D 1452292B
	v_cvt_f32_ubyte0_e32 v42, v37                              // 0000003C94E8: 7E542325
	.long 0x7e30399d                                           // 0000003C94EC: 7E30399D
	v_add3_u32 v25, v25, v31, 0x7fff                           // 0000003C94F0: D6550019 03FE3F19 00007FFF
	v_bfe_u32 v29, v30, 16, 1                                  // 0000003C94FC: D610001D 0205211E
	v_bfe_u32 v31, v1, 16, 1                                   // 0000003C9504: D610001F 02052101
	v_fma_mix_f32 v60, v42, v20, v20 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003C950C: CC20603C 1452292A
	v_and_or_b32 v128, 0xffff0000, v27, v24                    // 0000003C9514: D6570080 046236FF FFFF0000
	.long 0x7e303999                                           // 0000003C9520: 7E303999
	v_add3_u32 v25, v30, v29, 0x7fff                           // 0000003C9524: D6550019 03FE3B1E 00007FFF
	v_bfe_u32 v27, v28, 16, 1                                  // 0000003C9530: D610001B 0205211C
	v_bfe_u32 v29, v17, 16, 1                                  // 0000003C9538: D610001D 02052111
	v_add3_u32 v1, v1, v31, 0x7fff                             // 0000003C9540: D6550001 03FE3F01 00007FFF
	v_and_or_b32 v129, 0xffff0000, v26, v24                    // 0000003C954C: D6570081 046234FF FFFF0000
	.long 0x7e303999                                           // 0000003C9558: 7E303999
	v_add3_u32 v25, v28, v27, 0x7fff                           // 0000003C955C: D6550019 03FE371C 00007FFF
	v_add3_u32 v17, v17, v29, 0x7fff                           // 0000003C9568: D6550011 03FE3B11 00007FFF
	v_fma_mix_f32 v62, v46, v20, v20 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003C9574: CC20603E 1452292E
	v_bfe_u32 v63, v60, 16, 1                                  // 0000003C957C: D610003F 0205213C
	v_and_or_b32 v130, 0xffff0000, v1, v24                     // 0000003C9584: D6570082 046202FF FFFF0000
	.long 0x7e303999                                           // 0000003C9590: 7E303999
	v_and_b32_e32 v25, 48, v38                                 // 0000003C9594: 36324CB0
	v_bfe_u32 v65, v61, 16, 1                                  // 0000003C9598: D6100041 0205213D
	v_bfe_u32 v66, v62, 16, 1                                  // 0000003C95A0: D6100042 0205213E
	v_add3_u32 v60, v60, v63, 0x7fff                           // 0000003C95A8: D655003C 03FE7F3C 00007FFF
	v_and_or_b32 v132, 0xffff0000, v17, v24                    // 0000003C95B4: D6570084 046222FF FFFF0000
	.long 0x7e303983                                           // 0000003C95C0: 7E303983
	v_add3_u32 v61, v61, v65, 0x7fff                           // 0000003C95C4: D655003D 03FE833D 00007FFF
	v_add3_u32 v62, v62, v66, 0x7fff                           // 0000003C95D0: D655003E 03FE853E 00007FFF
	v_lshrrev_b32_e32 v53, 14, v18                             // 0000003C95DC: 326A248E
	v_lshrrev_b32_e32 v54, 8, v4                               // 0000003C95E0: 326C0888
	v_and_or_b32 v34, v24, 15, v25                             // 0000003C95E4: D6570022 04651F18
	s_clause 0x2                                               // 0000003C95EC: BF850002
	global_load_b128 v[25:28], v21, s[6:7] offset:1920         // 0000003C95F0: DC5E0780 19060015
	global_load_b128 v[29:32], v21, s[6:7] offset:2560         // 0000003C95F8: DC5E0A00 1D060015
	global_load_b128 v[41:44], v21, s[6:7] offset:656          // 0000003C9600: DC5E0290 29060015
	v_lshrrev_b32_e32 v58, 22, v18                             // 0000003C9608: 32742496
	v_lshrrev_b32_e32 v51, 12, v18                             // 0000003C960C: 3266248C
	v_cvt_f32_ubyte0_e32 v38, v34                              // 0000003C9610: 7E4C2322
	global_load_b128 v[33:36], v21, s[6:7] offset:3200         // 0000003C9614: DC5E0C80 21060015
	v_lshrrev_b32_e32 v55, 20, v18                             // 0000003C961C: 326E2494
	v_lshrrev_b32_e32 v1, 24, v18                              // 0000003C9620: 32022498
	v_lshrrev_b32_e32 v59, 26, v18                             // 0000003C9624: 3276249A
	v_fma_mix_f32 v45, v38, v20, v20 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003C9628: CC20602D 14522926
	global_load_b128 v[37:40], v21, s[6:7] offset:16           // 0000003C9630: DC5E0010 25060015
	v_lshrrev_b32_e32 v3, 28, v4                               // 0000003C9638: 3206089C
	v_and_b32_e32 v136, 48, v53                                // 0000003C963C: 37106AB0
	v_and_b32_e32 v138, 48, v58                                // 0000003C9640: 371474B0
	v_bfe_u32 v47, v45, 16, 1                                  // 0000003C9644: D610002F 0205212D
	v_and_b32_e32 v52, 15, v4                                  // 0000003C964C: 3668088F
	v_and_or_b32 v140, v59, 48, v3                             // 0000003C9650: D657008C 040D613B
	v_lshrrev_b32_e32 v57, 12, v4                              // 0000003C9658: 3272088C
	v_and_b32_e32 v117, 48, v49                                // 0000003C965C: 36EA62B0
	v_add3_u32 v64, v45, v47, 0x7fff                           // 0000003C9660: D6550040 03FE5F2D 00007FFF
	global_load_b128 v[45:48], v21, s[6:7] offset:1296         // 0000003C966C: DC5E0510 2D060015
	v_and_b32_e32 v133, 48, v50                                // 0000003C9674: 370A64B0
	v_and_or_b32 v135, v51, 48, v52                            // 0000003C9678: D6570087 04D16133
	global_load_b128 v[49:52], v21, s[6:7] offset:3840         // 0000003C9680: DC5E0F00 31060015
	.long 0x7e3039c0                                           // 0000003C9688: 7E3039C0
	v_and_b32_e32 v139, 48, v1                                 // 0000003C968C: 371602B0
	s_clause 0x2                                               // 0000003C9690: BF850002
	global_load_b128 v[73:76], v21, s[6:7] offset:1312         // 0000003C9694: DC5E0520 49060015
	global_load_b128 v[77:80], v21, s[6:7] offset:1328         // 0000003C969C: DC5E0530 4D060015
	global_load_b128 v[81:84], v21, s[6:7] offset:1936         // 0000003C96A4: DC5E0790 51060015
	v_lshrrev_b32_e32 v124, 4, v4                              // 0000003C96AC: 32F80884
	v_lshrrev_b32_e32 v131, 20, v4                             // 0000003C96B0: 33060894
	v_and_or_b32 v134, 0xffff0000, v60, v24                    // 0000003C96B4: D6570086 046278FF FFFF0000
	.long 0x7e3039bd                                           // 0000003C96C0: 7E3039BD
	v_and_b32_e32 v60, 48, v56                                 // 0000003C96C4: 367870B0
	s_clause 0x2                                               // 0000003C96C8: BF850002
	global_load_b128 v[85:88], v21, s[6:7] offset:2576         // 0000003C96CC: DC5E0A10 55060015
	global_load_b128 v[89:92], v21, s[6:7] offset:3216         // 0000003C96D4: DC5E0C90 59060015
	global_load_b128 v[93:96], v21, s[6:7] offset:3856         // 0000003C96DC: DC5E0F10 5D060015
	v_lshrrev_b32_e32 v123, 4, v2                              // 0000003C96E4: 32F60484
	v_lshrrev_b32_e32 v17, 24, v4                              // 0000003C96E8: 32220898
	v_and_or_b32 v137, 0xffff0000, v62, v24                    // 0000003C96EC: D6570089 04627CFF FFFF0000
	.long 0x7e303992                                           // 0000003C96F8: 7E303992
	.long 0xd7000312                                           // 0000003C96FC: D7000312
	v_cndmask_b32_e32 v1, s6, v21, vcc_lo                      // 0000003C9700: 02022A06
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003C9704: BF870191
	v_add_co_ci_u32_e64 v53, null, s7, 0, s3                   // 0000003C9708: D5207C35 000D0007
	v_and_b32_e32 v56, 48, v24                                 // 0000003C9710: 367030B0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003C9714: BF870093
	.long 0xd7006a79                                           // 0000003C9718: D7006A79
	v_cndmask_b32_e32 v1, 0x1000, v18, vcc_lo                  // 0000003C971C: 020224FF 00001000
	v_add_co_ci_u32_e64 v122, null, 0, v53, vcc_lo             // 0000003C9724: D5207C7A 01AA6A80
	s_delay_alu instid0(VALU_DEP_3)                            // 0000003C972C: BF870003
	v_and_or_b32 v58, v54, 15, v56                             // 0000003C9730: D657003A 04E11F36
	v_and_b32_e32 v18, 48, v55                                 // 0000003C9738: 36246EB0
	v_and_or_b32 v1, v57, 15, v60                              // 0000003C973C: D6570001 04F11F39
	global_load_b128 v[53:56], v[121:122], off offset:384      // 0000003C9744: DC5E0180 357C0079
	v_and_or_b32 v141, v2, 15, v117                            // 0000003C974C: D657008D 05D51F02
	v_cvt_f32_ubyte0_e32 v3, v58                               // 0000003C9754: 7E06233A
	s_clause 0x3                                               // 0000003C9758: BF850003
	global_load_b128 v[57:60], v21, s[6:7] offset:32           // 0000003C975C: DC5E0020 39060015
	global_load_b128 v[61:64], v21, s[6:7] offset:48           // 0000003C9764: DC5E0030 3D060015
	global_load_b128 v[65:68], v21, s[6:7] offset:672          // 0000003C976C: DC5E02A0 41060015
	global_load_b128 v[69:72], v21, s[6:7] offset:688          // 0000003C9774: DC5E02B0 45060015
	v_cvt_f32_ubyte0_e32 v1, v1                                // 0000003C977C: 7E022301
	v_fma_mix_f32 v3, v3, v20, v20 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003C9780: CC206003 14522903
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003C9788: BF870112
	v_fma_mix_f32 v1, v1, v20, v20 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003C978C: CC206001 14522901
	v_bfe_u32 v97, v3, 16, 1                                   // 0000003C9794: D6100061 02052103
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003C979C: BF870112
	v_bfe_u32 v109, v1, 16, 1                                  // 0000003C97A0: D610006D 02052101
	v_add3_u32 v3, v3, v97, 0x7fff                             // 0000003C97A8: D6550003 03FEC303 00007FFF
	s_clause 0x2                                               // 0000003C97B4: BF850002
	global_load_b128 v[97:100], v21, s[6:7] offset:1952        // 0000003C97B8: DC5E07A0 61060015
	global_load_b128 v[101:104], v21, s[6:7] offset:1968       // 0000003C97C0: DC5E07B0 65060015
	global_load_b128 v[105:108], v21, s[6:7] offset:3872       // 0000003C97C8: DC5E0F20 69060015
	v_add3_u32 v1, v1, v109, 0x7fff                            // 0000003C97D0: D6550001 03FEDB01 00007FFF
	s_clause 0x1                                               // 0000003C97DC: BF850001
	global_load_b128 v[109:112], v21, s[6:7] offset:2592       // 0000003C97E0: DC5E0A20 6D060015
	global_load_b128 v[113:116], v21, s[6:7] offset:2608       // 0000003C97E8: DC5E0A30 71060015
	.long 0x7e303983                                           // 0000003C97F0: 7E303983
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003C97F4: BF870001
	v_and_or_b32 v142, 0xffff0000, v1, v24                     // 0000003C97F8: D657008E 046202FF FFFF0000
	.long 0x7e303984                                           // 0000003C9804: 7E303984
	s_waitcnt vmcnt(25)                                        // 0000003C9808: BF8967F7
	v_dot2_f32_bf16 v5, v5, v23, 0                             // 0000003C980C: CC1A4005 1A022F05
	s_waitcnt vmcnt(24)                                        // 0000003C9814: BF8963F7
	v_dot2_f32_bf16 v3, v9, v23, 0                             // 0000003C9818: CC1A4003 1A022F09
	s_waitcnt vmcnt(23)                                        // 0000003C9820: BF895FF7
	v_dot2_f32_bf16 v13, v13, v23, 0                           // 0000003C9824: CC1A400D 1A022F0D
	v_dot2_f32_bf16 v5, v6, v22, v5                            // 0000003C982C: CC1A4005 1C162D06
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000003C9834: BF870223
	v_dot2_f32_bf16 v6, v10, v22, v3                           // 0000003C9838: CC1A4006 1C0E2D0A
	v_and_or_b32 v10, v123, 15, v133                           // 0000003C9840: D657000A 06151F7B
	v_dot2_f32_bf16 v13, v14, v22, v13                         // 0000003C9848: CC1A400D 1C362D0E
	v_cvt_f32_ubyte0_e32 v123, v135                            // 0000003C9850: 7EF62387
	v_dot2_f32_bf16 v5, v7, v125, v5                           // 0000003C9854: CC1A4005 1C16FB07
	v_dot2_f32_bf16 v6, v11, v125, v6                          // 0000003C985C: CC1A4006 1C1AFB0B
	v_and_or_b32 v11, v124, 15, v136                           // 0000003C9864: D657000B 06211F7C
	v_and_or_b32 v124, v131, 15, v138                          // 0000003C986C: D657007C 06291F83
	v_cvt_f32_ubyte0_e32 v133, v10                             // 0000003C9874: 7F0A230A
	v_dot2_f32_bf16 v5, v8, v126, v5                           // 0000003C9878: CC1A4005 1C16FD08
	v_dot2_f32_bf16 v131, v12, v126, v6                        // 0000003C9880: CC1A4083 1C1AFD0C
	global_load_b128 v[6:9], v[121:122], off offset:400        // 0000003C9888: DC5E0190 067C0079
	v_and_or_b32 v12, v17, 15, v139                            // 0000003C9890: D657000C 062D1F11
	v_dot2_f32_bf16 v10, v15, v125, v13                        // 0000003C9898: CC1A400A 1C36FB0F
	v_cvt_f32_ubyte0_e32 v14, v140                             // 0000003C98A0: 7E1C238C
	v_cvt_f32_ubyte0_e32 v17, v141                             // 0000003C98A4: 7E22238D
	v_cvt_f32_ubyte0_e32 v15, v11                              // 0000003C98A8: 7E1E230B
	v_cvt_f32_ubyte0_e32 v135, v12                             // 0000003C98AC: 7F0E230C
	v_dot2_f32_bf16 v136, v16, v126, v10                       // 0000003C98B0: CC1A4088 1C2AFD10
	global_load_b128 v[10:13], v[121:122], off offset:416      // 0000003C98B8: DC5E01A0 0A7C0079
	v_and_or_b32 v16, v24, 15, v18                             // 0000003C98C0: D6570010 04491F18
	s_clause 0x1                                               // 0000003C98C8: BF850001
	global_load_b128 v[1:4], v21, s[6:7] offset:3232           // 0000003C98CC: DC5E0CA0 01060015
	global_load_b128 v[117:120], v21, s[6:7] offset:3248       // 0000003C98D4: DC5E0CB0 75060015
	v_fma_mix_f32 v123, v123, v20, v20 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003C98DC: CC20607B 1452297B
	v_cvt_f32_ubyte0_e32 v124, v124                            // 0000003C98E4: 7EF8237C
	v_fma_mix_f32 v14, v14, v20, v20 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003C98E8: CC20600E 1452290E
	v_fma_mix_f32 v17, v17, v20, v20 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003C98F0: CC206011 14522911
	v_cvt_f32_ubyte0_e32 v16, v16                              // 0000003C98F8: 7E202310
	v_fma_mix_f32 v18, v133, v20, v20 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003C98FC: CC206012 14522985
	v_bfe_u32 v133, v123, 16, 1                                // 0000003C9904: D6100085 0205217B
	v_fma_mix_f32 v15, v15, v20, v20 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003C990C: CC20600F 1452290F
	v_fma_mix_f32 v124, v124, v20, v20 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003C9914: CC20607C 1452297C
	v_bfe_u32 v138, v14, 16, 1                                 // 0000003C991C: D610008A 0205210E
	v_bfe_u32 v139, v17, 16, 1                                 // 0000003C9924: D610008B 02052111
	v_fma_mix_f32 v16, v16, v20, v20 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003C992C: CC206010 14522910
	v_add3_u32 v133, v123, v133, 0x7fff                        // 0000003C9934: D6550085 03FF0B7B 00007FFF
	v_bfe_u32 v123, v15, 16, 1                                 // 0000003C9940: D610007B 0205210F
	v_add3_u32 v138, v14, v138, 0x7fff                         // 0000003C9948: D655008A 03FF150E 00007FFF
	v_add3_u32 v139, v17, v139, 0x7fff                         // 0000003C9954: D655008B 03FF1711 00007FFF
	v_bfe_u32 v14, v16, 16, 1                                  // 0000003C9960: D610000E 02052110
	v_bfe_u32 v17, v124, 16, 1                                 // 0000003C9968: D6100011 0205217C
	v_add3_u32 v141, v15, v123, 0x7fff                         // 0000003C9970: D655008D 03FEF70F 00007FFF
	v_fma_mix_f32 v135, v135, v20, v20 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003C997C: CC206087 14522987
	v_bfe_u32 v20, v18, 16, 1                                  // 0000003C9984: D6100014 02052112
	v_add3_u32 v140, v16, v14, 0x7fff                          // 0000003C998C: D655008C 03FE1D10 00007FFF
	v_add3_u32 v143, v124, v17, 0x7fff                         // 0000003C9998: D655008F 03FE237C 00007FFF
	s_clause 0x1                                               // 0000003C99A4: BF850001
	global_load_b128 v[14:17], v21, s[6:7] offset:3888         // 0000003C99A8: DC5E0F30 0E060015
	global_load_b128 v[121:124], v[121:122], off offset:432    // 0000003C99B0: DC5E01B0 797C0079
	v_add3_u32 v18, v18, v20, 0x7fff                           // 0000003C99B8: D6550012 03FE2912 00007FFF
	v_bfe_u32 v20, v135, 16, 1                                 // 0000003C99C4: D6100014 02052187
	.long 0xd59c0818                                           // 0000003C99CC: D59C0818
	v_cndmask_b32_e32 v0, v140, v128, vcc_lo                   // 0000003C99D0: 0201018C
	.long 0xd59c0815                                           // 0000003C99D4: D59C0815
	v_cndmask_b32_e32 v0, v133, v128, vcc_lo                   // 0000003C99D8: 02010185
	.long 0x7f2a3998                                           // 0000003C99DC: 7F2A3998
	.long 0xd59c0885                                           // 0000003C99E0: D59C0885
	v_cndmask_b32_e32 v0, v139, v128, vcc_lo                   // 0000003C99E4: 0201018B
	v_add3_u32 v20, v135, v20, 0x7fff                          // 0000003C99E8: D6550014 03FE2987 00007FFF
	.long 0xd59c4885                                           // 0000003C99F4: D59C4885
	v_cndmask_b32_e32 v0, v24, v128, vcc_lo                    // 0000003C99F8: 02010118
	v_and_or_b32 v135, 0xffff0000, v143, v24                   // 0000003C99FC: D6570087 04631EFF FFFF0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000003C9A08: BF870223
	.long 0x7e303994                                           // 0000003C9A0C: 7E303994
	v_and_or_b32 v20, 0xffff0000, v141, v21                    // 0000003C9A10: D6570014 04571AFF FFFF0000
	v_and_or_b32 v18, 0xffff0000, v18, v133                    // 0000003C9A1C: D6570012 061624FF FFFF0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 0000003C9A28: BF870153
	v_and_or_b32 v24, 0xffff0000, v138, v24                    // 0000003C9A2C: D6570018 046314FF FFFF0000
	s_waitcnt vmcnt(28)                                        // 0000003C9A38: BF8973F7
	v_dot2_f32_bf16 v21, v25, v23, 0                           // 0000003C9A3C: CC1A4015 1A022F19
	s_waitcnt vmcnt(27)                                        // 0000003C9A44: BF896FF7
	v_dot2_f32_bf16 v25, v29, v23, 0                           // 0000003C9A48: CC1A4019 1A022F1D
	v_dot2_f32_bf16 v21, v26, v22, v21                         // 0000003C9A50: CC1A4015 1C562D1A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000003C9A58: BF8701B2
	v_dot2_f32_bf16 v25, v30, v22, v25                         // 0000003C9A5C: CC1A4019 1C662D1E
	s_waitcnt vmcnt(25)                                        // 0000003C9A64: BF8967F7
	v_dot2_f32_bf16 v29, v33, v23, 0                           // 0000003C9A68: CC1A401D 1A022F21
	v_dot2_f32_bf16 v21, v27, v125, v21                        // 0000003C9A70: CC1A4015 1C56FB1B
	v_dot2_f32_bf16 v27, v41, v18, v131                        // 0000003C9A78: CC1A401B 1E0E2529
	s_waitcnt vmcnt(24)                                        // 0000003C9A80: BF8963F7
	v_dot2_f32_bf16 v5, v37, v18, v5                           // 0000003C9A84: CC1A4005 1C162525
	v_dot2_f32_bf16 v26, v34, v22, v29                         // 0000003C9A8C: CC1A401A 1C762D22
	v_dot2_f32_bf16 v25, v31, v125, v25                        // 0000003C9A94: CC1A4019 1C66FB1F
	v_dot2_f32_bf16 v21, v28, v126, v21                        // 0000003C9A9C: CC1A4015 1C56FD1C
	v_dot2_f32_bf16 v27, v42, v127, v27                        // 0000003C9AA4: CC1A401B 1C6EFF2A
	v_dot2_f32_bf16 v5, v38, v127, v5                          // 0000003C9AAC: CC1A4005 1C16FF26
	v_dot2_f32_bf16 v26, v35, v125, v26                        // 0000003C9AB4: CC1A401A 1C6AFB23
	v_dot2_f32_bf16 v25, v32, v126, v25                        // 0000003C9ABC: CC1A4019 1C66FD20
	s_waitcnt vmcnt(23)                                        // 0000003C9AC4: BF895FF7
	v_dot2_f32_bf16 v30, v45, v18, v136                        // 0000003C9AC8: CC1A401E 1E22252D
	v_dot2_f32_bf16 v27, v43, v128, v27                        // 0000003C9AD0: CC1A401B 1C6F012B
	v_dot2_f32_bf16 v5, v39, v128, v5                          // 0000003C9AD8: CC1A4005 1C170127
	s_waitcnt vmcnt(22)                                        // 0000003C9AE0: BF895BF7
	v_dot2_f32_bf16 v33, v49, v23, 0                           // 0000003C9AE4: CC1A4021 1A022F31
	v_dot2_f32_bf16 v26, v36, v126, v26                        // 0000003C9AEC: CC1A401A 1C6AFD24
	v_dot2_f32_bf16 v30, v46, v127, v30                        // 0000003C9AF4: CC1A401E 1C7AFF2E
	v_dot2_f32_bf16 v27, v44, v129, v27                        // 0000003C9AFC: CC1A401B 1C6F032C
	v_dot2_f32_bf16 v5, v40, v129, v5                          // 0000003C9B04: CC1A4005 1C170328
	v_dot2_f32_bf16 v29, v50, v22, v33                         // 0000003C9B0C: CC1A401D 1C862D32
	s_waitcnt vmcnt(19)                                        // 0000003C9B14: BF894FF7
	v_dot2_f32_bf16 v21, v81, v18, v21                         // 0000003C9B18: CC1A4015 1C562551
	v_dot2_f32_bf16 v30, v47, v128, v30                        // 0000003C9B20: CC1A401E 1C7B012F
	s_waitcnt vmcnt(17)                                        // 0000003C9B28: BF8947F7
	v_dot2_f32_bf16 v26, v89, v18, v26                         // 0000003C9B2C: CC1A401A 1C6A2559
	v_dot2_f32_bf16 v25, v85, v18, v25                         // 0000003C9B34: CC1A4019 1C662555
	v_dot2_f32_bf16 v29, v51, v125, v29                        // 0000003C9B3C: CC1A401D 1C76FB33
	v_dot2_f32_bf16 v21, v82, v127, v21                        // 0000003C9B44: CC1A4015 1C56FF52
	v_dot2_f32_bf16 v28, v48, v129, v30                        // 0000003C9B4C: CC1A401C 1C7B0330
	v_dot2_f32_bf16 v26, v90, v127, v26                        // 0000003C9B54: CC1A401A 1C6AFF5A
	v_dot2_f32_bf16 v25, v86, v127, v25                        // 0000003C9B5C: CC1A4019 1C66FF56
	v_dot2_f32_bf16 v29, v52, v126, v29                        // 0000003C9B64: CC1A401D 1C76FD34
	v_dot2_f32_bf16 v21, v83, v128, v21                        // 0000003C9B6C: CC1A4015 1C570153
	v_dot2_f32_bf16 v28, v73, v130, v28                        // 0000003C9B74: CC1A401C 1C730549
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003C9B7C: BF870194
	v_dot2_f32_bf16 v25, v87, v128, v25                        // 0000003C9B80: CC1A4019 1C670157
	v_dot2_f32_bf16 v21, v84, v129, v21                        // 0000003C9B88: CC1A4015 1C570354
	s_waitcnt vmcnt(15)                                        // 0000003C9B90: BF893FF7
	v_dot2_f32_bf16 v23, v53, v23, 0                           // 0000003C9B94: CC1A4017 1A022F35
	s_waitcnt vmcnt(14)                                        // 0000003C9B9C: BF893BF7
	v_dot2_f32_bf16 v5, v57, v130, v5                          // 0000003C9BA0: CC1A4005 1C170539
	s_waitcnt vmcnt(12)                                        // 0000003C9BA8: BF8933F7
	v_dot2_f32_bf16 v27, v65, v130, v27                        // 0000003C9BAC: CC1A401B 1C6F0541
	v_dot2_f32_bf16 v22, v54, v22, v23                         // 0000003C9BB4: CC1A4016 1C5E2D36
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003C9BBC: BF870193
	v_dot2_f32_bf16 v5, v58, v132, v5                          // 0000003C9BC0: CC1A4005 1C17093A
	v_dot2_f32_bf16 v23, v66, v132, v27                        // 0000003C9BC8: CC1A4017 1C6F0942
	v_dot2_f32_bf16 v27, v74, v132, v28                        // 0000003C9BD0: CC1A401B 1C73094A
	v_dot2_f32_bf16 v28, v93, v18, v29                         // 0000003C9BD8: CC1A401C 1C76255D
	v_dot2_f32_bf16 v22, v55, v125, v22                        // 0000003C9BE0: CC1A4016 1C5AFB37
	v_dot2_f32_bf16 v5, v59, v134, v5                          // 0000003C9BE8: CC1A4005 1C170D3B
	v_dot2_f32_bf16 v23, v67, v134, v23                        // 0000003C9BF0: CC1A4017 1C5F0D43
	v_dot2_f32_bf16 v27, v75, v134, v27                        // 0000003C9BF8: CC1A401B 1C6F0D4B
	v_dot2_f32_bf16 v28, v94, v127, v28                        // 0000003C9C00: CC1A401C 1C72FF5E
	v_dot2_f32_bf16 v22, v56, v126, v22                        // 0000003C9C08: CC1A4016 1C5AFD38
	v_dot2_f32_bf16 v5, v60, v137, v5                          // 0000003C9C10: CC1A4005 1C17133C
	v_dot2_f32_bf16 v23, v68, v137, v23                        // 0000003C9C18: CC1A4017 1C5F1344
	v_dot2_f32_bf16 v27, v76, v137, v27                        // 0000003C9C20: CC1A401B 1C6F134C
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000003C9C28: BF8701A3
	v_dot2_f32_bf16 v5, v61, v20, v5                           // 0000003C9C2C: CC1A4005 1C16293D
	s_waitcnt vmcnt(11)                                        // 0000003C9C34: BF892FF7
	v_dot2_f32_bf16 v23, v69, v20, v23                         // 0000003C9C38: CC1A4017 1C5E2945
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003C9C40: BF870193
	v_dot2_f32_bf16 v27, v77, v20, v27                         // 0000003C9C44: CC1A401B 1C6E294D
	v_dot2_f32_bf16 v5, v62, v142, v5                          // 0000003C9C4C: CC1A4005 1C171D3E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003C9C54: BF870193
	v_dot2_f32_bf16 v23, v70, v142, v23                        // 0000003C9C58: CC1A4017 1C5F1D46
	v_dot2_f32_bf16 v27, v78, v142, v27                        // 0000003C9C60: CC1A401B 1C6F1D4E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003C9C68: BF870193
	v_dot2_f32_bf16 v5, v63, v135, v5                          // 0000003C9C6C: CC1A4005 1C170F3F
	v_dot2_f32_bf16 v23, v71, v135, v23                        // 0000003C9C74: CC1A4017 1C5F0F47
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003C9C7C: BF870193
	v_dot2_f32_bf16 v27, v79, v135, v27                        // 0000003C9C80: CC1A401B 1C6F0F4F
	v_dot2_f32_bf16 v5, v64, v24, v5                           // 0000003C9C88: CC1A4005 1C163140
	s_waitcnt vmcnt(5)                                         // 0000003C9C90: BF8917F7
	v_dot2_f32_bf16 v6, v6, v18, v22                           // 0000003C9C94: CC1A4006 1C5A2506
	v_dot2_f32_bf16 v18, v72, v24, v23                         // 0000003C9C9C: CC1A4012 1C5E3148
	v_dot2_f32_bf16 v23, v91, v128, v26                        // 0000003C9CA4: CC1A4017 1C6B015B
	v_dot2_f32_bf16 v22, v80, v24, v27                         // 0000003C9CAC: CC1A4016 1C6E3150
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003C9CB4: BF870214
	v_dot2_f32_bf16 v26, v7, v127, v6                          // 0000003C9CB8: CC1A401A 1C1AFF07
	v_add_f32_e32 v7, 0, v18                                   // 0000003C9CC0: 060E2480
	v_dot2_f32_bf16 v18, v95, v128, v28                        // 0000003C9CC4: CC1A4012 1C73015F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003C9CCC: BF870214
	v_dual_add_f32 v6, 0, v5 :: v_dual_add_f32 v5, 0, v22      // 0000003C9CD0: C9080A80 06042C80
	v_dot2_f32_bf16 v8, v8, v128, v26                          // 0000003C9CD8: CC1A4008 1C6B0108
	v_dot2_f32_bf16 v22, v88, v129, v25                        // 0000003C9CE0: CC1A4016 1C670358
	v_dot2_f32_bf16 v23, v92, v129, v23                        // 0000003C9CE8: CC1A4017 1C5F035C
	v_dot2_f32_bf16 v18, v96, v129, v18                        // 0000003C9CF0: CC1A4012 1C4B0360
	s_delay_alu instid0(VALU_DEP_4)                            // 0000003C9CF8: BF870004
	v_dot2_f32_bf16 v8, v9, v129, v8                           // 0000003C9CFC: CC1A4008 1C230309
	v_dot2_f32_bf16 v9, v97, v130, v21                         // 0000003C9D04: CC1A4009 1C570561
	v_dot2_f32_bf16 v21, v109, v130, v22                       // 0000003C9D0C: CC1A4015 1C5B056D
	s_waitcnt vmcnt(3)                                         // 0000003C9D14: BF890FF7
	v_dot2_f32_bf16 v1, v1, v130, v23                          // 0000003C9D18: CC1A4001 1C5F0501
	v_dot2_f32_bf16 v18, v105, v130, v18                       // 0000003C9D20: CC1A4012 1C4B0569
	v_dot2_f32_bf16 v8, v10, v130, v8                          // 0000003C9D28: CC1A4008 1C23050A
	v_dot2_f32_bf16 v9, v98, v132, v9                          // 0000003C9D30: CC1A4009 1C270962
	v_dot2_f32_bf16 v10, v110, v132, v21                       // 0000003C9D38: CC1A400A 1C57096E
	v_dot2_f32_bf16 v1, v2, v132, v1                           // 0000003C9D40: CC1A4001 1C070902
	v_dot2_f32_bf16 v2, v106, v132, v18                        // 0000003C9D48: CC1A4002 1C4B096A
	v_dot2_f32_bf16 v8, v11, v132, v8                          // 0000003C9D50: CC1A4008 1C23090B
	v_dot2_f32_bf16 v9, v99, v134, v9                          // 0000003C9D58: CC1A4009 1C270D63
	v_dot2_f32_bf16 v10, v111, v134, v10                       // 0000003C9D60: CC1A400A 1C2B0D6F
	v_dot2_f32_bf16 v1, v3, v134, v1                           // 0000003C9D68: CC1A4001 1C070D03
	v_dot2_f32_bf16 v2, v107, v134, v2                         // 0000003C9D70: CC1A4002 1C0B0D6B
	v_dot2_f32_bf16 v3, v12, v134, v8                          // 0000003C9D78: CC1A4003 1C230D0C
	v_dot2_f32_bf16 v8, v100, v137, v9                         // 0000003C9D80: CC1A4008 1C271364
	v_dot2_f32_bf16 v9, v112, v137, v10                        // 0000003C9D88: CC1A4009 1C2B1370
	v_dot2_f32_bf16 v1, v4, v137, v1                           // 0000003C9D90: CC1A4001 1C071304
	v_dot2_f32_bf16 v2, v108, v137, v2                         // 0000003C9D98: CC1A4002 1C0B136C
	v_dot2_f32_bf16 v3, v13, v137, v3                          // 0000003C9DA0: CC1A4003 1C0F130D
	v_dot2_f32_bf16 v4, v101, v20, v8                          // 0000003C9DA8: CC1A4004 1C222965
	v_dot2_f32_bf16 v8, v113, v20, v9                          // 0000003C9DB0: CC1A4008 1C262971
	s_waitcnt vmcnt(2)                                         // 0000003C9DB8: BF890BF7
	v_dot2_f32_bf16 v1, v117, v20, v1                          // 0000003C9DBC: CC1A4001 1C062975
	s_waitcnt vmcnt(1)                                         // 0000003C9DC4: BF8907F7
	v_dot2_f32_bf16 v2, v14, v20, v2                           // 0000003C9DC8: CC1A4002 1C0A290E
	s_waitcnt vmcnt(0)                                         // 0000003C9DD0: BF8903F7
	v_dot2_f32_bf16 v3, v121, v20, v3                          // 0000003C9DD4: CC1A4003 1C0E2979
	v_dot2_f32_bf16 v4, v102, v142, v4                         // 0000003C9DDC: CC1A4004 1C131D66
	v_dot2_f32_bf16 v8, v114, v142, v8                         // 0000003C9DE4: CC1A4008 1C231D72
	v_dot2_f32_bf16 v1, v118, v142, v1                         // 0000003C9DEC: CC1A4001 1C071D76
	v_dot2_f32_bf16 v2, v15, v142, v2                          // 0000003C9DF4: CC1A4002 1C0B1D0F
	v_dot2_f32_bf16 v3, v122, v142, v3                         // 0000003C9DFC: CC1A4003 1C0F1D7A
	v_dot2_f32_bf16 v4, v103, v135, v4                         // 0000003C9E04: CC1A4004 1C130F67
	v_dot2_f32_bf16 v8, v115, v135, v8                         // 0000003C9E0C: CC1A4008 1C230F73
	v_dot2_f32_bf16 v1, v119, v135, v1                         // 0000003C9E14: CC1A4001 1C070F77
	v_dot2_f32_bf16 v2, v16, v135, v2                          // 0000003C9E1C: CC1A4002 1C0B0F10
	v_dot2_f32_bf16 v3, v123, v135, v3                         // 0000003C9E24: CC1A4003 1C0F0F7B
	v_dot2_f32_bf16 v4, v104, v24, v4                          // 0000003C9E2C: CC1A4004 1C123168
	v_dot2_f32_bf16 v8, v116, v24, v8                          // 0000003C9E34: CC1A4008 1C223174
	v_dot2_f32_bf16 v1, v120, v24, v1                          // 0000003C9E3C: CC1A4001 1C063178
	v_dot2_f32_bf16 v2, v17, v24, v2                           // 0000003C9E44: CC1A4002 1C0A3111
	v_dot2_f32_bf16 v3, v124, v24, v3                          // 0000003C9E4C: CC1A4003 1C0E317C
	v_add_f32_e32 v12, 0, v4                                   // 0000003C9E54: 06180880
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003C9E58: BF870194
	v_dual_add_f32 v10, 0, v8 :: v_dual_add_f32 v11, 0, v1     // 0000003C9E5C: C9081080 0A0A0280
	v_dual_add_f32 v8, 0, v2 :: v_dual_add_f32 v9, 0, v3       // 0000003C9E64: C9080480 08080680
	s_or_b32 exec_lo, exec_lo, s4                              // 0000003C9E6C: 8C7E047E
	.long 0xd71f0001                                           // 0000003C9E70: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000003C9E74: 020100C1
	s_mov_b32 s3, exec_lo                                      // 0000003C9E78: BE83007E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000003C9E7C: BF870121
	v_xor_b32_e32 v2, 8, v1                                    // 0000003C9E80: 3A040288
	v_xor_b32_e32 v18, 4, v1                                   // 0000003C9E84: 3A240284
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 0000003C9E88: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 0000003C9E8C: 02040501
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003C9E90: BF870113
	v_cmp_gt_u32_e32 vcc_lo, 32, v18                           // 0000003C9E94: 7C9824A0
	v_lshlrev_b32_e32 v2, 2, v2                                // 0000003C9E98: 30040482
	ds_bpermute_b32 v3, v2, v7                                 // 0000003C9E9C: DACC0000 03000702
	ds_bpermute_b32 v15, v2, v11                               // 0000003C9EA4: DACC0000 0F000B02
	s_waitcnt lgkmcnt(1)                                       // 0000003C9EAC: BF89FC17
	v_add_f32_e32 v3, v7, v3                                   // 0000003C9EB0: 06060707
	s_waitcnt lgkmcnt(0)                                       // 0000003C9EB4: BF89FC07
	v_add_f32_e32 v7, v11, v15                                 // 0000003C9EB8: 060E1F0B
	ds_bpermute_b32 v4, v2, v6                                 // 0000003C9EBC: DACC0000 04000602
	ds_bpermute_b32 v14, v2, v5                                // 0000003C9EC4: DACC0000 0E000502
	ds_bpermute_b32 v17, v2, v9                                // 0000003C9ECC: DACC0000 11000902
	ds_bpermute_b32 v13, v2, v12                               // 0000003C9ED4: DACC0000 0D000C02
	ds_bpermute_b32 v16, v2, v10                               // 0000003C9EDC: DACC0000 10000A02
	v_cndmask_b32_e32 v18, v1, v18, vcc_lo                     // 0000003C9EE4: 02242501
	ds_bpermute_b32 v2, v2, v8                                 // 0000003C9EE8: DACC0000 02000802
	v_lshlrev_b32_e32 v18, 2, v18                              // 0000003C9EF0: 30242482
	s_waitcnt lgkmcnt(4)                                       // 0000003C9EF4: BF89FC47
	v_dual_add_f32 v4, v6, v4 :: v_dual_add_f32 v5, v5, v14    // 0000003C9EF8: C9080906 04041D05
	s_waitcnt lgkmcnt(3)                                       // 0000003C9F00: BF89FC37
	v_add_f32_e32 v9, v9, v17                                  // 0000003C9F04: 06122309
	ds_bpermute_b32 v14, v18, v7                               // 0000003C9F08: DACC0000 0E000712
	s_waitcnt lgkmcnt(3)                                       // 0000003C9F10: BF89FC37
	v_add_f32_e32 v6, v12, v13                                 // 0000003C9F14: 060C1B0C
	ds_bpermute_b32 v11, v18, v4                               // 0000003C9F18: DACC0000 0B000412
	ds_bpermute_b32 v13, v18, v5                               // 0000003C9F20: DACC0000 0D000512
	s_waitcnt lgkmcnt(4)                                       // 0000003C9F28: BF89FC47
	v_add_f32_e32 v10, v10, v16                                // 0000003C9F2C: 0614210A
	ds_bpermute_b32 v16, v18, v9                               // 0000003C9F30: DACC0000 10000912
	s_waitcnt lgkmcnt(4)                                       // 0000003C9F38: BF89FC47
	v_add_f32_e32 v2, v8, v2                                   // 0000003C9F3C: 06040508
	ds_bpermute_b32 v8, v18, v3                                // 0000003C9F40: DACC0000 08000312
	s_waitcnt lgkmcnt(4)                                       // 0000003C9F48: BF89FC47
	v_add_f32_e32 v7, v7, v14                                  // 0000003C9F4C: 060E1D07
	ds_bpermute_b32 v12, v18, v6                               // 0000003C9F50: DACC0000 0C000612
	s_waitcnt lgkmcnt(3)                                       // 0000003C9F58: BF89FC37
	v_add_f32_e32 v5, v5, v13                                  // 0000003C9F5C: 060A1B05
	ds_bpermute_b32 v15, v18, v10                              // 0000003C9F60: DACC0000 0F000A12
	v_xor_b32_e32 v13, 1, v1                                   // 0000003C9F68: 3A1A0281
	s_waitcnt lgkmcnt(3)                                       // 0000003C9F6C: BF89FC37
	v_dual_add_f32 v4, v4, v11 :: v_dual_add_f32 v11, v9, v16  // 0000003C9F70: C9081704 040A2109
	ds_bpermute_b32 v17, v18, v2                               // 0000003C9F78: DACC0000 11000212
	v_xor_b32_e32 v18, 2, v1                                   // 0000003C9F80: 3A240282
	s_waitcnt lgkmcnt(3)                                       // 0000003C9F84: BF89FC37
	v_add_f32_e32 v3, v3, v8                                   // 0000003C9F88: 06061103
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000003C9F8C: BF8700D2
	v_cmp_gt_u32_e32 vcc_lo, 32, v18                           // 0000003C9F90: 7C9824A0
	v_cndmask_b32_e32 v18, v1, v18, vcc_lo                     // 0000003C9F94: 02242501
	v_cmp_gt_u32_e32 vcc_lo, 32, v13                           // 0000003C9F98: 7C981AA0
	s_waitcnt lgkmcnt(2)                                       // 0000003C9F9C: BF89FC27
	v_dual_add_f32 v6, v6, v12 :: v_dual_cndmask_b32 v1, v1, v13// 0000003C9FA0: C9121906 06001B01
	v_lshlrev_b32_e32 v21, 2, v1                               // 0000003C9FA8: 302A0282
	v_lshlrev_b32_e32 v18, 2, v18                              // 0000003C9FAC: 30242482
	ds_bpermute_b32 v9, v18, v3                                // 0000003C9FB0: DACC0000 09000312
	s_waitcnt lgkmcnt(0)                                       // 0000003C9FB8: BF89FC07
	v_add_f32_e32 v13, v3, v9                                  // 0000003C9FBC: 061A1303
	ds_bpermute_b32 v16, v18, v7                               // 0000003C9FC0: DACC0000 10000712
	v_add_f32_e32 v8, v10, v15                                 // 0000003C9FC8: 06101F0A
	ds_bpermute_b32 v10, v18, v4                               // 0000003C9FCC: DACC0000 0A000412
	ds_bpermute_b32 v15, v18, v5                               // 0000003C9FD4: DACC0000 0F000512
	ds_bpermute_b32 v20, v18, v11                              // 0000003C9FDC: DACC0000 14000B12
	v_add_f32_e32 v2, v2, v17                                  // 0000003C9FE4: 06042302
	ds_bpermute_b32 v12, v18, v6                               // 0000003C9FE8: DACC0000 0C000612
	s_waitcnt lgkmcnt(3)                                       // 0000003C9FF0: BF89FC37
	v_add_f32_e32 v14, v4, v10                                 // 0000003C9FF4: 061C1504
	s_waitcnt lgkmcnt(2)                                       // 0000003C9FF8: BF89FC27
	v_dual_add_f32 v10, v5, v15 :: v_dual_add_f32 v5, v7, v16  // 0000003C9FFC: C9081F05 0A042107
	ds_bpermute_b32 v17, v18, v8                               // 0000003CA004: DACC0000 11000812
	s_waitcnt lgkmcnt(2)                                       // 0000003CA00C: BF89FC27
	v_add_f32_e32 v1, v11, v20                                 // 0000003CA010: 0602290B
	ds_bpermute_b32 v18, v18, v2                               // 0000003CA014: DACC0000 12000212
	s_waitcnt lgkmcnt(2)                                       // 0000003CA01C: BF89FC27
	v_add_f32_e32 v9, v6, v12                                  // 0000003CA020: 06121906
	ds_bpermute_b32 v16, v21, v14                              // 0000003CA024: DACC0000 10000E15
	ds_bpermute_b32 v15, v21, v13                              // 0000003CA02C: DACC0000 0F000D15
	ds_bpermute_b32 v12, v21, v10                              // 0000003CA034: DACC0000 0C000A15
	ds_bpermute_b32 v7, v21, v5                                // 0000003CA03C: DACC0000 07000515
	ds_bpermute_b32 v11, v21, v9                               // 0000003CA044: DACC0000 0B000915
	ds_bpermute_b32 v3, v21, v1                                // 0000003CA04C: DACC0000 03000115
	s_waitcnt lgkmcnt(7)                                       // 0000003CA054: BF89FC77
	v_add_f32_e32 v6, v8, v17                                  // 0000003CA058: 060C2308
	s_waitcnt lgkmcnt(6)                                       // 0000003CA05C: BF89FC67
	v_add_f32_e32 v2, v2, v18                                  // 0000003CA060: 06042502
	ds_bpermute_b32 v8, v21, v6                                // 0000003CA064: DACC0000 08000615
	ds_bpermute_b32 v4, v21, v2                                // 0000003CA06C: DACC0000 04000215
	v_cmpx_eq_u32_e32 0, v19                                   // 0000003CA074: 7D942680
	s_cbranch_execz 67                                         // 0000003CA078: BFA50043 <_ZN7halogen12_GLOBAL__N_112k_hc6_fused3ILi8EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x1288>
	s_waitcnt lgkmcnt(6)                                       // 0000003CA07C: BF89FC67
	v_dual_add_f32 v14, v14, v16 :: v_dual_add_f32 v13, v13, v15// 0000003CA080: C908210E 0E0C1F0D
	.long 0x7f203880                                           // 0000003CA088: 7F203880
	s_waitcnt lgkmcnt(3)                                       // 0000003CA08C: BF89FC37
	v_dual_add_f32 v10, v10, v12 :: v_dual_add_f32 v9, v9, v11 // 0000003CA090: C908190A 0A081709
	s_delay_alu instid0(VALU_DEP_3)                            // 0000003CA098: BF870003
	.long 0x7e22398e                                           // 0000003CA09C: 7E22398E
	.long 0x7e20398d                                           // 0000003CA0A0: 7E20398D
	.long 0x7f223990                                           // 0000003CA0A4: 7F223990
	s_waitcnt lgkmcnt(1)                                       // 0000003CA0A8: BF89FC17
	v_dual_add_f32 v6, v6, v8 :: v_dual_add_f32 v5, v5, v7     // 0000003CA0AC: C9081106 06040F05
	.long 0x7e16398a                                           // 0000003CA0B4: 7E16398A
	v_and_b32_e32 v7, 1, v16                                   // 0000003CA0B8: 360E2081
	v_and_b32_e32 v8, 1, v17                                   // 0000003CA0BC: 36102281
	.long 0x7e203989                                           // 0000003CA0C0: 7E203989
	.long 0x7f163990                                           // 0000003CA0C4: 7F163990
	s_waitcnt lgkmcnt(0)                                       // 0000003CA0C8: BF89FC07
	v_add_f32_e32 v2, v2, v4                                   // 0000003CA0CC: 06040902
	v_and_b32_e32 v15, 0xf0, v0                                // 0000003CA0D0: 361E00FF 000000F0
	v_add3_u32 v8, v14, v8, 0x7fff                             // 0000003CA0D8: D6550008 03FE110E 00007FFF
	v_and_b32_e32 v4, 1, v16                                   // 0000003CA0E4: 36082081
	.long 0x7e203985                                           // 0000003CA0E8: 7E203985
	v_add_f32_e32 v14, v1, v3                                  // 0000003CA0EC: 061C0701
	.long 0x7e183986                                           // 0000003CA0F0: 7E183986
	.long 0x7f023990                                           // 0000003CA0F4: 7F023990
	.long 0x7f183990                                           // 0000003CA0F8: 7F183990
	v_and_b32_e32 v3, 1, v11                                   // 0000003CA0FC: 36061681
	.long 0x7e023982                                           // 0000003CA100: 7E023982
	v_and_b32_e32 v11, 1, v16                                  // 0000003CA104: 36162081
	.long 0x7e20398e                                           // 0000003CA108: 7E20398E
	v_and_b32_e32 v12, 1, v12                                  // 0000003CA10C: 36181881
	s_delay_alu instid0(VALU_DEP_4)                            // 0000003CA110: BF870004
	v_and_b32_e32 v17, 1, v1                                   // 0000003CA114: 36220281
	v_add3_u32 v1, v13, v7, 0x7fff                             // 0000003CA118: D6550001 03FE0F0D 00007FFF
	v_add3_u32 v7, v10, v3, 0x7fff                             // 0000003CA124: D6550007 03FE070A 00007FFF
	v_and_b32_e32 v10, 1, v16                                  // 0000003CA130: 36142081
	v_add3_u32 v6, v6, v12, 0x7fff                             // 0000003CA134: D6550006 03FE1906 00007FFF
	v_add3_u32 v13, v2, v17, 0x7fff                            // 0000003CA140: D655000D 03FE2302 00007FFF
	v_add3_u32 v2, v9, v4, 0x7fff                              // 0000003CA14C: D6550002 03FE0909 00007FFF
	v_add3_u32 v3, v5, v11, 0x7fff                             // 0000003CA158: D6550003 03FE1705 00007FFF
	v_add3_u32 v4, v14, v10, 0x7fff                            // 0000003CA164: D6550004 03FE150E 00007FFF
	.long 0x7e063986                                           // 0000003CA170: 7E063986
	.long 0x7e08398d                                           // 0000003CA174: 7E08398D
	.long 0x7e043987                                           // 0000003CA178: 7E043987
	.long 0x7e023988                                           // 0000003CA17C: 7E023988
	ds_store_b128 v15, v[1:4] offset:1024                      // 0000003CA180: DB7C0400 0000010F
	s_or_b32 exec_lo, exec_lo, s3                              // 0000003CA188: 8C7E037E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000003CA18C: BF870009
	s_mov_b32 s6, exec_lo                                      // 0000003CA190: BE86007E
	s_waitcnt lgkmcnt(0)                                       // 0000003CA194: BF89FC07
	s_barrier                                                  // 0000003CA198: BFBD0000
	buffer_gl0_inv                                             // 0000003CA19C: E0AC0000 00000000
	v_cmpx_gt_u32_e32 32, v0                                   // 0000003CA1A4: 7D9800A0
	s_cbranch_execz 258                                        // 0000003CA1A8: BFA50102 <_ZN7halogen12_GLOBAL__N_112k_hc6_fused3ILi8EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x16b4>
	v_lshrrev_b32_e32 v11, 3, v0                               // 0000003CA1AC: 32160083
	v_and_b32_e32 v12, 7, v0                                   // 0000003CA1B0: 36180087
	s_cmp_eq_u64 s[10:11], 0                                   // 0000003CA1B4: BF10800A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003CA1B8: BF870112
	v_or_b32_e32 v1, s25, v11                                  // 0000003CA1BC: 38021619
	v_mul_u32_u24_e32 v5, 0x5000, v12                          // 0000003CA1C0: 160A18FF 00005000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003CA1C8: BF870112
	v_ashrrev_i32_e32 v2, 31, v1                               // 0000003CA1CC: 3404029F
	.long 0xd7000305                                           // 0000003CA1D0: D7000305
	v_cndmask_b32_e32 v1, s20, v5, vcc_lo                      // 0000003CA1D4: 02020A14
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003CA1D8: BF870191
	v_add_co_ci_u32_e64 v6, null, s21, 0, s3                   // 0000003CA1DC: D5207C06 000D0015
	.long 0xd73c0003                                           // 0000003CA1E4: D73C0003
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 0000003CA1E8: 02020281
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003CA1EC: BF870091
	.long 0xd7006a03                                           // 0000003CA1F0: D7006A03
	v_cndmask_b32_e32 v1, v5, v3, vcc_lo                       // 0000003CA1F4: 02020705
	v_add_co_ci_u32_e64 v4, null, v6, v4, vcc_lo               // 0000003CA1F8: D5207C04 01AA0906
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003CA200: BF870092
	.long 0xd7006a05                                           // 0000003CA204: D7006A05
	v_cndmask_b32_e32 v1, 0x2000, v3, vcc_lo                   // 0000003CA208: 020206FF 00002000
	v_add_co_ci_u32_e64 v6, null, 0, v4, vcc_lo                // 0000003CA210: D5207C06 01AA0880
	.long 0xd7006a07                                           // 0000003CA218: D7006A07
	v_cndmask_b32_e32 v1, 0x3000, v3, vcc_lo                   // 0000003CA21C: 020206FF 00003000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003CA224: BF8700A1
	v_add_co_ci_u32_e64 v8, null, 0, v4, vcc_lo                // 0000003CA228: D5207C08 01AA0880
	.long 0xd7006a09                                           // 0000003CA230: D7006A09
	v_cndmask_b32_e32 v1, 0x1000, v3, vcc_lo                   // 0000003CA234: 020206FF 00001000
	v_add_co_ci_u32_e64 v10, null, 0, v4, vcc_lo               // 0000003CA23C: D5207C0A 01AA0880
	s_clause 0x3                                               // 0000003CA244: BF850003
	global_load_u16 v5, v[5:6], off offset:2048                // 0000003CA248: DC4A0800 057C0005
	global_load_u16 v6, v[7:8], off offset:3072                // 0000003CA250: DC4A0C00 067C0007
	global_load_u16 v3, v[3:4], off                            // 0000003CA258: DC4A0000 037C0003
	global_load_u16 v4, v[9:10], off offset:1024               // 0000003CA260: DC4A0400 047C0009
	v_lshlrev_b32_e32 v7, 1, v12                               // 0000003CA268: 300E1881
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003CA26C: BF870001
	v_lshl_or_b32 v7, v11, 6, v7                               // 0000003CA270: D6560007 041D0D0B
	ds_load_u16 v8, v7 offset:1024                             // 0000003CA278: D8F00400 08000007
	ds_load_u16 v9, v7 offset:1040                             // 0000003CA280: D8F00410 09000007
	ds_load_u16 v10, v7 offset:1056                            // 0000003CA288: D8F00420 0A000007
	ds_load_u16 v7, v7 offset:1072                             // 0000003CA290: D8F00430 07000007
	s_waitcnt lgkmcnt(0)                                       // 0000003CA298: BF89FC07
	v_lshlrev_b32_e32 v7, 16, v7                               // 0000003CA29C: 300E0E90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003CA2A0: BF870091
	v_dual_mul_f32 v7, 0xbfb8aa3b, v7 :: v_dual_lshlrev_b32 v8, 16, v8// 0000003CA2A4: C8E20EFF 07081090 BFB8AA3B
	v_dual_mul_f32 v8, 0xbfb8aa3b, v8 :: v_dual_lshlrev_b32 v9, 16, v9// 0000003CA2B0: C8E210FF 08081290 BFB8AA3B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003CA2BC: BF870092
	v_exp_f32_e32 v7, v7                                       // 0000003CA2C0: 7E0E4B07
	v_mul_f32_e32 v9, 0xbfb8aa3b, v9                           // 0000003CA2C4: 101212FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003CA2CC: BF870092
	v_exp_f32_e32 v8, v8                                       // 0000003CA2D0: 7E104B08
	v_exp_f32_e32 v9, v9                                       // 0000003CA2D4: 7E124B09
	s_delay_alu instid0(TRANS32_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 0000003CA2D8: BF870317
	v_dual_add_f32 v7, 1.0, v7 :: v_dual_lshlrev_b32 v10, 16, v10// 0000003CA2DC: C9220EF2 070A1490
	v_add_f32_e32 v8, 1.0, v8                                  // 0000003CA2E4: 061010F2
	s_delay_alu instid0(VALU_DEP_2)                            // 0000003CA2E8: BF870002
	v_div_scale_f32 v15, null, v7, v7, 1.0                     // 0000003CA2EC: D6FC7C0F 03CA0F07
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(VALU_DEP_3)   // 0000003CA2F4: BF870185
	v_dual_add_f32 v9, 1.0, v9 :: v_dual_mul_f32 v10, 0xbfb8aa3b, v10// 0000003CA2F8: C90612F2 090A14FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000003CA304: BF870223
	v_div_scale_f32 v11, null, v8, v8, 1.0                     // 0000003CA308: D6FC7C0B 03CA1108
	v_div_scale_f32 v20, vcc_lo, 1.0, v8, 1.0                  // 0000003CA310: D6FC6A14 03CA10F2
	v_rcp_f32_e32 v19, v15                                     // 0000003CA318: 7E26550F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000003CA31C: BF870143
	v_div_scale_f32 v13, null, v9, v9, 1.0                     // 0000003CA320: D6FC7C0D 03CA1309
	v_exp_f32_e32 v10, v10                                     // 0000003CA328: 7E144B0A
	v_rcp_f32_e32 v16, v11                                     // 0000003CA32C: 7E20550B
	v_div_scale_f32 v21, s3, 1.0, v9, 1.0                      // 0000003CA330: D6FC0315 03CA12F2
	v_rcp_f32_e32 v17, v13                                     // 0000003CA338: 7E22550D
	v_fma_f32 v26, -v15, v19, 1.0                              // 0000003CA33C: D613001A 23CA270F
	s_delay_alu instid0(TRANS32_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 0000003CA344: BF870317
	v_add_f32_e32 v10, 1.0, v10                                // 0000003CA348: 061414F2
	v_fma_f32 v22, -v11, v16, 1.0                              // 0000003CA34C: D6130016 23CA210B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000003CA354: BF870293
	v_fmac_f32_e32 v19, v26, v19                               // 0000003CA358: 5626271A
	v_fma_f32 v23, -v13, v17, 1.0                              // 0000003CA35C: D6130017 23CA230D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003CA364: BF870214
	v_div_scale_f32 v14, null, v10, v10, 1.0                   // 0000003CA368: D6FC7C0E 03CA150A
	v_fmac_f32_e32 v16, v22, v16                               // 0000003CA370: 56202116
	v_div_scale_f32 v25, s4, 1.0, v10, 1.0                     // 0000003CA374: D6FC0419 03CA14F2
	v_div_scale_f32 v22, s5, 1.0, v7, 1.0                      // 0000003CA37C: D6FC0516 03CA0EF2
	v_fmac_f32_e32 v17, v23, v17                               // 0000003CA384: 56222317
	v_rcp_f32_e32 v18, v14                                     // 0000003CA388: 7E24550E
	v_mul_f32_e32 v23, v20, v16                                // 0000003CA38C: 102E2114
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003CA390: BF870093
	v_mul_f32_e32 v27, v22, v19                                // 0000003CA394: 10362716
	v_fma_f32 v31, -v15, v27, v22                              // 0000003CA398: D613001F 245A370F
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003CA3A0: BF870095
	v_fma_f32 v24, -v14, v18, 1.0                              // 0000003CA3A4: D6130018 23CA250E
	v_dual_fmac_f32 v27, v31, v19 :: v_dual_fmac_f32 v18, v24, v18// 0000003CA3AC: C800271F 1B122518
	v_mul_f32_e32 v24, v21, v17                                // 0000003CA3B4: 10302315
	v_fma_f32 v28, -v11, v23, v20                              // 0000003CA3B8: D613001C 24522F0B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003CA3C0: BF870213
	v_fma_f32 v15, -v15, v27, v22                              // 0000003CA3C4: D613000F 245A370F
	v_mul_f32_e32 v26, v25, v18                                // 0000003CA3CC: 10342519
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003CA3D0: BF870214
	v_fma_f32 v29, -v13, v24, v21                              // 0000003CA3D4: D613001D 2456310D
	v_fmac_f32_e32 v23, v28, v16                               // 0000003CA3DC: 562E211C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003CA3E0: BF870193
	v_fma_f32 v30, -v14, v26, v25                              // 0000003CA3E4: D613001E 2466350E
	v_fmac_f32_e32 v24, v29, v17                               // 0000003CA3EC: 5630231D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003CA3F0: BF870193
	v_fma_f32 v11, -v11, v23, v20                              // 0000003CA3F4: D613000B 24522F0B
	v_fmac_f32_e32 v26, v30, v18                               // 0000003CA3FC: 5634251E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003CA400: BF870193
	v_fma_f32 v13, -v13, v24, v21                              // 0000003CA404: D613000D 2456310D
	v_div_fmas_f32 v11, v11, v16, v23                          // 0000003CA40C: D637000B 045E210B
	s_mov_b32 vcc_lo, s3                                       // 0000003CA414: BEEA0003
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003CA418: BF870193
	v_fma_f32 v14, -v14, v26, v25                              // 0000003CA41C: D613000E 2466350E
	v_div_fmas_f32 v13, v13, v17, v24                          // 0000003CA424: D637000D 0462230D
	s_mov_b32 vcc_lo, s4                                       // 0000003CA42C: BEEA0004
	v_div_fixup_f32 v8, v11, v8, 1.0                           // 0000003CA430: D6270008 03CA110B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003CA438: BF870193
	v_div_fmas_f32 v11, v14, v18, v26                          // 0000003CA43C: D637000B 046A250E
	v_div_fixup_f32 v9, v13, v9, 1.0                           // 0000003CA444: D6270009 03CA130D
	s_mov_b32 vcc_lo, s5                                       // 0000003CA44C: BEEA0005
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000003CA450: BF870243
	v_bfe_u32 v13, v8, 16, 1                                   // 0000003CA454: D610000D 02052108
	v_div_fmas_f32 v14, v15, v19, v27                          // 0000003CA45C: D637000E 046E270F
	v_div_fixup_f32 v10, v11, v10, 1.0                         // 0000003CA464: D627000A 03CA150B
	v_bfe_u32 v11, v9, 16, 1                                   // 0000003CA46C: D610000B 02052109
	v_add3_u32 v8, v8, v13, 0x7fff                             // 0000003CA474: D6550008 03FE1B08 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003CA480: BF870214
	v_div_fixup_f32 v7, v14, v7, 1.0                           // 0000003CA484: D6270007 03CA0F0E
	v_bfe_u32 v13, v10, 16, 1                                  // 0000003CA48C: D610000D 0205210A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003CA494: BF870194
	v_add3_u32 v9, v9, v11, 0x7fff                             // 0000003CA498: D6550009 03FE1709 00007FFF
	v_bfe_u32 v11, v7, 16, 1                                   // 0000003CA4A4: D610000B 02052107
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003CA4AC: BF870193
	v_add3_u32 v10, v10, v13, 0x7fff                           // 0000003CA4B0: D655000A 03FE1B0A 00007FFF
	v_and_b32_e32 v9, 0xffff0000, v9                           // 0000003CA4BC: 361212FF FFFF0000
	s_delay_alu instid0(VALU_DEP_3)                            // 0000003CA4C4: BF870003
	v_add3_u32 v7, v7, v11, 0x7fff                             // 0000003CA4C8: D6550007 03FE1707 00007FFF
	s_waitcnt vmcnt(3)                                         // 0000003CA4D4: BF890FF7
	v_lshlrev_b32_e32 v5, 16, v5                               // 0000003CA4D8: 300A0A90
	s_waitcnt vmcnt(2)                                         // 0000003CA4DC: BF890BF7
	v_lshlrev_b32_e32 v6, 16, v6                               // 0000003CA4E0: 300C0C90
	s_waitcnt vmcnt(1)                                         // 0000003CA4E4: BF8907F7
	v_lshlrev_b32_e32 v3, 16, v3                               // 0000003CA4E8: 30060690
	s_waitcnt vmcnt(0)                                         // 0000003CA4EC: BF8903F7
	v_lshlrev_b32_e32 v4, 16, v4                               // 0000003CA4F0: 30080890
	v_and_b32_e32 v8, 0xffff0000, v8                           // 0000003CA4F4: 361010FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003CA4FC: BF870091
	v_fma_f32 v3, v3, v8, 0                                    // 0000003CA500: D6130003 02021103
	v_dual_fmac_f32 v3, v4, v9 :: v_dual_and_b32 v4, 0xffff0000, v7// 0000003CA508: C8241304 03040EFF FFFF0000
	v_and_b32_e32 v8, 0xffff0000, v10                          // 0000003CA514: 361014FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003CA51C: BF870091
	v_fmac_f32_e32 v3, v5, v8                                  // 0000003CA520: 56061105
	v_fmac_f32_e32 v3, v6, v4                                  // 0000003CA524: 56060906
	v_mul_u32_u24_e32 v4, 0xa00, v12                           // 0000003CA528: 160818FF 00000A00
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003CA530: BF870112
	v_mul_f32_e32 v3, 0x3e800000, v3                           // 0000003CA534: 100606FF 3E800000
	.long 0xd7006a01                                           // 0000003CA53C: D7006A01
	v_cndmask_b32_e32 v1, v1, v4, vcc_lo                       // 0000003CA540: 02020901
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003CA544: BF870191
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 0000003CA548: D5207C02 01AA0480
	v_bfe_u32 v6, v3, 16, 1                                    // 0000003CA550: D6100006 02052103
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003CA558: BF870112
	.long 0xd73c0004                                           // 0000003CA55C: D73C0004
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 0000003CA560: 02020281
	v_add3_u32 v6, v3, v6, 0x7fff                              // 0000003CA564: D6550006 03FE0D03 00007FFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003CA570: BF870092
	.long 0xd7006a04                                           // 0000003CA574: D7006A04
	v_cndmask_b32_e32 v1, s8, v4, vcc_lo                       // 0000003CA578: 02020808
	v_add_co_ci_u32_e64 v5, null, s9, v5, vcc_lo               // 0000003CA57C: D5207C05 01AA0A09
	global_store_d16_hi_b16 v[4:5], v6, off                    // 0000003CA584: DC960000 007C0604
	s_cbranch_scc1 9                                           // 0000003CA58C: BFA20009 <_ZN7halogen12_GLOBAL__N_112k_hc6_fused3ILi8EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x16b4>
	.long 0xd73c0001                                           // 0000003CA590: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 0000003CA594: 02020282
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003CA598: BF870091
	.long 0xd7006a01                                           // 0000003CA59C: D7006A01
	v_cndmask_b32_e32 v1, s10, v1, vcc_lo                      // 0000003CA5A0: 0202020A
	v_add_co_ci_u32_e64 v2, null, s11, v2, vcc_lo              // 0000003CA5A4: D5207C02 01AA040B
	global_store_b32 v[1:2], v3, off                           // 0000003CA5AC: DC6A0000 007C0301
	s_or_b32 exec_lo, exec_lo, s6                              // 0000003CA5B4: 8C7E067E
	s_mov_b32 s3, 0                                            // 0000003CA5B8: BE830080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000003CA5BC: BF870009
	s_and_b32 vcc_lo, exec_lo, s3                              // 0000003CA5C0: 8B6A037E
	s_cbranch_vccz 1236                                        // 0000003CA5C4: BFA304D4 <_ZN7halogen12_GLOBAL__N_112k_hc6_fused3ILi8EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x2a18>
	s_clause 0x3                                               // 0000003CA5C8: BF850003
	s_load_b32 s3, s[0:1], 0x148                               // 0000003CA5CC: F40000C0 F8000148
	s_load_b32 s4, s[0:1], 0xb0                                // 0000003CA5D4: F4000100 F80000B0
	s_load_b32 s5, s[0:1], 0xf8                                // 0000003CA5DC: F4000140 F80000F8
	s_load_b32 s6, s[0:1], 0x140                               // 0000003CA5E4: F4000180 F8000140
	s_sub_i32 s24, s2, s24                                     // 0000003CA5EC: 81981802
	v_lshrrev_b32_e32 v5, 5, v0                                // 0000003CA5F0: 320A0085
	v_and_b32_e32 v64, 31, v0                                  // 0000003CA5F4: 3680009F
	v_dual_mov_b32 v46, 0 :: v_dual_mov_b32 v47, 0             // 0000003CA5F8: CA100080 2E2E0080
	v_mov_b32_e32 v85, 0                                       // 0000003CA600: 7EAA0280
	s_waitcnt lgkmcnt(0)                                       // 0000003CA604: BF89FC07
	s_cmp_gt_i32 s3, 1                                         // 0000003CA608: BF028103
	s_cselect_b32 s7, -1, 0                                    // 0000003CA60C: 980780C1
	s_cmp_ge_i32 s24, s4                                       // 0000003CA610: BF030418
	s_cselect_b32 s4, -1, 0                                    // 0000003CA614: 980480C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000003CA618: BF870009
	s_and_b32 s4, s7, s4                                       // 0000003CA61C: 8B040407
	s_cmp_gt_i32 s3, 2                                         // 0000003CA620: BF028203
	v_cndmask_b32_e64 v1, 0, 1, s4                             // 0000003CA624: D5010001 00110280
	s_cselect_b32 s7, -1, 0                                    // 0000003CA62C: 980780C1
	s_cmp_ge_i32 s24, s5                                       // 0000003CA630: BF030518
	s_cselect_b32 s5, -1, 0                                    // 0000003CA634: 980580C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000003CA638: BF870009
	s_and_b32 s4, s7, s5                                       // 0000003CA63C: 8B040507
	s_cmp_gt_i32 s3, 3                                         // 0000003CA640: BF028303
	v_readfirstlane_b32 s5, v1                                 // 0000003CA644: 7E0A0501
	s_cselect_b32 s3, -1, 0                                    // 0000003CA648: 980380C1
	s_cmp_ge_i32 s24, s6                                       // 0000003CA64C: BF030618
	s_cselect_b32 s6, -1, 0                                    // 0000003CA650: 980680C1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(SALU_CYCLE_1)// 0000003CA654: BF8704D9
	s_and_b32 s3, s3, s6                                       // 0000003CA658: 8B030603
	s_and_b32 s4, s4, exec_lo                                  // 0000003CA65C: 8B047E04
	s_cselect_b32 s4, 2, s5                                    // 0000003CA660: 98040582
	s_and_b32 s3, s3, exec_lo                                  // 0000003CA664: 8B037E03
	s_cselect_b32 s3, 3, s4                                    // 0000003CA668: 98030483
	s_mulk_i32 s3, 0x48                                        // 0000003CA66C: B8030048
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000003CA670: BF870009
	s_add_u32 s4, s0, s3                                       // 0000003CA674: 80040300
	s_addc_u32 s5, s1, 0                                       // 0000003CA678: 82058001
	s_clause 0x1                                               // 0000003CA67C: BF850001
	s_load_b64 s[6:7], s[4:5], 0x58                            // 0000003CA680: F4040182 F8000058
	s_load_b32 s3, s[4:5], 0x68                                // 0000003CA688: F40000C2 F8000068
	s_add_u32 s8, s4, 40                                       // 0000003CA690: 8008A804
	s_addc_u32 s9, s5, 0                                       // 0000003CA694: 82098005
	s_load_b64 s[4:5], s[4:5], 0x28                            // 0000003CA698: F4040102 F8000028
	s_waitcnt lgkmcnt(0)                                       // 0000003CA6A0: BF89FC07
	.long 0xd451001a                                           // 0000003CA6A4: D451001A
	v_cndmask_b32_e32 v0, s6, v137, vcc_lo                     // 0000003CA6A8: 02011206
	s_and_b32 s10, s26, exec_lo                                // 0000003CA6AC: 8B0A7E1A
	s_cselect_b32 s25, 8, 2                                    // 0000003CA6B0: 98198288
	s_cselect_b32 s27, 3, 1                                    // 0000003CA6B4: 981B8183
	v_cvt_f32_ubyte0_e32 v1, s25                               // 0000003CA6B8: 7E022219
	s_sub_i32 s10, s24, s3                                     // 0000003CA6BC: 818A0318
	s_add_i32 s3, s25, -1                                      // 0000003CA6C0: 8103C119
	s_ashr_i32 s11, s10, 31                                    // 0000003CA6C4: 860B9F0A
	s_and_b32 s19, s26, exec_lo                                // 0000003CA6C8: 8B137E1A
	v_rcp_iflag_f32_e32 v2, v1                                 // 0000003CA6CC: 7E045701
	s_cselect_b32 s28, 0, 2                                    // 0000003CA6D0: 981C8280
	s_ashr_i32 s29, s23, 31                                    // 0000003CA6D4: 861D9F17
	s_lshl_b64 s[10:11], s[10:11], s28                         // 0000003CA6D8: 848A1C0A
	v_lshrrev_b32_e32 v65, s27, v5                             // 0000003CA6DC: 32820A1B
	v_dual_mov_b32 v1, 0 :: v_dual_and_b32 v66, s3, v5         // 0000003CA6E0: CA240080 01420A03
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000003CA6E8: BF870292
	.long 0xd7000a03                                           // 0000003CA6EC: D7000A03
	v_cndmask_b32_e32 v1, s10, v65, vcc_lo                     // 0000003CA6F0: 0202820A
	v_readfirstlane_b32 s18, v2                                // 0000003CA6F4: 7E240502
	v_add_co_ci_u32_e64 v4, null, s11, 0, s10                  // 0000003CA6F8: D5207C04 0029000B
	s_mul_f32 s19, s18, 0x4f7ffffe                             // 0000003CA700: A213FF12 4F7FFFFE
	s_lshr_b32 s18, s29, 27                                    // 0000003CA708: 85129B1D
	v_cmp_gt_i64_e32 vcc_lo, s[6:7], v[3:4]                    // 0000003CA70C: 7CA80606
	s_add_u32 s18, s22, s18                                    // 0000003CA710: 80121216
	s_cvt_u32_f32 s33, s19                                     // 0000003CA714: BEA16713
	s_addc_u32 s19, s23, 0                                     // 0000003CA718: 82138017
	s_sub_i32 s34, 0, s25                                      // 0000003CA71C: 81A21980
	s_lshr_b64 s[30:31], s[18:19], 5                           // 0000003CA720: 859E8512
	s_mul_i32 s34, s34, s33                                    // 0000003CA724: 96222122
	s_add_i32 s18, s3, s30                                     // 0000003CA728: 81121E03
	s_mul_hi_u32 s19, s33, s34                                 // 0000003CA72C: 96932221
	s_abs_i32 s31, s18                                         // 0000003CA730: BE9F1512
	s_add_i32 s33, s33, s19                                    // 0000003CA734: 81211321
	s_ashr_i32 s18, s18, 31                                    // 0000003CA738: 86129F12
	s_mul_hi_u32 s19, s31, s33                                 // 0000003CA73C: 9693211F
	v_dual_mov_b32 v2, 0 :: v_dual_cndmask_b32 v3, 0, v3       // 0000003CA740: CA120080 02020680
	s_mul_i32 s33, s19, s25                                    // 0000003CA748: 96211913
	v_cndmask_b32_e32 v4, 0, v4, vcc_lo                        // 0000003CA74C: 02080880
	s_sub_i32 s31, s31, s33                                    // 0000003CA750: 819F211F
	s_add_i32 s33, s19, 1                                      // 0000003CA754: 81218113
	s_sub_i32 s34, s31, s25                                    // 0000003CA758: 81A2191F
	s_cmp_ge_u32 s31, s25                                      // 0000003CA75C: BF09191F
	s_cselect_b32 s10, s33, s19                                // 0000003CA760: 980A1321
	s_cselect_b32 s11, s34, s31                                // 0000003CA764: 980B1F22
	s_add_i32 s19, s10, 1                                      // 0000003CA768: 8113810A
	s_cmp_ge_u32 s11, s25                                      // 0000003CA76C: BF09190B
	s_cselect_b32 s3, s19, s10                                 // 0000003CA770: 98030A13
	s_lshr_b32 s10, s23, 31                                    // 0000003CA774: 850A9F17
	s_xor_b32 s3, s3, s18                                      // 0000003CA778: 8D031203
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000003CA77C: BF870009
	s_sub_i32 s3, s3, s18                                      // 0000003CA780: 81831203
	s_add_u32 s10, s22, s10                                    // 0000003CA784: 800A0A16
	s_addc_u32 s11, s23, 0                                     // 0000003CA788: 820B8017
	s_lshr_b32 s18, s29, 30                                    // 0000003CA78C: 85129E1D
	s_ashr_i64 s[10:11], s[10:11], 1                           // 0000003CA790: 868A810A
	s_add_u32 s18, s22, s18                                    // 0000003CA794: 80121216
	s_addc_u32 s19, s23, 0                                     // 0000003CA798: 82138017
	s_lshr_b32 s29, s29, 28                                    // 0000003CA79C: 851D9C1D
	s_ashr_i64 s[18:19], s[18:19], 2                           // 0000003CA7A0: 86928212
	s_add_u32 s34, s22, s29                                    // 0000003CA7A4: 80221D16
	s_addc_u32 s35, s23, 0                                     // 0000003CA7A8: 82238017
	.long 0xd72c0005                                           // 0000003CA7AC: D72C0005
	v_cndmask_b32_e32 v0, v66, v3, vcc_lo                      // 0000003CA7B0: 02000742
	s_ashr_i64 s[34:35], s[34:35], 4                           // 0000003CA7B4: 86A28422
	s_add_u32 s29, s18, s10                                    // 0000003CA7B8: 801D0A12
	s_addc_u32 s31, s19, s11                                   // 0000003CA7BC: 821F0B13
	s_add_u32 s29, s29, s34                                    // 0000003CA7C0: 801D221D
	s_addc_u32 s31, s31, s35                                   // 0000003CA7C4: 821F231F
	s_add_u32 s29, s29, 15                                     // 0000003CA7C8: 801D8F1D
	s_addc_u32 s31, s31, 0                                     // 0000003CA7CC: 821F801F
	v_add_nc_u32_e32 v6, s3, v5                                // 0000003CA7D0: 4A0C0A03
	s_ashr_i32 s33, s31, 31                                    // 0000003CA7D4: 86219F1F
	v_add_nc_u32_e32 v67, v5, v64                              // 0000003CA7D8: 4A868105
	s_lshr_b32 s33, s33, 28                                    // 0000003CA7DC: 85219C21
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000003CA7E0: BF870009
	s_add_u32 s3, s29, s33                                     // 0000003CA7E4: 8003211D
	s_addc_u32 s29, s31, 0                                     // 0000003CA7E8: 821D801F
	s_and_b32 s3, s3, -16                                      // 0000003CA7EC: 8B03D003
	.long 0xd72c0007                                           // 0000003CA7F0: D72C0007
	v_cndmask_b32_e32 v1, s29, v3, vcc_lo                      // 0000003CA7F4: 0202061D
	.long 0xd72c0008                                           // 0000003CA7F8: D72C0008
	v_cndmask_b32_e32 v1, s3, v4, vcc_lo                       // 0000003CA7FC: 02020803
	v_mad_u64_u32 v[41:42], null, s3, v3, s[4:5]               // 0000003CA800: D6FE7C29 00120603
	v_min_i32_e32 v68, s30, v6                                 // 0000003CA808: 22880C1E
	v_dual_mov_b32 v3, 0 :: v_dual_mov_b32 v4, 0               // 0000003CA80C: CA100080 03040080
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003CA814: BF870212
	.long 0xd4410004                                           // 0000003CA818: D4410004
	v_cndmask_b32_e32 v1, v67, v68, vcc_lo                     // 0000003CA81C: 02028943
	v_add3_u32 v69, v7, v42, v8                                // 0000003CA820: D6550045 04225507
	s_and_saveexec_b32 s3, s4                                  // 0000003CA828: BE832004
	s_cbranch_execz 39                                         // 0000003CA82C: BFA50027 <_ZN7halogen12_GLOBAL__N_112k_hc6_fused3ILi8EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x19cc>
	v_lshlrev_b32_e32 v1, 4, v67                               // 0000003CA830: 30028684
	v_lshlrev_b32_e32 v4, 1, v67                               // 0000003CA834: 30088681
	v_lshlrev_b32_e32 v3, 3, v67                               // 0000003CA838: 30068683
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000003CA83C: BF870223
	v_ashrrev_i32_e32 v2, 31, v1                               // 0000003CA840: 3404029F
	.long 0xd7006a01                                           // 0000003CA844: D7006A01
	v_cndmask_b32_e32 v1, v41, v1, vcc_lo                      // 0000003CA848: 02020329
	v_and_b32_e32 v4, -4, v4                                   // 0000003CA84C: 360808C4
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003CA850: BF870214
	v_ashrrev_i32_e32 v8, 31, v3                               // 0000003CA854: 3410069F
	v_add_co_ci_u32_e64 v2, null, v69, v2, vcc_lo              // 0000003CA858: D5207C02 01AA0545
	.long 0xd7006a06                                           // 0000003CA860: D7006A06
	v_cndmask_b32_e32 v0, v41, v10, vcc_lo                     // 0000003CA864: 02001529
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000003CA868: BF8701A1
	v_add_co_ci_u32_e64 v7, null, s11, v69, vcc_lo             // 0000003CA86C: D5207C07 01AA8A0B
	v_ashrrev_i32_e32 v11, 31, v4                              // 0000003CA874: 3416089F
	.long 0xd7006a09                                           // 0000003CA878: D7006A09
	v_cndmask_b32_e32 v0, v6, v18, vcc_lo                      // 0000003CA87C: 02002506
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003CA880: BF8700A1
	v_add_co_ci_u32_e64 v10, null, s19, v7, vcc_lo             // 0000003CA884: D5207C0A 01AA0E13
	.long 0xd7006a06                                           // 0000003CA88C: D7006A06
	v_cndmask_b32_e32 v1, v6, v3, vcc_lo                       // 0000003CA890: 02020706
	v_add_co_ci_u32_e64 v7, null, v7, v8, vcc_lo               // 0000003CA894: D5207C07 01AA1107
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003CA89C: BF870094
	.long 0xd7006a08                                           // 0000003CA8A0: D7006A08
	v_cndmask_b32_e32 v1, v9, v4, vcc_lo                       // 0000003CA8A4: 02020909
	v_add_co_ci_u32_e64 v9, null, v10, v11, vcc_lo             // 0000003CA8A8: D5207C09 01AA170A
	s_clause 0x2                                               // 0000003CA8B0: BF850002
	global_load_b128 v[1:4], v[1:2], off                       // 0000003CA8B4: DC5E0000 017C0001
	global_load_b64 v[46:47], v[6:7], off                      // 0000003CA8BC: DC560000 2E7C0006
	global_load_b32 v85, v[8:9], off                           // 0000003CA8C4: DC520000 557C0008
	s_or_b32 exec_lo, exec_lo, s3                              // 0000003CA8CC: 8C7E037E
	.long 0xd44a0003                                           // 0000003CA8D0: D44A0003
	v_cndmask_b32_e32 v1, 0, v0, vcc_lo                        // 0000003CA8D4: 02020080
	s_and_saveexec_b32 s5, s3                                  // 0000003CA8D8: BE852003
	s_cbranch_execz 20                                         // 0000003CA8DC: BFA50014 <_ZN7halogen12_GLOBAL__N_112k_hc6_fused3ILi8EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x1a30>
	v_mov_b32_e32 v6, 0                                        // 0000003CA8E0: 7E0C0280
	global_load_b64 v[7:8], v6, s[12:13] glc                   // 0000003CA8E4: DC564000 070C0006
	s_waitcnt vmcnt(0)                                         // 0000003CA8EC: BF8903F7
	buffer_gl1_inv                                             // 0000003CA8F0: E0B00000 00000000
	buffer_gl0_inv                                             // 0000003CA8F8: E0AC0000 00000000
	v_cmp_le_u64_e32 vcc_lo, s[14:15], v[7:8]                  // 0000003CA900: 7CB60E0E
	s_cbranch_vccnz 10                                         // 0000003CA904: BFA4000A <_ZN7halogen12_GLOBAL__N_112k_hc6_fused3ILi8EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x1a30>
	s_sleep 1                                                  // 0000003CA908: BF830001
	global_load_b64 v[7:8], v6, s[12:13] glc                   // 0000003CA90C: DC564000 070C0006
	s_waitcnt vmcnt(0)                                         // 0000003CA914: BF8903F7
	buffer_gl1_inv                                             // 0000003CA918: E0B00000 00000000
	buffer_gl0_inv                                             // 0000003CA920: E0AC0000 00000000
	v_cmp_gt_u64_e32 vcc_lo, s[14:15], v[7:8]                  // 0000003CA928: 7CB80E0E
	s_cbranch_vccnz 65526                                      // 0000003CA92C: BFA4FFF6 <_ZN7halogen12_GLOBAL__N_112k_hc6_fused3ILi8EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x1a08>
	s_or_b32 exec_lo, exec_lo, s5                              // 0000003CA930: 8C7E057E
	v_dual_mov_b32 v70, 0 :: v_dual_mov_b32 v71, 0             // 0000003CA934: CA100080 46460080
	v_dual_mov_b32 v72, 0 :: v_dual_mov_b32 v73, 0             // 0000003CA93C: CA100080 48480080
	v_dual_mov_b32 v74, 0 :: v_dual_mov_b32 v75, 0             // 0000003CA944: CA100080 4A4A0080
	v_dual_mov_b32 v76, 0 :: v_dual_mov_b32 v77, 0             // 0000003CA94C: CA100080 4C4C0080
	s_waitcnt vmcnt(0)                                         // 0000003CA954: BF8903F7
	s_waitcnt_vscnt null, 0x0                                  // 0000003CA958: BC7C0000
	s_barrier                                                  // 0000003CA95C: BFBD0000
	buffer_gl0_inv                                             // 0000003CA960: E0AC0000 00000000
	buffer_gl1_inv                                             // 0000003CA968: E0B00000 00000000
	buffer_gl0_inv                                             // 0000003CA970: E0AC0000 00000000
	s_and_saveexec_b32 s5, s4                                  // 0000003CA978: BE852004
	s_cbranch_execz 1389                                       // 0000003CA97C: BFA5056D <_ZN7halogen12_GLOBAL__N_112k_hc6_fused3ILi8EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x3034>
	.long 0xd7006a4e                                           // 0000003CA980: D7006A4E
	v_cndmask_b32_e32 v0, v41, v10, vcc_lo                     // 0000003CA984: 02001529
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000003CA988: BF870231
	v_add_co_ci_u32_e64 v79, null, s11, v69, vcc_lo            // 0000003CA98C: D5207C4F 01AA8A0B
	v_dual_mov_b32 v71, 0 :: v_dual_lshlrev_b32 v6, 5, v64     // 0000003CA994: CA220080 47068085
	v_dual_mov_b32 v70, 0 :: v_dual_add_nc_u32 v7, 32, v67     // 0000003CA99C: CA200080 460686A0
	.long 0xd7006a50                                           // 0000003CA9A4: D7006A50
	v_cndmask_b32_e32 v0, v78, v18, vcc_lo                     // 0000003CA9A8: 0200254E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003CA9AC: BF870211
	v_add_co_ci_u32_e64 v81, null, s19, v79, vcc_lo            // 0000003CA9B0: D5207C51 01AA9E13
	v_lshl_add_u32 v42, v5, 5, v6                              // 0000003CA9B8: D646002A 04190B05
	s_delay_alu instid0(VALU_DEP_4)                            // 0000003CA9C0: BF870004
	v_dual_mov_b32 v73, 0 :: v_dual_lshlrev_b32 v82, 4, v7     // 0000003CA9C4: CA220080 49520E84
	v_dual_mov_b32 v72, 0 :: v_dual_lshlrev_b32 v83, 3, v7     // 0000003CA9CC: CA220080 48520E83
	v_dual_mov_b32 v75, 0 :: v_dual_lshlrev_b32 v84, 1, v7     // 0000003CA9D4: CA220080 4B540E81
	v_dual_mov_b32 v74, 0 :: v_dual_mov_b32 v77, 0             // 0000003CA9DC: CA100080 4A4C0080
	v_mov_b32_e32 v76, 0                                       // 0000003CA9E4: 7E980280
	v_mov_b32_e32 v86, v85                                     // 0000003CA9E8: 7EAC0355
	s_mul_i32 s4, s23, 6                                       // 0000003CA9EC: 96048617
	s_mul_hi_u32 s14, s22, 6                                   // 0000003CA9F0: 968E8616
	s_lshl_b64 s[10:11], s[22:23], 2                           // 0000003CA9F4: 848A8216
	s_add_i32 s18, s14, s4                                     // 0000003CA9F8: 8112040E
	s_mul_i32 s29, s22, 6                                      // 0000003CA9FC: 961D8616
	s_mov_b32 s19, 0                                           // 0000003CAA00: BE930080
	s_lshl_b64 s[14:15], s[22:23], 1                           // 0000003CAA04: 848E8116
	s_branch 924                                               // 0000003CAA08: BFA0039C <_ZN7halogen12_GLOBAL__N_112k_hc6_fused3ILi8EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x297c>
	s_or_b32 exec_lo, exec_lo, s22                             // 0000003CAA0C: 8C7E167E
	v_ashrrev_i32_e32 v43, 31, v42                             // 0000003CAA10: 3456549F
	v_lshlrev_b32_e32 v87, 4, v46                              // 0000003CAA14: 30AE5C84
	v_lshlrev_b32_e32 v88, 2, v46                              // 0000003CAA18: 30B05C82
	v_lshrrev_b32_e32 v89, 4, v1                               // 0000003CAA1C: 32B20284
	v_lshrrev_b32_e32 v90, 8, v1                               // 0000003CAA20: 32B40288
	.long 0xd73c0009                                           // 0000003CAA24: D73C0009
	v_cndmask_b32_e32 v1, 1, v42, vcc_lo                       // 0000003CAA28: 02025481
	v_and_b32_e32 v87, 48, v87                                 // 0000003CAA2C: 36AEAEB0
	v_lshrrev_b32_e32 v91, 2, v46                              // 0000003CAA30: 32B65C82
	v_and_b32_e32 v92, 48, v46                                 // 0000003CAA34: 36B85CB0
	v_and_b32_e32 v88, 48, v88                                 // 0000003CAA38: 36B0B0B0
	v_lshrrev_b32_e32 v93, 12, v1                              // 0000003CAA3C: 32BA028C
	.long 0xd7000432                                           // 0000003CAA40: D7000432
	v_cndmask_b32_e32 v1, s20, v9, vcc_lo                      // 0000003CAA44: 02021214
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000003CAA48: BF8701A1
	v_add_co_ci_u32_e64 v51, null, s21, v10, s4                // 0000003CAA4C: D5207C33 00121415
	v_and_or_b32 v87, v1, 15, v87                              // 0000003CAA54: D6570057 055D1F01
	.long 0xd7000436                                           // 0000003CAA5C: D7000436
	v_cndmask_b32_e32 v0, v50, v14, vcc_lo                     // 0000003CAA60: 02001D32
	global_load_b128 v[13:16], v[50:51], off                   // 0000003CAA64: DC5E0000 0D7C0032
	v_add_co_ci_u32_e64 v55, null, s15, v51, s4                // 0000003CAA6C: D5207C37 0012660F
	.long 0xd7000438                                           // 0000003CAA74: D7000438
	v_cndmask_b32_e32 v0, v50, v10, vcc_lo                     // 0000003CAA78: 02001532
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003CAA7C: BF8700A1
	v_add_co_ci_u32_e64 v57, null, s11, v51, s4                // 0000003CAA80: D5207C39 0012660B
	.long 0xd7000430                                           // 0000003CAA88: D7000430
	v_cndmask_b32_e32 v0, v50, v29, vcc_lo                     // 0000003CAA8C: 02003B32
	v_add_co_ci_u32_e64 v49, null, s18, v51, s4                // 0000003CAA90: D5207C31 00126612
	s_clause 0x1                                               // 0000003CAA98: BF850001
	global_load_b128 v[21:24], v[54:55], off                   // 0000003CAA9C: DC5E0000 157C0036
	global_load_b128 v[17:20], v[56:57], off                   // 0000003CAAA4: DC5E0000 117C0038
	.long 0xd7000434                                           // 0000003CAAAC: D7000434
	v_cndmask_b32_e32 v0, v56, v10, vcc_lo                     // 0000003CAAB0: 02001538
	global_load_b128 v[9:12], v[48:49], off                    // 0000003CAAB4: DC5E0000 097C0030
	v_add_co_ci_u32_e64 v53, null, s11, v57, s4                // 0000003CAABC: D5207C35 0012720B
	.long 0xd700043a                                           // 0000003CAAC4: D700043A
	v_cndmask_b32_e32 v0, v48, v10, vcc_lo                     // 0000003CAAC8: 02001530
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000003CAACC: BF8700D1
	v_add_co_ci_u32_e64 v59, null, s11, v49, s4                // 0000003CAAD0: D5207C3B 0012620B
	s_clause 0x1                                               // 0000003CAAD8: BF850001
	global_load_b128 v[29:32], v[52:53], off                   // 0000003CAADC: DC5E0000 1D7C0034
	global_load_b128 v[25:28], v[58:59], off                   // 0000003CAAE4: DC5E0000 197C003A
	.long 0xd700043c                                           // 0000003CAAEC: D700043C
	v_cndmask_b32_e32 v0, v52, v10, vcc_lo                     // 0000003CAAF0: 02001534
	v_add_co_ci_u32_e64 v61, null, s11, v53, s4                // 0000003CAAF4: D5207C3D 00126A0B
	.long 0xd700043e                                           // 0000003CAAFC: D700043E
	v_cndmask_b32_e32 v0, v58, v10, vcc_lo                     // 0000003CAB00: 0200153A
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003CAB04: BF870001
	v_add_co_ci_u32_e64 v63, null, s11, v59, s4                // 0000003CAB08: D5207C3F 0012760B
	s_clause 0x1                                               // 0000003CAB10: BF850001
	global_load_b128 v[37:40], v[60:61], off                   // 0000003CAB14: DC5E0000 257C003C
	global_load_b128 v[33:36], v[62:63], off                   // 0000003CAB1C: DC5E0000 217C003E
	v_and_b32_e32 v91, 48, v91                                 // 0000003CAB24: 36B6B6B0
	v_and_or_b32 v88, v89, 15, v88                             // 0000003CAB28: D6570058 05611F59
	v_cvt_f32_ubyte0_e32 v87, v87                              // 0000003CAB30: 7EAE2357
	v_and_or_b32 v89, v90, 15, v92                             // 0000003CAB34: D6570059 05711F5A
	.long 0x7f563880                                           // 0000003CAB3C: 7F563880
	v_and_or_b32 v91, v93, 15, v91                             // 0000003CAB40: D657005B 056D1F5D
	v_cvt_f32_ubyte0_e32 v88, v88                              // 0000003CAB48: 7EB02358
	v_fma_mix_f32 v87, v87, v85, v85 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CAB4C: CC206057 1556AB57
	v_cvt_f32_ubyte0_e32 v89, v89                              // 0000003CAB54: 7EB22359
	v_lshrrev_b32_e32 v94, 4, v46                              // 0000003CAB58: 32BC5C84
	v_cvt_f32_ubyte0_e32 v91, v91                              // 0000003CAB5C: 7EB6235B
	v_fma_mix_f32 v88, v88, v85, v85 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CAB60: CC206058 1556AB58
	v_bfe_u32 v93, v87, 16, 1                                  // 0000003CAB68: D610005D 02052157
	v_fma_mix_f32 v89, v89, v85, v85 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CAB70: CC206059 1556AB59
	v_lshrrev_b32_e32 v95, 6, v46                              // 0000003CAB78: 32BE5C86
	v_fma_mix_f32 v91, v91, v85, v85 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CAB7C: CC20605B 1556AB5B
	v_bfe_u32 v116, v88, 16, 1                                 // 0000003CAB84: D6100074 02052158
	v_add3_u32 v87, v87, v93, 0x7fff                           // 0000003CAB8C: D6550057 03FEBB57 00007FFF
	v_bfe_u32 v93, v89, 16, 1                                  // 0000003CAB98: D610005D 02052159
	v_lshrrev_b32_e32 v96, 8, v46                              // 0000003CABA0: 32C05C88
	v_bfe_u32 v118, v91, 16, 1                                 // 0000003CABA4: D6100076 0205215B
	v_add3_u32 v88, v88, v116, 0x7fff                          // 0000003CABAC: D6550058 03FEE958 00007FFF
	.long 0x7e5639d7                                           // 0000003CABB8: 7E5639D7
	v_add3_u32 v87, v89, v93, 0x7fff                           // 0000003CABBC: D6550057 03FEBB59 00007FFF
	v_and_b32_e32 v94, 48, v94                                 // 0000003CABC8: 36BCBCB0
	v_add3_u32 v91, v91, v118, 0x7fff                          // 0000003CABCC: D655005B 03FEED5B 00007FFF
	v_lshrrev_b32_e32 v97, 20, v1                              // 0000003CABD8: 32C20294
	v_and_or_b32 v116, 0xffff0000, v88, v43                    // 0000003CABDC: D6570074 04AEB0FF FFFF0000
	.long 0x7e5639d7                                           // 0000003CABE8: 7E5639D7
	v_lshrrev_b32_e32 v98, 24, v1                              // 0000003CABEC: 32C40298
	v_and_b32_e32 v95, 48, v95                                 // 0000003CABF0: 36BEBEB0
	v_and_b32_e32 v96, 48, v96                                 // 0000003CABF4: 36C0C0B0
	v_lshrrev_b32_e32 v99, 28, v1                              // 0000003CABF8: 32C6029C
	v_and_or_b32 v119, 0xffff0000, v91, v43                    // 0000003CABFC: D6570077 04AEB6FF FFFF0000
	.long 0x7e563981                                           // 0000003CAC08: 7E563981
	v_lshrrev_b32_e32 v100, 10, v46                            // 0000003CAC0C: 32C85C8A
	v_and_or_b32 v95, v97, 15, v95                             // 0000003CAC10: D657005F 057D1F61
	v_and_or_b32 v96, v98, 15, v96                             // 0000003CAC18: D6570060 05811F62
	v_lshrrev_b32_e32 v103, 28, v2                             // 0000003CAC20: 32CE049C
	v_and_or_b32 v94, v43, 15, v94                             // 0000003CAC24: D657005E 05791F2B
	v_and_or_b32 v98, v100, 48, v99                            // 0000003CAC2C: D6570062 058D6164
	v_cvt_f32_ubyte0_e32 v95, v95                              // 0000003CAC34: 7EBE235F
	v_cvt_f32_ubyte0_e32 v96, v96                              // 0000003CAC38: 7EC02360
	v_lshrrev_b32_e32 v104, 26, v46                            // 0000003CAC3C: 32D05C9A
	v_cvt_f32_ubyte0_e32 v94, v94                              // 0000003CAC40: 7EBC235E
	v_cvt_f32_ubyte0_e32 v98, v98                              // 0000003CAC44: 7EC42362
	v_fma_mix_f32 v95, v95, v85, v85 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CAC48: CC20605F 1556AB5F
	v_fma_mix_f32 v96, v96, v85, v85 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CAC50: CC206060 1556AB60
	v_lshrrev_b32_e32 v108, 8, v3                              // 0000003CAC58: 32D80688
	v_fma_mix_f32 v94, v94, v85, v85 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CAC5C: CC20605E 1556AB5E
	v_fma_mix_f32 v98, v98, v85, v85 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CAC64: CC206062 1556AB62
	v_bfe_u32 v124, v95, 16, 1                                 // 0000003CAC6C: D610007C 0205215F
	v_and_b32_e32 v109, 48, v47                                // 0000003CAC74: 36DA5EB0
	v_lshrrev_b32_e32 v102, 14, v46                            // 0000003CAC78: 32CC5C8E
	v_bfe_u32 v100, v94, 16, 1                                 // 0000003CAC7C: D6100064 0205215E
	v_lshrrev_b32_e32 v105, 18, v46                            // 0000003CAC84: 32D25C92
	v_add3_u32 v95, v95, v124, 0x7fff                          // 0000003CAC88: D655005F 03FEF95F 00007FFF
	v_bfe_u32 v124, v98, 16, 1                                 // 0000003CAC94: D610007C 02052162
	v_lshrrev_b32_e32 v106, 8, v2                              // 0000003CAC9C: 32D40488
	v_add3_u32 v94, v94, v100, 0x7fff                          // 0000003CACA0: D655005E 03FEC95E 00007FFF
	v_bfe_u32 v100, v96, 16, 1                                 // 0000003CACAC: D6100064 02052160
	v_lshrrev_b32_e32 v112, 22, v46                            // 0000003CACB4: 32E05C96
	v_add3_u32 v98, v98, v124, 0x7fff                          // 0000003CACB8: D6550062 03FEF962 00007FFF
	v_lshrrev_b32_e32 v114, 24, v46                            // 0000003CACC4: 32E45C98
	.long 0x7e5639de                                           // 0000003CACC8: 7E5639DE
	v_add3_u32 v94, v96, v100, 0x7fff                          // 0000003CACCC: D655005E 03FEC960 00007FFF
	v_lshrrev_b32_e32 v117, 20, v46                            // 0000003CACD8: 32EA5C94
	v_lshrrev_b32_e32 v121, 12, v46                            // 0000003CACDC: 32F25C8C
	v_lshrrev_b32_e32 v107, 12, v2                             // 0000003CACE0: 32D6048C
	v_and_or_b32 v124, 0xffff0000, v95, v43                    // 0000003CACE4: D657007C 04AEBEFF FFFF0000
	.long 0x7e5639de                                           // 0000003CACF0: 7E5639DE
	v_and_or_b32 v95, v104, 48, v103                           // 0000003CACF4: D657005F 059D6168
	v_and_b32_e32 v105, 48, v105                               // 0000003CACFC: 36D2D2B0
	v_lshrrev_b32_e32 v100, 26, v47                            // 0000003CAD00: 32C85E9A
	v_lshrrev_b32_e32 v113, 20, v2                             // 0000003CAD04: 32E20494
	v_and_or_b32 v104, 0xffff0000, v98, v43                    // 0000003CAD08: D6570068 04AEC4FF FFFF0000
	.long 0x7e5639ae                                           // 0000003CAD14: 7E5639AE
	v_and_or_b32 v46, v108, 15, v109                           // 0000003CAD18: D657002E 05B51F6C
	v_and_or_b32 v105, v107, 15, v105                          // 0000003CAD20: D6570069 05A51F6B
	v_lshrrev_b32_e32 v89, 2, v47                              // 0000003CAD28: 32B25E82
	v_and_b32_e32 v112, 48, v112                               // 0000003CAD2C: 36E0E0B0
	v_and_b32_e32 v109, 48, v43                                // 0000003CAD30: 36DA56B0
	v_lshrrev_b32_e32 v93, 12, v3                              // 0000003CAD34: 32BA068C
	v_cvt_f32_ubyte0_e32 v105, v105                            // 0000003CAD38: 7ED22369
	v_and_b32_e32 v117, 48, v117                               // 0000003CAD3C: 36EAEAB0
	v_and_b32_e32 v89, 48, v89                                 // 0000003CAD40: 36B2B2B0
	v_and_or_b32 v106, v106, 15, v109                          // 0000003CAD44: D657006A 05B51F6A
	v_lshrrev_b32_e32 v109, 28, v4                             // 0000003CAD4C: 32DA089C
	v_fma_mix_f32 v105, v105, v85, v85 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CAD50: CC206069 1556AB69
	v_and_or_b32 v112, v113, 15, v112                          // 0000003CAD58: D6570070 05C11F71
	v_lshrrev_b32_e32 v90, 24, v2                              // 0000003CAD60: 32B40498
	v_cvt_f32_ubyte0_e32 v106, v106                            // 0000003CAD64: 7ED4236A
	v_and_or_b32 v109, v100, 48, v109                          // 0000003CAD68: D657006D 05B56164
	v_lshlrev_b32_e32 v88, 4, v47                              // 0000003CAD70: 30B05E84
	v_lshrrev_b32_e32 v96, 14, v47                             // 0000003CAD74: 32C05E8E
	v_and_b32_e32 v114, 48, v114                               // 0000003CAD78: 36E4E4B0
	v_fma_mix_f32 v106, v106, v85, v85 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CAD7C: CC20606A 1556AB6A
	v_and_or_b32 v89, v93, 15, v89                             // 0000003CAD84: D6570059 05651F5D
	v_cvt_f32_ubyte0_e32 v93, v95                              // 0000003CAD8C: 7EBA235F
	v_lshlrev_b32_e32 v92, 2, v47                              // 0000003CAD90: 30B85E82
	v_lshrrev_b32_e32 v97, 18, v47                             // 0000003CAD94: 32C25E92
	v_bfe_u32 v100, v106, 16, 1                                // 0000003CAD98: D6100064 0205216A
	v_lshrrev_b32_e32 v98, 4, v4                               // 0000003CADA0: 32C40884
	v_and_b32_e32 v88, 48, v88                                 // 0000003CADA4: 36B0B0B0
	v_and_b32_e32 v96, 48, v96                                 // 0000003CADA8: 36C0C0B0
	v_and_or_b32 v90, v90, 15, v114                            // 0000003CADAC: D657005A 05C91F5A
	v_add3_u32 v100, v106, v100, 0x7fff                        // 0000003CADB4: D6550064 03FEC96A 00007FFF
	v_bfe_u32 v106, v105, 16, 1                                // 0000003CADC0: D610006A 02052169
	v_lshrrev_b32_e32 v115, 4, v3                              // 0000003CADC8: 32E60684
	v_lshrrev_b32_e32 v99, 12, v4                              // 0000003CADCC: 32C6088C
	v_and_b32_e32 v92, 48, v92                                 // 0000003CADD0: 36B8B8B0
	.long 0x7e5639e4                                           // 0000003CADD4: 7E5639E4
	v_add3_u32 v105, v105, v106, 0x7fff                        // 0000003CADD8: D6550069 03FED569 00007FFF
	v_and_b32_e32 v97, 48, v97                                 // 0000003CADE4: 36C2C2B0
	v_and_or_b32 v88, v3, 15, v88                              // 0000003CADE8: D6570058 05611F03
	v_and_or_b32 v106, v98, 15, v96                            // 0000003CADF0: D657006A 05811F62
	v_cvt_f32_ubyte0_e32 v96, v112                             // 0000003CADF8: 7EC02370
	v_and_or_b32 v113, 0xffff0000, v105, v43                   // 0000003CADFC: D6570071 04AED2FF FFFF0000
	.long 0x7e563982                                           // 0000003CAE08: 7E563982
	v_cvt_f32_ubyte0_e32 v90, v90                              // 0000003CAE0C: 7EB4235A
	v_and_or_b32 v92, v115, 15, v92                            // 0000003CAE10: D657005C 05711F73
	v_and_or_b32 v105, v99, 15, v97                            // 0000003CAE18: D6570069 05851F63
	v_cvt_f32_ubyte0_e32 v88, v88                              // 0000003CAE20: 7EB02358
	v_and_or_b32 v95, v43, 15, v117                            // 0000003CAE24: D657005F 05D51F2B
	v_fma_mix_f32 v96, v96, v85, v85 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CAE2C: CC206060 1556AB60
	v_fma_mix_f32 v90, v90, v85, v85 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CAE34: CC20605A 1556AB5A
	v_lshrrev_b32_e32 v110, 28, v3                             // 0000003CAE3C: 32DC069C
	v_lshrrev_b32_e32 v111, 10, v47                            // 0000003CAE40: 32DE5E8A
	v_cvt_f32_ubyte0_e32 v95, v95                              // 0000003CAE44: 7EBE235F
	v_cvt_f32_ubyte0_e32 v46, v46                              // 0000003CAE48: 7E5C232E
	v_fma_mix_f32 v93, v93, v85, v85 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CAE4C: CC20605D 1556AB5D
	v_cvt_f32_ubyte0_e32 v92, v92                              // 0000003CAE54: 7EB8235C
	v_fma_mix_f32 v88, v88, v85, v85 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CAE58: CC206058 1556AB58
	v_fma_mix_f32 v95, v95, v85, v85 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CAE60: CC20605F 1556AB5F
	v_bfe_u32 v99, v96, 16, 1                                  // 0000003CAE68: D6100063 02052160
	v_lshrrev_b32_e32 v101, 4, v2                              // 0000003CAE70: 32CA0484
	v_and_or_b32 v108, v111, 48, v110                          // 0000003CAE74: D657006C 05B9616F
	v_and_b32_e32 v102, 48, v102                               // 0000003CAE7C: 36CCCCB0
	v_bfe_u32 v97, v95, 16, 1                                  // 0000003CAE80: D6100061 0205215F
	v_fma_mix_f32 v46, v46, v85, v85 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CAE88: CC20602E 1556AB2E
	v_cvt_f32_ubyte0_e32 v89, v89                              // 0000003CAE90: 7EB22359
	v_bfe_u32 v98, v93, 16, 1                                  // 0000003CAE94: D6100062 0205215D
	v_fma_mix_f32 v92, v92, v85, v85 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CAE9C: CC20605C 1556AB5C
	v_add3_u32 v95, v95, v97, 0x7fff                           // 0000003CAEA4: D655005F 03FEC35F 00007FFF
	v_bfe_u32 v97, v90, 16, 1                                  // 0000003CAEB0: D6100061 0205215A
	v_add3_u32 v96, v96, v99, 0x7fff                           // 0000003CAEB8: D6550060 03FEC760 00007FFF
	v_lshrrev_b32_e32 v87, 6, v47                              // 0000003CAEC4: 32AE5E86
	v_lshrrev_b32_e32 v103, 22, v47                            // 0000003CAEC8: 32CE5E96
	.long 0x7e5639df                                           // 0000003CAECC: 7E5639DF
	v_add3_u32 v90, v90, v97, 0x7fff                           // 0000003CAED0: D655005A 03FEC35A 00007FFF
	v_bfe_u32 v95, v88, 16, 1                                  // 0000003CAEDC: D610005F 02052158
	v_and_or_b32 v100, v101, 15, v102                          // 0000003CAEE4: D6570064 05991F65
	v_cvt_f32_ubyte0_e32 v101, v108                            // 0000003CAEEC: 7ECA236C
	v_fma_mix_f32 v89, v89, v85, v85 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CAEF0: CC206059 1556AB59
	v_add3_u32 v93, v93, v98, 0x7fff                           // 0000003CAEF8: D655005D 03FEC55D 00007FFF
	v_bfe_u32 v97, v92, 16, 1                                  // 0000003CAF04: D6100061 0205215C
	v_and_or_b32 v108, 0xffff0000, v96, v43                    // 0000003CAF0C: D657006C 04AEC0FF FFFF0000
	.long 0x7e5639da                                           // 0000003CAF18: 7E5639DA
	v_add3_u32 v88, v88, v95, 0x7fff                           // 0000003CAF1C: D6550058 03FEBF58 00007FFF
	v_bfe_u32 v90, v46, 16, 1                                  // 0000003CAF28: D610005A 0205212E
	v_lshrrev_b32_e32 v118, 20, v3                             // 0000003CAF30: 32EC0694
	v_lshrrev_b32_e32 v111, 20, v4                             // 0000003CAF34: 32DE0894
	v_and_b32_e32 v87, 48, v87                                 // 0000003CAF38: 36AEAEB0
	v_and_b32_e32 v103, 48, v103                               // 0000003CAF3C: 36CECEB0
	v_bfe_u32 v95, v89, 16, 1                                  // 0000003CAF40: D610005F 02052159
	v_add3_u32 v92, v92, v97, 0x7fff                           // 0000003CAF48: D655005C 03FEC35C 00007FFF
	v_and_or_b32 v112, 0xffff0000, v93, v43                    // 0000003CAF54: D6570070 04AEBAFF FFFF0000
	.long 0x7e5639d8                                           // 0000003CAF60: 7E5639D8
	v_add3_u32 v46, v46, v90, 0x7fff                           // 0000003CAF64: D655002E 03FEB52E 00007FFF
	v_lshrrev_b32_e32 v91, 4, v47                              // 0000003CAF70: 32B65E84
	v_and_or_b32 v87, v118, 15, v87                            // 0000003CAF74: D6570057 055D1F76
	v_and_or_b32 v103, v111, 15, v103                          // 0000003CAF7C: D6570067 059D1F6F
	v_add3_u32 v93, v89, v95, 0x7fff                           // 0000003CAF84: D655005D 03FEBF59 00007FFF
	v_and_or_b32 v111, 0xffff0000, v92, v43                    // 0000003CAF90: D657006F 04AEB8FF FFFF0000
	.long 0x7e5639ae                                           // 0000003CAF9C: 7E5639AE
	v_lshrrev_b32_e32 v1, 8, v47                               // 0000003CAFA0: 32025E88
	v_and_b32_e32 v91, 48, v91                                 // 0000003CAFA4: 36B6B6B0
	v_cvt_f32_ubyte0_e32 v46, v87                              // 0000003CAFA8: 7E5C2357
	global_load_b128 v[87:90], v[50:51], off offset:16         // 0000003CAFAC: DC5E0010 577C0032
	v_and_or_b32 v114, 0xffff0000, v93, v43                    // 0000003CAFB4: D6570072 04AEBAFF FFFF0000
	.long 0x7e563983                                           // 0000003CAFC0: 7E563983
	v_lshrrev_b32_e32 v120, 24, v3                             // 0000003CAFC4: 32F00698
	v_and_b32_e32 v1, 48, v1                                   // 0000003CAFC8: 360202B0
	v_fma_mix_f32 v3, v101, v85, v85 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CAFCC: CC206003 1556AB65
	v_lshrrev_b32_e32 v94, 24, v47                             // 0000003CAFD4: 32BC5E98
	v_lshrrev_b32_e32 v107, 24, v4                             // 0000003CAFD8: 32D60898
	v_and_b32_e32 v121, 48, v121                               // 0000003CAFDC: 36F2F2B0
	v_and_or_b32 v1, v120, 15, v1                              // 0000003CAFE0: D6570001 04051F78
	v_fma_mix_f32 v46, v46, v85, v85 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CAFE8: CC20602E 1556AB2E
	v_and_b32_e32 v94, 48, v94                                 // 0000003CAFF0: 36BCBCB0
	v_bfe_u32 v99, v3, 16, 1                                   // 0000003CAFF4: D6100063 02052103
	v_and_or_b32 v2, v2, 15, v121                              // 0000003CAFFC: D6570002 05E51F02
	v_cvt_f32_ubyte0_e32 v1, v1                                // 0000003CB004: 7E022301
	v_bfe_u32 v102, v46, 16, 1                                 // 0000003CB008: D6100066 0205212E
	v_and_or_b32 v107, v107, 15, v94                           // 0000003CB010: D657006B 05791F6B
	v_add3_u32 v3, v3, v99, 0x7fff                             // 0000003CB018: D6550003 03FEC703 00007FFF
	v_cvt_f32_ubyte0_e32 v2, v2                                // 0000003CB024: 7E042302
	v_fma_mix_f32 v1, v1, v85, v85 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CB028: CC206001 1556AB01
	v_add3_u32 v46, v46, v102, 0x7fff                          // 0000003CB030: D655002E 03FECD2E 00007FFF
	v_lshrrev_b32_e32 v122, 8, v4                              // 0000003CB03C: 32F40888
	v_and_b32_e32 v123, 15, v4                                 // 0000003CB040: 36F6088F
	v_fma_mix_f32 v2, v2, v85, v85 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CB044: CC206002 1556AB02
	v_bfe_u32 v99, v1, 16, 1                                   // 0000003CB04C: D6100063 02052101
	v_lshrrev_b32_e32 v125, 12, v47                            // 0000003CB054: 32FA5E8C
	v_lshrrev_b32_e32 v126, 20, v47                            // 0000003CB058: 32FC5E94
	v_add_nc_u32_e32 v42, 0x400, v42                           // 0000003CB05C: 4A5454FF 00000400
	v_add_nc_u32_e32 v82, 0x200, v82                           // 0000003CB064: 4AA4A4FF 00000200
	v_add3_u32 v1, v1, v99, 0x7fff                             // 0000003CB06C: D6550001 03FEC701 00007FFF
	v_and_or_b32 v110, v125, 48, v123                          // 0000003CB078: D657006E 05ED617D
	v_add_nc_u32_e32 v83, 0x100, v83                           // 0000003CB080: 4AA6A6FF 00000100
	v_add_nc_u32_e32 v84, 64, v84                              // 0000003CB088: 4AA8A8C0
	s_and_b32 s4, exec_lo, vcc_lo                              // 0000003CB08C: 8B046A7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000003CB090: BF8700B9
	s_or_b32 s19, s4, s19                                      // 0000003CB094: 8C131304
	s_waitcnt vmcnt(8)                                         // 0000003CB098: BF8923F7
	v_dot2_f32_bf16 v13, v13, v116, 0                          // 0000003CB09C: CC1A400D 1A02E90D
	v_dot2_f32_bf16 v13, v14, v119, v13                        // 0000003CB0A4: CC1A400D 1C36EF0E
	v_and_or_b32 v14, v43, 15, v91                             // 0000003CB0AC: D657000E 056D1F2B
	s_clause 0x1                                               // 0000003CB0B4: BF850001
	global_load_b128 v[91:94], v[54:55], off offset:16         // 0000003CB0B8: DC5E0010 5B7C0036
	global_load_b128 v[95:98], v[56:57], off offset:16         // 0000003CB0C0: DC5E0010 5F7C0038
	s_waitcnt vmcnt(9)                                         // 0000003CB0C8: BF8927F7
	v_dot2_f32_bf16 v21, v21, v116, 0                          // 0000003CB0CC: CC1A4015 1A02E915
	v_dot2_f32_bf16 v13, v15, v124, v13                        // 0000003CB0D4: CC1A400D 1C36F90F
	v_cvt_f32_ubyte0_e32 v101, v14                             // 0000003CB0DC: 7ECA230E
	s_waitcnt vmcnt(8)                                         // 0000003CB0E0: BF8923F7
	v_dot2_f32_bf16 v17, v17, v116, 0                          // 0000003CB0E4: CC1A4011 1A02E911
	v_dot2_f32_bf16 v21, v22, v119, v21                        // 0000003CB0EC: CC1A4015 1C56EF16
	v_dot2_f32_bf16 v115, v16, v104, v13                       // 0000003CB0F4: CC1A4073 1C36D110
	global_load_b128 v[13:16], v[48:49], off offset:16         // 0000003CB0FC: DC5E0010 0D7C0030
	v_fma_mix_f32 v101, v101, v85, v85 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CB104: CC206065 1556AB65
	s_waitcnt vmcnt(8)                                         // 0000003CB10C: BF8923F7
	v_dot2_f32_bf16 v9, v9, v116, 0                            // 0000003CB110: CC1A4009 1A02E909
	v_dot2_f32_bf16 v17, v18, v119, v17                        // 0000003CB118: CC1A4011 1C46EF12
	v_dot2_f32_bf16 v21, v23, v124, v21                        // 0000003CB120: CC1A4015 1C56F917
	v_bfe_u32 v18, v101, 16, 1                                 // 0000003CB128: D6100012 02052165
	s_delay_alu instid0(VALU_DEP_4)                            // 0000003CB130: BF870004
	v_dot2_f32_bf16 v9, v10, v119, v9                          // 0000003CB134: CC1A4009 1C26EF0A
	s_waitcnt vmcnt(7)                                         // 0000003CB13C: BF891FF7
	v_dot2_f32_bf16 v10, v29, v116, 0                          // 0000003CB140: CC1A400A 1A02E91D
	v_dot2_f32_bf16 v117, v24, v104, v21                       // 0000003CB148: CC1A4075 1C56D118
	global_load_b128 v[21:24], v[52:53], off offset:16         // 0000003CB150: DC5E0010 157C0034
	v_add3_u32 v101, v101, v18, 0x7fff                         // 0000003CB158: D6550065 03FE2565 00007FFF
	v_dot2_f32_bf16 v9, v11, v124, v9                          // 0000003CB164: CC1A4009 1C26F90B
	v_cvt_f32_ubyte0_e32 v29, v100                             // 0000003CB16C: 7E3A2364
	v_dot2_f32_bf16 v30, v30, v119, v10                        // 0000003CB170: CC1A401E 1C2AEF1E
	s_waitcnt vmcnt(7)                                         // 0000003CB178: BF891FF7
	v_dot2_f32_bf16 v25, v25, v116, 0                          // 0000003CB17C: CC1A4019 1A02E919
	.long 0x7e5639e5                                           // 0000003CB184: 7E5639E5
	v_dot2_f32_bf16 v120, v12, v104, v9                        // 0000003CB188: CC1A4078 1C26D10C
	global_load_b128 v[9:12], v[50:51], off offset:32          // 0000003CB190: DC5E0020 097C0032
	v_fma_mix_f32 v99, v29, v85, v85 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CB198: CC206063 1556AB1D
	v_dot2_f32_bf16 v25, v26, v119, v25                        // 0000003CB1A0: CC1A4019 1C66EF1A
	v_and_or_b32 v121, 0xffff0000, v46, v43                    // 0000003CB1A8: D6570079 04AE5CFF FFFF0000
	.long 0x7e563981                                           // 0000003CB1B4: 7E563981
	s_waitcnt vmcnt(7)                                         // 0000003CB1B8: BF891FF7
	v_dot2_f32_bf16 v1, v37, v116, 0                           // 0000003CB1BC: CC1A4001 1A02E925
	v_bfe_u32 v37, v99, 16, 1                                  // 0000003CB1C4: D6100025 02052163
	v_dot2_f32_bf16 v17, v19, v124, v17                        // 0000003CB1CC: CC1A4011 1C46F913
	v_dot2_f32_bf16 v26, v31, v124, v30                        // 0000003CB1D4: CC1A401A 1C7AF91F
	v_and_or_b32 v127, 0xffff0000, v3, v43                     // 0000003CB1DC: D657007F 04AE06FF FFFF0000
	s_waitcnt vmcnt(6)                                         // 0000003CB1E8: BF891BF7
	v_dot2_f32_bf16 v3, v33, v116, 0                           // 0000003CB1EC: CC1A4003 1A02E921
	v_bfe_u32 v33, v2, 16, 1                                   // 0000003CB1F4: D6100021 02052102
	.long 0x7e5639af                                           // 0000003CB1FC: 7E5639AF
	v_dot2_f32_bf16 v1, v38, v119, v1                          // 0000003CB200: CC1A4001 1C06EF26
	v_dot2_f32_bf16 v25, v27, v124, v25                        // 0000003CB208: CC1A4019 1C66F91B
	v_dot2_f32_bf16 v3, v34, v119, v3                          // 0000003CB210: CC1A4003 1C0EEF22
	v_add3_u32 v2, v2, v33, 0x7fff                             // 0000003CB218: D6550002 03FE4302 00007FFF
	v_add3_u32 v33, v99, v37, 0x7fff                           // 0000003CB224: D6550021 03FE4B63 00007FFF
	global_load_b128 v[99:102], v[54:55], off offset:32        // 0000003CB230: DC5E0020 637C0036
	v_and_b32_e32 v34, 48, v43                                 // 0000003CB238: 364456B0
	v_dot2_f32_bf16 v1, v39, v124, v1                          // 0000003CB23C: CC1A4001 1C06F927
	v_dot2_f32_bf16 v3, v35, v124, v3                          // 0000003CB244: CC1A4003 1C0EF923
	v_cvt_f32_ubyte0_e32 v35, v105                             // 0000003CB24C: 7E462369
	v_and_b32_e32 v46, 48, v126                                // 0000003CB250: 365CFCB0
	v_and_or_b32 v34, v122, 15, v34                            // 0000003CB254: D6570022 04891F7A
	v_dot2_f32_bf16 v116, v40, v104, v1                        // 0000003CB25C: CC1A4074 1C06D128
	.long 0x7e023982                                           // 0000003CB264: 7E023982
	.long 0x7f0239ab                                           // 0000003CB268: 7F0239AB
	v_cvt_f32_ubyte0_e32 v2, v110                              // 0000003CB26C: 7E04236E
	v_cvt_f32_ubyte0_e32 v34, v34                              // 0000003CB270: 7E442322
	v_dot2_f32_bf16 v126, v36, v104, v3                        // 0000003CB274: CC1A407E 1C0ED124
	v_dot2_f32_bf16 v118, v20, v104, v17                       // 0000003CB27C: CC1A4076 1C46D114
	v_and_or_b32 v122, 0xffff0000, v33, v1                     // 0000003CB284: D657007A 040642FF FFFF0000
	global_load_b128 v[17:20], v[58:59], off offset:16         // 0000003CB290: DC5E0010 117C003A
	v_fma_mix_f32 v119, v34, v85, v85 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CB298: CC206077 1556AB22
	v_dot2_f32_bf16 v123, v32, v104, v26                       // 0000003CB2A0: CC1A407B 1C6AD120
	v_dot2_f32_bf16 v125, v28, v104, v25                       // 0000003CB2A8: CC1A407D 1C66D11C
	v_cvt_f32_ubyte0_e32 v47, v109                             // 0000003CB2B0: 7E5E236D
	v_fma_mix_f32 v109, v2, v85, v85 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CB2B4: CC20606D 1556AB02
	v_bfe_u32 v3, v119, 16, 1                                  // 0000003CB2BC: D6100003 02052177
	v_fma_mix_f32 v2, v35, v85, v85 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CB2C4: CC206002 1556AB23
	v_cvt_f32_ubyte0_e32 v110, v106                            // 0000003CB2CC: 7EDC236A
	v_cvt_f32_ubyte0_e32 v1, v103                              // 0000003CB2D0: 7E022367
	s_clause 0x1                                               // 0000003CB2D4: BF850001
	global_load_b128 v[33:36], v[50:51], off offset:48         // 0000003CB2D8: DC5E0030 217C0032
	global_load_b128 v[103:106], v[54:55], off offset:48       // 0000003CB2E0: DC5E0030 677C0036
	v_add3_u32 v3, v119, v3, 0x7fff                            // 0000003CB2E8: D6550003 03FE0777 00007FFF
	s_clause 0x1                                               // 0000003CB2F4: BF850001
	global_load_b128 v[29:32], v[60:61], off offset:16         // 0000003CB2F8: DC5E0010 1D7C003C
	global_load_b128 v[25:28], v[62:63], off offset:16         // 0000003CB300: DC5E0010 197C003E
	v_bfe_u32 v124, v2, 16, 1                                  // 0000003CB308: D610007C 02052102
	v_cvt_f32_ubyte0_e32 v51, v107                             // 0000003CB310: 7E66236B
	.long 0x7e563983                                           // 0000003CB314: 7E563983
	v_fma_mix_f32 v107, v110, v85, v85 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CB318: CC20606B 1556AB6E
	v_fma_mix_f32 v110, v1, v85, v85 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CB320: CC20606E 1556AB01
	v_add3_u32 v2, v2, v124, 0x7fff                            // 0000003CB328: D6550002 03FEF902 00007FFF
	global_load_b128 v[37:40], v[56:57], off offset:32         // 0000003CB334: DC5E0020 257C0038
	v_fma_mix_f32 v47, v47, v85, v85 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CB33C: CC20602F 1556AB2F
	global_load_b128 v[54:57], v[56:57], off offset:48         // 0000003CB344: DC5E0030 367C0038
	s_waitcnt vmcnt(13)                                        // 0000003CB34C: BF8937F7
	v_dot2_f32_bf16 v87, v87, v122, v115                       // 0000003CB350: CC1A4057 1DCEF557
	v_and_or_b32 v115, 0xffff0000, v2, v43                     // 0000003CB358: D6570073 04AE04FF FFFF0000
	.long 0x7e563984                                           // 0000003CB364: 7E563984
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003CB368: BF870093
	v_dot2_f32_bf16 v50, v88, v113, v87                        // 0000003CB36C: CC1A4032 1D5EE358
	v_dot2_f32_bf16 v3, v89, v108, v50                         // 0000003CB374: CC1A4003 1CCAD959
	v_bfe_u32 v50, v109, 16, 1                                 // 0000003CB37C: D6100032 0205216D
	s_delay_alu instid0(VALU_DEP_2)                            // 0000003CB384: BF870002
	v_dot2_f32_bf16 v3, v90, v112, v3                          // 0000003CB388: CC1A4003 1C0EE15A
	global_load_b128 v[87:90], v[48:49], off offset:32         // 0000003CB390: DC5E0020 577C0030
	v_add3_u32 v109, v109, v50, 0x7fff                         // 0000003CB398: D655006D 03FE656D 00007FFF
	s_waitcnt vmcnt(13)                                        // 0000003CB3A4: BF8937F7
	v_dot2_f32_bf16 v1, v91, v122, v117                        // 0000003CB3A8: CC1A4001 1DD6F55B
	s_waitcnt vmcnt(12)                                        // 0000003CB3B0: BF8933F7
	v_dot2_f32_bf16 v91, v95, v122, v118                       // 0000003CB3B4: CC1A405B 1DDAF55F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003CB3BC: BF870112
	v_dot2_f32_bf16 v1, v92, v113, v1                          // 0000003CB3C0: CC1A4001 1C06E35C
	v_dot2_f32_bf16 v91, v96, v113, v91                        // 0000003CB3C8: CC1A405B 1D6EE360
	s_waitcnt vmcnt(11)                                        // 0000003CB3D0: BF892FF7
	v_dot2_f32_bf16 v13, v13, v122, v120                       // 0000003CB3D4: CC1A400D 1DE2F50D
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000003CB3DC: BF8701A2
	v_dot2_f32_bf16 v95, v97, v108, v91                        // 0000003CB3E0: CC1A405F 1D6ED961
	v_fma_mix_f32 v120, v51, v85, v85 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CB3E8: CC206078 1556AB33
	v_dot2_f32_bf16 v13, v14, v113, v13                        // 0000003CB3F0: CC1A400D 1C36E30E
	v_dot2_f32_bf16 v14, v93, v108, v1                         // 0000003CB3F8: CC1A400E 1C06D95D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 0000003CB400: BF870154
	v_dot2_f32_bf16 v117, v98, v112, v95                       // 0000003CB404: CC1A4075 1D7EE162
	global_load_b128 v[95:98], v[60:61], off offset:32         // 0000003CB40C: DC5E0020 5F7C003C
	v_dot2_f32_bf16 v13, v15, v108, v13                        // 0000003CB414: CC1A400D 1C36D90F
	s_waitcnt vmcnt(11)                                        // 0000003CB41C: BF892FF7
	v_dot2_f32_bf16 v21, v21, v122, v123                       // 0000003CB420: CC1A4015 1DEEF515
	v_dot2_f32_bf16 v118, v16, v112, v13                       // 0000003CB428: CC1A4076 1C36E110
	s_delay_alu instid0(VALU_DEP_2)                            // 0000003CB430: BF870002
	v_dot2_f32_bf16 v21, v22, v113, v21                        // 0000003CB434: CC1A4015 1C56E316
	s_waitcnt vmcnt(10)                                        // 0000003CB43C: BF892BF7
	v_dot2_f32_bf16 v9, v9, v111, v3                           // 0000003CB440: CC1A4009 1C0EDF09
	global_load_b128 v[1:4], v[52:53], off offset:32           // 0000003CB448: DC5E0020 017C0034
	v_dot2_f32_bf16 v21, v23, v108, v21                        // 0000003CB450: CC1A4015 1C56D917
	v_dot2_f32_bf16 v9, v10, v114, v9                          // 0000003CB458: CC1A4009 1C26E50A
	v_dot2_f32_bf16 v10, v94, v112, v14                        // 0000003CB460: CC1A400A 1C3AE15E
	s_clause 0x1                                               // 0000003CB468: BF850001
	global_load_b128 v[91:94], v[58:59], off offset:32         // 0000003CB46C: DC5E0020 5B7C003A
	global_load_b128 v[13:16], v[62:63], off offset:32         // 0000003CB474: DC5E0020 0D7C003E
	v_dot2_f32_bf16 v21, v24, v112, v21                        // 0000003CB47C: CC1A4015 1C56E118
	v_dot2_f32_bf16 v9, v11, v121, v9                          // 0000003CB484: CC1A4009 1C26F30B
	v_and_or_b32 v11, v43, 15, v46                             // 0000003CB48C: D657000B 04B91F2B
	v_bfe_u32 v46, v47, 16, 1                                  // 0000003CB494: D610002E 0205212F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003CB49C: BF870113
	v_dot2_f32_bf16 v119, v12, v127, v9                        // 0000003CB4A0: CC1A4077 1C26FF0C
	v_add3_u32 v124, v47, v46, 0x7fff                          // 0000003CB4A8: D655007C 03FE5D2F 00007FFF
	s_waitcnt vmcnt(12)                                        // 0000003CB4B4: BF8933F7
	v_dot2_f32_bf16 v10, v99, v111, v10                        // 0000003CB4B8: CC1A400A 1C2ADF63
	v_cvt_f32_ubyte0_e32 v99, v11                              // 0000003CB4C0: 7EC6230B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003CB4C4: BF870112
	v_dot2_f32_bf16 v51, v100, v114, v10                       // 0000003CB4C8: CC1A4033 1C2AE564
	v_fma_mix_f32 v85, v99, v85, v85 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003CB4D0: CC206055 1556AB63
	v_bfe_u32 v100, v107, 16, 1                                // 0000003CB4D8: D6100064 0205216B
	v_bfe_u32 v99, v110, 16, 1                                 // 0000003CB4E0: D6100063 0205216E
	global_load_b128 v[9:12], v[48:49], off offset:48          // 0000003CB4E8: DC5E0030 097C0030
	v_dot2_f32_bf16 v50, v101, v121, v51                       // 0000003CB4F0: CC1A4032 1CCEF365
	v_bfe_u32 v101, v85, 16, 1                                 // 0000003CB4F8: D6100065 02052155
	global_load_b128 v[46:49], v[52:53], off offset:48         // 0000003CB500: DC5E0030 2E7C0034
	v_add3_u32 v107, v107, v100, 0x7fff                        // 0000003CB508: D655006B 03FEC96B 00007FFF
	v_add3_u32 v110, v110, v99, 0x7fff                         // 0000003CB514: D655006E 03FEC76E 00007FFF
	v_dot2_f32_bf16 v128, v102, v127, v50                      // 0000003CB520: CC1A4080 1CCAFF66
	s_clause 0x1                                               // 0000003CB528: BF850001
	global_load_b128 v[50:53], v[58:59], off offset:48         // 0000003CB52C: DC5E0030 327C003A
	global_load_b128 v[58:61], v[60:61], off offset:48         // 0000003CB534: DC5E0030 3A7C003C
	v_add3_u32 v85, v85, v101, 0x7fff                          // 0000003CB53C: D6550055 03FECB55 00007FFF
	global_load_b128 v[99:102], v[62:63], off offset:48        // 0000003CB548: DC5E0030 637C003E
	s_waitcnt vmcnt(16)                                        // 0000003CB550: BF8943F7
	v_dot2_f32_bf16 v17, v17, v122, v125                       // 0000003CB554: CC1A4011 1DF6F511
	.long 0x7e5639d5                                           // 0000003CB55C: 7E5639D5
	v_mov_b32_e32 v85, v86                                     // 0000003CB560: 7EAA0356
	s_delay_alu instid0(VALU_DEP_3)                            // 0000003CB564: BF870003
	v_dot2_f32_bf16 v17, v18, v113, v17                        // 0000003CB568: CC1A4011 1C46E312
	s_waitcnt vmcnt(13)                                        // 0000003CB570: BF8937F7
	v_dot2_f32_bf16 v18, v29, v122, v116                       // 0000003CB574: CC1A4012 1DD2F51D
	s_waitcnt vmcnt(12)                                        // 0000003CB57C: BF8933F7
	v_dot2_f32_bf16 v25, v25, v122, v126                       // 0000003CB580: CC1A4019 1DFAF519
	v_dot2_f32_bf16 v17, v19, v108, v17                        // 0000003CB588: CC1A4011 1C46D913
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003CB590: BF870193
	v_dot2_f32_bf16 v18, v30, v113, v18                        // 0000003CB594: CC1A4012 1C4AE31E
	v_dot2_f32_bf16 v19, v26, v113, v25                        // 0000003CB59C: CC1A4013 1C66E31A
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_3)// 0000003CB5A4: BF8701D3
	v_dot2_f32_bf16 v17, v20, v112, v17                        // 0000003CB5A8: CC1A4011 1C46E114
	s_waitcnt vmcnt(11)                                        // 0000003CB5B0: BF892FF7
	v_dot2_f32_bf16 v37, v37, v111, v117                       // 0000003CB5B4: CC1A4025 1DD6DF25
	v_dot2_f32_bf16 v18, v31, v108, v18                        // 0000003CB5BC: CC1A4012 1C4AD91F
	v_dot2_f32_bf16 v19, v27, v108, v19                        // 0000003CB5C4: CC1A4013 1C4ED91B
	v_dot2_f32_bf16 v37, v38, v114, v37                        // 0000003CB5CC: CC1A4025 1C96E526
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003CB5D4: BF870193
	v_dot2_f32_bf16 v18, v32, v112, v18                        // 0000003CB5D8: CC1A4012 1C4AE120
	v_dot2_f32_bf16 v19, v28, v112, v19                        // 0000003CB5E0: CC1A4013 1C4EE11C
	.long 0x7e4c39ed                                           // 0000003CB5E8: 7E4C39ED
	.long 0x7f4c39ab                                           // 0000003CB5EC: 7F4C39AB
	v_dot2_f32_bf16 v37, v39, v121, v37                        // 0000003CB5F0: CC1A4025 1C96F327
	v_bfe_u32 v39, v120, 16, 1                                 // 0000003CB5F8: D6100027 02052178
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003CB600: BF870193
	v_and_or_b32 v38, 0xffff0000, v107, v38                    // 0000003CB604: D6570026 049AD6FF FFFF0000
	v_dot2_f32_bf16 v37, v40, v127, v37                        // 0000003CB610: CC1A4025 1C96FF28
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000003CB618: BF870223
	v_add3_u32 v39, v120, v39, 0x7fff                          // 0000003CB61C: D6550027 03FE4F78 00007FFF
	v_and_or_b32 v40, 0xffff0000, v110, v43                    // 0000003CB628: D6570028 04AEDCFF FFFF0000
	v_dot2_f32_bf16 v33, v33, v38, v119                        // 0000003CB634: CC1A4021 1DDE4D21
	v_dot2_f32_bf16 v22, v103, v38, v128                       // 0000003CB63C: CC1A4016 1E024D67
	s_waitcnt vmcnt(10)                                        // 0000003CB644: BF892BF7
	v_dot2_f32_bf16 v37, v54, v38, v37                         // 0000003CB648: CC1A4025 1C964D36
	.long 0x7e5639a7                                           // 0000003CB650: 7E5639A7
	v_dot2_f32_bf16 v33, v34, v115, v33                        // 0000003CB654: CC1A4021 1C86E722
	v_dot2_f32_bf16 v22, v104, v115, v22                       // 0000003CB65C: CC1A4016 1C5AE768
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003CB664: BF870214
	v_dot2_f32_bf16 v34, v55, v115, v37                        // 0000003CB668: CC1A4022 1C96E737
	v_and_or_b32 v23, 0xffff0000, v124, v43                    // 0000003CB670: D6570017 04AEF8FF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003CB67C: BF870214
	v_dot2_f32_bf16 v33, v35, v40, v33                         // 0000003CB680: CC1A4021 1C865123
	v_dot2_f32_bf16 v22, v105, v40, v22                        // 0000003CB688: CC1A4016 1C5A5169
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003CB690: BF870194
	v_dot2_f32_bf16 v24, v56, v40, v34                         // 0000003CB694: CC1A4018 1C8A5138
	v_dot2_f32_bf16 v29, v36, v23, v33                         // 0000003CB69C: CC1A401D 1C862F24
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003CB6A4: BF870193
	v_dot2_f32_bf16 v22, v106, v23, v22                        // 0000003CB6A8: CC1A4016 1C5A2F6A
	v_dot2_f32_bf16 v24, v57, v23, v24                         // 0000003CB6B0: CC1A4018 1C622F39
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003CB6B8: BF870112
	v_dual_add_f32 v77, v77, v29 :: v_dual_add_f32 v76, v76, v22// 0000003CB6BC: C9083B4D 4D4C2D4C
	v_add_f32_e32 v75, v75, v24                                // 0000003CB6C4: 0696314B
	s_waitcnt vmcnt(9)                                         // 0000003CB6C8: BF8927F7
	v_dot2_f32_bf16 v20, v87, v111, v118                       // 0000003CB6CC: CC1A4014 1DDADF57
	s_waitcnt vmcnt(8)                                         // 0000003CB6D4: BF8923F7
	v_dot2_f32_bf16 v18, v95, v111, v18                        // 0000003CB6D8: CC1A4012 1C4ADF5F
	s_waitcnt vmcnt(7)                                         // 0000003CB6E0: BF891FF7
	v_dot2_f32_bf16 v1, v1, v111, v21                          // 0000003CB6E4: CC1A4001 1C56DF01
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003CB6EC: BF870001
	v_dot2_f32_bf16 v1, v2, v114, v1                           // 0000003CB6F0: CC1A4001 1C06E502
	s_waitcnt vmcnt(6)                                         // 0000003CB6F8: BF891BF7
	v_dot2_f32_bf16 v17, v91, v111, v17                        // 0000003CB6FC: CC1A4011 1C46DF5B
	s_waitcnt vmcnt(5)                                         // 0000003CB704: BF8917F7
	v_dot2_f32_bf16 v13, v13, v111, v19                        // 0000003CB708: CC1A400D 1C4EDF0D
	v_dot2_f32_bf16 v19, v88, v114, v20                        // 0000003CB710: CC1A4013 1C52E558
	v_dot2_f32_bf16 v1, v3, v121, v1                           // 0000003CB718: CC1A4001 1C06F303
	v_dot2_f32_bf16 v2, v92, v114, v17                         // 0000003CB720: CC1A4002 1C46E55C
	v_dot2_f32_bf16 v17, v96, v114, v18                        // 0000003CB728: CC1A4011 1C4AE560
	v_dot2_f32_bf16 v13, v14, v114, v13                        // 0000003CB730: CC1A400D 1C36E50E
	v_dot2_f32_bf16 v14, v89, v121, v19                        // 0000003CB738: CC1A400E 1C4EF359
	v_dot2_f32_bf16 v1, v4, v127, v1                           // 0000003CB740: CC1A4001 1C06FF04
	v_dot2_f32_bf16 v2, v93, v121, v2                          // 0000003CB748: CC1A4002 1C0AF35D
	v_dot2_f32_bf16 v3, v97, v121, v17                         // 0000003CB750: CC1A4003 1C46F361
	v_dot2_f32_bf16 v13, v15, v121, v13                        // 0000003CB758: CC1A400D 1C36F30F
	v_dot2_f32_bf16 v14, v90, v127, v14                        // 0000003CB760: CC1A400E 1C3AFF5A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003CB768: BF870214
	v_dot2_f32_bf16 v2, v94, v127, v2                          // 0000003CB76C: CC1A4002 1C0AFF5E
	v_dot2_f32_bf16 v3, v98, v127, v3                          // 0000003CB774: CC1A4003 1C0EFF62
	s_delay_alu instid0(VALU_DEP_4)                            // 0000003CB77C: BF870004
	v_dot2_f32_bf16 v4, v16, v127, v13                         // 0000003CB780: CC1A4004 1C36FF10
	s_waitcnt vmcnt(4)                                         // 0000003CB788: BF8913F7
	v_dot2_f32_bf16 v9, v9, v38, v14                           // 0000003CB78C: CC1A4009 1C3A4D09
	s_waitcnt vmcnt(3)                                         // 0000003CB794: BF890FF7
	v_dot2_f32_bf16 v1, v46, v38, v1                           // 0000003CB798: CC1A4001 1C064D2E
	v_mov_b32_e32 v46, v44                                     // 0000003CB7A0: 7E5C032C
	s_delay_alu instid0(VALU_DEP_3)                            // 0000003CB7A4: BF870003
	v_dot2_f32_bf16 v9, v10, v115, v9                          // 0000003CB7A8: CC1A4009 1C26E70A
	s_waitcnt vmcnt(2)                                         // 0000003CB7B0: BF890BF7
	v_dot2_f32_bf16 v2, v50, v38, v2                           // 0000003CB7B4: CC1A4002 1C0A4D32
	s_waitcnt vmcnt(1)                                         // 0000003CB7BC: BF8907F7
	v_dot2_f32_bf16 v3, v58, v38, v3                           // 0000003CB7C0: CC1A4003 1C0E4D3A
	v_dot2_f32_bf16 v1, v47, v115, v1                          // 0000003CB7C8: CC1A4001 1C06E72F
	s_waitcnt vmcnt(0)                                         // 0000003CB7D0: BF8903F7
	v_dot2_f32_bf16 v4, v99, v38, v4                           // 0000003CB7D4: CC1A4004 1C124D63
	v_dot2_f32_bf16 v9, v11, v40, v9                           // 0000003CB7DC: CC1A4009 1C26510B
	v_dot2_f32_bf16 v2, v51, v115, v2                          // 0000003CB7E4: CC1A4002 1C0AE733
	v_dot2_f32_bf16 v3, v59, v115, v3                          // 0000003CB7EC: CC1A4003 1C0EE73B
	v_dot2_f32_bf16 v1, v48, v40, v1                           // 0000003CB7F4: CC1A4001 1C065130
	v_dot2_f32_bf16 v4, v100, v115, v4                         // 0000003CB7FC: CC1A4004 1C12E764
	v_dot2_f32_bf16 v9, v12, v23, v9                           // 0000003CB804: CC1A4009 1C262F0C
	v_dot2_f32_bf16 v2, v52, v40, v2                           // 0000003CB80C: CC1A4002 1C0A5134
	v_dot2_f32_bf16 v3, v60, v40, v3                           // 0000003CB814: CC1A4003 1C0E513C
	v_dot2_f32_bf16 v1, v49, v23, v1                           // 0000003CB81C: CC1A4001 1C062F31
	v_dot2_f32_bf16 v4, v101, v40, v4                          // 0000003CB824: CC1A4004 1C125165
	v_add_f32_e32 v74, v74, v9                                 // 0000003CB82C: 0694134A
	v_dot2_f32_bf16 v2, v53, v23, v2                           // 0000003CB830: CC1A4002 1C0A2F35
	v_dot2_f32_bf16 v3, v61, v23, v3                           // 0000003CB838: CC1A4003 1C0E2F3D
	v_add_f32_e32 v73, v73, v1                                 // 0000003CB840: 06920349
	v_dot2_f32_bf16 v4, v102, v23, v4                          // 0000003CB844: CC1A4004 1C122F66
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003CB84C: BF870214
	v_dual_mov_b32 v47, v45 :: v_dual_add_f32 v72, v72, v2     // 0000003CB850: CA08012D 2F480548
	v_add_f32_e32 v71, v71, v3                                 // 0000003CB858: 068E0747
	s_delay_alu instid0(VALU_DEP_3)                            // 0000003CB85C: BF870003
	v_dual_mov_b32 v3, v7 :: v_dual_add_f32 v70, v70, v4       // 0000003CB860: CA080107 03460946
	v_mov_b32_e32 v4, v8                                       // 0000003CB868: 7E080308
	v_dual_mov_b32 v2, v6 :: v_dual_mov_b32 v1, v5             // 0000003CB86C: CA100106 02000105
	s_and_not1_b32 exec_lo, exec_lo, s19                       // 0000003CB874: 917E137E
	s_cbranch_execz 429                                        // 0000003CB878: BFA501AD <_ZN7halogen12_GLOBAL__N_112k_hc6_fused3ILi8EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x3030>
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003CB87C: BF870111
	v_dual_mov_b32 v6, v2 :: v_dual_add_nc_u32 v67, 32, v67    // 0000003CB880: CA200102 064286A0
	v_dual_mov_b32 v5, v1 :: v_dual_mov_b32 v8, v4             // 0000003CB888: CA100101 05080104
	v_dual_mov_b32 v7, v3 :: v_dual_mov_b32 v44, v46           // 0000003CB890: CA100103 072C012E
	v_mov_b32_e32 v45, v47                                     // 0000003CB898: 7E5A032F
	s_mov_b32 s22, exec_lo                                     // 0000003CB89C: BE96007E
	v_cmp_ge_i32_e32 vcc_lo, v67, v68                          // 0000003CB8A0: 7C8C8943
	.long 0xd4c1007e                                           // 0000003CB8A4: D4C1007E
	v_cndmask_b32_e32 v1, v67, v68, vcc_lo                     // 0000003CB8A8: 02028943
	s_cbranch_execz 64599                                      // 0000003CB8AC: BFA5FC57 <_ZN7halogen12_GLOBAL__N_112k_hc6_fused3ILi8EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x1b0c>
	v_and_b32_e32 v7, -4, v84                                  // 0000003CB8B0: 360EA8C4
	v_ashrrev_i32_e32 v6, 31, v82                              // 0000003CB8B4: 340CA49F
	v_ashrrev_i32_e32 v8, 31, v83                              // 0000003CB8B8: 3410A69F
	.long 0xd7000405                                           // 0000003CB8BC: D7000405
	v_cndmask_b32_e32 v1, v41, v82, vcc_lo                     // 0000003CB8C0: 0202A529
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003CB8C4: BF870214
	v_ashrrev_i32_e32 v12, 31, v7                              // 0000003CB8C8: 34180E9F
	v_add_co_ci_u32_e64 v6, null, v69, v6, s4                  // 0000003CB8CC: D5207C06 00120D45
	.long 0xd7000409                                           // 0000003CB8D4: D7000409
	v_cndmask_b32_e32 v1, v78, v83, vcc_lo                     // 0000003CB8D8: 0202A74E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003CB8DC: BF8700A1
	v_add_co_ci_u32_e64 v10, null, v79, v8, s4                 // 0000003CB8E0: D5207C0A 0012114F
	.long 0xd700040b                                           // 0000003CB8E8: D700040B
	v_cndmask_b32_e32 v1, v80, v7, vcc_lo                      // 0000003CB8EC: 02020F50
	v_add_co_ci_u32_e64 v12, null, v81, v12, s4                // 0000003CB8F0: D5207C0C 00121951
	s_clause 0x2                                               // 0000003CB8F8: BF850002
	global_load_b128 v[5:8], v[5:6], off                       // 0000003CB8FC: DC5E0000 057C0005
	global_load_b64 v[44:45], v[9:10], off                     // 0000003CB904: DC560000 2C7C0009
	global_load_b32 v86, v[11:12], off                         // 0000003CB90C: DC520000 567C000B
	s_branch 64573                                             // 0000003CB914: BFA0FC3D <_ZN7halogen12_GLOBAL__N_112k_hc6_fused3ILi8EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x1b0c>
	s_mov_b32 s3, 0                                            // 0000003CB918: BE830080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000003CB91C: BF870009
	s_and_not1_b32 vcc_lo, exec_lo, s3                         // 0000003CB920: 916A037E
	s_cbranch_vccnz 1014                                       // 0000003CB924: BFA403F6 <_ZN7halogen12_GLOBAL__N_112k_hc6_fused3ILi8EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x3a00>
	s_load_b256 s[4:11], s[0:1], null                          // 0000003CB928: F40C0100 F8000000
	s_ashr_i32 s3, s2, 31                                      // 0000003CB930: 86039F02
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v5, v0              // 0000003CB934: CA100080 02040100
	s_lshr_b32 s14, s3, 30                                     // 0000003CB93C: 850E9E03
	s_load_b32 s1, s[0:1], 0x1b4                               // 0000003CB940: F4000040 F80001B4
	s_add_i32 s16, s2, s14                                     // 0000003CB948: 81100E02
	s_lshl_b64 s[14:15], s[2:3], 2                             // 0000003CB94C: 848E8202
	s_ashr_i32 s3, s16, 2                                      // 0000003CB950: 86038210
	s_mul_i32 s0, s2, 0x1400                                   // 0000003CB954: 9600FF02 00001400
	v_dual_mov_b32 v4, 0 :: v_dual_mov_b32 v1, v0              // 0000003CB95C: CA100080 04000100
	s_waitcnt lgkmcnt(0)                                       // 0000003CB964: BF89FC07
	s_add_u32 s8, s8, s14                                      // 0000003CB968: 80080E08
	s_addc_u32 s9, s9, s15                                     // 0000003CB96C: 82090F09
	s_add_u32 s0, s4, s0                                       // 0000003CB970: 80000004
	global_load_b32 v3, v2, s[8:9]                             // 0000003CB974: DC520000 03080002
	s_mul_hi_i32 s8, s2, 0x1400                                // 0000003CB97C: 9708FF02 00001400
	s_mul_i32 s9, s3, 0x1400                                   // 0000003CB984: 9609FF03 00001400
	s_addc_u32 s8, s5, s8                                      // 0000003CB98C: 82080805
	s_mul_hi_i32 s14, s3, 0x1400                               // 0000003CB990: 970EFF03 00001400
	s_add_u32 s6, s6, s9                                       // 0000003CB998: 80060906
	s_addc_u32 s7, s7, s14                                     // 0000003CB99C: 82070E07
	s_and_b32 s1, s1, 0xffff                                   // 0000003CB9A0: 8B01FF01 0000FFFF
	s_mov_b32 s9, 0                                            // 0000003CB9A8: BE890080
	s_set_inst_prefetch_distance 0x1                           // 0000003CB9AC: BF840001
	s_nop 0                                                    // 0000003CB9B0: BF800000
	s_nop 0                                                    // 0000003CB9B4: BF800000
	s_nop 0                                                    // 0000003CB9B8: BF800000
	s_nop 0                                                    // 0000003CB9BC: BF800000
	.long 0xd73c0006                                           // 0000003CB9C0: D73C0006
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 0000003CB9C4: 02020281
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003CB9C8: BF870091
	.long 0xd7006a08                                           // 0000003CB9CC: D7006A08
	v_cndmask_b32_e32 v1, s0, v6, vcc_lo                       // 0000003CB9D0: 02020C00
	v_add_co_ci_u32_e64 v9, null, s8, v7, vcc_lo               // 0000003CB9D4: D5207C09 01AA0E08
	.long 0xd7006a06                                           // 0000003CB9DC: D7006A06
	v_cndmask_b32_e32 v1, s6, v6, vcc_lo                       // 0000003CB9E0: 02020C06
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003CB9E4: BF870001
	v_add_co_ci_u32_e64 v7, null, s7, v7, vcc_lo               // 0000003CB9E8: D5207C07 01AA0E07
	global_load_u16 v10, v[8:9], off                           // 0000003CB9F0: DC4A0000 0A7C0008
	global_load_u16 v6, v[6:7], off                            // 0000003CB9F8: DC4A0000 067C0006
	s_waitcnt vmcnt(1)                                         // 0000003CBA00: BF8907F7
	v_lshlrev_b32_e32 v7, 16, v10                              // 0000003CBA04: 300E1490
	s_waitcnt vmcnt(0)                                         // 0000003CBA08: BF8903F7
	v_lshlrev_b32_e32 v6, 16, v6                               // 0000003CBA0C: 300C0C90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003CBA10: BF870091
	v_fmac_f32_e32 v7, v3, v6                                  // 0000003CBA14: 560E0D03
	v_bfe_u32 v6, v7, 16, 1                                    // 0000003CBA18: D6100006 02052107
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003CBA20: BF870091
	v_add3_u32 v6, v7, v6, 0x7fff                              // 0000003CBA24: D6550006 03FE0D07 00007FFF
	v_and_b32_e32 v7, 0xffff0000, v6                           // 0000003CBA30: 360E0CFF FFFF0000
	v_add_nc_u32_e32 v1, s1, v1                                // 0000003CBA38: 4A020201
	global_store_d16_hi_b16 v[8:9], v6, off                    // 0000003CBA3C: DC960000 007C0608
	v_fmac_f32_e32 v4, v7, v7                                  // 0000003CBA44: 56080F07
	v_cmp_lt_u32_e32 vcc_lo, 0x9ff, v1                         // 0000003CBA48: 7C9202FF 000009FF
	s_or_b32 s9, vcc_lo, s9                                    // 0000003CBA50: 8C09096A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000003CBA54: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s9                        // 0000003CBA58: 917E097E
	s_cbranch_execnz 65496                                     // 0000003CBA5C: BFA6FFD8 <_ZN7halogen12_GLOBAL__N_112k_hc6_fused3ILi8EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x2ac0>
	s_set_inst_prefetch_distance 0x2                           // 0000003CBA60: BF840002
	s_or_b32 exec_lo, exec_lo, s9                              // 0000003CBA64: 8C7E097E
	v_lshlrev_b32_e32 v1, 2, v0                                // 0000003CBA68: 30020082
	s_lshr_b32 s6, s1, 1                                       // 0000003CBA6C: 85068101
	s_mov_b32 s0, 0                                            // 0000003CBA70: BE800080
	ds_store_b32 v1, v4                                        // 0000003CBA74: D8340000 00000401
	s_waitcnt lgkmcnt(0)                                       // 0000003CBA7C: BF89FC07
	s_waitcnt_vscnt null, 0x0                                  // 0000003CBA80: BC7C0000
	s_barrier                                                  // 0000003CBA84: BFBD0000
	s_branch 17                                                // 0000003CBA88: BFA00011 <_ZN7halogen12_GLOBAL__N_112k_hc6_fused3ILi8EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x2bd0>
	s_nop 0                                                    // 0000003CBA8C: BF800000
	s_nop 0                                                    // 0000003CBA90: BF800000
	s_nop 0                                                    // 0000003CBA94: BF800000
	s_nop 0                                                    // 0000003CBA98: BF800000
	s_nop 0                                                    // 0000003CBA9C: BF800000
	s_nop 0                                                    // 0000003CBAA0: BF800000
	s_nop 0                                                    // 0000003CBAA4: BF800000
	s_nop 0                                                    // 0000003CBAA8: BF800000
	s_nop 0                                                    // 0000003CBAAC: BF800000
	s_nop 0                                                    // 0000003CBAB0: BF800000
	s_nop 0                                                    // 0000003CBAB4: BF800000
	s_nop 0                                                    // 0000003CBAB8: BF800000
	s_nop 0                                                    // 0000003CBABC: BF800000
	s_or_b32 exec_lo, exec_lo, s7                              // 0000003CBAC0: 8C7E077E
	s_waitcnt lgkmcnt(0)                                       // 0000003CBAC4: BF89FC07
	s_barrier                                                  // 0000003CBAC8: BFBD0000
	s_lshr_b32 s6, s6, 1                                       // 0000003CBACC: 85068106
	buffer_gl0_inv                                             // 0000003CBAD0: E0AC0000 00000000
	s_cbranch_scc0 15                                          // 0000003CBAD8: BFA1000F <_ZN7halogen12_GLOBAL__N_112k_hc6_fused3ILi8EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x2c18>
	s_mov_b32 s7, exec_lo                                      // 0000003CBADC: BE87007E
	.long 0xd4cc007e                                           // 0000003CBAE0: D4CC007E
	v_cndmask_b32_e32 v1, s6, v0, vcc_lo                       // 0000003CBAE4: 02020006
	s_cbranch_execz 65525                                      // 0000003CBAE8: BFA5FFF5 <_ZN7halogen12_GLOBAL__N_112k_hc6_fused3ILi8EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x2bc0>
	v_lshl_add_u32 v2, s6, 2, v1                               // 0000003CBAEC: D6460002 04050406
	ds_load_b32 v2, v2                                         // 0000003CBAF4: D8D80000 02000002
	ds_load_b32 v3, v1                                         // 0000003CBAFC: D8D80000 03000001
	s_waitcnt lgkmcnt(0)                                       // 0000003CBB04: BF89FC07
	v_add_f32_e32 v2, v2, v3                                   // 0000003CBB08: 06040702
	ds_store_b32 v1, v2                                        // 0000003CBB0C: D8340000 00000201
	s_branch 65514                                             // 0000003CBB14: BFA0FFEA <_ZN7halogen12_GLOBAL__N_112k_hc6_fused3ILi8EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x2bc0>
	v_mov_b32_e32 v1, 0                                        // 0000003CBB18: 7E020280
	s_cmp_eq_u32 s1, 1                                         // 0000003CBB1C: BF068101
	s_mul_hi_i32 s6, s2, 0x1400                                // 0000003CBB20: 9706FF02 00001400
	s_mul_i32 s7, s2, 0x1400                                   // 0000003CBB28: 9607FF02 00001400
	ds_load_b32 v1, v1                                         // 0000003CBB30: D8D80000 01000001
	s_waitcnt lgkmcnt(0)                                       // 0000003CBB38: BF89FC07
	v_div_scale_f32 v2, null, 0x45200000, 0x45200000, v1       // 0000003CBB3C: D6FC7C02 0405FEFF 45200000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003CBB48: BF870001
	v_rcp_f32_e32 v3, v2                                       // 0000003CBB4C: 7E065502
	v_xor_b32_e32 v2, 0x80000000, v2                           // 0000003CBB50: 3A0404FF 80000000
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(VALU_DEP_1)   // 0000003CBB58: BF870085
	v_fma_f32 v4, v2, v3, 1.0                                  // 0000003CBB5C: D6130004 03CA0702
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003CBB64: BF8700A1
	v_fmac_f32_e32 v3, v4, v3                                  // 0000003CBB68: 56060704
	v_div_scale_f32 v4, vcc_lo, v1, 0x45200000, v1             // 0000003CBB6C: D6FC6A04 0405FF01 45200000
	v_mul_f32_e32 v6, v4, v3                                   // 0000003CBB78: 100C0704
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003CBB7C: BF870091
	v_fma_f32 v7, v2, v6, v4                                   // 0000003CBB80: D6130007 04120D02
	v_fmac_f32_e32 v6, v7, v3                                  // 0000003CBB88: 560C0707
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003CBB8C: BF870091
	v_fmac_f32_e32 v4, v2, v6                                  // 0000003CBB90: 56080D02
	v_div_fmas_f32 v2, v4, v3, v6                              // 0000003CBB94: D6370002 041A0704
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003CBB9C: BF870091
	v_div_fixup_f32 v1, v2, 0x45200000, v1                     // 0000003CBBA0: D6270001 0405FF02 45200000
	v_add_f32_e32 v1, 0x358637bd, v1                           // 0000003CBBAC: 060202FF 358637BD
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000003CBBB4: BF870121
	v_mul_f32_e32 v2, 0x4b800000, v1                           // 0000003CBBB8: 100402FF 4B800000
	v_cmp_gt_f32_e32 vcc_lo, 0x800000, v1                      // 0000003CBBC0: 7C2802FF 00800000
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 0000003CBBC8: 02020501
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000003CBBCC: BF870291
	v_rsq_f32_e32 v1, v1                                       // 0000003CBBD0: 7E025D01
	v_mul_f32_e32 v2, 0x45800000, v1                           // 0000003CBBD4: 100402FF 45800000
	s_cbranch_scc1 5                                           // 0000003CBBDC: BFA20005 <_ZN7halogen12_GLOBAL__N_112k_hc6_fused3ILi8EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x2cf4>
	s_mov_b32 s0, -1                                           // 0000003CBBE0: BE8000C1
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003CBBE4: BF870001
	v_cndmask_b32_e32 v7, v1, v2, vcc_lo                       // 0000003CBBE8: 020E0501
	s_cbranch_execz 3                                          // 0000003CBBEC: BFA50003 <_ZN7halogen12_GLOBAL__N_112k_hc6_fused3ILi8EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x2cfc>
	s_branch 95                                                // 0000003CBBF0: BFA0005F <_ZN7halogen12_GLOBAL__N_112k_hc6_fused3ILi8EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x2e70>
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003CBBF4: BF870001
	v_cndmask_b32_e32 v7, v1, v2, vcc_lo                       // 0000003CBBF8: 020E0501
	v_sub_nc_u32_e32 v8, 0xa00, v0                             // 0000003CBBFC: 4C1000FF 00000A00
	v_lshl_or_b32 v2, v0, 1, s7                                // 0000003CBC04: D6560002 001D0300
	s_mul_i32 s0, s2, 0xa00                                    // 0000003CBC0C: 9600FF02 00000A00
	v_mov_b32_e32 v6, s6                                       // 0000003CBC14: 7E0C0206
	v_or_b32_e32 v1, s0, v0                                    // 0000003CBC18: 38020000
	v_and_b32_e32 v9, 0xbfe, v8                                // 0000003CBC1C: 361210FF 00000BFE
	.long 0xd7006a03                                           // 0000003CBC24: D7006A03
	v_cndmask_b32_e32 v1, s4, v2, vcc_lo                       // 0000003CBC28: 02020404
	s_mul_i32 s0, s3, 0x2800                                   // 0000003CBC2C: 9600FF03 00002800
	v_add_co_ci_u32_e64 v4, null, s5, v6, vcc_lo               // 0000003CBC34: D5207C04 01AA0C05
	.long 0xd7006a05                                           // 0000003CBC3C: D7006A05
	v_cndmask_b32_e32 v1, s20, v2, vcc_lo                      // 0000003CBC40: 02020414
	v_subrev_nc_u32_e32 v1, s0, v1                             // 0000003CBC44: 4E020200
	v_add_co_ci_u32_e64 v6, null, s21, v6, vcc_lo              // 0000003CBC48: D5207C06 01AA0C15
	v_mov_b32_e32 v10, v9                                      // 0000003CBC50: 7E140309
	s_mov_b32 s8, 0                                            // 0000003CBC54: BE880080
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000003CBC58: BF8700B3
	v_ashrrev_i32_e32 v2, 31, v1                               // 0000003CBC5C: 3404029F
	global_load_b32 v13, v[3:4], off                           // 0000003CBC60: DC520000 0D7C0003
	.long 0xd73c000b                                           // 0000003CBC68: D73C000B
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 0000003CBC6C: 02020281
	.long 0xd7006a0b                                           // 0000003CBC70: D7006A0B
	v_cndmask_b32_e32 v1, s10, v11, vcc_lo                     // 0000003CBC74: 0202160A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003CBC78: BF8700A1
	v_add_co_ci_u32_e64 v12, null, s11, v12, vcc_lo            // 0000003CBC7C: D5207C0C 01AA180B
	.long 0xd7006a03                                           // 0000003CBC84: D7006A03
	v_cndmask_b32_e32 v0, v3, v132, vcc_lo                     // 0000003CBC88: 02010903
	v_add_co_ci_u32_e64 v4, null, 0, v4, vcc_lo                // 0000003CBC8C: D5207C04 01AA0880
	global_load_b32 v2, v[11:12], off                          // 0000003CBC94: DC520000 027C000B
	.long 0x7f163880                                           // 0000003CBC9C: 7F163880
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000003CBCA0: BF8700D1
	.long 0x7f18398b                                           // 0000003CBCA4: 7F18398B
	s_waitcnt vmcnt(1)                                         // 0000003CBCA8: BF8907F7
	.long 0x7e1c390d                                           // 0000003CBCAC: 7E1C390D
	s_waitcnt vmcnt(0)                                         // 0000003CBCB0: BF8903F7
	.long 0x7e1e3902                                           // 0000003CBCB4: 7E1E3902
	v_lshlrev_b32_e32 v15, 16, v15                             // 0000003CBCB8: 301E1E90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003CBCBC: BF870091
	v_dual_add_f32 v15, 1.0, v15 :: v_dual_lshlrev_b32 v14, 16, v14// 0000003CBCC0: C9221EF2 0F0E1C90
	v_dual_mul_f32 v14, v7, v14 :: v_dual_add_nc_u32 v1, 2, v1 // 0000003CBCC8: C8E01D07 0E000282
	v_and_b32_e32 v2, 0xffff0000, v2                           // 0000003CBCD0: 360404FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003CBCD8: BF870091
	v_dual_add_f32 v2, 1.0, v2 :: v_dual_and_b32 v13, 0xffff0000, v13// 0000003CBCDC: C92404F2 020C1AFF FFFF0000
	v_dual_mul_f32 v13, v7, v13 :: v_dual_add_nc_u32 v10, -2, v10// 0000003CBCE8: C8E01B07 0D0A14C2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003CBCF0: BF870111
	v_cmp_eq_u32_e32 vcc_lo, 0, v10                            // 0000003CBCF4: 7C941480
	v_dual_mul_f32 v2, v13, v2 :: v_dual_mul_f32 v13, v14, v15 // 0000003CBCF8: C8C6050D 020C1F0E
	s_or_b32 s8, vcc_lo, s8                                    // 0000003CBD00: 8C08086A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003CBD04: BF870111
	.long 0x7e163982                                           // 0000003CBD08: 7E163982
	.long 0x7e18398d                                           // 0000003CBD0C: 7E18398D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003CBD10: BF870112
	v_and_b32_e32 v11, 1, v11                                  // 0000003CBD14: 36161681
	v_and_b32_e32 v12, 1, v12                                  // 0000003CBD18: 36181881
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003CBD1C: BF870112
	v_add3_u32 v2, v2, v11, 0x7fff                             // 0000003CBD20: D6550002 03FE1702 00007FFF
	v_add3_u32 v11, v13, v12, 0x7fff                           // 0000003CBD2C: D655000B 03FE190D 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000003CBD38: BF8700B1
	.long 0x7e04398b                                           // 0000003CBD3C: 7E04398B
	global_store_b32 v[5:6], v2, off                           // 0000003CBD40: DC6A0000 007C0205
	.long 0xd7000005                                           // 0000003CBD48: D7000005
	v_cndmask_b32_e32 v0, v5, v132, vcc_lo                     // 0000003CBD4C: 02010905
	v_add_co_ci_u32_e64 v6, null, 0, v6, s0                    // 0000003CBD50: D5207C06 00020C80
	s_and_not1_b32 exec_lo, exec_lo, s8                        // 0000003CBD58: 917E087E
	s_cbranch_execnz 65470                                     // 0000003CBD5C: BFA6FFBE <_ZN7halogen12_GLOBAL__N_112k_hc6_fused3ILi8EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x2d58>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000003CBD60: 8C7E087E
	v_add_nc_u32_e32 v5, v0, v9                                // 0000003CBD64: 4A0A1300
	.long 0xd44d0000                                           // 0000003CBD68: D44D0000
	v_cndmask_b32_e32 v1, v8, v9, vcc_lo                       // 0000003CBD6C: 02021308
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003CBD70: BF870001
	s_and_saveexec_b32 s8, s0                                  // 0000003CBD74: BE882000
	s_cbranch_execz 79                                         // 0000003CBD78: BFA5004F <_ZN7halogen12_GLOBAL__N_112k_hc6_fused3ILi8EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x2fb8>
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000003CBD7C: BF8704A2
	v_lshlrev_b32_e32 v1, 1, v5                                // 0000003CBD80: 30020A81
	s_lshl_b32 s0, s3, 2                                       // 0000003CBD84: 84008203
	s_sub_i32 s2, s2, s0                                       // 0000003CBD88: 81820002
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003CBD8C: BF870099
	s_mulk_i32 s2, 0xa00                                       // 0000003CBD90: B8020A00
	.long 0xd7000303                                           // 0000003CBD94: D7000303
	v_cndmask_b32_e32 v1, s7, v1, vcc_lo                       // 0000003CBD98: 02020207
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000003CBD9C: BF8700B1
	v_add_co_ci_u32_e64 v4, null, s6, 0, s3                    // 0000003CBDA0: D5207C04 000D0006
	s_lshl_b32 s3, s1, 1                                       // 0000003CBDA8: 84038101
	.long 0xd7006a01                                           // 0000003CBDAC: D7006A01
	v_cndmask_b32_e32 v1, s4, v3, vcc_lo                       // 0000003CBDB0: 02020604
	v_add_co_ci_u32_e64 v2, null, s5, v4, vcc_lo               // 0000003CBDB4: D5207C02 01AA0805
	.long 0xd7006a03                                           // 0000003CBDBC: D7006A03
	v_cndmask_b32_e32 v1, s20, v3, vcc_lo                      // 0000003CBDC0: 02020614
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003CBDC4: BF870001
	v_add_co_ci_u32_e64 v4, null, s21, v4, vcc_lo              // 0000003CBDC8: D5207C04 01AA0815
	s_mov_b32 s4, 0                                            // 0000003CBDD0: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000003CBDD4: BF840001
	s_nop 0                                                    // 0000003CBDD8: BF800000
	s_nop 0                                                    // 0000003CBDDC: BF800000
	s_nop 0                                                    // 0000003CBDE0: BF800000
	s_nop 0                                                    // 0000003CBDE4: BF800000
	s_nop 0                                                    // 0000003CBDE8: BF800000
	s_nop 0                                                    // 0000003CBDEC: BF800000
	s_nop 0                                                    // 0000003CBDF0: BF800000
	s_nop 0                                                    // 0000003CBDF4: BF800000
	s_nop 0                                                    // 0000003CBDF8: BF800000
	s_nop 0                                                    // 0000003CBDFC: BF800000
	v_add_nc_u32_e32 v8, s2, v5                                // 0000003CBE00: 4A100A02
	global_load_u16 v6, v[1:2], off                            // 0000003CBE04: DC4A0000 067C0001
	v_ashrrev_i32_e32 v9, 31, v8                               // 0000003CBE0C: 3412109F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003CBE10: BF870091
	.long 0xd73c0008                                           // 0000003CBE14: D73C0008
	v_cndmask_b32_e32 v1, 1, v8, vcc_lo                        // 0000003CBE18: 02021081
	.long 0xd7006a08                                           // 0000003CBE1C: D7006A08
	v_cndmask_b32_e32 v1, s10, v8, vcc_lo                      // 0000003CBE20: 0202100A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003CBE24: BF8700A1
	v_add_co_ci_u32_e64 v9, null, s11, v9, vcc_lo              // 0000003CBE28: D5207C09 01AA120B
	.long 0xd7006a01                                           // 0000003CBE30: D7006A01
	v_cndmask_b32_e32 v0, v1, v3, vcc_lo                       // 0000003CBE34: 02000701
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 0000003CBE38: D5207C02 01AA0480
	global_load_u16 v8, v[8:9], off                            // 0000003CBE40: DC4A0000 087C0008
	s_waitcnt vmcnt(1)                                         // 0000003CBE48: BF8907F7
	v_lshlrev_b32_e32 v6, 16, v6                               // 0000003CBE4C: 300C0C90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003CBE50: BF870091
	v_dual_mul_f32 v6, v7, v6 :: v_dual_add_nc_u32 v5, s1, v5  // 0000003CBE54: C8E00D07 06040A01
	v_cmp_lt_u32_e32 vcc_lo, 0x9ff, v5                         // 0000003CBE5C: 7C920AFF 000009FF
	s_or_b32 s4, vcc_lo, s4                                    // 0000003CBE64: 8C04046A
	s_waitcnt vmcnt(0)                                         // 0000003CBE68: BF8903F7
	v_lshlrev_b32_e32 v8, 16, v8                               // 0000003CBE6C: 30101090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003CBE70: BF870091
	v_add_f32_e32 v8, 1.0, v8                                  // 0000003CBE74: 061010F2
	v_mul_f32_e32 v6, v6, v8                                   // 0000003CBE78: 100C1106
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003CBE7C: BF870091
	v_bfe_u32 v8, v6, 16, 1                                    // 0000003CBE80: D6100008 02052106
	v_add3_u32 v6, v6, v8, 0x7fff                              // 0000003CBE88: D6550006 03FE1106 00007FFF
	global_store_d16_hi_b16 v[3:4], v6, off                    // 0000003CBE94: DC960000 007C0603
	.long 0xd7000003                                           // 0000003CBE9C: D7000003
	v_cndmask_b32_e32 v0, v3, v3, vcc_lo                       // 0000003CBEA0: 02000703
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003CBEA4: BF870001
	v_add_co_ci_u32_e64 v4, null, 0, v4, s0                    // 0000003CBEA8: D5207C04 00020880
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000003CBEB0: 917E047E
	s_cbranch_execnz 65490                                     // 0000003CBEB4: BFA6FFD2 <_ZN7halogen12_GLOBAL__N_112k_hc6_fused3ILi8EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x2f00>
	s_set_inst_prefetch_distance 0x2                           // 0000003CBEB8: BF840002
	s_or_b32 exec_lo, exec_lo, s8                              // 0000003CBEBC: 8C7E087E
	s_waitcnt_vscnt null, 0x0                                  // 0000003CBEC0: BC7C0000
	s_barrier                                                  // 0000003CBEC4: BFBD0000
	buffer_gl0_inv                                             // 0000003CBEC8: E0AC0000 00000000
	s_mov_b32 s0, exec_lo                                      // 0000003CBED0: BE80007E
	v_cmpx_eq_u32_e32 0, v0                                    // 0000003CBED4: 7D940080
	s_cbranch_execz 649                                        // 0000003CBED8: BFA50289 <_ZN7halogen12_GLOBAL__N_112k_hc6_fused3ILi8EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x3a00>
	s_mov_b32 s0, exec_lo                                      // 0000003CBEDC: BE80007E
	buffer_gl1_inv                                             // 0000003CBEE0: E0B00000 00000000
	buffer_gl0_inv                                             // 0000003CBEE8: E0AC0000 00000000
	.long 0xd71f0000                                           // 0000003CBEF0: D71F0000
	v_cndmask_b32_e32 v0, s0, v128, vcc_lo                     // 0000003CBEF4: 02010000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000003CBEF8: BF8704A1
	v_cmp_eq_u32_e32 vcc_lo, 0, v0                             // 0000003CBEFC: 7C940080
	s_and_b32 s1, exec_lo, vcc_lo                              // 0000003CBF00: 8B016A7E
	s_mov_b32 exec_lo, s1                                      // 0000003CBF04: BEFE0001
	s_cbranch_execz 637                                        // 0000003CBF08: BFA5027D <_ZN7halogen12_GLOBAL__N_112k_hc6_fused3ILi8EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x3a00>
	s_bcnt1_i32_b32 s0, s0                                     // 0000003CBF0C: BE801800
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000003CBF10: BF870009
	v_dual_mov_b32 v1, 0 :: v_dual_mov_b32 v0, s0              // 0000003CBF14: CA100080 01000000
	global_atomic_add_u64 v1, v[0:1], s[12:13]                 // 0000003CBF1C: DD0E0000 000C0001
	s_nop 0                                                    // 0000003CBF24: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 0000003CBF28: BFB60003
	s_endpgm                                                   // 0000003CBF2C: BFB00000
	s_or_b32 exec_lo, exec_lo, s19                             // 0000003CBF30: 8C7E137E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000003CBF34: BF8700B9
	s_or_b32 exec_lo, exec_lo, s5                              // 0000003CBF38: 8C7E057E
	.long 0xd71f0001                                           // 0000003CBF3C: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000003CBF40: 020100C1
	s_mov_b32 s4, exec_lo                                      // 0000003CBF44: BE84007E
	v_xor_b32_e32 v2, 16, v1                                   // 0000003CBF48: 3A040290
	v_xor_b32_e32 v10, 8, v1                                   // 0000003CBF4C: 3A140288
	v_xor_b32_e32 v18, 4, v1                                   // 0000003CBF50: 3A240284
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000003CBF54: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 0000003CBF58: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 0000003CBF5C: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v10                           // 0000003CBF60: 7C9814A0
	s_delay_alu instid0(VALU_DEP_2)                            // 0000003CBF64: BF870002
	v_lshlrev_b32_e32 v2, 2, v2                                // 0000003CBF68: 30040482
	ds_bpermute_b32 v3, v2, v77                                // 0000003CBF6C: DACC0000 03004D02
	s_waitcnt lgkmcnt(0)                                       // 0000003CBF74: BF89FC07
	v_add_f32_e32 v3, v77, v3                                  // 0000003CBF78: 0606074D
	ds_bpermute_b32 v9, v2, v71                                // 0000003CBF7C: DACC0000 09004702
	ds_bpermute_b32 v7, v2, v73                                // 0000003CBF84: DACC0000 07004902
	ds_bpermute_b32 v5, v2, v75                                // 0000003CBF8C: DACC0000 05004B02
	v_cndmask_b32_e32 v10, v1, v10, vcc_lo                     // 0000003CBF94: 02141501
	ds_bpermute_b32 v4, v2, v76                                // 0000003CBF98: DACC0000 04004C02
	ds_bpermute_b32 v6, v2, v74                                // 0000003CBFA0: DACC0000 06004A02
	ds_bpermute_b32 v8, v2, v72                                // 0000003CBFA8: DACC0000 08004802
	v_cmp_gt_u32_e32 vcc_lo, 32, v18                           // 0000003CBFB0: 7C9824A0
	ds_bpermute_b32 v2, v2, v70                                // 0000003CBFB4: DACC0000 02004602
	s_waitcnt lgkmcnt(6)                                       // 0000003CBFBC: BF89FC67
	v_dual_cndmask_b32 v18, v1, v18 :: v_dual_add_f32 v9, v71, v9// 0000003CBFC0: CA482501 12081347
	s_waitcnt lgkmcnt(5)                                       // 0000003CBFC8: BF89FC57
	v_dual_add_f32 v7, v73, v7 :: v_dual_lshlrev_b32 v10, 2, v10// 0000003CBFCC: C9220F49 070A1482
	s_waitcnt lgkmcnt(4)                                       // 0000003CBFD4: BF89FC47
	v_add_f32_e32 v5, v75, v5                                  // 0000003CBFD8: 060A0B4B
	ds_bpermute_b32 v11, v10, v3                               // 0000003CBFDC: DACC0000 0B00030A
	s_waitcnt lgkmcnt(4)                                       // 0000003CBFE4: BF89FC47
	v_add_f32_e32 v4, v76, v4                                  // 0000003CBFE8: 0608094C
	ds_bpermute_b32 v13, v10, v5                               // 0000003CBFEC: DACC0000 0D00050A
	ds_bpermute_b32 v15, v10, v7                               // 0000003CBFF4: DACC0000 0F00070A
	s_waitcnt lgkmcnt(5)                                       // 0000003CBFFC: BF89FC57
	v_add_f32_e32 v6, v74, v6                                  // 0000003CC000: 060C0D4A
	s_waitcnt lgkmcnt(4)                                       // 0000003CC004: BF89FC47
	v_add_f32_e32 v8, v72, v8                                  // 0000003CC008: 06101148
	ds_bpermute_b32 v17, v10, v9                               // 0000003CC00C: DACC0000 1100090A
	s_waitcnt lgkmcnt(3)                                       // 0000003CC014: BF89FC37
	v_dual_add_f32 v2, v70, v2 :: v_dual_add_f32 v3, v3, v11   // 0000003CC018: C9080546 02021703
	ds_bpermute_b32 v12, v10, v4                               // 0000003CC020: DACC0000 0C00040A
	s_waitcnt lgkmcnt(3)                                       // 0000003CC028: BF89FC37
	v_dual_add_f32 v5, v5, v13 :: v_dual_lshlrev_b32 v18, 2, v18// 0000003CC02C: C9221B05 05122482
	ds_bpermute_b32 v14, v10, v6                               // 0000003CC034: DACC0000 0E00060A
	s_waitcnt lgkmcnt(3)                                       // 0000003CC03C: BF89FC37
	v_add_f32_e32 v7, v7, v15                                  // 0000003CC040: 060E1F07
	ds_bpermute_b32 v16, v10, v8                               // 0000003CC044: DACC0000 1000080A
	s_waitcnt lgkmcnt(3)                                       // 0000003CC04C: BF89FC37
	v_add_f32_e32 v9, v9, v17                                  // 0000003CC050: 06122309
	ds_bpermute_b32 v10, v10, v2                               // 0000003CC054: DACC0000 0A00020A
	s_waitcnt lgkmcnt(3)                                       // 0000003CC05C: BF89FC37
	v_add_f32_e32 v4, v4, v12                                  // 0000003CC060: 06081904
	ds_bpermute_b32 v12, v18, v5                               // 0000003CC064: DACC0000 0C000512
	s_waitcnt lgkmcnt(2)                                       // 0000003CC06C: BF89FC27
	v_add_f32_e32 v8, v8, v16                                  // 0000003CC070: 06102108
	s_waitcnt lgkmcnt(0)                                       // 0000003CC074: BF89FC07
	v_add_f32_e32 v5, v5, v12                                  // 0000003CC078: 060A1905
	ds_bpermute_b32 v16, v18, v9                               // 0000003CC07C: DACC0000 10000912
	v_add_f32_e32 v6, v6, v14                                  // 0000003CC084: 060C1D06
	ds_bpermute_b32 v14, v18, v7                               // 0000003CC088: DACC0000 0E000712
	s_waitcnt lgkmcnt(1)                                       // 0000003CC090: BF89FC17
	v_add_f32_e32 v9, v9, v16                                  // 0000003CC094: 06122109
	ds_bpermute_b32 v13, v18, v6                               // 0000003CC098: DACC0000 0D000612
	s_waitcnt lgkmcnt(1)                                       // 0000003CC0A0: BF89FC17
	v_add_f32_e32 v7, v7, v14                                  // 0000003CC0A4: 060E1D07
	ds_bpermute_b32 v15, v18, v8                               // 0000003CC0A8: DACC0000 0F000812
	s_waitcnt lgkmcnt(0)                                       // 0000003CC0B0: BF89FC07
	v_add_f32_e32 v8, v8, v15                                  // 0000003CC0B4: 06101F08
	v_add_f32_e32 v2, v2, v10                                  // 0000003CC0B8: 06041502
	ds_bpermute_b32 v10, v18, v3                               // 0000003CC0BC: DACC0000 0A000312
	ds_bpermute_b32 v17, v18, v2                               // 0000003CC0C4: DACC0000 11000212
	s_waitcnt lgkmcnt(1)                                       // 0000003CC0CC: BF89FC17
	v_add_f32_e32 v3, v3, v10                                  // 0000003CC0D0: 06061503
	ds_bpermute_b32 v11, v18, v4                               // 0000003CC0D4: DACC0000 0B000412
	v_xor_b32_e32 v18, 2, v1                                   // 0000003CC0DC: 3A240282
	s_waitcnt lgkmcnt(1)                                       // 0000003CC0E0: BF89FC17
	v_add_f32_e32 v10, v2, v17                                 // 0000003CC0E4: 06142302
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003CC0E8: BF8700A2
	v_cmp_gt_u32_e32 vcc_lo, 32, v18                           // 0000003CC0EC: 7C9824A0
	v_cndmask_b32_e32 v18, v1, v18, vcc_lo                     // 0000003CC0F0: 02242501
	v_lshlrev_b32_e32 v18, 2, v18                              // 0000003CC0F4: 30242482
	s_waitcnt lgkmcnt(0)                                       // 0000003CC0F8: BF89FC07
	v_add_f32_e32 v4, v4, v11                                  // 0000003CC0FC: 06081704
	ds_bpermute_b32 v2, v18, v3                                // 0000003CC100: DACC0000 02000312
	v_add_f32_e32 v6, v6, v13                                  // 0000003CC108: 060C1B06
	ds_bpermute_b32 v12, v18, v5                               // 0000003CC10C: DACC0000 0C000512
	ds_bpermute_b32 v14, v18, v7                               // 0000003CC114: DACC0000 0E000712
	ds_bpermute_b32 v11, v18, v4                               // 0000003CC11C: DACC0000 0B000412
	ds_bpermute_b32 v15, v18, v8                               // 0000003CC124: DACC0000 0F000812
	ds_bpermute_b32 v13, v18, v6                               // 0000003CC12C: DACC0000 0D000612
	ds_bpermute_b32 v16, v18, v9                               // 0000003CC134: DACC0000 10000912
	ds_bpermute_b32 v17, v18, v10                              // 0000003CC13C: DACC0000 11000A12
	v_xor_b32_e32 v18, 1, v1                                   // 0000003CC144: 3A240281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000003CC148: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v18                           // 0000003CC14C: 7C9824A0
	v_cndmask_b32_e32 v1, v1, v18, vcc_lo                      // 0000003CC150: 02022501
	s_waitcnt lgkmcnt(7)                                       // 0000003CC154: BF89FC77
	v_dual_add_f32 v1, v3, v2 :: v_dual_lshlrev_b32 v18, 2, v1 // 0000003CC158: C9220503 01120282
	s_waitcnt lgkmcnt(4)                                       // 0000003CC160: BF89FC47
	v_add_f32_e32 v2, v4, v11                                  // 0000003CC164: 06041704
	s_waitcnt lgkmcnt(2)                                       // 0000003CC168: BF89FC27
	v_dual_add_f32 v4, v5, v12 :: v_dual_add_f32 v5, v6, v13   // 0000003CC16C: C9081905 04041B06
	v_add_f32_e32 v3, v7, v14                                  // 0000003CC174: 06061D07
	s_waitcnt lgkmcnt(1)                                       // 0000003CC178: BF89FC17
	v_dual_add_f32 v11, v8, v15 :: v_dual_add_f32 v12, v9, v16 // 0000003CC17C: C9081F08 0B0C2109
	s_waitcnt lgkmcnt(0)                                       // 0000003CC184: BF89FC07
	v_add_f32_e32 v13, v10, v17                                // 0000003CC188: 061A230A
	ds_bpermute_b32 v6, v18, v1                                // 0000003CC18C: DACC0000 06000112
	ds_bpermute_b32 v7, v18, v2                                // 0000003CC194: DACC0000 07000212
	ds_bpermute_b32 v9, v18, v4                                // 0000003CC19C: DACC0000 09000412
	ds_bpermute_b32 v10, v18, v5                               // 0000003CC1A4: DACC0000 0A000512
	ds_bpermute_b32 v8, v18, v3                                // 0000003CC1AC: DACC0000 08000312
	ds_bpermute_b32 v14, v18, v11                              // 0000003CC1B4: DACC0000 0E000B12
	ds_bpermute_b32 v15, v18, v12                              // 0000003CC1BC: DACC0000 0F000C12
	ds_bpermute_b32 v16, v18, v13                              // 0000003CC1C4: DACC0000 10000D12
	v_cmpx_eq_u32_e32 0, v64                                   // 0000003CC1CC: 7D948080
	s_cbranch_execz 17                                         // 0000003CC1D0: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_hc6_fused3ILi8EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x3318>
	s_waitcnt lgkmcnt(2)                                       // 0000003CC1D4: BF89FC27
	v_dual_add_f32 v11, v11, v14 :: v_dual_lshlrev_b32 v18, s27, v65// 0000003CC1D8: C9221D0B 0B12821B
	s_waitcnt lgkmcnt(0)                                       // 0000003CC1E0: BF89FC07
	v_dual_add_f32 v13, v13, v16 :: v_dual_add_f32 v12, v12, v15// 0000003CC1E4: C908210D 0D0C1F0C
	v_dual_add_f32 v17, v5, v10 :: v_dual_add_f32 v16, v4, v9  // 0000003CC1EC: C9081505 11101304
	v_dual_add_f32 v15, v2, v7 :: v_dual_add_f32 v14, v1, v6   // 0000003CC1F4: C9080F02 0F0E0D01
	v_add_lshl_u32 v1, v18, v66, 5                             // 0000003CC1FC: D6470001 02168512
	v_add_f32_e32 v10, v3, v8                                  // 0000003CC204: 06141103
	ds_store_b128 v1, v[14:17] offset:1280                     // 0000003CC208: DB7C0500 00000E01
	ds_store_b128 v1, v[10:13] offset:1296                     // 0000003CC210: DB7C0510 00000A01
	s_or_b32 exec_lo, exec_lo, s4                              // 0000003CC218: 8C7E047E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000003CC21C: BF870009
	s_and_b32 s4, s26, exec_lo                                 // 0000003CC220: 8B047E1A
	s_cselect_b32 s4, 8, 32                                    // 0000003CC224: 9804A088
	s_mov_b32 s5, exec_lo                                      // 0000003CC228: BE85007E
	s_waitcnt lgkmcnt(0)                                       // 0000003CC22C: BF89FC07
	s_barrier                                                  // 0000003CC230: BFBD0000
	buffer_gl0_inv                                             // 0000003CC234: E0AC0000 00000000
	.long 0xd4cc007e                                           // 0000003CC23C: D4CC007E
	v_cndmask_b32_e32 v1, s4, v0, vcc_lo                       // 0000003CC240: 02020004
	s_cbranch_execz 403                                        // 0000003CC244: BFA50193 <_ZN7halogen12_GLOBAL__N_112k_hc6_fused3ILi8EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x3994>
	s_load_b32 s4, s[8:9], 0x40                                // 0000003CC248: F4000104 F8000040
	v_lshrrev_b32_e32 v5, 3, v0                                // 0000003CC250: 320A0083
	v_mov_b32_e32 v4, 0                                        // 0000003CC254: 7E080280
	s_waitcnt lgkmcnt(0)                                       // 0000003CC258: BF89FC07
	s_sub_i32 s10, s24, s4                                     // 0000003CC25C: 818A0418
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000003CC260: BF870499
	s_ashr_i32 s11, s10, 31                                    // 0000003CC264: 860B9F0A
	s_lshl_b64 s[10:11], s[10:11], s28                         // 0000003CC268: 848A1C0A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003CC26C: BF870099
	.long 0xd7000401                                           // 0000003CC270: D7000401
	v_cndmask_b32_e32 v1, s10, v5, vcc_lo                      // 0000003CC274: 02020A0A
	v_add_co_ci_u32_e64 v2, null, s11, 0, s4                   // 0000003CC278: D5207C02 0011000B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003CC280: BF870001
	v_cmp_gt_i64_e32 vcc_lo, s[6:7], v[1:2]                    // 0000003CC284: 7CA80206
	s_and_b32 exec_lo, exec_lo, vcc_lo                         // 0000003CC288: 8B7E6A7E
	s_cbranch_execz 385                                        // 0000003CC28C: BFA50181 <_ZN7halogen12_GLOBAL__N_112k_hc6_fused3ILi8EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x3994>
	v_and_b32_e32 v3, 7, v0                                    // 0000003CC290: 36060087
	v_lshlrev_b32_e32 v5, s27, v5                              // 0000003CC294: 300A0A1B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003CC298: BF870092
	v_lshlrev_b32_e32 v6, 2, v3                                // 0000003CC29C: 300C0682
	v_lshl_or_b32 v5, v5, 5, v6                                // 0000003CC2A0: D6560005 04190B05
	ds_load_b32 v6, v5 offset:1280                             // 0000003CC2A8: D8D80500 06000005
	v_add_nc_u32_e32 v5, 32, v5                                // 0000003CC2B0: 4A0A0AA0
	s_add_i32 s25, s25, -1                                     // 0000003CC2B4: 8119C119
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000003CC2B8: BF870009
	s_cmp_eq_u32 s25, 0                                        // 0000003CC2BC: BF068019
	s_waitcnt lgkmcnt(0)                                       // 0000003CC2C0: BF89FC07
	v_add_f32_e32 v4, v4, v6                                   // 0000003CC2C4: 06080D04
	s_cbranch_scc0 65527                                       // 0000003CC2C8: BFA1FFF7 <_ZN7halogen12_GLOBAL__N_112k_hc6_fused3ILi8EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x33a8>
	s_clause 0x1                                               // 0000003CC2CC: BF850001
	s_load_b64 s[14:15], s[8:9], 0x38                          // 0000003CC2D0: F4040384 F8000038
	s_load_b64 s[10:11], s[8:9], 0x8                           // 0000003CC2D8: F4040284 F8000008
	s_mov_b32 s19, -1                                          // 0000003CC2E0: BE9300C1
	s_mov_b32 s18, 0                                           // 0000003CC2E4: BE920080
	s_mov_b32 s4, 0                                            // 0000003CC2E8: BE840080
	s_waitcnt lgkmcnt(0)                                       // 0000003CC2EC: BF89FC07
	s_cmp_lt_i32 s15, 3                                        // 0000003CC2F0: BF04830F
	s_cbranch_scc1 195                                         // 0000003CC2F4: BFA200C3 <_ZN7halogen12_GLOBAL__N_112k_hc6_fused3ILi8EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x3704>
	s_cmp_gt_i32 s15, 3                                        // 0000003CC2F8: BF02830F
	s_cbranch_scc0 73                                          // 0000003CC2FC: BFA10049 <_ZN7halogen12_GLOBAL__N_112k_hc6_fused3ILi8EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x3524>
	s_cmp_gt_i32 s15, 4                                        // 0000003CC300: BF02840F
	s_cbranch_scc0 73                                          // 0000003CC304: BFA10049 <_ZN7halogen12_GLOBAL__N_112k_hc6_fused3ILi8EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x352c>
	s_cmp_eq_u32 s15, 5                                        // 0000003CC308: BF06850F
	s_mov_b32 s4, -1                                           // 0000003CC30C: BE8400C1
	s_cbranch_scc0 66                                          // 0000003CC310: BFA10042 <_ZN7halogen12_GLOBAL__N_112k_hc6_fused3ILi8EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x351c>
	v_lshrrev_b32_e32 v5, 23, v2                               // 0000003CC314: 320A0497
	s_lshr_b32 s4, s7, 31                                      // 0000003CC318: 85049F07
	s_load_b64 s[8:9], s[8:9], 0x10                            // 0000003CC31C: F4040204 F8000010
	s_add_u32 s22, s6, s4                                      // 0000003CC324: 80160406
	s_addc_u32 s23, s7, 0                                      // 0000003CC328: 82178007
	.long 0xd7006a05                                           // 0000003CC32C: D7006A05
	v_cndmask_b32_e32 v1, v1, v5, vcc_lo                       // 0000003CC330: 02020B01
	s_ashr_i64 s[22:23], s[22:23], 1                           // 0000003CC334: 86968116
	v_add_co_ci_u32_e64 v10, null, 0, v2, vcc_lo               // 0000003CC338: D5207C0A 01AA0480
	v_dual_mov_b32 v12, s11 :: v_dual_and_b32 v11, 0xfffffe00, v5// 0000003CC340: CA24000B 0C0A0AFF FFFFFE00
	v_mad_u64_u32 v[5:6], null, s22, v3, 0                     // 0000003CC34C: D6FE7C05 02020616
	v_bfe_u32 v15, v4, 16, 1                                   // 0000003CC354: D610000F 02052104
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003CC35C: BF870093
	.long 0xd7016a08                                           // 0000003CC360: D7016A08
	v_cndmask_b32_e32 v1, v1, v11, vcc_lo                      // 0000003CC364: 02021701
	v_sub_co_ci_u32_e64 v9, null, v2, v10, vcc_lo              // 0000003CC368: D5217C09 01AA1502
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003CC370: BF870194
	v_mad_u64_u32 v[6:7], null, s23, v3, v[6:7]                // 0000003CC374: D6FE7C06 041A0617
	.long 0xd700040d                                           // 0000003CC37C: D700040D
	v_cndmask_b32_e32 v1, 0xffffff00, v8, vcc_lo               // 0000003CC380: 020210FF FFFFFF00
	s_delay_alu instid0(VALU_DEP_3)                            // 0000003CC388: BF870003
	v_cmp_gt_i64_e32 vcc_lo, 0x100, v[8:9]                     // 0000003CC38C: 7CA810FF 00000100
	v_mov_b32_e32 v7, s10                                      // 0000003CC394: 7E0E020A
	v_add_co_ci_u32_e64 v14, null, -1, v9, s4                  // 0000003CC398: D5207C0E 001212C1
	s_mov_b32 s4, 0                                            // 0000003CC3A0: BE840080
	.long 0xd73c0005                                           // 0000003CC3A4: D73C0005
	v_cndmask_b32_e32 v1, 1, v5, vcc_lo                        // 0000003CC3A8: 02020A81
	s_waitcnt lgkmcnt(0)                                       // 0000003CC3AC: BF89FC07
	v_dual_cndmask_b32 v8, v13, v8 :: v_dual_cndmask_b32 v7, s8, v7// 0000003CC3B0: CA52110D 08060E08
	v_dual_cndmask_b32 v12, s9, v12 :: v_dual_cndmask_b32 v9, v14, v9// 0000003CC3B8: CA521809 0C08130E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003CC3C0: BF870092
	.long 0xd7006a07                                           // 0000003CC3C4: D7006A07
	v_cndmask_b32_e32 v1, v7, v5, vcc_lo                       // 0000003CC3C8: 02020B07
	v_add_co_ci_u32_e64 v12, null, v12, v6, vcc_lo             // 0000003CC3CC: D5207C0C 01AA0D0C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003CC3D4: BF870193
	.long 0xd73c0005                                           // 0000003CC3D8: D73C0005
	v_cndmask_b32_e32 v1, 1, v8, vcc_lo                        // 0000003CC3DC: 02021081
	.long 0xd7006a07                                           // 0000003CC3E0: D7006A07
	v_cndmask_b32_e32 v1, v7, v11, vcc_lo                      // 0000003CC3E4: 02021707
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000003CC3E8: BF8701A1
	v_add_co_ci_u32_e64 v8, null, v12, v10, vcc_lo             // 0000003CC3EC: D5207C08 01AA150C
	v_add3_u32 v9, v4, v15, 0x7fff                             // 0000003CC3F4: D6550009 03FE1F04 00007FFF
	.long 0xd7006a05                                           // 0000003CC400: D7006A05
	v_cndmask_b32_e32 v1, v7, v5, vcc_lo                       // 0000003CC404: 02020B07
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003CC408: BF870001
	v_add_co_ci_u32_e64 v6, null, v8, v6, vcc_lo               // 0000003CC40C: D5207C06 01AA0D08
	global_store_d16_hi_b16 v[5:6], v9, off                    // 0000003CC414: DC960000 007C0905
	s_mov_b32 s8, 0                                            // 0000003CC41C: BE880080
	s_branch 3                                                 // 0000003CC420: BFA00003 <_ZN7halogen12_GLOBAL__N_112k_hc6_fused3ILi8EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x3530>
	s_mov_b32 s8, -1                                           // 0000003CC424: BE8800C1
	s_branch 54                                                // 0000003CC428: BFA00036 <_ZN7halogen12_GLOBAL__N_112k_hc6_fused3ILi8EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x3604>
	s_mov_b32 s8, -1                                           // 0000003CC42C: BE8800C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000003CC430: BF870009
	s_and_b32 vcc_lo, exec_lo, s8                              // 0000003CC434: 8B6A087E
	s_cbranch_vccz 49                                          // 0000003CC438: BFA30031 <_ZN7halogen12_GLOBAL__N_112k_hc6_fused3ILi8EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x3600>
	v_mul_f32_e32 v5, 0xbfb8aa3b, v4                           // 0000003CC43C: 100A08FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000003CC444: BF870291
	v_exp_f32_e32 v5, v5                                       // 0000003CC448: 7E0A4B05
	v_add_f32_e32 v9, 1.0, v5                                  // 0000003CC44C: 06120AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003CC450: BF870091
	v_div_scale_f32 v8, null, v9, v9, 1.0                      // 0000003CC454: D6FC7C08 03CA1309
	v_rcp_f32_e32 v10, v8                                      // 0000003CC45C: 7E145508
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003CC460: BF870095
	v_fma_f32 v5, -v8, v10, 1.0                                // 0000003CC464: D6130005 23CA1508
	v_fmac_f32_e32 v10, v5, v10                                // 0000003CC46C: 56141505
	v_div_scale_f32 v11, vcc_lo, 1.0, v9, 1.0                  // 0000003CC470: D6FC6A0B 03CA12F2
	v_mad_u64_u32 v[5:6], null, s6, v3, 0                      // 0000003CC478: D6FE7C05 02020606
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003CC480: BF870112
	v_mul_f32_e32 v12, v11, v10                                // 0000003CC484: 1018150B
	v_mad_u64_u32 v[6:7], null, s7, v3, v[6:7]                 // 0000003CC488: D6FE7C06 041A0607
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003CC490: BF870092
	v_fma_f32 v13, -v8, v12, v11                               // 0000003CC494: D613000D 242E1908
	v_fmac_f32_e32 v12, v13, v10                               // 0000003CC49C: 5618150D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003CC4A0: BF870113
	.long 0xd73c0005                                           // 0000003CC4A4: D73C0005
	v_cndmask_b32_e32 v1, 2, v5, vcc_lo                        // 0000003CC4A8: 02020A82
	v_fma_f32 v11, -v8, v12, v11                               // 0000003CC4AC: D613000B 242E1908
	.long 0xd73c0007                                           // 0000003CC4B4: D73C0007
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 0000003CC4B8: 02020282
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003CC4BC: BF870212
	v_div_fmas_f32 v10, v11, v10, v12                          // 0000003CC4C0: D637000A 0432150B
	.long 0xd7006a05                                           // 0000003CC4C8: D7006A05
	v_cndmask_b32_e32 v1, s10, v5, vcc_lo                      // 0000003CC4CC: 02020A0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003CC4D0: BF870191
	v_add_co_ci_u32_e64 v6, null, s11, v6, vcc_lo              // 0000003CC4D4: D5207C06 01AA0C0B
	v_div_fixup_f32 v9, v10, v9, 1.0                           // 0000003CC4DC: D6270009 03CA130A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003CC4E4: BF870093
	.long 0xd7006a05                                           // 0000003CC4E8: D7006A05
	v_cndmask_b32_e32 v1, v5, v7, vcc_lo                       // 0000003CC4EC: 02020F05
	v_add_co_ci_u32_e64 v6, null, v6, v8, vcc_lo               // 0000003CC4F0: D5207C06 01AA1106
	global_store_b32 v[5:6], v9, off                           // 0000003CC4F8: DC6A0000 007C0905
	s_mov_b32 s8, 0                                            // 0000003CC500: BE880080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000003CC504: BF870009
	s_and_b32 vcc_lo, exec_lo, s8                              // 0000003CC508: 8B6A087E
	s_cbranch_vccz 60                                          // 0000003CC50C: BFA3003C <_ZN7halogen12_GLOBAL__N_112k_hc6_fused3ILi8EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x3700>
	v_bfe_u32 v5, v4, 16, 1                                    // 0000003CC510: D6100005 02052104
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003CC518: BF870091
	v_add3_u32 v5, v4, v5, 0x7fff                              // 0000003CC51C: D6550005 03FE0B04 00007FFF
	v_and_b32_e32 v5, 0xffff0000, v5                           // 0000003CC528: 360A0AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003CC530: BF870091
	v_mul_f32_e32 v5, s14, v5                                  // 0000003CC534: 100A0A0E
	v_mul_f32_e32 v5, 0xbfb8aa3b, v5                           // 0000003CC538: 100A0AFF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000003CC540: BF870291
	v_exp_f32_e32 v5, v5                                       // 0000003CC544: 7E0A4B05
	v_add_f32_e32 v9, 1.0, v5                                  // 0000003CC548: 06120AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003CC54C: BF870091
	v_div_scale_f32 v8, null, v9, v9, 1.0                      // 0000003CC550: D6FC7C08 03CA1309
	v_rcp_f32_e32 v10, v8                                      // 0000003CC558: 7E145508
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003CC55C: BF870095
	v_fma_f32 v5, -v8, v10, 1.0                                // 0000003CC560: D6130005 23CA1508
	v_fmac_f32_e32 v10, v5, v10                                // 0000003CC568: 56141505
	v_div_scale_f32 v11, vcc_lo, 1.0, v9, 1.0                  // 0000003CC56C: D6FC6A0B 03CA12F2
	v_mad_u64_u32 v[5:6], null, s6, v3, 0                      // 0000003CC574: D6FE7C05 02020606
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003CC57C: BF870092
	v_mul_f32_e32 v12, v11, v10                                // 0000003CC580: 1018150B
	v_fma_f32 v7, -v8, v12, v11                                // 0000003CC584: D6130007 242E1908
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003CC58C: BF870211
	v_fmac_f32_e32 v12, v7, v10                                // 0000003CC590: 56181507
	v_mad_u64_u32 v[6:7], null, s7, v3, v[6:7]                 // 0000003CC594: D6FE7C06 041A0607
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003CC59C: BF870112
	v_fma_f32 v7, -v8, v12, v11                                // 0000003CC5A0: D6130007 242E1908
	.long 0xd73c0005                                           // 0000003CC5A8: D73C0005
	v_cndmask_b32_e32 v1, 2, v5, vcc_lo                        // 0000003CC5AC: 02020A82
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000003CC5B0: BF8701A2
	v_div_fmas_f32 v10, v7, v10, v12                           // 0000003CC5B4: D637000A 04321507
	.long 0xd73c0007                                           // 0000003CC5BC: D73C0007
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 0000003CC5C0: 02020282
	.long 0xd7006a05                                           // 0000003CC5C4: D7006A05
	v_cndmask_b32_e32 v1, s10, v5, vcc_lo                      // 0000003CC5C8: 02020A0A
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000003CC5CC: BF8701A3
	v_div_fixup_f32 v9, v10, v9, 1.0                           // 0000003CC5D0: D6270009 03CA130A
	v_add_co_ci_u32_e64 v6, null, s11, v6, vcc_lo              // 0000003CC5D8: D5207C06 01AA0C0B
	.long 0xd7006a05                                           // 0000003CC5E0: D7006A05
	v_cndmask_b32_e32 v1, v5, v7, vcc_lo                       // 0000003CC5E4: 02020F05
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003CC5E8: BF870193
	v_add_f32_e32 v9, v9, v9                                   // 0000003CC5EC: 06121309
	v_add_co_ci_u32_e64 v6, null, v6, v8, vcc_lo               // 0000003CC5F0: D5207C06 01AA1106
	global_store_b32 v[5:6], v9, off                           // 0000003CC5F8: DC6A0000 007C0905
	s_mov_b32 s19, 0                                           // 0000003CC600: BE930080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000003CC604: BF870009
	s_and_b32 vcc_lo, exec_lo, s19                             // 0000003CC608: 8B6A137E
	s_cbranch_vccz 72                                          // 0000003CC60C: BFA30048 <_ZN7halogen12_GLOBAL__N_112k_hc6_fused3ILi8EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x3830>
	s_cmp_gt_i32 s15, 1                                        // 0000003CC610: BF02810F
	s_mov_b32 s8, -1                                           // 0000003CC614: BE8800C1
	s_cbranch_scc0 64                                          // 0000003CC618: BFA10040 <_ZN7halogen12_GLOBAL__N_112k_hc6_fused3ILi8EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x381c>
	v_bfe_u32 v5, v4, 16, 1                                    // 0000003CC61C: D6100005 02052104
	s_mov_b32 s8, 0                                            // 0000003CC624: BE880080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003CC628: BF870091
	v_add3_u32 v5, v4, v5, 0x7fff                              // 0000003CC62C: D6550005 03FE0B04 00007FFF
	v_and_b32_e32 v5, 0xffff0000, v5                           // 0000003CC638: 360A0AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003CC640: BF870091
	v_mul_f32_e32 v5, 0xbfb8aa3b, v5                           // 0000003CC644: 100A0AFF BFB8AA3B
	v_exp_f32_e32 v5, v5                                       // 0000003CC64C: 7E0A4B05
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003CC650: BF870095
	v_add_f32_e32 v8, 1.0, v5                                  // 0000003CC654: 06100AF2
	v_div_scale_f32 v7, null, v8, v8, 1.0                      // 0000003CC658: D6FC7C07 03CA1108
	v_div_scale_f32 v10, vcc_lo, 1.0, v8, 1.0                  // 0000003CC660: D6FC6A0A 03CA10F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000003CC668: BF870292
	v_rcp_f32_e32 v9, v7                                       // 0000003CC66C: 7E125507
	v_fma_f32 v5, -v7, v9, 1.0                                 // 0000003CC670: D6130005 23CA1307
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000003CC678: BF870121
	v_fmac_f32_e32 v9, v5, v9                                  // 0000003CC67C: 56121305
	v_mad_u64_u32 v[5:6], null, s6, v3, 0                      // 0000003CC680: D6FE7C05 02020606
	v_mul_f32_e32 v11, v10, v9                                 // 0000003CC688: 1016130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003CC68C: BF870091
	v_fma_f32 v12, -v7, v11, v10                               // 0000003CC690: D613000C 242A1707
	v_fmac_f32_e32 v11, v12, v9                                // 0000003CC698: 5616130C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000003CC69C: BF870121
	v_fma_f32 v10, -v7, v11, v10                               // 0000003CC6A0: D613000A 242A1707
	v_mad_u64_u32 v[6:7], null, s7, v3, v[6:7]                 // 0000003CC6A8: D6FE7C06 041A0607
	v_div_fmas_f32 v7, v10, v9, v11                            // 0000003CC6B0: D6370007 042E130A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003CC6B8: BF870112
	.long 0xd73c0005                                           // 0000003CC6BC: D73C0005
	v_cndmask_b32_e32 v1, 1, v5, vcc_lo                        // 0000003CC6C0: 02020A81
	v_div_fixup_f32 v9, v7, v8, 1.0                            // 0000003CC6C4: D6270009 03CA1107
	.long 0xd73c0007                                           // 0000003CC6CC: D73C0007
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 0000003CC6D0: 02020281
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003CC6D4: BF870193
	.long 0xd7006a05                                           // 0000003CC6D8: D7006A05
	v_cndmask_b32_e32 v1, s10, v5, vcc_lo                      // 0000003CC6DC: 02020A0A
	v_bfe_u32 v10, v9, 16, 1                                   // 0000003CC6E0: D610000A 02052109
	v_add_co_ci_u32_e64 v6, null, s11, v6, vcc_lo              // 0000003CC6E8: D5207C06 01AA0C0B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003CC6F0: BF870193
	.long 0xd7006a05                                           // 0000003CC6F4: D7006A05
	v_cndmask_b32_e32 v1, v5, v7, vcc_lo                       // 0000003CC6F8: 02020F05
	v_add3_u32 v9, v9, v10, 0x7fff                             // 0000003CC6FC: D6550009 03FE1509 00007FFF
	s_delay_alu instid0(VALU_DEP_3)                            // 0000003CC708: BF870003
	v_add_co_ci_u32_e64 v6, null, v6, v8, vcc_lo               // 0000003CC70C: D5207C06 01AA1106
	global_store_d16_hi_b16 v[5:6], v9, off                    // 0000003CC714: DC960000 007C0905
	s_and_not1_b32 vcc_lo, exec_lo, s8                         // 0000003CC71C: 916A087E
	s_cbranch_vccnz 3                                          // 0000003CC720: BFA40003 <_ZN7halogen12_GLOBAL__N_112k_hc6_fused3ILi8EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x3830>
	s_cmp_lg_u32 s15, 1                                        // 0000003CC724: BF07810F
	s_mov_b32 s18, -1                                          // 0000003CC728: BE9200C1
	s_cselect_b32 s4, -1, 0                                    // 0000003CC72C: 980480C1
	v_bfe_u32 v5, v4, 16, 1                                    // 0000003CC730: D6100005 02052104
	.long 0xd73c0001                                           // 0000003CC738: D73C0001
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 0000003CC73C: 02020281
	s_and_b32 vcc_lo, exec_lo, s4                              // 0000003CC740: 8B6A047E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000003CC744: BF870002
	v_add3_u32 v4, v4, v5, 0x7fff                              // 0000003CC748: D6550004 03FE0B04 00007FFF
	s_cbranch_vccz 20                                          // 0000003CC754: BFA30014 <_ZN7halogen12_GLOBAL__N_112k_hc6_fused3ILi8EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x38a8>
	v_mad_u64_u32 v[5:6], null, s6, v3, 0                      // 0000003CC758: D6FE7C05 02020606
	s_mov_b32 s18, 0                                           // 0000003CC760: BE920080
	v_mad_u64_u32 v[6:7], null, s7, v3, v[6:7]                 // 0000003CC764: D6FE7C06 041A0607
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003CC76C: BF870091
	.long 0xd73c0005                                           // 0000003CC770: D73C0005
	v_cndmask_b32_e32 v1, 1, v5, vcc_lo                        // 0000003CC774: 02020A81
	.long 0xd7006a05                                           // 0000003CC778: D7006A05
	v_cndmask_b32_e32 v1, s10, v5, vcc_lo                      // 0000003CC77C: 02020A0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003CC780: BF870111
	v_add_co_ci_u32_e64 v6, null, s11, v6, vcc_lo              // 0000003CC784: D5207C06 01AA0C0B
	.long 0xd7006a05                                           // 0000003CC78C: D7006A05
	v_cndmask_b32_e32 v1, v5, v1, vcc_lo                       // 0000003CC790: 02020305
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003CC794: BF870001
	v_add_co_ci_u32_e64 v6, null, v6, v2, vcc_lo               // 0000003CC798: D5207C06 01AA0506
	global_store_d16_hi_b16 v[5:6], v4, off                    // 0000003CC7A0: DC960000 007C0405
	s_and_not1_b32 vcc_lo, exec_lo, s18                        // 0000003CC7A8: 916A127E
	s_cbranch_vccnz 57                                         // 0000003CC7AC: BFA40039 <_ZN7halogen12_GLOBAL__N_112k_hc6_fused3ILi8EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x3994>
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003CC7B0: BF870091
	v_and_b32_e32 v4, 0xffff0000, v4                           // 0000003CC7B4: 360808FF FFFF0000
	v_mul_f32_e32 v7, s14, v4                                  // 0000003CC7BC: 100E080E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003CC7C0: BF870091
	v_mul_f32_e32 v4, 0xbfb8aa3b, v7                           // 0000003CC7C4: 10080EFF BFB8AA3B
	v_exp_f32_e32 v4, v4                                       // 0000003CC7CC: 7E084B04
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003CC7D0: BF870095
	v_add_f32_e32 v8, 1.0, v4                                  // 0000003CC7D4: 061008F2
	v_div_scale_f32 v6, null, v8, v8, v7                       // 0000003CC7D8: D6FC7C06 041E1108
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000003CC7E0: BF870291
	v_rcp_f32_e32 v9, v6                                       // 0000003CC7E4: 7E125506
	v_fma_f32 v4, -v6, v9, 1.0                                 // 0000003CC7E8: D6130004 23CA1306
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000003CC7F0: BF870131
	v_fmac_f32_e32 v9, v4, v9                                  // 0000003CC7F4: 56121304
	v_div_scale_f32 v10, vcc_lo, v7, v8, v7                    // 0000003CC7F8: D6FC6A0A 041E1107
	v_mad_u64_u32 v[4:5], null, s6, v3, 0                      // 0000003CC800: D6FE7C04 02020606
	v_mul_f32_e32 v11, v10, v9                                 // 0000003CC808: 1016130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003CC80C: BF870091
	v_fma_f32 v12, -v6, v11, v10                               // 0000003CC810: D613000C 242A1706
	v_fmac_f32_e32 v11, v12, v9                                // 0000003CC818: 5616130C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000003CC81C: BF870121
	v_fma_f32 v10, -v6, v11, v10                               // 0000003CC820: D613000A 242A1706
	v_mad_u64_u32 v[5:6], null, s7, v3, v[5:6]                 // 0000003CC828: D6FE7C05 04160607
	v_div_fmas_f32 v3, v10, v9, v11                            // 0000003CC830: D6370003 042E130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003CC838: BF870191
	v_div_fixup_f32 v6, v3, v8, v7                             // 0000003CC83C: D6270006 041E1103
	.long 0xd73c0003                                           // 0000003CC844: D73C0003
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 0000003CC848: 02020881
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003CC84C: BF870112
	v_bfe_u32 v5, v6, 16, 1                                    // 0000003CC850: D6100005 02052106
	.long 0xd7006a03                                           // 0000003CC858: D7006A03
	v_cndmask_b32_e32 v1, s10, v3, vcc_lo                      // 0000003CC85C: 0202060A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003CC860: BF870191
	v_add_co_ci_u32_e64 v4, null, s11, v4, vcc_lo              // 0000003CC864: D5207C04 01AA080B
	v_add3_u32 v5, v6, v5, 0x7fff                              // 0000003CC86C: D6550005 03FE0B06 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003CC878: BF870093
	.long 0xd7006a01                                           // 0000003CC87C: D7006A01
	v_cndmask_b32_e32 v1, v3, v1, vcc_lo                       // 0000003CC880: 02020303
	v_add_co_ci_u32_e64 v2, null, v4, v2, vcc_lo               // 0000003CC884: D5207C02 01AA0504
	global_store_d16_hi_b16 v[1:2], v5, off                    // 0000003CC88C: DC960000 007C0501
	s_or_b32 exec_lo, exec_lo, s5                              // 0000003CC894: 8C7E057E
	s_waitcnt_vscnt null, 0x0                                  // 0000003CC898: BC7C0000
	s_barrier                                                  // 0000003CC89C: BFBD0000
	buffer_gl0_inv                                             // 0000003CC8A0: E0AC0000 00000000
	s_and_saveexec_b32 s4, s3                                  // 0000003CC8A8: BE842003
	s_cbranch_execz 18                                         // 0000003CC8AC: BFA50012 <_ZN7halogen12_GLOBAL__N_112k_hc6_fused3ILi8EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x39f8>
	s_mov_b32 s3, exec_lo                                      // 0000003CC8B0: BE83007E
	buffer_gl1_inv                                             // 0000003CC8B4: E0B00000 00000000
	buffer_gl0_inv                                             // 0000003CC8BC: E0AC0000 00000000
	.long 0xd71f0001                                           // 0000003CC8C4: D71F0001
	v_cndmask_b32_e32 v0, s3, v128, vcc_lo                     // 0000003CC8C8: 02010003
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000003CC8CC: BF8704A1
	v_cmp_eq_u32_e32 vcc_lo, 0, v1                             // 0000003CC8D0: 7C940280
	s_and_b32 s5, exec_lo, vcc_lo                              // 0000003CC8D4: 8B056A7E
	s_mov_b32 exec_lo, s5                                      // 0000003CC8D8: BEFE0005
	s_cbranch_execz 6                                          // 0000003CC8DC: BFA50006 <_ZN7halogen12_GLOBAL__N_112k_hc6_fused3ILi8EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x39f8>
	s_bcnt1_i32_b32 s3, s3                                     // 0000003CC8E0: BE831803
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000003CC8E4: BF870009
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v1, s3              // 0000003CC8E8: CA100080 02000003
	global_atomic_add_u64 v2, v[1:2], s[16:17]                 // 0000003CC8F0: DD0E0000 00100102
	s_or_b32 exec_lo, exec_lo, s4                              // 0000003CC8F8: 8C7E047E
	s_cbranch_execz 64522                                      // 0000003CC8FC: BFA5FC0A <_ZN7halogen12_GLOBAL__N_112k_hc6_fused3ILi8EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x2a28>
	s_nop 0                                                    // 0000003CC900: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 0000003CC904: BFB60003
	s_endpgm                                                   // 0000003CC908: BFB00000
		...

