0000000000591900 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi7ELi32ELi1ELb0EEEvPKhPKtPvll>:
; _ZN7halogen12_GLOBAL__N_18k_lq8s32ILi7ELi32ELi1ELb0EEEvPKhPKtPvll():
	s_clause 0x1                                               // 000000591900: BF850001
	s_load_b256 s[4:11], s[0:1], null                          // 000000591904: F40C0100 F8000000
	s_load_b64 s[12:13], s[0:1], 0x20                          // 00000059190C: F4040300 F8000020
	v_lshrrev_b32_e32 v1, 5, v0                                // 000000591914: 32020085
	s_mov_b32 s3, 0                                            // 000000591918: BE830080
	v_dual_mov_b32 v16, 0 :: v_dual_and_b32 v15, 31, v0        // 00000059191C: CA240080 100E009F
	s_lshl_b64 s[0:1], s[2:3], 3                               // 000000591924: 84808302
	.long 0x7e363880                                           // 000000591928: 7E363880
	v_or_b32_e32 v9, s0, v1                                    // 00000059192C: 38120200
	v_mov_b32_e32 v10, s1                                      // 000000591930: 7E140201
	v_dual_mov_b32 v4, 0 :: v_dual_mov_b32 v5, 0               // 000000591934: CA100080 04040080
	v_dual_mov_b32 v6, 0 :: v_dual_lshlrev_b32 v11, 4, v15     // 00000059193C: CA220080 060A1E84
	s_waitcnt lgkmcnt(0)                                       // 000000591944: BF89FC07
	s_ashr_i32 s0, s11, 31                                     // 000000591948: 86009F0B
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[9:10]                 // 00000059194C: 7CA8120C
	s_lshr_b32 s0, s0, 28                                      // 000000591950: 85009C00
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000591954: BF8704A9
	s_add_u32 s2, s10, s0                                      // 000000591958: 8002000A
	s_addc_u32 s3, s11, 0                                      // 00000059195C: 8203800B
	s_ashr_i64 s[2:3], s[2:3], 4                               // 000000591960: 86828402
	v_cndmask_b32_e32 v1, 0, v9, vcc_lo                        // 000000591964: 02021280
	s_add_u32 s0, s10, s2                                      // 000000591968: 8000020A
	v_cndmask_b32_e64 v2, 0, s1, vcc_lo                        // 00000059196C: D5010002 01A80280
	s_addc_u32 s1, s11, s3                                     // 000000591974: 8201030B
	s_add_u32 s0, s0, 15                                       // 000000591978: 80008F00
	s_addc_u32 s1, s1, 0                                       // 00000059197C: 82018001
	s_and_b32 s0, s0, -16                                      // 000000591980: 8B00D000
	.long 0xd72c0003                                           // 000000591984: D72C0003
	v_cndmask_b32_e32 v0, v1, v1, vcc_lo                       // 000000591988: 02000301
	.long 0xd72c0007                                           // 00000059198C: D72C0007
	v_cndmask_b32_e32 v0, v2, v0, vcc_lo                       // 000000591990: 02000102
	v_mad_u64_u32 v[1:2], null, v1, s0, 0                      // 000000591994: D6FE7C01 02000101
	.long 0xd4440000                                           // 00000059199C: D4440000
	v_cndmask_b32_e32 v1, s2, v15, vcc_lo                      // 0000005919A0: 02021E02
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000005919A4: BF870192
	v_add3_u32 v2, v2, v3, v7                                  // 0000005919A8: D6550002 041E0702
	.long 0xd7000112                                           // 0000005919B0: D7000112
	v_cndmask_b32_e32 v1, s4, v1, vcc_lo                       // 0000005919B4: 02020204
	v_mov_b32_e32 v7, 0                                        // 0000005919B8: 7E0E0280
	s_delay_alu instid0(VALU_DEP_3)                            // 0000005919BC: BF870003
	v_add_co_ci_u32_e64 v20, null, s5, v2, s1                  // 0000005919C0: D5207C14 00060405
	s_and_saveexec_b32 s3, s0                                  // 0000005919C8: BE832000
	s_cbranch_execz 21                                         // 0000005919CC: BFA50015 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi7ELi32ELi1ELb0EEEvPKhPKtPvll+0x124>
	v_lshlrev_b32_e32 v3, 4, v15                               // 0000005919D0: 30061E84
	.long 0xd7000105                                           // 0000005919D4: D7000105
	v_cndmask_b32_e32 v0, v18, v10, vcc_lo                     // 0000005919D8: 02001512
	v_and_b32_e32 v7, 30, v0                                   // 0000005919DC: 360E009E
	v_add_co_ci_u32_e64 v6, null, s11, v20, s1                 // 0000005919E0: D5207C06 0006280B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005919E8: BF870094
	.long 0xd7000103                                           // 0000005919EC: D7000103
	v_cndmask_b32_e32 v1, v18, v3, vcc_lo                      // 0000005919F0: 02020712
	v_add_co_ci_u32_e64 v4, null, 0, v20, s1                   // 0000005919F4: D5207C04 00062880
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005919FC: BF870094
	.long 0xd700010c                                           // 000000591A00: D700010C
	v_cndmask_b32_e32 v1, v5, v7, vcc_lo                       // 000000591A04: 02020F05
	v_add_co_ci_u32_e64 v13, null, 0, v6, s1                   // 000000591A08: D5207C0D 00060C80
	s_clause 0x1                                               // 000000591A10: BF850001
	global_load_b128 v[4:7], v[3:4], off                       // 000000591A14: DC5E0000 047C0003
	global_load_d16_b16 v27, v[12:13], off                     // 000000591A1C: DC820000 1B7C000C
	s_or_b32 exec_lo, exec_lo, s3                              // 000000591A24: 8C7E037E
	v_dual_mov_b32 v19, 0 :: v_dual_mov_b32 v22, 0             // 000000591A28: CA100080 13160080
	v_dual_mov_b32 v17, 0 :: v_dual_mov_b32 v24, 0             // 000000591A30: CA100080 11180080
	v_mov_b32_e32 v21, 0                                       // 000000591A38: 7E2A0280
	v_mov_b32_e32 v23, 0                                       // 000000591A3C: 7E2E0280
	s_and_saveexec_b32 s3, s0                                  // 000000591A40: BE832000
	s_cbranch_execz 539                                        // 000000591A44: BFA5021B <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi7ELi32ELi1ELb0EEEvPKhPKtPvll+0x9b4>
	v_and_or_b32 v0, v0, 30, 32                                // 000000591A48: D6570000 02813D00
	.long 0xd7000001                                           // 000000591A50: D7000001
	v_cndmask_b32_e32 v1, s10, v1, vcc_lo                      // 000000591A54: 0202020A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000591A58: BF8701A1
	v_add_co_ci_u32_e64 v2, null, s11, v2, s0                  // 000000591A5C: D5207C02 0002040B
	v_dual_mov_b32 v12, 0 :: v_dual_mov_b32 v25, v15           // 000000591A64: CA100080 0C18010F
	.long 0xd7000000                                           // 000000591A6C: D7000000
	v_cndmask_b32_e32 v1, v1, v0, vcc_lo                       // 000000591A70: 02020101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000591A74: BF870191
	v_add_co_ci_u32_e64 v1, null, 0, v2, s0                    // 000000591A78: D5207C01 00020480
	v_mov_b32_e32 v23, v12                                     // 000000591A80: 7E2E030C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000591A84: BF870093
	.long 0xd700000d                                           // 000000591A88: D700000D
	v_cndmask_b32_e32 v1, s4, v0, vcc_lo                       // 000000591A8C: 02020004
	v_add_co_ci_u32_e64 v14, null, s5, v1, s0                  // 000000591A90: D5207C0E 00020205
	v_mov_b32_e32 v24, v12                                     // 000000591A98: 7E30030C
	v_mov_b32_e32 v21, v12                                     // 000000591A9C: 7E2A030C
	v_mov_b32_e32 v22, v12                                     // 000000591AA0: 7E2C030C
	v_mov_b32_e32 v17, v12                                     // 000000591AA4: 7E22030C
	v_mov_b32_e32 v19, v12                                     // 000000591AA8: 7E26030C
	v_mov_b32_e32 v16, v12                                     // 000000591AAC: 7E20030C
	s_mul_i32 s1, s11, 6                                       // 000000591AB0: 9601860B
	s_mul_hi_u32 s16, s10, 6                                   // 000000591AB4: 9690860A
	s_lshl_b64 s[14:15], s[10:11], 2                           // 000000591AB8: 848E820A
	s_add_i32 s16, s16, s1                                     // 000000591ABC: 81100110
	s_mul_i32 s18, s10, 6                                      // 000000591AC0: 9612860A
	s_mov_b32 s17, 0                                           // 000000591AC4: BE910080
	s_lshl_b64 s[4:5], s[10:11], 1                             // 000000591AC8: 8484810A
	s_branch 475                                               // 000000591ACC: BFA001DB <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi7ELi32ELi1ELb0EEEvPKhPKtPvll+0x93c>
	s_or_b32 exec_lo, exec_lo, s10                             // 000000591AD0: 8C7E0A7E
	v_bfe_i32 v28, v4, 0, 8                                    // 000000591AD4: D611001C 02210104
	s_and_b32 s0, exec_lo, s0                                  // 000000591ADC: 8B00007E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000591AE0: BF870099
	s_or_b32 s17, s0, s17                                      // 000000591AE4: 8C111100
	v_cvt_f32_i32_e32 v28, v28                                 // 000000591AE8: 7E380B1C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000591AEC: BF870091
	v_fma_mix_f32 v28, v27, v28, neg(0) op_sel_hi:[1,0,0]      // 000000591AF0: CC20001C 8A02391B
	v_bfe_u32 v29, v28, 16, 1                                  // 000000591AF8: D610001D 0205211C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000591B00: BF870121
	v_add3_u32 v28, v28, v29, 0x7fff                           // 000000591B04: D655001C 03FE3B1C 00007FFF
	.long 0x7f3a3880                                           // 000000591B10: 7F3A3880
	.long 0x7e3a399c                                           // 000000591B14: 7E3A399C
	v_bfe_i32 v28, v4, 8, 8                                    // 000000591B18: D611001C 02211104
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000591B20: BF870091
	v_cvt_f32_i32_e32 v28, v28                                 // 000000591B24: 7E380B1C
	v_fma_mix_f32 v28, v27, v28, neg(0) op_sel_hi:[1,0,0]      // 000000591B28: CC20001C 8A02391B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000591B30: BF870091
	v_bfe_u32 v30, v28, 16, 1                                  // 000000591B34: D610001E 0205211C
	v_add3_u32 v28, v28, v30, 0x7fff                           // 000000591B3C: D655001C 03FE3D1C 00007FFF
	v_bfe_i32 v30, v4, 16, 8                                   // 000000591B48: D611001E 02212104
	v_ashrrev_i32_e32 v4, 24, v4                               // 000000591B50: 34080898
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000591B54: BF870193
	v_and_or_b32 v35, 0xffff0000, v28, v29                     // 000000591B58: D6570023 047638FF FFFF0000
	v_cvt_f32_i32_e32 v30, v30                                 // 000000591B64: 7E3C0B1E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000591B68: BF870113
	v_cvt_f32_i32_e32 v4, v4                                   // 000000591B6C: 7E080B04
	v_fma_mix_f32 v30, v27, v30, neg(0) op_sel_hi:[1,0,0]      // 000000591B70: CC20001E 8A023D1B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000591B78: BF870112
	v_fma_mix_f32 v4, v27, v4, neg(0) op_sel_hi:[1,0,0]        // 000000591B7C: CC200004 8A02091B
	v_bfe_u32 v31, v30, 16, 1                                  // 000000591B84: D610001F 0205211E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000591B8C: BF870191
	v_add3_u32 v30, v30, v31, 0x7fff                           // 000000591B90: D655001E 03FE3F1E 00007FFF
	v_bfe_u32 v31, v4, 16, 1                                   // 000000591B9C: D610001F 02052104
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000591BA4: BF8701A2
	.long 0x7e3c399e                                           // 000000591BA8: 7E3C399E
	.long 0x7f3c399d                                           // 000000591BAC: 7F3C399D
	v_add3_u32 v4, v4, v31, 0x7fff                             // 000000591BB0: D6550004 03FE3F04 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000591BBC: BF8700A1
	v_and_or_b32 v36, 0xffff0000, v4, v30                      // 000000591BC0: D6570024 047A08FF FFFF0000
	v_bfe_i32 v4, v5, 0, 8                                     // 000000591BCC: D6110004 02210105
	v_cvt_f32_i32_e32 v4, v4                                   // 000000591BD4: 7E080B04
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000591BD8: BF870091
	v_fma_mix_f32 v4, v27, v4, neg(0) op_sel_hi:[1,0,0]        // 000000591BDC: CC200004 8A02091B
	v_bfe_u32 v28, v4, 16, 1                                   // 000000591BE4: D610001C 02052104
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000591BEC: BF870091
	v_add3_u32 v4, v4, v28, 0x7fff                             // 000000591BF0: D6550004 03FE3904 00007FFF
	.long 0x7e3a3984                                           // 000000591BFC: 7E3A3984
	v_bfe_i32 v4, v5, 8, 8                                     // 000000591C00: D6110004 02211105
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000591C08: BF870091
	v_cvt_f32_i32_e32 v4, v4                                   // 000000591C0C: 7E080B04
	v_fma_mix_f32 v4, v27, v4, neg(0) op_sel_hi:[1,0,0]        // 000000591C10: CC200004 8A02091B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000591C18: BF870091
	v_bfe_u32 v28, v4, 16, 1                                   // 000000591C1C: D610001C 02052104
	v_add3_u32 v4, v4, v28, 0x7fff                             // 000000591C24: D6550004 03FE3904 00007FFF
	v_bfe_i32 v28, v5, 16, 8                                   // 000000591C30: D611001C 02212105
	v_ashrrev_i32_e32 v5, 24, v5                               // 000000591C38: 340A0A98
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000591C3C: BF870193
	v_and_or_b32 v37, 0xffff0000, v4, v29                      // 000000591C40: D6570025 047608FF FFFF0000
	v_cvt_f32_i32_e32 v28, v28                                 // 000000591C4C: 7E380B1C
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000591C50: BF8701A3
	v_cvt_f32_i32_e32 v5, v5                                   // 000000591C54: 7E0A0B05
	v_bfe_i32 v4, v6, 0, 8                                     // 000000591C58: D6110004 02210106
	v_fma_mix_f32 v28, v27, v28, neg(0) op_sel_hi:[1,0,0]      // 000000591C60: CC20001C 8A02391B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000591C68: BF870193
	v_fma_mix_f32 v5, v27, v5, neg(0) op_sel_hi:[1,0,0]        // 000000591C6C: CC200005 8A020B1B
	v_cvt_f32_i32_e32 v4, v4                                   // 000000591C74: 7E080B04
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000591C78: BF870113
	v_bfe_u32 v30, v28, 16, 1                                  // 000000591C7C: D610001E 0205211C
	v_fma_mix_f32 v4, v27, v4, neg(0) op_sel_hi:[1,0,0]        // 000000591C84: CC200004 8A02091B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000591C8C: BF870122
	v_add3_u32 v28, v28, v30, 0x7fff                           // 000000591C90: D655001C 03FE3D1C 00007FFF
	v_bfe_u32 v30, v5, 16, 1                                   // 000000591C9C: D610001E 02052105
	.long 0x7e38399c                                           // 000000591CA4: 7E38399C
	.long 0x7f38399d                                           // 000000591CA8: 7F38399D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000591CAC: BF870093
	v_add3_u32 v5, v5, v30, 0x7fff                             // 000000591CB0: D6550005 03FE3D05 00007FFF
	v_and_or_b32 v38, 0xffff0000, v5, v28                      // 000000591CBC: D6570026 04720AFF FFFF0000
	v_bfe_u32 v5, v4, 16, 1                                    // 000000591CC8: D6100005 02052104
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000591CD0: BF870091
	v_add3_u32 v4, v4, v5, 0x7fff                              // 000000591CD4: D6550004 03FE0B04 00007FFF
	.long 0x7e3a3984                                           // 000000591CE0: 7E3A3984
	v_bfe_i32 v4, v6, 8, 8                                     // 000000591CE4: D6110004 02211106
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000591CEC: BF870091
	v_cvt_f32_i32_e32 v4, v4                                   // 000000591CF0: 7E080B04
	v_fma_mix_f32 v4, v27, v4, neg(0) op_sel_hi:[1,0,0]        // 000000591CF4: CC200004 8A02091B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000591CFC: BF870091
	v_bfe_u32 v5, v4, 16, 1                                    // 000000591D00: D6100005 02052104
	v_add3_u32 v4, v4, v5, 0x7fff                              // 000000591D08: D6550004 03FE0B04 00007FFF
	v_bfe_i32 v5, v6, 16, 8                                    // 000000591D14: D6110005 02212106
	v_ashrrev_i32_e32 v6, 24, v6                               // 000000591D1C: 340C0C98
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000591D20: BF870193
	v_and_or_b32 v39, 0xffff0000, v4, v29                      // 000000591D24: D6570027 047608FF FFFF0000
	v_cvt_f32_i32_e32 v5, v5                                   // 000000591D30: 7E0A0B05
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000591D34: BF8701A3
	v_cvt_f32_i32_e32 v6, v6                                   // 000000591D38: 7E0C0B06
	v_bfe_i32 v4, v7, 0, 8                                     // 000000591D3C: D6110004 02210107
	v_fma_mix_f32 v5, v27, v5, neg(0) op_sel_hi:[1,0,0]        // 000000591D44: CC200005 8A020B1B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000591D4C: BF870193
	v_fma_mix_f32 v6, v27, v6, neg(0) op_sel_hi:[1,0,0]        // 000000591D50: CC200006 8A020D1B
	v_cvt_f32_i32_e32 v4, v4                                   // 000000591D58: 7E080B04
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000591D5C: BF870113
	v_bfe_u32 v28, v5, 16, 1                                   // 000000591D60: D610001C 02052105
	v_fma_mix_f32 v4, v27, v4, neg(0) op_sel_hi:[1,0,0]        // 000000591D68: CC200004 8A02091B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000591D70: BF870122
	v_add3_u32 v5, v5, v28, 0x7fff                             // 000000591D74: D6550005 03FE3905 00007FFF
	v_bfe_u32 v28, v6, 16, 1                                   // 000000591D80: D610001C 02052106
	.long 0x7e0a3985                                           // 000000591D88: 7E0A3985
	.long 0x7f0a399d                                           // 000000591D8C: 7F0A399D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000591D90: BF870093
	v_add3_u32 v6, v6, v28, 0x7fff                             // 000000591D94: D6550006 03FE3906 00007FFF
	v_and_or_b32 v40, 0xffff0000, v6, v5                       // 000000591DA0: D6570028 04160CFF FFFF0000
	v_bfe_u32 v5, v4, 16, 1                                    // 000000591DAC: D6100005 02052104
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000591DB4: BF870091
	v_add3_u32 v4, v4, v5, 0x7fff                              // 000000591DB8: D6550004 03FE0B04 00007FFF
	.long 0x7e3a3984                                           // 000000591DC4: 7E3A3984
	v_bfe_i32 v4, v7, 8, 8                                     // 000000591DC8: D6110004 02211107
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000591DD0: BF870091
	v_cvt_f32_i32_e32 v4, v4                                   // 000000591DD4: 7E080B04
	v_fma_mix_f32 v4, v27, v4, neg(0) op_sel_hi:[1,0,0]        // 000000591DD8: CC200004 8A02091B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000591DE0: BF870091
	v_bfe_u32 v5, v4, 16, 1                                    // 000000591DE4: D6100005 02052104
	v_add3_u32 v4, v4, v5, 0x7fff                              // 000000591DEC: D6550004 03FE0B04 00007FFF
	v_bfe_i32 v5, v7, 16, 8                                    // 000000591DF8: D6110005 02212107
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000591E00: BF870112
	v_and_or_b32 v41, 0xffff0000, v4, v29                      // 000000591E04: D6570029 047608FF FFFF0000
	v_cvt_f32_i32_e32 v5, v5                                   // 000000591E10: 7E0A0B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000591E14: BF870091
	v_fma_mix_f32 v5, v27, v5, neg(0) op_sel_hi:[1,0,0]        // 000000591E18: CC200005 8A020B1B
	v_bfe_u32 v6, v5, 16, 1                                    // 000000591E20: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000591E28: BF870121
	v_add3_u32 v5, v5, v6, 0x7fff                              // 000000591E2C: D6550005 03FE0D05 00007FFF
	v_ashrrev_i32_e32 v6, 24, v7                               // 000000591E38: 340C0E98
	.long 0x7e0a3985                                           // 000000591E3C: 7E0A3985
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000591E40: BF870122
	v_cvt_f32_i32_e32 v6, v6                                   // 000000591E44: 7E0C0B06
	.long 0x7f0a399d                                           // 000000591E48: 7F0A399D
	v_fma_mix_f32 v6, v27, v6, neg(0) op_sel_hi:[1,0,0]        // 000000591E4C: CC200006 8A020D1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000591E54: BF870091
	v_bfe_u32 v7, v6, 16, 1                                    // 000000591E58: D6100007 02052106
	v_add3_u32 v6, v6, v7, 0x7fff                              // 000000591E60: D6550006 03FE0F06 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000591E6C: BF870131
	v_and_or_b32 v42, 0xffff0000, v6, v5                       // 000000591E70: D657002A 04160CFF FFFF0000
	.long 0xd73c0004                                           // 000000591E7C: D73C0004
	v_cndmask_b32_e32 v1, 1, v11, vcc_lo                       // 000000591E80: 02021681
	v_mov_b32_e32 v11, v26                                     // 000000591E84: 7E16031A
	.long 0xd700001f                                           // 000000591E88: D700001F
	v_cndmask_b32_e32 v1, s6, v4, vcc_lo                       // 000000591E8C: 02020806
	s_delay_alu instid0(VALU_DEP_1)                            // 000000591E90: BF870001
	v_add_co_ci_u32_e64 v32, null, s7, v5, s0                  // 000000591E94: D5207C20 00020A07
	s_clause 0x1                                               // 000000591E9C: BF850001
	global_load_b128 v[4:7], v[31:32], off                     // 000000591EA0: DC5E0000 047C001F
	global_load_b128 v[27:30], v[31:32], off offset:16         // 000000591EA8: DC5E0010 1B7C001F
	s_waitcnt vmcnt(1)                                         // 000000591EB0: BF8907F7
	v_dot2_f32_bf16 v4, v4, v35, 0                             // 000000591EB4: CC1A4004 1A024704
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000591EBC: BF870091
	v_dot2_f32_bf16 v4, v5, v36, v4                            // 000000591EC0: CC1A4004 1C124905
	v_dot2_f32_bf16 v4, v6, v37, v4                            // 000000591EC8: CC1A4004 1C124B06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000591ED0: BF8700A1
	v_dot2_f32_bf16 v4, v7, v38, v4                            // 000000591ED4: CC1A4004 1C124D07
	s_waitcnt vmcnt(0)                                         // 000000591EDC: BF8903F7
	v_dot2_f32_bf16 v4, v27, v39, v4                           // 000000591EE0: CC1A4004 1C124F1B
	.long 0xd700001b                                           // 000000591EE8: D700001B
	v_cndmask_b32_e32 v0, v31, v4, vcc_lo                      // 000000591EEC: 0200091F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000591EF0: BF8701B2
	v_dot2_f32_bf16 v4, v28, v40, v4                           // 000000591EF4: CC1A4004 1C12511C
	v_add_co_ci_u32_e64 v28, null, s5, v32, s0                 // 000000591EFC: D5207C1C 00024005
	.long 0xd7000021                                           // 000000591F04: D7000021
	v_cndmask_b32_e32 v0, v31, v14, vcc_lo                     // 000000591F08: 02001D1F
	v_dot2_f32_bf16 v4, v29, v41, v4                           // 000000591F0C: CC1A4004 1C12531D
	v_add_co_ci_u32_e64 v34, null, s15, v32, s0                // 000000591F14: D5207C22 0002400F
	.long 0xd700001f                                           // 000000591F1C: D700001F
	v_cndmask_b32_e32 v0, v31, v18, vcc_lo                     // 000000591F20: 0200251F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000591F24: BF870123
	v_dot2_f32_bf16 v4, v30, v42, v4                           // 000000591F28: CC1A4004 1C12551E
	v_add_co_ci_u32_e64 v32, null, s16, v32, s0                // 000000591F30: D5207C20 00024010
	v_add_f32_e32 v23, v23, v4                                 // 000000591F38: 062E0917
	s_clause 0x1                                               // 000000591F3C: BF850001
	global_load_b128 v[4:7], v[27:28], off                     // 000000591F40: DC5E0000 047C001B
	global_load_b128 v[27:30], v[27:28], off offset:16         // 000000591F48: DC5E0010 1B7C001B
	s_waitcnt vmcnt(1)                                         // 000000591F50: BF8907F7
	v_dot2_f32_bf16 v4, v4, v35, 0                             // 000000591F54: CC1A4004 1A024704
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000591F5C: BF870091
	v_dot2_f32_bf16 v4, v5, v36, v4                            // 000000591F60: CC1A4004 1C124905
	v_dot2_f32_bf16 v4, v6, v37, v4                            // 000000591F68: CC1A4004 1C124B06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000591F70: BF8700A1
	v_dot2_f32_bf16 v4, v7, v38, v4                            // 000000591F74: CC1A4004 1C124D07
	s_waitcnt vmcnt(0)                                         // 000000591F7C: BF8903F7
	v_dot2_f32_bf16 v4, v27, v39, v4                           // 000000591F80: CC1A4004 1C124F1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000591F88: BF870091
	v_dot2_f32_bf16 v4, v28, v40, v4                           // 000000591F8C: CC1A4004 1C12511C
	v_dot2_f32_bf16 v4, v29, v41, v4                           // 000000591F94: CC1A4004 1C12531D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000591F9C: BF870091
	v_dot2_f32_bf16 v4, v30, v42, v4                           // 000000591FA0: CC1A4004 1C12551E
	v_add_f32_e32 v24, v24, v4                                 // 000000591FA8: 06300918
	s_clause 0x1                                               // 000000591FAC: BF850001
	global_load_b128 v[4:7], v[33:34], off                     // 000000591FB0: DC5E0000 047C0021
	global_load_b128 v[27:30], v[33:34], off offset:16         // 000000591FB8: DC5E0010 1B7C0021
	.long 0xd7000021                                           // 000000591FC0: D7000021
	v_cndmask_b32_e32 v0, v33, v14, vcc_lo                     // 000000591FC4: 02001D21
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000591FC8: BF8700B1
	v_add_co_ci_u32_e64 v34, null, s15, v34, s0                // 000000591FCC: D5207C22 0002440F
	s_waitcnt vmcnt(1)                                         // 000000591FD4: BF8907F7
	v_dot2_f32_bf16 v4, v4, v35, 0                             // 000000591FD8: CC1A4004 1A024704
	v_dot2_f32_bf16 v4, v5, v36, v4                            // 000000591FE0: CC1A4004 1C124905
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000591FE8: BF870091
	v_dot2_f32_bf16 v4, v6, v37, v4                            // 000000591FEC: CC1A4004 1C124B06
	v_dot2_f32_bf16 v4, v7, v38, v4                            // 000000591FF4: CC1A4004 1C124D07
	s_waitcnt vmcnt(0)                                         // 000000591FFC: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000592000: BF870091
	v_dot2_f32_bf16 v4, v27, v39, v4                           // 000000592004: CC1A4004 1C124F1B
	v_dot2_f32_bf16 v4, v28, v40, v4                           // 00000059200C: CC1A4004 1C12511C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000592014: BF870091
	v_dot2_f32_bf16 v4, v29, v41, v4                           // 000000592018: CC1A4004 1C12531D
	v_dot2_f32_bf16 v4, v30, v42, v4                           // 000000592020: CC1A4004 1C12551E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000592028: BF870001
	v_add_f32_e32 v21, v21, v4                                 // 00000059202C: 062A0915
	s_clause 0x1                                               // 000000592030: BF850001
	global_load_b128 v[4:7], v[31:32], off                     // 000000592034: DC5E0000 047C001F
	global_load_b128 v[27:30], v[31:32], off offset:16         // 00000059203C: DC5E0010 1B7C001F
	s_waitcnt vmcnt(1)                                         // 000000592044: BF8907F7
	v_dot2_f32_bf16 v4, v4, v35, 0                             // 000000592048: CC1A4004 1A024704
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000592050: BF870091
	v_dot2_f32_bf16 v4, v5, v36, v4                            // 000000592054: CC1A4004 1C124905
	v_dot2_f32_bf16 v4, v6, v37, v4                            // 00000059205C: CC1A4004 1C124B06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000592064: BF8700A1
	v_dot2_f32_bf16 v4, v7, v38, v4                            // 000000592068: CC1A4004 1C124D07
	s_waitcnt vmcnt(0)                                         // 000000592070: BF8903F7
	v_dot2_f32_bf16 v4, v27, v39, v4                           // 000000592074: CC1A4004 1C124F1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000059207C: BF870091
	v_dot2_f32_bf16 v4, v28, v40, v4                           // 000000592080: CC1A4004 1C12511C
	v_dot2_f32_bf16 v4, v29, v41, v4                           // 000000592088: CC1A4004 1C12531D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000592090: BF870091
	v_dot2_f32_bf16 v4, v30, v42, v4                           // 000000592094: CC1A4004 1C12551E
	v_add_f32_e32 v22, v22, v4                                 // 00000059209C: 062C0916
	s_clause 0x1                                               // 0000005920A0: BF850001
	global_load_b128 v[4:7], v[33:34], off                     // 0000005920A4: DC5E0000 047C0021
	global_load_b128 v[27:30], v[33:34], off offset:16         // 0000005920AC: DC5E0010 1B7C0021
	s_waitcnt vmcnt(1)                                         // 0000005920B4: BF8907F7
	v_dot2_f32_bf16 v4, v4, v35, 0                             // 0000005920B8: CC1A4004 1A024704
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005920C0: BF870091
	v_dot2_f32_bf16 v4, v5, v36, v4                            // 0000005920C4: CC1A4004 1C124905
	v_dot2_f32_bf16 v4, v6, v37, v4                            // 0000005920CC: CC1A4004 1C124B06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000005920D4: BF8700A1
	v_dot2_f32_bf16 v4, v7, v38, v4                            // 0000005920D8: CC1A4004 1C124D07
	s_waitcnt vmcnt(0)                                         // 0000005920E0: BF8903F7
	v_dot2_f32_bf16 v4, v27, v39, v4                           // 0000005920E4: CC1A4004 1C124F1B
	.long 0xd700001b                                           // 0000005920EC: D700001B
	v_cndmask_b32_e32 v0, v31, v14, vcc_lo                     // 0000005920F0: 02001D1F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000005920F4: BF870122
	v_dot2_f32_bf16 v4, v28, v40, v4                           // 0000005920F8: CC1A4004 1C12511C
	v_add_co_ci_u32_e64 v28, null, s15, v32, s0                // 000000592100: D5207C1C 0002400F
	v_dot2_f32_bf16 v4, v29, v41, v4                           // 000000592108: CC1A4004 1C12531D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000592110: BF870091
	v_dot2_f32_bf16 v4, v30, v42, v4                           // 000000592114: CC1A4004 1C12551E
	v_add_f32_e32 v17, v17, v4                                 // 00000059211C: 06220911
	s_clause 0x1                                               // 000000592120: BF850001
	global_load_b128 v[4:7], v[27:28], off                     // 000000592124: DC5E0000 047C001B
	global_load_b128 v[27:30], v[27:28], off offset:16         // 00000059212C: DC5E0010 1B7C001B
	s_waitcnt vmcnt(1)                                         // 000000592134: BF8907F7
	v_dot2_f32_bf16 v4, v4, v35, 0                             // 000000592138: CC1A4004 1A024704
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000592140: BF870091
	v_dot2_f32_bf16 v4, v5, v36, v4                            // 000000592144: CC1A4004 1C124905
	v_dot2_f32_bf16 v4, v6, v37, v4                            // 00000059214C: CC1A4004 1C124B06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000592154: BF8700A1
	v_dot2_f32_bf16 v4, v7, v38, v4                            // 000000592158: CC1A4004 1C124D07
	s_waitcnt vmcnt(0)                                         // 000000592160: BF8903F7
	v_dot2_f32_bf16 v4, v27, v39, v4                           // 000000592164: CC1A4004 1C124F1B
	.long 0xd700001b                                           // 00000059216C: D700001B
	v_cndmask_b32_e32 v0, v33, v14, vcc_lo                     // 000000592170: 02001D21
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000592174: BF8701B2
	v_dot2_f32_bf16 v4, v28, v40, v4                           // 000000592178: CC1A4004 1C12511C
	v_add_co_ci_u32_e64 v28, null, s15, v34, s0                // 000000592180: D5207C1C 0002440F
	.long 0xd700000d                                           // 000000592188: D700000D
	v_cndmask_b32_e32 v0, v13, v160, vcc_lo                    // 00000059218C: 0201410D
	v_dot2_f32_bf16 v4, v29, v41, v4                           // 000000592190: CC1A4004 1C12531D
	v_add_co_ci_u32_e64 v14, null, 0, v14, s0                  // 000000592198: D5207C0E 00021C80
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005921A0: BF870092
	v_dot2_f32_bf16 v4, v30, v42, v4                           // 0000005921A4: CC1A4004 1C12551E
	v_add_f32_e32 v19, v19, v4                                 // 0000005921AC: 06260913
	s_clause 0x1                                               // 0000005921B0: BF850001
	global_load_b128 v[4:7], v[27:28], off                     // 0000005921B4: DC5E0000 047C001B
	global_load_b128 v[27:30], v[27:28], off offset:16         // 0000005921BC: DC5E0010 1B7C001B
	s_waitcnt vmcnt(1)                                         // 0000005921C4: BF8907F7
	v_dot2_f32_bf16 v4, v4, v35, 0                             // 0000005921C8: CC1A4004 1A024704
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000005921D0: BF870121
	v_dot2_f32_bf16 v4, v5, v36, v4                            // 0000005921D4: CC1A4004 1C124905
	v_mov_b32_e32 v5, v1                                       // 0000005921DC: 7E0A0301
	v_dot2_f32_bf16 v4, v6, v37, v4                            // 0000005921E0: CC1A4004 1C124B06
	v_mov_b32_e32 v6, v2                                       // 0000005921E8: 7E0C0302
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000005921EC: BF870132
	v_dot2_f32_bf16 v4, v7, v38, v4                            // 0000005921F0: CC1A4004 1C124D07
	v_mov_b32_e32 v7, v3                                       // 0000005921F8: 7E0E0303
	s_waitcnt vmcnt(0)                                         // 0000005921FC: BF8903F7
	v_dot2_f32_bf16 v4, v27, v39, v4                           // 000000592200: CC1A4004 1C124F1B
	.long 0x7e363908                                           // 000000592208: 7E363908
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000059220C: BF870092
	v_dot2_f32_bf16 v4, v28, v40, v4                           // 000000592210: CC1A4004 1C12511C
	v_dot2_f32_bf16 v4, v29, v41, v4                           // 000000592218: CC1A4004 1C12531D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000592220: BF870091
	v_dot2_f32_bf16 v4, v30, v42, v4                           // 000000592224: CC1A4004 1C12551E
	v_add_f32_e32 v16, v16, v4                                 // 00000059222C: 06200910
	v_mov_b32_e32 v4, v0                                       // 000000592230: 7E080300
	s_and_not1_b32 exec_lo, exec_lo, s17                       // 000000592234: 917E117E
	s_cbranch_execz 29                                         // 000000592238: BFA5001D <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi7ELi32ELi1ELb0EEEvPKhPKtPvll+0x9b0>
	v_add_nc_u32_e32 v25, 32, v25                              // 00000059223C: 4A3232A0
	v_add_nc_u32_e32 v26, 0x200, v11                           // 000000592240: 4A3416FF 00000200
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000592248: BF8704A2
	.long 0xd4430000                                           // 00000059224C: D4430000
	v_cndmask_b32_e32 v1, s2, v25, vcc_lo                      // 000000592250: 02023202
	s_and_saveexec_b32 s1, s0                                  // 000000592254: BE812000
	s_xor_b32 s1, exec_lo, s1                                  // 000000592258: 8D01017E
	v_add_nc_u32_e32 v26, 0x200, v11                           // 00000059225C: 4A3416FF 00000200
	s_or_saveexec_b32 s10, s1                                  // 000000592264: BE8A2201
	s_waitcnt vmcnt(0)                                         // 000000592268: BF8903F7
	.long 0x7e10391b                                           // 00000059226C: 7E10391B
	v_dual_mov_b32 v0, v4 :: v_dual_mov_b32 v1, v5             // 000000592270: CA100104 00000105
	v_dual_mov_b32 v2, v6 :: v_dual_mov_b32 v3, v7             // 000000592278: CA100106 02020107
	s_xor_b32 exec_lo, exec_lo, s10                            // 000000592280: 8D7E0A7E
	s_cbranch_execz 65042                                      // 000000592284: BFA5FE12 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi7ELi32ELi1ELb0EEEvPKhPKtPvll+0x1d0>
	.long 0xd7000100                                           // 000000592288: D7000100
	v_cndmask_b32_e32 v1, v18, v26, vcc_lo                     // 00000059228C: 02023512
	s_delay_alu instid0(VALU_DEP_1)                            // 000000592290: BF870001
	v_add_co_ci_u32_e64 v1, null, 0, v20, s1                   // 000000592294: D5207C01 00062880
	global_load_b128 v[0:3], v[0:1], off                       // 00000059229C: DC5E0000 007C0000
	global_load_d16_b16 v8, v[13:14], off                      // 0000005922A4: DC820000 087C000D
	s_branch 65032                                             // 0000005922AC: BFA0FE08 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi7ELi32ELi1ELb0EEEvPKhPKtPvll+0x1d0>
	s_or_b32 exec_lo, exec_lo, s17                             // 0000005922B0: 8C7E117E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000005922B4: BF8700A9
	s_or_b32 exec_lo, exec_lo, s3                              // 0000005922B8: 8C7E037E
	.long 0xd71f0000                                           // 0000005922BC: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000005922C0: 020100C1
	v_xor_b32_e32 v1, 16, v0                                   // 0000005922C4: 3A020090
	v_xor_b32_e32 v8, 8, v0                                    // 0000005922C8: 3A100088
	v_xor_b32_e32 v18, 4, v0                                   // 0000005922CC: 3A240084
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005922D0: BF870093
	.long 0xd44c0000                                           // 0000005922D4: D44C0000
	v_cndmask_b32_e32 v1, 32, v1, vcc_lo                       // 0000005922D8: 020202A0
	v_cndmask_b32_e64 v1, v0, v1, s0                           // 0000005922DC: D5010001 00020300
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000005922E4: BF870114
	.long 0xd44c0000                                           // 0000005922E8: D44C0000
	v_cndmask_b32_e32 v1, 32, v8, vcc_lo                       // 0000005922EC: 020210A0
	v_lshlrev_b32_e32 v1, 2, v1                                // 0000005922F0: 30020282
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000005922F4: BF8700C2
	v_cndmask_b32_e64 v8, v0, v8, s0                           // 0000005922F8: D5010008 00021100
	.long 0xd44c0000                                           // 000000592300: D44C0000
	v_cndmask_b32_e32 v1, 32, v18, vcc_lo                      // 000000592304: 020224A0
	ds_bpermute_b32 v2, v1, v16                                // 000000592308: DACC0000 02001001
	v_cndmask_b32_e64 v18, v0, v18, s0                         // 000000592310: D5010012 00022500
	v_lshlrev_b32_e32 v18, 2, v18                              // 000000592318: 30242482
	s_waitcnt lgkmcnt(0)                                       // 00000059231C: BF89FC07
	v_add_f32_e32 v2, v16, v2                                  // 000000592320: 06040510
	s_waitcnt vmcnt(1)                                         // 000000592324: BF8907F7
	ds_bpermute_b32 v4, v1, v23                                // 000000592328: DACC0000 04001701
	ds_bpermute_b32 v3, v1, v24                                // 000000592330: DACC0000 03001801
	ds_bpermute_b32 v5, v1, v22                                // 000000592338: DACC0000 05001601
	ds_bpermute_b32 v6, v1, v21                                // 000000592340: DACC0000 06001501
	ds_bpermute_b32 v7, v1, v19                                // 000000592348: DACC0000 07001301
	ds_bpermute_b32 v1, v1, v17                                // 000000592350: DACC0000 01001101
	v_lshlrev_b32_e32 v8, 2, v8                                // 000000592358: 30101082
	s_waitcnt lgkmcnt(4)                                       // 00000059235C: BF89FC47
	v_dual_add_f32 v4, v23, v4 :: v_dual_add_f32 v3, v24, v3   // 000000592360: C9080917 04020718
	s_waitcnt lgkmcnt(2)                                       // 000000592368: BF89FC27
	v_dual_add_f32 v5, v22, v5 :: v_dual_add_f32 v6, v21, v6   // 00000059236C: C9080B16 05060D15
	s_waitcnt lgkmcnt(1)                                       // 000000592374: BF89FC17
	v_add_f32_e32 v7, v19, v7                                  // 000000592378: 060E0F13
	ds_bpermute_b32 v13, v8, v4                                // 00000059237C: DACC0000 0D000408
	s_waitcnt lgkmcnt(1)                                       // 000000592384: BF89FC17
	v_add_f32_e32 v1, v17, v1                                  // 000000592388: 06020311
	ds_bpermute_b32 v11, v8, v2                                // 00000059238C: DACC0000 0B000208
	ds_bpermute_b32 v12, v8, v3                                // 000000592394: DACC0000 0C000308
	ds_bpermute_b32 v14, v8, v5                                // 00000059239C: DACC0000 0E000508
	ds_bpermute_b32 v16, v8, v6                                // 0000005923A4: DACC0000 10000608
	ds_bpermute_b32 v17, v8, v7                                // 0000005923AC: DACC0000 11000708
	ds_bpermute_b32 v8, v8, v1                                 // 0000005923B4: DACC0000 08000108
	s_waitcnt lgkmcnt(6)                                       // 0000005923BC: BF89FC67
	v_add_f32_e32 v4, v4, v13                                  // 0000005923C0: 06081B04
	s_waitcnt lgkmcnt(4)                                       // 0000005923C4: BF89FC47
	v_dual_add_f32 v2, v2, v11 :: v_dual_add_f32 v3, v3, v12   // 0000005923C8: C9081702 02021903
	s_waitcnt lgkmcnt(3)                                       // 0000005923D0: BF89FC37
	v_add_f32_e32 v5, v5, v14                                  // 0000005923D4: 060A1D05
	ds_bpermute_b32 v12, v18, v4                               // 0000005923D8: DACC0000 0C000412
	s_waitcnt lgkmcnt(2)                                       // 0000005923E0: BF89FC27
	v_dual_add_f32 v6, v6, v16 :: v_dual_add_f32 v7, v7, v17   // 0000005923E4: C9082106 06062307
	s_waitcnt lgkmcnt(1)                                       // 0000005923EC: BF89FC17
	v_add_f32_e32 v1, v1, v8                                   // 0000005923F0: 06021101
	ds_bpermute_b32 v8, v18, v2                                // 0000005923F4: DACC0000 08000212
	ds_bpermute_b32 v11, v18, v3                               // 0000005923FC: DACC0000 0B000312
	ds_bpermute_b32 v13, v18, v5                               // 000000592404: DACC0000 0D000512
	ds_bpermute_b32 v14, v18, v6                               // 00000059240C: DACC0000 0E000612
	ds_bpermute_b32 v16, v18, v7                               // 000000592414: DACC0000 10000712
	ds_bpermute_b32 v17, v18, v1                               // 00000059241C: DACC0000 11000112
	v_xor_b32_e32 v18, 2, v0                                   // 000000592424: 3A240082
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000592428: BF870091
	.long 0xd44c0000                                           // 00000059242C: D44C0000
	v_cndmask_b32_e32 v1, 32, v18, vcc_lo                      // 000000592430: 020224A0
	v_cndmask_b32_e64 v18, v0, v18, s0                         // 000000592434: D5010012 00022500
	s_waitcnt lgkmcnt(6)                                       // 00000059243C: BF89FC67
	v_add_f32_e32 v4, v4, v12                                  // 000000592440: 06081904
	v_xor_b32_e32 v12, 1, v0                                   // 000000592444: 3A180081
	s_waitcnt lgkmcnt(4)                                       // 000000592448: BF89FC47
	v_dual_add_f32 v2, v2, v8 :: v_dual_add_f32 v3, v3, v11    // 00000059244C: C9081102 02021703
	v_lshlrev_b32_e32 v18, 2, v18                              // 000000592454: 30242482
	s_delay_alu instid0(VALU_DEP_3)                            // 000000592458: BF870003
	.long 0xd44c0000                                           // 00000059245C: D44C0000
	v_cndmask_b32_e32 v1, 32, v12, vcc_lo                      // 000000592460: 020218A0
	s_waitcnt lgkmcnt(2)                                       // 000000592464: BF89FC27
	v_dual_add_f32 v5, v5, v13 :: v_dual_add_f32 v6, v6, v14   // 000000592468: C9081B05 05061D06
	s_waitcnt lgkmcnt(1)                                       // 000000592470: BF89FC17
	v_add_f32_e32 v7, v7, v16                                  // 000000592474: 060E2107
	ds_bpermute_b32 v8, v18, v3                                // 000000592478: DACC0000 08000312
	v_cndmask_b32_e64 v0, v0, v12, s0                          // 000000592480: D5010000 00021900
	s_waitcnt lgkmcnt(1)                                       // 000000592488: BF89FC17
	v_add_f32_e32 v1, v1, v17                                  // 00000059248C: 06022301
	ds_bpermute_b32 v11, v18, v4                               // 000000592490: DACC0000 0B000412
	ds_bpermute_b32 v14, v18, v5                               // 000000592498: DACC0000 0E000512
	ds_bpermute_b32 v16, v18, v6                               // 0000005924A0: DACC0000 10000612
	ds_bpermute_b32 v17, v18, v7                               // 0000005924A8: DACC0000 11000712
	v_lshlrev_b32_e32 v20, 2, v0                               // 0000005924B0: 30280082
	ds_bpermute_b32 v19, v18, v1                               // 0000005924B4: DACC0000 13000112
	ds_bpermute_b32 v18, v18, v2                               // 0000005924BC: DACC0000 12000212
	.long 0xd44a0000                                           // 0000005924C4: D44A0000
	v_cndmask_b32_e32 v1, 0, v15, vcc_lo                       // 0000005924C8: 02021E80
	s_and_b32 s0, s0, vcc_lo                                   // 0000005924CC: 8B006A00
	s_waitcnt lgkmcnt(5)                                       // 0000005924D0: BF89FC57
	v_dual_add_f32 v12, v3, v8 :: v_dual_add_f32 v13, v4, v11  // 0000005924D4: C9081103 0C0C1704
	s_waitcnt lgkmcnt(3)                                       // 0000005924DC: BF89FC37
	v_dual_add_f32 v4, v5, v14 :: v_dual_add_f32 v5, v6, v16   // 0000005924E0: C9081D05 04042106
	s_waitcnt lgkmcnt(2)                                       // 0000005924E8: BF89FC27
	v_add_f32_e32 v0, v7, v17                                  // 0000005924EC: 06002307
	ds_bpermute_b32 v16, v20, v12                              // 0000005924F0: DACC0000 10000C14
	s_waitcnt lgkmcnt(1)                                       // 0000005924F8: BF89FC17
	v_dual_add_f32 v1, v1, v19 :: v_dual_add_f32 v8, v2, v18   // 0000005924FC: C9082701 01082502
	ds_bpermute_b32 v14, v20, v13                              // 000000592504: DACC0000 0E000D14
	ds_bpermute_b32 v6, v20, v5                                // 00000059250C: DACC0000 06000514
	ds_bpermute_b32 v7, v20, v4                                // 000000592514: DACC0000 07000414
	ds_bpermute_b32 v2, v20, v1                                // 00000059251C: DACC0000 02000114
	ds_bpermute_b32 v3, v20, v0                                // 000000592524: DACC0000 03000014
	ds_bpermute_b32 v11, v20, v8                               // 00000059252C: DACC0000 0B000814
	s_and_saveexec_b32 s1, s0                                  // 000000592534: BE812000
	s_cbranch_execz 102                                        // 000000592538: BFA50066 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi7ELi32ELi1ELb0EEEvPKhPKtPvll+0xdd4>
	s_waitcnt lgkmcnt(5)                                       // 00000059253C: BF89FC57
	v_dual_add_f32 v12, v12, v16 :: v_dual_add_f32 v13, v13, v14// 000000592540: C908210C 0C0C1D0D
	.long 0x7f1c3880                                           // 000000592548: 7F1C3880
	.long 0xd73c0009                                           // 00000059254C: D73C0009
	v_cndmask_b32_e32 v1, 1, v9, vcc_lo                        // 000000592550: 02021281
	s_lshl_b64 s[0:1], s[12:13], 1                             // 000000592554: 8480810C
	s_delay_alu instid0(VALU_DEP_3)                            // 000000592558: BF870003
	.long 0x7e1c398c                                           // 00000059255C: 7E1C398C
	.long 0x7e1e398d                                           // 000000592560: 7E1E398D
	.long 0x7f1e398e                                           // 000000592564: 7F1E398E
	s_waitcnt lgkmcnt(0)                                       // 000000592568: BF89FC07
	v_add_f32_e32 v8, v8, v11                                  // 00000059256C: 06101708
	.long 0xd7006a09                                           // 000000592570: D7006A09
	v_cndmask_b32_e32 v1, s8, v9, vcc_lo                       // 000000592574: 02021208
	v_dual_add_f32 v7, v4, v7 :: v_dual_and_b32 v16, 1, v14    // 000000592578: C9240F04 07101C81
	v_dual_add_f32 v6, v5, v6 :: v_dual_and_b32 v15, 1, v15    // 000000592580: C9240D05 060E1E81
	v_add_co_ci_u32_e64 v10, null, s9, v10, vcc_lo             // 000000592588: D5207C0A 01AA1409
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000592590: BF870223
	v_add3_u32 v16, v12, v16, 0x7fff                           // 000000592594: D6550010 03FE210C 00007FFF
	.long 0xd7006a0c                                           // 0000005925A0: D7006A0C
	v_cndmask_b32_e32 v0, v9, v0, vcc_lo                       // 0000005925A4: 02000109
	v_add3_u32 v15, v13, v15, 0x7fff                           // 0000005925A8: D655000F 03FE1F0D 00007FFF
	s_delay_alu instid0(VALU_DEP_4)                            // 0000005925B4: BF870004
	v_add_co_ci_u32_e64 v13, null, s1, v10, vcc_lo             // 0000005925B8: D5207C0D 01AA1401
	s_clause 0x1                                               // 0000005925C0: BF850001
	global_store_d16_hi_b16 v[9:10], v15, off                  // 0000005925C4: DC960000 007C0F09
	global_store_d16_hi_b16 v[12:13], v16, off                 // 0000005925CC: DC960000 007C100C
	.long 0x7e1c3987                                           // 0000005925D4: 7E1C3987
	v_add_f32_e32 v13, v1, v2                                  // 0000005925D8: 061A0501
	s_lshl_b64 s[0:1], s[12:13], 2                             // 0000005925DC: 8480820C
	.long 0x7e163986                                           // 0000005925E0: 7E163986
	.long 0xd7006a04                                           // 0000005925E4: D7006A04
	v_cndmask_b32_e32 v0, v9, v0, vcc_lo                       // 0000005925E8: 02000109
	.long 0x7f16398e                                           // 0000005925EC: 7F16398E
	v_add_f32_e32 v12, v0, v3                                  // 0000005925F0: 06180700
	v_mad_u64_u32 v[0:1], null, s12, 6, v[9:10]                // 0000005925F4: D6FE7C00 04250C0C
	v_and_b32_e32 v2, 1, v14                                   // 0000005925FC: 36041C81
	.long 0x7e12398d                                           // 000000592600: 7E12398D
	.long 0x7f12398e                                           // 000000592604: 7F12398E
	v_add_co_ci_u32_e64 v5, null, s1, v10, vcc_lo              // 000000592608: D5207C05 01AA1401
	v_and_b32_e32 v3, 1, v11                                   // 000000592610: 36061681
	v_add3_u32 v10, v7, v2, 0x7fff                             // 000000592614: D655000A 03FE0507 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 000000592620: BF870254
	v_and_b32_e32 v7, 1, v9                                    // 000000592624: 360E1281
	.long 0x7e1c398c                                           // 000000592628: 7E1C398C
	v_mad_u64_u32 v[1:2], null, s13, 6, v[1:2]                 // 00000059262C: D6FE7C01 04050C0D
	v_add3_u32 v11, v6, v3, 0x7fff                             // 000000592634: D655000B 03FE0706 00007FFF
	.long 0xd7006a02                                           // 000000592640: D7006A02
	v_cndmask_b32_e32 v0, v4, v0, vcc_lo                       // 000000592644: 02000104
	v_and_b32_e32 v6, 1, v14                                   // 000000592648: 360C1C81
	v_bfe_u32 v9, v8, 16, 1                                    // 00000059264C: D6100009 02052108
	v_add_co_ci_u32_e64 v3, null, s1, v5, vcc_lo               // 000000592654: D5207C03 01AA0A01
	v_add3_u32 v13, v13, v7, 0x7fff                            // 00000059265C: D655000D 03FE0F0D 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000592668: BF8700A4
	v_add3_u32 v12, v12, v6, 0x7fff                            // 00000059266C: D655000C 03FE0D0C 00007FFF
	.long 0xd7006a06                                           // 000000592678: D7006A06
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 00000059267C: 02000100
	v_add_co_ci_u32_e64 v7, null, s1, v1, vcc_lo               // 000000592680: D5207C07 01AA0201
	v_add3_u32 v14, v8, v9, 0x7fff                             // 000000592688: D655000E 03FE1308 00007FFF
	.long 0xd7006a08                                           // 000000592694: D7006A08
	v_cndmask_b32_e32 v0, v2, v0, vcc_lo                       // 000000592698: 02000102
	s_delay_alu instid0(VALU_DEP_1)                            // 00000059269C: BF870001
	v_add_co_ci_u32_e64 v9, null, s1, v3, vcc_lo               // 0000005926A0: D5207C09 01AA0601
	s_clause 0x4                                               // 0000005926A8: BF850004
	global_store_d16_hi_b16 v[4:5], v11, off                   // 0000005926AC: DC960000 007C0B04
	global_store_d16_hi_b16 v[0:1], v10, off                   // 0000005926B4: DC960000 007C0A00
	global_store_d16_hi_b16 v[2:3], v13, off                   // 0000005926BC: DC960000 007C0D02
	global_store_d16_hi_b16 v[6:7], v12, off                   // 0000005926C4: DC960000 007C0C06
	global_store_d16_hi_b16 v[8:9], v14, off                   // 0000005926CC: DC960000 007C0E08
	s_endpgm                                                   // 0000005926D4: BFB00000
		...

