00000000008c9000 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi8ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi8ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 0000008C9000: F4100100 F8000000
	v_dual_mov_b32 v28, 0 :: v_dual_and_b32 v1, 15, v0         // 0000008C9008: CA240080 1C00008F
	v_lshrrev_b32_e32 v2, 2, v0                                // 0000008C9010: 32040082
	s_ashr_i32 s3, s2, 31                                      // 0000008C9014: 86039F02
	v_mov_b32_e32 v5, 0                                        // 0000008C9018: 7E0A0280
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008C901C: BF870193
	v_dual_mov_b32 v6, 0 :: v_dual_lshlrev_b32 v1, 2, v1       // 0000008C9020: CA220080 06000282
	v_and_b32_e32 v2, 60, v2                                   // 0000008C9028: 360404BC
	v_lshrrev_b32_e32 v15, 5, v0                               // 0000008C902C: 321E0085
	.long 0x7f263880                                           // 0000008C9030: 7F263880
	v_dual_mov_b32 v17, 0 :: v_dual_mov_b32 v8, 0              // 0000008C9034: CA100080 11080080
	v_dual_mov_b32 v7, 0 :: v_dual_lshlrev_b32 v14, 2, v0      // 0000008C903C: CA220080 070E0082
	s_waitcnt lgkmcnt(0)                                       // 0000008C9044: BF89FC07
	s_clause 0x1                                               // 0000008C9048: BF850001
	global_load_b32 v11, v1, s[4:5]                            // 0000008C904C: DC520000 0B040001
	global_load_b32 v13, v2, s[4:5]                            // 0000008C9054: DC520000 0D040002
	.long 0xd4510014                                           // 0000008C905C: D4510014
	v_cndmask_b32_e32 v0, s2, v12, vcc_lo                      // 0000008C9060: 02001802
	s_and_b32 s20, s20, exec_lo                                // 0000008C9064: 8B147E14
	s_cselect_b32 s24, s3, 0                                   // 0000008C9068: 98188003
	s_cselect_b32 s25, s2, 0                                   // 0000008C906C: 98198002
	s_add_u32 s14, s4, s14                                     // 0000008C9070: 800E0E04
	s_addc_u32 s15, s5, s15                                    // 0000008C9074: 820F0F05
	s_lshr_b32 s20, s11, 31                                    // 0000008C9078: 85149F0B
	v_dual_mov_b32 v1, s14 :: v_dual_and_b32 v16, 31, v0       // 0000008C907C: CA24000E 0110009F
	s_add_u32 s20, s10, s20                                    // 0000008C9084: 8014140A
	s_addc_u32 s21, s11, 0                                     // 0000008C9088: 8215800B
	s_ashr_i32 s22, s11, 31                                    // 0000008C908C: 86169F0B
	s_ashr_i64 s[20:21], s[20:21], 1                           // 0000008C9090: 86948114
	s_lshr_b32 s22, s22, 27                                    // 0000008C9094: 85169B16
	v_mov_b32_e32 v2, s15                                      // 0000008C9098: 7E04020F
	s_add_u32 s22, s10, s22                                    // 0000008C909C: 8016160A
	s_addc_u32 s23, s11, 0                                     // 0000008C90A0: 8217800B
	s_mul_i32 s19, s19, s25                                    // 0000008C90A4: 96131913
	s_lshr_b64 s[22:23], s[22:23], 5                           // 0000008C90A8: 85968516
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000008C90AC: BF870499
	s_add_i32 s23, s22, 7                                      // 0000008C90B0: 81178716
	s_ashr_i32 s26, s23, 31                                    // 0000008C90B4: 861A9F17
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000008C90B8: BF870499
	s_lshr_b32 s26, s26, 29                                    // 0000008C90BC: 851A9D1A
	s_add_i32 s23, s23, s26                                    // 0000008C90C0: 81171A17
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000008C90C4: BF870009
	s_ashr_i32 s14, s23, 3                                     // 0000008C90C8: 860E8317
	s_add_u32 s4, s4, s16                                      // 0000008C90CC: 80041004
	s_addc_u32 s5, s5, s17                                     // 0000008C90D0: 82051105
	v_mov_b32_e32 v3, s4                                       // 0000008C90D4: 7E060204
	.long 0xd72c0012                                           // 0000008C90D8: D72C0012
	v_cndmask_b32_e32 v1, s14, v15, vcc_lo                     // 0000008C90DC: 02021E0E
	v_mov_b32_e32 v4, s5                                       // 0000008C90E0: 7E080205
	v_mad_u64_u32 v[9:10], null, s25, s20, v[1:2]              // 0000008C90E4: D6FE7C09 04042819
	s_mul_i32 s4, s24, s20                                     // 0000008C90EC: 96041418
	s_waitcnt vmcnt(1)                                         // 0000008C90F0: BF8907F7
	v_bfe_u32 v12, v11, 16, 1                                  // 0000008C90F4: D610000C 0205210B
	s_waitcnt vmcnt(0)                                         // 0000008C90FC: BF8903F7
	v_bfe_u32 v1, v13, 16, 1                                   // 0000008C9100: D6100001 0205210D
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000008C9108: BF870232
	v_add3_u32 v2, v11, v12, 0x7fff                            // 0000008C910C: D6550002 03FE190B 00007FFF
	v_mad_u64_u32 v[11:12], null, s18, s25, v[3:4]             // 0000008C9118: D6FE7C0B 040C3212
	v_add_nc_u32_e32 v3, s14, v18                              // 0000008C9120: 4A06240E
	v_add3_u32 v1, v13, v1, 0x7fff                             // 0000008C9124: D6550001 03FE030D 00007FFF
	s_mul_i32 s25, s25, s21                                    // 0000008C9130: 96191519
	.long 0x7e263982                                           // 0000008C9134: 7E263982
	v_add_nc_u32_e32 v2, s4, v10                               // 0000008C9138: 4A041404
	v_add_nc_u32_e32 v10, v18, v16                             // 0000008C913C: 4A142112
	v_min_i32_e32 v18, s22, v3                                 // 0000008C9140: 22240616
	v_add_nc_u32_e32 v3, s19, v12                              // 0000008C9144: 4A061813
	s_mul_i32 s4, s18, s24                                     // 0000008C9148: 96041812
	v_and_or_b32 v1, 0xffff0000, v1, v19                       // 0000008C914C: D6570001 044E02FF FFFF0000
	v_add_nc_u32_e32 v19, s25, v2                              // 0000008C9158: 4A260419
	v_cmp_lt_i32_e32 vcc_lo, v10, v18                          // 0000008C915C: 7C82250A
	v_add_nc_u32_e32 v20, s4, v3                               // 0000008C9160: 4A280604
	ds_store_b32 v14, v1                                       // 0000008C9164: D8340000 0000010E
	s_waitcnt lgkmcnt(0)                                       // 0000008C916C: BF89FC07
	s_barrier                                                  // 0000008C9170: BFBD0000
	buffer_gl0_inv                                             // 0000008C9174: E0AC0000 00000000
	s_and_saveexec_b32 s5, vcc_lo                              // 0000008C917C: BE85206A
	s_cbranch_execz 21                                         // 0000008C9180: BFA50015 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi8ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f+0x1d8>
	v_lshlrev_b32_e32 v1, 1, v10                               // 0000008C9184: 30021481
	v_lshlrev_b32_e32 v3, 4, v10                               // 0000008C9188: 30061484
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000008C918C: BF870112
	v_ashrrev_i32_e32 v2, 31, v1                               // 0000008C9190: 3404029F
	v_ashrrev_i32_e32 v4, 31, v3                               // 0000008C9194: 3408069F
	.long 0xd7000401                                           // 0000008C9198: D7000401
	v_cndmask_b32_e32 v1, v11, v1, vcc_lo                      // 0000008C919C: 0202030B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008C91A0: BF8700A1
	v_add_co_ci_u32_e64 v2, null, v20, v2, s4                  // 0000008C91A4: D5207C02 00120514
	.long 0xd7000403                                           // 0000008C91AC: D7000403
	v_cndmask_b32_e32 v1, v9, v3, vcc_lo                       // 0000008C91B0: 02020709
	v_add_co_ci_u32_e64 v4, null, v19, v4, s4                  // 0000008C91B4: D5207C04 00120913
	s_clause 0x1                                               // 0000008C91BC: BF850001
	global_load_d16_b16 v1, v[1:2], off                        // 0000008C91C0: DC820000 017C0001
	global_load_b128 v[5:8], v[3:4], off                       // 0000008C91C8: DC5E0000 057C0003
	s_waitcnt vmcnt(1)                                         // 0000008C91D0: BF8907F7
	v_cvt_f32_f16_e32 v28, v1                                  // 0000008C91D4: 7E381701
	s_or_b32 exec_lo, exec_lo, s5                              // 0000008C91D8: 8C7E057E
	v_dual_mov_b32 v22, 0 :: v_dual_mov_b32 v23, 0             // 0000008C91DC: CA100080 16160080
	v_dual_mov_b32 v24, 0 :: v_dual_mov_b32 v21, 0             // 0000008C91E4: CA100080 18140080
	s_and_saveexec_b32 s5, vcc_lo                              // 0000008C91EC: BE85206A
	s_cbranch_execz 460                                        // 0000008C91F0: BFA501CC <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi8ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f+0x924>
	v_dual_mov_b32 v24, 0 :: v_dual_add_nc_u32 v1, 32, v10     // 0000008C91F4: CA200080 180014A0
	v_dual_mov_b32 v21, 0 :: v_dual_lshlrev_b32 v12, 5, v10    // 0000008C91FC: CA220080 150C1485
	v_mov_b32_e32 v17, 0                                       // 0000008C9204: 7E220280
	s_delay_alu instid0(VALU_DEP_3)                            // 0000008C9208: BF870003
	v_dual_mov_b32 v22, 0 :: v_dual_lshlrev_b32 v25, 4, v1     // 0000008C920C: CA220080 16180284
	v_dual_mov_b32 v23, 0 :: v_dual_lshlrev_b32 v26, 1, v1     // 0000008C9214: CA220080 171A0281
	v_mov_b32_e32 v27, v28                                     // 0000008C921C: 7E36031C
	s_mul_i32 s4, s11, 6                                       // 0000008C9220: 9604860B
	s_mul_hi_u32 s16, s10, 6                                   // 0000008C9224: 9690860A
	s_lshl_b64 s[14:15], s[10:11], 2                           // 0000008C9228: 848E820A
	s_add_i32 s16, s16, s4                                     // 0000008C922C: 81100410
	s_mul_i32 s18, s10, 6                                      // 0000008C9230: 9612860A
	s_mov_b32 s17, 0                                           // 0000008C9234: BE910080
	s_lshl_b64 s[10:11], s[10:11], 1                           // 0000008C9238: 848A810A
	s_branch 409                                               // 0000008C923C: BFA00199 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi8ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f+0x8a4>
	s_or_b32 exec_lo, exec_lo, s19                             // 0000008C9240: 8C7E137E
	v_and_b32_e32 v13, 0xff, v5                                // 0000008C9244: 361A0AFF 000000FF
	s_and_b32 s4, exec_lo, vcc_lo                              // 0000008C924C: 8B046A7E
	v_add_nc_u32_e32 v25, 0x200, v25                           // 0000008C9250: 4A3232FF 00000200
	s_or_b32 s17, s4, s17                                      // 0000008C9258: 8C111104
	v_add_nc_u32_e32 v26, 64, v26                              // 0000008C925C: 4A3434C0
	v_lshlrev_b32_e32 v13, 2, v13                              // 0000008C9260: 301A1A82
	ds_load_b32 v45, v13                                       // 0000008C9264: D8D80000 2D00000D
	v_lshrrev_b32_e32 v13, 6, v5                               // 0000008C926C: 321A0A86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000008C9270: BF870141
	v_and_b32_e32 v13, 0x3fc, v13                              // 0000008C9274: 361A1AFF 000003FC
	ds_load_b32 v46, v13                                       // 0000008C927C: D8D80000 2E00000D
	v_lshrrev_b32_e32 v13, 14, v5                              // 0000008C9284: 321A0A8E
	v_lshrrev_b32_e32 v5, 22, v5                               // 0000008C9288: 320A0A96
	v_and_b32_e32 v13, 0x3fc, v13                              // 0000008C928C: 361A1AFF 000003FC
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 0000008C9294: BF870152
	v_and_b32_e32 v5, 0x3fc, v5                                // 0000008C9298: 360A0AFF 000003FC
	ds_load_b32 v47, v13                                       // 0000008C92A0: D8D80000 2F00000D
	ds_load_b32 v48, v5                                        // 0000008C92A8: D8D80000 30000005
	v_and_b32_e32 v5, 0xff, v6                                 // 0000008C92B0: 360A0CFF 000000FF
	v_ashrrev_i32_e32 v13, 31, v12                             // 0000008C92B8: 341A189F
	v_lshlrev_b32_e32 v5, 2, v5                                // 0000008C92BC: 300A0A82
	ds_load_b32 v49, v5                                        // 0000008C92C0: D8D80000 31000005
	v_lshrrev_b32_e32 v5, 6, v6                                // 0000008C92C8: 320A0C86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008C92CC: BF8700B1
	v_and_b32_e32 v5, 0x3fc, v5                                // 0000008C92D0: 360A0AFF 000003FC
	ds_load_b32 v50, v5                                        // 0000008C92D8: D8D80000 32000005
	v_lshrrev_b32_e32 v5, 14, v6                               // 0000008C92E0: 320A0C8E
	v_and_b32_e32 v5, 0x3fc, v5                                // 0000008C92E4: 360A0AFF 000003FC
	ds_load_b32 v51, v5                                        // 0000008C92EC: D8D80000 33000005
	v_lshrrev_b32_e32 v5, 22, v6                               // 0000008C92F4: 320A0C96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008C92F8: BF8700B1
	v_and_b32_e32 v5, 0x3fc, v5                                // 0000008C92FC: 360A0AFF 000003FC
	ds_load_b32 v52, v5                                        // 0000008C9304: D8D80000 34000005
	v_and_b32_e32 v5, 0xff, v7                                 // 0000008C930C: 360A0EFF 000000FF
	v_lshlrev_b32_e32 v5, 2, v5                                // 0000008C9314: 300A0A82
	ds_load_b32 v53, v5                                        // 0000008C9318: D8D80000 35000005
	v_lshrrev_b32_e32 v5, 6, v7                                // 0000008C9320: 320A0E86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008C9324: BF8700B1
	v_and_b32_e32 v5, 0x3fc, v5                                // 0000008C9328: 360A0AFF 000003FC
	ds_load_b32 v54, v5                                        // 0000008C9330: D8D80000 36000005
	v_lshrrev_b32_e32 v5, 14, v7                               // 0000008C9338: 320A0E8E
	v_and_b32_e32 v5, 0x3fc, v5                                // 0000008C933C: 360A0AFF 000003FC
	ds_load_b32 v55, v5                                        // 0000008C9344: D8D80000 37000005
	v_lshrrev_b32_e32 v5, 22, v7                               // 0000008C934C: 320A0E96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008C9350: BF8700B1
	v_and_b32_e32 v5, 0x3fc, v5                                // 0000008C9354: 360A0AFF 000003FC
	ds_load_b32 v56, v5                                        // 0000008C935C: D8D80000 38000005
	v_and_b32_e32 v5, 0xff, v8                                 // 0000008C9364: 360A10FF 000000FF
	v_lshlrev_b32_e32 v5, 2, v5                                // 0000008C936C: 300A0A82
	ds_load_b32 v57, v5                                        // 0000008C9370: D8D80000 39000005
	v_lshrrev_b32_e32 v5, 6, v8                                // 0000008C9378: 320A1086
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008C937C: BF8700B1
	v_and_b32_e32 v5, 0x3fc, v5                                // 0000008C9380: 360A0AFF 000003FC
	ds_load_b32 v58, v5                                        // 0000008C9388: D8D80000 3A000005
	v_lshrrev_b32_e32 v5, 14, v8                               // 0000008C9390: 320A108E
	v_and_b32_e32 v5, 0x3fc, v5                                // 0000008C9394: 360A0AFF 000003FC
	ds_load_b32 v59, v5                                        // 0000008C939C: D8D80000 3B000005
	v_lshrrev_b32_e32 v5, 22, v8                               // 0000008C93A4: 320A1096
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000008C93A8: BF870141
	v_and_b32_e32 v5, 0x3fc, v5                                // 0000008C93AC: 360A0AFF 000003FC
	ds_load_b32 v60, v5                                        // 0000008C93B4: D8D80000 3C000005
	.long 0xd73c0005                                           // 0000008C93BC: D73C0005
	v_cndmask_b32_e32 v1, 1, v12, vcc_lo                       // 0000008C93C0: 02021881
	v_add_nc_u32_e32 v12, 0x400, v12                           // 0000008C93C4: 4A1818FF 00000400
	.long 0xd7006a29                                           // 0000008C93CC: D7006A29
	v_cndmask_b32_e32 v1, s6, v5, vcc_lo                       // 0000008C93D0: 02020A06
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008C93D4: BF870001
	v_add_co_ci_u32_e64 v42, null, s7, v6, vcc_lo              // 0000008C93D8: D5207C2A 01AA0C07
	s_clause 0x3                                               // 0000008C93E0: BF850003
	global_load_b128 v[5:8], v[41:42], off                     // 0000008C93E4: DC5E0000 057C0029
	global_load_b128 v[29:32], v[41:42], off offset:16         // 0000008C93EC: DC5E0010 1D7C0029
	global_load_b128 v[33:36], v[41:42], off offset:32         // 0000008C93F4: DC5E0020 217C0029
	global_load_b128 v[37:40], v[41:42], off offset:48         // 0000008C93FC: DC5E0030 257C0029
	s_waitcnt vmcnt(3) lgkmcnt(15)                             // 0000008C9404: BF890CF7
	v_dot2_f32_bf16 v5, v5, v45, 0                             // 0000008C9408: CC1A4005 1A025B05
	s_waitcnt lgkmcnt(14)                                      // 0000008C9410: BF89FCE7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008C9414: BF8700A1
	v_dot2_f32_bf16 v5, v6, v46, v5                            // 0000008C9418: CC1A4005 1C165D06
	s_waitcnt lgkmcnt(13)                                      // 0000008C9420: BF89FCD7
	v_dot2_f32_bf16 v5, v7, v47, v5                            // 0000008C9424: CC1A4005 1C165F07
	s_waitcnt lgkmcnt(12)                                      // 0000008C942C: BF89FCC7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008C9430: BF8700A1
	v_dot2_f32_bf16 v5, v8, v48, v5                            // 0000008C9434: CC1A4005 1C166108
	s_waitcnt vmcnt(2) lgkmcnt(11)                             // 0000008C943C: BF8908B7
	v_dot2_f32_bf16 v5, v29, v49, v5                           // 0000008C9440: CC1A4005 1C16631D
	s_waitcnt lgkmcnt(10)                                      // 0000008C9448: BF89FCA7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008C944C: BF8700A1
	v_dot2_f32_bf16 v5, v30, v50, v5                           // 0000008C9450: CC1A4005 1C16651E
	s_waitcnt lgkmcnt(9)                                       // 0000008C9458: BF89FC97
	v_dot2_f32_bf16 v5, v31, v51, v5                           // 0000008C945C: CC1A4005 1C16671F
	s_waitcnt lgkmcnt(8)                                       // 0000008C9464: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008C9468: BF8700A1
	v_dot2_f32_bf16 v5, v32, v52, v5                           // 0000008C946C: CC1A4005 1C166920
	s_waitcnt vmcnt(1) lgkmcnt(7)                              // 0000008C9474: BF890477
	v_dot2_f32_bf16 v5, v33, v53, v5                           // 0000008C9478: CC1A4005 1C166B21
	s_waitcnt lgkmcnt(6)                                       // 0000008C9480: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008C9484: BF8700A1
	v_dot2_f32_bf16 v5, v34, v54, v5                           // 0000008C9488: CC1A4005 1C166D22
	s_waitcnt lgkmcnt(5)                                       // 0000008C9490: BF89FC57
	v_dot2_f32_bf16 v5, v35, v55, v5                           // 0000008C9494: CC1A4005 1C166F23
	s_waitcnt lgkmcnt(4)                                       // 0000008C949C: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008C94A0: BF8700A1
	v_dot2_f32_bf16 v5, v36, v56, v5                           // 0000008C94A4: CC1A4005 1C167124
	s_waitcnt vmcnt(0) lgkmcnt(3)                              // 0000008C94AC: BF890037
	v_dot2_f32_bf16 v5, v37, v57, v5                           // 0000008C94B0: CC1A4005 1C167325
	.long 0xd7006a25                                           // 0000008C94B8: D7006A25
	v_cndmask_b32_e32 v0, v41, v10, vcc_lo                     // 0000008C94BC: 02001529
	s_waitcnt lgkmcnt(2)                                       // 0000008C94C0: BF89FC27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000008C94C4: BF8701C2
	v_dot2_f32_bf16 v5, v38, v58, v5                           // 0000008C94C8: CC1A4005 1C167526
	v_add_co_ci_u32_e64 v38, null, s11, v42, vcc_lo            // 0000008C94D0: D5207C26 01AA540B
	.long 0xd7006a2b                                           // 0000008C94D8: D7006A2B
	v_cndmask_b32_e32 v0, v41, v14, vcc_lo                     // 0000008C94DC: 02001D29
	s_waitcnt lgkmcnt(1)                                       // 0000008C94E0: BF89FC17
	v_dot2_f32_bf16 v5, v39, v59, v5                           // 0000008C94E4: CC1A4005 1C167727
	v_add_co_ci_u32_e64 v44, null, s15, v42, vcc_lo            // 0000008C94EC: D5207C2C 01AA540F
	s_waitcnt lgkmcnt(0)                                       // 0000008C94F4: BF89FC07
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C94F8: BF870092
	v_dot2_f32_bf16 v5, v40, v60, v5                           // 0000008C94FC: CC1A4005 1C167928
	v_fmac_f32_e32 v21, v28, v5                                // 0000008C9504: 562A0B1C
	s_clause 0x3                                               // 0000008C9508: BF850003
	global_load_b128 v[5:8], v[37:38], off                     // 0000008C950C: DC5E0000 057C0025
	global_load_b128 v[29:32], v[37:38], off offset:16         // 0000008C9514: DC5E0010 1D7C0025
	global_load_b128 v[33:36], v[37:38], off offset:32         // 0000008C951C: DC5E0020 217C0025
	global_load_b128 v[37:40], v[37:38], off offset:48         // 0000008C9524: DC5E0030 257C0025
	s_waitcnt vmcnt(3)                                         // 0000008C952C: BF890FF7
	v_dot2_f32_bf16 v5, v5, v45, 0                             // 0000008C9530: CC1A4005 1A025B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C9538: BF870091
	v_dot2_f32_bf16 v5, v6, v46, v5                            // 0000008C953C: CC1A4005 1C165D06
	v_dot2_f32_bf16 v5, v7, v47, v5                            // 0000008C9544: CC1A4005 1C165F07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008C954C: BF8700A1
	v_dot2_f32_bf16 v5, v8, v48, v5                            // 0000008C9550: CC1A4005 1C166108
	s_waitcnt vmcnt(2)                                         // 0000008C9558: BF890BF7
	v_dot2_f32_bf16 v5, v29, v49, v5                           // 0000008C955C: CC1A4005 1C16631D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C9564: BF870091
	v_dot2_f32_bf16 v5, v30, v50, v5                           // 0000008C9568: CC1A4005 1C16651E
	v_dot2_f32_bf16 v5, v31, v51, v5                           // 0000008C9570: CC1A4005 1C16671F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008C9578: BF8700A1
	v_dot2_f32_bf16 v5, v32, v52, v5                           // 0000008C957C: CC1A4005 1C166920
	s_waitcnt vmcnt(1)                                         // 0000008C9584: BF8907F7
	v_dot2_f32_bf16 v5, v33, v53, v5                           // 0000008C9588: CC1A4005 1C166B21
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C9590: BF870091
	v_dot2_f32_bf16 v5, v34, v54, v5                           // 0000008C9594: CC1A4005 1C166D22
	v_dot2_f32_bf16 v5, v35, v55, v5                           // 0000008C959C: CC1A4005 1C166F23
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008C95A4: BF8700A1
	v_dot2_f32_bf16 v5, v36, v56, v5                           // 0000008C95A8: CC1A4005 1C167124
	s_waitcnt vmcnt(0)                                         // 0000008C95B0: BF8903F7
	v_dot2_f32_bf16 v5, v37, v57, v5                           // 0000008C95B4: CC1A4005 1C167325
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C95BC: BF870091
	v_dot2_f32_bf16 v5, v38, v58, v5                           // 0000008C95C0: CC1A4005 1C167526
	v_dot2_f32_bf16 v5, v39, v59, v5                           // 0000008C95C8: CC1A4005 1C167727
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C95D0: BF870091
	v_dot2_f32_bf16 v5, v40, v60, v5                           // 0000008C95D4: CC1A4005 1C167928
	v_fmac_f32_e32 v24, v28, v5                                // 0000008C95DC: 56300B1C
	s_clause 0x3                                               // 0000008C95E0: BF850003
	global_load_b128 v[5:8], v[43:44], off                     // 0000008C95E4: DC5E0000 057C002B
	global_load_b128 v[29:32], v[43:44], off offset:16         // 0000008C95EC: DC5E0010 1D7C002B
	global_load_b128 v[33:36], v[43:44], off offset:32         // 0000008C95F4: DC5E0020 217C002B
	global_load_b128 v[37:40], v[43:44], off offset:48         // 0000008C95FC: DC5E0030 257C002B
	s_waitcnt vmcnt(3)                                         // 0000008C9604: BF890FF7
	v_dot2_f32_bf16 v5, v5, v45, 0                             // 0000008C9608: CC1A4005 1A025B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C9610: BF870091
	v_dot2_f32_bf16 v5, v6, v46, v5                            // 0000008C9614: CC1A4005 1C165D06
	v_dot2_f32_bf16 v5, v7, v47, v5                            // 0000008C961C: CC1A4005 1C165F07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008C9624: BF8700A1
	v_dot2_f32_bf16 v5, v8, v48, v5                            // 0000008C9628: CC1A4005 1C166108
	s_waitcnt vmcnt(2)                                         // 0000008C9630: BF890BF7
	v_dot2_f32_bf16 v5, v29, v49, v5                           // 0000008C9634: CC1A4005 1C16631D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C963C: BF870091
	v_dot2_f32_bf16 v5, v30, v50, v5                           // 0000008C9640: CC1A4005 1C16651E
	v_dot2_f32_bf16 v5, v31, v51, v5                           // 0000008C9648: CC1A4005 1C16671F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008C9650: BF8700A1
	v_dot2_f32_bf16 v5, v32, v52, v5                           // 0000008C9654: CC1A4005 1C166920
	s_waitcnt vmcnt(1)                                         // 0000008C965C: BF8907F7
	v_dot2_f32_bf16 v5, v33, v53, v5                           // 0000008C9660: CC1A4005 1C166B21
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C9668: BF870091
	v_dot2_f32_bf16 v5, v34, v54, v5                           // 0000008C966C: CC1A4005 1C166D22
	v_dot2_f32_bf16 v5, v35, v55, v5                           // 0000008C9674: CC1A4005 1C166F23
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008C967C: BF8700A1
	v_dot2_f32_bf16 v5, v36, v56, v5                           // 0000008C9680: CC1A4005 1C167124
	s_waitcnt vmcnt(0)                                         // 0000008C9688: BF8903F7
	v_dot2_f32_bf16 v5, v37, v57, v5                           // 0000008C968C: CC1A4005 1C167325
	.long 0xd7006a25                                           // 0000008C9694: D7006A25
	v_cndmask_b32_e32 v0, v41, v18, vcc_lo                     // 0000008C9698: 02002529
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000008C969C: BF870122
	v_dot2_f32_bf16 v5, v38, v58, v5                           // 0000008C96A0: CC1A4005 1C167526
	v_add_co_ci_u32_e64 v38, null, s16, v42, vcc_lo            // 0000008C96A8: D5207C26 01AA5410
	v_dot2_f32_bf16 v5, v39, v59, v5                           // 0000008C96B0: CC1A4005 1C167727
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C96B8: BF870091
	v_dot2_f32_bf16 v5, v40, v60, v5                           // 0000008C96BC: CC1A4005 1C167928
	v_fmac_f32_e32 v23, v28, v5                                // 0000008C96C4: 562E0B1C
	s_clause 0x3                                               // 0000008C96C8: BF850003
	global_load_b128 v[5:8], v[37:38], off                     // 0000008C96CC: DC5E0000 057C0025
	global_load_b128 v[29:32], v[37:38], off offset:16         // 0000008C96D4: DC5E0010 1D7C0025
	global_load_b128 v[33:36], v[37:38], off offset:32         // 0000008C96DC: DC5E0020 217C0025
	global_load_b128 v[37:40], v[37:38], off offset:48         // 0000008C96E4: DC5E0030 257C0025
	s_waitcnt vmcnt(3)                                         // 0000008C96EC: BF890FF7
	v_dot2_f32_bf16 v5, v5, v45, 0                             // 0000008C96F0: CC1A4005 1A025B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C96F8: BF870091
	v_dot2_f32_bf16 v5, v6, v46, v5                            // 0000008C96FC: CC1A4005 1C165D06
	v_dot2_f32_bf16 v5, v7, v47, v5                            // 0000008C9704: CC1A4005 1C165F07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008C970C: BF8700A1
	v_dot2_f32_bf16 v5, v8, v48, v5                            // 0000008C9710: CC1A4005 1C166108
	s_waitcnt vmcnt(2)                                         // 0000008C9718: BF890BF7
	v_dot2_f32_bf16 v5, v29, v49, v5                           // 0000008C971C: CC1A4005 1C16631D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C9724: BF870091
	v_dot2_f32_bf16 v5, v30, v50, v5                           // 0000008C9728: CC1A4005 1C16651E
	v_dot2_f32_bf16 v5, v31, v51, v5                           // 0000008C9730: CC1A4005 1C16671F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008C9738: BF8700A1
	v_dot2_f32_bf16 v5, v32, v52, v5                           // 0000008C973C: CC1A4005 1C166920
	s_waitcnt vmcnt(1)                                         // 0000008C9744: BF8907F7
	v_dot2_f32_bf16 v5, v33, v53, v5                           // 0000008C9748: CC1A4005 1C166B21
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C9750: BF870091
	v_dot2_f32_bf16 v5, v34, v54, v5                           // 0000008C9754: CC1A4005 1C166D22
	v_dot2_f32_bf16 v5, v35, v55, v5                           // 0000008C975C: CC1A4005 1C166F23
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008C9764: BF8700A1
	v_dot2_f32_bf16 v5, v36, v56, v5                           // 0000008C9768: CC1A4005 1C167124
	s_waitcnt vmcnt(0)                                         // 0000008C9770: BF8903F7
	v_dot2_f32_bf16 v5, v37, v57, v5                           // 0000008C9774: CC1A4005 1C167325
	.long 0xd7006a25                                           // 0000008C977C: D7006A25
	v_cndmask_b32_e32 v0, v43, v14, vcc_lo                     // 0000008C9780: 02001D2B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000008C9784: BF870122
	v_dot2_f32_bf16 v5, v38, v58, v5                           // 0000008C9788: CC1A4005 1C167526
	v_add_co_ci_u32_e64 v38, null, s15, v44, vcc_lo            // 0000008C9790: D5207C26 01AA580F
	v_dot2_f32_bf16 v5, v39, v59, v5                           // 0000008C9798: CC1A4005 1C167727
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C97A0: BF870091
	v_dot2_f32_bf16 v5, v40, v60, v5                           // 0000008C97A4: CC1A4005 1C167928
	v_fmac_f32_e32 v22, v28, v5                                // 0000008C97AC: 562C0B1C
	s_clause 0x3                                               // 0000008C97B0: BF850003
	global_load_b128 v[5:8], v[37:38], off                     // 0000008C97B4: DC5E0000 057C0025
	global_load_b128 v[29:32], v[37:38], off offset:16         // 0000008C97BC: DC5E0010 1D7C0025
	global_load_b128 v[33:36], v[37:38], off offset:32         // 0000008C97C4: DC5E0020 217C0025
	global_load_b128 v[37:40], v[37:38], off offset:48         // 0000008C97CC: DC5E0030 257C0025
	s_waitcnt vmcnt(3)                                         // 0000008C97D4: BF890FF7
	v_dot2_f32_bf16 v5, v5, v45, 0                             // 0000008C97D8: CC1A4005 1A025B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000008C97E0: BF870121
	v_dot2_f32_bf16 v5, v6, v46, v5                            // 0000008C97E4: CC1A4005 1C165D06
	v_mov_b32_e32 v6, v2                                       // 0000008C97EC: 7E0C0302
	v_dot2_f32_bf16 v5, v7, v47, v5                            // 0000008C97F0: CC1A4005 1C165F07
	v_mov_b32_e32 v7, v3                                       // 0000008C97F8: 7E0E0303
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000008C97FC: BF870132
	v_dot2_f32_bf16 v5, v8, v48, v5                            // 0000008C9800: CC1A4005 1C166108
	v_mov_b32_e32 v8, v4                                       // 0000008C9808: 7E100304
	s_waitcnt vmcnt(2)                                         // 0000008C980C: BF890BF7
	v_dot2_f32_bf16 v5, v29, v49, v5                           // 0000008C9810: CC1A4005 1C16631D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C9818: BF870091
	v_dot2_f32_bf16 v5, v30, v50, v5                           // 0000008C981C: CC1A4005 1C16651E
	v_dot2_f32_bf16 v5, v31, v51, v5                           // 0000008C9824: CC1A4005 1C16671F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008C982C: BF8700A1
	v_dot2_f32_bf16 v5, v32, v52, v5                           // 0000008C9830: CC1A4005 1C166920
	s_waitcnt vmcnt(1)                                         // 0000008C9838: BF8907F7
	v_dot2_f32_bf16 v5, v33, v53, v5                           // 0000008C983C: CC1A4005 1C166B21
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C9844: BF870091
	v_dot2_f32_bf16 v5, v34, v54, v5                           // 0000008C9848: CC1A4005 1C166D22
	v_dot2_f32_bf16 v5, v35, v55, v5                           // 0000008C9850: CC1A4005 1C166F23
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008C9858: BF8700A1
	v_dot2_f32_bf16 v5, v36, v56, v5                           // 0000008C985C: CC1A4005 1C167124
	s_waitcnt vmcnt(0)                                         // 0000008C9864: BF8903F7
	v_dot2_f32_bf16 v5, v37, v57, v5                           // 0000008C9868: CC1A4005 1C167325
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C9870: BF870091
	v_dot2_f32_bf16 v5, v38, v58, v5                           // 0000008C9874: CC1A4005 1C167526
	v_dot2_f32_bf16 v5, v39, v59, v5                           // 0000008C987C: CC1A4005 1C167727
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C9884: BF870091
	v_dot2_f32_bf16 v5, v40, v60, v5                           // 0000008C9888: CC1A4005 1C167928
	v_fmac_f32_e32 v17, v28, v5                                // 0000008C9890: 56220B1C
	v_dual_mov_b32 v5, v1 :: v_dual_mov_b32 v28, v27           // 0000008C9894: CA100101 051C011B
	s_and_not1_b32 exec_lo, exec_lo, s17                       // 0000008C989C: 917E117E
	s_cbranch_execz 31                                         // 0000008C98A0: BFA5001F <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi8ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f+0x920>
	s_waitcnt vmcnt(0)                                         // 0000008C98A4: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000008C98A8: BF8701C1
	v_dual_mov_b32 v1, v5 :: v_dual_add_nc_u32 v10, 32, v10    // 0000008C98AC: CA200105 010A14A0
	v_dual_mov_b32 v2, v6 :: v_dual_mov_b32 v3, v7             // 0000008C98B4: CA100106 02020107
	v_mov_b32_e32 v4, v8                                       // 0000008C98BC: 7E080308
	s_mov_b32 s19, exec_lo                                     // 0000008C98C0: BE93007E
	v_cmp_ge_i32_e32 vcc_lo, v10, v18                          // 0000008C98C4: 7C8C250A
	.long 0xd4c1007e                                           // 0000008C98C8: D4C1007E
	v_cndmask_b32_e32 v1, v10, v18, vcc_lo                     // 0000008C98CC: 0202250A
	s_cbranch_execz 65115                                      // 0000008C98D0: BFA5FE5B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi8ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f+0x240>
	v_ashrrev_i32_e32 v2, 31, v26                              // 0000008C98D4: 3404349F
	v_ashrrev_i32_e32 v4, 31, v25                              // 0000008C98D8: 3408329F
	.long 0xd7000401                                           // 0000008C98DC: D7000401
	v_cndmask_b32_e32 v1, v11, v26, vcc_lo                     // 0000008C98E0: 0202350B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008C98E4: BF8700A1
	v_add_co_ci_u32_e64 v2, null, v20, v2, s4                  // 0000008C98E8: D5207C02 00120514
	.long 0xd7000403                                           // 0000008C98F0: D7000403
	v_cndmask_b32_e32 v1, v9, v25, vcc_lo                      // 0000008C98F4: 02023309
	v_add_co_ci_u32_e64 v4, null, v19, v4, s4                  // 0000008C98F8: D5207C04 00120913
	s_clause 0x1                                               // 0000008C9900: BF850001
	global_load_d16_b16 v13, v[1:2], off                       // 0000008C9904: DC820000 0D7C0001
	global_load_b128 v[1:4], v[3:4], off                       // 0000008C990C: DC5E0000 017C0003
	s_waitcnt vmcnt(1)                                         // 0000008C9914: BF8907F7
	v_cvt_f32_f16_e32 v27, v13                                 // 0000008C9918: 7E36170D
	s_branch 65096                                             // 0000008C991C: BFA0FE48 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi8ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f+0x240>
	s_or_b32 exec_lo, exec_lo, s17                             // 0000008C9920: 8C7E117E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008C9924: BF8700B9
	s_or_b32 exec_lo, exec_lo, s5                              // 0000008C9928: 8C7E057E
	.long 0xd71f0001                                           // 0000008C992C: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000008C9930: 020100C1
	s_mov_b32 s4, exec_lo                                      // 0000008C9934: BE84007E
	v_xor_b32_e32 v2, 16, v1                                   // 0000008C9938: 3A040290
	s_waitcnt vmcnt(0)                                         // 0000008C993C: BF8903F7
	v_xor_b32_e32 v7, 8, v1                                    // 0000008C9940: 3A0E0288
	v_xor_b32_e32 v12, 4, v1                                   // 0000008C9944: 3A180284
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000008C9948: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 0000008C994C: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 0000008C9950: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v7                            // 0000008C9954: 7C980EA0
	v_cndmask_b32_e32 v7, v1, v7, vcc_lo                       // 0000008C9958: 020E0F01
	v_cmp_gt_u32_e32 vcc_lo, 32, v12                           // 0000008C995C: 7C9818A0
	s_delay_alu instid0(VALU_DEP_2)                            // 0000008C9960: BF870002
	v_lshlrev_b32_e32 v7, 2, v7                                // 0000008C9964: 300E0E82
	v_lshlrev_b32_e32 v2, 2, v2                                // 0000008C9968: 30040482
	ds_bpermute_b32 v3, v2, v21                                // 0000008C996C: DACC0000 03001502
	s_waitcnt lgkmcnt(0)                                       // 0000008C9974: BF89FC07
	v_add_f32_e32 v3, v21, v3                                  // 0000008C9978: 06060715
	ds_bpermute_b32 v4, v2, v24                                // 0000008C997C: DACC0000 04001802
	ds_bpermute_b32 v5, v2, v23                                // 0000008C9984: DACC0000 05001702
	ds_bpermute_b32 v6, v2, v22                                // 0000008C998C: DACC0000 06001602
	ds_bpermute_b32 v2, v2, v17                                // 0000008C9994: DACC0000 02001102
	ds_bpermute_b32 v8, v7, v3                                 // 0000008C999C: DACC0000 08000307
	s_waitcnt lgkmcnt(3)                                       // 0000008C99A4: BF89FC37
	v_dual_add_f32 v4, v24, v4 :: v_dual_add_f32 v5, v23, v5   // 0000008C99A8: C9080918 04040B17
	s_waitcnt lgkmcnt(2)                                       // 0000008C99B0: BF89FC27
	v_add_f32_e32 v6, v22, v6                                  // 0000008C99B4: 060C0D16
	s_waitcnt lgkmcnt(0)                                       // 0000008C99B8: BF89FC07
	v_dual_add_f32 v2, v17, v2 :: v_dual_add_f32 v3, v3, v8    // 0000008C99BC: C9080511 02021103
	ds_bpermute_b32 v9, v7, v4                                 // 0000008C99C4: DACC0000 09000407
	ds_bpermute_b32 v10, v7, v5                                // 0000008C99CC: DACC0000 0A000507
	v_cndmask_b32_e32 v12, v1, v12, vcc_lo                     // 0000008C99D4: 02181901
	ds_bpermute_b32 v11, v7, v6                                // 0000008C99D8: DACC0000 0B000607
	ds_bpermute_b32 v7, v7, v2                                 // 0000008C99E0: DACC0000 07000207
	v_lshlrev_b32_e32 v12, 2, v12                              // 0000008C99E8: 30181882
	s_waitcnt lgkmcnt(2)                                       // 0000008C99EC: BF89FC27
	v_dual_add_f32 v4, v4, v9 :: v_dual_add_f32 v5, v5, v10    // 0000008C99F0: C9081304 04041505
	ds_bpermute_b32 v8, v12, v4                                // 0000008C99F8: DACC0000 0800040C
	ds_bpermute_b32 v9, v12, v5                                // 0000008C9A00: DACC0000 0900050C
	s_waitcnt lgkmcnt(3)                                       // 0000008C9A08: BF89FC37
	v_add_f32_e32 v6, v6, v11                                  // 0000008C9A0C: 060C1706
	s_waitcnt lgkmcnt(1)                                       // 0000008C9A10: BF89FC17
	v_add_f32_e32 v4, v4, v8                                   // 0000008C9A14: 06081104
	v_add_f32_e32 v2, v2, v7                                   // 0000008C9A18: 06040F02
	ds_bpermute_b32 v7, v12, v3                                // 0000008C9A1C: DACC0000 0700030C
	s_waitcnt lgkmcnt(1)                                       // 0000008C9A24: BF89FC17
	v_add_f32_e32 v5, v5, v9                                   // 0000008C9A28: 060A1305
	ds_bpermute_b32 v10, v12, v6                               // 0000008C9A2C: DACC0000 0A00060C
	ds_bpermute_b32 v11, v12, v2                               // 0000008C9A34: DACC0000 0B00020C
	v_xor_b32_e32 v12, 2, v1                                   // 0000008C9A3C: 3A180282
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008C9A40: BF870001
	v_cmp_gt_u32_e32 vcc_lo, 32, v12                           // 0000008C9A44: 7C9818A0
	s_waitcnt lgkmcnt(2)                                       // 0000008C9A48: BF89FC27
	v_dual_add_f32 v3, v3, v7 :: v_dual_cndmask_b32 v12, v1, v12// 0000008C9A4C: C9120F03 030C1901
	s_waitcnt lgkmcnt(1)                                       // 0000008C9A54: BF89FC17
	v_add_f32_e32 v6, v6, v10                                  // 0000008C9A58: 060C1506
	s_waitcnt lgkmcnt(0)                                       // 0000008C9A5C: BF89FC07
	v_add_f32_e32 v2, v2, v11                                  // 0000008C9A60: 06041702
	v_lshlrev_b32_e32 v12, 2, v12                              // 0000008C9A64: 30181882
	ds_bpermute_b32 v7, v12, v3                                // 0000008C9A68: DACC0000 0700030C
	ds_bpermute_b32 v8, v12, v4                                // 0000008C9A70: DACC0000 0800040C
	ds_bpermute_b32 v9, v12, v5                                // 0000008C9A78: DACC0000 0900050C
	ds_bpermute_b32 v10, v12, v6                               // 0000008C9A80: DACC0000 0A00060C
	ds_bpermute_b32 v11, v12, v2                               // 0000008C9A88: DACC0000 0B00020C
	v_xor_b32_e32 v12, 1, v1                                   // 0000008C9A90: 3A180281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008C9A94: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v12                           // 0000008C9A98: 7C9818A0
	v_cndmask_b32_e32 v1, v1, v12, vcc_lo                      // 0000008C9A9C: 02021901
	s_waitcnt lgkmcnt(4)                                       // 0000008C9AA0: BF89FC47
	v_dual_add_f32 v1, v3, v7 :: v_dual_lshlrev_b32 v12, 2, v1 // 0000008C9AA4: C9220F03 010C0282
	s_waitcnt lgkmcnt(2)                                       // 0000008C9AAC: BF89FC27
	v_dual_add_f32 v3, v4, v8 :: v_dual_add_f32 v4, v5, v9     // 0000008C9AB0: C9081104 03041305
	s_waitcnt lgkmcnt(1)                                       // 0000008C9AB8: BF89FC17
	v_add_f32_e32 v7, v6, v10                                  // 0000008C9ABC: 060E1506
	s_waitcnt lgkmcnt(0)                                       // 0000008C9AC0: BF89FC07
	v_add_f32_e32 v2, v2, v11                                  // 0000008C9AC4: 06041702
	ds_bpermute_b32 v5, v12, v1                                // 0000008C9AC8: DACC0000 0500010C
	ds_bpermute_b32 v8, v12, v3                                // 0000008C9AD0: DACC0000 0800030C
	ds_bpermute_b32 v9, v12, v4                                // 0000008C9AD8: DACC0000 0900040C
	ds_bpermute_b32 v10, v12, v7                               // 0000008C9AE0: DACC0000 0A00070C
	ds_bpermute_b32 v6, v12, v2                                // 0000008C9AE8: DACC0000 0600020C
	v_cmpx_eq_u32_e32 0, v16                                   // 0000008C9AF0: 7D942080
	s_cbranch_execz 18                                         // 0000008C9AF4: BFA50012 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi8ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f+0xb40>
	v_mul_u32_u24_e32 v11, 20, v15                             // 0000008C9AF8: 16161E94
	s_waitcnt lgkmcnt(0)                                       // 0000008C9AFC: BF89FC07
	v_dual_add_f32 v3, v3, v8 :: v_dual_add_f32 v2, v2, v6     // 0000008C9B00: C9081103 03020D02
	v_add_f32_e32 v1, v1, v5                                   // 0000008C9B08: 06020B01
	v_dual_add_f32 v7, v7, v10 :: v_dual_add_f32 v4, v4, v9    // 0000008C9B0C: C9081507 07041304
	v_or_b32_e32 v5, 0x400, v11                                // 0000008C9B14: 380A16FF 00000400
	v_mad_u32_u24 v8, v15, 20, 0x408                           // 0000008C9B1C: D60B0008 03FD290F 00000408
	ds_store_2addr_b32 v5, v1, v3 offset1:1                    // 0000008C9B28: D8380100 00030105
	ds_store_2addr_b32 v8, v4, v7 offset1:1                    // 0000008C9B30: D8380100 00070408
	ds_store_b32 v11, v2 offset:1040                           // 0000008C9B38: D8340410 0000020B
	s_or_b32 exec_lo, exec_lo, s4                              // 0000008C9B40: 8C7E047E
	.long 0xd4510004                                           // 0000008C9B44: D4510004
	v_cndmask_b32_e32 v0, s2, v12, vcc_lo                      // 0000008C9B48: 02001802
	v_cmp_gt_u32_e32 vcc_lo, 5, v0                             // 0000008C9B4C: 7C980085
	s_waitcnt lgkmcnt(0)                                       // 0000008C9B50: BF89FC07
	s_barrier                                                  // 0000008C9B54: BFBD0000
	buffer_gl0_inv                                             // 0000008C9B58: E0AC0000 00000000
	s_and_b32 s4, vcc_lo, s4                                   // 0000008C9B60: 8B04046A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000008C9B64: BF870009
	s_and_saveexec_b32 s5, s4                                  // 0000008C9B68: BE852004
	s_cbranch_execz 79                                         // 0000008C9B6C: BFA5004F <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi8ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f+0xcac>
	v_add_nc_u32_e32 v7, 0x400, v14                            // 0000008C9B70: 4A0E1CFF 00000400
	s_lshr_b32 s4, s13, 31                                     // 0000008C9B78: 85049F0D
	s_load_b64 s[0:1], s[0:1], 0x40                            // 0000008C9B7C: F4040000 F8000040
	s_add_u32 s4, s12, s4                                      // 0000008C9B84: 8004040C
	s_addc_u32 s5, s13, 0                                      // 0000008C9B88: 8205800D
	ds_load_2addr_b32 v[1:2], v7 offset1:5                     // 0000008C9B8C: D8DC0500 01000007
	ds_load_2addr_b32 v[3:4], v7 offset0:10 offset1:15         // 0000008C9B94: D8DC0F0A 03000007
	ds_load_2addr_b32 v[5:6], v7 offset0:20 offset1:25         // 0000008C9B9C: D8DC1914 05000007
	s_ashr_i64 s[4:5], s[4:5], 1                               // 0000008C9BA4: 86848104
	s_lshr_b32 s6, s3, 23                                      // 0000008C9BA8: 85069703
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000008C9BAC: BF8704B9
	s_add_u32 s6, s2, s6                                       // 0000008C9BB0: 80060602
	s_addc_u32 s7, s3, 0                                       // 0000008C9BB4: 82078003
	s_and_b32 s6, s6, 0xfffffe00                               // 0000008C9BB8: 8B06FF06 FFFFFE00
	s_sub_u32 s2, s2, s6                                       // 0000008C9BC0: 80820602
	s_subb_u32 s3, s3, s7                                      // 0000008C9BC4: 82830703
	s_waitcnt lgkmcnt(0)                                       // 0000008C9BC8: BF89FC07
	v_add_f32_e32 v1, 0, v1                                    // 0000008C9BCC: 06020280
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C9BD0: BF870091
	v_add_f32_e32 v1, v1, v2                                   // 0000008C9BD4: 06020501
	v_add_f32_e32 v3, v1, v3                                   // 0000008C9BD8: 06060701
	v_mad_u64_u32 v[1:2], null, s4, v0, 0                      // 0000008C9BDC: D6FE7C01 02020004
	.long 0xd4540004                                           // 0000008C9BE4: D4540004
	v_cndmask_b32_e32 v0, 0x100, v2, vcc_lo                    // 0000008C9BE8: 020004FF 00000100
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C9BF0: BF870093
	v_add_f32_e32 v3, v3, v4                                   // 0000008C9BF4: 06060903
	v_add_f32_e32 v4, v3, v5                                   // 0000008C9BF8: 06080B03
	ds_load_2addr_b32 v[7:8], v7 offset0:30 offset1:35         // 0000008C9BFC: D8DC231E 07000007
	v_mad_u64_u32 v[2:3], null, s5, v0, v[2:3]                 // 0000008C9C04: D6FE7C02 040A0005
	s_and_b32 s5, s4, exec_lo                                  // 0000008C9C0C: 8B057E04
	s_cselect_b32 s8, s8, s0                                   // 0000008C9C10: 98080008
	v_add_f32_e32 v0, v4, v6                                   // 0000008C9C14: 06000D04
	s_cselect_b32 s5, s9, s1                                   // 0000008C9C18: 98050109
	s_add_u32 s0, s2, 0xffffff00                               // 0000008C9C1C: 8000FF02 FFFFFF00
	s_addc_u32 s1, s3, -1                                      // 0000008C9C24: 8201C103
	s_and_b32 s4, s4, exec_lo                                  // 0000008C9C28: 8B047E04
	s_cselect_b32 s1, s3, s1                                   // 0000008C9C2C: 98010103
	s_cselect_b32 s0, s2, s0                                   // 0000008C9C30: 98000002
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000008C9C34: BF870149
	s_lshl_b64 s[0:1], s[0:1], 1                               // 0000008C9C38: 84808100
	s_waitcnt lgkmcnt(0)                                       // 0000008C9C3C: BF89FC07
	v_add_f32_e32 v3, v0, v7                                   // 0000008C9C40: 06060F00
	.long 0xd73c0000                                           // 0000008C9C44: D73C0000
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 0000008C9C48: 02020281
	v_add_f32_e32 v2, v3, v8                                   // 0000008C9C4C: 06041103
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C9C50: BF870092
	.long 0xd7006a00                                           // 0000008C9C54: D7006A00
	v_cndmask_b32_e32 v1, s8, v0, vcc_lo                       // 0000008C9C58: 02020008
	v_add_co_ci_u32_e64 v1, null, s5, v1, vcc_lo               // 0000008C9C5C: D5207C01 01AA0205
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008C9C64: BF870193
	v_bfe_u32 v3, v2, 16, 1                                    // 0000008C9C68: D6100003 02052102
	.long 0xd7006a00                                           // 0000008C9C70: D7006A00
	v_cndmask_b32_e32 v0, v0, v6, vcc_lo                       // 0000008C9C74: 02000D00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008C9C78: BF870191
	v_add_co_ci_u32_e64 v1, null, s7, v1, vcc_lo               // 0000008C9C7C: D5207C01 01AA0207
	v_add3_u32 v2, v2, v3, 0x7fff                              // 0000008C9C84: D6550002 03FE0702 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C9C90: BF870093
	.long 0xd7006a00                                           // 0000008C9C94: D7006A00
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 0000008C9C98: 02000100
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 0000008C9C9C: D5207C01 01AA0201
	global_store_d16_hi_b16 v[0:1], v2, off                    // 0000008C9CA4: DC960000 007C0200
	s_endpgm                                                   // 0000008C9CAC: BFB00000
		...

