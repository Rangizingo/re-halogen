0000000000faf100 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 000000FAF100: F4100100 F8000000
	s_ashr_i32 s3, s2, 31                                      // 000000FAF108: 86039F02
	v_lshrrev_b32_e32 v2, 2, v0                                // 000000FAF10C: 32040082
	v_lshrrev_b32_e32 v29, 5, v0                               // 000000FAF110: 323A0085
	v_and_b32_e32 v30, 31, v0                                  // 000000FAF114: 363C009F
	.long 0x7f0a3880                                           // 000000FAF118: 7F0A3880
	v_lshlrev_b32_e32 v28, 2, v0                               // 000000FAF11C: 30380082
	s_waitcnt lgkmcnt(0)                                       // 000000FAF120: BF89FC07
	.long 0xd4510000                                           // 000000FAF124: D4510000
	v_cndmask_b32_e32 v0, s2, v12, vcc_lo                      // 000000FAF128: 02001802
	s_and_b32 s0, s0, exec_lo                                  // 000000FAF12C: 8B007E00
	s_cselect_b32 s20, s3, 0                                   // 000000FAF130: 98148003
	s_cselect_b32 s21, s2, 0                                   // 000000FAF134: 98158002
	s_add_u32 s0, s4, s16                                      // 000000FAF138: 80001004
	s_addc_u32 s1, s5, s17                                     // 000000FAF13C: 82011105
	v_and_b32_e32 v1, 15, v0                                   // 000000FAF140: 3602008F
	v_and_b32_e32 v2, 60, v2                                   // 000000FAF144: 360404BC
	s_ashr_i32 s16, s11, 31                                    // 000000FAF148: 86109F0B
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000FAF14C: BF870119
	s_lshr_b32 s16, s16, 27                                    // 000000FAF150: 85109B10
	v_lshlrev_b32_e32 v1, 2, v1                                // 000000FAF154: 30020282
	s_add_u32 s16, s10, s16                                    // 000000FAF158: 8010100A
	s_clause 0x1                                               // 000000FAF15C: BF850001
	global_load_b32 v3, v1, s[4:5]                             // 000000FAF160: DC520000 03040001
	global_load_b32 v4, v2, s[4:5]                             // 000000FAF168: DC520000 04040002
	s_addc_u32 s17, s11, 0                                     // 000000FAF170: 8211800B
	v_mov_b32_e32 v2, s1                                       // 000000FAF174: 7E040201
	s_lshr_b64 s[16:17], s[16:17], 5                           // 000000FAF178: 85908510
	v_mov_b32_e32 v1, s0                                       // 000000FAF17C: 7E020200
	s_add_i32 s17, s16, 7                                      // 000000FAF180: 81118710
	s_mul_i32 s1, s19, s21                                     // 000000FAF184: 96011513
	s_ashr_i32 s22, s17, 31                                    // 000000FAF188: 86169F11
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 000000FAF18C: BF8704B9
	s_lshr_b32 s0, s22, 29                                     // 000000FAF190: 85009D16
	v_mad_u64_u32 v[24:25], null, s18, s21, v[1:2]             // 000000FAF194: D6FE7C18 04042A12
	s_add_i32 s17, s17, s0                                     // 000000FAF19C: 81110011
	s_ashr_i32 s0, s17, 3                                      // 000000FAF1A0: 86008311
	s_cmpk_lt_i32 s16, 0x801                                   // 000000FAF1A4: B3900801
	.long 0xd72c0001                                           // 000000FAF1A8: D72C0001
	v_cndmask_b32_e32 v1, s0, v29, vcc_lo                      // 000000FAF1AC: 02023A00
	s_mul_i32 s17, s18, s20                                    // 000000FAF1B0: 96111412
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000FAF1B4: BF870141
	v_add_nc_u32_e32 v7, s0, v1                                // 000000FAF1B8: 4A0E0200
	v_add_nc_u32_e32 v31, v1, v30                              // 000000FAF1BC: 4A3E3D01
	s_cselect_b32 s0, -1, 0                                    // 000000FAF1C0: 980080C1
	s_cmpk_gt_i32 s16, 0x800                                   // 000000FAF1C4: B2900800
	v_min_i32_e32 v32, s16, v7                                 // 000000FAF1C8: 22400E10
	s_cselect_b32 s16, -1, 0                                   // 000000FAF1CC: 981080C1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 000000FAF1D0: BF870159
	s_and_b32 vcc_lo, exec_lo, s16                             // 000000FAF1D4: 8B6A107E
	s_waitcnt vmcnt(1)                                         // 000000FAF1D8: BF8907F7
	v_bfe_u32 v2, v3, 16, 1                                    // 000000FAF1DC: D6100002 02052103
	s_waitcnt vmcnt(0)                                         // 000000FAF1E4: BF8903F7
	v_bfe_u32 v6, v4, 16, 1                                    // 000000FAF1E8: D6100006 02052104
	v_add3_u32 v2, v3, v2, 0x7fff                              // 000000FAF1F0: D6550002 03FE0503 00007FFF
	v_add_nc_u32_e32 v3, s1, v25                               // 000000FAF1FC: 4A063201
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000FAF200: BF870223
	v_add3_u32 v4, v4, v6, 0x7fff                              // 000000FAF204: D6550004 03FE0D04 00007FFF
	.long 0xd4410001                                           // 000000FAF210: D4410001
	v_cndmask_b32_e32 v1, v31, v32, vcc_lo                     // 000000FAF214: 0202411F
	.long 0x7e0a3982                                           // 000000FAF218: 7E0A3982
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000FAF21C: BF870114
	v_add_nc_u32_e32 v33, s17, v3                              // 000000FAF220: 4A420611
	v_and_or_b32 v1, 0xffff0000, v4, v5                        // 000000FAF224: D6570001 041608FF FFFF0000
	ds_store_b32 v28, v1                                       // 000000FAF230: D8340000 0000011C
	s_waitcnt lgkmcnt(0)                                       // 000000FAF238: BF89FC07
	s_barrier                                                  // 000000FAF23C: BFBD0000
	buffer_gl0_inv                                             // 000000FAF240: E0AC0000 00000000
	s_cbranch_vccnz 154                                        // 000000FAF248: BFA4009A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x3b4>
	v_dual_mov_b32 v9, 0 :: v_dual_mov_b32 v8, 0               // 000000FAF24C: CA100080 09080080
	s_and_saveexec_b32 s17, s1                                 // 000000FAF254: BE912001
	s_cbranch_execz 11                                         // 000000FAF258: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x188>
	v_lshlrev_b32_e32 v1, 1, v31                               // 000000FAF25C: 30023E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FAF260: BF8700A1
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000FAF264: 3404029F
	.long 0xd7006a01                                           // 000000FAF268: D7006A01
	v_cndmask_b32_e32 v1, v24, v1, vcc_lo                      // 000000FAF26C: 02020318
	v_add_co_ci_u32_e64 v2, null, v33, v2, vcc_lo              // 000000FAF270: D5207C02 01AA0521
	global_load_d16_b16 v1, v[1:2], off                        // 000000FAF278: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 000000FAF280: BF8903F7
	v_cvt_f32_f16_e32 v8, v1                                   // 000000FAF284: 7E101701
	s_or_b32 exec_lo, exec_lo, s17                             // 000000FAF288: 8C7E117E
	v_add_nc_u32_e32 v1, 32, v31                               // 000000FAF28C: 4A023EA0
	s_mov_b32 s1, exec_lo                                      // 000000FAF290: BE81007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000FAF294: BF870001
	.long 0xd4c1007e                                           // 000000FAF298: D4C1007E
	v_cndmask_b32_e32 v1, v1, v32, vcc_lo                      // 000000FAF29C: 02024101
	s_cbranch_execz 11                                         // 000000FAF2A0: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x1d0>
	v_lshlrev_b32_e32 v1, 1, v1                                // 000000FAF2A4: 30020281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FAF2A8: BF8700A1
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000FAF2AC: 3404029F
	.long 0xd7006a01                                           // 000000FAF2B0: D7006A01
	v_cndmask_b32_e32 v1, v24, v1, vcc_lo                      // 000000FAF2B4: 02020318
	v_add_co_ci_u32_e64 v2, null, v33, v2, vcc_lo              // 000000FAF2B8: D5207C02 01AA0521
	global_load_d16_b16 v1, v[1:2], off                        // 000000FAF2C0: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 000000FAF2C8: BF8903F7
	v_cvt_f32_f16_e32 v9, v1                                   // 000000FAF2CC: 7E121701
	s_or_b32 exec_lo, exec_lo, s1                              // 000000FAF2D0: 8C7E017E
	v_dual_mov_b32 v10, 0 :: v_dual_add_nc_u32 v1, 64, v31     // 000000FAF2D4: CA200080 0A003EC0
	v_mov_b32_e32 v11, 0                                       // 000000FAF2DC: 7E160280
	s_mov_b32 s1, exec_lo                                      // 000000FAF2E0: BE81007E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000FAF2E4: BF870002
	.long 0xd4c1007e                                           // 000000FAF2E8: D4C1007E
	v_cndmask_b32_e32 v1, v1, v32, vcc_lo                      // 000000FAF2EC: 02024101
	s_cbranch_execz 11                                         // 000000FAF2F0: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x220>
	v_lshlrev_b32_e32 v1, 1, v1                                // 000000FAF2F4: 30020281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FAF2F8: BF8700A1
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000FAF2FC: 3404029F
	.long 0xd7006a01                                           // 000000FAF300: D7006A01
	v_cndmask_b32_e32 v1, v24, v1, vcc_lo                      // 000000FAF304: 02020318
	v_add_co_ci_u32_e64 v2, null, v33, v2, vcc_lo              // 000000FAF308: D5207C02 01AA0521
	global_load_d16_b16 v1, v[1:2], off                        // 000000FAF310: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 000000FAF318: BF8903F7
	v_cvt_f32_f16_e32 v10, v1                                  // 000000FAF31C: 7E141701
	s_or_b32 exec_lo, exec_lo, s1                              // 000000FAF320: 8C7E017E
	v_add_nc_u32_e32 v1, 0x60, v31                             // 000000FAF324: 4A023EFF 00000060
	s_mov_b32 s1, exec_lo                                      // 000000FAF32C: BE81007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000FAF330: BF870001
	.long 0xd4c1007e                                           // 000000FAF334: D4C1007E
	v_cndmask_b32_e32 v1, v1, v32, vcc_lo                      // 000000FAF338: 02024101
	s_cbranch_execz 11                                         // 000000FAF33C: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x26c>
	v_lshlrev_b32_e32 v1, 1, v1                                // 000000FAF340: 30020281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FAF344: BF8700A1
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000FAF348: 3404029F
	.long 0xd7006a01                                           // 000000FAF34C: D7006A01
	v_cndmask_b32_e32 v1, v24, v1, vcc_lo                      // 000000FAF350: 02020318
	v_add_co_ci_u32_e64 v2, null, v33, v2, vcc_lo              // 000000FAF354: D5207C02 01AA0521
	global_load_d16_b16 v1, v[1:2], off                        // 000000FAF35C: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 000000FAF364: BF8903F7
	v_cvt_f32_f16_e32 v11, v1                                  // 000000FAF368: 7E161701
	s_or_b32 exec_lo, exec_lo, s1                              // 000000FAF36C: 8C7E017E
	v_dual_mov_b32 v12, 0 :: v_dual_add_nc_u32 v1, 0x80, v31   // 000000FAF370: CA200080 0C003EFF 00000080
	v_mov_b32_e32 v13, 0                                       // 000000FAF37C: 7E1A0280
	s_mov_b32 s1, exec_lo                                      // 000000FAF380: BE81007E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000FAF384: BF870002
	.long 0xd4c1007e                                           // 000000FAF388: D4C1007E
	v_cndmask_b32_e32 v1, v1, v32, vcc_lo                      // 000000FAF38C: 02024101
	s_cbranch_execz 11                                         // 000000FAF390: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x2c0>
	v_lshlrev_b32_e32 v1, 1, v1                                // 000000FAF394: 30020281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FAF398: BF8700A1
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000FAF39C: 3404029F
	.long 0xd7006a01                                           // 000000FAF3A0: D7006A01
	v_cndmask_b32_e32 v1, v24, v1, vcc_lo                      // 000000FAF3A4: 02020318
	v_add_co_ci_u32_e64 v2, null, v33, v2, vcc_lo              // 000000FAF3A8: D5207C02 01AA0521
	global_load_d16_b16 v1, v[1:2], off                        // 000000FAF3B0: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 000000FAF3B8: BF8903F7
	v_cvt_f32_f16_e32 v12, v1                                  // 000000FAF3BC: 7E181701
	s_or_b32 exec_lo, exec_lo, s1                              // 000000FAF3C0: 8C7E017E
	v_add_nc_u32_e32 v1, 0xa0, v31                             // 000000FAF3C4: 4A023EFF 000000A0
	s_mov_b32 s1, exec_lo                                      // 000000FAF3CC: BE81007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000FAF3D0: BF870001
	.long 0xd4c1007e                                           // 000000FAF3D4: D4C1007E
	v_cndmask_b32_e32 v1, v1, v32, vcc_lo                      // 000000FAF3D8: 02024101
	s_cbranch_execz 11                                         // 000000FAF3DC: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x30c>
	v_lshlrev_b32_e32 v1, 1, v1                                // 000000FAF3E0: 30020281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FAF3E4: BF8700A1
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000FAF3E8: 3404029F
	.long 0xd7006a01                                           // 000000FAF3EC: D7006A01
	v_cndmask_b32_e32 v1, v24, v1, vcc_lo                      // 000000FAF3F0: 02020318
	v_add_co_ci_u32_e64 v2, null, v33, v2, vcc_lo              // 000000FAF3F4: D5207C02 01AA0521
	global_load_d16_b16 v1, v[1:2], off                        // 000000FAF3FC: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 000000FAF404: BF8903F7
	v_cvt_f32_f16_e32 v13, v1                                  // 000000FAF408: 7E1A1701
	s_or_b32 exec_lo, exec_lo, s1                              // 000000FAF40C: 8C7E017E
	v_dual_mov_b32 v14, 0 :: v_dual_add_nc_u32 v1, 0xc0, v31   // 000000FAF410: CA200080 0E003EFF 000000C0
	v_mov_b32_e32 v15, 0                                       // 000000FAF41C: 7E1E0280
	s_mov_b32 s1, exec_lo                                      // 000000FAF420: BE81007E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000FAF424: BF870002
	.long 0xd4c1007e                                           // 000000FAF428: D4C1007E
	v_cndmask_b32_e32 v1, v1, v32, vcc_lo                      // 000000FAF42C: 02024101
	s_cbranch_execz 11                                         // 000000FAF430: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x360>
	v_lshlrev_b32_e32 v1, 1, v1                                // 000000FAF434: 30020281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FAF438: BF8700A1
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000FAF43C: 3404029F
	.long 0xd7006a01                                           // 000000FAF440: D7006A01
	v_cndmask_b32_e32 v1, v24, v1, vcc_lo                      // 000000FAF444: 02020318
	v_add_co_ci_u32_e64 v2, null, v33, v2, vcc_lo              // 000000FAF448: D5207C02 01AA0521
	global_load_d16_b16 v1, v[1:2], off                        // 000000FAF450: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 000000FAF458: BF8903F7
	v_cvt_f32_f16_e32 v14, v1                                  // 000000FAF45C: 7E1C1701
	s_or_b32 exec_lo, exec_lo, s1                              // 000000FAF460: 8C7E017E
	v_add_nc_u32_e32 v1, 0xe0, v31                             // 000000FAF464: 4A023EFF 000000E0
	s_mov_b32 s1, exec_lo                                      // 000000FAF46C: BE81007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000FAF470: BF870001
	.long 0xd4c1007e                                           // 000000FAF474: D4C1007E
	v_cndmask_b32_e32 v1, v1, v32, vcc_lo                      // 000000FAF478: 02024101
	s_cbranch_execz 11                                         // 000000FAF47C: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x3ac>
	v_lshlrev_b32_e32 v1, 1, v1                                // 000000FAF480: 30020281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FAF484: BF8700A1
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000FAF488: 3404029F
	.long 0xd7006a01                                           // 000000FAF48C: D7006A01
	v_cndmask_b32_e32 v1, v24, v1, vcc_lo                      // 000000FAF490: 02020318
	v_add_co_ci_u32_e64 v2, null, v33, v2, vcc_lo              // 000000FAF494: D5207C02 01AA0521
	global_load_d16_b16 v1, v[1:2], off                        // 000000FAF49C: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 000000FAF4A4: BF8903F7
	v_cvt_f32_f16_e32 v15, v1                                  // 000000FAF4A8: 7E1E1701
	s_or_b32 exec_lo, exec_lo, s1                              // 000000FAF4AC: 8C7E017E
	s_branch 9                                                 // 000000FAF4B0: BFA00009 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x3d8>
	v_mov_b32_e32 v8, 0                                        // 000000FAF4B4: 7E100280
	s_delay_alu instid0(VALU_DEP_1)                            // 000000FAF4B8: BF870001
	v_mov_b32_e32 v9, v8                                       // 000000FAF4BC: 7E120308
	v_mov_b32_e32 v10, v8                                      // 000000FAF4C0: 7E140308
	v_mov_b32_e32 v11, v8                                      // 000000FAF4C4: 7E160308
	v_mov_b32_e32 v12, v8                                      // 000000FAF4C8: 7E180308
	v_mov_b32_e32 v13, v8                                      // 000000FAF4CC: 7E1A0308
	v_mov_b32_e32 v14, v8                                      // 000000FAF4D0: 7E1C0308
	v_mov_b32_e32 v15, v8                                      // 000000FAF4D4: 7E1E0308
	s_add_u32 s4, s4, s14                                      // 000000FAF4D8: 80040E04
	s_addc_u32 s5, s5, s15                                     // 000000FAF4DC: 82050F05
	s_lshr_b32 s1, s11, 31                                     // 000000FAF4E0: 85019F0B
	v_dual_mov_b32 v1, s21 :: v_dual_mov_b32 v20, 0            // 000000FAF4E4: CA100015 01140080
	s_add_u32 s14, s10, s1                                     // 000000FAF4EC: 800E010A
	s_addc_u32 s15, s11, 0                                     // 000000FAF4F0: 820F800B
	.long 0xd4410001                                           // 000000FAF4F4: D4410001
	v_cndmask_b32_e32 v1, v31, v32, vcc_lo                     // 000000FAF4F8: 0202411F
	s_ashr_i64 s[14:15], s[14:15], 1                           // 000000FAF4FC: 868E810E
	v_dual_mov_b32 v34, 0 :: v_dual_mov_b32 v27, 0             // 000000FAF500: CA100080 221A0080
	v_mad_u64_u32 v[25:26], null, v1, s14, s[4:5]              // 000000FAF508: D6FE7C19 00101D01
	.long 0xd72c0001                                           // 000000FAF510: D72C0001
	v_cndmask_b32_e32 v0, s21, v15, vcc_lo                     // 000000FAF514: 02001E15
	.long 0xd72c0002                                           // 000000FAF518: D72C0002
	v_cndmask_b32_e32 v0, s20, v14, vcc_lo                     // 000000FAF51C: 02001C14
	v_cndmask_b32_e64 v35, 0, 1, s16                           // 000000FAF520: D5010023 00410280
	v_dual_mov_b32 v21, 0 :: v_dual_mov_b32 v22, 0             // 000000FAF528: CA100080 15160080
	v_mov_b32_e32 v23, 0                                       // 000000FAF530: 7E2E0280
	s_delay_alu instid0(VALU_DEP_4)                            // 000000FAF534: BF870004
	v_add3_u32 v36, v2, v26, v1                                // 000000FAF538: D6550024 04063502
	s_and_saveexec_b32 s4, s1                                  // 000000FAF540: BE842001
	s_cbranch_execz 22                                         // 000000FAF544: BFA50016 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x4a0>
	v_lshlrev_b32_e32 v1, 4, v31                               // 000000FAF548: 30023E84
	v_mov_b32_e32 v27, 0                                       // 000000FAF54C: 7E360280
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FAF550: BF8700A2
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000FAF554: 3404029F
	.long 0xd7006a01                                           // 000000FAF558: D7006A01
	v_cndmask_b32_e32 v1, v25, v1, vcc_lo                      // 000000FAF55C: 02020319
	v_add_co_ci_u32_e64 v2, null, v36, v2, vcc_lo              // 000000FAF560: D5207C02 01AA0524
	s_and_not1_b32 vcc_lo, exec_lo, s16                        // 000000FAF568: 916A107E
	global_load_b128 v[20:23], v[1:2], off                     // 000000FAF56C: DC5E0000 147C0001
	s_cbranch_vccnz 10                                         // 000000FAF574: BFA4000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x4a0>
	v_lshlrev_b32_e32 v1, 1, v31                               // 000000FAF578: 30023E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FAF57C: BF870091
	.long 0xd7006a01                                           // 000000FAF580: D7006A01
	v_cndmask_b32_e32 v1, v24, v1, vcc_lo                      // 000000FAF584: 02020318
	v_add_co_ci_u32_e64 v2, null, 0, v33, vcc_lo               // 000000FAF588: D5207C02 01AA4280
	global_load_d16_b16 v1, v[1:2], off                        // 000000FAF590: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 000000FAF598: BF8903F7
	v_cvt_f32_f16_e32 v27, v1                                  // 000000FAF59C: 7E361701
	s_or_b32 exec_lo, exec_lo, s4                              // 000000FAF5A0: 8C7E047E
	v_dual_mov_b32 v38, 0 :: v_dual_mov_b32 v39, 0             // 000000FAF5A4: CA100080 26260080
	v_dual_mov_b32 v40, 0 :: v_dual_mov_b32 v41, 0             // 000000FAF5AC: CA100080 28280080
	v_dual_mov_b32 v42, 0 :: v_dual_mov_b32 v43, 0             // 000000FAF5B4: CA100080 2A2A0080
	v_mov_b32_e32 v37, 0                                       // 000000FAF5BC: 7E4A0280
	s_and_saveexec_b32 s14, s1                                 // 000000FAF5C0: BE8E2001
	s_cbranch_execz 666                                        // 000000FAF5C4: BFA5029A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0xf30>
	v_dual_mov_b32 v42, 0 :: v_dual_add_nc_u32 v1, 32, v31     // 000000FAF5C8: CA200080 2A003EA0
	v_dual_mov_b32 v37, 0 :: v_dual_lshlrev_b32 v26, 5, v31    // 000000FAF5D0: CA220080 251A3E85
	v_dual_mov_b32 v41, 0 :: v_dual_mov_b32 v38, 0             // 000000FAF5D8: CA100080 29260080
	s_delay_alu instid0(VALU_DEP_3)                            // 000000FAF5E0: BF870003
	v_dual_mov_b32 v43, 0 :: v_dual_lshlrev_b32 v44, 4, v1     // 000000FAF5E4: CA220080 2B2C0284
	v_dual_mov_b32 v40, 0 :: v_dual_lshlrev_b32 v45, 1, v1     // 000000FAF5EC: CA220080 282C0281
	v_dual_mov_b32 v39, 0 :: v_dual_mov_b32 v34, 0             // 000000FAF5F4: CA100080 27220080
	v_mov_b32_e32 v46, v27                                     // 000000FAF5FC: 7E5C031B
	s_mul_i32 s1, s11, 6                                       // 000000FAF600: 9601860B
	s_mul_hi_u32 s15, s10, 6                                   // 000000FAF604: 968F860A
	s_lshl_b64 s[4:5], s[10:11], 2                             // 000000FAF608: 8484820A
	s_add_i32 s15, s15, s1                                     // 000000FAF60C: 810F010F
	s_mul_i32 s17, s10, 6                                      // 000000FAF610: 9611860A
	s_mov_b32 s16, 0                                           // 000000FAF614: BE900080
	s_lshl_b64 s[10:11], s[10:11], 1                           // 000000FAF618: 848A810A
	s_branch 608                                               // 000000FAF61C: BFA00260 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0xea0>
	s_or_b32 exec_lo, exec_lo, s18                             // 000000FAF620: 8C7E127E
	v_cndmask_b32_e64 v47, v27, v8, s0                         // 000000FAF624: D501002F 0002111B
	v_cndmask_b32_e64 v4, v11, v12, s0                         // 000000FAF62C: D5010004 0002190B
	v_cndmask_b32_e64 v3, v10, v11, s0                         // 000000FAF634: D5010003 0002170A
	v_cndmask_b32_e64 v2, v9, v10, s0                          // 000000FAF63C: D5010002 00021509
	v_cndmask_b32_e64 v1, v8, v9, s0                           // 000000FAF644: D5010001 00021308
	v_dual_mov_b32 v8, v15 :: v_dual_and_b32 v9, 0xff, v20     // 000000FAF64C: CA24010F 080828FF 000000FF
	v_lshrrev_b32_e32 v10, 6, v20                              // 000000FAF658: 32142886
	v_lshrrev_b32_e32 v11, 14, v20                             // 000000FAF65C: 3216288E
	v_cndmask_b32_e64 v7, v14, v15, s0                         // 000000FAF660: D5010007 00021F0E
	v_cndmask_b32_e64 v6, v13, v14, s0                         // 000000FAF668: D5010006 00021D0D
	v_lshlrev_b32_e32 v9, 2, v9                                // 000000FAF670: 30121282
	v_and_b32_e32 v10, 0x3fc, v10                              // 000000FAF674: 361414FF 000003FC
	v_and_b32_e32 v11, 0x3fc, v11                              // 000000FAF67C: 361616FF 000003FC
	v_cndmask_b32_e64 v5, v12, v13, s0                         // 000000FAF684: D5010005 00021B0C
	v_ashrrev_i32_e32 v27, 31, v26                             // 000000FAF68C: 3436349F
	ds_load_b32 v9, v9                                         // 000000FAF690: D8D80000 09000009
	ds_load_b32 v10, v10                                       // 000000FAF698: D8D80000 0A00000A
	ds_load_b32 v15, v11                                       // 000000FAF6A0: D8D80000 0F00000B
	v_lshrrev_b32_e32 v11, 22, v20                             // 000000FAF6A8: 32162896
	s_and_b32 s1, exec_lo, s1                                  // 000000FAF6AC: 8B01017E
	v_add_nc_u32_e32 v44, 0x200, v44                           // 000000FAF6B0: 4A5858FF 00000200
	s_or_b32 s16, s1, s16                                      // 000000FAF6B8: 8C101001
	v_add_nc_u32_e32 v45, 64, v45                              // 000000FAF6BC: 4A5A5AC0
	v_and_b32_e32 v11, 0x3fc, v11                              // 000000FAF6C0: 361616FF 000003FC
	ds_load_b32 v60, v11                                       // 000000FAF6C8: D8D80000 3C00000B
	v_and_b32_e32 v11, 0xff, v21                               // 000000FAF6D0: 36162AFF 000000FF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000FAF6D8: BF8700B1
	v_lshlrev_b32_e32 v11, 2, v11                              // 000000FAF6DC: 30161682
	ds_load_b32 v61, v11                                       // 000000FAF6E0: D8D80000 3D00000B
	v_lshrrev_b32_e32 v11, 6, v21                              // 000000FAF6E8: 32162A86
	v_and_b32_e32 v11, 0x3fc, v11                              // 000000FAF6EC: 361616FF 000003FC
	ds_load_b32 v62, v11                                       // 000000FAF6F4: D8D80000 3E00000B
	v_lshrrev_b32_e32 v11, 14, v21                             // 000000FAF6FC: 32162A8E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000FAF700: BF8700B1
	v_and_b32_e32 v11, 0x3fc, v11                              // 000000FAF704: 361616FF 000003FC
	ds_load_b32 v63, v11                                       // 000000FAF70C: D8D80000 3F00000B
	v_lshrrev_b32_e32 v11, 22, v21                             // 000000FAF714: 32162A96
	v_and_b32_e32 v11, 0x3fc, v11                              // 000000FAF718: 361616FF 000003FC
	ds_load_b32 v64, v11                                       // 000000FAF720: D8D80000 4000000B
	v_and_b32_e32 v11, 0xff, v22                               // 000000FAF728: 36162CFF 000000FF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000FAF730: BF8700B1
	v_lshlrev_b32_e32 v11, 2, v11                              // 000000FAF734: 30161682
	ds_load_b32 v65, v11                                       // 000000FAF738: D8D80000 4100000B
	v_lshrrev_b32_e32 v11, 6, v22                              // 000000FAF740: 32162C86
	v_and_b32_e32 v11, 0x3fc, v11                              // 000000FAF744: 361616FF 000003FC
	ds_load_b32 v66, v11                                       // 000000FAF74C: D8D80000 4200000B
	v_lshrrev_b32_e32 v11, 14, v22                             // 000000FAF754: 32162C8E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000FAF758: BF8700B1
	v_and_b32_e32 v11, 0x3fc, v11                              // 000000FAF75C: 361616FF 000003FC
	ds_load_b32 v67, v11                                       // 000000FAF764: D8D80000 4300000B
	v_lshrrev_b32_e32 v11, 22, v22                             // 000000FAF76C: 32162C96
	v_and_b32_e32 v11, 0x3fc, v11                              // 000000FAF770: 361616FF 000003FC
	ds_load_b32 v68, v11                                       // 000000FAF778: D8D80000 4400000B
	v_and_b32_e32 v11, 0xff, v23                               // 000000FAF780: 36162EFF 000000FF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000FAF788: BF8700B1
	v_lshlrev_b32_e32 v11, 2, v11                              // 000000FAF78C: 30161682
	ds_load_b32 v69, v11                                       // 000000FAF790: D8D80000 4500000B
	v_lshrrev_b32_e32 v11, 6, v23                              // 000000FAF798: 32162E86
	v_and_b32_e32 v11, 0x3fc, v11                              // 000000FAF79C: 361616FF 000003FC
	ds_load_b32 v70, v11                                       // 000000FAF7A4: D8D80000 4600000B
	v_lshrrev_b32_e32 v11, 14, v23                             // 000000FAF7AC: 32162E8E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000FAF7B0: BF8700B1
	v_and_b32_e32 v11, 0x3fc, v11                              // 000000FAF7B4: 361616FF 000003FC
	ds_load_b32 v71, v11                                       // 000000FAF7BC: D8D80000 4700000B
	v_lshrrev_b32_e32 v11, 22, v23                             // 000000FAF7C4: 32162E96
	v_and_b32_e32 v11, 0x3fc, v11                              // 000000FAF7C8: 361616FF 000003FC
	ds_load_b32 v72, v11                                       // 000000FAF7D0: D8D80000 4800000B
	.long 0xd73c000b                                           // 000000FAF7D8: D73C000B
	v_cndmask_b32_e32 v1, 1, v26, vcc_lo                       // 000000FAF7DC: 02023481
	v_dual_mov_b32 v27, v46 :: v_dual_add_nc_u32 v26, 0x400, v26// 000000FAF7E0: CA20012E 1B1A34FF 00000400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FAF7EC: BF870092
	.long 0xd7006a38                                           // 000000FAF7F0: D7006A38
	v_cndmask_b32_e32 v1, s6, v11, vcc_lo                      // 000000FAF7F4: 02021606
	v_add_co_ci_u32_e64 v57, null, s7, v12, vcc_lo             // 000000FAF7F8: D5207C39 01AA1807
	s_clause 0x3                                               // 000000FAF800: BF850003
	global_load_b128 v[11:14], v[56:57], off                   // 000000FAF804: DC5E0000 0B7C0038
	global_load_b128 v[20:23], v[56:57], off offset:16         // 000000FAF80C: DC5E0010 147C0038
	global_load_b128 v[48:51], v[56:57], off offset:32         // 000000FAF814: DC5E0020 307C0038
	global_load_b128 v[52:55], v[56:57], off offset:48         // 000000FAF81C: DC5E0030 347C0038
	s_waitcnt vmcnt(3) lgkmcnt(15)                             // 000000FAF824: BF890CF7
	v_dot2_f32_bf16 v11, v11, v9, 0                            // 000000FAF828: CC1A400B 1A02130B
	s_waitcnt lgkmcnt(14)                                      // 000000FAF830: BF89FCE7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FAF834: BF8700A1
	v_dot2_f32_bf16 v11, v12, v10, v11                         // 000000FAF838: CC1A400B 1C2E150C
	s_waitcnt lgkmcnt(13)                                      // 000000FAF840: BF89FCD7
	v_dot2_f32_bf16 v11, v13, v15, v11                         // 000000FAF844: CC1A400B 1C2E1F0D
	s_waitcnt lgkmcnt(12)                                      // 000000FAF84C: BF89FCC7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FAF850: BF8700A1
	v_dot2_f32_bf16 v11, v14, v60, v11                         // 000000FAF854: CC1A400B 1C2E790E
	s_waitcnt vmcnt(2) lgkmcnt(11)                             // 000000FAF85C: BF8908B7
	v_dot2_f32_bf16 v11, v20, v61, v11                         // 000000FAF860: CC1A400B 1C2E7B14
	s_waitcnt lgkmcnt(10)                                      // 000000FAF868: BF89FCA7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FAF86C: BF8700A1
	v_dot2_f32_bf16 v11, v21, v62, v11                         // 000000FAF870: CC1A400B 1C2E7D15
	s_waitcnt lgkmcnt(9)                                       // 000000FAF878: BF89FC97
	v_dot2_f32_bf16 v11, v22, v63, v11                         // 000000FAF87C: CC1A400B 1C2E7F16
	s_waitcnt lgkmcnt(8)                                       // 000000FAF884: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FAF888: BF8700A1
	v_dot2_f32_bf16 v11, v23, v64, v11                         // 000000FAF88C: CC1A400B 1C2E8117
	s_waitcnt vmcnt(1) lgkmcnt(7)                              // 000000FAF894: BF890477
	v_dot2_f32_bf16 v11, v48, v65, v11                         // 000000FAF898: CC1A400B 1C2E8330
	s_waitcnt lgkmcnt(6)                                       // 000000FAF8A0: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FAF8A4: BF8700A1
	v_dot2_f32_bf16 v11, v49, v66, v11                         // 000000FAF8A8: CC1A400B 1C2E8531
	s_waitcnt lgkmcnt(5)                                       // 000000FAF8B0: BF89FC57
	v_dot2_f32_bf16 v11, v50, v67, v11                         // 000000FAF8B4: CC1A400B 1C2E8732
	s_waitcnt lgkmcnt(4)                                       // 000000FAF8BC: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FAF8C0: BF8700A1
	v_dot2_f32_bf16 v11, v51, v68, v11                         // 000000FAF8C4: CC1A400B 1C2E8933
	s_waitcnt vmcnt(0) lgkmcnt(3)                              // 000000FAF8CC: BF890037
	v_dot2_f32_bf16 v11, v52, v69, v11                         // 000000FAF8D0: CC1A400B 1C2E8B34
	.long 0xd7006a34                                           // 000000FAF8D8: D7006A34
	v_cndmask_b32_e32 v0, v56, v10, vcc_lo                     // 000000FAF8DC: 02001538
	s_waitcnt lgkmcnt(2)                                       // 000000FAF8E0: BF89FC27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000FAF8E4: BF8701C2
	v_dot2_f32_bf16 v11, v53, v70, v11                         // 000000FAF8E8: CC1A400B 1C2E8D35
	v_add_co_ci_u32_e64 v53, null, s11, v57, vcc_lo            // 000000FAF8F0: D5207C35 01AA720B
	.long 0xd7006a3a                                           // 000000FAF8F8: D7006A3A
	v_cndmask_b32_e32 v0, v56, v4, vcc_lo                      // 000000FAF8FC: 02000938
	s_waitcnt lgkmcnt(1)                                       // 000000FAF900: BF89FC17
	v_dot2_f32_bf16 v11, v54, v71, v11                         // 000000FAF904: CC1A400B 1C2E8F36
	v_add_co_ci_u32_e64 v59, null, s5, v57, vcc_lo             // 000000FAF90C: D5207C3B 01AA7205
	.long 0xd7006a38                                           // 000000FAF914: D7006A38
	v_cndmask_b32_e32 v0, v56, v17, vcc_lo                     // 000000FAF918: 02002338
	s_waitcnt lgkmcnt(0)                                       // 000000FAF91C: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000FAF920: BF870123
	v_dot2_f32_bf16 v11, v55, v72, v11                         // 000000FAF924: CC1A400B 1C2E9137
	v_add_co_ci_u32_e64 v57, null, s15, v57, vcc_lo            // 000000FAF92C: D5207C39 01AA720F
	v_fmac_f32_e32 v37, v47, v11                               // 000000FAF934: 564A172F
	s_clause 0x3                                               // 000000FAF938: BF850003
	global_load_b128 v[11:14], v[52:53], off                   // 000000FAF93C: DC5E0000 0B7C0034
	global_load_b128 v[20:23], v[52:53], off offset:16         // 000000FAF944: DC5E0010 147C0034
	global_load_b128 v[48:51], v[52:53], off offset:32         // 000000FAF94C: DC5E0020 307C0034
	global_load_b128 v[52:55], v[52:53], off offset:48         // 000000FAF954: DC5E0030 347C0034
	s_waitcnt vmcnt(3)                                         // 000000FAF95C: BF890FF7
	v_dot2_f32_bf16 v11, v11, v9, 0                            // 000000FAF960: CC1A400B 1A02130B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FAF968: BF870091
	v_dot2_f32_bf16 v11, v12, v10, v11                         // 000000FAF96C: CC1A400B 1C2E150C
	v_dot2_f32_bf16 v11, v13, v15, v11                         // 000000FAF974: CC1A400B 1C2E1F0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FAF97C: BF8700A1
	v_dot2_f32_bf16 v11, v14, v60, v11                         // 000000FAF980: CC1A400B 1C2E790E
	s_waitcnt vmcnt(2)                                         // 000000FAF988: BF890BF7
	v_dot2_f32_bf16 v11, v20, v61, v11                         // 000000FAF98C: CC1A400B 1C2E7B14
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FAF994: BF870091
	v_dot2_f32_bf16 v11, v21, v62, v11                         // 000000FAF998: CC1A400B 1C2E7D15
	v_dot2_f32_bf16 v11, v22, v63, v11                         // 000000FAF9A0: CC1A400B 1C2E7F16
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FAF9A8: BF8700A1
	v_dot2_f32_bf16 v11, v23, v64, v11                         // 000000FAF9AC: CC1A400B 1C2E8117
	s_waitcnt vmcnt(1)                                         // 000000FAF9B4: BF8907F7
	v_dot2_f32_bf16 v11, v48, v65, v11                         // 000000FAF9B8: CC1A400B 1C2E8330
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FAF9C0: BF870091
	v_dot2_f32_bf16 v11, v49, v66, v11                         // 000000FAF9C4: CC1A400B 1C2E8531
	v_dot2_f32_bf16 v11, v50, v67, v11                         // 000000FAF9CC: CC1A400B 1C2E8732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FAF9D4: BF8700A1
	v_dot2_f32_bf16 v11, v51, v68, v11                         // 000000FAF9D8: CC1A400B 1C2E8933
	s_waitcnt vmcnt(0)                                         // 000000FAF9E0: BF8903F7
	v_dot2_f32_bf16 v11, v52, v69, v11                         // 000000FAF9E4: CC1A400B 1C2E8B34
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FAF9EC: BF870091
	v_dot2_f32_bf16 v11, v53, v70, v11                         // 000000FAF9F0: CC1A400B 1C2E8D35
	v_dot2_f32_bf16 v11, v54, v71, v11                         // 000000FAF9F8: CC1A400B 1C2E8F36
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FAFA00: BF870091
	v_dot2_f32_bf16 v11, v55, v72, v11                         // 000000FAFA04: CC1A400B 1C2E9137
	v_fmac_f32_e32 v43, v47, v11                               // 000000FAFA0C: 5656172F
	s_clause 0x3                                               // 000000FAFA10: BF850003
	global_load_b128 v[11:14], v[58:59], off                   // 000000FAFA14: DC5E0000 0B7C003A
	global_load_b128 v[20:23], v[58:59], off offset:16         // 000000FAFA1C: DC5E0010 147C003A
	global_load_b128 v[48:51], v[58:59], off offset:32         // 000000FAFA24: DC5E0020 307C003A
	global_load_b128 v[52:55], v[58:59], off offset:48         // 000000FAFA2C: DC5E0030 347C003A
	.long 0xd7006a3a                                           // 000000FAFA34: D7006A3A
	v_cndmask_b32_e32 v0, v58, v4, vcc_lo                      // 000000FAFA38: 0200093A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000FAFA3C: BF8700B1
	v_add_co_ci_u32_e64 v59, null, s5, v59, vcc_lo             // 000000FAFA40: D5207C3B 01AA7605
	s_waitcnt vmcnt(3)                                         // 000000FAFA48: BF890FF7
	v_dot2_f32_bf16 v11, v11, v9, 0                            // 000000FAFA4C: CC1A400B 1A02130B
	v_dot2_f32_bf16 v11, v12, v10, v11                         // 000000FAFA54: CC1A400B 1C2E150C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FAFA5C: BF870091
	v_dot2_f32_bf16 v11, v13, v15, v11                         // 000000FAFA60: CC1A400B 1C2E1F0D
	v_dot2_f32_bf16 v11, v14, v60, v11                         // 000000FAFA68: CC1A400B 1C2E790E
	s_waitcnt vmcnt(2)                                         // 000000FAFA70: BF890BF7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FAFA74: BF870091
	v_dot2_f32_bf16 v11, v20, v61, v11                         // 000000FAFA78: CC1A400B 1C2E7B14
	v_dot2_f32_bf16 v11, v21, v62, v11                         // 000000FAFA80: CC1A400B 1C2E7D15
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FAFA88: BF870091
	v_dot2_f32_bf16 v11, v22, v63, v11                         // 000000FAFA8C: CC1A400B 1C2E7F16
	v_dot2_f32_bf16 v11, v23, v64, v11                         // 000000FAFA94: CC1A400B 1C2E8117
	s_waitcnt vmcnt(1)                                         // 000000FAFA9C: BF8907F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FAFAA0: BF870091
	v_dot2_f32_bf16 v11, v48, v65, v11                         // 000000FAFAA4: CC1A400B 1C2E8330
	v_dot2_f32_bf16 v11, v49, v66, v11                         // 000000FAFAAC: CC1A400B 1C2E8531
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FAFAB4: BF870091
	v_dot2_f32_bf16 v11, v50, v67, v11                         // 000000FAFAB8: CC1A400B 1C2E8732
	v_dot2_f32_bf16 v11, v51, v68, v11                         // 000000FAFAC0: CC1A400B 1C2E8933
	s_waitcnt vmcnt(0)                                         // 000000FAFAC8: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FAFACC: BF870091
	v_dot2_f32_bf16 v11, v52, v69, v11                         // 000000FAFAD0: CC1A400B 1C2E8B34
	v_dot2_f32_bf16 v11, v53, v70, v11                         // 000000FAFAD8: CC1A400B 1C2E8D35
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FAFAE0: BF870091
	v_dot2_f32_bf16 v11, v54, v71, v11                         // 000000FAFAE4: CC1A400B 1C2E8F36
	v_dot2_f32_bf16 v11, v55, v72, v11                         // 000000FAFAEC: CC1A400B 1C2E9137
	s_delay_alu instid0(VALU_DEP_1)                            // 000000FAFAF4: BF870001
	v_fmac_f32_e32 v42, v47, v11                               // 000000FAFAF8: 5654172F
	s_clause 0x3                                               // 000000FAFAFC: BF850003
	global_load_b128 v[11:14], v[56:57], off                   // 000000FAFB00: DC5E0000 0B7C0038
	global_load_b128 v[20:23], v[56:57], off offset:16         // 000000FAFB08: DC5E0010 147C0038
	global_load_b128 v[48:51], v[56:57], off offset:32         // 000000FAFB10: DC5E0020 307C0038
	global_load_b128 v[52:55], v[56:57], off offset:48         // 000000FAFB18: DC5E0030 347C0038
	.long 0xd7006a38                                           // 000000FAFB20: D7006A38
	v_cndmask_b32_e32 v0, v56, v4, vcc_lo                      // 000000FAFB24: 02000938
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000FAFB28: BF8700B1
	v_add_co_ci_u32_e64 v57, null, s5, v57, vcc_lo             // 000000FAFB2C: D5207C39 01AA7205
	s_waitcnt vmcnt(3)                                         // 000000FAFB34: BF890FF7
	v_dot2_f32_bf16 v11, v11, v9, 0                            // 000000FAFB38: CC1A400B 1A02130B
	v_dot2_f32_bf16 v11, v12, v10, v11                         // 000000FAFB40: CC1A400B 1C2E150C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FAFB48: BF870091
	v_dot2_f32_bf16 v11, v13, v15, v11                         // 000000FAFB4C: CC1A400B 1C2E1F0D
	v_dot2_f32_bf16 v11, v14, v60, v11                         // 000000FAFB54: CC1A400B 1C2E790E
	s_waitcnt vmcnt(2)                                         // 000000FAFB5C: BF890BF7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FAFB60: BF870091
	v_dot2_f32_bf16 v11, v20, v61, v11                         // 000000FAFB64: CC1A400B 1C2E7B14
	v_dot2_f32_bf16 v11, v21, v62, v11                         // 000000FAFB6C: CC1A400B 1C2E7D15
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FAFB74: BF870091
	v_dot2_f32_bf16 v11, v22, v63, v11                         // 000000FAFB78: CC1A400B 1C2E7F16
	v_dot2_f32_bf16 v11, v23, v64, v11                         // 000000FAFB80: CC1A400B 1C2E8117
	s_waitcnt vmcnt(1)                                         // 000000FAFB88: BF8907F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FAFB8C: BF870091
	v_dot2_f32_bf16 v11, v48, v65, v11                         // 000000FAFB90: CC1A400B 1C2E8330
	v_dot2_f32_bf16 v11, v49, v66, v11                         // 000000FAFB98: CC1A400B 1C2E8531
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FAFBA0: BF870091
	v_dot2_f32_bf16 v11, v50, v67, v11                         // 000000FAFBA4: CC1A400B 1C2E8732
	v_dot2_f32_bf16 v11, v51, v68, v11                         // 000000FAFBAC: CC1A400B 1C2E8933
	s_waitcnt vmcnt(0)                                         // 000000FAFBB4: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FAFBB8: BF870091
	v_dot2_f32_bf16 v11, v52, v69, v11                         // 000000FAFBBC: CC1A400B 1C2E8B34
	v_dot2_f32_bf16 v11, v53, v70, v11                         // 000000FAFBC4: CC1A400B 1C2E8D35
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FAFBCC: BF870091
	v_dot2_f32_bf16 v11, v54, v71, v11                         // 000000FAFBD0: CC1A400B 1C2E8F36
	v_dot2_f32_bf16 v11, v55, v72, v11                         // 000000FAFBD8: CC1A400B 1C2E9137
	s_delay_alu instid0(VALU_DEP_1)                            // 000000FAFBE0: BF870001
	v_fmac_f32_e32 v41, v47, v11                               // 000000FAFBE4: 5652172F
	s_clause 0x3                                               // 000000FAFBE8: BF850003
	global_load_b128 v[11:14], v[58:59], off                   // 000000FAFBEC: DC5E0000 0B7C003A
	global_load_b128 v[20:23], v[58:59], off offset:16         // 000000FAFBF4: DC5E0010 147C003A
	global_load_b128 v[48:51], v[58:59], off offset:32         // 000000FAFBFC: DC5E0020 307C003A
	global_load_b128 v[52:55], v[58:59], off offset:48         // 000000FAFC04: DC5E0030 347C003A
	s_waitcnt vmcnt(3)                                         // 000000FAFC0C: BF890FF7
	v_dot2_f32_bf16 v11, v11, v9, 0                            // 000000FAFC10: CC1A400B 1A02130B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FAFC18: BF870091
	v_dot2_f32_bf16 v11, v12, v10, v11                         // 000000FAFC1C: CC1A400B 1C2E150C
	v_dot2_f32_bf16 v11, v13, v15, v11                         // 000000FAFC24: CC1A400B 1C2E1F0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FAFC2C: BF8700A1
	v_dot2_f32_bf16 v11, v14, v60, v11                         // 000000FAFC30: CC1A400B 1C2E790E
	s_waitcnt vmcnt(2)                                         // 000000FAFC38: BF890BF7
	v_dot2_f32_bf16 v11, v20, v61, v11                         // 000000FAFC3C: CC1A400B 1C2E7B14
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FAFC44: BF870091
	v_dot2_f32_bf16 v11, v21, v62, v11                         // 000000FAFC48: CC1A400B 1C2E7D15
	v_dot2_f32_bf16 v11, v22, v63, v11                         // 000000FAFC50: CC1A400B 1C2E7F16
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FAFC58: BF8700A1
	v_dot2_f32_bf16 v11, v23, v64, v11                         // 000000FAFC5C: CC1A400B 1C2E8117
	s_waitcnt vmcnt(1)                                         // 000000FAFC64: BF8907F7
	v_dot2_f32_bf16 v11, v48, v65, v11                         // 000000FAFC68: CC1A400B 1C2E8330
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FAFC70: BF870091
	v_dot2_f32_bf16 v11, v49, v66, v11                         // 000000FAFC74: CC1A400B 1C2E8531
	v_dot2_f32_bf16 v11, v50, v67, v11                         // 000000FAFC7C: CC1A400B 1C2E8732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FAFC84: BF8700A1
	v_dot2_f32_bf16 v11, v51, v68, v11                         // 000000FAFC88: CC1A400B 1C2E8933
	s_waitcnt vmcnt(0)                                         // 000000FAFC90: BF8903F7
	v_dot2_f32_bf16 v11, v52, v69, v11                         // 000000FAFC94: CC1A400B 1C2E8B34
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FAFC9C: BF870091
	v_dot2_f32_bf16 v11, v53, v70, v11                         // 000000FAFCA0: CC1A400B 1C2E8D35
	v_dot2_f32_bf16 v11, v54, v71, v11                         // 000000FAFCA8: CC1A400B 1C2E8F36
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FAFCB0: BF870091
	v_dot2_f32_bf16 v11, v55, v72, v11                         // 000000FAFCB4: CC1A400B 1C2E9137
	v_fmac_f32_e32 v40, v47, v11                               // 000000FAFCBC: 5650172F
	s_clause 0x3                                               // 000000FAFCC0: BF850003
	global_load_b128 v[11:14], v[56:57], off                   // 000000FAFCC4: DC5E0000 0B7C0038
	global_load_b128 v[20:23], v[56:57], off offset:16         // 000000FAFCCC: DC5E0010 147C0038
	global_load_b128 v[48:51], v[56:57], off offset:32         // 000000FAFCD4: DC5E0020 307C0038
	global_load_b128 v[52:55], v[56:57], off offset:48         // 000000FAFCDC: DC5E0030 347C0038
	s_waitcnt vmcnt(3)                                         // 000000FAFCE4: BF890FF7
	v_dot2_f32_bf16 v11, v11, v9, 0                            // 000000FAFCE8: CC1A400B 1A02130B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FAFCF0: BF870091
	v_dot2_f32_bf16 v11, v12, v10, v11                         // 000000FAFCF4: CC1A400B 1C2E150C
	v_dot2_f32_bf16 v11, v13, v15, v11                         // 000000FAFCFC: CC1A400B 1C2E1F0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FAFD04: BF8700A1
	v_dot2_f32_bf16 v11, v14, v60, v11                         // 000000FAFD08: CC1A400B 1C2E790E
	s_waitcnt vmcnt(2)                                         // 000000FAFD10: BF890BF7
	v_dot2_f32_bf16 v11, v20, v61, v11                         // 000000FAFD14: CC1A400B 1C2E7B14
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FAFD1C: BF870091
	v_dot2_f32_bf16 v11, v21, v62, v11                         // 000000FAFD20: CC1A400B 1C2E7D15
	v_dot2_f32_bf16 v11, v22, v63, v11                         // 000000FAFD28: CC1A400B 1C2E7F16
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FAFD30: BF8700A1
	v_dot2_f32_bf16 v11, v23, v64, v11                         // 000000FAFD34: CC1A400B 1C2E8117
	s_waitcnt vmcnt(1)                                         // 000000FAFD3C: BF8907F7
	v_dot2_f32_bf16 v11, v48, v65, v11                         // 000000FAFD40: CC1A400B 1C2E8330
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FAFD48: BF870091
	v_dot2_f32_bf16 v11, v49, v66, v11                         // 000000FAFD4C: CC1A400B 1C2E8531
	v_dot2_f32_bf16 v11, v50, v67, v11                         // 000000FAFD54: CC1A400B 1C2E8732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FAFD5C: BF8700A1
	v_dot2_f32_bf16 v11, v51, v68, v11                         // 000000FAFD60: CC1A400B 1C2E8933
	s_waitcnt vmcnt(0)                                         // 000000FAFD68: BF8903F7
	v_dot2_f32_bf16 v11, v52, v69, v11                         // 000000FAFD6C: CC1A400B 1C2E8B34
	.long 0xd7006a34                                           // 000000FAFD74: D7006A34
	v_cndmask_b32_e32 v0, v58, v4, vcc_lo                      // 000000FAFD78: 0200093A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000FAFD7C: BF870122
	v_dot2_f32_bf16 v11, v53, v70, v11                         // 000000FAFD80: CC1A400B 1C2E8D35
	v_add_co_ci_u32_e64 v53, null, s5, v59, vcc_lo             // 000000FAFD88: D5207C35 01AA7605
	v_dot2_f32_bf16 v11, v54, v71, v11                         // 000000FAFD90: CC1A400B 1C2E8F36
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FAFD98: BF870091
	v_dot2_f32_bf16 v11, v55, v72, v11                         // 000000FAFD9C: CC1A400B 1C2E9137
	v_fmac_f32_e32 v39, v47, v11                               // 000000FAFDA4: 564E172F
	s_clause 0x3                                               // 000000FAFDA8: BF850003
	global_load_b128 v[11:14], v[52:53], off                   // 000000FAFDAC: DC5E0000 0B7C0034
	global_load_b128 v[20:23], v[52:53], off offset:16         // 000000FAFDB4: DC5E0010 147C0034
	global_load_b128 v[48:51], v[52:53], off offset:32         // 000000FAFDBC: DC5E0020 307C0034
	global_load_b128 v[52:55], v[52:53], off offset:48         // 000000FAFDC4: DC5E0030 347C0034
	s_waitcnt vmcnt(3)                                         // 000000FAFDCC: BF890FF7
	v_dot2_f32_bf16 v11, v11, v9, 0                            // 000000FAFDD0: CC1A400B 1A02130B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FAFDD8: BF870091
	v_dot2_f32_bf16 v11, v12, v10, v11                         // 000000FAFDDC: CC1A400B 1C2E150C
	v_dot2_f32_bf16 v11, v13, v15, v11                         // 000000FAFDE4: CC1A400B 1C2E1F0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FAFDEC: BF8700A1
	v_dot2_f32_bf16 v11, v14, v60, v11                         // 000000FAFDF0: CC1A400B 1C2E790E
	s_waitcnt vmcnt(2)                                         // 000000FAFDF8: BF890BF7
	v_dot2_f32_bf16 v11, v20, v61, v11                         // 000000FAFDFC: CC1A400B 1C2E7B14
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FAFE04: BF870091
	v_dot2_f32_bf16 v11, v21, v62, v11                         // 000000FAFE08: CC1A400B 1C2E7D15
	v_dot2_f32_bf16 v11, v22, v63, v11                         // 000000FAFE10: CC1A400B 1C2E7F16
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FAFE18: BF8700A1
	v_dot2_f32_bf16 v11, v23, v64, v11                         // 000000FAFE1C: CC1A400B 1C2E8117
	s_waitcnt vmcnt(1)                                         // 000000FAFE24: BF8907F7
	v_dot2_f32_bf16 v11, v48, v65, v11                         // 000000FAFE28: CC1A400B 1C2E8330
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FAFE30: BF870091
	v_dot2_f32_bf16 v11, v49, v66, v11                         // 000000FAFE34: CC1A400B 1C2E8531
	v_dot2_f32_bf16 v11, v50, v67, v11                         // 000000FAFE3C: CC1A400B 1C2E8732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FAFE44: BF8700A1
	v_dot2_f32_bf16 v11, v51, v68, v11                         // 000000FAFE48: CC1A400B 1C2E8933
	s_waitcnt vmcnt(0)                                         // 000000FAFE50: BF8903F7
	v_dot2_f32_bf16 v11, v52, v69, v11                         // 000000FAFE54: CC1A400B 1C2E8B34
	.long 0xd7006a34                                           // 000000FAFE5C: D7006A34
	v_cndmask_b32_e32 v0, v56, v4, vcc_lo                      // 000000FAFE60: 02000938
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000FAFE64: BF870122
	v_dot2_f32_bf16 v11, v53, v70, v11                         // 000000FAFE68: CC1A400B 1C2E8D35
	v_add_co_ci_u32_e64 v53, null, s5, v57, vcc_lo             // 000000FAFE70: D5207C35 01AA7205
	v_dot2_f32_bf16 v11, v54, v71, v11                         // 000000FAFE78: CC1A400B 1C2E8F36
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FAFE80: BF870091
	v_dot2_f32_bf16 v11, v55, v72, v11                         // 000000FAFE84: CC1A400B 1C2E9137
	v_fmac_f32_e32 v38, v47, v11                               // 000000FAFE8C: 564C172F
	s_clause 0x3                                               // 000000FAFE90: BF850003
	global_load_b128 v[11:14], v[52:53], off                   // 000000FAFE94: DC5E0000 0B7C0034
	global_load_b128 v[20:23], v[52:53], off offset:16         // 000000FAFE9C: DC5E0010 147C0034
	global_load_b128 v[48:51], v[52:53], off offset:32         // 000000FAFEA4: DC5E0020 307C0034
	global_load_b128 v[52:55], v[52:53], off offset:48         // 000000FAFEAC: DC5E0030 347C0034
	s_waitcnt vmcnt(3)                                         // 000000FAFEB4: BF890FF7
	v_dot2_f32_bf16 v9, v11, v9, 0                             // 000000FAFEB8: CC1A4009 1A02130B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FAFEC0: BF870091
	v_dot2_f32_bf16 v9, v12, v10, v9                           // 000000FAFEC4: CC1A4009 1C26150C
	v_dot2_f32_bf16 v9, v13, v15, v9                           // 000000FAFECC: CC1A4009 1C261F0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FAFED4: BF8700A1
	v_dot2_f32_bf16 v9, v14, v60, v9                           // 000000FAFED8: CC1A4009 1C26790E
	s_waitcnt vmcnt(2)                                         // 000000FAFEE0: BF890BF7
	v_dot2_f32_bf16 v9, v20, v61, v9                           // 000000FAFEE4: CC1A4009 1C267B14
	v_mov_b32_e32 v20, v16                                     // 000000FAFEEC: 7E280310
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000FAFEF0: BF870122
	v_dot2_f32_bf16 v9, v21, v62, v9                           // 000000FAFEF4: CC1A4009 1C267D15
	v_mov_b32_e32 v21, v17                                     // 000000FAFEFC: 7E2A0311
	v_dot2_f32_bf16 v9, v22, v63, v9                           // 000000FAFF00: CC1A4009 1C267F16
	v_mov_b32_e32 v22, v18                                     // 000000FAFF08: 7E2C0312
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000FAFF0C: BF870132
	v_dot2_f32_bf16 v9, v23, v64, v9                           // 000000FAFF10: CC1A4009 1C268117
	v_mov_b32_e32 v23, v19                                     // 000000FAFF18: 7E2E0313
	s_waitcnt vmcnt(1)                                         // 000000FAFF1C: BF8907F7
	v_dot2_f32_bf16 v9, v48, v65, v9                           // 000000FAFF20: CC1A4009 1C268330
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FAFF28: BF870091
	v_dot2_f32_bf16 v9, v49, v66, v9                           // 000000FAFF2C: CC1A4009 1C268531
	v_dot2_f32_bf16 v9, v50, v67, v9                           // 000000FAFF34: CC1A4009 1C268732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FAFF3C: BF8700A1
	v_dot2_f32_bf16 v9, v51, v68, v9                           // 000000FAFF40: CC1A4009 1C268933
	s_waitcnt vmcnt(0)                                         // 000000FAFF48: BF8903F7
	v_dot2_f32_bf16 v9, v52, v69, v9                           // 000000FAFF4C: CC1A4009 1C268B34
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FAFF54: BF870091
	v_dot2_f32_bf16 v9, v53, v70, v9                           // 000000FAFF58: CC1A4009 1C268D35
	v_dot2_f32_bf16 v9, v54, v71, v9                           // 000000FAFF60: CC1A4009 1C268F36
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FAFF68: BF870091
	v_dot2_f32_bf16 v9, v55, v72, v9                           // 000000FAFF6C: CC1A4009 1C269137
	v_dual_fmac_f32 v34, v47, v9 :: v_dual_mov_b32 v15, v8     // 000000FAFF74: C810132F 220E0108
	v_dual_mov_b32 v14, v7 :: v_dual_mov_b32 v13, v6           // 000000FAFF7C: CA100107 0E0C0106
	v_dual_mov_b32 v12, v5 :: v_dual_mov_b32 v11, v4           // 000000FAFF84: CA100105 0C0A0104
	v_dual_mov_b32 v10, v3 :: v_dual_mov_b32 v9, v2            // 000000FAFF8C: CA100103 0A080102
	v_mov_b32_e32 v8, v1                                       // 000000FAFF94: 7E100301
	s_and_not1_b32 exec_lo, exec_lo, s16                       // 000000FAFF98: 917E107E
	s_cbranch_execz 35                                         // 000000FAFF9C: BFA50023 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0xf2c>
	s_waitcnt vmcnt(0)                                         // 000000FAFFA0: BF8903F7
	v_dual_mov_b32 v16, v20 :: v_dual_add_nc_u32 v31, 32, v31  // 000000FAFFA4: CA200114 101E3EA0
	v_dual_mov_b32 v17, v21 :: v_dual_mov_b32 v18, v22         // 000000FAFFAC: CA100115 11120116
	v_mov_b32_e32 v19, v23                                     // 000000FAFFB4: 7E260317
	s_delay_alu instid0(VALU_DEP_3)                            // 000000FAFFB8: BF870003
	.long 0xd4460001                                           // 000000FAFFBC: D4460001
	v_cndmask_b32_e32 v1, v31, v32, vcc_lo                     // 000000FAFFC0: 0202411F
	s_mov_b32 s18, exec_lo                                     // 000000FAFFC4: BE92007E
	.long 0xd4c1007e                                           // 000000FAFFC8: D4C1007E
	v_cndmask_b32_e32 v1, v31, v32, vcc_lo                     // 000000FAFFCC: 0202411F
	s_cbranch_execz 64915                                      // 000000FAFFD0: BFA5FD93 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x520>
	v_ashrrev_i32_e32 v2, 31, v44                              // 000000FAFFD4: 3404589F
	.long 0xd7006a01                                           // 000000FAFFD8: D7006A01
	v_cndmask_b32_e32 v1, v25, v44, vcc_lo                     // 000000FAFFDC: 02025919
	v_mov_b32_e32 v46, v27                                     // 000000FAFFE0: 7E5C031B
	s_delay_alu instid0(VALU_DEP_3)                            // 000000FAFFE4: BF870003
	v_add_co_ci_u32_e64 v2, null, v36, v2, vcc_lo              // 000000FAFFE8: D5207C02 01AA0524
	v_cmp_ne_u32_e32 vcc_lo, 1, v35                            // 000000FAFFF0: 7C9A4681
	global_load_b128 v[16:19], v[1:2], off                     // 000000FAFFF4: DC5E0000 107C0001
	s_cbranch_vccnz 64904                                      // 000000FAFFFC: BFA4FD88 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x520>
	v_ashrrev_i32_e32 v2, 31, v45                              // 000000FB0000: 34045A9F
	.long 0xd7006a01                                           // 000000FB0004: D7006A01
	v_cndmask_b32_e32 v1, v24, v45, vcc_lo                     // 000000FB0008: 02025B18
	s_delay_alu instid0(VALU_DEP_1)                            // 000000FB000C: BF870001
	v_add_co_ci_u32_e64 v2, null, v33, v2, vcc_lo              // 000000FB0010: D5207C02 01AA0521
	global_load_d16_b16 v1, v[1:2], off                        // 000000FB0018: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 000000FB0020: BF8903F7
	v_cvt_f32_f16_e32 v46, v1                                  // 000000FB0024: 7E5C1701
	s_branch 64893                                             // 000000FB0028: BFA0FD7D <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x520>
	s_or_b32 exec_lo, exec_lo, s16                             // 000000FB002C: 8C7E107E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000FB0030: BF8700B9
	s_or_b32 exec_lo, exec_lo, s14                             // 000000FB0034: 8C7E0E7E
	.long 0xd71f0001                                           // 000000FB0038: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 000000FB003C: 020100C1
	s_mov_b32 s0, exec_lo                                      // 000000FB0040: BE80007E
	v_xor_b32_e32 v2, 16, v1                                   // 000000FB0044: 3A040290
	v_xor_b32_e32 v10, 8, v1                                   // 000000FB0048: 3A140288
	v_xor_b32_e32 v18, 4, v1                                   // 000000FB004C: 3A240284
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000FB0050: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 000000FB0054: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 000000FB0058: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v10                           // 000000FB005C: 7C9814A0
	s_delay_alu instid0(VALU_DEP_2)                            // 000000FB0060: BF870002
	v_lshlrev_b32_e32 v2, 2, v2                                // 000000FB0064: 30040482
	ds_bpermute_b32 v3, v2, v37                                // 000000FB0068: DACC0000 03002502
	s_waitcnt lgkmcnt(0)                                       // 000000FB0070: BF89FC07
	v_add_f32_e32 v3, v37, v3                                  // 000000FB0074: 06060725
	ds_bpermute_b32 v5, v2, v42                                // 000000FB0078: DACC0000 05002A02
	ds_bpermute_b32 v7, v2, v40                                // 000000FB0080: DACC0000 07002802
	ds_bpermute_b32 v9, v2, v38                                // 000000FB0088: DACC0000 09002602
	v_cndmask_b32_e32 v10, v1, v10, vcc_lo                     // 000000FB0090: 02141501
	ds_bpermute_b32 v4, v2, v43                                // 000000FB0094: DACC0000 04002B02
	ds_bpermute_b32 v6, v2, v41                                // 000000FB009C: DACC0000 06002902
	ds_bpermute_b32 v8, v2, v39                                // 000000FB00A4: DACC0000 08002702
	ds_bpermute_b32 v2, v2, v34                                // 000000FB00AC: DACC0000 02002202
	v_cmp_gt_u32_e32 vcc_lo, 32, v18                           // 000000FB00B4: 7C9824A0
	s_waitcnt lgkmcnt(6)                                       // 000000FB00B8: BF89FC67
	v_add_f32_e32 v5, v42, v5                                  // 000000FB00BC: 060A0B2A
	s_waitcnt lgkmcnt(5)                                       // 000000FB00C0: BF89FC57
	v_dual_add_f32 v7, v40, v7 :: v_dual_lshlrev_b32 v10, 2, v10// 000000FB00C4: C9220F28 070A1482
	s_waitcnt lgkmcnt(4)                                       // 000000FB00CC: BF89FC47
	v_add_f32_e32 v9, v38, v9                                  // 000000FB00D0: 06121326
	ds_bpermute_b32 v11, v10, v3                               // 000000FB00D4: DACC0000 0B00030A
	ds_bpermute_b32 v13, v10, v5                               // 000000FB00DC: DACC0000 0D00050A
	ds_bpermute_b32 v15, v10, v7                               // 000000FB00E4: DACC0000 0F00070A
	ds_bpermute_b32 v17, v10, v9                               // 000000FB00EC: DACC0000 1100090A
	s_waitcnt lgkmcnt(7)                                       // 000000FB00F4: BF89FC77
	v_add_f32_e32 v4, v43, v4                                  // 000000FB00F8: 0608092B
	s_waitcnt lgkmcnt(6)                                       // 000000FB00FC: BF89FC67
	v_add_f32_e32 v6, v41, v6                                  // 000000FB0100: 060C0D29
	s_waitcnt lgkmcnt(5)                                       // 000000FB0104: BF89FC57
	v_add_f32_e32 v8, v39, v8                                  // 000000FB0108: 06101127
	s_waitcnt lgkmcnt(3)                                       // 000000FB010C: BF89FC37
	v_dual_add_f32 v2, v34, v2 :: v_dual_add_f32 v3, v3, v11   // 000000FB0110: C9080522 02021703
	ds_bpermute_b32 v14, v10, v6                               // 000000FB0118: DACC0000 0E00060A
	s_waitcnt lgkmcnt(3)                                       // 000000FB0120: BF89FC37
	v_add_f32_e32 v5, v5, v13                                  // 000000FB0124: 060A1B05
	ds_bpermute_b32 v12, v10, v4                               // 000000FB0128: DACC0000 0C00040A
	s_waitcnt lgkmcnt(3)                                       // 000000FB0130: BF89FC37
	v_add_f32_e32 v7, v7, v15                                  // 000000FB0134: 060E1F07
	s_waitcnt lgkmcnt(2)                                       // 000000FB0138: BF89FC27
	v_add_f32_e32 v9, v9, v17                                  // 000000FB013C: 06122309
	ds_bpermute_b32 v16, v10, v8                               // 000000FB0140: DACC0000 1000080A
	ds_bpermute_b32 v10, v10, v2                               // 000000FB0148: DACC0000 0A00020A
	s_waitcnt lgkmcnt(2)                                       // 000000FB0150: BF89FC27
	v_add_f32_e32 v4, v4, v12                                  // 000000FB0154: 06081904
	s_waitcnt lgkmcnt(1)                                       // 000000FB0158: BF89FC17
	v_add_f32_e32 v8, v8, v16                                  // 000000FB015C: 06102108
	s_waitcnt lgkmcnt(0)                                       // 000000FB0160: BF89FC07
	v_add_f32_e32 v2, v2, v10                                  // 000000FB0164: 06041502
	v_cndmask_b32_e32 v18, v1, v18, vcc_lo                     // 000000FB0168: 02242501
	s_delay_alu instid0(VALU_DEP_1)                            // 000000FB016C: BF870001
	v_lshlrev_b32_e32 v18, 2, v18                              // 000000FB0170: 30242482
	ds_bpermute_b32 v12, v18, v5                               // 000000FB0174: DACC0000 0C000512
	s_waitcnt lgkmcnt(0)                                       // 000000FB017C: BF89FC07
	v_add_f32_e32 v5, v5, v12                                  // 000000FB0180: 060A1905
	ds_bpermute_b32 v16, v18, v9                               // 000000FB0184: DACC0000 10000912
	v_add_f32_e32 v6, v6, v14                                  // 000000FB018C: 060C1D06
	ds_bpermute_b32 v10, v18, v3                               // 000000FB0190: DACC0000 0A000312
	ds_bpermute_b32 v14, v18, v7                               // 000000FB0198: DACC0000 0E000712
	ds_bpermute_b32 v17, v18, v2                               // 000000FB01A0: DACC0000 11000212
	s_waitcnt lgkmcnt(3)                                       // 000000FB01A8: BF89FC37
	v_add_f32_e32 v9, v9, v16                                  // 000000FB01AC: 06122109
	ds_bpermute_b32 v13, v18, v6                               // 000000FB01B0: DACC0000 0D000612
	s_waitcnt lgkmcnt(3)                                       // 000000FB01B8: BF89FC37
	v_add_f32_e32 v3, v3, v10                                  // 000000FB01BC: 06061503
	ds_bpermute_b32 v11, v18, v4                               // 000000FB01C0: DACC0000 0B000412
	s_waitcnt lgkmcnt(3)                                       // 000000FB01C8: BF89FC37
	v_add_f32_e32 v7, v7, v14                                  // 000000FB01CC: 060E1D07
	ds_bpermute_b32 v15, v18, v8                               // 000000FB01D0: DACC0000 0F000812
	v_xor_b32_e32 v18, 2, v1                                   // 000000FB01D8: 3A240282
	s_delay_alu instid0(VALU_DEP_1)                            // 000000FB01DC: BF870001
	v_cmp_gt_u32_e32 vcc_lo, 32, v18                           // 000000FB01E0: 7C9824A0
	s_waitcnt lgkmcnt(2)                                       // 000000FB01E4: BF89FC27
	v_add_f32_e32 v6, v6, v13                                  // 000000FB01E8: 060C1B06
	v_cndmask_b32_e32 v18, v1, v18, vcc_lo                     // 000000FB01EC: 02242501
	s_waitcnt lgkmcnt(1)                                       // 000000FB01F0: BF89FC17
	v_dual_add_f32 v4, v4, v11 :: v_dual_add_f32 v11, v2, v17  // 000000FB01F4: C9081704 040A2302
	s_delay_alu instid0(VALU_DEP_2)                            // 000000FB01FC: BF870002
	v_lshlrev_b32_e32 v18, 2, v18                              // 000000FB0200: 30242482
	ds_bpermute_b32 v14, v18, v7                               // 000000FB0204: DACC0000 0E000712
	s_waitcnt lgkmcnt(1)                                       // 000000FB020C: BF89FC17
	v_add_f32_e32 v8, v8, v15                                  // 000000FB0210: 06101F08
	ds_bpermute_b32 v2, v18, v3                                // 000000FB0214: DACC0000 02000312
	ds_bpermute_b32 v10, v18, v4                               // 000000FB021C: DACC0000 0A000412
	ds_bpermute_b32 v12, v18, v5                               // 000000FB0224: DACC0000 0C000512
	ds_bpermute_b32 v13, v18, v6                               // 000000FB022C: DACC0000 0D000612
	ds_bpermute_b32 v15, v18, v8                               // 000000FB0234: DACC0000 0F000812
	ds_bpermute_b32 v16, v18, v9                               // 000000FB023C: DACC0000 10000912
	ds_bpermute_b32 v17, v18, v11                              // 000000FB0244: DACC0000 11000B12
	v_xor_b32_e32 v18, 1, v1                                   // 000000FB024C: 3A240281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000FB0250: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v18                           // 000000FB0254: 7C9824A0
	v_cndmask_b32_e32 v1, v1, v18, vcc_lo                      // 000000FB0258: 02022501
	s_waitcnt lgkmcnt(6)                                       // 000000FB025C: BF89FC67
	v_dual_add_f32 v1, v3, v2 :: v_dual_lshlrev_b32 v18, 2, v1 // 000000FB0260: C9220503 01120282
	s_waitcnt lgkmcnt(5)                                       // 000000FB0268: BF89FC57
	v_add_f32_e32 v2, v4, v10                                  // 000000FB026C: 06041504
	s_waitcnt lgkmcnt(3)                                       // 000000FB0270: BF89FC37
	v_dual_add_f32 v4, v5, v12 :: v_dual_add_f32 v5, v6, v13   // 000000FB0274: C9081905 04041B06
	v_add_f32_e32 v3, v7, v14                                  // 000000FB027C: 06061D07
	s_waitcnt lgkmcnt(1)                                       // 000000FB0280: BF89FC17
	v_dual_add_f32 v7, v8, v15 :: v_dual_add_f32 v10, v9, v16  // 000000FB0284: C9081F08 070A2109
	s_waitcnt lgkmcnt(0)                                       // 000000FB028C: BF89FC07
	v_add_f32_e32 v12, v11, v17                                // 000000FB0290: 0618230B
	ds_bpermute_b32 v6, v18, v1                                // 000000FB0294: DACC0000 06000112
	ds_bpermute_b32 v8, v18, v2                                // 000000FB029C: DACC0000 08000212
	ds_bpermute_b32 v11, v18, v4                               // 000000FB02A4: DACC0000 0B000412
	ds_bpermute_b32 v13, v18, v5                               // 000000FB02AC: DACC0000 0D000512
	ds_bpermute_b32 v9, v18, v3                                // 000000FB02B4: DACC0000 09000312
	ds_bpermute_b32 v14, v18, v7                               // 000000FB02BC: DACC0000 0E000712
	ds_bpermute_b32 v15, v18, v10                              // 000000FB02C4: DACC0000 0F000A12
	ds_bpermute_b32 v16, v18, v12                              // 000000FB02CC: DACC0000 10000C12
	v_cmpx_eq_u32_e32 0, v30                                   // 000000FB02D4: 7D943C80
	s_cbranch_execz 16                                         // 000000FB02D8: BFA50010 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x121c>
	s_waitcnt lgkmcnt(2)                                       // 000000FB02DC: BF89FC27
	v_dual_add_f32 v14, v7, v14 :: v_dual_add_f32 v19, v4, v11 // 000000FB02E0: C9081D07 0E121704
	s_waitcnt vmcnt(0)                                         // 000000FB02E8: BF8903F7
	v_add_f32_e32 v20, v5, v13                                 // 000000FB02EC: 06281B05
	v_dual_add_f32 v18, v2, v8 :: v_dual_add_f32 v17, v1, v6   // 000000FB02F0: C9081102 12100D01
	s_waitcnt lgkmcnt(0)                                       // 000000FB02F8: BF89FC07
	v_dual_add_f32 v16, v12, v16 :: v_dual_lshlrev_b32 v1, 5, v29// 000000FB02FC: C922210C 10003A85
	v_add_f32_e32 v15, v10, v15                                // 000000FB0304: 061E1F0A
	v_add_f32_e32 v13, v3, v9                                  // 000000FB0308: 061A1303
	ds_store_b128 v1, v[17:20] offset:1024                     // 000000FB030C: DB7C0400 00001101
	ds_store_b128 v1, v[13:16] offset:1040                     // 000000FB0314: DB7C0410 00000D01
	s_or_b32 exec_lo, exec_lo, s0                              // 000000FB031C: 8C7E007E
	.long 0xd4510000                                           // 000000FB0320: D4510000
	v_cndmask_b32_e32 v0, s2, v12, vcc_lo                      // 000000FB0324: 02001802
	v_cmp_gt_u32_e32 vcc_lo, 8, v0                             // 000000FB0328: 7C980088
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000FB032C: BF890007
	s_barrier                                                  // 000000FB0330: BFBD0000
	buffer_gl0_inv                                             // 000000FB0334: E0AC0000 00000000
	s_and_b32 s0, vcc_lo, s0                                   // 000000FB033C: 8B00006A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000FB0340: BF870009
	s_and_saveexec_b32 s1, s0                                  // 000000FB0344: BE812000
	s_cbranch_execz 74                                         // 000000FB0348: BFA5004A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x1374>
	v_add_nc_u32_e32 v7, 0x400, v28                            // 000000FB034C: 4A0E38FF 00000400
	s_lshl_b64 s[0:1], s[2:3], 2                               // 000000FB0354: 84808202
	ds_load_2addr_b32 v[1:2], v7 offset1:8                     // 000000FB0358: D8DC0800 01000007
	ds_load_2addr_b32 v[3:4], v7 offset0:16 offset1:24         // 000000FB0360: D8DC1810 03000007
	ds_load_2addr_b32 v[5:6], v7 offset0:32 offset1:40         // 000000FB0368: D8DC2820 05000007
	s_waitcnt lgkmcnt(2)                                       // 000000FB0370: BF89FC27
	v_add_f32_e32 v1, 0, v1                                    // 000000FB0374: 06020280
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000FB0378: BF8700C1
	v_add_f32_e32 v8, v1, v2                                   // 000000FB037C: 06100501
	ds_load_2addr_b32 v[1:2], v7 offset0:48 offset1:56         // 000000FB0380: D8DC3830 01000007
	s_waitcnt lgkmcnt(2)                                       // 000000FB0388: BF89FC27
	v_add_f32_e32 v3, v8, v3                                   // 000000FB038C: 06060708
	v_add_f32_e32 v3, v3, v4                                   // 000000FB0390: 06060903
	s_waitcnt lgkmcnt(1)                                       // 000000FB0394: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FB0398: BF870091
	v_add_f32_e32 v3, v3, v5                                   // 000000FB039C: 06060B03
	v_add_f32_e32 v3, v3, v6                                   // 000000FB03A0: 06060D03
	s_waitcnt lgkmcnt(0)                                       // 000000FB03A4: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FB03A8: BF870091
	v_add_f32_e32 v1, v3, v1                                   // 000000FB03AC: 06020303
	v_add_f32_e32 v1, v1, v2                                   // 000000FB03B0: 06020501
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FB03B4: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v1                           // 000000FB03B8: 100202FF BFB8AA3B
	v_exp_f32_e32 v1, v1                                       // 000000FB03C0: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FB03C4: BF870095
	v_add_f32_e32 v4, 1.0, v1                                  // 000000FB03C8: 060802F2
	v_div_scale_f32 v5, null, v4, v4, 1.0                      // 000000FB03CC: D6FC7C05 03CA0904
	v_div_scale_f32 v7, vcc_lo, 1.0, v4, 1.0                   // 000000FB03D4: D6FC6A07 03CA08F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000FB03DC: BF870292
	v_rcp_f32_e32 v6, v5                                       // 000000FB03E0: 7E0C5505
	v_fma_f32 v1, -v5, v6, 1.0                                 // 000000FB03E4: D6130001 23CA0D05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000FB03EC: BF870121
	v_fmac_f32_e32 v6, v1, v6                                  // 000000FB03F0: 560C0D01
	v_mad_u64_u32 v[1:2], null, s12, v0, 0                     // 000000FB03F4: D6FE7C01 0202000C
	v_mul_f32_e32 v8, v7, v6                                   // 000000FB03FC: 10100D07
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000FB0400: BF870112
	v_mad_u64_u32 v[2:3], null, s13, v0, v[2:3]                // 000000FB0404: D6FE7C02 040A000D
	v_fma_f32 v9, -v5, v8, v7                                  // 000000FB040C: D6130009 241E1105
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000FB0414: BF870191
	v_fmac_f32_e32 v8, v9, v6                                  // 000000FB0418: 56100D09
	.long 0xd73c0000                                           // 000000FB041C: D73C0000
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 000000FB0420: 02020282
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FB0424: BF870092
	v_fma_f32 v3, -v5, v8, v7                                  // 000000FB0428: D6130003 241E1105
	v_div_fmas_f32 v2, v3, v6, v8                              // 000000FB0430: D6370002 04220D03
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FB0438: BF870093
	.long 0xd7006a00                                           // 000000FB043C: D7006A00
	v_cndmask_b32_e32 v1, s8, v0, vcc_lo                       // 000000FB0440: 02020008
	v_add_co_ci_u32_e64 v1, null, s9, v1, vcc_lo               // 000000FB0444: D5207C01 01AA0209
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000FB044C: BF870193
	v_div_fixup_f32 v2, v2, v4, 1.0                            // 000000FB0450: D6270002 03CA0902
	.long 0xd7006a00                                           // 000000FB0458: D7006A00
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 000000FB045C: 02000100
	s_delay_alu instid0(VALU_DEP_1)                            // 000000FB0460: BF870001
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 000000FB0464: D5207C01 01AA0201
	global_store_b32 v[0:1], v2, off                           // 000000FB046C: DC6A0000 007C0200
	s_endpgm                                                   // 000000FB0474: BFB00000
		...

