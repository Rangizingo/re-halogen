000000000022de00 <_ZN7halogen12_GLOBAL__N_116k_ht_rot_out_f32EPKfPKDF16_Ptii>:
; _ZN7halogen12_GLOBAL__N_116k_ht_rot_out_f32EPKfPKDF16_Ptii():
	s_load_b64 s[8:9], s[0:1], 0x18                            // 00000022DE00: F4040200 F8000018
	s_mov_b32 s3, 0                                            // 00000022DE08: BE830080
	v_lshrrev_b32_e32 v1, 5, v0                                // 00000022DE0C: 32020085
	s_lshl_b64 s[2:3], s[2:3], 3                               // 00000022DE10: 84828302
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000022DE14: BF870119
	v_mov_b32_e32 v2, s3                                       // 00000022DE18: 7E040203
	v_or_b32_e32 v1, s2, v1                                    // 00000022DE1C: 38020202
	s_mov_b32 s2, exec_lo                                      // 00000022DE20: BE82007E
	s_waitcnt lgkmcnt(0)                                       // 00000022DE24: BF89FC07
	s_ashr_i32 s10, s9, 31                                     // 00000022DE28: 860A9F09
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000022DE2C: BF870499
	s_lshr_b32 s4, s10, 25                                     // 00000022DE30: 8504990A
	s_add_i32 s3, s9, s4                                       // 00000022DE34: 81030409
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000022DE38: BF870499
	s_ashr_i32 s3, s3, 7                                       // 00000022DE3C: 86038703
	s_mul_hi_i32 s5, s3, s8                                    // 00000022DE40: 97050803
	s_mul_i32 s4, s3, s8                                       // 00000022DE44: 96040803
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000022DE48: BF870009
	.long 0xd4d4007e                                           // 00000022DE4C: D4D4007E
	v_cndmask_b32_e32 v1, s4, v1, vcc_lo                       // 00000022DE50: 02020204
	s_cbranch_execz 457                                        // 00000022DE54: BFA501C9 <_ZN7halogen12_GLOBAL__N_116k_ht_rot_out_f32EPKfPKDF16_Ptii+0x77c>
	s_ashr_i32 s2, s3, 31                                      // 00000022DE58: 86029F03
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000022DE5C: BF870099
	v_or_b32_e32 v3, s2, v2                                    // 00000022DE60: 38060402
	v_cmp_ne_u32_e32 vcc_lo, 0, v3                             // 00000022DE64: 7C9A0680
	s_and_saveexec_b32 s4, vcc_lo                              // 00000022DE68: BE84206A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000022DE6C: BF870009
	s_xor_b32 s8, exec_lo, s4                                  // 00000022DE70: 8D08047E
	s_cbranch_execz 170                                        // 00000022DE74: BFA500AA <_ZN7halogen12_GLOBAL__N_116k_ht_rot_out_f32EPKfPKDF16_Ptii+0x320>
	s_ashr_i32 s4, s2, 31                                      // 00000022DE78: 86049F02
	v_ashrrev_i32_e32 v8, 31, v2                               // 00000022DE7C: 3410049F
	s_add_u32 s6, s3, s4                                       // 00000022DE80: 80060403
	s_mov_b32 s5, s4                                           // 00000022DE84: BE850004
	s_addc_u32 s7, s2, s4                                      // 00000022DE88: 82070402
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000022DE8C: BF870499
	s_xor_b64 s[6:7], s[6:7], s[4:5]                           // 00000022DE90: 8D860406
	s_cvt_f32_u32 s2, s6                                       // 00000022DE94: BE826506
	s_cvt_f32_u32 s5, s7                                       // 00000022DE98: BE856507
	s_sub_u32 s11, 0, s6                                       // 00000022DE9C: 808B0680
	s_subb_u32 s12, 0, s7                                      // 00000022DEA0: 828C0780
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_3)// 00000022DEA4: BF870599
	s_fmamk_f32 s2, s5, 0x4f800000, s2                         // 00000022DEA8: A3020205 4F800000
	v_rcp_f32_e32 v3, s2                                       // 00000022DEB0: 7E065402
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000022DEB4: BF8700A5
	v_readfirstlane_b32 s2, v3                                 // 00000022DEB8: 7E040503
	.long 0xd7006a03                                           // 00000022DEBC: D7006A03
	v_cndmask_b32_e32 v1, v1, v8, vcc_lo                       // 00000022DEC0: 02021101
	v_add_co_ci_u32_e64 v2, null, v2, v8, vcc_lo               // 00000022DEC4: D5207C02 01AA1102
	s_mul_f32 s2, s2, 0x5f7ffffc                               // 00000022DECC: A202FF02 5F7FFFFC
	v_xor_b32_e32 v10, v3, v8                                  // 00000022DED4: 3A141103
	v_xor_b32_e32 v9, v2, v8                                   // 00000022DED8: 3A121102
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_3)// 00000022DEDC: BF870599
	s_mul_f32 s5, s2, 0x2f800000                               // 00000022DEE0: A205FF02 2F800000
	s_trunc_f32 s5, s5                                         // 00000022DEE8: BE856205
	s_delay_alu instid0(SALU_CYCLE_3) | instskip(SKIP_1) | instid1(SALU_CYCLE_2)// 00000022DEEC: BF87052B
	s_fmamk_f32 s2, s5, 0xcf800000, s2                         // 00000022DEF0: A3020205 CF800000
	s_cvt_u32_f32 s5, s5                                       // 00000022DEF8: BE856705
	s_cvt_u32_f32 s2, s2                                       // 00000022DEFC: BE826702
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(NEXT) | instid1(SALU_CYCLE_2)// 00000022DF00: BF87051A
	s_mul_i32 s13, s11, s5                                     // 00000022DF04: 960D050B
	s_mul_hi_u32 s15, s11, s2                                  // 00000022DF08: 968F020B
	s_mul_i32 s14, s12, s2                                     // 00000022DF0C: 960E020C
	s_add_i32 s13, s15, s13                                    // 00000022DF10: 810D0D0F
	s_mul_i32 s16, s11, s2                                     // 00000022DF14: 9610020B
	s_add_i32 s13, s13, s14                                    // 00000022DF18: 810D0E0D
	s_mul_hi_u32 s15, s2, s16                                  // 00000022DF1C: 968F1002
	s_mul_i32 s18, s2, s13                                     // 00000022DF20: 96120D02
	s_mul_hi_u32 s17, s5, s16                                  // 00000022DF24: 96911005
	s_mul_i32 s14, s5, s16                                     // 00000022DF28: 960E1005
	s_mul_hi_u32 s16, s2, s13                                  // 00000022DF2C: 96900D02
	s_add_u32 s15, s15, s18                                    // 00000022DF30: 800F120F
	s_addc_u32 s16, 0, s16                                     // 00000022DF34: 82101080
	s_mul_hi_u32 s19, s5, s13                                  // 00000022DF38: 96930D05
	s_add_u32 s14, s15, s14                                    // 00000022DF3C: 800E0E0F
	s_mul_i32 s13, s5, s13                                     // 00000022DF40: 960D0D05
	s_addc_u32 s14, s16, s17                                   // 00000022DF44: 820E1110
	s_addc_u32 s15, s19, 0                                     // 00000022DF48: 820F8013
	s_add_u32 s13, s14, s13                                    // 00000022DF4C: 800D0D0E
	s_addc_u32 s14, 0, s15                                     // 00000022DF50: 820E0F80
	s_add_u32 s2, s2, s13                                      // 00000022DF54: 80020D02
	s_addc_u32 s5, s5, s14                                     // 00000022DF58: 82050E05
	s_mul_hi_u32 s13, s11, s2                                  // 00000022DF5C: 968D020B
	s_mul_i32 s14, s11, s2                                     // 00000022DF60: 960E020B
	s_mul_i32 s11, s11, s5                                     // 00000022DF64: 960B050B
	s_mul_i32 s12, s12, s2                                     // 00000022DF68: 960C020C
	s_add_i32 s11, s13, s11                                    // 00000022DF6C: 810B0B0D
	s_mul_i32 s13, s5, s14                                     // 00000022DF70: 960D0E05
	s_add_i32 s11, s11, s12                                    // 00000022DF74: 810B0C0B
	s_mul_hi_u32 s12, s2, s14                                  // 00000022DF78: 968C0E02
	s_mul_i32 s17, s2, s11                                     // 00000022DF7C: 96110B02
	s_mul_hi_u32 s16, s2, s11                                  // 00000022DF80: 96900B02
	s_add_u32 s12, s12, s17                                    // 00000022DF84: 800C110C
	s_mul_hi_u32 s15, s5, s14                                  // 00000022DF88: 968F0E05
	s_addc_u32 s16, 0, s16                                     // 00000022DF8C: 82101080
	s_mul_hi_u32 s14, s5, s11                                  // 00000022DF90: 968E0B05
	s_add_u32 s12, s12, s13                                    // 00000022DF94: 800C0D0C
	s_mul_i32 s11, s5, s11                                     // 00000022DF98: 960B0B05
	s_addc_u32 s12, s16, s15                                   // 00000022DF9C: 820C0F10
	s_addc_u32 s13, s14, 0                                     // 00000022DFA0: 820D800E
	s_add_u32 s11, s12, s11                                    // 00000022DFA4: 800B0B0C
	s_addc_u32 s12, 0, s13                                     // 00000022DFA8: 820C0D80
	s_add_u32 s2, s2, s11                                      // 00000022DFAC: 80020B02
	s_addc_u32 s5, s5, s12                                     // 00000022DFB0: 82050C05
	.long 0xd72d000b                                           // 00000022DFB4: D72D000B
	v_cndmask_b32_e32 v0, v10, v2, vcc_lo                      // 00000022DFB8: 0200050A
	v_mad_u64_u32 v[2:3], null, v10, s5, 0                     // 00000022DFBC: D6FE7C02 02000B0A
	v_mad_u64_u32 v[4:5], null, v9, s2, 0                      // 00000022DFC4: D6FE7C04 02000509
	v_mad_u64_u32 v[6:7], null, v9, s5, 0                      // 00000022DFCC: D6FE7C06 02000B09
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000022DFD4: BF870093
	.long 0xd7006a02                                           // 00000022DFD8: D7006A02
	v_cndmask_b32_e32 v1, v11, v2, vcc_lo                      // 00000022DFDC: 0202050B
	v_add_co_ci_u32_e64 v3, null, 0, v3, vcc_lo                // 00000022DFE0: D5207C03 01AA0680
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000022DFE8: BF870112
	.long 0xd7006a02                                           // 00000022DFEC: D7006A02
	v_cndmask_b32_e32 v1, v2, v4, vcc_lo                       // 00000022DFF0: 02020902
	v_add_co_ci_u32_e32 v2, vcc_lo, v3, v5, vcc_lo             // 00000022DFF4: 40040B03
	v_add_co_ci_u32_e32 v3, vcc_lo, 0, v7, vcc_lo              // 00000022DFF8: 40060E80
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000022DFFC: BF870092
	.long 0xd7006a04                                           // 00000022E000: D7006A04
	v_cndmask_b32_e32 v1, v2, v6, vcc_lo                       // 00000022E004: 02020D02
	v_add_co_ci_u32_e64 v5, null, 0, v3, vcc_lo                // 00000022E008: D5207C05 01AA0680
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000022E010: BF8701A2
	.long 0xd72c0006                                           // 00000022E014: D72C0006
	v_cndmask_b32_e32 v1, s7, v4, vcc_lo                       // 00000022E018: 02020807
	v_mad_u64_u32 v[2:3], null, s6, v4, 0                      // 00000022E01C: D6FE7C02 02020806
	.long 0xd72c0007                                           // 00000022E024: D72C0007
	v_cndmask_b32_e32 v1, s6, v5, vcc_lo                       // 00000022E028: 02020A06
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000022E02C: BF870112
	.long 0xd7016a02                                           // 00000022E030: D7016A02
	v_cndmask_b32_e32 v1, v10, v2, vcc_lo                      // 00000022E034: 0202050A
	v_add3_u32 v3, v3, v7, v6                                  // 00000022E038: D6550003 041A0F03
	.long 0xd7000207                                           // 00000022E040: D7000207
	v_cndmask_b32_e32 v0, v4, v130, vcc_lo                     // 00000022E044: 02010504
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000022E048: BF870191
	v_add_co_ci_u32_e64 v10, null, 0, v5, s2                   // 00000022E04C: D5207C0A 000A0A80
	v_sub_nc_u32_e32 v6, v9, v3                                // 00000022E054: 4C0C0709
	.long 0xd701020b                                           // 00000022E058: D701020B
	v_cndmask_b32_e32 v0, v2, v6, vcc_lo                       // 00000022E05C: 02000D02
	v_sub_co_ci_u32_e64 v3, null, v9, v3, vcc_lo               // 00000022E060: D5217C03 01AA0709
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000022E068: BF870193
	v_subrev_co_ci_u32_e64 v6, null, s7, v6, vcc_lo            // 00000022E06C: D5227C06 01AA0C07
	v_cmp_le_u32_e32 vcc_lo, s6, v11                           // 00000022E074: 7C961606
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000022E078: BF870122
	v_subrev_co_ci_u32_e64 v6, null, 0, v6, s2                 // 00000022E07C: D5227C06 000A0C80
	v_cndmask_b32_e64 v9, 0, -1, vcc_lo                        // 00000022E084: D5010009 01A98280
	v_cmp_le_u32_e32 vcc_lo, s7, v6                            // 00000022E08C: 7C960C07
	v_cndmask_b32_e64 v11, 0, -1, vcc_lo                       // 00000022E090: D501000B 01A98280
	v_cmp_le_u32_e32 vcc_lo, s6, v2                            // 00000022E098: 7C960406
	v_cndmask_b32_e64 v2, 0, -1, vcc_lo                        // 00000022E09C: D5010002 01A98280
	v_cmp_le_u32_e32 vcc_lo, s7, v3                            // 00000022E0A4: 7C960607
	v_cndmask_b32_e64 v12, 0, -1, vcc_lo                       // 00000022E0A8: D501000C 01A98280
	v_cmp_eq_u32_e32 vcc_lo, s7, v6                            // 00000022E0B0: 7C940C07
	v_cndmask_b32_e32 v6, v11, v9, vcc_lo                      // 00000022E0B4: 020C130B
	.long 0xd7006a09                                           // 00000022E0B8: D7006A09
	v_cndmask_b32_e32 v0, v4, v129, vcc_lo                     // 00000022E0BC: 02010304
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_3)// 00000022E0C0: BF8701D1
	v_add_co_ci_u32_e64 v11, null, 0, v5, vcc_lo               // 00000022E0C4: D5207C0B 01AA0A80
	v_cmp_eq_u32_e32 vcc_lo, s7, v3                            // 00000022E0CC: 7C940607
	v_cndmask_b32_e32 v2, v12, v2, vcc_lo                      // 00000022E0D0: 0204050C
	v_cmp_ne_u32_e32 vcc_lo, 0, v6                             // 00000022E0D4: 7C9A0C80
	v_xor_b32_e32 v6, s4, v8                                   // 00000022E0D8: 3A0C1004
	.long 0xd44d0002                                           // 00000022E0DC: D44D0002
	v_cndmask_b32_e32 v1, 0, v2, vcc_lo                        // 00000022E0E0: 02020480
	v_dual_cndmask_b32 v3, v11, v10 :: v_dual_cndmask_b32 v2, v9, v7// 00000022E0E4: CA52150B 03020F09
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000022E0EC: BF870111
	v_cndmask_b32_e64 v3, v5, v3, s2                           // 00000022E0F0: D5010003 000A0705
	v_cndmask_b32_e64 v2, v4, v2, s2                           // 00000022E0F8: D5010002 000A0504
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000022E100: BF870112
	v_xor_b32_e32 v4, v3, v6                                   // 00000022E104: 3A080D03
	v_xor_b32_e32 v2, v2, v6                                   // 00000022E108: 3A040D02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000022E10C: BF870091
	.long 0xd7016a03                                           // 00000022E110: D7016A03
	v_cndmask_b32_e32 v1, v2, v6, vcc_lo                       // 00000022E114: 02020D02
	v_sub_co_ci_u32_e64 v4, null, v4, v6, vcc_lo               // 00000022E118: D5217C04 01AA0D04
	s_and_not1_saveexec_b32 s2, s8                             // 00000022E120: BE823008
	s_cbranch_execz 32                                         // 00000022E124: BFA50020 <_ZN7halogen12_GLOBAL__N_116k_ht_rot_out_f32EPKfPKDF16_Ptii+0x3a8>
	v_cvt_f32_u32_e32 v2, s3                                   // 00000022E128: 7E040C03
	s_sub_i32 s4, 0, s3                                        // 00000022E12C: 81840380
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000022E130: BF870291
	v_rcp_iflag_f32_e32 v2, v2                                 // 00000022E134: 7E045702
	v_mul_f32_e32 v2, 0x4f7ffffe, v2                           // 00000022E138: 100404FF 4F7FFFFE
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000022E140: BF870091
	v_cvt_u32_f32_e32 v2, v2                                   // 00000022E144: 7E040F02
	.long 0xd72c0003                                           // 00000022E148: D72C0003
	v_cndmask_b32_e32 v1, s4, v2, vcc_lo                       // 00000022E14C: 02020404
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000022E150: BF870091
	.long 0xd72d0003                                           // 00000022E154: D72D0003
	v_cndmask_b32_e32 v1, v2, v3, vcc_lo                       // 00000022E158: 02020702
	v_add_nc_u32_e32 v2, v2, v3                                // 00000022E15C: 4A040702
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000022E160: BF870091
	.long 0xd72d0002                                           // 00000022E164: D72D0002
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 00000022E168: 02020501
	.long 0xd72c0003                                           // 00000022E16C: D72C0003
	v_cndmask_b32_e32 v0, v2, v3, vcc_lo                       // 00000022E170: 02000702
	v_add_nc_u32_e32 v4, 1, v2                                 // 00000022E174: 4A080481
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000022E178: BF870092
	v_sub_nc_u32_e32 v3, v1, v3                                // 00000022E17C: 4C060701
	v_subrev_nc_u32_e32 v5, s3, v3                             // 00000022E180: 4E0A0603
	v_cmp_le_u32_e32 vcc_lo, s3, v3                            // 00000022E184: 7C960603
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000022E188: BF870092
	v_dual_cndmask_b32 v3, v3, v5 :: v_dual_cndmask_b32 v2, v2, v4// 00000022E18C: CA520B03 03020902
	v_cmp_le_u32_e32 vcc_lo, s3, v3                            // 00000022E194: 7C960603
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000022E198: BF870092
	v_add_nc_u32_e32 v4, 1, v2                                 // 00000022E19C: 4A080481
	v_dual_cndmask_b32 v3, v2, v4 :: v_dual_mov_b32 v4, 0      // 00000022E1A0: CA500902 03040080
	s_or_b32 exec_lo, exec_lo, s2                              // 00000022E1A8: 8C7E027E
	s_load_b128 s[4:7], s[0:1], null                           // 00000022E1AC: F4080100 F8000000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000022E1B4: BF870111
	.long 0xd72c0002                                           // 00000022E1B8: D72C0002
	v_cndmask_b32_e32 v0, v3, v3, vcc_lo                       // 00000022E1BC: 02000703
	.long 0xd72c0004                                           // 00000022E1C0: D72C0004
	v_cndmask_b32_e32 v0, v4, v9, vcc_lo                       // 00000022E1C4: 02001304
	.long 0xd72c0007                                           // 00000022E1C8: D72C0007
	v_cndmask_b32_e32 v0, v3, v10, vcc_lo                      // 00000022E1CC: 02001503
	v_mad_u64_u32 v[5:6], null, v3, s9, 0                      // 00000022E1D0: D6FE7C05 02001303
	v_dual_mov_b32 v8, 0 :: v_dual_and_b32 v11, 31, v0         // 00000022E1D8: CA240080 080A009F
	s_mov_b32 s2, 0x76543210                                   // 00000022E1E0: BE8200FF 76543210
	s_load_b64 s[0:1], s[0:1], 0x10                            // 00000022E1E8: F4040000 F8000010
	v_sub_nc_u32_e32 v1, v1, v2                                // 00000022E1F0: 4C020501
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000022E1F4: BF870212
	v_lshlrev_b32_e32 v3, 2, v11                               // 00000022E1F8: 30061682
	v_add3_u32 v6, v6, v7, v4                                  // 00000022E1FC: D6550006 04120F06
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000022E204: BF870112
	v_lshl_or_b32 v7, v1, 7, v3                                // 00000022E208: D6560007 040D0F01
	.long 0xd73c0001                                           // 00000022E210: D73C0001
	v_cndmask_b32_e32 v1, 2, v5, vcc_lo                        // 00000022E214: 02020A82
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000022E218: BF8701B2
	.long 0xd73c0003                                           // 00000022E21C: D73C0003
	v_cndmask_b32_e32 v1, 2, v7, vcc_lo                        // 00000022E220: 02020E82
	.long 0xd73c0007                                           // 00000022E224: D73C0007
	v_cndmask_b32_e32 v1, 1, v7, vcc_lo                        // 00000022E228: 02020E81
	s_waitcnt lgkmcnt(0)                                       // 00000022E22C: BF89FC07
	.long 0xd7006a01                                           // 00000022E230: D7006A01
	v_cndmask_b32_e32 v1, s4, v1, vcc_lo                       // 00000022E234: 02020204
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000022E238: BF870111
	v_add_co_ci_u32_e64 v2, null, s5, v2, vcc_lo               // 00000022E23C: D5207C02 01AA0405
	.long 0xd7006a01                                           // 00000022E244: D7006A01
	v_cndmask_b32_e32 v1, v1, v3, vcc_lo                       // 00000022E248: 02020701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000022E24C: BF8700A1
	v_add_co_ci_u32_e64 v2, null, v2, v4, vcc_lo               // 00000022E250: D5207C02 01AA0902
	.long 0xd7006a09                                           // 00000022E258: D7006A09
	v_cndmask_b32_e32 v1, s6, v7, vcc_lo                       // 00000022E25C: 02020E06
	v_add_co_ci_u32_e64 v10, null, s7, v8, vcc_lo              // 00000022E260: D5207C0A 01AA1007
	global_load_b128 v[1:4], v[1:2], off                       // 00000022E268: DC5E0000 017C0001
	v_and_b32_e32 v12, 1, v0                                   // 00000022E270: 36180081
	global_load_b64 v[9:10], v[9:10], off                      // 00000022E274: DC560000 097C0009
	s_waitcnt vmcnt(1)                                         // 00000022E27C: BF8907F7
	v_add_f32_e32 v14, v1, v2                                  // 00000022E280: 061C0501
	v_dual_sub_f32 v1, v1, v2 :: v_dual_add_f32 v2, v3, v4     // 00000022E284: C9480501 01020903
	v_sub_f32_e32 v3, v3, v4                                   // 00000022E28C: 08060903
	v_and_b32_e32 v13, 2, v0                                   // 00000022E290: 361A0082
	v_cmp_eq_u32_e32 vcc_lo, 0, v12                            // 00000022E294: 7C941880
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 00000022E298: BF870243
	v_add_f32_e32 v16, v1, v3                                  // 00000022E29C: 06200701
	v_dual_sub_f32 v1, v1, v3 :: v_dual_and_b32 v4, 4, v0      // 00000022E2A0: C9640701 01040084
	v_add_f32_e32 v15, v14, v2                                 // 00000022E2A8: 061E050E
	v_sub_f32_e32 v2, v14, v2                                  // 00000022E2AC: 0804050E
	v_mov_b32_dpp v14, v16 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000022E2B0: 7E1C02FA FF016110
	s_delay_alu instid0(VALU_DEP_4)                            // 00000022E2B8: BF870004
	v_mov_b32_dpp v17, v1 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000022E2BC: 7E2202FA FF016101
	v_cndmask_b32_e64 v1, -v1, v1, vcc_lo                      // 00000022E2C4: D5010001 21AA0301
	v_mov_b32_dpp v3, v15 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000022E2CC: 7E0602FA FF01610F
	v_cndmask_b32_e64 v12, -v15, v15, vcc_lo                   // 00000022E2D4: D501000C 21AA1F0F
	v_cndmask_b32_e64 v15, -v16, v16, vcc_lo                   // 00000022E2DC: D501000F 21AA2110
	v_and_b32_e32 v0, 8, v0                                    // 00000022E2E4: 36000088
	v_mov_b32_dpp v16, v2 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000022E2E8: 7E2002FA FF016102
	v_cndmask_b32_e64 v2, -v2, v2, vcc_lo                      // 00000022E2F0: D5010002 21AA0502
	v_add_f32_e32 v3, v12, v3                                  // 00000022E2F8: 0606070C
	v_cmp_eq_u32_e32 vcc_lo, 0, v13                            // 00000022E2FC: 7C941A80
	v_dual_add_f32 v12, v15, v14 :: v_dual_add_f32 v1, v1, v17 // 00000022E300: C9081D0F 0C002301
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000022E308: BF870233
	v_mov_b32_dpp v13, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000022E30C: 7E1A02FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 00000022E314: D5010003 21AA0703
	v_add_f32_e32 v2, v2, v16                                  // 00000022E31C: 06042102
	v_mov_b32_dpp v14, v12 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000022E320: 7E1C02FA FF01620C
	v_cndmask_b32_e64 v12, -v12, v12, vcc_lo                   // 00000022E328: D501000C 21AA190C
	v_mov_b32_dpp v16, v1 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000022E330: 7E2002FA FF016201
	v_cndmask_b32_e64 v1, -v1, v1, vcc_lo                      // 00000022E338: D5010001 21AA0301
	v_add_f32_e32 v3, v3, v13                                  // 00000022E340: 06061B03
	v_mov_b32_dpp v15, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000022E344: 7E1E02FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, vcc_lo                      // 00000022E34C: D5010002 21AA0502
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000022E354: BF8701B4
	v_dual_add_f32 v12, v12, v14 :: v_dual_add_f32 v1, v1, v16 // 00000022E358: C9081D0C 0C002101
	v_cmp_eq_u32_e32 vcc_lo, 0, v4                             // 00000022E360: 7C940880
	v_mov_b32_dpp v4, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000022E364: 7E0802FA FF016403
	v_mov_b32_dpp v13, v12 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000022E36C: 7E1A02FA FF01640C
	v_cndmask_b32_e64 v12, -v12, v12, vcc_lo                   // 00000022E374: D501000C 21AA190C
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 00000022E37C: D5010003 21AA0703
	v_add_f32_e32 v2, v2, v15                                  // 00000022E384: 06041F02
	v_mov_b32_dpp v15, v1 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000022E388: 7E1E02FA FF016401
	v_cndmask_b32_e64 v1, -v1, v1, vcc_lo                      // 00000022E390: D5010001 21AA0301
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000022E398: BF870214
	v_add_f32_e32 v3, v3, v4                                   // 00000022E39C: 06060903
	v_mov_b32_dpp v14, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000022E3A0: 7E1C02FA FF016402
	v_cndmask_b32_e64 v2, -v2, v2, vcc_lo                      // 00000022E3A8: D5010002 21AA0502
	v_add_f32_e32 v4, v12, v13                                 // 00000022E3B0: 06081B0C
	v_cmp_eq_u32_e32 vcc_lo, 0, v0                             // 00000022E3B4: 7C940080
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000022E3B8: BF870223
	v_dual_add_f32 v0, v1, v15 :: v_dual_add_f32 v1, v2, v14   // 00000022E3BC: C9081F01 00001D02
	v_mov_b32_dpp v2, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000022E3C4: 7E0402FA FF016803
	v_mov_b32_dpp v12, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000022E3CC: 7E1802FA FF016804
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 00000022E3D4: D5010004 21AA0904
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 00000022E3DC: D5010003 21AA0703
	v_mov_b32_dpp v13, v1 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000022E3E4: 7E1A02FA FF016801
	v_cndmask_b32_e64 v1, -v1, v1, vcc_lo                      // 00000022E3EC: D5010001 21AA0301
	s_delay_alu instid0(VALU_DEP_3)                            // 00000022E3F4: BF870003
	v_dual_add_f32 v2, v3, v2 :: v_dual_add_f32 v3, v4, v12    // 00000022E3F8: C9080503 02021904
	v_mov_b32_dpp v14, v0 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000022E400: 7E1C02FA FF016800
	v_cndmask_b32_e64 v0, -v0, v0, vcc_lo                      // 00000022E408: D5010000 21AA0100
	v_cmp_gt_u32_e32 vcc_lo, 16, v11                           // 00000022E410: 7C981690
	v_add_f32_e32 v1, v1, v13                                  // 00000022E414: 06021B01
	v_cndmask_b32_e64 v11, -v3, v3, vcc_lo                     // 00000022E418: D501000B 21AA0703
	v_permlanex16_b32 v3, v3, s2, 0xfedcba98                   // 00000022E420: D65C0003 03FC0503 FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000022E42C: BF870091
	v_dual_add_f32 v0, v0, v14 :: v_dual_add_f32 v3, v11, v3   // 00000022E430: C9081D00 0002070B
	v_dual_mov_b32 v4, v2 :: v_dual_mov_b32 v13, v0            // 00000022E438: CA100102 040C0100
	v_mov_b32_e32 v12, v1                                      // 00000022E440: 7E180301
	v_cndmask_b32_e64 v2, -v2, v2, vcc_lo                      // 00000022E444: D5010002 21AA0502
	v_cndmask_b32_e64 v1, -v1, v1, vcc_lo                      // 00000022E44C: D5010001 21AA0301
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_3)// 00000022E454: BF8701D4
	v_permlanex16_b32 v4, v4, s2, 0xfedcba98                   // 00000022E458: D65C0004 03FC0504 FEDCBA98
	v_cndmask_b32_e64 v0, -v0, v0, vcc_lo                      // 00000022E464: D5010000 21AA0100
	v_permlanex16_b32 v13, v13, s2, 0xfedcba98                 // 00000022E46C: D65C000D 03FC050D FEDCBA98
	v_mul_f32_e32 v3, 0x3db504f3, v3                           // 00000022E478: 100606FF 3DB504F3
	v_permlanex16_b32 v12, v12, s2, 0xfedcba98                 // 00000022E480: D65C000C 03FC050C FEDCBA98
	v_add_f32_e32 v0, v0, v13                                  // 00000022E48C: 06001B00
	s_waitcnt vmcnt(0)                                         // 00000022E490: BF8903F7
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000022E494: BF870193
	v_fma_mix_f32 v3, v9, v3, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 00000022E498: CC200803 8A020709
	v_add_f32_e32 v1, v1, v12                                  // 00000022E4A0: 06021901
	v_add_f32_e32 v2, v2, v4                                   // 00000022E4A4: 06040902
	.long 0x7f083880                                           // 00000022E4A8: 7F083880
	v_mul_f32_e32 v0, 0x3db504f3, v0                           // 00000022E4AC: 100000FF 3DB504F3
	.long 0x7e083983                                           // 00000022E4B4: 7E083983
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000022E4B8: BF870214
	v_dual_mul_f32 v1, 0x3db504f3, v1 :: v_dual_mul_f32 v2, 0x3db504f3, v2// 00000022E4BC: C8C602FF 010204FF 3DB504F3
	.long 0x7f163984                                           // 00000022E4C8: 7F163984
	.long 0x7f183984                                           // 00000022E4CC: 7F183984
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000022E4D0: BF870213
	v_fma_mix_f32 v2, v9, v2, neg(0) op_sel_hi:[1,0,0]         // 00000022E4D4: CC200002 8A020509
	v_fma_mix_f32 v9, v10, v1, neg(0) op_sel_hi:[1,0,0]        // 00000022E4DC: CC200009 8A02030A
	v_fma_mix_f32 v10, v10, v0, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 00000022E4E4: CC20080A 8A02010A
	.long 0xd73c0000                                           // 00000022E4EC: D73C0000
	v_cndmask_b32_e32 v1, 1, v5, vcc_lo                        // 00000022E4F0: 02020A81
	v_and_b32_e32 v5, 1, v4                                    // 00000022E4F4: 360A0881
	.long 0x7e163982                                           // 00000022E4F8: 7E163982
	.long 0x7e183989                                           // 00000022E4FC: 7E183989
	.long 0x7e08398a                                           // 00000022E500: 7E08398A
	.long 0xd7006a00                                           // 00000022E504: D7006A00
	v_cndmask_b32_e32 v1, s0, v0, vcc_lo                       // 00000022E508: 02020000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000022E50C: BF870214
	v_and_b32_e32 v6, 1, v11                                   // 00000022E510: 360C1681
	v_and_b32_e32 v11, 1, v12                                  // 00000022E514: 36161881
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000022E518: BF870224
	v_and_b32_e32 v4, 1, v4                                    // 00000022E51C: 36080881
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 00000022E520: D5207C01 01AA0201
	v_add3_u32 v6, v2, v6, 0x7fff                              // 00000022E528: D6550006 03FE0D02 00007FFF
	s_delay_alu instid0(VALU_DEP_4)                            // 00000022E534: BF870004
	v_add3_u32 v9, v9, v11, 0x7fff                             // 00000022E538: D6550009 03FE1709 00007FFF
	.long 0xd7006a00                                           // 00000022E544: D7006A00
	v_cndmask_b32_e32 v1, v0, v7, vcc_lo                       // 00000022E548: 02020F00
	v_add3_u32 v2, v3, v5, 0x7fff                              // 00000022E54C: D6550002 03FE0B03 00007FFF
	v_add3_u32 v3, v10, v4, 0x7fff                             // 00000022E558: D6550003 03FE090A 00007FFF
	v_add_co_ci_u32_e64 v1, null, v1, v8, vcc_lo               // 00000022E564: D5207C01 01AA1101
	.long 0x7e063989                                           // 00000022E56C: 7E063989
	.long 0x7e043986                                           // 00000022E570: 7E043986
	global_store_b64 v[0:1], v[2:3], off                       // 00000022E574: DC6E0000 007C0200
	s_endpgm                                                   // 00000022E57C: BFB00000
		...

