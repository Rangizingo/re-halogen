0000000000286d00 <_ZN7halogen12_GLOBAL__N_19k_deq_affILi4ELb0EEEvPKhPtNS0_6AffDevEjjl>:
; _ZN7halogen12_GLOBAL__N_19k_deq_affILi4ELb0EEEvPKhPtNS0_6AffDevEjjl():
	s_load_b64 s[12:13], s[0:1], 0x40                          // 000000286D00: F4040300 F8000040
	v_lshl_or_b32 v2, s2, 8, v0                                // 000000286D08: D6560002 04011002
	s_mov_b32 s2, exec_lo                                      // 000000286D10: BE82007E
	s_waitcnt lgkmcnt(0)                                       // 000000286D14: BF89FC07
	s_delay_alu instid0(VALU_DEP_1)                            // 000000286D18: BF870001
	.long 0xd4cc007e                                           // 000000286D1C: D4CC007E
	v_cndmask_b32_e32 v1, s13, v2, vcc_lo                      // 000000286D20: 0202040D
	s_cbranch_execz 498                                        // 000000286D24: BFA501F2 <_ZN7halogen12_GLOBAL__N_19k_deq_affILi4ELb0EEEvPKhPtNS0_6AffDevEjjl+0x7f0>
	s_clause 0x2                                               // 000000286D28: BF850002
	s_load_b128 s[4:7], s[0:1], null                           // 000000286D2C: F4080100 F8000000
	s_load_b64 s[14:15], s[0:1], 0x10                          // 000000286D34: F4040380 F8000010
	s_load_b64 s[2:3], s[0:1], 0x48                            // 000000286D3C: F4040080 F8000048
	s_cvt_f32_u32 s8, s12                                      // 000000286D44: BE88650C
	s_load_b32 s18, s[0:1], 0x50                               // 000000286D48: F4000480 F8000050
	v_mov_b32_e32 v1, 0                                        // 000000286D50: 7E020280
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(TRANS32_DEP_1)// 000000286D54: BF8702A9
	v_rcp_iflag_f32_e32 v0, s8                                 // 000000286D58: 7E005608
	s_load_b128 s[8:11], s[0:1], 0x20                          // 000000286D5C: F4080200 F8000020
	v_readfirstlane_b32 s16, v0                                // 000000286D64: 7E200500
	s_waitcnt lgkmcnt(0)                                       // 000000286D68: BF89FC07
	s_add_u32 s14, s4, s14                                     // 000000286D6C: 800E0E04
	s_addc_u32 s15, s5, s15                                    // 000000286D70: 820F0F05
	s_lshr_b32 s0, s3, 31                                      // 000000286D74: 85009F03
	s_mul_f32 s16, s16, 0x4f7ffffe                             // 000000286D78: A210FF10 4F7FFFFE
	s_add_u32 s0, s2, s0                                       // 000000286D80: 80000002
	s_addc_u32 s1, s3, 0                                       // 000000286D84: 82018003
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000286D88: BF870009
	s_cvt_u32_f32 s19, s16                                     // 000000286D8C: BE936710
	s_ashr_i64 s[16:17], s[0:1], 1                             // 000000286D90: 86908100
	s_add_u32 s4, s4, s8                                       // 000000286D94: 80040804
	s_addc_u32 s5, s5, s9                                      // 000000286D98: 82050905
	s_sub_i32 s0, 0, s12                                       // 000000286D9C: 81800C80
	s_mov_b32 s1, 0                                            // 000000286DA0: BE810080
	s_mul_i32 s0, s0, s19                                      // 000000286DA4: 96001300
	s_lshl_b32 s8, s18, 8                                      // 000000286DA8: 84088812
	s_mul_hi_u32 s0, s19, s0                                   // 000000286DAC: 96800013
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000286DB0: BF870009
	s_add_i32 s9, s19, s0                                      // 000000286DB4: 81090013
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000286DB8: BF870129
	.long 0xd72d0000                                           // 000000286DBC: D72D0000
	v_cndmask_b32_e32 v0, v2, v9, vcc_lo                       // 000000286DC0: 02001302
	.long 0x7f2a3880                                           // 000000286DC4: 7F2A3880
	.long 0xd72c0003                                           // 000000286DC8: D72C0003
	v_cndmask_b32_e32 v0, v0, v12, vcc_lo                      // 000000286DCC: 02001900
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000286DD0: BF870091
	v_sub_nc_u32_e32 v3, v2, v3                                // 000000286DD4: 4C060702
	v_subrev_nc_u32_e32 v5, s12, v3                            // 000000286DD8: 4E0A060C
	v_cmp_le_u32_e32 vcc_lo, s12, v3                           // 000000286DDC: 7C96060C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000286DE0: BF870092
	v_dual_cndmask_b32 v3, v3, v5 :: v_dual_add_nc_u32 v4, 1, v0// 000000286DE4: CA600B03 03040081
	v_cndmask_b32_e32 v0, v0, v4, vcc_lo                       // 000000286DEC: 02000900
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000286DF0: BF870112
	v_cmp_le_u32_e32 vcc_lo, s12, v3                           // 000000286DF4: 7C96060C
	v_add_nc_u32_e32 v4, 1, v0                                 // 000000286DF8: 4A080081
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000286DFC: BF870091
	v_cndmask_b32_e32 v0, v0, v4, vcc_lo                       // 000000286E00: 02000900
	.long 0xd72c0007                                           // 000000286E04: D72C0007
	v_cndmask_b32_e32 v0, v0, v12, vcc_lo                      // 000000286E08: 02001900
	v_mad_u64_u32 v[3:4], null, s16, v0, s[14:15]              // 000000286E0C: D6FE7C03 003A0010
	v_mad_u64_u32 v[5:6], null, s10, v0, s[4:5]                // 000000286E14: D6FE7C05 0012000A
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000286E1C: BF8701A3
	v_sub_nc_u32_e32 v10, v2, v7                               // 000000286E20: 4C140F02
	v_add_nc_u32_e32 v2, s8, v2                                // 000000286E24: 4A040408
	v_mad_u64_u32 v[7:8], null, s17, v0, v[4:5]                // 000000286E28: D6FE7C07 04120011
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000286E30: BF870113
	v_lshlrev_b32_e32 v4, 4, v10                               // 000000286E34: 30081484
	v_mad_u64_u32 v[8:9], null, s11, v0, v[6:7]                // 000000286E38: D6FE7C08 041A000B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000286E40: BF870132
	.long 0xd7006a03                                           // 000000286E44: D7006A03
	v_cndmask_b32_e32 v1, v3, v4, vcc_lo                       // 000000286E48: 02020903
	v_lshlrev_b32_e32 v6, 2, v10                               // 000000286E4C: 300C1482
	v_add_co_ci_u32_e64 v4, null, 0, v7, vcc_lo                // 000000286E50: D5207C04 01AA0E80
	v_ashrrev_i32_e32 v9, 31, v6                               // 000000286E58: 34120C9F
	.long 0xd7006a07                                           // 000000286E5C: D7006A07
	v_cndmask_b32_e32 v1, v5, v6, vcc_lo                       // 000000286E60: 02020D05
	global_load_b128 v[3:6], v[3:4], off                       // 000000286E64: DC5E0000 037C0003
	v_add_co_ci_u32_e64 v8, null, v8, v9, vcc_lo               // 000000286E6C: D5207C08 01AA1308
	v_cmp_le_u32_e32 vcc_lo, s13, v2                           // 000000286E74: 7C96040D
	global_load_b32 v11, v[7:8], off                           // 000000286E78: DC520000 0B7C0007
	s_or_b32 s1, vcc_lo, s1                                    // 000000286E80: 8C01016A
	s_waitcnt vmcnt(1)                                         // 000000286E84: BF8907F7
	v_and_b32_e32 v33, 15, v6                                  // 000000286E88: 36420C8F
	v_mad_u64_u32 v[7:8], null, s2, v0, 0                      // 000000286E8C: D6FE7C07 02020002
	v_bfe_u32 v34, v6, 4, 4                                    // 000000286E94: D6100022 02110906
	v_bfe_u32 v35, v6, 8, 4                                    // 000000286E9C: D6100023 02111106
	v_bfe_u32 v36, v6, 12, 4                                   // 000000286EA4: D6100024 02111906
	v_bfe_u32 v37, v6, 16, 4                                   // 000000286EAC: D6100025 02112106
	v_bfe_u32 v38, v6, 20, 4                                   // 000000286EB4: D6100026 02112906
	v_bfe_u32 v39, v6, 24, 4                                   // 000000286EBC: D6100027 02113106
	v_lshrrev_b32_e32 v6, 28, v6                               // 000000286EC4: 320C0C9C
	v_mad_u64_u32 v[8:9], null, s3, v0, v[8:9]                 // 000000286EC8: D6FE7C08 04220003
	v_lshlrev_b32_e32 v0, 5, v10                               // 000000286ED0: 30001485
	v_bfe_u32 v9, v3, 8, 4                                     // 000000286ED4: D6100009 02111103
	v_bfe_u32 v10, v3, 12, 4                                   // 000000286EDC: D610000A 02111903
	v_bfe_u32 v12, v3, 16, 4                                   // 000000286EE4: D610000C 02112103
	v_bfe_u32 v13, v3, 20, 4                                   // 000000286EEC: D610000D 02112903
	.long 0xd73c0011                                           // 000000286EF4: D73C0011
	v_cndmask_b32_e32 v1, 1, v0, vcc_lo                        // 000000286EF8: 02020081
	v_bfe_u32 v14, v3, 24, 4                                   // 000000286EFC: D610000E 02113103
	.long 0xd73c0007                                           // 000000286F04: D73C0007
	v_cndmask_b32_e32 v1, 1, v7, vcc_lo                        // 000000286F08: 02020E81
	v_and_b32_e32 v15, 15, v4                                  // 000000286F0C: 361E088F
	v_bfe_u32 v16, v4, 4, 4                                    // 000000286F10: D6100010 02110904
	v_bfe_u32 v19, v4, 8, 4                                    // 000000286F18: D6100013 02111104
	v_bfe_u32 v22, v4, 12, 4                                   // 000000286F20: D6100016 02111904
	v_bfe_u32 v23, v4, 16, 4                                   // 000000286F28: D6100017 02112104
	.long 0xd7000000                                           // 000000286F30: D7000000
	v_cndmask_b32_e32 v1, s6, v7, vcc_lo                       // 000000286F34: 02020E06
	v_and_b32_e32 v7, 15, v3                                   // 000000286F38: 360E068F
	v_add_co_ci_u32_e64 v20, null, s7, v8, s0                  // 000000286F3C: D5207C14 00021007
	v_bfe_u32 v8, v3, 4, 4                                     // 000000286F44: D6100008 02110903
	v_lshrrev_b32_e32 v3, 28, v3                               // 000000286F4C: 3206069C
	s_delay_alu instid0(VALU_DEP_4)                            // 000000286F50: BF870004
	v_cvt_f32_ubyte0_e32 v7, v7                                // 000000286F54: 7E0E2307
	v_bfe_u32 v24, v4, 20, 4                                   // 000000286F58: D6100018 02112904
	v_bfe_u32 v25, v4, 24, 4                                   // 000000286F60: D6100019 02113104
	v_lshrrev_b32_e32 v4, 28, v4                               // 000000286F68: 3208089C
	v_and_b32_e32 v26, 15, v5                                  // 000000286F6C: 36340A8F
	v_bfe_u32 v27, v5, 4, 4                                    // 000000286F70: D610001B 02110905
	v_bfe_u32 v28, v5, 8, 4                                    // 000000286F78: D610001C 02111105
	v_bfe_u32 v29, v5, 12, 4                                   // 000000286F80: D610001D 02111905
	v_bfe_u32 v30, v5, 16, 4                                   // 000000286F88: D610001E 02112105
	v_bfe_u32 v31, v5, 20, 4                                   // 000000286F90: D610001F 02112905
	v_bfe_u32 v32, v5, 24, 4                                   // 000000286F98: D6100020 02113105
	v_lshrrev_b32_e32 v5, 28, v5                               // 000000286FA0: 320A0A9C
	v_cvt_f32_ubyte0_e32 v8, v8                                // 000000286FA4: 7E102308
	v_cvt_f32_ubyte0_e32 v9, v9                                // 000000286FA8: 7E122309
	v_cvt_f32_ubyte0_e32 v6, v6                                // 000000286FAC: 7E0C2306
	s_waitcnt vmcnt(0)                                         // 000000286FB0: BF8903F7
	v_fma_mix_f32 v7, v7, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000286FB4: CC206007 142E1707
	v_cvt_f32_ubyte0_e32 v10, v10                              // 000000286FBC: 7E14230A
	v_cvt_f32_ubyte0_e32 v12, v12                              // 000000286FC0: 7E18230C
	v_cvt_f32_ubyte0_e32 v13, v13                              // 000000286FC4: 7E1A230D
	v_cvt_f32_ubyte0_e32 v14, v14                              // 000000286FC8: 7E1C230E
	v_cvt_f32_ubyte0_e32 v3, v3                                // 000000286FCC: 7E062303
	v_cvt_f32_ubyte0_e32 v15, v15                              // 000000286FD0: 7E1E230F
	v_cvt_f32_ubyte0_e32 v16, v16                              // 000000286FD4: 7E202310
	v_cvt_f32_ubyte0_e32 v19, v19                              // 000000286FD8: 7E262313
	v_cvt_f32_ubyte0_e32 v22, v22                              // 000000286FDC: 7E2C2316
	v_cvt_f32_ubyte0_e32 v23, v23                              // 000000286FE0: 7E2E2317
	v_cvt_f32_ubyte0_e32 v24, v24                              // 000000286FE4: 7E302318
	v_cvt_f32_ubyte0_e32 v25, v25                              // 000000286FE8: 7E322319
	v_cvt_f32_ubyte0_e32 v4, v4                                // 000000286FEC: 7E082304
	v_cvt_f32_ubyte0_e32 v26, v26                              // 000000286FF0: 7E34231A
	v_cvt_f32_ubyte0_e32 v27, v27                              // 000000286FF4: 7E36231B
	v_cvt_f32_ubyte0_e32 v28, v28                              // 000000286FF8: 7E38231C
	v_cvt_f32_ubyte0_e32 v29, v29                              // 000000286FFC: 7E3A231D
	v_cvt_f32_ubyte0_e32 v30, v30                              // 000000287000: 7E3C231E
	v_cvt_f32_ubyte0_e32 v31, v31                              // 000000287004: 7E3E231F
	v_cvt_f32_ubyte0_e32 v32, v32                              // 000000287008: 7E402320
	v_cvt_f32_ubyte0_e32 v5, v5                                // 00000028700C: 7E0A2305
	v_cvt_f32_ubyte0_e32 v33, v33                              // 000000287010: 7E422321
	v_cvt_f32_ubyte0_e32 v34, v34                              // 000000287014: 7E442322
	v_cvt_f32_ubyte0_e32 v35, v35                              // 000000287018: 7E462323
	v_cvt_f32_ubyte0_e32 v36, v36                              // 00000028701C: 7E482324
	v_cvt_f32_ubyte0_e32 v37, v37                              // 000000287020: 7E4A2325
	v_cvt_f32_ubyte0_e32 v38, v38                              // 000000287024: 7E4C2326
	v_cvt_f32_ubyte0_e32 v39, v39                              // 000000287028: 7E4E2327
	v_fma_mix_f32 v8, v8, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000028702C: CC206008 142E1708
	v_fma_mix_f32 v9, v9, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000287034: CC206009 142E1709
	v_fma_mix_f32 v40, v6, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000028703C: CC206028 142E1706
	v_bfe_u32 v6, v7, 16, 1                                    // 000000287044: D6100006 02052107
	v_fma_mix_f32 v10, v10, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000028704C: CC20600A 142E170A
	v_fma_mix_f32 v12, v12, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000287054: CC20600C 142E170C
	v_fma_mix_f32 v13, v13, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000028705C: CC20600D 142E170D
	v_fma_mix_f32 v14, v14, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000287064: CC20600E 142E170E
	v_fma_mix_f32 v3, v3, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000028706C: CC206003 142E1703
	v_fma_mix_f32 v15, v15, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000287074: CC20600F 142E170F
	v_fma_mix_f32 v16, v16, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000028707C: CC206010 142E1710
	v_fma_mix_f32 v19, v19, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000287084: CC206013 142E1713
	v_fma_mix_f32 v22, v22, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000028708C: CC206016 142E1716
	v_fma_mix_f32 v23, v23, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000287094: CC206017 142E1717
	v_fma_mix_f32 v24, v24, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000028709C: CC206018 142E1718
	v_fma_mix_f32 v25, v25, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002870A4: CC206019 142E1719
	v_fma_mix_f32 v4, v4, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002870AC: CC206004 142E1704
	v_fma_mix_f32 v26, v26, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002870B4: CC20601A 142E171A
	v_fma_mix_f32 v27, v27, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002870BC: CC20601B 142E171B
	v_fma_mix_f32 v28, v28, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002870C4: CC20601C 142E171C
	v_fma_mix_f32 v29, v29, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002870CC: CC20601D 142E171D
	v_fma_mix_f32 v30, v30, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002870D4: CC20601E 142E171E
	v_fma_mix_f32 v31, v31, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002870DC: CC20601F 142E171F
	v_fma_mix_f32 v32, v32, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002870E4: CC206020 142E1720
	v_fma_mix_f32 v5, v5, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002870EC: CC206005 142E1705
	v_fma_mix_f32 v33, v33, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002870F4: CC206021 142E1721
	v_fma_mix_f32 v34, v34, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002870FC: CC206022 142E1722
	v_fma_mix_f32 v35, v35, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000287104: CC206023 142E1723
	v_fma_mix_f32 v36, v36, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000028710C: CC206024 142E1724
	v_fma_mix_f32 v37, v37, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000287114: CC206025 142E1725
	v_fma_mix_f32 v38, v38, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000028711C: CC206026 142E1726
	v_fma_mix_f32 v39, v39, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000287124: CC206027 142E1727
	v_bfe_u32 v11, v8, 16, 1                                   // 00000028712C: D610000B 02052108
	v_bfe_u32 v41, v9, 16, 1                                   // 000000287134: D6100029 02052109
	v_add3_u32 v6, v7, v6, 0x7fff                              // 00000028713C: D6550006 03FE0D07 00007FFF
	v_bfe_u32 v42, v10, 16, 1                                  // 000000287148: D610002A 0205210A
	v_bfe_u32 v43, v12, 16, 1                                  // 000000287150: D610002B 0205210C
	v_bfe_u32 v44, v13, 16, 1                                  // 000000287158: D610002C 0205210D
	v_bfe_u32 v46, v3, 16, 1                                   // 000000287160: D610002E 02052103
	v_add3_u32 v7, v8, v11, 0x7fff                             // 000000287168: D6550007 03FE1708 00007FFF
	v_add3_u32 v8, v9, v41, 0x7fff                             // 000000287174: D6550008 03FE5309 00007FFF
	.long 0x7e2a3986                                           // 000000287180: 7E2A3986
	v_bfe_u32 v45, v14, 16, 1                                  // 000000287184: D610002D 0205210E
	v_bfe_u32 v47, v15, 16, 1                                  // 00000028718C: D610002F 0205210F
	v_bfe_u32 v48, v16, 16, 1                                  // 000000287194: D6100030 02052110
	v_bfe_u32 v49, v19, 16, 1                                  // 00000028719C: D6100031 02052113
	v_bfe_u32 v50, v22, 16, 1                                  // 0000002871A4: D6100032 02052116
	v_bfe_u32 v51, v23, 16, 1                                  // 0000002871AC: D6100033 02052117
	v_bfe_u32 v52, v24, 16, 1                                  // 0000002871B4: D6100034 02052118
	v_bfe_u32 v53, v25, 16, 1                                  // 0000002871BC: D6100035 02052119
	v_bfe_u32 v54, v4, 16, 1                                   // 0000002871C4: D6100036 02052104
	v_add3_u32 v9, v10, v42, 0x7fff                            // 0000002871CC: D6550009 03FE550A 00007FFF
	v_add3_u32 v10, v12, v43, 0x7fff                           // 0000002871D8: D655000A 03FE570C 00007FFF
	v_add3_u32 v11, v13, v44, 0x7fff                           // 0000002871E4: D655000B 03FE590D 00007FFF
	v_add3_u32 v13, v3, v46, 0x7fff                            // 0000002871F0: D655000D 03FE5D03 00007FFF
	v_and_or_b32 v3, 0xffff0000, v7, v21                       // 0000002871FC: D6570003 04560EFF FFFF0000
	.long 0x7e2a3988                                           // 000000287208: 7E2A3988
	v_bfe_u32 v62, v5, 16, 1                                   // 00000028720C: D610003E 02052105
	v_add3_u32 v12, v14, v45, 0x7fff                           // 000000287214: D655000C 03FE5B0E 00007FFF
	v_add3_u32 v14, v15, v47, 0x7fff                           // 000000287220: D655000E 03FE5F0F 00007FFF
	v_add3_u32 v15, v16, v48, 0x7fff                           // 00000028722C: D655000F 03FE6110 00007FFF
	v_add3_u32 v16, v19, v49, 0x7fff                           // 000000287238: D6550010 03FE6313 00007FFF
	v_add3_u32 v19, v22, v50, 0x7fff                           // 000000287244: D6550013 03FE6516 00007FFF
	v_add3_u32 v22, v23, v51, 0x7fff                           // 000000287250: D6550016 03FE6717 00007FFF
	v_add3_u32 v23, v24, v52, 0x7fff                           // 00000028725C: D6550017 03FE6918 00007FFF
	v_add3_u32 v24, v25, v53, 0x7fff                           // 000000287268: D6550018 03FE6B19 00007FFF
	v_add3_u32 v25, v4, v54, 0x7fff                            // 000000287274: D6550019 03FE6D04 00007FFF
	v_and_or_b32 v4, 0xffff0000, v9, v21                       // 000000287280: D6570004 045612FF FFFF0000
	.long 0x7e2a398a                                           // 00000028728C: 7E2A398A
	v_add3_u32 v41, v5, v62, 0x7fff                            // 000000287290: D6550029 03FE7D05 00007FFF
	v_bfe_u32 v55, v26, 16, 1                                  // 00000028729C: D6100037 0205211A
	v_bfe_u32 v56, v27, 16, 1                                  // 0000002872A4: D6100038 0205211B
	v_bfe_u32 v57, v28, 16, 1                                  // 0000002872AC: D6100039 0205211C
	v_and_or_b32 v5, 0xffff0000, v11, v21                      // 0000002872B4: D6570005 045616FF FFFF0000
	.long 0x7e2a398c                                           // 0000002872C0: 7E2A398C
	v_add3_u32 v26, v26, v55, 0x7fff                           // 0000002872C4: D655001A 03FE6F1A 00007FFF
	v_bfe_u32 v58, v29, 16, 1                                  // 0000002872D0: D610003A 0205211D
	v_bfe_u32 v59, v30, 16, 1                                  // 0000002872D8: D610003B 0205211E
	v_add3_u32 v27, v27, v56, 0x7fff                           // 0000002872E0: D655001B 03FE711B 00007FFF
	v_and_or_b32 v6, 0xffff0000, v13, v21                      // 0000002872EC: D6570006 04561AFF FFFF0000
	.long 0x7e2a398e                                           // 0000002872F8: 7E2A398E
	v_add3_u32 v28, v28, v57, 0x7fff                           // 0000002872FC: D655001C 03FE731C 00007FFF
	v_bfe_u32 v60, v31, 16, 1                                  // 000000287308: D610003C 0205211F
	v_bfe_u32 v61, v32, 16, 1                                  // 000000287310: D610003D 02052120
	v_add3_u32 v29, v29, v58, 0x7fff                           // 000000287318: D655001D 03FE751D 00007FFF
	v_and_or_b32 v7, 0xffff0000, v15, v21                      // 000000287324: D6570007 04561EFF FFFF0000
	.long 0x7e2a3990                                           // 000000287330: 7E2A3990
	v_add3_u32 v30, v30, v59, 0x7fff                           // 000000287334: D655001E 03FE771E 00007FFF
	v_bfe_u32 v63, v33, 16, 1                                  // 000000287340: D610003F 02052121
	v_add3_u32 v31, v31, v60, 0x7fff                           // 000000287348: D655001F 03FE791F 00007FFF
	v_add3_u32 v32, v32, v61, 0x7fff                           // 000000287354: D6550020 03FE7B20 00007FFF
	v_and_or_b32 v8, 0xffff0000, v19, v21                      // 000000287360: D6570008 045626FF FFFF0000
	.long 0x7e2a3996                                           // 00000028736C: 7E2A3996
	v_bfe_u32 v64, v34, 16, 1                                  // 000000287370: D6100040 02052122
	v_bfe_u32 v65, v35, 16, 1                                  // 000000287378: D6100041 02052123
	v_add3_u32 v33, v33, v63, 0x7fff                           // 000000287380: D6550021 03FE7F21 00007FFF
	v_bfe_u32 v66, v36, 16, 1                                  // 00000028738C: D6100042 02052124
	v_and_or_b32 v9, 0xffff0000, v23, v21                      // 000000287394: D6570009 04562EFF FFFF0000
	.long 0x7e2a3998                                           // 0000002873A0: 7E2A3998
	v_bfe_u32 v67, v37, 16, 1                                  // 0000002873A4: D6100043 02052125
	v_add3_u32 v34, v34, v64, 0x7fff                           // 0000002873AC: D6550022 03FE8122 00007FFF
	v_add3_u32 v35, v35, v65, 0x7fff                           // 0000002873B8: D6550023 03FE8323 00007FFF
	v_bfe_u32 v68, v38, 16, 1                                  // 0000002873C4: D6100044 02052126
	v_and_or_b32 v10, 0xffff0000, v25, v21                     // 0000002873CC: D657000A 045632FF FFFF0000
	.long 0x7e2a399a                                           // 0000002873D8: 7E2A399A
	v_bfe_u32 v69, v39, 16, 1                                  // 0000002873DC: D6100045 02052127
	v_add3_u32 v36, v36, v66, 0x7fff                           // 0000002873E4: D6550024 03FE8524 00007FFF
	v_add3_u32 v19, v37, v67, 0x7fff                           // 0000002873F0: D6550013 03FE8725 00007FFF
	v_bfe_u32 v70, v40, 16, 1                                  // 0000002873FC: D6100046 02052128
	v_and_or_b32 v11, 0xffff0000, v27, v21                     // 000000287404: D657000B 045636FF FFFF0000
	.long 0x7e2a399c                                           // 000000287410: 7E2A399C
	v_add3_u32 v22, v38, v68, 0x7fff                           // 000000287414: D6550016 03FE8926 00007FFF
	v_add3_u32 v23, v39, v69, 0x7fff                           // 000000287420: D6550017 03FE8B27 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000028742C: BF8700A3
	v_and_or_b32 v12, 0xffff0000, v29, v21                     // 000000287430: D657000C 04563AFF FFFF0000
	.long 0x7e2a399e                                           // 00000028743C: 7E2A399E
	v_and_or_b32 v13, 0xffff0000, v31, v21                     // 000000287440: D657000D 04563EFF FFFF0000
	.long 0x7e2a39a0                                           // 00000028744C: 7E2A39A0
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000287450: BF8700A1
	v_and_or_b32 v14, 0xffff0000, v41, v21                     // 000000287454: D657000E 045652FF FFFF0000
	.long 0x7e2a39a1                                           // 000000287460: 7E2A39A1
	v_and_or_b32 v15, 0xffff0000, v34, v21                     // 000000287464: D657000F 045644FF FFFF0000
	.long 0x7e2a39a3                                           // 000000287470: 7E2A39A3
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 000000287474: BF870251
	v_and_or_b32 v16, 0xffff0000, v36, v21                     // 000000287478: D6570010 045648FF FFFF0000
	.long 0x7e2a3993                                           // 000000287484: 7E2A3993
	.long 0xd7000013                                           // 000000287488: D7000013
	v_cndmask_b32_e32 v1, v0, v17, vcc_lo                      // 00000028748C: 02022300
	v_add3_u32 v0, v40, v70, 0x7fff                            // 000000287490: D6550000 03FE8D28 00007FFF
	v_add_co_ci_u32_e64 v20, null, v20, v18, s0                // 00000028749C: D5207C14 00022514
	v_and_or_b32 v17, 0xffff0000, v22, v21                     // 0000002874A4: D6570011 04562CFF FFFF0000
	.long 0x7e2a3997                                           // 0000002874B0: 7E2A3997
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002874B4: BF870001
	v_and_or_b32 v18, 0xffff0000, v0, v21                      // 0000002874B8: D6570012 045600FF FFFF0000
	s_clause 0x3                                               // 0000002874C4: BF850003
	global_store_b128 v[19:20], v[3:6], off                    // 0000002874C8: DC760000 007C0313
	global_store_b128 v[19:20], v[7:10], off offset:16         // 0000002874D0: DC760010 007C0713
	global_store_b128 v[19:20], v[11:14], off offset:32        // 0000002874D8: DC760020 007C0B13
	global_store_b128 v[19:20], v[15:18], off offset:48        // 0000002874E0: DC760030 007C0F13
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 0000002874E8: 917E017E
	s_cbranch_execnz 65074                                     // 0000002874EC: BFA6FE32 <_ZN7halogen12_GLOBAL__N_19k_deq_affILi4ELb0EEEvPKhPtNS0_6AffDevEjjl+0xb8>
	s_endpgm                                                   // 0000002874F0: BFB00000
		...

