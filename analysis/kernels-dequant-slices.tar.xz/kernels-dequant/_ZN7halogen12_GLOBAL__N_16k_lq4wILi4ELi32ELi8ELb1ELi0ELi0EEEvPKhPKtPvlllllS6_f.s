0000000000748600 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb1ELi0ELi0EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb1ELi0ELi0EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 000000748600: F4100100 F8000000
	v_dual_mov_b32 v6, 0 :: v_dual_and_b32 v1, 15, v0          // 000000748608: CA240080 0600008F
	v_lshrrev_b32_e32 v2, 2, v0                                // 000000748610: 32040082
	s_ashr_i32 s3, s2, 31                                      // 000000748614: 86039F02
	v_mov_b32_e32 v5, 0                                        // 000000748618: 7E0A0280
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000074861C: BF870193
	v_dual_mov_b32 v8, 0 :: v_dual_lshlrev_b32 v1, 2, v1       // 000000748620: CA220080 08000282
	v_and_b32_e32 v2, 60, v2                                   // 000000748628: 360404BC
	v_lshrrev_b32_e32 v15, 5, v0                               // 00000074862C: 321E0085
	v_dual_mov_b32 v21, 0 :: v_dual_and_b32 v16, 31, v0        // 000000748630: CA240080 1510009F
	.long 0x7f263880                                           // 000000748638: 7F263880
	v_dual_mov_b32 v17, 0 :: v_dual_lshlrev_b32 v14, 2, v0     // 00000074863C: CA220080 110E0082
	s_waitcnt lgkmcnt(0)                                       // 000000748644: BF89FC07
	s_clause 0x1                                               // 000000748648: BF850001
	global_load_b32 v11, v1, s[4:5]                            // 00000074864C: DC520000 0B040001
	global_load_b32 v13, v2, s[4:5]                            // 000000748654: DC520000 0D040002
	.long 0xd4510000                                           // 00000074865C: D4510000
	v_cndmask_b32_e32 v0, s2, v12, vcc_lo                      // 000000748660: 02001802
	s_and_b32 s0, s0, exec_lo                                  // 000000748664: 8B007E00
	s_cselect_b32 s22, s3, 0                                   // 000000748668: 98168003
	s_cselect_b32 s23, s2, 0                                   // 00000074866C: 98178002
	s_add_u32 s0, s4, s14                                      // 000000748670: 80000E04
	s_addc_u32 s1, s5, s15                                     // 000000748674: 82010F05
	s_lshr_b32 s14, s11, 31                                    // 000000748678: 850E9F0B
	v_dual_mov_b32 v7, 0 :: v_dual_mov_b32 v2, s1              // 00000074867C: CA100080 07020001
	s_add_u32 s14, s10, s14                                    // 000000748684: 800E0E0A
	s_addc_u32 s15, s11, 0                                     // 000000748688: 820F800B
	s_ashr_i32 s20, s11, 31                                    // 00000074868C: 86149F0B
	s_ashr_i64 s[14:15], s[14:15], 1                           // 000000748690: 868E810E
	s_lshr_b32 s20, s20, 27                                    // 000000748694: 85149B14
	v_mov_b32_e32 v1, s0                                       // 000000748698: 7E020200
	s_add_u32 s20, s10, s20                                    // 00000074869C: 8014140A
	s_addc_u32 s21, s11, 0                                     // 0000007486A0: 8215800B
	s_mul_i32 s19, s19, s23                                    // 0000007486A4: 96131713
	s_lshr_b64 s[20:21], s[20:21], 5                           // 0000007486A8: 85948514
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000007486AC: BF870499
	s_add_i32 s21, s20, 7                                      // 0000007486B0: 81158714
	s_ashr_i32 s24, s21, 31                                    // 0000007486B4: 86189F15
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000007486B8: BF870499
	s_lshr_b32 s24, s24, 29                                    // 0000007486BC: 85189D18
	s_add_i32 s21, s21, s24                                    // 0000007486C0: 81151815
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000007486C4: BF870009
	s_ashr_i32 s21, s21, 3                                     // 0000007486C8: 86158315
	s_add_u32 s0, s4, s16                                      // 0000007486CC: 80001004
	s_addc_u32 s1, s5, s17                                     // 0000007486D0: 82011105
	.long 0xd72c0012                                           // 0000007486D4: D72C0012
	v_cndmask_b32_e32 v1, s21, v15, vcc_lo                     // 0000007486D8: 02021E15
	v_mov_b32_e32 v4, s1                                       // 0000007486DC: 7E080201
	v_mad_u64_u32 v[9:10], null, s23, s14, v[1:2]              // 0000007486E0: D6FE7C09 04041C17
	v_mov_b32_e32 v3, s0                                       // 0000007486E8: 7E060200
	s_mul_i32 s0, s22, s14                                     // 0000007486EC: 96000E16
	s_waitcnt vmcnt(1)                                         // 0000007486F0: BF8907F7
	v_bfe_u32 v12, v11, 16, 1                                  // 0000007486F4: D610000C 0205210B
	s_waitcnt vmcnt(0)                                         // 0000007486FC: BF8903F7
	v_bfe_u32 v1, v13, 16, 1                                   // 000000748700: D6100001 0205210D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000748708: BF870112
	v_add3_u32 v2, v11, v12, 0x7fff                            // 00000074870C: D6550002 03FE190B 00007FFF
	v_add3_u32 v1, v13, v1, 0x7fff                             // 000000748718: D6550001 03FE030D 00007FFF
	s_delay_alu instid0(VALU_DEP_2)                            // 000000748724: BF870002
	.long 0x7e263982                                           // 000000748728: 7E263982
	v_add_nc_u32_e32 v2, s0, v10                               // 00000074872C: 4A041400
	v_mad_u64_u32 v[11:12], null, s18, s23, v[3:4]             // 000000748730: D6FE7C0B 040C2E12
	v_add_nc_u32_e32 v3, s21, v18                              // 000000748738: 4A062415
	v_add_nc_u32_e32 v10, v18, v16                             // 00000074873C: 4A142112
	s_mul_i32 s23, s23, s15                                    // 000000748740: 96170F17
	s_mul_i32 s0, s18, s22                                     // 000000748744: 96001612
	v_and_or_b32 v1, 0xffff0000, v1, v19                       // 000000748748: D6570001 044E02FF FFFF0000
	v_min_i32_e32 v18, s20, v3                                 // 000000748754: 22240614
	v_add_nc_u32_e32 v19, s23, v2                              // 000000748758: 4A260417
	v_add_nc_u32_e32 v3, s19, v12                              // 00000074875C: 4A061813
	ds_store_b32 v14, v1                                       // 000000748760: D8340000 0000010E
	v_cmp_lt_i32_e32 vcc_lo, v10, v18                          // 000000748768: 7C82250A
	v_add_nc_u32_e32 v20, s0, v3                               // 00000074876C: 4A280600
	s_waitcnt lgkmcnt(0)                                       // 000000748770: BF89FC07
	s_barrier                                                  // 000000748774: BFBD0000
	buffer_gl0_inv                                             // 000000748778: E0AC0000 00000000
	s_and_saveexec_b32 s1, vcc_lo                              // 000000748780: BE81206A
	s_cbranch_execz 21                                         // 000000748784: BFA50015 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb1ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x1dc>
	v_lshlrev_b32_e32 v1, 1, v10                               // 000000748788: 30021481
	v_lshlrev_b32_e32 v3, 4, v10                               // 00000074878C: 30061484
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000748790: BF870112
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000748794: 3404029F
	v_ashrrev_i32_e32 v4, 31, v3                               // 000000748798: 3408069F
	.long 0xd7000001                                           // 00000074879C: D7000001
	v_cndmask_b32_e32 v1, v11, v1, vcc_lo                      // 0000007487A0: 0202030B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007487A4: BF8700A1
	v_add_co_ci_u32_e64 v2, null, v20, v2, s0                  // 0000007487A8: D5207C02 00020514
	.long 0xd7000003                                           // 0000007487B0: D7000003
	v_cndmask_b32_e32 v1, v9, v3, vcc_lo                       // 0000007487B4: 02020709
	v_add_co_ci_u32_e64 v4, null, v19, v4, s0                  // 0000007487B8: D5207C04 00020913
	s_clause 0x1                                               // 0000007487C0: BF850001
	global_load_d16_b16 v1, v[1:2], off                        // 0000007487C4: DC820000 017C0001
	global_load_b128 v[5:8], v[3:4], off                       // 0000007487CC: DC5E0000 057C0003
	s_waitcnt vmcnt(1)                                         // 0000007487D4: BF8907F7
	v_cvt_f32_f16_e32 v21, v1                                  // 0000007487D8: 7E2A1701
	s_or_b32 exec_lo, exec_lo, s1                              // 0000007487DC: 8C7E017E
	v_dual_mov_b32 v23, 0 :: v_dual_mov_b32 v24, 0             // 0000007487E0: CA100080 17180080
	v_mov_b32_e32 v22, 0                                       // 0000007487E8: 7E2C0280
	s_and_saveexec_b32 s1, vcc_lo                              // 0000007487EC: BE81206A
	s_cbranch_execz 401                                        // 0000007487F0: BFA50191 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb1ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x838>
	v_dual_mov_b32 v22, 0 :: v_dual_add_nc_u32 v1, 32, v10     // 0000007487F4: CA200080 160014A0
	v_dual_mov_b32 v23, 0 :: v_dual_lshlrev_b32 v12, 5, v10    // 0000007487FC: CA220080 170C1485
	v_mov_b32_e32 v27, v21                                     // 000000748804: 7E360315
	s_delay_alu instid0(VALU_DEP_3)                            // 000000748808: BF870003
	v_dual_mov_b32 v24, 0 :: v_dual_lshlrev_b32 v25, 4, v1     // 00000074880C: CA220080 18180284
	v_dual_mov_b32 v17, 0 :: v_dual_lshlrev_b32 v26, 1, v1     // 000000748814: CA220080 111A0281
	s_mul_i32 s0, s11, 6                                       // 00000074881C: 9600860B
	s_mul_hi_u32 s14, s10, 6                                   // 000000748820: 968E860A
	s_lshl_b64 s[4:5], s[10:11], 2                             // 000000748824: 8484820A
	s_add_i32 s14, s14, s0                                     // 000000748828: 810E000E
	s_mul_i32 s16, s10, 6                                      // 00000074882C: 9610860A
	s_mov_b32 s15, 0                                           // 000000748830: BE8F0080
	s_lshl_b64 s[10:11], s[10:11], 1                           // 000000748834: 848A810A
	s_branch 351                                               // 000000748838: BFA0015F <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb1ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x7b8>
	s_or_b32 exec_lo, exec_lo, s17                             // 00000074883C: 8C7E117E
	v_and_b32_e32 v13, 0xff, v5                                // 000000748840: 361A0AFF 000000FF
	s_and_b32 s0, exec_lo, vcc_lo                              // 000000748848: 8B006A7E
	v_add_nc_u32_e32 v25, 0x200, v25                           // 00000074884C: 4A3232FF 00000200
	s_or_b32 s15, s0, s15                                      // 000000748854: 8C0F0F00
	v_add_nc_u32_e32 v26, 64, v26                              // 000000748858: 4A3434C0
	v_lshlrev_b32_e32 v13, 2, v13                              // 00000074885C: 301A1A82
	ds_load_b32 v42, v13                                       // 000000748860: D8D80000 2A00000D
	v_lshrrev_b32_e32 v13, 6, v5                               // 000000748868: 321A0A86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 00000074886C: BF870141
	v_and_b32_e32 v13, 0x3fc, v13                              // 000000748870: 361A1AFF 000003FC
	ds_load_b32 v43, v13                                       // 000000748878: D8D80000 2B00000D
	v_lshrrev_b32_e32 v13, 14, v5                              // 000000748880: 321A0A8E
	v_lshrrev_b32_e32 v5, 22, v5                               // 000000748884: 320A0A96
	v_and_b32_e32 v13, 0x3fc, v13                              // 000000748888: 361A1AFF 000003FC
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 000000748890: BF870152
	v_and_b32_e32 v5, 0x3fc, v5                                // 000000748894: 360A0AFF 000003FC
	ds_load_b32 v44, v13                                       // 00000074889C: D8D80000 2C00000D
	ds_load_b32 v45, v5                                        // 0000007488A4: D8D80000 2D000005
	v_and_b32_e32 v5, 0xff, v6                                 // 0000007488AC: 360A0CFF 000000FF
	v_ashrrev_i32_e32 v13, 31, v12                             // 0000007488B4: 341A189F
	v_lshlrev_b32_e32 v5, 2, v5                                // 0000007488B8: 300A0A82
	ds_load_b32 v46, v5                                        // 0000007488BC: D8D80000 2E000005
	v_lshrrev_b32_e32 v5, 6, v6                                // 0000007488C4: 320A0C86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007488C8: BF8700B1
	v_and_b32_e32 v5, 0x3fc, v5                                // 0000007488CC: 360A0AFF 000003FC
	ds_load_b32 v47, v5                                        // 0000007488D4: D8D80000 2F000005
	v_lshrrev_b32_e32 v5, 14, v6                               // 0000007488DC: 320A0C8E
	v_and_b32_e32 v5, 0x3fc, v5                                // 0000007488E0: 360A0AFF 000003FC
	ds_load_b32 v48, v5                                        // 0000007488E8: D8D80000 30000005
	v_lshrrev_b32_e32 v5, 22, v6                               // 0000007488F0: 320A0C96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007488F4: BF8700B1
	v_and_b32_e32 v5, 0x3fc, v5                                // 0000007488F8: 360A0AFF 000003FC
	ds_load_b32 v49, v5                                        // 000000748900: D8D80000 31000005
	v_and_b32_e32 v5, 0xff, v7                                 // 000000748908: 360A0EFF 000000FF
	v_lshlrev_b32_e32 v5, 2, v5                                // 000000748910: 300A0A82
	ds_load_b32 v50, v5                                        // 000000748914: D8D80000 32000005
	v_lshrrev_b32_e32 v5, 6, v7                                // 00000074891C: 320A0E86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000748920: BF8700B1
	v_and_b32_e32 v5, 0x3fc, v5                                // 000000748924: 360A0AFF 000003FC
	ds_load_b32 v51, v5                                        // 00000074892C: D8D80000 33000005
	v_lshrrev_b32_e32 v5, 14, v7                               // 000000748934: 320A0E8E
	v_and_b32_e32 v5, 0x3fc, v5                                // 000000748938: 360A0AFF 000003FC
	ds_load_b32 v52, v5                                        // 000000748940: D8D80000 34000005
	v_lshrrev_b32_e32 v5, 22, v7                               // 000000748948: 320A0E96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000074894C: BF8700B1
	v_and_b32_e32 v5, 0x3fc, v5                                // 000000748950: 360A0AFF 000003FC
	ds_load_b32 v53, v5                                        // 000000748958: D8D80000 35000005
	v_and_b32_e32 v5, 0xff, v8                                 // 000000748960: 360A10FF 000000FF
	v_lshlrev_b32_e32 v5, 2, v5                                // 000000748968: 300A0A82
	ds_load_b32 v54, v5                                        // 00000074896C: D8D80000 36000005
	v_lshrrev_b32_e32 v5, 6, v8                                // 000000748974: 320A1086
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000748978: BF8700B1
	v_and_b32_e32 v5, 0x3fc, v5                                // 00000074897C: 360A0AFF 000003FC
	ds_load_b32 v55, v5                                        // 000000748984: D8D80000 37000005
	v_lshrrev_b32_e32 v5, 14, v8                               // 00000074898C: 320A108E
	v_and_b32_e32 v5, 0x3fc, v5                                // 000000748990: 360A0AFF 000003FC
	ds_load_b32 v56, v5                                        // 000000748998: D8D80000 38000005
	v_lshrrev_b32_e32 v5, 22, v8                               // 0000007489A0: 320A1096
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000007489A4: BF870141
	v_and_b32_e32 v5, 0x3fc, v5                                // 0000007489A8: 360A0AFF 000003FC
	ds_load_b32 v57, v5                                        // 0000007489B0: D8D80000 39000005
	.long 0xd73c0005                                           // 0000007489B8: D73C0005
	v_cndmask_b32_e32 v1, 1, v12, vcc_lo                       // 0000007489BC: 02021881
	v_add_nc_u32_e32 v12, 0x400, v12                           // 0000007489C0: 4A1818FF 00000400
	.long 0xd7006a28                                           // 0000007489C8: D7006A28
	v_cndmask_b32_e32 v1, s6, v5, vcc_lo                       // 0000007489CC: 02020A06
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007489D0: BF870001
	v_add_co_ci_u32_e64 v41, null, s7, v6, vcc_lo              // 0000007489D4: D5207C29 01AA0C07
	s_clause 0x3                                               // 0000007489DC: BF850003
	global_load_b128 v[5:8], v[40:41], off                     // 0000007489E0: DC5E0000 057C0028
	global_load_b128 v[28:31], v[40:41], off offset:16         // 0000007489E8: DC5E0010 1C7C0028
	global_load_b128 v[32:35], v[40:41], off offset:32         // 0000007489F0: DC5E0020 207C0028
	global_load_b128 v[36:39], v[40:41], off offset:48         // 0000007489F8: DC5E0030 247C0028
	s_waitcnt vmcnt(3) lgkmcnt(15)                             // 000000748A00: BF890CF7
	v_dot2_f32_bf16 v5, v5, v42, 0                             // 000000748A04: CC1A4005 1A025505
	s_waitcnt lgkmcnt(14)                                      // 000000748A0C: BF89FCE7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000748A10: BF8700A1
	v_dot2_f32_bf16 v5, v6, v43, v5                            // 000000748A14: CC1A4005 1C165706
	s_waitcnt lgkmcnt(13)                                      // 000000748A1C: BF89FCD7
	v_dot2_f32_bf16 v5, v7, v44, v5                            // 000000748A20: CC1A4005 1C165907
	s_waitcnt lgkmcnt(12)                                      // 000000748A28: BF89FCC7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000748A2C: BF8700A1
	v_dot2_f32_bf16 v5, v8, v45, v5                            // 000000748A30: CC1A4005 1C165B08
	s_waitcnt vmcnt(2) lgkmcnt(11)                             // 000000748A38: BF8908B7
	v_dot2_f32_bf16 v5, v28, v46, v5                           // 000000748A3C: CC1A4005 1C165D1C
	s_waitcnt lgkmcnt(10)                                      // 000000748A44: BF89FCA7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000748A48: BF8700A1
	v_dot2_f32_bf16 v5, v29, v47, v5                           // 000000748A4C: CC1A4005 1C165F1D
	s_waitcnt lgkmcnt(9)                                       // 000000748A54: BF89FC97
	v_dot2_f32_bf16 v5, v30, v48, v5                           // 000000748A58: CC1A4005 1C16611E
	s_waitcnt lgkmcnt(8)                                       // 000000748A60: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000748A64: BF8700A1
	v_dot2_f32_bf16 v5, v31, v49, v5                           // 000000748A68: CC1A4005 1C16631F
	s_waitcnt vmcnt(1) lgkmcnt(7)                              // 000000748A70: BF890477
	v_dot2_f32_bf16 v5, v32, v50, v5                           // 000000748A74: CC1A4005 1C166520
	s_waitcnt lgkmcnt(6)                                       // 000000748A7C: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000748A80: BF8700A1
	v_dot2_f32_bf16 v5, v33, v51, v5                           // 000000748A84: CC1A4005 1C166721
	s_waitcnt lgkmcnt(5)                                       // 000000748A8C: BF89FC57
	v_dot2_f32_bf16 v5, v34, v52, v5                           // 000000748A90: CC1A4005 1C166922
	s_waitcnt lgkmcnt(4)                                       // 000000748A98: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000748A9C: BF8700A1
	v_dot2_f32_bf16 v5, v35, v53, v5                           // 000000748AA0: CC1A4005 1C166B23
	s_waitcnt vmcnt(0) lgkmcnt(3)                              // 000000748AA8: BF890037
	v_dot2_f32_bf16 v5, v36, v54, v5                           // 000000748AAC: CC1A4005 1C166D24
	.long 0xd7006a24                                           // 000000748AB4: D7006A24
	v_cndmask_b32_e32 v0, v40, v10, vcc_lo                     // 000000748AB8: 02001528
	s_waitcnt lgkmcnt(2)                                       // 000000748ABC: BF89FC27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000748AC0: BF870132
	v_dot2_f32_bf16 v5, v37, v55, v5                           // 000000748AC4: CC1A4005 1C166F25
	v_add_co_ci_u32_e64 v37, null, s11, v41, vcc_lo            // 000000748ACC: D5207C25 01AA520B
	s_waitcnt lgkmcnt(1)                                       // 000000748AD4: BF89FC17
	v_dot2_f32_bf16 v5, v38, v56, v5                           // 000000748AD8: CC1A4005 1C167126
	s_waitcnt lgkmcnt(0)                                       // 000000748AE0: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000748AE4: BF870091
	v_dot2_f32_bf16 v5, v39, v57, v5                           // 000000748AE8: CC1A4005 1C167327
	v_fmac_f32_e32 v22, v21, v5                                // 000000748AF0: 562C0B15
	s_clause 0x3                                               // 000000748AF4: BF850003
	global_load_b128 v[5:8], v[36:37], off                     // 000000748AF8: DC5E0000 057C0024
	global_load_b128 v[28:31], v[36:37], off offset:16         // 000000748B00: DC5E0010 1C7C0024
	global_load_b128 v[32:35], v[36:37], off offset:32         // 000000748B08: DC5E0020 207C0024
	global_load_b128 v[36:39], v[36:37], off offset:48         // 000000748B10: DC5E0030 247C0024
	s_waitcnt vmcnt(3)                                         // 000000748B18: BF890FF7
	v_dot2_f32_bf16 v5, v5, v42, 0                             // 000000748B1C: CC1A4005 1A025505
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000748B24: BF870091
	v_dot2_f32_bf16 v5, v6, v43, v5                            // 000000748B28: CC1A4005 1C165706
	v_dot2_f32_bf16 v5, v7, v44, v5                            // 000000748B30: CC1A4005 1C165907
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000748B38: BF8700A1
	v_dot2_f32_bf16 v5, v8, v45, v5                            // 000000748B3C: CC1A4005 1C165B08
	s_waitcnt vmcnt(2)                                         // 000000748B44: BF890BF7
	v_dot2_f32_bf16 v5, v28, v46, v5                           // 000000748B48: CC1A4005 1C165D1C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000748B50: BF870091
	v_dot2_f32_bf16 v5, v29, v47, v5                           // 000000748B54: CC1A4005 1C165F1D
	v_dot2_f32_bf16 v5, v30, v48, v5                           // 000000748B5C: CC1A4005 1C16611E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000748B64: BF8700A1
	v_dot2_f32_bf16 v5, v31, v49, v5                           // 000000748B68: CC1A4005 1C16631F
	s_waitcnt vmcnt(1)                                         // 000000748B70: BF8907F7
	v_dot2_f32_bf16 v5, v32, v50, v5                           // 000000748B74: CC1A4005 1C166520
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000748B7C: BF870091
	v_dot2_f32_bf16 v5, v33, v51, v5                           // 000000748B80: CC1A4005 1C166721
	v_dot2_f32_bf16 v5, v34, v52, v5                           // 000000748B88: CC1A4005 1C166922
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000748B90: BF8700A1
	v_dot2_f32_bf16 v5, v35, v53, v5                           // 000000748B94: CC1A4005 1C166B23
	s_waitcnt vmcnt(0)                                         // 000000748B9C: BF8903F7
	v_dot2_f32_bf16 v5, v36, v54, v5                           // 000000748BA0: CC1A4005 1C166D24
	.long 0xd7006a24                                           // 000000748BA8: D7006A24
	v_cndmask_b32_e32 v0, v40, v4, vcc_lo                      // 000000748BAC: 02000928
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000748BB0: BF870122
	v_dot2_f32_bf16 v5, v37, v55, v5                           // 000000748BB4: CC1A4005 1C166F25
	v_add_co_ci_u32_e64 v37, null, s5, v41, vcc_lo             // 000000748BBC: D5207C25 01AA5205
	v_dot2_f32_bf16 v5, v38, v56, v5                           // 000000748BC4: CC1A4005 1C167126
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000748BCC: BF870091
	v_dot2_f32_bf16 v5, v39, v57, v5                           // 000000748BD0: CC1A4005 1C167327
	v_fmac_f32_e32 v24, v21, v5                                // 000000748BD8: 56300B15
	s_clause 0x3                                               // 000000748BDC: BF850003
	global_load_b128 v[5:8], v[36:37], off                     // 000000748BE0: DC5E0000 057C0024
	global_load_b128 v[28:31], v[36:37], off offset:16         // 000000748BE8: DC5E0010 1C7C0024
	global_load_b128 v[32:35], v[36:37], off offset:32         // 000000748BF0: DC5E0020 207C0024
	global_load_b128 v[36:39], v[36:37], off offset:48         // 000000748BF8: DC5E0030 247C0024
	s_waitcnt vmcnt(3)                                         // 000000748C00: BF890FF7
	v_dot2_f32_bf16 v5, v5, v42, 0                             // 000000748C04: CC1A4005 1A025505
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000748C0C: BF870091
	v_dot2_f32_bf16 v5, v6, v43, v5                            // 000000748C10: CC1A4005 1C165706
	v_dot2_f32_bf16 v5, v7, v44, v5                            // 000000748C18: CC1A4005 1C165907
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000748C20: BF8700A1
	v_dot2_f32_bf16 v5, v8, v45, v5                            // 000000748C24: CC1A4005 1C165B08
	s_waitcnt vmcnt(2)                                         // 000000748C2C: BF890BF7
	v_dot2_f32_bf16 v5, v28, v46, v5                           // 000000748C30: CC1A4005 1C165D1C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000748C38: BF870091
	v_dot2_f32_bf16 v5, v29, v47, v5                           // 000000748C3C: CC1A4005 1C165F1D
	v_dot2_f32_bf16 v5, v30, v48, v5                           // 000000748C44: CC1A4005 1C16611E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000748C4C: BF8700A1
	v_dot2_f32_bf16 v5, v31, v49, v5                           // 000000748C50: CC1A4005 1C16631F
	s_waitcnt vmcnt(1)                                         // 000000748C58: BF8907F7
	v_dot2_f32_bf16 v5, v32, v50, v5                           // 000000748C5C: CC1A4005 1C166520
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000748C64: BF870091
	v_dot2_f32_bf16 v5, v33, v51, v5                           // 000000748C68: CC1A4005 1C166721
	v_dot2_f32_bf16 v5, v34, v52, v5                           // 000000748C70: CC1A4005 1C166922
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000748C78: BF8700A1
	v_dot2_f32_bf16 v5, v35, v53, v5                           // 000000748C7C: CC1A4005 1C166B23
	s_waitcnt vmcnt(0)                                         // 000000748C84: BF8903F7
	v_dot2_f32_bf16 v5, v36, v54, v5                           // 000000748C88: CC1A4005 1C166D24
	.long 0xd7006a24                                           // 000000748C90: D7006A24
	v_cndmask_b32_e32 v0, v40, v16, vcc_lo                     // 000000748C94: 02002128
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000748C98: BF870122
	v_dot2_f32_bf16 v5, v37, v55, v5                           // 000000748C9C: CC1A4005 1C166F25
	v_add_co_ci_u32_e64 v37, null, s14, v41, vcc_lo            // 000000748CA4: D5207C25 01AA520E
	v_dot2_f32_bf16 v5, v38, v56, v5                           // 000000748CAC: CC1A4005 1C167126
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000748CB4: BF870091
	v_dot2_f32_bf16 v5, v39, v57, v5                           // 000000748CB8: CC1A4005 1C167327
	v_fmac_f32_e32 v23, v21, v5                                // 000000748CC0: 562E0B15
	s_clause 0x3                                               // 000000748CC4: BF850003
	global_load_b128 v[5:8], v[36:37], off                     // 000000748CC8: DC5E0000 057C0024
	global_load_b128 v[28:31], v[36:37], off offset:16         // 000000748CD0: DC5E0010 1C7C0024
	global_load_b128 v[32:35], v[36:37], off offset:32         // 000000748CD8: DC5E0020 207C0024
	global_load_b128 v[36:39], v[36:37], off offset:48         // 000000748CE0: DC5E0030 247C0024
	s_waitcnt vmcnt(3)                                         // 000000748CE8: BF890FF7
	v_dot2_f32_bf16 v5, v5, v42, 0                             // 000000748CEC: CC1A4005 1A025505
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000748CF4: BF870121
	v_dot2_f32_bf16 v5, v6, v43, v5                            // 000000748CF8: CC1A4005 1C165706
	v_mov_b32_e32 v6, v2                                       // 000000748D00: 7E0C0302
	v_dot2_f32_bf16 v5, v7, v44, v5                            // 000000748D04: CC1A4005 1C165907
	v_mov_b32_e32 v7, v3                                       // 000000748D0C: 7E0E0303
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000748D10: BF870132
	v_dot2_f32_bf16 v5, v8, v45, v5                            // 000000748D14: CC1A4005 1C165B08
	v_mov_b32_e32 v8, v4                                       // 000000748D1C: 7E100304
	s_waitcnt vmcnt(2)                                         // 000000748D20: BF890BF7
	v_dot2_f32_bf16 v5, v28, v46, v5                           // 000000748D24: CC1A4005 1C165D1C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000748D2C: BF870091
	v_dot2_f32_bf16 v5, v29, v47, v5                           // 000000748D30: CC1A4005 1C165F1D
	v_dot2_f32_bf16 v5, v30, v48, v5                           // 000000748D38: CC1A4005 1C16611E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000748D40: BF8700A1
	v_dot2_f32_bf16 v5, v31, v49, v5                           // 000000748D44: CC1A4005 1C16631F
	s_waitcnt vmcnt(1)                                         // 000000748D4C: BF8907F7
	v_dot2_f32_bf16 v5, v32, v50, v5                           // 000000748D50: CC1A4005 1C166520
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000748D58: BF870091
	v_dot2_f32_bf16 v5, v33, v51, v5                           // 000000748D5C: CC1A4005 1C166721
	v_dot2_f32_bf16 v5, v34, v52, v5                           // 000000748D64: CC1A4005 1C166922
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000748D6C: BF8700A1
	v_dot2_f32_bf16 v5, v35, v53, v5                           // 000000748D70: CC1A4005 1C166B23
	s_waitcnt vmcnt(0)                                         // 000000748D78: BF8903F7
	v_dot2_f32_bf16 v5, v36, v54, v5                           // 000000748D7C: CC1A4005 1C166D24
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000748D84: BF870091
	v_dot2_f32_bf16 v5, v37, v55, v5                           // 000000748D88: CC1A4005 1C166F25
	v_dot2_f32_bf16 v5, v38, v56, v5                           // 000000748D90: CC1A4005 1C167126
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000748D98: BF870091
	v_dot2_f32_bf16 v5, v39, v57, v5                           // 000000748D9C: CC1A4005 1C167327
	v_fmac_f32_e32 v17, v21, v5                                // 000000748DA4: 56220B15
	v_mov_b32_e32 v5, v1                                       // 000000748DA8: 7E0A0301
	v_mov_b32_e32 v21, v27                                     // 000000748DAC: 7E2A031B
	s_and_not1_b32 exec_lo, exec_lo, s15                       // 000000748DB0: 917E0F7E
	s_cbranch_execz 31                                         // 000000748DB4: BFA5001F <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb1ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x834>
	s_waitcnt vmcnt(0)                                         // 000000748DB8: BF8903F7
	v_dual_mov_b32 v1, v5 :: v_dual_add_nc_u32 v10, 32, v10    // 000000748DBC: CA200105 010A14A0
	v_dual_mov_b32 v2, v6 :: v_dual_mov_b32 v3, v7             // 000000748DC4: CA100106 02020107
	v_mov_b32_e32 v4, v8                                       // 000000748DCC: 7E080308
	s_mov_b32 s17, exec_lo                                     // 000000748DD0: BE91007E
	s_delay_alu instid0(VALU_DEP_3)                            // 000000748DD4: BF870003
	v_cmp_ge_i32_e32 vcc_lo, v10, v18                          // 000000748DD8: 7C8C250A
	.long 0xd4c1007e                                           // 000000748DDC: D4C1007E
	v_cndmask_b32_e32 v1, v10, v18, vcc_lo                     // 000000748DE0: 0202250A
	s_cbranch_execz 65173                                      // 000000748DE4: BFA5FE95 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb1ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x23c>
	v_ashrrev_i32_e32 v2, 31, v26                              // 000000748DE8: 3404349F
	v_ashrrev_i32_e32 v4, 31, v25                              // 000000748DEC: 3408329F
	.long 0xd7000001                                           // 000000748DF0: D7000001
	v_cndmask_b32_e32 v1, v11, v26, vcc_lo                     // 000000748DF4: 0202350B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000748DF8: BF8700A1
	v_add_co_ci_u32_e64 v2, null, v20, v2, s0                  // 000000748DFC: D5207C02 00020514
	.long 0xd7000003                                           // 000000748E04: D7000003
	v_cndmask_b32_e32 v1, v9, v25, vcc_lo                      // 000000748E08: 02023309
	v_add_co_ci_u32_e64 v4, null, v19, v4, s0                  // 000000748E0C: D5207C04 00020913
	s_clause 0x1                                               // 000000748E14: BF850001
	global_load_d16_b16 v13, v[1:2], off                       // 000000748E18: DC820000 0D7C0001
	global_load_b128 v[1:4], v[3:4], off                       // 000000748E20: DC5E0000 017C0003
	s_waitcnt vmcnt(1)                                         // 000000748E28: BF8907F7
	v_cvt_f32_f16_e32 v27, v13                                 // 000000748E2C: 7E36170D
	s_branch 65154                                             // 000000748E30: BFA0FE82 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb1ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x23c>
	s_or_b32 exec_lo, exec_lo, s15                             // 000000748E34: 8C7E0F7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000748E38: BF8700B9
	s_or_b32 exec_lo, exec_lo, s1                              // 000000748E3C: 8C7E017E
	.long 0xd71f0001                                           // 000000748E40: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 000000748E44: 020100C1
	s_mov_b32 s0, exec_lo                                      // 000000748E48: BE80007E
	v_xor_b32_e32 v2, 16, v1                                   // 000000748E4C: 3A040290
	s_waitcnt vmcnt(0)                                         // 000000748E50: BF8903F7
	v_xor_b32_e32 v6, 8, v1                                    // 000000748E54: 3A0C0288
	v_xor_b32_e32 v10, 4, v1                                   // 000000748E58: 3A140284
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000748E5C: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 000000748E60: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 000000748E64: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v6                            // 000000748E68: 7C980CA0
	s_delay_alu instid0(VALU_DEP_2)                            // 000000748E6C: BF870002
	v_lshlrev_b32_e32 v2, 2, v2                                // 000000748E70: 30040482
	ds_bpermute_b32 v5, v2, v23                                // 000000748E74: DACC0000 05001702
	s_waitcnt lgkmcnt(0)                                       // 000000748E7C: BF89FC07
	v_add_f32_e32 v5, v23, v5                                  // 000000748E80: 060A0B17
	ds_bpermute_b32 v3, v2, v22                                // 000000748E84: DACC0000 03001602
	ds_bpermute_b32 v4, v2, v24                                // 000000748E8C: DACC0000 04001802
	ds_bpermute_b32 v2, v2, v17                                // 000000748E94: DACC0000 02001102
	s_waitcnt lgkmcnt(2)                                       // 000000748E9C: BF89FC27
	v_dual_add_f32 v3, v22, v3 :: v_dual_cndmask_b32 v6, v1, v6// 000000748EA0: C9120716 03060D01
	s_waitcnt lgkmcnt(0)                                       // 000000748EA8: BF89FC07
	v_add_f32_e32 v2, v17, v2                                  // 000000748EAC: 06040511
	v_cmp_gt_u32_e32 vcc_lo, 32, v10                           // 000000748EB0: 7C9814A0
	s_delay_alu instid0(VALU_DEP_3)                            // 000000748EB4: BF870003
	v_lshlrev_b32_e32 v6, 2, v6                                // 000000748EB8: 300C0C82
	v_cndmask_b32_e32 v10, v1, v10, vcc_lo                     // 000000748EBC: 02141501
	ds_bpermute_b32 v9, v6, v5                                 // 000000748EC0: DACC0000 09000506
	s_waitcnt lgkmcnt(0)                                       // 000000748EC8: BF89FC07
	v_add_f32_e32 v5, v5, v9                                   // 000000748ECC: 060A1305
	ds_bpermute_b32 v7, v6, v3                                 // 000000748ED0: DACC0000 07000306
	s_waitcnt lgkmcnt(0)                                       // 000000748ED8: BF89FC07
	v_dual_add_f32 v3, v3, v7 :: v_dual_lshlrev_b32 v10, 2, v10// 000000748EDC: C9220F03 030A1482
	v_add_f32_e32 v4, v24, v4                                  // 000000748EE4: 06080918
	ds_bpermute_b32 v8, v6, v4                                 // 000000748EE8: DACC0000 08000406
	ds_bpermute_b32 v6, v6, v2                                 // 000000748EF0: DACC0000 06000206
	s_waitcnt lgkmcnt(0)                                       // 000000748EF8: BF89FC07
	v_add_f32_e32 v2, v2, v6                                   // 000000748EFC: 06040D02
	ds_bpermute_b32 v6, v10, v3                                // 000000748F00: DACC0000 0600030A
	s_waitcnt lgkmcnt(0)                                       // 000000748F08: BF89FC07
	v_dual_add_f32 v3, v3, v6 :: v_dual_add_f32 v4, v4, v8     // 000000748F0C: C9080D03 03041104
	ds_bpermute_b32 v8, v10, v5                                // 000000748F14: DACC0000 0800050A
	s_waitcnt lgkmcnt(0)                                       // 000000748F1C: BF89FC07
	v_add_f32_e32 v5, v5, v8                                   // 000000748F20: 060A1105
	ds_bpermute_b32 v7, v10, v4                                // 000000748F24: DACC0000 0700040A
	ds_bpermute_b32 v9, v10, v2                                // 000000748F2C: DACC0000 0900020A
	v_xor_b32_e32 v10, 2, v1                                   // 000000748F34: 3A140282
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000748F38: BF8700A1
	v_cmp_gt_u32_e32 vcc_lo, 32, v10                           // 000000748F3C: 7C9814A0
	v_cndmask_b32_e32 v10, v1, v10, vcc_lo                     // 000000748F40: 02141501
	v_lshlrev_b32_e32 v10, 2, v10                              // 000000748F44: 30141482
	s_waitcnt lgkmcnt(0)                                       // 000000748F48: BF89FC07
	v_add_f32_e32 v6, v2, v9                                   // 000000748F4C: 060C1302
	ds_bpermute_b32 v2, v10, v3                                // 000000748F50: DACC0000 0200030A
	v_add_f32_e32 v4, v4, v7                                   // 000000748F58: 06080F04
	ds_bpermute_b32 v8, v10, v5                                // 000000748F5C: DACC0000 0800050A
	ds_bpermute_b32 v9, v10, v6                                // 000000748F64: DACC0000 0900060A
	ds_bpermute_b32 v7, v10, v4                                // 000000748F6C: DACC0000 0700040A
	v_xor_b32_e32 v10, 1, v1                                   // 000000748F74: 3A140281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000748F78: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v10                           // 000000748F7C: 7C9814A0
	v_cndmask_b32_e32 v1, v1, v10, vcc_lo                      // 000000748F80: 02021501
	s_waitcnt lgkmcnt(3)                                       // 000000748F84: BF89FC37
	v_dual_add_f32 v1, v3, v2 :: v_dual_lshlrev_b32 v10, 2, v1 // 000000748F88: C9220503 010A0282
	s_waitcnt lgkmcnt(2)                                       // 000000748F90: BF89FC27
	v_add_f32_e32 v3, v5, v8                                   // 000000748F94: 06061105
	s_waitcnt lgkmcnt(0)                                       // 000000748F98: BF89FC07
	v_dual_add_f32 v5, v6, v9 :: v_dual_add_f32 v2, v4, v7     // 000000748F9C: C9081306 05020F04
	ds_bpermute_b32 v4, v10, v1                                // 000000748FA4: DACC0000 0400010A
	ds_bpermute_b32 v7, v10, v3                                // 000000748FAC: DACC0000 0700030A
	ds_bpermute_b32 v8, v10, v5                                // 000000748FB4: DACC0000 0800050A
	ds_bpermute_b32 v6, v10, v2                                // 000000748FBC: DACC0000 0600020A
	v_cmpx_eq_u32_e32 0, v16                                   // 000000748FC4: 7D942080
	s_cbranch_execz 9                                          // 000000748FC8: BFA50009 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb1ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x9f0>
	s_waitcnt lgkmcnt(1)                                       // 000000748FCC: BF89FC17
	v_dual_add_f32 v8, v5, v8 :: v_dual_add_f32 v7, v3, v7     // 000000748FD0: C9081105 08060F03
	s_waitcnt lgkmcnt(0)                                       // 000000748FD8: BF89FC07
	v_dual_add_f32 v6, v2, v6 :: v_dual_add_f32 v5, v1, v4     // 000000748FDC: C9080D02 06040901
	v_lshlrev_b32_e32 v1, 4, v15                               // 000000748FE4: 30021E84
	ds_store_b128 v1, v[5:8] offset:1024                       // 000000748FE8: DB7C0400 00000501
	s_or_b32 exec_lo, exec_lo, s0                              // 000000748FF0: 8C7E007E
	.long 0xd4510000                                           // 000000748FF4: D4510000
	v_cndmask_b32_e32 v0, s2, v12, vcc_lo                      // 000000748FF8: 02001802
	v_cmp_gt_u32_e32 vcc_lo, 4, v0                             // 000000748FFC: 7C980084
	s_waitcnt lgkmcnt(0)                                       // 000000749000: BF89FC07
	s_barrier                                                  // 000000749004: BFBD0000
	buffer_gl0_inv                                             // 000000749008: E0AC0000 00000000
	s_and_b32 s0, vcc_lo, s0                                   // 000000749010: 8B00006A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000749014: BF870009
	s_and_saveexec_b32 s1, s0                                  // 000000749018: BE812000
	s_cbranch_execz 44                                         // 00000074901C: BFA5002C <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb1ELi0ELi0EEEvPKhPKtPvlllllS6_f+0xad0>
	v_add_nc_u32_e32 v7, 0x400, v14                            // 000000749020: 4A0E1CFF 00000400
	s_lshl_b64 s[0:1], s[2:3], 2                               // 000000749028: 84808202
	ds_load_2addr_b32 v[1:2], v7 offset1:4                     // 00000074902C: D8DC0400 01000007
	ds_load_2addr_b32 v[3:4], v7 offset0:8 offset1:12          // 000000749034: D8DC0C08 03000007
	ds_load_2addr_b32 v[5:6], v7 offset0:16 offset1:20         // 00000074903C: D8DC1410 05000007
	s_waitcnt lgkmcnt(2)                                       // 000000749044: BF89FC27
	v_add_f32_e32 v1, 0, v1                                    // 000000749048: 06020280
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000074904C: BF870131
	v_add_f32_e32 v9, v1, v2                                   // 000000749050: 06120501
	v_mad_u64_u32 v[1:2], null, s12, v0, 0                     // 000000749054: D6FE7C01 0202000C
	s_waitcnt lgkmcnt(1)                                       // 00000074905C: BF89FC17
	v_add_f32_e32 v3, v9, v3                                   // 000000749060: 06060709
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000749064: BF8700D1
	v_add_f32_e32 v4, v3, v4                                   // 000000749068: 06080903
	ds_load_2addr_b32 v[7:8], v7 offset0:24 offset1:28         // 00000074906C: D8DC1C18 07000007
	v_mad_u64_u32 v[2:3], null, s13, v0, v[2:3]                // 000000749074: D6FE7C02 040A000D
	s_waitcnt lgkmcnt(1)                                       // 00000074907C: BF89FC17
	v_add_f32_e32 v0, v4, v5                                   // 000000749080: 06000B04
	v_add_f32_e32 v3, v0, v6                                   // 000000749084: 06060D00
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000749088: BF870093
	.long 0xd73c0000                                           // 00000074908C: D73C0000
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 000000749090: 02020282
	.long 0xd7006a00                                           // 000000749094: D7006A00
	v_cndmask_b32_e32 v1, s8, v0, vcc_lo                       // 000000749098: 02020008
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000074909C: BF8701B1
	v_add_co_ci_u32_e64 v1, null, s9, v1, vcc_lo               // 0000007490A0: D5207C01 01AA0209
	s_waitcnt lgkmcnt(0)                                       // 0000007490A8: BF89FC07
	v_add_f32_e32 v2, v3, v7                                   // 0000007490AC: 06040F03
	.long 0xd7006a00                                           // 0000007490B0: D7006A00
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 0000007490B4: 02000100
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007490B8: BF870191
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 0000007490BC: D5207C01 01AA0201
	v_add_f32_e32 v2, v2, v8                                   // 0000007490C4: 06041102
	global_store_b32 v[0:1], v2, off                           // 0000007490C8: DC6A0000 007C0200
	s_endpgm                                                   // 0000007490D0: BFB00000
		...

