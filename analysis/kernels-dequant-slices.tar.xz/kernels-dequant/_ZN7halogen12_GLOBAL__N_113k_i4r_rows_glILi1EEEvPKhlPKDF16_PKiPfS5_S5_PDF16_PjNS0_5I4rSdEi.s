0000000000ded900 <_ZN7halogen12_GLOBAL__N_113k_i4r_rows_glILi1EEEvPKhlPKDF16_PKiPfS5_S5_PDF16_PjNS0_5I4rSdEi>:
; _ZN7halogen12_GLOBAL__N_113k_i4r_rows_glILi1EEEvPKhlPKDF16_PKiPfS5_S5_PDF16_PjNS0_5I4rSdEi():
	s_clause 0x1                                               // 000000DED900: BF850001
	s_load_b32 s3, s[0:1], 0xa0                                // 000000DED904: F40000C0 F80000A0
	s_load_b512 s[12:27], s[0:1], 0x40                         // 000000DED90C: F4100300 F8000040
	s_mov_b32 s4, -1                                           // 000000DED914: BE8400C1
	s_waitcnt lgkmcnt(0)                                       // 000000DED918: BF89FC07
	s_cmp_lt_i32 s2, s3                                        // 000000DED91C: BF040302
	s_cbranch_scc1 2236                                        // 000000DED920: BFA208BC <_ZN7halogen12_GLOBAL__N_113k_i4r_rows_glILi1EEEvPKhlPKDF16_PKiPfS5_S5_PDF16_PjNS0_5I4rSdEi+0x2314>
	s_load_b64 s[10:11], s[0:1], 0x94                          // 000000DED924: F4040280 F8000094
	s_sub_i32 s3, s2, s3                                       // 000000DED92C: 81830302
	s_clause 0x1                                               // 000000DED930: BF850001
	s_load_b128 s[28:31], s[0:1], 0x88                         // 000000DED934: F4080700 F8000088
	s_load_b64 s[36:37], s[0:1], 0x80                          // 000000DED93C: F4040900 F8000080
	v_lshrrev_b32_e32 v8, 5, v0                                // 000000DED944: 32100085
	v_and_b32_e32 v9, 31, v0                                   // 000000DED948: 3612009F
	s_mov_b32 s40, 0                                           // 000000DED94C: BEA80080
	s_mov_b32 s38, exec_lo                                     // 000000DED950: BEA6007E
	s_waitcnt lgkmcnt(0)                                       // 000000DED954: BF89FC07
	s_abs_i32 s4, s11                                          // 000000DED958: BE84150B
	s_ashr_i32 s7, s11, 31                                     // 000000DED95C: 86079F0B
	s_cvt_f32_u32 s5, s4                                       // 000000DED960: BE856504
	s_sub_i32 s6, 0, s4                                        // 000000DED964: 81860480
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000DED968: BF87029A
	v_rcp_iflag_f32_e32 v1, s5                                 // 000000DED96C: 7E025605
	v_readfirstlane_b32 s5, v1                                 // 000000DED970: 7E0A0501
	s_mul_f32 s5, s5, 0x4f7ffffe                               // 000000DED974: A205FF05 4F7FFFFE
	s_delay_alu instid0(SALU_CYCLE_3) | instskip(NEXT) | instid1(SALU_CYCLE_3)// 000000DED97C: BF87059B
	s_cvt_u32_f32 s5, s5                                       // 000000DED980: BE856705
	s_mul_i32 s6, s6, s5                                       // 000000DED984: 96060506
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000DED988: BF870499
	s_mul_hi_u32 s6, s5, s6                                    // 000000DED98C: 96860605
	s_add_i32 s5, s5, s6                                       // 000000DED990: 81050605
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000DED994: BF870499
	s_mul_hi_u32 s5, s3, s5                                    // 000000DED998: 96850503
	s_mul_i32 s6, s5, s4                                       // 000000DED99C: 96060405
	s_add_i32 s8, s5, 1                                        // 000000DED9A0: 81088105
	s_sub_i32 s6, s3, s6                                       // 000000DED9A4: 81860603
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000DED9A8: BF870009
	s_sub_i32 s9, s6, s4                                       // 000000DED9AC: 81890406
	s_cmp_ge_u32 s6, s4                                        // 000000DED9B0: BF090406
	s_cselect_b32 s5, s8, s5                                   // 000000DED9B4: 98050508
	s_cselect_b32 s6, s9, s6                                   // 000000DED9B8: 98060609
	s_add_i32 s8, s5, 1                                        // 000000DED9BC: 81088105
	s_cmp_ge_u32 s6, s4                                        // 000000DED9C0: BF090406
	s_cselect_b32 s4, s8, s5                                   // 000000DED9C4: 98040508
	s_ashr_i32 s33, s30, 31                                    // 000000DED9C8: 86219F1E
	s_xor_b32 s4, s4, s7                                       // 000000DED9CC: 8D040704
	s_lshr_b32 s5, s33, 25                                     // 000000DED9D0: 85059921
	s_sub_i32 s34, s4, s7                                      // 000000DED9D4: 81A20704
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000DED9D8: BF870499
	s_mul_i32 s4, s34, s11                                     // 000000DED9DC: 96040B22
	s_sub_i32 s31, s3, s4                                      // 000000DED9E0: 819F0403
	s_add_i32 s3, s30, s5                                      // 000000DED9E4: 8103051E
	s_mul_i32 s35, s31, s10                                    // 000000DED9E8: 96230A1F
	s_ashr_i32 s3, s3, 7                                       // 000000DED9EC: 86038703
	s_add_i32 s4, s35, s10                                     // 000000DED9F0: 81040A23
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000DED9F4: BF870499
	s_min_i32 s3, s3, s4                                       // 000000DED9F8: 89030403
	s_sub_i32 s39, s3, s35                                     // 000000DED9FC: 81A72303
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000DEDA00: BF870009
	.long 0xd4c4007e                                           // 000000DEDA04: D4C4007E
	v_cndmask_b32_e32 v1, s39, v8, vcc_lo                      // 000000DEDA08: 02021027
	s_cbranch_execz 503                                        // 000000DEDA0C: BFA501F7 <_ZN7halogen12_GLOBAL__N_113k_i4r_rows_glILi1EEEvPKhlPKDF16_PKiPfS5_S5_PDF16_PjNS0_5I4rSdEi+0x8ec>
	s_add_i32 s41, s28, -1                                     // 000000DEDA10: 8129C11C
	s_cmp_lg_u64 s[22:23], 0                                   // 000000DEDA14: BF118016
	v_dual_mov_b32 v10, v8 :: v_dual_and_b32 v1, 1, v0         // 000000DEDA18: CA240108 0A000081
	s_cselect_b32 s42, -1, 0                                   // 000000DEDA20: 982A80C1
	s_abs_i32 s43, s39                                         // 000000DEDA24: BEAB1527
	v_and_b32_e32 v2, 2, v0                                    // 000000DEDA28: 36040082
	s_cvt_f32_u32 s3, s43                                      // 000000DEDA2C: BE83652B
	v_lshlrev_b32_e32 v6, 3, v9                                // 000000DEDA30: 300C1283
	v_lshlrev_b32_e32 v7, 7, v8                                // 000000DEDA34: 300E1087
	v_and_b32_e32 v3, 4, v0                                    // 000000DEDA38: 36060084
	v_rcp_iflag_f32_e32 v4, s3                                 // 000000DEDA3C: 7E085603
	v_and_b32_e32 v5, 8, v0                                    // 000000DEDA40: 360A0088
	.long 0xd44a0004                                           // 000000DEDA44: D44A0004
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 000000DEDA48: 02020280
	.long 0xd44a0005                                           // 000000DEDA4C: D44A0005
	v_cndmask_b32_e32 v1, 0, v2, vcc_lo                        // 000000DEDA50: 02020480
	v_lshl_or_b32 v1, v8, 8, v6                                // 000000DEDA54: D6560001 04191108
	v_lshl_add_u32 v2, s35, 7, v7                              // 000000DEDA5C: D6460002 041D0E23
	s_ashr_i32 s45, s39, 31                                    // 000000DEDA64: 862D9F27
	s_sub_i32 s47, 0, s43                                      // 000000DEDA68: 81AF2B80
	s_mul_i32 s10, s45, 0x1400                                 // 000000DEDA6C: 960AFF2D 00001400
	.long 0xd44c0003                                           // 000000DEDA74: D44C0003
	v_cndmask_b32_e32 v1, 16, v9, vcc_lo                       // 000000DEDA78: 02021290
	v_readfirstlane_b32 s7, v4                                 // 000000DEDA7C: 7E0E0504
	.long 0xd44a0006                                           // 000000DEDA80: D44A0006
	v_cndmask_b32_e32 v1, 0, v3, vcc_lo                        // 000000DEDA84: 02020680
	v_subrev_nc_u32_e32 v11, s10, v1                           // 000000DEDA88: 4E16020A
	v_lshl_or_b32 v1, v9, 2, v2                                // 000000DEDA8C: D6560001 04090509
	s_lshl_b32 s8, s39, 7                                      // 000000DEDA94: 84088727
	s_mul_f32 s9, s7, 0x4f7ffffe                               // 000000DEDA98: A209FF07 4F7FFFFE
	.long 0xd44a0007                                           // 000000DEDAA0: D44A0007
	v_cndmask_b32_e32 v1, 0, v5, vcc_lo                        // 000000DEDAA4: 02020A80
	s_mov_b32 s44, 0x76543210                                  // 000000DEDAA8: BEAC00FF 76543210
	s_lshl_b32 s46, s39, 8                                     // 000000DEDAB0: 842E8827
	s_cvt_u32_f32 s9, s9                                       // 000000DEDAB4: BE896709
	s_mov_b32 s49, 0x3db504f3                                  // 000000DEDAB8: BEB100FF 3DB504F3
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000DEDAC0: BF87049A
	s_mul_i32 s47, s47, s9                                     // 000000DEDAC4: 962F092F
	s_mul_hi_u32 s10, s9, s47                                  // 000000DEDAC8: 968A2F09
	s_sub_i32 s47, 0, s8                                       // 000000DEDACC: 81AF0880
	s_add_i32 s48, s9, s10                                     // 000000DEDAD0: 81300A09
	s_branch 164                                               // 000000DEDAD4: BFA000A4 <_ZN7halogen12_GLOBAL__N_113k_i4r_rows_glILi1EEEvPKhlPKDF16_PKiPfS5_S5_PDF16_PjNS0_5I4rSdEi+0x468>
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DEDAD8: BF870091
	.long 0xd7006a02                                           // 000000DEDADC: D7006A02
	v_cndmask_b32_e32 v1, s16, v2, vcc_lo                      // 000000DEDAE0: 02020410
	v_add_co_ci_u32_e64 v3, null, s17, v3, vcc_lo              // 000000DEDAE4: D5207C03 01AA0611
	v_add_nc_u32_e32 v1, 0x400, v1                             // 000000DEDAEC: 4A0202FF 00000400
	v_add_nc_u32_e32 v10, 8, v10                               // 000000DEDAF4: 4A141488
	global_load_d16_b16 v2, v[2:3], off offset:6               // 000000DEDAF8: DC820006 027C0002
	v_cmp_le_i32_e32 vcc_lo, s39, v10                          // 000000DEDB00: 7C861427
	s_or_b32 s40, vcc_lo, s40                                  // 000000DEDB04: 8C28286A
	s_waitcnt vmcnt(0)                                         // 000000DEDB08: BF8903F7
	v_fma_mix_f32 v5, v16, v2, v14 op_sel_hi:[0,1,0]           // 000000DEDB0C: CC200005 143A0510
	v_sub_f32_e32 v4, v17, v15                                 // 000000DEDB14: 08081F11
	v_fma_mix_f32 v2, -v16, v2, v14 op_sel_hi:[0,1,0]          // 000000DEDB18: CC200002 343A0510
	v_add_f32_e32 v3, v17, v15                                 // 000000DEDB20: 06061F11
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000DEDB24: BF8701A2
	v_add_f32_e32 v7, v4, v2                                   // 000000DEDB28: 060E0504
	v_sub_f32_e32 v2, v4, v2                                   // 000000DEDB2C: 08040504
	v_add_f32_e32 v6, v3, v5                                   // 000000DEDB30: 060C0B03
	v_sub_f32_e32 v3, v3, v5                                   // 000000DEDB34: 08060B03
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DEDB38: BF870193
	v_mov_b32_dpp v15, v2 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DEDB3C: 7E1E02FA FF016102
	v_mov_b32_dpp v4, v6 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DEDB44: 7E0802FA FF016106
	v_cndmask_b32_e64 v6, -v6, v6, s4                          // 000000DEDB4C: D5010006 20120D06
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000DEDB54: BF870234
	v_mov_b32_dpp v14, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DEDB58: 7E1C02FA FF016103
	v_cndmask_b32_e64 v2, -v2, v2, s4                          // 000000DEDB60: D5010002 20120502
	v_cndmask_b32_e64 v3, -v3, v3, s4                          // 000000DEDB68: D5010003 20120703
	v_add_f32_e32 v4, v6, v4                                   // 000000DEDB70: 06080906
	v_mov_b32_dpp v5, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DEDB74: 7E0A02FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, s4                          // 000000DEDB7C: D5010007 20120F07
	.long 0xd72c0006                                           // 000000DEDB84: D72C0006
	v_cndmask_b32_e32 v1, 0x1400, v13, vcc_lo                  // 000000DEDB88: 02021AFF 00001400
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000DEDB90: BF870242
	v_dual_add_f32 v2, v2, v15 :: v_dual_add_f32 v5, v7, v5    // 000000DEDB94: C9081F02 02040B07
	v_mov_b32_dpp v7, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DEDB9C: 7E0E02FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, s5                          // 000000DEDBA4: D5010004 20160904
	v_add_f32_e32 v3, v3, v14                                  // 000000DEDBAC: 06061D03
	v_mov_b32_dpp v15, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DEDBB0: 7E1E02FA FF016202
	v_mov_b32_dpp v13, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DEDBB8: 7E1A02FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, s5                          // 000000DEDBC0: D5010005 20160B05
	v_cndmask_b32_e64 v2, -v2, v2, s5                          // 000000DEDBC8: D5010002 20160502
	v_add_f32_e32 v4, v4, v7                                   // 000000DEDBD0: 06080F04
	v_mov_b32_dpp v14, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DEDBD4: 7E1C02FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, s5                          // 000000DEDBDC: D5010003 20160703
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DEDBE4: BF870004
	v_dual_add_f32 v5, v5, v13 :: v_dual_add_f32 v2, v2, v15   // 000000DEDBE8: C9081B05 05021F02
	.long 0xd72c0007                                           // 000000DEDBF0: D72C0007
	v_cndmask_b32_e32 v1, s46, v12, vcc_lo                     // 000000DEDBF4: 0202182E
	v_mov_b32_dpp v12, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DEDBF8: 7E1802FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s6                          // 000000DEDC00: D5010004 201A0904
	v_add_f32_e32 v3, v3, v14                                  // 000000DEDC08: 06061D03
	v_mov_b32_dpp v13, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DEDC0C: 7E1A02FA FF016405
	v_cndmask_b32_e64 v5, -v5, v5, s6                          // 000000DEDC14: D5010005 201A0B05
	v_mov_b32_dpp v15, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DEDC1C: 7E1E02FA FF016402
	v_cndmask_b32_e64 v2, -v2, v2, s6                          // 000000DEDC24: D5010002 201A0502
	v_add_f32_e32 v4, v4, v12                                  // 000000DEDC2C: 06081904
	v_mov_b32_dpp v14, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DEDC30: 7E1C02FA FF016403
	v_cndmask_b32_e64 v3, -v3, v3, s6                          // 000000DEDC38: D5010003 201A0703
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DEDC40: BF870214
	v_dual_add_f32 v5, v5, v13 :: v_dual_add_f32 v2, v2, v15   // 000000DEDC44: C9081B05 05021F02
	v_mov_b32_dpp v12, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DEDC4C: 7E1802FA FF016804
	v_cndmask_b32_e64 v4, -v4, v4, s7                          // 000000DEDC54: D5010004 201E0904
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DEDC5C: BF870214
	v_add_f32_e32 v3, v3, v14                                  // 000000DEDC60: 06061D03
	v_mov_b32_dpp v13, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DEDC64: 7E1A02FA FF016805
	v_cndmask_b32_e64 v5, -v5, v5, s7                          // 000000DEDC6C: D5010005 201E0B05
	v_mov_b32_dpp v15, v2 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DEDC74: 7E1E02FA FF016802
	v_cndmask_b32_e64 v2, -v2, v2, s7                          // 000000DEDC7C: D5010002 201E0502
	v_mov_b32_dpp v14, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DEDC84: 7E1C02FA FF016803
	v_cndmask_b32_e64 v3, -v3, v3, s7                          // 000000DEDC8C: D5010003 201E0703
	v_dual_add_f32 v4, v4, v12 :: v_dual_add_f32 v5, v5, v13   // 000000DEDC94: C9081904 04041B05
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000DEDC9C: BF8701A4
	v_add_f32_e32 v2, v2, v15                                  // 000000DEDCA0: 06041F02
	v_sub_nc_u32_e32 v6, v6, v7                                // 000000DEDCA4: 4C0C0F06
	v_dual_add_f32 v3, v3, v14 :: v_dual_mov_b32 v12, v4       // 000000DEDCA8: C9101D03 030C0104
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DEDCB0: BF870004
	v_mov_b32_e32 v13, v5                                      // 000000DEDCB4: 7E1A0305
	v_cndmask_b32_e64 v5, -v5, v5, s3                          // 000000DEDCB8: D5010005 200E0B05
	v_mov_b32_e32 v15, v2                                      // 000000DEDCC0: 7E1E0302
	v_cndmask_b32_e64 v4, -v4, v4, s3                          // 000000DEDCC4: D5010004 200E0904
	v_cndmask_b32_e64 v2, -v2, v2, s3                          // 000000DEDCCC: D5010002 200E0502
	v_permlanex16_b32 v13, v13, s44, 0xfedcba98                // 000000DEDCD4: D65C000D 03FC590D FEDCBA98
	v_mov_b32_e32 v14, v3                                      // 000000DEDCE0: 7E1C0303
	v_cndmask_b32_e64 v3, -v3, v3, s3                          // 000000DEDCE4: D5010003 200E0703
	v_permlanex16_b32 v12, v12, s44, 0xfedcba98                // 000000DEDCEC: D65C000C 03FC590C FEDCBA98
	v_permlanex16_b32 v15, v15, s44, 0xfedcba98                // 000000DEDCF8: D65C000F 03FC590F FEDCBA98
	v_add_f32_e32 v5, v5, v13                                  // 000000DEDD04: 060A1B05
	v_permlanex16_b32 v14, v14, s44, 0xfedcba98                // 000000DEDD08: D65C000E 03FC590E FEDCBA98
	v_add_nc_u32_e32 v6, v11, v6                               // 000000DEDD14: 4A0C0D0B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DEDD18: BF870214
	v_dual_add_f32 v4, v4, v12 :: v_dual_add_f32 v7, v2, v15   // 000000DEDD1C: C9081904 04061F02
	v_fma_mixhi_f16 v2, v5, s49, 0                             // 000000DEDD24: CC220002 02006305
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DEDD2C: BF870194
	v_dual_add_f32 v12, v3, v14 :: v_dual_add_nc_u32 v11, 0x800, v11// 000000DEDD30: C9201D03 0C0A16FF 00000800
	v_fma_mixlo_f16 v2, v4, s49, 0                             // 000000DEDD3C: CC210002 02006304
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DEDD44: BF870194
	v_fma_mixhi_f16 v3, v7, s49, 0                             // 000000DEDD48: CC220003 02006307
	v_fma_mixlo_f16 v3, v12, s49, 0                            // 000000DEDD50: CC210003 0200630C
	ds_store_b64 v6, v[2:3]                                    // 000000DEDD58: D9340000 00000206
	s_and_not1_b32 exec_lo, exec_lo, s40                       // 000000DEDD60: 917E287E
	s_cbranch_execz 289                                        // 000000DEDD64: BFA50121 <_ZN7halogen12_GLOBAL__N_113k_i4r_rows_glILi1EEEvPKhlPKDF16_PKiPfS5_S5_PDF16_PjNS0_5I4rSdEi+0x8ec>
	.long 0xd72d0002                                           // 000000DEDD68: D72D0002
	v_cndmask_b32_e32 v0, v10, v48, vcc_lo                     // 000000DEDD6C: 0200610A
	s_mov_b32 s8, -1                                           // 000000DEDD70: BE8800C1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DEDD74: BF870091
	.long 0xd72c0003                                           // 000000DEDD78: D72C0003
	v_cndmask_b32_e32 v0, v2, v43, vcc_lo                      // 000000DEDD7C: 02005702
	v_sub_nc_u32_e32 v3, v10, v3                               // 000000DEDD80: 4C06070A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000DEDD84: BF870121
	v_subrev_nc_u32_e32 v5, s43, v3                            // 000000DEDD88: 4E0A062B
	v_cmp_le_u32_e32 vcc_lo, s43, v3                           // 000000DEDD8C: 7C96062B
	v_dual_cndmask_b32 v3, v3, v5 :: v_dual_add_nc_u32 v4, 1, v2// 000000DEDD90: CA600B03 03040481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DEDD98: BF870111
	v_cndmask_b32_e32 v2, v2, v4, vcc_lo                       // 000000DEDD9C: 02040902
	v_cmp_le_u32_e32 vcc_lo, s43, v3                           // 000000DEDDA0: 7C96062B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DEDDA4: BF870092
	v_add_nc_u32_e32 v4, 1, v2                                 // 000000DEDDA8: 4A080481
	v_cndmask_b32_e32 v2, v2, v4, vcc_lo                       // 000000DEDDAC: 02040902
	s_and_not1_b32 vcc_lo, exec_lo, s42                        // 000000DEDDB0: 916A2A7E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DEDDB4: BF870091
	v_xor_b32_e32 v13, s45, v2                                 // 000000DEDDB8: 3A1A042D
	v_subrev_nc_u32_e32 v12, s45, v13                          // 000000DEDDBC: 4E181A2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DEDDC0: BF8700A1
	v_mad_u64_u32 v[6:7], null, s47, v12, v[1:2]               // 000000DEDDC4: D6FE7C06 0406182F
	v_min_i32_e32 v2, s41, v12                                 // 000000DEDDCC: 22041829
	v_mad_i64_i32 v[4:5], null, v2, s30, 0                     // 000000DEDDD0: D6FF7C04 02003D02
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DEDDD8: BF870093
	v_ashrrev_i32_e32 v7, 31, v6                               // 000000DEDDDC: 340E0C9F
	.long 0xd73c0002                                           // 000000DEDDE0: D73C0002
	v_cndmask_b32_e32 v1, 1, v6, vcc_lo                        // 000000DEDDE4: 02020C81
	s_cbranch_vccnz 212                                        // 000000DEDDE8: BFA400D4 <_ZN7halogen12_GLOBAL__N_113k_i4r_rows_glILi1EEEvPKhlPKDF16_PKiPfS5_S5_PDF16_PjNS0_5I4rSdEi+0x83c>
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DEDDEC: BF870093
	.long 0xd7006a06                                           // 000000DEDDF0: D7006A06
	v_cndmask_b32_e32 v1, v4, v6, vcc_lo                       // 000000DEDDF4: 02020D04
	v_add_co_ci_u32_e64 v7, null, v5, v7, vcc_lo               // 000000DEDDF8: D5207C07 01AA0F05
	.long 0x7f3c3880                                           // 000000DEDE00: 7F3C3880
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DEDE04: BF870112
	.long 0xd73c0006                                           // 000000DEDE08: D73C0006
	v_cndmask_b32_e32 v1, 1, v6, vcc_lo                        // 000000DEDE0C: 02020C81
	.long 0x7f42399e                                           // 000000DEDE10: 7F42399E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DEDE14: BF870092
	.long 0xd7006a0e                                           // 000000DEDE18: D7006A0E
	v_cndmask_b32_e32 v1, s20, v6, vcc_lo                      // 000000DEDE1C: 02020C14
	v_add_co_ci_u32_e64 v15, null, s21, v7, vcc_lo             // 000000DEDE20: D5207C0F 01AA0E15
	.long 0xd7006a06                                           // 000000DEDE28: D7006A06
	v_cndmask_b32_e32 v1, s22, v6, vcc_lo                      // 000000DEDE2C: 02020C16
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DEDE30: BF870001
	v_add_co_ci_u32_e64 v7, null, s23, v7, vcc_lo              // 000000DEDE34: D5207C07 01AA0E17
	global_load_b64 v[14:15], v[14:15], off                    // 000000DEDE3C: DC560000 0E7C000E
	.long 0xd7006a10                                           // 000000DEDE44: D7006A10
	v_cndmask_b32_e32 v1, s16, v2, vcc_lo                      // 000000DEDE48: 02020410
	global_load_b64 v[6:7], v[6:7], off                        // 000000DEDE4C: DC560000 067C0006
	v_add_co_ci_u32_e64 v17, null, s17, v3, vcc_lo             // 000000DEDE54: D5207C11 01AA0611
	s_clause 0x1                                               // 000000DEDE5C: BF850001
	global_load_b32 v18, v[16:17], off                         // 000000DEDE60: DC520000 127C0010
	global_load_d16_b16 v16, v[16:17], off offset:4            // 000000DEDE68: DC820004 107C0010
	s_waitcnt vmcnt(3)                                         // 000000DEDE70: BF890FF7
	.long 0x7e22390e                                           // 000000DEDE74: 7E22390E
	s_waitcnt vmcnt(2)                                         // 000000DEDE78: BF890BF7
	v_and_b32_e32 v40, 0xffff0000, v6                          // 000000DEDE7C: 36500CFF FFFF0000
	v_lshlrev_b32_e32 v6, 16, v6                               // 000000DEDE84: 300C0C90
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DEDE88: BF870093
	v_lshlrev_b32_e32 v17, 16, v17                             // 000000DEDE8C: 30222290
	v_mul_f32_e32 v21, 0xbfb8aa3b, v17                         // 000000DEDE90: 102A22FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000DEDE98: BF870291
	v_exp_f32_e32 v21, v21                                     // 000000DEDE9C: 7E2A4B15
	v_dual_add_f32 v21, 1.0, v21 :: v_dual_and_b32 v14, 0xffff0000, v14// 000000DEDEA0: C9242AF2 150E1CFF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DEDEAC: BF870111
	v_mul_f32_e32 v20, 0xbfb8aa3b, v14                         // 000000DEDEB0: 10281CFF BFB8AA3B
	v_div_scale_f32 v25, null, v21, v21, v17                   // 000000DEDEB8: D6FC7C19 04462B15
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000DEDEC0: BF8701B2
	v_exp_f32_e32 v20, v20                                     // 000000DEDEC4: 7E284B14
	v_lshlrev_b32_e32 v19, 16, v15                             // 000000DEDEC8: 30261E90
	v_div_scale_f32 v38, s9, v17, v21, v17                     // 000000DEDECC: D6FC0926 04462B11
	v_rcp_f32_e32 v29, v25                                     // 000000DEDED4: 7E3A5519
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DEDED8: BF870196
	v_add_f32_e32 v20, 1.0, v20                                // 000000DEDEDC: 062828F2
	v_mul_f32_e32 v22, 0xbfb8aa3b, v19                         // 000000DEDEE0: 102C26FF BFB8AA3B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DEDEE8: BF870195
	v_fma_f32 v37, -v25, v29, 1.0                              // 000000DEDEEC: D6130025 23CA3B19
	v_div_scale_f32 v24, null, v20, v20, v14                   // 000000DEDEF4: D6FC7C18 043A2914
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000DEDEFC: BF8701B3
	v_exp_f32_e32 v22, v22                                     // 000000DEDF00: 7E2C4B16
	v_and_b32_e32 v15, 0xffff0000, v15                         // 000000DEDF04: 361E1EFF FFFF0000
	v_div_scale_f32 v34, vcc_lo, v14, v20, v14                 // 000000DEDF0C: D6FC6A22 043A290E
	v_rcp_f32_e32 v27, v24                                     // 000000DEDF14: 7E365518
	s_delay_alu instid0(TRANS32_DEP_2) | instid1(VALU_DEP_2)   // 000000DEDF18: BF870106
	v_dual_add_f32 v22, 1.0, v22 :: v_dual_mul_f32 v23, 0xbfb8aa3b, v15// 000000DEDF1C: C9062CF2 16161EFF BFB8AA3B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DEDF28: BF870115
	v_fma_f32 v35, -v24, v27, 1.0                              // 000000DEDF2C: D6130023 23CA3718
	v_div_scale_f32 v26, null, v22, v22, v19                   // 000000DEDF34: D6FC7C1A 044E2D16
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000DEDF3C: BF8701A3
	v_exp_f32_e32 v23, v23                                     // 000000DEDF40: 7E2E4B17
	v_div_scale_f32 v36, s8, v19, v22, v19                     // 000000DEDF44: D6FC0824 044E2D13
	v_fmac_f32_e32 v27, v35, v27                               // 000000DEDF4C: 56363723
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 000000DEDF50: BF870313
	v_rcp_f32_e32 v31, v26                                     // 000000DEDF54: 7E3E551A
	v_add_f32_e32 v23, 1.0, v23                                // 000000DEDF58: 062E2EF2
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DEDF5C: BF870115
	v_fma_f32 v39, -v26, v31, 1.0                              // 000000DEDF60: D6130027 23CA3F1A
	v_div_scale_f32 v28, null, v23, v23, v15                   // 000000DEDF68: D6FC7C1C 043E2F17
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000DEDF70: BF8701A2
	v_fmac_f32_e32 v31, v39, v31                               // 000000DEDF74: 563E3F27
	v_mul_f32_e32 v39, v34, v27                                // 000000DEDF78: 104E3722
	v_rcp_f32_e32 v32, v28                                     // 000000DEDF7C: 7E40551C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DEDF80: BF870091
	v_fma_f32 v42, -v24, v39, v34                              // 000000DEDF84: D613002A 248A4F18
	v_fmac_f32_e32 v39, v42, v27                               // 000000DEDF8C: 564E372A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DEDF90: BF870115
	v_fma_f32 v35, -v28, v32, 1.0                              // 000000DEDF94: D6130023 23CA411C
	v_fma_f32 v24, -v24, v39, v34                              // 000000DEDF9C: D6130018 248A4F18
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DEDFA4: BF870112
	v_fmac_f32_e32 v32, v35, v32                               // 000000DEDFA8: 56404123
	v_div_fmas_f32 v24, v24, v27, v39                          // 000000DEDFAC: D6370018 049E3718
	s_mov_b32 vcc_lo, s9                                       // 000000DEDFB4: BEEA0009
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000DEDFB8: BF8701B1
	v_div_fixup_f32 v14, v24, v20, v14                         // 000000DEDFBC: D627000E 043A2918
	v_fmac_f32_e32 v29, v37, v29                               // 000000DEDFC4: 563A3B25
	v_div_scale_f32 v37, s10, v15, v23, v15                    // 000000DEDFC8: D6FC0A25 043E2F0F
	v_mul_f32_e32 v14, v14, v40                                // 000000DEDFD0: 101C510E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DEDFD4: BF870193
	v_mul_f32_e32 v35, v38, v29                                // 000000DEDFD8: 10463B26
	v_mul_f32_e32 v43, v37, v32                                // 000000DEDFDC: 10564125
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DEDFE0: BF870193
	.long 0x7e3c398e                                           // 000000DEDFE4: 7E3C398E
	v_fma_f32 v44, -v25, v35, v38                              // 000000DEDFE8: D613002C 249A4719
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DEDFF0: BF870113
	v_fma_f32 v42, -v28, v43, v37                              // 000000DEDFF4: D613002A 2496571C
	v_fmac_f32_e32 v35, v44, v29                               // 000000DEDFFC: 56463B2C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DEE000: BF870112
	v_fmac_f32_e32 v43, v42, v32                               // 000000DEE004: 5656412A
	v_fma_f32 v25, -v25, v35, v38                              // 000000DEE008: D6130019 249A4719
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DEE010: BF870112
	v_fma_f32 v24, -v28, v43, v37                              // 000000DEE014: D6130018 2496571C
	v_div_fmas_f32 v25, v25, v29, v35                          // 000000DEE01C: D6370019 048E3B19
	s_mov_b32 vcc_lo, s8                                       // 000000DEE024: BEEA0008
	s_mov_b32 s8, 0                                            // 000000DEE028: BE880080
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000DEE02C: BF870121
	v_div_fixup_f32 v17, v25, v21, v17                         // 000000DEE030: D6270011 04462B19
	v_lshlrev_b32_e32 v21, 16, v7                              // 000000DEE038: 302A0E90
	v_dual_mul_f32 v6, v17, v6 :: v_dual_and_b32 v7, 0xffff0000, v7// 000000DEE03C: C8E40D11 06060EFF FFFF0000
	v_mul_f32_e32 v41, v36, v31                                // 000000DEE048: 10523F24
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DEE04C: BF870112
	.long 0x7e423986                                           // 000000DEE050: 7E423986
	v_fma_f32 v45, -v26, v41, v36                              // 000000DEE054: D613002D 2492531A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DEE05C: BF870091
	v_fmac_f32_e32 v41, v45, v31                               // 000000DEE060: 56523F2D
	v_fma_f32 v26, -v26, v41, v36                              // 000000DEE064: D613001A 2492531A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000DEE06C: BF870131
	v_div_fmas_f32 v20, v26, v31, v41                          // 000000DEE070: D6370014 04A63F1A
	s_mov_b32 vcc_lo, s10                                      // 000000DEE078: BEEA000A
	v_div_fmas_f32 v17, v24, v32, v43                          // 000000DEE07C: D6370011 04AE4118
	v_div_fixup_f32 v19, v20, v22, v19                         // 000000DEE084: D6270013 044E2D14
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000DEE08C: BF8701A2
	v_div_fixup_f32 v15, v17, v23, v15                         // 000000DEE090: D627000F 043E2F11
	v_and_b32_e32 v17, 1, v30                                  // 000000DEE098: 36223C81
	v_mul_f32_e32 v19, v19, v21                                // 000000DEE09C: 10262B13
	v_and_b32_e32 v21, 1, v33                                  // 000000DEE0A0: 362A4281
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DEE0A4: BF870214
	v_mul_f32_e32 v7, v15, v7                                  // 000000DEE0A8: 100E0F0F
	v_add3_u32 v14, v14, v17, 0x7fff                           // 000000DEE0AC: D655000E 03FE230E 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DEE0B8: BF870214
	v_bfe_u32 v20, v19, 16, 1                                  // 000000DEE0BC: D6100014 02052113
	v_add3_u32 v6, v6, v21, 0x7fff                             // 000000DEE0C4: D6550006 03FE2B06 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DEE0D0: BF870214
	v_bfe_u32 v17, v7, 16, 1                                   // 000000DEE0D4: D6100011 02052107
	v_and_b32_e32 v14, 0xffff0000, v14                         // 000000DEE0DC: 361C1CFF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DEE0E4: BF870214
	v_add3_u32 v15, v19, v20, 0x7fff                           // 000000DEE0E8: D655000F 03FE2913 00007FFF
	v_and_b32_e32 v6, 0xffff0000, v6                           // 000000DEE0F4: 360C0CFF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DEE0FC: BF870194
	v_add3_u32 v7, v7, v17, 0x7fff                             // 000000DEE100: D6550007 03FE2307 00007FFF
	v_and_b32_e32 v19, 0xffff0000, v15                         // 000000DEE10C: 36261EFF FFFF0000
	s_waitcnt vmcnt(1)                                         // 000000DEE114: BF8907F7
	v_fma_mix_f32 v15, v18, v14, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000DEE118: CC20080F 8A021D12
	v_fma_mix_f32 v17, v18, v6, neg(0) op_sel_hi:[1,0,0]       // 000000DEE120: CC200011 8A020D12
	s_waitcnt vmcnt(0)                                         // 000000DEE128: BF8903F7
	v_fma_mix_f32 v14, v16, v19, neg(0) op_sel_hi:[1,0,0]      // 000000DEE12C: CC20000E 8A022710
	v_and_b32_e32 v16, 0xffff0000, v7                          // 000000DEE134: 36200EFF FFFF0000
	s_and_not1_b32 vcc_lo, exec_lo, s8                         // 000000DEE13C: 916A087E
	s_cbranch_vccnz 65125                                      // 000000DEE140: BFA4FE65 <_ZN7halogen12_GLOBAL__N_113k_i4r_rows_glILi1EEEvPKhlPKDF16_PKiPfS5_S5_PDF16_PjNS0_5I4rSdEi+0x1d8>
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DEE144: BF870093
	.long 0xd73c0004                                           // 000000DEE148: D73C0004
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 000000DEE14C: 02020881
	.long 0xd7006a04                                           // 000000DEE150: D7006A04
	v_cndmask_b32_e32 v1, s20, v4, vcc_lo                      // 000000DEE154: 02020814
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DEE158: BF870111
	v_add_co_ci_u32_e64 v5, null, s21, v5, vcc_lo              // 000000DEE15C: D5207C05 01AA0A15
	.long 0xd7006a04                                           // 000000DEE164: D7006A04
	v_cndmask_b32_e32 v1, v4, v2, vcc_lo                       // 000000DEE168: 02020504
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DEE16C: BF8700A1
	v_add_co_ci_u32_e64 v5, null, v5, v3, vcc_lo               // 000000DEE170: D5207C05 01AA0705
	.long 0xd7006a06                                           // 000000DEE178: D7006A06
	v_cndmask_b32_e32 v1, s16, v2, vcc_lo                      // 000000DEE17C: 02020410
	v_add_co_ci_u32_e64 v7, null, s17, v3, vcc_lo              // 000000DEE180: D5207C07 01AA0611
	global_load_b64 v[4:5], v[4:5], off                        // 000000DEE188: DC560000 047C0004
	s_clause 0x1                                               // 000000DEE190: BF850001
	global_load_b32 v16, v[6:7], off                           // 000000DEE194: DC520000 107C0006
	global_load_d16_b16 v6, v[6:7], off offset:4               // 000000DEE19C: DC820004 067C0006
	s_waitcnt vmcnt(2)                                         // 000000DEE1A4: BF890BF7
	.long 0x7e0e3904                                           // 000000DEE1A8: 7E0E3904
	v_and_b32_e32 v4, 0xffff0000, v4                           // 000000DEE1AC: 360808FF FFFF0000
	v_lshlrev_b32_e32 v14, 16, v5                              // 000000DEE1B4: 301C0A90
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000DEE1B8: BF8701A3
	v_lshlrev_b32_e32 v7, 16, v7                               // 000000DEE1BC: 300E0E90
	s_waitcnt vmcnt(1)                                         // 000000DEE1C0: BF8907F7
	v_fma_mix_f32 v15, v16, v4, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000DEE1C4: CC20080F 8A020910
	s_waitcnt vmcnt(0)                                         // 000000DEE1CC: BF8903F7
	v_fma_mix_f32 v14, v6, v14, neg(0) op_sel_hi:[1,0,0]       // 000000DEE1D0: CC20000E 8A021D06
	v_fma_mix_f32 v17, v16, v7, neg(0) op_sel_hi:[1,0,0]       // 000000DEE1D8: CC200011 8A020F10
	v_and_b32_e32 v16, 0xffff0000, v5                          // 000000DEE1E0: 36200AFF FFFF0000
	s_branch 65083                                             // 000000DEE1E8: BFA0FE3B <_ZN7halogen12_GLOBAL__N_113k_i4r_rows_glILi1EEEvPKhlPKDF16_PKiPfS5_S5_PDF16_PjNS0_5I4rSdEi+0x1d8>
	s_or_b32 exec_lo, exec_lo, s38                             // 000000DEE1EC: 8C7E267E
	s_bfe_i32 s38, s39, 0x1001c                                // 000000DEE1F0: 93A6FF27 0001001C
	s_lshl_b32 s6, s35, 3                                      // 000000DEE1F8: 84068323
	s_lshr_b64 s[4:5], s[38:39], 29                            // 000000DEE1FC: 85849D26
	s_lshr_b32 s5, s33, 28                                     // 000000DEE200: 85059C21
	s_add_i32 s3, s4, 7                                        // 000000DEE204: 81038704
	s_add_i32 s5, s30, s5                                      // 000000DEE208: 8105051E
	s_ashr_i32 s3, s3, 3                                       // 000000DEE20C: 86038303
	s_lshl_b32 s4, s39, 3                                      // 000000DEE210: 84048327
	.long 0xd72c0001                                           // 000000DEE214: D72C0001
	v_cndmask_b32_e32 v1, s3, v8, vcc_lo                       // 000000DEE218: 02021003
	v_lshlrev_b32_e32 v7, 2, v9                                // 000000DEE21C: 300E1282
	s_waitcnt lgkmcnt(0)                                       // 000000DEE220: BF89FC07
	s_barrier                                                  // 000000DEE224: BFBD0000
	buffer_gl0_inv                                             // 000000DEE228: E0AC0000 00000000
	v_add_nc_u32_e32 v2, s3, v1                                // 000000DEE230: 4A040203
	s_ashr_i32 s3, s5, 4                                       // 000000DEE234: 86038405
	s_ashr_i32 s5, s6, 31                                      // 000000DEE238: 86059F06
	s_mul_hi_i32 s7, s34, s3                                   // 000000DEE23C: 97070322
	s_mul_i32 s3, s34, s3                                      // 000000DEE240: 96030322
	v_min_i32_e32 v10, s4, v2                                  // 000000DEE244: 22140404
	s_add_u32 s4, s3, s6                                       // 000000DEE248: 80040603
	s_addc_u32 s5, s7, s5                                      // 000000DEE24C: 82050507
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DEE250: BF870099
	s_lshl_b64 s[4:5], s[4:5], 10                              // 000000DEE254: 84848A04
	v_cmp_lt_i32_e32 vcc_lo, v1, v10                           // 000000DEE258: 7C821501
	s_add_u32 s4, s14, s4                                      // 000000DEE25C: 8004040E
	s_addc_u32 s5, s15, s5                                     // 000000DEE260: 8205050F
	s_and_saveexec_b32 s6, vcc_lo                              // 000000DEE264: BE86206A
	s_cbranch_execz 93                                         // 000000DEE268: BFA5005D <_ZN7halogen12_GLOBAL__N_113k_i4r_rows_glILi1EEEvPKhlPKDF16_PKiPfS5_S5_PDF16_PjNS0_5I4rSdEi+0xae0>
	.long 0xd7010302                                           // 000000DEE26C: D7010302
	v_cndmask_b32_e32 v0, v9, v129, vcc_lo                     // 000000DEE270: 02010309
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000DEE274: BF870121
	v_cndmask_b32_e64 v3, v2, 31, s3                           // 000000DEE278: D5010003 000D3F02
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000DEE280: 3404029F
	.long 0xd44c0003                                           // 000000DEE284: D44C0003
	v_cndmask_b32_e32 v1, 31, v3, vcc_lo                       // 000000DEE288: 0202069F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DEE28C: BF870091
	v_cndmask_b32_e64 v5, 0xe1, 1, s3                          // 000000DEE290: D5010005 000D02FF 000000E1
	v_dual_mov_b32 v4, 0 :: v_dual_add_nc_u32 v11, v5, v3      // 000000DEE29C: CA200080 040A0705
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DEE2A4: BF870114
	.long 0xd73c0005                                           // 000000DEE2A8: D73C0005
	v_cndmask_b32_e32 v1, 10, v1, vcc_lo                       // 000000DEE2AC: 0202028A
	.long 0xd73c0002                                           // 000000DEE2B0: D73C0002
	v_cndmask_b32_e32 v1, 2, v3, vcc_lo                        // 000000DEE2B4: 02020682
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000DEE2B8: BF870223
	v_lshlrev_b32_e32 v4, 24, v11                              // 000000DEE2BC: 30081698
	v_bfe_i32 v12, v11, 7, 1                                   // 000000DEE2C0: D611000C 02050F0B
	.long 0xd700030d                                           // 000000DEE2C8: D700030D
	v_cndmask_b32_e32 v1, s4, v5, vcc_lo                       // 000000DEE2CC: 02020A04
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DEE2D0: BF870211
	v_add_co_ci_u32_e64 v6, null, s5, v6, s3                   // 000000DEE2D4: D5207C06 000E0C05
	v_ashrrev_i32_e32 v11, 22, v4                              // 000000DEE2DC: 34160896
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DEE2E0: BF870093
	.long 0xd7000304                                           // 000000DEE2E4: D7000304
	v_cndmask_b32_e32 v1, v13, v2, vcc_lo                      // 000000DEE2E8: 0202050D
	v_add_co_ci_u32_e64 v5, null, v6, v3, s3                   // 000000DEE2EC: D5207C05 000E0706
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DEE2F4: BF870093
	.long 0xd700030b                                           // 000000DEE2F8: D700030B
	v_cndmask_b32_e32 v1, v13, v11, vcc_lo                     // 000000DEE2FC: 0202170D
	v_add_co_ci_u32_e64 v12, null, v6, v12, s3                 // 000000DEE300: D5207C0C 000E1906
	.long 0xd700030d                                           // 000000DEE308: D700030D
	v_cndmask_b32_e32 v1, v13, v7, vcc_lo                      // 000000DEE30C: 02020F0D
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DEE310: BF870001
	v_add_co_ci_u32_e64 v14, null, 0, v6, s3                   // 000000DEE314: D5207C0E 000E0C80
	s_clause 0x17                                              // 000000DEE31C: BF850017
	global_load_b32 v2, v[4:5], off                            // 000000DEE320: DC520000 027C0004
	global_load_b32 v56, v[4:5], off offset:128                // 000000DEE328: DC520080 387C0004
	global_load_b32 v53, v[4:5], off offset:256                // 000000DEE330: DC520100 357C0004
	global_load_b32 v50, v[4:5], off offset:384                // 000000DEE338: DC520180 327C0004
	global_load_b32 v47, v[4:5], off offset:512                // 000000DEE340: DC520200 2F7C0004
	global_load_b32 v44, v[4:5], off offset:640                // 000000DEE348: DC520280 2C7C0004
	global_load_b32 v26, v[4:5], off offset:768                // 000000DEE350: DC520300 1A7C0004
	global_load_b32 v20, v[4:5], off offset:896                // 000000DEE358: DC520380 147C0004
	global_load_b32 v4, v[11:12], off                          // 000000DEE360: DC520000 047C000B
	global_load_b32 v57, v[11:12], off offset:128              // 000000DEE368: DC520080 397C000B
	global_load_b32 v54, v[11:12], off offset:256              // 000000DEE370: DC520100 367C000B
	global_load_b32 v51, v[11:12], off offset:384              // 000000DEE378: DC520180 337C000B
	global_load_b32 v48, v[11:12], off offset:512              // 000000DEE380: DC520200 307C000B
	global_load_b32 v45, v[11:12], off offset:640              // 000000DEE388: DC520280 2D7C000B
	global_load_b32 v27, v[11:12], off offset:768              // 000000DEE390: DC520300 1B7C000B
	global_load_b32 v21, v[11:12], off offset:896              // 000000DEE398: DC520380 157C000B
	global_load_b32 v3, v[13:14], off                          // 000000DEE3A0: DC520000 037C000D
	global_load_b32 v55, v[13:14], off offset:128              // 000000DEE3A8: DC520080 377C000D
	global_load_b32 v52, v[13:14], off offset:256              // 000000DEE3B0: DC520100 347C000D
	global_load_b32 v49, v[13:14], off offset:384              // 000000DEE3B8: DC520180 317C000D
	global_load_b32 v46, v[13:14], off offset:512              // 000000DEE3C0: DC520200 2E7C000D
	global_load_b32 v43, v[13:14], off offset:640              // 000000DEE3C8: DC520280 2B7C000D
	global_load_b32 v25, v[13:14], off offset:768              // 000000DEE3D0: DC520300 197C000D
	global_load_b32 v19, v[13:14], off offset:896              // 000000DEE3D8: DC520380 137C000D
	s_or_b32 exec_lo, exec_lo, s6                              // 000000DEE3E0: 8C7E067E
	v_dual_mov_b32 v11, 0 :: v_dual_mov_b32 v12, 0             // 000000DEE3E4: CA100080 0B0C0080
	v_dual_mov_b32 v13, 0 :: v_dual_mov_b32 v14, 0             // 000000DEE3EC: CA100080 0D0E0080
	v_dual_mov_b32 v15, 0 :: v_dual_mov_b32 v16, 0             // 000000DEE3F4: CA100080 0F100080
	v_dual_mov_b32 v17, 0 :: v_dual_mov_b32 v18, 0             // 000000DEE3FC: CA100080 11120080
	s_ashr_i32 s35, s34, 31                                    // 000000DEE404: 86239F22
	s_and_saveexec_b32 s3, vcc_lo                              // 000000DEE408: BE83206A
	s_cbranch_execz 936                                        // 000000DEE40C: BFA503A8 <_ZN7halogen12_GLOBAL__N_113k_i4r_rows_glILi1EEEvPKhlPKDF16_PKiPfS5_S5_PDF16_PjNS0_5I4rSdEi+0x19b0>
	v_dual_mov_b32 v12, 0 :: v_dual_add_nc_u32 v5, -1, v0      // 000000DEE410: CA200080 0C0400C1
	v_dual_mov_b32 v11, 0 :: v_dual_and_b32 v22, 16, v0        // 000000DEE418: CA240080 0B160090
	v_dual_mov_b32 v14, 0 :: v_dual_lshlrev_b32 v23, 2, v9     // 000000DEE420: CA220080 0E161282
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000DEE428: BF8701B3
	v_dual_mov_b32 v16, 0 :: v_dual_and_b32 v5, 31, v5         // 000000DEE42C: CA240080 10040A9F
	v_mov_b32_e32 v13, 0                                       // 000000DEE434: 7E1A0280
	v_dual_mov_b32 v15, 0 :: v_dual_mov_b32 v18, 0             // 000000DEE438: CA100080 0F120080
	v_dual_mov_b32 v17, 0 :: v_dual_lshlrev_b32 v24, 2, v5     // 000000DEE440: CA220080 11180A82
	s_mov_b32 s6, 0                                            // 000000DEE448: BE860080
	s_movk_i32 s7, 0x1eee                                      // 000000DEE44C: B0071EEE
	s_branch 860                                               // 000000DEE450: BFA0035C <_ZN7halogen12_GLOBAL__N_113k_i4r_rows_glILi1EEEvPKhlPKDF16_PKiPfS5_S5_PDF16_PjNS0_5I4rSdEi+0x18c4>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000DEE454: 8C7E087E
	s_waitcnt vmcnt(15)                                        // 000000DEE458: BF893FF7
	v_alignbit_b32 v58, v2, v4, 16                             // 000000DEE45C: D616003A 02420902
	s_waitcnt vmcnt(7)                                         // 000000DEE464: BF891FF7
	v_bfe_u32 v59, v3, 12, 16                                  // 000000DEE468: D610003B 02411903
	v_bfe_u32 v60, v3, 8, 16                                   // 000000DEE470: D610003C 02411103
	v_lshl_or_b32 v1, v1, 5, v22                               // 000000DEE478: D6560001 04590B01
	v_bfe_u32 v61, v3, 4, 16                                   // 000000DEE480: D610003D 02410903
	v_bfe_u32 v62, v58, 12, 16                                 // 000000DEE488: D610003E 0241193A
	v_bfe_u32 v65, v58, 8, 16                                  // 000000DEE490: D6100041 0241113A
	.long 0xd72c003b                                           // 000000DEE498: D72C003B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 000000DEE49C: 020276FF 83DCD12D
	.long 0xd72c003c                                           // 000000DEE4A4: D72C003C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v60, vcc_lo              // 000000DEE4A8: 020278FF 83DCD12D
	.long 0xd72c003d                                           // 000000DEE4B0: D72C003D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v61, vcc_lo              // 000000DEE4B4: 02027AFF 83DCD12D
	.long 0xd72c003e                                           // 000000DEE4BC: D72C003E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v62, vcc_lo              // 000000DEE4C0: 02027CFF 83DCD12D
	.long 0xd72c0041                                           // 000000DEE4C8: D72C0041
	v_cndmask_b32_e32 v1, 0x83dcd12d, v65, vcc_lo              // 000000DEE4CC: 020282FF 83DCD12D
	v_alignbit_b32 v56, v56, v57, 16                           // 000000DEE4D4: D6160038 02427338
	v_alignbit_b32 v53, v53, v54, 16                           // 000000DEE4DC: D6160035 02426D35
	v_alignbit_b32 v50, v50, v51, 16                           // 000000DEE4E4: D6160032 02426732
	v_sad_u8 v59, v59, 0, 0x6400                               // 000000DEE4EC: D622003B 03FD013B 00006400
	v_sad_u8 v60, v60, 0, 0x6400                               // 000000DEE4F8: D622003C 03FD013C 00006400
	v_sad_u8 v61, v61, 0, 0x6400                               // 000000DEE504: D622003D 03FD013D 00006400
	v_sad_u8 v62, v62, 0, 0x6400                               // 000000DEE510: D622003E 03FD013E 00006400
	v_sad_u8 v65, v65, 0, 0x6400                               // 000000DEE51C: D6220041 03FD0141 00006400
	v_and_b32_e32 v59, 0xffff, v59                             // 000000DEE528: 367676FF 0000FFFF
	v_bfe_u32 v51, v50, 12, 16                                 // 000000DEE530: D6100033 02411932
	v_alignbit_b32 v47, v47, v48, 16                           // 000000DEE538: D616002F 0242612F
	v_and_b32_e32 v62, 0xffff, v62                             // 000000DEE540: 367C7CFF 0000FFFF
	v_alignbit_b32 v44, v44, v45, 16                           // 000000DEE548: D616002C 02425B2C
	v_lshl_or_b32 v59, v60, 16, v59                            // 000000DEE550: D656003B 04ED213C
	.long 0xd72c0033                                           // 000000DEE558: D72C0033
	v_cndmask_b32_e32 v1, 0x83dcd12d, v51, vcc_lo              // 000000DEE55C: 020266FF 83DCD12D
	v_alignbit_b32 v26, v26, v27, 16                           // 000000DEE564: D616001A 0242371A
	v_lshl_or_b32 v62, v65, 16, v62                            // 000000DEE56C: D656003E 04F92141
	s_waitcnt vmcnt(5)                                         // 000000DEE574: BF8917F7
	v_bfe_u32 v65, v52, 4, 16                                  // 000000DEE578: D6100041 02410934
	v_pk_fma_f16 v59, v59, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DEE580: CC0E003B 0BFC0F3B 0000C931
	v_alignbit_b32 v20, v20, v21, 16                           // 000000DEE58C: D6160014 02422B14
	v_cmp_eq_u32_e32 vcc_lo, v5, v10                           // 000000DEE594: 7C941505
	v_pk_fma_f16 v60, v62, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DEE598: CC0E003C 0BFC0F3E 0000C931
	v_and_b32_e32 v63, 0xffff, v3                              // 000000DEE5A4: 367E06FF 0000FFFF
	ds_load_b128 v[1:4], v1                                    // 000000DEE5AC: DBFC0000 01000001
	v_bfe_u32 v62, v55, 12, 16                                 // 000000DEE5B4: D610003E 02411937
	v_sad_u8 v51, v51, 0, 0x6400                               // 000000DEE5BC: D6220033 03FD0133 00006400
	s_or_b32 s6, vcc_lo, s6                                    // 000000DEE5C8: 8C06066A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DEE5CC: BF870112
	.long 0xd72c003e                                           // 000000DEE5D0: D72C003E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v62, vcc_lo              // 000000DEE5D4: 02027CFF 83DCD12D
	v_and_b32_e32 v51, 0xffff, v51                             // 000000DEE5DC: 366666FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DEE5E4: BF870092
	v_sad_u8 v62, v62, 0, 0x6400                               // 000000DEE5E8: D622003E 03FD013E 00006400
	v_and_b32_e32 v62, 0xffff, v62                             // 000000DEE5F4: 367C7CFF 0000FFFF
	s_waitcnt lgkmcnt(0)                                       // 000000DEE5FC: BF89FC07
	v_dot2acc_f32_f16 v18, v60, v1                             // 000000DEE600: 0424033C
	.long 0xd72c003f                                           // 000000DEE604: D72C003F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v63, vcc_lo              // 000000DEE608: 02027EFF 83DCD12D
	v_and_b32_e32 v60, 0xffff, v56                             // 000000DEE610: 367870FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DEE618: BF870191
	.long 0xd72c003c                                           // 000000DEE61C: D72C003C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v60, vcc_lo              // 000000DEE620: 020278FF 83DCD12D
	v_sad_u8 v63, v63, 0, 0x6400                               // 000000DEE628: D622003F 03FD013F 00006400
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DEE634: BF870191
	v_lshlrev_b32_e32 v63, 16, v63                             // 000000DEE638: 307E7E90
	v_sad_u8 v60, v60, 0, 0x6400                               // 000000DEE63C: D622003C 03FD013C 00006400
	s_delay_alu instid0(VALU_DEP_2)                            // 000000DEE648: BF870002
	v_and_or_b32 v57, 0xffff, v61, v63                         // 000000DEE64C: D6570039 04FE7AFF 0000FFFF
	v_bfe_u32 v61, v56, 12, 16                                 // 000000DEE658: D610003D 02411938
	v_bfe_u32 v63, v56, 8, 16                                  // 000000DEE660: D610003F 02411138
	v_bfe_u32 v56, v56, 4, 16                                  // 000000DEE668: D6100038 02410938
	v_lshlrev_b32_e32 v60, 16, v60                             // 000000DEE670: 30787890
	v_pk_fma_f16 v57, v57, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DEE674: CC0E0039 0BFC0F39 0000C931
	.long 0xd72c003d                                           // 000000DEE680: D72C003D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v61, vcc_lo              // 000000DEE684: 02027AFF 83DCD12D
	.long 0xd72c003f                                           // 000000DEE68C: D72C003F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v63, vcc_lo              // 000000DEE690: 02027EFF 83DCD12D
	.long 0xd72c0038                                           // 000000DEE698: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v56, vcc_lo              // 000000DEE69C: 020270FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DEE6A4: BF870193
	v_sad_u8 v61, v61, 0, 0x6400                               // 000000DEE6A8: D622003D 03FD013D 00006400
	v_sad_u8 v63, v63, 0, 0x6400                               // 000000DEE6B4: D622003F 03FD013F 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DEE6C0: BF870193
	v_sad_u8 v56, v56, 0, 0x6400                               // 000000DEE6C4: D6220038 03FD0138 00006400
	v_and_b32_e32 v61, 0xffff, v61                             // 000000DEE6D0: 367A7AFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DEE6D8: BF870112
	v_and_or_b32 v56, 0xffff, v56, v60                         // 000000DEE6DC: D6570038 04F270FF 0000FFFF
	v_lshl_or_b32 v61, v63, 16, v61                            // 000000DEE6E8: D656003D 04F5213F
	v_bfe_u32 v63, v52, 12, 16                                 // 000000DEE6F0: D610003F 02411934
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DEE6F8: BF870193
	v_pk_fma_f16 v56, v56, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DEE6FC: CC0E0038 0BFC0F38 0000C931
	v_pk_fma_f16 v54, v61, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DEE708: CC0E0036 0BFC0F3D 0000C931
	v_and_b32_e32 v64, 0xffff, v58                             // 000000DEE714: 368074FF 0000FFFF
	v_bfe_u32 v58, v58, 4, 16                                  // 000000DEE71C: D610003A 0241093A
	v_and_b32_e32 v61, 0xffff, v53                             // 000000DEE724: 367A6AFF 0000FFFF
	.long 0xd72c003f                                           // 000000DEE72C: D72C003F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v63, vcc_lo              // 000000DEE730: 02027EFF 83DCD12D
	v_dot2acc_f32_f16 v17, v54, v1                             // 000000DEE738: 04220336
	.long 0xd72c0040                                           // 000000DEE73C: D72C0040
	v_cndmask_b32_e32 v1, 0x83dcd12d, v64, vcc_lo              // 000000DEE740: 020280FF 83DCD12D
	.long 0xd72c003a                                           // 000000DEE748: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 000000DEE74C: 020274FF 83DCD12D
	.long 0xd72c0036                                           // 000000DEE754: D72C0036
	v_cndmask_b32_e32 v1, 0x83dcd12d, v65, vcc_lo              // 000000DEE758: 020282FF 83DCD12D
	.long 0xd72c003d                                           // 000000DEE760: D72C003D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v61, vcc_lo              // 000000DEE764: 02027AFF 83DCD12D
	v_dot2acc_f32_f16 v17, v56, v2                             // 000000DEE76C: 04220538
	s_waitcnt vmcnt(4)                                         // 000000DEE770: BF8913F7
	v_bfe_u32 v56, v49, 4, 16                                  // 000000DEE774: D6100038 02410931
	v_sad_u8 v63, v63, 0, 0x6400                               // 000000DEE77C: D622003F 03FD013F 00006400
	v_sad_u8 v64, v64, 0, 0x6400                               // 000000DEE788: D6220040 03FD0140 00006400
	v_sad_u8 v58, v58, 0, 0x6400                               // 000000DEE794: D622003A 03FD013A 00006400
	v_sad_u8 v54, v54, 0, 0x6400                               // 000000DEE7A0: D6220036 03FD0136 00006400
	v_sad_u8 v61, v61, 0, 0x6400                               // 000000DEE7AC: D622003D 03FD013D 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DEE7B8: BF870114
	v_lshlrev_b32_e32 v64, 16, v64                             // 000000DEE7BC: 30808090
	v_lshlrev_b32_e32 v61, 16, v61                             // 000000DEE7C0: 307A7A90
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000DEE7C4: BF870122
	v_and_or_b32 v58, 0xffff, v58, v64                         // 000000DEE7C8: D657003A 050274FF 0000FFFF
	v_bfe_u32 v64, v55, 8, 16                                  // 000000DEE7D4: D6100040 02411137
	v_pk_fma_f16 v58, v58, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DEE7DC: CC0E003A 0BFC0F3A 0000C931
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DEE7E8: BF870191
	v_dot2acc_f32_f16 v18, v58, v2                             // 000000DEE7EC: 0424053A
	.long 0xd72c003a                                           // 000000DEE7F0: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v64, vcc_lo              // 000000DEE7F4: 020280FF 83DCD12D
	v_bfe_u32 v64, v55, 4, 16                                  // 000000DEE7FC: D6100040 02410937
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000DEE804: BF8701A3
	v_dot2acc_f32_f16 v18, v59, v3                             // 000000DEE808: 0424073B
	v_bfe_u32 v59, v53, 12, 16                                 // 000000DEE80C: D610003B 02411935
	.long 0xd72c003c                                           // 000000DEE814: D72C003C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v64, vcc_lo              // 000000DEE818: 020280FF 83DCD12D
	v_bfe_u32 v64, v52, 8, 16                                  // 000000DEE820: D6100040 02411134
	v_and_b32_e32 v52, 0xffff, v52                             // 000000DEE828: 366868FF 0000FFFF
	v_sad_u8 v58, v58, 0, 0x6400                               // 000000DEE830: D622003A 03FD013A 00006400
	.long 0xd72c003b                                           // 000000DEE83C: D72C003B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 000000DEE840: 020276FF 83DCD12D
	v_dot2acc_f32_f16 v18, v57, v4                             // 000000DEE848: 04240939
	.long 0xd72c0040                                           // 000000DEE84C: D72C0040
	v_cndmask_b32_e32 v1, 0x83dcd12d, v64, vcc_lo              // 000000DEE850: 020280FF 83DCD12D
	.long 0xd72c0034                                           // 000000DEE858: D72C0034
	v_cndmask_b32_e32 v1, 0x83dcd12d, v52, vcc_lo              // 000000DEE85C: 020268FF 83DCD12D
	v_lshl_or_b32 v58, v58, 16, v62                            // 000000DEE864: D656003A 04F9213A
	v_bfe_u32 v62, v53, 8, 16                                  // 000000DEE86C: D610003E 02411135
	v_bfe_u32 v53, v53, 4, 16                                  // 000000DEE874: D6100035 02410935
	v_sad_u8 v60, v60, 0, 0x6400                               // 000000DEE87C: D622003C 03FD013C 00006400
	v_sad_u8 v59, v59, 0, 0x6400                               // 000000DEE888: D622003B 03FD013B 00006400
	v_pk_fma_f16 v58, v58, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DEE894: CC0E003A 0BFC0F3A 0000C931
	.long 0xd72c003e                                           // 000000DEE8A0: D72C003E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v62, vcc_lo              // 000000DEE8A4: 02027CFF 83DCD12D
	v_sad_u8 v52, v52, 0, 0x6400                               // 000000DEE8AC: D6220034 03FD0134 00006400
	.long 0xd72c0035                                           // 000000DEE8B8: D72C0035
	v_cndmask_b32_e32 v1, 0x83dcd12d, v53, vcc_lo              // 000000DEE8BC: 02026AFF 83DCD12D
	s_waitcnt vmcnt(3)                                         // 000000DEE8C4: BF890FF7
	v_bfe_u32 v57, v46, 8, 16                                  // 000000DEE8C8: D6100039 0241112E
	v_dot2acc_f32_f16 v17, v58, v3                             // 000000DEE8D0: 0422073A
	v_bfe_u32 v58, v46, 4, 16                                  // 000000DEE8D4: D610003A 0241092E
	v_lshlrev_b32_e32 v52, 16, v52                             // 000000DEE8DC: 30686890
	v_sad_u8 v62, v62, 0, 0x6400                               // 000000DEE8E0: D622003E 03FD013E 00006400
	.long 0xd72c0039                                           // 000000DEE8EC: D72C0039
	v_cndmask_b32_e32 v1, 0x83dcd12d, v57, vcc_lo              // 000000DEE8F0: 020272FF 83DCD12D
	v_sad_u8 v53, v53, 0, 0x6400                               // 000000DEE8F8: D6220035 03FD0135 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DEE904: BF870114
	v_and_or_b32 v52, 0xffff, v54, v52                         // 000000DEE908: D6570034 04D26CFF 0000FFFF
	v_and_or_b32 v53, 0xffff, v53, v61                         // 000000DEE914: D6570035 04F66AFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000DEE920: BF870232
	v_pk_fma_f16 v52, v52, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DEE924: CC0E0034 0BFC0F34 0000C931
	v_and_b32_e32 v59, 0xffff, v59                             // 000000DEE930: 367676FF 0000FFFF
	v_and_b32_e32 v61, 0xffff, v63                             // 000000DEE938: 367A7EFF 0000FFFF
	v_pk_fma_f16 v53, v53, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DEE940: CC0E0035 0BFC0F35 0000C931
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000DEE94C: BF870123
	v_lshl_or_b32 v59, v62, 16, v59                            // 000000DEE950: D656003B 04ED213E
	v_sad_u8 v62, v64, 0, 0x6400                               // 000000DEE958: D622003E 03FD0140 00006400
	v_pk_fma_f16 v59, v59, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DEE964: CC0E003B 0BFC0F3B 0000C931
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DEE970: BF870112
	v_lshl_or_b32 v61, v62, 16, v61                            // 000000DEE974: D656003D 04F5213E
	v_dual_dot2acc_f32_f16 v16, v59, v1 :: v_dual_and_b32 v55, 0xffff, v55// 000000DEE97C: CB24033B 10366EFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DEE988: BF870112
	v_pk_fma_f16 v54, v61, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DEE98C: CC0E0036 0BFC0F3D 0000C931
	v_dot2acc_f32_f16 v16, v53, v2                             // 000000DEE998: 04200535
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DEE99C: BF870113
	.long 0xd72c0037                                           // 000000DEE9A0: D72C0037
	v_cndmask_b32_e32 v1, 0x83dcd12d, v55, vcc_lo              // 000000DEE9A4: 02026EFF 83DCD12D
	v_dot2acc_f32_f16 v16, v54, v3                             // 000000DEE9AC: 04200736
	v_bfe_u32 v54, v49, 12, 16                                 // 000000DEE9B0: D6100036 02411931
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DEE9B8: BF870193
	v_sad_u8 v55, v55, 0, 0x6400                               // 000000DEE9BC: D6220037 03FD0137 00006400
	v_dot2acc_f32_f16 v16, v52, v4                             // 000000DEE9C8: 04200934
	v_bfe_u32 v52, v50, 8, 16                                  // 000000DEE9CC: D6100034 02411132
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DEE9D4: BF870214
	.long 0xd72c0036                                           // 000000DEE9D8: D72C0036
	v_cndmask_b32_e32 v1, 0x83dcd12d, v54, vcc_lo              // 000000DEE9DC: 02026CFF 83DCD12D
	v_lshlrev_b32_e32 v55, 16, v55                             // 000000DEE9E4: 306E6E90
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DEE9E8: BF870113
	.long 0xd72c0034                                           // 000000DEE9EC: D72C0034
	v_cndmask_b32_e32 v1, 0x83dcd12d, v52, vcc_lo              // 000000DEE9F0: 020268FF 83DCD12D
	v_and_or_b32 v55, 0xffff, v60, v55                         // 000000DEE9F8: D6570037 04DE78FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DEEA04: BF870114
	v_sad_u8 v54, v54, 0, 0x6400                               // 000000DEEA08: D6220036 03FD0136 00006400
	v_pk_fma_f16 v53, v55, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DEEA14: CC0E0035 0BFC0F37 0000C931
	v_bfe_u32 v55, v49, 8, 16                                  // 000000DEEA20: D6100037 02411131
	s_delay_alu instid0(VALU_DEP_3)                            // 000000DEEA28: BF870003
	v_and_b32_e32 v54, 0xffff, v54                             // 000000DEEA2C: 366C6CFF 0000FFFF
	v_and_b32_e32 v49, 0xffff, v49                             // 000000DEEA34: 366262FF 0000FFFF
	v_sad_u8 v52, v52, 0, 0x6400                               // 000000DEEA3C: D6220034 03FD0134 00006400
	v_dot2acc_f32_f16 v17, v53, v4                             // 000000DEEA48: 04220935
	v_and_b32_e32 v53, 0xffff, v50                             // 000000DEEA4C: 366A64FF 0000FFFF
	v_bfe_u32 v50, v50, 4, 16                                  // 000000DEEA54: D6100032 02410932
	.long 0xd72c0037                                           // 000000DEEA5C: D72C0037
	v_cndmask_b32_e32 v1, 0x83dcd12d, v55, vcc_lo              // 000000DEEA60: 02026EFF 83DCD12D
	.long 0xd72c0031                                           // 000000DEEA68: D72C0031
	v_cndmask_b32_e32 v1, 0x83dcd12d, v49, vcc_lo              // 000000DEEA6C: 020262FF 83DCD12D
	v_lshl_or_b32 v51, v52, 16, v51                            // 000000DEEA74: D6560033 04CD2134
	.long 0xd72c0035                                           // 000000DEEA7C: D72C0035
	v_cndmask_b32_e32 v1, 0x83dcd12d, v53, vcc_lo              // 000000DEEA80: 02026AFF 83DCD12D
	.long 0xd72c0032                                           // 000000DEEA88: D72C0032
	v_cndmask_b32_e32 v1, 0x83dcd12d, v50, vcc_lo              // 000000DEEA8C: 020264FF 83DCD12D
	.long 0xd72c0034                                           // 000000DEEA94: D72C0034
	v_cndmask_b32_e32 v1, 0x83dcd12d, v56, vcc_lo              // 000000DEEA98: 020270FF 83DCD12D
	v_bfe_u32 v56, v46, 12, 16                                 // 000000DEEAA0: D6100038 0241192E
	v_pk_fma_f16 v51, v51, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DEEAA8: CC0E0033 0BFC0F33 0000C931
	v_sad_u8 v55, v55, 0, 0x6400                               // 000000DEEAB4: D6220037 03FD0137 00006400
	v_sad_u8 v49, v49, 0, 0x6400                               // 000000DEEAC0: D6220031 03FD0131 00006400
	v_sad_u8 v53, v53, 0, 0x6400                               // 000000DEEACC: D6220035 03FD0135 00006400
	v_sad_u8 v50, v50, 0, 0x6400                               // 000000DEEAD8: D6220032 03FD0132 00006400
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DEEAE4: BF870004
	v_lshl_or_b32 v48, v55, 16, v54                            // 000000DEEAE8: D6560030 04D92137
	v_and_b32_e32 v54, 0xffff, v47                             // 000000DEEAF0: 366C5EFF 0000FFFF
	v_bfe_u32 v55, v47, 8, 16                                  // 000000DEEAF8: D6100037 0241112F
	v_lshlrev_b32_e32 v53, 16, v53                             // 000000DEEB00: 306A6A90
	.long 0xd72c0038                                           // 000000DEEB04: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v56, vcc_lo              // 000000DEEB08: 020270FF 83DCD12D
	v_sad_u8 v52, v52, 0, 0x6400                               // 000000DEEB10: D6220034 03FD0134 00006400
	.long 0xd72c0036                                           // 000000DEEB1C: D72C0036
	v_cndmask_b32_e32 v1, 0x83dcd12d, v54, vcc_lo              // 000000DEEB20: 02026CFF 83DCD12D
	.long 0xd72c0037                                           // 000000DEEB28: D72C0037
	v_cndmask_b32_e32 v1, 0x83dcd12d, v55, vcc_lo              // 000000DEEB2C: 02026EFF 83DCD12D
	v_and_or_b32 v50, 0xffff, v50, v53                         // 000000DEEB34: D6570032 04D664FF 0000FFFF
	v_bfe_u32 v53, v47, 12, 16                                 // 000000DEEB40: D6100035 0241192F
	v_bfe_u32 v47, v47, 4, 16                                  // 000000DEEB48: D610002F 0241092F
	v_lshlrev_b32_e32 v49, 16, v49                             // 000000DEEB50: 30626290
	v_sad_u8 v56, v56, 0, 0x6400                               // 000000DEEB54: D6220038 03FD0138 00006400
	v_pk_fma_f16 v50, v50, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DEEB60: CC0E0032 0BFC0F32 0000C931
	.long 0xd72c0035                                           // 000000DEEB6C: D72C0035
	v_cndmask_b32_e32 v1, 0x83dcd12d, v53, vcc_lo              // 000000DEEB70: 02026AFF 83DCD12D
	.long 0xd72c002f                                           // 000000DEEB78: D72C002F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v47, vcc_lo              // 000000DEEB7C: 02025EFF 83DCD12D
	v_sad_u8 v54, v54, 0, 0x6400                               // 000000DEEB84: D6220036 03FD0136 00006400
	v_sad_u8 v55, v55, 0, 0x6400                               // 000000DEEB90: D6220037 03FD0137 00006400
	v_and_or_b32 v49, 0xffff, v52, v49                         // 000000DEEB9C: D6570031 04C668FF 0000FFFF
	v_dot2acc_f32_f16 v15, v51, v1                             // 000000DEEBA8: 041E0333
	v_pk_fma_f16 v48, v48, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DEEBAC: CC0E0030 0BFC0F30 0000C931
	v_lshlrev_b32_e32 v54, 16, v54                             // 000000DEEBB8: 306C6C90
	v_sad_u8 v53, v53, 0, 0x6400                               // 000000DEEBBC: D6220035 03FD0135 00006400
	v_sad_u8 v47, v47, 0, 0x6400                               // 000000DEEBC8: D622002F 03FD012F 00006400
	v_dot2acc_f32_f16 v15, v50, v2                             // 000000DEEBD4: 041E0532
	s_waitcnt vmcnt(2)                                         // 000000DEEBD8: BF890BF7
	v_bfe_u32 v50, v43, 12, 16                                 // 000000DEEBDC: D6100032 0241192B
	v_and_b32_e32 v53, 0xffff, v53                             // 000000DEEBE4: 366A6AFF 0000FFFF
	v_and_or_b32 v47, 0xffff, v47, v54                         // 000000DEEBEC: D657002F 04DA5EFF 0000FFFF
	v_dual_dot2acc_f32_f16 v15, v48, v3 :: v_dual_and_b32 v54, 0xffff, v56// 000000DEEBF8: CB240730 0F3670FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DEEC04: BF870214
	.long 0xd72c0032                                           // 000000DEEC08: D72C0032
	v_cndmask_b32_e32 v1, 0x83dcd12d, v50, vcc_lo              // 000000DEEC0C: 020264FF 83DCD12D
	v_lshl_or_b32 v52, v55, 16, v53                            // 000000DEEC14: D6560034 04D52137
	v_sad_u8 v55, v57, 0, 0x6400                               // 000000DEEC1C: D6220037 03FD0139 00006400
	v_pk_fma_f16 v47, v47, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DEEC28: CC0E002F 0BFC0F2F 0000C931
	.long 0xd72c0035                                           // 000000DEEC34: D72C0035
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 000000DEEC38: 020274FF 83DCD12D
	v_mov_b32_e32 v57, v41                                     // 000000DEEC40: 7E720329
	v_pk_fma_f16 v51, v52, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DEEC44: CC0E0033 0BFC0F34 0000C931
	v_lshl_or_b32 v52, v55, 16, v54                            // 000000DEEC50: D6560034 04D92137
	v_sad_u8 v50, v50, 0, 0x6400                               // 000000DEEC58: D6220032 03FD0132 00006400
	v_dual_mov_b32 v55, v41 :: v_dual_mov_b32 v56, v35         // 000000DEEC64: CA100129 37380123
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DEEC6C: BF870214
	v_dot2acc_f32_f16 v14, v51, v1                             // 000000DEEC70: 041C0333
	v_pk_fma_f16 v45, v52, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DEEC74: CC0E002D 0BFC0F34 0000C931
	v_bfe_u32 v51, v43, 8, 16                                  // 000000DEEC80: D6100033 0241112B
	v_bfe_u32 v52, v43, 4, 16                                  // 000000DEEC88: D6100034 0241092B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000DEEC90: BF870234
	v_dual_dot2acc_f32_f16 v14, v47, v2 :: v_dual_and_b32 v43, 0xffff, v43// 000000DEEC94: CB24052F 0E2A56FF 0000FFFF
	v_pk_fma_f16 v47, v49, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DEECA0: CC0E002F 0BFC0F31 0000C931
	v_bfe_u32 v49, v44, 12, 16                                 // 000000DEECAC: D6100031 0241192C
	.long 0xd72c0034                                           // 000000DEECB4: D72C0034
	v_cndmask_b32_e32 v1, 0x83dcd12d, v52, vcc_lo              // 000000DEECB8: 020268FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DEECC0: BF870004
	.long 0xd72c002b                                           // 000000DEECC4: D72C002B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v43, vcc_lo              // 000000DEECC8: 020256FF 83DCD12D
	v_dot2acc_f32_f16 v14, v45, v3                             // 000000DEECD0: 041C072D
	v_bfe_u32 v45, v44, 8, 16                                  // 000000DEECD4: D610002D 0241112C
	.long 0xd72c0030                                           // 000000DEECDC: D72C0030
	v_cndmask_b32_e32 v1, 0x83dcd12d, v49, vcc_lo              // 000000DEECE0: 020262FF 83DCD12D
	v_and_b32_e32 v49, 0xffff, v44                             // 000000DEECE8: 366258FF 0000FFFF
	v_bfe_u32 v44, v44, 4, 16                                  // 000000DEECF0: D610002C 0241092C
	.long 0xd72c0033                                           // 000000DEECF8: D72C0033
	v_cndmask_b32_e32 v1, 0x83dcd12d, v51, vcc_lo              // 000000DEECFC: 020266FF 83DCD12D
	v_sad_u8 v52, v52, 0, 0x6400                               // 000000DEED04: D6220034 03FD0134 00006400
	v_sad_u8 v43, v43, 0, 0x6400                               // 000000DEED10: D622002B 03FD012B 00006400
	.long 0xd72c0031                                           // 000000DEED1C: D72C0031
	v_cndmask_b32_e32 v1, 0x83dcd12d, v49, vcc_lo              // 000000DEED20: 020262FF 83DCD12D
	.long 0xd72c002d                                           // 000000DEED28: D72C002D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v45, vcc_lo              // 000000DEED2C: 02025AFF 83DCD12D
	v_sad_u8 v48, v48, 0, 0x6400                               // 000000DEED34: D6220030 03FD0130 00006400
	.long 0xd72c002c                                           // 000000DEED40: D72C002C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v44, vcc_lo              // 000000DEED44: 020258FF 83DCD12D
	v_lshlrev_b32_e32 v43, 16, v43                             // 000000DEED4C: 30565690
	v_sad_u8 v51, v51, 0, 0x6400                               // 000000DEED50: D6220033 03FD0133 00006400
	v_sad_u8 v53, v53, 0, 0x6400                               // 000000DEED5C: D6220035 03FD0135 00006400
	v_and_b32_e32 v48, 0xffff, v48                             // 000000DEED68: 366060FF 0000FFFF
	v_sad_u8 v49, v49, 0, 0x6400                               // 000000DEED70: D6220031 03FD0131 00006400
	v_and_or_b32 v43, 0xffff, v52, v43                         // 000000DEED7C: D657002B 04AE68FF 0000FFFF
	v_sad_u8 v45, v45, 0, 0x6400                               // 000000DEED88: D622002D 03FD012D 00006400
	v_sad_u8 v44, v44, 0, 0x6400                               // 000000DEED94: D622002C 03FD012C 00006400
	s_waitcnt vmcnt(1)                                         // 000000DEEDA0: BF8907F7
	v_bfe_u32 v52, v25, 8, 16                                  // 000000DEEDA4: D6100034 02411119
	v_lshlrev_b32_e32 v49, 16, v49                             // 000000DEEDAC: 30626290
	v_pk_fma_f16 v43, v43, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DEEDB0: CC0E002B 0BFC0F2B 0000C931
	v_and_b32_e32 v50, 0xffff, v50                             // 000000DEEDBC: 366464FF 0000FFFF
	v_lshl_or_b32 v45, v45, 16, v48                            // 000000DEEDC4: D656002D 04C1212D
	v_bfe_u32 v48, v26, 12, 16                                 // 000000DEEDCC: D6100030 0241191A
	v_and_or_b32 v44, 0xffff, v44, v49                         // 000000DEEDD4: D657002C 04C658FF 0000FFFF
	v_and_b32_e32 v49, 0xffff, v26                             // 000000DEEDE0: 366234FF 0000FFFF
	v_lshl_or_b32 v27, v51, 16, v50                            // 000000DEEDE8: D656001B 04C92133
	v_bfe_u32 v50, v25, 12, 16                                 // 000000DEEDF0: D6100032 02411919
	v_pk_fma_f16 v45, v45, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DEEDF8: CC0E002D 0BFC0F2D 0000C931
	.long 0xd72c0030                                           // 000000DEEE04: D72C0030
	v_cndmask_b32_e32 v1, 0x83dcd12d, v48, vcc_lo              // 000000DEEE08: 020260FF 83DCD12D
	v_bfe_u32 v51, v26, 8, 16                                  // 000000DEEE10: D6100033 0241111A
	v_bfe_u32 v26, v26, 4, 16                                  // 000000DEEE18: D610001A 0241091A
	.long 0xd72c0032                                           // 000000DEEE20: D72C0032
	v_cndmask_b32_e32 v1, 0x83dcd12d, v50, vcc_lo              // 000000DEEE24: 020264FF 83DCD12D
	.long 0xd72c0031                                           // 000000DEEE2C: D72C0031
	v_cndmask_b32_e32 v1, 0x83dcd12d, v49, vcc_lo              // 000000DEEE30: 020262FF 83DCD12D
	v_dot2acc_f32_f16 v13, v45, v1                             // 000000DEEE38: 041A032D
	.long 0xd72c0033                                           // 000000DEEE3C: D72C0033
	v_cndmask_b32_e32 v1, 0x83dcd12d, v51, vcc_lo              // 000000DEEE40: 020266FF 83DCD12D
	.long 0xd72c002d                                           // 000000DEEE48: D72C002D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v52, vcc_lo              // 000000DEEE4C: 020268FF 83DCD12D
	v_pk_fma_f16 v44, v44, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DEEE54: CC0E002C 0BFC0F2C 0000C931
	v_sad_u8 v48, v48, 0, 0x6400                               // 000000DEEE60: D6220030 03FD0130 00006400
	.long 0xd72c001a                                           // 000000DEEE6C: D72C001A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v26, vcc_lo              // 000000DEEE70: 020234FF 83DCD12D
	v_sad_u8 v50, v50, 0, 0x6400                               // 000000DEEE78: D6220032 03FD0132 00006400
	v_sad_u8 v49, v49, 0, 0x6400                               // 000000DEEE84: D6220031 03FD0131 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000DEEE90: BF870224
	v_dual_dot2acc_f32_f16 v13, v44, v2 :: v_dual_and_b32 v48, 0xffff, v48// 000000DEEE94: CB24052C 0D3060FF 0000FFFF
	v_sad_u8 v51, v51, 0, 0x6400                               // 000000DEEEA0: D6220033 03FD0133 00006400
	v_and_b32_e32 v50, 0xffff, v50                             // 000000DEEEAC: 366464FF 0000FFFF
	v_sad_u8 v45, v45, 0, 0x6400                               // 000000DEEEB4: D622002D 03FD012D 00006400
	v_bfe_u32 v44, v20, 12, 16                                 // 000000DEEEC0: D610002C 02411914
	v_sad_u8 v26, v26, 0, 0x6400                               // 000000DEEEC8: D622001A 03FD011A 00006400
	v_lshlrev_b32_e32 v49, 16, v49                             // 000000DEEED4: 30626290
	v_bfe_u32 v52, v25, 4, 16                                  // 000000DEEED8: D6100034 02410919
	v_lshl_or_b32 v48, v51, 16, v48                            // 000000DEEEE0: D6560030 04C12133
	v_lshl_or_b32 v45, v45, 16, v50                            // 000000DEEEE8: D656002D 04C9212D
	.long 0xd72c002c                                           // 000000DEEEF0: D72C002C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v44, vcc_lo              // 000000DEEEF4: 020258FF 83DCD12D
	v_bfe_u32 v50, v20, 8, 16                                  // 000000DEEEFC: D6100032 02411114
	s_waitcnt vmcnt(0)                                         // 000000DEEF04: BF8903F7
	v_bfe_u32 v51, v19, 12, 16                                 // 000000DEEF08: D6100033 02411913
	v_and_or_b32 v26, 0xffff, v26, v49                         // 000000DEEF10: D657001A 04C634FF 0000FFFF
	.long 0xd72c0031                                           // 000000DEEF1C: D72C0031
	v_cndmask_b32_e32 v1, 0x83dcd12d, v52, vcc_lo              // 000000DEEF20: 020268FF 83DCD12D
	v_bfe_u32 v52, v19, 8, 16                                  // 000000DEEF28: D6100034 02411113
	.long 0xd72c0032                                           // 000000DEEF30: D72C0032
	v_cndmask_b32_e32 v1, 0x83dcd12d, v50, vcc_lo              // 000000DEEF34: 020264FF 83DCD12D
	.long 0xd72c0033                                           // 000000DEEF3C: D72C0033
	v_cndmask_b32_e32 v1, 0x83dcd12d, v51, vcc_lo              // 000000DEEF40: 020266FF 83DCD12D
	v_pk_fma_f16 v27, v27, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DEEF48: CC0E001B 0BFC0F1B 0000C931
	v_and_b32_e32 v46, 0xffff, v46                             // 000000DEEF54: 365C5CFF 0000FFFF
	v_sad_u8 v44, v44, 0, 0x6400                               // 000000DEEF5C: D622002C 03FD012C 00006400
	.long 0xd72c0034                                           // 000000DEEF68: D72C0034
	v_cndmask_b32_e32 v1, 0x83dcd12d, v52, vcc_lo              // 000000DEEF6C: 020268FF 83DCD12D
	v_and_b32_e32 v25, 0xffff, v25                             // 000000DEEF74: 363232FF 0000FFFF
	v_dot2acc_f32_f16 v13, v27, v3                             // 000000DEEF7C: 041A071B
	.long 0xd72c002e                                           // 000000DEEF80: D72C002E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v46, vcc_lo              // 000000DEEF84: 02025CFF 83DCD12D
	v_and_b32_e32 v44, 0xffff, v44                             // 000000DEEF8C: 365858FF 0000FFFF
	v_sad_u8 v50, v50, 0, 0x6400                               // 000000DEEF94: D6220032 03FD0132 00006400
	v_sad_u8 v51, v51, 0, 0x6400                               // 000000DEEFA0: D6220033 03FD0133 00006400
	v_dual_mov_b32 v54, v40 :: v_dual_dot2acc_f32_f16 v15, v47, v4// 000000DEEFAC: CA180128 360E092F
	v_pk_fma_f16 v26, v26, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DEEFB4: CC0E001A 0BFC0F1A 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DEEFC0: BF870214
	v_lshl_or_b32 v44, v50, 16, v44                            // 000000DEEFC4: D656002C 04B12132
	v_dual_mov_b32 v27, v36 :: v_dual_and_b32 v50, 0xffff, v51 // 000000DEEFCC: CA240124 1B3266FF 0000FFFF
	v_sad_u8 v51, v52, 0, 0x6400                               // 000000DEEFD8: D6220033 03FD0134 00006400
	v_mov_b32_e32 v52, v40                                     // 000000DEEFE4: 7E680328
	.long 0xd72c0015                                           // 000000DEEFE8: D72C0015
	v_cndmask_b32_e32 v1, 0x83dcd12d, v25, vcc_lo              // 000000DEEFEC: 020232FF 83DCD12D
	v_pk_fma_f16 v25, v48, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DEEFF4: CC0E0019 0BFC0F30 0000C931
	v_sad_u8 v48, v49, 0, 0x6400                               // 000000DEF000: D6220030 03FD0131 00006400
	v_and_b32_e32 v49, 0xffff, v20                             // 000000DEF00C: 366228FF 0000FFFF
	v_sad_u8 v46, v46, 0, 0x6400                               // 000000DEF014: D622002E 03FD012E 00006400
	v_bfe_u32 v20, v20, 4, 16                                  // 000000DEF020: D6100014 02410914
	v_dot2acc_f32_f16 v12, v25, v1                             // 000000DEF028: 04180319
	v_pk_fma_f16 v25, v44, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DEF02C: CC0E0019 0BFC0F2C 0000C931
	.long 0xd72c0031                                           // 000000DEF038: D72C0031
	v_cndmask_b32_e32 v1, 0x83dcd12d, v49, vcc_lo              // 000000DEF03C: 020262FF 83DCD12D
	v_lshlrev_b32_e32 v46, 16, v46                             // 000000DEF044: 305C5C90
	.long 0xd72c0014                                           // 000000DEF048: D72C0014
	v_cndmask_b32_e32 v1, 0x83dcd12d, v20, vcc_lo              // 000000DEF04C: 020228FF 83DCD12D
	v_sad_u8 v21, v21, 0, 0x6400                               // 000000DEF054: D6220015 03FD0115 00006400
	v_lshl_or_b32 v44, v51, 16, v50                            // 000000DEF060: D656002C 04C92133
	v_dot2acc_f32_f16 v11, v25, v1                             // 000000DEF068: 04160319
	v_and_or_b32 v46, 0xffff, v53, v46                         // 000000DEF06C: D657002E 04BA6AFF 0000FFFF
	v_bfe_u32 v53, v19, 4, 16                                  // 000000DEF078: D6100035 02410913
	v_sad_u8 v49, v49, 0, 0x6400                               // 000000DEF080: D6220031 03FD0131 00006400
	v_and_b32_e32 v19, 0xffff, v19                             // 000000DEF08C: 362626FF 0000FFFF
	v_sad_u8 v20, v20, 0, 0x6400                               // 000000DEF094: D6220014 03FD0114 00006400
	v_lshlrev_b32_e32 v21, 16, v21                             // 000000DEF0A0: 302A2A90
	v_pk_fma_f16 v45, v45, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DEF0A4: CC0E002D 0BFC0F2D 0000C931
	v_lshlrev_b32_e32 v49, 16, v49                             // 000000DEF0B0: 30626290
	.long 0xd72c0013                                           // 000000DEF0B4: D72C0013
	v_cndmask_b32_e32 v1, 0x83dcd12d, v19, vcc_lo              // 000000DEF0B8: 020226FF 83DCD12D
	v_dot2acc_f32_f16 v12, v26, v2                             // 000000DEF0C0: 0418051A
	v_and_or_b32 v1, 0xffff, v48, v21                          // 000000DEF0C4: D6570001 045660FF 0000FFFF
	v_pk_fma_f16 v21, v44, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DEF0D0: CC0E0015 0BFC0F2C 0000C931
	v_and_or_b32 v20, 0xffff, v20, v49                         // 000000DEF0DC: D6570014 04C628FF 0000FFFF
	.long 0xd72c0031                                           // 000000DEF0E8: D72C0031
	v_cndmask_b32_e32 v1, 0x83dcd12d, v53, vcc_lo              // 000000DEF0EC: 02026AFF 83DCD12D
	v_pk_fma_f16 v46, v46, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DEF0F4: CC0E002E 0BFC0F2E 0000C931
	v_pk_fma_f16 v1, v1, s7, 0xc931 op_sel_hi:[1,0,0]          // 000000DEF100: CC0E0001 0BFC0F01 0000C931
	v_sad_u8 v19, v19, 0, 0x6400                               // 000000DEF10C: D6220013 03FD0113 00006400
	v_pk_fma_f16 v20, v20, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DEF118: CC0E0014 0BFC0F14 0000C931
	v_dot2acc_f32_f16 v12, v45, v3                             // 000000DEF124: 0418072D
	v_dot2acc_f32_f16 v14, v46, v4                             // 000000DEF128: 041C092E
	v_dot2acc_f32_f16 v13, v43, v4                             // 000000DEF12C: 041A092B
	v_sad_u8 v49, v49, 0, 0x6400                               // 000000DEF130: D6220031 03FD0131 00006400
	v_lshlrev_b32_e32 v19, 16, v19                             // 000000DEF13C: 30262690
	v_dual_dot2acc_f32_f16 v11, v20, v2 :: v_dual_dot2acc_f32_f16 v12, v1, v4// 000000DEF140: CB180514 0B0C0901
	v_dual_mov_b32 v20, v6 :: v_dual_mov_b32 v25, v36          // 000000DEF148: CA100106 14180124
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DEF150: BF870193
	v_and_or_b32 v19, 0xffff, v49, v19                         // 000000DEF154: D6570013 044E62FF 0000FFFF
	v_dot2acc_f32_f16 v11, v21, v3                             // 000000DEF160: 04160715
	v_dual_mov_b32 v21, v34 :: v_dual_mov_b32 v26, v28         // 000000DEF164: CA100122 151A011C
	v_mov_b32_e32 v43, v37                                     // 000000DEF16C: 7E560325
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DEF170: BF870004
	v_pk_fma_f16 v2, v19, s7, 0xc931 op_sel_hi:[1,0,0]         // 000000DEF174: CC0E0002 0BFC0F13 0000C931
	v_mov_b32_e32 v19, v34                                     // 000000DEF180: 7E260322
	v_mov_b32_e32 v45, v37                                     // 000000DEF184: 7E5A0325
	v_mov_b32_e32 v44, v29                                     // 000000DEF188: 7E58031D
	v_mov_b32_e32 v46, v38                                     // 000000DEF18C: 7E5C0326
	v_dot2acc_f32_f16 v11, v2, v4                              // 000000DEF190: 04160902
	v_mov_b32_e32 v48, v38                                     // 000000DEF194: 7E600326
	v_mov_b32_e32 v47, v30                                     // 000000DEF198: 7E5E031E
	v_mov_b32_e32 v49, v39                                     // 000000DEF19C: 7E620327
	v_mov_b32_e32 v51, v39                                     // 000000DEF1A0: 7E660327
	v_dual_mov_b32 v50, v31 :: v_dual_mov_b32 v53, v32         // 000000DEF1A4: CA10011F 32340120
	v_mov_b32_e32 v3, v42                                      // 000000DEF1AC: 7E06032A
	v_mov_b32_e32 v4, v42                                      // 000000DEF1B0: 7E08032A
	v_mov_b32_e32 v2, v33                                      // 000000DEF1B4: 7E040321
	v_mov_b32_e32 v1, v5                                       // 000000DEF1B8: 7E020305
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 000000DEF1BC: 917E067E
	s_cbranch_execz 58                                         // 000000DEF1C0: BFA5003A <_ZN7halogen12_GLOBAL__N_113k_i4r_rows_glILi1EEEvPKhlPKDF16_PKiPfS5_S5_PDF16_PjNS0_5I4rSdEi+0x19ac>
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DEF1C4: BF8700A1
	v_add_nc_u32_e32 v5, 1, v1                                 // 000000DEF1C8: 4A0A0281
	s_mov_b32 s8, exec_lo                                      // 000000DEF1CC: BE88007E
	.long 0xd4c1007e                                           // 000000DEF1D0: D4C1007E
	v_cndmask_b32_e32 v1, v5, v10, vcc_lo                      // 000000DEF1D4: 02021505
	s_cbranch_execz 64670                                      // 000000DEF1D8: BFA5FC9E <_ZN7halogen12_GLOBAL__N_113k_i4r_rows_glILi1EEEvPKhlPKDF16_PKiPfS5_S5_PDF16_PjNS0_5I4rSdEi+0xb54>
	v_ashrrev_i32_e32 v6, 31, v5                               // 000000DEF1DC: 340C0A9F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DEF1E0: BF870091
	.long 0xd73c001c                                           // 000000DEF1E4: D73C001C
	v_cndmask_b32_e32 v1, 10, v5, vcc_lo                       // 000000DEF1E8: 02020A8A
	.long 0xd7006a06                                           // 000000DEF1EC: D7006A06
	v_cndmask_b32_e32 v1, s4, v28, vcc_lo                      // 000000DEF1F0: 02023804
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DEF1F4: BF870111
	v_add_co_ci_u32_e64 v28, null, s5, v29, vcc_lo             // 000000DEF1F8: D5207C1C 01AA3A05
	.long 0xd7006a24                                           // 000000DEF200: D7006A24
	v_cndmask_b32_e32 v1, v6, v24, vcc_lo                      // 000000DEF204: 02023106
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DEF208: BF8700A1
	v_add_co_ci_u32_e64 v37, null, 0, v28, vcc_lo              // 000000DEF20C: D5207C25 01AA3880
	.long 0xd7006a3a                                           // 000000DEF214: D7006A3A
	v_cndmask_b32_e32 v1, v6, v23, vcc_lo                      // 000000DEF218: 02022F06
	v_add_co_ci_u32_e64 v59, null, 0, v28, vcc_lo              // 000000DEF21C: D5207C3B 01AA3880
	s_clause 0xf                                               // 000000DEF224: BF85000F
	global_load_b32 v33, v[36:37], off                         // 000000DEF228: DC520000 217C0024
	global_load_b32 v35, v[36:37], off offset:128              // 000000DEF230: DC520080 237C0024
	global_load_b32 v32, v[36:37], off offset:256              // 000000DEF238: DC520100 207C0024
	global_load_b32 v31, v[36:37], off offset:384              // 000000DEF240: DC520180 1F7C0024
	global_load_b32 v30, v[36:37], off offset:512              // 000000DEF248: DC520200 1E7C0024
	global_load_b32 v29, v[36:37], off offset:640              // 000000DEF250: DC520280 1D7C0024
	global_load_b32 v28, v[36:37], off offset:768              // 000000DEF258: DC520300 1C7C0024
	global_load_b32 v6, v[36:37], off offset:896               // 000000DEF260: DC520380 067C0024
	global_load_b32 v42, v[58:59], off                         // 000000DEF268: DC520000 2A7C003A
	global_load_b32 v41, v[58:59], off offset:128              // 000000DEF270: DC520080 297C003A
	global_load_b32 v40, v[58:59], off offset:256              // 000000DEF278: DC520100 287C003A
	global_load_b32 v39, v[58:59], off offset:384              // 000000DEF280: DC520180 277C003A
	global_load_b32 v38, v[58:59], off offset:512              // 000000DEF288: DC520200 267C003A
	global_load_b32 v37, v[58:59], off offset:640              // 000000DEF290: DC520280 257C003A
	global_load_b32 v36, v[58:59], off offset:768              // 000000DEF298: DC520300 247C003A
	global_load_b32 v34, v[58:59], off offset:896              // 000000DEF2A0: DC520380 227C003A
	s_branch 64618                                             // 000000DEF2A8: BFA0FC6A <_ZN7halogen12_GLOBAL__N_113k_i4r_rows_glILi1EEEvPKhlPKDF16_PKiPfS5_S5_PDF16_PjNS0_5I4rSdEi+0xb54>
	s_or_b32 exec_lo, exec_lo, s6                              // 000000DEF2AC: 8C7E067E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000DEF2B0: BF870009
	s_or_b32 exec_lo, exec_lo, s3                              // 000000DEF2B4: 8C7E037E
	s_waitcnt vmcnt(23)                                        // 000000DEF2B8: BF895FF7
	v_dual_mov_b32 v1, v18 :: v_dual_mov_b32 v2, v17           // 000000DEF2BC: CA100112 01020111
	s_waitcnt vmcnt(7)                                         // 000000DEF2C4: BF891FF7
	v_dual_mov_b32 v3, v16 :: v_dual_mov_b32 v10, v15          // 000000DEF2C8: CA100110 030A010F
	v_dual_mov_b32 v4, v14 :: v_dual_mov_b32 v5, v13           // 000000DEF2D0: CA10010E 0404010D
	s_waitcnt vmcnt(0)                                         // 000000DEF2D8: BF8903F7
	v_dual_mov_b32 v6, v12 :: v_dual_mov_b32 v19, v11          // 000000DEF2DC: CA10010C 0612010B
	s_mov_b32 s3, 0x76543210                                   // 000000DEF2E4: BE8300FF 76543210
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000DEF2EC: BF870009
	v_permlanex16_b32 v1, v1, s3, 0xfedcba98                   // 000000DEF2F0: D65C0001 03FC0701 FEDCBA98
	v_permlanex16_b32 v2, v2, s3, 0xfedcba98                   // 000000DEF2FC: D65C0002 03FC0702 FEDCBA98
	v_permlanex16_b32 v3, v3, s3, 0xfedcba98                   // 000000DEF308: D65C0003 03FC0703 FEDCBA98
	v_permlanex16_b32 v10, v10, s3, 0xfedcba98                 // 000000DEF314: D65C000A 03FC070A FEDCBA98
	v_permlanex16_b32 v4, v4, s3, 0xfedcba98                   // 000000DEF320: D65C0004 03FC0704 FEDCBA98
	v_permlanex16_b32 v5, v5, s3, 0xfedcba98                   // 000000DEF32C: D65C0005 03FC0705 FEDCBA98
	v_permlanex16_b32 v6, v6, s3, 0xfedcba98                   // 000000DEF338: D65C0006 03FC0706 FEDCBA98
	v_permlanex16_b32 v19, v19, s3, 0xfedcba98                 // 000000DEF344: D65C0013 03FC0713 FEDCBA98
	.long 0xd44c0003                                           // 000000DEF350: D44C0003
	v_cndmask_b32_e32 v1, 16, v9, vcc_lo                       // 000000DEF354: 02021290
	s_barrier                                                  // 000000DEF358: BFBD0000
	buffer_gl0_inv                                             // 000000DEF35C: E0AC0000 00000000
	s_and_saveexec_b32 s4, s3                                  // 000000DEF364: BE842003
	s_cbranch_execz 18                                         // 000000DEF368: BFA50012 <_ZN7halogen12_GLOBAL__N_113k_i4r_rows_glILi1EEEvPKhlPKDF16_PKiPfS5_S5_PDF16_PjNS0_5I4rSdEi+0x1ab4>
	v_dual_add_f32 v9, v11, v19 :: v_dual_add_f32 v2, v17, v2  // 000000DEF36C: C908270B 09020511
	v_dual_add_f32 v1, v18, v1 :: v_dual_add_f32 v10, v15, v10 // 000000DEF374: C9080312 010A150F
	v_lshl_or_b32 v7, v8, 9, v7                                // 000000DEF37C: D6560007 041D1308
	v_dual_add_f32 v3, v16, v3 :: v_dual_add_f32 v4, v14, v4   // 000000DEF384: C9080710 0304090E
	v_dual_add_f32 v5, v13, v5 :: v_dual_add_f32 v6, v12, v6   // 000000DEF38C: C9080B0D 05060D0C
	ds_store_2addr_b32 v7, v1, v2 offset1:16                   // 000000DEF394: D8381000 00020107
	ds_store_2addr_b32 v7, v3, v10 offset0:32 offset1:48       // 000000DEF39C: D8383020 000A0307
	ds_store_2addr_b32 v7, v4, v5 offset0:64 offset1:80        // 000000DEF3A4: D8385040 00050407
	ds_store_2addr_b32 v7, v6, v9 offset0:96 offset1:112       // 000000DEF3AC: D8387060 00090607
	s_or_b32 exec_lo, exec_lo, s4                              // 000000DEF3B4: 8C7E047E
	.long 0xd44c0004                                           // 000000DEF3B8: D44C0004
	v_cndmask_b32_e32 v1, 0x80, v0, vcc_lo                     // 000000DEF3BC: 020200FF 00000080
	s_waitcnt lgkmcnt(0)                                       // 000000DEF3C4: BF89FC07
	s_barrier                                                  // 000000DEF3C8: BFBD0000
	buffer_gl0_inv                                             // 000000DEF3CC: E0AC0000 00000000
	s_and_saveexec_b32 s5, s4                                  // 000000DEF3D4: BE852004
	s_cbranch_execnz 7                                         // 000000DEF3D8: BFA60007 <_ZN7halogen12_GLOBAL__N_113k_i4r_rows_glILi1EEEvPKhlPKDF16_PKiPfS5_S5_PDF16_PjNS0_5I4rSdEi+0x1af8>
	s_or_b32 exec_lo, exec_lo, s5                              // 000000DEF3DC: 8C7E057E
	s_cmp_lt_i32 s11, 2                                        // 000000DEF3E0: BF04820B
	s_mov_b32 s5, -1                                           // 000000DEF3E4: BE8500C1
	s_cbranch_scc0 33                                          // 000000DEF3E8: BFA10021 <_ZN7halogen12_GLOBAL__N_113k_i4r_rows_glILi1EEEvPKhlPKDF16_PKiPfS5_S5_PDF16_PjNS0_5I4rSdEi+0x1b70>
	s_and_b32 vcc_lo, exec_lo, s5                              // 000000DEF3EC: 8B6A057E
	s_cbranch_vccnz 155                                        // 000000DEF3F0: BFA4009B <_ZN7halogen12_GLOBAL__N_113k_i4r_rows_glILi1EEEvPKhlPKDF16_PKiPfS5_S5_PDF16_PjNS0_5I4rSdEi+0x1d60>
	s_branch 518                                               // 000000DEF3F4: BFA00206 <_ZN7halogen12_GLOBAL__N_113k_i4r_rows_glILi1EEEvPKhlPKDF16_PKiPfS5_S5_PDF16_PjNS0_5I4rSdEi+0x2310>
	v_lshlrev_b32_e32 v7, 2, v0                                // 000000DEF3F8: 300E0082
	ds_load_2addr_stride64_b32 v[1:2], v7 offset1:2            // 000000DEF3FC: D8E00200 01000007
	ds_load_2addr_stride64_b32 v[3:4], v7 offset0:4 offset1:6  // 000000DEF404: D8E00604 03000007
	ds_load_2addr_stride64_b32 v[5:6], v7 offset0:8 offset1:10 // 000000DEF40C: D8E00A08 05000007
	s_waitcnt lgkmcnt(2)                                       // 000000DEF414: BF89FC27
	v_add_f32_e32 v1, 0, v1                                    // 000000DEF418: 06020280
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DEF41C: BF8700A1
	v_add_f32_e32 v1, v1, v2                                   // 000000DEF420: 06020501
	s_waitcnt lgkmcnt(1)                                       // 000000DEF424: BF89FC17
	v_add_f32_e32 v3, v1, v3                                   // 000000DEF428: 06060701
	ds_load_2addr_stride64_b32 v[1:2], v7 offset0:12 offset1:14// 000000DEF42C: D8E00E0C 01000007
	v_add_f32_e32 v3, v3, v4                                   // 000000DEF434: 06060903
	s_waitcnt lgkmcnt(1)                                       // 000000DEF438: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DEF43C: BF870091
	v_add_f32_e32 v3, v3, v5                                   // 000000DEF440: 06060B03
	v_add_f32_e32 v3, v3, v6                                   // 000000DEF444: 06060D03
	s_waitcnt lgkmcnt(0)                                       // 000000DEF448: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DEF44C: BF870091
	v_add_f32_e32 v1, v3, v1                                   // 000000DEF450: 06020303
	v_add_f32_e32 v1, v1, v2                                   // 000000DEF454: 06020501
	ds_store_b32 v7, v1 offset:4096                            // 000000DEF458: D8341000 00000107
	s_or_b32 exec_lo, exec_lo, s5                              // 000000DEF460: 8C7E057E
	s_cmp_lt_i32 s11, 2                                        // 000000DEF464: BF04820B
	s_mov_b32 s5, -1                                           // 000000DEF468: BE8500C1
	s_cbranch_scc1 65503                                       // 000000DEF46C: BFA2FFDF <_ZN7halogen12_GLOBAL__N_113k_i4r_rows_glILi1EEEvPKhlPKDF16_PKiPfS5_S5_PDF16_PjNS0_5I4rSdEi+0x1aec>
	s_waitcnt lgkmcnt(0)                                       // 000000DEF470: BF89FC07
	s_barrier                                                  // 000000DEF474: BFBD0000
	buffer_gl0_inv                                             // 000000DEF478: E0AC0000 00000000
	s_and_saveexec_b32 s5, s4                                  // 000000DEF480: BE852004
	s_cbranch_execz 17                                         // 000000DEF484: BFA50011 <_ZN7halogen12_GLOBAL__N_113k_i4r_rows_glILi1EEEvPKhlPKDF16_PKiPfS5_S5_PDF16_PjNS0_5I4rSdEi+0x1bcc>
	v_lshlrev_b32_e32 v1, 2, v0                                // 000000DEF488: 30020082
	s_mul_hi_i32 s7, s31, s29                                  // 000000DEF48C: 97071D1F
	s_mul_i32 s6, s31, s29                                     // 000000DEF490: 96061D1F
	s_lshl_b32 s8, s34, 7                                      // 000000DEF494: 84088722
	s_lshl_b64 s[6:7], s[6:7], 2                               // 000000DEF498: 84868206
	ds_load_b32 v2, v1 offset:4096                             // 000000DEF49C: D8D81000 02000001
	s_ashr_i32 s9, s8, 31                                      // 000000DEF4A4: 86099F08
	s_add_u32 s10, s26, s6                                     // 000000DEF4A8: 800A061A
	s_addc_u32 s14, s27, s7                                    // 000000DEF4AC: 820E071B
	s_lshl_b64 s[6:7], s[8:9], 2                               // 000000DEF4B0: 84868208
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000DEF4B4: BF870009
	s_add_u32 s6, s10, s6                                      // 000000DEF4B8: 8006060A
	s_addc_u32 s7, s14, s7                                     // 000000DEF4BC: 8207070E
	s_waitcnt lgkmcnt(0)                                       // 000000DEF4C0: BF89FC07
	global_store_b32 v1, v2, s[6:7]                            // 000000DEF4C4: DC6A0000 00060201
	s_or_b32 exec_lo, exec_lo, s5                              // 000000DEF4CC: 8C7E057E
	.long 0xd44a0005                                           // 000000DEF4D0: D44A0005
	v_cndmask_b32_e32 v1, 0, v0, vcc_lo                        // 000000DEF4D4: 02020080
	s_waitcnt_vscnt null, 0x0                                  // 000000DEF4D8: BC7C0000
	buffer_gl1_inv                                             // 000000DEF4DC: E0B00000 00000000
	buffer_gl0_inv                                             // 000000DEF4E4: E0AC0000 00000000
	s_barrier                                                  // 000000DEF4EC: BFBD0000
	buffer_gl0_inv                                             // 000000DEF4F0: E0AC0000 00000000
	s_and_saveexec_b32 s6, s5                                  // 000000DEF4F8: BE862005
	s_cbranch_execz 29                                         // 000000DEF4FC: BFA5001D <_ZN7halogen12_GLOBAL__N_113k_i4r_rows_glILi1EEEvPKhlPKDF16_PKiPfS5_S5_PDF16_PjNS0_5I4rSdEi+0x1c74>
	s_mov_b32 s8, exec_lo                                      // 000000DEF500: BE88007E
	s_mov_b32 s7, exec_lo                                      // 000000DEF504: BE87007E
	.long 0xd71f0001                                           // 000000DEF508: D71F0001
	v_cndmask_b32_e32 v0, s8, v128, vcc_lo                     // 000000DEF50C: 02010008
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DEF510: BF870001
	v_cmpx_eq_u32_e32 0, v1                                    // 000000DEF514: 7D940280
	s_cbranch_execz 9                                          // 000000DEF518: BFA50009 <_ZN7halogen12_GLOBAL__N_113k_i4r_rows_glILi1EEEvPKhlPKDF16_PKiPfS5_S5_PDF16_PjNS0_5I4rSdEi+0x1c40>
	s_lshl_b64 s[14:15], s[34:35], 2                           // 000000DEF51C: 848E8222
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 000000DEF520: BF8704B9
	s_add_u32 s14, s36, s14                                    // 000000DEF524: 800E0E24
	s_addc_u32 s15, s37, s15                                   // 000000DEF528: 820F0F25
	s_bcnt1_i32_b32 s8, s8                                     // 000000DEF52C: BE881808
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v3, s8              // 000000DEF530: CA100080 02020008
	global_atomic_add_u32 v2, v2, v3, s[14:15] glc             // 000000DEF538: DCD64000 020E0302
	s_or_b32 exec_lo, exec_lo, s7                              // 000000DEF540: 8C7E077E
	s_waitcnt vmcnt(0)                                         // 000000DEF544: BF8903F7
	v_readfirstlane_b32 s7, v2                                 // 000000DEF548: 7E0E0502
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DEF54C: BF870001
	v_dual_mov_b32 v2, 0 :: v_dual_add_nc_u32 v1, s7, v1       // 000000DEF550: CA200080 02000207
	s_add_i32 s7, s11, -1                                      // 000000DEF558: 8107C10B
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 000000DEF55C: BF870481
	v_cmp_eq_u32_e32 vcc_lo, s7, v1                            // 000000DEF560: 7C940207
	v_cndmask_b32_e64 v1, 0, 1, vcc_lo                         // 000000DEF564: D5010001 01A90280
	ds_store_b32 v2, v1 offset:10240                           // 000000DEF56C: D8342800 00000102
	s_or_b32 exec_lo, exec_lo, s6                              // 000000DEF574: 8C7E067E
	v_mov_b32_e32 v1, 0                                        // 000000DEF578: 7E020280
	s_waitcnt lgkmcnt(0)                                       // 000000DEF57C: BF89FC07
	s_barrier                                                  // 000000DEF580: BFBD0000
	buffer_gl0_inv                                             // 000000DEF584: E0AC0000 00000000
	ds_load_b32 v1, v1 offset:10240                            // 000000DEF58C: D8D82800 01000001
	s_waitcnt lgkmcnt(0)                                       // 000000DEF594: BF89FC07
	v_cmp_eq_u32_e32 vcc_lo, 0, v1                             // 000000DEF598: 7C940280
	s_cbranch_vccnz 47                                         // 000000DEF59C: BFA4002F <_ZN7halogen12_GLOBAL__N_113k_i4r_rows_glILi1EEEvPKhlPKDF16_PKiPfS5_S5_PDF16_PjNS0_5I4rSdEi+0x1d5c>
	buffer_gl1_inv                                             // 000000DEF5A0: E0B00000 00000000
	buffer_gl0_inv                                             // 000000DEF5A8: E0AC0000 00000000
	s_and_saveexec_b32 s8, s4                                  // 000000DEF5B0: BE882004
	s_cbranch_execz 29                                         // 000000DEF5B4: BFA5001D <_ZN7halogen12_GLOBAL__N_113k_i4r_rows_glILi1EEEvPKhlPKDF16_PKiPfS5_S5_PDF16_PjNS0_5I4rSdEi+0x1d2c>
	s_lshl_b32 s6, s34, 7                                      // 000000DEF5B8: 84068722
	v_dual_mov_b32 v4, 0 :: v_dual_lshlrev_b32 v3, 2, v0       // 000000DEF5BC: CA220080 04020082
	s_ashr_i32 s7, s6, 31                                      // 000000DEF5C4: 86079F06
	s_ashr_i32 s15, s29, 31                                    // 000000DEF5C8: 860F9F1D
	s_lshl_b64 s[6:7], s[6:7], 2                               // 000000DEF5CC: 84868206
	s_mov_b32 s14, s29                                         // 000000DEF5D0: BE8E001D
	s_add_u32 s4, s26, s6                                      // 000000DEF5D4: 8004061A
	s_addc_u32 s6, s27, s7                                     // 000000DEF5D8: 8206071B
	.long 0xd7000401                                           // 000000DEF5DC: D7000401
	v_cndmask_b32_e32 v1, s4, v3, vcc_lo                       // 000000DEF5E0: 02020604
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DEF5E4: BF870001
	v_add_co_ci_u32_e64 v2, null, s6, 0, s4                    // 000000DEF5E8: D5207C02 00110006
	s_lshl_b64 s[6:7], s[14:15], 2                             // 000000DEF5F0: 8486820E
	global_load_b32 v5, v[1:2], off glc                        // 000000DEF5F4: DC524000 057C0001
	.long 0xd7006a01                                           // 000000DEF5FC: D7006A01
	v_cndmask_b32_e32 v0, v1, v6, vcc_lo                       // 000000DEF600: 02000D01
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000DEF604: BF8704A1
	v_add_co_ci_u32_e64 v2, null, s7, v2, vcc_lo               // 000000DEF608: D5207C02 01AA0407
	s_add_i32 s11, s11, -1                                     // 000000DEF610: 810BC10B
	s_cmp_eq_u32 s11, 0                                        // 000000DEF614: BF06800B
	s_waitcnt vmcnt(0)                                         // 000000DEF618: BF8903F7
	v_add_f32_e32 v4, v4, v5                                   // 000000DEF61C: 06080B04
	s_cbranch_scc0 65524                                       // 000000DEF620: BFA1FFF4 <_ZN7halogen12_GLOBAL__N_113k_i4r_rows_glILi1EEEvPKhlPKDF16_PKiPfS5_S5_PDF16_PjNS0_5I4rSdEi+0x1cf4>
	ds_store_b32 v3, v4 offset:4096                            // 000000DEF624: D8341000 00000403
	s_or_b32 exec_lo, exec_lo, s8                              // 000000DEF62C: 8C7E087E
	s_and_saveexec_b32 s4, s5                                  // 000000DEF630: BE842005
	s_cbranch_execz 6                                          // 000000DEF634: BFA50006 <_ZN7halogen12_GLOBAL__N_113k_i4r_rows_glILi1EEEvPKhlPKDF16_PKiPfS5_S5_PDF16_PjNS0_5I4rSdEi+0x1d50>
	s_lshl_b64 s[6:7], s[34:35], 2                             // 000000DEF638: 84868222
	v_mov_b32_e32 v1, 0                                        // 000000DEF63C: 7E020280
	s_add_u32 s6, s36, s6                                      // 000000DEF640: 80060624
	s_addc_u32 s7, s37, s7                                     // 000000DEF644: 82070725
	global_store_b32 v1, v1, s[6:7]                            // 000000DEF648: DC6A0000 00060101
	s_or_b32 exec_lo, exec_lo, s4                              // 000000DEF650: 8C7E047E
	s_cbranch_execnz 2                                         // 000000DEF654: BFA60002 <_ZN7halogen12_GLOBAL__N_113k_i4r_rows_glILi1EEEvPKhlPKDF16_PKiPfS5_S5_PDF16_PjNS0_5I4rSdEi+0x1d60>
	s_branch 365                                               // 000000DEF658: BFA0016D <_ZN7halogen12_GLOBAL__N_113k_i4r_rows_glILi1EEEvPKhlPKDF16_PKiPfS5_S5_PDF16_PjNS0_5I4rSdEi+0x2310>
	s_branch 364                                               // 000000DEF65C: BFA0016C <_ZN7halogen12_GLOBAL__N_113k_i4r_rows_glILi1EEEvPKhlPKDF16_PKiPfS5_S5_PDF16_PjNS0_5I4rSdEi+0x2310>
	v_cmp_eq_u32_e32 vcc_lo, 0, v8                             // 000000DEF660: 7C941080
	s_cmp_gt_i32 s28, 0                                        // 000000DEF664: BF02801C
	s_waitcnt lgkmcnt(0)                                       // 000000DEF668: BF89FC07
	s_waitcnt_vscnt null, 0x0                                  // 000000DEF66C: BC7C0000
	s_cselect_b32 s4, -1, 0                                    // 000000DEF670: 980480C1
	s_barrier                                                  // 000000DEF674: BFBD0000
	s_and_b32 s4, vcc_lo, s4                                   // 000000DEF678: 8B04046A
	buffer_gl0_inv                                             // 000000DEF67C: E0AC0000 00000000
	s_and_saveexec_b32 s6, s4                                  // 000000DEF684: BE862004
	s_cbranch_execz 352                                        // 000000DEF688: BFA50160 <_ZN7halogen12_GLOBAL__N_113k_i4r_rows_glILi1EEEvPKhlPKDF16_PKiPfS5_S5_PDF16_PjNS0_5I4rSdEi+0x230c>
	v_and_b32_e32 v1, 15, v0                                   // 000000DEF68C: 3602008F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DEF690: BF870091
	v_lshlrev_b32_e32 v2, 2, v1                                // 000000DEF694: 30040282
	v_add_nc_u32_e32 v8, 0x1000, v2                            // 000000DEF698: 4A1004FF 00001000
	ds_load_2addr_b32 v[2:3], v8 offset1:16                    // 000000DEF6A0: D8DC1000 02000008
	ds_load_2addr_b32 v[4:5], v8 offset0:32 offset1:48         // 000000DEF6A8: D8DC3020 04000008
	ds_load_2addr_b32 v[6:7], v8 offset0:64 offset1:80         // 000000DEF6B0: D8DC5040 06000008
	ds_load_2addr_b32 v[8:9], v8 offset0:96 offset1:112        // 000000DEF6B8: D8DC7060 08000008
	v_and_b32_e32 v10, 1, v0                                   // 000000DEF6C0: 36140081
	v_and_b32_e32 v11, 2, v0                                   // 000000DEF6C4: 36160082
	s_waitcnt lgkmcnt(3)                                       // 000000DEF6C8: BF89FC37
	v_dual_add_f32 v13, v2, v3 :: v_dual_and_b32 v12, 4, v0    // 000000DEF6CC: C9240702 0D0C0084
	s_waitcnt lgkmcnt(2)                                       // 000000DEF6D4: BF89FC27
	v_dual_sub_f32 v2, v2, v3 :: v_dual_add_f32 v3, v4, v5     // 000000DEF6D8: C9480702 02020B04
	s_waitcnt lgkmcnt(1)                                       // 000000DEF6E0: BF89FC17
	v_dual_sub_f32 v4, v4, v5 :: v_dual_add_f32 v5, v6, v7     // 000000DEF6E4: C9480B04 04040F06
	s_waitcnt lgkmcnt(0)                                       // 000000DEF6EC: BF89FC07
	v_dual_sub_f32 v6, v6, v7 :: v_dual_add_f32 v7, v8, v9     // 000000DEF6F0: C9480F06 06061308
	v_dual_sub_f32 v8, v8, v9 :: v_dual_add_f32 v9, v13, v3    // 000000DEF6F8: C9481308 0808070D
	v_sub_f32_e32 v3, v13, v3                                  // 000000DEF700: 0806070D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000DEF704: BF870243
	v_dual_add_f32 v13, v2, v4 :: v_dual_add_f32 v14, v5, v7   // 000000DEF708: C9080902 0D0E0F05
	v_dual_sub_f32 v2, v2, v4 :: v_dual_sub_f32 v5, v5, v7     // 000000DEF710: C94A0902 02040F05
	v_cmp_eq_u32_e32 vcc_lo, 0, v10                            // 000000DEF718: 7C941480
	.long 0xd44a0004                                           // 000000DEF71C: D44A0004
	v_cndmask_b32_e32 v1, 0, v11, vcc_lo                       // 000000DEF720: 02021680
	v_dual_add_f32 v7, v9, v14 :: v_dual_add_f32 v4, v6, v8    // 000000DEF724: C9081D09 07041106
	v_sub_f32_e32 v6, v6, v8                                   // 000000DEF72C: 080C1106
	v_sub_f32_e32 v8, v9, v14                                  // 000000DEF730: 08101D09
	.long 0xd44a0005                                           // 000000DEF734: D44A0005
	v_cndmask_b32_e32 v1, 0, v12, vcc_lo                       // 000000DEF738: 02021880
	s_delay_alu instid0(VALU_DEP_3)                            // 000000DEF73C: BF870003
	v_dual_add_f32 v9, v13, v4 :: v_dual_sub_f32 v10, v2, v6   // 000000DEF740: C90A090D 090A0D02
	v_dual_sub_f32 v4, v13, v4 :: v_dual_add_f32 v13, v3, v5   // 000000DEF748: C948090D 040C0B03
	v_sub_f32_e32 v3, v3, v5                                   // 000000DEF750: 08060B03
	v_add_f32_e32 v5, v2, v6                                   // 000000DEF754: 060A0D02
	v_mov_b32_dpp v2, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DEF758: 7E0402FA FF016107
	v_cndmask_b32_e64 v6, -v7, v7, vcc_lo                      // 000000DEF760: D5010006 21AA0F07
	v_mov_b32_dpp v7, v9 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DEF768: 7E0E02FA FF016109
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 000000DEF770: D5010009 21AA1309
	v_mov_b32_dpp v15, v5 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DEF778: 7E1E02FA FF016105
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 000000DEF780: D5010005 21AA0B05
	v_mov_b32_dpp v14, v13 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DEF788: 7E1C02FA FF01610D
	v_cndmask_b32_e64 v13, -v13, v13, vcc_lo                   // 000000DEF790: D501000D 21AA1B0D
	v_mov_b32_dpp v16, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DEF798: 7E2002FA FF016108
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 000000DEF7A0: D5010008 21AA1108
	v_mov_b32_dpp v17, v4 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DEF7A8: 7E2202FA FF016104
	v_cndmask_b32_e64 v18, -v4, v4, vcc_lo                     // 000000DEF7B0: D5010012 21AA0904
	v_mov_b32_dpp v19, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DEF7B8: 7E2602FA FF016103
	v_cndmask_b32_e64 v20, -v3, v3, vcc_lo                     // 000000DEF7C0: D5010014 21AA0703
	v_dual_add_f32 v3, v9, v7 :: v_dual_add_f32 v2, v6, v2     // 000000DEF7C8: C9080F09 03020506
	v_dual_add_f32 v4, v5, v15 :: v_dual_add_f32 v7, v8, v16   // 000000DEF7D0: C9081F05 04062108
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DEF7D8: BF870192
	v_cndmask_b32_e64 v8, -v3, v3, s4                          // 000000DEF7DC: D5010008 20120703
	v_mov_b32_dpp v6, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DEF7E4: 7E0C02FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, s4                          // 000000DEF7EC: D5010002 20120502
	v_mov_b32_dpp v3, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DEF7F4: 7E0602FA FF016203
	v_mov_b32_dpp v11, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DEF7FC: 7E1602FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, s4                          // 000000DEF804: D5010004 20120904
	v_add_f32_e32 v5, v13, v14                                 // 000000DEF80C: 060A1D0D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000DEF810: BF870224
	v_dual_add_f32 v2, v2, v6 :: v_dual_add_f32 v3, v8, v3     // 000000DEF814: C9080D02 02020708
	v_mov_b32_dpp v13, v7 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DEF81C: 7E1A02FA FF016207
	v_add_f32_e32 v4, v4, v11                                  // 000000DEF824: 06081704
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DEF828: BF870004
	v_mov_b32_dpp v9, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DEF82C: 7E1202FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, s4                          // 000000DEF834: D5010005 20120B05
	v_mov_b32_dpp v6, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DEF83C: 7E0C02FA FF016402
	v_cndmask_b32_e64 v8, -v3, v3, s5                          // 000000DEF844: D5010008 20160703
	v_cndmask_b32_e64 v2, -v2, v2, s5                          // 000000DEF84C: D5010002 20160502
	v_mov_b32_dpp v11, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DEF854: 7E1602FA FF016403
	v_add_f32_e32 v5, v5, v9                                   // 000000DEF85C: 060A1305
	v_mov_b32_dpp v9, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DEF860: 7E1202FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s5                          // 000000DEF868: D5010004 20160904
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DEF870: BF870214
	v_dual_add_f32 v3, v2, v6 :: v_dual_add_f32 v6, v8, v11    // 000000DEF874: C9080D02 03061708
	v_mov_b32_dpp v8, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DEF87C: 7E1002FA FF016405
	v_cndmask_b32_e64 v11, -v5, v5, s5                         // 000000DEF884: D501000B 20160B05
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DEF88C: BF870004
	v_add_f32_e32 v4, v4, v9                                   // 000000DEF890: 06081304
	v_mov_b32_dpp v9, v10 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DEF894: 7E1202FA FF01610A
	v_cndmask_b32_e64 v10, -v10, v10, vcc_lo                   // 000000DEF89C: D501000A 21AA150A
	v_add_f32_e32 v12, v18, v17                                // 000000DEF8A4: 06182312
	v_cndmask_b32_e64 v7, -v7, v7, s4                          // 000000DEF8A8: D5010007 20120F07
	v_add_f32_e32 v14, v20, v19                                // 000000DEF8B0: 061C2714
	v_mov_b32_dpp v2, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DEF8B4: 7E0402FA FF016803
	v_add_f32_e32 v9, v10, v9                                  // 000000DEF8BC: 0612130A
	v_mov_b32_dpp v5, v6 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DEF8C0: 7E0A02FA FF016806
	v_add_f32_e32 v13, v7, v13                                 // 000000DEF8C8: 061A1B07
	v_mov_b32_dpp v15, v14 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DEF8CC: 7E1E02FA FF01620E
	v_cndmask_b32_e64 v14, -v14, v14, s4                       // 000000DEF8D4: D501000E 20121D0E
	v_mov_b32_dpp v16, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DEF8DC: 7E2002FA FF016209
	v_cndmask_b32_e64 v9, -v9, v9, s4                          // 000000DEF8E4: D5010009 20121309
	v_add_f32_e32 v7, v11, v8                                  // 000000DEF8EC: 060E110B
	v_mov_b32_dpp v10, v12 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DEF8F0: 7E1402FA FF01620C
	v_cndmask_b32_e64 v12, -v12, v12, s4                       // 000000DEF8F8: D501000C 2012190C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DEF900: BF870114
	v_dual_add_f32 v8, v14, v15 :: v_dual_add_f32 v9, v9, v16  // 000000DEF904: C9081F0E 08082109
	v_add_f32_e32 v10, v12, v10                                // 000000DEF90C: 0614150C
	v_mov_b32_dpp v11, v13 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DEF910: 7E1602FA FF01640D
	v_cndmask_b32_e64 v13, -v13, v13, s5                       // 000000DEF918: D501000D 20161B0D
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DEF920: BF870004
	v_mov_b32_dpp v15, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DEF924: 7E1E02FA FF016408
	v_mov_b32_dpp v17, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DEF92C: 7E2202FA FF016409
	v_mov_b32_dpp v12, v10 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DEF934: 7E1802FA FF01640A
	v_cndmask_b32_e64 v10, -v10, v10, s5                       // 000000DEF93C: D501000A 2016150A
	v_cndmask_b32_e64 v18, -v8, v8, s5                         // 000000DEF944: D5010012 20161108
	v_cndmask_b32_e64 v9, -v9, v9, s5                          // 000000DEF94C: D5010009 20161309
	v_add_f32_e32 v14, v13, v11                                // 000000DEF954: 061C170D
	v_mov_b32_dpp v8, v7 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DEF958: 7E1002FA FF016807
	v_add_f32_e32 v16, v10, v12                                // 000000DEF960: 0620190A
	v_add_f32_e32 v15, v18, v15                                // 000000DEF964: 061E1F12
	v_add_f32_e32 v17, v9, v17                                 // 000000DEF968: 06222309
	v_mov_b32_dpp v9, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DEF96C: 7E1202FA FF016804
	v_mov_b32_dpp v10, v14 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DEF974: 7E1402FA FF01680E
	v_mov_b32_dpp v11, v16 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DEF97C: 7E1602FA FF016810
	v_mov_b32_dpp v12, v15 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DEF984: 7E1802FA FF01680F
	v_mov_b32_dpp v13, v17 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DEF98C: 7E1A02FA FF016811
	s_and_b32 exec_lo, exec_lo, s3                             // 000000DEF994: 8B7E037E
	s_cbranch_execz 156                                        // 000000DEF998: BFA5009C <_ZN7halogen12_GLOBAL__N_113k_i4r_rows_glILi1EEEvPKhlPKDF16_PKiPfS5_S5_PDF16_PjNS0_5I4rSdEi+0x230c>
	v_lshl_or_b32 v18, s34, 7, v1                              // 000000DEF99C: D6560012 04050E22
	v_and_b32_e32 v1, 8, v0                                    // 000000DEF9A4: 36020088
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DEF9A8: BF870092
	v_ashrrev_i32_e32 v19, 31, v18                             // 000000DEF9AC: 3426249F
	.long 0xd73c0012                                           // 000000DEF9B0: D73C0012
	v_cndmask_b32_e32 v1, 1, v18, vcc_lo                       // 000000DEF9B4: 02022481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DEF9B8: BF870091
	.long 0xd7006a14                                           // 000000DEF9BC: D7006A14
	v_cndmask_b32_e32 v1, s18, v18, vcc_lo                     // 000000DEF9C0: 02022412
	v_add_co_ci_u32_e64 v21, null, s19, v19, vcc_lo            // 000000DEF9C4: D5207C15 01AA2613
	v_cmp_eq_u32_e32 vcc_lo, 0, v1                             // 000000DEF9CC: 7C940280
	s_clause 0x7                                               // 000000DEF9D0: BF850007
	global_load_d16_b16 v22, v[20:21], off offset:32           // 000000DEF9D4: DC820020 167C0014
	global_load_d16_b16 v23, v[20:21], off                     // 000000DEF9DC: DC820000 177C0014
	global_load_d16_b16 v24, v[20:21], off offset:64           // 000000DEF9E4: DC820040 187C0014
	global_load_d16_b16 v25, v[20:21], off offset:96           // 000000DEF9EC: DC820060 197C0014
	global_load_d16_b16 v26, v[20:21], off offset:128          // 000000DEF9F4: DC820080 1A7C0014
	global_load_d16_b16 v27, v[20:21], off offset:160          // 000000DEF9FC: DC8200A0 1B7C0014
	global_load_d16_b16 v28, v[20:21], off offset:192          // 000000DEFA04: DC8200C0 1C7C0014
	global_load_d16_b16 v20, v[20:21], off offset:224          // 000000DEFA0C: DC8200E0 147C0014
	.long 0x7f2a3880                                           // 000000DEFA14: 7F2A3880
	v_cndmask_b32_e64 v1, -v6, v6, vcc_lo                      // 000000DEFA18: D5010001 21AA0D06
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 000000DEFA20: D5010004 21AA0904
	v_cndmask_b32_e64 v14, -v14, v14, vcc_lo                   // 000000DEFA28: D501000E 21AA1D0E
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 000000DEFA30: D5010003 21AA0703
	s_waitcnt vmcnt(7)                                         // 000000DEFA38: BF891FF7
	.long 0x7f2c3995                                           // 000000DEFA3C: 7F2C3995
	v_add_f32_e32 v1, v1, v5                                   // 000000DEFA40: 06020B01
	v_cndmask_b32_e64 v5, -v7, v7, vcc_lo                      // 000000DEFA44: D5010005 21AA0F07
	v_cndmask_b32_e64 v7, -v16, v16, vcc_lo                    // 000000DEFA4C: D5010007 21AA2110
	v_cndmask_b32_e64 v16, -v17, v17, vcc_lo                   // 000000DEFA54: D5010010 21AA2311
	v_add_f32_e32 v4, v4, v9                                   // 000000DEFA5C: 06081304
	v_cndmask_b32_e64 v15, -v15, v15, vcc_lo                   // 000000DEFA60: D501000F 21AA1F0F
	v_dual_add_f32 v5, v5, v8 :: v_dual_add_f32 v8, v14, v10   // 000000DEFA68: C9081105 0508150E
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000DEFA70: BF8701A3
	v_dual_mul_f32 v17, 0x3db504f3, v1 :: v_dual_mul_f32 v4, 0x3db504f3, v4// 000000DEFA74: C8C602FF 110408FF 3DB504F3
	v_dual_add_f32 v3, v3, v2 :: v_dual_add_f32 v10, v16, v13  // 000000DEFA80: C9080503 030A1B10
	v_dual_add_f32 v7, v7, v11 :: v_dual_mul_f32 v8, 0x3db504f3, v8// 000000DEFA88: C9061707 070810FF 3DB504F3
	.long 0x7f0c3995                                           // 000000DEFA94: 7F0C3995
	s_delay_alu instid0(VALU_DEP_3)                            // 000000DEFA98: BF870003
	v_mul_f32_e32 v3, 0x3db504f3, v3                           // 000000DEFA9C: 100606FF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 000000DEFAA4: BF8903F7
	.long 0x7f283995                                           // 000000DEFAA8: 7F283995
	v_dual_mul_f32 v7, 0x3db504f3, v7 :: v_dual_mul_f32 v10, 0x3db504f3, v10// 000000DEFAAC: C8C60EFF 070A14FF 3DB504F3
	v_mul_f32_e32 v5, 0x3db504f3, v5                           // 000000DEFAB8: 100A0AFF 3DB504F3
	.long 0x7f2e3995                                           // 000000DEFAC0: 7F2E3995
	.long 0xd7006a01                                           // 000000DEFAC4: D7006A01
	v_cndmask_b32_e32 v1, s24, v18, vcc_lo                     // 000000DEFAC8: 02022418
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000DEFACC: BF870221
	v_add_co_ci_u32_e64 v2, null, s25, v19, vcc_lo             // 000000DEFAD0: D5207C02 01AA2619
	v_fma_mix_f32 v11, v22, v17, neg(0) op_sel_hi:[1,0,0]      // 000000DEFAD8: CC20000B 8A022316
	v_fma_mix_f32 v3, v23, v3, neg(0) op_sel_hi:[1,0,0]        // 000000DEFAE0: CC200003 8A020717
	v_fma_mix_f32 v5, v24, v5, neg(0) op_sel_hi:[1,0,0]        // 000000DEFAE8: CC200005 8A020B18
	v_fma_mix_f32 v4, v25, v4, neg(0) op_sel_hi:[1,0,0]        // 000000DEFAF0: CC200004 8A020919
	v_fma_mix_f32 v8, v26, v8, neg(0) op_sel_hi:[1,0,0]        // 000000DEFAF8: CC200008 8A02111A
	.long 0x7e2a398b                                           // 000000DEFB00: 7E2A398B
	v_add_f32_e32 v9, v15, v12                                 // 000000DEFB04: 0612190F
	v_fma_mix_f32 v7, v27, v7, neg(0) op_sel_hi:[1,0,0]        // 000000DEFB08: CC200007 8A020F1B
	v_fma_mix_f32 v10, v20, v10, neg(0) op_sel_hi:[1,0,0]      // 000000DEFB10: CC20000A 8A021514
	.long 0x7e0c3983                                           // 000000DEFB18: 7E0C3983
	v_and_b32_e32 v12, 1, v21                                  // 000000DEFB1C: 36182A81
	v_mul_f32_e32 v9, 0x3db504f3, v9                           // 000000DEFB20: 101212FF 3DB504F3
	.long 0x7e2a3984                                           // 000000DEFB28: 7E2A3984
	.long 0x7e283985                                           // 000000DEFB2C: 7E283985
	.long 0x7e2c3988                                           // 000000DEFB30: 7E2C3988
	v_and_b32_e32 v6, 1, v6                                    // 000000DEFB34: 360C0C81
	v_fma_mix_f32 v9, v28, v9, neg(0) op_sel_hi:[1,0,0]        // 000000DEFB38: CC200009 8A02131C
	v_and_b32_e32 v13, 1, v21                                  // 000000DEFB40: 361A2A81
	.long 0x7e2a3987                                           // 000000DEFB44: 7E2A3987
	v_and_b32_e32 v14, 1, v20                                  // 000000DEFB48: 361C2881
	v_and_b32_e32 v15, 1, v22                                  // 000000DEFB4C: 361E2C81
	.long 0x7e2e3989                                           // 000000DEFB50: 7E2E3989
	v_add3_u32 v3, v3, v6, 0x7fff                              // 000000DEFB54: D6550003 03FE0D03 00007FFF
	v_and_b32_e32 v16, 1, v21                                  // 000000DEFB60: 36202A81
	.long 0x7e2a398a                                           // 000000DEFB64: 7E2A398A
	v_add3_u32 v11, v11, v12, 0x7fff                           // 000000DEFB68: D655000B 03FE190B 00007FFF
	v_and_b32_e32 v17, 1, v23                                  // 000000DEFB74: 36222E81
	v_add3_u32 v5, v5, v14, 0x7fff                             // 000000DEFB78: D6550005 03FE1D05 00007FFF
	v_add3_u32 v4, v4, v13, 0x7fff                             // 000000DEFB84: D6550004 03FE1B04 00007FFF
	v_and_b32_e32 v6, 1, v21                                   // 000000DEFB90: 360C2A81
	v_add3_u32 v8, v8, v15, 0x7fff                             // 000000DEFB94: D6550008 03FE1F08 00007FFF
	v_add3_u32 v9, v9, v17, 0x7fff                             // 000000DEFBA0: D6550009 03FE2309 00007FFF
	v_add3_u32 v7, v7, v16, 0x7fff                             // 000000DEFBAC: D6550007 03FE2107 00007FFF
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DEFBB8: BF870004
	v_add3_u32 v6, v10, v6, 0x7fff                             // 000000DEFBBC: D6550006 03FE0D0A 00007FFF
	s_clause 0x7                                               // 000000DEFBC8: BF850007
	global_store_d16_hi_b16 v[1:2], v3, off                    // 000000DEFBCC: DC960000 007C0301
	global_store_d16_hi_b16 v[1:2], v11, off offset:32         // 000000DEFBD4: DC960020 007C0B01
	global_store_d16_hi_b16 v[1:2], v5, off offset:64          // 000000DEFBDC: DC960040 007C0501
	global_store_d16_hi_b16 v[1:2], v4, off offset:96          // 000000DEFBE4: DC960060 007C0401
	global_store_d16_hi_b16 v[1:2], v8, off offset:128         // 000000DEFBEC: DC960080 007C0801
	global_store_d16_hi_b16 v[1:2], v7, off offset:160         // 000000DEFBF4: DC9600A0 007C0701
	global_store_d16_hi_b16 v[1:2], v9, off offset:192         // 000000DEFBFC: DC9600C0 007C0901
	global_store_d16_hi_b16 v[1:2], v6, off offset:224         // 000000DEFC04: DC9600E0 007C0601
	s_or_b32 exec_lo, exec_lo, s6                              // 000000DEFC0C: 8C7E067E
	s_mov_b32 s4, 0                                            // 000000DEFC10: BE840080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000DEFC14: BF870009
	s_and_b32 vcc_lo, exec_lo, s4                              // 000000DEFC18: 8B6A047E
	s_cbranch_vccz 4590                                        // 000000DEFC1C: BFA311EE <_ZN7halogen12_GLOBAL__N_113k_i4r_rows_glILi1EEEvPKhlPKDF16_PKiPfS5_S5_PDF16_PjNS0_5I4rSdEi+0x6ad8>
	s_load_b512 s[16:31], s[0:1], null                         // 000000DEFC20: F4100400 F8000000
	s_mov_b32 s1, exec_lo                                      // 000000DEFC28: BE81007E
	v_cmpx_gt_u32_e32 0x140, v0                                // 000000DEFC2C: 7D9800FF 00000140
	s_cbranch_execz 54                                         // 000000DEFC34: BFA50036 <_ZN7halogen12_GLOBAL__N_113k_i4r_rows_glILi1EEEvPKhlPKDF16_PKiPfS5_S5_PDF16_PjNS0_5I4rSdEi+0x2410>
	s_mul_hi_u32 s0, s2, 0x51eb851f                            // 000000DEFC38: 9680FF02 51EB851F
	v_lshlrev_b32_e32 v4, 4, v0                                // 000000DEFC40: 30080084
	s_lshr_b32 s0, s0, 6                                       // 000000DEFC44: 85008600
	v_or_b32_e32 v3, 0xffffff00, v0                            // 000000DEFC48: 380600FF FFFFFF00
	s_mul_i32 s3, s0, 0x1400                                   // 000000DEFC50: 9603FF00 00001400
	s_mul_hi_u32 s0, s0, 0x1400                                // 000000DEFC58: 9680FF00 00001400
	s_waitcnt lgkmcnt(0)                                       // 000000DEFC60: BF89FC07
	s_add_u32 s3, s20, s3                                      // 000000DEFC64: 80030314
	s_addc_u32 s0, s21, s0                                     // 000000DEFC68: 82000015
	.long 0xd7000301                                           // 000000DEFC6C: D7000301
	v_cndmask_b32_e32 v1, s3, v4, vcc_lo                       // 000000DEFC70: 02020803
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DEFC74: BF870001
	v_add_co_ci_u32_e64 v2, null, s0, 0, s3                    // 000000DEFC78: D5207C02 000D0000
	s_mov_b32 s3, 0                                            // 000000DEFC80: BE830080
	s_nop 0                                                    // 000000DEFC84: BF800000
	s_nop 0                                                    // 000000DEFC88: BF800000
	s_nop 0                                                    // 000000DEFC8C: BF800000
	s_nop 0                                                    // 000000DEFC90: BF800000
	s_nop 0                                                    // 000000DEFC94: BF800000
	s_nop 0                                                    // 000000DEFC98: BF800000
	s_nop 0                                                    // 000000DEFC9C: BF800000
	s_nop 0                                                    // 000000DEFCA0: BF800000
	s_nop 0                                                    // 000000DEFCA4: BF800000
	s_nop 0                                                    // 000000DEFCA8: BF800000
	s_nop 0                                                    // 000000DEFCAC: BF800000
	s_nop 0                                                    // 000000DEFCB0: BF800000
	s_nop 0                                                    // 000000DEFCB4: BF800000
	s_nop 0                                                    // 000000DEFCB8: BF800000
	s_nop 0                                                    // 000000DEFCBC: BF800000
	global_load_b128 v[5:8], v[1:2], off                       // 000000DEFCC0: DC5E0000 057C0001
	v_add_nc_u32_e32 v3, 0x100, v3                             // 000000DEFCC8: 4A0606FF 00000100
	.long 0xd7006a01                                           // 000000DEFCD0: D7006A01
	v_cndmask_b32_e32 v1, 0x1000, v1, vcc_lo                   // 000000DEFCD4: 020202FF 00001000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DEFCDC: BF870191
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 000000DEFCE0: D5207C02 01AA0480
	.long 0xd4490000                                           // 000000DEFCE8: D4490000
	v_cndmask_b32_e32 v1, 63, v3, vcc_lo                       // 000000DEFCEC: 020206BF
	s_or_b32 s3, s0, s3                                        // 000000DEFCF0: 8C030300
	s_waitcnt vmcnt(0)                                         // 000000DEFCF4: BF8903F7
	ds_store_b128 v4, v[5:8] offset:5120                       // 000000DEFCF8: DB7C1400 00000504
	v_add_nc_u32_e32 v4, 0x1000, v4                            // 000000DEFD00: 4A0808FF 00001000
	s_and_not1_b32 exec_lo, exec_lo, s3                        // 000000DEFD08: 917E037E
	s_cbranch_execnz 65516                                     // 000000DEFD0C: BFA6FFEC <_ZN7halogen12_GLOBAL__N_113k_i4r_rows_glILi1EEEvPKhlPKDF16_PKiPfS5_S5_PDF16_PjNS0_5I4rSdEi+0x23c0>
	s_or_b32 exec_lo, exec_lo, s1                              // 000000DEFD10: 8C7E017E
	s_mul_hi_u32 s0, s2, 0xcccccccd                            // 000000DEFD14: 9680FF02 CCCCCCCD
	v_lshrrev_b32_e32 v2, 2, v0                                // 000000DEFD1C: 32040082
	s_lshr_b32 s9, s0, 4                                       // 000000DEFD20: 85098400
	s_waitcnt lgkmcnt(0)                                       // 000000DEFD24: BF89FC07
	s_waitcnt_vscnt null, 0x0                                  // 000000DEFD28: BC7C0000
	s_lshl_b32 s0, s9, 2                                       // 000000DEFD2C: 84008209
	s_barrier                                                  // 000000DEFD30: BFBD0000
	v_dual_mov_b32 v1, s0 :: v_dual_and_b32 v2, 56, v2         // 000000DEFD34: CA240000 010204B8
	buffer_gl0_inv                                             // 000000DEFD3C: E0AC0000 00000000
	s_mul_i32 s0, s9, 0xffffffec                               // 000000DEFD44: 9600FF09 FFFFFFEC
	v_bfe_u32 v3, v0, 2, 3                                     // 000000DEFD4C: D6100003 020D0500
	global_load_b32 v1, v1, s[22:23]                           // 000000DEFD54: DC520000 01160001
	s_add_i32 s0, s0, s2                                       // 000000DEFD5C: 81000200
	v_dual_mov_b32 v94, 0 :: v_dual_and_b32 v87, 3, v0         // 000000DEFD60: CA240080 5E560083
	s_lshl_b32 s1, s0, 6                                       // 000000DEFD68: 84018600
	v_mov_b32_e32 v92, 0                                       // 000000DEFD6C: 7EB80280
	v_or3_b32 v81, s1, v2, v3                                  // 000000DEFD70: D6580051 040E0401
	s_delay_alu instid0(VALU_DEP_3)                            // 000000DEFD78: BF870003
	v_lshlrev_b32_e32 v3, 4, v87                               // 000000DEFD7C: 3006AE84
	v_dual_mov_b32 v93, 0 :: v_dual_lshlrev_b32 v88, 6, v87    // 000000DEFD80: CA220080 5D58AE86
	ds_load_b128 v[33:36], v88 offset:5120                     // 000000DEFD88: DBFC1400 21000058
	ds_load_b128 v[45:48], v88 offset:5136                     // 000000DEFD90: DBFC1410 2D000058
	ds_load_b128 v[37:40], v88 offset:6400                     // 000000DEFD98: DBFC1900 25000058
	ds_load_b128 v[41:44], v88 offset:6656                     // 000000DEFDA0: DBFC1A00 29000058
	ds_load_b128 v[59:62], v88 offset:5376                     // 000000DEFDA8: DBFC1500 3B000058
	ds_load_b128 v[49:52], v88 offset:5392                     // 000000DEFDB0: DBFC1510 31000058
	v_ashrrev_i32_e32 v82, 31, v81                             // 000000DEFDB8: 34A4A29F
	ds_load_b128 v[63:66], v88 offset:5632                     // 000000DEFDBC: DBFC1600 3F000058
	ds_load_b128 v[53:56], v88 offset:5648                     // 000000DEFDC4: DBFC1610 35000058
	v_dual_mov_b32 v91, 0 :: v_dual_mov_b32 v90, 0             // 000000DEFDCC: CA100080 5B5A0080
	s_add_u32 s2, s16, s18                                     // 000000DEFDD4: 80021210
	s_addc_u32 s3, s17, s19                                    // 000000DEFDD8: 82031311
	s_mov_b32 s1, exec_lo                                      // 000000DEFDDC: BE81007E
	ds_load_b128 v[100:103], v88 offset:6960                   // 000000DEFDE0: DBFC1B30 64000058
	ds_load_b128 v[104:107], v88 offset:7216                   // 000000DEFDE8: DBFC1C30 68000058
	s_waitcnt vmcnt(0)                                         // 000000DEFDF0: BF8903F7
	v_mad_i64_i32 v[85:86], null, 0x500, v1, v[81:82]          // 000000DEFDF4: D6FF7C55 054602FF 00000500
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DEFE00: BF870091
	v_mad_u64_u32 v[1:2], null, 0x500, v85, s[16:17]           // 000000DEFE04: D6FE7C01 0042AAFF 00000500
	v_mad_i32_i24 v2, 0x500, v86, v2                           // 000000DEFE10: D60A0002 040AACFF 00000500
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DEFE1C: BF870092
	.long 0xd7006a53                                           // 000000DEFE20: D7006A53
	v_cndmask_b32_e32 v1, v1, v3, vcc_lo                       // 000000DEFE24: 02020701
	v_add_co_ci_u32_e64 v84, null, 0, v2, vcc_lo               // 000000DEFE28: D5207C54 01AA0480
	s_clause 0x7                                               // 000000DEFE30: BF850007
	global_load_b128 v[29:32], v[83:84], off                   // 000000DEFE34: DC5E0000 1D7C0053
	global_load_b128 v[25:28], v[83:84], off offset:64         // 000000DEFE3C: DC5E0040 197C0053
	global_load_b128 v[21:24], v[83:84], off offset:128        // 000000DEFE44: DC5E0080 157C0053
	global_load_b128 v[17:20], v[83:84], off offset:192        // 000000DEFE4C: DC5E00C0 117C0053
	global_load_b128 v[13:16], v[83:84], off offset:256        // 000000DEFE54: DC5E0100 0D7C0053
	global_load_b128 v[9:12], v[83:84], off offset:320         // 000000DEFE5C: DC5E0140 097C0053
	global_load_b128 v[5:8], v[83:84], off offset:384          // 000000DEFE64: DC5E0180 057C0053
	global_load_b128 v[1:4], v[83:84], off offset:448          // 000000DEFE6C: DC5E01C0 017C0053
	s_waitcnt vmcnt(7)                                         // 000000DEFE74: BF891FF7
	v_lshrrev_b32_e32 v57, 4, v29                              // 000000DEFE78: 32723A84
	v_and_b32_e32 v29, 0xf0f0f0f, v29                          // 000000DEFE7C: 363A3AFF 0F0F0F0F
	s_waitcnt vmcnt(6)                                         // 000000DEFE84: BF891BF7
	v_lshrrev_b32_e32 v58, 4, v25                              // 000000DEFE88: 32743284
	s_waitcnt vmcnt(5)                                         // 000000DEFE8C: BF8917F7
	v_lshrrev_b32_e32 v67, 4, v21                              // 000000DEFE90: 32862A84
	v_mov_b32_e32 v89, 0                                       // 000000DEFE94: 7EB20280
	v_and_b32_e32 v57, 0xf0f0f0f, v57                          // 000000DEFE98: 367272FF 0F0F0F0F
	v_and_b32_e32 v25, 0xf0f0f0f, v25                          // 000000DEFEA0: 363232FF 0F0F0F0F
	v_and_b32_e32 v21, 0xf0f0f0f, v21                          // 000000DEFEA8: 362A2AFF 0F0F0F0F
	v_and_b32_e32 v58, 0xf0f0f0f, v58                          // 000000DEFEB0: 367474FF 0F0F0F0F
	v_and_b32_e32 v67, 0xf0f0f0f, v67                          // 000000DEFEB8: 368686FF 0F0F0F0F
	v_perm_b32 v68, v57, v29, 0xc040c00                        // 000000DEFEC0: D6440044 03FE3B39 0C040C00
	v_perm_b32 v69, v57, v29, 0xc050c01                        // 000000DEFECC: D6440045 03FE3B39 0C050C01
	v_perm_b32 v70, v57, v29, 0xc060c02                        // 000000DEFED8: D6440046 03FE3B39 0C060C02
	v_perm_b32 v29, v57, v29, 0xc070c03                        // 000000DEFEE4: D644001D 03FE3B39 0C070C03
	v_perm_b32 v57, v58, v25, 0xc040c00                        // 000000DEFEF0: D6440039 03FE333A 0C040C00
	v_perm_b32 v71, v67, v21, 0xc040c00                        // 000000DEFEFC: D6440047 03FE2B43 0C040C00
	v_perm_b32 v72, v58, v25, 0xc050c01                        // 000000DEFF08: D6440048 03FE333A 0C050C01
	v_perm_b32 v73, v58, v25, 0xc060c02                        // 000000DEFF14: D6440049 03FE333A 0C060C02
	v_perm_b32 v25, v58, v25, 0xc070c03                        // 000000DEFF20: D6440019 03FE333A 0C070C03
	v_perm_b32 v58, v67, v21, 0xc050c01                        // 000000DEFF2C: D644003A 03FE2B43 0C050C01
	v_perm_b32 v74, v67, v21, 0xc060c02                        // 000000DEFF38: D644004A 03FE2B43 0C060C02
	v_perm_b32 v21, v67, v21, 0xc070c03                        // 000000DEFF44: D6440015 03FE2B43 0C070C03
	v_or_b32_e32 v67, 0x64006400, v68                          // 000000DEFF50: 388688FF 64006400
	v_or_b32_e32 v68, 0x64006400, v69                          // 000000DEFF58: 38888AFF 64006400
	v_or_b32_e32 v69, 0x64006400, v70                          // 000000DEFF60: 388A8CFF 64006400
	v_or_b32_e32 v57, 0x64006400, v57                          // 000000DEFF68: 387272FF 64006400
	v_or_b32_e32 v70, 0x64006400, v71                          // 000000DEFF70: 388C8EFF 64006400
	.long 0xcc0f4043                                           // 000000DEFF78: CC0F4043
	v_mul_i32_i24_e32 v1, 0xe408, v67                          // 000000DEFF7C: 120286FF 0000E408
	v_or_b32_e32 v71, 0x64006400, v72                          // 000000DEFF84: 388E90FF 64006400
	v_or_b32_e32 v58, 0x64006400, v58                          // 000000DEFF8C: 387474FF 64006400
	.long 0xcc0f4044                                           // 000000DEFF94: CC0F4044
	v_mul_i32_i24_e32 v1, 0xe408, v68                          // 000000DEFF98: 120288FF 0000E408
	.long 0xcc0f4039                                           // 000000DEFFA0: CC0F4039
	v_mul_i32_i24_e32 v1, 0xe408, v57                          // 000000DEFFA4: 120272FF 0000E408
	.long 0xcc0f4046                                           // 000000DEFFAC: CC0F4046
	v_mul_i32_i24_e32 v1, 0xe408, v70                          // 000000DEFFB0: 12028CFF 0000E408
	s_waitcnt lgkmcnt(9)                                       // 000000DEFFB8: BF89FC97
	v_dot2acc_f32_f16 v94, v67, v33                            // 000000DEFFBC: 04BC4343
	.long 0xcc0f4021                                           // 000000DEFFC0: CC0F4021
	v_mul_i32_i24_e32 v1, 0xe408, v71                          // 000000DEFFC4: 12028EFF 0000E408
	.long 0xcc0f403a                                           // 000000DEFFCC: CC0F403A
	v_mul_i32_i24_e32 v1, 0xe408, v58                          // 000000DEFFD0: 120274FF 0000E408
	s_waitcnt lgkmcnt(5)                                       // 000000DEFFD8: BF89FC57
	v_dot2acc_f32_f16 v93, v57, v59                            // 000000DEFFDC: 04BA7739
	s_waitcnt lgkmcnt(3)                                       // 000000DEFFE0: BF89FC37
	v_dot2acc_f32_f16 v92, v70, v63                            // 000000DEFFE4: 04B87F46
	v_dot2acc_f32_f16 v94, v68, v34                            // 000000DEFFE8: 04BC4544
	v_or_b32_e32 v34, 0x64006400, v74                          // 000000DEFFEC: 384494FF 64006400
	v_or_b32_e32 v72, 0x64006400, v73                          // 000000DEFFF4: 389092FF 64006400
	v_dot2acc_f32_f16 v93, v33, v60                            // 000000DEFFFC: 04BA7921
	v_dot2acc_f32_f16 v92, v58, v64                            // 000000DF0000: 04B8813A
	v_or_b32_e32 v21, 0x64006400, v21                          // 000000DF0004: 382A2AFF 64006400
	.long 0xcc0f4021                                           // 000000DF000C: CC0F4021
	v_mul_i32_i24_e32 v1, 0xe408, v34                          // 000000DF0010: 120244FF 0000E408
	.long 0xcc0f4045                                           // 000000DF0018: CC0F4045
	v_mul_i32_i24_e32 v1, 0xe408, v69                          // 000000DF001C: 12028AFF 0000E408
	.long 0xcc0f403f                                           // 000000DF0024: CC0F403F
	v_mul_i32_i24_e32 v1, 0xe408, v72                          // 000000DF0028: 120290FF 0000E408
	v_or_b32_e32 v29, 0x64006400, v29                          // 000000DF0030: 383A3AFF 64006400
	v_or_b32_e32 v25, 0x64006400, v25                          // 000000DF0038: 383232FF 64006400
	s_waitcnt vmcnt(4)                                         // 000000DF0040: BF8913F7
	v_lshrrev_b32_e32 v34, 4, v17                              // 000000DF0044: 32442284
	v_dot2acc_f32_f16 v92, v33, v65                            // 000000DF0048: 04B88321
	.long 0xcc0f4015                                           // 000000DF004C: CC0F4015
	v_mul_i32_i24_e32 v1, 0xe408, v21                          // 000000DF0050: 12022AFF 0000E408
	v_dot2acc_f32_f16 v94, v69, v35                            // 000000DF0058: 04BC4745
	.long 0xcc0f401d                                           // 000000DF005C: CC0F401D
	v_mul_i32_i24_e32 v1, 0xe408, v29                          // 000000DF0060: 12023AFF 0000E408
	.long 0xcc0f4019                                           // 000000DF0068: CC0F4019
	v_mul_i32_i24_e32 v1, 0xe408, v25                          // 000000DF006C: 120232FF 0000E408
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DF0074: BF870004
	v_dual_dot2acc_f32_f16 v92, v21, v66 :: v_dual_and_b32 v17, 0xf0f0f0f, v17// 000000DF0078: CB248515 5C1022FF 0F0F0F0F
	v_and_b32_e32 v65, 0xf0f0f0f, v34                          // 000000DF0084: 368244FF 0F0F0F0F
	s_waitcnt vmcnt(2)                                         // 000000DF008C: BF890BF7
	v_and_b32_e32 v66, 0xf0f0f0f, v9                           // 000000DF0090: 368412FF 0F0F0F0F
	v_dual_dot2acc_f32_f16 v93, v63, v61 :: v_dual_dot2acc_f32_f16 v94, v29, v36// 000000DF0098: CB187B3F 5D5E491D
	ds_load_b128 v[67:70], v88 offset:5888                     // 000000DF00A0: DBFC1700 43000058
	ds_load_b128 v[57:60], v88 offset:5904                     // 000000DF00A8: DBFC1710 39000058
	v_lshrrev_b32_e32 v29, 4, v13                              // 000000DF00B0: 323A1A84
	v_perm_b32 v21, v65, v17, 0xc050c01                        // 000000DF00B4: D6440015 03FE2341 0C050C01
	v_dot2acc_f32_f16 v93, v25, v62                            // 000000DF00C0: 04BA7D19
	v_perm_b32 v25, v65, v17, 0xc040c00                        // 000000DF00C4: D6440019 03FE2341 0C040C00
	ds_load_b128 v[33:36], v88 offset:6144                     // 000000DF00D0: DBFC1800 21000058
	ds_load_b128 v[61:64], v88 offset:6160                     // 000000DF00D8: DBFC1810 3D000058
	v_and_b32_e32 v13, 0xf0f0f0f, v13                          // 000000DF00E0: 361A1AFF 0F0F0F0F
	v_or_b32_e32 v21, 0x64006400, v21                          // 000000DF00E8: 382A2AFF 64006400
	v_and_b32_e32 v29, 0xf0f0f0f, v29                          // 000000DF00F0: 363A3AFF 0F0F0F0F
	v_or_b32_e32 v25, 0x64006400, v25                          // 000000DF00F8: 383232FF 64006400
	v_perm_b32 v71, v65, v17, 0xc060c02                        // 000000DF0100: D6440047 03FE2341 0C060C02
	v_perm_b32 v17, v65, v17, 0xc070c03                        // 000000DF010C: D6440011 03FE2341 0C070C03
	.long 0xcc0f4015                                           // 000000DF0118: CC0F4015
	v_mul_i32_i24_e32 v1, 0xe408, v21                          // 000000DF011C: 12022AFF 0000E408
	v_lshrrev_b32_e32 v9, 4, v9                                // 000000DF0124: 32121284
	.long 0xcc0f4019                                           // 000000DF0128: CC0F4019
	v_mul_i32_i24_e32 v1, 0xe408, v25                          // 000000DF012C: 120232FF 0000E408
	v_or_b32_e32 v65, 0x64006400, v71                          // 000000DF0134: 38828EFF 64006400
	v_or_b32_e32 v17, 0x64006400, v17                          // 000000DF013C: 382222FF 64006400
	v_mov_b32_e32 v95, 0                                       // 000000DF0144: 7EBE0280
	s_waitcnt lgkmcnt(3)                                       // 000000DF0148: BF89FC37
	v_dot2acc_f32_f16 v91, v25, v67                            // 000000DF014C: 04B68719
	v_perm_b32 v67, v29, v13, 0xc040c00                        // 000000DF0150: D6440043 03FE1B1D 0C040C00
	.long 0xcc0f4041                                           // 000000DF015C: CC0F4041
	v_mul_i32_i24_e32 v1, 0xe408, v65                          // 000000DF0160: 120282FF 0000E408
	.long 0xcc0f4011                                           // 000000DF0168: CC0F4011
	v_mul_i32_i24_e32 v1, 0xe408, v17                          // 000000DF016C: 120222FF 0000E408
	s_waitcnt vmcnt(1)                                         // 000000DF0174: BF8907F7
	v_lshrrev_b32_e32 v25, 4, v5                               // 000000DF0178: 32320A84
	v_dot2acc_f32_f16 v91, v21, v68                            // 000000DF017C: 04B68915
	v_perm_b32 v21, v29, v13, 0xc050c01                        // 000000DF0180: D6440015 03FE1B1D 0C050C01
	v_or_b32_e32 v67, 0x64006400, v67                          // 000000DF018C: 388686FF 64006400
	v_and_b32_e32 v5, 0xf0f0f0f, v5                            // 000000DF0194: 360A0AFF 0F0F0F0F
	v_and_b32_e32 v25, 0xf0f0f0f, v25                          // 000000DF019C: 363232FF 0F0F0F0F
	v_dot2acc_f32_f16 v91, v65, v69                            // 000000DF01A4: 04B68B41
	v_or_b32_e32 v21, 0x64006400, v21                          // 000000DF01A8: 382A2AFF 64006400
	.long 0xcc0f4047                                           // 000000DF01B0: CC0F4047
	v_mul_i32_i24_e32 v1, 0xe408, v67                          // 000000DF01B4: 120286FF 0000E408
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DF01BC: BF870193
	v_dot2acc_f32_f16 v91, v17, v70                            // 000000DF01C0: 04B68D11
	.long 0xcc0f4015                                           // 000000DF01C4: CC0F4015
	v_mul_i32_i24_e32 v1, 0xe408, v21                          // 000000DF01C8: 12022AFF 0000E408
	s_waitcnt lgkmcnt(1)                                       // 000000DF01D0: BF89FC17
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DF01D4: BF870093
	v_dot2acc_f32_f16 v90, v71, v33                            // 000000DF01D8: 04B44347
	v_dual_dot2acc_f32_f16 v90, v21, v34 :: v_dual_and_b32 v9, 0xf0f0f0f, v9// 000000DF01DC: CB244515 5A0812FF 0F0F0F0F
	v_perm_b32 v69, v29, v13, 0xc060c02                        // 000000DF01E8: D6440045 03FE1B1D 0C060C02
	v_perm_b32 v13, v29, v13, 0xc070c03                        // 000000DF01F4: D644000D 03FE1B1D 0C070C03
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DF0200: BF870193
	v_perm_b32 v29, v9, v66, 0xc040c00                         // 000000DF0204: D644001D 03FE8509 0C040C00
	v_or_b32_e32 v33, 0x64006400, v69                          // 000000DF0210: 38428AFF 64006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DF0218: BF870193
	v_or_b32_e32 v13, 0x64006400, v13                          // 000000DF021C: 381A1AFF 64006400
	v_or_b32_e32 v29, 0x64006400, v29                          // 000000DF0224: 383A3AFF 64006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DF022C: BF870112
	.long 0xcc0f400d                                           // 000000DF0230: CC0F400D
	v_mul_i32_i24_e32 v1, 0xe408, v13                          // 000000DF0234: 12021AFF 0000E408
	.long 0xcc0f401d                                           // 000000DF023C: CC0F401D
	v_mul_i32_i24_e32 v1, 0xe408, v29                          // 000000DF0240: 12023AFF 0000E408
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DF0248: BF8700A1
	v_dot2acc_f32_f16 v89, v29, v37                            // 000000DF024C: 04B24B1D
	.long 0xcc0f401d                                           // 000000DF0250: CC0F401D
	v_mul_i32_i24_e32 v1, 0xe408, v33                          // 000000DF0254: 120242FF 0000E408
	v_dot2acc_f32_f16 v90, v29, v35                            // 000000DF025C: 04B4471D
	v_perm_b32 v17, v9, v66, 0xc050c01                         // 000000DF0260: D6440011 03FE8509 0C050C01
	v_perm_b32 v70, v9, v66, 0xc060c02                         // 000000DF026C: D6440046 03FE8509 0C060C02
	v_perm_b32 v9, v9, v66, 0xc070c03                          // 000000DF0278: D6440009 03FE8509 0C070C03
	s_waitcnt vmcnt(0)                                         // 000000DF0284: BF8903F7
	v_dual_dot2acc_f32_f16 v90, v13, v36 :: v_dual_and_b32 v29, 0xf0f0f0f, v1// 000000DF0288: CB24490D 5A1C02FF 0F0F0F0F
	v_or_b32_e32 v17, 0x64006400, v17                          // 000000DF0294: 382222FF 64006400
	v_or_b32_e32 v69, 0x64006400, v70                          // 000000DF029C: 388A8CFF 64006400
	v_or_b32_e32 v21, 0x64006400, v9                           // 000000DF02A4: 382A12FF 64006400
	v_perm_b32 v13, v25, v5, 0xc050c01                         // 000000DF02AC: D644000D 03FE0B19 0C050C01
	v_mov_b32_e32 v9, 0                                        // 000000DF02B8: 7E120280
	.long 0xcc0f4011                                           // 000000DF02BC: CC0F4011
	v_mul_i32_i24_e32 v1, 0xe408, v17                          // 000000DF02C0: 120222FF 0000E408
	.long 0xcc0f4021                                           // 000000DF02C8: CC0F4021
	v_mul_i32_i24_e32 v1, 0xe408, v69                          // 000000DF02CC: 12028AFF 0000E408
	ds_load_b128 v[65:68], v88 offset:6416                     // 000000DF02D4: DBFC1910 41000058
	v_or_b32_e32 v13, 0x64006400, v13                          // 000000DF02DC: 381A1AFF 64006400
	ds_load_b128 v[69:72], v88 offset:6928                     // 000000DF02E4: DBFC1B10 45000058
	v_dot2acc_f32_f16 v89, v17, v38                            // 000000DF02EC: 04B24D11
	.long 0xcc0f4011                                           // 000000DF02F0: CC0F4011
	v_mul_i32_i24_e32 v1, 0xe408, v21                          // 000000DF02F4: 12022AFF 0000E408
	v_perm_b32 v21, v25, v5, 0xc040c00                         // 000000DF02FC: D6440015 03FE0B19 0C040C00
	.long 0xcc0f400d                                           // 000000DF0308: CC0F400D
	v_mul_i32_i24_e32 v1, 0xe408, v13                          // 000000DF030C: 12021AFF 0000E408
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DF0314: BF870004
	v_dot2acc_f32_f16 v89, v33, v39                            // 000000DF0318: 04B24F21
	ds_load_b128 v[33:36], v88 offset:6912                     // 000000DF031C: DBFC1B00 21000058
	ds_load_b128 v[73:76], v88 offset:6672                     // 000000DF0324: DBFC1A10 49000058
	v_dot2acc_f32_f16 v89, v17, v40                            // 000000DF032C: 04B25111
	v_or_b32_e32 v17, 0x64006400, v21                          // 000000DF0330: 38222AFF 64006400
	global_load_b128 v[37:40], v[83:84], off offset:512        // 000000DF0338: DC5E0200 257C0053
	v_lshrrev_b32_e32 v21, 4, v1                               // 000000DF0340: 322A0284
	v_perm_b32 v1, v25, v5, 0xc060c02                          // 000000DF0344: D6440001 03FE0B19 0C060C02
	v_perm_b32 v5, v25, v5, 0xc070c03                          // 000000DF0350: D6440005 03FE0B19 0C070C03
	.long 0xcc0f4011                                           // 000000DF035C: CC0F4011
	v_mul_i32_i24_e32 v1, 0xe408, v17                          // 000000DF0360: 120222FF 0000E408
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DF0368: BF870214
	v_and_b32_e32 v21, 0xf0f0f0f, v21                          // 000000DF036C: 362A2AFF 0F0F0F0F
	v_or_b32_e32 v1, 0x64006400, v1                            // 000000DF0374: 380202FF 64006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DF037C: BF870214
	v_or_b32_e32 v5, 0x64006400, v5                            // 000000DF0380: 380A0AFF 64006400
	v_dot2acc_f32_f16 v9, v17, v41                             // 000000DF0388: 04125311
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DF038C: BF870214
	v_perm_b32 v17, v21, v29, 0xc040c00                        // 000000DF0390: D6440011 03FE3B15 0C040C00
	.long 0xcc0f4001                                           // 000000DF039C: CC0F4001
	v_mul_i32_i24_e32 v1, 0xe408, v1                           // 000000DF03A0: 120202FF 0000E408
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DF03A8: BF870214
	.long 0xcc0f4005                                           // 000000DF03AC: CC0F4005
	v_mul_i32_i24_e32 v1, 0xe408, v5                           // 000000DF03B0: 12020AFF 0000E408
	v_dot2acc_f32_f16 v9, v13, v42                             // 000000DF03B8: 0412550D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000DF03BC: BF8701A4
	v_or_b32_e32 v13, 0x64006400, v17                          // 000000DF03C0: 381A22FF 64006400
	v_perm_b32 v17, v21, v29, 0xc060c02                        // 000000DF03C8: D6440011 03FE3B15 0C060C02
	v_dot2acc_f32_f16 v9, v1, v43                              // 000000DF03D4: 04125701
	v_mov_b32_e32 v1, 0                                        // 000000DF03D8: 7E020280
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DF03DC: BF870194
	.long 0xcc0f400d                                           // 000000DF03E0: CC0F400D
	v_mul_i32_i24_e32 v1, 0xe408, v13                          // 000000DF03E4: 12021AFF 0000E408
	v_dot2acc_f32_f16 v9, v5, v44                              // 000000DF03EC: 04125905
	v_perm_b32 v5, v21, v29, 0xc050c01                         // 000000DF03F0: D6440005 03FE3B15 0C050C01
	v_perm_b32 v21, v21, v29, 0xc070c03                        // 000000DF03FC: D6440015 03FE3B15 0C070C03
	s_waitcnt lgkmcnt(1)                                       // 000000DF0408: BF89FC17
	v_dot2acc_f32_f16 v1, v13, v33                             // 000000DF040C: 0402430D
	v_or_b32_e32 v13, 0x64006400, v17                          // 000000DF0410: 381A22FF 64006400
	ds_load_b128 v[41:44], v88 offset:7168                     // 000000DF0418: DBFC1C00 29000058
	ds_load_b128 v[77:80], v88 offset:7184                     // 000000DF0420: DBFC1C10 4D000058
	v_or_b32_e32 v5, 0x64006400, v5                            // 000000DF0428: 380A0AFF 64006400
	v_or_b32_e32 v17, 0x64006400, v21                          // 000000DF0430: 38222AFF 64006400
	.long 0xcc0f400d                                           // 000000DF0438: CC0F400D
	v_mul_i32_i24_e32 v1, 0xe408, v13                          // 000000DF043C: 12021AFF 0000E408
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DF0444: BF870093
	.long 0xcc0f4005                                           // 000000DF0448: CC0F4005
	v_mul_i32_i24_e32 v1, 0xe408, v5                           // 000000DF044C: 12020AFF 0000E408
	v_dot2acc_f32_f16 v1, v5, v34                              // 000000DF0454: 04024505
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DF0458: BF870114
	.long 0xcc0f4005                                           // 000000DF045C: CC0F4005
	v_mul_i32_i24_e32 v1, 0xe408, v17                          // 000000DF0460: 120222FF 0000E408
	v_dot2acc_f32_f16 v1, v13, v35                             // 000000DF0468: 0402470D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 000000DF046C: BF870151
	v_dot2acc_f32_f16 v1, v5, v36                              // 000000DF0470: 04024905
	global_load_b128 v[33:36], v[83:84], off offset:576        // 000000DF0474: DC5E0240 217C0053
	s_waitcnt vmcnt(1)                                         // 000000DF047C: BF8907F7
	v_lshrrev_b32_e32 v5, 4, v37                               // 000000DF0480: 320A4A84
	v_and_b32_e32 v13, 0xf0f0f0f, v37                          // 000000DF0484: 361A4AFF 0F0F0F0F
	v_and_b32_e32 v5, 0xf0f0f0f, v5                            // 000000DF048C: 360A0AFF 0F0F0F0F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000DF0494: BF870241
	v_perm_b32 v17, v5, v13, 0xc040c00                         // 000000DF0498: D6440011 03FE1B05 0C040C00
	v_perm_b32 v21, v5, v13, 0xc050c01                         // 000000DF04A4: D6440015 03FE1B05 0C050C01
	v_perm_b32 v25, v5, v13, 0xc060c02                         // 000000DF04B0: D6440019 03FE1B05 0C060C02
	v_perm_b32 v5, v5, v13, 0xc070c03                          // 000000DF04BC: D6440005 03FE1B05 0C070C03
	v_or_b32_e32 v13, 0x64006400, v17                          // 000000DF04C8: 381A22FF 64006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DF04D0: BF870112
	v_or_b32_e32 v5, 0x64006400, v5                            // 000000DF04D4: 380A0AFF 64006400
	.long 0xcc0f400d                                           // 000000DF04DC: CC0F400D
	v_mul_i32_i24_e32 v1, 0xe408, v13                          // 000000DF04E0: 12021AFF 0000E408
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000DF04E8: BF870122
	.long 0xcc0f4005                                           // 000000DF04EC: CC0F4005
	v_mul_i32_i24_e32 v1, 0xe408, v5                           // 000000DF04F0: 12020AFF 0000E408
	s_waitcnt lgkmcnt(1)                                       // 000000DF04F8: BF89FC17
	v_dot2acc_f32_f16 v95, v13, v41                            // 000000DF04FC: 04BE530D
	v_or_b32_e32 v13, 0x64006400, v21                          // 000000DF0500: 381A2AFF 64006400
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DF0508: BF870091
	.long 0xcc0f400d                                           // 000000DF050C: CC0F400D
	v_mul_i32_i24_e32 v1, 0xe408, v13                          // 000000DF0510: 12021AFF 0000E408
	v_dot2acc_f32_f16 v95, v13, v42                            // 000000DF0518: 04BE550D
	v_or_b32_e32 v13, 0x64006400, v25                          // 000000DF051C: 381A32FF 64006400
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DF0524: BF870091
	.long 0xcc0f400d                                           // 000000DF0528: CC0F400D
	v_mul_i32_i24_e32 v1, 0xe408, v13                          // 000000DF052C: 12021AFF 0000E408
	v_dot2acc_f32_f16 v95, v13, v43                            // 000000DF0534: 04BE570D
	s_waitcnt vmcnt(0)                                         // 000000DF0538: BF8903F7
	v_and_b32_e32 v13, 0xf0f0f0f, v33                          // 000000DF053C: 361A42FF 0F0F0F0F
	s_delay_alu instid0(VALU_DEP_2)                            // 000000DF0544: BF870002
	v_dot2acc_f32_f16 v95, v5, v44                             // 000000DF0548: 04BE5905
	v_lshrrev_b32_e32 v5, 4, v33                               // 000000DF054C: 320A4284
	ds_load_b128 v[96:99], v88 offset:7424                     // 000000DF0550: DBFC1D00 60000058
	ds_load_b128 v[41:44], v88 offset:7440                     // 000000DF0558: DBFC1D10 29000058
	v_mov_b32_e32 v33, 0                                       // 000000DF0560: 7E420280
	v_and_b32_e32 v5, 0xf0f0f0f, v5                            // 000000DF0564: 360A0AFF 0F0F0F0F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000DF056C: BF870241
	v_perm_b32 v17, v5, v13, 0xc040c00                         // 000000DF0570: D6440011 03FE1B05 0C040C00
	v_perm_b32 v21, v5, v13, 0xc050c01                         // 000000DF057C: D6440015 03FE1B05 0C050C01
	v_perm_b32 v25, v5, v13, 0xc060c02                         // 000000DF0588: D6440019 03FE1B05 0C060C02
	v_perm_b32 v5, v5, v13, 0xc070c03                          // 000000DF0594: D6440005 03FE1B05 0C070C03
	v_or_b32_e32 v13, 0x64006400, v17                          // 000000DF05A0: 381A22FF 64006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DF05A8: BF870112
	v_or_b32_e32 v5, 0x64006400, v5                            // 000000DF05AC: 380A0AFF 64006400
	.long 0xcc0f400d                                           // 000000DF05B4: CC0F400D
	v_mul_i32_i24_e32 v1, 0xe408, v13                          // 000000DF05B8: 12021AFF 0000E408
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000DF05C0: BF870122
	.long 0xcc0f4005                                           // 000000DF05C4: CC0F4005
	v_mul_i32_i24_e32 v1, 0xe408, v5                           // 000000DF05C8: 12020AFF 0000E408
	s_waitcnt lgkmcnt(1)                                       // 000000DF05D0: BF89FC17
	v_dot2acc_f32_f16 v33, v13, v96                            // 000000DF05D4: 0442C10D
	v_or_b32_e32 v13, 0x64006400, v21                          // 000000DF05D8: 381A2AFF 64006400
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DF05E0: BF870091
	.long 0xcc0f400d                                           // 000000DF05E4: CC0F400D
	v_mul_i32_i24_e32 v1, 0xe408, v13                          // 000000DF05E8: 12021AFF 0000E408
	v_dot2acc_f32_f16 v33, v13, v97                            // 000000DF05F0: 0442C30D
	v_or_b32_e32 v13, 0x64006400, v25                          // 000000DF05F4: 381A32FF 64006400
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DF05FC: BF870091
	.long 0xcc0f400d                                           // 000000DF0600: CC0F400D
	v_mul_i32_i24_e32 v1, 0xe408, v13                          // 000000DF0604: 12021AFF 0000E408
	v_dot2acc_f32_f16 v33, v13, v98                            // 000000DF060C: 0442C50D
	v_and_b32_e32 v13, 0xf0f0f0f, v30                          // 000000DF0610: 361A3CFF 0F0F0F0F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000DF0618: BF8700C2
	v_dot2acc_f32_f16 v33, v5, v99                             // 000000DF061C: 0442C705
	v_lshrrev_b32_e32 v5, 4, v30                               // 000000DF0620: 320A3C84
	ds_load_b128 v[96:99], v88 offset:6704                     // 000000DF0624: DBFC1A30 60000058
	v_and_b32_e32 v5, 0xf0f0f0f, v5                            // 000000DF062C: 360A0AFF 0F0F0F0F
	v_perm_b32 v17, v5, v13, 0xc040c00                         // 000000DF0634: D6440011 03FE1B05 0C040C00
	v_perm_b32 v21, v5, v13, 0xc050c01                         // 000000DF0640: D6440015 03FE1B05 0C050C01
	v_perm_b32 v25, v5, v13, 0xc060c02                         // 000000DF064C: D6440019 03FE1B05 0C060C02
	v_perm_b32 v5, v5, v13, 0xc070c03                          // 000000DF0658: D6440005 03FE1B05 0C070C03
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DF0664: BF870114
	v_or_b32_e32 v13, 0x64006400, v17                          // 000000DF0668: 381A22FF 64006400
	v_or_b32_e32 v5, 0x64006400, v5                            // 000000DF0670: 380A0AFF 64006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DF0678: BF870112
	.long 0xcc0f400d                                           // 000000DF067C: CC0F400D
	v_mul_i32_i24_e32 v1, 0xe408, v13                          // 000000DF0680: 12021AFF 0000E408
	.long 0xcc0f4005                                           // 000000DF0688: CC0F4005
	v_mul_i32_i24_e32 v1, 0xe408, v5                           // 000000DF068C: 12020AFF 0000E408
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DF0694: BF8700A2
	v_dot2acc_f32_f16 v94, v13, v45                            // 000000DF0698: 04BC5B0D
	v_or_b32_e32 v13, 0x64006400, v21                          // 000000DF069C: 381A2AFF 64006400
	.long 0xcc0f400d                                           // 000000DF06A4: CC0F400D
	v_mul_i32_i24_e32 v1, 0xe408, v13                          // 000000DF06A8: 12021AFF 0000E408
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DF06B0: BF8700A1
	v_dot2acc_f32_f16 v94, v13, v46                            // 000000DF06B4: 04BC5D0D
	v_or_b32_e32 v13, 0x64006400, v25                          // 000000DF06B8: 381A32FF 64006400
	.long 0xcc0f400d                                           // 000000DF06C0: CC0F400D
	v_mul_i32_i24_e32 v1, 0xe408, v13                          // 000000DF06C4: 12021AFF 0000E408
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DF06CC: BF870091
	v_dual_dot2acc_f32_f16 v94, v13, v47 :: v_dual_and_b32 v13, 0xf0f0f0f, v26// 000000DF06D0: CB245F0D 5E0C34FF 0F0F0F0F
	v_dot2acc_f32_f16 v94, v5, v48                             // 000000DF06DC: 04BC6105
	v_lshrrev_b32_e32 v5, 4, v26                               // 000000DF06E0: 320A3484
	ds_load_b128 v[45:48], v88 offset:5152                     // 000000DF06E4: DBFC1420 2D000058
	v_and_b32_e32 v5, 0xf0f0f0f, v5                            // 000000DF06EC: 360A0AFF 0F0F0F0F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000DF06F4: BF870241
	v_perm_b32 v17, v5, v13, 0xc040c00                         // 000000DF06F8: D6440011 03FE1B05 0C040C00
	v_perm_b32 v21, v5, v13, 0xc050c01                         // 000000DF0704: D6440015 03FE1B05 0C050C01
	v_perm_b32 v25, v5, v13, 0xc060c02                         // 000000DF0710: D6440019 03FE1B05 0C060C02
	v_perm_b32 v5, v5, v13, 0xc070c03                          // 000000DF071C: D6440005 03FE1B05 0C070C03
	v_or_b32_e32 v13, 0x64006400, v17                          // 000000DF0728: 381A22FF 64006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DF0730: BF870112
	v_or_b32_e32 v5, 0x64006400, v5                            // 000000DF0734: 380A0AFF 64006400
	.long 0xcc0f400d                                           // 000000DF073C: CC0F400D
	v_mul_i32_i24_e32 v1, 0xe408, v13                          // 000000DF0740: 12021AFF 0000E408
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DF0748: BF870112
	.long 0xcc0f4005                                           // 000000DF074C: CC0F4005
	v_mul_i32_i24_e32 v1, 0xe408, v5                           // 000000DF0750: 12020AFF 0000E408
	v_dot2acc_f32_f16 v93, v13, v49                            // 000000DF0758: 04BA630D
	v_or_b32_e32 v13, 0x64006400, v21                          // 000000DF075C: 381A2AFF 64006400
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DF0764: BF870091
	.long 0xcc0f400d                                           // 000000DF0768: CC0F400D
	v_mul_i32_i24_e32 v1, 0xe408, v13                          // 000000DF076C: 12021AFF 0000E408
	v_dot2acc_f32_f16 v93, v13, v50                            // 000000DF0774: 04BA650D
	v_or_b32_e32 v13, 0x64006400, v25                          // 000000DF0778: 381A32FF 64006400
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DF0780: BF870091
	.long 0xcc0f400d                                           // 000000DF0784: CC0F400D
	v_mul_i32_i24_e32 v1, 0xe408, v13                          // 000000DF0788: 12021AFF 0000E408
	v_dot2acc_f32_f16 v93, v13, v51                            // 000000DF0790: 04BA670D
	v_and_b32_e32 v13, 0xf0f0f0f, v22                          // 000000DF0794: 361A2CFF 0F0F0F0F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000DF079C: BF8700C2
	v_dot2acc_f32_f16 v93, v5, v52                             // 000000DF07A0: 04BA6905
	v_lshrrev_b32_e32 v5, 4, v22                               // 000000DF07A4: 320A2C84
	ds_load_b128 v[49:52], v88 offset:5664                     // 000000DF07A8: DBFC1620 31000058
	v_and_b32_e32 v5, 0xf0f0f0f, v5                            // 000000DF07B0: 360A0AFF 0F0F0F0F
	v_perm_b32 v17, v5, v13, 0xc040c00                         // 000000DF07B8: D6440011 03FE1B05 0C040C00
	v_perm_b32 v21, v5, v13, 0xc050c01                         // 000000DF07C4: D6440015 03FE1B05 0C050C01
	v_perm_b32 v22, v5, v13, 0xc060c02                         // 000000DF07D0: D6440016 03FE1B05 0C060C02
	v_perm_b32 v5, v5, v13, 0xc070c03                          // 000000DF07DC: D6440005 03FE1B05 0C070C03
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DF07E8: BF870114
	v_or_b32_e32 v13, 0x64006400, v17                          // 000000DF07EC: 381A22FF 64006400
	v_or_b32_e32 v5, 0x64006400, v5                            // 000000DF07F4: 380A0AFF 64006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DF07FC: BF870112
	.long 0xcc0f400d                                           // 000000DF0800: CC0F400D
	v_mul_i32_i24_e32 v1, 0xe408, v13                          // 000000DF0804: 12021AFF 0000E408
	.long 0xcc0f4005                                           // 000000DF080C: CC0F4005
	v_mul_i32_i24_e32 v1, 0xe408, v5                           // 000000DF0810: 12020AFF 0000E408
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DF0818: BF8700A2
	v_dot2acc_f32_f16 v92, v13, v53                            // 000000DF081C: 04B86B0D
	v_or_b32_e32 v13, 0x64006400, v21                          // 000000DF0820: 381A2AFF 64006400
	.long 0xcc0f400d                                           // 000000DF0828: CC0F400D
	v_mul_i32_i24_e32 v1, 0xe408, v13                          // 000000DF082C: 12021AFF 0000E408
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DF0834: BF8700A1
	v_dot2acc_f32_f16 v92, v13, v54                            // 000000DF0838: 04B86D0D
	v_or_b32_e32 v13, 0x64006400, v22                          // 000000DF083C: 381A2CFF 64006400
	.long 0xcc0f400d                                           // 000000DF0844: CC0F400D
	v_mul_i32_i24_e32 v1, 0xe408, v13                          // 000000DF0848: 12021AFF 0000E408
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DF0850: BF870091
	v_dual_dot2acc_f32_f16 v92, v13, v55 :: v_dual_and_b32 v13, 0xf0f0f0f, v18// 000000DF0854: CB246F0D 5C0C24FF 0F0F0F0F
	v_dot2acc_f32_f16 v92, v5, v56                             // 000000DF0860: 04B87105
	v_lshrrev_b32_e32 v5, 4, v18                               // 000000DF0864: 320A2484
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DF0868: BF870091
	v_and_b32_e32 v5, 0xf0f0f0f, v5                            // 000000DF086C: 360A0AFF 0F0F0F0F
	v_perm_b32 v17, v5, v13, 0xc040c00                         // 000000DF0874: D6440011 03FE1B05 0C040C00
	v_perm_b32 v18, v5, v13, 0xc050c01                         // 000000DF0880: D6440012 03FE1B05 0C050C01
	v_perm_b32 v21, v5, v13, 0xc060c02                         // 000000DF088C: D6440015 03FE1B05 0C060C02
	v_perm_b32 v5, v5, v13, 0xc070c03                          // 000000DF0898: D6440005 03FE1B05 0C070C03
	v_lshrrev_b32_e32 v13, 4, v14                              // 000000DF08A4: 321A1C84
	v_and_b32_e32 v14, 0xf0f0f0f, v14                          // 000000DF08A8: 361C1CFF 0F0F0F0F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DF08B0: BF870193
	v_or_b32_e32 v5, 0x64006400, v5                            // 000000DF08B4: 380A0AFF 64006400
	v_and_b32_e32 v13, 0xf0f0f0f, v13                          // 000000DF08BC: 361A1AFF 0F0F0F0F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DF08C4: BF870112
	.long 0xcc0f4005                                           // 000000DF08C8: CC0F4005
	v_mul_i32_i24_e32 v1, 0xe408, v5                           // 000000DF08CC: 12020AFF 0000E408
	v_perm_b32 v22, v13, v14, 0xc040c00                        // 000000DF08D4: D6440016 03FE1D0D 0C040C00
	v_perm_b32 v25, v13, v14, 0xc050c01                        // 000000DF08E0: D6440019 03FE1D0D 0C050C01
	v_perm_b32 v26, v13, v14, 0xc060c02                        // 000000DF08EC: D644001A 03FE1D0D 0C060C02
	v_perm_b32 v13, v13, v14, 0xc070c03                        // 000000DF08F8: D644000D 03FE1D0D 0C070C03
	v_or_b32_e32 v14, 0x64006400, v17                          // 000000DF0904: 381C22FF 64006400
	v_or_b32_e32 v17, 0x64006400, v21                          // 000000DF090C: 38222AFF 64006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DF0914: BF870193
	v_or_b32_e32 v13, 0x64006400, v13                          // 000000DF0918: 381A1AFF 64006400
	.long 0xcc0f400e                                           // 000000DF0920: CC0F400E
	v_mul_i32_i24_e32 v1, 0xe408, v14                          // 000000DF0924: 12021CFF 0000E408
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DF092C: BF870193
	.long 0xcc0f4011                                           // 000000DF0930: CC0F4011
	v_mul_i32_i24_e32 v1, 0xe408, v17                          // 000000DF0934: 120222FF 0000E408
	.long 0xcc0f400d                                           // 000000DF093C: CC0F400D
	v_mul_i32_i24_e32 v1, 0xe408, v13                          // 000000DF0940: 12021AFF 0000E408
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000DF0948: BF8700C3
	v_dot2acc_f32_f16 v91, v14, v57                            // 000000DF094C: 04B6730E
	v_or_b32_e32 v14, 0x64006400, v22                          // 000000DF0950: 381C2CFF 64006400
	ds_load_b128 v[54:57], v88 offset:5168                     // 000000DF0958: DBFC1430 36000058
	.long 0xcc0f400e                                           // 000000DF0960: CC0F400E
	v_mul_i32_i24_e32 v1, 0xe408, v14                          // 000000DF0964: 12021CFF 0000E408
	v_dot2acc_f32_f16 v90, v14, v61                            // 000000DF096C: 04B47B0E
	v_or_b32_e32 v14, 0x64006400, v18                          // 000000DF0970: 381C24FF 64006400
	v_or_b32_e32 v18, 0x64006400, v26                          // 000000DF0978: 382434FF 64006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DF0980: BF870112
	.long 0xcc0f400e                                           // 000000DF0984: CC0F400E
	v_mul_i32_i24_e32 v1, 0xe408, v14                          // 000000DF0988: 12021CFF 0000E408
	.long 0xcc0f4012                                           // 000000DF0990: CC0F4012
	v_mul_i32_i24_e32 v1, 0xe408, v18                          // 000000DF0994: 120224FF 0000E408
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000DF099C: BF870122
	v_dot2acc_f32_f16 v91, v14, v58                            // 000000DF09A0: 04B6750E
	v_or_b32_e32 v14, 0x64006400, v25                          // 000000DF09A4: 381C32FF 64006400
	v_dot2acc_f32_f16 v91, v17, v59                            // 000000DF09AC: 04B67711
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000DF09B0: BF870122
	.long 0xcc0f400e                                           // 000000DF09B4: CC0F400E
	v_mul_i32_i24_e32 v1, 0xe408, v14                          // 000000DF09B8: 12021CFF 0000E408
	v_lshrrev_b32_e32 v17, 4, v6                               // 000000DF09C0: 32220C84
	v_dual_dot2acc_f32_f16 v91, v5, v60 :: v_dual_dot2acc_f32_f16 v90, v14, v62// 000000DF09C4: CB187905 5B5A7D0E
	v_lshrrev_b32_e32 v14, 4, v10                              // 000000DF09CC: 321C1484
	v_and_b32_e32 v10, 0xf0f0f0f, v10                          // 000000DF09D0: 361414FF 0F0F0F0F
	v_and_b32_e32 v5, 0xf0f0f0f, v6                            // 000000DF09D8: 360A0CFF 0F0F0F0F
	v_and_b32_e32 v6, 0xf0f0f0f, v17                           // 000000DF09E0: 360C22FF 0F0F0F0F
	v_dot2acc_f32_f16 v90, v18, v63                            // 000000DF09E8: 04B47F12
	v_and_b32_e32 v14, 0xf0f0f0f, v14                          // 000000DF09EC: 361C1CFF 0F0F0F0F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DF09F4: BF870193
	v_perm_b32 v21, v6, v5, 0xc050c01                          // 000000DF09F8: D6440015 03FE0B06 0C050C01
	v_dot2acc_f32_f16 v90, v13, v64                            // 000000DF0A04: 04B4810D
	s_delay_alu instid0(VALU_DEP_3)                            // 000000DF0A08: BF870003
	v_perm_b32 v13, v14, v10, 0xc040c00                        // 000000DF0A0C: D644000D 03FE150E 0C040C00
	v_perm_b32 v17, v14, v10, 0xc050c01                        // 000000DF0A18: D6440011 03FE150E 0C050C01
	v_perm_b32 v18, v14, v10, 0xc060c02                        // 000000DF0A24: D6440012 03FE150E 0C060C02
	v_perm_b32 v10, v14, v10, 0xc070c03                        // 000000DF0A30: D644000A 03FE150E 0C070C03
	v_perm_b32 v14, v6, v5, 0xc040c00                          // 000000DF0A3C: D644000E 03FE0B06 0C040C00
	v_or_b32_e32 v13, 0x64006400, v13                          // 000000DF0A48: 381A1AFF 64006400
	v_perm_b32 v22, v6, v5, 0xc060c02                          // 000000DF0A50: D6440016 03FE0B06 0C060C02
	v_perm_b32 v5, v6, v5, 0xc070c03                           // 000000DF0A5C: D6440005 03FE0B06 0C070C03
	v_or_b32_e32 v17, 0x64006400, v17                          // 000000DF0A68: 382222FF 64006400
	v_or_b32_e32 v6, 0x64006400, v14                           // 000000DF0A70: 380C1CFF 64006400
	.long 0xcc0f400d                                           // 000000DF0A78: CC0F400D
	v_mul_i32_i24_e32 v1, 0xe408, v13                          // 000000DF0A7C: 12021AFF 0000E408
	v_and_b32_e32 v14, 0xf0f0f0f, v2                           // 000000DF0A84: 361C04FF 0F0F0F0F
	v_or_b32_e32 v21, 0x64006400, v21                          // 000000DF0A8C: 382A2AFF 64006400
	v_lshrrev_b32_e32 v2, 4, v2                                // 000000DF0A94: 32040484
	.long 0xcc0f4006                                           // 000000DF0A98: CC0F4006
	v_mul_i32_i24_e32 v1, 0xe408, v6                           // 000000DF0A9C: 12020CFF 0000E408
	.long 0xcc0f4011                                           // 000000DF0AA4: CC0F4011
	v_mul_i32_i24_e32 v1, 0xe408, v17                          // 000000DF0AA8: 120222FF 0000E408
	v_or_b32_e32 v10, 0x64006400, v10                          // 000000DF0AB0: 381414FF 64006400
	v_or_b32_e32 v5, 0x64006400, v5                            // 000000DF0AB8: 380A0AFF 64006400
	v_dual_dot2acc_f32_f16 v89, v13, v65 :: v_dual_and_b32 v2, 0xf0f0f0f, v2// 000000DF0AC0: CB24830D 590204FF 0F0F0F0F
	v_or_b32_e32 v13, 0x64006400, v18                          // 000000DF0ACC: 381A24FF 64006400
	.long 0xcc0f4012                                           // 000000DF0AD4: CC0F4012
	v_mul_i32_i24_e32 v1, 0xe408, v21                          // 000000DF0AD8: 12022AFF 0000E408
	v_dot2acc_f32_f16 v9, v6, v73                              // 000000DF0AE0: 04129306
	v_or_b32_e32 v21, 0x64006400, v22                          // 000000DF0AE4: 382A2CFF 64006400
	v_dot2acc_f32_f16 v89, v17, v66                            // 000000DF0AEC: 04B28511
	.long 0xcc0f400d                                           // 000000DF0AF0: CC0F400D
	v_mul_i32_i24_e32 v1, 0xe408, v13                          // 000000DF0AF4: 12021AFF 0000E408
	.long 0xcc0f400a                                           // 000000DF0AFC: CC0F400A
	v_mul_i32_i24_e32 v1, 0xe408, v10                          // 000000DF0B00: 120214FF 0000E408
	v_dot2acc_f32_f16 v9, v18, v74                             // 000000DF0B08: 04129512
	.long 0xcc0f4015                                           // 000000DF0B0C: CC0F4015
	v_mul_i32_i24_e32 v1, 0xe408, v21                          // 000000DF0B10: 12022AFF 0000E408
	v_lshrrev_b32_e32 v18, 4, v38                              // 000000DF0B18: 32244C84
	v_dot2acc_f32_f16 v89, v13, v67                            // 000000DF0B1C: 04B2870D
	v_lshrrev_b32_e32 v6, 4, v31                               // 000000DF0B20: 320C3E84
	v_and_b32_e32 v17, 0xf0f0f0f, v38                          // 000000DF0B24: 36224CFF 0F0F0F0F
	v_dot2acc_f32_f16 v9, v21, v75                             // 000000DF0B2C: 04129715
	v_perm_b32 v21, v2, v14, 0xc040c00                         // 000000DF0B30: D6440015 03FE1D02 0C040C00
	v_and_b32_e32 v18, 0xf0f0f0f, v18                          // 000000DF0B3C: 362424FF 0F0F0F0F
	.long 0xcc0f4005                                           // 000000DF0B44: CC0F4005
	v_mul_i32_i24_e32 v1, 0xe408, v5                           // 000000DF0B48: 12020AFF 0000E408
	v_dot2acc_f32_f16 v89, v10, v68                            // 000000DF0B50: 04B2890A
	v_perm_b32 v10, v2, v14, 0xc050c01                         // 000000DF0B54: D644000A 03FE1D02 0C050C01
	v_or_b32_e32 v21, 0x64006400, v21                          // 000000DF0B60: 382A2AFF 64006400
	v_and_b32_e32 v13, 0xf0f0f0f, v31                          // 000000DF0B68: 361A3EFF 0F0F0F0F
	v_and_b32_e32 v6, 0xf0f0f0f, v6                            // 000000DF0B70: 360C0CFF 0F0F0F0F
	v_perm_b32 v22, v2, v14, 0xc060c02                         // 000000DF0B78: D6440016 03FE1D02 0C060C02
	v_dot2acc_f32_f16 v9, v5, v76                              // 000000DF0B84: 04129905
	v_perm_b32 v5, v18, v17, 0xc040c00                         // 000000DF0B88: D6440005 03FE2312 0C040C00
	v_or_b32_e32 v10, 0x64006400, v10                          // 000000DF0B94: 381414FF 64006400
	.long 0xcc0f4015                                           // 000000DF0B9C: CC0F4015
	v_mul_i32_i24_e32 v1, 0xe408, v21                          // 000000DF0BA0: 12022AFF 0000E408
	v_perm_b32 v2, v2, v14, 0xc070c03                          // 000000DF0BA8: D6440002 03FE1D02 0C070C03
	v_perm_b32 v14, v6, v13, 0xc040c00                         // 000000DF0BB4: D644000E 03FE1B06 0C040C00
	v_perm_b32 v25, v6, v13, 0xc050c01                         // 000000DF0BC0: D6440019 03FE1B06 0C050C01
	v_perm_b32 v26, v18, v17, 0xc050c01                        // 000000DF0BCC: D644001A 03FE2312 0C050C01
	v_or_b32_e32 v5, 0x64006400, v5                            // 000000DF0BD8: 380A0AFF 64006400
	v_perm_b32 v29, v6, v13, 0xc060c02                         // 000000DF0BE0: D644001D 03FE1B06 0C060C02
	v_perm_b32 v6, v6, v13, 0xc070c03                          // 000000DF0BEC: D6440006 03FE1B06 0C070C03
	.long 0xcc0f400a                                           // 000000DF0BF8: CC0F400A
	v_mul_i32_i24_e32 v1, 0xe408, v10                          // 000000DF0BFC: 120214FF 0000E408
	v_dot2acc_f32_f16 v1, v21, v69                             // 000000DF0C04: 04028B15
	v_perm_b32 v13, v18, v17, 0xc060c02                        // 000000DF0C08: D644000D 03FE2312 0C060C02
	v_perm_b32 v17, v18, v17, 0xc070c03                        // 000000DF0C14: D6440011 03FE2312 0C070C03
	v_or_b32_e32 v18, 0x64006400, v22                          // 000000DF0C20: 38242CFF 64006400
	.long 0xcc0f4005                                           // 000000DF0C28: CC0F4005
	v_mul_i32_i24_e32 v1, 0xe408, v5                           // 000000DF0C2C: 12020AFF 0000E408
	v_dot2acc_f32_f16 v1, v10, v70                             // 000000DF0C34: 04028D0A
	v_or_b32_e32 v2, 0x64006400, v2                            // 000000DF0C38: 380404FF 64006400
	v_or_b32_e32 v14, 0x64006400, v14                          // 000000DF0C40: 381C1CFF 64006400
	.long 0xcc0f400a                                           // 000000DF0C48: CC0F400A
	v_mul_i32_i24_e32 v1, 0xe408, v18                          // 000000DF0C4C: 120224FF 0000E408
	v_dot2acc_f32_f16 v95, v5, v77                             // 000000DF0C54: 04BE9B05
	v_or_b32_e32 v5, 0x64006400, v26                           // 000000DF0C58: 380A34FF 64006400
	v_or_b32_e32 v18, 0x64006400, v25                          // 000000DF0C60: 382432FF 64006400
	.long 0xcc0f4002                                           // 000000DF0C68: CC0F4002
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000DF0C6C: 120204FF 0000E408
	v_dot2acc_f32_f16 v1, v10, v71                             // 000000DF0C74: 04028F0A
	.long 0xcc0f400a                                           // 000000DF0C78: CC0F400A
	v_mul_i32_i24_e32 v1, 0xe408, v14                          // 000000DF0C7C: 12021CFF 0000E408
	.long 0xcc0f4005                                           // 000000DF0C84: CC0F4005
	v_mul_i32_i24_e32 v1, 0xe408, v5                           // 000000DF0C88: 12020AFF 0000E408
	v_or_b32_e32 v13, 0x64006400, v13                          // 000000DF0C90: 381A1AFF 64006400
	.long 0xcc0f400e                                           // 000000DF0C98: CC0F400E
	v_mul_i32_i24_e32 v1, 0xe408, v18                          // 000000DF0C9C: 120224FF 0000E408
	v_dot2acc_f32_f16 v1, v2, v72                              // 000000DF0CA4: 04029102
	s_waitcnt lgkmcnt(2)                                       // 000000DF0CA8: BF89FC27
	v_dot2acc_f32_f16 v94, v10, v45                            // 000000DF0CAC: 04BC5B0A
	v_or_b32_e32 v2, 0x64006400, v29                           // 000000DF0CB0: 38043AFF 64006400
	v_dot2acc_f32_f16 v95, v5, v78                             // 000000DF0CB8: 04BE9D05
	.long 0xcc0f4005                                           // 000000DF0CBC: CC0F4005
	v_mul_i32_i24_e32 v1, 0xe408, v13                          // 000000DF0CC0: 12021AFF 0000E408
	v_or_b32_e32 v13, 0x64006400, v17                          // 000000DF0CC8: 381A22FF 64006400
	v_dot2acc_f32_f16 v94, v14, v46                            // 000000DF0CD0: 04BC5D0E
	.long 0xcc0f4002                                           // 000000DF0CD4: CC0F4002
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000DF0CD8: 120204FF 0000E408
	v_and_b32_e32 v10, 0xf0f0f0f, v27                          // 000000DF0CE0: 361436FF 0F0F0F0F
	v_dot2acc_f32_f16 v95, v5, v79                             // 000000DF0CE8: 04BE9F05
	v_lshrrev_b32_e32 v5, 4, v27                               // 000000DF0CEC: 320A3684
	.long 0xcc0f400d                                           // 000000DF0CF0: CC0F400D
	v_mul_i32_i24_e32 v1, 0xe408, v13                          // 000000DF0CF4: 12021AFF 0000E408
	v_dot2acc_f32_f16 v94, v2, v47                             // 000000DF0CFC: 04BC5F02
	v_lshrrev_b32_e32 v2, 4, v23                               // 000000DF0D00: 32042E84
	v_or_b32_e32 v6, 0x64006400, v6                            // 000000DF0D04: 380C0CFF 64006400
	v_and_b32_e32 v5, 0xf0f0f0f, v5                            // 000000DF0D0C: 360A0AFF 0F0F0F0F
	v_dot2acc_f32_f16 v95, v13, v80                            // 000000DF0D14: 04BEA10D
	v_and_b32_e32 v13, 0xf0f0f0f, v23                          // 000000DF0D18: 361A2EFF 0F0F0F0F
	v_and_b32_e32 v2, 0xf0f0f0f, v2                            // 000000DF0D20: 360404FF 0F0F0F0F
	ds_load_b128 v[58:61], v88 offset:5408                     // 000000DF0D28: DBFC1520 3A000058
	ds_load_b128 v[62:65], v88 offset:5424                     // 000000DF0D30: DBFC1530 3E000058
	.long 0xcc0f4006                                           // 000000DF0D38: CC0F4006
	v_mul_i32_i24_e32 v1, 0xe408, v6                           // 000000DF0D3C: 12020CFF 0000E408
	v_perm_b32 v14, v5, v10, 0xc040c00                         // 000000DF0D44: D644000E 03FE1505 0C040C00
	v_perm_b32 v17, v5, v10, 0xc060c02                         // 000000DF0D50: D6440011 03FE1505 0C060C02
	v_perm_b32 v18, v2, v13, 0xc040c00                         // 000000DF0D5C: D6440012 03FE1B02 0C040C00
	ds_load_b128 v[66:69], v88 offset:5680                     // 000000DF0D68: DBFC1630 42000058
	v_dot2acc_f32_f16 v94, v6, v48                             // 000000DF0D70: 04BC6106
	v_perm_b32 v6, v5, v10, 0xc050c01                          // 000000DF0D74: D6440006 03FE1505 0C050C01
	v_or_b32_e32 v14, 0x64006400, v14                          // 000000DF0D80: 381C1CFF 64006400
	v_perm_b32 v5, v5, v10, 0xc070c03                          // 000000DF0D88: D6440005 03FE1505 0C070C03
	v_perm_b32 v10, v2, v13, 0xc050c01                         // 000000DF0D94: D644000A 03FE1B02 0C050C01
	v_or_b32_e32 v18, 0x64006400, v18                          // 000000DF0DA0: 382424FF 64006400
	v_or_b32_e32 v6, 0x64006400, v6                            // 000000DF0DA8: 380C0CFF 64006400
	.long 0xcc0f400e                                           // 000000DF0DB0: CC0F400E
	v_mul_i32_i24_e32 v1, 0xe408, v14                          // 000000DF0DB4: 12021CFF 0000E408
	v_perm_b32 v21, v2, v13, 0xc060c02                         // 000000DF0DBC: D6440015 03FE1B02 0C060C02
	v_or_b32_e32 v10, 0x64006400, v10                          // 000000DF0DC8: 381414FF 64006400
	.long 0xcc0f4012                                           // 000000DF0DD0: CC0F4012
	v_mul_i32_i24_e32 v1, 0xe408, v18                          // 000000DF0DD4: 120224FF 0000E408
	.long 0xcc0f4006                                           // 000000DF0DDC: CC0F4006
	v_mul_i32_i24_e32 v1, 0xe408, v6                           // 000000DF0DE0: 12020CFF 0000E408
	v_perm_b32 v2, v2, v13, 0xc070c03                          // 000000DF0DE8: D6440002 03FE1B02 0C070C03
	s_waitcnt lgkmcnt(2)                                       // 000000DF0DF4: BF89FC27
	v_dot2acc_f32_f16 v93, v14, v58                            // 000000DF0DF8: 04BA750E
	v_or_b32_e32 v13, 0x64006400, v17                          // 000000DF0DFC: 381A22FF 64006400
	.long 0xcc0f400a                                           // 000000DF0E04: CC0F400A
	v_mul_i32_i24_e32 v1, 0xe408, v10                          // 000000DF0E08: 120214FF 0000E408
	v_dot2acc_f32_f16 v92, v18, v49                            // 000000DF0E10: 04B86312
	ds_load_b128 v[45:48], v88 offset:5920                     // 000000DF0E14: DBFC1720 2D000058
	ds_load_b128 v[70:73], v88 offset:5936                     // 000000DF0E1C: DBFC1730 46000058
	v_dot2acc_f32_f16 v93, v6, v59                             // 000000DF0E24: 04BA7706
	.long 0xcc0f4006                                           // 000000DF0E28: CC0F4006
	v_mul_i32_i24_e32 v1, 0xe408, v13                          // 000000DF0E2C: 12021AFF 0000E408
	v_or_b32_e32 v13, 0x64006400, v21                          // 000000DF0E34: 381A2AFF 64006400
	v_dot2acc_f32_f16 v92, v10, v50                            // 000000DF0E3C: 04B8650A
	v_lshrrev_b32_e32 v10, 4, v19                              // 000000DF0E40: 32142684
	v_or_b32_e32 v5, 0x64006400, v5                            // 000000DF0E44: 380A0AFF 64006400
	v_dual_dot2acc_f32_f16 v93, v6, v60 :: v_dual_and_b32 v6, 0xf0f0f0f, v19// 000000DF0E4C: CB247906 5D0626FF 0F0F0F0F
	.long 0xcc0f400d                                           // 000000DF0E58: CC0F400D
	v_mul_i32_i24_e32 v1, 0xe408, v13                          // 000000DF0E5C: 12021AFF 0000E408
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DF0E64: BF870004
	v_and_b32_e32 v10, 0xf0f0f0f, v10                          // 000000DF0E68: 361414FF 0F0F0F0F
	v_or_b32_e32 v2, 0x64006400, v2                            // 000000DF0E70: 380404FF 64006400
	.long 0xcc0f4005                                           // 000000DF0E78: CC0F4005
	v_mul_i32_i24_e32 v1, 0xe408, v5                           // 000000DF0E7C: 12020AFF 0000E408
	ds_load_b128 v[74:77], v88 offset:6192                     // 000000DF0E84: DBFC1830 4A000058
	v_dot2acc_f32_f16 v92, v13, v51                            // 000000DF0E8C: 04B8670D
	v_perm_b32 v13, v10, v6, 0xc040c00                         // 000000DF0E90: D644000D 03FE0D0A 0C040C00
	.long 0xcc0f4002                                           // 000000DF0E9C: CC0F4002
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000DF0EA0: 120204FF 0000E408
	v_dot2acc_f32_f16 v93, v5, v61                             // 000000DF0EA8: 04BA7B05
	v_perm_b32 v5, v10, v6, 0xc050c01                          // 000000DF0EAC: D6440005 03FE0D0A 0C050C01
	ds_load_b128 v[58:61], v88 offset:6176                     // 000000DF0EB8: DBFC1820 3A000058
	v_or_b32_e32 v13, 0x64006400, v13                          // 000000DF0EC0: 381A1AFF 64006400
	v_dot2acc_f32_f16 v92, v2, v52                             // 000000DF0EC8: 04B86902
	v_perm_b32 v2, v10, v6, 0xc060c02                          // 000000DF0ECC: D6440002 03FE0D0A 0C060C02
	v_or_b32_e32 v5, 0x64006400, v5                            // 000000DF0ED8: 380A0AFF 64006400
	v_perm_b32 v6, v10, v6, 0xc070c03                          // 000000DF0EE0: D6440006 03FE0D0A 0C070C03
	.long 0xcc0f400d                                           // 000000DF0EEC: CC0F400D
	v_mul_i32_i24_e32 v1, 0xe408, v13                          // 000000DF0EF0: 12021AFF 0000E408
	v_lshrrev_b32_e32 v10, 4, v15                              // 000000DF0EF8: 32141E84
	v_or_b32_e32 v2, 0x64006400, v2                            // 000000DF0EFC: 380404FF 64006400
	.long 0xcc0f4005                                           // 000000DF0F04: CC0F4005
	v_mul_i32_i24_e32 v1, 0xe408, v5                           // 000000DF0F08: 12020AFF 0000E408
	v_or_b32_e32 v6, 0x64006400, v6                            // 000000DF0F10: 380C0CFF 64006400
	s_waitcnt lgkmcnt(3)                                       // 000000DF0F18: BF89FC37
	v_dot2acc_f32_f16 v91, v13, v45                            // 000000DF0F1C: 04B65B0D
	v_and_b32_e32 v13, 0xf0f0f0f, v15                          // 000000DF0F20: 361A1EFF 0F0F0F0F
	v_and_b32_e32 v10, 0xf0f0f0f, v10                          // 000000DF0F28: 361414FF 0F0F0F0F
	.long 0xcc0f4002                                           // 000000DF0F30: CC0F4002
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000DF0F34: 120204FF 0000E408
	.long 0xcc0f4006                                           // 000000DF0F3C: CC0F4006
	v_mul_i32_i24_e32 v1, 0xe408, v6                           // 000000DF0F40: 12020CFF 0000E408
	v_dot2acc_f32_f16 v91, v5, v46                             // 000000DF0F48: 04B65D05
	v_and_b32_e32 v19, 0xf0f0f0f, v24                          // 000000DF0F4C: 362630FF 0F0F0F0F
	v_perm_b32 v5, v10, v13, 0xc040c00                         // 000000DF0F54: D6440005 03FE1B0A 0C040C00
	v_lshrrev_b32_e32 v25, 4, v24                              // 000000DF0F60: 32323084
	ds_load_b128 v[21:24], v88 offset:6944                     // 000000DF0F64: DBFC1B20 15000058
	v_dot2acc_f32_f16 v91, v2, v47                             // 000000DF0F6C: 04B65F02
	v_perm_b32 v2, v10, v13, 0xc050c01                         // 000000DF0F70: D6440002 03FE1B0A 0C050C01
	v_or_b32_e32 v5, 0x64006400, v5                            // 000000DF0F7C: 380A0AFF 64006400
	v_and_b32_e32 v17, 0xf0f0f0f, v28                          // 000000DF0F84: 362238FF 0F0F0F0F
	v_lshrrev_b32_e32 v18, 4, v28                              // 000000DF0F8C: 32243884
	v_dot2acc_f32_f16 v91, v6, v48                             // 000000DF0F90: 04B66106
	v_perm_b32 v6, v10, v13, 0xc060c02                         // 000000DF0F94: D6440006 03FE1B0A 0C060C02
	v_or_b32_e32 v2, 0x64006400, v2                            // 000000DF0FA0: 380404FF 64006400
	.long 0xcc0f4005                                           // 000000DF0FA8: CC0F4005
	v_mul_i32_i24_e32 v1, 0xe408, v5                           // 000000DF0FAC: 12020AFF 0000E408
	v_perm_b32 v10, v10, v13, 0xc070c03                        // 000000DF0FB4: D644000A 03FE1B0A 0C070C03
	ds_load_b128 v[45:48], v88 offset:6432                     // 000000DF0FC0: DBFC1920 2D000058
	v_or_b32_e32 v6, 0x64006400, v6                            // 000000DF0FC8: 380C0CFF 64006400
	.long 0xcc0f4002                                           // 000000DF0FD0: CC0F4002
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000DF0FD4: 120204FF 0000E408
	s_waitcnt lgkmcnt(2)                                       // 000000DF0FDC: BF89FC27
	v_dot2acc_f32_f16 v90, v5, v58                             // 000000DF0FE0: 04B47505
	v_or_b32_e32 v5, 0x64006400, v10                           // 000000DF0FE4: 380A14FF 64006400
	v_and_b32_e32 v10, 0xf0f0f0f, v32                          // 000000DF0FEC: 361440FF 0F0F0F0F
	.long 0xcc0f4006                                           // 000000DF0FF4: CC0F4006
	v_mul_i32_i24_e32 v1, 0xe408, v6                           // 000000DF0FF8: 12020CFF 0000E408
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DF1000: BF870214
	v_dual_dot2acc_f32_f16 v90, v2, v59 :: v_dual_and_b32 v27, 0xf0f0f0f, v16// 000000DF1004: CB247702 5A1A20FF 0F0F0F0F
	.long 0xcc0f4002                                           // 000000DF1010: CC0F4002
	v_mul_i32_i24_e32 v1, 0xe408, v5                           // 000000DF1014: 12020AFF 0000E408
	v_lshrrev_b32_e32 v5, 4, v11                               // 000000DF101C: 320A1684
	v_lshrrev_b32_e32 v28, 4, v16                              // 000000DF1020: 32382084
	v_mad_u64_u32 v[37:38], null, v85, 40, s[2:3]              // 000000DF1024: D6FE7C25 00095155
	v_dot2acc_f32_f16 v90, v6, v60                             // 000000DF102C: 04B47906
	v_and_b32_e32 v26, 0xf0f0f0f, v20                          // 000000DF1030: 363428FF 0F0F0F0F
	v_and_b32_e32 v5, 0xf0f0f0f, v5                            // 000000DF1038: 360A0AFF 0F0F0F0F
	v_lshrrev_b32_e32 v20, 4, v20                              // 000000DF1040: 32282884
	global_load_b128 v[49:52], v[83:84], off offset:704        // 000000DF1044: DC5E02C0 317C0053
	v_dot2acc_f32_f16 v90, v2, v61                             // 000000DF104C: 04B47B02
	v_and_b32_e32 v2, 0xf0f0f0f, v11                           // 000000DF1050: 360416FF 0F0F0F0F
	ds_load_b128 v[58:61], v88 offset:6448                     // 000000DF1058: DBFC1930 3A000058
	v_lshrrev_b32_e32 v11, 4, v32                              // 000000DF1060: 32164084
	ds_load_b128 v[29:32], v88 offset:6688                     // 000000DF1064: DBFC1A20 1D000058
	v_mad_i32_i24 v38, v86, 40, v38                            // 000000DF106C: D60A0026 04995156
	v_perm_b32 v6, v5, v2, 0xc040c00                           // 000000DF1074: D6440006 03FE0505 0C040C00
	v_perm_b32 v13, v5, v2, 0xc050c01                          // 000000DF1080: D644000D 03FE0505 0C050C01
	v_perm_b32 v14, v5, v2, 0xc060c02                          // 000000DF108C: D644000E 03FE0505 0C060C02
	v_perm_b32 v2, v5, v2, 0xc070c03                           // 000000DF1098: D6440002 03FE0505 0C070C03
	global_load_b128 v[108:111], v[37:38], off                 // 000000DF10A4: DC5E0000 6C7C0025
	v_or_b32_e32 v6, 0x64006400, v6                            // 000000DF10AC: 380C0CFF 64006400
	v_or_b32_e32 v5, 0x64006400, v13                           // 000000DF10B4: 380A1AFF 64006400
	v_or_b32_e32 v2, 0x64006400, v2                            // 000000DF10BC: 380404FF 64006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DF10C4: BF870193
	.long 0xcc0f4006                                           // 000000DF10C8: CC0F4006
	v_mul_i32_i24_e32 v1, 0xe408, v6                           // 000000DF10CC: 12020CFF 0000E408
	.long 0xcc0f4005                                           // 000000DF10D4: CC0F4005
	v_mul_i32_i24_e32 v1, 0xe408, v5                           // 000000DF10D8: 12020AFF 0000E408
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000DF10E0: BF8701A3
	.long 0xcc0f4002                                           // 000000DF10E4: CC0F4002
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000DF10E8: 120204FF 0000E408
	s_waitcnt lgkmcnt(2)                                       // 000000DF10F0: BF89FC27
	v_dot2acc_f32_f16 v89, v6, v45                             // 000000DF10F4: 04B25B06
	v_or_b32_e32 v6, 0x64006400, v14                           // 000000DF10F8: 380C1CFF 64006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DF1100: BF870112
	v_dot2acc_f32_f16 v89, v5, v46                             // 000000DF1104: 04B25D05
	.long 0xcc0f4006                                           // 000000DF1108: CC0F4006
	v_mul_i32_i24_e32 v1, 0xe408, v6                           // 000000DF110C: 12020CFF 0000E408
	v_lshrrev_b32_e32 v5, 4, v7                                // 000000DF1114: 320A0E84
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DF1118: BF870112
	v_dot2acc_f32_f16 v89, v6, v47                             // 000000DF111C: 04B25F06
	v_and_b32_e32 v5, 0xf0f0f0f, v5                            // 000000DF1120: 360A0AFF 0F0F0F0F
	s_delay_alu instid0(VALU_DEP_2)                            // 000000DF1128: BF870002
	v_dual_dot2acc_f32_f16 v89, v2, v48 :: v_dual_and_b32 v2, 0xf0f0f0f, v7// 000000DF112C: CB246102 59020EFF 0F0F0F0F
	global_load_b128 v[45:48], v[83:84], off offset:768        // 000000DF1138: DC5E0300 2D7C0053
	v_perm_b32 v6, v5, v2, 0xc040c00                           // 000000DF1140: D6440006 03FE0505 0C040C00
	v_perm_b32 v7, v5, v2, 0xc050c01                           // 000000DF114C: D6440007 03FE0505 0C050C01
	v_perm_b32 v13, v5, v2, 0xc060c02                          // 000000DF1158: D644000D 03FE0505 0C060C02
	v_perm_b32 v2, v5, v2, 0xc070c03                           // 000000DF1164: D6440002 03FE0505 0C070C03
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DF1170: BF870214
	v_or_b32_e32 v6, 0x64006400, v6                            // 000000DF1174: 380C0CFF 64006400
	v_or_b32_e32 v5, 0x64006400, v7                            // 000000DF117C: 380A0EFF 64006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DF1184: BF870193
	v_or_b32_e32 v2, 0x64006400, v2                            // 000000DF1188: 380404FF 64006400
	.long 0xcc0f4006                                           // 000000DF1190: CC0F4006
	v_mul_i32_i24_e32 v1, 0xe408, v6                           // 000000DF1194: 12020CFF 0000E408
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DF119C: BF870193
	.long 0xcc0f4005                                           // 000000DF11A0: CC0F4005
	v_mul_i32_i24_e32 v1, 0xe408, v5                           // 000000DF11A4: 12020AFF 0000E408
	.long 0xcc0f4002                                           // 000000DF11AC: CC0F4002
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000DF11B0: 120204FF 0000E408
	s_waitcnt lgkmcnt(0)                                       // 000000DF11B8: BF89FC07
	s_delay_alu instid0(VALU_DEP_3)                            // 000000DF11BC: BF870003
	v_dot2acc_f32_f16 v9, v6, v29                              // 000000DF11C0: 04123B06
	v_or_b32_e32 v6, 0x64006400, v13                           // 000000DF11C4: 380C1AFF 64006400
	ds_load_b128 v[13:16], v88 offset:7200                     // 000000DF11CC: DBFC1C20 0D000058
	v_dot2acc_f32_f16 v9, v5, v30                              // 000000DF11D4: 04123D05
	.long 0xcc0f4006                                           // 000000DF11D8: CC0F4006
	v_mul_i32_i24_e32 v1, 0xe408, v6                           // 000000DF11DC: 12020CFF 0000E408
	v_lshrrev_b32_e32 v5, 4, v3                                // 000000DF11E4: 320A0684
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DF11E8: BF870092
	v_dot2acc_f32_f16 v9, v6, v31                              // 000000DF11EC: 04123F06
	v_dual_dot2acc_f32_f16 v9, v2, v32 :: v_dual_and_b32 v2, 0xf0f0f0f, v3// 000000DF11F0: CB244102 090206FF 0F0F0F0F
	s_delay_alu instid0(VALU_DEP_3)                            // 000000DF11FC: BF870003
	v_and_b32_e32 v3, 0xf0f0f0f, v5                            // 000000DF1200: 36060AFF 0F0F0F0F
	global_load_b128 v[29:32], v[83:84], off offset:832        // 000000DF1208: DC5E0340 1D7C0053
	v_perm_b32 v5, v3, v2, 0xc040c00                           // 000000DF1210: D6440005 03FE0503 0C040C00
	v_perm_b32 v6, v3, v2, 0xc050c01                           // 000000DF121C: D6440006 03FE0503 0C050C01
	v_perm_b32 v7, v3, v2, 0xc060c02                           // 000000DF1228: D6440007 03FE0503 0C060C02
	v_perm_b32 v2, v3, v2, 0xc070c03                           // 000000DF1234: D6440002 03FE0503 0C070C03
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DF1240: BF870214
	v_or_b32_e32 v5, 0x64006400, v5                            // 000000DF1244: 380A0AFF 64006400
	v_or_b32_e32 v3, 0x64006400, v6                            // 000000DF124C: 38060CFF 64006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DF1254: BF870193
	v_or_b32_e32 v2, 0x64006400, v2                            // 000000DF1258: 380404FF 64006400
	.long 0xcc0f4005                                           // 000000DF1260: CC0F4005
	v_mul_i32_i24_e32 v1, 0xe408, v5                           // 000000DF1264: 12020AFF 0000E408
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DF126C: BF870193
	.long 0xcc0f4003                                           // 000000DF1270: CC0F4003
	v_mul_i32_i24_e32 v1, 0xe408, v3                           // 000000DF1274: 120206FF 0000E408
	.long 0xcc0f4002                                           // 000000DF127C: CC0F4002
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000DF1280: 120204FF 0000E408
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000DF1288: BF870243
	v_dot2acc_f32_f16 v1, v5, v21                              // 000000DF128C: 04022B05
	v_or_b32_e32 v5, 0x64006400, v7                            // 000000DF1290: 380A0EFF 64006400
	v_and_b32_e32 v21, 0xf0f0f0f, v12                          // 000000DF1298: 362A18FF 0F0F0F0F
	v_lshrrev_b32_e32 v12, 4, v12                              // 000000DF12A0: 32181884
	v_dot2acc_f32_f16 v1, v3, v22                              // 000000DF12A4: 04022D03
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000DF12A8: BF870124
	.long 0xcc0f4005                                           // 000000DF12AC: CC0F4005
	v_mul_i32_i24_e32 v1, 0xe408, v5                           // 000000DF12B0: 12020AFF 0000E408
	v_lshrrev_b32_e32 v3, 4, v39                               // 000000DF12B8: 32064E84
	v_dual_dot2acc_f32_f16 v1, v5, v23 :: v_dual_and_b32 v12, 0xf0f0f0f, v12// 000000DF12BC: CB242F05 010C18FF 0F0F0F0F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DF12C8: BF870112
	v_and_b32_e32 v3, 0xf0f0f0f, v3                            // 000000DF12CC: 360606FF 0F0F0F0F
	v_dual_dot2acc_f32_f16 v1, v2, v24 :: v_dual_and_b32 v2, 0xf0f0f0f, v39// 000000DF12D4: CB243102 01024EFF 0F0F0F0F
	v_and_b32_e32 v39, 0xf0f0f0f, v4                           // 000000DF12E0: 364E08FF 0F0F0F0F
	v_lshrrev_b32_e32 v4, 4, v4                                // 000000DF12E8: 32080884
	s_delay_alu instid0(VALU_DEP_3)                            // 000000DF12EC: BF870003
	v_perm_b32 v5, v3, v2, 0xc040c00                           // 000000DF12F0: D6440005 03FE0503 0C040C00
	v_perm_b32 v6, v3, v2, 0xc050c01                           // 000000DF12FC: D6440006 03FE0503 0C050C01
	v_perm_b32 v7, v3, v2, 0xc060c02                           // 000000DF1308: D6440007 03FE0503 0C060C02
	v_perm_b32 v2, v3, v2, 0xc070c03                           // 000000DF1314: D6440002 03FE0503 0C070C03
	v_and_b32_e32 v4, 0xf0f0f0f, v4                            // 000000DF1320: 360808FF 0F0F0F0F
	v_or_b32_e32 v5, 0x64006400, v5                            // 000000DF1328: 380A0AFF 64006400
	v_or_b32_e32 v3, 0x64006400, v6                            // 000000DF1330: 38060CFF 64006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DF1338: BF870194
	v_or_b32_e32 v2, 0x64006400, v2                            // 000000DF133C: 380404FF 64006400
	.long 0xcc0f4005                                           // 000000DF1344: CC0F4005
	v_mul_i32_i24_e32 v1, 0xe408, v5                           // 000000DF1348: 12020AFF 0000E408
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DF1350: BF870193
	.long 0xcc0f4003                                           // 000000DF1354: CC0F4003
	v_mul_i32_i24_e32 v1, 0xe408, v3                           // 000000DF1358: 120206FF 0000E408
	.long 0xcc0f4002                                           // 000000DF1360: CC0F4002
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000DF1364: 120204FF 0000E408
	s_waitcnt lgkmcnt(0)                                       // 000000DF136C: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DF1370: BF870093
	v_dot2acc_f32_f16 v95, v5, v13                             // 000000DF1374: 04BE1B05
	v_dot2acc_f32_f16 v95, v3, v14                             // 000000DF1378: 04BE1D03
	v_or_b32_e32 v3, 0x64006400, v7                            // 000000DF137C: 38060EFF 64006400
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DF1384: BF870091
	.long 0xcc0f4003                                           // 000000DF1388: CC0F4003
	v_mul_i32_i24_e32 v1, 0xe408, v3                           // 000000DF138C: 120206FF 0000E408
	v_dot2acc_f32_f16 v95, v3, v15                             // 000000DF1394: 04BE1F03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000DF1398: BF870121
	v_dual_dot2acc_f32_f16 v95, v2, v16 :: v_dual_and_b32 v2, 0xf0f0f0f, v11// 000000DF139C: CB242102 5F0216FF 0F0F0F0F
	v_lshrrev_b32_e32 v11, 4, v8                               // 000000DF13A8: 32161084
	v_perm_b32 v3, v2, v10, 0xc040c00                          // 000000DF13AC: D6440003 03FE1502 0C040C00
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DF13B8: BF870112
	v_and_b32_e32 v11, 0xf0f0f0f, v11                          // 000000DF13BC: 361616FF 0F0F0F0F
	v_or_b32_e32 v3, 0x64006400, v3                            // 000000DF13C4: 380606FF 64006400
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DF13CC: BF870091
	.long 0xcc0f4003                                           // 000000DF13D0: CC0F4003
	v_mul_i32_i24_e32 v1, 0xe408, v3                           // 000000DF13D4: 120206FF 0000E408
	v_dot2acc_f32_f16 v94, v3, v54                             // 000000DF13DC: 04BC6D03
	v_perm_b32 v3, v2, v10, 0xc050c01                          // 000000DF13E0: D6440003 03FE1502 0C050C01
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DF13EC: BF870091
	v_or_b32_e32 v3, 0x64006400, v3                            // 000000DF13F0: 380606FF 64006400
	.long 0xcc0f4003                                           // 000000DF13F8: CC0F4003
	v_mul_i32_i24_e32 v1, 0xe408, v3                           // 000000DF13FC: 120206FF 0000E408
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DF1404: BF870001
	v_dot2acc_f32_f16 v94, v3, v55                             // 000000DF1408: 04BC6F03
	v_perm_b32 v3, v2, v10, 0xc060c02                          // 000000DF140C: D6440003 03FE1502 0C060C02
	v_perm_b32 v2, v2, v10, 0xc070c03                          // 000000DF1418: D6440002 03FE1502 0C070C03
	v_and_b32_e32 v10, 0xf0f0f0f, v8                           // 000000DF1424: 361410FF 0F0F0F0F
	global_load_b128 v[5:8], v[37:38], off offset:16           // 000000DF142C: DC5E0010 057C0025
	v_or_b32_e32 v3, 0x64006400, v3                            // 000000DF1434: 380606FF 64006400
	v_or_b32_e32 v2, 0x64006400, v2                            // 000000DF143C: 380404FF 64006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DF1444: BF870112
	.long 0xcc0f4003                                           // 000000DF1448: CC0F4003
	v_mul_i32_i24_e32 v1, 0xe408, v3                           // 000000DF144C: 120206FF 0000E408
	.long 0xcc0f4002                                           // 000000DF1454: CC0F4002
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000DF1458: 120204FF 0000E408
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_3)// 000000DF1460: BF8701D2
	v_dot2acc_f32_f16 v94, v3, v56                             // 000000DF1464: 04BC7103
	global_load_b128 v[53:56], v[83:84], off offset:640        // 000000DF1468: DC5E0280 357C0053
	v_and_b32_e32 v3, 0xf0f0f0f, v25                           // 000000DF1470: 360632FF 0F0F0F0F
	v_dot2acc_f32_f16 v94, v2, v57                             // 000000DF1478: 04BC7302
	v_and_b32_e32 v2, 0xf0f0f0f, v18                           // 000000DF147C: 360424FF 0F0F0F0F
	v_perm_b32 v14, v3, v19, 0xc040c00                         // 000000DF1484: D644000E 03FE2703 0C040C00
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DF1490: BF870112
	v_perm_b32 v13, v2, v17, 0xc040c00                         // 000000DF1494: D644000D 03FE2302 0C040C00
	v_or_b32_e32 v14, 0x64006400, v14                          // 000000DF14A0: 381C1CFF 64006400
	v_perm_b32 v15, v2, v17, 0xc050c01                         // 000000DF14A8: D644000F 03FE2302 0C050C01
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DF14B4: BF870193
	v_or_b32_e32 v13, 0x64006400, v13                          // 000000DF14B8: 381A1AFF 64006400
	.long 0xcc0f400e                                           // 000000DF14C0: CC0F400E
	v_mul_i32_i24_e32 v1, 0xe408, v14                          // 000000DF14C4: 12021CFF 0000E408
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DF14CC: BF870193
	v_or_b32_e32 v15, 0x64006400, v15                          // 000000DF14D0: 381E1EFF 64006400
	.long 0xcc0f400d                                           // 000000DF14D8: CC0F400D
	v_mul_i32_i24_e32 v1, 0xe408, v13                          // 000000DF14DC: 12021AFF 0000E408
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000DF14E4: BF870223
	v_dot2acc_f32_f16 v92, v14, v66                            // 000000DF14E8: 04B8850E
	v_perm_b32 v14, v3, v19, 0xc050c01                         // 000000DF14EC: D644000E 03FE2703 0C050C01
	.long 0xcc0f400f                                           // 000000DF14F8: CC0F400F
	v_mul_i32_i24_e32 v1, 0xe408, v15                          // 000000DF14FC: 12021EFF 0000E408
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000DF1504: BF870244
	v_dot2acc_f32_f16 v93, v13, v62                            // 000000DF1508: 04BA7D0D
	v_perm_b32 v13, v2, v17, 0xc060c02                         // 000000DF150C: D644000D 03FE2302 0C060C02
	v_perm_b32 v2, v2, v17, 0xc070c03                          // 000000DF1518: D6440002 03FE2302 0C070C03
	v_or_b32_e32 v14, 0x64006400, v14                          // 000000DF1524: 381C1CFF 64006400
	v_dual_dot2acc_f32_f16 v93, v15, v63 :: v_dual_and_b32 v62, 0xf0f0f0f, v40// 000000DF152C: CB247F0F 5D3E50FF 0F0F0F0F
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DF1538: BF870004
	v_or_b32_e32 v13, 0x64006400, v13                          // 000000DF153C: 381A1AFF 64006400
	v_perm_b32 v15, v3, v19, 0xc060c02                         // 000000DF1544: D644000F 03FE2703 0C060C02
	v_or_b32_e32 v2, 0x64006400, v2                            // 000000DF1550: 380404FF 64006400
	.long 0xcc0f400e                                           // 000000DF1558: CC0F400E
	v_mul_i32_i24_e32 v1, 0xe408, v14                          // 000000DF155C: 12021CFF 0000E408
	v_perm_b32 v3, v3, v19, 0xc070c03                          // 000000DF1564: D6440003 03FE2703 0C070C03
	.long 0xcc0f400d                                           // 000000DF1570: CC0F400D
	v_mul_i32_i24_e32 v1, 0xe408, v13                          // 000000DF1574: 12021AFF 0000E408
	v_lshrrev_b32_e32 v40, 4, v40                              // 000000DF157C: 32505084
	.long 0xcc0f4002                                           // 000000DF1580: CC0F4002
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000DF1584: 120204FF 0000E408
	v_dot2acc_f32_f16 v92, v14, v67                            // 000000DF158C: 04B8870E
	v_or_b32_e32 v3, 0x64006400, v3                            // 000000DF1590: 380606FF 64006400
	v_dot2acc_f32_f16 v93, v13, v64                            // 000000DF1598: 04BA810D
	v_or_b32_e32 v13, 0x64006400, v15                          // 000000DF159C: 381A1EFF 64006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DF15A4: BF870193
	.long 0xcc0f4003                                           // 000000DF15A8: CC0F4003
	v_mul_i32_i24_e32 v1, 0xe408, v3                           // 000000DF15AC: 120206FF 0000E408
	v_dot2acc_f32_f16 v93, v2, v65                             // 000000DF15B4: 04BA8302
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000DF15B8: BF870123
	.long 0xcc0f400d                                           // 000000DF15BC: CC0F400D
	v_mul_i32_i24_e32 v1, 0xe408, v13                          // 000000DF15C0: 12021AFF 0000E408
	v_and_b32_e32 v2, 0xf0f0f0f, v20                           // 000000DF15C8: 360428FF 0F0F0F0F
	v_dot2acc_f32_f16 v92, v13, v68                            // 000000DF15D0: 04B8890D
	v_and_b32_e32 v13, 0xf0f0f0f, v28                          // 000000DF15D4: 361A38FF 0F0F0F0F
	s_delay_alu instid0(VALU_DEP_3)                            // 000000DF15DC: BF870003
	v_perm_b32 v14, v2, v26, 0xc040c00                         // 000000DF15E0: D644000E 03FE3502 0C040C00
	v_perm_b32 v15, v2, v26, 0xc050c01                         // 000000DF15EC: D644000F 03FE3502 0C050C01
	v_perm_b32 v16, v2, v26, 0xc060c02                         // 000000DF15F8: D6440010 03FE3502 0C060C02
	v_dot2acc_f32_f16 v92, v3, v69                             // 000000DF1604: 04B88B03
	v_perm_b32 v3, v13, v27, 0xc040c00                         // 000000DF1608: D6440003 03FE370D 0C040C00
	v_or_b32_e32 v14, 0x64006400, v14                          // 000000DF1614: 381C1CFF 64006400
	v_or_b32_e32 v15, 0x64006400, v15                          // 000000DF161C: 381E1EFF 64006400
	v_perm_b32 v2, v2, v26, 0xc070c03                          // 000000DF1624: D6440002 03FE3502 0C070C03
	v_or_b32_e32 v16, 0x64006400, v16                          // 000000DF1630: 382020FF 64006400
	v_or_b32_e32 v3, 0x64006400, v3                            // 000000DF1638: 380606FF 64006400
	.long 0xcc0f400e                                           // 000000DF1640: CC0F400E
	v_mul_i32_i24_e32 v1, 0xe408, v14                          // 000000DF1644: 12021CFF 0000E408
	.long 0xcc0f400f                                           // 000000DF164C: CC0F400F
	v_mul_i32_i24_e32 v1, 0xe408, v15                          // 000000DF1650: 12021EFF 0000E408
	v_or_b32_e32 v2, 0x64006400, v2                            // 000000DF1658: 380404FF 64006400
	v_perm_b32 v17, v13, v27, 0xc050c01                        // 000000DF1660: D6440011 03FE370D 0C050C01
	.long 0xcc0f4003                                           // 000000DF166C: CC0F4003
	v_mul_i32_i24_e32 v1, 0xe408, v3                           // 000000DF1670: 120206FF 0000E408
	v_dot2acc_f32_f16 v91, v14, v70                            // 000000DF1678: 04B68D0E
	.long 0xcc0f400e                                           // 000000DF167C: CC0F400E
	v_mul_i32_i24_e32 v1, 0xe408, v16                          // 000000DF1680: 120220FF 0000E408
	.long 0xcc0f4002                                           // 000000DF1688: CC0F4002
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000DF168C: 120204FF 0000E408
	v_perm_b32 v18, v13, v27, 0xc060c02                        // 000000DF1694: D6440012 03FE370D 0C060C02
	v_dot2acc_f32_f16 v90, v3, v74                             // 000000DF16A0: 04B49503
	v_perm_b32 v3, v12, v21, 0xc040c00                         // 000000DF16A4: D6440003 03FE2B0C 0C040C00
	v_dot2acc_f32_f16 v91, v15, v71                            // 000000DF16B0: 04B68F0F
	v_perm_b32 v15, v12, v21, 0xc050c01                        // 000000DF16B4: D644000F 03FE2B0C 0C050C01
	v_perm_b32 v13, v13, v27, 0xc070c03                        // 000000DF16C0: D644000D 03FE370D 0C070C03
	v_or_b32_e32 v16, 0x64006400, v17                          // 000000DF16CC: 382022FF 64006400
	v_or_b32_e32 v3, 0x64006400, v3                            // 000000DF16D4: 380606FF 64006400
	v_dot2acc_f32_f16 v91, v14, v72                            // 000000DF16DC: 04B6910E
	v_perm_b32 v14, v12, v21, 0xc060c02                        // 000000DF16E0: D644000E 03FE2B0C 0C060C02
	v_perm_b32 v12, v12, v21, 0xc070c03                        // 000000DF16EC: D644000C 03FE2B0C 0C070C03
	v_or_b32_e32 v17, 0x64006400, v18                          // 000000DF16F8: 382224FF 64006400
	.long 0xcc0f4003                                           // 000000DF1700: CC0F4003
	v_mul_i32_i24_e32 v1, 0xe408, v3                           // 000000DF1704: 120206FF 0000E408
	v_dot2acc_f32_f16 v91, v2, v73                             // 000000DF170C: 04B69302
	v_or_b32_e32 v2, 0x64006400, v15                           // 000000DF1710: 38041EFF 64006400
	.long 0xcc0f4010                                           // 000000DF1718: CC0F4010
	v_mul_i32_i24_e32 v1, 0xe408, v16                          // 000000DF171C: 120220FF 0000E408
	v_or_b32_e32 v12, 0x64006400, v12                          // 000000DF1724: 381818FF 64006400
	v_dot2acc_f32_f16 v89, v3, v58                             // 000000DF172C: 04B27503
	v_or_b32_e32 v3, 0x64006400, v13                           // 000000DF1730: 38061AFF 64006400
	v_or_b32_e32 v13, 0x64006400, v14                          // 000000DF1738: 381A1CFF 64006400
	.long 0xcc0f4002                                           // 000000DF1740: CC0F4002
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000DF1744: 120204FF 0000E408
	.long 0xcc0f4011                                           // 000000DF174C: CC0F4011
	v_mul_i32_i24_e32 v1, 0xe408, v17                          // 000000DF1750: 120222FF 0000E408
	v_dot2acc_f32_f16 v90, v16, v75                            // 000000DF1758: 04B49710
	.long 0xcc0f400c                                           // 000000DF175C: CC0F400C
	v_mul_i32_i24_e32 v1, 0xe408, v12                          // 000000DF1760: 120218FF 0000E408
	.long 0xcc0f4039                                           // 000000DF1768: CC0F4039
	v_mul_i32_i24_e32 v1, 0xe408, v13                          // 000000DF176C: 12021AFF 0000E408
	v_dot2acc_f32_f16 v89, v2, v59                             // 000000DF1774: 04B27702
	.long 0xcc0f4003                                           // 000000DF1778: CC0F4003
	v_mul_i32_i24_e32 v1, 0xe408, v3                           // 000000DF177C: 120206FF 0000E408
	v_dot2acc_f32_f16 v90, v17, v76                            // 000000DF1784: 04B49911
	s_clause 0x1                                               // 000000DF1788: BF850001
	global_load_b128 v[17:20], v[83:84], off offset:1024       // 000000DF178C: DC5E0400 117C0053
	global_load_b128 v[13:16], v[83:84], off offset:1088       // 000000DF1794: DC5E0440 0D7C0053
	v_lshrrev_b32_e32 v2, 4, v34                               // 000000DF179C: 32044484
	v_dot2acc_f32_f16 v89, v57, v60                            // 000000DF17A0: 04B27939
	v_perm_b32 v57, v11, v10, 0xc060c02                        // 000000DF17A4: D6440039 03FE150B 0C060C02
	v_dual_dot2acc_f32_f16 v90, v3, v77 :: v_dual_and_b32 v3, 0xf0f0f0f, v34// 000000DF17B0: CB249B03 5A0244FF 0F0F0F0F
	s_delay_alu instid0(VALU_DEP_3)                            // 000000DF17BC: BF870003
	v_dual_dot2acc_f32_f16 v89, v12, v61 :: v_dual_and_b32 v34, 0xf0f0f0f, v40// 000000DF17C0: CB247B0C 592250FF 0F0F0F0F
	v_perm_b32 v12, v11, v10, 0xc040c00                        // 000000DF17CC: D644000C 03FE150B 0C040C00
	v_perm_b32 v40, v11, v10, 0xc050c01                        // 000000DF17D8: D6440028 03FE150B 0C050C01
	v_perm_b32 v10, v11, v10, 0xc070c03                        // 000000DF17E4: D644000A 03FE150B 0C070C03
	v_perm_b32 v11, v4, v39, 0xc040c00                         // 000000DF17F0: D644000B 03FE4F04 0C040C00
	v_perm_b32 v58, v4, v39, 0xc050c01                         // 000000DF17FC: D644003A 03FE4F04 0C050C01
	v_or_b32_e32 v12, 0x64006400, v12                          // 000000DF1808: 381818FF 64006400
	v_or_b32_e32 v40, 0x64006400, v40                          // 000000DF1810: 385050FF 64006400
	v_perm_b32 v59, v4, v39, 0xc060c02                         // 000000DF1818: D644003B 03FE4F04 0C060C02
	v_or_b32_e32 v11, 0x64006400, v11                          // 000000DF1824: 381616FF 64006400
	v_or_b32_e32 v57, 0x64006400, v57                          // 000000DF182C: 387272FF 64006400
	.long 0xcc0f400c                                           // 000000DF1834: CC0F400C
	v_mul_i32_i24_e32 v1, 0xe408, v12                          // 000000DF1838: 120218FF 0000E408
	.long 0xcc0f4028                                           // 000000DF1840: CC0F4028
	v_mul_i32_i24_e32 v1, 0xe408, v40                          // 000000DF1844: 120250FF 0000E408
	v_or_b32_e32 v58, 0x64006400, v58                          // 000000DF184C: 387474FF 64006400
	.long 0xcc0f400b                                           // 000000DF1854: CC0F400B
	v_mul_i32_i24_e32 v1, 0xe408, v11                          // 000000DF1858: 120216FF 0000E408
	s_waitcnt vmcnt(6)                                         // 000000DF1860: BF891BF7
	v_fma_mix_f32 v60, v108, v94, 0 op_sel_hi:[1,0,0]          // 000000DF1864: CC20003C 0A02BD6C
	v_dual_dot2acc_f32_f16 v9, v12, v96 :: v_dual_and_b32 v2, 0xf0f0f0f, v2// 000000DF186C: CB24C10C 090204FF 0F0F0F0F
	v_perm_b32 v4, v4, v39, 0xc070c03                          // 000000DF1878: D6440004 03FE4F04 0C070C03
	v_dot2acc_f32_f16 v1, v11, v100                            // 000000DF1884: 0402C90B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DF1888: BF870214
	v_fma_mix_f32 v60, v108, v93, v60 op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000DF188C: CC20083C 0CF2BB6C
	v_dot2acc_f32_f16 v9, v40, v97                             // 000000DF1894: 0412C328
	v_or_b32_e32 v10, 0x64006400, v10                          // 000000DF1898: 381414FF 64006400
	v_or_b32_e32 v59, 0x64006400, v59                          // 000000DF18A0: 387676FF 64006400
	.long 0xcc0f4039                                           // 000000DF18A8: CC0F4039
	v_mul_i32_i24_e32 v1, 0xe408, v57                          // 000000DF18AC: 120272FF 0000E408
	v_fma_mix_f32 v60, v109, v92, v60 op_sel_hi:[1,0,0]        // 000000DF18B4: CC20003C 0CF2B96D
	.long 0xcc0f403a                                           // 000000DF18BC: CC0F403A
	v_mul_i32_i24_e32 v1, 0xe408, v58                          // 000000DF18C0: 120274FF 0000E408
	v_perm_b32 v39, v34, v62, 0xc040c00                        // 000000DF18C8: D6440027 03FE7D22 0C040C00
	v_perm_b32 v11, v2, v3, 0xc040c00                          // 000000DF18D4: D644000B 03FE0702 0C040C00
	v_or_b32_e32 v4, 0x64006400, v4                            // 000000DF18E0: 380808FF 64006400
	v_fma_mix_f32 v60, v109, v91, v60 op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000DF18E8: CC20083C 0CF2B76D
	.long 0xcc0f400a                                           // 000000DF18F0: CC0F400A
	v_mul_i32_i24_e32 v1, 0xe408, v10                          // 000000DF18F4: 120214FF 0000E408
	.long 0xcc0f403b                                           // 000000DF18FC: CC0F403B
	v_mul_i32_i24_e32 v1, 0xe408, v59                          // 000000DF1900: 120276FF 0000E408
	v_dot2acc_f32_f16 v1, v58, v101                            // 000000DF1908: 0402CB3A
	v_dot2acc_f32_f16 v9, v57, v98                             // 000000DF190C: 0412C539
	v_fma_mix_f32 v57, v110, v90, v60 op_sel_hi:[1,0,0]        // 000000DF1910: CC200039 0CF2B56E
	v_perm_b32 v12, v34, v62, 0xc050c01                        // 000000DF1918: D644000C 03FE7D22 0C050C01
	v_perm_b32 v40, v2, v3, 0xc050c01                          // 000000DF1924: D6440028 03FE0702 0C050C01
	v_or_b32_e32 v39, 0x64006400, v39                          // 000000DF1930: 384E4EFF 64006400
	v_or_b32_e32 v11, 0x64006400, v11                          // 000000DF1938: 381616FF 64006400
	.long 0xcc0f4004                                           // 000000DF1940: CC0F4004
	v_mul_i32_i24_e32 v1, 0xe408, v4                           // 000000DF1944: 120208FF 0000E408
	v_dot2acc_f32_f16 v1, v59, v102                            // 000000DF194C: 0402CD3B
	v_dot2acc_f32_f16 v9, v10, v99                             // 000000DF1950: 0412C70A
	v_fma_mix_f32 v10, v110, v89, v57 op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000DF1954: CC20080A 0CE6B36E
	v_perm_b32 v63, v2, v3, 0xc060c02                          // 000000DF195C: D644003F 03FE0702 0C060C02
	v_or_b32_e32 v12, 0x64006400, v12                          // 000000DF1968: 381818FF 64006400
	v_or_b32_e32 v40, 0x64006400, v40                          // 000000DF1970: 385050FF 64006400
	.long 0xcc0f4027                                           // 000000DF1978: CC0F4027
	v_mul_i32_i24_e32 v1, 0xe408, v39                          // 000000DF197C: 12024EFF 0000E408
	.long 0xcc0f400b                                           // 000000DF1984: CC0F400B
	v_mul_i32_i24_e32 v1, 0xe408, v11                          // 000000DF1988: 120216FF 0000E408
	v_dot2acc_f32_f16 v1, v4, v103                             // 000000DF1990: 0402CF04
	v_fma_mix_f32 v4, v111, v9, v10 op_sel_hi:[1,0,0]          // 000000DF1994: CC200004 0C2A136F
	v_lshrrev_b32_e32 v9, 4, v35                               // 000000DF199C: 32124684
	.long 0xcc0f400c                                           // 000000DF19A0: CC0F400C
	v_mul_i32_i24_e32 v1, 0xe408, v12                          // 000000DF19A4: 120218FF 0000E408
	v_dot2acc_f32_f16 v95, v39, v104                           // 000000DF19AC: 04BED127
	v_dot2acc_f32_f16 v33, v11, v41                            // 000000DF19B0: 0442530B
	.long 0xcc0f400a                                           // 000000DF19B4: CC0F400A
	v_mul_i32_i24_e32 v1, 0xe408, v40                          // 000000DF19B8: 120250FF 0000E408
	v_or_b32_e32 v11, 0x64006400, v63                          // 000000DF19C0: 38167EFF 64006400
	v_perm_b32 v2, v2, v3, 0xc070c03                           // 000000DF19C8: D6440002 03FE0702 0C070C03
	v_and_b32_e32 v3, 0xf0f0f0f, v35                           // 000000DF19D4: 360646FF 0F0F0F0F
	v_and_b32_e32 v9, 0xf0f0f0f, v9                            // 000000DF19DC: 361212FF 0F0F0F0F
	ds_load_b128 v[57:60], v88 offset:7456                     // 000000DF19E4: DBFC1D20 39000058
	s_clause 0x1                                               // 000000DF19EC: BF850001
	global_load_b128 v[25:28], v[83:84], off offset:896        // 000000DF19F0: DC5E0380 197C0053
	global_load_b128 v[21:24], v[83:84], off offset:960        // 000000DF19F8: DC5E03C0 157C0053
	v_perm_b32 v61, v34, v62, 0xc060c02                        // 000000DF1A00: D644003D 03FE7D22 0C060C02
	v_dot2acc_f32_f16 v95, v12, v105                           // 000000DF1A0C: 04BED30C
	v_perm_b32 v12, v34, v62, 0xc070c03                        // 000000DF1A10: D644000C 03FE7D22 0C070C03
	v_dot2acc_f32_f16 v33, v10, v42                            // 000000DF1A1C: 0442550A
	.long 0xcc0f400a                                           // 000000DF1A20: CC0F400A
	v_mul_i32_i24_e32 v1, 0xe408, v11                          // 000000DF1A24: 120216FF 0000E408
	v_or_b32_e32 v2, 0x64006400, v2                            // 000000DF1A2C: 380404FF 64006400
	v_perm_b32 v11, v9, v3, 0xc040c00                          // 000000DF1A34: D644000B 03FE0709 0C040C00
	v_or_b32_e32 v61, 0x64006400, v61                          // 000000DF1A40: 387A7AFF 64006400
	v_or_b32_e32 v12, 0x64006400, v12                          // 000000DF1A48: 381818FF 64006400
	v_dot2acc_f32_f16 v33, v10, v43                            // 000000DF1A50: 0442570A
	.long 0xcc0f4002                                           // 000000DF1A54: CC0F4002
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000DF1A58: 120204FF 0000E408
	v_or_b32_e32 v10, 0x64006400, v11                          // 000000DF1A60: 381416FF 64006400
	.long 0xcc0f4027                                           // 000000DF1A68: CC0F4027
	v_mul_i32_i24_e32 v1, 0xe408, v61                          // 000000DF1A6C: 12027AFF 0000E408
	.long 0xcc0f400b                                           // 000000DF1A74: CC0F400B
	v_mul_i32_i24_e32 v1, 0xe408, v12                          // 000000DF1A78: 120218FF 0000E408
	v_perm_b32 v12, v9, v3, 0xc050c01                          // 000000DF1A80: D644000C 03FE0709 0C050C01
	v_fma_mix_f32 v34, v111, v1, v4 op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000DF1A8C: CC200822 0C12036F
	v_dot2acc_f32_f16 v33, v2, v44                             // 000000DF1A94: 04425902
	.long 0xcc0f4001                                           // 000000DF1A98: CC0F4001
	v_mul_i32_i24_e32 v1, 0xe408, v10                          // 000000DF1A9C: 120214FF 0000E408
	v_dot2acc_f32_f16 v95, v39, v106                           // 000000DF1AA4: 04BED527
	v_or_b32_e32 v2, 0x64006400, v12                           // 000000DF1AA8: 380418FF 64006400
	v_perm_b32 v4, v9, v3, 0xc060c02                           // 000000DF1AB0: D6440004 03FE0709 0C060C02
	ds_load_b128 v[39:42], v88 offset:7472                     // 000000DF1ABC: DBFC1D30 27000058
	s_waitcnt lgkmcnt(1)                                       // 000000DF1AC4: BF89FC17
	v_dot2acc_f32_f16 v33, v1, v57                             // 000000DF1AC8: 04427301
	ds_load_b128 v[61:64], v88 offset:7680                     // 000000DF1ACC: DBFC1E00 3D000058
	ds_load_b128 v[65:68], v88 offset:7696                     // 000000DF1AD4: DBFC1E10 41000058
	.long 0xcc0f4002                                           // 000000DF1ADC: CC0F4002
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000DF1AE0: 120204FF 0000E408
	v_or_b32_e32 v4, 0x64006400, v4                            // 000000DF1AE8: 380808FF 64006400
	v_mov_b32_e32 v69, 0                                       // 000000DF1AF0: 7E8A0280
	v_perm_b32 v3, v9, v3, 0xc070c03                           // 000000DF1AF4: D6440003 03FE0709 0C070C03
	v_dot2acc_f32_f16 v95, v11, v107                           // 000000DF1B00: 04BED70B
	v_dot2acc_f32_f16 v33, v2, v58                             // 000000DF1B04: 04427502
	.long 0xcc0f402c                                           // 000000DF1B08: CC0F402C
	v_mul_i32_i24_e32 v1, 0xe408, v4                           // 000000DF1B0C: 120208FF 0000E408
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DF1B14: BF870001
	v_dot2acc_f32_f16 v33, v44, v59                            // 000000DF1B18: 0442772C
	s_waitcnt vmcnt(5)                                         // 000000DF1B1C: BF8917F7
	v_fma_mix_f32 v34, v5, v95, v34 op_sel_hi:[1,0,0]          // 000000DF1B20: CC200022 0C8ABF05
	s_waitcnt vmcnt(4)                                         // 000000DF1B28: BF8913F7
	v_lshrrev_b32_e32 v1, 4, v53                               // 000000DF1B2C: 32026A84
	v_and_b32_e32 v35, 0xf0f0f0f, v53                          // 000000DF1B30: 36466AFF 0F0F0F0F
	v_or_b32_e32 v53, 0x64006400, v3                           // 000000DF1B38: 386A06FF 64006400
	s_delay_alu instid0(VALU_DEP_3)                            // 000000DF1B40: BF870003
	v_and_b32_e32 v43, 0xf0f0f0f, v1                           // 000000DF1B44: 365602FF 0F0F0F0F
	s_clause 0x1                                               // 000000DF1B4C: BF850001
	global_load_b128 v[9:12], v[83:84], off offset:1152        // 000000DF1B50: DC5E0480 097C0053
	global_load_b128 v[1:4], v[83:84], off offset:1216         // 000000DF1B58: DC5E04C0 017C0053
	.long 0xcc0f4035                                           // 000000DF1B60: CC0F4035
	v_mul_i32_i24_e32 v1, 0xe408, v53                          // 000000DF1B64: 12026AFF 0000E408
	v_perm_b32 v57, v43, v35, 0xc040c00                        // 000000DF1B6C: D6440039 03FE472B 0C040C00
	v_perm_b32 v58, v43, v35, 0xc050c01                        // 000000DF1B78: D644003A 03FE472B 0C050C01
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DF1B84: BF870193
	v_dot2acc_f32_f16 v33, v53, v60                            // 000000DF1B88: 04427935
	v_or_b32_e32 v44, 0x64006400, v57                          // 000000DF1B8C: 385872FF 64006400
	v_lshrrev_b32_e32 v57, 4, v36                              // 000000DF1B94: 32724884
	v_and_b32_e32 v36, 0xf0f0f0f, v36                          // 000000DF1B98: 364848FF 0F0F0F0F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DF1BA0: BF870193
	.long 0xcc0f402c                                           // 000000DF1BA4: CC0F402C
	v_mul_i32_i24_e32 v1, 0xe408, v44                          // 000000DF1BA8: 120258FF 0000E408
	v_and_b32_e32 v70, 0xf0f0f0f, v57                          // 000000DF1BB0: 368C72FF 0F0F0F0F
	v_or_b32_e32 v57, 0x64006400, v58                          // 000000DF1BB8: 387274FF 64006400
	v_perm_b32 v58, v43, v35, 0xc060c02                        // 000000DF1BC0: D644003A 03FE472B 0C060C02
	v_perm_b32 v35, v43, v35, 0xc070c03                        // 000000DF1BCC: D6440023 03FE472B 0C070C03
	s_waitcnt lgkmcnt(1)                                       // 000000DF1BD8: BF89FC17
	v_dot2acc_f32_f16 v69, v44, v61                            // 000000DF1BDC: 048A7B2C
	v_lshrrev_b32_e32 v44, 4, v54                              // 000000DF1BE0: 32586C84
	.long 0xcc0f4039                                           // 000000DF1BE4: CC0F4039
	v_mul_i32_i24_e32 v1, 0xe408, v57                          // 000000DF1BE8: 120272FF 0000E408
	v_or_b32_e32 v58, 0x64006400, v58                          // 000000DF1BF0: 387474FF 64006400
	v_and_b32_e32 v43, 0xf0f0f0f, v54                          // 000000DF1BF8: 36566CFF 0F0F0F0F
	v_perm_b32 v54, v70, v36, 0xc040c00                        // 000000DF1C00: D6440036 03FE4946 0C040C00
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DF1C0C: BF870214
	v_dual_dot2acc_f32_f16 v69, v57, v62 :: v_dual_and_b32 v44, 0xf0f0f0f, v44// 000000DF1C10: CB247D39 452C58FF 0F0F0F0F
	.long 0xcc0f4039                                           // 000000DF1C1C: CC0F4039
	v_mul_i32_i24_e32 v1, 0xe408, v58                          // 000000DF1C20: 120274FF 0000E408
	v_or_b32_e32 v35, 0x64006400, v35                          // 000000DF1C28: 384646FF 64006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DF1C30: BF870214
	v_or_b32_e32 v54, 0x64006400, v54                          // 000000DF1C34: 386C6CFF 64006400
	v_perm_b32 v58, v44, v43, 0xc040c00                        // 000000DF1C3C: D644003A 03FE572C 0C040C00
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DF1C48: BF870214
	v_dot2acc_f32_f16 v69, v57, v63                            // 000000DF1C4C: 048A7F39
	.long 0xcc0f4023                                           // 000000DF1C50: CC0F4023
	v_mul_i32_i24_e32 v1, 0xe408, v35                          // 000000DF1C54: 120246FF 0000E408
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DF1C5C: BF870214
	.long 0xcc0f4036                                           // 000000DF1C60: CC0F4036
	v_mul_i32_i24_e32 v1, 0xe408, v54                          // 000000DF1C64: 12026CFF 0000E408
	v_or_b32_e32 v53, 0x64006400, v58                          // 000000DF1C6C: 386A74FF 64006400
	v_perm_b32 v57, v44, v43, 0xc050c01                        // 000000DF1C74: D6440039 03FE572C 0C050C01
	v_perm_b32 v58, v70, v36, 0xc050c01                        // 000000DF1C80: D644003A 03FE4946 0C050C01
	v_dot2acc_f32_f16 v69, v35, v64                            // 000000DF1C8C: 048A8123
	v_dot2acc_f32_f16 v33, v54, v39                            // 000000DF1C90: 04424F36
	.long 0xcc0f4023                                           // 000000DF1C94: CC0F4023
	v_mul_i32_i24_e32 v1, 0xe408, v53                          // 000000DF1C98: 12026AFF 0000E408
	v_or_b32_e32 v39, 0x64006400, v57                          // 000000DF1CA0: 384E72FF 64006400
	v_perm_b32 v53, v44, v43, 0xc060c02                        // 000000DF1CA8: D6440035 03FE572C 0C060C02
	v_or_b32_e32 v54, 0x64006400, v58                          // 000000DF1CB4: 386C74FF 64006400
	v_perm_b32 v43, v44, v43, 0xc070c03                        // 000000DF1CBC: D644002B 03FE572C 0C070C03
	s_waitcnt lgkmcnt(0)                                       // 000000DF1CC8: BF89FC07
	v_dot2acc_f32_f16 v69, v35, v65                            // 000000DF1CCC: 048A8323
	v_lshrrev_b32_e32 v35, 4, v55                              // 000000DF1CD0: 32466E84
	.long 0xcc0f4027                                           // 000000DF1CD4: CC0F4027
	v_mul_i32_i24_e32 v1, 0xe408, v39                          // 000000DF1CD8: 12024EFF 0000E408
	v_or_b32_e32 v53, 0x64006400, v53                          // 000000DF1CE0: 386A6AFF 64006400
	v_and_b32_e32 v44, 0xf0f0f0f, v55                          // 000000DF1CE8: 36586EFF 0F0F0F0F
	ds_load_b128 v[57:60], v88 offset:7712                     // 000000DF1CF0: DBFC1E20 39000058
	ds_load_b128 v[61:64], v88 offset:7728                     // 000000DF1CF8: DBFC1E30 3D000058
	v_and_b32_e32 v35, 0xf0f0f0f, v35                          // 000000DF1D00: 364646FF 0F0F0F0F
	v_dot2acc_f32_f16 v69, v39, v66                            // 000000DF1D08: 048A8527
	.long 0xcc0f4027                                           // 000000DF1D0C: CC0F4027
	v_mul_i32_i24_e32 v1, 0xe408, v53                          // 000000DF1D10: 12026AFF 0000E408
	v_or_b32_e32 v43, 0x64006400, v43                          // 000000DF1D18: 385656FF 64006400
	.long 0xcc0f4036                                           // 000000DF1D20: CC0F4036
	v_mul_i32_i24_e32 v1, 0xe408, v54                          // 000000DF1D24: 12026CFF 0000E408
	v_perm_b32 v53, v35, v44, 0xc040c00                        // 000000DF1D2C: D6440035 03FE5923 0C040C00
	v_perm_b32 v55, v70, v36, 0xc060c02                        // 000000DF1D38: D6440037 03FE4946 0C060C02
	v_dot2acc_f32_f16 v69, v39, v67                            // 000000DF1D44: 048A8727
	.long 0xcc0f4027                                           // 000000DF1D48: CC0F4027
	v_mul_i32_i24_e32 v1, 0xe408, v43                          // 000000DF1D4C: 120256FF 0000E408
	v_dot2acc_f32_f16 v33, v54, v40                            // 000000DF1D54: 04425136
	v_or_b32_e32 v43, 0x64006400, v53                          // 000000DF1D58: 38566AFF 64006400
	v_perm_b32 v40, v35, v44, 0xc050c01                        // 000000DF1D60: D6440028 03FE5923 0C050C01
	v_or_b32_e32 v55, 0x64006400, v55                          // 000000DF1D6C: 386E6EFF 64006400
	v_dot2acc_f32_f16 v69, v39, v68                            // 000000DF1D74: 048A8927
	ds_load_b128 v[65:68], v88 offset:7936                     // 000000DF1D78: DBFC1F00 41000058
	.long 0xcc0f4027                                           // 000000DF1D80: CC0F4027
	v_mul_i32_i24_e32 v1, 0xe408, v43                          // 000000DF1D84: 120256FF 0000E408
	v_or_b32_e32 v40, 0x64006400, v40                          // 000000DF1D8C: 385050FF 64006400
	v_perm_b32 v43, v35, v44, 0xc060c02                        // 000000DF1D94: D644002B 03FE5923 0C060C02
	v_perm_b32 v35, v35, v44, 0xc070c03                        // 000000DF1DA0: D6440023 03FE5923 0C070C03
	v_and_b32_e32 v44, 0xf0f0f0f, v49                          // 000000DF1DAC: 365862FF 0F0F0F0F
	s_waitcnt lgkmcnt(2)                                       // 000000DF1DB4: BF89FC27
	v_dot2acc_f32_f16 v69, v39, v57                            // 000000DF1DB8: 048A7327
	v_lshrrev_b32_e32 v39, 4, v49                              // 000000DF1DBC: 324E6284
	.long 0xcc0f4028                                           // 000000DF1DC0: CC0F4028
	v_mul_i32_i24_e32 v1, 0xe408, v40                          // 000000DF1DC4: 120250FF 0000E408
	v_or_b32_e32 v43, 0x64006400, v43                          // 000000DF1DCC: 385656FF 64006400
	.long 0xcc0f4035                                           // 000000DF1DD4: CC0F4035
	v_mul_i32_i24_e32 v1, 0xe408, v55                          // 000000DF1DD8: 12026EFF 0000E408
	v_mov_b32_e32 v57, 0                                       // 000000DF1DE0: 7E720280
	v_and_b32_e32 v39, 0xf0f0f0f, v39                          // 000000DF1DE4: 364E4EFF 0F0F0F0F
	v_dot2acc_f32_f16 v69, v40, v58                            // 000000DF1DEC: 048A7528
	.long 0xcc0f4028                                           // 000000DF1DF0: CC0F4028
	v_mul_i32_i24_e32 v1, 0xe408, v43                          // 000000DF1DF4: 120256FF 0000E408
	v_dot2acc_f32_f16 v33, v53, v41                            // 000000DF1DFC: 04425335
	v_lshrrev_b32_e32 v41, 4, v56                              // 000000DF1E00: 32527084
	v_perm_b32 v43, v39, v44, 0xc040c00                        // 000000DF1E04: D644002B 03FE5927 0C040C00
	v_and_b32_e32 v49, 0xf0f0f0f, v56                          // 000000DF1E10: 366270FF 0F0F0F0F
	v_dot2acc_f32_f16 v69, v40, v59                            // 000000DF1E18: 048A7728
	ds_load_b128 v[53:56], v88 offset:7952                     // 000000DF1E1C: DBFC1F10 35000058
	v_and_b32_e32 v58, 0xf0f0f0f, v41                          // 000000DF1E24: 367452FF 0F0F0F0F
	v_or_b32_e32 v40, 0x64006400, v43                          // 000000DF1E2C: 385056FF 64006400
	v_perm_b32 v43, v39, v44, 0xc050c01                        // 000000DF1E34: D644002B 03FE5927 0C050C01
	v_or_b32_e32 v35, 0x64006400, v35                          // 000000DF1E40: 384646FF 64006400
	v_perm_b32 v36, v70, v36, 0xc070c03                        // 000000DF1E48: D6440024 03FE4946 0C070C03
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DF1E54: BF870214
	.long 0xcc0f4028                                           // 000000DF1E58: CC0F4028
	v_mul_i32_i24_e32 v1, 0xe408, v40                          // 000000DF1E5C: 120250FF 0000E408
	v_or_b32_e32 v41, 0x64006400, v43                          // 000000DF1E64: 385256FF 64006400
	v_perm_b32 v43, v39, v44, 0xc060c02                        // 000000DF1E6C: D644002B 03FE5927 0C060C02
	v_perm_b32 v39, v39, v44, 0xc070c03                        // 000000DF1E78: D6440027 03FE5927 0C070C03
	s_waitcnt lgkmcnt(1)                                       // 000000DF1E84: BF89FC17
	v_dual_dot2acc_f32_f16 v57, v40, v65 :: v_dual_and_b32 v44, 0xf0f0f0f, v50// 000000DF1E88: CB248328 392C64FF 0F0F0F0F
	v_lshrrev_b32_e32 v40, 4, v50                              // 000000DF1E94: 32506484
	.long 0xcc0f4029                                           // 000000DF1E98: CC0F4029
	v_mul_i32_i24_e32 v1, 0xe408, v41                          // 000000DF1E9C: 120252FF 0000E408
	v_or_b32_e32 v43, 0x64006400, v43                          // 000000DF1EA4: 385656FF 64006400
	.long 0xcc0f4023                                           // 000000DF1EAC: CC0F4023
	v_mul_i32_i24_e32 v1, 0xe408, v35                          // 000000DF1EB0: 120246FF 0000E408
	v_or_b32_e32 v39, 0x64006400, v39                          // 000000DF1EB8: 384E4EFF 64006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DF1EC0: BF870214
	v_dual_dot2acc_f32_f16 v57, v41, v66 :: v_dual_and_b32 v40, 0xf0f0f0f, v40// 000000DF1EC4: CB248529 392850FF 0F0F0F0F
	.long 0xcc0f4029                                           // 000000DF1ED0: CC0F4029
	v_mul_i32_i24_e32 v1, 0xe408, v43                          // 000000DF1ED4: 120256FF 0000E408
	v_or_b32_e32 v36, 0x64006400, v36                          // 000000DF1EDC: 384848FF 64006400
	v_perm_b32 v50, v58, v49, 0xc040c00                        // 000000DF1EE4: D6440032 03FE633A 0C040C00
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DF1EF0: BF870004
	v_perm_b32 v43, v40, v44, 0xc040c00                        // 000000DF1EF4: D644002B 03FE5928 0C040C00
	v_dot2acc_f32_f16 v69, v35, v60                            // 000000DF1F00: 048A7923
	v_dot2acc_f32_f16 v57, v41, v67                            // 000000DF1F04: 04728729
	.long 0xcc0f4023                                           // 000000DF1F08: CC0F4023
	v_mul_i32_i24_e32 v1, 0xe408, v39                          // 000000DF1F0C: 12024EFF 0000E408
	.long 0xcc0f4024                                           // 000000DF1F14: CC0F4024
	v_mul_i32_i24_e32 v1, 0xe408, v36                          // 000000DF1F18: 120248FF 0000E408
	v_or_b32_e32 v39, 0x64006400, v43                          // 000000DF1F20: 384E56FF 64006400
	v_or_b32_e32 v50, 0x64006400, v50                          // 000000DF1F28: 386464FF 64006400
	v_perm_b32 v43, v40, v44, 0xc050c01                        // 000000DF1F30: D644002B 03FE5928 0C050C01
	v_dot2acc_f32_f16 v57, v35, v68                            // 000000DF1F3C: 04728923
	v_dot2acc_f32_f16 v33, v36, v42                            // 000000DF1F40: 04425524
	.long 0xcc0f4023                                           // 000000DF1F44: CC0F4023
	v_mul_i32_i24_e32 v1, 0xe408, v39                          // 000000DF1F48: 12024EFF 0000E408
	.long 0xcc0f4029                                           // 000000DF1F50: CC0F4029
	v_mul_i32_i24_e32 v1, 0xe408, v50                          // 000000DF1F54: 120264FF 0000E408
	v_or_b32_e32 v36, 0x64006400, v43                          // 000000DF1F5C: 384856FF 64006400
	v_perm_b32 v39, v40, v44, 0xc060c02                        // 000000DF1F64: D6440027 03FE5928 0C060C02
	v_perm_b32 v43, v58, v49, 0xc050c01                        // 000000DF1F70: D644002B 03FE633A 0C050C01
	s_waitcnt lgkmcnt(0)                                       // 000000DF1F7C: BF89FC07
	v_dot2acc_f32_f16 v57, v35, v53                            // 000000DF1F80: 04726B23
	v_lshrrev_b32_e32 v35, 4, v51                              // 000000DF1F84: 32466684
	v_dot2acc_f32_f16 v69, v41, v61                            // 000000DF1F88: 048A7B29
	.long 0xcc0f4024                                           // 000000DF1F8C: CC0F4024
	v_mul_i32_i24_e32 v1, 0xe408, v36                          // 000000DF1F90: 120248FF 0000E408
	v_or_b32_e32 v50, 0x64006400, v39                          // 000000DF1F98: 38644EFF 64006400
	v_perm_b32 v44, v40, v44, 0xc070c03                        // 000000DF1FA0: D644002C 03FE5928 0C070C03
	v_and_b32_e32 v51, 0xf0f0f0f, v51                          // 000000DF1FAC: 366666FF 0F0F0F0F
	v_and_b32_e32 v35, 0xf0f0f0f, v35                          // 000000DF1FB4: 364646FF 0F0F0F0F
	ds_load_b128 v[39:42], v88 offset:7968                     // 000000DF1FBC: DBFC1F20 27000058
	v_or_b32_e32 v43, 0x64006400, v43                          // 000000DF1FC4: 385656FF 64006400
	v_dot2acc_f32_f16 v57, v36, v54                            // 000000DF1FCC: 04726D24
	.long 0xcc0f4024                                           // 000000DF1FD0: CC0F4024
	v_mul_i32_i24_e32 v1, 0xe408, v50                          // 000000DF1FD4: 120264FF 0000E408
	v_or_b32_e32 v44, 0x64006400, v44                          // 000000DF1FDC: 385858FF 64006400
	v_perm_b32 v50, v35, v51, 0xc040c00                        // 000000DF1FE4: D6440032 03FE6723 0C040C00
	.long 0xcc0f402b                                           // 000000DF1FF0: CC0F402B
	v_mul_i32_i24_e32 v1, 0xe408, v43                          // 000000DF1FF4: 120256FF 0000E408
	v_perm_b32 v53, v58, v49, 0xc060c02                        // 000000DF1FFC: D6440035 03FE633A 0C060C02
	v_dot2acc_f32_f16 v57, v36, v55                            // 000000DF2008: 04726F24
	.long 0xcc0f4024                                           // 000000DF200C: CC0F4024
	v_mul_i32_i24_e32 v1, 0xe408, v44                          // 000000DF2010: 120258FF 0000E408
	v_or_b32_e32 v44, 0x64006400, v50                          // 000000DF2018: 385864FF 64006400
	v_perm_b32 v50, v35, v51, 0xc050c01                        // 000000DF2020: D6440032 03FE6723 0C050C01
	v_or_b32_e32 v53, 0x64006400, v53                          // 000000DF202C: 386A6AFF 64006400
	v_dot2acc_f32_f16 v69, v43, v62                            // 000000DF2034: 048A7D2B
	v_dot2acc_f32_f16 v57, v36, v56                            // 000000DF2038: 04727124
	.long 0xcc0f4024                                           // 000000DF203C: CC0F4024
	v_mul_i32_i24_e32 v1, 0xe408, v44                          // 000000DF2040: 120258FF 0000E408
	v_or_b32_e32 v43, 0x64006400, v50                          // 000000DF2048: 385664FF 64006400
	.long 0xcc0f402c                                           // 000000DF2050: CC0F402C
	v_mul_i32_i24_e32 v1, 0xe408, v53                          // 000000DF2054: 12026AFF 0000E408
	ds_load_b128 v[53:56], v88 offset:7984                     // 000000DF205C: DBFC1F30 35000058
	v_fma_mix_f32 v5, v5, v33, v34 op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000DF2064: CC200805 0C8A4305
	s_waitcnt lgkmcnt(1)                                       // 000000DF206C: BF89FC17
	v_dot2acc_f32_f16 v57, v36, v39                            // 000000DF2070: 04724F24
	.long 0xcc0f4024                                           // 000000DF2074: CC0F4024
	v_mul_i32_i24_e32 v1, 0xe408, v43                          // 000000DF2078: 120256FF 0000E408
	v_perm_b32 v39, v35, v51, 0xc060c02                        // 000000DF2080: D6440027 03FE6723 0C060C02
	v_lshrrev_b32_e32 v33, 4, v45                              // 000000DF208C: 32425A84
	v_perm_b32 v49, v58, v49, 0xc070c03                        // 000000DF2090: D6440031 03FE633A 0C070C03
	v_dot2acc_f32_f16 v69, v44, v63                            // 000000DF209C: 048A7F2C
	v_dot2acc_f32_f16 v57, v36, v40                            // 000000DF20A0: 04725124
	v_or_b32_e32 v39, 0x64006400, v39                          // 000000DF20A4: 384E4EFF 64006400
	v_perm_b32 v40, v35, v51, 0xc070c03                        // 000000DF20AC: D6440028 03FE6723 0C070C03
	v_lshrrev_b32_e32 v44, 4, v52                              // 000000DF20B8: 32586884
	v_and_b32_e32 v45, 0xf0f0f0f, v45                          // 000000DF20BC: 365A5AFF 0F0F0F0F
	v_and_b32_e32 v50, 0xf0f0f0f, v33                          // 000000DF20C4: 366442FF 0F0F0F0F
	ds_load_b128 v[33:36], v88 offset:8192                     // 000000DF20CC: DBFC2000 21000058
	v_or_b32_e32 v43, 0x64006400, v49                          // 000000DF20D4: 385662FF 64006400
	v_and_b32_e32 v49, 0xf0f0f0f, v52                          // 000000DF20DC: 366268FF 0F0F0F0F
	v_and_b32_e32 v44, 0xf0f0f0f, v44                          // 000000DF20E4: 365858FF 0F0F0F0F
	.long 0xcc0f4027                                           // 000000DF20EC: CC0F4027
	v_mul_i32_i24_e32 v1, 0xe408, v39                          // 000000DF20F0: 12024EFF 0000E408
	v_or_b32_e32 v40, 0x64006400, v40                          // 000000DF20F8: 385050FF 64006400
	v_perm_b32 v51, v50, v45, 0xc040c00                        // 000000DF2100: D6440033 03FE5B32 0C040C00
	.long 0xcc0f402b                                           // 000000DF210C: CC0F402B
	v_mul_i32_i24_e32 v1, 0xe408, v43                          // 000000DF2110: 120256FF 0000E408
	v_perm_b32 v52, v44, v49, 0xc040c00                        // 000000DF2118: D6440034 03FE632C 0C040C00
	v_dot2acc_f32_f16 v57, v39, v41                            // 000000DF2124: 04725327
	.long 0xcc0f4027                                           // 000000DF2128: CC0F4027
	v_mul_i32_i24_e32 v1, 0xe408, v40                          // 000000DF212C: 120250FF 0000E408
	v_or_b32_e32 v40, 0x64006400, v51                          // 000000DF2134: 385066FF 64006400
	v_dot2acc_f32_f16 v69, v43, v64                            // 000000DF213C: 048A812B
	v_or_b32_e32 v41, 0x64006400, v52                          // 000000DF2140: 385268FF 64006400
	v_perm_b32 v43, v50, v45, 0xc050c01                        // 000000DF2148: D644002B 03FE5B32 0C050C01
	v_mov_b32_e32 v52, 0                                       // 000000DF2154: 7E680280
	.long 0xcc0f4033                                           // 000000DF2158: CC0F4033
	v_mul_i32_i24_e32 v1, 0xe408, v40                          // 000000DF215C: 120250FF 0000E408
	v_dot2acc_f32_f16 v57, v39, v42                            // 000000DF2164: 04725527
	.long 0xcc0f403a                                           // 000000DF2168: CC0F403A
	v_mul_i32_i24_e32 v1, 0xe408, v41                          // 000000DF216C: 120252FF 0000E408
	v_or_b32_e32 v43, 0x64006400, v43                          // 000000DF2174: 385656FF 64006400
	v_perm_b32 v59, v50, v45, 0xc060c02                        // 000000DF217C: D644003B 03FE5B32 0C060C02
	ds_load_b128 v[39:42], v88 offset:8208                     // 000000DF2188: DBFC2010 27000058
	s_waitcnt lgkmcnt(1)                                       // 000000DF2190: BF89FC17
	v_dot2acc_f32_f16 v52, v51, v33                            // 000000DF2194: 04684333
	v_lshrrev_b32_e32 v33, 4, v46                              // 000000DF2198: 32425C84
	.long 0xcc0f402b                                           // 000000DF219C: CC0F402B
	v_mul_i32_i24_e32 v1, 0xe408, v43                          // 000000DF21A0: 120256FF 0000E408
	v_or_b32_e32 v51, 0x64006400, v59                          // 000000DF21A8: 386676FF 64006400
	v_perm_b32 v45, v50, v45, 0xc070c03                        // 000000DF21B0: D644002D 03FE5B32 0C070C03
	v_and_b32_e32 v46, 0xf0f0f0f, v46                          // 000000DF21BC: 365C5CFF 0F0F0F0F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DF21C4: BF870214
	v_dual_dot2acc_f32_f16 v52, v43, v34 :: v_dual_and_b32 v33, 0xf0f0f0f, v33// 000000DF21C8: CB24452B 342042FF 0F0F0F0F
	.long 0xcc0f4022                                           // 000000DF21D4: CC0F4022
	v_mul_i32_i24_e32 v1, 0xe408, v51                          // 000000DF21D8: 120266FF 0000E408
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000DF21E0: BF870224
	v_or_b32_e32 v43, 0x64006400, v45                          // 000000DF21E4: 38565AFF 64006400
	v_perm_b32 v50, v44, v49, 0xc050c01                        // 000000DF21EC: D6440032 03FE632C 0C050C01
	v_perm_b32 v45, v33, v46, 0xc040c00                        // 000000DF21F8: D644002D 03FE5D21 0C040C00
	v_dot2acc_f32_f16 v57, v58, v53                            // 000000DF2204: 04726B3A
	v_dot2acc_f32_f16 v52, v34, v35                            // 000000DF2208: 04684722
	.long 0xcc0f4022                                           // 000000DF220C: CC0F4022
	v_mul_i32_i24_e32 v1, 0xe408, v43                          // 000000DF2210: 120256FF 0000E408
	v_or_b32_e32 v50, 0x64006400, v50                          // 000000DF2218: 386464FF 64006400
	v_or_b32_e32 v35, 0x64006400, v45                          // 000000DF2220: 38465AFF 64006400
	v_perm_b32 v45, v33, v46, 0xc050c01                        // 000000DF2228: D644002D 03FE5D21 0C050C01
	v_fma_mix_f32 v5, v6, v69, v5 op_sel_hi:[1,0,0]            // 000000DF2234: CC200005 0C168B06
	v_dot2acc_f32_f16 v52, v34, v36                            // 000000DF223C: 04684922
	.long 0xcc0f402b                                           // 000000DF2240: CC0F402B
	v_mul_i32_i24_e32 v1, 0xe408, v50                          // 000000DF2244: 120264FF 0000E408
	.long 0xcc0f4022                                           // 000000DF224C: CC0F4022
	v_mul_i32_i24_e32 v1, 0xe408, v35                          // 000000DF2250: 120246FF 0000E408
	v_or_b32_e32 v35, 0x64006400, v45                          // 000000DF2258: 38465AFF 64006400
	v_perm_b32 v36, v33, v46, 0xc060c02                        // 000000DF2260: D6440024 03FE5D21 0C060C02
	v_perm_b32 v46, v33, v46, 0xc070c03                        // 000000DF226C: D644002E 03FE5D21 0C070C03
	s_waitcnt lgkmcnt(0)                                       // 000000DF2278: BF89FC07
	v_dual_dot2acc_f32_f16 v57, v43, v54 :: v_dual_dot2acc_f32_f16 v52, v34, v39// 000000DF227C: CB186D2B 39344F22
	v_lshrrev_b32_e32 v34, 4, v47                              // 000000DF2284: 32445E84
	v_perm_b32 v43, v44, v49, 0xc060c02                        // 000000DF2288: D644002B 03FE632C 0C060C02
	.long 0xcc0f4027                                           // 000000DF2294: CC0F4027
	v_mul_i32_i24_e32 v1, 0xe408, v35                          // 000000DF2298: 120246FF 0000E408
	v_or_b32_e32 v45, 0x64006400, v36                          // 000000DF22A0: 385A48FF 64006400
	v_and_b32_e32 v47, 0xf0f0f0f, v47                          // 000000DF22A8: 365E5EFF 0F0F0F0F
	v_and_b32_e32 v50, 0xf0f0f0f, v34                          // 000000DF22B0: 366444FF 0F0F0F0F
	ds_load_b128 v[33:36], v88 offset:8224                     // 000000DF22B8: DBFC2020 21000058
	v_or_b32_e32 v43, 0x64006400, v43                          // 000000DF22C0: 385656FF 64006400
	v_dot2acc_f32_f16 v52, v39, v40                            // 000000DF22C8: 04685127
	.long 0xcc0f4027                                           // 000000DF22CC: CC0F4027
	v_mul_i32_i24_e32 v1, 0xe408, v45                          // 000000DF22D0: 12025AFF 0000E408
	v_or_b32_e32 v40, 0x64006400, v46                          // 000000DF22D8: 38505CFF 64006400
	v_perm_b32 v45, v50, v47, 0xc040c00                        // 000000DF22E0: D644002D 03FE5F32 0C040C00
	v_perm_b32 v44, v44, v49, 0xc070c03                        // 000000DF22EC: D644002C 03FE632C 0C070C03
	.long 0xcc0f402b                                           // 000000DF22F8: CC0F402B
	v_mul_i32_i24_e32 v1, 0xe408, v43                          // 000000DF22FC: 120256FF 0000E408
	v_dot2acc_f32_f16 v52, v39, v41                            // 000000DF2304: 04685327
	.long 0xcc0f4027                                           // 000000DF2308: CC0F4027
	v_mul_i32_i24_e32 v1, 0xe408, v40                          // 000000DF230C: 120250FF 0000E408
	v_or_b32_e32 v40, 0x64006400, v45                          // 000000DF2314: 38505AFF 64006400
	v_or_b32_e32 v41, 0x64006400, v44                          // 000000DF231C: 385258FF 64006400
	v_perm_b32 v44, v50, v47, 0xc050c01                        // 000000DF2324: D644002C 03FE5F32 0C050C01
	v_dot2acc_f32_f16 v57, v43, v55                            // 000000DF2330: 04726F2B
	v_dot2acc_f32_f16 v52, v39, v42                            // 000000DF2334: 04685527
	.long 0xcc0f402b                                           // 000000DF2338: CC0F402B
	v_mul_i32_i24_e32 v1, 0xe408, v40                          // 000000DF233C: 120250FF 0000E408
	.long 0xcc0f4031                                           // 000000DF2344: CC0F4031
	v_mul_i32_i24_e32 v1, 0xe408, v41                          // 000000DF2348: 120252FF 0000E408
	v_or_b32_e32 v44, 0x64006400, v44                          // 000000DF2350: 385858FF 64006400
	v_perm_b32 v45, v50, v47, 0xc060c02                        // 000000DF2358: D644002D 03FE5F32 0C060C02
	ds_load_b128 v[39:42], v88 offset:8240                     // 000000DF2364: DBFC2030 27000058
	s_waitcnt lgkmcnt(1)                                       // 000000DF236C: BF89FC17
	v_dot2acc_f32_f16 v52, v43, v33                            // 000000DF2370: 0468432B
	v_lshrrev_b32_e32 v33, 4, v29                              // 000000DF2374: 32423A84
	.long 0xcc0f4033                                           // 000000DF2378: CC0F4033
	v_mul_i32_i24_e32 v1, 0xe408, v44                          // 000000DF237C: 120258FF 0000E408
	v_or_b32_e32 v53, 0x64006400, v45                          // 000000DF2384: 386A5AFF 64006400
	v_and_b32_e32 v29, 0xf0f0f0f, v29                          // 000000DF238C: 363A3AFF 0F0F0F0F
	ds_load_b128 v[43:46], v88 offset:8448                     // 000000DF2394: DBFC2100 2B000058
	v_and_b32_e32 v54, 0xf0f0f0f, v33                          // 000000DF239C: 366C42FF 0F0F0F0F
	v_perm_b32 v47, v50, v47, 0xc070c03                        // 000000DF23A4: D644002F 03FE5F32 0C070C03
	v_dual_dot2acc_f32_f16 v57, v49, v56 :: v_dual_dot2acc_f32_f16 v52, v51, v34// 000000DF23B0: CB187131 39344533
	.long 0xcc0f4031                                           // 000000DF23B8: CC0F4031
	v_mul_i32_i24_e32 v1, 0xe408, v53                          // 000000DF23BC: 12026AFF 0000E408
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DF23C4: BF870214
	v_perm_b32 v50, v54, v29, 0xc040c00                        // 000000DF23C8: D6440032 03FE3B36 0C040C00
	v_or_b32_e32 v47, 0x64006400, v47                          // 000000DF23D4: 385E5EFF 64006400
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DF23DC: BF870004
	v_fma_mix_f32 v5, v6, v57, v5 op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000DF23E0: CC200805 0C167306
	global_load_b64 v[33:34], v[37:38], off offset:32          // 000000DF23E8: DC560020 217C0025
	v_lshrrev_b32_e32 v37, 4, v48                              // 000000DF23F0: 324A6084
	v_or_b32_e32 v6, 0x64006400, v50                           // 000000DF23F4: 380C64FF 64006400
	v_perm_b32 v38, v54, v29, 0xc050c01                        // 000000DF23FC: D6440026 03FE3B36 0C050C01
	v_dual_mov_b32 v53, 0 :: v_dual_dot2acc_f32_f16 v52, v49, v35// 000000DF2408: CA180080 35344731
	.long 0xcc0f4023                                           // 000000DF2410: CC0F4023
	v_mul_i32_i24_e32 v1, 0xe408, v47                          // 000000DF2414: 12025EFF 0000E408
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DF241C: BF870004
	.long 0xcc0f4006                                           // 000000DF2420: CC0F4006
	v_mul_i32_i24_e32 v1, 0xe408, v6                           // 000000DF2424: 12020CFF 0000E408
	v_and_b32_e32 v51, 0xf0f0f0f, v48                          // 000000DF242C: 366660FF 0F0F0F0F
	v_and_b32_e32 v55, 0xf0f0f0f, v37                          // 000000DF2434: 366E4AFF 0F0F0F0F
	v_or_b32_e32 v37, 0x64006400, v38                          // 000000DF243C: 384A4CFF 64006400
	v_perm_b32 v38, v54, v29, 0xc060c02                        // 000000DF2444: D6440026 03FE3B36 0C060C02
	ds_load_b128 v[47:50], v88 offset:8464                     // 000000DF2450: DBFC2110 2F000058
	s_waitcnt lgkmcnt(1)                                       // 000000DF2458: BF89FC17
	v_dot2acc_f32_f16 v53, v6, v43                             // 000000DF245C: 046A5706
	v_lshrrev_b32_e32 v6, 4, v30                               // 000000DF2460: 320C3C84
	.long 0xcc0f4025                                           // 000000DF2464: CC0F4025
	v_mul_i32_i24_e32 v1, 0xe408, v37                          // 000000DF2468: 12024AFF 0000E408
	v_or_b32_e32 v38, 0x64006400, v38                          // 000000DF2470: 384C4CFF 64006400
	v_perm_b32 v29, v54, v29, 0xc070c03                        // 000000DF2478: D644001D 03FE3B36 0C070C03
	v_and_b32_e32 v30, 0xf0f0f0f, v30                          // 000000DF2484: 363C3CFF 0F0F0F0F
	v_and_b32_e32 v6, 0xf0f0f0f, v6                            // 000000DF248C: 360C0CFF 0F0F0F0F
	v_perm_b32 v43, v55, v51, 0xc040c00                        // 000000DF2494: D644002B 03FE6737 0C040C00
	v_dot2acc_f32_f16 v53, v37, v44                            // 000000DF24A0: 046A5925
	.long 0xcc0f4025                                           // 000000DF24A4: CC0F4025
	v_mul_i32_i24_e32 v1, 0xe408, v38                          // 000000DF24A8: 12024CFF 0000E408
	v_or_b32_e32 v29, 0x64006400, v29                          // 000000DF24B0: 383A3AFF 64006400
	v_perm_b32 v38, v6, v30, 0xc040c00                         // 000000DF24B8: D6440026 03FE3D06 0C040C00
	v_or_b32_e32 v43, 0x64006400, v43                          // 000000DF24C4: 385656FF 64006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DF24CC: BF870214
	v_dual_dot2acc_f32_f16 v52, v35, v36 :: v_dual_dot2acc_f32_f16 v53, v37, v45// 000000DF24D0: CB184923 34345B25
	.long 0xcc0f401d                                           // 000000DF24D8: CC0F401D
	v_mul_i32_i24_e32 v1, 0xe408, v29                          // 000000DF24DC: 12023AFF 0000E408
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DF24E4: BF870214
	v_or_b32_e32 v35, 0x64006400, v38                          // 000000DF24E8: 38464CFF 64006400
	.long 0xcc0f4024                                           // 000000DF24F0: CC0F4024
	v_mul_i32_i24_e32 v1, 0xe408, v43                          // 000000DF24F4: 120256FF 0000E408
	v_perm_b32 v37, v6, v30, 0xc050c01                         // 000000DF24FC: D6440025 03FE3D06 0C050C01
	v_perm_b32 v38, v55, v51, 0xc050c01                        // 000000DF2508: D6440026 03FE6737 0C050C01
	v_dot2acc_f32_f16 v53, v29, v46                            // 000000DF2514: 046A5D1D
	.long 0xcc0f401d                                           // 000000DF2518: CC0F401D
	v_mul_i32_i24_e32 v1, 0xe408, v35                          // 000000DF251C: 120246FF 0000E408
	v_dot2acc_f32_f16 v52, v36, v39                            // 000000DF2524: 04684F24
	v_or_b32_e32 v35, 0x64006400, v37                          // 000000DF2528: 38464AFF 64006400
	v_perm_b32 v36, v6, v30, 0xc060c02                         // 000000DF2530: D6440024 03FE3D06 0C060C02
	v_or_b32_e32 v39, 0x64006400, v38                          // 000000DF253C: 384E4CFF 64006400
	s_waitcnt lgkmcnt(0)                                       // 000000DF2544: BF89FC07
	v_dot2acc_f32_f16 v53, v29, v47                            // 000000DF2548: 046A5F1D
	v_lshrrev_b32_e32 v29, 4, v31                              // 000000DF254C: 323A3E84
	.long 0xcc0f402b                                           // 000000DF2550: CC0F402B
	v_mul_i32_i24_e32 v1, 0xe408, v35                          // 000000DF2554: 120246FF 0000E408
	v_or_b32_e32 v44, 0x64006400, v36                          // 000000DF255C: 385848FF 64006400
	v_perm_b32 v6, v6, v30, 0xc070c03                          // 000000DF2564: D6440006 03FE3D06 0C070C03
	v_and_b32_e32 v30, 0xf0f0f0f, v31                          // 000000DF2570: 363C3EFF 0F0F0F0F
	v_and_b32_e32 v29, 0xf0f0f0f, v29                          // 000000DF2578: 363A3AFF 0F0F0F0F
	ds_load_b128 v[35:38], v88 offset:8480                     // 000000DF2580: DBFC2120 23000058
	v_dot2acc_f32_f16 v53, v43, v48                            // 000000DF2588: 046A612B
	.long 0xcc0f402b                                           // 000000DF258C: CC0F402B
	v_mul_i32_i24_e32 v1, 0xe408, v44                          // 000000DF2590: 120258FF 0000E408
	v_or_b32_e32 v6, 0x64006400, v6                            // 000000DF2598: 380C0CFF 64006400
	v_perm_b32 v44, v29, v30, 0xc040c00                        // 000000DF25A0: D644002C 03FE3D1D 0C040C00
	.long 0xcc0f4027                                           // 000000DF25AC: CC0F4027
	v_mul_i32_i24_e32 v1, 0xe408, v39                          // 000000DF25B0: 12024EFF 0000E408
	v_perm_b32 v47, v29, v30, 0xc060c02                        // 000000DF25B8: D644002F 03FE3D1D 0C060C02
	v_dot2acc_f32_f16 v53, v43, v49                            // 000000DF25C4: 046A632B
	.long 0xcc0f4006                                           // 000000DF25C8: CC0F4006
	v_mul_i32_i24_e32 v1, 0xe408, v6                           // 000000DF25CC: 12020CFF 0000E408
	v_or_b32_e32 v43, 0x64006400, v44                          // 000000DF25D4: 385658FF 64006400
	v_dot2acc_f32_f16 v52, v39, v40                            // 000000DF25DC: 04685127
	v_perm_b32 v39, v29, v30, 0xc050c01                        // 000000DF25E0: D6440027 03FE3D1D 0C050C01
	v_perm_b32 v31, v55, v51, 0xc060c02                        // 000000DF25EC: D644001F 03FE6737 0C060C02
	v_dot2acc_f32_f16 v53, v6, v50                             // 000000DF25F8: 046A6506
	.long 0xcc0f4006                                           // 000000DF25FC: CC0F4006
	v_mul_i32_i24_e32 v1, 0xe408, v43                          // 000000DF2600: 120256FF 0000E408
	ds_load_b128 v[43:46], v88 offset:8496                     // 000000DF2608: DBFC2130 2B000058
	v_or_b32_e32 v39, 0x64006400, v39                          // 000000DF2610: 384E4EFF 64006400
	v_perm_b32 v40, v55, v51, 0xc070c03                        // 000000DF2618: D6440028 03FE6737 0C070C03
	v_or_b32_e32 v31, 0x64006400, v31                          // 000000DF2624: 383E3EFF 64006400
	v_perm_b32 v29, v29, v30, 0xc070c03                        // 000000DF262C: D644001D 03FE3D1D 0C070C03
	s_waitcnt lgkmcnt(1)                                       // 000000DF2638: BF89FC17
	v_dot2acc_f32_f16 v53, v6, v35                             // 000000DF263C: 046A4706
	s_waitcnt vmcnt(4)                                         // 000000DF2640: BF8913F7
	v_lshrrev_b32_e32 v6, 4, v25                               // 000000DF2644: 320C3284
	.long 0xcc0f4023                                           // 000000DF2648: CC0F4023
	v_mul_i32_i24_e32 v1, 0xe408, v39                          // 000000DF264C: 12024EFF 0000E408
	v_or_b32_e32 v39, 0x64006400, v47                          // 000000DF2654: 384E5EFF 64006400
	v_and_b32_e32 v25, 0xf0f0f0f, v25                          // 000000DF265C: 363232FF 0F0F0F0F
	ds_load_b128 v[47:50], v88 offset:8704                     // 000000DF2664: DBFC2200 2F000058
	v_and_b32_e32 v6, 0xf0f0f0f, v6                            // 000000DF266C: 360C0CFF 0F0F0F0F
	v_or_b32_e32 v30, 0x64006400, v40                          // 000000DF2674: 383C50FF 64006400
	v_dot2acc_f32_f16 v53, v35, v36                            // 000000DF267C: 046A4923
	.long 0xcc0f401f                                           // 000000DF2680: CC0F401F
	v_mul_i32_i24_e32 v1, 0xe408, v31                          // 000000DF2684: 12023EFF 0000E408
	.long 0xcc0f4023                                           // 000000DF268C: CC0F4023
	v_mul_i32_i24_e32 v1, 0xe408, v39                          // 000000DF2690: 12024EFF 0000E408
	v_perm_b32 v36, v6, v25, 0xc040c00                         // 000000DF2698: D6440024 03FE3306 0C040C00
	v_or_b32_e32 v29, 0x64006400, v29                          // 000000DF26A4: 383A3AFF 64006400
	.long 0xcc0f4027                                           // 000000DF26AC: CC0F4027
	v_mul_i32_i24_e32 v1, 0xe408, v30                          // 000000DF26B0: 12023CFF 0000E408
	v_dot2acc_f32_f16 v52, v31, v41                            // 000000DF26B8: 0468531F
	v_dot2acc_f32_f16 v53, v35, v37                            // 000000DF26BC: 046A4B23
	v_or_b32_e32 v30, 0x64006400, v36                          // 000000DF26C0: 383C48FF 64006400
	.long 0xcc0f4023                                           // 000000DF26C8: CC0F4023
	v_mul_i32_i24_e32 v1, 0xe408, v29                          // 000000DF26CC: 12023AFF 0000E408
	v_lshrrev_b32_e32 v29, 4, v32                              // 000000DF26D4: 323A4084
	v_perm_b32 v31, v6, v25, 0xc050c01                         // 000000DF26D8: D644001F 03FE3306 0C050C01
	v_mov_b32_e32 v51, 0                                       // 000000DF26E4: 7E660280
	.long 0xcc0f4024                                           // 000000DF26E8: CC0F4024
	v_mul_i32_i24_e32 v1, 0xe408, v30                          // 000000DF26EC: 12023CFF 0000E408
	v_and_b32_e32 v40, 0xf0f0f0f, v32                          // 000000DF26F4: 365040FF 0F0F0F0F
	v_and_b32_e32 v41, 0xf0f0f0f, v29                          // 000000DF26FC: 36523AFF 0F0F0F0F
	v_or_b32_e32 v37, 0x64006400, v31                          // 000000DF2704: 384A3EFF 64006400
	v_perm_b32 v54, v6, v25, 0xc060c02                         // 000000DF270C: D6440036 03FE3306 0C060C02
	ds_load_b128 v[29:32], v88 offset:8720                     // 000000DF2718: DBFC2210 1D000058
	s_waitcnt lgkmcnt(1)                                       // 000000DF2720: BF89FC17
	v_dot2acc_f32_f16 v51, v36, v47                            // 000000DF2724: 04665F24
	v_lshrrev_b32_e32 v36, 4, v26                              // 000000DF2728: 32483484
	.long 0xcc0f4025                                           // 000000DF272C: CC0F4025
	v_mul_i32_i24_e32 v1, 0xe408, v37                          // 000000DF2730: 12024AFF 0000E408
	v_or_b32_e32 v47, 0x64006400, v54                          // 000000DF2738: 385E6CFF 64006400
	v_perm_b32 v6, v6, v25, 0xc070c03                          // 000000DF2740: D6440006 03FE3306 0C070C03
	v_and_b32_e32 v25, 0xf0f0f0f, v26                          // 000000DF274C: 363234FF 0F0F0F0F
	v_and_b32_e32 v26, 0xf0f0f0f, v36                          // 000000DF2754: 363448FF 0F0F0F0F
	v_perm_b32 v36, v41, v40, 0xc040c00                        // 000000DF275C: D6440024 03FE5129 0C040C00
	v_dot2acc_f32_f16 v51, v37, v48                            // 000000DF2768: 04666125
	.long 0xcc0f4025                                           // 000000DF276C: CC0F4025
	v_mul_i32_i24_e32 v1, 0xe408, v47                          // 000000DF2770: 12025EFF 0000E408
	v_or_b32_e32 v6, 0x64006400, v6                            // 000000DF2778: 380C0CFF 64006400
	v_perm_b32 v47, v26, v25, 0xc040c00                        // 000000DF2780: D644002F 03FE331A 0C040C00
	v_or_b32_e32 v36, 0x64006400, v36                          // 000000DF278C: 384848FF 64006400
	v_dot2acc_f32_f16 v53, v35, v38                            // 000000DF2794: 046A4D23
	v_dot2acc_f32_f16 v51, v37, v49                            // 000000DF2798: 04666325
	.long 0xcc0f4006                                           // 000000DF279C: CC0F4006
	v_mul_i32_i24_e32 v1, 0xe408, v6                           // 000000DF27A0: 12020CFF 0000E408
	v_or_b32_e32 v35, 0x64006400, v47                          // 000000DF27A8: 38465EFF 64006400
	.long 0xcc0f4024                                           // 000000DF27B0: CC0F4024
	v_mul_i32_i24_e32 v1, 0xe408, v36                          // 000000DF27B4: 120248FF 0000E408
	v_perm_b32 v37, v26, v25, 0xc050c01                        // 000000DF27BC: D6440025 03FE331A 0C050C01
	v_dot2acc_f32_f16 v52, v39, v42                            // 000000DF27C8: 04685527
	v_dot2acc_f32_f16 v51, v6, v50                             // 000000DF27CC: 04666506
	.long 0xcc0f4006                                           // 000000DF27D0: CC0F4006
	v_mul_i32_i24_e32 v1, 0xe408, v35                          // 000000DF27D4: 120246FF 0000E408
	v_dot2acc_f32_f16 v53, v36, v43                            // 000000DF27DC: 046A5724
	v_or_b32_e32 v35, 0x64006400, v37                          // 000000DF27E0: 38464AFF 64006400
	v_perm_b32 v36, v26, v25, 0xc060c02                        // 000000DF27E8: D6440024 03FE331A 0C060C02
	v_perm_b32 v39, v41, v40, 0xc050c01                        // 000000DF27F4: D6440027 03FE5129 0C050C01
	s_waitcnt lgkmcnt(0)                                       // 000000DF2800: BF89FC07
	v_dot2acc_f32_f16 v51, v6, v29                             // 000000DF2804: 04663B06
	v_lshrrev_b32_e32 v6, 4, v27                               // 000000DF2808: 320C3684
	.long 0xcc0f401d                                           // 000000DF280C: CC0F401D
	v_mul_i32_i24_e32 v1, 0xe408, v35                          // 000000DF2810: 120246FF 0000E408
	v_or_b32_e32 v42, 0x64006400, v36                          // 000000DF2818: 385448FF 64006400
	v_perm_b32 v25, v26, v25, 0xc070c03                        // 000000DF2820: D6440019 03FE331A 0C070C03
	v_and_b32_e32 v26, 0xf0f0f0f, v27                          // 000000DF282C: 363436FF 0F0F0F0F
	v_and_b32_e32 v6, 0xf0f0f0f, v6                            // 000000DF2834: 360C0CFF 0F0F0F0F
	ds_load_b128 v[35:38], v88 offset:8736                     // 000000DF283C: DBFC2220 23000058
	v_or_b32_e32 v27, 0x64006400, v39                          // 000000DF2844: 38364EFF 64006400
	v_dot2acc_f32_f16 v51, v29, v30                            // 000000DF284C: 04663D1D
	.long 0xcc0f401d                                           // 000000DF2850: CC0F401D
	v_mul_i32_i24_e32 v1, 0xe408, v42                          // 000000DF2854: 120254FF 0000E408
	v_or_b32_e32 v25, 0x64006400, v25                          // 000000DF285C: 383232FF 64006400
	v_perm_b32 v30, v6, v26, 0xc040c00                         // 000000DF2864: D644001E 03FE3506 0C040C00
	.long 0xcc0f401b                                           // 000000DF2870: CC0F401B
	v_mul_i32_i24_e32 v1, 0xe408, v27                          // 000000DF2874: 120236FF 0000E408
	v_perm_b32 v39, v41, v40, 0xc060c02                        // 000000DF287C: D6440027 03FE5129 0C060C02
	v_dot2acc_f32_f16 v51, v29, v31                            // 000000DF2888: 04663F1D
	.long 0xcc0f4019                                           // 000000DF288C: CC0F4019
	v_mul_i32_i24_e32 v1, 0xe408, v25                          // 000000DF2890: 120232FF 0000E408
	v_or_b32_e32 v29, 0x64006400, v30                          // 000000DF2898: 383A3CFF 64006400
	v_perm_b32 v30, v6, v26, 0xc050c01                         // 000000DF28A0: D644001E 03FE3506 0C050C01
	v_or_b32_e32 v31, 0x64006400, v39                          // 000000DF28AC: 383E4EFF 64006400
	v_dot2acc_f32_f16 v53, v27, v44                            // 000000DF28B4: 046A591B
	v_dot2acc_f32_f16 v51, v25, v32                            // 000000DF28B8: 04664119
	.long 0xcc0f4019                                           // 000000DF28BC: CC0F4019
	v_mul_i32_i24_e32 v1, 0xe408, v29                          // 000000DF28C0: 12023AFF 0000E408
	v_or_b32_e32 v27, 0x64006400, v30                          // 000000DF28C8: 38363CFF 64006400
	.long 0xcc0f4027                                           // 000000DF28D0: CC0F4027
	v_mul_i32_i24_e32 v1, 0xe408, v31                          // 000000DF28D4: 12023EFF 0000E408
	ds_load_b128 v[29:32], v88 offset:8752                     // 000000DF28DC: DBFC2230 1D000058
	v_perm_b32 v40, v41, v40, 0xc070c03                        // 000000DF28E4: D6440028 03FE5129 0C070C03
	s_waitcnt lgkmcnt(1)                                       // 000000DF28F0: BF89FC17
	v_dot2acc_f32_f16 v51, v25, v35                            // 000000DF28F4: 04664719
	.long 0xcc0f4019                                           // 000000DF28F8: CC0F4019
	v_mul_i32_i24_e32 v1, 0xe408, v27                          // 000000DF28FC: 120236FF 0000E408
	v_perm_b32 v27, v6, v26, 0xc060c02                         // 000000DF2904: D644001B 03FE3506 0C060C02
	v_dot2acc_f32_f16 v53, v39, v45                            // 000000DF2910: 046A5B27
	v_or_b32_e32 v35, 0x64006400, v40                          // 000000DF2914: 384650FF 64006400
	v_perm_b32 v6, v6, v26, 0xc070c03                          // 000000DF291C: D6440006 03FE3506 0C070C03
	v_dot2acc_f32_f16 v51, v25, v36                            // 000000DF2928: 04664919
	s_waitcnt vmcnt(3)                                         // 000000DF292C: BF890FF7
	v_lshrrev_b32_e32 v25, 4, v21                              // 000000DF2930: 32322A84
	v_or_b32_e32 v36, 0x64006400, v27                          // 000000DF2934: 384836FF 64006400
	v_lshrrev_b32_e32 v39, 4, v28                              // 000000DF293C: 324E3884
	v_and_b32_e32 v40, 0xf0f0f0f, v28                          // 000000DF2940: 365038FF 0F0F0F0F
	v_and_b32_e32 v21, 0xf0f0f0f, v21                          // 000000DF2948: 362A2AFF 0F0F0F0F
	v_and_b32_e32 v41, 0xf0f0f0f, v25                          // 000000DF2950: 365232FF 0F0F0F0F
	ds_load_b128 v[25:28], v88 offset:8960                     // 000000DF2958: DBFC2300 19000058
	v_and_b32_e32 v39, 0xf0f0f0f, v39                          // 000000DF2960: 364E4EFF 0F0F0F0F
	.long 0xcc0f4024                                           // 000000DF2968: CC0F4024
	v_mul_i32_i24_e32 v1, 0xe408, v36                          // 000000DF296C: 120248FF 0000E408
	v_or_b32_e32 v6, 0x64006400, v6                            // 000000DF2974: 380C0CFF 64006400
	v_perm_b32 v42, v41, v21, 0xc040c00                        // 000000DF297C: D644002A 03FE2B29 0C040C00
	.long 0xcc0f4023                                           // 000000DF2988: CC0F4023
	v_mul_i32_i24_e32 v1, 0xe408, v35                          // 000000DF298C: 120246FF 0000E408
	v_perm_b32 v43, v39, v40, 0xc040c00                        // 000000DF2994: D644002B 03FE5127 0C040C00
	v_dot2acc_f32_f16 v51, v36, v37                            // 000000DF29A0: 04664B24
	.long 0xcc0f4006                                           // 000000DF29A4: CC0F4006
	v_mul_i32_i24_e32 v1, 0xe408, v6                           // 000000DF29A8: 12020CFF 0000E408
	v_or_b32_e32 v36, 0x64006400, v42                          // 000000DF29B0: 384854FF 64006400
	v_dot2acc_f32_f16 v53, v35, v46                            // 000000DF29B8: 046A5D23
	v_or_b32_e32 v35, 0x64006400, v43                          // 000000DF29BC: 384656FF 64006400
	v_perm_b32 v37, v41, v21, 0xc050c01                        // 000000DF29C4: D6440025 03FE2B29 0C050C01
	v_dot2acc_f32_f16 v51, v6, v38                             // 000000DF29D0: 04664D06
	.long 0xcc0f4006                                           // 000000DF29D4: CC0F4006
	v_mul_i32_i24_e32 v1, 0xe408, v36                          // 000000DF29D8: 120248FF 0000E408
	v_mov_b32_e32 v43, 0                                       // 000000DF29E0: 7E560280
	.long 0xcc0f402a                                           // 000000DF29E4: CC0F402A
	v_mul_i32_i24_e32 v1, 0xe408, v35                          // 000000DF29E8: 120246FF 0000E408
	v_or_b32_e32 v44, 0x64006400, v37                          // 000000DF29F0: 38584AFF 64006400
	v_perm_b32 v45, v41, v21, 0xc060c02                        // 000000DF29F8: D644002D 03FE2B29 0C060C02
	ds_load_b128 v[35:38], v88 offset:8976                     // 000000DF2A04: DBFC2310 23000058
	s_waitcnt lgkmcnt(1)                                       // 000000DF2A0C: BF89FC17
	v_dot2acc_f32_f16 v43, v6, v25                             // 000000DF2A10: 04563306
	v_lshrrev_b32_e32 v6, 4, v22                               // 000000DF2A14: 320C2C84
	.long 0xcc0f4019                                           // 000000DF2A18: CC0F4019
	v_mul_i32_i24_e32 v1, 0xe408, v44                          // 000000DF2A1C: 120258FF 0000E408
	v_or_b32_e32 v44, 0x64006400, v45                          // 000000DF2A24: 38585AFF 64006400
	v_perm_b32 v21, v41, v21, 0xc070c03                        // 000000DF2A2C: D6440015 03FE2B29 0C070C03
	v_and_b32_e32 v22, 0xf0f0f0f, v22                          // 000000DF2A38: 362C2CFF 0F0F0F0F
	v_and_b32_e32 v6, 0xf0f0f0f, v6                            // 000000DF2A40: 360C0CFF 0F0F0F0F
	v_dot2acc_f32_f16 v43, v25, v26                            // 000000DF2A48: 04563519
	.long 0xcc0f4019                                           // 000000DF2A4C: CC0F4019
	v_mul_i32_i24_e32 v1, 0xe408, v44                          // 000000DF2A50: 120258FF 0000E408
	v_or_b32_e32 v21, 0x64006400, v21                          // 000000DF2A58: 382A2AFF 64006400
	v_fma_mix_f32 v5, v7, v52, v5 op_sel_hi:[1,0,0]            // 000000DF2A60: CC200005 0C166907
	v_perm_b32 v26, v6, v22, 0xc040c00                         // 000000DF2A68: D644001A 03FE2D06 0C040C00
	v_perm_b32 v41, v39, v40, 0xc050c01                        // 000000DF2A74: D6440029 03FE5127 0C050C01
	v_dot2acc_f32_f16 v43, v25, v27                            // 000000DF2A80: 04563719
	.long 0xcc0f4015                                           // 000000DF2A84: CC0F4015
	v_mul_i32_i24_e32 v1, 0xe408, v21                          // 000000DF2A88: 12022AFF 0000E408
	v_perm_b32 v27, v6, v22, 0xc050c01                         // 000000DF2A90: D644001B 03FE2D06 0C050C01
	v_or_b32_e32 v25, 0x64006400, v26                          // 000000DF2A9C: 383234FF 64006400
	v_or_b32_e32 v41, 0x64006400, v41                          // 000000DF2AA4: 385252FF 64006400
	v_fma_mix_f32 v7, v7, v53, v5 op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000DF2AAC: CC200807 0C166B07
	v_dot2acc_f32_f16 v43, v21, v28                            // 000000DF2AB4: 04563915
	v_dot2acc_f32_f16 v51, v42, v29                            // 000000DF2AB8: 04663B2A
	.long 0xcc0f4005                                           // 000000DF2ABC: CC0F4005
	v_mul_i32_i24_e32 v1, 0xe408, v25                          // 000000DF2AC0: 120232FF 0000E408
	.long 0xcc0f401a                                           // 000000DF2AC8: CC0F401A
	v_mul_i32_i24_e32 v1, 0xe408, v41                          // 000000DF2ACC: 120252FF 0000E408
	v_or_b32_e32 v21, 0x64006400, v27                          // 000000DF2AD4: 382A36FF 64006400
	v_perm_b32 v25, v6, v22, 0xc060c02                         // 000000DF2ADC: D6440019 03FE2D06 0C060C02
	v_perm_b32 v29, v39, v40, 0xc060c02                        // 000000DF2AE8: D644001D 03FE5127 0C060C02
	s_waitcnt lgkmcnt(0)                                       // 000000DF2AF4: BF89FC07
	v_dot2acc_f32_f16 v43, v5, v35                             // 000000DF2AF8: 04564705
	v_lshrrev_b32_e32 v5, 4, v23                               // 000000DF2AFC: 320A2E84
	v_dot2acc_f32_f16 v51, v26, v30                            // 000000DF2B00: 04663D1A
	.long 0xcc0f4015                                           // 000000DF2B04: CC0F4015
	v_mul_i32_i24_e32 v1, 0xe408, v21                          // 000000DF2B08: 12022AFF 0000E408
	v_or_b32_e32 v30, 0x64006400, v25                          // 000000DF2B10: 383C32FF 64006400
	v_perm_b32 v6, v6, v22, 0xc070c03                          // 000000DF2B18: D6440006 03FE2D06 0C070C03
	v_and_b32_e32 v22, 0xf0f0f0f, v23                          // 000000DF2B24: 362C2EFF 0F0F0F0F
	v_and_b32_e32 v5, 0xf0f0f0f, v5                            // 000000DF2B2C: 360A0AFF 0F0F0F0F
	ds_load_b128 v[25:28], v88 offset:8992                     // 000000DF2B34: DBFC2320 19000058
	v_or_b32_e32 v23, 0x64006400, v29                          // 000000DF2B3C: 382E3AFF 64006400
	v_dot2acc_f32_f16 v43, v21, v36                            // 000000DF2B44: 04564915
	.long 0xcc0f4015                                           // 000000DF2B48: CC0F4015
	v_mul_i32_i24_e32 v1, 0xe408, v30                          // 000000DF2B4C: 12023CFF 0000E408
	v_or_b32_e32 v6, 0x64006400, v6                            // 000000DF2B54: 380C0CFF 64006400
	v_perm_b32 v29, v5, v22, 0xc040c00                         // 000000DF2B5C: D644001D 03FE2D05 0C040C00
	v_perm_b32 v30, v39, v40, 0xc070c03                        // 000000DF2B68: D644001E 03FE5127 0C070C03
	.long 0xcc0f4017                                           // 000000DF2B74: CC0F4017
	v_mul_i32_i24_e32 v1, 0xe408, v23                          // 000000DF2B78: 12022EFF 0000E408
	v_dot2acc_f32_f16 v43, v21, v37                            // 000000DF2B80: 04564B15
	.long 0xcc0f4006                                           // 000000DF2B84: CC0F4006
	v_mul_i32_i24_e32 v1, 0xe408, v6                           // 000000DF2B88: 12020CFF 0000E408
	v_or_b32_e32 v21, 0x64006400, v29                          // 000000DF2B90: 382A3AFF 64006400
	v_or_b32_e32 v29, 0x64006400, v30                          // 000000DF2B98: 383A3CFF 64006400
	v_perm_b32 v30, v5, v22, 0xc050c01                         // 000000DF2BA0: D644001E 03FE2D05 0C050C01
	v_dot2acc_f32_f16 v51, v23, v31                            // 000000DF2BAC: 04663F17
	v_dot2acc_f32_f16 v43, v6, v38                             // 000000DF2BB0: 04564D06
	.long 0xcc0f4006                                           // 000000DF2BB4: CC0F4006
	v_mul_i32_i24_e32 v1, 0xe408, v21                          // 000000DF2BB8: 12022AFF 0000E408
	.long 0xcc0f4015                                           // 000000DF2BC0: CC0F4015
	v_mul_i32_i24_e32 v1, 0xe408, v29                          // 000000DF2BC4: 12023AFF 0000E408
	v_or_b32_e32 v23, 0x64006400, v30                          // 000000DF2BCC: 382E3CFF 64006400
	v_perm_b32 v29, v5, v22, 0xc060c02                         // 000000DF2BD4: D644001D 03FE2D05 0C060C02
	ds_load_b128 v[35:38], v88 offset:9008                     // 000000DF2BE0: DBFC2330 23000058
	s_waitcnt lgkmcnt(1)                                       // 000000DF2BE8: BF89FC17
	v_dot2acc_f32_f16 v43, v6, v25                             // 000000DF2BEC: 04563306
	v_lshrrev_b32_e32 v6, 4, v17                               // 000000DF2BF0: 320C2284
	.long 0xcc0f4017                                           // 000000DF2BF4: CC0F4017
	v_mul_i32_i24_e32 v1, 0xe408, v23                          // 000000DF2BF8: 12022EFF 0000E408
	v_or_b32_e32 v25, 0x64006400, v29                          // 000000DF2C00: 38323AFF 64006400
	v_and_b32_e32 v17, 0xf0f0f0f, v17                          // 000000DF2C08: 362222FF 0F0F0F0F
	ds_load_b128 v[39:42], v88 offset:9216                     // 000000DF2C10: DBFC2400 27000058
	v_and_b32_e32 v6, 0xf0f0f0f, v6                            // 000000DF2C18: 360C0CFF 0F0F0F0F
	v_perm_b32 v5, v5, v22, 0xc070c03                          // 000000DF2C20: D6440005 03FE2D05 0C070C03
	v_dot2acc_f32_f16 v51, v21, v32                            // 000000DF2C2C: 04664115
	v_dot2acc_f32_f16 v43, v23, v26                            // 000000DF2C30: 04563517
	.long 0xcc0f4015                                           // 000000DF2C34: CC0F4015
	v_mul_i32_i24_e32 v1, 0xe408, v25                          // 000000DF2C38: 120232FF 0000E408
	v_perm_b32 v22, v6, v17, 0xc040c00                         // 000000DF2C40: D6440016 03FE2306 0C040C00
	v_or_b32_e32 v23, 0x64006400, v5                           // 000000DF2C4C: 382E0AFF 64006400
	v_dual_mov_b32 v44, 0 :: v_dual_and_b32 v29, 0xf0f0f0f, v24// 000000DF2C54: CA240080 2C1C30FF 0F0F0F0F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DF2C60: BF870214
	v_dot2acc_f32_f16 v43, v21, v27                            // 000000DF2C64: 04563715
	v_or_b32_e32 v21, 0x64006400, v22                          // 000000DF2C68: 382A2CFF 64006400
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DF2C70: BF870004
	.long 0xcc0f4019                                           // 000000DF2C74: CC0F4019
	v_mul_i32_i24_e32 v1, 0xe408, v23                          // 000000DF2C78: 12022EFF 0000E408
	v_lshrrev_b32_e32 v22, 4, v24                              // 000000DF2C80: 322C3084
	v_perm_b32 v23, v6, v17, 0xc050c01                         // 000000DF2C84: D6440017 03FE2306 0C050C01
	v_perm_b32 v31, v6, v17, 0xc060c02                         // 000000DF2C90: D644001F 03FE2306 0C060C02
	.long 0xcc0f401a                                           // 000000DF2C9C: CC0F401A
	v_mul_i32_i24_e32 v1, 0xe408, v21                          // 000000DF2CA0: 12022AFF 0000E408
	v_perm_b32 v6, v6, v17, 0xc070c03                          // 000000DF2CA8: D6440006 03FE2306 0C070C03
	v_and_b32_e32 v30, 0xf0f0f0f, v22                          // 000000DF2CB4: 363C2CFF 0F0F0F0F
	v_or_b32_e32 v27, 0x64006400, v23                          // 000000DF2CBC: 38362EFF 64006400
	ds_load_b128 v[21:24], v88 offset:9232                     // 000000DF2CC4: DBFC2410 15000058
	s_waitcnt lgkmcnt(1)                                       // 000000DF2CCC: BF89FC17
	v_dot2acc_f32_f16 v44, v26, v39                            // 000000DF2CD0: 04584F1A
	v_lshrrev_b32_e32 v26, 4, v18                              // 000000DF2CD4: 32342484
	v_or_b32_e32 v31, 0x64006400, v31                          // 000000DF2CD8: 383E3EFF 64006400
	.long 0xcc0f401b                                           // 000000DF2CE0: CC0F401B
	v_mul_i32_i24_e32 v1, 0xe408, v27                          // 000000DF2CE4: 120236FF 0000E408
	v_and_b32_e32 v17, 0xf0f0f0f, v18                          // 000000DF2CEC: 362224FF 0F0F0F0F
	v_or_b32_e32 v6, 0x64006400, v6                            // 000000DF2CF4: 380C0CFF 64006400
	v_and_b32_e32 v18, 0xf0f0f0f, v26                          // 000000DF2CFC: 362434FF 0F0F0F0F
	v_perm_b32 v26, v30, v29, 0xc040c00                        // 000000DF2D04: D644001A 03FE3B1E 0C040C00
	v_dot2acc_f32_f16 v44, v27, v40                            // 000000DF2D10: 0458511B
	.long 0xcc0f401b                                           // 000000DF2D14: CC0F401B
	v_mul_i32_i24_e32 v1, 0xe408, v31                          // 000000DF2D18: 12023EFF 0000E408
	v_dot2acc_f32_f16 v43, v25, v28                            // 000000DF2D20: 04563919
	v_perm_b32 v31, v18, v17, 0xc040c00                        // 000000DF2D24: D644001F 03FE2312 0C040C00
	v_or_b32_e32 v26, 0x64006400, v26                          // 000000DF2D30: 383434FF 64006400
	.long 0xcc0f4006                                           // 000000DF2D38: CC0F4006
	v_mul_i32_i24_e32 v1, 0xe408, v6                           // 000000DF2D3C: 12020CFF 0000E408
	v_dot2acc_f32_f16 v44, v27, v41                            // 000000DF2D44: 0458531B
	v_perm_b32 v27, v18, v17, 0xc050c01                        // 000000DF2D48: D644001B 03FE2312 0C050C01
	v_or_b32_e32 v25, 0x64006400, v31                          // 000000DF2D54: 38323EFF 64006400
	.long 0xcc0f401a                                           // 000000DF2D5C: CC0F401A
	v_mul_i32_i24_e32 v1, 0xe408, v26                          // 000000DF2D60: 120234FF 0000E408
	v_perm_b32 v28, v30, v29, 0xc050c01                        // 000000DF2D68: D644001C 03FE3B1E 0C050C01
	v_dot2acc_f32_f16 v44, v6, v42                             // 000000DF2D74: 04585506
	v_fma_mix_f32 v7, v8, v51, v7 op_sel_hi:[1,0,0]            // 000000DF2D78: CC200007 0C1E6708
	.long 0xcc0f4006                                           // 000000DF2D80: CC0F4006
	v_mul_i32_i24_e32 v1, 0xe408, v25                          // 000000DF2D84: 120232FF 0000E408
	v_dot2acc_f32_f16 v43, v26, v35                            // 000000DF2D8C: 0456471A
	v_or_b32_e32 v25, 0x64006400, v27                          // 000000DF2D90: 383236FF 64006400
	v_perm_b32 v26, v18, v17, 0xc060c02                        // 000000DF2D98: D644001A 03FE2312 0C060C02
	v_or_b32_e32 v31, 0x64006400, v28                          // 000000DF2DA4: 383E38FF 64006400
	s_waitcnt lgkmcnt(0)                                       // 000000DF2DAC: BF89FC07
	v_dot2acc_f32_f16 v44, v6, v21                             // 000000DF2DB0: 04582B06
	v_lshrrev_b32_e32 v6, 4, v19                               // 000000DF2DB4: 320C2684
	.long 0xcc0f4015                                           // 000000DF2DB8: CC0F4015
	v_mul_i32_i24_e32 v1, 0xe408, v25                          // 000000DF2DBC: 120232FF 0000E408
	v_or_b32_e32 v32, 0x64006400, v26                          // 000000DF2DC4: 384034FF 64006400
	v_perm_b32 v17, v18, v17, 0xc070c03                        // 000000DF2DCC: D6440011 03FE2312 0C070C03
	v_and_b32_e32 v18, 0xf0f0f0f, v19                          // 000000DF2DD8: 362426FF 0F0F0F0F
	v_and_b32_e32 v6, 0xf0f0f0f, v6                            // 000000DF2DE0: 360C0CFF 0F0F0F0F
	ds_load_b128 v[25:28], v88 offset:9248                     // 000000DF2DE8: DBFC2420 19000058
	v_dot2acc_f32_f16 v44, v21, v22                            // 000000DF2DF0: 04582D15
	.long 0xcc0f4015                                           // 000000DF2DF4: CC0F4015
	v_mul_i32_i24_e32 v1, 0xe408, v32                          // 000000DF2DF8: 120240FF 0000E408
	v_or_b32_e32 v17, 0x64006400, v17                          // 000000DF2E00: 382222FF 64006400
	v_perm_b32 v22, v6, v18, 0xc040c00                         // 000000DF2E08: D6440016 03FE2506 0C040C00
	v_perm_b32 v19, v30, v29, 0xc060c02                        // 000000DF2E14: D6440013 03FE3B1E 0C060C02
	.long 0xcc0f401f                                           // 000000DF2E20: CC0F401F
	v_mul_i32_i24_e32 v1, 0xe408, v31                          // 000000DF2E24: 12023EFF 0000E408
	v_dot2acc_f32_f16 v44, v21, v23                            // 000000DF2E2C: 04582F15
	.long 0xcc0f4011                                           // 000000DF2E30: CC0F4011
	v_mul_i32_i24_e32 v1, 0xe408, v17                          // 000000DF2E34: 120222FF 0000E408
	v_or_b32_e32 v21, 0x64006400, v22                          // 000000DF2E3C: 382A2CFF 64006400
	v_perm_b32 v22, v6, v18, 0xc050c01                         // 000000DF2E44: D6440016 03FE2506 0C050C01
	v_perm_b32 v35, v30, v29, 0xc070c03                        // 000000DF2E50: D6440023 03FE3B1E 0C070C03
	v_perm_b32 v30, v6, v18, 0xc060c02                         // 000000DF2E5C: D644001E 03FE2506 0C060C02
	v_dot2acc_f32_f16 v44, v17, v24                            // 000000DF2E68: 04583111
	.long 0xcc0f4011                                           // 000000DF2E6C: CC0F4011
	v_mul_i32_i24_e32 v1, 0xe408, v21                          // 000000DF2E70: 12022AFF 0000E408
	v_or_b32_e32 v29, 0x64006400, v22                          // 000000DF2E78: 383A2CFF 64006400
	ds_load_b128 v[21:24], v88 offset:9264                     // 000000DF2E80: DBFC2430 15000058
	v_dot2acc_f32_f16 v43, v31, v36                            // 000000DF2E88: 0456491F
	v_or_b32_e32 v36, 0x64006400, v30                          // 000000DF2E8C: 38483CFF 64006400
	v_or_b32_e32 v19, 0x64006400, v19                          // 000000DF2E94: 382626FF 64006400
	s_waitcnt lgkmcnt(1)                                       // 000000DF2E9C: BF89FC17
	v_dot2acc_f32_f16 v44, v17, v25                            // 000000DF2EA0: 04583311
	v_lshrrev_b32_e32 v17, 4, v13                              // 000000DF2EA4: 32221A84
	.long 0xcc0f4019                                           // 000000DF2EA8: CC0F4019
	v_mul_i32_i24_e32 v1, 0xe408, v29                          // 000000DF2EAC: 12023AFF 0000E408
	v_and_b32_e32 v13, 0xf0f0f0f, v13                          // 000000DF2EB4: 361A1AFF 0F0F0F0F
	ds_load_b128 v[29:32], v88 offset:9472                     // 000000DF2EBC: DBFC2500 1D000058
	.long 0xcc0f4013                                           // 000000DF2EC4: CC0F4013
	v_mul_i32_i24_e32 v1, 0xe408, v19                          // 000000DF2EC8: 120226FF 0000E408
	v_and_b32_e32 v39, 0xf0f0f0f, v17                          // 000000DF2ED0: 364E22FF 0F0F0F0F
	v_or_b32_e32 v17, 0x64006400, v35                          // 000000DF2ED8: 382246FF 64006400
	v_dot2acc_f32_f16 v44, v25, v26                            // 000000DF2EE0: 04583519
	v_perm_b32 v6, v6, v18, 0xc070c03                          // 000000DF2EE4: D6440006 03FE2506 0C070C03
	.long 0xcc0f4012                                           // 000000DF2EF0: CC0F4012
	v_mul_i32_i24_e32 v1, 0xe408, v36                          // 000000DF2EF4: 120248FF 0000E408
	v_perm_b32 v25, v39, v13, 0xc040c00                        // 000000DF2EFC: D6440019 03FE1B27 0C040C00
	.long 0xcc0f401a                                           // 000000DF2F08: CC0F401A
	v_mul_i32_i24_e32 v1, 0xe408, v17                          // 000000DF2F0C: 120222FF 0000E408
	v_dot2acc_f32_f16 v43, v19, v37                            // 000000DF2F14: 04564B13
	v_perm_b32 v19, v39, v13, 0xc050c01                        // 000000DF2F18: D6440013 03FE1B27 0C050C01
	v_dot2acc_f32_f16 v44, v18, v27                            // 000000DF2F24: 04583712
	v_or_b32_e32 v17, 0x64006400, v25                          // 000000DF2F28: 382232FF 64006400
	v_lshrrev_b32_e32 v18, 4, v20                              // 000000DF2F30: 32242884
	v_dual_mov_b32 v36, 0 :: v_dual_and_b32 v35, 0xf0f0f0f, v20// 000000DF2F34: CA240080 242228FF 0F0F0F0F
	v_or_b32_e32 v27, 0x64006400, v19                          // 000000DF2F40: 383626FF 64006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DF2F48: BF870214
	.long 0xcc0f4019                                           // 000000DF2F4C: CC0F4019
	v_mul_i32_i24_e32 v1, 0xe408, v17                          // 000000DF2F50: 120222FF 0000E408
	v_and_b32_e32 v37, 0xf0f0f0f, v18                          // 000000DF2F58: 364A24FF 0F0F0F0F
	v_perm_b32 v40, v39, v13, 0xc060c02                        // 000000DF2F60: D6440028 03FE1B27 0C060C02
	ds_load_b128 v[17:20], v88 offset:9488                     // 000000DF2F6C: DBFC2510 11000058
	v_or_b32_e32 v6, 0x64006400, v6                            // 000000DF2F74: 380C0CFF 64006400
	s_waitcnt lgkmcnt(1)                                       // 000000DF2F7C: BF89FC17
	v_dot2acc_f32_f16 v36, v25, v29                            // 000000DF2F80: 04483B19
	v_lshrrev_b32_e32 v25, 4, v14                              // 000000DF2F84: 32321C84
	.long 0xcc0f401b                                           // 000000DF2F88: CC0F401B
	v_mul_i32_i24_e32 v1, 0xe408, v27                          // 000000DF2F8C: 120236FF 0000E408
	v_or_b32_e32 v29, 0x64006400, v40                          // 000000DF2F94: 383A50FF 64006400
	v_perm_b32 v13, v39, v13, 0xc070c03                        // 000000DF2F9C: D644000D 03FE1B27 0C070C03
	v_and_b32_e32 v14, 0xf0f0f0f, v14                          // 000000DF2FA8: 361C1CFF 0F0F0F0F
	v_and_b32_e32 v25, 0xf0f0f0f, v25                          // 000000DF2FB0: 363232FF 0F0F0F0F
	.long 0xcc0f4006                                           // 000000DF2FB8: CC0F4006
	v_mul_i32_i24_e32 v1, 0xe408, v6                           // 000000DF2FBC: 12020CFF 0000E408
	v_perm_b32 v39, v37, v35, 0xc040c00                        // 000000DF2FC4: D6440027 03FE4725 0C040C00
	v_dot2acc_f32_f16 v36, v27, v30                            // 000000DF2FD0: 04483D1B
	.long 0xcc0f401b                                           // 000000DF2FD4: CC0F401B
	v_mul_i32_i24_e32 v1, 0xe408, v29                          // 000000DF2FD8: 12023AFF 0000E408
	v_or_b32_e32 v13, 0x64006400, v13                          // 000000DF2FE0: 381A1AFF 64006400
	v_perm_b32 v29, v25, v14, 0xc040c00                        // 000000DF2FE8: D644001D 03FE1D19 0C040C00
	v_or_b32_e32 v30, 0x64006400, v39                          // 000000DF2FF4: 383C4EFF 64006400
	v_dot2acc_f32_f16 v44, v6, v28                             // 000000DF2FFC: 04583906
	v_dot2acc_f32_f16 v36, v27, v31                            // 000000DF3000: 04483F1B
	.long 0xcc0f4006                                           // 000000DF3004: CC0F4006
	v_mul_i32_i24_e32 v1, 0xe408, v13                          // 000000DF3008: 12021AFF 0000E408
	v_or_b32_e32 v13, 0x64006400, v29                          // 000000DF3010: 381A3AFF 64006400
	.long 0xcc0f401b                                           // 000000DF3018: CC0F401B
	v_mul_i32_i24_e32 v1, 0xe408, v30                          // 000000DF301C: 12023CFF 0000E408
	v_perm_b32 v28, v25, v14, 0xc050c01                        // 000000DF3024: D644001C 03FE1D19 0C050C01
	v_dot2acc_f32_f16 v43, v26, v38                            // 000000DF3030: 04564D1A
	v_dot2acc_f32_f16 v36, v6, v32                             // 000000DF3034: 04484106
	.long 0xcc0f4006                                           // 000000DF3038: CC0F4006
	v_mul_i32_i24_e32 v1, 0xe408, v13                          // 000000DF303C: 12021AFF 0000E408
	v_dot2acc_f32_f16 v44, v27, v21                            // 000000DF3044: 04582B1B
	v_or_b32_e32 v13, 0x64006400, v28                          // 000000DF3048: 381A38FF 64006400
	v_perm_b32 v21, v25, v14, 0xc060c02                        // 000000DF3050: D6440015 03FE1D19 0C060C02
	v_perm_b32 v29, v37, v35, 0xc050c01                        // 000000DF305C: D644001D 03FE4725 0C050C01
	s_waitcnt lgkmcnt(0)                                       // 000000DF3068: BF89FC07
	v_dot2acc_f32_f16 v36, v6, v17                             // 000000DF306C: 04482306
	v_lshrrev_b32_e32 v6, 4, v15                               // 000000DF3070: 320C1E84
	.long 0xcc0f400d                                           // 000000DF3074: CC0F400D
	v_mul_i32_i24_e32 v1, 0xe408, v13                          // 000000DF3078: 12021AFF 0000E408
	v_or_b32_e32 v17, 0x64006400, v21                          // 000000DF3080: 38222AFF 64006400
	v_perm_b32 v14, v25, v14, 0xc070c03                        // 000000DF3088: D644000E 03FE1D19 0C070C03
	v_and_b32_e32 v15, 0xf0f0f0f, v15                          // 000000DF3094: 361E1EFF 0F0F0F0F
	v_and_b32_e32 v6, 0xf0f0f0f, v6                            // 000000DF309C: 360C0CFF 0F0F0F0F
	ds_load_b128 v[25:28], v88 offset:9504                     // 000000DF30A4: DBFC2520 19000058
	v_or_b32_e32 v21, 0x64006400, v29                          // 000000DF30AC: 382A3AFF 64006400
	v_dot2acc_f32_f16 v36, v13, v18                            // 000000DF30B4: 0448250D
	.long 0xcc0f400d                                           // 000000DF30B8: CC0F400D
	v_mul_i32_i24_e32 v1, 0xe408, v17                          // 000000DF30BC: 120222FF 0000E408
	v_or_b32_e32 v14, 0x64006400, v14                          // 000000DF30C4: 381C1CFF 64006400
	v_perm_b32 v17, v6, v15, 0xc040c00                         // 000000DF30CC: D6440011 03FE1F06 0C040C00
	.long 0xcc0f4012                                           // 000000DF30D8: CC0F4012
	v_mul_i32_i24_e32 v1, 0xe408, v21                          // 000000DF30DC: 12022AFF 0000E408
	v_perm_b32 v21, v37, v35, 0xc060c02                        // 000000DF30E4: D6440015 03FE4725 0C060C02
	v_dot2acc_f32_f16 v36, v13, v19                            // 000000DF30F0: 0448270D
	.long 0xcc0f400d                                           // 000000DF30F4: CC0F400D
	v_mul_i32_i24_e32 v1, 0xe408, v14                          // 000000DF30F8: 12021CFF 0000E408
	v_or_b32_e32 v14, 0x64006400, v17                          // 000000DF3100: 381C22FF 64006400
	v_perm_b32 v17, v6, v15, 0xc050c01                         // 000000DF3108: D6440011 03FE1F06 0C050C01
	v_or_b32_e32 v19, 0x64006400, v21                          // 000000DF3114: 38262AFF 64006400
	v_dot2acc_f32_f16 v44, v18, v22                            // 000000DF311C: 04582D12
	v_dot2acc_f32_f16 v36, v13, v20                            // 000000DF3120: 0448290D
	.long 0xcc0f400d                                           // 000000DF3124: CC0F400D
	v_mul_i32_i24_e32 v1, 0xe408, v14                          // 000000DF3128: 12021CFF 0000E408
	v_or_b32_e32 v14, 0x64006400, v17                          // 000000DF3130: 381C22FF 64006400
	.long 0xcc0f4015                                           // 000000DF3138: CC0F4015
	v_mul_i32_i24_e32 v1, 0xe408, v19                          // 000000DF313C: 120226FF 0000E408
	ds_load_b128 v[17:20], v88 offset:9520                     // 000000DF3144: DBFC2530 11000058
	v_perm_b32 v22, v37, v35, 0xc070c03                        // 000000DF314C: D6440016 03FE4725 0C070C03
	s_waitcnt lgkmcnt(1)                                       // 000000DF3158: BF89FC17
	v_dot2acc_f32_f16 v36, v13, v25                            // 000000DF315C: 0448330D
	.long 0xcc0f400d                                           // 000000DF3160: CC0F400D
	v_mul_i32_i24_e32 v1, 0xe408, v14                          // 000000DF3164: 12021CFF 0000E408
	v_perm_b32 v14, v6, v15, 0xc060c02                         // 000000DF316C: D644000E 03FE1F06 0C060C02
	v_fma_mix_f32 v25, v8, v43, v7 op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000DF3178: CC200819 0C1E5708
	s_waitcnt vmcnt(2)                                         // 000000DF3180: BF890BF7
	v_lshrrev_b32_e32 v7, 4, v9                                // 000000DF3184: 320E1284
	v_dot2acc_f32_f16 v44, v21, v23                            // 000000DF3188: 04582F15
	v_dot2acc_f32_f16 v36, v13, v26                            // 000000DF318C: 0448350D
	v_or_b32_e32 v13, 0x64006400, v14                          // 000000DF3190: 381A1CFF 64006400
	v_perm_b32 v14, v6, v15, 0xc070c03                         // 000000DF3198: D644000E 03FE1F06 0C070C03
	v_lshrrev_b32_e32 v15, 4, v16                              // 000000DF31A4: 321E2084
	v_and_b32_e32 v23, 0xf0f0f0f, v9                           // 000000DF31A8: 362E12FF 0F0F0F0F
	v_and_b32_e32 v26, 0xf0f0f0f, v7                           // 000000DF31B0: 36340EFF 0F0F0F0F
	ds_load_b128 v[6:9], v88 offset:9728                       // 000000DF31B8: DBFC2600 06000058
	v_or_b32_e32 v21, 0x64006400, v22                          // 000000DF31C0: 382A2CFF 64006400
	v_and_b32_e32 v22, 0xf0f0f0f, v16                          // 000000DF31C8: 362C20FF 0F0F0F0F
	v_and_b32_e32 v29, 0xf0f0f0f, v15                          // 000000DF31D0: 363A1EFF 0F0F0F0F
	.long 0xcc0f400d                                           // 000000DF31D8: CC0F400D
	v_mul_i32_i24_e32 v1, 0xe408, v13                          // 000000DF31DC: 12021AFF 0000E408
	v_or_b32_e32 v14, 0x64006400, v14                          // 000000DF31E4: 381C1CFF 64006400
	v_perm_b32 v15, v26, v23, 0xc040c00                        // 000000DF31EC: D644000F 03FE2F1A 0C040C00
	.long 0xcc0f4010                                           // 000000DF31F8: CC0F4010
	v_mul_i32_i24_e32 v1, 0xe408, v21                          // 000000DF31FC: 12022AFF 0000E408
	v_perm_b32 v21, v29, v22, 0xc040c00                        // 000000DF3204: D6440015 03FE2D1D 0C040C00
	v_dot2acc_f32_f16 v36, v13, v27                            // 000000DF3210: 0448370D
	.long 0xcc0f400d                                           // 000000DF3214: CC0F400D
	v_mul_i32_i24_e32 v1, 0xe408, v14                          // 000000DF3218: 12021CFF 0000E408
	v_or_b32_e32 v14, 0x64006400, v15                          // 000000DF3220: 381C1EFF 64006400
	v_dot2acc_f32_f16 v44, v16, v24                            // 000000DF3228: 04583110
	v_or_b32_e32 v15, 0x64006400, v21                          // 000000DF322C: 381E2AFF 64006400
	v_perm_b32 v16, v26, v23, 0xc050c01                        // 000000DF3234: D6440010 03FE2F1A 0C050C01
	v_mov_b32_e32 v27, 0                                       // 000000DF3240: 7E360280
	.long 0xcc0f4015                                           // 000000DF3244: CC0F4015
	v_mul_i32_i24_e32 v1, 0xe408, v14                          // 000000DF3248: 12021CFF 0000E408
	v_dot2acc_f32_f16 v36, v13, v28                            // 000000DF3250: 0448390D
	.long 0xcc0f4018                                           // 000000DF3254: CC0F4018
	v_mul_i32_i24_e32 v1, 0xe408, v15                          // 000000DF3258: 12021EFF 0000E408
	v_or_b32_e32 v28, 0x64006400, v16                          // 000000DF3260: 383820FF 64006400
	v_perm_b32 v30, v26, v23, 0xc060c02                        // 000000DF3268: D644001E 03FE2F1A 0C060C02
	ds_load_b128 v[13:16], v88 offset:9744                     // 000000DF3274: DBFC2610 0D000058
	s_waitcnt lgkmcnt(1)                                       // 000000DF327C: BF89FC17
	v_dot2acc_f32_f16 v27, v21, v6                             // 000000DF3280: 04360D15
	v_lshrrev_b32_e32 v6, 4, v10                               // 000000DF3284: 320C1484
	.long 0xcc0f4015                                           // 000000DF3288: CC0F4015
	v_mul_i32_i24_e32 v1, 0xe408, v28                          // 000000DF328C: 120238FF 0000E408
	v_or_b32_e32 v28, 0x64006400, v30                          // 000000DF3294: 38383CFF 64006400
	v_perm_b32 v23, v26, v23, 0xc070c03                        // 000000DF329C: D6440017 03FE2F1A 0C070C03
	v_and_b32_e32 v10, 0xf0f0f0f, v10                          // 000000DF32A8: 361414FF 0F0F0F0F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DF32B0: BF870214
	v_dual_dot2acc_f32_f16 v27, v21, v7 :: v_dual_and_b32 v6, 0xf0f0f0f, v6// 000000DF32B4: CB240F15 1B060CFF 0F0F0F0F
	.long 0xcc0f4007                                           // 000000DF32C0: CC0F4007
	v_mul_i32_i24_e32 v1, 0xe408, v28                          // 000000DF32C4: 120238FF 0000E408
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000DF32CC: BF870224
	v_or_b32_e32 v21, 0x64006400, v23                          // 000000DF32D0: 382A2EFF 64006400
	v_perm_b32 v26, v29, v22, 0xc050c01                        // 000000DF32D8: D644001A 03FE2D1D 0C050C01
	v_perm_b32 v23, v6, v10, 0xc040c00                         // 000000DF32E4: D6440017 03FE1506 0C040C00
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DF32F0: BF870214
	v_dual_dot2acc_f32_f16 v36, v24, v17 :: v_dual_dot2acc_f32_f16 v27, v7, v8// 000000DF32F4: CB182318 241A1107
	.long 0xcc0f4007                                           // 000000DF32FC: CC0F4007
	v_mul_i32_i24_e32 v1, 0xe408, v21                          // 000000DF3300: 12022AFF 0000E408
	v_perm_b32 v21, v6, v10, 0xc050c01                         // 000000DF3308: D6440015 03FE1506 0C050C01
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DF3314: BF870004
	v_or_b32_e32 v8, 0x64006400, v23                           // 000000DF3318: 38102EFF 64006400
	v_or_b32_e32 v26, 0x64006400, v26                          // 000000DF3320: 383434FF 64006400
	v_perm_b32 v23, v29, v22, 0xc060c02                        // 000000DF3328: D6440017 03FE2D1D 0C060C02
	v_dot2acc_f32_f16 v27, v7, v9                              // 000000DF3334: 04361307
	v_perm_b32 v9, v6, v10, 0xc060c02                          // 000000DF3338: D6440009 03FE1506 0C060C02
	.long 0xcc0f4007                                           // 000000DF3344: CC0F4007
	v_mul_i32_i24_e32 v1, 0xe408, v8                           // 000000DF3348: 120210FF 0000E408
	v_or_b32_e32 v8, 0x64006400, v21                           // 000000DF3350: 38102AFF 64006400
	.long 0xcc0f4011                                           // 000000DF3358: CC0F4011
	v_mul_i32_i24_e32 v1, 0xe408, v26                          // 000000DF335C: 120234FF 0000E408
	v_perm_b32 v10, v6, v10, 0xc070c03                         // 000000DF3364: D644000A 03FE1506 0C070C03
	v_mov_b32_e32 v5, 0                                        // 000000DF3370: 7E0A0280
	s_waitcnt lgkmcnt(0)                                       // 000000DF3374: BF89FC07
	v_dot2acc_f32_f16 v27, v7, v13                             // 000000DF3378: 04361B07
	v_lshrrev_b32_e32 v7, 4, v11                               // 000000DF337C: 320E1684
	.long 0xcc0f4008                                           // 000000DF3380: CC0F4008
	v_mul_i32_i24_e32 v1, 0xe408, v8                           // 000000DF3384: 120210FF 0000E408
	v_or_b32_e32 v13, 0x64006400, v9                           // 000000DF338C: 381A12FF 64006400
	v_and_b32_e32 v11, 0xf0f0f0f, v11                          // 000000DF3394: 361616FF 0F0F0F0F
	v_or_b32_e32 v10, 0x64006400, v10                          // 000000DF339C: 381414FF 64006400
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DF33A4: BF870004
	v_dual_dot2acc_f32_f16 v27, v8, v14 :: v_dual_and_b32 v26, 0xf0f0f0f, v7// 000000DF33A8: CB241D08 1B1A0EFF 0F0F0F0F
	ds_load_b128 v[6:9], v88 offset:9760                       // 000000DF33B4: DBFC2620 06000058
	.long 0xcc0f400d                                           // 000000DF33BC: CC0F400D
	v_mul_i32_i24_e32 v1, 0xe408, v13                          // 000000DF33C0: 12021AFF 0000E408
	.long 0xcc0f400a                                           // 000000DF33C8: CC0F400A
	v_mul_i32_i24_e32 v1, 0xe408, v10                          // 000000DF33CC: 120214FF 0000E408
	v_perm_b32 v14, v26, v11, 0xc040c00                        // 000000DF33D4: D644000E 03FE171A 0C040C00
	v_dot2acc_f32_f16 v36, v17, v18                            // 000000DF33E0: 04482511
	v_perm_b32 v18, v29, v22, 0xc070c03                        // 000000DF33E4: D6440012 03FE2D1D 0C070C03
	v_dot2acc_f32_f16 v27, v13, v15                            // 000000DF33F0: 04361F0D
	s_waitcnt vmcnt(1)                                         // 000000DF33F4: BF8907F7
	v_lshrrev_b32_e32 v15, 4, v1                               // 000000DF33F8: 321E0284
	v_or_b32_e32 v13, 0x64006400, v14                          // 000000DF33FC: 381A1CFF 64006400
	v_perm_b32 v14, v26, v11, 0xc050c01                        // 000000DF3404: D644000E 03FE171A 0C050C01
	v_and_b32_e32 v1, 0xf0f0f0f, v1                            // 000000DF3410: 360202FF 0F0F0F0F
	v_dot2acc_f32_f16 v27, v10, v16                            // 000000DF3418: 0436210A
	v_and_b32_e32 v29, 0xf0f0f0f, v15                          // 000000DF341C: 363A1EFF 0F0F0F0F
	.long 0xcc0f400a                                           // 000000DF3424: CC0F400A
	v_mul_i32_i24_e32 v1, 0xe408, v13                          // 000000DF3428: 12021AFF 0000E408
	v_or_b32_e32 v28, 0x64006400, v14                          // 000000DF3430: 38381CFF 64006400
	ds_load_b128 v[13:16], v88 offset:9984                     // 000000DF3438: DBFC2700 0D000058
	v_or_b32_e32 v17, 0x64006400, v23                          // 000000DF3440: 38222EFF 64006400
	v_perm_b32 v30, v26, v11, 0xc060c02                        // 000000DF3448: D644001E 03FE171A 0C060C02
	ds_load_b128 v[21:24], v88 offset:9776                     // 000000DF3454: DBFC2630 15000058
	v_or_b32_e32 v18, 0x64006400, v18                          // 000000DF345C: 382424FF 64006400
	s_waitcnt lgkmcnt(2)                                       // 000000DF3464: BF89FC27
	v_dot2acc_f32_f16 v27, v10, v6                             // 000000DF3468: 04360D0A
	.long 0xcc0f4006                                           // 000000DF346C: CC0F4006
	v_mul_i32_i24_e32 v1, 0xe408, v28                          // 000000DF3470: 120238FF 0000E408
	v_perm_b32 v10, v29, v1, 0xc040c00                         // 000000DF3478: D644000A 03FE031D 0C040C00
	.long 0xcc0f4011                                           // 000000DF3484: CC0F4011
	v_mul_i32_i24_e32 v1, 0xe408, v17                          // 000000DF3488: 120222FF 0000E408
	v_or_b32_e32 v28, 0x64006400, v30                          // 000000DF3490: 38383CFF 64006400
	s_waitcnt vmcnt(0)                                         // 000000DF3498: BF8903F7
	v_fma_mix_f32 v25, v33, v44, v25 op_sel_hi:[1,0,0]         // 000000DF349C: CC200019 0C665921
	v_dot2acc_f32_f16 v27, v6, v7                              // 000000DF34A4: 04360F06
	v_or_b32_e32 v6, 0x64006400, v10                           // 000000DF34A8: 380C14FF 64006400
	v_dot2acc_f32_f16 v36, v17, v19                            // 000000DF34B0: 04482711
	.long 0xcc0f4011                                           // 000000DF34B4: CC0F4011
	v_mul_i32_i24_e32 v1, 0xe408, v18                          // 000000DF34B8: 120224FF 0000E408
	.long 0xcc0f4007                                           // 000000DF34C0: CC0F4007
	v_mul_i32_i24_e32 v1, 0xe408, v28                          // 000000DF34C4: 120238FF 0000E408
	v_perm_b32 v10, v29, v1, 0xc050c01                         // 000000DF34CC: D644000A 03FE031D 0C050C01
	.long 0xcc0f4006                                           // 000000DF34D8: CC0F4006
	v_mul_i32_i24_e32 v1, 0xe408, v6                           // 000000DF34DC: 12020CFF 0000E408
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DF34E4: BF870214
	v_dot2acc_f32_f16 v36, v17, v20                            // 000000DF34E8: 04482911
	v_dot2acc_f32_f16 v27, v7, v8                              // 000000DF34EC: 04361107
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DF34F0: BF870004
	v_or_b32_e32 v7, 0x64006400, v10                           // 000000DF34F4: 380E14FF 64006400
	v_perm_b32 v8, v29, v1, 0xc060c02                          // 000000DF34FC: D6440008 03FE031D 0C060C02
	ds_load_b128 v[17:20], v88 offset:10000                    // 000000DF3508: DBFC2710 11000058
	s_waitcnt lgkmcnt(2)                                       // 000000DF3510: BF89FC27
	v_dot2acc_f32_f16 v5, v6, v13                              // 000000DF3514: 040A1B06
	v_lshrrev_b32_e32 v6, 4, v2                                // 000000DF3518: 320C0484
	.long 0xcc0f4007                                           // 000000DF351C: CC0F4007
	v_mul_i32_i24_e32 v1, 0xe408, v7                           // 000000DF3520: 12020EFF 0000E408
	v_or_b32_e32 v8, 0x64006400, v8                            // 000000DF3528: 381010FF 64006400
	v_perm_b32 v1, v29, v1, 0xc070c03                          // 000000DF3530: D6440001 03FE031D 0C070C03
	v_and_b32_e32 v2, 0xf0f0f0f, v2                            // 000000DF353C: 360404FF 0F0F0F0F
	v_and_b32_e32 v6, 0xf0f0f0f, v6                            // 000000DF3544: 360C0CFF 0F0F0F0F
	v_dot2acc_f32_f16 v5, v7, v14                              // 000000DF354C: 040A1D07
	.long 0xcc0f4007                                           // 000000DF3550: CC0F4007
	v_mul_i32_i24_e32 v1, 0xe408, v8                           // 000000DF3554: 120210FF 0000E408
	v_or_b32_e32 v1, 0x64006400, v1                            // 000000DF355C: 380202FF 64006400
	v_perm_b32 v10, v26, v11, 0xc070c03                        // 000000DF3564: D644000A 03FE171A 0C070C03
	v_perm_b32 v8, v6, v2, 0xc040c00                           // 000000DF3570: D6440008 03FE0506 0C040C00
	v_lshrrev_b32_e32 v11, 4, v12                              // 000000DF357C: 32161884
	v_dot2acc_f32_f16 v5, v7, v15                              // 000000DF3580: 040A1F07
	.long 0xcc0f4001                                           // 000000DF3584: CC0F4001
	v_mul_i32_i24_e32 v1, 0xe408, v1                           // 000000DF3588: 120202FF 0000E408
	v_or_b32_e32 v10, 0x64006400, v10                          // 000000DF3590: 381414FF 64006400
	v_or_b32_e32 v7, 0x64006400, v8                            // 000000DF3598: 380E10FF 64006400
	v_perm_b32 v8, v6, v2, 0xc050c01                           // 000000DF35A0: D6440008 03FE0506 0C050C01
	v_and_b32_e32 v14, 0xf0f0f0f, v12                          // 000000DF35AC: 361C18FF 0F0F0F0F
	v_dot2acc_f32_f16 v5, v1, v16                              // 000000DF35B4: 040A2101
	v_and_b32_e32 v15, 0xf0f0f0f, v11                          // 000000DF35B8: 361E16FF 0F0F0F0F
	.long 0xcc0f4001                                           // 000000DF35C0: CC0F4001
	v_mul_i32_i24_e32 v1, 0xe408, v7                           // 000000DF35C4: 12020EFF 0000E408
	.long 0xcc0f4007                                           // 000000DF35CC: CC0F4007
	v_mul_i32_i24_e32 v1, 0xe408, v10                          // 000000DF35D0: 120214FF 0000E408
	v_or_b32_e32 v8, 0x64006400, v8                            // 000000DF35D8: 381010FF 64006400
	v_perm_b32 v10, v6, v2, 0xc060c02                          // 000000DF35E0: D644000A 03FE0506 0C060C02
	v_perm_b32 v16, v15, v14, 0xc040c00                        // 000000DF35EC: D6440010 03FE1D0F 0C040C00
	s_waitcnt lgkmcnt(0)                                       // 000000DF35F8: BF89FC07
	v_dot2acc_f32_f16 v5, v1, v17                              // 000000DF35FC: 040A2301
	v_lshrrev_b32_e32 v1, 4, v3                                // 000000DF3600: 32020684
	.long 0xcc0f4008                                           // 000000DF3604: CC0F4008
	v_mul_i32_i24_e32 v1, 0xe408, v8                           // 000000DF3608: 120210FF 0000E408
	v_or_b32_e32 v17, 0x64006400, v10                          // 000000DF3610: 382214FF 64006400
	v_perm_b32 v2, v6, v2, 0xc070c03                           // 000000DF3618: D6440002 03FE0506 0C070C03
	v_and_b32_e32 v3, 0xf0f0f0f, v3                            // 000000DF3624: 360606FF 0F0F0F0F
	v_and_b32_e32 v1, 0xf0f0f0f, v1                            // 000000DF362C: 360202FF 0F0F0F0F
	ds_load_b128 v[10:13], v88 offset:10016                    // 000000DF3634: DBFC2720 0A000058
	v_or_b32_e32 v6, 0x64006400, v16                           // 000000DF363C: 380C20FF 64006400
	v_dot2acc_f32_f16 v5, v8, v18                              // 000000DF3644: 040A2508
	.long 0xcc0f4008                                           // 000000DF3648: CC0F4008
	v_mul_i32_i24_e32 v1, 0xe408, v17                          // 000000DF364C: 120222FF 0000E408
	v_or_b32_e32 v2, 0x64006400, v2                            // 000000DF3654: 380404FF 64006400
	v_perm_b32 v16, v1, v3, 0xc040c00                          // 000000DF365C: D6440010 03FE0701 0C040C00
	v_dot2acc_f32_f16 v27, v7, v9                              // 000000DF3668: 04361307
	.long 0xcc0f4006                                           // 000000DF366C: CC0F4006
	v_mul_i32_i24_e32 v1, 0xe408, v6                           // 000000DF3670: 12020CFF 0000E408
	v_dot2acc_f32_f16 v5, v8, v19                              // 000000DF3678: 040A2708
	.long 0xcc0f4002                                           // 000000DF367C: CC0F4002
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000DF3680: 120204FF 0000E408
	v_or_b32_e32 v7, 0x64006400, v16                           // 000000DF3688: 380E20FF 64006400
	v_perm_b32 v8, v15, v14, 0xc050c01                         // 000000DF3690: D6440008 03FE1D0F 0C050C01
	v_perm_b32 v9, v1, v3, 0xc050c01                           // 000000DF369C: D6440009 03FE0701 0C050C01
	v_dot2acc_f32_f16 v27, v6, v21                             // 000000DF36A8: 04362B06
	v_dot2acc_f32_f16 v5, v2, v20                              // 000000DF36AC: 040A2902
	.long 0xcc0f4002                                           // 000000DF36B0: CC0F4002
	v_mul_i32_i24_e32 v1, 0xe408, v7                           // 000000DF36B4: 12020EFF 0000E408
	v_or_b32_e32 v16, 0x64006400, v8                           // 000000DF36BC: 382010FF 64006400
	v_or_b32_e32 v17, 0x64006400, v9                           // 000000DF36C4: 382212FF 64006400
	v_perm_b32 v18, v1, v3, 0xc060c02                          // 000000DF36CC: D6440012 03FE0701 0C060C02
	ds_load_b128 v[6:9], v88 offset:10032                      // 000000DF36D8: DBFC2730 06000058
	s_waitcnt lgkmcnt(1)                                       // 000000DF36E0: BF89FC17
	v_dot2acc_f32_f16 v5, v2, v10                              // 000000DF36E4: 040A1502
	v_lshrrev_b32_e32 v2, 4, v4                                // 000000DF36E8: 32040884
	.long 0xcc0f400a                                           // 000000DF36EC: CC0F400A
	v_mul_i32_i24_e32 v1, 0xe408, v17                          // 000000DF36F0: 120222FF 0000E408
	v_or_b32_e32 v17, 0x64006400, v18                          // 000000DF36F8: 382224FF 64006400
	v_perm_b32 v1, v1, v3, 0xc070c03                           // 000000DF3700: D6440001 03FE0701 0C070C03
	v_and_b32_e32 v3, 0xf0f0f0f, v4                            // 000000DF370C: 360608FF 0F0F0F0F
	v_and_b32_e32 v2, 0xf0f0f0f, v2                            // 000000DF3714: 360404FF 0F0F0F0F
	.long 0xcc0f4004                                           // 000000DF371C: CC0F4004
	v_mul_i32_i24_e32 v1, 0xe408, v16                          // 000000DF3720: 120220FF 0000E408
	v_dot2acc_f32_f16 v5, v10, v11                             // 000000DF3728: 040A170A
	.long 0xcc0f400a                                           // 000000DF372C: CC0F400A
	v_mul_i32_i24_e32 v1, 0xe408, v17                          // 000000DF3730: 120222FF 0000E408
	v_or_b32_e32 v1, 0x64006400, v1                            // 000000DF3738: 380202FF 64006400
	v_perm_b32 v11, v2, v3, 0xc040c00                          // 000000DF3740: D644000B 03FE0702 0C040C00
	v_dot2acc_f32_f16 v27, v4, v22                             // 000000DF374C: 04362D04
	v_perm_b32 v4, v15, v14, 0xc060c02                         // 000000DF3750: D6440004 03FE1D0F 0C060C02
	v_dot2acc_f32_f16 v5, v10, v12                             // 000000DF375C: 040A190A
	.long 0xcc0f4001                                           // 000000DF3760: CC0F4001
	v_mul_i32_i24_e32 v1, 0xe408, v1                           // 000000DF3764: 120202FF 0000E408
	v_or_b32_e32 v10, 0x64006400, v11                          // 000000DF376C: 381416FF 64006400
	v_perm_b32 v11, v2, v3, 0xc050c01                          // 000000DF3774: D644000B 03FE0702 0C050C01
	v_or_b32_e32 v4, 0x64006400, v4                            // 000000DF3780: 380808FF 64006400
	v_perm_b32 v12, v15, v14, 0xc070c03                        // 000000DF3788: D644000C 03FE1D0F 0C070C03
	v_dot2acc_f32_f16 v5, v1, v13                              // 000000DF3794: 040A1B01
	.long 0xcc0f4001                                           // 000000DF3798: CC0F4001
	v_mul_i32_i24_e32 v1, 0xe408, v10                          // 000000DF379C: 120214FF 0000E408
	v_or_b32_e32 v10, 0x64006400, v11                          // 000000DF37A4: 381416FF 64006400
	v_perm_b32 v11, v2, v3, 0xc060c02                          // 000000DF37AC: D644000B 03FE0702 0C060C02
	.long 0xcc0f4004                                           // 000000DF37B8: CC0F4004
	v_mul_i32_i24_e32 v1, 0xe408, v4                           // 000000DF37BC: 120208FF 0000E408
	v_or_b32_e32 v12, 0x64006400, v12                          // 000000DF37C4: 381818FF 64006400
	s_waitcnt lgkmcnt(0)                                       // 000000DF37CC: BF89FC07
	v_dot2acc_f32_f16 v5, v1, v6                               // 000000DF37D0: 040A0D01
	.long 0xcc0f4001                                           // 000000DF37D4: CC0F4001
	v_mul_i32_i24_e32 v1, 0xe408, v10                          // 000000DF37D8: 120214FF 0000E408
	v_or_b32_e32 v6, 0x64006400, v11                           // 000000DF37E0: 380C16FF 64006400
	v_perm_b32 v2, v2, v3, 0xc070c03                           // 000000DF37E8: D6440002 03FE0702 0C070C03
	v_dot2acc_f32_f16 v27, v4, v23                             // 000000DF37F4: 04362F04
	.long 0xcc0f4003                                           // 000000DF37F8: CC0F4003
	v_mul_i32_i24_e32 v1, 0xe408, v12                          // 000000DF37FC: 120218FF 0000E408
	v_dot2acc_f32_f16 v5, v1, v7                               // 000000DF3804: 040A0F01
	.long 0xcc0f4001                                           // 000000DF3808: CC0F4001
	v_mul_i32_i24_e32 v1, 0xe408, v6                           // 000000DF380C: 12020CFF 0000E408
	v_or_b32_e32 v2, 0x64006400, v2                            // 000000DF3814: 380404FF 64006400
	v_fma_mix_f32 v4, v33, v36, v25 op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000DF381C: CC200804 0C664921
	v_dot2acc_f32_f16 v27, v3, v24                             // 000000DF3824: 04363103
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DF3828: BF870214
	v_dot2acc_f32_f16 v5, v1, v8                               // 000000DF382C: 040A1101
	.long 0xcc0f4001                                           // 000000DF3830: CC0F4001
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000DF3834: 120204FF 0000E408
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DF383C: BF870113
	v_fma_mix_f32 v2, v34, v27, v4 op_sel_hi:[1,0,0]           // 000000DF3840: CC200002 0C123722
	v_dot2acc_f32_f16 v5, v1, v9                               // 000000DF3848: 040A1301
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DF384C: BF870091
	v_fma_mix_f32 v1, v34, v5, v2 op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000DF3850: CC200801 0C0A0B22
	v_mov_b32_dpp v2, v1 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DF3858: 7E0402FA FF016101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DF3860: BF870091
	v_add_f32_e32 v1, v1, v2                                   // 000000DF3864: 06020501
	v_mov_b32_dpp v2, v1 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DF3868: 7E0402FA FF016201
	v_cmpx_eq_u32_e32 0, v87                                   // 000000DF3870: 7D94AE80
	s_cbranch_execz 17                                         // 000000DF3874: BFA50011 <_ZN7halogen12_GLOBAL__N_113k_i4r_rows_glILi1EEEvPKhlPKDF16_PKiPfS5_S5_PDF16_PjNS0_5I4rSdEi+0x5fbc>
	s_delay_alu instid0(VALU_DEP_2)                            // 000000DF3878: BF870002
	v_add_f32_e32 v3, v1, v2                                   // 000000DF387C: 06060501
	.long 0xd73c0001                                           // 000000DF3880: D73C0001
	v_cndmask_b32_e32 v1, 2, v81, vcc_lo                       // 000000DF3884: 0202A282
	s_mul_i32 s2, s9, 0x1400                                   // 000000DF3888: 9602FF09 00001400
	s_mul_hi_u32 s3, s9, 0x1400                                // 000000DF3890: 9683FF09 00001400
	s_add_u32 s2, s24, s2                                      // 000000DF3898: 80020218
	s_addc_u32 s3, s25, s3                                     // 000000DF389C: 82030319
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DF38A0: BF870091
	.long 0xd7006a01                                           // 000000DF38A4: D7006A01
	v_cndmask_b32_e32 v1, s2, v1, vcc_lo                       // 000000DF38A8: 02020202
	v_add_co_ci_u32_e64 v2, null, s3, v2, vcc_lo               // 000000DF38AC: D5207C02 01AA0403
	global_store_b32 v[1:2], v3, off                           // 000000DF38B4: DC6A0000 007C0301
	s_or_b32 exec_lo, exec_lo, s1                              // 000000DF38BC: 8C7E017E
	s_mul_hi_i32 s1, s0, 0x66666667                            // 000000DF38C0: 9701FF00 66666667
	s_waitcnt_vscnt null, 0x0                                  // 000000DF38C8: BC7C0000
	buffer_gl1_inv                                             // 000000DF38CC: E0B00000 00000000
	buffer_gl0_inv                                             // 000000DF38D4: E0AC0000 00000000
	s_lshr_b32 s2, s1, 31                                      // 000000DF38DC: 85029F01
	s_lshr_b32 s1, s1, 2                                       // 000000DF38E0: 85018201
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000DF38E4: BF870009
	s_add_i32 s1, s1, s2                                       // 000000DF38E8: 81010201
	s_mul_i32 s2, s9, 5                                        // 000000DF38EC: 96028509
	s_mul_i32 s1, s1, 10                                       // 000000DF38F0: 96018A01
	s_barrier                                                  // 000000DF38F4: BFBD0000
	s_sub_i32 s0, s0, s1                                       // 000000DF38F8: 81800100
	buffer_gl0_inv                                             // 000000DF38FC: E0AC0000 00000000
	s_bfe_u32 s1, s0, 0x10007                                  // 000000DF3904: 9301FF00 00010007
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000DF390C: BF870499
	s_add_i32 s0, s0, s1                                       // 000000DF3910: 81000100
	s_bfe_i32 s0, s0, 0x80000                                  // 000000DF3914: 9380FF00 00080000
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 000000DF391C: BF8704B9
	s_sext_i32_i16 s1, s0                                      // 000000DF3920: BE810F00
	.long 0xd44a0000                                           // 000000DF3924: D44A0000
	v_cndmask_b32_e32 v1, 0, v0, vcc_lo                        // 000000DF3928: 02020080
	s_ashr_i32 s1, s1, 1                                       // 000000DF392C: 86018101
	s_add_i32 s10, s2, s1                                      // 000000DF3930: 810A0102
	s_and_saveexec_b32 s2, s0                                  // 000000DF3934: BE822000
	s_cbranch_execz 29                                         // 000000DF3938: BFA5001D <_ZN7halogen12_GLOBAL__N_113k_i4r_rows_glILi1EEEvPKhlPKDF16_PKiPfS5_S5_PDF16_PjNS0_5I4rSdEi+0x60b0>
	s_mov_b32 s4, exec_lo                                      // 000000DF393C: BE84007E
	s_mov_b32 s3, exec_lo                                      // 000000DF3940: BE83007E
	.long 0xd71f0001                                           // 000000DF3944: D71F0001
	v_cndmask_b32_e32 v0, s4, v128, vcc_lo                     // 000000DF3948: 02010004
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DF394C: BF870001
	v_cmpx_eq_u32_e32 0, v1                                    // 000000DF3950: 7D940280
	s_cbranch_execz 11                                         // 000000DF3954: BFA5000B <_ZN7halogen12_GLOBAL__N_113k_i4r_rows_glILi1EEEvPKhlPKDF16_PKiPfS5_S5_PDF16_PjNS0_5I4rSdEi+0x6084>
	s_ashr_i32 s11, s10, 31                                    // 000000DF3958: 860B9F0A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000DF395C: BF870499
	s_lshl_b64 s[6:7], s[10:11], 2                             // 000000DF3960: 8486820A
	s_add_u32 s6, s12, s6                                      // 000000DF3964: 8006060C
	s_addc_u32 s7, s13, s7                                     // 000000DF3968: 8207070D
	s_bcnt1_i32_b32 s4, s4                                     // 000000DF396C: BE841804
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000DF3970: BF870009
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v3, s4              // 000000DF3974: CA100080 02020004
	global_atomic_add_u32 v2, v2, v3, s[6:7] glc               // 000000DF397C: DCD64000 02060302
	s_or_b32 exec_lo, exec_lo, s3                              // 000000DF3984: 8C7E037E
	s_waitcnt vmcnt(0)                                         // 000000DF3988: BF8903F7
	v_readfirstlane_b32 s3, v2                                 // 000000DF398C: 7E060502
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DF3990: BF870091
	v_dual_mov_b32 v2, 0 :: v_dual_add_nc_u32 v1, s3, v1       // 000000DF3994: CA200080 02000203
	v_cmp_eq_u32_e32 vcc_lo, 3, v1                             // 000000DF399C: 7C940283
	v_cndmask_b32_e64 v1, 0, 1, vcc_lo                         // 000000DF39A0: D5010001 01A90280
	ds_store_b32 v2, v1 offset:10244                           // 000000DF39A8: D8342804 00000102
	s_or_b32 exec_lo, exec_lo, s2                              // 000000DF39B0: 8C7E027E
	v_mov_b32_e32 v1, 0                                        // 000000DF39B4: 7E020280
	s_waitcnt lgkmcnt(0)                                       // 000000DF39B8: BF89FC07
	s_barrier                                                  // 000000DF39BC: BFBD0000
	buffer_gl0_inv                                             // 000000DF39C0: E0AC0000 00000000
	ds_load_b32 v1, v1 offset:10244                            // 000000DF39C8: D8D82804 01000001
	s_waitcnt lgkmcnt(0)                                       // 000000DF39D0: BF89FC07
	v_cmp_eq_u32_e32 vcc_lo, 0, v1                             // 000000DF39D4: 7C940280
	s_cbranch_vccnz 639                                        // 000000DF39D8: BFA4027F <_ZN7halogen12_GLOBAL__N_113k_i4r_rows_glILi1EEEvPKhlPKDF16_PKiPfS5_S5_PDF16_PjNS0_5I4rSdEi+0x6ad8>
	buffer_gl1_inv                                             // 000000DF39DC: E0B00000 00000000
	buffer_gl0_inv                                             // 000000DF39E4: E0AC0000 00000000
	s_mov_b32 s2, exec_lo                                      // 000000DF39EC: BE82007E
	v_cmpx_gt_u32_e32 32, v0                                   // 000000DF39F0: 7D9800A0
	s_cbranch_execz 632                                        // 000000DF39F4: BFA50278 <_ZN7halogen12_GLOBAL__N_113k_i4r_rows_glILi1EEEvPKhlPKDF16_PKiPfS5_S5_PDF16_PjNS0_5I4rSdEi+0x6ad8>
	s_mul_i32 s2, s9, 0x1400                                   // 000000DF39F8: 9602FF09 00001400
	s_mul_hi_u32 s3, s9, 0x1400                                // 000000DF3A00: 9683FF09 00001400
	s_add_u32 s4, s24, s2                                      // 000000DF3A08: 80040218
	s_addc_u32 s5, s25, s3                                     // 000000DF3A0C: 82050319
	s_lshl_b32 s14, s1, 7                                      // 000000DF3A10: 840E8701
	v_lshlrev_b32_e32 v1, 4, v0                                // 000000DF3A14: 30020084
	s_ashr_i32 s15, s14, 31                                    // 000000DF3A18: 860F9F0E
	s_mov_b32 s11, 0x76543210                                  // 000000DF3A1C: BE8B00FF 76543210
	s_lshl_b64 s[2:3], s[14:15], 2                             // 000000DF3A24: 8482820E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000DF3A28: BF870009
	s_add_u32 s2, s4, s2                                       // 000000DF3A2C: 80020204
	s_addc_u32 s3, s5, s3                                      // 000000DF3A30: 82030305
	s_clause 0x7                                               // 000000DF3A34: BF850007
	global_load_b32 v7, v1, s[2:3] glc                         // 000000DF3A38: DC524000 07020001
	global_load_b32 v8, v1, s[2:3] offset:2560 glc             // 000000DF3A40: DC524A00 08020001
	global_load_b32 v9, v1, s[2:3] offset:4 glc                // 000000DF3A48: DC524004 09020001
	global_load_b32 v10, v1, s[2:3] offset:2564 glc            // 000000DF3A50: DC524A04 0A020001
	global_load_b32 v11, v1, s[2:3] offset:8 glc               // 000000DF3A58: DC524008 0B020001
	global_load_b32 v12, v1, s[2:3] offset:2568 glc            // 000000DF3A60: DC524A08 0C020001
	global_load_b32 v13, v1, s[2:3] offset:12 glc              // 000000DF3A68: DC52400C 0D020001
	global_load_b32 v14, v1, s[2:3] offset:2572 glc            // 000000DF3A70: DC524A0C 0E020001
	v_lshl_or_b32 v1, v0, 2, s14                               // 000000DF3A78: D6560001 00390500
	v_and_b32_e32 v15, 1, v0                                   // 000000DF3A80: 361E0081
	v_and_b32_e32 v16, 2, v0                                   // 000000DF3A84: 36200082
	v_and_b32_e32 v17, 4, v0                                   // 000000DF3A88: 36220084
	v_and_b32_e32 v18, 8, v0                                   // 000000DF3A8C: 36240088
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000DF3A90: 3404029F
	.long 0xd44c0005                                           // 000000DF3A94: D44C0005
	v_cndmask_b32_e32 v1, 16, v0, vcc_lo                       // 000000DF3A98: 02020090
	v_lshlrev_b32_e32 v0, 3, v0                                // 000000DF3A9C: 30000083
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DF3AA0: BF870093
	.long 0xd73c0001                                           // 000000DF3AA4: D73C0001
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 000000DF3AA8: 02020281
	.long 0xd7006a03                                           // 000000DF3AAC: D7006A03
	v_cndmask_b32_e32 v1, s26, v1, vcc_lo                      // 000000DF3AB0: 0202021A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000DF3AB4: BF8700D1
	v_add_co_ci_u32_e64 v4, null, s27, v2, vcc_lo              // 000000DF3AB8: D5207C04 01AA041B
	s_clause 0x1                                               // 000000DF3AC0: BF850001
	global_load_b64 v[5:6], v[3:4], off                        // 000000DF3AC4: DC560000 057C0003
	global_load_b64 v[3:4], v[3:4], off offset:1280            // 000000DF3ACC: DC560500 037C0003
	.long 0xd7006a01                                           // 000000DF3AD4: D7006A01
	v_cndmask_b32_e32 v1, s28, v1, vcc_lo                      // 000000DF3AD8: 0202021C
	v_add_co_ci_u32_e64 v2, null, s29, v2, vcc_lo              // 000000DF3ADC: D5207C02 01AA041D
	global_load_b64 v[1:2], v[1:2], off                        // 000000DF3AE4: DC560000 017C0001
	s_waitcnt vmcnt(8)                                         // 000000DF3AEC: BF8923F7
	v_add_f32_e32 v19, v7, v9                                  // 000000DF3AF0: 06261307
	v_sub_f32_e32 v7, v7, v9                                   // 000000DF3AF4: 080E1307
	.long 0xd44a0002                                           // 000000DF3AF8: D44A0002
	v_cndmask_b32_e32 v1, 0, v16, vcc_lo                       // 000000DF3AFC: 02022080
	.long 0xd44a0004                                           // 000000DF3B00: D44A0004
	v_cndmask_b32_e32 v1, 0, v18, vcc_lo                       // 000000DF3B04: 02022480
	s_waitcnt vmcnt(4)                                         // 000000DF3B08: BF8913F7
	v_add_f32_e32 v9, v11, v13                                 // 000000DF3B0C: 06121B0B
	v_sub_f32_e32 v11, v11, v13                                // 000000DF3B10: 08161B0B
	v_add_f32_e32 v13, v8, v10                                 // 000000DF3B14: 061A1508
	v_sub_f32_e32 v8, v8, v10                                  // 000000DF3B18: 08101508
	s_waitcnt vmcnt(3)                                         // 000000DF3B1C: BF890FF7
	v_add_f32_e32 v10, v12, v14                                // 000000DF3B20: 06141D0C
	v_sub_f32_e32 v12, v12, v14                                // 000000DF3B24: 08181D0C
	.long 0xd44a0001                                           // 000000DF3B28: D44A0001
	v_cndmask_b32_e32 v1, 0, v15, vcc_lo                       // 000000DF3B2C: 02021E80
	.long 0xd44a0003                                           // 000000DF3B30: D44A0003
	v_cndmask_b32_e32 v1, 0, v17, vcc_lo                       // 000000DF3B34: 02022280
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000DF3B38: BF870133
	v_add_f32_e32 v15, v8, v12                                 // 000000DF3B3C: 061E1908
	v_sub_f32_e32 v8, v8, v12                                  // 000000DF3B40: 08101908
	v_add_f32_e32 v20, v7, v11                                 // 000000DF3B44: 06281707
	v_mov_b32_dpp v25, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DF3B48: 7E3202FA FF016108
	v_cndmask_b32_e64 v8, -v8, v8, s1                          // 000000DF3B50: D5010008 20061108
	v_sub_f32_e32 v7, v7, v11                                  // 000000DF3B58: 080E1707
	v_add_f32_e32 v11, v13, v10                                // 000000DF3B5C: 0616150D
	v_sub_f32_e32 v10, v13, v10                                // 000000DF3B60: 0814150D
	v_add_f32_e32 v14, v19, v9                                 // 000000DF3B64: 061C1313
	v_add_f32_e32 v8, v8, v25                                  // 000000DF3B68: 06103308
	v_mov_b32_dpp v21, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DF3B6C: 7E2A02FA FF016107
	v_mov_b32_dpp v22, v11 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DF3B74: 7E2C02FA FF01610B
	v_mov_b32_dpp v24, v10 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DF3B7C: 7E3002FA FF01610A
	v_mov_b32_dpp v12, v14 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DF3B84: 7E1802FA FF01610E
	v_cndmask_b32_e64 v13, -v14, v14, s1                       // 000000DF3B8C: D501000D 20061D0E
	v_mov_b32_dpp v14, v20 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DF3B94: 7E1C02FA FF016114
	v_cndmask_b32_e64 v10, -v10, v10, s1                       // 000000DF3B9C: D501000A 2006150A
	v_sub_f32_e32 v9, v19, v9                                  // 000000DF3BA4: 08121313
	v_cndmask_b32_e64 v19, -v20, v20, s1                       // 000000DF3BA8: D5010013 20062914
	v_cndmask_b32_e64 v11, -v11, v11, s1                       // 000000DF3BB0: D501000B 2006170B
	v_cndmask_b32_e64 v7, -v7, v7, s1                          // 000000DF3BB8: D5010007 20060F07
	v_add_f32_e32 v10, v10, v24                                // 000000DF3BC0: 0614310A
	v_mov_b32_dpp v20, v9 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DF3BC4: 7E2802FA FF016109
	v_cndmask_b32_e64 v9, -v9, v9, s1                          // 000000DF3BCC: D5010009 20061309
	v_add_f32_e32 v14, v19, v14                                // 000000DF3BD4: 061C1D13
	v_mov_b32_dpp v23, v15 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DF3BD8: 7E2E02FA FF01610F
	v_cndmask_b32_e64 v15, -v15, v15, s1                       // 000000DF3BE0: D501000F 20061F0F
	v_dual_add_f32 v11, v11, v22 :: v_dual_add_f32 v12, v13, v12// 000000DF3BE8: C9082D0B 0B0C190D
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DF3BF0: BF870004
	v_mov_b32_dpp v22, v14 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DF3BF4: 7E2C02FA FF01620E
	v_cndmask_b32_e64 v14, -v14, v14, s2                       // 000000DF3BFC: D501000E 200A1D0E
	v_add_f32_e32 v9, v9, v20                                  // 000000DF3C04: 06122909
	v_mov_b32_dpp v20, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DF3C08: 7E2802FA FF016208
	v_cndmask_b32_e64 v8, -v8, v8, s2                          // 000000DF3C10: D5010008 200A1108
	v_add_f32_e32 v15, v15, v23                                // 000000DF3C18: 061E2F0F
	v_mov_b32_dpp v13, v11 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DF3C1C: 7E1A02FA FF01620B
	v_cndmask_b32_e64 v11, -v11, v11, s2                       // 000000DF3C24: D501000B 200A170B
	v_mov_b32_dpp v19, v10 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DF3C2C: 7E2602FA FF01620A
	v_cndmask_b32_e64 v10, -v10, v10, s2                       // 000000DF3C34: D501000A 200A150A
	v_add_f32_e32 v7, v7, v21                                  // 000000DF3C3C: 060E2B07
	v_mov_b32_dpp v21, v12 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DF3C40: 7E2A02FA FF01620C
	v_cndmask_b32_e64 v12, -v12, v12, s2                       // 000000DF3C48: D501000C 200A190C
	v_add_f32_e32 v8, v8, v20                                  // 000000DF3C50: 06102908
	v_mov_b32_dpp v16, v15 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DF3C54: 7E2002FA FF01620F
	v_cndmask_b32_e64 v15, -v15, v15, s2                       // 000000DF3C5C: D501000F 200A1F0F
	v_add_f32_e32 v10, v10, v19                                // 000000DF3C64: 0614270A
	v_mov_b32_dpp v24, v7 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DF3C68: 7E3002FA FF016207
	v_cndmask_b32_e64 v7, -v7, v7, s2                          // 000000DF3C70: D5010007 200A0F07
	v_add_f32_e32 v14, v14, v22                                // 000000DF3C78: 061C2D0E
	v_add_f32_e32 v12, v12, v21                                // 000000DF3C7C: 06182B0C
	v_mov_b32_dpp v19, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DF3C80: 7E2602FA FF016408
	v_cndmask_b32_e64 v8, -v8, v8, s3                          // 000000DF3C88: D5010008 200E1108
	v_add_f32_e32 v11, v11, v13                                // 000000DF3C90: 06161B0B
	v_add_f32_e32 v13, v15, v16                                // 000000DF3C94: 061A210F
	v_mov_b32_dpp v23, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DF3C98: 7E2E02FA FF016209
	v_cndmask_b32_e64 v9, -v9, v9, s2                          // 000000DF3CA0: D5010009 200A1309
	v_mov_b32_dpp v17, v10 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DF3CA8: 7E2202FA FF01640A
	v_cndmask_b32_e64 v10, -v10, v10, s3                       // 000000DF3CB0: D501000A 200E150A
	v_add_f32_e32 v7, v7, v24                                  // 000000DF3CB8: 060E3107
	v_mov_b32_dpp v20, v12 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DF3CBC: 7E2802FA FF01640C
	v_mov_b32_dpp v21, v14 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DF3CC4: 7E2A02FA FF01640E
	v_cndmask_b32_e64 v14, -v14, v14, s3                       // 000000DF3CCC: D501000E 200E1D0E
	v_cndmask_b32_e64 v12, -v12, v12, s3                       // 000000DF3CD4: D501000C 200E190C
	v_add_f32_e32 v8, v8, v19                                  // 000000DF3CDC: 06102708
	v_mov_b32_dpp v15, v11 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DF3CE0: 7E1E02FA FF01640B
	v_cndmask_b32_e64 v11, -v11, v11, s3                       // 000000DF3CE8: D501000B 200E170B
	v_dual_add_f32 v9, v9, v23 :: v_dual_add_f32 v14, v14, v21 // 000000DF3CF0: C9082F09 090E2B0E
	v_mov_b32_dpp v16, v13 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DF3CF8: 7E2002FA FF01640D
	v_cndmask_b32_e64 v13, -v13, v13, s3                       // 000000DF3D00: D501000D 200E1B0D
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DF3D08: BF870004
	v_dual_add_f32 v11, v11, v15 :: v_dual_add_f32 v12, v12, v20// 000000DF3D0C: C9081F0B 0B0C290C
	v_add_f32_e32 v10, v10, v17                                // 000000DF3D14: 0614230A
	v_mov_b32_dpp v23, v7 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DF3D18: 7E2E02FA FF016407
	v_cndmask_b32_e64 v7, -v7, v7, s3                          // 000000DF3D20: D5010007 200E0F07
	v_mov_b32_dpp v22, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DF3D28: 7E2C02FA FF016409
	v_cndmask_b32_e64 v9, -v9, v9, s3                          // 000000DF3D30: D5010009 200E1309
	v_mov_b32_dpp v17, v10 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DF3D38: 7E2202FA FF01680A
	v_cndmask_b32_e64 v10, -v10, v10, s4                       // 000000DF3D40: D501000A 2012150A
	v_add_f32_e32 v13, v13, v16                                // 000000DF3D48: 061A210D
	v_mov_b32_dpp v19, v12 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DF3D4C: 7E2602FA FF01680C
	v_mov_b32_dpp v20, v14 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DF3D54: 7E2802FA FF01680E
	v_cndmask_b32_e64 v14, -v14, v14, s4                       // 000000DF3D5C: D501000E 20121D0E
	v_add_f32_e32 v7, v7, v23                                  // 000000DF3D64: 060E2F07
	v_cndmask_b32_e64 v12, -v12, v12, s4                       // 000000DF3D68: D501000C 2012190C
	v_add_f32_e32 v9, v9, v22                                  // 000000DF3D70: 06122D09
	v_mov_b32_dpp v15, v11 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DF3D74: 7E1E02FA FF01680B
	v_cndmask_b32_e64 v11, -v11, v11, s4                       // 000000DF3D7C: D501000B 2012170B
	v_add_f32_e32 v10, v10, v17                                // 000000DF3D84: 0614230A
	v_mov_b32_dpp v16, v13 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DF3D88: 7E2002FA FF01680D
	v_cndmask_b32_e64 v13, -v13, v13, s4                       // 000000DF3D90: D501000D 20121B0D
	v_add_f32_e32 v12, v12, v19                                // 000000DF3D98: 0618270C
	v_add_f32_e32 v14, v14, v20                                // 000000DF3D9C: 061C290E
	v_mov_b32_dpp v22, v7 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DF3DA0: 7E2C02FA FF016807
	v_cndmask_b32_e64 v7, -v7, v7, s4                          // 000000DF3DA8: D5010007 20120F07
	v_add_f32_e32 v11, v11, v15                                // 000000DF3DB0: 06161F0B
	v_mov_b32_dpp v21, v9 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DF3DB4: 7E2A02FA FF016809
	v_cndmask_b32_e64 v9, -v9, v9, s4                          // 000000DF3DBC: D5010009 20121309
	v_mov_b32_dpp v18, v8 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DF3DC4: 7E2402FA FF016808
	v_add_f32_e32 v7, v7, v22                                  // 000000DF3DCC: 060E2D07
	v_dual_add_f32 v13, v13, v16 :: v_dual_mov_b32 v16, v12    // 000000DF3DD0: C910210D 0D10010C
	v_cndmask_b32_e64 v12, -v12, v12, s5                       // 000000DF3DD8: D501000C 2016190C
	v_cndmask_b32_e64 v8, -v8, v8, s4                          // 000000DF3DE0: D5010008 20121108
	v_add_f32_e32 v9, v9, v21                                  // 000000DF3DE8: 06122B09
	v_cndmask_b32_e64 v15, -v11, v11, s5                       // 000000DF3DEC: D501000F 2016170B
	v_permlanex16_b32 v16, v16, s11, 0xfedcba98                // 000000DF3DF4: D65C0010 03FC1710 FEDCBA98
	v_permlanex16_b32 v11, v11, s11, 0xfedcba98                // 000000DF3E00: D65C000B 03FC170B FEDCBA98
	v_add_f32_e32 v8, v8, v18                                  // 000000DF3E0C: 06102508
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000DF3E10: BF870243
	v_dual_add_f32 v12, v12, v16 :: v_dual_mov_b32 v17, v14    // 000000DF3E14: C910210C 0C10010E
	v_cndmask_b32_e64 v14, -v14, v14, s5                       // 000000DF3E1C: D501000E 20161D0E
	v_mov_b32_e32 v20, v7                                      // 000000DF3E24: 7E280307
	v_cndmask_b32_e64 v7, -v7, v7, s5                          // 000000DF3E28: D5010007 20160F07
	v_mul_f32_e32 v12, 0x3db504f3, v12                         // 000000DF3E30: 101818FF 3DB504F3
	v_permlanex16_b32 v17, v17, s11, 0xfedcba98                // 000000DF3E38: D65C0011 03FC1711 FEDCBA98
	v_mov_b32_e32 v19, v9                                      // 000000DF3E44: 7E260309
	v_cndmask_b32_e64 v9, -v9, v9, s5                          // 000000DF3E48: D5010009 20161309
	v_permlanex16_b32 v20, v20, s11, 0xfedcba98                // 000000DF3E50: D65C0014 03FC1714 FEDCBA98
	s_waitcnt vmcnt(2)                                         // 000000DF3E5C: BF890BF7
	v_fma_mix_f32 v12, v5, v12, neg(0) op_sel_hi:[1,0,0]       // 000000DF3E60: CC20000C 8A021905
	v_add_f32_e32 v14, v14, v17                                // 000000DF3E68: 061C230E
	v_permlanex16_b32 v19, v19, s11, 0xfedcba98                // 000000DF3E6C: D65C0013 03FC1713 FEDCBA98
	v_dual_mov_b32 v16, v13 :: v_dual_add_f32 v7, v7, v20      // 000000DF3E78: CA08010D 10062907
	v_mov_b32_e32 v20, v8                                      // 000000DF3E80: 7E280308
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000DF3E84: BF870233
	v_dual_mul_f32 v14, 0x3db504f3, v14 :: v_dual_add_f32 v9, v9, v19// 000000DF3E88: C8C81CFF 0E082709 3DB504F3
	v_mov_b32_e32 v19, v10                                     // 000000DF3E94: 7E26030A
	v_cndmask_b32_e64 v8, -v8, v8, s5                          // 000000DF3E98: D5010008 20161108
	v_permlanex16_b32 v20, v20, s11, 0xfedcba98                // 000000DF3EA0: D65C0014 03FC1714 FEDCBA98
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DF3EAC: BF870004
	v_fma_mix_f32 v5, v5, v14, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000DF3EB0: CC200805 8A021D05
	v_mul_f32_e32 v9, 0x3db504f3, v9                           // 000000DF3EB8: 101212FF 3DB504F3
	v_cndmask_b32_e64 v10, -v10, v10, s5                       // 000000DF3EC0: D501000A 2016150A
	v_permlanex16_b32 v19, v19, s11, 0xfedcba98                // 000000DF3EC8: D65C0013 03FC1713 FEDCBA98
	v_add_f32_e32 v8, v8, v20                                  // 000000DF3ED4: 06102908
	v_mul_f32_e32 v14, 0xbfb8aa3b, v5                          // 000000DF3ED8: 101C0AFF BFB8AA3B
	v_fma_mix_f32 v9, v6, v9, neg(0) op_sel_hi:[1,0,0]         // 000000DF3EE0: CC200009 8A021306
	v_permlanex16_b32 v16, v16, s11, 0xfedcba98                // 000000DF3EE8: D65C0010 03FC1710 FEDCBA98
	v_add_f32_e32 v10, v10, v19                                // 000000DF3EF4: 0614270A
	v_mul_f32_e32 v8, 0x3db504f3, v8                           // 000000DF3EF8: 101010FF 3DB504F3
	v_exp_f32_e32 v14, v14                                     // 000000DF3F00: 7E1C4B0E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000DF3F04: BF870292
	v_dual_mul_f32 v7, 0x3db504f3, v7 :: v_dual_mul_f32 v10, 0x3db504f3, v10// 000000DF3F08: C8C60EFF 070A14FF 3DB504F3
	v_add_f32_e32 v14, 1.0, v14                                // 000000DF3F14: 061C1CF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000DF3F18: BF870232
	v_fma_mix_f32 v6, v6, v7, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000DF3F1C: CC200806 8A020F06
	v_cndmask_b32_e64 v7, -v13, v13, s5                        // 000000DF3F24: D5010007 20161B0D
	v_mul_f32_e32 v13, 0xbfb8aa3b, v12                         // 000000DF3F2C: 101A18FF BFB8AA3B
	v_div_scale_f32 v22, null, v14, v14, v5                    // 000000DF3F34: D6FC7C16 04161D0E
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000DF3F3C: BF870224
	v_mul_f32_e32 v18, 0xbfb8aa3b, v6                          // 000000DF3F40: 10240CFF BFB8AA3B
	v_div_scale_f32 v19, s6, v5, v14, v5                       // 000000DF3F48: D6FC0613 04161D05
	v_exp_f32_e32 v13, v13                                     // 000000DF3F50: 7E1A4B0D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DF3F54: BF870113
	v_rcp_f32_e32 v25, v22                                     // 000000DF3F58: 7E325516
	v_exp_f32_e32 v18, v18                                     // 000000DF3F5C: 7E244B12
	v_mul_f32_e32 v17, 0xbfb8aa3b, v9                          // 000000DF3F60: 102212FF BFB8AA3B
	s_delay_alu instid0(TRANS32_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 000000DF3F68: BF870317
	v_add_f32_e32 v13, 1.0, v13                                // 000000DF3F6C: 061A1AF2
	v_fma_f32 v29, -v22, v25, 1.0                              // 000000DF3F70: D613001D 23CA3316
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DF3F78: BF870215
	v_add_f32_e32 v18, 1.0, v18                                // 000000DF3F7C: 062424F2
	v_exp_f32_e32 v17, v17                                     // 000000DF3F80: 7E224B11
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DF3F84: BF870113
	v_div_scale_f32 v21, null, v13, v13, v12                   // 000000DF3F88: D6FC7C15 04321B0D
	v_div_scale_f32 v24, null, v18, v18, v6                    // 000000DF3F90: D6FC7C18 041A2512
	v_div_scale_f32 v32, s8, v6, v18, v6                       // 000000DF3F98: D6FC0820 041A2506
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 000000DF3FA0: BF870312
	v_rcp_f32_e32 v27, v24                                     // 000000DF3FA4: 7E365518
	v_add_f32_e32 v17, 1.0, v17                                // 000000DF3FA8: 062222F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(TRANS32_DEP_1)// 000000DF3FAC: BF8702A1
	v_div_scale_f32 v23, null, v17, v17, v9                    // 000000DF3FB0: D6FC7C17 04262311
	v_div_scale_f32 v20, s7, v9, v17, v9                       // 000000DF3FB8: D6FC0714 04262309
	v_fma_f32 v31, -v24, v27, 1.0                              // 000000DF3FC0: D613001F 23CA3718
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DF3FC8: BF870093
	v_rcp_f32_e32 v26, v23                                     // 000000DF3FCC: 7E345517
	v_fmac_f32_e32 v27, v31, v27                               // 000000DF3FD0: 5636371F
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000DF3FD4: BF870135
	v_fma_f32 v30, -v23, v26, 1.0                              // 000000DF3FD8: D613001E 23CA3517
	v_add_f32_e32 v11, v15, v11                                // 000000DF3FE0: 0616170F
	v_rcp_f32_e32 v15, v21                                     // 000000DF3FE4: 7E1E5515
	v_dual_fmac_f32 v26, v30, v26 :: v_dual_fmac_f32 v25, v29, v25// 000000DF3FE8: C800351E 1A18331D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000DF3FF0: BF870291
	v_mul_f32_e32 v30, v20, v26                                // 000000DF3FF4: 103C3514
	v_fma_f32 v28, -v21, v15, 1.0                              // 000000DF3FF8: D613001C 23CA1F15
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000DF4000: BF8701A2
	v_fma_f32 v35, -v23, v30, v20                              // 000000DF4004: D6130023 24523D17
	v_mul_f32_e32 v11, 0x3db504f3, v11                         // 000000DF400C: 101616FF 3DB504F3
	v_fmac_f32_e32 v15, v28, v15                               // 000000DF4014: 561E1F1C
	v_add_f32_e32 v7, v7, v16                                  // 000000DF4018: 060E2107
	v_div_scale_f32 v16, vcc_lo, v12, v13, v12                 // 000000DF401C: D6FC6A10 04321B0C
	v_fmac_f32_e32 v30, v35, v26                               // 000000DF4024: 563C3523
	s_waitcnt vmcnt(1)                                         // 000000DF4028: BF8907F7
	v_fma_mix_f32 v11, v3, v11, neg(0) op_sel_hi:[1,0,0]       // 000000DF402C: CC20000B 8A021703
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DF4034: BF870193
	v_mul_f32_e32 v28, v16, v15                                // 000000DF4038: 10381F10
	v_fma_f32 v20, -v23, v30, v20                              // 000000DF403C: D6130014 24523D17
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DF4044: BF870092
	v_fma_f32 v33, -v21, v28, v16                              // 000000DF4048: D6130021 24423915
	v_dual_mul_f32 v29, v19, v25 :: v_dual_fmac_f32 v28, v33, v15// 000000DF4050: C8C03313 1D1C1F21
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DF4058: BF870111
	v_fma_f32 v34, -v22, v29, v19                              // 000000DF405C: D6130022 244E3B16
	v_fma_f32 v16, -v21, v28, v16                              // 000000DF4064: D6130010 24423915
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DF406C: BF870112
	v_fmac_f32_e32 v29, v34, v25                               // 000000DF4070: 563A3322
	v_div_fmas_f32 v15, v16, v15, v28                          // 000000DF4074: D637000F 04721F10
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DF407C: BF8700A2
	v_fma_f32 v19, -v22, v29, v19                              // 000000DF4080: D6130013 244E3B16
	s_mov_b32 vcc_lo, s6                                       // 000000DF4088: BEEA0006
	v_div_fmas_f32 v16, v19, v25, v29                          // 000000DF408C: D6370010 04763313
	s_mov_b32 vcc_lo, s7                                       // 000000DF4094: BEEA0007
	v_div_fmas_f32 v19, v20, v26, v30                          // 000000DF4098: D6370013 047A3514
	s_mov_b32 vcc_lo, s8                                       // 000000DF40A0: BEEA0008
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DF40A4: BF870112
	v_div_fixup_f32 v5, v16, v14, v5                           // 000000DF40A8: D6270005 04161D10
	v_div_fixup_f32 v9, v19, v17, v9                           // 000000DF40B0: D6270009 04262313
	v_mul_f32_e32 v7, 0x3db504f3, v7                           // 000000DF40B8: 100E0EFF 3DB504F3
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DF40C0: BF870001
	v_fma_mix_f32 v3, v3, v7, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000DF40C4: CC200803 8A020F03
	v_fma_mix_f32 v7, v4, v8, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000DF40CC: CC200807 8A021104
	v_div_fixup_f32 v8, v15, v13, v12                          // 000000DF40D4: D6270008 04321B0F
	v_mul_f32_e32 v31, v32, v27                                // 000000DF40DC: 103E3720
	v_fma_mix_f32 v4, v4, v10, neg(0) op_sel_hi:[1,0,0]        // 000000DF40E0: CC200004 8A021504
	v_mul_f32_e32 v3, v3, v5                                   // 000000DF40E8: 10060B03
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DF40EC: BF870193
	v_fma_f32 v36, -v24, v31, v32                              // 000000DF40F0: D6130024 24823F18
	v_mul_f32_e32 v4, v4, v9                                   // 000000DF40F8: 10081304
	s_waitcnt vmcnt(0)                                         // 000000DF40FC: BF8903F7
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DF4100: BF870193
	v_fma_mix_f32 v3, v1, v3, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000DF4104: CC200803 8A020701
	v_fmac_f32_e32 v31, v36, v27                               // 000000DF410C: 563E3724
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DF4110: BF870091
	v_fma_f32 v21, -v24, v31, v32                              // 000000DF4114: D6130015 24823F18
	v_div_fmas_f32 v20, v21, v27, v31                          // 000000DF411C: D6370014 047E3715
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DF4124: BF870091
	v_div_fixup_f32 v6, v20, v18, v6                           // 000000DF4128: D6270006 041A2514
	v_mul_f32_e32 v5, v7, v6                                   // 000000DF4130: 100A0D07
	v_mul_f32_e32 v6, v11, v8                                  // 000000DF4134: 100C110B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DF4138: BF870112
	v_fma_mix_f32 v5, v2, v5, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000DF413C: CC200805 8A020B02
	v_fma_mix_f32 v7, v6, v1, v3 op_sel_hi:[0,1,0]             // 000000DF4144: CC200007 140E0306
	v_fma_mix_f32 v1, v6, v1, -v3 op_sel_hi:[0,1,0]            // 000000DF414C: CC200001 940E0306
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DF4154: BF8700A3
	v_fma_mix_f32 v8, v4, v2, v5 op_sel_hi:[0,1,0]             // 000000DF4158: CC200008 14160504
	v_fma_mix_f32 v2, v4, v2, -v5 op_sel_hi:[0,1,0]            // 000000DF4160: CC200002 94160504
	v_dual_add_f32 v3, v7, v8 :: v_dual_add_f32 v4, v1, v2     // 000000DF4168: C9081107 03040501
	v_sub_f32_e32 v5, v7, v8                                   // 000000DF4170: 080A1107
	v_sub_f32_e32 v1, v1, v2                                   // 000000DF4174: 08020501
	s_delay_alu instid0(VALU_DEP_3)                            // 000000DF4178: BF870003
	v_mov_b32_dpp v2, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DF417C: 7E0402FA FF016103
	v_cndmask_b32_e64 v3, -v3, v3, s1                          // 000000DF4184: D5010003 20060703
	v_mov_b32_dpp v6, v4 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DF418C: 7E0C02FA FF016104
	v_cndmask_b32_e64 v4, -v4, v4, s1                          // 000000DF4194: D5010004 20060904
	v_mov_b32_dpp v7, v5 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DF419C: 7E0E02FA FF016105
	v_cndmask_b32_e64 v5, -v5, v5, s1                          // 000000DF41A4: D5010005 20060B05
	v_add_f32_e32 v2, v3, v2                                   // 000000DF41AC: 06040503
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DF41B0: BF870112
	v_dual_add_f32 v3, v4, v6 :: v_dual_add_f32 v4, v5, v7     // 000000DF41B4: C9080D04 03040F05
	v_mov_b32_dpp v5, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DF41BC: 7E0A02FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, s2                          // 000000DF41C4: D5010002 200A0502
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000DF41CC: BF8701A3
	v_mov_b32_dpp v7, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DF41D0: 7E0E02FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, s2                          // 000000DF41D8: D5010004 200A0904
	v_add_f32_e32 v2, v2, v5                                   // 000000DF41E0: 06040B02
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DF41E4: BF870112
	v_add_f32_e32 v4, v4, v7                                   // 000000DF41E8: 06080F04
	v_mov_b32_dpp v5, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DF41EC: 7E0A02FA FF016402
	v_cndmask_b32_e64 v2, -v2, v2, s3                          // 000000DF41F4: D5010002 200E0502
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000DF41FC: BF8701A3
	v_mov_b32_dpp v7, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DF4200: 7E0E02FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s3                          // 000000DF4208: D5010004 200E0904
	v_add_f32_e32 v2, v2, v5                                   // 000000DF4210: 06040B02
	v_mov_b32_dpp v8, v1 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DF4214: 7E1002FA FF016101
	v_cndmask_b32_e64 v1, -v1, v1, s1                          // 000000DF421C: D5010001 20060301
	s_mov_b32 s1, 0x3db504f3                                   // 000000DF4224: BE8100FF 3DB504F3
	v_add_f32_e32 v4, v4, v7                                   // 000000DF422C: 06080F04
	v_mov_b32_dpp v5, v2 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DF4230: 7E0A02FA FF016802
	v_cndmask_b32_e64 v2, -v2, v2, s4                          // 000000DF4238: D5010002 20120502
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000DF4240: BF8701A3
	v_mov_b32_dpp v7, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DF4244: 7E0E02FA FF016804
	v_cndmask_b32_e64 v4, -v4, v4, s4                          // 000000DF424C: D5010004 20120904
	v_dual_add_f32 v1, v1, v8 :: v_dual_add_f32 v2, v2, v5     // 000000DF4254: C9081101 01020B02
	v_mov_b32_dpp v6, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DF425C: 7E0C02FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, s2                          // 000000DF4264: D5010003 200A0703
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DF426C: BF870214
	v_add_f32_e32 v4, v4, v7                                   // 000000DF4270: 06080F04
	v_mov_b32_dpp v8, v1 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DF4274: 7E1002FA FF016201
	v_cndmask_b32_e64 v1, -v1, v1, s2                          // 000000DF427C: D5010001 200A0301
	v_mov_b32_e32 v5, v2                                       // 000000DF4284: 7E0A0302
	v_cndmask_b32_e64 v2, -v2, v2, s5                          // 000000DF4288: D5010002 20160502
	v_mov_b32_e32 v7, v4                                       // 000000DF4290: 7E0E0304
	v_cndmask_b32_e64 v4, -v4, v4, s5                          // 000000DF4294: D5010004 20160904
	v_add_f32_e32 v1, v1, v8                                   // 000000DF429C: 06021101
	v_permlanex16_b32 v5, v5, s11, 0xfedcba98                  // 000000DF42A0: D65C0005 03FC1705 FEDCBA98
	s_mul_hi_u32 s2, s9, 0x500                                 // 000000DF42AC: 9682FF09 00000500
	v_permlanex16_b32 v7, v7, s11, 0xfedcba98                  // 000000DF42B4: D65C0007 03FC1707 FEDCBA98
	s_mulk_i32 s9, 0x500                                       // 000000DF42C0: B8090500
	v_mov_b32_dpp v8, v1 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DF42C4: 7E1002FA FF016401
	v_cndmask_b32_e64 v1, -v1, v1, s3                          // 000000DF42CC: D5010001 200E0301
	v_add_f32_e32 v2, v2, v5                                   // 000000DF42D4: 06040B02
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DF42D8: BF870092
	v_dual_add_f32 v4, v4, v7 :: v_dual_add_f32 v1, v1, v8     // 000000DF42DC: C9080F04 04001101
	v_mov_b32_dpp v8, v1 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DF42E4: 7E1002FA FF016801
	v_cndmask_b32_e64 v1, -v1, v1, s4                          // 000000DF42EC: D5010001 20120301
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DF42F4: BF870091
	v_add_f32_e32 v1, v1, v8                                   // 000000DF42F8: 06021101
	v_dual_add_f32 v3, v3, v6 :: v_dual_mov_b32 v8, v1         // 000000DF42FC: C9100D03 03080101
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000DF4304: BF870231
	v_mov_b32_dpp v6, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DF4308: 7E0C02FA FF016403
	v_cndmask_b32_e64 v3, -v3, v3, s3                          // 000000DF4310: D5010003 200E0703
	v_cndmask_b32_e64 v1, -v1, v1, s5                          // 000000DF4318: D5010001 20160301
	v_permlanex16_b32 v8, v8, s11, 0xfedcba98                  // 000000DF4320: D65C0008 03FC1708 FEDCBA98
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DF432C: BF870113
	v_add_f32_e32 v3, v3, v6                                   // 000000DF4330: 06060D03
	v_add_f32_e32 v5, v1, v8                                   // 000000DF4334: 060A1101
	v_fma_mixlo_f16 v1, v2, s1, 0                              // 000000DF4338: CC210001 02000302
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_3)// 000000DF4340: BF8701D3
	v_mov_b32_dpp v6, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DF4344: 7E0C02FA FF016803
	v_cndmask_b32_e64 v3, -v3, v3, s4                          // 000000DF434C: D5010003 20120703
	s_add_u32 s4, s30, s9                                      // 000000DF4354: 8004091E
	v_fma_mixlo_f16 v2, v4, s1, 0                              // 000000DF4358: CC210002 02000304
	v_fma_mixhi_f16 v2, v5, s1, 0                              // 000000DF4360: CC220002 02000305
	v_add_f32_e32 v3, v3, v6                                   // 000000DF4368: 06060D03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000DF436C: BF870141
	v_mov_b32_e32 v6, v3                                       // 000000DF4370: 7E0C0303
	v_cndmask_b32_e64 v3, -v3, v3, s5                          // 000000DF4374: D5010003 20160703
	s_addc_u32 s5, s31, s2                                     // 000000DF437C: 8205021F
	s_lshl_b64 s[2:3], s[14:15], 1                             // 000000DF4380: 8482810E
	v_permlanex16_b32 v6, v6, s11, 0xfedcba98                  // 000000DF4384: D65C0006 03FC1706 FEDCBA98
	s_add_u32 s2, s4, s2                                       // 000000DF4390: 80020204
	s_addc_u32 s3, s5, s3                                      // 000000DF4394: 82030305
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DF4398: BF870091
	v_add_f32_e32 v3, v3, v6                                   // 000000DF439C: 06060D03
	v_fma_mixhi_f16 v1, v3, s1, 0                              // 000000DF43A0: CC220001 02000303
	global_store_b64 v0, v[1:2], s[2:3]                        // 000000DF43A8: DC6E0000 00020100
	s_and_b32 exec_lo, exec_lo, s0                             // 000000DF43B0: 8B7E007E
	s_cbranch_execz 8                                          // 000000DF43B4: BFA50008 <_ZN7halogen12_GLOBAL__N_113k_i4r_rows_glILi1EEEvPKhlPKDF16_PKiPfS5_S5_PDF16_PjNS0_5I4rSdEi+0x6ad8>
	s_ashr_i32 s11, s10, 31                                    // 000000DF43B8: 860B9F0A
	v_mov_b32_e32 v0, 0                                        // 000000DF43BC: 7E000280
	s_lshl_b64 s[0:1], s[10:11], 2                             // 000000DF43C0: 8480820A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000DF43C4: BF870009
	s_add_u32 s0, s12, s0                                      // 000000DF43C8: 8000000C
	s_addc_u32 s1, s13, s1                                     // 000000DF43CC: 8201010D
	global_store_b32 v0, v0, s[0:1]                            // 000000DF43D0: DC6A0000 00000000
	s_nop 0                                                    // 000000DF43D8: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 000000DF43DC: BFB60003
	s_endpgm                                                   // 000000DF43E0: BFB00000
		...

