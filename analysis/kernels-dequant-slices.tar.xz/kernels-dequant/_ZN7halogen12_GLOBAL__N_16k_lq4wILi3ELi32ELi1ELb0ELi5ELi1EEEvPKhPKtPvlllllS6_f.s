00000000008bfe00 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[8:23], s[0:1], null                          // 0000008BFE00: F4100200 F8000000
	v_and_b32_e32 v1, 15, v0                                   // 0000008BFE08: 3602008F
	v_lshrrev_b32_e32 v2, 2, v0                                // 0000008BFE0C: 32040082
	s_ashr_i32 s3, s2, 31                                      // 0000008BFE10: 86039F02
	v_lshrrev_b32_e32 v3, 5, v0                                // 0000008BFE14: 32060085
	s_lshl_b64 s[2:3], s[2:3], 3                               // 0000008BFE18: 84828302
	v_lshlrev_b32_e32 v1, 2, v1                                // 0000008BFE1C: 30020282
	v_dual_mov_b32 v17, s3 :: v_dual_and_b32 v2, 60, v2        // 0000008BFE20: CA240003 110204BC
	s_delay_alu instid0(VALU_DEP_3)                            // 0000008BFE28: BF870003
	v_or_b32_e32 v16, s2, v3                                   // 0000008BFE2C: 38200602
	.long 0x7f063880                                           // 0000008BFE30: 7F063880
	v_and_b32_e32 v23, 31, v0                                  // 0000008BFE34: 362E009F
	v_lshlrev_b32_e32 v0, 2, v0                                // 0000008BFE38: 30000082
	s_waitcnt lgkmcnt(0)                                       // 0000008BFE3C: BF89FC07
	s_clause 0x1                                               // 0000008BFE40: BF850001
	global_load_b32 v1, v1, s[8:9]                             // 0000008BFE44: DC520000 01080001
	global_load_b32 v2, v2, s[8:9]                             // 0000008BFE4C: DC520000 02080002
	.long 0xd4540002                                           // 0000008BFE54: D4540002
	v_cndmask_b32_e32 v1, s16, v16, vcc_lo                     // 0000008BFE58: 02022010
	s_add_u32 s24, s8, s20                                     // 0000008BFE5C: 80181408
	s_addc_u32 s25, s9, s21                                    // 0000008BFE60: 82191509
	s_ashr_i32 s4, s15, 31                                     // 0000008BFE64: 86049F0F
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 0000008BFE68: BF870159
	s_lshr_b32 s4, s4, 27                                      // 0000008BFE6C: 85049B04
	v_cndmask_b32_e64 v8, 0, v16, s2                           // 0000008BFE70: D5010008 000A2080
	v_cndmask_b32_e64 v9, 0, s3, s2                            // 0000008BFE78: D5010009 00080680
	s_add_u32 s4, s14, s4                                      // 0000008BFE80: 8004040E
	s_addc_u32 s5, s15, 0                                      // 0000008BFE84: 8205800F
	.long 0xd72c0004                                           // 0000008BFE88: D72C0004
	v_cndmask_b32_e32 v1, s23, v8, vcc_lo                      // 0000008BFE8C: 02021017
	v_mad_u64_u32 v[12:13], null, s22, v8, 0                   // 0000008BFE90: D6FE7C0C 02021016
	s_lshr_b64 s[6:7], s[4:5], 5                               // 0000008BFE98: 85868504
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000008BFE9C: BF870009
	s_cmpk_lt_i32 s6, 0x101                                    // 0000008BFEA0: B3860101
	.long 0xd4440004                                           // 0000008BFEA4: D4440004
	v_cndmask_b32_e32 v1, s6, v23, vcc_lo                      // 0000008BFEA8: 02022E06
	s_cselect_b32 s3, -1, 0                                    // 0000008BFEAC: 980380C1
	s_cmpk_gt_i32 s6, 0x100                                    // 0000008BFEB0: B2860100
	.long 0xd700050e                                           // 0000008BFEB4: D700050E
	v_cndmask_b32_e32 v1, s24, v12, vcc_lo                     // 0000008BFEB8: 02021818
	s_cselect_b32 s7, -1, 0                                    // 0000008BFEBC: 980780C1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 0000008BFEC0: BF870159
	s_and_b32 vcc_lo, exec_lo, s7                              // 0000008BFEC4: 8B6A077E
	s_waitcnt vmcnt(1)                                         // 0000008BFEC8: BF8907F7
	v_bfe_u32 v5, v1, 16, 1                                    // 0000008BFECC: D6100005 02052101
	s_waitcnt vmcnt(0)                                         // 0000008BFED4: BF8903F7
	v_bfe_u32 v6, v2, 16, 1                                    // 0000008BFED8: D6100006 02052102
	v_add3_u32 v1, v1, v5, 0x7fff                              // 0000008BFEE0: D6550001 03FE0B01 00007FFF
	.long 0xd72c0005                                           // 0000008BFEEC: D72C0005
	v_cndmask_b32_e32 v1, s22, v9, vcc_lo                      // 0000008BFEF0: 02021216
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008BFEF4: BF870193
	v_add3_u32 v2, v2, v6, 0x7fff                              // 0000008BFEF8: D6550002 03FE0D02 00007FFF
	.long 0x7e063981                                           // 0000008BFF04: 7E063981
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000008BFF08: BF870113
	v_add3_u32 v13, v13, v5, v4                                // 0000008BFF0C: D655000D 04120B0D
	v_and_or_b32 v1, 0xffff0000, v2, v3                        // 0000008BFF14: D6570001 040E04FF FFFF0000
	s_delay_alu instid0(VALU_DEP_2)                            // 0000008BFF20: BF870002
	v_add_co_ci_u32_e64 v15, null, s25, v13, s5                // 0000008BFF24: D5207C0F 00161A19
	ds_store_b32 v0, v1                                        // 0000008BFF2C: D8340000 00000100
	s_waitcnt lgkmcnt(0)                                       // 0000008BFF34: BF89FC07
	s_barrier                                                  // 0000008BFF38: BFBD0000
	buffer_gl0_inv                                             // 0000008BFF3C: E0AC0000 00000000
	s_cbranch_vccnz 146                                        // 0000008BFF44: BFA40092 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x390>
	v_dual_mov_b32 v1, 0 :: v_dual_mov_b32 v0, 0               // 0000008BFF48: CA100080 01000080
	s_and_saveexec_b32 s5, s4                                  // 0000008BFF50: BE852004
	s_cbranch_execz 10                                         // 0000008BFF54: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x180>
	v_lshlrev_b32_e32 v0, 1, v23                               // 0000008BFF58: 30002E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008BFF5C: BF870091
	.long 0xd7006a02                                           // 0000008BFF60: D7006A02
	v_cndmask_b32_e32 v1, v14, v0, vcc_lo                      // 0000008BFF64: 0202010E
	v_add_co_ci_u32_e64 v3, null, 0, v15, vcc_lo               // 0000008BFF68: D5207C03 01AA1E80
	global_load_d16_b16 v0, v[2:3], off                        // 0000008BFF70: DC820000 007C0002
	s_waitcnt vmcnt(0)                                         // 0000008BFF78: BF8903F7
	v_cvt_f32_f16_e32 v0, v0                                   // 0000008BFF7C: 7E001700
	s_or_b32 exec_lo, exec_lo, s5                              // 0000008BFF80: 8C7E057E
	v_or_b32_e32 v2, 32, v23                                   // 0000008BFF84: 38042EA0
	s_mov_b32 s4, exec_lo                                      // 0000008BFF88: BE84007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008BFF8C: BF870001
	.long 0xd4c4007e                                           // 0000008BFF90: D4C4007E
	v_cndmask_b32_e32 v1, s6, v2, vcc_lo                       // 0000008BFF94: 02020406
	s_cbranch_execz 10                                         // 0000008BFF98: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x1c4>
	v_lshlrev_b32_e32 v1, 1, v2                                // 0000008BFF9C: 30020481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008BFFA0: BF870091
	.long 0xd7006a01                                           // 0000008BFFA4: D7006A01
	v_cndmask_b32_e32 v1, v14, v1, vcc_lo                      // 0000008BFFA8: 0202030E
	v_add_co_ci_u32_e64 v2, null, 0, v15, vcc_lo               // 0000008BFFAC: D5207C02 01AA1E80
	global_load_d16_b16 v1, v[1:2], off                        // 0000008BFFB4: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 0000008BFFBC: BF8903F7
	v_cvt_f32_f16_e32 v1, v1                                   // 0000008BFFC0: 7E021701
	s_or_b32 exec_lo, exec_lo, s4                              // 0000008BFFC4: 8C7E047E
	v_or_b32_e32 v4, 64, v23                                   // 0000008BFFC8: 38082EC0
	v_dual_mov_b32 v3, 0 :: v_dual_mov_b32 v2, 0               // 0000008BFFCC: CA100080 03020080
	s_mov_b32 s4, exec_lo                                      // 0000008BFFD4: BE84007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000008BFFD8: BF870002
	.long 0xd4c4007e                                           // 0000008BFFDC: D4C4007E
	v_cndmask_b32_e32 v1, s6, v4, vcc_lo                       // 0000008BFFE0: 02020806
	s_cbranch_execz 10                                         // 0000008BFFE4: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x210>
	v_lshlrev_b32_e32 v2, 1, v4                                // 0000008BFFE8: 30040881
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008BFFEC: BF870091
	.long 0xd7006a04                                           // 0000008BFFF0: D7006A04
	v_cndmask_b32_e32 v1, v14, v2, vcc_lo                      // 0000008BFFF4: 0202050E
	v_add_co_ci_u32_e64 v5, null, 0, v15, vcc_lo               // 0000008BFFF8: D5207C05 01AA1E80
	global_load_d16_b16 v2, v[4:5], off                        // 0000008C0000: DC820000 027C0004
	s_waitcnt vmcnt(0)                                         // 0000008C0008: BF8903F7
	v_cvt_f32_f16_e32 v2, v2                                   // 0000008C000C: 7E041702
	s_or_b32 exec_lo, exec_lo, s4                              // 0000008C0010: 8C7E047E
	v_or_b32_e32 v4, 0x60, v23                                 // 0000008C0014: 38082EFF 00000060
	s_mov_b32 s4, exec_lo                                      // 0000008C001C: BE84007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008C0020: BF870001
	.long 0xd4c4007e                                           // 0000008C0024: D4C4007E
	v_cndmask_b32_e32 v1, s6, v4, vcc_lo                       // 0000008C0028: 02020806
	s_cbranch_execz 10                                         // 0000008C002C: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x258>
	v_lshlrev_b32_e32 v3, 1, v4                                // 0000008C0030: 30060881
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C0034: BF870091
	.long 0xd7006a03                                           // 0000008C0038: D7006A03
	v_cndmask_b32_e32 v1, v14, v3, vcc_lo                      // 0000008C003C: 0202070E
	v_add_co_ci_u32_e64 v4, null, 0, v15, vcc_lo               // 0000008C0040: D5207C04 01AA1E80
	global_load_d16_b16 v3, v[3:4], off                        // 0000008C0048: DC820000 037C0003
	s_waitcnt vmcnt(0)                                         // 0000008C0050: BF8903F7
	v_cvt_f32_f16_e32 v3, v3                                   // 0000008C0054: 7E061703
	s_or_b32 exec_lo, exec_lo, s4                              // 0000008C0058: 8C7E047E
	v_or_b32_e32 v6, 0x80, v23                                 // 0000008C005C: 380C2EFF 00000080
	v_dual_mov_b32 v5, 0 :: v_dual_mov_b32 v4, 0               // 0000008C0064: CA100080 05040080
	s_mov_b32 s4, exec_lo                                      // 0000008C006C: BE84007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000008C0070: BF870002
	.long 0xd4c4007e                                           // 0000008C0074: D4C4007E
	v_cndmask_b32_e32 v1, s6, v6, vcc_lo                       // 0000008C0078: 02020C06
	s_cbranch_execz 10                                         // 0000008C007C: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x2a8>
	v_lshlrev_b32_e32 v4, 1, v6                                // 0000008C0080: 30080C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C0084: BF870091
	.long 0xd7006a06                                           // 0000008C0088: D7006A06
	v_cndmask_b32_e32 v1, v14, v4, vcc_lo                      // 0000008C008C: 0202090E
	v_add_co_ci_u32_e64 v7, null, 0, v15, vcc_lo               // 0000008C0090: D5207C07 01AA1E80
	global_load_d16_b16 v4, v[6:7], off                        // 0000008C0098: DC820000 047C0006
	s_waitcnt vmcnt(0)                                         // 0000008C00A0: BF8903F7
	v_cvt_f32_f16_e32 v4, v4                                   // 0000008C00A4: 7E081704
	s_or_b32 exec_lo, exec_lo, s4                              // 0000008C00A8: 8C7E047E
	v_or_b32_e32 v6, 0xa0, v23                                 // 0000008C00AC: 380C2EFF 000000A0
	s_mov_b32 s4, exec_lo                                      // 0000008C00B4: BE84007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008C00B8: BF870001
	.long 0xd4c4007e                                           // 0000008C00BC: D4C4007E
	v_cndmask_b32_e32 v1, s6, v6, vcc_lo                       // 0000008C00C0: 02020C06
	s_cbranch_execz 10                                         // 0000008C00C4: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x2f0>
	v_lshlrev_b32_e32 v5, 1, v6                                // 0000008C00C8: 300A0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C00CC: BF870091
	.long 0xd7006a05                                           // 0000008C00D0: D7006A05
	v_cndmask_b32_e32 v1, v14, v5, vcc_lo                      // 0000008C00D4: 02020B0E
	v_add_co_ci_u32_e64 v6, null, 0, v15, vcc_lo               // 0000008C00D8: D5207C06 01AA1E80
	global_load_d16_b16 v5, v[5:6], off                        // 0000008C00E0: DC820000 057C0005
	s_waitcnt vmcnt(0)                                         // 0000008C00E8: BF8903F7
	v_cvt_f32_f16_e32 v5, v5                                   // 0000008C00EC: 7E0A1705
	s_or_b32 exec_lo, exec_lo, s4                              // 0000008C00F0: 8C7E047E
	v_or_b32_e32 v10, 0xc0, v23                                // 0000008C00F4: 38142EFF 000000C0
	v_dual_mov_b32 v7, 0 :: v_dual_mov_b32 v6, 0               // 0000008C00FC: CA100080 07060080
	s_mov_b32 s4, exec_lo                                      // 0000008C0104: BE84007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000008C0108: BF870002
	.long 0xd4c4007e                                           // 0000008C010C: D4C4007E
	v_cndmask_b32_e32 v1, s6, v10, vcc_lo                      // 0000008C0110: 02021406
	s_cbranch_execz 10                                         // 0000008C0114: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x340>
	v_lshlrev_b32_e32 v6, 1, v10                               // 0000008C0118: 300C1481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C011C: BF870091
	.long 0xd7006a0a                                           // 0000008C0120: D7006A0A
	v_cndmask_b32_e32 v1, v14, v6, vcc_lo                      // 0000008C0124: 02020D0E
	v_add_co_ci_u32_e64 v11, null, 0, v15, vcc_lo              // 0000008C0128: D5207C0B 01AA1E80
	global_load_d16_b16 v6, v[10:11], off                      // 0000008C0130: DC820000 067C000A
	s_waitcnt vmcnt(0)                                         // 0000008C0138: BF8903F7
	v_cvt_f32_f16_e32 v6, v6                                   // 0000008C013C: 7E0C1706
	s_or_b32 exec_lo, exec_lo, s4                              // 0000008C0140: 8C7E047E
	v_or_b32_e32 v10, 0xe0, v23                                // 0000008C0144: 38142EFF 000000E0
	s_mov_b32 s4, exec_lo                                      // 0000008C014C: BE84007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008C0150: BF870001
	.long 0xd4c4007e                                           // 0000008C0154: D4C4007E
	v_cndmask_b32_e32 v1, s6, v10, vcc_lo                      // 0000008C0158: 02021406
	s_cbranch_execz 10                                         // 0000008C015C: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x388>
	v_lshlrev_b32_e32 v7, 1, v10                               // 0000008C0160: 300E1481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C0164: BF870091
	.long 0xd7006a0a                                           // 0000008C0168: D7006A0A
	v_cndmask_b32_e32 v1, v14, v7, vcc_lo                      // 0000008C016C: 02020F0E
	v_add_co_ci_u32_e64 v11, null, 0, v15, vcc_lo              // 0000008C0170: D5207C0B 01AA1E80
	global_load_d16_b16 v7, v[10:11], off                      // 0000008C0178: DC820000 077C000A
	s_waitcnt vmcnt(0)                                         // 0000008C0180: BF8903F7
	v_cvt_f32_f16_e32 v7, v7                                   // 0000008C0184: 7E0E1707
	s_or_b32 exec_lo, exec_lo, s4                              // 0000008C0188: 8C7E047E
	s_branch 9                                                 // 0000008C018C: BFA00009 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x3b4>
	v_mov_b32_e32 v0, 0                                        // 0000008C0190: 7E000280
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008C0194: BF870001
	v_mov_b32_e32 v1, v0                                       // 0000008C0198: 7E020300
	v_mov_b32_e32 v2, v0                                       // 0000008C019C: 7E040300
	v_mov_b32_e32 v3, v0                                       // 0000008C01A0: 7E060300
	v_mov_b32_e32 v4, v0                                       // 0000008C01A4: 7E080300
	v_mov_b32_e32 v5, v0                                       // 0000008C01A8: 7E0A0300
	v_mov_b32_e32 v6, v0                                       // 0000008C01AC: 7E0C0300
	v_mov_b32_e32 v7, v0                                       // 0000008C01B0: 7E0E0300
	s_add_u32 s4, s8, s18                                      // 0000008C01B4: 80041208
	s_addc_u32 s5, s9, s19                                     // 0000008C01B8: 82051309
	s_lshr_b32 s18, s15, 31                                    // 0000008C01BC: 85129F0F
	v_mov_b32_e32 v24, 0                                       // 0000008C01C0: 7E300280
	s_add_u32 s18, s14, s18                                    // 0000008C01C4: 8012120E
	s_addc_u32 s19, s15, 0                                     // 0000008C01C8: 8213800F
	v_cndmask_b32_e64 v25, 0, 1, s7                            // 0000008C01CC: D5010019 001D0280
	s_ashr_i64 s[18:19], s[18:19], 1                           // 0000008C01D4: 86928112
	v_mov_b32_e32 v32, 0                                       // 0000008C01D8: 7E400280
	v_mad_u64_u32 v[18:19], null, v8, s18, s[4:5]              // 0000008C01DC: D6FE7C12 00102508
	.long 0xd72c000b                                           // 0000008C01E4: D72C000B
	v_cndmask_b32_e32 v0, v8, v19, vcc_lo                      // 0000008C01E8: 02002708
	.long 0xd72c0014                                           // 0000008C01EC: D72C0014
	v_cndmask_b32_e32 v0, v9, v18, vcc_lo                      // 0000008C01F0: 02002509
	.long 0xd4440004                                           // 0000008C01F4: D4440004
	v_cndmask_b32_e32 v1, s6, v23, vcc_lo                      // 0000008C01F8: 02022E06
	v_dual_mov_b32 v8, 0 :: v_dual_mov_b32 v9, 0               // 0000008C01FC: CA100080 08080080
	v_mov_b32_e32 v10, 0                                       // 0000008C0204: 7E140280
	s_delay_alu instid0(VALU_DEP_4)                            // 0000008C0208: BF870004
	v_add3_u32 v26, v20, v19, v11                              // 0000008C020C: D655001A 042E2714
	v_mov_b32_e32 v11, 0                                       // 0000008C0214: 7E160280
	s_and_saveexec_b32 s5, s4                                  // 0000008C0218: BE852004
	s_cbranch_execz 21                                         // 0000008C021C: BFA50015 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x474>
	v_lshlrev_b32_e32 v8, 4, v23                               // 0000008C0220: 30102E84
	v_mov_b32_e32 v32, 0                                       // 0000008C0224: 7E400280
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C0228: BF870092
	.long 0xd7006a08                                           // 0000008C022C: D7006A08
	v_cndmask_b32_e32 v1, v18, v8, vcc_lo                      // 0000008C0230: 02021112
	v_add_co_ci_u32_e64 v9, null, 0, v26, vcc_lo               // 0000008C0234: D5207C09 01AA3480
	s_and_not1_b32 vcc_lo, exec_lo, s7                         // 0000008C023C: 916A077E
	global_load_b128 v[8:11], v[8:9], off                      // 0000008C0240: DC5E0000 087C0008
	s_cbranch_vccnz 10                                         // 0000008C0248: BFA4000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x474>
	v_lshlrev_b32_e32 v19, 1, v23                              // 0000008C024C: 30262E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C0250: BF870091
	.long 0xd7006a0e                                           // 0000008C0254: D7006A0E
	v_cndmask_b32_e32 v1, v14, v19, vcc_lo                     // 0000008C0258: 0202270E
	v_add_co_ci_u32_e64 v15, null, 0, v15, vcc_lo              // 0000008C025C: D5207C0F 01AA1E80
	global_load_d16_b16 v14, v[14:15], off                     // 0000008C0264: DC820000 0E7C000E
	s_waitcnt vmcnt(0)                                         // 0000008C026C: BF8903F7
	v_cvt_f32_f16_e32 v32, v14                                 // 0000008C0270: 7E40170E
	s_or_b32 exec_lo, exec_lo, s5                              // 0000008C0274: 8C7E057E
	v_dual_mov_b32 v27, 0 :: v_dual_mov_b32 v28, 0             // 0000008C0278: CA100080 1B1C0080
	s_and_saveexec_b32 s5, s4                                  // 0000008C0280: BE852004
	s_cbranch_execz 352                                        // 0000008C0284: BFA50160 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0xa08>
	.long 0xd7006a0c                                           // 0000008C0288: D7006A0C
	v_cndmask_b32_e32 v1, s20, v12, vcc_lo                     // 0000008C028C: 02021814
	v_dual_mov_b32 v20, 0 :: v_dual_lshlrev_b32 v19, 5, v23    // 0000008C0290: CA220080 14122E85
	v_lshlrev_b32_e32 v14, 1, v23                              // 0000008C0298: 301C2E81
	v_add_co_ci_u32_e64 v13, null, s21, v13, vcc_lo            // 0000008C029C: D5207C0D 01AA1A15
	v_lshl_or_b32 v29, v23, 4, 0x200                           // 0000008C02A4: D656001D 03FD0917 00000200
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000008C02B0: BF870214
	v_mov_b32_e32 v27, v20                                     // 0000008C02B4: 7E360314
	.long 0xd7006a0c                                           // 0000008C02B8: D7006A0C
	v_cndmask_b32_e32 v1, v12, v14, vcc_lo                     // 0000008C02BC: 02021D0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008C02C0: BF8701A1
	v_add_co_ci_u32_e64 v13, null, 0, v13, vcc_lo              // 0000008C02C4: D5207C0D 01AA1A80
	v_dual_mov_b32 v30, v23 :: v_dual_mov_b32 v31, v32         // 0000008C02CC: CA100117 1E1E0120
	.long 0xd7006a0c                                           // 0000008C02D4: D7006A0C
	v_cndmask_b32_e32 v1, s8, v12, vcc_lo                      // 0000008C02D8: 02021808
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008C02DC: BF8701A1
	v_add_co_ci_u32_e64 v13, null, s9, v13, vcc_lo             // 0000008C02E0: D5207C0D 01AA1A09
	v_mov_b32_e32 v28, v20                                     // 0000008C02E8: 7E380314
	.long 0xd7006a15                                           // 0000008C02EC: D7006A15
	v_cndmask_b32_e32 v0, v12, v192, vcc_lo                    // 0000008C02F0: 0201810C
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008C02F4: BF870001
	v_add_co_ci_u32_e64 v22, null, 0, v13, vcc_lo              // 0000008C02F8: D5207C16 01AA1A80
	v_mov_b32_e32 v24, v20                                     // 0000008C0300: 7E300314
	s_lshl_b64 s[8:9], s[14:15], 2                             // 0000008C0304: 8488820E
	s_mov_b32 s7, 0                                            // 0000008C0308: BE870080
	s_lshl_b64 s[14:15], s[14:15], 1                           // 0000008C030C: 848E810E
	s_branch 288                                               // 0000008C0310: BFA00120 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x994>
	s_or_b32 exec_lo, exec_lo, s18                             // 0000008C0314: 8C7E127E
	.long 0xd73c0021                                           // 0000008C0318: D73C0021
	v_cndmask_b32_e32 v1, 1, v19, vcc_lo                       // 0000008C031C: 02022681
	v_and_b32_e32 v81, 0xff, v8                                // 0000008C0320: 36A210FF 000000FF
	v_cndmask_b32_e64 v82, v32, v0, s3                         // 0000008C0328: D5010052 000E0120
	v_lshrrev_b32_e32 v32, 6, v8                               // 0000008C0330: 32401086
	v_lshrrev_b32_e32 v83, 14, v8                              // 0000008C0334: 32A6108E
	v_lshrrev_b32_e32 v8, 22, v8                               // 0000008C0338: 32101096
	.long 0xd7006a45                                           // 0000008C033C: D7006A45
	v_cndmask_b32_e32 v1, s10, v33, vcc_lo                     // 0000008C0340: 0202420A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008C0344: BF8701A1
	v_add_co_ci_u32_e64 v70, null, s11, v34, vcc_lo            // 0000008C0348: D5207C46 01AA440B
	v_lshlrev_b32_e32 v81, 2, v81                              // 0000008C0350: 30A2A282
	.long 0xd7006a49                                           // 0000008C0354: D7006A49
	v_cndmask_b32_e32 v0, v69, v14, vcc_lo                     // 0000008C0358: 02001D45
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008C035C: BF8700A1
	v_add_co_ci_u32_e64 v74, null, s15, v70, vcc_lo            // 0000008C0360: D5207C4A 01AA8C0F
	.long 0xd7006a4d                                           // 0000008C0368: D7006A4D
	v_cndmask_b32_e32 v0, v69, v8, vcc_lo                      // 0000008C036C: 02001145
	v_add_co_ci_u32_e64 v78, null, s9, v70, vcc_lo             // 0000008C0370: D5207C4E 01AA8C09
	s_clause 0xb                                               // 0000008C0378: BF85000B
	global_load_b128 v[33:36], v[69:70], off                   // 0000008C037C: DC5E0000 217C0045
	global_load_b128 v[37:40], v[73:74], off                   // 0000008C0384: DC5E0000 257C0049
	global_load_b128 v[41:44], v[77:78], off                   // 0000008C038C: DC5E0000 297C004D
	global_load_b128 v[45:48], v[69:70], off offset:16         // 0000008C0394: DC5E0010 2D7C0045
	global_load_b128 v[49:52], v[73:74], off offset:16         // 0000008C039C: DC5E0010 317C0049
	global_load_b128 v[53:56], v[77:78], off offset:16         // 0000008C03A4: DC5E0010 357C004D
	global_load_b128 v[57:60], v[69:70], off offset:32         // 0000008C03AC: DC5E0020 397C0045
	global_load_b128 v[61:64], v[73:74], off offset:32         // 0000008C03B4: DC5E0020 3D7C0049
	global_load_b128 v[65:68], v[77:78], off offset:32         // 0000008C03BC: DC5E0020 417C004D
	global_load_b128 v[69:72], v[69:70], off offset:48         // 0000008C03C4: DC5E0030 457C0045
	global_load_b128 v[73:76], v[73:74], off offset:48         // 0000008C03CC: DC5E0030 497C0049
	global_load_b128 v[77:80], v[77:78], off offset:48         // 0000008C03D4: DC5E0030 4D7C004D
	v_and_b32_e32 v32, 0x3fc, v32                              // 0000008C03DC: 364040FF 000003FC
	ds_load_b32 v81, v81                                       // 0000008C03E4: D8D80000 51000051
	v_and_b32_e32 v83, 0x3fc, v83                              // 0000008C03EC: 36A6A6FF 000003FC
	v_and_b32_e32 v84, 0xff, v9                                // 0000008C03F4: 36A812FF 000000FF
	v_lshrrev_b32_e32 v85, 6, v9                               // 0000008C03FC: 32AA1286
	v_lshrrev_b32_e32 v86, 14, v9                              // 0000008C0400: 32AC128E
	v_lshrrev_b32_e32 v9, 22, v9                               // 0000008C0404: 32121296
	ds_load_b32 v83, v83                                       // 0000008C0408: D8D80000 53000053
	ds_load_b32 v32, v32                                       // 0000008C0410: D8D80000 20000020
	v_and_b32_e32 v8, 0x3fc, v8                                // 0000008C0418: 361010FF 000003FC
	v_lshlrev_b32_e32 v84, 2, v84                              // 0000008C0420: 30A8A882
	v_and_b32_e32 v85, 0x3fc, v85                              // 0000008C0424: 36AAAAFF 000003FC
	v_and_b32_e32 v86, 0x3fc, v86                              // 0000008C042C: 36ACACFF 000003FC
	v_and_b32_e32 v9, 0x3fc, v9                                // 0000008C0434: 361212FF 000003FC
	ds_load_b32 v8, v8                                         // 0000008C043C: D8D80000 08000008
	ds_load_b32 v84, v84                                       // 0000008C0444: D8D80000 54000054
	ds_load_b32 v85, v85                                       // 0000008C044C: D8D80000 55000055
	ds_load_b32 v86, v86                                       // 0000008C0454: D8D80000 56000056
	ds_load_b32 v9, v9                                         // 0000008C045C: D8D80000 09000009
	v_and_b32_e32 v87, 0xff, v10                               // 0000008C0464: 36AE14FF 000000FF
	v_lshrrev_b32_e32 v88, 6, v10                              // 0000008C046C: 32B01486
	v_lshrrev_b32_e32 v89, 14, v10                             // 0000008C0470: 32B2148E
	v_lshrrev_b32_e32 v10, 22, v10                             // 0000008C0474: 32141496
	v_and_b32_e32 v90, 0xff, v11                               // 0000008C0478: 36B416FF 000000FF
	v_lshrrev_b32_e32 v91, 14, v11                             // 0000008C0480: 32B6168E
	.long 0xd7006a15                                           // 0000008C0484: D7006A15
	v_cndmask_b32_e32 v0, v21, v192, vcc_lo                    // 0000008C0488: 02018115
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000008C048C: BF8704A1
	v_add_co_ci_u32_e64 v22, null, 0, v22, vcc_lo              // 0000008C0490: D5207C16 01AA2C80
	s_and_b32 s4, exec_lo, s4                                  // 0000008C0498: 8B04047E
	s_or_b32 s7, s4, s7                                        // 0000008C049C: 8C070704
	s_waitcnt vmcnt(11) lgkmcnt(7)                             // 0000008C04A0: BF892C77
	v_dot2_f32_bf16 v33, v33, v81, 0                           // 0000008C04A4: CC1A4021 1A02A321
	s_waitcnt vmcnt(10)                                        // 0000008C04AC: BF892BF7
	v_dot2_f32_bf16 v37, v37, v81, 0                           // 0000008C04B0: CC1A4025 1A02A325
	s_waitcnt vmcnt(9)                                         // 0000008C04B8: BF8927F7
	v_dot2_f32_bf16 v41, v41, v81, 0                           // 0000008C04BC: CC1A4029 1A02A329
	v_lshrrev_b32_e32 v81, 6, v11                              // 0000008C04C4: 32A21686
	v_lshrrev_b32_e32 v11, 22, v11                             // 0000008C04C8: 32161696
	s_waitcnt lgkmcnt(5)                                       // 0000008C04CC: BF89FC57
	v_dot2_f32_bf16 v33, v34, v32, v33                         // 0000008C04D0: CC1A4021 1C864122
	v_dot2_f32_bf16 v34, v38, v32, v37                         // 0000008C04D8: CC1A4022 1C964126
	v_dot2_f32_bf16 v32, v42, v32, v41                         // 0000008C04E0: CC1A4020 1CA6412A
	v_lshlrev_b32_e32 v37, 2, v87                              // 0000008C04E8: 304AAE82
	v_and_b32_e32 v38, 0x3fc, v89                              // 0000008C04EC: 364CB2FF 000003FC
	v_dot2_f32_bf16 v33, v35, v83, v33                         // 0000008C04F4: CC1A4021 1C86A723
	v_dot2_f32_bf16 v34, v39, v83, v34                         // 0000008C04FC: CC1A4022 1C8AA727
	v_dot2_f32_bf16 v32, v43, v83, v32                         // 0000008C0504: CC1A4020 1C82A72B
	v_and_b32_e32 v35, 0x3fc, v88                              // 0000008C050C: 3646B0FF 000003FC
	v_and_b32_e32 v39, 0x3fc, v91                              // 0000008C0514: 364EB6FF 000003FC
	s_waitcnt lgkmcnt(4)                                       // 0000008C051C: BF89FC47
	v_dot2_f32_bf16 v33, v36, v8, v33                          // 0000008C0520: CC1A4021 1C861124
	v_dot2_f32_bf16 v34, v40, v8, v34                          // 0000008C0528: CC1A4022 1C8A1128
	v_dot2_f32_bf16 v8, v44, v8, v32                           // 0000008C0530: CC1A4008 1C82112C
	ds_load_b32 v36, v37                                       // 0000008C0538: D8D80000 24000025
	ds_load_b32 v40, v38                                       // 0000008C0540: D8D80000 28000026
	ds_load_b32 v35, v35                                       // 0000008C0548: D8D80000 23000023
	s_waitcnt vmcnt(8) lgkmcnt(6)                              // 0000008C0550: BF892067
	v_dot2_f32_bf16 v33, v45, v84, v33                         // 0000008C0554: CC1A4021 1C86A92D
	s_waitcnt vmcnt(7)                                         // 0000008C055C: BF891FF7
	v_dot2_f32_bf16 v34, v49, v84, v34                         // 0000008C0560: CC1A4022 1C8AA931
	s_waitcnt vmcnt(6)                                         // 0000008C0568: BF891BF7
	v_dot2_f32_bf16 v8, v53, v84, v8                           // 0000008C056C: CC1A4008 1C22A935
	v_cndmask_b32_e64 v38, v5, v6, s3                          // 0000008C0574: D5010026 000E0D05
	v_and_b32_e32 v10, 0x3fc, v10                              // 0000008C057C: 361414FF 000003FC
	s_waitcnt lgkmcnt(5)                                       // 0000008C0584: BF89FC57
	v_dot2_f32_bf16 v33, v46, v85, v33                         // 0000008C0588: CC1A4021 1C86AB2E
	v_dot2_f32_bf16 v34, v50, v85, v34                         // 0000008C0590: CC1A4022 1C8AAB32
	v_dot2_f32_bf16 v8, v54, v85, v8                           // 0000008C0598: CC1A4008 1C22AB36
	v_lshlrev_b32_e32 v32, 2, v90                              // 0000008C05A0: 3040B482
	v_and_b32_e32 v37, 0x3fc, v81                              // 0000008C05A4: 364AA2FF 000003FC
	s_waitcnt lgkmcnt(4)                                       // 0000008C05AC: BF89FC47
	v_dot2_f32_bf16 v33, v47, v86, v33                         // 0000008C05B0: CC1A4021 1C86AD2F
	v_dot2_f32_bf16 v34, v51, v86, v34                         // 0000008C05B8: CC1A4022 1C8AAD33
	v_dot2_f32_bf16 v8, v55, v86, v8                           // 0000008C05C0: CC1A4008 1C22AD37
	v_and_b32_e32 v11, 0x3fc, v11                              // 0000008C05C8: 361616FF 000003FC
	s_waitcnt lgkmcnt(3)                                       // 0000008C05D0: BF89FC37
	v_dot2_f32_bf16 v33, v48, v9, v33                          // 0000008C05D4: CC1A4021 1C861330
	v_dot2_f32_bf16 v34, v52, v9, v34                          // 0000008C05DC: CC1A4022 1C8A1334
	v_dot2_f32_bf16 v8, v56, v9, v8                            // 0000008C05E4: CC1A4008 1C221338
	ds_load_b32 v9, v10                                        // 0000008C05EC: D8D80000 0900000A
	ds_load_b32 v10, v32                                       // 0000008C05F4: D8D80000 0A000020
	ds_load_b32 v32, v37                                       // 0000008C05FC: D8D80000 20000025
	ds_load_b32 v41, v39                                       // 0000008C0604: D8D80000 29000027
	ds_load_b32 v42, v11                                       // 0000008C060C: D8D80000 2A00000B
	v_cndmask_b32_e64 v39, v6, v7, s3                          // 0000008C0614: D5010027 000E0F06
	s_waitcnt vmcnt(5) lgkmcnt(7)                              // 0000008C061C: BF891477
	v_dot2_f32_bf16 v11, v57, v36, v33                         // 0000008C0620: CC1A400B 1C864939
	s_waitcnt vmcnt(4)                                         // 0000008C0628: BF8913F7
	v_dot2_f32_bf16 v33, v61, v36, v34                         // 0000008C062C: CC1A4021 1C8A493D
	s_waitcnt vmcnt(3)                                         // 0000008C0634: BF890FF7
	v_dot2_f32_bf16 v8, v65, v36, v8                           // 0000008C0638: CC1A4008 1C224941
	v_cndmask_b32_e64 v37, v4, v5, s3                          // 0000008C0640: D5010025 000E0B04
	v_cndmask_b32_e64 v36, v3, v4, s3                          // 0000008C0648: D5010024 000E0903
	s_waitcnt lgkmcnt(5)                                       // 0000008C0650: BF89FC57
	v_dot2_f32_bf16 v6, v58, v35, v11                          // 0000008C0654: CC1A4006 1C2E473A
	v_dot2_f32_bf16 v11, v62, v35, v33                         // 0000008C065C: CC1A400B 1C86473E
	v_dot2_f32_bf16 v8, v66, v35, v8                           // 0000008C0664: CC1A4008 1C224742
	v_cndmask_b32_e64 v35, v2, v3, s3                          // 0000008C066C: D5010023 000E0702
	v_cndmask_b32_e64 v34, v1, v2, s3                          // 0000008C0674: D5010022 000E0501
	v_dot2_f32_bf16 v4, v59, v40, v6                           // 0000008C067C: CC1A4004 1C1A513B
	v_dot2_f32_bf16 v5, v63, v40, v11                          // 0000008C0684: CC1A4005 1C2E513F
	v_dot2_f32_bf16 v6, v67, v40, v8                           // 0000008C068C: CC1A4006 1C225143
	v_cndmask_b32_e64 v33, v0, v1, s3                          // 0000008C0694: D5010021 000E0300
	v_mov_b32_e32 v40, v7                                      // 0000008C069C: 7E500307
	s_waitcnt lgkmcnt(4)                                       // 0000008C06A0: BF89FC47
	v_dot2_f32_bf16 v2, v60, v9, v4                            // 0000008C06A4: CC1A4002 1C12133C
	v_dot2_f32_bf16 v3, v64, v9, v5                            // 0000008C06AC: CC1A4003 1C161340
	v_dot2_f32_bf16 v4, v68, v9, v6                            // 0000008C06B4: CC1A4004 1C1A1344
	v_add_nc_u32_e32 v19, 0x400, v19                           // 0000008C06BC: 4A2626FF 00000400
	v_add_nc_u32_e32 v29, 0x200, v29                           // 0000008C06C4: 4A3A3AFF 00000200
	s_waitcnt vmcnt(2) lgkmcnt(3)                              // 0000008C06CC: BF890837
	v_dot2_f32_bf16 v0, v69, v10, v2                           // 0000008C06D0: CC1A4000 1C0A1545
	s_waitcnt vmcnt(1)                                         // 0000008C06D8: BF8907F7
	v_dot2_f32_bf16 v1, v73, v10, v3                           // 0000008C06DC: CC1A4001 1C0E1549
	s_waitcnt vmcnt(0)                                         // 0000008C06E4: BF8903F7
	v_dot2_f32_bf16 v2, v77, v10, v4                           // 0000008C06E8: CC1A4002 1C12154D
	v_dual_mov_b32 v11, v15 :: v_dual_mov_b32 v10, v14         // 0000008C06F0: CA10010F 0B0A010E
	s_waitcnt lgkmcnt(2)                                       // 0000008C06F8: BF89FC27
	v_dot2_f32_bf16 v0, v70, v32, v0                           // 0000008C06FC: CC1A4000 1C024146
	v_dot2_f32_bf16 v1, v74, v32, v1                           // 0000008C0704: CC1A4001 1C06414A
	v_dot2_f32_bf16 v2, v78, v32, v2                           // 0000008C070C: CC1A4002 1C0A414E
	v_dual_mov_b32 v9, v13 :: v_dual_mov_b32 v8, v12           // 0000008C0714: CA10010D 0908010C
	s_waitcnt lgkmcnt(1)                                       // 0000008C071C: BF89FC17
	v_dot2_f32_bf16 v0, v71, v41, v0                           // 0000008C0720: CC1A4000 1C025347
	v_dot2_f32_bf16 v1, v75, v41, v1                           // 0000008C0728: CC1A4001 1C06534B
	v_dot2_f32_bf16 v2, v79, v41, v2                           // 0000008C0730: CC1A4002 1C0A534F
	v_mov_b32_e32 v32, v31                                     // 0000008C0738: 7E40031F
	s_waitcnt lgkmcnt(0)                                       // 0000008C073C: BF89FC07
	v_dot2_f32_bf16 v0, v72, v42, v0                           // 0000008C0740: CC1A4000 1C025548
	v_dot2_f32_bf16 v1, v76, v42, v1                           // 0000008C0748: CC1A4001 1C06554C
	v_dot2_f32_bf16 v2, v80, v42, v2                           // 0000008C0750: CC1A4002 1C0A5550
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008C0758: BF870193
	v_fmac_f32_e32 v28, v82, v0                                // 0000008C075C: 56380152
	v_fmac_f32_e32 v27, v82, v1                                // 0000008C0760: 56360352
	s_delay_alu instid0(VALU_DEP_3)                            // 0000008C0764: BF870003
	v_fmac_f32_e32 v24, v82, v2                                // 0000008C0768: 56300552
	v_dual_mov_b32 v0, v33 :: v_dual_mov_b32 v1, v34           // 0000008C076C: CA100121 00000122
	v_dual_mov_b32 v2, v35 :: v_dual_mov_b32 v3, v36           // 0000008C0774: CA100123 02020124
	v_dual_mov_b32 v4, v37 :: v_dual_mov_b32 v5, v38           // 0000008C077C: CA100125 04040126
	v_dual_mov_b32 v6, v39 :: v_dual_mov_b32 v7, v40           // 0000008C0784: CA100127 06060128
	s_and_not1_b32 exec_lo, exec_lo, s7                        // 0000008C078C: 917E077E
	s_cbranch_execz 28                                         // 0000008C0790: BFA5001C <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0xa04>
	s_waitcnt vmcnt(0)                                         // 0000008C0794: BF8903F7
	v_dual_mov_b32 v13, v9 :: v_dual_add_nc_u32 v30, 32, v30   // 0000008C0798: CA200109 0D1E3CA0
	v_dual_mov_b32 v12, v8 :: v_dual_mov_b32 v15, v11          // 0000008C07A0: CA100108 0C0E010B
	v_mov_b32_e32 v14, v10                                     // 0000008C07A8: 7E1C030A
	s_delay_alu instid0(VALU_DEP_3)                            // 0000008C07AC: BF870003
	.long 0xd4430004                                           // 0000008C07B0: D4430004
	v_cndmask_b32_e32 v1, s6, v30, vcc_lo                      // 0000008C07B4: 02023C06
	s_mov_b32 s18, exec_lo                                     // 0000008C07B8: BE92007E
	.long 0xd4c4007e                                           // 0000008C07BC: D4C4007E
	v_cndmask_b32_e32 v1, s6, v30, vcc_lo                      // 0000008C07C0: 02023C06
	s_cbranch_execz 65235                                      // 0000008C07C4: BFA5FED3 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x514>
	.long 0xd7006a0c                                           // 0000008C07C8: D7006A0C
	v_cndmask_b32_e32 v1, v18, v29, vcc_lo                     // 0000008C07CC: 02023B12
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008C07D0: BF870001
	v_add_co_ci_u32_e64 v13, null, 0, v26, vcc_lo              // 0000008C07D4: D5207C0D 01AA3480
	v_cmp_ne_u32_e32 vcc_lo, 1, v25                            // 0000008C07DC: 7C9A3281
	v_mov_b32_e32 v31, v32                                     // 0000008C07E0: 7E3E0320
	global_load_b128 v[12:15], v[12:13], off                   // 0000008C07E4: DC5E0000 0C7C000C
	s_cbranch_vccnz 65225                                      // 0000008C07EC: BFA4FEC9 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x514>
	global_load_d16_b16 v31, v[21:22], off                     // 0000008C07F0: DC820000 1F7C0015
	s_waitcnt vmcnt(0)                                         // 0000008C07F8: BF8903F7
	v_cvt_f32_f16_e32 v31, v31                                 // 0000008C07FC: 7E3E171F
	s_branch 65220                                             // 0000008C0800: BFA0FEC4 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x514>
	s_or_b32 exec_lo, exec_lo, s7                              // 0000008C0804: 8C7E077E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008C0808: BF8700A9
	s_or_b32 exec_lo, exec_lo, s5                              // 0000008C080C: 8C7E057E
	.long 0xd71f0000                                           // 0000008C0810: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000008C0814: 020100C1
	v_xor_b32_e32 v1, 16, v0                                   // 0000008C0818: 3A020090
	v_xor_b32_e32 v4, 8, v0                                    // 0000008C081C: 3A080088
	v_xor_b32_e32 v7, 4, v0                                    // 0000008C0820: 3A0E0084
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000008C0824: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v1                            // 0000008C0828: 7C9802A0
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 0000008C082C: 02020300
	v_cmp_gt_u32_e32 vcc_lo, 32, v4                            // 0000008C0830: 7C9808A0
	v_cndmask_b32_e32 v4, v0, v4, vcc_lo                       // 0000008C0834: 02080900
	v_cmp_gt_u32_e32 vcc_lo, 32, v7                            // 0000008C0838: 7C980EA0
	s_delay_alu instid0(VALU_DEP_2)                            // 0000008C083C: BF870002
	v_lshlrev_b32_e32 v4, 2, v4                                // 0000008C0840: 30080882
	v_lshlrev_b32_e32 v1, 2, v1                                // 0000008C0844: 30020282
	ds_bpermute_b32 v2, v1, v28                                // 0000008C0848: DACC0000 02001C01
	s_waitcnt lgkmcnt(0)                                       // 0000008C0850: BF89FC07
	v_add_f32_e32 v2, v28, v2                                  // 0000008C0854: 0604051C
	ds_bpermute_b32 v3, v1, v27                                // 0000008C0858: DACC0000 03001B01
	ds_bpermute_b32 v1, v1, v24                                // 0000008C0860: DACC0000 01001801
	ds_bpermute_b32 v5, v4, v2                                 // 0000008C0868: DACC0000 05000204
	v_cndmask_b32_e32 v7, v0, v7, vcc_lo                       // 0000008C0870: 020E0F00
	s_waitcnt lgkmcnt(0)                                       // 0000008C0874: BF89FC07
	v_dual_add_f32 v3, v27, v3 :: v_dual_add_f32 v2, v2, v5    // 0000008C0878: C908071B 03020B02
	v_add_f32_e32 v1, v24, v1                                  // 0000008C0880: 06020318
	ds_bpermute_b32 v6, v4, v3                                 // 0000008C0884: DACC0000 06000304
	ds_bpermute_b32 v4, v4, v1                                 // 0000008C088C: DACC0000 04000104
	s_waitcnt lgkmcnt(1)                                       // 0000008C0894: BF89FC17
	v_add_f32_e32 v3, v3, v6                                   // 0000008C0898: 06060D03
	s_waitcnt lgkmcnt(0)                                       // 0000008C089C: BF89FC07
	v_add_f32_e32 v1, v1, v4                                   // 0000008C08A0: 06020901
	v_lshlrev_b32_e32 v7, 2, v7                                // 0000008C08A4: 300E0E82
	ds_bpermute_b32 v4, v7, v2                                 // 0000008C08A8: DACC0000 04000207
	ds_bpermute_b32 v6, v7, v1                                 // 0000008C08B0: DACC0000 06000107
	s_waitcnt lgkmcnt(1)                                       // 0000008C08B8: BF89FC17
	v_add_f32_e32 v2, v2, v4                                   // 0000008C08BC: 06040902
	s_waitcnt lgkmcnt(0)                                       // 0000008C08C0: BF89FC07
	v_add_f32_e32 v4, v1, v6                                   // 0000008C08C4: 06080D01
	ds_bpermute_b32 v5, v7, v3                                 // 0000008C08C8: DACC0000 05000307
	v_xor_b32_e32 v7, 2, v0                                    // 0000008C08D0: 3A0E0082
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008C08D4: BF8700A1
	v_cmp_gt_u32_e32 vcc_lo, 32, v7                            // 0000008C08D8: 7C980EA0
	v_cndmask_b32_e32 v7, v0, v7, vcc_lo                       // 0000008C08DC: 020E0F00
	v_lshlrev_b32_e32 v7, 2, v7                                // 0000008C08E0: 300E0E82
	s_waitcnt lgkmcnt(0)                                       // 0000008C08E4: BF89FC07
	v_add_f32_e32 v3, v3, v5                                   // 0000008C08E8: 06060B03
	ds_bpermute_b32 v6, v7, v4                                 // 0000008C08EC: DACC0000 06000407
	s_waitcnt lgkmcnt(0)                                       // 0000008C08F4: BF89FC07
	v_add_f32_e32 v4, v4, v6                                   // 0000008C08F8: 06080D04
	ds_bpermute_b32 v1, v7, v2                                 // 0000008C08FC: DACC0000 01000207
	ds_bpermute_b32 v5, v7, v3                                 // 0000008C0904: DACC0000 05000307
	v_xor_b32_e32 v7, 1, v0                                    // 0000008C090C: 3A0E0081
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000008C0910: BF870131
	v_cmp_gt_u32_e32 vcc_lo, 32, v7                            // 0000008C0914: 7C980EA0
	v_cndmask_b32_e32 v0, v0, v7, vcc_lo                       // 0000008C0918: 02000F00
	v_cmp_eq_u32_e32 vcc_lo, 0, v23                            // 0000008C091C: 7C942E80
	v_lshlrev_b32_e32 v7, 2, v0                                // 0000008C0920: 300E0082
	s_and_b32 s2, vcc_lo, s2                                   // 0000008C0924: 8B02026A
	s_waitcnt lgkmcnt(1)                                       // 0000008C0928: BF89FC17
	v_add_f32_e32 v1, v2, v1                                   // 0000008C092C: 06020302
	s_waitcnt lgkmcnt(0)                                       // 0000008C0930: BF89FC07
	v_add_f32_e32 v0, v3, v5                                   // 0000008C0934: 06000B03
	ds_bpermute_b32 v5, v7, v4                                 // 0000008C0938: DACC0000 05000407
	ds_bpermute_b32 v2, v7, v1                                 // 0000008C0940: DACC0000 02000107
	ds_bpermute_b32 v3, v7, v0                                 // 0000008C0948: DACC0000 03000007
	s_and_saveexec_b32 s3, s2                                  // 0000008C0950: BE832002
	s_cbranch_execz 85                                         // 0000008C0954: BFA50055 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0xcac>
	v_ashrrev_i32_e32 v6, 31, v17                              // 0000008C0958: 340C229F
	s_load_b64 s[2:3], s[0:1], 0x40                            // 0000008C095C: F4040080 F8000040
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000008C0964: BF890007
	v_dual_mov_b32 v10, s12 :: v_dual_add_f32 v3, v0, v3       // 0000008C0968: CA08000C 0A020700
	v_add_f32_e32 v8, v4, v5                                   // 0000008C0970: 06100B04
	v_lshrrev_b32_e32 v6, 23, v6                               // 0000008C0974: 320C0C97
	.long 0x7f163880                                           // 0000008C0978: 7F163880
	s_lshr_b32 s1, s17, 31                                     // 0000008C097C: 85019F11
	.long 0x7e163983                                           // 0000008C0980: 7E163983
	v_mov_b32_e32 v9, s13                                      // 0000008C0984: 7E12020D
	.long 0xd7006a06                                           // 0000008C0988: D7006A06
	v_cndmask_b32_e32 v1, v16, v6, vcc_lo                      // 0000008C098C: 02020D10
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000008C0990: BF870111
	v_add_co_ci_u32_e64 v7, null, 0, v17, vcc_lo               // 0000008C0994: D5207C07 01AA2280
	v_and_b32_e32 v6, 0xfffffe00, v6                           // 0000008C099C: 360C0CFF FFFFFE00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C09A4: BF870091
	.long 0xd7016a04                                           // 0000008C09A8: D7016A04
	v_cndmask_b32_e32 v1, v16, v6, vcc_lo                      // 0000008C09AC: 02020D10
	v_sub_co_ci_u32_e64 v5, null, v17, v7, vcc_lo              // 0000008C09B0: D5217C05 01AA0F11
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000008C09B8: BF870112
	.long 0xd7000000                                           // 0000008C09BC: D7000000
	v_cndmask_b32_e32 v1, 0xffffff00, v4, vcc_lo               // 0000008C09C0: 020208FF FFFFFF00
	v_cmp_gt_i64_e32 vcc_lo, 0x100, v[4:5]                     // 0000008C09C8: 7CA808FF 00000100
	v_add_f32_e32 v2, v1, v2                                   // 0000008C09D0: 06040501
	v_add_co_ci_u32_e64 v1, null, -1, v5, s0                   // 0000008C09D4: D5207C01 00020AC1
	s_add_u32 s0, s16, s1                                      // 0000008C09DC: 80000110
	s_addc_u32 s1, s17, 0                                      // 0000008C09E0: 82018011
	v_dual_cndmask_b32 v0, v0, v4 :: v_dual_cndmask_b32 v1, v1, v5// 0000008C09E4: CA520900 00000B01
	v_cndmask_b32_e32 v5, s2, v10, vcc_lo                      // 0000008C09EC: 020A1402
	v_cndmask_b32_e32 v9, s3, v9, vcc_lo                       // 0000008C09F0: 02121203
	.long 0x7e083982                                           // 0000008C09F4: 7E083982
	.long 0x7f08398b                                           // 0000008C09F8: 7F08398B
	.long 0xd73c0000                                           // 0000008C09FC: D73C0000
	v_cndmask_b32_e32 v1, 1, v0, vcc_lo                        // 0000008C0A00: 02020081
	.long 0xd7006a05                                           // 0000008C0A04: D7006A05
	v_cndmask_b32_e32 v1, v5, v6, vcc_lo                       // 0000008C0A08: 02020D05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000008C0A0C: BF870211
	v_add_co_ci_u32_e64 v6, null, v9, v7, vcc_lo               // 0000008C0A10: D5207C06 01AA0F09
	v_and_b32_e32 v4, 1, v4                                    // 0000008C0A18: 36080881
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000008C0A1C: BF870223
	.long 0xd7006a00                                           // 0000008C0A20: D7006A00
	v_cndmask_b32_e32 v1, v5, v0, vcc_lo                       // 0000008C0A24: 02020105
	v_and_b32_e32 v10, 1, v11                                  // 0000008C0A28: 36141681
	v_add_co_ci_u32_e64 v1, null, v6, v1, vcc_lo               // 0000008C0A2C: D5207C01 01AA0306
	s_and_b32 s2, s0, -2                                       // 0000008C0A34: 8B02C200
	v_add3_u32 v7, v2, v4, 0x7fff                              // 0000008C0A38: D6550007 03FE0902 00007FFF
	.long 0xd7006a02                                           // 0000008C0A44: D7006A02
	v_cndmask_b32_e32 v0, v0, v2, vcc_lo                       // 0000008C0A48: 02000500
	v_bfe_u32 v4, v8, 16, 1                                    // 0000008C0A4C: D6100004 02052108
	v_add3_u32 v6, v3, v10, 0x7fff                             // 0000008C0A54: D6550006 03FE1503 00007FFF
	v_add_co_ci_u32_e64 v3, null, s1, v1, vcc_lo               // 0000008C0A60: D5207C03 01AA0201
	s_lshl_b64 s[0:1], s[0:1], 1                               // 0000008C0A68: 84808100
	v_add3_u32 v8, v8, v4, 0x7fff                              // 0000008C0A6C: D6550008 03FE0908 00007FFF
	s_and_b32 s0, s0, -4                                       // 0000008C0A78: 8B00C400
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C0A7C: BF870099
	.long 0xd7006a04                                           // 0000008C0A80: D7006A04
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 0000008C0A84: 02000100
	v_add_co_ci_u32_e64 v5, null, s1, v1, vcc_lo               // 0000008C0A88: D5207C05 01AA0201
	s_clause 0x2                                               // 0000008C0A90: BF850002
	global_store_d16_hi_b16 v[0:1], v7, off                    // 0000008C0A94: DC960000 007C0700
	global_store_d16_hi_b16 v[2:3], v6, off                    // 0000008C0A9C: DC960000 007C0602
	global_store_d16_hi_b16 v[4:5], v8, off                    // 0000008C0AA4: DC960000 007C0804
	s_endpgm                                                   // 0000008C0AAC: BFB00000
		...

