00000000007c1600 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb0ELi1ELi0EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb0ELi1ELi0EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 0000007C1600: F4100100 F8000000
	s_ashr_i32 s3, s2, 31                                      // 0000007C1608: 86039F02
	v_lshrrev_b32_e32 v2, 2, v0                                // 0000007C160C: 32040082
	s_lshl_b64 s[2:3], s[2:3], 3                               // 0000007C1610: 84828302
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007C1614: BF8701A9
	v_dual_mov_b32 v10, s3 :: v_dual_and_b32 v1, 15, v0        // 0000007C1618: CA240003 0A00008F
	.long 0x7f103880                                           // 0000007C1620: 7F103880
	v_and_b32_e32 v2, 60, v2                                   // 0000007C1624: 360404BC
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007C1628: BF870003
	v_dual_mov_b32 v18, 0 :: v_dual_lshlrev_b32 v1, 2, v1      // 0000007C162C: CA220080 12000282
	v_dual_mov_b32 v3, 0 :: v_dual_and_b32 v16, 31, v0         // 0000007C1634: CA240080 0310009F
	v_mov_b32_e32 v17, 0                                       // 0000007C163C: 7E220280
	s_waitcnt lgkmcnt(0)                                       // 0000007C1640: BF89FC07
	s_clause 0x1                                               // 0000007C1644: BF850001
	global_load_b32 v4, v1, s[4:5]                             // 0000007C1648: DC520000 04040001
	global_load_b32 v7, v2, s[4:5]                             // 0000007C1650: DC520000 07040002
	v_lshrrev_b32_e32 v2, 5, v0                                // 0000007C1658: 32040085
	s_add_u32 s14, s4, s14                                     // 0000007C165C: 800E0E04
	s_addc_u32 s15, s5, s15                                    // 0000007C1660: 820F0F05
	v_mov_b32_e32 v1, 0                                        // 0000007C1664: 7E020280
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007C1668: BF870002
	v_or_b32_e32 v9, s2, v2                                    // 0000007C166C: 38120402
	s_lshr_b32 s2, s11, 31                                     // 0000007C1670: 85029F0B
	v_mov_b32_e32 v2, 0                                        // 0000007C1674: 7E040280
	s_add_u32 s20, s10, s2                                     // 0000007C1678: 8014020A
	s_addc_u32 s21, s11, 0                                     // 0000007C167C: 8215800B
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[9:10]                 // 0000007C1680: 7CA8120C
	s_ashr_i32 s22, s11, 31                                    // 0000007C1684: 86169F0B
	v_cndmask_b32_e32 v11, 0, v9, vcc_lo                       // 0000007C1688: 02161280
	v_cndmask_b32_e64 v14, 0, s3, vcc_lo                       // 0000007C168C: D501000E 01A80680
	s_ashr_i64 s[2:3], s[20:21], 1                             // 0000007C1694: 86828114
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 0000007C1698: BF870481
	.long 0xd72c0014                                           // 0000007C169C: D72C0014
	v_cndmask_b32_e32 v0, v14, v2, vcc_lo                      // 0000007C16A0: 0200050E
	.long 0xd72c000e                                           // 0000007C16A4: D72C000E
	v_cndmask_b32_e32 v1, s18, v14, vcc_lo                     // 0000007C16A8: 02021C12
	s_waitcnt vmcnt(1)                                         // 0000007C16AC: BF8907F7
	v_bfe_u32 v12, v4, 16, 1                                   // 0000007C16B0: D610000C 02052104
	s_waitcnt vmcnt(0)                                         // 0000007C16B8: BF8903F7
	v_bfe_u32 v19, v7, 16, 1                                   // 0000007C16BC: D6100013 02052107
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007C16C4: BF870112
	v_add3_u32 v4, v4, v12, 0x7fff                             // 0000007C16C8: D6550004 03FE1904 00007FFF
	v_add3_u32 v7, v7, v19, 0x7fff                             // 0000007C16D4: D6550007 03FE2707 00007FFF
	v_lshlrev_b32_e32 v19, 2, v0                               // 0000007C16E0: 30260082
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007C16E4: BF870003
	.long 0x7e103984                                           // 0000007C16E8: 7E103984
	v_mov_b32_e32 v4, 0                                        // 0000007C16EC: 7E080280
	.long 0xd72c000d                                           // 0000007C16F0: D72C000D
	v_cndmask_b32_e32 v1, s19, v11, vcc_lo                     // 0000007C16F4: 02021613
	v_mad_u64_u32 v[5:6], null, s18, v11, 0                    // 0000007C16F8: D6FE7C05 02021612
	.long 0xd72c000f                                           // 0000007C1700: D72C000F
	v_cndmask_b32_e32 v0, v11, v3, vcc_lo                      // 0000007C1704: 0200070B
	v_mad_u64_u32 v[11:12], null, v11, s2, s[14:15]            // 0000007C1708: D6FE7C0B 0038050B
	s_lshr_b32 s19, s22, 27                                    // 0000007C1710: 85139B16
	v_and_or_b32 v7, 0xffff0000, v7, v8                        // 0000007C1714: D6570007 04220EFF FFFF0000
	s_add_u32 s14, s10, s19                                    // 0000007C1720: 800E130A
	s_addc_u32 s15, s11, 0                                     // 0000007C1724: 820F800B
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000007C1728: BF870009
	s_lshr_b64 s[14:15], s[14:15], 5                           // 0000007C172C: 858E850E
	v_add3_u32 v6, v6, v14, v13                                // 0000007C1730: D6550006 04361D06
	.long 0xd4440002                                           // 0000007C1738: D4440002
	v_cndmask_b32_e32 v1, s14, v16, vcc_lo                     // 0000007C173C: 0202200E
	v_add3_u32 v0, v20, v12, v15                               // 0000007C1740: D6550000 043E1914
	ds_store_b32 v19, v7                                       // 0000007C1748: D8340000 00000713
	s_waitcnt lgkmcnt(0)                                       // 0000007C1750: BF89FC07
	s_barrier                                                  // 0000007C1754: BFBD0000
	buffer_gl0_inv                                             // 0000007C1758: E0AC0000 00000000
	s_and_saveexec_b32 s15, s2                                 // 0000007C1760: BE8F2002
	s_cbranch_execz 26                                         // 0000007C1764: BFA5001A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb0ELi1ELi0EEEvPKhPKtPvlllllS6_f+0x1d0>
	s_add_u32 s3, s4, s16                                      // 0000007C1768: 80031004
	s_addc_u32 s18, s5, s17                                    // 0000007C176C: 82121105
	v_lshlrev_b32_e32 v1, 1, v16                               // 0000007C1770: 30022081
	.long 0xd7000302                                           // 0000007C1774: D7000302
	v_cndmask_b32_e32 v1, s3, v5, vcc_lo                       // 0000007C1778: 02020A03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007C177C: BF8701A1
	v_add_co_ci_u32_e64 v3, null, s18, v6, s3                  // 0000007C1780: D5207C03 000E0C12
	v_lshlrev_b32_e32 v4, 4, v16                               // 0000007C1788: 30082084
	.long 0xd7000301                                           // 0000007C178C: D7000301
	v_cndmask_b32_e32 v1, v2, v1, vcc_lo                       // 0000007C1790: 02020302
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007C1794: BF870191
	v_add_co_ci_u32_e64 v2, null, 0, v3, s3                    // 0000007C1798: D5207C02 000E0680
	.long 0xd7000303                                           // 0000007C17A0: D7000303
	v_cndmask_b32_e32 v1, v11, v4, vcc_lo                      // 0000007C17A4: 0202090B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007C17A8: BF870001
	v_add_co_ci_u32_e64 v4, null, 0, v0, s3                    // 0000007C17AC: D5207C04 000E0080
	s_clause 0x1                                               // 0000007C17B4: BF850001
	global_load_d16_b16 v7, v[1:2], off                        // 0000007C17B8: DC820000 077C0001
	global_load_b128 v[1:4], v[3:4], off                       // 0000007C17C0: DC5E0000 017C0003
	s_waitcnt vmcnt(1)                                         // 0000007C17C8: BF8907F7
	v_cvt_f32_f16_e32 v18, v7                                  // 0000007C17CC: 7E241707
	s_or_b32 exec_lo, exec_lo, s15                             // 0000007C17D0: 8C7E0F7E
	v_mov_b32_e32 v19, 0                                       // 0000007C17D4: 7E260280
	s_and_saveexec_b32 s15, s2                                 // 0000007C17D8: BE8F2002
	s_cbranch_execz 281                                        // 0000007C17DC: BFA50119 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb0ELi1ELi0EEEvPKhPKtPvlllllS6_f+0x644>
	v_dual_mov_b32 v22, v18 :: v_dual_lshlrev_b32 v7, 1, v16   // 0000007C17E0: CA220112 16062081
	.long 0xd7000205                                           // 0000007C17E8: D7000205
	v_cndmask_b32_e32 v1, s16, v5, vcc_lo                      // 0000007C17EC: 02020A10
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007C17F0: BF8701A1
	v_add_co_ci_u32_e64 v6, null, s17, v6, s2                  // 0000007C17F4: D5207C06 000A0C11
	v_dual_mov_b32 v13, 0 :: v_dual_lshlrev_b32 v12, 5, v16    // 0000007C17FC: CA220080 0D0C2085
	.long 0xd7000205                                           // 0000007C1804: D7000205
	v_cndmask_b32_e32 v1, v5, v7, vcc_lo                       // 0000007C1808: 02020F05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007C180C: BF8701A1
	v_add_co_ci_u32_e64 v6, null, 0, v6, s2                    // 0000007C1810: D5207C06 000A0C80
	v_lshl_or_b32 v20, v16, 4, 0x200                           // 0000007C1818: D6560014 03FD0910 00000200
	.long 0xd7000205                                           // 0000007C1824: D7000205
	v_cndmask_b32_e32 v1, s4, v5, vcc_lo                       // 0000007C1828: 02020A04
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007C182C: BF8701A1
	v_add_co_ci_u32_e64 v6, null, s5, v6, s2                   // 0000007C1830: D5207C06 000A0C05
	v_mov_b32_e32 v21, v16                                     // 0000007C1838: 7E2A0310
	.long 0xd700020e                                           // 0000007C183C: D700020E
	v_cndmask_b32_e32 v0, v5, v192, vcc_lo                     // 0000007C1840: 02018105
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007C1844: BF870001
	v_add_co_ci_u32_e64 v15, null, 0, v6, s2                   // 0000007C1848: D5207C0F 000A0C80
	v_mov_b32_e32 v19, v13                                     // 0000007C1850: 7E26030D
	v_mov_b32_e32 v17, v13                                     // 0000007C1854: 7E22030D
	s_mov_b32 s16, 0                                           // 0000007C1858: BE900080
	s_lshl_b64 s[4:5], s[10:11], 1                             // 0000007C185C: 8484810A
	s_branch 222                                               // 0000007C1860: BFA000DE <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb0ELi1ELi0EEEvPKhPKtPvlllllS6_f+0x5dc>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000007C1864: 8C7E0A7E
	.long 0xd73c0017                                           // 0000007C1868: D73C0017
	v_cndmask_b32_e32 v1, 1, v12, vcc_lo                       // 0000007C186C: 02021881
	v_and_b32_e32 v55, 0xff, v1                                // 0000007C1870: 366E02FF 000000FF
	v_lshrrev_b32_e32 v56, 6, v1                               // 0000007C1878: 32700286
	v_lshrrev_b32_e32 v57, 14, v1                              // 0000007C187C: 3272028E
	v_lshrrev_b32_e32 v1, 22, v1                               // 0000007C1880: 32020296
	v_and_b32_e32 v58, 0xff, v2                                // 0000007C1884: 367404FF 000000FF
	.long 0xd700032f                                           // 0000007C188C: D700032F
	v_cndmask_b32_e32 v1, s6, v23, vcc_lo                      // 0000007C1890: 02022E06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007C1894: BF8701A1
	v_add_co_ci_u32_e64 v48, null, s7, v24, s3                 // 0000007C1898: D5207C30 000E3007
	v_lshlrev_b32_e32 v55, 2, v55                              // 0000007C18A0: 306E6E82
	.long 0xd7000333                                           // 0000007C18A4: D7000333
	v_cndmask_b32_e32 v0, v47, v4, vcc_lo                      // 0000007C18A8: 0200092F
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007C18AC: BF870001
	v_add_co_ci_u32_e64 v52, null, s5, v48, s3                 // 0000007C18B0: D5207C34 000E6005
	v_and_b32_e32 v56, 0x3fc, v56                              // 0000007C18B8: 367070FF 000003FC
	ds_load_b32 v55, v55                                       // 0000007C18C0: D8D80000 37000037
	s_clause 0x7                                               // 0000007C18C8: BF850007
	global_load_b128 v[23:26], v[47:48], off                   // 0000007C18CC: DC5E0000 177C002F
	global_load_b128 v[27:30], v[51:52], off                   // 0000007C18D4: DC5E0000 1B7C0033
	global_load_b128 v[31:34], v[47:48], off offset:16         // 0000007C18DC: DC5E0010 1F7C002F
	global_load_b128 v[35:38], v[51:52], off offset:16         // 0000007C18E4: DC5E0010 237C0033
	global_load_b128 v[39:42], v[47:48], off offset:32         // 0000007C18EC: DC5E0020 277C002F
	global_load_b128 v[43:46], v[51:52], off offset:32         // 0000007C18F4: DC5E0020 2B7C0033
	global_load_b128 v[47:50], v[47:48], off offset:48         // 0000007C18FC: DC5E0030 2F7C002F
	global_load_b128 v[51:54], v[51:52], off offset:48         // 0000007C1904: DC5E0030 337C0033
	v_and_b32_e32 v57, 0x3fc, v57                              // 0000007C190C: 367272FF 000003FC
	v_lshrrev_b32_e32 v59, 6, v2                               // 0000007C1914: 32760486
	ds_load_b32 v56, v56                                       // 0000007C1918: D8D80000 38000038
	v_lshrrev_b32_e32 v60, 14, v2                              // 0000007C1920: 3278048E
	v_lshrrev_b32_e32 v2, 22, v2                               // 0000007C1924: 32040496
	ds_load_b32 v57, v57                                       // 0000007C1928: D8D80000 39000039
	v_and_b32_e32 v1, 0x3fc, v1                                // 0000007C1930: 360202FF 000003FC
	v_lshlrev_b32_e32 v58, 2, v58                              // 0000007C1938: 30747482
	v_and_b32_e32 v59, 0x3fc, v59                              // 0000007C193C: 367676FF 000003FC
	v_and_b32_e32 v60, 0x3fc, v60                              // 0000007C1944: 367878FF 000003FC
	v_and_b32_e32 v2, 0x3fc, v2                                // 0000007C194C: 360404FF 000003FC
	ds_load_b32 v1, v1                                         // 0000007C1954: D8D80000 01000001
	ds_load_b32 v58, v58                                       // 0000007C195C: D8D80000 3A00003A
	ds_load_b32 v59, v59                                       // 0000007C1964: D8D80000 3B00003B
	ds_load_b32 v60, v60                                       // 0000007C196C: D8D80000 3C00003C
	ds_load_b32 v2, v2                                         // 0000007C1974: D8D80000 02000002
	s_and_b32 s3, exec_lo, s2                                  // 0000007C197C: 8B03027E
	.long 0xd700020e                                           // 0000007C1980: D700020E
	v_cndmask_b32_e32 v0, v14, v192, vcc_lo                    // 0000007C1984: 0201810E
	v_add_nc_u32_e32 v12, 0x400, v12                           // 0000007C1988: 4A1818FF 00000400
	v_add_nc_u32_e32 v20, 0x200, v20                           // 0000007C1990: 4A2828FF 00000200
	v_add_co_ci_u32_e64 v15, null, 0, v15, s2                  // 0000007C1998: D5207C0F 000A1E80
	s_or_b32 s16, s3, s16                                      // 0000007C19A0: 8C101003
	s_waitcnt vmcnt(7) lgkmcnt(7)                              // 0000007C19A4: BF891C77
	v_dot2_f32_bf16 v23, v23, v55, 0                           // 0000007C19A8: CC1A4017 1A026F17
	s_waitcnt vmcnt(6)                                         // 0000007C19B0: BF891BF7
	v_dot2_f32_bf16 v27, v27, v55, 0                           // 0000007C19B4: CC1A401B 1A026F1B
	v_and_b32_e32 v55, 0xff, v3                                // 0000007C19BC: 366E06FF 000000FF
	s_waitcnt lgkmcnt(6)                                       // 0000007C19C4: BF89FC67
	v_dot2_f32_bf16 v23, v24, v56, v23                         // 0000007C19C8: CC1A4017 1C5E7118
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007C19D0: BF870003
	v_dot2_f32_bf16 v24, v28, v56, v27                         // 0000007C19D4: CC1A4018 1C6E711C
	v_lshrrev_b32_e32 v27, 6, v3                               // 0000007C19DC: 32360686
	v_lshrrev_b32_e32 v28, 14, v3                              // 0000007C19E0: 3238068E
	v_lshrrev_b32_e32 v3, 22, v3                               // 0000007C19E4: 32060696
	s_waitcnt lgkmcnt(5)                                       // 0000007C19E8: BF89FC57
	v_dot2_f32_bf16 v23, v25, v57, v23                         // 0000007C19EC: CC1A4017 1C5E7319
	v_dot2_f32_bf16 v24, v29, v57, v24                         // 0000007C19F4: CC1A4018 1C62731D
	v_and_b32_e32 v25, 0xff, v4                                // 0000007C19FC: 363208FF 000000FF
	v_lshrrev_b32_e32 v29, 6, v4                               // 0000007C1A04: 323A0886
	v_lshrrev_b32_e32 v56, 14, v4                              // 0000007C1A08: 3270088E
	s_waitcnt lgkmcnt(4)                                       // 0000007C1A0C: BF89FC47
	v_dot2_f32_bf16 v23, v26, v1, v23                          // 0000007C1A10: CC1A4017 1C5E031A
	v_dot2_f32_bf16 v1, v30, v1, v24                           // 0000007C1A18: CC1A4001 1C62031E
	v_lshlrev_b32_e32 v24, 2, v55                              // 0000007C1A20: 30306E82
	v_and_b32_e32 v26, 0x3fc, v27                              // 0000007C1A24: 363436FF 000003FC
	v_and_b32_e32 v27, 0x3fc, v28                              // 0000007C1A2C: 363638FF 000003FC
	s_waitcnt vmcnt(5) lgkmcnt(3)                              // 0000007C1A34: BF891437
	v_dot2_f32_bf16 v23, v31, v58, v23                         // 0000007C1A38: CC1A4017 1C5E751F
	s_waitcnt vmcnt(4)                                         // 0000007C1A40: BF8913F7
	v_dot2_f32_bf16 v1, v35, v58, v1                           // 0000007C1A44: CC1A4001 1C067523
	ds_load_b32 v24, v24                                       // 0000007C1A4C: D8D80000 18000018
	ds_load_b32 v26, v26                                       // 0000007C1A54: D8D80000 1A00001A
	ds_load_b32 v27, v27                                       // 0000007C1A5C: D8D80000 1B00001B
	s_waitcnt lgkmcnt(5)                                       // 0000007C1A64: BF89FC57
	v_dot2_f32_bf16 v23, v32, v59, v23                         // 0000007C1A68: CC1A4017 1C5E7720
	v_dot2_f32_bf16 v1, v36, v59, v1                           // 0000007C1A70: CC1A4001 1C067724
	v_lshrrev_b32_e32 v4, 22, v4                               // 0000007C1A78: 32080896
	v_and_b32_e32 v3, 0x3fc, v3                                // 0000007C1A7C: 360606FF 000003FC
	v_lshlrev_b32_e32 v25, 2, v25                              // 0000007C1A84: 30323282
	s_waitcnt lgkmcnt(4)                                       // 0000007C1A88: BF89FC47
	v_dot2_f32_bf16 v23, v33, v60, v23                         // 0000007C1A8C: CC1A4017 1C5E7921
	v_dot2_f32_bf16 v1, v37, v60, v1                           // 0000007C1A94: CC1A4001 1C067925
	v_and_b32_e32 v28, 0x3fc, v29                              // 0000007C1A9C: 36383AFF 000003FC
	v_and_b32_e32 v29, 0x3fc, v56                              // 0000007C1AA4: 363A70FF 000003FC
	v_and_b32_e32 v4, 0x3fc, v4                                // 0000007C1AAC: 360808FF 000003FC
	s_waitcnt lgkmcnt(3)                                       // 0000007C1AB4: BF89FC37
	v_dot2_f32_bf16 v23, v34, v2, v23                          // 0000007C1AB8: CC1A4017 1C5E0522
	v_dot2_f32_bf16 v1, v38, v2, v1                            // 0000007C1AC0: CC1A4001 1C060526
	ds_load_b32 v2, v3                                         // 0000007C1AC8: D8D80000 02000003
	ds_load_b32 v3, v25                                        // 0000007C1AD0: D8D80000 03000019
	ds_load_b32 v25, v28                                       // 0000007C1AD8: D8D80000 1900001C
	ds_load_b32 v28, v29                                       // 0000007C1AE0: D8D80000 1C00001D
	ds_load_b32 v29, v4                                        // 0000007C1AE8: D8D80000 1D000004
	s_waitcnt vmcnt(3) lgkmcnt(7)                              // 0000007C1AF0: BF890C77
	v_dot2_f32_bf16 v4, v39, v24, v23                          // 0000007C1AF4: CC1A4004 1C5E3127
	s_waitcnt vmcnt(2)                                         // 0000007C1AFC: BF890BF7
	v_dot2_f32_bf16 v1, v43, v24, v1                           // 0000007C1B00: CC1A4001 1C06312B
	s_waitcnt lgkmcnt(6)                                       // 0000007C1B08: BF89FC67
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007C1B0C: BF870112
	v_dot2_f32_bf16 v4, v40, v26, v4                           // 0000007C1B10: CC1A4004 1C123528
	v_dot2_f32_bf16 v1, v44, v26, v1                           // 0000007C1B18: CC1A4001 1C06352C
	s_waitcnt lgkmcnt(5)                                       // 0000007C1B20: BF89FC57
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007C1B24: BF870112
	v_dot2_f32_bf16 v4, v41, v27, v4                           // 0000007C1B28: CC1A4004 1C123729
	v_dot2_f32_bf16 v1, v45, v27, v1                           // 0000007C1B30: CC1A4001 1C06372D
	s_waitcnt lgkmcnt(4)                                       // 0000007C1B38: BF89FC47
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007C1B3C: BF870112
	v_dot2_f32_bf16 v4, v42, v2, v4                            // 0000007C1B40: CC1A4004 1C12052A
	v_dot2_f32_bf16 v1, v46, v2, v1                            // 0000007C1B48: CC1A4001 1C06052E
	s_waitcnt vmcnt(1) lgkmcnt(3)                              // 0000007C1B50: BF890437
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000007C1B54: BF870122
	v_dot2_f32_bf16 v2, v47, v3, v4                            // 0000007C1B58: CC1A4002 1C12072F
	s_waitcnt vmcnt(0)                                         // 0000007C1B60: BF8903F7
	v_dot2_f32_bf16 v1, v51, v3, v1                            // 0000007C1B64: CC1A4001 1C060733
	v_dual_mov_b32 v4, v8 :: v_dual_mov_b32 v3, v7             // 0000007C1B6C: CA100108 04020107
	s_waitcnt lgkmcnt(2)                                       // 0000007C1B74: BF89FC27
	v_dot2_f32_bf16 v2, v48, v25, v2                           // 0000007C1B78: CC1A4002 1C0A3330
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000007C1B80: BF870123
	v_dot2_f32_bf16 v1, v52, v25, v1                           // 0000007C1B84: CC1A4001 1C063334
	s_waitcnt lgkmcnt(1)                                       // 0000007C1B8C: BF89FC17
	v_dot2_f32_bf16 v2, v49, v28, v2                           // 0000007C1B90: CC1A4002 1C0A3931
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000007C1B98: BF870122
	v_dot2_f32_bf16 v1, v53, v28, v1                           // 0000007C1B9C: CC1A4001 1C063935
	s_waitcnt lgkmcnt(0)                                       // 0000007C1BA4: BF89FC07
	v_dot2_f32_bf16 v8, v50, v29, v2                           // 0000007C1BA8: CC1A4008 1C0A3B32
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007C1BB0: BF8701A2
	v_dot2_f32_bf16 v23, v54, v29, v1                          // 0000007C1BB4: CC1A4017 1C063B36
	v_dual_mov_b32 v2, v6 :: v_dual_mov_b32 v1, v5             // 0000007C1BBC: CA100106 02000105
	v_fmac_f32_e32 v19, v18, v8                                // 0000007C1BC4: 56261112
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007C1BC8: BF870003
	v_fmac_f32_e32 v17, v18, v23                               // 0000007C1BCC: 56222F12
	v_mov_b32_e32 v18, v22                                     // 0000007C1BD0: 7E240316
	s_and_not1_b32 exec_lo, exec_lo, s16                       // 0000007C1BD4: 917E107E
	s_cbranch_execz 25                                         // 0000007C1BD8: BFA50019 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb0ELi1ELi0EEEvPKhPKtPvlllllS6_f+0x640>
	s_waitcnt vmcnt(0)                                         // 0000007C1BDC: BF8903F7
	v_dual_mov_b32 v6, v2 :: v_dual_add_nc_u32 v21, 32, v21    // 0000007C1BE0: CA200102 06142AA0
	v_dual_mov_b32 v5, v1 :: v_dual_mov_b32 v8, v4             // 0000007C1BE8: CA100101 05080104
	v_mov_b32_e32 v7, v3                                       // 0000007C1BF0: 7E0E0303
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007C1BF4: BF870003
	.long 0xd4430002                                           // 0000007C1BF8: D4430002
	v_cndmask_b32_e32 v1, s14, v21, vcc_lo                     // 0000007C1BFC: 02022A0E
	s_mov_b32 s10, exec_lo                                     // 0000007C1C00: BE8A007E
	.long 0xd4c4007e                                           // 0000007C1C04: D4C4007E
	v_cndmask_b32_e32 v1, s14, v21, vcc_lo                     // 0000007C1C08: 02022A0E
	s_cbranch_execz 65301                                      // 0000007C1C0C: BFA5FF15 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb0ELi1ELi0EEEvPKhPKtPvlllllS6_f+0x264>
	.long 0xd7000305                                           // 0000007C1C10: D7000305
	v_cndmask_b32_e32 v1, v11, v20, vcc_lo                     // 0000007C1C14: 0202290B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007C1C18: BF870001
	v_add_co_ci_u32_e64 v6, null, 0, v0, s3                    // 0000007C1C1C: D5207C06 000E0080
	global_load_d16_b16 v22, v[14:15], off                     // 0000007C1C24: DC820000 167C000E
	global_load_b128 v[5:8], v[5:6], off                       // 0000007C1C2C: DC5E0000 057C0005
	s_waitcnt vmcnt(1)                                         // 0000007C1C34: BF8907F7
	v_cvt_f32_f16_e32 v22, v22                                 // 0000007C1C38: 7E2C1716
	s_branch 65289                                             // 0000007C1C3C: BFA0FF09 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb0ELi1ELi0EEEvPKhPKtPvlllllS6_f+0x264>
	s_or_b32 exec_lo, exec_lo, s16                             // 0000007C1C40: 8C7E107E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007C1C44: BF8700B9
	s_or_b32 exec_lo, exec_lo, s15                             // 0000007C1C48: 8C7E0F7E
	.long 0xd71f0000                                           // 0000007C1C4C: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000007C1C50: 020100C1
	s_waitcnt vmcnt(0)                                         // 0000007C1C54: BF8903F7
	v_xor_b32_e32 v1, 16, v0                                   // 0000007C1C58: 3A020090
	v_xor_b32_e32 v3, 8, v0                                    // 0000007C1C5C: 3A060088
	v_xor_b32_e32 v5, 4, v0                                    // 0000007C1C60: 3A0A0084
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007C1C64: BF870093
	.long 0xd44c0002                                           // 0000007C1C68: D44C0002
	v_cndmask_b32_e32 v1, 32, v1, vcc_lo                       // 0000007C1C6C: 020202A0
	v_cndmask_b32_e64 v1, v0, v1, s2                           // 0000007C1C70: D5010001 000A0300
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007C1C78: BF870114
	.long 0xd44c0002                                           // 0000007C1C7C: D44C0002
	v_cndmask_b32_e32 v1, 32, v3, vcc_lo                       // 0000007C1C80: 020206A0
	v_lshlrev_b32_e32 v1, 2, v1                                // 0000007C1C84: 30020282
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000007C1C88: BF8700D2
	v_cndmask_b32_e64 v3, v0, v3, s2                           // 0000007C1C8C: D5010003 000A0700
	.long 0xd44c0002                                           // 0000007C1C94: D44C0002
	v_cndmask_b32_e32 v1, 32, v5, vcc_lo                       // 0000007C1C98: 02020AA0
	ds_bpermute_b32 v2, v1, v19                                // 0000007C1C9C: DACC0000 02001301
	v_cndmask_b32_e64 v5, v0, v5, s2                           // 0000007C1CA4: D5010005 000A0B00
	s_waitcnt lgkmcnt(0)                                       // 0000007C1CAC: BF89FC07
	v_dual_add_f32 v2, v19, v2 :: v_dual_lshlrev_b32 v5, 2, v5 // 0000007C1CB0: C9220513 02040A82
	v_lshlrev_b32_e32 v3, 2, v3                                // 0000007C1CB8: 30060682
	ds_bpermute_b32 v1, v1, v17                                // 0000007C1CBC: DACC0000 01001101
	ds_bpermute_b32 v4, v3, v2                                 // 0000007C1CC4: DACC0000 04000203
	s_waitcnt lgkmcnt(0)                                       // 0000007C1CCC: BF89FC07
	v_dual_add_f32 v2, v2, v4 :: v_dual_add_f32 v1, v17, v1    // 0000007C1CD0: C9080902 02000311
	ds_bpermute_b32 v3, v3, v1                                 // 0000007C1CD8: DACC0000 03000103
	s_waitcnt lgkmcnt(0)                                       // 0000007C1CE0: BF89FC07
	v_add_f32_e32 v1, v1, v3                                   // 0000007C1CE4: 06020701
	ds_bpermute_b32 v3, v5, v2                                 // 0000007C1CE8: DACC0000 03000205
	ds_bpermute_b32 v4, v5, v1                                 // 0000007C1CF0: DACC0000 04000105
	v_xor_b32_e32 v5, 2, v0                                    // 0000007C1CF8: 3A0A0082
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007C1CFC: BF870091
	.long 0xd44c0002                                           // 0000007C1D00: D44C0002
	v_cndmask_b32_e32 v1, 32, v5, vcc_lo                       // 0000007C1D04: 02020AA0
	v_cndmask_b32_e64 v5, v0, v5, s2                           // 0000007C1D08: D5010005 000A0B00
	s_waitcnt lgkmcnt(0)                                       // 0000007C1D10: BF89FC07
	v_dual_add_f32 v2, v2, v3 :: v_dual_add_f32 v1, v1, v4     // 0000007C1D14: C9080702 02000901
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000007C1D1C: BF8700C2
	v_lshlrev_b32_e32 v5, 2, v5                                // 0000007C1D20: 300A0A82
	ds_bpermute_b32 v3, v5, v2                                 // 0000007C1D24: DACC0000 03000205
	ds_bpermute_b32 v4, v5, v1                                 // 0000007C1D2C: DACC0000 04000105
	v_xor_b32_e32 v5, 1, v0                                    // 0000007C1D34: 3A0A0081
	.long 0xd44c0002                                           // 0000007C1D38: D44C0002
	v_cndmask_b32_e32 v1, 32, v5, vcc_lo                       // 0000007C1D3C: 02020AA0
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000007C1D40: BF870121
	v_cndmask_b32_e64 v0, v0, v5, s2                           // 0000007C1D44: D5010000 000A0B00
	.long 0xd44a0002                                           // 0000007C1D4C: D44A0002
	v_cndmask_b32_e32 v1, 0, v16, vcc_lo                       // 0000007C1D50: 02022080
	v_lshlrev_b32_e32 v5, 2, v0                                // 0000007C1D54: 300A0082
	s_and_b32 s2, s2, vcc_lo                                   // 0000007C1D58: 8B026A02
	s_waitcnt lgkmcnt(1)                                       // 0000007C1D5C: BF89FC17
	v_add_f32_e32 v2, v2, v3                                   // 0000007C1D60: 06040702
	s_waitcnt lgkmcnt(0)                                       // 0000007C1D64: BF89FC07
	v_add_f32_e32 v0, v1, v4                                   // 0000007C1D68: 06000901
	ds_bpermute_b32 v3, v5, v2                                 // 0000007C1D6C: DACC0000 03000205
	ds_bpermute_b32 v1, v5, v0                                 // 0000007C1D74: DACC0000 01000005
	s_and_saveexec_b32 s3, s2                                  // 0000007C1D7C: BE832002
	s_cbranch_execz 118                                        // 0000007C1D80: BFA50076 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb0ELi1ELi0EEEvPKhPKtPvlllllS6_f+0x95c>
	s_waitcnt lgkmcnt(1)                                       // 0000007C1D84: BF89FC17
	v_add_f32_e32 v2, v2, v3                                   // 0000007C1D88: 06040702
	.long 0x7f063880                                           // 0000007C1D8C: 7F063880
	s_waitcnt lgkmcnt(0)                                       // 0000007C1D90: BF89FC07
	v_add_f32_e32 v0, v0, v1                                   // 0000007C1D94: 06000300
	s_load_b32 s0, s[0:1], 0x48                                // 0000007C1D98: F4000000 F8000048
	.long 0x7e023982                                           // 0000007C1DA0: 7E023982
	.long 0x7f023983                                           // 0000007C1DA4: 7F023983
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007C1DA8: BF870091
	v_and_b32_e32 v1, 1, v1                                    // 0000007C1DAC: 36020281
	v_add3_u32 v1, v2, v1, 0x7fff                              // 0000007C1DB0: D6550001 03FE0302 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007C1DBC: BF8700A1
	v_and_b32_e32 v1, 0xffff0000, v1                           // 0000007C1DC0: 360202FF FFFF0000
	s_waitcnt lgkmcnt(0)                                       // 0000007C1DC8: BF89FC07
	v_mul_f32_e32 v1, s0, v1                                   // 0000007C1DCC: 10020200
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007C1DD0: BF870091
	v_mul_f32_e32 v2, 0xbfb8aa3b, v1                           // 0000007C1DD4: 100402FF BFB8AA3B
	v_exp_f32_e32 v2, v2                                       // 0000007C1DDC: 7E044B02
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007C1DE0: BF870095
	v_add_f32_e32 v2, 1.0, v2                                  // 0000007C1DE4: 060404F2
	v_div_scale_f32 v5, null, v2, v2, v1                       // 0000007C1DE8: D6FC7C05 04060502
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000007C1DF0: BF870291
	v_rcp_f32_e32 v7, v5                                       // 0000007C1DF4: 7E0E5505
	v_fma_f32 v11, -v5, v7, 1.0                                // 0000007C1DF8: D613000B 23CA0F05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007C1E00: BF8700A1
	v_fmac_f32_e32 v7, v11, v7                                 // 0000007C1E04: 560E0F0B
	.long 0x7e063980                                           // 0000007C1E08: 7E063980
	v_and_b32_e32 v4, 1, v3                                    // 0000007C1E0C: 36080681
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007C1E10: BF870091
	v_add3_u32 v0, v0, v4, 0x7fff                              // 0000007C1E14: D6550000 03FE0900 00007FFF
	v_and_b32_e32 v0, 0xffff0000, v0                           // 0000007C1E20: 360000FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007C1E28: BF870091
	v_mul_f32_e32 v0, s0, v0                                   // 0000007C1E2C: 10000000
	v_mul_f32_e32 v4, 0xbfb8aa3b, v0                           // 0000007C1E30: 100800FF BFB8AA3B
	v_div_scale_f32 v13, vcc_lo, v1, v2, v1                    // 0000007C1E38: D6FC6A0D 04060501
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000007C1E40: BF870292
	v_exp_f32_e32 v4, v4                                       // 0000007C1E44: 7E084B04
	v_add_f32_e32 v4, 1.0, v4                                  // 0000007C1E48: 060808F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000007C1E4C: BF870121
	v_div_scale_f32 v6, null, v4, v4, v0                       // 0000007C1E50: D6FC7C06 04020904
	v_div_scale_f32 v11, s0, v0, v4, v0                        // 0000007C1E58: D6FC000B 04020900
	v_rcp_f32_e32 v8, v6                                       // 0000007C1E60: 7E105506
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007C1E64: BF870095
	v_fma_f32 v12, -v6, v8, 1.0                                // 0000007C1E68: D613000C 23CA1106
	v_fmac_f32_e32 v8, v12, v8                                 // 0000007C1E70: 5610110C
	v_mul_f32_e32 v12, v13, v7                                 // 0000007C1E74: 10180F0D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007C1E78: BF870112
	v_mul_f32_e32 v14, v11, v8                                 // 0000007C1E7C: 101C110B
	v_fma_f32 v15, -v5, v12, v13                               // 0000007C1E80: D613000F 24361905
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007C1E88: BF870112
	v_fma_f32 v16, -v6, v14, v11                               // 0000007C1E8C: D6130010 242E1D06
	v_fmac_f32_e32 v12, v15, v7                                // 0000007C1E94: 56180F0F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007C1E98: BF870112
	v_fmac_f32_e32 v14, v16, v8                                // 0000007C1E9C: 561C1110
	v_fma_f32 v5, -v5, v12, v13                                // 0000007C1EA0: D6130005 24361905
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007C1EA8: BF870112
	v_fma_f32 v6, -v6, v14, v11                                // 0000007C1EAC: D6130006 242E1D06
	v_div_fmas_f32 v5, v5, v7, v12                             // 0000007C1EB4: D6370005 04320F05
	s_mov_b32 vcc_lo, s0                                       // 0000007C1EBC: BEEA0000
	s_lshl_b64 s[0:1], s[12:13], 1                             // 0000007C1EC0: 8480810C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007C1EC4: BF870112
	v_div_fmas_f32 v6, v6, v8, v14                             // 0000007C1EC8: D6370006 043A1106
	v_div_fixup_f32 v2, v5, v2, v1                             // 0000007C1ED0: D6270002 04060505
	.long 0x7f0a3983                                           // 0000007C1ED8: 7F0A3983
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000007C1EDC: BF870223
	v_div_fixup_f32 v4, v6, v4, v0                             // 0000007C1EE0: D6270004 04020906
	.long 0xd73c0000                                           // 0000007C1EE8: D73C0000
	v_cndmask_b32_e32 v1, 1, v9, vcc_lo                        // 0000007C1EEC: 02021281
	.long 0x7e0a3982                                           // 0000007C1EF0: 7E0A3982
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007C1EF4: BF870113
	.long 0x7e063984                                           // 0000007C1EF8: 7E063984
	v_and_b32_e32 v5, 1, v5                                    // 0000007C1EFC: 360A0A81
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007C1F00: BF870194
	.long 0xd7006a00                                           // 0000007C1F04: D7006A00
	v_cndmask_b32_e32 v1, s8, v0, vcc_lo                       // 0000007C1F08: 02020008
	v_and_b32_e32 v3, 1, v3                                    // 0000007C1F0C: 36060681
	v_add_co_ci_u32_e64 v1, null, s9, v1, vcc_lo               // 0000007C1F10: D5207C01 01AA0209
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000007C1F18: BF870214
	v_add3_u32 v5, v2, v5, 0x7fff                              // 0000007C1F1C: D6550005 03FE0B02 00007FFF
	.long 0xd7006a02                                           // 0000007C1F28: D7006A02
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 0000007C1F2C: 02000100
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000007C1F30: BF870214
	v_add3_u32 v4, v4, v3, 0x7fff                              // 0000007C1F34: D6550004 03FE0704 00007FFF
	v_add_co_ci_u32_e64 v3, null, s1, v1, vcc_lo               // 0000007C1F40: D5207C03 01AA0201
	s_clause 0x1                                               // 0000007C1F48: BF850001
	global_store_d16_hi_b16 v[0:1], v5, off                    // 0000007C1F4C: DC960000 007C0500
	global_store_d16_hi_b16 v[2:3], v4, off                    // 0000007C1F54: DC960000 007C0402
	s_endpgm                                                   // 0000007C1F5C: BFB00000
		...

