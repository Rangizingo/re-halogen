00000000002e8d00 <_ZN7halogen12_GLOBAL__N_16k_lq8wILi5ELi16ELi1EEEvPKhPKtPtll>:
; _ZN7halogen12_GLOBAL__N_16k_lq8wILi5ELi16ELi1EEEvPKhPKtPtll():
	s_clause 0x1                                               // 0000002E8D00: BF850001
	s_load_b64 s[12:13], s[0:1], 0x20                          // 0000002E8D04: F4040300 F8000020
	s_load_b256 s[4:11], s[0:1], null                          // 0000002E8D0C: F40C0100 F8000000
	v_lshrrev_b32_e32 v1, 4, v0                                // 0000002E8D14: 32020084
	s_mov_b32 s3, 0                                            // 0000002E8D18: BE830080
	v_dual_mov_b32 v15, 0 :: v_dual_mov_b32 v6, 0              // 0000002E8D1C: CA100080 0F060080
	s_lshl_b64 s[0:1], s[2:3], 4                               // 0000002E8D24: 84808402
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000002E8D28: BF8701B9
	v_dual_mov_b32 v9, s1 :: v_dual_and_b32 v14, 15, v0        // 0000002E8D2C: CA240001 090E008F
	v_or_b32_e32 v8, s0, v1                                    // 0000002E8D34: 38100200
	v_mov_b32_e32 v25, 0                                       // 0000002E8D38: 7E320280
	v_dual_mov_b32 v5, 0 :: v_dual_lshlrev_b32 v10, 4, v14     // 0000002E8D3C: CA220080 050A1C84
	v_mov_b32_e32 v4, 0                                        // 0000002E8D44: 7E080280
	s_waitcnt lgkmcnt(0)                                       // 0000002E8D48: BF89FC07
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[8:9]                  // 0000002E8D4C: 7CA8100C
	s_ashr_i32 s0, s11, 31                                     // 0000002E8D50: 86009F0B
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000002E8D54: BF870499
	s_lshr_b32 s0, s0, 28                                      // 0000002E8D58: 85009C00
	s_add_u32 s2, s10, s0                                      // 0000002E8D5C: 8002000A
	s_addc_u32 s3, s11, 0                                      // 0000002E8D60: 8203800B
	v_cndmask_b32_e32 v3, 0, v8, vcc_lo                        // 0000002E8D64: 02061080
	v_cndmask_b32_e64 v1, 0, s1, vcc_lo                        // 0000002E8D68: D5010001 01A80280
	s_ashr_i64 s[2:3], s[2:3], 4                               // 0000002E8D70: 86828402
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002E8D74: BF8700A9
	s_add_u32 s0, s2, s10                                      // 0000002E8D78: 80000A02
	s_addc_u32 s1, s3, s11                                     // 0000002E8D7C: 82010B03
	.long 0xd72c0007                                           // 0000002E8D80: D72C0007
	v_cndmask_b32_e32 v0, v1, v0, vcc_lo                       // 0000002E8D84: 02000101
	v_mad_u64_u32 v[1:2], null, v3, s0, 0                      // 0000002E8D88: D6FE7C01 02000103
	.long 0xd72c0003                                           // 0000002E8D90: D72C0003
	v_cndmask_b32_e32 v0, v3, v1, vcc_lo                       // 0000002E8D94: 02000303
	.long 0xd4440000                                           // 0000002E8D98: D4440000
	v_cndmask_b32_e32 v1, s2, v14, vcc_lo                      // 0000002E8D9C: 02021C02
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002E8DA0: BF870193
	.long 0xd7000110                                           // 0000002E8DA4: D7000110
	v_cndmask_b32_e32 v1, s4, v1, vcc_lo                       // 0000002E8DA8: 02020204
	v_add3_u32 v2, v2, v3, v7                                  // 0000002E8DAC: D6550002 041E0702
	v_mov_b32_e32 v7, 0                                        // 0000002E8DB4: 7E0E0280
	s_delay_alu instid0(VALU_DEP_2)                            // 0000002E8DB8: BF870002
	v_add_co_ci_u32_e64 v17, null, s5, v2, s1                  // 0000002E8DBC: D5207C11 00060405
	s_and_saveexec_b32 s3, s0                                  // 0000002E8DC4: BE832000
	s_cbranch_execz 21                                         // 0000002E8DC8: BFA50015 <_ZN7halogen12_GLOBAL__N_16k_lq8wILi5ELi16ELi1EEEvPKhPKtPtll+0x120>
	v_lshlrev_b32_e32 v3, 4, v14                               // 0000002E8DCC: 30061C84
	.long 0xd7000105                                           // 0000002E8DD0: D7000105
	v_cndmask_b32_e32 v0, v16, v10, vcc_lo                     // 0000002E8DD4: 02001510
	v_and_b32_e32 v7, 12, v0                                   // 0000002E8DD8: 360E008C
	v_add_co_ci_u32_e64 v6, null, s11, v17, s1                 // 0000002E8DDC: D5207C06 0006220B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002E8DE4: BF870094
	.long 0xd7000103                                           // 0000002E8DE8: D7000103
	v_cndmask_b32_e32 v1, v16, v3, vcc_lo                      // 0000002E8DEC: 02020710
	v_add_co_ci_u32_e64 v4, null, 0, v17, s1                   // 0000002E8DF0: D5207C04 00062280
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002E8DF8: BF870094
	.long 0xd700010b                                           // 0000002E8DFC: D700010B
	v_cndmask_b32_e32 v1, v5, v7, vcc_lo                       // 0000002E8E00: 02020F05
	v_add_co_ci_u32_e64 v12, null, 0, v6, s1                   // 0000002E8E04: D5207C0C 00060C80
	s_clause 0x1                                               // 0000002E8E0C: BF850001
	global_load_b128 v[4:7], v[3:4], off                       // 0000002E8E10: DC5E0000 047C0003
	global_load_b32 v25, v[11:12], off                         // 0000002E8E18: DC520000 197C000B
	s_or_b32 exec_lo, exec_lo, s3                              // 0000002E8E20: 8C7E037E
	v_dual_mov_b32 v18, 0 :: v_dual_mov_b32 v19, 0             // 0000002E8E24: CA100080 12120080
	v_dual_mov_b32 v20, 0 :: v_dual_mov_b32 v21, 0             // 0000002E8E2C: CA100080 14140080
	s_and_saveexec_b32 s3, s0                                  // 0000002E8E34: BE832000
	s_cbranch_execz 436                                        // 0000002E8E38: BFA501B4 <_ZN7halogen12_GLOBAL__N_16k_lq8wILi5ELi16ELi1EEEvPKhPKtPtll+0x80c>
	v_and_or_b32 v0, v0, 12, 16                                // 0000002E8E3C: D6570000 02411900
	.long 0xd7000001                                           // 0000002E8E44: D7000001
	v_cndmask_b32_e32 v1, s10, v1, vcc_lo                      // 0000002E8E48: 0202020A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000002E8E4C: BF8701A1
	v_add_co_ci_u32_e64 v2, null, s11, v2, s0                  // 0000002E8E50: D5207C02 0002040B
	v_dual_mov_b32 v11, 0 :: v_dual_mov_b32 v22, v14           // 0000002E8E58: CA100080 0B16010E
	.long 0xd7000000                                           // 0000002E8E60: D7000000
	v_cndmask_b32_e32 v1, v1, v0, vcc_lo                       // 0000002E8E64: 02020101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002E8E68: BF870191
	v_add_co_ci_u32_e64 v1, null, 0, v2, s0                    // 0000002E8E6C: D5207C01 00020480
	v_mov_b32_e32 v21, v11                                     // 0000002E8E74: 7E2A030B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002E8E78: BF870093
	.long 0xd700000c                                           // 0000002E8E7C: D700000C
	v_cndmask_b32_e32 v1, s4, v0, vcc_lo                       // 0000002E8E80: 02020004
	v_add_co_ci_u32_e64 v13, null, s5, v1, s0                  // 0000002E8E84: D5207C0D 00020205
	v_mov_b32_e32 v20, v11                                     // 0000002E8E8C: 7E28030B
	v_mov_b32_e32 v19, v11                                     // 0000002E8E90: 7E26030B
	v_mov_b32_e32 v18, v11                                     // 0000002E8E94: 7E24030B
	v_mov_b32_e32 v15, v11                                     // 0000002E8E98: 7E1E030B
	s_mul_i32 s1, s11, 6                                       // 0000002E8E9C: 9601860B
	s_mul_hi_u32 s16, s10, 6                                   // 0000002E8EA0: 9690860A
	s_lshl_b64 s[14:15], s[10:11], 2                           // 0000002E8EA4: 848E820A
	s_add_i32 s16, s16, s1                                     // 0000002E8EA8: 81100110
	s_mul_i32 s18, s10, 6                                      // 0000002E8EAC: 9612860A
	s_mov_b32 s17, 0                                           // 0000002E8EB0: BE910080
	s_lshl_b64 s[4:5], s[10:11], 1                             // 0000002E8EB4: 8484810A
	s_branch 374                                               // 0000002E8EB8: BFA00176 <_ZN7halogen12_GLOBAL__N_16k_lq8wILi5ELi16ELi1EEEvPKhPKtPtll+0x794>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000002E8EBC: 8C7E0A7E
	v_cvt_f32_ubyte0_e32 v26, v4                               // 0000002E8EC0: 7E342304
	s_and_b32 s0, exec_lo, s0                                  // 0000002E8EC4: 8B00007E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002E8EC8: BF870099
	s_or_b32 s17, s0, s17                                      // 0000002E8ECC: 8C111100
	v_fma_mix_f32 v26, v26, v25, v25 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002E8ED0: CC20601A 1466331A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002E8ED8: BF870091
	v_bfe_u32 v27, v26, 16, 1                                  // 0000002E8EDC: D610001B 0205211A
	v_add3_u32 v26, v26, v27, 0x7fff                           // 0000002E8EE4: D655001A 03FE371A 00007FFF
	.long 0x7f363880                                           // 0000002E8EF0: 7F363880
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002E8EF4: BF8700A2
	.long 0x7e36399a                                           // 0000002E8EF8: 7E36399A
	v_cvt_f32_ubyte1_e32 v26, v4                               // 0000002E8EFC: 7E342504
	v_fma_mix_f32 v26, v26, v25, v25 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002E8F00: CC20601A 1466331A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002E8F08: BF870091
	v_bfe_u32 v28, v26, 16, 1                                  // 0000002E8F0C: D610001C 0205211A
	v_add3_u32 v26, v26, v28, 0x7fff                           // 0000002E8F14: D655001A 03FE391A 00007FFF
	v_cvt_f32_ubyte2_e32 v28, v4                               // 0000002E8F20: 7E382704
	v_cvt_f32_ubyte3_e32 v4, v4                                // 0000002E8F24: 7E082904
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002E8F28: BF870193
	v_and_or_b32 v33, 0xffff0000, v26, v27                     // 0000002E8F2C: D6570021 046E34FF FFFF0000
	v_fma_mix_f32 v28, v28, v25, v25 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002E8F38: CC20601C 1466331C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002E8F40: BF870113
	v_fma_mix_f32 v4, v4, v25, v25 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002E8F44: CC206004 14663304
	v_bfe_u32 v29, v28, 16, 1                                  // 0000002E8F4C: D610001D 0205211C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002E8F54: BF870191
	v_add3_u32 v28, v28, v29, 0x7fff                           // 0000002E8F58: D655001C 03FE3B1C 00007FFF
	v_bfe_u32 v29, v4, 16, 1                                   // 0000002E8F64: D610001D 02052104
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000002E8F6C: BF8701A2
	.long 0x7e38399c                                           // 0000002E8F70: 7E38399C
	.long 0x7f38399b                                           // 0000002E8F74: 7F38399B
	v_add3_u32 v4, v4, v29, 0x7fff                             // 0000002E8F78: D6550004 03FE3B04 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002E8F84: BF8700A1
	v_and_or_b32 v34, 0xffff0000, v4, v28                      // 0000002E8F88: D6570022 047208FF FFFF0000
	v_cvt_f32_ubyte0_e32 v4, v5                                // 0000002E8F94: 7E082305
	v_fma_mix_f32 v4, v4, v25, v25 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002E8F98: CC206004 14663304
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002E8FA0: BF870091
	v_bfe_u32 v26, v4, 16, 1                                   // 0000002E8FA4: D610001A 02052104
	v_add3_u32 v4, v4, v26, 0x7fff                             // 0000002E8FAC: D6550004 03FE3504 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002E8FB8: BF8700A1
	.long 0x7e363984                                           // 0000002E8FBC: 7E363984
	v_cvt_f32_ubyte1_e32 v4, v5                                // 0000002E8FC0: 7E082505
	v_fma_mix_f32 v4, v4, v25, v25 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002E8FC4: CC206004 14663304
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002E8FCC: BF870091
	v_bfe_u32 v26, v4, 16, 1                                   // 0000002E8FD0: D610001A 02052104
	v_add3_u32 v4, v4, v26, 0x7fff                             // 0000002E8FD8: D6550004 03FE3504 00007FFF
	v_cvt_f32_ubyte2_e32 v26, v5                               // 0000002E8FE4: 7E342705
	v_cvt_f32_ubyte3_e32 v5, v5                                // 0000002E8FE8: 7E0A2905
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002E8FEC: BF870193
	v_and_or_b32 v35, 0xffff0000, v4, v27                      // 0000002E8FF0: D6570023 046E08FF FFFF0000
	v_fma_mix_f32 v26, v26, v25, v25 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002E8FFC: CC20601A 1466331A
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000002E9004: BF8701A3
	v_fma_mix_f32 v5, v5, v25, v25 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002E9008: CC206005 14663305
	v_cvt_f32_ubyte0_e32 v4, v6                                // 0000002E9010: 7E082306
	v_bfe_u32 v28, v26, 16, 1                                  // 0000002E9014: D610001C 0205211A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002E901C: BF870112
	v_fma_mix_f32 v4, v4, v25, v25 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002E9020: CC206004 14663304
	v_add3_u32 v26, v26, v28, 0x7fff                           // 0000002E9028: D655001A 03FE391A 00007FFF
	v_bfe_u32 v28, v5, 16, 1                                   // 0000002E9034: D610001C 02052105
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000002E903C: BF8701A2
	.long 0x7e34399a                                           // 0000002E9040: 7E34399A
	.long 0x7f34399b                                           // 0000002E9044: 7F34399B
	v_add3_u32 v5, v5, v28, 0x7fff                             // 0000002E9048: D6550005 03FE3905 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002E9054: BF8700A1
	v_and_or_b32 v36, 0xffff0000, v5, v26                      // 0000002E9058: D6570024 046A0AFF FFFF0000
	v_bfe_u32 v5, v4, 16, 1                                    // 0000002E9064: D6100005 02052104
	v_add3_u32 v4, v4, v5, 0x7fff                              // 0000002E906C: D6550004 03FE0B04 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002E9078: BF8700A1
	.long 0x7e363984                                           // 0000002E907C: 7E363984
	v_cvt_f32_ubyte1_e32 v4, v6                                // 0000002E9080: 7E082506
	v_fma_mix_f32 v4, v4, v25, v25 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002E9084: CC206004 14663304
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002E908C: BF870091
	v_bfe_u32 v5, v4, 16, 1                                    // 0000002E9090: D6100005 02052104
	v_add3_u32 v4, v4, v5, 0x7fff                              // 0000002E9098: D6550004 03FE0B04 00007FFF
	v_cvt_f32_ubyte2_e32 v5, v6                                // 0000002E90A4: 7E0A2706
	v_cvt_f32_ubyte3_e32 v6, v6                                // 0000002E90A8: 7E0C2906
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002E90AC: BF870193
	v_and_or_b32 v37, 0xffff0000, v4, v27                      // 0000002E90B0: D6570025 046E08FF FFFF0000
	v_fma_mix_f32 v5, v5, v25, v25 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002E90BC: CC206005 14663305
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000002E90C4: BF8701A3
	v_fma_mix_f32 v6, v6, v25, v25 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002E90C8: CC206006 14663306
	v_cvt_f32_ubyte0_e32 v4, v7                                // 0000002E90D0: 7E082307
	v_bfe_u32 v26, v5, 16, 1                                   // 0000002E90D4: D610001A 02052105
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002E90DC: BF870112
	v_fma_mix_f32 v4, v4, v25, v25 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002E90E0: CC206004 14663304
	v_add3_u32 v5, v5, v26, 0x7fff                             // 0000002E90E8: D6550005 03FE3505 00007FFF
	v_bfe_u32 v26, v6, 16, 1                                   // 0000002E90F4: D610001A 02052106
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000002E90FC: BF8701A2
	.long 0x7e0a3985                                           // 0000002E9100: 7E0A3985
	.long 0x7f0a399b                                           // 0000002E9104: 7F0A399B
	v_add3_u32 v6, v6, v26, 0x7fff                             // 0000002E9108: D6550006 03FE3506 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002E9114: BF8700A1
	v_and_or_b32 v38, 0xffff0000, v6, v5                       // 0000002E9118: D6570026 04160CFF FFFF0000
	v_bfe_u32 v5, v4, 16, 1                                    // 0000002E9124: D6100005 02052104
	v_add3_u32 v4, v4, v5, 0x7fff                              // 0000002E912C: D6550004 03FE0B04 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002E9138: BF8700A1
	.long 0x7e363984                                           // 0000002E913C: 7E363984
	v_cvt_f32_ubyte1_e32 v4, v7                                // 0000002E9140: 7E082507
	v_fma_mix_f32 v4, v4, v25, v25 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002E9144: CC206004 14663304
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002E914C: BF870091
	v_bfe_u32 v5, v4, 16, 1                                    // 0000002E9150: D6100005 02052104
	v_add3_u32 v4, v4, v5, 0x7fff                              // 0000002E9158: D6550004 03FE0B04 00007FFF
	v_cvt_f32_ubyte2_e32 v5, v7                                // 0000002E9164: 7E0A2707
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002E9168: BF870112
	v_and_or_b32 v39, 0xffff0000, v4, v27                      // 0000002E916C: D6570027 046E08FF FFFF0000
	v_fma_mix_f32 v5, v5, v25, v25 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002E9178: CC206005 14663305
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002E9180: BF870091
	v_bfe_u32 v6, v5, 16, 1                                    // 0000002E9184: D6100006 02052105
	v_add3_u32 v5, v5, v6, 0x7fff                              // 0000002E918C: D6550005 03FE0D05 00007FFF
	v_cvt_f32_ubyte3_e32 v6, v7                                // 0000002E9198: 7E0C2907
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002E919C: BF870112
	.long 0x7e0a3985                                           // 0000002E91A0: 7E0A3985
	v_fma_mix_f32 v6, v6, v25, v25 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002E91A4: CC206006 14663306
	.long 0x7f0a399b                                           // 0000002E91AC: 7F0A399B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002E91B0: BF870092
	v_bfe_u32 v7, v6, 16, 1                                    // 0000002E91B4: D6100007 02052106
	v_add3_u32 v6, v6, v7, 0x7fff                              // 0000002E91BC: D6550006 03FE0F06 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000002E91C8: BF870131
	v_and_or_b32 v40, 0xffff0000, v6, v5                       // 0000002E91CC: D6570028 04160CFF FFFF0000
	.long 0xd73c0004                                           // 0000002E91D8: D73C0004
	v_cndmask_b32_e32 v1, 1, v10, vcc_lo                       // 0000002E91DC: 02021481
	v_mov_b32_e32 v10, v24                                     // 0000002E91E0: 7E140318
	.long 0xd700001d                                           // 0000002E91E4: D700001D
	v_cndmask_b32_e32 v1, s6, v4, vcc_lo                       // 0000002E91E8: 02020806
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002E91EC: BF870001
	v_add_co_ci_u32_e64 v30, null, s7, v5, s0                  // 0000002E91F0: D5207C1E 00020A07
	s_clause 0x1                                               // 0000002E91F8: BF850001
	global_load_b128 v[4:7], v[29:30], off                     // 0000002E91FC: DC5E0000 047C001D
	global_load_b128 v[25:28], v[29:30], off offset:16         // 0000002E9204: DC5E0010 197C001D
	s_waitcnt vmcnt(1)                                         // 0000002E920C: BF8907F7
	v_dot2_f32_bf16 v4, v4, v33, 0                             // 0000002E9210: CC1A4004 1A024304
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002E9218: BF870091
	v_dot2_f32_bf16 v4, v5, v34, v4                            // 0000002E921C: CC1A4004 1C124505
	v_dot2_f32_bf16 v4, v6, v35, v4                            // 0000002E9224: CC1A4004 1C124706
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002E922C: BF8700A1
	v_dot2_f32_bf16 v4, v7, v36, v4                            // 0000002E9230: CC1A4004 1C124907
	s_waitcnt vmcnt(0)                                         // 0000002E9238: BF8903F7
	v_dot2_f32_bf16 v4, v25, v37, v4                           // 0000002E923C: CC1A4004 1C124B19
	.long 0xd7000019                                           // 0000002E9244: D7000019
	v_cndmask_b32_e32 v0, v29, v4, vcc_lo                      // 0000002E9248: 0200091D
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000002E924C: BF8701B2
	v_dot2_f32_bf16 v4, v26, v38, v4                           // 0000002E9250: CC1A4004 1C124D1A
	v_add_co_ci_u32_e64 v26, null, s5, v30, s0                 // 0000002E9258: D5207C1A 00023C05
	.long 0xd700001f                                           // 0000002E9260: D700001F
	v_cndmask_b32_e32 v0, v29, v14, vcc_lo                     // 0000002E9264: 02001D1D
	v_dot2_f32_bf16 v4, v27, v39, v4                           // 0000002E9268: CC1A4004 1C124F1B
	v_add_co_ci_u32_e64 v32, null, s15, v30, s0                // 0000002E9270: D5207C20 00023C0F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002E9278: BF870092
	v_dot2_f32_bf16 v4, v28, v40, v4                           // 0000002E927C: CC1A4004 1C12511C
	v_add_f32_e32 v21, v21, v4                                 // 0000002E9284: 062A0915
	s_clause 0x1                                               // 0000002E9288: BF850001
	global_load_b128 v[4:7], v[25:26], off                     // 0000002E928C: DC5E0000 047C0019
	global_load_b128 v[25:28], v[25:26], off offset:16         // 0000002E9294: DC5E0010 197C0019
	s_waitcnt vmcnt(1)                                         // 0000002E929C: BF8907F7
	v_dot2_f32_bf16 v4, v4, v33, 0                             // 0000002E92A0: CC1A4004 1A024304
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002E92A8: BF870091
	v_dot2_f32_bf16 v4, v5, v34, v4                            // 0000002E92AC: CC1A4004 1C124505
	v_dot2_f32_bf16 v4, v6, v35, v4                            // 0000002E92B4: CC1A4004 1C124706
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002E92BC: BF8700A1
	v_dot2_f32_bf16 v4, v7, v36, v4                            // 0000002E92C0: CC1A4004 1C124907
	s_waitcnt vmcnt(0)                                         // 0000002E92C8: BF8903F7
	v_dot2_f32_bf16 v4, v25, v37, v4                           // 0000002E92CC: CC1A4004 1C124B19
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002E92D4: BF870091
	v_dot2_f32_bf16 v4, v26, v38, v4                           // 0000002E92D8: CC1A4004 1C124D1A
	v_dot2_f32_bf16 v4, v27, v39, v4                           // 0000002E92E0: CC1A4004 1C124F1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002E92E8: BF870091
	v_dot2_f32_bf16 v4, v28, v40, v4                           // 0000002E92EC: CC1A4004 1C12511C
	v_add_f32_e32 v20, v20, v4                                 // 0000002E92F4: 06280914
	s_clause 0x1                                               // 0000002E92F8: BF850001
	global_load_b128 v[4:7], v[31:32], off                     // 0000002E92FC: DC5E0000 047C001F
	global_load_b128 v[25:28], v[31:32], off offset:16         // 0000002E9304: DC5E0010 197C001F
	s_waitcnt vmcnt(1)                                         // 0000002E930C: BF8907F7
	v_dot2_f32_bf16 v4, v4, v33, 0                             // 0000002E9310: CC1A4004 1A024304
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002E9318: BF870091
	v_dot2_f32_bf16 v4, v5, v34, v4                            // 0000002E931C: CC1A4004 1C124505
	v_dot2_f32_bf16 v4, v6, v35, v4                            // 0000002E9324: CC1A4004 1C124706
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002E932C: BF8700A1
	v_dot2_f32_bf16 v4, v7, v36, v4                            // 0000002E9330: CC1A4004 1C124907
	s_waitcnt vmcnt(0)                                         // 0000002E9338: BF8903F7
	v_dot2_f32_bf16 v4, v25, v37, v4                           // 0000002E933C: CC1A4004 1C124B19
	.long 0xd7000019                                           // 0000002E9344: D7000019
	v_cndmask_b32_e32 v0, v29, v18, vcc_lo                     // 0000002E9348: 0200251D
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002E934C: BF870122
	v_dot2_f32_bf16 v4, v26, v38, v4                           // 0000002E9350: CC1A4004 1C124D1A
	v_add_co_ci_u32_e64 v26, null, s16, v30, s0                // 0000002E9358: D5207C1A 00023C10
	v_dot2_f32_bf16 v4, v27, v39, v4                           // 0000002E9360: CC1A4004 1C124F1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002E9368: BF870091
	v_dot2_f32_bf16 v4, v28, v40, v4                           // 0000002E936C: CC1A4004 1C12511C
	v_add_f32_e32 v19, v19, v4                                 // 0000002E9374: 06260913
	s_clause 0x1                                               // 0000002E9378: BF850001
	global_load_b128 v[4:7], v[25:26], off                     // 0000002E937C: DC5E0000 047C0019
	global_load_b128 v[25:28], v[25:26], off offset:16         // 0000002E9384: DC5E0010 197C0019
	s_waitcnt vmcnt(1)                                         // 0000002E938C: BF8907F7
	v_dot2_f32_bf16 v4, v4, v33, 0                             // 0000002E9390: CC1A4004 1A024304
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002E9398: BF870091
	v_dot2_f32_bf16 v4, v5, v34, v4                            // 0000002E939C: CC1A4004 1C124505
	v_dot2_f32_bf16 v4, v6, v35, v4                            // 0000002E93A4: CC1A4004 1C124706
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002E93AC: BF8700A1
	v_dot2_f32_bf16 v4, v7, v36, v4                            // 0000002E93B0: CC1A4004 1C124907
	s_waitcnt vmcnt(0)                                         // 0000002E93B8: BF8903F7
	v_dot2_f32_bf16 v4, v25, v37, v4                           // 0000002E93BC: CC1A4004 1C124B19
	.long 0xd7000019                                           // 0000002E93C4: D7000019
	v_cndmask_b32_e32 v0, v31, v14, vcc_lo                     // 0000002E93C8: 02001D1F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000002E93CC: BF8701B2
	v_dot2_f32_bf16 v4, v26, v38, v4                           // 0000002E93D0: CC1A4004 1C124D1A
	v_add_co_ci_u32_e64 v26, null, s15, v32, s0                // 0000002E93D8: D5207C1A 0002400F
	.long 0xd700000c                                           // 0000002E93E0: D700000C
	v_cndmask_b32_e32 v0, v12, v144, vcc_lo                    // 0000002E93E4: 0201210C
	v_dot2_f32_bf16 v4, v27, v39, v4                           // 0000002E93E8: CC1A4004 1C124F1B
	v_add_co_ci_u32_e64 v13, null, 0, v13, s0                  // 0000002E93F0: D5207C0D 00021A80
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002E93F8: BF870092
	v_dot2_f32_bf16 v4, v28, v40, v4                           // 0000002E93FC: CC1A4004 1C12511C
	v_add_f32_e32 v18, v18, v4                                 // 0000002E9404: 06240912
	s_clause 0x1                                               // 0000002E9408: BF850001
	global_load_b128 v[4:7], v[25:26], off                     // 0000002E940C: DC5E0000 047C0019
	global_load_b128 v[25:28], v[25:26], off offset:16         // 0000002E9414: DC5E0010 197C0019
	s_waitcnt vmcnt(1)                                         // 0000002E941C: BF8907F7
	v_dot2_f32_bf16 v4, v4, v33, 0                             // 0000002E9420: CC1A4004 1A024304
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002E9428: BF870121
	v_dot2_f32_bf16 v4, v5, v34, v4                            // 0000002E942C: CC1A4004 1C124505
	v_mov_b32_e32 v5, v1                                       // 0000002E9434: 7E0A0301
	v_dot2_f32_bf16 v4, v6, v35, v4                            // 0000002E9438: CC1A4004 1C124706
	v_mov_b32_e32 v6, v2                                       // 0000002E9440: 7E0C0302
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000002E9444: BF870132
	v_dot2_f32_bf16 v4, v7, v36, v4                            // 0000002E9448: CC1A4004 1C124907
	v_mov_b32_e32 v7, v3                                       // 0000002E9450: 7E0E0303
	s_waitcnt vmcnt(0)                                         // 0000002E9454: BF8903F7
	v_dot2_f32_bf16 v4, v25, v37, v4                           // 0000002E9458: CC1A4004 1C124B19
	v_mov_b32_e32 v25, v23                                     // 0000002E9460: 7E320317
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002E9464: BF870092
	v_dot2_f32_bf16 v4, v26, v38, v4                           // 0000002E9468: CC1A4004 1C124D1A
	v_dot2_f32_bf16 v4, v27, v39, v4                           // 0000002E9470: CC1A4004 1C124F1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002E9478: BF870091
	v_dot2_f32_bf16 v4, v28, v40, v4                           // 0000002E947C: CC1A4004 1C12511C
	v_dual_add_f32 v15, v15, v4 :: v_dual_mov_b32 v4, v0       // 0000002E9484: C910090F 0F040100
	s_and_not1_b32 exec_lo, exec_lo, s17                       // 0000002E948C: 917E117E
	s_cbranch_execz 29                                         // 0000002E9490: BFA5001D <_ZN7halogen12_GLOBAL__N_16k_lq8wILi5ELi16ELi1EEEvPKhPKtPtll+0x808>
	v_add_nc_u32_e32 v22, 16, v22                              // 0000002E9494: 4A2C2C90
	v_add_nc_u32_e32 v24, 0x100, v10                           // 0000002E9498: 4A3014FF 00000100
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000002E94A0: BF8704A2
	.long 0xd4430000                                           // 0000002E94A4: D4430000
	v_cndmask_b32_e32 v1, s2, v22, vcc_lo                      // 0000002E94A8: 02022C02
	s_and_saveexec_b32 s1, s0                                  // 0000002E94AC: BE812000
	s_xor_b32 s1, exec_lo, s1                                  // 0000002E94B0: 8D01017E
	v_add_nc_u32_e32 v24, 0x100, v10                           // 0000002E94B4: 4A3014FF 00000100
	s_or_saveexec_b32 s10, s1                                  // 0000002E94BC: BE8A2201
	s_waitcnt vmcnt(0)                                         // 0000002E94C0: BF8903F7
	v_dual_mov_b32 v23, v25 :: v_dual_mov_b32 v0, v4           // 0000002E94C4: CA100119 17000104
	v_dual_mov_b32 v1, v5 :: v_dual_mov_b32 v2, v6             // 0000002E94CC: CA100105 01020106
	v_mov_b32_e32 v3, v7                                       // 0000002E94D4: 7E060307
	s_xor_b32 exec_lo, exec_lo, s10                            // 0000002E94D8: 8D7E0A7E
	s_cbranch_execz 65143                                      // 0000002E94DC: BFA5FE77 <_ZN7halogen12_GLOBAL__N_16k_lq8wILi5ELi16ELi1EEEvPKhPKtPtll+0x1bc>
	.long 0xd7000100                                           // 0000002E94E0: D7000100
	v_cndmask_b32_e32 v1, v16, v24, vcc_lo                     // 0000002E94E4: 02023110
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002E94E8: BF870001
	v_add_co_ci_u32_e64 v1, null, 0, v17, s1                   // 0000002E94EC: D5207C01 00062280
	global_load_b128 v[0:3], v[0:1], off                       // 0000002E94F4: DC5E0000 007C0000
	global_load_b32 v23, v[12:13], off                         // 0000002E94FC: DC520000 177C000C
	s_branch 65133                                             // 0000002E9504: BFA0FE6D <_ZN7halogen12_GLOBAL__N_16k_lq8wILi5ELi16ELi1EEEvPKhPKtPtll+0x1bc>
	s_or_b32 exec_lo, exec_lo, s17                             // 0000002E9508: 8C7E117E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002E950C: BF8700A9
	s_or_b32 exec_lo, exec_lo, s3                              // 0000002E9510: 8C7E037E
	.long 0xd71f0000                                           // 0000002E9514: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000002E9518: 020100C1
	v_xor_b32_e32 v1, 8, v0                                    // 0000002E951C: 3A020088
	s_waitcnt vmcnt(1)                                         // 0000002E9520: BF8907F7
	v_xor_b32_e32 v6, 4, v0                                    // 0000002E9524: 3A0C0084
	v_xor_b32_e32 v13, 2, v0                                   // 0000002E9528: 3A1A0082
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002E952C: BF870093
	.long 0xd44c0000                                           // 0000002E9530: D44C0000
	v_cndmask_b32_e32 v1, 32, v1, vcc_lo                       // 0000002E9534: 020202A0
	v_cndmask_b32_e64 v1, v0, v1, s0                           // 0000002E9538: D5010001 00020300
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002E9540: BF870114
	.long 0xd44c0000                                           // 0000002E9544: D44C0000
	v_cndmask_b32_e32 v1, 32, v6, vcc_lo                       // 0000002E9548: 02020CA0
	v_lshlrev_b32_e32 v1, 2, v1                                // 0000002E954C: 30020282
	s_delay_alu instid0(VALU_DEP_2)                            // 0000002E9550: BF870002
	v_cndmask_b32_e64 v6, v0, v6, s0                           // 0000002E9554: D5010006 00020D00
	.long 0xd44c0000                                           // 0000002E955C: D44C0000
	v_cndmask_b32_e32 v1, 32, v13, vcc_lo                      // 0000002E9560: 02021AA0
	ds_bpermute_b32 v2, v1, v21                                // 0000002E9564: DACC0000 02001501
	v_cndmask_b32_e64 v13, v0, v13, s0                         // 0000002E956C: D501000D 00021B00
	s_waitcnt lgkmcnt(0)                                       // 0000002E9574: BF89FC07
	v_add_f32_e32 v2, v21, v2                                  // 0000002E9578: 06040515
	ds_bpermute_b32 v3, v1, v20                                // 0000002E957C: DACC0000 03001401
	ds_bpermute_b32 v4, v1, v19                                // 0000002E9584: DACC0000 04001301
	ds_bpermute_b32 v5, v1, v18                                // 0000002E958C: DACC0000 05001201
	ds_bpermute_b32 v1, v1, v15                                // 0000002E9594: DACC0000 01000F01
	s_waitcnt lgkmcnt(3)                                       // 0000002E959C: BF89FC37
	v_dual_add_f32 v3, v20, v3 :: v_dual_lshlrev_b32 v6, 2, v6 // 0000002E95A0: C9220714 03060C82
	ds_bpermute_b32 v7, v6, v2                                 // 0000002E95A8: DACC0000 07000206
	s_waitcnt lgkmcnt(2)                                       // 0000002E95B0: BF89FC27
	v_dual_add_f32 v4, v19, v4 :: v_dual_add_f32 v5, v18, v5   // 0000002E95B4: C9080913 04040B12
	s_waitcnt lgkmcnt(1)                                       // 0000002E95BC: BF89FC17
	v_add_f32_e32 v1, v15, v1                                  // 0000002E95C0: 0602030F
	ds_bpermute_b32 v10, v6, v3                                // 0000002E95C4: DACC0000 0A000306
	ds_bpermute_b32 v11, v6, v4                                // 0000002E95CC: DACC0000 0B000406
	ds_bpermute_b32 v12, v6, v5                                // 0000002E95D4: DACC0000 0C000506
	s_waitcnt lgkmcnt(3)                                       // 0000002E95DC: BF89FC37
	v_dual_add_f32 v2, v2, v7 :: v_dual_lshlrev_b32 v13, 2, v13// 0000002E95E0: C9220F02 020C1A82
	ds_bpermute_b32 v6, v6, v1                                 // 0000002E95E8: DACC0000 06000106
	s_waitcnt lgkmcnt(2)                                       // 0000002E95F0: BF89FC27
	v_dual_add_f32 v3, v3, v10 :: v_dual_add_f32 v4, v4, v11   // 0000002E95F4: C9081503 03041704
	ds_bpermute_b32 v11, v13, v4                               // 0000002E95FC: DACC0000 0B00040D
	s_waitcnt lgkmcnt(2)                                       // 0000002E9604: BF89FC27
	v_add_f32_e32 v5, v5, v12                                  // 0000002E9608: 060A1905
	s_waitcnt lgkmcnt(1)                                       // 0000002E960C: BF89FC17
	v_add_f32_e32 v10, v1, v6                                  // 0000002E9610: 06140D01
	ds_bpermute_b32 v1, v13, v2                                // 0000002E9614: DACC0000 0100020D
	v_xor_b32_e32 v6, 1, v0                                    // 0000002E961C: 3A0C0081
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002E9620: BF870091
	.long 0xd44c0000                                           // 0000002E9624: D44C0000
	v_cndmask_b32_e32 v1, 32, v6, vcc_lo                       // 0000002E9628: 02020CA0
	v_cndmask_b32_e64 v0, v0, v6, s0                           // 0000002E962C: D5010000 00020D00
	.long 0xd44a0000                                           // 0000002E9634: D44A0000
	v_cndmask_b32_e32 v1, 0, v14, vcc_lo                       // 0000002E9638: 02021C80
	s_waitcnt lgkmcnt(1)                                       // 0000002E963C: BF89FC17
	s_delay_alu instid0(VALU_DEP_2)                            // 0000002E9640: BF870002
	v_dual_add_f32 v0, v4, v11 :: v_dual_lshlrev_b32 v15, 2, v0// 0000002E9644: C9221704 000E0082
	ds_bpermute_b32 v12, v13, v5                               // 0000002E964C: DACC0000 0C00050D
	s_and_b32 s0, s0, vcc_lo                                   // 0000002E9654: 8B006A00
	s_waitcnt lgkmcnt(1)                                       // 0000002E9658: BF89FC17
	v_add_f32_e32 v6, v2, v1                                   // 0000002E965C: 060C0302
	ds_bpermute_b32 v7, v13, v3                                // 0000002E9660: DACC0000 0700030D
	ds_bpermute_b32 v13, v13, v10                              // 0000002E9668: DACC0000 0D000A0D
	ds_bpermute_b32 v2, v15, v0                                // 0000002E9670: DACC0000 0200000F
	s_waitcnt lgkmcnt(3)                                       // 0000002E9678: BF89FC37
	v_add_f32_e32 v1, v5, v12                                  // 0000002E967C: 06021905
	s_waitcnt lgkmcnt(1)                                       // 0000002E9680: BF89FC17
	v_dual_add_f32 v7, v3, v7 :: v_dual_add_f32 v4, v10, v13   // 0000002E9684: C9080F03 07041B0A
	ds_bpermute_b32 v10, v15, v6                               // 0000002E968C: DACC0000 0A00060F
	ds_bpermute_b32 v3, v15, v1                                // 0000002E9694: DACC0000 0300010F
	ds_bpermute_b32 v11, v15, v7                               // 0000002E969C: DACC0000 0B00070F
	ds_bpermute_b32 v5, v15, v4                                // 0000002E96A4: DACC0000 0500040F
	s_and_saveexec_b32 s1, s0                                  // 0000002E96AC: BE812000
	s_cbranch_execz 71                                         // 0000002E96B0: BFA50047 <_ZN7halogen12_GLOBAL__N_16k_lq8wILi5ELi16ELi1EEEvPKhPKtPtll+0xad0>
	s_waitcnt lgkmcnt(1)                                       // 0000002E96B4: BF89FC17
	v_dual_add_f32 v11, v7, v11 :: v_dual_add_f32 v10, v6, v10 // 0000002E96B8: C9081707 0B0A1506
	.long 0x7f183880                                           // 0000002E96C0: 7F183880
	.long 0xd73c0006                                           // 0000002E96C4: D73C0006
	v_cndmask_b32_e32 v1, 1, v8, vcc_lo                        // 0000002E96C8: 02021081
	s_waitcnt lgkmcnt(0)                                       // 0000002E96CC: BF89FC07
	v_dual_add_f32 v14, v4, v5 :: v_dual_add_f32 v3, v1, v3    // 0000002E96D0: C9080B04 0E020701
	.long 0x7e1a398a                                           // 0000002E96D8: 7E1A398A
	.long 0x7f1a398c                                           // 0000002E96DC: 7F1A398C
	.long 0x7e18398b                                           // 0000002E96E0: 7E18398B
	.long 0xd7006a04                                           // 0000002E96E4: D7006A04
	v_cndmask_b32_e32 v1, s8, v6, vcc_lo                       // 0000002E96E8: 02020C08
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000002E96EC: BF8701B3
	v_dual_add_f32 v2, v0, v2 :: v_dual_and_b32 v9, 1, v13     // 0000002E96F0: C9240500 02081A81
	v_add_co_ci_u32_e64 v5, null, s9, v7, vcc_lo               // 0000002E96F8: D5207C05 01AA0E09
	.long 0x7f00398c                                           // 0000002E9700: 7F00398C
	.long 0x7e003982                                           // 0000002E9704: 7E003982
	s_lshl_b64 s[0:1], s[12:13], 1                             // 0000002E9708: 8480810C
	v_and_b32_e32 v8, 1, v12                                   // 0000002E970C: 36101881
	.long 0x7e183983                                           // 0000002E9710: 7E183983
	.long 0xd7006a06                                           // 0000002E9714: D7006A06
	v_cndmask_b32_e32 v0, v4, v0, vcc_lo                       // 0000002E9718: 02000104
	v_and_b32_e32 v13, 1, v0                                   // 0000002E971C: 361A0081
	v_mad_u64_u32 v[0:1], null, s12, 6, v[4:5]                 // 0000002E9720: D6FE7C00 04110C0C
	v_add_co_ci_u32_e64 v7, null, s1, v5, vcc_lo               // 0000002E9728: D5207C07 01AA0A01
	s_lshl_b64 s[0:1], s[12:13], 2                             // 0000002E9730: 8480820C
	v_add3_u32 v11, v11, v8, 0x7fff                            // 0000002E9734: D655000B 03FE110B 00007FFF
	.long 0xd7006a08                                           // 0000002E9740: D7006A08
	v_cndmask_b32_e32 v0, v4, v0, vcc_lo                       // 0000002E9744: 02000104
	v_and_b32_e32 v12, 1, v12                                  // 0000002E9748: 36181881
	v_add3_u32 v10, v10, v9, 0x7fff                            // 0000002E974C: D655000A 03FE130A 00007FFF
	v_bfe_u32 v15, v14, 16, 1                                  // 0000002E9758: D610000F 0205210E
	v_add_co_ci_u32_e64 v9, null, s1, v5, vcc_lo               // 0000002E9760: D5207C09 01AA0A01
	v_add3_u32 v13, v2, v13, 0x7fff                            // 0000002E9768: D655000D 03FE1B02 00007FFF
	v_mad_u64_u32 v[1:2], null, s13, 6, v[1:2]                 // 0000002E9774: D6FE7C01 04050C0D
	.long 0xd7006a02                                           // 0000002E977C: D7006A02
	v_cndmask_b32_e32 v0, v8, v0, vcc_lo                       // 0000002E9780: 02000108
	v_add3_u32 v12, v3, v12, 0x7fff                            // 0000002E9784: D655000C 03FE1903 00007FFF
	v_add3_u32 v14, v14, v15, 0x7fff                           // 0000002E9790: D655000E 03FE1F0E 00007FFF
	v_add_co_ci_u32_e64 v3, null, s1, v9, vcc_lo               // 0000002E979C: D5207C03 01AA1201
	s_clause 0x4                                               // 0000002E97A4: BF850004
	global_store_d16_hi_b16 v[4:5], v10, off                   // 0000002E97A8: DC960000 007C0A04
	global_store_d16_hi_b16 v[6:7], v11, off                   // 0000002E97B0: DC960000 007C0B06
	global_store_d16_hi_b16 v[8:9], v13, off                   // 0000002E97B8: DC960000 007C0D08
	global_store_d16_hi_b16 v[0:1], v12, off                   // 0000002E97C0: DC960000 007C0C00
	global_store_d16_hi_b16 v[2:3], v14, off                   // 0000002E97C8: DC960000 007C0E02
	s_endpgm                                                   // 0000002E97D0: BFB00000
		...

