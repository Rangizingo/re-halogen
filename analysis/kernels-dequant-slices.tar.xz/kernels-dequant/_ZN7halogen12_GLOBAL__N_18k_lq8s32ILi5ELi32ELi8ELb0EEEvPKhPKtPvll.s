0000000000588b00 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi5ELi32ELi8ELb0EEEvPKhPKtPvll>:
; _ZN7halogen12_GLOBAL__N_18k_lq8s32ILi5ELi32ELi8ELb0EEEvPKhPKtPvll():
	s_clause 0x1                                               // 000000588B00: BF850001
	s_load_b256 s[4:11], s[0:1], null                          // 000000588B04: F40C0100 F8000000
	s_load_b64 s[12:13], s[0:1], 0x20                          // 000000588B0C: F4040300 F8000020
	s_mov_b32 s3, 0                                            // 000000588B14: BE830080
	v_lshrrev_b32_e32 v14, 5, v0                               // 000000588B18: 321C0085
	v_dual_mov_b32 v6, 0 :: v_dual_and_b32 v15, 31, v0         // 000000588B1C: CA240080 060E009F
	v_dual_mov_b32 v16, 0 :: v_dual_mov_b32 v5, 0              // 000000588B24: CA100080 10040080
	.long 0x7e1a3880                                           // 000000588B2C: 7E1A3880
	v_mov_b32_e32 v8, 0                                        // 000000588B30: 7E100280
	s_waitcnt lgkmcnt(0)                                       // 000000588B34: BF89FC07
	s_ashr_i32 s0, s11, 31                                     // 000000588B38: 86009F0B
	.long 0xd451000e                                           // 000000588B3C: D451000E
	v_cndmask_b32_e32 v0, s2, v12, vcc_lo                      // 000000588B40: 02001802
	s_lshr_b32 s0, s0, 28                                      // 000000588B44: 85009C00
	v_dual_mov_b32 v1, s4 :: v_dual_mov_b32 v2, s5             // 000000588B48: CA100004 01020005
	s_add_u32 s0, s10, s0                                      // 000000588B50: 8000000A
	s_addc_u32 s1, s11, 0                                      // 000000588B54: 8201800B
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000588B58: BF870499
	s_ashr_i64 s[0:1], s[0:1], 4                               // 000000588B5C: 86808400
	s_add_u32 s15, s10, s0                                     // 000000588B60: 800F000A
	s_addc_u32 s1, s11, s1                                     // 000000588B64: 8201010B
	s_add_u32 s15, s15, 15                                     // 000000588B68: 800F8F0F
	s_addc_u32 s1, s1, 0                                       // 000000588B6C: 82018001
	s_and_b32 s15, s15, -16                                    // 000000588B70: 8B0FD00F
	s_and_b32 s14, s14, exec_lo                                // 000000588B74: 8B0E7E0E
	s_cselect_b32 s14, s2, 0                                   // 000000588B78: 980E8002
	s_add_i32 s16, s0, 7                                       // 000000588B7C: 81108700
	v_mad_u64_u32 v[10:11], null, s14, s15, v[1:2]             // 000000588B80: D6FE7C0A 04041E0E
	s_ashr_i32 s17, s16, 31                                    // 000000588B88: 86119F10
	s_mul_i32 s14, s14, s1                                     // 000000588B8C: 960E010E
	s_lshr_b32 s17, s17, 29                                    // 000000588B90: 85119D11
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000588B94: BF870499
	s_add_i32 s16, s16, s17                                    // 000000588B98: 81101110
	s_ashr_i32 s4, s16, 3                                      // 000000588B9C: 86048310
	v_add_nc_u32_e32 v11, s14, v11                             // 000000588BA0: 4A16160E
	.long 0xd72c0003                                           // 000000588BA4: D72C0003
	v_cndmask_b32_e32 v1, s4, v14, vcc_lo                      // 000000588BA8: 02021C04
	.long 0xd7006a13                                           // 000000588BAC: D7006A13
	v_cndmask_b32_e32 v0, v10, v10, vcc_lo                     // 000000588BB0: 0200150A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000588BB4: BF870191
	v_add_co_ci_u32_e64 v20, null, s11, v11, vcc_lo            // 000000588BB8: D5207C14 01AA160B
	v_add_nc_u32_e32 v1, s4, v3                                // 000000588BC0: 4A020604
	v_add_nc_u32_e32 v17, v3, v15                              // 000000588BC4: 4A221F03
	v_mov_b32_e32 v7, 0                                        // 000000588BC8: 7E0E0280
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000588BCC: BF870193
	v_min_i32_e32 v18, s0, v1                                  // 000000588BD0: 22240200
	v_lshlrev_b32_e32 v12, 4, v17                              // 000000588BD4: 30182284
	s_delay_alu instid0(VALU_DEP_2)                            // 000000588BD8: BF870002
	v_cmp_lt_i32_e32 vcc_lo, v17, v18                          // 000000588BDC: 7C822511
	s_and_saveexec_b32 s1, vcc_lo                              // 000000588BE0: BE81206A
	s_cbranch_execz 19                                         // 000000588BE4: BFA50013 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi5ELi32ELi8ELb0EEEvPKhPKtPvll+0x134>
	v_lshlrev_b32_e32 v1, 4, v17                               // 000000588BE8: 30022284
	v_and_b32_e32 v3, -2, v17                                  // 000000588BEC: 360622C2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000588BF0: BF870112
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000588BF4: 3404029F
	v_ashrrev_i32_e32 v4, 31, v3                               // 000000588BF8: 3408069F
	.long 0xd7000001                                           // 000000588BFC: D7000001
	v_cndmask_b32_e32 v1, v10, v1, vcc_lo                      // 000000588C00: 0202030A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000588C04: BF8700A1
	v_add_co_ci_u32_e64 v2, null, v11, v2, s0                  // 000000588C08: D5207C02 0002050B
	.long 0xd7000003                                           // 000000588C10: D7000003
	v_cndmask_b32_e32 v1, v19, v3, vcc_lo                      // 000000588C14: 02020713
	v_add_co_ci_u32_e64 v4, null, v20, v4, s0                  // 000000588C18: D5207C04 00020914
	s_clause 0x1                                               // 000000588C20: BF850001
	global_load_b128 v[5:8], v[1:2], off                       // 000000588C24: DC5E0000 057C0001
	global_load_d16_b16 v13, v[3:4], off                       // 000000588C2C: DC820000 0D7C0003
	s_or_b32 exec_lo, exec_lo, s1                              // 000000588C34: 8C7E017E
	v_dual_mov_b32 v22, 0 :: v_dual_mov_b32 v23, 0             // 000000588C38: CA100080 16160080
	v_dual_mov_b32 v24, 0 :: v_dual_mov_b32 v21, 0             // 000000588C40: CA100080 18140080
	s_and_saveexec_b32 s1, vcc_lo                              // 000000588C48: BE81206A
	s_cbranch_execz 459                                        // 000000588C4C: BFA501CB <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi5ELi32ELi8ELb0EEEvPKhPKtPvll+0x87c>
	v_dual_mov_b32 v24, 0 :: v_dual_add_nc_u32 v25, 0x200, v12 // 000000588C50: CA200080 181818FF 00000200
	v_dual_mov_b32 v21, 0 :: v_dual_mov_b32 v22, 0             // 000000588C5C: CA100080 15160080
	v_dual_mov_b32 v23, 0 :: v_dual_mov_b32 v16, 0             // 000000588C64: CA100080 17100080
	s_mul_i32 s0, s11, 6                                       // 000000588C6C: 9600860B
	s_mul_hi_u32 s14, s10, 6                                   // 000000588C70: 968E860A
	s_lshl_b64 s[4:5], s[10:11], 2                             // 000000588C74: 8484820A
	s_add_i32 s14, s14, s0                                     // 000000588C78: 810E000E
	s_mul_i32 s16, s10, 6                                      // 000000588C7C: 9610860A
	s_mov_b32 s15, 0                                           // 000000588C80: BE8F0080
	s_lshl_b64 s[10:11], s[10:11], 1                           // 000000588C84: 848A810A
	s_branch 411                                               // 000000588C88: BFA0019B <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi5ELi32ELi8ELb0EEEvPKhPKtPvll+0x7f8>
	s_or_b32 exec_lo, exec_lo, s17                             // 000000588C8C: 8C7E117E
	v_bfe_i32 v26, v5, 0, 8                                    // 000000588C90: D611001A 02210105
	s_and_b32 s0, exec_lo, vcc_lo                              // 000000588C98: 8B006A7E
	v_add_nc_u32_e32 v25, 0x200, v25                           // 000000588C9C: 4A3232FF 00000200
	s_or_b32 s15, s0, s15                                      // 000000588CA4: 8C0F0F00
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000588CA8: BF870092
	v_cvt_f32_i32_e32 v26, v26                                 // 000000588CAC: 7E340B1A
	v_fma_mix_f32 v26, v13, v26, neg(0) op_sel_hi:[1,0,0]      // 000000588CB0: CC20001A 8A02350D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000588CB8: BF870091
	v_bfe_u32 v27, v26, 16, 1                                  // 000000588CBC: D610001B 0205211A
	v_add3_u32 v26, v26, v27, 0x7fff                           // 000000588CC4: D655001A 03FE371A 00007FFF
	.long 0x7f363880                                           // 000000588CD0: 7F363880
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000588CD4: BF8700A2
	.long 0x7e36399a                                           // 000000588CD8: 7E36399A
	v_bfe_i32 v26, v5, 8, 8                                    // 000000588CDC: D611001A 02211105
	v_cvt_f32_i32_e32 v26, v26                                 // 000000588CE4: 7E340B1A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000588CE8: BF870091
	v_fma_mix_f32 v26, v13, v26, neg(0) op_sel_hi:[1,0,0]      // 000000588CEC: CC20001A 8A02350D
	v_bfe_u32 v28, v26, 16, 1                                  // 000000588CF4: D610001C 0205211A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000588CFC: BF8701B1
	v_add3_u32 v26, v26, v28, 0x7fff                           // 000000588D00: D655001A 03FE391A 00007FFF
	v_bfe_i32 v28, v5, 16, 8                                   // 000000588D0C: D611001C 02212105
	v_ashrrev_i32_e32 v5, 24, v5                               // 000000588D14: 340A0A98
	v_and_or_b32 v34, 0xffff0000, v26, v27                     // 000000588D18: D6570022 046E34FF FFFF0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000588D24: BF870193
	v_cvt_f32_i32_e32 v28, v28                                 // 000000588D28: 7E380B1C
	v_cvt_f32_i32_e32 v5, v5                                   // 000000588D2C: 7E0A0B05
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000588D30: BF870112
	v_fma_mix_f32 v28, v13, v28, neg(0) op_sel_hi:[1,0,0]      // 000000588D34: CC20001C 8A02390D
	v_fma_mix_f32 v5, v13, v5, neg(0) op_sel_hi:[1,0,0]        // 000000588D3C: CC200005 8A020B0D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000588D44: BF870092
	v_bfe_u32 v29, v28, 16, 1                                  // 000000588D48: D610001D 0205211C
	v_add3_u32 v28, v28, v29, 0x7fff                           // 000000588D50: D655001C 03FE3B1C 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000588D5C: BF870113
	v_bfe_u32 v29, v5, 16, 1                                   // 000000588D60: D610001D 02052105
	.long 0x7e38399c                                           // 000000588D68: 7E38399C
	.long 0x7f38399b                                           // 000000588D6C: 7F38399B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000588D70: BF870093
	v_add3_u32 v5, v5, v29, 0x7fff                             // 000000588D74: D6550005 03FE3B05 00007FFF
	v_and_or_b32 v35, 0xffff0000, v5, v28                      // 000000588D80: D6570023 04720AFF FFFF0000
	v_bfe_i32 v5, v6, 0, 8                                     // 000000588D8C: D6110005 02210106
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000588D94: BF870091
	v_cvt_f32_i32_e32 v5, v5                                   // 000000588D98: 7E0A0B05
	v_fma_mix_f32 v5, v13, v5, neg(0) op_sel_hi:[1,0,0]        // 000000588D9C: CC200005 8A020B0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000588DA4: BF870091
	v_bfe_u32 v26, v5, 16, 1                                   // 000000588DA8: D610001A 02052105
	v_add3_u32 v5, v5, v26, 0x7fff                             // 000000588DB0: D6550005 03FE3505 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000588DBC: BF8700A1
	.long 0x7e363985                                           // 000000588DC0: 7E363985
	v_bfe_i32 v5, v6, 8, 8                                     // 000000588DC4: D6110005 02211106
	v_cvt_f32_i32_e32 v5, v5                                   // 000000588DCC: 7E0A0B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000588DD0: BF870091
	v_fma_mix_f32 v5, v13, v5, neg(0) op_sel_hi:[1,0,0]        // 000000588DD4: CC200005 8A020B0D
	v_bfe_u32 v26, v5, 16, 1                                   // 000000588DDC: D610001A 02052105
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000588DE4: BF8701B1
	v_add3_u32 v5, v5, v26, 0x7fff                             // 000000588DE8: D6550005 03FE3505 00007FFF
	v_bfe_i32 v26, v6, 16, 8                                   // 000000588DF4: D611001A 02212106
	v_ashrrev_i32_e32 v6, 24, v6                               // 000000588DFC: 340C0C98
	v_and_or_b32 v36, 0xffff0000, v5, v27                      // 000000588E00: D6570024 046E0AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000588E0C: BF870193
	v_cvt_f32_i32_e32 v26, v26                                 // 000000588E10: 7E340B1A
	v_cvt_f32_i32_e32 v6, v6                                   // 000000588E14: 7E0C0B06
	v_bfe_i32 v5, v7, 0, 8                                     // 000000588E18: D6110005 02210107
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000588E20: BF870193
	v_fma_mix_f32 v26, v13, v26, neg(0) op_sel_hi:[1,0,0]      // 000000588E24: CC20001A 8A02350D
	v_fma_mix_f32 v6, v13, v6, neg(0) op_sel_hi:[1,0,0]        // 000000588E2C: CC200006 8A020D0D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000588E34: BF870193
	v_cvt_f32_i32_e32 v5, v5                                   // 000000588E38: 7E0A0B05
	v_bfe_u32 v28, v26, 16, 1                                  // 000000588E3C: D610001C 0205211A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000588E44: BF870112
	v_fma_mix_f32 v5, v13, v5, neg(0) op_sel_hi:[1,0,0]        // 000000588E48: CC200005 8A020B0D
	v_add3_u32 v26, v26, v28, 0x7fff                           // 000000588E50: D655001A 03FE391A 00007FFF
	v_bfe_u32 v28, v6, 16, 1                                   // 000000588E5C: D610001C 02052106
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000588E64: BF8701A2
	.long 0x7e34399a                                           // 000000588E68: 7E34399A
	.long 0x7f34399b                                           // 000000588E6C: 7F34399B
	v_add3_u32 v6, v6, v28, 0x7fff                             // 000000588E70: D6550006 03FE3906 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000588E7C: BF8700A1
	v_and_or_b32 v37, 0xffff0000, v6, v26                      // 000000588E80: D6570025 046A0CFF FFFF0000
	v_bfe_u32 v6, v5, 16, 1                                    // 000000588E8C: D6100006 02052105
	v_add3_u32 v5, v5, v6, 0x7fff                              // 000000588E94: D6550005 03FE0D05 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000588EA0: BF8700A1
	.long 0x7e363985                                           // 000000588EA4: 7E363985
	v_bfe_i32 v5, v7, 8, 8                                     // 000000588EA8: D6110005 02211107
	v_cvt_f32_i32_e32 v5, v5                                   // 000000588EB0: 7E0A0B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000588EB4: BF870091
	v_fma_mix_f32 v5, v13, v5, neg(0) op_sel_hi:[1,0,0]        // 000000588EB8: CC200005 8A020B0D
	v_bfe_u32 v6, v5, 16, 1                                    // 000000588EC0: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000588EC8: BF8701B1
	v_add3_u32 v5, v5, v6, 0x7fff                              // 000000588ECC: D6550005 03FE0D05 00007FFF
	v_bfe_i32 v6, v7, 16, 8                                    // 000000588ED8: D6110006 02212107
	v_ashrrev_i32_e32 v7, 24, v7                               // 000000588EE0: 340E0E98
	v_and_or_b32 v38, 0xffff0000, v5, v27                      // 000000588EE4: D6570026 046E0AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000588EF0: BF870193
	v_cvt_f32_i32_e32 v6, v6                                   // 000000588EF4: 7E0C0B06
	v_cvt_f32_i32_e32 v7, v7                                   // 000000588EF8: 7E0E0B07
	v_bfe_i32 v5, v8, 0, 8                                     // 000000588EFC: D6110005 02210108
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000588F04: BF870193
	v_fma_mix_f32 v6, v13, v6, neg(0) op_sel_hi:[1,0,0]        // 000000588F08: CC200006 8A020D0D
	v_fma_mix_f32 v7, v13, v7, neg(0) op_sel_hi:[1,0,0]        // 000000588F10: CC200007 8A020F0D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000588F18: BF870193
	v_cvt_f32_i32_e32 v5, v5                                   // 000000588F1C: 7E0A0B05
	v_bfe_u32 v26, v6, 16, 1                                   // 000000588F20: D610001A 02052106
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000588F28: BF870112
	v_fma_mix_f32 v5, v13, v5, neg(0) op_sel_hi:[1,0,0]        // 000000588F2C: CC200005 8A020B0D
	v_add3_u32 v6, v6, v26, 0x7fff                             // 000000588F34: D6550006 03FE3506 00007FFF
	v_bfe_u32 v26, v7, 16, 1                                   // 000000588F40: D610001A 02052107
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000588F48: BF8701A2
	.long 0x7e0c3986                                           // 000000588F4C: 7E0C3986
	.long 0x7f0c399b                                           // 000000588F50: 7F0C399B
	v_add3_u32 v7, v7, v26, 0x7fff                             // 000000588F54: D6550007 03FE3507 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000588F60: BF8700A1
	v_and_or_b32 v39, 0xffff0000, v7, v6                       // 000000588F64: D6570027 041A0EFF FFFF0000
	v_bfe_u32 v6, v5, 16, 1                                    // 000000588F70: D6100006 02052105
	v_add3_u32 v5, v5, v6, 0x7fff                              // 000000588F78: D6550005 03FE0D05 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000588F84: BF8700A1
	.long 0x7e363985                                           // 000000588F88: 7E363985
	v_bfe_i32 v5, v8, 8, 8                                     // 000000588F8C: D6110005 02211108
	v_cvt_f32_i32_e32 v5, v5                                   // 000000588F94: 7E0A0B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000588F98: BF870091
	v_fma_mix_f32 v5, v13, v5, neg(0) op_sel_hi:[1,0,0]        // 000000588F9C: CC200005 8A020B0D
	v_bfe_u32 v6, v5, 16, 1                                    // 000000588FA4: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000588FAC: BF870121
	v_add3_u32 v5, v5, v6, 0x7fff                              // 000000588FB0: D6550005 03FE0D05 00007FFF
	v_bfe_i32 v6, v8, 16, 8                                    // 000000588FBC: D6110006 02212108
	v_and_or_b32 v40, 0xffff0000, v5, v27                      // 000000588FC4: D6570028 046E0AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000588FD0: BF870092
	v_cvt_f32_i32_e32 v6, v6                                   // 000000588FD4: 7E0C0B06
	v_fma_mix_f32 v6, v13, v6, neg(0) op_sel_hi:[1,0,0]        // 000000588FD8: CC200006 8A020D0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000588FE0: BF870091
	v_bfe_u32 v7, v6, 16, 1                                    // 000000588FE4: D6100007 02052106
	v_add3_u32 v6, v6, v7, 0x7fff                              // 000000588FEC: D6550006 03FE0F06 00007FFF
	v_ashrrev_i32_e32 v7, 24, v8                               // 000000588FF8: 340E1098
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000588FFC: BF870112
	.long 0x7e0c3986                                           // 000000589000: 7E0C3986
	v_cvt_f32_i32_e32 v7, v7                                   // 000000589004: 7E0E0B07
	.long 0x7f0c399b                                           // 000000589008: 7F0C399B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000058900C: BF870122
	v_fma_mix_f32 v7, v13, v7, neg(0) op_sel_hi:[1,0,0]        // 000000589010: CC200007 8A020F0D
	v_ashrrev_i32_e32 v13, 31, v12                             // 000000589018: 341A189F
	v_bfe_u32 v8, v7, 16, 1                                    // 00000058901C: D6100008 02052107
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000589024: BF870091
	v_add3_u32 v7, v7, v8, 0x7fff                              // 000000589028: D6550007 03FE1107 00007FFF
	v_and_or_b32 v41, 0xffff0000, v7, v6                       // 000000589034: D6570029 041A0EFF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000589040: BF8701C4
	.long 0xd73c0005                                           // 000000589044: D73C0005
	v_cndmask_b32_e32 v1, 1, v12, vcc_lo                       // 000000589048: 02021881
	s_waitcnt vmcnt(0)                                         // 00000058904C: BF8903F7
	.long 0x7e1a3909                                           // 000000589050: 7E1A3909
	v_add_nc_u32_e32 v12, 0x200, v12                           // 000000589054: 4A1818FF 00000200
	.long 0xd7006a1e                                           // 00000058905C: D7006A1E
	v_cndmask_b32_e32 v1, s6, v5, vcc_lo                       // 000000589060: 02020A06
	s_delay_alu instid0(VALU_DEP_1)                            // 000000589064: BF870001
	v_add_co_ci_u32_e64 v31, null, s7, v6, vcc_lo              // 000000589068: D5207C1F 01AA0C07
	s_clause 0x1                                               // 000000589070: BF850001
	global_load_b128 v[5:8], v[30:31], off                     // 000000589074: DC5E0000 057C001E
	global_load_b128 v[26:29], v[30:31], off offset:16         // 00000058907C: DC5E0010 1A7C001E
	s_waitcnt vmcnt(1)                                         // 000000589084: BF8907F7
	v_dot2_f32_bf16 v5, v5, v34, 0                             // 000000589088: CC1A4005 1A024505
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000589090: BF870091
	v_dot2_f32_bf16 v5, v6, v35, v5                            // 000000589094: CC1A4005 1C164706
	v_dot2_f32_bf16 v5, v7, v36, v5                            // 00000058909C: CC1A4005 1C164907
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000005890A4: BF8700A1
	v_dot2_f32_bf16 v5, v8, v37, v5                            // 0000005890A8: CC1A4005 1C164B08
	s_waitcnt vmcnt(0)                                         // 0000005890B0: BF8903F7
	v_dot2_f32_bf16 v5, v26, v38, v5                           // 0000005890B4: CC1A4005 1C164D1A
	.long 0xd7006a1a                                           // 0000005890BC: D7006A1A
	v_cndmask_b32_e32 v0, v30, v10, vcc_lo                     // 0000005890C0: 0200151E
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000005890C4: BF8701B2
	v_dot2_f32_bf16 v5, v27, v39, v5                           // 0000005890C8: CC1A4005 1C164F1B
	v_add_co_ci_u32_e64 v27, null, s11, v31, vcc_lo            // 0000005890D0: D5207C1B 01AA3E0B
	.long 0xd7006a20                                           // 0000005890D8: D7006A20
	v_cndmask_b32_e32 v0, v30, v4, vcc_lo                      // 0000005890DC: 0200091E
	v_dot2_f32_bf16 v5, v28, v40, v5                           // 0000005890E0: CC1A4005 1C16511C
	v_add_co_ci_u32_e64 v33, null, s5, v31, vcc_lo             // 0000005890E8: D5207C21 01AA3E05
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005890F0: BF870092
	v_dot2_f32_bf16 v5, v29, v41, v5                           // 0000005890F4: CC1A4005 1C16531D
	v_add_f32_e32 v21, v21, v5                                 // 0000005890FC: 062A0B15
	s_clause 0x1                                               // 000000589100: BF850001
	global_load_b128 v[5:8], v[26:27], off                     // 000000589104: DC5E0000 057C001A
	global_load_b128 v[26:29], v[26:27], off offset:16         // 00000058910C: DC5E0010 1A7C001A
	s_waitcnt vmcnt(1)                                         // 000000589114: BF8907F7
	v_dot2_f32_bf16 v5, v5, v34, 0                             // 000000589118: CC1A4005 1A024505
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000589120: BF870091
	v_dot2_f32_bf16 v5, v6, v35, v5                            // 000000589124: CC1A4005 1C164706
	v_dot2_f32_bf16 v5, v7, v36, v5                            // 00000058912C: CC1A4005 1C164907
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000589134: BF8700A1
	v_dot2_f32_bf16 v5, v8, v37, v5                            // 000000589138: CC1A4005 1C164B08
	s_waitcnt vmcnt(0)                                         // 000000589140: BF8903F7
	v_dot2_f32_bf16 v5, v26, v38, v5                           // 000000589144: CC1A4005 1C164D1A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000058914C: BF870091
	v_dot2_f32_bf16 v5, v27, v39, v5                           // 000000589150: CC1A4005 1C164F1B
	v_dot2_f32_bf16 v5, v28, v40, v5                           // 000000589158: CC1A4005 1C16511C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000589160: BF870091
	v_dot2_f32_bf16 v5, v29, v41, v5                           // 000000589164: CC1A4005 1C16531D
	v_add_f32_e32 v24, v24, v5                                 // 00000058916C: 06300B18
	s_clause 0x1                                               // 000000589170: BF850001
	global_load_b128 v[5:8], v[32:33], off                     // 000000589174: DC5E0000 057C0020
	global_load_b128 v[26:29], v[32:33], off offset:16         // 00000058917C: DC5E0010 1A7C0020
	s_waitcnt vmcnt(1)                                         // 000000589184: BF8907F7
	v_dot2_f32_bf16 v5, v5, v34, 0                             // 000000589188: CC1A4005 1A024505
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000589190: BF870091
	v_dot2_f32_bf16 v5, v6, v35, v5                            // 000000589194: CC1A4005 1C164706
	v_dot2_f32_bf16 v5, v7, v36, v5                            // 00000058919C: CC1A4005 1C164907
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000005891A4: BF8700A1
	v_dot2_f32_bf16 v5, v8, v37, v5                            // 0000005891A8: CC1A4005 1C164B08
	s_waitcnt vmcnt(0)                                         // 0000005891B0: BF8903F7
	v_dot2_f32_bf16 v5, v26, v38, v5                           // 0000005891B4: CC1A4005 1C164D1A
	.long 0xd7006a1a                                           // 0000005891BC: D7006A1A
	v_cndmask_b32_e32 v0, v30, v16, vcc_lo                     // 0000005891C0: 0200211E
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000005891C4: BF870122
	v_dot2_f32_bf16 v5, v27, v39, v5                           // 0000005891C8: CC1A4005 1C164F1B
	v_add_co_ci_u32_e64 v27, null, s14, v31, vcc_lo            // 0000005891D0: D5207C1B 01AA3E0E
	v_dot2_f32_bf16 v5, v28, v40, v5                           // 0000005891D8: CC1A4005 1C16511C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005891E0: BF870091
	v_dot2_f32_bf16 v5, v29, v41, v5                           // 0000005891E4: CC1A4005 1C16531D
	v_add_f32_e32 v23, v23, v5                                 // 0000005891EC: 062E0B17
	s_clause 0x1                                               // 0000005891F0: BF850001
	global_load_b128 v[5:8], v[26:27], off                     // 0000005891F4: DC5E0000 057C001A
	global_load_b128 v[26:29], v[26:27], off offset:16         // 0000005891FC: DC5E0010 1A7C001A
	s_waitcnt vmcnt(1)                                         // 000000589204: BF8907F7
	v_dot2_f32_bf16 v5, v5, v34, 0                             // 000000589208: CC1A4005 1A024505
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000589210: BF870091
	v_dot2_f32_bf16 v5, v6, v35, v5                            // 000000589214: CC1A4005 1C164706
	v_dot2_f32_bf16 v5, v7, v36, v5                            // 00000058921C: CC1A4005 1C164907
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000589224: BF8700A1
	v_dot2_f32_bf16 v5, v8, v37, v5                            // 000000589228: CC1A4005 1C164B08
	s_waitcnt vmcnt(0)                                         // 000000589230: BF8903F7
	v_dot2_f32_bf16 v5, v26, v38, v5                           // 000000589234: CC1A4005 1C164D1A
	.long 0xd7006a1a                                           // 00000058923C: D7006A1A
	v_cndmask_b32_e32 v0, v32, v4, vcc_lo                      // 000000589240: 02000920
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000589244: BF870122
	v_dot2_f32_bf16 v5, v27, v39, v5                           // 000000589248: CC1A4005 1C164F1B
	v_add_co_ci_u32_e64 v27, null, s5, v33, vcc_lo             // 000000589250: D5207C1B 01AA4205
	v_dot2_f32_bf16 v5, v28, v40, v5                           // 000000589258: CC1A4005 1C16511C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000589260: BF870091
	v_dot2_f32_bf16 v5, v29, v41, v5                           // 000000589264: CC1A4005 1C16531D
	v_add_f32_e32 v22, v22, v5                                 // 00000058926C: 062C0B16
	s_clause 0x1                                               // 000000589270: BF850001
	global_load_b128 v[5:8], v[26:27], off                     // 000000589274: DC5E0000 057C001A
	global_load_b128 v[26:29], v[26:27], off offset:16         // 00000058927C: DC5E0010 1A7C001A
	s_waitcnt vmcnt(1)                                         // 000000589284: BF8907F7
	v_dot2_f32_bf16 v5, v5, v34, 0                             // 000000589288: CC1A4005 1A024505
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000589290: BF870121
	v_dot2_f32_bf16 v5, v6, v35, v5                            // 000000589294: CC1A4005 1C164706
	v_mov_b32_e32 v6, v2                                       // 00000058929C: 7E0C0302
	v_dot2_f32_bf16 v5, v7, v36, v5                            // 0000005892A0: CC1A4005 1C164907
	v_mov_b32_e32 v7, v3                                       // 0000005892A8: 7E0E0303
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000005892AC: BF870132
	v_dot2_f32_bf16 v5, v8, v37, v5                            // 0000005892B0: CC1A4005 1C164B08
	v_mov_b32_e32 v8, v4                                       // 0000005892B8: 7E100304
	s_waitcnt vmcnt(0)                                         // 0000005892BC: BF8903F7
	v_dot2_f32_bf16 v5, v26, v38, v5                           // 0000005892C0: CC1A4005 1C164D1A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005892C8: BF870091
	v_dot2_f32_bf16 v5, v27, v39, v5                           // 0000005892CC: CC1A4005 1C164F1B
	v_dot2_f32_bf16 v5, v28, v40, v5                           // 0000005892D4: CC1A4005 1C16511C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005892DC: BF870091
	v_dot2_f32_bf16 v5, v29, v41, v5                           // 0000005892E0: CC1A4005 1C16531D
	v_dual_add_f32 v16, v16, v5 :: v_dual_mov_b32 v5, v1       // 0000005892E8: C9100B10 10040101
	s_and_not1_b32 exec_lo, exec_lo, s15                       // 0000005892F0: 917E0F7E
	s_cbranch_execz 32                                         // 0000005892F4: BFA50020 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi5ELi32ELi8ELb0EEEvPKhPKtPvll+0x878>
	s_waitcnt vmcnt(1)                                         // 0000005892F8: BF8907F7
	v_dual_mov_b32 v2, v6 :: v_dual_add_nc_u32 v17, 32, v17    // 0000005892FC: CA200106 021022A0
	s_waitcnt vmcnt(0)                                         // 000000589304: BF8903F7
	.long 0x7e12390d                                           // 000000589308: 7E12390D
	v_dual_mov_b32 v1, v5 :: v_dual_mov_b32 v4, v8             // 00000058930C: CA100105 01040108
	v_mov_b32_e32 v3, v7                                       // 000000589314: 7E060307
	s_mov_b32 s17, exec_lo                                     // 000000589318: BE91007E
	v_cmp_ge_i32_e32 vcc_lo, v17, v18                          // 00000058931C: 7C8C2511
	.long 0xd4c1007e                                           // 000000589320: D4C1007E
	v_cndmask_b32_e32 v1, v17, v18, vcc_lo                     // 000000589324: 02022511
	s_cbranch_execz 65112                                      // 000000589328: BFA5FE58 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi5ELi32ELi8ELb0EEEvPKhPKtPvll+0x18c>
	v_and_b32_e32 v3, -2, v17                                  // 00000058932C: 360622C2
	v_ashrrev_i32_e32 v2, 31, v25                              // 000000589330: 3404329F
	.long 0xd7000001                                           // 000000589334: D7000001
	v_cndmask_b32_e32 v1, v10, v25, vcc_lo                     // 000000589338: 0202330A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000058933C: BF870193
	v_ashrrev_i32_e32 v4, 31, v3                               // 000000589340: 3408069F
	v_add_co_ci_u32_e64 v2, null, v11, v2, s0                  // 000000589344: D5207C02 0002050B
	.long 0xd700001a                                           // 00000058934C: D700001A
	v_cndmask_b32_e32 v1, v19, v3, vcc_lo                      // 000000589350: 02020713
	s_delay_alu instid0(VALU_DEP_1)                            // 000000589354: BF870001
	v_add_co_ci_u32_e64 v27, null, v20, v4, s0                 // 000000589358: D5207C1B 00020914
	s_clause 0x1                                               // 000000589360: BF850001
	global_load_b128 v[1:4], v[1:2], off                       // 000000589364: DC5E0000 017C0001
	global_load_d16_b16 v9, v[26:27], off                      // 00000058936C: DC820000 097C001A
	s_branch 65093                                             // 000000589374: BFA0FE45 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi5ELi32ELi8ELb0EEEvPKhPKtPvll+0x18c>
	s_or_b32 exec_lo, exec_lo, s15                             // 000000589378: 8C7E0F7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000058937C: BF8700B9
	s_or_b32 exec_lo, exec_lo, s1                              // 000000589380: 8C7E017E
	.long 0xd71f0001                                           // 000000589384: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 000000589388: 020100C1
	s_mov_b32 s0, exec_lo                                      // 00000058938C: BE80007E
	v_xor_b32_e32 v2, 16, v1                                   // 000000589390: 3A040290
	s_waitcnt vmcnt(1)                                         // 000000589394: BF8907F7
	v_xor_b32_e32 v7, 8, v1                                    // 000000589398: 3A0E0288
	v_xor_b32_e32 v12, 4, v1                                   // 00000058939C: 3A180284
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000005893A0: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 0000005893A4: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 0000005893A8: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v7                            // 0000005893AC: 7C980EA0
	v_cndmask_b32_e32 v7, v1, v7, vcc_lo                       // 0000005893B0: 020E0F01
	v_cmp_gt_u32_e32 vcc_lo, 32, v12                           // 0000005893B4: 7C9818A0
	s_delay_alu instid0(VALU_DEP_2)                            // 0000005893B8: BF870002
	v_lshlrev_b32_e32 v7, 2, v7                                // 0000005893BC: 300E0E82
	v_lshlrev_b32_e32 v2, 2, v2                                // 0000005893C0: 30040482
	ds_bpermute_b32 v3, v2, v21                                // 0000005893C4: DACC0000 03001502
	s_waitcnt lgkmcnt(0)                                       // 0000005893CC: BF89FC07
	v_add_f32_e32 v3, v21, v3                                  // 0000005893D0: 06060715
	ds_bpermute_b32 v5, v2, v23                                // 0000005893D4: DACC0000 05001702
	ds_bpermute_b32 v4, v2, v24                                // 0000005893DC: DACC0000 04001802
	ds_bpermute_b32 v6, v2, v22                                // 0000005893E4: DACC0000 06001602
	ds_bpermute_b32 v2, v2, v16                                // 0000005893EC: DACC0000 02001002
	ds_bpermute_b32 v8, v7, v3                                 // 0000005893F4: DACC0000 08000307
	s_waitcnt lgkmcnt(3)                                       // 0000005893FC: BF89FC37
	v_dual_add_f32 v5, v23, v5 :: v_dual_add_f32 v4, v24, v4   // 000000589400: C9080B17 05040918
	s_waitcnt lgkmcnt(2)                                       // 000000589408: BF89FC27
	v_add_f32_e32 v6, v22, v6                                  // 00000058940C: 060C0D16
	s_waitcnt lgkmcnt(0)                                       // 000000589410: BF89FC07
	v_dual_add_f32 v2, v16, v2 :: v_dual_add_f32 v3, v3, v8    // 000000589414: C9080510 02021103
	ds_bpermute_b32 v10, v7, v5                                // 00000058941C: DACC0000 0A000507
	ds_bpermute_b32 v9, v7, v4                                 // 000000589424: DACC0000 09000407
	v_cndmask_b32_e32 v12, v1, v12, vcc_lo                     // 00000058942C: 02181901
	ds_bpermute_b32 v11, v7, v6                                // 000000589430: DACC0000 0B000607
	ds_bpermute_b32 v7, v7, v2                                 // 000000589438: DACC0000 07000207
	s_waitcnt lgkmcnt(3)                                       // 000000589440: BF89FC37
	v_dual_add_f32 v5, v5, v10 :: v_dual_lshlrev_b32 v12, 2, v12// 000000589444: C9221505 050C1882
	s_waitcnt lgkmcnt(2)                                       // 00000058944C: BF89FC27
	v_add_f32_e32 v4, v4, v9                                   // 000000589450: 06081304
	s_waitcnt lgkmcnt(0)                                       // 000000589454: BF89FC07
	v_add_f32_e32 v2, v2, v7                                   // 000000589458: 06040F02
	ds_bpermute_b32 v9, v12, v5                                // 00000058945C: DACC0000 0900050C
	v_add_f32_e32 v6, v6, v11                                  // 000000589464: 060C1706
	ds_bpermute_b32 v7, v12, v3                                // 000000589468: DACC0000 0700030C
	ds_bpermute_b32 v8, v12, v4                                // 000000589470: DACC0000 0800040C
	ds_bpermute_b32 v11, v12, v2                               // 000000589478: DACC0000 0B00020C
	s_waitcnt lgkmcnt(3)                                       // 000000589480: BF89FC37
	v_add_f32_e32 v5, v5, v9                                   // 000000589484: 060A1305
	ds_bpermute_b32 v10, v12, v6                               // 000000589488: DACC0000 0A00060C
	v_xor_b32_e32 v12, 2, v1                                   // 000000589490: 3A180282
	s_waitcnt lgkmcnt(2)                                       // 000000589494: BF89FC27
	v_dual_add_f32 v3, v3, v7 :: v_dual_add_f32 v4, v4, v8     // 000000589498: C9080F03 03041104
	s_waitcnt lgkmcnt(1)                                       // 0000005894A0: BF89FC17
	v_add_f32_e32 v8, v2, v11                                  // 0000005894A4: 06101702
	v_cmp_gt_u32_e32 vcc_lo, 32, v12                           // 0000005894A8: 7C9818A0
	v_cndmask_b32_e32 v12, v1, v12, vcc_lo                     // 0000005894AC: 02181901
	s_waitcnt lgkmcnt(0)                                       // 0000005894B0: BF89FC07
	v_add_f32_e32 v6, v6, v10                                  // 0000005894B4: 060C1506
	s_delay_alu instid0(VALU_DEP_2)                            // 0000005894B8: BF870002
	v_lshlrev_b32_e32 v12, 2, v12                              // 0000005894BC: 30181882
	ds_bpermute_b32 v7, v12, v4                                // 0000005894C0: DACC0000 0700040C
	ds_bpermute_b32 v10, v12, v6                               // 0000005894C8: DACC0000 0A00060C
	s_waitcnt lgkmcnt(0)                                       // 0000005894D0: BF89FC07
	v_dual_add_f32 v4, v4, v7 :: v_dual_add_f32 v7, v6, v10    // 0000005894D4: C9080F04 04061506
	ds_bpermute_b32 v2, v12, v3                                // 0000005894DC: DACC0000 0200030C
	ds_bpermute_b32 v9, v12, v5                                // 0000005894E4: DACC0000 0900050C
	ds_bpermute_b32 v11, v12, v8                               // 0000005894EC: DACC0000 0B00080C
	v_xor_b32_e32 v12, 1, v1                                   // 0000005894F4: 3A180281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000005894F8: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v12                           // 0000005894FC: 7C9818A0
	v_cndmask_b32_e32 v1, v1, v12, vcc_lo                      // 000000589500: 02021901
	s_waitcnt lgkmcnt(2)                                       // 000000589504: BF89FC27
	v_dual_add_f32 v1, v3, v2 :: v_dual_lshlrev_b32 v12, 2, v1 // 000000589508: C9220503 010C0282
	s_waitcnt lgkmcnt(0)                                       // 000000589510: BF89FC07
	v_dual_add_f32 v2, v5, v9 :: v_dual_add_f32 v3, v8, v11    // 000000589514: C9081305 02021708
	ds_bpermute_b32 v9, v12, v4                                // 00000058951C: DACC0000 0900040C
	ds_bpermute_b32 v10, v12, v7                               // 000000589524: DACC0000 0A00070C
	ds_bpermute_b32 v5, v12, v1                                // 00000058952C: DACC0000 0500010C
	ds_bpermute_b32 v6, v12, v2                                // 000000589534: DACC0000 0600020C
	ds_bpermute_b32 v8, v12, v3                                // 00000058953C: DACC0000 0800030C
	v_cmpx_eq_u32_e32 0, v15                                   // 000000589544: 7D941E80
	s_cbranch_execz 15                                         // 000000589548: BFA5000F <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi5ELi32ELi8ELb0EEEvPKhPKtPvll+0xa88>
	s_waitcnt lgkmcnt(3)                                       // 00000058954C: BF89FC37
	v_dual_add_f32 v7, v7, v10 :: v_dual_add_f32 v4, v4, v9    // 000000589550: C9081507 07041304
	s_waitcnt lgkmcnt(1)                                       // 000000589558: BF89FC17
	v_dual_add_f32 v1, v1, v5 :: v_dual_add_f32 v2, v2, v6     // 00000058955C: C9080B01 01020D02
	v_mul_u32_u24_e32 v5, 20, v14                              // 000000589564: 160A1C94
	s_waitcnt lgkmcnt(0)                                       // 000000589568: BF89FC07
	v_add_f32_e32 v3, v3, v8                                   // 00000058956C: 06061103
	ds_store_2addr_b32 v5, v1, v4 offset1:1                    // 000000589570: D8380100 00040105
	ds_store_2addr_b32 v5, v2, v7 offset0:2 offset1:3          // 000000589578: D8380302 00070205
	ds_store_b32 v5, v3 offset:16                              // 000000589580: D8340010 00000305
	s_or_b32 exec_lo, exec_lo, s0                              // 000000589588: 8C7E007E
	.long 0xd4510000                                           // 00000058958C: D4510000
	v_cndmask_b32_e32 v0, s2, v12, vcc_lo                      // 000000589590: 02001802
	v_cmp_gt_u32_e32 vcc_lo, 5, v0                             // 000000589594: 7C980085
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000589598: BF890007
	s_barrier                                                  // 00000058959C: BFBD0000
	buffer_gl0_inv                                             // 0000005895A0: E0AC0000 00000000
	s_and_b32 s0, vcc_lo, s0                                   // 0000005895A8: 8B00006A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000005895AC: BF870009
	s_and_saveexec_b32 s1, s0                                  // 0000005895B0: BE812000
	s_cbranch_execz 50                                         // 0000005895B4: BFA50032 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi5ELi32ELi8ELb0EEEvPKhPKtPvll+0xb80>
	v_lshlrev_b32_e32 v7, 2, v0                                // 0000005895B8: 300E0082
	s_lshl_b64 s[0:1], s[2:3], 1                               // 0000005895BC: 84808102
	ds_load_2addr_b32 v[1:2], v7 offset1:5                     // 0000005895C0: D8DC0500 01000007
	ds_load_2addr_b32 v[3:4], v7 offset0:10 offset1:15         // 0000005895C8: D8DC0F0A 03000007
	ds_load_2addr_b32 v[5:6], v7 offset0:20 offset1:25         // 0000005895D0: D8DC1914 05000007
	s_waitcnt lgkmcnt(2)                                       // 0000005895D8: BF89FC27
	v_add_f32_e32 v1, 0, v1                                    // 0000005895DC: 06020280
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000005895E0: BF8700A1
	v_add_f32_e32 v1, v1, v2                                   // 0000005895E4: 06020501
	s_waitcnt lgkmcnt(1)                                       // 0000005895E8: BF89FC17
	v_add_f32_e32 v1, v1, v3                                   // 0000005895EC: 06020701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000005895F0: BF870131
	v_add_f32_e32 v3, v1, v4                                   // 0000005895F4: 06060901
	v_mad_u64_u32 v[1:2], null, s12, v0, 0                     // 0000005895F8: D6FE7C01 0202000C
	s_waitcnt lgkmcnt(0)                                       // 000000589600: BF89FC07
	v_add_f32_e32 v3, v3, v5                                   // 000000589604: 06060B03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000589608: BF8700D1
	v_add_f32_e32 v4, v3, v6                                   // 00000058960C: 06080D03
	ds_load_2addr_b32 v[7:8], v7 offset0:30 offset1:35         // 000000589610: D8DC231E 07000007
	v_mad_u64_u32 v[2:3], null, s13, v0, v[2:3]                // 000000589618: D6FE7C02 040A000D
	s_waitcnt lgkmcnt(0)                                       // 000000589620: BF89FC07
	v_add_f32_e32 v0, v4, v7                                   // 000000589624: 06000F04
	v_add_f32_e32 v3, v0, v8                                   // 000000589628: 06061100
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000058962C: BF870113
	.long 0xd73c0000                                           // 000000589630: D73C0000
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 000000589634: 02020281
	v_bfe_u32 v2, v3, 16, 1                                    // 000000589638: D6100002 02052103
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000589640: BF870092
	.long 0xd7006a00                                           // 000000589644: D7006A00
	v_cndmask_b32_e32 v1, s8, v0, vcc_lo                       // 000000589648: 02020008
	v_add_co_ci_u32_e64 v1, null, s9, v1, vcc_lo               // 00000058964C: D5207C01 01AA0209
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000589654: BF870193
	v_add3_u32 v2, v3, v2, 0x7fff                              // 000000589658: D6550002 03FE0503 00007FFF
	.long 0xd7006a00                                           // 000000589664: D7006A00
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 000000589668: 02000100
	s_delay_alu instid0(VALU_DEP_1)                            // 00000058966C: BF870001
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 000000589670: D5207C01 01AA0201
	global_store_d16_hi_b16 v[0:1], v2, off                    // 000000589678: DC960000 007C0200
	s_endpgm                                                   // 000000589680: BFB00000
		...

