0000000000461f00 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb0ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_>:
; _ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb0ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_():
	s_clause 0x2                                               // 000000461F00: BF850002
	s_load_b128 s[24:27], s[0:1], 0x10                         // 000000461F04: F4080600 F8000010
	s_load_b256 s[12:19], s[0:1], 0x20                         // 000000461F0C: F40C0300 F8000020
	s_load_b128 s[20:23], s[0:1], 0x40                         // 000000461F14: F4080500 F8000040
	s_mov_b32 s10, s3                                          // 000000461F1C: BE8A0003
	v_and_b32_e32 v21, 31, v0                                  // 000000461F20: 362A009F
	v_lshrrev_b32_e32 v19, 5, v0                               // 000000461F24: 32260085
	s_delay_alu instid0(VALU_DEP_2)                            // 000000461F28: BF870002
	v_lshlrev_b32_e32 v8, 3, v21                               // 000000461F2C: 30102A83
	s_waitcnt lgkmcnt(0)                                       // 000000461F30: BF89FC07
	s_ashr_i32 s11, s25, 31                                    // 000000461F34: 860B9F19
	s_mul_i32 s34, s27, s10                                    // 000000461F38: 96220A1B
	s_lshr_b32 s3, s11, 25                                     // 000000461F3C: 8503990B
	s_add_i32 s4, s34, s27                                     // 000000461F40: 81041B22
	s_add_i32 s3, s25, s3                                      // 000000461F44: 81030319
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000461F48: BF870499
	s_ashr_i32 s3, s3, 7                                       // 000000461F4C: 86038703
	s_min_i32 s3, s3, s4                                       // 000000461F50: 89030403
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 000000461F54: BF8704B9
	s_sub_i32 s9, s3, s34                                      // 000000461F58: 81892203
	s_mov_b32 s3, exec_lo                                      // 000000461F5C: BE83007E
	s_lshl_b32 s27, s9, 2                                      // 000000461F60: 841B8209
	.long 0xd4c3007e                                           // 000000461F64: D4C3007E
	v_cndmask_b32_e32 v1, s27, v19, vcc_lo                     // 000000461F68: 0202261B
	s_xor_b32 s3, exec_lo, s3                                  // 000000461F6C: 8D03037E
	v_lshlrev_b32_e32 v8, 3, v21                               // 000000461F70: 30102A83
	s_or_saveexec_b32 s35, s3                                  // 000000461F74: BEA32203
	s_clause 0x1                                               // 000000461F78: BF850001
	s_load_b32 s33, s[0:1], 0x54                               // 000000461F7C: F4000840 F8000054
	s_load_b128 s[28:31], s[0:1], null                         // 000000461F84: F4080700 F8000000
	v_lshlrev_b32_e32 v20, 2, v21                              // 000000461F8C: 30282A82
	s_xor_b32 exec_lo, exec_lo, s35                            // 000000461F90: 8D7E237E
	s_cbranch_execz 500                                        // 000000461F94: BFA501F4 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb0ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x868>
	s_add_i32 s36, s24, -1                                     // 000000461F98: 8124C118
	s_cmp_lg_u64 s[22:23], 0                                   // 000000461F9C: BF118016
	v_and_b32_e32 v1, 1, v0                                    // 000000461FA0: 36020081
	s_cselect_b32 s37, -1, 0                                   // 000000461FA4: 982580C1
	s_abs_i32 s38, s9                                          // 000000461FA8: BEA61509
	v_and_b32_e32 v3, 2, v0                                    // 000000461FAC: 36060082
	s_cvt_f32_u32 s0, s38                                      // 000000461FB0: BE806526
	v_dual_mov_b32 v9, v19 :: v_dual_and_b32 v4, 4, v0         // 000000461FB4: CA240113 09040084
	v_and_b32_e32 v5, 8, v0                                    // 000000461FBC: 360A0088
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000461FC0: BF870009
	v_rcp_iflag_f32_e32 v2, s0                                 // 000000461FC4: 7E045600
	v_lshl_or_b32 v6, v19, 8, v8                               // 000000461FC8: D6560006 04211113
	v_add_nc_u32_e32 v7, s34, v19                              // 000000461FD0: 4A0E2622
	s_ashr_i32 s42, s9, 31                                     // 000000461FD4: 862A9F09
	s_sub_i32 s8, 0, s38                                       // 000000461FD8: 81882680
	s_mul_i32 s44, s42, 0x1400                                 // 000000461FDC: 962CFF2A 00001400
	.long 0xd44c0000                                           // 000000461FE4: D44C0000
	v_cndmask_b32_e32 v1, 16, v21, vcc_lo                      // 000000461FE8: 02022A90
	.long 0xd44a0001                                           // 000000461FEC: D44A0001
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 000000461FF0: 02020280
	.long 0xd44a0004                                           // 000000461FF4: D44A0004
	v_cndmask_b32_e32 v1, 0, v4, vcc_lo                        // 000000461FF8: 02020880
	.long 0xd44a0005                                           // 000000461FFC: D44A0005
	v_cndmask_b32_e32 v1, 0, v5, vcc_lo                        // 000000462000: 02020A80
	v_readfirstlane_b32 s3, v2                                 // 000000462004: 7E060502
	v_lshl_or_b32 v1, v7, 7, v20                               // 000000462008: D6560001 04510F07
	v_subrev_nc_u32_e32 v10, s44, v6                           // 000000462010: 4E140C2C
	s_lshl_b32 s6, s9, 7                                       // 000000462014: 84068709
	s_mov_b32 s39, s25                                         // 000000462018: BEA70019
	s_mul_f32 s7, s3, 0x4f7ffffe                               // 00000046201C: A207FF03 4F7FFFFE
	.long 0xd44a0003                                           // 000000462024: D44A0003
	v_cndmask_b32_e32 v1, 0, v3, vcc_lo                        // 000000462028: 02020680
	s_mov_b32 s40, 0                                           // 00000046202C: BEA80080
	s_mov_b32 s41, 0x76543210                                  // 000000462030: BEA900FF 76543210
	s_cvt_u32_f32 s7, s7                                       // 000000462038: BE876707
	s_lshl_b32 s43, s9, 8                                      // 00000046203C: 842B8809
	s_sub_i32 s44, 0, s6                                       // 000000462040: 81AC0680
	s_mov_b32 s46, 0x3db504f3                                  // 000000462044: BEAE00FF 3DB504F3
	s_mul_i32 s8, s8, s7                                       // 00000046204C: 96080708
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000462050: BF870499
	s_mul_hi_u32 s8, s7, s8                                    // 000000462054: 96880807
	s_add_i32 s45, s7, s8                                      // 000000462058: 812D0807
	s_branch 161                                               // 00000046205C: BFA000A1 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb0ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x3e4>
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000462060: BF870091
	.long 0xd7006a02                                           // 000000462064: D7006A02
	v_cndmask_b32_e32 v1, s12, v2, vcc_lo                      // 000000462068: 0202040C
	v_add_co_ci_u32_e64 v3, null, s13, v3, vcc_lo              // 00000046206C: D5207C03 01AA060D
	v_add_nc_u32_e32 v1, 0x400, v1                             // 000000462074: 4A0202FF 00000400
	global_load_d16_b16 v2, v[2:3], off offset:6               // 00000046207C: DC820006 027C0002
	v_add_f32_e32 v3, v16, v14                                 // 000000462084: 06061D10
	s_waitcnt vmcnt(0)                                         // 000000462088: BF8903F7
	v_fma_mix_f32 v5, v15, v2, v13 op_sel_hi:[0,1,0]           // 00000046208C: CC200005 1436050F
	v_sub_f32_e32 v4, v16, v14                                 // 000000462094: 08081D10
	v_fma_mix_f32 v2, -v15, v2, v13 op_sel_hi:[0,1,0]          // 000000462098: CC200002 3436050F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000004620A0: BF870121
	v_dual_add_f32 v6, v3, v5 :: v_dual_add_f32 v7, v4, v2     // 0000004620A4: C9080B03 06060504
	v_sub_f32_e32 v2, v4, v2                                   // 0000004620AC: 08040504
	v_mov_b32_dpp v4, v6 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000004620B0: 7E0802FA FF016106
	v_cndmask_b32_e64 v6, -v6, v6, s1                          // 0000004620B8: D5010006 20060D06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000004620C0: BF870241
	v_dual_add_f32 v4, v6, v4 :: v_dual_sub_f32 v3, v3, v5     // 0000004620C4: C90A0906 04020B03
	v_mov_b32_dpp v5, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000004620CC: 7E0A02FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, s1                          // 0000004620D4: D5010007 20060F07
	.long 0xd72c0006                                           // 0000004620DC: D72C0006
	v_cndmask_b32_e32 v1, 0x1400, v12, vcc_lo                  // 0000004620E0: 020218FF 00001400
	v_mov_b32_dpp v13, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000004620E8: 7E1A02FA FF016103
	v_cndmask_b32_e64 v3, -v3, v3, s1                          // 0000004620F0: D5010003 20060703
	s_delay_alu instid0(VALU_DEP_4)                            // 0000004620F8: BF870004
	v_add_f32_e32 v5, v7, v5                                   // 0000004620FC: 060A0B07
	v_mov_b32_dpp v14, v2 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000462100: 7E1C02FA FF016102
	v_cndmask_b32_e64 v2, -v2, v2, s1                          // 000000462108: D5010002 20060502
	v_mov_b32_dpp v7, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000462110: 7E0E02FA FF016204
	v_add_f32_e32 v3, v3, v13                                  // 000000462118: 06061B03
	v_cndmask_b32_e64 v4, -v4, v4, s3                          // 00000046211C: D5010004 200E0904
	v_mov_b32_dpp v12, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000462124: 7E1802FA FF016205
	v_add_f32_e32 v2, v2, v14                                  // 00000046212C: 06041D02
	v_cndmask_b32_e64 v5, -v5, v5, s3                          // 000000462130: D5010005 200E0B05
	v_mov_b32_dpp v13, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000462138: 7E1A02FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, s3                          // 000000462140: D5010003 200E0703
	v_add_f32_e32 v4, v4, v7                                   // 000000462148: 06080F04
	v_mov_b32_dpp v14, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000046214C: 7E1C02FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, s3                          // 000000462154: D5010002 200E0502
	v_add_f32_e32 v5, v5, v12                                  // 00000046215C: 060A1905
	.long 0xd72c0007                                           // 000000462160: D72C0007
	v_cndmask_b32_e32 v1, s43, v11, vcc_lo                     // 000000462164: 0202162B
	v_add_f32_e32 v3, v3, v13                                  // 000000462168: 06061B03
	v_mov_b32_dpp v11, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000046216C: 7E1602FA FF016404
	v_add_f32_e32 v2, v2, v14                                  // 000000462174: 06041D02
	v_cndmask_b32_e64 v4, -v4, v4, s4                          // 000000462178: D5010004 20120904
	v_mov_b32_dpp v12, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000462180: 7E1802FA FF016405
	v_cndmask_b32_e64 v5, -v5, v5, s4                          // 000000462188: D5010005 20120B05
	v_mov_b32_dpp v13, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000462190: 7E1A02FA FF016403
	v_mov_b32_dpp v14, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000462198: 7E1C02FA FF016402
	v_cndmask_b32_e64 v2, -v2, v2, s4                          // 0000004621A0: D5010002 20120502
	v_cndmask_b32_e64 v3, -v3, v3, s4                          // 0000004621A8: D5010003 20120703
	v_dual_add_f32 v4, v4, v11 :: v_dual_add_f32 v5, v5, v12   // 0000004621B0: C9081704 04041905
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000004621B8: BF8701A3
	v_dual_add_f32 v2, v2, v14 :: v_dual_add_nc_u32 v9, 8, v9  // 0000004621BC: C9201D02 02081288
	v_sub_nc_u32_e32 v6, v6, v7                                // 0000004621C4: 4C0C0F06
	v_mov_b32_dpp v11, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000004621C8: 7E1602FA FF016804
	v_cndmask_b32_e64 v4, -v4, v4, s5                          // 0000004621D0: D5010004 20160904
	v_add_f32_e32 v3, v3, v13                                  // 0000004621D8: 06061B03
	v_mov_b32_dpp v12, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000004621DC: 7E1802FA FF016805
	v_cndmask_b32_e64 v5, -v5, v5, s5                          // 0000004621E4: D5010005 20160B05
	v_mov_b32_dpp v14, v2 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000004621EC: 7E1C02FA FF016802
	v_cndmask_b32_e64 v2, -v2, v2, s5                          // 0000004621F4: D5010002 20160502
	v_add_f32_e32 v4, v4, v11                                  // 0000004621FC: 06081704
	v_mov_b32_dpp v13, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000462200: 7E1A02FA FF016803
	v_cndmask_b32_e64 v3, -v3, v3, s5                          // 000000462208: D5010003 20160703
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000462210: BF870214
	v_dual_add_f32 v5, v5, v12 :: v_dual_add_f32 v2, v2, v14   // 000000462214: C9081905 05021D02
	v_mov_b32_e32 v11, v4                                      // 00000046221C: 7E160304
	v_cndmask_b32_e64 v4, -v4, v4, s0                          // 000000462220: D5010004 20020904
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000462228: BF870213
	v_dual_add_f32 v3, v3, v13 :: v_dual_mov_b32 v12, v5       // 00000046222C: C9101B03 030C0105
	v_mov_b32_e32 v14, v2                                      // 000000462234: 7E1C0302
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000462238: BF870224
	v_permlanex16_b32 v11, v11, s41, 0xfedcba98                // 00000046223C: D65C000B 03FC530B FEDCBA98
	v_cndmask_b32_e64 v5, -v5, v5, s0                          // 000000462248: D5010005 20020B05
	v_mov_b32_e32 v13, v3                                      // 000000462250: 7E1A0303
	v_cndmask_b32_e64 v2, -v2, v2, s0                          // 000000462254: D5010002 20020502
	v_cndmask_b32_e64 v3, -v3, v3, s0                          // 00000046225C: D5010003 20020703
	v_permlanex16_b32 v12, v12, s41, 0xfedcba98                // 000000462264: D65C000C 03FC530C FEDCBA98
	v_permlanex16_b32 v14, v14, s41, 0xfedcba98                // 000000462270: D65C000E 03FC530E FEDCBA98
	v_add_f32_e32 v4, v4, v11                                  // 00000046227C: 06081704
	v_permlanex16_b32 v13, v13, s41, 0xfedcba98                // 000000462280: D65C000D 03FC530D FEDCBA98
	v_cmp_le_i32_e32 vcc_lo, s27, v9                           // 00000046228C: 7C86121B
	v_dual_add_f32 v5, v5, v12 :: v_dual_add_nc_u32 v6, v10, v6// 000000462290: C9201905 05060D0A
	v_add_f32_e32 v7, v2, v14                                  // 000000462298: 060E1D02
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000046229C: BF870194
	v_dual_add_f32 v11, v3, v13 :: v_dual_add_nc_u32 v10, 0x800, v10// 0000004622A0: C9201B03 0B0A14FF 00000800
	v_fma_mixhi_f16 v2, v5, s46, 0                             // 0000004622AC: CC220002 02005D05
	v_fma_mixlo_f16 v2, v4, s46, 0                             // 0000004622B4: CC210002 02005D04
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004622BC: BF870214
	v_fma_mixhi_f16 v3, v7, s46, 0                             // 0000004622C0: CC220003 02005D07
	v_fma_mixlo_f16 v3, v11, s46, 0                            // 0000004622C8: CC210003 02005D0B
	s_or_b32 s40, vcc_lo, s40                                  // 0000004622D0: 8C28286A
	ds_store_b64 v6, v[2:3]                                    // 0000004622D4: D9340000 00000206
	s_and_not1_b32 exec_lo, exec_lo, s40                       // 0000004622DC: 917E287E
	s_cbranch_execz 288                                        // 0000004622E0: BFA50120 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb0ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x864>
	.long 0xd72d0002                                           // 0000004622E4: D72D0002
	v_cndmask_b32_e32 v0, v9, v45, vcc_lo                      // 0000004622E8: 02005B09
	s_mov_b32 s6, -1                                           // 0000004622EC: BE8600C1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004622F0: BF870091
	.long 0xd72c0003                                           // 0000004622F4: D72C0003
	v_cndmask_b32_e32 v0, v2, v38, vcc_lo                      // 0000004622F8: 02004D02
	v_sub_nc_u32_e32 v3, v9, v3                                // 0000004622FC: 4C060709
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000462300: BF870121
	v_subrev_nc_u32_e32 v5, s38, v3                            // 000000462304: 4E0A0626
	v_cmp_le_u32_e32 vcc_lo, s38, v3                           // 000000462308: 7C960626
	v_dual_cndmask_b32 v3, v3, v5 :: v_dual_add_nc_u32 v4, 1, v2// 00000046230C: CA600B03 03040481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000462314: BF870111
	v_cndmask_b32_e32 v2, v2, v4, vcc_lo                       // 000000462318: 02040902
	v_cmp_le_u32_e32 vcc_lo, s38, v3                           // 00000046231C: 7C960626
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000462320: BF870092
	v_add_nc_u32_e32 v4, 1, v2                                 // 000000462324: 4A080481
	v_cndmask_b32_e32 v2, v2, v4, vcc_lo                       // 000000462328: 02040902
	s_and_not1_b32 vcc_lo, exec_lo, s37                        // 00000046232C: 916A257E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000462330: BF870091
	v_xor_b32_e32 v12, s42, v2                                 // 000000462334: 3A18042A
	v_subrev_nc_u32_e32 v11, s42, v12                          // 000000462338: 4E16182A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000046233C: BF8700A1
	v_mad_u64_u32 v[6:7], null, s44, v11, v[1:2]               // 000000462340: D6FE7C06 0406162C
	v_min_i32_e32 v2, s36, v11                                 // 000000462348: 22041624
	v_mad_i64_i32 v[4:5], null, v2, s39, 0                     // 00000046234C: D6FF7C04 02004F02
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000462354: BF870093
	v_ashrrev_i32_e32 v7, 31, v6                               // 000000462358: 340E0C9F
	.long 0xd73c0002                                           // 00000046235C: D73C0002
	v_cndmask_b32_e32 v1, 1, v6, vcc_lo                        // 000000462360: 02020C81
	s_cbranch_vccnz 210                                        // 000000462364: BFA400D2 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb0ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x7b0>
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000462368: BF870093
	.long 0xd7006a06                                           // 00000046236C: D7006A06
	v_cndmask_b32_e32 v1, v4, v6, vcc_lo                       // 000000462370: 02020D04
	v_add_co_ci_u32_e64 v7, null, v5, v7, vcc_lo               // 000000462374: D5207C07 01AA0F05
	.long 0x7f403880                                           // 00000046237C: 7F403880
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000462380: BF870112
	.long 0xd73c0006                                           // 000000462384: D73C0006
	v_cndmask_b32_e32 v1, 1, v6, vcc_lo                        // 000000462388: 02020C81
	.long 0x7f4639a0                                           // 00000046238C: 7F4639A0
	s_waitcnt lgkmcnt(0)                                       // 000000462390: BF89FC07
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000462394: BF870092
	.long 0xd7006a0d                                           // 000000462398: D7006A0D
	v_cndmask_b32_e32 v1, s30, v6, vcc_lo                      // 00000046239C: 02020C1E
	v_add_co_ci_u32_e64 v14, null, s31, v7, vcc_lo             // 0000004623A0: D5207C0E 01AA0E1F
	.long 0xd7006a06                                           // 0000004623A8: D7006A06
	v_cndmask_b32_e32 v1, s22, v6, vcc_lo                      // 0000004623AC: 02020C16
	s_delay_alu instid0(VALU_DEP_1)                            // 0000004623B0: BF870001
	v_add_co_ci_u32_e64 v7, null, s23, v7, vcc_lo              // 0000004623B4: D5207C07 01AA0E17
	global_load_b64 v[13:14], v[13:14], off                    // 0000004623BC: DC560000 0D7C000D
	.long 0xd7006a0f                                           // 0000004623C4: D7006A0F
	v_cndmask_b32_e32 v1, s12, v2, vcc_lo                      // 0000004623C8: 0202040C
	global_load_b64 v[6:7], v[6:7], off                        // 0000004623CC: DC560000 067C0006
	v_add_co_ci_u32_e64 v16, null, s13, v3, vcc_lo             // 0000004623D4: D5207C10 01AA060D
	s_clause 0x1                                               // 0000004623DC: BF850001
	global_load_b32 v17, v[15:16], off                         // 0000004623E0: DC520000 117C000F
	global_load_d16_b16 v15, v[15:16], off offset:4            // 0000004623E8: DC820004 0F7C000F
	s_waitcnt vmcnt(3)                                         // 0000004623F0: BF890FF7
	.long 0x7e20390d                                           // 0000004623F4: 7E20390D
	v_lshlrev_b32_e32 v18, 16, v14                             // 0000004623F8: 30241C90
	v_and_b32_e32 v14, 0xffff0000, v14                         // 0000004623FC: 361C1CFF FFFF0000
	v_and_b32_e32 v13, 0xffff0000, v13                         // 000000462404: 361A1AFF FFFF0000
	s_waitcnt vmcnt(2)                                         // 00000046240C: BF890BF7
	v_and_b32_e32 v42, 0xffff0000, v6                          // 000000462410: 36540CFF FFFF0000
	v_lshlrev_b32_e32 v16, 16, v16                             // 000000462418: 30202090
	v_lshlrev_b32_e32 v6, 16, v6                               // 00000046241C: 300C0C90
	v_mul_f32_e32 v25, 0xbfb8aa3b, v14                         // 000000462420: 10321CFF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000462428: BF870113
	v_mul_f32_e32 v23, 0xbfb8aa3b, v16                         // 00000046242C: 102E20FF BFB8AA3B
	v_exp_f32_e32 v25, v25                                     // 000000462434: 7E324B19
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(TRANS32_DEP_2)// 000000462438: BF870321
	v_exp_f32_e32 v23, v23                                     // 00000046243C: 7E2E4B17
	v_mul_f32_e32 v22, 0xbfb8aa3b, v13                         // 000000462440: 102C1AFF BFB8AA3B
	v_add_f32_e32 v25, 1.0, v25                                // 000000462448: 063232F2
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000046244C: BF870195
	v_add_f32_e32 v23, 1.0, v23                                // 000000462450: 062E2EF2
	v_exp_f32_e32 v22, v22                                     // 000000462454: 7E2C4B16
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000462458: BF870112
	v_div_scale_f32 v30, null, v25, v25, v14                   // 00000046245C: D6FC7C1E 043A3319
	v_div_scale_f32 v27, null, v23, v23, v16                   // 000000462464: D6FC7C1B 04422F17
	v_div_scale_f32 v40, s7, v16, v23, v16                     // 00000046246C: D6FC0728 04422F10
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000462474: BF870113
	v_rcp_f32_e32 v34, v30                                     // 000000462478: 7E44551E
	v_rcp_f32_e32 v31, v27                                     // 00000046247C: 7E3E551B
	s_delay_alu instid0(TRANS32_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000462480: BF870097
	v_add_f32_e32 v22, 1.0, v22                                // 000000462484: 062C2CF2
	v_div_scale_f32 v26, null, v22, v22, v13                   // 000000462488: D6FC7C1A 04362D16
	v_div_scale_f32 v36, vcc_lo, v13, v22, v13                 // 000000462490: D6FC6A24 04362D0D
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000462498: BF870195
	v_fma_f32 v39, -v27, v31, 1.0                              // 00000046249C: D6130027 23CA3F1B
	v_rcp_f32_e32 v29, v26                                     // 0000004624A4: 7E3A551A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(TRANS32_DEP_1)// 0000004624A8: BF8702A1
	v_fmac_f32_e32 v31, v39, v31                               // 0000004624AC: 563E3F27
	v_div_scale_f32 v39, s8, v14, v25, v14                     // 0000004624B0: D6FC0827 043A330E
	v_fma_f32 v37, -v26, v29, 1.0                              // 0000004624B8: D6130025 23CA3B1A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004624C0: BF870091
	v_dual_mul_f32 v24, 0xbfb8aa3b, v18 :: v_dual_fmac_f32 v29, v37, v29// 0000004624C4: C8C024FF 181C3B25 BFB8AA3B
	v_exp_f32_e32 v24, v24                                     // 0000004624D0: 7E304B18
	v_fma_f32 v37, -v30, v34, 1.0                              // 0000004624D4: D6130025 23CA451E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000004624DC: BF870291
	v_dual_fmac_f32 v34, v37, v34 :: v_dual_mul_f32 v37, v40, v31// 0000004624E0: C8064525 22243F28
	v_add_f32_e32 v24, 1.0, v24                                // 0000004624E8: 063030F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000004624EC: BF870112
	v_fma_f32 v46, -v27, v37, v40                              // 0000004624F0: D613002E 24A24B1B
	v_div_scale_f32 v28, null, v24, v24, v18                   // 0000004624F8: D6FC7C1C 044A3118
	v_div_scale_f32 v38, s6, v18, v24, v18                     // 000000462500: D6FC0626 044A3112
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000462508: BF870193
	v_fmac_f32_e32 v37, v46, v31                               // 00000046250C: 564A3F2E
	v_rcp_f32_e32 v33, v28                                     // 000000462510: 7E42551C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000462514: BF870291
	v_fma_f32 v27, -v27, v37, v40                              // 000000462518: D613001B 24A24B1B
	v_fma_f32 v41, -v28, v33, 1.0                              // 000000462520: D6130029 23CA431C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000462528: BF8700A1
	v_fmac_f32_e32 v33, v41, v33                               // 00000046252C: 56424329
	v_mul_f32_e32 v41, v36, v29                                // 000000462530: 10523B24
	v_fma_f32 v44, -v26, v41, v36                              // 000000462534: D613002C 2492531A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000046253C: BF870091
	v_fmac_f32_e32 v41, v44, v29                               // 000000462540: 56523B2C
	v_fma_f32 v26, -v26, v41, v36                              // 000000462544: D613001A 2492531A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 00000046254C: BF870141
	v_div_fmas_f32 v26, v26, v29, v41                          // 000000462550: D637001A 04A63B1A
	s_mov_b32 vcc_lo, s7                                       // 000000462558: BEEA0007
	v_div_fmas_f32 v27, v27, v31, v37                          // 00000046255C: D637001B 04963F1B
	s_mov_b32 vcc_lo, s6                                       // 000000462564: BEEA0006
	v_div_fixup_f32 v13, v26, v22, v13                         // 000000462568: D627000D 04362D1A
	s_mov_b32 s6, 0                                            // 000000462570: BE860080
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000462574: BF870242
	v_div_fixup_f32 v16, v27, v23, v16                         // 000000462578: D6270010 04422F1B
	v_mul_f32_e32 v43, v38, v33                                // 000000462580: 10564326
	v_lshlrev_b32_e32 v23, 16, v7                              // 000000462584: 302E0E90
	v_mul_f32_e32 v13, v13, v42                                // 000000462588: 101A550D
	v_dual_mul_f32 v6, v16, v6 :: v_dual_and_b32 v7, 0xffff0000, v7// 00000046258C: C8E40D10 06060EFF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000462598: BF870194
	v_fma_f32 v47, -v28, v43, v38                              // 00000046259C: D613002F 249A571C
	.long 0x7e40398d                                           // 0000004625A4: 7E40398D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000004625A8: BF870193
	.long 0x7e463986                                           // 0000004625AC: 7E463986
	v_fmac_f32_e32 v43, v47, v33                               // 0000004625B0: 5656432F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004625B4: BF870091
	v_fma_f32 v28, -v28, v43, v38                              // 0000004625B8: D613001C 249A571C
	v_div_fmas_f32 v22, v28, v33, v43                          // 0000004625C0: D6370016 04AE431C
	s_mov_b32 vcc_lo, s8                                       // 0000004625C8: BEEA0008
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004625CC: BF870091
	v_div_fixup_f32 v18, v22, v24, v18                         // 0000004625D0: D6270012 044A3116
	v_dual_mul_f32 v45, v39, v34 :: v_dual_mul_f32 v18, v18, v23// 0000004625D8: C8C64527 2D122F12
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000004625E0: BF8701A1
	v_fma_f32 v44, -v30, v45, v39                              // 0000004625E4: D613002C 249E5B1E
	v_and_b32_e32 v23, 1, v35                                  // 0000004625EC: 362E4681
	v_bfe_u32 v22, v18, 16, 1                                  // 0000004625F0: D6100016 02052112
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000004625F8: BF870193
	v_fmac_f32_e32 v45, v44, v34                               // 0000004625FC: 565A452C
	v_add3_u32 v6, v6, v23, 0x7fff                             // 000000462600: D6550006 03FE2F06 00007FFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000046260C: BF870112
	v_fma_f32 v26, -v30, v45, v39                              // 000000462610: D613001A 249E5B1E
	v_and_b32_e32 v6, 0xffff0000, v6                           // 000000462618: 360C0CFF FFFF0000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000462620: BF870092
	v_div_fmas_f32 v16, v26, v34, v45                          // 000000462624: D6370010 04B6451A
	v_div_fixup_f32 v14, v16, v25, v14                         // 00000046262C: D627000E 043A3310
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000462634: BF870091
	v_dual_mul_f32 v7, v14, v7 :: v_dual_and_b32 v16, 1, v32   // 000000462638: C8E40F0E 07104081
	v_add3_u32 v13, v13, v16, 0x7fff                           // 000000462640: D655000D 03FE210D 00007FFF
	v_add3_u32 v14, v18, v22, 0x7fff                           // 00000046264C: D655000E 03FE2D12 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000462658: BF870193
	v_bfe_u32 v16, v7, 16, 1                                   // 00000046265C: D6100010 02052107
	v_and_b32_e32 v13, 0xffff0000, v13                         // 000000462664: 361A1AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000046266C: BF870193
	v_and_b32_e32 v18, 0xffff0000, v14                         // 000000462670: 36241CFF FFFF0000
	v_add3_u32 v7, v7, v16, 0x7fff                             // 000000462678: D6550007 03FE2107 00007FFF
	s_waitcnt vmcnt(1)                                         // 000000462684: BF8907F7
	s_delay_alu instid0(VALU_DEP_3)                            // 000000462688: BF870003
	v_fma_mix_f32 v14, v17, v13, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 00000046268C: CC20080E 8A021B11
	s_waitcnt vmcnt(0)                                         // 000000462694: BF8903F7
	v_fma_mix_f32 v13, v15, v18, neg(0) op_sel_hi:[1,0,0]      // 000000462698: CC20000D 8A02250F
	v_fma_mix_f32 v16, v17, v6, neg(0) op_sel_hi:[1,0,0]       // 0000004626A0: CC200010 8A020D11
	v_and_b32_e32 v15, 0xffff0000, v7                          // 0000004626A8: 361E0EFF FFFF0000
	s_and_not1_b32 vcc_lo, exec_lo, s6                         // 0000004626B0: 916A067E
	s_cbranch_vccnz 65130                                      // 0000004626B4: BFA4FE6A <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb0ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x160>
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000004626B8: BF8700A3
	.long 0xd73c0004                                           // 0000004626BC: D73C0004
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 0000004626C0: 02020881
	s_waitcnt lgkmcnt(0)                                       // 0000004626C4: BF89FC07
	.long 0xd7006a04                                           // 0000004626C8: D7006A04
	v_cndmask_b32_e32 v1, s30, v4, vcc_lo                      // 0000004626CC: 0202081E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000004626D0: BF870111
	v_add_co_ci_u32_e64 v5, null, s31, v5, vcc_lo              // 0000004626D4: D5207C05 01AA0A1F
	.long 0xd7006a04                                           // 0000004626DC: D7006A04
	v_cndmask_b32_e32 v1, v4, v2, vcc_lo                       // 0000004626E0: 02020504
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000004626E4: BF8700A1
	v_add_co_ci_u32_e64 v5, null, v5, v3, vcc_lo               // 0000004626E8: D5207C05 01AA0705
	.long 0xd7006a06                                           // 0000004626F0: D7006A06
	v_cndmask_b32_e32 v1, s12, v2, vcc_lo                      // 0000004626F4: 0202040C
	v_add_co_ci_u32_e64 v7, null, s13, v3, vcc_lo              // 0000004626F8: D5207C07 01AA060D
	global_load_b64 v[4:5], v[4:5], off                        // 000000462700: DC560000 047C0004
	s_clause 0x1                                               // 000000462708: BF850001
	global_load_b32 v15, v[6:7], off                           // 00000046270C: DC520000 0F7C0006
	global_load_d16_b16 v6, v[6:7], off offset:4               // 000000462714: DC820004 067C0006
	s_waitcnt vmcnt(2)                                         // 00000046271C: BF890BF7
	.long 0x7e0e3904                                           // 000000462720: 7E0E3904
	v_and_b32_e32 v4, 0xffff0000, v4                           // 000000462724: 360808FF FFFF0000
	v_lshlrev_b32_e32 v13, 16, v5                              // 00000046272C: 301A0A90
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000462730: BF8701A3
	v_lshlrev_b32_e32 v7, 16, v7                               // 000000462734: 300E0E90
	s_waitcnt vmcnt(1)                                         // 000000462738: BF8907F7
	v_fma_mix_f32 v14, v15, v4, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 00000046273C: CC20080E 8A02090F
	s_waitcnt vmcnt(0)                                         // 000000462744: BF8903F7
	v_fma_mix_f32 v13, v6, v13, neg(0) op_sel_hi:[1,0,0]       // 000000462748: CC20000D 8A021B06
	v_fma_mix_f32 v16, v15, v7, neg(0) op_sel_hi:[1,0,0]       // 000000462750: CC200010 8A020F0F
	v_and_b32_e32 v15, 0xffff0000, v5                          // 000000462758: 361E0AFF FFFF0000
	s_branch 65087                                             // 000000462760: BFA0FE3F <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb0ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x160>
	s_or_b32 exec_lo, exec_lo, s40                             // 000000462764: 8C7E287E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000462768: BF870009
	s_or_b32 exec_lo, exec_lo, s35                             // 00000046276C: 8C7E237E
	s_bfe_i32 s8, s9, 0x1001c                                  // 000000462770: 9388FF09 0001001C
	s_lshr_b32 s4, s11, 28                                     // 000000462778: 85049C0B
	s_lshr_b64 s[0:1], s[8:9], 29                              // 00000046277C: 85809D08
	s_add_i32 s4, s25, s4                                      // 000000462780: 81040419
	s_add_i32 s0, s0, 7                                        // 000000462784: 81008700
	s_lshl_b32 s3, s9, 3                                       // 000000462788: 84038309
	s_ashr_i32 s0, s0, 3                                       // 00000046278C: 86008300
	s_lshl_b32 s1, s34, 3                                      // 000000462790: 84018322
	.long 0xd72c0001                                           // 000000462794: D72C0001
	v_cndmask_b32_e32 v1, s0, v19, vcc_lo                      // 000000462798: 02022600
	v_mov_b32_e32 v57, 0                                       // 00000046279C: 7E720280
	v_dual_mov_b32 v23, 0 :: v_dual_mov_b32 v56, 0             // 0000004627A0: CA100080 17380080
	v_dual_mov_b32 v55, 0 :: v_dual_mov_b32 v58, 0             // 0000004627A8: CA100080 373A0080
	v_dual_mov_b32 v59, 0 :: v_dual_mov_b32 v60, 0             // 0000004627B0: CA100080 3B3C0080
	v_add_nc_u32_e32 v2, s0, v1                                // 0000004627B8: 4A040200
	s_ashr_i32 s0, s4, 4                                       // 0000004627BC: 86008404
	s_ashr_i32 s4, s1, 31                                      // 0000004627C0: 86049F01
	s_mul_hi_i32 s5, s0, s2                                    // 0000004627C4: 97050200
	s_mul_i32 s0, s0, s2                                       // 0000004627C8: 96000200
	v_min_i32_e32 v54, s3, v2                                  // 0000004627CC: 226C0403
	s_add_u32 s0, s0, s1                                       // 0000004627D0: 80000100
	s_addc_u32 s1, s5, s4                                      // 0000004627D4: 82010405
	s_mul_hi_u32 s3, s0, 0x300                                 // 0000004627D8: 9683FF00 00000300
	s_mulk_i32 s1, 0x300                                       // 0000004627E0: B8010300
	v_cmp_lt_i32_e32 vcc_lo, v1, v54                           // 0000004627E4: 7C826D01
	s_add_i32 s5, s3, s1                                       // 0000004627E8: 81050103
	s_mul_i32 s4, s0, 0x300                                    // 0000004627EC: 9604FF00 00000300
	s_waitcnt lgkmcnt(0)                                       // 0000004627F4: BF89FC07
	s_barrier                                                  // 0000004627F8: BFBD0000
	buffer_gl0_inv                                             // 0000004627FC: E0AC0000 00000000
	s_and_saveexec_b32 s1, vcc_lo                              // 000000462804: BE81206A
	s_cbranch_execz 24                                         // 000000462808: BFA50018 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb0ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x96c>
	s_add_u32 s6, s28, s4                                      // 00000046280C: 8006041C
	s_addc_u32 s7, s29, s5                                     // 000000462810: 8207051D
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000462814: BF870099
	v_mad_i64_i32 v[2:3], null, 0x300, v1, s[6:7]              // 000000462818: D6FF7C02 001A02FF 00000300
	.long 0xd7000002                                           // 000000462824: D7000002
	v_cndmask_b32_e32 v1, v2, v20, vcc_lo                      // 000000462828: 02022902
	s_delay_alu instid0(VALU_DEP_1)                            // 00000046282C: BF870001
	v_add_co_ci_u32_e64 v3, null, 0, v3, s0                    // 000000462830: D5207C03 00020680
	s_clause 0x5                                               // 000000462838: BF850005
	global_load_b32 v55, v[2:3], off                           // 00000046283C: DC520000 377C0002
	global_load_b32 v56, v[2:3], off offset:128                // 000000462844: DC520080 387C0002
	global_load_b32 v57, v[2:3], off offset:256                // 00000046284C: DC520100 397C0002
	global_load_b32 v58, v[2:3], off offset:384                // 000000462854: DC520180 3A7C0002
	global_load_b32 v59, v[2:3], off offset:512                // 00000046285C: DC520200 3B7C0002
	global_load_b32 v60, v[2:3], off offset:640                // 000000462864: DC520280 3C7C0002
	s_or_b32 exec_lo, exec_lo, s1                              // 00000046286C: 8C7E017E
	v_dual_mov_b32 v53, 0 :: v_dual_mov_b32 v52, 0             // 000000462870: CA100080 35340080
	v_dual_mov_b32 v51, 0 :: v_dual_mov_b32 v50, 0             // 000000462878: CA100080 33320080
	v_dual_mov_b32 v49, 0 :: v_dual_mov_b32 v48, 0             // 000000462880: CA100080 31300080
	v_dual_mov_b32 v47, 0 :: v_dual_mov_b32 v46, 0             // 000000462888: CA100080 2F2E0080
	v_dual_mov_b32 v45, 0 :: v_dual_mov_b32 v44, 0             // 000000462890: CA100080 2D2C0080
	v_dual_mov_b32 v43, 0 :: v_dual_mov_b32 v42, 0             // 000000462898: CA100080 2B2A0080
	v_dual_mov_b32 v41, 0 :: v_dual_mov_b32 v40, 0             // 0000004628A0: CA100080 29280080
	v_dual_mov_b32 v39, 0 :: v_dual_mov_b32 v38, 0             // 0000004628A8: CA100080 27260080
	v_dual_mov_b32 v37, 0 :: v_dual_mov_b32 v36, 0             // 0000004628B0: CA100080 25240080
	v_dual_mov_b32 v35, 0 :: v_dual_mov_b32 v34, 0             // 0000004628B8: CA100080 23220080
	v_dual_mov_b32 v33, 0 :: v_dual_mov_b32 v32, 0             // 0000004628C0: CA100080 21200080
	v_dual_mov_b32 v24, 0 :: v_dual_mov_b32 v31, 0             // 0000004628C8: CA100080 181E0080
	v_dual_mov_b32 v30, 0 :: v_dual_mov_b32 v29, 0             // 0000004628D0: CA100080 1E1C0080
	v_dual_mov_b32 v28, 0 :: v_dual_mov_b32 v25, 0             // 0000004628D8: CA100080 1C180080
	v_dual_mov_b32 v27, 0 :: v_dual_mov_b32 v26, 0             // 0000004628E0: CA100080 1B1A0080
	v_mov_b32_e32 v22, 0                                       // 0000004628E8: 7E2C0280
	s_ashr_i32 s3, s2, 31                                      // 0000004628EC: 86039F02
	s_and_saveexec_b32 s1, vcc_lo                              // 0000004628F0: BE81206A
	s_cbranch_execz 1197                                       // 0000004628F4: BFA504AD <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb0ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1cac>
	v_or_b32_e32 v4, 4, v8                                     // 0000004628F8: 38081084
	v_mad_u32_u24 v7, v21, 24, 0x2f0                           // 0000004628FC: D60B0007 03FD3115 000002F0
	v_mad_i64_i32 v[2:3], null, 0x300, v1, s[4:5]              // 000000462908: D6FF7C02 001202FF 00000300
	v_mul_u32_u24_e32 v6, 0x320, v19                           // 000000462914: 160C26FF 00000320
	v_mul_i32_i24_e32 v8, 0xffffffe8, v21                      // 00000046291C: 12102AFF FFFFFFE8
	v_mad_u32_u24 v5, v4, 3, 0x2f0                             // 000000462924: D60B0005 03FD0704 000002F0
	v_cmp_lt_u32_e32 vcc_lo, 5, v4                             // 000000462930: 7C920885
	v_lshrrev_b32_e32 v12, 5, v7                               // 000000462934: 32180E85
	v_mul_i32_i24_e32 v13, -3, v4                              // 000000462938: 121A08C3
	v_mad_u32_u24 v10, 0x320, v19, v20                         // 00000046293C: D60B000A 045226FF 00000320
	v_lshrrev_b32_e32 v9, 5, v5                                // 000000462948: 32120A85
	v_dual_mov_b32 v26, 0 :: v_dual_and_b32 v5, 0x7e0, v5      // 00000046294C: CA240080 1A040AFF 000007E0
	v_dual_mov_b32 v22, 0 :: v_dual_and_b32 v11, 16, v0        // 000000462958: CA240080 160A0090
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000462960: BF870223
	v_subrev_nc_u32_e32 v9, 24, v9                             // 000000462964: 4E121298
	v_and_b32_e32 v7, 0x7e0, v7                                // 000000462968: 360E0EFF 000007E0
	v_add3_u32 v62, v13, v5, 0xfffffd34                        // 000000462970: D655003E 03FE0B0D FFFFFD34
	v_sub_nc_u32_e32 v64, 0, v54                               // 00000046297C: 4C806C80
	v_lshl_or_b32 v63, v1, 5, v11                              // 000000462980: D656003F 042D0B01
	v_cndmask_b32_e32 v4, 23, v9, vcc_lo                       // 000000462988: 02081297
	.long 0xd7006a02                                           // 00000046298C: D7006A02
	v_cndmask_b32_e32 v1, v2, v20, vcc_lo                      // 000000462990: 02022902
	s_delay_alu instid0(VALU_DEP_1)                            // 000000462994: BF870001
	v_add_co_ci_u32_e64 v3, null, 0, v3, vcc_lo                // 000000462998: D5207C03 01AA0680
	v_subrev_nc_u32_e32 v9, 24, v12                            // 0000004629A0: 4E121898
	v_cmp_ne_u32_e32 vcc_lo, 0, v21                            // 0000004629A4: 7C9A2A80
	v_add_nc_u32_e32 v12, 1, v4                                // 0000004629A8: 4A180881
	v_subrev_nc_u32_e32 v14, 23, v4                            // 0000004629AC: 4E1C0897
	v_add3_u32 v61, v8, v7, 0xfffffd34                         // 0000004629B0: D655003D 03FE0F08 FFFFFD34
	v_lshl_add_u32 v4, v4, 2, v6                               // 0000004629BC: D6460004 04190504
	v_cndmask_b32_e32 v9, 23, v9, vcc_lo                       // 0000004629C4: 02121297
	v_cmp_gt_u32_e32 vcc_lo, 24, v12                           // 0000004629C8: 7C981898
	v_dual_mov_b32 v28, 0 :: v_dual_add_nc_u32 v65, 1, v1      // 0000004629CC: CA200080 1C400281
	v_add_nc_u32_e32 v66, 0x5000, v10                          // 0000004629D4: 4A8414FF 00005000
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000004629DC: BF870244
	v_lshl_add_u32 v7, v9, 2, v6                               // 0000004629E0: D6460007 04190509
	v_cndmask_b32_e32 v5, v14, v12, vcc_lo                     // 0000004629E8: 020A190E
	v_cmp_gt_i32_e32 vcc_lo, 23, v9                            // 0000004629EC: 7C881297
	v_dual_mov_b32 v24, 0 :: v_dual_add_nc_u32 v69, 0x5000, v4 // 0000004629F0: CA200080 184408FF 00005000
	v_dual_mov_b32 v30, 0 :: v_dual_add_nc_u32 v67, 0x5000, v7 // 0000004629FC: CA200080 1E420EFF 00005000
	v_cndmask_b32_e64 v8, 0xffffffa4, 4, vcc_lo                // 000000462A08: D5010008 01A908FF FFFFFFA4
	.long 0xd7006a02                                           // 000000462A14: D7006A02
	v_cndmask_b32_e32 v1, s28, v2, vcc_lo                      // 000000462A18: 0202041C
	v_lshl_add_u32 v5, v5, 2, v6                               // 000000462A1C: D6460005 04190505
	v_add_co_ci_u32_e64 v3, null, s29, v3, vcc_lo              // 000000462A24: D5207C03 01AA061D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000462A2C: BF8701A3
	.long 0xd7006a11                                           // 000000462A30: D7006A11
	v_cndmask_b32_e32 v1, 0x300, v2, vcc_lo                    // 000000462A34: 020204FF 00000300
	v_dual_mov_b32 v27, 0 :: v_dual_add_nc_u32 v2, v7, v8      // 000000462A3C: CA200080 1B021107
	v_add_co_ci_u32_e64 v18, null, 0, v3, vcc_lo               // 000000462A44: D5207C12 01AA0680
	v_dual_mov_b32 v29, 0 :: v_dual_add_nc_u32 v70, 0x5000, v5 // 000000462A4C: CA200080 1D460AFF 00005000
	s_delay_alu instid0(VALU_DEP_3)                            // 000000462A58: BF870003
	v_dual_mov_b32 v25, 0 :: v_dual_add_nc_u32 v68, 0x5000, v2 // 000000462A5C: CA200080 194404FF 00005000
	v_dual_mov_b32 v31, 0 :: v_dual_mov_b32 v32, 0             // 000000462A68: CA100080 1F200080
	v_dual_mov_b32 v33, 0 :: v_dual_mov_b32 v34, 0             // 000000462A70: CA100080 21220080
	v_dual_mov_b32 v35, 0 :: v_dual_mov_b32 v36, 0             // 000000462A78: CA100080 23240080
	v_dual_mov_b32 v37, 0 :: v_dual_mov_b32 v38, 0             // 000000462A80: CA100080 25260080
	v_dual_mov_b32 v39, 0 :: v_dual_mov_b32 v40, 0             // 000000462A88: CA100080 27280080
	v_dual_mov_b32 v41, 0 :: v_dual_mov_b32 v42, 0             // 000000462A90: CA100080 292A0080
	v_dual_mov_b32 v43, 0 :: v_dual_mov_b32 v44, 0             // 000000462A98: CA100080 2B2C0080
	v_dual_mov_b32 v45, 0 :: v_dual_mov_b32 v46, 0             // 000000462AA0: CA100080 2D2E0080
	v_dual_mov_b32 v47, 0 :: v_dual_mov_b32 v48, 0             // 000000462AA8: CA100080 2F300080
	v_dual_mov_b32 v49, 0 :: v_dual_mov_b32 v50, 0             // 000000462AB0: CA100080 31320080
	v_dual_mov_b32 v51, 0 :: v_dual_mov_b32 v52, 0             // 000000462AB8: CA100080 33340080
	v_mov_b32_e32 v53, 0                                       // 000000462AC0: 7E6A0280
	v_mov_b32_e32 v23, 0                                       // 000000462AC4: 7E2E0280
	s_mov_b32 s4, 0                                            // 000000462AC8: BE840080
	s_movk_i32 s5, 0x1eee                                      // 000000462ACC: B0051EEE
	s_branch 1050                                              // 000000462AD0: BFA0041A <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb0ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1c3c>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000462AD4: 8C7E007E
	ds_load_2addr_b32 v[71:72], v68 offset1:24                 // 000000462AD8: D8DC1800 47000044
	ds_load_2addr_b32 v[73:74], v70 offset1:24                 // 000000462AE0: D8DC1800 49000046
	ds_load_2addr_b32 v[10:11], v67 offset1:24                 // 000000462AE8: D8DC1800 0A000043
	ds_load_2addr_b32 v[77:78], v69 offset1:24                 // 000000462AF0: D8DC1800 4D000045
	ds_load_b128 v[5:8], v63                                   // 000000462AF8: DBFC0000 0500003F
	ds_load_b128 v[1:4], v63 offset:5120                       // 000000462B00: DBFC1400 0100003F
	.long 0xd7000011                                           // 000000462B08: D7000011
	v_cndmask_b32_e32 v1, 0x300, v17, vcc_lo                   // 000000462B0C: 020222FF 00000300
	s_delay_alu instid0(VALU_DEP_1)                            // 000000462B14: BF870001
	v_add_co_ci_u32_e64 v18, null, 0, v18, s0                  // 000000462B18: D5207C12 00022480
	v_add_nc_u32_e32 v65, 1, v65                               // 000000462B20: 4A828281
	s_waitcnt lgkmcnt(4)                                       // 000000462B24: BF89FC47
	v_dual_mov_b32 v9, v71 :: v_dual_mov_b32 v76, v73          // 000000462B28: CA100147 094C0149
	s_waitcnt lgkmcnt(2)                                       // 000000462B30: BF89FC27
	v_mov_b32_e32 v75, v78                                     // 000000462B34: 7E96034E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000462B38: BF870192
	.long 0xd73d004e                                           // 000000462B3C: D73D004E
	v_cndmask_b32_e32 v1, v61, v9, vcc_lo                      // 000000462B40: 0202133D
	.long 0xd73d004c                                           // 000000462B44: D73D004C
	v_cndmask_b32_e32 v1, v62, v76, vcc_lo                     // 000000462B48: 0202993E
	v_mov_b32_e32 v73, v11                                     // 000000462B4C: 7E92030B
	ds_load_b128 v[9:12], v63 offset:10240                     // 000000462B50: DBFC2800 0900003F
	ds_load_b128 v[13:16], v63 offset:15360                    // 000000462B58: DBFC3C00 0D00003F
	v_add_nc_u32_e32 v63, 32, v63                              // 000000462B60: 4A7E7EA0
	.long 0xd73d0047                                           // 000000462B64: D73D0047
	v_cndmask_b32_e32 v1, v61, v72, vcc_lo                     // 000000462B68: 0202913D
	.long 0xd73d0048                                           // 000000462B6C: D73D0048
	v_cndmask_b32_e32 v1, v62, v74, vcc_lo                     // 000000462B70: 0202953E
	v_bfe_u32 v73, v78, 9, 16                                  // 000000462B74: D6100049 0241134E
	v_bfe_u32 v74, v78, 6, 16                                  // 000000462B7C: D610004A 02410D4E
	v_bfe_u32 v75, v78, 3, 16                                  // 000000462B84: D610004B 0241074E
	v_bfe_u32 v79, v76, 6, 16                                  // 000000462B8C: D610004F 02410D4C
	v_bfe_u32 v80, v76, 3, 16                                  // 000000462B94: D6100050 0241074C
	.long 0xd72c0049                                           // 000000462B9C: D72C0049
	v_cndmask_b32_e32 v1, 0x83dcd12d, v73, vcc_lo              // 000000462BA0: 020292FF 83DCD12D
	.long 0xd72c004a                                           // 000000462BA8: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 000000462BAC: 020294FF 83DCD12D
	.long 0xd72c004b                                           // 000000462BB4: D72C004B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v75, vcc_lo              // 000000462BB8: 020296FF 83DCD12D
	.long 0xd72c004f                                           // 000000462BC0: D72C004F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v79, vcc_lo              // 000000462BC4: 02029EFF 83DCD12D
	v_bfe_u32 v81, v71, 9, 16                                  // 000000462BCC: D6100051 02411347
	v_bfe_u32 v82, v71, 6, 16                                  // 000000462BD4: D6100052 02410D47
	v_bfe_u32 v83, v71, 3, 16                                  // 000000462BDC: D6100053 02410747
	.long 0xd72c0050                                           // 000000462BE4: D72C0050
	v_cndmask_b32_e32 v1, 0x83dcd12d, v80, vcc_lo              // 000000462BE8: 0202A0FF 83DCD12D
	v_sad_u8 v73, v73, 0, 0x6400                               // 000000462BF0: D6220049 03FD0149 00006400
	v_sad_u8 v74, v74, 0, 0x6400                               // 000000462BFC: D622004A 03FD014A 00006400
	v_sad_u8 v75, v75, 0, 0x6400                               // 000000462C08: D622004B 03FD014B 00006400
	v_sad_u8 v79, v79, 0, 0x6400                               // 000000462C14: D622004F 03FD014F 00006400
	.long 0xd72c0053                                           // 000000462C20: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v83, vcc_lo              // 000000462C24: 0202A6FF 83DCD12D
	v_and_b32_e32 v73, 0xffff, v73                             // 000000462C2C: 369292FF 0000FFFF
	.long 0xd72c0051                                           // 000000462C34: D72C0051
	v_cndmask_b32_e32 v1, 0x83dcd12d, v81, vcc_lo              // 000000462C38: 0202A2FF 83DCD12D
	.long 0xd72c0052                                           // 000000462C40: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 000000462C44: 0202A4FF 83DCD12D
	v_bfe_u32 v84, v72, 9, 16                                  // 000000462C4C: D6100054 02411348
	v_bfe_u32 v85, v72, 6, 16                                  // 000000462C54: D6100055 02410D48
	v_lshl_or_b32 v73, v74, 16, v73                            // 000000462C5C: D6560049 0525214A
	v_sad_u8 v74, v80, 0, 0x6400                               // 000000462C64: D622004A 03FD0150 00006400
	v_bfe_u32 v86, v72, 3, 16                                  // 000000462C70: D6100056 02410748
	v_and_b32_e32 v72, 0xffff, v72                             // 000000462C78: 369090FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4)                            // 000000462C80: BF870004
	v_pk_fma_f16 v73, v73, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000462C84: CC0E0049 0BFC0B49 0000C931
	v_and_b32_e32 v77, 0xffff, v78                             // 000000462C90: 369A9CFF 0000FFFF
	v_bfe_u32 v78, v76, 9, 16                                  // 000000462C98: D610004E 0241134C
	v_and_b32_e32 v76, 0xffff, v76                             // 000000462CA0: 369898FF 0000FFFF
	s_waitcnt lgkmcnt(2)                                       // 000000462CA8: BF89FC27
	v_dual_dot2acc_f32_f16 v26, v73, v1 :: v_dual_and_b32 v71, 0xffff, v71// 000000462CAC: CB240349 1A468EFF 0000FFFF
	v_dot2acc_f32_f16 v22, v73, v5                             // 000000462CB8: 042C0B49
	.long 0xd72c004d                                           // 000000462CBC: D72C004D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v77, vcc_lo              // 000000462CC0: 02029AFF 83DCD12D
	.long 0xd72c004e                                           // 000000462CC8: D72C004E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 000000462CCC: 02029CFF 83DCD12D
	.long 0xd72c004c                                           // 000000462CD4: D72C004C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v76, vcc_lo              // 000000462CD8: 020298FF 83DCD12D
	.long 0xd72c0047                                           // 000000462CE0: D72C0047
	v_cndmask_b32_e32 v1, 0x83dcd12d, v71, vcc_lo              // 000000462CE4: 02028EFF 83DCD12D
	s_waitcnt lgkmcnt(1)                                       // 000000462CEC: BF89FC17
	v_dot2acc_f32_f16 v27, v73, v9                             // 000000462CF0: 04361349
	v_sad_u8 v77, v77, 0, 0x6400                               // 000000462CF4: D622004D 03FD014D 00006400
	v_sad_u8 v78, v78, 0, 0x6400                               // 000000462D00: D622004E 03FD014E 00006400
	v_sad_u8 v76, v76, 0, 0x6400                               // 000000462D0C: D622004C 03FD014C 00006400
	v_sad_u8 v71, v71, 0, 0x6400                               // 000000462D18: D6220047 03FD0147 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000462D24: BF870214
	v_lshlrev_b32_e32 v77, 16, v77                             // 000000462D28: 309A9A90
	v_and_b32_e32 v78, 0xffff, v78                             // 000000462D2C: 369C9CFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000462D34: BF870214
	v_lshlrev_b32_e32 v76, 16, v76                             // 000000462D38: 30989890
	v_lshlrev_b32_e32 v71, 16, v71                             // 000000462D3C: 308E8E90
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000462D40: BF870214
	v_and_or_b32 v75, 0xffff, v75, v77                         // 000000462D44: D657004B 053696FF 0000FFFF
	v_lshl_or_b32 v78, v79, 16, v78                            // 000000462D50: D656004E 0539214F
	s_delay_alu instid0(VALU_DEP_4)                            // 000000462D58: BF870004
	v_and_or_b32 v74, 0xffff, v74, v76                         // 000000462D5C: D657004A 053294FF 0000FFFF
	.long 0xd72c004d                                           // 000000462D68: D72C004D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v84, vcc_lo              // 000000462D6C: 0202A8FF 83DCD12D
	.long 0xd72c004f                                           // 000000462D74: D72C004F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v72, vcc_lo              // 000000462D78: 020290FF 83DCD12D
	v_pk_fma_f16 v75, v75, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000462D80: CC0E004B 0BFC0B4B 0000C931
	v_pk_fma_f16 v76, v78, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000462D8C: CC0E004C 0BFC0B4E 0000C931
	v_pk_fma_f16 v78, v74, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000462D98: CC0E004E 0BFC0B4A 0000C931
	v_sad_u8 v74, v82, 0, 0x6400                               // 000000462DA4: D622004A 03FD0152 00006400
	s_waitcnt lgkmcnt(0)                                       // 000000462DB0: BF89FC07
	v_dual_dot2acc_f32_f16 v22, v75, v6 :: v_dual_dot2acc_f32_f16 v25, v73, v13// 000000462DB4: CB180D4B 16181B49
	v_dot2acc_f32_f16 v26, v75, v2                             // 000000462DBC: 0434054B
	v_dot2acc_f32_f16 v27, v75, v10                            // 000000462DC0: 0436154B
	v_sad_u8 v73, v81, 0, 0x6400                               // 000000462DC4: D6220049 03FD0151 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000462DD0: BF8701B4
	v_dual_dot2acc_f32_f16 v22, v76, v7 :: v_dual_dot2acc_f32_f16 v25, v75, v14// 000000462DD4: CB180F4C 16181D4B
	v_sad_u8 v75, v83, 0, 0x6400                               // 000000462DDC: D622004B 03FD0153 00006400
	v_dot2acc_f32_f16 v26, v76, v3                             // 000000462DE8: 0434074C
	v_dual_dot2acc_f32_f16 v27, v76, v11 :: v_dual_dot2acc_f32_f16 v22, v78, v8// 000000462DEC: CB18174C 1B16114E
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000462DF4: BF870214
	v_dot2acc_f32_f16 v25, v76, v15                            // 000000462DF8: 04321F4C
	v_and_or_b32 v80, 0xffff, v75, v71                         // 000000462DFC: D6570050 051E96FF 0000FFFF
	.long 0xd72c004c                                           // 000000462E08: D72C004C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v85, vcc_lo              // 000000462E0C: 0202AAFF 83DCD12D
	v_sad_u8 v77, v77, 0, 0x6400                               // 000000462E14: D622004D 03FD014D 00006400
	v_dot2acc_f32_f16 v26, v78, v4                             // 000000462E20: 0434094E
	ds_load_2addr_b32 v[71:72], v68 offset0:48 offset1:72      // 000000462E24: D8DC4830 47000044
	v_pk_fma_f16 v83, v80, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000462E2C: CC0E0053 0BFC0B50 0000C931
	v_and_b32_e32 v73, 0xffff, v73                             // 000000462E38: 369292FF 0000FFFF
	.long 0xd72c0051                                           // 000000462E40: D72C0051
	v_cndmask_b32_e32 v1, 0x83dcd12d, v86, vcc_lo              // 000000462E44: 0202ACFF 83DCD12D
	v_dot2acc_f32_f16 v25, v78, v16                            // 000000462E4C: 0432214E
	v_sad_u8 v76, v76, 0, 0x6400                               // 000000462E50: D622004C 03FD014C 00006400
	s_delay_alu instid0(VALU_DEP_4)                            // 000000462E5C: BF870004
	v_lshl_or_b32 v73, v74, 16, v73                            // 000000462E60: D6560049 0525214A
	ds_load_2addr_b32 v[74:75], v67 offset0:48 offset1:72      // 000000462E68: D8DC4830 4A000043
	v_sad_u8 v81, v81, 0, 0x6400                               // 000000462E70: D6220051 03FD0151 00006400
	v_pk_fma_f16 v82, v73, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000462E7C: CC0E0052 0BFC0B49 0000C931
	v_sad_u8 v73, v79, 0, 0x6400                               // 000000462E88: D6220049 03FD014F 00006400
	ds_load_2addr_b32 v[79:80], v69 offset0:48 offset1:72      // 000000462E94: D8DC4830 4F000045
	v_dot2acc_f32_f16 v28, v82, v5                             // 000000462E9C: 04380B52
	v_dot2acc_f32_f16 v27, v78, v12                            // 000000462EA0: 0436194E
	v_dot2acc_f32_f16 v30, v82, v9                             // 000000462EA4: 043C1352
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000462EA8: BF870113
	v_dual_dot2acc_f32_f16 v28, v83, v6 :: v_dual_and_b32 v77, 0xffff, v77// 000000462EAC: CB240D53 1C4C9AFF 0000FFFF
	v_dot2acc_f32_f16 v30, v83, v10                            // 000000462EB8: 043C1553
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000462EBC: BF8700B2
	v_lshl_or_b32 v84, v76, 16, v77                            // 000000462EC0: D6560054 0535214C
	ds_load_2addr_b32 v[76:77], v70 offset0:48 offset1:72      // 000000462EC8: D8DC4830 4C000046
	v_pk_fma_f16 v84, v84, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000462ED0: CC0E0054 0BFC0B54 0000C931
	v_dual_dot2acc_f32_f16 v30, v84, v11 :: v_dual_lshlrev_b32 v73, 16, v73// 000000462EDC: CB221754 1E489290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000462EE4: BF870131
	v_and_or_b32 v81, 0xffff, v81, v73                         // 000000462EE8: D6570051 0526A2FF 0000FFFF
	s_waitcnt lgkmcnt(3)                                       // 000000462EF4: BF89FC37
	v_dual_mov_b32 v73, v71 :: v_dual_dot2acc_f32_f16 v28, v84, v7// 000000462EF8: CA180147 491C0F54
	v_pk_fma_f16 v71, v81, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000462F00: CC0E0047 0BFC0B51 0000C931
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000462F0C: BF8701C1
	v_dual_dot2acc_f32_f16 v29, v82, v1 :: v_dual_dot2acc_f32_f16 v28, v71, v8// 000000462F10: CB180352 1D1C1147
	s_waitcnt lgkmcnt(0)                                       // 000000462F18: BF89FC07
	v_mov_b32_e32 v78, v76                                     // 000000462F1C: 7E9C034C
	.long 0xd73d0049                                           // 000000462F20: D73D0049
	v_cndmask_b32_e32 v1, v61, v73, vcc_lo                     // 000000462F24: 0202933D
	v_dot2acc_f32_f16 v29, v83, v2                             // 000000462F28: 043A0553
	v_dot2acc_f32_f16 v30, v71, v12                            // 000000462F2C: 043C1947
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000462F30: BF870214
	.long 0xd73d004e                                           // 000000462F34: D73D004E
	v_cndmask_b32_e32 v1, v62, v78, vcc_lo                     // 000000462F38: 02029D3E
	v_bfe_u32 v74, v73, 9, 16                                  // 000000462F3C: D610004A 02411349
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000462F44: BF870234
	v_dual_dot2acc_f32_f16 v29, v84, v3 :: v_dual_and_b32 v76, 0xffff, v73// 000000462F48: CB240754 1D4C92FF 0000FFFF
	v_bfe_u32 v79, v73, 6, 16                                  // 000000462F54: D610004F 02410D49
	v_bfe_u32 v73, v73, 3, 16                                  // 000000462F5C: D6100049 02410749
	.long 0xd72c004a                                           // 000000462F64: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 000000462F68: 020294FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4)                            // 000000462F70: BF870004
	.long 0xd72c004c                                           // 000000462F74: D72C004C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v76, vcc_lo              // 000000462F78: 020298FF 83DCD12D
	v_dot2acc_f32_f16 v29, v71, v4                             // 000000462F80: 043A0947
	v_bfe_u32 v81, v78, 9, 16                                  // 000000462F84: D6100051 0241134E
	.long 0xd72c004f                                           // 000000462F8C: D72C004F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v79, vcc_lo              // 000000462F90: 02029EFF 83DCD12D
	.long 0xd72c0049                                           // 000000462F98: D72C0049
	v_cndmask_b32_e32 v1, 0x83dcd12d, v73, vcc_lo              // 000000462F9C: 020292FF 83DCD12D
	v_sad_u8 v74, v74, 0, 0x6400                               // 000000462FA4: D622004A 03FD014A 00006400
	v_dot2acc_f32_f16 v31, v82, v13                            // 000000462FB0: 043E1B52
	v_bfe_u32 v82, v78, 6, 16                                  // 000000462FB4: D6100052 02410D4E
	v_sad_u8 v76, v76, 0, 0x6400                               // 000000462FBC: D622004C 03FD014C 00006400
	.long 0xd72c0051                                           // 000000462FC8: D72C0051
	v_cndmask_b32_e32 v1, 0x83dcd12d, v81, vcc_lo              // 000000462FCC: 0202A2FF 83DCD12D
	v_and_b32_e32 v74, 0xffff, v74                             // 000000462FD4: 369494FF 0000FFFF
	v_dot2acc_f32_f16 v31, v83, v14                            // 000000462FDC: 043E1D53
	v_bfe_u32 v83, v78, 3, 16                                  // 000000462FE0: D6100053 0241074E
	v_and_b32_e32 v78, 0xffff, v78                             // 000000462FE8: 369C9CFF 0000FFFF
	v_sad_u8 v79, v79, 0, 0x6400                               // 000000462FF0: D622004F 03FD014F 00006400
	v_sad_u8 v73, v73, 0, 0x6400                               // 000000462FFC: D6220049 03FD0149 00006400
	v_lshlrev_b32_e32 v76, 16, v76                             // 000000463008: 30989890
	.long 0xd72c0053                                           // 00000046300C: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v83, vcc_lo              // 000000463010: 0202A6FF 83DCD12D
	.long 0xd72c004e                                           // 000000463018: D72C004E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 00000046301C: 02029CFF 83DCD12D
	v_sad_u8 v81, v81, 0, 0x6400                               // 000000463024: D6220051 03FD0151 00006400
	v_lshl_or_b32 v74, v79, 16, v74                            // 000000463030: D656004A 0529214F
	v_and_or_b32 v73, 0xffff, v73, v76                         // 000000463038: D6570049 053292FF 0000FFFF
	v_dot2acc_f32_f16 v31, v84, v15                            // 000000463044: 043E1F54
	.long 0xd72c0052                                           // 000000463048: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 00000046304C: 0202A4FF 83DCD12D
	v_and_b32_e32 v76, 0xffff, v81                             // 000000463054: 3698A2FF 0000FFFF
	v_pk_fma_f16 v74, v74, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000046305C: CC0E004A 0BFC0B4A 0000C931
	v_sad_u8 v78, v78, 0, 0x6400                               // 000000463068: D622004E 03FD014E 00006400
	v_pk_fma_f16 v81, v73, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000463074: CC0E0051 0BFC0B49 0000C931
	v_sad_u8 v73, v83, 0, 0x6400                               // 000000463080: D6220049 03FD0153 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000046308C: BF870214
	v_dual_dot2acc_f32_f16 v31, v71, v16 :: v_dual_dot2acc_f32_f16 v24, v74, v5// 000000463090: CB182147 1F180B4A
	v_lshlrev_b32_e32 v78, 16, v78                             // 000000463098: 309C9C90
	v_sad_u8 v79, v82, 0, 0x6400                               // 00000046309C: D622004F 03FD0152 00006400
	v_dot2acc_f32_f16 v33, v74, v9                             // 0000004630A8: 0442134A
	v_dot2acc_f32_f16 v32, v74, v1                             // 0000004630AC: 0440034A
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000004630B0: BF870244
	v_and_or_b32 v71, 0xffff, v73, v78                         // 0000004630B4: D6570047 053A92FF 0000FFFF
	v_dual_mov_b32 v73, v75 :: v_dual_mov_b32 v78, v80         // 0000004630C0: CA10014B 494E0150
	v_dot2acc_f32_f16 v24, v81, v6                             // 0000004630C8: 04300D51
	v_lshl_or_b32 v76, v79, 16, v76                            // 0000004630CC: D656004C 0531214F
	v_pk_fma_f16 v82, v71, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000004630D4: CC0E0052 0BFC0B47 0000C931
	s_delay_alu instid0(VALU_DEP_4)                            // 0000004630E0: BF870004
	.long 0xd73d0047                                           // 0000004630E4: D73D0047
	v_cndmask_b32_e32 v1, v61, v72, vcc_lo                     // 0000004630E8: 0202913D
	v_dot2acc_f32_f16 v34, v74, v13                            // 0000004630EC: 04441B4A
	.long 0xd73d0048                                           // 0000004630F0: D73D0048
	v_cndmask_b32_e32 v1, v62, v77, vcc_lo                     // 0000004630F4: 02029B3E
	v_pk_fma_f16 v76, v76, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000004630F8: CC0E004C 0BFC0B4C 0000C931
	v_dot2acc_f32_f16 v33, v81, v10                            // 000000463104: 04421551
	v_dot2acc_f32_f16 v32, v81, v2                             // 000000463108: 04400551
	v_bfe_u32 v74, v71, 9, 16                                  // 00000046310C: D610004A 02411347
	v_dual_dot2acc_f32_f16 v34, v81, v14 :: v_dual_and_b32 v75, 0xffff, v71// 000000463114: CB241D51 224A8EFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000463120: BF870224
	v_dot2acc_f32_f16 v33, v76, v11                            // 000000463124: 0442174C
	v_dot2acc_f32_f16 v24, v76, v7                             // 000000463128: 04300F4C
	.long 0xd72c0049                                           // 00000046312C: D72C0049
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 000000463130: 020294FF 83DCD12D
	v_bfe_u32 v74, v71, 6, 16                                  // 000000463138: D610004A 02410D47
	v_bfe_u32 v71, v71, 3, 16                                  // 000000463140: D6100047 02410747
	.long 0xd72c004b                                           // 000000463148: D72C004B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v75, vcc_lo              // 00000046314C: 020296FF 83DCD12D
	v_dot2acc_f32_f16 v33, v82, v12                            // 000000463154: 04421952
	v_bfe_u32 v77, v72, 6, 16                                  // 000000463158: D610004D 02410D48
	.long 0xd72c004a                                           // 000000463160: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 000000463164: 020294FF 83DCD12D
	.long 0xd72c0047                                           // 00000046316C: D72C0047
	v_cndmask_b32_e32 v1, 0x83dcd12d, v71, vcc_lo              // 000000463170: 02028EFF 83DCD12D
	v_sad_u8 v73, v73, 0, 0x6400                               // 000000463178: D6220049 03FD0149 00006400
	v_dot2acc_f32_f16 v32, v76, v3                             // 000000463184: 0440074C
	v_bfe_u32 v78, v72, 3, 16                                  // 000000463188: D610004E 02410748
	v_sad_u8 v75, v75, 0, 0x6400                               // 000000463190: D622004B 03FD014B 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000046319C: BF870234
	v_dual_dot2acc_f32_f16 v24, v82, v8 :: v_dual_and_b32 v73, 0xffff, v73// 0000004631A0: CB241152 184892FF 0000FFFF
	v_sad_u8 v74, v74, 0, 0x6400                               // 0000004631AC: D622004A 03FD014A 00006400
	v_sad_u8 v71, v71, 0, 0x6400                               // 0000004631B8: D6220047 03FD0147 00006400
	v_lshlrev_b32_e32 v75, 16, v75                             // 0000004631C4: 30969690
	.long 0xd72c004d                                           // 0000004631C8: D72C004D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v77, vcc_lo              // 0000004631CC: 02029AFF 83DCD12D
	.long 0xd72c004e                                           // 0000004631D4: D72C004E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 0000004631D8: 02029CFF 83DCD12D
	v_lshl_or_b32 v73, v74, 16, v73                            // 0000004631E0: D6560049 0525214A
	s_delay_alu instid0(VALU_DEP_4)                            // 0000004631E8: BF870004
	v_and_or_b32 v80, 0xffff, v71, v75                         // 0000004631EC: D6570050 052E8EFF 0000FFFF
	ds_load_2addr_b32 v[74:75], v67 offset0:96 offset1:120     // 0000004631F8: D8DC7860 4A000043
	v_pk_fma_f16 v81, v73, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000463200: CC0E0051 0BFC0B49 0000C931
	v_dot2acc_f32_f16 v34, v76, v15                            // 00000046320C: 04441F4C
	v_bfe_u32 v76, v72, 9, 16                                  // 000000463210: D610004C 02411348
	v_pk_fma_f16 v83, v80, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000463218: CC0E0053 0BFC0B50 0000C931
	v_sad_u8 v77, v77, 0, 0x6400                               // 000000463224: D622004D 03FD014D 00006400
	v_dual_dot2acc_f32_f16 v35, v81, v5 :: v_dual_and_b32 v72, 0xffff, v72// 000000463230: CB240B51 234890FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000046323C: BF870234
	.long 0xd72c004c                                           // 000000463240: D72C004C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v76, vcc_lo              // 000000463244: 020298FF 83DCD12D
	v_dot2acc_f32_f16 v37, v81, v9                             // 00000046324C: 044A1351
	v_sad_u8 v78, v78, 0, 0x6400                               // 000000463250: D622004E 03FD014E 00006400
	v_dot2acc_f32_f16 v35, v83, v6                             // 00000046325C: 04460D53
	.long 0xd72c004f                                           // 000000463260: D72C004F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v72, vcc_lo              // 000000463264: 020290FF 83DCD12D
	ds_load_2addr_b32 v[71:72], v68 offset0:96 offset1:120     // 00000046326C: D8DC7860 47000044
	v_dual_dot2acc_f32_f16 v37, v83, v10 :: v_dual_dot2acc_f32_f16 v38, v81, v13// 000000463274: CB181553 25261B51
	v_sad_u8 v76, v76, 0, 0x6400                               // 00000046327C: D622004C 03FD014C 00006400
	v_sad_u8 v73, v79, 0, 0x6400                               // 000000463288: D6220049 03FD014F 00006400
	s_delay_alu instid0(VALU_DEP_2)                            // 000000463294: BF870002
	v_and_b32_e32 v76, 0xffff, v76                             // 000000463298: 369898FF 0000FFFF
	v_dot2acc_f32_f16 v32, v82, v4                             // 0000004632A0: 04400952
	ds_load_2addr_b32 v[79:80], v69 offset0:96 offset1:120     // 0000004632A4: D8DC7860 4F000045
	v_lshlrev_b32_e32 v73, 16, v73                             // 0000004632AC: 30929290
	v_lshl_or_b32 v84, v77, 16, v76                            // 0000004632B0: D6560054 0531214D
	ds_load_2addr_b32 v[76:77], v70 offset0:96 offset1:120     // 0000004632B8: D8DC7860 4C000046
	v_and_or_b32 v78, 0xffff, v78, v73                         // 0000004632C0: D657004E 05269CFF 0000FFFF
	v_pk_fma_f16 v84, v84, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000004632CC: CC0E0054 0BFC0B54 0000C931
	s_waitcnt lgkmcnt(2)                                       // 0000004632D8: BF89FC27
	v_dual_dot2acc_f32_f16 v36, v81, v1 :: v_dual_mov_b32 v73, v71// 0000004632DC: CB100351 24480147
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000004632E4: BF870113
	v_pk_fma_f16 v71, v78, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000004632E8: CC0E0047 0BFC0B4E 0000C931
	v_dual_dot2acc_f32_f16 v35, v84, v7 :: v_dual_dot2acc_f32_f16 v36, v83, v2// 0000004632F4: CB180F54 23240553
	v_dot2acc_f32_f16 v37, v84, v11                            // 0000004632FC: 044A1754
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000463300: BF870194
	.long 0xd73d0049                                           // 000000463304: D73D0049
	v_cndmask_b32_e32 v1, v61, v73, vcc_lo                     // 000000463308: 0202933D
	v_dual_dot2acc_f32_f16 v35, v71, v8 :: v_dual_dot2acc_f32_f16 v36, v84, v3// 00000046330C: CB181147 23240754
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000463314: BF870193
	v_dot2acc_f32_f16 v37, v71, v12                            // 000000463318: 044A1947
	v_bfe_u32 v74, v73, 9, 16                                  // 00000046331C: D610004A 02411349
	s_waitcnt lgkmcnt(0)                                       // 000000463324: BF89FC07
	v_mov_b32_e32 v78, v76                                     // 000000463328: 7E9C034C
	v_and_b32_e32 v76, 0xffff, v73                             // 00000046332C: 369892FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000463334: BF870193
	.long 0xd72c004a                                           // 000000463338: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 00000046333C: 020294FF 83DCD12D
	.long 0xd73d004e                                           // 000000463344: D73D004E
	v_cndmask_b32_e32 v1, v62, v78, vcc_lo                     // 000000463348: 02029D3E
	v_bfe_u32 v79, v73, 6, 16                                  // 00000046334C: D610004F 02410D49
	v_bfe_u32 v73, v73, 3, 16                                  // 000000463354: D6100049 02410749
	.long 0xd72c004c                                           // 00000046335C: D72C004C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v76, vcc_lo              // 000000463360: 020298FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3)                            // 000000463368: BF870003
	.long 0xd72c004f                                           // 00000046336C: D72C004F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v79, vcc_lo              // 000000463370: 02029EFF 83DCD12D
	v_sad_u8 v74, v74, 0, 0x6400                               // 000000463378: D622004A 03FD014A 00006400
	v_bfe_u32 v81, v78, 9, 16                                  // 000000463384: D6100051 0241134E
	.long 0xd72c0049                                           // 00000046338C: D72C0049
	v_cndmask_b32_e32 v1, 0x83dcd12d, v73, vcc_lo              // 000000463390: 020292FF 83DCD12D
	v_bfe_u32 v85, v78, 3, 16                                  // 000000463398: D6100055 0241074E
	v_sad_u8 v76, v76, 0, 0x6400                               // 0000004633A0: D622004C 03FD014C 00006400
	v_and_b32_e32 v74, 0xffff, v74                             // 0000004633AC: 369494FF 0000FFFF
	.long 0xd72c0051                                           // 0000004633B4: D72C0051
	v_cndmask_b32_e32 v1, 0x83dcd12d, v81, vcc_lo              // 0000004633B8: 0202A2FF 83DCD12D
	v_sad_u8 v79, v79, 0, 0x6400                               // 0000004633C0: D622004F 03FD014F 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000004633CC: BF8701A4
	v_lshlrev_b32_e32 v76, 16, v76                             // 0000004633D0: 30989890
	v_sad_u8 v73, v73, 0, 0x6400                               // 0000004633D4: D6220049 03FD0149 00006400
	v_lshl_or_b32 v74, v79, 16, v74                            // 0000004633E0: D656004A 0529214F
	v_sad_u8 v81, v81, 0, 0x6400                               // 0000004633E8: D6220051 03FD0151 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000004633F4: BF870193
	v_and_or_b32 v73, 0xffff, v73, v76                         // 0000004633F8: D6570049 053292FF 0000FFFF
	v_pk_fma_f16 v74, v74, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000463404: CC0E004A 0BFC0B4A 0000C931
	v_dot2acc_f32_f16 v36, v71, v4                             // 000000463410: 04480947
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000463414: BF870214
	v_and_b32_e32 v76, 0xffff, v81                             // 000000463418: 3698A2FF 0000FFFF
	v_pk_fma_f16 v81, v73, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000463420: CC0E0051 0BFC0B49 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 00000046342C: BF870244
	v_dot2acc_f32_f16 v39, v74, v5                             // 000000463430: 044E0B4A
	v_dot2acc_f32_f16 v34, v82, v16                            // 000000463434: 04442152
	v_bfe_u32 v82, v78, 6, 16                                  // 000000463438: D6100052 02410D4E
	v_dual_dot2acc_f32_f16 v41, v74, v9 :: v_dual_and_b32 v78, 0xffff, v78// 000000463440: CB24134A 294E9CFF 0000FFFF
	v_dual_dot2acc_f32_f16 v39, v81, v6 :: v_dual_dot2acc_f32_f16 v42, v74, v13// 00000046344C: CB180D51 272A1B4A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000463454: BF870193
	.long 0xd72c0052                                           // 000000463458: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 00000046345C: 0202A4FF 83DCD12D
	.long 0xd72c004e                                           // 000000463464: D72C004E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 000000463468: 02029CFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000463470: BF870214
	v_dot2acc_f32_f16 v41, v81, v10                            // 000000463474: 04521551
	v_dot2acc_f32_f16 v42, v81, v14                            // 000000463478: 04541D51
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000046347C: BF870214
	v_sad_u8 v79, v82, 0, 0x6400                               // 000000463480: D622004F 03FD0152 00006400
	v_sad_u8 v78, v78, 0, 0x6400                               // 00000046348C: D622004E 03FD014E 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000463498: BF870112
	v_lshl_or_b32 v76, v79, 16, v76                            // 00000046349C: D656004C 0531214F
	v_lshlrev_b32_e32 v78, 16, v78                             // 0000004634A4: 309C9C90
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004634A8: BF870092
	v_pk_fma_f16 v82, v76, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000004634AC: CC0E0052 0BFC0B4C 0000C931
	v_dual_dot2acc_f32_f16 v39, v82, v7 :: v_dual_dot2acc_f32_f16 v38, v83, v14// 0000004634B8: CB180F52 27261D53
	v_dot2acc_f32_f16 v41, v82, v11                            // 0000004634C0: 04521752
	.long 0xd72c0053                                           // 0000004634C4: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v85, vcc_lo              // 0000004634C8: 0202AAFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000004634D0: BF870113
	v_dot2acc_f32_f16 v38, v84, v15                            // 0000004634D4: 044C1F54
	v_sad_u8 v73, v83, 0, 0x6400                               // 0000004634D8: D6220049 03FD0153 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000004634E4: BF870112
	v_dot2acc_f32_f16 v38, v71, v16                            // 0000004634E8: 044C2147
	v_and_or_b32 v73, 0xffff, v73, v78                         // 0000004634EC: D6570049 053A92FF 0000FFFF
	v_mov_b32_e32 v78, v80                                     // 0000004634F8: 7E9C0350
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000004634FC: BF870122
	v_pk_fma_f16 v83, v73, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000463500: CC0E0053 0BFC0B49 0000C931
	v_mov_b32_e32 v73, v75                                     // 00000046350C: 7E92034B
	v_dot2acc_f32_f16 v39, v83, v8                             // 000000463510: 044E1153
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000463514: BF870242
	.long 0xd73d0047                                           // 000000463518: D73D0047
	v_cndmask_b32_e32 v1, v61, v72, vcc_lo                     // 00000046351C: 0202913D
	v_dot2acc_f32_f16 v40, v74, v1                             // 000000463520: 0450034A
	.long 0xd73d0048                                           // 000000463524: D73D0048
	v_cndmask_b32_e32 v1, v62, v77, vcc_lo                     // 000000463528: 02029B3E
	v_dot2acc_f32_f16 v41, v83, v12                            // 00000046352C: 04521953
	v_bfe_u32 v74, v71, 9, 16                                  // 000000463530: D610004A 02411347
	v_and_b32_e32 v75, 0xffff, v71                             // 000000463538: 36968EFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4)                            // 000000463540: BF870004
	v_bfe_u32 v76, v72, 9, 16                                  // 000000463544: D610004C 02411348
	v_bfe_u32 v77, v72, 6, 16                                  // 00000046354C: D610004D 02410D48
	v_bfe_u32 v78, v72, 3, 16                                  // 000000463554: D610004E 02410748
	.long 0xd72c0049                                           // 00000046355C: D72C0049
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 000000463560: 020294FF 83DCD12D
	v_bfe_u32 v74, v71, 6, 16                                  // 000000463568: D610004A 02410D47
	v_bfe_u32 v71, v71, 3, 16                                  // 000000463570: D6100047 02410747
	.long 0xd72c004b                                           // 000000463578: D72C004B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v75, vcc_lo              // 00000046357C: 020296FF 83DCD12D
	.long 0xd72c004c                                           // 000000463584: D72C004C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v76, vcc_lo              // 000000463588: 020298FF 83DCD12D
	v_and_b32_e32 v72, 0xffff, v72                             // 000000463590: 369090FF 0000FFFF
	.long 0xd72c004a                                           // 000000463598: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 00000046359C: 020294FF 83DCD12D
	.long 0xd72c0047                                           // 0000004635A4: D72C0047
	v_cndmask_b32_e32 v1, 0x83dcd12d, v71, vcc_lo              // 0000004635A8: 02028EFF 83DCD12D
	v_sad_u8 v73, v73, 0, 0x6400                               // 0000004635B0: D6220049 03FD0149 00006400
	.long 0xd72c004d                                           // 0000004635BC: D72C004D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v77, vcc_lo              // 0000004635C0: 02029AFF 83DCD12D
	.long 0xd72c004f                                           // 0000004635C8: D72C004F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v72, vcc_lo              // 0000004635CC: 020290FF 83DCD12D
	v_sad_u8 v75, v75, 0, 0x6400                               // 0000004635D4: D622004B 03FD014B 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000004635E0: BF870234
	v_dual_dot2acc_f32_f16 v40, v81, v2 :: v_dual_and_b32 v73, 0xffff, v73// 0000004635E4: CB240551 284892FF 0000FFFF
	v_sad_u8 v74, v74, 0, 0x6400                               // 0000004635F0: D622004A 03FD014A 00006400
	v_sad_u8 v71, v71, 0, 0x6400                               // 0000004635FC: D6220047 03FD0147 00006400
	v_lshlrev_b32_e32 v75, 16, v75                             // 000000463608: 30969690
	v_sad_u8 v76, v76, 0, 0x6400                               // 00000046360C: D622004C 03FD014C 00006400
	v_sad_u8 v77, v77, 0, 0x6400                               // 000000463618: D622004D 03FD014D 00006400
	v_lshl_or_b32 v73, v74, 16, v73                            // 000000463624: D6560049 0525214A
	.long 0xd72c004e                                           // 00000046362C: D72C004E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 000000463630: 02029CFF 83DCD12D
	v_and_or_b32 v80, 0xffff, v71, v75                         // 000000463638: D6570050 052E8EFF 0000FFFF
	ds_load_2addr_b32 v[71:72], v68 offset0:144 offset1:168    // 000000463644: D8DCA890 47000044
	v_and_b32_e32 v76, 0xffff, v76                             // 00000046364C: 369898FF 0000FFFF
	ds_load_2addr_b32 v[74:75], v67 offset0:144 offset1:168    // 000000463654: D8DCA890 4A000043
	v_pk_fma_f16 v81, v73, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000046365C: CC0E0051 0BFC0B49 0000C931
	v_sad_u8 v73, v79, 0, 0x6400                               // 000000463668: D6220049 03FD014F 00006400
	v_dot2acc_f32_f16 v40, v82, v3                             // 000000463674: 04500752
	v_lshl_or_b32 v85, v77, 16, v76                            // 000000463678: D6560055 0531214D
	ds_load_2addr_b32 v[76:77], v70 offset0:144 offset1:168    // 000000463680: D8DCA890 4C000046
	v_pk_fma_f16 v84, v80, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000463688: CC0E0054 0BFC0B50 0000C931
	v_sad_u8 v78, v78, 0, 0x6400                               // 000000463694: D622004E 03FD014E 00006400
	v_lshlrev_b32_e32 v73, 16, v73                             // 0000004636A0: 30929290
	ds_load_2addr_b32 v[79:80], v69 offset0:144 offset1:168    // 0000004636A4: D8DCA890 4F000045
	v_dual_dot2acc_f32_f16 v43, v81, v5 :: v_dual_dot2acc_f32_f16 v40, v83, v4// 0000004636AC: CB180B51 2B280953
	v_dot2acc_f32_f16 v45, v81, v9                             // 0000004636B4: 045A1351
	v_and_or_b32 v78, 0xffff, v78, v73                         // 0000004636B8: D657004E 05269CFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000004636C4: BF870193
	v_dual_dot2acc_f32_f16 v46, v81, v13 :: v_dual_dot2acc_f32_f16 v43, v84, v6// 0000004636C8: CB181B51 2E2A0D54
	v_dot2acc_f32_f16 v45, v84, v10                            // 0000004636D0: 045A1554
	s_waitcnt lgkmcnt(3)                                       // 0000004636D4: BF89FC37
	v_mov_b32_e32 v73, v71                                     // 0000004636D8: 7E920347
	v_pk_fma_f16 v71, v78, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000004636DC: CC0E0047 0BFC0B4E 0000C931
	v_dot2acc_f32_f16 v42, v82, v15                            // 0000004636E8: 04541F52
	v_pk_fma_f16 v82, v85, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000004636EC: CC0E0052 0BFC0B55 0000C931
	s_waitcnt lgkmcnt(2)                                       // 0000004636F8: BF89FC27
	.long 0xd73d0049                                           // 0000004636FC: D73D0049
	v_cndmask_b32_e32 v1, v61, v73, vcc_lo                     // 000000463700: 0202933D
	s_waitcnt lgkmcnt(1)                                       // 000000463704: BF89FC17
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000463708: BF8701A2
	v_dual_mov_b32 v78, v76 :: v_dual_dot2acc_f32_f16 v43, v82, v7// 00000046370C: CA18014C 4E2A0F52
	v_dual_dot2acc_f32_f16 v44, v81, v1 :: v_dual_dot2acc_f32_f16 v45, v82, v11// 000000463714: CB180351 2C2C1752
	v_bfe_u32 v74, v73, 9, 16                                  // 00000046371C: D610004A 02411349
	s_waitcnt lgkmcnt(0)                                       // 000000463724: BF89FC07
	s_delay_alu instid0(VALU_DEP_3)                            // 000000463728: BF870003
	.long 0xd73d004e                                           // 00000046372C: D73D004E
	v_cndmask_b32_e32 v1, v62, v78, vcc_lo                     // 000000463730: 02029D3E
	v_and_b32_e32 v76, 0xffff, v73                             // 000000463734: 369892FF 0000FFFF
	v_bfe_u32 v79, v73, 6, 16                                  // 00000046373C: D610004F 02410D49
	v_bfe_u32 v73, v73, 3, 16                                  // 000000463744: D6100049 02410749
	.long 0xd72c004a                                           // 00000046374C: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 000000463750: 020294FF 83DCD12D
	v_dot2acc_f32_f16 v43, v71, v8                             // 000000463758: 04561147
	.long 0xd72c004c                                           // 00000046375C: D72C004C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v76, vcc_lo              // 000000463760: 020298FF 83DCD12D
	.long 0xd72c004f                                           // 000000463768: D72C004F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v79, vcc_lo              // 00000046376C: 02029EFF 83DCD12D
	v_bfe_u32 v81, v78, 9, 16                                  // 000000463774: D6100051 0241134E
	.long 0xd72c0049                                           // 00000046377C: D72C0049
	v_cndmask_b32_e32 v1, 0x83dcd12d, v73, vcc_lo              // 000000463780: 020292FF 83DCD12D
	v_dot2acc_f32_f16 v45, v71, v12                            // 000000463788: 045A1947
	v_bfe_u32 v85, v78, 3, 16                                  // 00000046378C: D6100055 0241074E
	v_sad_u8 v74, v74, 0, 0x6400                               // 000000463794: D622004A 03FD014A 00006400
	.long 0xd72c0051                                           // 0000004637A0: D72C0051
	v_cndmask_b32_e32 v1, 0x83dcd12d, v81, vcc_lo              // 0000004637A4: 0202A2FF 83DCD12D
	v_sad_u8 v76, v76, 0, 0x6400                               // 0000004637AC: D622004C 03FD014C 00006400
	v_sad_u8 v79, v79, 0, 0x6400                               // 0000004637B8: D622004F 03FD014F 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000004637C4: BF870224
	v_and_b32_e32 v74, 0xffff, v74                             // 0000004637C8: 369494FF 0000FFFF
	v_sad_u8 v73, v73, 0, 0x6400                               // 0000004637D0: D6220049 03FD0149 00006400
	v_lshlrev_b32_e32 v76, 16, v76                             // 0000004637DC: 30989890
	v_sad_u8 v81, v81, 0, 0x6400                               // 0000004637E0: D6220051 03FD0151 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000004637EC: BF870194
	v_lshl_or_b32 v74, v79, 16, v74                            // 0000004637F0: D656004A 0529214F
	v_and_or_b32 v73, 0xffff, v73, v76                         // 0000004637F8: D6570049 053292FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000463804: BF870193
	v_and_b32_e32 v76, 0xffff, v81                             // 000000463808: 3698A2FF 0000FFFF
	v_pk_fma_f16 v74, v74, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000463810: CC0E004A 0BFC0B4A 0000C931
	v_dot2acc_f32_f16 v44, v84, v2                             // 00000046381C: 04580554
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000463820: BF870194
	v_pk_fma_f16 v81, v73, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000463824: CC0E0051 0BFC0B49 0000C931
	v_dot2acc_f32_f16 v47, v74, v5                             // 000000463830: 045E0B4A
	v_dot2acc_f32_f16 v49, v74, v9                             // 000000463834: 0462134A
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000463838: BF870224
	v_dot2acc_f32_f16 v44, v82, v3                             // 00000046383C: 04580752
	v_dot2acc_f32_f16 v48, v74, v1                             // 000000463840: 0460034A
	v_dual_dot2acc_f32_f16 v50, v74, v13 :: v_dual_dot2acc_f32_f16 v47, v81, v6// 000000463844: CB181B4A 322E0D51
	v_dot2acc_f32_f16 v42, v83, v16                            // 00000046384C: 04542153
	v_bfe_u32 v83, v78, 6, 16                                  // 000000463850: D6100053 02410D4E
	v_dual_dot2acc_f32_f16 v44, v71, v4 :: v_dual_dot2acc_f32_f16 v49, v81, v10// 000000463858: CB180947 2C301551
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000463860: BF870092
	.long 0xd72c0053                                           // 000000463864: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v83, vcc_lo              // 000000463868: 0202A6FF 83DCD12D
	v_sad_u8 v79, v83, 0, 0x6400                               // 000000463870: D622004F 03FD0153 00006400
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000046387C: BF870091
	v_lshl_or_b32 v76, v79, 16, v76                            // 000000463880: D656004C 0531214F
	v_pk_fma_f16 v76, v76, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000463888: CC0E004C 0BFC0B4C 0000C931
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000463894: BF870241
	v_dual_dot2acc_f32_f16 v49, v76, v11 :: v_dual_and_b32 v78, 0xffff, v78// 000000463898: CB24174C 314E9CFF 0000FFFF
	v_dot2acc_f32_f16 v46, v84, v14                            // 0000004638A4: 045C1D54
	.long 0xd72c0054                                           // 0000004638A8: D72C0054
	v_cndmask_b32_e32 v1, 0x83dcd12d, v85, vcc_lo              // 0000004638AC: 0202AAFF 83DCD12D
	v_dot2acc_f32_f16 v47, v76, v7                             // 0000004638B4: 045E0F4C
	.long 0xd72c004e                                           // 0000004638B8: D72C004E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 0000004638BC: 02029CFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004638C4: BF870214
	v_dot2acc_f32_f16 v46, v82, v15                            // 0000004638C8: 045C1F52
	v_sad_u8 v73, v84, 0, 0x6400                               // 0000004638CC: D6220049 03FD0154 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004638D8: BF870212
	v_dot2acc_f32_f16 v46, v71, v16                            // 0000004638DC: 045C2147
	v_sad_u8 v78, v78, 0, 0x6400                               // 0000004638E0: D622004E 03FD014E 00006400
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004638EC: BF870091
	v_lshlrev_b32_e32 v78, 16, v78                             // 0000004638F0: 309C9C90
	v_and_or_b32 v73, 0xffff, v73, v78                         // 0000004638F4: D6570049 053A92FF 0000FFFF
	v_mov_b32_e32 v78, v80                                     // 000000463900: 7E9C0350
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000463904: BF870122
	v_pk_fma_f16 v79, v73, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000463908: CC0E004F 0BFC0B49 0000C931
	v_mov_b32_e32 v73, v75                                     // 000000463914: 7E92034B
	v_dot2acc_f32_f16 v47, v79, v8                             // 000000463918: 045E114F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000046391C: BF8701B2
	.long 0xd73d0047                                           // 000000463920: D73D0047
	v_cndmask_b32_e32 v1, v61, v72, vcc_lo                     // 000000463924: 0202913D
	.long 0xd73d0048                                           // 000000463928: D73D0048
	v_cndmask_b32_e32 v1, v62, v77, vcc_lo                     // 00000046392C: 02029B3E
	v_dot2acc_f32_f16 v49, v79, v12                            // 000000463930: 0462194F
	v_bfe_u32 v74, v71, 9, 16                                  // 000000463934: D610004A 02411347
	v_and_b32_e32 v75, 0xffff, v71                             // 00000046393C: 36968EFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4)                            // 000000463944: BF870004
	v_bfe_u32 v77, v72, 9, 16                                  // 000000463948: D610004D 02411348
	v_bfe_u32 v78, v72, 6, 16                                  // 000000463950: D610004E 02410D48
	v_bfe_u32 v80, v72, 3, 16                                  // 000000463958: D6100050 02410748
	.long 0xd72c0049                                           // 000000463960: D72C0049
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 000000463964: 020294FF 83DCD12D
	v_bfe_u32 v74, v71, 6, 16                                  // 00000046396C: D610004A 02410D47
	v_bfe_u32 v71, v71, 3, 16                                  // 000000463974: D6100047 02410747
	.long 0xd72c004b                                           // 00000046397C: D72C004B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v75, vcc_lo              // 000000463980: 020296FF 83DCD12D
	.long 0xd72c004d                                           // 000000463988: D72C004D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v77, vcc_lo              // 00000046398C: 02029AFF 83DCD12D
	v_and_b32_e32 v72, 0xffff, v72                             // 000000463994: 369090FF 0000FFFF
	.long 0xd72c004a                                           // 00000046399C: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 0000004639A0: 020294FF 83DCD12D
	.long 0xd72c0047                                           // 0000004639A8: D72C0047
	v_cndmask_b32_e32 v1, 0x83dcd12d, v71, vcc_lo              // 0000004639AC: 02028EFF 83DCD12D
	v_sad_u8 v73, v73, 0, 0x6400                               // 0000004639B4: D6220049 03FD0149 00006400
	.long 0xd72c004e                                           // 0000004639C0: D72C004E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 0000004639C4: 02029CFF 83DCD12D
	.long 0xd72c0048                                           // 0000004639CC: D72C0048
	v_cndmask_b32_e32 v1, 0x83dcd12d, v72, vcc_lo              // 0000004639D0: 020290FF 83DCD12D
	v_sad_u8 v75, v75, 0, 0x6400                               // 0000004639D8: D622004B 03FD014B 00006400
	v_sad_u8 v77, v77, 0, 0x6400                               // 0000004639E4: D622004D 03FD014D 00006400
	v_and_b32_e32 v73, 0xffff, v73                             // 0000004639F0: 369292FF 0000FFFF
	v_sad_u8 v74, v74, 0, 0x6400                               // 0000004639F8: D622004A 03FD014A 00006400
	v_sad_u8 v71, v71, 0, 0x6400                               // 000000463A04: D6220047 03FD0147 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000463A10: BF870224
	v_and_b32_e32 v77, 0xffff, v77                             // 000000463A14: 369A9AFF 0000FFFF
	v_sad_u8 v78, v78, 0, 0x6400                               // 000000463A1C: D622004E 03FD014E 00006400
	v_lshl_or_b32 v73, v74, 16, v73                            // 000000463A28: D6560049 0525214A
	v_lshlrev_b32_e32 v74, 16, v75                             // 000000463A30: 30949690
	.long 0xd72c004b                                           // 000000463A34: D72C004B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v80, vcc_lo              // 000000463A38: 0202A0FF 83DCD12D
	v_sad_u8 v72, v72, 0, 0x6400                               // 000000463A40: D6220048 03FD0148 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000463A4C: BF870214
	v_pk_fma_f16 v73, v73, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000463A50: CC0E0049 0BFC0B49 0000C931
	v_and_or_b32 v71, 0xffff, v71, v74                         // 000000463A5C: D6570047 052A8EFF 0000FFFF
	v_lshl_or_b32 v74, v78, 16, v77                            // 000000463A68: D656004A 0535214E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000463A70: BF870193
	v_dual_dot2acc_f32_f16 v53, v73, v9 :: v_dual_lshlrev_b32 v72, 16, v72// 000000463A74: CB221349 35489090
	v_pk_fma_f16 v71, v71, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000463A7C: CC0E0047 0BFC0B47 0000C931
	v_sad_u8 v75, v75, 0, 0x6400                               // 000000463A88: D622004B 03FD014B 00006400
	v_dot2acc_f32_f16 v51, v73, v5                             // 000000463A94: 04660B49
	v_pk_fma_f16 v74, v74, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000463A98: CC0E004A 0BFC0B4A 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000463AA4: BF870244
	v_dual_dot2acc_f32_f16 v52, v73, v1 :: v_dual_dot2acc_f32_f16 v53, v71, v10// 000000463AA8: CB180349 34341547
	v_dot2acc_f32_f16 v48, v81, v2                             // 000000463AB0: 04600551
	v_and_or_b32 v5, 0xffff, v75, v72                          // 000000463AB4: D6570005 052296FF 0000FFFF
	v_dot2acc_f32_f16 v51, v71, v6                             // 000000463AC0: 04660D47
	v_dual_dot2acc_f32_f16 v23, v73, v13 :: v_dual_dot2acc_f32_f16 v52, v71, v2// 000000463AC4: CB181B49 17340547
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000463ACC: BF870214
	v_dot2acc_f32_f16 v48, v76, v3                             // 000000463AD0: 0460074C
	v_pk_fma_f16 v1, v5, s5, 0xc931 op_sel_hi:[1,0,0]          // 000000463AD4: CC0E0001 0BFC0B05 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000463AE0: BF870214
	v_dot2acc_f32_f16 v51, v74, v7                             // 000000463AE4: 04660F4A
	v_dual_dot2acc_f32_f16 v23, v71, v14 :: v_dual_add_nc_u32 v2, v64, v65// 000000463AE8: CB201D47 17028340
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000463AF0: BF870194
	v_dual_dot2acc_f32_f16 v48, v79, v4 :: v_dual_dot2acc_f32_f16 v53, v74, v11// 000000463AF4: CB18094F 3034174A
	v_dot2acc_f32_f16 v51, v1, v8                              // 000000463AFC: 04661101
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000463B00: BF8701B3
	v_dual_dot2acc_f32_f16 v50, v81, v14 :: v_dual_dot2acc_f32_f16 v23, v74, v15// 000000463B04: CB181D51 32161F4A
	v_dot2acc_f32_f16 v52, v74, v3                             // 000000463B0C: 0468074A
	v_cmp_eq_u32_e32 vcc_lo, 1, v2                             // 000000463B10: 7C940481
	v_dual_dot2acc_f32_f16 v53, v1, v12 :: v_dual_dot2acc_f32_f16 v50, v76, v15// 000000463B14: CB181901 35321F4C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000463B1C: BF870214
	v_dot2acc_f32_f16 v23, v1, v16                             // 000000463B20: 042E2101
	v_dot2acc_f32_f16 v52, v1, v4                              // 000000463B24: 04680901
	s_or_b32 s4, vcc_lo, s4                                    // 000000463B28: 8C04046A
	s_delay_alu instid0(VALU_DEP_3)                            // 000000463B2C: BF870003
	v_dot2acc_f32_f16 v50, v79, v16                            // 000000463B30: 0464214F
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000463B34: 917E047E
	s_cbranch_execz 27                                         // 000000463B38: BFA5001B <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb0ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1ca8>
	s_mov_b32 s0, exec_lo                                      // 000000463B3C: BE80007E
	s_waitcnt vmcnt(4)                                         // 000000463B40: BF8913F7
	ds_store_2addr_b32 v66, v55, v56 offset1:32                // 000000463B44: D8382000 00383742
	s_waitcnt vmcnt(2)                                         // 000000463B4C: BF890BF7
	ds_store_2addr_b32 v66, v57, v58 offset0:64 offset1:96     // 000000463B50: D8386040 003A3942
	s_waitcnt vmcnt(0)                                         // 000000463B58: BF8903F7
	ds_store_2addr_b32 v66, v59, v60 offset0:128 offset1:160   // 000000463B5C: D838A080 003C3B42
	.long 0xd4c1007e                                           // 000000463B64: D4C1007E
	v_cndmask_b32_e32 v1, v65, v54, vcc_lo                     // 000000463B68: 02026D41
	s_cbranch_execz 64473                                      // 000000463B6C: BFA5FBD9 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb0ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0xbd4>
	s_clause 0x5                                               // 000000463B70: BF850005
	global_load_b32 v55, v[17:18], off                         // 000000463B74: DC520000 377C0011
	global_load_b32 v56, v[17:18], off offset:128              // 000000463B7C: DC520080 387C0011
	global_load_b32 v57, v[17:18], off offset:256              // 000000463B84: DC520100 397C0011
	global_load_b32 v58, v[17:18], off offset:384              // 000000463B8C: DC520180 3A7C0011
	global_load_b32 v59, v[17:18], off offset:512              // 000000463B94: DC520200 3B7C0011
	global_load_b32 v60, v[17:18], off offset:640              // 000000463B9C: DC520280 3C7C0011
	s_branch 64459                                             // 000000463BA4: BFA0FBCB <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb0ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0xbd4>
	s_or_b32 exec_lo, exec_lo, s4                              // 000000463BA8: 8C7E047E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000463BAC: BF870009
	s_or_b32 exec_lo, exec_lo, s1                              // 000000463BB0: 8C7E017E
	v_dual_mov_b32 v1, v22 :: v_dual_mov_b32 v4, v27           // 000000463BB4: CA100116 0104011B
	v_dual_mov_b32 v2, v26 :: v_dual_mov_b32 v3, v25           // 000000463BBC: CA10011A 02020119
	v_dual_mov_b32 v5, v28 :: v_dual_mov_b32 v8, v30           // 000000463BC4: CA10011C 0508011E
	v_dual_mov_b32 v7, v29 :: v_dual_mov_b32 v6, v24           // 000000463BCC: CA10011D 07060118
	v_dual_mov_b32 v9, v31 :: v_dual_mov_b32 v10, v32          // 000000463BD4: CA10011F 090A0120
	v_dual_mov_b32 v11, v33 :: v_dual_mov_b32 v12, v34         // 000000463BDC: CA100121 0B0C0122
	v_dual_mov_b32 v13, v35 :: v_dual_mov_b32 v14, v36         // 000000463BE4: CA100123 0D0E0124
	v_dual_mov_b32 v15, v37 :: v_dual_mov_b32 v16, v38         // 000000463BEC: CA100125 0F100126
	v_dual_mov_b32 v17, v39 :: v_dual_mov_b32 v18, v40         // 000000463BF4: CA100127 11120128
	s_waitcnt vmcnt(5)                                         // 000000463BFC: BF8917F7
	v_dual_mov_b32 v54, v41 :: v_dual_mov_b32 v55, v42         // 000000463C00: CA100129 3636012A
	s_waitcnt vmcnt(3)                                         // 000000463C08: BF890FF7
	v_dual_mov_b32 v56, v43 :: v_dual_mov_b32 v57, v44         // 000000463C0C: CA10012B 3838012C
	s_waitcnt vmcnt(1)                                         // 000000463C14: BF8907F7
	v_dual_mov_b32 v58, v45 :: v_dual_mov_b32 v59, v46         // 000000463C18: CA10012D 3A3A012E
	s_waitcnt vmcnt(0)                                         // 000000463C20: BF8903F7
	v_dual_mov_b32 v60, v47 :: v_dual_mov_b32 v61, v48         // 000000463C24: CA10012F 3C3C0130
	v_dual_mov_b32 v62, v49 :: v_dual_mov_b32 v63, v50         // 000000463C2C: CA100131 3E3E0132
	v_dual_mov_b32 v64, v51 :: v_dual_mov_b32 v65, v52         // 000000463C34: CA100133 40400134
	v_dual_mov_b32 v66, v53 :: v_dual_mov_b32 v67, v23         // 000000463C3C: CA100135 42420117
	s_mov_b32 s0, 0x76543210                                   // 000000463C44: BE8000FF 76543210
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000463C4C: BF870009
	v_permlanex16_b32 v1, v1, s0, 0xfedcba98                   // 000000463C50: D65C0001 03FC0101 FEDCBA98
	v_permlanex16_b32 v2, v2, s0, 0xfedcba98                   // 000000463C5C: D65C0002 03FC0102 FEDCBA98
	v_permlanex16_b32 v4, v4, s0, 0xfedcba98                   // 000000463C68: D65C0004 03FC0104 FEDCBA98
	v_permlanex16_b32 v3, v3, s0, 0xfedcba98                   // 000000463C74: D65C0003 03FC0103 FEDCBA98
	v_permlanex16_b32 v5, v5, s0, 0xfedcba98                   // 000000463C80: D65C0005 03FC0105 FEDCBA98
	v_permlanex16_b32 v7, v7, s0, 0xfedcba98                   // 000000463C8C: D65C0007 03FC0107 FEDCBA98
	v_permlanex16_b32 v8, v8, s0, 0xfedcba98                   // 000000463C98: D65C0008 03FC0108 FEDCBA98
	v_permlanex16_b32 v9, v9, s0, 0xfedcba98                   // 000000463CA4: D65C0009 03FC0109 FEDCBA98
	v_permlanex16_b32 v6, v6, s0, 0xfedcba98                   // 000000463CB0: D65C0006 03FC0106 FEDCBA98
	v_permlanex16_b32 v10, v10, s0, 0xfedcba98                 // 000000463CBC: D65C000A 03FC010A FEDCBA98
	v_permlanex16_b32 v11, v11, s0, 0xfedcba98                 // 000000463CC8: D65C000B 03FC010B FEDCBA98
	v_permlanex16_b32 v12, v12, s0, 0xfedcba98                 // 000000463CD4: D65C000C 03FC010C FEDCBA98
	v_permlanex16_b32 v13, v13, s0, 0xfedcba98                 // 000000463CE0: D65C000D 03FC010D FEDCBA98
	v_permlanex16_b32 v14, v14, s0, 0xfedcba98                 // 000000463CEC: D65C000E 03FC010E FEDCBA98
	v_permlanex16_b32 v15, v15, s0, 0xfedcba98                 // 000000463CF8: D65C000F 03FC010F FEDCBA98
	v_permlanex16_b32 v16, v16, s0, 0xfedcba98                 // 000000463D04: D65C0010 03FC0110 FEDCBA98
	v_permlanex16_b32 v17, v17, s0, 0xfedcba98                 // 000000463D10: D65C0011 03FC0111 FEDCBA98
	v_permlanex16_b32 v18, v18, s0, 0xfedcba98                 // 000000463D1C: D65C0012 03FC0112 FEDCBA98
	v_permlanex16_b32 v54, v54, s0, 0xfedcba98                 // 000000463D28: D65C0036 03FC0136 FEDCBA98
	v_permlanex16_b32 v55, v55, s0, 0xfedcba98                 // 000000463D34: D65C0037 03FC0137 FEDCBA98
	v_permlanex16_b32 v56, v56, s0, 0xfedcba98                 // 000000463D40: D65C0038 03FC0138 FEDCBA98
	v_permlanex16_b32 v57, v57, s0, 0xfedcba98                 // 000000463D4C: D65C0039 03FC0139 FEDCBA98
	v_permlanex16_b32 v58, v58, s0, 0xfedcba98                 // 000000463D58: D65C003A 03FC013A FEDCBA98
	v_permlanex16_b32 v59, v59, s0, 0xfedcba98                 // 000000463D64: D65C003B 03FC013B FEDCBA98
	v_permlanex16_b32 v60, v60, s0, 0xfedcba98                 // 000000463D70: D65C003C 03FC013C FEDCBA98
	v_permlanex16_b32 v61, v61, s0, 0xfedcba98                 // 000000463D7C: D65C003D 03FC013D FEDCBA98
	v_permlanex16_b32 v62, v62, s0, 0xfedcba98                 // 000000463D88: D65C003E 03FC013E FEDCBA98
	v_permlanex16_b32 v63, v63, s0, 0xfedcba98                 // 000000463D94: D65C003F 03FC013F FEDCBA98
	v_permlanex16_b32 v64, v64, s0, 0xfedcba98                 // 000000463DA0: D65C0040 03FC0140 FEDCBA98
	v_permlanex16_b32 v65, v65, s0, 0xfedcba98                 // 000000463DAC: D65C0041 03FC0141 FEDCBA98
	v_permlanex16_b32 v66, v66, s0, 0xfedcba98                 // 000000463DB8: D65C0042 03FC0142 FEDCBA98
	v_permlanex16_b32 v67, v67, s0, 0xfedcba98                 // 000000463DC4: D65C0043 03FC0143 FEDCBA98
	.long 0xd44c0000                                           // 000000463DD0: D44C0000
	v_cndmask_b32_e32 v1, 16, v21, vcc_lo                      // 000000463DD4: 02022A90
	s_barrier                                                  // 000000463DD8: BFBD0000
	buffer_gl0_inv                                             // 000000463DDC: E0AC0000 00000000
	s_and_saveexec_b32 s1, s0                                  // 000000463DE4: BE812000
	s_cbranch_execz 68                                         // 000000463DE8: BFA50044 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb0ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1ffc>
	v_lshl_or_b32 v20, v19, 11, v20                            // 000000463DEC: D6560014 04511713
	v_add_f32_e32 v5, v28, v5                                  // 000000463DF4: 060A0B1C
	v_dual_add_f32 v1, v22, v1 :: v_dual_add_f32 v6, v24, v6   // 000000463DF8: C9080316 01060D18
	v_dual_add_f32 v9, v31, v9 :: v_dual_add_f32 v2, v26, v2   // 000000463E00: C908131F 0902051A
	v_dual_add_f32 v7, v29, v7 :: v_dual_add_f32 v4, v27, v4   // 000000463E08: C9080F1D 0704091B
	v_dual_add_f32 v11, v33, v11 :: v_dual_add_f32 v8, v30, v8 // 000000463E10: C9081721 0B08111E
	v_dual_add_f32 v3, v25, v3 :: v_dual_add_nc_u32 v22, 0x400, v20// 000000463E18: C9200719 031628FF 00000400
	v_dual_add_f32 v13, v35, v13 :: v_dual_add_f32 v10, v32, v10// 000000463E24: C9081B23 0D0A1520
	v_dual_add_f32 v21, v23, v67 :: v_dual_add_f32 v52, v52, v65// 000000463E2C: C9088717 15348334
	v_dual_add_f32 v23, v53, v66 :: v_dual_add_f32 v50, v50, v63// 000000463E34: C9088535 17327F32
	v_dual_add_f32 v51, v51, v64 :: v_dual_add_f32 v48, v48, v61// 000000463E3C: C9088133 33307B30
	v_dual_add_f32 v49, v49, v62 :: v_dual_add_f32 v46, v46, v59// 000000463E44: C9087D31 312E772E
	v_dual_add_f32 v47, v47, v60 :: v_dual_add_f32 v44, v44, v57// 000000463E4C: C908792F 2F2C732C
	v_dual_add_f32 v45, v45, v58 :: v_dual_add_f32 v42, v42, v55// 000000463E54: C908752D 2D2A6F2A
	v_dual_add_f32 v43, v43, v56 :: v_dual_add_f32 v18, v40, v18// 000000463E5C: C908712B 2B122528
	v_dual_add_f32 v41, v41, v54 :: v_dual_add_f32 v16, v38, v16// 000000463E64: C9086D29 29102126
	v_dual_add_f32 v17, v39, v17 :: v_dual_add_f32 v14, v36, v14// 000000463E6C: C9082327 110E1D24
	v_dual_add_f32 v15, v37, v15 :: v_dual_add_f32 v12, v34, v12// 000000463E74: C9081F25 0F0C1922
	ds_store_2addr_b32 v20, v1, v5 offset1:16                  // 000000463E7C: D8381000 00050114
	ds_store_2addr_b32 v20, v2, v7 offset0:128 offset1:144     // 000000463E84: D8389080 00070214
	ds_store_2addr_b32 v22, v4, v8 offset1:16                  // 000000463E8C: D8381000 00080416
	ds_store_2addr_b32 v22, v3, v9 offset0:128 offset1:144     // 000000463E94: D8389080 00090316
	ds_store_2addr_b32 v20, v6, v13 offset0:32 offset1:48      // 000000463E9C: D8383020 000D0614
	ds_store_2addr_b32 v20, v10, v14 offset0:160 offset1:176   // 000000463EA4: D838B0A0 000E0A14
	ds_store_2addr_b32 v22, v11, v15 offset0:32 offset1:48     // 000000463EAC: D8383020 000F0B16
	ds_store_2addr_b32 v22, v12, v16 offset0:160 offset1:176   // 000000463EB4: D838B0A0 00100C16
	ds_store_2addr_b32 v20, v17, v43 offset0:64 offset1:80     // 000000463EBC: D8385040 002B1114
	ds_store_2addr_b32 v20, v18, v44 offset0:192 offset1:208   // 000000463EC4: D838D0C0 002C1214
	ds_store_2addr_b32 v22, v41, v45 offset0:64 offset1:80     // 000000463ECC: D8385040 002D2916
	ds_store_2addr_b32 v22, v42, v46 offset0:192 offset1:208   // 000000463ED4: D838D0C0 002E2A16
	ds_store_2addr_b32 v20, v47, v51 offset0:96 offset1:112    // 000000463EDC: D8387060 00332F14
	ds_store_2addr_b32 v20, v48, v52 offset0:224 offset1:240   // 000000463EE4: D838F0E0 00343014
	ds_store_2addr_b32 v22, v49, v23 offset0:96 offset1:112    // 000000463EEC: D8387060 00173116
	ds_store_2addr_b32 v22, v50, v21 offset0:224 offset1:240   // 000000463EF4: D838F0E0 00153216
	s_or_b32 exec_lo, exec_lo, s1                              // 000000463EFC: 8C7E017E
	.long 0xd44c0001                                           // 000000463F00: D44C0001
	v_cndmask_b32_e32 v1, 0x200, v0, vcc_lo                    // 000000463F04: 020200FF 00000200
	s_waitcnt lgkmcnt(0)                                       // 000000463F0C: BF89FC07
	s_barrier                                                  // 000000463F10: BFBD0000
	buffer_gl0_inv                                             // 000000463F14: E0AC0000 00000000
	s_and_saveexec_b32 s4, s1                                  // 000000463F1C: BE842001
	s_cbranch_execz 42                                         // 000000463F20: BFA5002A <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb0ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x20cc>
	v_mov_b32_e32 v1, v0                                       // 000000463F24: 7E020300
	s_mov_b32 s5, 0                                            // 000000463F28: BE850080
	s_nop 0                                                    // 000000463F2C: BF800000
	s_nop 0                                                    // 000000463F30: BF800000
	s_nop 0                                                    // 000000463F34: BF800000
	s_nop 0                                                    // 000000463F38: BF800000
	s_nop 0                                                    // 000000463F3C: BF800000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000463F40: BF870001
	v_lshlrev_b32_e32 v8, 2, v1                                // 000000463F44: 30100282
	v_cmp_lt_u32_e32 vcc_lo, 0xff, v1                          // 000000463F48: 7C9202FF 000000FF
	ds_load_2addr_stride64_b32 v[2:3], v8 offset1:8            // 000000463F50: D8E00800 02000008
	ds_load_2addr_stride64_b32 v[4:5], v8 offset0:16 offset1:24// 000000463F58: D8E01810 04000008
	ds_load_2addr_stride64_b32 v[6:7], v8 offset0:32 offset1:40// 000000463F60: D8E02820 06000008
	s_or_b32 s5, vcc_lo, s5                                    // 000000463F68: 8C05056A
	s_waitcnt lgkmcnt(2)                                       // 000000463F6C: BF89FC27
	v_add_f32_e32 v2, 0, v2                                    // 000000463F70: 06040480
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000463F74: BF8700C1
	v_add_f32_e32 v9, v2, v3                                   // 000000463F78: 06120702
	ds_load_2addr_stride64_b32 v[2:3], v8 offset0:48 offset1:56// 000000463F7C: D8E03830 02000008
	s_waitcnt lgkmcnt(2)                                       // 000000463F84: BF89FC27
	v_add_f32_e32 v4, v9, v4                                   // 000000463F88: 06080909
	v_add_f32_e32 v4, v4, v5                                   // 000000463F8C: 06080B04
	s_waitcnt lgkmcnt(1)                                       // 000000463F90: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000463F94: BF870091
	v_add_f32_e32 v4, v4, v6                                   // 000000463F98: 06080D04
	v_add_f32_e32 v4, v4, v7                                   // 000000463F9C: 06080F04
	s_waitcnt lgkmcnt(0)                                       // 000000463FA0: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000463FA4: BF8700A1
	v_add_f32_e32 v2, v4, v2                                   // 000000463FA8: 06040504
	v_add_nc_u32_e32 v4, 0x100, v1                             // 000000463FAC: 4A0802FF 00000100
	v_dual_add_f32 v2, v2, v3 :: v_dual_mov_b32 v1, v4         // 000000463FB4: C9100702 02000104
	ds_store_b32 v8, v2 offset:16384                           // 000000463FBC: D8344000 00000208
	s_and_not1_b32 exec_lo, exec_lo, s5                        // 000000463FC4: 917E057E
	s_cbranch_execnz 65501                                     // 000000463FC8: BFA6FFDD <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb0ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2040>
	s_or_b32 exec_lo, exec_lo, s4                              // 000000463FCC: 8C7E047E
	s_cmp_lt_i32 s33, 2                                        // 000000463FD0: BF048221
	s_mov_b32 s4, -1                                           // 000000463FD4: BE8400C1
	s_cbranch_scc1 212                                         // 000000463FD8: BFA200D4 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb0ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x242c>
	s_waitcnt lgkmcnt(0)                                       // 000000463FDC: BF89FC07
	s_barrier                                                  // 000000463FE0: BFBD0000
	buffer_gl0_inv                                             // 000000463FE4: E0AC0000 00000000
	s_and_saveexec_b32 s6, s1                                  // 000000463FEC: BE862001
	s_cbranch_execz 71                                         // 000000463FF0: BFA50047 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb0ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2210>
	v_lshrrev_b32_e32 v1, 7, v0                                // 000000463FF4: 32020087
	s_ashr_i32 s11, s10, 31                                    // 000000463FF8: 860B9F0A
	s_ashr_i32 s27, s26, 31                                    // 000000463FFC: 861B9F1A
	s_lshl_b64 s[4:5], s[10:11], 2                             // 000000464000: 8484820A
	s_mov_b32 s7, 0                                            // 000000464004: BE870080
	v_or_b32_e32 v1, s4, v1                                    // 000000464008: 38020204
	s_mul_i32 s4, s5, s26                                      // 00000046400C: 96041A05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000464010: BF8700A1
	.long 0xd72c0003                                           // 000000464014: D72C0003
	v_cndmask_b32_e32 v0, v1, v27, vcc_lo                      // 000000464018: 02003701
	v_mad_u64_u32 v[1:2], null, v1, s26, 0                     // 00000046401C: D6FE7C01 02003501
	v_add3_u32 v2, v2, v3, s4                                  // 000000464024: D6550002 00120702
	s_lshl_b32 s4, s2, 7                                       // 00000046402C: 84048702
	v_and_b32_e32 v3, 0x7f, v0                                 // 000000464030: 360600FF 0000007F
	s_ashr_i32 s5, s4, 31                                      // 000000464038: 86059F04
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000046403C: BF870122
	.long 0xd73c0001                                           // 000000464040: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 000000464044: 02020282
	s_lshl_b64 s[4:5], s[4:5], 2                               // 000000464048: 84848204
	v_lshlrev_b32_e32 v4, 2, v3                                // 00000046404C: 30080682
	v_lshlrev_b32_e32 v3, 2, v0                                // 000000464050: 30060082
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000464054: BF870093
	.long 0xd7006a01                                           // 000000464058: D7006A01
	v_cndmask_b32_e32 v0, v1, v4, vcc_lo                       // 00000046405C: 02000901
	v_add_co_ci_u32_e64 v2, null, s5, v2, vcc_lo               // 000000464060: D5207C02 01AA0405
	s_lshl_b64 s[4:5], s[26:27], 3                             // 000000464068: 8484831A
	.long 0xd7006a01                                           // 00000046406C: D7006A01
	v_cndmask_b32_e32 v1, v1, v4, vcc_lo                       // 000000464070: 02020901
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000464074: BF8701A1
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 000000464078: D5207C02 01AA0480
	v_or_b32_e32 v4, 0xffffff00, v0                            // 000000464080: 380800FF FFFFFF00
	.long 0xd7006a01                                           // 000000464088: D7006A01
	v_cndmask_b32_e32 v1, s16, v1, vcc_lo                      // 00000046408C: 02020210
	s_delay_alu instid0(VALU_DEP_1)                            // 000000464090: BF870001
	v_add_co_ci_u32_e64 v2, null, s17, v2, vcc_lo              // 000000464094: D5207C02 01AA0411
	s_nop 0                                                    // 00000046409C: BF800000
	s_nop 0                                                    // 0000004640A0: BF800000
	s_nop 0                                                    // 0000004640A4: BF800000
	s_nop 0                                                    // 0000004640A8: BF800000
	s_nop 0                                                    // 0000004640AC: BF800000
	s_nop 0                                                    // 0000004640B0: BF800000
	s_nop 0                                                    // 0000004640B4: BF800000
	s_nop 0                                                    // 0000004640B8: BF800000
	s_nop 0                                                    // 0000004640BC: BF800000
	ds_load_b32 v5, v3 offset:16384                            // 0000004640C0: D8D84000 05000003
	.long 0xd7000804                                           // 0000004640C8: D7000804
	v_cndmask_b32_e32 v1, 0x100, v4, vcc_lo                    // 0000004640CC: 020208FF 00000100
	s_xor_b32 s8, s8, -1                                       // 0000004640D4: 8D08C108
	v_add_nc_u32_e32 v3, 0x400, v3                             // 0000004640D8: 4A0606FF 00000400
	s_and_b32 s8, exec_lo, s8                                  // 0000004640E0: 8B08087E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000004640E4: BF8700C9
	s_or_b32 s7, s8, s7                                        // 0000004640E8: 8C070708
	s_waitcnt lgkmcnt(0)                                       // 0000004640EC: BF89FC07
	global_store_b32 v[1:2], v5, off                           // 0000004640F0: DC6A0000 007C0501
	.long 0xd7006a01                                           // 0000004640F8: D7006A01
	v_cndmask_b32_e32 v0, v1, v4, vcc_lo                       // 0000004640FC: 02000901
	v_add_co_ci_u32_e64 v2, null, s5, v2, vcc_lo               // 000000464100: D5207C02 01AA0405
	s_and_not1_b32 exec_lo, exec_lo, s7                        // 000000464108: 917E077E
	s_cbranch_execnz 65516                                     // 00000046410C: BFA6FFEC <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb0ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x21c0>
	s_or_b32 exec_lo, exec_lo, s6                              // 000000464110: 8C7E067E
	.long 0xd44a0004                                           // 000000464114: D44A0004
	v_cndmask_b32_e32 v1, 0, v0, vcc_lo                        // 000000464118: 02020080
	s_waitcnt_vscnt null, 0x0                                  // 00000046411C: BC7C0000
	buffer_gl1_inv                                             // 000000464120: E0B00000 00000000
	buffer_gl0_inv                                             // 000000464128: E0AC0000 00000000
	s_barrier                                                  // 000000464130: BFBD0000
	buffer_gl0_inv                                             // 000000464134: E0AC0000 00000000
	s_and_saveexec_b32 s5, s4                                  // 00000046413C: BE852004
	s_cbranch_execz 29                                         // 000000464140: BFA5001D <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb0ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x22b8>
	s_mov_b32 s7, exec_lo                                      // 000000464144: BE87007E
	s_mov_b32 s6, exec_lo                                      // 000000464148: BE86007E
	.long 0xd71f0001                                           // 00000046414C: D71F0001
	v_cndmask_b32_e32 v0, s7, v128, vcc_lo                     // 000000464150: 02010007
	s_delay_alu instid0(VALU_DEP_1)                            // 000000464154: BF870001
	v_cmpx_eq_u32_e32 0, v1                                    // 000000464158: 7D940280
	s_cbranch_execz 9                                          // 00000046415C: BFA50009 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb0ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2284>
	s_lshl_b64 s[8:9], s[2:3], 2                               // 000000464160: 84888202
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 000000464164: BF8704B9
	s_add_u32 s8, s18, s8                                      // 000000464168: 80080812
	s_addc_u32 s9, s19, s9                                     // 00000046416C: 82090913
	s_bcnt1_i32_b32 s7, s7                                     // 000000464170: BE871807
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v3, s7              // 000000464174: CA100080 02020007
	global_atomic_add_u32 v2, v2, v3, s[8:9] glc               // 00000046417C: DCD64000 02080302
	s_or_b32 exec_lo, exec_lo, s6                              // 000000464184: 8C7E067E
	s_waitcnt vmcnt(0)                                         // 000000464188: BF8903F7
	v_readfirstlane_b32 s6, v2                                 // 00000046418C: 7E0C0502
	s_delay_alu instid0(VALU_DEP_1)                            // 000000464190: BF870001
	v_dual_mov_b32 v2, 0 :: v_dual_add_nc_u32 v1, s6, v1       // 000000464194: CA200080 02000206
	s_add_i32 s6, s33, -1                                      // 00000046419C: 8106C121
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 0000004641A0: BF870481
	v_cmp_eq_u32_e32 vcc_lo, s6, v1                            // 0000004641A4: 7C940206
	v_cndmask_b32_e64 v1, 0, 1, vcc_lo                         // 0000004641A8: D5010001 01A90280
	ds_store_b32 v2, v1 offset:26880                           // 0000004641B0: D8346900 00000102
	s_or_b32 exec_lo, exec_lo, s5                              // 0000004641B8: 8C7E057E
	v_mov_b32_e32 v1, 0                                        // 0000004641BC: 7E020280
	s_waitcnt lgkmcnt(0)                                       // 0000004641C0: BF89FC07
	s_barrier                                                  // 0000004641C4: BFBD0000
	buffer_gl0_inv                                             // 0000004641C8: E0AC0000 00000000
	ds_load_b32 v1, v1 offset:26880                            // 0000004641D0: D8D86900 01000001
	s_waitcnt lgkmcnt(0)                                       // 0000004641D8: BF89FC07
	v_cmp_eq_u32_e32 vcc_lo, 0, v1                             // 0000004641DC: 7C940280
	s_cbranch_vccnz 465                                        // 0000004641E0: BFA401D1 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb0ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2a28>
	buffer_gl1_inv                                             // 0000004641E4: E0B00000 00000000
	buffer_gl0_inv                                             // 0000004641EC: E0AC0000 00000000
	s_and_saveexec_b32 s5, s1                                  // 0000004641F4: BE852001
	s_cbranch_execz 65                                         // 0000004641F8: BFA50041 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb0ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2400>
	v_lshrrev_b32_e32 v1, 7, v0                                // 0000004641FC: 32020087
	s_lshl_b32 s6, s2, 7                                       // 000000464200: 84068702
	v_and_b32_e32 v3, 0x7f, v0                                 // 000000464204: 360600FF 0000007F
	s_ashr_i32 s7, s6, 31                                      // 00000046420C: 86079F06
	v_mov_b32_e32 v5, v0                                       // 000000464210: 7E0A0300
	v_mad_i64_i32 v[1:2], null, v1, s26, 0                     // 000000464214: D6FF7C01 02003501
	s_lshl_b64 s[6:7], s[6:7], 2                               // 00000046421C: 84868206
	v_lshlrev_b32_e32 v3, 2, v3                                // 000000464220: 30060682
	s_ashr_i32 s27, s26, 31                                    // 000000464224: 861B9F1A
	s_mov_b32 s10, 0                                           // 000000464228: BE8A0080
	s_lshl_b64 s[8:9], s[26:27], 4                             // 00000046422C: 8488841A
	.long 0xd73c0001                                           // 000000464230: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 000000464234: 02020282
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000464238: BF870091
	.long 0xd7006a01                                           // 00000046423C: D7006A01
	v_cndmask_b32_e32 v0, v1, v6, vcc_lo                       // 000000464240: 02000D01
	v_add_co_ci_u32_e64 v2, null, s7, v2, vcc_lo               // 000000464244: D5207C02 01AA0407
	s_lshl_b64 s[6:7], s[26:27], 3                             // 00000046424C: 8486831A
	.long 0xd7006a01                                           // 000000464250: D7006A01
	v_cndmask_b32_e32 v1, v1, v3, vcc_lo                       // 000000464254: 02020701
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000464258: BF870111
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 00000046425C: D5207C02 01AA0480
	.long 0xd7006a01                                           // 000000464264: D7006A01
	v_cndmask_b32_e32 v1, s16, v1, vcc_lo                      // 000000464268: 02020210
	s_delay_alu instid0(VALU_DEP_1)                            // 00000046426C: BF870001
	v_add_co_ci_u32_e64 v2, null, s17, v2, vcc_lo              // 000000464270: D5207C02 01AA0411
	s_nop 0                                                    // 000000464278: BF800000
	s_nop 0                                                    // 00000046427C: BF800000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000464280: BF870001
	v_dual_mov_b32 v4, v2 :: v_dual_mov_b32 v3, v1             // 000000464284: CA100102 04020101
	v_mov_b32_e32 v6, 0                                        // 00000046428C: 7E0C0280
	s_mov_b32 s1, s33                                          // 000000464290: BE810021
	global_load_b32 v7, v[3:4], off glc                        // 000000464294: DC524000 077C0003
	.long 0xd7006a03                                           // 00000046429C: D7006A03
	v_cndmask_b32_e32 v0, v3, v8, vcc_lo                       // 0000004642A0: 02001103
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000004642A4: BF8704A1
	v_add_co_ci_u32_e64 v4, null, s9, v4, vcc_lo               // 0000004642A8: D5207C04 01AA0809
	s_add_i32 s1, s1, -1                                       // 0000004642B0: 8101C101
	s_cmp_eq_u32 s1, 0                                         // 0000004642B4: BF068001
	s_waitcnt vmcnt(0)                                         // 0000004642B8: BF8903F7
	v_add_f32_e32 v6, v6, v7                                   // 0000004642BC: 060C0F06
	s_cbranch_scc0 65524                                       // 0000004642C0: BFA1FFF4 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb0ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2394>
	v_add_nc_u32_e32 v4, 0x100, v5                             // 0000004642C4: 4A080AFF 00000100
	v_cmp_lt_u32_e32 vcc_lo, 0xff, v5                          // 0000004642CC: 7C920AFF 000000FF
	.long 0xd7000101                                           // 0000004642D4: D7000101
	v_cndmask_b32_e32 v0, v1, v6, vcc_lo                       // 0000004642D8: 02000D01
	v_lshlrev_b32_e32 v3, 2, v5                                // 0000004642DC: 30060A82
	v_add_co_ci_u32_e64 v2, null, s7, v2, s1                   // 0000004642E0: D5207C02 00060407
	v_mov_b32_e32 v5, v4                                       // 0000004642E8: 7E0A0304
	s_or_b32 s10, vcc_lo, s10                                  // 0000004642EC: 8C0A0A6A
	ds_store_b32 v3, v6 offset:16384                           // 0000004642F0: D8344000 00000603
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000004642F8: 917E0A7E
	s_cbranch_execnz 65504                                     // 0000004642FC: BFA6FFE0 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb0ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2380>
	s_or_b32 exec_lo, exec_lo, s5                              // 000000464300: 8C7E057E
	s_and_saveexec_b32 s1, s4                                  // 000000464304: BE812004
	s_cbranch_execz 6                                          // 000000464308: BFA50006 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb0ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2424>
	s_lshl_b64 s[4:5], s[2:3], 2                               // 00000046430C: 84848202
	v_mov_b32_e32 v1, 0                                        // 000000464310: 7E020280
	s_add_u32 s4, s18, s4                                      // 000000464314: 80040412
	s_addc_u32 s5, s19, s5                                     // 000000464318: 82050513
	global_store_b32 v1, v1, s[4:5]                            // 00000046431C: DC6A0000 00040101
	s_or_b32 exec_lo, exec_lo, s1                              // 000000464324: 8C7E017E
	s_mov_b32 s4, -1                                           // 000000464328: BE8400C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000046432C: BF870009
	s_and_b32 vcc_lo, exec_lo, s4                              // 000000464330: 8B6A047E
	s_cbranch_vccz 380                                         // 000000464334: BFA3017C <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb0ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2a28>
	v_cmp_gt_i32_e32 vcc_lo, s24, v19                          // 000000464338: 7C882618
	.long 0xd44c0001                                           // 00000046433C: D44C0001
	v_cndmask_b32_e32 v1, 0x80, v0, vcc_lo                     // 000000464340: 020200FF 00000080
	s_waitcnt lgkmcnt(0)                                       // 000000464348: BF89FC07
	s_waitcnt_vscnt null, 0x0                                  // 00000046434C: BC7C0000
	s_barrier                                                  // 000000464350: BFBD0000
	buffer_gl0_inv                                             // 000000464354: E0AC0000 00000000
	s_and_b32 s1, vcc_lo, s1                                   // 00000046435C: 8B01016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000464360: BF870009
	s_and_saveexec_b32 s3, s1                                  // 000000464364: BE832001
	s_cbranch_execz 367                                        // 000000464368: BFA5016F <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb0ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2a28>
	v_and_b32_e32 v1, 15, v0                                   // 00000046436C: 3602008F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000464370: BF870091
	v_lshlrev_b32_e32 v2, 2, v1                                // 000000464374: 30040282
	v_lshl_or_b32 v2, v19, 9, v2                               // 000000464378: D6560002 04091313
	s_delay_alu instid0(VALU_DEP_1)                            // 000000464380: BF870001
	v_add_nc_u32_e32 v8, 0x4000, v2                            // 000000464384: 4A1004FF 00004000
	ds_load_2addr_b32 v[2:3], v8 offset1:16                    // 00000046438C: D8DC1000 02000008
	ds_load_2addr_b32 v[4:5], v8 offset0:32 offset1:48         // 000000464394: D8DC3020 04000008
	ds_load_2addr_b32 v[6:7], v8 offset0:64 offset1:80         // 00000046439C: D8DC5040 06000008
	ds_load_2addr_b32 v[8:9], v8 offset0:96 offset1:112        // 0000004643A4: D8DC7060 08000008
	v_and_b32_e32 v10, 1, v0                                   // 0000004643AC: 36140081
	v_and_b32_e32 v11, 2, v0                                   // 0000004643B0: 36160082
	s_waitcnt lgkmcnt(3)                                       // 0000004643B4: BF89FC37
	v_dual_add_f32 v13, v2, v3 :: v_dual_and_b32 v12, 4, v0    // 0000004643B8: C9240702 0D0C0084
	s_waitcnt lgkmcnt(2)                                       // 0000004643C0: BF89FC27
	v_dual_sub_f32 v2, v2, v3 :: v_dual_add_f32 v3, v4, v5     // 0000004643C4: C9480702 02020B04
	s_waitcnt lgkmcnt(1)                                       // 0000004643CC: BF89FC17
	v_dual_sub_f32 v4, v4, v5 :: v_dual_add_f32 v5, v6, v7     // 0000004643D0: C9480B04 04040F06
	s_waitcnt lgkmcnt(0)                                       // 0000004643D8: BF89FC07
	v_dual_sub_f32 v6, v6, v7 :: v_dual_add_f32 v7, v8, v9     // 0000004643DC: C9480F06 06061308
	v_dual_sub_f32 v8, v8, v9 :: v_dual_add_f32 v9, v13, v3    // 0000004643E4: C9481308 0808070D
	v_sub_f32_e32 v3, v13, v3                                  // 0000004643EC: 0806070D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000004643F0: BF870243
	v_dual_add_f32 v13, v2, v4 :: v_dual_add_f32 v14, v5, v7   // 0000004643F4: C9080902 0D0E0F05
	v_dual_sub_f32 v2, v2, v4 :: v_dual_sub_f32 v5, v5, v7     // 0000004643FC: C94A0902 02040F05
	v_cmp_eq_u32_e32 vcc_lo, 0, v10                            // 000000464404: 7C941480
	.long 0xd44a0001                                           // 000000464408: D44A0001
	v_cndmask_b32_e32 v1, 0, v12, vcc_lo                       // 00000046440C: 02021880
	v_dual_add_f32 v7, v9, v14 :: v_dual_add_f32 v4, v6, v8    // 000000464410: C9081D09 07041106
	v_sub_f32_e32 v6, v6, v8                                   // 000000464418: 080C1106
	v_sub_f32_e32 v8, v9, v14                                  // 00000046441C: 08101D09
	s_delay_alu instid0(VALU_DEP_3)                            // 000000464420: BF870003
	v_add_f32_e32 v9, v13, v4                                  // 000000464424: 0612090D
	v_dual_sub_f32 v4, v13, v4 :: v_dual_add_f32 v13, v3, v5   // 000000464428: C948090D 040C0B03
	v_sub_f32_e32 v3, v3, v5                                   // 000000464430: 08060B03
	v_add_f32_e32 v5, v2, v6                                   // 000000464434: 060A0D02
	v_sub_f32_e32 v2, v2, v6                                   // 000000464438: 08040D02
	v_mov_b32_dpp v6, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000046443C: 7E0C02FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, vcc_lo                      // 000000464444: D5010007 21AA0F07
	v_mov_b32_dpp v10, v9 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000046444C: 7E1402FA FF016109
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 000000464454: D5010009 21AA1309
	v_mov_b32_dpp v14, v13 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000046445C: 7E1C02FA FF01610D
	v_cndmask_b32_e64 v13, -v13, v13, vcc_lo                   // 000000464464: D501000D 21AA1B0D
	v_mov_b32_dpp v15, v5 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000046446C: 7E1E02FA FF016105
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 000000464474: D5010005 21AA0B05
	v_mov_b32_dpp v16, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000046447C: 7E2002FA FF016108
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 000000464484: D5010008 21AA1108
	v_mov_b32_dpp v17, v4 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000046448C: 7E2202FA FF016104
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 000000464494: D5010004 21AA0904
	v_mov_b32_dpp v18, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000046449C: 7E2402FA FF016103
	v_cndmask_b32_e64 v20, -v3, v3, vcc_lo                     // 0000004644A4: D5010014 21AA0703
	v_cndmask_b32_e64 v22, -v2, v2, vcc_lo                     // 0000004644AC: D5010016 21AA0502
	v_cmp_eq_u32_e32 vcc_lo, 0, v11                            // 0000004644B4: 7C941680
	v_dual_add_f32 v3, v7, v6 :: v_dual_add_f32 v8, v8, v16    // 0000004644B8: C9080D07 03082108
	v_mov_b32_dpp v21, v2 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000004644C0: 7E2A02FA FF016102
	v_dual_add_f32 v2, v9, v10 :: v_dual_add_f32 v9, v4, v17   // 0000004644C8: C9081509 02082304
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000004644D0: BF870233
	v_mov_b32_dpp v4, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000004644D4: 7E0802FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 0000004644DC: D5010003 21AA0703
	v_add_f32_e32 v6, v13, v14                                 // 0000004644E4: 060C1D0D
	v_mov_b32_dpp v7, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000004644E8: 7E0E02FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, vcc_lo                      // 0000004644F0: D5010002 21AA0502
	v_mov_b32_dpp v12, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000004644F8: 7E1802FA FF016208
	v_add_f32_e32 v3, v3, v4                                   // 000000464500: 06060903
	v_mov_b32_dpp v10, v6 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000464504: 7E1402FA FF016206
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 00000046450C: D5010006 21AA0D06
	v_add_f32_e32 v5, v5, v15                                  // 000000464514: 060A1F05
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 000000464518: D5010008 21AA1108
	v_add_f32_e32 v13, v22, v21                                // 000000464520: 061A2B16
	v_mov_b32_dpp v14, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000464524: 7E1C02FA FF016209
	v_add_f32_e32 v6, v6, v10                                  // 00000046452C: 060C1506
	v_mov_b32_dpp v11, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000464530: 7E1602FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 000000464538: D5010005 21AA0B05
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 000000464540: D5010009 21AA1309
	v_add_f32_e32 v8, v8, v12                                  // 000000464548: 06101908
	v_mov_b32_dpp v15, v13 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000046454C: 7E1E02FA FF01620D
	v_cndmask_b32_e64 v13, -v13, v13, vcc_lo                   // 000000464554: D501000D 21AA1B0D
	v_add_f32_e32 v4, v5, v11                                  // 00000046455C: 06081705
	v_mov_b32_dpp v5, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000464560: 7E0A02FA FF016403
	v_cndmask_b32_e64 v3, -v3, v3, s1                          // 000000464568: D5010003 20060703
	v_add_f32_e32 v2, v2, v7                                   // 000000464570: 06040F02
	v_mov_b32_dpp v11, v6 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000464574: 7E1602FA FF016406
	v_cndmask_b32_e64 v6, -v6, v6, s1                          // 00000046457C: D5010006 20060D06
	v_add_f32_e32 v9, v9, v14                                  // 000000464584: 06121D09
	v_add_f32_e32 v3, v3, v5                                   // 000000464588: 06060B03
	v_cndmask_b32_e64 v7, -v2, v2, s1                          // 00000046458C: D5010007 20060502
	v_mov_b32_dpp v2, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000464594: 7E0402FA FF016402
	v_cndmask_b32_e64 v14, -v8, v8, s1                         // 00000046459C: D501000E 20061108
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000004645A4: BF870242
	v_add_f32_e32 v7, v7, v2                                   // 0000004645A8: 060E0507
	v_mov_b32_dpp v10, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000004645AC: 7E1402FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s1                          // 0000004645B4: D5010004 20060904
	v_mov_b32_dpp v2, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000004645BC: 7E0402FA FF016803
	v_mov_b32_dpp v5, v7 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000004645C4: 7E0A02FA FF016807
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000004645CC: BF8700A3
	v_add_f32_e32 v4, v4, v10                                  // 0000004645D0: 06081504
	v_add_f32_e32 v10, v20, v18                                // 0000004645D4: 06142514
	v_mov_b32_dpp v12, v10 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000004645D8: 7E1802FA FF01620A
	v_cndmask_b32_e64 v10, -v10, v10, vcc_lo                   // 0000004645E0: D501000A 21AA150A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000004645E8: BF870241
	v_add_f32_e32 v10, v10, v12                                // 0000004645EC: 0614190A
	v_add_f32_e32 v12, v13, v15                                // 0000004645F0: 06181F0D
	v_mov_b32_dpp v13, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000004645F4: 7E1A02FA FF016409
	v_cndmask_b32_e64 v9, -v9, v9, s1                          // 0000004645FC: D5010009 20061309
	v_mov_b32_dpp v15, v10 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000464604: 7E1E02FA FF01640A
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 00000046460C: BF870254
	v_mov_b32_dpp v17, v12 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000464610: 7E2202FA FF01640C
	v_cndmask_b32_e64 v10, -v10, v10, s1                       // 000000464618: D501000A 2006150A
	v_cndmask_b32_e64 v12, -v12, v12, s1                       // 000000464620: D501000C 2006190C
	v_add_f32_e32 v6, v6, v11                                  // 000000464628: 060C1706
	v_mov_b32_dpp v11, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000046462C: 7E1602FA FF016408
	v_dual_add_f32 v16, v9, v13 :: v_dual_add_f32 v15, v10, v15// 000000464634: C9081B09 100E1F0A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000046463C: BF870214
	v_add_f32_e32 v17, v12, v17                                // 000000464640: 0622230C
	v_mov_b32_dpp v8, v6 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000464644: 7E1002FA FF016806
	s_delay_alu instid0(VALU_DEP_4)                            // 00000046464C: BF870004
	v_add_f32_e32 v14, v14, v11                                // 000000464650: 061C170E
	v_mov_b32_dpp v9, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000464654: 7E1202FA FF016804
	v_mov_b32_dpp v11, v16 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000046465C: 7E1602FA FF016810
	v_mov_b32_dpp v12, v15 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000464664: 7E1802FA FF01680F
	v_mov_b32_dpp v13, v17 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000046466C: 7E1A02FA FF016811
	v_mov_b32_dpp v10, v14 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000464674: 7E1402FA FF01680E
	s_and_b32 exec_lo, exec_lo, s0                             // 00000046467C: 8B7E007E
	s_cbranch_execz 169                                        // 000000464680: BFA500A9 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb0ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2a28>
	v_lshl_or_b32 v20, s2, 7, v1                               // 000000464684: D6560014 04050E02
	.long 0x7f243880                                           // 00000046468C: 7F243880
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000464690: BF870112
	v_ashrrev_i32_e32 v21, 31, v20                             // 000000464694: 342A289F
	.long 0x7f303992                                           // 000000464698: 7F303992
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000046469C: BF870092
	.long 0xd73c0014                                           // 0000004646A0: D73C0014
	v_cndmask_b32_e32 v1, 1, v20, vcc_lo                       // 0000004646A4: 02022881
	.long 0xd7006a16                                           // 0000004646A8: D7006A16
	v_cndmask_b32_e32 v1, s14, v20, vcc_lo                     // 0000004646AC: 0202280E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000004646B0: BF870001
	v_add_co_ci_u32_e64 v23, null, s15, v21, vcc_lo            // 0000004646B4: D5207C17 01AA2A0F
	s_clause 0x7                                               // 0000004646BC: BF850007
	global_load_d16_b16 v18, v[22:23], off offset:32           // 0000004646C0: DC820020 127C0016
	global_load_d16_b16 v24, v[22:23], off                     // 0000004646C8: DC820000 187C0016
	global_load_d16_b16 v25, v[22:23], off offset:64           // 0000004646D0: DC820040 197C0016
	global_load_d16_b16 v26, v[22:23], off offset:96           // 0000004646D8: DC820060 1A7C0016
	global_load_d16_b16 v27, v[22:23], off offset:128          // 0000004646E0: DC820080 1B7C0016
	global_load_d16_b16 v28, v[22:23], off offset:160          // 0000004646E8: DC8200A0 1C7C0016
	global_load_d16_b16 v29, v[22:23], off offset:192          // 0000004646F0: DC8200C0 1D7C0016
	global_load_d16_b16 v22, v[22:23], off offset:224          // 0000004646F8: DC8200E0 167C0016
	v_and_b32_e32 v23, 8, v0                                   // 000000464700: 362E0088
	v_mad_i64_i32 v[0:1], null, s26, v19, 0                    // 000000464704: D6FF7C00 0202261A
	s_waitcnt vmcnt(7)                                         // 00000046470C: BF891FF7
	.long 0x7f263992                                           // 000000464710: 7F263992
	s_waitcnt vmcnt(0)                                         // 000000464714: BF8903F7
	.long 0x7f2c3992                                           // 000000464718: 7F2C3992
	v_cmp_eq_u32_e32 vcc_lo, 0, v23                            // 00000046471C: 7C942E80
	.long 0x7f2e3992                                           // 000000464720: 7F2E3992
	.long 0xd73c0000                                           // 000000464724: D73C0000
	v_cndmask_b32_e32 v1, 1, v0, vcc_lo                        // 000000464728: 02020081
	v_cndmask_b32_e64 v7, -v7, v7, vcc_lo                      // 00000046472C: D5010007 21AA0F07
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 000000464734: D5010003 21AA0703
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 00000046473C: D5010004 21AA0904
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 000000464744: D5010006 21AA0D06
	v_cndmask_b32_e64 v14, -v14, v14, vcc_lo                   // 00000046474C: D501000E 21AA1D0E
	v_add_f32_e32 v5, v7, v5                                   // 000000464754: 060A0B07
	v_cndmask_b32_e64 v7, -v16, v16, vcc_lo                    // 000000464758: D5010007 21AA2110
	v_cndmask_b32_e64 v16, -v17, v17, vcc_lo                   // 000000464760: D5010010 21AA2311
	v_cndmask_b32_e64 v15, -v15, v15, vcc_lo                   // 000000464768: D501000F 21AA1F0F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000464770: BF870124
	v_dual_add_f32 v2, v3, v2 :: v_dual_mul_f32 v3, 0x3db504f3, v5// 000000464774: C9060503 02020AFF 3DB504F3
	v_dual_add_f32 v5, v6, v8 :: v_dual_add_f32 v4, v4, v9     // 000000464780: C9081106 05041304
	v_dual_add_f32 v7, v7, v11 :: v_dual_mul_f32 v2, 0x3db504f3, v2// 000000464788: C9061707 070204FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000464794: BF870194
	v_dual_add_f32 v8, v15, v12 :: v_dual_add_f32 v9, v16, v13 // 000000464798: C908190F 08081B10
	v_mul_f32_e32 v4, 0x3db504f3, v4                           // 0000004647A0: 100808FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000004647A8: BF870193
	v_dual_add_f32 v6, v14, v10 :: v_dual_mul_f32 v7, 0x3db504f3, v7// 0000004647AC: C906150E 06060EFF 3DB504F3
	v_dual_mul_f32 v8, 0x3db504f3, v8 :: v_dual_mul_f32 v5, 0x3db504f3, v5// 0000004647B8: C8C610FF 08040AFF 3DB504F3
	.long 0xd7006a00                                           // 0000004647C4: D7006A00
	v_cndmask_b32_e32 v1, s20, v0, vcc_lo                      // 0000004647C8: 02020014
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000004647CC: BF8701A3
	v_mul_f32_e32 v6, 0x3db504f3, v6                           // 0000004647D0: 100C0CFF 3DB504F3
	v_add_co_ci_u32_e64 v1, null, s21, v1, vcc_lo              // 0000004647D8: D5207C01 01AA0215
	.long 0xd7006a00                                           // 0000004647E0: D7006A00
	v_cndmask_b32_e32 v1, v0, v20, vcc_lo                      // 0000004647E4: 02022900
	s_delay_alu instid0(VALU_DEP_1)                            // 0000004647E8: BF870001
	v_add_co_ci_u32_e64 v1, null, v1, v21, vcc_lo              // 0000004647EC: D5207C01 01AA2B01
	v_fma_mix_f32 v3, v18, v3, neg(0) op_sel_hi:[1,0,0]        // 0000004647F4: CC200003 8A020712
	v_fma_mix_f32 v2, v24, v2, neg(0) op_sel_hi:[1,0,0]        // 0000004647FC: CC200002 8A020518
	v_fma_mix_f32 v5, v25, v5, neg(0) op_sel_hi:[1,0,0]        // 000000464804: CC200005 8A020B19
	v_fma_mix_f32 v4, v26, v4, neg(0) op_sel_hi:[1,0,0]        // 00000046480C: CC200004 8A02091A
	v_fma_mix_f32 v6, v27, v6, neg(0) op_sel_hi:[1,0,0]        // 000000464814: CC200006 8A020D1B
	.long 0x7e243983                                           // 00000046481C: 7E243983
	v_mul_f32_e32 v9, 0x3db504f3, v9                           // 000000464820: 101212FF 3DB504F3
	v_fma_mix_f32 v7, v28, v7, neg(0) op_sel_hi:[1,0,0]        // 000000464828: CC200007 8A020F1C
	v_fma_mix_f32 v8, v29, v8, neg(0) op_sel_hi:[1,0,0]        // 000000464830: CC200008 8A02111D
	.long 0x7e263982                                           // 000000464838: 7E263982
	v_and_b32_e32 v10, 1, v18                                  // 00000046483C: 36142481
	.long 0x7e243984                                           // 000000464840: 7E243984
	v_fma_mix_f32 v9, v22, v9, neg(0) op_sel_hi:[1,0,0]        // 000000464844: CC200009 8A021316
	.long 0x7e2c3985                                           // 00000046484C: 7E2C3985
	.long 0x7e2e3986                                           // 000000464850: 7E2E3986
	.long 0x7e303988                                           // 000000464854: 7E303988
	v_and_b32_e32 v11, 1, v18                                  // 000000464858: 36162481
	.long 0x7e243987                                           // 00000046485C: 7E243987
	v_and_b32_e32 v12, 1, v19                                  // 000000464860: 36182681
	v_and_b32_e32 v13, 1, v22                                  // 000000464864: 361A2C81
	v_and_b32_e32 v14, 1, v23                                  // 000000464868: 361C2E81
	v_and_b32_e32 v16, 1, v24                                  // 00000046486C: 36203081
	v_and_b32_e32 v15, 1, v18                                  // 000000464870: 361E2481
	.long 0x7e243989                                           // 000000464874: 7E243989
	v_add3_u32 v3, v3, v10, 0x7fff                             // 000000464878: D6550003 03FE1503 00007FFF
	v_add3_u32 v2, v2, v12, 0x7fff                             // 000000464884: D6550002 03FE1902 00007FFF
	v_add3_u32 v5, v5, v13, 0x7fff                             // 000000464890: D6550005 03FE1B05 00007FFF
	v_add3_u32 v4, v4, v11, 0x7fff                             // 00000046489C: D6550004 03FE1704 00007FFF
	v_and_b32_e32 v10, 1, v18                                  // 0000004648A8: 36142481
	v_add3_u32 v6, v6, v14, 0x7fff                             // 0000004648AC: D6550006 03FE1D06 00007FFF
	v_add3_u32 v8, v8, v16, 0x7fff                             // 0000004648B8: D6550008 03FE2108 00007FFF
	v_add3_u32 v7, v7, v15, 0x7fff                             // 0000004648C4: D6550007 03FE1F07 00007FFF
	s_delay_alu instid0(VALU_DEP_4)                            // 0000004648D0: BF870004
	v_add3_u32 v9, v9, v10, 0x7fff                             // 0000004648D4: D6550009 03FE1509 00007FFF
	s_clause 0x7                                               // 0000004648E0: BF850007
	global_store_d16_hi_b16 v[0:1], v2, off                    // 0000004648E4: DC960000 007C0200
	global_store_d16_hi_b16 v[0:1], v3, off offset:32          // 0000004648EC: DC960020 007C0300
	global_store_d16_hi_b16 v[0:1], v5, off offset:64          // 0000004648F4: DC960040 007C0500
	global_store_d16_hi_b16 v[0:1], v4, off offset:96          // 0000004648FC: DC960060 007C0400
	global_store_d16_hi_b16 v[0:1], v6, off offset:128         // 000000464904: DC960080 007C0600
	global_store_d16_hi_b16 v[0:1], v7, off offset:160         // 00000046490C: DC9600A0 007C0700
	global_store_d16_hi_b16 v[0:1], v8, off offset:192         // 000000464914: DC9600C0 007C0800
	global_store_d16_hi_b16 v[0:1], v9, off offset:224         // 00000046491C: DC9600E0 007C0900
	s_endpgm                                                   // 000000464924: BFB00000
	s_endpgm                                                   // 000000464928: BFB00000
		...

