000000000072db00 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi5ELi32ELi1ELb1EEEvPKhPKtPvll>:
; _ZN7halogen12_GLOBAL__N_18k_lq8s32ILi5ELi32ELi1ELb1EEEvPKhPKtPvll():
	s_clause 0x1                                               // 00000072DB00: BF850001
	s_load_b256 s[4:11], s[0:1], null                          // 00000072DB04: F40C0100 F8000000
	s_load_b64 s[12:13], s[0:1], 0x20                          // 00000072DB0C: F4040300 F8000020
	v_lshrrev_b32_e32 v1, 5, v0                                // 00000072DB14: 32020085
	s_mov_b32 s3, 0                                            // 00000072DB18: BE830080
	v_dual_mov_b32 v16, 0 :: v_dual_and_b32 v15, 31, v0        // 00000072DB1C: CA240080 100E009F
	s_lshl_b64 s[0:1], s[2:3], 3                               // 00000072DB24: 84808302
	.long 0x7e323880                                           // 00000072DB28: 7E323880
	v_or_b32_e32 v9, s0, v1                                    // 00000072DB2C: 38120200
	v_mov_b32_e32 v10, s1                                      // 00000072DB30: 7E140201
	v_dual_mov_b32 v4, 0 :: v_dual_mov_b32 v5, 0               // 00000072DB34: CA100080 04040080
	v_dual_mov_b32 v6, 0 :: v_dual_lshlrev_b32 v11, 4, v15     // 00000072DB3C: CA220080 060A1E84
	s_waitcnt lgkmcnt(0)                                       // 00000072DB44: BF89FC07
	s_ashr_i32 s0, s11, 31                                     // 00000072DB48: 86009F0B
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[9:10]                 // 00000072DB4C: 7CA8120C
	s_lshr_b32 s0, s0, 28                                      // 00000072DB50: 85009C00
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000072DB54: BF8704A9
	s_add_u32 s2, s10, s0                                      // 00000072DB58: 8002000A
	s_addc_u32 s3, s11, 0                                      // 00000072DB5C: 8203800B
	s_ashr_i64 s[2:3], s[2:3], 4                               // 00000072DB60: 86828402
	v_cndmask_b32_e32 v1, 0, v9, vcc_lo                        // 00000072DB64: 02021280
	s_add_u32 s0, s10, s2                                      // 00000072DB68: 8000020A
	v_cndmask_b32_e64 v2, 0, s1, vcc_lo                        // 00000072DB6C: D5010002 01A80280
	s_addc_u32 s1, s11, s3                                     // 00000072DB74: 8201030B
	s_add_u32 s0, s0, 15                                       // 00000072DB78: 80008F00
	s_addc_u32 s1, s1, 0                                       // 00000072DB7C: 82018001
	s_and_b32 s0, s0, -16                                      // 00000072DB80: 8B00D000
	.long 0xd72c0003                                           // 00000072DB84: D72C0003
	v_cndmask_b32_e32 v0, v1, v1, vcc_lo                       // 00000072DB88: 02000301
	.long 0xd72c0007                                           // 00000072DB8C: D72C0007
	v_cndmask_b32_e32 v0, v2, v0, vcc_lo                       // 00000072DB90: 02000102
	v_mad_u64_u32 v[1:2], null, v1, s0, 0                      // 00000072DB94: D6FE7C01 02000101
	.long 0xd4440000                                           // 00000072DB9C: D4440000
	v_cndmask_b32_e32 v1, s2, v15, vcc_lo                      // 00000072DBA0: 02021E02
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000072DBA4: BF870192
	v_add3_u32 v2, v2, v3, v7                                  // 00000072DBA8: D6550002 041E0702
	.long 0xd7000111                                           // 00000072DBB0: D7000111
	v_cndmask_b32_e32 v1, s4, v1, vcc_lo                       // 00000072DBB4: 02020204
	v_mov_b32_e32 v7, 0                                        // 00000072DBB8: 7E0E0280
	s_delay_alu instid0(VALU_DEP_3)                            // 00000072DBBC: BF870003
	v_add_co_ci_u32_e64 v18, null, s5, v2, s1                  // 00000072DBC0: D5207C12 00060405
	s_and_saveexec_b32 s3, s0                                  // 00000072DBC8: BE832000
	s_cbranch_execz 21                                         // 00000072DBCC: BFA50015 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi5ELi32ELi1ELb1EEEvPKhPKtPvll+0x124>
	v_lshlrev_b32_e32 v3, 4, v15                               // 00000072DBD0: 30061E84
	.long 0xd7000105                                           // 00000072DBD4: D7000105
	v_cndmask_b32_e32 v0, v17, v10, vcc_lo                     // 00000072DBD8: 02001511
	v_and_b32_e32 v7, 30, v0                                   // 00000072DBDC: 360E009E
	v_add_co_ci_u32_e64 v6, null, s11, v18, s1                 // 00000072DBE0: D5207C06 0006240B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000072DBE8: BF870094
	.long 0xd7000103                                           // 00000072DBEC: D7000103
	v_cndmask_b32_e32 v1, v17, v3, vcc_lo                      // 00000072DBF0: 02020711
	v_add_co_ci_u32_e64 v4, null, 0, v18, s1                   // 00000072DBF4: D5207C04 00062480
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000072DBFC: BF870094
	.long 0xd700010c                                           // 00000072DC00: D700010C
	v_cndmask_b32_e32 v1, v5, v7, vcc_lo                       // 00000072DC04: 02020F05
	v_add_co_ci_u32_e64 v13, null, 0, v6, s1                   // 00000072DC08: D5207C0D 00060C80
	s_clause 0x1                                               // 00000072DC10: BF850001
	global_load_b128 v[4:7], v[3:4], off                       // 00000072DC14: DC5E0000 047C0003
	global_load_d16_b16 v25, v[12:13], off                     // 00000072DC1C: DC820000 197C000C
	s_or_b32 exec_lo, exec_lo, s3                              // 00000072DC24: 8C7E037E
	v_dual_mov_b32 v19, 0 :: v_dual_mov_b32 v20, 0             // 00000072DC28: CA100080 13140080
	v_dual_mov_b32 v21, 0 :: v_dual_mov_b32 v22, 0             // 00000072DC30: CA100080 15160080
	s_and_saveexec_b32 s3, s0                                  // 00000072DC38: BE832000
	s_cbranch_execz 472                                        // 00000072DC3C: BFA501D8 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi5ELi32ELi1ELb1EEEvPKhPKtPvll+0x8a0>
	v_and_or_b32 v0, v0, 30, 32                                // 00000072DC40: D6570000 02813D00
	.long 0xd7000001                                           // 00000072DC48: D7000001
	v_cndmask_b32_e32 v1, s10, v1, vcc_lo                      // 00000072DC4C: 0202020A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000072DC50: BF8701A1
	v_add_co_ci_u32_e64 v2, null, s11, v2, s0                  // 00000072DC54: D5207C02 0002040B
	v_dual_mov_b32 v12, 0 :: v_dual_mov_b32 v23, v15           // 00000072DC5C: CA100080 0C16010F
	.long 0xd7000000                                           // 00000072DC64: D7000000
	v_cndmask_b32_e32 v1, v1, v0, vcc_lo                       // 00000072DC68: 02020101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000072DC6C: BF870191
	v_add_co_ci_u32_e64 v1, null, 0, v2, s0                    // 00000072DC70: D5207C01 00020480
	v_mov_b32_e32 v22, v12                                     // 00000072DC78: 7E2C030C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000072DC7C: BF870093
	.long 0xd700000d                                           // 00000072DC80: D700000D
	v_cndmask_b32_e32 v1, s4, v0, vcc_lo                       // 00000072DC84: 02020004
	v_add_co_ci_u32_e64 v14, null, s5, v1, s0                  // 00000072DC88: D5207C0E 00020205
	v_mov_b32_e32 v21, v12                                     // 00000072DC90: 7E2A030C
	v_mov_b32_e32 v20, v12                                     // 00000072DC94: 7E28030C
	v_mov_b32_e32 v19, v12                                     // 00000072DC98: 7E26030C
	v_mov_b32_e32 v16, v12                                     // 00000072DC9C: 7E20030C
	s_mul_i32 s1, s11, 6                                       // 00000072DCA0: 9601860B
	s_mul_hi_u32 s16, s10, 6                                   // 00000072DCA4: 9690860A
	s_lshl_b64 s[14:15], s[10:11], 2                           // 00000072DCA8: 848E820A
	s_add_i32 s16, s16, s1                                     // 00000072DCAC: 81100110
	s_mul_i32 s18, s10, 6                                      // 00000072DCB0: 9612860A
	s_mov_b32 s17, 0                                           // 00000072DCB4: BE910080
	s_lshl_b64 s[4:5], s[10:11], 1                             // 00000072DCB8: 8484810A
	s_branch 410                                               // 00000072DCBC: BFA0019A <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi5ELi32ELi1ELb1EEEvPKhPKtPvll+0x828>
	s_or_b32 exec_lo, exec_lo, s10                             // 00000072DCC0: 8C7E0A7E
	v_bfe_i32 v26, v4, 0, 8                                    // 00000072DCC4: D611001A 02210104
	s_and_b32 s0, exec_lo, s0                                  // 00000072DCCC: 8B00007E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000072DCD0: BF870099
	s_or_b32 s17, s0, s17                                      // 00000072DCD4: 8C111100
	v_cvt_f32_i32_e32 v26, v26                                 // 00000072DCD8: 7E340B1A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000072DCDC: BF870091
	v_fma_mix_f32 v26, v25, v26, neg(0) op_sel_hi:[1,0,0]      // 00000072DCE0: CC20001A 8A023519
	v_bfe_u32 v27, v26, 16, 1                                  // 00000072DCE8: D610001B 0205211A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000072DCF0: BF870121
	v_add3_u32 v26, v26, v27, 0x7fff                           // 00000072DCF4: D655001A 03FE371A 00007FFF
	.long 0x7f363880                                           // 00000072DD00: 7F363880
	.long 0x7e36399a                                           // 00000072DD04: 7E36399A
	v_bfe_i32 v26, v4, 8, 8                                    // 00000072DD08: D611001A 02211104
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000072DD10: BF870091
	v_cvt_f32_i32_e32 v26, v26                                 // 00000072DD14: 7E340B1A
	v_fma_mix_f32 v26, v25, v26, neg(0) op_sel_hi:[1,0,0]      // 00000072DD18: CC20001A 8A023519
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000072DD20: BF870091
	v_bfe_u32 v28, v26, 16, 1                                  // 00000072DD24: D610001C 0205211A
	v_add3_u32 v26, v26, v28, 0x7fff                           // 00000072DD2C: D655001A 03FE391A 00007FFF
	v_bfe_i32 v28, v4, 16, 8                                   // 00000072DD38: D611001C 02212104
	v_ashrrev_i32_e32 v4, 24, v4                               // 00000072DD40: 34080898
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000072DD44: BF870193
	v_and_or_b32 v33, 0xffff0000, v26, v27                     // 00000072DD48: D6570021 046E34FF FFFF0000
	v_cvt_f32_i32_e32 v28, v28                                 // 00000072DD54: 7E380B1C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000072DD58: BF870113
	v_cvt_f32_i32_e32 v4, v4                                   // 00000072DD5C: 7E080B04
	v_fma_mix_f32 v28, v25, v28, neg(0) op_sel_hi:[1,0,0]      // 00000072DD60: CC20001C 8A023919
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000072DD68: BF870112
	v_fma_mix_f32 v4, v25, v4, neg(0) op_sel_hi:[1,0,0]        // 00000072DD6C: CC200004 8A020919
	v_bfe_u32 v29, v28, 16, 1                                  // 00000072DD74: D610001D 0205211C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000072DD7C: BF870191
	v_add3_u32 v28, v28, v29, 0x7fff                           // 00000072DD80: D655001C 03FE3B1C 00007FFF
	v_bfe_u32 v29, v4, 16, 1                                   // 00000072DD8C: D610001D 02052104
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000072DD94: BF8701A2
	.long 0x7e38399c                                           // 00000072DD98: 7E38399C
	.long 0x7f38399b                                           // 00000072DD9C: 7F38399B
	v_add3_u32 v4, v4, v29, 0x7fff                             // 00000072DDA0: D6550004 03FE3B04 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000072DDAC: BF8700A1
	v_and_or_b32 v34, 0xffff0000, v4, v28                      // 00000072DDB0: D6570022 047208FF FFFF0000
	v_bfe_i32 v4, v5, 0, 8                                     // 00000072DDBC: D6110004 02210105
	v_cvt_f32_i32_e32 v4, v4                                   // 00000072DDC4: 7E080B04
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000072DDC8: BF870091
	v_fma_mix_f32 v4, v25, v4, neg(0) op_sel_hi:[1,0,0]        // 00000072DDCC: CC200004 8A020919
	v_bfe_u32 v26, v4, 16, 1                                   // 00000072DDD4: D610001A 02052104
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000072DDDC: BF870091
	v_add3_u32 v4, v4, v26, 0x7fff                             // 00000072DDE0: D6550004 03FE3504 00007FFF
	.long 0x7e363984                                           // 00000072DDEC: 7E363984
	v_bfe_i32 v4, v5, 8, 8                                     // 00000072DDF0: D6110004 02211105
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000072DDF8: BF870091
	v_cvt_f32_i32_e32 v4, v4                                   // 00000072DDFC: 7E080B04
	v_fma_mix_f32 v4, v25, v4, neg(0) op_sel_hi:[1,0,0]        // 00000072DE00: CC200004 8A020919
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000072DE08: BF870091
	v_bfe_u32 v26, v4, 16, 1                                   // 00000072DE0C: D610001A 02052104
	v_add3_u32 v4, v4, v26, 0x7fff                             // 00000072DE14: D6550004 03FE3504 00007FFF
	v_bfe_i32 v26, v5, 16, 8                                   // 00000072DE20: D611001A 02212105
	v_ashrrev_i32_e32 v5, 24, v5                               // 00000072DE28: 340A0A98
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000072DE2C: BF870193
	v_and_or_b32 v35, 0xffff0000, v4, v27                      // 00000072DE30: D6570023 046E08FF FFFF0000
	v_cvt_f32_i32_e32 v26, v26                                 // 00000072DE3C: 7E340B1A
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000072DE40: BF8701A3
	v_cvt_f32_i32_e32 v5, v5                                   // 00000072DE44: 7E0A0B05
	v_bfe_i32 v4, v6, 0, 8                                     // 00000072DE48: D6110004 02210106
	v_fma_mix_f32 v26, v25, v26, neg(0) op_sel_hi:[1,0,0]      // 00000072DE50: CC20001A 8A023519
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000072DE58: BF870193
	v_fma_mix_f32 v5, v25, v5, neg(0) op_sel_hi:[1,0,0]        // 00000072DE5C: CC200005 8A020B19
	v_cvt_f32_i32_e32 v4, v4                                   // 00000072DE64: 7E080B04
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000072DE68: BF870113
	v_bfe_u32 v28, v26, 16, 1                                  // 00000072DE6C: D610001C 0205211A
	v_fma_mix_f32 v4, v25, v4, neg(0) op_sel_hi:[1,0,0]        // 00000072DE74: CC200004 8A020919
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000072DE7C: BF870122
	v_add3_u32 v26, v26, v28, 0x7fff                           // 00000072DE80: D655001A 03FE391A 00007FFF
	v_bfe_u32 v28, v5, 16, 1                                   // 00000072DE8C: D610001C 02052105
	.long 0x7e34399a                                           // 00000072DE94: 7E34399A
	.long 0x7f34399b                                           // 00000072DE98: 7F34399B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000072DE9C: BF870093
	v_add3_u32 v5, v5, v28, 0x7fff                             // 00000072DEA0: D6550005 03FE3905 00007FFF
	v_and_or_b32 v36, 0xffff0000, v5, v26                      // 00000072DEAC: D6570024 046A0AFF FFFF0000
	v_bfe_u32 v5, v4, 16, 1                                    // 00000072DEB8: D6100005 02052104
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000072DEC0: BF870091
	v_add3_u32 v4, v4, v5, 0x7fff                              // 00000072DEC4: D6550004 03FE0B04 00007FFF
	.long 0x7e363984                                           // 00000072DED0: 7E363984
	v_bfe_i32 v4, v6, 8, 8                                     // 00000072DED4: D6110004 02211106
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000072DEDC: BF870091
	v_cvt_f32_i32_e32 v4, v4                                   // 00000072DEE0: 7E080B04
	v_fma_mix_f32 v4, v25, v4, neg(0) op_sel_hi:[1,0,0]        // 00000072DEE4: CC200004 8A020919
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000072DEEC: BF870091
	v_bfe_u32 v5, v4, 16, 1                                    // 00000072DEF0: D6100005 02052104
	v_add3_u32 v4, v4, v5, 0x7fff                              // 00000072DEF8: D6550004 03FE0B04 00007FFF
	v_bfe_i32 v5, v6, 16, 8                                    // 00000072DF04: D6110005 02212106
	v_ashrrev_i32_e32 v6, 24, v6                               // 00000072DF0C: 340C0C98
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000072DF10: BF870193
	v_and_or_b32 v37, 0xffff0000, v4, v27                      // 00000072DF14: D6570025 046E08FF FFFF0000
	v_cvt_f32_i32_e32 v5, v5                                   // 00000072DF20: 7E0A0B05
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000072DF24: BF8701A3
	v_cvt_f32_i32_e32 v6, v6                                   // 00000072DF28: 7E0C0B06
	v_bfe_i32 v4, v7, 0, 8                                     // 00000072DF2C: D6110004 02210107
	v_fma_mix_f32 v5, v25, v5, neg(0) op_sel_hi:[1,0,0]        // 00000072DF34: CC200005 8A020B19
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000072DF3C: BF870193
	v_fma_mix_f32 v6, v25, v6, neg(0) op_sel_hi:[1,0,0]        // 00000072DF40: CC200006 8A020D19
	v_cvt_f32_i32_e32 v4, v4                                   // 00000072DF48: 7E080B04
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000072DF4C: BF870113
	v_bfe_u32 v26, v5, 16, 1                                   // 00000072DF50: D610001A 02052105
	v_fma_mix_f32 v4, v25, v4, neg(0) op_sel_hi:[1,0,0]        // 00000072DF58: CC200004 8A020919
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000072DF60: BF870122
	v_add3_u32 v5, v5, v26, 0x7fff                             // 00000072DF64: D6550005 03FE3505 00007FFF
	v_bfe_u32 v26, v6, 16, 1                                   // 00000072DF70: D610001A 02052106
	.long 0x7e0a3985                                           // 00000072DF78: 7E0A3985
	.long 0x7f0a399b                                           // 00000072DF7C: 7F0A399B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000072DF80: BF870093
	v_add3_u32 v6, v6, v26, 0x7fff                             // 00000072DF84: D6550006 03FE3506 00007FFF
	v_and_or_b32 v38, 0xffff0000, v6, v5                       // 00000072DF90: D6570026 04160CFF FFFF0000
	v_bfe_u32 v5, v4, 16, 1                                    // 00000072DF9C: D6100005 02052104
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000072DFA4: BF870091
	v_add3_u32 v4, v4, v5, 0x7fff                              // 00000072DFA8: D6550004 03FE0B04 00007FFF
	.long 0x7e363984                                           // 00000072DFB4: 7E363984
	v_bfe_i32 v4, v7, 8, 8                                     // 00000072DFB8: D6110004 02211107
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000072DFC0: BF870091
	v_cvt_f32_i32_e32 v4, v4                                   // 00000072DFC4: 7E080B04
	v_fma_mix_f32 v4, v25, v4, neg(0) op_sel_hi:[1,0,0]        // 00000072DFC8: CC200004 8A020919
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000072DFD0: BF870091
	v_bfe_u32 v5, v4, 16, 1                                    // 00000072DFD4: D6100005 02052104
	v_add3_u32 v4, v4, v5, 0x7fff                              // 00000072DFDC: D6550004 03FE0B04 00007FFF
	v_bfe_i32 v5, v7, 16, 8                                    // 00000072DFE8: D6110005 02212107
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000072DFF0: BF870112
	v_and_or_b32 v39, 0xffff0000, v4, v27                      // 00000072DFF4: D6570027 046E08FF FFFF0000
	v_cvt_f32_i32_e32 v5, v5                                   // 00000072E000: 7E0A0B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000072E004: BF870091
	v_fma_mix_f32 v5, v25, v5, neg(0) op_sel_hi:[1,0,0]        // 00000072E008: CC200005 8A020B19
	v_bfe_u32 v6, v5, 16, 1                                    // 00000072E010: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000072E018: BF870121
	v_add3_u32 v5, v5, v6, 0x7fff                              // 00000072E01C: D6550005 03FE0D05 00007FFF
	v_ashrrev_i32_e32 v6, 24, v7                               // 00000072E028: 340C0E98
	.long 0x7e0a3985                                           // 00000072E02C: 7E0A3985
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000072E030: BF870122
	v_cvt_f32_i32_e32 v6, v6                                   // 00000072E034: 7E0C0B06
	.long 0x7f0a399b                                           // 00000072E038: 7F0A399B
	v_fma_mix_f32 v6, v25, v6, neg(0) op_sel_hi:[1,0,0]        // 00000072E03C: CC200006 8A020D19
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000072E044: BF870091
	v_bfe_u32 v7, v6, 16, 1                                    // 00000072E048: D6100007 02052106
	v_add3_u32 v6, v6, v7, 0x7fff                              // 00000072E050: D6550006 03FE0F06 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000072E05C: BF870131
	v_and_or_b32 v40, 0xffff0000, v6, v5                       // 00000072E060: D6570028 04160CFF FFFF0000
	.long 0xd73c0004                                           // 00000072E06C: D73C0004
	v_cndmask_b32_e32 v1, 1, v11, vcc_lo                       // 00000072E070: 02021681
	v_mov_b32_e32 v11, v24                                     // 00000072E074: 7E160318
	.long 0xd700001d                                           // 00000072E078: D700001D
	v_cndmask_b32_e32 v1, s6, v4, vcc_lo                       // 00000072E07C: 02020806
	s_delay_alu instid0(VALU_DEP_1)                            // 00000072E080: BF870001
	v_add_co_ci_u32_e64 v30, null, s7, v5, s0                  // 00000072E084: D5207C1E 00020A07
	s_clause 0x1                                               // 00000072E08C: BF850001
	global_load_b128 v[4:7], v[29:30], off                     // 00000072E090: DC5E0000 047C001D
	global_load_b128 v[25:28], v[29:30], off offset:16         // 00000072E098: DC5E0010 197C001D
	s_waitcnt vmcnt(1)                                         // 00000072E0A0: BF8907F7
	v_dot2_f32_bf16 v4, v4, v33, 0                             // 00000072E0A4: CC1A4004 1A024304
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000072E0AC: BF870091
	v_dot2_f32_bf16 v4, v5, v34, v4                            // 00000072E0B0: CC1A4004 1C124505
	v_dot2_f32_bf16 v4, v6, v35, v4                            // 00000072E0B8: CC1A4004 1C124706
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000072E0C0: BF8700A1
	v_dot2_f32_bf16 v4, v7, v36, v4                            // 00000072E0C4: CC1A4004 1C124907
	s_waitcnt vmcnt(0)                                         // 00000072E0CC: BF8903F7
	v_dot2_f32_bf16 v4, v25, v37, v4                           // 00000072E0D0: CC1A4004 1C124B19
	.long 0xd7000019                                           // 00000072E0D8: D7000019
	v_cndmask_b32_e32 v0, v29, v4, vcc_lo                      // 00000072E0DC: 0200091D
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000072E0E0: BF8701B2
	v_dot2_f32_bf16 v4, v26, v38, v4                           // 00000072E0E4: CC1A4004 1C124D1A
	v_add_co_ci_u32_e64 v26, null, s5, v30, s0                 // 00000072E0EC: D5207C1A 00023C05
	.long 0xd700001f                                           // 00000072E0F4: D700001F
	v_cndmask_b32_e32 v0, v29, v14, vcc_lo                     // 00000072E0F8: 02001D1D
	v_dot2_f32_bf16 v4, v27, v39, v4                           // 00000072E0FC: CC1A4004 1C124F1B
	v_add_co_ci_u32_e64 v32, null, s15, v30, s0                // 00000072E104: D5207C20 00023C0F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000072E10C: BF870092
	v_dot2_f32_bf16 v4, v28, v40, v4                           // 00000072E110: CC1A4004 1C12511C
	v_add_f32_e32 v22, v22, v4                                 // 00000072E118: 062C0916
	s_clause 0x1                                               // 00000072E11C: BF850001
	global_load_b128 v[4:7], v[25:26], off                     // 00000072E120: DC5E0000 047C0019
	global_load_b128 v[25:28], v[25:26], off offset:16         // 00000072E128: DC5E0010 197C0019
	s_waitcnt vmcnt(1)                                         // 00000072E130: BF8907F7
	v_dot2_f32_bf16 v4, v4, v33, 0                             // 00000072E134: CC1A4004 1A024304
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000072E13C: BF870091
	v_dot2_f32_bf16 v4, v5, v34, v4                            // 00000072E140: CC1A4004 1C124505
	v_dot2_f32_bf16 v4, v6, v35, v4                            // 00000072E148: CC1A4004 1C124706
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000072E150: BF8700A1
	v_dot2_f32_bf16 v4, v7, v36, v4                            // 00000072E154: CC1A4004 1C124907
	s_waitcnt vmcnt(0)                                         // 00000072E15C: BF8903F7
	v_dot2_f32_bf16 v4, v25, v37, v4                           // 00000072E160: CC1A4004 1C124B19
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000072E168: BF870091
	v_dot2_f32_bf16 v4, v26, v38, v4                           // 00000072E16C: CC1A4004 1C124D1A
	v_dot2_f32_bf16 v4, v27, v39, v4                           // 00000072E174: CC1A4004 1C124F1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000072E17C: BF870091
	v_dot2_f32_bf16 v4, v28, v40, v4                           // 00000072E180: CC1A4004 1C12511C
	v_add_f32_e32 v21, v21, v4                                 // 00000072E188: 062A0915
	s_clause 0x1                                               // 00000072E18C: BF850001
	global_load_b128 v[4:7], v[31:32], off                     // 00000072E190: DC5E0000 047C001F
	global_load_b128 v[25:28], v[31:32], off offset:16         // 00000072E198: DC5E0010 197C001F
	s_waitcnt vmcnt(1)                                         // 00000072E1A0: BF8907F7
	v_dot2_f32_bf16 v4, v4, v33, 0                             // 00000072E1A4: CC1A4004 1A024304
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000072E1AC: BF870091
	v_dot2_f32_bf16 v4, v5, v34, v4                            // 00000072E1B0: CC1A4004 1C124505
	v_dot2_f32_bf16 v4, v6, v35, v4                            // 00000072E1B8: CC1A4004 1C124706
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000072E1C0: BF8700A1
	v_dot2_f32_bf16 v4, v7, v36, v4                            // 00000072E1C4: CC1A4004 1C124907
	s_waitcnt vmcnt(0)                                         // 00000072E1CC: BF8903F7
	v_dot2_f32_bf16 v4, v25, v37, v4                           // 00000072E1D0: CC1A4004 1C124B19
	.long 0xd7000019                                           // 00000072E1D8: D7000019
	v_cndmask_b32_e32 v0, v29, v18, vcc_lo                     // 00000072E1DC: 0200251D
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000072E1E0: BF870122
	v_dot2_f32_bf16 v4, v26, v38, v4                           // 00000072E1E4: CC1A4004 1C124D1A
	v_add_co_ci_u32_e64 v26, null, s16, v30, s0                // 00000072E1EC: D5207C1A 00023C10
	v_dot2_f32_bf16 v4, v27, v39, v4                           // 00000072E1F4: CC1A4004 1C124F1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000072E1FC: BF870091
	v_dot2_f32_bf16 v4, v28, v40, v4                           // 00000072E200: CC1A4004 1C12511C
	v_add_f32_e32 v20, v20, v4                                 // 00000072E208: 06280914
	s_clause 0x1                                               // 00000072E20C: BF850001
	global_load_b128 v[4:7], v[25:26], off                     // 00000072E210: DC5E0000 047C0019
	global_load_b128 v[25:28], v[25:26], off offset:16         // 00000072E218: DC5E0010 197C0019
	s_waitcnt vmcnt(1)                                         // 00000072E220: BF8907F7
	v_dot2_f32_bf16 v4, v4, v33, 0                             // 00000072E224: CC1A4004 1A024304
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000072E22C: BF870091
	v_dot2_f32_bf16 v4, v5, v34, v4                            // 00000072E230: CC1A4004 1C124505
	v_dot2_f32_bf16 v4, v6, v35, v4                            // 00000072E238: CC1A4004 1C124706
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000072E240: BF8700A1
	v_dot2_f32_bf16 v4, v7, v36, v4                            // 00000072E244: CC1A4004 1C124907
	s_waitcnt vmcnt(0)                                         // 00000072E24C: BF8903F7
	v_dot2_f32_bf16 v4, v25, v37, v4                           // 00000072E250: CC1A4004 1C124B19
	.long 0xd7000019                                           // 00000072E258: D7000019
	v_cndmask_b32_e32 v0, v31, v14, vcc_lo                     // 00000072E25C: 02001D1F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000072E260: BF8701B2
	v_dot2_f32_bf16 v4, v26, v38, v4                           // 00000072E264: CC1A4004 1C124D1A
	v_add_co_ci_u32_e64 v26, null, s15, v32, s0                // 00000072E26C: D5207C1A 0002400F
	.long 0xd700000d                                           // 00000072E274: D700000D
	v_cndmask_b32_e32 v0, v13, v160, vcc_lo                    // 00000072E278: 0201410D
	v_dot2_f32_bf16 v4, v27, v39, v4                           // 00000072E27C: CC1A4004 1C124F1B
	v_add_co_ci_u32_e64 v14, null, 0, v14, s0                  // 00000072E284: D5207C0E 00021C80
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000072E28C: BF870092
	v_dot2_f32_bf16 v4, v28, v40, v4                           // 00000072E290: CC1A4004 1C12511C
	v_add_f32_e32 v19, v19, v4                                 // 00000072E298: 06260913
	s_clause 0x1                                               // 00000072E29C: BF850001
	global_load_b128 v[4:7], v[25:26], off                     // 00000072E2A0: DC5E0000 047C0019
	global_load_b128 v[25:28], v[25:26], off offset:16         // 00000072E2A8: DC5E0010 197C0019
	s_waitcnt vmcnt(1)                                         // 00000072E2B0: BF8907F7
	v_dot2_f32_bf16 v4, v4, v33, 0                             // 00000072E2B4: CC1A4004 1A024304
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000072E2BC: BF870121
	v_dot2_f32_bf16 v4, v5, v34, v4                            // 00000072E2C0: CC1A4004 1C124505
	v_mov_b32_e32 v5, v1                                       // 00000072E2C8: 7E0A0301
	v_dot2_f32_bf16 v4, v6, v35, v4                            // 00000072E2CC: CC1A4004 1C124706
	v_mov_b32_e32 v6, v2                                       // 00000072E2D4: 7E0C0302
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000072E2D8: BF870132
	v_dot2_f32_bf16 v4, v7, v36, v4                            // 00000072E2DC: CC1A4004 1C124907
	v_mov_b32_e32 v7, v3                                       // 00000072E2E4: 7E0E0303
	s_waitcnt vmcnt(0)                                         // 00000072E2E8: BF8903F7
	v_dot2_f32_bf16 v4, v25, v37, v4                           // 00000072E2EC: CC1A4004 1C124B19
	.long 0x7e323908                                           // 00000072E2F4: 7E323908
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000072E2F8: BF870092
	v_dot2_f32_bf16 v4, v26, v38, v4                           // 00000072E2FC: CC1A4004 1C124D1A
	v_dot2_f32_bf16 v4, v27, v39, v4                           // 00000072E304: CC1A4004 1C124F1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000072E30C: BF870091
	v_dot2_f32_bf16 v4, v28, v40, v4                           // 00000072E310: CC1A4004 1C12511C
	v_add_f32_e32 v16, v16, v4                                 // 00000072E318: 06200910
	v_mov_b32_e32 v4, v0                                       // 00000072E31C: 7E080300
	s_and_not1_b32 exec_lo, exec_lo, s17                       // 00000072E320: 917E117E
	s_cbranch_execz 29                                         // 00000072E324: BFA5001D <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi5ELi32ELi1ELb1EEEvPKhPKtPvll+0x89c>
	v_add_nc_u32_e32 v23, 32, v23                              // 00000072E328: 4A2E2EA0
	v_add_nc_u32_e32 v24, 0x200, v11                           // 00000072E32C: 4A3016FF 00000200
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000072E334: BF8704A2
	.long 0xd4430000                                           // 00000072E338: D4430000
	v_cndmask_b32_e32 v1, s2, v23, vcc_lo                      // 00000072E33C: 02022E02
	s_and_saveexec_b32 s1, s0                                  // 00000072E340: BE812000
	s_xor_b32 s1, exec_lo, s1                                  // 00000072E344: 8D01017E
	v_add_nc_u32_e32 v24, 0x200, v11                           // 00000072E348: 4A3016FF 00000200
	s_or_saveexec_b32 s10, s1                                  // 00000072E350: BE8A2201
	s_waitcnt vmcnt(0)                                         // 00000072E354: BF8903F7
	.long 0x7e103919                                           // 00000072E358: 7E103919
	v_dual_mov_b32 v0, v4 :: v_dual_mov_b32 v1, v5             // 00000072E35C: CA100104 00000105
	v_dual_mov_b32 v2, v6 :: v_dual_mov_b32 v3, v7             // 00000072E364: CA100106 02020107
	s_xor_b32 exec_lo, exec_lo, s10                            // 00000072E36C: 8D7E0A7E
	s_cbranch_execz 65107                                      // 00000072E370: BFA5FE53 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi5ELi32ELi1ELb1EEEvPKhPKtPvll+0x1c0>
	.long 0xd7000100                                           // 00000072E374: D7000100
	v_cndmask_b32_e32 v1, v17, v24, vcc_lo                     // 00000072E378: 02023111
	s_delay_alu instid0(VALU_DEP_1)                            // 00000072E37C: BF870001
	v_add_co_ci_u32_e64 v1, null, 0, v18, s1                   // 00000072E380: D5207C01 00062480
	global_load_b128 v[0:3], v[0:1], off                       // 00000072E388: DC5E0000 007C0000
	global_load_d16_b16 v8, v[13:14], off                      // 00000072E390: DC820000 087C000D
	s_branch 65097                                             // 00000072E398: BFA0FE49 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi5ELi32ELi1ELb1EEEvPKhPKtPvll+0x1c0>
	s_or_b32 exec_lo, exec_lo, s17                             // 00000072E39C: 8C7E117E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000072E3A0: BF8700A9
	s_or_b32 exec_lo, exec_lo, s3                              // 00000072E3A4: 8C7E037E
	.long 0xd71f0000                                           // 00000072E3A8: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 00000072E3AC: 020100C1
	v_xor_b32_e32 v1, 16, v0                                   // 00000072E3B0: 3A020090
	s_waitcnt vmcnt(1)                                         // 00000072E3B4: BF8907F7
	v_xor_b32_e32 v6, 8, v0                                    // 00000072E3B8: 3A0C0088
	v_xor_b32_e32 v13, 4, v0                                   // 00000072E3BC: 3A1A0084
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000072E3C0: BF870093
	.long 0xd44c0000                                           // 00000072E3C4: D44C0000
	v_cndmask_b32_e32 v1, 32, v1, vcc_lo                       // 00000072E3C8: 020202A0
	v_cndmask_b32_e64 v1, v0, v1, s0                           // 00000072E3CC: D5010001 00020300
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000072E3D4: BF870114
	.long 0xd44c0000                                           // 00000072E3D8: D44C0000
	v_cndmask_b32_e32 v1, 32, v6, vcc_lo                       // 00000072E3DC: 02020CA0
	v_lshlrev_b32_e32 v1, 2, v1                                // 00000072E3E0: 30020282
	s_delay_alu instid0(VALU_DEP_2)                            // 00000072E3E4: BF870002
	v_cndmask_b32_e64 v6, v0, v6, s0                           // 00000072E3E8: D5010006 00020D00
	.long 0xd44c0000                                           // 00000072E3F0: D44C0000
	v_cndmask_b32_e32 v1, 32, v13, vcc_lo                      // 00000072E3F4: 02021AA0
	ds_bpermute_b32 v2, v1, v22                                // 00000072E3F8: DACC0000 02001601
	v_cndmask_b32_e64 v13, v0, v13, s0                         // 00000072E400: D501000D 00021B00
	s_waitcnt lgkmcnt(0)                                       // 00000072E408: BF89FC07
	v_add_f32_e32 v2, v22, v2                                  // 00000072E40C: 06040516
	ds_bpermute_b32 v3, v1, v21                                // 00000072E410: DACC0000 03001501
	ds_bpermute_b32 v4, v1, v20                                // 00000072E418: DACC0000 04001401
	ds_bpermute_b32 v5, v1, v19                                // 00000072E420: DACC0000 05001301
	ds_bpermute_b32 v1, v1, v16                                // 00000072E428: DACC0000 01001001
	s_waitcnt lgkmcnt(3)                                       // 00000072E430: BF89FC37
	v_dual_add_f32 v3, v21, v3 :: v_dual_lshlrev_b32 v6, 2, v6 // 00000072E434: C9220715 03060C82
	ds_bpermute_b32 v7, v6, v2                                 // 00000072E43C: DACC0000 07000206
	s_waitcnt lgkmcnt(2)                                       // 00000072E444: BF89FC27
	v_dual_add_f32 v4, v20, v4 :: v_dual_add_f32 v5, v19, v5   // 00000072E448: C9080914 04040B13
	s_waitcnt lgkmcnt(1)                                       // 00000072E450: BF89FC17
	v_add_f32_e32 v1, v16, v1                                  // 00000072E454: 06020310
	ds_bpermute_b32 v8, v6, v3                                 // 00000072E458: DACC0000 08000306
	ds_bpermute_b32 v11, v6, v4                                // 00000072E460: DACC0000 0B000406
	ds_bpermute_b32 v12, v6, v5                                // 00000072E468: DACC0000 0C000506
	s_waitcnt lgkmcnt(3)                                       // 00000072E470: BF89FC37
	v_dual_add_f32 v2, v2, v7 :: v_dual_lshlrev_b32 v13, 2, v13// 00000072E474: C9220F02 020C1A82
	ds_bpermute_b32 v6, v6, v1                                 // 00000072E47C: DACC0000 06000106
	s_waitcnt lgkmcnt(0)                                       // 00000072E484: BF89FC07
	v_dual_add_f32 v4, v4, v11 :: v_dual_add_f32 v1, v1, v6    // 00000072E488: C9081704 04000D01
	ds_bpermute_b32 v6, v13, v2                                // 00000072E490: DACC0000 0600020D
	v_add_f32_e32 v3, v3, v8                                   // 00000072E498: 06061103
	ds_bpermute_b32 v8, v13, v4                                // 00000072E49C: DACC0000 0800040D
	s_waitcnt lgkmcnt(1)                                       // 00000072E4A4: BF89FC17
	v_dual_add_f32 v2, v2, v6 :: v_dual_add_f32 v5, v5, v12    // 00000072E4A8: C9080D02 02041905
	ds_bpermute_b32 v7, v13, v3                                // 00000072E4B0: DACC0000 0700030D
	s_waitcnt lgkmcnt(1)                                       // 00000072E4B8: BF89FC17
	v_add_f32_e32 v4, v4, v8                                   // 00000072E4BC: 06081104
	ds_bpermute_b32 v12, v13, v1                               // 00000072E4C0: DACC0000 0C00010D
	ds_bpermute_b32 v11, v13, v5                               // 00000072E4C8: DACC0000 0B00050D
	v_xor_b32_e32 v13, 2, v0                                   // 00000072E4D0: 3A1A0082
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000072E4D4: BF870091
	.long 0xd44c0000                                           // 00000072E4D8: D44C0000
	v_cndmask_b32_e32 v1, 32, v13, vcc_lo                      // 00000072E4DC: 02021AA0
	v_cndmask_b32_e64 v13, v0, v13, s0                         // 00000072E4E0: D501000D 00021B00
	s_waitcnt lgkmcnt(1)                                       // 00000072E4E8: BF89FC17
	s_delay_alu instid0(VALU_DEP_1)                            // 00000072E4EC: BF870001
	v_dual_add_f32 v6, v1, v12 :: v_dual_lshlrev_b32 v13, 2, v13// 00000072E4F0: C9221901 060C1A82
	s_waitcnt lgkmcnt(0)                                       // 00000072E4F8: BF89FC07
	v_add_f32_e32 v5, v5, v11                                  // 00000072E4FC: 060A1705
	ds_bpermute_b32 v8, v13, v4                                // 00000072E500: DACC0000 0800040D
	v_add_f32_e32 v3, v3, v7                                   // 00000072E508: 06060F03
	ds_bpermute_b32 v1, v13, v2                                // 00000072E50C: DACC0000 0100020D
	ds_bpermute_b32 v12, v13, v6                               // 00000072E514: DACC0000 0C00060D
	ds_bpermute_b32 v11, v13, v5                               // 00000072E51C: DACC0000 0B00050D
	ds_bpermute_b32 v7, v13, v3                                // 00000072E524: DACC0000 0700030D
	v_xor_b32_e32 v13, 1, v0                                   // 00000072E52C: 3A1A0081
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000072E530: BF870091
	.long 0xd44c0000                                           // 00000072E534: D44C0000
	v_cndmask_b32_e32 v1, 32, v13, vcc_lo                      // 00000072E538: 02021AA0
	v_cndmask_b32_e64 v0, v0, v13, s0                          // 00000072E53C: D5010000 00021B00
	.long 0xd44a0000                                           // 00000072E544: D44A0000
	v_cndmask_b32_e32 v1, 0, v15, vcc_lo                       // 00000072E548: 02021E80
	s_waitcnt lgkmcnt(3)                                       // 00000072E54C: BF89FC37
	s_delay_alu instid0(VALU_DEP_2)                            // 00000072E550: BF870002
	v_dual_add_f32 v0, v2, v1 :: v_dual_lshlrev_b32 v13, 2, v0 // 00000072E554: C9220302 000C0082
	s_waitcnt lgkmcnt(1)                                       // 00000072E55C: BF89FC17
	v_dual_add_f32 v2, v4, v8 :: v_dual_add_f32 v5, v5, v11    // 00000072E560: C9081104 02041705
	s_waitcnt lgkmcnt(0)                                       // 00000072E568: BF89FC07
	v_add_f32_e32 v1, v3, v7                                   // 00000072E56C: 06020F03
	v_add_f32_e32 v7, v6, v12                                  // 00000072E570: 060E1906
	ds_bpermute_b32 v3, v13, v0                                // 00000072E574: DACC0000 0300000D
	ds_bpermute_b32 v6, v13, v2                                // 00000072E57C: DACC0000 0600020D
	ds_bpermute_b32 v8, v13, v5                                // 00000072E584: DACC0000 0800050D
	ds_bpermute_b32 v4, v13, v1                                // 00000072E58C: DACC0000 0400010D
	ds_bpermute_b32 v11, v13, v7                               // 00000072E594: DACC0000 0B00070D
	s_and_b32 s0, s0, vcc_lo                                   // 00000072E59C: 8B006A00
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000072E5A0: BF870009
	s_and_saveexec_b32 s1, s0                                  // 00000072E5A4: BE812000
	s_cbranch_execz 45                                         // 00000072E5A8: BFA5002D <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi5ELi32ELi1ELb1EEEvPKhPKtPvll+0xb60>
	.long 0xd73c0009                                           // 00000072E5AC: D73C0009
	v_cndmask_b32_e32 v1, 2, v9, vcc_lo                        // 00000072E5B0: 02021282
	s_waitcnt lgkmcnt(0)                                       // 00000072E5B4: BF89FC07
	v_dual_add_f32 v11, v7, v11 :: v_dual_add_f32 v12, v5, v8  // 00000072E5B8: C9081707 0B0C1105
	s_lshl_b64 s[0:1], s[12:13], 2                             // 00000072E5C0: 8480820C
	v_dual_add_f32 v13, v2, v6 :: v_dual_add_f32 v14, v1, v4   // 00000072E5C4: C9080D02 0D0E0901
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000072E5CC: BF870093
	.long 0xd7006a07                                           // 00000072E5D0: D7006A07
	v_cndmask_b32_e32 v1, s8, v9, vcc_lo                       // 00000072E5D4: 02021208
	v_add_co_ci_u32_e64 v8, null, s9, v10, vcc_lo              // 00000072E5D8: D5207C08 01AA1409
	v_add_f32_e32 v15, v0, v3                                  // 00000072E5E0: 061E0700
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000072E5E4: BF870193
	.long 0xd7006a03                                           // 00000072E5E8: D7006A03
	v_cndmask_b32_e32 v0, v7, v0, vcc_lo                       // 00000072E5EC: 02000107
	v_mad_u64_u32 v[0:1], null, s12, 12, v[7:8]                // 00000072E5F0: D6FE7C00 041D180C
	v_add_co_ci_u32_e64 v4, null, s1, v8, vcc_lo               // 00000072E5F8: D5207C04 01AA1001
	s_lshl_b64 s[0:1], s[12:13], 3                             // 00000072E600: 8480830C
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000072E604: BF870099
	.long 0xd7006a05                                           // 00000072E608: D7006A05
	v_cndmask_b32_e32 v0, v7, v0, vcc_lo                       // 00000072E60C: 02000107
	v_add_co_ci_u32_e64 v6, null, s1, v8, vcc_lo               // 00000072E610: D5207C06 01AA1001
	v_mad_u64_u32 v[1:2], null, s13, 12, v[1:2]                // 00000072E618: D6FE7C01 0405180D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000072E620: BF870093
	.long 0xd7006a09                                           // 00000072E624: D7006A09
	v_cndmask_b32_e32 v0, v5, v0, vcc_lo                       // 00000072E628: 02000105
	v_add_co_ci_u32_e64 v10, null, s1, v6, vcc_lo              // 00000072E62C: D5207C0A 01AA0C01
	s_clause 0x4                                               // 00000072E634: BF850004
	global_store_b32 v[7:8], v15, off                          // 00000072E638: DC6A0000 007C0F07
	global_store_b32 v[3:4], v14, off                          // 00000072E640: DC6A0000 007C0E03
	global_store_b32 v[5:6], v13, off                          // 00000072E648: DC6A0000 007C0D05
	global_store_b32 v[0:1], v12, off                          // 00000072E650: DC6A0000 007C0C00
	global_store_b32 v[9:10], v11, off                         // 00000072E658: DC6A0000 007C0B09
	s_endpgm                                                   // 00000072E660: BFB00000
		...

