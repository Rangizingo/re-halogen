0000000000f82f00 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi1ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi1ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 000000F82F00: F4100100 F8000000
	v_and_b32_e32 v1, 15, v0                                   // 000000F82F08: 3602008F
	v_lshrrev_b32_e32 v2, 2, v0                                // 000000F82F0C: 32040082
	s_ashr_i32 s3, s2, 31                                      // 000000F82F10: 86039F02
	v_lshrrev_b32_e32 v3, 5, v0                                // 000000F82F14: 32060085
	s_lshl_b64 s[0:1], s[2:3], 3                               // 000000F82F18: 84808302
	v_lshlrev_b32_e32 v1, 2, v1                                // 000000F82F1C: 30020282
	v_dual_mov_b32 v17, s1 :: v_dual_and_b32 v2, 60, v2        // 000000F82F20: CA240001 110204BC
	s_delay_alu instid0(VALU_DEP_3)                            // 000000F82F28: BF870003
	v_or_b32_e32 v16, s0, v3                                   // 000000F82F2C: 38200600
	.long 0x7f063880                                           // 000000F82F30: 7F063880
	v_and_b32_e32 v23, 31, v0                                  // 000000F82F34: 362E009F
	v_lshlrev_b32_e32 v0, 2, v0                                // 000000F82F38: 30000082
	s_waitcnt lgkmcnt(0)                                       // 000000F82F3C: BF89FC07
	s_clause 0x1                                               // 000000F82F40: BF850001
	global_load_b32 v1, v1, s[4:5]                             // 000000F82F44: DC520000 01040001
	global_load_b32 v2, v2, s[4:5]                             // 000000F82F4C: DC520000 02040002
	.long 0xd4540000                                           // 000000F82F54: D4540000
	v_cndmask_b32_e32 v1, s12, v16, vcc_lo                     // 000000F82F58: 0202200C
	s_add_u32 s20, s4, s16                                     // 000000F82F5C: 80141004
	s_addc_u32 s21, s5, s17                                    // 000000F82F60: 82151105
	s_ashr_i32 s2, s11, 31                                     // 000000F82F64: 86029F0B
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 000000F82F68: BF870159
	s_lshr_b32 s2, s2, 27                                      // 000000F82F6C: 85029B02
	v_cndmask_b32_e64 v8, 0, v16, s0                           // 000000F82F70: D5010008 00022080
	v_cndmask_b32_e64 v9, 0, s1, s0                            // 000000F82F78: D5010009 00000280
	s_add_u32 s2, s10, s2                                      // 000000F82F80: 8002020A
	s_addc_u32 s3, s11, 0                                      // 000000F82F84: 8203800B
	.long 0xd72c0004                                           // 000000F82F88: D72C0004
	v_cndmask_b32_e32 v1, s19, v8, vcc_lo                      // 000000F82F8C: 02021013
	v_mad_u64_u32 v[12:13], null, s18, v8, 0                   // 000000F82F90: D6FE7C0C 02021012
	s_lshr_b64 s[12:13], s[2:3], 5                             // 000000F82F98: 858C8502
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000F82F9C: BF870009
	s_cmpk_lt_i32 s12, 0x101                                   // 000000F82FA0: B38C0101
	.long 0xd4440002                                           // 000000F82FA4: D4440002
	v_cndmask_b32_e32 v1, s12, v23, vcc_lo                     // 000000F82FA8: 02022E0C
	s_cselect_b32 s1, -1, 0                                    // 000000F82FAC: 980180C1
	s_cmpk_gt_i32 s12, 0x100                                   // 000000F82FB0: B28C0100
	.long 0xd700030e                                           // 000000F82FB4: D700030E
	v_cndmask_b32_e32 v1, s20, v12, vcc_lo                     // 000000F82FB8: 02021814
	s_cselect_b32 s13, -1, 0                                   // 000000F82FBC: 980D80C1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 000000F82FC0: BF870159
	s_and_b32 vcc_lo, exec_lo, s13                             // 000000F82FC4: 8B6A0D7E
	s_waitcnt vmcnt(1)                                         // 000000F82FC8: BF8907F7
	v_bfe_u32 v5, v1, 16, 1                                    // 000000F82FCC: D6100005 02052101
	s_waitcnt vmcnt(0)                                         // 000000F82FD4: BF8903F7
	v_bfe_u32 v6, v2, 16, 1                                    // 000000F82FD8: D6100006 02052102
	v_add3_u32 v1, v1, v5, 0x7fff                              // 000000F82FE0: D6550001 03FE0B01 00007FFF
	.long 0xd72c0005                                           // 000000F82FEC: D72C0005
	v_cndmask_b32_e32 v1, s18, v9, vcc_lo                      // 000000F82FF0: 02021212
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000F82FF4: BF870193
	v_add3_u32 v2, v2, v6, 0x7fff                              // 000000F82FF8: D6550002 03FE0D02 00007FFF
	.long 0x7e063981                                           // 000000F83004: 7E063981
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000F83008: BF870113
	v_add3_u32 v13, v13, v5, v4                                // 000000F8300C: D655000D 04120B0D
	v_and_or_b32 v1, 0xffff0000, v2, v3                        // 000000F83014: D6570001 040E04FF FFFF0000
	s_delay_alu instid0(VALU_DEP_2)                            // 000000F83020: BF870002
	v_add_co_ci_u32_e64 v15, null, s21, v13, s3                // 000000F83024: D5207C0F 000E1A15
	ds_store_b32 v0, v1                                        // 000000F8302C: D8340000 00000100
	s_waitcnt lgkmcnt(0)                                       // 000000F83034: BF89FC07
	s_barrier                                                  // 000000F83038: BFBD0000
	buffer_gl0_inv                                             // 000000F8303C: E0AC0000 00000000
	s_cbranch_vccnz 146                                        // 000000F83044: BFA40092 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi1ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x390>
	v_dual_mov_b32 v1, 0 :: v_dual_mov_b32 v0, 0               // 000000F83048: CA100080 01000080
	s_and_saveexec_b32 s3, s2                                  // 000000F83050: BE832002
	s_cbranch_execz 10                                         // 000000F83054: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi1ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x180>
	v_lshlrev_b32_e32 v0, 1, v23                               // 000000F83058: 30002E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F8305C: BF870091
	.long 0xd7006a02                                           // 000000F83060: D7006A02
	v_cndmask_b32_e32 v1, v14, v0, vcc_lo                      // 000000F83064: 0202010E
	v_add_co_ci_u32_e64 v3, null, 0, v15, vcc_lo               // 000000F83068: D5207C03 01AA1E80
	global_load_d16_b16 v0, v[2:3], off                        // 000000F83070: DC820000 007C0002
	s_waitcnt vmcnt(0)                                         // 000000F83078: BF8903F7
	v_cvt_f32_f16_e32 v0, v0                                   // 000000F8307C: 7E001700
	s_or_b32 exec_lo, exec_lo, s3                              // 000000F83080: 8C7E037E
	v_or_b32_e32 v2, 32, v23                                   // 000000F83084: 38042EA0
	s_mov_b32 s2, exec_lo                                      // 000000F83088: BE82007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000F8308C: BF870001
	.long 0xd4c4007e                                           // 000000F83090: D4C4007E
	v_cndmask_b32_e32 v1, s12, v2, vcc_lo                      // 000000F83094: 0202040C
	s_cbranch_execz 10                                         // 000000F83098: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi1ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x1c4>
	v_lshlrev_b32_e32 v1, 1, v2                                // 000000F8309C: 30020481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F830A0: BF870091
	.long 0xd7006a01                                           // 000000F830A4: D7006A01
	v_cndmask_b32_e32 v1, v14, v1, vcc_lo                      // 000000F830A8: 0202030E
	v_add_co_ci_u32_e64 v2, null, 0, v15, vcc_lo               // 000000F830AC: D5207C02 01AA1E80
	global_load_d16_b16 v1, v[1:2], off                        // 000000F830B4: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 000000F830BC: BF8903F7
	v_cvt_f32_f16_e32 v1, v1                                   // 000000F830C0: 7E021701
	s_or_b32 exec_lo, exec_lo, s2                              // 000000F830C4: 8C7E027E
	v_or_b32_e32 v4, 64, v23                                   // 000000F830C8: 38082EC0
	v_dual_mov_b32 v3, 0 :: v_dual_mov_b32 v2, 0               // 000000F830CC: CA100080 03020080
	s_mov_b32 s2, exec_lo                                      // 000000F830D4: BE82007E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000F830D8: BF870002
	.long 0xd4c4007e                                           // 000000F830DC: D4C4007E
	v_cndmask_b32_e32 v1, s12, v4, vcc_lo                      // 000000F830E0: 0202080C
	s_cbranch_execz 10                                         // 000000F830E4: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi1ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x210>
	v_lshlrev_b32_e32 v2, 1, v4                                // 000000F830E8: 30040881
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F830EC: BF870091
	.long 0xd7006a04                                           // 000000F830F0: D7006A04
	v_cndmask_b32_e32 v1, v14, v2, vcc_lo                      // 000000F830F4: 0202050E
	v_add_co_ci_u32_e64 v5, null, 0, v15, vcc_lo               // 000000F830F8: D5207C05 01AA1E80
	global_load_d16_b16 v2, v[4:5], off                        // 000000F83100: DC820000 027C0004
	s_waitcnt vmcnt(0)                                         // 000000F83108: BF8903F7
	v_cvt_f32_f16_e32 v2, v2                                   // 000000F8310C: 7E041702
	s_or_b32 exec_lo, exec_lo, s2                              // 000000F83110: 8C7E027E
	v_or_b32_e32 v4, 0x60, v23                                 // 000000F83114: 38082EFF 00000060
	s_mov_b32 s2, exec_lo                                      // 000000F8311C: BE82007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000F83120: BF870001
	.long 0xd4c4007e                                           // 000000F83124: D4C4007E
	v_cndmask_b32_e32 v1, s12, v4, vcc_lo                      // 000000F83128: 0202080C
	s_cbranch_execz 10                                         // 000000F8312C: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi1ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x258>
	v_lshlrev_b32_e32 v3, 1, v4                                // 000000F83130: 30060881
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F83134: BF870091
	.long 0xd7006a03                                           // 000000F83138: D7006A03
	v_cndmask_b32_e32 v1, v14, v3, vcc_lo                      // 000000F8313C: 0202070E
	v_add_co_ci_u32_e64 v4, null, 0, v15, vcc_lo               // 000000F83140: D5207C04 01AA1E80
	global_load_d16_b16 v3, v[3:4], off                        // 000000F83148: DC820000 037C0003
	s_waitcnt vmcnt(0)                                         // 000000F83150: BF8903F7
	v_cvt_f32_f16_e32 v3, v3                                   // 000000F83154: 7E061703
	s_or_b32 exec_lo, exec_lo, s2                              // 000000F83158: 8C7E027E
	v_or_b32_e32 v6, 0x80, v23                                 // 000000F8315C: 380C2EFF 00000080
	v_dual_mov_b32 v5, 0 :: v_dual_mov_b32 v4, 0               // 000000F83164: CA100080 05040080
	s_mov_b32 s2, exec_lo                                      // 000000F8316C: BE82007E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000F83170: BF870002
	.long 0xd4c4007e                                           // 000000F83174: D4C4007E
	v_cndmask_b32_e32 v1, s12, v6, vcc_lo                      // 000000F83178: 02020C0C
	s_cbranch_execz 10                                         // 000000F8317C: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi1ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x2a8>
	v_lshlrev_b32_e32 v4, 1, v6                                // 000000F83180: 30080C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F83184: BF870091
	.long 0xd7006a06                                           // 000000F83188: D7006A06
	v_cndmask_b32_e32 v1, v14, v4, vcc_lo                      // 000000F8318C: 0202090E
	v_add_co_ci_u32_e64 v7, null, 0, v15, vcc_lo               // 000000F83190: D5207C07 01AA1E80
	global_load_d16_b16 v4, v[6:7], off                        // 000000F83198: DC820000 047C0006
	s_waitcnt vmcnt(0)                                         // 000000F831A0: BF8903F7
	v_cvt_f32_f16_e32 v4, v4                                   // 000000F831A4: 7E081704
	s_or_b32 exec_lo, exec_lo, s2                              // 000000F831A8: 8C7E027E
	v_or_b32_e32 v6, 0xa0, v23                                 // 000000F831AC: 380C2EFF 000000A0
	s_mov_b32 s2, exec_lo                                      // 000000F831B4: BE82007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000F831B8: BF870001
	.long 0xd4c4007e                                           // 000000F831BC: D4C4007E
	v_cndmask_b32_e32 v1, s12, v6, vcc_lo                      // 000000F831C0: 02020C0C
	s_cbranch_execz 10                                         // 000000F831C4: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi1ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x2f0>
	v_lshlrev_b32_e32 v5, 1, v6                                // 000000F831C8: 300A0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F831CC: BF870091
	.long 0xd7006a05                                           // 000000F831D0: D7006A05
	v_cndmask_b32_e32 v1, v14, v5, vcc_lo                      // 000000F831D4: 02020B0E
	v_add_co_ci_u32_e64 v6, null, 0, v15, vcc_lo               // 000000F831D8: D5207C06 01AA1E80
	global_load_d16_b16 v5, v[5:6], off                        // 000000F831E0: DC820000 057C0005
	s_waitcnt vmcnt(0)                                         // 000000F831E8: BF8903F7
	v_cvt_f32_f16_e32 v5, v5                                   // 000000F831EC: 7E0A1705
	s_or_b32 exec_lo, exec_lo, s2                              // 000000F831F0: 8C7E027E
	v_or_b32_e32 v10, 0xc0, v23                                // 000000F831F4: 38142EFF 000000C0
	v_dual_mov_b32 v7, 0 :: v_dual_mov_b32 v6, 0               // 000000F831FC: CA100080 07060080
	s_mov_b32 s2, exec_lo                                      // 000000F83204: BE82007E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000F83208: BF870002
	.long 0xd4c4007e                                           // 000000F8320C: D4C4007E
	v_cndmask_b32_e32 v1, s12, v10, vcc_lo                     // 000000F83210: 0202140C
	s_cbranch_execz 10                                         // 000000F83214: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi1ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x340>
	v_lshlrev_b32_e32 v6, 1, v10                               // 000000F83218: 300C1481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F8321C: BF870091
	.long 0xd7006a0a                                           // 000000F83220: D7006A0A
	v_cndmask_b32_e32 v1, v14, v6, vcc_lo                      // 000000F83224: 02020D0E
	v_add_co_ci_u32_e64 v11, null, 0, v15, vcc_lo              // 000000F83228: D5207C0B 01AA1E80
	global_load_d16_b16 v6, v[10:11], off                      // 000000F83230: DC820000 067C000A
	s_waitcnt vmcnt(0)                                         // 000000F83238: BF8903F7
	v_cvt_f32_f16_e32 v6, v6                                   // 000000F8323C: 7E0C1706
	s_or_b32 exec_lo, exec_lo, s2                              // 000000F83240: 8C7E027E
	v_or_b32_e32 v10, 0xe0, v23                                // 000000F83244: 38142EFF 000000E0
	s_mov_b32 s2, exec_lo                                      // 000000F8324C: BE82007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000F83250: BF870001
	.long 0xd4c4007e                                           // 000000F83254: D4C4007E
	v_cndmask_b32_e32 v1, s12, v10, vcc_lo                     // 000000F83258: 0202140C
	s_cbranch_execz 10                                         // 000000F8325C: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi1ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x388>
	v_lshlrev_b32_e32 v7, 1, v10                               // 000000F83260: 300E1481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F83264: BF870091
	.long 0xd7006a0a                                           // 000000F83268: D7006A0A
	v_cndmask_b32_e32 v1, v14, v7, vcc_lo                      // 000000F8326C: 02020F0E
	v_add_co_ci_u32_e64 v11, null, 0, v15, vcc_lo              // 000000F83270: D5207C0B 01AA1E80
	global_load_d16_b16 v7, v[10:11], off                      // 000000F83278: DC820000 077C000A
	s_waitcnt vmcnt(0)                                         // 000000F83280: BF8903F7
	v_cvt_f32_f16_e32 v7, v7                                   // 000000F83284: 7E0E1707
	s_or_b32 exec_lo, exec_lo, s2                              // 000000F83288: 8C7E027E
	s_branch 9                                                 // 000000F8328C: BFA00009 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi1ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x3b4>
	v_mov_b32_e32 v0, 0                                        // 000000F83290: 7E000280
	s_delay_alu instid0(VALU_DEP_1)                            // 000000F83294: BF870001
	v_mov_b32_e32 v1, v0                                       // 000000F83298: 7E020300
	v_mov_b32_e32 v2, v0                                       // 000000F8329C: 7E040300
	v_mov_b32_e32 v3, v0                                       // 000000F832A0: 7E060300
	v_mov_b32_e32 v4, v0                                       // 000000F832A4: 7E080300
	v_mov_b32_e32 v5, v0                                       // 000000F832A8: 7E0A0300
	v_mov_b32_e32 v6, v0                                       // 000000F832AC: 7E0C0300
	v_mov_b32_e32 v7, v0                                       // 000000F832B0: 7E0E0300
	s_add_u32 s2, s4, s14                                      // 000000F832B4: 80020E04
	s_addc_u32 s3, s5, s15                                     // 000000F832B8: 82030F05
	s_lshr_b32 s14, s11, 31                                    // 000000F832BC: 850E9F0B
	v_mov_b32_e32 v26, 0                                       // 000000F832C0: 7E340280
	s_add_u32 s10, s10, s14                                    // 000000F832C4: 800A0E0A
	s_addc_u32 s11, s11, 0                                     // 000000F832C8: 820B800B
	v_cndmask_b32_e64 v24, 0, 1, s13                           // 000000F832CC: D5010018 00350280
	s_ashr_i64 s[10:11], s[10:11], 1                           // 000000F832D4: 868A810A
	v_mov_b32_e32 v27, 0                                       // 000000F832D8: 7E360280
	v_mad_u64_u32 v[18:19], null, v8, s10, s[2:3]              // 000000F832DC: D6FE7C12 00081508
	.long 0xd72c000b                                           // 000000F832E4: D72C000B
	v_cndmask_b32_e32 v0, v8, v11, vcc_lo                      // 000000F832E8: 02001708
	.long 0xd72c0014                                           // 000000F832EC: D72C0014
	v_cndmask_b32_e32 v0, v9, v10, vcc_lo                      // 000000F832F0: 02001509
	.long 0xd4440002                                           // 000000F832F4: D4440002
	v_cndmask_b32_e32 v1, s12, v23, vcc_lo                     // 000000F832F8: 02022E0C
	v_dual_mov_b32 v8, 0 :: v_dual_mov_b32 v9, 0               // 000000F832FC: CA100080 08080080
	v_mov_b32_e32 v10, 0                                       // 000000F83304: 7E140280
	s_delay_alu instid0(VALU_DEP_4)                            // 000000F83308: BF870004
	v_add3_u32 v25, v20, v19, v11                              // 000000F8330C: D6550019 042E2714
	v_mov_b32_e32 v11, 0                                       // 000000F83314: 7E160280
	s_and_saveexec_b32 s3, s2                                  // 000000F83318: BE832002
	s_cbranch_execz 21                                         // 000000F8331C: BFA50015 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi1ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x474>
	v_dual_mov_b32 v27, 0 :: v_dual_lshlrev_b32 v8, 4, v23     // 000000F83320: CA220080 1B082E84
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F83328: BF870091
	.long 0xd7006a08                                           // 000000F8332C: D7006A08
	v_cndmask_b32_e32 v1, v18, v8, vcc_lo                      // 000000F83330: 02021112
	v_add_co_ci_u32_e64 v9, null, 0, v25, vcc_lo               // 000000F83334: D5207C09 01AA3280
	s_and_not1_b32 vcc_lo, exec_lo, s13                        // 000000F8333C: 916A0D7E
	global_load_b128 v[8:11], v[8:9], off                      // 000000F83340: DC5E0000 087C0008
	s_cbranch_vccnz 10                                         // 000000F83348: BFA4000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi1ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x474>
	v_lshlrev_b32_e32 v19, 1, v23                              // 000000F8334C: 30262E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F83350: BF870091
	.long 0xd7006a0e                                           // 000000F83354: D7006A0E
	v_cndmask_b32_e32 v1, v14, v19, vcc_lo                     // 000000F83358: 0202270E
	v_add_co_ci_u32_e64 v15, null, 0, v15, vcc_lo              // 000000F8335C: D5207C0F 01AA1E80
	global_load_d16_b16 v14, v[14:15], off                     // 000000F83364: DC820000 0E7C000E
	s_waitcnt vmcnt(0)                                         // 000000F8336C: BF8903F7
	v_cvt_f32_f16_e32 v27, v14                                 // 000000F83370: 7E36170E
	s_or_b32 exec_lo, exec_lo, s3                              // 000000F83374: 8C7E037E
	s_and_saveexec_b32 s3, s2                                  // 000000F83378: BE832002
	s_cbranch_execz 256                                        // 000000F8337C: BFA50100 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi1ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x880>
	v_dual_mov_b32 v29, v23 :: v_dual_lshlrev_b32 v14, 1, v23  // 000000F83380: CA220117 1D0E2E81
	.long 0xd7006a0c                                           // 000000F83388: D7006A0C
	v_cndmask_b32_e32 v1, s16, v12, vcc_lo                     // 000000F8338C: 02021810
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000F83390: BF8701A1
	v_add_co_ci_u32_e64 v13, null, s17, v13, vcc_lo            // 000000F83394: D5207C0D 01AA1A11
	v_dual_mov_b32 v20, 0 :: v_dual_lshlrev_b32 v19, 5, v23    // 000000F8339C: CA220080 14122E85
	.long 0xd7006a0c                                           // 000000F833A4: D7006A0C
	v_cndmask_b32_e32 v1, v12, v14, vcc_lo                     // 000000F833A8: 02021D0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000F833AC: BF8701A1
	v_add_co_ci_u32_e64 v13, null, 0, v13, vcc_lo              // 000000F833B0: D5207C0D 01AA1A80
	v_lshl_or_b32 v28, v23, 4, 0x200                           // 000000F833B8: D656001C 03FD0917 00000200
	.long 0xd7006a0c                                           // 000000F833C4: D7006A0C
	v_cndmask_b32_e32 v1, s4, v12, vcc_lo                      // 000000F833C8: 02021804
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000F833CC: BF8701A1
	v_add_co_ci_u32_e64 v13, null, s5, v13, vcc_lo             // 000000F833D0: D5207C0D 01AA1A05
	v_mov_b32_e32 v26, v20                                     // 000000F833D8: 7E340314
	.long 0xd7006a15                                           // 000000F833DC: D7006A15
	v_cndmask_b32_e32 v0, v12, v192, vcc_lo                    // 000000F833E0: 0201810C
	s_delay_alu instid0(VALU_DEP_1)                            // 000000F833E4: BF870001
	v_add_co_ci_u32_e64 v22, null, 0, v13, vcc_lo              // 000000F833E8: D5207C16 01AA1A80
	v_mov_b32_e32 v30, v27                                     // 000000F833F0: 7E3C031B
	s_mov_b32 s4, 0                                            // 000000F833F4: BE840080
	s_branch 196                                               // 000000F833F8: BFA000C4 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi1ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x80c>
	s_or_b32 exec_lo, exec_lo, s5                              // 000000F833FC: 8C7E057E
	.long 0xd73c001f                                           // 000000F83400: D73C001F
	v_cndmask_b32_e32 v1, 1, v19, vcc_lo                       // 000000F83404: 02022681
	v_and_b32_e32 v47, 0xff, v8                                // 000000F83408: 365E10FF 000000FF
	v_lshrrev_b32_e32 v48, 6, v8                               // 000000F83410: 32601086
	v_lshrrev_b32_e32 v49, 14, v8                              // 000000F83414: 3262108E
	v_lshrrev_b32_e32 v8, 22, v8                               // 000000F83418: 32101096
	v_and_b32_e32 v50, 0xff, v9                                // 000000F8341C: 366412FF 000000FF
	.long 0xd7006a2b                                           // 000000F83424: D7006A2B
	v_cndmask_b32_e32 v1, s6, v31, vcc_lo                      // 000000F83428: 02023E06
	s_delay_alu instid0(VALU_DEP_1)                            // 000000F8342C: BF870001
	v_add_co_ci_u32_e64 v44, null, s7, v32, vcc_lo             // 000000F83430: D5207C2C 01AA4007
	v_lshlrev_b32_e32 v47, 2, v47                              // 000000F83438: 305E5E82
	v_and_b32_e32 v48, 0x3fc, v48                              // 000000F8343C: 366060FF 000003FC
	v_and_b32_e32 v49, 0x3fc, v49                              // 000000F83444: 366262FF 000003FC
	s_clause 0x3                                               // 000000F8344C: BF850003
	global_load_b128 v[31:34], v[43:44], off                   // 000000F83450: DC5E0000 1F7C002B
	global_load_b128 v[35:38], v[43:44], off offset:16         // 000000F83458: DC5E0010 237C002B
	global_load_b128 v[39:42], v[43:44], off offset:32         // 000000F83460: DC5E0020 277C002B
	global_load_b128 v[43:46], v[43:44], off offset:48         // 000000F83468: DC5E0030 2B7C002B
	v_lshrrev_b32_e32 v51, 6, v9                               // 000000F83470: 32661286
	ds_load_b32 v47, v47                                       // 000000F83474: D8D80000 2F00002F
	ds_load_b32 v48, v48                                       // 000000F8347C: D8D80000 30000030
	ds_load_b32 v49, v49                                       // 000000F83484: D8D80000 31000031
	v_lshrrev_b32_e32 v52, 14, v9                              // 000000F8348C: 3268128E
	v_lshrrev_b32_e32 v9, 22, v9                               // 000000F83490: 32121296
	v_and_b32_e32 v8, 0x3fc, v8                                // 000000F83494: 361010FF 000003FC
	v_lshlrev_b32_e32 v50, 2, v50                              // 000000F8349C: 30646482
	v_and_b32_e32 v51, 0x3fc, v51                              // 000000F834A0: 366666FF 000003FC
	v_and_b32_e32 v52, 0x3fc, v52                              // 000000F834A8: 366868FF 000003FC
	v_and_b32_e32 v9, 0x3fc, v9                                // 000000F834B0: 361212FF 000003FC
	ds_load_b32 v8, v8                                         // 000000F834B8: D8D80000 08000008
	ds_load_b32 v50, v50                                       // 000000F834C0: D8D80000 32000032
	ds_load_b32 v51, v51                                       // 000000F834C8: D8D80000 33000033
	ds_load_b32 v52, v52                                       // 000000F834D0: D8D80000 34000034
	ds_load_b32 v9, v9                                         // 000000F834D8: D8D80000 09000009
	.long 0xd7006a15                                           // 000000F834E0: D7006A15
	v_cndmask_b32_e32 v0, v21, v192, vcc_lo                    // 000000F834E4: 02018115
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000F834E8: BF8704A1
	v_add_co_ci_u32_e64 v22, null, 0, v22, vcc_lo              // 000000F834EC: D5207C16 01AA2C80
	s_and_b32 s2, exec_lo, s2                                  // 000000F834F4: 8B02027E
	s_or_b32 s4, s2, s4                                        // 000000F834F8: 8C040402
	s_waitcnt vmcnt(3) lgkmcnt(7)                              // 000000F834FC: BF890C77
	v_dot2_f32_bf16 v31, v31, v47, 0                           // 000000F83500: CC1A401F 1A025F1F
	v_lshrrev_b32_e32 v47, 14, v10                             // 000000F83508: 325E148E
	s_waitcnt lgkmcnt(6)                                       // 000000F8350C: BF89FC67
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000F83510: BF870132
	v_dot2_f32_bf16 v31, v32, v48, v31                         // 000000F83514: CC1A401F 1C7E6120
	v_and_b32_e32 v32, 0xff, v10                               // 000000F8351C: 364014FF 000000FF
	s_waitcnt lgkmcnt(5)                                       // 000000F83524: BF89FC57
	v_dot2_f32_bf16 v31, v33, v49, v31                         // 000000F83528: CC1A401F 1C7E6321
	v_lshrrev_b32_e32 v33, 6, v10                              // 000000F83530: 32421486
	v_lshrrev_b32_e32 v10, 22, v10                             // 000000F83534: 32141496
	s_waitcnt lgkmcnt(4)                                       // 000000F83538: BF89FC47
	s_delay_alu instid0(VALU_DEP_3)                            // 000000F8353C: BF870003
	v_dot2_f32_bf16 v8, v34, v8, v31                           // 000000F83540: CC1A4008 1C7E1122
	v_lshlrev_b32_e32 v31, 2, v32                              // 000000F83548: 303E4082
	v_and_b32_e32 v33, 0x3fc, v33                              // 000000F8354C: 364242FF 000003FC
	v_and_b32_e32 v32, 0xff, v11                               // 000000F83554: 364016FF 000000FF
	v_lshrrev_b32_e32 v34, 6, v11                              // 000000F8355C: 32441686
	s_waitcnt vmcnt(2) lgkmcnt(3)                              // 000000F83560: BF890837
	v_dot2_f32_bf16 v8, v35, v50, v8                           // 000000F83564: CC1A4008 1C226523
	ds_load_b32 v31, v31                                       // 000000F8356C: D8D80000 1F00001F
	ds_load_b32 v33, v33                                       // 000000F83574: D8D80000 21000021
	v_lshrrev_b32_e32 v35, 14, v11                             // 000000F8357C: 3246168E
	v_lshrrev_b32_e32 v11, 22, v11                             // 000000F83580: 32161696
	s_waitcnt lgkmcnt(4)                                       // 000000F83584: BF89FC47
	v_dot2_f32_bf16 v8, v36, v51, v8                           // 000000F83588: CC1A4008 1C226724
	v_lshlrev_b32_e32 v32, 2, v32                              // 000000F83590: 30404082
	v_and_b32_e32 v34, 0x3fc, v34                              // 000000F83594: 364444FF 000003FC
	v_and_b32_e32 v35, 0x3fc, v35                              // 000000F8359C: 364646FF 000003FC
	s_waitcnt lgkmcnt(3)                                       // 000000F835A4: BF89FC37
	v_dot2_f32_bf16 v8, v37, v52, v8                           // 000000F835A8: CC1A4008 1C226925
	v_cndmask_b32_e64 v37, v6, v7, s1                          // 000000F835B0: D5010025 00060F06
	v_and_b32_e32 v47, 0x3fc, v47                              // 000000F835B8: 365E5EFF 000003FC
	s_waitcnt lgkmcnt(2)                                       // 000000F835C0: BF89FC27
	s_delay_alu instid0(VALU_DEP_3)                            // 000000F835C4: BF870003
	v_dot2_f32_bf16 v8, v38, v9, v8                            // 000000F835C8: CC1A4008 1C221326
	ds_load_b32 v36, v47                                       // 000000F835D0: D8D80000 2400002F
	s_waitcnt vmcnt(1) lgkmcnt(2)                              // 000000F835D8: BF890427
	v_dot2_f32_bf16 v8, v39, v31, v8                           // 000000F835DC: CC1A4008 1C223F27
	v_cndmask_b32_e64 v31, v0, v1, s1                          // 000000F835E4: D501001F 00060300
	v_cndmask_b32_e64 v39, v27, v0, s1                         // 000000F835EC: D5010027 0006011B
	v_mov_b32_e32 v27, v30                                     // 000000F835F4: 7E36031E
	s_waitcnt lgkmcnt(1)                                       // 000000F835F8: BF89FC17
	v_dot2_f32_bf16 v8, v40, v33, v8                           // 000000F835FC: CC1A4008 1C224328
	v_cndmask_b32_e64 v33, v2, v3, s1                          // 000000F83604: D5010021 00060702
	s_waitcnt lgkmcnt(0)                                       // 000000F8360C: BF89FC07
	s_delay_alu instid0(VALU_DEP_2)                            // 000000F83610: BF870002
	v_dot2_f32_bf16 v8, v41, v36, v8                           // 000000F83614: CC1A4008 1C224929
	v_cndmask_b32_e64 v36, v5, v6, s1                          // 000000F8361C: D5010024 00060D05
	v_and_b32_e32 v10, 0x3fc, v10                              // 000000F83624: 361414FF 000003FC
	v_and_b32_e32 v11, 0x3fc, v11                              // 000000F8362C: 361616FF 000003FC
	ds_load_b32 v9, v10                                        // 000000F83634: D8D80000 0900000A
	ds_load_b32 v10, v32                                       // 000000F8363C: D8D80000 0A000020
	ds_load_b32 v38, v34                                       // 000000F83644: D8D80000 26000022
	ds_load_b32 v47, v35                                       // 000000F8364C: D8D80000 2F000023
	ds_load_b32 v48, v11                                       // 000000F83654: D8D80000 3000000B
	v_cndmask_b32_e64 v32, v1, v2, s1                          // 000000F8365C: D5010020 00060501
	v_cndmask_b32_e64 v35, v4, v5, s1                          // 000000F83664: D5010023 00060B04
	v_cndmask_b32_e64 v34, v3, v4, s1                          // 000000F8366C: D5010022 00060903
	v_mov_b32_e32 v11, v15                                     // 000000F83674: 7E16030F
	s_waitcnt lgkmcnt(4)                                       // 000000F83678: BF89FC47
	v_dot2_f32_bf16 v8, v42, v9, v8                            // 000000F8367C: CC1A4008 1C22132A
	v_mov_b32_e32 v9, v13                                      // 000000F83684: 7E12030D
	s_waitcnt vmcnt(0) lgkmcnt(3)                              // 000000F83688: BF890037
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000F8368C: BF8701C2
	v_dot2_f32_bf16 v6, v43, v10, v8                           // 000000F83690: CC1A4006 1C22152B
	v_mov_b32_e32 v10, v14                                     // 000000F83698: 7E14030E
	v_mov_b32_e32 v8, v12                                      // 000000F8369C: 7E10030C
	s_waitcnt lgkmcnt(2)                                       // 000000F836A0: BF89FC27
	v_dot2_f32_bf16 v2, v44, v38, v6                           // 000000F836A4: CC1A4002 1C1A4D2C
	v_dual_mov_b32 v38, v7 :: v_dual_add_nc_u32 v19, 0x400, v19// 000000F836AC: CA200107 261226FF 00000400
	v_add_nc_u32_e32 v28, 0x200, v28                           // 000000F836B8: 4A3838FF 00000200
	s_waitcnt lgkmcnt(1)                                       // 000000F836C0: BF89FC17
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F836C4: BF8700A3
	v_dot2_f32_bf16 v0, v45, v47, v2                           // 000000F836C8: CC1A4000 1C0A5F2D
	s_waitcnt lgkmcnt(0)                                       // 000000F836D0: BF89FC07
	v_dot2_f32_bf16 v0, v46, v48, v0                           // 000000F836D4: CC1A4000 1C02612E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000F836DC: BF870001
	v_fmac_f32_e32 v26, v39, v0                                // 000000F836E0: 56340127
	v_dual_mov_b32 v0, v31 :: v_dual_mov_b32 v1, v32           // 000000F836E4: CA10011F 00000120
	v_dual_mov_b32 v2, v33 :: v_dual_mov_b32 v3, v34           // 000000F836EC: CA100121 02020122
	v_dual_mov_b32 v4, v35 :: v_dual_mov_b32 v5, v36           // 000000F836F4: CA100123 04040124
	v_dual_mov_b32 v6, v37 :: v_dual_mov_b32 v7, v38           // 000000F836FC: CA100125 06060126
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000F83704: 917E047E
	s_cbranch_execz 28                                         // 000000F83708: BFA5001C <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi1ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x87c>
	s_waitcnt vmcnt(0)                                         // 000000F8370C: BF8903F7
	v_dual_mov_b32 v12, v8 :: v_dual_add_nc_u32 v29, 32, v29   // 000000F83710: CA200108 0C1C3AA0
	v_dual_mov_b32 v13, v9 :: v_dual_mov_b32 v14, v10          // 000000F83718: CA100109 0D0E010A
	v_mov_b32_e32 v15, v11                                     // 000000F83720: 7E1E030B
	s_delay_alu instid0(VALU_DEP_3)                            // 000000F83724: BF870003
	.long 0xd4430002                                           // 000000F83728: D4430002
	v_cndmask_b32_e32 v1, s12, v29, vcc_lo                     // 000000F8372C: 02023A0C
	s_mov_b32 s5, exec_lo                                      // 000000F83730: BE85007E
	.long 0xd4c4007e                                           // 000000F83734: D4C4007E
	v_cndmask_b32_e32 v1, s12, v29, vcc_lo                     // 000000F83738: 02023A0C
	s_cbranch_execz 65327                                      // 000000F8373C: BFA5FF2F <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi1ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x4fc>
	.long 0xd7006a0c                                           // 000000F83740: D7006A0C
	v_cndmask_b32_e32 v1, v18, v28, vcc_lo                     // 000000F83744: 02023912
	s_delay_alu instid0(VALU_DEP_1)                            // 000000F83748: BF870001
	v_add_co_ci_u32_e64 v13, null, 0, v25, vcc_lo              // 000000F8374C: D5207C0D 01AA3280
	v_cmp_ne_u32_e32 vcc_lo, 1, v24                            // 000000F83754: 7C9A3081
	v_mov_b32_e32 v30, v27                                     // 000000F83758: 7E3C031B
	global_load_b128 v[12:15], v[12:13], off                   // 000000F8375C: DC5E0000 0C7C000C
	s_cbranch_vccnz 65317                                      // 000000F83764: BFA4FF25 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi1ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x4fc>
	global_load_d16_b16 v30, v[21:22], off                     // 000000F83768: DC820000 1E7C0015
	s_waitcnt vmcnt(0)                                         // 000000F83770: BF8903F7
	v_cvt_f32_f16_e32 v30, v30                                 // 000000F83774: 7E3C171E
	s_branch 65312                                             // 000000F83778: BFA0FF20 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi1ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x4fc>
	s_or_b32 exec_lo, exec_lo, s4                              // 000000F8377C: 8C7E047E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F83780: BF8700A9
	s_or_b32 exec_lo, exec_lo, s3                              // 000000F83784: 8C7E037E
	.long 0xd71f0000                                           // 000000F83788: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 000000F8378C: 020100C1
	v_xor_b32_e32 v1, 16, v0                                   // 000000F83790: 3A020090
	v_xor_b32_e32 v2, 8, v0                                    // 000000F83794: 3A040088
	v_xor_b32_e32 v3, 4, v0                                    // 000000F83798: 3A060084
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000F8379C: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v1                            // 000000F837A0: 7C9802A0
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 000000F837A4: 02020300
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 000000F837A8: 7C9804A0
	v_cndmask_b32_e32 v2, v0, v2, vcc_lo                       // 000000F837AC: 02040500
	v_cmp_gt_u32_e32 vcc_lo, 32, v3                            // 000000F837B0: 7C9806A0
	s_delay_alu instid0(VALU_DEP_2)                            // 000000F837B4: BF870002
	v_lshlrev_b32_e32 v2, 2, v2                                // 000000F837B8: 30040482
	v_lshlrev_b32_e32 v1, 2, v1                                // 000000F837BC: 30020282
	v_cndmask_b32_e32 v3, v0, v3, vcc_lo                       // 000000F837C0: 02060700
	ds_bpermute_b32 v1, v1, v26                                // 000000F837C4: DACC0000 01001A01
	v_lshlrev_b32_e32 v3, 2, v3                                // 000000F837CC: 30060682
	s_waitcnt lgkmcnt(0)                                       // 000000F837D0: BF89FC07
	v_add_f32_e32 v1, v26, v1                                  // 000000F837D4: 0602031A
	ds_bpermute_b32 v2, v2, v1                                 // 000000F837D8: DACC0000 02000102
	s_waitcnt lgkmcnt(0)                                       // 000000F837E0: BF89FC07
	v_add_f32_e32 v1, v1, v2                                   // 000000F837E4: 06020501
	ds_bpermute_b32 v2, v3, v1                                 // 000000F837E8: DACC0000 02000103
	v_xor_b32_e32 v3, 2, v0                                    // 000000F837F0: 3A060082
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F837F4: BF8700A1
	v_cmp_gt_u32_e32 vcc_lo, 32, v3                            // 000000F837F8: 7C9806A0
	v_cndmask_b32_e32 v3, v0, v3, vcc_lo                       // 000000F837FC: 02060700
	v_lshlrev_b32_e32 v3, 2, v3                                // 000000F83800: 30060682
	s_waitcnt lgkmcnt(0)                                       // 000000F83804: BF89FC07
	v_add_f32_e32 v1, v1, v2                                   // 000000F83808: 06020501
	ds_bpermute_b32 v2, v3, v1                                 // 000000F8380C: DACC0000 02000103
	v_xor_b32_e32 v3, 1, v0                                    // 000000F83814: 3A060081
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 000000F83818: BF870151
	v_cmp_gt_u32_e32 vcc_lo, 32, v3                            // 000000F8381C: 7C9806A0
	v_cndmask_b32_e32 v3, v0, v3, vcc_lo                       // 000000F83820: 02060700
	v_cmp_eq_u32_e32 vcc_lo, 0, v23                            // 000000F83824: 7C942E80
	s_and_b32 s0, vcc_lo, s0                                   // 000000F83828: 8B00006A
	s_waitcnt lgkmcnt(0)                                       // 000000F8382C: BF89FC07
	v_dual_add_f32 v0, v1, v2 :: v_dual_lshlrev_b32 v1, 2, v3  // 000000F83830: C9220501 00000682
	ds_bpermute_b32 v1, v1, v0                                 // 000000F83838: DACC0000 01000001
	s_and_saveexec_b32 s1, s0                                  // 000000F83840: BE812000
	s_cbranch_execz 40                                         // 000000F83844: BFA50028 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi1ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x9e8>
	s_waitcnt lgkmcnt(0)                                       // 000000F83848: BF89FC07
	v_add_f32_e32 v0, v0, v1                                   // 000000F8384C: 06000300
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F83850: BF870091
	v_mul_f32_e32 v0, 0xbfb8aa3b, v0                           // 000000F83854: 100000FF BFB8AA3B
	v_exp_f32_e32 v0, v0                                       // 000000F8385C: 7E004B00
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F83860: BF870095
	v_add_f32_e32 v2, 1.0, v0                                  // 000000F83864: 060400F2
	v_div_scale_f32 v0, null, v2, v2, 1.0                      // 000000F83868: D6FC7C00 03CA0502
	v_div_scale_f32 v4, vcc_lo, 1.0, v2, 1.0                   // 000000F83870: D6FC6A04 03CA04F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000F83878: BF870292
	v_rcp_f32_e32 v1, v0                                       // 000000F8387C: 7E025500
	v_fma_f32 v3, -v0, v1, 1.0                                 // 000000F83880: D6130003 23CA0300
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F83888: BF870091
	v_fmac_f32_e32 v1, v3, v1                                  // 000000F8388C: 56020303
	v_mul_f32_e32 v3, v4, v1                                   // 000000F83890: 10060304
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F83894: BF870091
	v_fma_f32 v5, -v0, v3, v4                                  // 000000F83898: D6130005 24120700
	v_fmac_f32_e32 v3, v5, v1                                  // 000000F838A0: 56060305
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F838A4: BF870091
	v_fma_f32 v0, -v0, v3, v4                                  // 000000F838A8: D6130000 24120700
	v_div_fmas_f32 v3, v0, v1, v3                              // 000000F838B0: D6370003 040E0300
	.long 0xd73c0000                                           // 000000F838B8: D73C0000
	v_cndmask_b32_e32 v1, 2, v16, vcc_lo                       // 000000F838BC: 02022082
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000F838C0: BF870112
	v_div_fixup_f32 v2, v3, v2, 1.0                            // 000000F838C4: D6270002 03CA0503
	.long 0xd7006a00                                           // 000000F838CC: D7006A00
	v_cndmask_b32_e32 v1, s8, v0, vcc_lo                       // 000000F838D0: 02020008
	s_delay_alu instid0(VALU_DEP_1)                            // 000000F838D4: BF870001
	v_add_co_ci_u32_e64 v1, null, s9, v1, vcc_lo               // 000000F838D8: D5207C01 01AA0209
	global_store_b32 v[0:1], v2, off                           // 000000F838E0: DC6A0000 007C0200
	s_endpgm                                                   // 000000F838E8: BFB00000
		...

