00000000007bea00 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi2ELb0ELi1ELi0EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi2ELb0ELi1ELi0EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 0000007BEA00: F4100100 F8000000
	v_dual_mov_b32 v18, 0 :: v_dual_and_b32 v1, 15, v0         // 0000007BEA08: CA240080 1200008F
	v_lshrrev_b32_e32 v2, 2, v0                                // 0000007BEA10: 32040082
	s_ashr_i32 s3, s2, 31                                      // 0000007BEA14: 86039F02
	v_lshrrev_b32_e32 v14, 6, v0                               // 0000007BEA18: 321C0086
	s_lshl_b64 s[20:21], s[2:3], 2                             // 0000007BEA1C: 84948202
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007BEA20: BF8701A9
	v_dual_mov_b32 v4, s21 :: v_dual_lshlrev_b32 v1, 2, v1     // 0000007BEA24: CA220015 04000282
	v_and_b32_e32 v2, 60, v2                                   // 0000007BEA2C: 360404BC
	v_or_b32_e32 v3, s20, v14                                  // 0000007BEA30: 38061C14
	v_bfe_u32 v15, v0, 5, 1                                    // 0000007BEA34: D610000F 02050B00
	.long 0x7f0e3880                                           // 0000007BEA3C: 7F0E3880
	v_mov_b32_e32 v17, 0                                       // 0000007BEA40: 7E220280
	s_waitcnt lgkmcnt(0)                                       // 0000007BEA44: BF89FC07
	s_clause 0x1                                               // 0000007BEA48: BF850001
	global_load_b32 v5, v1, s[4:5]                             // 0000007BEA4C: DC520000 05040001
	global_load_b32 v6, v2, s[4:5]                             // 0000007BEA54: DC520000 06040002
	s_add_u32 s2, s4, s14                                      // 0000007BEA5C: 80020E04
	s_addc_u32 s3, s5, s15                                     // 0000007BEA60: 82030F05
	s_lshr_b32 s14, s11, 31                                    // 0000007BEA64: 850E9F0B
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[3:4]                  // 0000007BEA68: 7CA8060C
	s_add_u32 s14, s10, s14                                    // 0000007BEA6C: 800E0E0A
	s_addc_u32 s15, s11, 0                                     // 0000007BEA70: 820F800B
	s_ashr_i32 s22, s11, 31                                    // 0000007BEA74: 86169F0B
	s_ashr_i64 s[14:15], s[14:15], 1                           // 0000007BEA78: 868E810E
	s_lshr_b32 s22, s22, 27                                    // 0000007BEA7C: 85169B16
	v_dual_cndmask_b32 v3, 0, v3 :: v_dual_and_b32 v16, 31, v0 // 0000007BEA80: CA640680 0310009F
	s_add_u32 s22, s10, s22                                    // 0000007BEA88: 8016160A
	s_addc_u32 s23, s11, 0                                     // 0000007BEA8C: 8217800B
	v_cndmask_b32_e64 v4, 0, s21, vcc_lo                       // 0000007BEA90: D5010004 01A82A80
	s_lshr_b64 s[22:23], s[22:23], 5                           // 0000007BEA98: 85968516
	.long 0xd72c0008                                           // 0000007BEA9C: D72C0008
	v_cndmask_b32_e32 v1, s19, v3, vcc_lo                      // 0000007BEAA0: 02020613
	s_add_i32 s23, s22, 1                                      // 0000007BEAA4: 81178116
	.long 0xd72c000d                                           // 0000007BEAA8: D72C000D
	v_cndmask_b32_e32 v0, v3, v15, vcc_lo                      // 0000007BEAAC: 02001F03
	s_lshr_b32 s19, s23, 31                                    // 0000007BEAB0: 85139F17
	v_mad_u64_u32 v[9:10], null, v3, s14, s[2:3]               // 0000007BEAB4: D6FE7C09 00081D03
	s_add_i32 s23, s23, s19                                    // 0000007BEABC: 81171317
	.long 0xd72c0015                                           // 0000007BEAC0: D72C0015
	v_cndmask_b32_e32 v0, v4, v14, vcc_lo                      // 0000007BEAC4: 02001D04
	s_ashr_i32 s15, s23, 1                                     // 0000007BEAC8: 860F8117
	s_add_u32 s2, s4, s16                                      // 0000007BEACC: 80021004
	.long 0xd72c0013                                           // 0000007BEAD0: D72C0013
	v_cndmask_b32_e32 v1, s15, v15, vcc_lo                     // 0000007BEAD4: 02021E0F
	s_addc_u32 s3, s5, s17                                     // 0000007BEAD8: 82031105
	.long 0xd72c0016                                           // 0000007BEADC: D72C0016
	v_cndmask_b32_e32 v1, s18, v4, vcc_lo                      // 0000007BEAE0: 02020812
	v_dual_mov_b32 v1, 0 :: v_dual_mov_b32 v2, 0               // 0000007BEAE4: CA100080 01020080
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000007BEAEC: BF870214
	v_add3_u32 v10, v21, v10, v13                              // 0000007BEAF0: D655000A 04361515
	v_add_nc_u32_e32 v4, s15, v19                              // 0000007BEAF8: 4A08260F
	v_add_nc_u32_e32 v19, v19, v16                             // 0000007BEAFC: 4A262113
	s_waitcnt vmcnt(1)                                         // 0000007BEB00: BF8907F7
	v_bfe_u32 v11, v5, 16, 1                                   // 0000007BEB04: D610000B 02052105
	s_waitcnt vmcnt(0)                                         // 0000007BEB0C: BF8903F7
	v_bfe_u32 v20, v6, 16, 1                                   // 0000007BEB10: D6100014 02052106
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007BEB18: BF8701A2
	v_add3_u32 v5, v5, v11, 0x7fff                             // 0000007BEB1C: D6550005 03FE1705 00007FFF
	v_mad_u64_u32 v[11:12], null, s18, v3, s[2:3]              // 0000007BEB28: D6FE7C0B 000A0612
	v_add3_u32 v6, v6, v20, 0x7fff                             // 0000007BEB30: D6550006 03FE2906 00007FFF
	v_mov_b32_e32 v3, 0                                        // 0000007BEB3C: 7E060280
	v_min_i32_e32 v20, s22, v4                                 // 0000007BEB40: 22280816
	.long 0x7e0e3985                                           // 0000007BEB44: 7E0E3985
	v_dual_mov_b32 v4, 0 :: v_dual_lshlrev_b32 v5, 2, v0       // 0000007BEB48: CA220080 04040082
	v_add3_u32 v21, v8, v12, v22                               // 0000007BEB50: D6550015 045A1908
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007BEB58: BF870003
	v_and_or_b32 v6, 0xffff0000, v6, v7                        // 0000007BEB5C: D6570006 041E0CFF FFFF0000
	v_cmp_lt_i32_e32 vcc_lo, v19, v20                          // 0000007BEB68: 7C822913
	ds_store_b32 v5, v6                                        // 0000007BEB6C: D8340000 00000605
	s_waitcnt lgkmcnt(0)                                       // 0000007BEB74: BF89FC07
	s_barrier                                                  // 0000007BEB78: BFBD0000
	buffer_gl0_inv                                             // 0000007BEB7C: E0AC0000 00000000
	s_and_saveexec_b32 s3, vcc_lo                              // 0000007BEB84: BE83206A
	s_cbranch_execz 21                                         // 0000007BEB88: BFA50015 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi2ELb0ELi1ELi0EEEvPKhPKtPvlllllS6_f+0x1e0>
	v_lshlrev_b32_e32 v1, 1, v19                               // 0000007BEB8C: 30022681
	v_lshlrev_b32_e32 v3, 4, v19                               // 0000007BEB90: 30062684
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007BEB94: BF870112
	v_ashrrev_i32_e32 v2, 31, v1                               // 0000007BEB98: 3404029F
	v_ashrrev_i32_e32 v4, 31, v3                               // 0000007BEB9C: 3408069F
	.long 0xd7000201                                           // 0000007BEBA0: D7000201
	v_cndmask_b32_e32 v1, v11, v1, vcc_lo                      // 0000007BEBA4: 0202030B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007BEBA8: BF8700A1
	v_add_co_ci_u32_e64 v2, null, v21, v2, s2                  // 0000007BEBAC: D5207C02 000A0515
	.long 0xd7000203                                           // 0000007BEBB4: D7000203
	v_cndmask_b32_e32 v1, v9, v3, vcc_lo                       // 0000007BEBB8: 02020709
	v_add_co_ci_u32_e64 v4, null, v10, v4, s2                  // 0000007BEBBC: D5207C04 000A090A
	s_clause 0x1                                               // 0000007BEBC4: BF850001
	global_load_d16_b16 v5, v[1:2], off                        // 0000007BEBC8: DC820000 057C0001
	global_load_b128 v[1:4], v[3:4], off                       // 0000007BEBD0: DC5E0000 017C0003
	s_waitcnt vmcnt(1)                                         // 0000007BEBD8: BF8907F7
	v_cvt_f32_f16_e32 v18, v5                                  // 0000007BEBDC: 7E241705
	s_or_b32 exec_lo, exec_lo, s3                              // 0000007BEBE0: 8C7E037E
	v_mov_b32_e32 v22, 0                                       // 0000007BEBE4: 7E2C0280
	s_and_saveexec_b32 s3, vcc_lo                              // 0000007BEBE8: BE83206A
	s_cbranch_execz 264                                        // 0000007BEBEC: BFA50108 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi2ELb0ELi1ELi0EEEvPKhPKtPvlllllS6_f+0x610>
	v_dual_mov_b32 v22, 0 :: v_dual_add_nc_u32 v5, 32, v19     // 0000007BEBF0: CA200080 160426A0
	v_dual_mov_b32 v17, 0 :: v_dual_lshlrev_b32 v12, 5, v19    // 0000007BEBF8: CA220080 110C2685
	s_mov_b32 s14, 0                                           // 0000007BEC00: BE8E0080
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007BEC04: BF870002
	v_lshlrev_b32_e32 v23, 4, v5                               // 0000007BEC08: 302E0A84
	v_dual_mov_b32 v25, v18 :: v_dual_lshlrev_b32 v24, 1, v5   // 0000007BEC0C: CA220112 19180A81
	s_lshl_b64 s[4:5], s[10:11], 1                             // 0000007BEC14: 8484810A
	s_branch 221                                               // 0000007BEC18: BFA000DD <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi2ELb0ELi1ELi0EEEvPKhPKtPvlllllS6_f+0x590>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000007BEC1C: 8C7E0A7E
	v_ashrrev_i32_e32 v13, 31, v12                             // 0000007BEC20: 341A189F
	v_lshrrev_b32_e32 v58, 6, v1                               // 0000007BEC24: 32740286
	v_lshrrev_b32_e32 v59, 14, v1                              // 0000007BEC28: 3276028E
	v_and_b32_e32 v60, 0xff, v2                                // 0000007BEC2C: 367804FF 000000FF
	v_lshrrev_b32_e32 v61, 6, v2                               // 0000007BEC34: 327A0486
	.long 0xd73c001a                                           // 0000007BEC38: D73C001A
	v_cndmask_b32_e32 v1, 1, v12, vcc_lo                       // 0000007BEC3C: 02021881
	v_and_b32_e32 v13, 0xff, v1                                // 0000007BEC40: 361A02FF 000000FF
	v_and_b32_e32 v58, 0x3fc, v58                              // 0000007BEC48: 367474FF 000003FC
	v_and_b32_e32 v59, 0x3fc, v59                              // 0000007BEC50: 367676FF 000003FC
	v_lshrrev_b32_e32 v1, 22, v1                               // 0000007BEC58: 32020296
	v_lshrrev_b32_e32 v62, 14, v2                              // 0000007BEC5C: 327C048E
	.long 0xd7000232                                           // 0000007BEC60: D7000232
	v_cndmask_b32_e32 v1, s6, v26, vcc_lo                      // 0000007BEC64: 02023406
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007BEC68: BF8701A1
	v_add_co_ci_u32_e64 v51, null, s7, v27, s2                 // 0000007BEC6C: D5207C33 000A3607
	v_lshlrev_b32_e32 v13, 2, v13                              // 0000007BEC74: 301A1A82
	.long 0xd7000236                                           // 0000007BEC78: D7000236
	v_cndmask_b32_e32 v0, v50, v4, vcc_lo                      // 0000007BEC7C: 02000932
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007BEC80: BF870001
	v_add_co_ci_u32_e64 v55, null, s5, v51, s2                 // 0000007BEC84: D5207C37 000A6605
	ds_load_b32 v13, v13                                       // 0000007BEC8C: D8D80000 0D00000D
	ds_load_b32 v58, v58                                       // 0000007BEC94: D8D80000 3A00003A
	ds_load_b32 v59, v59                                       // 0000007BEC9C: D8D80000 3B00003B
	s_clause 0x7                                               // 0000007BECA4: BF850007
	global_load_b128 v[26:29], v[50:51], off                   // 0000007BECA8: DC5E0000 1A7C0032
	global_load_b128 v[30:33], v[54:55], off                   // 0000007BECB0: DC5E0000 1E7C0036
	global_load_b128 v[34:37], v[50:51], off offset:16         // 0000007BECB8: DC5E0010 227C0032
	global_load_b128 v[38:41], v[54:55], off offset:16         // 0000007BECC0: DC5E0010 267C0036
	global_load_b128 v[42:45], v[50:51], off offset:32         // 0000007BECC8: DC5E0020 2A7C0032
	global_load_b128 v[46:49], v[54:55], off offset:32         // 0000007BECD0: DC5E0020 2E7C0036
	global_load_b128 v[50:53], v[50:51], off offset:48         // 0000007BECD8: DC5E0030 327C0032
	global_load_b128 v[54:57], v[54:55], off offset:48         // 0000007BECE0: DC5E0030 367C0036
	v_lshrrev_b32_e32 v2, 22, v2                               // 0000007BECE8: 32040496
	v_and_b32_e32 v1, 0x3fc, v1                                // 0000007BECEC: 360202FF 000003FC
	v_lshlrev_b32_e32 v60, 2, v60                              // 0000007BECF4: 30787882
	v_and_b32_e32 v61, 0x3fc, v61                              // 0000007BECF8: 367A7AFF 000003FC
	v_and_b32_e32 v62, 0x3fc, v62                              // 0000007BED00: 367C7CFF 000003FC
	v_and_b32_e32 v2, 0x3fc, v2                                // 0000007BED08: 360404FF 000003FC
	ds_load_b32 v1, v1                                         // 0000007BED10: D8D80000 01000001
	ds_load_b32 v60, v60                                       // 0000007BED18: D8D80000 3C00003C
	ds_load_b32 v61, v61                                       // 0000007BED20: D8D80000 3D00003D
	ds_load_b32 v62, v62                                       // 0000007BED28: D8D80000 3E00003E
	ds_load_b32 v2, v2                                         // 0000007BED30: D8D80000 02000002
	v_add_nc_u32_e32 v23, 0x200, v23                           // 0000007BED38: 4A2E2EFF 00000200
	v_add_nc_u32_e32 v24, 64, v24                              // 0000007BED40: 4A3030C0
	v_add_nc_u32_e32 v12, 0x400, v12                           // 0000007BED44: 4A1818FF 00000400
	s_and_b32 s2, exec_lo, vcc_lo                              // 0000007BED4C: 8B026A7E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000007BED50: BF870009
	s_or_b32 s14, s2, s14                                      // 0000007BED54: 8C0E0E02
	s_waitcnt vmcnt(7) lgkmcnt(7)                              // 0000007BED58: BF891C77
	v_dot2_f32_bf16 v26, v26, v13, 0                           // 0000007BED5C: CC1A401A 1A021B1A
	s_waitcnt vmcnt(6)                                         // 0000007BED64: BF891BF7
	v_dot2_f32_bf16 v13, v30, v13, 0                           // 0000007BED68: CC1A400D 1A021B1E
	v_and_b32_e32 v30, 0xff, v3                                // 0000007BED70: 363C06FF 000000FF
	s_waitcnt lgkmcnt(6)                                       // 0000007BED78: BF89FC67
	v_dot2_f32_bf16 v26, v27, v58, v26                         // 0000007BED7C: CC1A401A 1C6A751B
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007BED84: BF870003
	v_dot2_f32_bf16 v13, v31, v58, v13                         // 0000007BED88: CC1A400D 1C36751F
	v_lshrrev_b32_e32 v27, 6, v3                               // 0000007BED90: 32360686
	v_lshrrev_b32_e32 v31, 14, v3                              // 0000007BED94: 323E068E
	v_lshrrev_b32_e32 v3, 22, v3                               // 0000007BED98: 32060696
	s_waitcnt lgkmcnt(5)                                       // 0000007BED9C: BF89FC57
	v_dot2_f32_bf16 v26, v28, v59, v26                         // 0000007BEDA0: CC1A401A 1C6A771C
	v_dot2_f32_bf16 v13, v32, v59, v13                         // 0000007BEDA8: CC1A400D 1C367720
	v_and_b32_e32 v27, 0x3fc, v27                              // 0000007BEDB0: 363636FF 000003FC
	v_and_b32_e32 v28, 0xff, v4                                // 0000007BEDB8: 363808FF 000000FF
	v_lshrrev_b32_e32 v32, 6, v4                               // 0000007BEDC0: 32400886
	s_waitcnt lgkmcnt(4)                                       // 0000007BEDC4: BF89FC47
	v_dot2_f32_bf16 v26, v29, v1, v26                          // 0000007BEDC8: CC1A401A 1C6A031D
	v_dot2_f32_bf16 v1, v33, v1, v13                           // 0000007BEDD0: CC1A4001 1C360321
	v_lshlrev_b32_e32 v13, 2, v30                              // 0000007BEDD8: 301A3C82
	v_and_b32_e32 v29, 0x3fc, v31                              // 0000007BEDDC: 363A3EFF 000003FC
	v_lshrrev_b32_e32 v58, 14, v4                              // 0000007BEDE4: 3274088E
	s_waitcnt vmcnt(5) lgkmcnt(3)                              // 0000007BEDE8: BF891437
	v_dot2_f32_bf16 v26, v34, v60, v26                         // 0000007BEDEC: CC1A401A 1C6A7922
	s_waitcnt vmcnt(4)                                         // 0000007BEDF4: BF8913F7
	v_dot2_f32_bf16 v1, v38, v60, v1                           // 0000007BEDF8: CC1A4001 1C067926
	ds_load_b32 v13, v13                                       // 0000007BEE00: D8D80000 0D00000D
	ds_load_b32 v27, v27                                       // 0000007BEE08: D8D80000 1B00001B
	ds_load_b32 v29, v29                                       // 0000007BEE10: D8D80000 1D00001D
	s_waitcnt lgkmcnt(5)                                       // 0000007BEE18: BF89FC57
	v_dot2_f32_bf16 v26, v35, v61, v26                         // 0000007BEE1C: CC1A401A 1C6A7B23
	v_dot2_f32_bf16 v1, v39, v61, v1                           // 0000007BEE24: CC1A4001 1C067B27
	v_lshrrev_b32_e32 v4, 22, v4                               // 0000007BEE2C: 32080896
	v_and_b32_e32 v3, 0x3fc, v3                                // 0000007BEE30: 360606FF 000003FC
	v_lshlrev_b32_e32 v28, 2, v28                              // 0000007BEE38: 30383882
	s_waitcnt lgkmcnt(4)                                       // 0000007BEE3C: BF89FC47
	v_dot2_f32_bf16 v26, v36, v62, v26                         // 0000007BEE40: CC1A401A 1C6A7D24
	v_dot2_f32_bf16 v1, v40, v62, v1                           // 0000007BEE48: CC1A4001 1C067D28
	v_and_b32_e32 v30, 0x3fc, v32                              // 0000007BEE50: 363C40FF 000003FC
	v_and_b32_e32 v31, 0x3fc, v58                              // 0000007BEE58: 363E74FF 000003FC
	v_and_b32_e32 v4, 0x3fc, v4                                // 0000007BEE60: 360808FF 000003FC
	s_waitcnt lgkmcnt(3)                                       // 0000007BEE68: BF89FC37
	v_dot2_f32_bf16 v26, v37, v2, v26                          // 0000007BEE6C: CC1A401A 1C6A0525
	v_dot2_f32_bf16 v1, v41, v2, v1                            // 0000007BEE74: CC1A4001 1C060529
	ds_load_b32 v2, v3                                         // 0000007BEE7C: D8D80000 02000003
	ds_load_b32 v3, v28                                        // 0000007BEE84: D8D80000 0300001C
	ds_load_b32 v28, v30                                       // 0000007BEE8C: D8D80000 1C00001E
	ds_load_b32 v30, v31                                       // 0000007BEE94: D8D80000 1E00001F
	ds_load_b32 v31, v4                                        // 0000007BEE9C: D8D80000 1F000004
	s_waitcnt vmcnt(3) lgkmcnt(7)                              // 0000007BEEA4: BF890C77
	v_dot2_f32_bf16 v4, v42, v13, v26                          // 0000007BEEA8: CC1A4004 1C6A1B2A
	s_waitcnt vmcnt(2)                                         // 0000007BEEB0: BF890BF7
	v_dot2_f32_bf16 v1, v46, v13, v1                           // 0000007BEEB4: CC1A4001 1C061B2E
	s_waitcnt lgkmcnt(6)                                       // 0000007BEEBC: BF89FC67
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007BEEC0: BF870112
	v_dot2_f32_bf16 v4, v43, v27, v4                           // 0000007BEEC4: CC1A4004 1C12372B
	v_dot2_f32_bf16 v1, v47, v27, v1                           // 0000007BEECC: CC1A4001 1C06372F
	s_waitcnt lgkmcnt(5)                                       // 0000007BEED4: BF89FC57
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007BEED8: BF870112
	v_dot2_f32_bf16 v4, v44, v29, v4                           // 0000007BEEDC: CC1A4004 1C123B2C
	v_dot2_f32_bf16 v1, v48, v29, v1                           // 0000007BEEE4: CC1A4001 1C063B30
	s_waitcnt lgkmcnt(4)                                       // 0000007BEEEC: BF89FC47
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007BEEF0: BF870112
	v_dot2_f32_bf16 v4, v45, v2, v4                            // 0000007BEEF4: CC1A4004 1C12052D
	v_dot2_f32_bf16 v1, v49, v2, v1                            // 0000007BEEFC: CC1A4001 1C060531
	s_waitcnt vmcnt(1) lgkmcnt(3)                              // 0000007BEF04: BF890437
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000007BEF08: BF870122
	v_dot2_f32_bf16 v2, v50, v3, v4                            // 0000007BEF0C: CC1A4002 1C120732
	s_waitcnt vmcnt(0)                                         // 0000007BEF14: BF8903F7
	v_dot2_f32_bf16 v1, v54, v3, v1                            // 0000007BEF18: CC1A4001 1C060736
	v_dual_mov_b32 v4, v8 :: v_dual_mov_b32 v3, v7             // 0000007BEF20: CA100108 04020107
	s_waitcnt lgkmcnt(2)                                       // 0000007BEF28: BF89FC27
	v_dot2_f32_bf16 v2, v51, v28, v2                           // 0000007BEF2C: CC1A4002 1C0A3933
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000007BEF34: BF870123
	v_dot2_f32_bf16 v1, v55, v28, v1                           // 0000007BEF38: CC1A4001 1C063937
	s_waitcnt lgkmcnt(1)                                       // 0000007BEF40: BF89FC17
	v_dot2_f32_bf16 v2, v52, v30, v2                           // 0000007BEF44: CC1A4002 1C0A3D34
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000007BEF4C: BF870122
	v_dot2_f32_bf16 v1, v56, v30, v1                           // 0000007BEF50: CC1A4001 1C063D38
	s_waitcnt lgkmcnt(0)                                       // 0000007BEF58: BF89FC07
	v_dot2_f32_bf16 v7, v53, v31, v2                           // 0000007BEF5C: CC1A4007 1C0A3F35
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007BEF64: BF8701A2
	v_dot2_f32_bf16 v8, v57, v31, v1                           // 0000007BEF68: CC1A4008 1C063F39
	v_dual_mov_b32 v2, v6 :: v_dual_mov_b32 v1, v5             // 0000007BEF70: CA100106 02000105
	v_fmac_f32_e32 v22, v18, v7                                // 0000007BEF78: 562C0F12
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007BEF7C: BF870003
	v_dual_fmac_f32 v17, v18, v8 :: v_dual_mov_b32 v18, v25    // 0000007BEF80: C8101112 11120119
	s_and_not1_b32 exec_lo, exec_lo, s14                       // 0000007BEF88: 917E0E7E
	s_cbranch_execz 31                                         // 0000007BEF8C: BFA5001F <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi2ELb0ELi1ELi0EEEvPKhPKtPvlllllS6_f+0x60c>
	s_waitcnt vmcnt(0)                                         // 0000007BEF90: BF8903F7
	v_dual_mov_b32 v6, v2 :: v_dual_add_nc_u32 v19, 32, v19    // 0000007BEF94: CA200102 061226A0
	v_dual_mov_b32 v5, v1 :: v_dual_mov_b32 v8, v4             // 0000007BEF9C: CA100101 05080104
	v_mov_b32_e32 v7, v3                                       // 0000007BEFA4: 7E0E0303
	s_mov_b32 s10, exec_lo                                     // 0000007BEFA8: BE8A007E
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007BEFAC: BF870003
	v_cmp_ge_i32_e32 vcc_lo, v19, v20                          // 0000007BEFB0: 7C8C2913
	.long 0xd4c1007e                                           // 0000007BEFB4: D4C1007E
	v_cndmask_b32_e32 v1, v19, v20, vcc_lo                     // 0000007BEFB8: 02022913
	s_cbranch_execz 65303                                      // 0000007BEFBC: BFA5FF17 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi2ELb0ELi1ELi0EEEvPKhPKtPvlllllS6_f+0x21c>
	v_ashrrev_i32_e32 v6, 31, v24                              // 0000007BEFC0: 340C309F
	v_ashrrev_i32_e32 v8, 31, v23                              // 0000007BEFC4: 34102E9F
	.long 0xd7000205                                           // 0000007BEFC8: D7000205
	v_cndmask_b32_e32 v1, v11, v24, vcc_lo                     // 0000007BEFCC: 0202310B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007BEFD0: BF8700A1
	v_add_co_ci_u32_e64 v6, null, v21, v6, s2                  // 0000007BEFD4: D5207C06 000A0D15
	.long 0xd7000207                                           // 0000007BEFDC: D7000207
	v_cndmask_b32_e32 v1, v9, v23, vcc_lo                      // 0000007BEFE0: 02022F09
	v_add_co_ci_u32_e64 v8, null, v10, v8, s2                  // 0000007BEFE4: D5207C08 000A110A
	s_clause 0x1                                               // 0000007BEFEC: BF850001
	global_load_d16_b16 v13, v[5:6], off                       // 0000007BEFF0: DC820000 0D7C0005
	global_load_b128 v[5:8], v[7:8], off                       // 0000007BEFF8: DC5E0000 057C0007
	s_waitcnt vmcnt(1)                                         // 0000007BF000: BF8907F7
	v_cvt_f32_f16_e32 v25, v13                                 // 0000007BF004: 7E32170D
	s_branch 65284                                             // 0000007BF008: BFA0FF04 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi2ELb0ELi1ELi0EEEvPKhPKtPvlllllS6_f+0x21c>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000007BF00C: 8C7E0E7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000007BF010: BF8700C9
	s_or_b32 exec_lo, exec_lo, s3                              // 0000007BF014: 8C7E037E
	s_waitcnt vmcnt(0)                                         // 0000007BF018: BF8903F7
	.long 0xd71f0001                                           // 0000007BF01C: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000007BF020: 020100C1
	s_mov_b32 s2, exec_lo                                      // 0000007BF024: BE82007E
	v_xor_b32_e32 v2, 16, v1                                   // 0000007BF028: 3A040290
	v_xor_b32_e32 v4, 8, v1                                    // 0000007BF02C: 3A080288
	v_xor_b32_e32 v6, 4, v1                                    // 0000007BF030: 3A0C0284
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000007BF034: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 0000007BF038: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 0000007BF03C: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v4                            // 0000007BF040: 7C9808A0
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007BF044: BF870002
	v_lshlrev_b32_e32 v2, 2, v2                                // 0000007BF048: 30040482
	v_cndmask_b32_e32 v4, v1, v4, vcc_lo                       // 0000007BF04C: 02080901
	v_cmp_gt_u32_e32 vcc_lo, 32, v6                            // 0000007BF050: 7C980CA0
	ds_bpermute_b32 v3, v2, v22                                // 0000007BF054: DACC0000 03001602
	v_lshlrev_b32_e32 v4, 2, v4                                // 0000007BF05C: 30080882
	v_cndmask_b32_e32 v6, v1, v6, vcc_lo                       // 0000007BF060: 020C0D01
	s_waitcnt lgkmcnt(0)                                       // 0000007BF064: BF89FC07
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007BF068: BF870001
	v_dual_add_f32 v3, v22, v3 :: v_dual_lshlrev_b32 v6, 2, v6 // 0000007BF06C: C9220716 03060C82
	ds_bpermute_b32 v5, v4, v3                                 // 0000007BF074: DACC0000 05000304
	s_waitcnt lgkmcnt(0)                                       // 0000007BF07C: BF89FC07
	v_add_f32_e32 v3, v3, v5                                   // 0000007BF080: 06060B03
	ds_bpermute_b32 v2, v2, v17                                // 0000007BF084: DACC0000 02001102
	s_waitcnt lgkmcnt(0)                                       // 0000007BF08C: BF89FC07
	v_add_f32_e32 v2, v17, v2                                  // 0000007BF090: 06040511
	ds_bpermute_b32 v4, v4, v2                                 // 0000007BF094: DACC0000 04000204
	s_waitcnt lgkmcnt(0)                                       // 0000007BF09C: BF89FC07
	v_add_f32_e32 v2, v2, v4                                   // 0000007BF0A0: 06040902
	ds_bpermute_b32 v4, v6, v3                                 // 0000007BF0A4: DACC0000 04000306
	ds_bpermute_b32 v5, v6, v2                                 // 0000007BF0AC: DACC0000 05000206
	v_xor_b32_e32 v6, 2, v1                                    // 0000007BF0B4: 3A0C0282
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007BF0B8: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v6                            // 0000007BF0BC: 7C980CA0
	v_cndmask_b32_e32 v6, v1, v6, vcc_lo                       // 0000007BF0C0: 020C0D01
	s_waitcnt lgkmcnt(1)                                       // 0000007BF0C4: BF89FC17
	v_dual_add_f32 v3, v3, v4 :: v_dual_lshlrev_b32 v6, 2, v6  // 0000007BF0C8: C9220903 03060C82
	s_waitcnt lgkmcnt(0)                                       // 0000007BF0D0: BF89FC07
	v_add_f32_e32 v4, v2, v5                                   // 0000007BF0D4: 06080B02
	ds_bpermute_b32 v2, v6, v3                                 // 0000007BF0D8: DACC0000 02000306
	ds_bpermute_b32 v5, v6, v4                                 // 0000007BF0E0: DACC0000 05000406
	v_xor_b32_e32 v6, 1, v1                                    // 0000007BF0E8: 3A0C0281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007BF0EC: BF8700A1
	v_cmp_gt_u32_e32 vcc_lo, 32, v6                            // 0000007BF0F0: 7C980CA0
	v_cndmask_b32_e32 v1, v1, v6, vcc_lo                       // 0000007BF0F4: 02020D01
	v_lshlrev_b32_e32 v6, 2, v1                                // 0000007BF0F8: 300C0282
	s_waitcnt lgkmcnt(0)                                       // 0000007BF0FC: BF89FC07
	v_dual_add_f32 v2, v3, v2 :: v_dual_add_f32 v1, v4, v5     // 0000007BF100: C9080503 02000B04
	ds_bpermute_b32 v4, v6, v2                                 // 0000007BF108: DACC0000 04000206
	ds_bpermute_b32 v3, v6, v1                                 // 0000007BF110: DACC0000 03000106
	v_cmpx_eq_u32_e32 0, v16                                   // 0000007BF118: 7D942080
	s_cbranch_execz 10                                         // 0000007BF11C: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi2ELb0ELi1ELi0EEEvPKhPKtPvlllllS6_f+0x748>
	s_waitcnt lgkmcnt(1)                                       // 0000007BF120: BF89FC17
	v_dual_add_f32 v2, v2, v4 :: v_dual_lshlrev_b32 v5, 3, v15 // 0000007BF124: C9220902 02041E83
	s_waitcnt lgkmcnt(0)                                       // 0000007BF12C: BF89FC07
	v_add_f32_e32 v3, v1, v3                                   // 0000007BF130: 06060701
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007BF134: BF870002
	v_lshl_or_b32 v4, v14, 4, v5                               // 0000007BF138: D6560004 0415090E
	ds_store_b64 v4, v[2:3] offset:1024                        // 0000007BF140: D9340400 00000204
	s_or_b32 exec_lo, exec_lo, s2                              // 0000007BF148: 8C7E027E
	s_waitcnt lgkmcnt(0)                                       // 0000007BF14C: BF89FC07
	v_lshrrev_b32_e32 v3, 1, v0                                // 0000007BF150: 32060081
	v_mov_b32_e32 v2, s21                                      // 0000007BF154: 7E040215
	.long 0xd44c0002                                           // 0000007BF158: D44C0002
	v_cndmask_b32_e32 v1, 8, v0, vcc_lo                        // 0000007BF15C: 02020088
	s_barrier                                                  // 0000007BF160: BFBD0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 0000007BF164: BF8704C3
	v_or_b32_e32 v1, s20, v3                                   // 0000007BF168: 38020614
	buffer_gl0_inv                                             // 0000007BF16C: E0AC0000 00000000
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[1:2]                  // 0000007BF174: 7CA8020C
	s_and_b32 s2, s2, vcc_lo                                   // 0000007BF178: 8B026A02
	s_and_saveexec_b32 s3, s2                                  // 0000007BF17C: BE832002
	s_cbranch_execz 80                                         // 0000007BF180: BFA50050 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi2ELb0ELi1ELi0EEEvPKhPKtPvlllllS6_f+0x8c4>
	v_and_b32_e32 v0, 1, v0                                    // 0000007BF184: 36000081
	s_load_b32 s0, s[0:1], 0x48                                // 0000007BF188: F4000000 F8000048
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007BF190: BF870091
	v_lshlrev_b32_e32 v4, 2, v0                                // 0000007BF194: 30080082
	v_lshl_or_b32 v3, v3, 4, v4                                // 0000007BF198: D6560003 04110903
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000007BF1A0: BF8700C1
	v_add_nc_u32_e32 v3, 0x400, v3                             // 0000007BF1A4: 4A0606FF 00000400
	ds_load_2addr_b32 v[3:4], v3 offset1:2                     // 0000007BF1AC: D8DC0200 03000003
	s_waitcnt lgkmcnt(0)                                       // 0000007BF1B4: BF89FC07
	v_add_f32_e32 v3, 0, v3                                    // 0000007BF1B8: 06060680
	v_add_f32_e32 v3, v3, v4                                   // 0000007BF1BC: 06060903
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007BF1C0: BF870091
	v_bfe_u32 v4, v3, 16, 1                                    // 0000007BF1C4: D6100004 02052103
	v_add3_u32 v3, v3, v4, 0x7fff                              // 0000007BF1CC: D6550003 03FE0903 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007BF1D8: BF870091
	v_and_b32_e32 v3, 0xffff0000, v3                           // 0000007BF1DC: 360606FF FFFF0000
	v_mul_f32_e32 v5, s0, v3                                   // 0000007BF1E4: 100A0600
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007BF1E8: BF870091
	v_mul_f32_e32 v3, 0xbfb8aa3b, v5                           // 0000007BF1EC: 10060AFF BFB8AA3B
	v_exp_f32_e32 v3, v3                                       // 0000007BF1F4: 7E064B03
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007BF1F8: BF870095
	v_add_f32_e32 v6, 1.0, v3                                  // 0000007BF1FC: 060C06F2
	v_div_scale_f32 v3, null, v6, v6, v5                       // 0000007BF200: D6FC7C03 04160D06
	v_div_scale_f32 v8, vcc_lo, v5, v6, v5                     // 0000007BF208: D6FC6A08 04160D05
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000007BF210: BF870292
	v_rcp_f32_e32 v7, v3                                       // 0000007BF214: 7E0E5503
	v_fma_f32 v4, -v3, v7, 1.0                                 // 0000007BF218: D6130004 23CA0F03
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007BF220: BF870091
	v_fmac_f32_e32 v7, v4, v7                                  // 0000007BF224: 560E0F04
	v_mul_f32_e32 v9, v8, v7                                   // 0000007BF228: 10120F08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007BF22C: BF870091
	v_fma_f32 v4, -v3, v9, v8                                  // 0000007BF230: D6130004 24221303
	v_fmac_f32_e32 v9, v4, v7                                  // 0000007BF238: 56120F04
	.long 0xd72c0004                                           // 0000007BF23C: D72C0004
	v_cndmask_b32_e32 v1, s13, v0, vcc_lo                      // 0000007BF240: 0202000D
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000007BF244: BF870122
	v_fma_f32 v8, -v3, v9, v8                                  // 0000007BF248: D6130008 24221303
	.long 0xd72c0003                                           // 0000007BF250: D72C0003
	v_cndmask_b32_e32 v1, s12, v0, vcc_lo                      // 0000007BF254: 0202000C
	v_div_fmas_f32 v0, v8, v7, v9                              // 0000007BF258: D6370000 04260F08
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007BF260: BF870112
	.long 0xd73c0003                                           // 0000007BF264: D73C0003
	v_cndmask_b32_e32 v1, 1, v3, vcc_lo                        // 0000007BF268: 02020681
	v_div_fixup_f32 v5, v0, v6, v5                             // 0000007BF26C: D6270005 04160D00
	.long 0xd73c0000                                           // 0000007BF274: D73C0000
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 0000007BF278: 02020281
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007BF27C: BF870193
	.long 0xd7006a03                                           // 0000007BF280: D7006A03
	v_cndmask_b32_e32 v1, s8, v3, vcc_lo                       // 0000007BF284: 02020608
	v_bfe_u32 v2, v5, 16, 1                                    // 0000007BF288: D6100002 02052105
	v_add_co_ci_u32_e64 v4, null, s9, v4, vcc_lo               // 0000007BF290: D5207C04 01AA0809
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007BF298: BF870193
	.long 0xd7006a00                                           // 0000007BF29C: D7006A00
	v_cndmask_b32_e32 v1, v3, v0, vcc_lo                       // 0000007BF2A0: 02020103
	v_add3_u32 v2, v5, v2, 0x7fff                              // 0000007BF2A4: D6550002 03FE0505 00007FFF
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007BF2B0: BF870003
	v_add_co_ci_u32_e64 v1, null, v4, v1, vcc_lo               // 0000007BF2B4: D5207C01 01AA0304
	global_store_d16_hi_b16 v[0:1], v2, off                    // 0000007BF2BC: DC960000 007C0200
	s_endpgm                                                   // 0000007BF2C4: BFB00000
		...

