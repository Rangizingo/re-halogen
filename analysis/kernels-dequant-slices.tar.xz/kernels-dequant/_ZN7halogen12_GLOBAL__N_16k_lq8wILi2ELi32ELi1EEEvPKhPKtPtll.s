00000000002e2200 <_ZN7halogen12_GLOBAL__N_16k_lq8wILi2ELi32ELi1EEEvPKhPKtPtll>:
; _ZN7halogen12_GLOBAL__N_16k_lq8wILi2ELi32ELi1EEEvPKhPKtPtll():
	s_clause 0x1                                               // 0000002E2200: BF850001
	s_load_b64 s[12:13], s[0:1], 0x20                          // 0000002E2204: F4040300 F8000020
	s_load_b256 s[4:11], s[0:1], null                          // 0000002E220C: F40C0100 F8000000
	v_lshrrev_b32_e32 v1, 5, v0                                // 0000002E2214: 32020085
	s_mov_b32 s3, 0                                            // 0000002E2218: BE830080
	v_dual_mov_b32 v16, 0 :: v_dual_and_b32 v15, 31, v0        // 0000002E221C: CA240080 100E009F
	s_lshl_b64 s[0:1], s[2:3], 3                               // 0000002E2224: 84808302
	v_mov_b32_e32 v20, 0                                       // 0000002E2228: 7E280280
	v_or_b32_e32 v9, s0, v1                                    // 0000002E222C: 38120200
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000002E2230: BF870133
	v_dual_mov_b32 v10, s1 :: v_dual_lshlrev_b32 v11, 4, v15   // 0000002E2234: CA220001 0A0A1E84
	v_mov_b32_e32 v3, 0                                        // 0000002E223C: 7E060280
	s_waitcnt lgkmcnt(0)                                       // 0000002E2240: BF89FC07
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[9:10]                 // 0000002E2244: 7CA8120C
	s_ashr_i32 s0, s11, 31                                     // 0000002E2248: 86009F0B
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000002E224C: BF870499
	s_lshr_b32 s0, s0, 28                                      // 0000002E2250: 85009C00
	s_add_u32 s2, s10, s0                                      // 0000002E2254: 8002000A
	s_addc_u32 s3, s11, 0                                      // 0000002E2258: 8203800B
	v_cndmask_b32_e32 v1, 0, v9, vcc_lo                        // 0000002E225C: 02021280
	v_cndmask_b32_e64 v2, 0, s1, vcc_lo                        // 0000002E2260: D5010002 01A80280
	s_ashr_i64 s[2:3], s[2:3], 4                               // 0000002E2268: 86828402
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002E226C: BF8700A9
	s_add_u32 s0, s2, s10                                      // 0000002E2270: 80000A02
	s_addc_u32 s1, s3, s11                                     // 0000002E2274: 82010B03
	.long 0xd72c0004                                           // 0000002E2278: D72C0004
	v_cndmask_b32_e32 v0, v2, v0, vcc_lo                       // 0000002E227C: 02000102
	v_mad_u64_u32 v[5:6], null, v1, s0, 0                      // 0000002E2280: D6FE7C05 02000101
	.long 0xd72c0007                                           // 0000002E2288: D72C0007
	v_cndmask_b32_e32 v0, v1, v1, vcc_lo                       // 0000002E228C: 02000301
	v_dual_mov_b32 v1, 0 :: v_dual_mov_b32 v2, 0               // 0000002E2290: CA100080 01020080
	.long 0xd4440000                                           // 0000002E2298: D4440000
	v_cndmask_b32_e32 v1, s2, v15, vcc_lo                      // 0000002E229C: 02021E02
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002E22A0: BF870214
	.long 0xd7000111                                           // 0000002E22A4: D7000111
	v_cndmask_b32_e32 v1, s4, v5, vcc_lo                       // 0000002E22A8: 02020A04
	v_add3_u32 v6, v6, v7, v4                                  // 0000002E22AC: D6550006 04120F06
	v_mov_b32_e32 v4, 0                                        // 0000002E22B4: 7E080280
	s_delay_alu instid0(VALU_DEP_2)                            // 0000002E22B8: BF870002
	v_add_co_ci_u32_e64 v18, null, s5, v6, s1                  // 0000002E22BC: D5207C12 00060C05
	s_and_saveexec_b32 s3, s0                                  // 0000002E22C4: BE832000
	s_cbranch_execz 21                                         // 0000002E22C8: BFA50015 <_ZN7halogen12_GLOBAL__N_16k_lq8wILi2ELi32ELi1EEEvPKhPKtPtll+0x120>
	v_lshlrev_b32_e32 v1, 4, v15                               // 0000002E22CC: 30021E84
	.long 0xd7000103                                           // 0000002E22D0: D7000103
	v_cndmask_b32_e32 v0, v17, v10, vcc_lo                     // 0000002E22D4: 02001511
	v_and_b32_e32 v7, 28, v0                                   // 0000002E22D8: 360E009C
	v_add_co_ci_u32_e64 v4, null, s11, v18, s1                 // 0000002E22DC: D5207C04 0006240B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002E22E4: BF870094
	.long 0xd7000101                                           // 0000002E22E8: D7000101
	v_cndmask_b32_e32 v1, v17, v1, vcc_lo                      // 0000002E22EC: 02020311
	v_add_co_ci_u32_e64 v2, null, 0, v18, s1                   // 0000002E22F0: D5207C02 00062480
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002E22F8: BF870094
	.long 0xd7000107                                           // 0000002E22FC: D7000107
	v_cndmask_b32_e32 v1, v3, v7, vcc_lo                       // 0000002E2300: 02020F03
	v_add_co_ci_u32_e64 v8, null, 0, v4, s1                    // 0000002E2304: D5207C08 00060880
	s_clause 0x1                                               // 0000002E230C: BF850001
	global_load_b128 v[1:4], v[1:2], off                       // 0000002E2310: DC5E0000 017C0001
	global_load_b32 v20, v[7:8], off                           // 0000002E2318: DC520000 147C0007
	s_or_b32 exec_lo, exec_lo, s3                              // 0000002E2320: 8C7E037E
	v_mov_b32_e32 v19, 0                                       // 0000002E2324: 7E260280
	s_and_saveexec_b32 s3, s0                                  // 0000002E2328: BE832000
	s_cbranch_execz 301                                        // 0000002E232C: BFA5012D <_ZN7halogen12_GLOBAL__N_16k_lq8wILi2ELi32ELi1EEEvPKhPKtPtll+0x5e4>
	v_and_or_b32 v0, v0, 28, 32                                // 0000002E2330: D6570000 02813900
	.long 0xd7000005                                           // 0000002E2338: D7000005
	v_cndmask_b32_e32 v1, s10, v5, vcc_lo                      // 0000002E233C: 02020A0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000002E2340: BF8701A1
	v_add_co_ci_u32_e64 v6, null, s11, v6, s0                  // 0000002E2344: D5207C06 00020C0B
	v_mov_b32_e32 v12, 0                                       // 0000002E234C: 7E180280
	.long 0xd7000000                                           // 0000002E2350: D7000000
	v_cndmask_b32_e32 v1, v5, v0, vcc_lo                       // 0000002E2354: 02020105
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002E2358: BF870191
	v_add_co_ci_u32_e64 v5, null, 0, v6, s0                    // 0000002E235C: D5207C05 00020C80
	v_mov_b32_e32 v19, v12                                     // 0000002E2364: 7E26030C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002E2368: BF870093
	.long 0xd700000d                                           // 0000002E236C: D700000D
	v_cndmask_b32_e32 v1, s4, v0, vcc_lo                       // 0000002E2370: 02020004
	v_add_co_ci_u32_e64 v14, null, s5, v5, s0                  // 0000002E2374: D5207C0E 00020A05
	v_mov_b32_e32 v0, v15                                      // 0000002E237C: 7E00030F
	v_mov_b32_e32 v16, v12                                     // 0000002E2380: 7E20030C
	s_mov_b32 s14, 0                                           // 0000002E2384: BE8E0080
	s_lshl_b64 s[4:5], s[10:11], 1                             // 0000002E2388: 8484810A
	s_branch 247                                               // 0000002E238C: BFA000F7 <_ZN7halogen12_GLOBAL__N_16k_lq8wILi2ELi32ELi1EEEvPKhPKtPtll+0x56c>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000002E2390: 8C7E0A7E
	.long 0xd73c0017                                           // 0000002E2394: D73C0017
	v_cndmask_b32_e32 v1, 1, v11, vcc_lo                       // 0000002E2398: 02021681
	v_cvt_f32_ubyte0_e32 v11, v1                               // 0000002E239C: 7E162301
	v_cvt_f32_ubyte1_e32 v40, v1                               // 0000002E23A0: 7E502501
	v_cvt_f32_ubyte2_e32 v41, v1                               // 0000002E23A4: 7E522701
	v_cvt_f32_ubyte3_e32 v1, v1                                // 0000002E23A8: 7E022901
	v_cvt_f32_ubyte0_e32 v42, v2                               // 0000002E23AC: 7E542302
	.long 0xd700011f                                           // 0000002E23B0: D700011F
	v_cndmask_b32_e32 v1, s6, v23, vcc_lo                      // 0000002E23B4: 02022E06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000002E23B8: BF8701A1
	v_add_co_ci_u32_e64 v32, null, s7, v24, s1                 // 0000002E23BC: D5207C20 00063007
	v_cvt_f32_ubyte1_e32 v43, v2                               // 0000002E23C4: 7E562502
	.long 0xd7000123                                           // 0000002E23C8: D7000123
	v_cndmask_b32_e32 v0, v31, v4, vcc_lo                      // 0000002E23CC: 0200091F
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002E23D0: BF870001
	v_add_co_ci_u32_e64 v36, null, s5, v32, s1                 // 0000002E23D4: D5207C24 00064005
	v_cvt_f32_ubyte2_e32 v44, v2                               // 0000002E23DC: 7E582702
	v_cvt_f32_ubyte3_e32 v2, v2                                // 0000002E23E0: 7E042902
	s_clause 0x3                                               // 0000002E23E4: BF850003
	global_load_b128 v[23:26], v[31:32], off                   // 0000002E23E8: DC5E0000 177C001F
	global_load_b128 v[27:30], v[35:36], off                   // 0000002E23F0: DC5E0000 1B7C0023
	global_load_b128 v[31:34], v[31:32], off offset:16         // 0000002E23F8: DC5E0010 1F7C001F
	global_load_b128 v[35:38], v[35:36], off offset:16         // 0000002E2400: DC5E0010 237C0023
	v_cvt_f32_ubyte0_e32 v45, v3                               // 0000002E2408: 7E5A2303
	v_cvt_f32_ubyte1_e32 v46, v3                               // 0000002E240C: 7E5C2503
	v_cvt_f32_ubyte2_e32 v47, v3                               // 0000002E2410: 7E5E2703
	v_cvt_f32_ubyte3_e32 v3, v3                                // 0000002E2414: 7E062903
	v_cvt_f32_ubyte0_e32 v48, v4                               // 0000002E2418: 7E602304
	v_cvt_f32_ubyte1_e32 v49, v4                               // 0000002E241C: 7E622504
	v_cvt_f32_ubyte2_e32 v50, v4                               // 0000002E2420: 7E642704
	v_cvt_f32_ubyte3_e32 v4, v4                                // 0000002E2424: 7E082904
	v_fma_mix_f32 v11, v11, v20, v20 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002E2428: CC20600B 1452290B
	v_fma_mix_f32 v40, v40, v20, v20 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002E2430: CC206028 14522928
	v_fma_mix_f32 v41, v41, v20, v20 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002E2438: CC206029 14522929
	v_fma_mix_f32 v1, v1, v20, v20 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002E2440: CC206001 14522901
	v_fma_mix_f32 v42, v42, v20, v20 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002E2448: CC20602A 1452292A
	v_fma_mix_f32 v43, v43, v20, v20 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002E2450: CC20602B 1452292B
	v_fma_mix_f32 v44, v44, v20, v20 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002E2458: CC20602C 1452292C
	v_fma_mix_f32 v2, v2, v20, v20 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002E2460: CC206002 14522902
	v_fma_mix_f32 v45, v45, v20, v20 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002E2468: CC20602D 1452292D
	v_fma_mix_f32 v46, v46, v20, v20 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002E2470: CC20602E 1452292E
	v_fma_mix_f32 v47, v47, v20, v20 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002E2478: CC20602F 1452292F
	v_fma_mix_f32 v3, v3, v20, v20 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002E2480: CC206003 14522903
	v_fma_mix_f32 v48, v48, v20, v20 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002E2488: CC206030 14522930
	v_fma_mix_f32 v49, v49, v20, v20 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002E2490: CC206031 14522931
	v_fma_mix_f32 v50, v50, v20, v20 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002E2498: CC206032 14522932
	v_fma_mix_f32 v4, v4, v20, v20 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002E24A0: CC206004 14522904
	v_bfe_u32 v20, v11, 16, 1                                  // 0000002E24A8: D6100014 0205210B
	v_bfe_u32 v55, v40, 16, 1                                  // 0000002E24B0: D6100037 02052128
	v_bfe_u32 v56, v41, 16, 1                                  // 0000002E24B8: D6100038 02052129
	.long 0x7f4e3880                                           // 0000002E24C0: 7F4E3880
	v_bfe_u32 v57, v1, 16, 1                                   // 0000002E24C4: D6100039 02052101
	v_add3_u32 v11, v11, v20, 0x7fff                           // 0000002E24CC: D655000B 03FE290B 00007FFF
	v_bfe_u32 v58, v42, 16, 1                                  // 0000002E24D8: D610003A 0205212A
	v_add3_u32 v20, v40, v55, 0x7fff                           // 0000002E24E0: D6550014 03FE6F28 00007FFF
	v_add3_u32 v40, v41, v56, 0x7fff                           // 0000002E24EC: D6550028 03FE7129 00007FFF
	.long 0x7f6639a7                                           // 0000002E24F8: 7F6639A7
	.long 0x7e4e398b                                           // 0000002E24FC: 7E4E398B
	v_bfe_u32 v59, v43, 16, 1                                  // 0000002E2500: D610003B 0205212B
	v_bfe_u32 v60, v44, 16, 1                                  // 0000002E2508: D610003C 0205212C
	v_add3_u32 v1, v1, v57, 0x7fff                             // 0000002E2510: D6550001 03FE7301 00007FFF
	v_add3_u32 v41, v42, v58, 0x7fff                           // 0000002E251C: D6550029 03FE752A 00007FFF
	.long 0x7e6639a8                                           // 0000002E2528: 7E6639A8
	v_and_or_b32 v20, 0xffff0000, v20, v39                     // 0000002E252C: D6570014 049E28FF FFFF0000
	v_bfe_u32 v61, v2, 16, 1                                   // 0000002E2538: D610003D 02052102
	v_bfe_u32 v62, v45, 16, 1                                  // 0000002E2540: D610003E 0205212D
	v_add3_u32 v42, v43, v59, 0x7fff                           // 0000002E2548: D655002A 03FE772B 00007FFF
	v_add3_u32 v11, v44, v60, 0x7fff                           // 0000002E2554: D655000B 03FE792C 00007FFF
	v_and_or_b32 v1, 0xffff0000, v1, v51                       // 0000002E2560: D6570001 04CE02FF FFFF0000
	.long 0x7e4e39a9                                           // 0000002E256C: 7E4E39A9
	.long 0x7f6839a7                                           // 0000002E2570: 7F6839A7
	v_bfe_u32 v63, v46, 16, 1                                  // 0000002E2574: D610003F 0205212E
	v_bfe_u32 v64, v47, 16, 1                                  // 0000002E257C: D6100040 0205212F
	v_add3_u32 v2, v2, v61, 0x7fff                             // 0000002E2584: D6550002 03FE7B02 00007FFF
	v_add3_u32 v40, v45, v62, 0x7fff                           // 0000002E2590: D6550028 03FE7D2D 00007FFF
	.long 0x7e68398b                                           // 0000002E259C: 7E68398B
	v_and_or_b32 v11, 0xffff0000, v42, v39                     // 0000002E25A0: D657000B 049E54FF FFFF0000
	v_bfe_u32 v65, v3, 16, 1                                   // 0000002E25AC: D6100041 02052103
	v_bfe_u32 v66, v48, 16, 1                                  // 0000002E25B4: D6100042 02052130
	v_add3_u32 v43, v46, v63, 0x7fff                           // 0000002E25BC: D655002B 03FE7F2E 00007FFF
	v_add3_u32 v44, v47, v64, 0x7fff                           // 0000002E25C8: D655002C 03FE812F 00007FFF
	v_and_or_b32 v2, 0xffff0000, v2, v52                       // 0000002E25D4: D6570002 04D204FF FFFF0000
	.long 0x7e4e39a8                                           // 0000002E25E0: 7E4E39A8
	.long 0x7f6a39a7                                           // 0000002E25E4: 7F6A39A7
	v_bfe_u32 v67, v49, 16, 1                                  // 0000002E25E8: D6100043 02052131
	v_bfe_u32 v68, v50, 16, 1                                  // 0000002E25F0: D6100044 02052132
	v_add3_u32 v3, v3, v65, 0x7fff                             // 0000002E25F8: D6550003 03FE8303 00007FFF
	.long 0x7e6a39ac                                           // 0000002E2604: 7E6A39AC
	v_bfe_u32 v69, v4, 16, 1                                   // 0000002E2608: D6100045 02052104
	.long 0x7f6c39a7                                           // 0000002E2610: 7F6C39A7
	s_and_b32 s1, exec_lo, s0                                  // 0000002E2614: 8B01007E
	.long 0xd700000d                                           // 0000002E2618: D700000D
	v_cndmask_b32_e32 v0, v13, v160, vcc_lo                    // 0000002E261C: 0201410D
	v_and_or_b32 v3, 0xffff0000, v3, v53                       // 0000002E2620: D6570003 04D606FF FFFF0000
	v_add3_u32 v4, v4, v69, 0x7fff                             // 0000002E262C: D6550004 03FE8B04 00007FFF
	v_add_co_ci_u32_e64 v14, null, 0, v14, s0                  // 0000002E2638: D5207C0E 00021C80
	s_or_b32 s14, s1, s14                                      // 0000002E2640: 8C0E0E01
	s_waitcnt vmcnt(3)                                         // 0000002E2644: BF890FF7
	v_dot2_f32_bf16 v23, v23, v20, 0                           // 0000002E2648: CC1A4017 1A022917
	s_waitcnt vmcnt(2)                                         // 0000002E2650: BF890BF7
	v_dot2_f32_bf16 v20, v27, v20, 0                           // 0000002E2654: CC1A4014 1A02291B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002E265C: BF870112
	v_dot2_f32_bf16 v23, v24, v1, v23                          // 0000002E2660: CC1A4017 1C5E0318
	v_dot2_f32_bf16 v1, v28, v1, v20                           // 0000002E2668: CC1A4001 1C52031C
	v_add3_u32 v20, v48, v66, 0x7fff                           // 0000002E2670: D6550014 03FE8530 00007FFF
	v_and_or_b32 v24, 0xffff0000, v43, v39                     // 0000002E267C: D6570018 049E56FF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002E2688: BF870214
	v_dot2_f32_bf16 v23, v25, v11, v23                         // 0000002E268C: CC1A4017 1C5E1719
	v_dot2_f32_bf16 v1, v29, v11, v1                           // 0000002E2694: CC1A4001 1C06171D
	v_add3_u32 v11, v49, v67, 0x7fff                           // 0000002E269C: D655000B 03FE8731 00007FFF
	.long 0x7e4e3994                                           // 0000002E26A8: 7E4E3994
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002E26AC: BF870214
	v_dot2_f32_bf16 v23, v26, v2, v23                          // 0000002E26B0: CC1A4017 1C5E051A
	v_dot2_f32_bf16 v1, v30, v2, v1                            // 0000002E26B8: CC1A4001 1C06051E
	v_add3_u32 v2, v50, v68, 0x7fff                            // 0000002E26C0: D6550002 03FE8932 00007FFF
	s_waitcnt vmcnt(1)                                         // 0000002E26CC: BF8907F7
	s_delay_alu instid0(VALU_DEP_3)                            // 0000002E26D0: BF870003
	v_dot2_f32_bf16 v20, v31, v24, v23                         // 0000002E26D4: CC1A4014 1C5E311F
	s_waitcnt vmcnt(0)                                         // 0000002E26DC: BF8903F7
	v_dot2_f32_bf16 v1, v35, v24, v1                           // 0000002E26E0: CC1A4001 1C063123
	.long 0x7e6c3982                                           // 0000002E26E8: 7E6C3982
	v_and_or_b32 v2, 0xffff0000, v11, v39                      // 0000002E26EC: D6570002 049E16FF FFFF0000
	v_dot2_f32_bf16 v11, v32, v3, v20                          // 0000002E26F8: CC1A400B 1C520720
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002E2700: BF870214
	v_dot2_f32_bf16 v1, v36, v3, v1                            // 0000002E2704: CC1A4001 1C060724
	v_and_or_b32 v3, 0xffff0000, v4, v54                       // 0000002E270C: D6570003 04DA08FF FFFF0000
	v_mov_b32_e32 v4, v8                                       // 0000002E2718: 7E080308
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002E271C: BF870214
	v_dot2_f32_bf16 v20, v33, v2, v11                          // 0000002E2720: CC1A4014 1C2E0521
	v_dot2_f32_bf16 v1, v37, v2, v1                            // 0000002E2728: CC1A4001 1C060525
	v_dual_mov_b32 v11, v21 :: v_dual_mov_b32 v2, v6           // 0000002E2730: CA100115 0B020106
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002E2738: BF870193
	v_dot2_f32_bf16 v8, v34, v3, v20                           // 0000002E273C: CC1A4008 1C520722
	v_dot2_f32_bf16 v20, v38, v3, v1                           // 0000002E2744: CC1A4014 1C060726
	v_mov_b32_e32 v3, v7                                       // 0000002E274C: 7E060307
	v_mov_b32_e32 v1, v5                                       // 0000002E2750: 7E020305
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002E2754: BF870214
	v_add_f32_e32 v19, v19, v8                                 // 0000002E2758: 06261113
	v_add_f32_e32 v16, v16, v20                                // 0000002E275C: 06202910
	v_mov_b32_e32 v20, v22                                     // 0000002E2760: 7E280316
	s_and_not1_b32 exec_lo, exec_lo, s14                       // 0000002E2764: 917E0E7E
	s_cbranch_execz 29                                         // 0000002E2768: BFA5001D <_ZN7halogen12_GLOBAL__N_16k_lq8wILi2ELi32ELi1EEEvPKhPKtPtll+0x5e0>
	v_add_nc_u32_e32 v0, 32, v0                                // 0000002E276C: 4A0000A0
	v_add_nc_u32_e32 v21, 0x200, v11                           // 0000002E2770: 4A2A16FF 00000200
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000002E2778: BF8704A2
	.long 0xd4430000                                           // 0000002E277C: D4430000
	v_cndmask_b32_e32 v1, s2, v0, vcc_lo                       // 0000002E2780: 02020002
	s_and_saveexec_b32 s1, s0                                  // 0000002E2784: BE812000
	s_xor_b32 s1, exec_lo, s1                                  // 0000002E2788: 8D01017E
	v_add_nc_u32_e32 v21, 0x200, v11                           // 0000002E278C: 4A2A16FF 00000200
	s_or_saveexec_b32 s10, s1                                  // 0000002E2794: BE8A2201
	s_waitcnt vmcnt(0)                                         // 0000002E2798: BF8903F7
	v_dual_mov_b32 v22, v20 :: v_dual_mov_b32 v5, v1           // 0000002E279C: CA100114 16040101
	v_dual_mov_b32 v6, v2 :: v_dual_mov_b32 v7, v3             // 0000002E27A4: CA100102 06060103
	v_mov_b32_e32 v8, v4                                       // 0000002E27AC: 7E100304
	s_xor_b32 exec_lo, exec_lo, s10                            // 0000002E27B0: 8D7E0A7E
	s_cbranch_execz 65270                                      // 0000002E27B4: BFA5FEF6 <_ZN7halogen12_GLOBAL__N_16k_lq8wILi2ELi32ELi1EEEvPKhPKtPtll+0x190>
	.long 0xd7000105                                           // 0000002E27B8: D7000105
	v_cndmask_b32_e32 v1, v17, v21, vcc_lo                     // 0000002E27BC: 02022B11
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002E27C0: BF870001
	v_add_co_ci_u32_e64 v6, null, 0, v18, s1                   // 0000002E27C4: D5207C06 00062480
	global_load_b128 v[5:8], v[5:6], off                       // 0000002E27CC: DC5E0000 057C0005
	global_load_b32 v22, v[13:14], off                         // 0000002E27D4: DC520000 167C000D
	s_branch 65260                                             // 0000002E27DC: BFA0FEEC <_ZN7halogen12_GLOBAL__N_16k_lq8wILi2ELi32ELi1EEEvPKhPKtPtll+0x190>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000002E27E0: 8C7E0E7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000002E27E4: BF8700B9
	s_or_b32 exec_lo, exec_lo, s3                              // 0000002E27E8: 8C7E037E
	.long 0xd71f0000                                           // 0000002E27EC: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000002E27F0: 020100C1
	s_waitcnt vmcnt(1)                                         // 0000002E27F4: BF8907F7
	v_xor_b32_e32 v1, 16, v0                                   // 0000002E27F8: 3A020090
	v_xor_b32_e32 v3, 8, v0                                    // 0000002E27FC: 3A060088
	v_xor_b32_e32 v5, 4, v0                                    // 0000002E2800: 3A0A0084
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002E2804: BF870093
	.long 0xd44c0000                                           // 0000002E2808: D44C0000
	v_cndmask_b32_e32 v1, 32, v1, vcc_lo                       // 0000002E280C: 020202A0
	v_cndmask_b32_e64 v1, v0, v1, s0                           // 0000002E2810: D5010001 00020300
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002E2818: BF870114
	.long 0xd44c0000                                           // 0000002E281C: D44C0000
	v_cndmask_b32_e32 v1, 32, v3, vcc_lo                       // 0000002E2820: 020206A0
	v_lshlrev_b32_e32 v1, 2, v1                                // 0000002E2824: 30020282
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000002E2828: BF8700D2
	v_cndmask_b32_e64 v3, v0, v3, s0                           // 0000002E282C: D5010003 00020700
	.long 0xd44c0000                                           // 0000002E2834: D44C0000
	v_cndmask_b32_e32 v1, 32, v5, vcc_lo                       // 0000002E2838: 02020AA0
	ds_bpermute_b32 v2, v1, v19                                // 0000002E283C: DACC0000 02001301
	v_cndmask_b32_e64 v5, v0, v5, s0                           // 0000002E2844: D5010005 00020B00
	s_waitcnt lgkmcnt(0)                                       // 0000002E284C: BF89FC07
	v_dual_add_f32 v2, v19, v2 :: v_dual_lshlrev_b32 v5, 2, v5 // 0000002E2850: C9220513 02040A82
	v_lshlrev_b32_e32 v3, 2, v3                                // 0000002E2858: 30060682
	ds_bpermute_b32 v1, v1, v16                                // 0000002E285C: DACC0000 01001001
	ds_bpermute_b32 v4, v3, v2                                 // 0000002E2864: DACC0000 04000203
	s_waitcnt lgkmcnt(0)                                       // 0000002E286C: BF89FC07
	v_dual_add_f32 v2, v2, v4 :: v_dual_add_f32 v1, v16, v1    // 0000002E2870: C9080902 02000310
	ds_bpermute_b32 v3, v3, v1                                 // 0000002E2878: DACC0000 03000103
	s_waitcnt lgkmcnt(0)                                       // 0000002E2880: BF89FC07
	v_add_f32_e32 v1, v1, v3                                   // 0000002E2884: 06020701
	ds_bpermute_b32 v3, v5, v2                                 // 0000002E2888: DACC0000 03000205
	ds_bpermute_b32 v4, v5, v1                                 // 0000002E2890: DACC0000 04000105
	v_xor_b32_e32 v5, 2, v0                                    // 0000002E2898: 3A0A0082
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002E289C: BF870091
	.long 0xd44c0000                                           // 0000002E28A0: D44C0000
	v_cndmask_b32_e32 v1, 32, v5, vcc_lo                       // 0000002E28A4: 02020AA0
	v_cndmask_b32_e64 v5, v0, v5, s0                           // 0000002E28A8: D5010005 00020B00
	s_waitcnt lgkmcnt(0)                                       // 0000002E28B0: BF89FC07
	v_dual_add_f32 v2, v2, v3 :: v_dual_add_f32 v1, v1, v4     // 0000002E28B4: C9080702 02000901
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000002E28BC: BF8700C2
	v_lshlrev_b32_e32 v5, 2, v5                                // 0000002E28C0: 300A0A82
	ds_bpermute_b32 v3, v5, v2                                 // 0000002E28C4: DACC0000 03000205
	ds_bpermute_b32 v4, v5, v1                                 // 0000002E28CC: DACC0000 04000105
	v_xor_b32_e32 v5, 1, v0                                    // 0000002E28D4: 3A0A0081
	.long 0xd44c0000                                           // 0000002E28D8: D44C0000
	v_cndmask_b32_e32 v1, 32, v5, vcc_lo                       // 0000002E28DC: 02020AA0
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002E28E0: BF870121
	v_cndmask_b32_e64 v0, v0, v5, s0                           // 0000002E28E4: D5010000 00020B00
	.long 0xd44a0000                                           // 0000002E28EC: D44A0000
	v_cndmask_b32_e32 v1, 0, v15, vcc_lo                       // 0000002E28F0: 02021E80
	v_lshlrev_b32_e32 v5, 2, v0                                // 0000002E28F4: 300A0082
	s_and_b32 s0, s0, vcc_lo                                   // 0000002E28F8: 8B006A00
	s_waitcnt lgkmcnt(1)                                       // 0000002E28FC: BF89FC17
	v_add_f32_e32 v2, v2, v3                                   // 0000002E2900: 06040702
	s_waitcnt lgkmcnt(0)                                       // 0000002E2904: BF89FC07
	v_add_f32_e32 v0, v1, v4                                   // 0000002E2908: 06000901
	ds_bpermute_b32 v3, v5, v2                                 // 0000002E290C: DACC0000 03000205
	ds_bpermute_b32 v1, v5, v0                                 // 0000002E2914: DACC0000 01000005
	s_and_saveexec_b32 s1, s0                                  // 0000002E291C: BE812000
	s_cbranch_execz 35                                         // 0000002E2920: BFA50023 <_ZN7halogen12_GLOBAL__N_16k_lq8wILi2ELi32ELi1EEEvPKhPKtPtll+0x7b0>
	s_waitcnt lgkmcnt(1)                                       // 0000002E2924: BF89FC17
	v_add_f32_e32 v2, v2, v3                                   // 0000002E2928: 06040702
	.long 0x7f063880                                           // 0000002E292C: 7F063880
	s_waitcnt lgkmcnt(0)                                       // 0000002E2930: BF89FC07
	v_add_f32_e32 v4, v0, v1                                   // 0000002E2934: 06080300
	.long 0xd73c0000                                           // 0000002E2938: D73C0000
	v_cndmask_b32_e32 v1, 1, v9, vcc_lo                        // 0000002E293C: 02021281
	s_lshl_b64 s[0:1], s[12:13], 1                             // 0000002E2940: 8480810C
	.long 0x7e0a3982                                           // 0000002E2944: 7E0A3982
	.long 0x7f0a3983                                           // 0000002E2948: 7F0A3983
	.long 0x7e063984                                           // 0000002E294C: 7E063984
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002E2950: BF870194
	.long 0xd7006a00                                           // 0000002E2954: D7006A00
	v_cndmask_b32_e32 v1, s8, v0, vcc_lo                       // 0000002E2958: 02020008
	v_and_b32_e32 v5, 1, v5                                    // 0000002E295C: 360A0A81
	v_add_co_ci_u32_e64 v1, null, s9, v1, vcc_lo               // 0000002E2960: D5207C01 01AA0209
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002E2968: BF870194
	v_and_b32_e32 v6, 1, v3                                    // 0000002E296C: 360C0681
	v_add3_u32 v5, v2, v5, 0x7fff                              // 0000002E2970: D6550005 03FE0B02 00007FFF
	.long 0xd7006a02                                           // 0000002E297C: D7006A02
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 0000002E2980: 02000100
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002E2984: BF870211
	v_add_co_ci_u32_e64 v3, null, s1, v1, vcc_lo               // 0000002E2988: D5207C03 01AA0201
	v_add3_u32 v4, v4, v6, 0x7fff                              // 0000002E2990: D6550004 03FE0D04 00007FFF
	s_clause 0x1                                               // 0000002E299C: BF850001
	global_store_d16_hi_b16 v[0:1], v5, off                    // 0000002E29A0: DC960000 007C0500
	global_store_d16_hi_b16 v[2:3], v4, off                    // 0000002E29A8: DC960000 007C0402
	s_endpgm                                                   // 0000002E29B0: BFB00000
		...

