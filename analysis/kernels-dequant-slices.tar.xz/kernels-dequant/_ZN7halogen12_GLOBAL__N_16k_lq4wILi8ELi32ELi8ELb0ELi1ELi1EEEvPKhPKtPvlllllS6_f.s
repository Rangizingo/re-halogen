00000000007ea300 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi8ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi8ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[8:23], s[0:1], null                          // 0000007EA300: F4100200 F8000000
	s_ashr_i32 s3, s2, 31                                      // 0000007EA308: 86039F02
	v_lshrrev_b32_e32 v2, 2, v0                                // 0000007EA30C: 32040082
	v_lshrrev_b32_e32 v29, 5, v0                               // 0000007EA310: 323A0085
	v_and_b32_e32 v30, 31, v0                                  // 0000007EA314: 363C009F
	.long 0x7f0a3880                                           // 0000007EA318: 7F0A3880
	v_lshlrev_b32_e32 v28, 2, v0                               // 0000007EA31C: 30380082
	s_waitcnt lgkmcnt(0)                                       // 0000007EA320: BF89FC07
	.long 0xd4510004                                           // 0000007EA324: D4510004
	v_cndmask_b32_e32 v0, s2, v16, vcc_lo                      // 0000007EA328: 02002002
	s_and_b32 s4, s4, exec_lo                                  // 0000007EA32C: 8B047E04
	s_cselect_b32 s6, s3, 0                                    // 0000007EA330: 98068003
	s_cselect_b32 s7, s2, 0                                    // 0000007EA334: 98078002
	s_add_u32 s4, s8, s20                                      // 0000007EA338: 80041408
	s_addc_u32 s5, s9, s21                                     // 0000007EA33C: 82051509
	v_and_b32_e32 v1, 15, v0                                   // 0000007EA340: 3602008F
	v_and_b32_e32 v2, 60, v2                                   // 0000007EA344: 360404BC
	s_ashr_i32 s20, s15, 31                                    // 0000007EA348: 86149F0F
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007EA34C: BF870119
	s_lshr_b32 s20, s20, 27                                    // 0000007EA350: 85149B14
	v_lshlrev_b32_e32 v1, 2, v1                                // 0000007EA354: 30020282
	s_add_u32 s20, s14, s20                                    // 0000007EA358: 8014140E
	s_clause 0x1                                               // 0000007EA35C: BF850001
	global_load_b32 v3, v1, s[8:9]                             // 0000007EA360: DC520000 03080001
	global_load_b32 v4, v2, s[8:9]                             // 0000007EA368: DC520000 04080002
	s_addc_u32 s21, s15, 0                                     // 0000007EA370: 8215800F
	v_mov_b32_e32 v1, s4                                       // 0000007EA374: 7E020204
	s_lshr_b64 s[20:21], s[20:21], 5                           // 0000007EA378: 85948514
	v_mov_b32_e32 v2, s5                                       // 0000007EA37C: 7E040205
	s_add_i32 s21, s20, 7                                      // 0000007EA380: 81158714
	s_mul_i32 s5, s23, s7                                      // 0000007EA384: 96050717
	s_ashr_i32 s24, s21, 31                                    // 0000007EA388: 86189F15
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000007EA38C: BF8704B9
	s_lshr_b32 s4, s24, 29                                     // 0000007EA390: 85049D18
	v_mad_u64_u32 v[24:25], null, s22, s7, v[1:2]              // 0000007EA394: D6FE7C18 04040E16
	s_add_i32 s21, s21, s4                                     // 0000007EA39C: 81150415
	s_ashr_i32 s4, s21, 3                                      // 0000007EA3A0: 86048315
	s_cmpk_lt_i32 s20, 0x801                                   // 0000007EA3A4: B3940801
	.long 0xd72c0001                                           // 0000007EA3A8: D72C0001
	v_cndmask_b32_e32 v1, s4, v29, vcc_lo                      // 0000007EA3AC: 02023A04
	s_mul_i32 s21, s22, s6                                     // 0000007EA3B0: 96150616
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000007EA3B4: BF870141
	v_add_nc_u32_e32 v7, s4, v1                                // 0000007EA3B8: 4A0E0204
	v_add_nc_u32_e32 v31, v1, v30                              // 0000007EA3BC: 4A3E3D01
	s_cselect_b32 s4, -1, 0                                    // 0000007EA3C0: 980480C1
	s_cmpk_gt_i32 s20, 0x800                                   // 0000007EA3C4: B2940800
	v_min_i32_e32 v32, s20, v7                                 // 0000007EA3C8: 22400E14
	s_cselect_b32 s20, -1, 0                                   // 0000007EA3CC: 981480C1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 0000007EA3D0: BF870159
	s_and_b32 vcc_lo, exec_lo, s20                             // 0000007EA3D4: 8B6A147E
	s_waitcnt vmcnt(1)                                         // 0000007EA3D8: BF8907F7
	v_bfe_u32 v2, v3, 16, 1                                    // 0000007EA3DC: D6100002 02052103
	s_waitcnt vmcnt(0)                                         // 0000007EA3E4: BF8903F7
	v_bfe_u32 v6, v4, 16, 1                                    // 0000007EA3E8: D6100006 02052104
	v_add3_u32 v2, v3, v2, 0x7fff                              // 0000007EA3F0: D6550002 03FE0503 00007FFF
	v_add_nc_u32_e32 v3, s5, v25                               // 0000007EA3FC: 4A063205
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000007EA400: BF870223
	v_add3_u32 v4, v4, v6, 0x7fff                              // 0000007EA404: D6550004 03FE0D04 00007FFF
	.long 0xd4410005                                           // 0000007EA410: D4410005
	v_cndmask_b32_e32 v1, v31, v32, vcc_lo                     // 0000007EA414: 0202411F
	.long 0x7e0a3982                                           // 0000007EA418: 7E0A3982
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007EA41C: BF870114
	v_add_nc_u32_e32 v33, s21, v3                              // 0000007EA420: 4A420615
	v_and_or_b32 v1, 0xffff0000, v4, v5                        // 0000007EA424: D6570001 041608FF FFFF0000
	ds_store_b32 v28, v1                                       // 0000007EA430: D8340000 0000011C
	s_waitcnt lgkmcnt(0)                                       // 0000007EA438: BF89FC07
	s_barrier                                                  // 0000007EA43C: BFBD0000
	buffer_gl0_inv                                             // 0000007EA440: E0AC0000 00000000
	s_cbranch_vccnz 154                                        // 0000007EA448: BFA4009A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi8ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x3b4>
	v_dual_mov_b32 v9, 0 :: v_dual_mov_b32 v8, 0               // 0000007EA44C: CA100080 09080080
	s_and_saveexec_b32 s21, s5                                 // 0000007EA454: BE952005
	s_cbranch_execz 11                                         // 0000007EA458: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi8ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x188>
	v_lshlrev_b32_e32 v1, 1, v31                               // 0000007EA45C: 30023E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007EA460: BF8700A1
	v_ashrrev_i32_e32 v2, 31, v1                               // 0000007EA464: 3404029F
	.long 0xd7006a01                                           // 0000007EA468: D7006A01
	v_cndmask_b32_e32 v1, v24, v1, vcc_lo                      // 0000007EA46C: 02020318
	v_add_co_ci_u32_e64 v2, null, v33, v2, vcc_lo              // 0000007EA470: D5207C02 01AA0521
	global_load_d16_b16 v1, v[1:2], off                        // 0000007EA478: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 0000007EA480: BF8903F7
	v_cvt_f32_f16_e32 v8, v1                                   // 0000007EA484: 7E101701
	s_or_b32 exec_lo, exec_lo, s21                             // 0000007EA488: 8C7E157E
	v_add_nc_u32_e32 v1, 32, v31                               // 0000007EA48C: 4A023EA0
	s_mov_b32 s5, exec_lo                                      // 0000007EA490: BE85007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007EA494: BF870001
	.long 0xd4c1007e                                           // 0000007EA498: D4C1007E
	v_cndmask_b32_e32 v1, v1, v32, vcc_lo                      // 0000007EA49C: 02024101
	s_cbranch_execz 11                                         // 0000007EA4A0: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi8ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x1d0>
	v_lshlrev_b32_e32 v1, 1, v1                                // 0000007EA4A4: 30020281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007EA4A8: BF8700A1
	v_ashrrev_i32_e32 v2, 31, v1                               // 0000007EA4AC: 3404029F
	.long 0xd7006a01                                           // 0000007EA4B0: D7006A01
	v_cndmask_b32_e32 v1, v24, v1, vcc_lo                      // 0000007EA4B4: 02020318
	v_add_co_ci_u32_e64 v2, null, v33, v2, vcc_lo              // 0000007EA4B8: D5207C02 01AA0521
	global_load_d16_b16 v1, v[1:2], off                        // 0000007EA4C0: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 0000007EA4C8: BF8903F7
	v_cvt_f32_f16_e32 v9, v1                                   // 0000007EA4CC: 7E121701
	s_or_b32 exec_lo, exec_lo, s5                              // 0000007EA4D0: 8C7E057E
	v_dual_mov_b32 v10, 0 :: v_dual_add_nc_u32 v1, 64, v31     // 0000007EA4D4: CA200080 0A003EC0
	v_mov_b32_e32 v11, 0                                       // 0000007EA4DC: 7E160280
	s_mov_b32 s5, exec_lo                                      // 0000007EA4E0: BE85007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007EA4E4: BF870002
	.long 0xd4c1007e                                           // 0000007EA4E8: D4C1007E
	v_cndmask_b32_e32 v1, v1, v32, vcc_lo                      // 0000007EA4EC: 02024101
	s_cbranch_execz 11                                         // 0000007EA4F0: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi8ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x220>
	v_lshlrev_b32_e32 v1, 1, v1                                // 0000007EA4F4: 30020281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007EA4F8: BF8700A1
	v_ashrrev_i32_e32 v2, 31, v1                               // 0000007EA4FC: 3404029F
	.long 0xd7006a01                                           // 0000007EA500: D7006A01
	v_cndmask_b32_e32 v1, v24, v1, vcc_lo                      // 0000007EA504: 02020318
	v_add_co_ci_u32_e64 v2, null, v33, v2, vcc_lo              // 0000007EA508: D5207C02 01AA0521
	global_load_d16_b16 v1, v[1:2], off                        // 0000007EA510: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 0000007EA518: BF8903F7
	v_cvt_f32_f16_e32 v10, v1                                  // 0000007EA51C: 7E141701
	s_or_b32 exec_lo, exec_lo, s5                              // 0000007EA520: 8C7E057E
	v_add_nc_u32_e32 v1, 0x60, v31                             // 0000007EA524: 4A023EFF 00000060
	s_mov_b32 s5, exec_lo                                      // 0000007EA52C: BE85007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007EA530: BF870001
	.long 0xd4c1007e                                           // 0000007EA534: D4C1007E
	v_cndmask_b32_e32 v1, v1, v32, vcc_lo                      // 0000007EA538: 02024101
	s_cbranch_execz 11                                         // 0000007EA53C: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi8ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x26c>
	v_lshlrev_b32_e32 v1, 1, v1                                // 0000007EA540: 30020281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007EA544: BF8700A1
	v_ashrrev_i32_e32 v2, 31, v1                               // 0000007EA548: 3404029F
	.long 0xd7006a01                                           // 0000007EA54C: D7006A01
	v_cndmask_b32_e32 v1, v24, v1, vcc_lo                      // 0000007EA550: 02020318
	v_add_co_ci_u32_e64 v2, null, v33, v2, vcc_lo              // 0000007EA554: D5207C02 01AA0521
	global_load_d16_b16 v1, v[1:2], off                        // 0000007EA55C: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 0000007EA564: BF8903F7
	v_cvt_f32_f16_e32 v11, v1                                  // 0000007EA568: 7E161701
	s_or_b32 exec_lo, exec_lo, s5                              // 0000007EA56C: 8C7E057E
	v_dual_mov_b32 v12, 0 :: v_dual_add_nc_u32 v1, 0x80, v31   // 0000007EA570: CA200080 0C003EFF 00000080
	v_mov_b32_e32 v13, 0                                       // 0000007EA57C: 7E1A0280
	s_mov_b32 s5, exec_lo                                      // 0000007EA580: BE85007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007EA584: BF870002
	.long 0xd4c1007e                                           // 0000007EA588: D4C1007E
	v_cndmask_b32_e32 v1, v1, v32, vcc_lo                      // 0000007EA58C: 02024101
	s_cbranch_execz 11                                         // 0000007EA590: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi8ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x2c0>
	v_lshlrev_b32_e32 v1, 1, v1                                // 0000007EA594: 30020281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007EA598: BF8700A1
	v_ashrrev_i32_e32 v2, 31, v1                               // 0000007EA59C: 3404029F
	.long 0xd7006a01                                           // 0000007EA5A0: D7006A01
	v_cndmask_b32_e32 v1, v24, v1, vcc_lo                      // 0000007EA5A4: 02020318
	v_add_co_ci_u32_e64 v2, null, v33, v2, vcc_lo              // 0000007EA5A8: D5207C02 01AA0521
	global_load_d16_b16 v1, v[1:2], off                        // 0000007EA5B0: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 0000007EA5B8: BF8903F7
	v_cvt_f32_f16_e32 v12, v1                                  // 0000007EA5BC: 7E181701
	s_or_b32 exec_lo, exec_lo, s5                              // 0000007EA5C0: 8C7E057E
	v_add_nc_u32_e32 v1, 0xa0, v31                             // 0000007EA5C4: 4A023EFF 000000A0
	s_mov_b32 s5, exec_lo                                      // 0000007EA5CC: BE85007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007EA5D0: BF870001
	.long 0xd4c1007e                                           // 0000007EA5D4: D4C1007E
	v_cndmask_b32_e32 v1, v1, v32, vcc_lo                      // 0000007EA5D8: 02024101
	s_cbranch_execz 11                                         // 0000007EA5DC: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi8ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x30c>
	v_lshlrev_b32_e32 v1, 1, v1                                // 0000007EA5E0: 30020281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007EA5E4: BF8700A1
	v_ashrrev_i32_e32 v2, 31, v1                               // 0000007EA5E8: 3404029F
	.long 0xd7006a01                                           // 0000007EA5EC: D7006A01
	v_cndmask_b32_e32 v1, v24, v1, vcc_lo                      // 0000007EA5F0: 02020318
	v_add_co_ci_u32_e64 v2, null, v33, v2, vcc_lo              // 0000007EA5F4: D5207C02 01AA0521
	global_load_d16_b16 v1, v[1:2], off                        // 0000007EA5FC: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 0000007EA604: BF8903F7
	v_cvt_f32_f16_e32 v13, v1                                  // 0000007EA608: 7E1A1701
	s_or_b32 exec_lo, exec_lo, s5                              // 0000007EA60C: 8C7E057E
	v_dual_mov_b32 v14, 0 :: v_dual_add_nc_u32 v1, 0xc0, v31   // 0000007EA610: CA200080 0E003EFF 000000C0
	v_mov_b32_e32 v15, 0                                       // 0000007EA61C: 7E1E0280
	s_mov_b32 s5, exec_lo                                      // 0000007EA620: BE85007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007EA624: BF870002
	.long 0xd4c1007e                                           // 0000007EA628: D4C1007E
	v_cndmask_b32_e32 v1, v1, v32, vcc_lo                      // 0000007EA62C: 02024101
	s_cbranch_execz 11                                         // 0000007EA630: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi8ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x360>
	v_lshlrev_b32_e32 v1, 1, v1                                // 0000007EA634: 30020281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007EA638: BF8700A1
	v_ashrrev_i32_e32 v2, 31, v1                               // 0000007EA63C: 3404029F
	.long 0xd7006a01                                           // 0000007EA640: D7006A01
	v_cndmask_b32_e32 v1, v24, v1, vcc_lo                      // 0000007EA644: 02020318
	v_add_co_ci_u32_e64 v2, null, v33, v2, vcc_lo              // 0000007EA648: D5207C02 01AA0521
	global_load_d16_b16 v1, v[1:2], off                        // 0000007EA650: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 0000007EA658: BF8903F7
	v_cvt_f32_f16_e32 v14, v1                                  // 0000007EA65C: 7E1C1701
	s_or_b32 exec_lo, exec_lo, s5                              // 0000007EA660: 8C7E057E
	v_add_nc_u32_e32 v1, 0xe0, v31                             // 0000007EA664: 4A023EFF 000000E0
	s_mov_b32 s5, exec_lo                                      // 0000007EA66C: BE85007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007EA670: BF870001
	.long 0xd4c1007e                                           // 0000007EA674: D4C1007E
	v_cndmask_b32_e32 v1, v1, v32, vcc_lo                      // 0000007EA678: 02024101
	s_cbranch_execz 11                                         // 0000007EA67C: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi8ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x3ac>
	v_lshlrev_b32_e32 v1, 1, v1                                // 0000007EA680: 30020281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007EA684: BF8700A1
	v_ashrrev_i32_e32 v2, 31, v1                               // 0000007EA688: 3404029F
	.long 0xd7006a01                                           // 0000007EA68C: D7006A01
	v_cndmask_b32_e32 v1, v24, v1, vcc_lo                      // 0000007EA690: 02020318
	v_add_co_ci_u32_e64 v2, null, v33, v2, vcc_lo              // 0000007EA694: D5207C02 01AA0521
	global_load_d16_b16 v1, v[1:2], off                        // 0000007EA69C: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 0000007EA6A4: BF8903F7
	v_cvt_f32_f16_e32 v15, v1                                  // 0000007EA6A8: 7E1E1701
	s_or_b32 exec_lo, exec_lo, s5                              // 0000007EA6AC: 8C7E057E
	s_branch 9                                                 // 0000007EA6B0: BFA00009 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi8ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x3d8>
	v_mov_b32_e32 v8, 0                                        // 0000007EA6B4: 7E100280
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007EA6B8: BF870001
	v_mov_b32_e32 v9, v8                                       // 0000007EA6BC: 7E120308
	v_mov_b32_e32 v10, v8                                      // 0000007EA6C0: 7E140308
	v_mov_b32_e32 v11, v8                                      // 0000007EA6C4: 7E160308
	v_mov_b32_e32 v12, v8                                      // 0000007EA6C8: 7E180308
	v_mov_b32_e32 v13, v8                                      // 0000007EA6CC: 7E1A0308
	v_mov_b32_e32 v14, v8                                      // 0000007EA6D0: 7E1C0308
	v_mov_b32_e32 v15, v8                                      // 0000007EA6D4: 7E1E0308
	s_add_u32 s8, s8, s18                                      // 0000007EA6D8: 80081208
	s_addc_u32 s9, s9, s19                                     // 0000007EA6DC: 82091309
	s_lshr_b32 s5, s15, 31                                     // 0000007EA6E0: 85059F0F
	v_dual_mov_b32 v1, s7 :: v_dual_mov_b32 v20, 0             // 0000007EA6E4: CA100007 01140080
	s_add_u32 s18, s14, s5                                     // 0000007EA6EC: 8012050E
	s_addc_u32 s19, s15, 0                                     // 0000007EA6F0: 8213800F
	.long 0xd4410005                                           // 0000007EA6F4: D4410005
	v_cndmask_b32_e32 v1, v31, v32, vcc_lo                     // 0000007EA6F8: 0202411F
	s_ashr_i64 s[18:19], s[18:19], 1                           // 0000007EA6FC: 86928112
	v_dual_mov_b32 v34, 0 :: v_dual_mov_b32 v27, 0             // 0000007EA700: CA100080 221A0080
	v_mad_u64_u32 v[25:26], null, v1, s18, s[8:9]              // 0000007EA708: D6FE7C19 00202501
	.long 0xd72c0001                                           // 0000007EA710: D72C0001
	v_cndmask_b32_e32 v0, s7, v19, vcc_lo                      // 0000007EA714: 02002607
	.long 0xd72c0002                                           // 0000007EA718: D72C0002
	v_cndmask_b32_e32 v0, s6, v18, vcc_lo                      // 0000007EA71C: 02002406
	v_cndmask_b32_e64 v35, 0, 1, s20                           // 0000007EA720: D5010023 00510280
	v_dual_mov_b32 v21, 0 :: v_dual_mov_b32 v22, 0             // 0000007EA728: CA100080 15160080
	v_mov_b32_e32 v23, 0                                       // 0000007EA730: 7E2E0280
	s_delay_alu instid0(VALU_DEP_4)                            // 0000007EA734: BF870004
	v_add3_u32 v36, v2, v26, v1                                // 0000007EA738: D6550024 04063502
	s_and_saveexec_b32 s6, s5                                  // 0000007EA740: BE862005
	s_cbranch_execz 22                                         // 0000007EA744: BFA50016 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi8ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x4a0>
	v_lshlrev_b32_e32 v1, 4, v31                               // 0000007EA748: 30023E84
	v_mov_b32_e32 v27, 0                                       // 0000007EA74C: 7E360280
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007EA750: BF8700A2
	v_ashrrev_i32_e32 v2, 31, v1                               // 0000007EA754: 3404029F
	.long 0xd7006a01                                           // 0000007EA758: D7006A01
	v_cndmask_b32_e32 v1, v25, v1, vcc_lo                      // 0000007EA75C: 02020319
	v_add_co_ci_u32_e64 v2, null, v36, v2, vcc_lo              // 0000007EA760: D5207C02 01AA0524
	s_and_not1_b32 vcc_lo, exec_lo, s20                        // 0000007EA768: 916A147E
	global_load_b128 v[20:23], v[1:2], off                     // 0000007EA76C: DC5E0000 147C0001
	s_cbranch_vccnz 10                                         // 0000007EA774: BFA4000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi8ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x4a0>
	v_lshlrev_b32_e32 v1, 1, v31                               // 0000007EA778: 30023E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007EA77C: BF870091
	.long 0xd7006a01                                           // 0000007EA780: D7006A01
	v_cndmask_b32_e32 v1, v24, v1, vcc_lo                      // 0000007EA784: 02020318
	v_add_co_ci_u32_e64 v2, null, 0, v33, vcc_lo               // 0000007EA788: D5207C02 01AA4280
	global_load_d16_b16 v1, v[1:2], off                        // 0000007EA790: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 0000007EA798: BF8903F7
	v_cvt_f32_f16_e32 v27, v1                                  // 0000007EA79C: 7E361701
	s_or_b32 exec_lo, exec_lo, s6                              // 0000007EA7A0: 8C7E067E
	v_dual_mov_b32 v38, 0 :: v_dual_mov_b32 v39, 0             // 0000007EA7A4: CA100080 26260080
	v_dual_mov_b32 v40, 0 :: v_dual_mov_b32 v41, 0             // 0000007EA7AC: CA100080 28280080
	v_dual_mov_b32 v42, 0 :: v_dual_mov_b32 v43, 0             // 0000007EA7B4: CA100080 2A2A0080
	v_mov_b32_e32 v37, 0                                       // 0000007EA7BC: 7E4A0280
	s_and_saveexec_b32 s18, s5                                 // 0000007EA7C0: BE922005
	s_cbranch_execz 666                                        // 0000007EA7C4: BFA5029A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi8ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0xf30>
	v_dual_mov_b32 v42, 0 :: v_dual_add_nc_u32 v1, 32, v31     // 0000007EA7C8: CA200080 2A003EA0
	v_dual_mov_b32 v37, 0 :: v_dual_lshlrev_b32 v26, 5, v31    // 0000007EA7D0: CA220080 251A3E85
	v_dual_mov_b32 v41, 0 :: v_dual_mov_b32 v38, 0             // 0000007EA7D8: CA100080 29260080
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007EA7E0: BF870003
	v_dual_mov_b32 v43, 0 :: v_dual_lshlrev_b32 v44, 4, v1     // 0000007EA7E4: CA220080 2B2C0284
	v_dual_mov_b32 v40, 0 :: v_dual_lshlrev_b32 v45, 1, v1     // 0000007EA7EC: CA220080 282C0281
	v_dual_mov_b32 v39, 0 :: v_dual_mov_b32 v34, 0             // 0000007EA7F4: CA100080 27220080
	v_mov_b32_e32 v46, v27                                     // 0000007EA7FC: 7E5C031B
	s_mul_i32 s5, s15, 6                                       // 0000007EA800: 9605860F
	s_mul_hi_u32 s8, s14, 6                                    // 0000007EA804: 9688860E
	s_lshl_b64 s[6:7], s[14:15], 2                             // 0000007EA808: 8486820E
	s_add_i32 s19, s8, s5                                      // 0000007EA80C: 81130508
	s_mul_i32 s21, s14, 6                                      // 0000007EA810: 9615860E
	s_mov_b32 s20, 0                                           // 0000007EA814: BE940080
	s_lshl_b64 s[8:9], s[14:15], 1                             // 0000007EA818: 8488810E
	s_branch 608                                               // 0000007EA81C: BFA00260 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi8ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0xea0>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000007EA820: 8C7E0E7E
	v_cndmask_b32_e64 v47, v27, v8, s4                         // 0000007EA824: D501002F 0012111B
	v_cndmask_b32_e64 v4, v11, v12, s4                         // 0000007EA82C: D5010004 0012190B
	v_cndmask_b32_e64 v3, v10, v11, s4                         // 0000007EA834: D5010003 0012170A
	v_cndmask_b32_e64 v2, v9, v10, s4                          // 0000007EA83C: D5010002 00121509
	v_cndmask_b32_e64 v1, v8, v9, s4                           // 0000007EA844: D5010001 00121308
	v_dual_mov_b32 v8, v15 :: v_dual_and_b32 v9, 0xff, v20     // 0000007EA84C: CA24010F 080828FF 000000FF
	v_lshrrev_b32_e32 v10, 6, v20                              // 0000007EA858: 32142886
	v_lshrrev_b32_e32 v11, 14, v20                             // 0000007EA85C: 3216288E
	v_cndmask_b32_e64 v7, v14, v15, s4                         // 0000007EA860: D5010007 00121F0E
	v_cndmask_b32_e64 v6, v13, v14, s4                         // 0000007EA868: D5010006 00121D0D
	v_lshlrev_b32_e32 v9, 2, v9                                // 0000007EA870: 30121282
	v_and_b32_e32 v10, 0x3fc, v10                              // 0000007EA874: 361414FF 000003FC
	v_and_b32_e32 v11, 0x3fc, v11                              // 0000007EA87C: 361616FF 000003FC
	v_cndmask_b32_e64 v5, v12, v13, s4                         // 0000007EA884: D5010005 00121B0C
	v_ashrrev_i32_e32 v27, 31, v26                             // 0000007EA88C: 3436349F
	ds_load_b32 v9, v9                                         // 0000007EA890: D8D80000 09000009
	ds_load_b32 v10, v10                                       // 0000007EA898: D8D80000 0A00000A
	ds_load_b32 v15, v11                                       // 0000007EA8A0: D8D80000 0F00000B
	v_lshrrev_b32_e32 v11, 22, v20                             // 0000007EA8A8: 32162896
	s_and_b32 s5, exec_lo, s5                                  // 0000007EA8AC: 8B05057E
	v_add_nc_u32_e32 v44, 0x200, v44                           // 0000007EA8B0: 4A5858FF 00000200
	s_or_b32 s20, s5, s20                                      // 0000007EA8B8: 8C141405
	v_add_nc_u32_e32 v45, 64, v45                              // 0000007EA8BC: 4A5A5AC0
	v_and_b32_e32 v11, 0x3fc, v11                              // 0000007EA8C0: 361616FF 000003FC
	ds_load_b32 v60, v11                                       // 0000007EA8C8: D8D80000 3C00000B
	v_and_b32_e32 v11, 0xff, v21                               // 0000007EA8D0: 36162AFF 000000FF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007EA8D8: BF8700B1
	v_lshlrev_b32_e32 v11, 2, v11                              // 0000007EA8DC: 30161682
	ds_load_b32 v61, v11                                       // 0000007EA8E0: D8D80000 3D00000B
	v_lshrrev_b32_e32 v11, 6, v21                              // 0000007EA8E8: 32162A86
	v_and_b32_e32 v11, 0x3fc, v11                              // 0000007EA8EC: 361616FF 000003FC
	ds_load_b32 v62, v11                                       // 0000007EA8F4: D8D80000 3E00000B
	v_lshrrev_b32_e32 v11, 14, v21                             // 0000007EA8FC: 32162A8E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007EA900: BF8700B1
	v_and_b32_e32 v11, 0x3fc, v11                              // 0000007EA904: 361616FF 000003FC
	ds_load_b32 v63, v11                                       // 0000007EA90C: D8D80000 3F00000B
	v_lshrrev_b32_e32 v11, 22, v21                             // 0000007EA914: 32162A96
	v_and_b32_e32 v11, 0x3fc, v11                              // 0000007EA918: 361616FF 000003FC
	ds_load_b32 v64, v11                                       // 0000007EA920: D8D80000 4000000B
	v_and_b32_e32 v11, 0xff, v22                               // 0000007EA928: 36162CFF 000000FF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007EA930: BF8700B1
	v_lshlrev_b32_e32 v11, 2, v11                              // 0000007EA934: 30161682
	ds_load_b32 v65, v11                                       // 0000007EA938: D8D80000 4100000B
	v_lshrrev_b32_e32 v11, 6, v22                              // 0000007EA940: 32162C86
	v_and_b32_e32 v11, 0x3fc, v11                              // 0000007EA944: 361616FF 000003FC
	ds_load_b32 v66, v11                                       // 0000007EA94C: D8D80000 4200000B
	v_lshrrev_b32_e32 v11, 14, v22                             // 0000007EA954: 32162C8E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007EA958: BF8700B1
	v_and_b32_e32 v11, 0x3fc, v11                              // 0000007EA95C: 361616FF 000003FC
	ds_load_b32 v67, v11                                       // 0000007EA964: D8D80000 4300000B
	v_lshrrev_b32_e32 v11, 22, v22                             // 0000007EA96C: 32162C96
	v_and_b32_e32 v11, 0x3fc, v11                              // 0000007EA970: 361616FF 000003FC
	ds_load_b32 v68, v11                                       // 0000007EA978: D8D80000 4400000B
	v_and_b32_e32 v11, 0xff, v23                               // 0000007EA980: 36162EFF 000000FF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007EA988: BF8700B1
	v_lshlrev_b32_e32 v11, 2, v11                              // 0000007EA98C: 30161682
	ds_load_b32 v69, v11                                       // 0000007EA990: D8D80000 4500000B
	v_lshrrev_b32_e32 v11, 6, v23                              // 0000007EA998: 32162E86
	v_and_b32_e32 v11, 0x3fc, v11                              // 0000007EA99C: 361616FF 000003FC
	ds_load_b32 v70, v11                                       // 0000007EA9A4: D8D80000 4600000B
	v_lshrrev_b32_e32 v11, 14, v23                             // 0000007EA9AC: 32162E8E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007EA9B0: BF8700B1
	v_and_b32_e32 v11, 0x3fc, v11                              // 0000007EA9B4: 361616FF 000003FC
	ds_load_b32 v71, v11                                       // 0000007EA9BC: D8D80000 4700000B
	v_lshrrev_b32_e32 v11, 22, v23                             // 0000007EA9C4: 32162E96
	v_and_b32_e32 v11, 0x3fc, v11                              // 0000007EA9C8: 361616FF 000003FC
	ds_load_b32 v72, v11                                       // 0000007EA9D0: D8D80000 4800000B
	.long 0xd73c000b                                           // 0000007EA9D8: D73C000B
	v_cndmask_b32_e32 v1, 1, v26, vcc_lo                       // 0000007EA9DC: 02023481
	v_dual_mov_b32 v27, v46 :: v_dual_add_nc_u32 v26, 0x400, v26// 0000007EA9E0: CA20012E 1B1A34FF 00000400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007EA9EC: BF870092
	.long 0xd7006a38                                           // 0000007EA9F0: D7006A38
	v_cndmask_b32_e32 v1, s10, v11, vcc_lo                     // 0000007EA9F4: 0202160A
	v_add_co_ci_u32_e64 v57, null, s11, v12, vcc_lo            // 0000007EA9F8: D5207C39 01AA180B
	s_clause 0x3                                               // 0000007EAA00: BF850003
	global_load_b128 v[11:14], v[56:57], off                   // 0000007EAA04: DC5E0000 0B7C0038
	global_load_b128 v[20:23], v[56:57], off offset:16         // 0000007EAA0C: DC5E0010 147C0038
	global_load_b128 v[48:51], v[56:57], off offset:32         // 0000007EAA14: DC5E0020 307C0038
	global_load_b128 v[52:55], v[56:57], off offset:48         // 0000007EAA1C: DC5E0030 347C0038
	s_waitcnt vmcnt(3) lgkmcnt(15)                             // 0000007EAA24: BF890CF7
	v_dot2_f32_bf16 v11, v11, v9, 0                            // 0000007EAA28: CC1A400B 1A02130B
	s_waitcnt lgkmcnt(14)                                      // 0000007EAA30: BF89FCE7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007EAA34: BF8700A1
	v_dot2_f32_bf16 v11, v12, v10, v11                         // 0000007EAA38: CC1A400B 1C2E150C
	s_waitcnt lgkmcnt(13)                                      // 0000007EAA40: BF89FCD7
	v_dot2_f32_bf16 v11, v13, v15, v11                         // 0000007EAA44: CC1A400B 1C2E1F0D
	s_waitcnt lgkmcnt(12)                                      // 0000007EAA4C: BF89FCC7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007EAA50: BF8700A1
	v_dot2_f32_bf16 v11, v14, v60, v11                         // 0000007EAA54: CC1A400B 1C2E790E
	s_waitcnt vmcnt(2) lgkmcnt(11)                             // 0000007EAA5C: BF8908B7
	v_dot2_f32_bf16 v11, v20, v61, v11                         // 0000007EAA60: CC1A400B 1C2E7B14
	s_waitcnt lgkmcnt(10)                                      // 0000007EAA68: BF89FCA7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007EAA6C: BF8700A1
	v_dot2_f32_bf16 v11, v21, v62, v11                         // 0000007EAA70: CC1A400B 1C2E7D15
	s_waitcnt lgkmcnt(9)                                       // 0000007EAA78: BF89FC97
	v_dot2_f32_bf16 v11, v22, v63, v11                         // 0000007EAA7C: CC1A400B 1C2E7F16
	s_waitcnt lgkmcnt(8)                                       // 0000007EAA84: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007EAA88: BF8700A1
	v_dot2_f32_bf16 v11, v23, v64, v11                         // 0000007EAA8C: CC1A400B 1C2E8117
	s_waitcnt vmcnt(1) lgkmcnt(7)                              // 0000007EAA94: BF890477
	v_dot2_f32_bf16 v11, v48, v65, v11                         // 0000007EAA98: CC1A400B 1C2E8330
	s_waitcnt lgkmcnt(6)                                       // 0000007EAAA0: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007EAAA4: BF8700A1
	v_dot2_f32_bf16 v11, v49, v66, v11                         // 0000007EAAA8: CC1A400B 1C2E8531
	s_waitcnt lgkmcnt(5)                                       // 0000007EAAB0: BF89FC57
	v_dot2_f32_bf16 v11, v50, v67, v11                         // 0000007EAAB4: CC1A400B 1C2E8732
	s_waitcnt lgkmcnt(4)                                       // 0000007EAABC: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007EAAC0: BF8700A1
	v_dot2_f32_bf16 v11, v51, v68, v11                         // 0000007EAAC4: CC1A400B 1C2E8933
	s_waitcnt vmcnt(0) lgkmcnt(3)                              // 0000007EAACC: BF890037
	v_dot2_f32_bf16 v11, v52, v69, v11                         // 0000007EAAD0: CC1A400B 1C2E8B34
	.long 0xd7006a34                                           // 0000007EAAD8: D7006A34
	v_cndmask_b32_e32 v0, v56, v8, vcc_lo                      // 0000007EAADC: 02001138
	s_waitcnt lgkmcnt(2)                                       // 0000007EAAE0: BF89FC27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000007EAAE4: BF8701C2
	v_dot2_f32_bf16 v11, v53, v70, v11                         // 0000007EAAE8: CC1A400B 1C2E8D35
	v_add_co_ci_u32_e64 v53, null, s9, v57, vcc_lo             // 0000007EAAF0: D5207C35 01AA7209
	.long 0xd7006a3a                                           // 0000007EAAF8: D7006A3A
	v_cndmask_b32_e32 v0, v56, v6, vcc_lo                      // 0000007EAAFC: 02000D38
	s_waitcnt lgkmcnt(1)                                       // 0000007EAB00: BF89FC17
	v_dot2_f32_bf16 v11, v54, v71, v11                         // 0000007EAB04: CC1A400B 1C2E8F36
	v_add_co_ci_u32_e64 v59, null, s7, v57, vcc_lo             // 0000007EAB0C: D5207C3B 01AA7207
	.long 0xd7006a38                                           // 0000007EAB14: D7006A38
	v_cndmask_b32_e32 v0, v56, v21, vcc_lo                     // 0000007EAB18: 02002B38
	s_waitcnt lgkmcnt(0)                                       // 0000007EAB1C: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000007EAB20: BF870123
	v_dot2_f32_bf16 v11, v55, v72, v11                         // 0000007EAB24: CC1A400B 1C2E9137
	v_add_co_ci_u32_e64 v57, null, s19, v57, vcc_lo            // 0000007EAB2C: D5207C39 01AA7213
	v_fmac_f32_e32 v37, v47, v11                               // 0000007EAB34: 564A172F
	s_clause 0x3                                               // 0000007EAB38: BF850003
	global_load_b128 v[11:14], v[52:53], off                   // 0000007EAB3C: DC5E0000 0B7C0034
	global_load_b128 v[20:23], v[52:53], off offset:16         // 0000007EAB44: DC5E0010 147C0034
	global_load_b128 v[48:51], v[52:53], off offset:32         // 0000007EAB4C: DC5E0020 307C0034
	global_load_b128 v[52:55], v[52:53], off offset:48         // 0000007EAB54: DC5E0030 347C0034
	s_waitcnt vmcnt(3)                                         // 0000007EAB5C: BF890FF7
	v_dot2_f32_bf16 v11, v11, v9, 0                            // 0000007EAB60: CC1A400B 1A02130B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007EAB68: BF870091
	v_dot2_f32_bf16 v11, v12, v10, v11                         // 0000007EAB6C: CC1A400B 1C2E150C
	v_dot2_f32_bf16 v11, v13, v15, v11                         // 0000007EAB74: CC1A400B 1C2E1F0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007EAB7C: BF8700A1
	v_dot2_f32_bf16 v11, v14, v60, v11                         // 0000007EAB80: CC1A400B 1C2E790E
	s_waitcnt vmcnt(2)                                         // 0000007EAB88: BF890BF7
	v_dot2_f32_bf16 v11, v20, v61, v11                         // 0000007EAB8C: CC1A400B 1C2E7B14
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007EAB94: BF870091
	v_dot2_f32_bf16 v11, v21, v62, v11                         // 0000007EAB98: CC1A400B 1C2E7D15
	v_dot2_f32_bf16 v11, v22, v63, v11                         // 0000007EABA0: CC1A400B 1C2E7F16
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007EABA8: BF8700A1
	v_dot2_f32_bf16 v11, v23, v64, v11                         // 0000007EABAC: CC1A400B 1C2E8117
	s_waitcnt vmcnt(1)                                         // 0000007EABB4: BF8907F7
	v_dot2_f32_bf16 v11, v48, v65, v11                         // 0000007EABB8: CC1A400B 1C2E8330
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007EABC0: BF870091
	v_dot2_f32_bf16 v11, v49, v66, v11                         // 0000007EABC4: CC1A400B 1C2E8531
	v_dot2_f32_bf16 v11, v50, v67, v11                         // 0000007EABCC: CC1A400B 1C2E8732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007EABD4: BF8700A1
	v_dot2_f32_bf16 v11, v51, v68, v11                         // 0000007EABD8: CC1A400B 1C2E8933
	s_waitcnt vmcnt(0)                                         // 0000007EABE0: BF8903F7
	v_dot2_f32_bf16 v11, v52, v69, v11                         // 0000007EABE4: CC1A400B 1C2E8B34
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007EABEC: BF870091
	v_dot2_f32_bf16 v11, v53, v70, v11                         // 0000007EABF0: CC1A400B 1C2E8D35
	v_dot2_f32_bf16 v11, v54, v71, v11                         // 0000007EABF8: CC1A400B 1C2E8F36
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007EAC00: BF870091
	v_dot2_f32_bf16 v11, v55, v72, v11                         // 0000007EAC04: CC1A400B 1C2E9137
	v_fmac_f32_e32 v43, v47, v11                               // 0000007EAC0C: 5656172F
	s_clause 0x3                                               // 0000007EAC10: BF850003
	global_load_b128 v[11:14], v[58:59], off                   // 0000007EAC14: DC5E0000 0B7C003A
	global_load_b128 v[20:23], v[58:59], off offset:16         // 0000007EAC1C: DC5E0010 147C003A
	global_load_b128 v[48:51], v[58:59], off offset:32         // 0000007EAC24: DC5E0020 307C003A
	global_load_b128 v[52:55], v[58:59], off offset:48         // 0000007EAC2C: DC5E0030 347C003A
	.long 0xd7006a3a                                           // 0000007EAC34: D7006A3A
	v_cndmask_b32_e32 v0, v58, v6, vcc_lo                      // 0000007EAC38: 02000D3A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007EAC3C: BF8700B1
	v_add_co_ci_u32_e64 v59, null, s7, v59, vcc_lo             // 0000007EAC40: D5207C3B 01AA7607
	s_waitcnt vmcnt(3)                                         // 0000007EAC48: BF890FF7
	v_dot2_f32_bf16 v11, v11, v9, 0                            // 0000007EAC4C: CC1A400B 1A02130B
	v_dot2_f32_bf16 v11, v12, v10, v11                         // 0000007EAC54: CC1A400B 1C2E150C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007EAC5C: BF870091
	v_dot2_f32_bf16 v11, v13, v15, v11                         // 0000007EAC60: CC1A400B 1C2E1F0D
	v_dot2_f32_bf16 v11, v14, v60, v11                         // 0000007EAC68: CC1A400B 1C2E790E
	s_waitcnt vmcnt(2)                                         // 0000007EAC70: BF890BF7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007EAC74: BF870091
	v_dot2_f32_bf16 v11, v20, v61, v11                         // 0000007EAC78: CC1A400B 1C2E7B14
	v_dot2_f32_bf16 v11, v21, v62, v11                         // 0000007EAC80: CC1A400B 1C2E7D15
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007EAC88: BF870091
	v_dot2_f32_bf16 v11, v22, v63, v11                         // 0000007EAC8C: CC1A400B 1C2E7F16
	v_dot2_f32_bf16 v11, v23, v64, v11                         // 0000007EAC94: CC1A400B 1C2E8117
	s_waitcnt vmcnt(1)                                         // 0000007EAC9C: BF8907F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007EACA0: BF870091
	v_dot2_f32_bf16 v11, v48, v65, v11                         // 0000007EACA4: CC1A400B 1C2E8330
	v_dot2_f32_bf16 v11, v49, v66, v11                         // 0000007EACAC: CC1A400B 1C2E8531
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007EACB4: BF870091
	v_dot2_f32_bf16 v11, v50, v67, v11                         // 0000007EACB8: CC1A400B 1C2E8732
	v_dot2_f32_bf16 v11, v51, v68, v11                         // 0000007EACC0: CC1A400B 1C2E8933
	s_waitcnt vmcnt(0)                                         // 0000007EACC8: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007EACCC: BF870091
	v_dot2_f32_bf16 v11, v52, v69, v11                         // 0000007EACD0: CC1A400B 1C2E8B34
	v_dot2_f32_bf16 v11, v53, v70, v11                         // 0000007EACD8: CC1A400B 1C2E8D35
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007EACE0: BF870091
	v_dot2_f32_bf16 v11, v54, v71, v11                         // 0000007EACE4: CC1A400B 1C2E8F36
	v_dot2_f32_bf16 v11, v55, v72, v11                         // 0000007EACEC: CC1A400B 1C2E9137
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007EACF4: BF870001
	v_fmac_f32_e32 v42, v47, v11                               // 0000007EACF8: 5654172F
	s_clause 0x3                                               // 0000007EACFC: BF850003
	global_load_b128 v[11:14], v[56:57], off                   // 0000007EAD00: DC5E0000 0B7C0038
	global_load_b128 v[20:23], v[56:57], off offset:16         // 0000007EAD08: DC5E0010 147C0038
	global_load_b128 v[48:51], v[56:57], off offset:32         // 0000007EAD10: DC5E0020 307C0038
	global_load_b128 v[52:55], v[56:57], off offset:48         // 0000007EAD18: DC5E0030 347C0038
	.long 0xd7006a38                                           // 0000007EAD20: D7006A38
	v_cndmask_b32_e32 v0, v56, v6, vcc_lo                      // 0000007EAD24: 02000D38
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007EAD28: BF8700B1
	v_add_co_ci_u32_e64 v57, null, s7, v57, vcc_lo             // 0000007EAD2C: D5207C39 01AA7207
	s_waitcnt vmcnt(3)                                         // 0000007EAD34: BF890FF7
	v_dot2_f32_bf16 v11, v11, v9, 0                            // 0000007EAD38: CC1A400B 1A02130B
	v_dot2_f32_bf16 v11, v12, v10, v11                         // 0000007EAD40: CC1A400B 1C2E150C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007EAD48: BF870091
	v_dot2_f32_bf16 v11, v13, v15, v11                         // 0000007EAD4C: CC1A400B 1C2E1F0D
	v_dot2_f32_bf16 v11, v14, v60, v11                         // 0000007EAD54: CC1A400B 1C2E790E
	s_waitcnt vmcnt(2)                                         // 0000007EAD5C: BF890BF7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007EAD60: BF870091
	v_dot2_f32_bf16 v11, v20, v61, v11                         // 0000007EAD64: CC1A400B 1C2E7B14
	v_dot2_f32_bf16 v11, v21, v62, v11                         // 0000007EAD6C: CC1A400B 1C2E7D15
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007EAD74: BF870091
	v_dot2_f32_bf16 v11, v22, v63, v11                         // 0000007EAD78: CC1A400B 1C2E7F16
	v_dot2_f32_bf16 v11, v23, v64, v11                         // 0000007EAD80: CC1A400B 1C2E8117
	s_waitcnt vmcnt(1)                                         // 0000007EAD88: BF8907F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007EAD8C: BF870091
	v_dot2_f32_bf16 v11, v48, v65, v11                         // 0000007EAD90: CC1A400B 1C2E8330
	v_dot2_f32_bf16 v11, v49, v66, v11                         // 0000007EAD98: CC1A400B 1C2E8531
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007EADA0: BF870091
	v_dot2_f32_bf16 v11, v50, v67, v11                         // 0000007EADA4: CC1A400B 1C2E8732
	v_dot2_f32_bf16 v11, v51, v68, v11                         // 0000007EADAC: CC1A400B 1C2E8933
	s_waitcnt vmcnt(0)                                         // 0000007EADB4: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007EADB8: BF870091
	v_dot2_f32_bf16 v11, v52, v69, v11                         // 0000007EADBC: CC1A400B 1C2E8B34
	v_dot2_f32_bf16 v11, v53, v70, v11                         // 0000007EADC4: CC1A400B 1C2E8D35
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007EADCC: BF870091
	v_dot2_f32_bf16 v11, v54, v71, v11                         // 0000007EADD0: CC1A400B 1C2E8F36
	v_dot2_f32_bf16 v11, v55, v72, v11                         // 0000007EADD8: CC1A400B 1C2E9137
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007EADE0: BF870001
	v_fmac_f32_e32 v41, v47, v11                               // 0000007EADE4: 5652172F
	s_clause 0x3                                               // 0000007EADE8: BF850003
	global_load_b128 v[11:14], v[58:59], off                   // 0000007EADEC: DC5E0000 0B7C003A
	global_load_b128 v[20:23], v[58:59], off offset:16         // 0000007EADF4: DC5E0010 147C003A
	global_load_b128 v[48:51], v[58:59], off offset:32         // 0000007EADFC: DC5E0020 307C003A
	global_load_b128 v[52:55], v[58:59], off offset:48         // 0000007EAE04: DC5E0030 347C003A
	s_waitcnt vmcnt(3)                                         // 0000007EAE0C: BF890FF7
	v_dot2_f32_bf16 v11, v11, v9, 0                            // 0000007EAE10: CC1A400B 1A02130B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007EAE18: BF870091
	v_dot2_f32_bf16 v11, v12, v10, v11                         // 0000007EAE1C: CC1A400B 1C2E150C
	v_dot2_f32_bf16 v11, v13, v15, v11                         // 0000007EAE24: CC1A400B 1C2E1F0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007EAE2C: BF8700A1
	v_dot2_f32_bf16 v11, v14, v60, v11                         // 0000007EAE30: CC1A400B 1C2E790E
	s_waitcnt vmcnt(2)                                         // 0000007EAE38: BF890BF7
	v_dot2_f32_bf16 v11, v20, v61, v11                         // 0000007EAE3C: CC1A400B 1C2E7B14
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007EAE44: BF870091
	v_dot2_f32_bf16 v11, v21, v62, v11                         // 0000007EAE48: CC1A400B 1C2E7D15
	v_dot2_f32_bf16 v11, v22, v63, v11                         // 0000007EAE50: CC1A400B 1C2E7F16
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007EAE58: BF8700A1
	v_dot2_f32_bf16 v11, v23, v64, v11                         // 0000007EAE5C: CC1A400B 1C2E8117
	s_waitcnt vmcnt(1)                                         // 0000007EAE64: BF8907F7
	v_dot2_f32_bf16 v11, v48, v65, v11                         // 0000007EAE68: CC1A400B 1C2E8330
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007EAE70: BF870091
	v_dot2_f32_bf16 v11, v49, v66, v11                         // 0000007EAE74: CC1A400B 1C2E8531
	v_dot2_f32_bf16 v11, v50, v67, v11                         // 0000007EAE7C: CC1A400B 1C2E8732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007EAE84: BF8700A1
	v_dot2_f32_bf16 v11, v51, v68, v11                         // 0000007EAE88: CC1A400B 1C2E8933
	s_waitcnt vmcnt(0)                                         // 0000007EAE90: BF8903F7
	v_dot2_f32_bf16 v11, v52, v69, v11                         // 0000007EAE94: CC1A400B 1C2E8B34
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007EAE9C: BF870091
	v_dot2_f32_bf16 v11, v53, v70, v11                         // 0000007EAEA0: CC1A400B 1C2E8D35
	v_dot2_f32_bf16 v11, v54, v71, v11                         // 0000007EAEA8: CC1A400B 1C2E8F36
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007EAEB0: BF870091
	v_dot2_f32_bf16 v11, v55, v72, v11                         // 0000007EAEB4: CC1A400B 1C2E9137
	v_fmac_f32_e32 v40, v47, v11                               // 0000007EAEBC: 5650172F
	s_clause 0x3                                               // 0000007EAEC0: BF850003
	global_load_b128 v[11:14], v[56:57], off                   // 0000007EAEC4: DC5E0000 0B7C0038
	global_load_b128 v[20:23], v[56:57], off offset:16         // 0000007EAECC: DC5E0010 147C0038
	global_load_b128 v[48:51], v[56:57], off offset:32         // 0000007EAED4: DC5E0020 307C0038
	global_load_b128 v[52:55], v[56:57], off offset:48         // 0000007EAEDC: DC5E0030 347C0038
	s_waitcnt vmcnt(3)                                         // 0000007EAEE4: BF890FF7
	v_dot2_f32_bf16 v11, v11, v9, 0                            // 0000007EAEE8: CC1A400B 1A02130B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007EAEF0: BF870091
	v_dot2_f32_bf16 v11, v12, v10, v11                         // 0000007EAEF4: CC1A400B 1C2E150C
	v_dot2_f32_bf16 v11, v13, v15, v11                         // 0000007EAEFC: CC1A400B 1C2E1F0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007EAF04: BF8700A1
	v_dot2_f32_bf16 v11, v14, v60, v11                         // 0000007EAF08: CC1A400B 1C2E790E
	s_waitcnt vmcnt(2)                                         // 0000007EAF10: BF890BF7
	v_dot2_f32_bf16 v11, v20, v61, v11                         // 0000007EAF14: CC1A400B 1C2E7B14
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007EAF1C: BF870091
	v_dot2_f32_bf16 v11, v21, v62, v11                         // 0000007EAF20: CC1A400B 1C2E7D15
	v_dot2_f32_bf16 v11, v22, v63, v11                         // 0000007EAF28: CC1A400B 1C2E7F16
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007EAF30: BF8700A1
	v_dot2_f32_bf16 v11, v23, v64, v11                         // 0000007EAF34: CC1A400B 1C2E8117
	s_waitcnt vmcnt(1)                                         // 0000007EAF3C: BF8907F7
	v_dot2_f32_bf16 v11, v48, v65, v11                         // 0000007EAF40: CC1A400B 1C2E8330
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007EAF48: BF870091
	v_dot2_f32_bf16 v11, v49, v66, v11                         // 0000007EAF4C: CC1A400B 1C2E8531
	v_dot2_f32_bf16 v11, v50, v67, v11                         // 0000007EAF54: CC1A400B 1C2E8732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007EAF5C: BF8700A1
	v_dot2_f32_bf16 v11, v51, v68, v11                         // 0000007EAF60: CC1A400B 1C2E8933
	s_waitcnt vmcnt(0)                                         // 0000007EAF68: BF8903F7
	v_dot2_f32_bf16 v11, v52, v69, v11                         // 0000007EAF6C: CC1A400B 1C2E8B34
	.long 0xd7006a34                                           // 0000007EAF74: D7006A34
	v_cndmask_b32_e32 v0, v58, v6, vcc_lo                      // 0000007EAF78: 02000D3A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000007EAF7C: BF870122
	v_dot2_f32_bf16 v11, v53, v70, v11                         // 0000007EAF80: CC1A400B 1C2E8D35
	v_add_co_ci_u32_e64 v53, null, s7, v59, vcc_lo             // 0000007EAF88: D5207C35 01AA7607
	v_dot2_f32_bf16 v11, v54, v71, v11                         // 0000007EAF90: CC1A400B 1C2E8F36
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007EAF98: BF870091
	v_dot2_f32_bf16 v11, v55, v72, v11                         // 0000007EAF9C: CC1A400B 1C2E9137
	v_fmac_f32_e32 v39, v47, v11                               // 0000007EAFA4: 564E172F
	s_clause 0x3                                               // 0000007EAFA8: BF850003
	global_load_b128 v[11:14], v[52:53], off                   // 0000007EAFAC: DC5E0000 0B7C0034
	global_load_b128 v[20:23], v[52:53], off offset:16         // 0000007EAFB4: DC5E0010 147C0034
	global_load_b128 v[48:51], v[52:53], off offset:32         // 0000007EAFBC: DC5E0020 307C0034
	global_load_b128 v[52:55], v[52:53], off offset:48         // 0000007EAFC4: DC5E0030 347C0034
	s_waitcnt vmcnt(3)                                         // 0000007EAFCC: BF890FF7
	v_dot2_f32_bf16 v11, v11, v9, 0                            // 0000007EAFD0: CC1A400B 1A02130B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007EAFD8: BF870091
	v_dot2_f32_bf16 v11, v12, v10, v11                         // 0000007EAFDC: CC1A400B 1C2E150C
	v_dot2_f32_bf16 v11, v13, v15, v11                         // 0000007EAFE4: CC1A400B 1C2E1F0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007EAFEC: BF8700A1
	v_dot2_f32_bf16 v11, v14, v60, v11                         // 0000007EAFF0: CC1A400B 1C2E790E
	s_waitcnt vmcnt(2)                                         // 0000007EAFF8: BF890BF7
	v_dot2_f32_bf16 v11, v20, v61, v11                         // 0000007EAFFC: CC1A400B 1C2E7B14
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007EB004: BF870091
	v_dot2_f32_bf16 v11, v21, v62, v11                         // 0000007EB008: CC1A400B 1C2E7D15
	v_dot2_f32_bf16 v11, v22, v63, v11                         // 0000007EB010: CC1A400B 1C2E7F16
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007EB018: BF8700A1
	v_dot2_f32_bf16 v11, v23, v64, v11                         // 0000007EB01C: CC1A400B 1C2E8117
	s_waitcnt vmcnt(1)                                         // 0000007EB024: BF8907F7
	v_dot2_f32_bf16 v11, v48, v65, v11                         // 0000007EB028: CC1A400B 1C2E8330
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007EB030: BF870091
	v_dot2_f32_bf16 v11, v49, v66, v11                         // 0000007EB034: CC1A400B 1C2E8531
	v_dot2_f32_bf16 v11, v50, v67, v11                         // 0000007EB03C: CC1A400B 1C2E8732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007EB044: BF8700A1
	v_dot2_f32_bf16 v11, v51, v68, v11                         // 0000007EB048: CC1A400B 1C2E8933
	s_waitcnt vmcnt(0)                                         // 0000007EB050: BF8903F7
	v_dot2_f32_bf16 v11, v52, v69, v11                         // 0000007EB054: CC1A400B 1C2E8B34
	.long 0xd7006a34                                           // 0000007EB05C: D7006A34
	v_cndmask_b32_e32 v0, v56, v6, vcc_lo                      // 0000007EB060: 02000D38
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000007EB064: BF870122
	v_dot2_f32_bf16 v11, v53, v70, v11                         // 0000007EB068: CC1A400B 1C2E8D35
	v_add_co_ci_u32_e64 v53, null, s7, v57, vcc_lo             // 0000007EB070: D5207C35 01AA7207
	v_dot2_f32_bf16 v11, v54, v71, v11                         // 0000007EB078: CC1A400B 1C2E8F36
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007EB080: BF870091
	v_dot2_f32_bf16 v11, v55, v72, v11                         // 0000007EB084: CC1A400B 1C2E9137
	v_fmac_f32_e32 v38, v47, v11                               // 0000007EB08C: 564C172F
	s_clause 0x3                                               // 0000007EB090: BF850003
	global_load_b128 v[11:14], v[52:53], off                   // 0000007EB094: DC5E0000 0B7C0034
	global_load_b128 v[20:23], v[52:53], off offset:16         // 0000007EB09C: DC5E0010 147C0034
	global_load_b128 v[48:51], v[52:53], off offset:32         // 0000007EB0A4: DC5E0020 307C0034
	global_load_b128 v[52:55], v[52:53], off offset:48         // 0000007EB0AC: DC5E0030 347C0034
	s_waitcnt vmcnt(3)                                         // 0000007EB0B4: BF890FF7
	v_dot2_f32_bf16 v9, v11, v9, 0                             // 0000007EB0B8: CC1A4009 1A02130B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007EB0C0: BF870091
	v_dot2_f32_bf16 v9, v12, v10, v9                           // 0000007EB0C4: CC1A4009 1C26150C
	v_dot2_f32_bf16 v9, v13, v15, v9                           // 0000007EB0CC: CC1A4009 1C261F0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007EB0D4: BF8700A1
	v_dot2_f32_bf16 v9, v14, v60, v9                           // 0000007EB0D8: CC1A4009 1C26790E
	s_waitcnt vmcnt(2)                                         // 0000007EB0E0: BF890BF7
	v_dot2_f32_bf16 v9, v20, v61, v9                           // 0000007EB0E4: CC1A4009 1C267B14
	v_mov_b32_e32 v20, v16                                     // 0000007EB0EC: 7E280310
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000007EB0F0: BF870122
	v_dot2_f32_bf16 v9, v21, v62, v9                           // 0000007EB0F4: CC1A4009 1C267D15
	v_mov_b32_e32 v21, v17                                     // 0000007EB0FC: 7E2A0311
	v_dot2_f32_bf16 v9, v22, v63, v9                           // 0000007EB100: CC1A4009 1C267F16
	v_mov_b32_e32 v22, v18                                     // 0000007EB108: 7E2C0312
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000007EB10C: BF870132
	v_dot2_f32_bf16 v9, v23, v64, v9                           // 0000007EB110: CC1A4009 1C268117
	v_mov_b32_e32 v23, v19                                     // 0000007EB118: 7E2E0313
	s_waitcnt vmcnt(1)                                         // 0000007EB11C: BF8907F7
	v_dot2_f32_bf16 v9, v48, v65, v9                           // 0000007EB120: CC1A4009 1C268330
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007EB128: BF870091
	v_dot2_f32_bf16 v9, v49, v66, v9                           // 0000007EB12C: CC1A4009 1C268531
	v_dot2_f32_bf16 v9, v50, v67, v9                           // 0000007EB134: CC1A4009 1C268732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007EB13C: BF8700A1
	v_dot2_f32_bf16 v9, v51, v68, v9                           // 0000007EB140: CC1A4009 1C268933
	s_waitcnt vmcnt(0)                                         // 0000007EB148: BF8903F7
	v_dot2_f32_bf16 v9, v52, v69, v9                           // 0000007EB14C: CC1A4009 1C268B34
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007EB154: BF870091
	v_dot2_f32_bf16 v9, v53, v70, v9                           // 0000007EB158: CC1A4009 1C268D35
	v_dot2_f32_bf16 v9, v54, v71, v9                           // 0000007EB160: CC1A4009 1C268F36
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007EB168: BF870091
	v_dot2_f32_bf16 v9, v55, v72, v9                           // 0000007EB16C: CC1A4009 1C269137
	v_dual_fmac_f32 v34, v47, v9 :: v_dual_mov_b32 v15, v8     // 0000007EB174: C810132F 220E0108
	v_dual_mov_b32 v14, v7 :: v_dual_mov_b32 v13, v6           // 0000007EB17C: CA100107 0E0C0106
	v_dual_mov_b32 v12, v5 :: v_dual_mov_b32 v11, v4           // 0000007EB184: CA100105 0C0A0104
	v_dual_mov_b32 v10, v3 :: v_dual_mov_b32 v9, v2            // 0000007EB18C: CA100103 0A080102
	v_mov_b32_e32 v8, v1                                       // 0000007EB194: 7E100301
	s_and_not1_b32 exec_lo, exec_lo, s20                       // 0000007EB198: 917E147E
	s_cbranch_execz 35                                         // 0000007EB19C: BFA50023 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi8ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0xf2c>
	s_waitcnt vmcnt(0)                                         // 0000007EB1A0: BF8903F7
	v_dual_mov_b32 v16, v20 :: v_dual_add_nc_u32 v31, 32, v31  // 0000007EB1A4: CA200114 101E3EA0
	v_dual_mov_b32 v17, v21 :: v_dual_mov_b32 v18, v22         // 0000007EB1AC: CA100115 11120116
	v_mov_b32_e32 v19, v23                                     // 0000007EB1B4: 7E260317
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007EB1B8: BF870003
	.long 0xd4460005                                           // 0000007EB1BC: D4460005
	v_cndmask_b32_e32 v1, v31, v32, vcc_lo                     // 0000007EB1C0: 0202411F
	s_mov_b32 s14, exec_lo                                     // 0000007EB1C4: BE8E007E
	.long 0xd4c1007e                                           // 0000007EB1C8: D4C1007E
	v_cndmask_b32_e32 v1, v31, v32, vcc_lo                     // 0000007EB1CC: 0202411F
	s_cbranch_execz 64915                                      // 0000007EB1D0: BFA5FD93 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi8ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x520>
	v_ashrrev_i32_e32 v2, 31, v44                              // 0000007EB1D4: 3404589F
	.long 0xd7006a01                                           // 0000007EB1D8: D7006A01
	v_cndmask_b32_e32 v1, v25, v44, vcc_lo                     // 0000007EB1DC: 02025919
	v_mov_b32_e32 v46, v27                                     // 0000007EB1E0: 7E5C031B
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007EB1E4: BF870003
	v_add_co_ci_u32_e64 v2, null, v36, v2, vcc_lo              // 0000007EB1E8: D5207C02 01AA0524
	v_cmp_ne_u32_e32 vcc_lo, 1, v35                            // 0000007EB1F0: 7C9A4681
	global_load_b128 v[16:19], v[1:2], off                     // 0000007EB1F4: DC5E0000 107C0001
	s_cbranch_vccnz 64904                                      // 0000007EB1FC: BFA4FD88 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi8ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x520>
	v_ashrrev_i32_e32 v2, 31, v45                              // 0000007EB200: 34045A9F
	.long 0xd7006a01                                           // 0000007EB204: D7006A01
	v_cndmask_b32_e32 v1, v24, v45, vcc_lo                     // 0000007EB208: 02025B18
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007EB20C: BF870001
	v_add_co_ci_u32_e64 v2, null, v33, v2, vcc_lo              // 0000007EB210: D5207C02 01AA0521
	global_load_d16_b16 v1, v[1:2], off                        // 0000007EB218: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 0000007EB220: BF8903F7
	v_cvt_f32_f16_e32 v46, v1                                  // 0000007EB224: 7E5C1701
	s_branch 64893                                             // 0000007EB228: BFA0FD7D <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi8ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x520>
	s_or_b32 exec_lo, exec_lo, s20                             // 0000007EB22C: 8C7E147E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007EB230: BF8700B9
	s_or_b32 exec_lo, exec_lo, s18                             // 0000007EB234: 8C7E127E
	.long 0xd71f0001                                           // 0000007EB238: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000007EB23C: 020100C1
	s_mov_b32 s4, exec_lo                                      // 0000007EB240: BE84007E
	v_xor_b32_e32 v2, 16, v1                                   // 0000007EB244: 3A040290
	v_xor_b32_e32 v10, 8, v1                                   // 0000007EB248: 3A140288
	v_xor_b32_e32 v18, 4, v1                                   // 0000007EB24C: 3A240284
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000007EB250: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 0000007EB254: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 0000007EB258: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v10                           // 0000007EB25C: 7C9814A0
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007EB260: BF870002
	v_lshlrev_b32_e32 v2, 2, v2                                // 0000007EB264: 30040482
	ds_bpermute_b32 v3, v2, v37                                // 0000007EB268: DACC0000 03002502
	s_waitcnt lgkmcnt(0)                                       // 0000007EB270: BF89FC07
	v_add_f32_e32 v3, v37, v3                                  // 0000007EB274: 06060725
	ds_bpermute_b32 v5, v2, v42                                // 0000007EB278: DACC0000 05002A02
	ds_bpermute_b32 v7, v2, v40                                // 0000007EB280: DACC0000 07002802
	ds_bpermute_b32 v9, v2, v38                                // 0000007EB288: DACC0000 09002602
	v_cndmask_b32_e32 v10, v1, v10, vcc_lo                     // 0000007EB290: 02141501
	ds_bpermute_b32 v4, v2, v43                                // 0000007EB294: DACC0000 04002B02
	ds_bpermute_b32 v6, v2, v41                                // 0000007EB29C: DACC0000 06002902
	ds_bpermute_b32 v8, v2, v39                                // 0000007EB2A4: DACC0000 08002702
	ds_bpermute_b32 v2, v2, v34                                // 0000007EB2AC: DACC0000 02002202
	v_cmp_gt_u32_e32 vcc_lo, 32, v18                           // 0000007EB2B4: 7C9824A0
	s_waitcnt lgkmcnt(6)                                       // 0000007EB2B8: BF89FC67
	v_add_f32_e32 v5, v42, v5                                  // 0000007EB2BC: 060A0B2A
	s_waitcnt lgkmcnt(5)                                       // 0000007EB2C0: BF89FC57
	v_dual_add_f32 v7, v40, v7 :: v_dual_lshlrev_b32 v10, 2, v10// 0000007EB2C4: C9220F28 070A1482
	s_waitcnt lgkmcnt(4)                                       // 0000007EB2CC: BF89FC47
	v_add_f32_e32 v9, v38, v9                                  // 0000007EB2D0: 06121326
	ds_bpermute_b32 v11, v10, v3                               // 0000007EB2D4: DACC0000 0B00030A
	ds_bpermute_b32 v13, v10, v5                               // 0000007EB2DC: DACC0000 0D00050A
	ds_bpermute_b32 v15, v10, v7                               // 0000007EB2E4: DACC0000 0F00070A
	ds_bpermute_b32 v17, v10, v9                               // 0000007EB2EC: DACC0000 1100090A
	s_waitcnt lgkmcnt(7)                                       // 0000007EB2F4: BF89FC77
	v_add_f32_e32 v4, v43, v4                                  // 0000007EB2F8: 0608092B
	s_waitcnt lgkmcnt(6)                                       // 0000007EB2FC: BF89FC67
	v_add_f32_e32 v6, v41, v6                                  // 0000007EB300: 060C0D29
	s_waitcnt lgkmcnt(5)                                       // 0000007EB304: BF89FC57
	v_add_f32_e32 v8, v39, v8                                  // 0000007EB308: 06101127
	s_waitcnt lgkmcnt(3)                                       // 0000007EB30C: BF89FC37
	v_dual_add_f32 v2, v34, v2 :: v_dual_add_f32 v3, v3, v11   // 0000007EB310: C9080522 02021703
	ds_bpermute_b32 v14, v10, v6                               // 0000007EB318: DACC0000 0E00060A
	s_waitcnt lgkmcnt(3)                                       // 0000007EB320: BF89FC37
	v_add_f32_e32 v5, v5, v13                                  // 0000007EB324: 060A1B05
	ds_bpermute_b32 v12, v10, v4                               // 0000007EB328: DACC0000 0C00040A
	s_waitcnt lgkmcnt(3)                                       // 0000007EB330: BF89FC37
	v_add_f32_e32 v7, v7, v15                                  // 0000007EB334: 060E1F07
	s_waitcnt lgkmcnt(2)                                       // 0000007EB338: BF89FC27
	v_add_f32_e32 v9, v9, v17                                  // 0000007EB33C: 06122309
	ds_bpermute_b32 v16, v10, v8                               // 0000007EB340: DACC0000 1000080A
	ds_bpermute_b32 v10, v10, v2                               // 0000007EB348: DACC0000 0A00020A
	s_waitcnt lgkmcnt(2)                                       // 0000007EB350: BF89FC27
	v_add_f32_e32 v4, v4, v12                                  // 0000007EB354: 06081904
	s_waitcnt lgkmcnt(1)                                       // 0000007EB358: BF89FC17
	v_add_f32_e32 v8, v8, v16                                  // 0000007EB35C: 06102108
	s_waitcnt lgkmcnt(0)                                       // 0000007EB360: BF89FC07
	v_add_f32_e32 v2, v2, v10                                  // 0000007EB364: 06041502
	v_cndmask_b32_e32 v18, v1, v18, vcc_lo                     // 0000007EB368: 02242501
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007EB36C: BF870001
	v_lshlrev_b32_e32 v18, 2, v18                              // 0000007EB370: 30242482
	ds_bpermute_b32 v12, v18, v5                               // 0000007EB374: DACC0000 0C000512
	s_waitcnt lgkmcnt(0)                                       // 0000007EB37C: BF89FC07
	v_add_f32_e32 v5, v5, v12                                  // 0000007EB380: 060A1905
	ds_bpermute_b32 v16, v18, v9                               // 0000007EB384: DACC0000 10000912
	v_add_f32_e32 v6, v6, v14                                  // 0000007EB38C: 060C1D06
	ds_bpermute_b32 v10, v18, v3                               // 0000007EB390: DACC0000 0A000312
	ds_bpermute_b32 v14, v18, v7                               // 0000007EB398: DACC0000 0E000712
	ds_bpermute_b32 v17, v18, v2                               // 0000007EB3A0: DACC0000 11000212
	s_waitcnt lgkmcnt(3)                                       // 0000007EB3A8: BF89FC37
	v_add_f32_e32 v9, v9, v16                                  // 0000007EB3AC: 06122109
	ds_bpermute_b32 v13, v18, v6                               // 0000007EB3B0: DACC0000 0D000612
	s_waitcnt lgkmcnt(3)                                       // 0000007EB3B8: BF89FC37
	v_add_f32_e32 v3, v3, v10                                  // 0000007EB3BC: 06061503
	ds_bpermute_b32 v11, v18, v4                               // 0000007EB3C0: DACC0000 0B000412
	s_waitcnt lgkmcnt(3)                                       // 0000007EB3C8: BF89FC37
	v_add_f32_e32 v7, v7, v14                                  // 0000007EB3CC: 060E1D07
	ds_bpermute_b32 v15, v18, v8                               // 0000007EB3D0: DACC0000 0F000812
	v_xor_b32_e32 v18, 2, v1                                   // 0000007EB3D8: 3A240282
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007EB3DC: BF870001
	v_cmp_gt_u32_e32 vcc_lo, 32, v18                           // 0000007EB3E0: 7C9824A0
	s_waitcnt lgkmcnt(2)                                       // 0000007EB3E4: BF89FC27
	v_add_f32_e32 v6, v6, v13                                  // 0000007EB3E8: 060C1B06
	v_cndmask_b32_e32 v18, v1, v18, vcc_lo                     // 0000007EB3EC: 02242501
	s_waitcnt lgkmcnt(1)                                       // 0000007EB3F0: BF89FC17
	v_dual_add_f32 v4, v4, v11 :: v_dual_add_f32 v11, v2, v17  // 0000007EB3F4: C9081704 040A2302
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007EB3FC: BF870002
	v_lshlrev_b32_e32 v18, 2, v18                              // 0000007EB400: 30242482
	ds_bpermute_b32 v14, v18, v7                               // 0000007EB404: DACC0000 0E000712
	s_waitcnt lgkmcnt(1)                                       // 0000007EB40C: BF89FC17
	v_add_f32_e32 v8, v8, v15                                  // 0000007EB410: 06101F08
	ds_bpermute_b32 v2, v18, v3                                // 0000007EB414: DACC0000 02000312
	ds_bpermute_b32 v10, v18, v4                               // 0000007EB41C: DACC0000 0A000412
	ds_bpermute_b32 v12, v18, v5                               // 0000007EB424: DACC0000 0C000512
	ds_bpermute_b32 v13, v18, v6                               // 0000007EB42C: DACC0000 0D000612
	ds_bpermute_b32 v15, v18, v8                               // 0000007EB434: DACC0000 0F000812
	ds_bpermute_b32 v16, v18, v9                               // 0000007EB43C: DACC0000 10000912
	ds_bpermute_b32 v17, v18, v11                              // 0000007EB444: DACC0000 11000B12
	v_xor_b32_e32 v18, 1, v1                                   // 0000007EB44C: 3A240281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007EB450: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v18                           // 0000007EB454: 7C9824A0
	v_cndmask_b32_e32 v1, v1, v18, vcc_lo                      // 0000007EB458: 02022501
	s_waitcnt lgkmcnt(6)                                       // 0000007EB45C: BF89FC67
	v_dual_add_f32 v1, v3, v2 :: v_dual_lshlrev_b32 v18, 2, v1 // 0000007EB460: C9220503 01120282
	s_waitcnt lgkmcnt(5)                                       // 0000007EB468: BF89FC57
	v_add_f32_e32 v2, v4, v10                                  // 0000007EB46C: 06041504
	s_waitcnt lgkmcnt(3)                                       // 0000007EB470: BF89FC37
	v_dual_add_f32 v4, v5, v12 :: v_dual_add_f32 v5, v6, v13   // 0000007EB474: C9081905 04041B06
	v_add_f32_e32 v3, v7, v14                                  // 0000007EB47C: 06061D07
	s_waitcnt lgkmcnt(1)                                       // 0000007EB480: BF89FC17
	v_dual_add_f32 v7, v8, v15 :: v_dual_add_f32 v10, v9, v16  // 0000007EB484: C9081F08 070A2109
	s_waitcnt lgkmcnt(0)                                       // 0000007EB48C: BF89FC07
	v_add_f32_e32 v12, v11, v17                                // 0000007EB490: 0618230B
	ds_bpermute_b32 v6, v18, v1                                // 0000007EB494: DACC0000 06000112
	ds_bpermute_b32 v8, v18, v2                                // 0000007EB49C: DACC0000 08000212
	ds_bpermute_b32 v11, v18, v4                               // 0000007EB4A4: DACC0000 0B000412
	ds_bpermute_b32 v13, v18, v5                               // 0000007EB4AC: DACC0000 0D000512
	ds_bpermute_b32 v9, v18, v3                                // 0000007EB4B4: DACC0000 09000312
	ds_bpermute_b32 v14, v18, v7                               // 0000007EB4BC: DACC0000 0E000712
	ds_bpermute_b32 v15, v18, v10                              // 0000007EB4C4: DACC0000 0F000A12
	ds_bpermute_b32 v16, v18, v12                              // 0000007EB4CC: DACC0000 10000C12
	v_cmpx_eq_u32_e32 0, v30                                   // 0000007EB4D4: 7D943C80
	s_cbranch_execz 16                                         // 0000007EB4D8: BFA50010 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi8ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x121c>
	s_waitcnt lgkmcnt(2)                                       // 0000007EB4DC: BF89FC27
	v_dual_add_f32 v14, v7, v14 :: v_dual_add_f32 v19, v4, v11 // 0000007EB4E0: C9081D07 0E121704
	s_waitcnt vmcnt(0)                                         // 0000007EB4E8: BF8903F7
	v_add_f32_e32 v20, v5, v13                                 // 0000007EB4EC: 06281B05
	v_dual_add_f32 v18, v2, v8 :: v_dual_add_f32 v17, v1, v6   // 0000007EB4F0: C9081102 12100D01
	s_waitcnt lgkmcnt(0)                                       // 0000007EB4F8: BF89FC07
	v_dual_add_f32 v16, v12, v16 :: v_dual_lshlrev_b32 v1, 5, v29// 0000007EB4FC: C922210C 10003A85
	v_add_f32_e32 v15, v10, v15                                // 0000007EB504: 061E1F0A
	v_add_f32_e32 v13, v3, v9                                  // 0000007EB508: 061A1303
	ds_store_b128 v1, v[17:20] offset:1024                     // 0000007EB50C: DB7C0400 00001101
	ds_store_b128 v1, v[13:16] offset:1040                     // 0000007EB514: DB7C0410 00000D01
	s_or_b32 exec_lo, exec_lo, s4                              // 0000007EB51C: 8C7E047E
	.long 0xd4510004                                           // 0000007EB520: D4510004
	v_cndmask_b32_e32 v0, s2, v16, vcc_lo                      // 0000007EB524: 02002002
	v_cmp_gt_u32_e32 vcc_lo, 8, v0                             // 0000007EB528: 7C980088
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000007EB52C: BF890007
	s_barrier                                                  // 0000007EB530: BFBD0000
	buffer_gl0_inv                                             // 0000007EB534: E0AC0000 00000000
	s_and_b32 s4, vcc_lo, s4                                   // 0000007EB53C: 8B04046A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000007EB540: BF870009
	s_and_saveexec_b32 s5, s4                                  // 0000007EB544: BE852004
	s_cbranch_execz 89                                         // 0000007EB548: BFA50059 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi8ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x13b0>
	v_add_nc_u32_e32 v7, 0x400, v28                            // 0000007EB54C: 4A0E38FF 00000400
	s_load_b32 s0, s[0:1], 0x48                                // 0000007EB554: F4000000 F8000048
	ds_load_2addr_b32 v[1:2], v7 offset1:8                     // 0000007EB55C: D8DC0800 01000007
	ds_load_2addr_b32 v[3:4], v7 offset0:16 offset1:24         // 0000007EB564: D8DC1810 03000007
	ds_load_2addr_b32 v[5:6], v7 offset0:32 offset1:40         // 0000007EB56C: D8DC2820 05000007
	s_waitcnt lgkmcnt(0)                                       // 0000007EB574: BF89FC07
	v_add_f32_e32 v1, 0, v1                                    // 0000007EB578: 06020280
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007EB57C: BF8700B1
	v_add_f32_e32 v8, v1, v2                                   // 0000007EB580: 06100501
	ds_load_2addr_b32 v[1:2], v7 offset0:48 offset1:56         // 0000007EB584: D8DC3830 01000007
	v_add_f32_e32 v3, v8, v3                                   // 0000007EB58C: 06060708
	v_add_f32_e32 v3, v3, v4                                   // 0000007EB590: 06060903
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007EB594: BF870091
	v_add_f32_e32 v3, v3, v5                                   // 0000007EB598: 06060B03
	v_add_f32_e32 v3, v3, v6                                   // 0000007EB59C: 06060D03
	s_waitcnt lgkmcnt(0)                                       // 0000007EB5A0: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007EB5A4: BF870091
	v_add_f32_e32 v1, v3, v1                                   // 0000007EB5A8: 06020303
	v_add_f32_e32 v1, v1, v2                                   // 0000007EB5AC: 06020501
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007EB5B0: BF870091
	v_bfe_u32 v2, v1, 16, 1                                    // 0000007EB5B4: D6100002 02052101
	v_add3_u32 v1, v1, v2, 0x7fff                              // 0000007EB5BC: D6550001 03FE0501 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007EB5C8: BF870091
	v_and_b32_e32 v1, 0xffff0000, v1                           // 0000007EB5CC: 360202FF FFFF0000
	v_mul_f32_e32 v4, s0, v1                                   // 0000007EB5D4: 10080200
	s_lshl_b64 s[0:1], s[2:3], 1                               // 0000007EB5D8: 84808102
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007EB5DC: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v4                           // 0000007EB5E0: 100208FF BFB8AA3B
	v_exp_f32_e32 v1, v1                                       // 0000007EB5E8: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007EB5EC: BF870095
	v_add_f32_e32 v5, 1.0, v1                                  // 0000007EB5F0: 060A02F2
	v_div_scale_f32 v3, null, v5, v5, v4                       // 0000007EB5F4: D6FC7C03 04120B05
	v_div_scale_f32 v7, vcc_lo, v4, v5, v4                     // 0000007EB5FC: D6FC6A07 04120B04
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000007EB604: BF870292
	v_rcp_f32_e32 v6, v3                                       // 0000007EB608: 7E0C5503
	v_fma_f32 v1, -v3, v6, 1.0                                 // 0000007EB60C: D6130001 23CA0D03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000007EB614: BF870121
	v_fmac_f32_e32 v6, v1, v6                                  // 0000007EB618: 560C0D01
	v_mad_u64_u32 v[1:2], null, s16, v0, 0                     // 0000007EB61C: D6FE7C01 02020010
	v_mul_f32_e32 v8, v7, v6                                   // 0000007EB624: 10100D07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007EB628: BF870091
	v_fma_f32 v9, -v3, v8, v7                                  // 0000007EB62C: D6130009 241E1103
	v_fmac_f32_e32 v8, v9, v6                                  // 0000007EB634: 56100D09
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000007EB638: BF870121
	v_fma_f32 v7, -v3, v8, v7                                  // 0000007EB63C: D6130007 241E1103
	v_mad_u64_u32 v[2:3], null, s17, v0, v[2:3]                // 0000007EB644: D6FE7C02 040A0011
	v_div_fmas_f32 v0, v7, v6, v8                              // 0000007EB64C: D6370000 04220D07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007EB654: BF870191
	v_div_fixup_f32 v3, v0, v5, v4                             // 0000007EB658: D6270003 04120B00
	.long 0xd73c0000                                           // 0000007EB660: D73C0000
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 0000007EB664: 02020281
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007EB668: BF870112
	v_bfe_u32 v2, v3, 16, 1                                    // 0000007EB66C: D6100002 02052103
	.long 0xd7006a00                                           // 0000007EB674: D7006A00
	v_cndmask_b32_e32 v1, s12, v0, vcc_lo                      // 0000007EB678: 0202000C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007EB67C: BF870191
	v_add_co_ci_u32_e64 v1, null, s13, v1, vcc_lo              // 0000007EB680: D5207C01 01AA020D
	v_add3_u32 v2, v3, v2, 0x7fff                              // 0000007EB688: D6550002 03FE0503 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007EB694: BF870093
	.long 0xd7006a00                                           // 0000007EB698: D7006A00
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 0000007EB69C: 02000100
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 0000007EB6A0: D5207C01 01AA0201
	global_store_d16_hi_b16 v[0:1], v2, off                    // 0000007EB6A8: DC960000 007C0200
	s_endpgm                                                   // 0000007EB6B0: BFB00000
		...

