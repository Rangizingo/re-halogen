00000000007e6400 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi16ELi1ELb0ELi1ELi0EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi16ELi1ELb0ELi1ELi0EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 0000007E6400: F4100100 F8000000
	v_dual_mov_b32 v4, 0 :: v_dual_and_b32 v15, 15, v0         // 0000007E6408: CA240080 040E008F
	v_lshrrev_b32_e32 v1, 4, v0                                // 0000007E6410: 32020084
	s_ashr_i32 s3, s2, 31                                      // 0000007E6414: 86039F02
	v_mov_b32_e32 v16, 0                                       // 0000007E6418: 7E200280
	s_lshl_b64 s[2:3], s[2:3], 4                               // 0000007E641C: 84828402
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000007E6420: BF870009
	v_dual_mov_b32 v9, s3 :: v_dual_lshlrev_b32 v2, 2, v15     // 0000007E6424: CA220003 09021E82
	v_lshlrev_b32_e32 v3, 2, v1                                // 0000007E642C: 30060282
	v_or_b32_e32 v8, s2, v1                                    // 0000007E6430: 38100202
	.long 0x7f183880                                           // 0000007E6434: 7F183880
	v_dual_mov_b32 v5, 0 :: v_dual_mov_b32 v6, 0               // 0000007E6438: CA100080 05060080
	s_waitcnt lgkmcnt(0)                                       // 0000007E6440: BF89FC07
	s_clause 0x1                                               // 0000007E6444: BF850001
	global_load_b32 v7, v2, s[4:5]                             // 0000007E6448: DC520000 07040002
	global_load_b32 v3, v3, s[4:5]                             // 0000007E6450: DC520000 03040003
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[8:9]                  // 0000007E6458: 7CA8100C
	s_add_u32 s14, s4, s14                                     // 0000007E645C: 800E0E04
	s_addc_u32 s15, s5, s15                                    // 0000007E6460: 820F0F05
	s_lshr_b32 s2, s11, 31                                     // 0000007E6464: 85029F0B
	v_mov_b32_e32 v27, 0                                       // 0000007E6468: 7E360280
	s_add_u32 s20, s10, s2                                     // 0000007E646C: 8014020A
	v_cndmask_b32_e32 v10, 0, v8, vcc_lo                       // 0000007E6470: 02141080
	v_cndmask_b32_e64 v14, 0, s3, vcc_lo                       // 0000007E6474: D501000E 01A80680
	s_addc_u32 s21, s11, 0                                     // 0000007E647C: 8215800B
	s_ashr_i32 s22, s11, 31                                    // 0000007E6480: 86169F0B
	s_ashr_i64 s[2:3], s[20:21], 1                             // 0000007E6484: 86828114
	.long 0xd72c000d                                           // 0000007E6488: D72C000D
	v_cndmask_b32_e32 v1, s19, v10, vcc_lo                     // 0000007E648C: 02021413
	v_mad_u64_u32 v[1:2], null, s18, v10, 0                    // 0000007E6490: D6FE7C01 02021412
	.long 0xd72c0011                                           // 0000007E6498: D72C0011
	v_cndmask_b32_e32 v0, v10, v3, vcc_lo                      // 0000007E649C: 0200070A
	.long 0xd72c0013                                           // 0000007E64A0: D72C0013
	v_cndmask_b32_e32 v0, v14, v2, vcc_lo                      // 0000007E64A4: 0200050E
	.long 0xd72c000e                                           // 0000007E64A8: D72C000E
	v_cndmask_b32_e32 v1, s18, v14, vcc_lo                     // 0000007E64AC: 02021C12
	s_lshr_b32 s19, s22, 27                                    // 0000007E64B0: 85139B16
	s_waitcnt vmcnt(1)                                         // 0000007E64B4: BF8907F7
	v_bfe_u32 v11, v7, 16, 1                                   // 0000007E64B8: D610000B 02052107
	s_waitcnt vmcnt(0)                                         // 0000007E64C0: BF8903F7
	v_bfe_u32 v18, v3, 16, 1                                   // 0000007E64C4: D6100012 02052103
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007E64CC: BF870002
	v_add3_u32 v7, v7, v11, 0x7fff                             // 0000007E64D0: D6550007 03FE1707 00007FFF
	v_mad_u64_u32 v[10:11], null, v10, s2, s[14:15]            // 0000007E64DC: D6FE7C0A 0038050A
	s_add_u32 s14, s10, s19                                    // 0000007E64E4: 800E130A
	v_add3_u32 v3, v3, v18, 0x7fff                             // 0000007E64E8: D6550003 03FE2503 00007FFF
	s_addc_u32 s15, s11, 0                                     // 0000007E64F4: 820F800B
	.long 0x7e183987                                           // 0000007E64F8: 7E183987
	s_lshr_b64 s[14:15], s[14:15], 5                           // 0000007E64FC: 858E850E
	v_dual_mov_b32 v7, 0 :: v_dual_lshlrev_b32 v18, 2, v0      // 0000007E6500: CA220080 07120082
	.long 0xd4440002                                           // 0000007E6508: D4440002
	v_cndmask_b32_e32 v1, s14, v15, vcc_lo                     // 0000007E650C: 02021E0E
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007E6510: BF870003
	v_and_or_b32 v3, 0xffff0000, v3, v12                       // 0000007E6514: D6570003 043206FF FFFF0000
	v_add3_u32 v17, v19, v11, v17                              // 0000007E6520: D6550011 04461713
	v_add3_u32 v0, v2, v14, v13                                // 0000007E6528: D6550000 04361D02
	ds_store_b32 v18, v3                                       // 0000007E6530: D8340000 00000312
	s_waitcnt lgkmcnt(0)                                       // 0000007E6538: BF89FC07
	s_barrier                                                  // 0000007E653C: BFBD0000
	buffer_gl0_inv                                             // 0000007E6540: E0AC0000 00000000
	s_and_saveexec_b32 s15, s2                                 // 0000007E6548: BE8F2002
	s_cbranch_execz 26                                         // 0000007E654C: BFA5001A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi16ELi1ELb0ELi1ELi0EEEvPKhPKtPvlllllS6_f+0x1b8>
	s_add_u32 s3, s4, s16                                      // 0000007E6550: 80031004
	s_addc_u32 s18, s5, s17                                    // 0000007E6554: 82121105
	v_lshlrev_b32_e32 v2, 1, v15                               // 0000007E6558: 30041E81
	.long 0xd7000303                                           // 0000007E655C: D7000303
	v_cndmask_b32_e32 v1, s3, v1, vcc_lo                       // 0000007E6560: 02020203
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007E6564: BF8701A1
	v_add_co_ci_u32_e64 v4, null, s18, v0, s3                  // 0000007E6568: D5207C04 000E0012
	v_lshlrev_b32_e32 v5, 4, v15                               // 0000007E6570: 300A1E84
	.long 0xd7000302                                           // 0000007E6574: D7000302
	v_cndmask_b32_e32 v1, v3, v2, vcc_lo                       // 0000007E6578: 02020503
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007E657C: BF870191
	v_add_co_ci_u32_e64 v3, null, 0, v4, s3                    // 0000007E6580: D5207C03 000E0880
	.long 0xd7000304                                           // 0000007E6588: D7000304
	v_cndmask_b32_e32 v1, v10, v5, vcc_lo                      // 0000007E658C: 02020B0A
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007E6590: BF870001
	v_add_co_ci_u32_e64 v5, null, 0, v17, s3                   // 0000007E6594: D5207C05 000E2280
	s_clause 0x1                                               // 0000007E659C: BF850001
	global_load_d16_b16 v2, v[2:3], off                        // 0000007E65A0: DC820000 027C0002
	global_load_b128 v[4:7], v[4:5], off                       // 0000007E65A8: DC5E0000 047C0004
	s_waitcnt vmcnt(1)                                         // 0000007E65B0: BF8907F7
	v_cvt_f32_f16_e32 v27, v2                                  // 0000007E65B4: 7E361702
	s_or_b32 exec_lo, exec_lo, s15                             // 0000007E65B8: 8C7E0F7E
	v_dual_mov_b32 v19, 0 :: v_dual_mov_b32 v18, 0             // 0000007E65BC: CA100080 13120080
	v_dual_mov_b32 v21, 0 :: v_dual_mov_b32 v20, 0             // 0000007E65C4: CA100080 15140080
	v_dual_mov_b32 v23, 0 :: v_dual_mov_b32 v22, 0             // 0000007E65CC: CA100080 17160080
	s_and_saveexec_b32 s15, s2                                 // 0000007E65D4: BE8F2002
	s_cbranch_execz 597                                        // 0000007E65D8: BFA50255 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi16ELi1ELb0ELi1ELi0EEEvPKhPKtPvlllllS6_f+0xb30>
	s_mul_i32 s2, s11, 6                                       // 0000007E65DC: 9602860B
	s_mul_hi_u32 s3, s10, 6                                    // 0000007E65E0: 9683860A
	v_dual_mov_b32 v25, v15 :: v_dual_lshlrev_b32 v2, 1, v15   // 0000007E65E4: CA22010F 19021E81
	s_add_i32 s20, s3, s2                                      // 0000007E65EC: 81140203
	.long 0xd7000201                                           // 0000007E65F0: D7000201
	v_cndmask_b32_e32 v1, s16, v1, vcc_lo                      // 0000007E65F4: 02020210
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007E65F8: BF8701A1
	v_add_co_ci_u32_e64 v0, null, s17, v0, s2                  // 0000007E65FC: D5207C00 000A0011
	v_dual_mov_b32 v12, 0 :: v_dual_lshlrev_b32 v11, 5, v15    // 0000007E6604: CA220080 0C0A1E85
	.long 0xd7000201                                           // 0000007E660C: D7000201
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 0000007E6610: 02020501
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007E6614: BF8701A1
	v_add_co_ci_u32_e64 v0, null, 0, v0, s2                    // 0000007E6618: D5207C00 000A0080
	v_lshl_or_b32 v24, v15, 4, 0x100                           // 0000007E6620: D6560018 03FD090F 00000100
	.long 0xd7000201                                           // 0000007E662C: D7000201
	v_cndmask_b32_e32 v1, s4, v1, vcc_lo                       // 0000007E6630: 02020204
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007E6634: BF8701A1
	v_add_co_ci_u32_e64 v0, null, s5, v0, s2                   // 0000007E6638: D5207C00 000A0005
	v_mov_b32_e32 v22, v12                                     // 0000007E6640: 7E2C030C
	.long 0xd700020d                                           // 0000007E6644: D700020D
	v_cndmask_b32_e32 v0, v1, v160, vcc_lo                     // 0000007E6648: 02014101
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007E664C: BF870001
	v_add_co_ci_u32_e64 v14, null, 0, v0, s2                   // 0000007E6650: D5207C0E 000A0080
	v_dual_mov_b32 v23, v12 :: v_dual_mov_b32 v26, v27         // 0000007E6658: CA10010C 171A011B
	v_mov_b32_e32 v20, v12                                     // 0000007E6660: 7E28030C
	v_mov_b32_e32 v21, v12                                     // 0000007E6664: 7E2A030C
	v_mov_b32_e32 v18, v12                                     // 0000007E6668: 7E24030C
	v_mov_b32_e32 v19, v12                                     // 0000007E666C: 7E26030C
	v_mov_b32_e32 v16, v12                                     // 0000007E6670: 7E20030C
	s_lshl_b64 s[18:19], s[10:11], 2                           // 0000007E6674: 8492820A
	s_mul_i32 s17, s10, 6                                      // 0000007E6678: 9611860A
	s_mov_b32 s16, 0                                           // 0000007E667C: BE900080
	s_lshl_b64 s[4:5], s[10:11], 1                             // 0000007E6680: 8484810A
	s_branch 528                                               // 0000007E6684: BFA00210 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi16ELi1ELb0ELi1ELi0EEEvPKhPKtPvlllllS6_f+0xac8>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000007E6688: 8C7E0A7E
	v_and_b32_e32 v28, 0xff, v4                                // 0000007E668C: 363808FF 000000FF
	s_and_b32 s2, exec_lo, s2                                  // 0000007E6694: 8B02027E
	v_add_nc_u32_e32 v24, 0x100, v24                           // 0000007E6698: 4A3030FF 00000100
	s_or_b32 s16, s2, s16                                      // 0000007E66A0: 8C101002
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007E66A4: BF8700B2
	v_lshlrev_b32_e32 v28, 2, v28                              // 0000007E66A8: 30383882
	ds_load_b32 v44, v28                                       // 0000007E66AC: D8D80000 2C00001C
	v_lshrrev_b32_e32 v28, 6, v4                               // 0000007E66B4: 32380886
	v_and_b32_e32 v28, 0x3fc, v28                              // 0000007E66B8: 363838FF 000003FC
	ds_load_b32 v45, v28                                       // 0000007E66C0: D8D80000 2D00001C
	v_lshrrev_b32_e32 v28, 14, v4                              // 0000007E66C8: 3238088E
	v_lshrrev_b32_e32 v4, 22, v4                               // 0000007E66CC: 32080896
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007E66D0: BF870112
	v_and_b32_e32 v28, 0x3fc, v28                              // 0000007E66D4: 363838FF 000003FC
	v_and_b32_e32 v4, 0x3fc, v4                                // 0000007E66DC: 360808FF 000003FC
	ds_load_b32 v46, v28                                       // 0000007E66E4: D8D80000 2E00001C
	ds_load_b32 v47, v4                                        // 0000007E66EC: D8D80000 2F000004
	v_and_b32_e32 v4, 0xff, v5                                 // 0000007E66F4: 36080AFF 000000FF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007E66FC: BF8700B1
	v_lshlrev_b32_e32 v4, 2, v4                                // 0000007E6700: 30080882
	ds_load_b32 v48, v4                                        // 0000007E6704: D8D80000 30000004
	v_lshrrev_b32_e32 v4, 6, v5                                // 0000007E670C: 32080A86
	v_and_b32_e32 v4, 0x3fc, v4                                // 0000007E6710: 360808FF 000003FC
	ds_load_b32 v49, v4                                        // 0000007E6718: D8D80000 31000004
	v_lshrrev_b32_e32 v4, 14, v5                               // 0000007E6720: 32080A8E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007E6724: BF8700B1
	v_and_b32_e32 v4, 0x3fc, v4                                // 0000007E6728: 360808FF 000003FC
	ds_load_b32 v50, v4                                        // 0000007E6730: D8D80000 32000004
	v_lshrrev_b32_e32 v4, 22, v5                               // 0000007E6738: 32080A96
	v_and_b32_e32 v4, 0x3fc, v4                                // 0000007E673C: 360808FF 000003FC
	ds_load_b32 v51, v4                                        // 0000007E6744: D8D80000 33000004
	v_and_b32_e32 v4, 0xff, v6                                 // 0000007E674C: 36080CFF 000000FF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007E6754: BF8700B1
	v_lshlrev_b32_e32 v4, 2, v4                                // 0000007E6758: 30080882
	ds_load_b32 v52, v4                                        // 0000007E675C: D8D80000 34000004
	v_lshrrev_b32_e32 v4, 6, v6                                // 0000007E6764: 32080C86
	v_and_b32_e32 v4, 0x3fc, v4                                // 0000007E6768: 360808FF 000003FC
	ds_load_b32 v53, v4                                        // 0000007E6770: D8D80000 35000004
	v_lshrrev_b32_e32 v4, 14, v6                               // 0000007E6778: 32080C8E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007E677C: BF8700B1
	v_and_b32_e32 v4, 0x3fc, v4                                // 0000007E6780: 360808FF 000003FC
	ds_load_b32 v54, v4                                        // 0000007E6788: D8D80000 36000004
	v_lshrrev_b32_e32 v4, 22, v6                               // 0000007E6790: 32080C96
	v_and_b32_e32 v4, 0x3fc, v4                                // 0000007E6794: 360808FF 000003FC
	ds_load_b32 v55, v4                                        // 0000007E679C: D8D80000 37000004
	v_and_b32_e32 v4, 0xff, v7                                 // 0000007E67A4: 36080EFF 000000FF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007E67AC: BF8700B1
	v_lshlrev_b32_e32 v4, 2, v4                                // 0000007E67B0: 30080882
	ds_load_b32 v56, v4                                        // 0000007E67B4: D8D80000 38000004
	v_lshrrev_b32_e32 v4, 6, v7                                // 0000007E67BC: 32080E86
	v_and_b32_e32 v4, 0x3fc, v4                                // 0000007E67C0: 360808FF 000003FC
	ds_load_b32 v57, v4                                        // 0000007E67C8: D8D80000 39000004
	v_lshrrev_b32_e32 v4, 14, v7                               // 0000007E67D0: 32080E8E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007E67D4: BF8700B1
	v_and_b32_e32 v4, 0x3fc, v4                                // 0000007E67D8: 360808FF 000003FC
	ds_load_b32 v58, v4                                        // 0000007E67E0: D8D80000 3A000004
	v_lshrrev_b32_e32 v4, 22, v7                               // 0000007E67E8: 32080E96
	v_and_b32_e32 v4, 0x3fc, v4                                // 0000007E67EC: 360808FF 000003FC
	ds_load_b32 v59, v4                                        // 0000007E67F4: D8D80000 3B000004
	.long 0xd73c0004                                           // 0000007E67FC: D73C0004
	v_cndmask_b32_e32 v1, 1, v11, vcc_lo                       // 0000007E6800: 02021681
	v_add_nc_u32_e32 v11, 0x200, v11                           // 0000007E6804: 4A1616FF 00000200
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E680C: BF870092
	.long 0xd7000228                                           // 0000007E6810: D7000228
	v_cndmask_b32_e32 v1, s6, v4, vcc_lo                       // 0000007E6814: 02020806
	v_add_co_ci_u32_e64 v41, null, s7, v5, s2                  // 0000007E6818: D5207C29 000A0A07
	s_clause 0x3                                               // 0000007E6820: BF850003
	global_load_b128 v[4:7], v[40:41], off                     // 0000007E6824: DC5E0000 047C0028
	global_load_b128 v[28:31], v[40:41], off offset:16         // 0000007E682C: DC5E0010 1C7C0028
	global_load_b128 v[32:35], v[40:41], off offset:32         // 0000007E6834: DC5E0020 207C0028
	global_load_b128 v[36:39], v[40:41], off offset:48         // 0000007E683C: DC5E0030 247C0028
	s_waitcnt vmcnt(3) lgkmcnt(15)                             // 0000007E6844: BF890CF7
	v_dot2_f32_bf16 v4, v4, v44, 0                             // 0000007E6848: CC1A4004 1A025904
	s_waitcnt lgkmcnt(14)                                      // 0000007E6850: BF89FCE7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007E6854: BF8700A1
	v_dot2_f32_bf16 v4, v5, v45, v4                            // 0000007E6858: CC1A4004 1C125B05
	s_waitcnt lgkmcnt(13)                                      // 0000007E6860: BF89FCD7
	v_dot2_f32_bf16 v4, v6, v46, v4                            // 0000007E6864: CC1A4004 1C125D06
	s_waitcnt lgkmcnt(12)                                      // 0000007E686C: BF89FCC7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007E6870: BF8700A1
	v_dot2_f32_bf16 v4, v7, v47, v4                            // 0000007E6874: CC1A4004 1C125F07
	s_waitcnt vmcnt(2) lgkmcnt(11)                             // 0000007E687C: BF8908B7
	v_dot2_f32_bf16 v4, v28, v48, v4                           // 0000007E6880: CC1A4004 1C12611C
	s_waitcnt lgkmcnt(10)                                      // 0000007E6888: BF89FCA7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007E688C: BF8700A1
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 0000007E6890: CC1A4004 1C12631D
	s_waitcnt lgkmcnt(9)                                       // 0000007E6898: BF89FC97
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 0000007E689C: CC1A4004 1C12651E
	s_waitcnt lgkmcnt(8)                                       // 0000007E68A4: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007E68A8: BF8700A1
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 0000007E68AC: CC1A4004 1C12671F
	s_waitcnt vmcnt(1) lgkmcnt(7)                              // 0000007E68B4: BF890477
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 0000007E68B8: CC1A4004 1C126920
	s_waitcnt lgkmcnt(6)                                       // 0000007E68C0: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007E68C4: BF8700A1
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 0000007E68C8: CC1A4004 1C126B21
	s_waitcnt lgkmcnt(5)                                       // 0000007E68D0: BF89FC57
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 0000007E68D4: CC1A4004 1C126D22
	s_waitcnt lgkmcnt(4)                                       // 0000007E68DC: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007E68E0: BF8700A1
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 0000007E68E4: CC1A4004 1C126F23
	s_waitcnt vmcnt(0) lgkmcnt(3)                              // 0000007E68EC: BF890037
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 0000007E68F0: CC1A4004 1C127124
	.long 0xd7000224                                           // 0000007E68F8: D7000224
	v_cndmask_b32_e32 v0, v40, v4, vcc_lo                      // 0000007E68FC: 02000928
	s_waitcnt lgkmcnt(2)                                       // 0000007E6900: BF89FC27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000007E6904: BF8701C2
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 0000007E6908: CC1A4004 1C127325
	v_add_co_ci_u32_e64 v37, null, s5, v41, s2                 // 0000007E6910: D5207C25 000A5205
	.long 0xd700022a                                           // 0000007E6918: D700022A
	v_cndmask_b32_e32 v0, v40, v18, vcc_lo                     // 0000007E691C: 02002528
	s_waitcnt lgkmcnt(1)                                       // 0000007E6920: BF89FC17
	v_dot2_f32_bf16 v4, v38, v58, v4                           // 0000007E6924: CC1A4004 1C127526
	v_add_co_ci_u32_e64 v43, null, s19, v41, s2                // 0000007E692C: D5207C2B 000A5213
	.long 0xd7000228                                           // 0000007E6934: D7000228
	v_cndmask_b32_e32 v0, v40, v17, vcc_lo                     // 0000007E6938: 02002328
	s_waitcnt lgkmcnt(0)                                       // 0000007E693C: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000007E6940: BF870123
	v_dot2_f32_bf16 v4, v39, v59, v4                           // 0000007E6944: CC1A4004 1C127727
	v_add_co_ci_u32_e64 v41, null, s20, v41, s2                // 0000007E694C: D5207C29 000A5214
	v_fmac_f32_e32 v22, v27, v4                                // 0000007E6954: 562C091B
	s_clause 0x3                                               // 0000007E6958: BF850003
	global_load_b128 v[4:7], v[36:37], off                     // 0000007E695C: DC5E0000 047C0024
	global_load_b128 v[28:31], v[36:37], off offset:16         // 0000007E6964: DC5E0010 1C7C0024
	global_load_b128 v[32:35], v[36:37], off offset:32         // 0000007E696C: DC5E0020 207C0024
	global_load_b128 v[36:39], v[36:37], off offset:48         // 0000007E6974: DC5E0030 247C0024
	s_waitcnt vmcnt(3)                                         // 0000007E697C: BF890FF7
	v_dot2_f32_bf16 v4, v4, v44, 0                             // 0000007E6980: CC1A4004 1A025904
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E6988: BF870091
	v_dot2_f32_bf16 v4, v5, v45, v4                            // 0000007E698C: CC1A4004 1C125B05
	v_dot2_f32_bf16 v4, v6, v46, v4                            // 0000007E6994: CC1A4004 1C125D06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007E699C: BF8700A1
	v_dot2_f32_bf16 v4, v7, v47, v4                            // 0000007E69A0: CC1A4004 1C125F07
	s_waitcnt vmcnt(2)                                         // 0000007E69A8: BF890BF7
	v_dot2_f32_bf16 v4, v28, v48, v4                           // 0000007E69AC: CC1A4004 1C12611C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E69B4: BF870091
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 0000007E69B8: CC1A4004 1C12631D
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 0000007E69C0: CC1A4004 1C12651E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007E69C8: BF8700A1
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 0000007E69CC: CC1A4004 1C12671F
	s_waitcnt vmcnt(1)                                         // 0000007E69D4: BF8907F7
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 0000007E69D8: CC1A4004 1C126920
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E69E0: BF870091
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 0000007E69E4: CC1A4004 1C126B21
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 0000007E69EC: CC1A4004 1C126D22
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007E69F4: BF8700A1
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 0000007E69F8: CC1A4004 1C126F23
	s_waitcnt vmcnt(0)                                         // 0000007E6A00: BF8903F7
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 0000007E6A04: CC1A4004 1C127124
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E6A0C: BF870091
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 0000007E6A10: CC1A4004 1C127325
	v_dot2_f32_bf16 v4, v38, v58, v4                           // 0000007E6A18: CC1A4004 1C127526
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E6A20: BF870091
	v_dot2_f32_bf16 v4, v39, v59, v4                           // 0000007E6A24: CC1A4004 1C127727
	v_fmac_f32_e32 v23, v27, v4                                // 0000007E6A2C: 562E091B
	s_clause 0x3                                               // 0000007E6A30: BF850003
	global_load_b128 v[4:7], v[42:43], off                     // 0000007E6A34: DC5E0000 047C002A
	global_load_b128 v[28:31], v[42:43], off offset:16         // 0000007E6A3C: DC5E0010 1C7C002A
	global_load_b128 v[32:35], v[42:43], off offset:32         // 0000007E6A44: DC5E0020 207C002A
	global_load_b128 v[36:39], v[42:43], off offset:48         // 0000007E6A4C: DC5E0030 247C002A
	.long 0xd700022a                                           // 0000007E6A54: D700022A
	v_cndmask_b32_e32 v0, v42, v18, vcc_lo                     // 0000007E6A58: 0200252A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007E6A5C: BF8700B1
	v_add_co_ci_u32_e64 v43, null, s19, v43, s2                // 0000007E6A60: D5207C2B 000A5613
	s_waitcnt vmcnt(3)                                         // 0000007E6A68: BF890FF7
	v_dot2_f32_bf16 v4, v4, v44, 0                             // 0000007E6A6C: CC1A4004 1A025904
	v_dot2_f32_bf16 v4, v5, v45, v4                            // 0000007E6A74: CC1A4004 1C125B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E6A7C: BF870091
	v_dot2_f32_bf16 v4, v6, v46, v4                            // 0000007E6A80: CC1A4004 1C125D06
	v_dot2_f32_bf16 v4, v7, v47, v4                            // 0000007E6A88: CC1A4004 1C125F07
	s_waitcnt vmcnt(2)                                         // 0000007E6A90: BF890BF7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E6A94: BF870091
	v_dot2_f32_bf16 v4, v28, v48, v4                           // 0000007E6A98: CC1A4004 1C12611C
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 0000007E6AA0: CC1A4004 1C12631D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E6AA8: BF870091
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 0000007E6AAC: CC1A4004 1C12651E
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 0000007E6AB4: CC1A4004 1C12671F
	s_waitcnt vmcnt(1)                                         // 0000007E6ABC: BF8907F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E6AC0: BF870091
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 0000007E6AC4: CC1A4004 1C126920
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 0000007E6ACC: CC1A4004 1C126B21
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E6AD4: BF870091
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 0000007E6AD8: CC1A4004 1C126D22
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 0000007E6AE0: CC1A4004 1C126F23
	s_waitcnt vmcnt(0)                                         // 0000007E6AE8: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E6AEC: BF870091
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 0000007E6AF0: CC1A4004 1C127124
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 0000007E6AF8: CC1A4004 1C127325
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E6B00: BF870091
	v_dot2_f32_bf16 v4, v38, v58, v4                           // 0000007E6B04: CC1A4004 1C127526
	v_dot2_f32_bf16 v4, v39, v59, v4                           // 0000007E6B0C: CC1A4004 1C127727
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007E6B14: BF870001
	v_fmac_f32_e32 v20, v27, v4                                // 0000007E6B18: 5628091B
	s_clause 0x3                                               // 0000007E6B1C: BF850003
	global_load_b128 v[4:7], v[40:41], off                     // 0000007E6B20: DC5E0000 047C0028
	global_load_b128 v[28:31], v[40:41], off offset:16         // 0000007E6B28: DC5E0010 1C7C0028
	global_load_b128 v[32:35], v[40:41], off offset:32         // 0000007E6B30: DC5E0020 207C0028
	global_load_b128 v[36:39], v[40:41], off offset:48         // 0000007E6B38: DC5E0030 247C0028
	s_waitcnt vmcnt(3)                                         // 0000007E6B40: BF890FF7
	v_dot2_f32_bf16 v4, v4, v44, 0                             // 0000007E6B44: CC1A4004 1A025904
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E6B4C: BF870091
	v_dot2_f32_bf16 v4, v5, v45, v4                            // 0000007E6B50: CC1A4004 1C125B05
	v_dot2_f32_bf16 v4, v6, v46, v4                            // 0000007E6B58: CC1A4004 1C125D06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007E6B60: BF8700A1
	v_dot2_f32_bf16 v4, v7, v47, v4                            // 0000007E6B64: CC1A4004 1C125F07
	s_waitcnt vmcnt(2)                                         // 0000007E6B6C: BF890BF7
	v_dot2_f32_bf16 v4, v28, v48, v4                           // 0000007E6B70: CC1A4004 1C12611C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E6B78: BF870091
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 0000007E6B7C: CC1A4004 1C12631D
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 0000007E6B84: CC1A4004 1C12651E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007E6B8C: BF8700A1
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 0000007E6B90: CC1A4004 1C12671F
	s_waitcnt vmcnt(1)                                         // 0000007E6B98: BF8907F7
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 0000007E6B9C: CC1A4004 1C126920
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E6BA4: BF870091
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 0000007E6BA8: CC1A4004 1C126B21
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 0000007E6BB0: CC1A4004 1C126D22
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007E6BB8: BF8700A1
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 0000007E6BBC: CC1A4004 1C126F23
	s_waitcnt vmcnt(0)                                         // 0000007E6BC4: BF8903F7
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 0000007E6BC8: CC1A4004 1C127124
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E6BD0: BF870091
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 0000007E6BD4: CC1A4004 1C127325
	v_dot2_f32_bf16 v4, v38, v58, v4                           // 0000007E6BDC: CC1A4004 1C127526
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E6BE4: BF870091
	v_dot2_f32_bf16 v4, v39, v59, v4                           // 0000007E6BE8: CC1A4004 1C127727
	v_fmac_f32_e32 v21, v27, v4                                // 0000007E6BF0: 562A091B
	s_clause 0x3                                               // 0000007E6BF4: BF850003
	global_load_b128 v[4:7], v[42:43], off                     // 0000007E6BF8: DC5E0000 047C002A
	global_load_b128 v[28:31], v[42:43], off offset:16         // 0000007E6C00: DC5E0010 1C7C002A
	global_load_b128 v[32:35], v[42:43], off offset:32         // 0000007E6C08: DC5E0020 207C002A
	global_load_b128 v[36:39], v[42:43], off offset:48         // 0000007E6C10: DC5E0030 247C002A
	s_waitcnt vmcnt(3)                                         // 0000007E6C18: BF890FF7
	v_dot2_f32_bf16 v4, v4, v44, 0                             // 0000007E6C1C: CC1A4004 1A025904
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E6C24: BF870091
	v_dot2_f32_bf16 v4, v5, v45, v4                            // 0000007E6C28: CC1A4004 1C125B05
	v_dot2_f32_bf16 v4, v6, v46, v4                            // 0000007E6C30: CC1A4004 1C125D06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007E6C38: BF8700A1
	v_dot2_f32_bf16 v4, v7, v47, v4                            // 0000007E6C3C: CC1A4004 1C125F07
	s_waitcnt vmcnt(2)                                         // 0000007E6C44: BF890BF7
	v_dot2_f32_bf16 v4, v28, v48, v4                           // 0000007E6C48: CC1A4004 1C12611C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E6C50: BF870091
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 0000007E6C54: CC1A4004 1C12631D
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 0000007E6C5C: CC1A4004 1C12651E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007E6C64: BF8700A1
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 0000007E6C68: CC1A4004 1C12671F
	s_waitcnt vmcnt(1)                                         // 0000007E6C70: BF8907F7
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 0000007E6C74: CC1A4004 1C126920
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E6C7C: BF870091
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 0000007E6C80: CC1A4004 1C126B21
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 0000007E6C88: CC1A4004 1C126D22
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007E6C90: BF8700A1
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 0000007E6C94: CC1A4004 1C126F23
	s_waitcnt vmcnt(0)                                         // 0000007E6C9C: BF8903F7
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 0000007E6CA0: CC1A4004 1C127124
	.long 0xd7000224                                           // 0000007E6CA8: D7000224
	v_cndmask_b32_e32 v0, v40, v18, vcc_lo                     // 0000007E6CAC: 02002528
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000007E6CB0: BF870122
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 0000007E6CB4: CC1A4004 1C127325
	v_add_co_ci_u32_e64 v37, null, s19, v41, s2                // 0000007E6CBC: D5207C25 000A5213
	v_dot2_f32_bf16 v4, v38, v58, v4                           // 0000007E6CC4: CC1A4004 1C127526
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E6CCC: BF870091
	v_dot2_f32_bf16 v4, v39, v59, v4                           // 0000007E6CD0: CC1A4004 1C127727
	v_fmac_f32_e32 v18, v27, v4                                // 0000007E6CD8: 5624091B
	s_clause 0x3                                               // 0000007E6CDC: BF850003
	global_load_b128 v[4:7], v[36:37], off                     // 0000007E6CE0: DC5E0000 047C0024
	global_load_b128 v[28:31], v[36:37], off offset:16         // 0000007E6CE8: DC5E0010 1C7C0024
	global_load_b128 v[32:35], v[36:37], off offset:32         // 0000007E6CF0: DC5E0020 207C0024
	global_load_b128 v[36:39], v[36:37], off offset:48         // 0000007E6CF8: DC5E0030 247C0024
	s_waitcnt vmcnt(3)                                         // 0000007E6D00: BF890FF7
	v_dot2_f32_bf16 v4, v4, v44, 0                             // 0000007E6D04: CC1A4004 1A025904
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E6D0C: BF870091
	v_dot2_f32_bf16 v4, v5, v45, v4                            // 0000007E6D10: CC1A4004 1C125B05
	v_dot2_f32_bf16 v4, v6, v46, v4                            // 0000007E6D18: CC1A4004 1C125D06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007E6D20: BF8700A1
	v_dot2_f32_bf16 v4, v7, v47, v4                            // 0000007E6D24: CC1A4004 1C125F07
	s_waitcnt vmcnt(2)                                         // 0000007E6D2C: BF890BF7
	v_dot2_f32_bf16 v4, v28, v48, v4                           // 0000007E6D30: CC1A4004 1C12611C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E6D38: BF870091
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 0000007E6D3C: CC1A4004 1C12631D
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 0000007E6D44: CC1A4004 1C12651E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007E6D4C: BF8700A1
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 0000007E6D50: CC1A4004 1C12671F
	s_waitcnt vmcnt(1)                                         // 0000007E6D58: BF8907F7
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 0000007E6D5C: CC1A4004 1C126920
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E6D64: BF870091
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 0000007E6D68: CC1A4004 1C126B21
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 0000007E6D70: CC1A4004 1C126D22
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007E6D78: BF8700A1
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 0000007E6D7C: CC1A4004 1C126F23
	s_waitcnt vmcnt(0)                                         // 0000007E6D84: BF8903F7
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 0000007E6D88: CC1A4004 1C127124
	.long 0xd7000224                                           // 0000007E6D90: D7000224
	v_cndmask_b32_e32 v0, v42, v18, vcc_lo                     // 0000007E6D94: 0200252A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000007E6D98: BF8701B2
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 0000007E6D9C: CC1A4004 1C127325
	v_add_co_ci_u32_e64 v37, null, s19, v43, s2                // 0000007E6DA4: D5207C25 000A5613
	.long 0xd700020d                                           // 0000007E6DAC: D700020D
	v_cndmask_b32_e32 v0, v13, v160, vcc_lo                    // 0000007E6DB0: 0201410D
	v_dot2_f32_bf16 v4, v38, v58, v4                           // 0000007E6DB4: CC1A4004 1C127526
	v_add_co_ci_u32_e64 v14, null, 0, v14, s2                  // 0000007E6DBC: D5207C0E 000A1C80
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E6DC4: BF870092
	v_dot2_f32_bf16 v4, v39, v59, v4                           // 0000007E6DC8: CC1A4004 1C127727
	v_fmac_f32_e32 v19, v27, v4                                // 0000007E6DD0: 5626091B
	s_clause 0x3                                               // 0000007E6DD4: BF850003
	global_load_b128 v[4:7], v[36:37], off                     // 0000007E6DD8: DC5E0000 047C0024
	global_load_b128 v[28:31], v[36:37], off offset:16         // 0000007E6DE0: DC5E0010 1C7C0024
	global_load_b128 v[32:35], v[36:37], off offset:32         // 0000007E6DE8: DC5E0020 207C0024
	global_load_b128 v[36:39], v[36:37], off offset:48         // 0000007E6DF0: DC5E0030 247C0024
	s_waitcnt vmcnt(3)                                         // 0000007E6DF8: BF890FF7
	v_dot2_f32_bf16 v4, v4, v44, 0                             // 0000007E6DFC: CC1A4004 1A025904
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000007E6E04: BF870121
	v_dot2_f32_bf16 v4, v5, v45, v4                            // 0000007E6E08: CC1A4004 1C125B05
	v_mov_b32_e32 v5, v1                                       // 0000007E6E10: 7E0A0301
	v_dot2_f32_bf16 v4, v6, v46, v4                            // 0000007E6E14: CC1A4004 1C125D06
	v_mov_b32_e32 v6, v2                                       // 0000007E6E1C: 7E0C0302
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000007E6E20: BF870132
	v_dot2_f32_bf16 v4, v7, v47, v4                            // 0000007E6E24: CC1A4004 1C125F07
	v_mov_b32_e32 v7, v3                                       // 0000007E6E2C: 7E0E0303
	s_waitcnt vmcnt(2)                                         // 0000007E6E30: BF890BF7
	v_dot2_f32_bf16 v4, v28, v48, v4                           // 0000007E6E34: CC1A4004 1C12611C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E6E3C: BF870091
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 0000007E6E40: CC1A4004 1C12631D
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 0000007E6E48: CC1A4004 1C12651E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007E6E50: BF8700A1
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 0000007E6E54: CC1A4004 1C12671F
	s_waitcnt vmcnt(1)                                         // 0000007E6E5C: BF8907F7
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 0000007E6E60: CC1A4004 1C126920
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E6E68: BF870091
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 0000007E6E6C: CC1A4004 1C126B21
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 0000007E6E74: CC1A4004 1C126D22
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007E6E7C: BF8700A1
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 0000007E6E80: CC1A4004 1C126F23
	s_waitcnt vmcnt(0)                                         // 0000007E6E88: BF8903F7
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 0000007E6E8C: CC1A4004 1C127124
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E6E94: BF870091
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 0000007E6E98: CC1A4004 1C127325
	v_dot2_f32_bf16 v4, v38, v58, v4                           // 0000007E6EA0: CC1A4004 1C127526
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E6EA8: BF870091
	v_dot2_f32_bf16 v4, v39, v59, v4                           // 0000007E6EAC: CC1A4004 1C127727
	v_fmac_f32_e32 v16, v27, v4                                // 0000007E6EB4: 5620091B
	v_dual_mov_b32 v4, v0 :: v_dual_mov_b32 v27, v26           // 0000007E6EB8: CA100100 041A011A
	s_and_not1_b32 exec_lo, exec_lo, s16                       // 0000007E6EC0: 917E107E
	s_cbranch_execz 25                                         // 0000007E6EC4: BFA50019 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi16ELi1ELb0ELi1ELi0EEEvPKhPKtPvlllllS6_f+0xb2c>
	s_waitcnt vmcnt(0)                                         // 0000007E6EC8: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000007E6ECC: BF8701B1
	v_dual_mov_b32 v0, v4 :: v_dual_add_nc_u32 v25, 16, v25    // 0000007E6ED0: CA200104 00183290
	v_dual_mov_b32 v1, v5 :: v_dual_mov_b32 v2, v6             // 0000007E6ED8: CA100105 01020106
	v_mov_b32_e32 v3, v7                                       // 0000007E6EE0: 7E060307
	.long 0xd4430002                                           // 0000007E6EE4: D4430002
	v_cndmask_b32_e32 v1, s14, v25, vcc_lo                     // 0000007E6EE8: 0202320E
	s_mov_b32 s10, exec_lo                                     // 0000007E6EEC: BE8A007E
	.long 0xd4c4007e                                           // 0000007E6EF0: D4C4007E
	v_cndmask_b32_e32 v1, s14, v25, vcc_lo                     // 0000007E6EF4: 0202320E
	s_cbranch_execz 64995                                      // 0000007E6EF8: BFA5FDE3 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi16ELi1ELb0ELi1ELi0EEEvPKhPKtPvlllllS6_f+0x288>
	.long 0xd7000300                                           // 0000007E6EFC: D7000300
	v_cndmask_b32_e32 v1, v10, v24, vcc_lo                     // 0000007E6F00: 0202310A
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007E6F04: BF870001
	v_add_co_ci_u32_e64 v1, null, 0, v17, s3                   // 0000007E6F08: D5207C01 000E2280
	global_load_d16_b16 v26, v[13:14], off                     // 0000007E6F10: DC820000 1A7C000D
	global_load_b128 v[0:3], v[0:1], off                       // 0000007E6F18: DC5E0000 007C0000
	s_waitcnt vmcnt(1)                                         // 0000007E6F20: BF8907F7
	v_cvt_f32_f16_e32 v26, v26                                 // 0000007E6F24: 7E34171A
	s_branch 64983                                             // 0000007E6F28: BFA0FDD7 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi16ELi1ELb0ELi1ELi0EEEvPKhPKtPvlllllS6_f+0x288>
	s_or_b32 exec_lo, exec_lo, s16                             // 0000007E6F2C: 8C7E107E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007E6F30: BF8700A9
	s_or_b32 exec_lo, exec_lo, s15                             // 0000007E6F34: 8C7E0F7E
	.long 0xd71f0000                                           // 0000007E6F38: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000007E6F3C: 020100C1
	v_xor_b32_e32 v1, 8, v0                                    // 0000007E6F40: 3A020088
	v_xor_b32_e32 v10, 4, v0                                   // 0000007E6F44: 3A140084
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E6F48: BF870092
	.long 0xd44c0002                                           // 0000007E6F4C: D44C0002
	v_cndmask_b32_e32 v1, 32, v1, vcc_lo                       // 0000007E6F50: 020202A0
	v_cndmask_b32_e64 v1, v0, v1, s2                           // 0000007E6F54: D5010001 000A0300
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007E6F5C: BF870113
	.long 0xd44c0002                                           // 0000007E6F60: D44C0002
	v_cndmask_b32_e32 v1, 32, v10, vcc_lo                      // 0000007E6F64: 020214A0
	v_lshlrev_b32_e32 v1, 2, v1                                // 0000007E6F68: 30020282
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007E6F6C: BF870002
	v_cndmask_b32_e64 v10, v0, v10, s2                         // 0000007E6F70: D501000A 000A1500
	ds_bpermute_b32 v2, v1, v16                                // 0000007E6F78: DACC0000 02001001
	s_waitcnt lgkmcnt(0)                                       // 0000007E6F80: BF89FC07
	v_add_f32_e32 v2, v16, v2                                  // 0000007E6F84: 06040510
	ds_bpermute_b32 v3, v1, v23                                // 0000007E6F88: DACC0000 03001701
	s_waitcnt vmcnt(0)                                         // 0000007E6F90: BF8903F7
	ds_bpermute_b32 v4, v1, v22                                // 0000007E6F94: DACC0000 04001601
	ds_bpermute_b32 v5, v1, v21                                // 0000007E6F9C: DACC0000 05001501
	ds_bpermute_b32 v6, v1, v20                                // 0000007E6FA4: DACC0000 06001401
	ds_bpermute_b32 v7, v1, v19                                // 0000007E6FAC: DACC0000 07001301
	ds_bpermute_b32 v1, v1, v18                                // 0000007E6FB4: DACC0000 01001201
	s_waitcnt lgkmcnt(5)                                       // 0000007E6FBC: BF89FC57
	v_dual_add_f32 v3, v23, v3 :: v_dual_lshlrev_b32 v10, 2, v10// 0000007E6FC0: C9220717 030A1482
	ds_bpermute_b32 v11, v10, v2                               // 0000007E6FC8: DACC0000 0B00020A
	s_waitcnt lgkmcnt(4)                                       // 0000007E6FD0: BF89FC47
	v_dual_add_f32 v4, v22, v4 :: v_dual_add_f32 v5, v21, v5   // 0000007E6FD4: C9080916 04040B15
	s_waitcnt lgkmcnt(2)                                       // 0000007E6FDC: BF89FC27
	v_dual_add_f32 v6, v20, v6 :: v_dual_add_f32 v7, v19, v7   // 0000007E6FE0: C9080D14 06060F13
	s_waitcnt lgkmcnt(1)                                       // 0000007E6FE8: BF89FC17
	v_add_f32_e32 v1, v18, v1                                  // 0000007E6FEC: 06020312
	v_xor_b32_e32 v18, 2, v0                                   // 0000007E6FF0: 3A240082
	ds_bpermute_b32 v12, v10, v3                               // 0000007E6FF4: DACC0000 0C00030A
	ds_bpermute_b32 v13, v10, v4                               // 0000007E6FFC: DACC0000 0D00040A
	ds_bpermute_b32 v14, v10, v5                               // 0000007E7004: DACC0000 0E00050A
	ds_bpermute_b32 v16, v10, v6                               // 0000007E700C: DACC0000 1000060A
	.long 0xd44c0002                                           // 0000007E7014: D44C0002
	v_cndmask_b32_e32 v1, 32, v18, vcc_lo                      // 0000007E7018: 020224A0
	ds_bpermute_b32 v17, v10, v7                               // 0000007E701C: DACC0000 1100070A
	v_cndmask_b32_e64 v18, v0, v18, s2                         // 0000007E7024: D5010012 000A2500
	s_waitcnt lgkmcnt(5)                                       // 0000007E702C: BF89FC57
	v_add_f32_e32 v2, v2, v11                                  // 0000007E7030: 06041702
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007E7034: BF870002
	v_lshlrev_b32_e32 v18, 2, v18                              // 0000007E7038: 30242482
	ds_bpermute_b32 v10, v10, v1                               // 0000007E703C: DACC0000 0A00010A
	s_waitcnt lgkmcnt(5)                                       // 0000007E7044: BF89FC57
	v_add_f32_e32 v3, v3, v12                                  // 0000007E7048: 06061903
	v_xor_b32_e32 v12, 1, v0                                   // 0000007E704C: 3A180081
	s_waitcnt lgkmcnt(3)                                       // 0000007E7050: BF89FC37
	v_dual_add_f32 v4, v4, v13 :: v_dual_add_f32 v5, v5, v14   // 0000007E7054: C9081B04 04041D05
	s_waitcnt lgkmcnt(1)                                       // 0000007E705C: BF89FC17
	v_dual_add_f32 v11, v6, v16 :: v_dual_add_f32 v14, v7, v17 // 0000007E7060: C9082106 0B0E2307
	.long 0xd44c0002                                           // 0000007E7068: D44C0002
	v_cndmask_b32_e32 v1, 32, v12, vcc_lo                      // 0000007E706C: 020218A0
	ds_bpermute_b32 v6, v18, v3                                // 0000007E7070: DACC0000 06000312
	ds_bpermute_b32 v7, v18, v4                                // 0000007E7078: DACC0000 07000412
	ds_bpermute_b32 v16, v18, v11                              // 0000007E7080: DACC0000 10000B12
	ds_bpermute_b32 v17, v18, v14                              // 0000007E7088: DACC0000 11000E12
	v_cndmask_b32_e64 v0, v0, v12, s2                          // 0000007E7090: D5010000 000A1900
	.long 0xd44a0002                                           // 0000007E7098: D44A0002
	v_cndmask_b32_e32 v1, 0, v15, vcc_lo                       // 0000007E709C: 02021E80
	s_waitcnt lgkmcnt(4)                                       // 0000007E70A0: BF89FC47
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007E70A4: BF870002
	v_dual_add_f32 v1, v1, v10 :: v_dual_lshlrev_b32 v20, 2, v0// 0000007E70A8: C9221501 01140082
	ds_bpermute_b32 v10, v18, v5                               // 0000007E70B0: DACC0000 0A000512
	s_and_b32 s2, s2, vcc_lo                                   // 0000007E70B8: 8B026A02
	ds_bpermute_b32 v19, v18, v1                               // 0000007E70BC: DACC0000 13000112
	ds_bpermute_b32 v18, v18, v2                               // 0000007E70C4: DACC0000 12000212
	s_waitcnt lgkmcnt(5)                                       // 0000007E70CC: BF89FC57
	v_dual_add_f32 v12, v3, v6 :: v_dual_add_f32 v13, v4, v7   // 0000007E70D0: C9080D03 0C0C0F04
	s_waitcnt lgkmcnt(3)                                       // 0000007E70D8: BF89FC37
	v_dual_add_f32 v7, v11, v16 :: v_dual_add_f32 v0, v14, v17 // 0000007E70DC: C908210B 0700230E
	ds_bpermute_b32 v14, v20, v12                              // 0000007E70E4: DACC0000 0E000C14
	ds_bpermute_b32 v16, v20, v13                              // 0000007E70EC: DACC0000 10000D14
	ds_bpermute_b32 v11, v20, v7                               // 0000007E70F4: DACC0000 0B000714
	s_waitcnt lgkmcnt(5)                                       // 0000007E70FC: BF89FC57
	v_add_f32_e32 v6, v5, v10                                  // 0000007E7100: 060C1505
	s_waitcnt lgkmcnt(3)                                       // 0000007E7104: BF89FC37
	v_dual_add_f32 v4, v1, v19 :: v_dual_add_f32 v1, v2, v18   // 0000007E7108: C9082701 04002502
	ds_bpermute_b32 v10, v20, v6                               // 0000007E7110: DACC0000 0A000614
	ds_bpermute_b32 v2, v20, v0                                // 0000007E7118: DACC0000 02000014
	ds_bpermute_b32 v5, v20, v4                                // 0000007E7120: DACC0000 05000414
	ds_bpermute_b32 v3, v20, v1                                // 0000007E7128: DACC0000 03000114
	s_and_saveexec_b32 s3, s2                                  // 0000007E7130: BE832002
	s_cbranch_execz 378                                        // 0000007E7134: BFA5017A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi16ELi1ELb0ELi1ELi0EEEvPKhPKtPvlllllS6_f+0x1320>
	s_waitcnt lgkmcnt(5)                                       // 0000007E7138: BF89FC57
	v_dual_add_f32 v13, v13, v16 :: v_dual_add_f32 v12, v12, v14// 0000007E713C: C908210D 0D0C1D0C
	.long 0x7f1e3880                                           // 0000007E7144: 7F1E3880
	s_load_b32 s1, s[0:1], 0x48                                // 0000007E7148: F4000040 F8000048
	s_waitcnt lgkmcnt(0)                                       // 0000007E7150: BF89FC07
	v_add_f32_e32 v6, v6, v10                                  // 0000007E7154: 060C1506
	.long 0x7e1c398d                                           // 0000007E7158: 7E1C398D
	.long 0x7e1e398c                                           // 0000007E715C: 7E1E398C
	.long 0x7f1c398f                                           // 0000007E7160: 7F1C398F
	.long 0x7f14398f                                           // 0000007E7164: 7F14398F
	v_add_f32_e32 v4, v4, v5                                   // 0000007E7168: 06080B04
	v_add_f32_e32 v0, v0, v2                                   // 0000007E716C: 06000500
	v_and_b32_e32 v16, 1, v15                                  // 0000007E7170: 36201E81
	v_and_b32_e32 v14, 1, v14                                  // 0000007E7174: 361C1C81
	.long 0x7f3a398f                                           // 0000007E7178: 7F3A398F
	.long 0x7f3e398f                                           // 0000007E717C: 7F3E398F
	s_lshl_b64 s[4:5], s[12:13], 2                             // 0000007E7180: 8484820C
	v_add3_u32 v12, v12, v16, 0x7fff                           // 0000007E7184: D655000C 03FE210C 00007FFF
	v_add3_u32 v13, v13, v14, 0x7fff                           // 0000007E7190: D655000D 03FE1D0D 00007FFF
	.long 0x7f40398f                                           // 0000007E719C: 7F40398F
	v_add_f32_e32 v7, v7, v11                                  // 0000007E71A0: 060E1707
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000007E71A4: BF870214
	v_dual_add_f32 v1, v1, v3 :: v_dual_and_b32 v12, 0xffff0000, v12// 0000007E71A8: C9240701 010C18FF FFFF0000
	v_and_b32_e32 v13, 0xffff0000, v13                         // 0000007E71B4: 361A1AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007E71BC: BF870193
	.long 0x7e143987                                           // 0000007E71C0: 7E143987
	v_bfe_u32 v2, v1, 16, 1                                    // 0000007E71C4: D6100002 02052101
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000007E71CC: BF870214
	v_mul_f32_e32 v12, s1, v12                                 // 0000007E71D0: 10181801
	v_mul_f32_e32 v16, s1, v13                                 // 0000007E71D4: 10201A01
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000007E71D8: BF870214
	v_and_b32_e32 v10, 1, v10                                  // 0000007E71DC: 36141481
	v_add3_u32 v1, v1, v2, 0x7fff                              // 0000007E71E0: D6550001 03FE0501 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000007E71EC: BF870214
	v_mul_f32_e32 v14, 0xbfb8aa3b, v12                         // 0000007E71F0: 101C18FF BFB8AA3B
	v_mul_f32_e32 v13, 0xbfb8aa3b, v16                         // 0000007E71F8: 101A20FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000007E7200: BF870214
	v_add3_u32 v7, v7, v10, 0x7fff                             // 0000007E7204: D6550007 03FE1507 00007FFF
	v_and_b32_e32 v1, 0xffff0000, v1                           // 0000007E7210: 360202FF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007E7218: BF870194
	v_exp_f32_e32 v14, v14                                     // 0000007E721C: 7E1C4B0E
	v_exp_f32_e32 v13, v13                                     // 0000007E7220: 7E1A4B0D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000007E7224: BF870292
	v_and_b32_e32 v7, 0xffff0000, v7                           // 0000007E7228: 360E0EFF FFFF0000
	v_add_f32_e32 v17, 1.0, v13                                // 0000007E7230: 06221AF2
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007E7234: BF870116
	v_add_f32_e32 v13, 1.0, v14                                // 0000007E7238: 061A1CF2
	v_div_scale_f32 v14, null, v17, v17, v16                   // 0000007E723C: D6FC7C0E 04422311
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007E7244: BF870112
	v_div_scale_f32 v18, null, v13, v13, v12                   // 0000007E7248: D6FC7C12 04321B0D
	v_rcp_f32_e32 v19, v14                                     // 0000007E7250: 7E26550E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 0000007E7254: BF870311
	v_rcp_f32_e32 v20, v18                                     // 0000007E7258: 7E285512
	v_fma_f32 v21, -v14, v19, 1.0                              // 0000007E725C: D6130015 23CA270E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007E7264: BF870115
	v_fma_f32 v22, -v18, v20, 1.0                              // 0000007E7268: D6130016 23CA2912
	v_fmac_f32_e32 v19, v21, v19                               // 0000007E7270: 56262715
	v_div_scale_f32 v21, s0, v12, v13, v12                     // 0000007E7274: D6FC0015 04321B0C
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000007E727C: BF870123
	v_fmac_f32_e32 v20, v22, v20                               // 0000007E7280: 56282916
	v_div_scale_f32 v23, vcc_lo, v16, v17, v16                 // 0000007E7284: D6FC6A17 04422310
	v_mul_f32_e32 v24, v21, v20                                // 0000007E728C: 10302915
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E7290: BF870091
	v_fma_f32 v26, -v18, v24, v21                              // 0000007E7294: D613001A 24563112
	v_fmac_f32_e32 v24, v26, v20                               // 0000007E729C: 5630291A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007E72A0: BF8700A1
	v_fma_f32 v18, -v18, v24, v21                              // 0000007E72A4: D6130012 24563112
	v_mul_f32_e32 v21, s1, v7                                  // 0000007E72AC: 102A0E01
	v_dual_mul_f32 v22, v23, v19 :: v_dual_mul_f32 v7, 0xbfb8aa3b, v21// 0000007E72B0: C8C62717 16062AFF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007E72BC: BF870111
	v_fma_f32 v25, -v14, v22, v23                              // 0000007E72C0: D6130019 245E2D0E
	v_exp_f32_e32 v7, v7                                       // 0000007E72C8: 7E0E4B07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E72CC: BF870091
	v_fmac_f32_e32 v22, v25, v19                               // 0000007E72D0: 562C2719
	v_fma_f32 v14, -v14, v22, v23                              // 0000007E72D4: D613000E 245E2D0E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(TRANS32_DEP_1)// 0000007E72DC: BF8702A1
	v_div_fmas_f32 v19, v14, v19, v22                          // 0000007E72E0: D6370013 045A270E
	s_mov_b32 vcc_lo, s0                                       // 0000007E72E8: BEEA0000
	v_add_f32_e32 v22, 1.0, v7                                 // 0000007E72EC: 062C0EF2
	v_div_fmas_f32 v14, v18, v20, v24                          // 0000007E72F0: D637000E 04622912
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007E72F8: BF870193
	v_div_fixup_f32 v16, v19, v17, v16                         // 0000007E72FC: D6270010 04422313
	v_div_scale_f32 v24, vcc_lo, v21, v22, v21                 // 0000007E7304: D6FC6A18 04562D15
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007E730C: BF870193
	v_div_fixup_f32 v18, v14, v13, v12                         // 0000007E7310: D6270012 04321B0E
	.long 0x7e3a3990                                           // 0000007E7318: 7E3A3990
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E731C: BF870092
	.long 0x7e1e3992                                           // 0000007E7320: 7E1E3992
	v_and_b32_e32 v20, 1, v15                                  // 0000007E7324: 36281E81
	.long 0x7e1e3986                                           // 0000007E7328: 7E1E3986
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E732C: BF870091
	v_and_b32_e32 v11, 1, v15                                  // 0000007E7330: 36161E81
	v_add3_u32 v6, v6, v11, 0x7fff                             // 0000007E7334: D6550006 03FE1706 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E7340: BF870091
	v_and_b32_e32 v6, 0xffff0000, v6                           // 0000007E7344: 360C0CFF FFFF0000
	v_mul_f32_e32 v6, s1, v6                                   // 0000007E734C: 100C0C01
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E7350: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v6                          // 0000007E7354: 10140CFF BFB8AA3B
	v_exp_f32_e32 v10, v10                                     // 0000007E735C: 7E144B0A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000007E7360: BF870125
	v_add_f32_e32 v7, 1.0, v10                                 // 0000007E7364: 060E14F2
	v_div_scale_f32 v10, null, v22, v22, v21                   // 0000007E7368: D6FC7C0A 04562D16
	v_div_scale_f32 v11, null, v7, v7, v6                      // 0000007E7370: D6FC7C0B 041A0F07
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E7378: BF870092
	v_rcp_f32_e32 v12, v10                                     // 0000007E737C: 7E18550A
	v_rcp_f32_e32 v13, v11                                     // 0000007E7380: 7E1A550B
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000007E7384: BF870296
	v_fma_f32 v14, -v10, v12, 1.0                              // 0000007E7388: D613000E 23CA190A
	v_fma_f32 v23, -v11, v13, 1.0                              // 0000007E7390: D6130017 23CA1B0B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007E7398: BF8701A2
	v_fmac_f32_e32 v12, v14, v12                               // 0000007E739C: 5618190E
	v_div_scale_f32 v14, s0, v6, v7, v6                        // 0000007E73A0: D6FC000E 041A0F06
	v_fmac_f32_e32 v13, v23, v13                               // 0000007E73A8: 561A1B17
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007E73AC: BF8701A3
	v_mul_f32_e32 v23, v24, v12                                // 0000007E73B0: 102E1918
	v_add3_u32 v18, v18, v20, 0x7fff                           // 0000007E73B4: D6550012 03FE2912 00007FFF
	v_mul_f32_e32 v25, v14, v13                                // 0000007E73C0: 10321B0E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007E73C4: BF870113
	v_fma_f32 v26, -v10, v23, v24                              // 0000007E73C8: D613001A 24622F0A
	v_fma_f32 v27, -v11, v25, v14                              // 0000007E73D0: D613001B 243A330B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007E73D8: BF870112
	v_fmac_f32_e32 v23, v26, v12                               // 0000007E73DC: 562E191A
	v_fmac_f32_e32 v25, v27, v13                               // 0000007E73E0: 56321B1B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007E73E4: BF8701A2
	v_fma_f32 v10, -v10, v23, v24                              // 0000007E73E8: D613000A 24622F0A
	v_mul_f32_e32 v27, s1, v1                                  // 0000007E73F0: 10360201
	v_fma_f32 v5, -v11, v25, v14                               // 0000007E73F4: D6130005 243A330B
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 0000007E73FC: BF870153
	v_div_fmas_f32 v23, v10, v12, v23                          // 0000007E7400: D6370017 045E190A
	s_mov_b32 vcc_lo, s0                                       // 0000007E7408: BEEA0000
	.long 0x7e143984                                           // 0000007E740C: 7E143984
	.long 0x7f14398f                                           // 0000007E7410: 7F14398F
	v_div_fmas_f32 v5, v5, v13, v25                            // 0000007E7414: D6370005 04661B05
	v_and_b32_e32 v3, 1, v10                                   // 0000007E741C: 36061481
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000007E7420: BF870232
	v_div_fixup_f32 v24, v5, v7, v6                            // 0000007E7424: D6270018 041A0F05
	v_div_fixup_f32 v17, v23, v22, v21                         // 0000007E742C: D6270011 04562D17
	v_and_b32_e32 v23, 1, v29                                  // 0000007E7434: 362E3A81
	v_add3_u32 v3, v4, v3, 0x7fff                              // 0000007E7438: D6550003 03FE0704 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000007E7444: BF870214
	.long 0x7e1e3998                                           // 0000007E7448: 7E1E3998
	.long 0x7e3e3991                                           // 0000007E744C: 7E3E3991
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000007E7450: BF870214
	v_add3_u32 v16, v16, v23, 0x7fff                           // 0000007E7454: D6550010 03FE2F10 00007FFF
	v_and_b32_e32 v2, 0xffff0000, v3                           // 0000007E7460: 360406FF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000007E7468: BF870134
	v_and_b32_e32 v25, 1, v15                                  // 0000007E746C: 36321E81
	.long 0x7e1e3980                                           // 0000007E7470: 7E1E3980
	v_and_b32_e32 v29, 1, v31                                  // 0000007E7474: 363A3E81
	v_and_b32_e32 v3, 1, v15                                   // 0000007E7478: 36061E81
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007E747C: BF870112
	v_add3_u32 v17, v17, v29, 0x7fff                           // 0000007E7480: D6550011 03FE3B11 00007FFF
	v_add3_u32 v0, v0, v3, 0x7fff                              // 0000007E748C: D6550000 03FE0700 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E7498: BF870091
	v_and_b32_e32 v0, 0xffff0000, v0                           // 0000007E749C: 360000FF FFFF0000
	v_mul_f32_e32 v28, s1, v0                                  // 0000007E74A4: 10380001
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E74A8: BF870091
	v_mul_f32_e32 v4, 0xbfb8aa3b, v28                          // 0000007E74AC: 100838FF BFB8AA3B
	v_exp_f32_e32 v5, v4                                       // 0000007E74B4: 7E0A4B04
	v_mul_f32_e32 v26, s1, v2                                  // 0000007E74B8: 10340401
	v_mul_f32_e32 v2, 0xbfb8aa3b, v27                          // 0000007E74BC: 100436FF BFB8AA3B
	s_lshl_b64 s[0:1], s[12:13], 1                             // 0000007E74C4: 8480810C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 0000007E74C8: BF870311
	v_exp_f32_e32 v2, v2                                       // 0000007E74CC: 7E044B02
	v_add_f32_e32 v37, 1.0, v5                                 // 0000007E74D0: 064A0AF2
	v_mul_f32_e32 v1, 0xbfb8aa3b, v26                          // 0000007E74D4: 100234FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007E74DC: BF870112
	v_div_scale_f32 v39, null, v37, v37, v28                   // 0000007E74E0: D6FC7C27 04724B25
	v_exp_f32_e32 v3, v1                                       // 0000007E74E8: 7E064B01
	.long 0xd73c0000                                           // 0000007E74EC: D73C0000
	v_cndmask_b32_e32 v1, 1, v8, vcc_lo                        // 0000007E74F0: 02021081
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007E74F4: BF870196
	v_add_f32_e32 v33, 1.0, v2                                 // 0000007E74F8: 064204F2
	v_rcp_f32_e32 v40, v39                                     // 0000007E74FC: 7E505527
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 0000007E7500: BF870311
	v_div_scale_f32 v35, null, v33, v33, v27                   // 0000007E7504: D6FC7C23 046E4321
	v_add_f32_e32 v30, 1.0, v3                                 // 0000007E750C: 063C06F2
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E7510: BF870094
	.long 0xd7006a03                                           // 0000007E7514: D7006A03
	v_cndmask_b32_e32 v1, s8, v0, vcc_lo                       // 0000007E7518: 02020008
	v_add_co_ci_u32_e64 v4, null, s9, v1, vcc_lo               // 0000007E751C: D5207C04 01AA0209
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007E7524: BF870193
	v_div_scale_f32 v34, null, v30, v30, v26                   // 0000007E7528: D6FC7C22 046A3D1E
	.long 0xd7006a05                                           // 0000007E7530: D7006A05
	v_cndmask_b32_e32 v0, v3, v0, vcc_lo                       // 0000007E7534: 02000103
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007E7538: BF870191
	v_add_co_ci_u32_e64 v6, null, s1, v4, vcc_lo               // 0000007E753C: D5207C06 01AA0801
	v_rcp_f32_e32 v36, v34                                     // 0000007E7544: 7E485522
	.long 0xd7006a07                                           // 0000007E7548: D7006A07
	v_cndmask_b32_e32 v0, v3, v4, vcc_lo                       // 0000007E754C: 02000903
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000007E7550: BF870121
	v_add_co_ci_u32_e64 v8, null, s5, v4, vcc_lo               // 0000007E7554: D5207C08 01AA0805
	v_rcp_f32_e32 v38, v35                                     // 0000007E755C: 7E4C5523
	.long 0xd7006a09                                           // 0000007E7560: D7006A09
	v_cndmask_b32_e32 v0, v7, v4, vcc_lo                       // 0000007E7564: 02000907
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 0000007E7568: BF870311
	v_add_co_ci_u32_e64 v10, null, s5, v8, vcc_lo              // 0000007E756C: D5207C0A 01AA1005
	v_fma_f32 v2, -v34, v36, 1.0                               // 0000007E7574: D6130002 23CA4922
	v_div_scale_f32 v41, vcc_lo, v26, v30, v26                 // 0000007E757C: D6FC6A29 046A3D1A
	v_mad_u64_u32 v[0:1], null, s12, 6, v[3:4]                 // 0000007E7584: D6FE7C00 040D0C0C
	v_div_scale_f32 v44, s1, v28, v37, v28                     // 0000007E758C: D6FC012C 04724B1C
	v_div_scale_f32 v42, s0, v27, v33, v27                     // 0000007E7594: D6FC002A 046E431B
	v_fmac_f32_e32 v36, v2, v36                                // 0000007E759C: 56484902
	s_delay_alu instid0(TRANS32_DEP_1)                         // 0000007E75A0: BF870005
	v_fma_f32 v11, -v35, v38, 1.0                              // 0000007E75A4: D613000B 23CA4D23
	s_clause 0x1                                               // 0000007E75AC: BF850001
	global_store_d16_hi_b16 v[3:4], v16, off                   // 0000007E75B0: DC960000 007C1003
	global_store_d16_hi_b16 v[5:6], v18, off                   // 0000007E75B8: DC960000 007C1205
	v_add3_u32 v5, v24, v25, 0x7fff                            // 0000007E75C0: D6550005 03FE3318 00007FFF
	v_mul_f32_e32 v43, v41, v36                                // 0000007E75CC: 10564929
	v_mad_u64_u32 v[1:2], null, s13, 6, v[1:2]                 // 0000007E75D0: D6FE7C01 04050C0D
	v_fma_f32 v2, -v39, v40, 1.0                               // 0000007E75D8: D6130002 23CA5127
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007E75E0: BF8701A3
	v_fma_f32 v45, -v34, v43, v41                              // 0000007E75E4: D613002D 24A65722
	v_fmac_f32_e32 v38, v11, v38                               // 0000007E75EC: 564C4D0B
	v_fmac_f32_e32 v40, v2, v40                                // 0000007E75F0: 56505102
	.long 0xd700020b                                           // 0000007E75F4: D700020B
	v_cndmask_b32_e32 v0, v9, v4, vcc_lo                       // 0000007E75F8: 02000909
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000007E75FC: BF870224
	v_fmac_f32_e32 v43, v45, v36                               // 0000007E7600: 5656492D
	v_add_co_ci_u32_e64 v12, null, s5, v10, s2                 // 0000007E7604: D5207C0C 000A1405
	v_mul_f32_e32 v46, v44, v40                                // 0000007E760C: 105C512C
	.long 0xd700020d                                           // 0000007E7610: D700020D
	v_cndmask_b32_e32 v0, v0, v4, vcc_lo                       // 0000007E7614: 02000900
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000007E7618: BF870224
	v_fma_f32 v19, -v34, v43, v41                              // 0000007E761C: D6130013 24A65722
	v_add_co_ci_u32_e64 v14, null, s5, v1, s2                  // 0000007E7624: D5207C0E 000A0205
	v_fma_f32 v47, -v39, v46, v44                              // 0000007E762C: D613002F 24B25D27
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000007E7634: BF870123
	v_div_fmas_f32 v19, v19, v36, v43                          // 0000007E7638: D6370013 04AE4913
	s_mov_b32 vcc_lo, s1                                       // 0000007E7640: BEEA0001
	v_fmac_f32_e32 v46, v47, v40                               // 0000007E7644: 565C512F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007E7648: BF870112
	v_div_fixup_f32 v19, v19, v30, v26                         // 0000007E764C: D6270013 046A3D13
	v_fma_f32 v21, -v39, v46, v44                              // 0000007E7654: D6130015 24B25D27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007E765C: BF8701A2
	.long 0x7e403993                                           // 0000007E7660: 7E403993
	v_mul_f32_e32 v2, v42, v38                                 // 0000007E7664: 10044D2A
	v_div_fmas_f32 v21, v21, v40, v46                          // 0000007E7668: D6370015 04BA5115
	s_mov_b32 vcc_lo, s0                                       // 0000007E7670: BEEA0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007E7674: BF870193
	v_and_b32_e32 v3, 1, v32                                   // 0000007E7678: 36064081
	v_fma_f32 v48, -v35, v2, v42                               // 0000007E767C: D6130030 24AA0523
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007E7684: BF870193
	v_div_fixup_f32 v21, v21, v37, v28                         // 0000007E7688: D6270015 04724B15
	v_add3_u32 v3, v19, v3, 0x7fff                             // 0000007E7690: D6550003 03FE0713 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007E769C: BF870193
	v_fmac_f32_e32 v2, v48, v38                                // 0000007E76A0: 56044D30
	.long 0x7e1e3995                                           // 0000007E76A4: 7E1E3995
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007E76A8: BF870112
	v_fma_f32 v22, -v35, v2, v42                               // 0000007E76AC: D6130016 24AA0523
	v_and_b32_e32 v4, 1, v15                                   // 0000007E76B4: 36081E81
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007E76B8: BF870112
	v_div_fmas_f32 v2, v22, v38, v2                            // 0000007E76BC: D6370002 040A4D16
	v_add3_u32 v4, v21, v4, 0x7fff                             // 0000007E76C4: D6550004 03FE0915 00007FFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E76D0: BF870092
	v_div_fixup_f32 v2, v2, v33, v27                           // 0000007E76D4: D6270002 046E4302
	v_bfe_u32 v15, v2, 16, 1                                   // 0000007E76DC: D610000F 02052102
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007E76E4: BF870001
	v_add3_u32 v2, v2, v15, 0x7fff                             // 0000007E76E8: D6550002 03FE1F02 00007FFF
	s_clause 0x4                                               // 0000007E76F4: BF850004
	global_store_d16_hi_b16 v[7:8], v17, off                   // 0000007E76F8: DC960000 007C1107
	global_store_d16_hi_b16 v[0:1], v5, off                    // 0000007E7700: DC960000 007C0500
	global_store_d16_hi_b16 v[9:10], v3, off                   // 0000007E7708: DC960000 007C0309
	global_store_d16_hi_b16 v[13:14], v4, off                  // 0000007E7710: DC960000 007C040D
	global_store_d16_hi_b16 v[11:12], v2, off                  // 0000007E7718: DC960000 007C020B
	s_endpgm                                                   // 0000007E7720: BFB00000
		...

