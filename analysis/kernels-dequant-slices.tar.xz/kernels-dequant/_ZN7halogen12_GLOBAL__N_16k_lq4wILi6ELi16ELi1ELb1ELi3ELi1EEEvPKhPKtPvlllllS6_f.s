0000000000853b00 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi16ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi16ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[8:23], s[0:1], null                          // 000000853B00: F4100200 F8000000
	v_and_b32_e32 v30, 15, v0                                  // 000000853B08: 363C008F
	v_lshrrev_b32_e32 v1, 4, v0                                // 000000853B0C: 32020084
	s_ashr_i32 s3, s2, 31                                      // 000000853B10: 86039F02
	v_lshlrev_b32_e32 v7, 2, v0                                // 000000853B14: 300E0082
	s_lshl_b64 s[2:3], s[2:3], 4                               // 000000853B18: 84828402
	v_lshlrev_b32_e32 v2, 2, v30                               // 000000853B1C: 30043C82
	v_dual_mov_b32 v24, s3 :: v_dual_lshlrev_b32 v3, 2, v1     // 000000853B20: CA220003 18020282
	v_or_b32_e32 v23, s2, v1                                   // 000000853B28: 382E0202
	.long 0x7f0c3880                                           // 000000853B2C: 7F0C3880
	s_waitcnt lgkmcnt(0)                                       // 000000853B30: BF89FC07
	s_clause 0x1                                               // 000000853B34: BF850001
	global_load_b32 v4, v2, s[8:9]                             // 000000853B38: DC520000 04080002
	global_load_b32 v3, v3, s[8:9]                             // 000000853B40: DC520000 03080003
	.long 0xd4540002                                           // 000000853B48: D4540002
	v_cndmask_b32_e32 v1, s16, v23, vcc_lo                     // 000000853B4C: 02022E10
	s_add_u32 s24, s8, s20                                     // 000000853B50: 80181408
	s_addc_u32 s25, s9, s21                                    // 000000853B54: 82191509
	s_ashr_i32 s4, s15, 31                                     // 000000853B58: 86049F0F
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 000000853B5C: BF870159
	s_lshr_b32 s4, s4, 27                                      // 000000853B60: 85049B04
	v_cndmask_b32_e64 v2, 0, v23, s2                           // 000000853B64: D5010002 000A2E80
	v_cndmask_b32_e64 v5, 0, s3, s2                            // 000000853B6C: D5010005 00080680
	s_add_u32 s4, s14, s4                                      // 000000853B74: 8004040E
	s_addc_u32 s5, s15, 0                                      // 000000853B78: 8205800F
	.long 0xd72c0008                                           // 000000853B7C: D72C0008
	v_cndmask_b32_e32 v1, s23, v2, vcc_lo                      // 000000853B80: 02020417
	v_mad_u64_u32 v[0:1], null, s22, v2, 0                     // 000000853B84: D6FE7C00 02020416
	s_lshr_b64 s[6:7], s[4:5], 5                               // 000000853B8C: 85868504
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(SALU_CYCLE_1)// 000000853B90: BF8704D9
	s_cmpk_lt_i32 s6, 0x81                                     // 000000853B94: B3860081
	.long 0xd4440004                                           // 000000853B98: D4440004
	v_cndmask_b32_e32 v1, s6, v30, vcc_lo                      // 000000853B9C: 02023C06
	s_cselect_b32 s3, -1, 0                                    // 000000853BA0: 980380C1
	s_cmpk_gt_i32 s6, 0x80                                     // 000000853BA4: B2860080
	s_cselect_b32 s7, -1, 0                                    // 000000853BA8: 980780C1
	s_and_b32 vcc_lo, exec_lo, s7                              // 000000853BAC: 8B6A077E
	s_waitcnt vmcnt(1)                                         // 000000853BB0: BF8907F7
	v_bfe_u32 v9, v4, 16, 1                                    // 000000853BB4: D6100009 02052104
	s_waitcnt vmcnt(0)                                         // 000000853BBC: BF8903F7
	v_bfe_u32 v10, v3, 16, 1                                   // 000000853BC0: D610000A 02052103
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000853BC8: BF8701A2
	v_add3_u32 v4, v4, v9, 0x7fff                              // 000000853BCC: D6550004 03FE1304 00007FFF
	.long 0xd72c0009                                           // 000000853BD8: D72C0009
	v_cndmask_b32_e32 v1, s22, v5, vcc_lo                      // 000000853BDC: 02020A16
	v_add3_u32 v3, v3, v10, 0x7fff                             // 000000853BE0: D6550003 03FE1503 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000853BEC: BF870193
	.long 0x7e0c3984                                           // 000000853BF0: 7E0C3984
	v_add3_u32 v1, v1, v9, v8                                  // 000000853BF4: D6550001 04221301
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000853BFC: BF8700A2
	v_and_or_b32 v6, 0xffff0000, v3, v6                        // 000000853C00: D6570006 041A06FF FFFF0000
	.long 0xd7000503                                           // 000000853C0C: D7000503
	v_cndmask_b32_e32 v1, s24, v0, vcc_lo                      // 000000853C10: 02020018
	v_add_co_ci_u32_e64 v4, null, s25, v1, s5                  // 000000853C14: D5207C04 00160219
	ds_store_b32 v7, v6                                        // 000000853C1C: D8340000 00000607
	s_waitcnt lgkmcnt(0)                                       // 000000853C24: BF89FC07
	s_barrier                                                  // 000000853C28: BFBD0000
	buffer_gl0_inv                                             // 000000853C2C: E0AC0000 00000000
	s_cbranch_vccnz 144                                        // 000000853C34: BFA40090 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi16ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x378>
	v_dual_mov_b32 v8, 0 :: v_dual_mov_b32 v7, 0               // 000000853C38: CA100080 08060080
	s_and_saveexec_b32 s5, s4                                  // 000000853C40: BE852004
	s_cbranch_execz 10                                         // 000000853C44: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi16ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x170>
	v_lshlrev_b32_e32 v6, 1, v30                               // 000000853C48: 300C3C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000853C4C: BF870091
	.long 0xd7006a06                                           // 000000853C50: D7006A06
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 000000853C54: 02020D03
	v_add_co_ci_u32_e64 v7, null, 0, v4, vcc_lo                // 000000853C58: D5207C07 01AA0880
	global_load_d16_b16 v6, v[6:7], off                        // 000000853C60: DC820000 067C0006
	s_waitcnt vmcnt(0)                                         // 000000853C68: BF8903F7
	v_cvt_f32_f16_e32 v7, v6                                   // 000000853C6C: 7E0E1706
	s_or_b32 exec_lo, exec_lo, s5                              // 000000853C70: 8C7E057E
	v_or_b32_e32 v6, 16, v30                                   // 000000853C74: 380C3C90
	s_mov_b32 s4, exec_lo                                      // 000000853C78: BE84007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000853C7C: BF870001
	.long 0xd4c4007e                                           // 000000853C80: D4C4007E
	v_cndmask_b32_e32 v1, s6, v6, vcc_lo                       // 000000853C84: 02020C06
	s_cbranch_execz 10                                         // 000000853C88: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi16ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x1b4>
	v_lshlrev_b32_e32 v6, 1, v6                                // 000000853C8C: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000853C90: BF870091
	.long 0xd7006a08                                           // 000000853C94: D7006A08
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 000000853C98: 02020D03
	v_add_co_ci_u32_e64 v9, null, 0, v4, vcc_lo                // 000000853C9C: D5207C09 01AA0880
	global_load_d16_b16 v6, v[8:9], off                        // 000000853CA4: DC820000 067C0008
	s_waitcnt vmcnt(0)                                         // 000000853CAC: BF8903F7
	v_cvt_f32_f16_e32 v8, v6                                   // 000000853CB0: 7E101706
	s_or_b32 exec_lo, exec_lo, s4                              // 000000853CB4: 8C7E047E
	v_or_b32_e32 v6, 32, v30                                   // 000000853CB8: 380C3CA0
	v_dual_mov_b32 v10, 0 :: v_dual_mov_b32 v9, 0              // 000000853CBC: CA100080 0A080080
	s_mov_b32 s4, exec_lo                                      // 000000853CC4: BE84007E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000853CC8: BF870002
	.long 0xd4c4007e                                           // 000000853CCC: D4C4007E
	v_cndmask_b32_e32 v1, s6, v6, vcc_lo                       // 000000853CD0: 02020C06
	s_cbranch_execz 10                                         // 000000853CD4: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi16ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x200>
	v_lshlrev_b32_e32 v6, 1, v6                                // 000000853CD8: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000853CDC: BF870091
	.long 0xd7006a0b                                           // 000000853CE0: D7006A0B
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 000000853CE4: 02020D03
	v_add_co_ci_u32_e64 v12, null, 0, v4, vcc_lo               // 000000853CE8: D5207C0C 01AA0880
	global_load_d16_b16 v6, v[11:12], off                      // 000000853CF0: DC820000 067C000B
	s_waitcnt vmcnt(0)                                         // 000000853CF8: BF8903F7
	v_cvt_f32_f16_e32 v9, v6                                   // 000000853CFC: 7E121706
	s_or_b32 exec_lo, exec_lo, s4                              // 000000853D00: 8C7E047E
	v_or_b32_e32 v6, 48, v30                                   // 000000853D04: 380C3CB0
	s_mov_b32 s4, exec_lo                                      // 000000853D08: BE84007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000853D0C: BF870001
	.long 0xd4c4007e                                           // 000000853D10: D4C4007E
	v_cndmask_b32_e32 v1, s6, v6, vcc_lo                       // 000000853D14: 02020C06
	s_cbranch_execz 10                                         // 000000853D18: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi16ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x244>
	v_lshlrev_b32_e32 v6, 1, v6                                // 000000853D1C: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000853D20: BF870091
	.long 0xd7006a0a                                           // 000000853D24: D7006A0A
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 000000853D28: 02020D03
	v_add_co_ci_u32_e64 v11, null, 0, v4, vcc_lo               // 000000853D2C: D5207C0B 01AA0880
	global_load_d16_b16 v6, v[10:11], off                      // 000000853D34: DC820000 067C000A
	s_waitcnt vmcnt(0)                                         // 000000853D3C: BF8903F7
	v_cvt_f32_f16_e32 v10, v6                                  // 000000853D40: 7E141706
	s_or_b32 exec_lo, exec_lo, s4                              // 000000853D44: 8C7E047E
	v_or_b32_e32 v6, 64, v30                                   // 000000853D48: 380C3CC0
	v_dual_mov_b32 v12, 0 :: v_dual_mov_b32 v11, 0             // 000000853D4C: CA100080 0C0A0080
	s_mov_b32 s4, exec_lo                                      // 000000853D54: BE84007E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000853D58: BF870002
	.long 0xd4c4007e                                           // 000000853D5C: D4C4007E
	v_cndmask_b32_e32 v1, s6, v6, vcc_lo                       // 000000853D60: 02020C06
	s_cbranch_execz 10                                         // 000000853D64: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi16ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x290>
	v_lshlrev_b32_e32 v6, 1, v6                                // 000000853D68: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000853D6C: BF870091
	.long 0xd7006a0d                                           // 000000853D70: D7006A0D
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 000000853D74: 02020D03
	v_add_co_ci_u32_e64 v14, null, 0, v4, vcc_lo               // 000000853D78: D5207C0E 01AA0880
	global_load_d16_b16 v6, v[13:14], off                      // 000000853D80: DC820000 067C000D
	s_waitcnt vmcnt(0)                                         // 000000853D88: BF8903F7
	v_cvt_f32_f16_e32 v11, v6                                  // 000000853D8C: 7E161706
	s_or_b32 exec_lo, exec_lo, s4                              // 000000853D90: 8C7E047E
	v_or_b32_e32 v6, 0x50, v30                                 // 000000853D94: 380C3CFF 00000050
	s_mov_b32 s4, exec_lo                                      // 000000853D9C: BE84007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000853DA0: BF870001
	.long 0xd4c4007e                                           // 000000853DA4: D4C4007E
	v_cndmask_b32_e32 v1, s6, v6, vcc_lo                       // 000000853DA8: 02020C06
	s_cbranch_execz 10                                         // 000000853DAC: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi16ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x2d8>
	v_lshlrev_b32_e32 v6, 1, v6                                // 000000853DB0: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000853DB4: BF870091
	.long 0xd7006a0c                                           // 000000853DB8: D7006A0C
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 000000853DBC: 02020D03
	v_add_co_ci_u32_e64 v13, null, 0, v4, vcc_lo               // 000000853DC0: D5207C0D 01AA0880
	global_load_d16_b16 v6, v[12:13], off                      // 000000853DC8: DC820000 067C000C
	s_waitcnt vmcnt(0)                                         // 000000853DD0: BF8903F7
	v_cvt_f32_f16_e32 v12, v6                                  // 000000853DD4: 7E181706
	s_or_b32 exec_lo, exec_lo, s4                              // 000000853DD8: 8C7E047E
	v_or_b32_e32 v6, 0x60, v30                                 // 000000853DDC: 380C3CFF 00000060
	v_dual_mov_b32 v14, 0 :: v_dual_mov_b32 v13, 0             // 000000853DE4: CA100080 0E0C0080
	s_mov_b32 s4, exec_lo                                      // 000000853DEC: BE84007E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000853DF0: BF870002
	.long 0xd4c4007e                                           // 000000853DF4: D4C4007E
	v_cndmask_b32_e32 v1, s6, v6, vcc_lo                       // 000000853DF8: 02020C06
	s_cbranch_execz 10                                         // 000000853DFC: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi16ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x328>
	v_lshlrev_b32_e32 v6, 1, v6                                // 000000853E00: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000853E04: BF870091
	.long 0xd7006a0f                                           // 000000853E08: D7006A0F
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 000000853E0C: 02020D03
	v_add_co_ci_u32_e64 v16, null, 0, v4, vcc_lo               // 000000853E10: D5207C10 01AA0880
	global_load_d16_b16 v6, v[15:16], off                      // 000000853E18: DC820000 067C000F
	s_waitcnt vmcnt(0)                                         // 000000853E20: BF8903F7
	v_cvt_f32_f16_e32 v13, v6                                  // 000000853E24: 7E1A1706
	s_or_b32 exec_lo, exec_lo, s4                              // 000000853E28: 8C7E047E
	v_or_b32_e32 v6, 0x70, v30                                 // 000000853E2C: 380C3CFF 00000070
	s_mov_b32 s4, exec_lo                                      // 000000853E34: BE84007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000853E38: BF870001
	.long 0xd4c4007e                                           // 000000853E3C: D4C4007E
	v_cndmask_b32_e32 v1, s6, v6, vcc_lo                       // 000000853E40: 02020C06
	s_cbranch_execz 10                                         // 000000853E44: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi16ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x370>
	v_lshlrev_b32_e32 v6, 1, v6                                // 000000853E48: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000853E4C: BF870091
	.long 0xd7006a0e                                           // 000000853E50: D7006A0E
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 000000853E54: 02020D03
	v_add_co_ci_u32_e64 v15, null, 0, v4, vcc_lo               // 000000853E58: D5207C0F 01AA0880
	global_load_d16_b16 v6, v[14:15], off                      // 000000853E60: DC820000 067C000E
	s_waitcnt vmcnt(0)                                         // 000000853E68: BF8903F7
	v_cvt_f32_f16_e32 v14, v6                                  // 000000853E6C: 7E1C1706
	s_or_b32 exec_lo, exec_lo, s4                              // 000000853E70: 8C7E047E
	s_branch 9                                                 // 000000853E74: BFA00009 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi16ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x39c>
	v_mov_b32_e32 v7, 0                                        // 000000853E78: 7E0E0280
	s_delay_alu instid0(VALU_DEP_1)                            // 000000853E7C: BF870001
	v_mov_b32_e32 v8, v7                                       // 000000853E80: 7E100307
	v_mov_b32_e32 v9, v7                                       // 000000853E84: 7E120307
	v_mov_b32_e32 v10, v7                                      // 000000853E88: 7E140307
	v_mov_b32_e32 v11, v7                                      // 000000853E8C: 7E160307
	v_mov_b32_e32 v12, v7                                      // 000000853E90: 7E180307
	v_mov_b32_e32 v13, v7                                      // 000000853E94: 7E1A0307
	v_mov_b32_e32 v14, v7                                      // 000000853E98: 7E1C0307
	s_add_u32 s4, s8, s18                                      // 000000853E9C: 80041208
	s_addc_u32 s5, s9, s19                                     // 000000853EA0: 82051309
	s_lshr_b32 s18, s15, 31                                    // 000000853EA4: 85129F0F
	v_dual_mov_b32 v19, 0 :: v_dual_mov_b32 v32, 0             // 000000853EA8: CA100080 13200080
	s_add_u32 s18, s14, s18                                    // 000000853EB0: 8012120E
	s_addc_u32 s19, s15, 0                                     // 000000853EB4: 8213800F
	v_cndmask_b32_e64 v31, 0, 1, s7                            // 000000853EB8: D501001F 001D0280
	s_ashr_i64 s[18:19], s[18:19], 1                           // 000000853EC0: 86928112
	v_dual_mov_b32 v42, 0 :: v_dual_mov_b32 v21, 0             // 000000853EC4: CA100080 2A140080
	v_mad_u64_u32 v[25:26], null, v2, s18, s[4:5]              // 000000853ECC: D6FE7C19 00102502
	.long 0xd72c0002                                           // 000000853ED4: D72C0002
	v_cndmask_b32_e32 v0, v2, v19, vcc_lo                      // 000000853ED8: 02002702
	.long 0xd72c0005                                           // 000000853EDC: D72C0005
	v_cndmask_b32_e32 v0, v5, v18, vcc_lo                      // 000000853EE0: 02002505
	.long 0xd4440004                                           // 000000853EE4: D4440004
	v_cndmask_b32_e32 v1, s6, v30, vcc_lo                      // 000000853EE8: 02023C06
	v_mov_b32_e32 v20, 0                                       // 000000853EEC: 7E280280
	v_mov_b32_e32 v22, 0                                       // 000000853EF0: 7E2C0280
	s_delay_alu instid0(VALU_DEP_4)                            // 000000853EF4: BF870004
	v_add3_u32 v33, v5, v26, v2                                // 000000853EF8: D6550021 040A3505
	s_and_saveexec_b32 s5, s4                                  // 000000853F00: BE852004
	s_cbranch_execz 21                                         // 000000853F04: BFA50015 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi16ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x45c>
	v_lshlrev_b32_e32 v2, 4, v30                               // 000000853F08: 30043C84
	v_mov_b32_e32 v42, 0                                       // 000000853F0C: 7E540280
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000853F10: BF870092
	.long 0xd7006a05                                           // 000000853F14: D7006A05
	v_cndmask_b32_e32 v1, v25, v2, vcc_lo                      // 000000853F18: 02020519
	v_add_co_ci_u32_e64 v6, null, 0, v33, vcc_lo               // 000000853F1C: D5207C06 01AA4280
	s_and_not1_b32 vcc_lo, exec_lo, s7                         // 000000853F24: 916A077E
	global_load_b128 v[19:22], v[5:6], off                     // 000000853F28: DC5E0000 137C0005
	s_cbranch_vccnz 10                                         // 000000853F30: BFA4000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi16ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x45c>
	v_lshlrev_b32_e32 v2, 1, v30                               // 000000853F34: 30043C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000853F38: BF870091
	.long 0xd7006a02                                           // 000000853F3C: D7006A02
	v_cndmask_b32_e32 v1, v3, v2, vcc_lo                       // 000000853F40: 02020503
	v_add_co_ci_u32_e64 v3, null, 0, v4, vcc_lo                // 000000853F44: D5207C03 01AA0880
	global_load_d16_b16 v2, v[2:3], off                        // 000000853F4C: DC820000 027C0002
	s_waitcnt vmcnt(0)                                         // 000000853F54: BF8903F7
	v_cvt_f32_f16_e32 v42, v2                                  // 000000853F58: 7E541702
	s_or_b32 exec_lo, exec_lo, s5                              // 000000853F5C: 8C7E057E
	v_dual_mov_b32 v34, 0 :: v_dual_mov_b32 v35, 0             // 000000853F60: CA100080 22220080
	v_dual_mov_b32 v36, 0 :: v_dual_mov_b32 v37, 0             // 000000853F68: CA100080 24240080
	v_mov_b32_e32 v38, 0                                       // 000000853F70: 7E4C0280
	s_and_saveexec_b32 s5, s4                                  // 000000853F74: BE852004
	s_cbranch_execz 565                                        // 000000853F78: BFA50235 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi16ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0xd50>
	v_dual_mov_b32 v27, 0 :: v_dual_lshlrev_b32 v2, 1, v30     // 000000853F7C: CA220080 1B023C81
	.long 0xd7006a00                                           // 000000853F84: D7006A00
	v_cndmask_b32_e32 v1, s20, v0, vcc_lo                      // 000000853F88: 02020014
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000853F8C: BF870191
	v_add_co_ci_u32_e64 v1, null, s21, v1, vcc_lo              // 000000853F90: D5207C01 01AA0215
	v_dual_mov_b32 v37, v27 :: v_dual_lshlrev_b32 v26, 5, v30  // 000000853F98: CA22011B 251A3C85
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000853FA0: BF870093
	.long 0xd7006a00                                           // 000000853FA4: D7006A00
	v_cndmask_b32_e32 v1, v0, v2, vcc_lo                       // 000000853FA8: 02020500
	v_add_co_ci_u32_e64 v1, null, 0, v1, vcc_lo                // 000000853FAC: D5207C01 01AA0280
	v_lshl_or_b32 v39, v30, 4, 0x100                           // 000000853FB4: D6560027 03FD091E 00000100
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000853FC0: BF870093
	.long 0xd7006a00                                           // 000000853FC4: D7006A00
	v_cndmask_b32_e32 v1, s8, v0, vcc_lo                       // 000000853FC8: 02020008
	v_add_co_ci_u32_e64 v1, null, s9, v1, vcc_lo               // 000000853FCC: D5207C01 01AA0209
	v_dual_mov_b32 v40, v30 :: v_dual_mov_b32 v35, v27         // 000000853FD4: CA10011E 2822011B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000853FDC: BF870093
	.long 0xd7006a1c                                           // 000000853FE0: D7006A1C
	v_cndmask_b32_e32 v0, v0, v160, vcc_lo                     // 000000853FE4: 02014100
	v_add_co_ci_u32_e64 v29, null, 0, v1, vcc_lo               // 000000853FE8: D5207C1D 01AA0280
	v_dual_mov_b32 v38, v27 :: v_dual_mov_b32 v41, v42         // 000000853FF0: CA10011B 2628012A
	v_mov_b32_e32 v36, v27                                     // 000000853FF8: 7E48031B
	v_mov_b32_e32 v34, v27                                     // 000000853FFC: 7E44031B
	v_mov_b32_e32 v32, v27                                     // 000000854000: 7E40031B
	s_mul_i32 s4, s15, 6                                       // 000000854004: 9604860F
	s_mul_hi_u32 s7, s14, 6                                    // 000000854008: 9687860E
	s_lshl_b64 s[18:19], s[14:15], 2                           // 00000085400C: 8492820E
	s_add_i32 s7, s7, s4                                       // 000000854010: 81070407
	s_mul_i32 s21, s14, 6                                      // 000000854014: 9615860E
	s_mov_b32 s20, 0                                           // 000000854018: BE940080
	s_lshl_b64 s[8:9], s[14:15], 1                             // 00000085401C: 8488810E
	s_branch 494                                               // 000000854020: BFA001EE <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi16ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0xcdc>
	s_or_b32 exec_lo, exec_lo, s14                             // 000000854024: 8C7E0E7E
	v_cndmask_b32_e64 v52, v42, v7, s3                         // 000000854028: D5010034 000E0F2A
	v_cndmask_b32_e64 v1, v8, v9, s3                           // 000000854030: D5010001 000E1308
	v_cndmask_b32_e64 v0, v7, v8, s3                           // 000000854038: D5010000 000E1107
	v_dual_mov_b32 v7, v14 :: v_dual_and_b32 v8, 0xff, v19     // 000000854040: CA24010E 070826FF 000000FF
	v_cndmask_b32_e64 v6, v13, v14, s3                         // 00000085404C: D5010006 000E1D0D
	v_cndmask_b32_e64 v5, v12, v13, s3                         // 000000854054: D5010005 000E1B0C
	v_cndmask_b32_e64 v4, v11, v12, s3                         // 00000085405C: D5010004 000E190B
	v_cndmask_b32_e64 v3, v10, v11, s3                         // 000000854064: D5010003 000E170A
	v_lshlrev_b32_e32 v8, 2, v8                                // 00000085406C: 30101082
	v_cndmask_b32_e64 v2, v9, v10, s3                          // 000000854070: D5010002 000E1509
	s_and_b32 s4, exec_lo, s4                                  // 000000854078: 8B04047E
	v_add_nc_u32_e32 v39, 0x100, v39                           // 00000085407C: 4A4E4EFF 00000100
	s_or_b32 s20, s4, s20                                      // 000000854084: 8C141404
	ds_load_b32 v14, v8                                        // 000000854088: D8D80000 0E000008
	v_lshrrev_b32_e32 v8, 6, v19                               // 000000854090: 32102686
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000854094: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 000000854098: 361010FF 000003FC
	ds_load_b32 v53, v8                                        // 0000008540A0: D8D80000 35000008
	v_lshrrev_b32_e32 v8, 14, v19                              // 0000008540A8: 3210268E
	v_and_b32_e32 v8, 0x3fc, v8                                // 0000008540AC: 361010FF 000003FC
	ds_load_b32 v54, v8                                        // 0000008540B4: D8D80000 36000008
	v_lshrrev_b32_e32 v8, 22, v19                              // 0000008540BC: 32102696
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008540C0: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 0000008540C4: 361010FF 000003FC
	ds_load_b32 v55, v8                                        // 0000008540CC: D8D80000 37000008
	v_and_b32_e32 v8, 0xff, v20                                // 0000008540D4: 361028FF 000000FF
	v_lshlrev_b32_e32 v8, 2, v8                                // 0000008540DC: 30101082
	ds_load_b32 v56, v8                                        // 0000008540E0: D8D80000 38000008
	v_lshrrev_b32_e32 v8, 6, v20                               // 0000008540E8: 32102886
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008540EC: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 0000008540F0: 361010FF 000003FC
	ds_load_b32 v57, v8                                        // 0000008540F8: D8D80000 39000008
	v_lshrrev_b32_e32 v8, 14, v20                              // 000000854100: 3210288E
	v_and_b32_e32 v8, 0x3fc, v8                                // 000000854104: 361010FF 000003FC
	ds_load_b32 v58, v8                                        // 00000085410C: D8D80000 3A000008
	v_lshrrev_b32_e32 v8, 22, v20                              // 000000854114: 32102896
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000854118: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 00000085411C: 361010FF 000003FC
	ds_load_b32 v59, v8                                        // 000000854124: D8D80000 3B000008
	v_and_b32_e32 v8, 0xff, v21                                // 00000085412C: 36102AFF 000000FF
	v_lshlrev_b32_e32 v8, 2, v8                                // 000000854134: 30101082
	ds_load_b32 v60, v8                                        // 000000854138: D8D80000 3C000008
	v_lshrrev_b32_e32 v8, 6, v21                               // 000000854140: 32102A86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000854144: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 000000854148: 361010FF 000003FC
	ds_load_b32 v61, v8                                        // 000000854150: D8D80000 3D000008
	v_lshrrev_b32_e32 v8, 14, v21                              // 000000854158: 32102A8E
	v_and_b32_e32 v8, 0x3fc, v8                                // 00000085415C: 361010FF 000003FC
	ds_load_b32 v62, v8                                        // 000000854164: D8D80000 3E000008
	v_lshrrev_b32_e32 v8, 22, v21                              // 00000085416C: 32102A96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000854170: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 000000854174: 361010FF 000003FC
	ds_load_b32 v63, v8                                        // 00000085417C: D8D80000 3F000008
	v_and_b32_e32 v8, 0xff, v22                                // 000000854184: 36102CFF 000000FF
	v_lshlrev_b32_e32 v8, 2, v8                                // 00000085418C: 30101082
	ds_load_b32 v64, v8                                        // 000000854190: D8D80000 40000008
	v_lshrrev_b32_e32 v8, 6, v22                               // 000000854198: 32102C86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000085419C: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 0000008541A0: 361010FF 000003FC
	ds_load_b32 v65, v8                                        // 0000008541A8: D8D80000 41000008
	v_lshrrev_b32_e32 v8, 14, v22                              // 0000008541B0: 32102C8E
	v_and_b32_e32 v8, 0x3fc, v8                                // 0000008541B4: 361010FF 000003FC
	ds_load_b32 v66, v8                                        // 0000008541BC: D8D80000 42000008
	v_lshrrev_b32_e32 v8, 22, v22                              // 0000008541C4: 32102C96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000008541C8: BF870141
	v_and_b32_e32 v8, 0x3fc, v8                                // 0000008541CC: 361010FF 000003FC
	ds_load_b32 v67, v8                                        // 0000008541D4: D8D80000 43000008
	.long 0xd73c0008                                           // 0000008541DC: D73C0008
	v_cndmask_b32_e32 v1, 1, v26, vcc_lo                       // 0000008541E0: 02023481
	v_add_nc_u32_e32 v26, 0x200, v26                           // 0000008541E4: 4A3434FF 00000200
	.long 0xd7006a0c                                           // 0000008541EC: D7006A0C
	v_cndmask_b32_e32 v1, s10, v8, vcc_lo                      // 0000008541F0: 0202100A
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008541F4: BF870001
	v_add_co_ci_u32_e64 v13, null, s11, v9, vcc_lo             // 0000008541F8: D5207C0D 01AA120B
	s_clause 0x3                                               // 000000854200: BF850003
	global_load_b128 v[8:11], v[12:13], off                    // 000000854204: DC5E0000 087C000C
	global_load_b128 v[19:22], v[12:13], off offset:16         // 00000085420C: DC5E0010 137C000C
	global_load_b128 v[42:45], v[12:13], off offset:32         // 000000854214: DC5E0020 2A7C000C
	global_load_b128 v[46:49], v[12:13], off offset:48         // 00000085421C: DC5E0030 2E7C000C
	s_waitcnt vmcnt(3) lgkmcnt(15)                             // 000000854224: BF890CF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 000000854228: CC1A4008 1A021D08
	s_waitcnt lgkmcnt(14)                                      // 000000854230: BF89FCE7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000854234: BF8700A1
	v_dot2_f32_bf16 v8, v9, v53, v8                            // 000000854238: CC1A4008 1C226B09
	s_waitcnt lgkmcnt(13)                                      // 000000854240: BF89FCD7
	v_dot2_f32_bf16 v8, v10, v54, v8                           // 000000854244: CC1A4008 1C226D0A
	s_waitcnt lgkmcnt(12)                                      // 00000085424C: BF89FCC7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000854250: BF8700A1
	v_dot2_f32_bf16 v8, v11, v55, v8                           // 000000854254: CC1A4008 1C226F0B
	s_waitcnt vmcnt(2) lgkmcnt(11)                             // 00000085425C: BF8908B7
	v_dot2_f32_bf16 v8, v19, v56, v8                           // 000000854260: CC1A4008 1C227113
	s_waitcnt lgkmcnt(10)                                      // 000000854268: BF89FCA7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000085426C: BF8700A1
	v_dot2_f32_bf16 v8, v20, v57, v8                           // 000000854270: CC1A4008 1C227314
	s_waitcnt lgkmcnt(9)                                       // 000000854278: BF89FC97
	v_dot2_f32_bf16 v8, v21, v58, v8                           // 00000085427C: CC1A4008 1C227515
	s_waitcnt lgkmcnt(8)                                       // 000000854284: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000854288: BF8700A1
	v_dot2_f32_bf16 v8, v22, v59, v8                           // 00000085428C: CC1A4008 1C227716
	s_waitcnt vmcnt(1) lgkmcnt(7)                              // 000000854294: BF890477
	v_dot2_f32_bf16 v8, v42, v60, v8                           // 000000854298: CC1A4008 1C22792A
	s_waitcnt lgkmcnt(6)                                       // 0000008542A0: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008542A4: BF8700A1
	v_dot2_f32_bf16 v8, v43, v61, v8                           // 0000008542A8: CC1A4008 1C227B2B
	s_waitcnt lgkmcnt(5)                                       // 0000008542B0: BF89FC57
	v_dot2_f32_bf16 v8, v44, v62, v8                           // 0000008542B4: CC1A4008 1C227D2C
	s_waitcnt lgkmcnt(4)                                       // 0000008542BC: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008542C0: BF8700A1
	v_dot2_f32_bf16 v8, v45, v63, v8                           // 0000008542C4: CC1A4008 1C227F2D
	s_waitcnt vmcnt(0) lgkmcnt(3)                              // 0000008542CC: BF890037
	v_dot2_f32_bf16 v8, v46, v64, v8                           // 0000008542D0: CC1A4008 1C22812E
	.long 0xd7006a2e                                           // 0000008542D8: D7006A2E
	v_cndmask_b32_e32 v0, v12, v8, vcc_lo                      // 0000008542DC: 0200110C
	s_waitcnt lgkmcnt(2)                                       // 0000008542E0: BF89FC27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000008542E4: BF8701C2
	v_dot2_f32_bf16 v8, v47, v65, v8                           // 0000008542E8: CC1A4008 1C22832F
	v_add_co_ci_u32_e64 v47, null, s9, v13, vcc_lo             // 0000008542F0: D5207C2F 01AA1A09
	.long 0xd7006a32                                           // 0000008542F8: D7006A32
	v_cndmask_b32_e32 v0, v12, v18, vcc_lo                     // 0000008542FC: 0200250C
	s_waitcnt lgkmcnt(1)                                       // 000000854300: BF89FC17
	v_dot2_f32_bf16 v8, v48, v66, v8                           // 000000854304: CC1A4008 1C228530
	v_add_co_ci_u32_e64 v51, null, s19, v13, vcc_lo            // 00000085430C: D5207C33 01AA1A13
	.long 0xd7006a0c                                           // 000000854314: D7006A0C
	v_cndmask_b32_e32 v0, v12, v21, vcc_lo                     // 000000854318: 02002B0C
	s_waitcnt lgkmcnt(0)                                       // 00000085431C: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000854320: BF870123
	v_dot2_f32_bf16 v8, v49, v67, v8                           // 000000854324: CC1A4008 1C228731
	v_add_co_ci_u32_e64 v13, null, s7, v13, vcc_lo             // 00000085432C: D5207C0D 01AA1A07
	v_fmac_f32_e32 v38, v52, v8                                // 000000854334: 564C1134
	s_clause 0x3                                               // 000000854338: BF850003
	global_load_b128 v[8:11], v[46:47], off                    // 00000085433C: DC5E0000 087C002E
	global_load_b128 v[19:22], v[46:47], off offset:16         // 000000854344: DC5E0010 137C002E
	global_load_b128 v[42:45], v[46:47], off offset:32         // 00000085434C: DC5E0020 2A7C002E
	global_load_b128 v[46:49], v[46:47], off offset:48         // 000000854354: DC5E0030 2E7C002E
	s_waitcnt vmcnt(3)                                         // 00000085435C: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 000000854360: CC1A4008 1A021D08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000854368: BF870091
	v_dot2_f32_bf16 v8, v9, v53, v8                            // 00000085436C: CC1A4008 1C226B09
	v_dot2_f32_bf16 v8, v10, v54, v8                           // 000000854374: CC1A4008 1C226D0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000085437C: BF8700A1
	v_dot2_f32_bf16 v8, v11, v55, v8                           // 000000854380: CC1A4008 1C226F0B
	s_waitcnt vmcnt(2)                                         // 000000854388: BF890BF7
	v_dot2_f32_bf16 v8, v19, v56, v8                           // 00000085438C: CC1A4008 1C227113
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000854394: BF870091
	v_dot2_f32_bf16 v8, v20, v57, v8                           // 000000854398: CC1A4008 1C227314
	v_dot2_f32_bf16 v8, v21, v58, v8                           // 0000008543A0: CC1A4008 1C227515
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008543A8: BF8700A1
	v_dot2_f32_bf16 v8, v22, v59, v8                           // 0000008543AC: CC1A4008 1C227716
	s_waitcnt vmcnt(1)                                         // 0000008543B4: BF8907F7
	v_dot2_f32_bf16 v8, v42, v60, v8                           // 0000008543B8: CC1A4008 1C22792A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008543C0: BF870091
	v_dot2_f32_bf16 v8, v43, v61, v8                           // 0000008543C4: CC1A4008 1C227B2B
	v_dot2_f32_bf16 v8, v44, v62, v8                           // 0000008543CC: CC1A4008 1C227D2C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008543D4: BF8700A1
	v_dot2_f32_bf16 v8, v45, v63, v8                           // 0000008543D8: CC1A4008 1C227F2D
	s_waitcnt vmcnt(0)                                         // 0000008543E0: BF8903F7
	v_dot2_f32_bf16 v8, v46, v64, v8                           // 0000008543E4: CC1A4008 1C22812E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008543EC: BF870091
	v_dot2_f32_bf16 v8, v47, v65, v8                           // 0000008543F0: CC1A4008 1C22832F
	v_dot2_f32_bf16 v8, v48, v66, v8                           // 0000008543F8: CC1A4008 1C228530
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000854400: BF870091
	v_dot2_f32_bf16 v8, v49, v67, v8                           // 000000854404: CC1A4008 1C228731
	v_fmac_f32_e32 v37, v52, v8                                // 00000085440C: 564A1134
	s_clause 0x3                                               // 000000854410: BF850003
	global_load_b128 v[8:11], v[50:51], off                    // 000000854414: DC5E0000 087C0032
	global_load_b128 v[19:22], v[50:51], off offset:16         // 00000085441C: DC5E0010 137C0032
	global_load_b128 v[42:45], v[50:51], off offset:32         // 000000854424: DC5E0020 2A7C0032
	global_load_b128 v[46:49], v[50:51], off offset:48         // 00000085442C: DC5E0030 2E7C0032
	s_waitcnt vmcnt(3)                                         // 000000854434: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 000000854438: CC1A4008 1A021D08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000854440: BF870091
	v_dot2_f32_bf16 v8, v9, v53, v8                            // 000000854444: CC1A4008 1C226B09
	v_dot2_f32_bf16 v8, v10, v54, v8                           // 00000085444C: CC1A4008 1C226D0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000854454: BF8700A1
	v_dot2_f32_bf16 v8, v11, v55, v8                           // 000000854458: CC1A4008 1C226F0B
	s_waitcnt vmcnt(2)                                         // 000000854460: BF890BF7
	v_dot2_f32_bf16 v8, v19, v56, v8                           // 000000854464: CC1A4008 1C227113
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000085446C: BF870091
	v_dot2_f32_bf16 v8, v20, v57, v8                           // 000000854470: CC1A4008 1C227314
	v_dot2_f32_bf16 v8, v21, v58, v8                           // 000000854478: CC1A4008 1C227515
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000854480: BF8700A1
	v_dot2_f32_bf16 v8, v22, v59, v8                           // 000000854484: CC1A4008 1C227716
	s_waitcnt vmcnt(1)                                         // 00000085448C: BF8907F7
	v_dot2_f32_bf16 v8, v42, v60, v8                           // 000000854490: CC1A4008 1C22792A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000854498: BF870091
	v_dot2_f32_bf16 v8, v43, v61, v8                           // 00000085449C: CC1A4008 1C227B2B
	v_dot2_f32_bf16 v8, v44, v62, v8                           // 0000008544A4: CC1A4008 1C227D2C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008544AC: BF8700A1
	v_dot2_f32_bf16 v8, v45, v63, v8                           // 0000008544B0: CC1A4008 1C227F2D
	s_waitcnt vmcnt(0)                                         // 0000008544B8: BF8903F7
	v_dot2_f32_bf16 v8, v46, v64, v8                           // 0000008544BC: CC1A4008 1C22812E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008544C4: BF870091
	v_dot2_f32_bf16 v8, v47, v65, v8                           // 0000008544C8: CC1A4008 1C22832F
	v_dot2_f32_bf16 v8, v48, v66, v8                           // 0000008544D0: CC1A4008 1C228530
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008544D8: BF870091
	v_dot2_f32_bf16 v8, v49, v67, v8                           // 0000008544DC: CC1A4008 1C228731
	v_fmac_f32_e32 v36, v52, v8                                // 0000008544E4: 56481134
	s_clause 0x3                                               // 0000008544E8: BF850003
	global_load_b128 v[8:11], v[12:13], off                    // 0000008544EC: DC5E0000 087C000C
	global_load_b128 v[19:22], v[12:13], off offset:16         // 0000008544F4: DC5E0010 137C000C
	global_load_b128 v[42:45], v[12:13], off offset:32         // 0000008544FC: DC5E0020 2A7C000C
	global_load_b128 v[46:49], v[12:13], off offset:48         // 000000854504: DC5E0030 2E7C000C
	s_waitcnt vmcnt(3)                                         // 00000085450C: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 000000854510: CC1A4008 1A021D08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000854518: BF870091
	v_dot2_f32_bf16 v8, v9, v53, v8                            // 00000085451C: CC1A4008 1C226B09
	v_dot2_f32_bf16 v8, v10, v54, v8                           // 000000854524: CC1A4008 1C226D0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000085452C: BF8700A1
	v_dot2_f32_bf16 v8, v11, v55, v8                           // 000000854530: CC1A4008 1C226F0B
	s_waitcnt vmcnt(2)                                         // 000000854538: BF890BF7
	v_dot2_f32_bf16 v8, v19, v56, v8                           // 00000085453C: CC1A4008 1C227113
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000854544: BF870091
	v_dot2_f32_bf16 v8, v20, v57, v8                           // 000000854548: CC1A4008 1C227314
	v_dot2_f32_bf16 v8, v21, v58, v8                           // 000000854550: CC1A4008 1C227515
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000854558: BF8700A1
	v_dot2_f32_bf16 v8, v22, v59, v8                           // 00000085455C: CC1A4008 1C227716
	s_waitcnt vmcnt(1)                                         // 000000854564: BF8907F7
	v_dot2_f32_bf16 v8, v42, v60, v8                           // 000000854568: CC1A4008 1C22792A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000854570: BF870091
	v_dot2_f32_bf16 v8, v43, v61, v8                           // 000000854574: CC1A4008 1C227B2B
	v_dot2_f32_bf16 v8, v44, v62, v8                           // 00000085457C: CC1A4008 1C227D2C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000854584: BF8700A1
	v_dot2_f32_bf16 v8, v45, v63, v8                           // 000000854588: CC1A4008 1C227F2D
	s_waitcnt vmcnt(0)                                         // 000000854590: BF8903F7
	v_dot2_f32_bf16 v8, v46, v64, v8                           // 000000854594: CC1A4008 1C22812E
	.long 0xd7006a2e                                           // 00000085459C: D7006A2E
	v_cndmask_b32_e32 v0, v50, v18, vcc_lo                     // 0000008545A0: 02002532
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000008545A4: BF8701B2
	v_dot2_f32_bf16 v8, v47, v65, v8                           // 0000008545A8: CC1A4008 1C22832F
	v_add_co_ci_u32_e64 v47, null, s19, v51, vcc_lo            // 0000008545B0: D5207C2F 01AA6613
	.long 0xd7006a0c                                           // 0000008545B8: D7006A0C
	v_cndmask_b32_e32 v0, v12, v18, vcc_lo                     // 0000008545BC: 0200250C
	v_dot2_f32_bf16 v8, v48, v66, v8                           // 0000008545C0: CC1A4008 1C228530
	v_add_co_ci_u32_e64 v13, null, s19, v13, vcc_lo            // 0000008545C8: D5207C0D 01AA1A13
	.long 0xd7006a1c                                           // 0000008545D0: D7006A1C
	v_cndmask_b32_e32 v0, v28, v160, vcc_lo                    // 0000008545D4: 0201411C
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000008545D8: BF870123
	v_dot2_f32_bf16 v8, v49, v67, v8                           // 0000008545DC: CC1A4008 1C228731
	v_add_co_ci_u32_e64 v29, null, 0, v29, vcc_lo              // 0000008545E4: D5207C1D 01AA3A80
	v_fmac_f32_e32 v35, v52, v8                                // 0000008545EC: 56461134
	s_clause 0x3                                               // 0000008545F0: BF850003
	global_load_b128 v[8:11], v[46:47], off                    // 0000008545F4: DC5E0000 087C002E
	global_load_b128 v[19:22], v[46:47], off offset:16         // 0000008545FC: DC5E0010 137C002E
	global_load_b128 v[42:45], v[46:47], off offset:32         // 000000854604: DC5E0020 2A7C002E
	global_load_b128 v[46:49], v[46:47], off offset:48         // 00000085460C: DC5E0030 2E7C002E
	s_waitcnt vmcnt(3)                                         // 000000854614: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 000000854618: CC1A4008 1A021D08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000854620: BF870091
	v_dot2_f32_bf16 v8, v9, v53, v8                            // 000000854624: CC1A4008 1C226B09
	v_dot2_f32_bf16 v8, v10, v54, v8                           // 00000085462C: CC1A4008 1C226D0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000854634: BF8700A1
	v_dot2_f32_bf16 v8, v11, v55, v8                           // 000000854638: CC1A4008 1C226F0B
	s_waitcnt vmcnt(2)                                         // 000000854640: BF890BF7
	v_dot2_f32_bf16 v8, v19, v56, v8                           // 000000854644: CC1A4008 1C227113
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000085464C: BF870091
	v_dot2_f32_bf16 v8, v20, v57, v8                           // 000000854650: CC1A4008 1C227314
	v_dot2_f32_bf16 v8, v21, v58, v8                           // 000000854658: CC1A4008 1C227515
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000854660: BF8700A1
	v_dot2_f32_bf16 v8, v22, v59, v8                           // 000000854664: CC1A4008 1C227716
	s_waitcnt vmcnt(1)                                         // 00000085466C: BF8907F7
	v_dot2_f32_bf16 v8, v42, v60, v8                           // 000000854670: CC1A4008 1C22792A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000854678: BF870091
	v_dot2_f32_bf16 v8, v43, v61, v8                           // 00000085467C: CC1A4008 1C227B2B
	v_dot2_f32_bf16 v8, v44, v62, v8                           // 000000854684: CC1A4008 1C227D2C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000085468C: BF8700A1
	v_dot2_f32_bf16 v8, v45, v63, v8                           // 000000854690: CC1A4008 1C227F2D
	s_waitcnt vmcnt(0)                                         // 000000854698: BF8903F7
	v_dot2_f32_bf16 v8, v46, v64, v8                           // 00000085469C: CC1A4008 1C22812E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008546A4: BF870091
	v_dot2_f32_bf16 v8, v47, v65, v8                           // 0000008546A8: CC1A4008 1C22832F
	v_dot2_f32_bf16 v8, v48, v66, v8                           // 0000008546B0: CC1A4008 1C228530
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008546B8: BF870091
	v_dot2_f32_bf16 v8, v49, v67, v8                           // 0000008546BC: CC1A4008 1C228731
	v_fmac_f32_e32 v34, v52, v8                                // 0000008546C4: 56441134
	s_clause 0x3                                               // 0000008546C8: BF850003
	global_load_b128 v[8:11], v[12:13], off                    // 0000008546CC: DC5E0000 087C000C
	global_load_b128 v[19:22], v[12:13], off offset:16         // 0000008546D4: DC5E0010 137C000C
	global_load_b128 v[42:45], v[12:13], off offset:32         // 0000008546DC: DC5E0020 2A7C000C
	global_load_b128 v[46:49], v[12:13], off offset:48         // 0000008546E4: DC5E0030 2E7C000C
	s_waitcnt vmcnt(3)                                         // 0000008546EC: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 0000008546F0: CC1A4008 1A021D08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008546F8: BF870091
	v_dot2_f32_bf16 v8, v9, v53, v8                            // 0000008546FC: CC1A4008 1C226B09
	v_dot2_f32_bf16 v8, v10, v54, v8                           // 000000854704: CC1A4008 1C226D0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000085470C: BF8700A1
	v_dot2_f32_bf16 v8, v11, v55, v8                           // 000000854710: CC1A4008 1C226F0B
	s_waitcnt vmcnt(2)                                         // 000000854718: BF890BF7
	v_dot2_f32_bf16 v8, v19, v56, v8                           // 00000085471C: CC1A4008 1C227113
	v_mov_b32_e32 v19, v15                                     // 000000854724: 7E26030F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000854728: BF870122
	v_dot2_f32_bf16 v8, v20, v57, v8                           // 00000085472C: CC1A4008 1C227314
	v_mov_b32_e32 v20, v16                                     // 000000854734: 7E280310
	v_dot2_f32_bf16 v8, v21, v58, v8                           // 000000854738: CC1A4008 1C227515
	v_mov_b32_e32 v21, v17                                     // 000000854740: 7E2A0311
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000854744: BF870132
	v_dot2_f32_bf16 v8, v22, v59, v8                           // 000000854748: CC1A4008 1C227716
	v_mov_b32_e32 v22, v18                                     // 000000854750: 7E2C0312
	s_waitcnt vmcnt(1)                                         // 000000854754: BF8907F7
	v_dot2_f32_bf16 v8, v42, v60, v8                           // 000000854758: CC1A4008 1C22792A
	v_mov_b32_e32 v42, v41                                     // 000000854760: 7E540329
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000854764: BF870092
	v_dot2_f32_bf16 v8, v43, v61, v8                           // 000000854768: CC1A4008 1C227B2B
	v_dot2_f32_bf16 v8, v44, v62, v8                           // 000000854770: CC1A4008 1C227D2C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000854778: BF8700A1
	v_dot2_f32_bf16 v8, v45, v63, v8                           // 00000085477C: CC1A4008 1C227F2D
	s_waitcnt vmcnt(0)                                         // 000000854784: BF8903F7
	v_dot2_f32_bf16 v8, v46, v64, v8                           // 000000854788: CC1A4008 1C22812E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000854790: BF870091
	v_dot2_f32_bf16 v8, v47, v65, v8                           // 000000854794: CC1A4008 1C22832F
	v_dot2_f32_bf16 v8, v48, v66, v8                           // 00000085479C: CC1A4008 1C228530
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008547A4: BF870091
	v_dot2_f32_bf16 v8, v49, v67, v8                           // 0000008547A8: CC1A4008 1C228731
	v_fmac_f32_e32 v32, v52, v8                                // 0000008547B0: 56401134
	v_mov_b32_e32 v14, v7                                      // 0000008547B4: 7E1C0307
	v_dual_mov_b32 v13, v6 :: v_dual_mov_b32 v12, v5           // 0000008547B8: CA100106 0D0C0105
	v_dual_mov_b32 v11, v4 :: v_dual_mov_b32 v10, v3           // 0000008547C0: CA100104 0B0A0103
	v_dual_mov_b32 v9, v2 :: v_dual_mov_b32 v8, v1             // 0000008547C8: CA100102 09080101
	v_mov_b32_e32 v7, v0                                       // 0000008547D0: 7E0E0300
	s_and_not1_b32 exec_lo, exec_lo, s20                       // 0000008547D4: 917E147E
	s_cbranch_execz 28                                         // 0000008547D8: BFA5001C <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi16ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0xd4c>
	s_waitcnt vmcnt(0)                                         // 0000008547DC: BF8903F7
	v_dual_mov_b32 v15, v19 :: v_dual_add_nc_u32 v40, 16, v40  // 0000008547E0: CA200113 0F285090
	v_dual_mov_b32 v16, v20 :: v_dual_mov_b32 v17, v21         // 0000008547E8: CA100114 10100115
	v_mov_b32_e32 v18, v22                                     // 0000008547F0: 7E240316
	s_delay_alu instid0(VALU_DEP_3)                            // 0000008547F4: BF870003
	.long 0xd4430004                                           // 0000008547F8: D4430004
	v_cndmask_b32_e32 v1, s6, v40, vcc_lo                      // 0000008547FC: 02025006
	s_mov_b32 s14, exec_lo                                     // 000000854800: BE8E007E
	.long 0xd4c4007e                                           // 000000854804: D4C4007E
	v_cndmask_b32_e32 v1, s6, v40, vcc_lo                      // 000000854808: 02025006
	s_cbranch_execz 65029                                      // 00000085480C: BFA5FE05 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi16ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x524>
	.long 0xd7006a00                                           // 000000854810: D7006A00
	v_cndmask_b32_e32 v1, v25, v39, vcc_lo                     // 000000854814: 02024F19
	s_delay_alu instid0(VALU_DEP_1)                            // 000000854818: BF870001
	v_add_co_ci_u32_e64 v1, null, 0, v33, vcc_lo               // 00000085481C: D5207C01 01AA4280
	v_cmp_ne_u32_e32 vcc_lo, 1, v31                            // 000000854824: 7C9A3E81
	v_mov_b32_e32 v41, v42                                     // 000000854828: 7E52032A
	global_load_b128 v[15:18], v[0:1], off                     // 00000085482C: DC5E0000 0F7C0000
	s_cbranch_vccnz 65019                                      // 000000854834: BFA4FDFB <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi16ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x524>
	global_load_d16_b16 v0, v[28:29], off                      // 000000854838: DC820000 007C001C
	s_waitcnt vmcnt(0)                                         // 000000854840: BF8903F7
	v_cvt_f32_f16_e32 v41, v0                                  // 000000854844: 7E521700
	s_branch 65014                                             // 000000854848: BFA0FDF6 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi16ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x524>
	s_or_b32 exec_lo, exec_lo, s20                             // 00000085484C: 8C7E147E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000854850: BF8700A9
	s_or_b32 exec_lo, exec_lo, s5                              // 000000854854: 8C7E057E
	.long 0xd71f0000                                           // 000000854858: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 00000085485C: 020100C1
	v_xor_b32_e32 v1, 8, v0                                    // 000000854860: 3A020088
	v_xor_b32_e32 v7, 4, v0                                    // 000000854864: 3A0E0084
	v_xor_b32_e32 v13, 2, v0                                   // 000000854868: 3A1A0082
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000085486C: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v1                            // 000000854870: 7C9802A0
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 000000854874: 02020300
	v_cmp_gt_u32_e32 vcc_lo, 32, v7                            // 000000854878: 7C980EA0
	s_delay_alu instid0(VALU_DEP_2)                            // 00000085487C: BF870002
	v_lshlrev_b32_e32 v1, 2, v1                                // 000000854880: 30020282
	ds_bpermute_b32 v4, v1, v36                                // 000000854884: DACC0000 04002401
	s_waitcnt lgkmcnt(0)                                       // 00000085488C: BF89FC07
	v_add_f32_e32 v4, v36, v4                                  // 000000854890: 06080924
	ds_bpermute_b32 v2, v1, v38                                // 000000854894: DACC0000 02002601
	ds_bpermute_b32 v6, v1, v34                                // 00000085489C: DACC0000 06002201
	v_cndmask_b32_e32 v7, v0, v7, vcc_lo                       // 0000008548A4: 020E0F00
	ds_bpermute_b32 v5, v1, v35                                // 0000008548A8: DACC0000 05002301
	ds_bpermute_b32 v3, v1, v37                                // 0000008548B0: DACC0000 03002501
	ds_bpermute_b32 v1, v1, v32                                // 0000008548B8: DACC0000 01002001
	v_cmp_gt_u32_e32 vcc_lo, 32, v13                           // 0000008548C0: 7C981AA0
	s_waitcnt lgkmcnt(4)                                       // 0000008548C4: BF89FC47
	v_dual_cndmask_b32 v13, v0, v13 :: v_dual_add_f32 v2, v38, v2// 0000008548C8: CA481B00 0D020526
	s_waitcnt lgkmcnt(3)                                       // 0000008548D0: BF89FC37
	v_dual_add_f32 v6, v34, v6 :: v_dual_lshlrev_b32 v7, 2, v7 // 0000008548D4: C9220D22 06060E82
	ds_bpermute_b32 v8, v7, v2                                 // 0000008548DC: DACC0000 08000207
	s_waitcnt lgkmcnt(0)                                       // 0000008548E4: BF89FC07
	v_add_f32_e32 v2, v2, v8                                   // 0000008548E8: 06041102
	ds_bpermute_b32 v12, v7, v6                                // 0000008548EC: DACC0000 0C000607
	ds_bpermute_b32 v10, v7, v4                                // 0000008548F4: DACC0000 0A000407
	v_add_f32_e32 v5, v35, v5                                  // 0000008548FC: 060A0B23
	s_waitcnt lgkmcnt(1)                                       // 000000854900: BF89FC17
	v_dual_add_f32 v3, v37, v3 :: v_dual_add_f32 v8, v6, v12   // 000000854904: C9080725 03081906
	v_xor_b32_e32 v6, 1, v0                                    // 00000085490C: 3A0C0081
	ds_bpermute_b32 v11, v7, v5                                // 000000854910: DACC0000 0B000507
	s_waitcnt lgkmcnt(1)                                       // 000000854918: BF89FC17
	v_add_f32_e32 v4, v4, v10                                  // 00000085491C: 06081504
	ds_bpermute_b32 v9, v7, v3                                 // 000000854920: DACC0000 09000307
	v_cmp_gt_u32_e32 vcc_lo, 32, v6                            // 000000854928: 7C980CA0
	v_dual_cndmask_b32 v0, v0, v6 :: v_dual_lshlrev_b32 v13, 2, v13// 00000085492C: CA620D00 000C1A82
	v_add_f32_e32 v1, v32, v1                                  // 000000854934: 06020320
	ds_bpermute_b32 v10, v13, v4                               // 000000854938: DACC0000 0A00040D
	ds_bpermute_b32 v12, v13, v8                               // 000000854940: DACC0000 0C00080D
	v_cmp_eq_u32_e32 vcc_lo, 0, v30                            // 000000854948: 7C943C80
	v_lshlrev_b32_e32 v14, 2, v0                               // 00000085494C: 301C0082
	ds_bpermute_b32 v7, v7, v1                                 // 000000854950: DACC0000 07000107
	s_and_b32 s2, vcc_lo, s2                                   // 000000854958: 8B02026A
	s_waitcnt lgkmcnt(2)                                       // 00000085495C: BF89FC27
	v_dual_add_f32 v3, v3, v9 :: v_dual_add_f32 v0, v4, v10    // 000000854960: C9081303 03001504
	s_waitcnt lgkmcnt(0)                                       // 000000854968: BF89FC07
	v_add_f32_e32 v9, v1, v7                                   // 00000085496C: 06120F01
	ds_bpermute_b32 v1, v13, v2                                // 000000854970: DACC0000 0100020D
	v_add_f32_e32 v5, v5, v11                                  // 000000854978: 060A1705
	ds_bpermute_b32 v7, v13, v3                                // 00000085497C: DACC0000 0700030D
	s_waitcnt lgkmcnt(1)                                       // 000000854984: BF89FC17
	v_add_f32_e32 v6, v2, v1                                   // 000000854988: 060C0302
	ds_bpermute_b32 v11, v13, v5                               // 00000085498C: DACC0000 0B00050D
	v_add_f32_e32 v2, v8, v12                                  // 000000854994: 06041908
	ds_bpermute_b32 v13, v13, v9                               // 000000854998: DACC0000 0D00090D
	s_waitcnt lgkmcnt(2)                                       // 0000008549A0: BF89FC27
	v_add_f32_e32 v7, v3, v7                                   // 0000008549A4: 060E0F03
	ds_bpermute_b32 v3, v14, v0                                // 0000008549A8: DACC0000 0300000E
	s_waitcnt lgkmcnt(2)                                       // 0000008549B0: BF89FC27
	v_add_f32_e32 v1, v5, v11                                  // 0000008549B4: 06021705
	ds_bpermute_b32 v5, v14, v2                                // 0000008549B8: DACC0000 0500020E
	s_waitcnt lgkmcnt(2)                                       // 0000008549C0: BF89FC27
	v_add_f32_e32 v8, v9, v13                                  // 0000008549C4: 06101B09
	ds_bpermute_b32 v9, v14, v6                                // 0000008549C8: DACC0000 0900060E
	ds_bpermute_b32 v10, v14, v7                               // 0000008549D0: DACC0000 0A00070E
	ds_bpermute_b32 v4, v14, v1                                // 0000008549D8: DACC0000 0400010E
	ds_bpermute_b32 v11, v14, v8                               // 0000008549E0: DACC0000 0B00080E
	s_and_saveexec_b32 s3, s2                                  // 0000008549E8: BE832002
	s_cbranch_execz 280                                        // 0000008549EC: BFA50118 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi16ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x1350>
	s_load_b32 s0, s[0:1], 0x48                                // 0000008549F0: F4000000 F8000048
	s_waitcnt lgkmcnt(0)                                       // 0000008549F8: BF89FC07
	v_dual_add_f32 v6, v6, v9 :: v_dual_add_f32 v7, v7, v10    // 0000008549FC: C9081306 06061507
	v_dual_add_f32 v8, v8, v11 :: v_dual_add_f32 v1, v1, v4    // 000000854A04: C9081708 08000901
	v_add_f32_e32 v0, v0, v3                                   // 000000854A0C: 06000700
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000854A10: BF870213
	v_bfe_u32 v9, v6, 16, 1                                    // 000000854A14: D6100009 02052106
	v_bfe_u32 v10, v7, 16, 1                                   // 000000854A1C: D610000A 02052107
	s_lshl_b64 s[4:5], s[16:17], 2                             // 000000854A24: 84848210
	s_delay_alu instid0(VALU_DEP_2)                            // 000000854A28: BF870002
	v_add3_u32 v3, v6, v9, 0x7fff                              // 000000854A2C: D6550003 03FE1306 00007FFF
	v_bfe_u32 v6, v1, 16, 1                                    // 000000854A38: D6100006 02052101
	v_add_f32_e32 v2, v2, v5                                   // 000000854A40: 06040B02
	v_add3_u32 v4, v7, v10, 0x7fff                             // 000000854A44: D6550004 03FE1507 00007FFF
	v_bfe_u32 v9, v8, 16, 1                                    // 000000854A50: D6100009 02052108
	v_and_b32_e32 v3, 0xffff0000, v3                           // 000000854A58: 360606FF FFFF0000
	v_add3_u32 v1, v1, v6, 0x7fff                              // 000000854A60: D6550001 03FE0D01 00007FFF
	v_bfe_u32 v7, v2, 16, 1                                    // 000000854A6C: D6100007 02052102
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000854A74: BF870193
	v_dual_mul_f32 v3, s0, v3 :: v_dual_and_b32 v4, 0xffff0000, v4// 000000854A78: C8E40600 030408FF FFFF0000
	v_and_b32_e32 v1, 0xffff0000, v1                           // 000000854A84: 360202FF FFFF0000
	v_bfe_u32 v5, v0, 16, 1                                    // 000000854A8C: D6100005 02052100
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000854A94: BF870233
	v_mul_f32_e32 v4, s0, v4                                   // 000000854A98: 10080800
	v_add3_u32 v2, v2, v7, 0x7fff                              // 000000854A9C: D6550002 03FE0F02 00007FFF
	v_mul_f32_e32 v3, 0xbfb8aa3b, v3                           // 000000854AA8: 100606FF BFB8AA3B
	v_add3_u32 v0, v0, v5, 0x7fff                              // 000000854AB0: D6550000 03FE0B00 00007FFF
	v_add3_u32 v5, v8, v9, 0x7fff                              // 000000854ABC: D6550005 03FE1308 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000854AC8: BF870093
	v_exp_f32_e32 v3, v3                                       // 000000854ACC: 7E064B03
	v_and_b32_e32 v5, 0xffff0000, v5                           // 000000854AD0: 360A0AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000854AD8: BF870001
	v_dual_mul_f32 v5, s0, v5 :: v_dual_and_b32 v0, 0xffff0000, v0// 000000854ADC: C8E40A00 050000FF FFFF0000
	v_mul_f32_e32 v4, 0xbfb8aa3b, v4                           // 000000854AE8: 100808FF BFB8AA3B
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(VALU_DEP_2)   // 000000854AF0: BF870105
	v_dual_add_f32 v8, 1.0, v3 :: v_dual_mul_f32 v3, 0xbfb8aa3b, v5// 000000854AF4: C90606F2 08020AFF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000854B00: BF870092
	v_exp_f32_e32 v4, v4                                       // 000000854B04: 7E084B04
	v_exp_f32_e32 v11, v3                                      // 000000854B08: 7E164B03
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000854B0C: BF870095
	v_dual_mul_f32 v0, s0, v0 :: v_dual_add_f32 v11, 1.0, v11  // 000000854B10: C8C80000 000A16F2
	v_dual_mul_f32 v6, s0, v1 :: v_dual_mul_f32 v7, 0xbfb8aa3b, v0// 000000854B18: C8C60200 060600FF BFB8AA3B
	.long 0xd73c0000                                           // 000000854B24: D73C0000
	v_cndmask_b32_e32 v1, 2, v23, vcc_lo                       // 000000854B28: 02022E82
	s_waitcnt vmcnt(0)                                         // 000000854B2C: BF8903F7
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000854B30: BF870193
	v_div_scale_f32 v21, null, v11, v11, 1.0                   // 000000854B34: D6FC7C15 03CA170B
	v_exp_f32_e32 v7, v7                                       // 000000854B3C: 7E0E4B07
	v_and_b32_e32 v2, 0xffff0000, v2                           // 000000854B40: 360404FF FFFF0000
	s_delay_alu instid0(VALU_DEP_2)                            // 000000854B48: BF870002
	v_rcp_f32_e32 v27, v21                                     // 000000854B4C: 7E365515
	s_delay_alu instid0(TRANS32_DEP_2) | instid1(VALU_DEP_1)   // 000000854B50: BF870086
	v_dual_add_f32 v7, 1.0, v7 :: v_dual_mul_f32 v2, s0, v2    // 000000854B54: C9060EF2 07020400
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000854B5C: BF870095
	v_fma_f32 v28, -v21, v27, 1.0                              // 000000854B60: D613001C 23CA3715
	v_dual_mul_f32 v2, 0xbfb8aa3b, v2 :: v_dual_fmac_f32 v27, v28, v27// 000000854B68: C8C004FF 021A371C BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000854B74: BF8700A1
	v_exp_f32_e32 v10, v2                                      // 000000854B78: 7E144B02
	.long 0xd7006a02                                           // 000000854B7C: D7006A02
	v_cndmask_b32_e32 v1, s12, v0, vcc_lo                      // 000000854B80: 0202000C
	v_add_co_ci_u32_e64 v3, null, s13, v1, vcc_lo              // 000000854B84: D5207C03 01AA020D
	v_div_scale_f32 v1, null, v7, v7, 1.0                      // 000000854B8C: D6FC7C01 03CA0F07
	v_div_scale_f32 v15, vcc_lo, 1.0, v8, 1.0                  // 000000854B94: D6FC6A0F 03CA10F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000854B9C: BF870292
	v_rcp_f32_e32 v17, v1                                      // 000000854BA0: 7E225501
	v_fma_f32 v23, -v1, v17, 1.0                               // 000000854BA4: D6130017 23CA2301
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000854BAC: BF870091
	v_dual_add_f32 v4, 1.0, v4 :: v_dual_fmac_f32 v17, v23, v17// 000000854BB0: C90008F2 04102317
	v_div_scale_f32 v9, null, v4, v4, 1.0                      // 000000854BB8: D6FC7C09 03CA0904
	v_div_scale_f32 v16, s0, 1.0, v4, 1.0                      // 000000854BC0: D6FC0010 03CA08F2
	v_add_f32_e32 v10, 1.0, v10                                // 000000854BC8: 061414F2
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000854BCC: BF870293
	v_rcp_f32_e32 v13, v9                                      // 000000854BD0: 7E1A5509
	v_fma_f32 v14, -v9, v13, 1.0                               // 000000854BD4: D613000E 23CA1B09
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000854BDC: BF870091
	v_dual_mul_f32 v6, 0xbfb8aa3b, v6 :: v_dual_fmac_f32 v13, v14, v13// 000000854BE0: C8C00CFF 060C1B0E BFB8AA3B
	v_exp_f32_e32 v5, v6                                       // 000000854BEC: 7E0A4B06
	v_div_scale_f32 v6, null, v8, v8, 1.0                      // 000000854BF0: D6FC7C06 03CA1108
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000854BF8: BF870112
	v_mul_f32_e32 v20, v16, v13                                // 000000854BFC: 10281B10
	v_rcp_f32_e32 v12, v6                                      // 000000854C00: 7E185506
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000854C04: BF870091
	v_fma_f32 v25, -v9, v20, v16                               // 000000854C08: D6130019 24422909
	v_fmac_f32_e32 v20, v25, v13                               // 000000854C10: 56281B19
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(TRANS32_DEP_2)// 000000854C14: BF870321
	v_fma_f32 v9, -v9, v20, v16                                // 000000854C18: D6130009 24422909
	v_div_scale_f32 v16, s3, 1.0, v10, 1.0                     // 000000854C20: D6FC0310 03CA14F2
	v_add_f32_e32 v0, 1.0, v5                                  // 000000854C28: 06000AF2
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000854C2C: BF870095
	v_fma_f32 v5, -v6, v12, 1.0                                // 000000854C30: D6130005 23CA1906
	v_fmac_f32_e32 v12, v5, v12                                // 000000854C38: 56181905
	v_div_scale_f32 v5, s1, 1.0, v7, 1.0                       // 000000854C3C: D6FC0105 03CA0EF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000854C44: BF870112
	v_mul_f32_e32 v19, v15, v12                                // 000000854C48: 1026190F
	v_mul_f32_e32 v25, v5, v17                                 // 000000854C4C: 10322305
	v_div_scale_f32 v18, null, v10, v10, 1.0                   // 000000854C50: D6FC7C12 03CA150A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000854C58: BF870113
	v_fma_f32 v24, -v6, v19, v15                               // 000000854C5C: D6130018 243E2706
	v_rcp_f32_e32 v26, v18                                     // 000000854C64: 7E345512
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000854C68: BF870091
	v_fmac_f32_e32 v19, v24, v12                               // 000000854C6C: 56261918
	v_fma_f32 v6, -v6, v19, v15                                // 000000854C70: D6130006 243E2706
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000854C78: BF870115
	v_fma_f32 v15, -v18, v26, 1.0                              // 000000854C7C: D613000F 23CA3512
	v_div_fmas_f32 v6, v6, v12, v19                            // 000000854C84: D6370006 044E1906
	s_mov_b32 vcc_lo, s0                                       // 000000854C8C: BEEA0000
	v_fma_f32 v12, -v1, v25, v5                                // 000000854C90: D613000C 24163301
	v_div_fmas_f32 v9, v9, v13, v20                            // 000000854C98: D6370009 04521B09
	v_fmac_f32_e32 v26, v15, v26                               // 000000854CA0: 5634350F
	s_mov_b32 vcc_lo, s1                                       // 000000854CA4: BEEA0001
	v_div_fixup_f32 v6, v6, v8, 1.0                            // 000000854CA8: D6270006 03CA1106
	v_fmac_f32_e32 v25, v12, v17                               // 000000854CB0: 5632230C
	v_div_fixup_f32 v4, v9, v4, 1.0                            // 000000854CB4: D6270004 03CA0909
	v_mul_f32_e32 v9, v16, v26                                 // 000000854CBC: 10123510
	v_div_scale_f32 v14, null, v0, v0, 1.0                     // 000000854CC0: D6FC7C0E 03CA0100
	v_div_scale_f32 v23, s2, 1.0, v0, 1.0                      // 000000854CC8: D6FC0217 03CA00F2
	v_fma_f32 v1, -v1, v25, v5                                 // 000000854CD0: D6130001 24163301
	v_add_f32_e32 v12, v4, v4                                  // 000000854CD8: 06180904
	v_fma_f32 v5, -v18, v9, v16                                // 000000854CDC: D6130005 24421312
	v_rcp_f32_e32 v22, v14                                     // 000000854CE4: 7E2C550E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000854CE8: BF870113
	v_div_fmas_f32 v1, v1, v17, v25                            // 000000854CEC: D6370001 04662301
	v_fmac_f32_e32 v9, v5, v26                                 // 000000854CF4: 56123505
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000854CF8: BF870112
	v_div_fixup_f32 v1, v1, v7, 1.0                            // 000000854CFC: D6270001 03CA0F01
	v_fma_f32 v15, -v18, v9, v16                               // 000000854D04: D613000F 24421312
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000854D0C: BF870095
	v_fma_f32 v24, -v14, v22, 1.0                              // 000000854D10: D6130018 23CA2D0E
	v_dual_add_f32 v13, v1, v1 :: v_dual_fmac_f32 v22, v24, v22// 000000854D18: C9000301 0D162D18
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000854D20: BF870091
	v_mul_f32_e32 v8, v23, v22                                 // 000000854D24: 10102D17
	v_fma_f32 v4, -v14, v8, v23                                // 000000854D28: D6130004 245E110E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000854D30: BF8700A1
	v_fmac_f32_e32 v8, v4, v22                                 // 000000854D34: 56102D04
	.long 0xd7006a04                                           // 000000854D38: D7006A04
	v_cndmask_b32_e32 v0, v2, v4, vcc_lo                       // 000000854D3C: 02000902
	v_add_co_ci_u32_e64 v5, null, s5, v3, vcc_lo               // 000000854D40: D5207C05 01AA0605
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000854D48: BF8700A3
	v_fma_f32 v1, -v14, v8, v23                                // 000000854D4C: D6130001 245E110E
	s_mov_b32 vcc_lo, s2                                       // 000000854D54: BEEA0002
	v_div_fmas_f32 v1, v1, v22, v8                             // 000000854D58: D6370001 04222D01
	s_mov_b32 vcc_lo, s3                                       // 000000854D60: BEEA0003
	s_lshl_b64 s[2:3], s[16:17], 3                             // 000000854D64: 84828310
	v_div_fmas_f32 v8, v15, v26, v9                            // 000000854D68: D6370008 0426350F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000854D70: BF8701A2
	v_div_fixup_f32 v9, v1, v0, 1.0                            // 000000854D74: D6270009 03CA0101
	v_mad_u64_u32 v[0:1], null, s16, 12, v[2:3]                // 000000854D7C: D6FE7C00 04091810
	v_div_fixup_f32 v8, v8, v10, 1.0                           // 000000854D84: D6270008 03CA1508
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000854D8C: BF8700D1
	v_dual_add_f32 v6, v6, v6 :: v_dual_add_f32 v15, v8, v8    // 000000854D90: C9080D06 060E1108
	global_store_b32 v[2:3], v6, off                           // 000000854D98: DC6A0000 007C0602
	v_div_scale_f32 v6, s0, 1.0, v11, 1.0                      // 000000854DA0: D6FC0006 03CA16F2
	s_mov_b32 vcc_lo, s0                                       // 000000854DA8: BEEA0000
	v_mul_f32_e32 v7, v6, v27                                  // 000000854DAC: 100E3706
	v_fma_f32 v14, -v21, v7, v6                                // 000000854DB0: D613000E 241A0F15
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000854DB8: BF870091
	v_dual_fmac_f32 v7, v14, v27 :: v_dual_add_f32 v14, v9, v9 // 000000854DBC: C808370E 070E1309
	v_fma_f32 v6, -v21, v7, v6                                 // 000000854DC4: D6130006 241A0F15
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000854DCC: BF870241
	v_div_fmas_f32 v10, v6, v27, v7                            // 000000854DD0: D637000A 041E3706
	.long 0xd7006a06                                           // 000000854DD8: D7006A06
	v_cndmask_b32_e32 v0, v2, v2, vcc_lo                       // 000000854DDC: 02000502
	v_mad_u64_u32 v[1:2], null, s17, 12, v[1:2]                // 000000854DE0: D6FE7C01 04051811
	v_add_co_ci_u32_e64 v7, null, s3, v3, vcc_lo               // 000000854DE8: D5207C07 01AA0603
	v_div_fixup_f32 v8, v10, v11, 1.0                          // 000000854DF0: D6270008 03CA170A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000854DF8: BF870094
	.long 0xd7006a02                                           // 000000854DFC: D7006A02
	v_cndmask_b32_e32 v0, v6, v2, vcc_lo                       // 000000854E00: 02000506
	v_add_co_ci_u32_e64 v3, null, s3, v7, vcc_lo               // 000000854E04: D5207C03 01AA0E03
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000854E0C: BF8700A3
	v_add_f32_e32 v10, v8, v8                                  // 000000854E10: 06141108
	.long 0xd7006a08                                           // 000000854E14: D7006A08
	v_cndmask_b32_e32 v0, v0, v2, vcc_lo                       // 000000854E18: 02000500
	v_add_co_ci_u32_e64 v9, null, s3, v1, vcc_lo               // 000000854E1C: D5207C09 01AA0203
	s_clause 0x4                                               // 000000854E24: BF850004
	global_store_b32 v[4:5], v12, off                          // 000000854E28: DC6A0000 007C0C04
	global_store_b32 v[6:7], v13, off                          // 000000854E30: DC6A0000 007C0D06
	global_store_b32 v[0:1], v14, off                          // 000000854E38: DC6A0000 007C0E00
	global_store_b32 v[2:3], v15, off                          // 000000854E40: DC6A0000 007C0F02
	global_store_b32 v[8:9], v10, off                          // 000000854E48: DC6A0000 007C0A08
	s_endpgm                                                   // 000000854E50: BFB00000
		...

