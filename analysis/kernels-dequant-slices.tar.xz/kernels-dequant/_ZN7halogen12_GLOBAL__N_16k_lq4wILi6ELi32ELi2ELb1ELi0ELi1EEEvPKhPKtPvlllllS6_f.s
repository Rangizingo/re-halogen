0000000000756c00 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi2ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi2ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 000000756C00: F4100100 F8000000
	s_ashr_i32 s3, s2, 31                                      // 000000756C08: 86039F02
	v_lshrrev_b32_e32 v2, 2, v0                                // 000000756C0C: 32040082
	s_lshl_b64 s[2:3], s[2:3], 2                               // 000000756C10: 84828202
	v_and_b32_e32 v1, 15, v0                                   // 000000756C14: 3602008F
	v_lshrrev_b32_e32 v28, 6, v0                               // 000000756C18: 32380086
	v_bfe_u32 v29, v0, 5, 1                                    // 000000756C1C: D610001D 02050B00
	v_and_b32_e32 v2, 60, v2                                   // 000000756C24: 360404BC
	v_and_b32_e32 v30, 31, v0                                  // 000000756C28: 363C009F
	v_lshlrev_b32_e32 v1, 2, v1                                // 000000756C2C: 30020282
	.long 0x7f0a3880                                           // 000000756C30: 7F0A3880
	v_lshlrev_b32_e32 v6, 2, v0                                // 000000756C34: 300C0082
	s_waitcnt lgkmcnt(0)                                       // 000000756C38: BF89FC07
	s_clause 0x1                                               // 000000756C3C: BF850001
	global_load_b32 v3, v1, s[4:5]                             // 000000756C40: DC520000 03040001
	global_load_b32 v4, v2, s[4:5]                             // 000000756C48: DC520000 04040002
	s_add_u32 s0, s4, s16                                      // 000000756C50: 80001004
	s_addc_u32 s1, s5, s17                                     // 000000756C54: 82011105
	s_ashr_i32 s16, s11, 31                                    // 000000756C58: 86109F0B
	v_mov_b32_e32 v2, s3                                       // 000000756C5C: 7E040203
	s_lshr_b32 s16, s16, 27                                    // 000000756C60: 85109B10
	v_or_b32_e32 v1, s2, v28                                   // 000000756C64: 38023802
	s_add_u32 s16, s10, s16                                    // 000000756C68: 8010100A
	s_addc_u32 s17, s11, 0                                     // 000000756C6C: 8211800B
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000756C70: BF870099
	s_lshr_b64 s[16:17], s[16:17], 5                           // 000000756C74: 85908510
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[1:2]                  // 000000756C78: 7CA8020C
	s_add_i32 s17, s16, 1                                      // 000000756C7C: 81118110
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000756C80: BF870499
	s_lshr_b32 s20, s17, 31                                    // 000000756C84: 85149F11
	s_add_i32 s17, s17, s20                                    // 000000756C88: 81111411
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 000000756C8C: 02020280
	s_ashr_i32 s17, s17, 1                                     // 000000756C90: 86118111
	v_cndmask_b32_e64 v2, 0, s3, vcc_lo                        // 000000756C94: D5010002 01A80680
	.long 0xd72c0007                                           // 000000756C9C: D72C0007
	v_cndmask_b32_e32 v1, s17, v29, vcc_lo                     // 000000756CA0: 02023A11
	s_cmpk_lt_i32 s16, 0x201                                   // 000000756CA4: B3900201
	.long 0xd72c0009                                           // 000000756CA8: D72C0009
	v_cndmask_b32_e32 v1, s19, v1, vcc_lo                      // 000000756CAC: 02020213
	v_mad_u64_u32 v[24:25], null, s18, v1, s[0:1]              // 000000756CB0: D6FE7C18 00020212
	s_cselect_b32 s0, -1, 0                                    // 000000756CB8: 980080C1
	s_cmpk_gt_i32 s16, 0x200                                   // 000000756CBC: B2900200
	v_add_nc_u32_e32 v11, s17, v7                              // 000000756CC0: 4A160E11
	v_add_nc_u32_e32 v31, v7, v30                              // 000000756CC4: 4A3E3D07
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000756CC8: BF8704A2
	v_min_i32_e32 v32, s16, v11                                // 000000756CCC: 22401610
	s_cselect_b32 s16, -1, 0                                   // 000000756CD0: 981080C1
	s_and_b32 vcc_lo, exec_lo, s16                             // 000000756CD4: 8B6A107E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 000000756CD8: BF870151
	.long 0xd4410001                                           // 000000756CDC: D4410001
	v_cndmask_b32_e32 v1, v31, v32, vcc_lo                     // 000000756CE0: 0202411F
	s_waitcnt vmcnt(1)                                         // 000000756CE4: BF8907F7
	v_bfe_u32 v8, v3, 16, 1                                    // 000000756CE8: D6100008 02052103
	s_waitcnt vmcnt(0)                                         // 000000756CF0: BF8903F7
	v_bfe_u32 v10, v4, 16, 1                                   // 000000756CF4: D610000A 02052104
	v_add3_u32 v3, v3, v8, 0x7fff                              // 000000756CFC: D6550003 03FE1103 00007FFF
	.long 0xd72c0008                                           // 000000756D08: D72C0008
	v_cndmask_b32_e32 v1, s18, v2, vcc_lo                      // 000000756D0C: 02020412
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000756D10: BF870193
	v_add3_u32 v4, v4, v10, 0x7fff                             // 000000756D14: D6550004 03FE1504 00007FFF
	.long 0x7e0a3983                                           // 000000756D20: 7E0A3983
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000756D24: BF870113
	v_add3_u32 v33, v9, v25, v8                                // 000000756D28: D6550021 04223309
	v_and_or_b32 v3, 0xffff0000, v4, v5                        // 000000756D30: D6570003 041608FF FFFF0000
	ds_store_b32 v6, v3                                        // 000000756D3C: D8340000 00000306
	s_waitcnt lgkmcnt(0)                                       // 000000756D44: BF89FC07
	s_barrier                                                  // 000000756D48: BFBD0000
	buffer_gl0_inv                                             // 000000756D4C: E0AC0000 00000000
	s_cbranch_vccnz 154                                        // 000000756D54: BFA4009A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi2ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x3c0>
	v_dual_mov_b32 v9, 0 :: v_dual_mov_b32 v8, 0               // 000000756D58: CA100080 09080080
	s_and_saveexec_b32 s17, s1                                 // 000000756D60: BE912001
	s_cbranch_execz 11                                         // 000000756D64: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi2ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x194>
	v_lshlrev_b32_e32 v3, 1, v31                               // 000000756D68: 30063E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000756D6C: BF8700A1
	v_ashrrev_i32_e32 v4, 31, v3                               // 000000756D70: 3408069F
	.long 0xd7006a03                                           // 000000756D74: D7006A03
	v_cndmask_b32_e32 v1, v24, v3, vcc_lo                      // 000000756D78: 02020718
	v_add_co_ci_u32_e64 v4, null, v33, v4, vcc_lo              // 000000756D7C: D5207C04 01AA0921
	global_load_d16_b16 v3, v[3:4], off                        // 000000756D84: DC820000 037C0003
	s_waitcnt vmcnt(0)                                         // 000000756D8C: BF8903F7
	v_cvt_f32_f16_e32 v8, v3                                   // 000000756D90: 7E101703
	s_or_b32 exec_lo, exec_lo, s17                             // 000000756D94: 8C7E117E
	v_add_nc_u32_e32 v3, 32, v31                               // 000000756D98: 4A063EA0
	s_mov_b32 s1, exec_lo                                      // 000000756D9C: BE81007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000756DA0: BF870001
	.long 0xd4c1007e                                           // 000000756DA4: D4C1007E
	v_cndmask_b32_e32 v1, v3, v32, vcc_lo                      // 000000756DA8: 02024103
	s_cbranch_execz 11                                         // 000000756DAC: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi2ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x1dc>
	v_lshlrev_b32_e32 v3, 1, v3                                // 000000756DB0: 30060681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000756DB4: BF8700A1
	v_ashrrev_i32_e32 v4, 31, v3                               // 000000756DB8: 3408069F
	.long 0xd7006a03                                           // 000000756DBC: D7006A03
	v_cndmask_b32_e32 v1, v24, v3, vcc_lo                      // 000000756DC0: 02020718
	v_add_co_ci_u32_e64 v4, null, v33, v4, vcc_lo              // 000000756DC4: D5207C04 01AA0921
	global_load_d16_b16 v3, v[3:4], off                        // 000000756DCC: DC820000 037C0003
	s_waitcnt vmcnt(0)                                         // 000000756DD4: BF8903F7
	v_cvt_f32_f16_e32 v9, v3                                   // 000000756DD8: 7E121703
	s_or_b32 exec_lo, exec_lo, s1                              // 000000756DDC: 8C7E017E
	v_dual_mov_b32 v10, 0 :: v_dual_add_nc_u32 v3, 64, v31     // 000000756DE0: CA200080 0A023EC0
	v_mov_b32_e32 v11, 0                                       // 000000756DE8: 7E160280
	s_mov_b32 s1, exec_lo                                      // 000000756DEC: BE81007E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000756DF0: BF870002
	.long 0xd4c1007e                                           // 000000756DF4: D4C1007E
	v_cndmask_b32_e32 v1, v3, v32, vcc_lo                      // 000000756DF8: 02024103
	s_cbranch_execz 11                                         // 000000756DFC: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi2ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x22c>
	v_lshlrev_b32_e32 v3, 1, v3                                // 000000756E00: 30060681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000756E04: BF8700A1
	v_ashrrev_i32_e32 v4, 31, v3                               // 000000756E08: 3408069F
	.long 0xd7006a03                                           // 000000756E0C: D7006A03
	v_cndmask_b32_e32 v1, v24, v3, vcc_lo                      // 000000756E10: 02020718
	v_add_co_ci_u32_e64 v4, null, v33, v4, vcc_lo              // 000000756E14: D5207C04 01AA0921
	global_load_d16_b16 v3, v[3:4], off                        // 000000756E1C: DC820000 037C0003
	s_waitcnt vmcnt(0)                                         // 000000756E24: BF8903F7
	v_cvt_f32_f16_e32 v10, v3                                  // 000000756E28: 7E141703
	s_or_b32 exec_lo, exec_lo, s1                              // 000000756E2C: 8C7E017E
	v_add_nc_u32_e32 v3, 0x60, v31                             // 000000756E30: 4A063EFF 00000060
	s_mov_b32 s1, exec_lo                                      // 000000756E38: BE81007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000756E3C: BF870001
	.long 0xd4c1007e                                           // 000000756E40: D4C1007E
	v_cndmask_b32_e32 v1, v3, v32, vcc_lo                      // 000000756E44: 02024103
	s_cbranch_execz 11                                         // 000000756E48: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi2ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x278>
	v_lshlrev_b32_e32 v3, 1, v3                                // 000000756E4C: 30060681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000756E50: BF8700A1
	v_ashrrev_i32_e32 v4, 31, v3                               // 000000756E54: 3408069F
	.long 0xd7006a03                                           // 000000756E58: D7006A03
	v_cndmask_b32_e32 v1, v24, v3, vcc_lo                      // 000000756E5C: 02020718
	v_add_co_ci_u32_e64 v4, null, v33, v4, vcc_lo              // 000000756E60: D5207C04 01AA0921
	global_load_d16_b16 v3, v[3:4], off                        // 000000756E68: DC820000 037C0003
	s_waitcnt vmcnt(0)                                         // 000000756E70: BF8903F7
	v_cvt_f32_f16_e32 v11, v3                                  // 000000756E74: 7E161703
	s_or_b32 exec_lo, exec_lo, s1                              // 000000756E78: 8C7E017E
	v_dual_mov_b32 v12, 0 :: v_dual_add_nc_u32 v3, 0x80, v31   // 000000756E7C: CA200080 0C023EFF 00000080
	v_mov_b32_e32 v13, 0                                       // 000000756E88: 7E1A0280
	s_mov_b32 s1, exec_lo                                      // 000000756E8C: BE81007E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000756E90: BF870002
	.long 0xd4c1007e                                           // 000000756E94: D4C1007E
	v_cndmask_b32_e32 v1, v3, v32, vcc_lo                      // 000000756E98: 02024103
	s_cbranch_execz 11                                         // 000000756E9C: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi2ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x2cc>
	v_lshlrev_b32_e32 v3, 1, v3                                // 000000756EA0: 30060681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000756EA4: BF8700A1
	v_ashrrev_i32_e32 v4, 31, v3                               // 000000756EA8: 3408069F
	.long 0xd7006a03                                           // 000000756EAC: D7006A03
	v_cndmask_b32_e32 v1, v24, v3, vcc_lo                      // 000000756EB0: 02020718
	v_add_co_ci_u32_e64 v4, null, v33, v4, vcc_lo              // 000000756EB4: D5207C04 01AA0921
	global_load_d16_b16 v3, v[3:4], off                        // 000000756EBC: DC820000 037C0003
	s_waitcnt vmcnt(0)                                         // 000000756EC4: BF8903F7
	v_cvt_f32_f16_e32 v12, v3                                  // 000000756EC8: 7E181703
	s_or_b32 exec_lo, exec_lo, s1                              // 000000756ECC: 8C7E017E
	v_add_nc_u32_e32 v3, 0xa0, v31                             // 000000756ED0: 4A063EFF 000000A0
	s_mov_b32 s1, exec_lo                                      // 000000756ED8: BE81007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000756EDC: BF870001
	.long 0xd4c1007e                                           // 000000756EE0: D4C1007E
	v_cndmask_b32_e32 v1, v3, v32, vcc_lo                      // 000000756EE4: 02024103
	s_cbranch_execz 11                                         // 000000756EE8: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi2ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x318>
	v_lshlrev_b32_e32 v3, 1, v3                                // 000000756EEC: 30060681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000756EF0: BF8700A1
	v_ashrrev_i32_e32 v4, 31, v3                               // 000000756EF4: 3408069F
	.long 0xd7006a03                                           // 000000756EF8: D7006A03
	v_cndmask_b32_e32 v1, v24, v3, vcc_lo                      // 000000756EFC: 02020718
	v_add_co_ci_u32_e64 v4, null, v33, v4, vcc_lo              // 000000756F00: D5207C04 01AA0921
	global_load_d16_b16 v3, v[3:4], off                        // 000000756F08: DC820000 037C0003
	s_waitcnt vmcnt(0)                                         // 000000756F10: BF8903F7
	v_cvt_f32_f16_e32 v13, v3                                  // 000000756F14: 7E1A1703
	s_or_b32 exec_lo, exec_lo, s1                              // 000000756F18: 8C7E017E
	v_dual_mov_b32 v14, 0 :: v_dual_add_nc_u32 v3, 0xc0, v31   // 000000756F1C: CA200080 0E023EFF 000000C0
	v_mov_b32_e32 v15, 0                                       // 000000756F28: 7E1E0280
	s_mov_b32 s1, exec_lo                                      // 000000756F2C: BE81007E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000756F30: BF870002
	.long 0xd4c1007e                                           // 000000756F34: D4C1007E
	v_cndmask_b32_e32 v1, v3, v32, vcc_lo                      // 000000756F38: 02024103
	s_cbranch_execz 11                                         // 000000756F3C: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi2ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x36c>
	v_lshlrev_b32_e32 v3, 1, v3                                // 000000756F40: 30060681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000756F44: BF8700A1
	v_ashrrev_i32_e32 v4, 31, v3                               // 000000756F48: 3408069F
	.long 0xd7006a03                                           // 000000756F4C: D7006A03
	v_cndmask_b32_e32 v1, v24, v3, vcc_lo                      // 000000756F50: 02020718
	v_add_co_ci_u32_e64 v4, null, v33, v4, vcc_lo              // 000000756F54: D5207C04 01AA0921
	global_load_d16_b16 v3, v[3:4], off                        // 000000756F5C: DC820000 037C0003
	s_waitcnt vmcnt(0)                                         // 000000756F64: BF8903F7
	v_cvt_f32_f16_e32 v14, v3                                  // 000000756F68: 7E1C1703
	s_or_b32 exec_lo, exec_lo, s1                              // 000000756F6C: 8C7E017E
	v_add_nc_u32_e32 v3, 0xe0, v31                             // 000000756F70: 4A063EFF 000000E0
	s_mov_b32 s1, exec_lo                                      // 000000756F78: BE81007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000756F7C: BF870001
	.long 0xd4c1007e                                           // 000000756F80: D4C1007E
	v_cndmask_b32_e32 v1, v3, v32, vcc_lo                      // 000000756F84: 02024103
	s_cbranch_execz 11                                         // 000000756F88: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi2ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x3b8>
	v_lshlrev_b32_e32 v3, 1, v3                                // 000000756F8C: 30060681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000756F90: BF8700A1
	v_ashrrev_i32_e32 v4, 31, v3                               // 000000756F94: 3408069F
	.long 0xd7006a03                                           // 000000756F98: D7006A03
	v_cndmask_b32_e32 v1, v24, v3, vcc_lo                      // 000000756F9C: 02020718
	v_add_co_ci_u32_e64 v4, null, v33, v4, vcc_lo              // 000000756FA0: D5207C04 01AA0921
	global_load_d16_b16 v3, v[3:4], off                        // 000000756FA8: DC820000 037C0003
	s_waitcnt vmcnt(0)                                         // 000000756FB0: BF8903F7
	v_cvt_f32_f16_e32 v15, v3                                  // 000000756FB4: 7E1E1703
	s_or_b32 exec_lo, exec_lo, s1                              // 000000756FB8: 8C7E017E
	s_branch 9                                                 // 000000756FBC: BFA00009 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi2ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x3e4>
	v_mov_b32_e32 v8, 0                                        // 000000756FC0: 7E100280
	s_delay_alu instid0(VALU_DEP_1)                            // 000000756FC4: BF870001
	v_mov_b32_e32 v9, v8                                       // 000000756FC8: 7E120308
	v_mov_b32_e32 v10, v8                                      // 000000756FCC: 7E140308
	v_mov_b32_e32 v11, v8                                      // 000000756FD0: 7E160308
	v_mov_b32_e32 v12, v8                                      // 000000756FD4: 7E180308
	v_mov_b32_e32 v13, v8                                      // 000000756FD8: 7E1A0308
	v_mov_b32_e32 v14, v8                                      // 000000756FDC: 7E1C0308
	v_mov_b32_e32 v15, v8                                      // 000000756FE0: 7E1E0308
	s_add_u32 s4, s4, s14                                      // 000000756FE4: 80040E04
	s_addc_u32 s5, s5, s15                                     // 000000756FE8: 82050F05
	s_lshr_b32 s1, s11, 31                                     // 000000756FEC: 85019F0B
	v_dual_mov_b32 v20, 0 :: v_dual_mov_b32 v27, 0             // 000000756FF0: CA100080 141A0080
	s_add_u32 s14, s10, s1                                     // 000000756FF8: 800E010A
	s_addc_u32 s15, s11, 0                                     // 000000756FFC: 820F800B
	.long 0xd4410001                                           // 000000757000: D4410001
	v_cndmask_b32_e32 v1, v31, v32, vcc_lo                     // 000000757004: 0202411F
	s_ashr_i64 s[14:15], s[14:15], 1                           // 000000757008: 868E810E
	v_dual_mov_b32 v34, 0 :: v_dual_mov_b32 v21, 0             // 00000075700C: CA100080 22140080
	v_mad_u64_u32 v[25:26], null, v1, s14, s[4:5]              // 000000757014: D6FE7C19 00101D01
	.long 0xd72c0001                                           // 00000075701C: D72C0001
	v_cndmask_b32_e32 v0, v1, v15, vcc_lo                      // 000000757020: 02001F01
	.long 0xd72c0002                                           // 000000757024: D72C0002
	v_cndmask_b32_e32 v0, v2, v14, vcc_lo                      // 000000757028: 02001D02
	v_cndmask_b32_e64 v35, 0, 1, s16                           // 00000075702C: D5010023 00410280
	v_dual_mov_b32 v22, 0 :: v_dual_mov_b32 v23, 0             // 000000757034: CA100080 16160080
	s_delay_alu instid0(VALU_DEP_3)                            // 00000075703C: BF870003
	v_add3_u32 v36, v2, v26, v1                                // 000000757040: D6550024 04063502
	s_and_saveexec_b32 s4, s1                                  // 000000757048: BE842001
	s_cbranch_execz 22                                         // 00000075704C: BFA50016 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi2ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x4a8>
	v_lshlrev_b32_e32 v1, 4, v31                               // 000000757050: 30023E84
	v_mov_b32_e32 v27, 0                                       // 000000757054: 7E360280
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000757058: BF8700A2
	v_ashrrev_i32_e32 v2, 31, v1                               // 00000075705C: 3404029F
	.long 0xd7006a01                                           // 000000757060: D7006A01
	v_cndmask_b32_e32 v1, v25, v1, vcc_lo                      // 000000757064: 02020319
	v_add_co_ci_u32_e64 v2, null, v36, v2, vcc_lo              // 000000757068: D5207C02 01AA0524
	s_and_not1_b32 vcc_lo, exec_lo, s16                        // 000000757070: 916A107E
	global_load_b128 v[20:23], v[1:2], off                     // 000000757074: DC5E0000 147C0001
	s_cbranch_vccnz 10                                         // 00000075707C: BFA4000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi2ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x4a8>
	v_lshlrev_b32_e32 v1, 1, v31                               // 000000757080: 30023E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000757084: BF870091
	.long 0xd7006a01                                           // 000000757088: D7006A01
	v_cndmask_b32_e32 v1, v24, v1, vcc_lo                      // 00000075708C: 02020318
	v_add_co_ci_u32_e64 v2, null, 0, v33, vcc_lo               // 000000757090: D5207C02 01AA4280
	global_load_d16_b16 v1, v[1:2], off                        // 000000757098: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 0000007570A0: BF8903F7
	v_cvt_f32_f16_e32 v27, v1                                  // 0000007570A4: 7E361701
	s_or_b32 exec_lo, exec_lo, s4                              // 0000007570A8: 8C7E047E
	v_dual_mov_b32 v38, 0 :: v_dual_mov_b32 v39, 0             // 0000007570AC: CA100080 26260080
	v_dual_mov_b32 v40, 0 :: v_dual_mov_b32 v41, 0             // 0000007570B4: CA100080 28280080
	v_mov_b32_e32 v37, 0                                       // 0000007570BC: 7E4A0280
	s_and_saveexec_b32 s14, s1                                 // 0000007570C0: BE8E2001
	s_cbranch_execz 548                                        // 0000007570C4: BFA50224 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi2ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0xd58>
	v_dual_mov_b32 v40, 0 :: v_dual_add_nc_u32 v1, 32, v31     // 0000007570C8: CA200080 28003EA0
	v_dual_mov_b32 v37, 0 :: v_dual_lshlrev_b32 v26, 5, v31    // 0000007570D0: CA220080 251A3E85
	v_dual_mov_b32 v39, 0 :: v_dual_mov_b32 v34, 0             // 0000007570D8: CA100080 27220080
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007570E0: BF870003
	v_dual_mov_b32 v41, 0 :: v_dual_lshlrev_b32 v42, 4, v1     // 0000007570E4: CA220080 292A0284
	v_dual_mov_b32 v38, 0 :: v_dual_lshlrev_b32 v43, 1, v1     // 0000007570EC: CA220080 262A0281
	v_mov_b32_e32 v44, v27                                     // 0000007570F4: 7E58031B
	s_mul_i32 s1, s11, 6                                       // 0000007570F8: 9601860B
	s_mul_hi_u32 s15, s10, 6                                   // 0000007570FC: 968F860A
	s_lshl_b64 s[4:5], s[10:11], 2                             // 000000757100: 8484820A
	s_add_i32 s15, s15, s1                                     // 000000757104: 810F010F
	s_mul_i32 s17, s10, 6                                      // 000000757108: 9611860A
	s_mov_b32 s16, 0                                           // 00000075710C: BE900080
	s_lshl_b64 s[10:11], s[10:11], 1                           // 000000757110: 848A810A
	s_branch 492                                               // 000000757114: BFA001EC <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi2ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0xcc8>
	s_or_b32 exec_lo, exec_lo, s18                             // 000000757118: 8C7E127E
	v_cndmask_b32_e64 v55, v27, v8, s0                         // 00000075711C: D5010037 0002111B
	v_cndmask_b32_e64 v2, v9, v10, s0                          // 000000757124: D5010002 00021509
	v_cndmask_b32_e64 v1, v8, v9, s0                           // 00000075712C: D5010001 00021308
	v_dual_mov_b32 v8, v15 :: v_dual_and_b32 v9, 0xff, v20     // 000000757134: CA24010F 080828FF 000000FF
	v_cndmask_b32_e64 v7, v14, v15, s0                         // 000000757140: D5010007 00021F0E
	v_cndmask_b32_e64 v6, v13, v14, s0                         // 000000757148: D5010006 00021D0D
	v_cndmask_b32_e64 v5, v12, v13, s0                         // 000000757150: D5010005 00021B0C
	v_cndmask_b32_e64 v4, v11, v12, s0                         // 000000757158: D5010004 0002190B
	v_lshlrev_b32_e32 v9, 2, v9                                // 000000757160: 30121282
	v_cndmask_b32_e64 v3, v10, v11, s0                         // 000000757164: D5010003 0002170A
	v_ashrrev_i32_e32 v27, 31, v26                             // 00000075716C: 3436349F
	s_and_b32 s1, exec_lo, s1                                  // 000000757170: 8B01017E
	v_add_nc_u32_e32 v42, 0x200, v42                           // 000000757174: 4A5454FF 00000200
	ds_load_b32 v15, v9                                        // 00000075717C: D8D80000 0F000009
	v_lshrrev_b32_e32 v9, 6, v20                               // 000000757184: 32122886
	s_or_b32 s16, s1, s16                                      // 000000757188: 8C101001
	v_add_nc_u32_e32 v43, 64, v43                              // 00000075718C: 4A5656C0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000757190: BF8700B2
	v_and_b32_e32 v9, 0x3fc, v9                                // 000000757194: 361212FF 000003FC
	ds_load_b32 v56, v9                                        // 00000075719C: D8D80000 38000009
	v_lshrrev_b32_e32 v9, 14, v20                              // 0000007571A4: 3212288E
	v_and_b32_e32 v9, 0x3fc, v9                                // 0000007571A8: 361212FF 000003FC
	ds_load_b32 v57, v9                                        // 0000007571B0: D8D80000 39000009
	v_lshrrev_b32_e32 v9, 22, v20                              // 0000007571B8: 32122896
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007571BC: BF8700B1
	v_and_b32_e32 v9, 0x3fc, v9                                // 0000007571C0: 361212FF 000003FC
	ds_load_b32 v58, v9                                        // 0000007571C8: D8D80000 3A000009
	v_and_b32_e32 v9, 0xff, v21                                // 0000007571D0: 36122AFF 000000FF
	v_lshlrev_b32_e32 v9, 2, v9                                // 0000007571D8: 30121282
	ds_load_b32 v59, v9                                        // 0000007571DC: D8D80000 3B000009
	v_lshrrev_b32_e32 v9, 6, v21                               // 0000007571E4: 32122A86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007571E8: BF8700B1
	v_and_b32_e32 v9, 0x3fc, v9                                // 0000007571EC: 361212FF 000003FC
	ds_load_b32 v60, v9                                        // 0000007571F4: D8D80000 3C000009
	v_lshrrev_b32_e32 v9, 14, v21                              // 0000007571FC: 32122A8E
	v_and_b32_e32 v9, 0x3fc, v9                                // 000000757200: 361212FF 000003FC
	ds_load_b32 v61, v9                                        // 000000757208: D8D80000 3D000009
	v_lshrrev_b32_e32 v9, 22, v21                              // 000000757210: 32122A96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000757214: BF8700B1
	v_and_b32_e32 v9, 0x3fc, v9                                // 000000757218: 361212FF 000003FC
	ds_load_b32 v62, v9                                        // 000000757220: D8D80000 3E000009
	v_and_b32_e32 v9, 0xff, v22                                // 000000757228: 36122CFF 000000FF
	v_lshlrev_b32_e32 v9, 2, v9                                // 000000757230: 30121282
	ds_load_b32 v63, v9                                        // 000000757234: D8D80000 3F000009
	v_lshrrev_b32_e32 v9, 6, v22                               // 00000075723C: 32122C86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000757240: BF8700B1
	v_and_b32_e32 v9, 0x3fc, v9                                // 000000757244: 361212FF 000003FC
	ds_load_b32 v64, v9                                        // 00000075724C: D8D80000 40000009
	v_lshrrev_b32_e32 v9, 14, v22                              // 000000757254: 32122C8E
	v_and_b32_e32 v9, 0x3fc, v9                                // 000000757258: 361212FF 000003FC
	ds_load_b32 v65, v9                                        // 000000757260: D8D80000 41000009
	v_lshrrev_b32_e32 v9, 22, v22                              // 000000757268: 32122C96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000075726C: BF8700B1
	v_and_b32_e32 v9, 0x3fc, v9                                // 000000757270: 361212FF 000003FC
	ds_load_b32 v66, v9                                        // 000000757278: D8D80000 42000009
	v_and_b32_e32 v9, 0xff, v23                                // 000000757280: 36122EFF 000000FF
	v_lshlrev_b32_e32 v9, 2, v9                                // 000000757288: 30121282
	ds_load_b32 v67, v9                                        // 00000075728C: D8D80000 43000009
	v_lshrrev_b32_e32 v9, 6, v23                               // 000000757294: 32122E86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000757298: BF8700B1
	v_and_b32_e32 v9, 0x3fc, v9                                // 00000075729C: 361212FF 000003FC
	ds_load_b32 v68, v9                                        // 0000007572A4: D8D80000 44000009
	v_lshrrev_b32_e32 v9, 14, v23                              // 0000007572AC: 32122E8E
	v_and_b32_e32 v9, 0x3fc, v9                                // 0000007572B0: 361212FF 000003FC
	ds_load_b32 v69, v9                                        // 0000007572B8: D8D80000 45000009
	v_lshrrev_b32_e32 v9, 22, v23                              // 0000007572C0: 32122E96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000007572C4: BF870141
	v_and_b32_e32 v9, 0x3fc, v9                                // 0000007572C8: 361212FF 000003FC
	ds_load_b32 v70, v9                                        // 0000007572D0: D8D80000 46000009
	.long 0xd73c0009                                           // 0000007572D8: D73C0009
	v_cndmask_b32_e32 v1, 1, v26, vcc_lo                       // 0000007572DC: 02023481
	v_dual_mov_b32 v27, v44 :: v_dual_add_nc_u32 v26, 0x400, v26// 0000007572E0: CA20012C 1B1A34FF 00000400
	.long 0xd7006a0d                                           // 0000007572EC: D7006A0D
	v_cndmask_b32_e32 v1, s6, v9, vcc_lo                       // 0000007572F0: 02021206
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007572F4: BF870001
	v_add_co_ci_u32_e64 v14, null, s7, v10, vcc_lo             // 0000007572F8: D5207C0E 01AA1407
	s_clause 0x3                                               // 000000757300: BF850003
	global_load_b128 v[9:12], v[13:14], off                    // 000000757304: DC5E0000 097C000D
	global_load_b128 v[20:23], v[13:14], off offset:16         // 00000075730C: DC5E0010 147C000D
	global_load_b128 v[45:48], v[13:14], off offset:32         // 000000757314: DC5E0020 2D7C000D
	global_load_b128 v[49:52], v[13:14], off offset:48         // 00000075731C: DC5E0030 317C000D
	s_waitcnt vmcnt(3) lgkmcnt(15)                             // 000000757324: BF890CF7
	v_dot2_f32_bf16 v9, v9, v15, 0                             // 000000757328: CC1A4009 1A021F09
	s_waitcnt lgkmcnt(14)                                      // 000000757330: BF89FCE7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000757334: BF8700A1
	v_dot2_f32_bf16 v9, v10, v56, v9                           // 000000757338: CC1A4009 1C26710A
	s_waitcnt lgkmcnt(13)                                      // 000000757340: BF89FCD7
	v_dot2_f32_bf16 v9, v11, v57, v9                           // 000000757344: CC1A4009 1C26730B
	s_waitcnt lgkmcnt(12)                                      // 00000075734C: BF89FCC7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000757350: BF8700A1
	v_dot2_f32_bf16 v9, v12, v58, v9                           // 000000757354: CC1A4009 1C26750C
	s_waitcnt vmcnt(2) lgkmcnt(11)                             // 00000075735C: BF8908B7
	v_dot2_f32_bf16 v9, v20, v59, v9                           // 000000757360: CC1A4009 1C267714
	s_waitcnt lgkmcnt(10)                                      // 000000757368: BF89FCA7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000075736C: BF8700A1
	v_dot2_f32_bf16 v9, v21, v60, v9                           // 000000757370: CC1A4009 1C267915
	s_waitcnt lgkmcnt(9)                                       // 000000757378: BF89FC97
	v_dot2_f32_bf16 v9, v22, v61, v9                           // 00000075737C: CC1A4009 1C267B16
	s_waitcnt lgkmcnt(8)                                       // 000000757384: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000757388: BF8700A1
	v_dot2_f32_bf16 v9, v23, v62, v9                           // 00000075738C: CC1A4009 1C267D17
	s_waitcnt vmcnt(1) lgkmcnt(7)                              // 000000757394: BF890477
	v_dot2_f32_bf16 v9, v45, v63, v9                           // 000000757398: CC1A4009 1C267F2D
	s_waitcnt lgkmcnt(6)                                       // 0000007573A0: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007573A4: BF8700A1
	v_dot2_f32_bf16 v9, v46, v64, v9                           // 0000007573A8: CC1A4009 1C26812E
	s_waitcnt lgkmcnt(5)                                       // 0000007573B0: BF89FC57
	v_dot2_f32_bf16 v9, v47, v65, v9                           // 0000007573B4: CC1A4009 1C26832F
	s_waitcnt lgkmcnt(4)                                       // 0000007573BC: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007573C0: BF8700A1
	v_dot2_f32_bf16 v9, v48, v66, v9                           // 0000007573C4: CC1A4009 1C268530
	s_waitcnt vmcnt(0) lgkmcnt(3)                              // 0000007573CC: BF890037
	v_dot2_f32_bf16 v9, v49, v67, v9                           // 0000007573D0: CC1A4009 1C268731
	.long 0xd7006a31                                           // 0000007573D8: D7006A31
	v_cndmask_b32_e32 v0, v13, v10, vcc_lo                     // 0000007573DC: 0200150D
	s_waitcnt lgkmcnt(2)                                       // 0000007573E0: BF89FC27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000007573E4: BF8701C2
	v_dot2_f32_bf16 v9, v50, v68, v9                           // 0000007573E8: CC1A4009 1C268932
	v_add_co_ci_u32_e64 v50, null, s11, v14, vcc_lo            // 0000007573F0: D5207C32 01AA1C0B
	.long 0xd7006a35                                           // 0000007573F8: D7006A35
	v_cndmask_b32_e32 v0, v13, v4, vcc_lo                      // 0000007573FC: 0200090D
	s_waitcnt lgkmcnt(1)                                       // 000000757400: BF89FC17
	v_dot2_f32_bf16 v9, v51, v69, v9                           // 000000757404: CC1A4009 1C268B33
	v_add_co_ci_u32_e64 v54, null, s5, v14, vcc_lo             // 00000075740C: D5207C36 01AA1C05
	.long 0xd7006a0d                                           // 000000757414: D7006A0D
	v_cndmask_b32_e32 v0, v13, v17, vcc_lo                     // 000000757418: 0200230D
	s_waitcnt lgkmcnt(0)                                       // 00000075741C: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000757420: BF870123
	v_dot2_f32_bf16 v9, v52, v70, v9                           // 000000757424: CC1A4009 1C268D34
	v_add_co_ci_u32_e64 v14, null, s15, v14, vcc_lo            // 00000075742C: D5207C0E 01AA1C0F
	v_fmac_f32_e32 v37, v55, v9                                // 000000757434: 564A1337
	s_clause 0x3                                               // 000000757438: BF850003
	global_load_b128 v[9:12], v[49:50], off                    // 00000075743C: DC5E0000 097C0031
	global_load_b128 v[20:23], v[49:50], off offset:16         // 000000757444: DC5E0010 147C0031
	global_load_b128 v[45:48], v[49:50], off offset:32         // 00000075744C: DC5E0020 2D7C0031
	global_load_b128 v[49:52], v[49:50], off offset:48         // 000000757454: DC5E0030 317C0031
	s_waitcnt vmcnt(3)                                         // 00000075745C: BF890FF7
	v_dot2_f32_bf16 v9, v9, v15, 0                             // 000000757460: CC1A4009 1A021F09
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000757468: BF870091
	v_dot2_f32_bf16 v9, v10, v56, v9                           // 00000075746C: CC1A4009 1C26710A
	v_dot2_f32_bf16 v9, v11, v57, v9                           // 000000757474: CC1A4009 1C26730B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000075747C: BF8700A1
	v_dot2_f32_bf16 v9, v12, v58, v9                           // 000000757480: CC1A4009 1C26750C
	s_waitcnt vmcnt(2)                                         // 000000757488: BF890BF7
	v_dot2_f32_bf16 v9, v20, v59, v9                           // 00000075748C: CC1A4009 1C267714
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000757494: BF870091
	v_dot2_f32_bf16 v9, v21, v60, v9                           // 000000757498: CC1A4009 1C267915
	v_dot2_f32_bf16 v9, v22, v61, v9                           // 0000007574A0: CC1A4009 1C267B16
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007574A8: BF8700A1
	v_dot2_f32_bf16 v9, v23, v62, v9                           // 0000007574AC: CC1A4009 1C267D17
	s_waitcnt vmcnt(1)                                         // 0000007574B4: BF8907F7
	v_dot2_f32_bf16 v9, v45, v63, v9                           // 0000007574B8: CC1A4009 1C267F2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007574C0: BF870091
	v_dot2_f32_bf16 v9, v46, v64, v9                           // 0000007574C4: CC1A4009 1C26812E
	v_dot2_f32_bf16 v9, v47, v65, v9                           // 0000007574CC: CC1A4009 1C26832F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007574D4: BF8700A1
	v_dot2_f32_bf16 v9, v48, v66, v9                           // 0000007574D8: CC1A4009 1C268530
	s_waitcnt vmcnt(0)                                         // 0000007574E0: BF8903F7
	v_dot2_f32_bf16 v9, v49, v67, v9                           // 0000007574E4: CC1A4009 1C268731
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007574EC: BF870091
	v_dot2_f32_bf16 v9, v50, v68, v9                           // 0000007574F0: CC1A4009 1C268932
	v_dot2_f32_bf16 v9, v51, v69, v9                           // 0000007574F8: CC1A4009 1C268B33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000757500: BF870091
	v_dot2_f32_bf16 v9, v52, v70, v9                           // 000000757504: CC1A4009 1C268D34
	v_fmac_f32_e32 v41, v55, v9                                // 00000075750C: 56521337
	s_clause 0x3                                               // 000000757510: BF850003
	global_load_b128 v[9:12], v[53:54], off                    // 000000757514: DC5E0000 097C0035
	global_load_b128 v[20:23], v[53:54], off offset:16         // 00000075751C: DC5E0010 147C0035
	global_load_b128 v[45:48], v[53:54], off offset:32         // 000000757524: DC5E0020 2D7C0035
	global_load_b128 v[49:52], v[53:54], off offset:48         // 00000075752C: DC5E0030 317C0035
	s_waitcnt vmcnt(3)                                         // 000000757534: BF890FF7
	v_dot2_f32_bf16 v9, v9, v15, 0                             // 000000757538: CC1A4009 1A021F09
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000757540: BF870091
	v_dot2_f32_bf16 v9, v10, v56, v9                           // 000000757544: CC1A4009 1C26710A
	v_dot2_f32_bf16 v9, v11, v57, v9                           // 00000075754C: CC1A4009 1C26730B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000757554: BF8700A1
	v_dot2_f32_bf16 v9, v12, v58, v9                           // 000000757558: CC1A4009 1C26750C
	s_waitcnt vmcnt(2)                                         // 000000757560: BF890BF7
	v_dot2_f32_bf16 v9, v20, v59, v9                           // 000000757564: CC1A4009 1C267714
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000075756C: BF870091
	v_dot2_f32_bf16 v9, v21, v60, v9                           // 000000757570: CC1A4009 1C267915
	v_dot2_f32_bf16 v9, v22, v61, v9                           // 000000757578: CC1A4009 1C267B16
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000757580: BF8700A1
	v_dot2_f32_bf16 v9, v23, v62, v9                           // 000000757584: CC1A4009 1C267D17
	s_waitcnt vmcnt(1)                                         // 00000075758C: BF8907F7
	v_dot2_f32_bf16 v9, v45, v63, v9                           // 000000757590: CC1A4009 1C267F2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000757598: BF870091
	v_dot2_f32_bf16 v9, v46, v64, v9                           // 00000075759C: CC1A4009 1C26812E
	v_dot2_f32_bf16 v9, v47, v65, v9                           // 0000007575A4: CC1A4009 1C26832F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007575AC: BF8700A1
	v_dot2_f32_bf16 v9, v48, v66, v9                           // 0000007575B0: CC1A4009 1C268530
	s_waitcnt vmcnt(0)                                         // 0000007575B8: BF8903F7
	v_dot2_f32_bf16 v9, v49, v67, v9                           // 0000007575BC: CC1A4009 1C268731
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007575C4: BF870091
	v_dot2_f32_bf16 v9, v50, v68, v9                           // 0000007575C8: CC1A4009 1C268932
	v_dot2_f32_bf16 v9, v51, v69, v9                           // 0000007575D0: CC1A4009 1C268B33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007575D8: BF870091
	v_dot2_f32_bf16 v9, v52, v70, v9                           // 0000007575DC: CC1A4009 1C268D34
	v_fmac_f32_e32 v40, v55, v9                                // 0000007575E4: 56501337
	s_clause 0x3                                               // 0000007575E8: BF850003
	global_load_b128 v[9:12], v[13:14], off                    // 0000007575EC: DC5E0000 097C000D
	global_load_b128 v[20:23], v[13:14], off offset:16         // 0000007575F4: DC5E0010 147C000D
	global_load_b128 v[45:48], v[13:14], off offset:32         // 0000007575FC: DC5E0020 2D7C000D
	global_load_b128 v[49:52], v[13:14], off offset:48         // 000000757604: DC5E0030 317C000D
	s_waitcnt vmcnt(3)                                         // 00000075760C: BF890FF7
	v_dot2_f32_bf16 v9, v9, v15, 0                             // 000000757610: CC1A4009 1A021F09
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000757618: BF870091
	v_dot2_f32_bf16 v9, v10, v56, v9                           // 00000075761C: CC1A4009 1C26710A
	v_dot2_f32_bf16 v9, v11, v57, v9                           // 000000757624: CC1A4009 1C26730B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000075762C: BF8700A1
	v_dot2_f32_bf16 v9, v12, v58, v9                           // 000000757630: CC1A4009 1C26750C
	s_waitcnt vmcnt(2)                                         // 000000757638: BF890BF7
	v_dot2_f32_bf16 v9, v20, v59, v9                           // 00000075763C: CC1A4009 1C267714
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000757644: BF870091
	v_dot2_f32_bf16 v9, v21, v60, v9                           // 000000757648: CC1A4009 1C267915
	v_dot2_f32_bf16 v9, v22, v61, v9                           // 000000757650: CC1A4009 1C267B16
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000757658: BF8700A1
	v_dot2_f32_bf16 v9, v23, v62, v9                           // 00000075765C: CC1A4009 1C267D17
	s_waitcnt vmcnt(1)                                         // 000000757664: BF8907F7
	v_dot2_f32_bf16 v9, v45, v63, v9                           // 000000757668: CC1A4009 1C267F2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000757670: BF870091
	v_dot2_f32_bf16 v9, v46, v64, v9                           // 000000757674: CC1A4009 1C26812E
	v_dot2_f32_bf16 v9, v47, v65, v9                           // 00000075767C: CC1A4009 1C26832F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000757684: BF8700A1
	v_dot2_f32_bf16 v9, v48, v66, v9                           // 000000757688: CC1A4009 1C268530
	s_waitcnt vmcnt(0)                                         // 000000757690: BF8903F7
	v_dot2_f32_bf16 v9, v49, v67, v9                           // 000000757694: CC1A4009 1C268731
	.long 0xd7006a31                                           // 00000075769C: D7006A31
	v_cndmask_b32_e32 v0, v53, v4, vcc_lo                      // 0000007576A0: 02000935
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000007576A4: BF8701B2
	v_dot2_f32_bf16 v9, v50, v68, v9                           // 0000007576A8: CC1A4009 1C268932
	v_add_co_ci_u32_e64 v50, null, s5, v54, vcc_lo             // 0000007576B0: D5207C32 01AA6C05
	.long 0xd7006a0d                                           // 0000007576B8: D7006A0D
	v_cndmask_b32_e32 v0, v13, v4, vcc_lo                      // 0000007576BC: 0200090D
	v_dot2_f32_bf16 v9, v51, v69, v9                           // 0000007576C0: CC1A4009 1C268B33
	v_add_co_ci_u32_e64 v14, null, s5, v14, vcc_lo             // 0000007576C8: D5207C0E 01AA1C05
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007576D0: BF870092
	v_dot2_f32_bf16 v9, v52, v70, v9                           // 0000007576D4: CC1A4009 1C268D34
	v_fmac_f32_e32 v39, v55, v9                                // 0000007576DC: 564E1337
	s_clause 0x3                                               // 0000007576E0: BF850003
	global_load_b128 v[9:12], v[49:50], off                    // 0000007576E4: DC5E0000 097C0031
	global_load_b128 v[20:23], v[49:50], off offset:16         // 0000007576EC: DC5E0010 147C0031
	global_load_b128 v[45:48], v[49:50], off offset:32         // 0000007576F4: DC5E0020 2D7C0031
	global_load_b128 v[49:52], v[49:50], off offset:48         // 0000007576FC: DC5E0030 317C0031
	s_waitcnt vmcnt(3)                                         // 000000757704: BF890FF7
	v_dot2_f32_bf16 v9, v9, v15, 0                             // 000000757708: CC1A4009 1A021F09
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000757710: BF870091
	v_dot2_f32_bf16 v9, v10, v56, v9                           // 000000757714: CC1A4009 1C26710A
	v_dot2_f32_bf16 v9, v11, v57, v9                           // 00000075771C: CC1A4009 1C26730B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000757724: BF8700A1
	v_dot2_f32_bf16 v9, v12, v58, v9                           // 000000757728: CC1A4009 1C26750C
	s_waitcnt vmcnt(2)                                         // 000000757730: BF890BF7
	v_dot2_f32_bf16 v9, v20, v59, v9                           // 000000757734: CC1A4009 1C267714
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000075773C: BF870091
	v_dot2_f32_bf16 v9, v21, v60, v9                           // 000000757740: CC1A4009 1C267915
	v_dot2_f32_bf16 v9, v22, v61, v9                           // 000000757748: CC1A4009 1C267B16
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000757750: BF8700A1
	v_dot2_f32_bf16 v9, v23, v62, v9                           // 000000757754: CC1A4009 1C267D17
	s_waitcnt vmcnt(1)                                         // 00000075775C: BF8907F7
	v_dot2_f32_bf16 v9, v45, v63, v9                           // 000000757760: CC1A4009 1C267F2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000757768: BF870091
	v_dot2_f32_bf16 v9, v46, v64, v9                           // 00000075776C: CC1A4009 1C26812E
	v_dot2_f32_bf16 v9, v47, v65, v9                           // 000000757774: CC1A4009 1C26832F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000075777C: BF8700A1
	v_dot2_f32_bf16 v9, v48, v66, v9                           // 000000757780: CC1A4009 1C268530
	s_waitcnt vmcnt(0)                                         // 000000757788: BF8903F7
	v_dot2_f32_bf16 v9, v49, v67, v9                           // 00000075778C: CC1A4009 1C268731
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000757794: BF870091
	v_dot2_f32_bf16 v9, v50, v68, v9                           // 000000757798: CC1A4009 1C268932
	v_dot2_f32_bf16 v9, v51, v69, v9                           // 0000007577A0: CC1A4009 1C268B33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007577A8: BF870091
	v_dot2_f32_bf16 v9, v52, v70, v9                           // 0000007577AC: CC1A4009 1C268D34
	v_fmac_f32_e32 v38, v55, v9                                // 0000007577B4: 564C1337
	s_clause 0x3                                               // 0000007577B8: BF850003
	global_load_b128 v[9:12], v[13:14], off                    // 0000007577BC: DC5E0000 097C000D
	global_load_b128 v[20:23], v[13:14], off offset:16         // 0000007577C4: DC5E0010 147C000D
	global_load_b128 v[45:48], v[13:14], off offset:32         // 0000007577CC: DC5E0020 2D7C000D
	global_load_b128 v[49:52], v[13:14], off offset:48         // 0000007577D4: DC5E0030 317C000D
	s_waitcnt vmcnt(3)                                         // 0000007577DC: BF890FF7
	v_dot2_f32_bf16 v9, v9, v15, 0                             // 0000007577E0: CC1A4009 1A021F09
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007577E8: BF870091
	v_dot2_f32_bf16 v9, v10, v56, v9                           // 0000007577EC: CC1A4009 1C26710A
	v_dot2_f32_bf16 v9, v11, v57, v9                           // 0000007577F4: CC1A4009 1C26730B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007577FC: BF8700A1
	v_dot2_f32_bf16 v9, v12, v58, v9                           // 000000757800: CC1A4009 1C26750C
	s_waitcnt vmcnt(2)                                         // 000000757808: BF890BF7
	v_dot2_f32_bf16 v9, v20, v59, v9                           // 00000075780C: CC1A4009 1C267714
	v_mov_b32_e32 v20, v16                                     // 000000757814: 7E280310
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000757818: BF870122
	v_dot2_f32_bf16 v9, v21, v60, v9                           // 00000075781C: CC1A4009 1C267915
	v_mov_b32_e32 v21, v17                                     // 000000757824: 7E2A0311
	v_dot2_f32_bf16 v9, v22, v61, v9                           // 000000757828: CC1A4009 1C267B16
	v_mov_b32_e32 v22, v18                                     // 000000757830: 7E2C0312
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000757834: BF870132
	v_dot2_f32_bf16 v9, v23, v62, v9                           // 000000757838: CC1A4009 1C267D17
	v_mov_b32_e32 v23, v19                                     // 000000757840: 7E2E0313
	s_waitcnt vmcnt(1)                                         // 000000757844: BF8907F7
	v_dot2_f32_bf16 v9, v45, v63, v9                           // 000000757848: CC1A4009 1C267F2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000757850: BF870091
	v_dot2_f32_bf16 v9, v46, v64, v9                           // 000000757854: CC1A4009 1C26812E
	v_dot2_f32_bf16 v9, v47, v65, v9                           // 00000075785C: CC1A4009 1C26832F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000757864: BF8700A1
	v_dot2_f32_bf16 v9, v48, v66, v9                           // 000000757868: CC1A4009 1C268530
	s_waitcnt vmcnt(0)                                         // 000000757870: BF8903F7
	v_dot2_f32_bf16 v9, v49, v67, v9                           // 000000757874: CC1A4009 1C268731
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000075787C: BF870091
	v_dot2_f32_bf16 v9, v50, v68, v9                           // 000000757880: CC1A4009 1C268932
	v_dot2_f32_bf16 v9, v51, v69, v9                           // 000000757888: CC1A4009 1C268B33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000757890: BF870091
	v_dot2_f32_bf16 v9, v52, v70, v9                           // 000000757894: CC1A4009 1C268D34
	v_dual_fmac_f32 v34, v55, v9 :: v_dual_mov_b32 v15, v8     // 00000075789C: C8101337 220E0108
	v_dual_mov_b32 v14, v7 :: v_dual_mov_b32 v13, v6           // 0000007578A4: CA100107 0E0C0106
	v_dual_mov_b32 v12, v5 :: v_dual_mov_b32 v11, v4           // 0000007578AC: CA100105 0C0A0104
	v_dual_mov_b32 v10, v3 :: v_dual_mov_b32 v9, v2            // 0000007578B4: CA100103 0A080102
	v_mov_b32_e32 v8, v1                                       // 0000007578BC: 7E100301
	s_and_not1_b32 exec_lo, exec_lo, s16                       // 0000007578C0: 917E107E
	s_cbranch_execz 35                                         // 0000007578C4: BFA50023 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi2ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0xd54>
	s_waitcnt vmcnt(0)                                         // 0000007578C8: BF8903F7
	v_dual_mov_b32 v16, v20 :: v_dual_add_nc_u32 v31, 32, v31  // 0000007578CC: CA200114 101E3EA0
	v_dual_mov_b32 v17, v21 :: v_dual_mov_b32 v18, v22         // 0000007578D4: CA100115 11120116
	v_mov_b32_e32 v19, v23                                     // 0000007578DC: 7E260317
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007578E0: BF870003
	.long 0xd4460001                                           // 0000007578E4: D4460001
	v_cndmask_b32_e32 v1, v31, v32, vcc_lo                     // 0000007578E8: 0202411F
	s_mov_b32 s18, exec_lo                                     // 0000007578EC: BE92007E
	.long 0xd4c1007e                                           // 0000007578F0: D4C1007E
	v_cndmask_b32_e32 v1, v31, v32, vcc_lo                     // 0000007578F4: 0202411F
	s_cbranch_execz 65031                                      // 0000007578F8: BFA5FE07 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi2ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x518>
	v_ashrrev_i32_e32 v2, 31, v42                              // 0000007578FC: 3404549F
	.long 0xd7006a01                                           // 000000757900: D7006A01
	v_cndmask_b32_e32 v1, v25, v42, vcc_lo                     // 000000757904: 02025519
	v_mov_b32_e32 v44, v27                                     // 000000757908: 7E58031B
	s_delay_alu instid0(VALU_DEP_3)                            // 00000075790C: BF870003
	v_add_co_ci_u32_e64 v2, null, v36, v2, vcc_lo              // 000000757910: D5207C02 01AA0524
	v_cmp_ne_u32_e32 vcc_lo, 1, v35                            // 000000757918: 7C9A4681
	global_load_b128 v[16:19], v[1:2], off                     // 00000075791C: DC5E0000 107C0001
	s_cbranch_vccnz 65020                                      // 000000757924: BFA4FDFC <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi2ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x518>
	v_ashrrev_i32_e32 v2, 31, v43                              // 000000757928: 3404569F
	.long 0xd7006a01                                           // 00000075792C: D7006A01
	v_cndmask_b32_e32 v1, v24, v43, vcc_lo                     // 000000757930: 02025718
	s_delay_alu instid0(VALU_DEP_1)                            // 000000757934: BF870001
	v_add_co_ci_u32_e64 v2, null, v33, v2, vcc_lo              // 000000757938: D5207C02 01AA0521
	global_load_d16_b16 v1, v[1:2], off                        // 000000757940: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 000000757948: BF8903F7
	v_cvt_f32_f16_e32 v44, v1                                  // 00000075794C: 7E581701
	s_branch 65009                                             // 000000757950: BFA0FDF1 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi2ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x518>
	s_or_b32 exec_lo, exec_lo, s16                             // 000000757954: 8C7E107E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000757958: BF8700B9
	s_or_b32 exec_lo, exec_lo, s14                             // 00000075795C: 8C7E0E7E
	.long 0xd71f0001                                           // 000000757960: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 000000757964: 020100C1
	s_mov_b32 s0, exec_lo                                      // 000000757968: BE80007E
	v_xor_b32_e32 v2, 16, v1                                   // 00000075796C: 3A040290
	v_xor_b32_e32 v8, 8, v1                                    // 000000757970: 3A100288
	v_xor_b32_e32 v14, 4, v1                                   // 000000757974: 3A1C0284
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000757978: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 00000075797C: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 000000757980: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v8                            // 000000757984: 7C9810A0
	s_delay_alu instid0(VALU_DEP_2)                            // 000000757988: BF870002
	v_lshlrev_b32_e32 v2, 2, v2                                // 00000075798C: 30040482
	ds_bpermute_b32 v3, v2, v37                                // 000000757990: DACC0000 03002502
	s_waitcnt lgkmcnt(0)                                       // 000000757998: BF89FC07
	v_add_f32_e32 v3, v37, v3                                  // 00000075799C: 06060725
	ds_bpermute_b32 v7, v2, v38                                // 0000007579A0: DACC0000 07002602
	v_cndmask_b32_e32 v8, v1, v8, vcc_lo                       // 0000007579A8: 02101101
	ds_bpermute_b32 v5, v2, v40                                // 0000007579AC: DACC0000 05002802
	ds_bpermute_b32 v6, v2, v39                                // 0000007579B4: DACC0000 06002702
	ds_bpermute_b32 v4, v2, v41                                // 0000007579BC: DACC0000 04002902
	ds_bpermute_b32 v2, v2, v34                                // 0000007579C4: DACC0000 02002202
	v_cmp_gt_u32_e32 vcc_lo, 32, v14                           // 0000007579CC: 7C981CA0
	s_waitcnt lgkmcnt(4)                                       // 0000007579D0: BF89FC47
	v_dual_add_f32 v7, v38, v7 :: v_dual_lshlrev_b32 v8, 2, v8 // 0000007579D4: C9220F26 07081082
	s_waitcnt lgkmcnt(3)                                       // 0000007579DC: BF89FC37
	v_add_f32_e32 v5, v40, v5                                  // 0000007579E0: 060A0B28
	ds_bpermute_b32 v9, v8, v3                                 // 0000007579E4: DACC0000 09000308
	s_waitcnt lgkmcnt(0)                                       // 0000007579EC: BF89FC07
	v_add_f32_e32 v3, v3, v9                                   // 0000007579F0: 06061303
	ds_bpermute_b32 v11, v8, v5                                // 0000007579F4: DACC0000 0B000508
	ds_bpermute_b32 v13, v8, v7                                // 0000007579FC: DACC0000 0D000708
	v_add_f32_e32 v6, v39, v6                                  // 000000757A04: 060C0D27
	v_add_f32_e32 v4, v41, v4                                  // 000000757A08: 06080929
	s_waitcnt lgkmcnt(1)                                       // 000000757A0C: BF89FC17
	v_dual_add_f32 v2, v34, v2 :: v_dual_add_f32 v5, v5, v11   // 000000757A10: C9080522 02041705
	ds_bpermute_b32 v12, v8, v6                                // 000000757A18: DACC0000 0C000608
	s_waitcnt lgkmcnt(1)                                       // 000000757A20: BF89FC17
	v_dual_add_f32 v7, v7, v13 :: v_dual_cndmask_b32 v14, v1, v14// 000000757A24: C9121B07 070E1D01
	ds_bpermute_b32 v10, v8, v4                                // 000000757A2C: DACC0000 0A000408
	ds_bpermute_b32 v8, v8, v2                                 // 000000757A34: DACC0000 08000208
	v_lshlrev_b32_e32 v14, 2, v14                              // 000000757A3C: 301C1C82
	s_waitcnt lgkmcnt(2)                                       // 000000757A40: BF89FC27
	v_add_f32_e32 v6, v6, v12                                  // 000000757A44: 060C1906
	ds_bpermute_b32 v12, v14, v7                               // 000000757A48: DACC0000 0C00070E
	s_waitcnt lgkmcnt(1)                                       // 000000757A50: BF89FC17
	v_add_f32_e32 v2, v2, v8                                   // 000000757A54: 06041102
	ds_bpermute_b32 v8, v14, v3                                // 000000757A58: DACC0000 0800030E
	ds_bpermute_b32 v13, v14, v2                               // 000000757A60: DACC0000 0D00020E
	s_waitcnt lgkmcnt(2)                                       // 000000757A68: BF89FC27
	v_dual_add_f32 v7, v7, v12 :: v_dual_add_f32 v4, v4, v10   // 000000757A6C: C9081907 07041504
	ds_bpermute_b32 v10, v14, v5                               // 000000757A74: DACC0000 0A00050E
	s_waitcnt lgkmcnt(2)                                       // 000000757A7C: BF89FC27
	v_add_f32_e32 v3, v3, v8                                   // 000000757A80: 06061103
	ds_bpermute_b32 v9, v14, v4                                // 000000757A84: DACC0000 0900040E
	s_waitcnt lgkmcnt(1)                                       // 000000757A8C: BF89FC17
	v_dual_add_f32 v8, v2, v13 :: v_dual_add_f32 v5, v5, v10   // 000000757A90: C9081B02 08041505
	ds_bpermute_b32 v11, v14, v6                               // 000000757A98: DACC0000 0B00060E
	v_xor_b32_e32 v14, 2, v1                                   // 000000757AA0: 3A1C0282
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000757AA4: BF8700A1
	v_cmp_gt_u32_e32 vcc_lo, 32, v14                           // 000000757AA8: 7C981CA0
	v_cndmask_b32_e32 v14, v1, v14, vcc_lo                     // 000000757AAC: 021C1D01
	v_lshlrev_b32_e32 v14, 2, v14                              // 000000757AB0: 301C1C82
	s_waitcnt lgkmcnt(0)                                       // 000000757AB4: BF89FC07
	v_add_f32_e32 v6, v6, v11                                  // 000000757AB8: 060C1706
	ds_bpermute_b32 v2, v14, v3                                // 000000757ABC: DACC0000 0200030E
	v_add_f32_e32 v4, v4, v9                                   // 000000757AC4: 06081304
	ds_bpermute_b32 v10, v14, v5                               // 000000757AC8: DACC0000 0A00050E
	ds_bpermute_b32 v12, v14, v7                               // 000000757AD0: DACC0000 0C00070E
	ds_bpermute_b32 v11, v14, v6                               // 000000757AD8: DACC0000 0B00060E
	ds_bpermute_b32 v13, v14, v8                               // 000000757AE0: DACC0000 0D00080E
	ds_bpermute_b32 v9, v14, v4                                // 000000757AE8: DACC0000 0900040E
	v_xor_b32_e32 v14, 1, v1                                   // 000000757AF0: 3A1C0281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000757AF4: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v14                           // 000000757AF8: 7C981CA0
	v_cndmask_b32_e32 v1, v1, v14, vcc_lo                      // 000000757AFC: 02021D01
	s_waitcnt lgkmcnt(5)                                       // 000000757B00: BF89FC57
	v_dual_add_f32 v1, v3, v2 :: v_dual_lshlrev_b32 v14, 2, v1 // 000000757B04: C9220503 010E0282
	s_waitcnt lgkmcnt(0)                                       // 000000757B0C: BF89FC07
	v_dual_add_f32 v3, v7, v12 :: v_dual_add_f32 v2, v4, v9    // 000000757B10: C9081907 03021304
	v_dual_add_f32 v4, v5, v10 :: v_dual_add_f32 v5, v6, v11   // 000000757B18: C9081505 04041706
	v_add_f32_e32 v9, v8, v13                                  // 000000757B20: 06121B08
	ds_bpermute_b32 v6, v14, v1                                // 000000757B24: DACC0000 0600010E
	ds_bpermute_b32 v7, v14, v2                                // 000000757B2C: DACC0000 0700020E
	ds_bpermute_b32 v10, v14, v4                               // 000000757B34: DACC0000 0A00040E
	ds_bpermute_b32 v11, v14, v5                               // 000000757B3C: DACC0000 0B00050E
	ds_bpermute_b32 v8, v14, v3                                // 000000757B44: DACC0000 0800030E
	ds_bpermute_b32 v12, v14, v9                               // 000000757B4C: DACC0000 0C00090E
	v_cmpx_eq_u32_e32 0, v30                                   // 000000757B54: 7D943C80
	s_cbranch_execz 16                                         // 000000757B58: BFA50010 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi2ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0xf9c>
	.long 0xd72c000d                                           // 000000757B5C: D72C000D
	v_cndmask_b32_e32 v0, v28, v176, vcc_lo                    // 000000757B60: 0201611C
	s_waitcnt lgkmcnt(0)                                       // 000000757B64: BF89FC07
	v_dual_add_f32 v9, v9, v12 :: v_dual_add_f32 v4, v4, v10   // 000000757B68: C9081909 09041504
	v_dual_add_f32 v5, v5, v11 :: v_dual_add_f32 v8, v3, v8    // 000000757B70: C9081705 05081103
	v_dual_add_f32 v2, v2, v7 :: v_dual_add_f32 v1, v1, v6     // 000000757B78: C9080F02 02000D01
	s_delay_alu instid0(VALU_DEP_4)                            // 000000757B80: BF870004
	v_mad_u32_u24 v6, v29, 24, v13                             // 000000757B84: D60B0006 0435311D
	ds_store_2addr_b64 v6, v[1:2], v[4:5] offset0:128 offset1:129// 000000757B8C: D9388180 00040106
	ds_store_b64 v6, v[8:9] offset:1040                        // 000000757B94: D9340410 00000806
	s_or_b32 exec_lo, exec_lo, s0                              // 000000757B9C: 8C7E007E
	.long 0xd7050001                                           // 000000757BA0: D7050001
	v_cndmask_b32_e32 v1, 0xab, v0, vcc_lo                     // 000000757BA4: 020200FF 000000AB
	.long 0x7f063880                                           // 000000757BAC: 7F063880
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000757BB0: BF890007
	s_barrier                                                  // 000000757BB4: BFBD0000
	buffer_gl0_inv                                             // 000000757BB8: E0AC0000 00000000
	.long 0xd7390003                                           // 000000757BC0: D7390003
	v_cndmask_b32_e32 v1, 10, v1, vcc_lo                       // 000000757BC4: 0202028A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000757BC8: BF870091
	.long 0xd7000001                                           // 000000757BCC: D7000001
	v_cndmask_b32_e32 v1, s2, v3, vcc_lo                       // 000000757BD0: 02020602
	v_add_co_ci_u32_e64 v2, null, s3, 0, s0                    // 000000757BD4: D5207C02 00010003
	.long 0xd44c0000                                           // 000000757BDC: D44C0000
	v_cndmask_b32_e32 v1, 24, v0, vcc_lo                       // 000000757BE0: 02020098
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000757BE4: BF8704A2
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[1:2]                  // 000000757BE8: 7CA8020C
	s_and_b32 s0, s0, vcc_lo                                   // 000000757BEC: 8B006A00
	s_and_saveexec_b32 s1, s0                                  // 000000757BF0: BE812000
	s_cbranch_execz 39                                         // 000000757BF4: BFA50027 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi2ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x1094>
	.long 0xd7054000                                           // 000000757BF8: D7054000
	v_cndmask_b32_e32 v0, v3, v134, vcc_lo                     // 000000757BFC: 02010D03
	v_mul_u32_u24_e32 v3, 48, v3                               // 000000757C00: 160606B0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000757C04: BF870092
	.long 0xd7041000                                           // 000000757C08: D7041000
	v_cndmask_b32_e32 v1, v0, v0, vcc_lo                       // 000000757C0C: 02020100
	v_and_b32_e32 v0, 0xff, v0                                 // 000000757C10: 360000FF 000000FF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000757C18: BF870091
	v_lshl_add_u32 v3, v0, 2, v3                               // 000000757C1C: D6460003 040D0500
	v_add_nc_u32_e32 v5, 0x400, v3                             // 000000757C24: 4A0A06FF 00000400
	v_mad_u64_u32 v[3:4], null, s12, v0, 0                     // 000000757C2C: D6FE7C03 0202000C
	ds_load_2addr_b32 v[6:7], v5 offset1:6                     // 000000757C34: D8DC0600 06000005
	v_mad_u64_u32 v[4:5], null, s13, v0, v[4:5]                // 000000757C3C: D6FE7C04 0412000D
	.long 0xd73c0000                                           // 000000757C44: D73C0000
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 000000757C48: 02020282
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000757C4C: BF870092
	.long 0xd73c0003                                           // 000000757C50: D73C0003
	v_cndmask_b32_e32 v1, 2, v3, vcc_lo                        // 000000757C54: 02020682
	.long 0xd7006a03                                           // 000000757C58: D7006A03
	v_cndmask_b32_e32 v1, s8, v3, vcc_lo                       // 000000757C5C: 02020608
	s_waitcnt lgkmcnt(0)                                       // 000000757C60: BF89FC07
	v_add_f32_e32 v2, 0, v6                                    // 000000757C64: 06040C80
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000757C68: BF870193
	v_add_co_ci_u32_e64 v4, null, s9, v4, vcc_lo               // 000000757C6C: D5207C04 01AA0809
	.long 0xd7006a00                                           // 000000757C74: D7006A00
	v_cndmask_b32_e32 v1, v3, v0, vcc_lo                       // 000000757C78: 02020103
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000757C7C: BF870193
	v_add_f32_e32 v2, v2, v7                                   // 000000757C80: 06040F02
	v_add_co_ci_u32_e64 v1, null, v4, v1, vcc_lo               // 000000757C84: D5207C01 01AA0304
	global_store_b32 v[0:1], v2, off                           // 000000757C8C: DC6A0000 007C0200
	s_endpgm                                                   // 000000757C94: BFB00000
		...

