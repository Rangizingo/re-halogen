000000000034db00 <_ZN7halogen12_GLOBAL__N_16k_lq6wILi7ELi16ELi1EEEvPKhPKtPtll>:
; _ZN7halogen12_GLOBAL__N_16k_lq6wILi7ELi16ELi1EEEvPKhPKtPtll():
	s_load_b256 s[4:11], s[0:1], null                          // 00000034DB00: F40C0100 F8000000
	s_mov_b32 s3, 0                                            // 00000034DB08: BE830080
	v_lshrrev_b32_e32 v1, 4, v0                                // 00000034DB0C: 32020084
	s_lshl_b64 s[12:13], s[2:3], 4                             // 00000034DB10: 848C8402
	s_load_b64 s[2:3], s[0:1], 0x20                            // 00000034DB14: F4040080 F8000020
	v_mov_b32_e32 v9, s13                                      // 00000034DB1C: 7E12020D
	v_dual_mov_b32 v6, 0 :: v_dual_and_b32 v17, 15, v0         // 00000034DB20: CA240080 0610008F
	v_or_b32_e32 v8, s12, v1                                   // 00000034DB28: 3810020C
	v_dual_mov_b32 v4, 0 :: v_dual_mov_b32 v5, 0               // 00000034DB2C: CA100080 04040080
	v_dual_mov_b32 v7, 0 :: v_dual_mov_b32 v16, 0              // 00000034DB34: CA100080 07100080
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(SALU_CYCLE_1)// 00000034DB3C: BF8704D3
	.long 0xd73c0001                                           // 00000034DB40: D73C0001
	v_cndmask_b32_e32 v1, 4, v8, vcc_lo                        // 00000034DB44: 02021084
	v_dual_mov_b32 v15, 0 :: v_dual_mov_b32 v46, 0             // 00000034DB48: CA100080 0F2E0080
	v_mov_b32_e32 v18, 0                                       // 00000034DB50: 7E240280
	s_waitcnt lgkmcnt(0)                                       // 00000034DB54: BF89FC07
	s_ashr_i32 s16, s11, 31                                    // 00000034DB58: 86109F0B
	s_lshr_b32 s0, s16, 27                                     // 00000034DB5C: 85009B10
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000034DB60: BF870009
	s_add_u32 s0, s10, s0                                      // 00000034DB64: 8000000A
	s_addc_u32 s1, s11, 0                                      // 00000034DB68: 8201800B
	s_lshr_b32 s14, s11, 31                                    // 00000034DB6C: 850E9F0B
	s_lshr_b64 s[12:13], s[0:1], 5                             // 00000034DB70: 858C8500
	s_add_u32 s0, s10, s14                                     // 00000034DB74: 80000E0A
	s_addc_u32 s1, s11, 0                                      // 00000034DB78: 8201800B
	s_lshr_b32 s13, s16, 30                                    // 00000034DB7C: 850D9E10
	s_ashr_i64 s[14:15], s[0:1], 1                             // 00000034DB80: 868E8100
	s_add_u32 s0, s10, s13                                     // 00000034DB84: 80000D0A
	s_addc_u32 s1, s11, 0                                      // 00000034DB88: 8201800B
	s_lshr_b32 s13, s16, 28                                    // 00000034DB8C: 850D9C10
	s_ashr_i64 s[16:17], s[0:1], 2                             // 00000034DB90: 86908200
	s_add_u32 s0, s10, s13                                     // 00000034DB94: 80000D0A
	s_addc_u32 s1, s11, 0                                      // 00000034DB98: 8201800B
	v_cmp_gt_i64_e32 vcc_lo, s[2:3], v[8:9]                    // 00000034DB9C: 7CA81002
	s_ashr_i64 s[0:1], s[0:1], 4                               // 00000034DBA0: 86808400
	s_add_u32 s13, s16, s14                                    // 00000034DBA4: 800D0E10
	s_addc_u32 s18, s17, s15                                   // 00000034DBA8: 82120F11
	s_add_u32 s0, s13, s0                                      // 00000034DBAC: 8000000D
	s_addc_u32 s1, s18, s1                                     // 00000034DBB0: 82010112
	s_add_u32 s0, s0, 15                                       // 00000034DBB4: 80008F00
	s_addc_u32 s1, s1, 0                                       // 00000034DBB8: 82018001
	v_cndmask_b32_e32 v2, 0, v2, vcc_lo                        // 00000034DBBC: 02040480
	s_ashr_i32 s13, s1, 31                                     // 00000034DBC0: 860D9F01
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 00000034DBC4: 02020280
	s_lshr_b32 s13, s13, 28                                    // 00000034DBC8: 850D9C0D
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000034DBCC: BF8704A9
	s_add_u32 s0, s0, s13                                      // 00000034DBD0: 80000D00
	s_addc_u32 s1, s1, 0                                       // 00000034DBD4: 82018001
	s_ashr_i64 s[0:1], s[0:1], 4                               // 00000034DBD8: 86808400
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 00000034DBDC: BF870149
	.long 0xd72c0003                                           // 00000034DBE0: D72C0003
	v_cndmask_b32_e32 v0, v1, v1, vcc_lo                       // 00000034DBE4: 02000301
	.long 0xd72c0002                                           // 00000034DBE8: D72C0002
	v_cndmask_b32_e32 v0, v2, v0, vcc_lo                       // 00000034DBEC: 02000102
	v_mad_u64_u32 v[10:11], null, v1, s0, s[4:5]               // 00000034DBF0: D6FE7C0A 00100101
	.long 0xd4440000                                           // 00000034DBF8: D4440000
	v_cndmask_b32_e32 v1, s12, v17, vcc_lo                     // 00000034DBFC: 0202220C
	v_add3_u32 v19, v2, v11, v3                                // 00000034DC00: D6550013 040E1702
	s_and_saveexec_b32 s4, s0                                  // 00000034DC08: BE842000
	s_cbranch_execz 35                                         // 00000034DC0C: BFA50023 <_ZN7halogen12_GLOBAL__N_16k_lq6wILi7ELi16ELi1EEEvPKhPKtPtll+0x19c>
	v_lshlrev_b32_e32 v1, 4, v17                               // 00000034DC10: 30022284
	v_lshlrev_b32_e32 v0, 1, v0                                // 00000034DC14: 30000081
	v_lshlrev_b32_e32 v5, 3, v17                               // 00000034DC18: 300A2283
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034DC1C: BF870093
	.long 0xd7000101                                           // 00000034DC20: D7000101
	v_cndmask_b32_e32 v1, v10, v1, vcc_lo                      // 00000034DC24: 0202030A
	v_add_co_ci_u32_e64 v2, null, 0, v19, s1                   // 00000034DC28: D5207C02 00062680
	.long 0xd7000103                                           // 00000034DC30: D7000103
	v_cndmask_b32_e32 v0, v10, v14, vcc_lo                     // 00000034DC34: 02001D0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000034DC38: BF8701A1
	v_add_co_ci_u32_e64 v4, null, s15, v19, s1                 // 00000034DC3C: D5207C04 0006260F
	v_and_b32_e32 v0, 28, v0                                   // 00000034DC44: 3600009C
	.long 0xd7000106                                           // 00000034DC48: D7000106
	v_cndmask_b32_e32 v0, v3, v16, vcc_lo                      // 00000034DC4C: 02002103
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000034DC50: BF8700A1
	v_add_co_ci_u32_e64 v7, null, s17, v4, s1                  // 00000034DC54: D5207C07 00060811
	.long 0xd700010b                                           // 00000034DC5C: D700010B
	v_cndmask_b32_e32 v1, v3, v5, vcc_lo                       // 00000034DC60: 02020B03
	v_add_co_ci_u32_e64 v12, null, 0, v4, s1                   // 00000034DC64: D5207C0C 00060880
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034DC6C: BF870094
	.long 0xd700010d                                           // 00000034DC70: D700010D
	v_cndmask_b32_e32 v1, v6, v0, vcc_lo                       // 00000034DC74: 02020106
	v_add_co_ci_u32_e64 v14, null, 0, v7, s1                   // 00000034DC78: D5207C0E 00060E80
	s_clause 0x2                                               // 00000034DC80: BF850002
	global_load_b128 v[4:7], v[1:2], off                       // 00000034DC84: DC5E0000 047C0001
	global_load_b64 v[15:16], v[11:12], off                    // 00000034DC8C: DC560000 0F7C000B
	global_load_b32 v46, v[13:14], off                         // 00000034DC94: DC520000 2E7C000D
	s_or_b32 exec_lo, exec_lo, s4                              // 00000034DC9C: 8C7E047E
	v_dual_mov_b32 v20, 0 :: v_dual_mov_b32 v21, 0             // 00000034DCA0: CA100080 14140080
	v_dual_mov_b32 v22, 0 :: v_dual_mov_b32 v23, 0             // 00000034DCA8: CA100080 16160080
	v_dual_mov_b32 v24, 0 :: v_dual_mov_b32 v25, 0             // 00000034DCB0: CA100080 18180080
	s_and_saveexec_b32 s13, s0                                 // 00000034DCB8: BE8D2000
	s_cbranch_execz 1074                                       // 00000034DCBC: BFA50432 <_ZN7halogen12_GLOBAL__N_16k_lq6wILi7ELi16ELi1EEEvPKhPKtPtll+0x1288>
	.long 0xd700001a                                           // 00000034DCC0: D700001A
	v_cndmask_b32_e32 v0, v10, v14, vcc_lo                     // 00000034DCC4: 02001D0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000034DCC8: BF8701A1
	v_add_co_ci_u32_e64 v27, null, s15, v19, s0                // 00000034DCCC: D5207C1B 0002260F
	v_dual_mov_b32 v12, 0 :: v_dual_lshlrev_b32 v11, 5, v17    // 00000034DCD4: CA220080 0C0A2285
	.long 0xd700001c                                           // 00000034DCDC: D700001C
	v_cndmask_b32_e32 v0, v26, v16, vcc_lo                     // 00000034DCE0: 0200211A
	s_delay_alu instid0(VALU_DEP_1)                            // 00000034DCE4: BF870001
	v_add_co_ci_u32_e64 v29, null, s17, v27, s0                // 00000034DCE8: D5207C1D 00023611
	v_lshl_or_b32 v30, v17, 4, 0x100                           // 00000034DCF0: D656001E 03FD0911 00000100
	v_lshl_or_b32 v31, v17, 3, 0x80                            // 00000034DCFC: D656001F 03FD0711 00000080
	v_lshl_or_b32 v32, v17, 1, 32                              // 00000034DD08: D6560020 02810311
	v_dual_mov_b32 v18, v12 :: v_dual_mov_b32 v33, v17         // 00000034DD10: CA10010C 12200111
	v_mov_b32_e32 v20, v12                                     // 00000034DD18: 7E28030C
	s_waitcnt vmcnt(0)                                         // 00000034DD1C: BF8903F7
	v_dual_mov_b32 v21, v12 :: v_dual_mov_b32 v34, v46         // 00000034DD20: CA10010C 1522012E
	v_mov_b32_e32 v22, v12                                     // 00000034DD28: 7E2C030C
	v_mov_b32_e32 v23, v12                                     // 00000034DD2C: 7E2E030C
	v_mov_b32_e32 v24, v12                                     // 00000034DD30: 7E30030C
	v_mov_b32_e32 v25, v12                                     // 00000034DD34: 7E32030C
	s_mul_i32 s0, s11, 6                                       // 00000034DD38: 9600860B
	s_mul_hi_u32 s1, s10, 6                                    // 00000034DD3C: 9681860A
	s_lshl_b64 s[4:5], s[10:11], 2                             // 00000034DD40: 8484820A
	s_add_i32 s14, s1, s0                                      // 00000034DD44: 810E0001
	s_mul_i32 s16, s10, 6                                      // 00000034DD48: 9610860A
	s_mov_b32 s15, 0                                           // 00000034DD4C: BE8F0080
	s_lshl_b64 s[10:11], s[10:11], 1                           // 00000034DD50: 848A810A
	s_branch 997                                               // 00000034DD54: BFA003E5 <_ZN7halogen12_GLOBAL__N_16k_lq6wILi7ELi16ELi1EEEvPKhPKtPtll+0x11ec>
	s_or_b32 exec_lo, exec_lo, s17                             // 00000034DD58: 8C7E117E
	v_lshlrev_b32_e32 v35, 4, v15                              // 00000034DD5C: 30461E84
	v_lshlrev_b32_e32 v37, 2, v15                              // 00000034DD60: 304A1E82
	v_lshrrev_b32_e32 v36, 4, v4                               // 00000034DD64: 32480884
	.long 0x7f5e3880                                           // 00000034DD68: 7F5E3880
	v_lshrrev_b32_e32 v39, 6, v15                              // 00000034DD6C: 324E1E86
	v_and_b32_e32 v35, 48, v35                                 // 00000034DD70: 364646B0
	v_and_b32_e32 v37, 48, v37                                 // 00000034DD74: 364A4AB0
	v_lshrrev_b32_e32 v42, 22, v15                             // 00000034DD78: 32541E96
	v_lshrrev_b32_e32 v45, 6, v16                              // 00000034DD7C: 325A2086
	v_and_b32_e32 v39, 48, v39                                 // 00000034DD80: 364E4EB0
	v_and_or_b32 v35, v4, 15, v35                              // 00000034DD84: D6570023 048D1F04
	v_and_or_b32 v36, v36, 15, v37                             // 00000034DD8C: D6570024 04951F24
	v_and_b32_e32 v42, 48, v42                                 // 00000034DD94: 365454B0
	v_lshrrev_b32_e32 v44, 20, v6                              // 00000034DD98: 32580C94
	v_and_b32_e32 v45, 48, v45                                 // 00000034DD9C: 365A5AB0
	v_cvt_f32_ubyte0_e32 v35, v35                              // 00000034DDA0: 7E462323
	v_lshrrev_b32_e32 v49, 18, v16                             // 00000034DDA4: 32622092
	v_lshrrev_b32_e32 v50, 22, v16                             // 00000034DDA8: 32642096
	s_and_b32 s0, exec_lo, s0                                  // 00000034DDAC: 8B00007E
	v_and_or_b32 v44, v44, 15, v45                             // 00000034DDB0: D657002C 04B51F2C
	v_fma_mix_f32 v35, v35, v46, v46 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000034DDB8: CC206023 14BA5D23
	v_and_b32_e32 v49, 48, v49                                 // 00000034DDC0: 366262B0
	v_and_b32_e32 v50, 48, v50                                 // 00000034DDC4: 366464B0
	s_or_b32 s15, s0, s15                                      // 00000034DDC8: 8C0F0F00
	v_add_nc_u32_e32 v30, 0x100, v30                           // 00000034DDCC: 4A3C3CFF 00000100
	v_bfe_u32 v37, v35, 16, 1                                  // 00000034DDD4: D6100025 02052123
	v_add_nc_u32_e32 v31, 0x80, v31                            // 00000034DDDC: 4A3E3EFF 00000080
	v_add_nc_u32_e32 v32, 32, v32                              // 00000034DDE4: 4A4040A0
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000034DDE8: BF870123
	v_add3_u32 v35, v35, v37, 0x7fff                           // 00000034DDEC: D6550023 03FE4B23 00007FFF
	v_lshrrev_b32_e32 v37, 2, v15                              // 00000034DDF8: 324A1E82
	.long 0x7e5e39a3                                           // 00000034DDFC: 7E5E39A3
	v_cvt_f32_ubyte0_e32 v35, v36                              // 00000034DE00: 7E462324
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000034DE04: BF870113
	v_and_b32_e32 v37, 48, v37                                 // 00000034DE08: 364A4AB0
	v_fma_mix_f32 v35, v35, v46, v46 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000034DE0C: CC206023 14BA5D23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034DE14: BF870091
	v_bfe_u32 v36, v35, 16, 1                                  // 00000034DE18: D6100024 02052123
	v_add3_u32 v35, v35, v36, 0x7fff                           // 00000034DE20: D6550023 03FE4923 00007FFF
	v_and_b32_e32 v36, 48, v15                                 // 00000034DE2C: 36481EB0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000034DE30: BF8700A2
	v_and_or_b32 v38, 0xffff0000, v35, v47                     // 00000034DE34: D6570026 04BE46FF FFFF0000
	v_lshrrev_b32_e32 v35, 8, v4                               // 00000034DE40: 32460888
	v_and_or_b32 v35, v35, 15, v36                             // 00000034DE44: D6570023 04911F23
	v_lshrrev_b32_e32 v36, 12, v4                              // 00000034DE4C: 3248088C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000034DE50: BF870112
	v_cvt_f32_ubyte0_e32 v35, v35                              // 00000034DE54: 7E462323
	v_and_or_b32 v36, v36, 15, v37                             // 00000034DE58: D6570024 04951F24
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034DE60: BF870092
	v_fma_mix_f32 v35, v35, v46, v46 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000034DE64: CC206023 14BA5D23
	v_bfe_u32 v37, v35, 16, 1                                  // 00000034DE6C: D6100025 02052123
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000034DE74: BF870121
	v_add3_u32 v35, v35, v37, 0x7fff                           // 00000034DE78: D6550023 03FE4B23 00007FFF
	v_lshrrev_b32_e32 v37, 20, v4                              // 00000034DE84: 324A0894
	.long 0x7e5e39a3                                           // 00000034DE88: 7E5E39A3
	v_cvt_f32_ubyte0_e32 v35, v36                              // 00000034DE8C: 7E462324
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000034DE90: BF870113
	v_and_or_b32 v37, v37, 15, v39                             // 00000034DE94: D6570025 049D1F25
	v_fma_mix_f32 v35, v35, v46, v46 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000034DE9C: CC206023 14BA5D23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034DEA4: BF870091
	v_bfe_u32 v36, v35, 16, 1                                  // 00000034DEA8: D6100024 02052123
	v_add3_u32 v35, v35, v36, 0x7fff                           // 00000034DEB0: D6550023 03FE4923 00007FFF
	v_lshrrev_b32_e32 v36, 4, v15                              // 00000034DEBC: 32481E84
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000034DEC0: BF8701A2
	v_and_or_b32 v40, 0xffff0000, v35, v47                     // 00000034DEC4: D6570028 04BE46FF FFFF0000
	.long 0x7e5e3984                                           // 00000034DED0: 7E5E3984
	v_and_b32_e32 v36, 48, v36                                 // 00000034DED4: 364848B0
	v_lshrrev_b32_e32 v35, 8, v15                              // 00000034DED8: 32461E88
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000034DEDC: BF870112
	v_and_or_b32 v36, v47, 15, v36                             // 00000034DEE0: D6570024 04911F2F
	v_and_b32_e32 v35, 48, v35                                 // 00000034DEE8: 364646B0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034DEEC: BF870092
	v_cvt_f32_ubyte0_e32 v36, v36                              // 00000034DEF0: 7E482324
	v_fma_mix_f32 v36, v36, v46, v46 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000034DEF4: CC206024 14BA5D24
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034DEFC: BF870091
	v_bfe_u32 v39, v36, 16, 1                                  // 00000034DF00: D6100027 02052124
	v_add3_u32 v36, v36, v39, 0x7fff                           // 00000034DF08: D6550024 03FE4F24 00007FFF
	v_lshrrev_b32_e32 v39, 18, v15                             // 00000034DF14: 324E1E92
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000034DF18: BF8701A2
	.long 0x7e5e39a4                                           // 00000034DF1C: 7E5E39A4
	v_cvt_f32_ubyte0_e32 v36, v37                              // 00000034DF20: 7E482325
	v_and_b32_e32 v39, 48, v39                                 // 00000034DF24: 364E4EB0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034DF28: BF870092
	v_fma_mix_f32 v36, v36, v46, v46 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000034DF2C: CC206024 14BA5D24
	v_bfe_u32 v37, v36, 16, 1                                  // 00000034DF34: D6100025 02052124
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000034DF3C: BF870121
	v_add3_u32 v36, v36, v37, 0x7fff                           // 00000034DF40: D6550024 03FE4B24 00007FFF
	v_lshrrev_b32_e32 v37, 12, v15                             // 00000034DF4C: 324A1E8C
	v_and_or_b32 v41, 0xffff0000, v36, v47                     // 00000034DF50: D6570029 04BE48FF FFFF0000
	v_lshrrev_b32_e32 v36, 24, v4                              // 00000034DF5C: 32480898
	v_lshrrev_b32_e32 v4, 28, v4                               // 00000034DF60: 3208089C
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000034DF64: BF870122
	v_and_or_b32 v35, v36, 15, v35                             // 00000034DF68: D6570023 048D1F24
	v_lshrrev_b32_e32 v36, 10, v15                             // 00000034DF70: 32481E8A
	v_cvt_f32_ubyte0_e32 v35, v35                              // 00000034DF74: 7E462323
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000034DF78: BF870112
	v_and_or_b32 v4, v36, 48, v4                               // 00000034DF7C: D6570004 04116124
	v_fma_mix_f32 v35, v35, v46, v46 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000034DF84: CC206023 14BA5D23
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000034DF8C: BF870112
	v_cvt_f32_ubyte0_e32 v4, v4                                // 00000034DF90: 7E082304
	v_bfe_u32 v36, v35, 16, 1                                  // 00000034DF94: D6100024 02052123
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000034DF9C: BF870112
	v_fma_mix_f32 v4, v4, v46, v46 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000034DFA0: CC206004 14BA5D04
	v_add3_u32 v35, v35, v36, 0x7fff                           // 00000034DFA8: D6550023 03FE4923 00007FFF
	v_lshrrev_b32_e32 v36, 14, v15                             // 00000034DFB4: 32481E8E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000034DFB8: BF870212
	.long 0x7e5e39a3                                           // 00000034DFBC: 7E5E39A3
	v_bfe_u32 v35, v4, 16, 1                                   // 00000034DFC0: D6100023 02052104
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000034DFC8: BF870113
	v_and_b32_e32 v36, 48, v36                                 // 00000034DFCC: 364848B0
	v_add3_u32 v4, v4, v35, 0x7fff                             // 00000034DFD0: D6550004 03FE4704 00007FFF
	v_lshrrev_b32_e32 v35, 4, v5                               // 00000034DFDC: 32460A84
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000034DFE0: BF8701A2
	v_and_or_b32 v43, 0xffff0000, v4, v47                      // 00000034DFE4: D657002B 04BE08FF FFFF0000
	v_and_b32_e32 v4, 48, v37                                  // 00000034DFF0: 36084AB0
	v_and_or_b32 v35, v35, 15, v36                             // 00000034DFF4: D6570023 04911F23
	.long 0x7e5e398f                                           // 00000034DFFC: 7E5E398F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000034E000: BF870193
	v_and_or_b32 v4, v5, 15, v4                                // 00000034E004: D6570004 04111F05
	v_cvt_f32_ubyte0_e32 v35, v35                              // 00000034E00C: 7E462323
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000034E010: BF870193
	v_and_b32_e32 v37, 48, v47                                 // 00000034E014: 364A5EB0
	v_cvt_f32_ubyte0_e32 v4, v4                                // 00000034E018: 7E082304
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000034E01C: BF870113
	v_fma_mix_f32 v35, v35, v46, v46 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000034E020: CC206023 14BA5D23
	v_fma_mix_f32 v4, v4, v46, v46 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000034E028: CC206004 14BA5D04
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034E030: BF870091
	v_bfe_u32 v36, v4, 16, 1                                   // 00000034E034: D6100024 02052104
	v_add3_u32 v4, v4, v36, 0x7fff                             // 00000034E03C: D6550004 03FE4904 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000034E048: BF870114
	v_bfe_u32 v36, v35, 16, 1                                  // 00000034E04C: D6100024 02052123
	.long 0x7e083984                                           // 00000034E054: 7E083984
	.long 0x7f0839af                                           // 00000034E058: 7F0839AF
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000034E05C: BF870123
	v_add3_u32 v35, v35, v36, 0x7fff                           // 00000034E060: D6550023 03FE4923 00007FFF
	v_lshrrev_b32_e32 v36, 20, v15                             // 00000034E06C: 32481E94
	v_and_or_b32 v4, 0xffff0000, v35, v4                       // 00000034E070: D6570004 041246FF FFFF0000
	v_lshrrev_b32_e32 v35, 8, v5                               // 00000034E07C: 32460A88
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000034E080: BF870113
	v_and_b32_e32 v36, 48, v36                                 // 00000034E084: 364848B0
	v_and_or_b32 v35, v35, 15, v37                             // 00000034E088: D6570023 04951F23
	v_lshrrev_b32_e32 v37, 12, v5                              // 00000034E090: 324A0A8C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000034E094: BF870112
	v_cvt_f32_ubyte0_e32 v35, v35                              // 00000034E098: 7E462323
	v_and_or_b32 v37, v37, 15, v39                             // 00000034E09C: D6570025 049D1F25
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034E0A4: BF870092
	v_fma_mix_f32 v35, v35, v46, v46 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000034E0A8: CC206023 14BA5D23
	v_bfe_u32 v39, v35, 16, 1                                  // 00000034E0B0: D6100027 02052123
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000034E0B8: BF870121
	v_add3_u32 v35, v35, v39, 0x7fff                           // 00000034E0BC: D6550023 03FE4F23 00007FFF
	v_lshrrev_b32_e32 v39, 20, v5                              // 00000034E0C8: 324E0A94
	.long 0x7e5e39a3                                           // 00000034E0CC: 7E5E39A3
	v_cvt_f32_ubyte0_e32 v35, v37                              // 00000034E0D0: 7E462325
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000034E0D4: BF870113
	v_and_or_b32 v39, v39, 15, v42                             // 00000034E0D8: D6570027 04A91F27
	v_fma_mix_f32 v35, v35, v46, v46 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000034E0E0: CC206023 14BA5D23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034E0E8: BF870091
	v_bfe_u32 v37, v35, 16, 1                                  // 00000034E0EC: D6100025 02052123
	v_add3_u32 v35, v35, v37, 0x7fff                           // 00000034E0F4: D6550023 03FE4B23 00007FFF
	v_lshrrev_b32_e32 v37, 24, v15                             // 00000034E100: 324A1E98
	v_lshrrev_b32_e32 v15, 26, v15                             // 00000034E104: 321E1E9A
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000034E108: BF870223
	v_and_or_b32 v35, 0xffff0000, v35, v47                     // 00000034E10C: D6570023 04BE46FF FFFF0000
	.long 0x7e5e3985                                           // 00000034E118: 7E5E3985
	v_and_b32_e32 v37, 48, v37                                 // 00000034E11C: 364A4AB0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034E120: BF870092
	v_and_or_b32 v36, v47, 15, v36                             // 00000034E124: D6570024 04911F2F
	v_cvt_f32_ubyte0_e32 v36, v36                              // 00000034E12C: 7E482324
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034E130: BF870091
	v_fma_mix_f32 v36, v36, v46, v46 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000034E134: CC206024 14BA5D24
	v_bfe_u32 v42, v36, 16, 1                                  // 00000034E13C: D610002A 02052124
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000034E144: BF870121
	v_add3_u32 v36, v36, v42, 0x7fff                           // 00000034E148: D6550024 03FE5524 00007FFF
	v_lshrrev_b32_e32 v42, 2, v16                              // 00000034E154: 32542082
	.long 0x7e5e39a4                                           // 00000034E158: 7E5E39A4
	v_cvt_f32_ubyte0_e32 v36, v39                              // 00000034E15C: 7E482327
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000034E160: BF870113
	v_and_b32_e32 v42, 48, v42                                 // 00000034E164: 365454B0
	v_fma_mix_f32 v36, v36, v46, v46 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000034E168: CC206024 14BA5D24
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034E170: BF870091
	v_bfe_u32 v39, v36, 16, 1                                  // 00000034E174: D6100027 02052124
	v_add3_u32 v36, v36, v39, 0x7fff                           // 00000034E17C: D6550024 03FE4F24 00007FFF
	v_lshrrev_b32_e32 v39, 24, v5                              // 00000034E188: 324E0A98
	v_lshrrev_b32_e32 v5, 28, v5                               // 00000034E18C: 320A0A9C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000034E190: BF870193
	v_and_or_b32 v36, 0xffff0000, v36, v47                     // 00000034E194: D6570024 04BE48FF FFFF0000
	v_and_or_b32 v37, v39, 15, v37                             // 00000034E1A0: D6570025 04951F27
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000034E1A8: BF8701A3
	v_and_or_b32 v5, v15, 48, v5                               // 00000034E1AC: D6570005 0415610F
	v_lshlrev_b32_e32 v39, 2, v16                              // 00000034E1B4: 304E2082
	v_cvt_f32_ubyte0_e32 v15, v37                              // 00000034E1B8: 7E1E2325
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000034E1BC: BF870193
	v_cvt_f32_ubyte0_e32 v5, v5                                // 00000034E1C0: 7E0A2305
	v_and_b32_e32 v39, 48, v39                                 // 00000034E1C4: 364E4EB0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000034E1C8: BF870193
	v_fma_mix_f32 v15, v15, v46, v46 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000034E1CC: CC20600F 14BA5D0F
	v_fma_mix_f32 v5, v5, v46, v46 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000034E1D4: CC206005 14BA5D05
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034E1DC: BF870092
	v_bfe_u32 v37, v15, 16, 1                                  // 00000034E1E0: D6100025 0205210F
	v_add3_u32 v15, v15, v37, 0x7fff                           // 00000034E1E8: D655000F 03FE4B0F 00007FFF
	v_lshrrev_b32_e32 v37, 4, v6                               // 00000034E1F4: 324A0C84
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000034E1F8: BF8701A2
	.long 0x7e5e398f                                           // 00000034E1FC: 7E5E398F
	v_bfe_u32 v15, v5, 16, 1                                   // 00000034E200: D610000F 02052105
	v_and_or_b32 v37, v37, 15, v39                             // 00000034E208: D6570025 049D1F25
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000034E210: BF870122
	v_add3_u32 v5, v5, v15, 0x7fff                             // 00000034E214: D6550005 03FE1F05 00007FFF
	v_lshlrev_b32_e32 v15, 4, v16                              // 00000034E220: 301E2084
	v_and_or_b32 v5, 0xffff0000, v5, v47                       // 00000034E224: D6570005 04BE0AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034E230: BF870092
	v_and_b32_e32 v15, 48, v15                                 // 00000034E234: 361E1EB0
	v_and_or_b32 v15, v6, 15, v15                              // 00000034E238: D657000F 043D1F06
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034E240: BF870091
	v_cvt_f32_ubyte0_e32 v15, v15                              // 00000034E244: 7E1E230F
	v_fma_mix_f32 v15, v15, v46, v46 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000034E248: CC20600F 14BA5D0F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034E250: BF870091
	v_bfe_u32 v39, v15, 16, 1                                  // 00000034E254: D6100027 0205210F
	v_add3_u32 v15, v15, v39, 0x7fff                           // 00000034E25C: D655000F 03FE4F0F 00007FFF
	v_and_b32_e32 v39, 48, v16                                 // 00000034E268: 364E20B0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000034E26C: BF8700A2
	.long 0x7e5e398f                                           // 00000034E270: 7E5E398F
	v_cvt_f32_ubyte0_e32 v15, v37                              // 00000034E274: 7E1E2325
	v_fma_mix_f32 v15, v15, v46, v46 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000034E278: CC20600F 14BA5D0F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034E280: BF870091
	v_bfe_u32 v37, v15, 16, 1                                  // 00000034E284: D6100025 0205210F
	v_add3_u32 v15, v15, v37, 0x7fff                           // 00000034E28C: D655000F 03FE4B0F 00007FFF
	v_lshrrev_b32_e32 v37, 8, v6                               // 00000034E298: 324A0C88
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000034E29C: BF870112
	v_and_or_b32 v15, 0xffff0000, v15, v47                     // 00000034E2A0: D657000F 04BE1EFF FFFF0000
	v_and_or_b32 v37, v37, 15, v39                             // 00000034E2AC: D6570025 049D1F25
	v_lshrrev_b32_e32 v39, 12, v6                              // 00000034E2B4: 324E0C8C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000034E2B8: BF870112
	v_cvt_f32_ubyte0_e32 v37, v37                              // 00000034E2BC: 7E4A2325
	v_and_or_b32 v39, v39, 15, v42                             // 00000034E2C0: D6570027 04A91F27
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034E2C8: BF870092
	v_fma_mix_f32 v37, v37, v46, v46 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000034E2CC: CC206025 14BA5D25
	v_bfe_u32 v42, v37, 16, 1                                  // 00000034E2D4: D610002A 02052125
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000034E2DC: BF870121
	v_add3_u32 v37, v37, v42, 0x7fff                           // 00000034E2E0: D6550025 03FE5525 00007FFF
	v_lshrrev_b32_e32 v42, 8, v16                              // 00000034E2EC: 32542088
	.long 0x7e5e39a5                                           // 00000034E2F0: 7E5E39A5
	v_cvt_f32_ubyte0_e32 v37, v39                              // 00000034E2F4: 7E4A2327
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000034E2F8: BF870113
	v_and_b32_e32 v42, 48, v42                                 // 00000034E2FC: 365454B0
	v_fma_mix_f32 v37, v37, v46, v46 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000034E300: CC206025 14BA5D25
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034E308: BF870091
	v_bfe_u32 v39, v37, 16, 1                                  // 00000034E30C: D6100027 02052125
	v_add3_u32 v37, v37, v39, 0x7fff                           // 00000034E314: D6550025 03FE4F25 00007FFF
	v_lshrrev_b32_e32 v39, 4, v16                              // 00000034E320: 324E2084
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000034E324: BF8701A2
	v_and_or_b32 v37, 0xffff0000, v37, v47                     // 00000034E328: D6570025 04BE4AFF FFFF0000
	.long 0x7e5e3986                                           // 00000034E334: 7E5E3986
	v_and_b32_e32 v39, 48, v39                                 // 00000034E338: 364E4EB0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034E33C: BF870091
	v_and_or_b32 v39, v47, 15, v39                             // 00000034E340: D6570027 049D1F2F
	v_cvt_f32_ubyte0_e32 v39, v39                              // 00000034E348: 7E4E2327
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034E34C: BF870091
	v_fma_mix_f32 v39, v39, v46, v46 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000034E350: CC206027 14BA5D27
	v_bfe_u32 v45, v39, 16, 1                                  // 00000034E358: D610002D 02052127
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000034E360: BF870121
	v_add3_u32 v39, v39, v45, 0x7fff                           // 00000034E364: D6550027 03FE5B27 00007FFF
	v_lshrrev_b32_e32 v45, 12, v16                             // 00000034E370: 325A208C
	.long 0x7e5e39a7                                           // 00000034E374: 7E5E39A7
	v_cvt_f32_ubyte0_e32 v39, v44                              // 00000034E378: 7E4E232C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034E37C: BF870091
	v_fma_mix_f32 v39, v39, v46, v46 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000034E380: CC206027 14BA5D27
	v_bfe_u32 v44, v39, 16, 1                                  // 00000034E388: D610002C 02052127
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000034E390: BF8701B1
	v_add3_u32 v39, v39, v44, 0x7fff                           // 00000034E394: D6550027 03FE5927 00007FFF
	v_lshrrev_b32_e32 v44, 24, v6                              // 00000034E3A0: 32580C98
	v_lshrrev_b32_e32 v6, 28, v6                               // 00000034E3A4: 320C0C9C
	v_and_or_b32 v39, 0xffff0000, v39, v47                     // 00000034E3A8: D6570027 04BE4EFF FFFF0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000034E3B4: BF870123
	v_and_or_b32 v42, v44, 15, v42                             // 00000034E3B8: D657002A 04A91F2C
	v_lshrrev_b32_e32 v44, 10, v16                             // 00000034E3C0: 3258208A
	v_cvt_f32_ubyte0_e32 v42, v42                              // 00000034E3C4: 7E54232A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000034E3C8: BF870112
	v_and_or_b32 v6, v44, 48, v6                               // 00000034E3CC: D6570006 0419612C
	v_fma_mix_f32 v42, v42, v46, v46 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000034E3D4: CC20602A 14BA5D2A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000034E3DC: BF870112
	v_cvt_f32_ubyte0_e32 v6, v6                                // 00000034E3E0: 7E0C2306
	v_bfe_u32 v44, v42, 16, 1                                  // 00000034E3E4: D610002C 0205212A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000034E3EC: BF870112
	v_fma_mix_f32 v6, v6, v46, v46 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000034E3F0: CC206006 14BA5D06
	v_add3_u32 v42, v42, v44, 0x7fff                           // 00000034E3F8: D655002A 03FE592A 00007FFF
	v_lshrrev_b32_e32 v44, 4, v7                               // 00000034E404: 32580E84
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000034E408: BF870212
	.long 0x7e5e39aa                                           // 00000034E40C: 7E5E39AA
	v_bfe_u32 v42, v6, 16, 1                                   // 00000034E410: D610002A 02052106
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000034E418: BF870121
	v_add3_u32 v6, v6, v42, 0x7fff                             // 00000034E41C: D6550006 03FE5506 00007FFF
	v_and_b32_e32 v42, 15, v7                                  // 00000034E428: 36540E8F
	v_and_or_b32 v6, 0xffff0000, v6, v47                       // 00000034E42C: D6570006 04BE0CFF FFFF0000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000034E438: BF8701B2
	v_and_or_b32 v42, v45, 48, v42                             // 00000034E43C: D657002A 04A9612D
	v_lshrrev_b32_e32 v45, 14, v16                             // 00000034E444: 325A208E
	.long 0x7e5e3990                                           // 00000034E448: 7E5E3990
	v_cvt_f32_ubyte0_e32 v42, v42                              // 00000034E44C: 7E54232A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000034E450: BF870193
	v_and_b32_e32 v45, 48, v45                                 // 00000034E454: 365A5AB0
	v_and_b32_e32 v48, 48, v47                                 // 00000034E458: 36605EB0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000034E45C: BF870193
	v_fma_mix_f32 v42, v42, v46, v46 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000034E460: CC20602A 14BA5D2A
	v_and_or_b32 v44, v44, 15, v45                             // 00000034E468: D657002C 04B51F2C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000034E470: BF870112
	v_bfe_u32 v45, v42, 16, 1                                  // 00000034E474: D610002D 0205212A
	v_cvt_f32_ubyte0_e32 v44, v44                              // 00000034E47C: 7E58232C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000034E480: BF870112
	v_add3_u32 v42, v42, v45, 0x7fff                           // 00000034E484: D655002A 03FE5B2A 00007FFF
	v_fma_mix_f32 v44, v44, v46, v46 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000034E490: CC20602C 14BA5D2C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000034E498: BF870112
	.long 0x7e5439aa                                           // 00000034E49C: 7E5439AA
	v_bfe_u32 v45, v44, 16, 1                                  // 00000034E4A0: D610002D 0205212C
	.long 0x7f5439af                                           // 00000034E4A8: 7F5439AF
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000034E4AC: BF870122
	v_add3_u32 v44, v44, v45, 0x7fff                           // 00000034E4B0: D655002C 03FE5B2C 00007FFF
	v_lshrrev_b32_e32 v45, 20, v16                             // 00000034E4BC: 325A2094
	v_and_or_b32 v42, 0xffff0000, v44, v42                     // 00000034E4C0: D657002A 04AA58FF FFFF0000
	v_lshrrev_b32_e32 v44, 8, v7                               // 00000034E4CC: 32580E88
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000034E4D0: BF870113
	v_and_b32_e32 v45, 48, v45                                 // 00000034E4D4: 365A5AB0
	v_and_or_b32 v44, v44, 15, v48                             // 00000034E4D8: D657002C 04C11F2C
	v_lshrrev_b32_e32 v48, 12, v7                              // 00000034E4E0: 32600E8C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000034E4E4: BF870112
	v_cvt_f32_ubyte0_e32 v44, v44                              // 00000034E4E8: 7E58232C
	v_and_or_b32 v48, v48, 15, v49                             // 00000034E4EC: D6570030 04C51F30
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034E4F4: BF870092
	v_fma_mix_f32 v44, v44, v46, v46 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000034E4F8: CC20602C 14BA5D2C
	v_bfe_u32 v49, v44, 16, 1                                  // 00000034E500: D6100031 0205212C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000034E508: BF870121
	v_add3_u32 v44, v44, v49, 0x7fff                           // 00000034E50C: D655002C 03FE632C 00007FFF
	v_lshrrev_b32_e32 v49, 20, v7                              // 00000034E518: 32620E94
	.long 0x7e5e39ac                                           // 00000034E51C: 7E5E39AC
	v_cvt_f32_ubyte0_e32 v44, v48                              // 00000034E520: 7E582330
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000034E524: BF870113
	v_and_or_b32 v49, v49, 15, v50                             // 00000034E528: D6570031 04C91F31
	v_fma_mix_f32 v44, v44, v46, v46 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000034E530: CC20602C 14BA5D2C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034E538: BF870091
	v_bfe_u32 v48, v44, 16, 1                                  // 00000034E53C: D6100030 0205212C
	v_add3_u32 v44, v44, v48, 0x7fff                           // 00000034E544: D655002C 03FE612C 00007FFF
	v_lshrrev_b32_e32 v48, 24, v16                             // 00000034E550: 32602098
	v_lshrrev_b32_e32 v16, 26, v16                             // 00000034E554: 3220209A
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000034E558: BF870223
	v_and_or_b32 v44, 0xffff0000, v44, v47                     // 00000034E55C: D657002C 04BE58FF FFFF0000
	.long 0x7e5e3987                                           // 00000034E568: 7E5E3987
	v_and_b32_e32 v48, 48, v48                                 // 00000034E56C: 366060B0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034E570: BF870092
	v_and_or_b32 v45, v47, 15, v45                             // 00000034E574: D657002D 04B51F2F
	v_cvt_f32_ubyte0_e32 v45, v45                              // 00000034E57C: 7E5A232D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034E580: BF870091
	v_fma_mix_f32 v45, v45, v46, v46 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000034E584: CC20602D 14BA5D2D
	v_bfe_u32 v50, v45, 16, 1                                  // 00000034E58C: D6100032 0205212D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034E594: BF870091
	v_add3_u32 v45, v45, v50, 0x7fff                           // 00000034E598: D655002D 03FE652D 00007FFF
	.long 0x7e5e39ad                                           // 00000034E5A4: 7E5E39AD
	v_cvt_f32_ubyte0_e32 v45, v49                              // 00000034E5A8: 7E5A2331
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034E5AC: BF870091
	v_fma_mix_f32 v45, v45, v46, v46 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000034E5B0: CC20602D 14BA5D2D
	v_bfe_u32 v49, v45, 16, 1                                  // 00000034E5B8: D6100031 0205212D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000034E5C0: BF8701B1
	v_add3_u32 v45, v45, v49, 0x7fff                           // 00000034E5C4: D655002D 03FE632D 00007FFF
	v_lshrrev_b32_e32 v49, 24, v7                              // 00000034E5D0: 32620E98
	v_lshrrev_b32_e32 v7, 28, v7                               // 00000034E5D4: 320E0E9C
	v_and_or_b32 v45, 0xffff0000, v45, v47                     // 00000034E5D8: D657002D 04BE5AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000034E5E4: BF870193
	v_and_or_b32 v48, v49, 15, v48                             // 00000034E5E8: D6570030 04C11F31
	v_and_or_b32 v7, v16, 48, v7                               // 00000034E5F0: D6570007 041D6110
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000034E5F8: BF870112
	v_cvt_f32_ubyte0_e32 v16, v48                              // 00000034E5FC: 7E202330
	v_cvt_f32_ubyte0_e32 v7, v7                                // 00000034E600: 7E0E2307
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000034E604: BF870112
	v_fma_mix_f32 v16, v16, v46, v46 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000034E608: CC206010 14BA5D10
	v_fma_mix_f32 v7, v7, v46, v46 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000034E610: CC206007 14BA5D07
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034E618: BF870092
	v_bfe_u32 v48, v16, 16, 1                                  // 00000034E61C: D6100030 02052110
	v_add3_u32 v16, v16, v48, 0x7fff                           // 00000034E624: D6550010 03FE6110 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000034E630: BF870211
	.long 0x7e5e3990                                           // 00000034E634: 7E5E3990
	v_bfe_u32 v16, v7, 16, 1                                   // 00000034E638: D6100010 02052107
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034E640: BF870091
	v_add3_u32 v7, v7, v16, 0x7fff                             // 00000034E644: D6550007 03FE2107 00007FFF
	v_and_or_b32 v7, 0xffff0000, v7, v47                       // 00000034E650: D6570007 04BE0EFF FFFF0000
	.long 0xd73c002e                                           // 00000034E65C: D73C002E
	v_cndmask_b32_e32 v1, 1, v11, vcc_lo                       // 00000034E660: 02021681
	v_add_nc_u32_e32 v11, 0x200, v11                           // 00000034E664: 4A1616FF 00000200
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034E66C: BF870092
	.long 0xd700003e                                           // 00000034E670: D700003E
	v_cndmask_b32_e32 v1, s6, v46, vcc_lo                      // 00000034E674: 02025C06
	v_add_co_ci_u32_e64 v63, null, s7, v47, s0                 // 00000034E678: D5207C3F 00025E07
	s_clause 0x3                                               // 00000034E680: BF850003
	global_load_b128 v[46:49], v[62:63], off                   // 00000034E684: DC5E0000 2E7C003E
	global_load_b128 v[50:53], v[62:63], off offset:16         // 00000034E68C: DC5E0010 327C003E
	global_load_b128 v[54:57], v[62:63], off offset:32         // 00000034E694: DC5E0020 367C003E
	global_load_b128 v[58:61], v[62:63], off offset:48         // 00000034E69C: DC5E0030 3A7C003E
	s_waitcnt vmcnt(3)                                         // 00000034E6A4: BF890FF7
	v_dot2_f32_bf16 v16, v46, v38, 0                           // 00000034E6A8: CC1A4010 1A024D2E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034E6B0: BF870091
	v_dot2_f32_bf16 v16, v47, v40, v16                         // 00000034E6B4: CC1A4010 1C42512F
	v_dot2_f32_bf16 v16, v48, v41, v16                         // 00000034E6BC: CC1A4010 1C425330
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000034E6C4: BF8700A1
	v_dot2_f32_bf16 v16, v49, v43, v16                         // 00000034E6C8: CC1A4010 1C425731
	s_waitcnt vmcnt(2)                                         // 00000034E6D0: BF890BF7
	v_dot2_f32_bf16 v16, v50, v4, v16                          // 00000034E6D4: CC1A4010 1C420932
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034E6DC: BF870091
	v_dot2_f32_bf16 v16, v51, v35, v16                         // 00000034E6E0: CC1A4010 1C424733
	v_dot2_f32_bf16 v16, v52, v36, v16                         // 00000034E6E8: CC1A4010 1C424934
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000034E6F0: BF8700A1
	v_dot2_f32_bf16 v16, v53, v5, v16                          // 00000034E6F4: CC1A4010 1C420B35
	s_waitcnt vmcnt(1)                                         // 00000034E6FC: BF8907F7
	v_dot2_f32_bf16 v16, v54, v15, v16                         // 00000034E700: CC1A4010 1C421F36
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034E708: BF870091
	v_dot2_f32_bf16 v16, v55, v37, v16                         // 00000034E70C: CC1A4010 1C424B37
	v_dot2_f32_bf16 v16, v56, v39, v16                         // 00000034E714: CC1A4010 1C424F38
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000034E71C: BF8700A1
	v_dot2_f32_bf16 v16, v57, v6, v16                          // 00000034E720: CC1A4010 1C420D39
	s_waitcnt vmcnt(0)                                         // 00000034E728: BF8903F7
	v_dot2_f32_bf16 v16, v58, v42, v16                         // 00000034E72C: CC1A4010 1C42553A
	.long 0xd700003a                                           // 00000034E734: D700003A
	v_cndmask_b32_e32 v0, v62, v10, vcc_lo                     // 00000034E738: 0200153E
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000034E73C: BF8701B2
	v_dot2_f32_bf16 v16, v59, v44, v16                         // 00000034E740: CC1A4010 1C42593B
	v_add_co_ci_u32_e64 v59, null, s11, v63, s0                // 00000034E748: D5207C3B 00027E0B
	.long 0xd7000040                                           // 00000034E750: D7000040
	v_cndmask_b32_e32 v0, v62, v4, vcc_lo                      // 00000034E754: 0200093E
	v_dot2_f32_bf16 v16, v60, v45, v16                         // 00000034E758: CC1A4010 1C425B3C
	v_add_co_ci_u32_e64 v65, null, s5, v63, s0                 // 00000034E760: D5207C41 00027E05
	.long 0xd700003e                                           // 00000034E768: D700003E
	v_cndmask_b32_e32 v0, v62, v16, vcc_lo                     // 00000034E76C: 0200213E
	s_delay_alu instid0(VALU_DEP_3)                            // 00000034E770: BF870003
	v_dot2_f32_bf16 v16, v61, v7, v16                          // 00000034E774: CC1A4010 1C420F3D
	s_clause 0x3                                               // 00000034E77C: BF850003
	global_load_b128 v[46:49], v[58:59], off                   // 00000034E780: DC5E0000 2E7C003A
	global_load_b128 v[50:53], v[58:59], off offset:16         // 00000034E788: DC5E0010 327C003A
	global_load_b128 v[54:57], v[58:59], off offset:32         // 00000034E790: DC5E0020 367C003A
	global_load_b128 v[58:61], v[58:59], off offset:48         // 00000034E798: DC5E0030 3A7C003A
	v_add_co_ci_u32_e64 v63, null, s14, v63, s0                // 00000034E7A0: D5207C3F 00027E0E
	v_add_f32_e32 v25, v25, v16                                // 00000034E7A8: 06322119
	s_waitcnt vmcnt(3)                                         // 00000034E7AC: BF890FF7
	v_dot2_f32_bf16 v16, v46, v38, 0                           // 00000034E7B0: CC1A4010 1A024D2E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034E7B8: BF870091
	v_dot2_f32_bf16 v16, v47, v40, v16                         // 00000034E7BC: CC1A4010 1C42512F
	v_dot2_f32_bf16 v16, v48, v41, v16                         // 00000034E7C4: CC1A4010 1C425330
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000034E7CC: BF8700A1
	v_dot2_f32_bf16 v16, v49, v43, v16                         // 00000034E7D0: CC1A4010 1C425731
	s_waitcnt vmcnt(2)                                         // 00000034E7D8: BF890BF7
	v_dot2_f32_bf16 v16, v50, v4, v16                          // 00000034E7DC: CC1A4010 1C420932
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034E7E4: BF870091
	v_dot2_f32_bf16 v16, v51, v35, v16                         // 00000034E7E8: CC1A4010 1C424733
	v_dot2_f32_bf16 v16, v52, v36, v16                         // 00000034E7F0: CC1A4010 1C424934
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000034E7F8: BF8700A1
	v_dot2_f32_bf16 v16, v53, v5, v16                          // 00000034E7FC: CC1A4010 1C420B35
	s_waitcnt vmcnt(1)                                         // 00000034E804: BF8907F7
	v_dot2_f32_bf16 v16, v54, v15, v16                         // 00000034E808: CC1A4010 1C421F36
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034E810: BF870091
	v_dot2_f32_bf16 v16, v55, v37, v16                         // 00000034E814: CC1A4010 1C424B37
	v_dot2_f32_bf16 v16, v56, v39, v16                         // 00000034E81C: CC1A4010 1C424F38
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000034E824: BF8700A1
	v_dot2_f32_bf16 v16, v57, v6, v16                          // 00000034E828: CC1A4010 1C420D39
	s_waitcnt vmcnt(0)                                         // 00000034E830: BF8903F7
	v_dot2_f32_bf16 v16, v58, v42, v16                         // 00000034E834: CC1A4010 1C42553A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034E83C: BF870091
	v_dot2_f32_bf16 v16, v59, v44, v16                         // 00000034E840: CC1A4010 1C42593B
	v_dot2_f32_bf16 v16, v60, v45, v16                         // 00000034E848: CC1A4010 1C425B3C
	s_delay_alu instid0(VALU_DEP_1)                            // 00000034E850: BF870001
	v_dot2_f32_bf16 v16, v61, v7, v16                          // 00000034E854: CC1A4010 1C420F3D
	s_clause 0x3                                               // 00000034E85C: BF850003
	global_load_b128 v[46:49], v[64:65], off                   // 00000034E860: DC5E0000 2E7C0040
	global_load_b128 v[50:53], v[64:65], off offset:16         // 00000034E868: DC5E0010 327C0040
	global_load_b128 v[54:57], v[64:65], off offset:32         // 00000034E870: DC5E0020 367C0040
	global_load_b128 v[58:61], v[64:65], off offset:48         // 00000034E878: DC5E0030 3A7C0040
	.long 0xd7000040                                           // 00000034E880: D7000040
	v_cndmask_b32_e32 v0, v64, v4, vcc_lo                      // 00000034E884: 02000940
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000034E888: BF8700C1
	v_add_co_ci_u32_e64 v65, null, s5, v65, s0                 // 00000034E88C: D5207C41 00028205
	v_add_f32_e32 v24, v24, v16                                // 00000034E894: 06302118
	s_waitcnt vmcnt(3)                                         // 00000034E898: BF890FF7
	v_dot2_f32_bf16 v16, v46, v38, 0                           // 00000034E89C: CC1A4010 1A024D2E
	v_dot2_f32_bf16 v16, v47, v40, v16                         // 00000034E8A4: CC1A4010 1C42512F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034E8AC: BF870091
	v_dot2_f32_bf16 v16, v48, v41, v16                         // 00000034E8B0: CC1A4010 1C425330
	v_dot2_f32_bf16 v16, v49, v43, v16                         // 00000034E8B8: CC1A4010 1C425731
	s_waitcnt vmcnt(2)                                         // 00000034E8C0: BF890BF7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034E8C4: BF870091
	v_dot2_f32_bf16 v16, v50, v4, v16                          // 00000034E8C8: CC1A4010 1C420932
	v_dot2_f32_bf16 v16, v51, v35, v16                         // 00000034E8D0: CC1A4010 1C424733
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034E8D8: BF870091
	v_dot2_f32_bf16 v16, v52, v36, v16                         // 00000034E8DC: CC1A4010 1C424934
	v_dot2_f32_bf16 v16, v53, v5, v16                          // 00000034E8E4: CC1A4010 1C420B35
	s_waitcnt vmcnt(1)                                         // 00000034E8EC: BF8907F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034E8F0: BF870091
	v_dot2_f32_bf16 v16, v54, v15, v16                         // 00000034E8F4: CC1A4010 1C421F36
	v_dot2_f32_bf16 v16, v55, v37, v16                         // 00000034E8FC: CC1A4010 1C424B37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034E904: BF870091
	v_dot2_f32_bf16 v16, v56, v39, v16                         // 00000034E908: CC1A4010 1C424F38
	v_dot2_f32_bf16 v16, v57, v6, v16                          // 00000034E910: CC1A4010 1C420D39
	s_waitcnt vmcnt(0)                                         // 00000034E918: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034E91C: BF870091
	v_dot2_f32_bf16 v16, v58, v42, v16                         // 00000034E920: CC1A4010 1C42553A
	v_dot2_f32_bf16 v16, v59, v44, v16                         // 00000034E928: CC1A4010 1C42593B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034E930: BF870091
	v_dot2_f32_bf16 v16, v60, v45, v16                         // 00000034E934: CC1A4010 1C425B3C
	v_dot2_f32_bf16 v16, v61, v7, v16                          // 00000034E93C: CC1A4010 1C420F3D
	s_clause 0x3                                               // 00000034E944: BF850003
	global_load_b128 v[46:49], v[62:63], off                   // 00000034E948: DC5E0000 2E7C003E
	global_load_b128 v[50:53], v[62:63], off offset:16         // 00000034E950: DC5E0010 327C003E
	global_load_b128 v[54:57], v[62:63], off offset:32         // 00000034E958: DC5E0020 367C003E
	global_load_b128 v[58:61], v[62:63], off offset:48         // 00000034E960: DC5E0030 3A7C003E
	v_add_f32_e32 v23, v23, v16                                // 00000034E968: 062E2117
	s_waitcnt vmcnt(3)                                         // 00000034E96C: BF890FF7
	v_dot2_f32_bf16 v16, v46, v38, 0                           // 00000034E970: CC1A4010 1A024D2E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034E978: BF870091
	v_dot2_f32_bf16 v16, v47, v40, v16                         // 00000034E97C: CC1A4010 1C42512F
	v_dot2_f32_bf16 v16, v48, v41, v16                         // 00000034E984: CC1A4010 1C425330
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000034E98C: BF8700A1
	v_dot2_f32_bf16 v16, v49, v43, v16                         // 00000034E990: CC1A4010 1C425731
	s_waitcnt vmcnt(2)                                         // 00000034E998: BF890BF7
	v_dot2_f32_bf16 v16, v50, v4, v16                          // 00000034E99C: CC1A4010 1C420932
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034E9A4: BF870091
	v_dot2_f32_bf16 v16, v51, v35, v16                         // 00000034E9A8: CC1A4010 1C424733
	v_dot2_f32_bf16 v16, v52, v36, v16                         // 00000034E9B0: CC1A4010 1C424934
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000034E9B8: BF8700A1
	v_dot2_f32_bf16 v16, v53, v5, v16                          // 00000034E9BC: CC1A4010 1C420B35
	s_waitcnt vmcnt(1)                                         // 00000034E9C4: BF8907F7
	v_dot2_f32_bf16 v16, v54, v15, v16                         // 00000034E9C8: CC1A4010 1C421F36
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034E9D0: BF870091
	v_dot2_f32_bf16 v16, v55, v37, v16                         // 00000034E9D4: CC1A4010 1C424B37
	v_dot2_f32_bf16 v16, v56, v39, v16                         // 00000034E9DC: CC1A4010 1C424F38
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000034E9E4: BF8700A1
	v_dot2_f32_bf16 v16, v57, v6, v16                          // 00000034E9E8: CC1A4010 1C420D39
	s_waitcnt vmcnt(0)                                         // 00000034E9F0: BF8903F7
	v_dot2_f32_bf16 v16, v58, v42, v16                         // 00000034E9F4: CC1A4010 1C42553A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034E9FC: BF870091
	v_dot2_f32_bf16 v16, v59, v44, v16                         // 00000034EA00: CC1A4010 1C42593B
	v_dot2_f32_bf16 v16, v60, v45, v16                         // 00000034EA08: CC1A4010 1C425B3C
	s_delay_alu instid0(VALU_DEP_1)                            // 00000034EA10: BF870001
	v_dot2_f32_bf16 v16, v61, v7, v16                          // 00000034EA14: CC1A4010 1C420F3D
	s_clause 0x3                                               // 00000034EA1C: BF850003
	global_load_b128 v[46:49], v[64:65], off                   // 00000034EA20: DC5E0000 2E7C0040
	global_load_b128 v[50:53], v[64:65], off offset:16         // 00000034EA28: DC5E0010 327C0040
	global_load_b128 v[54:57], v[64:65], off offset:32         // 00000034EA30: DC5E0020 367C0040
	global_load_b128 v[58:61], v[64:65], off offset:48         // 00000034EA38: DC5E0030 3A7C0040
	v_add_f32_e32 v22, v22, v16                                // 00000034EA40: 062C2116
	s_waitcnt vmcnt(3)                                         // 00000034EA44: BF890FF7
	v_dot2_f32_bf16 v16, v46, v38, 0                           // 00000034EA48: CC1A4010 1A024D2E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034EA50: BF870091
	v_dot2_f32_bf16 v16, v47, v40, v16                         // 00000034EA54: CC1A4010 1C42512F
	v_dot2_f32_bf16 v16, v48, v41, v16                         // 00000034EA5C: CC1A4010 1C425330
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000034EA64: BF8700A1
	v_dot2_f32_bf16 v16, v49, v43, v16                         // 00000034EA68: CC1A4010 1C425731
	s_waitcnt vmcnt(2)                                         // 00000034EA70: BF890BF7
	v_dot2_f32_bf16 v16, v50, v4, v16                          // 00000034EA74: CC1A4010 1C420932
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034EA7C: BF870091
	v_dot2_f32_bf16 v16, v51, v35, v16                         // 00000034EA80: CC1A4010 1C424733
	v_dot2_f32_bf16 v16, v52, v36, v16                         // 00000034EA88: CC1A4010 1C424934
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000034EA90: BF8700A1
	v_dot2_f32_bf16 v16, v53, v5, v16                          // 00000034EA94: CC1A4010 1C420B35
	s_waitcnt vmcnt(1)                                         // 00000034EA9C: BF8907F7
	v_dot2_f32_bf16 v16, v54, v15, v16                         // 00000034EAA0: CC1A4010 1C421F36
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034EAA8: BF870091
	v_dot2_f32_bf16 v16, v55, v37, v16                         // 00000034EAAC: CC1A4010 1C424B37
	v_dot2_f32_bf16 v16, v56, v39, v16                         // 00000034EAB4: CC1A4010 1C424F38
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000034EABC: BF8700A1
	v_dot2_f32_bf16 v16, v57, v6, v16                          // 00000034EAC0: CC1A4010 1C420D39
	s_waitcnt vmcnt(0)                                         // 00000034EAC8: BF8903F7
	v_dot2_f32_bf16 v16, v58, v42, v16                         // 00000034EACC: CC1A4010 1C42553A
	.long 0xd700003a                                           // 00000034EAD4: D700003A
	v_cndmask_b32_e32 v0, v62, v4, vcc_lo                      // 00000034EAD8: 0200093E
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000034EADC: BF870122
	v_dot2_f32_bf16 v16, v59, v44, v16                         // 00000034EAE0: CC1A4010 1C42593B
	v_add_co_ci_u32_e64 v59, null, s5, v63, s0                 // 00000034EAE8: D5207C3B 00027E05
	v_dot2_f32_bf16 v16, v60, v45, v16                         // 00000034EAF0: CC1A4010 1C425B3C
	s_delay_alu instid0(VALU_DEP_1)                            // 00000034EAF8: BF870001
	v_dot2_f32_bf16 v16, v61, v7, v16                          // 00000034EAFC: CC1A4010 1C420F3D
	s_clause 0x3                                               // 00000034EB04: BF850003
	global_load_b128 v[46:49], v[58:59], off                   // 00000034EB08: DC5E0000 2E7C003A
	global_load_b128 v[50:53], v[58:59], off offset:16         // 00000034EB10: DC5E0010 327C003A
	global_load_b128 v[54:57], v[58:59], off offset:32         // 00000034EB18: DC5E0020 367C003A
	global_load_b128 v[58:61], v[58:59], off offset:48         // 00000034EB20: DC5E0030 3A7C003A
	v_add_f32_e32 v21, v21, v16                                // 00000034EB28: 062A2115
	s_waitcnt vmcnt(3)                                         // 00000034EB2C: BF890FF7
	v_dot2_f32_bf16 v16, v46, v38, 0                           // 00000034EB30: CC1A4010 1A024D2E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034EB38: BF870091
	v_dot2_f32_bf16 v16, v47, v40, v16                         // 00000034EB3C: CC1A4010 1C42512F
	v_dot2_f32_bf16 v16, v48, v41, v16                         // 00000034EB44: CC1A4010 1C425330
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000034EB4C: BF8700A1
	v_dot2_f32_bf16 v16, v49, v43, v16                         // 00000034EB50: CC1A4010 1C425731
	s_waitcnt vmcnt(2)                                         // 00000034EB58: BF890BF7
	v_dot2_f32_bf16 v16, v50, v4, v16                          // 00000034EB5C: CC1A4010 1C420932
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034EB64: BF870091
	v_dot2_f32_bf16 v16, v51, v35, v16                         // 00000034EB68: CC1A4010 1C424733
	v_dot2_f32_bf16 v16, v52, v36, v16                         // 00000034EB70: CC1A4010 1C424934
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000034EB78: BF8700A1
	v_dot2_f32_bf16 v16, v53, v5, v16                          // 00000034EB7C: CC1A4010 1C420B35
	s_waitcnt vmcnt(1)                                         // 00000034EB84: BF8907F7
	v_dot2_f32_bf16 v16, v54, v15, v16                         // 00000034EB88: CC1A4010 1C421F36
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034EB90: BF870091
	v_dot2_f32_bf16 v16, v55, v37, v16                         // 00000034EB94: CC1A4010 1C424B37
	v_dot2_f32_bf16 v16, v56, v39, v16                         // 00000034EB9C: CC1A4010 1C424F38
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000034EBA4: BF8700A1
	v_dot2_f32_bf16 v16, v57, v6, v16                          // 00000034EBA8: CC1A4010 1C420D39
	s_waitcnt vmcnt(0)                                         // 00000034EBB0: BF8903F7
	v_dot2_f32_bf16 v16, v58, v42, v16                         // 00000034EBB4: CC1A4010 1C42553A
	.long 0xd700003a                                           // 00000034EBBC: D700003A
	v_cndmask_b32_e32 v0, v64, v4, vcc_lo                      // 00000034EBC0: 02000940
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000034EBC4: BF870122
	v_dot2_f32_bf16 v16, v59, v44, v16                         // 00000034EBC8: CC1A4010 1C42593B
	v_add_co_ci_u32_e64 v59, null, s5, v65, s0                 // 00000034EBD0: D5207C3B 00028205
	v_dot2_f32_bf16 v16, v60, v45, v16                         // 00000034EBD8: CC1A4010 1C425B3C
	s_delay_alu instid0(VALU_DEP_1)                            // 00000034EBE0: BF870001
	v_dot2_f32_bf16 v16, v61, v7, v16                          // 00000034EBE4: CC1A4010 1C420F3D
	s_clause 0x3                                               // 00000034EBEC: BF850003
	global_load_b128 v[46:49], v[58:59], off                   // 00000034EBF0: DC5E0000 2E7C003A
	global_load_b128 v[50:53], v[58:59], off offset:16         // 00000034EBF8: DC5E0010 327C003A
	global_load_b128 v[54:57], v[58:59], off offset:32         // 00000034EC00: DC5E0020 367C003A
	global_load_b128 v[58:61], v[58:59], off offset:48         // 00000034EC08: DC5E0030 3A7C003A
	v_add_f32_e32 v20, v20, v16                                // 00000034EC10: 06282114
	s_waitcnt vmcnt(3)                                         // 00000034EC14: BF890FF7
	v_dot2_f32_bf16 v16, v46, v38, 0                           // 00000034EC18: CC1A4010 1A024D2E
	v_mov_b32_e32 v46, v34                                     // 00000034EC20: 7E5C0322
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034EC24: BF870092
	v_dot2_f32_bf16 v16, v47, v40, v16                         // 00000034EC28: CC1A4010 1C42512F
	v_dot2_f32_bf16 v16, v48, v41, v16                         // 00000034EC30: CC1A4010 1C425330
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000034EC38: BF8700A1
	v_dot2_f32_bf16 v16, v49, v43, v16                         // 00000034EC3C: CC1A4010 1C425731
	s_waitcnt vmcnt(2)                                         // 00000034EC44: BF890BF7
	v_dot2_f32_bf16 v4, v50, v4, v16                           // 00000034EC48: CC1A4004 1C420932
	v_mov_b32_e32 v16, v14                                     // 00000034EC50: 7E20030E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034EC54: BF870092
	v_dot2_f32_bf16 v4, v51, v35, v4                           // 00000034EC58: CC1A4004 1C124733
	v_dot2_f32_bf16 v4, v52, v36, v4                           // 00000034EC60: CC1A4004 1C124934
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000034EC68: BF870131
	v_dot2_f32_bf16 v4, v53, v5, v4                            // 00000034EC6C: CC1A4004 1C120B35
	v_mov_b32_e32 v5, v1                                       // 00000034EC74: 7E0A0301
	s_waitcnt vmcnt(1)                                         // 00000034EC78: BF8907F7
	v_dot2_f32_bf16 v4, v54, v15, v4                           // 00000034EC7C: CC1A4004 1C121F36
	v_mov_b32_e32 v15, v13                                     // 00000034EC84: 7E1E030D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034EC88: BF870092
	v_dot2_f32_bf16 v4, v55, v37, v4                           // 00000034EC8C: CC1A4004 1C124B37
	v_dot2_f32_bf16 v4, v56, v39, v4                           // 00000034EC94: CC1A4004 1C124F38
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000034EC9C: BF870131
	v_dot2_f32_bf16 v4, v57, v6, v4                            // 00000034ECA0: CC1A4004 1C120D39
	v_mov_b32_e32 v6, v2                                       // 00000034ECA8: 7E0C0302
	s_waitcnt vmcnt(0)                                         // 00000034ECAC: BF8903F7
	v_dot2_f32_bf16 v4, v58, v42, v4                           // 00000034ECB0: CC1A4004 1C12553A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034ECB8: BF870091
	v_dot2_f32_bf16 v4, v59, v44, v4                           // 00000034ECBC: CC1A4004 1C12593B
	v_dot2_f32_bf16 v4, v60, v45, v4                           // 00000034ECC4: CC1A4004 1C125B3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034ECCC: BF870091
	v_dot2_f32_bf16 v4, v61, v7, v4                            // 00000034ECD0: CC1A4004 1C120F3D
	v_dual_mov_b32 v7, v3 :: v_dual_add_f32 v18, v18, v4       // 00000034ECD8: CA080103 07120912
	v_mov_b32_e32 v4, v0                                       // 00000034ECE0: 7E080300
	s_and_not1_b32 exec_lo, exec_lo, s15                       // 00000034ECE4: 917E0F7E
	s_cbranch_execz 38                                         // 00000034ECE8: BFA50026 <_ZN7halogen12_GLOBAL__N_16k_lq6wILi7ELi16ELi1EEEvPKhPKtPtll+0x1284>
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000034ECEC: BF8701B1
	v_dual_mov_b32 v0, v4 :: v_dual_add_nc_u32 v33, 16, v33    // 00000034ECF0: CA200104 00204290
	v_dual_mov_b32 v1, v5 :: v_dual_mov_b32 v2, v6             // 00000034ECF8: CA100105 01020106
	v_dual_mov_b32 v3, v7 :: v_dual_mov_b32 v14, v16           // 00000034ED00: CA100107 030E0110
	.long 0xd4430000                                           // 00000034ED08: D4430000
	v_cndmask_b32_e32 v1, s12, v33, vcc_lo                     // 00000034ED0C: 0202420C
	v_mov_b32_e32 v13, v15                                     // 00000034ED10: 7E1A030F
	s_mov_b32 s17, exec_lo                                     // 00000034ED14: BE91007E
	.long 0xd4c4007e                                           // 00000034ED18: D4C4007E
	v_cndmask_b32_e32 v1, s12, v33, vcc_lo                     // 00000034ED1C: 0202420C
	s_cbranch_execz 64525                                      // 00000034ED20: BFA5FC0D <_ZN7halogen12_GLOBAL__N_16k_lq6wILi7ELi16ELi1EEEvPKhPKtPtll+0x258>
	v_and_b32_e32 v2, 0x7ffffffc, v32                          // 00000034ED24: 360440FF 7FFFFFFC
	.long 0xd7000100                                           // 00000034ED2C: D7000100
	v_cndmask_b32_e32 v1, v10, v30, vcc_lo                     // 00000034ED30: 02023D0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000034ED34: BF8700A1
	v_add_co_ci_u32_e64 v1, null, 0, v19, s1                   // 00000034ED38: D5207C01 00062680
	.long 0xd700010d                                           // 00000034ED40: D700010D
	v_cndmask_b32_e32 v1, v26, v31, vcc_lo                     // 00000034ED44: 02023F1A
	v_add_co_ci_u32_e64 v14, null, 0, v27, s1                  // 00000034ED48: D5207C0E 00063680
	.long 0xd7000122                                           // 00000034ED50: D7000122
	v_cndmask_b32_e32 v1, v28, v2, vcc_lo                      // 00000034ED54: 0202051C
	s_delay_alu instid0(VALU_DEP_1)                            // 00000034ED58: BF870001
	v_add_co_ci_u32_e64 v35, null, 0, v29, s1                  // 00000034ED5C: D5207C23 00063A80
	s_clause 0x2                                               // 00000034ED64: BF850002
	global_load_b128 v[0:3], v[0:1], off                       // 00000034ED68: DC5E0000 007C0000
	global_load_b64 v[13:14], v[13:14], off                    // 00000034ED70: DC560000 0D7C000D
	global_load_b32 v34, v[34:35], off                         // 00000034ED78: DC520000 227C0022
	s_branch 64501                                             // 00000034ED80: BFA0FBF5 <_ZN7halogen12_GLOBAL__N_16k_lq6wILi7ELi16ELi1EEEvPKhPKtPtll+0x258>
	s_or_b32 exec_lo, exec_lo, s15                             // 00000034ED84: 8C7E0F7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000034ED88: BF8700A9
	s_or_b32 exec_lo, exec_lo, s13                             // 00000034ED8C: 8C7E0D7E
	.long 0xd71f0000                                           // 00000034ED90: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 00000034ED94: 020100C1
	v_xor_b32_e32 v1, 8, v0                                    // 00000034ED98: 3A020088
	v_xor_b32_e32 v10, 4, v0                                   // 00000034ED9C: 3A140084
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034EDA0: BF870092
	.long 0xd44c0000                                           // 00000034EDA4: D44C0000
	v_cndmask_b32_e32 v1, 32, v1, vcc_lo                       // 00000034EDA8: 020202A0
	v_cndmask_b32_e64 v1, v0, v1, s0                           // 00000034EDAC: D5010001 00020300
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000034EDB4: BF870113
	.long 0xd44c0000                                           // 00000034EDB8: D44C0000
	v_cndmask_b32_e32 v1, 32, v10, vcc_lo                      // 00000034EDBC: 020214A0
	v_lshlrev_b32_e32 v1, 2, v1                                // 00000034EDC0: 30020282
	s_delay_alu instid0(VALU_DEP_2)                            // 00000034EDC4: BF870002
	v_cndmask_b32_e64 v10, v0, v10, s0                         // 00000034EDC8: D501000A 00021500
	ds_bpermute_b32 v2, v1, v18                                // 00000034EDD0: DACC0000 02001201
	s_waitcnt lgkmcnt(0)                                       // 00000034EDD8: BF89FC07
	v_add_f32_e32 v2, v18, v2                                  // 00000034EDDC: 06040512
	ds_bpermute_b32 v3, v1, v24                                // 00000034EDE0: DACC0000 03001801
	s_waitcnt vmcnt(2)                                         // 00000034EDE8: BF890BF7
	ds_bpermute_b32 v4, v1, v25                                // 00000034EDEC: DACC0000 04001901
	ds_bpermute_b32 v5, v1, v22                                // 00000034EDF4: DACC0000 05001601
	ds_bpermute_b32 v6, v1, v23                                // 00000034EDFC: DACC0000 06001701
	ds_bpermute_b32 v7, v1, v20                                // 00000034EE04: DACC0000 07001401
	ds_bpermute_b32 v1, v1, v21                                // 00000034EE0C: DACC0000 01001501
	v_lshlrev_b32_e32 v10, 2, v10                              // 00000034EE14: 30141482
	v_xor_b32_e32 v18, 2, v0                                   // 00000034EE18: 3A240082
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034EE1C: BF870091
	.long 0xd44c0000                                           // 00000034EE20: D44C0000
	v_cndmask_b32_e32 v1, 32, v18, vcc_lo                      // 00000034EE24: 020224A0
	v_cndmask_b32_e64 v18, v0, v18, s0                         // 00000034EE28: D5010012 00022500
	s_waitcnt lgkmcnt(5)                                       // 00000034EE30: BF89FC57
	v_add_f32_e32 v3, v24, v3                                  // 00000034EE34: 06060718
	ds_bpermute_b32 v11, v10, v2                               // 00000034EE38: DACC0000 0B00020A
	s_waitcnt lgkmcnt(4)                                       // 00000034EE40: BF89FC47
	v_dual_add_f32 v4, v25, v4 :: v_dual_add_f32 v5, v22, v5   // 00000034EE44: C9080919 04040B16
	s_waitcnt lgkmcnt(2)                                       // 00000034EE4C: BF89FC27
	v_dual_add_f32 v6, v23, v6 :: v_dual_add_f32 v7, v20, v7   // 00000034EE50: C9080D17 06060F14
	ds_bpermute_b32 v12, v10, v3                               // 00000034EE58: DACC0000 0C00030A
	s_waitcnt lgkmcnt(2)                                       // 00000034EE60: BF89FC27
	v_dual_add_f32 v1, v21, v1 :: v_dual_lshlrev_b32 v18, 2, v18// 00000034EE64: C9220315 01122482
	ds_bpermute_b32 v13, v10, v4                               // 00000034EE6C: DACC0000 0D00040A
	ds_bpermute_b32 v14, v10, v5                               // 00000034EE74: DACC0000 0E00050A
	s_waitcnt vmcnt(1)                                         // 00000034EE7C: BF8907F7
	ds_bpermute_b32 v15, v10, v6                               // 00000034EE80: DACC0000 0F00060A
	ds_bpermute_b32 v16, v10, v7                               // 00000034EE88: DACC0000 1000070A
	ds_bpermute_b32 v10, v10, v1                               // 00000034EE90: DACC0000 0A00010A
	s_waitcnt lgkmcnt(5)                                       // 00000034EE98: BF89FC57
	v_dual_add_f32 v2, v2, v11 :: v_dual_add_f32 v3, v3, v12   // 00000034EE9C: C9081702 02021903
	v_xor_b32_e32 v12, 1, v0                                   // 00000034EEA4: 3A180081
	s_waitcnt lgkmcnt(3)                                       // 00000034EEA8: BF89FC37
	v_dual_add_f32 v4, v4, v13 :: v_dual_add_f32 v5, v5, v14   // 00000034EEAC: C9081B04 04041D05
	s_waitcnt lgkmcnt(1)                                       // 00000034EEB4: BF89FC17
	v_dual_add_f32 v6, v6, v15 :: v_dual_add_f32 v7, v7, v16   // 00000034EEB8: C9081F06 06062107
	.long 0xd44c0000                                           // 00000034EEC0: D44C0000
	v_cndmask_b32_e32 v1, 32, v12, vcc_lo                      // 00000034EEC4: 020218A0
	ds_bpermute_b32 v11, v18, v4                               // 00000034EEC8: DACC0000 0B000412
	ds_bpermute_b32 v14, v18, v5                               // 00000034EED0: DACC0000 0E000512
	ds_bpermute_b32 v15, v18, v6                               // 00000034EED8: DACC0000 0F000612
	ds_bpermute_b32 v16, v18, v7                               // 00000034EEE0: DACC0000 10000712
	v_cndmask_b32_e64 v0, v0, v12, s0                          // 00000034EEE8: D5010000 00021900
	s_waitcnt lgkmcnt(4)                                       // 00000034EEF0: BF89FC47
	v_add_f32_e32 v1, v1, v10                                  // 00000034EEF4: 06021501
	ds_bpermute_b32 v10, v18, v3                               // 00000034EEF8: DACC0000 0A000312
	.long 0xd44a0000                                           // 00000034EF00: D44A0000
	v_cndmask_b32_e32 v1, 0, v17, vcc_lo                       // 00000034EF04: 02022280
	v_lshlrev_b32_e32 v20, 2, v0                               // 00000034EF08: 30280082
	ds_bpermute_b32 v19, v18, v1                               // 00000034EF0C: DACC0000 13000112
	ds_bpermute_b32 v18, v18, v2                               // 00000034EF14: DACC0000 12000212
	s_and_b32 s0, s0, vcc_lo                                   // 00000034EF1C: 8B006A00
	s_waitcnt lgkmcnt(5)                                       // 00000034EF20: BF89FC57
	v_dual_add_f32 v13, v4, v11 :: v_dual_add_f32 v4, v5, v14  // 00000034EF24: C9081704 0D041D05
	s_waitcnt lgkmcnt(3)                                       // 00000034EF2C: BF89FC37
	v_dual_add_f32 v5, v6, v15 :: v_dual_add_f32 v0, v7, v16   // 00000034EF30: C9081F06 05002107
	ds_bpermute_b32 v14, v20, v13                              // 00000034EF38: DACC0000 0E000D14
	s_waitcnt lgkmcnt(3)                                       // 00000034EF40: BF89FC37
	v_add_f32_e32 v12, v3, v10                                 // 00000034EF44: 06181503
	ds_bpermute_b32 v6, v20, v5                                // 00000034EF48: DACC0000 06000514
	ds_bpermute_b32 v7, v20, v4                                // 00000034EF50: DACC0000 07000414
	s_waitcnt lgkmcnt(3)                                       // 00000034EF58: BF89FC37
	v_dual_add_f32 v1, v1, v19 :: v_dual_add_f32 v10, v2, v18  // 00000034EF5C: C9082701 010A2502
	ds_bpermute_b32 v15, v20, v12                              // 00000034EF64: DACC0000 0F000C14
	ds_bpermute_b32 v3, v20, v0                                // 00000034EF6C: DACC0000 03000014
	ds_bpermute_b32 v2, v20, v1                                // 00000034EF74: DACC0000 02000114
	ds_bpermute_b32 v11, v20, v10                              // 00000034EF7C: DACC0000 0B000A14
	s_and_saveexec_b32 s1, s0                                  // 00000034EF84: BE812000
	s_cbranch_execz 102                                        // 00000034EF88: BFA50066 <_ZN7halogen12_GLOBAL__N_16k_lq6wILi7ELi16ELi1EEEvPKhPKtPtll+0x1624>
	s_waitcnt lgkmcnt(3)                                       // 00000034EF8C: BF89FC37
	v_dual_add_f32 v12, v12, v15 :: v_dual_add_f32 v13, v13, v14// 00000034EF90: C9081F0C 0C0C1D0D
	.long 0x7f1c3880                                           // 00000034EF98: 7F1C3880
	.long 0xd73c0008                                           // 00000034EF9C: D73C0008
	v_cndmask_b32_e32 v1, 1, v8, vcc_lo                        // 00000034EFA0: 02021081
	s_lshl_b64 s[0:1], s[2:3], 1                               // 00000034EFA4: 84808102
	s_delay_alu instid0(VALU_DEP_3)                            // 00000034EFA8: BF870003
	.long 0x7e1c398c                                           // 00000034EFAC: 7E1C398C
	.long 0x7e1e398d                                           // 00000034EFB0: 7E1E398D
	.long 0x7f1e398e                                           // 00000034EFB4: 7F1E398E
	s_waitcnt lgkmcnt(0)                                       // 00000034EFB8: BF89FC07
	v_add_f32_e32 v10, v10, v11                                // 00000034EFBC: 0614170A
	.long 0xd7006a08                                           // 00000034EFC0: D7006A08
	v_cndmask_b32_e32 v1, s8, v8, vcc_lo                       // 00000034EFC4: 02021008
	v_dual_add_f32 v7, v4, v7 :: v_dual_and_b32 v16, 1, v14    // 00000034EFC8: C9240F04 07101C81
	v_dual_add_f32 v6, v5, v6 :: v_dual_and_b32 v15, 1, v15    // 00000034EFD0: C9240D05 060E1E81
	v_add_co_ci_u32_e64 v9, null, s9, v9, vcc_lo               // 00000034EFD8: D5207C09 01AA1209
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000034EFE0: BF870223
	v_add3_u32 v16, v12, v16, 0x7fff                           // 00000034EFE4: D6550010 03FE210C 00007FFF
	.long 0xd7006a0c                                           // 00000034EFF0: D7006A0C
	v_cndmask_b32_e32 v0, v8, v0, vcc_lo                       // 00000034EFF4: 02000108
	v_add3_u32 v15, v13, v15, 0x7fff                           // 00000034EFF8: D655000F 03FE1F0D 00007FFF
	s_delay_alu instid0(VALU_DEP_4)                            // 00000034F004: BF870004
	v_add_co_ci_u32_e64 v13, null, s1, v9, vcc_lo              // 00000034F008: D5207C0D 01AA1201
	s_clause 0x1                                               // 00000034F010: BF850001
	global_store_d16_hi_b16 v[8:9], v15, off                   // 00000034F014: DC960000 007C0F08
	global_store_d16_hi_b16 v[12:13], v16, off                 // 00000034F01C: DC960000 007C100C
	.long 0x7e1c3987                                           // 00000034F024: 7E1C3987
	v_add_f32_e32 v13, v1, v2                                  // 00000034F028: 061A0501
	s_lshl_b64 s[0:1], s[2:3], 2                               // 00000034F02C: 84808202
	.long 0x7e163986                                           // 00000034F030: 7E163986
	.long 0xd7006a04                                           // 00000034F034: D7006A04
	v_cndmask_b32_e32 v0, v8, v0, vcc_lo                       // 00000034F038: 02000108
	.long 0x7f16398e                                           // 00000034F03C: 7F16398E
	v_add_f32_e32 v12, v0, v3                                  // 00000034F040: 06180700
	v_mad_u64_u32 v[0:1], null, s2, 6, v[8:9]                  // 00000034F044: D6FE7C00 04210C02
	v_and_b32_e32 v2, 1, v14                                   // 00000034F04C: 36041C81
	.long 0x7e10398d                                           // 00000034F050: 7E10398D
	.long 0x7f10398e                                           // 00000034F054: 7F10398E
	v_and_b32_e32 v3, 1, v11                                   // 00000034F058: 36061681
	v_add_co_ci_u32_e64 v5, null, s1, v9, vcc_lo               // 00000034F05C: D5207C05 01AA1201
	v_add3_u32 v11, v7, v2, 0x7fff                             // 00000034F064: D655000B 03FE0507 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 00000034F070: BF870254
	v_and_b32_e32 v7, 1, v8                                    // 00000034F074: 360E1081
	.long 0x7e1c398c                                           // 00000034F078: 7E1C398C
	v_mad_u64_u32 v[1:2], null, s3, 6, v[1:2]                  // 00000034F07C: D6FE7C01 04050C03
	v_add3_u32 v15, v6, v3, 0x7fff                             // 00000034F084: D655000F 03FE0706 00007FFF
	.long 0xd7006a02                                           // 00000034F090: D7006A02
	v_cndmask_b32_e32 v0, v4, v0, vcc_lo                       // 00000034F094: 02000104
	v_and_b32_e32 v6, 1, v14                                   // 00000034F098: 360C1C81
	v_bfe_u32 v8, v10, 16, 1                                   // 00000034F09C: D6100008 0205210A
	v_add_co_ci_u32_e64 v3, null, s1, v5, vcc_lo               // 00000034F0A4: D5207C03 01AA0A01
	v_add3_u32 v13, v13, v7, 0x7fff                            // 00000034F0AC: D655000D 03FE0F0D 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000034F0B8: BF8700A4
	v_add3_u32 v12, v12, v6, 0x7fff                            // 00000034F0BC: D655000C 03FE0D0C 00007FFF
	.long 0xd7006a06                                           // 00000034F0C8: D7006A06
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 00000034F0CC: 02000100
	v_add_co_ci_u32_e64 v7, null, s1, v1, vcc_lo               // 00000034F0D0: D5207C07 01AA0201
	v_add3_u32 v10, v10, v8, 0x7fff                            // 00000034F0D8: D655000A 03FE110A 00007FFF
	.long 0xd7006a08                                           // 00000034F0E4: D7006A08
	v_cndmask_b32_e32 v0, v2, v0, vcc_lo                       // 00000034F0E8: 02000102
	s_delay_alu instid0(VALU_DEP_1)                            // 00000034F0EC: BF870001
	v_add_co_ci_u32_e64 v9, null, s1, v3, vcc_lo               // 00000034F0F0: D5207C09 01AA0601
	s_clause 0x4                                               // 00000034F0F8: BF850004
	global_store_d16_hi_b16 v[4:5], v15, off                   // 00000034F0FC: DC960000 007C0F04
	global_store_d16_hi_b16 v[0:1], v11, off                   // 00000034F104: DC960000 007C0B00
	global_store_d16_hi_b16 v[2:3], v13, off                   // 00000034F10C: DC960000 007C0D02
	global_store_d16_hi_b16 v[6:7], v12, off                   // 00000034F114: DC960000 007C0C06
	global_store_d16_hi_b16 v[8:9], v10, off                   // 00000034F11C: DC960000 007C0A08
	s_endpgm                                                   // 00000034F124: BFB00000
		...

