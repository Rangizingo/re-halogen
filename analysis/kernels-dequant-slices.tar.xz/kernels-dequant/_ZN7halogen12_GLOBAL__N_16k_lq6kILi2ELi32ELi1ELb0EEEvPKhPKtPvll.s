0000000000599c00 <_ZN7halogen12_GLOBAL__N_16k_lq6kILi2ELi32ELi1ELb0EEEvPKhPKtPvll>:
; _ZN7halogen12_GLOBAL__N_16k_lq6kILi2ELi32ELi1ELb0EEEvPKhPKtPvll():
	s_clause 0x1                                               // 000000599C00: BF850001
	s_load_b256 s[4:11], s[0:1], null                          // 000000599C04: F40C0100 F8000000
	s_load_b64 s[12:13], s[0:1], 0x20                          // 000000599C0C: F4040300 F8000020
	s_mov_b32 s3, 0                                            // 000000599C14: BE830080
	v_lshrrev_b32_e32 v1, 5, v0                                // 000000599C18: 32020085
	s_lshl_b64 s[0:1], s[2:3], 3                               // 000000599C1C: 84808302
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000599C20: BF8701A9
	v_dual_mov_b32 v2, s1 :: v_dual_and_b32 v7, 31, v0         // 000000599C24: CA240001 0206009F
	v_dual_mov_b32 v8, 0 :: v_dual_mov_b32 v9, 0               // 000000599C2C: CA100080 08080080
	v_or_b32_e32 v1, s0, v1                                    // 000000599C34: 38020200
	s_waitcnt lgkmcnt(0)                                       // 000000599C38: BF89FC07
	s_ashr_i32 s1, s11, 31                                     // 000000599C3C: 86019F0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000599C40: BF8704A1
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[1:2]                  // 000000599C44: 7CA8020C
	s_lshr_b32 s1, s1, 28                                      // 000000599C48: 85019C01
	s_add_u32 s0, s10, s1                                      // 000000599C4C: 8000010A
	s_addc_u32 s1, s11, 0                                      // 000000599C50: 8201800B
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000599C54: BF870009
	s_lshr_b64 s[14:15], s[0:1], 4                             // 000000599C58: 858E8400
	s_mov_b32 s1, exec_lo                                      // 000000599C5C: BE81007E
	.long 0xd4c4007e                                           // 000000599C60: D4C4007E
	v_cndmask_b32_e32 v1, s14, v7, vcc_lo                      // 000000599C64: 02020E0E
	s_cbranch_execz 400                                        // 000000599C68: BFA50190 <_ZN7halogen12_GLOBAL__N_16k_lq6kILi2ELi32ELi1ELb0EEEvPKhPKtPvll+0x6ac>
	s_ashr_i32 s0, s11, 31                                     // 000000599C6C: 86009F0B
	v_dual_cndmask_b32 v3, 0, v2 :: v_dual_and_b32 v10, 6, v0  // 000000599C70: CA640480 030A0086
	s_lshr_b32 s0, s0, 24                                      // 000000599C78: 85009800
	v_cndmask_b32_e32 v5, 0, v1, vcc_lo                        // 000000599C7C: 020A0280
	s_add_u32 s16, s10, s0                                     // 000000599C80: 8010000A
	s_addc_u32 s17, s11, 0                                     // 000000599C84: 8211800B
	v_bfe_u32 v9, v0, 3, 1                                     // 000000599C88: D6100009 02050700
	s_ashr_i64 s[16:17], s[16:17], 8                           // 000000599C90: 86908810
	v_dual_mov_b32 v6, 0 :: v_dual_and_b32 v11, 4, v0          // 000000599C94: CA240080 060A0084
	s_mul_i32 s0, s17, 0xd2                                    // 000000599C9C: 9600FF11 000000D2
	s_mul_hi_u32 s2, s16, 0xd2                                 // 000000599CA4: 9682FF10 000000D2
	s_mul_i32 s15, s16, 0xd2                                   // 000000599CAC: 960FFF10 000000D2
	s_add_i32 s2, s2, s0                                       // 000000599CB4: 81020002
	.long 0xd72c0008                                           // 000000599CB8: D72C0008
	v_cndmask_b32_e32 v1, s15, v3, vcc_lo                      // 000000599CBC: 0202060F
	v_and_b32_e32 v0, 15, v0                                   // 000000599CC0: 3600008F
	v_mad_u64_u32 v[3:4], null, s15, v5, s[4:5]                // 000000599CC4: D6FE7C03 00120A0F
	.long 0xd72c0005                                           // 000000599CCC: D72C0005
	v_cndmask_b32_e32 v1, s2, v5, vcc_lo                       // 000000599CD0: 02020A02
	v_dual_mov_b32 v21, v7 :: v_dual_lshlrev_b32 v12, 6, v9    // 000000599CD4: CA220107 150C1286
	v_lshlrev_b32_e32 v13, 5, v9                               // 000000599CDC: 301A1285
	v_or_b32_e32 v14, 8, v11                                   // 000000599CE0: 381C1688
	v_or_b32_e32 v15, 8, v10                                   // 000000599CE4: 381E1488
	v_or_b32_e32 v16, 16, v11                                  // 000000599CE8: 38201690
	v_or_b32_e32 v17, 16, v10                                  // 000000599CEC: 38221490
	v_add3_u32 v4, v5, v4, v8                                  // 000000599CF0: D6550004 04220905
	v_lshrrev_b32_e32 v8, 4, v7                                // 000000599CF8: 32100E84
	v_or_b32_e32 v18, 24, v11                                  // 000000599CFC: 38241698
	v_or_b32_e32 v19, 24, v10                                  // 000000599D00: 38261498
	v_lshlrev_b32_e32 v5, 4, v7                                // 000000599D04: 300A0E84
	v_mov_b32_e32 v9, v6                                       // 000000599D08: 7E120306
	v_mul_u32_u24_e32 v20, 0xd2, v8                            // 000000599D0C: 162810FF 000000D2
	v_mov_b32_e32 v8, v6                                       // 000000599D14: 7E100306
	s_lshl_b64 s[4:5], s[10:11], 1                             // 000000599D18: 8484810A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000599D1C: BF870092
	.long 0xd700001e                                           // 000000599D20: D700001E
	v_cndmask_b32_e32 v1, v3, v20, vcc_lo                      // 000000599D24: 02022903
	v_add_co_ci_u32_e64 v31, null, 0, v4, s0                   // 000000599D28: D5207C1F 00020880
	v_and_b32_e32 v26, 16, v5                                  // 000000599D30: 36340A90
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000599D34: BF870093
	.long 0xd700001c                                           // 000000599D38: D700001C
	v_cndmask_b32_e32 v1, v30, v12, vcc_lo                     // 000000599D3C: 0202191E
	v_add_co_ci_u32_e64 v29, null, 0, v31, s0                  // 000000599D40: D5207C1D 00023E80
	.long 0xd7000018                                           // 000000599D48: D7000018
	v_cndmask_b32_e32 v1, v30, v13, vcc_lo                     // 000000599D4C: 02021B1E
	v_and_b32_e32 v27, 32, v5                                  // 000000599D50: 36360AA0
	v_add_co_ci_u32_e64 v25, null, 0, v31, s0                  // 000000599D54: D5207C19 00023E80
	.long 0xd7000016                                           // 000000599D5C: D7000016
	v_cndmask_b32_e32 v1, v30, v0, vcc_lo                      // 000000599D60: 0202011E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000599D64: BF8700A1
	v_add_co_ci_u32_e64 v23, null, 0, v31, s0                  // 000000599D68: D5207C17 00023E80
	.long 0xd7000018                                           // 000000599D70: D7000018
	v_cndmask_b32_e32 v1, v24, v26, vcc_lo                     // 000000599D74: 02023518
	v_add_co_ci_u32_e64 v25, null, 0, v25, s0                  // 000000599D78: D5207C19 00023280
	.long 0xd700001b                                           // 000000599D80: D700001B
	v_cndmask_b32_e32 v1, v28, v27, vcc_lo                     // 000000599D84: 0202371C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000599D88: BF8700D1
	v_add_co_ci_u32_e64 v28, null, 0, v29, s0                  // 000000599D8C: D5207C1C 00023A80
	s_clause 0x1                                               // 000000599D94: BF850001
	global_load_i8 v46, v[22:23], off offset:192               // 000000599D98: DC4600C0 2E7C0016
	global_load_b128 v[22:25], v[24:25], off offset:128        // 000000599DA0: DC5E0080 167C0018
	.long 0xd700001a                                           // 000000599DA8: D700001A
	v_cndmask_b32_e32 v1, v27, v26, vcc_lo                     // 000000599DAC: 0202351B
	v_add_co_ci_u32_e64 v27, null, 0, v28, s0                  // 000000599DB0: D5207C1B 00023880
	s_clause 0x1                                               // 000000599DB8: BF850001
	global_load_b128 v[26:29], v[26:27], off                   // 000000599DBC: DC5E0000 1A7C001A
	global_load_d16_b16 v47, v[30:31], off offset:208          // 000000599DC4: DC8200D0 2F7C001E
	.long 0xd73c001e                                           // 000000599DCC: D73C001E
	v_cndmask_b32_e32 v1, 1, v5, vcc_lo                        // 000000599DD0: 02020A81
	v_add_nc_u32_e32 v21, 32, v21                              // 000000599DD4: 4A2A2AA0
	v_add_nc_u32_e32 v5, 0x200, v5                             // 000000599DD8: 4A0A0AFF 00000200
	v_add_nc_u32_e32 v20, 0x1a4, v20                           // 000000599DE0: 4A2828FF 000001A4
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000599DE8: BF870094
	.long 0xd7000026                                           // 000000599DEC: D7000026
	v_cndmask_b32_e32 v1, s6, v30, vcc_lo                      // 000000599DF0: 02023C06
	v_add_co_ci_u32_e64 v39, null, s7, v31, s0                 // 000000599DF4: D5207C27 00023E07
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000599DFC: BF870092
	.long 0xd700002a                                           // 000000599E00: D700002A
	v_cndmask_b32_e32 v0, v38, v4, vcc_lo                      // 000000599E04: 02000926
	v_add_co_ci_u32_e64 v43, null, s5, v39, s0                 // 000000599E08: D5207C2B 00024E05
	s_clause 0x3                                               // 000000599E10: BF850003
	global_load_b128 v[30:33], v[38:39], off                   // 000000599E14: DC5E0000 1E7C0026
	global_load_b128 v[34:37], v[42:43], off                   // 000000599E1C: DC5E0000 227C002A
	global_load_b128 v[38:41], v[38:39], off offset:16         // 000000599E24: DC5E0010 267C0026
	global_load_b128 v[42:45], v[42:43], off offset:16         // 000000599E2C: DC5E0010 2A7C002A
	.long 0xd4430000                                           // 000000599E34: D4430000
	v_cndmask_b32_e32 v1, s14, v21, vcc_lo                     // 000000599E38: 02022A0E
	s_or_b32 s3, s0, s3                                        // 000000599E3C: 8C030300
	s_waitcnt vmcnt(7)                                         // 000000599E40: BF891FF7
	v_cvt_f32_i32_e32 v46, v46                                 // 000000599E44: 7E5C0B2E
	s_waitcnt vmcnt(6)                                         // 000000599E48: BF891BF7
	v_lshrrev_b32_e32 v51, v10, v23                            // 000000599E4C: 32662F0A
	v_lshrrev_b32_e32 v52, v15, v23                            // 000000599E50: 32682F0F
	v_lshrrev_b32_e32 v53, v17, v23                            // 000000599E54: 326A2F11
	v_lshrrev_b32_e32 v23, v19, v23                            // 000000599E58: 322E2F13
	v_lshrrev_b32_e32 v57, v10, v25                            // 000000599E5C: 3272330A
	v_lshrrev_b32_e32 v58, v15, v25                            // 000000599E60: 3274330F
	v_lshrrev_b32_e32 v59, v17, v25                            // 000000599E64: 32763311
	v_lshrrev_b32_e32 v25, v19, v25                            // 000000599E68: 32323313
	s_waitcnt vmcnt(4)                                         // 000000599E6C: BF8913F7
	v_fma_mix_f32 v46, v47, v46, neg(0) op_sel_hi:[1,0,0]      // 000000599E70: CC20002E 8A025D2F
	v_bfe_u32 v62, v27, v11, 4                                 // 000000599E78: D610003E 0212171B
	v_bfe_u32 v63, v27, v14, 4                                 // 000000599E80: D610003F 02121D1B
	v_bfe_u32 v64, v27, v16, 4                                 // 000000599E88: D6100040 0212211B
	v_bfe_u32 v27, v27, v18, 4                                 // 000000599E90: D610001B 0212251B
	v_lshlrev_b32_e32 v23, 4, v23                              // 000000599E98: 302E2E84
	v_bfe_u32 v68, v29, v11, 4                                 // 000000599E9C: D6100044 0212171D
	v_bfe_u32 v69, v29, v14, 4                                 // 000000599EA4: D6100045 02121D1D
	v_bfe_u32 v70, v29, v16, 4                                 // 000000599EAC: D6100046 0212211D
	v_bfe_u32 v29, v29, v18, 4                                 // 000000599EB4: D610001D 0212251D
	v_lshlrev_b32_e32 v25, 4, v25                              // 000000599EBC: 30323284
	v_and_or_b32 v23, v23, 48, v27                             // 000000599EC0: D6570017 046D6117
	v_lshrrev_b32_e32 v48, v10, v22                            // 000000599EC8: 32602D0A
	v_lshrrev_b32_e32 v49, v15, v22                            // 000000599ECC: 32622D0F
	v_lshrrev_b32_e32 v50, v17, v22                            // 000000599ED0: 32642D11
	v_and_or_b32 v25, v25, 48, v29                             // 000000599ED4: D6570019 04756119
	v_lshrrev_b32_e32 v22, v19, v22                            // 000000599EDC: 322C2D13
	v_subrev_nc_u32_e32 v23, 32, v23                           // 000000599EE0: 4E2E2EA0
	v_lshrrev_b32_e32 v54, v10, v24                            // 000000599EE4: 326C310A
	v_lshrrev_b32_e32 v55, v15, v24                            // 000000599EE8: 326E310F
	v_lshrrev_b32_e32 v56, v17, v24                            // 000000599EEC: 32703111
	v_lshrrev_b32_e32 v24, v19, v24                            // 000000599EF0: 32303113
	v_subrev_nc_u32_e32 v25, 32, v25                           // 000000599EF4: 4E3232A0
	v_bfe_u32 v47, v26, v11, 4                                 // 000000599EF8: D610002F 0212171A
	v_bfe_u32 v60, v26, v14, 4                                 // 000000599F00: D610003C 02121D1A
	v_bfe_u32 v61, v26, v16, 4                                 // 000000599F08: D610003D 0212211A
	v_bfe_u32 v26, v26, v18, 4                                 // 000000599F10: D610001A 0212251A
	v_cvt_f32_i32_e32 v23, v23                                 // 000000599F18: 7E2E0B17
	v_lshlrev_b32_e32 v22, 4, v22                              // 000000599F1C: 302C2C84
	v_bfe_u32 v65, v28, v11, 4                                 // 000000599F20: D6100041 0212171C
	v_lshlrev_b32_e32 v54, 4, v54                              // 000000599F28: 306C6C84
	v_bfe_u32 v66, v28, v14, 4                                 // 000000599F2C: D6100042 02121D1C
	v_bfe_u32 v67, v28, v16, 4                                 // 000000599F34: D6100043 0212211C
	v_bfe_u32 v28, v28, v18, 4                                 // 000000599F3C: D610001C 0212251C
	v_cvt_f32_i32_e32 v25, v25                                 // 000000599F44: 7E320B19
	v_dual_mul_f32 v23, v46, v23 :: v_dual_lshlrev_b32 v24, 4, v24// 000000599F48: C8E22F2E 17183084
	v_and_or_b32 v22, v22, 48, v26                             // 000000599F50: D6570016 04696116
	v_and_or_b32 v27, v54, 48, v65                             // 000000599F58: D657001B 05056136
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000599F60: BF870214
	v_mul_f32_e32 v25, v46, v25                                // 000000599F64: 1032332E
	v_and_or_b32 v24, v24, 48, v28                             // 000000599F68: D6570018 04716118
	v_lshlrev_b32_e32 v48, 4, v48                              // 000000599F70: 30606084
	v_subrev_nc_u32_e32 v22, 32, v22                           // 000000599F74: 4E2C2CA0
	v_subrev_nc_u32_e32 v27, 32, v27                           // 000000599F78: 4E3636A0
	v_lshlrev_b32_e32 v50, 4, v50                              // 000000599F7C: 30646484
	v_subrev_nc_u32_e32 v24, 32, v24                           // 000000599F80: 4E3030A0
	v_lshlrev_b32_e32 v51, 4, v51                              // 000000599F84: 30666684
	v_cvt_f32_i32_e32 v22, v22                                 // 000000599F88: 7E2C0B16
	v_lshlrev_b32_e32 v49, 4, v49                              // 000000599F8C: 30626284
	v_lshlrev_b32_e32 v53, 4, v53                              // 000000599F90: 306A6A84
	v_lshlrev_b32_e32 v56, 4, v56                              // 000000599F94: 30707084
	v_lshlrev_b32_e32 v57, 4, v57                              // 000000599F98: 30727284
	v_lshlrev_b32_e32 v58, 4, v58                              // 000000599F9C: 30747484
	v_lshlrev_b32_e32 v59, 4, v59                              // 000000599FA0: 30767684
	v_and_or_b32 v47, v48, 48, v47                             // 000000599FA4: D657002F 04BD6130
	v_cvt_f32_i32_e32 v27, v27                                 // 000000599FAC: 7E360B1B
	v_lshlrev_b32_e32 v52, 4, v52                              // 000000599FB0: 30686884
	v_cvt_f32_i32_e32 v24, v24                                 // 000000599FB4: 7E300B18
	v_dual_mul_f32 v22, v46, v22 :: v_dual_lshlrev_b32 v55, 4, v55// 000000599FB8: C8E22D2E 16366E84
	v_and_or_b32 v48, v49, 48, v60                             // 000000599FC0: D6570030 04F16131
	v_and_or_b32 v49, v50, 48, v61                             // 000000599FC8: D6570031 04F56132
	v_and_or_b32 v26, v51, 48, v62                             // 000000599FD0: D657001A 04F96133
	v_and_or_b32 v51, v53, 48, v64                             // 000000599FD8: D6570033 05016135
	v_and_or_b32 v53, v56, 48, v67                             // 000000599FE0: D6570035 050D6138
	v_and_or_b32 v28, v57, 48, v68                             // 000000599FE8: D657001C 05116139
	v_and_or_b32 v54, v58, 48, v69                             // 000000599FF0: D6570036 0515613A
	v_subrev_nc_u32_e32 v29, 32, v47                           // 000000599FF8: 4E3A5EA0
	v_mul_f32_e32 v27, v46, v27                                // 000000599FFC: 1036372E
	v_and_or_b32 v50, v52, 48, v63                             // 00000059A000: D6570032 04FD6134
	v_mul_f32_e32 v24, v46, v24                                // 00000059A008: 1030312E
	v_and_or_b32 v52, v55, 48, v66                             // 00000059A00C: D6570034 05096137
	v_and_or_b32 v55, v59, 48, v70                             // 00000059A014: D6570037 0519613B
	v_subrev_nc_u32_e32 v47, 32, v48                           // 00000059A01C: 4E5E60A0
	v_subrev_nc_u32_e32 v48, 32, v49                           // 00000059A020: 4E6062A0
	v_subrev_nc_u32_e32 v26, 32, v26                           // 00000059A024: 4E3434A0
	v_subrev_nc_u32_e32 v49, 32, v50                           // 00000059A028: 4E6264A0
	v_subrev_nc_u32_e32 v50, 32, v51                           // 00000059A02C: 4E6466A0
	v_subrev_nc_u32_e32 v51, 32, v52                           // 00000059A030: 4E6668A0
	v_subrev_nc_u32_e32 v52, 32, v53                           // 00000059A034: 4E686AA0
	v_subrev_nc_u32_e32 v28, 32, v28                           // 00000059A038: 4E3838A0
	v_subrev_nc_u32_e32 v53, 32, v54                           // 00000059A03C: 4E6A6CA0
	v_subrev_nc_u32_e32 v54, 32, v55                           // 00000059A040: 4E6C6EA0
	v_cvt_f32_i32_e32 v29, v29                                 // 00000059A044: 7E3A0B1D
	v_cvt_f32_i32_e32 v47, v47                                 // 00000059A048: 7E5E0B2F
	v_cvt_f32_i32_e32 v48, v48                                 // 00000059A04C: 7E600B30
	v_cvt_f32_i32_e32 v26, v26                                 // 00000059A050: 7E340B1A
	v_cvt_f32_i32_e32 v49, v49                                 // 00000059A054: 7E620B31
	v_cvt_f32_i32_e32 v50, v50                                 // 00000059A058: 7E640B32
	v_cvt_f32_i32_e32 v51, v51                                 // 00000059A05C: 7E660B33
	v_cvt_f32_i32_e32 v52, v52                                 // 00000059A060: 7E680B34
	v_cvt_f32_i32_e32 v28, v28                                 // 00000059A064: 7E380B1C
	v_cvt_f32_i32_e32 v53, v53                                 // 00000059A068: 7E6A0B35
	v_cvt_f32_i32_e32 v54, v54                                 // 00000059A06C: 7E6C0B36
	v_mul_f32_e32 v29, v46, v29                                // 00000059A070: 103A3B2E
	v_mul_f32_e32 v47, v46, v47                                // 00000059A074: 105E5F2E
	v_mul_f32_e32 v48, v46, v48                                // 00000059A078: 1060612E
	v_mul_f32_e32 v26, v46, v26                                // 00000059A07C: 1034352E
	v_mul_f32_e32 v49, v46, v49                                // 00000059A080: 1062632E
	v_mul_f32_e32 v50, v46, v50                                // 00000059A084: 1064652E
	v_mul_f32_e32 v51, v46, v51                                // 00000059A088: 1066672E
	v_mul_f32_e32 v52, v46, v52                                // 00000059A08C: 1068692E
	v_mul_f32_e32 v28, v46, v28                                // 00000059A090: 1038392E
	v_mul_f32_e32 v53, v46, v53                                // 00000059A094: 106A6B2E
	v_mul_f32_e32 v54, v46, v54                                // 00000059A098: 106C6D2E
	v_bfe_u32 v46, v29, 16, 1                                  // 00000059A09C: D610002E 0205211D
	v_bfe_u32 v55, v47, 16, 1                                  // 00000059A0A4: D6100037 0205212F
	v_bfe_u32 v56, v48, 16, 1                                  // 00000059A0AC: D6100038 02052130
	v_bfe_u32 v57, v22, 16, 1                                  // 00000059A0B4: D6100039 02052116
	v_bfe_u32 v58, v26, 16, 1                                  // 00000059A0BC: D610003A 0205211A
	v_add3_u32 v29, v29, v46, 0x7fff                           // 00000059A0C4: D655001D 03FE5D1D 00007FFF
	v_add3_u32 v47, v47, v55, 0x7fff                           // 00000059A0D0: D655002F 03FE6F2F 00007FFF
	v_add3_u32 v48, v48, v56, 0x7fff                           // 00000059A0DC: D6550030 03FE7130 00007FFF
	v_bfe_u32 v59, v49, 16, 1                                  // 00000059A0E8: D610003B 02052131
	v_add3_u32 v22, v22, v57, 0x7fff                           // 00000059A0F0: D6550016 03FE7316 00007FFF
	.long 0x7e5e399d                                           // 00000059A0FC: 7E5E399D
	v_bfe_u32 v60, v50, 16, 1                                  // 00000059A100: D610003C 02052132
	v_add3_u32 v26, v26, v58, 0x7fff                           // 00000059A108: D655001A 03FE751A 00007FFF
	.long 0x7e2c39b0                                           // 00000059A114: 7E2C39B0
	v_bfe_u32 v61, v23, 16, 1                                  // 00000059A118: D610003D 02052117
	s_waitcnt vmcnt(3)                                         // 00000059A120: BF890FF7
	v_dot2_f32_bf16 v29, v30, v47, 0                           // 00000059A124: CC1A401D 1A025F1E
	s_waitcnt vmcnt(2)                                         // 00000059A12C: BF890BF7
	v_dot2_f32_bf16 v30, v34, v47, 0                           // 00000059A130: CC1A401E 1A025F22
	v_add3_u32 v34, v49, v59, 0x7fff                           // 00000059A138: D6550022 03FE7731 00007FFF
	v_bfe_u32 v62, v27, 16, 1                                  // 00000059A144: D610003E 0205211B
	v_add3_u32 v47, v50, v60, 0x7fff                           // 00000059A14C: D655002F 03FE7932 00007FFF
	.long 0x7e44399a                                           // 00000059A158: 7E44399A
	v_dot2_f32_bf16 v26, v31, v22, v29                         // 00000059A15C: CC1A401A 1C762D1F
	v_dot2_f32_bf16 v22, v35, v22, v30                         // 00000059A164: CC1A4016 1C7A2D23
	v_bfe_u32 v63, v51, 16, 1                                  // 00000059A16C: D610003F 02052133
	v_add3_u32 v23, v23, v61, 0x7fff                           // 00000059A174: D6550017 03FE7B17 00007FFF
	v_bfe_u32 v64, v52, 16, 1                                  // 00000059A180: D6100040 02052134
	v_add3_u32 v27, v27, v62, 0x7fff                           // 00000059A188: D655001B 03FE7D1B 00007FFF
	.long 0x7e2e39af                                           // 00000059A194: 7E2E39AF
	v_dot2_f32_bf16 v26, v32, v34, v26                         // 00000059A198: CC1A401A 1C6A4520
	v_dot2_f32_bf16 v22, v36, v34, v22                         // 00000059A1A0: CC1A4016 1C5A4524
	v_bfe_u32 v65, v24, 16, 1                                  // 00000059A1A8: D6100041 02052118
	v_add3_u32 v29, v51, v63, 0x7fff                           // 00000059A1B0: D655001D 03FE7F33 00007FFF
	v_bfe_u32 v66, v28, 16, 1                                  // 00000059A1BC: D6100042 0205211C
	v_add3_u32 v30, v52, v64, 0x7fff                           // 00000059A1C4: D655001E 03FE8134 00007FFF
	.long 0x7e3a399b                                           // 00000059A1D0: 7E3A399B
	v_dot2_f32_bf16 v26, v33, v23, v26                         // 00000059A1D4: CC1A401A 1C6A2F21
	v_dot2_f32_bf16 v22, v37, v23, v22                         // 00000059A1DC: CC1A4016 1C5A2F25
	v_bfe_u32 v67, v53, 16, 1                                  // 00000059A1E4: D6100043 02052135
	v_add3_u32 v23, v24, v65, 0x7fff                           // 00000059A1EC: D6550017 03FE8318 00007FFF
	v_bfe_u32 v68, v54, 16, 1                                  // 00000059A1F8: D6100044 02052136
	v_add3_u32 v24, v28, v66, 0x7fff                           // 00000059A200: D6550018 03FE851C 00007FFF
	.long 0x7e2e399e                                           // 00000059A20C: 7E2E399E
	s_waitcnt vmcnt(1)                                         // 00000059A210: BF8907F7
	v_dot2_f32_bf16 v26, v38, v29, v26                         // 00000059A214: CC1A401A 1C6A3B26
	s_waitcnt vmcnt(0)                                         // 00000059A21C: BF8903F7
	v_dot2_f32_bf16 v22, v42, v29, v22                         // 00000059A220: CC1A4016 1C5A3B2A
	v_bfe_u32 v46, v25, 16, 1                                  // 00000059A228: D610002E 02052119
	v_add3_u32 v27, v53, v67, 0x7fff                           // 00000059A230: D655001B 03FE8735 00007FFF
	v_add3_u32 v28, v54, v68, 0x7fff                           // 00000059A23C: D655001C 03FE8936 00007FFF
	.long 0x7e363998                                           // 00000059A248: 7E363998
	v_dot2_f32_bf16 v24, v39, v23, v26                         // 00000059A24C: CC1A4018 1C6A2F27
	v_dot2_f32_bf16 v22, v43, v23, v22                         // 00000059A254: CC1A4016 1C5A2F2B
	v_add3_u32 v23, v25, v46, 0x7fff                           // 00000059A25C: D6550017 03FE5D19 00007FFF
	.long 0x7e2e399c                                           // 00000059A268: 7E2E399C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000059A26C: BF870214
	v_dot2_f32_bf16 v24, v40, v27, v24                         // 00000059A270: CC1A4018 1C623728
	v_dot2_f32_bf16 v22, v44, v27, v22                         // 00000059A278: CC1A4016 1C5A372C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000059A280: BF870112
	v_dot2_f32_bf16 v24, v41, v23, v24                         // 00000059A284: CC1A4018 1C622F29
	v_dot2_f32_bf16 v22, v45, v23, v22                         // 00000059A28C: CC1A4016 1C5A2F2D
	s_delay_alu instid0(VALU_DEP_1)                            // 00000059A294: BF870001
	v_dual_add_f32 v9, v9, v24 :: v_dual_add_f32 v8, v8, v22   // 00000059A298: C9083109 09082D08
	s_and_not1_b32 exec_lo, exec_lo, s3                        // 00000059A2A0: 917E037E
	s_cbranch_execnz 65181                                     // 00000059A2A4: BFA6FE9D <_ZN7halogen12_GLOBAL__N_16k_lq6kILi2ELi32ELi1ELb0EEEvPKhPKtPvll+0x11c>
	s_or_b32 exec_lo, exec_lo, s3                              // 00000059A2A8: 8C7E037E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000059A2AC: BF8700A9
	s_or_b32 exec_lo, exec_lo, s1                              // 00000059A2B0: 8C7E017E
	.long 0xd71f0000                                           // 00000059A2B4: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 00000059A2B8: 020100C1
	v_xor_b32_e32 v3, 16, v0                                   // 00000059A2BC: 3A060090
	v_xor_b32_e32 v5, 8, v0                                    // 00000059A2C0: 3A0A0088
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000059A2C4: BF870092
	.long 0xd44c0000                                           // 00000059A2C8: D44C0000
	v_cndmask_b32_e32 v1, 32, v3, vcc_lo                       // 00000059A2CC: 020206A0
	v_cndmask_b32_e64 v3, v0, v3, s0                           // 00000059A2D0: D5010003 00020700
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000059A2D8: BF870113
	.long 0xd44c0000                                           // 00000059A2DC: D44C0000
	v_cndmask_b32_e32 v1, 32, v5, vcc_lo                       // 00000059A2E0: 02020AA0
	v_lshlrev_b32_e32 v3, 2, v3                                // 00000059A2E4: 30060682
	s_delay_alu instid0(VALU_DEP_2)                            // 00000059A2E8: BF870002
	v_cndmask_b32_e64 v5, v0, v5, s0                           // 00000059A2EC: D5010005 00020B00
	ds_bpermute_b32 v4, v3, v9                                 // 00000059A2F4: DACC0000 04000903
	s_waitcnt lgkmcnt(0)                                       // 00000059A2FC: BF89FC07
	v_add_f32_e32 v4, v9, v4                                   // 00000059A300: 06080909
	ds_bpermute_b32 v3, v3, v8                                 // 00000059A304: DACC0000 03000803
	v_lshlrev_b32_e32 v5, 2, v5                                // 00000059A30C: 300A0A82
	ds_bpermute_b32 v6, v5, v4                                 // 00000059A310: DACC0000 06000405
	s_waitcnt lgkmcnt(1)                                       // 00000059A318: BF89FC17
	v_add_f32_e32 v3, v8, v3                                   // 00000059A31C: 06060708
	v_xor_b32_e32 v8, 4, v0                                    // 00000059A320: 3A100084
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000059A324: BF870131
	.long 0xd44c0000                                           // 00000059A328: D44C0000
	v_cndmask_b32_e32 v1, 32, v8, vcc_lo                       // 00000059A32C: 020210A0
	s_waitcnt lgkmcnt(0)                                       // 00000059A330: BF89FC07
	v_add_f32_e32 v4, v4, v6                                   // 00000059A334: 06080D04
	v_cndmask_b32_e64 v8, v0, v8, s0                           // 00000059A338: D5010008 00021100
	s_delay_alu instid0(VALU_DEP_1)                            // 00000059A340: BF870001
	v_lshlrev_b32_e32 v8, 2, v8                                // 00000059A344: 30101082
	ds_bpermute_b32 v5, v5, v3                                 // 00000059A348: DACC0000 05000305
	s_waitcnt lgkmcnt(0)                                       // 00000059A350: BF89FC07
	v_add_f32_e32 v3, v3, v5                                   // 00000059A354: 06060B03
	ds_bpermute_b32 v5, v8, v4                                 // 00000059A358: DACC0000 05000408
	ds_bpermute_b32 v6, v8, v3                                 // 00000059A360: DACC0000 06000308
	v_xor_b32_e32 v8, 2, v0                                    // 00000059A368: 3A100082
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000059A36C: BF870091
	.long 0xd44c0000                                           // 00000059A370: D44C0000
	v_cndmask_b32_e32 v1, 32, v8, vcc_lo                       // 00000059A374: 020210A0
	v_cndmask_b32_e64 v8, v0, v8, s0                           // 00000059A378: D5010008 00021100
	s_delay_alu instid0(VALU_DEP_1)                            // 00000059A380: BF870001
	v_lshlrev_b32_e32 v8, 2, v8                                // 00000059A384: 30101082
	s_waitcnt lgkmcnt(0)                                       // 00000059A388: BF89FC07
	v_dual_add_f32 v4, v4, v5 :: v_dual_add_f32 v3, v3, v6     // 00000059A38C: C9080B04 04020D03
	ds_bpermute_b32 v5, v8, v4                                 // 00000059A394: DACC0000 05000408
	ds_bpermute_b32 v6, v8, v3                                 // 00000059A39C: DACC0000 06000308
	v_xor_b32_e32 v8, 1, v0                                    // 00000059A3A4: 3A100081
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000059A3A8: BF870091
	.long 0xd44c0000                                           // 00000059A3AC: D44C0000
	v_cndmask_b32_e32 v1, 32, v8, vcc_lo                       // 00000059A3B0: 020210A0
	v_cndmask_b32_e64 v0, v0, v8, s0                           // 00000059A3B4: D5010000 00021100
	.long 0xd44a0000                                           // 00000059A3BC: D44A0000
	v_cndmask_b32_e32 v1, 0, v7, vcc_lo                        // 00000059A3C0: 02020E80
	s_delay_alu instid0(VALU_DEP_2)                            // 00000059A3C4: BF870002
	v_lshlrev_b32_e32 v8, 2, v0                                // 00000059A3C8: 30100082
	s_waitcnt lgkmcnt(1)                                       // 00000059A3CC: BF89FC17
	v_add_f32_e32 v4, v4, v5                                   // 00000059A3D0: 06080B04
	s_and_b32 s0, s0, vcc_lo                                   // 00000059A3D4: 8B006A00
	s_waitcnt lgkmcnt(0)                                       // 00000059A3D8: BF89FC07
	v_add_f32_e32 v0, v3, v6                                   // 00000059A3DC: 06000D03
	ds_bpermute_b32 v5, v8, v4                                 // 00000059A3E0: DACC0000 05000408
	ds_bpermute_b32 v3, v8, v0                                 // 00000059A3E8: DACC0000 03000008
	s_and_saveexec_b32 s1, s0                                  // 00000059A3F0: BE812000
	s_cbranch_execz 35                                         // 00000059A3F4: BFA50023 <_ZN7halogen12_GLOBAL__N_16k_lq6kILi2ELi32ELi1ELb0EEEvPKhPKtPvll+0x884>
	s_waitcnt lgkmcnt(1)                                       // 00000059A3F8: BF89FC17
	v_add_f32_e32 v4, v4, v5                                   // 00000059A3FC: 06080B04
	.long 0x7f0a3880                                           // 00000059A400: 7F0A3880
	s_waitcnt lgkmcnt(0)                                       // 00000059A404: BF89FC07
	v_add_f32_e32 v6, v0, v3                                   // 00000059A408: 060C0700
	.long 0xd73c0000                                           // 00000059A40C: D73C0000
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 00000059A410: 02020281
	s_lshl_b64 s[0:1], s[12:13], 1                             // 00000059A414: 8480810C
	.long 0x7e063984                                           // 00000059A418: 7E063984
	.long 0x7f063985                                           // 00000059A41C: 7F063985
	.long 0x7e0a3986                                           // 00000059A420: 7E0A3986
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000059A424: BF870194
	.long 0xd7006a00                                           // 00000059A428: D7006A00
	v_cndmask_b32_e32 v1, s8, v0, vcc_lo                       // 00000059A42C: 02020008
	v_and_b32_e32 v2, 1, v3                                    // 00000059A430: 36040681
	v_add_co_ci_u32_e64 v1, null, s9, v1, vcc_lo               // 00000059A434: D5207C01 01AA0209
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000059A43C: BF870194
	v_and_b32_e32 v5, 1, v5                                    // 00000059A440: 360A0A81
	v_add3_u32 v4, v4, v2, 0x7fff                              // 00000059A444: D6550004 03FE0504 00007FFF
	.long 0xd7006a02                                           // 00000059A450: D7006A02
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 00000059A454: 02000100
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000059A458: BF870211
	v_add_co_ci_u32_e64 v3, null, s1, v1, vcc_lo               // 00000059A45C: D5207C03 01AA0201
	v_add3_u32 v5, v6, v5, 0x7fff                              // 00000059A464: D6550005 03FE0B06 00007FFF
	s_clause 0x1                                               // 00000059A470: BF850001
	global_store_d16_hi_b16 v[0:1], v4, off                    // 00000059A474: DC960000 007C0400
	global_store_d16_hi_b16 v[2:3], v5, off                    // 00000059A47C: DC960000 007C0502
	s_endpgm                                                   // 00000059A484: BFB00000
		...

