0000000000714b00 <_ZN7halogen12_GLOBAL__N_16k_lq6kILi4ELi32ELi1ELb1EEEvPKhPKtPvll>:
; _ZN7halogen12_GLOBAL__N_16k_lq6kILi4ELi32ELi1ELb1EEEvPKhPKtPvll():
	s_clause 0x1                                               // 000000714B00: BF850001
	s_load_b256 s[4:11], s[0:1], null                          // 000000714B04: F40C0100 F8000000
	s_load_b64 s[12:13], s[0:1], 0x20                          // 000000714B0C: F4040300 F8000020
	s_mov_b32 s3, 0                                            // 000000714B14: BE830080
	v_lshrrev_b32_e32 v1, 5, v0                                // 000000714B18: 32020085
	s_lshl_b64 s[0:1], s[2:3], 3                               // 000000714B1C: 84808302
	v_dual_mov_b32 v8, 0 :: v_dual_mov_b32 v9, 0               // 000000714B20: CA100080 08080080
	v_dual_mov_b32 v2, s1 :: v_dual_and_b32 v7, 31, v0         // 000000714B28: CA240001 0206009F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000714B30: BF870143
	v_or_b32_e32 v1, s0, v1                                    // 000000714B34: 38020200
	v_dual_mov_b32 v10, 0 :: v_dual_mov_b32 v11, 0             // 000000714B38: CA100080 0A0A0080
	s_waitcnt lgkmcnt(0)                                       // 000000714B40: BF89FC07
	s_ashr_i32 s1, s11, 31                                     // 000000714B44: 86019F0B
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[1:2]                  // 000000714B48: 7CA8020C
	s_lshr_b32 s1, s1, 28                                      // 000000714B4C: 85019C01
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000714B50: BF8704A9
	s_add_u32 s0, s10, s1                                      // 000000714B54: 8000010A
	s_addc_u32 s1, s11, 0                                      // 000000714B58: 8201800B
	s_lshr_b64 s[14:15], s[0:1], 4                             // 000000714B5C: 858E8400
	s_mov_b32 s1, exec_lo                                      // 000000714B60: BE81007E
	.long 0xd4c4007e                                           // 000000714B64: D4C4007E
	v_cndmask_b32_e32 v1, s14, v7, vcc_lo                      // 000000714B68: 02020E0E
	s_cbranch_execz 461                                        // 000000714B6C: BFA501CD <_ZN7halogen12_GLOBAL__N_16k_lq6kILi4ELi32ELi1ELb1EEEvPKhPKtPvll+0x7a4>
	s_ashr_i32 s0, s11, 31                                     // 000000714B70: 86009F0B
	v_dual_cndmask_b32 v3, 0, v2 :: v_dual_and_b32 v12, 6, v0  // 000000714B74: CA640480 030C0086
	s_lshr_b32 s0, s0, 24                                      // 000000714B7C: 85009800
	v_cndmask_b32_e32 v5, 0, v1, vcc_lo                        // 000000714B80: 020A0280
	s_add_u32 s16, s10, s0                                     // 000000714B84: 8010000A
	s_addc_u32 s17, s11, 0                                     // 000000714B88: 8211800B
	v_bfe_u32 v9, v0, 3, 1                                     // 000000714B8C: D6100009 02050700
	s_ashr_i64 s[16:17], s[16:17], 8                           // 000000714B94: 86908810
	v_dual_mov_b32 v6, 0 :: v_dual_and_b32 v13, 4, v0          // 000000714B98: CA240080 060C0084
	s_mul_i32 s0, s17, 0xd2                                    // 000000714BA0: 9600FF11 000000D2
	s_mul_hi_u32 s2, s16, 0xd2                                 // 000000714BA8: 9682FF10 000000D2
	s_mul_i32 s15, s16, 0xd2                                   // 000000714BB0: 960FFF10 000000D2
	s_add_i32 s2, s2, s0                                       // 000000714BB8: 81020002
	.long 0xd72c0008                                           // 000000714BBC: D72C0008
	v_cndmask_b32_e32 v1, s15, v3, vcc_lo                      // 000000714BC0: 0202060F
	v_and_b32_e32 v0, 15, v0                                   // 000000714BC4: 3600008F
	v_mad_u64_u32 v[3:4], null, s15, v5, s[4:5]                // 000000714BC8: D6FE7C03 00120A0F
	.long 0xd72c0005                                           // 000000714BD0: D72C0005
	v_cndmask_b32_e32 v1, s2, v5, vcc_lo                       // 000000714BD4: 02020A02
	v_dual_mov_b32 v23, v7 :: v_dual_lshlrev_b32 v14, 6, v9    // 000000714BD8: CA220107 170E1286
	v_dual_mov_b32 v10, v6 :: v_dual_lshlrev_b32 v15, 5, v9    // 000000714BE0: CA220106 0A0E1285
	v_or_b32_e32 v16, 8, v13                                   // 000000714BE8: 38201A88
	v_or_b32_e32 v17, 8, v12                                   // 000000714BEC: 38221888
	v_or_b32_e32 v18, 16, v13                                  // 000000714BF0: 38241A90
	v_add3_u32 v4, v5, v4, v8                                  // 000000714BF4: D6550004 04220905
	v_lshrrev_b32_e32 v8, 4, v7                                // 000000714BFC: 32100E84
	v_or_b32_e32 v19, 16, v12                                  // 000000714C00: 38261890
	v_or_b32_e32 v20, 24, v13                                  // 000000714C04: 38281A98
	v_or_b32_e32 v21, 24, v12                                  // 000000714C08: 382A1898
	v_lshlrev_b32_e32 v5, 4, v7                                // 000000714C0C: 300A0E84
	v_mul_u32_u24_e32 v22, 0xd2, v8                            // 000000714C10: 162C10FF 000000D2
	v_mov_b32_e32 v11, v6                                      // 000000714C18: 7E160306
	v_mov_b32_e32 v9, v6                                       // 000000714C1C: 7E120306
	v_mov_b32_e32 v8, v6                                       // 000000714C20: 7E100306
	s_mul_i32 s0, s11, 6                                       // 000000714C24: 9600860B
	s_mul_hi_u32 s2, s10, 6                                    // 000000714C28: 9682860A
	s_lshl_b64 s[4:5], s[10:11], 2                             // 000000714C2C: 8484820A
	s_add_i32 s2, s2, s0                                       // 000000714C30: 81020002
	s_mul_i32 s15, s10, 6                                      // 000000714C34: 960F860A
	s_lshl_b64 s[10:11], s[10:11], 1                           // 000000714C38: 848A810A
	.long 0xd7000020                                           // 000000714C3C: D7000020
	v_cndmask_b32_e32 v1, v3, v22, vcc_lo                      // 000000714C40: 02022D03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000714C44: BF8701A1
	v_add_co_ci_u32_e64 v33, null, 0, v4, s0                   // 000000714C48: D5207C21 00020880
	v_and_b32_e32 v28, 16, v5                                  // 000000714C50: 36380A90
	.long 0xd700001e                                           // 000000714C54: D700001E
	v_cndmask_b32_e32 v1, v32, v14, vcc_lo                     // 000000714C58: 02021D20
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000714C5C: BF8700D1
	v_add_co_ci_u32_e64 v31, null, 0, v33, s0                  // 000000714C60: D5207C1F 00024280
	.long 0xd700001a                                           // 000000714C68: D700001A
	v_cndmask_b32_e32 v1, v32, v15, vcc_lo                     // 000000714C6C: 02021F20
	v_and_b32_e32 v29, 32, v5                                  // 000000714C70: 363A0AA0
	v_add_co_ci_u32_e64 v27, null, 0, v33, s0                  // 000000714C74: D5207C1B 00024280
	.long 0xd7000018                                           // 000000714C7C: D7000018
	v_cndmask_b32_e32 v1, v32, v0, vcc_lo                      // 000000714C80: 02020120
	v_add_co_ci_u32_e64 v25, null, 0, v33, s0                  // 000000714C84: D5207C19 00024280
	.long 0xd700001a                                           // 000000714C8C: D700001A
	v_cndmask_b32_e32 v1, v26, v28, vcc_lo                     // 000000714C90: 0202391A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000714C94: BF8700A1
	v_add_co_ci_u32_e64 v27, null, 0, v27, s0                  // 000000714C98: D5207C1B 00023680
	.long 0xd700001d                                           // 000000714CA0: D700001D
	v_cndmask_b32_e32 v1, v30, v29, vcc_lo                     // 000000714CA4: 02023B1E
	v_add_co_ci_u32_e64 v30, null, 0, v31, s0                  // 000000714CA8: D5207C1E 00023E80
	s_clause 0x1                                               // 000000714CB0: BF850001
	global_load_i8 v64, v[24:25], off offset:192               // 000000714CB4: DC4600C0 407C0018
	global_load_b128 v[24:27], v[26:27], off offset:128        // 000000714CBC: DC5E0080 187C001A
	.long 0xd700001c                                           // 000000714CC4: D700001C
	v_cndmask_b32_e32 v1, v29, v28, vcc_lo                     // 000000714CC8: 0202391D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000714CCC: BF8700D1
	v_add_co_ci_u32_e64 v29, null, 0, v30, s0                  // 000000714CD0: D5207C1D 00023C80
	s_clause 0x1                                               // 000000714CD8: BF850001
	global_load_b128 v[28:31], v[28:29], off                   // 000000714CDC: DC5E0000 1C7C001C
	global_load_d16_b16 v65, v[32:33], off offset:208          // 000000714CE4: DC8200D0 417C0020
	.long 0xd73c0020                                           // 000000714CEC: D73C0020
	v_cndmask_b32_e32 v1, 1, v5, vcc_lo                        // 000000714CF0: 02020A81
	.long 0xd7000030                                           // 000000714CF4: D7000030
	v_cndmask_b32_e32 v1, s6, v32, vcc_lo                      // 000000714CF8: 02024006
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000714CFC: BF870111
	v_add_co_ci_u32_e64 v49, null, s7, v33, s0                 // 000000714D00: D5207C31 00024207
	.long 0xd7000034                                           // 000000714D08: D7000034
	v_cndmask_b32_e32 v0, v48, v10, vcc_lo                     // 000000714D0C: 02001530
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000714D10: BF8700A1
	v_add_co_ci_u32_e64 v53, null, s11, v49, s0                // 000000714D14: D5207C35 0002620B
	.long 0xd7000038                                           // 000000714D1C: D7000038
	v_cndmask_b32_e32 v0, v48, v4, vcc_lo                      // 000000714D20: 02000930
	v_add_co_ci_u32_e64 v57, null, s5, v49, s0                 // 000000714D24: D5207C39 00026205
	.long 0xd700003c                                           // 000000714D2C: D700003C
	v_cndmask_b32_e32 v0, v48, v15, vcc_lo                     // 000000714D30: 02001F30
	s_delay_alu instid0(VALU_DEP_1)                            // 000000714D34: BF870001
	v_add_co_ci_u32_e64 v61, null, s2, v49, s0                 // 000000714D38: D5207C3D 00026202
	s_clause 0x7                                               // 000000714D40: BF850007
	global_load_b128 v[32:35], v[48:49], off                   // 000000714D44: DC5E0000 207C0030
	global_load_b128 v[36:39], v[52:53], off                   // 000000714D4C: DC5E0000 247C0034
	global_load_b128 v[40:43], v[56:57], off                   // 000000714D54: DC5E0000 287C0038
	global_load_b128 v[44:47], v[60:61], off                   // 000000714D5C: DC5E0000 2C7C003C
	global_load_b128 v[48:51], v[48:49], off offset:16         // 000000714D64: DC5E0010 307C0030
	global_load_b128 v[52:55], v[52:53], off offset:16         // 000000714D6C: DC5E0010 347C0034
	global_load_b128 v[56:59], v[56:57], off offset:16         // 000000714D74: DC5E0010 387C0038
	global_load_b128 v[60:63], v[60:61], off offset:16         // 000000714D7C: DC5E0010 3C7C003C
	s_waitcnt vmcnt(11)                                        // 000000714D84: BF892FF7
	v_cvt_f32_i32_e32 v64, v64                                 // 000000714D88: 7E800B40
	s_waitcnt vmcnt(10)                                        // 000000714D8C: BF892BF7
	v_lshrrev_b32_e32 v75, v12, v27                            // 000000714D90: 3296370C
	v_lshrrev_b32_e32 v76, v17, v27                            // 000000714D94: 32983711
	v_lshrrev_b32_e32 v77, v19, v27                            // 000000714D98: 329A3713
	v_lshrrev_b32_e32 v27, v21, v27                            // 000000714D9C: 32363715
	v_lshrrev_b32_e32 v72, v12, v26                            // 000000714DA0: 3290350C
	v_lshrrev_b32_e32 v73, v17, v26                            // 000000714DA4: 32923511
	v_lshrrev_b32_e32 v74, v19, v26                            // 000000714DA8: 32943513
	s_waitcnt vmcnt(9)                                         // 000000714DAC: BF8927F7
	v_bfe_u32 v86, v31, v13, 4                                 // 000000714DB0: D6100056 02121B1F
	v_bfe_u32 v87, v31, v16, 4                                 // 000000714DB8: D6100057 0212211F
	v_bfe_u32 v88, v31, v18, 4                                 // 000000714DC0: D6100058 0212251F
	v_bfe_u32 v31, v31, v20, 4                                 // 000000714DC8: D610001F 0212291F
	v_lshlrev_b32_e32 v27, 4, v27                              // 000000714DD0: 30363684
	v_lshrrev_b32_e32 v26, v21, v26                            // 000000714DD4: 32343515
	s_waitcnt vmcnt(8)                                         // 000000714DD8: BF8923F7
	v_fma_mix_f32 v64, v65, v64, neg(0) op_sel_hi:[1,0,0]      // 000000714DDC: CC200040 8A028141
	v_bfe_u32 v83, v30, v13, 4                                 // 000000714DE4: D6100053 02121B1E
	v_bfe_u32 v84, v30, v16, 4                                 // 000000714DEC: D6100054 0212211E
	v_and_or_b32 v27, v27, 48, v31                             // 000000714DF4: D657001B 047D611B
	v_bfe_u32 v85, v30, v18, 4                                 // 000000714DFC: D6100055 0212251E
	v_bfe_u32 v30, v30, v20, 4                                 // 000000714E04: D610001E 0212291E
	v_lshlrev_b32_e32 v75, 4, v75                              // 000000714E0C: 30969684
	v_lshrrev_b32_e32 v69, v12, v25                            // 000000714E10: 328A330C
	v_subrev_nc_u32_e32 v27, 32, v27                           // 000000714E14: 4E3636A0
	v_lshrrev_b32_e32 v70, v17, v25                            // 000000714E18: 328C3311
	v_lshrrev_b32_e32 v71, v19, v25                            // 000000714E1C: 328E3313
	v_lshrrev_b32_e32 v25, v21, v25                            // 000000714E20: 32323315
	v_bfe_u32 v80, v29, v13, 4                                 // 000000714E24: D6100050 02121B1D
	v_cvt_f32_i32_e32 v27, v27                                 // 000000714E2C: 7E360B1B
	v_lshlrev_b32_e32 v26, 4, v26                              // 000000714E30: 30343484
	v_bfe_u32 v81, v29, v16, 4                                 // 000000714E34: D6100051 0212211D
	v_bfe_u32 v82, v29, v18, 4                                 // 000000714E3C: D6100052 0212251D
	v_bfe_u32 v29, v29, v20, 4                                 // 000000714E44: D610001D 0212291D
	v_mul_f32_e32 v27, v64, v27                                // 000000714E4C: 10363740
	v_and_or_b32 v26, v26, 48, v30                             // 000000714E50: D657001A 0479611A
	v_and_or_b32 v30, v75, 48, v86                             // 000000714E58: D657001E 0559614B
	v_lshlrev_b32_e32 v72, 4, v72                              // 000000714E60: 30909084
	v_lshrrev_b32_e32 v66, v12, v24                            // 000000714E64: 3284310C
	v_lshrrev_b32_e32 v67, v17, v24                            // 000000714E68: 32863111
	v_lshrrev_b32_e32 v68, v19, v24                            // 000000714E6C: 32883113
	v_subrev_nc_u32_e32 v30, 32, v30                           // 000000714E70: 4E3C3CA0
	v_lshrrev_b32_e32 v24, v21, v24                            // 000000714E74: 32303115
	v_bfe_u32 v65, v28, v13, 4                                 // 000000714E78: D6100041 02121B1C
	v_lshlrev_b32_e32 v66, 4, v66                              // 000000714E80: 30848484
	v_subrev_nc_u32_e32 v26, 32, v26                           // 000000714E84: 4E3434A0
	v_cvt_f32_i32_e32 v30, v30                                 // 000000714E88: 7E3C0B1E
	v_lshlrev_b32_e32 v25, 4, v25                              // 000000714E8C: 30323284
	v_bfe_u32 v78, v28, v16, 4                                 // 000000714E90: D610004E 0212211C
	v_lshlrev_b32_e32 v67, 4, v67                              // 000000714E98: 30868684
	v_bfe_u32 v79, v28, v18, 4                                 // 000000714E9C: D610004F 0212251C
	v_mul_f32_e32 v30, v64, v30                                // 000000714EA4: 103C3D40
	v_and_or_b32 v25, v25, 48, v29                             // 000000714EA8: D6570019 04756119
	v_and_or_b32 v29, v72, 48, v83                             // 000000714EB0: D657001D 054D6148
	v_lshlrev_b32_e32 v68, 4, v68                              // 000000714EB8: 30888884
	v_bfe_u32 v28, v28, v20, 4                                 // 000000714EBC: D610001C 0212291C
	v_lshlrev_b32_e32 v69, 4, v69                              // 000000714EC4: 308A8A84
	v_subrev_nc_u32_e32 v25, 32, v25                           // 000000714EC8: 4E3232A0
	v_subrev_nc_u32_e32 v29, 32, v29                           // 000000714ECC: 4E3A3AA0
	v_lshlrev_b32_e32 v73, 4, v73                              // 000000714ED0: 30929284
	v_lshlrev_b32_e32 v74, 4, v74                              // 000000714ED4: 30949484
	v_lshlrev_b32_e32 v76, 4, v76                              // 000000714ED8: 30989884
	v_lshlrev_b32_e32 v77, 4, v77                              // 000000714EDC: 309A9A84
	v_and_or_b32 v65, v66, 48, v65                             // 000000714EE0: D6570041 05056142
	v_cvt_f32_i32_e32 v25, v25                                 // 000000714EE8: 7E320B19
	v_lshlrev_b32_e32 v24, 4, v24                              // 000000714EEC: 30303084
	v_cvt_f32_i32_e32 v29, v29                                 // 000000714EF0: 7E3A0B1D
	v_lshlrev_b32_e32 v70, 4, v70                              // 000000714EF4: 308C8C84
	v_cvt_f32_i32_e32 v26, v26                                 // 000000714EF8: 7E340B1A
	v_lshlrev_b32_e32 v71, 4, v71                              // 000000714EFC: 308E8E84
	v_and_or_b32 v66, v67, 48, v78                             // 000000714F00: D6570042 05396143
	v_and_or_b32 v67, v68, 48, v79                             // 000000714F08: D6570043 053D6144
	v_and_or_b32 v72, v76, 48, v87                             // 000000714F10: D6570048 055D614C
	v_subrev_nc_u32_e32 v31, 32, v65                           // 000000714F18: 4E3E82A0
	v_mul_f32_e32 v25, v64, v25                                // 000000714F1C: 10323340
	v_and_or_b32 v24, v24, 48, v28                             // 000000714F20: D6570018 04716118
	v_and_or_b32 v28, v69, 48, v80                             // 000000714F28: D657001C 05416145
	v_mul_f32_e32 v29, v64, v29                                // 000000714F30: 103A3B40
	v_and_or_b32 v68, v70, 48, v81                             // 000000714F34: D6570044 05456146
	v_and_or_b32 v70, v73, 48, v84                             // 000000714F3C: D6570046 05516149
	v_and_or_b32 v73, v77, 48, v88                             // 000000714F44: D6570049 0561614D
	v_mul_f32_e32 v26, v64, v26                                // 000000714F4C: 10343540
	v_and_or_b32 v69, v71, 48, v82                             // 000000714F50: D6570045 05496147
	v_and_or_b32 v71, v74, 48, v85                             // 000000714F58: D6570047 0555614A
	v_subrev_nc_u32_e32 v65, 32, v66                           // 000000714F60: 4E8284A0
	v_subrev_nc_u32_e32 v66, 32, v67                           // 000000714F64: 4E8486A0
	v_subrev_nc_u32_e32 v24, 32, v24                           // 000000714F68: 4E3030A0
	v_subrev_nc_u32_e32 v28, 32, v28                           // 000000714F6C: 4E3838A0
	v_subrev_nc_u32_e32 v67, 32, v68                           // 000000714F70: 4E8688A0
	v_subrev_nc_u32_e32 v68, 32, v69                           // 000000714F74: 4E888AA0
	v_subrev_nc_u32_e32 v69, 32, v70                           // 000000714F78: 4E8A8CA0
	v_subrev_nc_u32_e32 v70, 32, v71                           // 000000714F7C: 4E8C8EA0
	v_subrev_nc_u32_e32 v71, 32, v72                           // 000000714F80: 4E8E90A0
	v_subrev_nc_u32_e32 v72, 32, v73                           // 000000714F84: 4E9092A0
	v_cvt_f32_i32_e32 v31, v31                                 // 000000714F88: 7E3E0B1F
	v_cvt_f32_i32_e32 v65, v65                                 // 000000714F8C: 7E820B41
	v_cvt_f32_i32_e32 v66, v66                                 // 000000714F90: 7E840B42
	v_cvt_f32_i32_e32 v24, v24                                 // 000000714F94: 7E300B18
	v_cvt_f32_i32_e32 v28, v28                                 // 000000714F98: 7E380B1C
	v_cvt_f32_i32_e32 v67, v67                                 // 000000714F9C: 7E860B43
	v_cvt_f32_i32_e32 v68, v68                                 // 000000714FA0: 7E880B44
	v_cvt_f32_i32_e32 v69, v69                                 // 000000714FA4: 7E8A0B45
	v_cvt_f32_i32_e32 v70, v70                                 // 000000714FA8: 7E8C0B46
	v_cvt_f32_i32_e32 v71, v71                                 // 000000714FAC: 7E8E0B47
	v_cvt_f32_i32_e32 v72, v72                                 // 000000714FB0: 7E900B48
	v_mul_f32_e32 v31, v64, v31                                // 000000714FB4: 103E3F40
	v_mul_f32_e32 v65, v64, v65                                // 000000714FB8: 10828340
	v_dual_mul_f32 v24, v64, v24 :: v_dual_add_nc_u32 v23, 32, v23// 000000714FBC: C8E03140 18162EA0
	v_dual_mul_f32 v28, v64, v28 :: v_dual_add_nc_u32 v5, 0x200, v5// 000000714FC4: C8E03940 1C040AFF 00000200
	v_mul_f32_e32 v66, v64, v66                                // 000000714FD0: 10848540
	v_mul_f32_e32 v67, v64, v67                                // 000000714FD4: 10868740
	v_mul_f32_e32 v68, v64, v68                                // 000000714FD8: 10888940
	v_mul_f32_e32 v69, v64, v69                                // 000000714FDC: 108A8B40
	v_mul_f32_e32 v70, v64, v70                                // 000000714FE0: 108C8D40
	v_mul_f32_e32 v71, v64, v71                                // 000000714FE4: 108E8F40
	v_mul_f32_e32 v72, v64, v72                                // 000000714FE8: 10909140
	v_bfe_u32 v64, v31, 16, 1                                  // 000000714FEC: D6100040 0205211F
	v_bfe_u32 v73, v65, 16, 1                                  // 000000714FF4: D6100049 02052141
	v_bfe_u32 v74, v66, 16, 1                                  // 000000714FFC: D610004A 02052142
	v_bfe_u32 v75, v24, 16, 1                                  // 000000715004: D610004B 02052118
	v_bfe_u32 v76, v28, 16, 1                                  // 00000071500C: D610004C 0205211C
	v_add3_u32 v31, v31, v64, 0x7fff                           // 000000715014: D655001F 03FE811F 00007FFF
	v_add3_u32 v64, v65, v73, 0x7fff                           // 000000715020: D6550040 03FE9341 00007FFF
	v_add3_u32 v65, v66, v74, 0x7fff                           // 00000071502C: D6550041 03FE9542 00007FFF
	v_bfe_u32 v77, v67, 16, 1                                  // 000000715038: D610004D 02052143
	v_add3_u32 v24, v24, v75, 0x7fff                           // 000000715040: D6550018 03FE9718 00007FFF
	.long 0x7e80399f                                           // 00000071504C: 7E80399F
	v_bfe_u32 v78, v68, 16, 1                                  // 000000715050: D610004E 02052144
	v_add3_u32 v28, v28, v76, 0x7fff                           // 000000715058: D655001C 03FE991C 00007FFF
	.long 0x7e3039c1                                           // 000000715064: 7E3039C1
	v_bfe_u32 v79, v25, 16, 1                                  // 000000715068: D610004F 02052119
	s_waitcnt vmcnt(7)                                         // 000000715070: BF891FF7
	v_dot2_f32_bf16 v31, v32, v64, 0                           // 000000715074: CC1A401F 1A028120
	s_waitcnt vmcnt(6)                                         // 00000071507C: BF891BF7
	v_dot2_f32_bf16 v32, v36, v64, 0                           // 000000715080: CC1A4020 1A028124
	s_waitcnt vmcnt(5)                                         // 000000715088: BF8917F7
	v_dot2_f32_bf16 v36, v40, v64, 0                           // 00000071508C: CC1A4024 1A028128
	s_waitcnt vmcnt(4)                                         // 000000715094: BF8913F7
	v_dot2_f32_bf16 v40, v44, v64, 0                           // 000000715098: CC1A4028 1A02812C
	v_add3_u32 v66, v67, v77, 0x7fff                           // 0000007150A0: D6550042 03FE9B43 00007FFF
	v_bfe_u32 v80, v29, 16, 1                                  // 0000007150AC: D6100050 0205211D
	v_add3_u32 v67, v68, v78, 0x7fff                           // 0000007150B4: D6550043 03FE9D44 00007FFF
	.long 0x7e84399c                                           // 0000007150C0: 7E84399C
	v_dot2_f32_bf16 v28, v33, v24, v31                         // 0000007150C4: CC1A401C 1C7E3121
	v_dot2_f32_bf16 v31, v37, v24, v32                         // 0000007150CC: CC1A401F 1C823125
	v_dot2_f32_bf16 v32, v41, v24, v36                         // 0000007150D4: CC1A4020 1C923129
	v_dot2_f32_bf16 v24, v45, v24, v40                         // 0000007150DC: CC1A4018 1CA2312D
	v_bfe_u32 v81, v69, 16, 1                                  // 0000007150E4: D6100051 02052145
	v_add3_u32 v25, v25, v79, 0x7fff                           // 0000007150EC: D6550019 03FE9F19 00007FFF
	v_bfe_u32 v82, v70, 16, 1                                  // 0000007150F8: D6100052 02052146
	v_add3_u32 v29, v29, v80, 0x7fff                           // 000000715100: D655001D 03FEA11D 00007FFF
	.long 0x7e3239c3                                           // 00000071510C: 7E3239C3
	v_dot2_f32_bf16 v28, v34, v66, v28                         // 000000715110: CC1A401C 1C728522
	v_dot2_f32_bf16 v31, v38, v66, v31                         // 000000715118: CC1A401F 1C7E8526
	v_dot2_f32_bf16 v32, v42, v66, v32                         // 000000715120: CC1A4020 1C82852A
	v_dot2_f32_bf16 v24, v46, v66, v24                         // 000000715128: CC1A4018 1C62852E
	v_bfe_u32 v83, v26, 16, 1                                  // 000000715130: D6100053 0205211A
	v_add3_u32 v68, v69, v81, 0x7fff                           // 000000715138: D6550044 03FEA345 00007FFF
	v_bfe_u32 v84, v30, 16, 1                                  // 000000715144: D6100054 0205211E
	v_add3_u32 v69, v70, v82, 0x7fff                           // 00000071514C: D6550045 03FEA546 00007FFF
	.long 0x7e88399d                                           // 000000715158: 7E88399D
	v_dot2_f32_bf16 v28, v35, v25, v28                         // 00000071515C: CC1A401C 1C723323
	v_dot2_f32_bf16 v29, v39, v25, v31                         // 000000715164: CC1A401D 1C7E3327
	v_dot2_f32_bf16 v31, v43, v25, v32                         // 00000071516C: CC1A401F 1C82332B
	v_dot2_f32_bf16 v24, v47, v25, v24                         // 000000715174: CC1A4018 1C62332F
	v_bfe_u32 v85, v71, 16, 1                                  // 00000071517C: D6100055 02052147
	v_add3_u32 v26, v26, v83, 0x7fff                           // 000000715184: D655001A 03FEA71A 00007FFF
	v_bfe_u32 v86, v72, 16, 1                                  // 000000715190: D6100056 02052148
	v_add3_u32 v30, v30, v84, 0x7fff                           // 000000715198: D655001E 03FEA91E 00007FFF
	.long 0x7e3439c5                                           // 0000007151A4: 7E3439C5
	s_waitcnt vmcnt(3)                                         // 0000007151A8: BF890FF7
	v_dot2_f32_bf16 v25, v48, v68, v28                         // 0000007151AC: CC1A4019 1C728930
	s_waitcnt vmcnt(2)                                         // 0000007151B4: BF890BF7
	v_dot2_f32_bf16 v28, v52, v68, v29                         // 0000007151B8: CC1A401C 1C768934
	s_waitcnt vmcnt(1)                                         // 0000007151C0: BF8907F7
	v_dot2_f32_bf16 v29, v56, v68, v31                         // 0000007151C4: CC1A401D 1C7E8938
	s_waitcnt vmcnt(0)                                         // 0000007151CC: BF8903F7
	v_dot2_f32_bf16 v24, v60, v68, v24                         // 0000007151D0: CC1A4018 1C62893C
	v_bfe_u32 v87, v27, 16, 1                                  // 0000007151D8: D6100057 0205211B
	v_add3_u32 v70, v71, v85, 0x7fff                           // 0000007151E0: D6550046 03FEAB47 00007FFF
	v_add3_u32 v71, v72, v86, 0x7fff                           // 0000007151EC: D6550047 03FEAD48 00007FFF
	.long 0x7e8c399e                                           // 0000007151F8: 7E8C399E
	v_dot2_f32_bf16 v25, v49, v26, v25                         // 0000007151FC: CC1A4019 1C663531
	v_dot2_f32_bf16 v28, v53, v26, v28                         // 000000715204: CC1A401C 1C723535
	v_dot2_f32_bf16 v29, v57, v26, v29                         // 00000071520C: CC1A401D 1C763539
	v_dot2_f32_bf16 v24, v61, v26, v24                         // 000000715214: CC1A4018 1C62353D
	v_add3_u32 v27, v27, v87, 0x7fff                           // 00000071521C: D655001B 03FEAF1B 00007FFF
	.long 0x7e3639c7                                           // 000000715228: 7E3639C7
	v_dot2_f32_bf16 v25, v50, v70, v25                         // 00000071522C: CC1A4019 1C668D32
	v_dot2_f32_bf16 v26, v54, v70, v28                         // 000000715234: CC1A401A 1C728D36
	v_dot2_f32_bf16 v28, v58, v70, v29                         // 00000071523C: CC1A401C 1C768D3A
	v_dot2_f32_bf16 v24, v62, v70, v24                         // 000000715244: CC1A4018 1C628D3E
	.long 0xd4430000                                           // 00000071524C: D4430000
	v_cndmask_b32_e32 v1, s14, v23, vcc_lo                     // 000000715250: 02022E0E
	v_dot2_f32_bf16 v25, v51, v27, v25                         // 000000715254: CC1A4019 1C663733
	v_dot2_f32_bf16 v26, v55, v27, v26                         // 00000071525C: CC1A401A 1C6A3737
	v_dot2_f32_bf16 v28, v59, v27, v28                         // 000000715264: CC1A401C 1C72373B
	v_dot2_f32_bf16 v24, v63, v27, v24                         // 00000071526C: CC1A4018 1C62373F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000715274: BF870194
	v_dual_add_f32 v11, v11, v25 :: v_dual_add_nc_u32 v22, 0x1a4, v22// 000000715278: C920330B 0B162CFF 000001A4
	v_dual_add_f32 v10, v10, v26 :: v_dual_add_f32 v9, v9, v28 // 000000715284: C908350A 0A083909
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000071528C: BF8704A3
	v_add_f32_e32 v8, v8, v24                                  // 000000715290: 06103108
	s_or_b32 s3, s0, s3                                        // 000000715294: 8C030300
	s_and_not1_b32 exec_lo, exec_lo, s3                        // 000000715298: 917E037E
	s_cbranch_execnz 65127                                     // 00000071529C: BFA6FE67 <_ZN7halogen12_GLOBAL__N_16k_lq6kILi4ELi32ELi1ELb1EEEvPKhPKtPvll+0x13c>
	s_or_b32 exec_lo, exec_lo, s3                              // 0000007152A0: 8C7E037E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007152A4: BF8700A9
	s_or_b32 exec_lo, exec_lo, s1                              // 0000007152A8: 8C7E017E
	.long 0xd71f0000                                           // 0000007152AC: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000007152B0: 020100C1
	v_xor_b32_e32 v3, 16, v0                                   // 0000007152B4: 3A060090
	v_xor_b32_e32 v12, 8, v0                                   // 0000007152B8: 3A180088
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007152BC: BF870092
	.long 0xd44c0000                                           // 0000007152C0: D44C0000
	v_cndmask_b32_e32 v1, 32, v3, vcc_lo                       // 0000007152C4: 020206A0
	v_cndmask_b32_e64 v3, v0, v3, s0                           // 0000007152C8: D5010003 00020700
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007152D0: BF870113
	.long 0xd44c0000                                           // 0000007152D4: D44C0000
	v_cndmask_b32_e32 v1, 32, v12, vcc_lo                      // 0000007152D8: 020218A0
	v_lshlrev_b32_e32 v3, 2, v3                                // 0000007152DC: 30060682
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007152E0: BF870002
	v_cndmask_b32_e64 v12, v0, v12, s0                         // 0000007152E4: D501000C 00021900
	ds_bpermute_b32 v4, v3, v11                                // 0000007152EC: DACC0000 04000B03
	s_waitcnt lgkmcnt(0)                                       // 0000007152F4: BF89FC07
	v_add_f32_e32 v4, v11, v4                                  // 0000007152F8: 0608090B
	ds_bpermute_b32 v5, v3, v10                                // 0000007152FC: DACC0000 05000A03
	ds_bpermute_b32 v6, v3, v9                                 // 000000715304: DACC0000 06000903
	ds_bpermute_b32 v3, v3, v8                                 // 00000071530C: DACC0000 03000803
	s_waitcnt lgkmcnt(2)                                       // 000000715314: BF89FC27
	v_dual_add_f32 v5, v10, v5 :: v_dual_lshlrev_b32 v12, 2, v12// 000000715318: C9220B0A 050C1882
	s_waitcnt lgkmcnt(0)                                       // 000000715320: BF89FC07
	v_dual_add_f32 v6, v9, v6 :: v_dual_add_f32 v3, v8, v3     // 000000715324: C9080D09 06020708
	ds_bpermute_b32 v8, v12, v4                                // 00000071532C: DACC0000 0800040C
	ds_bpermute_b32 v9, v12, v5                                // 000000715334: DACC0000 0900050C
	ds_bpermute_b32 v10, v12, v6                               // 00000071533C: DACC0000 0A00060C
	ds_bpermute_b32 v11, v12, v3                               // 000000715344: DACC0000 0B00030C
	v_xor_b32_e32 v12, 4, v0                                   // 00000071534C: 3A180084
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000715350: BF870091
	.long 0xd44c0000                                           // 000000715354: D44C0000
	v_cndmask_b32_e32 v1, 32, v12, vcc_lo                      // 000000715358: 020218A0
	v_cndmask_b32_e64 v12, v0, v12, s0                         // 00000071535C: D501000C 00021900
	s_delay_alu instid0(VALU_DEP_1)                            // 000000715364: BF870001
	v_lshlrev_b32_e32 v12, 2, v12                              // 000000715368: 30181882
	s_waitcnt lgkmcnt(2)                                       // 00000071536C: BF89FC27
	v_dual_add_f32 v4, v4, v8 :: v_dual_add_f32 v5, v5, v9     // 000000715370: C9081104 04041305
	s_waitcnt lgkmcnt(0)                                       // 000000715378: BF89FC07
	v_add_f32_e32 v3, v3, v11                                  // 00000071537C: 06061703
	ds_bpermute_b32 v8, v12, v4                                // 000000715380: DACC0000 0800040C
	ds_bpermute_b32 v9, v12, v5                                // 000000715388: DACC0000 0900050C
	v_add_f32_e32 v6, v6, v10                                  // 000000715390: 060C1506
	ds_bpermute_b32 v11, v12, v3                               // 000000715394: DACC0000 0B00030C
	s_waitcnt lgkmcnt(1)                                       // 00000071539C: BF89FC17
	v_dual_add_f32 v4, v4, v8 :: v_dual_add_f32 v5, v5, v9     // 0000007153A0: C9081104 04041305
	ds_bpermute_b32 v10, v12, v6                               // 0000007153A8: DACC0000 0A00060C
	v_xor_b32_e32 v12, 2, v0                                   // 0000007153B0: 3A180082
	s_waitcnt lgkmcnt(1)                                       // 0000007153B4: BF89FC17
	v_add_f32_e32 v3, v3, v11                                  // 0000007153B8: 06061703
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007153BC: BF870092
	.long 0xd44c0000                                           // 0000007153C0: D44C0000
	v_cndmask_b32_e32 v1, 32, v12, vcc_lo                      // 0000007153C4: 020218A0
	v_cndmask_b32_e64 v12, v0, v12, s0                         // 0000007153C8: D501000C 00021900
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007153D0: BF870001
	v_lshlrev_b32_e32 v12, 2, v12                              // 0000007153D4: 30181882
	s_waitcnt lgkmcnt(0)                                       // 0000007153D8: BF89FC07
	v_add_f32_e32 v8, v6, v10                                  // 0000007153DC: 06101506
	ds_bpermute_b32 v6, v12, v4                                // 0000007153E0: DACC0000 0600040C
	ds_bpermute_b32 v9, v12, v5                                // 0000007153E8: DACC0000 0900050C
	ds_bpermute_b32 v11, v12, v3                               // 0000007153F0: DACC0000 0B00030C
	ds_bpermute_b32 v10, v12, v8                               // 0000007153F8: DACC0000 0A00080C
	v_xor_b32_e32 v12, 1, v0                                   // 000000715400: 3A180081
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000715404: BF870091
	.long 0xd44c0000                                           // 000000715408: D44C0000
	v_cndmask_b32_e32 v1, 32, v12, vcc_lo                      // 00000071540C: 020218A0
	v_cndmask_b32_e64 v0, v0, v12, s0                          // 000000715410: D5010000 00021900
	.long 0xd44a0000                                           // 000000715418: D44A0000
	v_cndmask_b32_e32 v1, 0, v7, vcc_lo                        // 00000071541C: 02020E80
	s_delay_alu instid0(VALU_DEP_2)                            // 000000715420: BF870002
	v_lshlrev_b32_e32 v12, 2, v0                               // 000000715424: 30180082
	s_waitcnt lgkmcnt(3)                                       // 000000715428: BF89FC37
	v_add_f32_e32 v4, v4, v6                                   // 00000071542C: 06080D04
	s_waitcnt lgkmcnt(2)                                       // 000000715430: BF89FC27
	v_add_f32_e32 v6, v5, v9                                   // 000000715434: 060C1305
	s_waitcnt lgkmcnt(1)                                       // 000000715438: BF89FC17
	v_add_f32_e32 v0, v3, v11                                  // 00000071543C: 06001703
	s_waitcnt lgkmcnt(0)                                       // 000000715440: BF89FC07
	v_add_f32_e32 v8, v8, v10                                  // 000000715444: 06101508
	s_and_b32 s0, s0, vcc_lo                                   // 000000715448: 8B006A00
	ds_bpermute_b32 v5, v12, v4                                // 00000071544C: DACC0000 0500040C
	ds_bpermute_b32 v9, v12, v6                                // 000000715454: DACC0000 0900060C
	ds_bpermute_b32 v3, v12, v0                                // 00000071545C: DACC0000 0300000C
	ds_bpermute_b32 v10, v12, v8                               // 000000715464: DACC0000 0A00080C
	s_and_saveexec_b32 s1, s0                                  // 00000071546C: BE812000
	s_cbranch_execz 37                                         // 000000715470: BFA50025 <_ZN7halogen12_GLOBAL__N_16k_lq6kILi4ELi32ELi1ELb1EEEvPKhPKtPvll+0xa08>
	.long 0xd73c0001                                           // 000000715474: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 000000715478: 02020282
	s_waitcnt lgkmcnt(0)                                       // 00000071547C: BF89FC07
	v_dual_add_f32 v10, v8, v10 :: v_dual_add_f32 v11, v6, v9  // 000000715480: C9081508 0A0A1306
	s_lshl_b64 s[0:1], s[12:13], 2                             // 000000715488: 8480820C
	v_add_f32_e32 v12, v4, v5                                  // 00000071548C: 06180B04
	s_lshl_b64 s[2:3], s[12:13], 3                             // 000000715490: 8482830C
	.long 0xd7006a01                                           // 000000715494: D7006A01
	v_cndmask_b32_e32 v1, s8, v1, vcc_lo                       // 000000715498: 02020208
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000071549C: BF8701A1
	v_add_co_ci_u32_e64 v2, null, s9, v2, vcc_lo               // 0000007154A0: D5207C02 01AA0409
	v_add_f32_e32 v0, v0, v3                                   // 0000007154A8: 06000700
	.long 0xd7006a04                                           // 0000007154AC: D7006A04
	v_cndmask_b32_e32 v0, v1, v0, vcc_lo                       // 0000007154B0: 02000101
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000007154B4: BF870123
	v_mad_u64_u32 v[6:7], null, s12, 12, v[1:2]                // 0000007154B8: D6FE7C06 0405180C
	v_add_co_ci_u32_e64 v5, null, s1, v2, vcc_lo               // 0000007154C0: D5207C05 01AA0401
	v_mad_u64_u32 v[7:8], null, s13, 12, v[7:8]                // 0000007154C8: D6FE7C07 041D180D
	.long 0xd7006a08                                           // 0000007154D0: D7006A08
	v_cndmask_b32_e32 v0, v1, v2, vcc_lo                       // 0000007154D4: 02000501
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007154D8: BF870001
	v_add_co_ci_u32_e64 v9, null, s3, v2, vcc_lo               // 0000007154DC: D5207C09 01AA0403
	s_clause 0x3                                               // 0000007154E4: BF850003
	global_store_b32 v[1:2], v12, off                          // 0000007154E8: DC6A0000 007C0C01
	global_store_b32 v[4:5], v11, off                          // 0000007154F0: DC6A0000 007C0B04
	global_store_b32 v[8:9], v10, off                          // 0000007154F8: DC6A0000 007C0A08
	global_store_b32 v[6:7], v0, off                           // 000000715500: DC6A0000 007C0006
	s_endpgm                                                   // 000000715508: BFB00000
		...

