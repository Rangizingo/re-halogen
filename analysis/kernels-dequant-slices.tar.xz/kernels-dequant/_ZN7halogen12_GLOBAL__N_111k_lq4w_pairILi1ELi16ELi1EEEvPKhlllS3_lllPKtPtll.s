0000000000287500 <_ZN7halogen12_GLOBAL__N_111k_lq4w_pairILi1ELi16ELi1EEEvPKhlllS3_lllPKtPtll>:
; _ZN7halogen12_GLOBAL__N_111k_lq4w_pairILi1ELi16ELi1EEEvPKhlllS3_lllPKtPtll():
	s_load_b512 s[4:19], s[0:1], null                          // 000000287500: F4100100 F8000000
	v_and_b32_e32 v27, 15, v0                                  // 000000287508: 3636008F
	v_lshrrev_b32_e32 v1, 4, v0                                // 00000028750C: 32020084
	s_mov_b32 s3, 0                                            // 000000287510: BE830080
	s_load_b256 s[20:27], s[0:1], 0x40                         // 000000287514: F40C0500 F8000040
	s_lshl_b64 s[0:1], s[2:3], 4                               // 00000028751C: 84808402
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000287520: BF870009
	v_dual_mov_b32 v17, s1 :: v_dual_lshlrev_b32 v2, 2, v27    // 000000287524: CA220001 11023682
	v_lshlrev_b32_e32 v3, 2, v1                                // 00000028752C: 30060282
	v_and_b32_e32 v6, 14, v1                                   // 000000287530: 360C028E
	v_and_b32_e32 v1, 1, v1                                    // 000000287534: 36020281
	v_lshlrev_b32_e32 v7, 2, v0                                // 000000287538: 300E0082
	s_waitcnt lgkmcnt(0)                                       // 00000028753C: BF89FC07
	s_clause 0x1                                               // 000000287540: BF850001
	global_load_b32 v4, v2, s[4:5]                             // 000000287544: DC520000 04040002
	global_load_b32 v2, v2, s[12:13]                           // 00000028754C: DC520000 020C0002
	s_clause 0x1                                               // 000000287554: BF850001
	global_load_b32 v5, v3, s[4:5]                             // 000000287558: DC520000 05040003
	global_load_b32 v3, v3, s[12:13]                           // 000000287560: DC520000 030C0003
	v_or3_b32 v16, s0, v6, v1                                  // 000000287568: D6580010 04060C00
	.long 0x7f0c3880                                           // 000000287570: 7F0C3880
	s_ashr_i32 s2, s25, 31                                     // 000000287574: 86029F19
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000287578: BF8704A2
	.long 0xd4540000                                           // 00000028757C: D4540000
	v_cndmask_b32_e32 v1, s26, v16, vcc_lo                     // 000000287580: 0202201A
	s_lshr_b32 s2, s2, 27                                      // 000000287584: 85029B02
	s_add_u32 s2, s24, s2                                      // 000000287588: 80020218
	s_addc_u32 s3, s25, 0                                      // 00000028758C: 82038019
	v_cndmask_b32_e64 v1, 0, v16, s0                           // 000000287590: D5010001 00022080
	v_cndmask_b32_e64 v0, 0, s1, s0                            // 000000287598: D5010000 00000280
	s_lshr_b64 s[26:27], s[2:3], 5                             // 0000002875A0: 859A8502
	s_add_u32 s3, s4, s8                                       // 0000002875A4: 80030804
	.long 0xd4440002                                           // 0000002875A8: D4440002
	v_cndmask_b32_e32 v1, s26, v27, vcc_lo                     // 0000002875AC: 0202361A
	.long 0xd72c000c                                           // 0000002875B0: D72C000C
	v_cndmask_b32_e32 v0, v1, v11, vcc_lo                      // 0000002875B4: 02001701
	v_mad_u64_u32 v[10:11], null, v1, s10, 0                   // 0000002875B8: D6FE7C0A 02001501
	.long 0xd72c000e                                           // 0000002875C0: D72C000E
	v_cndmask_b32_e32 v0, v0, v10, vcc_lo                      // 0000002875C4: 02001500
	.long 0xd72c000d                                           // 0000002875C8: D72C000D
	v_cndmask_b32_e32 v0, v1, v19, vcc_lo                      // 0000002875CC: 02002701
	v_mad_u64_u32 v[8:9], null, v1, s18, 0                     // 0000002875D0: D6FE7C08 02002501
	.long 0xd72c0012                                           // 0000002875D8: D72C0012
	v_cndmask_b32_e32 v0, v0, v18, vcc_lo                      // 0000002875DC: 02002500
	s_addc_u32 s11, s5, s9                                     // 0000002875E0: 820B0905
	s_add_u32 s19, s12, s16                                    // 0000002875E4: 8013100C
	s_addc_u32 s27, s13, s17                                   // 0000002875E8: 821B110D
	s_cmpk_lt_i32 s26, 0x81                                    // 0000002875EC: B39A0081
	v_add3_u32 v11, v11, v12, v14                              // 0000002875F0: D655000B 043A190B
	.long 0xd700030e                                           // 0000002875F8: D700030E
	v_cndmask_b32_e32 v1, s3, v10, vcc_lo                      // 0000002875FC: 02021403
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 000000287600: BF8704C3
	v_add3_u32 v9, v9, v13, v18                                // 000000287604: D6550009 044A1B09
	s_cselect_b32 s1, -1, 0                                    // 00000028760C: 980180C1
	s_cmpk_gt_i32 s26, 0x80                                    // 000000287610: B29A0080
	s_cselect_b32 s10, -1, 0                                   // 000000287614: 980A80C1
	s_and_b32 vcc_lo, exec_lo, s10                             // 000000287618: 8B6A0A7E
	s_waitcnt vmcnt(3)                                         // 00000028761C: BF890FF7
	v_bfe_u32 v15, v4, 16, 1                                   // 000000287620: D610000F 02052104
	s_waitcnt vmcnt(1)                                         // 000000287628: BF8907F7
	v_bfe_u32 v19, v5, 16, 1                                   // 00000028762C: D6100013 02052105
	s_waitcnt vmcnt(0)                                         // 000000287634: BF8903F7
	v_bfe_u32 v20, v3, 16, 1                                   // 000000287638: D6100014 02052103
	v_add3_u32 v4, v4, v15, 0x7fff                             // 000000287640: D6550004 03FE1F04 00007FFF
	v_bfe_u32 v15, v2, 16, 1                                   // 00000028764C: D610000F 02052102
	v_add3_u32 v5, v5, v19, 0x7fff                             // 000000287654: D6550005 03FE2705 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000287660: BF870214
	v_add3_u32 v3, v3, v20, 0x7fff                             // 000000287664: D6550003 03FE2903 00007FFF
	.long 0x7e0c3984                                           // 000000287670: 7E0C3984
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000287674: BF870234
	v_add3_u32 v2, v2, v15, 0x7fff                             // 000000287678: D6550002 03FE1F02 00007FFF
	v_add_co_ci_u32_e64 v15, null, s11, v11, s3                // 000000287684: D5207C0F 000E160B
	.long 0xd700030c                                           // 00000028768C: D700030C
	v_cndmask_b32_e32 v1, s19, v8, vcc_lo                      // 000000287690: 02021013
	v_and_or_b32 v4, 0xffff0000, v5, v6                        // 000000287694: D6570004 041A0AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002876A0: BF870124
	.long 0x7e0c3982                                           // 0000002876A4: 7E0C3982
	v_add_co_ci_u32_e64 v13, null, s27, v9, s3                 // 0000002876A8: D5207C0D 000E121B
	v_and_or_b32 v2, 0xffff0000, v3, v6                        // 0000002876B0: D6570002 041A06FF FFFF0000
	ds_store_2addr_stride64_b32 v7, v4, v2 offset1:4           // 0000002876BC: D83C0400 00020407
	s_waitcnt lgkmcnt(0)                                       // 0000002876C4: BF89FC07
	s_barrier                                                  // 0000002876C8: BFBD0000
	buffer_gl0_inv                                             // 0000002876CC: E0AC0000 00000000
	s_cbranch_vccnz 242                                        // 0000002876D4: BFA400F2 <_ZN7halogen12_GLOBAL__N_111k_lq4w_pairILi1ELi16ELi1EEEvPKhlllS3_lllPKtPtll+0x5a0>
	v_mov_b32_e32 v32, 0                                       // 0000002876D8: 7E400280
	v_mov_b32_e32 v34, 0                                       // 0000002876DC: 7E440280
	s_and_saveexec_b32 s3, s2                                  // 0000002876E0: BE832002
	s_cbranch_execz 10                                         // 0000002876E4: BFA5000A <_ZN7halogen12_GLOBAL__N_111k_lq4w_pairILi1ELi16ELi1EEEvPKhlllS3_lllPKtPtll+0x210>
	v_lshlrev_b32_e32 v2, 1, v27                               // 0000002876E8: 30043681
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002876EC: BF870091
	.long 0xd7006a02                                           // 0000002876F0: D7006A02
	v_cndmask_b32_e32 v1, v14, v2, vcc_lo                      // 0000002876F4: 0202050E
	v_add_co_ci_u32_e64 v3, null, 0, v15, vcc_lo               // 0000002876F8: D5207C03 01AA1E80
	global_load_d16_b16 v2, v[2:3], off                        // 000000287700: DC820000 027C0002
	s_waitcnt vmcnt(0)                                         // 000000287708: BF8903F7
	v_cvt_f32_f16_e32 v34, v2                                  // 00000028770C: 7E441702
	s_or_b32 exec_lo, exec_lo, s3                              // 000000287710: 8C7E037E
	s_and_saveexec_b32 s3, s2                                  // 000000287714: BE832002
	s_cbranch_execz 10                                         // 000000287718: BFA5000A <_ZN7halogen12_GLOBAL__N_111k_lq4w_pairILi1ELi16ELi1EEEvPKhlllS3_lllPKtPtll+0x244>
	v_lshlrev_b32_e32 v2, 1, v27                               // 00000028771C: 30043681
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000287720: BF870091
	.long 0xd7006a02                                           // 000000287724: D7006A02
	v_cndmask_b32_e32 v1, v12, v2, vcc_lo                      // 000000287728: 0202050C
	v_add_co_ci_u32_e64 v3, null, 0, v13, vcc_lo               // 00000028772C: D5207C03 01AA1A80
	global_load_d16_b16 v2, v[2:3], off                        // 000000287734: DC820000 027C0002
	s_waitcnt vmcnt(0)                                         // 00000028773C: BF8903F7
	v_cvt_f32_f16_e32 v32, v2                                  // 000000287740: 7E401702
	s_or_b32 exec_lo, exec_lo, s3                              // 000000287744: 8C7E037E
	v_or_b32_e32 v2, 16, v27                                   // 000000287748: 38043690
	v_dual_mov_b32 v41, 0 :: v_dual_mov_b32 v28, 0             // 00000028774C: CA100080 291C0080
	s_delay_alu instid0(VALU_DEP_2)                            // 000000287754: BF870002
	v_cmp_gt_i32_e32 vcc_lo, s26, v2                           // 000000287758: 7C88041A
	v_lshlrev_b32_e32 v2, 1, v2                                // 00000028775C: 30040481
	s_and_saveexec_b32 s3, vcc_lo                              // 000000287760: BE83206A
	s_cbranch_execz 9                                          // 000000287764: BFA50009 <_ZN7halogen12_GLOBAL__N_111k_lq4w_pairILi1ELi16ELi1EEEvPKhlllS3_lllPKtPtll+0x28c>
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000287768: BF870091
	.long 0xd7000203                                           // 00000028776C: D7000203
	v_cndmask_b32_e32 v1, v14, v2, vcc_lo                      // 000000287770: 0202050E
	v_add_co_ci_u32_e64 v4, null, 0, v15, s2                   // 000000287774: D5207C04 000A1E80
	global_load_d16_b16 v3, v[3:4], off                        // 00000028777C: DC820000 037C0003
	s_waitcnt vmcnt(0)                                         // 000000287784: BF8903F7
	v_cvt_f32_f16_e32 v28, v3                                  // 000000287788: 7E381703
	s_or_b32 exec_lo, exec_lo, s3                              // 00000028778C: 8C7E037E
	s_and_saveexec_b32 s2, vcc_lo                              // 000000287790: BE82206A
	s_cbranch_execz 9                                          // 000000287794: BFA50009 <_ZN7halogen12_GLOBAL__N_111k_lq4w_pairILi1ELi16ELi1EEEvPKhlllS3_lllPKtPtll+0x2bc>
	.long 0xd7006a02                                           // 000000287798: D7006A02
	v_cndmask_b32_e32 v1, v12, v2, vcc_lo                      // 00000028779C: 0202050C
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002877A0: BF870001
	v_add_co_ci_u32_e64 v3, null, 0, v13, vcc_lo               // 0000002877A4: D5207C03 01AA1A80
	global_load_d16_b16 v2, v[2:3], off                        // 0000002877AC: DC820000 027C0002
	s_waitcnt vmcnt(0)                                         // 0000002877B4: BF8903F7
	v_cvt_f32_f16_e32 v41, v2                                  // 0000002877B8: 7E521702
	s_or_b32 exec_lo, exec_lo, s2                              // 0000002877BC: 8C7E027E
	v_or_b32_e32 v2, 32, v27                                   // 0000002877C0: 380436A0
	v_mov_b32_e32 v43, 0                                       // 0000002877C4: 7E560280
	v_mov_b32_e32 v29, 0                                       // 0000002877C8: 7E3A0280
	s_delay_alu instid0(VALU_DEP_3)                            // 0000002877CC: BF870003
	v_cmp_gt_i32_e32 vcc_lo, s26, v2                           // 0000002877D0: 7C88041A
	v_lshlrev_b32_e32 v2, 1, v2                                // 0000002877D4: 30040481
	s_and_saveexec_b32 s3, vcc_lo                              // 0000002877D8: BE83206A
	s_cbranch_execz 9                                          // 0000002877DC: BFA50009 <_ZN7halogen12_GLOBAL__N_111k_lq4w_pairILi1ELi16ELi1EEEvPKhlllS3_lllPKtPtll+0x304>
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002877E0: BF870091
	.long 0xd7000203                                           // 0000002877E4: D7000203
	v_cndmask_b32_e32 v1, v14, v2, vcc_lo                      // 0000002877E8: 0202050E
	v_add_co_ci_u32_e64 v4, null, 0, v15, s2                   // 0000002877EC: D5207C04 000A1E80
	global_load_d16_b16 v3, v[3:4], off                        // 0000002877F4: DC820000 037C0003
	s_waitcnt vmcnt(0)                                         // 0000002877FC: BF8903F7
	v_cvt_f32_f16_e32 v29, v3                                  // 000000287800: 7E3A1703
	s_or_b32 exec_lo, exec_lo, s3                              // 000000287804: 8C7E037E
	s_and_saveexec_b32 s2, vcc_lo                              // 000000287808: BE82206A
	s_cbranch_execz 9                                          // 00000028780C: BFA50009 <_ZN7halogen12_GLOBAL__N_111k_lq4w_pairILi1ELi16ELi1EEEvPKhlllS3_lllPKtPtll+0x334>
	.long 0xd7006a02                                           // 000000287810: D7006A02
	v_cndmask_b32_e32 v1, v12, v2, vcc_lo                      // 000000287814: 0202050C
	s_delay_alu instid0(VALU_DEP_1)                            // 000000287818: BF870001
	v_add_co_ci_u32_e64 v3, null, 0, v13, vcc_lo               // 00000028781C: D5207C03 01AA1A80
	global_load_d16_b16 v2, v[2:3], off                        // 000000287824: DC820000 027C0002
	s_waitcnt vmcnt(0)                                         // 00000028782C: BF8903F7
	v_cvt_f32_f16_e32 v43, v2                                  // 000000287830: 7E561702
	s_or_b32 exec_lo, exec_lo, s2                              // 000000287834: 8C7E027E
	v_or_b32_e32 v2, 48, v27                                   // 000000287838: 380436B0
	v_mov_b32_e32 v46, 0                                       // 00000028783C: 7E5C0280
	v_mov_b32_e32 v30, 0                                       // 000000287840: 7E3C0280
	s_delay_alu instid0(VALU_DEP_3)                            // 000000287844: BF870003
	v_cmp_gt_i32_e32 vcc_lo, s26, v2                           // 000000287848: 7C88041A
	v_lshlrev_b32_e32 v2, 1, v2                                // 00000028784C: 30040481
	s_and_saveexec_b32 s3, vcc_lo                              // 000000287850: BE83206A
	s_cbranch_execz 9                                          // 000000287854: BFA50009 <_ZN7halogen12_GLOBAL__N_111k_lq4w_pairILi1ELi16ELi1EEEvPKhlllS3_lllPKtPtll+0x37c>
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000287858: BF870091
	.long 0xd7000203                                           // 00000028785C: D7000203
	v_cndmask_b32_e32 v1, v14, v2, vcc_lo                      // 000000287860: 0202050E
	v_add_co_ci_u32_e64 v4, null, 0, v15, s2                   // 000000287864: D5207C04 000A1E80
	global_load_d16_b16 v3, v[3:4], off                        // 00000028786C: DC820000 037C0003
	s_waitcnt vmcnt(0)                                         // 000000287874: BF8903F7
	v_cvt_f32_f16_e32 v30, v3                                  // 000000287878: 7E3C1703
	s_or_b32 exec_lo, exec_lo, s3                              // 00000028787C: 8C7E037E
	s_and_saveexec_b32 s2, vcc_lo                              // 000000287880: BE82206A
	s_cbranch_execz 9                                          // 000000287884: BFA50009 <_ZN7halogen12_GLOBAL__N_111k_lq4w_pairILi1ELi16ELi1EEEvPKhlllS3_lllPKtPtll+0x3ac>
	.long 0xd7006a02                                           // 000000287888: D7006A02
	v_cndmask_b32_e32 v1, v12, v2, vcc_lo                      // 00000028788C: 0202050C
	s_delay_alu instid0(VALU_DEP_1)                            // 000000287890: BF870001
	v_add_co_ci_u32_e64 v3, null, 0, v13, vcc_lo               // 000000287894: D5207C03 01AA1A80
	global_load_d16_b16 v2, v[2:3], off                        // 00000028789C: DC820000 027C0002
	s_waitcnt vmcnt(0)                                         // 0000002878A4: BF8903F7
	v_cvt_f32_f16_e32 v46, v2                                  // 0000002878A8: 7E5C1702
	s_or_b32 exec_lo, exec_lo, s2                              // 0000002878AC: 8C7E027E
	v_or_b32_e32 v2, 64, v27                                   // 0000002878B0: 380436C0
	v_dual_mov_b32 v48, 0 :: v_dual_mov_b32 v31, 0             // 0000002878B4: CA100080 301E0080
	s_delay_alu instid0(VALU_DEP_2)                            // 0000002878BC: BF870002
	v_cmp_gt_i32_e32 vcc_lo, s26, v2                           // 0000002878C0: 7C88041A
	v_lshlrev_b32_e32 v2, 1, v2                                // 0000002878C4: 30040481
	s_and_saveexec_b32 s3, vcc_lo                              // 0000002878C8: BE83206A
	s_cbranch_execz 9                                          // 0000002878CC: BFA50009 <_ZN7halogen12_GLOBAL__N_111k_lq4w_pairILi1ELi16ELi1EEEvPKhlllS3_lllPKtPtll+0x3f4>
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002878D0: BF870091
	.long 0xd7000203                                           // 0000002878D4: D7000203
	v_cndmask_b32_e32 v1, v14, v2, vcc_lo                      // 0000002878D8: 0202050E
	v_add_co_ci_u32_e64 v4, null, 0, v15, s2                   // 0000002878DC: D5207C04 000A1E80
	global_load_d16_b16 v3, v[3:4], off                        // 0000002878E4: DC820000 037C0003
	s_waitcnt vmcnt(0)                                         // 0000002878EC: BF8903F7
	v_cvt_f32_f16_e32 v31, v3                                  // 0000002878F0: 7E3E1703
	s_or_b32 exec_lo, exec_lo, s3                              // 0000002878F4: 8C7E037E
	s_and_saveexec_b32 s2, vcc_lo                              // 0000002878F8: BE82206A
	s_cbranch_execz 9                                          // 0000002878FC: BFA50009 <_ZN7halogen12_GLOBAL__N_111k_lq4w_pairILi1ELi16ELi1EEEvPKhlllS3_lllPKtPtll+0x424>
	.long 0xd7006a02                                           // 000000287900: D7006A02
	v_cndmask_b32_e32 v1, v12, v2, vcc_lo                      // 000000287904: 0202050C
	s_delay_alu instid0(VALU_DEP_1)                            // 000000287908: BF870001
	v_add_co_ci_u32_e64 v3, null, 0, v13, vcc_lo               // 00000028790C: D5207C03 01AA1A80
	global_load_d16_b16 v2, v[2:3], off                        // 000000287914: DC820000 027C0002
	s_waitcnt vmcnt(0)                                         // 00000028791C: BF8903F7
	v_cvt_f32_f16_e32 v48, v2                                  // 000000287920: 7E601702
	s_or_b32 exec_lo, exec_lo, s2                              // 000000287924: 8C7E027E
	v_or_b32_e32 v2, 0x50, v27                                 // 000000287928: 380436FF 00000050
	v_mov_b32_e32 v49, 0                                       // 000000287930: 7E620280
	v_mov_b32_e32 v33, 0                                       // 000000287934: 7E420280
	s_delay_alu instid0(VALU_DEP_3)                            // 000000287938: BF870003
	v_cmp_gt_i32_e32 vcc_lo, s26, v2                           // 00000028793C: 7C88041A
	v_lshlrev_b32_e32 v2, 1, v2                                // 000000287940: 30040481
	s_and_saveexec_b32 s3, vcc_lo                              // 000000287944: BE83206A
	s_cbranch_execz 9                                          // 000000287948: BFA50009 <_ZN7halogen12_GLOBAL__N_111k_lq4w_pairILi1ELi16ELi1EEEvPKhlllS3_lllPKtPtll+0x470>
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000028794C: BF870091
	.long 0xd7000203                                           // 000000287950: D7000203
	v_cndmask_b32_e32 v1, v14, v2, vcc_lo                      // 000000287954: 0202050E
	v_add_co_ci_u32_e64 v4, null, 0, v15, s2                   // 000000287958: D5207C04 000A1E80
	global_load_d16_b16 v3, v[3:4], off                        // 000000287960: DC820000 037C0003
	s_waitcnt vmcnt(0)                                         // 000000287968: BF8903F7
	v_cvt_f32_f16_e32 v33, v3                                  // 00000028796C: 7E421703
	s_or_b32 exec_lo, exec_lo, s3                              // 000000287970: 8C7E037E
	s_and_saveexec_b32 s2, vcc_lo                              // 000000287974: BE82206A
	s_cbranch_execz 9                                          // 000000287978: BFA50009 <_ZN7halogen12_GLOBAL__N_111k_lq4w_pairILi1ELi16ELi1EEEvPKhlllS3_lllPKtPtll+0x4a0>
	.long 0xd7006a02                                           // 00000028797C: D7006A02
	v_cndmask_b32_e32 v1, v12, v2, vcc_lo                      // 000000287980: 0202050C
	s_delay_alu instid0(VALU_DEP_1)                            // 000000287984: BF870001
	v_add_co_ci_u32_e64 v3, null, 0, v13, vcc_lo               // 000000287988: D5207C03 01AA1A80
	global_load_d16_b16 v2, v[2:3], off                        // 000000287990: DC820000 027C0002
	s_waitcnt vmcnt(0)                                         // 000000287998: BF8903F7
	v_cvt_f32_f16_e32 v49, v2                                  // 00000028799C: 7E621702
	s_or_b32 exec_lo, exec_lo, s2                              // 0000002879A0: 8C7E027E
	v_or_b32_e32 v2, 0x60, v27                                 // 0000002879A4: 380436FF 00000060
	v_mov_b32_e32 v47, 0                                       // 0000002879AC: 7E5E0280
	v_mov_b32_e32 v35, 0                                       // 0000002879B0: 7E460280
	s_delay_alu instid0(VALU_DEP_3)                            // 0000002879B4: BF870003
	v_cmp_gt_i32_e32 vcc_lo, s26, v2                           // 0000002879B8: 7C88041A
	v_lshlrev_b32_e32 v2, 1, v2                                // 0000002879BC: 30040481
	s_and_saveexec_b32 s3, vcc_lo                              // 0000002879C0: BE83206A
	s_cbranch_execz 9                                          // 0000002879C4: BFA50009 <_ZN7halogen12_GLOBAL__N_111k_lq4w_pairILi1ELi16ELi1EEEvPKhlllS3_lllPKtPtll+0x4ec>
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002879C8: BF870091
	.long 0xd7000203                                           // 0000002879CC: D7000203
	v_cndmask_b32_e32 v1, v14, v2, vcc_lo                      // 0000002879D0: 0202050E
	v_add_co_ci_u32_e64 v4, null, 0, v15, s2                   // 0000002879D4: D5207C04 000A1E80
	global_load_d16_b16 v3, v[3:4], off                        // 0000002879DC: DC820000 037C0003
	s_waitcnt vmcnt(0)                                         // 0000002879E4: BF8903F7
	v_cvt_f32_f16_e32 v35, v3                                  // 0000002879E8: 7E461703
	s_or_b32 exec_lo, exec_lo, s3                              // 0000002879EC: 8C7E037E
	s_and_saveexec_b32 s2, vcc_lo                              // 0000002879F0: BE82206A
	s_cbranch_execz 9                                          // 0000002879F4: BFA50009 <_ZN7halogen12_GLOBAL__N_111k_lq4w_pairILi1ELi16ELi1EEEvPKhlllS3_lllPKtPtll+0x51c>
	.long 0xd7006a02                                           // 0000002879F8: D7006A02
	v_cndmask_b32_e32 v1, v12, v2, vcc_lo                      // 0000002879FC: 0202050C
	s_delay_alu instid0(VALU_DEP_1)                            // 000000287A00: BF870001
	v_add_co_ci_u32_e64 v3, null, 0, v13, vcc_lo               // 000000287A04: D5207C03 01AA1A80
	global_load_d16_b16 v2, v[2:3], off                        // 000000287A0C: DC820000 027C0002
	s_waitcnt vmcnt(0)                                         // 000000287A14: BF8903F7
	v_cvt_f32_f16_e32 v47, v2                                  // 000000287A18: 7E5E1702
	s_or_b32 exec_lo, exec_lo, s2                              // 000000287A1C: 8C7E027E
	v_or_b32_e32 v2, 0x70, v27                                 // 000000287A20: 380436FF 00000070
	v_dual_mov_b32 v37, 0 :: v_dual_mov_b32 v36, 0             // 000000287A28: CA100080 25240080
	s_delay_alu instid0(VALU_DEP_2)                            // 000000287A30: BF870002
	v_cmp_gt_i32_e32 vcc_lo, s26, v2                           // 000000287A34: 7C88041A
	v_lshlrev_b32_e32 v2, 1, v2                                // 000000287A38: 30040481
	s_and_saveexec_b32 s3, vcc_lo                              // 000000287A3C: BE83206A
	s_cbranch_execz 9                                          // 000000287A40: BFA50009 <_ZN7halogen12_GLOBAL__N_111k_lq4w_pairILi1ELi16ELi1EEEvPKhlllS3_lllPKtPtll+0x568>
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000287A44: BF870091
	.long 0xd7000203                                           // 000000287A48: D7000203
	v_cndmask_b32_e32 v1, v14, v2, vcc_lo                      // 000000287A4C: 0202050E
	v_add_co_ci_u32_e64 v4, null, 0, v15, s2                   // 000000287A50: D5207C04 000A1E80
	global_load_d16_b16 v3, v[3:4], off                        // 000000287A58: DC820000 037C0003
	s_waitcnt vmcnt(0)                                         // 000000287A60: BF8903F7
	v_cvt_f32_f16_e32 v36, v3                                  // 000000287A64: 7E481703
	s_or_b32 exec_lo, exec_lo, s3                              // 000000287A68: 8C7E037E
	s_and_saveexec_b32 s2, vcc_lo                              // 000000287A6C: BE82206A
	s_cbranch_execz 9                                          // 000000287A70: BFA50009 <_ZN7halogen12_GLOBAL__N_111k_lq4w_pairILi1ELi16ELi1EEEvPKhlllS3_lllPKtPtll+0x598>
	.long 0xd7006a02                                           // 000000287A74: D7006A02
	v_cndmask_b32_e32 v1, v12, v2, vcc_lo                      // 000000287A78: 0202050C
	s_delay_alu instid0(VALU_DEP_1)                            // 000000287A7C: BF870001
	v_add_co_ci_u32_e64 v3, null, 0, v13, vcc_lo               // 000000287A80: D5207C03 01AA1A80
	global_load_d16_b16 v2, v[2:3], off                        // 000000287A88: DC820000 027C0002
	s_waitcnt vmcnt(0)                                         // 000000287A90: BF8903F7
	v_cvt_f32_f16_e32 v37, v2                                  // 000000287A94: 7E4A1702
	s_or_b32 exec_lo, exec_lo, s2                              // 000000287A98: 8C7E027E
	s_branch 8                                                 // 000000287A9C: BFA00008 <_ZN7halogen12_GLOBAL__N_111k_lq4w_pairILi1ELi16ELi1EEEvPKhlllS3_lllPKtPtll+0x5c0>
	v_dual_mov_b32 v36, 0 :: v_dual_mov_b32 v35, 0             // 000000287AA0: CA100080 24220080
	v_dual_mov_b32 v33, 0 :: v_dual_mov_b32 v30, 0             // 000000287AA8: CA100080 211E0080
	v_dual_mov_b32 v31, 0 :: v_dual_mov_b32 v28, 0             // 000000287AB0: CA100080 1F1C0080
	v_dual_mov_b32 v29, 0 :: v_dual_mov_b32 v34, 0             // 000000287AB8: CA100080 1D220080
	s_add_u32 s2, s4, s6                                       // 000000287AC0: 80020604
	s_addc_u32 s3, s5, s7                                      // 000000287AC4: 82030705
	s_lshr_b32 s6, s25, 31                                     // 000000287AC8: 85069F19
	v_mov_b32_e32 v40, 0                                       // 000000287ACC: 7E500280
	s_add_u32 s6, s24, s6                                      // 000000287AD0: 80060618
	s_addc_u32 s7, s25, 0                                      // 000000287AD4: 82078019
	v_cndmask_b32_e64 v38, 0, 1, s10                           // 000000287AD8: D5010026 00290280
	s_ashr_i64 s[6:7], s[6:7], 1                               // 000000287AE0: 86868106
	s_add_u32 s14, s12, s14                                    // 000000287AE4: 800E0E0C
	s_addc_u32 s15, s13, s15                                   // 000000287AE8: 820F0F0D
	v_mad_u64_u32 v[18:19], null, v1, s6, s[2:3]               // 000000287AEC: D6FE7C12 00080D01
	.long 0xd72c0002                                           // 000000287AF4: D72C0002
	v_cndmask_b32_e32 v0, v1, v7, vcc_lo                       // 000000287AF8: 02000F01
	.long 0xd72c0003                                           // 000000287AFC: D72C0003
	v_cndmask_b32_e32 v0, v0, v6, vcc_lo                       // 000000287B00: 02000D00
	v_mad_u64_u32 v[20:21], null, v1, s6, s[14:15]             // 000000287B04: D6FE7C14 00380D01
	.long 0xd4440002                                           // 000000287B0C: D4440002
	v_cndmask_b32_e32 v1, s26, v27, vcc_lo                     // 000000287B10: 0202361A
	v_dual_mov_b32 v0, 0 :: v_dual_mov_b32 v51, 0              // 000000287B14: CA100080 00320080
	v_dual_mov_b32 v52, 0 :: v_dual_mov_b32 v1, 0              // 000000287B1C: CA100080 34000080
	v_dual_mov_b32 v4, 0 :: v_dual_mov_b32 v7, 0               // 000000287B24: CA100080 04060080
	v_add3_u32 v19, v3, v19, v2                                // 000000287B2C: D6550013 040A2703
	v_add3_u32 v39, v3, v21, v2                                // 000000287B34: D6550027 040A2B03
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v5, 0               // 000000287B3C: CA100080 02040080
	v_dual_mov_b32 v3, 0 :: v_dual_mov_b32 v6, 0               // 000000287B44: CA100080 03060080
	s_and_saveexec_b32 s3, s2                                  // 000000287B4C: BE832002
	s_cbranch_execz 37                                         // 000000287B50: BFA50025 <_ZN7halogen12_GLOBAL__N_111k_lq4w_pairILi1ELi16ELi1EEEvPKhlllS3_lllPKtPtll+0x6e8>
	v_dual_mov_b32 v51, 0 :: v_dual_lshlrev_b32 v2, 4, v27     // 000000287B54: CA220080 33023684
	v_mov_b32_e32 v52, 0                                       // 000000287B5C: 7E680280
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000287B60: BF870092
	.long 0xd7006a00                                           // 000000287B64: D7006A00
	v_cndmask_b32_e32 v1, v18, v2, vcc_lo                      // 000000287B68: 02020512
	v_add_co_ci_u32_e64 v1, null, 0, v19, vcc_lo               // 000000287B6C: D5207C01 01AA2680
	.long 0xd7006a02                                           // 000000287B74: D7006A02
	v_cndmask_b32_e32 v1, v20, v2, vcc_lo                      // 000000287B78: 02020514
	s_delay_alu instid0(VALU_DEP_1)                            // 000000287B7C: BF870001
	v_add_co_ci_u32_e64 v3, null, 0, v39, vcc_lo               // 000000287B80: D5207C03 01AA4E80
	global_load_b128 v[4:7], v[0:1], off                       // 000000287B88: DC5E0000 047C0000
	global_load_b128 v[0:3], v[2:3], off                       // 000000287B90: DC5E0000 007C0002
	s_and_not1_b32 vcc_lo, exec_lo, s10                        // 000000287B98: 916A0A7E
	s_cbranch_vccnz 18                                         // 000000287B9C: BFA40012 <_ZN7halogen12_GLOBAL__N_111k_lq4w_pairILi1ELi16ELi1EEEvPKhlllS3_lllPKtPtll+0x6e8>
	v_lshlrev_b32_e32 v21, 1, v27                              // 000000287BA0: 302A3681
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000287BA4: BF870091
	.long 0xd7006a0e                                           // 000000287BA8: D7006A0E
	v_cndmask_b32_e32 v1, v14, v21, vcc_lo                     // 000000287BAC: 02022B0E
	v_add_co_ci_u32_e64 v15, null, 0, v15, vcc_lo              // 000000287BB0: D5207C0F 01AA1E80
	.long 0xd7006a15                                           // 000000287BB8: D7006A15
	v_cndmask_b32_e32 v1, v12, v21, vcc_lo                     // 000000287BBC: 02022B0C
	s_delay_alu instid0(VALU_DEP_1)                            // 000000287BC0: BF870001
	v_add_co_ci_u32_e64 v22, null, 0, v13, vcc_lo              // 000000287BC4: D5207C16 01AA1A80
	global_load_d16_b16 v12, v[14:15], off                     // 000000287BCC: DC820000 0C7C000E
	global_load_d16_hi_b16 v12, v[21:22], off                  // 000000287BD4: DC8E0000 0C7C0015
	s_waitcnt vmcnt(0)                                         // 000000287BDC: BF8903F7
	v_cvt_f32_f16_e32 v51, v12                                 // 000000287BE0: 7E66170C
	v_cvt_f32_f16_e32 v52, v140/*Invalid register, operand has 'VS_32_Lo128' register class*/// 000000287BE4: 7E68178C
	s_or_b32 exec_lo, exec_lo, s3                              // 000000287BE8: 8C7E037E
	v_mov_b32_e32 v44, 0                                       // 000000287BEC: 7E580280
	s_and_saveexec_b32 s3, s2                                  // 000000287BF0: BE832002
	s_cbranch_execz 429                                        // 000000287BF4: BFA501AD <_ZN7halogen12_GLOBAL__N_111k_lq4w_pairILi1ELi16ELi1EEEvPKhlllS3_lllPKtPtll+0xdac>
	.long 0xd7006a0a                                           // 000000287BF8: D7006A0A
	v_cndmask_b32_e32 v1, s8, v10, vcc_lo                      // 000000287BFC: 02021408
	v_dual_mov_b32 v45, v27 :: v_dual_lshlrev_b32 v12, 1, v27  // 000000287C00: CA22011B 2D0C3681
	v_add_co_ci_u32_e64 v11, null, s9, v11, vcc_lo             // 000000287C08: D5207C0B 01AA1609
	.long 0xd7006a08                                           // 000000287C10: D7006A08
	v_cndmask_b32_e32 v1, s16, v8, vcc_lo                      // 000000287C14: 02021010
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000287C18: BF870211
	v_add_co_ci_u32_e64 v9, null, s17, v9, vcc_lo              // 000000287C1C: D5207C09 01AA1211
	.long 0xd7006a0a                                           // 000000287C24: D7006A0A
	v_cndmask_b32_e32 v1, v10, v12, vcc_lo                     // 000000287C28: 0202190A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000287C2C: BF870211
	v_add_co_ci_u32_e64 v11, null, 0, v11, vcc_lo              // 000000287C30: D5207C0B 01AA1680
	.long 0xd7006a08                                           // 000000287C38: D7006A08
	v_cndmask_b32_e32 v1, v8, v12, vcc_lo                      // 000000287C3C: 02021908
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000287C40: BF870211
	v_add_co_ci_u32_e64 v9, null, 0, v9, vcc_lo                // 000000287C44: D5207C09 01AA1280
	.long 0xd7006a0a                                           // 000000287C4C: D7006A0A
	v_cndmask_b32_e32 v1, s4, v10, vcc_lo                      // 000000287C50: 02021404
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000287C54: BF870211
	v_add_co_ci_u32_e64 v11, null, s5, v11, vcc_lo             // 000000287C58: D5207C0B 01AA1605
	.long 0xd7006a08                                           // 000000287C60: D7006A08
	v_cndmask_b32_e32 v1, s12, v8, vcc_lo                      // 000000287C64: 0202100C
	v_dual_mov_b32 v22, 0 :: v_dual_lshlrev_b32 v21, 5, v27    // 000000287C68: CA220080 16143685
	v_add_co_ci_u32_e64 v9, null, s13, v9, vcc_lo              // 000000287C70: D5207C09 01AA120D
	.long 0xd7006a17                                           // 000000287C78: D7006A17
	v_cndmask_b32_e32 v0, v10, v160, vcc_lo                    // 000000287C7C: 0201410A
	s_delay_alu instid0(VALU_DEP_1)                            // 000000287C80: BF870001
	v_add_co_ci_u32_e64 v24, null, 0, v11, vcc_lo              // 000000287C84: D5207C18 01AA1680
	.long 0xd7006a19                                           // 000000287C8C: D7006A19
	v_cndmask_b32_e32 v0, v8, v160, vcc_lo                     // 000000287C90: 02014108
	v_lshl_or_b32 v42, v27, 4, 0x100                           // 000000287C94: D656002A 03FD091B 00000100
	v_add_co_ci_u32_e64 v26, null, 0, v9, vcc_lo               // 000000287CA0: D5207C1A 01AA1280
	v_mov_b32_e32 v40, v22                                     // 000000287CA8: 7E500316
	v_mov_b32_e32 v44, v22                                     // 000000287CAC: 7E580316
	s_mov_b32 s4, 0                                            // 000000287CB0: BE840080
	s_branch 311                                               // 000000287CB4: BFA00137 <_ZN7halogen12_GLOBAL__N_111k_lq4w_pairILi1ELi16ELi1EEEvPKhlllS3_lllPKtPtll+0xc94>
	s_or_b32 exec_lo, exec_lo, s5                              // 000000287CB8: 8C7E057E
	.long 0xd73c002e                                           // 000000287CBC: D73C002E
	v_cndmask_b32_e32 v1, 1, v21, vcc_lo                       // 000000287CC0: 02022A81
	v_cndmask_b32_e64 v78, v52, v32, s1                        // 000000287CC4: D501004E 00064134
	v_and_b32_e32 v32, 0xff, v4                                // 000000287CCC: 364008FF 000000FF
	v_and_b32_e32 v41, 0xff, v0                                // 000000287CD4: 365200FF 000000FF
	v_lshrrev_b32_e32 v43, 6, v4                               // 000000287CDC: 32560886
	v_lshrrev_b32_e32 v48, 14, v4                              // 000000287CE0: 3260088E
	.long 0xd7006a2e                                           // 000000287CE4: D7006A2E
	v_cndmask_b32_e32 v1, s20, v46, vcc_lo                     // 000000287CE8: 02025C14
	s_delay_alu instid0(VALU_DEP_1)                            // 000000287CEC: BF870001
	v_add_co_ci_u32_e64 v47, null, s21, v47, vcc_lo            // 000000287CF0: D5207C2F 01AA5E15
	v_lshlrev_b32_e32 v41, 2, v41                              // 000000287CF8: 30525282
	v_and_b32_e32 v43, 0x3fc, v43                              // 000000287CFC: 365656FF 000003FC
	v_lshrrev_b32_e32 v49, 14, v0                              // 000000287D04: 3262008E
	s_clause 0x3                                               // 000000287D08: BF850003
	global_load_b128 v[62:65], v[46:47], off                   // 000000287D0C: DC5E0000 3E7C002E
	global_load_b128 v[66:69], v[46:47], off offset:16         // 000000287D14: DC5E0010 427C002E
	global_load_b128 v[70:73], v[46:47], off offset:32         // 000000287D1C: DC5E0020 467C002E
	global_load_b128 v[74:77], v[46:47], off offset:48         // 000000287D24: DC5E0030 4A7C002E
	v_dual_mov_b32 v47, v61 :: v_dual_lshlrev_b32 v32, 2, v32  // 000000287D2C: CA22013D 2F204082
	v_lshrrev_b32_e32 v46, 6, v0                               // 000000287D34: 325C0086
	v_lshrrev_b32_e32 v4, 22, v4                               // 000000287D38: 32080896
	ds_load_b32 v32, v32                                       // 000000287D3C: D8D80000 20000020
	ds_load_b32 v41, v41 offset:1024                           // 000000287D44: D8D80400 29000029
	v_and_b32_e32 v46, 0x3fc, v46                              // 000000287D4C: 365C5CFF 000003FC
	v_and_b32_e32 v48, 0x3fc, v48                              // 000000287D54: 366060FF 000003FC
	ds_load_b32 v43, v43                                       // 000000287D5C: D8D80000 2B00002B
	ds_load_b32 v46, v46 offset:1024                           // 000000287D64: D8D80400 2E00002E
	v_lshrrev_b32_e32 v0, 22, v0                               // 000000287D6C: 32000096
	v_and_b32_e32 v49, 0x3fc, v49                              // 000000287D70: 366262FF 000003FC
	v_cndmask_b32_e64 v34, v51, v34, s1                        // 000000287D78: D5010022 00064533
	v_and_b32_e32 v51, 0xff, v5                                // 000000287D80: 36660AFF 000000FF
	v_and_b32_e32 v4, 0x3fc, v4                                // 000000287D88: 360808FF 000003FC
	ds_load_b32 v48, v48                                       // 000000287D90: D8D80000 30000030
	ds_load_b32 v49, v49 offset:1024                           // 000000287D98: D8D80400 31000031
	v_and_b32_e32 v52, 0xff, v1                                // 000000287DA0: 366802FF 000000FF
	v_and_b32_e32 v0, 0x3fc, v0                                // 000000287DA8: 360000FF 000003FC
	v_lshrrev_b32_e32 v79, 6, v5                               // 000000287DB0: 329E0A86
	v_lshlrev_b32_e32 v51, 2, v51                              // 000000287DB4: 30666682
	ds_load_b32 v4, v4                                         // 000000287DB8: D8D80000 04000004
	ds_load_b32 v0, v0 offset:1024                             // 000000287DC0: D8D80400 00000000
	v_lshrrev_b32_e32 v80, 6, v1                               // 000000287DC8: 32A00286
	v_lshlrev_b32_e32 v52, 2, v52                              // 000000287DCC: 30686882
	v_lshrrev_b32_e32 v81, 14, v5                              // 000000287DD0: 32A20A8E
	v_and_b32_e32 v61, 0x3fc, v79                              // 000000287DD4: 367A9EFF 000003FC
	ds_load_b32 v51, v51                                       // 000000287DDC: D8D80000 33000033
	ds_load_b32 v52, v52 offset:1024                           // 000000287DE4: D8D80400 34000034
	v_lshrrev_b32_e32 v82, 14, v1                              // 000000287DEC: 32A4028E
	v_and_b32_e32 v79, 0x3fc, v80                              // 000000287DF0: 369EA0FF 000003FC
	v_lshrrev_b32_e32 v5, 22, v5                               // 000000287DF8: 320A0A96
	v_and_b32_e32 v80, 0x3fc, v81                              // 000000287DFC: 36A0A2FF 000003FC
	v_lshrrev_b32_e32 v1, 22, v1                               // 000000287E04: 32020296
	v_and_b32_e32 v81, 0x3fc, v82                              // 000000287E08: 36A2A4FF 000003FC
	v_and_b32_e32 v83, 0xff, v6                                // 000000287E10: 36A60CFF 000000FF
	v_and_b32_e32 v5, 0x3fc, v5                                // 000000287E18: 360A0AFF 000003FC
	v_and_b32_e32 v84, 0xff, v2                                // 000000287E20: 36A804FF 000000FF
	v_and_b32_e32 v1, 0x3fc, v1                                // 000000287E28: 360202FF 000003FC
	v_lshrrev_b32_e32 v85, 6, v6                               // 000000287E30: 32AA0C86
	v_lshlrev_b32_e32 v82, 2, v83                              // 000000287E34: 30A4A682
	ds_load_b32 v5, v5                                         // 000000287E38: D8D80000 05000005
	ds_load_b32 v1, v1 offset:1024                             // 000000287E40: D8D80400 01000001
	v_lshrrev_b32_e32 v86, 6, v2                               // 000000287E48: 32AC0486
	v_lshlrev_b32_e32 v83, 2, v84                              // 000000287E4C: 30A6A882
	v_lshrrev_b32_e32 v87, 14, v6                              // 000000287E50: 32AE0C8E
	v_and_b32_e32 v84, 0x3fc, v85                              // 000000287E54: 36A8AAFF 000003FC
	v_lshrrev_b32_e32 v88, 14, v2                              // 000000287E5C: 32B0048E
	v_and_b32_e32 v85, 0x3fc, v86                              // 000000287E60: 36AAACFF 000003FC
	v_lshrrev_b32_e32 v6, 22, v6                               // 000000287E68: 320C0C96
	v_and_b32_e32 v86, 0x3fc, v87                              // 000000287E6C: 36ACAEFF 000003FC
	v_lshrrev_b32_e32 v2, 22, v2                               // 000000287E74: 32040496
	v_and_b32_e32 v87, 0x3fc, v88                              // 000000287E78: 36AEB0FF 000003FC
	v_and_b32_e32 v89, 0xff, v7                                // 000000287E80: 36B20EFF 000000FF
	v_and_b32_e32 v6, 0x3fc, v6                                // 000000287E88: 360C0CFF 000003FC
	v_lshrrev_b32_e32 v91, 6, v7                               // 000000287E90: 32B60E86
	v_and_b32_e32 v2, 0x3fc, v2                                // 000000287E94: 360404FF 000003FC
	ds_load_b32 v6, v6                                         // 000000287E9C: D8D80000 06000006
	ds_load_b32 v2, v2 offset:1024                             // 000000287EA4: D8D80400 02000002
	v_lshrrev_b32_e32 v93, 14, v7                              // 000000287EAC: 32BA0E8E
	v_lshrrev_b32_e32 v7, 22, v7                               // 000000287EB0: 320E0E96
	v_and_b32_e32 v90, 0xff, v3                                // 000000287EB4: 36B406FF 000000FF
	v_lshrrev_b32_e32 v92, 6, v3                               // 000000287EBC: 32B80686
	v_lshrrev_b32_e32 v94, 14, v3                              // 000000287EC0: 32BC068E
	v_lshrrev_b32_e32 v3, 22, v3                               // 000000287EC4: 32060696
	v_and_b32_e32 v7, 0x3fc, v7                                // 000000287EC8: 360E0EFF 000003FC
	v_add_nc_u32_e32 v21, 0x200, v21                           // 000000287ED0: 4A2A2AFF 00000200
	.long 0xd7006a17                                           // 000000287ED8: D7006A17
	v_cndmask_b32_e32 v0, v23, v160, vcc_lo                    // 000000287EDC: 02014117
	s_delay_alu instid0(VALU_DEP_4)                            // 000000287EE0: BF870004
	v_and_b32_e32 v3, 0x3fc, v3                                // 000000287EE4: 360606FF 000003FC
	v_add_co_ci_u32_e64 v24, null, 0, v24, vcc_lo              // 000000287EEC: D5207C18 01AA3080
	.long 0xd7006a19                                           // 000000287EF4: D7006A19
	v_cndmask_b32_e32 v0, v25, v160, vcc_lo                    // 000000287EF8: 02014119
	v_add_nc_u32_e32 v42, 0x100, v42                           // 000000287EFC: 4A5454FF 00000100
	v_add_co_ci_u32_e64 v26, null, 0, v26, vcc_lo              // 000000287F04: D5207C1A 01AA3480
	s_and_b32 s2, exec_lo, s2                                  // 000000287F0C: 8B02027E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000287F10: BF870009
	s_or_b32 s4, s2, s4                                        // 000000287F14: 8C040402
	s_waitcnt vmcnt(3) lgkmcnt(13)                             // 000000287F18: BF890CD7
	v_dot2_f32_bf16 v32, v62, v32, 0                           // 000000287F1C: CC1A4020 1A02413E
	s_waitcnt lgkmcnt(12)                                      // 000000287F24: BF89FCC7
	v_dot2_f32_bf16 v41, v62, v41, 0                           // 000000287F28: CC1A4029 1A02533E
	ds_load_b32 v61, v61                                       // 000000287F30: D8D80000 3D00003D
	ds_load_b32 v62, v79 offset:1024                           // 000000287F38: D8D80400 3E00004F
	s_waitcnt lgkmcnt(13)                                      // 000000287F40: BF89FCD7
	v_dot2_f32_bf16 v32, v63, v43, v32                         // 000000287F44: CC1A4020 1C82573F
	s_waitcnt lgkmcnt(12)                                      // 000000287F4C: BF89FCC7
	v_dot2_f32_bf16 v41, v63, v46, v41                         // 000000287F50: CC1A4029 1CA65D3F
	ds_load_b32 v43, v80                                       // 000000287F58: D8D80000 2B000050
	ds_load_b32 v46, v81 offset:1024                           // 000000287F60: D8D80400 2E000051
	s_waitcnt lgkmcnt(13)                                      // 000000287F68: BF89FCD7
	v_dot2_f32_bf16 v32, v64, v48, v32                         // 000000287F6C: CC1A4020 1C826140
	s_waitcnt lgkmcnt(12)                                      // 000000287F74: BF89FCC7
	v_dot2_f32_bf16 v41, v64, v49, v41                         // 000000287F78: CC1A4029 1CA66340
	s_waitcnt lgkmcnt(11)                                      // 000000287F80: BF89FCB7
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000287F84: BF870122
	v_dot2_f32_bf16 v4, v65, v4, v32                           // 000000287F88: CC1A4004 1C820941
	s_waitcnt lgkmcnt(10)                                      // 000000287F90: BF89FCA7
	v_dot2_f32_bf16 v0, v65, v0, v41                           // 000000287F94: CC1A4000 1CA60141
	ds_load_b32 v41, v82                                       // 000000287F9C: D8D80000 29000052
	ds_load_b32 v49, v83 offset:1024                           // 000000287FA4: D8D80400 31000053
	s_waitcnt vmcnt(2) lgkmcnt(11)                             // 000000287FAC: BF8908B7
	v_dot2_f32_bf16 v4, v66, v51, v4                           // 000000287FB0: CC1A4004 1C126742
	s_waitcnt lgkmcnt(10)                                      // 000000287FB8: BF89FCA7
	v_dot2_f32_bf16 v0, v66, v52, v0                           // 000000287FBC: CC1A4000 1C026942
	ds_load_b32 v52, v84                                       // 000000287FC4: D8D80000 34000054
	ds_load_b32 v63, v85 offset:1024                           // 000000287FCC: D8D80400 3F000055
	v_and_b32_e32 v51, 0x3fc, v91                              // 000000287FD4: 3666B6FF 000003FC
	s_waitcnt lgkmcnt(7)                                       // 000000287FDC: BF89FC77
	v_dot2_f32_bf16 v4, v67, v61, v4                           // 000000287FE0: CC1A4004 1C127B43
	s_waitcnt lgkmcnt(6)                                       // 000000287FE8: BF89FC67
	v_dot2_f32_bf16 v0, v67, v62, v0                           // 000000287FEC: CC1A4000 1C027D43
	ds_load_b32 v62, v86                                       // 000000287FF4: D8D80000 3E000056
	ds_load_b32 v64, v87 offset:1024                           // 000000287FFC: D8D80400 40000057
	v_and_b32_e32 v61, 0x3fc, v92                              // 000000288004: 367AB8FF 000003FC
	ds_load_b32 v51, v51                                       // 00000028800C: D8D80000 33000033
	ds_load_b32 v61, v61 offset:1024                           // 000000288014: D8D80400 3D00003D
	s_waitcnt lgkmcnt(9)                                       // 00000028801C: BF89FC97
	v_dot2_f32_bf16 v4, v68, v43, v4                           // 000000288020: CC1A4004 1C125744
	s_waitcnt lgkmcnt(8)                                       // 000000288028: BF89FC87
	v_dot2_f32_bf16 v0, v68, v46, v0                           // 00000028802C: CC1A4000 1C025D44
	v_dual_mov_b32 v46, v54 :: v_dual_and_b32 v43, 0x3fc, v93  // 000000288034: CA240136 2E2ABAFF 000003FC
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000288040: BF870193
	v_dot2_f32_bf16 v4, v69, v5, v4                            // 000000288044: CC1A4004 1C120B45
	v_dot2_f32_bf16 v0, v69, v1, v0                            // 00000028804C: CC1A4000 1C020345
	v_and_b32_e32 v1, 0x3fc, v94                               // 000000288054: 3602BCFF 000003FC
	s_waitcnt vmcnt(1) lgkmcnt(7)                              // 00000028805C: BF890477
	s_delay_alu instid0(VALU_DEP_3)                            // 000000288060: BF870003
	v_dot2_f32_bf16 v4, v70, v41, v4                           // 000000288064: CC1A4004 1C125346
	s_waitcnt lgkmcnt(6)                                       // 00000028806C: BF89FC67
	v_dot2_f32_bf16 v0, v70, v49, v0                           // 000000288070: CC1A4000 1C026346
	v_mov_b32_e32 v49, v58                                     // 000000288078: 7E62033A
	v_dual_mov_b32 v41, v55 :: v_dual_lshlrev_b32 v32, 2, v90  // 00000028807C: CA220137 2920B482
	s_waitcnt lgkmcnt(5)                                       // 000000288084: BF89FC57
	v_dot2_f32_bf16 v4, v71, v52, v4                           // 000000288088: CC1A4004 1C126947
	s_waitcnt lgkmcnt(4)                                       // 000000288090: BF89FC47
	v_dot2_f32_bf16 v0, v71, v63, v0                           // 000000288094: CC1A4000 1C027F47
	ds_load_b32 v52, v43                                       // 00000028809C: D8D80000 3400002B
	ds_load_b32 v1, v1 offset:1024                             // 0000002880A4: D8D80400 01000001
	v_mov_b32_e32 v43, v56                                     // 0000002880AC: 7E560338
	s_waitcnt lgkmcnt(5)                                       // 0000002880B0: BF89FC57
	v_dot2_f32_bf16 v4, v72, v62, v4                           // 0000002880B4: CC1A4004 1C127D48
	ds_load_b32 v58, v7                                        // 0000002880BC: D8D80000 3A000007
	ds_load_b32 v62, v3 offset:1024                            // 0000002880C4: D8D80400 3E000003
	s_waitcnt lgkmcnt(6)                                       // 0000002880CC: BF89FC67
	v_dot2_f32_bf16 v0, v72, v64, v0                           // 0000002880D0: CC1A4000 1C028148
	v_mov_b32_e32 v7, v15                                      // 0000002880D8: 7E0E030F
	v_dot2_f32_bf16 v3, v73, v6, v4                            // 0000002880DC: CC1A4003 1C120D49
	v_mov_b32_e32 v6, v14                                      // 0000002880E4: 7E0C030E
	v_lshlrev_b32_e32 v48, 2, v89                              // 0000002880E8: 3060B282
	ds_load_b32 v5, v48                                        // 0000002880EC: D8D80000 05000030
	ds_load_b32 v32, v32 offset:1024                           // 0000002880F4: D8D80400 20000020
	v_dot2_f32_bf16 v0, v73, v2, v0                            // 0000002880FC: CC1A4000 1C020549
	v_mov_b32_e32 v4, v12                                      // 000000288104: 7E08030C
	v_mov_b32_e32 v48, v53                                     // 000000288108: 7E600335
	s_waitcnt vmcnt(0) lgkmcnt(1)                              // 00000028810C: BF890017
	v_dot2_f32_bf16 v2, v74, v5, v3                            // 000000288110: CC1A4002 1C0E0B4A
	s_waitcnt lgkmcnt(0)                                       // 000000288118: BF89FC07
	v_dot2_f32_bf16 v0, v74, v32, v0                           // 00000028811C: CC1A4000 1C02414A
	v_mov_b32_e32 v32, v57                                     // 000000288124: 7E400339
	v_mov_b32_e32 v5, v13                                      // 000000288128: 7E0A030D
	v_mov_b32_e32 v3, v11                                      // 00000028812C: 7E06030B
	v_dot2_f32_bf16 v2, v75, v51, v2                           // 000000288130: CC1A4002 1C0A674B
	v_dot2_f32_bf16 v0, v75, v61, v0                           // 000000288138: CC1A4000 1C027B4B
	v_mov_b32_e32 v51, v60                                     // 000000288140: 7E66033C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000288144: BF870193
	v_dot2_f32_bf16 v12, v76, v52, v2                          // 000000288148: CC1A400C 1C0A694C
	v_dot2_f32_bf16 v0, v76, v1, v0                            // 000000288150: CC1A4000 1C02034C
	v_dual_mov_b32 v2, v10 :: v_dual_mov_b32 v1, v9            // 000000288158: CA10010A 02000109
	v_mov_b32_e32 v52, v59                                     // 000000288160: 7E68033B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000288164: BF870214
	v_dot2_f32_bf16 v9, v77, v58, v12                          // 000000288168: CC1A4009 1C32754D
	v_dot2_f32_bf16 v10, v77, v62, v0                          // 000000288170: CC1A400A 1C027D4D
	v_mov_b32_e32 v0, v8                                       // 000000288178: 7E000308
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000028817C: BF870193
	v_fmac_f32_e32 v44, v34, v9                                // 000000288180: 56581322
	v_fmac_f32_e32 v40, v78, v10                               // 000000288184: 5650154E
	v_mov_b32_e32 v34, v50                                     // 000000288188: 7E440332
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 00000028818C: 917E047E
	s_cbranch_execz 69                                         // 000000288190: BFA50045 <_ZN7halogen12_GLOBAL__N_111k_lq4w_pairILi1ELi16ELi1EEEvPKhlllS3_lllPKtPtll+0xda8>
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 000000288194: 916A017E
	s_cbranch_vccnz 15                                         // 000000288198: BFA4000F <_ZN7halogen12_GLOBAL__N_111k_lq4w_pairILi1ELi16ELi1EEEvPKhlllS3_lllPKtPtll+0xcd8>
	v_dual_mov_b32 v61, v37 :: v_dual_mov_b32 v58, v47         // 00000028819C: CA100125 3D3A012F
	v_dual_mov_b32 v53, v49 :: v_dual_mov_b32 v54, v48         // 0000002881A4: CA100131 35360130
	v_dual_mov_b32 v56, v46 :: v_dual_mov_b32 v55, v43         // 0000002881AC: CA10012E 3836012B
	v_dual_mov_b32 v57, v41 :: v_dual_mov_b32 v50, v28         // 0000002881B4: CA100129 3932011C
	v_dual_mov_b32 v28, v29 :: v_dual_mov_b32 v29, v30         // 0000002881BC: CA10011D 1C1C011E
	v_dual_mov_b32 v30, v31 :: v_dual_mov_b32 v31, v33         // 0000002881C4: CA10011F 1E1E0121
	v_mov_b32_e32 v33, v35                                     // 0000002881CC: 7E420323
	v_mov_b32_e32 v35, v36                                     // 0000002881D0: 7E460324
	s_branch 8                                                 // 0000002881D4: BFA00008 <_ZN7halogen12_GLOBAL__N_111k_lq4w_pairILi1ELi16ELi1EEEvPKhlllS3_lllPKtPtll+0xcf8>
	v_dual_mov_b32 v61, v47 :: v_dual_mov_b32 v58, v49         // 0000002881D8: CA10012F 3D3A0131
	v_dual_mov_b32 v53, v48 :: v_dual_mov_b32 v54, v46         // 0000002881E0: CA100130 3536012E
	v_dual_mov_b32 v56, v43 :: v_dual_mov_b32 v55, v41         // 0000002881E8: CA10012B 38360129
	v_dual_mov_b32 v57, v32 :: v_dual_mov_b32 v50, v34         // 0000002881F0: CA100120 39320122
	v_dual_mov_b32 v60, v51 :: v_dual_add_nc_u32 v45, 16, v45  // 0000002881F8: CA200133 3C2C5A90
	s_waitcnt vmcnt(0)                                         // 000000288200: BF8903F7
	v_dual_mov_b32 v59, v52 :: v_dual_mov_b32 v10, v2          // 000000288204: CA100134 3B0A0102
	v_dual_mov_b32 v8, v0 :: v_dual_mov_b32 v9, v1             // 00000028820C: CA100100 08080101
	s_delay_alu instid0(VALU_DEP_3)                            // 000000288214: BF870003
	.long 0xd4430002                                           // 000000288218: D4430002
	v_cndmask_b32_e32 v1, s26, v45, vcc_lo                     // 00000028821C: 02025A1A
	v_dual_mov_b32 v11, v3 :: v_dual_mov_b32 v12, v4           // 000000288220: CA100103 0B0C0104
	v_dual_mov_b32 v13, v5 :: v_dual_mov_b32 v14, v6           // 000000288228: CA100105 0D0E0106
	v_mov_b32_e32 v15, v7                                      // 000000288230: 7E1E0307
	s_mov_b32 s5, exec_lo                                      // 000000288234: BE85007E
	.long 0xd4c4007e                                           // 000000288238: D4C4007E
	v_cndmask_b32_e32 v1, s26, v45, vcc_lo                     // 00000028823C: 02025A1A
	s_cbranch_execz 65181                                      // 000000288240: BFA5FE9D <_ZN7halogen12_GLOBAL__N_111k_lq4w_pairILi1ELi16ELi1EEEvPKhlllS3_lllPKtPtll+0x7b8>
	.long 0xd7006a08                                           // 000000288244: D7006A08
	v_cndmask_b32_e32 v1, v18, v42, vcc_lo                     // 000000288248: 02025512
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000028824C: BF8700A1
	v_add_co_ci_u32_e64 v9, null, 0, v19, vcc_lo               // 000000288250: D5207C09 01AA2680
	.long 0xd7006a0a                                           // 000000288258: D7006A0A
	v_cndmask_b32_e32 v1, v20, v42, vcc_lo                     // 00000028825C: 02025514
	v_add_co_ci_u32_e64 v11, null, 0, v39, vcc_lo              // 000000288260: D5207C0B 01AA4E80
	global_load_b128 v[12:15], v[8:9], off                     // 000000288268: DC5E0000 0C7C0008
	global_load_b128 v[8:11], v[10:11], off                    // 000000288270: DC5E0000 087C000A
	v_cmp_ne_u32_e32 vcc_lo, 1, v38                            // 000000288278: 7C9A4C81
	v_dual_mov_b32 v60, v51 :: v_dual_mov_b32 v59, v52         // 00000028827C: CA100133 3C3A0134
	s_cbranch_vccnz 65164                                      // 000000288284: BFA4FE8C <_ZN7halogen12_GLOBAL__N_111k_lq4w_pairILi1ELi16ELi1EEEvPKhlllS3_lllPKtPtll+0x7b8>
	global_load_d16_b16 v41, v[23:24], off                     // 000000288288: DC820000 297C0017
	global_load_d16_hi_b16 v41, v[25:26], off                  // 000000288290: DC8E0000 297C0019
	s_waitcnt vmcnt(0)                                         // 000000288298: BF8903F7
	v_cvt_f32_f16_e32 v60, v41                                 // 00000028829C: 7E781729
	v_cvt_f32_f16_e32 v59, v169/*Invalid register, operand has 'VS_32_Lo128' register class*/// 0000002882A0: 7E7617A9
	s_branch 65156                                             // 0000002882A4: BFA0FE84 <_ZN7halogen12_GLOBAL__N_111k_lq4w_pairILi1ELi16ELi1EEEvPKhlllS3_lllPKtPtll+0x7b8>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000002882A8: 8C7E047E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000002882AC: BF8700B9
	s_or_b32 exec_lo, exec_lo, s3                              // 0000002882B0: 8C7E037E
	s_waitcnt vmcnt(0)                                         // 0000002882B4: BF8903F7
	.long 0xd71f0000                                           // 0000002882B8: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000002882BC: 020100C1
	v_xor_b32_e32 v1, 8, v0                                    // 0000002882C0: 3A020088
	v_xor_b32_e32 v3, 4, v0                                    // 0000002882C4: 3A060084
	v_xor_b32_e32 v5, 2, v0                                    // 0000002882C8: 3A0A0082
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000002882CC: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v1                            // 0000002882D0: 7C9802A0
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 0000002882D4: 02020300
	v_cmp_gt_u32_e32 vcc_lo, 32, v3                            // 0000002882D8: 7C9806A0
	s_delay_alu instid0(VALU_DEP_2)                            // 0000002882DC: BF870002
	v_lshlrev_b32_e32 v1, 2, v1                                // 0000002882E0: 30020282
	v_cndmask_b32_e32 v3, v0, v3, vcc_lo                       // 0000002882E4: 02060700
	v_cmp_gt_u32_e32 vcc_lo, 32, v5                            // 0000002882E8: 7C980AA0
	ds_bpermute_b32 v2, v1, v44                                // 0000002882EC: DACC0000 02002C01
	v_lshlrev_b32_e32 v3, 2, v3                                // 0000002882F4: 30060682
	v_cndmask_b32_e32 v5, v0, v5, vcc_lo                       // 0000002882F8: 020A0B00
	s_waitcnt lgkmcnt(0)                                       // 0000002882FC: BF89FC07
	s_delay_alu instid0(VALU_DEP_1)                            // 000000288300: BF870001
	v_dual_add_f32 v2, v44, v2 :: v_dual_lshlrev_b32 v5, 2, v5 // 000000288304: C922052C 02040A82
	ds_bpermute_b32 v1, v1, v40                                // 00000028830C: DACC0000 01002801
	ds_bpermute_b32 v4, v3, v2                                 // 000000288314: DACC0000 04000203
	s_waitcnt lgkmcnt(0)                                       // 00000028831C: BF89FC07
	v_dual_add_f32 v2, v2, v4 :: v_dual_add_f32 v1, v40, v1    // 000000288320: C9080902 02000328
	ds_bpermute_b32 v3, v3, v1                                 // 000000288328: DACC0000 03000103
	s_waitcnt lgkmcnt(0)                                       // 000000288330: BF89FC07
	v_add_f32_e32 v1, v1, v3                                   // 000000288334: 06020701
	ds_bpermute_b32 v3, v5, v2                                 // 000000288338: DACC0000 03000205
	ds_bpermute_b32 v4, v5, v1                                 // 000000288340: DACC0000 04000105
	v_xor_b32_e32 v5, 1, v0                                    // 000000288348: 3A0A0081
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 00000028834C: BF870141
	v_cmp_gt_u32_e32 vcc_lo, 32, v5                            // 000000288350: 7C980AA0
	v_cndmask_b32_e32 v0, v0, v5, vcc_lo                       // 000000288354: 02000B00
	v_cmp_eq_u32_e32 vcc_lo, 0, v27                            // 000000288358: 7C943680
	s_waitcnt lgkmcnt(1)                                       // 00000028835C: BF89FC17
	v_dual_add_f32 v2, v2, v3 :: v_dual_lshlrev_b32 v5, 2, v0  // 000000288360: C9220702 02040082
	s_and_b32 s0, vcc_lo, s0                                   // 000000288368: 8B00006A
	s_waitcnt lgkmcnt(0)                                       // 00000028836C: BF89FC07
	v_add_f32_e32 v0, v1, v4                                   // 000000288370: 06000901
	ds_bpermute_b32 v3, v5, v2                                 // 000000288374: DACC0000 03000205
	ds_bpermute_b32 v1, v5, v0                                 // 00000028837C: DACC0000 01000005
	s_and_saveexec_b32 s1, s0                                  // 000000288384: BE812000
	s_cbranch_execz 66                                         // 000000288388: BFA50042 <_ZN7halogen12_GLOBAL__N_111k_lq4w_pairILi1ELi16ELi1EEEvPKhlllS3_lllPKtPtll+0xf94>
	s_waitcnt lgkmcnt(1)                                       // 00000028838C: BF89FC17
	v_add_f32_e32 v2, v2, v3                                   // 000000288390: 06040702
	s_waitcnt lgkmcnt(0)                                       // 000000288394: BF89FC07
	v_add_f32_e32 v0, v0, v1                                   // 000000288398: 06000300
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000028839C: BF870112
	v_bfe_u32 v3, v2, 16, 1                                    // 0000002883A0: D6100003 02052102
	v_bfe_u32 v1, v0, 16, 1                                    // 0000002883A8: D6100001 02052100
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002883B0: BF870112
	v_add3_u32 v2, v2, v3, 0x7fff                              // 0000002883B4: D6550002 03FE0702 00007FFF
	v_add3_u32 v0, v0, v1, 0x7fff                              // 0000002883C0: D6550000 03FE0300 00007FFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002883CC: BF870112
	v_and_b32_e32 v2, 0xffff0000, v2                           // 0000002883D0: 360404FF FFFF0000
	v_and_b32_e32 v0, 0xffff0000, v0                           // 0000002883D8: 360000FF FFFF0000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002883E0: BF870092
	v_mul_f32_e32 v3, 0xbfb8aa3b, v2                           // 0000002883E4: 100604FF BFB8AA3B
	v_exp_f32_e32 v3, v3                                       // 0000002883EC: 7E064B03
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002883F0: BF870095
	v_add_f32_e32 v3, 1.0, v3                                  // 0000002883F4: 060606F2
	v_div_scale_f32 v4, null, v3, v3, v2                       // 0000002883F8: D6FC7C04 040A0703
	v_div_scale_f32 v7, vcc_lo, v2, v3, v2                     // 000000288400: D6FC6A07 040A0702
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000288408: BF870292
	v_rcp_f32_e32 v5, v4                                       // 00000028840C: 7E0A5504
	v_fma_f32 v6, -v4, v5, 1.0                                 // 000000288410: D6130006 23CA0B04
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000288418: BF870091
	v_fmac_f32_e32 v5, v6, v5                                  // 00000028841C: 560A0B06
	v_mul_f32_e32 v6, v7, v5                                   // 000000288420: 100C0B07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000288424: BF870091
	v_fma_f32 v8, -v4, v6, v7                                  // 000000288428: D6130008 241E0D04
	v_fmac_f32_e32 v6, v8, v5                                  // 000000288430: 560C0B08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000288434: BF870091
	v_fma_f32 v4, -v4, v6, v7                                  // 000000288438: D6130004 241E0D04
	v_div_fmas_f32 v1, v4, v5, v6                              // 000000288440: D6370001 041A0B04
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000288448: BF870091
	v_div_fixup_f32 v1, v1, v3, v2                             // 00000028844C: D6270001 040A0701
	v_mul_f32_e32 v2, v1, v0                                   // 000000288454: 10040101
	.long 0xd73c0000                                           // 000000288458: D73C0000
	v_cndmask_b32_e32 v1, 1, v16, vcc_lo                       // 00000028845C: 02022081
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000288460: BF870112
	v_bfe_u32 v3, v2, 16, 1                                    // 000000288464: D6100003 02052102
	.long 0xd7006a00                                           // 00000028846C: D7006A00
	v_cndmask_b32_e32 v1, s22, v0, vcc_lo                      // 000000288470: 02020016
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000288474: BF870191
	v_add_co_ci_u32_e64 v1, null, s23, v1, vcc_lo              // 000000288478: D5207C01 01AA0217
	v_add3_u32 v2, v2, v3, 0x7fff                              // 000000288480: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off                    // 00000028848C: DC960000 007C0200
	s_endpgm                                                   // 000000288494: BFB00000
		...

