00000000005a1000 <_ZN7halogen12_GLOBAL__N_16k_lq6kILi5ELi16ELi1ELb0EEEvPKhPKtPvll>:
; _ZN7halogen12_GLOBAL__N_16k_lq6kILi5ELi16ELi1ELb0EEEvPKhPKtPvll():
	s_clause 0x1                                               // 0000005A1000: BF850001
	s_load_b256 s[4:11], s[0:1], null                          // 0000005A1004: F40C0100 F8000000
	s_load_b64 s[12:13], s[0:1], 0x20                          // 0000005A100C: F4040300 F8000020
	s_mov_b32 s3, 0                                            // 0000005A1014: BE830080
	v_lshrrev_b32_e32 v1, 4, v0                                // 0000005A1018: 32020084
	s_lshl_b64 s[0:1], s[2:3], 4                               // 0000005A101C: 84808402
	v_dual_mov_b32 v8, 0 :: v_dual_mov_b32 v9, 0               // 0000005A1020: CA100080 08080080
	v_dual_mov_b32 v2, s1 :: v_dual_mov_b32 v11, 0             // 0000005A1028: CA100001 020A0080
	v_dual_mov_b32 v10, 0 :: v_dual_and_b32 v7, 15, v0         // 0000005A1030: CA240080 0A06008F
	v_or_b32_e32 v1, s0, v1                                    // 0000005A1038: 38020200
	v_mov_b32_e32 v12, 0                                       // 0000005A103C: 7E180280
	s_waitcnt lgkmcnt(0)                                       // 0000005A1040: BF89FC07
	s_ashr_i32 s1, s11, 31                                     // 0000005A1044: 86019F0B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000005A1048: BF8704A2
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[1:2]                  // 0000005A104C: 7CA8020C
	s_lshr_b32 s1, s1, 28                                      // 0000005A1050: 85019C01
	s_add_u32 s0, s10, s1                                      // 0000005A1054: 8000010A
	s_addc_u32 s1, s11, 0                                      // 0000005A1058: 8201800B
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000005A105C: BF870009
	s_lshr_b64 s[14:15], s[0:1], 4                             // 0000005A1060: 858E8400
	s_mov_b32 s1, exec_lo                                      // 0000005A1064: BE81007E
	.long 0xd4c4007e                                           // 0000005A1068: D4C4007E
	v_cndmask_b32_e32 v1, s14, v7, vcc_lo                      // 0000005A106C: 02020E0E
	s_cbranch_execz 492                                        // 0000005A1070: BFA501EC <_ZN7halogen12_GLOBAL__N_16k_lq6kILi5ELi16ELi1ELb0EEEvPKhPKtPvll+0x824>
	s_ashr_i32 s0, s11, 31                                     // 0000005A1074: 86009F0B
	v_cndmask_b32_e32 v3, 0, v2, vcc_lo                        // 0000005A1078: 02060480
	s_lshr_b32 s0, s0, 24                                      // 0000005A107C: 85009800
	v_dual_cndmask_b32 v5, 0, v1 :: v_dual_mov_b32 v6, 0       // 0000005A1080: CA500280 05060080
	s_add_u32 s16, s10, s0                                     // 0000005A1088: 8010000A
	s_addc_u32 s17, s11, 0                                     // 0000005A108C: 8211800B
	v_dual_mov_b32 v22, 0 :: v_dual_and_b32 v13, 4, v0         // 0000005A1090: CA240080 160C0084
	s_ashr_i64 s[16:17], s[16:17], 8                           // 0000005A1098: 86908810
	v_and_b32_e32 v0, 6, v0                                    // 0000005A109C: 36000086
	s_mul_i32 s0, s17, 0xd2                                    // 0000005A10A0: 9600FF11 000000D2
	s_mul_hi_u32 s2, s16, 0xd2                                 // 0000005A10A8: 9682FF10 000000D2
	s_mul_i32 s15, s16, 0xd2                                   // 0000005A10B0: 960FFF10 000000D2
	s_add_i32 s2, s2, s0                                       // 0000005A10B8: 81020002
	.long 0xd72c0008                                           // 0000005A10BC: D72C0008
	v_cndmask_b32_e32 v1, s15, v3, vcc_lo                      // 0000005A10C0: 0202060F
	v_mad_u64_u32 v[3:4], null, s15, v5, s[4:5]                // 0000005A10C4: D6FE7C03 00120A0F
	.long 0xd72c0005                                           // 0000005A10CC: D72C0005
	v_cndmask_b32_e32 v1, s2, v5, vcc_lo                       // 0000005A10D0: 02020A02
	v_lshrrev_b32_e32 v9, 3, v7                                // 0000005A10D4: 32120E83
	v_or_b32_e32 v16, 8, v13                                   // 0000005A10D8: 38201A88
	v_or_b32_e32 v17, 8, v0                                    // 0000005A10DC: 38220088
	v_or_b32_e32 v18, 16, v13                                  // 0000005A10E0: 38241A90
	v_or_b32_e32 v19, 16, v0                                   // 0000005A10E4: 38260090
	v_dual_mov_b32 v23, v7 :: v_dual_lshlrev_b32 v14, 6, v9    // 0000005A10E8: CA220107 170E1286
	v_dual_mov_b32 v12, v6 :: v_dual_lshlrev_b32 v15, 5, v9    // 0000005A10F0: CA220106 0C0E1285
	v_add3_u32 v4, v5, v4, v8                                  // 0000005A10F8: D6550004 04220905
	v_or_b32_e32 v20, 24, v13                                  // 0000005A1100: 38281A98
	v_or_b32_e32 v21, 24, v0                                   // 0000005A1104: 382A0098
	v_dual_mov_b32 v10, v6 :: v_dual_lshlrev_b32 v5, 4, v7     // 0000005A1108: CA220106 0A040E84
	v_mov_b32_e32 v11, v6                                      // 0000005A1110: 7E160306
	v_mov_b32_e32 v9, v6                                       // 0000005A1114: 7E120306
	v_mov_b32_e32 v8, v6                                       // 0000005A1118: 7E100306
	s_mul_i32 s0, s11, 6                                       // 0000005A111C: 9600860B
	s_mul_hi_u32 s2, s10, 6                                    // 0000005A1120: 9682860A
	s_lshl_b64 s[4:5], s[10:11], 2                             // 0000005A1124: 8484820A
	s_add_i32 s2, s2, s0                                       // 0000005A1128: 81020002
	s_mul_i32 s15, s10, 6                                      // 0000005A112C: 960F860A
	s_lshl_b64 s[10:11], s[10:11], 1                           // 0000005A1130: 848A810A
	.long 0xd7000034                                           // 0000005A1134: D7000034
	v_cndmask_b32_e32 v1, v3, v22, vcc_lo                      // 0000005A1138: 02022D03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000005A113C: BF8701A1
	v_add_co_ci_u32_e64 v53, null, 0, v4, s0                   // 0000005A1140: D5207C35 00020880
	.long 0xd73c0018                                           // 0000005A1148: D73C0018
	v_cndmask_b32_e32 v1, 1, v5, vcc_lo                        // 0000005A114C: 02020A81
	.long 0xd700001b                                           // 0000005A1150: D700001B
	v_cndmask_b32_e32 v1, v52, v14, vcc_lo                     // 0000005A1154: 02021D34
	s_delay_alu instid0(VALU_DEP_1)                            // 0000005A1158: BF870001
	v_add_co_ci_u32_e64 v28, null, 0, v53, s0                  // 0000005A115C: D5207C1C 00026A80
	.long 0xd700001d                                           // 0000005A1164: D700001D
	v_cndmask_b32_e32 v1, v52, v15, vcc_lo                     // 0000005A1168: 02021F34
	v_and_b32_e32 v26, 32, v5                                  // 0000005A116C: 36340AA0
	v_add_co_ci_u32_e64 v30, null, 0, v53, s0                  // 0000005A1170: D5207C1E 00026A80
	.long 0xd7000024                                           // 0000005A1178: D7000024
	v_cndmask_b32_e32 v1, v52, v7, vcc_lo                      // 0000005A117C: 02020F34
	v_and_b32_e32 v38, 16, v5                                  // 0000005A1180: 364C0A90
	v_add_co_ci_u32_e64 v37, null, 0, v53, s0                  // 0000005A1184: D5207C25 00026A80
	.long 0xd7000020                                           // 0000005A118C: D7000020
	v_cndmask_b32_e32 v1, s6, v24, vcc_lo                      // 0000005A1190: 02023006
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000005A1194: BF8700A1
	v_add_co_ci_u32_e64 v33, null, s7, v25, s0                 // 0000005A1198: D5207C21 00023207
	.long 0xd7000027                                           // 0000005A11A0: D7000027
	v_cndmask_b32_e32 v1, v27, v26, vcc_lo                     // 0000005A11A4: 0202351B
	v_add_co_ci_u32_e64 v40, null, 0, v28, s0                  // 0000005A11A8: D5207C28 00023880
	.long 0xd7000022                                           // 0000005A11B0: D7000022
	v_cndmask_b32_e32 v1, v29, v38, vcc_lo                     // 0000005A11B4: 02024D1D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000005A11B8: BF8700A1
	v_add_co_ci_u32_e64 v35, null, 0, v30, s0                  // 0000005A11BC: D5207C23 00023C80
	.long 0xd7000038                                           // 0000005A11C4: D7000038
	v_cndmask_b32_e32 v0, v32, v10, vcc_lo                     // 0000005A11C8: 02001520
	v_add_co_ci_u32_e64 v57, null, s11, v33, s0                // 0000005A11CC: D5207C39 0002420B
	.long 0xd700003a                                           // 0000005A11D4: D700003A
	v_cndmask_b32_e32 v0, v32, v4, vcc_lo                      // 0000005A11D8: 02000920
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000005A11DC: BF8700A1
	v_add_co_ci_u32_e64 v59, null, s5, v33, s0                 // 0000005A11E0: D5207C3B 00024205
	.long 0xd700003c                                           // 0000005A11E8: D700003C
	v_cndmask_b32_e32 v0, v32, v15, vcc_lo                     // 0000005A11EC: 02001F20
	v_add_co_ci_u32_e64 v61, null, s2, v33, s0                 // 0000005A11F0: D5207C3D 00024202
	.long 0xd7000030                                           // 0000005A11F8: D7000030
	v_cndmask_b32_e32 v1, v39, v38, vcc_lo                     // 0000005A11FC: 02024D27
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000005A1200: BF8700A1
	v_add_co_ci_u32_e64 v49, null, 0, v40, s0                  // 0000005A1204: D5207C31 00025080
	.long 0xd700003e                                           // 0000005A120C: D700003E
	v_cndmask_b32_e32 v0, v58, v4, vcc_lo                      // 0000005A1210: 0200093A
	v_add_co_ci_u32_e64 v63, null, s5, v59, s0                 // 0000005A1214: D5207C3F 00027605
	s_clause 0x1                                               // 0000005A121C: BF850001
	global_load_b128 v[24:27], v[32:33], off                   // 0000005A1220: DC5E0000 187C0020
	global_load_b128 v[28:31], v[32:33], off offset:16         // 0000005A1228: DC5E0010 1C7C0020
	s_clause 0x2                                               // 0000005A1230: BF850002
	global_load_b128 v[32:35], v[34:35], off offset:128        // 0000005A1234: DC5E0080 207C0022
	global_load_b128 v[48:51], v[48:49], off                   // 0000005A123C: DC5E0000 307C0030
	global_load_d16_b16 v65, v[52:53], off offset:208          // 0000005A1244: DC8200D0 417C0034
	global_load_b128 v[52:55], v[62:63], off                   // 0000005A124C: DC5E0000 347C003E
	global_load_i8 v64, v[36:37], off offset:192               // 0000005A1254: DC4600C0 407C0024
	s_clause 0x2                                               // 0000005A125C: BF850002
	global_load_b128 v[36:39], v[56:57], off                   // 0000005A1260: DC5E0000 247C0038
	global_load_b128 v[40:43], v[58:59], off                   // 0000005A1268: DC5E0000 287C003A
	global_load_b128 v[44:47], v[60:61], off                   // 0000005A1270: DC5E0000 2C7C003C
	s_waitcnt vmcnt(6)                                         // 0000005A1278: BF891BF7
	v_bfe_u32 v82, v48, v13, 4                                 // 0000005A127C: D6100052 02121B30
	v_lshrrev_b32_e32 v66, v0, v32                             // 0000005A1284: 32844100
	v_lshrrev_b32_e32 v67, v17, v32                            // 0000005A1288: 32864111
	v_lshrrev_b32_e32 v68, v19, v32                            // 0000005A128C: 32884113
	v_lshrrev_b32_e32 v69, v21, v32                            // 0000005A1290: 328A4115
	v_lshrrev_b32_e32 v70, v0, v33                             // 0000005A1294: 328C4300
	v_lshrrev_b32_e32 v71, v17, v33                            // 0000005A1298: 328E4311
	v_lshrrev_b32_e32 v72, v19, v33                            // 0000005A129C: 32904313
	v_lshrrev_b32_e32 v73, v21, v33                            // 0000005A12A0: 32924315
	v_lshrrev_b32_e32 v74, v0, v34                             // 0000005A12A4: 32944500
	v_lshrrev_b32_e32 v75, v17, v34                            // 0000005A12A8: 32964511
	v_lshrrev_b32_e32 v76, v19, v34                            // 0000005A12AC: 32984513
	v_lshrrev_b32_e32 v77, v21, v34                            // 0000005A12B0: 329A4515
	v_lshrrev_b32_e32 v78, v0, v35                             // 0000005A12B4: 329C4700
	v_lshrrev_b32_e32 v79, v17, v35                            // 0000005A12B8: 329E4711
	v_lshrrev_b32_e32 v80, v19, v35                            // 0000005A12BC: 32A04713
	v_lshrrev_b32_e32 v81, v21, v35                            // 0000005A12C0: 32A24715
	v_bfe_u32 v83, v48, v16, 4                                 // 0000005A12C4: D6100053 02122130
	v_bfe_u32 v84, v48, v18, 4                                 // 0000005A12CC: D6100054 02122530
	v_bfe_u32 v85, v48, v20, 4                                 // 0000005A12D4: D6100055 02122930
	v_bfe_u32 v86, v49, v13, 4                                 // 0000005A12DC: D6100056 02121B31
	v_bfe_u32 v87, v49, v16, 4                                 // 0000005A12E4: D6100057 02122131
	v_bfe_u32 v88, v49, v18, 4                                 // 0000005A12EC: D6100058 02122531
	v_bfe_u32 v89, v49, v20, 4                                 // 0000005A12F4: D6100059 02122931
	v_bfe_u32 v90, v50, v13, 4                                 // 0000005A12FC: D610005A 02121B32
	v_bfe_u32 v91, v50, v16, 4                                 // 0000005A1304: D610005B 02122132
	v_bfe_u32 v92, v50, v18, 4                                 // 0000005A130C: D610005C 02122532
	v_bfe_u32 v93, v50, v20, 4                                 // 0000005A1314: D610005D 02122932
	v_bfe_u32 v94, v51, v13, 4                                 // 0000005A131C: D610005E 02121B33
	v_bfe_u32 v95, v51, v16, 4                                 // 0000005A1324: D610005F 02122133
	v_bfe_u32 v96, v51, v18, 4                                 // 0000005A132C: D6100060 02122533
	v_bfe_u32 v97, v51, v20, 4                                 // 0000005A1334: D6100061 02122933
	s_clause 0x1                                               // 0000005A133C: BF850001
	global_load_b128 v[32:35], v[56:57], off offset:16         // 0000005A1340: DC5E0010 207C0038
	global_load_b128 v[48:51], v[58:59], off offset:16         // 0000005A1348: DC5E0010 307C003A
	s_waitcnt vmcnt(5)                                         // 0000005A1350: BF8917F7
	v_cvt_f32_i32_e32 v56, v64                                 // 0000005A1354: 7E700B40
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000005A1358: BF8700A1
	v_fma_mix_f32 v64, v65, v56, neg(0) op_sel_hi:[1,0,0]      // 0000005A135C: CC200040 8A027141
	v_lshlrev_b32_e32 v57, 4, v66                              // 0000005A1364: 30728484
	v_and_or_b32 v65, v57, 48, v82                             // 0000005A1368: D6570041 05496139
	global_load_b128 v[56:59], v[60:61], off offset:16         // 0000005A1370: DC5E0010 387C003C
	v_subrev_nc_u32_e32 v65, 32, v65                           // 0000005A1378: 4E8282A0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005A137C: BF870091
	v_cvt_f32_i32_e32 v65, v65                                 // 0000005A1380: 7E820B41
	v_dual_mul_f32 v65, v64, v65 :: v_dual_lshlrev_b32 v60, 4, v67// 0000005A1384: C8E28340 413C8684
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005A138C: BF870091
	v_and_or_b32 v66, v60, 48, v83                             // 0000005A1390: D6570042 054D613C
	v_subrev_nc_u32_e32 v66, 32, v66                           // 0000005A1398: 4E8484A0
	s_delay_alu instid0(VALU_DEP_1)                            // 0000005A139C: BF870001
	v_cvt_f32_i32_e32 v66, v66                                 // 0000005A13A0: 7E840B42
	v_lshlrev_b32_e32 v61, 4, v68                              // 0000005A13A4: 307A8884
	v_lshlrev_b32_e32 v68, 4, v69                              // 0000005A13A8: 30888A84
	v_lshlrev_b32_e32 v69, 4, v70                              // 0000005A13AC: 308A8C84
	v_lshlrev_b32_e32 v70, 4, v71                              // 0000005A13B0: 308C8E84
	v_mul_f32_e32 v66, v64, v66                                // 0000005A13B4: 10848540
	v_and_or_b32 v67, v61, 48, v84                             // 0000005A13B8: D6570043 0551613D
	global_load_b128 v[60:63], v[62:63], off offset:16         // 0000005A13C0: DC5E0010 3C7C003E
	v_lshlrev_b32_e32 v71, 4, v72                              // 0000005A13C8: 308E9084
	v_lshlrev_b32_e32 v72, 4, v73                              // 0000005A13CC: 30909284
	v_lshlrev_b32_e32 v73, 4, v74                              // 0000005A13D0: 30929484
	v_lshlrev_b32_e32 v74, 4, v75                              // 0000005A13D4: 30949684
	v_lshlrev_b32_e32 v75, 4, v76                              // 0000005A13D8: 30969884
	v_lshlrev_b32_e32 v76, 4, v77                              // 0000005A13DC: 30989A84
	v_lshlrev_b32_e32 v77, 4, v78                              // 0000005A13E0: 309A9C84
	v_lshlrev_b32_e32 v78, 4, v79                              // 0000005A13E4: 309C9E84
	v_lshlrev_b32_e32 v79, 4, v80                              // 0000005A13E8: 309EA084
	v_and_or_b32 v73, v73, 48, v90                             // 0000005A13EC: D6570049 05696149
	v_and_or_b32 v76, v76, 48, v93                             // 0000005A13F4: D657004C 0575614C
	v_and_or_b32 v77, v77, 48, v94                             // 0000005A13FC: D657004D 0579614D
	v_and_or_b32 v78, v78, 48, v95                             // 0000005A1404: D657004E 057D614E
	v_and_or_b32 v79, v79, 48, v96                             // 0000005A140C: D657004F 0581614F
	v_subrev_nc_u32_e32 v73, 32, v73                           // 0000005A1414: 4E9292A0
	v_subrev_nc_u32_e32 v76, 32, v76                           // 0000005A1418: 4E9898A0
	v_subrev_nc_u32_e32 v77, 32, v77                           // 0000005A141C: 4E9A9AA0
	v_subrev_nc_u32_e32 v78, 32, v78                           // 0000005A1420: 4E9C9CA0
	v_subrev_nc_u32_e32 v79, 32, v79                           // 0000005A1424: 4E9E9EA0
	v_lshlrev_b32_e32 v80, 4, v81                              // 0000005A1428: 30A0A284
	v_cvt_f32_i32_e32 v73, v73                                 // 0000005A142C: 7E920B49
	v_cvt_f32_i32_e32 v77, v77                                 // 0000005A1430: 7E9A0B4D
	v_cvt_f32_i32_e32 v78, v78                                 // 0000005A1434: 7E9C0B4E
	v_cvt_f32_i32_e32 v76, v76                                 // 0000005A1438: 7E980B4C
	v_cvt_f32_i32_e32 v79, v79                                 // 0000005A143C: 7E9E0B4F
	v_and_or_b32 v80, v80, 48, v97                             // 0000005A1440: D6570050 05856150
	v_mul_f32_e32 v77, v64, v77                                // 0000005A1448: 109A9B40
	v_and_or_b32 v74, v74, 48, v91                             // 0000005A144C: D657004A 056D614A
	v_mul_f32_e32 v78, v64, v78                                // 0000005A1454: 109C9D40
	v_and_or_b32 v75, v75, 48, v92                             // 0000005A1458: D657004B 0571614B
	v_mul_f32_e32 v73, v64, v73                                // 0000005A1460: 10929340
	v_and_or_b32 v70, v70, 48, v87                             // 0000005A1464: D6570046 055D6146
	v_subrev_nc_u32_e32 v74, 32, v74                           // 0000005A146C: 4E9494A0
	v_mul_f32_e32 v76, v64, v76                                // 0000005A1470: 10989940
	v_subrev_nc_u32_e32 v75, 32, v75                           // 0000005A1474: 4E9696A0
	v_and_or_b32 v69, v69, 48, v86                             // 0000005A1478: D6570045 05596145
	v_mul_f32_e32 v79, v64, v79                                // 0000005A1480: 109E9F40
	v_cvt_f32_i32_e32 v74, v74                                 // 0000005A1484: 7E940B4A
	v_and_or_b32 v72, v72, 48, v89                             // 0000005A1488: D6570048 05656148
	v_cvt_f32_i32_e32 v75, v75                                 // 0000005A1490: 7E960B4B
	v_subrev_nc_u32_e32 v67, 32, v67                           // 0000005A1494: 4E8686A0
	v_subrev_nc_u32_e32 v69, 32, v69                           // 0000005A1498: 4E8A8AA0
	v_mul_f32_e32 v74, v64, v74                                // 0000005A149C: 10949540
	v_and_or_b32 v71, v71, 48, v88                             // 0000005A14A0: D6570047 05616147
	v_mul_f32_e32 v75, v64, v75                                // 0000005A14A8: 10969740
	v_and_or_b32 v68, v68, 48, v85                             // 0000005A14AC: D6570044 05556144
	v_subrev_nc_u32_e32 v70, 32, v70                           // 0000005A14B4: 4E8C8CA0
	v_subrev_nc_u32_e32 v72, 32, v72                           // 0000005A14B8: 4E9090A0
	v_subrev_nc_u32_e32 v71, 32, v71                           // 0000005A14BC: 4E8E8EA0
	v_subrev_nc_u32_e32 v80, 32, v80                           // 0000005A14C0: 4EA0A0A0
	v_subrev_nc_u32_e32 v68, 32, v68                           // 0000005A14C4: 4E8888A0
	v_cvt_f32_i32_e32 v67, v67                                 // 0000005A14C8: 7E860B43
	v_cvt_f32_i32_e32 v69, v69                                 // 0000005A14CC: 7E8A0B45
	v_cvt_f32_i32_e32 v70, v70                                 // 0000005A14D0: 7E8C0B46
	v_cvt_f32_i32_e32 v71, v71                                 // 0000005A14D4: 7E8E0B47
	v_cvt_f32_i32_e32 v68, v68                                 // 0000005A14D8: 7E880B44
	v_cvt_f32_i32_e32 v72, v72                                 // 0000005A14DC: 7E900B48
	v_cvt_f32_i32_e32 v80, v80                                 // 0000005A14E0: 7EA00B50
	v_dual_mul_f32 v70, v64, v70 :: v_dual_add_nc_u32 v23, 16, v23// 0000005A14E4: C8E08D40 46162E90
	s_delay_alu instid0(VALU_DEP_3)                            // 0000005A14EC: BF870003
	v_dual_mul_f32 v72, v64, v72 :: v_dual_add_nc_u32 v5, 0x100, v5// 0000005A14F0: C8E09140 48040AFF 00000100
	v_dual_mul_f32 v69, v64, v69 :: v_dual_add_nc_u32 v22, 0xd2, v22// 0000005A14FC: C8E08B40 45162CFF 000000D2
	v_mul_f32_e32 v67, v64, v67                                // 0000005A1508: 10868740
	v_mul_f32_e32 v68, v64, v68                                // 0000005A150C: 10888940
	v_mul_f32_e32 v71, v64, v71                                // 0000005A1510: 108E8F40
	v_mul_f32_e32 v64, v64, v80                                // 0000005A1514: 1080A140
	v_bfe_u32 v80, v65, 16, 1                                  // 0000005A1518: D6100050 02052141
	v_bfe_u32 v81, v66, 16, 1                                  // 0000005A1520: D6100051 02052142
	v_bfe_u32 v82, v67, 16, 1                                  // 0000005A1528: D6100052 02052143
	v_bfe_u32 v83, v68, 16, 1                                  // 0000005A1530: D6100053 02052144
	v_bfe_u32 v84, v69, 16, 1                                  // 0000005A1538: D6100054 02052145
	v_add3_u32 v65, v65, v80, 0x7fff                           // 0000005A1540: D6550041 03FEA141 00007FFF
	v_add3_u32 v66, v66, v81, 0x7fff                           // 0000005A154C: D6550042 03FEA342 00007FFF
	v_add3_u32 v67, v67, v82, 0x7fff                           // 0000005A1558: D6550043 03FEA543 00007FFF
	v_bfe_u32 v85, v70, 16, 1                                  // 0000005A1564: D6100055 02052146
	v_add3_u32 v68, v68, v83, 0x7fff                           // 0000005A156C: D6550044 03FEA744 00007FFF
	.long 0x7e8439c1                                           // 0000005A1578: 7E8439C1
	v_bfe_u32 v86, v71, 16, 1                                  // 0000005A157C: D6100056 02052147
	v_add3_u32 v69, v69, v84, 0x7fff                           // 0000005A1584: D6550045 03FEA945 00007FFF
	.long 0x7e8839c3                                           // 0000005A1590: 7E8839C3
	v_bfe_u32 v87, v72, 16, 1                                  // 0000005A1594: D6100057 02052148
	v_dot2_f32_bf16 v24, v24, v66, 0                           // 0000005A159C: CC1A4018 1A028518
	s_waitcnt vmcnt(6)                                         // 0000005A15A4: BF891BF7
	v_dot2_f32_bf16 v36, v36, v66, 0                           // 0000005A15A8: CC1A4024 1A028524
	s_waitcnt vmcnt(5)                                         // 0000005A15B0: BF8917F7
	v_dot2_f32_bf16 v40, v40, v66, 0                           // 0000005A15B4: CC1A4028 1A028528
	s_waitcnt vmcnt(4)                                         // 0000005A15BC: BF8913F7
	v_dot2_f32_bf16 v44, v44, v66, 0                           // 0000005A15C0: CC1A402C 1A02852C
	v_dot2_f32_bf16 v52, v52, v66, 0                           // 0000005A15C8: CC1A4034 1A028534
	v_add3_u32 v70, v70, v85, 0x7fff                           // 0000005A15D0: D6550046 03FEAB46 00007FFF
	v_bfe_u32 v88, v73, 16, 1                                  // 0000005A15DC: D6100058 02052149
	v_add3_u32 v71, v71, v86, 0x7fff                           // 0000005A15E4: D6550047 03FEAD47 00007FFF
	.long 0x7e8c39c5                                           // 0000005A15F0: 7E8C39C5
	v_dot2_f32_bf16 v24, v25, v68, v24                         // 0000005A15F4: CC1A4018 1C628919
	v_dot2_f32_bf16 v25, v37, v68, v36                         // 0000005A15FC: CC1A4019 1C928925
	v_dot2_f32_bf16 v36, v41, v68, v40                         // 0000005A1604: CC1A4024 1CA28929
	v_dot2_f32_bf16 v37, v45, v68, v44                         // 0000005A160C: CC1A4025 1CB2892D
	v_dot2_f32_bf16 v40, v53, v68, v52                         // 0000005A1614: CC1A4028 1CD28935
	v_bfe_u32 v89, v74, 16, 1                                  // 0000005A161C: D6100059 0205214A
	v_add3_u32 v72, v72, v87, 0x7fff                           // 0000005A1624: D6550048 03FEAF48 00007FFF
	v_bfe_u32 v90, v75, 16, 1                                  // 0000005A1630: D610005A 0205214B
	v_add3_u32 v73, v73, v88, 0x7fff                           // 0000005A1638: D6550049 03FEB149 00007FFF
	.long 0x7e9039c7                                           // 0000005A1644: 7E9039C7
	v_dot2_f32_bf16 v24, v26, v70, v24                         // 0000005A1648: CC1A4018 1C628D1A
	v_dot2_f32_bf16 v25, v38, v70, v25                         // 0000005A1650: CC1A4019 1C668D26
	v_dot2_f32_bf16 v26, v42, v70, v36                         // 0000005A1658: CC1A401A 1C928D2A
	v_dot2_f32_bf16 v36, v46, v70, v37                         // 0000005A1660: CC1A4024 1C968D2E
	v_dot2_f32_bf16 v37, v54, v70, v40                         // 0000005A1668: CC1A4025 1CA28D36
	v_bfe_u32 v91, v76, 16, 1                                  // 0000005A1670: D610005B 0205214C
	v_add3_u32 v74, v74, v89, 0x7fff                           // 0000005A1678: D655004A 03FEB34A 00007FFF
	v_bfe_u32 v92, v77, 16, 1                                  // 0000005A1684: D610005C 0205214D
	v_add3_u32 v75, v75, v90, 0x7fff                           // 0000005A168C: D655004B 03FEB54B 00007FFF
	.long 0x7e9439c9                                           // 0000005A1698: 7E9439C9
	v_dot2_f32_bf16 v24, v27, v72, v24                         // 0000005A169C: CC1A4018 1C62911B
	v_dot2_f32_bf16 v25, v39, v72, v25                         // 0000005A16A4: CC1A4019 1C669127
	v_dot2_f32_bf16 v26, v43, v72, v26                         // 0000005A16AC: CC1A401A 1C6A912B
	v_dot2_f32_bf16 v27, v47, v72, v36                         // 0000005A16B4: CC1A401B 1C92912F
	v_dot2_f32_bf16 v36, v55, v72, v37                         // 0000005A16BC: CC1A4024 1C969137
	v_bfe_u32 v93, v78, 16, 1                                  // 0000005A16C4: D610005D 0205214E
	v_add3_u32 v76, v76, v91, 0x7fff                           // 0000005A16CC: D655004C 03FEB74C 00007FFF
	v_bfe_u32 v80, v79, 16, 1                                  // 0000005A16D8: D6100050 0205214F
	v_add3_u32 v77, v77, v92, 0x7fff                           // 0000005A16E0: D655004D 03FEB94D 00007FFF
	.long 0x7e9839cb                                           // 0000005A16EC: 7E9839CB
	v_dot2_f32_bf16 v24, v28, v74, v24                         // 0000005A16F0: CC1A4018 1C62951C
	v_bfe_u32 v81, v64, 16, 1                                  // 0000005A16F8: D6100051 02052140
	v_add3_u32 v78, v78, v93, 0x7fff                           // 0000005A1700: D655004E 03FEBB4E 00007FFF
	v_add3_u32 v79, v79, v80, 0x7fff                           // 0000005A170C: D655004F 03FEA14F 00007FFF
	.long 0x7e9c39cd                                           // 0000005A1718: 7E9C39CD
	v_dot2_f32_bf16 v24, v29, v76, v24                         // 0000005A171C: CC1A4018 1C62991D
	v_add3_u32 v64, v64, v81, 0x7fff                           // 0000005A1724: D6550040 03FEA340 00007FFF
	.long 0xd4430000                                           // 0000005A1730: D4430000
	v_cndmask_b32_e32 v1, s14, v23, vcc_lo                     // 0000005A1734: 02022E0E
	.long 0x7e8039cf                                           // 0000005A1738: 7E8039CF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000005A173C: BF8700A4
	v_dot2_f32_bf16 v24, v30, v78, v24                         // 0000005A1740: CC1A4018 1C629D1E
	s_or_b32 s3, s0, s3                                        // 0000005A1748: 8C030300
	v_dot2_f32_bf16 v24, v31, v64, v24                         // 0000005A174C: CC1A4018 1C62811F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 0000005A1754: BF870151
	v_add_f32_e32 v12, v12, v24                                // 0000005A1758: 0618310C
	s_waitcnt vmcnt(3)                                         // 0000005A175C: BF890FF7
	v_dot2_f32_bf16 v25, v32, v74, v25                         // 0000005A1760: CC1A4019 1C669520
	s_waitcnt vmcnt(2)                                         // 0000005A1768: BF890BF7
	v_dot2_f32_bf16 v26, v48, v74, v26                         // 0000005A176C: CC1A401A 1C6A9530
	v_dot2_f32_bf16 v25, v33, v76, v25                         // 0000005A1774: CC1A4019 1C669921
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000005A177C: BF870112
	v_dot2_f32_bf16 v26, v49, v76, v26                         // 0000005A1780: CC1A401A 1C6A9931
	v_dot2_f32_bf16 v25, v34, v78, v25                         // 0000005A1788: CC1A4019 1C669D22
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000005A1790: BF8701B2
	v_dot2_f32_bf16 v26, v50, v78, v26                         // 0000005A1794: CC1A401A 1C6A9D32
	s_waitcnt vmcnt(1)                                         // 0000005A179C: BF8907F7
	v_dot2_f32_bf16 v27, v56, v74, v27                         // 0000005A17A0: CC1A401B 1C6E9538
	v_dot2_f32_bf16 v25, v35, v64, v25                         // 0000005A17A8: CC1A4019 1C668123
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000005A17B0: BF870193
	v_dot2_f32_bf16 v26, v51, v64, v26                         // 0000005A17B4: CC1A401A 1C6A8133
	v_dot2_f32_bf16 v27, v57, v76, v27                         // 0000005A17BC: CC1A401B 1C6E9939
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000005A17C4: BF870112
	v_dual_add_f32 v11, v11, v25 :: v_dual_add_f32 v10, v10, v26// 0000005A17C8: C908330B 0B0A350A
	v_dot2_f32_bf16 v27, v58, v78, v27                         // 0000005A17D0: CC1A401B 1C6E9D3A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005A17D8: BF870091
	v_dot2_f32_bf16 v27, v59, v64, v27                         // 0000005A17DC: CC1A401B 1C6E813B
	v_add_f32_e32 v9, v9, v27                                  // 0000005A17E4: 06123709
	s_waitcnt vmcnt(0)                                         // 0000005A17E8: BF8903F7
	v_dot2_f32_bf16 v28, v60, v74, v36                         // 0000005A17EC: CC1A401C 1C92953C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005A17F4: BF870091
	v_dot2_f32_bf16 v28, v61, v76, v28                         // 0000005A17F8: CC1A401C 1C72993D
	v_dot2_f32_bf16 v28, v62, v78, v28                         // 0000005A1800: CC1A401C 1C729D3E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005A1808: BF870091
	v_dot2_f32_bf16 v28, v63, v64, v28                         // 0000005A180C: CC1A401C 1C72813F
	v_add_f32_e32 v8, v8, v28                                  // 0000005A1814: 06103908
	s_and_not1_b32 exec_lo, exec_lo, s3                        // 0000005A1818: 917E037E
	s_cbranch_execnz 65093                                     // 0000005A181C: BFA6FE45 <_ZN7halogen12_GLOBAL__N_16k_lq6kILi5ELi16ELi1ELb0EEEvPKhPKtPvll+0x134>
	s_or_b32 exec_lo, exec_lo, s3                              // 0000005A1820: 8C7E037E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000005A1824: BF8700A9
	s_or_b32 exec_lo, exec_lo, s1                              // 0000005A1828: 8C7E017E
	.long 0xd71f0000                                           // 0000005A182C: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000005A1830: 020100C1
	v_xor_b32_e32 v3, 8, v0                                    // 0000005A1834: 3A060088
	v_xor_b32_e32 v14, 4, v0                                   // 0000005A1838: 3A1C0084
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005A183C: BF870092
	.long 0xd44c0000                                           // 0000005A1840: D44C0000
	v_cndmask_b32_e32 v1, 32, v3, vcc_lo                       // 0000005A1844: 020206A0
	v_cndmask_b32_e64 v3, v0, v3, s0                           // 0000005A1848: D5010003 00020700
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000005A1850: BF870113
	.long 0xd44c0000                                           // 0000005A1854: D44C0000
	v_cndmask_b32_e32 v1, 32, v14, vcc_lo                      // 0000005A1858: 02021CA0
	v_lshlrev_b32_e32 v3, 2, v3                                // 0000005A185C: 30060682
	s_delay_alu instid0(VALU_DEP_2)                            // 0000005A1860: BF870002
	v_cndmask_b32_e64 v14, v0, v14, s0                         // 0000005A1864: D501000E 00021D00
	ds_bpermute_b32 v4, v3, v12                                // 0000005A186C: DACC0000 04000C03
	s_waitcnt lgkmcnt(0)                                       // 0000005A1874: BF89FC07
	v_add_f32_e32 v4, v12, v4                                  // 0000005A1878: 0608090C
	ds_bpermute_b32 v5, v3, v11                                // 0000005A187C: DACC0000 05000B03
	ds_bpermute_b32 v6, v3, v10                                // 0000005A1884: DACC0000 06000A03
	ds_bpermute_b32 v13, v3, v9                                // 0000005A188C: DACC0000 0D000903
	ds_bpermute_b32 v3, v3, v8                                 // 0000005A1894: DACC0000 03000803
	s_waitcnt lgkmcnt(3)                                       // 0000005A189C: BF89FC37
	v_dual_add_f32 v5, v11, v5 :: v_dual_lshlrev_b32 v14, 2, v14// 0000005A18A0: C9220B0B 050E1C82
	s_waitcnt lgkmcnt(1)                                       // 0000005A18A8: BF89FC17
	v_dual_add_f32 v6, v10, v6 :: v_dual_add_f32 v9, v9, v13   // 0000005A18AC: C9080D0A 06081B09
	s_waitcnt lgkmcnt(0)                                       // 0000005A18B4: BF89FC07
	v_add_f32_e32 v3, v8, v3                                   // 0000005A18B8: 06060708
	ds_bpermute_b32 v8, v14, v4                                // 0000005A18BC: DACC0000 0800040E
	ds_bpermute_b32 v10, v14, v5                               // 0000005A18C4: DACC0000 0A00050E
	ds_bpermute_b32 v11, v14, v6                               // 0000005A18CC: DACC0000 0B00060E
	ds_bpermute_b32 v12, v14, v9                               // 0000005A18D4: DACC0000 0C00090E
	ds_bpermute_b32 v13, v14, v3                               // 0000005A18DC: DACC0000 0D00030E
	v_xor_b32_e32 v14, 2, v0                                   // 0000005A18E4: 3A1C0082
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005A18E8: BF870091
	.long 0xd44c0000                                           // 0000005A18EC: D44C0000
	v_cndmask_b32_e32 v1, 32, v14, vcc_lo                      // 0000005A18F0: 02021CA0
	v_cndmask_b32_e64 v14, v0, v14, s0                         // 0000005A18F4: D501000E 00021D00
	s_delay_alu instid0(VALU_DEP_1)                            // 0000005A18FC: BF870001
	v_lshlrev_b32_e32 v14, 2, v14                              // 0000005A1900: 301C1C82
	s_waitcnt lgkmcnt(3)                                       // 0000005A1904: BF89FC37
	v_dual_add_f32 v4, v4, v8 :: v_dual_add_f32 v5, v5, v10    // 0000005A1908: C9081104 04041505
	s_waitcnt lgkmcnt(0)                                       // 0000005A1910: BF89FC07
	v_dual_add_f32 v6, v6, v11 :: v_dual_add_f32 v11, v3, v13  // 0000005A1914: C9081706 060A1B03
	ds_bpermute_b32 v3, v14, v4                                // 0000005A191C: DACC0000 0300040E
	v_add_f32_e32 v8, v9, v12                                  // 0000005A1924: 06101909
	v_xor_b32_e32 v9, 1, v0                                    // 0000005A1928: 3A120081
	ds_bpermute_b32 v10, v14, v5                               // 0000005A192C: DACC0000 0A00050E
	ds_bpermute_b32 v12, v14, v6                               // 0000005A1934: DACC0000 0C00060E
	.long 0xd44c0000                                           // 0000005A193C: D44C0000
	v_cndmask_b32_e32 v1, 32, v9, vcc_lo                       // 0000005A1940: 020212A0
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000005A1944: BF870121
	v_cndmask_b32_e64 v0, v0, v9, s0                           // 0000005A1948: D5010000 00021300
	.long 0xd44a0000                                           // 0000005A1950: D44A0000
	v_cndmask_b32_e32 v1, 0, v7, vcc_lo                        // 0000005A1954: 02020E80
	v_lshlrev_b32_e32 v15, 2, v0                               // 0000005A1958: 301E0082
	s_and_b32 s0, s0, vcc_lo                                   // 0000005A195C: 8B006A00
	s_waitcnt lgkmcnt(2)                                       // 0000005A1960: BF89FC27
	v_add_f32_e32 v9, v4, v3                                   // 0000005A1964: 06120704
	ds_bpermute_b32 v13, v14, v8                               // 0000005A1968: DACC0000 0D00080E
	ds_bpermute_b32 v14, v14, v11                              // 0000005A1970: DACC0000 0E000B0E
	s_waitcnt lgkmcnt(3)                                       // 0000005A1978: BF89FC37
	v_add_f32_e32 v10, v5, v10                                 // 0000005A197C: 06141505
	s_waitcnt lgkmcnt(2)                                       // 0000005A1980: BF89FC27
	v_add_f32_e32 v0, v6, v12                                  // 0000005A1984: 06001906
	ds_bpermute_b32 v12, v15, v10                              // 0000005A1988: DACC0000 0C000A0F
	s_waitcnt lgkmcnt(1)                                       // 0000005A1990: BF89FC17
	v_dual_add_f32 v3, v8, v13 :: v_dual_add_f32 v6, v11, v14  // 0000005A1994: C9081B08 03061D0B
	ds_bpermute_b32 v11, v15, v9                               // 0000005A199C: DACC0000 0B00090F
	ds_bpermute_b32 v4, v15, v0                                // 0000005A19A4: DACC0000 0400000F
	ds_bpermute_b32 v5, v15, v3                                // 0000005A19AC: DACC0000 0500030F
	ds_bpermute_b32 v8, v15, v6                                // 0000005A19B4: DACC0000 0800060F
	s_and_saveexec_b32 s1, s0                                  // 0000005A19BC: BE812000
	s_cbranch_execz 72                                         // 0000005A19C0: BFA50048 <_ZN7halogen12_GLOBAL__N_16k_lq6kILi5ELi16ELi1ELb0EEEvPKhPKtPvll+0xae4>
	s_waitcnt lgkmcnt(3)                                       // 0000005A19C4: BF89FC37
	v_dual_add_f32 v10, v10, v12 :: v_dual_add_f32 v9, v9, v11 // 0000005A19C8: C908190A 0A081709
	.long 0x7f163880                                           // 0000005A19D0: 7F163880
	.long 0xd73c0001                                           // 0000005A19D4: D73C0001
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 0000005A19D8: 02020281
	s_lshl_b64 s[0:1], s[12:13], 1                             // 0000005A19DC: 8480810C
	s_delay_alu instid0(VALU_DEP_3)                            // 0000005A19E0: BF870003
	.long 0x7e16398a                                           // 0000005A19E4: 7E16398A
	.long 0x7e0e3989                                           // 0000005A19E8: 7E0E3989
	.long 0x7f0e398b                                           // 0000005A19EC: 7F0E398B
	s_waitcnt lgkmcnt(0)                                       // 0000005A19F0: BF89FC07
	v_add_f32_e32 v12, v6, v8                                  // 0000005A19F4: 06181106
	.long 0xd7006a06                                           // 0000005A19F8: D7006A06
	v_cndmask_b32_e32 v1, s8, v1, vcc_lo                       // 0000005A19FC: 02020208
	v_and_b32_e32 v8, 1, v11                                   // 0000005A1A00: 36101681
	v_and_b32_e32 v13, 1, v7                                   // 0000005A1A04: 361A0E81
	v_add_co_ci_u32_e64 v7, null, s9, v2, vcc_lo               // 0000005A1A08: D5207C07 01AA0409
	v_dual_add_f32 v2, v3, v5 :: v_dual_add_f32 v5, v0, v4     // 0000005A1A10: C9080B03 02040900
	.long 0x7f00398b                                           // 0000005A1A18: 7F00398B
	v_add3_u32 v14, v10, v8, 0x7fff                            // 0000005A1A1C: D655000E 03FE110A 00007FFF
	.long 0xd7006a03                                           // 0000005A1A28: D7006A03
	v_cndmask_b32_e32 v0, v6, v0, vcc_lo                       // 0000005A1A2C: 02000106
	s_delay_alu instid0(VALU_DEP_4)                            // 0000005A1A30: BF870004
	.long 0x7e163982                                           // 0000005A1A34: 7E163982
	.long 0x7e003985                                           // 0000005A1A38: 7E003985
	v_add_co_ci_u32_e64 v4, null, s1, v7, vcc_lo               // 0000005A1A3C: D5207C04 01AA0E01
	s_lshl_b64 s[0:1], s[12:13], 2                             // 0000005A1A44: 8480820C
	v_and_b32_e32 v10, 1, v11                                  // 0000005A1A48: 36141681
	v_and_b32_e32 v11, 1, v0                                   // 0000005A1A4C: 36160081
	v_mad_u64_u32 v[0:1], null, s12, 6, v[6:7]                 // 0000005A1A50: D6FE7C00 04190C0C
	.long 0xd7006a08                                           // 0000005A1A58: D7006A08
	v_cndmask_b32_e32 v0, v6, v0, vcc_lo                       // 0000005A1A5C: 02000106
	v_add3_u32 v13, v9, v13, 0x7fff                            // 0000005A1A60: D655000D 03FE1B09 00007FFF
	v_bfe_u32 v15, v12, 16, 1                                  // 0000005A1A6C: D610000F 0205210C
	v_add_co_ci_u32_e64 v9, null, s1, v7, vcc_lo               // 0000005A1A74: D5207C09 01AA0E01
	v_add3_u32 v16, v2, v10, 0x7fff                            // 0000005A1A7C: D6550010 03FE1502 00007FFF
	v_mad_u64_u32 v[1:2], null, s13, 6, v[1:2]                 // 0000005A1A88: D6FE7C01 04050C0D
	v_add3_u32 v5, v5, v11, 0x7fff                             // 0000005A1A90: D6550005 03FE1705 00007FFF
	.long 0xd7006a0a                                           // 0000005A1A9C: D7006A0A
	v_cndmask_b32_e32 v0, v8, v0, vcc_lo                       // 0000005A1AA0: 02000108
	v_add3_u32 v2, v12, v15, 0x7fff                            // 0000005A1AA4: D6550002 03FE1F0C 00007FFF
	v_add_co_ci_u32_e64 v11, null, s1, v9, vcc_lo              // 0000005A1AB0: D5207C0B 01AA1201
	s_clause 0x4                                               // 0000005A1AB8: BF850004
	global_store_d16_hi_b16 v[6:7], v13, off                   // 0000005A1ABC: DC960000 007C0D06
	global_store_d16_hi_b16 v[3:4], v14, off                   // 0000005A1AC4: DC960000 007C0E03
	global_store_d16_hi_b16 v[8:9], v5, off                    // 0000005A1ACC: DC960000 007C0508
	global_store_d16_hi_b16 v[0:1], v16, off                   // 0000005A1AD4: DC960000 007C1000
	global_store_d16_hi_b16 v[10:11], v2, off                  // 0000005A1ADC: DC960000 007C020A
	s_nop 0                                                    // 0000005A1AE4: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 0000005A1AE8: BFB60003
	s_endpgm                                                   // 0000005A1AEC: BFB00000
		...

