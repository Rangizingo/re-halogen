0000000000fa9500 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi2ELb1ELi4ELi0EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi2ELb1ELi4ELi0EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 000000FA9500: F4100100 F8000000
	s_ashr_i32 s3, s2, 31                                      // 000000FA9508: 86039F02
	v_lshrrev_b32_e32 v2, 2, v0                                // 000000FA950C: 32040082
	s_lshl_b64 s[2:3], s[2:3], 2                               // 000000FA9510: 84828202
	v_and_b32_e32 v1, 15, v0                                   // 000000FA9514: 3602008F
	v_mov_b32_e32 v5, 0                                        // 000000FA9518: 7E0A0280
	v_lshrrev_b32_e32 v14, 6, v0                               // 000000FA951C: 321C0086
	v_and_b32_e32 v2, 60, v2                                   // 000000FA9520: 360404BC
	s_delay_alu instid0(VALU_DEP_4)                            // 000000FA9524: BF870004
	v_dual_mov_b32 v6, 0 :: v_dual_lshlrev_b32 v1, 2, v1       // 000000FA9528: CA220080 06000282
	v_bfe_u32 v15, v0, 5, 1                                    // 000000FA9530: D610000F 02050B00
	v_dual_mov_b32 v17, 0 :: v_dual_and_b32 v16, 31, v0        // 000000FA9538: CA240080 1110009F
	.long 0x7f103880                                           // 000000FA9540: 7F103880
	s_waitcnt lgkmcnt(0)                                       // 000000FA9544: BF89FC07
	s_clause 0x1                                               // 000000FA9548: BF850001
	global_load_b32 v3, v1, s[4:5]                             // 000000FA954C: DC520000 03040001
	global_load_b32 v4, v2, s[4:5]                             // 000000FA9554: DC520000 04040002
	v_mov_b32_e32 v2, s3                                       // 000000FA955C: 7E040203
	v_or_b32_e32 v1, s2, v14                                   // 000000FA9560: 38021C02
	s_add_u32 s0, s4, s14                                      // 000000FA9564: 80000E04
	s_addc_u32 s1, s5, s15                                     // 000000FA9568: 82010F05
	s_lshr_b32 s14, s11, 31                                    // 000000FA956C: 850E9F0B
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000FA9570: BF870009
	s_add_u32 s14, s10, s14                                    // 000000FA9574: 800E0E0A
	s_addc_u32 s15, s11, 0                                     // 000000FA9578: 820F800B
	s_ashr_i32 s20, s11, 31                                    // 000000FA957C: 86149F0B
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[1:2]                  // 000000FA9580: 7CA8020C
	s_lshr_b32 s20, s20, 27                                    // 000000FA9584: 85149B14
	s_ashr_i64 s[14:15], s[14:15], 1                           // 000000FA9588: 868E810E
	s_add_u32 s20, s10, s20                                    // 000000FA958C: 8014140A
	s_addc_u32 s21, s11, 0                                     // 000000FA9590: 8215800B
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 000000FA9594: 02020280
	s_lshr_b64 s[20:21], s[20:21], 5                           // 000000FA9598: 85948514
	v_cndmask_b32_e64 v7, 0, s3, vcc_lo                        // 000000FA959C: D5010007 01A80680
	s_add_i32 s21, s20, 1                                      // 000000FA95A4: 81158114
	s_delay_alu instid0(VALU_DEP_2)                            // 000000FA95A8: BF870002
	.long 0xd72c0002                                           // 000000FA95AC: D72C0002
	v_cndmask_b32_e32 v1, s19, v1, vcc_lo                      // 000000FA95B0: 02020213
	s_lshr_b32 s19, s21, 31                                    // 000000FA95B4: 85139F15
	.long 0xd72c000d                                           // 000000FA95B8: D72C000D
	v_cndmask_b32_e32 v0, v1, v15, vcc_lo                      // 000000FA95BC: 02001F01
	s_add_i32 s21, s21, s19                                    // 000000FA95C0: 81151315
	v_mad_u64_u32 v[9:10], null, v1, s14, s[0:1]               // 000000FA95C4: D6FE7C09 00001D01
	s_ashr_i32 s15, s21, 1                                     // 000000FA95CC: 860F8115
	s_add_u32 s0, s4, s16                                      // 000000FA95D0: 80001004
	.long 0xd72c0012                                           // 000000FA95D4: D72C0012
	v_cndmask_b32_e32 v1, s15, v15, vcc_lo                     // 000000FA95D8: 02021E0F
	s_addc_u32 s1, s5, s17                                     // 000000FA95DC: 82011105
	.long 0xd72c0014                                           // 000000FA95E0: D72C0014
	v_cndmask_b32_e32 v0, v7, v14, vcc_lo                      // 000000FA95E4: 02001D07
	.long 0xd72c0015                                           // 000000FA95E8: D72C0015
	v_cndmask_b32_e32 v1, s18, v7, vcc_lo                      // 000000FA95EC: 02020E12
	v_mov_b32_e32 v29, 0                                       // 000000FA95F0: 7E3A0280
	v_mov_b32_e32 v7, 0                                        // 000000FA95F4: 7E0E0280
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 000000FA95F8: BF870154
	v_add3_u32 v10, v20, v10, v13                              // 000000FA95FC: D655000A 04361514
	s_waitcnt vmcnt(1)                                         // 000000FA9604: BF8907F7
	v_bfe_u32 v11, v3, 16, 1                                   // 000000FA9608: D610000B 02052103
	s_waitcnt vmcnt(0)                                         // 000000FA9610: BF8903F7
	v_bfe_u32 v19, v4, 16, 1                                   // 000000FA9614: D6100013 02052104
	v_add3_u32 v3, v3, v11, 0x7fff                             // 000000FA961C: D6550003 03FE1703 00007FFF
	v_mad_u64_u32 v[11:12], null, s18, v1, s[0:1]              // 000000FA9628: D6FE7C0B 00020212
	v_add_nc_u32_e32 v1, s15, v18                              // 000000FA9630: 4A02240F
	s_delay_alu instid0(VALU_DEP_4)                            // 000000FA9634: BF870004
	v_add3_u32 v4, v4, v19, 0x7fff                             // 000000FA9638: D6550004 03FE2704 00007FFF
	v_add_nc_u32_e32 v18, v18, v16                             // 000000FA9644: 4A242112
	.long 0x7e103983                                           // 000000FA9648: 7E103983
	v_lshlrev_b32_e32 v3, 2, v0                                // 000000FA964C: 30060082
	v_min_i32_e32 v19, s20, v1                                 // 000000FA9650: 22260214
	v_add3_u32 v20, v2, v12, v21                               // 000000FA9654: D6550014 04561902
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000FA965C: BF870224
	v_and_or_b32 v1, 0xffff0000, v4, v8                        // 000000FA9660: D6570001 042208FF FFFF0000
	v_mov_b32_e32 v8, 0                                        // 000000FA966C: 7E100280
	v_cmp_lt_i32_e32 vcc_lo, v18, v19                          // 000000FA9670: 7C822712
	ds_store_b32 v3, v1                                        // 000000FA9674: D8340000 00000103
	s_waitcnt lgkmcnt(0)                                       // 000000FA967C: BF89FC07
	s_barrier                                                  // 000000FA9680: BFBD0000
	buffer_gl0_inv                                             // 000000FA9684: E0AC0000 00000000
	s_and_saveexec_b32 s1, vcc_lo                              // 000000FA968C: BE81206A
	s_cbranch_execz 21                                         // 000000FA9690: BFA50015 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi2ELb1ELi4ELi0EEEvPKhPKtPvlllllS6_f+0x1e8>
	v_lshlrev_b32_e32 v1, 1, v18                               // 000000FA9694: 30022481
	v_lshlrev_b32_e32 v3, 4, v18                               // 000000FA9698: 30062484
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000FA969C: BF870112
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000FA96A0: 3404029F
	v_ashrrev_i32_e32 v4, 31, v3                               // 000000FA96A4: 3408069F
	.long 0xd7000001                                           // 000000FA96A8: D7000001
	v_cndmask_b32_e32 v1, v11, v1, vcc_lo                      // 000000FA96AC: 0202030B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FA96B0: BF8700A1
	v_add_co_ci_u32_e64 v2, null, v20, v2, s0                  // 000000FA96B4: D5207C02 00020514
	.long 0xd7000003                                           // 000000FA96BC: D7000003
	v_cndmask_b32_e32 v1, v9, v3, vcc_lo                       // 000000FA96C0: 02020709
	v_add_co_ci_u32_e64 v4, null, v10, v4, s0                  // 000000FA96C4: D5207C04 0002090A
	s_clause 0x1                                               // 000000FA96CC: BF850001
	global_load_d16_b16 v1, v[1:2], off                        // 000000FA96D0: DC820000 017C0001
	global_load_b128 v[5:8], v[3:4], off                       // 000000FA96D8: DC5E0000 057C0003
	s_waitcnt vmcnt(1)                                         // 000000FA96E0: BF8907F7
	v_cvt_f32_f16_e32 v29, v1                                  // 000000FA96E4: 7E3A1701
	s_or_b32 exec_lo, exec_lo, s1                              // 000000FA96E8: 8C7E017E
	v_dual_mov_b32 v22, 0 :: v_dual_mov_b32 v23, 0             // 000000FA96EC: CA100080 16160080
	v_dual_mov_b32 v24, 0 :: v_dual_mov_b32 v25, 0             // 000000FA96F4: CA100080 18180080
	v_dual_mov_b32 v26, 0 :: v_dual_mov_b32 v21, 0             // 000000FA96FC: CA100080 1A140080
	s_and_saveexec_b32 s1, vcc_lo                              // 000000FA9704: BE81206A
	s_cbranch_execz 579                                        // 000000FA9708: BFA50243 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi2ELb1ELi4ELi0EEEvPKhPKtPvlllllS6_f+0xb18>
	v_dual_mov_b32 v26, 0 :: v_dual_add_nc_u32 v1, 32, v18     // 000000FA970C: CA200080 1A0024A0
	v_dual_mov_b32 v21, 0 :: v_dual_lshlrev_b32 v12, 5, v18    // 000000FA9714: CA220080 150C2485
	v_dual_mov_b32 v23, 0 :: v_dual_mov_b32 v22, 0             // 000000FA971C: CA100080 17160080
	s_delay_alu instid0(VALU_DEP_3)                            // 000000FA9724: BF870003
	v_dual_mov_b32 v24, 0 :: v_dual_lshlrev_b32 v27, 4, v1     // 000000FA9728: CA220080 181A0284
	v_dual_mov_b32 v25, 0 :: v_dual_lshlrev_b32 v28, 1, v1     // 000000FA9730: CA220080 191C0281
	v_dual_mov_b32 v17, 0 :: v_dual_mov_b32 v30, v29           // 000000FA9738: CA100080 111E011D
	s_mul_i32 s0, s11, 6                                       // 000000FA9740: 9600860B
	s_mul_hi_u32 s14, s10, 6                                   // 000000FA9744: 968E860A
	s_lshl_b64 s[4:5], s[10:11], 2                             // 000000FA9748: 8484820A
	s_add_i32 s14, s14, s0                                     // 000000FA974C: 810E000E
	s_mul_i32 s16, s10, 6                                      // 000000FA9750: 9610860A
	s_mov_b32 s15, 0                                           // 000000FA9754: BE8F0080
	s_lshl_b64 s[10:11], s[10:11], 1                           // 000000FA9758: 848A810A
	s_branch 526                                               // 000000FA975C: BFA0020E <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi2ELb1ELi4ELi0EEEvPKhPKtPvlllllS6_f+0xa98>
	s_or_b32 exec_lo, exec_lo, s17                             // 000000FA9760: 8C7E117E
	v_and_b32_e32 v13, 0xff, v5                                // 000000FA9764: 361A0AFF 000000FF
	s_and_b32 s0, exec_lo, vcc_lo                              // 000000FA976C: 8B006A7E
	v_add_nc_u32_e32 v27, 0x200, v27                           // 000000FA9770: 4A3636FF 00000200
	s_or_b32 s15, s0, s15                                      // 000000FA9778: 8C0F0F00
	v_add_nc_u32_e32 v28, 64, v28                              // 000000FA977C: 4A3838C0
	v_lshlrev_b32_e32 v13, 2, v13                              // 000000FA9780: 301A1A82
	ds_load_b32 v47, v13                                       // 000000FA9784: D8D80000 2F00000D
	v_lshrrev_b32_e32 v13, 6, v5                               // 000000FA978C: 321A0A86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000FA9790: BF870141
	v_and_b32_e32 v13, 0x3fc, v13                              // 000000FA9794: 361A1AFF 000003FC
	ds_load_b32 v48, v13                                       // 000000FA979C: D8D80000 3000000D
	v_lshrrev_b32_e32 v13, 14, v5                              // 000000FA97A4: 321A0A8E
	v_lshrrev_b32_e32 v5, 22, v5                               // 000000FA97A8: 320A0A96
	v_and_b32_e32 v13, 0x3fc, v13                              // 000000FA97AC: 361A1AFF 000003FC
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 000000FA97B4: BF870152
	v_and_b32_e32 v5, 0x3fc, v5                                // 000000FA97B8: 360A0AFF 000003FC
	ds_load_b32 v49, v13                                       // 000000FA97C0: D8D80000 3100000D
	ds_load_b32 v50, v5                                        // 000000FA97C8: D8D80000 32000005
	v_and_b32_e32 v5, 0xff, v6                                 // 000000FA97D0: 360A0CFF 000000FF
	v_ashrrev_i32_e32 v13, 31, v12                             // 000000FA97D8: 341A189F
	v_lshlrev_b32_e32 v5, 2, v5                                // 000000FA97DC: 300A0A82
	ds_load_b32 v51, v5                                        // 000000FA97E0: D8D80000 33000005
	v_lshrrev_b32_e32 v5, 6, v6                                // 000000FA97E8: 320A0C86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000FA97EC: BF8700B1
	v_and_b32_e32 v5, 0x3fc, v5                                // 000000FA97F0: 360A0AFF 000003FC
	ds_load_b32 v52, v5                                        // 000000FA97F8: D8D80000 34000005
	v_lshrrev_b32_e32 v5, 14, v6                               // 000000FA9800: 320A0C8E
	v_and_b32_e32 v5, 0x3fc, v5                                // 000000FA9804: 360A0AFF 000003FC
	ds_load_b32 v53, v5                                        // 000000FA980C: D8D80000 35000005
	v_lshrrev_b32_e32 v5, 22, v6                               // 000000FA9814: 320A0C96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000FA9818: BF8700B1
	v_and_b32_e32 v5, 0x3fc, v5                                // 000000FA981C: 360A0AFF 000003FC
	ds_load_b32 v54, v5                                        // 000000FA9824: D8D80000 36000005
	v_and_b32_e32 v5, 0xff, v7                                 // 000000FA982C: 360A0EFF 000000FF
	v_lshlrev_b32_e32 v5, 2, v5                                // 000000FA9834: 300A0A82
	ds_load_b32 v55, v5                                        // 000000FA9838: D8D80000 37000005
	v_lshrrev_b32_e32 v5, 6, v7                                // 000000FA9840: 320A0E86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000FA9844: BF8700B1
	v_and_b32_e32 v5, 0x3fc, v5                                // 000000FA9848: 360A0AFF 000003FC
	ds_load_b32 v56, v5                                        // 000000FA9850: D8D80000 38000005
	v_lshrrev_b32_e32 v5, 14, v7                               // 000000FA9858: 320A0E8E
	v_and_b32_e32 v5, 0x3fc, v5                                // 000000FA985C: 360A0AFF 000003FC
	ds_load_b32 v57, v5                                        // 000000FA9864: D8D80000 39000005
	v_lshrrev_b32_e32 v5, 22, v7                               // 000000FA986C: 320A0E96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000FA9870: BF8700B1
	v_and_b32_e32 v5, 0x3fc, v5                                // 000000FA9874: 360A0AFF 000003FC
	ds_load_b32 v58, v5                                        // 000000FA987C: D8D80000 3A000005
	v_and_b32_e32 v5, 0xff, v8                                 // 000000FA9884: 360A10FF 000000FF
	v_lshlrev_b32_e32 v5, 2, v5                                // 000000FA988C: 300A0A82
	ds_load_b32 v59, v5                                        // 000000FA9890: D8D80000 3B000005
	v_lshrrev_b32_e32 v5, 6, v8                                // 000000FA9898: 320A1086
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000FA989C: BF8700B1
	v_and_b32_e32 v5, 0x3fc, v5                                // 000000FA98A0: 360A0AFF 000003FC
	ds_load_b32 v60, v5                                        // 000000FA98A8: D8D80000 3C000005
	v_lshrrev_b32_e32 v5, 14, v8                               // 000000FA98B0: 320A108E
	v_and_b32_e32 v5, 0x3fc, v5                                // 000000FA98B4: 360A0AFF 000003FC
	ds_load_b32 v61, v5                                        // 000000FA98BC: D8D80000 3D000005
	v_lshrrev_b32_e32 v5, 22, v8                               // 000000FA98C4: 320A1096
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000FA98C8: BF870141
	v_and_b32_e32 v5, 0x3fc, v5                                // 000000FA98CC: 360A0AFF 000003FC
	ds_load_b32 v62, v5                                        // 000000FA98D4: D8D80000 3E000005
	.long 0xd73c0005                                           // 000000FA98DC: D73C0005
	v_cndmask_b32_e32 v1, 1, v12, vcc_lo                       // 000000FA98E0: 02021881
	v_add_nc_u32_e32 v12, 0x400, v12                           // 000000FA98E4: 4A1818FF 00000400
	.long 0xd7006a2b                                           // 000000FA98EC: D7006A2B
	v_cndmask_b32_e32 v1, s6, v5, vcc_lo                       // 000000FA98F0: 02020A06
	s_delay_alu instid0(VALU_DEP_1)                            // 000000FA98F4: BF870001
	v_add_co_ci_u32_e64 v44, null, s7, v6, vcc_lo              // 000000FA98F8: D5207C2C 01AA0C07
	s_clause 0x3                                               // 000000FA9900: BF850003
	global_load_b128 v[5:8], v[43:44], off                     // 000000FA9904: DC5E0000 057C002B
	global_load_b128 v[31:34], v[43:44], off offset:16         // 000000FA990C: DC5E0010 1F7C002B
	global_load_b128 v[35:38], v[43:44], off offset:32         // 000000FA9914: DC5E0020 237C002B
	global_load_b128 v[39:42], v[43:44], off offset:48         // 000000FA991C: DC5E0030 277C002B
	s_waitcnt vmcnt(3) lgkmcnt(15)                             // 000000FA9924: BF890CF7
	v_dot2_f32_bf16 v5, v5, v47, 0                             // 000000FA9928: CC1A4005 1A025F05
	s_waitcnt lgkmcnt(14)                                      // 000000FA9930: BF89FCE7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FA9934: BF8700A1
	v_dot2_f32_bf16 v5, v6, v48, v5                            // 000000FA9938: CC1A4005 1C166106
	s_waitcnt lgkmcnt(13)                                      // 000000FA9940: BF89FCD7
	v_dot2_f32_bf16 v5, v7, v49, v5                            // 000000FA9944: CC1A4005 1C166307
	s_waitcnt lgkmcnt(12)                                      // 000000FA994C: BF89FCC7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FA9950: BF8700A1
	v_dot2_f32_bf16 v5, v8, v50, v5                            // 000000FA9954: CC1A4005 1C166508
	s_waitcnt vmcnt(2) lgkmcnt(11)                             // 000000FA995C: BF8908B7
	v_dot2_f32_bf16 v5, v31, v51, v5                           // 000000FA9960: CC1A4005 1C16671F
	s_waitcnt lgkmcnt(10)                                      // 000000FA9968: BF89FCA7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FA996C: BF8700A1
	v_dot2_f32_bf16 v5, v32, v52, v5                           // 000000FA9970: CC1A4005 1C166920
	s_waitcnt lgkmcnt(9)                                       // 000000FA9978: BF89FC97
	v_dot2_f32_bf16 v5, v33, v53, v5                           // 000000FA997C: CC1A4005 1C166B21
	s_waitcnt lgkmcnt(8)                                       // 000000FA9984: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FA9988: BF8700A1
	v_dot2_f32_bf16 v5, v34, v54, v5                           // 000000FA998C: CC1A4005 1C166D22
	s_waitcnt vmcnt(1) lgkmcnt(7)                              // 000000FA9994: BF890477
	v_dot2_f32_bf16 v5, v35, v55, v5                           // 000000FA9998: CC1A4005 1C166F23
	s_waitcnt lgkmcnt(6)                                       // 000000FA99A0: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FA99A4: BF8700A1
	v_dot2_f32_bf16 v5, v36, v56, v5                           // 000000FA99A8: CC1A4005 1C167124
	s_waitcnt lgkmcnt(5)                                       // 000000FA99B0: BF89FC57
	v_dot2_f32_bf16 v5, v37, v57, v5                           // 000000FA99B4: CC1A4005 1C167325
	s_waitcnt lgkmcnt(4)                                       // 000000FA99BC: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FA99C0: BF8700A1
	v_dot2_f32_bf16 v5, v38, v58, v5                           // 000000FA99C4: CC1A4005 1C167526
	s_waitcnt vmcnt(0) lgkmcnt(3)                              // 000000FA99CC: BF890037
	v_dot2_f32_bf16 v5, v39, v59, v5                           // 000000FA99D0: CC1A4005 1C167727
	.long 0xd7006a27                                           // 000000FA99D8: D7006A27
	v_cndmask_b32_e32 v0, v43, v10, vcc_lo                     // 000000FA99DC: 0200152B
	s_waitcnt lgkmcnt(2)                                       // 000000FA99E0: BF89FC27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000FA99E4: BF8701C2
	v_dot2_f32_bf16 v5, v40, v60, v5                           // 000000FA99E8: CC1A4005 1C167928
	v_add_co_ci_u32_e64 v40, null, s11, v44, vcc_lo            // 000000FA99F0: D5207C28 01AA580B
	.long 0xd7006a2d                                           // 000000FA99F8: D7006A2D
	v_cndmask_b32_e32 v0, v43, v4, vcc_lo                      // 000000FA99FC: 0200092B
	s_waitcnt lgkmcnt(1)                                       // 000000FA9A00: BF89FC17
	v_dot2_f32_bf16 v5, v41, v61, v5                           // 000000FA9A04: CC1A4005 1C167B29
	v_add_co_ci_u32_e64 v46, null, s5, v44, vcc_lo             // 000000FA9A0C: D5207C2E 01AA5805
	.long 0xd7006a2b                                           // 000000FA9A14: D7006A2B
	v_cndmask_b32_e32 v0, v43, v16, vcc_lo                     // 000000FA9A18: 0200212B
	s_waitcnt lgkmcnt(0)                                       // 000000FA9A1C: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000FA9A20: BF870123
	v_dot2_f32_bf16 v5, v42, v62, v5                           // 000000FA9A24: CC1A4005 1C167D2A
	v_add_co_ci_u32_e64 v44, null, s14, v44, vcc_lo            // 000000FA9A2C: D5207C2C 01AA580E
	v_fmac_f32_e32 v21, v29, v5                                // 000000FA9A34: 562A0B1D
	s_clause 0x3                                               // 000000FA9A38: BF850003
	global_load_b128 v[5:8], v[39:40], off                     // 000000FA9A3C: DC5E0000 057C0027
	global_load_b128 v[31:34], v[39:40], off offset:16         // 000000FA9A44: DC5E0010 1F7C0027
	global_load_b128 v[35:38], v[39:40], off offset:32         // 000000FA9A4C: DC5E0020 237C0027
	global_load_b128 v[39:42], v[39:40], off offset:48         // 000000FA9A54: DC5E0030 277C0027
	s_waitcnt vmcnt(3)                                         // 000000FA9A5C: BF890FF7
	v_dot2_f32_bf16 v5, v5, v47, 0                             // 000000FA9A60: CC1A4005 1A025F05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FA9A68: BF870091
	v_dot2_f32_bf16 v5, v6, v48, v5                            // 000000FA9A6C: CC1A4005 1C166106
	v_dot2_f32_bf16 v5, v7, v49, v5                            // 000000FA9A74: CC1A4005 1C166307
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FA9A7C: BF8700A1
	v_dot2_f32_bf16 v5, v8, v50, v5                            // 000000FA9A80: CC1A4005 1C166508
	s_waitcnt vmcnt(2)                                         // 000000FA9A88: BF890BF7
	v_dot2_f32_bf16 v5, v31, v51, v5                           // 000000FA9A8C: CC1A4005 1C16671F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FA9A94: BF870091
	v_dot2_f32_bf16 v5, v32, v52, v5                           // 000000FA9A98: CC1A4005 1C166920
	v_dot2_f32_bf16 v5, v33, v53, v5                           // 000000FA9AA0: CC1A4005 1C166B21
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FA9AA8: BF8700A1
	v_dot2_f32_bf16 v5, v34, v54, v5                           // 000000FA9AAC: CC1A4005 1C166D22
	s_waitcnt vmcnt(1)                                         // 000000FA9AB4: BF8907F7
	v_dot2_f32_bf16 v5, v35, v55, v5                           // 000000FA9AB8: CC1A4005 1C166F23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FA9AC0: BF870091
	v_dot2_f32_bf16 v5, v36, v56, v5                           // 000000FA9AC4: CC1A4005 1C167124
	v_dot2_f32_bf16 v5, v37, v57, v5                           // 000000FA9ACC: CC1A4005 1C167325
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FA9AD4: BF8700A1
	v_dot2_f32_bf16 v5, v38, v58, v5                           // 000000FA9AD8: CC1A4005 1C167526
	s_waitcnt vmcnt(0)                                         // 000000FA9AE0: BF8903F7
	v_dot2_f32_bf16 v5, v39, v59, v5                           // 000000FA9AE4: CC1A4005 1C167727
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FA9AEC: BF870091
	v_dot2_f32_bf16 v5, v40, v60, v5                           // 000000FA9AF0: CC1A4005 1C167928
	v_dot2_f32_bf16 v5, v41, v61, v5                           // 000000FA9AF8: CC1A4005 1C167B29
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FA9B00: BF870091
	v_dot2_f32_bf16 v5, v42, v62, v5                           // 000000FA9B04: CC1A4005 1C167D2A
	v_fmac_f32_e32 v26, v29, v5                                // 000000FA9B0C: 56340B1D
	s_clause 0x3                                               // 000000FA9B10: BF850003
	global_load_b128 v[5:8], v[45:46], off                     // 000000FA9B14: DC5E0000 057C002D
	global_load_b128 v[31:34], v[45:46], off offset:16         // 000000FA9B1C: DC5E0010 1F7C002D
	global_load_b128 v[35:38], v[45:46], off offset:32         // 000000FA9B24: DC5E0020 237C002D
	global_load_b128 v[39:42], v[45:46], off offset:48         // 000000FA9B2C: DC5E0030 277C002D
	.long 0xd7006a2d                                           // 000000FA9B34: D7006A2D
	v_cndmask_b32_e32 v0, v45, v4, vcc_lo                      // 000000FA9B38: 0200092D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000FA9B3C: BF8700B1
	v_add_co_ci_u32_e64 v46, null, s5, v46, vcc_lo             // 000000FA9B40: D5207C2E 01AA5C05
	s_waitcnt vmcnt(3)                                         // 000000FA9B48: BF890FF7
	v_dot2_f32_bf16 v5, v5, v47, 0                             // 000000FA9B4C: CC1A4005 1A025F05
	v_dot2_f32_bf16 v5, v6, v48, v5                            // 000000FA9B54: CC1A4005 1C166106
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FA9B5C: BF870091
	v_dot2_f32_bf16 v5, v7, v49, v5                            // 000000FA9B60: CC1A4005 1C166307
	v_dot2_f32_bf16 v5, v8, v50, v5                            // 000000FA9B68: CC1A4005 1C166508
	s_waitcnt vmcnt(2)                                         // 000000FA9B70: BF890BF7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FA9B74: BF870091
	v_dot2_f32_bf16 v5, v31, v51, v5                           // 000000FA9B78: CC1A4005 1C16671F
	v_dot2_f32_bf16 v5, v32, v52, v5                           // 000000FA9B80: CC1A4005 1C166920
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FA9B88: BF870091
	v_dot2_f32_bf16 v5, v33, v53, v5                           // 000000FA9B8C: CC1A4005 1C166B21
	v_dot2_f32_bf16 v5, v34, v54, v5                           // 000000FA9B94: CC1A4005 1C166D22
	s_waitcnt vmcnt(1)                                         // 000000FA9B9C: BF8907F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FA9BA0: BF870091
	v_dot2_f32_bf16 v5, v35, v55, v5                           // 000000FA9BA4: CC1A4005 1C166F23
	v_dot2_f32_bf16 v5, v36, v56, v5                           // 000000FA9BAC: CC1A4005 1C167124
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FA9BB4: BF870091
	v_dot2_f32_bf16 v5, v37, v57, v5                           // 000000FA9BB8: CC1A4005 1C167325
	v_dot2_f32_bf16 v5, v38, v58, v5                           // 000000FA9BC0: CC1A4005 1C167526
	s_waitcnt vmcnt(0)                                         // 000000FA9BC8: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FA9BCC: BF870091
	v_dot2_f32_bf16 v5, v39, v59, v5                           // 000000FA9BD0: CC1A4005 1C167727
	v_dot2_f32_bf16 v5, v40, v60, v5                           // 000000FA9BD8: CC1A4005 1C167928
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FA9BE0: BF870091
	v_dot2_f32_bf16 v5, v41, v61, v5                           // 000000FA9BE4: CC1A4005 1C167B29
	v_dot2_f32_bf16 v5, v42, v62, v5                           // 000000FA9BEC: CC1A4005 1C167D2A
	s_delay_alu instid0(VALU_DEP_1)                            // 000000FA9BF4: BF870001
	v_fmac_f32_e32 v25, v29, v5                                // 000000FA9BF8: 56320B1D
	s_clause 0x3                                               // 000000FA9BFC: BF850003
	global_load_b128 v[5:8], v[43:44], off                     // 000000FA9C00: DC5E0000 057C002B
	global_load_b128 v[31:34], v[43:44], off offset:16         // 000000FA9C08: DC5E0010 1F7C002B
	global_load_b128 v[35:38], v[43:44], off offset:32         // 000000FA9C10: DC5E0020 237C002B
	global_load_b128 v[39:42], v[43:44], off offset:48         // 000000FA9C18: DC5E0030 277C002B
	s_waitcnt vmcnt(3)                                         // 000000FA9C20: BF890FF7
	v_dot2_f32_bf16 v5, v5, v47, 0                             // 000000FA9C24: CC1A4005 1A025F05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FA9C2C: BF870091
	v_dot2_f32_bf16 v5, v6, v48, v5                            // 000000FA9C30: CC1A4005 1C166106
	v_dot2_f32_bf16 v5, v7, v49, v5                            // 000000FA9C38: CC1A4005 1C166307
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FA9C40: BF8700A1
	v_dot2_f32_bf16 v5, v8, v50, v5                            // 000000FA9C44: CC1A4005 1C166508
	s_waitcnt vmcnt(2)                                         // 000000FA9C4C: BF890BF7
	v_dot2_f32_bf16 v5, v31, v51, v5                           // 000000FA9C50: CC1A4005 1C16671F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FA9C58: BF870091
	v_dot2_f32_bf16 v5, v32, v52, v5                           // 000000FA9C5C: CC1A4005 1C166920
	v_dot2_f32_bf16 v5, v33, v53, v5                           // 000000FA9C64: CC1A4005 1C166B21
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FA9C6C: BF8700A1
	v_dot2_f32_bf16 v5, v34, v54, v5                           // 000000FA9C70: CC1A4005 1C166D22
	s_waitcnt vmcnt(1)                                         // 000000FA9C78: BF8907F7
	v_dot2_f32_bf16 v5, v35, v55, v5                           // 000000FA9C7C: CC1A4005 1C166F23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FA9C84: BF870091
	v_dot2_f32_bf16 v5, v36, v56, v5                           // 000000FA9C88: CC1A4005 1C167124
	v_dot2_f32_bf16 v5, v37, v57, v5                           // 000000FA9C90: CC1A4005 1C167325
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FA9C98: BF8700A1
	v_dot2_f32_bf16 v5, v38, v58, v5                           // 000000FA9C9C: CC1A4005 1C167526
	s_waitcnt vmcnt(0)                                         // 000000FA9CA4: BF8903F7
	v_dot2_f32_bf16 v5, v39, v59, v5                           // 000000FA9CA8: CC1A4005 1C167727
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FA9CB0: BF870091
	v_dot2_f32_bf16 v5, v40, v60, v5                           // 000000FA9CB4: CC1A4005 1C167928
	v_dot2_f32_bf16 v5, v41, v61, v5                           // 000000FA9CBC: CC1A4005 1C167B29
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FA9CC4: BF870091
	v_dot2_f32_bf16 v5, v42, v62, v5                           // 000000FA9CC8: CC1A4005 1C167D2A
	v_fmac_f32_e32 v24, v29, v5                                // 000000FA9CD0: 56300B1D
	s_clause 0x3                                               // 000000FA9CD4: BF850003
	global_load_b128 v[5:8], v[45:46], off                     // 000000FA9CD8: DC5E0000 057C002D
	global_load_b128 v[31:34], v[45:46], off offset:16         // 000000FA9CE0: DC5E0010 1F7C002D
	global_load_b128 v[35:38], v[45:46], off offset:32         // 000000FA9CE8: DC5E0020 237C002D
	global_load_b128 v[39:42], v[45:46], off offset:48         // 000000FA9CF0: DC5E0030 277C002D
	s_waitcnt vmcnt(3)                                         // 000000FA9CF8: BF890FF7
	v_dot2_f32_bf16 v5, v5, v47, 0                             // 000000FA9CFC: CC1A4005 1A025F05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FA9D04: BF870091
	v_dot2_f32_bf16 v5, v6, v48, v5                            // 000000FA9D08: CC1A4005 1C166106
	v_dot2_f32_bf16 v5, v7, v49, v5                            // 000000FA9D10: CC1A4005 1C166307
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FA9D18: BF8700A1
	v_dot2_f32_bf16 v5, v8, v50, v5                            // 000000FA9D1C: CC1A4005 1C166508
	s_waitcnt vmcnt(2)                                         // 000000FA9D24: BF890BF7
	v_dot2_f32_bf16 v5, v31, v51, v5                           // 000000FA9D28: CC1A4005 1C16671F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FA9D30: BF870091
	v_dot2_f32_bf16 v5, v32, v52, v5                           // 000000FA9D34: CC1A4005 1C166920
	v_dot2_f32_bf16 v5, v33, v53, v5                           // 000000FA9D3C: CC1A4005 1C166B21
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FA9D44: BF8700A1
	v_dot2_f32_bf16 v5, v34, v54, v5                           // 000000FA9D48: CC1A4005 1C166D22
	s_waitcnt vmcnt(1)                                         // 000000FA9D50: BF8907F7
	v_dot2_f32_bf16 v5, v35, v55, v5                           // 000000FA9D54: CC1A4005 1C166F23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FA9D5C: BF870091
	v_dot2_f32_bf16 v5, v36, v56, v5                           // 000000FA9D60: CC1A4005 1C167124
	v_dot2_f32_bf16 v5, v37, v57, v5                           // 000000FA9D68: CC1A4005 1C167325
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FA9D70: BF8700A1
	v_dot2_f32_bf16 v5, v38, v58, v5                           // 000000FA9D74: CC1A4005 1C167526
	s_waitcnt vmcnt(0)                                         // 000000FA9D7C: BF8903F7
	v_dot2_f32_bf16 v5, v39, v59, v5                           // 000000FA9D80: CC1A4005 1C167727
	.long 0xd7006a27                                           // 000000FA9D88: D7006A27
	v_cndmask_b32_e32 v0, v43, v4, vcc_lo                      // 000000FA9D8C: 0200092B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000FA9D90: BF870122
	v_dot2_f32_bf16 v5, v40, v60, v5                           // 000000FA9D94: CC1A4005 1C167928
	v_add_co_ci_u32_e64 v40, null, s5, v44, vcc_lo             // 000000FA9D9C: D5207C28 01AA5805
	v_dot2_f32_bf16 v5, v41, v61, v5                           // 000000FA9DA4: CC1A4005 1C167B29
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FA9DAC: BF870091
	v_dot2_f32_bf16 v5, v42, v62, v5                           // 000000FA9DB0: CC1A4005 1C167D2A
	v_fmac_f32_e32 v23, v29, v5                                // 000000FA9DB8: 562E0B1D
	s_clause 0x3                                               // 000000FA9DBC: BF850003
	global_load_b128 v[5:8], v[39:40], off                     // 000000FA9DC0: DC5E0000 057C0027
	global_load_b128 v[31:34], v[39:40], off offset:16         // 000000FA9DC8: DC5E0010 1F7C0027
	global_load_b128 v[35:38], v[39:40], off offset:32         // 000000FA9DD0: DC5E0020 237C0027
	global_load_b128 v[39:42], v[39:40], off offset:48         // 000000FA9DD8: DC5E0030 277C0027
	s_waitcnt vmcnt(3)                                         // 000000FA9DE0: BF890FF7
	v_dot2_f32_bf16 v5, v5, v47, 0                             // 000000FA9DE4: CC1A4005 1A025F05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FA9DEC: BF870091
	v_dot2_f32_bf16 v5, v6, v48, v5                            // 000000FA9DF0: CC1A4005 1C166106
	v_dot2_f32_bf16 v5, v7, v49, v5                            // 000000FA9DF8: CC1A4005 1C166307
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FA9E00: BF8700A1
	v_dot2_f32_bf16 v5, v8, v50, v5                            // 000000FA9E04: CC1A4005 1C166508
	s_waitcnt vmcnt(2)                                         // 000000FA9E0C: BF890BF7
	v_dot2_f32_bf16 v5, v31, v51, v5                           // 000000FA9E10: CC1A4005 1C16671F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FA9E18: BF870091
	v_dot2_f32_bf16 v5, v32, v52, v5                           // 000000FA9E1C: CC1A4005 1C166920
	v_dot2_f32_bf16 v5, v33, v53, v5                           // 000000FA9E24: CC1A4005 1C166B21
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FA9E2C: BF8700A1
	v_dot2_f32_bf16 v5, v34, v54, v5                           // 000000FA9E30: CC1A4005 1C166D22
	s_waitcnt vmcnt(1)                                         // 000000FA9E38: BF8907F7
	v_dot2_f32_bf16 v5, v35, v55, v5                           // 000000FA9E3C: CC1A4005 1C166F23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FA9E44: BF870091
	v_dot2_f32_bf16 v5, v36, v56, v5                           // 000000FA9E48: CC1A4005 1C167124
	v_dot2_f32_bf16 v5, v37, v57, v5                           // 000000FA9E50: CC1A4005 1C167325
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FA9E58: BF8700A1
	v_dot2_f32_bf16 v5, v38, v58, v5                           // 000000FA9E5C: CC1A4005 1C167526
	s_waitcnt vmcnt(0)                                         // 000000FA9E64: BF8903F7
	v_dot2_f32_bf16 v5, v39, v59, v5                           // 000000FA9E68: CC1A4005 1C167727
	.long 0xd7006a27                                           // 000000FA9E70: D7006A27
	v_cndmask_b32_e32 v0, v45, v4, vcc_lo                      // 000000FA9E74: 0200092D
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000FA9E78: BF870122
	v_dot2_f32_bf16 v5, v40, v60, v5                           // 000000FA9E7C: CC1A4005 1C167928
	v_add_co_ci_u32_e64 v40, null, s5, v46, vcc_lo             // 000000FA9E84: D5207C28 01AA5C05
	v_dot2_f32_bf16 v5, v41, v61, v5                           // 000000FA9E8C: CC1A4005 1C167B29
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FA9E94: BF870091
	v_dot2_f32_bf16 v5, v42, v62, v5                           // 000000FA9E98: CC1A4005 1C167D2A
	v_fmac_f32_e32 v22, v29, v5                                // 000000FA9EA0: 562C0B1D
	s_clause 0x3                                               // 000000FA9EA4: BF850003
	global_load_b128 v[5:8], v[39:40], off                     // 000000FA9EA8: DC5E0000 057C0027
	global_load_b128 v[31:34], v[39:40], off offset:16         // 000000FA9EB0: DC5E0010 1F7C0027
	global_load_b128 v[35:38], v[39:40], off offset:32         // 000000FA9EB8: DC5E0020 237C0027
	global_load_b128 v[39:42], v[39:40], off offset:48         // 000000FA9EC0: DC5E0030 277C0027
	s_waitcnt vmcnt(3)                                         // 000000FA9EC8: BF890FF7
	v_dot2_f32_bf16 v5, v5, v47, 0                             // 000000FA9ECC: CC1A4005 1A025F05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000FA9ED4: BF870121
	v_dot2_f32_bf16 v5, v6, v48, v5                            // 000000FA9ED8: CC1A4005 1C166106
	v_mov_b32_e32 v6, v2                                       // 000000FA9EE0: 7E0C0302
	v_dot2_f32_bf16 v5, v7, v49, v5                            // 000000FA9EE4: CC1A4005 1C166307
	v_mov_b32_e32 v7, v3                                       // 000000FA9EEC: 7E0E0303
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000FA9EF0: BF870132
	v_dot2_f32_bf16 v5, v8, v50, v5                            // 000000FA9EF4: CC1A4005 1C166508
	v_mov_b32_e32 v8, v4                                       // 000000FA9EFC: 7E100304
	s_waitcnt vmcnt(2)                                         // 000000FA9F00: BF890BF7
	v_dot2_f32_bf16 v5, v31, v51, v5                           // 000000FA9F04: CC1A4005 1C16671F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FA9F0C: BF870091
	v_dot2_f32_bf16 v5, v32, v52, v5                           // 000000FA9F10: CC1A4005 1C166920
	v_dot2_f32_bf16 v5, v33, v53, v5                           // 000000FA9F18: CC1A4005 1C166B21
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FA9F20: BF8700A1
	v_dot2_f32_bf16 v5, v34, v54, v5                           // 000000FA9F24: CC1A4005 1C166D22
	s_waitcnt vmcnt(1)                                         // 000000FA9F2C: BF8907F7
	v_dot2_f32_bf16 v5, v35, v55, v5                           // 000000FA9F30: CC1A4005 1C166F23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FA9F38: BF870091
	v_dot2_f32_bf16 v5, v36, v56, v5                           // 000000FA9F3C: CC1A4005 1C167124
	v_dot2_f32_bf16 v5, v37, v57, v5                           // 000000FA9F44: CC1A4005 1C167325
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FA9F4C: BF8700A1
	v_dot2_f32_bf16 v5, v38, v58, v5                           // 000000FA9F50: CC1A4005 1C167526
	s_waitcnt vmcnt(0)                                         // 000000FA9F58: BF8903F7
	v_dot2_f32_bf16 v5, v39, v59, v5                           // 000000FA9F5C: CC1A4005 1C167727
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FA9F64: BF870091
	v_dot2_f32_bf16 v5, v40, v60, v5                           // 000000FA9F68: CC1A4005 1C167928
	v_dot2_f32_bf16 v5, v41, v61, v5                           // 000000FA9F70: CC1A4005 1C167B29
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FA9F78: BF870091
	v_dot2_f32_bf16 v5, v42, v62, v5                           // 000000FA9F7C: CC1A4005 1C167D2A
	v_fmac_f32_e32 v17, v29, v5                                // 000000FA9F84: 56220B1D
	v_mov_b32_e32 v5, v1                                       // 000000FA9F88: 7E0A0301
	v_mov_b32_e32 v29, v30                                     // 000000FA9F8C: 7E3A031E
	s_and_not1_b32 exec_lo, exec_lo, s15                       // 000000FA9F90: 917E0F7E
	s_cbranch_execz 31                                         // 000000FA9F94: BFA5001F <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi2ELb1ELi4ELi0EEEvPKhPKtPvlllllS6_f+0xb14>
	s_waitcnt vmcnt(0)                                         // 000000FA9F98: BF8903F7
	v_dual_mov_b32 v1, v5 :: v_dual_add_nc_u32 v18, 32, v18    // 000000FA9F9C: CA200105 011224A0
	v_dual_mov_b32 v2, v6 :: v_dual_mov_b32 v3, v7             // 000000FA9FA4: CA100106 02020107
	v_mov_b32_e32 v4, v8                                       // 000000FA9FAC: 7E080308
	s_mov_b32 s17, exec_lo                                     // 000000FA9FB0: BE91007E
	s_delay_alu instid0(VALU_DEP_3)                            // 000000FA9FB4: BF870003
	v_cmp_ge_i32_e32 vcc_lo, v18, v19                          // 000000FA9FB8: 7C8C2712
	.long 0xd4c1007e                                           // 000000FA9FBC: D4C1007E
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 000000FA9FC0: 02022712
	s_cbranch_execz 64998                                      // 000000FA9FC4: BFA5FDE6 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi2ELb1ELi4ELi0EEEvPKhPKtPvlllllS6_f+0x260>
	v_ashrrev_i32_e32 v2, 31, v28                              // 000000FA9FC8: 3404389F
	v_ashrrev_i32_e32 v4, 31, v27                              // 000000FA9FCC: 3408369F
	.long 0xd7000001                                           // 000000FA9FD0: D7000001
	v_cndmask_b32_e32 v1, v11, v28, vcc_lo                     // 000000FA9FD4: 0202390B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FA9FD8: BF8700A1
	v_add_co_ci_u32_e64 v2, null, v20, v2, s0                  // 000000FA9FDC: D5207C02 00020514
	.long 0xd7000003                                           // 000000FA9FE4: D7000003
	v_cndmask_b32_e32 v1, v9, v27, vcc_lo                      // 000000FA9FE8: 02023709
	v_add_co_ci_u32_e64 v4, null, v10, v4, s0                  // 000000FA9FEC: D5207C04 0002090A
	s_clause 0x1                                               // 000000FA9FF4: BF850001
	global_load_d16_b16 v13, v[1:2], off                       // 000000FA9FF8: DC820000 0D7C0001
	global_load_b128 v[1:4], v[3:4], off                       // 000000FAA000: DC5E0000 017C0003
	s_waitcnt vmcnt(1)                                         // 000000FAA008: BF8907F7
	v_cvt_f32_f16_e32 v30, v13                                 // 000000FAA00C: 7E3C170D
	s_branch 64979                                             // 000000FAA010: BFA0FDD3 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi2ELb1ELi4ELi0EEEvPKhPKtPvlllllS6_f+0x260>
	s_or_b32 exec_lo, exec_lo, s15                             // 000000FAA014: 8C7E0F7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000FAA018: BF8700B9
	s_or_b32 exec_lo, exec_lo, s1                              // 000000FAA01C: 8C7E017E
	.long 0xd71f0001                                           // 000000FAA020: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 000000FAA024: 020100C1
	s_mov_b32 s0, exec_lo                                      // 000000FAA028: BE80007E
	v_xor_b32_e32 v2, 16, v1                                   // 000000FAA02C: 3A040290
	v_xor_b32_e32 v9, 8, v1                                    // 000000FAA030: 3A120288
	v_xor_b32_e32 v19, 4, v1                                   // 000000FAA034: 3A260284
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000FAA038: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 000000FAA03C: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 000000FAA040: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v9                            // 000000FAA044: 7C9812A0
	v_cndmask_b32_e32 v9, v1, v9, vcc_lo                       // 000000FAA048: 02121301
	v_cmp_gt_u32_e32 vcc_lo, 32, v19                           // 000000FAA04C: 7C9826A0
	s_delay_alu instid0(VALU_DEP_2)                            // 000000FAA050: BF870002
	v_lshlrev_b32_e32 v9, 2, v9                                // 000000FAA054: 30121282
	v_lshlrev_b32_e32 v2, 2, v2                                // 000000FAA058: 30040482
	ds_bpermute_b32 v3, v2, v21                                // 000000FAA05C: DACC0000 03001502
	s_waitcnt lgkmcnt(0)                                       // 000000FAA064: BF89FC07
	v_add_f32_e32 v3, v21, v3                                  // 000000FAA068: 06060715
	s_waitcnt vmcnt(0)                                         // 000000FAA06C: BF8903F7
	ds_bpermute_b32 v5, v2, v25                                // 000000FAA070: DACC0000 05001902
	ds_bpermute_b32 v6, v2, v24                                // 000000FAA078: DACC0000 06001802
	ds_bpermute_b32 v4, v2, v26                                // 000000FAA080: DACC0000 04001A02
	ds_bpermute_b32 v7, v2, v23                                // 000000FAA088: DACC0000 07001702
	ds_bpermute_b32 v8, v2, v22                                // 000000FAA090: DACC0000 08001602
	ds_bpermute_b32 v2, v2, v17                                // 000000FAA098: DACC0000 02001102
	ds_bpermute_b32 v10, v9, v3                                // 000000FAA0A0: DACC0000 0A000309
	s_waitcnt lgkmcnt(5)                                       // 000000FAA0A8: BF89FC57
	v_dual_add_f32 v5, v25, v5 :: v_dual_add_f32 v6, v24, v6   // 000000FAA0AC: C9080B19 05060D18
	s_waitcnt lgkmcnt(3)                                       // 000000FAA0B4: BF89FC37
	v_dual_add_f32 v4, v26, v4 :: v_dual_add_f32 v7, v23, v7   // 000000FAA0B8: C908091A 04060F17
	s_waitcnt lgkmcnt(2)                                       // 000000FAA0C0: BF89FC27
	v_add_f32_e32 v8, v22, v8                                  // 000000FAA0C4: 06101116
	ds_bpermute_b32 v12, v9, v5                                // 000000FAA0C8: DACC0000 0C000509
	ds_bpermute_b32 v13, v9, v6                                // 000000FAA0D0: DACC0000 0D000609
	ds_bpermute_b32 v11, v9, v4                                // 000000FAA0D8: DACC0000 0B000409
	v_cndmask_b32_e32 v19, v1, v19, vcc_lo                     // 000000FAA0E0: 02262701
	ds_bpermute_b32 v18, v9, v8                                // 000000FAA0E4: DACC0000 12000809
	s_waitcnt lgkmcnt(4)                                       // 000000FAA0EC: BF89FC47
	v_add_f32_e32 v3, v3, v10                                  // 000000FAA0F0: 06061503
	s_waitcnt lgkmcnt(2)                                       // 000000FAA0F4: BF89FC27
	v_dual_add_f32 v5, v5, v12 :: v_dual_add_f32 v6, v6, v13   // 000000FAA0F8: C9081905 05061B06
	v_dual_add_f32 v2, v17, v2 :: v_dual_lshlrev_b32 v19, 2, v19// 000000FAA100: C9220511 02122682
	ds_bpermute_b32 v17, v9, v7                                // 000000FAA108: DACC0000 11000709
	s_waitcnt lgkmcnt(2)                                       // 000000FAA110: BF89FC27
	v_add_f32_e32 v4, v4, v11                                  // 000000FAA114: 06081704
	s_waitcnt lgkmcnt(1)                                       // 000000FAA118: BF89FC17
	v_add_f32_e32 v8, v8, v18                                  // 000000FAA11C: 06102508
	ds_bpermute_b32 v9, v9, v2                                 // 000000FAA120: DACC0000 09000209
	ds_bpermute_b32 v11, v19, v5                               // 000000FAA128: DACC0000 0B000513
	ds_bpermute_b32 v12, v19, v6                               // 000000FAA130: DACC0000 0C000613
	ds_bpermute_b32 v10, v19, v4                               // 000000FAA138: DACC0000 0A000413
	s_waitcnt lgkmcnt(4)                                       // 000000FAA140: BF89FC47
	v_add_f32_e32 v7, v7, v17                                  // 000000FAA144: 060E2307
	ds_bpermute_b32 v17, v19, v8                               // 000000FAA148: DACC0000 11000813
	s_waitcnt lgkmcnt(4)                                       // 000000FAA150: BF89FC47
	v_add_f32_e32 v2, v2, v9                                   // 000000FAA154: 06041302
	ds_bpermute_b32 v9, v19, v3                                // 000000FAA158: DACC0000 09000313
	s_waitcnt lgkmcnt(3)                                       // 000000FAA160: BF89FC37
	v_add_f32_e32 v6, v6, v12                                  // 000000FAA164: 060C1906
	s_waitcnt lgkmcnt(2)                                       // 000000FAA168: BF89FC27
	v_add_f32_e32 v4, v4, v10                                  // 000000FAA16C: 06081504
	ds_bpermute_b32 v13, v19, v7                               // 000000FAA170: DACC0000 0D000713
	ds_bpermute_b32 v18, v19, v2                               // 000000FAA178: DACC0000 12000213
	v_xor_b32_e32 v19, 2, v1                                   // 000000FAA180: 3A260282
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FAA184: BF8700A1
	v_cmp_gt_u32_e32 vcc_lo, 32, v19                           // 000000FAA188: 7C9826A0
	v_cndmask_b32_e32 v19, v1, v19, vcc_lo                     // 000000FAA18C: 02262701
	v_lshlrev_b32_e32 v19, 2, v19                              // 000000FAA190: 30262682
	s_waitcnt lgkmcnt(2)                                       // 000000FAA194: BF89FC27
	v_add_f32_e32 v3, v3, v9                                   // 000000FAA198: 06061303
	s_waitcnt lgkmcnt(0)                                       // 000000FAA19C: BF89FC07
	v_dual_add_f32 v7, v7, v13 :: v_dual_add_f32 v2, v2, v18   // 000000FAA1A0: C9081B07 07022502
	ds_bpermute_b32 v10, v19, v4                               // 000000FAA1A8: DACC0000 0A000413
	ds_bpermute_b32 v12, v19, v6                               // 000000FAA1B0: DACC0000 0C000613
	ds_bpermute_b32 v13, v19, v7                               // 000000FAA1B8: DACC0000 0D000713
	ds_bpermute_b32 v18, v19, v2                               // 000000FAA1C0: DACC0000 12000213
	v_add_f32_e32 v5, v5, v11                                  // 000000FAA1C8: 060A1705
	v_add_f32_e32 v9, v8, v17                                  // 000000FAA1CC: 06122308
	ds_bpermute_b32 v8, v19, v3                                // 000000FAA1D0: DACC0000 08000313
	ds_bpermute_b32 v11, v19, v5                               // 000000FAA1D8: DACC0000 0B000513
	s_waitcnt lgkmcnt(2)                                       // 000000FAA1E0: BF89FC27
	v_add_f32_e32 v2, v2, v18                                  // 000000FAA1E4: 06042502
	ds_bpermute_b32 v17, v19, v9                               // 000000FAA1E8: DACC0000 11000913
	v_xor_b32_e32 v19, 1, v1                                   // 000000FAA1F0: 3A260281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FAA1F4: BF8700A1
	v_cmp_gt_u32_e32 vcc_lo, 32, v19                           // 000000FAA1F8: 7C9826A0
	v_cndmask_b32_e32 v1, v1, v19, vcc_lo                      // 000000FAA1FC: 02022701
	v_lshlrev_b32_e32 v19, 2, v1                               // 000000FAA200: 30260282
	s_waitcnt lgkmcnt(2)                                       // 000000FAA204: BF89FC27
	v_add_f32_e32 v1, v3, v8                                   // 000000FAA208: 06021103
	v_dual_add_f32 v3, v4, v10 :: v_dual_add_f32 v8, v7, v13   // 000000FAA20C: C9081504 03081B07
	s_waitcnt lgkmcnt(1)                                       // 000000FAA214: BF89FC17
	v_dual_add_f32 v4, v5, v11 :: v_dual_add_f32 v5, v6, v12   // 000000FAA218: C9081705 04041906
	s_waitcnt lgkmcnt(0)                                       // 000000FAA220: BF89FC07
	v_add_f32_e32 v10, v9, v17                                 // 000000FAA224: 06142309
	ds_bpermute_b32 v6, v19, v1                                // 000000FAA228: DACC0000 06000113
	ds_bpermute_b32 v9, v19, v3                                // 000000FAA230: DACC0000 09000313
	ds_bpermute_b32 v11, v19, v4                               // 000000FAA238: DACC0000 0B000413
	ds_bpermute_b32 v12, v19, v5                               // 000000FAA240: DACC0000 0C000513
	ds_bpermute_b32 v13, v19, v8                               // 000000FAA248: DACC0000 0D000813
	ds_bpermute_b32 v17, v19, v10                              // 000000FAA250: DACC0000 11000A13
	ds_bpermute_b32 v7, v19, v2                                // 000000FAA258: DACC0000 07000213
	v_cmpx_eq_u32_e32 0, v16                                   // 000000FAA260: 7D942080
	s_cbranch_execz 29                                         // 000000FAA264: BFA5001D <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi2ELb1ELi4ELi0EEEvPKhPKtPvlllllS6_f+0xddc>
	.long 0xd72c000e                                           // 000000FAA268: D72C000E
	v_cndmask_b32_e32 v0, v14, v184, vcc_lo                    // 000000FAA26C: 0201710E
	s_waitcnt lgkmcnt(2)                                       // 000000FAA270: BF89FC27
	v_dual_add_f32 v8, v8, v13 :: v_dual_add_f32 v1, v1, v6    // 000000FAA274: C9081B08 08000D01
	v_dual_add_f32 v4, v4, v11 :: v_dual_add_f32 v3, v3, v9    // 000000FAA27C: C9081704 04021303
	s_waitcnt lgkmcnt(1)                                       // 000000FAA284: BF89FC17
	v_dual_add_f32 v10, v10, v17 :: v_dual_add_f32 v5, v5, v12 // 000000FAA288: C908230A 0A041905
	s_waitcnt lgkmcnt(0)                                       // 000000FAA290: BF89FC07
	v_add_f32_e32 v2, v2, v7                                   // 000000FAA294: 06040F02
	v_mad_u32_u24 v13, v15, 28, v14                            // 000000FAA298: D60B000D 0439390F
	s_delay_alu instid0(VALU_DEP_1)                            // 000000FAA2A0: BF870001
	v_add_nc_u32_e32 v6, 0x400, v13                            // 000000FAA2A4: 4A0C1AFF 00000400
	v_add_nc_u32_e32 v9, 0x408, v13                            // 000000FAA2AC: 4A121AFF 00000408
	v_add_nc_u32_e32 v11, 0x410, v13                           // 000000FAA2B4: 4A161AFF 00000410
	ds_store_2addr_b32 v6, v1, v3 offset1:1                    // 000000FAA2BC: D8380100 00030106
	ds_store_2addr_b32 v9, v4, v5 offset1:1                    // 000000FAA2C4: D8380100 00050409
	ds_store_2addr_b32 v11, v8, v10 offset1:1                  // 000000FAA2CC: D8380100 000A080B
	ds_store_b32 v13, v2 offset:1048                           // 000000FAA2D4: D8340418 0000020D
	s_or_b32 exec_lo, exec_lo, s0                              // 000000FAA2DC: 8C7E007E
	.long 0xd7050001                                           // 000000FAA2E0: D7050001
	v_cndmask_b32_e32 v0, v0, v165, vcc_lo                     // 000000FAA2E4: 02014B00
	.long 0x7f063880                                           // 000000FAA2E8: 7F063880
	s_waitcnt lgkmcnt(0)                                       // 000000FAA2EC: BF89FC07
	s_barrier                                                  // 000000FAA2F0: BFBD0000
	buffer_gl0_inv                                             // 000000FAA2F4: E0AC0000 00000000
	.long 0xd7390001                                           // 000000FAA2FC: D7390001
	v_cndmask_b32_e32 v1, 8, v1, vcc_lo                        // 000000FAA300: 02020288
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FAA304: BF870091
	.long 0xd7044001                                           // 000000FAA308: D7044001
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 000000FAA30C: 02020300
	.long 0xd7395001                                           // 000000FAA310: D7395001
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 000000FAA314: 02020281
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FAA318: BF870091
	.long 0xd7625001                                           // 000000FAA31C: D7625001
	v_cndmask_b32_e32 v1, 0x7f, v1, vcc_lo                     // 000000FAA320: 020202FF 0000007F
	.long 0xd7030801                                           // 000000FAA328: D7030801
	v_cndmask_b32_e32 v1, v1, v1, vcc_lo                       // 000000FAA32C: 02020301
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FAA330: BF870091
	.long 0xd7390003                                           // 000000FAA334: D7390003
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 000000FAA338: 02020282
	.long 0xd7000001                                           // 000000FAA33C: D7000001
	v_cndmask_b32_e32 v1, s2, v3, vcc_lo                       // 000000FAA340: 02020602
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000FAA344: BF870121
	v_add_co_ci_u32_e64 v2, null, s3, 0, s0                    // 000000FAA348: D5207C02 00010003
	.long 0xd44c0000                                           // 000000FAA350: D44C0000
	v_cndmask_b32_e32 v1, 28, v0, vcc_lo                       // 000000FAA354: 0202009C
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[1:2]                  // 000000FAA358: 7CA8020C
	s_and_b32 s0, s0, vcc_lo                                   // 000000FAA35C: 8B006A00
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000FAA360: BF870009
	s_and_saveexec_b32 s1, s0                                  // 000000FAA364: BE812000
	s_cbranch_execz 68                                         // 000000FAA368: BFA50044 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi2ELb1ELi4ELi0EEEvPKhPKtPvlllllS6_f+0xf7c>
	.long 0xd7054000                                           // 000000FAA36C: D7054000
	v_cndmask_b32_e32 v0, v3, v135, vcc_lo                     // 000000FAA370: 02010F03
	v_mul_u32_u24_e32 v3, 56, v3                               // 000000FAA374: 160606B8
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FAA378: BF870092
	.long 0xd7041000                                           // 000000FAA37C: D7041000
	v_cndmask_b32_e32 v1, v0, v0, vcc_lo                       // 000000FAA380: 02020100
	v_and_b32_e32 v0, 0xff, v0                                 // 000000FAA384: 360000FF 000000FF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FAA38C: BF870091
	v_lshl_add_u32 v3, v0, 2, v3                               // 000000FAA390: D6460003 040D0500
	v_add_nc_u32_e32 v3, 0x400, v3                             // 000000FAA398: 4A0606FF 00000400
	ds_load_2addr_b32 v[3:4], v3 offset1:7                     // 000000FAA3A0: D8DC0700 03000003
	s_waitcnt lgkmcnt(0)                                       // 000000FAA3A8: BF89FC07
	v_add_f32_e32 v3, 0, v3                                    // 000000FAA3AC: 06060680
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FAA3B0: BF870091
	v_add_f32_e32 v3, v3, v4                                   // 000000FAA3B4: 06060903
	v_mul_f32_e32 v3, 0xbfb8aa3b, v3                           // 000000FAA3B8: 100606FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000FAA3C0: BF870291
	v_exp_f32_e32 v3, v3                                       // 000000FAA3C4: 7E064B03
	v_add_f32_e32 v6, 1.0, v3                                  // 000000FAA3C8: 060C06F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000FAA3CC: BF870121
	v_div_scale_f32 v7, null, v6, v6, 1.0                      // 000000FAA3D0: D6FC7C07 03CA0D06
	v_div_scale_f32 v9, vcc_lo, 1.0, v6, 1.0                   // 000000FAA3D8: D6FC6A09 03CA0CF2
	v_rcp_f32_e32 v8, v7                                       // 000000FAA3E0: 7E105507
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FAA3E4: BF870095
	v_fma_f32 v3, -v7, v8, 1.0                                 // 000000FAA3E8: D6130003 23CA1107
	v_fmac_f32_e32 v8, v3, v8                                  // 000000FAA3F0: 56101103
	v_mad_u64_u32 v[3:4], null, s12, v0, 0                     // 000000FAA3F4: D6FE7C03 0202000C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000FAA3FC: BF870112
	v_mul_f32_e32 v10, v9, v8                                  // 000000FAA400: 10141109
	v_mad_u64_u32 v[4:5], null, s13, v0, v[4:5]                // 000000FAA404: D6FE7C04 0412000D
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000FAA40C: BF870122
	v_fma_f32 v11, -v7, v10, v9                                // 000000FAA410: D613000B 24261507
	.long 0xd73c0000                                           // 000000FAA418: D73C0000
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 000000FAA41C: 02020282
	v_fmac_f32_e32 v10, v11, v8                                // 000000FAA420: 5614110B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000FAA424: BF870114
	.long 0xd73c0003                                           // 000000FAA428: D73C0003
	v_cndmask_b32_e32 v1, 2, v3, vcc_lo                        // 000000FAA42C: 02020682
	v_fma_f32 v5, -v7, v10, v9                                 // 000000FAA430: D6130005 24261507
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000FAA438: BF870191
	v_div_fmas_f32 v2, v5, v8, v10                             // 000000FAA43C: D6370002 042A1105
	.long 0xd7006a03                                           // 000000FAA444: D7006A03
	v_cndmask_b32_e32 v1, s8, v3, vcc_lo                       // 000000FAA448: 02020608
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000FAA44C: BF870191
	v_add_co_ci_u32_e64 v4, null, s9, v4, vcc_lo               // 000000FAA450: D5207C04 01AA0809
	v_div_fixup_f32 v2, v2, v6, 1.0                            // 000000FAA458: D6270002 03CA0D02
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FAA460: BF870093
	.long 0xd7006a00                                           // 000000FAA464: D7006A00
	v_cndmask_b32_e32 v1, v3, v0, vcc_lo                       // 000000FAA468: 02020103
	v_add_co_ci_u32_e64 v1, null, v4, v1, vcc_lo               // 000000FAA46C: D5207C01 01AA0304
	global_store_b32 v[0:1], v2, off                           // 000000FAA474: DC6A0000 007C0200
	s_endpgm                                                   // 000000FAA47C: BFB00000
		...

