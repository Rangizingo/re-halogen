00000000002cce00 <_ZN7halogen12_GLOBAL__N_17k_hcup4ILi2ELi1EEEvPKhlllPKtS5_PtPf>:
; _ZN7halogen12_GLOBAL__N_17k_hcup4ILi2ELi1EEEvPKhlllPKtS5_PtPf():
	s_load_b128 s[12:15], s[0:1], null                         // 0000002CCE00: F4080300 F8000000
	v_and_b32_e32 v2, 15, v0                                   // 0000002CCE08: 3604008F
	v_lshrrev_b32_e32 v1, 4, v0                                // 0000002CCE0C: 32020084
	s_load_b256 s[4:11], s[0:1], 0x20                          // 0000002CCE10: F40C0100 F8000020
	s_mov_b32 s3, exec_lo                                      // 0000002CCE18: BE83007E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002CCE1C: BF870112
	v_lshlrev_b32_e32 v3, 2, v2                                // 0000002CCE20: 30060482
	v_lshlrev_b32_e32 v4, 2, v1                                // 0000002CCE24: 30080282
	s_waitcnt lgkmcnt(0)                                       // 0000002CCE28: BF89FC07
	s_clause 0x1                                               // 0000002CCE2C: BF850001
	global_load_b32 v3, v3, s[12:13]                           // 0000002CCE30: DC520000 030C0003
	global_load_b32 v4, v4, s[12:13]                           // 0000002CCE38: DC520000 040C0004
	s_waitcnt vmcnt(1)                                         // 0000002CCE40: BF8907F7
	v_bfe_u32 v5, v3, 16, 1                                    // 0000002CCE44: D6100005 02052103
	s_waitcnt vmcnt(0)                                         // 0000002CCE4C: BF8903F7
	v_bfe_u32 v6, v4, 16, 1                                    // 0000002CCE50: D6100006 02052104
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000002CCE58: BF8701A2
	v_add3_u32 v3, v3, v5, 0x7fff                              // 0000002CCE5C: D6550003 03FE0B03 00007FFF
	.long 0x7f0a3880                                           // 0000002CCE68: 7F0A3880
	v_add3_u32 v4, v4, v6, 0x7fff                              // 0000002CCE6C: D6550004 03FE0D04 00007FFF
	v_lshlrev_b32_e32 v6, 2, v0                                // 0000002CCE78: 300C0082
	v_mov_b32_e32 v0, 0                                        // 0000002CCE7C: 7E000280
	.long 0x7e0a3983                                           // 0000002CCE80: 7E0A3983
	v_mov_b32_e32 v3, 0                                        // 0000002CCE84: 7E060280
	s_delay_alu instid0(VALU_DEP_2)                            // 0000002CCE88: BF870002
	v_and_or_b32 v4, 0xffff0000, v4, v5                        // 0000002CCE8C: D6570004 041608FF FFFF0000
	ds_store_b32 v6, v4                                        // 0000002CCE98: D8340000 00000406
	s_waitcnt lgkmcnt(0)                                       // 0000002CCEA0: BF89FC07
	s_barrier                                                  // 0000002CCEA4: BFBD0000
	buffer_gl0_inv                                             // 0000002CCEA8: E0AC0000 00000000
	v_cmpx_gt_u32_e32 10, v2                                   // 0000002CCEB0: 7D98048A
	s_cbranch_execz 210                                        // 0000002CCEB4: BFA500D2 <_ZN7halogen12_GLOBAL__N_17k_hcup4ILi2ELi1EEEvPKhlllPKtS5_PtPf+0x400>
	v_lshlrev_b32_e32 v0, 4, v2                                // 0000002CCEB8: 30000484
	s_add_u32 s14, s12, s14                                    // 0000002CCEBC: 800E0E0C
	s_addc_u32 s15, s13, s15                                   // 0000002CCEC0: 820F0F0D
	s_load_b64 s[0:1], s[0:1], 0x10                            // 0000002CCEC4: F4040000 F8000010
	global_load_b128 v[3:6], v0, s[14:15]                      // 0000002CCECC: DC5E0000 030E0000
	v_lshlrev_b32_e32 v0, 6, v2                                // 0000002CCED4: 30000486
	s_clause 0x7                                               // 0000002CCED8: BF850007
	global_load_b128 v[7:10], v0, s[4:5]                       // 0000002CCEDC: DC5E0000 07040000
	global_load_b128 v[11:14], v0, s[4:5] offset:640           // 0000002CCEE4: DC5E0280 0B040000
	global_load_b128 v[15:18], v0, s[4:5] offset:16            // 0000002CCEEC: DC5E0010 0F040000
	global_load_b128 v[19:22], v0, s[4:5] offset:656           // 0000002CCEF4: DC5E0290 13040000
	global_load_b128 v[23:26], v0, s[4:5] offset:32            // 0000002CCEFC: DC5E0020 17040000
	global_load_b128 v[27:30], v0, s[4:5] offset:672           // 0000002CCF04: DC5E02A0 1B040000
	global_load_b128 v[31:34], v0, s[4:5] offset:48            // 0000002CCF0C: DC5E0030 1F040000
	global_load_b128 v[35:38], v0, s[4:5] offset:688           // 0000002CCF14: DC5E02B0 23040000
	v_lshlrev_b32_e32 v0, 1, v2                                // 0000002CCF1C: 30000481
	s_waitcnt lgkmcnt(0)                                       // 0000002CCF20: BF89FC07
	s_add_u32 s0, s12, s0                                      // 0000002CCF24: 8000000C
	s_addc_u32 s1, s13, s1                                     // 0000002CCF28: 8201010D
	global_load_d16_b16 v39, v0, s[0:1]                        // 0000002CCF2C: DC820000 27000000
	s_waitcnt vmcnt(9)                                         // 0000002CCF34: BF8927F7
	v_and_b32_e32 v0, 0xff, v3                                 // 0000002CCF38: 360006FF 000000FF
	v_lshrrev_b32_e32 v40, 6, v3                               // 0000002CCF40: 32500686
	v_lshrrev_b32_e32 v41, 14, v3                              // 0000002CCF44: 3252068E
	v_lshrrev_b32_e32 v3, 22, v3                               // 0000002CCF48: 32060696
	v_and_b32_e32 v42, 0xff, v4                                // 0000002CCF4C: 365408FF 000000FF
	v_lshlrev_b32_e32 v0, 2, v0                                // 0000002CCF54: 30000082
	v_and_b32_e32 v40, 0x3fc, v40                              // 0000002CCF58: 365050FF 000003FC
	v_and_b32_e32 v41, 0x3fc, v41                              // 0000002CCF60: 365252FF 000003FC
	v_lshrrev_b32_e32 v43, 6, v4                               // 0000002CCF68: 32560886
	v_lshrrev_b32_e32 v44, 14, v4                              // 0000002CCF6C: 3258088E
	ds_load_b32 v0, v0                                         // 0000002CCF70: D8D80000 00000000
	ds_load_b32 v40, v40                                       // 0000002CCF78: D8D80000 28000028
	ds_load_b32 v41, v41                                       // 0000002CCF80: D8D80000 29000029
	v_lshrrev_b32_e32 v4, 22, v4                               // 0000002CCF88: 32080896
	v_and_b32_e32 v3, 0x3fc, v3                                // 0000002CCF8C: 360606FF 000003FC
	v_lshlrev_b32_e32 v42, 2, v42                              // 0000002CCF94: 30545482
	v_and_b32_e32 v43, 0x3fc, v43                              // 0000002CCF98: 365656FF 000003FC
	v_and_b32_e32 v44, 0x3fc, v44                              // 0000002CCFA0: 365858FF 000003FC
	v_and_b32_e32 v4, 0x3fc, v4                                // 0000002CCFA8: 360808FF 000003FC
	ds_load_b32 v3, v3                                         // 0000002CCFB0: D8D80000 03000003
	ds_load_b32 v42, v42                                       // 0000002CCFB8: D8D80000 2A00002A
	ds_load_b32 v43, v43                                       // 0000002CCFC0: D8D80000 2B00002B
	ds_load_b32 v44, v44                                       // 0000002CCFC8: D8D80000 2C00002C
	ds_load_b32 v4, v4                                         // 0000002CCFD0: D8D80000 04000004
	s_waitcnt vmcnt(8) lgkmcnt(7)                              // 0000002CCFD8: BF892077
	v_dot2_f32_bf16 v7, v7, v0, 0                              // 0000002CCFDC: CC1A4007 1A020107
	s_waitcnt vmcnt(7)                                         // 0000002CCFE4: BF891FF7
	v_dot2_f32_bf16 v0, v11, v0, 0                             // 0000002CCFE8: CC1A4000 1A02010B
	v_and_b32_e32 v11, 0xff, v5                                // 0000002CCFF0: 36160AFF 000000FF
	s_waitcnt lgkmcnt(6)                                       // 0000002CCFF8: BF89FC67
	v_dot2_f32_bf16 v7, v8, v40, v7                            // 0000002CCFFC: CC1A4007 1C1E5108
	s_delay_alu instid0(VALU_DEP_3)                            // 0000002CD004: BF870003
	v_dot2_f32_bf16 v0, v12, v40, v0                           // 0000002CD008: CC1A4000 1C02510C
	v_lshrrev_b32_e32 v8, 6, v5                                // 0000002CD010: 32100A86
	v_lshrrev_b32_e32 v12, 14, v5                              // 0000002CD014: 32180A8E
	v_lshrrev_b32_e32 v5, 22, v5                               // 0000002CD018: 320A0A96
	s_waitcnt lgkmcnt(5)                                       // 0000002CD01C: BF89FC57
	v_dot2_f32_bf16 v7, v9, v41, v7                            // 0000002CD020: CC1A4007 1C1E5309
	v_dot2_f32_bf16 v0, v13, v41, v0                           // 0000002CD028: CC1A4000 1C02530D
	v_and_b32_e32 v8, 0x3fc, v8                                // 0000002CD030: 361010FF 000003FC
	v_and_b32_e32 v9, 0xff, v6                                 // 0000002CD038: 36120CFF 000000FF
	v_lshrrev_b32_e32 v13, 6, v6                               // 0000002CD040: 321A0C86
	s_waitcnt lgkmcnt(4)                                       // 0000002CD044: BF89FC47
	v_dot2_f32_bf16 v7, v10, v3, v7                            // 0000002CD048: CC1A4007 1C1E070A
	v_dot2_f32_bf16 v0, v14, v3, v0                            // 0000002CD050: CC1A4000 1C02070E
	v_lshlrev_b32_e32 v3, 2, v11                               // 0000002CD058: 30061682
	v_and_b32_e32 v10, 0x3fc, v12                              // 0000002CD05C: 361418FF 000003FC
	v_lshrrev_b32_e32 v40, 14, v6                              // 0000002CD064: 32500C8E
	s_waitcnt vmcnt(6) lgkmcnt(3)                              // 0000002CD068: BF891837
	v_dot2_f32_bf16 v7, v15, v42, v7                           // 0000002CD06C: CC1A4007 1C1E550F
	s_waitcnt vmcnt(5)                                         // 0000002CD074: BF8917F7
	v_dot2_f32_bf16 v0, v19, v42, v0                           // 0000002CD078: CC1A4000 1C025513
	ds_load_b32 v3, v3                                         // 0000002CD080: D8D80000 03000003
	ds_load_b32 v8, v8                                         // 0000002CD088: D8D80000 08000008
	ds_load_b32 v10, v10                                       // 0000002CD090: D8D80000 0A00000A
	s_waitcnt lgkmcnt(5)                                       // 0000002CD098: BF89FC57
	v_dot2_f32_bf16 v7, v16, v43, v7                           // 0000002CD09C: CC1A4007 1C1E5710
	v_dot2_f32_bf16 v0, v20, v43, v0                           // 0000002CD0A4: CC1A4000 1C025714
	v_lshrrev_b32_e32 v6, 22, v6                               // 0000002CD0AC: 320C0C96
	v_and_b32_e32 v5, 0x3fc, v5                                // 0000002CD0B0: 360A0AFF 000003FC
	v_lshlrev_b32_e32 v9, 2, v9                                // 0000002CD0B8: 30121282
	s_waitcnt lgkmcnt(4)                                       // 0000002CD0BC: BF89FC47
	v_dot2_f32_bf16 v7, v17, v44, v7                           // 0000002CD0C0: CC1A4007 1C1E5911
	v_dot2_f32_bf16 v0, v21, v44, v0                           // 0000002CD0C8: CC1A4000 1C025915
	v_and_b32_e32 v11, 0x3fc, v13                              // 0000002CD0D0: 36161AFF 000003FC
	v_and_b32_e32 v12, 0x3fc, v40                              // 0000002CD0D8: 361850FF 000003FC
	v_and_b32_e32 v6, 0x3fc, v6                                // 0000002CD0E0: 360C0CFF 000003FC
	s_waitcnt lgkmcnt(3)                                       // 0000002CD0E8: BF89FC37
	v_dot2_f32_bf16 v7, v18, v4, v7                            // 0000002CD0EC: CC1A4007 1C1E0912
	v_dot2_f32_bf16 v0, v22, v4, v0                            // 0000002CD0F4: CC1A4000 1C020916
	ds_load_b32 v4, v5                                         // 0000002CD0FC: D8D80000 04000005
	ds_load_b32 v5, v9                                         // 0000002CD104: D8D80000 05000009
	ds_load_b32 v9, v11                                        // 0000002CD10C: D8D80000 0900000B
	ds_load_b32 v11, v12                                       // 0000002CD114: D8D80000 0B00000C
	ds_load_b32 v6, v6                                         // 0000002CD11C: D8D80000 06000006
	s_waitcnt vmcnt(4) lgkmcnt(7)                              // 0000002CD124: BF891077
	v_dot2_f32_bf16 v7, v23, v3, v7                            // 0000002CD128: CC1A4007 1C1E0717
	s_waitcnt vmcnt(3)                                         // 0000002CD130: BF890FF7
	v_dot2_f32_bf16 v0, v27, v3, v0                            // 0000002CD134: CC1A4000 1C02071B
	s_waitcnt lgkmcnt(6)                                       // 0000002CD13C: BF89FC67
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002CD140: BF870112
	v_dot2_f32_bf16 v3, v24, v8, v7                            // 0000002CD144: CC1A4003 1C1E1118
	v_dot2_f32_bf16 v0, v28, v8, v0                            // 0000002CD14C: CC1A4000 1C02111C
	s_waitcnt lgkmcnt(5)                                       // 0000002CD154: BF89FC57
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002CD158: BF870112
	v_dot2_f32_bf16 v3, v25, v10, v3                           // 0000002CD15C: CC1A4003 1C0E1519
	v_dot2_f32_bf16 v0, v29, v10, v0                           // 0000002CD164: CC1A4000 1C02151D
	s_waitcnt lgkmcnt(4)                                       // 0000002CD16C: BF89FC47
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002CD170: BF870112
	v_dot2_f32_bf16 v3, v26, v4, v3                            // 0000002CD174: CC1A4003 1C0E091A
	v_dot2_f32_bf16 v0, v30, v4, v0                            // 0000002CD17C: CC1A4000 1C02091E
	s_waitcnt vmcnt(2) lgkmcnt(3)                              // 0000002CD184: BF890837
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002CD188: BF870122
	v_dot2_f32_bf16 v3, v31, v5, v3                            // 0000002CD18C: CC1A4003 1C0E0B1F
	s_waitcnt vmcnt(1)                                         // 0000002CD194: BF8907F7
	v_dot2_f32_bf16 v0, v35, v5, v0                            // 0000002CD198: CC1A4000 1C020B23
	s_waitcnt lgkmcnt(2)                                       // 0000002CD1A0: BF89FC27
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002CD1A4: BF870112
	v_dot2_f32_bf16 v3, v32, v9, v3                            // 0000002CD1A8: CC1A4003 1C0E1320
	v_dot2_f32_bf16 v0, v36, v9, v0                            // 0000002CD1B0: CC1A4000 1C021324
	s_waitcnt lgkmcnt(1)                                       // 0000002CD1B8: BF89FC17
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002CD1BC: BF870112
	v_dot2_f32_bf16 v3, v33, v11, v3                           // 0000002CD1C0: CC1A4003 1C0E1721
	v_dot2_f32_bf16 v0, v37, v11, v0                           // 0000002CD1C8: CC1A4000 1C021725
	s_waitcnt lgkmcnt(0)                                       // 0000002CD1D0: BF89FC07
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002CD1D4: BF870112
	v_dot2_f32_bf16 v3, v34, v6, v3                            // 0000002CD1D8: CC1A4003 1C0E0D22
	v_dot2_f32_bf16 v4, v38, v6, v0                            // 0000002CD1E0: CC1A4004 1C020D26
	s_waitcnt vmcnt(0)                                         // 0000002CD1E8: BF8903F7
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002CD1EC: BF870112
	v_fma_mix_f32 v0, v39, v3, 0 op_sel_hi:[1,0,0]             // 0000002CD1F0: CC200000 0A020727
	v_fma_mix_f32 v3, v39, v4, 0 op_sel_hi:[1,0,0]             // 0000002CD1F8: CC200003 0A020927
	s_or_b32 exec_lo, exec_lo, s3                              // 0000002CD200: 8C7E037E
	.long 0xd71f0004                                           // 0000002CD204: D71F0004
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000002CD208: 020100C1
	s_mov_b32 s0, exec_lo                                      // 0000002CD20C: BE80007E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002CD210: BF870121
	v_xor_b32_e32 v5, 8, v4                                    // 0000002CD214: 3A0A0888
	v_xor_b32_e32 v7, 4, v4                                    // 0000002CD218: 3A0E0884
	v_cmp_gt_u32_e32 vcc_lo, 32, v5                            // 0000002CD21C: 7C980AA0
	v_cndmask_b32_e32 v5, v4, v5, vcc_lo                       // 0000002CD220: 020A0B04
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002CD224: BF870113
	v_cmp_gt_u32_e32 vcc_lo, 32, v7                            // 0000002CD228: 7C980EA0
	v_lshlrev_b32_e32 v5, 2, v5                                // 0000002CD22C: 300A0A82
	v_cndmask_b32_e32 v7, v4, v7, vcc_lo                       // 0000002CD230: 020E0F04
	ds_bpermute_b32 v6, v5, v0                                 // 0000002CD234: DACC0000 06000005
	s_waitcnt lgkmcnt(0)                                       // 0000002CD23C: BF89FC07
	v_add_f32_e32 v0, v0, v6                                   // 0000002CD240: 06000D00
	ds_bpermute_b32 v5, v5, v3                                 // 0000002CD244: DACC0000 05000305
	v_lshlrev_b32_e32 v7, 2, v7                                // 0000002CD24C: 300E0E82
	s_waitcnt lgkmcnt(0)                                       // 0000002CD250: BF89FC07
	v_add_f32_e32 v3, v3, v5                                   // 0000002CD254: 06060B03
	ds_bpermute_b32 v5, v7, v0                                 // 0000002CD258: DACC0000 05000007
	s_waitcnt lgkmcnt(0)                                       // 0000002CD260: BF89FC07
	v_add_f32_e32 v0, v0, v5                                   // 0000002CD264: 06000B00
	ds_bpermute_b32 v6, v7, v3                                 // 0000002CD268: DACC0000 06000307
	v_xor_b32_e32 v7, 2, v4                                    // 0000002CD270: 3A0E0882
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002CD274: BF8700A1
	v_cmp_gt_u32_e32 vcc_lo, 32, v7                            // 0000002CD278: 7C980EA0
	v_cndmask_b32_e32 v7, v4, v7, vcc_lo                       // 0000002CD27C: 020E0F04
	v_lshlrev_b32_e32 v7, 2, v7                                // 0000002CD280: 300E0E82
	s_waitcnt lgkmcnt(0)                                       // 0000002CD284: BF89FC07
	v_add_f32_e32 v5, v3, v6                                   // 0000002CD288: 060A0D03
	ds_bpermute_b32 v3, v7, v0                                 // 0000002CD28C: DACC0000 03000007
	ds_bpermute_b32 v6, v7, v5                                 // 0000002CD294: DACC0000 06000507
	v_xor_b32_e32 v7, 1, v4                                    // 0000002CD29C: 3A0E0881
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002CD2A0: BF8700A1
	v_cmp_gt_u32_e32 vcc_lo, 32, v7                            // 0000002CD2A4: 7C980EA0
	v_cndmask_b32_e32 v4, v4, v7, vcc_lo                       // 0000002CD2A8: 02080F04
	v_lshlrev_b32_e32 v7, 2, v4                                // 0000002CD2AC: 300E0882
	s_waitcnt lgkmcnt(0)                                       // 0000002CD2B0: BF89FC07
	v_dual_add_f32 v3, v0, v3 :: v_dual_add_f32 v6, v5, v6     // 0000002CD2B4: C9080700 03060D05
	ds_bpermute_b32 v4, v7, v3                                 // 0000002CD2BC: DACC0000 04000307
	ds_bpermute_b32 v7, v7, v6                                 // 0000002CD2C4: DACC0000 07000607
	v_cmpx_eq_u32_e32 0, v2                                    // 0000002CD2CC: 7D940480
	s_cbranch_execz 254                                        // 0000002CD2D0: BFA500FE <_ZN7halogen12_GLOBAL__N_17k_hcup4ILi2ELi1EEEvPKhlllPKtS5_PtPf+0x8cc>
	s_waitcnt lgkmcnt(1)                                       // 0000002CD2D4: BF89FC17
	v_dual_add_f32 v3, v3, v4 :: v_dual_and_b32 v0, 14, v1     // 0000002CD2D8: C9240903 0300028E
	v_and_b32_e32 v1, 1, v1                                    // 0000002CD2E0: 36020281
	s_lshl_b32 s0, s2, 4                                       // 0000002CD2E4: 84008402
	s_cmp_lg_u64 s[10:11], 0                                   // 0000002CD2E8: BF11800A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002CD2EC: BF870112
	v_bfe_u32 v4, v3, 16, 1                                    // 0000002CD2F0: D6100004 02052103
	v_or3_b32 v9, v0, s0, v1                                   // 0000002CD2F8: D6580009 04040100
	s_cselect_b32 s0, -1, 0                                    // 0000002CD300: 980080C1
	s_cmp_eq_u64 s[10:11], 0                                   // 0000002CD304: BF10800A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002CD308: BF870112
	v_add3_u32 v3, v3, v4, 0x7fff                              // 0000002CD30C: D6550003 03FE0903 00007FFF
	v_ashrrev_i32_e32 v10, 31, v9                              // 0000002CD318: 3414129F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002CD31C: BF870112
	v_and_b32_e32 v3, 0xffff0000, v3                           // 0000002CD320: 360606FF FFFF0000
	.long 0xd73c000b                                           // 0000002CD328: D73C000B
	v_cndmask_b32_e32 v1, 1, v9, vcc_lo                        // 0000002CD32C: 02021281
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002CD330: BF870091
	.long 0xd7006a00                                           // 0000002CD334: D7006A00
	v_cndmask_b32_e32 v1, s6, v11, vcc_lo                      // 0000002CD338: 02021606
	v_add_co_ci_u32_e64 v1, null, s7, v12, vcc_lo              // 0000002CD33C: D5207C01 01AA1807
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002CD344: BF870092
	.long 0xd7006a0d                                           // 0000002CD348: D7006A0D
	v_cndmask_b32_e32 v1, 0x2000, v0, vcc_lo                   // 0000002CD34C: 020200FF 00002000
	v_add_co_ci_u32_e64 v14, null, 0, v1, vcc_lo               // 0000002CD354: D5207C0E 01AA0280
	.long 0xd7006a0f                                           // 0000002CD35C: D7006A0F
	v_cndmask_b32_e32 v1, 0x3000, v0, vcc_lo                   // 0000002CD360: 020200FF 00003000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002CD368: BF8700A1
	v_add_co_ci_u32_e64 v16, null, 0, v1, vcc_lo               // 0000002CD36C: D5207C10 01AA0280
	.long 0xd7006a11                                           // 0000002CD374: D7006A11
	v_cndmask_b32_e32 v1, 0x1000, v0, vcc_lo                   // 0000002CD378: 020200FF 00001000
	v_add_co_ci_u32_e64 v18, null, 0, v1, vcc_lo               // 0000002CD380: D5207C12 01AA0280
	s_clause 0x3                                               // 0000002CD388: BF850003
	global_load_u16 v2, v[13:14], off offset:2048              // 0000002CD38C: DC4A0800 027C000D
	global_load_u16 v5, v[15:16], off offset:3072              // 0000002CD394: DC4A0C00 057C000F
	global_load_u16 v8, v[0:1], off                            // 0000002CD39C: DC4A0000 087C0000
	global_load_u16 v13, v[17:18], off offset:1024             // 0000002CD3A4: DC4A0400 0D7C0011
	v_mul_f32_e32 v3, 0xbfb8aa3b, v3                           // 0000002CD3AC: 100606FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002CD3B4: BF870291
	v_exp_f32_e32 v3, v3                                       // 0000002CD3B8: 7E064B03
	v_add_f32_e32 v3, 1.0, v3                                  // 0000002CD3BC: 060606F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002CD3C0: BF870121
	v_div_scale_f32 v4, null, v3, v3, 1.0                      // 0000002CD3C4: D6FC7C04 03CA0703
	v_div_scale_f32 v16, vcc_lo, 1.0, v3, 1.0                  // 0000002CD3CC: D6FC6A10 03CA06F2
	v_rcp_f32_e32 v14, v4                                      // 0000002CD3D4: 7E1C5504
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002CD3D8: BF870095
	v_fma_f32 v15, -v4, v14, 1.0                               // 0000002CD3DC: D613000F 23CA1D04
	v_fmac_f32_e32 v14, v15, v14                               // 0000002CD3E4: 561C1D0F
	s_waitcnt vmcnt(3)                                         // 0000002CD3E8: BF890FF7
	v_lshlrev_b32_e32 v2, 16, v2                               // 0000002CD3EC: 30040490
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000002CD3F0: BF870132
	v_mul_f32_e32 v15, v16, v14                                // 0000002CD3F4: 101E1D10
	s_waitcnt vmcnt(2)                                         // 0000002CD3F8: BF890BF7
	v_lshlrev_b32_e32 v5, 16, v5                               // 0000002CD3FC: 300A0A90
	v_fma_f32 v17, -v4, v15, v16                               // 0000002CD400: D6130011 24421F04
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002CD408: BF870091
	v_fmac_f32_e32 v15, v17, v14                               // 0000002CD40C: 561E1D11
	v_fma_f32 v4, -v4, v15, v16                                // 0000002CD410: D6130004 24421F04
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002CD418: BF870091
	v_div_fmas_f32 v4, v4, v14, v15                            // 0000002CD41C: D6370004 043E1D04
	v_div_fixup_f32 v3, v4, v3, 1.0                            // 0000002CD424: D6270003 03CA0704
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002CD42C: BF870091
	v_bfe_u32 v4, v3, 16, 1                                    // 0000002CD430: D6100004 02052103
	v_add3_u32 v3, v3, v4, 0x7fff                              // 0000002CD438: D6550003 03FE0903 00007FFF
	s_waitcnt vmcnt(1)                                         // 0000002CD444: BF8907F7
	v_lshlrev_b32_e32 v4, 16, v8                               // 0000002CD448: 30081090
	s_waitcnt vmcnt(0)                                         // 0000002CD44C: BF8903F7
	v_lshlrev_b32_e32 v8, 16, v13                              // 0000002CD450: 30101A90
	v_and_b32_e32 v3, 0xffff0000, v3                           // 0000002CD454: 360606FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002CD45C: BF870091
	v_fma_f32 v4, v4, v3, 0                                    // 0000002CD460: D6130004 02020704
	v_fmac_f32_e32 v4, v8, v3                                  // 0000002CD468: 56080708
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002CD46C: BF870121
	v_fmac_f32_e32 v4, v2, v3                                  // 0000002CD470: 56080702
	.long 0xd7006a02                                           // 0000002CD474: D7006A02
	v_cndmask_b32_e32 v1, s8, v11, vcc_lo                      // 0000002CD478: 02021608
	v_fmac_f32_e32 v4, v5, v3                                  // 0000002CD47C: 56080705
	v_add_co_ci_u32_e64 v3, null, s9, v12, vcc_lo              // 0000002CD480: D5207C03 01AA1809
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002CD488: BF870092
	v_mul_f32_e32 v8, 0x3e800000, v4                           // 0000002CD48C: 101008FF 3E800000
	v_bfe_u32 v4, v8, 16, 1                                    // 0000002CD494: D6100004 02052108
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002CD49C: BF870001
	v_add3_u32 v11, v8, v4, 0x7fff                             // 0000002CD4A0: D655000B 03FE0908 00007FFF
	.long 0xd73c0004                                           // 0000002CD4AC: D73C0004
	v_cndmask_b32_e32 v1, 2, v9, vcc_lo                        // 0000002CD4B0: 02021282
	global_store_d16_hi_b16 v[2:3], v11, off                   // 0000002CD4B4: DC960000 007C0B02
	s_cbranch_scc1 7                                           // 0000002CD4BC: BFA20007 <_ZN7halogen12_GLOBAL__N_17k_hcup4ILi2ELi1EEEvPKhlllPKtS5_PtPf+0x6dc>
	.long 0xd7006a09                                           // 0000002CD4C0: D7006A09
	v_cndmask_b32_e32 v1, s10, v4, vcc_lo                      // 0000002CD4C4: 0202080A
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002CD4C8: BF870001
	v_add_co_ci_u32_e64 v10, null, s11, v5, vcc_lo             // 0000002CD4CC: D5207C0A 01AA0A0B
	global_store_b32 v[9:10], v8, off                          // 0000002CD4D4: DC6A0000 007C0809
	.long 0xd7006a08                                           // 0000002CD4DC: D7006A08
	v_cndmask_b32_e32 v1, 0x5000, v0, vcc_lo                   // 0000002CD4E0: 020200FF 00005000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002CD4E8: BF8700A1
	v_add_co_ci_u32_e64 v9, null, 0, v1, vcc_lo                // 0000002CD4EC: D5207C09 01AA0280
	.long 0xd7006a0a                                           // 0000002CD4F4: D7006A0A
	v_cndmask_b32_e32 v1, 0x6000, v0, vcc_lo                   // 0000002CD4F8: 020200FF 00006000
	v_add_co_ci_u32_e64 v11, null, 0, v1, vcc_lo               // 0000002CD500: D5207C0B 01AA0280
	s_clause 0x1                                               // 0000002CD508: BF850001
	global_load_u16 v12, v[8:9], off                           // 0000002CD50C: DC4A0000 0C7C0008
	global_load_u16 v10, v[10:11], off offset:1024             // 0000002CD514: DC4A0400 0A7C000A
	.long 0xd7006a08                                           // 0000002CD51C: D7006A08
	v_cndmask_b32_e32 v1, 0x7000, v0, vcc_lo                   // 0000002CD520: 020200FF 00007000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002CD528: BF8700A1
	v_add_co_ci_u32_e64 v9, null, 0, v1, vcc_lo                // 0000002CD52C: D5207C09 01AA0280
	.long 0xd7006a00                                           // 0000002CD534: D7006A00
	v_cndmask_b32_e32 v1, 0x8000, v0, vcc_lo                   // 0000002CD538: 020200FF 00008000
	v_add_co_ci_u32_e64 v1, null, 0, v1, vcc_lo                // 0000002CD540: D5207C01 01AA0280
	s_clause 0x1                                               // 0000002CD548: BF850001
	global_load_u16 v8, v[8:9], off offset:2048                // 0000002CD54C: DC4A0800 087C0008
	global_load_u16 v0, v[0:1], off offset:3072                // 0000002CD554: DC4A0C00 007C0000
	s_waitcnt lgkmcnt(0)                                       // 0000002CD55C: BF89FC07
	v_add_f32_e32 v1, v6, v7                                   // 0000002CD560: 06020F06
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002CD564: BF870091
	v_bfe_u32 v6, v1, 16, 1                                    // 0000002CD568: D6100006 02052101
	v_add3_u32 v1, v1, v6, 0x7fff                              // 0000002CD570: D6550001 03FE0D01 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002CD57C: BF8700A1
	v_and_b32_e32 v1, 0xffff0000, v1                           // 0000002CD580: 360202FF FFFF0000
	s_waitcnt vmcnt(1)                                         // 0000002CD588: BF8907F7
	v_dual_mul_f32 v1, 0xbfb8aa3b, v1 :: v_dual_lshlrev_b32 v8, 16, v8// 0000002CD58C: C8E202FF 01081090 BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(TRANS32_DEP_1)// 0000002CD598: BF8702A1
	v_exp_f32_e32 v1, v1                                       // 0000002CD59C: 7E024B01
	s_waitcnt vmcnt(0)                                         // 0000002CD5A0: BF8903F7
	v_dual_add_f32 v1, 1.0, v1 :: v_dual_lshlrev_b32 v0, 16, v0// 0000002CD5A4: C92202F2 01000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002CD5AC: BF870121
	v_div_scale_f32 v6, null, v1, v1, 1.0                      // 0000002CD5B0: D6FC7C06 03CA0301
	v_div_scale_f32 v11, vcc_lo, 1.0, v1, 1.0                  // 0000002CD5B8: D6FC6A0B 03CA02F2
	v_rcp_f32_e32 v7, v6                                       // 0000002CD5C0: 7E0E5506
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002CD5C4: BF870095
	v_fma_f32 v9, -v6, v7, 1.0                                 // 0000002CD5C8: D6130009 23CA0F06
	v_fmac_f32_e32 v7, v9, v7                                  // 0000002CD5D0: 560E0F09
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002CD5D4: BF870091
	v_mul_f32_e32 v9, v11, v7                                  // 0000002CD5D8: 10120F0B
	v_fma_f32 v13, -v6, v9, v11                                // 0000002CD5DC: D613000D 242E1306
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002CD5E4: BF870091
	v_fmac_f32_e32 v9, v13, v7                                 // 0000002CD5E8: 56120F0D
	v_fma_f32 v6, -v6, v9, v11                                 // 0000002CD5EC: D6130006 242E1306
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002CD5F4: BF870121
	v_div_fmas_f32 v6, v6, v7, v9                              // 0000002CD5F8: D6370006 04260F06
	v_lshlrev_b32_e32 v7, 16, v10                              // 0000002CD600: 300E1490
	v_div_fixup_f32 v1, v6, v1, 1.0                            // 0000002CD604: D6270001 03CA0306
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002CD60C: BF870091
	v_bfe_u32 v6, v1, 16, 1                                    // 0000002CD610: D6100006 02052101
	v_add3_u32 v1, v1, v6, 0x7fff                              // 0000002CD618: D6550001 03FE0D01 00007FFF
	v_lshlrev_b32_e32 v6, 16, v12                              // 0000002CD624: 300C1890
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002CD628: BF870092
	v_and_b32_e32 v1, 0xffff0000, v1                           // 0000002CD62C: 360202FF FFFF0000
	v_fma_f32 v6, v6, v1, 0                                    // 0000002CD634: D6130006 02020306
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002CD63C: BF870091
	v_fmac_f32_e32 v6, v7, v1                                  // 0000002CD640: 560C0307
	v_fmac_f32_e32 v6, v8, v1                                  // 0000002CD644: 560C0308
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002CD648: BF870091
	v_fmac_f32_e32 v6, v0, v1                                  // 0000002CD64C: 560C0300
	v_mul_f32_e32 v0, 0x3e800000, v6                           // 0000002CD650: 10000CFF 3E800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002CD658: BF870091
	v_bfe_u32 v1, v0, 16, 1                                    // 0000002CD65C: D6100001 02052100
	v_add3_u32 v6, v0, v1, 0x7fff                              // 0000002CD664: D6550006 03FE0300 00007FFF
	.long 0xd7006a01                                           // 0000002CD670: D7006A01
	v_cndmask_b32_e32 v1, 0x1000, v2, vcc_lo                   // 0000002CD674: 020204FF 00001000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002CD67C: BF870001
	v_add_co_ci_u32_e64 v2, null, 0, v3, vcc_lo                // 0000002CD680: D5207C02 01AA0680
	s_and_not1_b32 vcc_lo, exec_lo, s0                         // 0000002CD688: 916A007E
	global_store_d16_hi_b16 v[1:2], v6, off offset:1024        // 0000002CD68C: DC960400 007C0601
	s_cbranch_vccnz 13                                         // 0000002CD694: BFA4000D <_ZN7halogen12_GLOBAL__N_17k_hcup4ILi2ELi1EEEvPKhlllPKtS5_PtPf+0x8cc>
	.long 0xd7006a01                                           // 0000002CD698: D7006A01
	v_cndmask_b32_e32 v1, s10, v4, vcc_lo                      // 0000002CD69C: 0202080A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002CD6A0: BF870111
	v_add_co_ci_u32_e64 v2, null, s11, v5, vcc_lo              // 0000002CD6A4: D5207C02 01AA0A0B
	.long 0xd7006a01                                           // 0000002CD6AC: D7006A01
	v_cndmask_b32_e32 v1, 0x2000, v1, vcc_lo                   // 0000002CD6B0: 020202FF 00002000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002CD6B8: BF870001
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 0000002CD6BC: D5207C02 01AA0480
	global_store_b32 v[1:2], v0, off offset:2048               // 0000002CD6C4: DC6A0800 007C0001
	s_endpgm                                                   // 0000002CD6CC: BFB00000
		...

