00000000007f1b00 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi1ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi1ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[8:23], s[0:1], null                          // 0000007F1B00: F4100200 F8000000
	s_ashr_i32 s3, s2, 31                                      // 0000007F1B08: 86039F02
	v_lshrrev_b32_e32 v2, 2, v0                                // 0000007F1B0C: 32040082
	s_lshl_b64 s[2:3], s[2:3], 3                               // 0000007F1B10: 84828302
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007F1B14: BF8701A9
	v_dual_mov_b32 v24, s3 :: v_dual_and_b32 v1, 15, v0        // 0000007F1B18: CA240003 1800008F
	v_and_b32_e32 v30, 31, v0                                  // 0000007F1B20: 363C009F
	v_and_b32_e32 v2, 60, v2                                   // 0000007F1B24: 360404BC
	v_lshlrev_b32_e32 v7, 2, v0                                // 0000007F1B28: 300E0082
	s_delay_alu instid0(VALU_DEP_4)                            // 0000007F1B2C: BF870004
	v_lshlrev_b32_e32 v1, 2, v1                                // 0000007F1B30: 30020282
	.long 0x7f0c3880                                           // 0000007F1B34: 7F0C3880
	s_waitcnt lgkmcnt(0)                                       // 0000007F1B38: BF89FC07
	s_clause 0x1                                               // 0000007F1B3C: BF850001
	global_load_b32 v3, v1, s[8:9]                             // 0000007F1B40: DC520000 03080001
	global_load_b32 v4, v2, s[8:9]                             // 0000007F1B48: DC520000 04080002
	v_lshrrev_b32_e32 v1, 5, v0                                // 0000007F1B50: 32020085
	s_add_u32 s24, s8, s20                                     // 0000007F1B54: 80181408
	s_addc_u32 s25, s9, s21                                    // 0000007F1B58: 82191509
	s_ashr_i32 s4, s15, 31                                     // 0000007F1B5C: 86049F0F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000007F1B60: BF8704A1
	v_or_b32_e32 v23, s2, v1                                   // 0000007F1B64: 382E0202
	s_lshr_b32 s4, s4, 27                                      // 0000007F1B68: 85049B04
	s_add_u32 s4, s14, s4                                      // 0000007F1B6C: 8004040E
	s_addc_u32 s5, s15, 0                                      // 0000007F1B70: 8205800F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000007F1B74: BF8704A1
	.long 0xd4540002                                           // 0000007F1B78: D4540002
	v_cndmask_b32_e32 v1, s16, v23, vcc_lo                     // 0000007F1B7C: 02022E10
	s_lshr_b64 s[6:7], s[4:5], 5                               // 0000007F1B80: 85868504
	s_cmpk_lt_i32 s6, 0x101                                    // 0000007F1B84: B3860101
	.long 0xd4440004                                           // 0000007F1B88: D4440004
	v_cndmask_b32_e32 v1, s6, v30, vcc_lo                      // 0000007F1B8C: 02023C06
	v_cndmask_b32_e64 v2, 0, v23, s2                           // 0000007F1B90: D5010002 000A2E80
	v_cndmask_b32_e64 v5, 0, s3, s2                            // 0000007F1B98: D5010005 00080680
	s_cselect_b32 s3, -1, 0                                    // 0000007F1BA0: 980380C1
	s_cmpk_gt_i32 s6, 0x100                                    // 0000007F1BA4: B2860100
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000007F1BA8: BF8704B2
	.long 0xd72c0008                                           // 0000007F1BAC: D72C0008
	v_cndmask_b32_e32 v1, s23, v2, vcc_lo                      // 0000007F1BB0: 02020417
	v_mad_u64_u32 v[0:1], null, s22, v2, 0                     // 0000007F1BB4: D6FE7C00 02020416
	s_cselect_b32 s7, -1, 0                                    // 0000007F1BBC: 980780C1
	s_and_b32 vcc_lo, exec_lo, s7                              // 0000007F1BC0: 8B6A077E
	s_waitcnt vmcnt(1)                                         // 0000007F1BC4: BF8907F7
	v_bfe_u32 v9, v3, 16, 1                                    // 0000007F1BC8: D6100009 02052103
	s_waitcnt vmcnt(0)                                         // 0000007F1BD0: BF8903F7
	v_bfe_u32 v10, v4, 16, 1                                   // 0000007F1BD4: D610000A 02052104
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007F1BDC: BF8701A2
	v_add3_u32 v3, v3, v9, 0x7fff                              // 0000007F1BE0: D6550003 03FE1303 00007FFF
	.long 0xd72c0009                                           // 0000007F1BEC: D72C0009
	v_cndmask_b32_e32 v1, s22, v5, vcc_lo                      // 0000007F1BF0: 02020A16
	v_add3_u32 v4, v4, v10, 0x7fff                             // 0000007F1BF4: D6550004 03FE1504 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000007F1C00: BF870223
	.long 0x7e0c3983                                           // 0000007F1C04: 7E0C3983
	.long 0xd7000503                                           // 0000007F1C08: D7000503
	v_cndmask_b32_e32 v1, s24, v0, vcc_lo                      // 0000007F1C0C: 02020018
	v_add3_u32 v1, v1, v9, v8                                  // 0000007F1C10: D6550001 04221301
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007F1C18: BF870113
	v_and_or_b32 v6, 0xffff0000, v4, v6                        // 0000007F1C1C: D6570006 041A08FF FFFF0000
	v_add_co_ci_u32_e64 v4, null, s25, v1, s5                  // 0000007F1C28: D5207C04 00160219
	ds_store_b32 v7, v6                                        // 0000007F1C30: D8340000 00000607
	s_waitcnt lgkmcnt(0)                                       // 0000007F1C38: BF89FC07
	s_barrier                                                  // 0000007F1C3C: BFBD0000
	buffer_gl0_inv                                             // 0000007F1C40: E0AC0000 00000000
	s_cbranch_vccnz 146                                        // 0000007F1C48: BFA40092 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi1ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x394>
	v_dual_mov_b32 v8, 0 :: v_dual_mov_b32 v7, 0               // 0000007F1C4C: CA100080 08060080
	s_and_saveexec_b32 s5, s4                                  // 0000007F1C54: BE852004
	s_cbranch_execz 10                                         // 0000007F1C58: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi1ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x184>
	v_lshlrev_b32_e32 v6, 1, v30                               // 0000007F1C5C: 300C3C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007F1C60: BF870091
	.long 0xd7006a06                                           // 0000007F1C64: D7006A06
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 0000007F1C68: 02020D03
	v_add_co_ci_u32_e64 v7, null, 0, v4, vcc_lo                // 0000007F1C6C: D5207C07 01AA0880
	global_load_d16_b16 v6, v[6:7], off                        // 0000007F1C74: DC820000 067C0006
	s_waitcnt vmcnt(0)                                         // 0000007F1C7C: BF8903F7
	v_cvt_f32_f16_e32 v7, v6                                   // 0000007F1C80: 7E0E1706
	s_or_b32 exec_lo, exec_lo, s5                              // 0000007F1C84: 8C7E057E
	v_or_b32_e32 v6, 32, v30                                   // 0000007F1C88: 380C3CA0
	s_mov_b32 s4, exec_lo                                      // 0000007F1C8C: BE84007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007F1C90: BF870001
	.long 0xd4c4007e                                           // 0000007F1C94: D4C4007E
	v_cndmask_b32_e32 v1, s6, v6, vcc_lo                       // 0000007F1C98: 02020C06
	s_cbranch_execz 10                                         // 0000007F1C9C: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi1ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x1c8>
	v_lshlrev_b32_e32 v6, 1, v6                                // 0000007F1CA0: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007F1CA4: BF870091
	.long 0xd7006a08                                           // 0000007F1CA8: D7006A08
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 0000007F1CAC: 02020D03
	v_add_co_ci_u32_e64 v9, null, 0, v4, vcc_lo                // 0000007F1CB0: D5207C09 01AA0880
	global_load_d16_b16 v6, v[8:9], off                        // 0000007F1CB8: DC820000 067C0008
	s_waitcnt vmcnt(0)                                         // 0000007F1CC0: BF8903F7
	v_cvt_f32_f16_e32 v8, v6                                   // 0000007F1CC4: 7E101706
	s_or_b32 exec_lo, exec_lo, s4                              // 0000007F1CC8: 8C7E047E
	v_or_b32_e32 v6, 64, v30                                   // 0000007F1CCC: 380C3CC0
	v_dual_mov_b32 v10, 0 :: v_dual_mov_b32 v9, 0              // 0000007F1CD0: CA100080 0A080080
	s_mov_b32 s4, exec_lo                                      // 0000007F1CD8: BE84007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007F1CDC: BF870002
	.long 0xd4c4007e                                           // 0000007F1CE0: D4C4007E
	v_cndmask_b32_e32 v1, s6, v6, vcc_lo                       // 0000007F1CE4: 02020C06
	s_cbranch_execz 10                                         // 0000007F1CE8: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi1ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x214>
	v_lshlrev_b32_e32 v6, 1, v6                                // 0000007F1CEC: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007F1CF0: BF870091
	.long 0xd7006a0b                                           // 0000007F1CF4: D7006A0B
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 0000007F1CF8: 02020D03
	v_add_co_ci_u32_e64 v12, null, 0, v4, vcc_lo               // 0000007F1CFC: D5207C0C 01AA0880
	global_load_d16_b16 v6, v[11:12], off                      // 0000007F1D04: DC820000 067C000B
	s_waitcnt vmcnt(0)                                         // 0000007F1D0C: BF8903F7
	v_cvt_f32_f16_e32 v9, v6                                   // 0000007F1D10: 7E121706
	s_or_b32 exec_lo, exec_lo, s4                              // 0000007F1D14: 8C7E047E
	v_or_b32_e32 v6, 0x60, v30                                 // 0000007F1D18: 380C3CFF 00000060
	s_mov_b32 s4, exec_lo                                      // 0000007F1D20: BE84007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007F1D24: BF870001
	.long 0xd4c4007e                                           // 0000007F1D28: D4C4007E
	v_cndmask_b32_e32 v1, s6, v6, vcc_lo                       // 0000007F1D2C: 02020C06
	s_cbranch_execz 10                                         // 0000007F1D30: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi1ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x25c>
	v_lshlrev_b32_e32 v6, 1, v6                                // 0000007F1D34: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007F1D38: BF870091
	.long 0xd7006a0a                                           // 0000007F1D3C: D7006A0A
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 0000007F1D40: 02020D03
	v_add_co_ci_u32_e64 v11, null, 0, v4, vcc_lo               // 0000007F1D44: D5207C0B 01AA0880
	global_load_d16_b16 v6, v[10:11], off                      // 0000007F1D4C: DC820000 067C000A
	s_waitcnt vmcnt(0)                                         // 0000007F1D54: BF8903F7
	v_cvt_f32_f16_e32 v10, v6                                  // 0000007F1D58: 7E141706
	s_or_b32 exec_lo, exec_lo, s4                              // 0000007F1D5C: 8C7E047E
	v_or_b32_e32 v6, 0x80, v30                                 // 0000007F1D60: 380C3CFF 00000080
	v_dual_mov_b32 v12, 0 :: v_dual_mov_b32 v11, 0             // 0000007F1D68: CA100080 0C0A0080
	s_mov_b32 s4, exec_lo                                      // 0000007F1D70: BE84007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007F1D74: BF870002
	.long 0xd4c4007e                                           // 0000007F1D78: D4C4007E
	v_cndmask_b32_e32 v1, s6, v6, vcc_lo                       // 0000007F1D7C: 02020C06
	s_cbranch_execz 10                                         // 0000007F1D80: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi1ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x2ac>
	v_lshlrev_b32_e32 v6, 1, v6                                // 0000007F1D84: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007F1D88: BF870091
	.long 0xd7006a0d                                           // 0000007F1D8C: D7006A0D
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 0000007F1D90: 02020D03
	v_add_co_ci_u32_e64 v14, null, 0, v4, vcc_lo               // 0000007F1D94: D5207C0E 01AA0880
	global_load_d16_b16 v6, v[13:14], off                      // 0000007F1D9C: DC820000 067C000D
	s_waitcnt vmcnt(0)                                         // 0000007F1DA4: BF8903F7
	v_cvt_f32_f16_e32 v11, v6                                  // 0000007F1DA8: 7E161706
	s_or_b32 exec_lo, exec_lo, s4                              // 0000007F1DAC: 8C7E047E
	v_or_b32_e32 v6, 0xa0, v30                                 // 0000007F1DB0: 380C3CFF 000000A0
	s_mov_b32 s4, exec_lo                                      // 0000007F1DB8: BE84007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007F1DBC: BF870001
	.long 0xd4c4007e                                           // 0000007F1DC0: D4C4007E
	v_cndmask_b32_e32 v1, s6, v6, vcc_lo                       // 0000007F1DC4: 02020C06
	s_cbranch_execz 10                                         // 0000007F1DC8: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi1ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x2f4>
	v_lshlrev_b32_e32 v6, 1, v6                                // 0000007F1DCC: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007F1DD0: BF870091
	.long 0xd7006a0c                                           // 0000007F1DD4: D7006A0C
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 0000007F1DD8: 02020D03
	v_add_co_ci_u32_e64 v13, null, 0, v4, vcc_lo               // 0000007F1DDC: D5207C0D 01AA0880
	global_load_d16_b16 v6, v[12:13], off                      // 0000007F1DE4: DC820000 067C000C
	s_waitcnt vmcnt(0)                                         // 0000007F1DEC: BF8903F7
	v_cvt_f32_f16_e32 v12, v6                                  // 0000007F1DF0: 7E181706
	s_or_b32 exec_lo, exec_lo, s4                              // 0000007F1DF4: 8C7E047E
	v_or_b32_e32 v6, 0xc0, v30                                 // 0000007F1DF8: 380C3CFF 000000C0
	v_dual_mov_b32 v14, 0 :: v_dual_mov_b32 v13, 0             // 0000007F1E00: CA100080 0E0C0080
	s_mov_b32 s4, exec_lo                                      // 0000007F1E08: BE84007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007F1E0C: BF870002
	.long 0xd4c4007e                                           // 0000007F1E10: D4C4007E
	v_cndmask_b32_e32 v1, s6, v6, vcc_lo                       // 0000007F1E14: 02020C06
	s_cbranch_execz 10                                         // 0000007F1E18: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi1ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x344>
	v_lshlrev_b32_e32 v6, 1, v6                                // 0000007F1E1C: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007F1E20: BF870091
	.long 0xd7006a0f                                           // 0000007F1E24: D7006A0F
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 0000007F1E28: 02020D03
	v_add_co_ci_u32_e64 v16, null, 0, v4, vcc_lo               // 0000007F1E2C: D5207C10 01AA0880
	global_load_d16_b16 v6, v[15:16], off                      // 0000007F1E34: DC820000 067C000F
	s_waitcnt vmcnt(0)                                         // 0000007F1E3C: BF8903F7
	v_cvt_f32_f16_e32 v13, v6                                  // 0000007F1E40: 7E1A1706
	s_or_b32 exec_lo, exec_lo, s4                              // 0000007F1E44: 8C7E047E
	v_or_b32_e32 v6, 0xe0, v30                                 // 0000007F1E48: 380C3CFF 000000E0
	s_mov_b32 s4, exec_lo                                      // 0000007F1E50: BE84007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007F1E54: BF870001
	.long 0xd4c4007e                                           // 0000007F1E58: D4C4007E
	v_cndmask_b32_e32 v1, s6, v6, vcc_lo                       // 0000007F1E5C: 02020C06
	s_cbranch_execz 10                                         // 0000007F1E60: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi1ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x38c>
	v_lshlrev_b32_e32 v6, 1, v6                                // 0000007F1E64: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007F1E68: BF870091
	.long 0xd7006a0e                                           // 0000007F1E6C: D7006A0E
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 0000007F1E70: 02020D03
	v_add_co_ci_u32_e64 v15, null, 0, v4, vcc_lo               // 0000007F1E74: D5207C0F 01AA0880
	global_load_d16_b16 v6, v[14:15], off                      // 0000007F1E7C: DC820000 067C000E
	s_waitcnt vmcnt(0)                                         // 0000007F1E84: BF8903F7
	v_cvt_f32_f16_e32 v14, v6                                  // 0000007F1E88: 7E1C1706
	s_or_b32 exec_lo, exec_lo, s4                              // 0000007F1E8C: 8C7E047E
	s_branch 9                                                 // 0000007F1E90: BFA00009 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi1ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x3b8>
	v_mov_b32_e32 v7, 0                                        // 0000007F1E94: 7E0E0280
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007F1E98: BF870001
	v_mov_b32_e32 v8, v7                                       // 0000007F1E9C: 7E100307
	v_mov_b32_e32 v9, v7                                       // 0000007F1EA0: 7E120307
	v_mov_b32_e32 v10, v7                                      // 0000007F1EA4: 7E140307
	v_mov_b32_e32 v11, v7                                      // 0000007F1EA8: 7E160307
	v_mov_b32_e32 v12, v7                                      // 0000007F1EAC: 7E180307
	v_mov_b32_e32 v13, v7                                      // 0000007F1EB0: 7E1A0307
	v_mov_b32_e32 v14, v7                                      // 0000007F1EB4: 7E1C0307
	s_add_u32 s4, s8, s18                                      // 0000007F1EB8: 80041208
	s_addc_u32 s5, s9, s19                                     // 0000007F1EBC: 82051309
	s_lshr_b32 s18, s15, 31                                    // 0000007F1EC0: 85129F0F
	v_dual_mov_b32 v19, 0 :: v_dual_mov_b32 v44, 0             // 0000007F1EC4: CA100080 132C0080
	s_add_u32 s18, s14, s18                                    // 0000007F1ECC: 8012120E
	s_addc_u32 s19, s15, 0                                     // 0000007F1ED0: 8213800F
	v_dual_mov_b32 v31, 0 :: v_dual_mov_b32 v20, 0             // 0000007F1ED4: CA100080 1F140080
	s_ashr_i64 s[18:19], s[18:19], 1                           // 0000007F1EDC: 86928112
	v_cndmask_b32_e64 v32, 0, 1, s7                            // 0000007F1EE0: D5010020 001D0280
	v_mad_u64_u32 v[25:26], null, v2, s18, s[4:5]              // 0000007F1EE8: D6FE7C19 00102502
	.long 0xd72c0002                                           // 0000007F1EF0: D72C0002
	v_cndmask_b32_e32 v0, v2, v19, vcc_lo                      // 0000007F1EF4: 02002702
	.long 0xd72c0005                                           // 0000007F1EF8: D72C0005
	v_cndmask_b32_e32 v0, v5, v18, vcc_lo                      // 0000007F1EFC: 02002505
	.long 0xd4440004                                           // 0000007F1F00: D4440004
	v_cndmask_b32_e32 v1, s6, v30, vcc_lo                      // 0000007F1F04: 02023C06
	v_dual_mov_b32 v21, 0 :: v_dual_mov_b32 v22, 0             // 0000007F1F08: CA100080 15160080
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007F1F10: BF870003
	v_add3_u32 v33, v5, v26, v2                                // 0000007F1F14: D6550021 040A3505
	s_and_saveexec_b32 s5, s4                                  // 0000007F1F1C: BE852004
	s_cbranch_execz 21                                         // 0000007F1F20: BFA50015 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi1ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x478>
	v_lshlrev_b32_e32 v2, 4, v30                               // 0000007F1F24: 30043C84
	v_mov_b32_e32 v44, 0                                       // 0000007F1F28: 7E580280
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007F1F2C: BF870092
	.long 0xd7006a05                                           // 0000007F1F30: D7006A05
	v_cndmask_b32_e32 v1, v25, v2, vcc_lo                      // 0000007F1F34: 02020519
	v_add_co_ci_u32_e64 v6, null, 0, v33, vcc_lo               // 0000007F1F38: D5207C06 01AA4280
	s_and_not1_b32 vcc_lo, exec_lo, s7                         // 0000007F1F40: 916A077E
	global_load_b128 v[19:22], v[5:6], off                     // 0000007F1F44: DC5E0000 137C0005
	s_cbranch_vccnz 10                                         // 0000007F1F4C: BFA4000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi1ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x478>
	v_lshlrev_b32_e32 v2, 1, v30                               // 0000007F1F50: 30043C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007F1F54: BF870091
	.long 0xd7006a02                                           // 0000007F1F58: D7006A02
	v_cndmask_b32_e32 v1, v3, v2, vcc_lo                       // 0000007F1F5C: 02020503
	v_add_co_ci_u32_e64 v3, null, 0, v4, vcc_lo                // 0000007F1F60: D5207C03 01AA0880
	global_load_d16_b16 v2, v[2:3], off                        // 0000007F1F68: DC820000 027C0002
	s_waitcnt vmcnt(0)                                         // 0000007F1F70: BF8903F7
	v_cvt_f32_f16_e32 v44, v2                                  // 0000007F1F74: 7E581702
	s_or_b32 exec_lo, exec_lo, s5                              // 0000007F1F78: 8C7E057E
	v_dual_mov_b32 v34, 0 :: v_dual_mov_b32 v35, 0             // 0000007F1F7C: CA100080 22220080
	v_dual_mov_b32 v36, 0 :: v_dual_mov_b32 v37, 0             // 0000007F1F84: CA100080 24240080
	v_dual_mov_b32 v38, 0 :: v_dual_mov_b32 v39, 0             // 0000007F1F8C: CA100080 26260080
	v_mov_b32_e32 v40, 0                                       // 0000007F1F94: 7E500280
	s_and_saveexec_b32 s5, s4                                  // 0000007F1F98: BE852004
	s_cbranch_execz 685                                        // 0000007F1F9C: BFA502AD <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi1ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0xf54>
	v_dual_mov_b32 v27, 0 :: v_dual_lshlrev_b32 v2, 1, v30     // 0000007F1FA0: CA220080 1B023C81
	.long 0xd7006a00                                           // 0000007F1FA8: D7006A00
	v_cndmask_b32_e32 v1, s20, v0, vcc_lo                      // 0000007F1FAC: 02020014
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007F1FB0: BF870191
	v_add_co_ci_u32_e64 v1, null, s21, v1, vcc_lo              // 0000007F1FB4: D5207C01 01AA0215
	v_dual_mov_b32 v39, v27 :: v_dual_lshlrev_b32 v26, 5, v30  // 0000007F1FBC: CA22011B 271A3C85
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007F1FC4: BF870093
	.long 0xd7006a00                                           // 0000007F1FC8: D7006A00
	v_cndmask_b32_e32 v1, v0, v2, vcc_lo                       // 0000007F1FCC: 02020500
	v_add_co_ci_u32_e64 v1, null, 0, v1, vcc_lo                // 0000007F1FD0: D5207C01 01AA0280
	v_lshl_or_b32 v41, v30, 4, 0x200                           // 0000007F1FD8: D6560029 03FD091E 00000200
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007F1FE4: BF870093
	.long 0xd7006a00                                           // 0000007F1FE8: D7006A00
	v_cndmask_b32_e32 v1, s8, v0, vcc_lo                       // 0000007F1FEC: 02020008
	v_add_co_ci_u32_e64 v1, null, s9, v1, vcc_lo               // 0000007F1FF0: D5207C01 01AA0209
	v_dual_mov_b32 v42, v30 :: v_dual_mov_b32 v37, v27         // 0000007F1FF8: CA10011E 2A24011B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007F2000: BF870093
	.long 0xd7006a1c                                           // 0000007F2004: D7006A1C
	v_cndmask_b32_e32 v0, v0, v192, vcc_lo                     // 0000007F2008: 02018100
	v_add_co_ci_u32_e64 v29, null, 0, v1, vcc_lo               // 0000007F200C: D5207C1D 01AA0280
	v_dual_mov_b32 v40, v27 :: v_dual_mov_b32 v43, v44         // 0000007F2014: CA10011B 282A012C
	v_mov_b32_e32 v38, v27                                     // 0000007F201C: 7E4C031B
	v_mov_b32_e32 v36, v27                                     // 0000007F2020: 7E48031B
	v_mov_b32_e32 v35, v27                                     // 0000007F2024: 7E46031B
	v_mov_b32_e32 v34, v27                                     // 0000007F2028: 7E44031B
	v_mov_b32_e32 v31, v27                                     // 0000007F202C: 7E3E031B
	s_mul_i32 s4, s15, 6                                       // 0000007F2030: 9604860F
	s_mul_hi_u32 s7, s14, 6                                    // 0000007F2034: 9687860E
	s_lshl_b64 s[18:19], s[14:15], 2                           // 0000007F2038: 8492820E
	s_add_i32 s7, s7, s4                                       // 0000007F203C: 81070407
	s_mul_i32 s21, s14, 6                                      // 0000007F2040: 9615860E
	s_mov_b32 s20, 0                                           // 0000007F2044: BE940080
	s_lshl_b64 s[8:9], s[14:15], 1                             // 0000007F2048: 8488810E
	s_branch 612                                               // 0000007F204C: BFA00264 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi1ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0xee0>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000007F2050: 8C7E0E7E
	v_cndmask_b32_e64 v44, v44, v7, s3                         // 0000007F2054: D501002C 000E0F2C
	v_cndmask_b32_e64 v1, v8, v9, s3                           // 0000007F205C: D5010001 000E1308
	v_cndmask_b32_e64 v0, v7, v8, s3                           // 0000007F2064: D5010000 000E1107
	v_dual_mov_b32 v7, v14 :: v_dual_and_b32 v8, 0xff, v19     // 0000007F206C: CA24010E 070826FF 000000FF
	v_cndmask_b32_e64 v6, v13, v14, s3                         // 0000007F2078: D5010006 000E1D0D
	v_cndmask_b32_e64 v5, v12, v13, s3                         // 0000007F2080: D5010005 000E1B0C
	v_cndmask_b32_e64 v4, v11, v12, s3                         // 0000007F2088: D5010004 000E190B
	v_cndmask_b32_e64 v3, v10, v11, s3                         // 0000007F2090: D5010003 000E170A
	v_lshlrev_b32_e32 v8, 2, v8                                // 0000007F2098: 30101082
	v_cndmask_b32_e64 v2, v9, v10, s3                          // 0000007F209C: D5010002 000E1509
	s_and_b32 s4, exec_lo, s4                                  // 0000007F20A4: 8B04047E
	v_add_nc_u32_e32 v41, 0x200, v41                           // 0000007F20A8: 4A5252FF 00000200
	s_or_b32 s20, s4, s20                                      // 0000007F20B0: 8C141404
	ds_load_b32 v14, v8                                        // 0000007F20B4: D8D80000 0E000008
	v_lshrrev_b32_e32 v8, 6, v19                               // 0000007F20BC: 32102686
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007F20C0: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 0000007F20C4: 361010FF 000003FC
	ds_load_b32 v55, v8                                        // 0000007F20CC: D8D80000 37000008
	v_lshrrev_b32_e32 v8, 14, v19                              // 0000007F20D4: 3210268E
	v_and_b32_e32 v8, 0x3fc, v8                                // 0000007F20D8: 361010FF 000003FC
	ds_load_b32 v56, v8                                        // 0000007F20E0: D8D80000 38000008
	v_lshrrev_b32_e32 v8, 22, v19                              // 0000007F20E8: 32102696
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007F20EC: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 0000007F20F0: 361010FF 000003FC
	ds_load_b32 v57, v8                                        // 0000007F20F8: D8D80000 39000008
	v_and_b32_e32 v8, 0xff, v20                                // 0000007F2100: 361028FF 000000FF
	v_lshlrev_b32_e32 v8, 2, v8                                // 0000007F2108: 30101082
	ds_load_b32 v58, v8                                        // 0000007F210C: D8D80000 3A000008
	v_lshrrev_b32_e32 v8, 6, v20                               // 0000007F2114: 32102886
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007F2118: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 0000007F211C: 361010FF 000003FC
	ds_load_b32 v59, v8                                        // 0000007F2124: D8D80000 3B000008
	v_lshrrev_b32_e32 v8, 14, v20                              // 0000007F212C: 3210288E
	v_and_b32_e32 v8, 0x3fc, v8                                // 0000007F2130: 361010FF 000003FC
	ds_load_b32 v60, v8                                        // 0000007F2138: D8D80000 3C000008
	v_lshrrev_b32_e32 v8, 22, v20                              // 0000007F2140: 32102896
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007F2144: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 0000007F2148: 361010FF 000003FC
	ds_load_b32 v61, v8                                        // 0000007F2150: D8D80000 3D000008
	v_and_b32_e32 v8, 0xff, v21                                // 0000007F2158: 36102AFF 000000FF
	v_lshlrev_b32_e32 v8, 2, v8                                // 0000007F2160: 30101082
	ds_load_b32 v62, v8                                        // 0000007F2164: D8D80000 3E000008
	v_lshrrev_b32_e32 v8, 6, v21                               // 0000007F216C: 32102A86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007F2170: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 0000007F2174: 361010FF 000003FC
	ds_load_b32 v63, v8                                        // 0000007F217C: D8D80000 3F000008
	v_lshrrev_b32_e32 v8, 14, v21                              // 0000007F2184: 32102A8E
	v_and_b32_e32 v8, 0x3fc, v8                                // 0000007F2188: 361010FF 000003FC
	ds_load_b32 v64, v8                                        // 0000007F2190: D8D80000 40000008
	v_lshrrev_b32_e32 v8, 22, v21                              // 0000007F2198: 32102A96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007F219C: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 0000007F21A0: 361010FF 000003FC
	ds_load_b32 v65, v8                                        // 0000007F21A8: D8D80000 41000008
	v_and_b32_e32 v8, 0xff, v22                                // 0000007F21B0: 36102CFF 000000FF
	v_lshlrev_b32_e32 v8, 2, v8                                // 0000007F21B8: 30101082
	ds_load_b32 v66, v8                                        // 0000007F21BC: D8D80000 42000008
	v_lshrrev_b32_e32 v8, 6, v22                               // 0000007F21C4: 32102C86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007F21C8: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 0000007F21CC: 361010FF 000003FC
	ds_load_b32 v67, v8                                        // 0000007F21D4: D8D80000 43000008
	v_lshrrev_b32_e32 v8, 14, v22                              // 0000007F21DC: 32102C8E
	v_and_b32_e32 v8, 0x3fc, v8                                // 0000007F21E0: 361010FF 000003FC
	ds_load_b32 v68, v8                                        // 0000007F21E8: D8D80000 44000008
	v_lshrrev_b32_e32 v8, 22, v22                              // 0000007F21F0: 32102C96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000007F21F4: BF870141
	v_and_b32_e32 v8, 0x3fc, v8                                // 0000007F21F8: 361010FF 000003FC
	ds_load_b32 v69, v8                                        // 0000007F2200: D8D80000 45000008
	.long 0xd73c0008                                           // 0000007F2208: D73C0008
	v_cndmask_b32_e32 v1, 1, v26, vcc_lo                       // 0000007F220C: 02023481
	v_add_nc_u32_e32 v26, 0x400, v26                           // 0000007F2210: 4A3434FF 00000400
	.long 0xd7006a0c                                           // 0000007F2218: D7006A0C
	v_cndmask_b32_e32 v1, s10, v8, vcc_lo                      // 0000007F221C: 0202100A
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007F2220: BF870001
	v_add_co_ci_u32_e64 v13, null, s11, v9, vcc_lo             // 0000007F2224: D5207C0D 01AA120B
	s_clause 0x3                                               // 0000007F222C: BF850003
	global_load_b128 v[8:11], v[12:13], off                    // 0000007F2230: DC5E0000 087C000C
	global_load_b128 v[19:22], v[12:13], off offset:16         // 0000007F2238: DC5E0010 137C000C
	global_load_b128 v[45:48], v[12:13], off offset:32         // 0000007F2240: DC5E0020 2D7C000C
	global_load_b128 v[49:52], v[12:13], off offset:48         // 0000007F2248: DC5E0030 317C000C
	s_waitcnt vmcnt(3) lgkmcnt(15)                             // 0000007F2250: BF890CF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 0000007F2254: CC1A4008 1A021D08
	s_waitcnt lgkmcnt(14)                                      // 0000007F225C: BF89FCE7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007F2260: BF8700A1
	v_dot2_f32_bf16 v8, v9, v55, v8                            // 0000007F2264: CC1A4008 1C226F09
	s_waitcnt lgkmcnt(13)                                      // 0000007F226C: BF89FCD7
	v_dot2_f32_bf16 v8, v10, v56, v8                           // 0000007F2270: CC1A4008 1C22710A
	s_waitcnt lgkmcnt(12)                                      // 0000007F2278: BF89FCC7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007F227C: BF8700A1
	v_dot2_f32_bf16 v8, v11, v57, v8                           // 0000007F2280: CC1A4008 1C22730B
	s_waitcnt vmcnt(2) lgkmcnt(11)                             // 0000007F2288: BF8908B7
	v_dot2_f32_bf16 v8, v19, v58, v8                           // 0000007F228C: CC1A4008 1C227513
	s_waitcnt lgkmcnt(10)                                      // 0000007F2294: BF89FCA7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007F2298: BF8700A1
	v_dot2_f32_bf16 v8, v20, v59, v8                           // 0000007F229C: CC1A4008 1C227714
	s_waitcnt lgkmcnt(9)                                       // 0000007F22A4: BF89FC97
	v_dot2_f32_bf16 v8, v21, v60, v8                           // 0000007F22A8: CC1A4008 1C227915
	s_waitcnt lgkmcnt(8)                                       // 0000007F22B0: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007F22B4: BF8700A1
	v_dot2_f32_bf16 v8, v22, v61, v8                           // 0000007F22B8: CC1A4008 1C227B16
	s_waitcnt vmcnt(1) lgkmcnt(7)                              // 0000007F22C0: BF890477
	v_dot2_f32_bf16 v8, v45, v62, v8                           // 0000007F22C4: CC1A4008 1C227D2D
	s_waitcnt lgkmcnt(6)                                       // 0000007F22CC: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007F22D0: BF8700A1
	v_dot2_f32_bf16 v8, v46, v63, v8                           // 0000007F22D4: CC1A4008 1C227F2E
	s_waitcnt lgkmcnt(5)                                       // 0000007F22DC: BF89FC57
	v_dot2_f32_bf16 v8, v47, v64, v8                           // 0000007F22E0: CC1A4008 1C22812F
	s_waitcnt lgkmcnt(4)                                       // 0000007F22E8: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007F22EC: BF8700A1
	v_dot2_f32_bf16 v8, v48, v65, v8                           // 0000007F22F0: CC1A4008 1C228330
	s_waitcnt vmcnt(0) lgkmcnt(3)                              // 0000007F22F8: BF890037
	v_dot2_f32_bf16 v8, v49, v66, v8                           // 0000007F22FC: CC1A4008 1C228531
	.long 0xd7006a31                                           // 0000007F2304: D7006A31
	v_cndmask_b32_e32 v0, v12, v8, vcc_lo                      // 0000007F2308: 0200110C
	s_waitcnt lgkmcnt(2)                                       // 0000007F230C: BF89FC27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000007F2310: BF8701C2
	v_dot2_f32_bf16 v8, v50, v67, v8                           // 0000007F2314: CC1A4008 1C228732
	v_add_co_ci_u32_e64 v50, null, s9, v13, vcc_lo             // 0000007F231C: D5207C32 01AA1A09
	.long 0xd7006a35                                           // 0000007F2324: D7006A35
	v_cndmask_b32_e32 v0, v12, v18, vcc_lo                     // 0000007F2328: 0200250C
	s_waitcnt lgkmcnt(1)                                       // 0000007F232C: BF89FC17
	v_dot2_f32_bf16 v8, v51, v68, v8                           // 0000007F2330: CC1A4008 1C228933
	v_add_co_ci_u32_e64 v54, null, s19, v13, vcc_lo            // 0000007F2338: D5207C36 01AA1A13
	.long 0xd7006a0c                                           // 0000007F2340: D7006A0C
	v_cndmask_b32_e32 v0, v12, v21, vcc_lo                     // 0000007F2344: 02002B0C
	s_waitcnt lgkmcnt(0)                                       // 0000007F2348: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000007F234C: BF870123
	v_dot2_f32_bf16 v8, v52, v69, v8                           // 0000007F2350: CC1A4008 1C228B34
	v_add_co_ci_u32_e64 v13, null, s7, v13, vcc_lo             // 0000007F2358: D5207C0D 01AA1A07
	v_fmac_f32_e32 v40, v44, v8                                // 0000007F2360: 5650112C
	s_clause 0x3                                               // 0000007F2364: BF850003
	global_load_b128 v[8:11], v[49:50], off                    // 0000007F2368: DC5E0000 087C0031
	global_load_b128 v[19:22], v[49:50], off offset:16         // 0000007F2370: DC5E0010 137C0031
	global_load_b128 v[45:48], v[49:50], off offset:32         // 0000007F2378: DC5E0020 2D7C0031
	global_load_b128 v[49:52], v[49:50], off offset:48         // 0000007F2380: DC5E0030 317C0031
	s_waitcnt vmcnt(3)                                         // 0000007F2388: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 0000007F238C: CC1A4008 1A021D08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007F2394: BF870091
	v_dot2_f32_bf16 v8, v9, v55, v8                            // 0000007F2398: CC1A4008 1C226F09
	v_dot2_f32_bf16 v8, v10, v56, v8                           // 0000007F23A0: CC1A4008 1C22710A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007F23A8: BF8700A1
	v_dot2_f32_bf16 v8, v11, v57, v8                           // 0000007F23AC: CC1A4008 1C22730B
	s_waitcnt vmcnt(2)                                         // 0000007F23B4: BF890BF7
	v_dot2_f32_bf16 v8, v19, v58, v8                           // 0000007F23B8: CC1A4008 1C227513
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007F23C0: BF870091
	v_dot2_f32_bf16 v8, v20, v59, v8                           // 0000007F23C4: CC1A4008 1C227714
	v_dot2_f32_bf16 v8, v21, v60, v8                           // 0000007F23CC: CC1A4008 1C227915
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007F23D4: BF8700A1
	v_dot2_f32_bf16 v8, v22, v61, v8                           // 0000007F23D8: CC1A4008 1C227B16
	s_waitcnt vmcnt(1)                                         // 0000007F23E0: BF8907F7
	v_dot2_f32_bf16 v8, v45, v62, v8                           // 0000007F23E4: CC1A4008 1C227D2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007F23EC: BF870091
	v_dot2_f32_bf16 v8, v46, v63, v8                           // 0000007F23F0: CC1A4008 1C227F2E
	v_dot2_f32_bf16 v8, v47, v64, v8                           // 0000007F23F8: CC1A4008 1C22812F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007F2400: BF8700A1
	v_dot2_f32_bf16 v8, v48, v65, v8                           // 0000007F2404: CC1A4008 1C228330
	s_waitcnt vmcnt(0)                                         // 0000007F240C: BF8903F7
	v_dot2_f32_bf16 v8, v49, v66, v8                           // 0000007F2410: CC1A4008 1C228531
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007F2418: BF870091
	v_dot2_f32_bf16 v8, v50, v67, v8                           // 0000007F241C: CC1A4008 1C228732
	v_dot2_f32_bf16 v8, v51, v68, v8                           // 0000007F2424: CC1A4008 1C228933
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007F242C: BF870091
	v_dot2_f32_bf16 v8, v52, v69, v8                           // 0000007F2430: CC1A4008 1C228B34
	v_fmac_f32_e32 v39, v44, v8                                // 0000007F2438: 564E112C
	s_clause 0x3                                               // 0000007F243C: BF850003
	global_load_b128 v[8:11], v[53:54], off                    // 0000007F2440: DC5E0000 087C0035
	global_load_b128 v[19:22], v[53:54], off offset:16         // 0000007F2448: DC5E0010 137C0035
	global_load_b128 v[45:48], v[53:54], off offset:32         // 0000007F2450: DC5E0020 2D7C0035
	global_load_b128 v[49:52], v[53:54], off offset:48         // 0000007F2458: DC5E0030 317C0035
	.long 0xd7006a35                                           // 0000007F2460: D7006A35
	v_cndmask_b32_e32 v0, v53, v18, vcc_lo                     // 0000007F2464: 02002535
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007F2468: BF8700B1
	v_add_co_ci_u32_e64 v54, null, s19, v54, vcc_lo            // 0000007F246C: D5207C36 01AA6C13
	s_waitcnt vmcnt(3)                                         // 0000007F2474: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 0000007F2478: CC1A4008 1A021D08
	v_dot2_f32_bf16 v8, v9, v55, v8                            // 0000007F2480: CC1A4008 1C226F09
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007F2488: BF870091
	v_dot2_f32_bf16 v8, v10, v56, v8                           // 0000007F248C: CC1A4008 1C22710A
	v_dot2_f32_bf16 v8, v11, v57, v8                           // 0000007F2494: CC1A4008 1C22730B
	s_waitcnt vmcnt(2)                                         // 0000007F249C: BF890BF7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007F24A0: BF870091
	v_dot2_f32_bf16 v8, v19, v58, v8                           // 0000007F24A4: CC1A4008 1C227513
	v_dot2_f32_bf16 v8, v20, v59, v8                           // 0000007F24AC: CC1A4008 1C227714
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007F24B4: BF870091
	v_dot2_f32_bf16 v8, v21, v60, v8                           // 0000007F24B8: CC1A4008 1C227915
	v_dot2_f32_bf16 v8, v22, v61, v8                           // 0000007F24C0: CC1A4008 1C227B16
	s_waitcnt vmcnt(1)                                         // 0000007F24C8: BF8907F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007F24CC: BF870091
	v_dot2_f32_bf16 v8, v45, v62, v8                           // 0000007F24D0: CC1A4008 1C227D2D
	v_dot2_f32_bf16 v8, v46, v63, v8                           // 0000007F24D8: CC1A4008 1C227F2E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007F24E0: BF870091
	v_dot2_f32_bf16 v8, v47, v64, v8                           // 0000007F24E4: CC1A4008 1C22812F
	v_dot2_f32_bf16 v8, v48, v65, v8                           // 0000007F24EC: CC1A4008 1C228330
	s_waitcnt vmcnt(0)                                         // 0000007F24F4: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007F24F8: BF870091
	v_dot2_f32_bf16 v8, v49, v66, v8                           // 0000007F24FC: CC1A4008 1C228531
	v_dot2_f32_bf16 v8, v50, v67, v8                           // 0000007F2504: CC1A4008 1C228732
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007F250C: BF870091
	v_dot2_f32_bf16 v8, v51, v68, v8                           // 0000007F2510: CC1A4008 1C228933
	v_dot2_f32_bf16 v8, v52, v69, v8                           // 0000007F2518: CC1A4008 1C228B34
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007F2520: BF870001
	v_fmac_f32_e32 v38, v44, v8                                // 0000007F2524: 564C112C
	s_clause 0x3                                               // 0000007F2528: BF850003
	global_load_b128 v[8:11], v[12:13], off                    // 0000007F252C: DC5E0000 087C000C
	global_load_b128 v[19:22], v[12:13], off offset:16         // 0000007F2534: DC5E0010 137C000C
	global_load_b128 v[45:48], v[12:13], off offset:32         // 0000007F253C: DC5E0020 2D7C000C
	global_load_b128 v[49:52], v[12:13], off offset:48         // 0000007F2544: DC5E0030 317C000C
	.long 0xd7006a0c                                           // 0000007F254C: D7006A0C
	v_cndmask_b32_e32 v0, v12, v18, vcc_lo                     // 0000007F2550: 0200250C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007F2554: BF8700B1
	v_add_co_ci_u32_e64 v13, null, s19, v13, vcc_lo            // 0000007F2558: D5207C0D 01AA1A13
	s_waitcnt vmcnt(3)                                         // 0000007F2560: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 0000007F2564: CC1A4008 1A021D08
	v_dot2_f32_bf16 v8, v9, v55, v8                            // 0000007F256C: CC1A4008 1C226F09
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007F2574: BF870091
	v_dot2_f32_bf16 v8, v10, v56, v8                           // 0000007F2578: CC1A4008 1C22710A
	v_dot2_f32_bf16 v8, v11, v57, v8                           // 0000007F2580: CC1A4008 1C22730B
	s_waitcnt vmcnt(2)                                         // 0000007F2588: BF890BF7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007F258C: BF870091
	v_dot2_f32_bf16 v8, v19, v58, v8                           // 0000007F2590: CC1A4008 1C227513
	v_dot2_f32_bf16 v8, v20, v59, v8                           // 0000007F2598: CC1A4008 1C227714
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007F25A0: BF870091
	v_dot2_f32_bf16 v8, v21, v60, v8                           // 0000007F25A4: CC1A4008 1C227915
	v_dot2_f32_bf16 v8, v22, v61, v8                           // 0000007F25AC: CC1A4008 1C227B16
	s_waitcnt vmcnt(1)                                         // 0000007F25B4: BF8907F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007F25B8: BF870091
	v_dot2_f32_bf16 v8, v45, v62, v8                           // 0000007F25BC: CC1A4008 1C227D2D
	v_dot2_f32_bf16 v8, v46, v63, v8                           // 0000007F25C4: CC1A4008 1C227F2E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007F25CC: BF870091
	v_dot2_f32_bf16 v8, v47, v64, v8                           // 0000007F25D0: CC1A4008 1C22812F
	v_dot2_f32_bf16 v8, v48, v65, v8                           // 0000007F25D8: CC1A4008 1C228330
	s_waitcnt vmcnt(0)                                         // 0000007F25E0: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007F25E4: BF870091
	v_dot2_f32_bf16 v8, v49, v66, v8                           // 0000007F25E8: CC1A4008 1C228531
	v_dot2_f32_bf16 v8, v50, v67, v8                           // 0000007F25F0: CC1A4008 1C228732
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007F25F8: BF870091
	v_dot2_f32_bf16 v8, v51, v68, v8                           // 0000007F25FC: CC1A4008 1C228933
	v_dot2_f32_bf16 v8, v52, v69, v8                           // 0000007F2604: CC1A4008 1C228B34
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007F260C: BF870001
	v_fmac_f32_e32 v37, v44, v8                                // 0000007F2610: 564A112C
	s_clause 0x3                                               // 0000007F2614: BF850003
	global_load_b128 v[8:11], v[53:54], off                    // 0000007F2618: DC5E0000 087C0035
	global_load_b128 v[19:22], v[53:54], off offset:16         // 0000007F2620: DC5E0010 137C0035
	global_load_b128 v[45:48], v[53:54], off offset:32         // 0000007F2628: DC5E0020 2D7C0035
	global_load_b128 v[49:52], v[53:54], off offset:48         // 0000007F2630: DC5E0030 317C0035
	s_waitcnt vmcnt(3)                                         // 0000007F2638: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 0000007F263C: CC1A4008 1A021D08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007F2644: BF870091
	v_dot2_f32_bf16 v8, v9, v55, v8                            // 0000007F2648: CC1A4008 1C226F09
	v_dot2_f32_bf16 v8, v10, v56, v8                           // 0000007F2650: CC1A4008 1C22710A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007F2658: BF8700A1
	v_dot2_f32_bf16 v8, v11, v57, v8                           // 0000007F265C: CC1A4008 1C22730B
	s_waitcnt vmcnt(2)                                         // 0000007F2664: BF890BF7
	v_dot2_f32_bf16 v8, v19, v58, v8                           // 0000007F2668: CC1A4008 1C227513
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007F2670: BF870091
	v_dot2_f32_bf16 v8, v20, v59, v8                           // 0000007F2674: CC1A4008 1C227714
	v_dot2_f32_bf16 v8, v21, v60, v8                           // 0000007F267C: CC1A4008 1C227915
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007F2684: BF8700A1
	v_dot2_f32_bf16 v8, v22, v61, v8                           // 0000007F2688: CC1A4008 1C227B16
	s_waitcnt vmcnt(1)                                         // 0000007F2690: BF8907F7
	v_dot2_f32_bf16 v8, v45, v62, v8                           // 0000007F2694: CC1A4008 1C227D2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007F269C: BF870091
	v_dot2_f32_bf16 v8, v46, v63, v8                           // 0000007F26A0: CC1A4008 1C227F2E
	v_dot2_f32_bf16 v8, v47, v64, v8                           // 0000007F26A8: CC1A4008 1C22812F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007F26B0: BF8700A1
	v_dot2_f32_bf16 v8, v48, v65, v8                           // 0000007F26B4: CC1A4008 1C228330
	s_waitcnt vmcnt(0)                                         // 0000007F26BC: BF8903F7
	v_dot2_f32_bf16 v8, v49, v66, v8                           // 0000007F26C0: CC1A4008 1C228531
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007F26C8: BF870091
	v_dot2_f32_bf16 v8, v50, v67, v8                           // 0000007F26CC: CC1A4008 1C228732
	v_dot2_f32_bf16 v8, v51, v68, v8                           // 0000007F26D4: CC1A4008 1C228933
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007F26DC: BF870091
	v_dot2_f32_bf16 v8, v52, v69, v8                           // 0000007F26E0: CC1A4008 1C228B34
	v_fmac_f32_e32 v36, v44, v8                                // 0000007F26E8: 5648112C
	s_clause 0x3                                               // 0000007F26EC: BF850003
	global_load_b128 v[8:11], v[12:13], off                    // 0000007F26F0: DC5E0000 087C000C
	global_load_b128 v[19:22], v[12:13], off offset:16         // 0000007F26F8: DC5E0010 137C000C
	global_load_b128 v[45:48], v[12:13], off offset:32         // 0000007F2700: DC5E0020 2D7C000C
	global_load_b128 v[49:52], v[12:13], off offset:48         // 0000007F2708: DC5E0030 317C000C
	s_waitcnt vmcnt(3)                                         // 0000007F2710: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 0000007F2714: CC1A4008 1A021D08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007F271C: BF870091
	v_dot2_f32_bf16 v8, v9, v55, v8                            // 0000007F2720: CC1A4008 1C226F09
	v_dot2_f32_bf16 v8, v10, v56, v8                           // 0000007F2728: CC1A4008 1C22710A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007F2730: BF8700A1
	v_dot2_f32_bf16 v8, v11, v57, v8                           // 0000007F2734: CC1A4008 1C22730B
	s_waitcnt vmcnt(2)                                         // 0000007F273C: BF890BF7
	v_dot2_f32_bf16 v8, v19, v58, v8                           // 0000007F2740: CC1A4008 1C227513
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007F2748: BF870091
	v_dot2_f32_bf16 v8, v20, v59, v8                           // 0000007F274C: CC1A4008 1C227714
	v_dot2_f32_bf16 v8, v21, v60, v8                           // 0000007F2754: CC1A4008 1C227915
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007F275C: BF8700A1
	v_dot2_f32_bf16 v8, v22, v61, v8                           // 0000007F2760: CC1A4008 1C227B16
	s_waitcnt vmcnt(1)                                         // 0000007F2768: BF8907F7
	v_dot2_f32_bf16 v8, v45, v62, v8                           // 0000007F276C: CC1A4008 1C227D2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007F2774: BF870091
	v_dot2_f32_bf16 v8, v46, v63, v8                           // 0000007F2778: CC1A4008 1C227F2E
	v_dot2_f32_bf16 v8, v47, v64, v8                           // 0000007F2780: CC1A4008 1C22812F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007F2788: BF8700A1
	v_dot2_f32_bf16 v8, v48, v65, v8                           // 0000007F278C: CC1A4008 1C228330
	s_waitcnt vmcnt(0)                                         // 0000007F2794: BF8903F7
	v_dot2_f32_bf16 v8, v49, v66, v8                           // 0000007F2798: CC1A4008 1C228531
	.long 0xd7006a31                                           // 0000007F27A0: D7006A31
	v_cndmask_b32_e32 v0, v53, v18, vcc_lo                     // 0000007F27A4: 02002535
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000007F27A8: BF8701B2
	v_dot2_f32_bf16 v8, v50, v67, v8                           // 0000007F27AC: CC1A4008 1C228732
	v_add_co_ci_u32_e64 v50, null, s19, v54, vcc_lo            // 0000007F27B4: D5207C32 01AA6C13
	.long 0xd7006a0c                                           // 0000007F27BC: D7006A0C
	v_cndmask_b32_e32 v0, v12, v18, vcc_lo                     // 0000007F27C0: 0200250C
	v_dot2_f32_bf16 v8, v51, v68, v8                           // 0000007F27C4: CC1A4008 1C228933
	v_add_co_ci_u32_e64 v13, null, s19, v13, vcc_lo            // 0000007F27CC: D5207C0D 01AA1A13
	.long 0xd7006a1c                                           // 0000007F27D4: D7006A1C
	v_cndmask_b32_e32 v0, v28, v192, vcc_lo                    // 0000007F27D8: 0201811C
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000007F27DC: BF870123
	v_dot2_f32_bf16 v8, v52, v69, v8                           // 0000007F27E0: CC1A4008 1C228B34
	v_add_co_ci_u32_e64 v29, null, 0, v29, vcc_lo              // 0000007F27E8: D5207C1D 01AA3A80
	v_fmac_f32_e32 v35, v44, v8                                // 0000007F27F0: 5646112C
	s_clause 0x3                                               // 0000007F27F4: BF850003
	global_load_b128 v[8:11], v[49:50], off                    // 0000007F27F8: DC5E0000 087C0031
	global_load_b128 v[19:22], v[49:50], off offset:16         // 0000007F2800: DC5E0010 137C0031
	global_load_b128 v[45:48], v[49:50], off offset:32         // 0000007F2808: DC5E0020 2D7C0031
	global_load_b128 v[49:52], v[49:50], off offset:48         // 0000007F2810: DC5E0030 317C0031
	s_waitcnt vmcnt(3)                                         // 0000007F2818: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 0000007F281C: CC1A4008 1A021D08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007F2824: BF870091
	v_dot2_f32_bf16 v8, v9, v55, v8                            // 0000007F2828: CC1A4008 1C226F09
	v_dot2_f32_bf16 v8, v10, v56, v8                           // 0000007F2830: CC1A4008 1C22710A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007F2838: BF8700A1
	v_dot2_f32_bf16 v8, v11, v57, v8                           // 0000007F283C: CC1A4008 1C22730B
	s_waitcnt vmcnt(2)                                         // 0000007F2844: BF890BF7
	v_dot2_f32_bf16 v8, v19, v58, v8                           // 0000007F2848: CC1A4008 1C227513
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007F2850: BF870091
	v_dot2_f32_bf16 v8, v20, v59, v8                           // 0000007F2854: CC1A4008 1C227714
	v_dot2_f32_bf16 v8, v21, v60, v8                           // 0000007F285C: CC1A4008 1C227915
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007F2864: BF8700A1
	v_dot2_f32_bf16 v8, v22, v61, v8                           // 0000007F2868: CC1A4008 1C227B16
	s_waitcnt vmcnt(1)                                         // 0000007F2870: BF8907F7
	v_dot2_f32_bf16 v8, v45, v62, v8                           // 0000007F2874: CC1A4008 1C227D2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007F287C: BF870091
	v_dot2_f32_bf16 v8, v46, v63, v8                           // 0000007F2880: CC1A4008 1C227F2E
	v_dot2_f32_bf16 v8, v47, v64, v8                           // 0000007F2888: CC1A4008 1C22812F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007F2890: BF8700A1
	v_dot2_f32_bf16 v8, v48, v65, v8                           // 0000007F2894: CC1A4008 1C228330
	s_waitcnt vmcnt(0)                                         // 0000007F289C: BF8903F7
	v_dot2_f32_bf16 v8, v49, v66, v8                           // 0000007F28A0: CC1A4008 1C228531
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007F28A8: BF870091
	v_dot2_f32_bf16 v8, v50, v67, v8                           // 0000007F28AC: CC1A4008 1C228732
	v_dot2_f32_bf16 v8, v51, v68, v8                           // 0000007F28B4: CC1A4008 1C228933
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007F28BC: BF870091
	v_dot2_f32_bf16 v8, v52, v69, v8                           // 0000007F28C0: CC1A4008 1C228B34
	v_fmac_f32_e32 v34, v44, v8                                // 0000007F28C8: 5644112C
	s_clause 0x3                                               // 0000007F28CC: BF850003
	global_load_b128 v[8:11], v[12:13], off                    // 0000007F28D0: DC5E0000 087C000C
	global_load_b128 v[19:22], v[12:13], off offset:16         // 0000007F28D8: DC5E0010 137C000C
	global_load_b128 v[45:48], v[12:13], off offset:32         // 0000007F28E0: DC5E0020 2D7C000C
	global_load_b128 v[49:52], v[12:13], off offset:48         // 0000007F28E8: DC5E0030 317C000C
	s_waitcnt vmcnt(3)                                         // 0000007F28F0: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 0000007F28F4: CC1A4008 1A021D08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007F28FC: BF870091
	v_dot2_f32_bf16 v8, v9, v55, v8                            // 0000007F2900: CC1A4008 1C226F09
	v_dot2_f32_bf16 v8, v10, v56, v8                           // 0000007F2908: CC1A4008 1C22710A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007F2910: BF8700A1
	v_dot2_f32_bf16 v8, v11, v57, v8                           // 0000007F2914: CC1A4008 1C22730B
	s_waitcnt vmcnt(2)                                         // 0000007F291C: BF890BF7
	v_dot2_f32_bf16 v8, v19, v58, v8                           // 0000007F2920: CC1A4008 1C227513
	v_mov_b32_e32 v19, v15                                     // 0000007F2928: 7E26030F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000007F292C: BF870122
	v_dot2_f32_bf16 v8, v20, v59, v8                           // 0000007F2930: CC1A4008 1C227714
	v_mov_b32_e32 v20, v16                                     // 0000007F2938: 7E280310
	v_dot2_f32_bf16 v8, v21, v60, v8                           // 0000007F293C: CC1A4008 1C227915
	v_mov_b32_e32 v21, v17                                     // 0000007F2944: 7E2A0311
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000007F2948: BF870132
	v_dot2_f32_bf16 v8, v22, v61, v8                           // 0000007F294C: CC1A4008 1C227B16
	v_mov_b32_e32 v22, v18                                     // 0000007F2954: 7E2C0312
	s_waitcnt vmcnt(1)                                         // 0000007F2958: BF8907F7
	v_dot2_f32_bf16 v8, v45, v62, v8                           // 0000007F295C: CC1A4008 1C227D2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007F2964: BF870091
	v_dot2_f32_bf16 v8, v46, v63, v8                           // 0000007F2968: CC1A4008 1C227F2E
	v_dot2_f32_bf16 v8, v47, v64, v8                           // 0000007F2970: CC1A4008 1C22812F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007F2978: BF8700A1
	v_dot2_f32_bf16 v8, v48, v65, v8                           // 0000007F297C: CC1A4008 1C228330
	s_waitcnt vmcnt(0)                                         // 0000007F2984: BF8903F7
	v_dot2_f32_bf16 v8, v49, v66, v8                           // 0000007F2988: CC1A4008 1C228531
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007F2990: BF870091
	v_dot2_f32_bf16 v8, v50, v67, v8                           // 0000007F2994: CC1A4008 1C228732
	v_dot2_f32_bf16 v8, v51, v68, v8                           // 0000007F299C: CC1A4008 1C228933
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007F29A4: BF870091
	v_dot2_f32_bf16 v8, v52, v69, v8                           // 0000007F29A8: CC1A4008 1C228B34
	v_dual_fmac_f32 v31, v44, v8 :: v_dual_mov_b32 v14, v7     // 0000007F29B0: C810112C 1F0E0107
	v_dual_mov_b32 v44, v43 :: v_dual_mov_b32 v13, v6          // 0000007F29B8: CA10012B 2C0C0106
	v_dual_mov_b32 v12, v5 :: v_dual_mov_b32 v11, v4           // 0000007F29C0: CA100105 0C0A0104
	v_dual_mov_b32 v10, v3 :: v_dual_mov_b32 v9, v2            // 0000007F29C8: CA100103 0A080102
	v_dual_mov_b32 v8, v1 :: v_dual_mov_b32 v7, v0             // 0000007F29D0: CA100101 08060100
	s_and_not1_b32 exec_lo, exec_lo, s20                       // 0000007F29D8: 917E147E
	s_cbranch_execz 28                                         // 0000007F29DC: BFA5001C <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi1ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0xf50>
	s_waitcnt vmcnt(0)                                         // 0000007F29E0: BF8903F7
	v_dual_mov_b32 v15, v19 :: v_dual_add_nc_u32 v42, 32, v42  // 0000007F29E4: CA200113 0F2A54A0
	v_dual_mov_b32 v16, v20 :: v_dual_mov_b32 v17, v21         // 0000007F29EC: CA100114 10100115
	v_mov_b32_e32 v18, v22                                     // 0000007F29F4: 7E240316
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007F29F8: BF870003
	.long 0xd4430004                                           // 0000007F29FC: D4430004
	v_cndmask_b32_e32 v1, s6, v42, vcc_lo                      // 0000007F2A00: 02025406
	s_mov_b32 s14, exec_lo                                     // 0000007F2A04: BE8E007E
	.long 0xd4c4007e                                           // 0000007F2A08: D4C4007E
	v_cndmask_b32_e32 v1, s6, v42, vcc_lo                      // 0000007F2A0C: 02025406
	s_cbranch_execz 64911                                      // 0000007F2A10: BFA5FD8F <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi1ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x550>
	.long 0xd7006a00                                           // 0000007F2A14: D7006A00
	v_cndmask_b32_e32 v1, v25, v41, vcc_lo                     // 0000007F2A18: 02025319
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007F2A1C: BF870001
	v_add_co_ci_u32_e64 v1, null, 0, v33, vcc_lo               // 0000007F2A20: D5207C01 01AA4280
	v_cmp_ne_u32_e32 vcc_lo, 1, v32                            // 0000007F2A28: 7C9A4081
	v_mov_b32_e32 v43, v44                                     // 0000007F2A2C: 7E56032C
	global_load_b128 v[15:18], v[0:1], off                     // 0000007F2A30: DC5E0000 0F7C0000
	s_cbranch_vccnz 64901                                      // 0000007F2A38: BFA4FD85 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi1ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x550>
	global_load_d16_b16 v0, v[28:29], off                      // 0000007F2A3C: DC820000 007C001C
	s_waitcnt vmcnt(0)                                         // 0000007F2A44: BF8903F7
	v_cvt_f32_f16_e32 v43, v0                                  // 0000007F2A48: 7E561700
	s_branch 64896                                             // 0000007F2A4C: BFA0FD80 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi1ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x550>
	s_or_b32 exec_lo, exec_lo, s20                             // 0000007F2A50: 8C7E147E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007F2A54: BF8700A9
	s_or_b32 exec_lo, exec_lo, s5                              // 0000007F2A58: 8C7E057E
	.long 0xd71f0000                                           // 0000007F2A5C: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000007F2A60: 020100C1
	v_xor_b32_e32 v1, 16, v0                                   // 0000007F2A64: 3A020090
	v_xor_b32_e32 v9, 8, v0                                    // 0000007F2A68: 3A120088
	v_xor_b32_e32 v17, 4, v0                                   // 0000007F2A6C: 3A220084
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000007F2A70: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v1                            // 0000007F2A74: 7C9802A0
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 0000007F2A78: 02020300
	v_cmp_gt_u32_e32 vcc_lo, 32, v9                            // 0000007F2A7C: 7C9812A0
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007F2A80: BF870002
	v_lshlrev_b32_e32 v1, 2, v1                                // 0000007F2A84: 30020282
	ds_bpermute_b32 v2, v1, v40                                // 0000007F2A88: DACC0000 02002801
	s_waitcnt lgkmcnt(0)                                       // 0000007F2A90: BF89FC07
	v_add_f32_e32 v2, v40, v2                                  // 0000007F2A94: 06040528
	ds_bpermute_b32 v8, v1, v34                                // 0000007F2A98: DACC0000 08002201
	ds_bpermute_b32 v6, v1, v36                                // 0000007F2AA0: DACC0000 06002401
	ds_bpermute_b32 v4, v1, v38                                // 0000007F2AA8: DACC0000 04002601
	v_cndmask_b32_e32 v9, v0, v9, vcc_lo                       // 0000007F2AB0: 02121300
	ds_bpermute_b32 v5, v1, v37                                // 0000007F2AB4: DACC0000 05002501
	ds_bpermute_b32 v3, v1, v39                                // 0000007F2ABC: DACC0000 03002701
	ds_bpermute_b32 v7, v1, v35                                // 0000007F2AC4: DACC0000 07002301
	ds_bpermute_b32 v1, v1, v31                                // 0000007F2ACC: DACC0000 01001F01
	v_cmp_gt_u32_e32 vcc_lo, 32, v17                           // 0000007F2AD4: 7C9822A0
	s_waitcnt lgkmcnt(6)                                       // 0000007F2AD8: BF89FC67
	v_dual_add_f32 v8, v34, v8 :: v_dual_lshlrev_b32 v9, 2, v9 // 0000007F2ADC: C9221122 08081282
	s_waitcnt lgkmcnt(5)                                       // 0000007F2AE4: BF89FC57
	v_add_f32_e32 v6, v36, v6                                  // 0000007F2AE8: 060C0D24
	s_waitcnt lgkmcnt(4)                                       // 0000007F2AEC: BF89FC47
	v_add_f32_e32 v4, v38, v4                                  // 0000007F2AF0: 06080926
	ds_bpermute_b32 v11, v9, v2                                // 0000007F2AF4: DACC0000 0B000209
	s_waitcnt lgkmcnt(4)                                       // 0000007F2AFC: BF89FC47
	v_add_f32_e32 v5, v37, v5                                  // 0000007F2B00: 060A0B25
	ds_bpermute_b32 v13, v9, v4                                // 0000007F2B04: DACC0000 0D000409
	ds_bpermute_b32 v15, v9, v6                                // 0000007F2B0C: DACC0000 0F000609
	s_waitcnt lgkmcnt(5)                                       // 0000007F2B14: BF89FC57
	v_add_f32_e32 v3, v39, v3                                  // 0000007F2B18: 06060727
	s_waitcnt lgkmcnt(4)                                       // 0000007F2B1C: BF89FC47
	v_add_f32_e32 v7, v35, v7                                  // 0000007F2B20: 060E0F23
	s_waitcnt lgkmcnt(3)                                       // 0000007F2B24: BF89FC37
	v_add_f32_e32 v1, v31, v1                                  // 0000007F2B28: 0602031F
	ds_bpermute_b32 v14, v9, v7                                // 0000007F2B2C: DACC0000 0E000709
	s_waitcnt lgkmcnt(3)                                       // 0000007F2B34: BF89FC37
	v_add_f32_e32 v2, v2, v11                                  // 0000007F2B38: 06041702
	ds_bpermute_b32 v12, v9, v5                                // 0000007F2B3C: DACC0000 0C000509
	v_cndmask_b32_e32 v17, v0, v17, vcc_lo                     // 0000007F2B44: 02222300
	s_waitcnt lgkmcnt(3)                                       // 0000007F2B48: BF89FC37
	v_add_f32_e32 v4, v4, v13                                  // 0000007F2B4C: 06081B04
	ds_bpermute_b32 v10, v9, v3                                // 0000007F2B50: DACC0000 0A000309
	s_waitcnt lgkmcnt(3)                                       // 0000007F2B58: BF89FC37
	v_add_f32_e32 v6, v6, v15                                  // 0000007F2B5C: 060C1F06
	ds_bpermute_b32 v16, v9, v1                                // 0000007F2B60: DACC0000 10000109
	ds_bpermute_b32 v9, v9, v8                                 // 0000007F2B68: DACC0000 09000809
	v_lshlrev_b32_e32 v17, 2, v17                              // 0000007F2B70: 30222282
	s_waitcnt lgkmcnt(3)                                       // 0000007F2B74: BF89FC37
	v_add_f32_e32 v5, v5, v12                                  // 0000007F2B78: 060A1905
	ds_bpermute_b32 v12, v17, v4                               // 0000007F2B7C: DACC0000 0C000411
	s_waitcnt lgkmcnt(1)                                       // 0000007F2B84: BF89FC17
	v_dual_add_f32 v1, v1, v16 :: v_dual_add_f32 v8, v8, v9    // 0000007F2B88: C9082101 01081308
	s_waitcnt lgkmcnt(0)                                       // 0000007F2B90: BF89FC07
	v_add_f32_e32 v4, v4, v12                                  // 0000007F2B94: 06081904
	ds_bpermute_b32 v16, v17, v8                               // 0000007F2B98: DACC0000 10000811
	v_add_f32_e32 v3, v3, v10                                  // 0000007F2BA0: 06061503
	ds_bpermute_b32 v10, v17, v2                               // 0000007F2BA4: DACC0000 0A000211
	v_xor_b32_e32 v12, 1, v0                                   // 0000007F2BAC: 3A180081
	v_add_f32_e32 v7, v7, v14                                  // 0000007F2BB0: 060E1D07
	ds_bpermute_b32 v14, v17, v6                               // 0000007F2BB4: DACC0000 0E000611
	ds_bpermute_b32 v15, v17, v1                               // 0000007F2BBC: DACC0000 0F000111
	ds_bpermute_b32 v13, v17, v7                               // 0000007F2BC4: DACC0000 0D000711
	s_waitcnt lgkmcnt(3)                                       // 0000007F2BCC: BF89FC37
	v_add_f32_e32 v2, v2, v10                                  // 0000007F2BD0: 06041502
	v_add_f32_e32 v10, v8, v16                                 // 0000007F2BD4: 06142108
	ds_bpermute_b32 v9, v17, v3                                // 0000007F2BD8: DACC0000 09000311
	s_waitcnt lgkmcnt(3)                                       // 0000007F2BE0: BF89FC37
	v_add_f32_e32 v6, v6, v14                                  // 0000007F2BE4: 060C1D06
	ds_bpermute_b32 v11, v17, v5                               // 0000007F2BE8: DACC0000 0B000511
	v_xor_b32_e32 v17, 2, v0                                   // 0000007F2BF0: 3A220082
	s_waitcnt lgkmcnt(3)                                       // 0000007F2BF4: BF89FC37
	v_add_f32_e32 v1, v1, v15                                  // 0000007F2BF8: 06021F01
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007F2BFC: BF870002
	v_cmp_gt_u32_e32 vcc_lo, 32, v17                           // 0000007F2C00: 7C9822A0
	s_waitcnt lgkmcnt(1)                                       // 0000007F2C04: BF89FC17
	v_add_f32_e32 v3, v3, v9                                   // 0000007F2C08: 06061303
	v_cndmask_b32_e32 v17, v0, v17, vcc_lo                     // 0000007F2C0C: 02222300
	s_waitcnt lgkmcnt(0)                                       // 0000007F2C10: BF89FC07
	v_add_f32_e32 v5, v5, v11                                  // 0000007F2C14: 060A1705
	v_cmp_gt_u32_e32 vcc_lo, 32, v12                           // 0000007F2C18: 7C9818A0
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007F2C1C: BF870003
	v_dual_cndmask_b32 v0, v0, v12 :: v_dual_lshlrev_b32 v17, 2, v17// 0000007F2C20: CA621900 00102282
	v_add_f32_e32 v7, v7, v13                                  // 0000007F2C28: 060E1B07
	v_cmp_eq_u32_e32 vcc_lo, 0, v30                            // 0000007F2C2C: 7C943C80
	ds_bpermute_b32 v8, v17, v3                                // 0000007F2C30: DACC0000 08000311
	ds_bpermute_b32 v11, v17, v5                               // 0000007F2C38: DACC0000 0B000511
	s_waitcnt vmcnt(0)                                         // 0000007F2C40: BF8903F7
	v_lshlrev_b32_e32 v19, 2, v0                               // 0000007F2C44: 30260082
	s_and_b32 s2, vcc_lo, s2                                   // 0000007F2C48: 8B02026A
	s_waitcnt lgkmcnt(1)                                       // 0000007F2C4C: BF89FC17
	v_add_f32_e32 v12, v3, v8                                  // 0000007F2C50: 06181103
	s_waitcnt lgkmcnt(0)                                       // 0000007F2C54: BF89FC07
	v_add_f32_e32 v8, v5, v11                                  // 0000007F2C58: 06101705
	ds_bpermute_b32 v9, v17, v2                                // 0000007F2C5C: DACC0000 09000211
	ds_bpermute_b32 v14, v17, v4                               // 0000007F2C64: DACC0000 0E000411
	ds_bpermute_b32 v15, v17, v7                               // 0000007F2C6C: DACC0000 0F000711
	ds_bpermute_b32 v16, v17, v6                               // 0000007F2C74: DACC0000 10000611
	ds_bpermute_b32 v18, v17, v1                               // 0000007F2C7C: DACC0000 12000111
	ds_bpermute_b32 v17, v17, v10                              // 0000007F2C84: DACC0000 11000A11
	s_waitcnt lgkmcnt(5)                                       // 0000007F2C8C: BF89FC57
	v_add_f32_e32 v13, v2, v9                                  // 0000007F2C90: 061A1302
	s_waitcnt lgkmcnt(3)                                       // 0000007F2C94: BF89FC37
	v_dual_add_f32 v9, v4, v14 :: v_dual_add_f32 v4, v7, v15   // 0000007F2C98: C9081D04 09041F07
	s_waitcnt lgkmcnt(1)                                       // 0000007F2CA0: BF89FC17
	v_dual_add_f32 v5, v6, v16 :: v_dual_add_f32 v0, v1, v18   // 0000007F2CA4: C9082106 05002501
	s_waitcnt lgkmcnt(0)                                       // 0000007F2CAC: BF89FC07
	v_add_f32_e32 v2, v10, v17                                 // 0000007F2CB0: 0604230A
	ds_bpermute_b32 v15, v19, v13                              // 0000007F2CB4: DACC0000 0F000D13
	ds_bpermute_b32 v14, v19, v12                              // 0000007F2CBC: DACC0000 0E000C13
	ds_bpermute_b32 v11, v19, v9                               // 0000007F2CC4: DACC0000 0B000913
	ds_bpermute_b32 v10, v19, v8                               // 0000007F2CCC: DACC0000 0A000813
	ds_bpermute_b32 v7, v19, v5                                // 0000007F2CD4: DACC0000 07000513
	ds_bpermute_b32 v6, v19, v4                                // 0000007F2CDC: DACC0000 06000413
	ds_bpermute_b32 v3, v19, v2                                // 0000007F2CE4: DACC0000 03000213
	ds_bpermute_b32 v1, v19, v0                                // 0000007F2CEC: DACC0000 01000013
	s_and_saveexec_b32 s3, s2                                  // 0000007F2CF4: BE832002
	s_cbranch_execz 421                                        // 0000007F2CF8: BFA501A5 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi1ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x1890>
	s_waitcnt lgkmcnt(6)                                       // 0000007F2CFC: BF89FC67
	v_dual_add_f32 v13, v13, v15 :: v_dual_add_f32 v12, v12, v14// 0000007F2D00: C9081F0D 0D0C1D0C
	.long 0x7f1e3880                                           // 0000007F2D08: 7F1E3880
	s_waitcnt lgkmcnt(4)                                       // 0000007F2D0C: BF89FC47
	v_dual_add_f32 v9, v9, v11 :: v_dual_add_f32 v8, v8, v10   // 0000007F2D10: C9081709 09081508
	s_load_b32 s1, s[0:1], 0x48                                // 0000007F2D18: F4000040 F8000048
	.long 0x7e1c398d                                           // 0000007F2D20: 7E1C398D
	.long 0x7f14398f                                           // 0000007F2D24: 7F14398F
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007F2D28: BF870003
	.long 0x7e143989                                           // 0000007F2D2C: 7E143989
	.long 0x7f1c398f                                           // 0000007F2D30: 7F1C398F
	.long 0x7e1e398c                                           // 0000007F2D34: 7E1E398C
	s_waitcnt lgkmcnt(0)                                       // 0000007F2D38: BF89FC07
	v_add_f32_e32 v2, v2, v3                                   // 0000007F2D3C: 06040702
	.long 0x7f06398f                                           // 0000007F2D40: 7F06398F
	v_and_b32_e32 v10, 1, v10                                  // 0000007F2D44: 36141481
	v_and_b32_e32 v14, 1, v14                                  // 0000007F2D48: 361C1C81
	v_add_f32_e32 v4, v4, v6                                   // 0000007F2D4C: 06080D04
	.long 0x7e063982                                           // 0000007F2D50: 7E063982
	v_add_f32_e32 v0, v0, v1                                   // 0000007F2D54: 06000300
	v_add3_u32 v9, v9, v10, 0x7fff                             // 0000007F2D58: D6550009 03FE1509 00007FFF
	v_add3_u32 v13, v13, v14, 0x7fff                           // 0000007F2D64: D655000D 03FE1D0D 00007FFF
	.long 0x7f0c398f                                           // 0000007F2D70: 7F0C398F
	v_and_b32_e32 v1, 1, v3                                    // 0000007F2D74: 36020681
	.long 0x7f48398f                                           // 0000007F2D78: 7F48398F
	v_and_b32_e32 v9, 0xffff0000, v9                           // 0000007F2D7C: 361212FF FFFF0000
	v_and_b32_e32 v16, 1, v15                                  // 0000007F2D84: 36201E81
	s_lshl_b64 s[2:3], s[16:17], 2                             // 0000007F2D88: 84828210
	v_add3_u32 v1, v2, v1, 0x7fff                              // 0000007F2D8C: D6550001 03FE0302 00007FFF
	.long 0x7f44398f                                           // 0000007F2D98: 7F44398F
	.long 0x7f46398f                                           // 0000007F2D9C: 7F46398F
	v_add3_u32 v12, v12, v16, 0x7fff                           // 0000007F2DA0: D655000C 03FE210C 00007FFF
	.long 0x7f4a398f                                           // 0000007F2DAC: 7F4A398F
	v_and_b32_e32 v1, 0xffff0000, v1                           // 0000007F2DB0: 360202FF FFFF0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000007F2DB8: BF870123
	v_dual_add_f32 v5, v5, v7 :: v_dual_and_b32 v12, 0xffff0000, v12// 0000007F2DBC: C9240F05 050C18FF FFFF0000
	v_and_b32_e32 v13, 0xffff0000, v13                         // 0000007F2DC8: 361A1AFF FFFF0000
	.long 0x7e0c3985                                           // 0000007F2DD0: 7E0C3985
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007F2DD4: BF870112
	v_dual_mul_f32 v12, s1, v12 :: v_dual_mul_f32 v13, s1, v13 // 0000007F2DD8: C8C61801 0C0C1A01
	v_and_b32_e32 v6, 1, v6                                    // 0000007F2DE0: 360C0C81
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007F2DE4: BF870192
	v_mul_f32_e32 v16, 0xbfb8aa3b, v12                         // 0000007F2DE8: 102018FF BFB8AA3B
	v_mul_f32_e32 v14, 0xbfb8aa3b, v13                         // 0000007F2DF0: 101C1AFF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007F2DF8: BF870193
	v_add3_u32 v5, v5, v6, 0x7fff                              // 0000007F2DFC: D6550005 03FE0D05 00007FFF
	v_exp_f32_e32 v16, v16                                     // 0000007F2E08: 7E204B10
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 0000007F2E0C: BF870312
	v_exp_f32_e32 v14, v14                                     // 0000007F2E10: 7E1C4B0E
	v_dual_add_f32 v16, 1.0, v16 :: v_dual_and_b32 v5, 0xffff0000, v5// 0000007F2E14: C92420F2 10040AFF FFFF0000
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007F2E20: BF870115
	v_add_f32_e32 v14, 1.0, v14                                // 0000007F2E24: 061C1CF2
	v_div_scale_f32 v18, null, v16, v16, v12                   // 0000007F2E28: D6FC7C12 04322110
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007F2E30: BF8701A2
	v_div_scale_f32 v17, null, v14, v14, v13                   // 0000007F2E34: D6FC7C11 04361D0E
	v_div_scale_f32 v25, vcc_lo, v13, v14, v13                 // 0000007F2E3C: D6FC6A19 04361D0D
	v_rcp_f32_e32 v20, v18                                     // 0000007F2E44: 7E285512
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 0000007F2E48: BF870312
	v_rcp_f32_e32 v19, v17                                     // 0000007F2E4C: 7E265511
	v_fma_f32 v22, -v18, v20, 1.0                              // 0000007F2E50: D6130016 23CA2912
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007F2E58: BF870095
	v_fma_f32 v21, -v17, v19, 1.0                              // 0000007F2E5C: D6130015 23CA2711
	v_dual_fmac_f32 v20, v22, v20 :: v_dual_fmac_f32 v19, v21, v19// 0000007F2E64: C8002916 14122715
	v_div_scale_f32 v21, s0, v12, v16, v12                     // 0000007F2E6C: D6FC0015 0432210C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007F2E74: BF870112
	v_mul_f32_e32 v22, v25, v19                                // 0000007F2E78: 102C2719
	v_mul_f32_e32 v26, v21, v20                                // 0000007F2E7C: 10342915
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007F2E80: BF870112
	v_fma_f32 v27, -v17, v22, v25                              // 0000007F2E84: D613001B 24662D11
	v_fma_f32 v28, -v18, v26, v21                              // 0000007F2E8C: D613001C 24563512
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007F2E94: BF870112
	v_fmac_f32_e32 v22, v27, v19                               // 0000007F2E98: 562C271B
	v_fmac_f32_e32 v26, v28, v20                               // 0000007F2E9C: 5634291C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007F2EA0: BF870112
	v_fma_f32 v17, -v17, v22, v25                              // 0000007F2EA4: D6130011 24662D11
	v_fma_f32 v18, -v18, v26, v21                              // 0000007F2EAC: D6130012 24563512
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000007F2EB4: BF870122
	v_div_fmas_f32 v17, v17, v19, v22                          // 0000007F2EB8: D6370011 045A2711
	s_mov_b32 vcc_lo, s0                                       // 0000007F2EC0: BEEA0000
	v_div_fmas_f32 v18, v18, v20, v26                          // 0000007F2EC4: D6370012 046A2912
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007F2ECC: BF870091
	v_div_fixup_f32 v16, v18, v16, v12                         // 0000007F2ED0: D6270010 04322112
	.long 0x7e1e3990                                           // 0000007F2ED8: 7E1E3990
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007F2EDC: BF8700A1
	v_and_b32_e32 v18, 1, v15                                  // 0000007F2EE0: 36241E81
	.long 0x7e1e3988                                           // 0000007F2EE4: 7E1E3988
	v_and_b32_e32 v11, 1, v15                                  // 0000007F2EE8: 36161E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007F2EEC: BF870091
	v_add3_u32 v8, v8, v11, 0x7fff                             // 0000007F2EF0: D6550008 03FE1708 00007FFF
	v_and_b32_e32 v8, 0xffff0000, v8                           // 0000007F2EFC: 361010FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007F2F04: BF870091
	v_dual_mul_f32 v8, s1, v8 :: v_dual_mul_f32 v11, s1, v9    // 0000007F2F08: C8C61001 080A1201
	v_dual_mul_f32 v10, 0xbfb8aa3b, v8 :: v_dual_mul_f32 v9, 0xbfb8aa3b, v11// 0000007F2F10: C8C610FF 0A0816FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007F2F1C: BF870091
	v_exp_f32_e32 v10, v10                                     // 0000007F2F20: 7E144B0A
	v_exp_f32_e32 v9, v9                                       // 0000007F2F24: 7E124B09
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007F2F28: BF870095
	v_dual_add_f32 v12, 1.0, v9 :: v_dual_add_f32 v9, 1.0, v10 // 0000007F2F2C: C90812F2 0C0814F2
	v_div_scale_f32 v10, null, v12, v12, v11                   // 0000007F2F34: D6FC7C0A 042E190C
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007F2F3C: BF8701A2
	v_div_scale_f32 v19, null, v9, v9, v8                      // 0000007F2F40: D6FC7C13 04221309
	v_div_scale_f32 v26, vcc_lo, v11, v12, v11                 // 0000007F2F48: D6FC6A1A 042E190B
	v_rcp_f32_e32 v20, v10                                     // 0000007F2F50: 7E28550A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 0000007F2F54: BF870312
	v_rcp_f32_e32 v21, v19                                     // 0000007F2F58: 7E2A5513
	v_fma_f32 v22, -v10, v20, 1.0                              // 0000007F2F5C: D6130016 23CA290A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007F2F64: BF870115
	v_fma_f32 v25, -v19, v21, 1.0                              // 0000007F2F68: D6130019 23CA2B13
	v_fmac_f32_e32 v20, v22, v20                               // 0000007F2F70: 56282916
	v_div_scale_f32 v22, s0, v8, v9, v8                        // 0000007F2F74: D6FC0016 04221308
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000007F2F7C: BF870223
	v_fmac_f32_e32 v21, v25, v21                               // 0000007F2F80: 562A2B19
	v_div_fixup_f32 v17, v17, v14, v13                         // 0000007F2F84: D6270011 04361D11
	v_mul_f32_e32 v25, v26, v20                                // 0000007F2F8C: 1032291A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007F2F90: BF870193
	v_mul_f32_e32 v27, v22, v21                                // 0000007F2F94: 10362B16
	.long 0x7e443991                                           // 0000007F2F98: 7E443991
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007F2F9C: BF870193
	v_fma_f32 v28, -v10, v25, v26                              // 0000007F2FA0: D613001C 246A330A
	v_fma_f32 v29, -v19, v27, v22                              // 0000007F2FA8: D613001D 245A3713
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007F2FB0: BF870112
	v_fmac_f32_e32 v25, v28, v20                               // 0000007F2FB4: 5632291C
	v_fmac_f32_e32 v27, v29, v21                               // 0000007F2FB8: 56362B1D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007F2FBC: BF870112
	v_fma_f32 v10, -v10, v25, v26                              // 0000007F2FC0: D613000A 246A330A
	v_fma_f32 v19, -v19, v27, v22                              // 0000007F2FC8: D6130013 245A3713
	v_mul_f32_e32 v22, s1, v5                                  // 0000007F2FD0: 102C0A01
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007F2FD4: BF8701A3
	v_div_fmas_f32 v20, v10, v20, v25                          // 0000007F2FD8: D6370014 0466290A
	s_mov_b32 vcc_lo, s0                                       // 0000007F2FE0: BEEA0000
	v_div_fmas_f32 v10, v19, v21, v27                          // 0000007F2FE4: D637000A 046E2B13
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007F2FEC: BF8701A3
	v_mul_f32_e32 v5, 0xbfb8aa3b, v22                          // 0000007F2FF0: 100A2CFF BFB8AA3B
	v_add3_u32 v16, v16, v18, 0x7fff                           // 0000007F2FF8: D6550010 03FE2510 00007FFF
	v_div_fixup_f32 v19, v10, v9, v8                           // 0000007F3004: D6270013 0422130A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007F300C: BF870093
	v_exp_f32_e32 v5, v5                                       // 0000007F3010: 7E0A4B05
	.long 0x7e1e3993                                           // 0000007F3014: 7E1E3993
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(TRANS32_DEP_1)// 0000007F3018: BF8702A1
	v_and_b32_e32 v21, 1, v15                                  // 0000007F301C: 362A1E81
	.long 0x7e1e3984                                           // 0000007F3020: 7E1E3984
	v_add_f32_e32 v25, 1.0, v5                                 // 0000007F3024: 06320AF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007F3028: BF870112
	v_and_b32_e32 v7, 1, v15                                   // 0000007F302C: 360E1E81
	v_div_scale_f32 v27, vcc_lo, v22, v25, v22                 // 0000007F3030: D6FC6A1B 045A3316
	v_div_fixup_f32 v20, v20, v12, v11                         // 0000007F3038: D6270014 042E1914
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007F3040: BF870113
	v_add3_u32 v4, v4, v7, 0x7fff                              // 0000007F3044: D6550004 03FE0F04 00007FFF
	.long 0x7e463994                                           // 0000007F3050: 7E463994
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007F3054: BF870092
	v_and_b32_e32 v4, 0xffff0000, v4                           // 0000007F3058: 360808FF FFFF0000
	v_mul_f32_e32 v4, s1, v4                                   // 0000007F3060: 10080801
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007F3064: BF870091
	v_mul_f32_e32 v6, 0xbfb8aa3b, v4                           // 0000007F3068: 100C08FF BFB8AA3B
	v_exp_f32_e32 v6, v6                                       // 0000007F3070: 7E0C4B06
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000007F3074: BF870125
	v_add_f32_e32 v5, 1.0, v6                                  // 0000007F3078: 060A0CF2
	v_div_scale_f32 v6, null, v25, v25, v22                    // 0000007F307C: D6FC7C06 045A3319
	v_div_scale_f32 v7, null, v5, v5, v4                       // 0000007F3084: D6FC7C07 04120B05
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007F308C: BF870092
	v_rcp_f32_e32 v8, v6                                       // 0000007F3090: 7E105506
	v_rcp_f32_e32 v9, v7                                       // 0000007F3094: 7E125507
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000007F3098: BF870296
	v_fma_f32 v10, -v6, v8, 1.0                                // 0000007F309C: D613000A 23CA1106
	v_fma_f32 v26, -v7, v9, 1.0                                // 0000007F30A4: D613001A 23CA1307
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007F30AC: BF870092
	v_fmac_f32_e32 v8, v10, v8                                 // 0000007F30B0: 5610110A
	v_dual_fmac_f32 v9, v26, v9 :: v_dual_mul_f32 v26, v27, v8 // 0000007F30B4: C806131A 091A111B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007F30BC: BF870091
	v_fma_f32 v29, -v6, v26, v27                               // 0000007F30C0: D613001D 246E3506
	v_dual_fmac_f32 v26, v29, v8 :: v_dual_mul_f32 v29, s1, v1 // 0000007F30C8: C806111D 1A1C0201
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007F30D0: BF870111
	v_fma_f32 v6, -v6, v26, v27                                // 0000007F30D4: D6130006 246E3506
	v_mul_f32_e32 v1, 0xbfb8aa3b, v29                          // 0000007F30DC: 10023AFF BFB8AA3B
	v_div_scale_f32 v10, s0, v4, v5, v4                        // 0000007F30E4: D6FC000A 04120B04
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000007F30EC: BF870123
	v_div_fmas_f32 v26, v6, v8, v26                            // 0000007F30F0: D637001A 046A1106
	s_mov_b32 vcc_lo, s0                                       // 0000007F30F8: BEEA0000
	v_mul_f32_e32 v28, v10, v9                                 // 0000007F30FC: 1038130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007F3100: BF870091
	v_fma_f32 v30, -v7, v28, v10                               // 0000007F3104: D613001E 242A3907
	v_fmac_f32_e32 v28, v30, v9                                // 0000007F310C: 5638131E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007F3110: BF870091
	v_fma_f32 v7, -v7, v28, v10                                // 0000007F3114: D6130007 242A3907
	v_div_fmas_f32 v6, v7, v9, v28                             // 0000007F311C: D6370006 04721307
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007F3124: BF870091
	v_div_fixup_f32 v27, v6, v5, v4                            // 0000007F3128: D627001B 04120B06
	.long 0x7e1e399b                                           // 0000007F3130: 7E1E399B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007F3134: BF8700A1
	v_and_b32_e32 v28, 1, v15                                  // 0000007F3138: 36381E81
	.long 0x7e1e3980                                           // 0000007F313C: 7E1E3980
	v_and_b32_e32 v2, 1, v15                                   // 0000007F3140: 36041E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007F3144: BF870091
	v_add3_u32 v0, v0, v2, 0x7fff                              // 0000007F3148: D6550000 03FE0500 00007FFF
	v_and_b32_e32 v0, 0xffff0000, v0                           // 0000007F3154: 360000FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007F315C: BF8700B1
	v_mul_f32_e32 v30, s1, v0                                  // 0000007F3160: 103C0001
	v_exp_f32_e32 v0, v1                                       // 0000007F3164: 7E004B01
	s_lshl_b64 s[0:1], s[16:17], 1                             // 0000007F3168: 84808110
	v_mul_f32_e32 v1, 0xbfb8aa3b, v30                          // 0000007F316C: 10023CFF BFB8AA3B
	v_div_fixup_f32 v22, v26, v25, v22                         // 0000007F3174: D6270016 045A331A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 0000007F317C: BF870312
	v_exp_f32_e32 v1, v1                                       // 0000007F3180: 7E024B01
	v_add_f32_e32 v31, 1.0, v0                                 // 0000007F3184: 063E00F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007F3188: BF870112
	.long 0x7e483996                                           // 0000007F318C: 7E483996
	v_div_scale_f32 v32, null, v31, v31, v29                   // 0000007F3190: D6FC7C20 04763F1F
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007F3198: BF8701A5
	v_add_f32_e32 v33, 1.0, v1                                 // 0000007F319C: 064202F2
	.long 0xd73c0000                                           // 0000007F31A0: D73C0000
	v_cndmask_b32_e32 v1, 1, v23, vcc_lo                       // 0000007F31A4: 02022E81
	v_rcp_f32_e32 v23, v32                                     // 0000007F31A8: 7E2E5520
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007F31AC: BF870112
	v_div_scale_f32 v24, null, v33, v33, v30                   // 0000007F31B0: D6FC7C18 047A4321
	.long 0xd7006a03                                           // 0000007F31B8: D7006A03
	v_cndmask_b32_e32 v1, s12, v0, vcc_lo                      // 0000007F31BC: 0202000C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007F31C0: BF870191
	v_add_co_ci_u32_e64 v4, null, s13, v1, vcc_lo              // 0000007F31C4: D5207C04 01AA020D
	v_rcp_f32_e32 v38, v24                                     // 0000007F31CC: 7E4C5518
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007F31D0: BF870196
	v_fma_f32 v0, -v32, v23, 1.0                               // 0000007F31D4: D6130000 23CA2F20
	.long 0xd7006a05                                           // 0000007F31DC: D7006A05
	v_cndmask_b32_e32 v0, v3, v0, vcc_lo                       // 0000007F31E0: 02000103
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000007F31E4: BF870221
	v_add_co_ci_u32_e64 v6, null, s1, v4, vcc_lo               // 0000007F31E8: D5207C06 01AA0801
	v_div_scale_f32 v39, vcc_lo, v29, v31, v29                 // 0000007F31F0: D6FC6A27 04763F1D
	v_fmac_f32_e32 v23, v0, v23                                // 0000007F31F8: 562E2F00
	.long 0xd7000007                                           // 0000007F31FC: D7000007
	v_cndmask_b32_e32 v0, v3, v2, vcc_lo                       // 0000007F3200: 02000503
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000007F3204: BF870245
	v_fma_f32 v2, -v24, v38, 1.0                               // 0000007F3208: D6130002 23CA4D18
	v_mad_u64_u32 v[0:1], null, s16, 6, v[3:4]                 // 0000007F3210: D6FE7C00 040D0C10
	v_add_co_ci_u32_e64 v8, null, s3, v4, s0                   // 0000007F3218: D5207C08 00020803
	v_div_scale_f32 v41, s0, v30, v33, v30                     // 0000007F3220: D6FC0029 047A431E
	v_fmac_f32_e32 v38, v2, v38                                // 0000007F3228: 564C4D02
	v_mul_f32_e32 v40, v39, v23                                // 0000007F322C: 10502F27
	.long 0xd7000109                                           // 0000007F3230: D7000109
	v_cndmask_b32_e32 v0, v7, v2, vcc_lo                       // 0000007F3234: 02000507
	v_mad_u64_u32 v[1:2], null, s17, 6, v[1:2]                 // 0000007F3238: D6FE7C01 04050C11
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000007F3240: BF870214
	v_mul_f32_e32 v42, v41, v38                                // 0000007F3244: 10544D29
	v_fma_f32 v2, -v32, v40, v39                               // 0000007F3248: D6130002 249E5120
	v_add_co_ci_u32_e64 v10, null, s3, v8, s1                  // 0000007F3250: D5207C0A 00061003
	.long 0xd700010b                                           // 0000007F3258: D700010B
	v_cndmask_b32_e32 v0, v9, v2, vcc_lo                       // 0000007F325C: 02000509
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000007F3260: BF870214
	v_fma_f32 v13, -v24, v42, v41                              // 0000007F3264: D613000D 24A65518
	v_fmac_f32_e32 v40, v2, v23                                // 0000007F326C: 56502F02
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007F3270: BF870194
	v_add_co_ci_u32_e64 v12, null, s3, v10, s1                 // 0000007F3274: D5207C0C 00061403
	v_fmac_f32_e32 v42, v13, v38                               // 0000007F327C: 56544D0D
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007F3280: BF870003
	v_fma_f32 v2, -v32, v40, v39                               // 0000007F3284: D6130002 249E5120
	v_and_b32_e32 v32, 1, v34                                  // 0000007F328C: 36404481
	v_and_b32_e32 v34, 1, v35                                  // 0000007F3290: 36444681
	.long 0xd700010d                                           // 0000007F3294: D700010D
	v_cndmask_b32_e32 v0, v0, v2, vcc_lo                       // 0000007F3298: 02000500
	v_fma_f32 v24, -v24, v42, v41                              // 0000007F329C: D6130018 24A65518
	v_div_fmas_f32 v2, v2, v23, v40                            // 0000007F32A4: D6370002 04A22F02
	s_mov_b32 vcc_lo, s0                                       // 0000007F32AC: BEEA0000
	v_add3_u32 v17, v17, v32, 0x7fff                           // 0000007F32B0: D6550011 03FE4111 00007FFF
	v_add3_u32 v20, v20, v34, 0x7fff                           // 0000007F32BC: D6550014 03FE4514 00007FFF
	v_div_fmas_f32 v23, v24, v38, v42                          // 0000007F32C8: D6370017 04AA4D18
	v_div_fixup_f32 v2, v2, v31, v29                           // 0000007F32D0: D6270002 04763F02
	v_add_co_ci_u32_e64 v14, null, s3, v1, s1                  // 0000007F32D8: D5207C0E 00060203
	global_store_d16_hi_b16 v[3:4], v17, off                   // 0000007F32E0: DC960000 007C1103
	v_div_fixup_f32 v18, v23, v33, v30                         // 0000007F32E8: D6270012 047A4317
	.long 0x7e4a3982                                           // 0000007F32F0: 7E4A3982
	v_and_b32_e32 v3, 1, v36                                   // 0000007F32F4: 36064881
	global_store_d16_hi_b16 v[5:6], v16, off                   // 0000007F32F8: DC960000 007C1005
	v_add3_u32 v6, v19, v21, 0x7fff                            // 0000007F3300: D6550006 03FE2B13 00007FFF
	.long 0x7e1e3992                                           // 0000007F330C: 7E1E3992
	v_and_b32_e32 v4, 1, v37                                   // 0000007F3310: 36084A81
	global_store_d16_hi_b16 v[7:8], v20, off                   // 0000007F3314: DC960000 007C1407
	v_add3_u32 v7, v22, v3, 0x7fff                             // 0000007F331C: D6550007 03FE0716 00007FFF
	v_add3_u32 v8, v27, v28, 0x7fff                            // 0000007F3328: D6550008 03FE391B 00007FFF
	v_and_b32_e32 v5, 1, v15                                   // 0000007F3334: 360A1E81
	v_add3_u32 v4, v2, v4, 0x7fff                              // 0000007F3338: D6550004 03FE0902 00007FFF
	.long 0xd7006a02                                           // 0000007F3344: D7006A02
	v_cndmask_b32_e32 v0, v13, v2, vcc_lo                      // 0000007F3348: 0200050D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000007F334C: BF870211
	v_add_co_ci_u32_e64 v3, null, s3, v14, vcc_lo              // 0000007F3350: D5207C03 01AA1C03
	v_add3_u32 v5, v18, v5, 0x7fff                             // 0000007F3358: D6550005 03FE0B12 00007FFF
	s_clause 0x4                                               // 0000007F3364: BF850004
	global_store_d16_hi_b16 v[0:1], v6, off                    // 0000007F3368: DC960000 007C0600
	global_store_d16_hi_b16 v[9:10], v7, off                   // 0000007F3370: DC960000 007C0709
	global_store_d16_hi_b16 v[13:14], v8, off                  // 0000007F3378: DC960000 007C080D
	global_store_d16_hi_b16 v[11:12], v4, off                  // 0000007F3380: DC960000 007C040B
	global_store_d16_hi_b16 v[2:3], v5, off                    // 0000007F3388: DC960000 007C0502
	s_endpgm                                                   // 0000007F3390: BFB00000
		...

