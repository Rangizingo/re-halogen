0000000000dc2300 <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_oILi1EEEvPKhlPKDF16_PKiPfS5_S5_PDF16_PjNS0_5I4rSdEiS7_>:
; _ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_oILi1EEEvPKhlPKDF16_PKiPfS5_S5_PDF16_PjNS0_5I4rSdEiS7_():
	s_clause 0x1                                               // 000000DC2300: BF850001
	s_load_b32 s3, s[0:1], 0xa0                                // 000000DC2304: F40000C0 F80000A0
	s_load_b512 s[12:27], s[0:1], 0x40                         // 000000DC230C: F4100300 F8000040
	s_mov_b32 s4, -1                                           // 000000DC2314: BE8400C1
	s_waitcnt lgkmcnt(0)                                       // 000000DC2318: BF89FC07
	s_cmp_lt_i32 s2, s3                                        // 000000DC231C: BF040302
	s_cbranch_scc1 2236                                        // 000000DC2320: BFA208BC <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_oILi1EEEvPKhlPKDF16_PKiPfS5_S5_PDF16_PjNS0_5I4rSdEiS7_+0x2314>
	s_load_b64 s[10:11], s[0:1], 0x94                          // 000000DC2324: F4040280 F8000094
	s_sub_i32 s3, s2, s3                                       // 000000DC232C: 81830302
	s_clause 0x1                                               // 000000DC2330: BF850001
	s_load_b128 s[28:31], s[0:1], 0x88                         // 000000DC2334: F4080700 F8000088
	s_load_b64 s[36:37], s[0:1], 0x80                          // 000000DC233C: F4040900 F8000080
	v_lshrrev_b32_e32 v8, 5, v0                                // 000000DC2344: 32100085
	v_and_b32_e32 v9, 31, v0                                   // 000000DC2348: 3612009F
	s_mov_b32 s40, 0                                           // 000000DC234C: BEA80080
	s_mov_b32 s38, exec_lo                                     // 000000DC2350: BEA6007E
	s_waitcnt lgkmcnt(0)                                       // 000000DC2354: BF89FC07
	s_abs_i32 s4, s11                                          // 000000DC2358: BE84150B
	s_ashr_i32 s7, s11, 31                                     // 000000DC235C: 86079F0B
	s_cvt_f32_u32 s5, s4                                       // 000000DC2360: BE856504
	s_sub_i32 s6, 0, s4                                        // 000000DC2364: 81860480
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000DC2368: BF87029A
	v_rcp_iflag_f32_e32 v1, s5                                 // 000000DC236C: 7E025605
	v_readfirstlane_b32 s5, v1                                 // 000000DC2370: 7E0A0501
	s_mul_f32 s5, s5, 0x4f7ffffe                               // 000000DC2374: A205FF05 4F7FFFFE
	s_delay_alu instid0(SALU_CYCLE_3) | instskip(NEXT) | instid1(SALU_CYCLE_3)// 000000DC237C: BF87059B
	s_cvt_u32_f32 s5, s5                                       // 000000DC2380: BE856705
	s_mul_i32 s6, s6, s5                                       // 000000DC2384: 96060506
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000DC2388: BF870499
	s_mul_hi_u32 s6, s5, s6                                    // 000000DC238C: 96860605
	s_add_i32 s5, s5, s6                                       // 000000DC2390: 81050605
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000DC2394: BF870499
	s_mul_hi_u32 s5, s3, s5                                    // 000000DC2398: 96850503
	s_mul_i32 s6, s5, s4                                       // 000000DC239C: 96060405
	s_add_i32 s8, s5, 1                                        // 000000DC23A0: 81088105
	s_sub_i32 s6, s3, s6                                       // 000000DC23A4: 81860603
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000DC23A8: BF870009
	s_sub_i32 s9, s6, s4                                       // 000000DC23AC: 81890406
	s_cmp_ge_u32 s6, s4                                        // 000000DC23B0: BF090406
	s_cselect_b32 s5, s8, s5                                   // 000000DC23B4: 98050508
	s_cselect_b32 s6, s9, s6                                   // 000000DC23B8: 98060609
	s_add_i32 s8, s5, 1                                        // 000000DC23BC: 81088105
	s_cmp_ge_u32 s6, s4                                        // 000000DC23C0: BF090406
	s_cselect_b32 s4, s8, s5                                   // 000000DC23C4: 98040508
	s_ashr_i32 s33, s30, 31                                    // 000000DC23C8: 86219F1E
	s_xor_b32 s4, s4, s7                                       // 000000DC23CC: 8D040704
	s_lshr_b32 s5, s33, 25                                     // 000000DC23D0: 85059921
	s_sub_i32 s34, s4, s7                                      // 000000DC23D4: 81A20704
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000DC23D8: BF870499
	s_mul_i32 s4, s34, s11                                     // 000000DC23DC: 96040B22
	s_sub_i32 s31, s3, s4                                      // 000000DC23E0: 819F0403
	s_add_i32 s3, s30, s5                                      // 000000DC23E4: 8103051E
	s_mul_i32 s35, s31, s10                                    // 000000DC23E8: 96230A1F
	s_ashr_i32 s3, s3, 7                                       // 000000DC23EC: 86038703
	s_add_i32 s4, s35, s10                                     // 000000DC23F0: 81040A23
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000DC23F4: BF870499
	s_min_i32 s3, s3, s4                                       // 000000DC23F8: 89030403
	s_sub_i32 s39, s3, s35                                     // 000000DC23FC: 81A72303
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000DC2400: BF870009
	.long 0xd4c4007e                                           // 000000DC2404: D4C4007E
	v_cndmask_b32_e32 v1, s39, v8, vcc_lo                      // 000000DC2408: 02021027
	s_cbranch_execz 503                                        // 000000DC240C: BFA501F7 <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_oILi1EEEvPKhlPKDF16_PKiPfS5_S5_PDF16_PjNS0_5I4rSdEiS7_+0x8ec>
	s_add_i32 s41, s28, -1                                     // 000000DC2410: 8129C11C
	s_cmp_lg_u64 s[22:23], 0                                   // 000000DC2414: BF118016
	v_dual_mov_b32 v10, v8 :: v_dual_and_b32 v1, 1, v0         // 000000DC2418: CA240108 0A000081
	s_cselect_b32 s42, -1, 0                                   // 000000DC2420: 982A80C1
	s_abs_i32 s43, s39                                         // 000000DC2424: BEAB1527
	v_and_b32_e32 v2, 2, v0                                    // 000000DC2428: 36040082
	s_cvt_f32_u32 s3, s43                                      // 000000DC242C: BE83652B
	v_lshlrev_b32_e32 v6, 3, v9                                // 000000DC2430: 300C1283
	v_lshlrev_b32_e32 v7, 7, v8                                // 000000DC2434: 300E1087
	v_and_b32_e32 v3, 4, v0                                    // 000000DC2438: 36060084
	v_rcp_iflag_f32_e32 v4, s3                                 // 000000DC243C: 7E085603
	v_and_b32_e32 v5, 8, v0                                    // 000000DC2440: 360A0088
	.long 0xd44a0004                                           // 000000DC2444: D44A0004
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 000000DC2448: 02020280
	.long 0xd44a0005                                           // 000000DC244C: D44A0005
	v_cndmask_b32_e32 v1, 0, v2, vcc_lo                        // 000000DC2450: 02020480
	v_lshl_or_b32 v1, v8, 8, v6                                // 000000DC2454: D6560001 04191108
	v_lshl_add_u32 v2, s35, 7, v7                              // 000000DC245C: D6460002 041D0E23
	s_ashr_i32 s45, s39, 31                                    // 000000DC2464: 862D9F27
	s_sub_i32 s47, 0, s43                                      // 000000DC2468: 81AF2B80
	s_mul_i32 s10, s45, 0x1400                                 // 000000DC246C: 960AFF2D 00001400
	.long 0xd44c0003                                           // 000000DC2474: D44C0003
	v_cndmask_b32_e32 v1, 16, v9, vcc_lo                       // 000000DC2478: 02021290
	v_readfirstlane_b32 s7, v4                                 // 000000DC247C: 7E0E0504
	.long 0xd44a0006                                           // 000000DC2480: D44A0006
	v_cndmask_b32_e32 v1, 0, v3, vcc_lo                        // 000000DC2484: 02020680
	v_subrev_nc_u32_e32 v11, s10, v1                           // 000000DC2488: 4E16020A
	v_lshl_or_b32 v1, v9, 2, v2                                // 000000DC248C: D6560001 04090509
	s_lshl_b32 s8, s39, 7                                      // 000000DC2494: 84088727
	s_mul_f32 s9, s7, 0x4f7ffffe                               // 000000DC2498: A209FF07 4F7FFFFE
	.long 0xd44a0007                                           // 000000DC24A0: D44A0007
	v_cndmask_b32_e32 v1, 0, v5, vcc_lo                        // 000000DC24A4: 02020A80
	s_mov_b32 s44, 0x76543210                                  // 000000DC24A8: BEAC00FF 76543210
	s_lshl_b32 s46, s39, 8                                     // 000000DC24B0: 842E8827
	s_cvt_u32_f32 s9, s9                                       // 000000DC24B4: BE896709
	s_mov_b32 s49, 0x3db504f3                                  // 000000DC24B8: BEB100FF 3DB504F3
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000DC24C0: BF87049A
	s_mul_i32 s47, s47, s9                                     // 000000DC24C4: 962F092F
	s_mul_hi_u32 s10, s9, s47                                  // 000000DC24C8: 968A2F09
	s_sub_i32 s47, 0, s8                                       // 000000DC24CC: 81AF0880
	s_add_i32 s48, s9, s10                                     // 000000DC24D0: 81300A09
	s_branch 164                                               // 000000DC24D4: BFA000A4 <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_oILi1EEEvPKhlPKDF16_PKiPfS5_S5_PDF16_PjNS0_5I4rSdEiS7_+0x468>
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DC24D8: BF870091
	.long 0xd7006a02                                           // 000000DC24DC: D7006A02
	v_cndmask_b32_e32 v1, s16, v2, vcc_lo                      // 000000DC24E0: 02020410
	v_add_co_ci_u32_e64 v3, null, s17, v3, vcc_lo              // 000000DC24E4: D5207C03 01AA0611
	v_add_nc_u32_e32 v1, 0x400, v1                             // 000000DC24EC: 4A0202FF 00000400
	v_add_nc_u32_e32 v10, 8, v10                               // 000000DC24F4: 4A141488
	global_load_d16_b16 v2, v[2:3], off offset:6               // 000000DC24F8: DC820006 027C0002
	v_cmp_le_i32_e32 vcc_lo, s39, v10                          // 000000DC2500: 7C861427
	s_or_b32 s40, vcc_lo, s40                                  // 000000DC2504: 8C28286A
	s_waitcnt vmcnt(0)                                         // 000000DC2508: BF8903F7
	v_fma_mix_f32 v5, v16, v2, v14 op_sel_hi:[0,1,0]           // 000000DC250C: CC200005 143A0510
	v_sub_f32_e32 v4, v17, v15                                 // 000000DC2514: 08081F11
	v_fma_mix_f32 v2, -v16, v2, v14 op_sel_hi:[0,1,0]          // 000000DC2518: CC200002 343A0510
	v_add_f32_e32 v3, v17, v15                                 // 000000DC2520: 06061F11
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000DC2524: BF8701A2
	v_add_f32_e32 v7, v4, v2                                   // 000000DC2528: 060E0504
	v_sub_f32_e32 v2, v4, v2                                   // 000000DC252C: 08040504
	v_add_f32_e32 v6, v3, v5                                   // 000000DC2530: 060C0B03
	v_sub_f32_e32 v3, v3, v5                                   // 000000DC2534: 08060B03
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DC2538: BF870193
	v_mov_b32_dpp v15, v2 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DC253C: 7E1E02FA FF016102
	v_mov_b32_dpp v4, v6 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DC2544: 7E0802FA FF016106
	v_cndmask_b32_e64 v6, -v6, v6, s4                          // 000000DC254C: D5010006 20120D06
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000DC2554: BF870234
	v_mov_b32_dpp v14, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DC2558: 7E1C02FA FF016103
	v_cndmask_b32_e64 v2, -v2, v2, s4                          // 000000DC2560: D5010002 20120502
	v_cndmask_b32_e64 v3, -v3, v3, s4                          // 000000DC2568: D5010003 20120703
	v_add_f32_e32 v4, v6, v4                                   // 000000DC2570: 06080906
	v_mov_b32_dpp v5, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DC2574: 7E0A02FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, s4                          // 000000DC257C: D5010007 20120F07
	.long 0xd72c0006                                           // 000000DC2584: D72C0006
	v_cndmask_b32_e32 v1, 0x1400, v13, vcc_lo                  // 000000DC2588: 02021AFF 00001400
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000DC2590: BF870242
	v_dual_add_f32 v2, v2, v15 :: v_dual_add_f32 v5, v7, v5    // 000000DC2594: C9081F02 02040B07
	v_mov_b32_dpp v7, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DC259C: 7E0E02FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, s5                          // 000000DC25A4: D5010004 20160904
	v_add_f32_e32 v3, v3, v14                                  // 000000DC25AC: 06061D03
	v_mov_b32_dpp v15, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DC25B0: 7E1E02FA FF016202
	v_mov_b32_dpp v13, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DC25B8: 7E1A02FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, s5                          // 000000DC25C0: D5010005 20160B05
	v_cndmask_b32_e64 v2, -v2, v2, s5                          // 000000DC25C8: D5010002 20160502
	v_add_f32_e32 v4, v4, v7                                   // 000000DC25D0: 06080F04
	v_mov_b32_dpp v14, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DC25D4: 7E1C02FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, s5                          // 000000DC25DC: D5010003 20160703
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DC25E4: BF870004
	v_dual_add_f32 v5, v5, v13 :: v_dual_add_f32 v2, v2, v15   // 000000DC25E8: C9081B05 05021F02
	.long 0xd72c0007                                           // 000000DC25F0: D72C0007
	v_cndmask_b32_e32 v1, s46, v12, vcc_lo                     // 000000DC25F4: 0202182E
	v_mov_b32_dpp v12, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DC25F8: 7E1802FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s6                          // 000000DC2600: D5010004 201A0904
	v_add_f32_e32 v3, v3, v14                                  // 000000DC2608: 06061D03
	v_mov_b32_dpp v13, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DC260C: 7E1A02FA FF016405
	v_cndmask_b32_e64 v5, -v5, v5, s6                          // 000000DC2614: D5010005 201A0B05
	v_mov_b32_dpp v15, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DC261C: 7E1E02FA FF016402
	v_cndmask_b32_e64 v2, -v2, v2, s6                          // 000000DC2624: D5010002 201A0502
	v_add_f32_e32 v4, v4, v12                                  // 000000DC262C: 06081904
	v_mov_b32_dpp v14, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DC2630: 7E1C02FA FF016403
	v_cndmask_b32_e64 v3, -v3, v3, s6                          // 000000DC2638: D5010003 201A0703
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DC2640: BF870214
	v_dual_add_f32 v5, v5, v13 :: v_dual_add_f32 v2, v2, v15   // 000000DC2644: C9081B05 05021F02
	v_mov_b32_dpp v12, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DC264C: 7E1802FA FF016804
	v_cndmask_b32_e64 v4, -v4, v4, s7                          // 000000DC2654: D5010004 201E0904
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DC265C: BF870214
	v_add_f32_e32 v3, v3, v14                                  // 000000DC2660: 06061D03
	v_mov_b32_dpp v13, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DC2664: 7E1A02FA FF016805
	v_cndmask_b32_e64 v5, -v5, v5, s7                          // 000000DC266C: D5010005 201E0B05
	v_mov_b32_dpp v15, v2 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DC2674: 7E1E02FA FF016802
	v_cndmask_b32_e64 v2, -v2, v2, s7                          // 000000DC267C: D5010002 201E0502
	v_mov_b32_dpp v14, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DC2684: 7E1C02FA FF016803
	v_cndmask_b32_e64 v3, -v3, v3, s7                          // 000000DC268C: D5010003 201E0703
	v_dual_add_f32 v4, v4, v12 :: v_dual_add_f32 v5, v5, v13   // 000000DC2694: C9081904 04041B05
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000DC269C: BF8701A4
	v_add_f32_e32 v2, v2, v15                                  // 000000DC26A0: 06041F02
	v_sub_nc_u32_e32 v6, v6, v7                                // 000000DC26A4: 4C0C0F06
	v_dual_add_f32 v3, v3, v14 :: v_dual_mov_b32 v12, v4       // 000000DC26A8: C9101D03 030C0104
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DC26B0: BF870004
	v_mov_b32_e32 v13, v5                                      // 000000DC26B4: 7E1A0305
	v_cndmask_b32_e64 v5, -v5, v5, s3                          // 000000DC26B8: D5010005 200E0B05
	v_mov_b32_e32 v15, v2                                      // 000000DC26C0: 7E1E0302
	v_cndmask_b32_e64 v4, -v4, v4, s3                          // 000000DC26C4: D5010004 200E0904
	v_cndmask_b32_e64 v2, -v2, v2, s3                          // 000000DC26CC: D5010002 200E0502
	v_permlanex16_b32 v13, v13, s44, 0xfedcba98                // 000000DC26D4: D65C000D 03FC590D FEDCBA98
	v_mov_b32_e32 v14, v3                                      // 000000DC26E0: 7E1C0303
	v_cndmask_b32_e64 v3, -v3, v3, s3                          // 000000DC26E4: D5010003 200E0703
	v_permlanex16_b32 v12, v12, s44, 0xfedcba98                // 000000DC26EC: D65C000C 03FC590C FEDCBA98
	v_permlanex16_b32 v15, v15, s44, 0xfedcba98                // 000000DC26F8: D65C000F 03FC590F FEDCBA98
	v_add_f32_e32 v5, v5, v13                                  // 000000DC2704: 060A1B05
	v_permlanex16_b32 v14, v14, s44, 0xfedcba98                // 000000DC2708: D65C000E 03FC590E FEDCBA98
	v_add_nc_u32_e32 v6, v11, v6                               // 000000DC2714: 4A0C0D0B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DC2718: BF870214
	v_dual_add_f32 v4, v4, v12 :: v_dual_add_f32 v7, v2, v15   // 000000DC271C: C9081904 04061F02
	v_fma_mixhi_f16 v2, v5, s49, 0                             // 000000DC2724: CC220002 02006305
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DC272C: BF870194
	v_dual_add_f32 v12, v3, v14 :: v_dual_add_nc_u32 v11, 0x800, v11// 000000DC2730: C9201D03 0C0A16FF 00000800
	v_fma_mixlo_f16 v2, v4, s49, 0                             // 000000DC273C: CC210002 02006304
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DC2744: BF870194
	v_fma_mixhi_f16 v3, v7, s49, 0                             // 000000DC2748: CC220003 02006307
	v_fma_mixlo_f16 v3, v12, s49, 0                            // 000000DC2750: CC210003 0200630C
	ds_store_b64 v6, v[2:3]                                    // 000000DC2758: D9340000 00000206
	s_and_not1_b32 exec_lo, exec_lo, s40                       // 000000DC2760: 917E287E
	s_cbranch_execz 289                                        // 000000DC2764: BFA50121 <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_oILi1EEEvPKhlPKDF16_PKiPfS5_S5_PDF16_PjNS0_5I4rSdEiS7_+0x8ec>
	.long 0xd72d0002                                           // 000000DC2768: D72D0002
	v_cndmask_b32_e32 v0, v10, v48, vcc_lo                     // 000000DC276C: 0200610A
	s_mov_b32 s8, -1                                           // 000000DC2770: BE8800C1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DC2774: BF870091
	.long 0xd72c0003                                           // 000000DC2778: D72C0003
	v_cndmask_b32_e32 v0, v2, v43, vcc_lo                      // 000000DC277C: 02005702
	v_sub_nc_u32_e32 v3, v10, v3                               // 000000DC2780: 4C06070A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000DC2784: BF870121
	v_subrev_nc_u32_e32 v5, s43, v3                            // 000000DC2788: 4E0A062B
	v_cmp_le_u32_e32 vcc_lo, s43, v3                           // 000000DC278C: 7C96062B
	v_dual_cndmask_b32 v3, v3, v5 :: v_dual_add_nc_u32 v4, 1, v2// 000000DC2790: CA600B03 03040481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DC2798: BF870111
	v_cndmask_b32_e32 v2, v2, v4, vcc_lo                       // 000000DC279C: 02040902
	v_cmp_le_u32_e32 vcc_lo, s43, v3                           // 000000DC27A0: 7C96062B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DC27A4: BF870092
	v_add_nc_u32_e32 v4, 1, v2                                 // 000000DC27A8: 4A080481
	v_cndmask_b32_e32 v2, v2, v4, vcc_lo                       // 000000DC27AC: 02040902
	s_and_not1_b32 vcc_lo, exec_lo, s42                        // 000000DC27B0: 916A2A7E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DC27B4: BF870091
	v_xor_b32_e32 v13, s45, v2                                 // 000000DC27B8: 3A1A042D
	v_subrev_nc_u32_e32 v12, s45, v13                          // 000000DC27BC: 4E181A2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DC27C0: BF8700A1
	v_mad_u64_u32 v[6:7], null, s47, v12, v[1:2]               // 000000DC27C4: D6FE7C06 0406182F
	v_min_i32_e32 v2, s41, v12                                 // 000000DC27CC: 22041829
	v_mad_i64_i32 v[4:5], null, v2, s30, 0                     // 000000DC27D0: D6FF7C04 02003D02
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DC27D8: BF870093
	v_ashrrev_i32_e32 v7, 31, v6                               // 000000DC27DC: 340E0C9F
	.long 0xd73c0002                                           // 000000DC27E0: D73C0002
	v_cndmask_b32_e32 v1, 1, v6, vcc_lo                        // 000000DC27E4: 02020C81
	s_cbranch_vccnz 212                                        // 000000DC27E8: BFA400D4 <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_oILi1EEEvPKhlPKDF16_PKiPfS5_S5_PDF16_PjNS0_5I4rSdEiS7_+0x83c>
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DC27EC: BF870093
	.long 0xd7006a06                                           // 000000DC27F0: D7006A06
	v_cndmask_b32_e32 v1, v4, v6, vcc_lo                       // 000000DC27F4: 02020D04
	v_add_co_ci_u32_e64 v7, null, v5, v7, vcc_lo               // 000000DC27F8: D5207C07 01AA0F05
	.long 0x7f3c3880                                           // 000000DC2800: 7F3C3880
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DC2804: BF870112
	.long 0xd73c0006                                           // 000000DC2808: D73C0006
	v_cndmask_b32_e32 v1, 1, v6, vcc_lo                        // 000000DC280C: 02020C81
	.long 0x7f42399e                                           // 000000DC2810: 7F42399E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DC2814: BF870092
	.long 0xd7006a0e                                           // 000000DC2818: D7006A0E
	v_cndmask_b32_e32 v1, s20, v6, vcc_lo                      // 000000DC281C: 02020C14
	v_add_co_ci_u32_e64 v15, null, s21, v7, vcc_lo             // 000000DC2820: D5207C0F 01AA0E15
	.long 0xd7006a06                                           // 000000DC2828: D7006A06
	v_cndmask_b32_e32 v1, s22, v6, vcc_lo                      // 000000DC282C: 02020C16
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DC2830: BF870001
	v_add_co_ci_u32_e64 v7, null, s23, v7, vcc_lo              // 000000DC2834: D5207C07 01AA0E17
	global_load_b64 v[14:15], v[14:15], off                    // 000000DC283C: DC560000 0E7C000E
	.long 0xd7006a10                                           // 000000DC2844: D7006A10
	v_cndmask_b32_e32 v1, s16, v2, vcc_lo                      // 000000DC2848: 02020410
	global_load_b64 v[6:7], v[6:7], off                        // 000000DC284C: DC560000 067C0006
	v_add_co_ci_u32_e64 v17, null, s17, v3, vcc_lo             // 000000DC2854: D5207C11 01AA0611
	s_clause 0x1                                               // 000000DC285C: BF850001
	global_load_b32 v18, v[16:17], off                         // 000000DC2860: DC520000 127C0010
	global_load_d16_b16 v16, v[16:17], off offset:4            // 000000DC2868: DC820004 107C0010
	s_waitcnt vmcnt(3)                                         // 000000DC2870: BF890FF7
	.long 0x7e22390e                                           // 000000DC2874: 7E22390E
	s_waitcnt vmcnt(2)                                         // 000000DC2878: BF890BF7
	v_and_b32_e32 v40, 0xffff0000, v6                          // 000000DC287C: 36500CFF FFFF0000
	v_lshlrev_b32_e32 v6, 16, v6                               // 000000DC2884: 300C0C90
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DC2888: BF870093
	v_lshlrev_b32_e32 v17, 16, v17                             // 000000DC288C: 30222290
	v_mul_f32_e32 v21, 0xbfb8aa3b, v17                         // 000000DC2890: 102A22FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000DC2898: BF870291
	v_exp_f32_e32 v21, v21                                     // 000000DC289C: 7E2A4B15
	v_dual_add_f32 v21, 1.0, v21 :: v_dual_and_b32 v14, 0xffff0000, v14// 000000DC28A0: C9242AF2 150E1CFF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DC28AC: BF870111
	v_mul_f32_e32 v20, 0xbfb8aa3b, v14                         // 000000DC28B0: 10281CFF BFB8AA3B
	v_div_scale_f32 v25, null, v21, v21, v17                   // 000000DC28B8: D6FC7C19 04462B15
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000DC28C0: BF8701B2
	v_exp_f32_e32 v20, v20                                     // 000000DC28C4: 7E284B14
	v_lshlrev_b32_e32 v19, 16, v15                             // 000000DC28C8: 30261E90
	v_div_scale_f32 v38, s9, v17, v21, v17                     // 000000DC28CC: D6FC0926 04462B11
	v_rcp_f32_e32 v29, v25                                     // 000000DC28D4: 7E3A5519
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DC28D8: BF870196
	v_add_f32_e32 v20, 1.0, v20                                // 000000DC28DC: 062828F2
	v_mul_f32_e32 v22, 0xbfb8aa3b, v19                         // 000000DC28E0: 102C26FF BFB8AA3B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DC28E8: BF870195
	v_fma_f32 v37, -v25, v29, 1.0                              // 000000DC28EC: D6130025 23CA3B19
	v_div_scale_f32 v24, null, v20, v20, v14                   // 000000DC28F4: D6FC7C18 043A2914
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000DC28FC: BF8701B3
	v_exp_f32_e32 v22, v22                                     // 000000DC2900: 7E2C4B16
	v_and_b32_e32 v15, 0xffff0000, v15                         // 000000DC2904: 361E1EFF FFFF0000
	v_div_scale_f32 v34, vcc_lo, v14, v20, v14                 // 000000DC290C: D6FC6A22 043A290E
	v_rcp_f32_e32 v27, v24                                     // 000000DC2914: 7E365518
	s_delay_alu instid0(TRANS32_DEP_2) | instid1(VALU_DEP_2)   // 000000DC2918: BF870106
	v_dual_add_f32 v22, 1.0, v22 :: v_dual_mul_f32 v23, 0xbfb8aa3b, v15// 000000DC291C: C9062CF2 16161EFF BFB8AA3B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DC2928: BF870115
	v_fma_f32 v35, -v24, v27, 1.0                              // 000000DC292C: D6130023 23CA3718
	v_div_scale_f32 v26, null, v22, v22, v19                   // 000000DC2934: D6FC7C1A 044E2D16
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000DC293C: BF8701A3
	v_exp_f32_e32 v23, v23                                     // 000000DC2940: 7E2E4B17
	v_div_scale_f32 v36, s8, v19, v22, v19                     // 000000DC2944: D6FC0824 044E2D13
	v_fmac_f32_e32 v27, v35, v27                               // 000000DC294C: 56363723
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 000000DC2950: BF870313
	v_rcp_f32_e32 v31, v26                                     // 000000DC2954: 7E3E551A
	v_add_f32_e32 v23, 1.0, v23                                // 000000DC2958: 062E2EF2
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DC295C: BF870115
	v_fma_f32 v39, -v26, v31, 1.0                              // 000000DC2960: D6130027 23CA3F1A
	v_div_scale_f32 v28, null, v23, v23, v15                   // 000000DC2968: D6FC7C1C 043E2F17
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000DC2970: BF8701A2
	v_fmac_f32_e32 v31, v39, v31                               // 000000DC2974: 563E3F27
	v_mul_f32_e32 v39, v34, v27                                // 000000DC2978: 104E3722
	v_rcp_f32_e32 v32, v28                                     // 000000DC297C: 7E40551C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DC2980: BF870091
	v_fma_f32 v42, -v24, v39, v34                              // 000000DC2984: D613002A 248A4F18
	v_fmac_f32_e32 v39, v42, v27                               // 000000DC298C: 564E372A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DC2990: BF870115
	v_fma_f32 v35, -v28, v32, 1.0                              // 000000DC2994: D6130023 23CA411C
	v_fma_f32 v24, -v24, v39, v34                              // 000000DC299C: D6130018 248A4F18
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DC29A4: BF870112
	v_fmac_f32_e32 v32, v35, v32                               // 000000DC29A8: 56404123
	v_div_fmas_f32 v24, v24, v27, v39                          // 000000DC29AC: D6370018 049E3718
	s_mov_b32 vcc_lo, s9                                       // 000000DC29B4: BEEA0009
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000DC29B8: BF8701B1
	v_div_fixup_f32 v14, v24, v20, v14                         // 000000DC29BC: D627000E 043A2918
	v_fmac_f32_e32 v29, v37, v29                               // 000000DC29C4: 563A3B25
	v_div_scale_f32 v37, s10, v15, v23, v15                    // 000000DC29C8: D6FC0A25 043E2F0F
	v_mul_f32_e32 v14, v14, v40                                // 000000DC29D0: 101C510E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DC29D4: BF870193
	v_mul_f32_e32 v35, v38, v29                                // 000000DC29D8: 10463B26
	v_mul_f32_e32 v43, v37, v32                                // 000000DC29DC: 10564125
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DC29E0: BF870193
	.long 0x7e3c398e                                           // 000000DC29E4: 7E3C398E
	v_fma_f32 v44, -v25, v35, v38                              // 000000DC29E8: D613002C 249A4719
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DC29F0: BF870113
	v_fma_f32 v42, -v28, v43, v37                              // 000000DC29F4: D613002A 2496571C
	v_fmac_f32_e32 v35, v44, v29                               // 000000DC29FC: 56463B2C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DC2A00: BF870112
	v_fmac_f32_e32 v43, v42, v32                               // 000000DC2A04: 5656412A
	v_fma_f32 v25, -v25, v35, v38                              // 000000DC2A08: D6130019 249A4719
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DC2A10: BF870112
	v_fma_f32 v24, -v28, v43, v37                              // 000000DC2A14: D6130018 2496571C
	v_div_fmas_f32 v25, v25, v29, v35                          // 000000DC2A1C: D6370019 048E3B19
	s_mov_b32 vcc_lo, s8                                       // 000000DC2A24: BEEA0008
	s_mov_b32 s8, 0                                            // 000000DC2A28: BE880080
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000DC2A2C: BF870121
	v_div_fixup_f32 v17, v25, v21, v17                         // 000000DC2A30: D6270011 04462B19
	v_lshlrev_b32_e32 v21, 16, v7                              // 000000DC2A38: 302A0E90
	v_dual_mul_f32 v6, v17, v6 :: v_dual_and_b32 v7, 0xffff0000, v7// 000000DC2A3C: C8E40D11 06060EFF FFFF0000
	v_mul_f32_e32 v41, v36, v31                                // 000000DC2A48: 10523F24
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DC2A4C: BF870112
	.long 0x7e423986                                           // 000000DC2A50: 7E423986
	v_fma_f32 v45, -v26, v41, v36                              // 000000DC2A54: D613002D 2492531A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DC2A5C: BF870091
	v_fmac_f32_e32 v41, v45, v31                               // 000000DC2A60: 56523F2D
	v_fma_f32 v26, -v26, v41, v36                              // 000000DC2A64: D613001A 2492531A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000DC2A6C: BF870131
	v_div_fmas_f32 v20, v26, v31, v41                          // 000000DC2A70: D6370014 04A63F1A
	s_mov_b32 vcc_lo, s10                                      // 000000DC2A78: BEEA000A
	v_div_fmas_f32 v17, v24, v32, v43                          // 000000DC2A7C: D6370011 04AE4118
	v_div_fixup_f32 v19, v20, v22, v19                         // 000000DC2A84: D6270013 044E2D14
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000DC2A8C: BF8701A2
	v_div_fixup_f32 v15, v17, v23, v15                         // 000000DC2A90: D627000F 043E2F11
	v_and_b32_e32 v17, 1, v30                                  // 000000DC2A98: 36223C81
	v_mul_f32_e32 v19, v19, v21                                // 000000DC2A9C: 10262B13
	v_and_b32_e32 v21, 1, v33                                  // 000000DC2AA0: 362A4281
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DC2AA4: BF870214
	v_mul_f32_e32 v7, v15, v7                                  // 000000DC2AA8: 100E0F0F
	v_add3_u32 v14, v14, v17, 0x7fff                           // 000000DC2AAC: D655000E 03FE230E 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DC2AB8: BF870214
	v_bfe_u32 v20, v19, 16, 1                                  // 000000DC2ABC: D6100014 02052113
	v_add3_u32 v6, v6, v21, 0x7fff                             // 000000DC2AC4: D6550006 03FE2B06 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DC2AD0: BF870214
	v_bfe_u32 v17, v7, 16, 1                                   // 000000DC2AD4: D6100011 02052107
	v_and_b32_e32 v14, 0xffff0000, v14                         // 000000DC2ADC: 361C1CFF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DC2AE4: BF870214
	v_add3_u32 v15, v19, v20, 0x7fff                           // 000000DC2AE8: D655000F 03FE2913 00007FFF
	v_and_b32_e32 v6, 0xffff0000, v6                           // 000000DC2AF4: 360C0CFF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DC2AFC: BF870194
	v_add3_u32 v7, v7, v17, 0x7fff                             // 000000DC2B00: D6550007 03FE2307 00007FFF
	v_and_b32_e32 v19, 0xffff0000, v15                         // 000000DC2B0C: 36261EFF FFFF0000
	s_waitcnt vmcnt(1)                                         // 000000DC2B14: BF8907F7
	v_fma_mix_f32 v15, v18, v14, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000DC2B18: CC20080F 8A021D12
	v_fma_mix_f32 v17, v18, v6, neg(0) op_sel_hi:[1,0,0]       // 000000DC2B20: CC200011 8A020D12
	s_waitcnt vmcnt(0)                                         // 000000DC2B28: BF8903F7
	v_fma_mix_f32 v14, v16, v19, neg(0) op_sel_hi:[1,0,0]      // 000000DC2B2C: CC20000E 8A022710
	v_and_b32_e32 v16, 0xffff0000, v7                          // 000000DC2B34: 36200EFF FFFF0000
	s_and_not1_b32 vcc_lo, exec_lo, s8                         // 000000DC2B3C: 916A087E
	s_cbranch_vccnz 65125                                      // 000000DC2B40: BFA4FE65 <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_oILi1EEEvPKhlPKDF16_PKiPfS5_S5_PDF16_PjNS0_5I4rSdEiS7_+0x1d8>
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DC2B44: BF870093
	.long 0xd73c0004                                           // 000000DC2B48: D73C0004
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 000000DC2B4C: 02020881
	.long 0xd7006a04                                           // 000000DC2B50: D7006A04
	v_cndmask_b32_e32 v1, s20, v4, vcc_lo                      // 000000DC2B54: 02020814
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DC2B58: BF870111
	v_add_co_ci_u32_e64 v5, null, s21, v5, vcc_lo              // 000000DC2B5C: D5207C05 01AA0A15
	.long 0xd7006a04                                           // 000000DC2B64: D7006A04
	v_cndmask_b32_e32 v1, v4, v2, vcc_lo                       // 000000DC2B68: 02020504
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DC2B6C: BF8700A1
	v_add_co_ci_u32_e64 v5, null, v5, v3, vcc_lo               // 000000DC2B70: D5207C05 01AA0705
	.long 0xd7006a06                                           // 000000DC2B78: D7006A06
	v_cndmask_b32_e32 v1, s16, v2, vcc_lo                      // 000000DC2B7C: 02020410
	v_add_co_ci_u32_e64 v7, null, s17, v3, vcc_lo              // 000000DC2B80: D5207C07 01AA0611
	global_load_b64 v[4:5], v[4:5], off                        // 000000DC2B88: DC560000 047C0004
	s_clause 0x1                                               // 000000DC2B90: BF850001
	global_load_b32 v16, v[6:7], off                           // 000000DC2B94: DC520000 107C0006
	global_load_d16_b16 v6, v[6:7], off offset:4               // 000000DC2B9C: DC820004 067C0006
	s_waitcnt vmcnt(2)                                         // 000000DC2BA4: BF890BF7
	.long 0x7e0e3904                                           // 000000DC2BA8: 7E0E3904
	v_and_b32_e32 v4, 0xffff0000, v4                           // 000000DC2BAC: 360808FF FFFF0000
	v_lshlrev_b32_e32 v14, 16, v5                              // 000000DC2BB4: 301C0A90
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000DC2BB8: BF8701A3
	v_lshlrev_b32_e32 v7, 16, v7                               // 000000DC2BBC: 300E0E90
	s_waitcnt vmcnt(1)                                         // 000000DC2BC0: BF8907F7
	v_fma_mix_f32 v15, v16, v4, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000DC2BC4: CC20080F 8A020910
	s_waitcnt vmcnt(0)                                         // 000000DC2BCC: BF8903F7
	v_fma_mix_f32 v14, v6, v14, neg(0) op_sel_hi:[1,0,0]       // 000000DC2BD0: CC20000E 8A021D06
	v_fma_mix_f32 v17, v16, v7, neg(0) op_sel_hi:[1,0,0]       // 000000DC2BD8: CC200011 8A020F10
	v_and_b32_e32 v16, 0xffff0000, v5                          // 000000DC2BE0: 36200AFF FFFF0000
	s_branch 65083                                             // 000000DC2BE8: BFA0FE3B <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_oILi1EEEvPKhlPKDF16_PKiPfS5_S5_PDF16_PjNS0_5I4rSdEiS7_+0x1d8>
	s_or_b32 exec_lo, exec_lo, s38                             // 000000DC2BEC: 8C7E267E
	s_bfe_i32 s38, s39, 0x1001c                                // 000000DC2BF0: 93A6FF27 0001001C
	s_lshl_b32 s6, s35, 3                                      // 000000DC2BF8: 84068323
	s_lshr_b64 s[4:5], s[38:39], 29                            // 000000DC2BFC: 85849D26
	s_lshr_b32 s5, s33, 28                                     // 000000DC2C00: 85059C21
	s_add_i32 s3, s4, 7                                        // 000000DC2C04: 81038704
	s_add_i32 s5, s30, s5                                      // 000000DC2C08: 8105051E
	s_ashr_i32 s3, s3, 3                                       // 000000DC2C0C: 86038303
	s_lshl_b32 s4, s39, 3                                      // 000000DC2C10: 84048327
	.long 0xd72c0001                                           // 000000DC2C14: D72C0001
	v_cndmask_b32_e32 v1, s3, v8, vcc_lo                       // 000000DC2C18: 02021003
	v_lshlrev_b32_e32 v7, 2, v9                                // 000000DC2C1C: 300E1282
	s_waitcnt lgkmcnt(0)                                       // 000000DC2C20: BF89FC07
	s_barrier                                                  // 000000DC2C24: BFBD0000
	buffer_gl0_inv                                             // 000000DC2C28: E0AC0000 00000000
	v_add_nc_u32_e32 v2, s3, v1                                // 000000DC2C30: 4A040203
	s_ashr_i32 s3, s5, 4                                       // 000000DC2C34: 86038405
	s_ashr_i32 s5, s6, 31                                      // 000000DC2C38: 86059F06
	s_mul_hi_i32 s7, s34, s3                                   // 000000DC2C3C: 97070322
	s_mul_i32 s3, s34, s3                                      // 000000DC2C40: 96030322
	v_min_i32_e32 v10, s4, v2                                  // 000000DC2C44: 22140404
	s_add_u32 s4, s3, s6                                       // 000000DC2C48: 80040603
	s_addc_u32 s5, s7, s5                                      // 000000DC2C4C: 82050507
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DC2C50: BF870099
	s_lshl_b64 s[4:5], s[4:5], 10                              // 000000DC2C54: 84848A04
	v_cmp_lt_i32_e32 vcc_lo, v1, v10                           // 000000DC2C58: 7C821501
	s_add_u32 s4, s14, s4                                      // 000000DC2C5C: 8004040E
	s_addc_u32 s5, s15, s5                                     // 000000DC2C60: 8205050F
	s_and_saveexec_b32 s6, vcc_lo                              // 000000DC2C64: BE86206A
	s_cbranch_execz 93                                         // 000000DC2C68: BFA5005D <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_oILi1EEEvPKhlPKDF16_PKiPfS5_S5_PDF16_PjNS0_5I4rSdEiS7_+0xae0>
	.long 0xd7010302                                           // 000000DC2C6C: D7010302
	v_cndmask_b32_e32 v0, v9, v129, vcc_lo                     // 000000DC2C70: 02010309
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000DC2C74: BF870121
	v_cndmask_b32_e64 v3, v2, 31, s3                           // 000000DC2C78: D5010003 000D3F02
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000DC2C80: 3404029F
	.long 0xd44c0003                                           // 000000DC2C84: D44C0003
	v_cndmask_b32_e32 v1, 31, v3, vcc_lo                       // 000000DC2C88: 0202069F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DC2C8C: BF870091
	v_cndmask_b32_e64 v5, 0xe1, 1, s3                          // 000000DC2C90: D5010005 000D02FF 000000E1
	v_dual_mov_b32 v4, 0 :: v_dual_add_nc_u32 v11, v5, v3      // 000000DC2C9C: CA200080 040A0705
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DC2CA4: BF870114
	.long 0xd73c0005                                           // 000000DC2CA8: D73C0005
	v_cndmask_b32_e32 v1, 10, v1, vcc_lo                       // 000000DC2CAC: 0202028A
	.long 0xd73c0002                                           // 000000DC2CB0: D73C0002
	v_cndmask_b32_e32 v1, 2, v3, vcc_lo                        // 000000DC2CB4: 02020682
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000DC2CB8: BF870223
	v_lshlrev_b32_e32 v4, 24, v11                              // 000000DC2CBC: 30081698
	v_bfe_i32 v12, v11, 7, 1                                   // 000000DC2CC0: D611000C 02050F0B
	.long 0xd700030d                                           // 000000DC2CC8: D700030D
	v_cndmask_b32_e32 v1, s4, v5, vcc_lo                       // 000000DC2CCC: 02020A04
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DC2CD0: BF870211
	v_add_co_ci_u32_e64 v6, null, s5, v6, s3                   // 000000DC2CD4: D5207C06 000E0C05
	v_ashrrev_i32_e32 v11, 22, v4                              // 000000DC2CDC: 34160896
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DC2CE0: BF870093
	.long 0xd7000304                                           // 000000DC2CE4: D7000304
	v_cndmask_b32_e32 v1, v13, v2, vcc_lo                      // 000000DC2CE8: 0202050D
	v_add_co_ci_u32_e64 v5, null, v6, v3, s3                   // 000000DC2CEC: D5207C05 000E0706
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DC2CF4: BF870093
	.long 0xd700030b                                           // 000000DC2CF8: D700030B
	v_cndmask_b32_e32 v1, v13, v11, vcc_lo                     // 000000DC2CFC: 0202170D
	v_add_co_ci_u32_e64 v12, null, v6, v12, s3                 // 000000DC2D00: D5207C0C 000E1906
	.long 0xd700030d                                           // 000000DC2D08: D700030D
	v_cndmask_b32_e32 v1, v13, v7, vcc_lo                      // 000000DC2D0C: 02020F0D
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DC2D10: BF870001
	v_add_co_ci_u32_e64 v14, null, 0, v6, s3                   // 000000DC2D14: D5207C0E 000E0C80
	s_clause 0x17                                              // 000000DC2D1C: BF850017
	global_load_b32 v2, v[4:5], off                            // 000000DC2D20: DC520000 027C0004
	global_load_b32 v56, v[4:5], off offset:128                // 000000DC2D28: DC520080 387C0004
	global_load_b32 v53, v[4:5], off offset:256                // 000000DC2D30: DC520100 357C0004
	global_load_b32 v50, v[4:5], off offset:384                // 000000DC2D38: DC520180 327C0004
	global_load_b32 v47, v[4:5], off offset:512                // 000000DC2D40: DC520200 2F7C0004
	global_load_b32 v44, v[4:5], off offset:640                // 000000DC2D48: DC520280 2C7C0004
	global_load_b32 v26, v[4:5], off offset:768                // 000000DC2D50: DC520300 1A7C0004
	global_load_b32 v20, v[4:5], off offset:896                // 000000DC2D58: DC520380 147C0004
	global_load_b32 v4, v[11:12], off                          // 000000DC2D60: DC520000 047C000B
	global_load_b32 v57, v[11:12], off offset:128              // 000000DC2D68: DC520080 397C000B
	global_load_b32 v54, v[11:12], off offset:256              // 000000DC2D70: DC520100 367C000B
	global_load_b32 v51, v[11:12], off offset:384              // 000000DC2D78: DC520180 337C000B
	global_load_b32 v48, v[11:12], off offset:512              // 000000DC2D80: DC520200 307C000B
	global_load_b32 v45, v[11:12], off offset:640              // 000000DC2D88: DC520280 2D7C000B
	global_load_b32 v27, v[11:12], off offset:768              // 000000DC2D90: DC520300 1B7C000B
	global_load_b32 v21, v[11:12], off offset:896              // 000000DC2D98: DC520380 157C000B
	global_load_b32 v3, v[13:14], off                          // 000000DC2DA0: DC520000 037C000D
	global_load_b32 v55, v[13:14], off offset:128              // 000000DC2DA8: DC520080 377C000D
	global_load_b32 v52, v[13:14], off offset:256              // 000000DC2DB0: DC520100 347C000D
	global_load_b32 v49, v[13:14], off offset:384              // 000000DC2DB8: DC520180 317C000D
	global_load_b32 v46, v[13:14], off offset:512              // 000000DC2DC0: DC520200 2E7C000D
	global_load_b32 v43, v[13:14], off offset:640              // 000000DC2DC8: DC520280 2B7C000D
	global_load_b32 v25, v[13:14], off offset:768              // 000000DC2DD0: DC520300 197C000D
	global_load_b32 v19, v[13:14], off offset:896              // 000000DC2DD8: DC520380 137C000D
	s_or_b32 exec_lo, exec_lo, s6                              // 000000DC2DE0: 8C7E067E
	v_dual_mov_b32 v11, 0 :: v_dual_mov_b32 v12, 0             // 000000DC2DE4: CA100080 0B0C0080
	v_dual_mov_b32 v13, 0 :: v_dual_mov_b32 v14, 0             // 000000DC2DEC: CA100080 0D0E0080
	v_dual_mov_b32 v15, 0 :: v_dual_mov_b32 v16, 0             // 000000DC2DF4: CA100080 0F100080
	v_dual_mov_b32 v17, 0 :: v_dual_mov_b32 v18, 0             // 000000DC2DFC: CA100080 11120080
	s_ashr_i32 s35, s34, 31                                    // 000000DC2E04: 86239F22
	s_and_saveexec_b32 s3, vcc_lo                              // 000000DC2E08: BE83206A
	s_cbranch_execz 936                                        // 000000DC2E0C: BFA503A8 <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_oILi1EEEvPKhlPKDF16_PKiPfS5_S5_PDF16_PjNS0_5I4rSdEiS7_+0x19b0>
	v_dual_mov_b32 v12, 0 :: v_dual_add_nc_u32 v5, -1, v0      // 000000DC2E10: CA200080 0C0400C1
	v_dual_mov_b32 v11, 0 :: v_dual_and_b32 v22, 16, v0        // 000000DC2E18: CA240080 0B160090
	v_dual_mov_b32 v14, 0 :: v_dual_lshlrev_b32 v23, 2, v9     // 000000DC2E20: CA220080 0E161282
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000DC2E28: BF8701B3
	v_dual_mov_b32 v16, 0 :: v_dual_and_b32 v5, 31, v5         // 000000DC2E2C: CA240080 10040A9F
	v_mov_b32_e32 v13, 0                                       // 000000DC2E34: 7E1A0280
	v_dual_mov_b32 v15, 0 :: v_dual_mov_b32 v18, 0             // 000000DC2E38: CA100080 0F120080
	v_dual_mov_b32 v17, 0 :: v_dual_lshlrev_b32 v24, 2, v5     // 000000DC2E40: CA220080 11180A82
	s_mov_b32 s6, 0                                            // 000000DC2E48: BE860080
	s_movk_i32 s7, 0x1eee                                      // 000000DC2E4C: B0071EEE
	s_branch 860                                               // 000000DC2E50: BFA0035C <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_oILi1EEEvPKhlPKDF16_PKiPfS5_S5_PDF16_PjNS0_5I4rSdEiS7_+0x18c4>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000DC2E54: 8C7E087E
	s_waitcnt vmcnt(15)                                        // 000000DC2E58: BF893FF7
	v_alignbit_b32 v58, v2, v4, 16                             // 000000DC2E5C: D616003A 02420902
	s_waitcnt vmcnt(7)                                         // 000000DC2E64: BF891FF7
	v_bfe_u32 v59, v3, 12, 16                                  // 000000DC2E68: D610003B 02411903
	v_bfe_u32 v60, v3, 8, 16                                   // 000000DC2E70: D610003C 02411103
	v_lshl_or_b32 v1, v1, 5, v22                               // 000000DC2E78: D6560001 04590B01
	v_bfe_u32 v61, v3, 4, 16                                   // 000000DC2E80: D610003D 02410903
	v_bfe_u32 v62, v58, 12, 16                                 // 000000DC2E88: D610003E 0241193A
	v_bfe_u32 v65, v58, 8, 16                                  // 000000DC2E90: D6100041 0241113A
	.long 0xd72c003b                                           // 000000DC2E98: D72C003B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 000000DC2E9C: 020276FF 83DCD12D
	.long 0xd72c003c                                           // 000000DC2EA4: D72C003C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v60, vcc_lo              // 000000DC2EA8: 020278FF 83DCD12D
	.long 0xd72c003d                                           // 000000DC2EB0: D72C003D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v61, vcc_lo              // 000000DC2EB4: 02027AFF 83DCD12D
	.long 0xd72c003e                                           // 000000DC2EBC: D72C003E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v62, vcc_lo              // 000000DC2EC0: 02027CFF 83DCD12D
	.long 0xd72c0041                                           // 000000DC2EC8: D72C0041
	v_cndmask_b32_e32 v1, 0x83dcd12d, v65, vcc_lo              // 000000DC2ECC: 020282FF 83DCD12D
	v_alignbit_b32 v56, v56, v57, 16                           // 000000DC2ED4: D6160038 02427338
	v_alignbit_b32 v53, v53, v54, 16                           // 000000DC2EDC: D6160035 02426D35
	v_alignbit_b32 v50, v50, v51, 16                           // 000000DC2EE4: D6160032 02426732
	v_sad_u8 v59, v59, 0, 0x6400                               // 000000DC2EEC: D622003B 03FD013B 00006400
	v_sad_u8 v60, v60, 0, 0x6400                               // 000000DC2EF8: D622003C 03FD013C 00006400
	v_sad_u8 v61, v61, 0, 0x6400                               // 000000DC2F04: D622003D 03FD013D 00006400
	v_sad_u8 v62, v62, 0, 0x6400                               // 000000DC2F10: D622003E 03FD013E 00006400
	v_sad_u8 v65, v65, 0, 0x6400                               // 000000DC2F1C: D6220041 03FD0141 00006400
	v_and_b32_e32 v59, 0xffff, v59                             // 000000DC2F28: 367676FF 0000FFFF
	v_bfe_u32 v51, v50, 12, 16                                 // 000000DC2F30: D6100033 02411932
	v_alignbit_b32 v47, v47, v48, 16                           // 000000DC2F38: D616002F 0242612F
	v_and_b32_e32 v62, 0xffff, v62                             // 000000DC2F40: 367C7CFF 0000FFFF
	v_alignbit_b32 v44, v44, v45, 16                           // 000000DC2F48: D616002C 02425B2C
	v_lshl_or_b32 v59, v60, 16, v59                            // 000000DC2F50: D656003B 04ED213C
	.long 0xd72c0033                                           // 000000DC2F58: D72C0033
	v_cndmask_b32_e32 v1, 0x83dcd12d, v51, vcc_lo              // 000000DC2F5C: 020266FF 83DCD12D
	v_alignbit_b32 v26, v26, v27, 16                           // 000000DC2F64: D616001A 0242371A
	v_lshl_or_b32 v62, v65, 16, v62                            // 000000DC2F6C: D656003E 04F92141
	s_waitcnt vmcnt(5)                                         // 000000DC2F74: BF8917F7
	v_bfe_u32 v65, v52, 4, 16                                  // 000000DC2F78: D6100041 02410934
	v_pk_fma_f16 v59, v59, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DC2F80: CC0E003B 0BFC0F3B 0000C931
	v_alignbit_b32 v20, v20, v21, 16                           // 000000DC2F8C: D6160014 02422B14
	v_cmp_eq_u32_e32 vcc_lo, v5, v10                           // 000000DC2F94: 7C941505
	v_pk_fma_f16 v60, v62, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DC2F98: CC0E003C 0BFC0F3E 0000C931
	v_and_b32_e32 v63, 0xffff, v3                              // 000000DC2FA4: 367E06FF 0000FFFF
	ds_load_b128 v[1:4], v1                                    // 000000DC2FAC: DBFC0000 01000001
	v_bfe_u32 v62, v55, 12, 16                                 // 000000DC2FB4: D610003E 02411937
	v_sad_u8 v51, v51, 0, 0x6400                               // 000000DC2FBC: D6220033 03FD0133 00006400
	s_or_b32 s6, vcc_lo, s6                                    // 000000DC2FC8: 8C06066A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DC2FCC: BF870112
	.long 0xd72c003e                                           // 000000DC2FD0: D72C003E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v62, vcc_lo              // 000000DC2FD4: 02027CFF 83DCD12D
	v_and_b32_e32 v51, 0xffff, v51                             // 000000DC2FDC: 366666FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DC2FE4: BF870092
	v_sad_u8 v62, v62, 0, 0x6400                               // 000000DC2FE8: D622003E 03FD013E 00006400
	v_and_b32_e32 v62, 0xffff, v62                             // 000000DC2FF4: 367C7CFF 0000FFFF
	s_waitcnt lgkmcnt(0)                                       // 000000DC2FFC: BF89FC07
	v_dot2acc_f32_f16 v18, v60, v1                             // 000000DC3000: 0424033C
	.long 0xd72c003f                                           // 000000DC3004: D72C003F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v63, vcc_lo              // 000000DC3008: 02027EFF 83DCD12D
	v_and_b32_e32 v60, 0xffff, v56                             // 000000DC3010: 367870FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DC3018: BF870191
	.long 0xd72c003c                                           // 000000DC301C: D72C003C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v60, vcc_lo              // 000000DC3020: 020278FF 83DCD12D
	v_sad_u8 v63, v63, 0, 0x6400                               // 000000DC3028: D622003F 03FD013F 00006400
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DC3034: BF870191
	v_lshlrev_b32_e32 v63, 16, v63                             // 000000DC3038: 307E7E90
	v_sad_u8 v60, v60, 0, 0x6400                               // 000000DC303C: D622003C 03FD013C 00006400
	s_delay_alu instid0(VALU_DEP_2)                            // 000000DC3048: BF870002
	v_and_or_b32 v57, 0xffff, v61, v63                         // 000000DC304C: D6570039 04FE7AFF 0000FFFF
	v_bfe_u32 v61, v56, 12, 16                                 // 000000DC3058: D610003D 02411938
	v_bfe_u32 v63, v56, 8, 16                                  // 000000DC3060: D610003F 02411138
	v_bfe_u32 v56, v56, 4, 16                                  // 000000DC3068: D6100038 02410938
	v_lshlrev_b32_e32 v60, 16, v60                             // 000000DC3070: 30787890
	v_pk_fma_f16 v57, v57, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DC3074: CC0E0039 0BFC0F39 0000C931
	.long 0xd72c003d                                           // 000000DC3080: D72C003D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v61, vcc_lo              // 000000DC3084: 02027AFF 83DCD12D
	.long 0xd72c003f                                           // 000000DC308C: D72C003F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v63, vcc_lo              // 000000DC3090: 02027EFF 83DCD12D
	.long 0xd72c0038                                           // 000000DC3098: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v56, vcc_lo              // 000000DC309C: 020270FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DC30A4: BF870193
	v_sad_u8 v61, v61, 0, 0x6400                               // 000000DC30A8: D622003D 03FD013D 00006400
	v_sad_u8 v63, v63, 0, 0x6400                               // 000000DC30B4: D622003F 03FD013F 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DC30C0: BF870193
	v_sad_u8 v56, v56, 0, 0x6400                               // 000000DC30C4: D6220038 03FD0138 00006400
	v_and_b32_e32 v61, 0xffff, v61                             // 000000DC30D0: 367A7AFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DC30D8: BF870112
	v_and_or_b32 v56, 0xffff, v56, v60                         // 000000DC30DC: D6570038 04F270FF 0000FFFF
	v_lshl_or_b32 v61, v63, 16, v61                            // 000000DC30E8: D656003D 04F5213F
	v_bfe_u32 v63, v52, 12, 16                                 // 000000DC30F0: D610003F 02411934
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DC30F8: BF870193
	v_pk_fma_f16 v56, v56, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DC30FC: CC0E0038 0BFC0F38 0000C931
	v_pk_fma_f16 v54, v61, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DC3108: CC0E0036 0BFC0F3D 0000C931
	v_and_b32_e32 v64, 0xffff, v58                             // 000000DC3114: 368074FF 0000FFFF
	v_bfe_u32 v58, v58, 4, 16                                  // 000000DC311C: D610003A 0241093A
	v_and_b32_e32 v61, 0xffff, v53                             // 000000DC3124: 367A6AFF 0000FFFF
	.long 0xd72c003f                                           // 000000DC312C: D72C003F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v63, vcc_lo              // 000000DC3130: 02027EFF 83DCD12D
	v_dot2acc_f32_f16 v17, v54, v1                             // 000000DC3138: 04220336
	.long 0xd72c0040                                           // 000000DC313C: D72C0040
	v_cndmask_b32_e32 v1, 0x83dcd12d, v64, vcc_lo              // 000000DC3140: 020280FF 83DCD12D
	.long 0xd72c003a                                           // 000000DC3148: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 000000DC314C: 020274FF 83DCD12D
	.long 0xd72c0036                                           // 000000DC3154: D72C0036
	v_cndmask_b32_e32 v1, 0x83dcd12d, v65, vcc_lo              // 000000DC3158: 020282FF 83DCD12D
	.long 0xd72c003d                                           // 000000DC3160: D72C003D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v61, vcc_lo              // 000000DC3164: 02027AFF 83DCD12D
	v_dot2acc_f32_f16 v17, v56, v2                             // 000000DC316C: 04220538
	s_waitcnt vmcnt(4)                                         // 000000DC3170: BF8913F7
	v_bfe_u32 v56, v49, 4, 16                                  // 000000DC3174: D6100038 02410931
	v_sad_u8 v63, v63, 0, 0x6400                               // 000000DC317C: D622003F 03FD013F 00006400
	v_sad_u8 v64, v64, 0, 0x6400                               // 000000DC3188: D6220040 03FD0140 00006400
	v_sad_u8 v58, v58, 0, 0x6400                               // 000000DC3194: D622003A 03FD013A 00006400
	v_sad_u8 v54, v54, 0, 0x6400                               // 000000DC31A0: D6220036 03FD0136 00006400
	v_sad_u8 v61, v61, 0, 0x6400                               // 000000DC31AC: D622003D 03FD013D 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DC31B8: BF870114
	v_lshlrev_b32_e32 v64, 16, v64                             // 000000DC31BC: 30808090
	v_lshlrev_b32_e32 v61, 16, v61                             // 000000DC31C0: 307A7A90
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000DC31C4: BF870122
	v_and_or_b32 v58, 0xffff, v58, v64                         // 000000DC31C8: D657003A 050274FF 0000FFFF
	v_bfe_u32 v64, v55, 8, 16                                  // 000000DC31D4: D6100040 02411137
	v_pk_fma_f16 v58, v58, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DC31DC: CC0E003A 0BFC0F3A 0000C931
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DC31E8: BF870191
	v_dot2acc_f32_f16 v18, v58, v2                             // 000000DC31EC: 0424053A
	.long 0xd72c003a                                           // 000000DC31F0: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v64, vcc_lo              // 000000DC31F4: 020280FF 83DCD12D
	v_bfe_u32 v64, v55, 4, 16                                  // 000000DC31FC: D6100040 02410937
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000DC3204: BF8701A3
	v_dot2acc_f32_f16 v18, v59, v3                             // 000000DC3208: 0424073B
	v_bfe_u32 v59, v53, 12, 16                                 // 000000DC320C: D610003B 02411935
	.long 0xd72c003c                                           // 000000DC3214: D72C003C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v64, vcc_lo              // 000000DC3218: 020280FF 83DCD12D
	v_bfe_u32 v64, v52, 8, 16                                  // 000000DC3220: D6100040 02411134
	v_and_b32_e32 v52, 0xffff, v52                             // 000000DC3228: 366868FF 0000FFFF
	v_sad_u8 v58, v58, 0, 0x6400                               // 000000DC3230: D622003A 03FD013A 00006400
	.long 0xd72c003b                                           // 000000DC323C: D72C003B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 000000DC3240: 020276FF 83DCD12D
	v_dot2acc_f32_f16 v18, v57, v4                             // 000000DC3248: 04240939
	.long 0xd72c0040                                           // 000000DC324C: D72C0040
	v_cndmask_b32_e32 v1, 0x83dcd12d, v64, vcc_lo              // 000000DC3250: 020280FF 83DCD12D
	.long 0xd72c0034                                           // 000000DC3258: D72C0034
	v_cndmask_b32_e32 v1, 0x83dcd12d, v52, vcc_lo              // 000000DC325C: 020268FF 83DCD12D
	v_lshl_or_b32 v58, v58, 16, v62                            // 000000DC3264: D656003A 04F9213A
	v_bfe_u32 v62, v53, 8, 16                                  // 000000DC326C: D610003E 02411135
	v_bfe_u32 v53, v53, 4, 16                                  // 000000DC3274: D6100035 02410935
	v_sad_u8 v60, v60, 0, 0x6400                               // 000000DC327C: D622003C 03FD013C 00006400
	v_sad_u8 v59, v59, 0, 0x6400                               // 000000DC3288: D622003B 03FD013B 00006400
	v_pk_fma_f16 v58, v58, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DC3294: CC0E003A 0BFC0F3A 0000C931
	.long 0xd72c003e                                           // 000000DC32A0: D72C003E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v62, vcc_lo              // 000000DC32A4: 02027CFF 83DCD12D
	v_sad_u8 v52, v52, 0, 0x6400                               // 000000DC32AC: D6220034 03FD0134 00006400
	.long 0xd72c0035                                           // 000000DC32B8: D72C0035
	v_cndmask_b32_e32 v1, 0x83dcd12d, v53, vcc_lo              // 000000DC32BC: 02026AFF 83DCD12D
	s_waitcnt vmcnt(3)                                         // 000000DC32C4: BF890FF7
	v_bfe_u32 v57, v46, 8, 16                                  // 000000DC32C8: D6100039 0241112E
	v_dot2acc_f32_f16 v17, v58, v3                             // 000000DC32D0: 0422073A
	v_bfe_u32 v58, v46, 4, 16                                  // 000000DC32D4: D610003A 0241092E
	v_lshlrev_b32_e32 v52, 16, v52                             // 000000DC32DC: 30686890
	v_sad_u8 v62, v62, 0, 0x6400                               // 000000DC32E0: D622003E 03FD013E 00006400
	.long 0xd72c0039                                           // 000000DC32EC: D72C0039
	v_cndmask_b32_e32 v1, 0x83dcd12d, v57, vcc_lo              // 000000DC32F0: 020272FF 83DCD12D
	v_sad_u8 v53, v53, 0, 0x6400                               // 000000DC32F8: D6220035 03FD0135 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DC3304: BF870114
	v_and_or_b32 v52, 0xffff, v54, v52                         // 000000DC3308: D6570034 04D26CFF 0000FFFF
	v_and_or_b32 v53, 0xffff, v53, v61                         // 000000DC3314: D6570035 04F66AFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000DC3320: BF870232
	v_pk_fma_f16 v52, v52, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DC3324: CC0E0034 0BFC0F34 0000C931
	v_and_b32_e32 v59, 0xffff, v59                             // 000000DC3330: 367676FF 0000FFFF
	v_and_b32_e32 v61, 0xffff, v63                             // 000000DC3338: 367A7EFF 0000FFFF
	v_pk_fma_f16 v53, v53, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DC3340: CC0E0035 0BFC0F35 0000C931
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000DC334C: BF870123
	v_lshl_or_b32 v59, v62, 16, v59                            // 000000DC3350: D656003B 04ED213E
	v_sad_u8 v62, v64, 0, 0x6400                               // 000000DC3358: D622003E 03FD0140 00006400
	v_pk_fma_f16 v59, v59, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DC3364: CC0E003B 0BFC0F3B 0000C931
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DC3370: BF870112
	v_lshl_or_b32 v61, v62, 16, v61                            // 000000DC3374: D656003D 04F5213E
	v_dual_dot2acc_f32_f16 v16, v59, v1 :: v_dual_and_b32 v55, 0xffff, v55// 000000DC337C: CB24033B 10366EFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DC3388: BF870112
	v_pk_fma_f16 v54, v61, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DC338C: CC0E0036 0BFC0F3D 0000C931
	v_dot2acc_f32_f16 v16, v53, v2                             // 000000DC3398: 04200535
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DC339C: BF870113
	.long 0xd72c0037                                           // 000000DC33A0: D72C0037
	v_cndmask_b32_e32 v1, 0x83dcd12d, v55, vcc_lo              // 000000DC33A4: 02026EFF 83DCD12D
	v_dot2acc_f32_f16 v16, v54, v3                             // 000000DC33AC: 04200736
	v_bfe_u32 v54, v49, 12, 16                                 // 000000DC33B0: D6100036 02411931
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DC33B8: BF870193
	v_sad_u8 v55, v55, 0, 0x6400                               // 000000DC33BC: D6220037 03FD0137 00006400
	v_dot2acc_f32_f16 v16, v52, v4                             // 000000DC33C8: 04200934
	v_bfe_u32 v52, v50, 8, 16                                  // 000000DC33CC: D6100034 02411132
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DC33D4: BF870214
	.long 0xd72c0036                                           // 000000DC33D8: D72C0036
	v_cndmask_b32_e32 v1, 0x83dcd12d, v54, vcc_lo              // 000000DC33DC: 02026CFF 83DCD12D
	v_lshlrev_b32_e32 v55, 16, v55                             // 000000DC33E4: 306E6E90
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DC33E8: BF870113
	.long 0xd72c0034                                           // 000000DC33EC: D72C0034
	v_cndmask_b32_e32 v1, 0x83dcd12d, v52, vcc_lo              // 000000DC33F0: 020268FF 83DCD12D
	v_and_or_b32 v55, 0xffff, v60, v55                         // 000000DC33F8: D6570037 04DE78FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DC3404: BF870114
	v_sad_u8 v54, v54, 0, 0x6400                               // 000000DC3408: D6220036 03FD0136 00006400
	v_pk_fma_f16 v53, v55, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DC3414: CC0E0035 0BFC0F37 0000C931
	v_bfe_u32 v55, v49, 8, 16                                  // 000000DC3420: D6100037 02411131
	s_delay_alu instid0(VALU_DEP_3)                            // 000000DC3428: BF870003
	v_and_b32_e32 v54, 0xffff, v54                             // 000000DC342C: 366C6CFF 0000FFFF
	v_and_b32_e32 v49, 0xffff, v49                             // 000000DC3434: 366262FF 0000FFFF
	v_sad_u8 v52, v52, 0, 0x6400                               // 000000DC343C: D6220034 03FD0134 00006400
	v_dot2acc_f32_f16 v17, v53, v4                             // 000000DC3448: 04220935
	v_and_b32_e32 v53, 0xffff, v50                             // 000000DC344C: 366A64FF 0000FFFF
	v_bfe_u32 v50, v50, 4, 16                                  // 000000DC3454: D6100032 02410932
	.long 0xd72c0037                                           // 000000DC345C: D72C0037
	v_cndmask_b32_e32 v1, 0x83dcd12d, v55, vcc_lo              // 000000DC3460: 02026EFF 83DCD12D
	.long 0xd72c0031                                           // 000000DC3468: D72C0031
	v_cndmask_b32_e32 v1, 0x83dcd12d, v49, vcc_lo              // 000000DC346C: 020262FF 83DCD12D
	v_lshl_or_b32 v51, v52, 16, v51                            // 000000DC3474: D6560033 04CD2134
	.long 0xd72c0035                                           // 000000DC347C: D72C0035
	v_cndmask_b32_e32 v1, 0x83dcd12d, v53, vcc_lo              // 000000DC3480: 02026AFF 83DCD12D
	.long 0xd72c0032                                           // 000000DC3488: D72C0032
	v_cndmask_b32_e32 v1, 0x83dcd12d, v50, vcc_lo              // 000000DC348C: 020264FF 83DCD12D
	.long 0xd72c0034                                           // 000000DC3494: D72C0034
	v_cndmask_b32_e32 v1, 0x83dcd12d, v56, vcc_lo              // 000000DC3498: 020270FF 83DCD12D
	v_bfe_u32 v56, v46, 12, 16                                 // 000000DC34A0: D6100038 0241192E
	v_pk_fma_f16 v51, v51, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DC34A8: CC0E0033 0BFC0F33 0000C931
	v_sad_u8 v55, v55, 0, 0x6400                               // 000000DC34B4: D6220037 03FD0137 00006400
	v_sad_u8 v49, v49, 0, 0x6400                               // 000000DC34C0: D6220031 03FD0131 00006400
	v_sad_u8 v53, v53, 0, 0x6400                               // 000000DC34CC: D6220035 03FD0135 00006400
	v_sad_u8 v50, v50, 0, 0x6400                               // 000000DC34D8: D6220032 03FD0132 00006400
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DC34E4: BF870004
	v_lshl_or_b32 v48, v55, 16, v54                            // 000000DC34E8: D6560030 04D92137
	v_and_b32_e32 v54, 0xffff, v47                             // 000000DC34F0: 366C5EFF 0000FFFF
	v_bfe_u32 v55, v47, 8, 16                                  // 000000DC34F8: D6100037 0241112F
	v_lshlrev_b32_e32 v53, 16, v53                             // 000000DC3500: 306A6A90
	.long 0xd72c0038                                           // 000000DC3504: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v56, vcc_lo              // 000000DC3508: 020270FF 83DCD12D
	v_sad_u8 v52, v52, 0, 0x6400                               // 000000DC3510: D6220034 03FD0134 00006400
	.long 0xd72c0036                                           // 000000DC351C: D72C0036
	v_cndmask_b32_e32 v1, 0x83dcd12d, v54, vcc_lo              // 000000DC3520: 02026CFF 83DCD12D
	.long 0xd72c0037                                           // 000000DC3528: D72C0037
	v_cndmask_b32_e32 v1, 0x83dcd12d, v55, vcc_lo              // 000000DC352C: 02026EFF 83DCD12D
	v_and_or_b32 v50, 0xffff, v50, v53                         // 000000DC3534: D6570032 04D664FF 0000FFFF
	v_bfe_u32 v53, v47, 12, 16                                 // 000000DC3540: D6100035 0241192F
	v_bfe_u32 v47, v47, 4, 16                                  // 000000DC3548: D610002F 0241092F
	v_lshlrev_b32_e32 v49, 16, v49                             // 000000DC3550: 30626290
	v_sad_u8 v56, v56, 0, 0x6400                               // 000000DC3554: D6220038 03FD0138 00006400
	v_pk_fma_f16 v50, v50, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DC3560: CC0E0032 0BFC0F32 0000C931
	.long 0xd72c0035                                           // 000000DC356C: D72C0035
	v_cndmask_b32_e32 v1, 0x83dcd12d, v53, vcc_lo              // 000000DC3570: 02026AFF 83DCD12D
	.long 0xd72c002f                                           // 000000DC3578: D72C002F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v47, vcc_lo              // 000000DC357C: 02025EFF 83DCD12D
	v_sad_u8 v54, v54, 0, 0x6400                               // 000000DC3584: D6220036 03FD0136 00006400
	v_sad_u8 v55, v55, 0, 0x6400                               // 000000DC3590: D6220037 03FD0137 00006400
	v_and_or_b32 v49, 0xffff, v52, v49                         // 000000DC359C: D6570031 04C668FF 0000FFFF
	v_dot2acc_f32_f16 v15, v51, v1                             // 000000DC35A8: 041E0333
	v_pk_fma_f16 v48, v48, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DC35AC: CC0E0030 0BFC0F30 0000C931
	v_lshlrev_b32_e32 v54, 16, v54                             // 000000DC35B8: 306C6C90
	v_sad_u8 v53, v53, 0, 0x6400                               // 000000DC35BC: D6220035 03FD0135 00006400
	v_sad_u8 v47, v47, 0, 0x6400                               // 000000DC35C8: D622002F 03FD012F 00006400
	v_dot2acc_f32_f16 v15, v50, v2                             // 000000DC35D4: 041E0532
	s_waitcnt vmcnt(2)                                         // 000000DC35D8: BF890BF7
	v_bfe_u32 v50, v43, 12, 16                                 // 000000DC35DC: D6100032 0241192B
	v_and_b32_e32 v53, 0xffff, v53                             // 000000DC35E4: 366A6AFF 0000FFFF
	v_and_or_b32 v47, 0xffff, v47, v54                         // 000000DC35EC: D657002F 04DA5EFF 0000FFFF
	v_dual_dot2acc_f32_f16 v15, v48, v3 :: v_dual_and_b32 v54, 0xffff, v56// 000000DC35F8: CB240730 0F3670FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DC3604: BF870214
	.long 0xd72c0032                                           // 000000DC3608: D72C0032
	v_cndmask_b32_e32 v1, 0x83dcd12d, v50, vcc_lo              // 000000DC360C: 020264FF 83DCD12D
	v_lshl_or_b32 v52, v55, 16, v53                            // 000000DC3614: D6560034 04D52137
	v_sad_u8 v55, v57, 0, 0x6400                               // 000000DC361C: D6220037 03FD0139 00006400
	v_pk_fma_f16 v47, v47, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DC3628: CC0E002F 0BFC0F2F 0000C931
	.long 0xd72c0035                                           // 000000DC3634: D72C0035
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 000000DC3638: 020274FF 83DCD12D
	v_mov_b32_e32 v57, v41                                     // 000000DC3640: 7E720329
	v_pk_fma_f16 v51, v52, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DC3644: CC0E0033 0BFC0F34 0000C931
	v_lshl_or_b32 v52, v55, 16, v54                            // 000000DC3650: D6560034 04D92137
	v_sad_u8 v50, v50, 0, 0x6400                               // 000000DC3658: D6220032 03FD0132 00006400
	v_dual_mov_b32 v55, v41 :: v_dual_mov_b32 v56, v35         // 000000DC3664: CA100129 37380123
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DC366C: BF870214
	v_dot2acc_f32_f16 v14, v51, v1                             // 000000DC3670: 041C0333
	v_pk_fma_f16 v45, v52, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DC3674: CC0E002D 0BFC0F34 0000C931
	v_bfe_u32 v51, v43, 8, 16                                  // 000000DC3680: D6100033 0241112B
	v_bfe_u32 v52, v43, 4, 16                                  // 000000DC3688: D6100034 0241092B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000DC3690: BF870234
	v_dual_dot2acc_f32_f16 v14, v47, v2 :: v_dual_and_b32 v43, 0xffff, v43// 000000DC3694: CB24052F 0E2A56FF 0000FFFF
	v_pk_fma_f16 v47, v49, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DC36A0: CC0E002F 0BFC0F31 0000C931
	v_bfe_u32 v49, v44, 12, 16                                 // 000000DC36AC: D6100031 0241192C
	.long 0xd72c0034                                           // 000000DC36B4: D72C0034
	v_cndmask_b32_e32 v1, 0x83dcd12d, v52, vcc_lo              // 000000DC36B8: 020268FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DC36C0: BF870004
	.long 0xd72c002b                                           // 000000DC36C4: D72C002B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v43, vcc_lo              // 000000DC36C8: 020256FF 83DCD12D
	v_dot2acc_f32_f16 v14, v45, v3                             // 000000DC36D0: 041C072D
	v_bfe_u32 v45, v44, 8, 16                                  // 000000DC36D4: D610002D 0241112C
	.long 0xd72c0030                                           // 000000DC36DC: D72C0030
	v_cndmask_b32_e32 v1, 0x83dcd12d, v49, vcc_lo              // 000000DC36E0: 020262FF 83DCD12D
	v_and_b32_e32 v49, 0xffff, v44                             // 000000DC36E8: 366258FF 0000FFFF
	v_bfe_u32 v44, v44, 4, 16                                  // 000000DC36F0: D610002C 0241092C
	.long 0xd72c0033                                           // 000000DC36F8: D72C0033
	v_cndmask_b32_e32 v1, 0x83dcd12d, v51, vcc_lo              // 000000DC36FC: 020266FF 83DCD12D
	v_sad_u8 v52, v52, 0, 0x6400                               // 000000DC3704: D6220034 03FD0134 00006400
	v_sad_u8 v43, v43, 0, 0x6400                               // 000000DC3710: D622002B 03FD012B 00006400
	.long 0xd72c0031                                           // 000000DC371C: D72C0031
	v_cndmask_b32_e32 v1, 0x83dcd12d, v49, vcc_lo              // 000000DC3720: 020262FF 83DCD12D
	.long 0xd72c002d                                           // 000000DC3728: D72C002D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v45, vcc_lo              // 000000DC372C: 02025AFF 83DCD12D
	v_sad_u8 v48, v48, 0, 0x6400                               // 000000DC3734: D6220030 03FD0130 00006400
	.long 0xd72c002c                                           // 000000DC3740: D72C002C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v44, vcc_lo              // 000000DC3744: 020258FF 83DCD12D
	v_lshlrev_b32_e32 v43, 16, v43                             // 000000DC374C: 30565690
	v_sad_u8 v51, v51, 0, 0x6400                               // 000000DC3750: D6220033 03FD0133 00006400
	v_sad_u8 v53, v53, 0, 0x6400                               // 000000DC375C: D6220035 03FD0135 00006400
	v_and_b32_e32 v48, 0xffff, v48                             // 000000DC3768: 366060FF 0000FFFF
	v_sad_u8 v49, v49, 0, 0x6400                               // 000000DC3770: D6220031 03FD0131 00006400
	v_and_or_b32 v43, 0xffff, v52, v43                         // 000000DC377C: D657002B 04AE68FF 0000FFFF
	v_sad_u8 v45, v45, 0, 0x6400                               // 000000DC3788: D622002D 03FD012D 00006400
	v_sad_u8 v44, v44, 0, 0x6400                               // 000000DC3794: D622002C 03FD012C 00006400
	s_waitcnt vmcnt(1)                                         // 000000DC37A0: BF8907F7
	v_bfe_u32 v52, v25, 8, 16                                  // 000000DC37A4: D6100034 02411119
	v_lshlrev_b32_e32 v49, 16, v49                             // 000000DC37AC: 30626290
	v_pk_fma_f16 v43, v43, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DC37B0: CC0E002B 0BFC0F2B 0000C931
	v_and_b32_e32 v50, 0xffff, v50                             // 000000DC37BC: 366464FF 0000FFFF
	v_lshl_or_b32 v45, v45, 16, v48                            // 000000DC37C4: D656002D 04C1212D
	v_bfe_u32 v48, v26, 12, 16                                 // 000000DC37CC: D6100030 0241191A
	v_and_or_b32 v44, 0xffff, v44, v49                         // 000000DC37D4: D657002C 04C658FF 0000FFFF
	v_and_b32_e32 v49, 0xffff, v26                             // 000000DC37E0: 366234FF 0000FFFF
	v_lshl_or_b32 v27, v51, 16, v50                            // 000000DC37E8: D656001B 04C92133
	v_bfe_u32 v50, v25, 12, 16                                 // 000000DC37F0: D6100032 02411919
	v_pk_fma_f16 v45, v45, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DC37F8: CC0E002D 0BFC0F2D 0000C931
	.long 0xd72c0030                                           // 000000DC3804: D72C0030
	v_cndmask_b32_e32 v1, 0x83dcd12d, v48, vcc_lo              // 000000DC3808: 020260FF 83DCD12D
	v_bfe_u32 v51, v26, 8, 16                                  // 000000DC3810: D6100033 0241111A
	v_bfe_u32 v26, v26, 4, 16                                  // 000000DC3818: D610001A 0241091A
	.long 0xd72c0032                                           // 000000DC3820: D72C0032
	v_cndmask_b32_e32 v1, 0x83dcd12d, v50, vcc_lo              // 000000DC3824: 020264FF 83DCD12D
	.long 0xd72c0031                                           // 000000DC382C: D72C0031
	v_cndmask_b32_e32 v1, 0x83dcd12d, v49, vcc_lo              // 000000DC3830: 020262FF 83DCD12D
	v_dot2acc_f32_f16 v13, v45, v1                             // 000000DC3838: 041A032D
	.long 0xd72c0033                                           // 000000DC383C: D72C0033
	v_cndmask_b32_e32 v1, 0x83dcd12d, v51, vcc_lo              // 000000DC3840: 020266FF 83DCD12D
	.long 0xd72c002d                                           // 000000DC3848: D72C002D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v52, vcc_lo              // 000000DC384C: 020268FF 83DCD12D
	v_pk_fma_f16 v44, v44, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DC3854: CC0E002C 0BFC0F2C 0000C931
	v_sad_u8 v48, v48, 0, 0x6400                               // 000000DC3860: D6220030 03FD0130 00006400
	.long 0xd72c001a                                           // 000000DC386C: D72C001A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v26, vcc_lo              // 000000DC3870: 020234FF 83DCD12D
	v_sad_u8 v50, v50, 0, 0x6400                               // 000000DC3878: D6220032 03FD0132 00006400
	v_sad_u8 v49, v49, 0, 0x6400                               // 000000DC3884: D6220031 03FD0131 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000DC3890: BF870224
	v_dual_dot2acc_f32_f16 v13, v44, v2 :: v_dual_and_b32 v48, 0xffff, v48// 000000DC3894: CB24052C 0D3060FF 0000FFFF
	v_sad_u8 v51, v51, 0, 0x6400                               // 000000DC38A0: D6220033 03FD0133 00006400
	v_and_b32_e32 v50, 0xffff, v50                             // 000000DC38AC: 366464FF 0000FFFF
	v_sad_u8 v45, v45, 0, 0x6400                               // 000000DC38B4: D622002D 03FD012D 00006400
	v_bfe_u32 v44, v20, 12, 16                                 // 000000DC38C0: D610002C 02411914
	v_sad_u8 v26, v26, 0, 0x6400                               // 000000DC38C8: D622001A 03FD011A 00006400
	v_lshlrev_b32_e32 v49, 16, v49                             // 000000DC38D4: 30626290
	v_bfe_u32 v52, v25, 4, 16                                  // 000000DC38D8: D6100034 02410919
	v_lshl_or_b32 v48, v51, 16, v48                            // 000000DC38E0: D6560030 04C12133
	v_lshl_or_b32 v45, v45, 16, v50                            // 000000DC38E8: D656002D 04C9212D
	.long 0xd72c002c                                           // 000000DC38F0: D72C002C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v44, vcc_lo              // 000000DC38F4: 020258FF 83DCD12D
	v_bfe_u32 v50, v20, 8, 16                                  // 000000DC38FC: D6100032 02411114
	s_waitcnt vmcnt(0)                                         // 000000DC3904: BF8903F7
	v_bfe_u32 v51, v19, 12, 16                                 // 000000DC3908: D6100033 02411913
	v_and_or_b32 v26, 0xffff, v26, v49                         // 000000DC3910: D657001A 04C634FF 0000FFFF
	.long 0xd72c0031                                           // 000000DC391C: D72C0031
	v_cndmask_b32_e32 v1, 0x83dcd12d, v52, vcc_lo              // 000000DC3920: 020268FF 83DCD12D
	v_bfe_u32 v52, v19, 8, 16                                  // 000000DC3928: D6100034 02411113
	.long 0xd72c0032                                           // 000000DC3930: D72C0032
	v_cndmask_b32_e32 v1, 0x83dcd12d, v50, vcc_lo              // 000000DC3934: 020264FF 83DCD12D
	.long 0xd72c0033                                           // 000000DC393C: D72C0033
	v_cndmask_b32_e32 v1, 0x83dcd12d, v51, vcc_lo              // 000000DC3940: 020266FF 83DCD12D
	v_pk_fma_f16 v27, v27, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DC3948: CC0E001B 0BFC0F1B 0000C931
	v_and_b32_e32 v46, 0xffff, v46                             // 000000DC3954: 365C5CFF 0000FFFF
	v_sad_u8 v44, v44, 0, 0x6400                               // 000000DC395C: D622002C 03FD012C 00006400
	.long 0xd72c0034                                           // 000000DC3968: D72C0034
	v_cndmask_b32_e32 v1, 0x83dcd12d, v52, vcc_lo              // 000000DC396C: 020268FF 83DCD12D
	v_and_b32_e32 v25, 0xffff, v25                             // 000000DC3974: 363232FF 0000FFFF
	v_dot2acc_f32_f16 v13, v27, v3                             // 000000DC397C: 041A071B
	.long 0xd72c002e                                           // 000000DC3980: D72C002E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v46, vcc_lo              // 000000DC3984: 02025CFF 83DCD12D
	v_and_b32_e32 v44, 0xffff, v44                             // 000000DC398C: 365858FF 0000FFFF
	v_sad_u8 v50, v50, 0, 0x6400                               // 000000DC3994: D6220032 03FD0132 00006400
	v_sad_u8 v51, v51, 0, 0x6400                               // 000000DC39A0: D6220033 03FD0133 00006400
	v_dual_mov_b32 v54, v40 :: v_dual_dot2acc_f32_f16 v15, v47, v4// 000000DC39AC: CA180128 360E092F
	v_pk_fma_f16 v26, v26, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DC39B4: CC0E001A 0BFC0F1A 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DC39C0: BF870214
	v_lshl_or_b32 v44, v50, 16, v44                            // 000000DC39C4: D656002C 04B12132
	v_dual_mov_b32 v27, v36 :: v_dual_and_b32 v50, 0xffff, v51 // 000000DC39CC: CA240124 1B3266FF 0000FFFF
	v_sad_u8 v51, v52, 0, 0x6400                               // 000000DC39D8: D6220033 03FD0134 00006400
	v_mov_b32_e32 v52, v40                                     // 000000DC39E4: 7E680328
	.long 0xd72c0015                                           // 000000DC39E8: D72C0015
	v_cndmask_b32_e32 v1, 0x83dcd12d, v25, vcc_lo              // 000000DC39EC: 020232FF 83DCD12D
	v_pk_fma_f16 v25, v48, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DC39F4: CC0E0019 0BFC0F30 0000C931
	v_sad_u8 v48, v49, 0, 0x6400                               // 000000DC3A00: D6220030 03FD0131 00006400
	v_and_b32_e32 v49, 0xffff, v20                             // 000000DC3A0C: 366228FF 0000FFFF
	v_sad_u8 v46, v46, 0, 0x6400                               // 000000DC3A14: D622002E 03FD012E 00006400
	v_bfe_u32 v20, v20, 4, 16                                  // 000000DC3A20: D6100014 02410914
	v_dot2acc_f32_f16 v12, v25, v1                             // 000000DC3A28: 04180319
	v_pk_fma_f16 v25, v44, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DC3A2C: CC0E0019 0BFC0F2C 0000C931
	.long 0xd72c0031                                           // 000000DC3A38: D72C0031
	v_cndmask_b32_e32 v1, 0x83dcd12d, v49, vcc_lo              // 000000DC3A3C: 020262FF 83DCD12D
	v_lshlrev_b32_e32 v46, 16, v46                             // 000000DC3A44: 305C5C90
	.long 0xd72c0014                                           // 000000DC3A48: D72C0014
	v_cndmask_b32_e32 v1, 0x83dcd12d, v20, vcc_lo              // 000000DC3A4C: 020228FF 83DCD12D
	v_sad_u8 v21, v21, 0, 0x6400                               // 000000DC3A54: D6220015 03FD0115 00006400
	v_lshl_or_b32 v44, v51, 16, v50                            // 000000DC3A60: D656002C 04C92133
	v_dot2acc_f32_f16 v11, v25, v1                             // 000000DC3A68: 04160319
	v_and_or_b32 v46, 0xffff, v53, v46                         // 000000DC3A6C: D657002E 04BA6AFF 0000FFFF
	v_bfe_u32 v53, v19, 4, 16                                  // 000000DC3A78: D6100035 02410913
	v_sad_u8 v49, v49, 0, 0x6400                               // 000000DC3A80: D6220031 03FD0131 00006400
	v_and_b32_e32 v19, 0xffff, v19                             // 000000DC3A8C: 362626FF 0000FFFF
	v_sad_u8 v20, v20, 0, 0x6400                               // 000000DC3A94: D6220014 03FD0114 00006400
	v_lshlrev_b32_e32 v21, 16, v21                             // 000000DC3AA0: 302A2A90
	v_pk_fma_f16 v45, v45, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DC3AA4: CC0E002D 0BFC0F2D 0000C931
	v_lshlrev_b32_e32 v49, 16, v49                             // 000000DC3AB0: 30626290
	.long 0xd72c0013                                           // 000000DC3AB4: D72C0013
	v_cndmask_b32_e32 v1, 0x83dcd12d, v19, vcc_lo              // 000000DC3AB8: 020226FF 83DCD12D
	v_dot2acc_f32_f16 v12, v26, v2                             // 000000DC3AC0: 0418051A
	v_and_or_b32 v1, 0xffff, v48, v21                          // 000000DC3AC4: D6570001 045660FF 0000FFFF
	v_pk_fma_f16 v21, v44, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DC3AD0: CC0E0015 0BFC0F2C 0000C931
	v_and_or_b32 v20, 0xffff, v20, v49                         // 000000DC3ADC: D6570014 04C628FF 0000FFFF
	.long 0xd72c0031                                           // 000000DC3AE8: D72C0031
	v_cndmask_b32_e32 v1, 0x83dcd12d, v53, vcc_lo              // 000000DC3AEC: 02026AFF 83DCD12D
	v_pk_fma_f16 v46, v46, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DC3AF4: CC0E002E 0BFC0F2E 0000C931
	v_pk_fma_f16 v1, v1, s7, 0xc931 op_sel_hi:[1,0,0]          // 000000DC3B00: CC0E0001 0BFC0F01 0000C931
	v_sad_u8 v19, v19, 0, 0x6400                               // 000000DC3B0C: D6220013 03FD0113 00006400
	v_pk_fma_f16 v20, v20, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DC3B18: CC0E0014 0BFC0F14 0000C931
	v_dot2acc_f32_f16 v12, v45, v3                             // 000000DC3B24: 0418072D
	v_dot2acc_f32_f16 v14, v46, v4                             // 000000DC3B28: 041C092E
	v_dot2acc_f32_f16 v13, v43, v4                             // 000000DC3B2C: 041A092B
	v_sad_u8 v49, v49, 0, 0x6400                               // 000000DC3B30: D6220031 03FD0131 00006400
	v_lshlrev_b32_e32 v19, 16, v19                             // 000000DC3B3C: 30262690
	v_dual_dot2acc_f32_f16 v11, v20, v2 :: v_dual_dot2acc_f32_f16 v12, v1, v4// 000000DC3B40: CB180514 0B0C0901
	v_dual_mov_b32 v20, v6 :: v_dual_mov_b32 v25, v36          // 000000DC3B48: CA100106 14180124
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DC3B50: BF870193
	v_and_or_b32 v19, 0xffff, v49, v19                         // 000000DC3B54: D6570013 044E62FF 0000FFFF
	v_dot2acc_f32_f16 v11, v21, v3                             // 000000DC3B60: 04160715
	v_dual_mov_b32 v21, v34 :: v_dual_mov_b32 v26, v28         // 000000DC3B64: CA100122 151A011C
	v_mov_b32_e32 v43, v37                                     // 000000DC3B6C: 7E560325
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DC3B70: BF870004
	v_pk_fma_f16 v2, v19, s7, 0xc931 op_sel_hi:[1,0,0]         // 000000DC3B74: CC0E0002 0BFC0F13 0000C931
	v_mov_b32_e32 v19, v34                                     // 000000DC3B80: 7E260322
	v_mov_b32_e32 v45, v37                                     // 000000DC3B84: 7E5A0325
	v_mov_b32_e32 v44, v29                                     // 000000DC3B88: 7E58031D
	v_mov_b32_e32 v46, v38                                     // 000000DC3B8C: 7E5C0326
	v_dot2acc_f32_f16 v11, v2, v4                              // 000000DC3B90: 04160902
	v_mov_b32_e32 v48, v38                                     // 000000DC3B94: 7E600326
	v_mov_b32_e32 v47, v30                                     // 000000DC3B98: 7E5E031E
	v_mov_b32_e32 v49, v39                                     // 000000DC3B9C: 7E620327
	v_mov_b32_e32 v51, v39                                     // 000000DC3BA0: 7E660327
	v_dual_mov_b32 v50, v31 :: v_dual_mov_b32 v53, v32         // 000000DC3BA4: CA10011F 32340120
	v_mov_b32_e32 v3, v42                                      // 000000DC3BAC: 7E06032A
	v_mov_b32_e32 v4, v42                                      // 000000DC3BB0: 7E08032A
	v_mov_b32_e32 v2, v33                                      // 000000DC3BB4: 7E040321
	v_mov_b32_e32 v1, v5                                       // 000000DC3BB8: 7E020305
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 000000DC3BBC: 917E067E
	s_cbranch_execz 58                                         // 000000DC3BC0: BFA5003A <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_oILi1EEEvPKhlPKDF16_PKiPfS5_S5_PDF16_PjNS0_5I4rSdEiS7_+0x19ac>
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DC3BC4: BF8700A1
	v_add_nc_u32_e32 v5, 1, v1                                 // 000000DC3BC8: 4A0A0281
	s_mov_b32 s8, exec_lo                                      // 000000DC3BCC: BE88007E
	.long 0xd4c1007e                                           // 000000DC3BD0: D4C1007E
	v_cndmask_b32_e32 v1, v5, v10, vcc_lo                      // 000000DC3BD4: 02021505
	s_cbranch_execz 64670                                      // 000000DC3BD8: BFA5FC9E <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_oILi1EEEvPKhlPKDF16_PKiPfS5_S5_PDF16_PjNS0_5I4rSdEiS7_+0xb54>
	v_ashrrev_i32_e32 v6, 31, v5                               // 000000DC3BDC: 340C0A9F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DC3BE0: BF870091
	.long 0xd73c001c                                           // 000000DC3BE4: D73C001C
	v_cndmask_b32_e32 v1, 10, v5, vcc_lo                       // 000000DC3BE8: 02020A8A
	.long 0xd7006a06                                           // 000000DC3BEC: D7006A06
	v_cndmask_b32_e32 v1, s4, v28, vcc_lo                      // 000000DC3BF0: 02023804
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DC3BF4: BF870111
	v_add_co_ci_u32_e64 v28, null, s5, v29, vcc_lo             // 000000DC3BF8: D5207C1C 01AA3A05
	.long 0xd7006a24                                           // 000000DC3C00: D7006A24
	v_cndmask_b32_e32 v1, v6, v24, vcc_lo                      // 000000DC3C04: 02023106
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DC3C08: BF8700A1
	v_add_co_ci_u32_e64 v37, null, 0, v28, vcc_lo              // 000000DC3C0C: D5207C25 01AA3880
	.long 0xd7006a3a                                           // 000000DC3C14: D7006A3A
	v_cndmask_b32_e32 v1, v6, v23, vcc_lo                      // 000000DC3C18: 02022F06
	v_add_co_ci_u32_e64 v59, null, 0, v28, vcc_lo              // 000000DC3C1C: D5207C3B 01AA3880
	s_clause 0xf                                               // 000000DC3C24: BF85000F
	global_load_b32 v33, v[36:37], off                         // 000000DC3C28: DC520000 217C0024
	global_load_b32 v35, v[36:37], off offset:128              // 000000DC3C30: DC520080 237C0024
	global_load_b32 v32, v[36:37], off offset:256              // 000000DC3C38: DC520100 207C0024
	global_load_b32 v31, v[36:37], off offset:384              // 000000DC3C40: DC520180 1F7C0024
	global_load_b32 v30, v[36:37], off offset:512              // 000000DC3C48: DC520200 1E7C0024
	global_load_b32 v29, v[36:37], off offset:640              // 000000DC3C50: DC520280 1D7C0024
	global_load_b32 v28, v[36:37], off offset:768              // 000000DC3C58: DC520300 1C7C0024
	global_load_b32 v6, v[36:37], off offset:896               // 000000DC3C60: DC520380 067C0024
	global_load_b32 v42, v[58:59], off                         // 000000DC3C68: DC520000 2A7C003A
	global_load_b32 v41, v[58:59], off offset:128              // 000000DC3C70: DC520080 297C003A
	global_load_b32 v40, v[58:59], off offset:256              // 000000DC3C78: DC520100 287C003A
	global_load_b32 v39, v[58:59], off offset:384              // 000000DC3C80: DC520180 277C003A
	global_load_b32 v38, v[58:59], off offset:512              // 000000DC3C88: DC520200 267C003A
	global_load_b32 v37, v[58:59], off offset:640              // 000000DC3C90: DC520280 257C003A
	global_load_b32 v36, v[58:59], off offset:768              // 000000DC3C98: DC520300 247C003A
	global_load_b32 v34, v[58:59], off offset:896              // 000000DC3CA0: DC520380 227C003A
	s_branch 64618                                             // 000000DC3CA8: BFA0FC6A <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_oILi1EEEvPKhlPKDF16_PKiPfS5_S5_PDF16_PjNS0_5I4rSdEiS7_+0xb54>
	s_or_b32 exec_lo, exec_lo, s6                              // 000000DC3CAC: 8C7E067E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000DC3CB0: BF870009
	s_or_b32 exec_lo, exec_lo, s3                              // 000000DC3CB4: 8C7E037E
	s_waitcnt vmcnt(23)                                        // 000000DC3CB8: BF895FF7
	v_dual_mov_b32 v1, v18 :: v_dual_mov_b32 v2, v17           // 000000DC3CBC: CA100112 01020111
	s_waitcnt vmcnt(7)                                         // 000000DC3CC4: BF891FF7
	v_dual_mov_b32 v3, v16 :: v_dual_mov_b32 v10, v15          // 000000DC3CC8: CA100110 030A010F
	v_dual_mov_b32 v4, v14 :: v_dual_mov_b32 v5, v13           // 000000DC3CD0: CA10010E 0404010D
	s_waitcnt vmcnt(0)                                         // 000000DC3CD8: BF8903F7
	v_dual_mov_b32 v6, v12 :: v_dual_mov_b32 v19, v11          // 000000DC3CDC: CA10010C 0612010B
	s_mov_b32 s3, 0x76543210                                   // 000000DC3CE4: BE8300FF 76543210
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000DC3CEC: BF870009
	v_permlanex16_b32 v1, v1, s3, 0xfedcba98                   // 000000DC3CF0: D65C0001 03FC0701 FEDCBA98
	v_permlanex16_b32 v2, v2, s3, 0xfedcba98                   // 000000DC3CFC: D65C0002 03FC0702 FEDCBA98
	v_permlanex16_b32 v3, v3, s3, 0xfedcba98                   // 000000DC3D08: D65C0003 03FC0703 FEDCBA98
	v_permlanex16_b32 v10, v10, s3, 0xfedcba98                 // 000000DC3D14: D65C000A 03FC070A FEDCBA98
	v_permlanex16_b32 v4, v4, s3, 0xfedcba98                   // 000000DC3D20: D65C0004 03FC0704 FEDCBA98
	v_permlanex16_b32 v5, v5, s3, 0xfedcba98                   // 000000DC3D2C: D65C0005 03FC0705 FEDCBA98
	v_permlanex16_b32 v6, v6, s3, 0xfedcba98                   // 000000DC3D38: D65C0006 03FC0706 FEDCBA98
	v_permlanex16_b32 v19, v19, s3, 0xfedcba98                 // 000000DC3D44: D65C0013 03FC0713 FEDCBA98
	.long 0xd44c0003                                           // 000000DC3D50: D44C0003
	v_cndmask_b32_e32 v1, 16, v9, vcc_lo                       // 000000DC3D54: 02021290
	s_barrier                                                  // 000000DC3D58: BFBD0000
	buffer_gl0_inv                                             // 000000DC3D5C: E0AC0000 00000000
	s_and_saveexec_b32 s4, s3                                  // 000000DC3D64: BE842003
	s_cbranch_execz 18                                         // 000000DC3D68: BFA50012 <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_oILi1EEEvPKhlPKDF16_PKiPfS5_S5_PDF16_PjNS0_5I4rSdEiS7_+0x1ab4>
	v_dual_add_f32 v9, v11, v19 :: v_dual_add_f32 v2, v17, v2  // 000000DC3D6C: C908270B 09020511
	v_dual_add_f32 v1, v18, v1 :: v_dual_add_f32 v10, v15, v10 // 000000DC3D74: C9080312 010A150F
	v_lshl_or_b32 v7, v8, 9, v7                                // 000000DC3D7C: D6560007 041D1308
	v_dual_add_f32 v3, v16, v3 :: v_dual_add_f32 v4, v14, v4   // 000000DC3D84: C9080710 0304090E
	v_dual_add_f32 v5, v13, v5 :: v_dual_add_f32 v6, v12, v6   // 000000DC3D8C: C9080B0D 05060D0C
	ds_store_2addr_b32 v7, v1, v2 offset1:16                   // 000000DC3D94: D8381000 00020107
	ds_store_2addr_b32 v7, v3, v10 offset0:32 offset1:48       // 000000DC3D9C: D8383020 000A0307
	ds_store_2addr_b32 v7, v4, v5 offset0:64 offset1:80        // 000000DC3DA4: D8385040 00050407
	ds_store_2addr_b32 v7, v6, v9 offset0:96 offset1:112       // 000000DC3DAC: D8387060 00090607
	s_or_b32 exec_lo, exec_lo, s4                              // 000000DC3DB4: 8C7E047E
	.long 0xd44c0004                                           // 000000DC3DB8: D44C0004
	v_cndmask_b32_e32 v1, 0x80, v0, vcc_lo                     // 000000DC3DBC: 020200FF 00000080
	s_waitcnt lgkmcnt(0)                                       // 000000DC3DC4: BF89FC07
	s_barrier                                                  // 000000DC3DC8: BFBD0000
	buffer_gl0_inv                                             // 000000DC3DCC: E0AC0000 00000000
	s_and_saveexec_b32 s5, s4                                  // 000000DC3DD4: BE852004
	s_cbranch_execnz 7                                         // 000000DC3DD8: BFA60007 <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_oILi1EEEvPKhlPKDF16_PKiPfS5_S5_PDF16_PjNS0_5I4rSdEiS7_+0x1af8>
	s_or_b32 exec_lo, exec_lo, s5                              // 000000DC3DDC: 8C7E057E
	s_cmp_lt_i32 s11, 2                                        // 000000DC3DE0: BF04820B
	s_mov_b32 s5, -1                                           // 000000DC3DE4: BE8500C1
	s_cbranch_scc0 33                                          // 000000DC3DE8: BFA10021 <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_oILi1EEEvPKhlPKDF16_PKiPfS5_S5_PDF16_PjNS0_5I4rSdEiS7_+0x1b70>
	s_and_b32 vcc_lo, exec_lo, s5                              // 000000DC3DEC: 8B6A057E
	s_cbranch_vccnz 155                                        // 000000DC3DF0: BFA4009B <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_oILi1EEEvPKhlPKDF16_PKiPfS5_S5_PDF16_PjNS0_5I4rSdEiS7_+0x1d60>
	s_branch 518                                               // 000000DC3DF4: BFA00206 <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_oILi1EEEvPKhlPKDF16_PKiPfS5_S5_PDF16_PjNS0_5I4rSdEiS7_+0x2310>
	v_lshlrev_b32_e32 v7, 2, v0                                // 000000DC3DF8: 300E0082
	ds_load_2addr_stride64_b32 v[1:2], v7 offset1:2            // 000000DC3DFC: D8E00200 01000007
	ds_load_2addr_stride64_b32 v[3:4], v7 offset0:4 offset1:6  // 000000DC3E04: D8E00604 03000007
	ds_load_2addr_stride64_b32 v[5:6], v7 offset0:8 offset1:10 // 000000DC3E0C: D8E00A08 05000007
	s_waitcnt lgkmcnt(2)                                       // 000000DC3E14: BF89FC27
	v_add_f32_e32 v1, 0, v1                                    // 000000DC3E18: 06020280
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DC3E1C: BF8700A1
	v_add_f32_e32 v1, v1, v2                                   // 000000DC3E20: 06020501
	s_waitcnt lgkmcnt(1)                                       // 000000DC3E24: BF89FC17
	v_add_f32_e32 v3, v1, v3                                   // 000000DC3E28: 06060701
	ds_load_2addr_stride64_b32 v[1:2], v7 offset0:12 offset1:14// 000000DC3E2C: D8E00E0C 01000007
	v_add_f32_e32 v3, v3, v4                                   // 000000DC3E34: 06060903
	s_waitcnt lgkmcnt(1)                                       // 000000DC3E38: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DC3E3C: BF870091
	v_add_f32_e32 v3, v3, v5                                   // 000000DC3E40: 06060B03
	v_add_f32_e32 v3, v3, v6                                   // 000000DC3E44: 06060D03
	s_waitcnt lgkmcnt(0)                                       // 000000DC3E48: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DC3E4C: BF870091
	v_add_f32_e32 v1, v3, v1                                   // 000000DC3E50: 06020303
	v_add_f32_e32 v1, v1, v2                                   // 000000DC3E54: 06020501
	ds_store_b32 v7, v1 offset:4096                            // 000000DC3E58: D8341000 00000107
	s_or_b32 exec_lo, exec_lo, s5                              // 000000DC3E60: 8C7E057E
	s_cmp_lt_i32 s11, 2                                        // 000000DC3E64: BF04820B
	s_mov_b32 s5, -1                                           // 000000DC3E68: BE8500C1
	s_cbranch_scc1 65503                                       // 000000DC3E6C: BFA2FFDF <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_oILi1EEEvPKhlPKDF16_PKiPfS5_S5_PDF16_PjNS0_5I4rSdEiS7_+0x1aec>
	s_waitcnt lgkmcnt(0)                                       // 000000DC3E70: BF89FC07
	s_barrier                                                  // 000000DC3E74: BFBD0000
	buffer_gl0_inv                                             // 000000DC3E78: E0AC0000 00000000
	s_and_saveexec_b32 s5, s4                                  // 000000DC3E80: BE852004
	s_cbranch_execz 17                                         // 000000DC3E84: BFA50011 <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_oILi1EEEvPKhlPKDF16_PKiPfS5_S5_PDF16_PjNS0_5I4rSdEiS7_+0x1bcc>
	v_lshlrev_b32_e32 v1, 2, v0                                // 000000DC3E88: 30020082
	s_mul_hi_i32 s7, s31, s29                                  // 000000DC3E8C: 97071D1F
	s_mul_i32 s6, s31, s29                                     // 000000DC3E90: 96061D1F
	s_lshl_b32 s8, s34, 7                                      // 000000DC3E94: 84088722
	s_lshl_b64 s[6:7], s[6:7], 2                               // 000000DC3E98: 84868206
	ds_load_b32 v2, v1 offset:4096                             // 000000DC3E9C: D8D81000 02000001
	s_ashr_i32 s9, s8, 31                                      // 000000DC3EA4: 86099F08
	s_add_u32 s10, s26, s6                                     // 000000DC3EA8: 800A061A
	s_addc_u32 s14, s27, s7                                    // 000000DC3EAC: 820E071B
	s_lshl_b64 s[6:7], s[8:9], 2                               // 000000DC3EB0: 84868208
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000DC3EB4: BF870009
	s_add_u32 s6, s10, s6                                      // 000000DC3EB8: 8006060A
	s_addc_u32 s7, s14, s7                                     // 000000DC3EBC: 8207070E
	s_waitcnt lgkmcnt(0)                                       // 000000DC3EC0: BF89FC07
	global_store_b32 v1, v2, s[6:7]                            // 000000DC3EC4: DC6A0000 00060201
	s_or_b32 exec_lo, exec_lo, s5                              // 000000DC3ECC: 8C7E057E
	.long 0xd44a0005                                           // 000000DC3ED0: D44A0005
	v_cndmask_b32_e32 v1, 0, v0, vcc_lo                        // 000000DC3ED4: 02020080
	s_waitcnt_vscnt null, 0x0                                  // 000000DC3ED8: BC7C0000
	buffer_gl1_inv                                             // 000000DC3EDC: E0B00000 00000000
	buffer_gl0_inv                                             // 000000DC3EE4: E0AC0000 00000000
	s_barrier                                                  // 000000DC3EEC: BFBD0000
	buffer_gl0_inv                                             // 000000DC3EF0: E0AC0000 00000000
	s_and_saveexec_b32 s6, s5                                  // 000000DC3EF8: BE862005
	s_cbranch_execz 29                                         // 000000DC3EFC: BFA5001D <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_oILi1EEEvPKhlPKDF16_PKiPfS5_S5_PDF16_PjNS0_5I4rSdEiS7_+0x1c74>
	s_mov_b32 s8, exec_lo                                      // 000000DC3F00: BE88007E
	s_mov_b32 s7, exec_lo                                      // 000000DC3F04: BE87007E
	.long 0xd71f0001                                           // 000000DC3F08: D71F0001
	v_cndmask_b32_e32 v0, s8, v128, vcc_lo                     // 000000DC3F0C: 02010008
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DC3F10: BF870001
	v_cmpx_eq_u32_e32 0, v1                                    // 000000DC3F14: 7D940280
	s_cbranch_execz 9                                          // 000000DC3F18: BFA50009 <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_oILi1EEEvPKhlPKDF16_PKiPfS5_S5_PDF16_PjNS0_5I4rSdEiS7_+0x1c40>
	s_lshl_b64 s[14:15], s[34:35], 2                           // 000000DC3F1C: 848E8222
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 000000DC3F20: BF8704B9
	s_add_u32 s14, s36, s14                                    // 000000DC3F24: 800E0E24
	s_addc_u32 s15, s37, s15                                   // 000000DC3F28: 820F0F25
	s_bcnt1_i32_b32 s8, s8                                     // 000000DC3F2C: BE881808
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v3, s8              // 000000DC3F30: CA100080 02020008
	global_atomic_add_u32 v2, v2, v3, s[14:15] glc             // 000000DC3F38: DCD64000 020E0302
	s_or_b32 exec_lo, exec_lo, s7                              // 000000DC3F40: 8C7E077E
	s_waitcnt vmcnt(0)                                         // 000000DC3F44: BF8903F7
	v_readfirstlane_b32 s7, v2                                 // 000000DC3F48: 7E0E0502
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DC3F4C: BF870001
	v_dual_mov_b32 v2, 0 :: v_dual_add_nc_u32 v1, s7, v1       // 000000DC3F50: CA200080 02000207
	s_add_i32 s7, s11, -1                                      // 000000DC3F58: 8107C10B
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 000000DC3F5C: BF870481
	v_cmp_eq_u32_e32 vcc_lo, s7, v1                            // 000000DC3F60: 7C940207
	v_cndmask_b32_e64 v1, 0, 1, vcc_lo                         // 000000DC3F64: D5010001 01A90280
	ds_store_b32 v2, v1 offset:10240                           // 000000DC3F6C: D8342800 00000102
	s_or_b32 exec_lo, exec_lo, s6                              // 000000DC3F74: 8C7E067E
	v_mov_b32_e32 v1, 0                                        // 000000DC3F78: 7E020280
	s_waitcnt lgkmcnt(0)                                       // 000000DC3F7C: BF89FC07
	s_barrier                                                  // 000000DC3F80: BFBD0000
	buffer_gl0_inv                                             // 000000DC3F84: E0AC0000 00000000
	ds_load_b32 v1, v1 offset:10240                            // 000000DC3F8C: D8D82800 01000001
	s_waitcnt lgkmcnt(0)                                       // 000000DC3F94: BF89FC07
	v_cmp_eq_u32_e32 vcc_lo, 0, v1                             // 000000DC3F98: 7C940280
	s_cbranch_vccnz 47                                         // 000000DC3F9C: BFA4002F <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_oILi1EEEvPKhlPKDF16_PKiPfS5_S5_PDF16_PjNS0_5I4rSdEiS7_+0x1d5c>
	buffer_gl1_inv                                             // 000000DC3FA0: E0B00000 00000000
	buffer_gl0_inv                                             // 000000DC3FA8: E0AC0000 00000000
	s_and_saveexec_b32 s8, s4                                  // 000000DC3FB0: BE882004
	s_cbranch_execz 29                                         // 000000DC3FB4: BFA5001D <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_oILi1EEEvPKhlPKDF16_PKiPfS5_S5_PDF16_PjNS0_5I4rSdEiS7_+0x1d2c>
	s_lshl_b32 s6, s34, 7                                      // 000000DC3FB8: 84068722
	v_dual_mov_b32 v4, 0 :: v_dual_lshlrev_b32 v3, 2, v0       // 000000DC3FBC: CA220080 04020082
	s_ashr_i32 s7, s6, 31                                      // 000000DC3FC4: 86079F06
	s_ashr_i32 s15, s29, 31                                    // 000000DC3FC8: 860F9F1D
	s_lshl_b64 s[6:7], s[6:7], 2                               // 000000DC3FCC: 84868206
	s_mov_b32 s14, s29                                         // 000000DC3FD0: BE8E001D
	s_add_u32 s4, s26, s6                                      // 000000DC3FD4: 8004061A
	s_addc_u32 s6, s27, s7                                     // 000000DC3FD8: 8206071B
	.long 0xd7000401                                           // 000000DC3FDC: D7000401
	v_cndmask_b32_e32 v1, s4, v3, vcc_lo                       // 000000DC3FE0: 02020604
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DC3FE4: BF870001
	v_add_co_ci_u32_e64 v2, null, s6, 0, s4                    // 000000DC3FE8: D5207C02 00110006
	s_lshl_b64 s[6:7], s[14:15], 2                             // 000000DC3FF0: 8486820E
	global_load_b32 v5, v[1:2], off glc                        // 000000DC3FF4: DC524000 057C0001
	.long 0xd7006a01                                           // 000000DC3FFC: D7006A01
	v_cndmask_b32_e32 v0, v1, v6, vcc_lo                       // 000000DC4000: 02000D01
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000DC4004: BF8704A1
	v_add_co_ci_u32_e64 v2, null, s7, v2, vcc_lo               // 000000DC4008: D5207C02 01AA0407
	s_add_i32 s11, s11, -1                                     // 000000DC4010: 810BC10B
	s_cmp_eq_u32 s11, 0                                        // 000000DC4014: BF06800B
	s_waitcnt vmcnt(0)                                         // 000000DC4018: BF8903F7
	v_add_f32_e32 v4, v4, v5                                   // 000000DC401C: 06080B04
	s_cbranch_scc0 65524                                       // 000000DC4020: BFA1FFF4 <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_oILi1EEEvPKhlPKDF16_PKiPfS5_S5_PDF16_PjNS0_5I4rSdEiS7_+0x1cf4>
	ds_store_b32 v3, v4 offset:4096                            // 000000DC4024: D8341000 00000403
	s_or_b32 exec_lo, exec_lo, s8                              // 000000DC402C: 8C7E087E
	s_and_saveexec_b32 s4, s5                                  // 000000DC4030: BE842005
	s_cbranch_execz 6                                          // 000000DC4034: BFA50006 <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_oILi1EEEvPKhlPKDF16_PKiPfS5_S5_PDF16_PjNS0_5I4rSdEiS7_+0x1d50>
	s_lshl_b64 s[6:7], s[34:35], 2                             // 000000DC4038: 84868222
	v_mov_b32_e32 v1, 0                                        // 000000DC403C: 7E020280
	s_add_u32 s6, s36, s6                                      // 000000DC4040: 80060624
	s_addc_u32 s7, s37, s7                                     // 000000DC4044: 82070725
	global_store_b32 v1, v1, s[6:7]                            // 000000DC4048: DC6A0000 00060101
	s_or_b32 exec_lo, exec_lo, s4                              // 000000DC4050: 8C7E047E
	s_cbranch_execnz 2                                         // 000000DC4054: BFA60002 <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_oILi1EEEvPKhlPKDF16_PKiPfS5_S5_PDF16_PjNS0_5I4rSdEiS7_+0x1d60>
	s_branch 365                                               // 000000DC4058: BFA0016D <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_oILi1EEEvPKhlPKDF16_PKiPfS5_S5_PDF16_PjNS0_5I4rSdEiS7_+0x2310>
	s_branch 364                                               // 000000DC405C: BFA0016C <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_oILi1EEEvPKhlPKDF16_PKiPfS5_S5_PDF16_PjNS0_5I4rSdEiS7_+0x2310>
	v_cmp_eq_u32_e32 vcc_lo, 0, v8                             // 000000DC4060: 7C941080
	s_cmp_gt_i32 s28, 0                                        // 000000DC4064: BF02801C
	s_waitcnt lgkmcnt(0)                                       // 000000DC4068: BF89FC07
	s_waitcnt_vscnt null, 0x0                                  // 000000DC406C: BC7C0000
	s_cselect_b32 s4, -1, 0                                    // 000000DC4070: 980480C1
	s_barrier                                                  // 000000DC4074: BFBD0000
	s_and_b32 s4, vcc_lo, s4                                   // 000000DC4078: 8B04046A
	buffer_gl0_inv                                             // 000000DC407C: E0AC0000 00000000
	s_and_saveexec_b32 s6, s4                                  // 000000DC4084: BE862004
	s_cbranch_execz 352                                        // 000000DC4088: BFA50160 <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_oILi1EEEvPKhlPKDF16_PKiPfS5_S5_PDF16_PjNS0_5I4rSdEiS7_+0x230c>
	v_and_b32_e32 v1, 15, v0                                   // 000000DC408C: 3602008F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DC4090: BF870091
	v_lshlrev_b32_e32 v2, 2, v1                                // 000000DC4094: 30040282
	v_add_nc_u32_e32 v8, 0x1000, v2                            // 000000DC4098: 4A1004FF 00001000
	ds_load_2addr_b32 v[2:3], v8 offset1:16                    // 000000DC40A0: D8DC1000 02000008
	ds_load_2addr_b32 v[4:5], v8 offset0:32 offset1:48         // 000000DC40A8: D8DC3020 04000008
	ds_load_2addr_b32 v[6:7], v8 offset0:64 offset1:80         // 000000DC40B0: D8DC5040 06000008
	ds_load_2addr_b32 v[8:9], v8 offset0:96 offset1:112        // 000000DC40B8: D8DC7060 08000008
	v_and_b32_e32 v10, 1, v0                                   // 000000DC40C0: 36140081
	v_and_b32_e32 v11, 2, v0                                   // 000000DC40C4: 36160082
	s_waitcnt lgkmcnt(3)                                       // 000000DC40C8: BF89FC37
	v_dual_add_f32 v13, v2, v3 :: v_dual_and_b32 v12, 4, v0    // 000000DC40CC: C9240702 0D0C0084
	s_waitcnt lgkmcnt(2)                                       // 000000DC40D4: BF89FC27
	v_dual_sub_f32 v2, v2, v3 :: v_dual_add_f32 v3, v4, v5     // 000000DC40D8: C9480702 02020B04
	s_waitcnt lgkmcnt(1)                                       // 000000DC40E0: BF89FC17
	v_dual_sub_f32 v4, v4, v5 :: v_dual_add_f32 v5, v6, v7     // 000000DC40E4: C9480B04 04040F06
	s_waitcnt lgkmcnt(0)                                       // 000000DC40EC: BF89FC07
	v_dual_sub_f32 v6, v6, v7 :: v_dual_add_f32 v7, v8, v9     // 000000DC40F0: C9480F06 06061308
	v_dual_sub_f32 v8, v8, v9 :: v_dual_add_f32 v9, v13, v3    // 000000DC40F8: C9481308 0808070D
	v_sub_f32_e32 v3, v13, v3                                  // 000000DC4100: 0806070D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000DC4104: BF870243
	v_dual_add_f32 v13, v2, v4 :: v_dual_add_f32 v14, v5, v7   // 000000DC4108: C9080902 0D0E0F05
	v_dual_sub_f32 v2, v2, v4 :: v_dual_sub_f32 v5, v5, v7     // 000000DC4110: C94A0902 02040F05
	v_cmp_eq_u32_e32 vcc_lo, 0, v10                            // 000000DC4118: 7C941480
	.long 0xd44a0004                                           // 000000DC411C: D44A0004
	v_cndmask_b32_e32 v1, 0, v11, vcc_lo                       // 000000DC4120: 02021680
	v_dual_add_f32 v7, v9, v14 :: v_dual_add_f32 v4, v6, v8    // 000000DC4124: C9081D09 07041106
	v_sub_f32_e32 v6, v6, v8                                   // 000000DC412C: 080C1106
	v_sub_f32_e32 v8, v9, v14                                  // 000000DC4130: 08101D09
	.long 0xd44a0005                                           // 000000DC4134: D44A0005
	v_cndmask_b32_e32 v1, 0, v12, vcc_lo                       // 000000DC4138: 02021880
	s_delay_alu instid0(VALU_DEP_3)                            // 000000DC413C: BF870003
	v_dual_add_f32 v9, v13, v4 :: v_dual_sub_f32 v10, v2, v6   // 000000DC4140: C90A090D 090A0D02
	v_dual_sub_f32 v4, v13, v4 :: v_dual_add_f32 v13, v3, v5   // 000000DC4148: C948090D 040C0B03
	v_sub_f32_e32 v3, v3, v5                                   // 000000DC4150: 08060B03
	v_add_f32_e32 v5, v2, v6                                   // 000000DC4154: 060A0D02
	v_mov_b32_dpp v2, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DC4158: 7E0402FA FF016107
	v_cndmask_b32_e64 v6, -v7, v7, vcc_lo                      // 000000DC4160: D5010006 21AA0F07
	v_mov_b32_dpp v7, v9 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DC4168: 7E0E02FA FF016109
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 000000DC4170: D5010009 21AA1309
	v_mov_b32_dpp v15, v5 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DC4178: 7E1E02FA FF016105
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 000000DC4180: D5010005 21AA0B05
	v_mov_b32_dpp v14, v13 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DC4188: 7E1C02FA FF01610D
	v_cndmask_b32_e64 v13, -v13, v13, vcc_lo                   // 000000DC4190: D501000D 21AA1B0D
	v_mov_b32_dpp v16, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DC4198: 7E2002FA FF016108
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 000000DC41A0: D5010008 21AA1108
	v_mov_b32_dpp v17, v4 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DC41A8: 7E2202FA FF016104
	v_cndmask_b32_e64 v18, -v4, v4, vcc_lo                     // 000000DC41B0: D5010012 21AA0904
	v_mov_b32_dpp v19, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DC41B8: 7E2602FA FF016103
	v_cndmask_b32_e64 v20, -v3, v3, vcc_lo                     // 000000DC41C0: D5010014 21AA0703
	v_dual_add_f32 v3, v9, v7 :: v_dual_add_f32 v2, v6, v2     // 000000DC41C8: C9080F09 03020506
	v_dual_add_f32 v4, v5, v15 :: v_dual_add_f32 v7, v8, v16   // 000000DC41D0: C9081F05 04062108
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DC41D8: BF870192
	v_cndmask_b32_e64 v8, -v3, v3, s4                          // 000000DC41DC: D5010008 20120703
	v_mov_b32_dpp v6, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DC41E4: 7E0C02FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, s4                          // 000000DC41EC: D5010002 20120502
	v_mov_b32_dpp v3, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DC41F4: 7E0602FA FF016203
	v_mov_b32_dpp v11, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DC41FC: 7E1602FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, s4                          // 000000DC4204: D5010004 20120904
	v_add_f32_e32 v5, v13, v14                                 // 000000DC420C: 060A1D0D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000DC4210: BF870224
	v_dual_add_f32 v2, v2, v6 :: v_dual_add_f32 v3, v8, v3     // 000000DC4214: C9080D02 02020708
	v_mov_b32_dpp v13, v7 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DC421C: 7E1A02FA FF016207
	v_add_f32_e32 v4, v4, v11                                  // 000000DC4224: 06081704
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DC4228: BF870004
	v_mov_b32_dpp v9, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DC422C: 7E1202FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, s4                          // 000000DC4234: D5010005 20120B05
	v_mov_b32_dpp v6, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DC423C: 7E0C02FA FF016402
	v_cndmask_b32_e64 v8, -v3, v3, s5                          // 000000DC4244: D5010008 20160703
	v_cndmask_b32_e64 v2, -v2, v2, s5                          // 000000DC424C: D5010002 20160502
	v_mov_b32_dpp v11, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DC4254: 7E1602FA FF016403
	v_add_f32_e32 v5, v5, v9                                   // 000000DC425C: 060A1305
	v_mov_b32_dpp v9, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DC4260: 7E1202FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s5                          // 000000DC4268: D5010004 20160904
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DC4270: BF870214
	v_dual_add_f32 v3, v2, v6 :: v_dual_add_f32 v6, v8, v11    // 000000DC4274: C9080D02 03061708
	v_mov_b32_dpp v8, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DC427C: 7E1002FA FF016405
	v_cndmask_b32_e64 v11, -v5, v5, s5                         // 000000DC4284: D501000B 20160B05
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DC428C: BF870004
	v_add_f32_e32 v4, v4, v9                                   // 000000DC4290: 06081304
	v_mov_b32_dpp v9, v10 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DC4294: 7E1202FA FF01610A
	v_cndmask_b32_e64 v10, -v10, v10, vcc_lo                   // 000000DC429C: D501000A 21AA150A
	v_add_f32_e32 v12, v18, v17                                // 000000DC42A4: 06182312
	v_cndmask_b32_e64 v7, -v7, v7, s4                          // 000000DC42A8: D5010007 20120F07
	v_add_f32_e32 v14, v20, v19                                // 000000DC42B0: 061C2714
	v_mov_b32_dpp v2, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DC42B4: 7E0402FA FF016803
	v_add_f32_e32 v9, v10, v9                                  // 000000DC42BC: 0612130A
	v_mov_b32_dpp v5, v6 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DC42C0: 7E0A02FA FF016806
	v_add_f32_e32 v13, v7, v13                                 // 000000DC42C8: 061A1B07
	v_mov_b32_dpp v15, v14 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DC42CC: 7E1E02FA FF01620E
	v_cndmask_b32_e64 v14, -v14, v14, s4                       // 000000DC42D4: D501000E 20121D0E
	v_mov_b32_dpp v16, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DC42DC: 7E2002FA FF016209
	v_cndmask_b32_e64 v9, -v9, v9, s4                          // 000000DC42E4: D5010009 20121309
	v_add_f32_e32 v7, v11, v8                                  // 000000DC42EC: 060E110B
	v_mov_b32_dpp v10, v12 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DC42F0: 7E1402FA FF01620C
	v_cndmask_b32_e64 v12, -v12, v12, s4                       // 000000DC42F8: D501000C 2012190C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DC4300: BF870114
	v_dual_add_f32 v8, v14, v15 :: v_dual_add_f32 v9, v9, v16  // 000000DC4304: C9081F0E 08082109
	v_add_f32_e32 v10, v12, v10                                // 000000DC430C: 0614150C
	v_mov_b32_dpp v11, v13 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DC4310: 7E1602FA FF01640D
	v_cndmask_b32_e64 v13, -v13, v13, s5                       // 000000DC4318: D501000D 20161B0D
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DC4320: BF870004
	v_mov_b32_dpp v15, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DC4324: 7E1E02FA FF016408
	v_mov_b32_dpp v17, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DC432C: 7E2202FA FF016409
	v_mov_b32_dpp v12, v10 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DC4334: 7E1802FA FF01640A
	v_cndmask_b32_e64 v10, -v10, v10, s5                       // 000000DC433C: D501000A 2016150A
	v_cndmask_b32_e64 v18, -v8, v8, s5                         // 000000DC4344: D5010012 20161108
	v_cndmask_b32_e64 v9, -v9, v9, s5                          // 000000DC434C: D5010009 20161309
	v_add_f32_e32 v14, v13, v11                                // 000000DC4354: 061C170D
	v_mov_b32_dpp v8, v7 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DC4358: 7E1002FA FF016807
	v_add_f32_e32 v16, v10, v12                                // 000000DC4360: 0620190A
	v_add_f32_e32 v15, v18, v15                                // 000000DC4364: 061E1F12
	v_add_f32_e32 v17, v9, v17                                 // 000000DC4368: 06222309
	v_mov_b32_dpp v9, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DC436C: 7E1202FA FF016804
	v_mov_b32_dpp v10, v14 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DC4374: 7E1402FA FF01680E
	v_mov_b32_dpp v11, v16 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DC437C: 7E1602FA FF016810
	v_mov_b32_dpp v12, v15 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DC4384: 7E1802FA FF01680F
	v_mov_b32_dpp v13, v17 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DC438C: 7E1A02FA FF016811
	s_and_b32 exec_lo, exec_lo, s3                             // 000000DC4394: 8B7E037E
	s_cbranch_execz 156                                        // 000000DC4398: BFA5009C <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_oILi1EEEvPKhlPKDF16_PKiPfS5_S5_PDF16_PjNS0_5I4rSdEiS7_+0x230c>
	v_lshl_or_b32 v18, s34, 7, v1                              // 000000DC439C: D6560012 04050E22
	v_and_b32_e32 v1, 8, v0                                    // 000000DC43A4: 36020088
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DC43A8: BF870092
	v_ashrrev_i32_e32 v19, 31, v18                             // 000000DC43AC: 3426249F
	.long 0xd73c0012                                           // 000000DC43B0: D73C0012
	v_cndmask_b32_e32 v1, 1, v18, vcc_lo                       // 000000DC43B4: 02022481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DC43B8: BF870091
	.long 0xd7006a14                                           // 000000DC43BC: D7006A14
	v_cndmask_b32_e32 v1, s18, v18, vcc_lo                     // 000000DC43C0: 02022412
	v_add_co_ci_u32_e64 v21, null, s19, v19, vcc_lo            // 000000DC43C4: D5207C15 01AA2613
	v_cmp_eq_u32_e32 vcc_lo, 0, v1                             // 000000DC43CC: 7C940280
	s_clause 0x7                                               // 000000DC43D0: BF850007
	global_load_d16_b16 v22, v[20:21], off offset:32           // 000000DC43D4: DC820020 167C0014
	global_load_d16_b16 v23, v[20:21], off                     // 000000DC43DC: DC820000 177C0014
	global_load_d16_b16 v24, v[20:21], off offset:64           // 000000DC43E4: DC820040 187C0014
	global_load_d16_b16 v25, v[20:21], off offset:96           // 000000DC43EC: DC820060 197C0014
	global_load_d16_b16 v26, v[20:21], off offset:128          // 000000DC43F4: DC820080 1A7C0014
	global_load_d16_b16 v27, v[20:21], off offset:160          // 000000DC43FC: DC8200A0 1B7C0014
	global_load_d16_b16 v28, v[20:21], off offset:192          // 000000DC4404: DC8200C0 1C7C0014
	global_load_d16_b16 v20, v[20:21], off offset:224          // 000000DC440C: DC8200E0 147C0014
	.long 0x7f2a3880                                           // 000000DC4414: 7F2A3880
	v_cndmask_b32_e64 v1, -v6, v6, vcc_lo                      // 000000DC4418: D5010001 21AA0D06
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 000000DC4420: D5010004 21AA0904
	v_cndmask_b32_e64 v14, -v14, v14, vcc_lo                   // 000000DC4428: D501000E 21AA1D0E
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 000000DC4430: D5010003 21AA0703
	s_waitcnt vmcnt(7)                                         // 000000DC4438: BF891FF7
	.long 0x7f2c3995                                           // 000000DC443C: 7F2C3995
	v_add_f32_e32 v1, v1, v5                                   // 000000DC4440: 06020B01
	v_cndmask_b32_e64 v5, -v7, v7, vcc_lo                      // 000000DC4444: D5010005 21AA0F07
	v_cndmask_b32_e64 v7, -v16, v16, vcc_lo                    // 000000DC444C: D5010007 21AA2110
	v_cndmask_b32_e64 v16, -v17, v17, vcc_lo                   // 000000DC4454: D5010010 21AA2311
	v_add_f32_e32 v4, v4, v9                                   // 000000DC445C: 06081304
	v_cndmask_b32_e64 v15, -v15, v15, vcc_lo                   // 000000DC4460: D501000F 21AA1F0F
	v_dual_add_f32 v5, v5, v8 :: v_dual_add_f32 v8, v14, v10   // 000000DC4468: C9081105 0508150E
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000DC4470: BF8701A3
	v_dual_mul_f32 v17, 0x3db504f3, v1 :: v_dual_mul_f32 v4, 0x3db504f3, v4// 000000DC4474: C8C602FF 110408FF 3DB504F3
	v_dual_add_f32 v3, v3, v2 :: v_dual_add_f32 v10, v16, v13  // 000000DC4480: C9080503 030A1B10
	v_dual_add_f32 v7, v7, v11 :: v_dual_mul_f32 v8, 0x3db504f3, v8// 000000DC4488: C9061707 070810FF 3DB504F3
	.long 0x7f0c3995                                           // 000000DC4494: 7F0C3995
	s_delay_alu instid0(VALU_DEP_3)                            // 000000DC4498: BF870003
	v_mul_f32_e32 v3, 0x3db504f3, v3                           // 000000DC449C: 100606FF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 000000DC44A4: BF8903F7
	.long 0x7f283995                                           // 000000DC44A8: 7F283995
	v_dual_mul_f32 v7, 0x3db504f3, v7 :: v_dual_mul_f32 v10, 0x3db504f3, v10// 000000DC44AC: C8C60EFF 070A14FF 3DB504F3
	v_mul_f32_e32 v5, 0x3db504f3, v5                           // 000000DC44B8: 100A0AFF 3DB504F3
	.long 0x7f2e3995                                           // 000000DC44C0: 7F2E3995
	.long 0xd7006a01                                           // 000000DC44C4: D7006A01
	v_cndmask_b32_e32 v1, s24, v18, vcc_lo                     // 000000DC44C8: 02022418
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000DC44CC: BF870221
	v_add_co_ci_u32_e64 v2, null, s25, v19, vcc_lo             // 000000DC44D0: D5207C02 01AA2619
	v_fma_mix_f32 v11, v22, v17, neg(0) op_sel_hi:[1,0,0]      // 000000DC44D8: CC20000B 8A022316
	v_fma_mix_f32 v3, v23, v3, neg(0) op_sel_hi:[1,0,0]        // 000000DC44E0: CC200003 8A020717
	v_fma_mix_f32 v5, v24, v5, neg(0) op_sel_hi:[1,0,0]        // 000000DC44E8: CC200005 8A020B18
	v_fma_mix_f32 v4, v25, v4, neg(0) op_sel_hi:[1,0,0]        // 000000DC44F0: CC200004 8A020919
	v_fma_mix_f32 v8, v26, v8, neg(0) op_sel_hi:[1,0,0]        // 000000DC44F8: CC200008 8A02111A
	.long 0x7e2a398b                                           // 000000DC4500: 7E2A398B
	v_add_f32_e32 v9, v15, v12                                 // 000000DC4504: 0612190F
	v_fma_mix_f32 v7, v27, v7, neg(0) op_sel_hi:[1,0,0]        // 000000DC4508: CC200007 8A020F1B
	v_fma_mix_f32 v10, v20, v10, neg(0) op_sel_hi:[1,0,0]      // 000000DC4510: CC20000A 8A021514
	.long 0x7e0c3983                                           // 000000DC4518: 7E0C3983
	v_and_b32_e32 v12, 1, v21                                  // 000000DC451C: 36182A81
	v_mul_f32_e32 v9, 0x3db504f3, v9                           // 000000DC4520: 101212FF 3DB504F3
	.long 0x7e2a3984                                           // 000000DC4528: 7E2A3984
	.long 0x7e283985                                           // 000000DC452C: 7E283985
	.long 0x7e2c3988                                           // 000000DC4530: 7E2C3988
	v_and_b32_e32 v6, 1, v6                                    // 000000DC4534: 360C0C81
	v_fma_mix_f32 v9, v28, v9, neg(0) op_sel_hi:[1,0,0]        // 000000DC4538: CC200009 8A02131C
	v_and_b32_e32 v13, 1, v21                                  // 000000DC4540: 361A2A81
	.long 0x7e2a3987                                           // 000000DC4544: 7E2A3987
	v_and_b32_e32 v14, 1, v20                                  // 000000DC4548: 361C2881
	v_and_b32_e32 v15, 1, v22                                  // 000000DC454C: 361E2C81
	.long 0x7e2e3989                                           // 000000DC4550: 7E2E3989
	v_add3_u32 v3, v3, v6, 0x7fff                              // 000000DC4554: D6550003 03FE0D03 00007FFF
	v_and_b32_e32 v16, 1, v21                                  // 000000DC4560: 36202A81
	.long 0x7e2a398a                                           // 000000DC4564: 7E2A398A
	v_add3_u32 v11, v11, v12, 0x7fff                           // 000000DC4568: D655000B 03FE190B 00007FFF
	v_and_b32_e32 v17, 1, v23                                  // 000000DC4574: 36222E81
	v_add3_u32 v5, v5, v14, 0x7fff                             // 000000DC4578: D6550005 03FE1D05 00007FFF
	v_add3_u32 v4, v4, v13, 0x7fff                             // 000000DC4584: D6550004 03FE1B04 00007FFF
	v_and_b32_e32 v6, 1, v21                                   // 000000DC4590: 360C2A81
	v_add3_u32 v8, v8, v15, 0x7fff                             // 000000DC4594: D6550008 03FE1F08 00007FFF
	v_add3_u32 v9, v9, v17, 0x7fff                             // 000000DC45A0: D6550009 03FE2309 00007FFF
	v_add3_u32 v7, v7, v16, 0x7fff                             // 000000DC45AC: D6550007 03FE2107 00007FFF
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DC45B8: BF870004
	v_add3_u32 v6, v10, v6, 0x7fff                             // 000000DC45BC: D6550006 03FE0D0A 00007FFF
	s_clause 0x7                                               // 000000DC45C8: BF850007
	global_store_d16_hi_b16 v[1:2], v3, off                    // 000000DC45CC: DC960000 007C0301
	global_store_d16_hi_b16 v[1:2], v11, off offset:32         // 000000DC45D4: DC960020 007C0B01
	global_store_d16_hi_b16 v[1:2], v5, off offset:64          // 000000DC45DC: DC960040 007C0501
	global_store_d16_hi_b16 v[1:2], v4, off offset:96          // 000000DC45E4: DC960060 007C0401
	global_store_d16_hi_b16 v[1:2], v8, off offset:128         // 000000DC45EC: DC960080 007C0801
	global_store_d16_hi_b16 v[1:2], v7, off offset:160         // 000000DC45F4: DC9600A0 007C0701
	global_store_d16_hi_b16 v[1:2], v9, off offset:192         // 000000DC45FC: DC9600C0 007C0901
	global_store_d16_hi_b16 v[1:2], v6, off offset:224         // 000000DC4604: DC9600E0 007C0601
	s_or_b32 exec_lo, exec_lo, s6                              // 000000DC460C: 8C7E067E
	s_mov_b32 s4, 0                                            // 000000DC4610: BE840080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000DC4614: BF870009
	s_and_b32 vcc_lo, exec_lo, s4                              // 000000DC4618: 8B6A047E
	s_cbranch_vccz 4662                                        // 000000DC461C: BFA31236 <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_oILi1EEEvPKhlPKDF16_PKiPfS5_S5_PDF16_PjNS0_5I4rSdEiS7_+0x6bf8>
	s_load_b64 s[4:5], s[0:1], 0xa8                            // 000000DC4620: F4040100 F80000A8
	s_mul_hi_u32 s3, s2, 0xcccccccd                            // 000000DC4628: 9683FF02 CCCCCCCD
	s_load_b512 s[16:31], s[0:1], null                         // 000000DC4630: F4100400 F8000000
	s_lshr_b32 s3, s3, 4                                       // 000000DC4638: 85038403
	s_mov_b32 s1, exec_lo                                      // 000000DC463C: BE81007E
	s_lshl_b32 s6, s3, 2                                       // 000000DC4640: 84068203
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000DC4644: BF870009
	v_mov_b32_e32 v1, s6                                       // 000000DC4648: 7E020206
	s_waitcnt lgkmcnt(0)                                       // 000000DC464C: BF89FC07
	global_load_b32 v1, v1, s[4:5]                             // 000000DC4650: DC520000 01040001
	s_waitcnt vmcnt(0)                                         // 000000DC4658: BF8903F7
	v_readfirstlane_b32 s10, v1                                // 000000DC465C: 7E140501
	v_cmpx_gt_u32_e32 0x140, v0                                // 000000DC4660: 7D9800FF 00000140
	s_cbranch_execz 41                                         // 000000DC4668: BFA50029 <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_oILi1EEEvPKhlPKDF16_PKiPfS5_S5_PDF16_PjNS0_5I4rSdEiS7_+0x2410>
	s_mul_hi_i32 s0, s10, 0x66666667                           // 000000DC466C: 9700FF0A 66666667
	v_lshlrev_b32_e32 v4, 4, v0                                // 000000DC4674: 30080084
	s_lshr_b32 s4, s0, 31                                      // 000000DC4678: 85049F00
	s_ashr_i32 s0, s0, 2                                       // 000000DC467C: 86008200
	v_or_b32_e32 v3, 0xffffff00, v0                            // 000000DC4680: 380600FF FFFFFF00
	s_add_i32 s0, s0, s4                                       // 000000DC4688: 81000400
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000DC468C: BF8700D9
	s_mul_i32 s4, s0, 0x1400                                   // 000000DC4690: 9604FF00 00001400
	s_mul_hi_i32 s0, s0, 0x1400                                // 000000DC4698: 9700FF00 00001400
	s_add_u32 s4, s20, s4                                      // 000000DC46A0: 80040414
	s_addc_u32 s0, s21, s0                                     // 000000DC46A4: 82000015
	.long 0xd7000401                                           // 000000DC46A8: D7000401
	v_cndmask_b32_e32 v1, s4, v4, vcc_lo                       // 000000DC46AC: 02020804
	v_add_co_ci_u32_e64 v2, null, s0, 0, s4                    // 000000DC46B0: D5207C02 00110000
	s_mov_b32 s4, 0                                            // 000000DC46B8: BE840080
	s_nop 0                                                    // 000000DC46BC: BF800000
	global_load_b128 v[5:8], v[1:2], off                       // 000000DC46C0: DC5E0000 057C0001
	v_add_nc_u32_e32 v3, 0x100, v3                             // 000000DC46C8: 4A0606FF 00000100
	.long 0xd7006a01                                           // 000000DC46D0: D7006A01
	v_cndmask_b32_e32 v1, 0x1000, v1, vcc_lo                   // 000000DC46D4: 020202FF 00001000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DC46DC: BF870191
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 000000DC46E0: D5207C02 01AA0480
	.long 0xd4490000                                           // 000000DC46E8: D4490000
	v_cndmask_b32_e32 v1, 63, v3, vcc_lo                       // 000000DC46EC: 020206BF
	s_or_b32 s4, s0, s4                                        // 000000DC46F0: 8C040400
	s_waitcnt vmcnt(0)                                         // 000000DC46F4: BF8903F7
	ds_store_b128 v4, v[5:8] offset:5120                       // 000000DC46F8: DB7C1400 00000504
	v_add_nc_u32_e32 v4, 0x1000, v4                            // 000000DC4700: 4A0808FF 00001000
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000DC4708: 917E047E
	s_cbranch_execnz 65516                                     // 000000DC470C: BFA6FFEC <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_oILi1EEEvPKhlPKDF16_PKiPfS5_S5_PDF16_PjNS0_5I4rSdEiS7_+0x23c0>
	s_or_b32 exec_lo, exec_lo, s1                              // 000000DC4710: 8C7E017E
	s_mul_i32 s0, s3, 0xffffffec                               // 000000DC4714: 9600FF03 FFFFFFEC
	s_ashr_i32 s11, s10, 31                                    // 000000DC471C: 860B9F0A
	s_add_i32 s0, s0, s2                                       // 000000DC4720: 81000200
	s_lshl_b64 s[2:3], s[10:11], 2                             // 000000DC4724: 8482820A
	v_dual_mov_b32 v68, 0 :: v_dual_and_b32 v69, 3, v0         // 000000DC4728: CA240080 44440083
	s_add_u32 s2, s22, s2                                      // 000000DC4730: 80020216
	s_addc_u32 s3, s23, s3                                     // 000000DC4734: 82030317
	s_waitcnt lgkmcnt(0)                                       // 000000DC4738: BF89FC07
	s_waitcnt_vscnt null, 0x0                                  // 000000DC473C: BC7C0000
	s_barrier                                                  // 000000DC4740: BFBD0000
	buffer_gl0_inv                                             // 000000DC4744: E0AC0000 00000000
	global_load_b32 v1, v68, s[2:3]                            // 000000DC474C: DC520000 01020044
	v_lshrrev_b32_e32 v2, 2, v0                                // 000000DC4754: 32040082
	v_bfe_u32 v3, v0, 2, 3                                     // 000000DC4758: D6100003 020D0500
	s_lshl_b32 s1, s0, 6                                       // 000000DC4760: 84018600
	v_dual_mov_b32 v71, 0 :: v_dual_mov_b32 v72, 0             // 000000DC4764: CA100080 47480080
	s_delay_alu instid0(VALU_DEP_3)                            // 000000DC476C: BF870003
	v_and_b32_e32 v2, 56, v2                                   // 000000DC4770: 360404B8
	v_dual_mov_b32 v73, 0 :: v_dual_lshlrev_b32 v70, 6, v69    // 000000DC4774: CA220080 49468A86
	ds_load_b128 v[34:37], v70 offset:5120                     // 000000DC477C: DBFC1400 22000046
	ds_load_b128 v[78:81], v70 offset:5136                     // 000000DC4784: DBFC1410 4E000046
	ds_load_b128 v[38:41], v70 offset:5376                     // 000000DC478C: DBFC1500 26000046
	ds_load_b128 v[54:57], v70 offset:5392                     // 000000DC4794: DBFC1510 36000046
	v_or3_b32 v62, s1, v2, v3                                  // 000000DC479C: D658003E 040E0401
	v_lshlrev_b32_e32 v3, 4, v69                               // 000000DC47A4: 30068A84
	ds_load_b128 v[58:61], v70 offset:5632                     // 000000DC47A8: DBFC1600 3A000046
	ds_load_b128 v[50:53], v70 offset:5648                     // 000000DC47B0: DBFC1610 32000046
	v_dual_mov_b32 v74, 0 :: v_dual_mov_b32 v75, 0             // 000000DC47B8: CA100080 4A4A0080
	v_ashrrev_i32_e32 v63, 31, v62                             // 000000DC47C0: 347E7C9F
	ds_load_b128 v[90:93], v70 offset:7168                     // 000000DC47C4: DBFC1C00 5A000046
	ds_load_b128 v[94:97], v70 offset:7184                     // 000000DC47CC: DBFC1C10 5E000046
	s_add_u32 s2, s16, s18                                     // 000000DC47D4: 80021210
	s_addc_u32 s3, s17, s19                                    // 000000DC47D8: 82031311
	s_mov_b32 s1, exec_lo                                      // 000000DC47DC: BE81007E
	ds_load_b128 v[98:101], v70 offset:7216                    // 000000DC47E0: DBFC1C30 62000046
	s_waitcnt vmcnt(0)                                         // 000000DC47E8: BF8903F7
	v_mad_i64_i32 v[66:67], null, 0x500, v1, v[62:63]          // 000000DC47EC: D6FF7C42 04FA02FF 00000500
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DC47F8: BF870091
	v_mad_u64_u32 v[1:2], null, 0x500, v66, s[16:17]           // 000000DC47FC: D6FE7C01 004284FF 00000500
	v_mad_i32_i24 v2, 0x500, v67, v2                           // 000000DC4808: D60A0002 040A86FF 00000500
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DC4814: BF870092
	.long 0xd7006a40                                           // 000000DC4818: D7006A40
	v_cndmask_b32_e32 v1, v1, v3, vcc_lo                       // 000000DC481C: 02020701
	v_add_co_ci_u32_e64 v65, null, 0, v2, vcc_lo               // 000000DC4820: D5207C41 01AA0480
	s_clause 0x8                                               // 000000DC4828: BF850008
	global_load_b128 v[30:33], v[64:65], off                   // 000000DC482C: DC5E0000 1E7C0040
	global_load_b128 v[26:29], v[64:65], off offset:64         // 000000DC4834: DC5E0040 1A7C0040
	global_load_b128 v[22:25], v[64:65], off offset:128        // 000000DC483C: DC5E0080 167C0040
	global_load_b128 v[18:21], v[64:65], off offset:192        // 000000DC4844: DC5E00C0 127C0040
	global_load_b128 v[14:17], v[64:65], off offset:256        // 000000DC484C: DC5E0100 0E7C0040
	global_load_b128 v[10:13], v[64:65], off offset:320        // 000000DC4854: DC5E0140 0A7C0040
	global_load_b128 v[6:9], v[64:65], off offset:384          // 000000DC485C: DC5E0180 067C0040
	global_load_b128 v[2:5], v[64:65], off offset:448          // 000000DC4864: DC5E01C0 027C0040
	global_load_b128 v[106:109], v[64:65], off offset:640      // 000000DC486C: DC5E0280 6A7C0040
	s_waitcnt vmcnt(8)                                         // 000000DC4874: BF8923F7
	v_lshrrev_b32_e32 v1, 4, v30                               // 000000DC4878: 32023C84
	s_waitcnt vmcnt(7)                                         // 000000DC487C: BF891FF7
	v_lshrrev_b32_e32 v42, 4, v26                              // 000000DC4880: 32543484
	v_mov_b32_e32 v76, 0                                       // 000000DC4884: 7E980280
	v_and_b32_e32 v30, 0xf0f0f0f, v30                          // 000000DC4888: 363C3CFF 0F0F0F0F
	s_waitcnt vmcnt(6)                                         // 000000DC4890: BF891BF7
	v_lshrrev_b32_e32 v43, 4, v22                              // 000000DC4894: 32562C84
	v_and_b32_e32 v1, 0xf0f0f0f, v1                            // 000000DC4898: 360202FF 0F0F0F0F
	v_and_b32_e32 v26, 0xf0f0f0f, v26                          // 000000DC48A0: 363434FF 0F0F0F0F
	v_and_b32_e32 v42, 0xf0f0f0f, v42                          // 000000DC48A8: 365454FF 0F0F0F0F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DC48B0: BF870214
	v_and_b32_e32 v77, 0xf0f0f0f, v43                          // 000000DC48B4: 369A56FF 0F0F0F0F
	v_perm_b32 v43, v1, v30, 0xc040c00                         // 000000DC48BC: D644002B 03FE3D01 0C040C00
	v_perm_b32 v44, v1, v30, 0xc050c01                         // 000000DC48C8: D644002C 03FE3D01 0C050C01
	v_perm_b32 v45, v1, v30, 0xc060c02                         // 000000DC48D4: D644002D 03FE3D01 0C060C02
	v_perm_b32 v1, v1, v30, 0xc070c03                          // 000000DC48E0: D6440001 03FE3D01 0C070C03
	v_perm_b32 v30, v42, v26, 0xc040c00                        // 000000DC48EC: D644001E 03FE352A 0C040C00
	v_perm_b32 v46, v42, v26, 0xc050c01                        // 000000DC48F8: D644002E 03FE352A 0C050C01
	v_or_b32_e32 v43, 0x64006400, v43                          // 000000DC4904: 385656FF 64006400
	v_perm_b32 v47, v42, v26, 0xc060c02                        // 000000DC490C: D644002F 03FE352A 0C060C02
	v_perm_b32 v26, v42, v26, 0xc070c03                        // 000000DC4918: D644001A 03FE352A 0C070C03
	v_or_b32_e32 v30, 0x64006400, v30                          // 000000DC4924: 383C3CFF 64006400
	v_or_b32_e32 v42, 0x64006400, v44                          // 000000DC492C: 385458FF 64006400
	v_or_b32_e32 v44, 0x64006400, v45                          // 000000DC4934: 38585AFF 64006400
	.long 0xcc0f402b                                           // 000000DC493C: CC0F402B
	v_mul_i32_i24_e32 v1, 0xe408, v43                          // 000000DC4940: 120256FF 0000E408
	v_or_b32_e32 v45, 0x64006400, v46                          // 000000DC4948: 385A5CFF 64006400
	.long 0xcc0f401e                                           // 000000DC4950: CC0F401E
	v_mul_i32_i24_e32 v1, 0xe408, v30                          // 000000DC4954: 12023CFF 0000E408
	.long 0xcc0f402a                                           // 000000DC495C: CC0F402A
	v_mul_i32_i24_e32 v1, 0xe408, v42                          // 000000DC4960: 120254FF 0000E408
	v_or_b32_e32 v1, 0x64006400, v1                            // 000000DC4968: 380202FF 64006400
	v_or_b32_e32 v26, 0x64006400, v26                          // 000000DC4970: 383434FF 64006400
	s_waitcnt lgkmcnt(6)                                       // 000000DC4978: BF89FC67
	v_dot2acc_f32_f16 v72, v30, v38                            // 000000DC497C: 04904D1E
	v_dot2acc_f32_f16 v71, v43, v34                            // 000000DC4980: 048E452B
	.long 0xcc0f402b                                           // 000000DC4984: CC0F402B
	v_mul_i32_i24_e32 v1, 0xe408, v44                          // 000000DC4988: 120258FF 0000E408
	.long 0xcc0f402c                                           // 000000DC4990: CC0F402C
	v_mul_i32_i24_e32 v1, 0xe408, v45                          // 000000DC4994: 12025AFF 0000E408
	v_or_b32_e32 v34, 0x64006400, v47                          // 000000DC499C: 38445EFF 64006400
	.long 0xcc0f4001                                           // 000000DC49A4: CC0F4001
	v_mul_i32_i24_e32 v1, 0xe408, v1                           // 000000DC49A8: 120202FF 0000E408
	.long 0xcc0f401a                                           // 000000DC49B0: CC0F401A
	v_mul_i32_i24_e32 v1, 0xe408, v26                          // 000000DC49B4: 120234FF 0000E408
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000DC49BC: BF870134
	v_dot2acc_f32_f16 v72, v44, v39                            // 000000DC49C0: 04904F2C
	v_dot2acc_f32_f16 v71, v42, v35                            // 000000DC49C4: 048E472A
	.long 0xcc0f401e                                           // 000000DC49C8: CC0F401E
	v_mul_i32_i24_e32 v1, 0xe408, v34                          // 000000DC49CC: 120244FF 0000E408
	v_dual_dot2acc_f32_f16 v71, v43, v36 :: v_dual_and_b32 v22, 0xf0f0f0f, v22// 000000DC49D4: CB24492B 47162CFF 0F0F0F0F
	ds_load_b128 v[82:85], v70 offset:5888                     // 000000DC49E0: DBFC1700 52000046
	ds_load_b128 v[42:45], v70 offset:5904                     // 000000DC49E8: DBFC1710 2A000046
	v_dot2acc_f32_f16 v71, v1, v37                             // 000000DC49F0: 048E4B01
	v_perm_b32 v86, v77, v22, 0xc040c00                        // 000000DC49F4: D6440056 03FE2D4D 0C040C00
	s_waitcnt vmcnt(5)                                         // 000000DC4A00: BF8917F7
	v_lshrrev_b32_e32 v1, 4, v18                               // 000000DC4A04: 32022484
	v_dot2acc_f32_f16 v72, v30, v40                            // 000000DC4A08: 0490511E
	v_perm_b32 v30, v77, v22, 0xc050c01                        // 000000DC4A0C: D644001E 03FE2D4D 0C050C01
	ds_load_b128 v[34:37], v70 offset:6144                     // 000000DC4A18: DBFC1800 22000046
	ds_load_b128 v[46:49], v70 offset:6160                     // 000000DC4A20: DBFC1810 2E000046
	v_and_b32_e32 v1, 0xf0f0f0f, v1                            // 000000DC4A28: 360202FF 0F0F0F0F
	v_dot2acc_f32_f16 v72, v26, v41                            // 000000DC4A30: 0490531A
	v_or_b32_e32 v26, 0x64006400, v86                          // 000000DC4A34: 3834ACFF 64006400
	v_perm_b32 v86, v77, v22, 0xc060c02                        // 000000DC4A3C: D6440056 03FE2D4D 0C060C02
	v_perm_b32 v22, v77, v22, 0xc070c03                        // 000000DC4A48: D6440016 03FE2D4D 0C070C03
	v_or_b32_e32 v30, 0x64006400, v30                          // 000000DC4A54: 383C3CFF 64006400
	ds_load_b128 v[38:41], v70 offset:6400                     // 000000DC4A5C: DBFC1900 26000046
	.long 0xcc0f401a                                           // 000000DC4A64: CC0F401A
	v_mul_i32_i24_e32 v1, 0xe408, v26                          // 000000DC4A68: 120234FF 0000E408
	v_or_b32_e32 v22, 0x64006400, v22                          // 000000DC4A70: 382C2CFF 64006400
	.long 0xcc0f401e                                           // 000000DC4A78: CC0F401E
	v_mul_i32_i24_e32 v1, 0xe408, v30                          // 000000DC4A7C: 12023CFF 0000E408
	s_waitcnt lgkmcnt(9)                                       // 000000DC4A84: BF89FC97
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DC4A88: BF870193
	v_dot2acc_f32_f16 v73, v26, v58                            // 000000DC4A8C: 0492751A
	.long 0xcc0f4016                                           // 000000DC4A90: CC0F4016
	v_mul_i32_i24_e32 v1, 0xe408, v22                          // 000000DC4A94: 12022CFF 0000E408
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DC4A9C: BF870092
	v_dual_dot2acc_f32_f16 v73, v30, v59 :: v_dual_and_b32 v18, 0xf0f0f0f, v18// 000000DC4AA0: CB24771E 491224FF 0F0F0F0F
	v_perm_b32 v77, v1, v18, 0xc040c00                         // 000000DC4AAC: D644004D 03FE2501 0C040C00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000DC4AB8: BF870121
	v_or_b32_e32 v58, 0x64006400, v77                          // 000000DC4ABC: 38749AFF 64006400
	v_or_b32_e32 v77, 0x64006400, v86                          // 000000DC4AC4: 389AACFF 64006400
	.long 0xcc0f403a                                           // 000000DC4ACC: CC0F403A
	v_mul_i32_i24_e32 v1, 0xe408, v58                          // 000000DC4AD0: 120274FF 0000E408
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DC4AD8: BF8700A2
	.long 0xcc0f404d                                           // 000000DC4ADC: CC0F404D
	v_mul_i32_i24_e32 v1, 0xe408, v77                          // 000000DC4AE0: 12029AFF 0000E408
	s_waitcnt lgkmcnt(4)                                       // 000000DC4AE8: BF89FC47
	v_dual_dot2acc_f32_f16 v74, v58, v82 :: v_dual_dot2acc_f32_f16 v73, v77, v60// 000000DC4AEC: CB18A53A 4A48794D
	s_waitcnt vmcnt(3)                                         // 000000DC4AF4: BF890FF7
	v_lshrrev_b32_e32 v58, 4, v10                              // 000000DC4AF8: 32741484
	s_delay_alu instid0(VALU_DEP_2)                            // 000000DC4AFC: BF870002
	v_dot2acc_f32_f16 v73, v22, v61                            // 000000DC4B00: 04927B16
	v_perm_b32 v87, v1, v18, 0xc050c01                         // 000000DC4B04: D6440057 03FE2501 0C050C01
	v_perm_b32 v26, v1, v18, 0xc060c02                         // 000000DC4B10: D644001A 03FE2501 0C060C02
	v_perm_b32 v1, v1, v18, 0xc070c03                          // 000000DC4B1C: D6440001 03FE2501 0C070C03
	v_and_b32_e32 v18, 0xf0f0f0f, v14                          // 000000DC4B28: 36241CFF 0F0F0F0F
	v_lshrrev_b32_e32 v14, 4, v14                              // 000000DC4B30: 321C1C84
	v_or_b32_e32 v30, 0x64006400, v87                          // 000000DC4B34: 383CAEFF 64006400
	v_or_b32_e32 v26, 0x64006400, v26                          // 000000DC4B3C: 383434FF 64006400
	v_or_b32_e32 v1, 0x64006400, v1                            // 000000DC4B44: 380202FF 64006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DC4B4C: BF870214
	v_and_b32_e32 v14, 0xf0f0f0f, v14                          // 000000DC4B50: 361C1CFF 0F0F0F0F
	.long 0xcc0f401e                                           // 000000DC4B58: CC0F401E
	v_mul_i32_i24_e32 v1, 0xe408, v30                          // 000000DC4B5C: 12023CFF 0000E408
	v_and_b32_e32 v77, 0xf0f0f0f, v58                          // 000000DC4B64: 369A74FF 0F0F0F0F
	ds_load_b128 v[58:61], v70 offset:6416                     // 000000DC4B6C: DBFC1910 3A000046
	.long 0xcc0f401a                                           // 000000DC4B74: CC0F401A
	v_mul_i32_i24_e32 v1, 0xe408, v26                          // 000000DC4B78: 120234FF 0000E408
	v_perm_b32 v22, v14, v18, 0xc050c01                        // 000000DC4B80: D6440016 03FE250E 0C050C01
	v_dot2acc_f32_f16 v74, v30, v83                            // 000000DC4B8C: 0494A71E
	v_perm_b32 v30, v14, v18, 0xc040c00                        // 000000DC4B90: D644001E 03FE250E 0C040C00
	v_perm_b32 v86, v14, v18, 0xc060c02                        // 000000DC4B9C: D6440056 03FE250E 0C060C02
	v_perm_b32 v14, v14, v18, 0xc070c03                        // 000000DC4BA8: D644000E 03FE250E 0C070C03
	v_or_b32_e32 v22, 0x64006400, v22                          // 000000DC4BB4: 382C2CFF 64006400
	.long 0xcc0f4001                                           // 000000DC4BBC: CC0F4001
	v_mul_i32_i24_e32 v1, 0xe408, v1                           // 000000DC4BC0: 120202FF 0000E408
	v_or_b32_e32 v18, 0x64006400, v30                          // 000000DC4BC8: 38243CFF 64006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DC4BD0: BF870214
	v_or_b32_e32 v14, 0x64006400, v14                          // 000000DC4BD4: 381C1CFF 64006400
	.long 0xcc0f4016                                           // 000000DC4BDC: CC0F4016
	v_mul_i32_i24_e32 v1, 0xe408, v22                          // 000000DC4BE0: 12022CFF 0000E408
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DC4BE8: BF870193
	.long 0xcc0f4012                                           // 000000DC4BEC: CC0F4012
	v_mul_i32_i24_e32 v1, 0xe408, v18                          // 000000DC4BF0: 120224FF 0000E408
	.long 0xcc0f400e                                           // 000000DC4BF8: CC0F400E
	v_mul_i32_i24_e32 v1, 0xe408, v14                          // 000000DC4BFC: 12021CFF 0000E408
	s_waitcnt lgkmcnt(3)                                       // 000000DC4C04: BF89FC37
	s_delay_alu instid0(VALU_DEP_2)                            // 000000DC4C08: BF870002
	v_dot2acc_f32_f16 v75, v18, v34                            // 000000DC4C0C: 04964512
	s_waitcnt vmcnt(2)                                         // 000000DC4C10: BF890BF7
	v_and_b32_e32 v18, 0xf0f0f0f, v6                           // 000000DC4C14: 36240CFF 0F0F0F0F
	v_lshrrev_b32_e32 v6, 4, v6                                // 000000DC4C1C: 320C0C84
	v_dot2acc_f32_f16 v74, v26, v84                            // 000000DC4C20: 0494A91A
	v_dual_dot2acc_f32_f16 v75, v22, v35 :: v_dual_and_b32 v10, 0xf0f0f0f, v10// 000000DC4C24: CB244716 4B0A14FF 0F0F0F0F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DC4C30: BF870112
	v_dot2acc_f32_f16 v74, v1, v85                             // 000000DC4C34: 0494AB01
	v_perm_b32 v82, v77, v10, 0xc040c00                        // 000000DC4C38: D6440052 03FE154D 0C040C00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000DC4C44: BF8700C1
	v_or_b32_e32 v26, 0x64006400, v82                          // 000000DC4C48: 3834A4FF 64006400
	ds_load_b128 v[82:85], v70 offset:6656                     // 000000DC4C50: DBFC1A00 52000046
	.long 0xcc0f401a                                           // 000000DC4C58: CC0F401A
	v_mul_i32_i24_e32 v1, 0xe408, v26                          // 000000DC4C5C: 120234FF 0000E408
	s_waitcnt lgkmcnt(2)                                       // 000000DC4C64: BF89FC27
	v_dot2acc_f32_f16 v76, v26, v38                            // 000000DC4C68: 04984D1A
	v_or_b32_e32 v26, 0x64006400, v86                          // 000000DC4C6C: 3834ACFF 64006400
	ds_load_b128 v[86:89], v70 offset:6672                     // 000000DC4C74: DBFC1A10 56000046
	.long 0xcc0f401a                                           // 000000DC4C7C: CC0F401A
	v_mul_i32_i24_e32 v1, 0xe408, v26                          // 000000DC4C80: 120234FF 0000E408
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DC4C88: BF870001
	v_dot2acc_f32_f16 v75, v26, v36                            // 000000DC4C8C: 0496491A
	v_perm_b32 v1, v77, v10, 0xc050c01                         // 000000DC4C90: D6440001 03FE154D 0C050C01
	v_perm_b32 v30, v77, v10, 0xc060c02                        // 000000DC4C9C: D644001E 03FE154D 0C060C02
	v_perm_b32 v10, v77, v10, 0xc070c03                        // 000000DC4CA8: D644000A 03FE154D 0C070C03
	v_mov_b32_e32 v77, 0                                       // 000000DC4CB4: 7E9A0280
	v_dot2acc_f32_f16 v75, v14, v37                            // 000000DC4CB8: 04964B0E
	v_or_b32_e32 v1, 0x64006400, v1                            // 000000DC4CBC: 380202FF 64006400
	v_or_b32_e32 v30, 0x64006400, v30                          // 000000DC4CC4: 383C3CFF 64006400
	v_or_b32_e32 v10, 0x64006400, v10                          // 000000DC4CCC: 381414FF 64006400
	ds_load_b128 v[34:37], v70 offset:6912                     // 000000DC4CD4: DBFC1B00 22000046
	.long 0xcc0f4001                                           // 000000DC4CDC: CC0F4001
	v_mul_i32_i24_e32 v1, 0xe408, v1                           // 000000DC4CE0: 120202FF 0000E408
	.long 0xcc0f4016                                           // 000000DC4CE8: CC0F4016
	v_mul_i32_i24_e32 v1, 0xe408, v30                          // 000000DC4CEC: 12023CFF 0000E408
	.long 0xcc0f400a                                           // 000000DC4CF4: CC0F400A
	v_mul_i32_i24_e32 v1, 0xe408, v10                          // 000000DC4CF8: 120214FF 0000E408
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000DC4D00: BF870123
	v_dual_dot2acc_f32_f16 v76, v1, v39 :: v_dual_and_b32 v1, 0xf0f0f0f, v6// 000000DC4D04: CB244F01 4C000CFF 0F0F0F0F
	v_mov_b32_e32 v6, 0                                        // 000000DC4D10: 7E0C0280
	v_dot2acc_f32_f16 v76, v22, v40                            // 000000DC4D14: 04985116
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000DC4D18: BF8701A3
	v_perm_b32 v22, v1, v18, 0xc040c00                         // 000000DC4D1C: D6440016 03FE2501 0C040C00
	v_perm_b32 v26, v1, v18, 0xc060c02                         // 000000DC4D28: D644001A 03FE2501 0C060C02
	v_dot2acc_f32_f16 v76, v10, v41                            // 000000DC4D34: 0498530A
	global_load_b128 v[38:41], v[64:65], off offset:512        // 000000DC4D38: DC5E0200 267C0040
	v_perm_b32 v10, v1, v18, 0xc050c01                         // 000000DC4D40: D644000A 03FE2501 0C050C01
	v_or_b32_e32 v14, 0x64006400, v22                          // 000000DC4D4C: 381C2CFF 64006400
	s_waitcnt vmcnt(2)                                         // 000000DC4D54: BF890BF7
	v_lshrrev_b32_e32 v22, 4, v2                               // 000000DC4D58: 322C0484
	v_and_b32_e32 v2, 0xf0f0f0f, v2                            // 000000DC4D5C: 360404FF 0F0F0F0F
	v_perm_b32 v1, v1, v18, 0xc070c03                          // 000000DC4D64: D6440001 03FE2501 0C070C03
	v_or_b32_e32 v10, 0x64006400, v10                          // 000000DC4D70: 381414FF 64006400
	.long 0xcc0f400e                                           // 000000DC4D78: CC0F400E
	v_mul_i32_i24_e32 v1, 0xe408, v14                          // 000000DC4D7C: 12021CFF 0000E408
	v_and_b32_e32 v22, 0xf0f0f0f, v22                          // 000000DC4D84: 362C2CFF 0F0F0F0F
	v_or_b32_e32 v18, 0x64006400, v26                          // 000000DC4D8C: 382434FF 64006400
	v_or_b32_e32 v1, 0x64006400, v1                            // 000000DC4D94: 380202FF 64006400
	.long 0xcc0f400a                                           // 000000DC4D9C: CC0F400A
	v_mul_i32_i24_e32 v1, 0xe408, v10                          // 000000DC4DA0: 120214FF 0000E408
	s_waitcnt lgkmcnt(2)                                       // 000000DC4DA8: BF89FC27
	v_dot2acc_f32_f16 v6, v14, v82                             // 000000DC4DAC: 040CA50E
	v_perm_b32 v14, v22, v2, 0xc040c00                         // 000000DC4DB0: D644000E 03FE0516 0C040C00
	.long 0xcc0f4012                                           // 000000DC4DBC: CC0F4012
	v_mul_i32_i24_e32 v1, 0xe408, v18                          // 000000DC4DC0: 120224FF 0000E408
	v_perm_b32 v26, v22, v2, 0xc050c01                         // 000000DC4DC8: D644001A 03FE0516 0C050C01
	.long 0xcc0f4001                                           // 000000DC4DD4: CC0F4001
	v_mul_i32_i24_e32 v1, 0xe408, v1                           // 000000DC4DD8: 120202FF 0000E408
	v_dot2acc_f32_f16 v6, v10, v83                             // 000000DC4DE0: 040CA70A
	v_or_b32_e32 v14, 0x64006400, v14                          // 000000DC4DE4: 381C1CFF 64006400
	v_mov_b32_e32 v10, 0                                       // 000000DC4DEC: 7E140280
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000DC4DF0: BF870223
	v_dot2acc_f32_f16 v6, v18, v84                             // 000000DC4DF4: 040CA912
	v_or_b32_e32 v18, 0x64006400, v26                          // 000000DC4DF8: 382434FF 64006400
	.long 0xcc0f400e                                           // 000000DC4E00: CC0F400E
	v_mul_i32_i24_e32 v1, 0xe408, v14                          // 000000DC4E04: 12021CFF 0000E408
	s_delay_alu instid0(VALU_DEP_3)                            // 000000DC4E0C: BF870003
	v_dot2acc_f32_f16 v6, v1, v85                              // 000000DC4E10: 040CAB01
	ds_load_b128 v[82:85], v70 offset:6928                     // 000000DC4E14: DBFC1B10 52000046
	.long 0xcc0f4001                                           // 000000DC4E1C: CC0F4001
	v_mul_i32_i24_e32 v1, 0xe408, v18                          // 000000DC4E20: 120224FF 0000E408
	s_waitcnt lgkmcnt(1)                                       // 000000DC4E28: BF89FC17
	v_dot2acc_f32_f16 v10, v14, v34                            // 000000DC4E2C: 0414450E
	v_perm_b32 v14, v22, v2, 0xc060c02                         // 000000DC4E30: D644000E 03FE0516 0C060C02
	v_perm_b32 v2, v22, v2, 0xc070c03                          // 000000DC4E3C: D6440002 03FE0516 0C070C03
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DC4E48: BF870193
	v_dot2acc_f32_f16 v10, v1, v35                             // 000000DC4E4C: 04144701
	v_or_b32_e32 v1, 0x64006400, v14                           // 000000DC4E50: 38021CFF 64006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DC4E58: BF870113
	v_or_b32_e32 v2, 0x64006400, v2                            // 000000DC4E5C: 380404FF 64006400
	.long 0xcc0f4001                                           // 000000DC4E64: CC0F4001
	v_mul_i32_i24_e32 v1, 0xe408, v1                           // 000000DC4E68: 120202FF 0000E408
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DC4E70: BF870112
	.long 0xcc0f4002                                           // 000000DC4E74: CC0F4002
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000DC4E78: 120204FF 0000E408
	v_dot2acc_f32_f16 v10, v1, v36                             // 000000DC4E80: 04144901
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 000000DC4E84: BF870151
	v_dot2acc_f32_f16 v10, v2, v37                             // 000000DC4E88: 04144B02
	global_load_b128 v[34:37], v[64:65], off offset:576        // 000000DC4E8C: DC5E0240 227C0040
	s_waitcnt vmcnt(1)                                         // 000000DC4E94: BF8907F7
	v_lshrrev_b32_e32 v1, 4, v38                               // 000000DC4E98: 32024C84
	v_and_b32_e32 v2, 0xf0f0f0f, v38                           // 000000DC4E9C: 36044CFF 0F0F0F0F
	v_and_b32_e32 v1, 0xf0f0f0f, v1                            // 000000DC4EA4: 360202FF 0F0F0F0F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000DC4EAC: BF870241
	v_perm_b32 v14, v1, v2, 0xc040c00                          // 000000DC4EB0: D644000E 03FE0501 0C040C00
	v_perm_b32 v18, v1, v2, 0xc050c01                          // 000000DC4EBC: D6440012 03FE0501 0C050C01
	v_perm_b32 v22, v1, v2, 0xc060c02                          // 000000DC4EC8: D6440016 03FE0501 0C060C02
	v_perm_b32 v1, v1, v2, 0xc070c03                           // 000000DC4ED4: D6440001 03FE0501 0C070C03
	v_or_b32_e32 v2, 0x64006400, v14                           // 000000DC4EE0: 38041CFF 64006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DC4EE8: BF870112
	v_or_b32_e32 v1, 0x64006400, v1                            // 000000DC4EEC: 380202FF 64006400
	.long 0xcc0f4002                                           // 000000DC4EF4: CC0F4002
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000DC4EF8: 120204FF 0000E408
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DC4F00: BF870112
	.long 0xcc0f4001                                           // 000000DC4F04: CC0F4001
	v_mul_i32_i24_e32 v1, 0xe408, v1                           // 000000DC4F08: 120202FF 0000E408
	v_dot2acc_f32_f16 v77, v2, v90                             // 000000DC4F10: 049AB502
	v_or_b32_e32 v2, 0x64006400, v18                           // 000000DC4F14: 380424FF 64006400
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DC4F1C: BF870091
	.long 0xcc0f4002                                           // 000000DC4F20: CC0F4002
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000DC4F24: 120204FF 0000E408
	v_dot2acc_f32_f16 v77, v2, v91                             // 000000DC4F2C: 049AB702
	v_or_b32_e32 v2, 0x64006400, v22                           // 000000DC4F30: 38042CFF 64006400
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DC4F38: BF870091
	.long 0xcc0f4002                                           // 000000DC4F3C: CC0F4002
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000DC4F40: 120204FF 0000E408
	v_dual_dot2acc_f32_f16 v77, v2, v92 :: v_dual_and_b32 v2, 0xf0f0f0f, v31// 000000DC4F48: CB24B902 4D023EFF 0F0F0F0F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000DC4F54: BF8700C1
	v_dot2acc_f32_f16 v77, v1, v93                             // 000000DC4F58: 049ABB01
	v_lshrrev_b32_e32 v1, 4, v31                               // 000000DC4F5C: 32023E84
	ds_load_b128 v[90:93], v70 offset:6448                     // 000000DC4F60: DBFC1930 5A000046
	v_and_b32_e32 v1, 0xf0f0f0f, v1                            // 000000DC4F68: 360202FF 0F0F0F0F
	v_perm_b32 v14, v1, v2, 0xc040c00                          // 000000DC4F70: D644000E 03FE0501 0C040C00
	v_perm_b32 v18, v1, v2, 0xc050c01                          // 000000DC4F7C: D6440012 03FE0501 0C050C01
	v_perm_b32 v22, v1, v2, 0xc060c02                          // 000000DC4F88: D6440016 03FE0501 0C060C02
	v_perm_b32 v1, v1, v2, 0xc070c03                           // 000000DC4F94: D6440001 03FE0501 0C070C03
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DC4FA0: BF870114
	v_or_b32_e32 v2, 0x64006400, v14                           // 000000DC4FA4: 38041CFF 64006400
	v_or_b32_e32 v1, 0x64006400, v1                            // 000000DC4FAC: 380202FF 64006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DC4FB4: BF870112
	.long 0xcc0f4002                                           // 000000DC4FB8: CC0F4002
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000DC4FBC: 120204FF 0000E408
	.long 0xcc0f4001                                           // 000000DC4FC4: CC0F4001
	v_mul_i32_i24_e32 v1, 0xe408, v1                           // 000000DC4FC8: 120202FF 0000E408
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DC4FD0: BF8700A2
	v_dot2acc_f32_f16 v71, v2, v78                             // 000000DC4FD4: 048E9D02
	v_or_b32_e32 v2, 0x64006400, v18                           // 000000DC4FD8: 380424FF 64006400
	.long 0xcc0f4002                                           // 000000DC4FE0: CC0F4002
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000DC4FE4: 120204FF 0000E408
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DC4FEC: BF8700A1
	v_dot2acc_f32_f16 v71, v2, v79                             // 000000DC4FF0: 048E9F02
	v_or_b32_e32 v2, 0x64006400, v22                           // 000000DC4FF4: 38042CFF 64006400
	.long 0xcc0f4002                                           // 000000DC4FFC: CC0F4002
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000DC5000: 120204FF 0000E408
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DC5008: BF870091
	v_dual_dot2acc_f32_f16 v71, v2, v80 :: v_dual_and_b32 v2, 0xf0f0f0f, v27// 000000DC500C: CB24A102 470236FF 0F0F0F0F
	v_dot2acc_f32_f16 v71, v1, v81                             // 000000DC5018: 048EA301
	v_lshrrev_b32_e32 v1, 4, v27                               // 000000DC501C: 32023684
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DC5020: BF870091
	v_and_b32_e32 v1, 0xf0f0f0f, v1                            // 000000DC5024: 360202FF 0F0F0F0F
	v_perm_b32 v14, v1, v2, 0xc040c00                          // 000000DC502C: D644000E 03FE0501 0C040C00
	v_perm_b32 v18, v1, v2, 0xc050c01                          // 000000DC5038: D6440012 03FE0501 0C050C01
	v_perm_b32 v22, v1, v2, 0xc060c02                          // 000000DC5044: D6440016 03FE0501 0C060C02
	v_perm_b32 v1, v1, v2, 0xc070c03                           // 000000DC5050: D6440001 03FE0501 0C070C03
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DC505C: BF870114
	v_or_b32_e32 v2, 0x64006400, v14                           // 000000DC5060: 38041CFF 64006400
	v_or_b32_e32 v1, 0x64006400, v1                            // 000000DC5068: 380202FF 64006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DC5070: BF870112
	.long 0xcc0f4002                                           // 000000DC5074: CC0F4002
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000DC5078: 120204FF 0000E408
	.long 0xcc0f4001                                           // 000000DC5080: CC0F4001
	v_mul_i32_i24_e32 v1, 0xe408, v1                           // 000000DC5084: 120202FF 0000E408
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DC508C: BF8700A2
	v_dot2acc_f32_f16 v72, v2, v54                             // 000000DC5090: 04906D02
	v_or_b32_e32 v2, 0x64006400, v18                           // 000000DC5094: 380424FF 64006400
	.long 0xcc0f4002                                           // 000000DC509C: CC0F4002
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000DC50A0: 120204FF 0000E408
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DC50A8: BF8700A1
	v_dot2acc_f32_f16 v72, v2, v55                             // 000000DC50AC: 04906F02
	v_or_b32_e32 v2, 0x64006400, v22                           // 000000DC50B0: 38042CFF 64006400
	.long 0xcc0f4002                                           // 000000DC50B8: CC0F4002
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000DC50BC: 120204FF 0000E408
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000DC50C4: BF870121
	v_dot2acc_f32_f16 v72, v2, v56                             // 000000DC50C8: 04907102
	v_and_b32_e32 v2, 0xf0f0f0f, v23                           // 000000DC50CC: 36042EFF 0F0F0F0F
	v_dot2acc_f32_f16 v72, v1, v57                             // 000000DC50D4: 04907301
	v_lshrrev_b32_e32 v1, 4, v23                               // 000000DC50D8: 32022E84
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DC50DC: BF870091
	v_and_b32_e32 v1, 0xf0f0f0f, v1                            // 000000DC50E0: 360202FF 0F0F0F0F
	v_perm_b32 v14, v1, v2, 0xc040c00                          // 000000DC50E8: D644000E 03FE0501 0C040C00
	v_perm_b32 v18, v1, v2, 0xc050c01                          // 000000DC50F4: D6440012 03FE0501 0C050C01
	v_perm_b32 v22, v1, v2, 0xc060c02                          // 000000DC5100: D6440016 03FE0501 0C060C02
	v_perm_b32 v1, v1, v2, 0xc070c03                           // 000000DC510C: D6440001 03FE0501 0C070C03
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DC5118: BF870214
	v_or_b32_e32 v14, 0x64006400, v14                          // 000000DC511C: 381C1CFF 64006400
	v_or_b32_e32 v18, 0x64006400, v18                          // 000000DC5124: 382424FF 64006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DC512C: BF870214
	v_or_b32_e32 v2, 0x64006400, v22                           // 000000DC5130: 38042CFF 64006400
	v_or_b32_e32 v1, 0x64006400, v1                            // 000000DC5138: 380202FF 64006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DC5140: BF870214
	.long 0xcc0f400e                                           // 000000DC5144: CC0F400E
	v_mul_i32_i24_e32 v1, 0xe408, v14                          // 000000DC5148: 12021CFF 0000E408
	.long 0xcc0f4012                                           // 000000DC5150: CC0F4012
	v_mul_i32_i24_e32 v1, 0xe408, v18                          // 000000DC5154: 120224FF 0000E408
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DC515C: BF870214
	.long 0xcc0f4002                                           // 000000DC5160: CC0F4002
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000DC5164: 120204FF 0000E408
	.long 0xcc0f4001                                           // 000000DC516C: CC0F4001
	v_mul_i32_i24_e32 v1, 0xe408, v1                           // 000000DC5170: 120202FF 0000E408
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000DC5178: BF870124
	v_dot2acc_f32_f16 v73, v14, v50                            // 000000DC517C: 0492650E
	v_lshrrev_b32_e32 v14, 4, v19                              // 000000DC5180: 321C2684
	v_dot2acc_f32_f16 v73, v18, v51                            // 000000DC5184: 04926712
	v_and_b32_e32 v18, 0xf0f0f0f, v19                          // 000000DC5188: 362426FF 0F0F0F0F
	v_lshrrev_b32_e32 v19, 4, v15                              // 000000DC5190: 32261E84
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000DC5194: BF8701A3
	v_dual_dot2acc_f32_f16 v73, v2, v52 :: v_dual_and_b32 v2, 0xf0f0f0f, v14// 000000DC5198: CB246902 49021CFF 0F0F0F0F
	v_and_b32_e32 v14, 0xf0f0f0f, v15                          // 000000DC51A4: 361C1EFF 0F0F0F0F
	v_and_b32_e32 v15, 0xf0f0f0f, v19                          // 000000DC51AC: 361E26FF 0F0F0F0F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DC51B4: BF870213
	v_dot2acc_f32_f16 v73, v1, v53                             // 000000DC51B8: 04926B01
	v_perm_b32 v1, v2, v18, 0xc040c00                          // 000000DC51BC: D6440001 03FE2502 0C040C00
	v_perm_b32 v19, v2, v18, 0xc050c01                         // 000000DC51C8: D6440013 03FE2502 0C050C01
	v_perm_b32 v22, v2, v18, 0xc060c02                         // 000000DC51D4: D6440016 03FE2502 0C060C02
	v_perm_b32 v2, v2, v18, 0xc070c03                          // 000000DC51E0: D6440002 03FE2502 0C070C03
	v_perm_b32 v18, v15, v14, 0xc040c00                        // 000000DC51EC: D6440012 03FE1D0F 0C040C00
	v_or_b32_e32 v1, 0x64006400, v1                            // 000000DC51F8: 380202FF 64006400
	v_perm_b32 v23, v15, v14, 0xc050c01                        // 000000DC5200: D6440017 03FE1D0F 0C050C01
	v_perm_b32 v26, v15, v14, 0xc060c02                        // 000000DC520C: D644001A 03FE1D0F 0C060C02
	v_perm_b32 v14, v15, v14, 0xc070c03                        // 000000DC5218: D644000E 03FE1D0F 0C070C03
	v_lshrrev_b32_e32 v15, 4, v11                              // 000000DC5224: 321E1684
	.long 0xcc0f4001                                           // 000000DC5228: CC0F4001
	v_mul_i32_i24_e32 v1, 0xe408, v1                           // 000000DC522C: 120202FF 0000E408
	v_and_b32_e32 v11, 0xf0f0f0f, v11                          // 000000DC5234: 361616FF 0F0F0F0F
	v_or_b32_e32 v2, 0x64006400, v2                            // 000000DC523C: 380404FF 64006400
	v_or_b32_e32 v14, 0x64006400, v14                          // 000000DC5244: 381C1CFF 64006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000DC524C: BF870234
	v_dual_dot2acc_f32_f16 v74, v1, v42 :: v_dual_and_b32 v15, 0xf0f0f0f, v15// 000000DC5250: CB245501 4A0E1EFF 0F0F0F0F
	v_or_b32_e32 v1, 0x64006400, v18                           // 000000DC525C: 380224FF 64006400
	v_or_b32_e32 v18, 0x64006400, v26                          // 000000DC5264: 382434FF 64006400
	.long 0xcc0f400e                                           // 000000DC526C: CC0F400E
	v_mul_i32_i24_e32 v1, 0xe408, v14                          // 000000DC5270: 12021CFF 0000E408
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DC5278: BF870004
	v_perm_b32 v27, v15, v11, 0xc040c00                        // 000000DC527C: D644001B 03FE170F 0C040C00
	v_perm_b32 v30, v15, v11, 0xc050c01                        // 000000DC5288: D644001E 03FE170F 0C050C01
	v_perm_b32 v31, v15, v11, 0xc060c02                        // 000000DC5294: D644001F 03FE170F 0C060C02
	v_perm_b32 v11, v15, v11, 0xc070c03                        // 000000DC52A0: D644000B 03FE170F 0C070C03
	v_lshrrev_b32_e32 v15, 4, v7                               // 000000DC52AC: 321E0E84
	.long 0xcc0f4001                                           // 000000DC52B0: CC0F4001
	v_mul_i32_i24_e32 v1, 0xe408, v1                           // 000000DC52B4: 120202FF 0000E408
	v_and_b32_e32 v7, 0xf0f0f0f, v7                            // 000000DC52BC: 360E0EFF 0F0F0F0F
	.long 0xcc0f4012                                           // 000000DC52C4: CC0F4012
	v_mul_i32_i24_e32 v1, 0xe408, v18                          // 000000DC52C8: 120224FF 0000E408
	.long 0xcc0f4002                                           // 000000DC52D0: CC0F4002
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000DC52D4: 120204FF 0000E408
	v_and_b32_e32 v15, 0xf0f0f0f, v15                          // 000000DC52DC: 361E1EFF 0F0F0F0F
	v_dot2acc_f32_f16 v75, v1, v46                             // 000000DC52E4: 04965D01
	v_or_b32_e32 v1, 0x64006400, v27                           // 000000DC52E8: 380236FF 64006400
	v_or_b32_e32 v11, 0x64006400, v11                          // 000000DC52F0: 381616FF 64006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000DC52F8: BF870224
	v_perm_b32 v38, v15, v7, 0xc040c00                         // 000000DC52FC: D6440026 03FE0F0F 0C040C00
	v_perm_b32 v50, v15, v7, 0xc050c01                         // 000000DC5308: D6440032 03FE0F0F 0C050C01
	.long 0xcc0f4001                                           // 000000DC5314: CC0F4001
	v_mul_i32_i24_e32 v1, 0xe408, v1                           // 000000DC5318: 120202FF 0000E408
	v_perm_b32 v51, v15, v7, 0xc060c02                         // 000000DC5320: D6440033 03FE0F0F 0C060C02
	v_perm_b32 v7, v15, v7, 0xc070c03                          // 000000DC532C: D6440007 03FE0F0F 0C070C03
	v_or_b32_e32 v15, 0x64006400, v22                          // 000000DC5338: 381E2CFF 64006400
	.long 0xcc0f400b                                           // 000000DC5340: CC0F400B
	v_mul_i32_i24_e32 v1, 0xe408, v11                          // 000000DC5344: 120216FF 0000E408
	v_dot2acc_f32_f16 v76, v1, v58                             // 000000DC534C: 04987501
	v_or_b32_e32 v1, 0x64006400, v38                           // 000000DC5350: 38024CFF 64006400
	v_or_b32_e32 v7, 0x64006400, v7                            // 000000DC5358: 380E0EFF 64006400
	.long 0xcc0f400f                                           // 000000DC5360: CC0F400F
	v_mul_i32_i24_e32 v1, 0xe408, v15                          // 000000DC5364: 12021EFF 0000E408
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DC536C: BF870193
	.long 0xcc0f4001                                           // 000000DC5370: CC0F4001
	v_mul_i32_i24_e32 v1, 0xe408, v1                           // 000000DC5374: 120202FF 0000E408
	.long 0xcc0f4007                                           // 000000DC537C: CC0F4007
	v_mul_i32_i24_e32 v1, 0xe408, v7                           // 000000DC5380: 12020EFF 0000E408
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000DC5388: BF870132
	v_dot2acc_f32_f16 v6, v1, v86                              // 000000DC538C: 040CAD01
	v_or_b32_e32 v1, 0x64006400, v19                           // 000000DC5390: 380226FF 64006400
	v_or_b32_e32 v19, 0x64006400, v31                          // 000000DC5398: 38263EFF 64006400
	.long 0xcc0f4001                                           // 000000DC53A0: CC0F4001
	v_mul_i32_i24_e32 v1, 0xe408, v1                           // 000000DC53A4: 120202FF 0000E408
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DC53AC: BF870112
	.long 0xcc0f4013                                           // 000000DC53B0: CC0F4013
	v_mul_i32_i24_e32 v1, 0xe408, v19                          // 000000DC53B4: 120226FF 0000E408
	v_dot2acc_f32_f16 v74, v1, v43                             // 000000DC53BC: 04945701
	v_or_b32_e32 v1, 0x64006400, v23                           // 000000DC53C0: 38022EFF 64006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DC53C8: BF870112
	v_dot2acc_f32_f16 v74, v15, v44                            // 000000DC53CC: 0494590F
	.long 0xcc0f4001                                           // 000000DC53D0: CC0F4001
	v_mul_i32_i24_e32 v1, 0xe408, v1                           // 000000DC53D4: 120202FF 0000E408
	v_lshrrev_b32_e32 v15, 4, v39                              // 000000DC53DC: 321E4E84
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000DC53E0: BF8701A2
	v_dual_dot2acc_f32_f16 v74, v2, v45 :: v_dual_dot2acc_f32_f16 v75, v1, v47// 000000DC53E4: CB185B02 4A4A5F01
	v_or_b32_e32 v1, 0x64006400, v30                           // 000000DC53EC: 38023CFF 64006400
	v_and_b32_e32 v15, 0xf0f0f0f, v15                          // 000000DC53F4: 361E1EFF 0F0F0F0F
	v_mad_u64_u32 v[46:47], null, v66, 40, s[2:3]              // 000000DC53FC: D6FE7C2E 00095142
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DC5404: BF870214
	v_dual_dot2acc_f32_f16 v75, v18, v48 :: v_dual_and_b32 v18, 0xf0f0f0f, v39// 000000DC5408: CB246112 4B124EFF 0F0F0F0F
	.long 0xcc0f4001                                           // 000000DC5414: CC0F4001
	v_mul_i32_i24_e32 v1, 0xe408, v1                           // 000000DC5418: 120202FF 0000E408
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DC5420: BF870192
	v_dot2acc_f32_f16 v75, v14, v49                            // 000000DC5424: 0496630E
	v_perm_b32 v14, v15, v18, 0xc040c00                        // 000000DC5428: D644000E 03FE250F 0C040C00
	s_delay_alu instid0(VALU_DEP_3)                            // 000000DC5434: BF870003
	v_dot2acc_f32_f16 v76, v1, v59                             // 000000DC5438: 04987701
	v_or_b32_e32 v1, 0x64006400, v50                           // 000000DC543C: 380264FF 64006400
	ds_load_b128 v[52:55], v70 offset:5408                     // 000000DC5444: DBFC1520 34000046
	ds_load_b128 v[56:59], v70 offset:5424                     // 000000DC544C: DBFC1530 38000046
	v_mad_i32_i24 v47, v67, 40, v47                            // 000000DC5454: D60A002F 04BD5143
	v_or_b32_e32 v14, 0x64006400, v14                          // 000000DC545C: 381C1CFF 64006400
	v_dot2acc_f32_f16 v76, v19, v60                            // 000000DC5464: 04987913
	.long 0xcc0f4001                                           // 000000DC5468: CC0F4001
	v_mul_i32_i24_e32 v1, 0xe408, v1                           // 000000DC546C: 120202FF 0000E408
	v_or_b32_e32 v19, 0x64006400, v51                          // 000000DC5474: 382666FF 64006400
	ds_load_b128 v[42:45], v70 offset:5152                     // 000000DC547C: DBFC1420 2A000046
	ds_load_b128 v[48:51], v70 offset:5168                     // 000000DC5484: DBFC1430 30000046
	.long 0xcc0f400e                                           // 000000DC548C: CC0F400E
	v_mul_i32_i24_e32 v1, 0xe408, v14                          // 000000DC5490: 12021CFF 0000E408
	v_dot2acc_f32_f16 v76, v11, v61                            // 000000DC5498: 04987B0B
	global_load_b128 v[102:105], v[46:47], off                 // 000000DC549C: DC5E0000 667C002E
	.long 0xcc0f4013                                           // 000000DC54A4: CC0F4013
	v_mul_i32_i24_e32 v1, 0xe408, v19                          // 000000DC54A8: 120226FF 0000E408
	v_lshrrev_b32_e32 v61, 4, v41                              // 000000DC54B0: 327A5284
	v_dot2acc_f32_f16 v77, v14, v94                            // 000000DC54B4: 049ABD0E
	v_lshrrev_b32_e32 v14, 4, v28                              // 000000DC54B8: 321C3884
	v_dot2acc_f32_f16 v6, v1, v87                              // 000000DC54BC: 040CAF01
	v_lshrrev_b32_e32 v1, 4, v3                                // 000000DC54C0: 32020684
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DC54C4: BF870112
	v_dual_dot2acc_f32_f16 v6, v19, v88 :: v_dual_and_b32 v3, 0xf0f0f0f, v3// 000000DC54C8: CB24B113 060206FF 0F0F0F0F
	v_and_b32_e32 v1, 0xf0f0f0f, v1                            // 000000DC54D4: 360202FF 0F0F0F0F
	v_perm_b32 v19, v15, v18, 0xc060c02                        // 000000DC54DC: D6440013 03FE250F 0C060C02
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DC54E8: BF870193
	v_dot2acc_f32_f16 v6, v7, v89                              // 000000DC54EC: 040CB307
	v_perm_b32 v2, v1, v3, 0xc040c00                           // 000000DC54F0: D6440002 03FE0701 0C040C00
	v_perm_b32 v7, v1, v3, 0xc050c01                           // 000000DC54FC: D6440007 03FE0701 0C050C01
	v_perm_b32 v11, v1, v3, 0xc060c02                          // 000000DC5508: D644000B 03FE0701 0C060C02
	v_perm_b32 v1, v1, v3, 0xc070c03                           // 000000DC5514: D6440001 03FE0701 0C070C03
	v_perm_b32 v3, v15, v18, 0xc050c01                         // 000000DC5520: D6440003 03FE250F 0C050C01
	v_or_b32_e32 v2, 0x64006400, v2                            // 000000DC552C: 380404FF 64006400
	v_or_b32_e32 v7, 0x64006400, v7                            // 000000DC5534: 380E0EFF 64006400
	v_or_b32_e32 v11, 0x64006400, v11                          // 000000DC553C: 381616FF 64006400
	v_or_b32_e32 v1, 0x64006400, v1                            // 000000DC5544: 380202FF 64006400
	v_or_b32_e32 v3, 0x64006400, v3                            // 000000DC554C: 380606FF 64006400
	.long 0xcc0f4002                                           // 000000DC5554: CC0F4002
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000DC5558: 120204FF 0000E408
	.long 0xcc0f4007                                           // 000000DC5560: CC0F4007
	v_mul_i32_i24_e32 v1, 0xe408, v7                           // 000000DC5564: 12020EFF 0000E408
	.long 0xcc0f400b                                           // 000000DC556C: CC0F400B
	v_mul_i32_i24_e32 v1, 0xe408, v11                          // 000000DC5570: 120216FF 0000E408
	.long 0xcc0f4001                                           // 000000DC5578: CC0F4001
	v_mul_i32_i24_e32 v1, 0xe408, v1                           // 000000DC557C: 120202FF 0000E408
	v_perm_b32 v15, v15, v18, 0xc070c03                        // 000000DC5584: D644000F 03FE250F 0C070C03
	s_waitcnt lgkmcnt(5)                                       // 000000DC5590: BF89FC57
	v_dot2acc_f32_f16 v10, v2, v82                             // 000000DC5594: 0414A502
	v_lshrrev_b32_e32 v2, 4, v32                               // 000000DC5598: 32044084
	v_and_b32_e32 v18, 0xf0f0f0f, v32                          // 000000DC559C: 362440FF 0F0F0F0F
	v_or_b32_e32 v19, 0x64006400, v19                          // 000000DC55A4: 382626FF 64006400
	.long 0xcc0f4003                                           // 000000DC55AC: CC0F4003
	v_mul_i32_i24_e32 v1, 0xe408, v3                           // 000000DC55B0: 120206FF 0000E408
	v_dot2acc_f32_f16 v10, v7, v83                             // 000000DC55B8: 0414A707
	v_or_b32_e32 v15, 0x64006400, v15                          // 000000DC55BC: 381E1EFF 64006400
	v_and_b32_e32 v7, 0xf0f0f0f, v28                           // 000000DC55C4: 360E38FF 0F0F0F0F
	.long 0xcc0f4013                                           // 000000DC55CC: CC0F4013
	v_mul_i32_i24_e32 v1, 0xe408, v19                          // 000000DC55D0: 120226FF 0000E408
	v_dot2acc_f32_f16 v77, v3, v95                             // 000000DC55D8: 049ABF03
	v_dual_dot2acc_f32_f16 v10, v11, v84 :: v_dual_and_b32 v11, 0xf0f0f0f, v14// 000000DC55DC: CB24A90B 0A0A1CFF 0F0F0F0F
	.long 0xcc0f4003                                           // 000000DC55E8: CC0F4003
	v_mul_i32_i24_e32 v1, 0xe408, v15                          // 000000DC55EC: 12021EFF 0000E408
	ds_load_b128 v[86:89], v70 offset:5920                     // 000000DC55F4: DBFC1720 56000046
	v_dual_dot2acc_f32_f16 v77, v19, v96 :: v_dual_dot2acc_f32_f16 v10, v1, v85// 000000DC55FC: CB18C113 4D0AAB01
	ds_load_b128 v[78:81], v70 offset:5664                     // 000000DC5604: DBFC1620 4E000046
	ds_load_b128 v[82:85], v70 offset:5680                     // 000000DC560C: DBFC1630 52000046
	v_and_b32_e32 v2, 0xf0f0f0f, v2                            // 000000DC5614: 360404FF 0F0F0F0F
	v_perm_b32 v15, v11, v7, 0xc040c00                         // 000000DC561C: D644000F 03FE0F0B 0C040C00
	v_dot2acc_f32_f16 v77, v3, v97                             // 000000DC5628: 049AC303
	v_perm_b32 v19, v11, v7, 0xc060c02                         // 000000DC562C: D6440013 03FE0F0B 0C060C02
	ds_load_b128 v[94:97], v70 offset:6960                     // 000000DC5638: DBFC1B30 5E000046
	v_perm_b32 v14, v2, v18, 0xc040c00                         // 000000DC5640: D644000E 03FE2502 0C040C00
	v_perm_b32 v1, v2, v18, 0xc050c01                          // 000000DC564C: D6440001 03FE2502 0C050C01
	v_perm_b32 v3, v2, v18, 0xc060c02                          // 000000DC5658: D6440003 03FE2502 0C060C02
	v_perm_b32 v2, v2, v18, 0xc070c03                          // 000000DC5664: D6440002 03FE2502 0C070C03
	v_perm_b32 v18, v11, v7, 0xc050c01                         // 000000DC5670: D6440012 03FE0F0B 0C050C01
	v_or_b32_e32 v14, 0x64006400, v14                          // 000000DC567C: 381C1CFF 64006400
	v_or_b32_e32 v1, 0x64006400, v1                            // 000000DC5684: 380202FF 64006400
	v_or_b32_e32 v15, 0x64006400, v15                          // 000000DC568C: 381E1EFF 64006400
	v_or_b32_e32 v3, 0x64006400, v3                            // 000000DC5694: 380606FF 64006400
	v_or_b32_e32 v18, 0x64006400, v18                          // 000000DC569C: 382424FF 64006400
	.long 0xcc0f400e                                           // 000000DC56A4: CC0F400E
	v_mul_i32_i24_e32 v1, 0xe408, v14                          // 000000DC56A8: 12021CFF 0000E408
	.long 0xcc0f4001                                           // 000000DC56B0: CC0F4001
	v_mul_i32_i24_e32 v1, 0xe408, v1                           // 000000DC56B4: 120202FF 0000E408
	.long 0xcc0f400f                                           // 000000DC56BC: CC0F400F
	v_mul_i32_i24_e32 v1, 0xe408, v15                          // 000000DC56C0: 12021EFF 0000E408
	.long 0xcc0f4003                                           // 000000DC56C8: CC0F4003
	v_mul_i32_i24_e32 v1, 0xe408, v3                           // 000000DC56CC: 120206FF 0000E408
	v_perm_b32 v7, v11, v7, 0xc070c03                          // 000000DC56D4: D6440007 03FE0F0B 0C070C03
	s_waitcnt lgkmcnt(5)                                       // 000000DC56E0: BF89FC57
	v_dot2acc_f32_f16 v71, v14, v42                            // 000000DC56E4: 048E550E
	.long 0xcc0f400b                                           // 000000DC56E8: CC0F400B
	v_mul_i32_i24_e32 v1, 0xe408, v18                          // 000000DC56EC: 120224FF 0000E408
	v_dot2acc_f32_f16 v72, v15, v52                            // 000000DC56F4: 0490690F
	v_or_b32_e32 v2, 0x64006400, v2                            // 000000DC56F8: 380404FF 64006400
	v_or_b32_e32 v7, 0x64006400, v7                            // 000000DC5700: 380E0EFF 64006400
	v_dot2acc_f32_f16 v71, v1, v43                             // 000000DC5708: 048E5701
	v_or_b32_e32 v1, 0x64006400, v19                           // 000000DC570C: 380226FF 64006400
	v_dual_dot2acc_f32_f16 v72, v11, v53 :: v_dual_and_b32 v11, 0xf0f0f0f, v24// 000000DC5714: CB246B0B 480A30FF 0F0F0F0F
	.long 0xcc0f4002                                           // 000000DC5720: CC0F4002
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000DC5724: 120204FF 0000E408
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000DC572C: BF870244
	v_dot2acc_f32_f16 v71, v3, v44                             // 000000DC5730: 048E5903
	v_lshrrev_b32_e32 v3, 4, v24                               // 000000DC5734: 32063084
	.long 0xcc0f4001                                           // 000000DC5738: CC0F4001
	v_mul_i32_i24_e32 v1, 0xe408, v1                           // 000000DC573C: 120202FF 0000E408
	.long 0xcc0f4007                                           // 000000DC5744: CC0F4007
	v_mul_i32_i24_e32 v1, 0xe408, v7                           // 000000DC5748: 12020EFF 0000E408
	v_dot2acc_f32_f16 v71, v2, v45                             // 000000DC5750: 048E5B02
	s_delay_alu instid0(VALU_DEP_3)                            // 000000DC5754: BF870003
	v_dual_dot2acc_f32_f16 v72, v1, v54 :: v_dual_and_b32 v3, 0xf0f0f0f, v3// 000000DC5758: CB246D01 480206FF 0F0F0F0F
	v_lshrrev_b32_e32 v1, 4, v20                               // 000000DC5764: 32022884
	ds_load_b128 v[42:45], v70 offset:6176                     // 000000DC5768: DBFC1820 2A000046
	v_and_b32_e32 v2, 0xf0f0f0f, v20                           // 000000DC5770: 360428FF 0F0F0F0F
	v_perm_b32 v14, v3, v11, 0xc040c00                         // 000000DC5778: D644000E 03FE1703 0C040C00
	v_dual_dot2acc_f32_f16 v72, v7, v55 :: v_dual_and_b32 v1, 0xf0f0f0f, v1// 000000DC5784: CB246F07 480002FF 0F0F0F0F
	v_perm_b32 v7, v3, v11, 0xc050c01                          // 000000DC5790: D6440007 03FE1703 0C050C01
	v_perm_b32 v15, v3, v11, 0xc060c02                         // 000000DC579C: D644000F 03FE1703 0C060C02
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DC57A8: BF870004
	v_or_b32_e32 v14, 0x64006400, v14                          // 000000DC57AC: 381C1CFF 64006400
	v_perm_b32 v3, v3, v11, 0xc070c03                          // 000000DC57B4: D6440003 03FE1703 0C070C03
	v_perm_b32 v18, v1, v2, 0xc040c00                          // 000000DC57C0: D6440012 03FE0501 0C040C00
	v_or_b32_e32 v7, 0x64006400, v7                            // 000000DC57CC: 380E0EFF 64006400
	v_perm_b32 v11, v1, v2, 0xc050c01                          // 000000DC57D4: D644000B 03FE0501 0C050C01
	.long 0xcc0f400e                                           // 000000DC57E0: CC0F400E
	v_mul_i32_i24_e32 v1, 0xe408, v14                          // 000000DC57E4: 12021CFF 0000E408
	v_perm_b32 v19, v1, v2, 0xc060c02                          // 000000DC57EC: D6440013 03FE0501 0C060C02
	v_or_b32_e32 v18, 0x64006400, v18                          // 000000DC57F8: 382424FF 64006400
	.long 0xcc0f4007                                           // 000000DC5800: CC0F4007
	v_mul_i32_i24_e32 v1, 0xe408, v7                           // 000000DC5804: 12020EFF 0000E408
	v_perm_b32 v1, v1, v2, 0xc070c03                           // 000000DC580C: D6440001 03FE0501 0C070C03
	s_waitcnt lgkmcnt(3)                                       // 000000DC5818: BF89FC37
	v_dot2acc_f32_f16 v73, v14, v78                            // 000000DC581C: 04929D0E
	v_or_b32_e32 v2, 0x64006400, v15                           // 000000DC5820: 38041EFF 64006400
	v_or_b32_e32 v11, 0x64006400, v11                          // 000000DC5828: 381616FF 64006400
	.long 0xcc0f4012                                           // 000000DC5830: CC0F4012
	v_mul_i32_i24_e32 v1, 0xe408, v18                          // 000000DC5834: 120224FF 0000E408
	v_or_b32_e32 v3, 0x64006400, v3                            // 000000DC583C: 380606FF 64006400
	v_dot2acc_f32_f16 v73, v7, v79                             // 000000DC5844: 04929F07
	.long 0xcc0f4002                                           // 000000DC5848: CC0F4002
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000DC584C: 120204FF 0000E408
	ds_load_b128 v[52:55], v70 offset:5936                     // 000000DC5854: DBFC1730 34000046
	.long 0xcc0f400b                                           // 000000DC585C: CC0F400B
	v_mul_i32_i24_e32 v1, 0xe408, v11                          // 000000DC5860: 120216FF 0000E408
	v_dot2acc_f32_f16 v74, v18, v86                            // 000000DC5868: 0494AD12
	.long 0xcc0f4003                                           // 000000DC586C: CC0F4003
	v_mul_i32_i24_e32 v1, 0xe408, v3                           // 000000DC5870: 120206FF 0000E408
	v_dot2acc_f32_f16 v73, v2, v80                             // 000000DC5878: 0492A102
	v_or_b32_e32 v7, 0x64006400, v19                           // 000000DC587C: 380E26FF 64006400
	v_and_b32_e32 v2, 0xf0f0f0f, v16                           // 000000DC5884: 360420FF 0F0F0F0F
	v_or_b32_e32 v1, 0x64006400, v1                            // 000000DC588C: 380202FF 64006400
	v_and_b32_e32 v19, 0xf0f0f0f, v21                          // 000000DC5894: 36262AFF 0F0F0F0F
	v_dot2acc_f32_f16 v73, v3, v81                             // 000000DC589C: 0492A303
	ds_load_b128 v[78:81], v70 offset:6192                     // 000000DC58A0: DBFC1830 4E000046
	v_dot2acc_f32_f16 v74, v11, v87                            // 000000DC58A8: 0494AF0B
	v_lshrrev_b32_e32 v11, 4, v16                              // 000000DC58AC: 32162084
	.long 0xcc0f4007                                           // 000000DC58B0: CC0F4007
	v_mul_i32_i24_e32 v1, 0xe408, v7                           // 000000DC58B4: 12020EFF 0000E408
	.long 0xcc0f4001                                           // 000000DC58BC: CC0F4001
	v_mul_i32_i24_e32 v1, 0xe408, v1                           // 000000DC58C0: 120202FF 0000E408
	v_lshrrev_b32_e32 v15, 4, v25                              // 000000DC58C8: 321E3284
	v_and_b32_e32 v18, 0xf0f0f0f, v40                          // 000000DC58CC: 362450FF 0F0F0F0F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000DC58D4: BF870224
	v_dual_dot2acc_f32_f16 v74, v7, v88 :: v_dual_and_b32 v11, 0xf0f0f0f, v11// 000000DC58D8: CB24B107 4A0A16FF 0F0F0F0F
	v_lshrrev_b32_e32 v20, 4, v21                              // 000000DC58E4: 32282A84
	v_and_b32_e32 v15, 0xf0f0f0f, v15                          // 000000DC58E8: 361E1EFF 0F0F0F0F
	s_delay_alu instid0(VALU_DEP_3)                            // 000000DC58F0: BF870003
	v_perm_b32 v7, v11, v2, 0xc040c00                          // 000000DC58F4: D6440007 03FE050B 0C040C00
	v_perm_b32 v3, v11, v2, 0xc050c01                          // 000000DC5900: D6440003 03FE050B 0C050C01
	v_dot2acc_f32_f16 v74, v1, v89                             // 000000DC590C: 0494B301
	v_perm_b32 v1, v11, v2, 0xc060c02                          // 000000DC5910: D6440001 03FE050B 0C060C02
	v_perm_b32 v2, v11, v2, 0xc070c03                          // 000000DC591C: D6440002 03FE050B 0C070C03
	v_or_b32_e32 v7, 0x64006400, v7                            // 000000DC5928: 380E0EFF 64006400
	v_or_b32_e32 v3, 0x64006400, v3                            // 000000DC5930: 380606FF 64006400
	v_lshrrev_b32_e32 v11, 4, v12                              // 000000DC5938: 32161884
	ds_load_b128 v[86:89], v70 offset:6432                     // 000000DC593C: DBFC1920 56000046
	v_or_b32_e32 v1, 0x64006400, v1                            // 000000DC5944: 380202FF 64006400
	.long 0xcc0f4007                                           // 000000DC594C: CC0F4007
	v_mul_i32_i24_e32 v1, 0xe408, v7                           // 000000DC5950: 12020EFF 0000E408
	.long 0xcc0f4003                                           // 000000DC5958: CC0F4003
	v_mul_i32_i24_e32 v1, 0xe408, v3                           // 000000DC595C: 120206FF 0000E408
	v_and_b32_e32 v11, 0xf0f0f0f, v11                          // 000000DC5964: 361616FF 0F0F0F0F
	v_or_b32_e32 v2, 0x64006400, v2                            // 000000DC596C: 380404FF 64006400
	.long 0xcc0f4001                                           // 000000DC5974: CC0F4001
	v_mul_i32_i24_e32 v1, 0xe408, v1                           // 000000DC5978: 120202FF 0000E408
	s_waitcnt lgkmcnt(3)                                       // 000000DC5980: BF89FC37
	v_dot2acc_f32_f16 v75, v7, v42                             // 000000DC5984: 04965507
	v_and_b32_e32 v7, 0xf0f0f0f, v12                           // 000000DC5988: 360E18FF 0F0F0F0F
	.long 0xcc0f4002                                           // 000000DC5990: CC0F4002
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000DC5994: 120204FF 0000E408
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DC599C: BF870193
	v_dot2acc_f32_f16 v75, v3, v43                             // 000000DC59A0: 04965703
	v_perm_b32 v3, v11, v7, 0xc040c00                          // 000000DC59A4: D6440003 03FE0F0B 0C040C00
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000DC59B0: BF8701A2
	v_dot2acc_f32_f16 v75, v1, v44                             // 000000DC59B4: 04965901
	v_perm_b32 v1, v11, v7, 0xc050c01                          // 000000DC59B8: D6440001 03FE0F0B 0C050C01
	v_or_b32_e32 v3, 0x64006400, v3                            // 000000DC59C4: 380606FF 64006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000DC59CC: BF870223
	v_dot2acc_f32_f16 v75, v2, v45                             // 000000DC59D0: 04965B02
	v_perm_b32 v2, v11, v7, 0xc060c02                          // 000000DC59D4: D6440002 03FE0F0B 0C060C02
	v_or_b32_e32 v1, 0x64006400, v1                            // 000000DC59E0: 380202FF 64006400
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DC59E8: BF870004
	.long 0xcc0f4003                                           // 000000DC59EC: CC0F4003
	v_mul_i32_i24_e32 v1, 0xe408, v3                           // 000000DC59F0: 120206FF 0000E408
	v_perm_b32 v7, v11, v7, 0xc070c03                          // 000000DC59F8: D6440007 03FE0F0B 0C070C03
	ds_load_b128 v[42:45], v70 offset:6688                     // 000000DC5A04: DBFC1A20 2A000046
	v_or_b32_e32 v2, 0x64006400, v2                            // 000000DC5A0C: 380404FF 64006400
	.long 0xcc0f4001                                           // 000000DC5A14: CC0F4001
	v_mul_i32_i24_e32 v1, 0xe408, v1                           // 000000DC5A18: 120202FF 0000E408
	s_waitcnt lgkmcnt(1)                                       // 000000DC5A20: BF89FC17
	v_dot2acc_f32_f16 v76, v3, v86                             // 000000DC5A24: 0498AD03
	v_or_b32_e32 v3, 0x64006400, v7                            // 000000DC5A28: 38060EFF 64006400
	v_and_b32_e32 v7, 0xf0f0f0f, v33                           // 000000DC5A30: 360E42FF 0F0F0F0F
	.long 0xcc0f4002                                           // 000000DC5A38: CC0F4002
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000DC5A3C: 120204FF 0000E408
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DC5A44: BF870214
	v_dot2acc_f32_f16 v76, v1, v87                             // 000000DC5A48: 0498AF01
	.long 0xcc0f4001                                           // 000000DC5A4C: CC0F4001
	v_mul_i32_i24_e32 v1, 0xe408, v3                           // 000000DC5A50: 120206FF 0000E408
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000DC5A58: BF870122
	v_dot2acc_f32_f16 v76, v2, v88                             // 000000DC5A5C: 0498B102
	v_lshrrev_b32_e32 v2, 4, v8                                // 000000DC5A60: 32041084
	v_dual_dot2acc_f32_f16 v76, v1, v89 :: v_dual_and_b32 v1, 0xf0f0f0f, v8// 000000DC5A64: CB24B301 4C0010FF 0F0F0F0F
	s_delay_alu instid0(VALU_DEP_2)                            // 000000DC5A70: BF870002
	v_and_b32_e32 v2, 0xf0f0f0f, v2                            // 000000DC5A74: 360404FF 0F0F0F0F
	ds_load_b128 v[86:89], v70 offset:6704                     // 000000DC5A7C: DBFC1A30 56000046
	v_lshrrev_b32_e32 v8, 4, v33                               // 000000DC5A84: 32104284
	ds_load_b128 v[30:33], v70 offset:6944                     // 000000DC5A88: DBFC1B20 1E000046
	v_perm_b32 v3, v2, v1, 0xc040c00                           // 000000DC5A90: D6440003 03FE0302 0C040C00
	v_perm_b32 v11, v2, v1, 0xc050c01                          // 000000DC5A9C: D644000B 03FE0302 0C050C01
	v_perm_b32 v12, v2, v1, 0xc060c02                          // 000000DC5AA8: D644000C 03FE0302 0C060C02
	v_perm_b32 v1, v2, v1, 0xc070c03                           // 000000DC5AB4: D6440001 03FE0302 0C070C03
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DC5AC0: BF870214
	v_or_b32_e32 v3, 0x64006400, v3                            // 000000DC5AC4: 380606FF 64006400
	v_or_b32_e32 v2, 0x64006400, v11                           // 000000DC5ACC: 380416FF 64006400
	v_and_b32_e32 v11, 0xf0f0f0f, v29                          // 000000DC5AD4: 36163AFF 0F0F0F0F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DC5ADC: BF870214
	v_or_b32_e32 v1, 0x64006400, v1                            // 000000DC5AE0: 380202FF 64006400
	.long 0xcc0f4003                                           // 000000DC5AE8: CC0F4003
	v_mul_i32_i24_e32 v1, 0xe408, v3                           // 000000DC5AEC: 120206FF 0000E408
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DC5AF4: BF870194
	.long 0xcc0f4002                                           // 000000DC5AF8: CC0F4002
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000DC5AFC: 120204FF 0000E408
	.long 0xcc0f4001                                           // 000000DC5B04: CC0F4001
	v_mul_i32_i24_e32 v1, 0xe408, v1                           // 000000DC5B08: 120202FF 0000E408
	s_waitcnt lgkmcnt(2)                                       // 000000DC5B10: BF89FC27
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000DC5B14: BF8701B3
	v_dot2acc_f32_f16 v6, v3, v42                              // 000000DC5B18: 040C5503
	v_or_b32_e32 v3, 0x64006400, v12                           // 000000DC5B1C: 380618FF 64006400
	v_lshrrev_b32_e32 v12, 4, v29                              // 000000DC5B24: 32183A84
	v_dot2acc_f32_f16 v6, v2, v43                              // 000000DC5B28: 040C5702
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000DC5B2C: BF870123
	.long 0xcc0f4003                                           // 000000DC5B30: CC0F4003
	v_mul_i32_i24_e32 v1, 0xe408, v3                           // 000000DC5B34: 120206FF 0000E408
	v_lshrrev_b32_e32 v2, 4, v4                                // 000000DC5B3C: 32040884
	v_dot2acc_f32_f16 v6, v3, v44                              // 000000DC5B40: 040C5903
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DC5B44: BF870112
	v_and_b32_e32 v2, 0xf0f0f0f, v2                            // 000000DC5B48: 360404FF 0F0F0F0F
	v_dual_dot2acc_f32_f16 v6, v1, v45 :: v_dual_and_b32 v1, 0xf0f0f0f, v4// 000000DC5B50: CB245B01 060008FF 0F0F0F0F
	global_load_b128 v[42:45], v[64:65], off offset:704        // 000000DC5B5C: DC5E02C0 2A7C0040
	v_perm_b32 v3, v2, v1, 0xc040c00                           // 000000DC5B64: D6440003 03FE0302 0C040C00
	v_perm_b32 v4, v2, v1, 0xc050c01                           // 000000DC5B70: D6440004 03FE0302 0C050C01
	v_perm_b32 v16, v2, v1, 0xc060c02                          // 000000DC5B7C: D6440010 03FE0302 0C060C02
	v_perm_b32 v1, v2, v1, 0xc070c03                           // 000000DC5B88: D6440001 03FE0302 0C070C03
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DC5B94: BF870214
	v_or_b32_e32 v3, 0x64006400, v3                            // 000000DC5B98: 380606FF 64006400
	v_or_b32_e32 v2, 0x64006400, v4                            // 000000DC5BA0: 380408FF 64006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DC5BA8: BF870193
	v_or_b32_e32 v1, 0x64006400, v1                            // 000000DC5BAC: 380202FF 64006400
	.long 0xcc0f4003                                           // 000000DC5BB4: CC0F4003
	v_mul_i32_i24_e32 v1, 0xe408, v3                           // 000000DC5BB8: 120206FF 0000E408
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DC5BC0: BF870193
	.long 0xcc0f4002                                           // 000000DC5BC4: CC0F4002
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000DC5BC8: 120204FF 0000E408
	.long 0xcc0f4001                                           // 000000DC5BD0: CC0F4001
	v_mul_i32_i24_e32 v1, 0xe408, v1                           // 000000DC5BD4: 120202FF 0000E408
	s_waitcnt lgkmcnt(0)                                       // 000000DC5BDC: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000DC5BE0: BF8701B3
	v_dot2acc_f32_f16 v10, v3, v30                             // 000000DC5BE4: 04143D03
	v_or_b32_e32 v3, 0x64006400, v16                           // 000000DC5BE8: 380620FF 64006400
	v_lshrrev_b32_e32 v16, 4, v40                              // 000000DC5BF0: 32205084
	v_dot2acc_f32_f16 v10, v2, v31                             // 000000DC5BF4: 04143F02
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DC5BF8: BF870193
	.long 0xcc0f4003                                           // 000000DC5BFC: CC0F4003
	v_mul_i32_i24_e32 v1, 0xe408, v3                           // 000000DC5C00: 120206FF 0000E408
	v_and_b32_e32 v16, 0xf0f0f0f, v16                          // 000000DC5C08: 362020FF 0F0F0F0F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DC5C10: BF870112
	v_dot2acc_f32_f16 v10, v3, v32                             // 000000DC5C14: 04144103
	v_perm_b32 v21, v16, v18, 0xc040c00                        // 000000DC5C18: D6440015 03FE2510 0C040C00
	v_perm_b32 v22, v16, v18, 0xc050c01                        // 000000DC5C24: D6440016 03FE2510 0C050C01
	v_perm_b32 v23, v16, v18, 0xc060c02                        // 000000DC5C30: D6440017 03FE2510 0C060C02
	v_perm_b32 v16, v16, v18, 0xc070c03                        // 000000DC5C3C: D6440010 03FE2510 0C070C03
	v_dot2acc_f32_f16 v10, v1, v33                             // 000000DC5C48: 04144301
	ds_load_b128 v[1:4], v70 offset:7200                       // 000000DC5C4C: DBFC1C20 01000046
	v_or_b32_e32 v21, 0x64006400, v21                          // 000000DC5C54: 382A2AFF 64006400
	v_mov_b32_e32 v33, 0                                       // 000000DC5C5C: 7E420280
	global_load_b128 v[29:32], v[64:65], off offset:832        // 000000DC5C60: DC5E0340 1D7C0040
	.long 0xcc0f4015                                           // 000000DC5C68: CC0F4015
	v_mul_i32_i24_e32 v1, 0xe408, v21                          // 000000DC5C6C: 12022AFF 0000E408
	s_waitcnt lgkmcnt(0)                                       // 000000DC5C74: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DC5C78: BF8700A1
	v_dot2acc_f32_f16 v77, v21, v1                             // 000000DC5C7C: 049A0315
	v_or_b32_e32 v1, 0x64006400, v22                           // 000000DC5C80: 38022CFF 64006400
	.long 0xcc0f4001                                           // 000000DC5C88: CC0F4001
	v_mul_i32_i24_e32 v1, 0xe408, v1                           // 000000DC5C8C: 120202FF 0000E408
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DC5C94: BF8700A1
	v_dot2acc_f32_f16 v77, v1, v2                              // 000000DC5C98: 049A0501
	v_or_b32_e32 v1, 0x64006400, v23                           // 000000DC5C9C: 38022EFF 64006400
	.long 0xcc0f4001                                           // 000000DC5CA4: CC0F4001
	v_mul_i32_i24_e32 v1, 0xe408, v1                           // 000000DC5CA8: 120202FF 0000E408
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000DC5CB0: BF870131
	v_dot2acc_f32_f16 v77, v1, v3                              // 000000DC5CB4: 049A0701
	v_or_b32_e32 v1, 0x64006400, v16                           // 000000DC5CB8: 380220FF 64006400
	v_lshrrev_b32_e32 v16, 4, v17                              // 000000DC5CC0: 32202284
	.long 0xcc0f4001                                           // 000000DC5CC4: CC0F4001
	v_mul_i32_i24_e32 v1, 0xe408, v1                           // 000000DC5CC8: 120202FF 0000E408
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DC5CD0: BF8700A1
	v_dot2acc_f32_f16 v77, v1, v4                              // 000000DC5CD4: 049A0901
	v_and_b32_e32 v1, 0xf0f0f0f, v8                            // 000000DC5CD8: 360210FF 0F0F0F0F
	v_perm_b32 v2, v1, v7, 0xc040c00                           // 000000DC5CE0: D6440002 03FE0F01 0C040C00
	v_perm_b32 v3, v1, v7, 0xc050c01                           // 000000DC5CEC: D6440003 03FE0F01 0C050C01
	v_perm_b32 v4, v1, v7, 0xc060c02                           // 000000DC5CF8: D6440004 03FE0F01 0C060C02
	v_perm_b32 v7, v1, v7, 0xc070c03                           // 000000DC5D04: D6440007 03FE0F01 0C070C03
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DC5D10: BF870214
	v_or_b32_e32 v2, 0x64006400, v2                            // 000000DC5D14: 380404FF 64006400
	v_or_b32_e32 v3, 0x64006400, v3                            // 000000DC5D1C: 380606FF 64006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DC5D24: BF870214
	v_or_b32_e32 v4, 0x64006400, v4                            // 000000DC5D28: 380808FF 64006400
	v_or_b32_e32 v7, 0x64006400, v7                            // 000000DC5D30: 380E0EFF 64006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DC5D38: BF870214
	.long 0xcc0f4002                                           // 000000DC5D3C: CC0F4002
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000DC5D40: 120204FF 0000E408
	.long 0xcc0f4003                                           // 000000DC5D48: CC0F4003
	v_mul_i32_i24_e32 v1, 0xe408, v3                           // 000000DC5D4C: 120206FF 0000E408
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DC5D54: BF870193
	.long 0xcc0f4007                                           // 000000DC5D58: CC0F4007
	v_mul_i32_i24_e32 v1, 0xe408, v7                           // 000000DC5D5C: 12020EFF 0000E408
	v_dot2acc_f32_f16 v71, v2, v48                             // 000000DC5D64: 048E6102
	.long 0xcc0f4002                                           // 000000DC5D68: CC0F4002
	v_mul_i32_i24_e32 v1, 0xe408, v4                           // 000000DC5D6C: 120208FF 0000E408
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DC5D74: BF870092
	v_dot2acc_f32_f16 v71, v3, v49                             // 000000DC5D78: 048E6303
	v_dot2acc_f32_f16 v71, v2, v50                             // 000000DC5D7C: 048E6502
	global_load_b128 v[1:4], v[46:47], off offset:16           // 000000DC5D80: DC5E0010 017C002E
	v_dual_dot2acc_f32_f16 v71, v7, v51 :: v_dual_and_b32 v14, 0xf0f0f0f, v25// 000000DC5D88: CB246707 470E32FF 0F0F0F0F
	v_and_b32_e32 v7, 0xf0f0f0f, v12                           // 000000DC5D94: 360E18FF 0F0F0F0F
	ds_load_b128 v[48:51], v70 offset:7424                     // 000000DC5D9C: DBFC1D00 30000046
	v_perm_b32 v21, v7, v11, 0xc040c00                         // 000000DC5DA4: D6440015 03FE1707 0C040C00
	v_perm_b32 v23, v7, v11, 0xc060c02                         // 000000DC5DB0: D6440017 03FE1707 0C060C02
	v_perm_b32 v22, v7, v11, 0xc050c01                         // 000000DC5DBC: D6440016 03FE1707 0C050C01
	v_perm_b32 v7, v7, v11, 0xc070c03                          // 000000DC5DC8: D6440007 03FE1707 0C070C03
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DC5DD4: BF870214
	v_or_b32_e32 v21, 0x64006400, v21                          // 000000DC5DD8: 382A2AFF 64006400
	v_or_b32_e32 v11, 0x64006400, v23                          // 000000DC5DE0: 38162EFF 64006400
	v_perm_b32 v23, v15, v14, 0xc050c01                        // 000000DC5DE8: D6440017 03FE1D0F 0C050C01
	v_or_b32_e32 v22, 0x64006400, v22                          // 000000DC5DF4: 382C2CFF 64006400
	v_or_b32_e32 v7, 0x64006400, v7                            // 000000DC5DFC: 380E0EFF 64006400
	.long 0xcc0f4015                                           // 000000DC5E04: CC0F4015
	v_mul_i32_i24_e32 v1, 0xe408, v21                          // 000000DC5E08: 12022AFF 0000E408
	.long 0xcc0f400b                                           // 000000DC5E10: CC0F400B
	v_mul_i32_i24_e32 v1, 0xe408, v11                          // 000000DC5E14: 120216FF 0000E408
	v_or_b32_e32 v23, 0x64006400, v23                          // 000000DC5E1C: 382E2EFF 64006400
	.long 0xcc0f4016                                           // 000000DC5E24: CC0F4016
	v_mul_i32_i24_e32 v1, 0xe408, v22                          // 000000DC5E28: 12022CFF 0000E408
	.long 0xcc0f4007                                           // 000000DC5E30: CC0F4007
	v_mul_i32_i24_e32 v1, 0xe408, v7                           // 000000DC5E34: 12020EFF 0000E408
	v_dot2acc_f32_f16 v72, v21, v56                            // 000000DC5E3C: 04907115
	v_perm_b32 v21, v15, v14, 0xc040c00                        // 000000DC5E40: D6440015 03FE1D0F 0C040C00
	.long 0xcc0f4017                                           // 000000DC5E4C: CC0F4017
	v_mul_i32_i24_e32 v1, 0xe408, v23                          // 000000DC5E50: 12022EFF 0000E408
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DC5E58: BF870193
	v_dot2acc_f32_f16 v72, v22, v57                            // 000000DC5E5C: 04907316
	v_or_b32_e32 v21, 0x64006400, v21                          // 000000DC5E60: 382A2AFF 64006400
	v_perm_b32 v22, v15, v14, 0xc060c02                        // 000000DC5E68: D6440016 03FE1D0F 0C060C02
	v_perm_b32 v14, v15, v14, 0xc070c03                        // 000000DC5E74: D644000E 03FE1D0F 0C070C03
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DC5E80: BF870214
	v_dot2acc_f32_f16 v72, v11, v58                            // 000000DC5E84: 0490750B
	.long 0xcc0f4015                                           // 000000DC5E88: CC0F4015
	v_mul_i32_i24_e32 v1, 0xe408, v21                          // 000000DC5E8C: 12022AFF 0000E408
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DC5E94: BF870214
	v_or_b32_e32 v22, 0x64006400, v22                          // 000000DC5E98: 382C2CFF 64006400
	v_or_b32_e32 v14, 0x64006400, v14                          // 000000DC5EA0: 381C1CFF 64006400
	s_delay_alu instid0(VALU_DEP_3)                            // 000000DC5EA8: BF870003
	v_dual_dot2acc_f32_f16 v72, v7, v59 :: v_dual_dot2acc_f32_f16 v73, v21, v82// 000000DC5EAC: CB187707 4848A515
	ds_load_b128 v[56:59], v70 offset:7440                     // 000000DC5EB4: DBFC1D10 38000046
	v_and_b32_e32 v20, 0xf0f0f0f, v20                          // 000000DC5EBC: 362828FF 0F0F0F0F
	v_and_b32_e32 v16, 0xf0f0f0f, v16                          // 000000DC5EC4: 362020FF 0F0F0F0F
	.long 0xcc0f400e                                           // 000000DC5ECC: CC0F400E
	v_mul_i32_i24_e32 v1, 0xe408, v14                          // 000000DC5ED0: 12021CFF 0000E408
	v_dual_dot2acc_f32_f16 v73, v23, v83 :: v_dual_and_b32 v8, 0xf0f0f0f, v17// 000000DC5ED8: CB24A717 490822FF 0F0F0F0F
	v_and_b32_e32 v17, 0xf0f0f0f, v13                          // 000000DC5EE4: 36221AFF 0F0F0F0F
	v_lshrrev_b32_e32 v13, 4, v13                              // 000000DC5EEC: 321A1A84
	v_perm_b32 v15, v20, v19, 0xc040c00                        // 000000DC5EF0: D644000F 03FE2714 0C040C00
	v_perm_b32 v11, v20, v19, 0xc050c01                        // 000000DC5EFC: D644000B 03FE2714 0C050C01
	v_perm_b32 v24, v20, v19, 0xc060c02                        // 000000DC5F08: D6440018 03FE2714 0C060C02
	v_perm_b32 v19, v20, v19, 0xc070c03                        // 000000DC5F14: D6440013 03FE2714 0C070C03
	v_and_b32_e32 v13, 0xf0f0f0f, v13                          // 000000DC5F20: 361A1AFF 0F0F0F0F
	v_or_b32_e32 v15, 0x64006400, v15                          // 000000DC5F28: 381E1EFF 64006400
	v_perm_b32 v20, v16, v8, 0xc040c00                         // 000000DC5F30: D6440014 03FE1110 0C040C00
	v_perm_b32 v7, v16, v8, 0xc050c01                          // 000000DC5F3C: D6440007 03FE1110 0C050C01
	v_perm_b32 v25, v16, v8, 0xc060c02                         // 000000DC5F48: D6440019 03FE1110 0C060C02
	v_perm_b32 v8, v16, v8, 0xc070c03                          // 000000DC5F54: D6440008 03FE1110 0C070C03
	.long 0xcc0f400f                                           // 000000DC5F60: CC0F400F
	v_mul_i32_i24_e32 v1, 0xe408, v15                          // 000000DC5F64: 12021EFF 0000E408
	v_perm_b32 v16, v13, v17, 0xc040c00                        // 000000DC5F6C: D6440010 03FE230D 0C040C00
	v_perm_b32 v26, v13, v17, 0xc050c01                        // 000000DC5F78: D644001A 03FE230D 0C050C01
	v_perm_b32 v21, v13, v17, 0xc060c02                        // 000000DC5F84: D6440015 03FE230D 0C060C02
	v_perm_b32 v13, v13, v17, 0xc070c03                        // 000000DC5F90: D644000D 03FE230D 0C070C03
	.long 0xcc0f4011                                           // 000000DC5F9C: CC0F4011
	v_mul_i32_i24_e32 v1, 0xe408, v22                          // 000000DC5FA0: 12022CFF 0000E408
	v_dot2acc_f32_f16 v74, v15, v52                            // 000000DC5FA8: 0494690F
	s_waitcnt vmcnt(4)                                         // 000000DC5FAC: BF8913F7
	v_lshrrev_b32_e32 v15, 4, v34                              // 000000DC5FB0: 321E4484
	v_or_b32_e32 v11, 0x64006400, v11                          // 000000DC5FB4: 381616FF 64006400
	v_or_b32_e32 v7, 0x64006400, v7                            // 000000DC5FBC: 380E0EFF 64006400
	v_dot2acc_f32_f16 v73, v17, v84                            // 000000DC5FC4: 0492A911
	v_and_b32_e32 v17, 0xf0f0f0f, v34                          // 000000DC5FC8: 362244FF 0F0F0F0F
	v_and_b32_e32 v15, 0xf0f0f0f, v15                          // 000000DC5FD0: 361E1EFF 0F0F0F0F
	.long 0xcc0f400b                                           // 000000DC5FD8: CC0F400B
	v_mul_i32_i24_e32 v1, 0xe408, v11                          // 000000DC5FDC: 120216FF 0000E408
	.long 0xcc0f4007                                           // 000000DC5FE4: CC0F4007
	v_mul_i32_i24_e32 v1, 0xe408, v7                           // 000000DC5FE8: 12020EFF 0000E408
	v_or_b32_e32 v22, 0x64006400, v24                          // 000000DC5FF0: 382C30FF 64006400
	v_dot2acc_f32_f16 v73, v14, v85                            // 000000DC5FF8: 0492AB0E
	v_or_b32_e32 v19, 0x64006400, v19                          // 000000DC5FFC: 382626FF 64006400
	v_dot2acc_f32_f16 v74, v11, v53                            // 000000DC6004: 04946B0B
	v_perm_b32 v11, v15, v17, 0xc040c00                        // 000000DC6008: D644000B 03FE230F 0C040C00
	.long 0xcc0f4016                                           // 000000DC6014: CC0F4016
	v_mul_i32_i24_e32 v1, 0xe408, v22                          // 000000DC6018: 12022CFF 0000E408
	v_or_b32_e32 v13, 0x64006400, v13                          // 000000DC6020: 381A1AFF 64006400
	.long 0xcc0f4013                                           // 000000DC6028: CC0F4013
	v_mul_i32_i24_e32 v1, 0xe408, v19                          // 000000DC602C: 120226FF 0000E408
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DC6034: BF870094
	v_or_b32_e32 v11, 0x64006400, v11                          // 000000DC6038: 381616FF 64006400
	.long 0xcc0f400b                                           // 000000DC6040: CC0F400B
	v_mul_i32_i24_e32 v1, 0xe408, v11                          // 000000DC6044: 120216FF 0000E408
	v_and_b32_e32 v18, 0xf0f0f0f, v9                           // 000000DC604C: 362412FF 0F0F0F0F
	v_lshrrev_b32_e32 v9, 4, v9                                // 000000DC6054: 32121284
	s_waitcnt lgkmcnt(1)                                       // 000000DC6058: BF89FC17
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000DC605C: BF8701A3
	v_dot2acc_f32_f16 v33, v11, v48                            // 000000DC6060: 0442610B
	v_or_b32_e32 v11, 0x64006400, v20                          // 000000DC6064: 381628FF 64006400
	v_and_b32_e32 v9, 0xf0f0f0f, v9                            // 000000DC606C: 361212FF 0F0F0F0F
	v_perm_b32 v48, v15, v17, 0xc070c03                        // 000000DC6074: D6440030 03FE230F 0C070C03
	s_delay_alu instid0(VALU_DEP_3)                            // 000000DC6080: BF870003
	.long 0xcc0f400b                                           // 000000DC6084: CC0F400B
	v_mul_i32_i24_e32 v1, 0xe408, v11                          // 000000DC6088: 120216FF 0000E408
	v_and_b32_e32 v12, 0xf0f0f0f, v5                           // 000000DC6090: 36180AFF 0F0F0F0F
	v_lshrrev_b32_e32 v5, 4, v5                                // 000000DC6098: 320A0A84
	v_perm_b32 v14, v9, v18, 0xc040c00                         // 000000DC609C: D644000E 03FE2509 0C040C00
	v_perm_b32 v34, v9, v18, 0xc050c01                         // 000000DC60A8: D6440022 03FE2509 0C050C01
	v_dual_dot2acc_f32_f16 v75, v11, v78 :: v_dual_and_b32 v60, 0xf0f0f0f, v41// 000000DC60B4: CB249D0B 4B3C52FF 0F0F0F0F
	global_load_b128 v[38:41], v[64:65], off offset:768        // 000000DC60C0: DC5E0300 267C0040
	v_and_b32_e32 v5, 0xf0f0f0f, v5                            // 000000DC60C8: 360A0AFF 0F0F0F0F
	v_perm_b32 v52, v9, v18, 0xc060c02                         // 000000DC60D0: D6440034 03FE2509 0C060C02
	v_dot2acc_f32_f16 v75, v7, v79                             // 000000DC60DC: 04969F07
	v_or_b32_e32 v7, 0x64006400, v8                            // 000000DC60E0: 380E10FF 64006400
	v_perm_b32 v9, v9, v18, 0xc070c03                          // 000000DC60E8: D6440009 03FE2509 0C070C03
	v_perm_b32 v18, v5, v12, 0xc040c00                         // 000000DC60F4: D6440012 03FE1905 0C040C00
	v_perm_b32 v53, v5, v12, 0xc050c01                         // 000000DC6100: D6440035 03FE1905 0C050C01
	v_perm_b32 v11, v15, v17, 0xc050c01                        // 000000DC610C: D644000B 03FE230F 0C050C01
	.long 0xcc0f4007                                           // 000000DC6118: CC0F4007
	v_mul_i32_i24_e32 v1, 0xe408, v7                           // 000000DC611C: 12020EFF 0000E408
	v_dot2acc_f32_f16 v74, v22, v54                            // 000000DC6124: 04946D16
	v_perm_b32 v54, v5, v12, 0xc060c02                         // 000000DC6128: D6440036 03FE1905 0C060C02
	v_perm_b32 v5, v5, v12, 0xc070c03                          // 000000DC6134: D6440005 03FE1905 0C070C03
	v_or_b32_e32 v12, 0x64006400, v16                          // 000000DC6140: 381820FF 64006400
	v_or_b32_e32 v11, 0x64006400, v11                          // 000000DC6148: 381616FF 64006400
	v_or_b32_e32 v16, 0x64006400, v26                          // 000000DC6150: 382034FF 64006400
	v_or_b32_e32 v48, 0x64006400, v48                          // 000000DC6158: 386060FF 64006400
	v_or_b32_e32 v9, 0x64006400, v9                            // 000000DC6160: 381212FF 64006400
	.long 0xcc0f400c                                           // 000000DC6168: CC0F400C
	v_mul_i32_i24_e32 v1, 0xe408, v12                          // 000000DC616C: 120218FF 0000E408
	.long 0xcc0f400b                                           // 000000DC6174: CC0F400B
	v_mul_i32_i24_e32 v1, 0xe408, v11                          // 000000DC6178: 120216FF 0000E408
	.long 0xcc0f4010                                           // 000000DC6180: CC0F4010
	v_mul_i32_i24_e32 v1, 0xe408, v16                          // 000000DC6184: 120220FF 0000E408
	.long 0xcc0f4030                                           // 000000DC618C: CC0F4030
	v_mul_i32_i24_e32 v1, 0xe408, v48                          // 000000DC6190: 120260FF 0000E408
	v_or_b32_e32 v5, 0x64006400, v5                            // 000000DC6198: 380A0AFF 64006400
	v_dot2acc_f32_f16 v76, v12, v90                            // 000000DC61A0: 0498B50C
	v_perm_b32 v12, v15, v17, 0xc060c02                        // 000000DC61A4: D644000C 03FE230F 0C060C02
	v_or_b32_e32 v15, 0x64006400, v25                          // 000000DC61B0: 381E32FF 64006400
	v_dot2acc_f32_f16 v33, v11, v49                            // 000000DC61B8: 0442630B
	v_or_b32_e32 v11, 0x64006400, v21                          // 000000DC61BC: 38162AFF 64006400
	v_or_b32_e32 v49, 0x64006400, v54                          // 000000DC61C4: 38626CFF 64006400
	v_or_b32_e32 v8, 0x64006400, v12                           // 000000DC61CC: 381018FF 64006400
	.long 0xcc0f400c                                           // 000000DC61D4: CC0F400C
	v_mul_i32_i24_e32 v1, 0xe408, v15                          // 000000DC61D8: 12021EFF 0000E408
	.long 0xcc0f4009                                           // 000000DC61E0: CC0F4009
	v_mul_i32_i24_e32 v1, 0xe408, v9                           // 000000DC61E4: 120212FF 0000E408
	.long 0xcc0f400b                                           // 000000DC61EC: CC0F400B
	v_mul_i32_i24_e32 v1, 0xe408, v11                          // 000000DC61F0: 120216FF 0000E408
	.long 0xcc0f4031                                           // 000000DC61F8: CC0F4031
	v_mul_i32_i24_e32 v1, 0xe408, v49                          // 000000DC61FC: 120262FF 0000E408
	.long 0xcc0f4008                                           // 000000DC6204: CC0F4008
	v_mul_i32_i24_e32 v1, 0xe408, v8                           // 000000DC6208: 120210FF 0000E408
	v_dot2acc_f32_f16 v75, v12, v80                            // 000000DC6210: 0496A10C
	v_or_b32_e32 v12, 0x64006400, v14                          // 000000DC6214: 38181CFF 64006400
	v_or_b32_e32 v14, 0x64006400, v18                          // 000000DC621C: 381C24FF 64006400
	.long 0xcc0f4005                                           // 000000DC6224: CC0F4005
	v_mul_i32_i24_e32 v1, 0xe408, v5                           // 000000DC6228: 12020AFF 0000E408
	v_dot2acc_f32_f16 v33, v8, v50                             // 000000DC6230: 04426508
	v_dot2acc_f32_f16 v75, v7, v81                             // 000000DC6234: 0496A307
	v_or_b32_e32 v7, 0x64006400, v34                           // 000000DC6238: 380E44FF 64006400
	.long 0xcc0f4008                                           // 000000DC6240: CC0F4008
	v_mul_i32_i24_e32 v1, 0xe408, v12                          // 000000DC6244: 120218FF 0000E408
	.long 0xcc0f400c                                           // 000000DC624C: CC0F400C
	v_mul_i32_i24_e32 v1, 0xe408, v13                          // 000000DC6250: 12021AFF 0000E408
	v_dot2acc_f32_f16 v33, v48, v51                            // 000000DC6258: 04426730
	v_dot2acc_f32_f16 v74, v19, v55                            // 000000DC625C: 04946F13
	.long 0xcc0f4007                                           // 000000DC6260: CC0F4007
	v_mul_i32_i24_e32 v1, 0xe408, v7                           // 000000DC6264: 12020EFF 0000E408
	v_dot2acc_f32_f16 v6, v8, v86                              // 000000DC626C: 040CAD08
	s_waitcnt vmcnt(4)                                         // 000000DC6270: BF8913F7
	v_fma_mix_f32 v13, v102, v71, 0 op_sel_hi:[1,0,0]          // 000000DC6274: CC20000D 0A028F66
	v_or_b32_e32 v34, 0x64006400, v52                          // 000000DC627C: 384468FF 64006400
	v_mov_b32_e32 v71, 0                                       // 000000DC6284: 7E8E0280
	s_clause 0x1                                               // 000000DC6288: BF850001
	global_load_b128 v[25:28], v[64:65], off offset:896        // 000000DC628C: DC5E0380 197C0040
	global_load_b128 v[21:24], v[64:65], off offset:960        // 000000DC6294: DC5E03C0 157C0040
	v_dot2acc_f32_f16 v6, v7, v87                              // 000000DC629C: 040CAF07
	v_and_b32_e32 v7, 0xf0f0f0f, v35                           // 000000DC62A0: 360E46FF 0F0F0F0F
	v_dot2acc_f32_f16 v76, v16, v91                            // 000000DC62A8: 0498B710
	v_fma_mix_f32 v8, v102, v72, v13 op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000DC62AC: CC200808 0C369166
	.long 0xcc0f4022                                           // 000000DC62B4: CC0F4022
	v_mul_i32_i24_e32 v1, 0xe408, v34                          // 000000DC62B8: 120244FF 0000E408
	v_mov_b32_e32 v72, 0                                       // 000000DC62C0: 7E900280
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DC62C4: BF870004
	v_dot2acc_f32_f16 v76, v11, v92                            // 000000DC62C8: 0498B90B
	.long 0xcc0f400b                                           // 000000DC62CC: CC0F400B
	v_mul_i32_i24_e32 v1, 0xe408, v14                          // 000000DC62D0: 12021CFF 0000E408
	v_fma_mix_f32 v8, v103, v73, v8 op_sel_hi:[1,0,0]          // 000000DC62D8: CC200008 0C229367
	v_dot2acc_f32_f16 v6, v34, v88                             // 000000DC62E0: 040CB122
	s_clause 0x1                                               // 000000DC62E4: BF850001
	global_load_b128 v[17:20], v[64:65], off offset:1024       // 000000DC62E8: DC5E0400 117C0040
	global_load_b128 v[13:16], v[64:65], off offset:1088       // 000000DC62F0: DC5E0440 0D7C0040
	v_dot2acc_f32_f16 v76, v12, v93                            // 000000DC62F8: 0498BB0C
	v_dot2acc_f32_f16 v10, v11, v94                            // 000000DC62FC: 0414BD0B
	v_or_b32_e32 v11, 0x64006400, v53                          // 000000DC6300: 38166AFF 64006400
	v_lshrrev_b32_e32 v12, 4, v35                              // 000000DC6308: 32184684
	v_and_b32_e32 v35, 0xf0f0f0f, v61                          // 000000DC630C: 36467AFF 0F0F0F0F
	v_fma_mix_f32 v8, v103, v74, v8 op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000DC6314: CC200808 0C229567
	v_dot2acc_f32_f16 v6, v9, v89                              // 000000DC631C: 040CB309
	.long 0xcc0f400b                                           // 000000DC6320: CC0F400B
	v_mul_i32_i24_e32 v1, 0xe408, v11                          // 000000DC6324: 120216FF 0000E408
	v_and_b32_e32 v12, 0xf0f0f0f, v12                          // 000000DC632C: 361818FF 0F0F0F0F
	v_perm_b32 v50, v35, v60, 0xc050c01                        // 000000DC6334: D6440032 03FE7923 0C050C01
	v_perm_b32 v34, v35, v60, 0xc060c02                        // 000000DC6340: D6440022 03FE7923 0C060C02
	v_fma_mix_f32 v8, v104, v75, v8 op_sel_hi:[1,0,0]          // 000000DC634C: CC200008 0C229768
	v_dot2acc_f32_f16 v10, v11, v95                            // 000000DC6354: 0414BF0B
	v_perm_b32 v11, v35, v60, 0xc040c00                        // 000000DC6358: D644000B 03FE7923 0C040C00
	v_or_b32_e32 v50, 0x64006400, v50                          // 000000DC6364: 386464FF 64006400
	v_or_b32_e32 v34, 0x64006400, v34                          // 000000DC636C: 384444FF 64006400
	v_perm_b32 v52, v12, v7, 0xc050c01                         // 000000DC6374: D6440034 03FE0F0C 0C050C01
	v_dot2acc_f32_f16 v10, v49, v96                            // 000000DC6380: 0414C131
	v_or_b32_e32 v11, 0x64006400, v11                          // 000000DC6384: 381616FF 64006400
	.long 0xcc0f4032                                           // 000000DC638C: CC0F4032
	v_mul_i32_i24_e32 v1, 0xe408, v50                          // 000000DC6390: 120264FF 0000E408
	v_perm_b32 v49, v12, v7, 0xc040c00                         // 000000DC6398: D6440031 03FE0F0C 0C040C00
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DC63A4: BF870214
	v_dot2acc_f32_f16 v10, v5, v97                             // 000000DC63A8: 0414C305
	.long 0xcc0f400b                                           // 000000DC63AC: CC0F400B
	v_mul_i32_i24_e32 v1, 0xe408, v11                          // 000000DC63B0: 120216FF 0000E408
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DC63B8: BF870113
	v_or_b32_e32 v49, 0x64006400, v49                          // 000000DC63BC: 386262FF 64006400
	v_dot2acc_f32_f16 v77, v11, v98                            // 000000DC63C4: 049AC50B
	.long 0xcc0f400b                                           // 000000DC63C8: CC0F400B
	v_mul_i32_i24_e32 v1, 0xe408, v34                          // 000000DC63CC: 120244FF 0000E408
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000DC63D4: BF870223
	.long 0xcc0f4009                                           // 000000DC63D8: CC0F4009
	v_mul_i32_i24_e32 v1, 0xe408, v49                          // 000000DC63DC: 120262FF 0000E408
	v_perm_b32 v34, v35, v60, 0xc070c03                        // 000000DC63E4: D6440022 03FE7923 0C070C03
	v_dot2acc_f32_f16 v77, v50, v99                            // 000000DC63F0: 049AC732
	ds_load_b128 v[48:51], v70 offset:7456                     // 000000DC63F4: DBFC1D20 30000046
	s_waitcnt lgkmcnt(1)                                       // 000000DC63FC: BF89FC17
	v_dot2acc_f32_f16 v33, v9, v56                             // 000000DC6400: 04427109
	v_lshrrev_b32_e32 v9, 4, v36                               // 000000DC6404: 32124884
	v_or_b32_e32 v34, 0x64006400, v34                          // 000000DC6408: 384444FF 64006400
	v_dot2acc_f32_f16 v77, v11, v100                           // 000000DC6410: 049AC90B
	v_fma_mix_f32 v8, v104, v76, v8 op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000DC6414: CC200808 0C229968
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DC641C: BF870114
	v_and_b32_e32 v9, 0xf0f0f0f, v9                            // 000000DC6420: 361212FF 0F0F0F0F
	v_fma_mix_f32 v5, v105, v6, v8 op_sel_hi:[1,0,0]           // 000000DC6428: CC200005 0C220D69
	v_or_b32_e32 v6, 0x64006400, v52                           // 000000DC6430: 380C68FF 64006400
	ds_load_b128 v[52:55], v70 offset:7472                     // 000000DC6438: DBFC1D30 34000046
	.long 0xcc0f4006                                           // 000000DC6440: CC0F4006
	v_mul_i32_i24_e32 v1, 0xe408, v6                           // 000000DC6444: 12020CFF 0000E408
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000DC644C: BF8701C1
	v_dot2acc_f32_f16 v33, v6, v57                             // 000000DC6450: 04427306
	v_perm_b32 v8, v12, v7, 0xc060c02                          // 000000DC6454: D6440008 03FE0F0C 0C060C02
	v_perm_b32 v7, v12, v7, 0xc070c03                          // 000000DC6460: D6440007 03FE0F0C 0C070C03
	v_and_b32_e32 v12, 0xf0f0f0f, v36                          // 000000DC646C: 361848FF 0F0F0F0F
	v_or_b32_e32 v8, 0x64006400, v8                            // 000000DC6474: 381010FF 64006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DC647C: BF870193
	v_or_b32_e32 v7, 0x64006400, v7                            // 000000DC6480: 380E0EFF 64006400
	v_perm_b32 v11, v9, v12, 0xc050c01                         // 000000DC6488: D644000B 03FE1909 0C050C01
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000DC6494: BF870123
	.long 0xcc0f4006                                           // 000000DC6498: CC0F4006
	v_mul_i32_i24_e32 v1, 0xe408, v8                           // 000000DC649C: 120210FF 0000E408
	v_perm_b32 v8, v9, v12, 0xc040c00                          // 000000DC64A4: D6440008 03FE1909 0C040C00
	v_dot2acc_f32_f16 v33, v6, v58                             // 000000DC64B0: 04427506
	.long 0xcc0f4006                                           // 000000DC64B4: CC0F4006
	v_mul_i32_i24_e32 v1, 0xe408, v7                           // 000000DC64B8: 12020EFF 0000E408
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000DC64C0: BF870233
	v_or_b32_e32 v7, 0x64006400, v8                            // 000000DC64C4: 380E10FF 64006400
	.long 0xcc0f4008                                           // 000000DC64CC: CC0F4008
	v_mul_i32_i24_e32 v1, 0xe408, v34                          // 000000DC64D0: 120244FF 0000E408
	v_fma_mix_f32 v34, v105, v10, v5 op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000DC64D8: CC200822 0C161569
	v_dot2acc_f32_f16 v33, v6, v59                             // 000000DC64E0: 04427706
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DC64E4: BF870004
	.long 0xcc0f4005                                           // 000000DC64E8: CC0F4005
	v_mul_i32_i24_e32 v1, 0xe408, v7                           // 000000DC64EC: 12020EFF 0000E408
	v_or_b32_e32 v6, 0x64006400, v11                           // 000000DC64F4: 380C16FF 64006400
	ds_load_b128 v[56:59], v70 offset:7680                     // 000000DC64FC: DBFC1E00 38000046
	v_dot2acc_f32_f16 v77, v8, v101                            // 000000DC6504: 049ACB08
	s_waitcnt lgkmcnt(2)                                       // 000000DC6508: BF89FC27
	v_dual_dot2acc_f32_f16 v33, v5, v48 :: v_dual_and_b32 v48, 0xf0f0f0f, v106// 000000DC650C: CB246105 2130D4FF 0F0F0F0F
	v_lshrrev_b32_e32 v5, 4, v106                              // 000000DC6518: 320AD484
	.long 0xcc0f4006                                           // 000000DC651C: CC0F4006
	v_mul_i32_i24_e32 v1, 0xe408, v6                           // 000000DC6520: 12020CFF 0000E408
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DC6528: BF870112
	v_and_b32_e32 v60, 0xf0f0f0f, v5                           // 000000DC652C: 36780AFF 0F0F0F0F
	v_dot2acc_f32_f16 v33, v6, v49                             // 000000DC6534: 04426306
	v_perm_b32 v7, v9, v12, 0xc060c02                          // 000000DC6538: D6440007 03FE1909 0C060C02
	v_perm_b32 v8, v9, v12, 0xc070c03                          // 000000DC6544: D6440008 03FE1909 0C070C03
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DC6550: BF870194
	v_perm_b32 v49, v60, v48, 0xc040c00                        // 000000DC6554: D6440031 03FE613C 0C040C00
	v_or_b32_e32 v7, 0x64006400, v7                            // 000000DC6560: 380E0EFF 64006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DC6568: BF870113
	v_or_b32_e32 v36, 0x64006400, v8                           // 000000DC656C: 384810FF 64006400
	.long 0xcc0f4023                                           // 000000DC6574: CC0F4023
	v_mul_i32_i24_e32 v1, 0xe408, v7                           // 000000DC6578: 12020EFF 0000E408
	s_clause 0x1                                               // 000000DC6580: BF850001
	global_load_b128 v[9:12], v[64:65], off offset:1152        // 000000DC6584: DC5E0480 097C0040
	global_load_b128 v[5:8], v[64:65], off offset:1216         // 000000DC658C: DC5E04C0 057C0040
	v_dot2acc_f32_f16 v33, v35, v50                            // 000000DC6594: 04426523
	v_lshrrev_b32_e32 v35, 4, v37                              // 000000DC6598: 32464A84
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DC659C: BF870001
	v_and_b32_e32 v65, 0xf0f0f0f, v35                          // 000000DC65A0: 368246FF 0F0F0F0F
	s_waitcnt vmcnt(7)                                         // 000000DC65A8: BF891FF7
	v_fma_mix_f32 v61, v1, v77, v34 op_sel_hi:[1,0,0]          // 000000DC65AC: CC20003D 0C8A9B01
	v_or_b32_e32 v34, 0x64006400, v49                          // 000000DC65B4: 384462FF 64006400
	.long 0xcc0f4031                                           // 000000DC65BC: CC0F4031
	v_mul_i32_i24_e32 v1, 0xe408, v36                          // 000000DC65C0: 120248FF 0000E408
	v_perm_b32 v36, v60, v48, 0xc050c01                        // 000000DC65C8: D6440024 03FE613C 0C050C01
	v_and_b32_e32 v64, 0xf0f0f0f, v37                          // 000000DC65D4: 36804AFF 0F0F0F0F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DC65DC: BF870214
	.long 0xcc0f4032                                           // 000000DC65E0: CC0F4032
	v_mul_i32_i24_e32 v1, 0xe408, v34                          // 000000DC65E4: 120244FF 0000E408
	v_dot2acc_f32_f16 v33, v49, v51                            // 000000DC65EC: 04426731
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DC65F0: BF870004
	v_or_b32_e32 v66, 0x64006400, v36                          // 000000DC65F4: 388448FF 64006400
	ds_load_b128 v[34:37], v70 offset:7696                     // 000000DC65FC: DBFC1E10 22000046
	s_waitcnt lgkmcnt(1)                                       // 000000DC6604: BF89FC17
	v_dot2acc_f32_f16 v71, v50, v56                            // 000000DC6608: 048E7132
	v_perm_b32 v67, v60, v48, 0xc060c02                        // 000000DC660C: D6440043 03FE613C 0C060C02
	.long 0xcc0f4038                                           // 000000DC6618: CC0F4038
	v_mul_i32_i24_e32 v1, 0xe408, v66                          // 000000DC661C: 120284FF 0000E408
	v_perm_b32 v48, v60, v48, 0xc070c03                        // 000000DC6624: D6440030 03FE613C 0C070C03
	v_lshrrev_b32_e32 v50, 4, v107                             // 000000DC6630: 3264D684
	v_and_b32_e32 v60, 0xf0f0f0f, v107                         // 000000DC6634: 3678D6FF 0F0F0F0F
	v_or_b32_e32 v66, 0x64006400, v67                          // 000000DC663C: 388486FF 64006400
	v_dot2acc_f32_f16 v71, v56, v57                            // 000000DC6644: 048E7338
	v_or_b32_e32 v48, 0x64006400, v48                          // 000000DC6648: 386060FF 64006400
	v_perm_b32 v67, v65, v64, 0xc040c00                        // 000000DC6650: D6440043 03FE8141 0C040C00
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DC665C: BF870194
	.long 0xcc0f4038                                           // 000000DC6660: CC0F4038
	v_mul_i32_i24_e32 v1, 0xe408, v66                          // 000000DC6664: 120284FF 0000E408
	.long 0xcc0f4030                                           // 000000DC666C: CC0F4030
	v_mul_i32_i24_e32 v1, 0xe408, v48                          // 000000DC6670: 120260FF 0000E408
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DC6678: BF870193
	v_or_b32_e32 v66, 0x64006400, v67                          // 000000DC667C: 388486FF 64006400
	v_dot2acc_f32_f16 v71, v56, v58                            // 000000DC6684: 048E7538
	v_and_b32_e32 v50, 0xf0f0f0f, v50                          // 000000DC6688: 366464FF 0F0F0F0F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DC6690: BF870193
	.long 0xcc0f4033                                           // 000000DC6694: CC0F4033
	v_mul_i32_i24_e32 v1, 0xe408, v66                          // 000000DC6698: 120284FF 0000E408
	v_dot2acc_f32_f16 v71, v48, v59                            // 000000DC66A0: 048E7730
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000DC66A4: BF870243
	v_perm_b32 v57, v50, v60, 0xc040c00                        // 000000DC66A8: D6440039 03FE7932 0C040C00
	v_perm_b32 v56, v50, v60, 0xc050c01                        // 000000DC66B4: D6440038 03FE7932 0C050C01
	v_perm_b32 v58, v50, v60, 0xc070c03                        // 000000DC66C0: D644003A 03FE7932 0C070C03
	v_and_b32_e32 v59, 0xf0f0f0f, v108                         // 000000DC66CC: 3676D8FF 0F0F0F0F
	v_or_b32_e32 v49, 0x64006400, v57                          // 000000DC66D4: 386272FF 64006400
	v_perm_b32 v57, v65, v64, 0xc050c01                        // 000000DC66DC: D6440039 03FE8141 0C050C01
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000DC66E8: BF870132
	.long 0xcc0f4030                                           // 000000DC66EC: CC0F4030
	v_mul_i32_i24_e32 v1, 0xe408, v49                          // 000000DC66F0: 120262FF 0000E408
	v_or_b32_e32 v49, 0x64006400, v56                          // 000000DC66F8: 386270FF 64006400
	s_waitcnt lgkmcnt(0)                                       // 000000DC6700: BF89FC07
	v_dot2acc_f32_f16 v71, v48, v34                            // 000000DC6704: 048E4530
	v_lshrrev_b32_e32 v34, 4, v108                             // 000000DC6708: 3244D884
	v_dot2acc_f32_f16 v33, v51, v52                            // 000000DC670C: 04426933
	v_perm_b32 v51, v50, v60, 0xc060c02                        // 000000DC6710: D6440033 03FE7932 0C060C02
	v_or_b32_e32 v52, 0x64006400, v57                          // 000000DC671C: 386872FF 64006400
	.long 0xcc0f4038                                           // 000000DC6724: CC0F4038
	v_mul_i32_i24_e32 v1, 0xe408, v49                          // 000000DC6728: 120262FF 0000E408
	v_and_b32_e32 v60, 0xf0f0f0f, v34                          // 000000DC6730: 367844FF 0F0F0F0F
	v_perm_b32 v34, v65, v64, 0xc060c02                        // 000000DC6738: D6440022 03FE8141 0C060C02
	v_or_b32_e32 v57, 0x64006400, v51                          // 000000DC6744: 387266FF 64006400
	ds_load_b128 v[48:51], v70 offset:7712                     // 000000DC674C: DBFC1E20 30000046
	v_dot2acc_f32_f16 v71, v56, v35                            // 000000DC6754: 048E4738
	v_or_b32_e32 v56, 0x64006400, v58                          // 000000DC6758: 387074FF 64006400
	.long 0xcc0f4034                                           // 000000DC6760: CC0F4034
	v_mul_i32_i24_e32 v1, 0xe408, v52                          // 000000DC6764: 120268FF 0000E408
	.long 0xcc0f4023                                           // 000000DC676C: CC0F4023
	v_mul_i32_i24_e32 v1, 0xe408, v57                          // 000000DC6770: 120272FF 0000E408
	v_perm_b32 v57, v60, v59, 0xc040c00                        // 000000DC6778: D6440039 03FE773C 0C040C00
	v_or_b32_e32 v34, 0x64006400, v34                          // 000000DC6784: 384444FF 64006400
	v_perm_b32 v64, v65, v64, 0xc070c03                        // 000000DC678C: D6440040 03FE8141 0C070C03
	v_dot2acc_f32_f16 v33, v52, v53                            // 000000DC6798: 04426B34
	v_dot2acc_f32_f16 v71, v35, v36                            // 000000DC679C: 048E4923
	.long 0xcc0f4023                                           // 000000DC67A0: CC0F4023
	v_mul_i32_i24_e32 v1, 0xe408, v56                          // 000000DC67A4: 120270FF 0000E408
	v_or_b32_e32 v36, 0x64006400, v57                          // 000000DC67AC: 384872FF 64006400
	v_perm_b32 v52, v60, v59, 0xc050c01                        // 000000DC67B4: D6440034 03FE773C 0C050C01
	.long 0xcc0f4035                                           // 000000DC67C0: CC0F4035
	v_mul_i32_i24_e32 v1, 0xe408, v34                          // 000000DC67C4: 120244FF 0000E408
	v_perm_b32 v57, v60, v59, 0xc060c02                        // 000000DC67CC: D6440039 03FE773C 0C060C02
	v_dot2acc_f32_f16 v71, v35, v37                            // 000000DC67D8: 048E4B23
	.long 0xcc0f4038                                           // 000000DC67DC: CC0F4038
	v_mul_i32_i24_e32 v1, 0xe408, v36                          // 000000DC67E0: 120248FF 0000E408
	v_or_b32_e32 v52, 0x64006400, v52                          // 000000DC67E8: 386868FF 64006400
	ds_load_b128 v[34:37], v70 offset:7728                     // 000000DC67F0: DBFC1E30 22000046
	v_or_b32_e32 v65, 0x64006400, v57                          // 000000DC67F8: 388272FF 64006400
	v_perm_b32 v60, v60, v59, 0xc070c03                        // 000000DC6800: D644003C 03FE773C 0C070C03
	s_waitcnt lgkmcnt(1)                                       // 000000DC680C: BF89FC17
	v_dot2acc_f32_f16 v71, v56, v48                            // 000000DC6810: 048E6138
	v_lshrrev_b32_e32 v48, 4, v42                              // 000000DC6814: 32605484
	.long 0xcc0f4034                                           // 000000DC6818: CC0F4034
	v_mul_i32_i24_e32 v1, 0xe408, v52                          // 000000DC681C: 120268FF 0000E408
	v_and_b32_e32 v42, 0xf0f0f0f, v42                          // 000000DC6824: 365454FF 0F0F0F0F
	ds_load_b128 v[56:59], v70 offset:7936                     // 000000DC682C: DBFC1F00 38000046
	v_or_b32_e32 v64, 0x64006400, v64                          // 000000DC6834: 388080FF 64006400
	v_dual_dot2acc_f32_f16 v71, v52, v49 :: v_dual_and_b32 v48, 0xf0f0f0f, v48// 000000DC683C: CB246334 473060FF 0F0F0F0F
	.long 0xcc0f4031                                           // 000000DC6848: CC0F4031
	v_mul_i32_i24_e32 v1, 0xe408, v65                          // 000000DC684C: 120282FF 0000E408
	v_or_b32_e32 v60, 0x64006400, v60                          // 000000DC6854: 387878FF 64006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000DC685C: BF870223
	v_perm_b32 v52, v48, v42, 0xc040c00                        // 000000DC6860: D6440034 03FE5530 0C040C00
	v_perm_b32 v73, v48, v42, 0xc060c02                        // 000000DC686C: D6440049 03FE5530 0C060C02
	v_dot2acc_f32_f16 v71, v49, v50                            // 000000DC6878: 048E6531
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000DC687C: BF870244
	.long 0xcc0f4032                                           // 000000DC6880: CC0F4032
	v_mul_i32_i24_e32 v1, 0xe408, v60                          // 000000DC6884: 120278FF 0000E408
	v_and_b32_e32 v60, 0xf0f0f0f, v109                         // 000000DC688C: 3678DAFF 0F0F0F0F
	v_or_b32_e32 v49, 0x64006400, v52                          // 000000DC6894: 386268FF 64006400
	v_lshrrev_b32_e32 v52, 4, v109                             // 000000DC689C: 3268DA84
	v_dot2acc_f32_f16 v71, v50, v51                            // 000000DC68A0: 048E6732
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DC68A4: BF870193
	.long 0xcc0f4031                                           // 000000DC68A8: CC0F4031
	v_mul_i32_i24_e32 v1, 0xe408, v49                          // 000000DC68AC: 120262FF 0000E408
	v_dual_dot2acc_f32_f16 v33, v53, v54 :: v_dual_and_b32 v52, 0xf0f0f0f, v52// 000000DC68B4: CB246D35 213468FF 0F0F0F0F
	v_perm_b32 v54, v48, v42, 0xc050c01                        // 000000DC68C0: D6440036 03FE5530 0C050C01
	.long 0xcc0f4035                                           // 000000DC68CC: CC0F4035
	v_mul_i32_i24_e32 v1, 0xe408, v64                          // 000000DC68D0: 120280FF 0000E408
	ds_load_b128 v[64:67], v70 offset:7952                     // 000000DC68D8: DBFC1F10 40000046
	s_waitcnt lgkmcnt(1)                                       // 000000DC68E0: BF89FC17
	v_dot2acc_f32_f16 v72, v49, v56                            // 000000DC68E4: 04907131
	v_lshrrev_b32_e32 v49, 4, v43                              // 000000DC68E8: 32625684
	v_or_b32_e32 v54, 0x64006400, v54                          // 000000DC68EC: 386C6CFF 64006400
	v_or_b32_e32 v56, 0x64006400, v73                          // 000000DC68F4: 387092FF 64006400
	v_perm_b32 v42, v48, v42, 0xc070c03                        // 000000DC68FC: D644002A 03FE5530 0C070C03
	v_and_b32_e32 v43, 0xf0f0f0f, v43                          // 000000DC6908: 365656FF 0F0F0F0F
	v_and_b32_e32 v48, 0xf0f0f0f, v49                          // 000000DC6910: 366062FF 0F0F0F0F
	.long 0xcc0f4036                                           // 000000DC6918: CC0F4036
	v_mul_i32_i24_e32 v1, 0xe408, v54                          // 000000DC691C: 12026CFF 0000E408
	v_perm_b32 v49, v52, v60, 0xc040c00                        // 000000DC6924: D6440031 03FE7934 0C040C00
	v_or_b32_e32 v42, 0x64006400, v42                          // 000000DC6930: 385454FF 64006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DC6938: BF870214
	v_perm_b32 v51, v48, v43, 0xc050c01                        // 000000DC693C: D6440033 03FE5730 0C050C01
	v_dot2acc_f32_f16 v72, v54, v57                            // 000000DC6948: 04907336
	.long 0xcc0f4036                                           // 000000DC694C: CC0F4036
	v_mul_i32_i24_e32 v1, 0xe408, v56                          // 000000DC6950: 120270FF 0000E408
	v_perm_b32 v56, v48, v43, 0xc040c00                        // 000000DC6958: D6440038 03FE5730 0C040C00
	.long 0xcc0f402a                                           // 000000DC6964: CC0F402A
	v_mul_i32_i24_e32 v1, 0xe408, v42                          // 000000DC6968: 120254FF 0000E408
	v_or_b32_e32 v49, 0x64006400, v49                          // 000000DC6970: 386262FF 64006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DC6978: BF870214
	v_dot2acc_f32_f16 v72, v54, v58                            // 000000DC697C: 04907536
	v_or_b32_e32 v50, 0x64006400, v56                          // 000000DC6980: 386470FF 64006400
	v_perm_b32 v56, v52, v60, 0xc070c03                        // 000000DC6988: D6440038 03FE7934 0C070C03
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DC6994: BF870214
	.long 0xcc0f4031                                           // 000000DC6998: CC0F4031
	v_mul_i32_i24_e32 v1, 0xe408, v49                          // 000000DC699C: 120262FF 0000E408
	v_dot2acc_f32_f16 v72, v42, v59                            // 000000DC69A4: 0490772A
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DC69A8: BF8700A4
	.long 0xcc0f402a                                           // 000000DC69AC: CC0F402A
	v_mul_i32_i24_e32 v1, 0xe408, v50                          // 000000DC69B0: 120264FF 0000E408
	s_waitcnt lgkmcnt(0)                                       // 000000DC69B8: BF89FC07
	v_dot2acc_f32_f16 v72, v42, v64                            // 000000DC69BC: 0490812A
	v_lshrrev_b32_e32 v42, 4, v44                              // 000000DC69C0: 32545884
	v_and_b32_e32 v44, 0xf0f0f0f, v44                          // 000000DC69C4: 365858FF 0F0F0F0F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000DC69CC: BF8700B2
	v_and_b32_e32 v42, 0xf0f0f0f, v42                          // 000000DC69D0: 365454FF 0F0F0F0F
	v_dot2acc_f32_f16 v71, v49, v34                            // 000000DC69D8: 048E4531
	v_or_b32_e32 v34, 0x64006400, v51                          // 000000DC69DC: 384466FF 64006400
	.long 0xcc0f4022                                           // 000000DC69E4: CC0F4022
	v_mul_i32_i24_e32 v1, 0xe408, v34                          // 000000DC69E8: 120244FF 0000E408
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000DC69F0: BF870131
	v_dot2acc_f32_f16 v72, v34, v65                            // 000000DC69F4: 04908322
	v_perm_b32 v49, v48, v43, 0xc060c02                        // 000000DC69F8: D6440031 03FE5730 0C060C02
	v_perm_b32 v43, v48, v43, 0xc070c03                        // 000000DC6A04: D644002B 03FE5730 0C070C03
	v_or_b32_e32 v54, 0x64006400, v49                          // 000000DC6A10: 386C62FF 64006400
	ds_load_b128 v[48:51], v70 offset:7968                     // 000000DC6A18: DBFC1F20 30000046
	v_or_b32_e32 v43, 0x64006400, v43                          // 000000DC6A20: 385656FF 64006400
	.long 0xcc0f4022                                           // 000000DC6A28: CC0F4022
	v_mul_i32_i24_e32 v1, 0xe408, v54                          // 000000DC6A2C: 12026CFF 0000E408
	v_dot2acc_f32_f16 v33, v53, v55                            // 000000DC6A34: 04426F35
	v_perm_b32 v53, v52, v60, 0xc050c01                        // 000000DC6A38: D6440035 03FE7934 0C050C01
	v_perm_b32 v54, v42, v44, 0xc040c00                        // 000000DC6A44: D6440036 03FE592A 0C040C00
	v_perm_b32 v55, v52, v60, 0xc060c02                        // 000000DC6A50: D6440037 03FE7934 0C060C02
	v_dot2acc_f32_f16 v72, v34, v66                            // 000000DC6A5C: 04908522
	.long 0xcc0f4022                                           // 000000DC6A60: CC0F4022
	v_mul_i32_i24_e32 v1, 0xe408, v43                          // 000000DC6A64: 120256FF 0000E408
	v_or_b32_e32 v53, 0x64006400, v53                          // 000000DC6A6C: 386A6AFF 64006400
	v_or_b32_e32 v43, 0x64006400, v54                          // 000000DC6A74: 38566CFF 64006400
	v_perm_b32 v54, v42, v44, 0xc050c01                        // 000000DC6A7C: D6440036 03FE592A 0C050C01
	v_or_b32_e32 v55, 0x64006400, v55                          // 000000DC6A88: 386E6EFF 64006400
	v_dot2acc_f32_f16 v72, v34, v67                            // 000000DC6A90: 04908722
	.long 0xcc0f4035                                           // 000000DC6A94: CC0F4035
	v_mul_i32_i24_e32 v1, 0xe408, v53                          // 000000DC6A98: 12026AFF 0000E408
	.long 0xcc0f4022                                           // 000000DC6AA0: CC0F4022
	v_mul_i32_i24_e32 v1, 0xe408, v43                          // 000000DC6AA4: 120256FF 0000E408
	v_fma_mix_f32 v1, v1, v33, v61 op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000DC6AAC: CC200801 0CF64301
	.long 0xcc0f402b                                           // 000000DC6AB4: CC0F402B
	v_mul_i32_i24_e32 v1, 0xe408, v55                          // 000000DC6AB8: 12026EFF 0000E408
	s_waitcnt vmcnt(6)                                         // 000000DC6AC0: BF891BF7
	v_lshrrev_b32_e32 v33, 4, v38                              // 000000DC6AC4: 32424C84
	v_dot2acc_f32_f16 v71, v53, v35                            // 000000DC6AC8: 048E4735
	v_or_b32_e32 v35, 0x64006400, v54                          // 000000DC6ACC: 38466CFF 64006400
	ds_load_b128 v[52:55], v70 offset:7984                     // 000000DC6AD4: DBFC1F30 34000046
	s_waitcnt lgkmcnt(1)                                       // 000000DC6ADC: BF89FC17
	v_dot2acc_f32_f16 v72, v34, v48                            // 000000DC6AE0: 04906122
	.long 0xcc0f4022                                           // 000000DC6AE4: CC0F4022
	v_mul_i32_i24_e32 v1, 0xe408, v35                          // 000000DC6AE8: 120246FF 0000E408
	v_perm_b32 v35, v42, v44, 0xc060c02                        // 000000DC6AF0: D6440023 03FE592A 0C060C02
	v_perm_b32 v42, v42, v44, 0xc070c03                        // 000000DC6AFC: D644002A 03FE592A 0C070C03
	v_dot2acc_f32_f16 v71, v43, v36                            // 000000DC6B08: 048E492B
	v_or_b32_e32 v43, 0x64006400, v56                          // 000000DC6B0C: 385670FF 64006400
	v_lshrrev_b32_e32 v44, 4, v45                              // 000000DC6B14: 32585A84
	v_or_b32_e32 v48, 0x64006400, v35                          // 000000DC6B18: 386046FF 64006400
	v_or_b32_e32 v42, 0x64006400, v42                          // 000000DC6B20: 385454FF 64006400
	v_dot2acc_f32_f16 v72, v34, v49                            // 000000DC6B28: 04906322
	v_and_b32_e32 v56, 0xf0f0f0f, v33                          // 000000DC6B2C: 367042FF 0F0F0F0F
	ds_load_b128 v[33:36], v70 offset:8192                     // 000000DC6B34: DBFC2000 21000046
	.long 0xcc0f402b                                           // 000000DC6B3C: CC0F402B
	v_mul_i32_i24_e32 v1, 0xe408, v43                          // 000000DC6B40: 120256FF 0000E408
	v_and_b32_e32 v38, 0xf0f0f0f, v38                          // 000000DC6B48: 364C4CFF 0F0F0F0F
	.long 0xcc0f402a                                           // 000000DC6B50: CC0F402A
	v_mul_i32_i24_e32 v1, 0xe408, v42                          // 000000DC6B54: 120254FF 0000E408
	v_and_b32_e32 v57, 0xf0f0f0f, v44                          // 000000DC6B5C: 367258FF 0F0F0F0F
	.long 0xcc0f402c                                           // 000000DC6B64: CC0F402C
	v_mul_i32_i24_e32 v1, 0xe408, v48                          // 000000DC6B68: 120260FF 0000E408
	v_and_b32_e32 v49, 0xf0f0f0f, v45                          // 000000DC6B70: 36625AFF 0F0F0F0F
	v_dot2acc_f32_f16 v71, v43, v37                            // 000000DC6B78: 048E4B2B
	v_perm_b32 v45, v56, v38, 0xc040c00                        // 000000DC6B7C: D644002D 03FE4D38 0C040C00
	v_perm_b32 v43, v56, v38, 0xc050c01                        // 000000DC6B88: D644002B 03FE4D38 0C050C01
	v_dot2acc_f32_f16 v72, v44, v50                            // 000000DC6B94: 0490652C
	v_mov_b32_e32 v50, 0                                       // 000000DC6B98: 7E640280
	v_perm_b32 v58, v56, v38, 0xc060c02                        // 000000DC6B9C: D644003A 03FE4D38 0C060C02
	v_or_b32_e32 v44, 0x64006400, v45                          // 000000DC6BA8: 38585AFF 64006400
	v_perm_b32 v38, v56, v38, 0xc070c03                        // 000000DC6BB0: D6440026 03FE4D38 0C070C03
	v_dot2acc_f32_f16 v72, v42, v51                            // 000000DC6BBC: 0490672A
	v_perm_b32 v48, v57, v49, 0xc040c00                        // 000000DC6BC0: D6440030 03FE6339 0C040C00
	v_or_b32_e32 v51, 0x64006400, v43                          // 000000DC6BCC: 386656FF 64006400
	v_perm_b32 v56, v57, v49, 0xc050c01                        // 000000DC6BD4: D6440038 03FE6339 0C050C01
	v_or_b32_e32 v38, 0x64006400, v38                          // 000000DC6BE0: 384C4CFF 64006400
	v_fma_mix_f32 v1, v2, v71, v1 op_sel_hi:[1,0,0]            // 000000DC6BE8: CC200001 0C068F02
	v_or_b32_e32 v37, 0x64006400, v48                          // 000000DC6BF0: 384A60FF 64006400
	.long 0xcc0f4030                                           // 000000DC6BF8: CC0F4030
	v_mul_i32_i24_e32 v1, 0xe408, v44                          // 000000DC6BFC: 120258FF 0000E408
	ds_load_b128 v[42:45], v70 offset:8208                     // 000000DC6C04: DBFC2010 2A000046
	.long 0xcc0f4025                                           // 000000DC6C0C: CC0F4025
	v_mul_i32_i24_e32 v1, 0xe408, v37                          // 000000DC6C10: 12024AFF 0000E408
	s_waitcnt lgkmcnt(1)                                       // 000000DC6C18: BF89FC17
	v_dot2acc_f32_f16 v50, v48, v33                            // 000000DC6C1C: 04644330
	v_lshrrev_b32_e32 v33, 4, v39                              // 000000DC6C20: 32424E84
	.long 0xcc0f4030                                           // 000000DC6C24: CC0F4030
	v_mul_i32_i24_e32 v1, 0xe408, v51                          // 000000DC6C28: 120266FF 0000E408
	v_or_b32_e32 v51, 0x64006400, v58                          // 000000DC6C30: 386674FF 64006400
	v_dual_dot2acc_f32_f16 v72, v37, v52 :: v_dual_and_b32 v39, 0xf0f0f0f, v39// 000000DC6C38: CB246925 48264EFF 0F0F0F0F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DC6C44: BF870193
	v_dual_dot2acc_f32_f16 v50, v48, v34 :: v_dual_and_b32 v33, 0xf0f0f0f, v33// 000000DC6C48: CB244530 322042FF 0F0F0F0F
	.long 0xcc0f4022                                           // 000000DC6C54: CC0F4022
	v_mul_i32_i24_e32 v1, 0xe408, v51                          // 000000DC6C58: 120266FF 0000E408
	v_or_b32_e32 v51, 0x64006400, v56                          // 000000DC6C60: 386670FF 64006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DC6C68: BF870193
	v_perm_b32 v48, v33, v39, 0xc040c00                        // 000000DC6C6C: D6440030 03FE4F21 0C040C00
	v_dot2acc_f32_f16 v50, v34, v35                            // 000000DC6C78: 04644722
	.long 0xcc0f4022                                           // 000000DC6C7C: CC0F4022
	v_mul_i32_i24_e32 v1, 0xe408, v38                          // 000000DC6C80: 12024CFF 0000E408
	v_perm_b32 v38, v33, v39, 0xc050c01                        // 000000DC6C88: D6440026 03FE4F21 0C050C01
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DC6C94: BF870004
	v_or_b32_e32 v35, 0x64006400, v48                          // 000000DC6C98: 384660FF 64006400
	.long 0xcc0f4025                                           // 000000DC6CA0: CC0F4025
	v_mul_i32_i24_e32 v1, 0xe408, v51                          // 000000DC6CA4: 120266FF 0000E408
	v_and_b32_e32 v48, 0xf0f0f0f, v40                          // 000000DC6CAC: 366050FF 0F0F0F0F
	v_dot2acc_f32_f16 v50, v34, v36                            // 000000DC6CB4: 04644922
	v_perm_b32 v36, v33, v39, 0xc060c02                        // 000000DC6CB8: D6440024 03FE4F21 0C060C02
	.long 0xcc0f4022                                           // 000000DC6CC4: CC0F4022
	v_mul_i32_i24_e32 v1, 0xe408, v35                          // 000000DC6CC8: 120246FF 0000E408
	v_or_b32_e32 v35, 0x64006400, v38                          // 000000DC6CD0: 38464CFF 64006400
	v_perm_b32 v39, v33, v39, 0xc070c03                        // 000000DC6CD8: D6440027 03FE4F21 0C070C03
	v_dot2acc_f32_f16 v72, v37, v53                            // 000000DC6CE4: 04906B25
	v_perm_b32 v37, v57, v49, 0xc060c02                        // 000000DC6CE8: D6440025 03FE6339 0C060C02
	s_waitcnt lgkmcnt(0)                                       // 000000DC6CF4: BF89FC07
	v_dot2acc_f32_f16 v50, v34, v42                            // 000000DC6CF8: 04645522
	v_lshrrev_b32_e32 v34, 4, v40                              // 000000DC6CFC: 32445084
	.long 0xcc0f4026                                           // 000000DC6D00: CC0F4026
	v_mul_i32_i24_e32 v1, 0xe408, v35                          // 000000DC6D04: 120246FF 0000E408
	v_or_b32_e32 v42, 0x64006400, v36                          // 000000DC6D0C: 385448FF 64006400
	v_or_b32_e32 v39, 0x64006400, v39                          // 000000DC6D14: 384E4EFF 64006400
	v_or_b32_e32 v37, 0x64006400, v37                          // 000000DC6D1C: 384A4AFF 64006400
	v_and_b32_e32 v51, 0xf0f0f0f, v34                          // 000000DC6D24: 366644FF 0F0F0F0F
	ds_load_b128 v[33:36], v70 offset:8224                     // 000000DC6D2C: DBFC2020 21000046
	v_dot2acc_f32_f16 v50, v38, v43                            // 000000DC6D34: 04645726
	.long 0xcc0f4026                                           // 000000DC6D38: CC0F4026
	v_mul_i32_i24_e32 v1, 0xe408, v42                          // 000000DC6D3C: 120254FF 0000E408
	v_perm_b32 v42, v57, v49, 0xc070c03                        // 000000DC6D44: D644002A 03FE6339 0C070C03
	v_perm_b32 v40, v51, v48, 0xc040c00                        // 000000DC6D50: D6440028 03FE6133 0C040C00
	.long 0xcc0f4025                                           // 000000DC6D5C: CC0F4025
	v_mul_i32_i24_e32 v1, 0xe408, v37                          // 000000DC6D60: 12024AFF 0000E408
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000DC6D68: BF870224
	v_dot2acc_f32_f16 v50, v38, v44                            // 000000DC6D6C: 04645926
	.long 0xcc0f4026                                           // 000000DC6D70: CC0F4026
	v_mul_i32_i24_e32 v1, 0xe408, v39                          // 000000DC6D74: 12024EFF 0000E408
	v_or_b32_e32 v39, 0x64006400, v40                          // 000000DC6D7C: 384E50FF 64006400
	v_or_b32_e32 v40, 0x64006400, v42                          // 000000DC6D84: 385054FF 64006400
	v_perm_b32 v42, v51, v48, 0xc050c01                        // 000000DC6D8C: D644002A 03FE6133 0C050C01
	v_dot2acc_f32_f16 v72, v37, v54                            // 000000DC6D98: 04906D25
	v_dot2acc_f32_f16 v50, v38, v45                            // 000000DC6D9C: 04645B26
	.long 0xcc0f402b                                           // 000000DC6DA0: CC0F402B
	v_mul_i32_i24_e32 v1, 0xe408, v39                          // 000000DC6DA4: 12024EFF 0000E408
	.long 0xcc0f4031                                           // 000000DC6DAC: CC0F4031
	v_mul_i32_i24_e32 v1, 0xe408, v40                          // 000000DC6DB0: 120250FF 0000E408
	v_or_b32_e32 v42, 0x64006400, v42                          // 000000DC6DB8: 385454FF 64006400
	v_perm_b32 v44, v51, v48, 0xc060c02                        // 000000DC6DC0: D644002C 03FE6133 0C060C02
	ds_load_b128 v[37:40], v70 offset:8240                     // 000000DC6DCC: DBFC2030 25000046
	v_perm_b32 v48, v51, v48, 0xc070c03                        // 000000DC6DD4: D6440030 03FE6133 0C070C03
	s_waitcnt lgkmcnt(1)                                       // 000000DC6DE0: BF89FC17
	v_dot2acc_f32_f16 v50, v43, v33                            // 000000DC6DE4: 0464432B
	v_lshrrev_b32_e32 v33, 4, v29                              // 000000DC6DE8: 32423A84
	.long 0xcc0f4034                                           // 000000DC6DEC: CC0F4034
	v_mul_i32_i24_e32 v1, 0xe408, v42                          // 000000DC6DF0: 120254FF 0000E408
	v_or_b32_e32 v53, 0x64006400, v44                          // 000000DC6DF8: 386A58FF 64006400
	v_and_b32_e32 v29, 0xf0f0f0f, v29                          // 000000DC6E00: 363A3AFF 0F0F0F0F
	ds_load_b128 v[42:45], v70 offset:8448                     // 000000DC6E08: DBFC2100 2A000046
	v_dual_dot2acc_f32_f16 v72, v49, v55 :: v_dual_and_b32 v51, 0xf0f0f0f, v33// 000000DC6E10: CB246F31 483242FF 0F0F0F0F
	v_dot2acc_f32_f16 v50, v52, v34                            // 000000DC6E1C: 04644534
	.long 0xcc0f4031                                           // 000000DC6E20: CC0F4031
	v_mul_i32_i24_e32 v1, 0xe408, v53                          // 000000DC6E24: 12026AFF 0000E408
	v_or_b32_e32 v48, 0x64006400, v48                          // 000000DC6E2C: 386060FF 64006400
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DC6E34: BF870004
	v_perm_b32 v52, v51, v29, 0xc040c00                        // 000000DC6E38: D6440034 03FE3B33 0C040C00
	v_fma_mix_f32 v1, v2, v72, v1 op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000DC6E44: CC200801 0C069102
	global_load_b64 v[33:34], v[46:47], off offset:32          // 000000DC6E4C: DC560020 217C002E
	v_lshrrev_b32_e32 v46, 4, v41                              // 000000DC6E54: 325C5284
	v_perm_b32 v47, v51, v29, 0xc050c01                        // 000000DC6E58: D644002F 03FE3B33 0C050C01
	v_or_b32_e32 v2, 0x64006400, v52                           // 000000DC6E64: 380468FF 64006400
	v_dual_mov_b32 v53, 0 :: v_dual_dot2acc_f32_f16 v50, v49, v35// 000000DC6E6C: CA180080 35324731
	.long 0xcc0f4023                                           // 000000DC6E74: CC0F4023
	v_mul_i32_i24_e32 v1, 0xe408, v48                          // 000000DC6E78: 120260FF 0000E408
	v_and_b32_e32 v52, 0xf0f0f0f, v41                          // 000000DC6E80: 366852FF 0F0F0F0F
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DC6E88: BF870004
	.long 0xcc0f4002                                           // 000000DC6E8C: CC0F4002
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000DC6E90: 120204FF 0000E408
	v_and_b32_e32 v54, 0xf0f0f0f, v46                          // 000000DC6E98: 366C5CFF 0F0F0F0F
	v_or_b32_e32 v41, 0x64006400, v47                          // 000000DC6EA0: 38525EFF 64006400
	v_perm_b32 v55, v51, v29, 0xc060c02                        // 000000DC6EA8: D6440037 03FE3B33 0C060C02
	ds_load_b128 v[46:49], v70 offset:8464                     // 000000DC6EB4: DBFC2110 2E000046
	s_waitcnt lgkmcnt(1)                                       // 000000DC6EBC: BF89FC17
	v_dot2acc_f32_f16 v53, v2, v42                             // 000000DC6EC0: 046A5502
	v_lshrrev_b32_e32 v2, 4, v30                               // 000000DC6EC4: 32043C84
	.long 0xcc0f4029                                           // 000000DC6EC8: CC0F4029
	v_mul_i32_i24_e32 v1, 0xe408, v41                          // 000000DC6ECC: 120252FF 0000E408
	v_or_b32_e32 v42, 0x64006400, v55                          // 000000DC6ED4: 38546EFF 64006400
	v_perm_b32 v29, v51, v29, 0xc070c03                        // 000000DC6EDC: D644001D 03FE3B33 0C070C03
	v_and_b32_e32 v30, 0xf0f0f0f, v30                          // 000000DC6EE8: 363C3CFF 0F0F0F0F
	v_and_b32_e32 v2, 0xf0f0f0f, v2                            // 000000DC6EF0: 360404FF 0F0F0F0F
	v_perm_b32 v51, v54, v52, 0xc040c00                        // 000000DC6EF8: D6440033 03FE6936 0C040C00
	v_dot2acc_f32_f16 v53, v41, v43                            // 000000DC6F04: 046A5729
	.long 0xcc0f4029                                           // 000000DC6F08: CC0F4029
	v_mul_i32_i24_e32 v1, 0xe408, v42                          // 000000DC6F0C: 120254FF 0000E408
	v_or_b32_e32 v29, 0x64006400, v29                          // 000000DC6F14: 383A3AFF 64006400
	v_perm_b32 v42, v2, v30, 0xc040c00                         // 000000DC6F1C: D644002A 03FE3D02 0C040C00
	v_or_b32_e32 v43, 0x64006400, v51                          // 000000DC6F28: 385666FF 64006400
	v_dot2acc_f32_f16 v50, v35, v36                            // 000000DC6F30: 04644923
	v_dot2acc_f32_f16 v53, v41, v44                            // 000000DC6F34: 046A5929
	.long 0xcc0f401d                                           // 000000DC6F38: CC0F401D
	v_mul_i32_i24_e32 v1, 0xe408, v29                          // 000000DC6F3C: 12023AFF 0000E408
	v_or_b32_e32 v35, 0x64006400, v42                          // 000000DC6F44: 384654FF 64006400
	.long 0xcc0f4024                                           // 000000DC6F4C: CC0F4024
	v_mul_i32_i24_e32 v1, 0xe408, v43                          // 000000DC6F50: 120256FF 0000E408
	v_perm_b32 v41, v2, v30, 0xc050c01                         // 000000DC6F58: D6440029 03FE3D02 0C050C01
	v_perm_b32 v42, v54, v52, 0xc050c01                        // 000000DC6F64: D644002A 03FE6936 0C050C01
	v_dot2acc_f32_f16 v53, v29, v45                            // 000000DC6F70: 046A5B1D
	.long 0xcc0f401d                                           // 000000DC6F74: CC0F401D
	v_mul_i32_i24_e32 v1, 0xe408, v35                          // 000000DC6F78: 120246FF 0000E408
	v_dot2acc_f32_f16 v50, v36, v37                            // 000000DC6F80: 04644B24
	v_or_b32_e32 v35, 0x64006400, v41                          // 000000DC6F84: 384652FF 64006400
	v_perm_b32 v36, v2, v30, 0xc060c02                         // 000000DC6F8C: D6440024 03FE3D02 0C060C02
	v_or_b32_e32 v37, 0x64006400, v42                          // 000000DC6F98: 384A54FF 64006400
	s_waitcnt lgkmcnt(0)                                       // 000000DC6FA0: BF89FC07
	v_dot2acc_f32_f16 v53, v29, v46                            // 000000DC6FA4: 046A5D1D
	v_lshrrev_b32_e32 v29, 4, v31                              // 000000DC6FA8: 323A3E84
	.long 0xcc0f4023                                           // 000000DC6FAC: CC0F4023
	v_mul_i32_i24_e32 v1, 0xe408, v35                          // 000000DC6FB0: 120246FF 0000E408
	v_or_b32_e32 v36, 0x64006400, v36                          // 000000DC6FB8: 384848FF 64006400
	v_perm_b32 v2, v2, v30, 0xc070c03                          // 000000DC6FC0: D6440002 03FE3D02 0C070C03
	v_and_b32_e32 v30, 0xf0f0f0f, v31                          // 000000DC6FCC: 363C3EFF 0F0F0F0F
	v_and_b32_e32 v29, 0xf0f0f0f, v29                          // 000000DC6FD4: 363A3AFF 0F0F0F0F
	ds_load_b128 v[41:44], v70 offset:8480                     // 000000DC6FDC: DBFC2120 29000046
	v_dot2acc_f32_f16 v53, v35, v47                            // 000000DC6FE4: 046A5F23
	.long 0xcc0f4023                                           // 000000DC6FE8: CC0F4023
	v_mul_i32_i24_e32 v1, 0xe408, v36                          // 000000DC6FEC: 120248FF 0000E408
	v_or_b32_e32 v2, 0x64006400, v2                            // 000000DC6FF4: 380404FF 64006400
	v_perm_b32 v36, v29, v30, 0xc040c00                        // 000000DC6FFC: D6440024 03FE3D1D 0C040C00
	.long 0xcc0f4025                                           // 000000DC7008: CC0F4025
	v_mul_i32_i24_e32 v1, 0xe408, v37                          // 000000DC700C: 12024AFF 0000E408
	v_perm_b32 v46, v29, v30, 0xc060c02                        // 000000DC7014: D644002E 03FE3D1D 0C060C02
	v_dot2acc_f32_f16 v53, v35, v48                            // 000000DC7020: 046A6123
	.long 0xcc0f4002                                           // 000000DC7024: CC0F4002
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000DC7028: 120204FF 0000E408
	v_or_b32_e32 v35, 0x64006400, v36                          // 000000DC7030: 384648FF 64006400
	v_perm_b32 v36, v29, v30, 0xc050c01                        // 000000DC7038: D6440024 03FE3D1D 0C050C01
	v_dot2acc_f32_f16 v50, v37, v38                            // 000000DC7044: 04644D25
	v_or_b32_e32 v51, 0x64006400, v46                          // 000000DC7048: 38665CFF 64006400
	v_dot2acc_f32_f16 v53, v2, v49                             // 000000DC7050: 046A6302
	.long 0xcc0f4002                                           // 000000DC7054: CC0F4002
	v_mul_i32_i24_e32 v1, 0xe408, v35                          // 000000DC7058: 120246FF 0000E408
	v_or_b32_e32 v45, 0x64006400, v36                          // 000000DC7060: 385A48FF 64006400
	ds_load_b128 v[35:38], v70 offset:8496                     // 000000DC7068: DBFC2130 23000046
	v_perm_b32 v29, v29, v30, 0xc070c03                        // 000000DC7070: D644001D 03FE3D1D 0C070C03
	s_waitcnt lgkmcnt(1)                                       // 000000DC707C: BF89FC17
	v_dot2acc_f32_f16 v53, v2, v41                             // 000000DC7080: 046A5302
	.long 0xcc0f4029                                           // 000000DC7084: CC0F4029
	v_mul_i32_i24_e32 v1, 0xe408, v45                          // 000000DC7088: 12025AFF 0000E408
	s_waitcnt vmcnt(6)                                         // 000000DC7090: BF891BF7
	v_lshrrev_b32_e32 v2, 4, v25                               // 000000DC7094: 32043284
	v_and_b32_e32 v25, 0xf0f0f0f, v25                          // 000000DC7098: 363232FF 0F0F0F0F
	ds_load_b128 v[45:48], v70 offset:8704                     // 000000DC70A0: DBFC2200 2D000046
	v_or_b32_e32 v29, 0x64006400, v29                          // 000000DC70A8: 383A3AFF 64006400
	v_dot2acc_f32_f16 v53, v41, v42                            // 000000DC70B0: 046A5529
	.long 0xcc0f4029                                           // 000000DC70B4: CC0F4029
	v_mul_i32_i24_e32 v1, 0xe408, v51                          // 000000DC70B8: 120266FF 0000E408
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000DC70C0: BF870121
	v_dual_dot2acc_f32_f16 v53, v41, v43 :: v_dual_and_b32 v2, 0xf0f0f0f, v2// 000000DC70C4: CB245729 350204FF 0F0F0F0F
	v_perm_b32 v49, v54, v52, 0xc070c03                        // 000000DC70D0: D6440031 03FE6936 0C070C03
	v_perm_b32 v42, v2, v25, 0xc040c00                         // 000000DC70DC: D644002A 03FE3302 0C040C00
	.long 0xcc0f4029                                           // 000000DC70E8: CC0F4029
	v_mul_i32_i24_e32 v1, 0xe408, v29                          // 000000DC70EC: 12023AFF 0000E408
	v_lshrrev_b32_e32 v29, 4, v32                              // 000000DC70F4: 323A4084
	v_and_b32_e32 v43, 0xf0f0f0f, v32                          // 000000DC70F8: 365640FF 0F0F0F0F
	v_or_b32_e32 v30, 0x64006400, v49                          // 000000DC7100: 383C62FF 64006400
	v_mov_b32_e32 v49, 0                                       // 000000DC7108: 7E620280
	v_perm_b32 v31, v54, v52, 0xc060c02                        // 000000DC710C: D644001F 03FE6936 0C060C02
	v_perm_b32 v54, v2, v25, 0xc060c02                         // 000000DC7118: D6440036 03FE3302 0C060C02
	v_and_b32_e32 v51, 0xf0f0f0f, v29                          // 000000DC7124: 36663AFF 0F0F0F0F
	v_dot2acc_f32_f16 v53, v41, v44                            // 000000DC712C: 046A5929
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DC7130: BF870094
	v_or_b32_e32 v31, 0x64006400, v31                          // 000000DC7134: 383E3EFF 64006400
	.long 0xcc0f401f                                           // 000000DC713C: CC0F401F
	v_mul_i32_i24_e32 v1, 0xe408, v31                          // 000000DC7140: 12023EFF 0000E408
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000DC7148: BF870141
	v_dot2acc_f32_f16 v50, v31, v39                            // 000000DC714C: 04644F1F
	.long 0xcc0f4027                                           // 000000DC7150: CC0F4027
	v_mul_i32_i24_e32 v1, 0xe408, v30                          // 000000DC7154: 12023CFF 0000E408
	v_or_b32_e32 v30, 0x64006400, v42                          // 000000DC715C: 383C54FF 64006400
	v_perm_b32 v31, v2, v25, 0xc050c01                         // 000000DC7164: D644001F 03FE3302 0C050C01
	.long 0xcc0f402a                                           // 000000DC7170: CC0F402A
	v_mul_i32_i24_e32 v1, 0xe408, v30                          // 000000DC7174: 12023CFF 0000E408
	s_delay_alu instid0(VALU_DEP_2)                            // 000000DC717C: BF870002
	v_or_b32_e32 v52, 0x64006400, v31                          // 000000DC7180: 38683EFF 64006400
	ds_load_b128 v[29:32], v70 offset:8720                     // 000000DC7188: DBFC2210 1D000046
	s_waitcnt lgkmcnt(1)                                       // 000000DC7190: BF89FC17
	v_dot2acc_f32_f16 v49, v42, v45                            // 000000DC7194: 04625B2A
	.long 0xcc0f402d                                           // 000000DC7198: CC0F402D
	v_mul_i32_i24_e32 v1, 0xe408, v52                          // 000000DC719C: 120268FF 0000E408
	v_or_b32_e32 v52, 0x64006400, v54                          // 000000DC71A4: 38686CFF 64006400
	v_lshrrev_b32_e32 v42, 4, v26                              // 000000DC71AC: 32543484
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DC71B0: BF870193
	v_dot2acc_f32_f16 v49, v45, v46                            // 000000DC71B4: 04625D2D
	.long 0xcc0f402d                                           // 000000DC71B8: CC0F402D
	v_mul_i32_i24_e32 v1, 0xe408, v52                          // 000000DC71BC: 120268FF 0000E408
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 000000DC71C4: BF870251
	v_dot2acc_f32_f16 v49, v45, v47                            // 000000DC71C8: 04625F2D
	v_perm_b32 v2, v2, v25, 0xc070c03                          // 000000DC71CC: D6440002 03FE3302 0C070C03
	v_and_b32_e32 v25, 0xf0f0f0f, v26                          // 000000DC71D8: 363234FF 0F0F0F0F
	v_and_b32_e32 v26, 0xf0f0f0f, v42                          // 000000DC71E0: 363454FF 0F0F0F0F
	v_perm_b32 v42, v51, v43, 0xc040c00                        // 000000DC71E8: D644002A 03FE5733 0C040C00
	v_or_b32_e32 v2, 0x64006400, v2                            // 000000DC71F4: 380404FF 64006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DC71FC: BF870112
	v_or_b32_e32 v42, 0x64006400, v42                          // 000000DC7200: 385454FF 64006400
	.long 0xcc0f4002                                           // 000000DC7208: CC0F4002
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000DC720C: 120204FF 0000E408
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DC7214: BF870112
	.long 0xcc0f402a                                           // 000000DC7218: CC0F402A
	v_mul_i32_i24_e32 v1, 0xe408, v42                          // 000000DC721C: 120254FF 0000E408
	v_dot2acc_f32_f16 v49, v2, v48                             // 000000DC7224: 04626102
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000DC7228: BF870132
	v_dot2acc_f32_f16 v53, v42, v35                            // 000000DC722C: 046A472A
	v_perm_b32 v46, v26, v25, 0xc040c00                        // 000000DC7230: D644002E 03FE331A 0C040C00
	v_perm_b32 v44, v26, v25, 0xc050c01                        // 000000DC723C: D644002C 03FE331A 0C050C01
	v_or_b32_e32 v41, 0x64006400, v46                          // 000000DC7248: 38525CFF 64006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000DC7250: BF8701A2
	v_or_b32_e32 v35, 0x64006400, v44                          // 000000DC7254: 384658FF 64006400
	v_perm_b32 v44, v51, v43, 0xc050c01                        // 000000DC725C: D644002C 03FE5733 0C050C01
	.long 0xcc0f4002                                           // 000000DC7268: CC0F4002
	v_mul_i32_i24_e32 v1, 0xe408, v41                          // 000000DC726C: 120252FF 0000E408
	v_dot2acc_f32_f16 v50, v39, v40                            // 000000DC7274: 04645127
	v_perm_b32 v39, v26, v25, 0xc060c02                        // 000000DC7278: D6440027 03FE331A 0C060C02
	v_perm_b32 v25, v26, v25, 0xc070c03                        // 000000DC7284: D6440019 03FE331A 0C070C03
	s_waitcnt lgkmcnt(0)                                       // 000000DC7290: BF89FC07
	v_dot2acc_f32_f16 v49, v2, v29                             // 000000DC7294: 04623B02
	v_lshrrev_b32_e32 v2, 4, v27                               // 000000DC7298: 32043684
	.long 0xcc0f401d                                           // 000000DC729C: CC0F401D
	v_mul_i32_i24_e32 v1, 0xe408, v35                          // 000000DC72A0: 120246FF 0000E408
	v_or_b32_e32 v35, 0x64006400, v39                          // 000000DC72A8: 38464EFF 64006400
	v_and_b32_e32 v26, 0xf0f0f0f, v27                          // 000000DC72B0: 363436FF 0F0F0F0F
	ds_load_b128 v[39:42], v70 offset:8736                     // 000000DC72B8: DBFC2220 27000046
	v_or_b32_e32 v27, 0x64006400, v44                          // 000000DC72C0: 383658FF 64006400
	v_dot2acc_f32_f16 v49, v29, v30                            // 000000DC72C8: 04623D1D
	.long 0xcc0f401d                                           // 000000DC72CC: CC0F401D
	v_mul_i32_i24_e32 v1, 0xe408, v35                          // 000000DC72D0: 120246FF 0000E408
	v_and_b32_e32 v2, 0xf0f0f0f, v2                            // 000000DC72D8: 360404FF 0F0F0F0F
	v_or_b32_e32 v25, 0x64006400, v25                          // 000000DC72E0: 383232FF 64006400
	.long 0xcc0f401b                                           // 000000DC72E8: CC0F401B
	v_mul_i32_i24_e32 v1, 0xe408, v27                          // 000000DC72EC: 120236FF 0000E408
	v_perm_b32 v35, v51, v43, 0xc060c02                        // 000000DC72F4: D6440023 03FE5733 0C060C02
	v_dot2acc_f32_f16 v49, v29, v31                            // 000000DC7300: 04623F1D
	v_perm_b32 v30, v2, v26, 0xc040c00                         // 000000DC7304: D644001E 03FE3502 0C040C00
	.long 0xcc0f4019                                           // 000000DC7310: CC0F4019
	v_mul_i32_i24_e32 v1, 0xe408, v25                          // 000000DC7314: 120232FF 0000E408
	v_dot2acc_f32_f16 v53, v27, v36                            // 000000DC731C: 046A491B
	v_or_b32_e32 v31, 0x64006400, v35                          // 000000DC7320: 383E46FF 64006400
	v_perm_b32 v36, v51, v43, 0xc070c03                        // 000000DC7328: D6440024 03FE5733 0C070C03
	v_or_b32_e32 v29, 0x64006400, v30                          // 000000DC7334: 383A3CFF 64006400
	v_perm_b32 v30, v2, v26, 0xc050c01                         // 000000DC733C: D644001E 03FE3502 0C050C01
	v_dot2acc_f32_f16 v49, v25, v32                            // 000000DC7348: 04624119
	.long 0xcc0f4023                                           // 000000DC734C: CC0F4023
	v_mul_i32_i24_e32 v1, 0xe408, v31                          // 000000DC7350: 12023EFF 0000E408
	v_fma_mix_f32 v1, v3, v50, v1 op_sel_hi:[1,0,0]            // 000000DC7358: CC200001 0C066503
	.long 0xcc0f4019                                           // 000000DC7360: CC0F4019
	v_mul_i32_i24_e32 v1, 0xe408, v29                          // 000000DC7364: 12023AFF 0000E408
	v_or_b32_e32 v27, 0x64006400, v30                          // 000000DC736C: 38363CFF 64006400
	ds_load_b128 v[29:32], v70 offset:8752                     // 000000DC7374: DBFC2230 1D000046
	s_waitcnt lgkmcnt(1)                                       // 000000DC737C: BF89FC17
	v_dot2acc_f32_f16 v49, v25, v39                            // 000000DC7380: 04624F19
	.long 0xcc0f4019                                           // 000000DC7384: CC0F4019
	v_mul_i32_i24_e32 v1, 0xe408, v27                          // 000000DC7388: 120236FF 0000E408
	v_perm_b32 v27, v2, v26, 0xc060c02                         // 000000DC7390: D644001B 03FE3502 0C060C02
	v_perm_b32 v2, v2, v26, 0xc070c03                          // 000000DC739C: D6440002 03FE3502 0C070C03
	v_and_b32_e32 v39, 0xf0f0f0f, v28                          // 000000DC73A8: 364E38FF 0F0F0F0F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000DC73B0: BF870144
	v_dot2acc_f32_f16 v49, v25, v40                            // 000000DC73B4: 04625119
	s_waitcnt vmcnt(5)                                         // 000000DC73B8: BF8917F7
	v_lshrrev_b32_e32 v25, 4, v21                              // 000000DC73BC: 32322A84
	v_or_b32_e32 v2, 0x64006400, v2                            // 000000DC73C0: 380404FF 64006400
	v_and_b32_e32 v40, 0xf0f0f0f, v25                          // 000000DC73C8: 365032FF 0F0F0F0F
	v_dot2acc_f32_f16 v53, v35, v37                            // 000000DC73D0: 046A4B23
	v_or_b32_e32 v35, 0x64006400, v36                          // 000000DC73D4: 384648FF 64006400
	v_or_b32_e32 v36, 0x64006400, v27                          // 000000DC73DC: 384836FF 64006400
	v_lshrrev_b32_e32 v37, 4, v28                              // 000000DC73E4: 324A3884
	ds_load_b128 v[25:28], v70 offset:8960                     // 000000DC73E8: DBFC2300 19000046
	v_and_b32_e32 v21, 0xf0f0f0f, v21                          // 000000DC73F0: 362A2AFF 0F0F0F0F
	.long 0xcc0f4023                                           // 000000DC73F8: CC0F4023
	v_mul_i32_i24_e32 v1, 0xe408, v35                          // 000000DC73FC: 120246FF 0000E408
	.long 0xcc0f4024                                           // 000000DC7404: CC0F4024
	v_mul_i32_i24_e32 v1, 0xe408, v36                          // 000000DC7408: 120248FF 0000E408
	v_and_b32_e32 v43, 0xf0f0f0f, v37                          // 000000DC7410: 36564AFF 0F0F0F0F
	.long 0xcc0f4002                                           // 000000DC7418: CC0F4002
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000DC741C: 120204FF 0000E408
	v_perm_b32 v37, v40, v21, 0xc040c00                        // 000000DC7424: D6440025 03FE2B28 0C040C00
	v_dot2acc_f32_f16 v53, v35, v38                            // 000000DC7430: 046A4D23
	v_dot2acc_f32_f16 v49, v36, v41                            // 000000DC7434: 04625324
	v_perm_b32 v44, v43, v39, 0xc040c00                        // 000000DC7438: D644002C 03FE4F2B 0C040C00
	v_perm_b32 v45, v40, v21, 0xc060c02                        // 000000DC7444: D644002D 03FE2B28 0C060C02
	v_or_b32_e32 v36, 0x64006400, v37                          // 000000DC7450: 38484AFF 64006400
	v_perm_b32 v37, v40, v21, 0xc050c01                        // 000000DC7458: D6440025 03FE2B28 0C050C01
	v_dot2acc_f32_f16 v49, v2, v42                             // 000000DC7464: 04625502
	v_or_b32_e32 v35, 0x64006400, v44                          // 000000DC7468: 384658FF 64006400
	v_mov_b32_e32 v44, 0                                       // 000000DC7470: 7E580280
	.long 0xcc0f4002                                           // 000000DC7474: CC0F4002
	v_mul_i32_i24_e32 v1, 0xe408, v36                          // 000000DC7478: 120248FF 0000E408
	v_or_b32_e32 v42, 0x64006400, v37                          // 000000DC7480: 38544AFF 64006400
	v_fma_mix_f32 v1, v3, v53, v1 op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000DC7488: CC200801 0C066B03
	.long 0xcc0f4029                                           // 000000DC7490: CC0F4029
	v_mul_i32_i24_e32 v1, 0xe408, v35                          // 000000DC7494: 120246FF 0000E408
	ds_load_b128 v[35:38], v70 offset:8976                     // 000000DC749C: DBFC2310 23000046
	s_waitcnt lgkmcnt(1)                                       // 000000DC74A4: BF89FC17
	v_dot2acc_f32_f16 v44, v2, v25                             // 000000DC74A8: 04583302
	.long 0xcc0f4019                                           // 000000DC74AC: CC0F4019
	v_mul_i32_i24_e32 v1, 0xe408, v42                          // 000000DC74B0: 120254FF 0000E408
	v_or_b32_e32 v42, 0x64006400, v45                          // 000000DC74B8: 38545AFF 64006400
	v_lshrrev_b32_e32 v2, 4, v22                               // 000000DC74C0: 32042C84
	v_and_b32_e32 v22, 0xf0f0f0f, v22                          // 000000DC74C4: 362C2CFF 0F0F0F0F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DC74CC: BF870214
	v_dot2acc_f32_f16 v44, v25, v26                            // 000000DC74D0: 04583519
	.long 0xcc0f4019                                           // 000000DC74D4: CC0F4019
	v_mul_i32_i24_e32 v1, 0xe408, v42                          // 000000DC74D8: 120254FF 0000E408
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DC74E0: BF870114
	v_and_b32_e32 v2, 0xf0f0f0f, v2                            // 000000DC74E4: 360404FF 0F0F0F0F
	v_dot2acc_f32_f16 v44, v25, v27                            // 000000DC74EC: 04583719
	v_perm_b32 v21, v40, v21, 0xc070c03                        // 000000DC74F0: D6440015 03FE2B28 0C070C03
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000DC74FC: BF8701A3
	v_perm_b32 v26, v2, v22, 0xc040c00                         // 000000DC7500: D644001A 03FE2D02 0C040C00
	v_perm_b32 v27, v2, v22, 0xc050c01                         // 000000DC750C: D644001B 03FE2D02 0C050C01
	v_or_b32_e32 v21, 0x64006400, v21                          // 000000DC7518: 382A2AFF 64006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DC7520: BF870113
	v_or_b32_e32 v25, 0x64006400, v26                          // 000000DC7524: 383234FF 64006400
	.long 0xcc0f4015                                           // 000000DC752C: CC0F4015
	v_mul_i32_i24_e32 v1, 0xe408, v21                          // 000000DC7530: 12022AFF 0000E408
	s_delay_alu instid0(VALU_DEP_2)                            // 000000DC7538: BF870002
	.long 0xcc0f4003                                           // 000000DC753C: CC0F4003
	v_mul_i32_i24_e32 v1, 0xe408, v25                          // 000000DC7540: 120232FF 0000E408
	v_perm_b32 v25, v2, v22, 0xc060c02                         // 000000DC7548: D6440019 03FE2D02 0C060C02
	v_perm_b32 v2, v2, v22, 0xc070c03                          // 000000DC7554: D6440002 03FE2D02 0C070C03
	v_and_b32_e32 v22, 0xf0f0f0f, v23                          // 000000DC7560: 362C2EFF 0F0F0F0F
	v_dot2acc_f32_f16 v44, v21, v28                            // 000000DC7568: 04583915
	v_perm_b32 v40, v43, v39, 0xc050c01                        // 000000DC756C: D6440028 03FE4F2B 0C050C01
	v_or_b32_e32 v21, 0x64006400, v27                          // 000000DC7578: 382A36FF 64006400
	v_or_b32_e32 v2, 0x64006400, v2                            // 000000DC7580: 380404FF 64006400
	s_waitcnt lgkmcnt(0)                                       // 000000DC7588: BF89FC07
	v_dot2acc_f32_f16 v44, v3, v35                             // 000000DC758C: 04584703
	v_or_b32_e32 v40, 0x64006400, v40                          // 000000DC7590: 385050FF 64006400
	.long 0xcc0f4015                                           // 000000DC7598: CC0F4015
	v_mul_i32_i24_e32 v1, 0xe408, v21                          // 000000DC759C: 12022AFF 0000E408
	.long 0xcc0f4002                                           // 000000DC75A4: CC0F4002
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000DC75A8: 120204FF 0000E408
	v_lshrrev_b32_e32 v3, 4, v23                               // 000000DC75B0: 32062E84
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DC75B4: BF870214
	.long 0xcc0f401a                                           // 000000DC75B8: CC0F401A
	v_mul_i32_i24_e32 v1, 0xe408, v40                          // 000000DC75BC: 120250FF 0000E408
	v_dot2acc_f32_f16 v44, v21, v36                            // 000000DC75C4: 04584915
	v_dot2acc_f32_f16 v49, v41, v29                            // 000000DC75C8: 04623B29
	v_perm_b32 v29, v43, v39, 0xc060c02                        // 000000DC75CC: D644001D 03FE4F2B 0C060C02
	s_delay_alu instid0(VALU_DEP_2)                            // 000000DC75D8: BF870002
	v_dot2acc_f32_f16 v49, v26, v30                            // 000000DC75DC: 04623D1A
	v_or_b32_e32 v30, 0x64006400, v25                          // 000000DC75E0: 383C32FF 64006400
	ds_load_b128 v[25:28], v70 offset:8992                     // 000000DC75E8: DBFC2320 19000046
	v_or_b32_e32 v23, 0x64006400, v29                          // 000000DC75F0: 382E3AFF 64006400
	.long 0xcc0f4015                                           // 000000DC75F8: CC0F4015
	v_mul_i32_i24_e32 v1, 0xe408, v30                          // 000000DC75FC: 12023CFF 0000E408
	v_perm_b32 v30, v43, v39, 0xc070c03                        // 000000DC7604: D644001E 03FE4F2B 0C070C03
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000DC7610: BF8700B3
	.long 0xcc0f4017                                           // 000000DC7614: CC0F4017
	v_mul_i32_i24_e32 v1, 0xe408, v23                          // 000000DC7618: 12022EFF 0000E408
	ds_load_b128 v[39:42], v70 offset:9216                     // 000000DC7620: DBFC2400 27000046
	v_dual_mov_b32 v43, 0 :: v_dual_dot2acc_f32_f16 v44, v21, v37// 000000DC7628: CA180080 2B2C4B15
	v_dot2acc_f32_f16 v44, v2, v38                             // 000000DC7630: 04584D02
	ds_load_b128 v[35:38], v70 offset:9008                     // 000000DC7634: DBFC2330 23000046
	v_and_b32_e32 v3, 0xf0f0f0f, v3                            // 000000DC763C: 360606FF 0F0F0F0F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DC7644: BF870091
	v_perm_b32 v29, v3, v22, 0xc040c00                         // 000000DC7648: D644001D 03FE2D03 0C040C00
	v_or_b32_e32 v21, 0x64006400, v29                          // 000000DC7654: 382A3AFF 64006400
	v_or_b32_e32 v29, 0x64006400, v30                          // 000000DC765C: 383A3CFF 64006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DC7664: BF870112
	.long 0xcc0f4002                                           // 000000DC7668: CC0F4002
	v_mul_i32_i24_e32 v1, 0xe408, v21                          // 000000DC766C: 12022AFF 0000E408
	.long 0xcc0f4015                                           // 000000DC7674: CC0F4015
	v_mul_i32_i24_e32 v1, 0xe408, v29                          // 000000DC7678: 12023AFF 0000E408
	s_waitcnt lgkmcnt(2)                                       // 000000DC7680: BF89FC27
	s_delay_alu instid0(VALU_DEP_2)                            // 000000DC7684: BF870002
	v_dot2acc_f32_f16 v44, v2, v25                             // 000000DC7688: 04583302
	v_perm_b32 v30, v3, v22, 0xc050c01                         // 000000DC768C: D644001E 03FE2D03 0C050C01
	v_perm_b32 v29, v3, v22, 0xc060c02                         // 000000DC7698: D644001D 03FE2D03 0C060C02
	s_waitcnt vmcnt(4)                                         // 000000DC76A4: BF8913F7
	v_lshrrev_b32_e32 v2, 4, v17                               // 000000DC76A8: 32042284
	v_dot2acc_f32_f16 v49, v23, v31                            // 000000DC76AC: 04623F17
	v_perm_b32 v3, v3, v22, 0xc070c03                          // 000000DC76B0: D6440003 03FE2D03 0C070C03
	v_or_b32_e32 v23, 0x64006400, v30                          // 000000DC76BC: 382E3CFF 64006400
	v_or_b32_e32 v25, 0x64006400, v29                          // 000000DC76C4: 38323AFF 64006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DC76CC: BF870214
	v_dual_dot2acc_f32_f16 v49, v21, v32 :: v_dual_and_b32 v2, 0xf0f0f0f, v2// 000000DC76D0: CB244115 310204FF 0F0F0F0F
	v_or_b32_e32 v3, 0x64006400, v3                            // 000000DC76DC: 380606FF 64006400
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DC76E4: BF870004
	.long 0xcc0f4017                                           // 000000DC76E8: CC0F4017
	v_mul_i32_i24_e32 v1, 0xe408, v23                          // 000000DC76EC: 12022EFF 0000E408
	v_and_b32_e32 v17, 0xf0f0f0f, v17                          // 000000DC76F4: 362222FF 0F0F0F0F
	.long 0xcc0f4015                                           // 000000DC76FC: CC0F4015
	v_mul_i32_i24_e32 v1, 0xe408, v25                          // 000000DC7700: 120232FF 0000E408
	v_and_b32_e32 v29, 0xf0f0f0f, v24                          // 000000DC7708: 363A30FF 0F0F0F0F
	.long 0xcc0f4003                                           // 000000DC7710: CC0F4003
	v_mul_i32_i24_e32 v1, 0xe408, v3                           // 000000DC7714: 120206FF 0000E408
	v_dot2acc_f32_f16 v44, v23, v26                            // 000000DC771C: 04583517
	v_perm_b32 v22, v2, v17, 0xc040c00                         // 000000DC7720: D6440016 03FE2302 0C040C00
	v_perm_b32 v23, v2, v17, 0xc050c01                         // 000000DC772C: D6440017 03FE2302 0C050C01
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DC7738: BF870193
	v_dot2acc_f32_f16 v44, v21, v27                            // 000000DC773C: 04583715
	v_or_b32_e32 v21, 0x64006400, v22                          // 000000DC7740: 382A2CFF 64006400
	v_lshrrev_b32_e32 v22, 4, v24                              // 000000DC7748: 322C3084
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DC774C: BF870004
	v_or_b32_e32 v26, 0x64006400, v23                          // 000000DC7750: 38342EFF 64006400
	v_perm_b32 v27, v2, v17, 0xc060c02                         // 000000DC7758: D644001B 03FE2302 0C060C02
	v_perm_b32 v2, v2, v17, 0xc070c03                          // 000000DC7764: D6440002 03FE2302 0C070C03
	.long 0xcc0f4019                                           // 000000DC7770: CC0F4019
	v_mul_i32_i24_e32 v1, 0xe408, v21                          // 000000DC7774: 12022AFF 0000E408
	v_and_b32_e32 v30, 0xf0f0f0f, v22                          // 000000DC777C: 363C2CFF 0F0F0F0F
	ds_load_b128 v[21:24], v70 offset:9232                     // 000000DC7784: DBFC2410 15000046
	v_dual_dot2acc_f32_f16 v44, v3, v28 :: v_dual_and_b32 v17, 0xf0f0f0f, v18// 000000DC778C: CB243903 2C1024FF 0F0F0F0F
	s_waitcnt lgkmcnt(2)                                       // 000000DC7798: BF89FC27
	v_dot2acc_f32_f16 v43, v25, v39                            // 000000DC779C: 04564F19
	v_lshrrev_b32_e32 v25, 4, v18                              // 000000DC77A0: 32322484
	.long 0xcc0f401a                                           // 000000DC77A4: CC0F401A
	v_mul_i32_i24_e32 v1, 0xe408, v26                          // 000000DC77A8: 120234FF 0000E408
	v_or_b32_e32 v27, 0x64006400, v27                          // 000000DC77B0: 383636FF 64006400
	v_or_b32_e32 v2, 0x64006400, v2                            // 000000DC77B8: 380404FF 64006400
	v_fma_mix_f32 v1, v4, v49, v1 op_sel_hi:[1,0,0]            // 000000DC77C0: CC200001 0C066304
	v_and_b32_e32 v18, 0xf0f0f0f, v25                          // 000000DC77C8: 362432FF 0F0F0F0F
	v_perm_b32 v25, v30, v29, 0xc040c00                        // 000000DC77D0: D6440019 03FE3B1E 0C040C00
	v_dot2acc_f32_f16 v43, v26, v40                            // 000000DC77DC: 0456511A
	.long 0xcc0f401a                                           // 000000DC77E0: CC0F401A
	v_mul_i32_i24_e32 v1, 0xe408, v27                          // 000000DC77E4: 120236FF 0000E408
	.long 0xcc0f4002                                           // 000000DC77EC: CC0F4002
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000DC77F0: 120204FF 0000E408
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DC77F8: BF870194
	v_or_b32_e32 v25, 0x64006400, v25                          // 000000DC77FC: 383232FF 64006400
	v_dot2acc_f32_f16 v43, v26, v41                            // 000000DC7804: 0456531A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DC7808: BF8700A2
	.long 0xcc0f4019                                           // 000000DC780C: CC0F4019
	v_mul_i32_i24_e32 v1, 0xe408, v25                          // 000000DC7810: 120232FF 0000E408
	s_waitcnt lgkmcnt(1)                                       // 000000DC7818: BF89FC17
	v_dual_dot2acc_f32_f16 v43, v2, v42 :: v_dual_dot2acc_f32_f16 v44, v25, v35// 000000DC781C: CB185502 2B2C4719
	v_perm_b32 v27, v18, v17, 0xc040c00                        // 000000DC7824: D644001B 03FE2312 0C040C00
	v_perm_b32 v26, v18, v17, 0xc050c01                        // 000000DC7830: D644001A 03FE2312 0C050C01
	v_perm_b32 v25, v18, v17, 0xc060c02                        // 000000DC783C: D6440019 03FE2312 0C060C02
	v_perm_b32 v17, v18, v17, 0xc070c03                        // 000000DC7848: D6440011 03FE2312 0C070C03
	v_and_b32_e32 v18, 0xf0f0f0f, v19                          // 000000DC7854: 362426FF 0F0F0F0F
	v_or_b32_e32 v3, 0x64006400, v27                           // 000000DC785C: 380636FF 64006400
	v_perm_b32 v27, v30, v29, 0xc050c01                        // 000000DC7864: D644001B 03FE3B1E 0C050C01
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DC7870: BF870194
	v_or_b32_e32 v17, 0x64006400, v17                          // 000000DC7874: 382222FF 64006400
	.long 0xcc0f4002                                           // 000000DC787C: CC0F4002
	v_mul_i32_i24_e32 v1, 0xe408, v3                           // 000000DC7880: 120206FF 0000E408
	v_or_b32_e32 v3, 0x64006400, v26                           // 000000DC7888: 380634FF 64006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000DC7890: BF8701A4
	v_or_b32_e32 v31, 0x64006400, v27                          // 000000DC7894: 383E36FF 64006400
	s_waitcnt lgkmcnt(0)                                       // 000000DC789C: BF89FC07
	v_dot2acc_f32_f16 v43, v2, v21                             // 000000DC78A0: 04562B02
	v_lshrrev_b32_e32 v2, 4, v19                               // 000000DC78A4: 32042684
	.long 0xcc0f4003                                           // 000000DC78A8: CC0F4003
	v_mul_i32_i24_e32 v1, 0xe408, v3                           // 000000DC78AC: 120206FF 0000E408
	v_or_b32_e32 v21, 0x64006400, v25                          // 000000DC78B4: 382A32FF 64006400
	ds_load_b128 v[25:28], v70 offset:9248                     // 000000DC78BC: DBFC2420 19000046
	v_perm_b32 v19, v30, v29, 0xc060c02                        // 000000DC78C4: D6440013 03FE3B1E 0C060C02
	v_and_b32_e32 v2, 0xf0f0f0f, v2                            // 000000DC78D0: 360404FF 0F0F0F0F
	v_dot2acc_f32_f16 v43, v3, v22                             // 000000DC78D8: 04562D03
	.long 0xcc0f4003                                           // 000000DC78DC: CC0F4003
	v_mul_i32_i24_e32 v1, 0xe408, v21                          // 000000DC78E0: 12022AFF 0000E408
	.long 0xcc0f4016                                           // 000000DC78E8: CC0F4016
	v_mul_i32_i24_e32 v1, 0xe408, v31                          // 000000DC78EC: 12023EFF 0000E408
	v_or_b32_e32 v19, 0x64006400, v19                          // 000000DC78F4: 382626FF 64006400
	v_perm_b32 v21, v2, v18, 0xc040c00                         // 000000DC78FC: D6440015 03FE2502 0C040C00
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000DC7908: BF870233
	v_dot2acc_f32_f16 v44, v22, v36                            // 000000DC790C: 04584916
	v_dual_mov_b32 v36, 0 :: v_dual_dot2acc_f32_f16 v43, v3, v23// 000000DC7910: CA180080 242A2F03
	.long 0xcc0f4003                                           // 000000DC7918: CC0F4003
	v_mul_i32_i24_e32 v1, 0xe408, v17                          // 000000DC791C: 120222FF 0000E408
	v_or_b32_e32 v17, 0x64006400, v21                          // 000000DC7924: 38222AFF 64006400
	v_perm_b32 v21, v2, v18, 0xc050c01                         // 000000DC792C: D6440015 03FE2502 0C050C01
	.long 0xcc0f4013                                           // 000000DC7938: CC0F4013
	v_mul_i32_i24_e32 v1, 0xe408, v19                          // 000000DC793C: 120226FF 0000E408
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DC7944: BF870214
	v_dot2acc_f32_f16 v43, v3, v24                             // 000000DC7948: 04563103
	.long 0xcc0f4003                                           // 000000DC794C: CC0F4003
	v_mul_i32_i24_e32 v1, 0xe408, v17                          // 000000DC7950: 120222FF 0000E408
	v_perm_b32 v17, v30, v29, 0xc070c03                        // 000000DC7958: D6440011 03FE3B1E 0C070C03
	v_or_b32_e32 v29, 0x64006400, v21                          // 000000DC7964: 383A2AFF 64006400
	v_perm_b32 v30, v2, v18, 0xc060c02                         // 000000DC796C: D644001E 03FE2502 0C060C02
	ds_load_b128 v[21:24], v70 offset:9264                     // 000000DC7978: DBFC2430 15000046
	v_dot2acc_f32_f16 v44, v19, v37                            // 000000DC7980: 04584B13
	s_waitcnt lgkmcnt(1)                                       // 000000DC7984: BF89FC17
	v_dot2acc_f32_f16 v43, v3, v25                             // 000000DC7988: 04563303
	s_waitcnt vmcnt(3)                                         // 000000DC798C: BF890FF7
	v_lshrrev_b32_e32 v3, 4, v13                               // 000000DC7990: 32061A84
	.long 0xcc0f4019                                           // 000000DC7994: CC0F4019
	v_mul_i32_i24_e32 v1, 0xe408, v29                          // 000000DC7998: 12023AFF 0000E408
	v_or_b32_e32 v35, 0x64006400, v30                          // 000000DC79A0: 38463CFF 64006400
	ds_load_b128 v[29:32], v70 offset:9472                     // 000000DC79A8: DBFC2500 1D000046
	v_and_b32_e32 v13, 0xf0f0f0f, v13                          // 000000DC79B0: 361A1AFF 0F0F0F0F
	v_and_b32_e32 v3, 0xf0f0f0f, v3                            // 000000DC79B8: 360606FF 0F0F0F0F
	v_or_b32_e32 v17, 0x64006400, v17                          // 000000DC79C0: 382222FF 64006400
	v_dot2acc_f32_f16 v43, v25, v26                            // 000000DC79C8: 04563519
	v_perm_b32 v2, v2, v18, 0xc070c03                          // 000000DC79CC: D6440002 03FE2502 0C070C03
	.long 0xcc0f4012                                           // 000000DC79D8: CC0F4012
	v_mul_i32_i24_e32 v1, 0xe408, v35                          // 000000DC79DC: 120246FF 0000E408
	v_perm_b32 v25, v3, v13, 0xc040c00                         // 000000DC79E4: D6440019 03FE1B03 0C040C00
	.long 0xcc0f401a                                           // 000000DC79F0: CC0F401A
	v_mul_i32_i24_e32 v1, 0xe408, v17                          // 000000DC79F4: 120222FF 0000E408
	v_perm_b32 v19, v3, v13, 0xc050c01                         // 000000DC79FC: D6440013 03FE1B03 0C050C01
	v_and_b32_e32 v35, 0xf0f0f0f, v20                          // 000000DC7A08: 364628FF 0F0F0F0F
	v_dot2acc_f32_f16 v43, v18, v27                            // 000000DC7A10: 04563712
	v_or_b32_e32 v17, 0x64006400, v25                          // 000000DC7A14: 382232FF 64006400
	v_lshrrev_b32_e32 v18, 4, v20                              // 000000DC7A1C: 32242884
	v_or_b32_e32 v27, 0x64006400, v19                          // 000000DC7A20: 383626FF 64006400
	v_or_b32_e32 v2, 0x64006400, v2                            // 000000DC7A28: 380404FF 64006400
	v_dot2acc_f32_f16 v44, v26, v38                            // 000000DC7A30: 04584D1A
	.long 0xcc0f4019                                           // 000000DC7A34: CC0F4019
	v_mul_i32_i24_e32 v1, 0xe408, v17                          // 000000DC7A38: 120222FF 0000E408
	v_and_b32_e32 v37, 0xf0f0f0f, v18                          // 000000DC7A40: 364A24FF 0F0F0F0F
	ds_load_b128 v[17:20], v70 offset:9488                     // 000000DC7A48: DBFC2510 11000046
	.long 0xcc0f401b                                           // 000000DC7A50: CC0F401B
	v_mul_i32_i24_e32 v1, 0xe408, v27                          // 000000DC7A54: 120236FF 0000E408
	.long 0xcc0f4002                                           // 000000DC7A5C: CC0F4002
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000DC7A60: 120204FF 0000E408
	s_waitcnt lgkmcnt(1)                                       // 000000DC7A68: BF89FC17
	v_dot2acc_f32_f16 v36, v25, v29                            // 000000DC7A6C: 04483B19
	v_lshrrev_b32_e32 v25, 4, v14                              // 000000DC7A70: 32321C84
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 000000DC7A74: BF870252
	v_dual_dot2acc_f32_f16 v43, v2, v28 :: v_dual_dot2acc_f32_f16 v36, v27, v30// 000000DC7A78: CB183902 2B243D1B
	v_perm_b32 v39, v3, v13, 0xc060c02                         // 000000DC7A80: D6440027 03FE1B03 0C060C02
	v_perm_b32 v3, v3, v13, 0xc070c03                          // 000000DC7A8C: D6440003 03FE1B03 0C070C03
	v_and_b32_e32 v13, 0xf0f0f0f, v14                          // 000000DC7A98: 361A1CFF 0F0F0F0F
	v_and_b32_e32 v14, 0xf0f0f0f, v25                          // 000000DC7AA0: 361C32FF 0F0F0F0F
	v_or_b32_e32 v29, 0x64006400, v39                          // 000000DC7AA8: 383A4EFF 64006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DC7AB0: BF870114
	v_or_b32_e32 v3, 0x64006400, v3                            // 000000DC7AB4: 380606FF 64006400
	.long 0xcc0f401b                                           // 000000DC7ABC: CC0F401B
	v_mul_i32_i24_e32 v1, 0xe408, v29                          // 000000DC7AC0: 12023AFF 0000E408
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DC7AC8: BF870194
	v_perm_b32 v29, v14, v13, 0xc040c00                        // 000000DC7ACC: D644001D 03FE1B0E 0C040C00
	.long 0xcc0f4002                                           // 000000DC7AD8: CC0F4002
	v_mul_i32_i24_e32 v1, 0xe408, v3                           // 000000DC7ADC: 120206FF 0000E408
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DC7AE4: BF870193
	v_dot2acc_f32_f16 v36, v27, v31                            // 000000DC7AE8: 04483F1B
	v_or_b32_e32 v3, 0x64006400, v29                           // 000000DC7AEC: 38063AFF 64006400
	v_perm_b32 v27, v14, v13, 0xc050c01                        // 000000DC7AF4: D644001B 03FE1B0E 0C050C01
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DC7B00: BF870193
	v_dot2acc_f32_f16 v36, v2, v32                             // 000000DC7B04: 04484102
	.long 0xcc0f4002                                           // 000000DC7B08: CC0F4002
	v_mul_i32_i24_e32 v1, 0xe408, v3                           // 000000DC7B0C: 120206FF 0000E408
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000DC7B14: BF870123
	v_or_b32_e32 v3, 0x64006400, v27                           // 000000DC7B18: 380636FF 64006400
	s_waitcnt lgkmcnt(0)                                       // 000000DC7B20: BF89FC07
	v_dot2acc_f32_f16 v36, v2, v17                             // 000000DC7B24: 04482302
	v_perm_b32 v25, v37, v35, 0xc040c00                        // 000000DC7B28: D6440019 03FE4725 0C040C00
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000DC7B34: BF8701A3
	.long 0xcc0f4003                                           // 000000DC7B38: CC0F4003
	v_mul_i32_i24_e32 v1, 0xe408, v3                           // 000000DC7B3C: 120206FF 0000E408
	v_lshrrev_b32_e32 v2, 4, v15                               // 000000DC7B44: 32041E84
	v_or_b32_e32 v25, 0x64006400, v25                          // 000000DC7B48: 383232FF 64006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DC7B50: BF870193
	v_dot2acc_f32_f16 v36, v3, v18                             // 000000DC7B54: 04482503
	v_and_b32_e32 v2, 0xf0f0f0f, v2                            // 000000DC7B58: 360404FF 0F0F0F0F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DC7B60: BF870093
	.long 0xcc0f4019                                           // 000000DC7B64: CC0F4019
	v_mul_i32_i24_e32 v1, 0xe408, v25                          // 000000DC7B68: 120232FF 0000E408
	v_dot2acc_f32_f16 v43, v25, v21                            // 000000DC7B70: 04562B19
	v_perm_b32 v21, v14, v13, 0xc060c02                        // 000000DC7B74: D6440015 03FE1B0E 0C060C02
	v_perm_b32 v13, v14, v13, 0xc070c03                        // 000000DC7B80: D644000D 03FE1B0E 0C070C03
	v_and_b32_e32 v14, 0xf0f0f0f, v15                          // 000000DC7B8C: 361C1EFF 0F0F0F0F
	ds_load_b128 v[25:28], v70 offset:9504                     // 000000DC7B94: DBFC2520 19000046
	v_or_b32_e32 v17, 0x64006400, v21                          // 000000DC7B9C: 38222AFF 64006400
	v_or_b32_e32 v13, 0x64006400, v13                          // 000000DC7BA4: 381A1AFF 64006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000DC7BAC: BF870122
	.long 0xcc0f4003                                           // 000000DC7BB0: CC0F4003
	v_mul_i32_i24_e32 v1, 0xe408, v17                          // 000000DC7BB4: 120222FF 0000E408
	v_perm_b32 v17, v2, v14, 0xc040c00                         // 000000DC7BBC: D6440011 03FE1D02 0C040C00
	v_dot2acc_f32_f16 v36, v3, v19                             // 000000DC7BC8: 04482703
	v_perm_b32 v29, v37, v35, 0xc050c01                        // 000000DC7BCC: D644001D 03FE4725 0C050C01
	v_perm_b32 v18, v37, v35, 0xc060c02                        // 000000DC7BD8: D6440012 03FE4725 0C060C02
	.long 0xcc0f4003                                           // 000000DC7BE4: CC0F4003
	v_mul_i32_i24_e32 v1, 0xe408, v13                          // 000000DC7BE8: 12021AFF 0000E408
	v_or_b32_e32 v13, 0x64006400, v17                          // 000000DC7BF0: 381A22FF 64006400
	v_perm_b32 v17, v2, v14, 0xc050c01                         // 000000DC7BF8: D6440011 03FE1D02 0C050C01
	v_or_b32_e32 v15, 0x64006400, v29                          // 000000DC7C04: 381E3AFF 64006400
	v_or_b32_e32 v18, 0x64006400, v18                          // 000000DC7C0C: 382424FF 64006400
	v_dot2acc_f32_f16 v36, v3, v20                             // 000000DC7C14: 04482903
	.long 0xcc0f4003                                           // 000000DC7C18: CC0F4003
	v_mul_i32_i24_e32 v1, 0xe408, v13                          // 000000DC7C1C: 12021AFF 0000E408
	v_or_b32_e32 v13, 0x64006400, v17                          // 000000DC7C24: 381A22FF 64006400
	.long 0xcc0f400f                                           // 000000DC7C2C: CC0F400F
	v_mul_i32_i24_e32 v1, 0xe408, v15                          // 000000DC7C30: 12021EFF 0000E408
	v_perm_b32 v21, v37, v35, 0xc070c03                        // 000000DC7C38: D6440015 03FE4725 0C070C03
	s_delay_alu instid0(VALU_DEP_2)                            // 000000DC7C44: BF870002
	v_dual_dot2acc_f32_f16 v43, v15, v22 :: v_dual_and_b32 v22, 0xf0f0f0f, v16// 000000DC7C48: CB242D0F 2B1620FF 0F0F0F0F
	.long 0xcc0f400f                                           // 000000DC7C54: CC0F400F
	v_mul_i32_i24_e32 v1, 0xe408, v18                          // 000000DC7C58: 120224FF 0000E408
	ds_load_b128 v[17:20], v70 offset:9520                     // 000000DC7C60: DBFC2530 11000046
	s_waitcnt lgkmcnt(1)                                       // 000000DC7C68: BF89FC17
	v_dot2acc_f32_f16 v36, v3, v25                             // 000000DC7C6C: 04483303
	.long 0xcc0f4003                                           // 000000DC7C70: CC0F4003
	v_mul_i32_i24_e32 v1, 0xe408, v13                          // 000000DC7C74: 12021AFF 0000E408
	v_perm_b32 v13, v2, v14, 0xc060c02                         // 000000DC7C7C: D644000D 03FE1D02 0C060C02
	v_perm_b32 v14, v2, v14, 0xc070c03                         // 000000DC7C88: D644000E 03FE1D02 0C070C03
	v_fma_mix_f32 v25, v4, v44, v1 op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000DC7C94: CC200819 0C065904
	s_waitcnt vmcnt(2)                                         // 000000DC7C9C: BF890BF7
	v_lshrrev_b32_e32 v1, 4, v9                                // 000000DC7CA0: 32021284
	v_dual_dot2acc_f32_f16 v36, v3, v26 :: v_dual_and_b32 v9, 0xf0f0f0f, v9// 000000DC7CA4: CB243503 240812FF 0F0F0F0F
	v_or_b32_e32 v13, 0x64006400, v13                          // 000000DC7CB0: 381A1AFF 64006400
	v_or_b32_e32 v14, 0x64006400, v14                          // 000000DC7CB8: 381C1CFF 64006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DC7CC0: BF870092
	.long 0xcc0f400d                                           // 000000DC7CC4: CC0F400D
	v_mul_i32_i24_e32 v1, 0xe408, v13                          // 000000DC7CC8: 12021AFF 0000E408
	v_dot2acc_f32_f16 v36, v13, v27                            // 000000DC7CD0: 0448370D
	s_delay_alu instid0(VALU_DEP_3)                            // 000000DC7CD4: BF870003
	.long 0xcc0f400d                                           // 000000DC7CD8: CC0F400D
	v_mul_i32_i24_e32 v1, 0xe408, v14                          // 000000DC7CDC: 12021CFF 0000E408
	v_dot2acc_f32_f16 v43, v15, v23                            // 000000DC7CE4: 04562F0F
	v_or_b32_e32 v15, 0x64006400, v21                          // 000000DC7CE8: 381E2AFF 64006400
	v_lshrrev_b32_e32 v21, 4, v16                              // 000000DC7CF0: 322A2084
	v_and_b32_e32 v23, 0xf0f0f0f, v1                           // 000000DC7CF4: 362E02FF 0F0F0F0F
	ds_load_b128 v[1:4], v70 offset:9728                       // 000000DC7CFC: DBFC2600 01000046
	v_dot2acc_f32_f16 v36, v13, v28                            // 000000DC7D04: 0448390D
	.long 0xcc0f400f                                           // 000000DC7D08: CC0F400F
	v_mul_i32_i24_e32 v1, 0xe408, v15                          // 000000DC7D0C: 12021EFF 0000E408
	v_and_b32_e32 v21, 0xf0f0f0f, v21                          // 000000DC7D14: 362A2AFF 0F0F0F0F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DC7D1C: BF870112
	v_dot2acc_f32_f16 v43, v15, v24                            // 000000DC7D20: 0456310F
	v_perm_b32 v26, v21, v22, 0xc040c00                        // 000000DC7D24: D644001A 03FE2D15 0C040C00
	s_waitcnt vmcnt(0)                                         // 000000DC7D30: BF8903F7
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DC7D34: BF870112
	v_fma_mix_f32 v25, v33, v43, v25 op_sel_hi:[1,0,0]         // 000000DC7D38: CC200019 0C665721
	v_or_b32_e32 v15, 0x64006400, v26                          // 000000DC7D40: 381E34FF 64006400
	v_mov_b32_e32 v26, 0                                       // 000000DC7D48: 7E340280
	v_perm_b32 v16, v23, v9, 0xc040c00                         // 000000DC7D4C: D6440010 03FE1317 0C040C00
	v_perm_b32 v29, v23, v9, 0xc060c02                         // 000000DC7D58: D644001D 03FE1317 0C060C02
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DC7D64: BF870194
	.long 0xcc0f401b                                           // 000000DC7D68: CC0F401B
	v_mul_i32_i24_e32 v1, 0xe408, v15                          // 000000DC7D6C: 12021EFF 0000E408
	v_or_b32_e32 v14, 0x64006400, v16                          // 000000DC7D74: 381C20FF 64006400
	v_perm_b32 v16, v23, v9, 0xc050c01                         // 000000DC7D7C: D6440010 03FE1317 0C050C01
	v_perm_b32 v9, v23, v9, 0xc070c03                          // 000000DC7D88: D6440009 03FE1317 0C070C03
	s_waitcnt lgkmcnt(1)                                       // 000000DC7D94: BF89FC17
	v_dot2acc_f32_f16 v36, v27, v17                            // 000000DC7D98: 0448231B
	.long 0xcc0f4018                                           // 000000DC7D9C: CC0F4018
	v_mul_i32_i24_e32 v1, 0xe408, v14                          // 000000DC7DA0: 12021CFF 0000E408
	v_or_b32_e32 v28, 0x64006400, v16                          // 000000DC7DA8: 383820FF 64006400
	ds_load_b128 v[13:16], v70 offset:9744                     // 000000DC7DB0: DBFC2610 0D000046
	v_or_b32_e32 v9, 0x64006400, v9                            // 000000DC7DB8: 381212FF 64006400
	s_waitcnt lgkmcnt(1)                                       // 000000DC7DC0: BF89FC17
	v_dot2acc_f32_f16 v26, v24, v1                             // 000000DC7DC4: 04340318
	v_lshrrev_b32_e32 v1, 4, v10                               // 000000DC7DC8: 32021484
	.long 0xcc0f4018                                           // 000000DC7DCC: CC0F4018
	v_mul_i32_i24_e32 v1, 0xe408, v28                          // 000000DC7DD0: 120238FF 0000E408
	v_or_b32_e32 v28, 0x64006400, v29                          // 000000DC7DD8: 38383AFF 64006400
	v_and_b32_e32 v10, 0xf0f0f0f, v10                          // 000000DC7DE0: 361414FF 0F0F0F0F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DC7DE8: BF870193
	v_dot2acc_f32_f16 v26, v24, v2                             // 000000DC7DEC: 04340518
	.long 0xcc0f4002                                           // 000000DC7DF0: CC0F4002
	v_mul_i32_i24_e32 v1, 0xe408, v28                          // 000000DC7DF4: 120238FF 0000E408
	v_and_b32_e32 v1, 0xf0f0f0f, v1                            // 000000DC7DFC: 360202FF 0F0F0F0F
	v_perm_b32 v23, v21, v22, 0xc050c01                        // 000000DC7E04: D6440017 03FE2D15 0C050C01
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DC7E10: BF870193
	v_dot2acc_f32_f16 v26, v2, v3                              // 000000DC7E14: 04340702
	v_perm_b32 v24, v1, v10, 0xc040c00                         // 000000DC7E18: D6440018 03FE1501 0C040C00
	.long 0xcc0f4002                                           // 000000DC7E24: CC0F4002
	v_mul_i32_i24_e32 v1, 0xe408, v9                           // 000000DC7E28: 120212FF 0000E408
	v_perm_b32 v17, v1, v10, 0xc050c01                         // 000000DC7E30: D6440011 03FE1501 0C050C01
	v_or_b32_e32 v23, 0x64006400, v23                          // 000000DC7E3C: 382E2EFF 64006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DC7E44: BF870214
	v_or_b32_e32 v3, 0x64006400, v24                           // 000000DC7E48: 380630FF 64006400
	v_dot2acc_f32_f16 v26, v2, v4                              // 000000DC7E50: 04340902
	v_perm_b32 v4, v1, v10, 0xc060c02                          // 000000DC7E54: D6440004 03FE1501 0C060C02
	v_perm_b32 v10, v1, v10, 0xc070c03                         // 000000DC7E60: D644000A 03FE1501 0C070C03
	.long 0xcc0f4009                                           // 000000DC7E6C: CC0F4009
	v_mul_i32_i24_e32 v1, 0xe408, v23                          // 000000DC7E70: 12022EFF 0000E408
	.long 0xcc0f4002                                           // 000000DC7E78: CC0F4002
	v_mul_i32_i24_e32 v1, 0xe408, v3                           // 000000DC7E7C: 120206FF 0000E408
	v_or_b32_e32 v3, 0x64006400, v17                           // 000000DC7E84: 380622FF 64006400
	v_perm_b32 v23, v21, v22, 0xc060c02                        // 000000DC7E8C: D6440017 03FE2D15 0C060C02
	v_or_b32_e32 v10, 0x64006400, v10                          // 000000DC7E98: 381414FF 64006400
	v_dot2acc_f32_f16 v36, v9, v18                             // 000000DC7EA0: 04482509
	s_waitcnt lgkmcnt(0)                                       // 000000DC7EA4: BF89FC07
	v_dot2acc_f32_f16 v26, v2, v13                             // 000000DC7EA8: 04341B02
	v_lshrrev_b32_e32 v2, 4, v11                               // 000000DC7EAC: 32041684
	.long 0xcc0f4003                                           // 000000DC7EB0: CC0F4003
	v_mul_i32_i24_e32 v1, 0xe408, v3                           // 000000DC7EB4: 120206FF 0000E408
	v_or_b32_e32 v13, 0x64006400, v4                           // 000000DC7EBC: 381A08FF 64006400
	v_and_b32_e32 v11, 0xf0f0f0f, v11                          // 000000DC7EC4: 361616FF 0F0F0F0F
	.long 0xcc0f400a                                           // 000000DC7ECC: CC0F400A
	v_mul_i32_i24_e32 v1, 0xe408, v10                          // 000000DC7ED0: 120214FF 0000E408
	v_and_b32_e32 v27, 0xf0f0f0f, v2                           // 000000DC7ED8: 363604FF 0F0F0F0F
	v_dot2acc_f32_f16 v26, v3, v14                             // 000000DC7EE0: 04341D03
	ds_load_b128 v[1:4], v70 offset:9760                       // 000000DC7EE4: DBFC2620 01000046
	.long 0xcc0f400d                                           // 000000DC7EEC: CC0F400D
	v_mul_i32_i24_e32 v1, 0xe408, v13                          // 000000DC7EF0: 12021AFF 0000E408
	v_or_b32_e32 v9, 0x64006400, v23                           // 000000DC7EF8: 38122EFF 64006400
	v_perm_b32 v14, v27, v11, 0xc040c00                        // 000000DC7F00: D644000E 03FE171B 0C040C00
	v_perm_b32 v17, v21, v22, 0xc070c03                        // 000000DC7F0C: D6440011 03FE2D15 0C070C03
	v_perm_b32 v29, v27, v11, 0xc060c02                        // 000000DC7F18: D644001D 03FE171B 0C060C02
	v_dot2acc_f32_f16 v26, v13, v15                            // 000000DC7F24: 04341F0D
	v_lshrrev_b32_e32 v15, 4, v5                               // 000000DC7F28: 321E0A84
	v_or_b32_e32 v13, 0x64006400, v14                          // 000000DC7F2C: 381A1CFF 64006400
	v_perm_b32 v14, v27, v11, 0xc050c01                        // 000000DC7F34: D644000E 03FE171B 0C050C01
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DC7F40: BF870214
	v_dual_dot2acc_f32_f16 v26, v10, v16 :: v_dual_and_b32 v5, 0xf0f0f0f, v5// 000000DC7F44: CB24210A 1A040AFF 0F0F0F0F
	v_and_b32_e32 v28, 0xf0f0f0f, v15                          // 000000DC7F50: 36381EFF 0F0F0F0F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DC7F58: BF870214
	.long 0xcc0f400a                                           // 000000DC7F5C: CC0F400A
	v_mul_i32_i24_e32 v1, 0xe408, v13                          // 000000DC7F60: 12021AFF 0000E408
	v_or_b32_e32 v18, 0x64006400, v14                          // 000000DC7F68: 38241CFF 64006400
	ds_load_b128 v[13:16], v70 offset:9984                     // 000000DC7F70: DBFC2700 0D000046
	ds_load_b128 v[21:24], v70 offset:9776                     // 000000DC7F78: DBFC2630 15000046
	.long 0xcc0f4009                                           // 000000DC7F80: CC0F4009
	v_mul_i32_i24_e32 v1, 0xe408, v9                           // 000000DC7F84: 120212FF 0000E408
	v_or_b32_e32 v17, 0x64006400, v17                          // 000000DC7F8C: 382222FF 64006400
	s_waitcnt lgkmcnt(2)                                       // 000000DC7F94: BF89FC27
	v_dot2acc_f32_f16 v26, v10, v1                             // 000000DC7F98: 0434030A
	.long 0xcc0f4001                                           // 000000DC7F9C: CC0F4001
	v_mul_i32_i24_e32 v1, 0xe408, v18                          // 000000DC7FA0: 120224FF 0000E408
	v_perm_b32 v10, v28, v5, 0xc040c00                         // 000000DC7FA8: D644000A 03FE0B1C 0C040C00
	v_or_b32_e32 v18, 0x64006400, v29                          // 000000DC7FB4: 38243AFF 64006400
	v_dot2acc_f32_f16 v36, v9, v19                             // 000000DC7FBC: 04482709
	.long 0xcc0f4009                                           // 000000DC7FC0: CC0F4009
	v_mul_i32_i24_e32 v1, 0xe408, v17                          // 000000DC7FC4: 120222FF 0000E408
	v_dot2acc_f32_f16 v26, v1, v2                              // 000000DC7FCC: 04340501
	v_or_b32_e32 v1, 0x64006400, v10                           // 000000DC7FD0: 380214FF 64006400
	.long 0xcc0f4002                                           // 000000DC7FD8: CC0F4002
	v_mul_i32_i24_e32 v1, 0xe408, v18                          // 000000DC7FDC: 120224FF 0000E408
	v_perm_b32 v10, v28, v5, 0xc050c01                         // 000000DC7FE4: D644000A 03FE0B1C 0C050C01
	v_dot2acc_f32_f16 v36, v9, v20                             // 000000DC7FF0: 04482909
	ds_load_b128 v[17:20], v70 offset:10000                    // 000000DC7FF4: DBFC2710 11000046
	.long 0xcc0f4001                                           // 000000DC7FFC: CC0F4001
	v_mul_i32_i24_e32 v1, 0xe408, v1                           // 000000DC8000: 120202FF 0000E408
	v_dot2acc_f32_f16 v26, v2, v3                              // 000000DC8008: 04340702
	v_or_b32_e32 v2, 0x64006400, v10                           // 000000DC800C: 380414FF 64006400
	v_perm_b32 v3, v28, v5, 0xc060c02                          // 000000DC8014: D6440003 03FE0B1C 0C060C02
	v_perm_b32 v5, v28, v5, 0xc070c03                          // 000000DC8020: D6440005 03FE0B1C 0C070C03
	s_waitcnt lgkmcnt(2)                                       // 000000DC802C: BF89FC27
	v_dot2acc_f32_f16 v68, v1, v13                             // 000000DC8030: 04881B01
	v_lshrrev_b32_e32 v1, 4, v6                                // 000000DC8034: 32020C84
	.long 0xcc0f4002                                           // 000000DC8038: CC0F4002
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000DC803C: 120204FF 0000E408
	v_or_b32_e32 v3, 0x64006400, v3                            // 000000DC8044: 380606FF 64006400
	v_and_b32_e32 v6, 0xf0f0f0f, v6                            // 000000DC804C: 360C0CFF 0F0F0F0F
	v_perm_b32 v9, v27, v11, 0xc070c03                         // 000000DC8054: D6440009 03FE171B 0C070C03
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DC8060: BF870214
	v_dual_dot2acc_f32_f16 v68, v2, v14 :: v_dual_and_b32 v1, 0xf0f0f0f, v1// 000000DC8064: CB241D02 440002FF 0F0F0F0F
	.long 0xcc0f4002                                           // 000000DC8070: CC0F4002
	v_mul_i32_i24_e32 v1, 0xe408, v3                           // 000000DC8074: 120206FF 0000E408
	v_or_b32_e32 v3, 0x64006400, v5                            // 000000DC807C: 38060AFF 64006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DC8084: BF870214
	v_or_b32_e32 v9, 0x64006400, v9                            // 000000DC8088: 381212FF 64006400
	v_perm_b32 v5, v1, v6, 0xc040c00                           // 000000DC8090: D6440005 03FE0D01 0C040C00
	v_lshrrev_b32_e32 v10, 4, v12                              // 000000DC809C: 32141884
	v_dot2acc_f32_f16 v68, v2, v15                             // 000000DC80A0: 04881F02
	.long 0xcc0f4002                                           // 000000DC80A4: CC0F4002
	v_mul_i32_i24_e32 v1, 0xe408, v3                           // 000000DC80A8: 120206FF 0000E408
	v_perm_b32 v11, v1, v6, 0xc050c01                          // 000000DC80B0: D644000B 03FE0D01 0C050C01
	v_or_b32_e32 v3, 0x64006400, v5                            // 000000DC80BC: 38060AFF 64006400
	v_and_b32_e32 v5, 0xf0f0f0f, v12                           // 000000DC80C4: 360A18FF 0F0F0F0F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000DC80CC: BF870224
	v_dual_dot2acc_f32_f16 v68, v2, v16 :: v_dual_and_b32 v13, 0xf0f0f0f, v10// 000000DC80D0: CB242102 440C14FF 0F0F0F0F
	v_perm_b32 v10, v1, v6, 0xc060c02                          // 000000DC80DC: D644000A 03FE0D01 0C060C02
	.long 0xcc0f4002                                           // 000000DC80E8: CC0F4002
	v_mul_i32_i24_e32 v1, 0xe408, v3                           // 000000DC80EC: 120206FF 0000E408
	.long 0xcc0f4003                                           // 000000DC80F4: CC0F4003
	v_mul_i32_i24_e32 v1, 0xe408, v9                           // 000000DC80F8: 120212FF 0000E408
	v_or_b32_e32 v9, 0x64006400, v11                           // 000000DC8100: 381216FF 64006400
	v_perm_b32 v14, v13, v5, 0xc040c00                         // 000000DC8108: D644000E 03FE0B0D 0C040C00
	v_or_b32_e32 v16, 0x64006400, v10                          // 000000DC8114: 382014FF 64006400
	s_waitcnt lgkmcnt(0)                                       // 000000DC811C: BF89FC07
	v_dot2acc_f32_f16 v68, v2, v17                             // 000000DC8120: 04882302
	v_lshrrev_b32_e32 v2, 4, v7                                // 000000DC8124: 32040E84
	.long 0xcc0f400f                                           // 000000DC8128: CC0F400F
	v_mul_i32_i24_e32 v1, 0xe408, v9                           // 000000DC812C: 120212FF 0000E408
	v_perm_b32 v1, v1, v6, 0xc070c03                           // 000000DC8134: D6440001 03FE0D01 0C070C03
	v_and_b32_e32 v6, 0xf0f0f0f, v7                            // 000000DC8140: 360C0EFF 0F0F0F0F
	ds_load_b128 v[9:12], v70 offset:10016                     // 000000DC8148: DBFC2720 09000046
	v_and_b32_e32 v7, 0xf0f0f0f, v2                            // 000000DC8150: 360E04FF 0F0F0F0F
	v_or_b32_e32 v2, 0x64006400, v14                           // 000000DC8158: 38041CFF 64006400
	v_dot2acc_f32_f16 v68, v15, v18                            // 000000DC8160: 0488250F
	.long 0xcc0f400e                                           // 000000DC8164: CC0F400E
	v_mul_i32_i24_e32 v1, 0xe408, v16                          // 000000DC8168: 120220FF 0000E408
	v_or_b32_e32 v1, 0x64006400, v1                            // 000000DC8170: 380202FF 64006400
	v_perm_b32 v15, v7, v6, 0xc040c00                          // 000000DC8178: D644000F 03FE0D07 0C040C00
	v_dot2acc_f32_f16 v26, v3, v4                              // 000000DC8184: 04340903
	.long 0xcc0f4002                                           // 000000DC8188: CC0F4002
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000DC818C: 120204FF 0000E408
	v_dot2acc_f32_f16 v68, v14, v19                            // 000000DC8194: 0488270E
	.long 0xcc0f4001                                           // 000000DC8198: CC0F4001
	v_mul_i32_i24_e32 v1, 0xe408, v1                           // 000000DC819C: 120202FF 0000E408
	v_or_b32_e32 v3, 0x64006400, v15                           // 000000DC81A4: 38061EFF 64006400
	v_perm_b32 v4, v13, v5, 0xc050c01                          // 000000DC81AC: D6440004 03FE0B0D 0C050C01
	v_perm_b32 v14, v7, v6, 0xc050c01                          // 000000DC81B8: D644000E 03FE0D07 0C050C01
	v_dot2acc_f32_f16 v26, v2, v21                             // 000000DC81C4: 04342B02
	v_dot2acc_f32_f16 v68, v1, v20                             // 000000DC81C8: 04882901
	.long 0xcc0f400f                                           // 000000DC81CC: CC0F400F
	v_mul_i32_i24_e32 v1, 0xe408, v3                           // 000000DC81D0: 120206FF 0000E408
	v_or_b32_e32 v16, 0x64006400, v4                           // 000000DC81D8: 382008FF 64006400
	v_or_b32_e32 v14, 0x64006400, v14                          // 000000DC81E0: 381C1CFF 64006400
	v_perm_b32 v17, v7, v6, 0xc060c02                          // 000000DC81E8: D6440011 03FE0D07 0C060C02
	ds_load_b128 v[1:4], v70 offset:10032                      // 000000DC81F4: DBFC2730 01000046
	s_waitcnt lgkmcnt(1)                                       // 000000DC81FC: BF89FC17
	v_dot2acc_f32_f16 v68, v15, v9                             // 000000DC8200: 0488130F
	v_lshrrev_b32_e32 v9, 4, v8                                // 000000DC8204: 32121084
	.long 0xcc0f400e                                           // 000000DC8208: CC0F400E
	v_mul_i32_i24_e32 v1, 0xe408, v14                          // 000000DC820C: 12021CFF 0000E408
	v_or_b32_e32 v15, 0x64006400, v17                          // 000000DC8214: 381E22FF 64006400
	v_perm_b32 v6, v7, v6, 0xc070c03                           // 000000DC821C: D6440006 03FE0D07 0C070C03
	v_and_b32_e32 v7, 0xf0f0f0f, v8                            // 000000DC8228: 360E10FF 0F0F0F0F
	v_and_b32_e32 v8, 0xf0f0f0f, v9                            // 000000DC8230: 361012FF 0F0F0F0F
	.long 0xcc0f4009                                           // 000000DC8238: CC0F4009
	v_mul_i32_i24_e32 v1, 0xe408, v16                          // 000000DC823C: 120220FF 0000E408
	v_dot2acc_f32_f16 v68, v14, v10                            // 000000DC8244: 0488150E
	.long 0xcc0f400a                                           // 000000DC8248: CC0F400A
	v_mul_i32_i24_e32 v1, 0xe408, v15                          // 000000DC824C: 12021EFF 0000E408
	v_or_b32_e32 v6, 0x64006400, v6                            // 000000DC8254: 380C0CFF 64006400
	v_perm_b32 v14, v8, v7, 0xc040c00                          // 000000DC825C: D644000E 03FE0F08 0C040C00
	v_dot2acc_f32_f16 v26, v9, v22                             // 000000DC8268: 04342D09
	v_perm_b32 v9, v13, v5, 0xc060c02                          // 000000DC826C: D6440009 03FE0B0D 0C060C02
	v_dot2acc_f32_f16 v68, v10, v11                            // 000000DC8278: 0488170A
	.long 0xcc0f4006                                           // 000000DC827C: CC0F4006
	v_mul_i32_i24_e32 v1, 0xe408, v6                           // 000000DC8280: 12020CFF 0000E408
	v_or_b32_e32 v10, 0x64006400, v14                          // 000000DC8288: 38141CFF 64006400
	v_perm_b32 v11, v8, v7, 0xc050c01                          // 000000DC8290: D644000B 03FE0F08 0C050C01
	v_or_b32_e32 v9, 0x64006400, v9                            // 000000DC829C: 381212FF 64006400
	v_perm_b32 v5, v13, v5, 0xc070c03                          // 000000DC82A4: D6440005 03FE0B0D 0C070C03
	v_dot2acc_f32_f16 v68, v6, v12                             // 000000DC82B0: 04881906
	.long 0xcc0f4006                                           // 000000DC82B4: CC0F4006
	v_mul_i32_i24_e32 v1, 0xe408, v10                          // 000000DC82B8: 120214FF 0000E408
	v_or_b32_e32 v10, 0x64006400, v11                          // 000000DC82C0: 381416FF 64006400
	v_perm_b32 v11, v8, v7, 0xc060c02                          // 000000DC82C8: D644000B 03FE0F08 0C060C02
	.long 0xcc0f4009                                           // 000000DC82D4: CC0F4009
	v_mul_i32_i24_e32 v1, 0xe408, v9                           // 000000DC82D8: 120212FF 0000E408
	v_or_b32_e32 v5, 0x64006400, v5                            // 000000DC82E0: 380A0AFF 64006400
	s_waitcnt lgkmcnt(0)                                       // 000000DC82E8: BF89FC07
	v_dot2acc_f32_f16 v68, v6, v1                              // 000000DC82EC: 04880306
	.long 0xcc0f4001                                           // 000000DC82F0: CC0F4001
	v_mul_i32_i24_e32 v1, 0xe408, v10                          // 000000DC82F4: 120214FF 0000E408
	v_or_b32_e32 v6, 0x64006400, v11                           // 000000DC82FC: 380C16FF 64006400
	v_perm_b32 v7, v8, v7, 0xc070c03                           // 000000DC8304: D6440007 03FE0F08 0C070C03
	v_dot2acc_f32_f16 v26, v9, v23                             // 000000DC8310: 04342F09
	.long 0xcc0f4005                                           // 000000DC8314: CC0F4005
	v_mul_i32_i24_e32 v1, 0xe408, v5                           // 000000DC8318: 12020AFF 0000E408
	v_dot2acc_f32_f16 v68, v1, v2                              // 000000DC8320: 04880501
	.long 0xcc0f4001                                           // 000000DC8324: CC0F4001
	v_mul_i32_i24_e32 v1, 0xe408, v6                           // 000000DC8328: 12020CFF 0000E408
	v_or_b32_e32 v2, 0x64006400, v7                            // 000000DC8330: 38040EFF 64006400
	v_fma_mix_f32 v6, v33, v36, v25 op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000DC8338: CC200806 0C664921
	v_dot2acc_f32_f16 v26, v5, v24                             // 000000DC8340: 04343105
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DC8344: BF870214
	v_dot2acc_f32_f16 v68, v1, v3                              // 000000DC8348: 04880701
	.long 0xcc0f4001                                           // 000000DC834C: CC0F4001
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000DC8350: 120204FF 0000E408
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DC8358: BF870113
	v_fma_mix_f32 v2, v34, v26, v6 op_sel_hi:[1,0,0]           // 000000DC835C: CC200002 0C1A3522
	v_dot2acc_f32_f16 v68, v1, v4                              // 000000DC8364: 04880901
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DC8368: BF870091
	v_fma_mix_f32 v1, v34, v68, v2 op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000DC836C: CC200801 0C0A8922
	v_mov_b32_dpp v2, v1 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DC8374: 7E0402FA FF016101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DC837C: BF870091
	v_add_f32_e32 v1, v1, v2                                   // 000000DC8380: 06020501
	v_mov_b32_dpp v2, v1 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DC8384: 7E0402FA FF016201
	v_cmpx_eq_u32_e32 0, v69                                   // 000000DC838C: 7D948A80
	s_cbranch_execz 17                                         // 000000DC8390: BFA50011 <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_oILi1EEEvPKhlPKDF16_PKiPfS5_S5_PDF16_PjNS0_5I4rSdEiS7_+0x60d8>
	s_delay_alu instid0(VALU_DEP_2)                            // 000000DC8394: BF870002
	v_add_f32_e32 v3, v1, v2                                   // 000000DC8398: 06060501
	.long 0xd73c0001                                           // 000000DC839C: D73C0001
	v_cndmask_b32_e32 v1, 2, v62, vcc_lo                       // 000000DC83A0: 02027C82
	s_mul_i32 s2, s10, 0x1400                                  // 000000DC83A4: 9602FF0A 00001400
	s_mul_hi_i32 s3, s10, 0x1400                               // 000000DC83AC: 9703FF0A 00001400
	s_add_u32 s2, s24, s2                                      // 000000DC83B4: 80020218
	s_addc_u32 s3, s25, s3                                     // 000000DC83B8: 82030319
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DC83BC: BF870091
	.long 0xd7006a01                                           // 000000DC83C0: D7006A01
	v_cndmask_b32_e32 v1, s2, v1, vcc_lo                       // 000000DC83C4: 02020202
	v_add_co_ci_u32_e64 v2, null, s3, v2, vcc_lo               // 000000DC83C8: D5207C02 01AA0403
	global_store_b32 v[1:2], v3, off                           // 000000DC83D0: DC6A0000 007C0301
	s_or_b32 exec_lo, exec_lo, s1                              // 000000DC83D8: 8C7E017E
	s_mul_hi_i32 s1, s0, 0x66666667                            // 000000DC83DC: 9701FF00 66666667
	s_waitcnt_vscnt null, 0x0                                  // 000000DC83E4: BC7C0000
	buffer_gl1_inv                                             // 000000DC83E8: E0B00000 00000000
	buffer_gl0_inv                                             // 000000DC83F0: E0AC0000 00000000
	s_lshr_b32 s2, s1, 31                                      // 000000DC83F8: 85029F01
	s_lshr_b32 s1, s1, 2                                       // 000000DC83FC: 85018201
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000DC8400: BF870009
	s_add_i32 s1, s1, s2                                       // 000000DC8404: 81010201
	s_mul_i32 s2, s10, 5                                       // 000000DC8408: 9602850A
	s_mul_i32 s1, s1, 10                                       // 000000DC840C: 96018A01
	s_barrier                                                  // 000000DC8410: BFBD0000
	s_sub_i32 s0, s0, s1                                       // 000000DC8414: 81800100
	buffer_gl0_inv                                             // 000000DC8418: E0AC0000 00000000
	s_bfe_u32 s1, s0, 0x10007                                  // 000000DC8420: 9301FF00 00010007
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000DC8428: BF870499
	s_add_i32 s0, s0, s1                                       // 000000DC842C: 81000100
	s_bfe_i32 s0, s0, 0x80000                                  // 000000DC8430: 9380FF00 00080000
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 000000DC8438: BF8704B9
	s_sext_i32_i16 s1, s0                                      // 000000DC843C: BE810F00
	.long 0xd44a0000                                           // 000000DC8440: D44A0000
	v_cndmask_b32_e32 v1, 0, v0, vcc_lo                        // 000000DC8444: 02020080
	s_ashr_i32 s1, s1, 1                                       // 000000DC8448: 86018101
	s_add_i32 s14, s2, s1                                      // 000000DC844C: 810E0102
	s_and_saveexec_b32 s2, s0                                  // 000000DC8450: BE822000
	s_cbranch_execz 29                                         // 000000DC8454: BFA5001D <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_oILi1EEEvPKhlPKDF16_PKiPfS5_S5_PDF16_PjNS0_5I4rSdEiS7_+0x61cc>
	s_mov_b32 s4, exec_lo                                      // 000000DC8458: BE84007E
	s_mov_b32 s3, exec_lo                                      // 000000DC845C: BE83007E
	.long 0xd71f0001                                           // 000000DC8460: D71F0001
	v_cndmask_b32_e32 v0, s4, v128, vcc_lo                     // 000000DC8464: 02010004
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DC8468: BF870001
	v_cmpx_eq_u32_e32 0, v1                                    // 000000DC846C: 7D940280
	s_cbranch_execz 11                                         // 000000DC8470: BFA5000B <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_oILi1EEEvPKhlPKDF16_PKiPfS5_S5_PDF16_PjNS0_5I4rSdEiS7_+0x61a0>
	s_ashr_i32 s15, s14, 31                                    // 000000DC8474: 860F9F0E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000DC8478: BF870499
	s_lshl_b64 s[6:7], s[14:15], 2                             // 000000DC847C: 8486820E
	s_add_u32 s6, s12, s6                                      // 000000DC8480: 8006060C
	s_addc_u32 s7, s13, s7                                     // 000000DC8484: 8207070D
	s_bcnt1_i32_b32 s4, s4                                     // 000000DC8488: BE841804
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000DC848C: BF870009
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v3, s4              // 000000DC8490: CA100080 02020004
	global_atomic_add_u32 v2, v2, v3, s[6:7] glc               // 000000DC8498: DCD64000 02060302
	s_or_b32 exec_lo, exec_lo, s3                              // 000000DC84A0: 8C7E037E
	s_waitcnt vmcnt(0)                                         // 000000DC84A4: BF8903F7
	v_readfirstlane_b32 s3, v2                                 // 000000DC84A8: 7E060502
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DC84AC: BF870091
	v_dual_mov_b32 v2, 0 :: v_dual_add_nc_u32 v1, s3, v1       // 000000DC84B0: CA200080 02000203
	v_cmp_eq_u32_e32 vcc_lo, 3, v1                             // 000000DC84B8: 7C940283
	v_cndmask_b32_e64 v1, 0, 1, vcc_lo                         // 000000DC84BC: D5010001 01A90280
	ds_store_b32 v2, v1 offset:10244                           // 000000DC84C4: D8342804 00000102
	s_or_b32 exec_lo, exec_lo, s2                              // 000000DC84CC: 8C7E027E
	v_mov_b32_e32 v1, 0                                        // 000000DC84D0: 7E020280
	s_waitcnt lgkmcnt(0)                                       // 000000DC84D4: BF89FC07
	s_barrier                                                  // 000000DC84D8: BFBD0000
	buffer_gl0_inv                                             // 000000DC84DC: E0AC0000 00000000
	ds_load_b32 v1, v1 offset:10244                            // 000000DC84E4: D8D82804 01000001
	s_waitcnt lgkmcnt(0)                                       // 000000DC84EC: BF89FC07
	v_cmp_eq_u32_e32 vcc_lo, 0, v1                             // 000000DC84F0: 7C940280
	s_cbranch_vccnz 640                                        // 000000DC84F4: BFA40280 <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_oILi1EEEvPKhlPKDF16_PKiPfS5_S5_PDF16_PjNS0_5I4rSdEiS7_+0x6bf8>
	buffer_gl1_inv                                             // 000000DC84F8: E0B00000 00000000
	buffer_gl0_inv                                             // 000000DC8500: E0AC0000 00000000
	s_mov_b32 s2, exec_lo                                      // 000000DC8508: BE82007E
	v_cmpx_gt_u32_e32 32, v0                                   // 000000DC850C: 7D9800A0
	s_cbranch_execz 633                                        // 000000DC8510: BFA50279 <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_oILi1EEEvPKhlPKDF16_PKiPfS5_S5_PDF16_PjNS0_5I4rSdEiS7_+0x6bf8>
	s_mul_i32 s2, s10, 0x1400                                  // 000000DC8514: 9602FF0A 00001400
	s_mul_hi_i32 s3, s10, 0x1400                               // 000000DC851C: 9703FF0A 00001400
	s_add_u32 s4, s24, s2                                      // 000000DC8524: 80040218
	s_addc_u32 s5, s25, s3                                     // 000000DC8528: 82050319
	s_lshl_b32 s16, s1, 7                                      // 000000DC852C: 84108701
	v_lshlrev_b32_e32 v1, 4, v0                                // 000000DC8530: 30020084
	s_ashr_i32 s17, s16, 31                                    // 000000DC8534: 86119F10
	s_mov_b32 s9, 0x76543210                                   // 000000DC8538: BE8900FF 76543210
	s_lshl_b64 s[2:3], s[16:17], 2                             // 000000DC8540: 84828210
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000DC8544: BF870009
	s_add_u32 s2, s4, s2                                       // 000000DC8548: 80020204
	s_addc_u32 s3, s5, s3                                      // 000000DC854C: 82030305
	s_clause 0x7                                               // 000000DC8550: BF850007
	global_load_b32 v7, v1, s[2:3] glc                         // 000000DC8554: DC524000 07020001
	global_load_b32 v8, v1, s[2:3] offset:2560 glc             // 000000DC855C: DC524A00 08020001
	global_load_b32 v9, v1, s[2:3] offset:4 glc                // 000000DC8564: DC524004 09020001
	global_load_b32 v10, v1, s[2:3] offset:2564 glc            // 000000DC856C: DC524A04 0A020001
	global_load_b32 v11, v1, s[2:3] offset:8 glc               // 000000DC8574: DC524008 0B020001
	global_load_b32 v12, v1, s[2:3] offset:2568 glc            // 000000DC857C: DC524A08 0C020001
	global_load_b32 v13, v1, s[2:3] offset:12 glc              // 000000DC8584: DC52400C 0D020001
	global_load_b32 v14, v1, s[2:3] offset:2572 glc            // 000000DC858C: DC524A0C 0E020001
	v_lshl_or_b32 v1, v0, 2, s16                               // 000000DC8594: D6560001 00410500
	v_and_b32_e32 v15, 1, v0                                   // 000000DC859C: 361E0081
	v_and_b32_e32 v16, 2, v0                                   // 000000DC85A0: 36200082
	v_and_b32_e32 v17, 4, v0                                   // 000000DC85A4: 36220084
	v_and_b32_e32 v18, 8, v0                                   // 000000DC85A8: 36240088
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000DC85AC: 3404029F
	.long 0xd44c0005                                           // 000000DC85B0: D44C0005
	v_cndmask_b32_e32 v1, 16, v0, vcc_lo                       // 000000DC85B4: 02020090
	v_lshlrev_b32_e32 v0, 3, v0                                // 000000DC85B8: 30000083
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DC85BC: BF870093
	.long 0xd73c0001                                           // 000000DC85C0: D73C0001
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 000000DC85C4: 02020281
	.long 0xd7006a03                                           // 000000DC85C8: D7006A03
	v_cndmask_b32_e32 v1, s26, v1, vcc_lo                      // 000000DC85CC: 0202021A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000DC85D0: BF8700D1
	v_add_co_ci_u32_e64 v4, null, s27, v2, vcc_lo              // 000000DC85D4: D5207C04 01AA041B
	s_clause 0x1                                               // 000000DC85DC: BF850001
	global_load_b64 v[5:6], v[3:4], off                        // 000000DC85E0: DC560000 057C0003
	global_load_b64 v[3:4], v[3:4], off offset:1280            // 000000DC85E8: DC560500 037C0003
	.long 0xd7006a01                                           // 000000DC85F0: D7006A01
	v_cndmask_b32_e32 v1, s28, v1, vcc_lo                      // 000000DC85F4: 0202021C
	v_add_co_ci_u32_e64 v2, null, s29, v2, vcc_lo              // 000000DC85F8: D5207C02 01AA041D
	global_load_b64 v[1:2], v[1:2], off                        // 000000DC8600: DC560000 017C0001
	s_waitcnt vmcnt(8)                                         // 000000DC8608: BF8923F7
	v_add_f32_e32 v19, v7, v9                                  // 000000DC860C: 06261307
	v_sub_f32_e32 v7, v7, v9                                   // 000000DC8610: 080E1307
	.long 0xd44a0002                                           // 000000DC8614: D44A0002
	v_cndmask_b32_e32 v1, 0, v16, vcc_lo                       // 000000DC8618: 02022080
	.long 0xd44a0004                                           // 000000DC861C: D44A0004
	v_cndmask_b32_e32 v1, 0, v18, vcc_lo                       // 000000DC8620: 02022480
	s_waitcnt vmcnt(4)                                         // 000000DC8624: BF8913F7
	v_add_f32_e32 v9, v11, v13                                 // 000000DC8628: 06121B0B
	v_sub_f32_e32 v11, v11, v13                                // 000000DC862C: 08161B0B
	v_add_f32_e32 v13, v8, v10                                 // 000000DC8630: 061A1508
	v_sub_f32_e32 v8, v8, v10                                  // 000000DC8634: 08101508
	s_waitcnt vmcnt(3)                                         // 000000DC8638: BF890FF7
	v_add_f32_e32 v10, v12, v14                                // 000000DC863C: 06141D0C
	v_sub_f32_e32 v12, v12, v14                                // 000000DC8640: 08181D0C
	.long 0xd44a0001                                           // 000000DC8644: D44A0001
	v_cndmask_b32_e32 v1, 0, v15, vcc_lo                       // 000000DC8648: 02021E80
	.long 0xd44a0003                                           // 000000DC864C: D44A0003
	v_cndmask_b32_e32 v1, 0, v17, vcc_lo                       // 000000DC8650: 02022280
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000DC8654: BF870133
	v_add_f32_e32 v15, v8, v12                                 // 000000DC8658: 061E1908
	v_sub_f32_e32 v8, v8, v12                                  // 000000DC865C: 08101908
	v_add_f32_e32 v20, v7, v11                                 // 000000DC8660: 06281707
	v_mov_b32_dpp v25, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DC8664: 7E3202FA FF016108
	v_cndmask_b32_e64 v8, -v8, v8, s1                          // 000000DC866C: D5010008 20061108
	v_sub_f32_e32 v7, v7, v11                                  // 000000DC8674: 080E1707
	v_add_f32_e32 v11, v13, v10                                // 000000DC8678: 0616150D
	v_sub_f32_e32 v10, v13, v10                                // 000000DC867C: 0814150D
	v_add_f32_e32 v14, v19, v9                                 // 000000DC8680: 061C1313
	v_add_f32_e32 v8, v8, v25                                  // 000000DC8684: 06103308
	v_mov_b32_dpp v21, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DC8688: 7E2A02FA FF016107
	v_mov_b32_dpp v22, v11 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DC8690: 7E2C02FA FF01610B
	v_mov_b32_dpp v24, v10 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DC8698: 7E3002FA FF01610A
	v_mov_b32_dpp v12, v14 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DC86A0: 7E1802FA FF01610E
	v_cndmask_b32_e64 v13, -v14, v14, s1                       // 000000DC86A8: D501000D 20061D0E
	v_mov_b32_dpp v14, v20 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DC86B0: 7E1C02FA FF016114
	v_cndmask_b32_e64 v10, -v10, v10, s1                       // 000000DC86B8: D501000A 2006150A
	v_sub_f32_e32 v9, v19, v9                                  // 000000DC86C0: 08121313
	v_cndmask_b32_e64 v19, -v20, v20, s1                       // 000000DC86C4: D5010013 20062914
	v_cndmask_b32_e64 v11, -v11, v11, s1                       // 000000DC86CC: D501000B 2006170B
	v_cndmask_b32_e64 v7, -v7, v7, s1                          // 000000DC86D4: D5010007 20060F07
	v_add_f32_e32 v10, v10, v24                                // 000000DC86DC: 0614310A
	v_mov_b32_dpp v20, v9 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DC86E0: 7E2802FA FF016109
	v_cndmask_b32_e64 v9, -v9, v9, s1                          // 000000DC86E8: D5010009 20061309
	v_add_f32_e32 v14, v19, v14                                // 000000DC86F0: 061C1D13
	v_mov_b32_dpp v23, v15 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DC86F4: 7E2E02FA FF01610F
	v_cndmask_b32_e64 v15, -v15, v15, s1                       // 000000DC86FC: D501000F 20061F0F
	v_dual_add_f32 v11, v11, v22 :: v_dual_add_f32 v12, v13, v12// 000000DC8704: C9082D0B 0B0C190D
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DC870C: BF870004
	v_mov_b32_dpp v22, v14 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DC8710: 7E2C02FA FF01620E
	v_cndmask_b32_e64 v14, -v14, v14, s2                       // 000000DC8718: D501000E 200A1D0E
	v_add_f32_e32 v9, v9, v20                                  // 000000DC8720: 06122909
	v_mov_b32_dpp v20, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DC8724: 7E2802FA FF016208
	v_cndmask_b32_e64 v8, -v8, v8, s2                          // 000000DC872C: D5010008 200A1108
	v_add_f32_e32 v15, v15, v23                                // 000000DC8734: 061E2F0F
	v_mov_b32_dpp v13, v11 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DC8738: 7E1A02FA FF01620B
	v_cndmask_b32_e64 v11, -v11, v11, s2                       // 000000DC8740: D501000B 200A170B
	v_mov_b32_dpp v19, v10 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DC8748: 7E2602FA FF01620A
	v_cndmask_b32_e64 v10, -v10, v10, s2                       // 000000DC8750: D501000A 200A150A
	v_add_f32_e32 v7, v7, v21                                  // 000000DC8758: 060E2B07
	v_mov_b32_dpp v21, v12 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DC875C: 7E2A02FA FF01620C
	v_cndmask_b32_e64 v12, -v12, v12, s2                       // 000000DC8764: D501000C 200A190C
	v_add_f32_e32 v8, v8, v20                                  // 000000DC876C: 06102908
	v_mov_b32_dpp v16, v15 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DC8770: 7E2002FA FF01620F
	v_cndmask_b32_e64 v15, -v15, v15, s2                       // 000000DC8778: D501000F 200A1F0F
	v_add_f32_e32 v10, v10, v19                                // 000000DC8780: 0614270A
	v_mov_b32_dpp v24, v7 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DC8784: 7E3002FA FF016207
	v_cndmask_b32_e64 v7, -v7, v7, s2                          // 000000DC878C: D5010007 200A0F07
	v_add_f32_e32 v14, v14, v22                                // 000000DC8794: 061C2D0E
	v_add_f32_e32 v12, v12, v21                                // 000000DC8798: 06182B0C
	v_mov_b32_dpp v19, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DC879C: 7E2602FA FF016408
	v_cndmask_b32_e64 v8, -v8, v8, s3                          // 000000DC87A4: D5010008 200E1108
	v_add_f32_e32 v11, v11, v13                                // 000000DC87AC: 06161B0B
	v_add_f32_e32 v13, v15, v16                                // 000000DC87B0: 061A210F
	v_mov_b32_dpp v23, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DC87B4: 7E2E02FA FF016209
	v_cndmask_b32_e64 v9, -v9, v9, s2                          // 000000DC87BC: D5010009 200A1309
	v_mov_b32_dpp v17, v10 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DC87C4: 7E2202FA FF01640A
	v_cndmask_b32_e64 v10, -v10, v10, s3                       // 000000DC87CC: D501000A 200E150A
	v_add_f32_e32 v7, v7, v24                                  // 000000DC87D4: 060E3107
	v_mov_b32_dpp v20, v12 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DC87D8: 7E2802FA FF01640C
	v_mov_b32_dpp v21, v14 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DC87E0: 7E2A02FA FF01640E
	v_cndmask_b32_e64 v14, -v14, v14, s3                       // 000000DC87E8: D501000E 200E1D0E
	v_cndmask_b32_e64 v12, -v12, v12, s3                       // 000000DC87F0: D501000C 200E190C
	v_add_f32_e32 v8, v8, v19                                  // 000000DC87F8: 06102708
	v_mov_b32_dpp v15, v11 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DC87FC: 7E1E02FA FF01640B
	v_cndmask_b32_e64 v11, -v11, v11, s3                       // 000000DC8804: D501000B 200E170B
	v_dual_add_f32 v9, v9, v23 :: v_dual_add_f32 v14, v14, v21 // 000000DC880C: C9082F09 090E2B0E
	v_mov_b32_dpp v16, v13 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DC8814: 7E2002FA FF01640D
	v_cndmask_b32_e64 v13, -v13, v13, s3                       // 000000DC881C: D501000D 200E1B0D
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DC8824: BF870004
	v_dual_add_f32 v11, v11, v15 :: v_dual_add_f32 v12, v12, v20// 000000DC8828: C9081F0B 0B0C290C
	v_add_f32_e32 v10, v10, v17                                // 000000DC8830: 0614230A
	v_mov_b32_dpp v23, v7 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DC8834: 7E2E02FA FF016407
	v_cndmask_b32_e64 v7, -v7, v7, s3                          // 000000DC883C: D5010007 200E0F07
	v_mov_b32_dpp v22, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DC8844: 7E2C02FA FF016409
	v_cndmask_b32_e64 v9, -v9, v9, s3                          // 000000DC884C: D5010009 200E1309
	v_mov_b32_dpp v17, v10 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DC8854: 7E2202FA FF01680A
	v_cndmask_b32_e64 v10, -v10, v10, s4                       // 000000DC885C: D501000A 2012150A
	v_add_f32_e32 v13, v13, v16                                // 000000DC8864: 061A210D
	v_mov_b32_dpp v19, v12 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DC8868: 7E2602FA FF01680C
	v_mov_b32_dpp v20, v14 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DC8870: 7E2802FA FF01680E
	v_cndmask_b32_e64 v14, -v14, v14, s4                       // 000000DC8878: D501000E 20121D0E
	v_add_f32_e32 v7, v7, v23                                  // 000000DC8880: 060E2F07
	v_cndmask_b32_e64 v12, -v12, v12, s4                       // 000000DC8884: D501000C 2012190C
	v_add_f32_e32 v9, v9, v22                                  // 000000DC888C: 06122D09
	v_mov_b32_dpp v15, v11 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DC8890: 7E1E02FA FF01680B
	v_cndmask_b32_e64 v11, -v11, v11, s4                       // 000000DC8898: D501000B 2012170B
	v_add_f32_e32 v10, v10, v17                                // 000000DC88A0: 0614230A
	v_mov_b32_dpp v16, v13 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DC88A4: 7E2002FA FF01680D
	v_cndmask_b32_e64 v13, -v13, v13, s4                       // 000000DC88AC: D501000D 20121B0D
	v_add_f32_e32 v12, v12, v19                                // 000000DC88B4: 0618270C
	v_add_f32_e32 v14, v14, v20                                // 000000DC88B8: 061C290E
	v_mov_b32_dpp v22, v7 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DC88BC: 7E2C02FA FF016807
	v_cndmask_b32_e64 v7, -v7, v7, s4                          // 000000DC88C4: D5010007 20120F07
	v_add_f32_e32 v11, v11, v15                                // 000000DC88CC: 06161F0B
	v_mov_b32_dpp v21, v9 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DC88D0: 7E2A02FA FF016809
	v_cndmask_b32_e64 v9, -v9, v9, s4                          // 000000DC88D8: D5010009 20121309
	v_mov_b32_dpp v18, v8 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DC88E0: 7E2402FA FF016808
	v_add_f32_e32 v7, v7, v22                                  // 000000DC88E8: 060E2D07
	v_dual_add_f32 v13, v13, v16 :: v_dual_mov_b32 v16, v12    // 000000DC88EC: C910210D 0D10010C
	v_cndmask_b32_e64 v12, -v12, v12, s5                       // 000000DC88F4: D501000C 2016190C
	v_cndmask_b32_e64 v8, -v8, v8, s4                          // 000000DC88FC: D5010008 20121108
	v_add_f32_e32 v9, v9, v21                                  // 000000DC8904: 06122B09
	v_cndmask_b32_e64 v15, -v11, v11, s5                       // 000000DC8908: D501000F 2016170B
	v_permlanex16_b32 v16, v16, s9, 0xfedcba98                 // 000000DC8910: D65C0010 03FC1310 FEDCBA98
	v_permlanex16_b32 v11, v11, s9, 0xfedcba98                 // 000000DC891C: D65C000B 03FC130B FEDCBA98
	v_add_f32_e32 v8, v8, v18                                  // 000000DC8928: 06102508
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000DC892C: BF870243
	v_dual_add_f32 v12, v12, v16 :: v_dual_mov_b32 v17, v14    // 000000DC8930: C910210C 0C10010E
	v_cndmask_b32_e64 v14, -v14, v14, s5                       // 000000DC8938: D501000E 20161D0E
	v_mov_b32_e32 v20, v7                                      // 000000DC8940: 7E280307
	v_cndmask_b32_e64 v7, -v7, v7, s5                          // 000000DC8944: D5010007 20160F07
	v_mul_f32_e32 v12, 0x3db504f3, v12                         // 000000DC894C: 101818FF 3DB504F3
	v_permlanex16_b32 v17, v17, s9, 0xfedcba98                 // 000000DC8954: D65C0011 03FC1311 FEDCBA98
	v_mov_b32_e32 v19, v9                                      // 000000DC8960: 7E260309
	v_cndmask_b32_e64 v9, -v9, v9, s5                          // 000000DC8964: D5010009 20161309
	v_permlanex16_b32 v20, v20, s9, 0xfedcba98                 // 000000DC896C: D65C0014 03FC1314 FEDCBA98
	s_waitcnt vmcnt(2)                                         // 000000DC8978: BF890BF7
	v_fma_mix_f32 v12, v5, v12, neg(0) op_sel_hi:[1,0,0]       // 000000DC897C: CC20000C 8A021905
	v_add_f32_e32 v14, v14, v17                                // 000000DC8984: 061C230E
	v_permlanex16_b32 v19, v19, s9, 0xfedcba98                 // 000000DC8988: D65C0013 03FC1313 FEDCBA98
	v_dual_mov_b32 v16, v13 :: v_dual_add_f32 v7, v7, v20      // 000000DC8994: CA08010D 10062907
	v_mov_b32_e32 v20, v8                                      // 000000DC899C: 7E280308
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000DC89A0: BF870233
	v_dual_mul_f32 v14, 0x3db504f3, v14 :: v_dual_add_f32 v9, v9, v19// 000000DC89A4: C8C81CFF 0E082709 3DB504F3
	v_mov_b32_e32 v19, v10                                     // 000000DC89B0: 7E26030A
	v_cndmask_b32_e64 v8, -v8, v8, s5                          // 000000DC89B4: D5010008 20161108
	v_permlanex16_b32 v20, v20, s9, 0xfedcba98                 // 000000DC89BC: D65C0014 03FC1314 FEDCBA98
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DC89C8: BF870004
	v_fma_mix_f32 v5, v5, v14, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000DC89CC: CC200805 8A021D05
	v_mul_f32_e32 v9, 0x3db504f3, v9                           // 000000DC89D4: 101212FF 3DB504F3
	v_cndmask_b32_e64 v10, -v10, v10, s5                       // 000000DC89DC: D501000A 2016150A
	v_permlanex16_b32 v19, v19, s9, 0xfedcba98                 // 000000DC89E4: D65C0013 03FC1313 FEDCBA98
	v_add_f32_e32 v8, v8, v20                                  // 000000DC89F0: 06102908
	v_mul_f32_e32 v14, 0xbfb8aa3b, v5                          // 000000DC89F4: 101C0AFF BFB8AA3B
	v_fma_mix_f32 v9, v6, v9, neg(0) op_sel_hi:[1,0,0]         // 000000DC89FC: CC200009 8A021306
	v_permlanex16_b32 v16, v16, s9, 0xfedcba98                 // 000000DC8A04: D65C0010 03FC1310 FEDCBA98
	v_add_f32_e32 v10, v10, v19                                // 000000DC8A10: 0614270A
	v_mul_f32_e32 v8, 0x3db504f3, v8                           // 000000DC8A14: 101010FF 3DB504F3
	v_exp_f32_e32 v14, v14                                     // 000000DC8A1C: 7E1C4B0E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000DC8A20: BF870292
	v_dual_mul_f32 v7, 0x3db504f3, v7 :: v_dual_mul_f32 v10, 0x3db504f3, v10// 000000DC8A24: C8C60EFF 070A14FF 3DB504F3
	v_add_f32_e32 v14, 1.0, v14                                // 000000DC8A30: 061C1CF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000DC8A34: BF870232
	v_fma_mix_f32 v6, v6, v7, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000DC8A38: CC200806 8A020F06
	v_cndmask_b32_e64 v7, -v13, v13, s5                        // 000000DC8A40: D5010007 20161B0D
	v_mul_f32_e32 v13, 0xbfb8aa3b, v12                         // 000000DC8A48: 101A18FF BFB8AA3B
	v_div_scale_f32 v22, null, v14, v14, v5                    // 000000DC8A50: D6FC7C16 04161D0E
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000DC8A58: BF870224
	v_mul_f32_e32 v18, 0xbfb8aa3b, v6                          // 000000DC8A5C: 10240CFF BFB8AA3B
	v_div_scale_f32 v19, s6, v5, v14, v5                       // 000000DC8A64: D6FC0613 04161D05
	v_exp_f32_e32 v13, v13                                     // 000000DC8A6C: 7E1A4B0D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DC8A70: BF870113
	v_rcp_f32_e32 v25, v22                                     // 000000DC8A74: 7E325516
	v_exp_f32_e32 v18, v18                                     // 000000DC8A78: 7E244B12
	v_mul_f32_e32 v17, 0xbfb8aa3b, v9                          // 000000DC8A7C: 102212FF BFB8AA3B
	s_delay_alu instid0(TRANS32_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 000000DC8A84: BF870317
	v_add_f32_e32 v13, 1.0, v13                                // 000000DC8A88: 061A1AF2
	v_fma_f32 v29, -v22, v25, 1.0                              // 000000DC8A8C: D613001D 23CA3316
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DC8A94: BF870215
	v_add_f32_e32 v18, 1.0, v18                                // 000000DC8A98: 062424F2
	v_exp_f32_e32 v17, v17                                     // 000000DC8A9C: 7E224B11
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DC8AA0: BF870113
	v_div_scale_f32 v21, null, v13, v13, v12                   // 000000DC8AA4: D6FC7C15 04321B0D
	v_div_scale_f32 v24, null, v18, v18, v6                    // 000000DC8AAC: D6FC7C18 041A2512
	v_div_scale_f32 v32, s8, v6, v18, v6                       // 000000DC8AB4: D6FC0820 041A2506
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 000000DC8ABC: BF870312
	v_rcp_f32_e32 v27, v24                                     // 000000DC8AC0: 7E365518
	v_add_f32_e32 v17, 1.0, v17                                // 000000DC8AC4: 062222F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(TRANS32_DEP_1)// 000000DC8AC8: BF8702A1
	v_div_scale_f32 v23, null, v17, v17, v9                    // 000000DC8ACC: D6FC7C17 04262311
	v_div_scale_f32 v20, s7, v9, v17, v9                       // 000000DC8AD4: D6FC0714 04262309
	v_fma_f32 v31, -v24, v27, 1.0                              // 000000DC8ADC: D613001F 23CA3718
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DC8AE4: BF870093
	v_rcp_f32_e32 v26, v23                                     // 000000DC8AE8: 7E345517
	v_fmac_f32_e32 v27, v31, v27                               // 000000DC8AEC: 5636371F
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000DC8AF0: BF870135
	v_fma_f32 v30, -v23, v26, 1.0                              // 000000DC8AF4: D613001E 23CA3517
	v_add_f32_e32 v11, v15, v11                                // 000000DC8AFC: 0616170F
	v_rcp_f32_e32 v15, v21                                     // 000000DC8B00: 7E1E5515
	v_dual_fmac_f32 v26, v30, v26 :: v_dual_fmac_f32 v25, v29, v25// 000000DC8B04: C800351E 1A18331D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000DC8B0C: BF870291
	v_mul_f32_e32 v30, v20, v26                                // 000000DC8B10: 103C3514
	v_fma_f32 v28, -v21, v15, 1.0                              // 000000DC8B14: D613001C 23CA1F15
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000DC8B1C: BF8701A2
	v_fma_f32 v35, -v23, v30, v20                              // 000000DC8B20: D6130023 24523D17
	v_mul_f32_e32 v11, 0x3db504f3, v11                         // 000000DC8B28: 101616FF 3DB504F3
	v_fmac_f32_e32 v15, v28, v15                               // 000000DC8B30: 561E1F1C
	v_add_f32_e32 v7, v7, v16                                  // 000000DC8B34: 060E2107
	v_div_scale_f32 v16, vcc_lo, v12, v13, v12                 // 000000DC8B38: D6FC6A10 04321B0C
	v_fmac_f32_e32 v30, v35, v26                               // 000000DC8B40: 563C3523
	s_waitcnt vmcnt(1)                                         // 000000DC8B44: BF8907F7
	v_fma_mix_f32 v11, v3, v11, neg(0) op_sel_hi:[1,0,0]       // 000000DC8B48: CC20000B 8A021703
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DC8B50: BF870193
	v_mul_f32_e32 v28, v16, v15                                // 000000DC8B54: 10381F10
	v_fma_f32 v20, -v23, v30, v20                              // 000000DC8B58: D6130014 24523D17
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DC8B60: BF870092
	v_fma_f32 v33, -v21, v28, v16                              // 000000DC8B64: D6130021 24423915
	v_dual_mul_f32 v29, v19, v25 :: v_dual_fmac_f32 v28, v33, v15// 000000DC8B6C: C8C03313 1D1C1F21
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DC8B74: BF870111
	v_fma_f32 v34, -v22, v29, v19                              // 000000DC8B78: D6130022 244E3B16
	v_fma_f32 v16, -v21, v28, v16                              // 000000DC8B80: D6130010 24423915
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DC8B88: BF870112
	v_fmac_f32_e32 v29, v34, v25                               // 000000DC8B8C: 563A3322
	v_div_fmas_f32 v15, v16, v15, v28                          // 000000DC8B90: D637000F 04721F10
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DC8B98: BF8700A2
	v_fma_f32 v19, -v22, v29, v19                              // 000000DC8B9C: D6130013 244E3B16
	s_mov_b32 vcc_lo, s6                                       // 000000DC8BA4: BEEA0006
	v_div_fmas_f32 v16, v19, v25, v29                          // 000000DC8BA8: D6370010 04763313
	s_mov_b32 vcc_lo, s7                                       // 000000DC8BB0: BEEA0007
	v_div_fmas_f32 v19, v20, v26, v30                          // 000000DC8BB4: D6370013 047A3514
	s_mov_b32 vcc_lo, s8                                       // 000000DC8BBC: BEEA0008
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DC8BC0: BF870112
	v_div_fixup_f32 v5, v16, v14, v5                           // 000000DC8BC4: D6270005 04161D10
	v_div_fixup_f32 v9, v19, v17, v9                           // 000000DC8BCC: D6270009 04262313
	v_mul_f32_e32 v7, 0x3db504f3, v7                           // 000000DC8BD4: 100E0EFF 3DB504F3
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DC8BDC: BF870001
	v_fma_mix_f32 v3, v3, v7, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000DC8BE0: CC200803 8A020F03
	v_fma_mix_f32 v7, v4, v8, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000DC8BE8: CC200807 8A021104
	v_div_fixup_f32 v8, v15, v13, v12                          // 000000DC8BF0: D6270008 04321B0F
	v_mul_f32_e32 v31, v32, v27                                // 000000DC8BF8: 103E3720
	v_fma_mix_f32 v4, v4, v10, neg(0) op_sel_hi:[1,0,0]        // 000000DC8BFC: CC200004 8A021504
	v_mul_f32_e32 v3, v3, v5                                   // 000000DC8C04: 10060B03
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DC8C08: BF870193
	v_fma_f32 v36, -v24, v31, v32                              // 000000DC8C0C: D6130024 24823F18
	v_mul_f32_e32 v4, v4, v9                                   // 000000DC8C14: 10081304
	s_waitcnt vmcnt(0)                                         // 000000DC8C18: BF8903F7
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DC8C1C: BF870193
	v_fma_mix_f32 v3, v1, v3, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000DC8C20: CC200803 8A020701
	v_fmac_f32_e32 v31, v36, v27                               // 000000DC8C28: 563E3724
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DC8C2C: BF870091
	v_fma_f32 v21, -v24, v31, v32                              // 000000DC8C30: D6130015 24823F18
	v_div_fmas_f32 v20, v21, v27, v31                          // 000000DC8C38: D6370014 047E3715
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DC8C40: BF870091
	v_div_fixup_f32 v6, v20, v18, v6                           // 000000DC8C44: D6270006 041A2514
	v_mul_f32_e32 v5, v7, v6                                   // 000000DC8C4C: 100A0D07
	v_mul_f32_e32 v6, v11, v8                                  // 000000DC8C50: 100C110B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DC8C54: BF870112
	v_fma_mix_f32 v5, v2, v5, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000DC8C58: CC200805 8A020B02
	v_fma_mix_f32 v7, v6, v1, v3 op_sel_hi:[0,1,0]             // 000000DC8C60: CC200007 140E0306
	v_fma_mix_f32 v1, v6, v1, -v3 op_sel_hi:[0,1,0]            // 000000DC8C68: CC200001 940E0306
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DC8C70: BF8700A3
	v_fma_mix_f32 v8, v4, v2, v5 op_sel_hi:[0,1,0]             // 000000DC8C74: CC200008 14160504
	v_fma_mix_f32 v2, v4, v2, -v5 op_sel_hi:[0,1,0]            // 000000DC8C7C: CC200002 94160504
	v_dual_add_f32 v3, v7, v8 :: v_dual_add_f32 v4, v1, v2     // 000000DC8C84: C9081107 03040501
	v_sub_f32_e32 v5, v7, v8                                   // 000000DC8C8C: 080A1107
	v_sub_f32_e32 v1, v1, v2                                   // 000000DC8C90: 08020501
	s_delay_alu instid0(VALU_DEP_3)                            // 000000DC8C94: BF870003
	v_mov_b32_dpp v2, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DC8C98: 7E0402FA FF016103
	v_cndmask_b32_e64 v3, -v3, v3, s1                          // 000000DC8CA0: D5010003 20060703
	v_mov_b32_dpp v6, v4 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DC8CA8: 7E0C02FA FF016104
	v_cndmask_b32_e64 v4, -v4, v4, s1                          // 000000DC8CB0: D5010004 20060904
	v_mov_b32_dpp v7, v5 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DC8CB8: 7E0E02FA FF016105
	v_cndmask_b32_e64 v5, -v5, v5, s1                          // 000000DC8CC0: D5010005 20060B05
	v_add_f32_e32 v2, v3, v2                                   // 000000DC8CC8: 06040503
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DC8CCC: BF870112
	v_dual_add_f32 v3, v4, v6 :: v_dual_add_f32 v4, v5, v7     // 000000DC8CD0: C9080D04 03040F05
	v_mov_b32_dpp v5, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DC8CD8: 7E0A02FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, s2                          // 000000DC8CE0: D5010002 200A0502
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000DC8CE8: BF8701A3
	v_mov_b32_dpp v7, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DC8CEC: 7E0E02FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, s2                          // 000000DC8CF4: D5010004 200A0904
	v_add_f32_e32 v2, v2, v5                                   // 000000DC8CFC: 06040B02
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DC8D00: BF870112
	v_add_f32_e32 v4, v4, v7                                   // 000000DC8D04: 06080F04
	v_mov_b32_dpp v5, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DC8D08: 7E0A02FA FF016402
	v_cndmask_b32_e64 v2, -v2, v2, s3                          // 000000DC8D10: D5010002 200E0502
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000DC8D18: BF8701A3
	v_mov_b32_dpp v7, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DC8D1C: 7E0E02FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s3                          // 000000DC8D24: D5010004 200E0904
	v_add_f32_e32 v2, v2, v5                                   // 000000DC8D2C: 06040B02
	v_mov_b32_dpp v8, v1 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DC8D30: 7E1002FA FF016101
	v_cndmask_b32_e64 v1, -v1, v1, s1                          // 000000DC8D38: D5010001 20060301
	s_mov_b32 s1, 0x3db504f3                                   // 000000DC8D40: BE8100FF 3DB504F3
	v_add_f32_e32 v4, v4, v7                                   // 000000DC8D48: 06080F04
	v_mov_b32_dpp v5, v2 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DC8D4C: 7E0A02FA FF016802
	v_cndmask_b32_e64 v2, -v2, v2, s4                          // 000000DC8D54: D5010002 20120502
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000DC8D5C: BF8701A3
	v_mov_b32_dpp v7, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DC8D60: 7E0E02FA FF016804
	v_cndmask_b32_e64 v4, -v4, v4, s4                          // 000000DC8D68: D5010004 20120904
	v_dual_add_f32 v1, v1, v8 :: v_dual_add_f32 v2, v2, v5     // 000000DC8D70: C9081101 01020B02
	v_mov_b32_dpp v6, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DC8D78: 7E0C02FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, s2                          // 000000DC8D80: D5010003 200A0703
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DC8D88: BF870214
	v_add_f32_e32 v4, v4, v7                                   // 000000DC8D8C: 06080F04
	v_mov_b32_dpp v8, v1 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DC8D90: 7E1002FA FF016201
	v_cndmask_b32_e64 v1, -v1, v1, s2                          // 000000DC8D98: D5010001 200A0301
	v_mov_b32_e32 v5, v2                                       // 000000DC8DA0: 7E0A0302
	v_cndmask_b32_e64 v2, -v2, v2, s5                          // 000000DC8DA4: D5010002 20160502
	v_mov_b32_e32 v7, v4                                       // 000000DC8DAC: 7E0E0304
	v_cndmask_b32_e64 v4, -v4, v4, s5                          // 000000DC8DB0: D5010004 20160904
	v_add_f32_e32 v1, v1, v8                                   // 000000DC8DB8: 06021101
	v_permlanex16_b32 v5, v5, s9, 0xfedcba98                   // 000000DC8DBC: D65C0005 03FC1305 FEDCBA98
	s_mul_hi_i32 s2, s10, 0x500                                // 000000DC8DC8: 9702FF0A 00000500
	v_permlanex16_b32 v7, v7, s9, 0xfedcba98                   // 000000DC8DD0: D65C0007 03FC1307 FEDCBA98
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000DC8DDC: BF870133
	v_mov_b32_dpp v8, v1 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DC8DE0: 7E1002FA FF016401
	v_cndmask_b32_e64 v1, -v1, v1, s3                          // 000000DC8DE8: D5010001 200E0301
	v_add_f32_e32 v2, v2, v5                                   // 000000DC8DF0: 06040B02
	v_dual_add_f32 v4, v4, v7 :: v_dual_add_f32 v1, v1, v8     // 000000DC8DF4: C9080F04 04001101
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DC8DFC: BF8700A1
	v_mov_b32_dpp v8, v1 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DC8E00: 7E1002FA FF016801
	v_cndmask_b32_e64 v1, -v1, v1, s4                          // 000000DC8E08: D5010001 20120301
	v_add_f32_e32 v1, v1, v8                                   // 000000DC8E10: 06021101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DC8E14: BF870091
	v_dual_add_f32 v3, v3, v6 :: v_dual_mov_b32 v8, v1         // 000000DC8E18: C9100D03 03080101
	v_mov_b32_dpp v6, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DC8E20: 7E0C02FA FF016403
	v_cndmask_b32_e64 v3, -v3, v3, s3                          // 000000DC8E28: D5010003 200E0703
	v_cndmask_b32_e64 v1, -v1, v1, s5                          // 000000DC8E30: D5010001 20160301
	s_mul_i32 s3, s10, 0x500                                   // 000000DC8E38: 9603FF0A 00000500
	v_permlanex16_b32 v8, v8, s9, 0xfedcba98                   // 000000DC8E40: D65C0008 03FC1308 FEDCBA98
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DC8E4C: BF870113
	v_add_f32_e32 v3, v3, v6                                   // 000000DC8E50: 06060D03
	v_add_f32_e32 v5, v1, v8                                   // 000000DC8E54: 060A1101
	v_fma_mixlo_f16 v1, v2, s1, 0                              // 000000DC8E58: CC210001 02000302
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_3)// 000000DC8E60: BF8701D3
	v_mov_b32_dpp v6, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DC8E64: 7E0C02FA FF016803
	v_cndmask_b32_e64 v3, -v3, v3, s4                          // 000000DC8E6C: D5010003 20120703
	s_add_u32 s4, s30, s3                                      // 000000DC8E74: 8004031E
	v_fma_mixlo_f16 v2, v4, s1, 0                              // 000000DC8E78: CC210002 02000304
	v_fma_mixhi_f16 v2, v5, s1, 0                              // 000000DC8E80: CC220002 02000305
	v_add_f32_e32 v3, v3, v6                                   // 000000DC8E88: 06060D03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000DC8E8C: BF870141
	v_mov_b32_e32 v6, v3                                       // 000000DC8E90: 7E0C0303
	v_cndmask_b32_e64 v3, -v3, v3, s5                          // 000000DC8E94: D5010003 20160703
	s_addc_u32 s5, s31, s2                                     // 000000DC8E9C: 8205021F
	s_lshl_b64 s[2:3], s[16:17], 1                             // 000000DC8EA0: 84828110
	v_permlanex16_b32 v6, v6, s9, 0xfedcba98                   // 000000DC8EA4: D65C0006 03FC1306 FEDCBA98
	s_add_u32 s2, s4, s2                                       // 000000DC8EB0: 80020204
	s_addc_u32 s3, s5, s3                                      // 000000DC8EB4: 82030305
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DC8EB8: BF870091
	v_add_f32_e32 v3, v3, v6                                   // 000000DC8EBC: 06060D03
	v_fma_mixhi_f16 v1, v3, s1, 0                              // 000000DC8EC0: CC220001 02000303
	global_store_b64 v0, v[1:2], s[2:3]                        // 000000DC8EC8: DC6E0000 00020100
	s_and_b32 exec_lo, exec_lo, s0                             // 000000DC8ED0: 8B7E007E
	s_cbranch_execz 8                                          // 000000DC8ED4: BFA50008 <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_oILi1EEEvPKhlPKDF16_PKiPfS5_S5_PDF16_PjNS0_5I4rSdEiS7_+0x6bf8>
	s_ashr_i32 s15, s14, 31                                    // 000000DC8ED8: 860F9F0E
	v_mov_b32_e32 v0, 0                                        // 000000DC8EDC: 7E000280
	s_lshl_b64 s[0:1], s[14:15], 2                             // 000000DC8EE0: 8480820E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000DC8EE4: BF870009
	s_add_u32 s0, s12, s0                                      // 000000DC8EE8: 8000000C
	s_addc_u32 s1, s13, s1                                     // 000000DC8EEC: 8201010D
	global_store_b32 v0, v0, s[0:1]                            // 000000DC8EF0: DC6A0000 00000000
	s_nop 0                                                    // 000000DC8EF8: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 000000DC8EFC: BFB60003
	s_endpgm                                                   // 000000DC8F00: BFB00000
		...

