0000000000230400 <_ZN7halogen12_GLOBAL__N_114k_i4r_rows_rotEPKhliPKtPKDF16_PKiPf>:
; _ZN7halogen12_GLOBAL__N_114k_i4r_rows_rotEPKhliPKtPKDF16_PKiPf():
	s_clause 0x1                                               // 000000230400: BF850001
	s_load_b32 s18, s[0:1], 0x10                               // 000000230404: F4000480 F8000010
	s_load_b256 s[8:15], s[0:1], 0x18                          // 00000023040C: F40C0200 F8000018
	s_mov_b32 s17, 0                                           // 000000230414: BE910080
	s_mov_b32 s20, exec_lo                                     // 000000230418: BE94007E
	s_waitcnt lgkmcnt(0)                                       // 00000023041C: BF89FC07
	s_ashr_i32 s3, s18, 31                                     // 000000230420: 86039F12
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000230424: BF870499
	s_lshr_b32 s3, s3, 26                                      // 000000230428: 85039A03
	s_add_i32 s3, s18, s3                                      // 00000023042C: 81030312
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000230430: BF870499
	s_ashr_i32 s19, s3, 6                                      // 000000230434: 86138603
	s_cvt_f32_u32 s3, s19                                      // 000000230438: BE836513
	s_sub_i32 s4, 0, s19                                       // 00000023043C: 81841380
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000230440: BF87029A
	v_rcp_iflag_f32_e32 v1, s3                                 // 000000230444: 7E025603
	v_readfirstlane_b32 s3, v1                                 // 000000230448: 7E060501
	s_mul_f32 s3, s3, 0x4f7ffffe                               // 00000023044C: A203FF03 4F7FFFFE
	s_delay_alu instid0(SALU_CYCLE_3) | instskip(NEXT) | instid1(SALU_CYCLE_3)// 000000230454: BF87059B
	s_cvt_u32_f32 s3, s3                                       // 000000230458: BE836703
	s_mul_i32 s4, s4, s3                                       // 00000023045C: 96040304
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000230460: BF870499
	s_mul_hi_u32 s4, s3, s4                                    // 000000230464: 96840403
	s_add_i32 s3, s3, s4                                       // 000000230468: 81030403
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000023046C: BF870499
	s_mul_hi_u32 s3, s2, s3                                    // 000000230470: 96830302
	s_mul_i32 s4, s3, s19                                      // 000000230474: 96041303
	s_add_i32 s5, s3, 1                                        // 000000230478: 81058103
	s_sub_i32 s4, s2, s4                                       // 00000023047C: 81840402
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000230480: BF870009
	s_sub_i32 s6, s4, s19                                      // 000000230484: 81861304
	s_cmp_ge_u32 s4, s19                                       // 000000230488: BF091304
	s_cselect_b32 s3, s5, s3                                   // 00000023048C: 98030305
	s_cselect_b32 s4, s6, s4                                   // 000000230490: 98040406
	s_add_i32 s5, s3, 1                                        // 000000230494: 81058103
	s_cmp_ge_u32 s4, s19                                       // 000000230498: BF091304
	s_cselect_b32 s16, s5, s3                                  // 00000023049C: 98100305
	v_cmpx_gt_u32_e32 0x280, v0                                // 0000002304A0: 7D9800FF 00000280
	s_cbranch_execz 207                                        // 0000002304A8: BFA500CF <_ZN7halogen12_GLOBAL__N_114k_i4r_rows_rotEPKhliPKtPKDF16_PKiPf+0x3e8>
	s_mul_hi_u32 s3, s16, 0xcccccccd                           // 0000002304AC: 9683FF10 CCCCCCCD
	v_and_b32_e32 v3, 31, v0                                   // 0000002304B4: 3606009F
	v_and_b32_e32 v5, 2, v0                                    // 0000002304B8: 360A0082
	v_and_b32_e32 v6, 4, v0                                    // 0000002304BC: 360C0084
	v_and_b32_e32 v7, 8, v0                                    // 0000002304C0: 360E0088
	s_lshr_b32 s3, s3, 3                                       // 0000002304C4: 85038303
	v_lshrrev_b32_e32 v2, 5, v0                                // 0000002304C8: 32040085
	s_mul_hi_u32 s7, s3, 0x1400                                // 0000002304CC: 9687FF03 00001400
	s_mulk_i32 s3, 0x1400                                      // 0000002304D4: B8031400
	v_lshlrev_b32_e32 v1, 2, v3                                // 0000002304D8: 30020682
	v_and_b32_e32 v4, 1, v0                                    // 0000002304DC: 36080081
	s_add_u32 s8, s8, s3                                       // 0000002304E0: 80080308
	.long 0xd44a0003                                           // 0000002304E4: D44A0003
	v_cndmask_b32_e32 v1, 0, v5, vcc_lo                        // 0000002304E8: 02020A80
	.long 0xd44a0004                                           // 0000002304EC: D44A0004
	v_cndmask_b32_e32 v1, 0, v6, vcc_lo                        // 0000002304F0: 02020C80
	.long 0xd44a0005                                           // 0000002304F4: D44A0005
	v_cndmask_b32_e32 v1, 0, v7, vcc_lo                        // 0000002304F8: 02020E80
	.long 0xd44c0006                                           // 0000002304FC: D44C0006
	v_cndmask_b32_e32 v1, 16, v3, vcc_lo                       // 000000230500: 02020690
	v_lshlrev_b32_e32 v3, 3, v3                                // 000000230504: 30060683
	s_addc_u32 s9, s9, s7                                      // 000000230508: 82090709
	s_mov_b32 s21, 0x76543210                                  // 00000023050C: BE9500FF 76543210
	s_mov_b32 s22, 0x3db504f3                                  // 000000230514: BE9600FF 3DB504F3
	v_cmp_eq_u32_e32 vcc_lo, 0, v4                             // 00000023051C: 7C940880
	v_lshlrev_b32_e32 v8, 8, v2                                // 000000230520: 30100488
	.long 0xd4490007                                           // 000000230524: D4490007
	v_cndmask_b32_e32 v1, 11, v2, vcc_lo                       // 000000230528: 0202048B
	s_delay_alu instid0(VALU_DEP_2)                            // 00000023052C: BF870002
	v_lshl_or_b32 v6, v1, 1, v8                                // 000000230530: D6560006 04210301
	s_or_b32 s17, s7, s17                                      // 000000230538: 8C111107
	s_clause 0x1                                               // 00000023053C: BF850001
	global_load_b64 v[4:5], v6, s[8:9]                         // 000000230540: DC560000 04080006
	global_load_b64 v[6:7], v6, s[10:11]                       // 000000230548: DC560000 060A0006
	s_waitcnt vmcnt(1)                                         // 000000230550: BF8907F7
	.long 0x7e143904                                           // 000000230554: 7E143904
	v_and_b32_e32 v4, 0xffff0000, v4                           // 000000230558: 360808FF FFFF0000
	.long 0x7e163905                                           // 000000230560: 7E163905
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000230564: BF8701A3
	v_lshlrev_b32_e32 v10, 16, v10                             // 000000230568: 30141490
	s_waitcnt vmcnt(0)                                         // 00000023056C: BF8903F7
	v_fma_mix_f32 v4, v6, v4, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000230570: CC200804 8A020906
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000230578: BF8701C1
	v_fma_mix_f32 v13, v6, v10, v4 op_sel_hi:[1,0,0]           // 00000023057C: CC20000D 0C121506
	v_and_b32_e32 v5, 0xffff0000, v5                           // 000000230584: 360A0AFF FFFF0000
	v_fma_mix_f32 v4, v6, v10, -v4 op_sel_hi:[1,0,0]           // 00000023058C: CC200004 8C121506
	v_lshlrev_b32_e32 v11, 16, v11                             // 000000230594: 30161690
	v_fma_mix_f32 v5, v7, v5, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000230598: CC200805 8A020B07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002305A0: BF870121
	v_fma_mix_f32 v12, v7, v11, v5 op_sel_hi:[1,0,0]           // 0000002305A4: CC20000C 0C161707
	v_fma_mix_f32 v5, v7, v11, -v5 op_sel_hi:[1,0,0]           // 0000002305AC: CC200005 8C161707
	v_dual_add_f32 v6, v13, v12 :: v_dual_add_nc_u32 v9, 8, v2 // 0000002305B4: C920190D 06080488
	s_delay_alu instid0(VALU_DEP_2)                            // 0000002305BC: BF870002
	v_add_f32_e32 v7, v5, v4                                   // 0000002305C0: 060E0905
	v_sub_f32_e32 v10, v13, v12                                // 0000002305C4: 0814190D
	v_sub_f32_e32 v4, v4, v5                                   // 0000002305C8: 08080B04
	v_or_b32_e32 v8, v3, v8                                    // 0000002305CC: 38101103
	v_mov_b32_dpp v5, v6 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000002305D0: 7E0A02FA FF016106
	v_mov_b32_dpp v11, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000002305D8: 7E1602FA FF016107
	v_mov_b32_dpp v12, v10 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000002305E0: 7E1802FA FF01610A
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 0000002305E8: D5010006 21AA0D06
	v_cndmask_b32_e64 v7, -v7, v7, vcc_lo                      // 0000002305F0: D5010007 21AA0F07
	v_cndmask_b32_e64 v10, -v10, v10, vcc_lo                   // 0000002305F8: D501000A 21AA150A
	v_mov_b32_dpp v13, v4 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000230600: 7E1A02FA FF016104
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 000000230608: D5010004 21AA0904
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000230610: BF870214
	v_dual_add_f32 v5, v6, v5 :: v_dual_add_f32 v6, v7, v11    // 000000230614: C9080B06 05061707
	v_add_f32_e32 v7, v10, v12                                 // 00000023061C: 060E190A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000230620: BF870232
	v_mov_b32_dpp v10, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000230624: 7E1402FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, s3                          // 00000023062C: D5010005 200E0B05
	v_add_f32_e32 v4, v4, v13                                  // 000000230634: 06081B04
	v_mov_b32_dpp v12, v7 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000230638: 7E1802FA FF016207
	v_cndmask_b32_e64 v7, -v7, v7, s3                          // 000000230640: D5010007 200E0F07
	v_mov_b32_dpp v11, v6 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000230648: 7E1602FA FF016206
	v_cndmask_b32_e64 v6, -v6, v6, s3                          // 000000230650: D5010006 200E0D06
	v_add_f32_e32 v5, v5, v10                                  // 000000230658: 060A1505
	v_mov_b32_dpp v13, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000023065C: 7E1A02FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, s3                          // 000000230664: D5010004 200E0904
	v_add_f32_e32 v7, v7, v12                                  // 00000023066C: 060E1907
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000230670: BF870234
	v_mov_b32_dpp v10, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000230674: 7E1402FA FF016405
	v_cndmask_b32_e64 v5, -v5, v5, s4                          // 00000023067C: D5010005 20120B05
	v_add_f32_e32 v6, v6, v11                                  // 000000230684: 060C1706
	v_mov_b32_dpp v12, v7 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000230688: 7E1802FA FF016407
	v_cndmask_b32_e64 v7, -v7, v7, s4                          // 000000230690: D5010007 20120F07
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000230698: BF870214
	v_dual_add_f32 v4, v4, v13 :: v_dual_add_f32 v5, v5, v10   // 00000023069C: C9081B04 04041505
	v_mov_b32_dpp v11, v6 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000002306A4: 7E1602FA FF016406
	v_cndmask_b32_e64 v6, -v6, v6, s4                          // 0000002306AC: D5010006 20120D06
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002306B4: BF870214
	v_add_f32_e32 v7, v7, v12                                  // 0000002306B8: 060E1907
	v_mov_b32_dpp v13, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000002306BC: 7E1A02FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s4                          // 0000002306C4: D5010004 20120904
	v_mov_b32_dpp v10, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000002306CC: 7E1402FA FF016805
	v_cndmask_b32_e64 v5, -v5, v5, s5                          // 0000002306D4: D5010005 20160B05
	v_add_f32_e32 v6, v6, v11                                  // 0000002306DC: 060C1706
	v_mov_b32_dpp v12, v7 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000002306E0: 7E1802FA FF016807
	v_cndmask_b32_e64 v7, -v7, v7, s5                          // 0000002306E8: D5010007 20160F07
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002306F0: BF870214
	v_dual_add_f32 v4, v4, v13 :: v_dual_add_f32 v5, v5, v10   // 0000002306F4: C9081B04 04041505
	v_mov_b32_dpp v11, v6 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000002306FC: 7E1602FA FF016806
	v_cndmask_b32_e64 v6, -v6, v6, s5                          // 000000230704: D5010006 20160D06
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000023070C: BF870214
	v_add_f32_e32 v7, v7, v12                                  // 000000230710: 060E1907
	v_mov_b32_dpp v13, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000230714: 7E1A02FA FF016804
	v_cndmask_b32_e64 v4, -v4, v4, s5                          // 00000023071C: D5010004 20160904
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000230724: BF8701A3
	v_mov_b32_e32 v12, v7                                      // 000000230728: 7E180307
	v_cndmask_b32_e64 v7, -v7, v7, s6                          // 00000023072C: D5010007 201A0F07
	v_add_f32_e32 v4, v4, v13                                  // 000000230734: 06081B04
	v_add_f32_e32 v6, v6, v11                                  // 000000230738: 060C1706
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000023073C: BF870194
	v_permlanex16_b32 v12, v12, s21, 0xfedcba98                // 000000230740: D65C000C 03FC2B0C FEDCBA98
	v_dual_mov_b32 v10, v5 :: v_dual_mov_b32 v13, v4           // 00000023074C: CA100105 0A0C0104
	s_delay_alu instid0(VALU_DEP_3)                            // 000000230754: BF870003
	v_mov_b32_e32 v11, v6                                      // 000000230758: 7E160306
	v_cndmask_b32_e64 v6, -v6, v6, s6                          // 00000023075C: D5010006 201A0D06
	v_cndmask_b32_e64 v5, -v5, v5, s6                          // 000000230764: D5010005 201A0B05
	v_cndmask_b32_e64 v4, -v4, v4, s6                          // 00000023076C: D5010004 201A0904
	v_permlanex16_b32 v13, v13, s21, 0xfedcba98                // 000000230774: D65C000D 03FC2B0D FEDCBA98
	v_permlanex16_b32 v11, v11, s21, 0xfedcba98                // 000000230780: D65C000B 03FC2B0B FEDCBA98
	v_add_f32_e32 v7, v7, v12                                  // 00000023078C: 060E1907
	v_permlanex16_b32 v10, v10, s21, 0xfedcba98                // 000000230790: D65C000A 03FC2B0A FEDCBA98
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000023079C: BF870113
	v_add_f32_e32 v2, v6, v11                                  // 0000002307A0: 06041706
	v_dual_add_f32 v6, v4, v13 :: v_dual_add_f32 v5, v5, v10   // 0000002307A4: C9081B04 06041505
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000002307AC: BF8701A2
	v_fma_mixhi_f16 v4, v2, s22, 0                             // 0000002307B0: CC220004 02002D02
	v_mov_b32_e32 v2, v9                                       // 0000002307B8: 7E040309
	v_fma_mixlo_f16 v4, v5, s22, 0                             // 0000002307BC: CC210004 02002D05
	s_delay_alu instid0(VALU_DEP_4)                            // 0000002307C4: BF870004
	v_fma_mixhi_f16 v5, v6, s22, 0                             // 0000002307C8: CC220005 02002D06
	v_fma_mixlo_f16 v5, v7, s22, 0                             // 0000002307D0: CC210005 02002D07
	ds_store_b64 v8, v[4:5]                                    // 0000002307D8: D9340000 00000408
	s_and_not1_b32 exec_lo, exec_lo, s17                       // 0000002307E0: 917E117E
	s_cbranch_execnz 65358                                     // 0000002307E4: BFA6FF4E <_ZN7halogen12_GLOBAL__N_114k_i4r_rows_rotEPKhliPKtPKDF16_PKiPf+0x120>
	s_or_b32 exec_lo, exec_lo, s20                             // 0000002307E8: 8C7E147E
	s_ashr_i32 s17, s16, 31                                    // 0000002307EC: 86119F10
	s_mul_i32 s3, s16, s19                                     // 0000002307F0: 96031310
	s_lshl_b64 s[4:5], s[16:17], 2                             // 0000002307F4: 84848210
	s_sub_i32 s6, s2, s3                                       // 0000002307F8: 81860302
	s_add_u32 s2, s12, s4                                      // 0000002307FC: 8002040C
	s_addc_u32 s3, s13, s5                                     // 000000230800: 8203050D
	s_waitcnt lgkmcnt(0)                                       // 000000230804: BF89FC07
	s_barrier                                                  // 000000230808: BFBD0000
	buffer_gl0_inv                                             // 00000023080C: E0AC0000 00000000
	v_lshrrev_b32_e32 v1, 2, v0                                // 000000230814: 32020082
	s_load_b32 s4, s[2:3], null                                // 000000230818: F4000101 F8000000
	v_bfe_u32 v2, v0, 2, 3                                     // 000000230820: D6100002 020D0500
	s_load_b128 s[0:3], s[0:1], null                           // 000000230828: F4080000 F8000000
	s_lshl_b32 s5, s6, 6                                       // 000000230830: 84058606
	v_dual_mov_b32 v62, 0 :: v_dual_and_b32 v1, 56, v1         // 000000230834: CA240080 3E0002B8
	v_dual_mov_b32 v64, 0 :: v_dual_and_b32 v59, 3, v0         // 00000023083C: CA240080 403A0083
	v_mov_b32_e32 v61, 0                                       // 000000230844: 7E7A0280
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000230848: BF870193
	v_or3_b32 v55, s5, v1, v2                                  // 00000023084C: D6580037 040A0205
	v_dual_mov_b32 v63, 0 :: v_dual_lshlrev_b32 v60, 6, v59    // 000000230854: CA220080 3F3C7686
	v_lshlrev_b32_e32 v0, 4, v59                               // 00000023085C: 30007684
	ds_load_b128 v[30:33], v60                                 // 000000230860: DBFC0000 1E00003C
	ds_load_b128 v[34:37], v60 offset:16                       // 000000230868: DBFC0010 2200003C
	ds_load_b128 v[38:41], v60 offset:256                      // 000000230870: DBFC0100 2600003C
	ds_load_b128 v[42:45], v60 offset:272                      // 000000230878: DBFC0110 2A00003C
	ds_load_b128 v[46:49], v60 offset:512                      // 000000230880: DBFC0200 2E00003C
	ds_load_b128 v[67:70], v60 offset:528                      // 000000230888: DBFC0210 4300003C
	ds_load_b128 v[71:74], v60 offset:768                      // 000000230890: DBFC0300 4700003C
	ds_load_b128 v[75:78], v60 offset:784                      // 000000230898: DBFC0310 4B00003C
	v_ashrrev_i32_e32 v56, 31, v55                             // 0000002308A0: 34706E9F
	v_dual_mov_b32 v66, 0 :: v_dual_mov_b32 v65, 0             // 0000002308A4: CA100080 42400080
	s_waitcnt lgkmcnt(0)                                       // 0000002308AC: BF89FC07
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002308B0: BF870092
	v_mad_i64_i32 v[1:2], null, s4, s18, v[55:56]              // 0000002308B4: D6FF7C01 04DC2404
	v_mad_u64_u32 v[3:4], null, 0x500, v1, s[0:1]              // 0000002308BC: D6FE7C03 000202FF 00000500
	s_add_u32 s0, s0, s2                                       // 0000002308C8: 80000200
	s_addc_u32 s1, s1, s3                                      // 0000002308CC: 82010301
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(VALU_DEP_3)// 0000002308D0: BF8701D9
	v_mad_u64_u32 v[52:53], null, v1, 40, s[0:1]               // 0000002308D4: D6FE7C34 00015101
	s_mov_b32 s0, exec_lo                                      // 0000002308DC: BE80007E
	v_mad_u64_u32 v[4:5], null, 0x500, v2, v[4:5]              // 0000002308E0: D6FE7C04 041204FF 00000500
	.long 0xd7006a39                                           // 0000002308EC: D7006A39
	v_cndmask_b32_e32 v1, v3, v0, vcc_lo                       // 0000002308F0: 02020103
	v_mad_u64_u32 v[53:54], null, v2, 40, v[53:54]             // 0000002308F4: D6FE7C35 04D55102
	v_add_co_ci_u32_e64 v58, null, 0, v4, vcc_lo               // 0000002308FC: D5207C3A 01AA0880
	s_clause 0x5                                               // 000000230904: BF850005
	global_load_b128 v[26:29], v[57:58], off                   // 000000230908: DC5E0000 1A7C0039
	global_load_b128 v[22:25], v[57:58], off offset:64         // 000000230910: DC5E0040 167C0039
	global_load_b128 v[18:21], v[57:58], off offset:128        // 000000230918: DC5E0080 127C0039
	global_load_b128 v[14:17], v[57:58], off offset:192        // 000000230920: DC5E00C0 0E7C0039
	global_load_b128 v[3:6], v[57:58], off offset:256          // 000000230928: DC5E0100 037C0039
	global_load_b128 v[7:10], v[57:58], off offset:320         // 000000230930: DC5E0140 077C0039
	s_waitcnt vmcnt(5)                                         // 000000230938: BF8917F7
	v_lshrrev_b32_e32 v1, 4, v26                               // 00000023093C: 32023484
	v_and_b32_e32 v0, 0xf0f0f0f, v26                           // 000000230940: 360034FF 0F0F0F0F
	v_and_b32_e32 v50, 0xf0f0f0f, v27                          // 000000230948: 366436FF 0F0F0F0F
	v_lshrrev_b32_e32 v51, 4, v27                              // 000000230950: 32663684
	s_waitcnt vmcnt(4)                                         // 000000230954: BF8913F7
	v_lshrrev_b32_e32 v11, 4, v22                              // 000000230958: 32162C84
	v_and_b32_e32 v1, 0xf0f0f0f, v1                            // 00000023095C: 360202FF 0F0F0F0F
	v_and_b32_e32 v89, 0xf0f0f0f, v25                          // 000000230964: 36B232FF 0F0F0F0F
	v_lshrrev_b32_e32 v90, 4, v25                              // 00000023096C: 32B43284
	s_waitcnt vmcnt(3)                                         // 000000230970: BF890FF7
	v_lshrrev_b32_e32 v13, 4, v18                              // 000000230974: 321A2484
	v_and_b32_e32 v12, 0xf0f0f0f, v18                          // 000000230978: 361824FF 0F0F0F0F
	v_perm_b32 v27, v1, v0, 0xc060c02                          // 000000230980: D644001B 03FE0101 0C060C02
	v_perm_b32 v25, v1, v0, 0xc040c00                          // 00000023098C: D6440019 03FE0101 0C040C00
	v_perm_b32 v26, v1, v0, 0xc050c01                          // 000000230998: D644001A 03FE0101 0C050C01
	v_perm_b32 v0, v1, v0, 0xc070c03                           // 0000002309A4: D6440000 03FE0101 0C070C03
	v_and_b32_e32 v11, 0xf0f0f0f, v11                          // 0000002309B0: 361616FF 0F0F0F0F
	v_or_b32_e32 v27, 0x64006400, v27                          // 0000002309B8: 383636FF 64006400
	v_and_b32_e32 v13, 0xf0f0f0f, v13                          // 0000002309C0: 361A1AFF 0F0F0F0F
	v_lshrrev_b32_e32 v83, 4, v28                              // 0000002309C8: 32A63884
	v_or_b32_e32 v0, 0x64006400, v0                            // 0000002309CC: 380000FF 64006400
	s_waitcnt vmcnt(2)                                         // 0000002309D4: BF890BF7
	v_and_b32_e32 v18, 0xf0f0f0f, v14                          // 0000002309D8: 36241CFF 0F0F0F0F
	.long 0xcc0f401b                                           // 0000002309E0: CC0F401B
	v_mul_i32_i24_e32 v1, 0xe408, v27                          // 0000002309E4: 120236FF 0000E408
	v_and_b32_e32 v2, 0xf0f0f0f, v22                           // 0000002309EC: 36042CFF 0F0F0F0F
	v_perm_b32 v80, v13, v12, 0xc050c01                        // 0000002309F4: D6440050 03FE190D 0C050C01
	.long 0xcc0f4000                                           // 000000230A00: CC0F4000
	v_mul_i32_i24_e32 v1, 0xe408, v0                           // 000000230A04: 120200FF 0000E408
	v_and_b32_e32 v54, 0xf0f0f0f, v28                          // 000000230A0C: 366C38FF 0F0F0F0F
	v_lshrrev_b32_e32 v14, 4, v14                              // 000000230A14: 321C1C84
	v_perm_b32 v1, v11, v2, 0xc040c00                          // 000000230A18: D6440001 03FE050B 0C040C00
	v_perm_b32 v28, v11, v2, 0xc050c01                         // 000000230A24: D644001C 03FE050B 0C050C01
	v_perm_b32 v79, v11, v2, 0xc060c02                         // 000000230A30: D644004F 03FE050B 0C060C02
	v_perm_b32 v2, v11, v2, 0xc070c03                          // 000000230A3C: D6440002 03FE050B 0C070C03
	v_or_b32_e32 v11, 0x64006400, v25                          // 000000230A48: 381632FF 64006400
	v_perm_b32 v25, v13, v12, 0xc040c00                        // 000000230A50: D6440019 03FE190D 0C040C00
	v_and_b32_e32 v14, 0xf0f0f0f, v14                          // 000000230A5C: 361C1CFF 0F0F0F0F
	v_or_b32_e32 v1, 0x64006400, v1                            // 000000230A64: 380202FF 64006400
	v_or_b32_e32 v26, 0x64006400, v26                          // 000000230A6C: 383434FF 64006400
	.long 0xcc0f400b                                           // 000000230A74: CC0F400B
	v_mul_i32_i24_e32 v1, 0xe408, v11                          // 000000230A78: 120216FF 0000E408
	v_or_b32_e32 v25, 0x64006400, v25                          // 000000230A80: 383232FF 64006400
	v_perm_b32 v91, v14, v18, 0xc060c02                        // 000000230A88: D644005B 03FE250E 0C060C02
	.long 0xcc0f4001                                           // 000000230A94: CC0F4001
	v_mul_i32_i24_e32 v1, 0xe408, v1                           // 000000230A98: 120202FF 0000E408
	v_and_b32_e32 v87, 0xf0f0f0f, v29                          // 000000230AA0: 36AE3AFF 0F0F0F0F
	v_dot2acc_f32_f16 v61, v11, v30                            // 000000230AA8: 047A3D0B
	.long 0xcc0f4019                                           // 000000230AAC: CC0F4019
	v_mul_i32_i24_e32 v1, 0xe408, v25                          // 000000230AB0: 120232FF 0000E408
	v_perm_b32 v11, v14, v18, 0xc050c01                        // 000000230AB8: D644000B 03FE250E 0C050C01
	.long 0xcc0f401a                                           // 000000230AC4: CC0F401A
	v_mul_i32_i24_e32 v1, 0xe408, v26                          // 000000230AC8: 120234FF 0000E408
	v_dot2acc_f32_f16 v62, v1, v38                             // 000000230AD0: 047C4D01
	v_or_b32_e32 v1, 0x64006400, v79                           // 000000230AD4: 38029EFF 64006400
	v_dot2acc_f32_f16 v64, v25, v46                            // 000000230ADC: 04805D19
	v_or_b32_e32 v25, 0x64006400, v80                          // 000000230AE0: 3832A0FF 64006400
	v_dot2acc_f32_f16 v61, v26, v31                            // 000000230AE8: 047A3F1A
	v_or_b32_e32 v2, 0x64006400, v2                            // 000000230AEC: 380404FF 64006400
	.long 0xcc0f4001                                           // 000000230AF4: CC0F4001
	v_mul_i32_i24_e32 v1, 0xe408, v1                           // 000000230AF8: 120202FF 0000E408
	v_lshrrev_b32_e32 v88, 4, v29                              // 000000230B00: 32B03A84
	.long 0xcc0f4019                                           // 000000230B04: CC0F4019
	v_mul_i32_i24_e32 v1, 0xe408, v25                          // 000000230B08: 120232FF 0000E408
	v_dot2acc_f32_f16 v61, v27, v32                            // 000000230B10: 047A411B
	.long 0xcc0f4002                                           // 000000230B14: CC0F4002
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000230B18: 120204FF 0000E408
	v_lshrrev_b32_e32 v85, 4, v24                              // 000000230B20: 32AA3084
	v_lshrrev_b32_e32 v92, 4, v21                              // 000000230B24: 32B82A84
	v_dot2acc_f32_f16 v64, v25, v47                            // 000000230B28: 04805F19
	v_perm_b32 v86, v13, v12, 0xc060c02                        // 000000230B2C: D6440056 03FE190D 0C060C02
	v_perm_b32 v12, v13, v12, 0xc070c03                        // 000000230B38: D644000C 03FE190D 0C070C03
	v_perm_b32 v13, v14, v18, 0xc040c00                        // 000000230B44: D644000D 03FE250E 0C040C00
	v_perm_b32 v14, v14, v18, 0xc070c03                        // 000000230B50: D644000E 03FE250E 0C070C03
	v_or_b32_e32 v18, 0x64006400, v28                          // 000000230B5C: 382438FF 64006400
	v_dot2acc_f32_f16 v61, v0, v33                             // 000000230B64: 047A4300
	ds_load_b128 v[26:29], v60 offset:1024                     // 000000230B68: DBFC0400 1A00003C
	ds_load_b128 v[30:33], v60 offset:1040                     // 000000230B70: DBFC0410 1E00003C
	v_and_b32_e32 v84, 0xf0f0f0f, v24                          // 000000230B78: 36A830FF 0F0F0F0F
	v_or_b32_e32 v13, 0x64006400, v13                          // 000000230B80: 381A1AFF 64006400
	.long 0xcc0f4012                                           // 000000230B88: CC0F4012
	v_mul_i32_i24_e32 v1, 0xe408, v18                          // 000000230B8C: 120224FF 0000E408
	v_or_b32_e32 v25, 0x64006400, v14                          // 000000230B94: 38321CFF 64006400
	v_lshrrev_b32_e32 v94, 4, v17                              // 000000230B9C: 32BC2284
	s_waitcnt vmcnt(1)                                         // 000000230BA0: BF8907F7
	v_lshrrev_b32_e32 v96, 4, v6                               // 000000230BA4: 32C00C84
	.long 0xcc0f400d                                           // 000000230BA8: CC0F400D
	v_mul_i32_i24_e32 v1, 0xe408, v13                          // 000000230BAC: 12021AFF 0000E408
	v_dot2acc_f32_f16 v62, v18, v39                            // 000000230BB4: 047C4F12
	.long 0xcc0f4019                                           // 000000230BB8: CC0F4019
	v_mul_i32_i24_e32 v1, 0xe408, v25                          // 000000230BBC: 120232FF 0000E408
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000230BC4: BF870193
	v_dot2acc_f32_f16 v66, v13, v71                            // 000000230BC8: 04848F0D
	v_dot2acc_f32_f16 v62, v1, v40                             // 000000230BCC: 047C5101
	v_or_b32_e32 v1, 0x64006400, v86                           // 000000230BD0: 3802ACFF 64006400
	s_delay_alu instid0(VALU_DEP_2)                            // 000000230BD8: BF870002
	v_dot2acc_f32_f16 v62, v2, v41                             // 000000230BDC: 047C5302
	ds_load_b128 v[38:41], v60 offset:1280                     // 000000230BE0: DBFC0500 2600003C
	ds_load_b128 v[79:82], v60 offset:1296                     // 000000230BE8: DBFC0510 4F00003C
	v_and_b32_e32 v24, 0xf0f0f0f, v3                           // 000000230BF0: 363006FF 0F0F0F0F
	v_lshrrev_b32_e32 v3, 4, v3                                // 000000230BF8: 32060684
	.long 0xcc0f4001                                           // 000000230BFC: CC0F4001
	v_mul_i32_i24_e32 v1, 0xe408, v1                           // 000000230C00: 120202FF 0000E408
	v_or_b32_e32 v2, 0x64006400, v12                           // 000000230C08: 380418FF 64006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000230C10: BF870112
	v_dual_dot2acc_f32_f16 v64, v1, v48 :: v_dual_and_b32 v3, 0xf0f0f0f, v3// 000000230C14: CB246101 400206FF 0F0F0F0F
	.long 0xcc0f4002                                           // 000000230C20: CC0F4002
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000230C24: 120204FF 0000E408
	s_delay_alu instid0(VALU_DEP_2)                            // 000000230C2C: BF870002
	v_perm_b32 v0, v3, v24, 0xc040c00                          // 000000230C30: D6440000 03FE3103 0C040C00
	v_perm_b32 v18, v3, v24, 0xc050c01                         // 000000230C3C: D6440012 03FE3103 0C050C01
	v_perm_b32 v46, v3, v24, 0xc060c02                         // 000000230C48: D644002E 03FE3103 0C060C02
	v_perm_b32 v24, v3, v24, 0xc070c03                         // 000000230C54: D6440018 03FE3103 0C070C03
	v_or_b32_e32 v3, 0x64006400, v11                           // 000000230C60: 380616FF 64006400
	v_or_b32_e32 v0, 0x64006400, v0                            // 000000230C68: 380000FF 64006400
	v_or_b32_e32 v18, 0x64006400, v18                          // 000000230C70: 382424FF 64006400
	v_or_b32_e32 v11, 0x64006400, v91                          // 000000230C78: 3816B6FF 64006400
	v_and_b32_e32 v91, 0xf0f0f0f, v21                          // 000000230C80: 36B62AFF 0F0F0F0F
	.long 0xcc0f4003                                           // 000000230C88: CC0F4003
	v_mul_i32_i24_e32 v1, 0xe408, v3                           // 000000230C8C: 120206FF 0000E408
	.long 0xcc0f4000                                           // 000000230C94: CC0F4000
	v_mul_i32_i24_e32 v1, 0xe408, v0                           // 000000230C98: 120200FF 0000E408
	v_and_b32_e32 v22, 0xf0f0f0f, v23                          // 000000230CA0: 362C2EFF 0F0F0F0F
	.long 0xcc0f4012                                           // 000000230CA8: CC0F4012
	v_mul_i32_i24_e32 v1, 0xe408, v18                          // 000000230CAC: 120224FF 0000E408
	.long 0xcc0f402f                                           // 000000230CB4: CC0F402F
	v_mul_i32_i24_e32 v1, 0xe408, v11                          // 000000230CB8: 120216FF 0000E408
	s_waitcnt lgkmcnt(3)                                       // 000000230CC0: BF89FC37
	v_dual_dot2acc_f32_f16 v66, v3, v72 :: v_dual_dot2acc_f32_f16 v65, v0, v26// 000000230CC4: CB189103 42403500
	v_or_b32_e32 v26, 0x64006400, v46                          // 000000230CCC: 38345CFF 64006400
	v_lshrrev_b32_e32 v23, 4, v23                              // 000000230CD4: 322E2E84
	v_or_b32_e32 v46, 0x64006400, v24                          // 000000230CD8: 385C30FF 64006400
	s_delay_alu instid0(VALU_DEP_4)                            // 000000230CE0: BF870004
	v_dual_dot2acc_f32_f16 v66, v47, v73 :: v_dual_dot2acc_f32_f16 v65, v18, v27// 000000230CE4: CB18932F 42403712
	s_waitcnt vmcnt(0)                                         // 000000230CEC: BF8903F7
	v_lshrrev_b32_e32 v18, 4, v7                               // 000000230CF0: 32240E84
	.long 0xcc0f402f                                           // 000000230CF4: CC0F402F
	v_mul_i32_i24_e32 v1, 0xe408, v26                          // 000000230CF8: 120234FF 0000E408
	v_and_b32_e32 v7, 0xf0f0f0f, v7                            // 000000230D00: 360E0EFF 0F0F0F0F
	.long 0xcc0f402e                                           // 000000230D08: CC0F402E
	v_mul_i32_i24_e32 v1, 0xe408, v46                          // 000000230D0C: 12025CFF 0000E408
	v_dual_dot2acc_f32_f16 v64, v2, v49 :: v_dual_and_b32 v21, 0xf0f0f0f, v51// 000000230D14: CB246302 401466FF 0F0F0F0F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000230D20: BF870244
	v_dual_dot2acc_f32_f16 v65, v47, v28 :: v_dual_and_b32 v18, 0xf0f0f0f, v18// 000000230D24: CB24392F 411224FF 0F0F0F0F
	v_and_b32_e32 v28, 0xf0f0f0f, v19                          // 000000230D30: 363826FF 0F0F0F0F
	v_lshrrev_b32_e32 v47, 4, v19                              // 000000230D38: 325E2684
	v_and_b32_e32 v23, 0xf0f0f0f, v23                          // 000000230D3C: 362E2EFF 0F0F0F0F
	v_perm_b32 v19, v18, v7, 0xc040c00                         // 000000230D44: D6440013 03FE0F12 0C040C00
	v_dot2acc_f32_f16 v65, v46, v29                            // 000000230D50: 04823B2E
	v_and_b32_e32 v29, 0xf0f0f0f, v20                          // 000000230D54: 363A28FF 0F0F0F0F
	v_lshrrev_b32_e32 v46, 4, v20                              // 000000230D5C: 325C2884
	v_perm_b32 v20, v18, v7, 0xc050c01                         // 000000230D60: D6440014 03FE0F12 0C050C01
	v_or_b32_e32 v19, 0x64006400, v19                          // 000000230D6C: 382626FF 64006400
	v_perm_b32 v48, v18, v7, 0xc060c02                         // 000000230D74: D6440030 03FE0F12 0C060C02
	v_perm_b32 v7, v18, v7, 0xc070c03                          // 000000230D80: D6440007 03FE0F12 0C070C03
	v_perm_b32 v49, v21, v50, 0xc040c00                        // 000000230D8C: D6440031 03FE6515 0C040C00
	v_or_b32_e32 v20, 0x64006400, v20                          // 000000230D98: 382828FF 64006400
	.long 0xcc0f4013                                           // 000000230DA0: CC0F4013
	v_mul_i32_i24_e32 v1, 0xe408, v19                          // 000000230DA4: 120226FF 0000E408
	v_or_b32_e32 v18, 0x64006400, v48                          // 000000230DAC: 382460FF 64006400
	v_or_b32_e32 v7, 0x64006400, v7                            // 000000230DB4: 380E0EFF 64006400
	v_perm_b32 v48, v21, v50, 0xc060c02                        // 000000230DBC: D6440030 03FE6515 0C060C02
	.long 0xcc0f4014                                           // 000000230DC8: CC0F4014
	v_mul_i32_i24_e32 v1, 0xe408, v20                          // 000000230DCC: 120228FF 0000E408
	s_waitcnt lgkmcnt(1)                                       // 000000230DD4: BF89FC17
	v_dot2acc_f32_f16 v63, v19, v38                            // 000000230DD8: 047E4D13
	.long 0xcc0f4012                                           // 000000230DDC: CC0F4012
	v_mul_i32_i24_e32 v1, 0xe408, v18                          // 000000230DE0: 120224FF 0000E408
	v_perm_b32 v38, v21, v50, 0xc050c01                        // 000000230DE8: D6440026 03FE6515 0C050C01
	v_or_b32_e32 v19, 0x64006400, v49                          // 000000230DF4: 382662FF 64006400
	v_perm_b32 v49, v23, v22, 0xc040c00                        // 000000230DFC: D6440031 03FE2D17 0C040C00
	v_dual_dot2acc_f32_f16 v63, v20, v39 :: v_dual_dot2acc_f32_f16 v66, v25, v74// 000000230E08: CB184F14 3F429519
	.long 0xcc0f4007                                           // 000000230E10: CC0F4007
	v_mul_i32_i24_e32 v1, 0xe408, v7                           // 000000230E14: 12020EFF 0000E408
	v_perm_b32 v39, v21, v50, 0xc070c03                        // 000000230E1C: D6440027 03FE6515 0C070C03
	v_perm_b32 v50, v23, v22, 0xc060c02                        // 000000230E28: D6440032 03FE2D17 0C060C02
	s_delay_alu instid0(VALU_DEP_4)                            // 000000230E34: BF870004
	v_dot2acc_f32_f16 v63, v18, v40                            // 000000230E38: 047E5112
	.long 0xcc0f4012                                           // 000000230E3C: CC0F4012
	v_mul_i32_i24_e32 v1, 0xe408, v19                          // 000000230E40: 120226FF 0000E408
	v_perm_b32 v40, v23, v22, 0xc050c01                        // 000000230E48: D6440028 03FE2D17 0C050C01
	v_perm_b32 v22, v23, v22, 0xc070c03                        // 000000230E54: D6440016 03FE2D17 0C070C03
	v_or_b32_e32 v23, 0x64006400, v38                          // 000000230E60: 382E4CFF 64006400
	v_dot2acc_f32_f16 v63, v7, v41                             // 000000230E68: 047E5307
	v_or_b32_e32 v7, 0x64006400, v49                           // 000000230E6C: 380E62FF 64006400
	v_dot2acc_f32_f16 v61, v18, v34                            // 000000230E74: 047A4512
	v_or_b32_e32 v34, 0x64006400, v48                          // 000000230E78: 384460FF 64006400
	v_or_b32_e32 v38, 0x64006400, v39                          // 000000230E80: 384C4EFF 64006400
	v_or_b32_e32 v39, 0x64006400, v40                          // 000000230E88: 384E50FF 64006400
	.long 0xcc0f4007                                           // 000000230E90: CC0F4007
	v_mul_i32_i24_e32 v1, 0xe408, v7                           // 000000230E94: 12020EFF 0000E408
	.long 0xcc0f4017                                           // 000000230E9C: CC0F4017
	v_mul_i32_i24_e32 v1, 0xe408, v23                          // 000000230EA0: 12022EFF 0000E408
	s_clause 0x1                                               // 000000230EA8: BF850001
	global_load_b128 v[0:3], v[52:53], off offset:16           // 000000230EAC: DC5E0010 007C0034
	global_load_b128 v[11:14], v[52:53], off                   // 000000230EB4: DC5E0000 0B7C0034
	v_or_b32_e32 v40, 0x64006400, v50                          // 000000230EBC: 385064FF 64006400
	.long 0xcc0f4022                                           // 000000230EC4: CC0F4022
	v_mul_i32_i24_e32 v1, 0xe408, v34                          // 000000230EC8: 120244FF 0000E408
	.long 0xcc0f4027                                           // 000000230ED0: CC0F4027
	v_mul_i32_i24_e32 v1, 0xe408, v39                          // 000000230ED4: 12024EFF 0000E408
	v_dot2acc_f32_f16 v61, v23, v35                            // 000000230EDC: 047A4717
	v_dot2acc_f32_f16 v62, v7, v42                             // 000000230EE0: 047C5507
	v_or_b32_e32 v7, 0x64006400, v22                           // 000000230EE4: 380E2CFF 64006400
	.long 0xcc0f4016                                           // 000000230EEC: CC0F4016
	v_mul_i32_i24_e32 v1, 0xe408, v38                          // 000000230EF0: 12024CFF 0000E408
	.long 0xcc0f4017                                           // 000000230EF8: CC0F4017
	v_mul_i32_i24_e32 v1, 0xe408, v40                          // 000000230EFC: 120250FF 0000E408
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000230F04: BF870244
	v_dual_dot2acc_f32_f16 v61, v34, v36 :: v_dual_dot2acc_f32_f16 v62, v39, v43// 000000230F08: CB184922 3D3E5727
	v_and_b32_e32 v42, 0xf0f0f0f, v47                          // 000000230F10: 36545EFF 0F0F0F0F
	.long 0xcc0f4007                                           // 000000230F18: CC0F4007
	v_mul_i32_i24_e32 v1, 0xe408, v7                           // 000000230F1C: 12020EFF 0000E408
	v_and_b32_e32 v43, 0xf0f0f0f, v16                          // 000000230F24: 365620FF 0F0F0F0F
	v_dual_dot2acc_f32_f16 v61, v22, v37 :: v_dual_dot2acc_f32_f16 v62, v23, v44// 000000230F2C: CB184B16 3D3E5917
	v_and_b32_e32 v23, 0xf0f0f0f, v15                          // 000000230F34: 362E1EFF 0F0F0F0F
	v_perm_b32 v22, v42, v28, 0xc040c00                        // 000000230F3C: D6440016 03FE392A 0C040C00
	v_lshrrev_b32_e32 v44, 4, v16                              // 000000230F48: 32582084
	v_perm_b32 v16, v42, v28, 0xc060c02                        // 000000230F4C: D6440010 03FE392A 0C060C02
	v_dot2acc_f32_f16 v62, v7, v45                             // 000000230F58: 047C5B07
	v_lshrrev_b32_e32 v7, 4, v15                               // 000000230F5C: 320E1E84
	v_perm_b32 v15, v42, v28, 0xc050c01                        // 000000230F60: D644000F 03FE392A 0C050C01
	v_or_b32_e32 v22, 0x64006400, v22                          // 000000230F6C: 382C2CFF 64006400
	v_perm_b32 v28, v42, v28, 0xc070c03                        // 000000230F74: D644001C 03FE392A 0C070C03
	v_or_b32_e32 v16, 0x64006400, v16                          // 000000230F80: 382020FF 64006400
	s_clause 0x1                                               // 000000230F88: BF850001
	global_load_b128 v[24:27], v[57:58], off offset:384        // 000000230F8C: DC5E0180 187C0039
	global_load_b128 v[48:51], v[57:58], off offset:448        // 000000230F94: DC5E01C0 307C0039
	v_or_b32_e32 v15, 0x64006400, v15                          // 000000230F9C: 381E1EFF 64006400
	.long 0xcc0f4016                                           // 000000230FA4: CC0F4016
	v_mul_i32_i24_e32 v1, 0xe408, v22                          // 000000230FA8: 12022CFF 0000E408
	v_and_b32_e32 v93, 0xf0f0f0f, v17                          // 000000230FB0: 36BA22FF 0F0F0F0F
	.long 0xcc0f4010                                           // 000000230FB8: CC0F4010
	v_mul_i32_i24_e32 v1, 0xe408, v16                          // 000000230FBC: 120220FF 0000E408
	v_and_b32_e32 v42, 0xf0f0f0f, v5                           // 000000230FC4: 36540AFF 0F0F0F0F
	.long 0xcc0f400f                                           // 000000230FCC: CC0F400F
	v_mul_i32_i24_e32 v1, 0xe408, v15                          // 000000230FD0: 12021EFF 0000E408
	v_dot2acc_f32_f16 v64, v22, v67                            // 000000230FD8: 04808716
	v_or_b32_e32 v22, 0x64006400, v28                          // 000000230FDC: 382C38FF 64006400
	v_lshrrev_b32_e32 v45, 4, v5                               // 000000230FE4: 325A0A84
	v_and_b32_e32 v7, 0xf0f0f0f, v7                            // 000000230FE8: 360E0EFF 0F0F0F0F
	ds_load_b128 v[18:21], v60 offset:32                       // 000000230FF0: DBFC0020 1200003C
	ds_load_b128 v[71:74], v60 offset:48                       // 000000230FF8: DBFC0030 4700003C
	v_dot2acc_f32_f16 v64, v15, v68                            // 000000231000: 0480890F
	v_and_b32_e32 v17, 0xf0f0f0f, v4                           // 000000231004: 362208FF 0F0F0F0F
	.long 0xcc0f4005                                           // 00000023100C: CC0F4005
	v_mul_i32_i24_e32 v1, 0xe408, v22                          // 000000231010: 12022CFF 0000E408
	v_perm_b32 v22, v7, v23, 0xc050c01                         // 000000231018: D6440016 03FE2F07 0C050C01
	v_lshrrev_b32_e32 v4, 4, v4                                // 000000231024: 32080884
	v_dot2acc_f32_f16 v64, v16, v69                            // 000000231028: 04808B10
	v_and_b32_e32 v16, 0xf0f0f0f, v46                          // 00000023102C: 36205CFF 0F0F0F0F
	v_perm_b32 v46, v7, v23, 0xc060c02                         // 000000231034: D644002E 03FE2F07 0C060C02
	v_or_b32_e32 v22, 0x64006400, v22                          // 000000231040: 382C2CFF 64006400
	v_and_b32_e32 v28, 0xf0f0f0f, v4                           // 000000231048: 363808FF 0F0F0F0F
	v_dual_dot2acc_f32_f16 v64, v5, v70 :: v_dual_and_b32 v15, 0xf0f0f0f, v85// 000000231050: CB248D05 400EAAFF 0F0F0F0F
	v_perm_b32 v5, v7, v23, 0xc040c00                          // 00000023105C: D6440005 03FE2F07 0C040C00
	v_perm_b32 v7, v7, v23, 0xc070c03                          // 000000231068: D6440007 03FE2F07 0C070C03
	v_or_b32_e32 v23, 0x64006400, v46                          // 000000231074: 382E5CFF 64006400
	.long 0xcc0f4016                                           // 00000023107C: CC0F4016
	v_mul_i32_i24_e32 v1, 0xe408, v22                          // 000000231080: 12022CFF 0000E408
	ds_load_b128 v[34:37], v60 offset:544                      // 000000231088: DBFC0220 2200003C
	v_or_b32_e32 v5, 0x64006400, v5                            // 000000231090: 380A0AFF 64006400
	ds_load_b128 v[38:41], v60 offset:288                      // 000000231098: DBFC0120 2600003C
	.long 0xcc0f4005                                           // 0000002310A0: CC0F4005
	v_mul_i32_i24_e32 v1, 0xe408, v5                           // 0000002310A4: 12020AFF 0000E408
	v_and_b32_e32 v95, 0xf0f0f0f, v6                           // 0000002310AC: 36BE0CFF 0F0F0F0F
	v_and_b32_e32 v6, 0xf0f0f0f, v83                           // 0000002310B4: 360CA6FF 0F0F0F0F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000002310BC: BF8701A3
	v_dot2acc_f32_f16 v66, v5, v75                             // 0000002310C0: 04849705
	v_or_b32_e32 v5, 0x64006400, v7                            // 0000002310C4: 380A0EFF 64006400
	v_perm_b32 v4, v6, v54, 0xc040c00                          // 0000002310CC: D6440004 03FE6D06 0C040C00
	v_perm_b32 v47, v6, v54, 0xc050c01                         // 0000002310D8: D644002F 03FE6D06 0C050C01
	v_perm_b32 v46, v6, v54, 0xc060c02                         // 0000002310E4: D644002E 03FE6D06 0C060C02
	v_perm_b32 v54, v6, v54, 0xc070c03                         // 0000002310F0: D6440036 03FE6D06 0C070C03
	.long 0xcc0f4006                                           // 0000002310FC: CC0F4006
	v_mul_i32_i24_e32 v1, 0xe408, v23                          // 000000231100: 12022EFF 0000E408
	v_dot2acc_f32_f16 v66, v22, v76                            // 000000231108: 04849916
	v_perm_b32 v23, v28, v17, 0xc040c00                        // 00000023110C: D6440017 03FE231C 0C040C00
	v_perm_b32 v7, v15, v84, 0xc040c00                         // 000000231118: D6440007 03FEA90F 0C040C00
	v_perm_b32 v22, v15, v84, 0xc050c01                        // 000000231124: D6440016 03FEA90F 0C050C01
	v_perm_b32 v75, v15, v84, 0xc060c02                        // 000000231130: D644004B 03FEA90F 0C060C02
	v_dot2acc_f32_f16 v66, v6, v77                             // 00000023113C: 04849B06
	v_perm_b32 v76, v15, v84, 0xc070c03                        // 000000231140: D644004C 03FEA90F 0C070C03
	v_perm_b32 v6, v28, v17, 0xc050c01                         // 00000023114C: D6440006 03FE231C 0C050C01
	v_or_b32_e32 v15, 0x64006400, v23                          // 000000231158: 381E2EFF 64006400
	.long 0xcc0f4005                                           // 000000231160: CC0F4005
	v_mul_i32_i24_e32 v1, 0xe408, v5                           // 000000231164: 12020AFF 0000E408
	v_or_b32_e32 v4, 0x64006400, v4                            // 00000023116C: 380808FF 64006400
	v_or_b32_e32 v7, 0x64006400, v7                            // 000000231174: 380E0EFF 64006400
	v_or_b32_e32 v6, 0x64006400, v6                            // 00000023117C: 380C0CFF 64006400
	.long 0xcc0f400f                                           // 000000231184: CC0F400F
	v_mul_i32_i24_e32 v1, 0xe408, v15                          // 000000231188: 12021EFF 0000E408
	v_dot2acc_f32_f16 v66, v5, v78                             // 000000231190: 04849D05
	v_or_b32_e32 v22, 0x64006400, v22                          // 000000231194: 382C2CFF 64006400
	ds_load_b128 v[83:86], v60 offset:1312                     // 00000023119C: DBFC0520 5300003C
	.long 0xcc0f4006                                           // 0000002311A4: CC0F4006
	v_mul_i32_i24_e32 v1, 0xe408, v6                           // 0000002311A8: 12020CFF 0000E408
	v_dot2acc_f32_f16 v65, v15, v30                            // 0000002311B0: 04823D0F
	.long 0xcc0f4016                                           // 0000002311B4: CC0F4016
	v_mul_i32_i24_e32 v1, 0xe408, v22                          // 0000002311B8: 12022CFF 0000E408
	s_delay_alu instid0(VALU_DEP_2)                            // 0000002311C0: BF870002
	v_dot2acc_f32_f16 v65, v6, v31                             // 0000002311C4: 04823F06
	v_perm_b32 v23, v16, v29, 0xc040c00                        // 0000002311C8: D6440017 03FE3B10 0C040C00
	v_perm_b32 v67, v16, v29, 0xc050c01                        // 0000002311D4: D6440043 03FE3B10 0C050C01
	v_perm_b32 v77, v16, v29, 0xc060c02                        // 0000002311E0: D644004D 03FE3B10 0C060C02
	v_perm_b32 v78, v16, v29, 0xc070c03                        // 0000002311EC: D644004E 03FE3B10 0C070C03
	.long 0xcc0f4010                                           // 0000002311F8: CC0F4010
	v_mul_i32_i24_e32 v1, 0xe408, v4                           // 0000002311FC: 120208FF 0000E408
	v_or_b32_e32 v23, 0x64006400, v23                          // 000000231204: 382E2EFF 64006400
	.long 0xcc0f401d                                           // 00000023120C: CC0F401D
	v_mul_i32_i24_e32 v1, 0xe408, v7                           // 000000231210: 12020EFF 0000E408
	v_or_b32_e32 v30, 0x64006400, v67                          // 000000231218: 383C86FF 64006400
	s_waitcnt lgkmcnt(4)                                       // 000000231220: BF89FC47
	v_dot2acc_f32_f16 v61, v16, v18                            // 000000231224: 047A2510
	v_perm_b32 v5, v28, v17, 0xc060c02                         // 000000231228: D6440005 03FE231C 0C060C02
	.long 0xcc0f4017                                           // 000000231234: CC0F4017
	v_mul_i32_i24_e32 v1, 0xe408, v23                          // 000000231238: 12022EFF 0000E408
	v_perm_b32 v28, v28, v17, 0xc070c03                        // 000000231240: D644001C 03FE231C 0C070C03
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000023124C: BF870113
	v_or_b32_e32 v5, 0x64006400, v5                            // 000000231250: 380A0AFF 64006400
	v_or_b32_e32 v28, 0x64006400, v28                          // 000000231258: 383838FF 64006400
	s_delay_alu instid0(VALU_DEP_2)                            // 000000231260: BF870002
	.long 0xcc0f400f                                           // 000000231264: CC0F400F
	v_mul_i32_i24_e32 v1, 0xe408, v5                           // 000000231268: 12020AFF 0000E408
	ds_load_b128 v[4:7], v60 offset:304                        // 000000231270: DBFC0130 0400003C
	.long 0xcc0f401c                                           // 000000231278: CC0F401C
	v_mul_i32_i24_e32 v1, 0xe408, v28                          // 00000023127C: 120238FF 0000E408
	v_dot2acc_f32_f16 v65, v15, v32                            // 000000231284: 0482410F
	ds_load_b128 v[15:18], v60 offset:560                      // 000000231288: DBFC0230 0F00003C
	s_waitcnt lgkmcnt(4)                                       // 000000231290: BF89FC47
	v_dot2acc_f32_f16 v64, v23, v34                            // 000000231294: 04804517
	v_or_b32_e32 v23, 0x64006400, v54                          // 000000231298: 382E6CFF 64006400
	.long 0xcc0f4020                                           // 0000002312A0: CC0F4020
	v_mul_i32_i24_e32 v1, 0xe408, v30                          // 0000002312A4: 12023CFF 0000E408
	v_dot2acc_f32_f16 v65, v28, v33                            // 0000002312AC: 0482431C
	v_or_b32_e32 v33, 0x64006400, v77                          // 0000002312B0: 38429AFF 64006400
	v_or_b32_e32 v34, 0x64006400, v76                          // 0000002312B8: 384498FF 64006400
	.long 0xcc0f4017                                           // 0000002312C0: CC0F4017
	v_mul_i32_i24_e32 v1, 0xe408, v23                          // 0000002312C4: 12022EFF 0000E408
	s_waitcnt lgkmcnt(3)                                       // 0000002312CC: BF89FC37
	v_dot2acc_f32_f16 v62, v29, v38                            // 0000002312D0: 047C4D1D
	v_or_b32_e32 v29, 0x64006400, v47                          // 0000002312D4: 383A5EFF 64006400
	v_dot2acc_f32_f16 v64, v32, v35                            // 0000002312DC: 04804720
	v_or_b32_e32 v32, 0x64006400, v75                          // 0000002312E0: 384096FF 64006400
	.long 0xcc0f4021                                           // 0000002312E8: CC0F4021
	v_mul_i32_i24_e32 v1, 0xe408, v33                          // 0000002312EC: 120242FF 0000E408
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002312F4: BF870194
	.long 0xcc0f401d                                           // 0000002312F8: CC0F401D
	v_mul_i32_i24_e32 v1, 0xe408, v29                          // 0000002312FC: 12023AFF 0000E408
	.long 0xcc0f4020                                           // 000000231304: CC0F4020
	v_mul_i32_i24_e32 v1, 0xe408, v32                          // 000000231308: 120240FF 0000E408
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000231310: BF870193
	v_dot2acc_f32_f16 v64, v33, v36                            // 000000231314: 04804921
	v_dot2acc_f32_f16 v61, v29, v19                            // 000000231318: 047A271D
	v_or_b32_e32 v19, 0x64006400, v46                          // 00000023131C: 38265CFF 64006400
	ds_load_b128 v[28:31], v60 offset:800                      // 000000231324: DBFC0320 1C00003C
	ds_load_b128 v[67:70], v60 offset:816                      // 00000023132C: DBFC0330 4300003C
	.long 0xcc0f4013                                           // 000000231334: CC0F4013
	v_mul_i32_i24_e32 v1, 0xe408, v19                          // 000000231338: 120226FF 0000E408
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000231340: BF8701B1
	v_dot2acc_f32_f16 v61, v19, v20                            // 000000231344: 047A2913
	v_or_b32_e32 v19, 0x64006400, v78                          // 000000231348: 38269CFF 64006400
	.long 0xcc0f4014                                           // 000000231350: CC0F4014
	v_mul_i32_i24_e32 v1, 0xe408, v34                          // 000000231354: 120244FF 0000E408
	v_dual_dot2acc_f32_f16 v61, v23, v21 :: v_dual_dot2acc_f32_f16 v62, v22, v39// 00000023135C: CB182B17 3D3E4F16
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000231364: BF870113
	.long 0xcc0f4013                                           // 000000231368: CC0F4013
	v_mul_i32_i24_e32 v1, 0xe408, v19                          // 00000023136C: 120226FF 0000E408
	v_dot2acc_f32_f16 v62, v32, v40                            // 000000231374: 047C5120
	ds_load_b128 v[32:35], v60 offset:1056                     // 000000231378: DBFC0420 2000003C
	ds_load_b128 v[75:78], v60 offset:1072                     // 000000231380: DBFC0430 4B00003C
	v_and_b32_e32 v38, 0xf0f0f0f, v44                          // 000000231388: 364C58FF 0F0F0F0F
	v_dot2acc_f32_f16 v64, v19, v37                            // 000000231390: 04804B13
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000231394: BF8701B2
	v_perm_b32 v22, v38, v43, 0xc040c00                        // 000000231398: D6440016 03FE5726 0C040C00
	v_perm_b32 v36, v38, v43, 0xc050c01                        // 0000002313A4: D6440024 03FE5726 0C050C01
	v_perm_b32 v19, v38, v43, 0xc060c02                        // 0000002313B0: D6440013 03FE5726 0C060C02
	v_or_b32_e32 v39, 0x64006400, v22                          // 0000002313BC: 384E2CFF 64006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002313C4: BF870193
	v_or_b32_e32 v36, 0x64006400, v36                          // 0000002313C8: 384848FF 64006400
	v_or_b32_e32 v19, 0x64006400, v19                          // 0000002313D0: 382626FF 64006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000002313D8: BF870223
	.long 0xcc0f4025                                           // 0000002313DC: CC0F4025
	v_mul_i32_i24_e32 v1, 0xe408, v39                          // 0000002313E0: 12024EFF 0000E408
	v_and_b32_e32 v39, 0xf0f0f0f, v88                          // 0000002313E8: 364EB0FF 0F0F0F0F
	.long 0xcc0f4024                                           // 0000002313F0: CC0F4024
	v_mul_i32_i24_e32 v1, 0xe408, v36                          // 0000002313F4: 120248FF 0000E408
	s_delay_alu instid0(VALU_DEP_4)                            // 0000002313FC: BF870004
	.long 0xcc0f4013                                           // 000000231400: CC0F4013
	v_mul_i32_i24_e32 v1, 0xe408, v19                          // 000000231404: 120226FF 0000E408
	s_waitcnt lgkmcnt(3)                                       // 00000023140C: BF89FC37
	v_dot2acc_f32_f16 v66, v37, v28                            // 000000231410: 04843925
	v_perm_b32 v37, v38, v43, 0xc070c03                        // 000000231414: D6440025 03FE5726 0C070C03
	v_and_b32_e32 v38, 0xf0f0f0f, v45                          // 000000231420: 364C5AFF 0F0F0F0F
	v_perm_b32 v54, v39, v87, 0xc070c03                        // 000000231428: D6440036 03FEAF27 0C070C03
	v_and_b32_e32 v28, 0xf0f0f0f, v90                          // 000000231434: 3638B4FF 0F0F0F0F
	v_dot2acc_f32_f16 v66, v36, v29                            // 00000023143C: 04843B24
	v_perm_b32 v29, v39, v87, 0xc040c00                        // 000000231440: D644001D 03FEAF27 0C040C00
	v_or_b32_e32 v36, 0x64006400, v37                          // 00000023144C: 38484AFF 64006400
	v_perm_b32 v40, v38, v42, 0xc040c00                        // 000000231454: D6440028 03FE5526 0C040C00
	v_perm_b32 v37, v39, v87, 0xc050c01                        // 000000231460: D6440025 03FEAF27 0C050C01
	v_dot2acc_f32_f16 v66, v19, v30                            // 00000023146C: 04843D13
	v_or_b32_e32 v29, 0x64006400, v29                          // 000000231470: 383A3AFF 64006400
	v_perm_b32 v19, v39, v87, 0xc060c02                        // 000000231478: D6440013 03FEAF27 0C060C02
	.long 0xcc0f401e                                           // 000000231484: CC0F401E
	v_mul_i32_i24_e32 v1, 0xe408, v36                          // 000000231488: 120248FF 0000E408
	v_perm_b32 v36, v38, v42, 0xc050c01                        // 000000231490: D6440024 03FE5526 0C050C01
	v_or_b32_e32 v39, 0x64006400, v40                          // 00000023149C: 384E50FF 64006400
	.long 0xcc0f401d                                           // 0000002314A4: CC0F401D
	v_mul_i32_i24_e32 v1, 0xe408, v29                          // 0000002314A8: 12023AFF 0000E408
	v_perm_b32 v87, v28, v89, 0xc050c01                        // 0000002314B0: D6440057 03FEB31C 0C050C01
	v_dot2acc_f32_f16 v66, v30, v31                            // 0000002314BC: 04843F1E
	v_or_b32_e32 v31, 0x64006400, v36                          // 0000002314C0: 383E48FF 64006400
	.long 0xcc0f4024                                           // 0000002314C8: CC0F4024
	v_mul_i32_i24_e32 v1, 0xe408, v39                          // 0000002314CC: 12024EFF 0000E408
	v_dual_dot2acc_f32_f16 v61, v29, v71 :: v_dual_dot2acc_f32_f16 v62, v20, v41// 0000002314D4: CB188F1D 3D3E5314
	s_clause 0x1                                               // 0000002314DC: BF850001
	global_load_b128 v[20:23], v[57:58], off offset:512        // 0000002314E0: DC5E0200 147C0039
	global_load_b128 v[44:47], v[57:58], off offset:576        // 0000002314E8: DC5E0240 2C7C0039
	v_perm_b32 v39, v38, v42, 0xc060c02                        // 0000002314F0: D6440027 03FE5526 0C060C02
	v_perm_b32 v30, v28, v89, 0xc040c00                        // 0000002314FC: D644001E 03FEB31C 0C040C00
	v_perm_b32 v88, v28, v89, 0xc060c02                        // 000000231508: D6440058 03FEB31C 0C060C02
	.long 0xcc0f401f                                           // 000000231514: CC0F401F
	v_mul_i32_i24_e32 v1, 0xe408, v31                          // 000000231518: 12023EFF 0000E408
	s_waitcnt lgkmcnt(1)                                       // 000000231520: BF89FC17
	v_dot2acc_f32_f16 v65, v36, v32                            // 000000231524: 04824124
	v_perm_b32 v89, v28, v89, 0xc070c03                        // 000000231528: D6440059 03FEB31C 0C070C03
	v_perm_b32 v28, v38, v42, 0xc070c03                        // 000000231534: D644001C 03FE5526 0C070C03
	v_or_b32_e32 v32, 0x64006400, v39                          // 000000231540: 38404EFF 64006400
	v_or_b32_e32 v30, 0x64006400, v30                          // 000000231548: 383C3CFF 64006400
	v_dot2acc_f32_f16 v65, v31, v33                            // 000000231550: 0482431F
	v_or_b32_e32 v33, 0x64006400, v37                          // 000000231554: 38424AFF 64006400
	v_or_b32_e32 v28, 0x64006400, v28                          // 00000023155C: 383838FF 64006400
	.long 0xcc0f4020                                           // 000000231564: CC0F4020
	v_mul_i32_i24_e32 v1, 0xe408, v32                          // 000000231568: 120240FF 0000E408
	.long 0xcc0f401e                                           // 000000231570: CC0F401E
	v_mul_i32_i24_e32 v1, 0xe408, v30                          // 000000231574: 12023CFF 0000E408
	v_or_b32_e32 v29, 0x64006400, v87                          // 00000023157C: 383AAEFF 64006400
	.long 0xcc0f4021                                           // 000000231584: CC0F4021
	v_mul_i32_i24_e32 v1, 0xe408, v33                          // 000000231588: 120242FF 0000E408
	.long 0xcc0f401c                                           // 000000231590: CC0F401C
	v_mul_i32_i24_e32 v1, 0xe408, v28                          // 000000231594: 120238FF 0000E408
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000023159C: BF870224
	v_dual_dot2acc_f32_f16 v65, v32, v34 :: v_dual_dot2acc_f32_f16 v62, v30, v4// 0000002315A0: CB184520 413E091E
	v_or_b32_e32 v4, 0x64006400, v19                           // 0000002315A8: 380826FF 64006400
	v_dual_dot2acc_f32_f16 v61, v33, v72 :: v_dual_and_b32 v72, 0xf0f0f0f, v94// 0000002315B0: CB249121 3D48BCFF 0F0F0F0F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002315BC: BF870193
	v_dual_dot2acc_f32_f16 v65, v28, v35 :: v_dual_and_b32 v40, 0xf0f0f0f, v92// 0000002315C0: CB24471C 4128B8FF 0F0F0F0F
	.long 0xcc0f4004                                           // 0000002315CC: CC0F4004
	v_mul_i32_i24_e32 v1, 0xe408, v4                           // 0000002315D0: 120208FF 0000E408
	.long 0xcc0f401d                                           // 0000002315D8: CC0F401D
	v_mul_i32_i24_e32 v1, 0xe408, v29                          // 0000002315DC: 12023AFF 0000E408
	v_or_b32_e32 v19, 0x64006400, v54                          // 0000002315E4: 38266CFF 64006400
	s_delay_alu instid0(VALU_DEP_4)                            // 0000002315EC: BF870004
	v_perm_b32 v31, v40, v91, 0xc040c00                        // 0000002315F0: D644001F 03FEB728 0C040C00
	v_perm_b32 v32, v40, v91, 0xc050c01                        // 0000002315FC: D6440020 03FEB728 0C050C01
	v_dot2acc_f32_f16 v61, v4, v73                             // 000000231608: 047A9304
	v_or_b32_e32 v4, 0x64006400, v88                           // 00000023160C: 3808B0FF 64006400
	v_dot2acc_f32_f16 v62, v29, v5                             // 000000231614: 047C0B1D
	v_or_b32_e32 v28, 0x64006400, v31                          // 000000231618: 38383EFF 64006400
	v_or_b32_e32 v30, 0x64006400, v32                          // 000000231620: 383C40FF 64006400
	v_perm_b32 v71, v40, v91, 0xc060c02                        // 000000231628: D6440047 03FEB728 0C060C02
	.long 0xcc0f4004                                           // 000000231634: CC0F4004
	v_mul_i32_i24_e32 v1, 0xe408, v4                           // 000000231638: 120208FF 0000E408
	.long 0xcc0f4013                                           // 000000231640: CC0F4013
	v_mul_i32_i24_e32 v1, 0xe408, v19                          // 000000231644: 120226FF 0000E408
	.long 0xcc0f401c                                           // 00000023164C: CC0F401C
	v_mul_i32_i24_e32 v1, 0xe408, v28                          // 000000231650: 120238FF 0000E408
	.long 0xcc0f4036                                           // 000000231658: CC0F4036
	v_mul_i32_i24_e32 v1, 0xe408, v30                          // 00000023165C: 12023CFF 0000E408
	v_or_b32_e32 v5, 0x64006400, v71                           // 000000231664: 380A8EFF 64006400
	v_dot2acc_f32_f16 v62, v4, v6                              // 00000023166C: 047C0D04
	v_perm_b32 v4, v72, v93, 0xc050c01                         // 000000231670: D6440004 03FEBB48 0C050C01
	v_dot2acc_f32_f16 v64, v28, v15                            // 00000023167C: 04801F1C
	v_perm_b32 v15, v72, v93, 0xc040c00                        // 000000231680: D644000F 03FEBB48 0C040C00
	v_dot2acc_f32_f16 v61, v19, v74                            // 00000023168C: 047A9513
	.long 0xcc0f4005                                           // 000000231690: CC0F4005
	v_mul_i32_i24_e32 v1, 0xe408, v5                           // 000000231694: 12020AFF 0000E408
	v_or_b32_e32 v71, 0x64006400, v4                           // 00000023169C: 388E08FF 64006400
	v_dot2acc_f32_f16 v64, v54, v16                            // 0000002316A4: 04802136
	v_or_b32_e32 v16, 0x64006400, v89                          // 0000002316A8: 3820B2FF 64006400
	v_or_b32_e32 v6, 0x64006400, v15                           // 0000002316B0: 380C1EFF 64006400
	v_perm_b32 v54, v72, v93, 0xc060c02                        // 0000002316B8: D6440036 03FEBB48 0C060C02
	.long 0xcc0f4047                                           // 0000002316C4: CC0F4047
	v_mul_i32_i24_e32 v1, 0xe408, v71                          // 0000002316C8: 12028EFF 0000E408
	s_clause 0x1                                               // 0000002316D0: BF850001
	global_load_b128 v[32:35], v[57:58], off offset:768        // 0000002316D4: DC5E0300 207C0039
	global_load_b128 v[28:31], v[57:58], off offset:832        // 0000002316DC: DC5E0340 1C7C0039
	.long 0xcc0f400f                                           // 0000002316E4: CC0F400F
	v_mul_i32_i24_e32 v1, 0xe408, v16                          // 0000002316E8: 120220FF 0000E408
	.long 0xcc0f4049                                           // 0000002316F0: CC0F4049
	v_mul_i32_i24_e32 v1, 0xe408, v6                           // 0000002316F4: 12020CFF 0000E408
	v_or_b32_e32 v54, 0x64006400, v54                          // 0000002316FC: 386C6CFF 64006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000231704: BF870223
	v_dot2acc_f32_f16 v62, v15, v7                             // 000000231708: 047C0F0F
	v_perm_b32 v15, v72, v93, 0xc070c03                        // 00000023170C: D644000F 03FEBB48 0C070C03
	v_dual_dot2acc_f32_f16 v66, v73, v67 :: v_dual_and_b32 v67, 0xf0f0f0f, v8// 000000231718: CB248749 424210FF 0F0F0F0F
	v_lshrrev_b32_e32 v8, 4, v8                                // 000000231724: 32101084
	.long 0xcc0f4036                                           // 000000231728: CC0F4036
	v_mul_i32_i24_e32 v1, 0xe408, v54                          // 00000023172C: 12026CFF 0000E408
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000231734: BF870214
	v_or_b32_e32 v15, 0x64006400, v15                          // 000000231738: 381E1EFF 64006400
	v_dot2acc_f32_f16 v66, v71, v68                            // 000000231740: 04848947
	v_and_b32_e32 v68, 0xf0f0f0f, v96                          // 000000231744: 3688C0FF 0F0F0F0F
	v_and_b32_e32 v8, 0xf0f0f0f, v8                            // 00000023174C: 361010FF 0F0F0F0F
	v_and_b32_e32 v71, 0xf0f0f0f, v9                           // 000000231754: 368E12FF 0F0F0F0F
	.long 0xcc0f400f                                           // 00000023175C: CC0F400F
	v_mul_i32_i24_e32 v1, 0xe408, v15                          // 000000231760: 12021EFF 0000E408
	v_dot2acc_f32_f16 v66, v54, v69                            // 000000231768: 04848B36
	v_perm_b32 v54, v68, v95, 0xc040c00                        // 00000023176C: D6440036 03FEBF44 0C040C00
	v_perm_b32 v69, v68, v95, 0xc050c01                        // 000000231778: D6440045 03FEBF44 0C050C01
	v_perm_b32 v72, v8, v67, 0xc050c01                         // 000000231784: D6440048 03FE8708 0C050C01
	v_lshrrev_b32_e32 v9, 4, v9                                // 000000231790: 32121284
	v_dot2acc_f32_f16 v66, v15, v70                            // 000000231794: 04848D0F
	v_perm_b32 v70, v8, v67, 0xc040c00                         // 000000231798: D6440046 03FE8708 0C040C00
	v_or_b32_e32 v54, 0x64006400, v54                          // 0000002317A4: 386C6CFF 64006400
	v_perm_b32 v15, v68, v95, 0xc060c02                        // 0000002317AC: D644000F 03FEBF44 0C060C02
	v_or_b32_e32 v69, 0x64006400, v69                          // 0000002317B8: 388A8AFF 64006400
	v_perm_b32 v73, v8, v67, 0xc060c02                         // 0000002317C0: D6440049 03FE8708 0C060C02
	v_or_b32_e32 v70, 0x64006400, v70                          // 0000002317CC: 388C8CFF 64006400
	.long 0xcc0f4036                                           // 0000002317D4: CC0F4036
	v_mul_i32_i24_e32 v1, 0xe408, v54                          // 0000002317D8: 12026CFF 0000E408
	v_or_b32_e32 v15, 0x64006400, v15                          // 0000002317E0: 381E1EFF 64006400
	v_or_b32_e32 v72, 0x64006400, v72                          // 0000002317E8: 389090FF 64006400
	v_and_b32_e32 v9, 0xf0f0f0f, v9                            // 0000002317F0: 361212FF 0F0F0F0F
	.long 0xcc0f4046                                           // 0000002317F8: CC0F4046
	v_mul_i32_i24_e32 v1, 0xe408, v70                          // 0000002317FC: 12028CFF 0000E408
	s_waitcnt lgkmcnt(0)                                       // 000000231804: BF89FC07
	v_dot2acc_f32_f16 v65, v54, v75                            // 000000231808: 04829736
	v_perm_b32 v90, v40, v91, 0xc070c03                        // 00000023180C: D644005A 03FEB728 0C070C03
	v_perm_b32 v8, v8, v67, 0xc070c03                          // 000000231818: D6440008 03FE8708 0C070C03
	v_or_b32_e32 v73, 0x64006400, v73                          // 000000231824: 389292FF 64006400
	.long 0xcc0f4048                                           // 00000023182C: CC0F4048
	v_mul_i32_i24_e32 v1, 0xe408, v72                          // 000000231830: 120290FF 0000E408
	v_dot2acc_f32_f16 v63, v70, v79                            // 000000231838: 047E9F46
	v_or_b32_e32 v19, 0x64006400, v90                          // 00000023183C: 3826B4FF 64006400
	.long 0xcc0f400f                                           // 000000231844: CC0F400F
	v_mul_i32_i24_e32 v1, 0xe408, v15                          // 000000231848: 12021EFF 0000E408
	s_clause 0x1                                               // 000000231850: BF850001
	global_load_b128 v[40:43], v[57:58], off offset:640        // 000000231854: DC5E0280 287C0039
	global_load_b128 v[36:39], v[57:58], off offset:704        // 00000023185C: DC5E02C0 247C0039
	v_perm_b32 v67, v9, v71, 0xc040c00                         // 000000231864: D6440043 03FE8F09 0C040C00
	v_or_b32_e32 v8, 0x64006400, v8                            // 000000231870: 381010FF 64006400
	.long 0xcc0f4010                                           // 000000231878: CC0F4010
	v_mul_i32_i24_e32 v1, 0xe408, v19                          // 00000023187C: 120226FF 0000E408
	v_dot2acc_f32_f16 v63, v72, v80                            // 000000231884: 047EA148
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000231888: BF870214
	v_or_b32_e32 v54, 0x64006400, v67                          // 00000023188C: 386C86FF 64006400
	.long 0xcc0f4008                                           // 000000231894: CC0F4008
	v_mul_i32_i24_e32 v1, 0xe408, v8                           // 000000231898: 120210FF 0000E408
	s_waitcnt vmcnt(8)                                         // 0000002318A0: BF8923F7
	v_fma_mix_f32 v61, v11, v61, 0 op_sel_hi:[1,0,0]           // 0000002318A4: CC20003D 0A027B0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000002318AC: BF870131
	v_fma_mix_f32 v11, v11, v62, v61 op_sel:[1,0,0] op_sel_hi:[1,0,0]// 0000002318B0: CC20080B 0CF67D0B
	.long 0xcc0f403d                                           // 0000002318B8: CC0F403D
	v_mul_i32_i24_e32 v1, 0xe408, v69                          // 0000002318BC: 12028AFF 0000E408
	.long 0xcc0f403e                                           // 0000002318C4: CC0F403E
	v_mul_i32_i24_e32 v1, 0xe408, v73                          // 0000002318C8: 120292FF 0000E408
	v_dot2acc_f32_f16 v65, v61, v76                            // 0000002318D0: 0482993D
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000002318D4: BF8701A2
	v_dot2acc_f32_f16 v63, v62, v81                            // 0000002318D8: 047EA33E
	v_perm_b32 v61, v9, v71, 0xc060c02                         // 0000002318DC: D644003D 03FE8F09 0C060C02
	v_dual_mov_b32 v76, 0 :: v_dual_dot2acc_f32_f16 v65, v15, v77// 0000002318E8: CA180080 4C409B0F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000002318F0: BF870243
	v_dual_dot2acc_f32_f16 v64, v5, v17 :: v_dual_dot2acc_f32_f16 v63, v8, v82// 0000002318F4: CB182305 403EA508
	.long 0xcc0f4008                                           // 0000002318FC: CC0F4008
	v_mul_i32_i24_e32 v1, 0xe408, v54                          // 000000231900: 12026CFF 0000E408
	v_perm_b32 v54, v68, v95, 0xc070c03                        // 000000231908: D6440036 03FEBF44 0C070C03
	v_or_b32_e32 v61, 0x64006400, v61                          // 000000231914: 387A7AFF 64006400
	v_dot2acc_f32_f16 v64, v16, v18                            // 00000023191C: 04802510
	s_clause 0x1                                               // 000000231920: BF850001
	global_load_b128 v[16:19], v[57:58], off offset:896        // 000000231924: DC5E0380 107C0039
	global_load_b128 v[4:7], v[57:58], off offset:960          // 00000023192C: DC5E03C0 047C0039
	v_fma_mix_f32 v11, v12, v64, v11 op_sel_hi:[1,0,0]         // 000000231934: CC20000B 0C2E810C
	s_delay_alu instid0(VALU_DEP_1)                            // 00000023193C: BF870001
	v_fma_mix_f32 v12, v12, v66, v11 op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000231940: CC20080C 0C2E850C
	v_perm_b32 v11, v9, v71, 0xc050c01                         // 000000231948: D644000B 03FE8F09 0C050C01
	ds_load_b128 v[66:69], v60 offset:1328                     // 000000231954: DBFC0530 4200003C
	v_dot2acc_f32_f16 v63, v8, v83                             // 00000023195C: 047EA708
	s_waitcnt vmcnt(9)                                         // 000000231960: BF8927F7
	v_lshrrev_b32_e32 v8, 4, v24                               // 000000231964: 32103084
	v_perm_b32 v9, v9, v71, 0xc070c03                          // 000000231968: D6440009 03FE8F09 0C070C03
	v_or_b32_e32 v11, 0x64006400, v11                          // 000000231974: 381616FF 64006400
	v_and_b32_e32 v24, 0xf0f0f0f, v24                          // 00000023197C: 363030FF 0F0F0F0F
	ds_load_b128 v[70:73], v60 offset:1536                     // 000000231984: DBFC0600 4600003C
	v_and_b32_e32 v62, 0xf0f0f0f, v8                           // 00000023198C: 367C10FF 0F0F0F0F
	v_or_b32_e32 v8, 0x64006400, v54                           // 000000231994: 38106CFF 64006400
	.long 0xcc0f400b                                           // 00000023199C: CC0F400B
	v_mul_i32_i24_e32 v1, 0xe408, v11                          // 0000002319A0: 120216FF 0000E408
	v_or_b32_e32 v9, 0x64006400, v9                            // 0000002319A8: 381212FF 64006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002319B0: BF870214
	v_perm_b32 v54, v62, v24, 0xc040c00                        // 0000002319B4: D6440036 03FE313E 0C040C00
	.long 0xcc0f400f                                           // 0000002319C0: CC0F400F
	v_mul_i32_i24_e32 v1, 0xe408, v8                           // 0000002319C4: 120210FF 0000E408
	s_delay_alu instid0(VALU_DEP_4)                            // 0000002319CC: BF870004
	v_dot2acc_f32_f16 v63, v11, v84                            // 0000002319D0: 047EA90B
	.long 0xcc0f400b                                           // 0000002319D4: CC0F400B
	v_mul_i32_i24_e32 v1, 0xe408, v61                          // 0000002319D8: 12027AFF 0000E408
	v_and_b32_e32 v61, 0xf0f0f0f, v10                          // 0000002319E0: 367A14FF 0F0F0F0F
	v_or_b32_e32 v8, 0x64006400, v54                           // 0000002319E8: 38106CFF 64006400
	.long 0xcc0f4036                                           // 0000002319F0: CC0F4036
	v_mul_i32_i24_e32 v1, 0xe408, v9                           // 0000002319F4: 120212FF 0000E408
	v_lshrrev_b32_e32 v9, 4, v10                               // 0000002319FC: 32121484
	v_dot2acc_f32_f16 v63, v11, v85                            // 000000231A00: 047EAB0B
	v_perm_b32 v11, v62, v24, 0xc050c01                        // 000000231A04: D644000B 03FE313E 0C050C01
	.long 0xcc0f4040                                           // 000000231A10: CC0F4040
	v_mul_i32_i24_e32 v1, 0xe408, v8                           // 000000231A14: 120210FF 0000E408
	v_perm_b32 v77, v62, v24, 0xc060c02                        // 000000231A1C: D644004D 03FE313E 0C060C02
	v_and_b32_e32 v74, 0xf0f0f0f, v9                           // 000000231A28: 369412FF 0F0F0F0F
	v_perm_b32 v24, v62, v24, 0xc070c03                        // 000000231A30: D6440018 03FE313E 0C070C03
	v_or_b32_e32 v75, 0x64006400, v11                          // 000000231A3C: 389616FF 64006400
	ds_load_b128 v[8:11], v60 offset:1552                      // 000000231A44: DBFC0610 0800003C
	s_waitcnt lgkmcnt(1)                                       // 000000231A4C: BF89FC17
	v_dot2acc_f32_f16 v76, v64, v70                            // 000000231A50: 04988D40
	v_lshrrev_b32_e32 v64, 4, v25                              // 000000231A54: 32803284
	v_and_b32_e32 v25, 0xf0f0f0f, v25                          // 000000231A58: 363232FF 0F0F0F0F
	.long 0xcc0f4046                                           // 000000231A60: CC0F4046
	v_mul_i32_i24_e32 v1, 0xe408, v75                          // 000000231A64: 120296FF 0000E408
	v_or_b32_e32 v75, 0x64006400, v77                          // 000000231A6C: 38969AFF 64006400
	v_or_b32_e32 v24, 0x64006400, v24                          // 000000231A74: 383030FF 64006400
	v_and_b32_e32 v62, 0xf0f0f0f, v64                          // 000000231A7C: 367C80FF 0F0F0F0F
	v_perm_b32 v64, v74, v61, 0xc040c00                        // 000000231A84: D6440040 03FE7B4A 0C040C00
	v_dot2acc_f32_f16 v76, v70, v71                            // 000000231A90: 04988F46
	.long 0xcc0f4046                                           // 000000231A94: CC0F4046
	v_mul_i32_i24_e32 v1, 0xe408, v75                          // 000000231A98: 120296FF 0000E408
	v_dot2acc_f32_f16 v63, v54, v86                            // 000000231AA0: 047EAD36
	v_perm_b32 v71, v62, v25, 0xc040c00                        // 000000231AA4: D6440047 03FE333E 0C040C00
	.long 0xcc0f4018                                           // 000000231AB0: CC0F4018
	v_mul_i32_i24_e32 v1, 0xe408, v24                          // 000000231AB4: 120230FF 0000E408
	v_or_b32_e32 v64, 0x64006400, v64                          // 000000231ABC: 388080FF 64006400
	v_dot2acc_f32_f16 v76, v70, v72                            // 000000231AC4: 04989146
	v_perm_b32 v70, v62, v25, 0xc050c01                        // 000000231AC8: D6440046 03FE333E 0C050C01
	v_or_b32_e32 v54, 0x64006400, v71                          // 000000231AD4: 386C8EFF 64006400
	v_dot2acc_f32_f16 v65, v15, v78                            // 000000231ADC: 04829D0F
	.long 0xcc0f4040                                           // 000000231AE0: CC0F4040
	v_mul_i32_i24_e32 v1, 0xe408, v64                          // 000000231AE4: 120280FF 0000E408
	v_dot2acc_f32_f16 v76, v24, v73                            // 000000231AEC: 04989318
	v_or_b32_e32 v24, 0x64006400, v70                          // 000000231AF0: 38308CFF 64006400
	.long 0xcc0f400f                                           // 000000231AF8: CC0F400F
	v_mul_i32_i24_e32 v1, 0xe408, v54                          // 000000231AFC: 12026CFF 0000E408
	v_perm_b32 v54, v62, v25, 0xc060c02                        // 000000231B04: D6440036 03FE333E 0C060C02
	v_dot2acc_f32_f16 v63, v64, v66                            // 000000231B10: 047E8540
	v_perm_b32 v64, v74, v61, 0xc050c01                        // 000000231B14: D6440040 03FE7B4A 0C050C01
	v_perm_b32 v25, v62, v25, 0xc070c03                        // 000000231B20: D6440019 03FE333E 0C070C03
	s_waitcnt lgkmcnt(0)                                       // 000000231B2C: BF89FC07
	v_dot2acc_f32_f16 v76, v15, v8                             // 000000231B30: 0498110F
	v_lshrrev_b32_e32 v8, 4, v26                               // 000000231B34: 32103484
	.long 0xcc0f400f                                           // 000000231B38: CC0F400F
	v_mul_i32_i24_e32 v1, 0xe408, v24                          // 000000231B3C: 120230FF 0000E408
	v_or_b32_e32 v24, 0x64006400, v54                          // 000000231B44: 38306CFF 64006400
	v_and_b32_e32 v26, 0xf0f0f0f, v26                          // 000000231B4C: 363434FF 0F0F0F0F
	ds_load_b128 v[70:73], v60 offset:1568                     // 000000231B54: DBFC0620 4600003C
	v_and_b32_e32 v54, 0xf0f0f0f, v8                           // 000000231B5C: 366C10FF 0F0F0F0F
	v_or_b32_e32 v8, 0x64006400, v64                           // 000000231B64: 381080FF 64006400
	v_dot2acc_f32_f16 v76, v15, v9                             // 000000231B6C: 0498130F
	.long 0xcc0f4009                                           // 000000231B70: CC0F4009
	v_mul_i32_i24_e32 v1, 0xe408, v24                          // 000000231B74: 120230FF 0000E408
	v_or_b32_e32 v15, 0x64006400, v25                          // 000000231B7C: 381E32FF 64006400
	v_perm_b32 v24, v54, v26, 0xc040c00                        // 000000231B84: D6440018 03FE3536 0C040C00
	v_perm_b32 v25, v74, v61, 0xc060c02                        // 000000231B90: D6440019 03FE7B4A 0C060C02
	.long 0xcc0f4008                                           // 000000231B9C: CC0F4008
	v_mul_i32_i24_e32 v1, 0xe408, v8                           // 000000231BA0: 120210FF 0000E408
	v_dot2acc_f32_f16 v76, v9, v10                             // 000000231BA8: 04981509
	.long 0xcc0f4009                                           // 000000231BAC: CC0F4009
	v_mul_i32_i24_e32 v1, 0xe408, v15                          // 000000231BB0: 12021EFF 0000E408
	v_or_b32_e32 v10, 0x64006400, v24                          // 000000231BB8: 381430FF 64006400
	v_perm_b32 v15, v54, v26, 0xc050c01                        // 000000231BC0: D644000F 03FE3536 0C050C01
	v_or_b32_e32 v24, 0x64006400, v25                          // 000000231BCC: 383032FF 64006400
	v_dot2acc_f32_f16 v63, v8, v67                             // 000000231BD4: 047E8708
	v_dot2acc_f32_f16 v76, v9, v11                             // 000000231BD8: 04981709
	.long 0xcc0f4019                                           // 000000231BDC: CC0F4019
	v_mul_i32_i24_e32 v1, 0xe408, v10                          // 000000231BE0: 120214FF 0000E408
	v_or_b32_e32 v15, 0x64006400, v15                          // 000000231BE8: 381E1EFF 64006400
	.long 0xcc0f4018                                           // 000000231BF0: CC0F4018
	v_mul_i32_i24_e32 v1, 0xe408, v24                          // 000000231BF4: 120230FF 0000E408
	ds_load_b128 v[8:11], v60 offset:1584                      // 000000231BFC: DBFC0630 0800003C
	v_perm_b32 v61, v74, v61, 0xc070c03                        // 000000231C04: D644003D 03FE7B4A 0C070C03
	s_waitcnt lgkmcnt(1)                                       // 000000231C10: BF89FC17
	v_dot2acc_f32_f16 v76, v25, v70                            // 000000231C14: 04988D19
	.long 0xcc0f400f                                           // 000000231C18: CC0F400F
	v_mul_i32_i24_e32 v1, 0xe408, v15                          // 000000231C1C: 12021EFF 0000E408
	v_perm_b32 v25, v54, v26, 0xc060c02                        // 000000231C24: D6440019 03FE3536 0C060C02
	v_dot2acc_f32_f16 v63, v24, v68                            // 000000231C30: 047E8918
	s_waitcnt vmcnt(8)                                         // 000000231C34: BF8923F7
	v_lshrrev_b32_e32 v24, 4, v48                              // 000000231C38: 32306084
	v_perm_b32 v54, v54, v26, 0xc070c03                        // 000000231C3C: D6440036 03FE3536 0C070C03
	v_dot2acc_f32_f16 v76, v15, v71                            // 000000231C48: 04988F0F
	v_or_b32_e32 v15, 0x64006400, v25                          // 000000231C4C: 381E32FF 64006400
	v_lshrrev_b32_e32 v62, 4, v27                              // 000000231C54: 327C3684
	v_and_b32_e32 v74, 0xf0f0f0f, v27                          // 000000231C58: 369436FF 0F0F0F0F
	v_and_b32_e32 v48, 0xf0f0f0f, v48                          // 000000231C60: 366060FF 0F0F0F0F
	v_and_b32_e32 v68, 0xf0f0f0f, v24                          // 000000231C68: 368830FF 0F0F0F0F
	ds_load_b128 v[24:27], v60 offset:1792                     // 000000231C70: DBFC0700 1800003C
	.long 0xcc0f400f                                           // 000000231C78: CC0F400F
	v_mul_i32_i24_e32 v1, 0xe408, v15                          // 000000231C7C: 12021EFF 0000E408
	v_or_b32_e32 v54, 0x64006400, v54                          // 000000231C84: 386C6CFF 64006400
	v_or_b32_e32 v61, 0x64006400, v61                          // 000000231C8C: 387A7AFF 64006400
	v_perm_b32 v64, v68, v48, 0xc040c00                        // 000000231C94: D6440040 03FE6144 0C040C00
	v_and_b32_e32 v62, 0xf0f0f0f, v62                          // 000000231CA0: 367C7CFF 0F0F0F0F
	v_dot2acc_f32_f16 v76, v15, v72                            // 000000231CA8: 0498910F
	.long 0xcc0f400f                                           // 000000231CAC: CC0F400F
	v_mul_i32_i24_e32 v1, 0xe408, v54                          // 000000231CB0: 12026CFF 0000E408
	v_fma_mix_f32 v12, v13, v65, v12 op_sel_hi:[1,0,0]         // 000000231CB8: CC20000C 0C32830D
	v_or_b32_e32 v54, 0x64006400, v64                          // 000000231CC0: 386C80FF 64006400
	.long 0xcc0f403d                                           // 000000231CC8: CC0F403D
	v_mul_i32_i24_e32 v1, 0xe408, v61                          // 000000231CCC: 12027AFF 0000E408
	v_perm_b32 v65, v62, v74, 0xc040c00                        // 000000231CD4: D6440041 03FE953E 0C040C00
	v_perm_b32 v64, v68, v48, 0xc050c01                        // 000000231CE0: D6440040 03FE6144 0C050C01
	v_dot2acc_f32_f16 v76, v15, v73                            // 000000231CEC: 0498930F
	.long 0xcc0f400f                                           // 000000231CF0: CC0F400F
	v_mul_i32_i24_e32 v1, 0xe408, v54                          // 000000231CF4: 12026CFF 0000E408
	v_dual_mov_b32 v54, 0 :: v_dual_dot2acc_f32_f16 v63, v61, v69// 000000231CFC: CA180080 363E8B3D
	v_or_b32_e32 v61, 0x64006400, v65                          // 000000231D04: 387A82FF 64006400
	v_or_b32_e32 v69, 0x64006400, v64                          // 000000231D0C: 388A80FF 64006400
	v_perm_b32 v70, v68, v48, 0xc060c02                        // 000000231D14: D6440046 03FE6144 0C060C02
	ds_load_b128 v[64:67], v60 offset:1808                     // 000000231D20: DBFC0710 4000003C
	s_waitcnt lgkmcnt(1)                                       // 000000231D28: BF89FC17
	v_dot2acc_f32_f16 v54, v15, v24                            // 000000231D2C: 046C310F
	v_lshrrev_b32_e32 v15, 4, v49                              // 000000231D30: 321E6284
	.long 0xcc0f4018                                           // 000000231D34: CC0F4018
	v_mul_i32_i24_e32 v1, 0xe408, v69                          // 000000231D38: 12028AFF 0000E408
	v_or_b32_e32 v69, 0x64006400, v70                          // 000000231D40: 388A8CFF 64006400
	v_perm_b32 v48, v68, v48, 0xc070c03                        // 000000231D48: D6440030 03FE6144 0C070C03
	v_and_b32_e32 v49, 0xf0f0f0f, v49                          // 000000231D54: 366262FF 0F0F0F0F
	v_and_b32_e32 v15, 0xf0f0f0f, v15                          // 000000231D5C: 361E1EFF 0F0F0F0F
	.long 0xcc0f403d                                           // 000000231D64: CC0F403D
	v_mul_i32_i24_e32 v1, 0xe408, v61                          // 000000231D68: 12027AFF 0000E408
	v_perm_b32 v68, v62, v74, 0xc050c01                        // 000000231D70: D6440044 03FE953E 0C050C01
	v_dot2acc_f32_f16 v54, v24, v25                            // 000000231D7C: 046C3318
	.long 0xcc0f4018                                           // 000000231D80: CC0F4018
	v_mul_i32_i24_e32 v1, 0xe408, v69                          // 000000231D84: 12028AFF 0000E408
	v_or_b32_e32 v25, 0x64006400, v48                          // 000000231D8C: 383260FF 64006400
	v_perm_b32 v48, v15, v49, 0xc040c00                        // 000000231D94: D6440030 03FE630F 0C040C00
	v_or_b32_e32 v68, 0x64006400, v68                          // 000000231DA0: 388888FF 64006400
	v_dot2acc_f32_f16 v76, v61, v8                             // 000000231DA8: 0498113D
	v_dot2acc_f32_f16 v54, v24, v26                            // 000000231DAC: 046C3518
	.long 0xcc0f4008                                           // 000000231DB0: CC0F4008
	v_mul_i32_i24_e32 v1, 0xe408, v25                          // 000000231DB4: 120232FF 0000E408
	v_or_b32_e32 v24, 0x64006400, v48                          // 000000231DBC: 383060FF 64006400
	.long 0xcc0f4019                                           // 000000231DC4: CC0F4019
	v_mul_i32_i24_e32 v1, 0xe408, v68                          // 000000231DC8: 120288FF 0000E408
	v_perm_b32 v26, v15, v49, 0xc050c01                        // 000000231DD0: D644001A 03FE630F 0C050C01
	v_perm_b32 v48, v62, v74, 0xc060c02                        // 000000231DDC: D6440030 03FE953E 0C060C02
	v_dot2acc_f32_f16 v54, v8, v27                             // 000000231DE8: 046C3708
	.long 0xcc0f4008                                           // 000000231DEC: CC0F4008
	v_mul_i32_i24_e32 v1, 0xe408, v24                          // 000000231DF0: 120230FF 0000E408
	v_dot2acc_f32_f16 v76, v25, v9                             // 000000231DF8: 04981319
	v_or_b32_e32 v9, 0x64006400, v26                           // 000000231DFC: 381234FF 64006400
	v_perm_b32 v24, v15, v49, 0xc060c02                        // 000000231E04: D6440018 03FE630F 0C060C02
	v_or_b32_e32 v25, 0x64006400, v48                          // 000000231E10: 383260FF 64006400
	s_waitcnt lgkmcnt(0)                                       // 000000231E18: BF89FC07
	v_dot2acc_f32_f16 v54, v8, v64                             // 000000231E1C: 046C8108
	v_lshrrev_b32_e32 v8, 4, v50                               // 000000231E20: 32106484
	.long 0xcc0f4009                                           // 000000231E24: CC0F4009
	v_mul_i32_i24_e32 v1, 0xe408, v9                           // 000000231E28: 120212FF 0000E408
	v_or_b32_e32 v24, 0x64006400, v24                          // 000000231E30: 383030FF 64006400
	v_perm_b32 v15, v15, v49, 0xc070c03                        // 000000231E38: D644000F 03FE630F 0C070C03
	v_and_b32_e32 v48, 0xf0f0f0f, v50                          // 000000231E44: 366064FF 0F0F0F0F
	v_and_b32_e32 v49, 0xf0f0f0f, v8                           // 000000231E4C: 366210FF 0F0F0F0F
	ds_load_b128 v[68:71], v60 offset:1824                     // 000000231E54: DBFC0720 4400003C
	v_dot2acc_f32_f16 v54, v9, v65                             // 000000231E5C: 046C8309
	.long 0xcc0f4009                                           // 000000231E60: CC0F4009
	v_mul_i32_i24_e32 v1, 0xe408, v24                          // 000000231E64: 120230FF 0000E408
	v_or_b32_e32 v15, 0x64006400, v15                          // 000000231E6C: 381E1EFF 64006400
	v_perm_b32 v24, v49, v48, 0xc040c00                        // 000000231E74: D6440018 03FE6131 0C040C00
	.long 0xcc0f4019                                           // 000000231E80: CC0F4019
	v_mul_i32_i24_e32 v1, 0xe408, v25                          // 000000231E84: 120232FF 0000E408
	v_perm_b32 v8, v62, v74, 0xc070c03                         // 000000231E8C: D6440008 03FE953E 0C070C03
	v_dot2acc_f32_f16 v54, v9, v66                             // 000000231E98: 046C8509
	.long 0xcc0f4009                                           // 000000231E9C: CC0F4009
	v_mul_i32_i24_e32 v1, 0xe408, v15                          // 000000231EA0: 12021EFF 0000E408
	v_or_b32_e32 v15, 0x64006400, v24                          // 000000231EA8: 381E30FF 64006400
	v_perm_b32 v24, v49, v48, 0xc050c01                        // 000000231EB0: D6440018 03FE6131 0C050C01
	v_dot2acc_f32_f16 v76, v25, v10                            // 000000231EBC: 04981519
	v_or_b32_e32 v8, 0x64006400, v8                            // 000000231EC0: 381010FF 64006400
	v_dot2acc_f32_f16 v54, v9, v67                             // 000000231EC8: 046C8709
	.long 0xcc0f4009                                           // 000000231ECC: CC0F4009
	v_mul_i32_i24_e32 v1, 0xe408, v15                          // 000000231ED0: 12021EFF 0000E408
	v_or_b32_e32 v10, 0x64006400, v24                          // 000000231ED8: 381430FF 64006400
	v_perm_b32 v15, v49, v48, 0xc060c02                        // 000000231EE0: D644000F 03FE6131 0C060C02
	ds_load_b128 v[64:67], v60 offset:1840                     // 000000231EEC: DBFC0730 4000003C
	ds_load_b128 v[72:75], v60 offset:2048                     // 000000231EF4: DBFC0800 4800003C
	.long 0xcc0f4008                                           // 000000231EFC: CC0F4008
	v_mul_i32_i24_e32 v1, 0xe408, v8                           // 000000231F00: 120210FF 0000E408
	s_waitcnt lgkmcnt(2)                                       // 000000231F08: BF89FC27
	v_dot2acc_f32_f16 v54, v9, v68                             // 000000231F0C: 046C8909
	.long 0xcc0f4009                                           // 000000231F10: CC0F4009
	v_mul_i32_i24_e32 v1, 0xe408, v10                          // 000000231F14: 120214FF 0000E408
	v_or_b32_e32 v10, 0x64006400, v15                          // 000000231F1C: 38141EFF 64006400
	v_fma_mix_f32 v12, v13, v63, v12 op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000231F24: CC20080C 0C327F0D
	v_dot2acc_f32_f16 v76, v8, v11                             // 000000231F2C: 04981708
	v_perm_b32 v61, v49, v48, 0xc070c03                        // 000000231F30: D644003D 03FE6131 0C070C03
	v_dot2acc_f32_f16 v54, v9, v69                             // 000000231F3C: 046C8B09
	.long 0xcc0f4032                                           // 000000231F40: CC0F4032
	v_mul_i32_i24_e32 v1, 0xe408, v10                          // 000000231F44: 120214FF 0000E408
	s_waitcnt vmcnt(7)                                         // 000000231F4C: BF891FF7
	v_lshrrev_b32_e32 v24, 4, v20                              // 000000231F50: 32302884
	v_and_b32_e32 v15, 0xf0f0f0f, v20                          // 000000231F54: 361E28FF 0F0F0F0F
	v_fma_mix_f32 v12, v14, v76, v12 op_sel_hi:[1,0,0]         // 000000231F5C: CC20000C 0C32990E
	v_mov_b32_e32 v76, 0                                       // 000000231F64: 7E980280
	v_dot2acc_f32_f16 v54, v50, v70                            // 000000231F68: 046C8D32
	v_and_b32_e32 v20, 0xf0f0f0f, v24                          // 000000231F6C: 362830FF 0F0F0F0F
	v_and_b32_e32 v62, 0xf0f0f0f, v51                          // 000000231F74: 367C66FF 0F0F0F0F
	v_lshrrev_b32_e32 v63, 4, v51                              // 000000231F7C: 327E6684
	v_or_b32_e32 v61, 0x64006400, v61                          // 000000231F80: 387A7AFF 64006400
	s_clause 0x1                                               // 000000231F88: BF850001
	global_load_b128 v[24:27], v[57:58], off offset:1024       // 000000231F8C: DC5E0400 187C0039
	global_load_b128 v[8:11], v[57:58], off offset:1088        // 000000231F94: DC5E0440 087C0039
	v_perm_b32 v13, v20, v15, 0xc040c00                        // 000000231F9C: D644000D 03FE1F14 0C040C00
	v_perm_b32 v48, v20, v15, 0xc050c01                        // 000000231FA8: D6440030 03FE1F14 0C050C01
	v_perm_b32 v69, v20, v15, 0xc060c02                        // 000000231FB4: D6440045 03FE1F14 0C060C02
	v_perm_b32 v15, v20, v15, 0xc070c03                        // 000000231FC0: D644000F 03FE1F14 0C070C03
	v_and_b32_e32 v20, 0xf0f0f0f, v21                          // 000000231FCC: 36282AFF 0F0F0F0F
	v_or_b32_e32 v13, 0x64006400, v13                          // 000000231FD4: 381A1AFF 64006400
	v_or_b32_e32 v68, 0x64006400, v48                          // 000000231FDC: 388860FF 64006400
	ds_load_b128 v[48:51], v60 offset:2064                     // 000000231FE4: DBFC0810 3000003C
	v_or_b32_e32 v69, 0x64006400, v69                          // 000000231FEC: 388A8AFF 64006400
	v_or_b32_e32 v15, 0x64006400, v15                          // 000000231FF4: 381E1EFF 64006400
	.long 0xcc0f400d                                           // 000000231FFC: CC0F400D
	v_mul_i32_i24_e32 v1, 0xe408, v13                          // 000000232000: 12021AFF 0000E408
	.long 0xcc0f4044                                           // 000000232008: CC0F4044
	v_mul_i32_i24_e32 v1, 0xe408, v68                          // 00000023200C: 120288FF 0000E408
	.long 0xcc0f403d                                           // 000000232014: CC0F403D
	v_mul_i32_i24_e32 v1, 0xe408, v61                          // 000000232018: 12027AFF 0000E408
	s_delay_alu instid0(VALU_DEP_4)                            // 000000232020: BF870004
	.long 0xcc0f400f                                           // 000000232024: CC0F400F
	v_mul_i32_i24_e32 v1, 0xe408, v15                          // 000000232028: 12021EFF 0000E408
	s_waitcnt lgkmcnt(1)                                       // 000000232030: BF89FC17
	v_dot2acc_f32_f16 v76, v13, v72                            // 000000232034: 0498910D
	v_lshrrev_b32_e32 v13, 4, v21                              // 000000232038: 321A2A84
	v_and_b32_e32 v21, 0xf0f0f0f, v63                          // 00000023203C: 362A7EFF 0F0F0F0F
	.long 0xcc0f403f                                           // 000000232044: CC0F403F
	v_mul_i32_i24_e32 v1, 0xe408, v69                          // 000000232048: 12028AFF 0000E408
	v_dot2acc_f32_f16 v54, v61, v71                            // 000000232050: 046C8F3D
	v_dot2acc_f32_f16 v76, v68, v73                            // 000000232054: 04989344
	v_and_b32_e32 v13, 0xf0f0f0f, v13                          // 000000232058: 361A1AFF 0F0F0F0F
	v_perm_b32 v69, v21, v62, 0xc040c00                        // 000000232060: D6440045 03FE7D15 0C040C00
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000023206C: BF870193
	v_dot2acc_f32_f16 v76, v63, v74                            // 000000232070: 0498953F
	v_perm_b32 v68, v13, v20, 0xc040c00                        // 000000232074: D6440044 03FE290D 0C040C00
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000232080: BF870193
	v_or_b32_e32 v69, 0x64006400, v69                          // 000000232084: 388A8AFF 64006400
	v_dot2acc_f32_f16 v76, v15, v75                            // 00000023208C: 0498970F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000232090: BF870223
	v_or_b32_e32 v63, 0x64006400, v68                          // 000000232094: 387E88FF 64006400
	v_perm_b32 v68, v13, v20, 0xc050c01                        // 00000023209C: D6440044 03FE290D 0C050C01
	.long 0xcc0f4048                                           // 0000002320A8: CC0F4048
	v_mul_i32_i24_e32 v1, 0xe408, v69                          // 0000002320AC: 12028AFF 0000E408
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002320B4: BF870193
	.long 0xcc0f400f                                           // 0000002320B8: CC0F400F
	v_mul_i32_i24_e32 v1, 0xe408, v63                          // 0000002320BC: 12027EFF 0000E408
	v_or_b32_e32 v61, 0x64006400, v68                          // 0000002320C4: 387A88FF 64006400
	v_perm_b32 v63, v13, v20, 0xc060c02                        // 0000002320CC: D644003F 03FE290D 0C060C02
	v_perm_b32 v13, v13, v20, 0xc070c03                        // 0000002320D8: D644000D 03FE290D 0C070C03
	v_and_b32_e32 v20, 0xf0f0f0f, v22                          // 0000002320E4: 36282CFF 0F0F0F0F
	s_waitcnt lgkmcnt(0)                                       // 0000002320EC: BF89FC07
	v_dot2acc_f32_f16 v76, v15, v48                            // 0000002320F0: 0498610F
	v_lshrrev_b32_e32 v15, 4, v22                              // 0000002320F4: 321E2C84
	.long 0xcc0f4030                                           // 0000002320F8: CC0F4030
	v_mul_i32_i24_e32 v1, 0xe408, v61                          // 0000002320FC: 12027AFF 0000E408
	v_or_b32_e32 v61, 0x64006400, v63                          // 000000232104: 387A7EFF 64006400
	ds_load_b128 v[68:71], v60 offset:2080                     // 00000023210C: DBFC0820 4400003C
	v_or_b32_e32 v13, 0x64006400, v13                          // 000000232114: 381A1AFF 64006400
	v_dual_dot2acc_f32_f16 v76, v48, v49 :: v_dual_and_b32 v15, 0xf0f0f0f, v15// 00000023211C: CB246330 4C0E1EFF 0F0F0F0F
	.long 0xcc0f4030                                           // 000000232128: CC0F4030
	v_mul_i32_i24_e32 v1, 0xe408, v61                          // 00000023212C: 12027AFF 0000E408
	v_perm_b32 v22, v21, v62, 0xc050c01                        // 000000232134: D6440016 03FE7D15 0C050C01
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000232140: BF870214
	.long 0xcc0f400d                                           // 000000232144: CC0F400D
	v_mul_i32_i24_e32 v1, 0xe408, v13                          // 000000232148: 12021AFF 0000E408
	v_perm_b32 v49, v15, v20, 0xc040c00                        // 000000232150: D6440031 03FE290F 0C040C00
	v_dot2acc_f32_f16 v54, v72, v64                            // 00000023215C: 046C8148
	v_dot2acc_f32_f16 v76, v48, v50                            // 000000232160: 04986530
	v_or_b32_e32 v22, 0x64006400, v22                          // 000000232164: 382C2CFF 64006400
	v_perm_b32 v50, v21, v62, 0xc060c02                        // 00000023216C: D6440032 03FE7D15 0C060C02
	v_or_b32_e32 v48, 0x64006400, v49                          // 000000232178: 386062FF 64006400
	v_perm_b32 v49, v15, v20, 0xc050c01                        // 000000232180: D6440031 03FE290F 0C050C01
	v_dot2acc_f32_f16 v76, v13, v51                            // 00000023218C: 0498670D
	.long 0xcc0f4016                                           // 000000232190: CC0F4016
	v_mul_i32_i24_e32 v1, 0xe408, v22                          // 000000232194: 12022CFF 0000E408
	v_or_b32_e32 v63, 0x64006400, v50                          // 00000023219C: 387E64FF 64006400
	.long 0xcc0f400d                                           // 0000002321A4: CC0F400D
	v_mul_i32_i24_e32 v1, 0xe408, v48                          // 0000002321A8: 120260FF 0000E408
	v_or_b32_e32 v61, 0x64006400, v49                          // 0000002321B0: 387A62FF 64006400
	v_perm_b32 v64, v15, v20, 0xc060c02                        // 0000002321B8: D6440040 03FE290F 0C060C02
	ds_load_b128 v[48:51], v60 offset:2096                     // 0000002321C4: DBFC0830 3000003C
	v_dot2acc_f32_f16 v54, v22, v65                            // 0000002321CC: 046C8316
	s_waitcnt lgkmcnt(1)                                       // 0000002321D0: BF89FC17
	v_dot2acc_f32_f16 v76, v13, v68                            // 0000002321D4: 0498890D
	.long 0xcc0f400d                                           // 0000002321D8: CC0F400D
	v_mul_i32_i24_e32 v1, 0xe408, v61                          // 0000002321DC: 12027AFF 0000E408
	v_or_b32_e32 v22, 0x64006400, v64                          // 0000002321E4: 382C80FF 64006400
	v_perm_b32 v15, v15, v20, 0xc070c03                        // 0000002321EC: D644000F 03FE290F 0C070C03
	s_waitcnt vmcnt(8)                                         // 0000002321F8: BF8923F7
	v_lshrrev_b32_e32 v20, 4, v44                              // 0000002321FC: 32285884
	.long 0xcc0f403d                                           // 000000232200: CC0F403D
	v_mul_i32_i24_e32 v1, 0xe408, v63                          // 000000232204: 12027EFF 0000E408
	v_dot2acc_f32_f16 v76, v13, v69                            // 00000023220C: 04988B0D
	v_lshrrev_b32_e32 v13, 4, v23                              // 000000232210: 321A2E84
	v_perm_b32 v62, v21, v62, 0xc070c03                        // 000000232214: D644003E 03FE7D15 0C070C03
	.long 0xcc0f403f                                           // 000000232220: CC0F403F
	v_mul_i32_i24_e32 v1, 0xe408, v22                          // 000000232224: 12022CFF 0000E408
	v_and_b32_e32 v69, 0xf0f0f0f, v23                          // 00000023222C: 368A2EFF 0F0F0F0F
	v_and_b32_e32 v44, 0xf0f0f0f, v44                          // 000000232234: 365858FF 0F0F0F0F
	v_and_b32_e32 v13, 0xf0f0f0f, v13                          // 00000023223C: 361A1AFF 0F0F0F0F
	v_and_b32_e32 v65, 0xf0f0f0f, v20                          // 000000232244: 368228FF 0F0F0F0F
	ds_load_b128 v[20:23], v60 offset:2304                     // 00000023224C: DBFC0900 1400003C
	v_or_b32_e32 v15, 0x64006400, v15                          // 000000232254: 381E1EFF 64006400
	v_or_b32_e32 v62, 0x64006400, v62                          // 00000023225C: 387C7CFF 64006400
	v_perm_b32 v64, v13, v69, 0xc040c00                        // 000000232264: D6440040 03FE8B0D 0C040C00
	v_dot2acc_f32_f16 v76, v63, v70                            // 000000232270: 04988D3F
	v_perm_b32 v63, v65, v44, 0xc040c00                        // 000000232274: D644003F 03FE5941 0C040C00
	.long 0xcc0f400f                                           // 000000232280: CC0F400F
	v_mul_i32_i24_e32 v1, 0xe408, v15                          // 000000232284: 12021EFF 0000E408
	v_dot2acc_f32_f16 v54, v61, v66                            // 00000023228C: 046C853D
	v_or_b32_e32 v64, 0x64006400, v64                          // 000000232290: 388080FF 64006400
	.long 0xcc0f403d                                           // 000000232298: CC0F403D
	v_mul_i32_i24_e32 v1, 0xe408, v62                          // 00000023229C: 12027CFF 0000E408
	v_or_b32_e32 v62, 0x64006400, v63                          // 0000002322A4: 387C7EFF 64006400
	v_dot2acc_f32_f16 v76, v15, v71                            // 0000002322AC: 04988F0F
	v_perm_b32 v63, v65, v44, 0xc050c01                        // 0000002322B0: D644003F 03FE5941 0C050C01
	.long 0xcc0f400f                                           // 0000002322BC: CC0F400F
	v_mul_i32_i24_e32 v1, 0xe408, v64                          // 0000002322C0: 120280FF 0000E408
	v_mov_b32_e32 v70, 0                                       // 0000002322C8: 7E8C0280
	.long 0xcc0f4042                                           // 0000002322CC: CC0F4042
	v_mul_i32_i24_e32 v1, 0xe408, v62                          // 0000002322D0: 12027CFF 0000E408
	v_dot2acc_f32_f16 v54, v61, v67                            // 0000002322D8: 046C873D
	s_waitcnt lgkmcnt(1)                                       // 0000002322DC: BF89FC17
	v_dot2acc_f32_f16 v76, v15, v48                            // 0000002322E0: 0498610F
	v_or_b32_e32 v15, 0x64006400, v63                          // 0000002322E4: 381E7EFF 64006400
	v_perm_b32 v48, v65, v44, 0xc060c02                        // 0000002322EC: D6440030 03FE5941 0C060C02
	ds_load_b128 v[61:64], v60 offset:2320                     // 0000002322F8: DBFC0910 3D00003C
	s_waitcnt lgkmcnt(1)                                       // 000000232300: BF89FC17
	v_dot2acc_f32_f16 v70, v66, v20                            // 000000232304: 048C2942
	v_lshrrev_b32_e32 v20, 4, v45                              // 000000232308: 32285A84
	.long 0xcc0f400f                                           // 00000023230C: CC0F400F
	v_mul_i32_i24_e32 v1, 0xe408, v15                          // 000000232310: 12021EFF 0000E408
	v_or_b32_e32 v48, 0x64006400, v48                          // 000000232318: 386060FF 64006400
	v_perm_b32 v44, v65, v44, 0xc070c03                        // 000000232320: D644002C 03FE5941 0C070C03
	v_and_b32_e32 v45, 0xf0f0f0f, v45                          // 00000023232C: 365A5AFF 0F0F0F0F
	v_and_b32_e32 v20, 0xf0f0f0f, v20                          // 000000232334: 362828FF 0F0F0F0F
	v_perm_b32 v65, v13, v69, 0xc050c01                        // 00000023233C: D6440041 03FE8B0D 0C050C01
	v_dot2acc_f32_f16 v70, v15, v21                            // 000000232348: 048C2B0F
	.long 0xcc0f400f                                           // 00000023234C: CC0F400F
	v_mul_i32_i24_e32 v1, 0xe408, v48                          // 000000232350: 120260FF 0000E408
	v_or_b32_e32 v21, 0x64006400, v44                          // 000000232358: 382A58FF 64006400
	v_perm_b32 v44, v20, v45, 0xc040c00                        // 000000232360: D644002C 03FE5B14 0C040C00
	v_or_b32_e32 v48, 0x64006400, v65                          // 00000023236C: 386082FF 64006400
	v_perm_b32 v65, v13, v69, 0xc060c02                        // 000000232374: D6440041 03FE8B0D 0C060C02
	v_dot2acc_f32_f16 v70, v15, v22                            // 000000232380: 048C2D0F
	.long 0xcc0f400f                                           // 000000232384: CC0F400F
	v_mul_i32_i24_e32 v1, 0xe408, v21                          // 000000232388: 12022AFF 0000E408
	v_or_b32_e32 v21, 0x64006400, v44                          // 000000232390: 382A58FF 64006400
	.long 0xcc0f4016                                           // 000000232398: CC0F4016
	v_mul_i32_i24_e32 v1, 0xe408, v48                          // 00000023239C: 120260FF 0000E408
	v_perm_b32 v44, v20, v45, 0xc050c01                        // 0000002323A4: D644002C 03FE5B14 0C050C01
	v_or_b32_e32 v48, 0x64006400, v65                          // 0000002323B0: 386082FF 64006400
	v_dot2acc_f32_f16 v70, v15, v23                            // 0000002323B8: 048C2F0F
	.long 0xcc0f400f                                           // 0000002323BC: CC0F400F
	v_mul_i32_i24_e32 v1, 0xe408, v21                          // 0000002323C0: 12022AFF 0000E408
	v_dot2acc_f32_f16 v76, v22, v49                            // 0000002323C8: 04986316
	v_or_b32_e32 v21, 0x64006400, v44                          // 0000002323CC: 382A58FF 64006400
	v_perm_b32 v22, v20, v45, 0xc060c02                        // 0000002323D4: D6440016 03FE5B14 0C060C02
	v_perm_b32 v20, v20, v45, 0xc070c03                        // 0000002323E0: D6440014 03FE5B14 0C070C03
	s_waitcnt lgkmcnt(0)                                       // 0000002323EC: BF89FC07
	v_dot2acc_f32_f16 v70, v15, v61                            // 0000002323F0: 048C7B0F
	v_lshrrev_b32_e32 v15, 4, v46                              // 0000002323F4: 321E5C84
	.long 0xcc0f4015                                           // 0000002323F8: CC0F4015
	v_mul_i32_i24_e32 v1, 0xe408, v21                          // 0000002323FC: 12022AFF 0000E408
	v_or_b32_e32 v22, 0x64006400, v22                          // 000000232404: 382C2CFF 64006400
	v_and_b32_e32 v44, 0xf0f0f0f, v46                          // 00000023240C: 36585CFF 0F0F0F0F
	ds_load_b128 v[65:68], v60 offset:2336                     // 000000232414: DBFC0920 4100003C
	v_and_b32_e32 v15, 0xf0f0f0f, v15                          // 00000023241C: 361E1EFF 0F0F0F0F
	v_perm_b32 v13, v13, v69, 0xc070c03                        // 000000232424: D644000D 03FE8B0D 0C070C03
	v_dot2acc_f32_f16 v70, v21, v62                            // 000000232430: 048C7D15
	.long 0xcc0f4015                                           // 000000232434: CC0F4015
	v_mul_i32_i24_e32 v1, 0xe408, v22                          // 000000232438: 12022CFF 0000E408
	v_or_b32_e32 v20, 0x64006400, v20                          // 000000232440: 382828FF 64006400
	v_perm_b32 v22, v15, v44, 0xc040c00                        // 000000232448: D6440016 03FE590F 0C040C00
	.long 0xcc0f4017                                           // 000000232454: CC0F4017
	v_mul_i32_i24_e32 v1, 0xe408, v48                          // 000000232458: 120260FF 0000E408
	v_or_b32_e32 v13, 0x64006400, v13                          // 000000232460: 381A1AFF 64006400
	v_dot2acc_f32_f16 v70, v21, v63                            // 000000232468: 048C7F15
	.long 0xcc0f4014                                           // 00000023246C: CC0F4014
	v_mul_i32_i24_e32 v1, 0xe408, v20                          // 000000232470: 120228FF 0000E408
	v_or_b32_e32 v21, 0x64006400, v22                          // 000000232478: 382A2CFF 64006400
	v_dot2acc_f32_f16 v76, v23, v50                            // 000000232480: 04986517
	.long 0xcc0f400d                                           // 000000232484: CC0F400D
	v_mul_i32_i24_e32 v1, 0xe408, v13                          // 000000232488: 12021AFF 0000E408
	v_perm_b32 v22, v15, v44, 0xc050c01                        // 000000232490: D6440016 03FE590F 0C050C01
	v_fma_mix_f32 v45, v14, v54, v12 op_sel:[1,0,0] op_sel_hi:[1,0,0]// 00000023249C: CC20082D 0C326D0E
	v_dot2acc_f32_f16 v70, v20, v64                            // 0000002324A4: 048C8114
	.long 0xcc0f400c                                           // 0000002324A8: CC0F400C
	v_mul_i32_i24_e32 v1, 0xe408, v21                          // 0000002324AC: 12022AFF 0000E408
	v_dot2acc_f32_f16 v76, v13, v51                            // 0000002324B4: 0498670D
	v_or_b32_e32 v13, 0x64006400, v22                          // 0000002324B8: 381A2CFF 64006400
	v_perm_b32 v14, v15, v44, 0xc060c02                        // 0000002324C0: D644000E 03FE590F 0C060C02
	ds_load_b128 v[48:51], v60 offset:2352                     // 0000002324CC: DBFC0930 3000003C
	s_waitcnt lgkmcnt(1)                                       // 0000002324D4: BF89FC17
	v_dot2acc_f32_f16 v70, v12, v65                            // 0000002324D8: 048C830C
	s_waitcnt vmcnt(5)                                         // 0000002324DC: BF8917F7
	v_lshrrev_b32_e32 v12, 4, v40                              // 0000002324E0: 32185084
	.long 0xcc0f400d                                           // 0000002324E4: CC0F400D
	v_mul_i32_i24_e32 v1, 0xe408, v13                          // 0000002324E8: 12021AFF 0000E408
	v_or_b32_e32 v14, 0x64006400, v14                          // 0000002324F0: 381C1CFF 64006400
	v_and_b32_e32 v40, 0xf0f0f0f, v40                          // 0000002324F8: 365050FF 0F0F0F0F
	ds_load_b128 v[61:64], v60 offset:2560                     // 000000232500: DBFC0A00 3D00003C
	v_and_b32_e32 v54, 0xf0f0f0f, v12                          // 000000232508: 366C18FF 0F0F0F0F
	v_perm_b32 v15, v15, v44, 0xc070c03                        // 000000232510: D644000F 03FE590F 0C070C03
	v_dot2acc_f32_f16 v70, v13, v66                            // 00000023251C: 048C850D
	.long 0xcc0f402c                                           // 000000232520: CC0F402C
	v_mul_i32_i24_e32 v1, 0xe408, v14                          // 000000232524: 12021CFF 0000E408
	v_mov_b32_e32 v69, 0                                       // 00000023252C: 7E8A0280
	v_perm_b32 v65, v54, v40, 0xc040c00                        // 000000232530: D6440041 03FE5136 0C040C00
	v_or_b32_e32 v46, 0x64006400, v15                          // 00000023253C: 385C1EFF 64006400
	s_clause 0x1                                               // 000000232544: BF850001
	global_load_b128 v[20:23], v[57:58], off offset:1152       // 000000232548: DC5E0480 147C0039
	global_load_b128 v[12:15], v[57:58], off offset:1216       // 000000232550: DC5E04C0 0C7C0039
	v_dot2acc_f32_f16 v70, v44, v67                            // 000000232558: 048C872C
	v_fma_mix_f32 v57, v0, v76, v45 op_sel_hi:[1,0,0]          // 00000023255C: CC200039 0CB69900
	v_or_b32_e32 v44, 0x64006400, v65                          // 000000232564: 385882FF 64006400
	.long 0xcc0f403a                                           // 00000023256C: CC0F403A
	v_mul_i32_i24_e32 v1, 0xe408, v46                          // 000000232570: 12025CFF 0000E408
	v_lshrrev_b32_e32 v45, 4, v47                              // 000000232578: 325A5E84
	v_perm_b32 v46, v54, v40, 0xc050c01                        // 00000023257C: D644002E 03FE5136 0C050C01
	v_and_b32_e32 v65, 0xf0f0f0f, v47                          // 000000232588: 36825EFF 0F0F0F0F
	.long 0xcc0f4042                                           // 000000232590: CC0F4042
	v_mul_i32_i24_e32 v1, 0xe408, v44                          // 000000232594: 120258FF 0000E408
	v_perm_b32 v72, v54, v40, 0xc060c02                        // 00000023259C: D6440048 03FE5136 0C060C02
	v_and_b32_e32 v67, 0xf0f0f0f, v45                          // 0000002325A8: 36865AFF 0F0F0F0F
	v_or_b32_e32 v71, 0x64006400, v46                          // 0000002325B0: 388E5CFF 64006400
	ds_load_b128 v[44:47], v60 offset:2576                     // 0000002325B8: DBFC0A10 2C00003C
	s_waitcnt lgkmcnt(1)                                       // 0000002325C0: BF89FC17
	v_dot2acc_f32_f16 v69, v66, v61                            // 0000002325C4: 048A7B42
	v_lshrrev_b32_e32 v61, 4, v41                              // 0000002325C8: 327A5284
	v_perm_b32 v40, v54, v40, 0xc070c03                        // 0000002325CC: D6440028 03FE5136 0C070C03
	.long 0xcc0f4042                                           // 0000002325D8: CC0F4042
	v_mul_i32_i24_e32 v1, 0xe408, v71                          // 0000002325DC: 12028EFF 0000E408
	v_or_b32_e32 v71, 0x64006400, v72                          // 0000002325E4: 388E90FF 64006400
	v_and_b32_e32 v41, 0xf0f0f0f, v41                          // 0000002325EC: 365252FF 0F0F0F0F
	v_and_b32_e32 v54, 0xf0f0f0f, v61                          // 0000002325F4: 366C7AFF 0F0F0F0F
	v_perm_b32 v61, v67, v65, 0xc040c00                        // 0000002325FC: D644003D 03FE8343 0C040C00
	v_dot2acc_f32_f16 v69, v66, v62                            // 000000232608: 048A7D42
	.long 0xcc0f403e                                           // 00000023260C: CC0F403E
	v_mul_i32_i24_e32 v1, 0xe408, v71                          // 000000232610: 12028EFF 0000E408
	v_or_b32_e32 v40, 0x64006400, v40                          // 000000232618: 385050FF 64006400
	v_perm_b32 v66, v54, v41, 0xc040c00                        // 000000232620: D6440042 03FE5336 0C040C00
	v_or_b32_e32 v61, 0x64006400, v61                          // 00000023262C: 387A7AFF 64006400
	v_dot2acc_f32_f16 v70, v58, v68                            // 000000232634: 048C893A
	v_dot2acc_f32_f16 v69, v62, v63                            // 000000232638: 048A7F3E
	.long 0xcc0f4028                                           // 00000023263C: CC0F4028
	v_mul_i32_i24_e32 v1, 0xe408, v40                          // 000000232640: 120250FF 0000E408
	v_or_b32_e32 v58, 0x64006400, v66                          // 000000232648: 387484FF 64006400
	.long 0xcc0f403d                                           // 000000232650: CC0F403D
	v_mul_i32_i24_e32 v1, 0xe408, v61                          // 000000232654: 12027AFF 0000E408
	v_perm_b32 v62, v54, v41, 0xc050c01                        // 00000023265C: D644003E 03FE5336 0C050C01
	v_perm_b32 v63, v67, v65, 0xc050c01                        // 000000232668: D644003F 03FE8343 0C050C01
	v_dot2acc_f32_f16 v69, v40, v64                            // 000000232674: 048A8128
	.long 0xcc0f4028                                           // 000000232678: CC0F4028
	v_mul_i32_i24_e32 v1, 0xe408, v58                          // 00000023267C: 120274FF 0000E408
	v_dot2acc_f32_f16 v70, v61, v48                            // 000000232684: 048C613D
	v_or_b32_e32 v48, 0x64006400, v62                          // 000000232688: 38607CFF 64006400
	v_perm_b32 v58, v54, v41, 0xc060c02                        // 000000232690: D644003A 03FE5336 0C060C02
	v_or_b32_e32 v66, 0x64006400, v63                          // 00000023269C: 38847EFF 64006400
	s_waitcnt lgkmcnt(0)                                       // 0000002326A4: BF89FC07
	v_dot2acc_f32_f16 v69, v40, v44                            // 0000002326A8: 048A5928
	v_lshrrev_b32_e32 v40, 4, v42                              // 0000002326AC: 32505484
	.long 0xcc0f402c                                           // 0000002326B0: CC0F402C
	v_mul_i32_i24_e32 v1, 0xe408, v48                          // 0000002326B4: 120260FF 0000E408
	v_or_b32_e32 v48, 0x64006400, v58                          // 0000002326BC: 386074FF 64006400
	v_perm_b32 v41, v54, v41, 0xc070c03                        // 0000002326C4: D6440029 03FE5336 0C070C03
	v_and_b32_e32 v42, 0xf0f0f0f, v42                          // 0000002326D0: 365454FF 0F0F0F0F
	v_and_b32_e32 v40, 0xf0f0f0f, v40                          // 0000002326D8: 365050FF 0F0F0F0F
	ds_load_b128 v[61:64], v60 offset:2592                     // 0000002326E0: DBFC0A20 3D00003C
	v_dot2acc_f32_f16 v69, v44, v45                            // 0000002326E8: 048A5B2C
	.long 0xcc0f402c                                           // 0000002326EC: CC0F402C
	v_mul_i32_i24_e32 v1, 0xe408, v48                          // 0000002326F0: 120260FF 0000E408
	v_or_b32_e32 v41, 0x64006400, v41                          // 0000002326F8: 385252FF 64006400
	v_perm_b32 v45, v40, v42, 0xc040c00                        // 000000232700: D644002D 03FE5528 0C040C00
	v_perm_b32 v54, v67, v65, 0xc060c02                        // 00000023270C: D6440036 03FE8343 0C060C02
	.long 0xcc0f4030                                           // 000000232718: CC0F4030
	v_mul_i32_i24_e32 v1, 0xe408, v66                          // 00000023271C: 120284FF 0000E408
	v_dot2acc_f32_f16 v69, v44, v46                            // 000000232724: 048A5D2C
	.long 0xcc0f4029                                           // 000000232728: CC0F4029
	v_mul_i32_i24_e32 v1, 0xe408, v41                          // 00000023272C: 120252FF 0000E408
	v_or_b32_e32 v44, 0x64006400, v45                          // 000000232734: 38585AFF 64006400
	v_or_b32_e32 v54, 0x64006400, v54                          // 00000023273C: 386C6CFF 64006400
	v_perm_b32 v45, v40, v42, 0xc050c01                        // 000000232744: D644002D 03FE5528 0C050C01
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000232750: BF870214
	v_dual_dot2acc_f32_f16 v70, v48, v49 :: v_dual_dot2acc_f32_f16 v69, v41, v47// 000000232754: CB186330 46445F29
	.long 0xcc0f4029                                           // 00000023275C: CC0F4029
	v_mul_i32_i24_e32 v1, 0xe408, v44                          // 000000232760: 120258FF 0000E408
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000232768: BF870214
	.long 0xcc0f4030                                           // 00000023276C: CC0F4030
	v_mul_i32_i24_e32 v1, 0xe408, v54                          // 000000232770: 12026CFF 0000E408
	v_or_b32_e32 v54, 0x64006400, v45                          // 000000232778: 386C5AFF 64006400
	ds_load_b128 v[44:47], v60 offset:2608                     // 000000232780: DBFC0A30 2C00003C
	v_perm_b32 v49, v67, v65, 0xc070c03                        // 000000232788: D6440031 03FE8343 0C070C03
	v_perm_b32 v58, v40, v42, 0xc060c02                        // 000000232794: D644003A 03FE5528 0C060C02
	s_waitcnt lgkmcnt(1)                                       // 0000002327A0: BF89FC17
	v_dot2acc_f32_f16 v69, v41, v61                            // 0000002327A4: 048A7B29
	s_waitcnt vmcnt(6)                                         // 0000002327A8: BF891BF7
	v_lshrrev_b32_e32 v41, 4, v36                              // 0000002327AC: 32524884
	v_and_b32_e32 v36, 0xf0f0f0f, v36                          // 0000002327B0: 364848FF 0F0F0F0F
	ds_load_b128 v[65:68], v60 offset:2816                     // 0000002327B8: DBFC0B00 4100003C
	.long 0xcc0f4036                                           // 0000002327C0: CC0F4036
	v_mul_i32_i24_e32 v1, 0xe408, v54                          // 0000002327C4: 12026CFF 0000E408
	v_or_b32_e32 v58, 0x64006400, v58                          // 0000002327CC: 387474FF 64006400
	v_and_b32_e32 v61, 0xf0f0f0f, v41                          // 0000002327D4: 367A52FF 0F0F0F0F
	v_perm_b32 v40, v40, v42, 0xc070c03                        // 0000002327DC: D6440028 03FE5528 0C070C03
	v_or_b32_e32 v41, 0x64006400, v49                          // 0000002327E8: 385262FF 64006400
	v_dot2acc_f32_f16 v69, v54, v62                            // 0000002327F0: 048A7D36
	.long 0xcc0f402a                                           // 0000002327F4: CC0F402A
	v_mul_i32_i24_e32 v1, 0xe408, v58                          // 0000002327F8: 120274FF 0000E408
	v_perm_b32 v49, v61, v36, 0xc040c00                        // 000000232800: D6440031 03FE493D 0C040C00
	v_or_b32_e32 v40, 0x64006400, v40                          // 00000023280C: 385050FF 64006400
	v_dot2acc_f32_f16 v70, v48, v50                            // 000000232814: 048C6530
	.long 0xcc0f4030                                           // 000000232818: CC0F4030
	v_mul_i32_i24_e32 v1, 0xe408, v41                          // 00000023281C: 120252FF 0000E408
	v_dot2acc_f32_f16 v69, v42, v63                            // 000000232824: 048A7F2A
	v_or_b32_e32 v41, 0x64006400, v49                          // 000000232828: 385262FF 64006400
	.long 0xcc0f4031                                           // 000000232830: CC0F4031
	v_mul_i32_i24_e32 v1, 0xe408, v40                          // 000000232834: 120250FF 0000E408
	v_lshrrev_b32_e32 v40, 4, v43                              // 00000023283C: 32505684
	v_perm_b32 v42, v61, v36, 0xc050c01                        // 000000232840: D644002A 03FE493D 0C050C01
	v_mov_b32_e32 v58, 0                                       // 00000023284C: 7E740280
	.long 0xcc0f4032                                           // 000000232850: CC0F4032
	v_mul_i32_i24_e32 v1, 0xe408, v41                          // 000000232854: 120252FF 0000E408
	v_and_b32_e32 v54, 0xf0f0f0f, v43                          // 00000023285C: 366C56FF 0F0F0F0F
	v_and_b32_e32 v62, 0xf0f0f0f, v40                          // 000000232864: 367C50FF 0F0F0F0F
	v_or_b32_e32 v63, 0x64006400, v42                          // 00000023286C: 387E54FF 64006400
	v_perm_b32 v71, v61, v36, 0xc060c02                        // 000000232874: D6440047 03FE493D 0C060C02
	ds_load_b128 v[40:43], v60 offset:2832                     // 000000232880: DBFC0B10 2800003C
	s_waitcnt lgkmcnt(1)                                       // 000000232888: BF89FC17
	v_dot2acc_f32_f16 v58, v50, v65                            // 00000023288C: 04748332
	v_lshrrev_b32_e32 v50, 4, v37                              // 000000232890: 32644A84
	.long 0xcc0f403f                                           // 000000232894: CC0F403F
	v_mul_i32_i24_e32 v1, 0xe408, v63                          // 000000232898: 12027EFF 0000E408
	v_or_b32_e32 v65, 0x64006400, v71                          // 0000002328A0: 38828EFF 64006400
	v_perm_b32 v36, v61, v36, 0xc070c03                        // 0000002328A8: D6440024 03FE493D 0C070C03
	v_and_b32_e32 v37, 0xf0f0f0f, v37                          // 0000002328B4: 364A4AFF 0F0F0F0F
	v_and_b32_e32 v50, 0xf0f0f0f, v50                          // 0000002328BC: 366464FF 0F0F0F0F
	v_perm_b32 v61, v62, v54, 0xc040c00                        // 0000002328C4: D644003D 03FE6D3E 0C040C00
	v_dot2acc_f32_f16 v58, v63, v66                            // 0000002328D0: 0474853F
	.long 0xcc0f403f                                           // 0000002328D4: CC0F403F
	v_mul_i32_i24_e32 v1, 0xe408, v65                          // 0000002328D8: 120282FF 0000E408
	v_or_b32_e32 v36, 0x64006400, v36                          // 0000002328E0: 384848FF 64006400
	v_perm_b32 v65, v50, v37, 0xc040c00                        // 0000002328E8: D6440041 03FE4B32 0C040C00
	v_or_b32_e32 v61, 0x64006400, v61                          // 0000002328F4: 387A7AFF 64006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002328FC: BF870214
	v_dual_dot2acc_f32_f16 v69, v49, v64 :: v_dual_dot2acc_f32_f16 v58, v63, v67// 000000232900: CB188131 453A873F
	.long 0xcc0f4024                                           // 000000232908: CC0F4024
	v_mul_i32_i24_e32 v1, 0xe408, v36                          // 00000023290C: 120248FF 0000E408
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000232914: BF870214
	v_or_b32_e32 v49, 0x64006400, v65                          // 000000232918: 386282FF 64006400
	.long 0xcc0f403d                                           // 000000232920: CC0F403D
	v_mul_i32_i24_e32 v1, 0xe408, v61                          // 000000232924: 12027AFF 0000E408
	v_perm_b32 v63, v50, v37, 0xc050c01                        // 00000023292C: D644003F 03FE4B32 0C050C01
	v_dot2acc_f32_f16 v70, v48, v51                            // 000000232938: 048C6730
	v_dot2acc_f32_f16 v58, v36, v68                            // 00000023293C: 04748924
	.long 0xcc0f4024                                           // 000000232940: CC0F4024
	v_mul_i32_i24_e32 v1, 0xe408, v49                          // 000000232944: 120262FF 0000E408
	v_dot2acc_f32_f16 v69, v61, v44                            // 00000023294C: 048A593D
	v_or_b32_e32 v44, 0x64006400, v63                          // 000000232950: 38587EFF 64006400
	v_perm_b32 v48, v50, v37, 0xc060c02                        // 000000232958: D6440030 03FE4B32 0C060C02
	v_perm_b32 v61, v62, v54, 0xc050c01                        // 000000232964: D644003D 03FE6D3E 0C050C01
	s_waitcnt lgkmcnt(0)                                       // 000000232970: BF89FC07
	v_dot2acc_f32_f16 v58, v36, v40                            // 000000232974: 04745124
	v_lshrrev_b32_e32 v36, 4, v38                              // 000000232978: 32484C84
	.long 0xcc0f4028                                           // 00000023297C: CC0F4028
	v_mul_i32_i24_e32 v1, 0xe408, v44                          // 000000232980: 120258FF 0000E408
	v_or_b32_e32 v44, 0x64006400, v48                          // 000000232988: 385860FF 64006400
	v_perm_b32 v37, v50, v37, 0xc070c03                        // 000000232990: D6440025 03FE4B32 0C070C03
	v_and_b32_e32 v38, 0xf0f0f0f, v38                          // 00000023299C: 364C4CFF 0F0F0F0F
	v_and_b32_e32 v36, 0xf0f0f0f, v36                          // 0000002329A4: 364848FF 0F0F0F0F
	ds_load_b128 v[48:51], v60 offset:2848                     // 0000002329AC: DBFC0B20 3000003C
	v_or_b32_e32 v61, 0x64006400, v61                          // 0000002329B4: 387A7AFF 64006400
	v_dot2acc_f32_f16 v58, v40, v41                            // 0000002329BC: 04745328
	.long 0xcc0f4028                                           // 0000002329C0: CC0F4028
	v_mul_i32_i24_e32 v1, 0xe408, v44                          // 0000002329C4: 120258FF 0000E408
	v_or_b32_e32 v37, 0x64006400, v37                          // 0000002329CC: 384A4AFF 64006400
	v_perm_b32 v41, v36, v38, 0xc040c00                        // 0000002329D4: D6440029 03FE4D24 0C040C00
	.long 0xcc0f402c                                           // 0000002329E0: CC0F402C
	v_mul_i32_i24_e32 v1, 0xe408, v61                          // 0000002329E4: 12027AFF 0000E408
	v_perm_b32 v61, v62, v54, 0xc060c02                        // 0000002329EC: D644003D 03FE6D3E 0C060C02
	v_dot2acc_f32_f16 v58, v40, v42                            // 0000002329F8: 04745528
	.long 0xcc0f4025                                           // 0000002329FC: CC0F4025
	v_mul_i32_i24_e32 v1, 0xe408, v37                          // 000000232A00: 12024AFF 0000E408
	v_or_b32_e32 v40, 0x64006400, v41                          // 000000232A08: 385052FF 64006400
	v_perm_b32 v41, v36, v38, 0xc050c01                        // 000000232A10: D6440029 03FE4D24 0C050C01
	v_or_b32_e32 v42, 0x64006400, v61                          // 000000232A1C: 38547AFF 64006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000232A24: BF870214
	v_dual_dot2acc_f32_f16 v69, v44, v45 :: v_dual_dot2acc_f32_f16 v58, v37, v43// 000000232A28: CB185B2C 453A5725
	.long 0xcc0f4025                                           // 000000232A30: CC0F4025
	v_mul_i32_i24_e32 v1, 0xe408, v40                          // 000000232A34: 120250FF 0000E408
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000232A3C: BF870214
	v_or_b32_e32 v44, 0x64006400, v41                          // 000000232A40: 385852FF 64006400
	.long 0xcc0f402d                                           // 000000232A48: CC0F402D
	v_mul_i32_i24_e32 v1, 0xe408, v42                          // 000000232A4C: 120254FF 0000E408
	ds_load_b128 v[40:43], v60 offset:2864                     // 000000232A54: DBFC0B30 2800003C
	v_perm_b32 v54, v62, v54, 0xc070c03                        // 000000232A5C: D6440036 03FE6D3E 0C070C03
	s_waitcnt lgkmcnt(1)                                       // 000000232A68: BF89FC17
	v_dot2acc_f32_f16 v58, v37, v48                            // 000000232A6C: 04746125
	.long 0xcc0f4025                                           // 000000232A70: CC0F4025
	v_mul_i32_i24_e32 v1, 0xe408, v44                          // 000000232A74: 120258FF 0000E408
	v_perm_b32 v44, v36, v38, 0xc060c02                        // 000000232A7C: D644002C 03FE4D24 0C060C02
	v_dot2acc_f32_f16 v69, v45, v46                            // 000000232A88: 048A5D2D
	v_or_b32_e32 v45, 0x64006400, v54                          // 000000232A8C: 385A6CFF 64006400
	v_perm_b32 v46, v36, v38, 0xc070c03                        // 000000232A94: D644002E 03FE4D24 0C070C03
	v_dot2acc_f32_f16 v58, v37, v49                            // 000000232AA0: 04746325
	v_lshrrev_b32_e32 v37, 4, v32                              // 000000232AA4: 324A4084
	v_or_b32_e32 v44, 0x64006400, v44                          // 000000232AA8: 385858FF 64006400
	v_lshrrev_b32_e32 v48, 4, v39                              // 000000232AB0: 32604E84
	v_and_b32_e32 v49, 0xf0f0f0f, v39                          // 000000232AB4: 36624EFF 0F0F0F0F
	v_and_b32_e32 v32, 0xf0f0f0f, v32                          // 000000232ABC: 364040FF 0F0F0F0F
	v_and_b32_e32 v54, 0xf0f0f0f, v37                          // 000000232AC4: 366C4AFF 0F0F0F0F
	ds_load_b128 v[36:39], v60 offset:3072                     // 000000232ACC: DBFC0C00 2400003C
	v_fma_mix_f32 v0, v0, v70, v57 op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000232AD4: CC200800 0CE68D00
	v_and_b32_e32 v48, 0xf0f0f0f, v48                          // 000000232ADC: 366060FF 0F0F0F0F
	.long 0xcc0f402c                                           // 000000232AE4: CC0F402C
	v_mul_i32_i24_e32 v1, 0xe408, v44                          // 000000232AE8: 120258FF 0000E408
	v_or_b32_e32 v46, 0x64006400, v46                          // 000000232AF0: 385C5CFF 64006400
	v_perm_b32 v57, v54, v32, 0xc040c00                        // 000000232AF8: D6440039 03FE4136 0C040C00
	.long 0xcc0f402d                                           // 000000232B04: CC0F402D
	v_mul_i32_i24_e32 v1, 0xe408, v45                          // 000000232B08: 12025AFF 0000E408
	v_perm_b32 v61, v48, v49, 0xc040c00                        // 000000232B10: D644003D 03FE6330 0C040C00
	v_dot2acc_f32_f16 v58, v44, v50                            // 000000232B1C: 0474652C
	.long 0xcc0f402c                                           // 000000232B20: CC0F402C
	v_mul_i32_i24_e32 v1, 0xe408, v46                          // 000000232B24: 12025CFF 0000E408
	v_or_b32_e32 v46, 0x64006400, v57                          // 000000232B2C: 385C72FF 64006400
	v_dot2acc_f32_f16 v69, v45, v47                            // 000000232B34: 048A5F2D
	v_or_b32_e32 v45, 0x64006400, v61                          // 000000232B38: 385A7AFF 64006400
	v_perm_b32 v47, v54, v32, 0xc050c01                        // 000000232B40: D644002F 03FE4136 0C050C01
	v_mov_b32_e32 v57, 0                                       // 000000232B4C: 7E720280
	.long 0xcc0f4032                                           // 000000232B50: CC0F4032
	v_mul_i32_i24_e32 v1, 0xe408, v46                          // 000000232B54: 12025CFF 0000E408
	v_dot2acc_f32_f16 v58, v44, v51                            // 000000232B5C: 0474672C
	.long 0xcc0f4033                                           // 000000232B60: CC0F4033
	v_mul_i32_i24_e32 v1, 0xe408, v45                          // 000000232B64: 12025AFF 0000E408
	v_or_b32_e32 v61, 0x64006400, v47                          // 000000232B6C: 387A5EFF 64006400
	v_perm_b32 v62, v54, v32, 0xc060c02                        // 000000232B74: D644003E 03FE4136 0C060C02
	ds_load_b128 v[44:47], v60 offset:3088                     // 000000232B80: DBFC0C10 2C00003C
	s_waitcnt lgkmcnt(1)                                       // 000000232B88: BF89FC17
	v_dot2acc_f32_f16 v57, v50, v36                            // 000000232B8C: 04724932
	v_lshrrev_b32_e32 v36, 4, v33                              // 000000232B90: 32484284
	.long 0xcc0f4032                                           // 000000232B94: CC0F4032
	v_mul_i32_i24_e32 v1, 0xe408, v61                          // 000000232B98: 12027AFF 0000E408
	v_or_b32_e32 v61, 0x64006400, v62                          // 000000232BA0: 387A7CFF 64006400
	v_perm_b32 v32, v54, v32, 0xc070c03                        // 000000232BA8: D6440020 03FE4136 0C070C03
	v_and_b32_e32 v33, 0xf0f0f0f, v33                          // 000000232BB4: 364242FF 0F0F0F0F
	v_and_b32_e32 v36, 0xf0f0f0f, v36                          // 000000232BBC: 364848FF 0F0F0F0F
	v_perm_b32 v54, v48, v49, 0xc050c01                        // 000000232BC4: D6440036 03FE6330 0C050C01
	v_dot2acc_f32_f16 v57, v50, v37                            // 000000232BD0: 04724B32
	.long 0xcc0f4025                                           // 000000232BD4: CC0F4025
	v_mul_i32_i24_e32 v1, 0xe408, v61                          // 000000232BD8: 12027AFF 0000E408
	v_or_b32_e32 v32, 0x64006400, v32                          // 000000232BE0: 384040FF 64006400
	v_perm_b32 v50, v36, v33, 0xc040c00                        // 000000232BE8: D6440032 03FE4324 0C040C00
	v_or_b32_e32 v54, 0x64006400, v54                          // 000000232BF4: 386C6CFF 64006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000232BFC: BF870214
	v_dual_dot2acc_f32_f16 v58, v51, v40 :: v_dual_dot2acc_f32_f16 v57, v37, v38// 000000232C00: CB185133 3A384D25
	.long 0xcc0f4020                                           // 000000232C08: CC0F4020
	v_mul_i32_i24_e32 v1, 0xe408, v32                          // 000000232C0C: 120240FF 0000E408
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000232C14: BF870214
	v_or_b32_e32 v37, 0x64006400, v50                          // 000000232C18: 384A64FF 64006400
	.long 0xcc0f4026                                           // 000000232C20: CC0F4026
	v_mul_i32_i24_e32 v1, 0xe408, v54                          // 000000232C24: 12026CFF 0000E408
	v_perm_b32 v40, v36, v33, 0xc050c01                        // 000000232C2C: D6440028 03FE4324 0C050C01
	v_fma_mix_f32 v0, v1, v69, v0 op_sel_hi:[1,0,0]            // 000000232C38: CC200000 0C028B01
	v_dot2acc_f32_f16 v57, v32, v39                            // 000000232C40: 04724F20
	.long 0xcc0f4020                                           // 000000232C44: CC0F4020
	v_mul_i32_i24_e32 v1, 0xe408, v37                          // 000000232C48: 12024AFF 0000E408
	v_dot2acc_f32_f16 v58, v38, v41                            // 000000232C50: 04745326
	v_or_b32_e32 v37, 0x64006400, v40                          // 000000232C54: 384A50FF 64006400
	v_perm_b32 v38, v36, v33, 0xc060c02                        // 000000232C5C: D6440026 03FE4324 0C060C02
	v_perm_b32 v33, v36, v33, 0xc070c03                        // 000000232C68: D6440021 03FE4324 0C070C03
	s_waitcnt lgkmcnt(0)                                       // 000000232C74: BF89FC07
	v_dot2acc_f32_f16 v57, v32, v44                            // 000000232C78: 04725920
	v_lshrrev_b32_e32 v32, 4, v34                              // 000000232C7C: 32404484
	.long 0xcc0f4029                                           // 000000232C80: CC0F4029
	v_mul_i32_i24_e32 v1, 0xe408, v37                          // 000000232C84: 12024AFF 0000E408
	v_or_b32_e32 v44, 0x64006400, v38                          // 000000232C8C: 38584CFF 64006400
	v_and_b32_e32 v34, 0xf0f0f0f, v34                          // 000000232C94: 364444FF 0F0F0F0F
	ds_load_b128 v[36:39], v60 offset:3104                     // 000000232C9C: DBFC0C20 2400003C
	v_and_b32_e32 v32, 0xf0f0f0f, v32                          // 000000232CA4: 364040FF 0F0F0F0F
	v_perm_b32 v40, v48, v49, 0xc060c02                        // 000000232CAC: D6440028 03FE6330 0C060C02
	v_dot2acc_f32_f16 v57, v41, v45                            // 000000232CB8: 04725B29
	.long 0xcc0f4029                                           // 000000232CBC: CC0F4029
	v_mul_i32_i24_e32 v1, 0xe408, v44                          // 000000232CC0: 120258FF 0000E408
	v_or_b32_e32 v33, 0x64006400, v33                          // 000000232CC8: 384242FF 64006400
	v_perm_b32 v44, v32, v34, 0xc040c00                        // 000000232CD0: D644002C 03FE4520 0C040C00
	v_or_b32_e32 v40, 0x64006400, v40                          // 000000232CDC: 385050FF 64006400
	v_perm_b32 v45, v48, v49, 0xc070c03                        // 000000232CE4: D644002D 03FE6330 0C070C03
	v_dot2acc_f32_f16 v57, v41, v46                            // 000000232CF0: 04725D29
	.long 0xcc0f4021                                           // 000000232CF4: CC0F4021
	v_mul_i32_i24_e32 v1, 0xe408, v33                          // 000000232CF8: 120242FF 0000E408
	v_or_b32_e32 v41, 0x64006400, v44                          // 000000232D00: 385258FF 64006400
	.long 0xcc0f4028                                           // 000000232D08: CC0F4028
	v_mul_i32_i24_e32 v1, 0xe408, v40                          // 000000232D0C: 120250FF 0000E408
	v_or_b32_e32 v44, 0x64006400, v45                          // 000000232D14: 38585AFF 64006400
	v_perm_b32 v45, v32, v34, 0xc050c01                        // 000000232D1C: D644002D 03FE4520 0C050C01
	v_dot2acc_f32_f16 v57, v33, v47                            // 000000232D28: 04725F21
	.long 0xcc0f4021                                           // 000000232D2C: CC0F4021
	v_mul_i32_i24_e32 v1, 0xe408, v41                          // 000000232D30: 120252FF 0000E408
	v_dot2acc_f32_f16 v58, v40, v42                            // 000000232D38: 04745528
	.long 0xcc0f4028                                           // 000000232D3C: CC0F4028
	v_mul_i32_i24_e32 v1, 0xe408, v44                          // 000000232D40: 120258FF 0000E408
	v_or_b32_e32 v41, 0x64006400, v45                          // 000000232D48: 38525AFF 64006400
	v_perm_b32 v42, v32, v34, 0xc060c02                        // 000000232D50: D644002A 03FE4520 0C060C02
	ds_load_b128 v[44:47], v60 offset:3120                     // 000000232D5C: DBFC0C30 2C00003C
	s_waitcnt lgkmcnt(1)                                       // 000000232D64: BF89FC17
	v_dot2acc_f32_f16 v57, v33, v36                            // 000000232D68: 04724921
	v_lshrrev_b32_e32 v33, 4, v28                              // 000000232D6C: 32423884
	.long 0xcc0f4024                                           // 000000232D70: CC0F4024
	v_mul_i32_i24_e32 v1, 0xe408, v41                          // 000000232D74: 120252FF 0000E408
	v_or_b32_e32 v41, 0x64006400, v42                          // 000000232D7C: 385254FF 64006400
	v_and_b32_e32 v28, 0xf0f0f0f, v28                          // 000000232D84: 363838FF 0F0F0F0F
	ds_load_b128 v[48:51], v60 offset:3328                     // 000000232D8C: DBFC0D00 3000003C
	v_and_b32_e32 v42, 0xf0f0f0f, v33                          // 000000232D94: 365442FF 0F0F0F0F
	v_dot2acc_f32_f16 v58, v40, v43                            // 000000232D9C: 04745728
	v_dot2acc_f32_f16 v57, v36, v37                            // 000000232DA0: 04724B24
	v_perm_b32 v32, v32, v34, 0xc070c03                        // 000000232DA4: D6440020 03FE4520 0C070C03
	.long 0xcc0f4022                                           // 000000232DB0: CC0F4022
	v_mul_i32_i24_e32 v1, 0xe408, v41                          // 000000232DB4: 120252FF 0000E408
	v_perm_b32 v36, v42, v28, 0xc040c00                        // 000000232DBC: D6440024 03FE392A 0C040C00
	v_fma_mix_f32 v0, v1, v58, v0 op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000232DC8: CC200800 0C027501
	v_and_b32_e32 v43, 0xf0f0f0f, v35                          // 000000232DD0: 365646FF 0F0F0F0F
	v_or_b32_e32 v37, 0x64006400, v32                          // 000000232DD8: 384A40FF 64006400
	global_load_b64 v[32:33], v[52:53], off offset:32          // 000000232DE0: DC560020 207C0034
	v_or_b32_e32 v1, 0x64006400, v36                           // 000000232DE8: 380248FF 64006400
	v_dot2acc_f32_f16 v57, v34, v38                            // 000000232DF0: 04724D22
	v_lshrrev_b32_e32 v34, 4, v35                              // 000000232DF4: 32444684
	v_perm_b32 v36, v42, v28, 0xc050c01                        // 000000232DF8: D6440024 03FE392A 0C050C01
	v_mov_b32_e32 v52, 0                                       // 000000232E04: 7E680280
	.long 0xcc0f4001                                           // 000000232E08: CC0F4001
	v_mul_i32_i24_e32 v1, 0xe408, v1                           // 000000232E0C: 120202FF 0000E408
	.long 0xcc0f4026                                           // 000000232E14: CC0F4026
	v_mul_i32_i24_e32 v1, 0xe408, v37                          // 000000232E18: 12024AFF 0000E408
	v_and_b32_e32 v53, 0xf0f0f0f, v34                          // 000000232E20: 366A44FF 0F0F0F0F
	v_or_b32_e32 v40, 0x64006400, v36                          // 000000232E28: 385048FF 64006400
	v_perm_b32 v41, v42, v28, 0xc060c02                        // 000000232E30: D6440029 03FE392A 0C060C02
	ds_load_b128 v[34:37], v60 offset:3344                     // 000000232E3C: DBFC0D10 2200003C
	s_waitcnt lgkmcnt(1)                                       // 000000232E44: BF89FC17
	v_dot2acc_f32_f16 v52, v1, v48                             // 000000232E48: 04686101
	v_lshrrev_b32_e32 v1, 4, v29                               // 000000232E4C: 32023A84
	.long 0xcc0f4028                                           // 000000232E50: CC0F4028
	v_mul_i32_i24_e32 v1, 0xe408, v40                          // 000000232E54: 120250FF 0000E408
	v_or_b32_e32 v41, 0x64006400, v41                          // 000000232E5C: 385252FF 64006400
	v_perm_b32 v28, v42, v28, 0xc070c03                        // 000000232E64: D644001C 03FE392A 0C070C03
	v_and_b32_e32 v29, 0xf0f0f0f, v29                          // 000000232E70: 363A3AFF 0F0F0F0F
	v_and_b32_e32 v1, 0xf0f0f0f, v1                            // 000000232E78: 360202FF 0F0F0F0F
	v_perm_b32 v42, v53, v43, 0xc040c00                        // 000000232E80: D644002A 03FE5735 0C040C00
	v_dot2acc_f32_f16 v52, v40, v49                            // 000000232E8C: 04686328
	.long 0xcc0f4028                                           // 000000232E90: CC0F4028
	v_mul_i32_i24_e32 v1, 0xe408, v41                          // 000000232E94: 120252FF 0000E408
	v_or_b32_e32 v28, 0x64006400, v28                          // 000000232E9C: 383838FF 64006400
	v_perm_b32 v41, v1, v29, 0xc040c00                         // 000000232EA4: D6440029 03FE3B01 0C040C00
	v_or_b32_e32 v42, 0x64006400, v42                          // 000000232EB0: 385454FF 64006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000232EB8: BF870214
	v_dual_dot2acc_f32_f16 v57, v38, v39 :: v_dual_dot2acc_f32_f16 v52, v40, v50// 000000232EBC: CB184F26 39346528
	.long 0xcc0f401c                                           // 000000232EC4: CC0F401C
	v_mul_i32_i24_e32 v1, 0xe408, v28                          // 000000232EC8: 120238FF 0000E408
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000232ED0: BF870214
	v_or_b32_e32 v38, 0x64006400, v41                          // 000000232ED4: 384C52FF 64006400
	.long 0xcc0f4027                                           // 000000232EDC: CC0F4027
	v_mul_i32_i24_e32 v1, 0xe408, v42                          // 000000232EE0: 120254FF 0000E408
	v_perm_b32 v40, v1, v29, 0xc050c01                         // 000000232EE8: D6440028 03FE3B01 0C050C01
	v_perm_b32 v41, v53, v43, 0xc050c01                        // 000000232EF4: D6440029 03FE5735 0C050C01
	v_dot2acc_f32_f16 v52, v28, v51                            // 000000232F00: 0468671C
	.long 0xcc0f401c                                           // 000000232F04: CC0F401C
	v_mul_i32_i24_e32 v1, 0xe408, v38                          // 000000232F08: 12024CFF 0000E408
	v_dot2acc_f32_f16 v57, v39, v44                            // 000000232F10: 04725927
	v_or_b32_e32 v38, 0x64006400, v40                          // 000000232F14: 384C50FF 64006400
	v_perm_b32 v39, v1, v29, 0xc060c02                         // 000000232F1C: D6440027 03FE3B01 0C060C02
	v_or_b32_e32 v42, 0x64006400, v41                          // 000000232F28: 385452FF 64006400
	s_waitcnt lgkmcnt(0)                                       // 000000232F30: BF89FC07
	v_dot2acc_f32_f16 v52, v28, v34                            // 000000232F34: 0468451C
	v_lshrrev_b32_e32 v28, 4, v30                              // 000000232F38: 32383C84
	.long 0xcc0f4022                                           // 000000232F3C: CC0F4022
	v_mul_i32_i24_e32 v1, 0xe408, v38                          // 000000232F40: 12024CFF 0000E408
	v_or_b32_e32 v44, 0x64006400, v39                          // 000000232F48: 38584EFF 64006400
	v_perm_b32 v1, v1, v29, 0xc070c03                          // 000000232F50: D6440001 03FE3B01 0C070C03
	v_and_b32_e32 v29, 0xf0f0f0f, v30                          // 000000232F5C: 363A3CFF 0F0F0F0F
	v_and_b32_e32 v28, 0xf0f0f0f, v28                          // 000000232F64: 363838FF 0F0F0F0F
	ds_load_b128 v[38:41], v60 offset:3360                     // 000000232F6C: DBFC0D20 2600003C
	v_dot2acc_f32_f16 v52, v34, v35                            // 000000232F74: 04684722
	.long 0xcc0f4022                                           // 000000232F78: CC0F4022
	v_mul_i32_i24_e32 v1, 0xe408, v44                          // 000000232F7C: 120258FF 0000E408
	v_or_b32_e32 v1, 0x64006400, v1                            // 000000232F84: 380202FF 64006400
	v_perm_b32 v35, v28, v29, 0xc040c00                        // 000000232F8C: D6440023 03FE3B1C 0C040C00
	.long 0xcc0f402a                                           // 000000232F98: CC0F402A
	v_mul_i32_i24_e32 v1, 0xe408, v42                          // 000000232F9C: 120254FF 0000E408
	v_perm_b32 v30, v53, v43, 0xc060c02                        // 000000232FA4: D644001E 03FE5735 0C060C02
	v_dot2acc_f32_f16 v52, v34, v36                            // 000000232FB0: 04684922
	.long 0xcc0f4001                                           // 000000232FB4: CC0F4001
	v_mul_i32_i24_e32 v1, 0xe408, v1                           // 000000232FB8: 120202FF 0000E408
	v_or_b32_e32 v34, 0x64006400, v35                          // 000000232FC0: 384446FF 64006400
	v_perm_b32 v35, v28, v29, 0xc050c01                        // 000000232FC8: D6440023 03FE3B1C 0C050C01
	v_dot2acc_f32_f16 v57, v42, v45                            // 000000232FD4: 04725B2A
	v_perm_b32 v48, v53, v43, 0xc070c03                        // 000000232FD8: D6440030 03FE5735 0C070C03
	v_dot2acc_f32_f16 v52, v1, v37                             // 000000232FE4: 04684B01
	.long 0xcc0f4001                                           // 000000232FE8: CC0F4001
	v_mul_i32_i24_e32 v1, 0xe408, v34                          // 000000232FEC: 120244FF 0000E408
	v_or_b32_e32 v42, 0x64006400, v35                          // 000000232FF4: 385446FF 64006400
	v_perm_b32 v43, v28, v29, 0xc060c02                        // 000000232FFC: D644002B 03FE3B1C 0C060C02
	ds_load_b128 v[34:37], v60 offset:3376                     // 000000233008: DBFC0D30 2200003C
	v_or_b32_e32 v30, 0x64006400, v30                          // 000000233010: 383C3CFF 64006400
	v_perm_b32 v28, v28, v29, 0xc070c03                        // 000000233018: D644001C 03FE3B1C 0C070C03
	s_waitcnt lgkmcnt(1)                                       // 000000233024: BF89FC17
	v_dot2acc_f32_f16 v52, v1, v38                             // 000000233028: 04684D01
	s_waitcnt vmcnt(6)                                         // 00000023302C: BF891BF7
	v_lshrrev_b32_e32 v1, 4, v16                               // 000000233030: 32022084
	.long 0xcc0f4026                                           // 000000233034: CC0F4026
	v_mul_i32_i24_e32 v1, 0xe408, v42                          // 000000233038: 120254FF 0000E408
	v_or_b32_e32 v49, 0x64006400, v43                          // 000000233040: 386256FF 64006400
	v_and_b32_e32 v16, 0xf0f0f0f, v16                          // 000000233048: 362020FF 0F0F0F0F
	ds_load_b128 v[42:45], v60 offset:3584                     // 000000233050: DBFC0E00 2A00003C
	v_and_b32_e32 v1, 0xf0f0f0f, v1                            // 000000233058: 360202FF 0F0F0F0F
	.long 0xcc0f401e                                           // 000000233060: CC0F401E
	v_mul_i32_i24_e32 v1, 0xe408, v30                          // 000000233064: 12023CFF 0000E408
	v_or_b32_e32 v29, 0x64006400, v48                          // 00000023306C: 383A60FF 64006400
	v_dot2acc_f32_f16 v52, v38, v39                            // 000000233074: 04684F26
	.long 0xcc0f4026                                           // 000000233078: CC0F4026
	v_mul_i32_i24_e32 v1, 0xe408, v49                          // 00000023307C: 120262FF 0000E408
	v_perm_b32 v39, v1, v16, 0xc040c00                         // 000000233084: D6440027 03FE2101 0C040C00
	v_or_b32_e32 v28, 0x64006400, v28                          // 000000233090: 383838FF 64006400
	v_dot2acc_f32_f16 v57, v30, v46                            // 000000233098: 04725D1E
	.long 0xcc0f402e                                           // 00000023309C: CC0F402E
	v_mul_i32_i24_e32 v1, 0xe408, v29                          // 0000002330A0: 12023AFF 0000E408
	v_dot2acc_f32_f16 v52, v38, v40                            // 0000002330A8: 04685126
	v_or_b32_e32 v29, 0x64006400, v39                          // 0000002330AC: 383A4EFF 64006400
	.long 0xcc0f4026                                           // 0000002330B4: CC0F4026
	v_mul_i32_i24_e32 v1, 0xe408, v28                          // 0000002330B8: 120238FF 0000E408
	v_lshrrev_b32_e32 v28, 4, v31                              // 0000002330C0: 32383E84
	v_perm_b32 v30, v1, v16, 0xc050c01                         // 0000002330C4: D644001E 03FE2101 0C050C01
	v_mov_b32_e32 v49, 0                                       // 0000002330D0: 7E620280
	.long 0xcc0f4027                                           // 0000002330D4: CC0F4027
	v_mul_i32_i24_e32 v1, 0xe408, v29                          // 0000002330D8: 12023AFF 0000E408
	v_and_b32_e32 v48, 0xf0f0f0f, v31                          // 0000002330E0: 36603EFF 0F0F0F0F
	v_and_b32_e32 v50, 0xf0f0f0f, v28                          // 0000002330E8: 366438FF 0F0F0F0F
	v_or_b32_e32 v40, 0x64006400, v30                          // 0000002330F0: 38503CFF 64006400
	v_perm_b32 v51, v1, v16, 0xc060c02                         // 0000002330F8: D6440033 03FE2101 0C060C02
	ds_load_b128 v[28:31], v60 offset:3600                     // 000000233104: DBFC0E10 1C00003C
	s_waitcnt lgkmcnt(1)                                       // 00000023310C: BF89FC17
	v_dot2acc_f32_f16 v49, v39, v42                            // 000000233110: 04625527
	v_lshrrev_b32_e32 v39, 4, v17                              // 000000233114: 324E2284
	.long 0xcc0f4028                                           // 000000233118: CC0F4028
	v_mul_i32_i24_e32 v1, 0xe408, v40                          // 00000023311C: 120250FF 0000E408
	v_or_b32_e32 v42, 0x64006400, v51                          // 000000233124: 385466FF 64006400
	v_perm_b32 v1, v1, v16, 0xc070c03                          // 00000023312C: D6440001 03FE2101 0C070C03
	v_and_b32_e32 v16, 0xf0f0f0f, v17                          // 000000233138: 362022FF 0F0F0F0F
	v_and_b32_e32 v17, 0xf0f0f0f, v39                          // 000000233140: 36224EFF 0F0F0F0F
	v_perm_b32 v39, v50, v48, 0xc040c00                        // 000000233148: D6440027 03FE6132 0C040C00
	v_dot2acc_f32_f16 v49, v40, v43                            // 000000233154: 04625728
	.long 0xcc0f4028                                           // 000000233158: CC0F4028
	v_mul_i32_i24_e32 v1, 0xe408, v42                          // 00000023315C: 120254FF 0000E408
	v_or_b32_e32 v1, 0x64006400, v1                            // 000000233164: 380202FF 64006400
	v_perm_b32 v42, v17, v16, 0xc040c00                        // 00000023316C: D644002A 03FE2111 0C040C00
	v_or_b32_e32 v39, 0x64006400, v39                          // 000000233178: 384E4EFF 64006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000233180: BF870214
	v_dual_dot2acc_f32_f16 v52, v38, v41 :: v_dual_dot2acc_f32_f16 v49, v40, v44// 000000233184: CB185326 34305928
	.long 0xcc0f4001                                           // 00000023318C: CC0F4001
	v_mul_i32_i24_e32 v1, 0xe408, v1                           // 000000233190: 120202FF 0000E408
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000233198: BF870214
	v_or_b32_e32 v38, 0x64006400, v42                          // 00000023319C: 384C54FF 64006400
	.long 0xcc0f4027                                           // 0000002331A4: CC0F4027
	v_mul_i32_i24_e32 v1, 0xe408, v39                          // 0000002331A8: 12024EFF 0000E408
	v_perm_b32 v40, v17, v16, 0xc050c01                        // 0000002331B0: D6440028 03FE2111 0C050C01
	v_perm_b32 v42, v50, v48, 0xc050c01                        // 0000002331BC: D644002A 03FE6132 0C050C01
	v_dot2acc_f32_f16 v49, v1, v45                             // 0000002331C8: 04625B01
	.long 0xcc0f4001                                           // 0000002331CC: CC0F4001
	v_mul_i32_i24_e32 v1, 0xe408, v38                          // 0000002331D0: 12024CFF 0000E408
	v_dot2acc_f32_f16 v52, v39, v34                            // 0000002331D8: 04684527
	v_or_b32_e32 v34, 0x64006400, v40                          // 0000002331DC: 384450FF 64006400
	v_perm_b32 v38, v17, v16, 0xc060c02                        // 0000002331E4: D6440026 03FE2111 0C060C02
	v_perm_b32 v16, v17, v16, 0xc070c03                        // 0000002331F0: D6440010 03FE2111 0C070C03
	s_waitcnt lgkmcnt(0)                                       // 0000002331FC: BF89FC07
	v_dot2acc_f32_f16 v49, v1, v28                             // 000000233200: 04623901
	v_lshrrev_b32_e32 v1, 4, v18                               // 000000233204: 32022484
	.long 0xcc0f401c                                           // 000000233208: CC0F401C
	v_mul_i32_i24_e32 v1, 0xe408, v34                          // 00000023320C: 120244FF 0000E408
	v_or_b32_e32 v34, 0x64006400, v38                          // 000000233214: 38444CFF 64006400
	v_and_b32_e32 v17, 0xf0f0f0f, v18                          // 00000023321C: 362224FF 0F0F0F0F
	ds_load_b128 v[38:41], v60 offset:3616                     // 000000233224: DBFC0E20 2600003C
	v_and_b32_e32 v1, 0xf0f0f0f, v1                            // 00000023322C: 360202FF 0F0F0F0F
	v_or_b32_e32 v18, 0x64006400, v42                          // 000000233234: 382454FF 64006400
	v_dot2acc_f32_f16 v49, v28, v29                            // 00000023323C: 04623B1C
	.long 0xcc0f401c                                           // 000000233240: CC0F401C
	v_mul_i32_i24_e32 v1, 0xe408, v34                          // 000000233244: 120244FF 0000E408
	v_or_b32_e32 v16, 0x64006400, v16                          // 00000023324C: 382020FF 64006400
	v_perm_b32 v29, v1, v17, 0xc040c00                         // 000000233254: D644001D 03FE2301 0C040C00
	.long 0xcc0f4012                                           // 000000233260: CC0F4012
	v_mul_i32_i24_e32 v1, 0xe408, v18                          // 000000233264: 120224FF 0000E408
	v_perm_b32 v34, v50, v48, 0xc060c02                        // 00000023326C: D6440022 03FE6132 0C060C02
	v_dot2acc_f32_f16 v49, v28, v30                            // 000000233278: 04623D1C
	.long 0xcc0f4010                                           // 00000023327C: CC0F4010
	v_mul_i32_i24_e32 v1, 0xe408, v16                          // 000000233280: 120220FF 0000E408
	v_or_b32_e32 v28, 0x64006400, v29                          // 000000233288: 38383AFF 64006400
	v_perm_b32 v29, v1, v17, 0xc050c01                         // 000000233290: D644001D 03FE2301 0C050C01
	v_or_b32_e32 v30, 0x64006400, v34                          // 00000023329C: 383C44FF 64006400
	v_dot2acc_f32_f16 v52, v18, v35                            // 0000002332A4: 04684712
	v_dot2acc_f32_f16 v49, v16, v31                            // 0000002332A8: 04623F10
	.long 0xcc0f4010                                           // 0000002332AC: CC0F4010
	v_mul_i32_i24_e32 v1, 0xe408, v28                          // 0000002332B0: 120238FF 0000E408
	v_or_b32_e32 v18, 0x64006400, v29                          // 0000002332B8: 38243AFF 64006400
	.long 0xcc0f4022                                           // 0000002332C0: CC0F4022
	v_mul_i32_i24_e32 v1, 0xe408, v30                          // 0000002332C4: 12023CFF 0000E408
	ds_load_b128 v[28:31], v60 offset:3632                     // 0000002332CC: DBFC0E30 1C00003C
	v_perm_b32 v35, v50, v48, 0xc070c03                        // 0000002332D4: D6440023 03FE6132 0C070C03
	s_waitcnt lgkmcnt(1)                                       // 0000002332E0: BF89FC17
	v_dot2acc_f32_f16 v49, v16, v38                            // 0000002332E4: 04624D10
	.long 0xcc0f4010                                           // 0000002332E8: CC0F4010
	v_mul_i32_i24_e32 v1, 0xe408, v18                          // 0000002332EC: 120224FF 0000E408
	v_perm_b32 v18, v1, v17, 0xc060c02                         // 0000002332F4: D6440012 03FE2301 0C060C02
	v_dot2acc_f32_f16 v52, v34, v36                            // 000000233300: 04684922
	v_or_b32_e32 v34, 0x64006400, v35                          // 000000233304: 384446FF 64006400
	v_perm_b32 v1, v1, v17, 0xc070c03                          // 00000023330C: D6440001 03FE2301 0C070C03
	v_dot2acc_f32_f16 v49, v16, v39                            // 000000233318: 04624F10
	s_waitcnt vmcnt(5)                                         // 00000023331C: BF8917F7
	v_lshrrev_b32_e32 v16, 4, v4                               // 000000233320: 32200884
	v_or_b32_e32 v35, 0x64006400, v18                          // 000000233324: 384624FF 64006400
	v_lshrrev_b32_e32 v36, 4, v19                              // 00000023332C: 32482684
	v_and_b32_e32 v38, 0xf0f0f0f, v19                          // 000000233330: 364C26FF 0F0F0F0F
	v_and_b32_e32 v4, 0xf0f0f0f, v4                            // 000000233338: 360808FF 0F0F0F0F
	v_and_b32_e32 v39, 0xf0f0f0f, v16                          // 000000233340: 364E20FF 0F0F0F0F
	ds_load_b128 v[16:19], v60 offset:3840                     // 000000233348: DBFC0F00 1000003C
	v_and_b32_e32 v42, 0xf0f0f0f, v36                          // 000000233350: 365448FF 0F0F0F0F
	.long 0xcc0f4023                                           // 000000233358: CC0F4023
	v_mul_i32_i24_e32 v1, 0xe408, v35                          // 00000023335C: 120246FF 0000E408
	v_or_b32_e32 v1, 0x64006400, v1                            // 000000233364: 380202FF 64006400
	v_perm_b32 v36, v39, v4, 0xc040c00                         // 00000023336C: D6440024 03FE0927 0C040C00
	.long 0xcc0f4022                                           // 000000233378: CC0F4022
	v_mul_i32_i24_e32 v1, 0xe408, v34                          // 00000023337C: 120244FF 0000E408
	v_perm_b32 v43, v42, v38, 0xc040c00                        // 000000233384: D644002B 03FE4D2A 0C040C00
	v_dot2acc_f32_f16 v49, v35, v40                            // 000000233390: 04625123
	.long 0xcc0f4001                                           // 000000233394: CC0F4001
	v_mul_i32_i24_e32 v1, 0xe408, v1                           // 000000233398: 120202FF 0000E408
	v_or_b32_e32 v35, 0x64006400, v36                          // 0000002333A0: 384648FF 64006400
	v_dot2acc_f32_f16 v52, v34, v37                            // 0000002333A8: 04684B22
	v_or_b32_e32 v34, 0x64006400, v43                          // 0000002333AC: 384456FF 64006400
	v_perm_b32 v36, v39, v4, 0xc050c01                         // 0000002333B4: D6440024 03FE0927 0C050C01
	v_dot2acc_f32_f16 v49, v1, v41                             // 0000002333C0: 04625301
	.long 0xcc0f4001                                           // 0000002333C4: CC0F4001
	v_mul_i32_i24_e32 v1, 0xe408, v35                          // 0000002333C8: 120246FF 0000E408
	v_mov_b32_e32 v43, 0                                       // 0000002333D0: 7E560280
	.long 0xcc0f4028                                           // 0000002333D4: CC0F4028
	v_mul_i32_i24_e32 v1, 0xe408, v34                          // 0000002333D8: 120244FF 0000E408
	v_or_b32_e32 v41, 0x64006400, v36                          // 0000002333E0: 385248FF 64006400
	v_perm_b32 v44, v39, v4, 0xc060c02                         // 0000002333E8: D644002C 03FE0927 0C060C02
	ds_load_b128 v[34:37], v60 offset:3856                     // 0000002333F4: DBFC0F10 2200003C
	s_waitcnt lgkmcnt(1)                                       // 0000002333FC: BF89FC17
	v_dot2acc_f32_f16 v43, v1, v16                             // 000000233400: 04562101
	v_lshrrev_b32_e32 v1, 4, v5                                // 000000233404: 32020A84
	.long 0xcc0f4010                                           // 000000233408: CC0F4010
	v_mul_i32_i24_e32 v1, 0xe408, v41                          // 00000023340C: 120252FF 0000E408
	v_or_b32_e32 v41, 0x64006400, v44                          // 000000233414: 385258FF 64006400
	v_perm_b32 v4, v39, v4, 0xc070c03                          // 00000023341C: D6440004 03FE0927 0C070C03
	v_and_b32_e32 v5, 0xf0f0f0f, v5                            // 000000233428: 360A0AFF 0F0F0F0F
	v_and_b32_e32 v1, 0xf0f0f0f, v1                            // 000000233430: 360202FF 0F0F0F0F
	v_dot2acc_f32_f16 v57, v46, v47                            // 000000233438: 04725F2E
	v_dot2acc_f32_f16 v43, v16, v17                            // 00000023343C: 04562310
	.long 0xcc0f4010                                           // 000000233440: CC0F4010
	v_mul_i32_i24_e32 v1, 0xe408, v41                          // 000000233444: 120252FF 0000E408
	v_or_b32_e32 v4, 0x64006400, v4                            // 00000023344C: 380808FF 64006400
	v_perm_b32 v17, v1, v5, 0xc040c00                          // 000000233454: D6440011 03FE0B01 0C040C00
	v_fma_mix_f32 v0, v2, v57, v0 op_sel_hi:[1,0,0]            // 000000233460: CC200000 0C027302
	v_perm_b32 v39, v42, v38, 0xc050c01                        // 000000233468: D6440027 03FE4D2A 0C050C01
	v_dot2acc_f32_f16 v43, v16, v18                            // 000000233474: 04562510
	.long 0xcc0f4004                                           // 000000233478: CC0F4004
	v_mul_i32_i24_e32 v1, 0xe408, v4                           // 00000023347C: 120208FF 0000E408
	v_or_b32_e32 v16, 0x64006400, v17                          // 000000233484: 382022FF 64006400
	v_perm_b32 v18, v1, v5, 0xc050c01                          // 00000023348C: D6440012 03FE0B01 0C050C01
	v_or_b32_e32 v39, 0x64006400, v39                          // 000000233498: 384E4EFF 64006400
	v_fma_mix_f32 v2, v2, v52, v0 op_sel:[1,0,0] op_sel_hi:[1,0,0]// 0000002334A0: CC200802 0C026902
	v_dot2acc_f32_f16 v43, v4, v19                             // 0000002334A8: 04562704
	.long 0xcc0f4000                                           // 0000002334AC: CC0F4000
	v_mul_i32_i24_e32 v1, 0xe408, v16                          // 0000002334B0: 120220FF 0000E408
	v_dot2acc_f32_f16 v49, v40, v28                            // 0000002334B8: 04623928
	.long 0xcc0f4011                                           // 0000002334BC: CC0F4011
	v_mul_i32_i24_e32 v1, 0xe408, v39                          // 0000002334C0: 12024EFF 0000E408
	v_or_b32_e32 v4, 0x64006400, v18                           // 0000002334C8: 380824FF 64006400
	v_perm_b32 v16, v1, v5, 0xc060c02                          // 0000002334D0: D6440010 03FE0B01 0C060C02
	s_waitcnt lgkmcnt(0)                                       // 0000002334DC: BF89FC07
	v_dot2acc_f32_f16 v43, v0, v34                             // 0000002334E0: 04564500
	v_lshrrev_b32_e32 v0, 4, v6                                // 0000002334E4: 32000C84
	v_dot2acc_f32_f16 v49, v17, v29                            // 0000002334E8: 04623B11
	v_perm_b32 v28, v42, v38, 0xc060c02                        // 0000002334EC: D644001C 03FE4D2A 0C060C02
	.long 0xcc0f4004                                           // 0000002334F8: CC0F4004
	v_mul_i32_i24_e32 v1, 0xe408, v4                           // 0000002334FC: 120208FF 0000E408
	v_or_b32_e32 v29, 0x64006400, v16                          // 000000233504: 383A20FF 64006400
	v_perm_b32 v1, v1, v5, 0xc070c03                           // 00000023350C: D6440001 03FE0B01 0C070C03
	v_and_b32_e32 v5, 0xf0f0f0f, v6                            // 000000233518: 360A0CFF 0F0F0F0F
	v_and_b32_e32 v0, 0xf0f0f0f, v0                            // 000000233520: 360000FF 0F0F0F0F
	ds_load_b128 v[16:19], v60 offset:3872                     // 000000233528: DBFC0F20 1000003C
	v_or_b32_e32 v6, 0x64006400, v28                           // 000000233530: 380C38FF 64006400
	v_dot2acc_f32_f16 v43, v4, v35                             // 000000233538: 04564704
	.long 0xcc0f4004                                           // 00000023353C: CC0F4004
	v_mul_i32_i24_e32 v1, 0xe408, v29                          // 000000233540: 12023AFF 0000E408
	v_or_b32_e32 v1, 0x64006400, v1                            // 000000233548: 380202FF 64006400
	v_perm_b32 v28, v0, v5, 0xc040c00                          // 000000233550: D644001C 03FE0B00 0C040C00
	v_perm_b32 v29, v42, v38, 0xc070c03                        // 00000023355C: D644001D 03FE4D2A 0C070C03
	.long 0xcc0f4006                                           // 000000233568: CC0F4006
	v_mul_i32_i24_e32 v1, 0xe408, v6                           // 00000023356C: 12020CFF 0000E408
	v_dot2acc_f32_f16 v43, v4, v36                             // 000000233574: 04564904
	.long 0xcc0f4001                                           // 000000233578: CC0F4001
	v_mul_i32_i24_e32 v1, 0xe408, v1                           // 00000023357C: 120202FF 0000E408
	v_or_b32_e32 v4, 0x64006400, v28                           // 000000233584: 380838FF 64006400
	v_or_b32_e32 v28, 0x64006400, v29                          // 00000023358C: 38383AFF 64006400
	v_perm_b32 v29, v0, v5, 0xc050c01                          // 000000233594: D644001D 03FE0B00 0C050C01
	v_dot2acc_f32_f16 v49, v6, v30                             // 0000002335A0: 04623D06
	v_dot2acc_f32_f16 v43, v1, v37                             // 0000002335A4: 04564B01
	.long 0xcc0f4001                                           // 0000002335A8: CC0F4001
	v_mul_i32_i24_e32 v1, 0xe408, v4                           // 0000002335AC: 120208FF 0000E408
	.long 0xcc0f4004                                           // 0000002335B4: CC0F4004
	v_mul_i32_i24_e32 v1, 0xe408, v28                          // 0000002335B8: 120238FF 0000E408
	v_or_b32_e32 v6, 0x64006400, v29                           // 0000002335C0: 380C3AFF 64006400
	v_perm_b32 v28, v0, v5, 0xc060c02                          // 0000002335C8: D644001C 03FE0B00 0C060C02
	ds_load_b128 v[34:37], v60 offset:3888                     // 0000002335D4: DBFC0F30 2200003C
	s_waitcnt lgkmcnt(1)                                       // 0000002335DC: BF89FC17
	v_dot2acc_f32_f16 v43, v1, v16                             // 0000002335E0: 04562101
	s_waitcnt vmcnt(4)                                         // 0000002335E4: BF8913F7
	v_lshrrev_b32_e32 v1, 4, v24                               // 0000002335E8: 32023084
	.long 0xcc0f4006                                           // 0000002335EC: CC0F4006
	v_mul_i32_i24_e32 v1, 0xe408, v6                           // 0000002335F0: 12020CFF 0000E408
	v_or_b32_e32 v16, 0x64006400, v28                          // 0000002335F8: 382038FF 64006400
	v_and_b32_e32 v24, 0xf0f0f0f, v24                          // 000000233600: 363030FF 0F0F0F0F
	ds_load_b128 v[38:41], v60 offset:4096                     // 000000233608: DBFC1000 2600003C
	v_and_b32_e32 v1, 0xf0f0f0f, v1                            // 000000233610: 360202FF 0F0F0F0F
	v_perm_b32 v0, v0, v5, 0xc070c03                           // 000000233618: D6440000 03FE0B00 0C070C03
	v_dot2acc_f32_f16 v49, v4, v31                             // 000000233624: 04623F04
	v_dot2acc_f32_f16 v43, v6, v17                             // 000000233628: 04562306
	.long 0xcc0f4004                                           // 00000023362C: CC0F4004
	v_mul_i32_i24_e32 v1, 0xe408, v16                          // 000000233630: 120220FF 0000E408
	v_perm_b32 v5, v1, v24, 0xc040c00                          // 000000233638: D6440005 03FE3101 0C040C00
	v_or_b32_e32 v6, 0x64006400, v0                            // 000000233644: 380C00FF 64006400
	v_mov_b32_e32 v42, 0                                       // 00000023364C: 7E540280
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000233650: BF870214
	v_dual_dot2acc_f32_f16 v43, v4, v18 :: v_dual_and_b32 v28, 0xf0f0f0f, v7// 000000233654: CB242504 2B1C0EFF 0F0F0F0F
	v_or_b32_e32 v4, 0x64006400, v5                            // 000000233660: 38080AFF 64006400
	s_delay_alu instid0(VALU_DEP_4)                            // 000000233668: BF870004
	.long 0xcc0f4010                                           // 00000023366C: CC0F4010
	v_mul_i32_i24_e32 v1, 0xe408, v6                           // 000000233670: 12020CFF 0000E408
	v_lshrrev_b32_e32 v5, 4, v7                                // 000000233678: 320A0E84
	v_perm_b32 v6, v1, v24, 0xc050c01                          // 00000023367C: D6440006 03FE3101 0C050C01
	v_perm_b32 v30, v1, v24, 0xc060c02                         // 000000233688: D644001E 03FE3101 0C060C02
	.long 0xcc0f4011                                           // 000000233694: CC0F4011
	v_mul_i32_i24_e32 v1, 0xe408, v4                           // 000000233698: 120208FF 0000E408
	v_perm_b32 v1, v1, v24, 0xc070c03                          // 0000002336A0: D6440001 03FE3101 0C070C03
	v_and_b32_e32 v29, 0xf0f0f0f, v5                           // 0000002336AC: 363A0AFF 0F0F0F0F
	v_or_b32_e32 v18, 0x64006400, v6                           // 0000002336B4: 38240CFF 64006400
	ds_load_b128 v[4:7], v60 offset:4112                       // 0000002336BC: DBFC1010 0400003C
	s_waitcnt lgkmcnt(1)                                       // 0000002336C4: BF89FC17
	v_dot2acc_f32_f16 v42, v17, v38                            // 0000002336C8: 04544D11
	v_lshrrev_b32_e32 v17, 4, v25                              // 0000002336CC: 32223284
	v_or_b32_e32 v30, 0x64006400, v30                          // 0000002336D0: 383C3CFF 64006400
	.long 0xcc0f4012                                           // 0000002336D8: CC0F4012
	v_mul_i32_i24_e32 v1, 0xe408, v18                          // 0000002336DC: 120224FF 0000E408
	v_and_b32_e32 v24, 0xf0f0f0f, v25                          // 0000002336E4: 363032FF 0F0F0F0F
	v_perm_b32 v25, v29, v28, 0xc040c00                        // 0000002336EC: D6440019 03FE391D 0C040C00
	v_and_b32_e32 v17, 0xf0f0f0f, v17                          // 0000002336F8: 362222FF 0F0F0F0F
	v_or_b32_e32 v1, 0x64006400, v1                            // 000000233700: 380202FF 64006400
	v_dot2acc_f32_f16 v42, v18, v39                            // 000000233708: 04544F12
	.long 0xcc0f4012                                           // 00000023370C: CC0F4012
	v_mul_i32_i24_e32 v1, 0xe408, v30                          // 000000233710: 12023CFF 0000E408
	v_or_b32_e32 v25, 0x64006400, v25                          // 000000233718: 383232FF 64006400
	v_perm_b32 v30, v17, v24, 0xc040c00                        // 000000233720: D644001E 03FE3111 0C040C00
	v_dot2acc_f32_f16 v43, v16, v19                            // 00000023372C: 04562710
	.long 0xcc0f4001                                           // 000000233730: CC0F4001
	v_mul_i32_i24_e32 v1, 0xe408, v1                           // 000000233734: 120202FF 0000E408
	v_dot2acc_f32_f16 v42, v18, v40                            // 00000023373C: 04545112
	.long 0xcc0f4012                                           // 000000233740: CC0F4012
	v_mul_i32_i24_e32 v1, 0xe408, v25                          // 000000233744: 120232FF 0000E408
	v_or_b32_e32 v16, 0x64006400, v30                          // 00000023374C: 38203CFF 64006400
	v_perm_b32 v19, v17, v24, 0xc050c01                        // 000000233754: D6440013 03FE3111 0C050C01
	v_perm_b32 v25, v29, v28, 0xc050c01                        // 000000233760: D6440019 03FE391D 0C050C01
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000023376C: BF870214
	v_dual_dot2acc_f32_f16 v42, v1, v41 :: v_dual_dot2acc_f32_f16 v43, v18, v34// 000000233770: CB185301 2A2A4512
	.long 0xcc0f4001                                           // 000000233778: CC0F4001
	v_mul_i32_i24_e32 v1, 0xe408, v16                          // 00000023377C: 120220FF 0000E408
	s_delay_alu instid0(VALU_DEP_4)                            // 000000233784: BF870004
	v_or_b32_e32 v16, 0x64006400, v19                          // 000000233788: 382026FF 64006400
	v_perm_b32 v18, v17, v24, 0xc060c02                        // 000000233790: D6440012 03FE3111 0C060C02
	v_perm_b32 v24, v17, v24, 0xc070c03                        // 00000023379C: D6440018 03FE3111 0C070C03
	v_or_b32_e32 v25, 0x64006400, v25                          // 0000002337A8: 383232FF 64006400
	s_waitcnt lgkmcnt(0)                                       // 0000002337B0: BF89FC07
	v_dot2acc_f32_f16 v42, v1, v4                              // 0000002337B4: 04540901
	v_lshrrev_b32_e32 v1, 4, v26                               // 0000002337B8: 32023484
	.long 0xcc0f4004                                           // 0000002337BC: CC0F4004
	v_mul_i32_i24_e32 v1, 0xe408, v16                          // 0000002337C0: 120220FF 0000E408
	v_or_b32_e32 v30, 0x64006400, v18                          // 0000002337C8: 383C24FF 64006400
	v_and_b32_e32 v26, 0xf0f0f0f, v26                          // 0000002337D0: 363434FF 0F0F0F0F
	ds_load_b128 v[16:19], v60 offset:4128                     // 0000002337D8: DBFC1020 1000003C
	v_and_b32_e32 v1, 0xf0f0f0f, v1                            // 0000002337E0: 360202FF 0F0F0F0F
	v_dot2acc_f32_f16 v42, v4, v5                              // 0000002337E8: 04540B04
	.long 0xcc0f4004                                           // 0000002337EC: CC0F4004
	v_mul_i32_i24_e32 v1, 0xe408, v30                          // 0000002337F0: 12023CFF 0000E408
	v_or_b32_e32 v5, 0x64006400, v24                           // 0000002337F8: 380A30FF 64006400
	.long 0xcc0f4019                                           // 000000233800: CC0F4019
	v_mul_i32_i24_e32 v1, 0xe408, v25                          // 000000233804: 120232FF 0000E408
	v_perm_b32 v24, v1, v26, 0xc040c00                         // 00000023380C: D6440018 03FE3501 0C040C00
	v_perm_b32 v31, v29, v28, 0xc060c02                        // 000000233818: D644001F 03FE391D 0C060C02
	v_dot2acc_f32_f16 v42, v4, v6                              // 000000233824: 04540D04
	.long 0xcc0f4004                                           // 000000233828: CC0F4004
	v_mul_i32_i24_e32 v1, 0xe408, v5                           // 00000023382C: 12020AFF 0000E408
	v_dot2acc_f32_f16 v43, v25, v35                            // 000000233834: 04564719
	v_or_b32_e32 v5, 0x64006400, v24                           // 000000233838: 380A30FF 64006400
	v_perm_b32 v6, v1, v26, 0xc050c01                          // 000000233840: D6440006 03FE3501 0C050C01
	v_or_b32_e32 v30, 0x64006400, v31                          // 00000023384C: 383C3EFF 64006400
	v_dot2acc_f32_f16 v42, v4, v7                              // 000000233854: 04540F04
	v_perm_b32 v34, v29, v28, 0xc070c03                        // 000000233858: D6440022 03FE391D 0C070C03
	.long 0xcc0f4019                                           // 000000233864: CC0F4019
	v_mul_i32_i24_e32 v1, 0xe408, v5                           // 000000233868: 12020AFF 0000E408
	v_or_b32_e32 v28, 0x64006400, v6                           // 000000233870: 38380CFF 64006400
	v_perm_b32 v29, v1, v26, 0xc060c02                         // 000000233878: D644001D 03FE3501 0C060C02
	ds_load_b128 v[4:7], v60 offset:4144                       // 000000233884: DBFC1030 0400003C
	.long 0xcc0f4018                                           // 00000023388C: CC0F4018
	v_mul_i32_i24_e32 v1, 0xe408, v30                          // 000000233890: 12023CFF 0000E408
	s_waitcnt lgkmcnt(1)                                       // 000000233898: BF89FC17
	v_dot2acc_f32_f16 v42, v25, v16                            // 00000023389C: 04542119
	s_waitcnt vmcnt(3)                                         // 0000002338A0: BF890FF7
	v_lshrrev_b32_e32 v16, 4, v8                               // 0000002338A4: 32201084
	.long 0xcc0f4019                                           // 0000002338A8: CC0F4019
	v_mul_i32_i24_e32 v1, 0xe408, v28                          // 0000002338AC: 120238FF 0000E408
	v_or_b32_e32 v35, 0x64006400, v29                          // 0000002338B4: 38463AFF 64006400
	v_and_b32_e32 v8, 0xf0f0f0f, v8                            // 0000002338BC: 361010FF 0F0F0F0F
	ds_load_b128 v[28:31], v60 offset:4352                     // 0000002338C4: DBFC1100 1C00003C
	v_and_b32_e32 v16, 0xf0f0f0f, v16                          // 0000002338CC: 362020FF 0F0F0F0F
	v_dot2acc_f32_f16 v42, v25, v17                            // 0000002338D4: 04542319
	.long 0xcc0f4011                                           // 0000002338D8: CC0F4011
	v_mul_i32_i24_e32 v1, 0xe408, v35                          // 0000002338DC: 120246FF 0000E408
	v_perm_b32 v1, v1, v26, 0xc070c03                          // 0000002338E4: D6440001 03FE3501 0C070C03
	v_or_b32_e32 v26, 0x64006400, v34                          // 0000002338F0: 383444FF 64006400
	v_perm_b32 v25, v16, v8, 0xc040c00                         // 0000002338F8: D6440019 03FE1110 0C040C00
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000233904: BF870234
	v_dual_dot2acc_f32_f16 v43, v24, v36 :: v_dual_dot2acc_f32_f16 v42, v17, v18// 000000233908: CB184918 2B2A2511
	v_lshrrev_b32_e32 v18, 4, v27                              // 000000233910: 32243684
	v_perm_b32 v24, v16, v8, 0xc050c01                         // 000000233914: D6440018 03FE1110 0C050C01
	v_or_b32_e32 v17, 0x64006400, v25                          // 000000233920: 382232FF 64006400
	v_mov_b32_e32 v36, 0                                       // 000000233928: 7E480280
	.long 0xcc0f4022                                           // 00000023392C: CC0F4022
	v_mul_i32_i24_e32 v1, 0xe408, v26                          // 000000233930: 120234FF 0000E408
	v_and_b32_e32 v35, 0xf0f0f0f, v27                          // 000000233938: 364636FF 0F0F0F0F
	v_and_b32_e32 v38, 0xf0f0f0f, v18                          // 000000233940: 364C24FF 0F0F0F0F
	.long 0xcc0f4011                                           // 000000233948: CC0F4011
	v_mul_i32_i24_e32 v1, 0xe408, v17                          // 00000023394C: 120222FF 0000E408
	v_or_b32_e32 v18, 0x64006400, v24                          // 000000233954: 382430FF 64006400
	v_perm_b32 v39, v16, v8, 0xc060c02                         // 00000023395C: D6440027 03FE1110 0C060C02
	ds_load_b128 v[24:27], v60 offset:4368                     // 000000233968: DBFC1110 1800003C
	v_or_b32_e32 v1, 0x64006400, v1                            // 000000233970: 380202FF 64006400
	s_waitcnt lgkmcnt(1)                                       // 000000233978: BF89FC17
	v_dot2acc_f32_f16 v36, v17, v28                            // 00000023397C: 04483911
	v_lshrrev_b32_e32 v17, 4, v9                               // 000000233980: 32221284
	.long 0xcc0f4012                                           // 000000233984: CC0F4012
	v_mul_i32_i24_e32 v1, 0xe408, v18                          // 000000233988: 120224FF 0000E408
	v_or_b32_e32 v28, 0x64006400, v39                          // 000000233990: 38384EFF 64006400
	v_perm_b32 v8, v16, v8, 0xc070c03                          // 000000233998: D6440008 03FE1110 0C070C03
	v_and_b32_e32 v9, 0xf0f0f0f, v9                            // 0000002339A4: 361212FF 0F0F0F0F
	v_and_b32_e32 v16, 0xf0f0f0f, v17                          // 0000002339AC: 362022FF 0F0F0F0F
	.long 0xcc0f4001                                           // 0000002339B4: CC0F4001
	v_mul_i32_i24_e32 v1, 0xe408, v1                           // 0000002339B8: 120202FF 0000E408
	v_perm_b32 v17, v38, v35, 0xc040c00                        // 0000002339C0: D6440011 03FE4726 0C040C00
	v_dot2acc_f32_f16 v36, v18, v29                            // 0000002339CC: 04483B12
	.long 0xcc0f4012                                           // 0000002339D0: CC0F4012
	v_mul_i32_i24_e32 v1, 0xe408, v28                          // 0000002339D4: 120238FF 0000E408
	v_or_b32_e32 v8, 0x64006400, v8                            // 0000002339DC: 381010FF 64006400
	v_perm_b32 v28, v16, v9, 0xc040c00                         // 0000002339E4: D644001C 03FE1310 0C040C00
	v_or_b32_e32 v17, 0x64006400, v17                          // 0000002339F0: 382222FF 64006400
	v_dot2acc_f32_f16 v42, v1, v19                             // 0000002339F8: 04542701
	v_dot2acc_f32_f16 v36, v18, v30                            // 0000002339FC: 04483D12
	.long 0xcc0f4001                                           // 000000233A00: CC0F4001
	v_mul_i32_i24_e32 v1, 0xe408, v8                           // 000000233A04: 120210FF 0000E408
	v_or_b32_e32 v8, 0x64006400, v28                           // 000000233A0C: 381038FF 64006400
	.long 0xcc0f4011                                           // 000000233A14: CC0F4011
	v_mul_i32_i24_e32 v1, 0xe408, v17                          // 000000233A18: 120222FF 0000E408
	v_perm_b32 v18, v16, v9, 0xc050c01                         // 000000233A20: D6440012 03FE1310 0C050C01
	v_perm_b32 v28, v38, v35, 0xc050c01                        // 000000233A2C: D644001C 03FE4726 0C050C01
	v_dot2acc_f32_f16 v36, v1, v31                             // 000000233A38: 04483F01
	.long 0xcc0f4001                                           // 000000233A3C: CC0F4001
	v_mul_i32_i24_e32 v1, 0xe408, v8                           // 000000233A40: 120210FF 0000E408
	v_dot2acc_f32_f16 v42, v17, v4                             // 000000233A48: 04540911
	v_or_b32_e32 v4, 0x64006400, v18                           // 000000233A4C: 380824FF 64006400
	v_perm_b32 v8, v16, v9, 0xc060c02                          // 000000233A54: D6440008 03FE1310 0C060C02
	v_perm_b32 v9, v16, v9, 0xc070c03                          // 000000233A60: D6440009 03FE1310 0C070C03
	s_waitcnt lgkmcnt(0)                                       // 000000233A6C: BF89FC07
	v_dot2acc_f32_f16 v36, v1, v24                             // 000000233A70: 04483101
	v_lshrrev_b32_e32 v1, 4, v10                               // 000000233A74: 32021484
	.long 0xcc0f4004                                           // 000000233A78: CC0F4004
	v_mul_i32_i24_e32 v1, 0xe408, v4                           // 000000233A7C: 120208FF 0000E408
	v_or_b32_e32 v8, 0x64006400, v8                            // 000000233A84: 381010FF 64006400
	v_and_b32_e32 v10, 0xf0f0f0f, v10                          // 000000233A8C: 361414FF 0F0F0F0F
	ds_load_b128 v[16:19], v60 offset:4384                     // 000000233A94: DBFC1120 1000003C
	v_and_b32_e32 v1, 0xf0f0f0f, v1                            // 000000233A9C: 360202FF 0F0F0F0F
	v_or_b32_e32 v24, 0x64006400, v28                          // 000000233AA4: 383038FF 64006400
	v_dot2acc_f32_f16 v36, v4, v25                             // 000000233AAC: 04483304
	.long 0xcc0f4004                                           // 000000233AB0: CC0F4004
	v_mul_i32_i24_e32 v1, 0xe408, v8                           // 000000233AB4: 120210FF 0000E408
	v_or_b32_e32 v8, 0x64006400, v9                            // 000000233ABC: 381012FF 64006400
	v_perm_b32 v9, v1, v10, 0xc040c00                          // 000000233AC4: D6440009 03FE1501 0C040C00
	.long 0xcc0f4018                                           // 000000233AD0: CC0F4018
	v_mul_i32_i24_e32 v1, 0xe408, v24                          // 000000233AD4: 120230FF 0000E408
	v_perm_b32 v25, v38, v35, 0xc060c02                        // 000000233ADC: D6440019 03FE4726 0C060C02
	v_dot2acc_f32_f16 v36, v4, v26                             // 000000233AE8: 04483504
	.long 0xcc0f4004                                           // 000000233AEC: CC0F4004
	v_mul_i32_i24_e32 v1, 0xe408, v8                           // 000000233AF0: 120210FF 0000E408
	v_or_b32_e32 v8, 0x64006400, v9                            // 000000233AF8: 381012FF 64006400
	v_perm_b32 v9, v1, v10, 0xc050c01                          // 000000233B00: D6440009 03FE1501 0C050C01
	v_fma_mix_f32 v2, v3, v49, v2 op_sel_hi:[1,0,0]            // 000000233B0C: CC200002 0C0A6303
	v_dot2acc_f32_f16 v43, v34, v37                            // 000000233B14: 04564B22
	v_or_b32_e32 v25, 0x64006400, v25                          // 000000233B18: 383232FF 64006400
	v_dot2acc_f32_f16 v42, v24, v5                             // 000000233B20: 04540B18
	v_dot2acc_f32_f16 v36, v4, v27                             // 000000233B24: 04483704
	.long 0xcc0f4004                                           // 000000233B28: CC0F4004
	v_mul_i32_i24_e32 v1, 0xe408, v8                           // 000000233B2C: 120210FF 0000E408
	v_or_b32_e32 v5, 0x64006400, v9                            // 000000233B34: 380A12FF 64006400
	.long 0xcc0f4008                                           // 000000233B3C: CC0F4008
	v_mul_i32_i24_e32 v1, 0xe408, v25                          // 000000233B40: 120232FF 0000E408
	v_perm_b32 v9, v38, v35, 0xc070c03                         // 000000233B48: D6440009 03FE4726 0C070C03
	ds_load_b128 v[24:27], v60 offset:4400                     // 000000233B54: DBFC1130 1800003C
	s_waitcnt lgkmcnt(1)                                       // 000000233B5C: BF89FC17
	v_dot2acc_f32_f16 v36, v4, v16                             // 000000233B60: 04482104
	.long 0xcc0f4004                                           // 000000233B64: CC0F4004
	v_mul_i32_i24_e32 v1, 0xe408, v5                           // 000000233B68: 12020AFF 0000E408
	v_perm_b32 v5, v1, v10, 0xc060c02                          // 000000233B70: D6440005 03FE1501 0C060C02
	v_fma_mix_f32 v16, v3, v43, v2 op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000233B7C: CC200810 0C0A5703
	s_waitcnt vmcnt(2)                                         // 000000233B84: BF890BF7
	v_lshrrev_b32_e32 v2, 4, v20                               // 000000233B88: 32042884
	v_dot2acc_f32_f16 v42, v8, v6                              // 000000233B8C: 04540D08
	v_or_b32_e32 v6, 0x64006400, v9                            // 000000233B90: 380C12FF 64006400
	v_dot2acc_f32_f16 v36, v4, v17                             // 000000233B98: 04482304
	v_or_b32_e32 v5, 0x64006400, v5                            // 000000233B9C: 380A0AFF 64006400
	v_perm_b32 v8, v1, v10, 0xc070c03                          // 000000233BA4: D6440008 03FE1501 0C070C03
	v_lshrrev_b32_e32 v9, 4, v11                               // 000000233BB0: 32121684
	v_and_b32_e32 v10, 0xf0f0f0f, v11                          // 000000233BB4: 361416FF 0F0F0F0F
	v_and_b32_e32 v11, 0xf0f0f0f, v20                          // 000000233BBC: 361628FF 0F0F0F0F
	v_and_b32_e32 v17, 0xf0f0f0f, v2                           // 000000233BC4: 362204FF 0F0F0F0F
	ds_load_b128 v[1:4], v60 offset:4608                       // 000000233BCC: DBFC1200 0100003C
	v_and_b32_e32 v9, 0xf0f0f0f, v9                            // 000000233BD4: 361212FF 0F0F0F0F
	.long 0xcc0f4005                                           // 000000233BDC: CC0F4005
	v_mul_i32_i24_e32 v1, 0xe408, v5                           // 000000233BE0: 12020AFF 0000E408
	v_or_b32_e32 v8, 0x64006400, v8                            // 000000233BE8: 381010FF 64006400
	v_perm_b32 v20, v17, v11, 0xc040c00                        // 000000233BF0: D6440014 03FE1711 0C040C00
	.long 0xcc0f4006                                           // 000000233BFC: CC0F4006
	v_mul_i32_i24_e32 v1, 0xe408, v6                           // 000000233C00: 12020CFF 0000E408
	v_perm_b32 v28, v9, v10, 0xc040c00                         // 000000233C08: D644001C 03FE1509 0C040C00
	v_dot2acc_f32_f16 v36, v5, v18                             // 000000233C14: 04482505
	.long 0xcc0f4005                                           // 000000233C18: CC0F4005
	v_mul_i32_i24_e32 v1, 0xe408, v8                           // 000000233C1C: 120210FF 0000E408
	v_or_b32_e32 v8, 0x64006400, v20                           // 000000233C24: 381028FF 64006400
	v_dot2acc_f32_f16 v42, v6, v7                              // 000000233C2C: 04540F06
	v_or_b32_e32 v6, 0x64006400, v28                           // 000000233C30: 380C38FF 64006400
	v_perm_b32 v7, v17, v11, 0xc050c01                         // 000000233C38: D6440007 03FE1711 0C050C01
	v_mov_b32_e32 v20, 0                                       // 000000233C44: 7E280280
	.long 0xcc0f4012                                           // 000000233C48: CC0F4012
	v_mul_i32_i24_e32 v1, 0xe408, v8                           // 000000233C4C: 120210FF 0000E408
	v_dot2acc_f32_f16 v36, v5, v19                             // 000000233C54: 04482705
	.long 0xcc0f4013                                           // 000000233C58: CC0F4013
	v_mul_i32_i24_e32 v1, 0xe408, v6                           // 000000233C5C: 12020CFF 0000E408
	v_or_b32_e32 v28, 0x64006400, v7                           // 000000233C64: 38380EFF 64006400
	v_perm_b32 v29, v17, v11, 0xc060c02                        // 000000233C6C: D644001D 03FE1711 0C060C02
	ds_load_b128 v[5:8], v60 offset:4624                       // 000000233C78: DBFC1210 0500003C
	s_waitcnt lgkmcnt(1)                                       // 000000233C80: BF89FC17
	v_dot2acc_f32_f16 v20, v18, v1                             // 000000233C84: 04280312
	v_lshrrev_b32_e32 v1, 4, v21                               // 000000233C88: 32022A84
	.long 0xcc0f4012                                           // 000000233C8C: CC0F4012
	v_mul_i32_i24_e32 v1, 0xe408, v28                          // 000000233C90: 120238FF 0000E408
	v_or_b32_e32 v28, 0x64006400, v29                          // 000000233C98: 38383AFF 64006400
	v_perm_b32 v11, v17, v11, 0xc070c03                        // 000000233CA0: D644000B 03FE1711 0C070C03
	v_and_b32_e32 v17, 0xf0f0f0f, v21                          // 000000233CAC: 36222AFF 0F0F0F0F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000233CB4: BF870214
	v_dual_dot2acc_f32_f16 v20, v18, v2 :: v_dual_and_b32 v1, 0xf0f0f0f, v1// 000000233CB8: CB240512 140002FF 0F0F0F0F
	.long 0xcc0f4002                                           // 000000233CC4: CC0F4002
	v_mul_i32_i24_e32 v1, 0xe408, v28                          // 000000233CC8: 120238FF 0000E408
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000233CD0: BF870224
	v_or_b32_e32 v11, 0x64006400, v11                          // 000000233CD4: 381616FF 64006400
	v_perm_b32 v21, v9, v10, 0xc050c01                         // 000000233CDC: D6440015 03FE1509 0C050C01
	v_perm_b32 v18, v1, v17, 0xc040c00                         // 000000233CE8: D6440012 03FE2301 0C040C00
	v_dot2acc_f32_f16 v36, v19, v24                            // 000000233CF4: 04483113
	v_dot2acc_f32_f16 v20, v2, v3                              // 000000233CF8: 04280702
	.long 0xcc0f4002                                           // 000000233CFC: CC0F4002
	v_mul_i32_i24_e32 v1, 0xe408, v11                          // 000000233D00: 120216FF 0000E408
	v_or_b32_e32 v21, 0x64006400, v21                          // 000000233D08: 382A2AFF 64006400
	v_or_b32_e32 v3, 0x64006400, v18                           // 000000233D10: 380624FF 64006400
	v_perm_b32 v18, v1, v17, 0xc050c01                         // 000000233D18: D6440012 03FE2301 0C050C01
	v_perm_b32 v19, v9, v10, 0xc060c02                         // 000000233D24: D6440013 03FE1509 0C060C02
	v_dot2acc_f32_f16 v20, v2, v4                              // 000000233D30: 04280902
	v_perm_b32 v4, v1, v17, 0xc060c02                          // 000000233D34: D6440004 03FE2301 0C060C02
	.long 0xcc0f4002                                           // 000000233D40: CC0F4002
	v_mul_i32_i24_e32 v1, 0xe408, v3                           // 000000233D44: 120206FF 0000E408
	v_or_b32_e32 v3, 0x64006400, v18                           // 000000233D4C: 380624FF 64006400
	.long 0xcc0f400b                                           // 000000233D54: CC0F400B
	v_mul_i32_i24_e32 v1, 0xe408, v21                          // 000000233D58: 12022AFF 0000E408
	v_perm_b32 v17, v1, v17, 0xc070c03                         // 000000233D60: D6440011 03FE2301 0C070C03
	s_waitcnt lgkmcnt(0)                                       // 000000233D6C: BF89FC07
	v_dual_dot2acc_f32_f16 v20, v2, v5 :: v_dual_and_b32 v21, 0xf0f0f0f, v22// 000000233D70: CB240B02 14142CFF 0F0F0F0F
	v_lshrrev_b32_e32 v2, 4, v22                               // 000000233D7C: 32042C84
	.long 0xcc0f4003                                           // 000000233D80: CC0F4003
	v_mul_i32_i24_e32 v1, 0xe408, v3                           // 000000233D84: 120206FF 0000E408
	v_or_b32_e32 v5, 0x64006400, v4                            // 000000233D8C: 380A08FF 64006400
	v_perm_b32 v9, v9, v10, 0xc070c03                          // 000000233D94: D6440009 03FE1509 0C070C03
	v_dot2acc_f32_f16 v36, v11, v25                            // 000000233DA0: 0448330B
	v_and_b32_e32 v22, 0xf0f0f0f, v2                           // 000000233DA4: 362C04FF 0F0F0F0F
	v_dot2acc_f32_f16 v20, v3, v6                              // 000000233DAC: 04280D03
	ds_load_b128 v[1:4], v60 offset:4640                       // 000000233DB0: DBFC1220 0100003C
	.long 0xcc0f4005                                           // 000000233DB8: CC0F4005
	v_mul_i32_i24_e32 v1, 0xe408, v5                           // 000000233DBC: 12020AFF 0000E408
	v_or_b32_e32 v6, 0x64006400, v17                           // 000000233DC4: 380C22FF 64006400
	v_perm_b32 v17, v22, v21, 0xc040c00                        // 000000233DCC: D6440011 03FE2B16 0C040C00
	v_or_b32_e32 v11, 0x64006400, v19                          // 000000233DD8: 381626FF 64006400
	s_waitcnt vmcnt(1)                                         // 000000233DE0: BF8907F7
	v_dual_dot2acc_f32_f16 v20, v5, v7 :: v_dual_and_b32 v25, 0xf0f0f0f, v12// 000000233DE4: CB240F05 141818FF 0F0F0F0F
	.long 0xcc0f4005                                           // 000000233DF0: CC0F4005
	v_mul_i32_i24_e32 v1, 0xe408, v6                           // 000000233DF4: 12020CFF 0000E408
	v_or_b32_e32 v6, 0x64006400, v17                           // 000000233DFC: 380C22FF 64006400
	v_perm_b32 v7, v22, v21, 0xc050c01                         // 000000233E04: D6440007 03FE2B16 0C050C01
	v_or_b32_e32 v17, 0x64006400, v9                           // 000000233E10: 382212FF 64006400
	v_lshrrev_b32_e32 v9, 4, v12                               // 000000233E18: 32121884
	v_dot2acc_f32_f16 v20, v5, v8                              // 000000233E1C: 04281105
	.long 0xcc0f4013                                           // 000000233E20: CC0F4013
	v_mul_i32_i24_e32 v1, 0xe408, v6                           // 000000233E24: 12020CFF 0000E408
	v_or_b32_e32 v24, 0x64006400, v7                           // 000000233E2C: 38300EFF 64006400
	ds_load_b128 v[5:8], v60 offset:4864                       // 000000233E34: DBFC1300 0500003C
	v_and_b32_e32 v28, 0xf0f0f0f, v9                           // 000000233E3C: 363812FF 0F0F0F0F
	.long 0xcc0f4012                                           // 000000233E44: CC0F4012
	v_mul_i32_i24_e32 v1, 0xe408, v11                          // 000000233E48: 120216FF 0000E408
	v_perm_b32 v29, v22, v21, 0xc060c02                        // 000000233E50: D644001D 03FE2B16 0C060C02
	ds_load_b128 v[9:12], v60 offset:4656                      // 000000233E5C: DBFC1230 0900003C
	s_waitcnt lgkmcnt(2)                                       // 000000233E64: BF89FC27
	v_dot2acc_f32_f16 v20, v19, v1                             // 000000233E68: 04280313
	.long 0xcc0f4001                                           // 000000233E6C: CC0F4001
	v_mul_i32_i24_e32 v1, 0xe408, v24                          // 000000233E70: 120230FF 0000E408
	v_perm_b32 v19, v28, v25, 0xc040c00                        // 000000233E78: D6440013 03FE331C 0C040C00
	v_or_b32_e32 v24, 0x64006400, v29                          // 000000233E84: 38303AFF 64006400
	v_mov_b32_e32 v0, 0                                        // 000000233E8C: 7E000280
	v_dot2acc_f32_f16 v36, v18, v26                            // 000000233E90: 04483512
	v_dot2acc_f32_f16 v20, v1, v2                              // 000000233E94: 04280501
	v_or_b32_e32 v1, 0x64006400, v19                           // 000000233E98: 380226FF 64006400
	.long 0xcc0f4011                                           // 000000233EA0: CC0F4011
	v_mul_i32_i24_e32 v1, 0xe408, v17                          // 000000233EA4: 120222FF 0000E408
	.long 0xcc0f4002                                           // 000000233EAC: CC0F4002
	v_mul_i32_i24_e32 v1, 0xe408, v24                          // 000000233EB0: 120230FF 0000E408
	v_perm_b32 v18, v28, v25, 0xc050c01                        // 000000233EB8: D6440012 03FE331C 0C050C01
	s_waitcnt vmcnt(0)                                         // 000000233EC4: BF8903F7
	v_fma_mix_f32 v24, v32, v42, v16 op_sel_hi:[1,0,0]         // 000000233EC8: CC200018 0C425520
	.long 0xcc0f4001                                           // 000000233ED0: CC0F4001
	v_mul_i32_i24_e32 v1, 0xe408, v1                           // 000000233ED4: 120202FF 0000E408
	v_dot2acc_f32_f16 v36, v17, v27                            // 000000233EDC: 04483711
	v_dot2acc_f32_f16 v20, v2, v3                              // 000000233EE0: 04280702
	v_or_b32_e32 v2, 0x64006400, v18                           // 000000233EE4: 380424FF 64006400
	v_perm_b32 v3, v28, v25, 0xc060c02                         // 000000233EEC: D6440003 03FE331C 0C060C02
	ds_load_b128 v[16:19], v60 offset:4880                     // 000000233EF8: DBFC1310 1000003C
	s_waitcnt lgkmcnt(2)                                       // 000000233F00: BF89FC27
	v_dot2acc_f32_f16 v0, v1, v5                               // 000000233F04: 04000B01
	v_lshrrev_b32_e32 v1, 4, v13                               // 000000233F08: 32021A84
	.long 0xcc0f4002                                           // 000000233F0C: CC0F4002
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000233F10: 120204FF 0000E408
	v_or_b32_e32 v3, 0x64006400, v3                            // 000000233F18: 380606FF 64006400
	v_perm_b32 v5, v28, v25, 0xc070c03                         // 000000233F20: D6440005 03FE331C 0C070C03
	v_and_b32_e32 v13, 0xf0f0f0f, v13                          // 000000233F2C: 361A1AFF 0F0F0F0F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000233F34: BF870214
	v_dual_dot2acc_f32_f16 v0, v2, v6 :: v_dual_and_b32 v1, 0xf0f0f0f, v1// 000000233F38: CB240D02 000002FF 0F0F0F0F
	.long 0xcc0f4002                                           // 000000233F44: CC0F4002
	v_mul_i32_i24_e32 v1, 0xe408, v3                           // 000000233F48: 120206FF 0000E408
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000233F50: BF870224
	v_or_b32_e32 v3, 0x64006400, v5                            // 000000233F54: 38060AFF 64006400
	v_perm_b32 v21, v22, v21, 0xc070c03                        // 000000233F5C: D6440015 03FE2B16 0C070C03
	v_perm_b32 v5, v1, v13, 0xc040c00                          // 000000233F68: D6440005 03FE1B01 0C040C00
	v_and_b32_e32 v22, 0xf0f0f0f, v23                          // 000000233F74: 362C2EFF 0F0F0F0F
	v_dot2acc_f32_f16 v0, v2, v7                               // 000000233F7C: 04000F02
	.long 0xcc0f4002                                           // 000000233F80: CC0F4002
	v_mul_i32_i24_e32 v1, 0xe408, v3                           // 000000233F84: 120206FF 0000E408
	v_or_b32_e32 v6, 0x64006400, v21                           // 000000233F8C: 380C2AFF 64006400
	v_or_b32_e32 v3, 0x64006400, v5                            // 000000233F94: 38060AFF 64006400
	v_lshrrev_b32_e32 v21, 4, v23                              // 000000233F9C: 322A2E84
	v_perm_b32 v5, v1, v13, 0xc050c01                          // 000000233FA0: D6440005 03FE1B01 0C050C01
	v_dot2acc_f32_f16 v0, v2, v8                               // 000000233FAC: 04001102
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000233FB0: BF870214
	.long 0xcc0f4002                                           // 000000233FB4: CC0F4002
	v_mul_i32_i24_e32 v1, 0xe408, v3                           // 000000233FB8: 120206FF 0000E408
	v_and_b32_e32 v21, 0xf0f0f0f, v21                          // 000000233FC0: 362A2AFF 0F0F0F0F
	.long 0xcc0f4003                                           // 000000233FC8: CC0F4003
	v_mul_i32_i24_e32 v1, 0xe408, v6                           // 000000233FCC: 12020CFF 0000E408
	v_or_b32_e32 v5, 0x64006400, v5                            // 000000233FD4: 380A0AFF 64006400
	v_perm_b32 v6, v1, v13, 0xc060c02                          // 000000233FDC: D6440006 03FE1B01 0C060C02
	s_waitcnt lgkmcnt(0)                                       // 000000233FE8: BF89FC07
	v_dot2acc_f32_f16 v0, v2, v16                              // 000000233FEC: 04002102
	v_lshrrev_b32_e32 v2, 4, v14                               // 000000233FF0: 32041C84
	v_perm_b32 v23, v21, v22, 0xc040c00                        // 000000233FF4: D6440017 03FE2D15 0C040C00
	.long 0xcc0f4010                                           // 000000234000: CC0F4010
	v_mul_i32_i24_e32 v1, 0xe408, v5                           // 000000234004: 12020AFF 0000E408
	v_or_b32_e32 v25, 0x64006400, v6                           // 00000023400C: 38320CFF 64006400
	v_perm_b32 v1, v1, v13, 0xc070c03                          // 000000234014: D6440001 03FE1B01 0C070C03
	v_and_b32_e32 v13, 0xf0f0f0f, v14                          // 000000234020: 361A1CFF 0F0F0F0F
	v_and_b32_e32 v14, 0xf0f0f0f, v2                           // 000000234028: 361C04FF 0F0F0F0F
	ds_load_b128 v[5:8], v60 offset:4896                       // 000000234030: DBFC1320 0500003C
	v_or_b32_e32 v2, 0x64006400, v23                           // 000000234038: 38042EFF 64006400
	v_dot2acc_f32_f16 v0, v16, v17                             // 000000234040: 04002310
	.long 0xcc0f4010                                           // 000000234044: CC0F4010
	v_mul_i32_i24_e32 v1, 0xe408, v25                          // 000000234048: 120232FF 0000E408
	v_or_b32_e32 v1, 0x64006400, v1                            // 000000234050: 380202FF 64006400
	v_perm_b32 v17, v14, v13, 0xc040c00                        // 000000234058: D6440011 03FE1B0E 0C040C00
	v_dot2acc_f32_f16 v20, v3, v4                              // 000000234064: 04280903
	.long 0xcc0f4002                                           // 000000234068: CC0F4002
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 00000023406C: 120204FF 0000E408
	v_dot2acc_f32_f16 v0, v16, v18                             // 000000234074: 04002510
	.long 0xcc0f4001                                           // 000000234078: CC0F4001
	v_mul_i32_i24_e32 v1, 0xe408, v1                           // 00000023407C: 120202FF 0000E408
	v_or_b32_e32 v3, 0x64006400, v17                           // 000000234084: 380622FF 64006400
	v_perm_b32 v4, v21, v22, 0xc050c01                         // 00000023408C: D6440004 03FE2D15 0C050C01
	v_perm_b32 v16, v14, v13, 0xc050c01                        // 000000234098: D6440010 03FE1B0E 0C050C01
	v_dot2acc_f32_f16 v20, v2, v9                              // 0000002340A4: 04281302
	v_dot2acc_f32_f16 v0, v1, v19                              // 0000002340A8: 04002701
	.long 0xcc0f4009                                           // 0000002340AC: CC0F4009
	v_mul_i32_i24_e32 v1, 0xe408, v3                           // 0000002340B0: 120206FF 0000E408
	v_or_b32_e32 v17, 0x64006400, v4                           // 0000002340B8: 382208FF 64006400
	v_or_b32_e32 v16, 0x64006400, v16                          // 0000002340C0: 382020FF 64006400
	v_perm_b32 v18, v14, v13, 0xc060c02                        // 0000002340C8: D6440012 03FE1B0E 0C060C02
	ds_load_b128 v[1:4], v60 offset:4912                       // 0000002340D4: DBFC1330 0100003C
	s_waitcnt lgkmcnt(1)                                       // 0000002340DC: BF89FC17
	v_dot2acc_f32_f16 v0, v9, v5                               // 0000002340E0: 04000B09
	v_lshrrev_b32_e32 v5, 4, v15                               // 0000002340E4: 320A1E84
	.long 0xcc0f4009                                           // 0000002340E8: CC0F4009
	v_mul_i32_i24_e32 v1, 0xe408, v16                          // 0000002340EC: 120220FF 0000E408
	v_or_b32_e32 v16, 0x64006400, v18                          // 0000002340F4: 382024FF 64006400
	v_perm_b32 v13, v14, v13, 0xc070c03                        // 0000002340FC: D644000D 03FE1B0E 0C070C03
	v_and_b32_e32 v14, 0xf0f0f0f, v15                          // 000000234108: 361C1EFF 0F0F0F0F
	v_and_b32_e32 v5, 0xf0f0f0f, v5                            // 000000234110: 360A0AFF 0F0F0F0F
	.long 0xcc0f400f                                           // 000000234118: CC0F400F
	v_mul_i32_i24_e32 v1, 0xe408, v17                          // 00000023411C: 120222FF 0000E408
	v_dot2acc_f32_f16 v0, v9, v6                               // 000000234124: 04000D09
	.long 0xcc0f4006                                           // 000000234128: CC0F4006
	v_mul_i32_i24_e32 v1, 0xe408, v16                          // 00000023412C: 120220FF 0000E408
	v_or_b32_e32 v9, 0x64006400, v13                           // 000000234134: 38121AFF 64006400
	v_perm_b32 v13, v5, v14, 0xc040c00                         // 00000023413C: D644000D 03FE1D05 0C040C00
	v_dot2acc_f32_f16 v20, v15, v10                            // 000000234148: 0428150F
	v_perm_b32 v10, v21, v22, 0xc060c02                        // 00000023414C: D644000A 03FE2D15 0C060C02
	v_dot2acc_f32_f16 v0, v6, v7                               // 000000234158: 04000F06
	.long 0xcc0f4006                                           // 00000023415C: CC0F4006
	v_mul_i32_i24_e32 v1, 0xe408, v9                           // 000000234160: 120212FF 0000E408
	v_or_b32_e32 v7, 0x64006400, v13                           // 000000234168: 380E1AFF 64006400
	v_perm_b32 v9, v5, v14, 0xc050c01                          // 000000234170: D6440009 03FE1D05 0C050C01
	v_or_b32_e32 v10, 0x64006400, v10                          // 00000023417C: 381414FF 64006400
	v_perm_b32 v13, v21, v22, 0xc070c03                        // 000000234184: D644000D 03FE2D15 0C070C03
	v_dot2acc_f32_f16 v0, v6, v8                               // 000000234190: 04001106
	.long 0xcc0f4006                                           // 000000234194: CC0F4006
	v_mul_i32_i24_e32 v1, 0xe408, v7                           // 000000234198: 12020EFF 0000E408
	v_or_b32_e32 v7, 0x64006400, v9                            // 0000002341A0: 380E12FF 64006400
	v_perm_b32 v8, v5, v14, 0xc060c02                          // 0000002341A8: D6440008 03FE1D05 0C060C02
	.long 0xcc0f4009                                           // 0000002341B4: CC0F4009
	v_mul_i32_i24_e32 v1, 0xe408, v10                          // 0000002341B8: 120214FF 0000E408
	v_or_b32_e32 v10, 0x64006400, v13                          // 0000002341C0: 38141AFF 64006400
	s_waitcnt lgkmcnt(0)                                       // 0000002341C8: BF89FC07
	v_dot2acc_f32_f16 v0, v6, v1                               // 0000002341CC: 04000306
	.long 0xcc0f4001                                           // 0000002341D0: CC0F4001
	v_mul_i32_i24_e32 v1, 0xe408, v7                           // 0000002341D4: 12020EFF 0000E408
	v_or_b32_e32 v6, 0x64006400, v8                            // 0000002341DC: 380C10FF 64006400
	v_perm_b32 v5, v5, v14, 0xc070c03                          // 0000002341E4: D6440005 03FE1D05 0C070C03
	v_dot2acc_f32_f16 v20, v9, v11                             // 0000002341F0: 04281709
	.long 0xcc0f4007                                           // 0000002341F4: CC0F4007
	v_mul_i32_i24_e32 v1, 0xe408, v10                          // 0000002341F8: 120214FF 0000E408
	v_dot2acc_f32_f16 v0, v1, v2                               // 000000234200: 04000501
	.long 0xcc0f4001                                           // 000000234204: CC0F4001
	v_mul_i32_i24_e32 v1, 0xe408, v6                           // 000000234208: 12020CFF 0000E408
	v_or_b32_e32 v2, 0x64006400, v5                            // 000000234210: 38040AFF 64006400
	v_fma_mix_f32 v5, v32, v36, v24 op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000234218: CC200805 0C624920
	v_dot2acc_f32_f16 v20, v7, v12                             // 000000234220: 04281907
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000234224: BF870214
	v_dot2acc_f32_f16 v0, v1, v3                               // 000000234228: 04000701
	.long 0xcc0f4001                                           // 00000023422C: CC0F4001
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000234230: 120204FF 0000E408
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000234238: BF870113
	v_fma_mix_f32 v2, v33, v20, v5 op_sel_hi:[1,0,0]           // 00000023423C: CC200002 0C162921
	v_dot2acc_f32_f16 v0, v1, v4                               // 000000234244: 04000901
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000234248: BF870091
	v_fma_mix_f32 v0, v33, v0, v2 op_sel:[1,0,0] op_sel_hi:[1,0,0]// 00000023424C: CC200800 0C0A0121
	v_mov_b32_dpp v1, v0 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000234254: 7E0202FA FF016100
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000023425C: BF870091
	v_add_f32_e32 v0, v0, v1                                   // 000000234260: 06000300
	v_mov_b32_dpp v1, v0 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000234264: 7E0202FA FF016200
	v_cmpx_eq_u32_e32 0, v59                                   // 00000023426C: 7D947680
	s_cbranch_execz 15                                         // 000000234270: BFA5000F <_ZN7halogen12_GLOBAL__N_114k_i4r_rows_rotEPKhliPKtPKDF16_PKiPf+0x3eb0>
	s_mul_hi_i32 s1, s16, s18                                  // 000000234274: 97011210
	s_mul_i32 s0, s16, s18                                     // 000000234278: 96001210
	.long 0xd73c0002                                           // 00000023427C: D73C0002
	v_cndmask_b32_e32 v1, 2, v55, vcc_lo                       // 000000234280: 02026E82
	s_lshl_b64 s[0:1], s[0:1], 2                               // 000000234284: 84808200
	v_add_f32_e32 v4, v0, v1                                   // 000000234288: 06080300
	s_add_u32 s0, s14, s0                                      // 00000023428C: 8000000E
	s_addc_u32 s1, s15, s1                                     // 000000234290: 8201010F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000234294: BF870092
	.long 0xd7006a00                                           // 000000234298: D7006A00
	v_cndmask_b32_e32 v1, s0, v2, vcc_lo                       // 00000023429C: 02020400
	v_add_co_ci_u32_e64 v1, null, s1, v3, vcc_lo               // 0000002342A0: D5207C01 01AA0601
	global_store_b32 v[0:1], v4, off                           // 0000002342A8: DC6A0000 007C0400
	s_nop 0                                                    // 0000002342B0: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 0000002342B4: BFB60003
	s_endpgm                                                   // 0000002342B8: BFB00000
		...

