00000000008b8d00 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi16ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi16ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[8:23], s[0:1], null                          // 0000008B8D00: F4100200 F8000000
	v_and_b32_e32 v23, 15, v0                                  // 0000008B8D08: 362E008F
	v_lshrrev_b32_e32 v1, 4, v0                                // 0000008B8D0C: 32020084
	s_ashr_i32 s3, s2, 31                                      // 0000008B8D10: 86039F02
	v_lshlrev_b32_e32 v0, 2, v0                                // 0000008B8D14: 30000082
	s_lshl_b64 s[2:3], s[2:3], 4                               // 0000008B8D18: 84828402
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000008B8D1C: BF870009
	v_dual_mov_b32 v17, s3 :: v_dual_lshlrev_b32 v2, 2, v23    // 0000008B8D20: CA220003 11022E82
	v_lshlrev_b32_e32 v3, 2, v1                                // 0000008B8D28: 30060282
	v_or_b32_e32 v16, s2, v1                                   // 0000008B8D2C: 38200202
	.long 0x7f023880                                           // 0000008B8D30: 7F023880
	s_waitcnt lgkmcnt(0)                                       // 0000008B8D34: BF89FC07
	s_clause 0x1                                               // 0000008B8D38: BF850001
	global_load_b32 v2, v2, s[8:9]                             // 0000008B8D3C: DC520000 02080002
	global_load_b32 v3, v3, s[8:9]                             // 0000008B8D44: DC520000 03080003
	.long 0xd4540002                                           // 0000008B8D4C: D4540002
	v_cndmask_b32_e32 v1, s16, v16, vcc_lo                     // 0000008B8D50: 02022010
	s_add_u32 s24, s8, s20                                     // 0000008B8D54: 80181408
	s_addc_u32 s25, s9, s21                                    // 0000008B8D58: 82191509
	s_ashr_i32 s4, s15, 31                                     // 0000008B8D5C: 86049F0F
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 0000008B8D60: BF870159
	s_lshr_b32 s4, s4, 27                                      // 0000008B8D64: 85049B04
	v_cndmask_b32_e64 v8, 0, v16, s2                           // 0000008B8D68: D5010008 000A2080
	v_cndmask_b32_e64 v9, 0, s3, s2                            // 0000008B8D70: D5010009 00080680
	s_add_u32 s4, s14, s4                                      // 0000008B8D78: 8004040E
	s_addc_u32 s5, s15, 0                                      // 0000008B8D7C: 8205800F
	.long 0xd72c0004                                           // 0000008B8D80: D72C0004
	v_cndmask_b32_e32 v1, s23, v8, vcc_lo                      // 0000008B8D84: 02021017
	v_mad_u64_u32 v[12:13], null, s22, v8, 0                   // 0000008B8D88: D6FE7C0C 02021016
	s_lshr_b64 s[6:7], s[4:5], 5                               // 0000008B8D90: 85868504
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000008B8D94: BF870009
	s_cmpk_lt_i32 s6, 0x81                                     // 0000008B8D98: B3860081
	.long 0xd4440004                                           // 0000008B8D9C: D4440004
	v_cndmask_b32_e32 v1, s6, v23, vcc_lo                      // 0000008B8DA0: 02022E06
	s_cselect_b32 s3, -1, 0                                    // 0000008B8DA4: 980380C1
	s_cmpk_gt_i32 s6, 0x80                                     // 0000008B8DA8: B2860080
	.long 0xd700050e                                           // 0000008B8DAC: D700050E
	v_cndmask_b32_e32 v1, s24, v12, vcc_lo                     // 0000008B8DB0: 02021818
	s_cselect_b32 s7, -1, 0                                    // 0000008B8DB4: 980780C1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 0000008B8DB8: BF870159
	s_and_b32 vcc_lo, exec_lo, s7                              // 0000008B8DBC: 8B6A077E
	s_waitcnt vmcnt(1)                                         // 0000008B8DC0: BF8907F7
	v_bfe_u32 v5, v2, 16, 1                                    // 0000008B8DC4: D6100005 02052102
	s_waitcnt vmcnt(0)                                         // 0000008B8DCC: BF8903F7
	v_bfe_u32 v6, v3, 16, 1                                    // 0000008B8DD0: D6100006 02052103
	v_add3_u32 v2, v2, v5, 0x7fff                              // 0000008B8DD8: D6550002 03FE0B02 00007FFF
	.long 0xd72c0005                                           // 0000008B8DE4: D72C0005
	v_cndmask_b32_e32 v1, s22, v9, vcc_lo                      // 0000008B8DE8: 02021216
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008B8DEC: BF870193
	v_add3_u32 v3, v3, v6, 0x7fff                              // 0000008B8DF0: D6550003 03FE0D03 00007FFF
	.long 0x7e023982                                           // 0000008B8DFC: 7E023982
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000008B8E00: BF870113
	v_add3_u32 v13, v13, v5, v4                                // 0000008B8E04: D655000D 04120B0D
	v_and_or_b32 v1, 0xffff0000, v3, v1                        // 0000008B8E0C: D6570001 040606FF FFFF0000
	s_delay_alu instid0(VALU_DEP_2)                            // 0000008B8E18: BF870002
	v_add_co_ci_u32_e64 v15, null, s25, v13, s5                // 0000008B8E1C: D5207C0F 00161A19
	ds_store_b32 v0, v1                                        // 0000008B8E24: D8340000 00000100
	s_waitcnt lgkmcnt(0)                                       // 0000008B8E2C: BF89FC07
	s_barrier                                                  // 0000008B8E30: BFBD0000
	buffer_gl0_inv                                             // 0000008B8E34: E0AC0000 00000000
	s_cbranch_vccnz 144                                        // 0000008B8E3C: BFA40090 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi16ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x380>
	v_dual_mov_b32 v1, 0 :: v_dual_mov_b32 v0, 0               // 0000008B8E40: CA100080 01000080
	s_and_saveexec_b32 s5, s4                                  // 0000008B8E48: BE852004
	s_cbranch_execz 10                                         // 0000008B8E4C: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi16ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x178>
	v_lshlrev_b32_e32 v0, 1, v23                               // 0000008B8E50: 30002E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008B8E54: BF870091
	.long 0xd7006a02                                           // 0000008B8E58: D7006A02
	v_cndmask_b32_e32 v1, v14, v0, vcc_lo                      // 0000008B8E5C: 0202010E
	v_add_co_ci_u32_e64 v3, null, 0, v15, vcc_lo               // 0000008B8E60: D5207C03 01AA1E80
	global_load_d16_b16 v0, v[2:3], off                        // 0000008B8E68: DC820000 007C0002
	s_waitcnt vmcnt(0)                                         // 0000008B8E70: BF8903F7
	v_cvt_f32_f16_e32 v0, v0                                   // 0000008B8E74: 7E001700
	s_or_b32 exec_lo, exec_lo, s5                              // 0000008B8E78: 8C7E057E
	v_or_b32_e32 v2, 16, v23                                   // 0000008B8E7C: 38042E90
	s_mov_b32 s4, exec_lo                                      // 0000008B8E80: BE84007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008B8E84: BF870001
	.long 0xd4c4007e                                           // 0000008B8E88: D4C4007E
	v_cndmask_b32_e32 v1, s6, v2, vcc_lo                       // 0000008B8E8C: 02020406
	s_cbranch_execz 10                                         // 0000008B8E90: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi16ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x1bc>
	v_lshlrev_b32_e32 v1, 1, v2                                // 0000008B8E94: 30020481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008B8E98: BF870091
	.long 0xd7006a01                                           // 0000008B8E9C: D7006A01
	v_cndmask_b32_e32 v1, v14, v1, vcc_lo                      // 0000008B8EA0: 0202030E
	v_add_co_ci_u32_e64 v2, null, 0, v15, vcc_lo               // 0000008B8EA4: D5207C02 01AA1E80
	global_load_d16_b16 v1, v[1:2], off                        // 0000008B8EAC: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 0000008B8EB4: BF8903F7
	v_cvt_f32_f16_e32 v1, v1                                   // 0000008B8EB8: 7E021701
	s_or_b32 exec_lo, exec_lo, s4                              // 0000008B8EBC: 8C7E047E
	v_or_b32_e32 v4, 32, v23                                   // 0000008B8EC0: 38082EA0
	v_dual_mov_b32 v3, 0 :: v_dual_mov_b32 v2, 0               // 0000008B8EC4: CA100080 03020080
	s_mov_b32 s4, exec_lo                                      // 0000008B8ECC: BE84007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000008B8ED0: BF870002
	.long 0xd4c4007e                                           // 0000008B8ED4: D4C4007E
	v_cndmask_b32_e32 v1, s6, v4, vcc_lo                       // 0000008B8ED8: 02020806
	s_cbranch_execz 10                                         // 0000008B8EDC: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi16ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x208>
	v_lshlrev_b32_e32 v2, 1, v4                                // 0000008B8EE0: 30040881
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008B8EE4: BF870091
	.long 0xd7006a04                                           // 0000008B8EE8: D7006A04
	v_cndmask_b32_e32 v1, v14, v2, vcc_lo                      // 0000008B8EEC: 0202050E
	v_add_co_ci_u32_e64 v5, null, 0, v15, vcc_lo               // 0000008B8EF0: D5207C05 01AA1E80
	global_load_d16_b16 v2, v[4:5], off                        // 0000008B8EF8: DC820000 027C0004
	s_waitcnt vmcnt(0)                                         // 0000008B8F00: BF8903F7
	v_cvt_f32_f16_e32 v2, v2                                   // 0000008B8F04: 7E041702
	s_or_b32 exec_lo, exec_lo, s4                              // 0000008B8F08: 8C7E047E
	v_or_b32_e32 v4, 48, v23                                   // 0000008B8F0C: 38082EB0
	s_mov_b32 s4, exec_lo                                      // 0000008B8F10: BE84007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008B8F14: BF870001
	.long 0xd4c4007e                                           // 0000008B8F18: D4C4007E
	v_cndmask_b32_e32 v1, s6, v4, vcc_lo                       // 0000008B8F1C: 02020806
	s_cbranch_execz 10                                         // 0000008B8F20: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi16ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x24c>
	v_lshlrev_b32_e32 v3, 1, v4                                // 0000008B8F24: 30060881
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008B8F28: BF870091
	.long 0xd7006a03                                           // 0000008B8F2C: D7006A03
	v_cndmask_b32_e32 v1, v14, v3, vcc_lo                      // 0000008B8F30: 0202070E
	v_add_co_ci_u32_e64 v4, null, 0, v15, vcc_lo               // 0000008B8F34: D5207C04 01AA1E80
	global_load_d16_b16 v3, v[3:4], off                        // 0000008B8F3C: DC820000 037C0003
	s_waitcnt vmcnt(0)                                         // 0000008B8F44: BF8903F7
	v_cvt_f32_f16_e32 v3, v3                                   // 0000008B8F48: 7E061703
	s_or_b32 exec_lo, exec_lo, s4                              // 0000008B8F4C: 8C7E047E
	v_or_b32_e32 v6, 64, v23                                   // 0000008B8F50: 380C2EC0
	v_dual_mov_b32 v5, 0 :: v_dual_mov_b32 v4, 0               // 0000008B8F54: CA100080 05040080
	s_mov_b32 s4, exec_lo                                      // 0000008B8F5C: BE84007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000008B8F60: BF870002
	.long 0xd4c4007e                                           // 0000008B8F64: D4C4007E
	v_cndmask_b32_e32 v1, s6, v6, vcc_lo                       // 0000008B8F68: 02020C06
	s_cbranch_execz 10                                         // 0000008B8F6C: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi16ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x298>
	v_lshlrev_b32_e32 v4, 1, v6                                // 0000008B8F70: 30080C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008B8F74: BF870091
	.long 0xd7006a06                                           // 0000008B8F78: D7006A06
	v_cndmask_b32_e32 v1, v14, v4, vcc_lo                      // 0000008B8F7C: 0202090E
	v_add_co_ci_u32_e64 v7, null, 0, v15, vcc_lo               // 0000008B8F80: D5207C07 01AA1E80
	global_load_d16_b16 v4, v[6:7], off                        // 0000008B8F88: DC820000 047C0006
	s_waitcnt vmcnt(0)                                         // 0000008B8F90: BF8903F7
	v_cvt_f32_f16_e32 v4, v4                                   // 0000008B8F94: 7E081704
	s_or_b32 exec_lo, exec_lo, s4                              // 0000008B8F98: 8C7E047E
	v_or_b32_e32 v6, 0x50, v23                                 // 0000008B8F9C: 380C2EFF 00000050
	s_mov_b32 s4, exec_lo                                      // 0000008B8FA4: BE84007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008B8FA8: BF870001
	.long 0xd4c4007e                                           // 0000008B8FAC: D4C4007E
	v_cndmask_b32_e32 v1, s6, v6, vcc_lo                       // 0000008B8FB0: 02020C06
	s_cbranch_execz 10                                         // 0000008B8FB4: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi16ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x2e0>
	v_lshlrev_b32_e32 v5, 1, v6                                // 0000008B8FB8: 300A0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008B8FBC: BF870091
	.long 0xd7006a05                                           // 0000008B8FC0: D7006A05
	v_cndmask_b32_e32 v1, v14, v5, vcc_lo                      // 0000008B8FC4: 02020B0E
	v_add_co_ci_u32_e64 v6, null, 0, v15, vcc_lo               // 0000008B8FC8: D5207C06 01AA1E80
	global_load_d16_b16 v5, v[5:6], off                        // 0000008B8FD0: DC820000 057C0005
	s_waitcnt vmcnt(0)                                         // 0000008B8FD8: BF8903F7
	v_cvt_f32_f16_e32 v5, v5                                   // 0000008B8FDC: 7E0A1705
	s_or_b32 exec_lo, exec_lo, s4                              // 0000008B8FE0: 8C7E047E
	v_or_b32_e32 v10, 0x60, v23                                // 0000008B8FE4: 38142EFF 00000060
	v_dual_mov_b32 v7, 0 :: v_dual_mov_b32 v6, 0               // 0000008B8FEC: CA100080 07060080
	s_mov_b32 s4, exec_lo                                      // 0000008B8FF4: BE84007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000008B8FF8: BF870002
	.long 0xd4c4007e                                           // 0000008B8FFC: D4C4007E
	v_cndmask_b32_e32 v1, s6, v10, vcc_lo                      // 0000008B9000: 02021406
	s_cbranch_execz 10                                         // 0000008B9004: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi16ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x330>
	v_lshlrev_b32_e32 v6, 1, v10                               // 0000008B9008: 300C1481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008B900C: BF870091
	.long 0xd7006a0a                                           // 0000008B9010: D7006A0A
	v_cndmask_b32_e32 v1, v14, v6, vcc_lo                      // 0000008B9014: 02020D0E
	v_add_co_ci_u32_e64 v11, null, 0, v15, vcc_lo              // 0000008B9018: D5207C0B 01AA1E80
	global_load_d16_b16 v6, v[10:11], off                      // 0000008B9020: DC820000 067C000A
	s_waitcnt vmcnt(0)                                         // 0000008B9028: BF8903F7
	v_cvt_f32_f16_e32 v6, v6                                   // 0000008B902C: 7E0C1706
	s_or_b32 exec_lo, exec_lo, s4                              // 0000008B9030: 8C7E047E
	v_or_b32_e32 v10, 0x70, v23                                // 0000008B9034: 38142EFF 00000070
	s_mov_b32 s4, exec_lo                                      // 0000008B903C: BE84007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008B9040: BF870001
	.long 0xd4c4007e                                           // 0000008B9044: D4C4007E
	v_cndmask_b32_e32 v1, s6, v10, vcc_lo                      // 0000008B9048: 02021406
	s_cbranch_execz 10                                         // 0000008B904C: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi16ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x378>
	v_lshlrev_b32_e32 v7, 1, v10                               // 0000008B9050: 300E1481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008B9054: BF870091
	.long 0xd7006a0a                                           // 0000008B9058: D7006A0A
	v_cndmask_b32_e32 v1, v14, v7, vcc_lo                      // 0000008B905C: 02020F0E
	v_add_co_ci_u32_e64 v11, null, 0, v15, vcc_lo              // 0000008B9060: D5207C0B 01AA1E80
	global_load_d16_b16 v7, v[10:11], off                      // 0000008B9068: DC820000 077C000A
	s_waitcnt vmcnt(0)                                         // 0000008B9070: BF8903F7
	v_cvt_f32_f16_e32 v7, v7                                   // 0000008B9074: 7E0E1707
	s_or_b32 exec_lo, exec_lo, s4                              // 0000008B9078: 8C7E047E
	s_branch 9                                                 // 0000008B907C: BFA00009 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi16ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x3a4>
	v_mov_b32_e32 v0, 0                                        // 0000008B9080: 7E000280
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008B9084: BF870001
	v_mov_b32_e32 v1, v0                                       // 0000008B9088: 7E020300
	v_mov_b32_e32 v2, v0                                       // 0000008B908C: 7E040300
	v_mov_b32_e32 v3, v0                                       // 0000008B9090: 7E060300
	v_mov_b32_e32 v4, v0                                       // 0000008B9094: 7E080300
	v_mov_b32_e32 v5, v0                                       // 0000008B9098: 7E0A0300
	v_mov_b32_e32 v6, v0                                       // 0000008B909C: 7E0C0300
	v_mov_b32_e32 v7, v0                                       // 0000008B90A0: 7E0E0300
	s_add_u32 s4, s8, s18                                      // 0000008B90A4: 80041208
	s_addc_u32 s5, s9, s19                                     // 0000008B90A8: 82051309
	s_lshr_b32 s18, s15, 31                                    // 0000008B90AC: 85129F0F
	v_mov_b32_e32 v26, 0                                       // 0000008B90B0: 7E340280
	s_add_u32 s18, s14, s18                                    // 0000008B90B4: 8012120E
	s_addc_u32 s19, s15, 0                                     // 0000008B90B8: 8213800F
	v_cndmask_b32_e64 v24, 0, 1, s7                            // 0000008B90BC: D5010018 001D0280
	s_ashr_i64 s[18:19], s[18:19], 1                           // 0000008B90C4: 86928112
	v_mov_b32_e32 v27, 0                                       // 0000008B90C8: 7E360280
	v_mad_u64_u32 v[18:19], null, v8, s18, s[4:5]              // 0000008B90CC: D6FE7C12 00102508
	.long 0xd72c000b                                           // 0000008B90D4: D72C000B
	v_cndmask_b32_e32 v0, v8, v19, vcc_lo                      // 0000008B90D8: 02002708
	.long 0xd72c0014                                           // 0000008B90DC: D72C0014
	v_cndmask_b32_e32 v0, v9, v18, vcc_lo                      // 0000008B90E0: 02002509
	.long 0xd4440004                                           // 0000008B90E4: D4440004
	v_cndmask_b32_e32 v1, s6, v23, vcc_lo                      // 0000008B90E8: 02022E06
	v_dual_mov_b32 v8, 0 :: v_dual_mov_b32 v9, 0               // 0000008B90EC: CA100080 08080080
	v_mov_b32_e32 v10, 0                                       // 0000008B90F4: 7E140280
	s_delay_alu instid0(VALU_DEP_4)                            // 0000008B90F8: BF870004
	v_add3_u32 v25, v20, v19, v11                              // 0000008B90FC: D6550019 042E2714
	v_mov_b32_e32 v11, 0                                       // 0000008B9104: 7E160280
	s_and_saveexec_b32 s5, s4                                  // 0000008B9108: BE852004
	s_cbranch_execz 21                                         // 0000008B910C: BFA50015 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi16ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x464>
	v_dual_mov_b32 v27, 0 :: v_dual_lshlrev_b32 v8, 4, v23     // 0000008B9110: CA220080 1B082E84
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008B9118: BF870091
	.long 0xd7006a08                                           // 0000008B911C: D7006A08
	v_cndmask_b32_e32 v1, v18, v8, vcc_lo                      // 0000008B9120: 02021112
	v_add_co_ci_u32_e64 v9, null, 0, v25, vcc_lo               // 0000008B9124: D5207C09 01AA3280
	s_and_not1_b32 vcc_lo, exec_lo, s7                         // 0000008B912C: 916A077E
	global_load_b128 v[8:11], v[8:9], off                      // 0000008B9130: DC5E0000 087C0008
	s_cbranch_vccnz 10                                         // 0000008B9138: BFA4000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi16ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x464>
	v_lshlrev_b32_e32 v19, 1, v23                              // 0000008B913C: 30262E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008B9140: BF870091
	.long 0xd7006a0e                                           // 0000008B9144: D7006A0E
	v_cndmask_b32_e32 v1, v14, v19, vcc_lo                     // 0000008B9148: 0202270E
	v_add_co_ci_u32_e64 v15, null, 0, v15, vcc_lo              // 0000008B914C: D5207C0F 01AA1E80
	global_load_d16_b16 v14, v[14:15], off                     // 0000008B9154: DC820000 0E7C000E
	s_waitcnt vmcnt(0)                                         // 0000008B915C: BF8903F7
	v_cvt_f32_f16_e32 v27, v14                                 // 0000008B9160: 7E36170E
	s_or_b32 exec_lo, exec_lo, s5                              // 0000008B9164: 8C7E057E
	v_mov_b32_e32 v28, 0                                       // 0000008B9168: 7E380280
	s_and_saveexec_b32 s5, s4                                  // 0000008B916C: BE852004
	s_cbranch_execz 305                                        // 0000008B9170: BFA50131 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi16ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x938>
	v_dual_mov_b32 v31, v27 :: v_dual_lshlrev_b32 v14, 1, v23  // 0000008B9174: CA22011B 1F0E2E81
	.long 0xd7006a0c                                           // 0000008B917C: D7006A0C
	v_cndmask_b32_e32 v1, s20, v12, vcc_lo                     // 0000008B9180: 02021814
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008B9184: BF8701A1
	v_add_co_ci_u32_e64 v13, null, s21, v13, vcc_lo            // 0000008B9188: D5207C0D 01AA1A15
	v_dual_mov_b32 v20, 0 :: v_dual_lshlrev_b32 v19, 5, v23    // 0000008B9190: CA220080 14122E85
	.long 0xd7006a0c                                           // 0000008B9198: D7006A0C
	v_cndmask_b32_e32 v1, v12, v14, vcc_lo                     // 0000008B919C: 02021D0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008B91A0: BF8701A1
	v_add_co_ci_u32_e64 v13, null, 0, v13, vcc_lo              // 0000008B91A4: D5207C0D 01AA1A80
	v_lshl_or_b32 v29, v23, 4, 0x100                           // 0000008B91AC: D656001D 03FD0917 00000100
	.long 0xd7006a0c                                           // 0000008B91B8: D7006A0C
	v_cndmask_b32_e32 v1, s8, v12, vcc_lo                      // 0000008B91BC: 02021808
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008B91C0: BF8701A1
	v_add_co_ci_u32_e64 v13, null, s9, v13, vcc_lo             // 0000008B91C4: D5207C0D 01AA1A09
	v_mov_b32_e32 v30, v23                                     // 0000008B91CC: 7E3C0317
	.long 0xd7006a15                                           // 0000008B91D0: D7006A15
	v_cndmask_b32_e32 v0, v12, v160, vcc_lo                    // 0000008B91D4: 0201410C
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008B91D8: BF870001
	v_add_co_ci_u32_e64 v22, null, 0, v13, vcc_lo              // 0000008B91DC: D5207C16 01AA1A80
	v_mov_b32_e32 v28, v20                                     // 0000008B91E4: 7E380314
	v_mov_b32_e32 v26, v20                                     // 0000008B91E8: 7E340314
	s_mov_b32 s7, 0                                            // 0000008B91EC: BE870080
	s_lshl_b64 s[8:9], s[14:15], 1                             // 0000008B91F0: 8488810E
	s_branch 243                                               // 0000008B91F4: BFA000F3 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi16ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x8c4>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000008B91F8: 8C7E0E7E
	.long 0xd73c0020                                           // 0000008B91FC: D73C0020
	v_cndmask_b32_e32 v1, 1, v19, vcc_lo                       // 0000008B9200: 02022681
	v_and_b32_e32 v64, 0xff, v8                                // 0000008B9204: 368010FF 000000FF
	v_lshrrev_b32_e32 v65, 6, v8                               // 0000008B920C: 32821086
	v_lshrrev_b32_e32 v66, 14, v8                              // 0000008B9210: 3284108E
	v_lshrrev_b32_e32 v8, 22, v8                               // 0000008B9214: 32101096
	v_and_b32_e32 v67, 0xff, v9                                // 0000008B9218: 368612FF 000000FF
	.long 0xd7006a38                                           // 0000008B9220: D7006A38
	v_cndmask_b32_e32 v1, s10, v32, vcc_lo                     // 0000008B9224: 0202400A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008B9228: BF8701A1
	v_add_co_ci_u32_e64 v57, null, s11, v33, vcc_lo            // 0000008B922C: D5207C39 01AA420B
	v_lshlrev_b32_e32 v64, 2, v64                              // 0000008B9234: 30808082
	.long 0xd7006a3c                                           // 0000008B9238: D7006A3C
	v_cndmask_b32_e32 v0, v56, v8, vcc_lo                      // 0000008B923C: 02001138
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008B9240: BF870001
	v_add_co_ci_u32_e64 v61, null, s9, v57, vcc_lo             // 0000008B9244: D5207C3D 01AA7209
	v_and_b32_e32 v65, 0x3fc, v65                              // 0000008B924C: 368282FF 000003FC
	ds_load_b32 v64, v64                                       // 0000008B9254: D8D80000 40000040
	s_clause 0x7                                               // 0000008B925C: BF850007
	global_load_b128 v[32:35], v[56:57], off                   // 0000008B9260: DC5E0000 207C0038
	global_load_b128 v[36:39], v[60:61], off                   // 0000008B9268: DC5E0000 247C003C
	global_load_b128 v[40:43], v[56:57], off offset:16         // 0000008B9270: DC5E0010 287C0038
	global_load_b128 v[44:47], v[60:61], off offset:16         // 0000008B9278: DC5E0010 2C7C003C
	global_load_b128 v[48:51], v[56:57], off offset:32         // 0000008B9280: DC5E0020 307C0038
	global_load_b128 v[52:55], v[60:61], off offset:32         // 0000008B9288: DC5E0020 347C003C
	global_load_b128 v[56:59], v[56:57], off offset:48         // 0000008B9290: DC5E0030 387C0038
	global_load_b128 v[60:63], v[60:61], off offset:48         // 0000008B9298: DC5E0030 3C7C003C
	v_and_b32_e32 v66, 0x3fc, v66                              // 0000008B92A0: 368484FF 000003FC
	v_lshrrev_b32_e32 v68, 6, v9                               // 0000008B92A8: 32881286
	ds_load_b32 v65, v65                                       // 0000008B92AC: D8D80000 41000041
	v_lshrrev_b32_e32 v69, 14, v9                              // 0000008B92B4: 328A128E
	v_lshrrev_b32_e32 v9, 22, v9                               // 0000008B92B8: 32121296
	ds_load_b32 v66, v66                                       // 0000008B92BC: D8D80000 42000042
	v_and_b32_e32 v8, 0x3fc, v8                                // 0000008B92C4: 361010FF 000003FC
	v_lshlrev_b32_e32 v67, 2, v67                              // 0000008B92CC: 30868682
	v_and_b32_e32 v68, 0x3fc, v68                              // 0000008B92D0: 368888FF 000003FC
	v_and_b32_e32 v69, 0x3fc, v69                              // 0000008B92D8: 368A8AFF 000003FC
	v_and_b32_e32 v9, 0x3fc, v9                                // 0000008B92E0: 361212FF 000003FC
	ds_load_b32 v8, v8                                         // 0000008B92E8: D8D80000 08000008
	ds_load_b32 v67, v67                                       // 0000008B92F0: D8D80000 43000043
	ds_load_b32 v68, v68                                       // 0000008B92F8: D8D80000 44000044
	ds_load_b32 v69, v69                                       // 0000008B9300: D8D80000 45000045
	ds_load_b32 v9, v9                                         // 0000008B9308: D8D80000 09000009
	.long 0xd7006a15                                           // 0000008B9310: D7006A15
	v_cndmask_b32_e32 v0, v21, v160, vcc_lo                    // 0000008B9314: 02014115
	v_add_nc_u32_e32 v29, 0x100, v29                           // 0000008B9318: 4A3A3AFF 00000100
	v_add_co_ci_u32_e64 v22, null, 0, v22, vcc_lo              // 0000008B9320: D5207C16 01AA2C80
	s_and_b32 s4, exec_lo, s4                                  // 0000008B9328: 8B04047E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000008B932C: BF870009
	s_or_b32 s7, s4, s7                                        // 0000008B9330: 8C070704
	s_waitcnt vmcnt(7) lgkmcnt(7)                              // 0000008B9334: BF891C77
	v_dot2_f32_bf16 v32, v32, v64, 0                           // 0000008B9338: CC1A4020 1A028120
	s_waitcnt vmcnt(6)                                         // 0000008B9340: BF891BF7
	v_dot2_f32_bf16 v36, v36, v64, 0                           // 0000008B9344: CC1A4024 1A028124
	v_and_b32_e32 v64, 0xff, v10                               // 0000008B934C: 368014FF 000000FF
	s_waitcnt lgkmcnt(6)                                       // 0000008B9354: BF89FC67
	v_dot2_f32_bf16 v32, v33, v65, v32                         // 0000008B9358: CC1A4020 1C828321
	s_delay_alu instid0(VALU_DEP_3)                            // 0000008B9360: BF870003
	v_dot2_f32_bf16 v33, v37, v65, v36                         // 0000008B9364: CC1A4021 1C928325
	v_lshrrev_b32_e32 v36, 6, v10                              // 0000008B936C: 32481486
	v_lshrrev_b32_e32 v37, 14, v10                             // 0000008B9370: 324A148E
	v_lshrrev_b32_e32 v10, 22, v10                             // 0000008B9374: 32141496
	s_waitcnt lgkmcnt(5)                                       // 0000008B9378: BF89FC57
	v_dot2_f32_bf16 v32, v34, v66, v32                         // 0000008B937C: CC1A4020 1C828522
	v_dot2_f32_bf16 v33, v38, v66, v33                         // 0000008B9384: CC1A4021 1C868526
	v_and_b32_e32 v34, 0xff, v11                               // 0000008B938C: 364416FF 000000FF
	v_lshrrev_b32_e32 v38, 6, v11                              // 0000008B9394: 324C1686
	v_lshrrev_b32_e32 v65, 14, v11                             // 0000008B9398: 3282168E
	s_waitcnt lgkmcnt(4)                                       // 0000008B939C: BF89FC47
	v_dot2_f32_bf16 v32, v35, v8, v32                          // 0000008B93A0: CC1A4020 1C821123
	v_dot2_f32_bf16 v8, v39, v8, v33                           // 0000008B93A8: CC1A4008 1C861127
	v_and_b32_e32 v35, 0x3fc, v36                              // 0000008B93B0: 364648FF 000003FC
	v_and_b32_e32 v36, 0x3fc, v37                              // 0000008B93B8: 36484AFF 000003FC
	v_lshrrev_b32_e32 v11, 22, v11                             // 0000008B93C0: 32161696
	s_waitcnt vmcnt(5) lgkmcnt(3)                              // 0000008B93C4: BF891437
	v_dot2_f32_bf16 v32, v40, v67, v32                         // 0000008B93C8: CC1A4020 1C828728
	s_waitcnt vmcnt(4)                                         // 0000008B93D0: BF8913F7
	v_dot2_f32_bf16 v8, v44, v67, v8                           // 0000008B93D4: CC1A4008 1C22872C
	v_and_b32_e32 v10, 0x3fc, v10                              // 0000008B93DC: 361414FF 000003FC
	v_lshlrev_b32_e32 v34, 2, v34                              // 0000008B93E4: 30444482
	v_and_b32_e32 v37, 0x3fc, v38                              // 0000008B93E8: 364A4CFF 000003FC
	s_waitcnt lgkmcnt(2)                                       // 0000008B93F0: BF89FC27
	v_dot2_f32_bf16 v32, v41, v68, v32                         // 0000008B93F4: CC1A4020 1C828929
	v_dot2_f32_bf16 v8, v45, v68, v8                           // 0000008B93FC: CC1A4008 1C22892D
	v_and_b32_e32 v38, 0x3fc, v65                              // 0000008B9404: 364C82FF 000003FC
	v_and_b32_e32 v11, 0x3fc, v11                              // 0000008B940C: 361616FF 000003FC
	ds_load_b32 v35, v35                                       // 0000008B9414: D8D80000 23000023
	ds_load_b32 v36, v36                                       // 0000008B941C: D8D80000 24000024
	s_waitcnt lgkmcnt(3)                                       // 0000008B9424: BF89FC37
	v_dot2_f32_bf16 v32, v42, v69, v32                         // 0000008B9428: CC1A4020 1C828B2A
	v_cndmask_b32_e64 v42, v27, v0, s3                         // 0000008B9430: D501002A 000E011B
	v_lshlrev_b32_e32 v33, 2, v64                              // 0000008B9438: 30428082
	v_dot2_f32_bf16 v8, v46, v69, v8                           // 0000008B943C: CC1A4008 1C228B2E
	v_mov_b32_e32 v27, v31                                     // 0000008B9444: 7E36031F
	s_waitcnt lgkmcnt(2)                                       // 0000008B9448: BF89FC27
	v_dot2_f32_bf16 v32, v43, v9, v32                          // 0000008B944C: CC1A4020 1C82132B
	ds_load_b32 v33, v33                                       // 0000008B9454: D8D80000 21000021
	v_dot2_f32_bf16 v8, v47, v9, v8                            // 0000008B945C: CC1A4008 1C22132F
	ds_load_b32 v9, v10                                        // 0000008B9464: D8D80000 0900000A
	ds_load_b32 v10, v34                                       // 0000008B946C: D8D80000 0A000022
	ds_load_b32 v39, v37                                       // 0000008B9474: D8D80000 27000025
	ds_load_b32 v40, v38                                       // 0000008B947C: D8D80000 28000026
	ds_load_b32 v41, v11                                       // 0000008B9484: D8D80000 2900000B
	v_cndmask_b32_e64 v37, v5, v6, s3                          // 0000008B948C: D5010025 000E0D05
	v_cndmask_b32_e64 v38, v6, v7, s3                          // 0000008B9494: D5010026 000E0F06
	v_cndmask_b32_e64 v34, v2, v3, s3                          // 0000008B949C: D5010022 000E0702
	s_waitcnt vmcnt(3) lgkmcnt(5)                              // 0000008B94A4: BF890C57
	v_dot2_f32_bf16 v11, v48, v33, v32                         // 0000008B94A8: CC1A400B 1C824330
	s_waitcnt vmcnt(2)                                         // 0000008B94B0: BF890BF7
	v_dot2_f32_bf16 v8, v52, v33, v8                           // 0000008B94B4: CC1A4008 1C224334
	v_cndmask_b32_e64 v33, v1, v2, s3                          // 0000008B94BC: D5010021 000E0501
	v_cndmask_b32_e64 v32, v0, v1, s3                          // 0000008B94C4: D5010020 000E0300
	v_dot2_f32_bf16 v11, v49, v35, v11                         // 0000008B94CC: CC1A400B 1C2E4731
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008B94D4: BF8701A4
	v_dot2_f32_bf16 v8, v53, v35, v8                           // 0000008B94D8: CC1A4008 1C224735
	v_cndmask_b32_e64 v35, v3, v4, s3                          // 0000008B94E0: D5010023 000E0903
	v_dot2_f32_bf16 v11, v50, v36, v11                         // 0000008B94E8: CC1A400B 1C2E4932
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000008B94F0: BF8701B3
	v_dot2_f32_bf16 v8, v54, v36, v8                           // 0000008B94F4: CC1A4008 1C224936
	v_cndmask_b32_e64 v36, v4, v5, s3                          // 0000008B94FC: D5010024 000E0B04
	s_waitcnt lgkmcnt(4)                                       // 0000008B9504: BF89FC47
	v_dot2_f32_bf16 v11, v51, v9, v11                          // 0000008B9508: CC1A400B 1C2E1333
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000008B9510: BF8701B3
	v_dot2_f32_bf16 v8, v55, v9, v8                            // 0000008B9514: CC1A4008 1C221337
	v_mov_b32_e32 v9, v13                                      // 0000008B951C: 7E12030D
	s_waitcnt vmcnt(1) lgkmcnt(3)                              // 0000008B9520: BF890437
	v_dot2_f32_bf16 v4, v56, v10, v11                          // 0000008B9524: CC1A4004 1C2E1538
	s_waitcnt vmcnt(0)                                         // 0000008B952C: BF8903F7
	v_dot2_f32_bf16 v5, v60, v10, v8                           // 0000008B9530: CC1A4005 1C22153C
	v_dual_mov_b32 v11, v15 :: v_dual_mov_b32 v10, v14         // 0000008B9538: CA10010F 0B0A010E
	v_mov_b32_e32 v8, v12                                      // 0000008B9540: 7E10030C
	s_waitcnt lgkmcnt(2)                                       // 0000008B9544: BF89FC27
	v_dot2_f32_bf16 v0, v57, v39, v4                           // 0000008B9548: CC1A4000 1C124F39
	v_dot2_f32_bf16 v1, v61, v39, v5                           // 0000008B9550: CC1A4001 1C164F3D
	v_mov_b32_e32 v39, v7                                      // 0000008B9558: 7E4E0307
	v_add_nc_u32_e32 v19, 0x200, v19                           // 0000008B955C: 4A2626FF 00000200
	s_waitcnt lgkmcnt(1)                                       // 0000008B9564: BF89FC17
	v_dot2_f32_bf16 v0, v58, v40, v0                           // 0000008B9568: CC1A4000 1C02513A
	v_dot2_f32_bf16 v1, v62, v40, v1                           // 0000008B9570: CC1A4001 1C06513E
	s_waitcnt lgkmcnt(0)                                       // 0000008B9578: BF89FC07
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000008B957C: BF870112
	v_dot2_f32_bf16 v0, v59, v41, v0                           // 0000008B9580: CC1A4000 1C02533B
	v_dot2_f32_bf16 v1, v63, v41, v1                           // 0000008B9588: CC1A4001 1C06533F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000008B9590: BF870112
	v_fmac_f32_e32 v28, v42, v0                                // 0000008B9594: 5638012A
	v_fmac_f32_e32 v26, v42, v1                                // 0000008B9598: 5634032A
	v_dual_mov_b32 v0, v32 :: v_dual_mov_b32 v1, v33           // 0000008B959C: CA100120 00000121
	v_dual_mov_b32 v2, v34 :: v_dual_mov_b32 v3, v35           // 0000008B95A4: CA100122 02020123
	v_dual_mov_b32 v4, v36 :: v_dual_mov_b32 v5, v37           // 0000008B95AC: CA100124 04040125
	v_dual_mov_b32 v6, v38 :: v_dual_mov_b32 v7, v39           // 0000008B95B4: CA100126 06060127
	s_and_not1_b32 exec_lo, exec_lo, s7                        // 0000008B95BC: 917E077E
	s_cbranch_execz 28                                         // 0000008B95C0: BFA5001C <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi16ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x934>
	s_waitcnt vmcnt(0)                                         // 0000008B95C4: BF8903F7
	v_dual_mov_b32 v13, v9 :: v_dual_add_nc_u32 v30, 16, v30   // 0000008B95C8: CA200109 0D1E3C90
	v_dual_mov_b32 v12, v8 :: v_dual_mov_b32 v15, v11          // 0000008B95D0: CA100108 0C0E010B
	v_mov_b32_e32 v14, v10                                     // 0000008B95D8: 7E1C030A
	s_delay_alu instid0(VALU_DEP_3)                            // 0000008B95DC: BF870003
	.long 0xd4430004                                           // 0000008B95E0: D4430004
	v_cndmask_b32_e32 v1, s6, v30, vcc_lo                      // 0000008B95E4: 02023C06
	s_mov_b32 s14, exec_lo                                     // 0000008B95E8: BE8E007E
	.long 0xd4c4007e                                           // 0000008B95EC: D4C4007E
	v_cndmask_b32_e32 v1, s6, v30, vcc_lo                      // 0000008B95F0: 02023C06
	s_cbranch_execz 65280                                      // 0000008B95F4: BFA5FF00 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi16ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x4f8>
	.long 0xd7006a0c                                           // 0000008B95F8: D7006A0C
	v_cndmask_b32_e32 v1, v18, v29, vcc_lo                     // 0000008B95FC: 02023B12
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008B9600: BF870001
	v_add_co_ci_u32_e64 v13, null, 0, v25, vcc_lo              // 0000008B9604: D5207C0D 01AA3280
	v_cmp_ne_u32_e32 vcc_lo, 1, v24                            // 0000008B960C: 7C9A3081
	v_mov_b32_e32 v31, v27                                     // 0000008B9610: 7E3E031B
	global_load_b128 v[12:15], v[12:13], off                   // 0000008B9614: DC5E0000 0C7C000C
	s_cbranch_vccnz 65270                                      // 0000008B961C: BFA4FEF6 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi16ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x4f8>
	global_load_d16_b16 v31, v[21:22], off                     // 0000008B9620: DC820000 1F7C0015
	s_waitcnt vmcnt(0)                                         // 0000008B9628: BF8903F7
	v_cvt_f32_f16_e32 v31, v31                                 // 0000008B962C: 7E3E171F
	s_branch 65265                                             // 0000008B9630: BFA0FEF1 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi16ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x4f8>
	s_or_b32 exec_lo, exec_lo, s7                              // 0000008B9634: 8C7E077E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008B9638: BF8700A9
	s_or_b32 exec_lo, exec_lo, s5                              // 0000008B963C: 8C7E057E
	.long 0xd71f0000                                           // 0000008B9640: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000008B9644: 020100C1
	v_xor_b32_e32 v1, 8, v0                                    // 0000008B9648: 3A020088
	v_xor_b32_e32 v3, 4, v0                                    // 0000008B964C: 3A060084
	v_xor_b32_e32 v5, 2, v0                                    // 0000008B9650: 3A0A0082
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000008B9654: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v1                            // 0000008B9658: 7C9802A0
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 0000008B965C: 02020300
	v_cmp_gt_u32_e32 vcc_lo, 32, v3                            // 0000008B9660: 7C9806A0
	s_delay_alu instid0(VALU_DEP_2)                            // 0000008B9664: BF870002
	v_lshlrev_b32_e32 v1, 2, v1                                // 0000008B9668: 30020282
	v_cndmask_b32_e32 v3, v0, v3, vcc_lo                       // 0000008B966C: 02060700
	v_cmp_gt_u32_e32 vcc_lo, 32, v5                            // 0000008B9670: 7C980AA0
	ds_bpermute_b32 v2, v1, v28                                // 0000008B9674: DACC0000 02001C01
	s_waitcnt lgkmcnt(0)                                       // 0000008B967C: BF89FC07
	v_dual_add_f32 v2, v28, v2 :: v_dual_lshlrev_b32 v3, 2, v3 // 0000008B9680: C922051C 02020682
	ds_bpermute_b32 v1, v1, v26                                // 0000008B9688: DACC0000 01001A01
	ds_bpermute_b32 v4, v3, v2                                 // 0000008B9690: DACC0000 04000203
	s_waitcnt lgkmcnt(1)                                       // 0000008B9698: BF89FC17
	v_add_f32_e32 v1, v26, v1                                  // 0000008B969C: 0602031A
	s_waitcnt lgkmcnt(0)                                       // 0000008B96A0: BF89FC07
	v_add_f32_e32 v2, v2, v4                                   // 0000008B96A4: 06040902
	ds_bpermute_b32 v3, v3, v1                                 // 0000008B96A8: DACC0000 03000103
	v_cndmask_b32_e32 v5, v0, v5, vcc_lo                       // 0000008B96B0: 020A0B00
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008B96B4: BF870001
	v_lshlrev_b32_e32 v5, 2, v5                                // 0000008B96B8: 300A0A82
	s_waitcnt lgkmcnt(0)                                       // 0000008B96BC: BF89FC07
	v_add_f32_e32 v1, v1, v3                                   // 0000008B96C0: 06020701
	ds_bpermute_b32 v3, v5, v2                                 // 0000008B96C4: DACC0000 03000205
	ds_bpermute_b32 v4, v5, v1                                 // 0000008B96CC: DACC0000 04000105
	v_xor_b32_e32 v5, 1, v0                                    // 0000008B96D4: 3A0A0081
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000008B96D8: BF870141
	v_cmp_gt_u32_e32 vcc_lo, 32, v5                            // 0000008B96DC: 7C980AA0
	v_cndmask_b32_e32 v0, v0, v5, vcc_lo                       // 0000008B96E0: 02000B00
	v_cmp_eq_u32_e32 vcc_lo, 0, v23                            // 0000008B96E4: 7C942E80
	s_waitcnt lgkmcnt(1)                                       // 0000008B96E8: BF89FC17
	v_dual_add_f32 v2, v2, v3 :: v_dual_lshlrev_b32 v5, 2, v0  // 0000008B96EC: C9220702 02040082
	s_and_b32 s2, vcc_lo, s2                                   // 0000008B96F4: 8B02026A
	s_waitcnt lgkmcnt(0)                                       // 0000008B96F8: BF89FC07
	v_add_f32_e32 v0, v1, v4                                   // 0000008B96FC: 06000901
	ds_bpermute_b32 v3, v5, v2                                 // 0000008B9700: DACC0000 03000205
	ds_bpermute_b32 v1, v5, v0                                 // 0000008B9708: DACC0000 01000005
	s_and_saveexec_b32 s3, s2                                  // 0000008B9710: BE832002
	s_cbranch_execz 72                                         // 0000008B9714: BFA50048 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi16ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0xb38>
	v_ashrrev_i32_e32 v4, 31, v17                              // 0000008B9718: 3408229F
	s_load_b64 s[2:3], s[0:1], 0x40                            // 0000008B971C: F4040080 F8000040
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000008B9724: BF890007
	v_dual_mov_b32 v6, s13 :: v_dual_add_f32 v9, v0, v1        // 0000008B9728: CA08000D 06080300
	.long 0x7f143880                                           // 0000008B9730: 7F143880
	v_lshrrev_b32_e32 v4, 23, v4                               // 0000008B9734: 32080897
	s_lshr_b32 s0, s17, 31                                     // 0000008B9738: 85009F11
	v_mov_b32_e32 v7, s12                                      // 0000008B973C: 7E0E020C
	.long 0x7e143989                                           // 0000008B9740: 7E143989
	v_add_f32_e32 v8, v2, v3                                   // 0000008B9744: 06100702
	.long 0xd7006a04                                           // 0000008B9748: D7006A04
	v_cndmask_b32_e32 v1, v16, v4, vcc_lo                      // 0000008B974C: 02020910
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 0000008B9750: BF870151
	v_add_co_ci_u32_e64 v5, null, 0, v17, vcc_lo               // 0000008B9754: D5207C05 01AA2280
	s_add_u32 s1, s16, s0                                      // 0000008B975C: 80010010
	v_and_b32_e32 v4, 0xfffffe00, v4                           // 0000008B9760: 360808FF FFFFFE00
	.long 0x7f16398a                                           // 0000008B9768: 7F16398A
	s_addc_u32 s4, s17, 0                                      // 0000008B976C: 82048011
	.long 0xd7016a02                                           // 0000008B9770: D7016A02
	v_cndmask_b32_e32 v1, v16, v4, vcc_lo                      // 0000008B9774: 02020910
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000008B9778: BF870111
	v_sub_co_ci_u32_e64 v3, null, v17, v5, vcc_lo              // 0000008B977C: D5217C03 01AA0B11
	.long 0xd7000000                                           // 0000008B9784: D7000000
	v_cndmask_b32_e32 v1, 0xffffff00, v2, vcc_lo               // 0000008B9788: 020204FF FFFFFF00
	s_delay_alu instid0(VALU_DEP_2)                            // 0000008B9790: BF870002
	v_cmp_gt_i64_e32 vcc_lo, 0x100, v[2:3]                     // 0000008B9794: 7CA804FF 00000100
	v_add_co_ci_u32_e64 v1, null, -1, v3, s0                   // 0000008B979C: D5207C01 000206C1
	s_and_b32 s0, s1, -2                                       // 0000008B97A4: 8B00C201
	v_dual_cndmask_b32 v6, s3, v6 :: v_dual_cndmask_b32 v1, v1, v3// 0000008B97A8: CA520C03 06000701
	v_and_b32_e32 v3, 1, v10                                   // 0000008B97B0: 36061481
	.long 0x7e163988                                           // 0000008B97B4: 7E163988
	v_cndmask_b32_e32 v0, v0, v2, vcc_lo                       // 0000008B97B8: 02000500
	v_cndmask_b32_e32 v2, s2, v7, vcc_lo                       // 0000008B97BC: 02040E02
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008B97C0: BF870193
	v_and_b32_e32 v7, 1, v11                                   // 0000008B97C4: 360E1681
	.long 0xd73c0000                                           // 0000008B97C8: D73C0000
	v_cndmask_b32_e32 v1, 1, v0, vcc_lo                        // 0000008B97CC: 02020081
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008B97D0: BF870093
	.long 0xd7006a02                                           // 0000008B97D4: D7006A02
	v_cndmask_b32_e32 v1, v2, v4, vcc_lo                       // 0000008B97D8: 02020902
	v_add_co_ci_u32_e64 v4, null, v6, v5, vcc_lo               // 0000008B97DC: D5207C04 01AA0B06
	v_add3_u32 v5, v9, v3, 0x7fff                              // 0000008B97E4: D6550005 03FE0709 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008B97F0: BF870093
	.long 0xd7006a00                                           // 0000008B97F4: D7006A00
	v_cndmask_b32_e32 v1, v2, v0, vcc_lo                       // 0000008B97F8: 02020102
	v_add_co_ci_u32_e64 v1, null, v4, v1, vcc_lo               // 0000008B97FC: D5207C01 01AA0304
	v_add3_u32 v4, v8, v7, 0x7fff                              // 0000008B9804: D6550004 03FE0F08 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008B9810: BF870093
	.long 0xd7006a02                                           // 0000008B9814: D7006A02
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 0000008B9818: 02000100
	v_add_co_ci_u32_e64 v3, null, s4, v1, vcc_lo               // 0000008B981C: D5207C03 01AA0204
	s_clause 0x1                                               // 0000008B9824: BF850001
	global_store_d16_hi_b16 v[0:1], v4, off                    // 0000008B9828: DC960000 007C0400
	global_store_d16_hi_b16 v[2:3], v5, off                    // 0000008B9830: DC960000 007C0502
	s_endpgm                                                   // 0000008B9838: BFB00000
		...

