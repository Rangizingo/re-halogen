0000000000375600 <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi6ELi32ELi2EEEvNS0_5LqGrpEPKtl>:
; _ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi6ELi32ELi2EEEvNS0_5LqGrpEPKtl():
	s_clause 0x3                                               // 000000375600: BF850003
	s_load_b32 s3, s[0:1], 0x120                               // 000000375604: F40000C0 F8000120
	s_load_b32 s4, s[0:1], 0x88                                // 00000037560C: F4000100 F8000088
	s_load_b32 s5, s[0:1], 0xd0                                // 000000375614: F4000140 F80000D0
	s_load_b32 s6, s[0:1], 0x118                               // 00000037561C: F4000180 F8000118
	v_lshrrev_b32_e32 v5, 5, v0                                // 000000375624: 320A0085
	v_and_b32_e32 v53, 31, v0                                  // 000000375628: 366A009F
	v_dual_mov_b32 v55, 0 :: v_dual_mov_b32 v2, 0              // 00000037562C: CA100080 37020080
	v_mov_b32_e32 v38, 0                                       // 000000375634: 7E4C0280
	v_dual_mov_b32 v72, 0 :: v_dual_mov_b32 v39, 0             // 000000375638: CA100080 48260080
	s_waitcnt lgkmcnt(0)                                       // 000000375640: BF89FC07
	s_cmp_gt_i32 s3, 1                                         // 000000375644: BF028103
	s_cselect_b32 s7, -1, 0                                    // 000000375648: 980780C1
	s_cmp_ge_i32 s2, s4                                        // 00000037564C: BF030402
	s_cselect_b32 s4, -1, 0                                    // 000000375650: 980480C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000375654: BF870009
	s_and_b32 s4, s7, s4                                       // 000000375658: 8B040407
	s_cmp_gt_i32 s3, 2                                         // 00000037565C: BF028203
	v_cndmask_b32_e64 v1, 0, 1, s4                             // 000000375660: D5010001 00110280
	s_cselect_b32 s7, -1, 0                                    // 000000375668: 980780C1
	s_cmp_ge_i32 s2, s5                                        // 00000037566C: BF030502
	s_cselect_b32 s5, -1, 0                                    // 000000375670: 980580C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000375674: BF870009
	s_and_b32 s4, s7, s5                                       // 000000375678: 8B040507
	s_cmp_gt_i32 s3, 3                                         // 00000037567C: BF028303
	v_readfirstlane_b32 s5, v1                                 // 000000375680: 7E0A0501
	s_cselect_b32 s3, -1, 0                                    // 000000375684: 980380C1
	s_cmp_ge_i32 s2, s6                                        // 000000375688: BF030602
	s_cselect_b32 s6, -1, 0                                    // 00000037568C: 980680C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000375690: BF870009
	s_and_b32 s3, s3, s6                                       // 000000375694: 8B030603
	s_and_b32 s4, s4, exec_lo                                  // 000000375698: 8B047E04
	s_cselect_b32 s4, 2, s5                                    // 00000037569C: 98040582
	s_and_b32 s3, s3, exec_lo                                  // 0000003756A0: 8B037E03
	s_cselect_b32 s3, 3, s4                                    // 0000003756A4: 98030483
	s_load_b128 s[4:7], s[0:1], 0x128                          // 0000003756A8: F4080100 F8000128
	s_mulk_i32 s3, 0x48                                        // 0000003756B0: B8030048
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000003756B4: BF870009
	s_add_u32 s10, s0, s3                                      // 0000003756B8: 800A0300
	s_addc_u32 s11, s1, 0                                      // 0000003756BC: 820B8001
	s_clause 0x2                                               // 0000003756C0: BF850002
	s_load_b64 s[8:9], s[10:11], 0x30                          // 0000003756C4: F4040205 F8000030
	s_load_b32 s12, s[10:11], 0x40                             // 0000003756CC: F4000305 F8000040
	s_load_b64 s[0:1], s[10:11], null                          // 0000003756D4: F4040005 F8000000
	s_waitcnt lgkmcnt(0)                                       // 0000003756DC: BF89FC07
	.long 0xd4510011                                           // 0000003756E0: D4510011
	v_cndmask_b32_e32 v0, s8, v137, vcc_lo                     // 0000003756E4: 02011208
	s_and_b32 s3, s17, exec_lo                                 // 0000003756E8: 8B037E11
	s_cselect_b32 s16, 8, 2                                    // 0000003756EC: 98108288
	s_cselect_b32 s18, 3, 1                                    // 0000003756F0: 98128183
	v_cvt_f32_ubyte0_e32 v1, s16                               // 0000003756F4: 7E022210
	s_sub_i32 s2, s2, s12                                      // 0000003756F8: 81820C02
	s_add_i32 s14, s16, -1                                     // 0000003756FC: 810EC110
	s_and_b32 s13, s17, exec_lo                                // 000000375700: 8B0D7E11
	s_cselect_b32 s13, 0, 2                                    // 000000375704: 980D8280
	v_rcp_iflag_f32_e32 v3, v1                                 // 000000375708: 7E065701
	s_ashr_i32 s19, s7, 31                                     // 00000037570C: 86139F07
	s_mov_b32 s3, 0                                            // 000000375710: BE830080
	v_dual_mov_b32 v1, 0 :: v_dual_and_b32 v54, s14, v5        // 000000375714: CA240080 01360A0E
	s_lshl_b64 s[2:3], s[2:3], s13                             // 00000037571C: 84820D02
	v_lshrrev_b32_e32 v52, s18, v5                             // 000000375720: 32680A12
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000375724: BF870115
	v_readfirstlane_b32 s12, v3                                // 000000375728: 7E180503
	.long 0xd7001703                                           // 00000037572C: D7001703
	v_cndmask_b32_e32 v1, s2, v52, vcc_lo                      // 000000375730: 02026802
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 000000375734: BF8704B1
	v_add_co_ci_u32_e64 v4, null, s3, 0, s23                   // 000000375738: D5207C04 005D0003
	s_mul_f32 s15, s12, 0x4f7ffffe                             // 000000375740: A20FFF0C 4F7FFFFE
	s_lshr_b32 s12, s19, 27                                    // 000000375748: 850C9B13
	s_add_u32 s12, s6, s12                                     // 00000037574C: 800C0C06
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000375750: BF870009
	s_cvt_u32_f32 s15, s15                                     // 000000375754: BE8F670F
	s_addc_u32 s13, s7, 0                                      // 000000375758: 820D8007
	s_sub_i32 s22, 0, s16                                      // 00000037575C: 81961080
	s_lshr_b64 s[20:21], s[12:13], 5                           // 000000375760: 8594850C
	s_mul_i32 s22, s22, s15                                    // 000000375764: 96160F16
	s_add_i32 s12, s14, s20                                    // 000000375768: 810C140E
	s_mul_hi_u32 s13, s15, s22                                 // 00000037576C: 968D160F
	s_abs_i32 s21, s12                                         // 000000375770: BE95150C
	s_add_i32 s15, s15, s13                                    // 000000375774: 810F0D0F
	s_ashr_i32 s12, s12, 31                                    // 000000375778: 860C9F0C
	s_mul_hi_u32 s13, s21, s15                                 // 00000037577C: 968D0F15
	v_cmp_gt_i64_e32 vcc_lo, s[8:9], v[3:4]                    // 000000375780: 7CA80608
	s_mul_i32 s15, s13, s16                                    // 000000375784: 960F100D
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000375788: BF870009
	s_sub_i32 s15, s21, s15                                    // 00000037578C: 818F0F15
	s_add_i32 s21, s13, 1                                      // 000000375790: 8115810D
	s_sub_i32 s22, s15, s16                                    // 000000375794: 8196100F
	s_cmp_ge_u32 s15, s16                                      // 000000375798: BF09100F
	v_dual_cndmask_b32 v3, 0, v3 :: v_dual_cndmask_b32 v4, 0, v4// 00000037579C: CA520680 03040880
	s_cselect_b32 s13, s21, s13                                // 0000003757A4: 980D0D15
	s_cselect_b32 s15, s22, s15                                // 0000003757A8: 980F0F16
	s_add_i32 s21, s13, 1                                      // 0000003757AC: 8115810D
	s_cmp_ge_u32 s15, s16                                      // 0000003757B0: BF09100F
	s_cselect_b32 s13, s21, s13                                // 0000003757B4: 980D0D15
	s_lshr_b32 s14, s7, 31                                     // 0000003757B8: 850E9F07
	s_xor_b32 s13, s13, s12                                    // 0000003757BC: 8D0D0C0D
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000003757C0: BF870009
	s_sub_i32 s21, s13, s12                                    // 0000003757C4: 81950C0D
	s_add_u32 s12, s6, s14                                     // 0000003757C8: 800C0E06
	s_addc_u32 s13, s7, 0                                      // 0000003757CC: 820D8007
	s_lshr_b32 s14, s19, 30                                    // 0000003757D0: 850E9E13
	s_ashr_i64 s[12:13], s[12:13], 1                           // 0000003757D4: 868C810C
	s_add_u32 s14, s6, s14                                     // 0000003757D8: 800E0E06
	s_addc_u32 s15, s7, 0                                      // 0000003757DC: 820F8007
	s_lshr_b32 s19, s19, 28                                    // 0000003757E0: 85139C13
	s_ashr_i64 s[14:15], s[14:15], 2                           // 0000003757E4: 868E820E
	s_add_u32 s22, s6, s19                                     // 0000003757E8: 80161306
	s_addc_u32 s23, s7, 0                                      // 0000003757EC: 82178007
	.long 0xd72c0005                                           // 0000003757F0: D72C0005
	v_cndmask_b32_e32 v0, v54, v21, vcc_lo                     // 0000003757F4: 02002B36
	s_ashr_i64 s[22:23], s[22:23], 4                           // 0000003757F8: 86968416
	s_add_u32 s19, s14, s12                                    // 0000003757FC: 80130C0E
	s_addc_u32 s24, s15, s13                                   // 000000375800: 82180D0F
	s_add_u32 s19, s19, s22                                    // 000000375804: 80131613
	s_addc_u32 s22, s24, s23                                   // 000000375808: 82161718
	s_add_u32 s19, s19, 15                                     // 00000037580C: 80138F13
	s_addc_u32 s22, s22, 0                                     // 000000375810: 82168016
	v_add_nc_u32_e32 v6, s21, v5                               // 000000375814: 4A0C0A15
	s_ashr_i32 s23, s22, 31                                    // 000000375818: 86179F16
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000037581C: BF870499
	s_lshr_b32 s23, s23, 28                                    // 000000375820: 85179C17
	s_add_u32 s19, s19, s23                                    // 000000375824: 80131713
	s_addc_u32 s21, s22, 0                                     // 000000375828: 82158016
	s_and_b32 s19, s19, -16                                    // 00000037582C: 8B13D013
	.long 0xd72c0007                                           // 000000375830: D72C0007
	v_cndmask_b32_e32 v1, s21, v3, vcc_lo                      // 000000375834: 02020615
	.long 0xd72c0008                                           // 000000375838: D72C0008
	v_cndmask_b32_e32 v1, s19, v4, vcc_lo                      // 00000037583C: 02020813
	v_mad_u64_u32 v[33:34], null, s19, v3, s[0:1]              // 000000375840: D6FE7C21 00020613
	v_mov_b32_e32 v3, 0                                        // 000000375848: 7E060280
	v_min_i32_e32 v57, s20, v6                                 // 00000037584C: 22720C14
	v_mov_b32_e32 v4, 0                                        // 000000375850: 7E080280
	v_add_nc_u32_e32 v56, v5, v53                              // 000000375854: 4A706B05
	v_add3_u32 v58, v7, v34, v8                                // 000000375858: D655003A 04224507
	s_delay_alu instid0(VALU_DEP_2)                            // 000000375860: BF870002
	v_cmp_lt_i32_e32 vcc_lo, v56, v57                          // 000000375864: 7C827338
	s_and_saveexec_b32 s1, vcc_lo                              // 000000375868: BE81206A
	s_cbranch_execz 39                                         // 00000037586C: BFA50027 <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi6ELi32ELi2EEEvNS0_5LqGrpEPKtl+0x30c>
	v_lshlrev_b32_e32 v1, 4, v56                               // 000000375870: 30027084
	v_lshlrev_b32_e32 v4, 1, v56                               // 000000375874: 30087081
	v_lshlrev_b32_e32 v3, 3, v56                               // 000000375878: 30067083
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000037587C: BF870223
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000375880: 3404029F
	.long 0xd7000001                                           // 000000375884: D7000001
	v_cndmask_b32_e32 v1, v33, v1, vcc_lo                      // 000000375888: 02020321
	v_and_b32_e32 v4, -4, v4                                   // 00000037588C: 360808C4
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000375890: BF870214
	v_ashrrev_i32_e32 v8, 31, v3                               // 000000375894: 3410069F
	v_add_co_ci_u32_e64 v2, null, v58, v2, s0                  // 000000375898: D5207C02 0002053A
	.long 0xd7000006                                           // 0000003758A0: D7000006
	v_cndmask_b32_e32 v0, v33, v12, vcc_lo                     // 0000003758A4: 02001921
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000003758A8: BF8701A1
	v_add_co_ci_u32_e64 v7, null, s13, v58, s0                 // 0000003758AC: D5207C07 0002740D
	v_ashrrev_i32_e32 v11, 31, v4                              // 0000003758B4: 3416089F
	.long 0xd7000009                                           // 0000003758B8: D7000009
	v_cndmask_b32_e32 v0, v6, v14, vcc_lo                      // 0000003758BC: 02001D06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003758C0: BF8700A1
	v_add_co_ci_u32_e64 v10, null, s15, v7, s0                 // 0000003758C4: D5207C0A 00020E0F
	.long 0xd7000006                                           // 0000003758CC: D7000006
	v_cndmask_b32_e32 v1, v6, v3, vcc_lo                       // 0000003758D0: 02020706
	v_add_co_ci_u32_e64 v7, null, v7, v8, s0                   // 0000003758D4: D5207C07 00021107
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003758DC: BF870094
	.long 0xd7000008                                           // 0000003758E0: D7000008
	v_cndmask_b32_e32 v1, v9, v4, vcc_lo                       // 0000003758E4: 02020909
	v_add_co_ci_u32_e64 v9, null, v10, v11, s0                 // 0000003758E8: D5207C09 0002170A
	s_clause 0x2                                               // 0000003758F0: BF850002
	global_load_b128 v[1:4], v[1:2], off                       // 0000003758F4: DC5E0000 017C0001
	global_load_b64 v[38:39], v[6:7], off                      // 0000003758FC: DC560000 267C0006
	global_load_b32 v72, v[8:9], off                           // 000000375904: DC520000 487C0008
	s_or_b32 exec_lo, exec_lo, s1                              // 00000037590C: 8C7E017E
	v_dual_mov_b32 v59, 0 :: v_dual_mov_b32 v60, 0             // 000000375910: CA100080 3B3C0080
	v_dual_mov_b32 v61, 0 :: v_dual_mov_b32 v62, 0             // 000000375918: CA100080 3D3E0080
	v_mov_b32_e32 v63, 0                                       // 000000375920: 7E7E0280
	s_and_saveexec_b32 s1, vcc_lo                              // 000000375924: BE81206A
	s_cbranch_execz 883                                        // 000000375928: BFA50373 <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi6ELi32ELi2EEEvNS0_5LqGrpEPKtl+0x10f8>
	.long 0xd7006a40                                           // 00000037592C: D7006A40
	v_cndmask_b32_e32 v0, v33, v12, vcc_lo                     // 000000375930: 02001921
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000375934: BF870231
	v_add_co_ci_u32_e64 v65, null, s13, v58, vcc_lo            // 000000375938: D5207C41 01AA740D
	v_dual_mov_b32 v55, 0 :: v_dual_lshlrev_b32 v6, 5, v53     // 000000375940: CA220080 37066A85
	v_dual_mov_b32 v60, 0 :: v_dual_add_nc_u32 v7, 32, v56     // 000000375948: CA200080 3C0670A0
	.long 0xd7006a42                                           // 000000375950: D7006A42
	v_cndmask_b32_e32 v0, v64, v14, vcc_lo                     // 000000375954: 02001D40
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000375958: BF870211
	v_add_co_ci_u32_e64 v67, null, s15, v65, vcc_lo            // 00000037595C: D5207C43 01AA820F
	v_lshl_add_u32 v34, v5, 5, v6                              // 000000375964: D6460022 04190B05
	s_delay_alu instid0(VALU_DEP_4)                            // 00000037596C: BF870004
	v_dual_mov_b32 v59, 0 :: v_dual_lshlrev_b32 v68, 4, v7     // 000000375970: CA220080 3B440E84
	v_dual_mov_b32 v62, 0 :: v_dual_lshlrev_b32 v69, 3, v7     // 000000375978: CA220080 3E440E83
	v_dual_mov_b32 v61, 0 :: v_dual_lshlrev_b32 v70, 1, v7     // 000000375980: CA220080 3D460E81
	v_mov_b32_e32 v63, 0                                       // 000000375988: 7E7E0280
	s_waitcnt vmcnt(0)                                         // 00000037598C: BF8903F7
	v_mov_b32_e32 v71, v72                                     // 000000375990: 7E8E0348
	s_mul_i32 s0, s7, 6                                        // 000000375994: 96008607
	s_mul_hi_u32 s14, s6, 6                                    // 000000375998: 968E8606
	s_lshl_b64 s[12:13], s[6:7], 2                             // 00000037599C: 848C8206
	s_add_i32 s14, s14, s0                                     // 0000003759A0: 810E000E
	s_mul_i32 s19, s6, 6                                       // 0000003759A4: 96138606
	s_mov_b32 s15, 0                                           // 0000003759A8: BE8F0080
	s_lshl_b64 s[6:7], s[6:7], 1                               // 0000003759AC: 84868106
	s_branch 809                                               // 0000003759B0: BFA00329 <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi6ELi32ELi2EEEvNS0_5LqGrpEPKtl+0x1058>
	s_or_b32 exec_lo, exec_lo, s20                             // 0000003759B4: 8C7E147E
	v_ashrrev_i32_e32 v35, 31, v34                             // 0000003759B8: 3446449F
	v_lshlrev_b32_e32 v73, 2, v38                              // 0000003759BC: 30924C82
	v_lshrrev_b32_e32 v74, 4, v1                               // 0000003759C0: 32940284
	v_lshrrev_b32_e32 v75, 8, v1                               // 0000003759C4: 32960288
	v_lshrrev_b32_e32 v76, 2, v38                              // 0000003759C8: 32984C82
	.long 0xd73c0009                                           // 0000003759CC: D73C0009
	v_cndmask_b32_e32 v1, 1, v34, vcc_lo                       // 0000003759D0: 02024481
	v_lshlrev_b32_e32 v35, 4, v38                              // 0000003759D4: 30464C84
	v_and_b32_e32 v78, 48, v38                                 // 0000003759D8: 369C4CB0
	v_and_b32_e32 v73, 48, v73                                 // 0000003759DC: 369292B0
	v_lshrrev_b32_e32 v79, 12, v1                              // 0000003759E0: 329E028C
	v_and_b32_e32 v76, 48, v76                                 // 0000003759E4: 369898B0
	.long 0xd700002c                                           // 0000003759E8: D700002C
	v_cndmask_b32_e32 v1, s4, v9, vcc_lo                       // 0000003759EC: 02021204
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000003759F0: BF8701A1
	v_add_co_ci_u32_e64 v45, null, s5, v10, s0                 // 0000003759F4: D5207C2D 00021405
	v_and_b32_e32 v77, 48, v35                                 // 0000003759FC: 369A46B0
	.long 0xd7000028                                           // 000000375A00: D7000028
	v_cndmask_b32_e32 v0, v44, v6, vcc_lo                      // 000000375A04: 02000D2C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000375A08: BF8700D1
	v_add_co_ci_u32_e64 v41, null, s7, v45, s0                 // 000000375A0C: D5207C29 00025A07
	.long 0xd700002a                                           // 000000375A14: D700002A
	v_cndmask_b32_e32 v0, v44, v12, vcc_lo                     // 000000375A18: 0200192C
	global_load_b128 v[9:12], v[44:45], off                    // 000000375A1C: DC5E0000 097C002C
	v_add_co_ci_u32_e64 v43, null, s13, v45, s0                // 000000375A24: D5207C2B 00025A0D
	.long 0xd700002e                                           // 000000375A2C: D700002E
	v_cndmask_b32_e32 v0, v44, v19, vcc_lo                     // 000000375A30: 0200272C
	v_add_co_ci_u32_e64 v47, null, s14, v45, s0                // 000000375A34: D5207C2F 00025A0E
	.long 0xd7000030                                           // 000000375A3C: D7000030
	v_cndmask_b32_e32 v0, v42, v12, vcc_lo                     // 000000375A40: 0200192A
	s_clause 0x1                                               // 000000375A44: BF850001
	global_load_b128 v[17:20], v[40:41], off                   // 000000375A48: DC5E0000 117C0028
	global_load_b128 v[13:16], v[42:43], off                   // 000000375A50: DC5E0000 0D7C002A
	v_add_co_ci_u32_e64 v49, null, s13, v43, s0                // 000000375A58: D5207C31 0002560D
	s_clause 0x1                                               // 000000375A60: BF850001
	global_load_b128 v[21:24], v[46:47], off                   // 000000375A64: DC5E0000 157C002E
	global_load_b128 v[25:28], v[48:49], off                   // 000000375A6C: DC5E0000 197C0030
	.long 0xd7000032                                           // 000000375A74: D7000032
	v_cndmask_b32_e32 v0, v46, v12, vcc_lo                     // 000000375A78: 0200192E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000375A7C: BF870001
	v_add_co_ci_u32_e64 v51, null, s13, v47, s0                // 000000375A80: D5207C33 00025E0D
	v_and_or_b32 v77, v1, 15, v77                              // 000000375A88: D657004D 05351F01
	v_and_or_b32 v73, v74, 15, v73                             // 000000375A90: D6570049 05251F4A
	v_and_or_b32 v75, v75, 15, v78                             // 000000375A98: D657004B 05391F4B
	global_load_b128 v[29:32], v[50:51], off                   // 000000375AA0: DC5E0000 1D7C0032
	v_and_or_b32 v76, v79, 15, v76                             // 000000375AA8: D657004C 05311F4F
	v_cvt_f32_ubyte0_e32 v74, v77                              // 000000375AB0: 7E94234D
	v_cvt_f32_ubyte0_e32 v73, v73                              // 000000375AB4: 7E922349
	v_cvt_f32_ubyte0_e32 v75, v75                              // 000000375AB8: 7E96234B
	.long 0x7f463880                                           // 000000375ABC: 7F463880
	v_cvt_f32_ubyte0_e32 v76, v76                              // 000000375AC0: 7E98234C
	v_fma_mix_f32 v74, v74, v72, v72 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000375AC4: CC20604A 1522914A
	v_fma_mix_f32 v73, v73, v72, v72 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000375ACC: CC206049 15229149
	v_fma_mix_f32 v75, v75, v72, v72 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000375AD4: CC20604B 1522914B
	v_lshrrev_b32_e32 v80, 4, v38                              // 000000375ADC: 32A04C84
	v_fma_mix_f32 v76, v76, v72, v72 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000375AE0: CC20604C 1522914C
	v_bfe_u32 v79, v74, 16, 1                                  // 000000375AE8: D610004F 0205214A
	v_bfe_u32 v83, v73, 16, 1                                  // 000000375AF0: D6100053 02052149
	v_lshrrev_b32_e32 v81, 6, v38                              // 000000375AF8: 32A24C86
	v_lshrrev_b32_e32 v77, 8, v38                              // 000000375AFC: 329A4C88
	v_bfe_u32 v85, v76, 16, 1                                  // 000000375B00: D6100055 0205214C
	v_add3_u32 v74, v74, v79, 0x7fff                           // 000000375B08: D655004A 03FE9F4A 00007FFF
	v_bfe_u32 v79, v75, 16, 1                                  // 000000375B14: D610004F 0205214B
	v_add3_u32 v73, v73, v83, 0x7fff                           // 000000375B1C: D6550049 03FEA749 00007FFF
	v_and_b32_e32 v80, 48, v80                                 // 000000375B28: 36A0A0B0
	v_add3_u32 v76, v76, v85, 0x7fff                           // 000000375B2C: D655004C 03FEAB4C 00007FFF
	.long 0x7e4639ca                                           // 000000375B38: 7E4639CA
	v_add3_u32 v74, v75, v79, 0x7fff                           // 000000375B3C: D655004A 03FE9F4B 00007FFF
	v_lshrrev_b32_e32 v78, 20, v1                              // 000000375B48: 329C0294
	v_lshrrev_b32_e32 v82, 24, v1                              // 000000375B4C: 32A40298
	v_and_b32_e32 v81, 48, v81                                 // 000000375B50: 36A2A2B0
	v_and_or_b32 v105, 0xffff0000, v73, v35                    // 000000375B54: D6570069 048E92FF FFFF0000
	.long 0x7e4639ca                                           // 000000375B60: 7E4639CA
	v_and_b32_e32 v77, 48, v77                                 // 000000375B64: 369A9AB0
	v_lshrrev_b32_e32 v84, 28, v1                              // 000000375B68: 32A8029C
	v_lshrrev_b32_e32 v75, 10, v38                             // 000000375B6C: 32964C8A
	v_and_or_b32 v78, v78, 15, v81                             // 000000375B70: D657004E 05451F4E
	v_and_or_b32 v106, 0xffff0000, v76, v35                    // 000000375B78: D657006A 048E98FF FFFF0000
	.long 0x7e463981                                           // 000000375B84: 7E463981
	v_and_or_b32 v77, v82, 15, v77                             // 000000375B88: D657004D 05351F52
	v_and_or_b32 v75, v75, 48, v84                             // 000000375B90: D657004B 0551614B
	v_cvt_f32_ubyte0_e32 v78, v78                              // 000000375B98: 7E9C234E
	v_lshrrev_b32_e32 v79, 8, v2                               // 000000375B9C: 329E0488
	v_and_or_b32 v80, v35, 15, v80                             // 000000375BA0: D6570050 05411F23
	v_cvt_f32_ubyte0_e32 v77, v77                              // 000000375BA8: 7E9A234D
	v_cvt_f32_ubyte0_e32 v75, v75                              // 000000375BAC: 7E96234B
	v_fma_mix_f32 v78, v78, v72, v72 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000375BB0: CC20604E 1522914E
	v_lshrrev_b32_e32 v73, 18, v38                             // 000000375BB8: 32924C92
	v_cvt_f32_ubyte0_e32 v80, v80                              // 000000375BBC: 7EA02350
	v_fma_mix_f32 v77, v77, v72, v72 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000375BC0: CC20604D 1522914D
	v_fma_mix_f32 v75, v75, v72, v72 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000375BC8: CC20604B 1522914B
	v_bfe_u32 v89, v78, 16, 1                                  // 000000375BD0: D6100059 0205214E
	v_lshrrev_b32_e32 v83, 12, v2                              // 000000375BD8: 32A6048C
	v_fma_mix_f32 v80, v80, v72, v72 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000375BDC: CC206050 15229150
	v_and_b32_e32 v73, 48, v73                                 // 000000375BE4: 369292B0
	v_bfe_u32 v91, v75, 16, 1                                  // 000000375BE8: D610005B 0205214B
	v_add3_u32 v78, v78, v89, 0x7fff                           // 000000375BF0: D655004E 03FEB34E 00007FFF
	v_lshrrev_b32_e32 v74, 20, v38                             // 000000375BFC: 32944C94
	v_bfe_u32 v84, v80, 16, 1                                  // 000000375C00: D6100054 02052150
	v_and_or_b32 v73, v83, 15, v73                             // 000000375C08: D6570049 05251F53
	v_add3_u32 v75, v75, v91, 0x7fff                           // 000000375C10: D655004B 03FEB74B 00007FFF
	v_lshrrev_b32_e32 v1, 24, v38                              // 000000375C1C: 32024C98
	v_lshrrev_b32_e32 v85, 22, v38                             // 000000375C20: 32AA4C96
	v_add3_u32 v80, v80, v84, 0x7fff                           // 000000375C24: D6550050 03FEA950 00007FFF
	v_bfe_u32 v84, v77, 16, 1                                  // 000000375C30: D6100054 0205214D
	v_cvt_f32_ubyte0_e32 v73, v73                              // 000000375C38: 7E922349
	v_and_b32_e32 v74, 48, v74                                 // 000000375C3C: 369494B0
	v_lshrrev_b32_e32 v76, 20, v2                              // 000000375C40: 32980494
	.long 0x7e4639d0                                           // 000000375C44: 7E4639D0
	v_add3_u32 v77, v77, v84, 0x7fff                           // 000000375C48: D655004D 03FEA94D 00007FFF
	v_fma_mix_f32 v73, v73, v72, v72 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000375C54: CC206049 15229149
	v_lshrrev_b32_e32 v86, 24, v2                              // 000000375C5C: 32AC0498
	v_lshrrev_b32_e32 v87, 28, v2                              // 000000375C60: 32AE049C
	v_and_or_b32 v109, 0xffff0000, v78, v35                    // 000000375C64: D657006D 048E9CFF FFFF0000
	.long 0x7e4639cd                                           // 000000375C70: 7E4639CD
	v_bfe_u32 v113, v73, 16, 1                                 // 000000375C74: D6100071 02052149
	v_lshrrev_b32_e32 v81, 26, v38                             // 000000375C7C: 32A24C9A
	v_lshlrev_b32_e32 v82, 4, v39                              // 000000375C80: 30A44E84
	v_lshlrev_b32_e32 v90, 2, v39                              // 000000375C84: 30B44E82
	v_and_or_b32 v110, 0xffff0000, v75, v35                    // 000000375C88: D657006E 048E96FF FFFF0000
	.long 0x7e4639a6                                           // 000000375C94: 7E4639A6
	v_add3_u32 v73, v73, v113, 0x7fff                          // 000000375C98: D6550049 03FEE349 00007FFF
	v_and_b32_e32 v85, 48, v85                                 // 000000375CA4: 36AAAAB0
	v_and_b32_e32 v1, 48, v1                                   // 000000375CA8: 360202B0
	v_lshrrev_b32_e32 v88, 4, v3                               // 000000375CAC: 32B00684
	v_and_b32_e32 v95, 48, v35                                 // 000000375CB0: 36BE46B0
	v_lshrrev_b32_e32 v80, 8, v3                               // 000000375CB4: 32A00688
	v_and_b32_e32 v84, 48, v39                                 // 000000375CB8: 36A84EB0
	v_lshrrev_b32_e32 v78, 2, v39                              // 000000375CBC: 329C4E82
	v_and_or_b32 v76, v76, 15, v85                             // 000000375CC0: D657004C 05551F4C
	v_and_or_b32 v79, v79, 15, v95                             // 000000375CC8: D657004F 057D1F4F
	v_and_or_b32 v1, v86, 15, v1                               // 000000375CD0: D6570001 04051F56
	v_lshrrev_b32_e32 v77, 12, v3                              // 000000375CD8: 329A068C
	v_and_or_b32 v80, v80, 15, v84                             // 000000375CDC: D6570050 05511F50
	v_cvt_f32_ubyte0_e32 v76, v76                              // 000000375CE4: 7E98234C
	v_cvt_f32_ubyte0_e32 v79, v79                              // 000000375CE8: 7E9E234F
	v_cvt_f32_ubyte0_e32 v1, v1                                // 000000375CEC: 7E022301
	v_lshrrev_b32_e32 v89, 4, v39                              // 000000375CF0: 32B24E84
	v_lshrrev_b32_e32 v91, 6, v39                              // 000000375CF4: 32B64E86
	v_fma_mix_f32 v76, v76, v72, v72 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000375CF8: CC20604C 1522914C
	v_fma_mix_f32 v79, v79, v72, v72 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000375D00: CC20604F 1522914F
	v_fma_mix_f32 v1, v1, v72, v72 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000375D08: CC206001 15229101
	v_lshrrev_b32_e32 v75, 8, v39                              // 000000375D10: 32964E88
	v_lshrrev_b32_e32 v92, 20, v3                              // 000000375D14: 32B80694
	v_bfe_u32 v84, v76, 16, 1                                  // 000000375D18: D6100054 0205214C
	v_bfe_u32 v107, v79, 16, 1                                 // 000000375D20: D610006B 0205214F
	v_lshrrev_b32_e32 v93, 24, v3                              // 000000375D28: 32BA0698
	v_and_b32_e32 v75, 48, v75                                 // 000000375D2C: 369696B0
	v_lshrrev_b32_e32 v94, 28, v3                              // 000000375D30: 32BC069C
	v_add3_u32 v76, v76, v84, 0x7fff                           // 000000375D34: D655004C 03FEA94C 00007FFF
	v_add3_u32 v79, v79, v107, 0x7fff                          // 000000375D40: D655004F 03FED74F 00007FFF
	v_lshrrev_b32_e32 v96, 10, v39                             // 000000375D4C: 32C04E8A
	v_and_or_b32 v75, v93, 15, v75                             // 000000375D50: D657004B 052D1F5D
	v_lshrrev_b32_e32 v112, 22, v39                            // 000000375D58: 32E04E96
	v_lshrrev_b32_e32 v111, 20, v4                             // 000000375D5C: 32DE0894
	.long 0x7e4639cf                                           // 000000375D60: 7E4639CF
	v_and_or_b32 v79, v81, 48, v87                             // 000000375D64: D657004F 055D6151
	v_and_b32_e32 v81, 48, v82                                 // 000000375D6C: 36A2A4B0
	v_and_b32_e32 v82, 48, v90                                 // 000000375D70: 36A4B4B0
	v_cvt_f32_ubyte0_e32 v75, v75                              // 000000375D74: 7E96234B
	v_and_or_b32 v113, 0xffff0000, v73, v35                    // 000000375D78: D6570071 048E92FF FFFF0000
	.long 0x7e463982                                           // 000000375D84: 7E463982
	v_and_b32_e32 v73, 48, v78                                 // 000000375D88: 36929CB0
	v_cvt_f32_ubyte0_e32 v78, v79                              // 000000375D8C: 7E9C234F
	v_and_or_b32 v79, v3, 15, v81                              // 000000375D90: D657004F 05451F03
	v_and_or_b32 v81, v88, 15, v82                             // 000000375D98: D6570051 05491F58
	v_and_or_b32 v74, v35, 15, v74                             // 000000375DA0: D657004A 05291F23
	v_and_or_b32 v73, v77, 15, v73                             // 000000375DA8: D6570049 05251F4D
	v_cvt_f32_ubyte0_e32 v77, v80                              // 000000375DB0: 7E9A2350
	v_cvt_f32_ubyte0_e32 v79, v79                              // 000000375DB4: 7E9E234F
	v_cvt_f32_ubyte0_e32 v80, v81                              // 000000375DB8: 7EA02351
	v_cvt_f32_ubyte0_e32 v74, v74                              // 000000375DBC: 7E94234A
	v_fma_mix_f32 v78, v78, v72, v72 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000375DC0: CC20604E 1522914E
	v_fma_mix_f32 v77, v77, v72, v72 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000375DC8: CC20604D 1522914D
	v_fma_mix_f32 v79, v79, v72, v72 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000375DD0: CC20604F 1522914F
	v_cvt_f32_ubyte0_e32 v73, v73                              // 000000375DD8: 7E922349
	v_fma_mix_f32 v74, v74, v72, v72 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000375DDC: CC20604A 1522914A
	v_bfe_u32 v82, v78, 16, 1                                  // 000000375DE4: D6100052 0205214E
	v_fma_mix_f32 v80, v80, v72, v72 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000375DEC: CC206050 15229150
	v_fma_mix_f32 v75, v75, v72, v72 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000375DF4: CC20604B 1522914B
	v_fma_mix_f32 v73, v73, v72, v72 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000375DFC: CC206049 15229149
	v_bfe_u32 v81, v74, 16, 1                                  // 000000375E04: D6100051 0205214A
	v_add3_u32 v78, v78, v82, 0x7fff                           // 000000375E0C: D655004E 03FEA54E 00007FFF
	v_lshrrev_b32_e32 v97, 12, v38                             // 000000375E18: 32C24C8C
	v_lshrrev_b32_e32 v95, 12, v39                             // 000000375E1C: 32BE4E8C
	v_lshrrev_b32_e32 v100, 18, v39                            // 000000375E20: 32C84E92
	v_add3_u32 v74, v74, v81, 0x7fff                           // 000000375E24: D655004A 03FEA34A 00007FFF
	v_bfe_u32 v81, v1, 16, 1                                   // 000000375E30: D6100051 02052101
	v_lshrrev_b32_e32 v101, 14, v39                            // 000000375E38: 32CA4E8E
	v_lshrrev_b32_e32 v102, 8, v4                              // 000000375E3C: 32CC0888
	v_lshrrev_b32_e32 v104, 20, v39                            // 000000375E40: 32D04E94
	.long 0x7e4639ca                                           // 000000375E44: 7E4639CA
	v_add3_u32 v1, v1, v81, 0x7fff                             // 000000375E48: D6550001 03FEA301 00007FFF
	v_bfe_u32 v74, v79, 16, 1                                  // 000000375E54: D610004A 0205214F
	v_bfe_u32 v81, v80, 16, 1                                  // 000000375E5C: D6100051 02052150
	v_lshrrev_b32_e32 v108, 24, v39                            // 000000375E64: 32D84E98
	v_and_or_b32 v114, 0xffff0000, v76, v35                    // 000000375E68: D6570072 048E98FF FFFF0000
	.long 0x7e463981                                           // 000000375E74: 7E463981
	v_add3_u32 v1, v79, v74, 0x7fff                            // 000000375E78: D6550001 03FE954F 00007FFF
	v_bfe_u32 v74, v77, 16, 1                                  // 000000375E84: D610004A 0205214D
	v_bfe_u32 v76, v73, 16, 1                                  // 000000375E8C: D610004C 02052149
	v_add3_u32 v79, v80, v81, 0x7fff                           // 000000375E94: D655004F 03FEA350 00007FFF
	v_and_or_b32 v115, 0xffff0000, v78, v35                    // 000000375EA0: D6570073 048E9CFF FFFF0000
	.long 0x7e463981                                           // 000000375EAC: 7E463981
	v_add3_u32 v1, v77, v74, 0x7fff                            // 000000375EB0: D6550001 03FE954D 00007FFF
	v_add3_u32 v73, v73, v76, 0x7fff                           // 000000375EBC: D6550049 03FE9949 00007FFF
	v_and_b32_e32 v76, 48, v89                                 // 000000375EC8: 3698B2B0
	v_and_b32_e32 v78, 48, v91                                 // 000000375ECC: 369CB6B0
	v_and_or_b32 v116, 0xffff0000, v79, v35                    // 000000375ED0: D6570074 048E9EFF FFFF0000
	.long 0x7e463981                                           // 000000375EDC: 7E463981
	v_and_b32_e32 v81, 48, v112                                // 000000375EE0: 36A2E0B0
	v_lshrrev_b32_e32 v77, 28, v4                              // 000000375EE4: 329A089C
	v_and_or_b32 v78, v92, 15, v78                             // 000000375EE8: D657004E 05391F5C
	v_lshrrev_b32_e32 v1, 26, v39                              // 000000375EF0: 32024E9A
	v_and_or_b32 v117, 0xffff0000, v73, v35                    // 000000375EF4: D6570075 048E92FF FFFF0000
	.long 0x7e463983                                           // 000000375F00: 7E463983
	v_and_or_b32 v3, v96, 48, v94                              // 000000375F04: D6570003 05796160
	v_cvt_f32_ubyte0_e32 v78, v78                              // 000000375F0C: 7E9C234E
	v_and_or_b32 v1, v1, 48, v77                               // 000000375F10: D6570001 05356101
	v_lshrrev_b32_e32 v103, 12, v4                             // 000000375F18: 32CE088C
	v_and_or_b32 v76, v35, 15, v76                             // 000000375F1C: D657004C 05311F23
	v_cvt_f32_ubyte0_e32 v3, v3                                // 000000375F24: 7E062303
	v_fma_mix_f32 v78, v78, v72, v72 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000375F28: CC20604E 1522914E
	v_and_b32_e32 v73, 48, v100                                // 000000375F30: 3692C8B0
	v_and_b32_e32 v79, 48, v97                                 // 000000375F34: 369EC2B0
	v_cvt_f32_ubyte0_e32 v76, v76                              // 000000375F38: 7E98234C
	v_fma_mix_f32 v3, v3, v72, v72 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000375F3C: CC206003 15229103
	v_bfe_u32 v85, v78, 16, 1                                  // 000000375F44: D6100055 0205214E
	v_cvt_f32_ubyte0_e32 v1, v1                                // 000000375F4C: 7E022301
	v_and_b32_e32 v99, 15, v4                                  // 000000375F50: 36C6088F
	v_fma_mix_f32 v76, v76, v72, v72 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000375F54: CC20604C 1522914C
	v_bfe_u32 v86, v3, 16, 1                                   // 000000375F5C: D6100056 02052103
	v_add3_u32 v78, v78, v85, 0x7fff                           // 000000375F64: D655004E 03FEAB4E 00007FFF
	v_lshrrev_b32_e32 v98, 4, v2                               // 000000375F70: 32C40484
	v_lshrrev_b32_e32 v83, 4, v4                               // 000000375F74: 32A60884
	v_bfe_u32 v84, v76, 16, 1                                  // 000000375F78: D6100054 0205214C
	v_add3_u32 v3, v3, v86, 0x7fff                             // 000000375F80: D6550003 03FEAD03 00007FFF
	v_lshrrev_b32_e32 v74, 24, v4                              // 000000375F8C: 32940898
	v_and_b32_e32 v77, 48, v101                                // 000000375F90: 369ACAB0
	v_and_b32_e32 v82, 48, v108                                // 000000375F94: 36A4D8B0
	v_add3_u32 v76, v76, v84, 0x7fff                           // 000000375F98: D655004C 03FEA94C 00007FFF
	v_bfe_u32 v84, v75, 16, 1                                  // 000000375FA4: D6100054 0205214B
	v_and_or_b32 v73, v103, 15, v73                            // 000000375FAC: D6570049 05251F67
	v_and_or_b32 v2, v2, 15, v79                               // 000000375FB4: D6570002 053D1F02
	v_fma_mix_f32 v119, v1, v72, v72 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000375FBC: CC206077 15229101
	.long 0x7e4639cc                                           // 000000375FC4: 7E4639CC
	v_add3_u32 v75, v75, v84, 0x7fff                           // 000000375FC8: D655004B 03FEA94B 00007FFF
	v_and_or_b32 v76, v111, 15, v81                            // 000000375FD4: D657004C 05451F6F
	v_and_or_b32 v80, v95, 48, v99                             // 000000375FDC: D6570050 058D615F
	v_and_or_b32 v74, v74, 15, v82                             // 000000375FE4: D657004A 05491F4A
	v_and_or_b32 v112, 0xffff0000, v78, v35                    // 000000375FEC: D6570070 048E9CFF FFFF0000
	.long 0x7e4639cb                                           // 000000375FF8: 7E4639CB
	v_and_or_b32 v75, v83, 15, v77                             // 000000375FFC: D657004B 05351F53
	v_cvt_f32_ubyte0_e32 v2, v2                                // 000000376004: 7E042302
	v_cvt_f32_ubyte0_e32 v77, v80                              // 000000376008: 7E9A2350
	v_lshrrev_b32_e32 v38, 14, v38                             // 00000037600C: 324C4C8E
	v_and_or_b32 v111, 0xffff0000, v3, v35                     // 000000376010: D657006F 048E06FF FFFF0000
	.long 0x7e4639a7                                           // 00000037601C: 7E4639A7
	v_cvt_f32_ubyte0_e32 v3, v73                               // 000000376020: 7E062349
	v_cvt_f32_ubyte0_e32 v85, v75                              // 000000376024: 7EAA234B
	v_cvt_f32_ubyte0_e32 v86, v76                              // 000000376028: 7EAC234C
	v_cvt_f32_ubyte0_e32 v87, v74                              // 00000037602C: 7EAE234A
	v_and_b32_e32 v39, 48, v35                                 // 000000376030: 364E46B0
	v_fma_mix_f32 v3, v3, v72, v72 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000376034: CC206003 15229103
	v_fma_mix_f32 v118, v77, v72, v72 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000037603C: CC206076 1522914D
	s_clause 0x2                                               // 000000376044: BF850002
	global_load_b128 v[73:76], v[44:45], off offset:16         // 000000376048: DC5E0010 497C002C
	global_load_b128 v[77:80], v[44:45], off offset:32         // 000000376050: DC5E0020 4D7C002C
	global_load_b128 v[81:84], v[44:45], off offset:48         // 000000376058: DC5E0030 517C002C
	v_and_b32_e32 v38, 48, v38                                 // 000000376060: 364C4CB0
	v_and_or_b32 v39, v102, 15, v39                            // 000000376064: D6570027 049D1F66
	v_fma_mix_f32 v120, v86, v72, v72 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000037606C: CC206078 15229156
	v_fma_mix_f32 v121, v87, v72, v72 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000376074: CC206079 15229157
	v_bfe_u32 v101, v3, 16, 1                                  // 00000037607C: D6100065 02052103
	global_load_b128 v[93:96], v[46:47], off offset:16         // 000000376084: DC5E0010 5D7C002E
	v_cvt_f32_ubyte0_e32 v1, v39                               // 00000037608C: 7E022327
	v_fma_mix_f32 v39, v2, v72, v72 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000376090: CC206027 15229102
	v_fma_mix_f32 v45, v85, v72, v72 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000376098: CC20602D 15229155
	s_clause 0x1                                               // 0000003760A0: BF850001
	global_load_b128 v[85:88], v[40:41], off offset:16         // 0000003760A4: DC5E0010 557C0028
	global_load_b128 v[89:92], v[42:43], off offset:16         // 0000003760AC: DC5E0010 597C002A
	v_and_b32_e32 v108, 48, v104                               // 0000003760B4: 36D8D0B0
	v_fma_mix_f32 v1, v1, v72, v72 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003760B8: CC206001 15229101
	v_and_or_b32 v38, v98, 15, v38                             // 0000003760C0: D6570026 04991F62
	global_load_b128 v[97:100], v[48:49], off offset:16        // 0000003760C8: DC5E0010 617C0030
	v_add3_u32 v3, v3, v101, 0x7fff                            // 0000003760D0: D6550003 03FECB03 00007FFF
	global_load_b128 v[101:104], v[50:51], off offset:16       // 0000003760DC: DC5E0010 657C0032
	v_bfe_u32 v2, v1, 16, 1                                    // 0000003760E4: D6100002 02052101
	v_cvt_f32_ubyte0_e32 v38, v38                              // 0000003760EC: 7E4C2326
	v_bfe_u32 v44, v118, 16, 1                                 // 0000003760F0: D610002C 02052176
	.long 0x7fd639a3                                           // 0000003760F8: 7FD639A3
	v_bfe_u32 v122, v119, 16, 1                                // 0000003760FC: D610007A 02052177
	v_add3_u32 v1, v1, v2, 0x7fff                              // 000000376104: D6550001 03FE0501 00007FFF
	v_fma_mix_f32 v38, v38, v72, v72 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000376110: CC206026 15229126
	v_add3_u32 v118, v118, v44, 0x7fff                         // 000000376118: D6550076 03FE5976 00007FFF
	v_bfe_u32 v44, v45, 16, 1                                  // 000000376124: D610002C 0205212D
	v_add3_u32 v119, v119, v122, 0x7fff                        // 00000037612C: D6550077 03FEF577 00007FFF
	.long 0x7e463981                                           // 000000376138: 7E463981
	v_bfe_u32 v122, v120, 16, 1                                // 00000037613C: D610007A 02052178
	v_add_nc_u32_e32 v34, 0x400, v34                           // 000000376144: 4A4444FF 00000400
	v_add3_u32 v131, v45, v44, 0x7fff                          // 00000037614C: D6550083 03FE592D 00007FFF
	v_add_nc_u32_e32 v68, 0x200, v68                           // 000000376158: 4A8888FF 00000200
	v_and_or_b32 v123, 0xffff0000, v3, v35                     // 000000376160: D657007B 048E06FF FFFF0000
	.long 0x7e463984                                           // 00000037616C: 7E463984
	v_add3_u32 v120, v120, v122, 0x7fff                        // 000000376170: D6550078 03FEF578 00007FFF
	v_add_nc_u32_e32 v69, 0x100, v69                           // 00000037617C: 4A8A8AFF 00000100
	v_add_nc_u32_e32 v70, 64, v70                              // 000000376184: 4A8C8CC0
	s_and_b32 s0, exec_lo, vcc_lo                              // 000000376188: 8B006A7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000037618C: BF8700B9
	s_or_b32 s15, s0, s15                                      // 000000376190: 8C0F0F00
	s_waitcnt vmcnt(13)                                        // 000000376194: BF8937F7
	v_dot2_f32_bf16 v2, v9, v105, 0                            // 000000376198: CC1A4002 1A02D309
	v_dot2_f32_bf16 v1, v10, v106, v2                          // 0000003761A0: CC1A4001 1C0AD50A
	s_waitcnt vmcnt(12)                                        // 0000003761A8: BF8933F7
	v_dot2_f32_bf16 v9, v17, v105, 0                           // 0000003761AC: CC1A4009 1A02D311
	s_waitcnt vmcnt(11)                                        // 0000003761B4: BF892FF7
	v_dot2_f32_bf16 v2, v13, v105, 0                           // 0000003761B8: CC1A4002 1A02D30D
	v_dot2_f32_bf16 v10, v11, v109, v1                         // 0000003761C0: CC1A400A 1C06DB0B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003761C8: BF870193
	v_dot2_f32_bf16 v9, v18, v106, v9                          // 0000003761CC: CC1A4009 1C26D512
	v_dot2_f32_bf16 v11, v14, v106, v2                         // 0000003761D4: CC1A400B 1C0AD50E
	s_waitcnt vmcnt(10)                                        // 0000003761DC: BF892BF7
	v_dot2_f32_bf16 v17, v21, v105, 0                          // 0000003761E0: CC1A4011 1A02D315
	s_waitcnt vmcnt(9)                                         // 0000003761E8: BF8927F7
	v_dot2_f32_bf16 v18, v25, v105, 0                          // 0000003761EC: CC1A4012 1A02D319
	global_load_b128 v[1:4], v[40:41], off offset:32           // 0000003761F4: DC5E0020 017C0028
	v_dot2_f32_bf16 v13, v19, v109, v9                         // 0000003761FC: CC1A400D 1C26DB13
	v_dot2_f32_bf16 v14, v15, v109, v11                        // 000000376204: CC1A400E 1C2EDB0F
	v_and_or_b32 v19, v35, 15, v108                            // 00000037620C: D6570013 05B11F23
	v_dot2_f32_bf16 v17, v22, v106, v17                        // 000000376214: CC1A4011 1C46D516
	v_dot2_f32_bf16 v18, v26, v106, v18                        // 00000037621C: CC1A4012 1C4AD51A
	v_dot2_f32_bf16 v124, v12, v110, v10                       // 000000376224: CC1A407C 1C2ADD0C
	global_load_b128 v[9:12], v[42:43], off offset:32          // 00000037622C: DC5E0020 097C002A
	v_dot2_f32_bf16 v125, v20, v110, v13                       // 000000376234: CC1A407D 1C36DD14
	v_dot2_f32_bf16 v126, v16, v110, v14                       // 00000037623C: CC1A407E 1C3ADD10
	global_load_b128 v[13:16], v[46:47], off offset:32         // 000000376244: DC5E0020 0D7C002E
	v_cvt_f32_ubyte0_e32 v19, v19                              // 00000037624C: 7E262313
	v_dot2_f32_bf16 v17, v23, v109, v17                        // 000000376250: CC1A4011 1C46DB17
	v_dot2_f32_bf16 v21, v27, v109, v18                        // 000000376258: CC1A4015 1C4ADB1B
	v_bfe_u32 v25, v39, 16, 1                                  // 000000376260: D6100019 02052127
	v_bfe_u32 v26, v38, 16, 1                                  // 000000376268: D610001A 02052126
	v_fma_mix_f32 v72, v19, v72, v72 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000376270: CC206048 15229113
	v_dot2_f32_bf16 v127, v24, v110, v17                       // 000000376278: CC1A407F 1C46DD18
	global_load_b128 v[17:20], v[48:49], off offset:32         // 000000376280: DC5E0020 117C0030
	v_dot2_f32_bf16 v128, v28, v110, v21                       // 000000376288: CC1A4080 1C56DD1C
	global_load_b128 v[21:24], v[50:51], off offset:32         // 000000376290: DC5E0020 157C0032
	v_bfe_u32 v108, v72, 16, 1                                 // 000000376298: D610006C 02052148
	v_add3_u32 v129, v39, v25, 0x7fff                          // 0000003762A0: D6550081 03FE3327 00007FFF
	v_add3_u32 v130, v38, v26, 0x7fff                          // 0000003762AC: D6550082 03FE3526 00007FFF
	s_clause 0x1                                               // 0000003762B8: BF850001
	global_load_b128 v[25:28], v[40:41], off offset:48         // 0000003762BC: DC5E0030 197C0028
	global_load_b128 v[38:41], v[42:43], off offset:48         // 0000003762C4: DC5E0030 267C002A
	v_add3_u32 v72, v72, v108, 0x7fff                          // 0000003762CC: D6550048 03FED948 00007FFF
	v_bfe_u32 v108, v121, 16, 1                                // 0000003762D8: D610006C 02052179
	.long 0xd59c086b                                           // 0000003762E0: D59C086B
	v_cndmask_b32_e32 v0, v129, v128, vcc_lo                   // 0000003762E4: 02010181
	s_clause 0x1                                               // 0000003762E8: BF850001
	global_load_b128 v[42:45], v[46:47], off offset:48         // 0000003762EC: DC5E0030 2A7C002E
	global_load_b128 v[46:49], v[48:49], off offset:48         // 0000003762F4: DC5E0030 2E7C0030
	s_waitcnt vmcnt(17)                                        // 0000003762FC: BF8947F7
	v_dot2_f32_bf16 v29, v29, v105, 0                          // 000000376300: CC1A401D 1A02D31D
	.long 0x7e4639c8                                           // 000000376308: 7E4639C8
	v_add3_u32 v72, v121, v108, 0x7fff                         // 00000037630C: D6550048 03FED979 00007FFF
	v_and_or_b32 v121, 0xffff0000, v130, v107                  // 000000376318: D6570079 05AF04FF FFFF0000
	s_delay_alu instid0(VALU_DEP_4)                            // 000000376324: BF870004
	v_dot2_f32_bf16 v29, v30, v106, v29                        // 000000376328: CC1A401D 1C76D51E
	global_load_b128 v[105:108], v[50:51], off offset:48       // 000000376330: DC5E0030 697C0032
	v_and_or_b32 v120, 0xffff0000, v120, v35                   // 000000376338: D6570078 048EF0FF FFFF0000
	.long 0x7e4639c8                                           // 000000376344: 7E4639C8
	.long 0x7f3c39a3                                           // 000000376348: 7F3C39A3
	v_dot2_f32_bf16 v29, v31, v109, v29                        // 00000037634C: CC1A401D 1C76DB1F
	.long 0x7e3c39f6                                           // 000000376354: 7E3C39F6
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000376358: BF870194
	v_and_or_b32 v31, 0xffff0000, v119, v35                    // 00000037635C: D657001F 048EEEFF FFFF0000
	v_dot2_f32_bf16 v29, v32, v110, v29                        // 000000376368: CC1A401D 1C76DD20
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000376370: BF8700B3
	v_and_or_b32 v30, 0xffff0000, v131, v30                    // 000000376374: D657001E 047B06FF FFFF0000
	s_waitcnt vmcnt(17)                                        // 000000376380: BF8947F7
	v_dot2_f32_bf16 v50, v73, v121, v124                       // 000000376384: CC1A4032 1DF2F349
	v_dot2_f32_bf16 v35, v74, v113, v50                        // 00000037638C: CC1A4023 1CCAE34A
	s_waitcnt vmcnt(14)                                        // 000000376394: BF893BF7
	v_dot2_f32_bf16 v32, v93, v121, v127                       // 000000376398: CC1A4020 1DFEF35D
	s_delay_alu instid0(VALU_DEP_2)                            // 0000003763A0: BF870002
	v_dot2_f32_bf16 v35, v75, v114, v35                        // 0000003763A4: CC1A4023 1C8EE54B
	s_waitcnt vmcnt(13)                                        // 0000003763AC: BF8937F7
	v_dot2_f32_bf16 v50, v85, v121, v125                       // 0000003763B0: CC1A4032 1DF6F355
	s_waitcnt vmcnt(12)                                        // 0000003763B8: BF8933F7
	v_dot2_f32_bf16 v51, v89, v121, v126                       // 0000003763BC: CC1A4033 1DFAF359
	v_dot2_f32_bf16 v32, v94, v113, v32                        // 0000003763C4: CC1A4020 1C82E35E
	v_dot2_f32_bf16 v35, v76, v115, v35                        // 0000003763CC: CC1A4023 1C8EE74C
	v_dot2_f32_bf16 v50, v86, v113, v50                        // 0000003763D4: CC1A4032 1CCAE356
	s_delay_alu instid0(VALU_DEP_4)                            // 0000003763DC: BF870004
	v_dot2_f32_bf16 v51, v90, v113, v51                        // 0000003763E0: CC1A4033 1CCEE35A
	s_waitcnt vmcnt(11)                                        // 0000003763E8: BF892FF7
	v_dot2_f32_bf16 v72, v97, v121, v128                       // 0000003763EC: CC1A4048 1E02F361
	s_waitcnt vmcnt(10)                                        // 0000003763F4: BF892BF7
	v_dot2_f32_bf16 v29, v101, v121, v29                       // 0000003763F8: CC1A401D 1C76F365
	v_dot2_f32_bf16 v32, v95, v114, v32                        // 000000376400: CC1A4020 1C82E55F
	v_dot2_f32_bf16 v50, v87, v114, v50                        // 000000376408: CC1A4032 1CCAE557
	v_dot2_f32_bf16 v51, v91, v114, v51                        // 000000376410: CC1A4033 1CCEE55B
	v_dot2_f32_bf16 v72, v98, v113, v72                        // 000000376418: CC1A4048 1D22E362
	v_dot2_f32_bf16 v29, v102, v113, v29                       // 000000376420: CC1A401D 1C76E366
	v_dot2_f32_bf16 v32, v96, v115, v32                        // 000000376428: CC1A4020 1C82E760
	v_dot2_f32_bf16 v50, v88, v115, v50                        // 000000376430: CC1A4032 1CCAE758
	v_dot2_f32_bf16 v51, v92, v115, v51                        // 000000376438: CC1A4033 1CCEE75C
	v_dot2_f32_bf16 v72, v99, v114, v72                        // 000000376440: CC1A4048 1D22E563
	v_dot2_f32_bf16 v29, v103, v114, v29                       // 000000376448: CC1A401D 1C76E567
	v_dot2_f32_bf16 v35, v77, v116, v35                        // 000000376450: CC1A4023 1C8EE94D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000376458: BF870193
	v_dot2_f32_bf16 v72, v100, v115, v72                       // 00000037645C: CC1A4048 1D22E764
	v_dot2_f32_bf16 v29, v104, v115, v29                       // 000000376464: CC1A401D 1C76E768
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000037646C: BF8700B3
	v_dot2_f32_bf16 v35, v78, v117, v35                        // 000000376470: CC1A4023 1C8EEB4E
	s_waitcnt vmcnt(9)                                         // 000000376478: BF8927F7
	v_dot2_f32_bf16 v1, v1, v116, v50                          // 00000037647C: CC1A4001 1CCAE901
	v_dot2_f32_bf16 v1, v2, v117, v1                           // 000000376484: CC1A4001 1C06EB02
	s_waitcnt vmcnt(8)                                         // 00000037648C: BF8923F7
	v_dot2_f32_bf16 v9, v9, v116, v51                          // 000000376490: CC1A4009 1CCEE909
	s_waitcnt vmcnt(7)                                         // 000000376498: BF891FF7
	v_dot2_f32_bf16 v13, v13, v116, v32                        // 00000037649C: CC1A400D 1C82E90D
	v_dot2_f32_bf16 v1, v3, v112, v1                           // 0000003764A4: CC1A4001 1C06E103
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000003764AC: BF870223
	v_dot2_f32_bf16 v2, v10, v117, v9                          // 0000003764B0: CC1A4002 1C26EB0A
	v_dot2_f32_bf16 v32, v79, v112, v35                        // 0000003764B8: CC1A4020 1C8EE14F
	v_dot2_f32_bf16 v9, v14, v117, v13                         // 0000003764C0: CC1A4009 1C36EB0E
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003764C8: BF870214
	v_dot2_f32_bf16 v1, v4, v111, v1                           // 0000003764CC: CC1A4001 1C06DF04
	v_dot2_f32_bf16 v2, v11, v112, v2                          // 0000003764D4: CC1A4002 1C0AE10B
	s_waitcnt vmcnt(6)                                         // 0000003764DC: BF891BF7
	v_dot2_f32_bf16 v10, v17, v116, v72                        // 0000003764E0: CC1A400A 1D22E911
	v_dot2_f32_bf16 v14, v80, v111, v32                        // 0000003764E8: CC1A400E 1C82DF50
	s_waitcnt vmcnt(5)                                         // 0000003764F0: BF8917F7
	v_dot2_f32_bf16 v13, v21, v116, v29                        // 0000003764F4: CC1A400D 1C76E915
	v_dot2_f32_bf16 v3, v15, v112, v9                          // 0000003764FC: CC1A4003 1C26E10F
	v_dot2_f32_bf16 v2, v12, v111, v2                          // 000000376504: CC1A4002 1C0ADF0C
	v_dot2_f32_bf16 v9, v18, v117, v10                         // 00000037650C: CC1A4009 1C2AEB12
	v_dot2_f32_bf16 v11, v81, v30, v14                         // 000000376514: CC1A400B 1C3A3D51
	v_dot2_f32_bf16 v10, v22, v117, v13                        // 00000037651C: CC1A400A 1C36EB16
	v_dot2_f32_bf16 v3, v16, v111, v3                          // 000000376524: CC1A4003 1C0EDF10
	s_waitcnt vmcnt(4)                                         // 00000037652C: BF8913F7
	v_dot2_f32_bf16 v1, v25, v30, v1                           // 000000376530: CC1A4001 1C063D19
	v_dot2_f32_bf16 v4, v19, v112, v9                          // 000000376538: CC1A4004 1C26E113
	s_waitcnt vmcnt(3)                                         // 000000376540: BF890FF7
	v_dot2_f32_bf16 v2, v38, v30, v2                           // 000000376544: CC1A4002 1C0A3D26
	v_dot2_f32_bf16 v9, v23, v112, v10                         // 00000037654C: CC1A4009 1C2AE117
	s_waitcnt vmcnt(2)                                         // 000000376554: BF890BF7
	v_dot2_f32_bf16 v3, v42, v30, v3                           // 000000376558: CC1A4003 1C0E3D2A
	v_dot2_f32_bf16 v10, v82, v123, v11                        // 000000376560: CC1A400A 1C2EF752
	v_dot2_f32_bf16 v4, v20, v111, v4                          // 000000376568: CC1A4004 1C12DF14
	v_dot2_f32_bf16 v1, v26, v123, v1                          // 000000376570: CC1A4001 1C06F71A
	v_dot2_f32_bf16 v9, v24, v111, v9                          // 000000376578: CC1A4009 1C26DF18
	v_dot2_f32_bf16 v2, v39, v123, v2                          // 000000376580: CC1A4002 1C0AF727
	v_dot2_f32_bf16 v3, v43, v123, v3                          // 000000376588: CC1A4003 1C0EF72B
	s_waitcnt vmcnt(1)                                         // 000000376590: BF8907F7
	v_dot2_f32_bf16 v4, v46, v30, v4                           // 000000376594: CC1A4004 1C123D2E
	v_dot2_f32_bf16 v10, v83, v120, v10                        // 00000037659C: CC1A400A 1C2AF153
	s_waitcnt vmcnt(0)                                         // 0000003765A4: BF8903F7
	v_dot2_f32_bf16 v9, v105, v30, v9                          // 0000003765A8: CC1A4009 1C263D69
	v_dot2_f32_bf16 v1, v27, v120, v1                          // 0000003765B0: CC1A4001 1C06F11B
	v_dot2_f32_bf16 v2, v40, v120, v2                          // 0000003765B8: CC1A4002 1C0AF128
	v_dot2_f32_bf16 v4, v47, v123, v4                          // 0000003765C0: CC1A4004 1C12F72F
	v_dot2_f32_bf16 v3, v44, v120, v3                          // 0000003765C8: CC1A4003 1C0EF12C
	v_dot2_f32_bf16 v9, v106, v123, v9                         // 0000003765D0: CC1A4009 1C26F76A
	v_dot2_f32_bf16 v10, v84, v31, v10                         // 0000003765D8: CC1A400A 1C2A3F54
	v_dot2_f32_bf16 v1, v28, v31, v1                           // 0000003765E0: CC1A4001 1C063F1C
	v_dot2_f32_bf16 v4, v48, v120, v4                          // 0000003765E8: CC1A4004 1C12F130
	v_dot2_f32_bf16 v2, v41, v31, v2                           // 0000003765F0: CC1A4002 1C0A3F29
	v_dot2_f32_bf16 v9, v107, v120, v9                         // 0000003765F8: CC1A4009 1C26F16B
	v_dot2_f32_bf16 v3, v45, v31, v3                           // 000000376600: CC1A4003 1C0E3F2D
	v_add_f32_e32 v63, v63, v10                                // 000000376608: 067E153F
	v_dot2_f32_bf16 v4, v49, v31, v4                           // 00000037660C: CC1A4004 1C123F31
	v_add_f32_e32 v62, v62, v1                                 // 000000376614: 067C033E
	v_dot2_f32_bf16 v9, v108, v31, v9                          // 000000376618: CC1A4009 1C263F6C
	v_dual_add_f32 v61, v61, v2 :: v_dual_add_f32 v60, v60, v3 // 000000376620: C908053D 3D3C073C
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000376628: BF870224
	v_add_f32_e32 v59, v59, v4                                 // 00000037662C: 0676093B
	v_mov_b32_e32 v72, v71                                     // 000000376630: 7E900347
	v_add_f32_e32 v55, v55, v9                                 // 000000376634: 066E1337
	v_dual_mov_b32 v39, v37 :: v_dual_mov_b32 v38, v36         // 000000376638: CA100125 27260124
	v_dual_mov_b32 v4, v8 :: v_dual_mov_b32 v3, v7             // 000000376640: CA100108 04020107
	v_dual_mov_b32 v2, v6 :: v_dual_mov_b32 v1, v5             // 000000376648: CA100106 02000105
	s_and_not1_b32 exec_lo, exec_lo, s15                       // 000000376650: 917E0F7E
	s_cbranch_execz 39                                         // 000000376654: BFA50027 <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi6ELi32ELi2EEEvNS0_5LqGrpEPKtl+0x10f4>
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000376658: BF870111
	v_dual_mov_b32 v5, v1 :: v_dual_add_nc_u32 v56, 32, v56    // 00000037665C: CA200101 053870A0
	v_dual_mov_b32 v6, v2 :: v_dual_mov_b32 v7, v3             // 000000376664: CA100102 06060103
	v_dual_mov_b32 v8, v4 :: v_dual_mov_b32 v37, v39           // 00000037666C: CA100104 08240127
	v_mov_b32_e32 v36, v38                                     // 000000376674: 7E480326
	s_mov_b32 s20, exec_lo                                     // 000000376678: BE94007E
	v_cmp_ge_i32_e32 vcc_lo, v56, v57                          // 00000037667C: 7C8C7338
	.long 0xd4c1007e                                           // 000000376680: D4C1007E
	v_cndmask_b32_e32 v1, v56, v57, vcc_lo                     // 000000376684: 02027338
	s_cbranch_execz 64714                                      // 000000376688: BFA5FCCA <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi6ELi32ELi2EEEvNS0_5LqGrpEPKtl+0x3b4>
	v_and_b32_e32 v7, -4, v70                                  // 00000037668C: 360E8CC4
	v_ashrrev_i32_e32 v6, 31, v68                              // 000000376690: 340C889F
	v_ashrrev_i32_e32 v8, 31, v69                              // 000000376694: 34108A9F
	.long 0xd7000005                                           // 000000376698: D7000005
	v_cndmask_b32_e32 v1, v33, v68, vcc_lo                     // 00000037669C: 02028921
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003766A0: BF870214
	v_ashrrev_i32_e32 v12, 31, v7                              // 0000003766A4: 34180E9F
	v_add_co_ci_u32_e64 v6, null, v58, v6, s0                  // 0000003766A8: D5207C06 00020D3A
	.long 0xd7000009                                           // 0000003766B0: D7000009
	v_cndmask_b32_e32 v1, v64, v69, vcc_lo                     // 0000003766B4: 02028B40
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003766B8: BF8700A1
	v_add_co_ci_u32_e64 v10, null, v65, v8, s0                 // 0000003766BC: D5207C0A 00021141
	.long 0xd700000b                                           // 0000003766C4: D700000B
	v_cndmask_b32_e32 v1, v66, v7, vcc_lo                      // 0000003766C8: 02020F42
	v_add_co_ci_u32_e64 v12, null, v67, v12, s0                // 0000003766CC: D5207C0C 00021943
	s_clause 0x2                                               // 0000003766D4: BF850002
	global_load_b128 v[5:8], v[5:6], off                       // 0000003766D8: DC5E0000 057C0005
	global_load_b64 v[36:37], v[9:10], off                     // 0000003766E0: DC560000 247C0009
	global_load_b32 v71, v[11:12], off                         // 0000003766E8: DC520000 477C000B
	s_branch 64688                                             // 0000003766F0: BFA0FCB0 <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi6ELi32ELi2EEEvNS0_5LqGrpEPKtl+0x3b4>
	s_or_b32 exec_lo, exec_lo, s15                             // 0000003766F4: 8C7E0F7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000003766F8: BF8700C9
	s_or_b32 exec_lo, exec_lo, s1                              // 0000003766FC: 8C7E017E
	s_waitcnt vmcnt(2)                                         // 000000376700: BF890BF7
	.long 0xd71f0001                                           // 000000376704: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 000000376708: 020100C1
	s_mov_b32 s0, exec_lo                                      // 00000037670C: BE80007E
	v_xor_b32_e32 v2, 16, v1                                   // 000000376710: 3A040290
	v_xor_b32_e32 v8, 8, v1                                    // 000000376714: 3A100288
	v_xor_b32_e32 v14, 4, v1                                   // 000000376718: 3A1C0284
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000037671C: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 000000376720: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 000000376724: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v8                            // 000000376728: 7C9810A0
	s_delay_alu instid0(VALU_DEP_2)                            // 00000037672C: BF870002
	v_lshlrev_b32_e32 v2, 2, v2                                // 000000376730: 30040482
	ds_bpermute_b32 v5, v2, v61                                // 000000376734: DACC0000 05003D02
	s_waitcnt lgkmcnt(0)                                       // 00000037673C: BF89FC07
	v_add_f32_e32 v5, v61, v5                                  // 000000376740: 060A0B3D
	ds_bpermute_b32 v3, v2, v63                                // 000000376744: DACC0000 03003F02
	ds_bpermute_b32 v7, v2, v59                                // 00000037674C: DACC0000 07003B02
	v_cndmask_b32_e32 v8, v1, v8, vcc_lo                       // 000000376754: 02101101
	ds_bpermute_b32 v6, v2, v60                                // 000000376758: DACC0000 06003C02
	ds_bpermute_b32 v4, v2, v62                                // 000000376760: DACC0000 04003E02
	v_cmp_gt_u32_e32 vcc_lo, 32, v14                           // 000000376768: 7C981CA0
	ds_bpermute_b32 v2, v2, v55                                // 00000037676C: DACC0000 02003702
	s_waitcnt lgkmcnt(4)                                       // 000000376774: BF89FC47
	v_add_f32_e32 v3, v63, v3                                  // 000000376778: 0606073F
	s_waitcnt lgkmcnt(3)                                       // 00000037677C: BF89FC37
	v_dual_add_f32 v7, v59, v7 :: v_dual_lshlrev_b32 v8, 2, v8 // 000000376780: C9220F3B 07081082
	ds_bpermute_b32 v9, v8, v3                                 // 000000376788: DACC0000 09000308
	s_waitcnt lgkmcnt(0)                                       // 000000376790: BF89FC07
	v_add_f32_e32 v3, v3, v9                                   // 000000376794: 06061303
	ds_bpermute_b32 v13, v8, v7                                // 000000376798: DACC0000 0D000708
	v_add_f32_e32 v6, v60, v6                                  // 0000003767A0: 060C0D3C
	ds_bpermute_b32 v11, v8, v5                                // 0000003767A4: DACC0000 0B000508
	v_cndmask_b32_e32 v14, v1, v14, vcc_lo                     // 0000003767AC: 021C1D01
	s_waitcnt lgkmcnt(1)                                       // 0000003767B0: BF89FC17
	v_dual_add_f32 v4, v62, v4 :: v_dual_add_f32 v7, v7, v13   // 0000003767B4: C908093E 04061B07
	ds_bpermute_b32 v12, v8, v6                                // 0000003767BC: DACC0000 0C000608
	s_waitcnt lgkmcnt(1)                                       // 0000003767C4: BF89FC17
	v_dual_add_f32 v5, v5, v11 :: v_dual_lshlrev_b32 v14, 2, v14// 0000003767C8: C9221705 050E1C82
	ds_bpermute_b32 v10, v8, v4                                // 0000003767D0: DACC0000 0A000408
	s_waitcnt lgkmcnt(1)                                       // 0000003767D8: BF89FC17
	v_add_f32_e32 v6, v6, v12                                  // 0000003767DC: 060C1906
	ds_bpermute_b32 v12, v14, v7                               // 0000003767E0: DACC0000 0C00070E
	s_waitcnt lgkmcnt(0)                                       // 0000003767E8: BF89FC07
	v_dual_add_f32 v7, v7, v12 :: v_dual_add_f32 v4, v4, v10   // 0000003767EC: C9081907 07041504
	ds_bpermute_b32 v10, v14, v5                               // 0000003767F4: DACC0000 0A00050E
	ds_bpermute_b32 v9, v14, v4                                // 0000003767FC: DACC0000 0900040E
	s_waitcnt lgkmcnt(1)                                       // 000000376804: BF89FC17
	v_add_f32_e32 v5, v5, v10                                  // 000000376808: 060A1505
	ds_bpermute_b32 v11, v14, v6                               // 00000037680C: DACC0000 0B00060E
	s_waitcnt lgkmcnt(0)                                       // 000000376814: BF89FC07
	v_add_f32_e32 v6, v6, v11                                  // 000000376818: 060C1706
	v_add_f32_e32 v2, v55, v2                                  // 00000037681C: 06040537
	ds_bpermute_b32 v8, v8, v2                                 // 000000376820: DACC0000 08000208
	s_waitcnt lgkmcnt(0)                                       // 000000376828: BF89FC07
	v_add_f32_e32 v2, v2, v8                                   // 00000037682C: 06041102
	ds_bpermute_b32 v8, v14, v3                                // 000000376830: DACC0000 0800030E
	ds_bpermute_b32 v13, v14, v2                               // 000000376838: DACC0000 0D00020E
	v_xor_b32_e32 v14, 2, v1                                   // 000000376840: 3A1C0282
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000376844: BF8700C1
	v_cmp_gt_u32_e32 vcc_lo, 32, v14                           // 000000376848: 7C981CA0
	s_waitcnt lgkmcnt(0)                                       // 00000037684C: BF89FC07
	v_dual_add_f32 v3, v3, v8 :: v_dual_add_f32 v8, v2, v13    // 000000376850: C9081103 03081B02
	v_cndmask_b32_e32 v14, v1, v14, vcc_lo                     // 000000376858: 021C1D01
	v_lshlrev_b32_e32 v14, 2, v14                              // 00000037685C: 301C1C82
	ds_bpermute_b32 v2, v14, v3                                // 000000376860: DACC0000 0200030E
	v_add_f32_e32 v4, v4, v9                                   // 000000376868: 06081304
	ds_bpermute_b32 v10, v14, v5                               // 00000037686C: DACC0000 0A00050E
	ds_bpermute_b32 v11, v14, v6                               // 000000376874: DACC0000 0B00060E
	ds_bpermute_b32 v12, v14, v7                               // 00000037687C: DACC0000 0C00070E
	ds_bpermute_b32 v13, v14, v8                               // 000000376884: DACC0000 0D00080E
	ds_bpermute_b32 v9, v14, v4                                // 00000037688C: DACC0000 0900040E
	v_xor_b32_e32 v14, 1, v1                                   // 000000376894: 3A1C0281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000376898: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v14                           // 00000037689C: 7C981CA0
	v_cndmask_b32_e32 v1, v1, v14, vcc_lo                      // 0000003768A0: 02021D01
	s_waitcnt lgkmcnt(5)                                       // 0000003768A4: BF89FC57
	v_dual_add_f32 v1, v3, v2 :: v_dual_lshlrev_b32 v14, 2, v1 // 0000003768A8: C9220503 010E0282
	s_waitcnt lgkmcnt(0)                                       // 0000003768B0: BF89FC07
	v_dual_add_f32 v3, v7, v12 :: v_dual_add_f32 v2, v4, v9    // 0000003768B4: C9081907 03021304
	v_dual_add_f32 v4, v5, v10 :: v_dual_add_f32 v5, v6, v11   // 0000003768BC: C9081505 04041706
	v_add_f32_e32 v11, v8, v13                                 // 0000003768C4: 06161B08
	ds_bpermute_b32 v6, v14, v1                                // 0000003768C8: DACC0000 0600010E
	ds_bpermute_b32 v7, v14, v2                                // 0000003768D0: DACC0000 0700020E
	ds_bpermute_b32 v9, v14, v4                                // 0000003768D8: DACC0000 0900040E
	ds_bpermute_b32 v10, v14, v5                               // 0000003768E0: DACC0000 0A00050E
	ds_bpermute_b32 v8, v14, v3                                // 0000003768E8: DACC0000 0800030E
	ds_bpermute_b32 v12, v14, v11                              // 0000003768F0: DACC0000 0C000B0E
	v_cmpx_eq_u32_e32 0, v53                                   // 0000003768F8: 7D946A80
	s_cbranch_execz 15                                         // 0000003768FC: BFA5000F <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi6ELi32ELi2EEEvNS0_5LqGrpEPKtl+0x133c>
	s_waitcnt lgkmcnt(0)                                       // 000000376900: BF89FC07
	v_dual_add_f32 v11, v11, v12 :: v_dual_add_f32 v4, v4, v9  // 000000376904: C908190B 0B041304
	v_lshl_add_u32 v12, v52, s18, v54                          // 00000037690C: D646000C 04D82534
	v_dual_add_f32 v5, v5, v10 :: v_dual_add_f32 v2, v2, v7    // 000000376914: C9081505 05020F02
	v_dual_add_f32 v1, v1, v6 :: v_dual_add_f32 v10, v3, v8    // 00000037691C: C9080D01 010A1103
	s_delay_alu instid0(VALU_DEP_3)                            // 000000376924: BF870003
	v_mul_u32_u24_e32 v6, 24, v12                              // 000000376928: 160C1898
	ds_store_2addr_b64 v6, v[1:2], v[4:5] offset1:1            // 00000037692C: D9380100 00040106
	ds_store_b64 v6, v[10:11] offset:16                        // 000000376934: D9340010 00000A06
	s_or_b32 exec_lo, exec_lo, s0                              // 00000037693C: 8C7E007E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000376940: BF870009
	s_and_b32 s0, s17, exec_lo                                 // 000000376944: 8B007E11
	s_cselect_b32 s0, 6, 24                                    // 000000376948: 98009886
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000037694C: BF890007
	v_cmp_gt_u32_e32 vcc_lo, s0, v0                            // 000000376950: 7C980000
	s_barrier                                                  // 000000376954: BFBD0000
	buffer_gl0_inv                                             // 000000376958: E0AC0000 00000000
	s_and_saveexec_b32 s0, vcc_lo                              // 000000376960: BE80206A
	s_cbranch_execz 398                                        // 000000376964: BFA5018E <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi6ELi32ELi2EEEvNS0_5LqGrpEPKtl+0x19a0>
	.long 0xd7054000                                           // 000000376968: D7054000
	v_cndmask_b32_e32 v1, 0xab, v0, vcc_lo                     // 00000037696C: 020200FF 000000AB
	.long 0x7f063880                                           // 000000376974: 7F063880
	v_mov_b32_e32 v4, 0                                        // 000000376978: 7E080280
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000037697C: BF870093
	.long 0xd7391003                                           // 000000376980: D7391003
	v_cndmask_b32_e32 v1, 10, v0, vcc_lo                       // 000000376984: 0202008A
	.long 0xd7000001                                           // 000000376988: D7000001
	v_cndmask_b32_e32 v1, s2, v3, vcc_lo                       // 00000037698C: 02020602
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000376990: BF870091
	v_add_co_ci_u32_e64 v2, null, s3, 0, s0                    // 000000376994: D5207C02 00010003
	v_cmp_gt_i64_e32 vcc_lo, s[8:9], v[1:2]                    // 00000037699C: 7CA80208
	s_and_b32 exec_lo, exec_lo, vcc_lo                         // 0000003769A0: 8B7E6A7E
	s_cbranch_execz 382                                        // 0000003769A4: BFA5017E <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi6ELi32ELi2EEEvNS0_5LqGrpEPKtl+0x19a0>
	.long 0xd7054000                                           // 0000003769A8: D7054000
	v_cndmask_b32_e32 v0, v3, v134, vcc_lo                     // 0000003769AC: 02010D03
	v_lshlrev_b32_e32 v3, s18, v3                              // 0000003769B0: 30060612
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003769B4: BF870112
	.long 0xd7041000                                           // 0000003769B8: D7041000
	v_cndmask_b32_e32 v1, v0, v0, vcc_lo                       // 0000003769BC: 02020100
	v_mul_u32_u24_e32 v3, 24, v3                               // 0000003769C0: 16060698
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003769C4: BF870092
	v_and_b32_e32 v5, 0xff, v0                                 // 0000003769C8: 360A00FF 000000FF
	v_lshl_add_u32 v3, v5, 2, v3                               // 0000003769D0: D6460003 040D0505
	ds_load_b32 v5, v3                                         // 0000003769D8: D8D80000 05000003
	v_add_nc_u32_e32 v3, 24, v3                                // 0000003769E0: 4A060698
	s_add_i32 s16, s16, -1                                     // 0000003769E4: 8110C110
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000003769E8: BF870009
	s_cmp_eq_u32 s16, 0                                        // 0000003769EC: BF068010
	s_waitcnt lgkmcnt(0)                                       // 0000003769F0: BF89FC07
	v_add_f32_e32 v4, v4, v5                                   // 0000003769F4: 06080B04
	s_cbranch_scc0 65527                                       // 0000003769F8: BFA1FFF7 <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi6ELi32ELi2EEEvNS0_5LqGrpEPKtl+0x13d8>
	s_clause 0x1                                               // 0000003769FC: BF850001
	s_load_b64 s[2:3], s[10:11], 0x38                          // 000000376A00: F4040085 F8000038
	s_load_b64 s[0:1], s[10:11], 0x8                           // 000000376A08: F4040005 F8000008
	v_and_b32_e32 v3, 0xff, v0                                 // 000000376A10: 360600FF 000000FF
	s_mov_b32 s6, -1                                           // 000000376A18: BE8600C1
	s_mov_b32 s4, 0                                            // 000000376A1C: BE840080
	s_mov_b32 s5, 0                                            // 000000376A20: BE850080
	s_waitcnt lgkmcnt(0)                                       // 000000376A24: BF89FC07
	s_cmp_lt_i32 s3, 3                                         // 000000376A28: BF048303
	s_cbranch_scc1 183                                         // 000000376A2C: BFA200B7 <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi6ELi32ELi2EEEvNS0_5LqGrpEPKtl+0x170c>
	s_cmp_gt_i32 s3, 3                                         // 000000376A30: BF028303
	s_cbranch_scc0 117                                         // 000000376A34: BFA10075 <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi6ELi32ELi2EEEvNS0_5LqGrpEPKtl+0x160c>
	s_cmp_gt_i32 s3, 4                                         // 000000376A38: BF028403
	s_cbranch_scc0 62                                          // 000000376A3C: BFA1003E <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi6ELi32ELi2EEEvNS0_5LqGrpEPKtl+0x1538>
	s_cmp_eq_u32 s3, 5                                         // 000000376A40: BF068503
	s_mov_b32 s5, -1                                           // 000000376A44: BE8500C1
	s_cbranch_scc0 58                                          // 000000376A48: BFA1003A <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi6ELi32ELi2EEEvNS0_5LqGrpEPKtl+0x1534>
	s_load_b64 s[6:7], s[10:11], 0x10                          // 000000376A4C: F4040185 F8000010
	s_lshr_b64 s[10:11], s[8:9], 1                             // 000000376A54: 858A8108
	v_dual_mov_b32 v9, 0 :: v_dual_and_b32 v0, 7, v2           // 000000376A58: CA240080 09000487
	v_mad_u64_u32 v[5:6], null, s10, v3, 0                     // 000000376A60: D6FE7C05 0202060A
	v_and_b32_e32 v8, 0x1ff, v1                                // 000000376A68: 361002FF 000001FF
	s_lshr_b32 s5, s9, 1                                       // 000000376A70: 85058109
	v_dual_mov_b32 v11, s0 :: v_dual_and_b32 v10, 0xfffffe00, v1// 000000376A74: CA240000 0B0A02FF FFFFFE00
	v_bfe_u32 v14, v4, 16, 1                                   // 000000376A80: D610000E 02052104
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000376A88: BF8700C4
	v_mad_u64_u32 v[6:7], null, s5, v3, v[6:7]                 // 000000376A8C: D6FE7C06 041A0605
	v_mov_b32_e32 v7, s1                                       // 000000376A94: 7E0E0201
	v_cmp_gt_u64_e32 vcc_lo, 0x100, v[8:9]                     // 000000376A98: 7CB810FF 00000100
	.long 0xd7000509                                           // 000000376AA0: D7000509
	v_cndmask_b32_e32 v1, 0xffffff00, v8, vcc_lo               // 000000376AA4: 020210FF FFFFFF00
	v_add_co_ci_u32_e64 v12, null, 0, -1, s5                   // 000000376AAC: D5207C0C 00158280
	s_mov_b32 s5, 0                                            // 000000376AB4: BE850080
	.long 0xd73c0005                                           // 000000376AB8: D73C0005
	v_cndmask_b32_e32 v1, 1, v5, vcc_lo                        // 000000376ABC: 02020A81
	s_waitcnt lgkmcnt(0)                                       // 000000376AC0: BF89FC07
	v_cndmask_b32_e32 v11, s6, v11, vcc_lo                     // 000000376AC4: 02161606
	v_cndmask_b32_e32 v13, s7, v7, vcc_lo                      // 000000376AC8: 021A0E07
	v_cndmask_b32_e32 v7, v9, v8, vcc_lo                       // 000000376ACC: 020E1109
	v_cndmask_b32_e64 v8, v12, 0, vcc_lo                       // 000000376AD0: D5010008 01A9010C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000376AD8: BF870094
	.long 0xd7006a09                                           // 000000376ADC: D7006A09
	v_cndmask_b32_e32 v1, v11, v5, vcc_lo                      // 000000376AE0: 02020B0B
	v_add_co_ci_u32_e64 v11, null, v13, v6, vcc_lo             // 000000376AE4: D5207C0B 01AA0D0D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000376AEC: BF870193
	.long 0xd73c0005                                           // 000000376AF0: D73C0005
	v_cndmask_b32_e32 v1, 1, v7, vcc_lo                        // 000000376AF4: 02020E81
	.long 0xd7006a07                                           // 000000376AF8: D7006A07
	v_cndmask_b32_e32 v1, v9, v10, vcc_lo                      // 000000376AFC: 02021509
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000376B00: BF8701A1
	v_add_co_ci_u32_e64 v0, null, v11, v0, vcc_lo              // 000000376B04: D5207C00 01AA010B
	v_add3_u32 v8, v4, v14, 0x7fff                             // 000000376B0C: D6550008 03FE1D04 00007FFF
	.long 0xd7006a05                                           // 000000376B18: D7006A05
	v_cndmask_b32_e32 v1, v7, v5, vcc_lo                       // 000000376B1C: 02020B07
	s_delay_alu instid0(VALU_DEP_1)                            // 000000376B20: BF870001
	v_add_co_ci_u32_e64 v6, null, v0, v6, vcc_lo               // 000000376B24: D5207C06 01AA0D00
	global_store_d16_hi_b16 v[5:6], v8, off                    // 000000376B2C: DC960000 007C0805
	s_mov_b32 s6, 0                                            // 000000376B34: BE860080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000376B38: BF870009
	s_and_b32 vcc_lo, exec_lo, s6                              // 000000376B3C: 8B6A067E
	s_cbranch_vccz 49                                          // 000000376B40: BFA30031 <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi6ELi32ELi2EEEvNS0_5LqGrpEPKtl+0x1608>
	v_mul_f32_e32 v0, 0xbfb8aa3b, v4                           // 000000376B44: 100008FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000376B4C: BF870291
	v_exp_f32_e32 v0, v0                                       // 000000376B50: 7E004B00
	v_add_f32_e32 v0, 1.0, v0                                  // 000000376B54: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000376B58: BF870121
	v_div_scale_f32 v8, null, v0, v0, 1.0                      // 000000376B5C: D6FC7C08 03CA0100
	v_div_scale_f32 v10, vcc_lo, 1.0, v0, 1.0                  // 000000376B64: D6FC6A0A 03CA00F2
	v_rcp_f32_e32 v9, v8                                       // 000000376B6C: 7E125508
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000376B70: BF870095
	v_fma_f32 v5, -v8, v9, 1.0                                 // 000000376B74: D6130005 23CA1308
	v_fmac_f32_e32 v9, v5, v9                                  // 000000376B7C: 56121305
	v_mad_u64_u32 v[5:6], null, s8, v3, 0                      // 000000376B80: D6FE7C05 02020608
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000376B88: BF870112
	v_mul_f32_e32 v11, v10, v9                                 // 000000376B8C: 1016130A
	v_mad_u64_u32 v[6:7], null, s9, v3, v[6:7]                 // 000000376B90: D6FE7C06 041A0609
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000376B98: BF870092
	v_fma_f32 v12, -v8, v11, v10                               // 000000376B9C: D613000C 242A1708
	v_fmac_f32_e32 v11, v12, v9                                // 000000376BA4: 5616130C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000376BA8: BF870113
	.long 0xd73c0005                                           // 000000376BAC: D73C0005
	v_cndmask_b32_e32 v1, 2, v5, vcc_lo                        // 000000376BB0: 02020A82
	v_fma_f32 v10, -v8, v11, v10                               // 000000376BB4: D613000A 242A1708
	.long 0xd73c0007                                           // 000000376BBC: D73C0007
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 000000376BC0: 02020282
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000376BC4: BF870212
	v_div_fmas_f32 v9, v10, v9, v11                            // 000000376BC8: D6370009 042E130A
	.long 0xd7006a05                                           // 000000376BD0: D7006A05
	v_cndmask_b32_e32 v1, s0, v5, vcc_lo                       // 000000376BD4: 02020A00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000376BD8: BF870191
	v_add_co_ci_u32_e64 v6, null, s1, v6, vcc_lo               // 000000376BDC: D5207C06 01AA0C01
	v_div_fixup_f32 v0, v9, v0, 1.0                            // 000000376BE4: D6270000 03CA0109
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000376BEC: BF870093
	.long 0xd7006a05                                           // 000000376BF0: D7006A05
	v_cndmask_b32_e32 v1, v5, v7, vcc_lo                       // 000000376BF4: 02020F05
	v_add_co_ci_u32_e64 v6, null, v6, v8, vcc_lo               // 000000376BF8: D5207C06 01AA1106
	global_store_b32 v[5:6], v0, off                           // 000000376C00: DC6A0000 007C0005
	s_mov_b32 s6, 0                                            // 000000376C08: BE860080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000376C0C: BF870009
	s_and_b32 vcc_lo, exec_lo, s6                              // 000000376C10: 8B6A067E
	s_cbranch_vccz 60                                          // 000000376C14: BFA3003C <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi6ELi32ELi2EEEvNS0_5LqGrpEPKtl+0x1708>
	v_bfe_u32 v0, v4, 16, 1                                    // 000000376C18: D6100000 02052104
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000376C20: BF870091
	v_add3_u32 v0, v4, v0, 0x7fff                              // 000000376C24: D6550000 03FE0104 00007FFF
	v_and_b32_e32 v0, 0xffff0000, v0                           // 000000376C30: 360000FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000376C38: BF870091
	v_mul_f32_e32 v0, s2, v0                                   // 000000376C3C: 10000002
	v_mul_f32_e32 v0, 0xbfb8aa3b, v0                           // 000000376C40: 100000FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000376C48: BF870291
	v_exp_f32_e32 v0, v0                                       // 000000376C4C: 7E004B00
	v_add_f32_e32 v0, 1.0, v0                                  // 000000376C50: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000376C54: BF870121
	v_div_scale_f32 v8, null, v0, v0, 1.0                      // 000000376C58: D6FC7C08 03CA0100
	v_div_scale_f32 v10, vcc_lo, 1.0, v0, 1.0                  // 000000376C60: D6FC6A0A 03CA00F2
	v_rcp_f32_e32 v9, v8                                       // 000000376C68: 7E125508
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000376C6C: BF870095
	v_fma_f32 v5, -v8, v9, 1.0                                 // 000000376C70: D6130005 23CA1308
	v_fmac_f32_e32 v9, v5, v9                                  // 000000376C78: 56121305
	v_mad_u64_u32 v[5:6], null, s8, v3, 0                      // 000000376C7C: D6FE7C05 02020608
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000376C84: BF870092
	v_mul_f32_e32 v11, v10, v9                                 // 000000376C88: 1016130A
	v_fma_f32 v7, -v8, v11, v10                                // 000000376C8C: D6130007 242A1708
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000376C94: BF870211
	v_fmac_f32_e32 v11, v7, v9                                 // 000000376C98: 56161307
	v_mad_u64_u32 v[6:7], null, s9, v3, v[6:7]                 // 000000376C9C: D6FE7C06 041A0609
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000376CA4: BF870112
	v_fma_f32 v7, -v8, v11, v10                                // 000000376CA8: D6130007 242A1708
	.long 0xd73c0005                                           // 000000376CB0: D73C0005
	v_cndmask_b32_e32 v1, 2, v5, vcc_lo                        // 000000376CB4: 02020A82
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000376CB8: BF8701A2
	v_div_fmas_f32 v9, v7, v9, v11                             // 000000376CBC: D6370009 042E1307
	.long 0xd73c0007                                           // 000000376CC4: D73C0007
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 000000376CC8: 02020282
	.long 0xd7006a05                                           // 000000376CCC: D7006A05
	v_cndmask_b32_e32 v1, s0, v5, vcc_lo                       // 000000376CD0: 02020A00
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000376CD4: BF8701A3
	v_div_fixup_f32 v0, v9, v0, 1.0                            // 000000376CD8: D6270000 03CA0109
	v_add_co_ci_u32_e64 v6, null, s1, v6, vcc_lo               // 000000376CE0: D5207C06 01AA0C01
	.long 0xd7006a05                                           // 000000376CE8: D7006A05
	v_cndmask_b32_e32 v1, v5, v7, vcc_lo                       // 000000376CEC: 02020F05
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000376CF0: BF870193
	v_add_f32_e32 v0, v0, v0                                   // 000000376CF4: 06000100
	v_add_co_ci_u32_e64 v6, null, v6, v8, vcc_lo               // 000000376CF8: D5207C06 01AA1106
	global_store_b32 v[5:6], v0, off                           // 000000376D00: DC6A0000 007C0005
	s_mov_b32 s6, 0                                            // 000000376D08: BE860080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000376D0C: BF870009
	s_and_b32 vcc_lo, exec_lo, s6                              // 000000376D10: 8B6A067E
	s_cbranch_vccz 73                                          // 000000376D14: BFA30049 <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi6ELi32ELi2EEEvNS0_5LqGrpEPKtl+0x183c>
	s_cmp_gt_i32 s3, 1                                         // 000000376D18: BF028103
	s_mov_b32 s4, -1                                           // 000000376D1C: BE8400C1
	s_cbranch_scc0 64                                          // 000000376D20: BFA10040 <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi6ELi32ELi2EEEvNS0_5LqGrpEPKtl+0x1824>
	v_bfe_u32 v0, v4, 16, 1                                    // 000000376D24: D6100000 02052104
	s_mov_b32 s4, 0                                            // 000000376D2C: BE840080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000376D30: BF870091
	v_add3_u32 v0, v4, v0, 0x7fff                              // 000000376D34: D6550000 03FE0104 00007FFF
	v_and_b32_e32 v0, 0xffff0000, v0                           // 000000376D40: 360000FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000376D48: BF870091
	v_mul_f32_e32 v0, 0xbfb8aa3b, v0                           // 000000376D4C: 100000FF BFB8AA3B
	v_exp_f32_e32 v0, v0                                       // 000000376D54: 7E004B00
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000376D58: BF870095
	v_add_f32_e32 v0, 1.0, v0                                  // 000000376D5C: 060000F2
	v_div_scale_f32 v7, null, v0, v0, 1.0                      // 000000376D60: D6FC7C07 03CA0100
	v_div_scale_f32 v9, vcc_lo, 1.0, v0, 1.0                   // 000000376D68: D6FC6A09 03CA00F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000376D70: BF870292
	v_rcp_f32_e32 v8, v7                                       // 000000376D74: 7E105507
	v_fma_f32 v5, -v7, v8, 1.0                                 // 000000376D78: D6130005 23CA1107
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000376D80: BF870121
	v_fmac_f32_e32 v8, v5, v8                                  // 000000376D84: 56101105
	v_mad_u64_u32 v[5:6], null, s8, v3, 0                      // 000000376D88: D6FE7C05 02020608
	v_mul_f32_e32 v10, v9, v8                                  // 000000376D90: 10141109
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000376D94: BF870091
	v_fma_f32 v11, -v7, v10, v9                                // 000000376D98: D613000B 24261507
	v_fmac_f32_e32 v10, v11, v8                                // 000000376DA0: 5614110B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000376DA4: BF870121
	v_fma_f32 v9, -v7, v10, v9                                 // 000000376DA8: D6130009 24261507
	v_mad_u64_u32 v[6:7], null, s9, v3, v[6:7]                 // 000000376DB0: D6FE7C06 041A0609
	v_div_fmas_f32 v7, v9, v8, v10                             // 000000376DB8: D6370007 042A1109
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000376DC0: BF870112
	.long 0xd73c0005                                           // 000000376DC4: D73C0005
	v_cndmask_b32_e32 v1, 1, v5, vcc_lo                        // 000000376DC8: 02020A81
	v_div_fixup_f32 v0, v7, v0, 1.0                            // 000000376DCC: D6270000 03CA0107
	.long 0xd73c0007                                           // 000000376DD4: D73C0007
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 000000376DD8: 02020281
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000376DDC: BF870193
	.long 0xd7006a05                                           // 000000376DE0: D7006A05
	v_cndmask_b32_e32 v1, s0, v5, vcc_lo                       // 000000376DE4: 02020A00
	v_bfe_u32 v9, v0, 16, 1                                    // 000000376DE8: D6100009 02052100
	v_add_co_ci_u32_e64 v6, null, s1, v6, vcc_lo               // 000000376DF0: D5207C06 01AA0C01
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000376DF8: BF870193
	.long 0xd7006a05                                           // 000000376DFC: D7006A05
	v_cndmask_b32_e32 v1, v5, v7, vcc_lo                       // 000000376E00: 02020F05
	v_add3_u32 v0, v0, v9, 0x7fff                              // 000000376E04: D6550000 03FE1300 00007FFF
	s_delay_alu instid0(VALU_DEP_3)                            // 000000376E10: BF870003
	v_add_co_ci_u32_e64 v6, null, v6, v8, vcc_lo               // 000000376E14: D5207C06 01AA1106
	global_store_d16_hi_b16 v[5:6], v0, off                    // 000000376E1C: DC960000 007C0005
	s_and_not1_b32 vcc_lo, exec_lo, s4                         // 000000376E24: 916A047E
	s_mov_b32 s4, 0                                            // 000000376E28: BE840080
	s_cbranch_vccnz 3                                          // 000000376E2C: BFA40003 <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi6ELi32ELi2EEEvNS0_5LqGrpEPKtl+0x183c>
	s_cmp_lg_u32 s3, 1                                         // 000000376E30: BF078103
	s_mov_b32 s4, -1                                           // 000000376E34: BE8400C1
	s_cselect_b32 s5, -1, 0                                    // 000000376E38: 980580C1
	v_bfe_u32 v5, v4, 16, 1                                    // 000000376E3C: D6100005 02052104
	.long 0xd73c0000                                           // 000000376E44: D73C0000
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 000000376E48: 02020281
	s_and_b32 vcc_lo, exec_lo, s5                              // 000000376E4C: 8B6A057E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000376E50: BF870002
	v_add3_u32 v2, v4, v5, 0x7fff                              // 000000376E54: D6550002 03FE0B04 00007FFF
	s_cbranch_vccz 20                                          // 000000376E60: BFA30014 <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi6ELi32ELi2EEEvNS0_5LqGrpEPKtl+0x18b4>
	v_mad_u64_u32 v[4:5], null, s8, v3, 0                      // 000000376E64: D6FE7C04 02020608
	s_mov_b32 s4, 0                                            // 000000376E6C: BE840080
	v_mad_u64_u32 v[5:6], null, s9, v3, v[5:6]                 // 000000376E70: D6FE7C05 04160609
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000376E78: BF870091
	.long 0xd73c0004                                           // 000000376E7C: D73C0004
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 000000376E80: 02020881
	.long 0xd7006a04                                           // 000000376E84: D7006A04
	v_cndmask_b32_e32 v1, s0, v4, vcc_lo                       // 000000376E88: 02020800
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000376E8C: BF870111
	v_add_co_ci_u32_e64 v5, null, s1, v5, vcc_lo               // 000000376E90: D5207C05 01AA0A01
	.long 0xd7006a04                                           // 000000376E98: D7006A04
	v_cndmask_b32_e32 v1, v4, v0, vcc_lo                       // 000000376E9C: 02020104
	s_delay_alu instid0(VALU_DEP_1)                            // 000000376EA0: BF870001
	v_add_co_ci_u32_e64 v5, null, v5, v1, vcc_lo               // 000000376EA4: D5207C05 01AA0305
	global_store_d16_hi_b16 v[4:5], v2, off                    // 000000376EAC: DC960000 007C0204
	s_and_not1_b32 vcc_lo, exec_lo, s4                         // 000000376EB4: 916A047E
	s_cbranch_vccnz 57                                         // 000000376EB8: BFA40039 <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi6ELi32ELi2EEEvNS0_5LqGrpEPKtl+0x19a0>
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000376EBC: BF870091
	v_and_b32_e32 v2, 0xffff0000, v2                           // 000000376EC0: 360404FF FFFF0000
	v_mul_f32_e32 v2, s2, v2                                   // 000000376EC8: 10040402
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000376ECC: BF870091
	v_mul_f32_e32 v4, 0xbfb8aa3b, v2                           // 000000376ED0: 100804FF BFB8AA3B
	v_exp_f32_e32 v4, v4                                       // 000000376ED8: 7E084B04
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000376EDC: BF870095
	v_add_f32_e32 v7, 1.0, v4                                  // 000000376EE0: 060E08F2
	v_div_scale_f32 v6, null, v7, v7, v2                       // 000000376EE4: D6FC7C06 040A0F07
	v_div_scale_f32 v9, vcc_lo, v2, v7, v2                     // 000000376EEC: D6FC6A09 040A0F02
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000376EF4: BF870292
	v_rcp_f32_e32 v8, v6                                       // 000000376EF8: 7E105506
	v_fma_f32 v4, -v6, v8, 1.0                                 // 000000376EFC: D6130004 23CA1106
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000376F04: BF870121
	v_fmac_f32_e32 v8, v4, v8                                  // 000000376F08: 56101104
	v_mad_u64_u32 v[4:5], null, s8, v3, 0                      // 000000376F0C: D6FE7C04 02020608
	v_mul_f32_e32 v10, v9, v8                                  // 000000376F14: 10141109
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000376F18: BF870091
	v_fma_f32 v11, -v6, v10, v9                                // 000000376F1C: D613000B 24261506
	v_fmac_f32_e32 v10, v11, v8                                // 000000376F24: 5614110B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000376F28: BF870121
	v_fma_f32 v9, -v6, v10, v9                                 // 000000376F2C: D6130009 24261506
	v_mad_u64_u32 v[5:6], null, s9, v3, v[5:6]                 // 000000376F34: D6FE7C05 04160609
	v_div_fmas_f32 v3, v9, v8, v10                             // 000000376F3C: D6370003 042A1109
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000376F44: BF870191
	v_div_fixup_f32 v6, v3, v7, v2                             // 000000376F48: D6270006 040A0F03
	.long 0xd73c0002                                           // 000000376F50: D73C0002
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 000000376F54: 02020881
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000376F58: BF870112
	v_bfe_u32 v4, v6, 16, 1                                    // 000000376F5C: D6100004 02052106
	.long 0xd7006a02                                           // 000000376F64: D7006A02
	v_cndmask_b32_e32 v1, s0, v2, vcc_lo                       // 000000376F68: 02020400
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000376F6C: BF870191
	v_add_co_ci_u32_e64 v3, null, s1, v3, vcc_lo               // 000000376F70: D5207C03 01AA0601
	v_add3_u32 v4, v6, v4, 0x7fff                              // 000000376F78: D6550004 03FE0906 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000376F84: BF870093
	.long 0xd7006a00                                           // 000000376F88: D7006A00
	v_cndmask_b32_e32 v1, v2, v0, vcc_lo                       // 000000376F8C: 02020102
	v_add_co_ci_u32_e64 v1, null, v3, v1, vcc_lo               // 000000376F90: D5207C01 01AA0303
	global_store_d16_hi_b16 v[0:1], v4, off                    // 000000376F98: DC960000 007C0400
	s_nop 0                                                    // 000000376FA0: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 000000376FA4: BFB60003
	s_endpgm                                                   // 000000376FA8: BFB00000
		...

