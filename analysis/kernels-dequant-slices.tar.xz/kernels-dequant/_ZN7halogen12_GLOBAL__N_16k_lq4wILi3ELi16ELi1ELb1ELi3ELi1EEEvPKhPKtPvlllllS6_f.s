000000000083da00 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi16ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi16ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[8:23], s[0:1], null                          // 00000083DA00: F4100200 F8000000
	v_and_b32_e32 v23, 15, v0                                  // 00000083DA08: 362E008F
	v_lshrrev_b32_e32 v1, 4, v0                                // 00000083DA0C: 32020084
	s_ashr_i32 s3, s2, 31                                      // 00000083DA10: 86039F02
	v_lshlrev_b32_e32 v0, 2, v0                                // 00000083DA14: 30000082
	s_lshl_b64 s[2:3], s[2:3], 4                               // 00000083DA18: 84828402
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000083DA1C: BF870009
	v_dual_mov_b32 v17, s3 :: v_dual_lshlrev_b32 v2, 2, v23    // 00000083DA20: CA220003 11022E82
	v_lshlrev_b32_e32 v3, 2, v1                                // 00000083DA28: 30060282
	v_or_b32_e32 v16, s2, v1                                   // 00000083DA2C: 38200202
	.long 0x7f023880                                           // 00000083DA30: 7F023880
	s_waitcnt lgkmcnt(0)                                       // 00000083DA34: BF89FC07
	s_clause 0x1                                               // 00000083DA38: BF850001
	global_load_b32 v2, v2, s[8:9]                             // 00000083DA3C: DC520000 02080002
	global_load_b32 v3, v3, s[8:9]                             // 00000083DA44: DC520000 03080003
	.long 0xd4540002                                           // 00000083DA4C: D4540002
	v_cndmask_b32_e32 v1, s16, v16, vcc_lo                     // 00000083DA50: 02022010
	s_add_u32 s24, s8, s20                                     // 00000083DA54: 80181408
	s_addc_u32 s25, s9, s21                                    // 00000083DA58: 82191509
	s_ashr_i32 s4, s15, 31                                     // 00000083DA5C: 86049F0F
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 00000083DA60: BF870159
	s_lshr_b32 s4, s4, 27                                      // 00000083DA64: 85049B04
	v_cndmask_b32_e64 v8, 0, v16, s2                           // 00000083DA68: D5010008 000A2080
	v_cndmask_b32_e64 v9, 0, s3, s2                            // 00000083DA70: D5010009 00080680
	s_add_u32 s4, s14, s4                                      // 00000083DA78: 8004040E
	s_addc_u32 s5, s15, 0                                      // 00000083DA7C: 8205800F
	.long 0xd72c0004                                           // 00000083DA80: D72C0004
	v_cndmask_b32_e32 v1, s23, v8, vcc_lo                      // 00000083DA84: 02021017
	v_mad_u64_u32 v[12:13], null, s22, v8, 0                   // 00000083DA88: D6FE7C0C 02021016
	s_lshr_b64 s[6:7], s[4:5], 5                               // 00000083DA90: 85868504
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000083DA94: BF870009
	s_cmpk_lt_i32 s6, 0x81                                     // 00000083DA98: B3860081
	.long 0xd4440004                                           // 00000083DA9C: D4440004
	v_cndmask_b32_e32 v1, s6, v23, vcc_lo                      // 00000083DAA0: 02022E06
	s_cselect_b32 s3, -1, 0                                    // 00000083DAA4: 980380C1
	s_cmpk_gt_i32 s6, 0x80                                     // 00000083DAA8: B2860080
	.long 0xd700050e                                           // 00000083DAAC: D700050E
	v_cndmask_b32_e32 v1, s24, v12, vcc_lo                     // 00000083DAB0: 02021818
	s_cselect_b32 s7, -1, 0                                    // 00000083DAB4: 980780C1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 00000083DAB8: BF870159
	s_and_b32 vcc_lo, exec_lo, s7                              // 00000083DABC: 8B6A077E
	s_waitcnt vmcnt(1)                                         // 00000083DAC0: BF8907F7
	v_bfe_u32 v5, v2, 16, 1                                    // 00000083DAC4: D6100005 02052102
	s_waitcnt vmcnt(0)                                         // 00000083DACC: BF8903F7
	v_bfe_u32 v6, v3, 16, 1                                    // 00000083DAD0: D6100006 02052103
	v_add3_u32 v2, v2, v5, 0x7fff                              // 00000083DAD8: D6550002 03FE0B02 00007FFF
	.long 0xd72c0005                                           // 00000083DAE4: D72C0005
	v_cndmask_b32_e32 v1, s22, v9, vcc_lo                      // 00000083DAE8: 02021216
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000083DAEC: BF870193
	v_add3_u32 v3, v3, v6, 0x7fff                              // 00000083DAF0: D6550003 03FE0D03 00007FFF
	.long 0x7e023982                                           // 00000083DAFC: 7E023982
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000083DB00: BF870113
	v_add3_u32 v13, v13, v5, v4                                // 00000083DB04: D655000D 04120B0D
	v_and_or_b32 v1, 0xffff0000, v3, v1                        // 00000083DB0C: D6570001 040606FF FFFF0000
	s_delay_alu instid0(VALU_DEP_2)                            // 00000083DB18: BF870002
	v_add_co_ci_u32_e64 v15, null, s25, v13, s5                // 00000083DB1C: D5207C0F 00161A19
	ds_store_b32 v0, v1                                        // 00000083DB24: D8340000 00000100
	s_waitcnt lgkmcnt(0)                                       // 00000083DB2C: BF89FC07
	s_barrier                                                  // 00000083DB30: BFBD0000
	buffer_gl0_inv                                             // 00000083DB34: E0AC0000 00000000
	s_cbranch_vccnz 144                                        // 00000083DB3C: BFA40090 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi16ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x380>
	v_dual_mov_b32 v1, 0 :: v_dual_mov_b32 v0, 0               // 00000083DB40: CA100080 01000080
	s_and_saveexec_b32 s5, s4                                  // 00000083DB48: BE852004
	s_cbranch_execz 10                                         // 00000083DB4C: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi16ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x178>
	v_lshlrev_b32_e32 v0, 1, v23                               // 00000083DB50: 30002E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000083DB54: BF870091
	.long 0xd7006a02                                           // 00000083DB58: D7006A02
	v_cndmask_b32_e32 v1, v14, v0, vcc_lo                      // 00000083DB5C: 0202010E
	v_add_co_ci_u32_e64 v3, null, 0, v15, vcc_lo               // 00000083DB60: D5207C03 01AA1E80
	global_load_d16_b16 v0, v[2:3], off                        // 00000083DB68: DC820000 007C0002
	s_waitcnt vmcnt(0)                                         // 00000083DB70: BF8903F7
	v_cvt_f32_f16_e32 v0, v0                                   // 00000083DB74: 7E001700
	s_or_b32 exec_lo, exec_lo, s5                              // 00000083DB78: 8C7E057E
	v_or_b32_e32 v2, 16, v23                                   // 00000083DB7C: 38042E90
	s_mov_b32 s4, exec_lo                                      // 00000083DB80: BE84007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000083DB84: BF870001
	.long 0xd4c4007e                                           // 00000083DB88: D4C4007E
	v_cndmask_b32_e32 v1, s6, v2, vcc_lo                       // 00000083DB8C: 02020406
	s_cbranch_execz 10                                         // 00000083DB90: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi16ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x1bc>
	v_lshlrev_b32_e32 v1, 1, v2                                // 00000083DB94: 30020481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000083DB98: BF870091
	.long 0xd7006a01                                           // 00000083DB9C: D7006A01
	v_cndmask_b32_e32 v1, v14, v1, vcc_lo                      // 00000083DBA0: 0202030E
	v_add_co_ci_u32_e64 v2, null, 0, v15, vcc_lo               // 00000083DBA4: D5207C02 01AA1E80
	global_load_d16_b16 v1, v[1:2], off                        // 00000083DBAC: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 00000083DBB4: BF8903F7
	v_cvt_f32_f16_e32 v1, v1                                   // 00000083DBB8: 7E021701
	s_or_b32 exec_lo, exec_lo, s4                              // 00000083DBBC: 8C7E047E
	v_or_b32_e32 v4, 32, v23                                   // 00000083DBC0: 38082EA0
	v_dual_mov_b32 v3, 0 :: v_dual_mov_b32 v2, 0               // 00000083DBC4: CA100080 03020080
	s_mov_b32 s4, exec_lo                                      // 00000083DBCC: BE84007E
	s_delay_alu instid0(VALU_DEP_2)                            // 00000083DBD0: BF870002
	.long 0xd4c4007e                                           // 00000083DBD4: D4C4007E
	v_cndmask_b32_e32 v1, s6, v4, vcc_lo                       // 00000083DBD8: 02020806
	s_cbranch_execz 10                                         // 00000083DBDC: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi16ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x208>
	v_lshlrev_b32_e32 v2, 1, v4                                // 00000083DBE0: 30040881
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000083DBE4: BF870091
	.long 0xd7006a04                                           // 00000083DBE8: D7006A04
	v_cndmask_b32_e32 v1, v14, v2, vcc_lo                      // 00000083DBEC: 0202050E
	v_add_co_ci_u32_e64 v5, null, 0, v15, vcc_lo               // 00000083DBF0: D5207C05 01AA1E80
	global_load_d16_b16 v2, v[4:5], off                        // 00000083DBF8: DC820000 027C0004
	s_waitcnt vmcnt(0)                                         // 00000083DC00: BF8903F7
	v_cvt_f32_f16_e32 v2, v2                                   // 00000083DC04: 7E041702
	s_or_b32 exec_lo, exec_lo, s4                              // 00000083DC08: 8C7E047E
	v_or_b32_e32 v4, 48, v23                                   // 00000083DC0C: 38082EB0
	s_mov_b32 s4, exec_lo                                      // 00000083DC10: BE84007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000083DC14: BF870001
	.long 0xd4c4007e                                           // 00000083DC18: D4C4007E
	v_cndmask_b32_e32 v1, s6, v4, vcc_lo                       // 00000083DC1C: 02020806
	s_cbranch_execz 10                                         // 00000083DC20: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi16ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x24c>
	v_lshlrev_b32_e32 v3, 1, v4                                // 00000083DC24: 30060881
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000083DC28: BF870091
	.long 0xd7006a03                                           // 00000083DC2C: D7006A03
	v_cndmask_b32_e32 v1, v14, v3, vcc_lo                      // 00000083DC30: 0202070E
	v_add_co_ci_u32_e64 v4, null, 0, v15, vcc_lo               // 00000083DC34: D5207C04 01AA1E80
	global_load_d16_b16 v3, v[3:4], off                        // 00000083DC3C: DC820000 037C0003
	s_waitcnt vmcnt(0)                                         // 00000083DC44: BF8903F7
	v_cvt_f32_f16_e32 v3, v3                                   // 00000083DC48: 7E061703
	s_or_b32 exec_lo, exec_lo, s4                              // 00000083DC4C: 8C7E047E
	v_or_b32_e32 v6, 64, v23                                   // 00000083DC50: 380C2EC0
	v_dual_mov_b32 v5, 0 :: v_dual_mov_b32 v4, 0               // 00000083DC54: CA100080 05040080
	s_mov_b32 s4, exec_lo                                      // 00000083DC5C: BE84007E
	s_delay_alu instid0(VALU_DEP_2)                            // 00000083DC60: BF870002
	.long 0xd4c4007e                                           // 00000083DC64: D4C4007E
	v_cndmask_b32_e32 v1, s6, v6, vcc_lo                       // 00000083DC68: 02020C06
	s_cbranch_execz 10                                         // 00000083DC6C: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi16ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x298>
	v_lshlrev_b32_e32 v4, 1, v6                                // 00000083DC70: 30080C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000083DC74: BF870091
	.long 0xd7006a06                                           // 00000083DC78: D7006A06
	v_cndmask_b32_e32 v1, v14, v4, vcc_lo                      // 00000083DC7C: 0202090E
	v_add_co_ci_u32_e64 v7, null, 0, v15, vcc_lo               // 00000083DC80: D5207C07 01AA1E80
	global_load_d16_b16 v4, v[6:7], off                        // 00000083DC88: DC820000 047C0006
	s_waitcnt vmcnt(0)                                         // 00000083DC90: BF8903F7
	v_cvt_f32_f16_e32 v4, v4                                   // 00000083DC94: 7E081704
	s_or_b32 exec_lo, exec_lo, s4                              // 00000083DC98: 8C7E047E
	v_or_b32_e32 v6, 0x50, v23                                 // 00000083DC9C: 380C2EFF 00000050
	s_mov_b32 s4, exec_lo                                      // 00000083DCA4: BE84007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000083DCA8: BF870001
	.long 0xd4c4007e                                           // 00000083DCAC: D4C4007E
	v_cndmask_b32_e32 v1, s6, v6, vcc_lo                       // 00000083DCB0: 02020C06
	s_cbranch_execz 10                                         // 00000083DCB4: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi16ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x2e0>
	v_lshlrev_b32_e32 v5, 1, v6                                // 00000083DCB8: 300A0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000083DCBC: BF870091
	.long 0xd7006a05                                           // 00000083DCC0: D7006A05
	v_cndmask_b32_e32 v1, v14, v5, vcc_lo                      // 00000083DCC4: 02020B0E
	v_add_co_ci_u32_e64 v6, null, 0, v15, vcc_lo               // 00000083DCC8: D5207C06 01AA1E80
	global_load_d16_b16 v5, v[5:6], off                        // 00000083DCD0: DC820000 057C0005
	s_waitcnt vmcnt(0)                                         // 00000083DCD8: BF8903F7
	v_cvt_f32_f16_e32 v5, v5                                   // 00000083DCDC: 7E0A1705
	s_or_b32 exec_lo, exec_lo, s4                              // 00000083DCE0: 8C7E047E
	v_or_b32_e32 v10, 0x60, v23                                // 00000083DCE4: 38142EFF 00000060
	v_dual_mov_b32 v7, 0 :: v_dual_mov_b32 v6, 0               // 00000083DCEC: CA100080 07060080
	s_mov_b32 s4, exec_lo                                      // 00000083DCF4: BE84007E
	s_delay_alu instid0(VALU_DEP_2)                            // 00000083DCF8: BF870002
	.long 0xd4c4007e                                           // 00000083DCFC: D4C4007E
	v_cndmask_b32_e32 v1, s6, v10, vcc_lo                      // 00000083DD00: 02021406
	s_cbranch_execz 10                                         // 00000083DD04: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi16ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x330>
	v_lshlrev_b32_e32 v6, 1, v10                               // 00000083DD08: 300C1481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000083DD0C: BF870091
	.long 0xd7006a0a                                           // 00000083DD10: D7006A0A
	v_cndmask_b32_e32 v1, v14, v6, vcc_lo                      // 00000083DD14: 02020D0E
	v_add_co_ci_u32_e64 v11, null, 0, v15, vcc_lo              // 00000083DD18: D5207C0B 01AA1E80
	global_load_d16_b16 v6, v[10:11], off                      // 00000083DD20: DC820000 067C000A
	s_waitcnt vmcnt(0)                                         // 00000083DD28: BF8903F7
	v_cvt_f32_f16_e32 v6, v6                                   // 00000083DD2C: 7E0C1706
	s_or_b32 exec_lo, exec_lo, s4                              // 00000083DD30: 8C7E047E
	v_or_b32_e32 v10, 0x70, v23                                // 00000083DD34: 38142EFF 00000070
	s_mov_b32 s4, exec_lo                                      // 00000083DD3C: BE84007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000083DD40: BF870001
	.long 0xd4c4007e                                           // 00000083DD44: D4C4007E
	v_cndmask_b32_e32 v1, s6, v10, vcc_lo                      // 00000083DD48: 02021406
	s_cbranch_execz 10                                         // 00000083DD4C: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi16ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x378>
	v_lshlrev_b32_e32 v7, 1, v10                               // 00000083DD50: 300E1481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000083DD54: BF870091
	.long 0xd7006a0a                                           // 00000083DD58: D7006A0A
	v_cndmask_b32_e32 v1, v14, v7, vcc_lo                      // 00000083DD5C: 02020F0E
	v_add_co_ci_u32_e64 v11, null, 0, v15, vcc_lo              // 00000083DD60: D5207C0B 01AA1E80
	global_load_d16_b16 v7, v[10:11], off                      // 00000083DD68: DC820000 077C000A
	s_waitcnt vmcnt(0)                                         // 00000083DD70: BF8903F7
	v_cvt_f32_f16_e32 v7, v7                                   // 00000083DD74: 7E0E1707
	s_or_b32 exec_lo, exec_lo, s4                              // 00000083DD78: 8C7E047E
	s_branch 9                                                 // 00000083DD7C: BFA00009 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi16ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x3a4>
	v_mov_b32_e32 v0, 0                                        // 00000083DD80: 7E000280
	s_delay_alu instid0(VALU_DEP_1)                            // 00000083DD84: BF870001
	v_mov_b32_e32 v1, v0                                       // 00000083DD88: 7E020300
	v_mov_b32_e32 v2, v0                                       // 00000083DD8C: 7E040300
	v_mov_b32_e32 v3, v0                                       // 00000083DD90: 7E060300
	v_mov_b32_e32 v4, v0                                       // 00000083DD94: 7E080300
	v_mov_b32_e32 v5, v0                                       // 00000083DD98: 7E0A0300
	v_mov_b32_e32 v6, v0                                       // 00000083DD9C: 7E0C0300
	v_mov_b32_e32 v7, v0                                       // 00000083DDA0: 7E0E0300
	s_add_u32 s4, s8, s18                                      // 00000083DDA4: 80041208
	s_addc_u32 s5, s9, s19                                     // 00000083DDA8: 82051309
	s_lshr_b32 s18, s15, 31                                    // 00000083DDAC: 85129F0F
	v_mov_b32_e32 v26, 0                                       // 00000083DDB0: 7E340280
	s_add_u32 s18, s14, s18                                    // 00000083DDB4: 8012120E
	s_addc_u32 s19, s15, 0                                     // 00000083DDB8: 8213800F
	v_cndmask_b32_e64 v24, 0, 1, s7                            // 00000083DDBC: D5010018 001D0280
	s_ashr_i64 s[18:19], s[18:19], 1                           // 00000083DDC4: 86928112
	v_mov_b32_e32 v32, 0                                       // 00000083DDC8: 7E400280
	v_mad_u64_u32 v[18:19], null, v8, s18, s[4:5]              // 00000083DDCC: D6FE7C12 00102508
	.long 0xd72c000b                                           // 00000083DDD4: D72C000B
	v_cndmask_b32_e32 v0, v8, v19, vcc_lo                      // 00000083DDD8: 02002708
	.long 0xd72c0014                                           // 00000083DDDC: D72C0014
	v_cndmask_b32_e32 v0, v9, v18, vcc_lo                      // 00000083DDE0: 02002509
	.long 0xd4440004                                           // 00000083DDE4: D4440004
	v_cndmask_b32_e32 v1, s6, v23, vcc_lo                      // 00000083DDE8: 02022E06
	v_dual_mov_b32 v8, 0 :: v_dual_mov_b32 v9, 0               // 00000083DDEC: CA100080 08080080
	v_mov_b32_e32 v10, 0                                       // 00000083DDF4: 7E140280
	s_delay_alu instid0(VALU_DEP_4)                            // 00000083DDF8: BF870004
	v_add3_u32 v25, v20, v19, v11                              // 00000083DDFC: D6550019 042E2714
	v_mov_b32_e32 v11, 0                                       // 00000083DE04: 7E160280
	s_and_saveexec_b32 s5, s4                                  // 00000083DE08: BE852004
	s_cbranch_execz 21                                         // 00000083DE0C: BFA50015 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi16ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x464>
	v_lshlrev_b32_e32 v8, 4, v23                               // 00000083DE10: 30102E84
	v_mov_b32_e32 v32, 0                                       // 00000083DE14: 7E400280
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000083DE18: BF870092
	.long 0xd7006a08                                           // 00000083DE1C: D7006A08
	v_cndmask_b32_e32 v1, v18, v8, vcc_lo                      // 00000083DE20: 02021112
	v_add_co_ci_u32_e64 v9, null, 0, v25, vcc_lo               // 00000083DE24: D5207C09 01AA3280
	s_and_not1_b32 vcc_lo, exec_lo, s7                         // 00000083DE2C: 916A077E
	global_load_b128 v[8:11], v[8:9], off                      // 00000083DE30: DC5E0000 087C0008
	s_cbranch_vccnz 10                                         // 00000083DE38: BFA4000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi16ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x464>
	v_lshlrev_b32_e32 v19, 1, v23                              // 00000083DE3C: 30262E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000083DE40: BF870091
	.long 0xd7006a0e                                           // 00000083DE44: D7006A0E
	v_cndmask_b32_e32 v1, v14, v19, vcc_lo                     // 00000083DE48: 0202270E
	v_add_co_ci_u32_e64 v15, null, 0, v15, vcc_lo              // 00000083DE4C: D5207C0F 01AA1E80
	global_load_d16_b16 v14, v[14:15], off                     // 00000083DE54: DC820000 0E7C000E
	s_waitcnt vmcnt(0)                                         // 00000083DE5C: BF8903F7
	v_cvt_f32_f16_e32 v32, v14                                 // 00000083DE60: 7E40170E
	s_or_b32 exec_lo, exec_lo, s5                              // 00000083DE64: 8C7E057E
	v_dual_mov_b32 v27, 0 :: v_dual_mov_b32 v28, 0             // 00000083DE68: CA100080 1B1C0080
	s_and_saveexec_b32 s5, s4                                  // 00000083DE70: BE852004
	s_cbranch_execz 352                                        // 00000083DE74: BFA50160 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi16ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x9f8>
	.long 0xd7006a0c                                           // 00000083DE78: D7006A0C
	v_cndmask_b32_e32 v1, s20, v12, vcc_lo                     // 00000083DE7C: 02021814
	v_dual_mov_b32 v20, 0 :: v_dual_lshlrev_b32 v19, 5, v23    // 00000083DE80: CA220080 14122E85
	v_lshlrev_b32_e32 v14, 1, v23                              // 00000083DE88: 301C2E81
	v_add_co_ci_u32_e64 v13, null, s21, v13, vcc_lo            // 00000083DE8C: D5207C0D 01AA1A15
	v_lshl_or_b32 v29, v23, 4, 0x100                           // 00000083DE94: D656001D 03FD0917 00000100
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000083DEA0: BF870214
	v_mov_b32_e32 v27, v20                                     // 00000083DEA4: 7E360314
	.long 0xd7006a0c                                           // 00000083DEA8: D7006A0C
	v_cndmask_b32_e32 v1, v12, v14, vcc_lo                     // 00000083DEAC: 02021D0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000083DEB0: BF8701A1
	v_add_co_ci_u32_e64 v13, null, 0, v13, vcc_lo              // 00000083DEB4: D5207C0D 01AA1A80
	v_dual_mov_b32 v30, v23 :: v_dual_mov_b32 v31, v32         // 00000083DEBC: CA100117 1E1E0120
	.long 0xd7006a0c                                           // 00000083DEC4: D7006A0C
	v_cndmask_b32_e32 v1, s8, v12, vcc_lo                      // 00000083DEC8: 02021808
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000083DECC: BF8701A1
	v_add_co_ci_u32_e64 v13, null, s9, v13, vcc_lo             // 00000083DED0: D5207C0D 01AA1A09
	v_mov_b32_e32 v28, v20                                     // 00000083DED8: 7E380314
	.long 0xd7006a15                                           // 00000083DEDC: D7006A15
	v_cndmask_b32_e32 v0, v12, v160, vcc_lo                    // 00000083DEE0: 0201410C
	s_delay_alu instid0(VALU_DEP_1)                            // 00000083DEE4: BF870001
	v_add_co_ci_u32_e64 v22, null, 0, v13, vcc_lo              // 00000083DEE8: D5207C16 01AA1A80
	v_mov_b32_e32 v26, v20                                     // 00000083DEF0: 7E340314
	s_lshl_b64 s[8:9], s[14:15], 2                             // 00000083DEF4: 8488820E
	s_mov_b32 s7, 0                                            // 00000083DEF8: BE870080
	s_lshl_b64 s[14:15], s[14:15], 1                           // 00000083DEFC: 848E810E
	s_branch 288                                               // 00000083DF00: BFA00120 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi16ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x984>
	s_or_b32 exec_lo, exec_lo, s18                             // 00000083DF04: 8C7E127E
	.long 0xd73c0021                                           // 00000083DF08: D73C0021
	v_cndmask_b32_e32 v1, 1, v19, vcc_lo                       // 00000083DF0C: 02022681
	v_and_b32_e32 v81, 0xff, v8                                // 00000083DF10: 36A210FF 000000FF
	v_cndmask_b32_e64 v82, v32, v0, s3                         // 00000083DF18: D5010052 000E0120
	v_lshrrev_b32_e32 v32, 6, v8                               // 00000083DF20: 32401086
	v_lshrrev_b32_e32 v83, 14, v8                              // 00000083DF24: 32A6108E
	v_lshrrev_b32_e32 v8, 22, v8                               // 00000083DF28: 32101096
	.long 0xd7006a45                                           // 00000083DF2C: D7006A45
	v_cndmask_b32_e32 v1, s10, v33, vcc_lo                     // 00000083DF30: 0202420A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000083DF34: BF8701A1
	v_add_co_ci_u32_e64 v70, null, s11, v34, vcc_lo            // 00000083DF38: D5207C46 01AA440B
	v_lshlrev_b32_e32 v81, 2, v81                              // 00000083DF40: 30A2A282
	.long 0xd7006a49                                           // 00000083DF44: D7006A49
	v_cndmask_b32_e32 v0, v69, v14, vcc_lo                     // 00000083DF48: 02001D45
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000083DF4C: BF8700A1
	v_add_co_ci_u32_e64 v74, null, s15, v70, vcc_lo            // 00000083DF50: D5207C4A 01AA8C0F
	.long 0xd7006a4d                                           // 00000083DF58: D7006A4D
	v_cndmask_b32_e32 v0, v69, v8, vcc_lo                      // 00000083DF5C: 02001145
	v_add_co_ci_u32_e64 v78, null, s9, v70, vcc_lo             // 00000083DF60: D5207C4E 01AA8C09
	s_clause 0xb                                               // 00000083DF68: BF85000B
	global_load_b128 v[33:36], v[69:70], off                   // 00000083DF6C: DC5E0000 217C0045
	global_load_b128 v[37:40], v[73:74], off                   // 00000083DF74: DC5E0000 257C0049
	global_load_b128 v[41:44], v[77:78], off                   // 00000083DF7C: DC5E0000 297C004D
	global_load_b128 v[45:48], v[69:70], off offset:16         // 00000083DF84: DC5E0010 2D7C0045
	global_load_b128 v[49:52], v[73:74], off offset:16         // 00000083DF8C: DC5E0010 317C0049
	global_load_b128 v[53:56], v[77:78], off offset:16         // 00000083DF94: DC5E0010 357C004D
	global_load_b128 v[57:60], v[69:70], off offset:32         // 00000083DF9C: DC5E0020 397C0045
	global_load_b128 v[61:64], v[73:74], off offset:32         // 00000083DFA4: DC5E0020 3D7C0049
	global_load_b128 v[65:68], v[77:78], off offset:32         // 00000083DFAC: DC5E0020 417C004D
	global_load_b128 v[69:72], v[69:70], off offset:48         // 00000083DFB4: DC5E0030 457C0045
	global_load_b128 v[73:76], v[73:74], off offset:48         // 00000083DFBC: DC5E0030 497C0049
	global_load_b128 v[77:80], v[77:78], off offset:48         // 00000083DFC4: DC5E0030 4D7C004D
	v_and_b32_e32 v32, 0x3fc, v32                              // 00000083DFCC: 364040FF 000003FC
	ds_load_b32 v81, v81                                       // 00000083DFD4: D8D80000 51000051
	v_and_b32_e32 v83, 0x3fc, v83                              // 00000083DFDC: 36A6A6FF 000003FC
	v_and_b32_e32 v84, 0xff, v9                                // 00000083DFE4: 36A812FF 000000FF
	v_lshrrev_b32_e32 v85, 6, v9                               // 00000083DFEC: 32AA1286
	v_lshrrev_b32_e32 v86, 14, v9                              // 00000083DFF0: 32AC128E
	v_lshrrev_b32_e32 v9, 22, v9                               // 00000083DFF4: 32121296
	ds_load_b32 v83, v83                                       // 00000083DFF8: D8D80000 53000053
	ds_load_b32 v32, v32                                       // 00000083E000: D8D80000 20000020
	v_and_b32_e32 v8, 0x3fc, v8                                // 00000083E008: 361010FF 000003FC
	v_lshlrev_b32_e32 v84, 2, v84                              // 00000083E010: 30A8A882
	v_and_b32_e32 v85, 0x3fc, v85                              // 00000083E014: 36AAAAFF 000003FC
	v_and_b32_e32 v86, 0x3fc, v86                              // 00000083E01C: 36ACACFF 000003FC
	v_and_b32_e32 v9, 0x3fc, v9                                // 00000083E024: 361212FF 000003FC
	ds_load_b32 v8, v8                                         // 00000083E02C: D8D80000 08000008
	ds_load_b32 v84, v84                                       // 00000083E034: D8D80000 54000054
	ds_load_b32 v85, v85                                       // 00000083E03C: D8D80000 55000055
	ds_load_b32 v86, v86                                       // 00000083E044: D8D80000 56000056
	ds_load_b32 v9, v9                                         // 00000083E04C: D8D80000 09000009
	v_and_b32_e32 v87, 0xff, v10                               // 00000083E054: 36AE14FF 000000FF
	v_lshrrev_b32_e32 v88, 6, v10                              // 00000083E05C: 32B01486
	v_lshrrev_b32_e32 v89, 14, v10                             // 00000083E060: 32B2148E
	v_lshrrev_b32_e32 v10, 22, v10                             // 00000083E064: 32141496
	v_and_b32_e32 v90, 0xff, v11                               // 00000083E068: 36B416FF 000000FF
	v_lshrrev_b32_e32 v91, 14, v11                             // 00000083E070: 32B6168E
	.long 0xd7006a15                                           // 00000083E074: D7006A15
	v_cndmask_b32_e32 v0, v21, v160, vcc_lo                    // 00000083E078: 02014115
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000083E07C: BF8704A1
	v_add_co_ci_u32_e64 v22, null, 0, v22, vcc_lo              // 00000083E080: D5207C16 01AA2C80
	s_and_b32 s4, exec_lo, s4                                  // 00000083E088: 8B04047E
	s_or_b32 s7, s4, s7                                        // 00000083E08C: 8C070704
	s_waitcnt vmcnt(11) lgkmcnt(7)                             // 00000083E090: BF892C77
	v_dot2_f32_bf16 v33, v33, v81, 0                           // 00000083E094: CC1A4021 1A02A321
	s_waitcnt vmcnt(10)                                        // 00000083E09C: BF892BF7
	v_dot2_f32_bf16 v37, v37, v81, 0                           // 00000083E0A0: CC1A4025 1A02A325
	s_waitcnt vmcnt(9)                                         // 00000083E0A8: BF8927F7
	v_dot2_f32_bf16 v41, v41, v81, 0                           // 00000083E0AC: CC1A4029 1A02A329
	v_lshrrev_b32_e32 v81, 6, v11                              // 00000083E0B4: 32A21686
	v_lshrrev_b32_e32 v11, 22, v11                             // 00000083E0B8: 32161696
	s_waitcnt lgkmcnt(5)                                       // 00000083E0BC: BF89FC57
	v_dot2_f32_bf16 v33, v34, v32, v33                         // 00000083E0C0: CC1A4021 1C864122
	v_dot2_f32_bf16 v34, v38, v32, v37                         // 00000083E0C8: CC1A4022 1C964126
	v_dot2_f32_bf16 v32, v42, v32, v41                         // 00000083E0D0: CC1A4020 1CA6412A
	v_lshlrev_b32_e32 v37, 2, v87                              // 00000083E0D8: 304AAE82
	v_and_b32_e32 v38, 0x3fc, v89                              // 00000083E0DC: 364CB2FF 000003FC
	v_dot2_f32_bf16 v33, v35, v83, v33                         // 00000083E0E4: CC1A4021 1C86A723
	v_dot2_f32_bf16 v34, v39, v83, v34                         // 00000083E0EC: CC1A4022 1C8AA727
	v_dot2_f32_bf16 v32, v43, v83, v32                         // 00000083E0F4: CC1A4020 1C82A72B
	v_and_b32_e32 v35, 0x3fc, v88                              // 00000083E0FC: 3646B0FF 000003FC
	v_and_b32_e32 v39, 0x3fc, v91                              // 00000083E104: 364EB6FF 000003FC
	s_waitcnt lgkmcnt(4)                                       // 00000083E10C: BF89FC47
	v_dot2_f32_bf16 v33, v36, v8, v33                          // 00000083E110: CC1A4021 1C861124
	v_dot2_f32_bf16 v34, v40, v8, v34                          // 00000083E118: CC1A4022 1C8A1128
	v_dot2_f32_bf16 v8, v44, v8, v32                           // 00000083E120: CC1A4008 1C82112C
	ds_load_b32 v36, v37                                       // 00000083E128: D8D80000 24000025
	ds_load_b32 v40, v38                                       // 00000083E130: D8D80000 28000026
	ds_load_b32 v35, v35                                       // 00000083E138: D8D80000 23000023
	s_waitcnt vmcnt(8) lgkmcnt(6)                              // 00000083E140: BF892067
	v_dot2_f32_bf16 v33, v45, v84, v33                         // 00000083E144: CC1A4021 1C86A92D
	s_waitcnt vmcnt(7)                                         // 00000083E14C: BF891FF7
	v_dot2_f32_bf16 v34, v49, v84, v34                         // 00000083E150: CC1A4022 1C8AA931
	s_waitcnt vmcnt(6)                                         // 00000083E158: BF891BF7
	v_dot2_f32_bf16 v8, v53, v84, v8                           // 00000083E15C: CC1A4008 1C22A935
	v_cndmask_b32_e64 v38, v5, v6, s3                          // 00000083E164: D5010026 000E0D05
	v_and_b32_e32 v10, 0x3fc, v10                              // 00000083E16C: 361414FF 000003FC
	s_waitcnt lgkmcnt(5)                                       // 00000083E174: BF89FC57
	v_dot2_f32_bf16 v33, v46, v85, v33                         // 00000083E178: CC1A4021 1C86AB2E
	v_dot2_f32_bf16 v34, v50, v85, v34                         // 00000083E180: CC1A4022 1C8AAB32
	v_dot2_f32_bf16 v8, v54, v85, v8                           // 00000083E188: CC1A4008 1C22AB36
	v_lshlrev_b32_e32 v32, 2, v90                              // 00000083E190: 3040B482
	v_and_b32_e32 v37, 0x3fc, v81                              // 00000083E194: 364AA2FF 000003FC
	s_waitcnt lgkmcnt(4)                                       // 00000083E19C: BF89FC47
	v_dot2_f32_bf16 v33, v47, v86, v33                         // 00000083E1A0: CC1A4021 1C86AD2F
	v_dot2_f32_bf16 v34, v51, v86, v34                         // 00000083E1A8: CC1A4022 1C8AAD33
	v_dot2_f32_bf16 v8, v55, v86, v8                           // 00000083E1B0: CC1A4008 1C22AD37
	v_and_b32_e32 v11, 0x3fc, v11                              // 00000083E1B8: 361616FF 000003FC
	s_waitcnt lgkmcnt(3)                                       // 00000083E1C0: BF89FC37
	v_dot2_f32_bf16 v33, v48, v9, v33                          // 00000083E1C4: CC1A4021 1C861330
	v_dot2_f32_bf16 v34, v52, v9, v34                          // 00000083E1CC: CC1A4022 1C8A1334
	v_dot2_f32_bf16 v8, v56, v9, v8                            // 00000083E1D4: CC1A4008 1C221338
	ds_load_b32 v9, v10                                        // 00000083E1DC: D8D80000 0900000A
	ds_load_b32 v10, v32                                       // 00000083E1E4: D8D80000 0A000020
	ds_load_b32 v32, v37                                       // 00000083E1EC: D8D80000 20000025
	ds_load_b32 v41, v39                                       // 00000083E1F4: D8D80000 29000027
	ds_load_b32 v42, v11                                       // 00000083E1FC: D8D80000 2A00000B
	v_cndmask_b32_e64 v39, v6, v7, s3                          // 00000083E204: D5010027 000E0F06
	s_waitcnt vmcnt(5) lgkmcnt(7)                              // 00000083E20C: BF891477
	v_dot2_f32_bf16 v11, v57, v36, v33                         // 00000083E210: CC1A400B 1C864939
	s_waitcnt vmcnt(4)                                         // 00000083E218: BF8913F7
	v_dot2_f32_bf16 v33, v61, v36, v34                         // 00000083E21C: CC1A4021 1C8A493D
	s_waitcnt vmcnt(3)                                         // 00000083E224: BF890FF7
	v_dot2_f32_bf16 v8, v65, v36, v8                           // 00000083E228: CC1A4008 1C224941
	v_cndmask_b32_e64 v37, v4, v5, s3                          // 00000083E230: D5010025 000E0B04
	v_cndmask_b32_e64 v36, v3, v4, s3                          // 00000083E238: D5010024 000E0903
	s_waitcnt lgkmcnt(5)                                       // 00000083E240: BF89FC57
	v_dot2_f32_bf16 v6, v58, v35, v11                          // 00000083E244: CC1A4006 1C2E473A
	v_dot2_f32_bf16 v11, v62, v35, v33                         // 00000083E24C: CC1A400B 1C86473E
	v_dot2_f32_bf16 v8, v66, v35, v8                           // 00000083E254: CC1A4008 1C224742
	v_cndmask_b32_e64 v35, v2, v3, s3                          // 00000083E25C: D5010023 000E0702
	v_cndmask_b32_e64 v34, v1, v2, s3                          // 00000083E264: D5010022 000E0501
	v_dot2_f32_bf16 v4, v59, v40, v6                           // 00000083E26C: CC1A4004 1C1A513B
	v_dot2_f32_bf16 v5, v63, v40, v11                          // 00000083E274: CC1A4005 1C2E513F
	v_dot2_f32_bf16 v6, v67, v40, v8                           // 00000083E27C: CC1A4006 1C225143
	v_cndmask_b32_e64 v33, v0, v1, s3                          // 00000083E284: D5010021 000E0300
	v_mov_b32_e32 v40, v7                                      // 00000083E28C: 7E500307
	s_waitcnt lgkmcnt(4)                                       // 00000083E290: BF89FC47
	v_dot2_f32_bf16 v2, v60, v9, v4                            // 00000083E294: CC1A4002 1C12133C
	v_dot2_f32_bf16 v3, v64, v9, v5                            // 00000083E29C: CC1A4003 1C161340
	v_dot2_f32_bf16 v4, v68, v9, v6                            // 00000083E2A4: CC1A4004 1C1A1344
	v_add_nc_u32_e32 v19, 0x200, v19                           // 00000083E2AC: 4A2626FF 00000200
	v_add_nc_u32_e32 v29, 0x100, v29                           // 00000083E2B4: 4A3A3AFF 00000100
	s_waitcnt vmcnt(2) lgkmcnt(3)                              // 00000083E2BC: BF890837
	v_dot2_f32_bf16 v0, v69, v10, v2                           // 00000083E2C0: CC1A4000 1C0A1545
	s_waitcnt vmcnt(1)                                         // 00000083E2C8: BF8907F7
	v_dot2_f32_bf16 v1, v73, v10, v3                           // 00000083E2CC: CC1A4001 1C0E1549
	s_waitcnt vmcnt(0)                                         // 00000083E2D4: BF8903F7
	v_dot2_f32_bf16 v2, v77, v10, v4                           // 00000083E2D8: CC1A4002 1C12154D
	v_dual_mov_b32 v11, v15 :: v_dual_mov_b32 v10, v14         // 00000083E2E0: CA10010F 0B0A010E
	s_waitcnt lgkmcnt(2)                                       // 00000083E2E8: BF89FC27
	v_dot2_f32_bf16 v0, v70, v32, v0                           // 00000083E2EC: CC1A4000 1C024146
	v_dot2_f32_bf16 v1, v74, v32, v1                           // 00000083E2F4: CC1A4001 1C06414A
	v_dot2_f32_bf16 v2, v78, v32, v2                           // 00000083E2FC: CC1A4002 1C0A414E
	v_dual_mov_b32 v9, v13 :: v_dual_mov_b32 v8, v12           // 00000083E304: CA10010D 0908010C
	s_waitcnt lgkmcnt(1)                                       // 00000083E30C: BF89FC17
	v_dot2_f32_bf16 v0, v71, v41, v0                           // 00000083E310: CC1A4000 1C025347
	v_dot2_f32_bf16 v1, v75, v41, v1                           // 00000083E318: CC1A4001 1C06534B
	v_dot2_f32_bf16 v2, v79, v41, v2                           // 00000083E320: CC1A4002 1C0A534F
	v_mov_b32_e32 v32, v31                                     // 00000083E328: 7E40031F
	s_waitcnt lgkmcnt(0)                                       // 00000083E32C: BF89FC07
	v_dot2_f32_bf16 v0, v72, v42, v0                           // 00000083E330: CC1A4000 1C025548
	v_dot2_f32_bf16 v1, v76, v42, v1                           // 00000083E338: CC1A4001 1C06554C
	v_dot2_f32_bf16 v2, v80, v42, v2                           // 00000083E340: CC1A4002 1C0A5550
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000083E348: BF870193
	v_fmac_f32_e32 v28, v82, v0                                // 00000083E34C: 56380152
	v_fmac_f32_e32 v27, v82, v1                                // 00000083E350: 56360352
	s_delay_alu instid0(VALU_DEP_3)                            // 00000083E354: BF870003
	v_fmac_f32_e32 v26, v82, v2                                // 00000083E358: 56340552
	v_dual_mov_b32 v0, v33 :: v_dual_mov_b32 v1, v34           // 00000083E35C: CA100121 00000122
	v_dual_mov_b32 v2, v35 :: v_dual_mov_b32 v3, v36           // 00000083E364: CA100123 02020124
	v_dual_mov_b32 v4, v37 :: v_dual_mov_b32 v5, v38           // 00000083E36C: CA100125 04040126
	v_dual_mov_b32 v6, v39 :: v_dual_mov_b32 v7, v40           // 00000083E374: CA100127 06060128
	s_and_not1_b32 exec_lo, exec_lo, s7                        // 00000083E37C: 917E077E
	s_cbranch_execz 28                                         // 00000083E380: BFA5001C <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi16ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x9f4>
	s_waitcnt vmcnt(0)                                         // 00000083E384: BF8903F7
	v_dual_mov_b32 v13, v9 :: v_dual_add_nc_u32 v30, 16, v30   // 00000083E388: CA200109 0D1E3C90
	v_dual_mov_b32 v12, v8 :: v_dual_mov_b32 v15, v11          // 00000083E390: CA100108 0C0E010B
	v_mov_b32_e32 v14, v10                                     // 00000083E398: 7E1C030A
	s_delay_alu instid0(VALU_DEP_3)                            // 00000083E39C: BF870003
	.long 0xd4430004                                           // 00000083E3A0: D4430004
	v_cndmask_b32_e32 v1, s6, v30, vcc_lo                      // 00000083E3A4: 02023C06
	s_mov_b32 s18, exec_lo                                     // 00000083E3A8: BE92007E
	.long 0xd4c4007e                                           // 00000083E3AC: D4C4007E
	v_cndmask_b32_e32 v1, s6, v30, vcc_lo                      // 00000083E3B0: 02023C06
	s_cbranch_execz 65235                                      // 00000083E3B4: BFA5FED3 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi16ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x504>
	.long 0xd7006a0c                                           // 00000083E3B8: D7006A0C
	v_cndmask_b32_e32 v1, v18, v29, vcc_lo                     // 00000083E3BC: 02023B12
	s_delay_alu instid0(VALU_DEP_1)                            // 00000083E3C0: BF870001
	v_add_co_ci_u32_e64 v13, null, 0, v25, vcc_lo              // 00000083E3C4: D5207C0D 01AA3280
	v_cmp_ne_u32_e32 vcc_lo, 1, v24                            // 00000083E3CC: 7C9A3081
	v_mov_b32_e32 v31, v32                                     // 00000083E3D0: 7E3E0320
	global_load_b128 v[12:15], v[12:13], off                   // 00000083E3D4: DC5E0000 0C7C000C
	s_cbranch_vccnz 65225                                      // 00000083E3DC: BFA4FEC9 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi16ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x504>
	global_load_d16_b16 v31, v[21:22], off                     // 00000083E3E0: DC820000 1F7C0015
	s_waitcnt vmcnt(0)                                         // 00000083E3E8: BF8903F7
	v_cvt_f32_f16_e32 v31, v31                                 // 00000083E3EC: 7E3E171F
	s_branch 65220                                             // 00000083E3F0: BFA0FEC4 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi16ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x504>
	s_or_b32 exec_lo, exec_lo, s7                              // 00000083E3F4: 8C7E077E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000083E3F8: BF8700A9
	s_or_b32 exec_lo, exec_lo, s5                              // 00000083E3FC: 8C7E057E
	.long 0xd71f0000                                           // 00000083E400: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 00000083E404: 020100C1
	v_xor_b32_e32 v1, 8, v0                                    // 00000083E408: 3A020088
	v_xor_b32_e32 v4, 4, v0                                    // 00000083E40C: 3A080084
	v_xor_b32_e32 v7, 2, v0                                    // 00000083E410: 3A0E0082
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000083E414: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v1                            // 00000083E418: 7C9802A0
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 00000083E41C: 02020300
	v_cmp_gt_u32_e32 vcc_lo, 32, v4                            // 00000083E420: 7C9808A0
	v_cndmask_b32_e32 v4, v0, v4, vcc_lo                       // 00000083E424: 02080900
	v_cmp_gt_u32_e32 vcc_lo, 32, v7                            // 00000083E428: 7C980EA0
	s_delay_alu instid0(VALU_DEP_2)                            // 00000083E42C: BF870002
	v_lshlrev_b32_e32 v4, 2, v4                                // 00000083E430: 30080882
	v_lshlrev_b32_e32 v1, 2, v1                                // 00000083E434: 30020282
	ds_bpermute_b32 v2, v1, v28                                // 00000083E438: DACC0000 02001C01
	s_waitcnt lgkmcnt(0)                                       // 00000083E440: BF89FC07
	v_add_f32_e32 v2, v28, v2                                  // 00000083E444: 0604051C
	ds_bpermute_b32 v3, v1, v27                                // 00000083E448: DACC0000 03001B01
	ds_bpermute_b32 v1, v1, v26                                // 00000083E450: DACC0000 01001A01
	ds_bpermute_b32 v5, v4, v2                                 // 00000083E458: DACC0000 05000204
	v_cndmask_b32_e32 v7, v0, v7, vcc_lo                       // 00000083E460: 020E0F00
	s_waitcnt lgkmcnt(2)                                       // 00000083E464: BF89FC27
	v_add_f32_e32 v3, v27, v3                                  // 00000083E468: 0606071B
	s_waitcnt lgkmcnt(1)                                       // 00000083E46C: BF89FC17
	v_add_f32_e32 v1, v26, v1                                  // 00000083E470: 0602031A
	s_waitcnt lgkmcnt(0)                                       // 00000083E474: BF89FC07
	v_add_f32_e32 v2, v2, v5                                   // 00000083E478: 06040B02
	ds_bpermute_b32 v6, v4, v3                                 // 00000083E47C: DACC0000 06000304
	ds_bpermute_b32 v4, v4, v1                                 // 00000083E484: DACC0000 04000104
	s_waitcnt lgkmcnt(0)                                       // 00000083E48C: BF89FC07
	v_dual_add_f32 v4, v1, v4 :: v_dual_lshlrev_b32 v7, 2, v7  // 00000083E490: C9220901 04060E82
	ds_bpermute_b32 v1, v7, v2                                 // 00000083E498: DACC0000 01000207
	v_add_f32_e32 v3, v3, v6                                   // 00000083E4A0: 06060D03
	ds_bpermute_b32 v6, v7, v4                                 // 00000083E4A4: DACC0000 06000407
	ds_bpermute_b32 v5, v7, v3                                 // 00000083E4AC: DACC0000 05000307
	v_xor_b32_e32 v7, 1, v0                                    // 00000083E4B4: 3A0E0081
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 00000083E4B8: BF870141
	v_cmp_gt_u32_e32 vcc_lo, 32, v7                            // 00000083E4BC: 7C980EA0
	v_cndmask_b32_e32 v0, v0, v7, vcc_lo                       // 00000083E4C0: 02000F00
	v_cmp_eq_u32_e32 vcc_lo, 0, v23                            // 00000083E4C4: 7C942E80
	s_waitcnt lgkmcnt(2)                                       // 00000083E4C8: BF89FC27
	v_dual_add_f32 v0, v2, v1 :: v_dual_lshlrev_b32 v7, 2, v0  // 00000083E4CC: C9220302 00060082
	s_waitcnt lgkmcnt(1)                                       // 00000083E4D4: BF89FC17
	v_add_f32_e32 v2, v4, v6                                   // 00000083E4D8: 06040D04
	s_and_b32 s2, vcc_lo, s2                                   // 00000083E4DC: 8B02026A
	s_waitcnt lgkmcnt(0)                                       // 00000083E4E0: BF89FC07
	v_add_f32_e32 v1, v3, v5                                   // 00000083E4E4: 06020B03
	ds_bpermute_b32 v3, v7, v0                                 // 00000083E4E8: DACC0000 03000007
	ds_bpermute_b32 v5, v7, v2                                 // 00000083E4F0: DACC0000 05000207
	ds_bpermute_b32 v4, v7, v1                                 // 00000083E4F8: DACC0000 04000107
	s_and_saveexec_b32 s3, s2                                  // 00000083E500: BE832002
	s_cbranch_execz 147                                        // 00000083E504: BFA50093 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi16ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0xd54>
	s_load_b32 s0, s[0:1], 0x48                                // 00000083E508: F4000000 F8000048
	s_waitcnt lgkmcnt(0)                                       // 00000083E510: BF89FC07
	v_dual_add_f32 v0, v0, v3 :: v_dual_add_f32 v1, v1, v4     // 00000083E514: C9080700 00000901
	s_lshl_b64 s[2:3], s[16:17], 2                             // 00000083E51C: 84828210
	s_lshl_b64 s[4:5], s[16:17], 3                             // 00000083E520: 84848310
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000083E524: BF870111
	v_bfe_u32 v3, v0, 16, 1                                    // 00000083E528: D6100003 02052100
	v_bfe_u32 v4, v1, 16, 1                                    // 00000083E530: D6100004 02052101
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000083E538: BF870112
	v_add3_u32 v0, v0, v3, 0x7fff                              // 00000083E53C: D6550000 03FE0700 00007FFF
	v_add3_u32 v1, v1, v4, 0x7fff                              // 00000083E548: D6550001 03FE0901 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000083E554: BF870091
	v_and_b32_e32 v1, 0xffff0000, v1                           // 00000083E558: 360202FF FFFF0000
	v_dual_mul_f32 v1, s0, v1 :: v_dual_and_b32 v0, 0xffff0000, v0// 00000083E560: C8E40200 010000FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000083E56C: BF870091
	v_dual_mul_f32 v0, s0, v0 :: v_dual_mul_f32 v1, 0xbfb8aa3b, v1// 00000083E570: C8C60000 000002FF BFB8AA3B
	v_mul_f32_e32 v0, 0xbfb8aa3b, v0                           // 00000083E57C: 100000FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000083E584: BF870092
	v_exp_f32_e32 v1, v1                                       // 00000083E588: 7E024B01
	v_exp_f32_e32 v0, v0                                       // 00000083E58C: 7E004B00
	v_add_f32_e32 v2, v2, v5                                   // 00000083E590: 06040B02
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000083E594: BF870115
	v_dual_add_f32 v4, 1.0, v1 :: v_dual_add_f32 v3, 1.0, v0   // 00000083E598: C90802F2 040200F2
	v_bfe_u32 v5, v2, 16, 1                                    // 00000083E5A0: D6100005 02052102
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000083E5A8: BF8701A2
	v_div_scale_f32 v6, null, v4, v4, 1.0                      // 00000083E5AC: D6FC7C06 03CA0904
	s_waitcnt vmcnt(0)                                         // 00000083E5B4: BF8903F7
	v_div_scale_f32 v11, vcc_lo, 1.0, v3, 1.0                  // 00000083E5B8: D6FC6A0B 03CA06F2
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000083E5C0: BF8700B3
	v_add3_u32 v2, v2, v5, 0x7fff                              // 00000083E5C4: D6550002 03FE0B02 00007FFF
	v_div_scale_f32 v5, null, v3, v3, 1.0                      // 00000083E5D0: D6FC7C05 03CA0703
	v_rcp_f32_e32 v9, v6                                       // 00000083E5D8: 7E125506
	v_rcp_f32_e32 v8, v5                                       // 00000083E5DC: 7E105505
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(SKIP_1) | instid1(TRANS32_DEP_1)// 00000083E5E0: BF8702A6
	v_fma_f32 v1, -v6, v9, 1.0                                 // 00000083E5E4: D6130001 23CA1306
	v_and_b32_e32 v2, 0xffff0000, v2                           // 00000083E5EC: 360404FF FFFF0000
	v_fma_f32 v0, -v5, v8, 1.0                                 // 00000083E5F4: D6130000 23CA1105
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000083E5FC: BF8701A2
	v_dual_fmac_f32 v9, v1, v9 :: v_dual_mul_f32 v2, s0, v2    // 00000083E600: C8061301 09020400
	v_div_scale_f32 v13, s0, 1.0, v4, 1.0                      // 00000083E608: D6FC000D 03CA08F2
	v_fmac_f32_e32 v8, v0, v8                                  // 00000083E610: 56101100
	.long 0xd73c0000                                           // 00000083E614: D73C0000
	v_cndmask_b32_e32 v1, 2, v16, vcc_lo                       // 00000083E618: 02022082
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000083E61C: BF870093
	v_mul_f32_e32 v15, v13, v9                                 // 00000083E620: 101E130D
	v_fma_f32 v20, -v6, v15, v13                               // 00000083E624: D6130014 24361F06
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000083E62C: BF870091
	v_dual_mul_f32 v2, 0xbfb8aa3b, v2 :: v_dual_fmac_f32 v15, v20, v9// 00000083E630: C8C004FF 020E1314 BFB8AA3B
	v_exp_f32_e32 v2, v2                                       // 00000083E63C: 7E044B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000083E640: BF870291
	v_fma_f32 v6, -v6, v15, v13                                // 00000083E644: D6130006 24361F06
	v_add_f32_e32 v2, 1.0, v2                                  // 00000083E64C: 060404F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000083E650: BF870121
	v_div_scale_f32 v7, null, v2, v2, 1.0                      // 00000083E654: D6FC7C07 03CA0502
	v_div_scale_f32 v14, s1, 1.0, v2, 1.0                      // 00000083E65C: D6FC010E 03CA04F2
	v_rcp_f32_e32 v10, v7                                      // 00000083E664: 7E145507
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000083E668: BF870095
	v_fma_f32 v12, -v7, v10, 1.0                               // 00000083E66C: D613000C 23CA1507
	v_fmac_f32_e32 v10, v12, v10                               // 00000083E674: 5614150C
	v_mul_f32_e32 v12, v11, v8                                 // 00000083E678: 1018110B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000083E67C: BF870112
	v_mul_f32_e32 v18, v14, v10                                // 00000083E680: 1024150E
	v_fma_f32 v19, -v5, v12, v11                               // 00000083E684: D6130013 242E1905
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000083E68C: BF870112
	v_fma_f32 v21, -v7, v18, v14                               // 00000083E690: D6130015 243A2507
	v_fmac_f32_e32 v12, v19, v8                                // 00000083E698: 56181113
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000083E69C: BF870112
	v_fmac_f32_e32 v18, v21, v10                               // 00000083E6A0: 56241515
	v_fma_f32 v5, -v5, v12, v11                                // 00000083E6A4: D6130005 242E1905
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000083E6AC: BF870112
	v_fma_f32 v7, -v7, v18, v14                                // 00000083E6B0: D6130007 243A2507
	v_div_fmas_f32 v5, v5, v8, v12                             // 00000083E6B8: D6370005 04321105
	s_mov_b32 vcc_lo, s0                                       // 00000083E6C0: BEEA0000
	v_div_fmas_f32 v6, v6, v9, v15                             // 00000083E6C4: D6370006 043E1306
	s_mov_b32 vcc_lo, s1                                       // 00000083E6CC: BEEA0001
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000083E6D0: BF8700B2
	v_div_fixup_f32 v5, v5, v3, 1.0                            // 00000083E6D4: D6270005 03CA0705
	v_div_fmas_f32 v7, v7, v10, v18                            // 00000083E6DC: D6370007 044A1507
	.long 0xd7006a00                                           // 00000083E6E4: D7006A00
	v_cndmask_b32_e32 v1, s12, v0, vcc_lo                      // 00000083E6E8: 0202000C
	v_add_co_ci_u32_e64 v1, null, s13, v1, vcc_lo              // 00000083E6EC: D5207C01 01AA020D
	v_div_fixup_f32 v4, v6, v4, 1.0                            // 00000083E6F4: D6270004 03CA0906
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000083E6FC: BF870214
	v_div_fixup_f32 v6, v7, v2, 1.0                            // 00000083E700: D6270006 03CA0507
	.long 0xd7006a02                                           // 00000083E708: D7006A02
	v_cndmask_b32_e32 v0, v0, v2, vcc_lo                       // 00000083E70C: 02000500
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000083E710: BF870211
	v_add_co_ci_u32_e64 v3, null, s3, v1, vcc_lo               // 00000083E714: D5207C03 01AA0203
	v_dual_add_f32 v7, v5, v5 :: v_dual_add_f32 v8, v4, v4     // 00000083E71C: C9080B05 07080904
	.long 0xd7006a04                                           // 00000083E724: D7006A04
	v_cndmask_b32_e32 v0, v0, v4, vcc_lo                       // 00000083E728: 02000900
	v_add_f32_e32 v6, v6, v6                                   // 00000083E72C: 060C0D06
	v_add_co_ci_u32_e64 v5, null, s5, v1, vcc_lo               // 00000083E730: D5207C05 01AA0205
	s_clause 0x2                                               // 00000083E738: BF850002
	global_store_b32 v[0:1], v7, off                           // 00000083E73C: DC6A0000 007C0700
	global_store_b32 v[2:3], v8, off                           // 00000083E744: DC6A0000 007C0802
	global_store_b32 v[4:5], v6, off                           // 00000083E74C: DC6A0000 007C0604
	s_endpgm                                                   // 00000083E754: BFB00000
		...

