0000000000355100 <_ZN7halogen12_GLOBAL__N_16k_lq6wILi8ELi32ELi1EEEvPKhPKtPtll>:
; _ZN7halogen12_GLOBAL__N_16k_lq6wILi8ELi32ELi1EEEvPKhPKtPtll():
	s_load_b256 s[4:11], s[0:1], null                          // 000000355100: F40C0100 F8000000
	s_mov_b32 s3, 0                                            // 000000355108: BE830080
	v_lshrrev_b32_e32 v1, 5, v0                                // 00000035510C: 32020085
	s_lshl_b64 s[12:13], s[2:3], 3                             // 000000355110: 848C8302
	s_load_b64 s[2:3], s[0:1], 0x20                            // 000000355114: F4040080 F8000020
	v_mov_b32_e32 v9, s13                                      // 00000035511C: 7E12020D
	v_dual_mov_b32 v6, 0 :: v_dual_and_b32 v17, 31, v0         // 000000355120: CA240080 0610009F
	v_or_b32_e32 v8, s12, v1                                   // 000000355128: 3810020C
	v_dual_mov_b32 v4, 0 :: v_dual_mov_b32 v5, 0               // 00000035512C: CA100080 04040080
	v_dual_mov_b32 v7, 0 :: v_dual_mov_b32 v16, 0              // 000000355134: CA100080 07100080
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(SALU_CYCLE_1)// 00000035513C: BF8704D3
	.long 0xd73c0001                                           // 000000355140: D73C0001
	v_cndmask_b32_e32 v1, 4, v8, vcc_lo                        // 000000355144: 02021084
	v_mov_b32_e32 v15, 0                                       // 000000355148: 7E1E0280
	v_dual_mov_b32 v47, 0 :: v_dual_mov_b32 v18, 0             // 00000035514C: CA100080 2F120080
	s_waitcnt lgkmcnt(0)                                       // 000000355154: BF89FC07
	s_ashr_i32 s16, s11, 31                                    // 000000355158: 86109F0B
	s_lshr_b32 s0, s16, 27                                     // 00000035515C: 85009B10
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000355160: BF870009
	s_add_u32 s0, s10, s0                                      // 000000355164: 8000000A
	s_addc_u32 s1, s11, 0                                      // 000000355168: 8201800B
	s_lshr_b32 s14, s11, 31                                    // 00000035516C: 850E9F0B
	s_lshr_b64 s[12:13], s[0:1], 5                             // 000000355170: 858C8500
	s_add_u32 s0, s10, s14                                     // 000000355174: 80000E0A
	s_addc_u32 s1, s11, 0                                      // 000000355178: 8201800B
	s_lshr_b32 s13, s16, 30                                    // 00000035517C: 850D9E10
	s_ashr_i64 s[14:15], s[0:1], 1                             // 000000355180: 868E8100
	s_add_u32 s0, s10, s13                                     // 000000355184: 80000D0A
	s_addc_u32 s1, s11, 0                                      // 000000355188: 8201800B
	s_lshr_b32 s13, s16, 28                                    // 00000035518C: 850D9C10
	s_ashr_i64 s[16:17], s[0:1], 2                             // 000000355190: 86908200
	s_add_u32 s0, s10, s13                                     // 000000355194: 80000D0A
	s_addc_u32 s1, s11, 0                                      // 000000355198: 8201800B
	v_cmp_gt_i64_e32 vcc_lo, s[2:3], v[8:9]                    // 00000035519C: 7CA81002
	s_ashr_i64 s[0:1], s[0:1], 4                               // 0000003551A0: 86808400
	s_add_u32 s13, s16, s14                                    // 0000003551A4: 800D0E10
	s_addc_u32 s18, s17, s15                                   // 0000003551A8: 82120F11
	s_add_u32 s0, s13, s0                                      // 0000003551AC: 8000000D
	s_addc_u32 s1, s18, s1                                     // 0000003551B0: 82010112
	s_add_u32 s0, s0, 15                                       // 0000003551B4: 80008F00
	s_addc_u32 s1, s1, 0                                       // 0000003551B8: 82018001
	v_cndmask_b32_e32 v2, 0, v2, vcc_lo                        // 0000003551BC: 02040480
	s_ashr_i32 s13, s1, 31                                     // 0000003551C0: 860D9F01
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 0000003551C4: 02020280
	s_lshr_b32 s13, s13, 28                                    // 0000003551C8: 850D9C0D
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000003551CC: BF8704A9
	s_add_u32 s0, s0, s13                                      // 0000003551D0: 80000D00
	s_addc_u32 s1, s1, 0                                       // 0000003551D4: 82018001
	s_ashr_i64 s[0:1], s[0:1], 4                               // 0000003551D8: 86808400
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000003551DC: BF870149
	.long 0xd72c0003                                           // 0000003551E0: D72C0003
	v_cndmask_b32_e32 v0, v1, v1, vcc_lo                       // 0000003551E4: 02000301
	.long 0xd72c0002                                           // 0000003551E8: D72C0002
	v_cndmask_b32_e32 v0, v2, v0, vcc_lo                       // 0000003551EC: 02000102
	v_mad_u64_u32 v[10:11], null, v1, s0, s[4:5]               // 0000003551F0: D6FE7C0A 00100101
	.long 0xd4440000                                           // 0000003551F8: D4440000
	v_cndmask_b32_e32 v1, s12, v17, vcc_lo                     // 0000003551FC: 0202220C
	v_add3_u32 v20, v2, v11, v3                                // 000000355200: D6550014 040E1702
	s_and_saveexec_b32 s4, s0                                  // 000000355208: BE842000
	s_cbranch_execz 35                                         // 00000035520C: BFA50023 <_ZN7halogen12_GLOBAL__N_16k_lq6wILi8ELi32ELi1EEEvPKhPKtPtll+0x19c>
	v_lshlrev_b32_e32 v1, 4, v17                               // 000000355210: 30022284
	v_lshlrev_b32_e32 v0, 1, v0                                // 000000355214: 30000081
	v_lshlrev_b32_e32 v5, 3, v17                               // 000000355218: 300A2283
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000035521C: BF870093
	.long 0xd7000101                                           // 000000355220: D7000101
	v_cndmask_b32_e32 v1, v10, v1, vcc_lo                      // 000000355224: 0202030A
	v_add_co_ci_u32_e64 v2, null, 0, v20, s1                   // 000000355228: D5207C02 00062880
	.long 0xd7000103                                           // 000000355230: D7000103
	v_cndmask_b32_e32 v0, v10, v14, vcc_lo                     // 000000355234: 02001D0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000355238: BF8701A1
	v_add_co_ci_u32_e64 v4, null, s15, v20, s1                 // 00000035523C: D5207C04 0006280F
	v_and_b32_e32 v0, 60, v0                                   // 000000355244: 360000BC
	.long 0xd7000106                                           // 000000355248: D7000106
	v_cndmask_b32_e32 v0, v3, v16, vcc_lo                      // 00000035524C: 02002103
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000355250: BF8700A1
	v_add_co_ci_u32_e64 v7, null, s17, v4, s1                  // 000000355254: D5207C07 00060811
	.long 0xd700010b                                           // 00000035525C: D700010B
	v_cndmask_b32_e32 v1, v3, v5, vcc_lo                       // 000000355260: 02020B03
	v_add_co_ci_u32_e64 v12, null, 0, v4, s1                   // 000000355264: D5207C0C 00060880
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000035526C: BF870094
	.long 0xd700010d                                           // 000000355270: D700010D
	v_cndmask_b32_e32 v1, v6, v0, vcc_lo                       // 000000355274: 02020106
	v_add_co_ci_u32_e64 v14, null, 0, v7, s1                   // 000000355278: D5207C0E 00060E80
	s_clause 0x2                                               // 000000355280: BF850002
	global_load_b128 v[4:7], v[1:2], off                       // 000000355284: DC5E0000 047C0001
	global_load_b64 v[15:16], v[11:12], off                    // 00000035528C: DC560000 0F7C000B
	global_load_b32 v47, v[13:14], off                         // 000000355294: DC520000 2F7C000D
	s_or_b32 exec_lo, exec_lo, s4                              // 00000035529C: 8C7E047E
	v_dual_mov_b32 v19, 0 :: v_dual_mov_b32 v22, 0             // 0000003552A0: CA100080 13160080
	v_dual_mov_b32 v21, 0 :: v_dual_mov_b32 v24, 0             // 0000003552A8: CA100080 15180080
	v_dual_mov_b32 v23, 0 :: v_dual_mov_b32 v26, 0             // 0000003552B0: CA100080 171A0080
	v_mov_b32_e32 v25, 0                                       // 0000003552B8: 7E320280
	s_and_saveexec_b32 s13, s0                                 // 0000003552BC: BE8D2000
	s_cbranch_execz 1133                                       // 0000003552C0: BFA5046D <_ZN7halogen12_GLOBAL__N_16k_lq6wILi8ELi32ELi1EEEvPKhPKtPtll+0x1378>
	.long 0xd700001b                                           // 0000003552C4: D700001B
	v_cndmask_b32_e32 v0, v10, v14, vcc_lo                     // 0000003552C8: 02001D0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000003552CC: BF8701A1
	v_add_co_ci_u32_e64 v28, null, s15, v20, s0                // 0000003552D0: D5207C1C 0002280F
	v_dual_mov_b32 v12, 0 :: v_dual_lshlrev_b32 v11, 5, v17    // 0000003552D8: CA220080 0C0A2285
	.long 0xd700001d                                           // 0000003552E0: D700001D
	v_cndmask_b32_e32 v0, v27, v16, vcc_lo                     // 0000003552E4: 0200211B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003552E8: BF870001
	v_add_co_ci_u32_e64 v30, null, s17, v28, s0                // 0000003552EC: D5207C1E 00023811
	v_lshl_or_b32 v31, v17, 4, 0x200                           // 0000003552F4: D656001F 03FD0911 00000200
	v_lshl_or_b32 v32, v17, 3, 0x100                           // 000000355300: D6560020 03FD0711 00000100
	v_lshl_or_b32 v33, v17, 1, 64                              // 00000035530C: D6560021 03010311
	s_waitcnt vmcnt(0)                                         // 000000355314: BF8903F7
	v_dual_mov_b32 v18, v12 :: v_dual_mov_b32 v35, v47         // 000000355318: CA10010C 1222012F
	v_dual_mov_b32 v19, v12 :: v_dual_mov_b32 v34, v17         // 000000355320: CA10010C 13220111
	v_mov_b32_e32 v21, v12                                     // 000000355328: 7E2A030C
	v_mov_b32_e32 v22, v12                                     // 00000035532C: 7E2C030C
	v_mov_b32_e32 v23, v12                                     // 000000355330: 7E2E030C
	v_mov_b32_e32 v24, v12                                     // 000000355334: 7E30030C
	v_mov_b32_e32 v25, v12                                     // 000000355338: 7E32030C
	v_mov_b32_e32 v26, v12                                     // 00000035533C: 7E34030C
	s_mul_i32 s0, s11, 6                                       // 000000355340: 9600860B
	s_mul_hi_u32 s1, s10, 6                                    // 000000355344: 9681860A
	s_lshl_b64 s[4:5], s[10:11], 2                             // 000000355348: 8484820A
	s_add_i32 s14, s1, s0                                      // 00000035534C: 810E0001
	s_mul_i32 s16, s10, 6                                      // 000000355350: 9610860A
	s_mov_b32 s15, 0                                           // 000000355354: BE8F0080
	s_lshl_b64 s[10:11], s[10:11], 1                           // 000000355358: 848A810A
	s_branch 1055                                              // 00000035535C: BFA0041F <_ZN7halogen12_GLOBAL__N_16k_lq6wILi8ELi32ELi1EEEvPKhPKtPtll+0x12dc>
	s_or_b32 exec_lo, exec_lo, s17                             // 000000355360: 8C7E117E
	v_lshlrev_b32_e32 v36, 4, v15                              // 000000355364: 30481E84
	v_lshlrev_b32_e32 v38, 2, v15                              // 000000355368: 304C1E82
	v_lshrrev_b32_e32 v37, 4, v4                               // 00000035536C: 324A0884
	.long 0x7f603880                                           // 000000355370: 7F603880
	v_lshrrev_b32_e32 v39, 6, v15                              // 000000355374: 324E1E86
	v_and_b32_e32 v36, 48, v36                                 // 000000355378: 364848B0
	v_and_b32_e32 v38, 48, v38                                 // 00000035537C: 364C4CB0
	v_lshrrev_b32_e32 v40, 22, v15                             // 000000355380: 32501E96
	v_lshrrev_b32_e32 v42, 6, v16                              // 000000355384: 32542086
	v_and_b32_e32 v39, 48, v39                                 // 000000355388: 364E4EB0
	v_and_or_b32 v36, v4, 15, v36                              // 00000035538C: D6570024 04911F04
	v_and_or_b32 v37, v37, 15, v38                             // 000000355394: D6570025 04991F25
	v_and_b32_e32 v40, 48, v40                                 // 00000035539C: 365050B0
	v_lshrrev_b32_e32 v41, 20, v6                              // 0000003553A0: 32520C94
	v_and_b32_e32 v42, 48, v42                                 // 0000003553A4: 365454B0
	v_cvt_f32_ubyte0_e32 v36, v36                              // 0000003553A8: 7E482324
	v_lshrrev_b32_e32 v50, 18, v16                             // 0000003553AC: 32642092
	v_lshrrev_b32_e32 v51, 22, v16                             // 0000003553B0: 32662096
	s_and_b32 s0, exec_lo, s0                                  // 0000003553B4: 8B00007E
	v_and_or_b32 v41, v41, 15, v42                             // 0000003553B8: D6570029 04A91F29
	v_fma_mix_f32 v36, v36, v47, v47 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003553C0: CC206024 14BE5F24
	v_and_b32_e32 v50, 48, v50                                 // 0000003553C8: 366464B0
	v_and_b32_e32 v51, 48, v51                                 // 0000003553CC: 366666B0
	s_or_b32 s15, s0, s15                                      // 0000003553D0: 8C0F0F00
	v_add_nc_u32_e32 v31, 0x200, v31                           // 0000003553D4: 4A3E3EFF 00000200
	v_bfe_u32 v38, v36, 16, 1                                  // 0000003553DC: D6100026 02052124
	v_add_nc_u32_e32 v32, 0x100, v32                           // 0000003553E4: 4A4040FF 00000100
	v_add_nc_u32_e32 v33, 64, v33                              // 0000003553EC: 4A4242C0
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000003553F0: BF870123
	v_add3_u32 v36, v36, v38, 0x7fff                           // 0000003553F4: D6550024 03FE4D24 00007FFF
	v_lshrrev_b32_e32 v38, 2, v15                              // 000000355400: 324C1E82
	.long 0x7e6039a4                                           // 000000355404: 7E6039A4
	v_cvt_f32_ubyte0_e32 v36, v37                              // 000000355408: 7E482325
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000035540C: BF870113
	v_and_b32_e32 v38, 48, v38                                 // 000000355410: 364C4CB0
	v_fma_mix_f32 v36, v36, v47, v47 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000355414: CC206024 14BE5F24
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000035541C: BF870091
	v_bfe_u32 v37, v36, 16, 1                                  // 000000355420: D6100025 02052124
	v_add3_u32 v36, v36, v37, 0x7fff                           // 000000355428: D6550024 03FE4B24 00007FFF
	v_and_b32_e32 v37, 48, v15                                 // 000000355434: 364A1EB0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000355438: BF8700A2
	v_and_or_b32 v43, 0xffff0000, v36, v48                     // 00000035543C: D657002B 04C248FF FFFF0000
	v_lshrrev_b32_e32 v36, 8, v4                               // 000000355448: 32480888
	v_and_or_b32 v36, v36, 15, v37                             // 00000035544C: D6570024 04951F24
	v_lshrrev_b32_e32 v37, 12, v4                              // 000000355454: 324A088C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000355458: BF870112
	v_cvt_f32_ubyte0_e32 v36, v36                              // 00000035545C: 7E482324
	v_and_or_b32 v37, v37, 15, v38                             // 000000355460: D6570025 04991F25
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000355468: BF870092
	v_fma_mix_f32 v36, v36, v47, v47 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000035546C: CC206024 14BE5F24
	v_bfe_u32 v38, v36, 16, 1                                  // 000000355474: D6100026 02052124
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000035547C: BF870121
	v_add3_u32 v36, v36, v38, 0x7fff                           // 000000355480: D6550024 03FE4D24 00007FFF
	v_lshrrev_b32_e32 v38, 20, v4                              // 00000035548C: 324C0894
	.long 0x7e6039a4                                           // 000000355490: 7E6039A4
	v_cvt_f32_ubyte0_e32 v36, v37                              // 000000355494: 7E482325
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000355498: BF870113
	v_and_or_b32 v38, v38, 15, v39                             // 00000035549C: D6570026 049D1F26
	v_fma_mix_f32 v36, v36, v47, v47 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003554A4: CC206024 14BE5F24
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003554AC: BF870091
	v_bfe_u32 v37, v36, 16, 1                                  // 0000003554B0: D6100025 02052124
	v_add3_u32 v36, v36, v37, 0x7fff                           // 0000003554B8: D6550024 03FE4B24 00007FFF
	v_lshrrev_b32_e32 v37, 4, v15                              // 0000003554C4: 324A1E84
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000003554C8: BF8701A2
	v_and_or_b32 v44, 0xffff0000, v36, v48                     // 0000003554CC: D657002C 04C248FF FFFF0000
	.long 0x7e603984                                           // 0000003554D8: 7E603984
	v_and_b32_e32 v37, 48, v37                                 // 0000003554DC: 364A4AB0
	v_lshrrev_b32_e32 v36, 8, v15                              // 0000003554E0: 32481E88
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003554E4: BF870112
	v_and_or_b32 v37, v48, 15, v37                             // 0000003554E8: D6570025 04951F30
	v_and_b32_e32 v36, 48, v36                                 // 0000003554F0: 364848B0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003554F4: BF870092
	v_cvt_f32_ubyte0_e32 v37, v37                              // 0000003554F8: 7E4A2325
	v_fma_mix_f32 v37, v37, v47, v47 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003554FC: CC206025 14BE5F25
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000355504: BF870091
	v_bfe_u32 v39, v37, 16, 1                                  // 000000355508: D6100027 02052125
	v_add3_u32 v37, v37, v39, 0x7fff                           // 000000355510: D6550025 03FE4F25 00007FFF
	v_lshrrev_b32_e32 v39, 18, v15                             // 00000035551C: 324E1E92
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000355520: BF8701A2
	.long 0x7e6039a5                                           // 000000355524: 7E6039A5
	v_cvt_f32_ubyte0_e32 v37, v38                              // 000000355528: 7E4A2326
	v_and_b32_e32 v39, 48, v39                                 // 00000035552C: 364E4EB0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000355530: BF870092
	v_fma_mix_f32 v37, v37, v47, v47 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000355534: CC206025 14BE5F25
	v_bfe_u32 v38, v37, 16, 1                                  // 00000035553C: D6100026 02052125
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000355544: BF870121
	v_add3_u32 v37, v37, v38, 0x7fff                           // 000000355548: D6550025 03FE4D25 00007FFF
	v_lshrrev_b32_e32 v38, 12, v15                             // 000000355554: 324C1E8C
	v_and_or_b32 v45, 0xffff0000, v37, v48                     // 000000355558: D657002D 04C24AFF FFFF0000
	v_lshrrev_b32_e32 v37, 24, v4                              // 000000355564: 324A0898
	v_lshrrev_b32_e32 v4, 28, v4                               // 000000355568: 3208089C
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000035556C: BF870122
	v_and_or_b32 v36, v37, 15, v36                             // 000000355570: D6570024 04911F25
	v_lshrrev_b32_e32 v37, 10, v15                             // 000000355578: 324A1E8A
	v_cvt_f32_ubyte0_e32 v36, v36                              // 00000035557C: 7E482324
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000355580: BF870112
	v_and_or_b32 v4, v37, 48, v4                               // 000000355584: D6570004 04116125
	v_fma_mix_f32 v36, v36, v47, v47 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000035558C: CC206024 14BE5F24
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000355594: BF870112
	v_cvt_f32_ubyte0_e32 v4, v4                                // 000000355598: 7E082304
	v_bfe_u32 v37, v36, 16, 1                                  // 00000035559C: D6100025 02052124
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003555A4: BF870112
	v_fma_mix_f32 v4, v4, v47, v47 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003555A8: CC206004 14BE5F04
	v_add3_u32 v36, v36, v37, 0x7fff                           // 0000003555B0: D6550024 03FE4B24 00007FFF
	v_lshrrev_b32_e32 v37, 14, v15                             // 0000003555BC: 324A1E8E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003555C0: BF870212
	.long 0x7e6039a4                                           // 0000003555C4: 7E6039A4
	v_bfe_u32 v36, v4, 16, 1                                   // 0000003555C8: D6100024 02052104
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003555D0: BF870113
	v_and_b32_e32 v37, 48, v37                                 // 0000003555D4: 364A4AB0
	v_add3_u32 v4, v4, v36, 0x7fff                             // 0000003555D8: D6550004 03FE4904 00007FFF
	v_lshrrev_b32_e32 v36, 4, v5                               // 0000003555E4: 32480A84
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000003555E8: BF8701A2
	v_and_or_b32 v46, 0xffff0000, v4, v48                      // 0000003555EC: D657002E 04C208FF FFFF0000
	v_and_b32_e32 v4, 48, v38                                  // 0000003555F8: 36084CB0
	v_and_or_b32 v36, v36, 15, v37                             // 0000003555FC: D6570024 04951F24
	.long 0x7e60398f                                           // 000000355604: 7E60398F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000355608: BF870193
	v_and_or_b32 v4, v5, 15, v4                                // 00000035560C: D6570004 04111F05
	v_cvt_f32_ubyte0_e32 v36, v36                              // 000000355614: 7E482324
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000355618: BF870193
	v_and_b32_e32 v38, 48, v48                                 // 00000035561C: 364C60B0
	v_cvt_f32_ubyte0_e32 v4, v4                                // 000000355620: 7E082304
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000355624: BF870113
	v_fma_mix_f32 v36, v36, v47, v47 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000355628: CC206024 14BE5F24
	v_fma_mix_f32 v4, v4, v47, v47 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000355630: CC206004 14BE5F04
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000355638: BF870091
	v_bfe_u32 v37, v4, 16, 1                                   // 00000035563C: D6100025 02052104
	v_add3_u32 v4, v4, v37, 0x7fff                             // 000000355644: D6550004 03FE4B04 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000355650: BF870114
	v_bfe_u32 v37, v36, 16, 1                                  // 000000355654: D6100025 02052124
	.long 0x7e083984                                           // 00000035565C: 7E083984
	.long 0x7f0839b0                                           // 000000355660: 7F0839B0
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000355664: BF870123
	v_add3_u32 v36, v36, v37, 0x7fff                           // 000000355668: D6550024 03FE4B24 00007FFF
	v_lshrrev_b32_e32 v37, 20, v15                             // 000000355674: 324A1E94
	v_and_or_b32 v4, 0xffff0000, v36, v4                       // 000000355678: D6570004 041248FF FFFF0000
	v_lshrrev_b32_e32 v36, 8, v5                               // 000000355684: 32480A88
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000355688: BF870113
	v_and_b32_e32 v37, 48, v37                                 // 00000035568C: 364A4AB0
	v_and_or_b32 v36, v36, 15, v38                             // 000000355690: D6570024 04991F24
	v_lshrrev_b32_e32 v38, 12, v5                              // 000000355698: 324C0A8C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000035569C: BF870112
	v_cvt_f32_ubyte0_e32 v36, v36                              // 0000003556A0: 7E482324
	v_and_or_b32 v38, v38, 15, v39                             // 0000003556A4: D6570026 049D1F26
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003556AC: BF870092
	v_fma_mix_f32 v36, v36, v47, v47 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003556B0: CC206024 14BE5F24
	v_bfe_u32 v39, v36, 16, 1                                  // 0000003556B8: D6100027 02052124
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000003556C0: BF870121
	v_add3_u32 v36, v36, v39, 0x7fff                           // 0000003556C4: D6550024 03FE4F24 00007FFF
	v_lshrrev_b32_e32 v39, 20, v5                              // 0000003556D0: 324E0A94
	.long 0x7e6039a4                                           // 0000003556D4: 7E6039A4
	v_cvt_f32_ubyte0_e32 v36, v38                              // 0000003556D8: 7E482326
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003556DC: BF870113
	v_and_or_b32 v39, v39, 15, v40                             // 0000003556E0: D6570027 04A11F27
	v_fma_mix_f32 v36, v36, v47, v47 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003556E8: CC206024 14BE5F24
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003556F0: BF870091
	v_bfe_u32 v38, v36, 16, 1                                  // 0000003556F4: D6100026 02052124
	v_add3_u32 v36, v36, v38, 0x7fff                           // 0000003556FC: D6550024 03FE4D24 00007FFF
	v_lshrrev_b32_e32 v38, 24, v15                             // 000000355708: 324C1E98
	v_lshrrev_b32_e32 v15, 26, v15                             // 00000035570C: 321E1E9A
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000355710: BF870223
	v_and_or_b32 v36, 0xffff0000, v36, v48                     // 000000355714: D6570024 04C248FF FFFF0000
	.long 0x7e603985                                           // 000000355720: 7E603985
	v_and_b32_e32 v38, 48, v38                                 // 000000355724: 364C4CB0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000355728: BF870092
	v_and_or_b32 v37, v48, 15, v37                             // 00000035572C: D6570025 04951F30
	v_cvt_f32_ubyte0_e32 v37, v37                              // 000000355734: 7E4A2325
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000355738: BF870091
	v_fma_mix_f32 v37, v37, v47, v47 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000035573C: CC206025 14BE5F25
	v_bfe_u32 v40, v37, 16, 1                                  // 000000355744: D6100028 02052125
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000035574C: BF870121
	v_add3_u32 v37, v37, v40, 0x7fff                           // 000000355750: D6550025 03FE5125 00007FFF
	v_lshrrev_b32_e32 v40, 2, v16                              // 00000035575C: 32502082
	.long 0x7e6039a5                                           // 000000355760: 7E6039A5
	v_cvt_f32_ubyte0_e32 v37, v39                              // 000000355764: 7E4A2327
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000355768: BF870113
	v_and_b32_e32 v40, 48, v40                                 // 00000035576C: 365050B0
	v_fma_mix_f32 v37, v37, v47, v47 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000355770: CC206025 14BE5F25
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000355778: BF870091
	v_bfe_u32 v39, v37, 16, 1                                  // 00000035577C: D6100027 02052125
	v_add3_u32 v37, v37, v39, 0x7fff                           // 000000355784: D6550025 03FE4F25 00007FFF
	v_lshrrev_b32_e32 v39, 24, v5                              // 000000355790: 324E0A98
	v_lshrrev_b32_e32 v5, 28, v5                               // 000000355794: 320A0A9C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000355798: BF870193
	v_and_or_b32 v37, 0xffff0000, v37, v48                     // 00000035579C: D6570025 04C24AFF FFFF0000
	v_and_or_b32 v38, v39, 15, v38                             // 0000003557A8: D6570026 04991F27
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000003557B0: BF8701A3
	v_and_or_b32 v5, v15, 48, v5                               // 0000003557B4: D6570005 0415610F
	v_lshlrev_b32_e32 v39, 2, v16                              // 0000003557BC: 304E2082
	v_cvt_f32_ubyte0_e32 v15, v38                              // 0000003557C0: 7E1E2326
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003557C4: BF870193
	v_cvt_f32_ubyte0_e32 v5, v5                                // 0000003557C8: 7E0A2305
	v_and_b32_e32 v39, 48, v39                                 // 0000003557CC: 364E4EB0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003557D0: BF870193
	v_fma_mix_f32 v15, v15, v47, v47 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003557D4: CC20600F 14BE5F0F
	v_fma_mix_f32 v5, v5, v47, v47 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003557DC: CC206005 14BE5F05
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003557E4: BF870092
	v_bfe_u32 v38, v15, 16, 1                                  // 0000003557E8: D6100026 0205210F
	v_add3_u32 v15, v15, v38, 0x7fff                           // 0000003557F0: D655000F 03FE4D0F 00007FFF
	v_lshrrev_b32_e32 v38, 4, v6                               // 0000003557FC: 324C0C84
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000355800: BF8701A2
	.long 0x7e60398f                                           // 000000355804: 7E60398F
	v_bfe_u32 v15, v5, 16, 1                                   // 000000355808: D610000F 02052105
	v_and_or_b32 v38, v38, 15, v39                             // 000000355810: D6570026 049D1F26
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000355818: BF870122
	v_add3_u32 v5, v5, v15, 0x7fff                             // 00000035581C: D6550005 03FE1F05 00007FFF
	v_lshlrev_b32_e32 v15, 4, v16                              // 000000355828: 301E2084
	v_and_or_b32 v5, 0xffff0000, v5, v48                       // 00000035582C: D6570005 04C20AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000355838: BF870092
	v_and_b32_e32 v15, 48, v15                                 // 00000035583C: 361E1EB0
	v_and_or_b32 v15, v6, 15, v15                              // 000000355840: D657000F 043D1F06
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000355848: BF870091
	v_cvt_f32_ubyte0_e32 v15, v15                              // 00000035584C: 7E1E230F
	v_fma_mix_f32 v15, v15, v47, v47 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000355850: CC20600F 14BE5F0F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000355858: BF870091
	v_bfe_u32 v39, v15, 16, 1                                  // 00000035585C: D6100027 0205210F
	v_add3_u32 v15, v15, v39, 0x7fff                           // 000000355864: D655000F 03FE4F0F 00007FFF
	v_and_b32_e32 v39, 48, v16                                 // 000000355870: 364E20B0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000355874: BF8700A2
	.long 0x7e60398f                                           // 000000355878: 7E60398F
	v_cvt_f32_ubyte0_e32 v15, v38                              // 00000035587C: 7E1E2326
	v_fma_mix_f32 v15, v15, v47, v47 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000355880: CC20600F 14BE5F0F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000355888: BF870091
	v_bfe_u32 v38, v15, 16, 1                                  // 00000035588C: D6100026 0205210F
	v_add3_u32 v15, v15, v38, 0x7fff                           // 000000355894: D655000F 03FE4D0F 00007FFF
	v_lshrrev_b32_e32 v38, 8, v6                               // 0000003558A0: 324C0C88
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003558A4: BF870112
	v_and_or_b32 v15, 0xffff0000, v15, v48                     // 0000003558A8: D657000F 04C21EFF FFFF0000
	v_and_or_b32 v38, v38, 15, v39                             // 0000003558B4: D6570026 049D1F26
	v_lshrrev_b32_e32 v39, 12, v6                              // 0000003558BC: 324E0C8C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003558C0: BF870112
	v_cvt_f32_ubyte0_e32 v38, v38                              // 0000003558C4: 7E4C2326
	v_and_or_b32 v39, v39, 15, v40                             // 0000003558C8: D6570027 04A11F27
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003558D0: BF870092
	v_fma_mix_f32 v38, v38, v47, v47 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003558D4: CC206026 14BE5F26
	v_bfe_u32 v40, v38, 16, 1                                  // 0000003558DC: D6100028 02052126
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000003558E4: BF870121
	v_add3_u32 v38, v38, v40, 0x7fff                           // 0000003558E8: D6550026 03FE5126 00007FFF
	v_lshrrev_b32_e32 v40, 8, v16                              // 0000003558F4: 32502088
	.long 0x7e6039a6                                           // 0000003558F8: 7E6039A6
	v_cvt_f32_ubyte0_e32 v38, v39                              // 0000003558FC: 7E4C2327
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000355900: BF870113
	v_and_b32_e32 v40, 48, v40                                 // 000000355904: 365050B0
	v_fma_mix_f32 v38, v38, v47, v47 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000355908: CC206026 14BE5F26
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000355910: BF870091
	v_bfe_u32 v39, v38, 16, 1                                  // 000000355914: D6100027 02052126
	v_add3_u32 v38, v38, v39, 0x7fff                           // 00000035591C: D6550026 03FE4F26 00007FFF
	v_lshrrev_b32_e32 v39, 4, v16                              // 000000355928: 324E2084
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000035592C: BF8701A2
	v_and_or_b32 v38, 0xffff0000, v38, v48                     // 000000355930: D6570026 04C24CFF FFFF0000
	.long 0x7e603986                                           // 00000035593C: 7E603986
	v_and_b32_e32 v39, 48, v39                                 // 000000355940: 364E4EB0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000355944: BF870091
	v_and_or_b32 v39, v48, 15, v39                             // 000000355948: D6570027 049D1F30
	v_cvt_f32_ubyte0_e32 v39, v39                              // 000000355950: 7E4E2327
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000355954: BF870091
	v_fma_mix_f32 v39, v39, v47, v47 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000355958: CC206027 14BE5F27
	v_bfe_u32 v42, v39, 16, 1                                  // 000000355960: D610002A 02052127
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000355968: BF870121
	v_add3_u32 v39, v39, v42, 0x7fff                           // 00000035596C: D6550027 03FE5527 00007FFF
	v_lshrrev_b32_e32 v42, 12, v16                             // 000000355978: 3254208C
	.long 0x7e6039a7                                           // 00000035597C: 7E6039A7
	v_cvt_f32_ubyte0_e32 v39, v41                              // 000000355980: 7E4E2329
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000355984: BF870091
	v_fma_mix_f32 v39, v39, v47, v47 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000355988: CC206027 14BE5F27
	v_bfe_u32 v41, v39, 16, 1                                  // 000000355990: D6100029 02052127
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000355998: BF8701B1
	v_add3_u32 v39, v39, v41, 0x7fff                           // 00000035599C: D6550027 03FE5327 00007FFF
	v_lshrrev_b32_e32 v41, 24, v6                              // 0000003559A8: 32520C98
	v_lshrrev_b32_e32 v6, 28, v6                               // 0000003559AC: 320C0C9C
	v_and_or_b32 v39, 0xffff0000, v39, v48                     // 0000003559B0: D6570027 04C24EFF FFFF0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000003559BC: BF870123
	v_and_or_b32 v40, v41, 15, v40                             // 0000003559C0: D6570028 04A11F29
	v_lshrrev_b32_e32 v41, 10, v16                             // 0000003559C8: 3252208A
	v_cvt_f32_ubyte0_e32 v40, v40                              // 0000003559CC: 7E502328
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003559D0: BF870112
	v_and_or_b32 v6, v41, 48, v6                               // 0000003559D4: D6570006 04196129
	v_fma_mix_f32 v40, v40, v47, v47 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003559DC: CC206028 14BE5F28
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003559E4: BF870112
	v_cvt_f32_ubyte0_e32 v6, v6                                // 0000003559E8: 7E0C2306
	v_bfe_u32 v41, v40, 16, 1                                  // 0000003559EC: D6100029 02052128
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003559F4: BF870112
	v_fma_mix_f32 v6, v6, v47, v47 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003559F8: CC206006 14BE5F06
	v_add3_u32 v40, v40, v41, 0x7fff                           // 000000355A00: D6550028 03FE5328 00007FFF
	v_lshrrev_b32_e32 v41, 4, v7                               // 000000355A0C: 32520E84
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000355A10: BF870212
	.long 0x7e6039a8                                           // 000000355A14: 7E6039A8
	v_bfe_u32 v40, v6, 16, 1                                   // 000000355A18: D6100028 02052106
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000355A20: BF870121
	v_add3_u32 v6, v6, v40, 0x7fff                             // 000000355A24: D6550006 03FE5106 00007FFF
	v_and_b32_e32 v40, 15, v7                                  // 000000355A30: 36500E8F
	v_and_or_b32 v6, 0xffff0000, v6, v48                       // 000000355A34: D6570006 04C20CFF FFFF0000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000355A40: BF8701B2
	v_and_or_b32 v40, v42, 48, v40                             // 000000355A44: D6570028 04A1612A
	v_lshrrev_b32_e32 v42, 14, v16                             // 000000355A4C: 3254208E
	.long 0x7e603990                                           // 000000355A50: 7E603990
	v_cvt_f32_ubyte0_e32 v40, v40                              // 000000355A54: 7E502328
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000355A58: BF870193
	v_and_b32_e32 v42, 48, v42                                 // 000000355A5C: 365454B0
	v_and_b32_e32 v49, 48, v48                                 // 000000355A60: 366260B0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000355A64: BF870193
	v_fma_mix_f32 v40, v40, v47, v47 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000355A68: CC206028 14BE5F28
	v_and_or_b32 v41, v41, 15, v42                             // 000000355A70: D6570029 04A91F29
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000355A78: BF870112
	v_bfe_u32 v42, v40, 16, 1                                  // 000000355A7C: D610002A 02052128
	v_cvt_f32_ubyte0_e32 v41, v41                              // 000000355A84: 7E522329
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000355A88: BF870112
	v_add3_u32 v40, v40, v42, 0x7fff                           // 000000355A8C: D6550028 03FE5528 00007FFF
	v_fma_mix_f32 v41, v41, v47, v47 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000355A98: CC206029 14BE5F29
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000355AA0: BF870112
	.long 0x7e5039a8                                           // 000000355AA4: 7E5039A8
	v_bfe_u32 v42, v41, 16, 1                                  // 000000355AA8: D610002A 02052129
	.long 0x7f5039b0                                           // 000000355AB0: 7F5039B0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000355AB4: BF870122
	v_add3_u32 v41, v41, v42, 0x7fff                           // 000000355AB8: D6550029 03FE5529 00007FFF
	v_lshrrev_b32_e32 v42, 20, v16                             // 000000355AC4: 32542094
	v_and_or_b32 v40, 0xffff0000, v41, v40                     // 000000355AC8: D6570028 04A252FF FFFF0000
	v_lshrrev_b32_e32 v41, 8, v7                               // 000000355AD4: 32520E88
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000355AD8: BF870113
	v_and_b32_e32 v42, 48, v42                                 // 000000355ADC: 365454B0
	v_and_or_b32 v41, v41, 15, v49                             // 000000355AE0: D6570029 04C51F29
	v_lshrrev_b32_e32 v49, 12, v7                              // 000000355AE8: 32620E8C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000355AEC: BF870112
	v_cvt_f32_ubyte0_e32 v41, v41                              // 000000355AF0: 7E522329
	v_and_or_b32 v49, v49, 15, v50                             // 000000355AF4: D6570031 04C91F31
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000355AFC: BF870092
	v_fma_mix_f32 v41, v41, v47, v47 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000355B00: CC206029 14BE5F29
	v_bfe_u32 v50, v41, 16, 1                                  // 000000355B08: D6100032 02052129
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000355B10: BF870121
	v_add3_u32 v41, v41, v50, 0x7fff                           // 000000355B14: D6550029 03FE6529 00007FFF
	v_lshrrev_b32_e32 v50, 20, v7                              // 000000355B20: 32640E94
	.long 0x7e6039a9                                           // 000000355B24: 7E6039A9
	v_cvt_f32_ubyte0_e32 v41, v49                              // 000000355B28: 7E522331
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000355B2C: BF870113
	v_and_or_b32 v50, v50, 15, v51                             // 000000355B30: D6570032 04CD1F32
	v_fma_mix_f32 v41, v41, v47, v47 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000355B38: CC206029 14BE5F29
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000355B40: BF870091
	v_bfe_u32 v49, v41, 16, 1                                  // 000000355B44: D6100031 02052129
	v_add3_u32 v41, v41, v49, 0x7fff                           // 000000355B4C: D6550029 03FE6329 00007FFF
	v_lshrrev_b32_e32 v49, 24, v16                             // 000000355B58: 32622098
	v_lshrrev_b32_e32 v16, 26, v16                             // 000000355B5C: 3220209A
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000355B60: BF870223
	v_and_or_b32 v41, 0xffff0000, v41, v48                     // 000000355B64: D6570029 04C252FF FFFF0000
	.long 0x7e603987                                           // 000000355B70: 7E603987
	v_and_b32_e32 v49, 48, v49                                 // 000000355B74: 366262B0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000355B78: BF870092
	v_and_or_b32 v42, v48, 15, v42                             // 000000355B7C: D657002A 04A91F30
	v_cvt_f32_ubyte0_e32 v42, v42                              // 000000355B84: 7E54232A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000355B88: BF870091
	v_fma_mix_f32 v42, v42, v47, v47 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000355B8C: CC20602A 14BE5F2A
	v_bfe_u32 v51, v42, 16, 1                                  // 000000355B94: D6100033 0205212A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000355B9C: BF870091
	v_add3_u32 v42, v42, v51, 0x7fff                           // 000000355BA0: D655002A 03FE672A 00007FFF
	.long 0x7e6039aa                                           // 000000355BAC: 7E6039AA
	v_cvt_f32_ubyte0_e32 v42, v50                              // 000000355BB0: 7E542332
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000355BB4: BF870091
	v_fma_mix_f32 v42, v42, v47, v47 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000355BB8: CC20602A 14BE5F2A
	v_bfe_u32 v50, v42, 16, 1                                  // 000000355BC0: D6100032 0205212A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000355BC8: BF8701B1
	v_add3_u32 v42, v42, v50, 0x7fff                           // 000000355BCC: D655002A 03FE652A 00007FFF
	v_lshrrev_b32_e32 v50, 24, v7                              // 000000355BD8: 32640E98
	v_lshrrev_b32_e32 v7, 28, v7                               // 000000355BDC: 320E0E9C
	v_and_or_b32 v42, 0xffff0000, v42, v48                     // 000000355BE0: D657002A 04C254FF FFFF0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000355BEC: BF870193
	v_and_or_b32 v49, v50, 15, v49                             // 000000355BF0: D6570031 04C51F32
	v_and_or_b32 v7, v16, 48, v7                               // 000000355BF8: D6570007 041D6110
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000355C00: BF870112
	v_cvt_f32_ubyte0_e32 v16, v49                              // 000000355C04: 7E202331
	v_cvt_f32_ubyte0_e32 v7, v7                                // 000000355C08: 7E0E2307
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000355C0C: BF870112
	v_fma_mix_f32 v16, v16, v47, v47 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000355C10: CC206010 14BE5F10
	v_fma_mix_f32 v7, v7, v47, v47 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000355C18: CC206007 14BE5F07
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000355C20: BF870092
	v_bfe_u32 v49, v16, 16, 1                                  // 000000355C24: D6100031 02052110
	v_add3_u32 v16, v16, v49, 0x7fff                           // 000000355C2C: D6550010 03FE6310 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000355C38: BF870211
	.long 0x7e603990                                           // 000000355C3C: 7E603990
	v_bfe_u32 v16, v7, 16, 1                                   // 000000355C40: D6100010 02052107
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000355C48: BF870091
	v_add3_u32 v7, v7, v16, 0x7fff                             // 000000355C4C: D6550007 03FE2107 00007FFF
	v_and_or_b32 v7, 0xffff0000, v7, v48                       // 000000355C58: D6570007 04C20EFF FFFF0000
	.long 0xd73c002f                                           // 000000355C64: D73C002F
	v_cndmask_b32_e32 v1, 1, v11, vcc_lo                       // 000000355C68: 02021681
	v_add_nc_u32_e32 v11, 0x400, v11                           // 000000355C6C: 4A1616FF 00000400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000355C74: BF870092
	.long 0xd700003f                                           // 000000355C78: D700003F
	v_cndmask_b32_e32 v1, s6, v47, vcc_lo                      // 000000355C7C: 02025E06
	v_add_co_ci_u32_e64 v64, null, s7, v48, s0                 // 000000355C80: D5207C40 00026007
	s_clause 0x3                                               // 000000355C88: BF850003
	global_load_b128 v[47:50], v[63:64], off                   // 000000355C8C: DC5E0000 2F7C003F
	global_load_b128 v[51:54], v[63:64], off offset:16         // 000000355C94: DC5E0010 337C003F
	global_load_b128 v[55:58], v[63:64], off offset:32         // 000000355C9C: DC5E0020 377C003F
	global_load_b128 v[59:62], v[63:64], off offset:48         // 000000355CA4: DC5E0030 3B7C003F
	s_waitcnt vmcnt(3)                                         // 000000355CAC: BF890FF7
	v_dot2_f32_bf16 v16, v47, v43, 0                           // 000000355CB0: CC1A4010 1A02572F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000355CB8: BF870091
	v_dot2_f32_bf16 v16, v48, v44, v16                         // 000000355CBC: CC1A4010 1C425930
	v_dot2_f32_bf16 v16, v49, v45, v16                         // 000000355CC4: CC1A4010 1C425B31
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000355CCC: BF8700A1
	v_dot2_f32_bf16 v16, v50, v46, v16                         // 000000355CD0: CC1A4010 1C425D32
	s_waitcnt vmcnt(2)                                         // 000000355CD8: BF890BF7
	v_dot2_f32_bf16 v16, v51, v4, v16                          // 000000355CDC: CC1A4010 1C420933
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000355CE4: BF870091
	v_dot2_f32_bf16 v16, v52, v36, v16                         // 000000355CE8: CC1A4010 1C424934
	v_dot2_f32_bf16 v16, v53, v37, v16                         // 000000355CF0: CC1A4010 1C424B35
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000355CF8: BF8700A1
	v_dot2_f32_bf16 v16, v54, v5, v16                          // 000000355CFC: CC1A4010 1C420B36
	s_waitcnt vmcnt(1)                                         // 000000355D04: BF8907F7
	v_dot2_f32_bf16 v16, v55, v15, v16                         // 000000355D08: CC1A4010 1C421F37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000355D10: BF870091
	v_dot2_f32_bf16 v16, v56, v38, v16                         // 000000355D14: CC1A4010 1C424D38
	v_dot2_f32_bf16 v16, v57, v39, v16                         // 000000355D1C: CC1A4010 1C424F39
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000355D24: BF8700A1
	v_dot2_f32_bf16 v16, v58, v6, v16                          // 000000355D28: CC1A4010 1C420D3A
	s_waitcnt vmcnt(0)                                         // 000000355D30: BF8903F7
	v_dot2_f32_bf16 v16, v59, v40, v16                         // 000000355D34: CC1A4010 1C42513B
	.long 0xd700003b                                           // 000000355D3C: D700003B
	v_cndmask_b32_e32 v0, v63, v10, vcc_lo                     // 000000355D40: 0200153F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000355D44: BF8701B2
	v_dot2_f32_bf16 v16, v60, v41, v16                         // 000000355D48: CC1A4010 1C42533C
	v_add_co_ci_u32_e64 v60, null, s11, v64, s0                // 000000355D50: D5207C3C 0002800B
	.long 0xd7000041                                           // 000000355D58: D7000041
	v_cndmask_b32_e32 v0, v63, v4, vcc_lo                      // 000000355D5C: 0200093F
	v_dot2_f32_bf16 v16, v61, v42, v16                         // 000000355D60: CC1A4010 1C42553D
	v_add_co_ci_u32_e64 v66, null, s5, v64, s0                 // 000000355D68: D5207C42 00028005
	.long 0xd700003f                                           // 000000355D70: D700003F
	v_cndmask_b32_e32 v0, v63, v16, vcc_lo                     // 000000355D74: 0200213F
	s_delay_alu instid0(VALU_DEP_3)                            // 000000355D78: BF870003
	v_dot2_f32_bf16 v16, v62, v7, v16                          // 000000355D7C: CC1A4010 1C420F3E
	s_clause 0x3                                               // 000000355D84: BF850003
	global_load_b128 v[47:50], v[59:60], off                   // 000000355D88: DC5E0000 2F7C003B
	global_load_b128 v[51:54], v[59:60], off offset:16         // 000000355D90: DC5E0010 337C003B
	global_load_b128 v[55:58], v[59:60], off offset:32         // 000000355D98: DC5E0020 377C003B
	global_load_b128 v[59:62], v[59:60], off offset:48         // 000000355DA0: DC5E0030 3B7C003B
	v_add_co_ci_u32_e64 v64, null, s14, v64, s0                // 000000355DA8: D5207C40 0002800E
	v_add_f32_e32 v26, v26, v16                                // 000000355DB0: 0634211A
	s_waitcnt vmcnt(3)                                         // 000000355DB4: BF890FF7
	v_dot2_f32_bf16 v16, v47, v43, 0                           // 000000355DB8: CC1A4010 1A02572F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000355DC0: BF870091
	v_dot2_f32_bf16 v16, v48, v44, v16                         // 000000355DC4: CC1A4010 1C425930
	v_dot2_f32_bf16 v16, v49, v45, v16                         // 000000355DCC: CC1A4010 1C425B31
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000355DD4: BF8700A1
	v_dot2_f32_bf16 v16, v50, v46, v16                         // 000000355DD8: CC1A4010 1C425D32
	s_waitcnt vmcnt(2)                                         // 000000355DE0: BF890BF7
	v_dot2_f32_bf16 v16, v51, v4, v16                          // 000000355DE4: CC1A4010 1C420933
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000355DEC: BF870091
	v_dot2_f32_bf16 v16, v52, v36, v16                         // 000000355DF0: CC1A4010 1C424934
	v_dot2_f32_bf16 v16, v53, v37, v16                         // 000000355DF8: CC1A4010 1C424B35
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000355E00: BF8700A1
	v_dot2_f32_bf16 v16, v54, v5, v16                          // 000000355E04: CC1A4010 1C420B36
	s_waitcnt vmcnt(1)                                         // 000000355E0C: BF8907F7
	v_dot2_f32_bf16 v16, v55, v15, v16                         // 000000355E10: CC1A4010 1C421F37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000355E18: BF870091
	v_dot2_f32_bf16 v16, v56, v38, v16                         // 000000355E1C: CC1A4010 1C424D38
	v_dot2_f32_bf16 v16, v57, v39, v16                         // 000000355E24: CC1A4010 1C424F39
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000355E2C: BF8700A1
	v_dot2_f32_bf16 v16, v58, v6, v16                          // 000000355E30: CC1A4010 1C420D3A
	s_waitcnt vmcnt(0)                                         // 000000355E38: BF8903F7
	v_dot2_f32_bf16 v16, v59, v40, v16                         // 000000355E3C: CC1A4010 1C42513B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000355E44: BF870091
	v_dot2_f32_bf16 v16, v60, v41, v16                         // 000000355E48: CC1A4010 1C42533C
	v_dot2_f32_bf16 v16, v61, v42, v16                         // 000000355E50: CC1A4010 1C42553D
	s_delay_alu instid0(VALU_DEP_1)                            // 000000355E58: BF870001
	v_dot2_f32_bf16 v16, v62, v7, v16                          // 000000355E5C: CC1A4010 1C420F3E
	s_clause 0x3                                               // 000000355E64: BF850003
	global_load_b128 v[47:50], v[65:66], off                   // 000000355E68: DC5E0000 2F7C0041
	global_load_b128 v[51:54], v[65:66], off offset:16         // 000000355E70: DC5E0010 337C0041
	global_load_b128 v[55:58], v[65:66], off offset:32         // 000000355E78: DC5E0020 377C0041
	global_load_b128 v[59:62], v[65:66], off offset:48         // 000000355E80: DC5E0030 3B7C0041
	.long 0xd7000041                                           // 000000355E88: D7000041
	v_cndmask_b32_e32 v0, v65, v4, vcc_lo                      // 000000355E8C: 02000941
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000355E90: BF8700C1
	v_add_co_ci_u32_e64 v66, null, s5, v66, s0                 // 000000355E94: D5207C42 00028405
	v_add_f32_e32 v25, v25, v16                                // 000000355E9C: 06322119
	s_waitcnt vmcnt(3)                                         // 000000355EA0: BF890FF7
	v_dot2_f32_bf16 v16, v47, v43, 0                           // 000000355EA4: CC1A4010 1A02572F
	v_dot2_f32_bf16 v16, v48, v44, v16                         // 000000355EAC: CC1A4010 1C425930
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000355EB4: BF870091
	v_dot2_f32_bf16 v16, v49, v45, v16                         // 000000355EB8: CC1A4010 1C425B31
	v_dot2_f32_bf16 v16, v50, v46, v16                         // 000000355EC0: CC1A4010 1C425D32
	s_waitcnt vmcnt(2)                                         // 000000355EC8: BF890BF7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000355ECC: BF870091
	v_dot2_f32_bf16 v16, v51, v4, v16                          // 000000355ED0: CC1A4010 1C420933
	v_dot2_f32_bf16 v16, v52, v36, v16                         // 000000355ED8: CC1A4010 1C424934
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000355EE0: BF870091
	v_dot2_f32_bf16 v16, v53, v37, v16                         // 000000355EE4: CC1A4010 1C424B35
	v_dot2_f32_bf16 v16, v54, v5, v16                          // 000000355EEC: CC1A4010 1C420B36
	s_waitcnt vmcnt(1)                                         // 000000355EF4: BF8907F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000355EF8: BF870091
	v_dot2_f32_bf16 v16, v55, v15, v16                         // 000000355EFC: CC1A4010 1C421F37
	v_dot2_f32_bf16 v16, v56, v38, v16                         // 000000355F04: CC1A4010 1C424D38
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000355F0C: BF870091
	v_dot2_f32_bf16 v16, v57, v39, v16                         // 000000355F10: CC1A4010 1C424F39
	v_dot2_f32_bf16 v16, v58, v6, v16                          // 000000355F18: CC1A4010 1C420D3A
	s_waitcnt vmcnt(0)                                         // 000000355F20: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000355F24: BF870091
	v_dot2_f32_bf16 v16, v59, v40, v16                         // 000000355F28: CC1A4010 1C42513B
	v_dot2_f32_bf16 v16, v60, v41, v16                         // 000000355F30: CC1A4010 1C42533C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000355F38: BF870091
	v_dot2_f32_bf16 v16, v61, v42, v16                         // 000000355F3C: CC1A4010 1C42553D
	v_dot2_f32_bf16 v16, v62, v7, v16                          // 000000355F44: CC1A4010 1C420F3E
	s_clause 0x3                                               // 000000355F4C: BF850003
	global_load_b128 v[47:50], v[63:64], off                   // 000000355F50: DC5E0000 2F7C003F
	global_load_b128 v[51:54], v[63:64], off offset:16         // 000000355F58: DC5E0010 337C003F
	global_load_b128 v[55:58], v[63:64], off offset:32         // 000000355F60: DC5E0020 377C003F
	global_load_b128 v[59:62], v[63:64], off offset:48         // 000000355F68: DC5E0030 3B7C003F
	.long 0xd700003f                                           // 000000355F70: D700003F
	v_cndmask_b32_e32 v0, v63, v4, vcc_lo                      // 000000355F74: 0200093F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000355F78: BF8700C1
	v_add_co_ci_u32_e64 v64, null, s5, v64, s0                 // 000000355F7C: D5207C40 00028005
	v_add_f32_e32 v24, v24, v16                                // 000000355F84: 06302118
	s_waitcnt vmcnt(3)                                         // 000000355F88: BF890FF7
	v_dot2_f32_bf16 v16, v47, v43, 0                           // 000000355F8C: CC1A4010 1A02572F
	v_dot2_f32_bf16 v16, v48, v44, v16                         // 000000355F94: CC1A4010 1C425930
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000355F9C: BF870091
	v_dot2_f32_bf16 v16, v49, v45, v16                         // 000000355FA0: CC1A4010 1C425B31
	v_dot2_f32_bf16 v16, v50, v46, v16                         // 000000355FA8: CC1A4010 1C425D32
	s_waitcnt vmcnt(2)                                         // 000000355FB0: BF890BF7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000355FB4: BF870091
	v_dot2_f32_bf16 v16, v51, v4, v16                          // 000000355FB8: CC1A4010 1C420933
	v_dot2_f32_bf16 v16, v52, v36, v16                         // 000000355FC0: CC1A4010 1C424934
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000355FC8: BF870091
	v_dot2_f32_bf16 v16, v53, v37, v16                         // 000000355FCC: CC1A4010 1C424B35
	v_dot2_f32_bf16 v16, v54, v5, v16                          // 000000355FD4: CC1A4010 1C420B36
	s_waitcnt vmcnt(1)                                         // 000000355FDC: BF8907F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000355FE0: BF870091
	v_dot2_f32_bf16 v16, v55, v15, v16                         // 000000355FE4: CC1A4010 1C421F37
	v_dot2_f32_bf16 v16, v56, v38, v16                         // 000000355FEC: CC1A4010 1C424D38
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000355FF4: BF870091
	v_dot2_f32_bf16 v16, v57, v39, v16                         // 000000355FF8: CC1A4010 1C424F39
	v_dot2_f32_bf16 v16, v58, v6, v16                          // 000000356000: CC1A4010 1C420D3A
	s_waitcnt vmcnt(0)                                         // 000000356008: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000035600C: BF870091
	v_dot2_f32_bf16 v16, v59, v40, v16                         // 000000356010: CC1A4010 1C42513B
	v_dot2_f32_bf16 v16, v60, v41, v16                         // 000000356018: CC1A4010 1C42533C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000356020: BF870091
	v_dot2_f32_bf16 v16, v61, v42, v16                         // 000000356024: CC1A4010 1C42553D
	v_dot2_f32_bf16 v16, v62, v7, v16                          // 00000035602C: CC1A4010 1C420F3E
	s_clause 0x3                                               // 000000356034: BF850003
	global_load_b128 v[47:50], v[65:66], off                   // 000000356038: DC5E0000 2F7C0041
	global_load_b128 v[51:54], v[65:66], off offset:16         // 000000356040: DC5E0010 337C0041
	global_load_b128 v[55:58], v[65:66], off offset:32         // 000000356048: DC5E0020 377C0041
	global_load_b128 v[59:62], v[65:66], off offset:48         // 000000356050: DC5E0030 3B7C0041
	v_add_f32_e32 v23, v23, v16                                // 000000356058: 062E2117
	s_waitcnt vmcnt(3)                                         // 00000035605C: BF890FF7
	v_dot2_f32_bf16 v16, v47, v43, 0                           // 000000356060: CC1A4010 1A02572F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000356068: BF870091
	v_dot2_f32_bf16 v16, v48, v44, v16                         // 00000035606C: CC1A4010 1C425930
	v_dot2_f32_bf16 v16, v49, v45, v16                         // 000000356074: CC1A4010 1C425B31
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000035607C: BF8700A1
	v_dot2_f32_bf16 v16, v50, v46, v16                         // 000000356080: CC1A4010 1C425D32
	s_waitcnt vmcnt(2)                                         // 000000356088: BF890BF7
	v_dot2_f32_bf16 v16, v51, v4, v16                          // 00000035608C: CC1A4010 1C420933
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000356094: BF870091
	v_dot2_f32_bf16 v16, v52, v36, v16                         // 000000356098: CC1A4010 1C424934
	v_dot2_f32_bf16 v16, v53, v37, v16                         // 0000003560A0: CC1A4010 1C424B35
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003560A8: BF8700A1
	v_dot2_f32_bf16 v16, v54, v5, v16                          // 0000003560AC: CC1A4010 1C420B36
	s_waitcnt vmcnt(1)                                         // 0000003560B4: BF8907F7
	v_dot2_f32_bf16 v16, v55, v15, v16                         // 0000003560B8: CC1A4010 1C421F37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003560C0: BF870091
	v_dot2_f32_bf16 v16, v56, v38, v16                         // 0000003560C4: CC1A4010 1C424D38
	v_dot2_f32_bf16 v16, v57, v39, v16                         // 0000003560CC: CC1A4010 1C424F39
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003560D4: BF8700A1
	v_dot2_f32_bf16 v16, v58, v6, v16                          // 0000003560D8: CC1A4010 1C420D3A
	s_waitcnt vmcnt(0)                                         // 0000003560E0: BF8903F7
	v_dot2_f32_bf16 v16, v59, v40, v16                         // 0000003560E4: CC1A4010 1C42513B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003560EC: BF870091
	v_dot2_f32_bf16 v16, v60, v41, v16                         // 0000003560F0: CC1A4010 1C42533C
	v_dot2_f32_bf16 v16, v61, v42, v16                         // 0000003560F8: CC1A4010 1C42553D
	s_delay_alu instid0(VALU_DEP_1)                            // 000000356100: BF870001
	v_dot2_f32_bf16 v16, v62, v7, v16                          // 000000356104: CC1A4010 1C420F3E
	s_clause 0x3                                               // 00000035610C: BF850003
	global_load_b128 v[47:50], v[63:64], off                   // 000000356110: DC5E0000 2F7C003F
	global_load_b128 v[51:54], v[63:64], off offset:16         // 000000356118: DC5E0010 337C003F
	global_load_b128 v[55:58], v[63:64], off offset:32         // 000000356120: DC5E0020 377C003F
	global_load_b128 v[59:62], v[63:64], off offset:48         // 000000356128: DC5E0030 3B7C003F
	v_add_f32_e32 v22, v22, v16                                // 000000356130: 062C2116
	s_waitcnt vmcnt(3)                                         // 000000356134: BF890FF7
	v_dot2_f32_bf16 v16, v47, v43, 0                           // 000000356138: CC1A4010 1A02572F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000356140: BF870091
	v_dot2_f32_bf16 v16, v48, v44, v16                         // 000000356144: CC1A4010 1C425930
	v_dot2_f32_bf16 v16, v49, v45, v16                         // 00000035614C: CC1A4010 1C425B31
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000356154: BF8700A1
	v_dot2_f32_bf16 v16, v50, v46, v16                         // 000000356158: CC1A4010 1C425D32
	s_waitcnt vmcnt(2)                                         // 000000356160: BF890BF7
	v_dot2_f32_bf16 v16, v51, v4, v16                          // 000000356164: CC1A4010 1C420933
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000035616C: BF870091
	v_dot2_f32_bf16 v16, v52, v36, v16                         // 000000356170: CC1A4010 1C424934
	v_dot2_f32_bf16 v16, v53, v37, v16                         // 000000356178: CC1A4010 1C424B35
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000356180: BF8700A1
	v_dot2_f32_bf16 v16, v54, v5, v16                          // 000000356184: CC1A4010 1C420B36
	s_waitcnt vmcnt(1)                                         // 00000035618C: BF8907F7
	v_dot2_f32_bf16 v16, v55, v15, v16                         // 000000356190: CC1A4010 1C421F37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000356198: BF870091
	v_dot2_f32_bf16 v16, v56, v38, v16                         // 00000035619C: CC1A4010 1C424D38
	v_dot2_f32_bf16 v16, v57, v39, v16                         // 0000003561A4: CC1A4010 1C424F39
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003561AC: BF8700A1
	v_dot2_f32_bf16 v16, v58, v6, v16                          // 0000003561B0: CC1A4010 1C420D3A
	s_waitcnt vmcnt(0)                                         // 0000003561B8: BF8903F7
	v_dot2_f32_bf16 v16, v59, v40, v16                         // 0000003561BC: CC1A4010 1C42513B
	.long 0xd700003b                                           // 0000003561C4: D700003B
	v_cndmask_b32_e32 v0, v65, v4, vcc_lo                      // 0000003561C8: 02000941
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000003561CC: BF870122
	v_dot2_f32_bf16 v16, v60, v41, v16                         // 0000003561D0: CC1A4010 1C42533C
	v_add_co_ci_u32_e64 v60, null, s5, v66, s0                 // 0000003561D8: D5207C3C 00028405
	v_dot2_f32_bf16 v16, v61, v42, v16                         // 0000003561E0: CC1A4010 1C42553D
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003561E8: BF870001
	v_dot2_f32_bf16 v16, v62, v7, v16                          // 0000003561EC: CC1A4010 1C420F3E
	s_clause 0x3                                               // 0000003561F4: BF850003
	global_load_b128 v[47:50], v[59:60], off                   // 0000003561F8: DC5E0000 2F7C003B
	global_load_b128 v[51:54], v[59:60], off offset:16         // 000000356200: DC5E0010 337C003B
	global_load_b128 v[55:58], v[59:60], off offset:32         // 000000356208: DC5E0020 377C003B
	global_load_b128 v[59:62], v[59:60], off offset:48         // 000000356210: DC5E0030 3B7C003B
	v_add_f32_e32 v21, v21, v16                                // 000000356218: 062A2115
	s_waitcnt vmcnt(3)                                         // 00000035621C: BF890FF7
	v_dot2_f32_bf16 v16, v47, v43, 0                           // 000000356220: CC1A4010 1A02572F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000356228: BF870091
	v_dot2_f32_bf16 v16, v48, v44, v16                         // 00000035622C: CC1A4010 1C425930
	v_dot2_f32_bf16 v16, v49, v45, v16                         // 000000356234: CC1A4010 1C425B31
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000035623C: BF8700A1
	v_dot2_f32_bf16 v16, v50, v46, v16                         // 000000356240: CC1A4010 1C425D32
	s_waitcnt vmcnt(2)                                         // 000000356248: BF890BF7
	v_dot2_f32_bf16 v16, v51, v4, v16                          // 00000035624C: CC1A4010 1C420933
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000356254: BF870091
	v_dot2_f32_bf16 v16, v52, v36, v16                         // 000000356258: CC1A4010 1C424934
	v_dot2_f32_bf16 v16, v53, v37, v16                         // 000000356260: CC1A4010 1C424B35
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000356268: BF8700A1
	v_dot2_f32_bf16 v16, v54, v5, v16                          // 00000035626C: CC1A4010 1C420B36
	s_waitcnt vmcnt(1)                                         // 000000356274: BF8907F7
	v_dot2_f32_bf16 v16, v55, v15, v16                         // 000000356278: CC1A4010 1C421F37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000356280: BF870091
	v_dot2_f32_bf16 v16, v56, v38, v16                         // 000000356284: CC1A4010 1C424D38
	v_dot2_f32_bf16 v16, v57, v39, v16                         // 00000035628C: CC1A4010 1C424F39
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000356294: BF8700A1
	v_dot2_f32_bf16 v16, v58, v6, v16                          // 000000356298: CC1A4010 1C420D3A
	s_waitcnt vmcnt(0)                                         // 0000003562A0: BF8903F7
	v_dot2_f32_bf16 v16, v59, v40, v16                         // 0000003562A4: CC1A4010 1C42513B
	.long 0xd700003b                                           // 0000003562AC: D700003B
	v_cndmask_b32_e32 v0, v63, v4, vcc_lo                      // 0000003562B0: 0200093F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000003562B4: BF870122
	v_dot2_f32_bf16 v16, v60, v41, v16                         // 0000003562B8: CC1A4010 1C42533C
	v_add_co_ci_u32_e64 v60, null, s5, v64, s0                 // 0000003562C0: D5207C3C 00028005
	v_dot2_f32_bf16 v16, v61, v42, v16                         // 0000003562C8: CC1A4010 1C42553D
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003562D0: BF870001
	v_dot2_f32_bf16 v16, v62, v7, v16                          // 0000003562D4: CC1A4010 1C420F3E
	s_clause 0x3                                               // 0000003562DC: BF850003
	global_load_b128 v[47:50], v[59:60], off                   // 0000003562E0: DC5E0000 2F7C003B
	global_load_b128 v[51:54], v[59:60], off offset:16         // 0000003562E8: DC5E0010 337C003B
	global_load_b128 v[55:58], v[59:60], off offset:32         // 0000003562F0: DC5E0020 377C003B
	global_load_b128 v[59:62], v[59:60], off offset:48         // 0000003562F8: DC5E0030 3B7C003B
	v_add_f32_e32 v19, v19, v16                                // 000000356300: 06262113
	s_waitcnt vmcnt(3)                                         // 000000356304: BF890FF7
	v_dot2_f32_bf16 v16, v47, v43, 0                           // 000000356308: CC1A4010 1A02572F
	v_mov_b32_e32 v47, v35                                     // 000000356310: 7E5E0323
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000356314: BF870092
	v_dot2_f32_bf16 v16, v48, v44, v16                         // 000000356318: CC1A4010 1C425930
	v_dot2_f32_bf16 v16, v49, v45, v16                         // 000000356320: CC1A4010 1C425B31
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000356328: BF8700A1
	v_dot2_f32_bf16 v16, v50, v46, v16                         // 00000035632C: CC1A4010 1C425D32
	s_waitcnt vmcnt(2)                                         // 000000356334: BF890BF7
	v_dot2_f32_bf16 v4, v51, v4, v16                           // 000000356338: CC1A4004 1C420933
	v_mov_b32_e32 v16, v14                                     // 000000356340: 7E20030E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000356344: BF870092
	v_dot2_f32_bf16 v4, v52, v36, v4                           // 000000356348: CC1A4004 1C124934
	v_dot2_f32_bf16 v4, v53, v37, v4                           // 000000356350: CC1A4004 1C124B35
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000356358: BF870131
	v_dot2_f32_bf16 v4, v54, v5, v4                            // 00000035635C: CC1A4004 1C120B36
	v_mov_b32_e32 v5, v1                                       // 000000356364: 7E0A0301
	s_waitcnt vmcnt(1)                                         // 000000356368: BF8907F7
	v_dot2_f32_bf16 v4, v55, v15, v4                           // 00000035636C: CC1A4004 1C121F37
	v_mov_b32_e32 v15, v13                                     // 000000356374: 7E1E030D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000356378: BF870092
	v_dot2_f32_bf16 v4, v56, v38, v4                           // 00000035637C: CC1A4004 1C124D38
	v_dot2_f32_bf16 v4, v57, v39, v4                           // 000000356384: CC1A4004 1C124F39
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000035638C: BF870131
	v_dot2_f32_bf16 v4, v58, v6, v4                            // 000000356390: CC1A4004 1C120D3A
	v_mov_b32_e32 v6, v2                                       // 000000356398: 7E0C0302
	s_waitcnt vmcnt(0)                                         // 00000035639C: BF8903F7
	v_dot2_f32_bf16 v4, v59, v40, v4                           // 0000003563A0: CC1A4004 1C12513B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003563A8: BF870091
	v_dot2_f32_bf16 v4, v60, v41, v4                           // 0000003563AC: CC1A4004 1C12533C
	v_dot2_f32_bf16 v4, v61, v42, v4                           // 0000003563B4: CC1A4004 1C12553D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003563BC: BF870091
	v_dot2_f32_bf16 v4, v62, v7, v4                            // 0000003563C0: CC1A4004 1C120F3E
	v_dual_mov_b32 v7, v3 :: v_dual_add_f32 v18, v18, v4       // 0000003563C8: CA080103 07120912
	v_mov_b32_e32 v4, v0                                       // 0000003563D0: 7E080300
	s_and_not1_b32 exec_lo, exec_lo, s15                       // 0000003563D4: 917E0F7E
	s_cbranch_execz 38                                         // 0000003563D8: BFA50026 <_ZN7halogen12_GLOBAL__N_16k_lq6wILi8ELi32ELi1EEEvPKhPKtPtll+0x1374>
	v_dual_mov_b32 v1, v5 :: v_dual_add_nc_u32 v34, 32, v34    // 0000003563DC: CA200105 012244A0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000003563E4: BF8701A2
	v_dual_mov_b32 v0, v4 :: v_dual_mov_b32 v3, v7             // 0000003563E8: CA100104 00020107
	v_dual_mov_b32 v2, v6 :: v_dual_mov_b32 v13, v15           // 0000003563F0: CA100106 020C010F
	.long 0xd4430000                                           // 0000003563F8: D4430000
	v_cndmask_b32_e32 v1, s12, v34, vcc_lo                     // 0000003563FC: 0202440C
	v_mov_b32_e32 v14, v16                                     // 000000356400: 7E1C0310
	s_mov_b32 s17, exec_lo                                     // 000000356404: BE91007E
	.long 0xd4c4007e                                           // 000000356408: D4C4007E
	v_cndmask_b32_e32 v1, s12, v34, vcc_lo                     // 00000035640C: 0202440C
	s_cbranch_execz 64467                                      // 000000356410: BFA5FBD3 <_ZN7halogen12_GLOBAL__N_16k_lq6wILi8ELi32ELi1EEEvPKhPKtPtll+0x260>
	v_and_b32_e32 v2, 0x7ffffffc, v33                          // 000000356414: 360442FF 7FFFFFFC
	.long 0xd7000100                                           // 00000035641C: D7000100
	v_cndmask_b32_e32 v1, v10, v31, vcc_lo                     // 000000356420: 02023F0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000356424: BF8700A1
	v_add_co_ci_u32_e64 v1, null, 0, v20, s1                   // 000000356428: D5207C01 00062880
	.long 0xd700010d                                           // 000000356430: D700010D
	v_cndmask_b32_e32 v1, v27, v32, vcc_lo                     // 000000356434: 0202411B
	v_add_co_ci_u32_e64 v14, null, 0, v28, s1                  // 000000356438: D5207C0E 00063880
	.long 0xd7000123                                           // 000000356440: D7000123
	v_cndmask_b32_e32 v1, v29, v2, vcc_lo                      // 000000356444: 0202051D
	s_delay_alu instid0(VALU_DEP_1)                            // 000000356448: BF870001
	v_add_co_ci_u32_e64 v36, null, 0, v30, s1                  // 00000035644C: D5207C24 00063C80
	s_clause 0x2                                               // 000000356454: BF850002
	global_load_b128 v[0:3], v[0:1], off                       // 000000356458: DC5E0000 007C0000
	global_load_b64 v[13:14], v[13:14], off                    // 000000356460: DC560000 0D7C000D
	global_load_b32 v35, v[35:36], off                         // 000000356468: DC520000 237C0023
	s_branch 64443                                             // 000000356470: BFA0FBBB <_ZN7halogen12_GLOBAL__N_16k_lq6wILi8ELi32ELi1EEEvPKhPKtPtll+0x260>
	s_or_b32 exec_lo, exec_lo, s15                             // 000000356474: 8C7E0F7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000356478: BF8700A9
	s_or_b32 exec_lo, exec_lo, s13                             // 00000035647C: 8C7E0D7E
	.long 0xd71f0000                                           // 000000356480: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 000000356484: 020100C1
	v_xor_b32_e32 v1, 16, v0                                   // 000000356488: 3A020090
	v_xor_b32_e32 v11, 8, v0                                   // 00000035648C: 3A160088
	v_xor_b32_e32 v20, 4, v0                                   // 000000356490: 3A280084
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000356494: BF870093
	.long 0xd44c0000                                           // 000000356498: D44C0000
	v_cndmask_b32_e32 v1, 32, v1, vcc_lo                       // 00000035649C: 020202A0
	v_cndmask_b32_e64 v1, v0, v1, s0                           // 0000003564A0: D5010001 00020300
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003564A8: BF870114
	.long 0xd44c0000                                           // 0000003564AC: D44C0000
	v_cndmask_b32_e32 v1, 32, v11, vcc_lo                      // 0000003564B0: 020216A0
	v_lshlrev_b32_e32 v1, 2, v1                                // 0000003564B4: 30020282
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000003564B8: BF8700C2
	v_cndmask_b32_e64 v11, v0, v11, s0                         // 0000003564BC: D501000B 00021700
	.long 0xd44c0000                                           // 0000003564C4: D44C0000
	v_cndmask_b32_e32 v1, 32, v20, vcc_lo                      // 0000003564C8: 020228A0
	ds_bpermute_b32 v2, v1, v25                                // 0000003564CC: DACC0000 02001901
	v_cndmask_b32_e64 v20, v0, v20, s0                         // 0000003564D4: D5010014 00022900
	v_lshlrev_b32_e32 v20, 2, v20                              // 0000003564DC: 30282882
	s_waitcnt lgkmcnt(0)                                       // 0000003564E0: BF89FC07
	v_add_f32_e32 v2, v25, v2                                  // 0000003564E4: 06040519
	s_waitcnt vmcnt(2)                                         // 0000003564E8: BF890BF7
	ds_bpermute_b32 v4, v1, v23                                // 0000003564EC: DACC0000 04001701
	ds_bpermute_b32 v3, v1, v26                                // 0000003564F4: DACC0000 03001A01
	ds_bpermute_b32 v5, v1, v24                                // 0000003564FC: DACC0000 05001801
	ds_bpermute_b32 v6, v1, v21                                // 000000356504: DACC0000 06001501
	ds_bpermute_b32 v7, v1, v22                                // 00000035650C: DACC0000 07001601
	ds_bpermute_b32 v10, v1, v18                               // 000000356514: DACC0000 0A001201
	ds_bpermute_b32 v1, v1, v19                                // 00000035651C: DACC0000 01001301
	s_waitcnt lgkmcnt(6)                                       // 000000356524: BF89FC67
	v_dual_add_f32 v4, v23, v4 :: v_dual_lshlrev_b32 v11, 2, v11// 000000356528: C9220917 040A1682
	ds_bpermute_b32 v12, v11, v2                               // 000000356530: DACC0000 0C00020B
	s_waitcnt lgkmcnt(4)                                       // 000000356538: BF89FC47
	v_dual_add_f32 v3, v26, v3 :: v_dual_add_f32 v6, v21, v6   // 00000035653C: C908071A 03060D15
	s_waitcnt lgkmcnt(2)                                       // 000000356544: BF89FC27
	v_dual_add_f32 v5, v24, v5 :: v_dual_add_f32 v10, v18, v10 // 000000356548: C9080B18 050A1512
	v_add_f32_e32 v7, v22, v7                                  // 000000356550: 060E0F16
	s_waitcnt lgkmcnt(1)                                       // 000000356554: BF89FC17
	v_add_f32_e32 v1, v19, v1                                  // 000000356558: 06020313
	ds_bpermute_b32 v13, v11, v3                               // 00000035655C: DACC0000 0D00030B
	ds_bpermute_b32 v14, v11, v4                               // 000000356564: DACC0000 0E00040B
	s_waitcnt vmcnt(1)                                         // 00000035656C: BF8907F7
	ds_bpermute_b32 v15, v11, v5                               // 000000356570: DACC0000 0F00050B
	ds_bpermute_b32 v16, v11, v6                               // 000000356578: DACC0000 1000060B
	ds_bpermute_b32 v18, v11, v7                               // 000000356580: DACC0000 1200070B
	ds_bpermute_b32 v19, v11, v10                              // 000000356588: DACC0000 13000A0B
	s_waitcnt lgkmcnt(6)                                       // 000000356590: BF89FC67
	v_add_f32_e32 v2, v2, v12                                  // 000000356594: 06041902
	ds_bpermute_b32 v11, v11, v1                               // 000000356598: DACC0000 0B00010B
	s_waitcnt lgkmcnt(5)                                       // 0000003565A0: BF89FC57
	v_dual_add_f32 v3, v3, v13 :: v_dual_add_f32 v4, v4, v14   // 0000003565A4: C9081B03 03041D04
	s_waitcnt lgkmcnt(3)                                       // 0000003565AC: BF89FC37
	v_dual_add_f32 v5, v5, v15 :: v_dual_add_f32 v6, v6, v16   // 0000003565B0: C9081F05 05062106
	s_waitcnt lgkmcnt(1)                                       // 0000003565B8: BF89FC17
	v_dual_add_f32 v7, v7, v18 :: v_dual_add_f32 v10, v10, v19 // 0000003565BC: C9082507 070A270A
	ds_bpermute_b32 v12, v20, v3                               // 0000003565C4: DACC0000 0C000314
	ds_bpermute_b32 v13, v20, v4                               // 0000003565CC: DACC0000 0D000414
	ds_bpermute_b32 v14, v20, v5                               // 0000003565D4: DACC0000 0E000514
	ds_bpermute_b32 v15, v20, v6                               // 0000003565DC: DACC0000 0F000614
	ds_bpermute_b32 v16, v20, v7                               // 0000003565E4: DACC0000 10000714
	ds_bpermute_b32 v18, v20, v10                              // 0000003565EC: DACC0000 12000A14
	s_waitcnt lgkmcnt(6)                                       // 0000003565F4: BF89FC67
	v_add_f32_e32 v1, v1, v11                                  // 0000003565F8: 06021701
	ds_bpermute_b32 v11, v20, v2                               // 0000003565FC: DACC0000 0B000214
	ds_bpermute_b32 v19, v20, v1                               // 000000356604: DACC0000 13000114
	v_xor_b32_e32 v20, 2, v0                                   // 00000035660C: 3A280082
	s_delay_alu instid0(VALU_DEP_1)                            // 000000356610: BF870001
	.long 0xd44c0000                                           // 000000356614: D44C0000
	v_cndmask_b32_e32 v1, 32, v20, vcc_lo                      // 000000356618: 020228A0
	s_waitcnt lgkmcnt(6)                                       // 00000035661C: BF89FC67
	v_dual_add_f32 v3, v3, v12 :: v_dual_add_f32 v4, v4, v13   // 000000356620: C9081903 03041B04
	s_waitcnt lgkmcnt(4)                                       // 000000356628: BF89FC47
	v_dual_add_f32 v5, v5, v14 :: v_dual_add_f32 v6, v6, v15   // 00000035662C: C9081D05 05061F06
	s_waitcnt lgkmcnt(3)                                       // 000000356634: BF89FC37
	v_add_f32_e32 v7, v7, v16                                  // 000000356638: 060E2107
	v_cndmask_b32_e64 v20, v0, v20, s0                         // 00000035663C: D5010014 00022900
	v_xor_b32_e32 v14, 1, v0                                   // 000000356644: 3A1C0081
	s_waitcnt lgkmcnt(1)                                       // 000000356648: BF89FC17
	v_add_f32_e32 v2, v2, v11                                  // 00000035664C: 06041702
	s_delay_alu instid0(VALU_DEP_3)                            // 000000356650: BF870003
	v_lshlrev_b32_e32 v20, 2, v20                              // 000000356654: 30282882
	v_add_f32_e32 v12, v10, v18                                // 000000356658: 0618250A
	.long 0xd44c0000                                           // 00000035665C: D44C0000
	v_cndmask_b32_e32 v1, 32, v14, vcc_lo                      // 000000356660: 02021CA0
	s_waitcnt lgkmcnt(0)                                       // 000000356664: BF89FC07
	v_add_f32_e32 v1, v1, v19                                  // 000000356668: 06022701
	ds_bpermute_b32 v10, v20, v2                               // 00000035666C: DACC0000 0A000214
	ds_bpermute_b32 v11, v20, v3                               // 000000356674: DACC0000 0B000314
	ds_bpermute_b32 v13, v20, v4                               // 00000035667C: DACC0000 0D000414
	ds_bpermute_b32 v16, v20, v5                               // 000000356684: DACC0000 10000514
	ds_bpermute_b32 v18, v20, v6                               // 00000035668C: DACC0000 12000614
	ds_bpermute_b32 v19, v20, v7                               // 000000356694: DACC0000 13000714
	ds_bpermute_b32 v21, v20, v12                              // 00000035669C: DACC0000 15000C14
	ds_bpermute_b32 v20, v20, v1                               // 0000003566A4: DACC0000 14000114
	v_cndmask_b32_e64 v0, v0, v14, s0                          // 0000003566AC: D5010000 00021D00
	.long 0xd44a0000                                           // 0000003566B4: D44A0000
	v_cndmask_b32_e32 v1, 0, v17, vcc_lo                       // 0000003566B8: 02022280
	s_delay_alu instid0(VALU_DEP_2)                            // 0000003566BC: BF870002
	v_lshlrev_b32_e32 v22, 2, v0                               // 0000003566C0: 302C0082
	s_and_b32 s0, s0, vcc_lo                                   // 0000003566C4: 8B006A00
	s_waitcnt lgkmcnt(6)                                       // 0000003566C8: BF89FC67
	v_dual_add_f32 v14, v2, v10 :: v_dual_add_f32 v15, v3, v11 // 0000003566CC: C9081502 0E0E1703
	s_waitcnt lgkmcnt(4)                                       // 0000003566D4: BF89FC47
	v_dual_add_f32 v10, v4, v13 :: v_dual_add_f32 v11, v5, v16 // 0000003566D8: C9081B04 0A0A2105
	s_waitcnt lgkmcnt(2)                                       // 0000003566E0: BF89FC27
	v_dual_add_f32 v4, v6, v18 :: v_dual_add_f32 v5, v7, v19   // 0000003566E4: C9082506 04042707
	s_waitcnt lgkmcnt(0)                                       // 0000003566EC: BF89FC07
	v_dual_add_f32 v0, v12, v21 :: v_dual_add_f32 v1, v1, v20  // 0000003566F0: C9082B0C 00002901
	ds_bpermute_b32 v16, v22, v15                              // 0000003566F8: DACC0000 10000F16
	ds_bpermute_b32 v18, v22, v14                              // 000000356700: DACC0000 12000E16
	ds_bpermute_b32 v13, v22, v11                              // 000000356708: DACC0000 0D000B16
	ds_bpermute_b32 v12, v22, v10                              // 000000356710: DACC0000 0C000A16
	ds_bpermute_b32 v6, v22, v5                                // 000000356718: DACC0000 06000516
	ds_bpermute_b32 v7, v22, v4                                // 000000356720: DACC0000 07000416
	ds_bpermute_b32 v2, v22, v1                                // 000000356728: DACC0000 02000116
	ds_bpermute_b32 v3, v22, v0                                // 000000356730: DACC0000 03000016
	s_and_saveexec_b32 s1, s0                                  // 000000356738: BE812000
	s_cbranch_execz 120                                        // 00000035673C: BFA50078 <_ZN7halogen12_GLOBAL__N_16k_lq6wILi8ELi32ELi1EEEvPKhPKtPtll+0x1820>
	s_waitcnt lgkmcnt(6)                                       // 000000356740: BF89FC67
	v_dual_add_f32 v14, v14, v18 :: v_dual_add_f32 v15, v15, v16// 000000356744: C908250E 0E0E210F
	.long 0x7f203880                                           // 00000035674C: 7F203880
	.long 0xd73c0008                                           // 000000356750: D73C0008
	v_cndmask_b32_e32 v1, 1, v8, vcc_lo                        // 000000356754: 02021081
	s_lshl_b64 s[0:1], s[2:3], 1                               // 000000356758: 84808102
	s_delay_alu instid0(VALU_DEP_3)                            // 00000035675C: BF870003
	.long 0x7e20398e                                           // 000000356760: 7E20398E
	.long 0x7e22398f                                           // 000000356764: 7E22398F
	.long 0x7f223990                                           // 000000356768: 7F223990
	s_waitcnt lgkmcnt(5)                                       // 00000035676C: BF89FC57
	v_add_f32_e32 v13, v11, v13                                // 000000356770: 061A1B0B
	.long 0xd7006a08                                           // 000000356774: D7006A08
	v_cndmask_b32_e32 v1, s8, v8, vcc_lo                       // 000000356778: 02021008
	v_and_b32_e32 v18, 1, v16                                  // 00000035677C: 36242081
	s_waitcnt lgkmcnt(4)                                       // 000000356780: BF89FC47
	v_dual_add_f32 v12, v10, v12 :: v_dual_and_b32 v17, 1, v17 // 000000356784: C924190A 0C102281
	v_add_co_ci_u32_e64 v9, null, s9, v9, vcc_lo               // 00000035678C: D5207C09 01AA1209
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000356794: BF870223
	v_add3_u32 v18, v14, v18, 0x7fff                           // 000000356798: D6550012 03FE250E 00007FFF
	.long 0xd7006a0e                                           // 0000003567A4: D7006A0E
	v_cndmask_b32_e32 v0, v8, v0, vcc_lo                       // 0000003567A8: 02000108
	v_add3_u32 v17, v15, v17, 0x7fff                           // 0000003567AC: D6550011 03FE230F 00007FFF
	s_delay_alu instid0(VALU_DEP_4)                            // 0000003567B8: BF870004
	v_add_co_ci_u32_e64 v15, null, s1, v9, vcc_lo              // 0000003567BC: D5207C0F 01AA1201
	s_clause 0x1                                               // 0000003567C4: BF850001
	global_store_d16_hi_b16 v[8:9], v17, off                   // 0000003567C8: DC960000 007C1108
	global_store_d16_hi_b16 v[14:15], v18, off                 // 0000003567D0: DC960000 007C120E
	.long 0x7e1c398d                                           // 0000003567D8: 7E1C398D
	.long 0x7f1c3990                                           // 0000003567DC: 7F1C3990
	.long 0x7e20398c                                           // 0000003567E0: 7E20398C
	s_waitcnt lgkmcnt(3)                                       // 0000003567E4: BF89FC37
	v_add_f32_e32 v15, v5, v6                                  // 0000003567E8: 061E0D05
	s_lshl_b64 s[0:1], s[2:3], 2                               // 0000003567EC: 84808202
	s_waitcnt lgkmcnt(2)                                       // 0000003567F0: BF89FC27
	v_dual_add_f32 v7, v4, v7 :: v_dual_and_b32 v14, 1, v14    // 0000003567F4: C9240F04 070E1C81
	v_mad_u64_u32 v[4:5], null, s2, 6, v[8:9]                  // 0000003567FC: D6FE7C04 04210C02
	.long 0xd7006a0a                                           // 000000356804: D7006A0A
	v_cndmask_b32_e32 v0, v8, v0, vcc_lo                       // 000000356808: 02000108
	s_delay_alu instid0(VALU_DEP_1)                            // 00000035680C: BF870001
	v_add_co_ci_u32_e64 v11, null, s1, v9, vcc_lo              // 000000356810: D5207C0B 01AA1201
	v_and_b32_e32 v6, 1, v16                                   // 000000356818: 360C2081
	v_add3_u32 v8, v13, v14, 0x7fff                            // 00000035681C: D6550008 03FE1D0D 00007FFF
	.long 0x7e12398f                                           // 000000356828: 7E12398F
	.long 0x7f123990                                           // 00000035682C: 7F123990
	.long 0x7e203987                                           // 000000356830: 7E203987
	v_add3_u32 v12, v12, v6, 0x7fff                            // 000000356834: D655000C 03FE0D0C 00007FFF
	global_store_d16_hi_b16 v[10:11], v8, off                  // 000000356840: DC960000 007C080A
	v_mad_u64_u32 v[5:6], null, s3, 6, v[5:6]                  // 000000356848: D6FE7C05 04150C03
	s_waitcnt lgkmcnt(0)                                       // 000000356850: BF89FC07
	v_dual_add_f32 v13, v0, v3 :: v_dual_and_b32 v8, 1, v9     // 000000356854: C9240700 0D081281
	v_dual_add_f32 v9, v1, v2 :: v_dual_and_b32 v6, 1, v16     // 00000035685C: C9240501 09062081
	.long 0xd7006a00                                           // 000000356864: D7006A00
	v_cndmask_b32_e32 v0, v10, v0, vcc_lo                      // 000000356868: 0200010A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000035686C: BF870193
	.long 0x7e20398d                                           // 000000356870: 7E20398D
	v_add3_u32 v10, v7, v6, 0x7fff                             // 000000356874: D655000A 03FE0D07 00007FFF
	s_delay_alu instid0(VALU_DEP_4)                            // 000000356880: BF870004
	.long 0x7e0c3989                                           // 000000356884: 7E0C3989
	.long 0x7f0c3990                                           // 000000356888: 7F0C3990
	v_add_co_ci_u32_e64 v1, null, s1, v11, vcc_lo              // 00000035688C: D5207C01 01AA1601
	v_add3_u32 v11, v15, v8, 0x7fff                            // 000000356894: D655000B 03FE110F 00007FFF
	.long 0xd7006a02                                           // 0000003568A0: D7006A02
	v_cndmask_b32_e32 v0, v4, v0, vcc_lo                       // 0000003568A4: 02000104
	v_and_b32_e32 v8, 1, v16                                   // 0000003568A8: 36102081
	v_and_b32_e32 v14, 1, v6                                   // 0000003568AC: 361C0C81
	v_add_co_ci_u32_e64 v3, null, s1, v5, vcc_lo               // 0000003568B0: D5207C03 01AA0A01
	.long 0xd7006a06                                           // 0000003568B8: D7006A06
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 0000003568BC: 02000100
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003568C0: BF870001
	v_add_co_ci_u32_e64 v7, null, s1, v1, vcc_lo               // 0000003568C4: D5207C07 01AA0201
	v_add3_u32 v13, v13, v8, 0x7fff                            // 0000003568CC: D655000D 03FE110D 00007FFF
	.long 0xd7006a08                                           // 0000003568D8: D7006A08
	v_cndmask_b32_e32 v0, v2, v0, vcc_lo                       // 0000003568DC: 02000102
	v_add3_u32 v14, v9, v14, 0x7fff                            // 0000003568E0: D655000E 03FE1D09 00007FFF
	v_add_co_ci_u32_e64 v9, null, s1, v3, vcc_lo               // 0000003568EC: D5207C09 01AA0601
	s_clause 0x4                                               // 0000003568F4: BF850004
	global_store_d16_hi_b16 v[4:5], v12, off                   // 0000003568F8: DC960000 007C0C04
	global_store_d16_hi_b16 v[0:1], v11, off                   // 000000356900: DC960000 007C0B00
	global_store_d16_hi_b16 v[2:3], v10, off                   // 000000356908: DC960000 007C0A02
	global_store_d16_hi_b16 v[6:7], v14, off                   // 000000356910: DC960000 007C0E06
	global_store_d16_hi_b16 v[8:9], v13, off                   // 000000356918: DC960000 007C0D08
	s_endpgm                                                   // 000000356920: BFB00000
		...

