0000000000522300 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb1ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_>:
; _ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb1ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_():
	s_clause 0x3                                               // 000000522300: BF850003
	s_load_b256 s[20:27], s[0:1], null                         // 000000522304: F40C0500 F8000000
	s_load_b256 s[12:19], s[0:1], 0x20                         // 00000052230C: F40C0300 F8000020
	s_load_b128 s[28:31], s[0:1], 0x40                         // 000000522314: F4080700 F8000040
	s_load_b32 s33, s[0:1], 0x54                               // 00000052231C: F4000840 F8000054
	v_and_b32_e32 v10, 31, v0                                  // 000000522324: 3614009F
	v_lshrrev_b32_e32 v8, 5, v0                                // 000000522328: 32100085
	s_mov_b32 s4, s3                                           // 00000052232C: BE840003
	s_mov_b32 s10, exec_lo                                     // 000000522330: BE8A007E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000522334: BF870002
	v_lshlrev_b32_e32 v9, 2, v10                               // 000000522338: 30121482
	s_waitcnt lgkmcnt(0)                                       // 00000052233C: BF89FC07
	s_ashr_i32 s35, s25, 31                                    // 000000522340: 86239F19
	s_mul_i32 s34, s27, s3                                     // 000000522344: 9622031B
	s_lshr_b32 s0, s35, 25                                     // 000000522348: 85009923
	s_add_i32 s1, s34, s27                                     // 00000052234C: 81011B22
	s_add_i32 s0, s25, s0                                      // 000000522350: 81000019
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000522354: BF870499
	s_ashr_i32 s0, s0, 7                                       // 000000522358: 86008700
	s_min_i32 s0, s0, s1                                       // 00000052235C: 89000100
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000522360: BF870499
	s_sub_i32 s11, s0, s34                                     // 000000522364: 818B2200
	.long 0xd4c4007e                                           // 000000522368: D4C4007E
	v_cndmask_b32_e32 v1, s11, v8, vcc_lo                      // 00000052236C: 0202100B
	s_cbranch_execz 501                                        // 000000522370: BFA501F5 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb1ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x848>
	s_add_i32 s27, s24, -1                                     // 000000522374: 811BC118
	s_cmp_lg_u64 s[30:31], 0                                   // 000000522378: BF11801E
	v_dual_mov_b32 v11, v8 :: v_dual_and_b32 v2, 2, v0         // 00000052237C: CA240108 0B020082
	s_cselect_b32 s36, -1, 0                                   // 000000522384: 982480C1
	s_abs_i32 s37, s11                                         // 000000522388: BEA5150B
	v_lshlrev_b32_e32 v6, 3, v10                               // 00000052238C: 300C1483
	s_cvt_f32_u32 s0, s37                                      // 000000522390: BE806525
	v_and_b32_e32 v1, 1, v0                                    // 000000522394: 36020081
	v_and_b32_e32 v4, 4, v0                                    // 000000522398: 36080084
	v_and_b32_e32 v5, 8, v0                                    // 00000052239C: 360A0088
	v_rcp_iflag_f32_e32 v3, s0                                 // 0000005223A0: 7E065600
	v_add_nc_u32_e32 v7, s34, v8                               // 0000005223A4: 4A0E1022
	.long 0xd44a0003                                           // 0000005223A8: D44A0003
	v_cndmask_b32_e32 v1, 0, v2, vcc_lo                        // 0000005223AC: 02020480
	v_lshl_or_b32 v2, v8, 8, v6                                // 0000005223B0: D6560002 04191108
	s_ashr_i32 s41, s11, 31                                    // 0000005223B8: 86299F0B
	s_sub_i32 s9, 0, s37                                       // 0000005223BC: 81892580
	s_mul_i32 s43, s41, 0x1400                                 // 0000005223C0: 962BFF29 00001400
	.long 0xd44c0000                                           // 0000005223C8: D44C0000
	v_cndmask_b32_e32 v1, 16, v10, vcc_lo                      // 0000005223CC: 02021490
	.long 0xd44a0001                                           // 0000005223D0: D44A0001
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 0000005223D4: 02020280
	.long 0xd44a0006                                           // 0000005223D8: D44A0006
	v_cndmask_b32_e32 v1, 0, v5, vcc_lo                        // 0000005223DC: 02020A80
	v_readfirstlane_b32 s5, v3                                 // 0000005223E0: 7E0A0503
	v_lshl_or_b32 v1, v7, 7, v9                                // 0000005223E4: D6560001 04250F07
	v_subrev_nc_u32_e32 v12, s43, v2                           // 0000005223EC: 4E18042B
	s_lshl_b32 s7, s11, 7                                      // 0000005223F0: 8407870B
	s_mov_b32 s38, s25                                         // 0000005223F4: BEA60019
	s_mul_f32 s8, s5, 0x4f7ffffe                               // 0000005223F8: A208FF05 4F7FFFFE
	.long 0xd44a0005                                           // 000000522400: D44A0005
	v_cndmask_b32_e32 v1, 0, v4, vcc_lo                        // 000000522404: 02020880
	s_mov_b32 s39, 0                                           // 000000522408: BEA70080
	s_mov_b32 s40, 0x76543210                                  // 00000052240C: BEA800FF 76543210
	s_cvt_u32_f32 s8, s8                                       // 000000522414: BE886708
	s_lshl_b32 s42, s11, 8                                     // 000000522418: 842A880B
	s_sub_i32 s43, 0, s7                                       // 00000052241C: 81AB0780
	s_mov_b32 s45, 0x3db504f3                                  // 000000522420: BEAD00FF 3DB504F3
	s_mul_i32 s9, s9, s8                                       // 000000522428: 96090809
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000052242C: BF870499
	s_mul_hi_u32 s9, s8, s9                                    // 000000522430: 96890908
	s_add_i32 s44, s8, s9                                      // 000000522434: 812C0908
	s_branch 164                                               // 000000522438: BFA000A4 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb1ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x3cc>
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000052243C: BF870091
	.long 0xd7006a02                                           // 000000522440: D7006A02
	v_cndmask_b32_e32 v1, s12, v2, vcc_lo                      // 000000522444: 0202040C
	v_add_co_ci_u32_e64 v3, null, s13, v3, vcc_lo              // 000000522448: D5207C03 01AA060D
	v_add_nc_u32_e32 v1, 0x400, v1                             // 000000522450: 4A0202FF 00000400
	global_load_d16_b16 v2, v[2:3], off offset:6               // 000000522458: DC820006 027C0002
	s_waitcnt vmcnt(0)                                         // 000000522460: BF8903F7
	v_fma_mix_f32 v5, v17, v2, v15 op_sel_hi:[0,1,0]           // 000000522464: CC200005 143E0511
	v_sub_f32_e32 v4, v18, v16                                 // 00000052246C: 08082112
	v_fma_mix_f32 v2, -v17, v2, v15 op_sel_hi:[0,1,0]          // 000000522470: CC200002 343E0511
	v_add_f32_e32 v3, v18, v16                                 // 000000522478: 06062112
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000052247C: BF8701A2
	v_add_f32_e32 v7, v4, v2                                   // 000000522480: 060E0504
	v_sub_f32_e32 v2, v4, v2                                   // 000000522484: 08040504
	v_add_f32_e32 v6, v3, v5                                   // 000000522488: 060C0B03
	v_sub_f32_e32 v3, v3, v5                                   // 00000052248C: 08060B03
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000522490: BF870193
	v_mov_b32_dpp v16, v2 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000522494: 7E2002FA FF016102
	v_mov_b32_dpp v4, v6 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000052249C: 7E0802FA FF016106
	v_cndmask_b32_e64 v6, -v6, v6, s1                          // 0000005224A4: D5010006 20060D06
	v_cndmask_b32_e64 v2, -v2, v2, s1                          // 0000005224AC: D5010002 20060502
	v_mov_b32_dpp v15, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000005224B4: 7E1E02FA FF016103
	v_cndmask_b32_e64 v3, -v3, v3, s1                          // 0000005224BC: D5010003 20060703
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000005224C4: BF870144
	v_add_f32_e32 v4, v6, v4                                   // 0000005224C8: 06080906
	v_mov_b32_dpp v5, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000005224CC: 7E0A02FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, s1                          // 0000005224D4: D5010007 20060F07
	.long 0xd72c0006                                           // 0000005224DC: D72C0006
	v_cndmask_b32_e32 v1, 0x1400, v14, vcc_lo                  // 0000005224E0: 02021CFF 00001400
	v_dual_add_f32 v2, v2, v16 :: v_dual_add_f32 v5, v7, v5    // 0000005224E8: C9082102 02040B07
	v_mov_b32_dpp v7, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000005224F0: 7E0E02FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, s3                          // 0000005224F8: D5010004 200E0904
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000522500: BF8701C3
	v_mov_b32_dpp v16, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000522504: 7E2002FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, s3                          // 00000052250C: D5010002 200E0502
	v_mov_b32_dpp v14, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000522514: 7E1C02FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, s3                          // 00000052251C: D5010005 200E0B05
	v_dual_add_f32 v3, v3, v15 :: v_dual_add_f32 v2, v2, v16   // 000000522524: C9081F03 03022102
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000052252C: BF870112
	v_add_f32_e32 v5, v5, v14                                  // 000000522530: 060A1D05
	v_mov_b32_dpp v15, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000522534: 7E1E02FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, s3                          // 00000052253C: D5010003 200E0703
	s_delay_alu instid0(VALU_DEP_4)                            // 000000522544: BF870004
	v_mov_b32_dpp v16, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000522548: 7E2002FA FF016402
	v_cndmask_b32_e64 v2, -v2, v2, s5                          // 000000522550: D5010002 20160502
	v_mov_b32_dpp v14, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000522558: 7E1C02FA FF016405
	v_cndmask_b32_e64 v5, -v5, v5, s5                          // 000000522560: D5010005 20160B05
	v_add_f32_e32 v4, v4, v7                                   // 000000522568: 06080F04
	.long 0xd72c0007                                           // 00000052256C: D72C0007
	v_cndmask_b32_e32 v1, s42, v13, vcc_lo                     // 000000522570: 02021A2A
	v_dual_add_f32 v2, v2, v16 :: v_dual_add_nc_u32 v11, 8, v11// 000000522574: C9202102 020A1688
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000052257C: BF870214
	v_add_f32_e32 v5, v5, v14                                  // 000000522580: 060A1D05
	v_mov_b32_dpp v13, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000522584: 7E1A02FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s5                          // 00000052258C: D5010004 20160904
	v_add_f32_e32 v3, v3, v15                                  // 000000522594: 06061F03
	v_mov_b32_dpp v16, v2 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000522598: 7E2002FA FF016802
	v_mov_b32_dpp v14, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000005225A0: 7E1C02FA FF016805
	v_cndmask_b32_e64 v5, -v5, v5, s6                          // 0000005225A8: D5010005 201A0B05
	v_add_f32_e32 v4, v4, v13                                  // 0000005225B0: 06081B04
	v_mov_b32_dpp v15, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000005225B4: 7E1E02FA FF016403
	v_cndmask_b32_e64 v3, -v3, v3, s5                          // 0000005225BC: D5010003 20160703
	v_cndmask_b32_e64 v2, -v2, v2, s6                          // 0000005225C4: D5010002 201A0502
	v_add_f32_e32 v5, v5, v14                                  // 0000005225CC: 060A1D05
	v_mov_b32_dpp v13, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000005225D0: 7E1A02FA FF016804
	v_cndmask_b32_e64 v4, -v4, v4, s6                          // 0000005225D8: D5010004 201A0904
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000005225E0: BF870214
	v_dual_add_f32 v3, v3, v15 :: v_dual_add_f32 v2, v2, v16   // 0000005225E4: C9081F03 03022102
	v_mov_b32_e32 v14, v5                                      // 0000005225EC: 7E1C0305
	v_cndmask_b32_e64 v5, -v5, v5, s0                          // 0000005225F0: D5010005 20020B05
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000005225F8: BF870214
	v_add_f32_e32 v4, v4, v13                                  // 0000005225FC: 06081B04
	v_mov_b32_dpp v15, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000522600: 7E1E02FA FF016803
	v_cndmask_b32_e64 v3, -v3, v3, s6                          // 000000522608: D5010003 201A0703
	v_mov_b32_e32 v16, v2                                      // 000000522610: 7E200302
	v_cndmask_b32_e64 v2, -v2, v2, s0                          // 000000522614: D5010002 20020502
	v_mov_b32_e32 v13, v4                                      // 00000052261C: 7E1A0304
	v_cndmask_b32_e64 v4, -v4, v4, s0                          // 000000522620: D5010004 20020904
	v_add_f32_e32 v3, v3, v15                                  // 000000522628: 06061F03
	v_permlanex16_b32 v14, v14, s40, 0xfedcba98                // 00000052262C: D65C000E 03FC510E FEDCBA98
	v_permlanex16_b32 v16, v16, s40, 0xfedcba98                // 000000522638: D65C0010 03FC5110 FEDCBA98
	v_permlanex16_b32 v13, v13, s40, 0xfedcba98                // 000000522644: D65C000D 03FC510D FEDCBA98
	v_sub_nc_u32_e32 v6, v6, v7                                // 000000522650: 4C0C0F06
	v_mov_b32_e32 v15, v3                                      // 000000522654: 7E1E0303
	v_cndmask_b32_e64 v3, -v3, v3, s0                          // 000000522658: D5010003 20020703
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000522660: BF870214
	v_dual_add_f32 v5, v5, v14 :: v_dual_add_f32 v4, v4, v13   // 000000522664: C9081D05 05041B04
	v_dual_add_f32 v7, v2, v16 :: v_dual_add_nc_u32 v6, v12, v6// 00000052266C: C9202102 07060D0C
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000522674: BF870224
	v_permlanex16_b32 v15, v15, s40, 0xfedcba98                // 000000522678: D65C000F 03FC510F FEDCBA98
	v_cmp_le_i32_e32 vcc_lo, s11, v11                          // 000000522684: 7C86160B
	v_fma_mixlo_f16 v2, v4, s45, 0                             // 000000522688: CC210002 02005B04
	v_add_nc_u32_e32 v12, 0x800, v12                           // 000000522690: 4A1818FF 00000800
	v_fma_mixhi_f16 v2, v5, s45, 0                             // 000000522698: CC220002 02005B05
	v_add_f32_e32 v13, v3, v15                                 // 0000005226A0: 061A1F03
	v_fma_mixhi_f16 v3, v7, s45, 0                             // 0000005226A4: CC220003 02005B07
	s_or_b32 s39, vcc_lo, s39                                  // 0000005226AC: 8C27276A
	s_delay_alu instid0(VALU_DEP_2)                            // 0000005226B0: BF870002
	v_fma_mixlo_f16 v3, v13, s45, 0                            // 0000005226B4: CC210003 02005B0D
	ds_store_b64 v6, v[2:3]                                    // 0000005226BC: D9340000 00000206
	s_and_not1_b32 exec_lo, exec_lo, s39                       // 0000005226C4: 917E277E
	s_cbranch_execz 287                                        // 0000005226C8: BFA5011F <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb1ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x848>
	.long 0xd72d0002                                           // 0000005226CC: D72D0002
	v_cndmask_b32_e32 v0, v11, v44, vcc_lo                     // 0000005226D0: 0200590B
	s_mov_b32 s7, -1                                           // 0000005226D4: BE8700C1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005226D8: BF870091
	.long 0xd72c0003                                           // 0000005226DC: D72C0003
	v_cndmask_b32_e32 v0, v2, v37, vcc_lo                      // 0000005226E0: 02004B02
	v_sub_nc_u32_e32 v3, v11, v3                               // 0000005226E4: 4C06070B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000005226E8: BF870121
	v_subrev_nc_u32_e32 v5, s37, v3                            // 0000005226EC: 4E0A0625
	v_cmp_le_u32_e32 vcc_lo, s37, v3                           // 0000005226F0: 7C960625
	v_dual_cndmask_b32 v3, v3, v5 :: v_dual_add_nc_u32 v4, 1, v2// 0000005226F4: CA600B03 03040481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000005226FC: BF870111
	v_cndmask_b32_e32 v2, v2, v4, vcc_lo                       // 000000522700: 02040902
	v_cmp_le_u32_e32 vcc_lo, s37, v3                           // 000000522704: 7C960625
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000522708: BF870092
	v_add_nc_u32_e32 v4, 1, v2                                 // 00000052270C: 4A080481
	v_cndmask_b32_e32 v2, v2, v4, vcc_lo                       // 000000522710: 02040902
	s_and_not1_b32 vcc_lo, exec_lo, s36                        // 000000522714: 916A247E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000522718: BF870091
	v_xor_b32_e32 v14, s41, v2                                 // 00000052271C: 3A1C0429
	v_subrev_nc_u32_e32 v13, s41, v14                          // 000000522720: 4E1A1C29
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000522724: BF8700A1
	v_mad_u64_u32 v[6:7], null, s43, v13, v[1:2]               // 000000522728: D6FE7C06 04061A2B
	v_min_i32_e32 v2, s27, v13                                 // 000000522730: 22041A1B
	v_mad_i64_i32 v[4:5], null, v2, s38, 0                     // 000000522734: D6FF7C04 02004D02
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000052273C: BF870093
	v_ashrrev_i32_e32 v7, 31, v6                               // 000000522740: 340E0C9F
	.long 0xd73c0002                                           // 000000522744: D73C0002
	v_cndmask_b32_e32 v1, 1, v6, vcc_lo                        // 000000522748: 02020C81
	s_cbranch_vccnz 210                                        // 00000052274C: BFA400D2 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb1ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x798>
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000522750: BF870093
	.long 0xd7006a06                                           // 000000522754: D7006A06
	v_cndmask_b32_e32 v1, v4, v6, vcc_lo                       // 000000522758: 02020D04
	v_add_co_ci_u32_e64 v7, null, v5, v7, vcc_lo               // 00000052275C: D5207C07 01AA0F05
	.long 0x7f3e3880                                           // 000000522764: 7F3E3880
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000522768: BF870112
	.long 0xd73c0006                                           // 00000052276C: D73C0006
	v_cndmask_b32_e32 v1, 1, v6, vcc_lo                        // 000000522770: 02020C81
	.long 0x7f44399f                                           // 000000522774: 7F44399F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000522778: BF870092
	.long 0xd7006a0f                                           // 00000052277C: D7006A0F
	v_cndmask_b32_e32 v1, s22, v6, vcc_lo                      // 000000522780: 02020C16
	v_add_co_ci_u32_e64 v16, null, s23, v7, vcc_lo             // 000000522784: D5207C10 01AA0E17
	.long 0xd7006a06                                           // 00000052278C: D7006A06
	v_cndmask_b32_e32 v1, s30, v6, vcc_lo                      // 000000522790: 02020C1E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000522794: BF870001
	v_add_co_ci_u32_e64 v7, null, s31, v7, vcc_lo              // 000000522798: D5207C07 01AA0E1F
	global_load_b64 v[15:16], v[15:16], off                    // 0000005227A0: DC560000 0F7C000F
	.long 0xd7006a11                                           // 0000005227A8: D7006A11
	v_cndmask_b32_e32 v1, s12, v2, vcc_lo                      // 0000005227AC: 0202040C
	global_load_b64 v[6:7], v[6:7], off                        // 0000005227B0: DC560000 067C0006
	v_add_co_ci_u32_e64 v18, null, s13, v3, vcc_lo             // 0000005227B8: D5207C12 01AA060D
	s_clause 0x1                                               // 0000005227C0: BF850001
	global_load_b32 v19, v[17:18], off                         // 0000005227C4: DC520000 137C0011
	global_load_d16_b16 v17, v[17:18], off offset:4            // 0000005227CC: DC820004 117C0011
	s_waitcnt vmcnt(3)                                         // 0000005227D4: BF890FF7
	.long 0x7e24390f                                           // 0000005227D8: 7E24390F
	s_waitcnt vmcnt(2)                                         // 0000005227DC: BF890BF7
	v_and_b32_e32 v41, 0xffff0000, v6                          // 0000005227E0: 36520CFF FFFF0000
	v_lshlrev_b32_e32 v6, 16, v6                               // 0000005227E8: 300C0C90
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005227EC: BF870093
	v_lshlrev_b32_e32 v18, 16, v18                             // 0000005227F0: 30242490
	v_mul_f32_e32 v22, 0xbfb8aa3b, v18                         // 0000005227F4: 102C24FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000005227FC: BF870291
	v_exp_f32_e32 v22, v22                                     // 000000522800: 7E2C4B16
	v_dual_add_f32 v22, 1.0, v22 :: v_dual_and_b32 v15, 0xffff0000, v15// 000000522804: C9242CF2 160E1EFF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000522810: BF870111
	v_mul_f32_e32 v21, 0xbfb8aa3b, v15                         // 000000522814: 102A1EFF BFB8AA3B
	v_div_scale_f32 v26, null, v22, v22, v18                   // 00000052281C: D6FC7C1A 044A2D16
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000522824: BF8701B2
	v_exp_f32_e32 v21, v21                                     // 000000522828: 7E2A4B15
	v_lshlrev_b32_e32 v20, 16, v16                             // 00000052282C: 30282090
	v_div_scale_f32 v39, s8, v18, v22, v18                     // 000000522830: D6FC0827 044A2D12
	v_rcp_f32_e32 v30, v26                                     // 000000522838: 7E3C551A
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000052283C: BF870196
	v_add_f32_e32 v21, 1.0, v21                                // 000000522840: 062A2AF2
	v_mul_f32_e32 v23, 0xbfb8aa3b, v20                         // 000000522844: 102E28FF BFB8AA3B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000052284C: BF870195
	v_fma_f32 v38, -v26, v30, 1.0                              // 000000522850: D6130026 23CA3D1A
	v_div_scale_f32 v25, null, v21, v21, v15                   // 000000522858: D6FC7C19 043E2B15
	s_delay_alu instid0(VALU_DEP_3)                            // 000000522860: BF870003
	v_exp_f32_e32 v23, v23                                     // 000000522864: 7E2E4B17
	v_and_b32_e32 v16, 0xffff0000, v16                         // 000000522868: 362020FF FFFF0000
	v_div_scale_f32 v35, vcc_lo, v15, v21, v15                 // 000000522870: D6FC6A23 043E2B0F
	v_fmac_f32_e32 v30, v38, v30                               // 000000522878: 563C3D26
	v_rcp_f32_e32 v28, v25                                     // 00000052287C: 7E385519
	s_delay_alu instid0(TRANS32_DEP_2) | instid1(VALU_DEP_3)   // 000000522880: BF870186
	v_dual_add_f32 v23, 1.0, v23 :: v_dual_mul_f32 v24, 0xbfb8aa3b, v16// 000000522884: C9062EF2 171820FF BFB8AA3B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000522890: BF870115
	v_fma_f32 v36, -v25, v28, 1.0                              // 000000522894: D6130024 23CA3919
	v_div_scale_f32 v27, null, v23, v23, v20                   // 00000052289C: D6FC7C1B 04522F17
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000005228A4: BF8701A3
	v_exp_f32_e32 v24, v24                                     // 0000005228A8: 7E304B18
	v_div_scale_f32 v37, s7, v20, v23, v20                     // 0000005228AC: D6FC0725 04522F14
	v_fmac_f32_e32 v28, v36, v28                               // 0000005228B4: 56383924
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 0000005228B8: BF870313
	v_rcp_f32_e32 v32, v27                                     // 0000005228BC: 7E40551B
	v_add_f32_e32 v24, 1.0, v24                                // 0000005228C0: 063030F2
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000005228C4: BF870115
	v_fma_f32 v40, -v27, v32, 1.0                              // 0000005228C8: D6130028 23CA411B
	v_div_scale_f32 v29, null, v24, v24, v16                   // 0000005228D0: D6FC7C1D 04423118
	v_div_scale_f32 v38, s9, v16, v24, v16                     // 0000005228D8: D6FC0926 04423110
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000005228E0: BF870193
	v_fmac_f32_e32 v32, v40, v32                               // 0000005228E4: 56404128
	v_rcp_f32_e32 v33, v29                                     // 0000005228E8: 7E42551D
	v_mul_f32_e32 v40, v35, v28                                // 0000005228EC: 10503923
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000005228F0: BF870112
	v_mul_f32_e32 v42, v37, v32                                // 0000005228F4: 10544125
	v_fma_f32 v43, -v25, v40, v35                              // 0000005228F8: D613002B 248E5119
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000522900: BF870292
	v_fma_f32 v46, -v27, v42, v37                              // 000000522904: D613002E 2496551B
	v_fma_f32 v36, -v29, v33, 1.0                              // 00000052290C: D6130024 23CA431D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000522914: BF870113
	v_fmac_f32_e32 v40, v43, v28                               // 000000522918: 5650392B
	v_dual_fmac_f32 v42, v46, v32 :: v_dual_fmac_f32 v33, v36, v33// 00000052291C: C800412E 2A204324
	v_mul_f32_e32 v36, v39, v30                                // 000000522924: 10483D27
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000522928: BF870193
	v_fma_f32 v25, -v25, v40, v35                              // 00000052292C: D6130019 248E5119
	v_fma_f32 v27, -v27, v42, v37                              // 000000522934: D613001B 2496551B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000052293C: BF870214
	v_mul_f32_e32 v44, v38, v33                                // 000000522940: 10584326
	v_fma_f32 v45, -v26, v36, v39                              // 000000522944: D613002D 249E491A
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000052294C: BF8701A4
	v_div_fmas_f32 v25, v25, v28, v40                          // 000000522950: D6370019 04A23919
	s_mov_b32 vcc_lo, s8                                       // 000000522958: BEEA0008
	v_fma_f32 v43, -v29, v44, v38                              // 00000052295C: D613002B 249A591D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000522964: BF870193
	v_fmac_f32_e32 v36, v45, v30                               // 000000522968: 56483D2D
	v_div_fixup_f32 v15, v25, v21, v15                         // 00000052296C: D627000F 043E2B19
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000522974: BF870193
	v_fmac_f32_e32 v44, v43, v33                               // 000000522978: 5658432B
	v_fma_f32 v26, -v26, v36, v39                              // 00000052297C: D613001A 249E491A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000522984: BF870193
	v_mul_f32_e32 v15, v15, v41                                // 000000522988: 101E530F
	v_fma_f32 v25, -v29, v44, v38                              // 00000052298C: D6130019 249A591D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000522994: BF8701A3
	v_div_fmas_f32 v26, v26, v30, v36                          // 000000522998: D637001A 04923D1A
	s_mov_b32 vcc_lo, s7                                       // 0000005229A0: BEEA0007
	.long 0x7e3e398f                                           // 0000005229A4: 7E3E398F
	v_div_fmas_f32 v21, v27, v32, v42                          // 0000005229A8: D6370015 04AA411B
	s_mov_b32 vcc_lo, s9                                       // 0000005229B0: BEEA0009
	v_div_fixup_f32 v18, v26, v22, v18                         // 0000005229B4: D6270012 044A2D1A
	v_lshlrev_b32_e32 v22, 16, v7                              // 0000005229BC: 302C0E90
	v_and_b32_e32 v7, 0xffff0000, v7                           // 0000005229C0: 360E0EFF FFFF0000
	v_div_fixup_f32 v20, v21, v23, v20                         // 0000005229C8: D6270014 04522F15
	s_mov_b32 s7, 0                                            // 0000005229D0: BE870080
	v_mul_f32_e32 v6, v18, v6                                  // 0000005229D4: 100C0D12
	v_div_fmas_f32 v18, v25, v33, v44                          // 0000005229D8: D6370012 04B24319
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000005229E0: BF870193
	v_mul_f32_e32 v20, v20, v22                                // 0000005229E4: 10282D14
	.long 0x7e443986                                           // 0000005229E8: 7E443986
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000005229EC: BF870223
	v_div_fixup_f32 v16, v18, v24, v16                         // 0000005229F0: D6270010 04423112
	v_and_b32_e32 v18, 1, v31                                  // 0000005229F8: 36243E81
	v_bfe_u32 v21, v20, 16, 1                                  // 0000005229FC: D6100015 02052114
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000522A04: BF870193
	v_dual_mul_f32 v7, v16, v7 :: v_dual_and_b32 v22, 1, v34   // 000000522A08: C8E40F10 07164481
	v_add3_u32 v15, v15, v18, 0x7fff                           // 000000522A10: D655000F 03FE250F 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000522A1C: BF870193
	v_add3_u32 v16, v20, v21, 0x7fff                           // 000000522A20: D6550010 03FE2B14 00007FFF
	v_add3_u32 v6, v6, v22, 0x7fff                             // 000000522A2C: D6550006 03FE2D06 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000522A38: BF870214
	v_bfe_u32 v18, v7, 16, 1                                   // 000000522A3C: D6100012 02052107
	v_and_b32_e32 v15, 0xffff0000, v15                         // 000000522A44: 361E1EFF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000522A4C: BF870214
	v_and_b32_e32 v20, 0xffff0000, v16                         // 000000522A50: 362820FF FFFF0000
	v_and_b32_e32 v6, 0xffff0000, v6                           // 000000522A58: 360C0CFF FFFF0000
	s_delay_alu instid0(VALU_DEP_4)                            // 000000522A60: BF870004
	v_add3_u32 v7, v7, v18, 0x7fff                             // 000000522A64: D6550007 03FE2507 00007FFF
	s_waitcnt vmcnt(1)                                         // 000000522A70: BF8907F7
	v_fma_mix_f32 v16, v19, v15, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000522A74: CC200810 8A021F13
	s_waitcnt vmcnt(0)                                         // 000000522A7C: BF8903F7
	v_fma_mix_f32 v15, v17, v20, neg(0) op_sel_hi:[1,0,0]      // 000000522A80: CC20000F 8A022911
	v_fma_mix_f32 v18, v19, v6, neg(0) op_sel_hi:[1,0,0]       // 000000522A88: CC200012 8A020D13
	v_and_b32_e32 v17, 0xffff0000, v7                          // 000000522A90: 36220EFF FFFF0000
	s_and_not1_b32 vcc_lo, exec_lo, s7                         // 000000522A98: 916A077E
	s_cbranch_vccnz 65127                                      // 000000522A9C: BFA4FE67 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb1ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x13c>
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000522AA0: BF870093
	.long 0xd73c0004                                           // 000000522AA4: D73C0004
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 000000522AA8: 02020881
	.long 0xd7006a04                                           // 000000522AAC: D7006A04
	v_cndmask_b32_e32 v1, s22, v4, vcc_lo                      // 000000522AB0: 02020816
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000522AB4: BF870111
	v_add_co_ci_u32_e64 v5, null, s23, v5, vcc_lo              // 000000522AB8: D5207C05 01AA0A17
	.long 0xd7006a04                                           // 000000522AC0: D7006A04
	v_cndmask_b32_e32 v1, v4, v2, vcc_lo                       // 000000522AC4: 02020504
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000522AC8: BF8700A1
	v_add_co_ci_u32_e64 v5, null, v5, v3, vcc_lo               // 000000522ACC: D5207C05 01AA0705
	.long 0xd7006a06                                           // 000000522AD4: D7006A06
	v_cndmask_b32_e32 v1, s12, v2, vcc_lo                      // 000000522AD8: 0202040C
	v_add_co_ci_u32_e64 v7, null, s13, v3, vcc_lo              // 000000522ADC: D5207C07 01AA060D
	global_load_b64 v[4:5], v[4:5], off                        // 000000522AE4: DC560000 047C0004
	s_clause 0x1                                               // 000000522AEC: BF850001
	global_load_b32 v17, v[6:7], off                           // 000000522AF0: DC520000 117C0006
	global_load_d16_b16 v6, v[6:7], off offset:4               // 000000522AF8: DC820004 067C0006
	s_waitcnt vmcnt(2)                                         // 000000522B00: BF890BF7
	.long 0x7e0e3904                                           // 000000522B04: 7E0E3904
	v_and_b32_e32 v4, 0xffff0000, v4                           // 000000522B08: 360808FF FFFF0000
	v_lshlrev_b32_e32 v15, 16, v5                              // 000000522B10: 301E0A90
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000522B14: BF8701A3
	v_lshlrev_b32_e32 v7, 16, v7                               // 000000522B18: 300E0E90
	s_waitcnt vmcnt(1)                                         // 000000522B1C: BF8907F7
	v_fma_mix_f32 v16, v17, v4, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000522B20: CC200810 8A020911
	s_waitcnt vmcnt(0)                                         // 000000522B28: BF8903F7
	v_fma_mix_f32 v15, v6, v15, neg(0) op_sel_hi:[1,0,0]       // 000000522B2C: CC20000F 8A021F06
	v_fma_mix_f32 v18, v17, v7, neg(0) op_sel_hi:[1,0,0]       // 000000522B34: CC200012 8A020F11
	v_and_b32_e32 v17, 0xffff0000, v5                          // 000000522B3C: 36220AFF FFFF0000
	s_branch 65085                                             // 000000522B44: BFA0FE3D <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb1ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x13c>
	s_or_b32 exec_lo, exec_lo, s10                             // 000000522B48: 8C7E0A7E
	s_bfe_i32 s10, s11, 0x1001c                                // 000000522B4C: 938AFF0B 0001001C
	s_lshl_b32 s3, s11, 3                                      // 000000522B54: 8403830B
	s_lshr_b64 s[0:1], s[10:11], 29                            // 000000522B58: 85809D0A
	s_lshr_b32 s1, s35, 28                                     // 000000522B5C: 85019C23
	s_add_i32 s0, s0, 7                                        // 000000522B60: 81008700
	s_add_i32 s1, s25, s1                                      // 000000522B64: 81010119
	s_ashr_i32 s0, s0, 3                                       // 000000522B68: 86008300
	s_waitcnt lgkmcnt(0)                                       // 000000522B6C: BF89FC07
	.long 0xd72c0001                                           // 000000522B70: D72C0001
	v_cndmask_b32_e32 v1, s0, v8, vcc_lo                       // 000000522B74: 02021000
	s_barrier                                                  // 000000522B78: BFBD0000
	buffer_gl0_inv                                             // 000000522B7C: E0AC0000 00000000
	v_add_nc_u32_e32 v2, s0, v1                                // 000000522B84: 4A040200
	s_ashr_i32 s0, s1, 4                                       // 000000522B88: 86008401
	s_lshl_b32 s1, s34, 3                                      // 000000522B8C: 84018322
	s_mul_hi_i32 s5, s0, s2                                    // 000000522B90: 97050200
	s_mul_i32 s0, s0, s2                                       // 000000522B94: 96000200
	v_min_i32_e32 v7, s3, v2                                   // 000000522B98: 220E0403
	s_ashr_i32 s3, s1, 31                                      // 000000522B9C: 86039F01
	s_add_u32 s0, s0, s1                                       // 000000522BA0: 80000100
	s_addc_u32 s1, s5, s3                                      // 000000522BA4: 82010305
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000522BA8: BF870009
	s_lshl_b64 s[6:7], s[0:1], 10                              // 000000522BAC: 84868A00
	v_cmp_lt_i32_e32 vcc_lo, v1, v7                            // 000000522BB0: 7C820F01
	s_add_u32 s1, s20, s6                                      // 000000522BB4: 80010614
	s_addc_u32 s5, s21, s7                                     // 000000522BB8: 82050715
	s_and_saveexec_b32 s3, vcc_lo                              // 000000522BBC: BE83206A
	s_cbranch_execz 93                                         // 000000522BC0: BFA5005D <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb1ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0xa38>
	.long 0xd7010002                                           // 000000522BC4: D7010002
	v_cndmask_b32_e32 v0, v10, v129, vcc_lo                    // 000000522BC8: 0201030A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000522BCC: BF870121
	v_cndmask_b32_e64 v3, v2, 31, s0                           // 000000522BD0: D5010003 00013F02
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000522BD8: 3404029F
	.long 0xd44c0000                                           // 000000522BDC: D44C0000
	v_cndmask_b32_e32 v1, 31, v3, vcc_lo                       // 000000522BE0: 0202069F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000522BE4: BF870091
	v_cndmask_b32_e64 v5, 0xe1, 1, s0                          // 000000522BE8: D5010005 000102FF 000000E1
	v_dual_mov_b32 v4, 0 :: v_dual_add_nc_u32 v11, v5, v3      // 000000522BF4: CA200080 040A0705
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000522BFC: BF870114
	.long 0xd73c0005                                           // 000000522C00: D73C0005
	v_cndmask_b32_e32 v1, 10, v1, vcc_lo                       // 000000522C04: 0202028A
	.long 0xd73c0002                                           // 000000522C08: D73C0002
	v_cndmask_b32_e32 v1, 2, v3, vcc_lo                        // 000000522C0C: 02020682
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000522C10: BF870223
	v_lshlrev_b32_e32 v4, 24, v11                              // 000000522C14: 30081698
	v_bfe_i32 v12, v11, 7, 1                                   // 000000522C18: D611000C 02050F0B
	.long 0xd700000d                                           // 000000522C20: D700000D
	v_cndmask_b32_e32 v1, s1, v5, vcc_lo                       // 000000522C24: 02020A01
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000522C28: BF870211
	v_add_co_ci_u32_e64 v6, null, s5, v6, s0                   // 000000522C2C: D5207C06 00020C05
	v_ashrrev_i32_e32 v11, 22, v4                              // 000000522C34: 34160896
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000522C38: BF870093
	.long 0xd7000004                                           // 000000522C3C: D7000004
	v_cndmask_b32_e32 v1, v13, v2, vcc_lo                      // 000000522C40: 0202050D
	v_add_co_ci_u32_e64 v5, null, v6, v3, s0                   // 000000522C44: D5207C05 00020706
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000522C4C: BF870093
	.long 0xd700000b                                           // 000000522C50: D700000B
	v_cndmask_b32_e32 v1, v13, v11, vcc_lo                     // 000000522C54: 0202170D
	v_add_co_ci_u32_e64 v12, null, v6, v12, s0                 // 000000522C58: D5207C0C 00021906
	.long 0xd700000d                                           // 000000522C60: D700000D
	v_cndmask_b32_e32 v1, v13, v9, vcc_lo                      // 000000522C64: 0202130D
	s_delay_alu instid0(VALU_DEP_1)                            // 000000522C68: BF870001
	v_add_co_ci_u32_e64 v14, null, 0, v6, s0                   // 000000522C6C: D5207C0E 00020C80
	s_clause 0x17                                              // 000000522C74: BF850017
	global_load_b32 v2, v[4:5], off                            // 000000522C78: DC520000 027C0004
	global_load_b32 v56, v[4:5], off offset:128                // 000000522C80: DC520080 387C0004
	global_load_b32 v54, v[4:5], off offset:256                // 000000522C88: DC520100 367C0004
	global_load_b32 v50, v[4:5], off offset:384                // 000000522C90: DC520180 327C0004
	global_load_b32 v48, v[4:5], off offset:512                // 000000522C98: DC520200 307C0004
	global_load_b32 v45, v[4:5], off offset:640                // 000000522CA0: DC520280 2D7C0004
	global_load_b32 v42, v[4:5], off offset:768                // 000000522CA8: DC520300 2A7C0004
	global_load_b32 v21, v[4:5], off offset:896                // 000000522CB0: DC520380 157C0004
	global_load_b32 v3, v[11:12], off                          // 000000522CB8: DC520000 037C000B
	global_load_b32 v58, v[11:12], off offset:128              // 000000522CC0: DC520080 3A7C000B
	global_load_b32 v55, v[11:12], off offset:256              // 000000522CC8: DC520100 377C000B
	global_load_b32 v52, v[11:12], off offset:384              // 000000522CD0: DC520180 347C000B
	global_load_b32 v49, v[11:12], off offset:512              // 000000522CD8: DC520200 317C000B
	global_load_b32 v46, v[11:12], off offset:640              // 000000522CE0: DC520280 2E7C000B
	global_load_b32 v43, v[11:12], off offset:768              // 000000522CE8: DC520300 2B7C000B
	global_load_b32 v23, v[11:12], off offset:896              // 000000522CF0: DC520380 177C000B
	global_load_b32 v59, v[13:14], off                         // 000000522CF8: DC520000 3B7C000D
	global_load_b32 v57, v[13:14], off offset:128              // 000000522D00: DC520080 397C000D
	global_load_b32 v53, v[13:14], off offset:256              // 000000522D08: DC520100 357C000D
	global_load_b32 v51, v[13:14], off offset:384              // 000000522D10: DC520180 337C000D
	global_load_b32 v47, v[13:14], off offset:512              // 000000522D18: DC520200 2F7C000D
	global_load_b32 v44, v[13:14], off offset:640              // 000000522D20: DC520280 2C7C000D
	global_load_b32 v26, v[13:14], off offset:768              // 000000522D28: DC520300 1A7C000D
	global_load_b32 v19, v[13:14], off offset:896              // 000000522D30: DC520380 137C000D
	s_or_b32 exec_lo, exec_lo, s3                              // 000000522D38: 8C7E037E
	v_dual_mov_b32 v11, 0 :: v_dual_mov_b32 v12, 0             // 000000522D3C: CA100080 0B0C0080
	v_dual_mov_b32 v13, 0 :: v_dual_mov_b32 v14, 0             // 000000522D44: CA100080 0D0E0080
	v_dual_mov_b32 v15, 0 :: v_dual_mov_b32 v16, 0             // 000000522D4C: CA100080 0F100080
	v_dual_mov_b32 v17, 0 :: v_dual_mov_b32 v18, 0             // 000000522D54: CA100080 11120080
	s_ashr_i32 s3, s2, 31                                      // 000000522D5C: 86039F02
	s_and_saveexec_b32 s0, vcc_lo                              // 000000522D60: BE80206A
	s_cbranch_execz 997                                        // 000000522D64: BFA503E5 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb1ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x19fc>
	v_dual_mov_b32 v11, 0 :: v_dual_add_nc_u32 v4, -1, v0      // 000000522D68: CA200080 0B0400C1
	v_dual_mov_b32 v13, 0 :: v_dual_and_b32 v6, 16, v0         // 000000522D70: CA240080 0D060090
	v_dual_mov_b32 v12, 0 :: v_dual_add_nc_u32 v5, 1, v1       // 000000522D78: CA200080 0C040281
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000522D80: BF870243
	v_dual_mov_b32 v15, 0 :: v_dual_and_b32 v4, 31, v4         // 000000522D84: CA240080 0F04089F
	v_sub_nc_u32_e32 v20, 0, v7                                // 000000522D8C: 4C280E80
	v_dual_mov_b32 v17, 0 :: v_dual_lshlrev_b32 v22, 2, v10    // 000000522D90: CA220080 11161482
	v_lshl_or_b32 v24, v1, 5, v6                               // 000000522D98: D6560018 04190B01
	v_dual_mov_b32 v14, 0 :: v_dual_lshlrev_b32 v25, 2, v4     // 000000522DA0: CA220080 0E180882
	v_mov_b32_e32 v16, 0                                       // 000000522DA8: 7E200280
	v_mov_b32_e32 v18, 0                                       // 000000522DAC: 7E240280
	s_mov_b32 s6, 0                                            // 000000522DB0: BE860080
	s_mov_b32 s7, 0xdcd12d                                     // 000000522DB4: BE8700FF 00DCD12D
	s_movk_i32 s8, 0x83                                        // 000000522DBC: B0080083
	s_movk_i32 s9, 0x1eee                                      // 000000522DC0: B0091EEE
	s_branch 916                                               // 000000522DC4: BFA00394 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb1ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1918>
	s_or_b32 exec_lo, exec_lo, s10                             // 000000522DC8: 8C7E0A7E
	s_waitcnt vmcnt(15)                                        // 000000522DCC: BF893FF7
	v_alignbit_b32 v60, v2, v3, 16                             // 000000522DD0: D616003C 02420702
	s_waitcnt vmcnt(7)                                         // 000000522DD8: BF891FF7
	v_bfe_u32 v61, v59, 12, 16                                 // 000000522DDC: D610003D 0241193B
	ds_load_b128 v[1:4], v24                                   // 000000522DE4: DBFC0000 01000018
	v_alignbit_b32 v56, v56, v58, 16                           // 000000522DEC: D6160038 02427538
	v_bfe_u32 v62, v59, 8, 16                                  // 000000522DF4: D610003E 0241113B
	v_bfe_u32 v63, v60, 12, 16                                 // 000000522DFC: D610003F 0241193C
	v_bfe_u32 v65, v60, 8, 16                                  // 000000522E04: D6100041 0241113C
	v_mul_u32_u24_e32 v67, s7, v63                             // 000000522E0C: 16867E07
	v_mul_u32_u24_e32 v63, s8, v63                             // 000000522E10: 167E7E08
	v_bfe_u32 v66, v60, 4, 16                                  // 000000522E14: D6100042 0241093C
	v_lshl_add_u32 v63, v63, 24, v67                           // 000000522E1C: D646003F 050D313F
	v_mul_u32_u24_e32 v67, s7, v65                             // 000000522E24: 16868207
	v_mul_u32_u24_e32 v65, s8, v65                             // 000000522E28: 16828208
	v_lshl_add_u32 v65, v65, 24, v67                           // 000000522E2C: D6460041 050D3141
	v_mul_u32_u24_e32 v67, s7, v66                             // 000000522E34: 16868407
	v_mul_u32_u24_e32 v66, s8, v66                             // 000000522E38: 16848408
	v_lshl_add_u32 v66, v66, 24, v67                           // 000000522E3C: D6460042 050D3142
	v_and_b32_e32 v60, 0xffff, v60                             // 000000522E44: 367878FF 0000FFFF
	v_mul_u32_u24_e32 v67, s7, v61                             // 000000522E4C: 16867A07
	v_mul_u32_u24_e32 v61, s8, v61                             // 000000522E50: 167A7A08
	v_lshl_add_u32 v61, v61, 24, v67                           // 000000522E54: D646003D 050D313D
	v_mul_u32_u24_e32 v67, s7, v60                             // 000000522E5C: 16867807
	v_mul_u32_u24_e32 v60, s8, v60                             // 000000522E60: 16787808
	v_sad_u8 v66, v66, 0, 0x6400                               // 000000522E64: D6220042 03FD0142 00006400
	v_lshl_add_u32 v60, v60, 24, v67                           // 000000522E70: D646003C 050D313C
	v_sad_u8 v63, v63, 0, 0x6400                               // 000000522E78: D622003F 03FD013F 00006400
	v_sad_u8 v65, v65, 0, 0x6400                               // 000000522E84: D6220041 03FD0141 00006400
	v_mul_u32_u24_e32 v67, s7, v62                             // 000000522E90: 16867C07
	v_and_b32_e32 v66, 0xffff, v66                             // 000000522E94: 368484FF 0000FFFF
	v_sad_u8 v60, v60, 0, 0x6400                               // 000000522E9C: D622003C 03FD013C 00006400
	v_mul_u32_u24_e32 v62, s8, v62                             // 000000522EA8: 167C7C08
	v_bfe_u32 v64, v59, 4, 16                                  // 000000522EAC: D6100040 0241093B
	v_sad_u8 v61, v61, 0, 0x6400                               // 000000522EB4: D622003D 03FD013D 00006400
	v_lshl_add_u32 v62, v62, 24, v67                           // 000000522EC0: D646003E 050D313E
	v_lshl_or_b32 v60, v60, 16, v66                            // 000000522EC8: D656003C 0509213C
	v_mul_u32_u24_e32 v67, s7, v64                             // 000000522ED0: 16868007
	v_mul_u32_u24_e32 v64, s8, v64                             // 000000522ED4: 16808008
	v_lshl_add_u32 v64, v64, 24, v67                           // 000000522ED8: D6460040 050D3140
	v_sad_u8 v62, v62, 0, 0x6400                               // 000000522EE0: D622003E 03FD013E 00006400
	v_pk_fma_f16 v58, v60, s9, 0xc931 op_sel_hi:[1,0,0]        // 000000522EEC: CC0E003A 0BFC133C 0000C931
	v_and_b32_e32 v63, 0xffff, v63                             // 000000522EF8: 367E7EFF 0000FFFF
	s_waitcnt vmcnt(6)                                         // 000000522F00: BF891BF7
	v_bfe_u32 v66, v57, 4, 16                                  // 000000522F04: D6100042 02410939
	v_sad_u8 v64, v64, 0, 0x6400                               // 000000522F0C: D6220040 03FD0140 00006400
	v_alignbit_b32 v54, v54, v55, 16                           // 000000522F18: D6160036 02426F36
	v_alignbit_b32 v50, v50, v52, 16                           // 000000522F20: D6160032 02426932
	v_lshl_or_b32 v63, v65, 16, v63                            // 000000522F28: D656003F 04FD2141
	v_bfe_u32 v65, v57, 8, 16                                  // 000000522F30: D6100041 02411139
	v_alignbit_b32 v48, v48, v49, 16                           // 000000522F38: D6160030 02426330
	v_alignbit_b32 v45, v45, v46, 16                           // 000000522F40: D616002D 02425D2D
	v_alignbit_b32 v42, v42, v43, 16                           // 000000522F48: D616002A 0242572A
	v_pk_fma_f16 v63, v63, s9, 0xc931 op_sel_hi:[1,0,0]        // 000000522F50: CC0E003F 0BFC133F 0000C931
	v_and_b32_e32 v59, 0xffff, v59                             // 000000522F5C: 367676FF 0000FFFF
	v_alignbit_b32 v21, v21, v23, 16                           // 000000522F64: D6160015 02422F15
	v_add_nc_u32_e32 v5, 1, v5                                 // 000000522F6C: 4A0A0A81
	v_add_nc_u32_e32 v24, 32, v24                              // 000000522F70: 4A3030A0
	s_waitcnt lgkmcnt(0)                                       // 000000522F74: BF89FC07
	v_dot2acc_f32_f16 v18, v63, v1                             // 000000522F78: 0424033F
	v_mul_u32_u24_e32 v67, s7, v59                             // 000000522F7C: 16867607
	v_mul_u32_u24_e32 v59, s8, v59                             // 000000522F80: 16767608
	v_lshl_add_u32 v59, v59, 24, v67                           // 000000522F84: D646003B 050D313B
	v_bfe_u32 v63, v56, 4, 16                                  // 000000522F8C: D610003F 02410938
	v_dual_dot2acc_f32_f16 v18, v58, v2 :: v_dual_and_b32 v61, 0xffff, v61// 000000522F94: CB24053A 123C7AFF 0000FFFF
	v_bfe_u32 v58, v54, 12, 16                                 // 000000522FA0: D610003A 02411936
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000522FA8: BF870194
	v_sad_u8 v59, v59, 0, 0x6400                               // 000000522FAC: D622003B 03FD013B 00006400
	v_lshl_or_b32 v61, v62, 16, v61                            // 000000522FB8: D656003D 04F5213E
	v_and_b32_e32 v62, 0xffff, v64                             // 000000522FC0: 367C80FF 0000FFFF
	v_bfe_u32 v64, v57, 12, 16                                 // 000000522FC8: D6100040 02411939
	v_and_b32_e32 v57, 0xffff, v57                             // 000000522FD0: 367272FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000522FD8: BF8700C4
	v_pk_fma_f16 v60, v61, s9, 0xc931 op_sel_hi:[1,0,0]        // 000000522FDC: CC0E003C 0BFC133D 0000C931
	v_bfe_u32 v61, v56, 12, 16                                 // 000000522FE8: D610003D 02411938
	v_mul_u32_u24_e32 v67, s7, v61                             // 000000522FF0: 16867A07
	v_mul_u32_u24_e32 v61, s8, v61                             // 000000522FF4: 167A7A08
	v_lshl_add_u32 v61, v61, 24, v67                           // 000000522FF8: D646003D 050D313D
	v_lshl_or_b32 v59, v59, 16, v62                            // 000000523000: D656003B 04F9213B
	v_bfe_u32 v62, v56, 8, 16                                  // 000000523008: D610003E 02411138
	v_mul_u32_u24_e32 v67, s7, v63                             // 000000523010: 16867E07
	v_mul_u32_u24_e32 v63, s8, v63                             // 000000523014: 167E7E08
	v_lshl_add_u32 v63, v63, 24, v67                           // 000000523018: D646003F 050D313F
	v_mul_u32_u24_e32 v67, s7, v62                             // 000000523020: 16867C07
	v_mul_u32_u24_e32 v62, s8, v62                             // 000000523024: 167C7C08
	v_sad_u8 v61, v61, 0, 0x6400                               // 000000523028: D622003D 03FD013D 00006400
	v_lshl_add_u32 v62, v62, 24, v67                           // 000000523034: D646003E 050D313E
	v_and_b32_e32 v56, 0xffff, v56                             // 00000052303C: 367070FF 0000FFFF
	v_mul_u32_u24_e32 v67, s7, v56                             // 000000523044: 16867007
	v_mul_u32_u24_e32 v56, s8, v56                             // 000000523048: 16707008
	s_delay_alu instid0(VALU_DEP_1)                            // 00000052304C: BF870001
	v_lshl_add_u32 v56, v56, 24, v67                           // 000000523050: D6460038 050D3138
	v_mul_u32_u24_e32 v67, s7, v64                             // 000000523058: 16868007
	v_mul_u32_u24_e32 v64, s8, v64                             // 00000052305C: 16808008
	v_sad_u8 v63, v63, 0, 0x6400                               // 000000523060: D622003F 03FD013F 00006400
	v_lshl_add_u32 v64, v64, 24, v67                           // 00000052306C: D6460040 050D3140
	v_and_b32_e32 v61, 0xffff, v61                             // 000000523074: 367A7AFF 0000FFFF
	v_sad_u8 v62, v62, 0, 0x6400                               // 00000052307C: D622003E 03FD013E 00006400
	v_mul_u32_u24_e32 v67, s7, v65                             // 000000523088: 16868207
	v_mul_u32_u24_e32 v65, s8, v65                             // 00000052308C: 16828208
	v_and_b32_e32 v63, 0xffff, v63                             // 000000523090: 367E7EFF 0000FFFF
	v_sad_u8 v56, v56, 0, 0x6400                               // 000000523098: D6220038 03FD0138 00006400
	v_sad_u8 v64, v64, 0, 0x6400                               // 0000005230A4: D6220040 03FD0140 00006400
	v_lshl_add_u32 v65, v65, 24, v67                           // 0000005230B0: D6460041 050D3141
	v_lshl_or_b32 v61, v62, 16, v61                            // 0000005230B8: D656003D 04F5213E
	v_mul_u32_u24_e32 v67, s7, v66                             // 0000005230C0: 16868407
	v_mul_u32_u24_e32 v66, s8, v66                             // 0000005230C4: 16848408
	v_lshl_add_u32 v66, v66, 24, v67                           // 0000005230C8: D6460042 050D3142
	v_lshl_or_b32 v56, v56, 16, v63                            // 0000005230D0: D6560038 04FD2138
	v_and_b32_e32 v62, 0xffff, v64                             // 0000005230D8: 367C80FF 0000FFFF
	v_sad_u8 v63, v65, 0, 0x6400                               // 0000005230E0: D622003F 03FD0141 00006400
	v_pk_fma_f16 v61, v61, s9, 0xc931 op_sel_hi:[1,0,0]        // 0000005230EC: CC0E003D 0BFC133D 0000C931
	v_mul_u32_u24_e32 v65, s7, v57                             // 0000005230F8: 16827207
	v_mul_u32_u24_e32 v57, s8, v57                             // 0000005230FC: 16727208
	v_sad_u8 v64, v66, 0, 0x6400                               // 000000523100: D6220040 03FD0142 00006400
	v_lshl_add_u32 v57, v57, 24, v65                           // 00000052310C: D6460039 05053139
	v_pk_fma_f16 v56, v56, s9, 0xc931 op_sel_hi:[1,0,0]        // 000000523114: CC0E0038 0BFC1338 0000C931
	v_lshl_or_b32 v62, v63, 16, v62                            // 000000523120: D656003E 04F9213F
	v_dot2acc_f32_f16 v17, v61, v1                             // 000000523128: 0422033D
	v_and_b32_e32 v63, 0xffff, v64                             // 00000052312C: 367E80FF 0000FFFF
	v_sad_u8 v57, v57, 0, 0x6400                               // 000000523134: D6220039 03FD0139 00006400
	v_dot2acc_f32_f16 v18, v60, v3                             // 000000523140: 0424073C
	v_pk_fma_f16 v55, v62, s9, 0xc931 op_sel_hi:[1,0,0]        // 000000523144: CC0E0037 0BFC133E 0000C931
	v_dot2acc_f32_f16 v17, v56, v2                             // 000000523150: 04220538
	v_pk_fma_f16 v56, v59, s9, 0xc931 op_sel_hi:[1,0,0]        // 000000523154: CC0E0038 0BFC133B 0000C931
	v_mul_u32_u24_e32 v59, s7, v58                             // 000000523160: 16767407
	v_mul_u32_u24_e32 v58, s8, v58                             // 000000523164: 16747408
	v_lshl_add_u32 v58, v58, 24, v59                           // 000000523168: D646003A 04ED313A
	v_lshl_or_b32 v57, v57, 16, v63                            // 000000523170: D6560039 04FD2139
	v_dot2acc_f32_f16 v17, v55, v3                             // 000000523178: 04220737
	v_bfe_u32 v55, v54, 8, 16                                  // 00000052317C: D6100037 02411136
	v_mul_u32_u24_e32 v63, s7, v55                             // 000000523184: 167E6E07
	v_mul_u32_u24_e32 v55, s8, v55                             // 000000523188: 166E6E08
	v_sad_u8 v58, v58, 0, 0x6400                               // 00000052318C: D622003A 03FD013A 00006400
	s_delay_alu instid0(VALU_DEP_2)                            // 000000523198: BF870002
	v_lshl_add_u32 v55, v55, 24, v63                           // 00000052319C: D6460037 04FD3137
	v_bfe_u32 v59, v54, 4, 16                                  // 0000005231A4: D610003B 02410936
	v_pk_fma_f16 v57, v57, s9, 0xc931 op_sel_hi:[1,0,0]        // 0000005231AC: CC0E0039 0BFC1339 0000C931
	s_waitcnt vmcnt(5)                                         // 0000005231B8: BF8917F7
	v_bfe_u32 v60, v53, 12, 16                                 // 0000005231BC: D610003C 02411935
	v_mul_u32_u24_e32 v63, s7, v59                             // 0000005231C4: 167E7607
	v_mul_u32_u24_e32 v59, s8, v59                             // 0000005231C8: 16767608
	v_lshl_add_u32 v59, v59, 24, v63                           // 0000005231CC: D646003B 04FD313B
	v_mul_u32_u24_e32 v63, s7, v60                             // 0000005231D4: 167E7807
	v_mul_u32_u24_e32 v60, s8, v60                             // 0000005231D8: 16787808
	v_lshl_add_u32 v60, v60, 24, v63                           // 0000005231DC: D646003C 04FD313C
	v_and_b32_e32 v58, 0xffff, v58                             // 0000005231E4: 367474FF 0000FFFF
	v_sad_u8 v55, v55, 0, 0x6400                               // 0000005231EC: D6220037 03FD0137 00006400
	v_dual_dot2acc_f32_f16 v17, v57, v4 :: v_dual_and_b32 v54, 0xffff, v54// 0000005231F8: CB240939 11366CFF 0000FFFF
	v_bfe_u32 v61, v53, 8, 16                                  // 000000523204: D610003D 02411135
	v_mul_u32_u24_e32 v63, s7, v54                             // 00000052320C: 167E6C07
	v_mul_u32_u24_e32 v54, s8, v54                             // 000000523210: 166C6C08
	s_delay_alu instid0(VALU_DEP_2)                            // 000000523214: BF870002
	v_lshl_add_u32 v54, v54, 24, v63                           // 000000523218: D6460036 04FD3136
	v_mul_u32_u24_e32 v63, s7, v61                             // 000000523220: 167E7A07
	v_mul_u32_u24_e32 v61, s8, v61                             // 000000523224: 167A7A08
	v_sad_u8 v59, v59, 0, 0x6400                               // 000000523228: D622003B 03FD013B 00006400
	v_sad_u8 v60, v60, 0, 0x6400                               // 000000523234: D622003C 03FD013C 00006400
	v_lshl_add_u32 v61, v61, 24, v63                           // 000000523240: D646003D 04FD313D
	v_lshl_or_b32 v55, v55, 16, v58                            // 000000523248: D6560037 04E92137
	v_bfe_u32 v62, v53, 4, 16                                  // 000000523250: D610003E 02410935
	v_and_b32_e32 v58, 0xffff, v59                             // 000000523258: 367476FF 0000FFFF
	v_and_b32_e32 v59, 0xffff, v60                             // 000000523260: 367678FF 0000FFFF
	v_sad_u8 v60, v61, 0, 0x6400                               // 000000523268: D622003C 03FD013D 00006400
	v_mul_u32_u24_e32 v61, s7, v62                             // 000000523274: 167A7C07
	v_sad_u8 v54, v54, 0, 0x6400                               // 000000523278: D6220036 03FD0136 00006400
	v_mul_u32_u24_e32 v62, s8, v62                             // 000000523284: 167C7C08
	v_lshl_add_u32 v61, v62, 24, v61                           // 000000523288: D646003D 04F5313E
	v_pk_fma_f16 v55, v55, s9, 0xc931 op_sel_hi:[1,0,0]        // 000000523290: CC0E0037 0BFC1337 0000C931
	v_dual_dot2acc_f32_f16 v18, v56, v4 :: v_dual_and_b32 v53, 0xffff, v53// 00000052329C: CB240938 12346AFF 0000FFFF
	v_lshl_or_b32 v54, v54, 16, v58                            // 0000005232A8: D6560036 04E92136
	v_lshl_or_b32 v58, v60, 16, v59                            // 0000005232B0: D656003A 04ED213C
	v_sad_u8 v59, v61, 0, 0x6400                               // 0000005232B8: D622003B 03FD013D 00006400
	v_dot2acc_f32_f16 v16, v55, v1                             // 0000005232C4: 04200337
	v_bfe_u32 v55, v50, 12, 16                                 // 0000005232C8: D6100037 02411932
	v_mul_u32_u24_e32 v64, s7, v55                             // 0000005232D0: 16806E07
	v_mul_u32_u24_e32 v55, s8, v55                             // 0000005232D4: 166E6E08
	s_delay_alu instid0(VALU_DEP_1)                            // 0000005232D8: BF870001
	v_lshl_add_u32 v55, v55, 24, v64                           // 0000005232DC: D6460037 05013137
	v_mul_u32_u24_e32 v60, s7, v53                             // 0000005232E4: 16786A07
	v_mul_u32_u24_e32 v53, s8, v53                             // 0000005232E8: 166A6A08
	v_lshl_add_u32 v53, v53, 24, v60                           // 0000005232EC: D6460035 04F13135
	v_bfe_u32 v60, v50, 4, 16                                  // 0000005232F4: D610003C 02410932
	v_pk_fma_f16 v52, v58, s9, 0xc931 op_sel_hi:[1,0,0]        // 0000005232FC: CC0E0034 0BFC133A 0000C931
	v_and_b32_e32 v58, 0xffff, v59                             // 000000523308: 367476FF 0000FFFF
	v_bfe_u32 v59, v50, 8, 16                                  // 000000523310: D610003B 02411132
	v_mul_u32_u24_e32 v64, s7, v60                             // 000000523318: 16807807
	v_mul_u32_u24_e32 v60, s8, v60                             // 00000052331C: 16787808
	v_lshl_add_u32 v60, v60, 24, v64                           // 000000523320: D646003C 0501313C
	v_mul_u32_u24_e32 v64, s7, v59                             // 000000523328: 16807607
	v_mul_u32_u24_e32 v59, s8, v59                             // 00000052332C: 16767608
	v_sad_u8 v55, v55, 0, 0x6400                               // 000000523330: D6220037 03FD0137 00006400
	v_lshl_add_u32 v59, v59, 24, v64                           // 00000052333C: D646003B 0501313B
	v_and_b32_e32 v50, 0xffff, v50                             // 000000523344: 366464FF 0000FFFF
	v_mul_u32_u24_e32 v64, s7, v50                             // 00000052334C: 16806407
	v_mul_u32_u24_e32 v50, s8, v50                             // 000000523350: 16646408
	v_sad_u8 v60, v60, 0, 0x6400                               // 000000523354: D622003C 03FD013C 00006400
	s_delay_alu instid0(VALU_DEP_2)                            // 000000523360: BF870002
	v_lshl_add_u32 v50, v50, 24, v64                           // 000000523364: D6460032 05013132
	v_and_b32_e32 v55, 0xffff, v55                             // 00000052336C: 366E6EFF 0000FFFF
	v_sad_u8 v59, v59, 0, 0x6400                               // 000000523374: D622003B 03FD013B 00006400
	v_pk_fma_f16 v54, v54, s9, 0xc931 op_sel_hi:[1,0,0]        // 000000523380: CC0E0036 0BFC1336 0000C931
	v_and_b32_e32 v60, 0xffff, v60                             // 00000052338C: 367878FF 0000FFFF
	v_sad_u8 v50, v50, 0, 0x6400                               // 000000523394: D6220032 03FD0132 00006400
	v_sad_u8 v53, v53, 0, 0x6400                               // 0000005233A0: D6220035 03FD0135 00006400
	v_lshl_or_b32 v55, v59, 16, v55                            // 0000005233AC: D6560037 04DD213B
	s_waitcnt vmcnt(4)                                         // 0000005233B4: BF8913F7
	v_bfe_u32 v61, v51, 12, 16                                 // 0000005233B8: D610003D 02411933
	v_mul_u32_u24_e32 v64, s7, v61                             // 0000005233C0: 16807A07
	v_lshl_or_b32 v50, v50, 16, v60                            // 0000005233C4: D6560032 04F12132
	v_mul_u32_u24_e32 v61, s8, v61                             // 0000005233CC: 167A7A08
	v_pk_fma_f16 v55, v55, s9, 0xc931 op_sel_hi:[1,0,0]        // 0000005233D0: CC0E0037 0BFC1337 0000C931
	v_lshl_or_b32 v53, v53, 16, v58                            // 0000005233DC: D6560035 04E92135
	v_dot2acc_f32_f16 v16, v54, v2                             // 0000005233E4: 04200536
	v_pk_fma_f16 v50, v50, s9, 0xc931 op_sel_hi:[1,0,0]        // 0000005233E8: CC0E0032 0BFC1332 0000C931
	v_lshl_add_u32 v61, v61, 24, v64                           // 0000005233F4: D646003D 0501313D
	v_dot2acc_f32_f16 v15, v55, v1                             // 0000005233FC: 041E0337
	v_bfe_u32 v62, v51, 8, 16                                  // 000000523400: D610003E 02411133
	v_bfe_u32 v63, v51, 4, 16                                  // 000000523408: D610003F 02410933
	v_mul_u32_u24_e32 v64, s7, v62                             // 000000523410: 16807C07
	v_mul_u32_u24_e32 v62, s8, v62                             // 000000523414: 167C7C08
	s_delay_alu instid0(VALU_DEP_2)                            // 000000523418: BF870002
	v_lshl_add_u32 v62, v62, 24, v64                           // 00000052341C: D646003E 0501313E
	v_mul_u32_u24_e32 v64, s7, v63                             // 000000523424: 16807E07
	v_mul_u32_u24_e32 v63, s8, v63                             // 000000523428: 167E7E08
	v_dot2acc_f32_f16 v15, v50, v2                             // 00000052342C: 041E0532
	v_pk_fma_f16 v50, v53, s9, 0xc931 op_sel_hi:[1,0,0]        // 000000523430: CC0E0032 0BFC1335 0000C931
	v_dot2acc_f32_f16 v16, v52, v3                             // 00000052343C: 04200734
	v_sad_u8 v61, v61, 0, 0x6400                               // 000000523440: D622003D 03FD013D 00006400
	v_lshl_add_u32 v63, v63, 24, v64                           // 00000052344C: D646003F 0501313F
	v_and_b32_e32 v51, 0xffff, v51                             // 000000523454: 366666FF 0000FFFF
	v_sad_u8 v60, v62, 0, 0x6400                               // 00000052345C: D622003C 03FD013E 00006400
	v_dot2acc_f32_f16 v16, v50, v4                             // 000000523468: 04200932
	v_mul_u32_u24_e32 v62, s7, v51                             // 00000052346C: 167C6607
	v_mul_u32_u24_e32 v51, s8, v51                             // 000000523470: 16666608
	v_and_b32_e32 v59, 0xffff, v61                             // 000000523474: 36767AFF 0000FFFF
	v_sad_u8 v61, v63, 0, 0x6400                               // 00000052347C: D622003D 03FD013F 00006400
	v_lshl_add_u32 v51, v51, 24, v62                           // 000000523488: D6460033 04F93133
	v_bfe_u32 v50, v48, 4, 16                                  // 000000523490: D6100032 02410930
	s_waitcnt vmcnt(3)                                         // 000000523498: BF890FF7
	v_bfe_u32 v53, v47, 8, 16                                  // 00000052349C: D6100035 0241112F
	v_lshl_or_b32 v59, v60, 16, v59                            // 0000005234A4: D656003B 04ED213C
	v_and_b32_e32 v60, 0xffff, v61                             // 0000005234AC: 36787AFF 0000FFFF
	v_sad_u8 v51, v51, 0, 0x6400                               // 0000005234B4: D6220033 03FD0133 00006400
	v_mov_b32_e32 v58, v40                                     // 0000005234C0: 7E740328
	v_mov_b32_e32 v57, v40                                     // 0000005234C4: 7E720328
	v_pk_fma_f16 v54, v59, s9, 0xc931 op_sel_hi:[1,0,0]        // 0000005234C8: CC0E0036 0BFC133B 0000C931
	v_mov_b32_e32 v59, v41                                     // 0000005234D4: 7E760329
	v_lshl_or_b32 v51, v51, 16, v60                            // 0000005234D8: D6560033 04F12133
	v_mov_b32_e32 v56, v34                                     // 0000005234E0: 7E700322
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000005234E4: BF870224
	v_dot2acc_f32_f16 v15, v54, v3                             // 0000005234E8: 041E0736
	v_bfe_u32 v54, v47, 4, 16                                  // 0000005234EC: D6100036 0241092F
	v_pk_fma_f16 v49, v51, s9, 0xc931 op_sel_hi:[1,0,0]        // 0000005234F4: CC0E0031 0BFC1333 0000C931
	v_bfe_u32 v51, v48, 12, 16                                 // 000000523500: D6100033 02411930
	v_mul_u32_u24_e32 v52, s7, v51                             // 000000523508: 16686607
	v_mul_u32_u24_e32 v51, s8, v51                             // 00000052350C: 16666608
	s_delay_alu instid0(VALU_DEP_1)                            // 000000523510: BF870001
	v_lshl_add_u32 v51, v51, 24, v52                           // 000000523514: D6460033 04D13133
	v_dot2acc_f32_f16 v15, v49, v4                             // 00000052351C: 041E0931
	v_bfe_u32 v49, v48, 8, 16                                  // 000000523520: D6100031 02411130
	v_mul_u32_u24_e32 v55, s7, v49                             // 000000523528: 166E6207
	v_mul_u32_u24_e32 v49, s8, v49                             // 00000052352C: 16626208
	v_sad_u8 v51, v51, 0, 0x6400                               // 000000523530: D6220033 03FD0133 00006400
	s_delay_alu instid0(VALU_DEP_2)                            // 00000052353C: BF870002
	v_lshl_add_u32 v49, v49, 24, v55                           // 000000523540: D6460031 04DD3131
	v_bfe_u32 v52, v47, 12, 16                                 // 000000523548: D6100034 0241192F
	v_mul_u32_u24_e32 v55, s7, v50                             // 000000523550: 166E6407
	v_mul_u32_u24_e32 v50, s8, v50                             // 000000523554: 16646408
	v_lshl_add_u32 v50, v50, 24, v55                           // 000000523558: D6460032 04DD3132
	v_mul_u32_u24_e32 v55, s7, v52                             // 000000523560: 166E6807
	v_mul_u32_u24_e32 v52, s8, v52                             // 000000523564: 16686808
	v_and_b32_e32 v48, 0xffff, v48                             // 000000523568: 366060FF 0000FFFF
	v_and_b32_e32 v51, 0xffff, v51                             // 000000523570: 366666FF 0000FFFF
	v_sad_u8 v49, v49, 0, 0x6400                               // 000000523578: D6220031 03FD0131 00006400
	v_lshl_add_u32 v52, v52, 24, v55                           // 000000523584: D6460034 04DD3134
	v_mul_u32_u24_e32 v55, s7, v48                             // 00000052358C: 166E6007
	v_mul_u32_u24_e32 v48, s8, v48                             // 000000523590: 16606008
	v_lshl_add_u32 v48, v48, 24, v55                           // 000000523594: D6460030 04DD3130
	v_mul_u32_u24_e32 v55, s7, v53                             // 00000052359C: 166E6A07
	v_mul_u32_u24_e32 v53, s8, v53                             // 0000005235A0: 166A6A08
	v_lshl_add_u32 v53, v53, 24, v55                           // 0000005235A4: D6460035 04DD3135
	v_mul_u32_u24_e32 v55, s7, v54                             // 0000005235AC: 166E6C07
	v_mul_u32_u24_e32 v54, s8, v54                             // 0000005235B0: 166C6C08
	v_lshl_add_u32 v54, v54, 24, v55                           // 0000005235B4: D6460036 04DD3136
	v_sad_u8 v50, v50, 0, 0x6400                               // 0000005235BC: D6220032 03FD0132 00006400
	v_sad_u8 v52, v52, 0, 0x6400                               // 0000005235C8: D6220034 03FD0134 00006400
	v_lshl_or_b32 v49, v49, 16, v51                            // 0000005235D4: D6560031 04CD2131
	v_and_b32_e32 v47, 0xffff, v47                             // 0000005235DC: 365E5EFF 0000FFFF
	v_mul_u32_u24_e32 v55, s7, v47                             // 0000005235E4: 166E5E07
	v_mul_u32_u24_e32 v47, s8, v47                             // 0000005235E8: 165E5E08
	v_sad_u8 v54, v54, 0, 0x6400                               // 0000005235EC: D6220036 03FD0136 00006400
	s_delay_alu instid0(VALU_DEP_2)                            // 0000005235F8: BF870002
	v_lshl_add_u32 v47, v47, 24, v55                           // 0000005235FC: D646002F 04DD312F
	v_and_b32_e32 v50, 0xffff, v50                             // 000000523604: 366464FF 0000FFFF
	v_sad_u8 v48, v48, 0, 0x6400                               // 00000052360C: D6220030 03FD0130 00006400
	v_and_b32_e32 v52, 0xffff, v52                             // 000000523618: 366868FF 0000FFFF
	v_sad_u8 v53, v53, 0, 0x6400                               // 000000523620: D6220035 03FD0135 00006400
	v_pk_fma_f16 v49, v49, s9, 0xc931 op_sel_hi:[1,0,0]        // 00000052362C: CC0E0031 0BFC1331 0000C931
	v_and_b32_e32 v51, 0xffff, v54                             // 000000523638: 36666CFF 0000FFFF
	v_sad_u8 v47, v47, 0, 0x6400                               // 000000523640: D622002F 03FD012F 00006400
	v_lshl_or_b32 v48, v48, 16, v50                            // 00000052364C: D6560030 04C92130
	v_lshl_or_b32 v50, v53, 16, v52                            // 000000523654: D6560032 04D12135
	v_dot2acc_f32_f16 v14, v49, v1                             // 00000052365C: 041C0331
	v_bfe_u32 v49, v45, 12, 16                                 // 000000523660: D6100031 0241192D
	v_mul_u32_u24_e32 v55, s7, v49                             // 000000523668: 166E6207
	v_mul_u32_u24_e32 v49, s8, v49                             // 00000052366C: 16626208
	s_delay_alu instid0(VALU_DEP_1)                            // 000000523670: BF870001
	v_lshl_add_u32 v49, v49, 24, v55                           // 000000523674: D6460031 04DD3131
	v_lshl_or_b32 v47, v47, 16, v51                            // 00000052367C: D656002F 04CD212F
	v_bfe_u32 v51, v45, 4, 16                                  // 000000523684: D6100033 0241092D
	v_pk_fma_f16 v46, v48, s9, 0xc931 op_sel_hi:[1,0,0]        // 00000052368C: CC0E002E 0BFC1330 0000C931
	v_pk_fma_f16 v48, v50, s9, 0xc931 op_sel_hi:[1,0,0]        // 000000523698: CC0E0030 0BFC1332 0000C931
	v_bfe_u32 v50, v45, 8, 16                                  // 0000005236A4: D6100032 0241112D
	v_mul_u32_u24_e32 v55, s7, v51                             // 0000005236AC: 166E6607
	v_mul_u32_u24_e32 v51, s8, v51                             // 0000005236B0: 16666608
	v_lshl_add_u32 v51, v51, 24, v55                           // 0000005236B4: D6460033 04DD3133
	v_mul_u32_u24_e32 v55, s7, v50                             // 0000005236BC: 166E6407
	v_mul_u32_u24_e32 v50, s8, v50                             // 0000005236C0: 16646408
	v_sad_u8 v49, v49, 0, 0x6400                               // 0000005236C4: D6220031 03FD0131 00006400
	v_lshl_add_u32 v50, v50, 24, v55                           // 0000005236D0: D6460032 04DD3132
	v_and_b32_e32 v45, 0xffff, v45                             // 0000005236D8: 365A5AFF 0000FFFF
	s_waitcnt vmcnt(2)                                         // 0000005236E0: BF890BF7
	v_bfe_u32 v52, v44, 12, 16                                 // 0000005236E4: D6100034 0241192C
	v_mul_u32_u24_e32 v55, s7, v45                             // 0000005236EC: 166E5A07
	v_mul_u32_u24_e32 v45, s8, v45                             // 0000005236F0: 165A5A08
	v_lshl_add_u32 v45, v45, 24, v55                           // 0000005236F4: D646002D 04DD312D
	v_mul_u32_u24_e32 v55, s7, v52                             // 0000005236FC: 166E6807
	v_mul_u32_u24_e32 v52, s8, v52                             // 000000523700: 16686808
	v_sad_u8 v51, v51, 0, 0x6400                               // 000000523704: D6220033 03FD0133 00006400
	v_lshl_add_u32 v52, v52, 24, v55                           // 000000523710: D6460034 04DD3134
	v_and_b32_e32 v49, 0xffff, v49                             // 000000523718: 366262FF 0000FFFF
	v_sad_u8 v50, v50, 0, 0x6400                               // 000000523720: D6220032 03FD0132 00006400
	v_bfe_u32 v53, v44, 8, 16                                  // 00000052372C: D6100035 0241112C
	v_mul_u32_u24_e32 v55, s7, v53                             // 000000523734: 166E6A07
	v_mul_u32_u24_e32 v53, s8, v53                             // 000000523738: 166A6A08
	v_and_b32_e32 v51, 0xffff, v51                             // 00000052373C: 366666FF 0000FFFF
	v_sad_u8 v45, v45, 0, 0x6400                               // 000000523744: D622002D 03FD012D 00006400
	v_sad_u8 v52, v52, 0, 0x6400                               // 000000523750: D6220034 03FD0134 00006400
	v_lshl_add_u32 v53, v53, 24, v55                           // 00000052375C: D6460035 04DD3135
	v_lshl_or_b32 v49, v50, 16, v49                            // 000000523764: D6560031 04C52132
	v_bfe_u32 v54, v44, 4, 16                                  // 00000052376C: D6100036 0241092C
	v_mul_u32_u24_e32 v55, s7, v54                             // 000000523774: 166E6C07
	v_mul_u32_u24_e32 v54, s8, v54                             // 000000523778: 166C6C08
	s_delay_alu instid0(VALU_DEP_1)                            // 00000052377C: BF870001
	v_lshl_add_u32 v54, v54, 24, v55                           // 000000523780: D6460036 04DD3136
	v_lshl_or_b32 v45, v45, 16, v51                            // 000000523788: D656002D 04CD212D
	v_and_b32_e32 v50, 0xffff, v52                             // 000000523790: 366468FF 0000FFFF
	v_sad_u8 v51, v53, 0, 0x6400                               // 000000523798: D6220033 03FD0135 00006400
	v_pk_fma_f16 v49, v49, s9, 0xc931 op_sel_hi:[1,0,0]        // 0000005237A4: CC0E0031 0BFC1331 0000C931
	v_and_b32_e32 v44, 0xffff, v44                             // 0000005237B0: 365858FF 0000FFFF
	v_mul_u32_u24_e32 v53, s7, v44                             // 0000005237B8: 166A5807
	v_mul_u32_u24_e32 v44, s8, v44                             // 0000005237BC: 16585808
	v_sad_u8 v52, v54, 0, 0x6400                               // 0000005237C0: D6220034 03FD0136 00006400
	s_delay_alu instid0(VALU_DEP_2)                            // 0000005237CC: BF870002
	v_lshl_add_u32 v44, v44, 24, v53                           // 0000005237D0: D646002C 04D5312C
	v_pk_fma_f16 v45, v45, s9, 0xc931 op_sel_hi:[1,0,0]        // 0000005237D8: CC0E002D 0BFC132D 0000C931
	v_lshl_or_b32 v50, v51, 16, v50                            // 0000005237E4: D6560032 04C92133
	v_dot2acc_f32_f16 v13, v49, v1                             // 0000005237EC: 041A0331
	v_and_b32_e32 v51, 0xffff, v52                             // 0000005237F0: 366668FF 0000FFFF
	v_sad_u8 v44, v44, 0, 0x6400                               // 0000005237F8: D622002C 03FD012C 00006400
	v_dot2acc_f32_f16 v14, v46, v2                             // 000000523804: 041C052E
	v_pk_fma_f16 v43, v50, s9, 0xc931 op_sel_hi:[1,0,0]        // 000000523808: CC0E002B 0BFC1332 0000C931
	v_dot2acc_f32_f16 v13, v45, v2                             // 000000523814: 041A052D
	v_bfe_u32 v46, v42, 12, 16                                 // 000000523818: D610002E 0241192A
	v_pk_fma_f16 v45, v47, s9, 0xc931 op_sel_hi:[1,0,0]        // 000000523820: CC0E002D 0BFC132F 0000C931
	v_mul_u32_u24_e32 v47, s7, v46                             // 00000052382C: 165E5C07
	v_mul_u32_u24_e32 v46, s8, v46                             // 000000523830: 165C5C08
	s_delay_alu instid0(VALU_DEP_2)                            // 000000523834: BF870002
	v_lshl_add_u32 v46, v46, 24, v47                           // 000000523838: D646002E 04BD312E
	v_lshl_or_b32 v44, v44, 16, v51                            // 000000523840: D656002C 04CD212C
	v_dot2acc_f32_f16 v13, v43, v3                             // 000000523848: 041A072B
	v_bfe_u32 v43, v42, 8, 16                                  // 00000052384C: D610002B 0241112A
	v_mul_u32_u24_e32 v51, s7, v43                             // 000000523854: 16665607
	v_mul_u32_u24_e32 v43, s8, v43                             // 000000523858: 16565608
	v_sad_u8 v46, v46, 0, 0x6400                               // 00000052385C: D622002E 03FD012E 00006400
	s_delay_alu instid0(VALU_DEP_2)                            // 000000523868: BF870002
	v_lshl_add_u32 v43, v43, 24, v51                           // 00000052386C: D646002B 04CD312B
	v_bfe_u32 v47, v42, 4, 16                                  // 000000523874: D610002F 0241092A
	v_dot2acc_f32_f16 v14, v48, v3                             // 00000052387C: 041C0730
	v_pk_fma_f16 v44, v44, s9, 0xc931 op_sel_hi:[1,0,0]        // 000000523880: CC0E002C 0BFC132C 0000C931
	s_waitcnt vmcnt(1)                                         // 00000052388C: BF8907F7
	v_bfe_u32 v48, v26, 12, 16                                 // 000000523890: D6100030 0241191A
	v_mul_u32_u24_e32 v51, s7, v47                             // 000000523898: 16665E07
	v_mul_u32_u24_e32 v47, s8, v47                             // 00000052389C: 165E5E08
	v_lshl_add_u32 v47, v47, 24, v51                           // 0000005238A0: D646002F 04CD312F
	v_mul_u32_u24_e32 v51, s7, v48                             // 0000005238A8: 16666007
	v_mul_u32_u24_e32 v48, s8, v48                             // 0000005238AC: 16606008
	v_lshl_add_u32 v48, v48, 24, v51                           // 0000005238B0: D6460030 04CD3130
	v_and_b32_e32 v46, 0xffff, v46                             // 0000005238B8: 365C5CFF 0000FFFF
	v_sad_u8 v43, v43, 0, 0x6400                               // 0000005238C0: D622002B 03FD012B 00006400
	v_dual_dot2acc_f32_f16 v13, v44, v4 :: v_dual_and_b32 v42, 0xffff, v42// 0000005238CC: CB24092C 0D2A54FF 0000FFFF
	v_bfe_u32 v49, v26, 8, 16                                  // 0000005238D8: D6100031 0241111A
	v_mul_u32_u24_e32 v51, s7, v42                             // 0000005238E0: 16665407
	v_mul_u32_u24_e32 v42, s8, v42                             // 0000005238E4: 16545408
	s_delay_alu instid0(VALU_DEP_2)                            // 0000005238E8: BF870002
	v_lshl_add_u32 v42, v42, 24, v51                           // 0000005238EC: D646002A 04CD312A
	v_mul_u32_u24_e32 v51, s7, v49                             // 0000005238F4: 16666207
	v_mul_u32_u24_e32 v49, s8, v49                             // 0000005238F8: 16626208
	v_sad_u8 v47, v47, 0, 0x6400                               // 0000005238FC: D622002F 03FD012F 00006400
	v_sad_u8 v48, v48, 0, 0x6400                               // 000000523908: D6220030 03FD0130 00006400
	v_lshl_add_u32 v49, v49, 24, v51                           // 000000523914: D6460031 04CD3131
	v_lshl_or_b32 v43, v43, 16, v46                            // 00000052391C: D656002B 04B9212B
	v_bfe_u32 v50, v26, 4, 16                                  // 000000523924: D6100032 0241091A
	v_and_b32_e32 v46, 0xffff, v47                             // 00000052392C: 365C5EFF 0000FFFF
	v_and_b32_e32 v47, 0xffff, v48                             // 000000523934: 365E60FF 0000FFFF
	v_sad_u8 v48, v49, 0, 0x6400                               // 00000052393C: D6220030 03FD0131 00006400
	v_mul_u32_u24_e32 v49, s7, v50                             // 000000523948: 16626407
	v_sad_u8 v42, v42, 0, 0x6400                               // 00000052394C: D622002A 03FD012A 00006400
	v_mul_u32_u24_e32 v50, s8, v50                             // 000000523958: 16646408
	v_lshl_add_u32 v49, v50, 24, v49                           // 00000052395C: D6460031 04C53132
	v_pk_fma_f16 v43, v43, s9, 0xc931 op_sel_hi:[1,0,0]        // 000000523964: CC0E002B 0BFC132B 0000C931
	v_and_b32_e32 v26, 0xffff, v26                             // 000000523970: 363434FF 0000FFFF
	v_lshl_or_b32 v42, v42, 16, v46                            // 000000523978: D656002A 04B9212A
	v_lshl_or_b32 v46, v48, 16, v47                            // 000000523980: D656002E 04BD2130
	v_sad_u8 v47, v49, 0, 0x6400                               // 000000523988: D622002F 03FD0131 00006400
	v_dot2acc_f32_f16 v12, v43, v1                             // 000000523994: 0418032B
	v_bfe_u32 v43, v21, 12, 16                                 // 000000523998: D610002B 02411915
	v_dual_dot2acc_f32_f16 v14, v45, v4 :: v_dual_mov_b32 v45, v28// 0000005239A0: CB10092D 0E2C011C
	v_mul_u32_u24_e32 v48, s7, v26                             // 0000005239A8: 16603407
	v_mul_u32_u24_e32 v26, s8, v26                             // 0000005239AC: 16343408
	v_lshl_add_u32 v26, v26, 24, v48                           // 0000005239B0: D646001A 04C1311A
	v_bfe_u32 v48, v21, 4, 16                                  // 0000005239B8: D6100030 02410915
	v_mul_u32_u24_e32 v52, s7, v43                             // 0000005239C0: 16685607
	v_mul_u32_u24_e32 v43, s8, v43                             // 0000005239C4: 16565608
	v_lshl_add_u32 v43, v43, 24, v52                           // 0000005239C8: D646002B 04D1312B
	v_mul_u32_u24_e32 v52, s7, v48                             // 0000005239D0: 16686007
	v_mul_u32_u24_e32 v48, s8, v48                             // 0000005239D4: 16606008
	v_lshl_add_u32 v48, v48, 24, v52                           // 0000005239D8: D6460030 04D13130
	v_pk_fma_f16 v23, v46, s9, 0xc931 op_sel_hi:[1,0,0]        // 0000005239E0: CC0E0017 0BFC132E 0000C931
	v_and_b32_e32 v46, 0xffff, v47                             // 0000005239EC: 365C5EFF 0000FFFF
	v_bfe_u32 v47, v21, 8, 16                                  // 0000005239F4: D610002F 02411115
	v_and_b32_e32 v21, 0xffff, v21                             // 0000005239FC: 362A2AFF 0000FFFF
	v_mul_u32_u24_e32 v52, s7, v47                             // 000000523A04: 16685E07
	v_mul_u32_u24_e32 v47, s8, v47                             // 000000523A08: 165E5E08
	s_delay_alu instid0(VALU_DEP_2)                            // 000000523A0C: BF870002
	v_lshl_add_u32 v47, v47, 24, v52                           // 000000523A10: D646002F 04D1312F
	v_mul_u32_u24_e32 v52, s7, v21                             // 000000523A18: 16682A07
	v_mul_u32_u24_e32 v21, s8, v21                             // 000000523A1C: 162A2A08
	v_sad_u8 v48, v48, 0, 0x6400                               // 000000523A20: D6220030 03FD0130 00006400
	v_lshl_add_u32 v21, v21, 24, v52                           // 000000523A2C: D6460015 04D13115
	v_sad_u8 v43, v43, 0, 0x6400                               // 000000523A34: D622002B 03FD012B 00006400
	s_waitcnt vmcnt(0)                                         // 000000523A40: BF8903F7
	v_bfe_u32 v49, v19, 12, 16                                 // 000000523A44: D6100031 02411913
	v_bfe_u32 v50, v19, 8, 16                                  // 000000523A4C: D6100032 02411113
	v_mul_u32_u24_e32 v52, s7, v49                             // 000000523A54: 16686207
	v_mul_u32_u24_e32 v49, s8, v49                             // 000000523A58: 16626208
	s_delay_alu instid0(VALU_DEP_2)                            // 000000523A5C: BF870002
	v_lshl_add_u32 v49, v49, 24, v52                           // 000000523A60: D6460031 04D13131
	v_mul_u32_u24_e32 v52, s7, v50                             // 000000523A68: 16686407
	v_mul_u32_u24_e32 v50, s8, v50                             // 000000523A6C: 16646408
	v_and_b32_e32 v48, 0xffff, v48                             // 000000523A70: 366060FF 0000FFFF
	v_sad_u8 v21, v21, 0, 0x6400                               // 000000523A78: D6220015 03FD0115 00006400
	v_lshl_add_u32 v50, v50, 24, v52                           // 000000523A84: D6460032 04D13132
	v_and_b32_e32 v43, 0xffff, v43                             // 000000523A8C: 365656FF 0000FFFF
	v_sad_u8 v47, v47, 0, 0x6400                               // 000000523A94: D622002F 03FD012F 00006400
	v_bfe_u32 v51, v19, 4, 16                                  // 000000523AA0: D6100033 02410913
	v_and_b32_e32 v19, 0xffff, v19                             // 000000523AA8: 362626FF 0000FFFF
	v_mul_u32_u24_e32 v52, s7, v51                             // 000000523AB0: 16686607
	v_mul_u32_u24_e32 v51, s8, v51                             // 000000523AB4: 16666608
	s_delay_alu instid0(VALU_DEP_2)                            // 000000523AB8: BF870002
	v_lshl_add_u32 v51, v51, 24, v52                           // 000000523ABC: D6460033 04D13133
	v_lshl_or_b32 v21, v21, 16, v48                            // 000000523AC4: D6560015 04C12115
	v_sad_u8 v48, v50, 0, 0x6400                               // 000000523ACC: D6220030 03FD0132 00006400
	v_mov_b32_e32 v52, v38                                     // 000000523AD8: 7E680326
	v_mul_u32_u24_e32 v50, s7, v19                             // 000000523ADC: 16642607
	v_mul_u32_u24_e32 v19, s8, v19                             // 000000523AE0: 16262608
	v_sad_u8 v49, v49, 0, 0x6400                               // 000000523AE4: D6220031 03FD0131 00006400
	v_lshl_add_u32 v19, v19, 24, v50                           // 000000523AF0: D6460013 04C93113
	v_mov_b32_e32 v50, v30                                     // 000000523AF8: 7E64031E
	v_lshl_or_b32 v43, v47, 16, v43                            // 000000523AFC: D656002B 04AD212F
	v_pk_fma_f16 v42, v42, s9, 0xc931 op_sel_hi:[1,0,0]        // 000000523B04: CC0E002A 0BFC132A 0000C931
	v_dual_mov_b32 v54, v31 :: v_dual_and_b32 v47, 0xffff, v49 // 000000523B10: CA24011F 362E62FF 0000FFFF
	v_sad_u8 v49, v51, 0, 0x6400                               // 000000523B1C: D6220031 03FD0133 00006400
	s_delay_alu instid0(VALU_DEP_4)                            // 000000523B28: BF870004
	v_pk_fma_f16 v43, v43, s9, 0xc931 op_sel_hi:[1,0,0]        // 000000523B2C: CC0E002B 0BFC132B 0000C931
	v_sad_u8 v26, v26, 0, 0x6400                               // 000000523B38: D622001A 03FD011A 00006400
	v_pk_fma_f16 v21, v21, s9, 0xc931 op_sel_hi:[1,0,0]        // 000000523B44: CC0E0015 0BFC1315 0000C931
	v_lshl_or_b32 v47, v48, 16, v47                            // 000000523B50: D656002F 04BD2130
	v_dual_mov_b32 v51, v38 :: v_dual_and_b32 v48, 0xffff, v49 // 000000523B58: CA240126 333062FF 0000FFFF
	v_dot2acc_f32_f16 v11, v43, v1                             // 000000523B64: 0416032B
	v_sad_u8 v19, v19, 0, 0x6400                               // 000000523B68: D6220013 03FD0113 00006400
	v_lshl_or_b32 v1, v26, 16, v46                             // 000000523B74: D6560001 04B9211A
	v_dot2acc_f32_f16 v12, v42, v2                             // 000000523B7C: 0418052A
	v_pk_fma_f16 v26, v47, s9, 0xc931 op_sel_hi:[1,0,0]        // 000000523B80: CC0E001A 0BFC132F 0000C931
	v_dot2acc_f32_f16 v11, v21, v2                             // 000000523B8C: 04160515
	v_lshl_or_b32 v19, v19, 16, v48                            // 000000523B90: D6560013 04C12113
	v_pk_fma_f16 v1, v1, s9, 0xc931 op_sel_hi:[1,0,0]          // 000000523B98: CC0E0001 0BFC1301 0000C931
	v_dual_dot2acc_f32_f16 v12, v23, v3 :: v_dual_mov_b32 v23, v33// 000000523BA4: CB100717 0C160121
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000523BAC: BF870234
	v_dot2acc_f32_f16 v11, v26, v3                             // 000000523BB0: 0416071A
	v_add_nc_u32_e32 v3, v20, v5                               // 000000523BB4: 4A060B14
	v_pk_fma_f16 v2, v19, s9, 0xc931 op_sel_hi:[1,0,0]         // 000000523BB8: CC0E0002 0BFC1313 0000C931
	v_dot2acc_f32_f16 v12, v1, v4                              // 000000523BC4: 04180901
	v_mov_b32_e32 v19, v33                                     // 000000523BC8: 7E260321
	v_mov_b32_e32 v21, v6                                      // 000000523BCC: 7E2A0306
	v_cmp_eq_u32_e32 vcc_lo, 1, v3                             // 000000523BD0: 7C940681
	v_dual_dot2acc_f32_f16 v11, v2, v4 :: v_dual_mov_b32 v26, v35// 000000523BD4: CB100902 0B1A0123
	v_mov_b32_e32 v43, v35                                     // 000000523BDC: 7E560323
	v_mov_b32_e32 v42, v27                                     // 000000523BE0: 7E54031B
	v_mov_b32_e32 v44, v36                                     // 000000523BE4: 7E580324
	v_dual_mov_b32 v46, v36 :: v_dual_mov_b32 v47, v37         // 000000523BE8: CA100124 2E2E0125
	v_mov_b32_e32 v49, v37                                     // 000000523BF0: 7E620325
	v_dual_mov_b32 v48, v29 :: v_dual_mov_b32 v53, v39         // 000000523BF4: CA10011D 30340127
	v_dual_mov_b32 v55, v39 :: v_dual_mov_b32 v2, v32          // 000000523BFC: CA100127 37020120
	v_mov_b32_e32 v3, v41                                      // 000000523C04: 7E060329
	s_or_b32 s6, vcc_lo, s6                                    // 000000523C08: 8C06066A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000523C0C: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 000000523C10: 917E067E
	s_cbranch_execz 56                                         // 000000523C14: BFA50038 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb1ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x19f8>
	s_mov_b32 s10, exec_lo                                     // 000000523C18: BE8A007E
	.long 0xd4c1007e                                           // 000000523C1C: D4C1007E
	v_cndmask_b32_e32 v1, v5, v7, vcc_lo                       // 000000523C20: 02020F05
	s_cbranch_execz 64616                                      // 000000523C24: BFA5FC68 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb1ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0xac8>
	v_ashrrev_i32_e32 v6, 31, v5                               // 000000523C28: 340C0A9F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000523C2C: BF870091
	.long 0xd73c001b                                           // 000000523C30: D73C001B
	v_cndmask_b32_e32 v1, 10, v5, vcc_lo                       // 000000523C34: 02020A8A
	.long 0xd7006a01                                           // 000000523C38: D7006A01
	v_cndmask_b32_e32 v1, s1, v27, vcc_lo                      // 000000523C3C: 02023601
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000523C40: BF870111
	v_add_co_ci_u32_e64 v4, null, s5, v28, vcc_lo              // 000000523C44: D5207C04 01AA3805
	.long 0xd7006a23                                           // 000000523C4C: D7006A23
	v_cndmask_b32_e32 v1, v1, v25, vcc_lo                      // 000000523C50: 02023301
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000523C54: BF8700A1
	v_add_co_ci_u32_e64 v36, null, 0, v4, vcc_lo               // 000000523C58: D5207C24 01AA0880
	.long 0xd7006a3c                                           // 000000523C60: D7006A3C
	v_cndmask_b32_e32 v1, v1, v22, vcc_lo                      // 000000523C64: 02022D01
	v_add_co_ci_u32_e64 v61, null, 0, v4, vcc_lo               // 000000523C68: D5207C3D 01AA0880
	s_clause 0xf                                               // 000000523C70: BF85000F
	global_load_b32 v32, v[35:36], off                         // 000000523C74: DC520000 207C0023
	global_load_b32 v34, v[35:36], off offset:128              // 000000523C7C: DC520080 227C0023
	global_load_b32 v31, v[35:36], off offset:256              // 000000523C84: DC520100 1F7C0023
	global_load_b32 v30, v[35:36], off offset:384              // 000000523C8C: DC520180 1E7C0023
	global_load_b32 v29, v[35:36], off offset:512              // 000000523C94: DC520200 1D7C0023
	global_load_b32 v28, v[35:36], off offset:640              // 000000523C9C: DC520280 1C7C0023
	global_load_b32 v27, v[35:36], off offset:768              // 000000523CA4: DC520300 1B7C0023
	global_load_b32 v6, v[35:36], off offset:896               // 000000523CAC: DC520380 067C0023
	global_load_b32 v41, v[60:61], off                         // 000000523CB4: DC520000 297C003C
	global_load_b32 v40, v[60:61], off offset:128              // 000000523CBC: DC520080 287C003C
	global_load_b32 v39, v[60:61], off offset:256              // 000000523CC4: DC520100 277C003C
	global_load_b32 v38, v[60:61], off offset:384              // 000000523CCC: DC520180 267C003C
	global_load_b32 v37, v[60:61], off offset:512              // 000000523CD4: DC520200 257C003C
	global_load_b32 v36, v[60:61], off offset:640              // 000000523CDC: DC520280 247C003C
	global_load_b32 v35, v[60:61], off offset:768              // 000000523CE4: DC520300 237C003C
	global_load_b32 v33, v[60:61], off offset:896              // 000000523CEC: DC520380 217C003C
	s_branch 64564                                             // 000000523CF4: BFA0FC34 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb1ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0xac8>
	s_or_b32 exec_lo, exec_lo, s6                              // 000000523CF8: 8C7E067E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000523CFC: BF870009
	s_or_b32 exec_lo, exec_lo, s0                              // 000000523D00: 8C7E007E
	s_waitcnt vmcnt(23)                                        // 000000523D04: BF895FF7
	v_dual_mov_b32 v1, v18 :: v_dual_mov_b32 v2, v17           // 000000523D08: CA100112 01020111
	s_waitcnt vmcnt(15)                                        // 000000523D10: BF893FF7
	v_dual_mov_b32 v3, v16 :: v_dual_mov_b32 v4, v14           // 000000523D14: CA100110 0304010E
	v_dual_mov_b32 v7, v15 :: v_dual_mov_b32 v6, v12           // 000000523D1C: CA10010F 0706010C
	v_mov_b32_e32 v5, v13                                      // 000000523D24: 7E0A030D
	s_waitcnt vmcnt(0)                                         // 000000523D28: BF8903F7
	v_mov_b32_e32 v19, v11                                     // 000000523D2C: 7E26030B
	s_mov_b32 s0, 0x76543210                                   // 000000523D30: BE8000FF 76543210
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000523D38: BF870009
	v_permlanex16_b32 v1, v1, s0, 0xfedcba98                   // 000000523D3C: D65C0001 03FC0101 FEDCBA98
	v_permlanex16_b32 v2, v2, s0, 0xfedcba98                   // 000000523D48: D65C0002 03FC0102 FEDCBA98
	v_permlanex16_b32 v3, v3, s0, 0xfedcba98                   // 000000523D54: D65C0003 03FC0103 FEDCBA98
	v_permlanex16_b32 v7, v7, s0, 0xfedcba98                   // 000000523D60: D65C0007 03FC0107 FEDCBA98
	v_permlanex16_b32 v4, v4, s0, 0xfedcba98                   // 000000523D6C: D65C0004 03FC0104 FEDCBA98
	v_permlanex16_b32 v5, v5, s0, 0xfedcba98                   // 000000523D78: D65C0005 03FC0105 FEDCBA98
	v_permlanex16_b32 v6, v6, s0, 0xfedcba98                   // 000000523D84: D65C0006 03FC0106 FEDCBA98
	v_permlanex16_b32 v19, v19, s0, 0xfedcba98                 // 000000523D90: D65C0013 03FC0113 FEDCBA98
	.long 0xd44c0000                                           // 000000523D9C: D44C0000
	v_cndmask_b32_e32 v1, 16, v10, vcc_lo                      // 000000523DA0: 02021490
	s_barrier                                                  // 000000523DA4: BFBD0000
	buffer_gl0_inv                                             // 000000523DA8: E0AC0000 00000000
	s_and_saveexec_b32 s1, s0                                  // 000000523DB0: BE812000
	s_cbranch_execz 18                                         // 000000523DB4: BFA50012 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb1ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1b00>
	v_dual_add_f32 v10, v11, v19 :: v_dual_add_f32 v1, v18, v1 // 000000523DB8: C908270B 0A000312
	v_dual_add_f32 v2, v17, v2 :: v_dual_add_f32 v3, v16, v3   // 000000523DC0: C9080511 02020710
	v_lshl_or_b32 v9, v8, 9, v9                                // 000000523DC8: D6560009 04251308
	v_dual_add_f32 v7, v15, v7 :: v_dual_add_f32 v4, v14, v4   // 000000523DD0: C9080F0F 0704090E
	v_dual_add_f32 v5, v13, v5 :: v_dual_add_f32 v6, v12, v6   // 000000523DD8: C9080B0D 05060D0C
	ds_store_2addr_b32 v9, v1, v2 offset1:16                   // 000000523DE0: D8381000 00020109
	ds_store_2addr_b32 v9, v3, v7 offset0:32 offset1:48        // 000000523DE8: D8383020 00070309
	ds_store_2addr_b32 v9, v4, v5 offset0:64 offset1:80        // 000000523DF0: D8385040 00050409
	ds_store_2addr_b32 v9, v6, v10 offset0:96 offset1:112      // 000000523DF8: D8387060 000A0609
	s_or_b32 exec_lo, exec_lo, s1                              // 000000523E00: 8C7E017E
	.long 0xd44c0001                                           // 000000523E04: D44C0001
	v_cndmask_b32_e32 v1, 0x80, v0, vcc_lo                     // 000000523E08: 020200FF 00000080
	s_waitcnt lgkmcnt(0)                                       // 000000523E10: BF89FC07
	s_barrier                                                  // 000000523E14: BFBD0000
	buffer_gl0_inv                                             // 000000523E18: E0AC0000 00000000
	s_and_saveexec_b32 s5, s1                                  // 000000523E20: BE852001
	s_cbranch_execnz 7                                         // 000000523E24: BFA60007 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb1ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1b44>
	s_or_b32 exec_lo, exec_lo, s5                              // 000000523E28: 8C7E057E
	s_cmp_lt_i32 s33, 2                                        // 000000523E2C: BF048221
	s_mov_b32 s5, -1                                           // 000000523E30: BE8500C1
	s_cbranch_scc0 33                                          // 000000523E34: BFA10021 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb1ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1bbc>
	s_and_b32 vcc_lo, exec_lo, s5                              // 000000523E38: 8B6A057E
	s_cbranch_vccnz 154                                        // 000000523E3C: BFA4009A <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb1ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1da8>
	s_endpgm                                                   // 000000523E40: BFB00000
	v_lshlrev_b32_e32 v7, 2, v0                                // 000000523E44: 300E0082
	ds_load_2addr_stride64_b32 v[1:2], v7 offset1:2            // 000000523E48: D8E00200 01000007
	ds_load_2addr_stride64_b32 v[3:4], v7 offset0:4 offset1:6  // 000000523E50: D8E00604 03000007
	ds_load_2addr_stride64_b32 v[5:6], v7 offset0:8 offset1:10 // 000000523E58: D8E00A08 05000007
	s_waitcnt lgkmcnt(2)                                       // 000000523E60: BF89FC27
	v_add_f32_e32 v1, 0, v1                                    // 000000523E64: 06020280
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000523E68: BF8700A1
	v_add_f32_e32 v1, v1, v2                                   // 000000523E6C: 06020501
	s_waitcnt lgkmcnt(1)                                       // 000000523E70: BF89FC17
	v_add_f32_e32 v3, v1, v3                                   // 000000523E74: 06060701
	ds_load_2addr_stride64_b32 v[1:2], v7 offset0:12 offset1:14// 000000523E78: D8E00E0C 01000007
	v_add_f32_e32 v3, v3, v4                                   // 000000523E80: 06060903
	s_waitcnt lgkmcnt(1)                                       // 000000523E84: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000523E88: BF870091
	v_add_f32_e32 v3, v3, v5                                   // 000000523E8C: 06060B03
	v_add_f32_e32 v3, v3, v6                                   // 000000523E90: 06060D03
	s_waitcnt lgkmcnt(0)                                       // 000000523E94: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000523E98: BF870091
	v_add_f32_e32 v1, v3, v1                                   // 000000523E9C: 06020303
	v_add_f32_e32 v1, v1, v2                                   // 000000523EA0: 06020501
	ds_store_b32 v7, v1 offset:4096                            // 000000523EA4: D8341000 00000107
	s_or_b32 exec_lo, exec_lo, s5                              // 000000523EAC: 8C7E057E
	s_cmp_lt_i32 s33, 2                                        // 000000523EB0: BF048221
	s_mov_b32 s5, -1                                           // 000000523EB4: BE8500C1
	s_cbranch_scc1 65503                                       // 000000523EB8: BFA2FFDF <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb1ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1b38>
	s_waitcnt lgkmcnt(0)                                       // 000000523EBC: BF89FC07
	s_barrier                                                  // 000000523EC0: BFBD0000
	buffer_gl0_inv                                             // 000000523EC4: E0AC0000 00000000
	s_and_saveexec_b32 s5, s1                                  // 000000523ECC: BE852001
	s_cbranch_execz 17                                         // 000000523ED0: BFA50011 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb1ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1c18>
	v_lshlrev_b32_e32 v1, 2, v0                                // 000000523ED4: 30020082
	s_mul_hi_i32 s7, s26, s4                                   // 000000523ED8: 9707041A
	s_mul_i32 s6, s26, s4                                      // 000000523EDC: 9606041A
	s_lshl_b32 s8, s2, 7                                       // 000000523EE0: 84088702
	s_lshl_b64 s[6:7], s[6:7], 2                               // 000000523EE4: 84868206
	ds_load_b32 v2, v1 offset:4096                             // 000000523EE8: D8D81000 02000001
	s_ashr_i32 s9, s8, 31                                      // 000000523EF0: 86099F08
	s_add_u32 s4, s16, s6                                      // 000000523EF4: 80040610
	s_addc_u32 s10, s17, s7                                    // 000000523EF8: 820A0711
	s_lshl_b64 s[6:7], s[8:9], 2                               // 000000523EFC: 84868208
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000523F00: BF870009
	s_add_u32 s6, s4, s6                                       // 000000523F04: 80060604
	s_addc_u32 s7, s10, s7                                     // 000000523F08: 8207070A
	s_waitcnt lgkmcnt(0)                                       // 000000523F0C: BF89FC07
	global_store_b32 v1, v2, s[6:7]                            // 000000523F10: DC6A0000 00060201
	s_or_b32 exec_lo, exec_lo, s5                              // 000000523F18: 8C7E057E
	.long 0xd44a0004                                           // 000000523F1C: D44A0004
	v_cndmask_b32_e32 v1, 0, v0, vcc_lo                        // 000000523F20: 02020080
	s_waitcnt_vscnt null, 0x0                                  // 000000523F24: BC7C0000
	buffer_gl1_inv                                             // 000000523F28: E0B00000 00000000
	buffer_gl0_inv                                             // 000000523F30: E0AC0000 00000000
	s_barrier                                                  // 000000523F38: BFBD0000
	buffer_gl0_inv                                             // 000000523F3C: E0AC0000 00000000
	s_and_saveexec_b32 s5, s4                                  // 000000523F44: BE852004
	s_cbranch_execz 29                                         // 000000523F48: BFA5001D <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb1ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1cc0>
	s_mov_b32 s7, exec_lo                                      // 000000523F4C: BE87007E
	s_mov_b32 s6, exec_lo                                      // 000000523F50: BE86007E
	.long 0xd71f0001                                           // 000000523F54: D71F0001
	v_cndmask_b32_e32 v0, s7, v128, vcc_lo                     // 000000523F58: 02010007
	s_delay_alu instid0(VALU_DEP_1)                            // 000000523F5C: BF870001
	v_cmpx_eq_u32_e32 0, v1                                    // 000000523F60: 7D940280
	s_cbranch_execz 9                                          // 000000523F64: BFA50009 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb1ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1c8c>
	s_lshl_b64 s[8:9], s[2:3], 2                               // 000000523F68: 84888202
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 000000523F6C: BF8704B9
	s_add_u32 s8, s18, s8                                      // 000000523F70: 80080812
	s_addc_u32 s9, s19, s9                                     // 000000523F74: 82090913
	s_bcnt1_i32_b32 s7, s7                                     // 000000523F78: BE871807
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v3, s7              // 000000523F7C: CA100080 02020007
	global_atomic_add_u32 v2, v2, v3, s[8:9] glc               // 000000523F84: DCD64000 02080302
	s_or_b32 exec_lo, exec_lo, s6                              // 000000523F8C: 8C7E067E
	s_waitcnt vmcnt(0)                                         // 000000523F90: BF8903F7
	v_readfirstlane_b32 s6, v2                                 // 000000523F94: 7E0C0502
	s_delay_alu instid0(VALU_DEP_1)                            // 000000523F98: BF870001
	v_dual_mov_b32 v2, 0 :: v_dual_add_nc_u32 v1, s6, v1       // 000000523F9C: CA200080 02000206
	s_add_i32 s6, s33, -1                                      // 000000523FA4: 8106C121
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 000000523FA8: BF870481
	v_cmp_eq_u32_e32 vcc_lo, s6, v1                            // 000000523FAC: 7C940206
	v_cndmask_b32_e64 v1, 0, 1, vcc_lo                         // 000000523FB0: D5010001 01A90280
	ds_store_b32 v2, v1 offset:5120                            // 000000523FB8: D8341400 00000102
	s_or_b32 exec_lo, exec_lo, s5                              // 000000523FC0: 8C7E057E
	v_mov_b32_e32 v1, 0                                        // 000000523FC4: 7E020280
	s_waitcnt lgkmcnt(0)                                       // 000000523FC8: BF89FC07
	s_barrier                                                  // 000000523FCC: BFBD0000
	buffer_gl0_inv                                             // 000000523FD0: E0AC0000 00000000
	ds_load_b32 v1, v1 offset:5120                             // 000000523FD8: D8D81400 01000001
	s_waitcnt lgkmcnt(0)                                       // 000000523FE0: BF89FC07
	v_cmp_eq_u32_e32 vcc_lo, 0, v1                             // 000000523FE4: 7C940280
	s_cbranch_vccnz 46                                         // 000000523FE8: BFA4002E <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb1ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1da4>
	buffer_gl1_inv                                             // 000000523FEC: E0B00000 00000000
	buffer_gl0_inv                                             // 000000523FF4: E0AC0000 00000000
	s_and_saveexec_b32 s5, s1                                  // 000000523FFC: BE852001
	s_cbranch_execz 28                                         // 000000524000: BFA5001C <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb1ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1d74>
	s_lshl_b32 s6, s2, 7                                       // 000000524004: 84068702
	v_dual_mov_b32 v4, 0 :: v_dual_lshlrev_b32 v3, 2, v0       // 000000524008: CA220080 04020082
	s_ashr_i32 s7, s6, 31                                      // 000000524010: 86079F06
	s_ashr_i32 s27, s26, 31                                    // 000000524014: 861B9F1A
	s_lshl_b64 s[6:7], s[6:7], 2                               // 000000524018: 84868206
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000052401C: BF8700B9
	s_add_u32 s1, s16, s6                                      // 000000524020: 80010610
	s_addc_u32 s6, s17, s7                                     // 000000524024: 82060711
	.long 0xd7000101                                           // 000000524028: D7000101
	v_cndmask_b32_e32 v1, s1, v3, vcc_lo                       // 00000052402C: 02020601
	v_add_co_ci_u32_e64 v2, null, s6, 0, s1                    // 000000524030: D5207C02 00050006
	s_lshl_b64 s[6:7], s[26:27], 2                             // 000000524038: 8486821A
	global_load_b32 v5, v[1:2], off glc                        // 00000052403C: DC524000 057C0001
	.long 0xd7006a01                                           // 000000524044: D7006A01
	v_cndmask_b32_e32 v0, v1, v6, vcc_lo                       // 000000524048: 02000D01
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000052404C: BF8704A1
	v_add_co_ci_u32_e64 v2, null, s7, v2, vcc_lo               // 000000524050: D5207C02 01AA0407
	s_add_i32 s33, s33, -1                                     // 000000524058: 8121C121
	s_cmp_eq_u32 s33, 0                                        // 00000052405C: BF068021
	s_waitcnt vmcnt(0)                                         // 000000524060: BF8903F7
	v_add_f32_e32 v4, v4, v5                                   // 000000524064: 06080B04
	s_cbranch_scc0 65524                                       // 000000524068: BFA1FFF4 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb1ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1d3c>
	ds_store_b32 v3, v4 offset:4096                            // 00000052406C: D8341000 00000403
	s_or_b32 exec_lo, exec_lo, s5                              // 000000524074: 8C7E057E
	s_and_saveexec_b32 s1, s4                                  // 000000524078: BE812004
	s_cbranch_execz 6                                          // 00000052407C: BFA50006 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb1ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1d98>
	s_lshl_b64 s[4:5], s[2:3], 2                               // 000000524080: 84848202
	v_mov_b32_e32 v1, 0                                        // 000000524084: 7E020280
	s_add_u32 s4, s18, s4                                      // 000000524088: 80040412
	s_addc_u32 s5, s19, s5                                     // 00000052408C: 82050513
	global_store_b32 v1, v1, s[4:5]                            // 000000524090: DC6A0000 00040101
	s_or_b32 exec_lo, exec_lo, s1                              // 000000524098: 8C7E017E
	s_cbranch_execz 65384                                      // 00000052409C: BFA5FF68 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb1ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1b40>
	s_branch 1                                                 // 0000005240A0: BFA00001 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb1ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1da8>
	s_branch 65382                                             // 0000005240A4: BFA0FF66 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb1ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1b40>
	v_cmp_eq_u32_e32 vcc_lo, 0, v8                             // 0000005240A8: 7C941080
	s_cmp_gt_i32 s24, 0                                        // 0000005240AC: BF028018
	s_waitcnt lgkmcnt(0)                                       // 0000005240B0: BF89FC07
	s_waitcnt_vscnt null, 0x0                                  // 0000005240B4: BC7C0000
	s_cselect_b32 s1, -1, 0                                    // 0000005240B8: 980180C1
	s_barrier                                                  // 0000005240BC: BFBD0000
	s_and_b32 s1, vcc_lo, s1                                   // 0000005240C0: 8B01016A
	buffer_gl0_inv                                             // 0000005240C4: E0AC0000 00000000
	s_and_saveexec_b32 s3, s1                                  // 0000005240CC: BE832001
	s_cbranch_execz 65371                                      // 0000005240D0: BFA5FF5B <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb1ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1b40>
	v_and_b32_e32 v1, 15, v0                                   // 0000005240D4: 3602008F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005240D8: BF870091
	v_lshlrev_b32_e32 v2, 2, v1                                // 0000005240DC: 30040282
	v_add_nc_u32_e32 v8, 0x1000, v2                            // 0000005240E0: 4A1004FF 00001000
	ds_load_2addr_b32 v[2:3], v8 offset1:16                    // 0000005240E8: D8DC1000 02000008
	ds_load_2addr_b32 v[4:5], v8 offset0:32 offset1:48         // 0000005240F0: D8DC3020 04000008
	ds_load_2addr_b32 v[6:7], v8 offset0:64 offset1:80         // 0000005240F8: D8DC5040 06000008
	ds_load_2addr_b32 v[8:9], v8 offset0:96 offset1:112        // 000000524100: D8DC7060 08000008
	v_and_b32_e32 v10, 1, v0                                   // 000000524108: 36140081
	s_waitcnt lgkmcnt(3)                                       // 00000052410C: BF89FC37
	v_dual_add_f32 v12, v2, v3 :: v_dual_and_b32 v11, 2, v0    // 000000524110: C9240702 0C0A0082
	s_waitcnt lgkmcnt(2)                                       // 000000524118: BF89FC27
	v_dual_sub_f32 v2, v2, v3 :: v_dual_add_f32 v3, v4, v5     // 00000052411C: C9480702 02020B04
	s_waitcnt lgkmcnt(1)                                       // 000000524124: BF89FC17
	v_dual_sub_f32 v4, v4, v5 :: v_dual_add_f32 v5, v6, v7     // 000000524128: C9480B04 04040F06
	s_waitcnt lgkmcnt(0)                                       // 000000524130: BF89FC07
	v_dual_sub_f32 v6, v6, v7 :: v_dual_sub_f32 v7, v8, v9     // 000000524134: C94A0F06 06061308
	v_dual_add_f32 v8, v8, v9 :: v_dual_and_b32 v9, 4, v0      // 00000052413C: C9241308 08080084
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000524144: BF870233
	v_add_f32_e32 v13, v2, v4                                  // 000000524148: 061A0902
	v_cmp_eq_u32_e32 vcc_lo, 0, v10                            // 00000052414C: 7C941480
	.long 0xd44a0001                                           // 000000524150: D44A0001
	v_cndmask_b32_e32 v1, 0, v11, vcc_lo                       // 000000524154: 02021680
	v_add_f32_e32 v16, v5, v8                                  // 000000524158: 06201105
	v_dual_sub_f32 v5, v5, v8 :: v_dual_add_f32 v14, v12, v3   // 00000052415C: C9481105 050E070C
	v_add_f32_e32 v15, v6, v7                                  // 000000524164: 061E0F06
	v_dual_sub_f32 v3, v12, v3 :: v_dual_sub_f32 v2, v2, v4    // 000000524168: C94A070C 03020902
	v_sub_f32_e32 v4, v6, v7                                   // 000000524170: 08080F06
	.long 0xd44a0003                                           // 000000524174: D44A0003
	v_cndmask_b32_e32 v1, 0, v9, vcc_lo                        // 000000524178: 02021280
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000052417C: BF870214
	v_add_f32_e32 v6, v13, v15                                 // 000000524180: 060C1F0D
	v_dual_sub_f32 v8, v13, v15 :: v_dual_add_f32 v13, v3, v5  // 000000524184: C9481F0D 080C0B03
	v_add_f32_e32 v7, v14, v16                                 // 00000052418C: 060E210E
	v_dual_sub_f32 v15, v3, v5 :: v_dual_add_f32 v12, v2, v4   // 000000524190: C9480B03 0F0C0902
	s_delay_alu instid0(VALU_DEP_4)                            // 000000524198: BF870004
	v_mov_b32_dpp v3, v6 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000052419C: 7E0602FA FF016106
	v_sub_f32_e32 v10, v14, v16                                // 0000005241A4: 0814210E
	v_sub_f32_e32 v14, v2, v4                                  // 0000005241A8: 081C0902
	v_mov_b32_dpp v2, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000005241AC: 7E0402FA FF016107
	v_cndmask_b32_e64 v4, -v6, v6, vcc_lo                      // 0000005241B4: D5010004 21AA0D06
	v_cndmask_b32_e64 v5, -v7, v7, vcc_lo                      // 0000005241BC: D5010005 21AA0F07
	v_mov_b32_dpp v16, v13 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000005241C4: 7E2002FA FF01610D
	v_cndmask_b32_e64 v13, -v13, v13, vcc_lo                   // 0000005241CC: D501000D 21AA1B0D
	v_mov_b32_dpp v18, v15 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000005241D4: 7E2402FA FF01610F
	v_add_f32_e32 v3, v4, v3                                   // 0000005241DC: 06060704
	v_mov_b32_dpp v6, v10 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000005241E0: 7E0C02FA FF01610A
	v_cndmask_b32_e64 v10, -v10, v10, vcc_lo                   // 0000005241E8: D501000A 21AA150A
	v_add_f32_e32 v2, v5, v2                                   // 0000005241F0: 06040505
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000005241F4: BF870112
	v_add_f32_e32 v5, v10, v6                                  // 0000005241F8: 060A0D0A
	v_mov_b32_dpp v6, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000005241FC: 7E0C02FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, s1                          // 000000524204: D5010002 20060502
	v_mov_b32_dpp v7, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000052420C: 7E0E02FA FF016108
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 000000524214: D5010008 21AA1108
	v_mov_b32_dpp v10, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000052421C: 7E1402FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, s1                          // 000000524224: D5010005 20060B05
	v_add_f32_e32 v2, v2, v6                                   // 00000052422C: 06040D02
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000524230: BF870112
	v_add_f32_e32 v10, v5, v10                                 // 000000524234: 06141505
	v_mov_b32_dpp v6, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000524238: 7E0C02FA FF016402
	v_cndmask_b32_e64 v2, -v2, v2, s3                          // 000000524240: D5010002 200E0502
	v_add_f32_e32 v4, v8, v7                                   // 000000524248: 06080F08
	v_cndmask_b32_e64 v8, -v3, v3, s1                          // 00000052424C: D5010008 20060703
	v_mov_b32_dpp v3, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000524254: 7E0602FA FF016203
	v_add_f32_e32 v7, v13, v16                                 // 00000052425C: 060E210D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000524260: BF870112
	v_add_f32_e32 v3, v8, v3                                   // 000000524264: 06060708
	v_mov_b32_dpp v13, v7 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000524268: 7E1A02FA FF016207
	v_cndmask_b32_e64 v7, -v7, v7, s1                          // 000000524270: D5010007 20060F07
	v_mov_b32_dpp v17, v12 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000524278: 7E2202FA FF01610C
	v_cndmask_b32_e64 v12, -v12, v12, vcc_lo                   // 000000524280: D501000C 21AA190C
	v_cndmask_b32_e64 v8, -v3, v3, s3                          // 000000524288: D5010008 200E0703
	v_mov_b32_dpp v9, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000524290: 7E1202FA FF016403
	v_add_f32_e32 v3, v2, v6                                   // 000000524298: 06060D02
	v_mov_b32_dpp v11, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000052429C: 7E1602FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, s1                          // 0000005242A4: D5010004 20060904
	v_add_f32_e32 v13, v7, v13                                 // 0000005242AC: 061A1B07
	v_add_f32_e32 v5, v8, v9                                   // 0000005242B0: 060A1308
	v_mov_b32_dpp v8, v10 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000005242B4: 7E1002FA FF01640A
	v_cndmask_b32_e64 v9, -v10, v10, s3                        // 0000005242BC: D5010009 200E150A
	v_add_f32_e32 v4, v4, v11                                  // 0000005242C4: 06081704
	v_cndmask_b32_e64 v10, -v15, v15, vcc_lo                   // 0000005242C8: D501000A 21AA1F0F
	v_mov_b32_dpp v19, v14 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000005242D0: 7E2602FA FF01610E
	v_mov_b32_dpp v2, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000005242D8: 7E0402FA FF016803
	v_add_f32_e32 v7, v9, v8                                   // 0000005242E0: 060E1109
	v_mov_b32_dpp v11, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000005242E4: 7E1602FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s3                          // 0000005242EC: D5010004 200E0904
	v_mov_b32_dpp v9, v13 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000005242F4: 7E1202FA FF01640D
	v_cndmask_b32_e64 v13, -v13, v13, s3                       // 0000005242FC: D501000D 200E1B0D
	v_add_f32_e32 v10, v10, v18                                // 000000524304: 0614250A
	v_mov_b32_dpp v6, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000524308: 7E0C02FA FF016805
	v_add_f32_e32 v4, v4, v11                                  // 000000524310: 06081704
	v_cndmask_b32_e64 v11, -v14, v14, vcc_lo                   // 000000524314: D501000B 21AA1D0E
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000052431C: BF8701A4
	v_mov_b32_dpp v15, v10 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000524320: 7E1E02FA FF01620A
	v_cndmask_b32_e64 v10, -v10, v10, s1                       // 000000524328: D501000A 2006150A
	v_add_f32_e32 v11, v11, v19                                // 000000524330: 0616270B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000524334: BF870112
	v_dual_add_f32 v8, v10, v15 :: v_dual_add_f32 v15, v13, v9 // 000000524338: C9081F0A 080E130D
	v_mov_b32_dpp v16, v11 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000524340: 7E2002FA FF01620B
	v_cndmask_b32_e64 v11, -v11, v11, s1                       // 000000524348: D501000B 2006170B
	v_mov_b32_dpp v9, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000524350: 7E1202FA FF016804
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000524358: BF870224
	v_cndmask_b32_e64 v18, -v8, v8, s3                         // 00000052435C: D5010012 200E1108
	v_add_f32_e32 v12, v12, v17                                // 000000524364: 0618230C
	v_add_f32_e32 v10, v11, v16                                // 000000524368: 0614210B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000052436C: BF8701A2
	v_mov_b32_dpp v14, v12 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000524370: 7E1C02FA FF01620C
	v_cndmask_b32_e64 v12, -v12, v12, s1                       // 000000524378: D501000C 2006190C
	v_mov_b32_dpp v16, v10 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000524380: 7E2002FA FF01640A
	v_cndmask_b32_e64 v10, -v10, v10, s3                       // 000000524388: D501000A 200E150A
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000524390: BF8701A3
	v_add_f32_e32 v12, v12, v14                                // 000000524394: 06181D0C
	v_mov_b32_dpp v14, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000524398: 7E1C02FA FF016408
	v_add_f32_e32 v16, v10, v16                                // 0000005243A0: 0620210A
	v_mov_b32_dpp v8, v7 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000005243A4: 7E1002FA FF016807
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000005243AC: BF870134
	v_mov_b32_dpp v11, v12 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000005243B0: 7E1602FA FF01640C
	v_cndmask_b32_e64 v12, -v12, v12, s3                       // 0000005243B8: D501000C 200E190C
	v_add_f32_e32 v13, v18, v14                                // 0000005243C0: 061A1D12
	v_add_f32_e32 v17, v12, v11                                // 0000005243C4: 0622170C
	v_mov_b32_dpp v11, v15 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000005243C8: 7E1602FA FF01680F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000005243D0: BF870223
	v_mov_b32_dpp v10, v13 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000005243D4: 7E1402FA FF01680D
	v_mov_b32_dpp v12, v16 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000005243DC: 7E1802FA FF016810
	v_mov_b32_dpp v14, v17 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000005243E4: 7E1C02FA FF016811
	s_and_b32 exec_lo, exec_lo, s0                             // 0000005243EC: 8B7E007E
	s_cbranch_execz 65171                                      // 0000005243F0: BFA5FE93 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi1ELb1ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1b40>
	v_lshl_or_b32 v18, s2, 7, v1                               // 0000005243F4: D6560012 04050E02
	v_and_b32_e32 v0, 8, v0                                    // 0000005243FC: 36000088
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000524400: BF870092
	v_ashrrev_i32_e32 v19, 31, v18                             // 000000524404: 3426249F
	.long 0xd73c0014                                           // 000000524408: D73C0014
	v_cndmask_b32_e32 v1, 1, v18, vcc_lo                       // 00000052440C: 02022481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000524410: BF870091
	.long 0xd7006a14                                           // 000000524414: D7006A14
	v_cndmask_b32_e32 v1, s14, v20, vcc_lo                     // 000000524418: 0202280E
	v_add_co_ci_u32_e64 v21, null, s15, v21, vcc_lo            // 00000052441C: D5207C15 01AA2A0F
	v_cmp_eq_u32_e32 vcc_lo, 0, v0                             // 000000524424: 7C940080
	.long 0xd73c0000                                           // 000000524428: D73C0000
	v_cndmask_b32_e32 v1, 2, v18, vcc_lo                       // 00000052442C: 02022482
	s_clause 0x7                                               // 000000524430: BF850007
	global_load_d16_b16 v22, v[20:21], off offset:32           // 000000524434: DC820020 167C0014
	global_load_d16_b16 v23, v[20:21], off                     // 00000052443C: DC820000 177C0014
	global_load_d16_b16 v24, v[20:21], off offset:96           // 000000524444: DC820060 187C0014
	global_load_d16_b16 v25, v[20:21], off offset:64           // 00000052444C: DC820040 197C0014
	global_load_d16_b16 v26, v[20:21], off offset:160          // 000000524454: DC8200A0 1A7C0014
	global_load_d16_b16 v27, v[20:21], off offset:128          // 00000052445C: DC820080 1B7C0014
	global_load_d16_b16 v28, v[20:21], off offset:224          // 000000524464: DC8200E0 1C7C0014
	global_load_d16_b16 v20, v[20:21], off offset:192          // 00000052446C: DC8200C0 147C0014
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 000000524474: D5010005 21AA0B05
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 00000052447C: D5010003 21AA0703
	v_cndmask_b32_e64 v15, -v15, v15, vcc_lo                   // 000000524484: D501000F 21AA1F0F
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 00000052448C: D5010004 21AA0904
	v_cndmask_b32_e64 v7, -v7, v7, vcc_lo                      // 000000524494: D5010007 21AA0F07
	v_add_f32_e32 v5, v5, v6                                   // 00000052449C: 060A0D05
	v_cndmask_b32_e64 v6, -v17, v17, vcc_lo                    // 0000005244A0: D5010006 21AA2311
	v_cndmask_b32_e64 v16, -v16, v16, vcc_lo                   // 0000005244A8: D5010010 21AA2110
	v_cndmask_b32_e64 v13, -v13, v13, vcc_lo                   // 0000005244B0: D501000D 21AA1B0D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000005244B8: BF870214
	v_dual_add_f32 v2, v3, v2 :: v_dual_mul_f32 v3, 0x3db504f3, v5// 0000005244BC: C9060503 02020AFF 3DB504F3
	v_dual_add_f32 v5, v6, v14 :: v_dual_add_f32 v6, v15, v11  // 0000005244C8: C9081D06 0506170F
	v_dual_add_f32 v4, v4, v9 :: v_dual_add_f32 v7, v7, v8     // 0000005244D0: C9081304 04061107
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000005244D8: BF870194
	v_dual_add_f32 v8, v16, v12 :: v_dual_add_f32 v9, v13, v10 // 0000005244DC: C9081910 0808150D
	v_dual_mul_f32 v2, 0x3db504f3, v2 :: v_dual_mul_f32 v5, 0x3db504f3, v5// 0000005244E4: C8C604FF 02040AFF 3DB504F3
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000005244F0: BF8700A3
	v_dual_mul_f32 v6, 0x3db504f3, v6 :: v_dual_mul_f32 v7, 0x3db504f3, v7// 0000005244F4: C8C60CFF 06060EFF 3DB504F3
	.long 0xd7006a00                                           // 000000524500: D7006A00
	v_cndmask_b32_e32 v1, s28, v0, vcc_lo                      // 000000524504: 0202001C
	v_add_co_ci_u32_e64 v1, null, s29, v1, vcc_lo              // 000000524508: D5207C01 01AA021D
	v_dual_mul_f32 v4, 0x3db504f3, v4 :: v_dual_mul_f32 v9, 0x3db504f3, v9// 000000524510: C8C608FF 040812FF 3DB504F3
	v_mul_f32_e32 v8, 0x3db504f3, v8                           // 00000052451C: 101010FF 3DB504F3
	s_waitcnt vmcnt(7)                                         // 000000524524: BF891FF7
	v_fma_mix_f32 v3, v22, v3, neg(0) op_sel_hi:[1,0,0]        // 000000524528: CC200003 8A020716
	s_waitcnt vmcnt(6)                                         // 000000524530: BF891BF7
	v_fma_mix_f32 v2, v23, v2, neg(0) op_sel_hi:[1,0,0]        // 000000524534: CC200002 8A020517
	s_waitcnt vmcnt(5)                                         // 00000052453C: BF8917F7
	v_fma_mix_f32 v5, v24, v5, neg(0) op_sel_hi:[1,0,0]        // 000000524540: CC200005 8A020B18
	s_waitcnt vmcnt(4)                                         // 000000524548: BF8913F7
	v_fma_mix_f32 v6, v25, v6, neg(0) op_sel_hi:[1,0,0]        // 00000052454C: CC200006 8A020D19
	s_waitcnt vmcnt(3)                                         // 000000524554: BF890FF7
	v_fma_mix_f32 v4, v26, v4, neg(0) op_sel_hi:[1,0,0]        // 000000524558: CC200004 8A02091A
	s_waitcnt vmcnt(2)                                         // 000000524560: BF890BF7
	v_fma_mix_f32 v7, v27, v7, neg(0) op_sel_hi:[1,0,0]        // 000000524564: CC200007 8A020F1B
	s_waitcnt vmcnt(1)                                         // 00000052456C: BF8907F7
	v_fma_mix_f32 v8, v28, v8, neg(0) op_sel_hi:[1,0,0]        // 000000524570: CC200008 8A02111C
	s_waitcnt vmcnt(0)                                         // 000000524578: BF8903F7
	v_fma_mix_f32 v9, v20, v9, neg(0) op_sel_hi:[1,0,0]        // 00000052457C: CC200009 8A021314
	s_clause 0x7                                               // 000000524584: BF850007
	global_store_b32 v[0:1], v2, off                           // 000000524588: DC6A0000 007C0200
	global_store_b32 v[0:1], v3, off offset:64                 // 000000524590: DC6A0040 007C0300
	global_store_b32 v[0:1], v6, off offset:128                // 000000524598: DC6A0080 007C0600
	global_store_b32 v[0:1], v5, off offset:192                // 0000005245A0: DC6A00C0 007C0500
	global_store_b32 v[0:1], v7, off offset:256                // 0000005245A8: DC6A0100 007C0700
	global_store_b32 v[0:1], v4, off offset:320                // 0000005245B0: DC6A0140 007C0400
	global_store_b32 v[0:1], v9, off offset:384                // 0000005245B8: DC6A0180 007C0900
	global_store_b32 v[0:1], v8, off offset:448                // 0000005245C0: DC6A01C0 007C0800
	s_endpgm                                                   // 0000005245C8: BFB00000
		...

